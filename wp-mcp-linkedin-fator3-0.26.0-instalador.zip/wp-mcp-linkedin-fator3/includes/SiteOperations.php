<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class SiteOperations {
    public const OWNER='wordpress-site';
    /** Resolve authority in this blog; never log in as the replacement or rewrite the recorded actor. */
    public static function administrator(array $actor,bool $observe=false): array {
        $id=$actor['user_id']??0;
        if(!is_int($id)||$id<1)throw new Fault('not_authorized','Registro sem administrador de origem válido.');
        if(user_can($id,'manage_options'))return ['user_id'=>$id,'channel'=>null];
        if($observe)self::incident('autorizacao_recusada','administrador:'.$id,true);
        foreach(get_users(['blog_id'=>get_current_blog_id(),'capability'=>'manage_options','fields'=>'ID','orderby'=>'ID','order'=>'ASC']) as $candidate){
            if(!user_can((int)$candidate,'manage_options'))continue;
            return ['user_id'=>(int)$candidate,'channel'=>null];
        }
        throw new Fault('not_authorized','O site não tem administrador disponível com manage_options.');
    }
    /** Durable, per-resource FIFO. A Core acknowledgment covers acceptance even when email is queued. */
    public static function incident(string $code,string $resource,bool $open,int $expires=0): void {
        $state=$open?'aberto':'recuperado';$key=hash('sha256',$code.'|'.$resource);
        try{Store::lock('incident:'.$key,static function()use($key,$code,$resource,$state,$expires){
            $r=Store::get('technical_incident',$key);$v=$r['value']??['state'=>'recuperado','queue'=>[]];
            if($v['state']!==$state){
                $event=['pacote'=>'linkedin','codigo'=>$code,'recurso'=>$resource,'estado'=>$state,'desde'=>time(),'acao_humana'=>true];
                if($expires>0)$event['vence_em']=$expires;
                $v['state']=$state;$v['queue'][]=$event;$r=Store::put('technical_incident',$key,$v,$r['revision']??0);
            }
            if($r)self::deliver($key,$r);
        });}catch(Fault $e){update_option('f3_linkedin_incident_write_failure',['code'=>$e->reason,'at'=>time()],false);}
    }
    private static function deliver(string $key,array $r): void {
        $v=$r['value'];
        while(!empty($v['queue'])){
            try{$ack=apply_filters('f3base_incidente_publicar_v1',null,$v['queue'][0]);}catch(\Throwable $e){return;}
            if(empty($ack['ok']))return;
            array_shift($v['queue']);$r=Store::put('technical_incident',$key,$v,$r['revision']);
        }
        if($v['state']==='recuperado')Store::remove('technical_incident',$key,$r['revision']);
    }
    public static function maintenance(): void {
        $after=(string)get_option('f3_linkedin_incident_cursor','');$rows=Store::scan('technical_incident',$after,60);
        foreach($rows as $r){$key=$r['key'];$after=$key;
            Store::lock('incident:'.$key,static function()use($key){if($r=Store::get('technical_incident',$key))self::deliver($key,$r);});
        }
        update_option('f3_linkedin_incident_cursor',count($rows)===60?$after:'',false);
        foreach(['grant','conversion_grant','connection','schedule'] as $bucket){
            $opt='f3_linkedin_authority_cursor_'.$bucket;$after=(string)get_option($opt,'');$rows=Store::scan($bucket,$after,50);
            foreach($rows as $r){$after=$r['key'];$g=$r['value'];if(empty($g['enabled']))continue;
                $id=(int)($g['principal']['user_id']??$g['configured_by']??$g['updated_by']??0);if($id>0)self::incident('autorizacao_recusada','administrador:'.$id,!user_can($id,'manage_options'));
            }update_option($opt,count($rows)===50?$after:'',false);
        }
        foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];self::scheduleIncident($r['key'],$v);}
    }
    public static function scheduleIncident(string $id,array $v): void {
        $job=!empty($v['last_job'])?Store::get('job',$v['last_job']):null;
        $codes=['not_authorized','unauthorized','forbidden','authorization_revoked','grant_revoked','credential_revoked','revision_conflict','not_configured','connection_paused','token_expired','asset_access_denied','scope_missing','upstream_unauthorized','credential_revalidation_required'];
        $jobFailure=!empty($v['enabled'])&&($job['value']['status']??'')==='paused'&&in_array($job['value']['last_code']??'',$codes,true);
        if(!empty($v['last_code'])&&!$v['enabled']||$jobFailure){self::incident('agenda_parada','agenda:'.$id,true);return;}
        // A queued retry or another inconclusive execution is not evidence of recovery.
        if(empty($v['enabled'])||in_array($job['value']['status']??'',['complete','partial'],true))self::incident('agenda_parada','agenda:'.$id,false);
    }
    public static function reminders(array $c): void {
        // Core's optional public summary exposes the configured window. Share its resource for an equal threshold.
        $central=is_callable(['F3Base_Alertas_Operacionais','resumo'])?(int)(\F3Base_Alertas_Operacionais::resumo()['antecedencia_dias']??14):14;
        foreach(['token'=>'token_vencendo','refresh_token'=>'refresh_vencendo'] as $field=>$code){
            $expires=(int)($c[$field==='token'?'expires_at':'refresh_expires_at']??0);
            if(empty($c[$field])||$expires<1)continue;
            $days=($expires-time())/DAY_IN_SECONDS;
            // On first observation send only the most urgent band. Previously opened bands stay open until renewal.
            $band=$days<=3?3:($days<=14?14:($days<=30?30:0));
            foreach([30,14,3] as $n){if($n===$band||$days>$n)self::incident($code,($central===$n?$c['id']:$c['id'].':'.$n),$n===$band,$expires);}
        }
    }
    public static function upgrade(): void {
        if(get_option('f3_linkedin_owner26_ready',false))return;
        Store::lock('owner26',static function(){
            foreach(Store::list('schedule',0,100) as $row){
                $id=$row['key'];Store::lock('connection:'.$row['value']['query']['connection_id'],static function()use($id){
                    $r=Store::get('schedule',$id);if(!$r)return;$v=$r['value'];
                    if(!$v['enabled']&&($v['last_code']??null)==='not_authorized'&&!isset($v['edit_revision'])){
                        $v['enabled']=true;$v['last_code']=null;$v['next_at']=time();unset($v['retry_not_before']);$v['edit_revision']=$r['revision'];Store::put('schedule',$id,$v,$r['revision']);
                    }
                });
            }
            $after=(string)get_option('f3_linkedin_owner26_job_cursor','');
            $rows=Store::scan('job',$after,100);$wake=(bool)get_option('f3_linkedin_owner26_wake',false);
            foreach($rows as $row){$after=$row['key'];if(($row['value']['status']??'')!=='paused'||($row['value']['last_code']??'')!=='not_authorized')continue;
                $wake=true;update_option('f3_linkedin_owner26_wake',1,false);$id=$row['key'];
                Store::lock('job:'.$id,static function()use($id){
                    $r=Store::get('job',$id);if(!$r)return;$v=$r['value'];
                    if(($v['status']??'')!=='paused'||($v['last_code']??'')!=='not_authorized')return;
                    $v['status']='queued';$v['next_at']=time();$v['attempts']=0;$v['last_code']=null;$v['last_error']=null;
                    Store::put('job',$id,$v,$r['revision']);
                });
            }
            if(($wake||Schedules::active())&&!Jobs::scheduleTick())return;
            if(count($rows)===100){update_option('f3_linkedin_owner26_job_cursor',$after,false);return;}
            delete_option('f3_linkedin_owner26_wake');delete_option('f3_linkedin_owner26_job_cursor');
            update_option('f3_linkedin_owner26_ready',1,true);
        });
    }
}
