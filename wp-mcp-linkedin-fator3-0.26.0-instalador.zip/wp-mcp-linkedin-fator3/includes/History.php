<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
/** Daily observations, never inferred from collection time or expanded from monthly totals. */
final class History {
    public const REPORTS=['page_statistics','share_statistics','follower_statistics','ad_analytics'];
    public static function legacyTable(): string {global $wpdb;return $wpdb->prefix.Config::KEY.'_history';}
    public static function table(): string {return self::legacyTable().'_site';}
    /** The old encrypted table is a read-only snapshot; in-progress exports can finish against it. */
    public static function upgradeSite(): void {
        if(get_option('f3_linkedin_history_site_ready',false))return;
        Store::lock('history',static function(){
            global $wpdb;$legacy=self::legacyTable();$state=get_option('f3_linkedin_history_site_progress',['kind'=>'metric','after'=>'','unmapped'=>0]);
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($legacy)))!==$legacy){
                if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao localizar histórico.');
                update_option('f3_linkedin_history_site_ready',1,true);return;
            }
            // A coverage-only receipt has no account in its payload. Rebuild its exact old hash from retained site records.
            if(empty($state['index_complete'])){
                $buckets=['schedule','job','history_export','grant','conversion_grant'];$n=$state['index_bucket']??0;$after=$state['index_after']??'';
                while(isset($buckets[$n])){
                    $items=Store::scan($buckets[$n],$after,100);
                    foreach($items as $item){
                        $after=$item['key'];$g=$item['value'];$actor=$g['principal']??null;if(!$actor)continue;
                        $q=$g['query']??[];$c=$q['connection_id']??$g['connection_id']??'';
                        if(!$c)continue;$keys=[];
                        if(isset($q['channel'],$q['account_id']))$keys[]=[$q['channel'],$q['account_id']];
                        else{$conn=Store::get('connection',$c);foreach(($conn['value']['assets']??[]) as $ch=>$ids)foreach($ids as $id)$keys[]=[$ch,$id];}
                        foreach($keys as [$ch,$id]){$orig=hash('sha256',Util::json([$actor,$c,$ch,$id]));if(!Store::get('history_site_map',$orig))Store::put('history_site_map',$orig,['partition'=>self::partition([],['connection_id'=>$c,'channel'=>$ch,'account_id'=>$id])]);}
                    }
                    if(count($items)===100){$state['index_bucket']=$n;$state['index_after']=$after;update_option('f3_linkedin_history_site_progress',$state,false);return;}
                    $n++;$after='';
                }
                $state['index_complete']=true;
            }
            foreach(['metric','coverage'] as $kind){
                if($kind!==$state['kind'])continue;
                $rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE row_kind=%s AND row_key>%s ORDER BY row_key LIMIT 100',$legacy,$kind,$state['after']),ARRAY_A);
                if($wpdb->last_error)throw new Fault('storage_unavailable','Histórico anterior indisponível.');
                ConnectionChanges::transaction(static function()use($rows,$kind,&$state,$wpdb){
                    foreach($rows as $row){
                        $v=Store::decode($row['payload']);$orig=$row['partition_key'];
                        if($kind==='metric'){
                            $part=self::partition([],$v);
                            if(!Store::get('history_site_map',$orig))Store::put('history_site_map',$orig,['partition'=>$part]);
                            $key=hash('sha256',Util::json([$part,$v['report'],$v['row']['entity'],$v['row']['pivot'],$v['data_day'],$v['row']['metric'],$v['currency']]));
                            $v['row_id']=$key;
                        }else{
                            $part=Store::get('history_site_map',$orig)['value']['partition']??null;
                            if(!$part){
                                $origin=$v['origin']??'';$job=Store::get('job',explode(':',$origin)[0]);$saved=Store::get('result',$origin);
                                $q=$saved['value']['query']??$job['value']['query']??null;
                                $actor=$saved['value']['principal']??$job['value']['principal']??null;
                                if($q&&$actor&&hash_equals($orig,hash('sha256',Util::json([$actor,$q['connection_id'],$q['channel'],$q['account_id']]))))$part=self::partition([],$q);
                            }
                            if(!$part){$state['unmapped']++;$state['after']=$row['row_key'];continue;}
                            $key=hash('sha256',Util::json([$part,'coverage',$v['origin']]));
                        }
                        $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE row_key=%s',self::table(),$key),ARRAY_A);
                        if($wpdb->last_error)throw new Fault('storage_unavailable','Índice de histórico indisponível.');
                        $first=(int)$row['first_seen'];$last=(int)$row['last_seen'];
                        if($old){
                            $first=min($first,(int)$old['first_seen']);
                            if((int)$old['last_seen']>=$last){$v=Store::decode($old['payload']);$last=(int)$old['last_seen'];}
                        }
                        if($kind==='metric')$v['first_seen']=gmdate('c',$first);
                        self::put($key,$part,$row['report'],$kind,$row['data_day'],$row['last_day'],$first,$last,$v);
                        $state['after']=$row['row_key'];
                    }
                });
                if(count($rows)<100){$state['kind']=$kind==='metric'?'coverage':'done';$state['after']='';}
                update_option('f3_linkedin_history_site_progress',$state,false);
            }
            if($state['kind']==='done')update_option('f3_linkedin_history_site_ready',1,true);
        });
    }
    public static function install(): void {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::table();
        dbDelta("CREATE TABLE $t (
row_key char(64) NOT NULL,
partition_key char(64) NOT NULL,
report varchar(40) NOT NULL,
row_kind varchar(16) NOT NULL,
data_day varchar(10) NOT NULL,
last_day varchar(10) NOT NULL,
first_seen bigint unsigned NOT NULL,
last_seen bigint unsigned NOT NULL,
payload longtext NOT NULL,
PRIMARY KEY  (row_key),
KEY selection (partition_key,row_kind,report,data_day,row_key),
KEY page_order (partition_key,row_kind,row_key),
KEY coverage_order (partition_key,row_kind,last_seen,row_key)
) ENGINE=InnoDB {$wpdb->get_charset_collate()};");
        if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t)throw new Fault('storage_unavailable','Histórico indisponível.');
        $columns=$wpdb->get_col("SHOW COLUMNS FROM $t");if(count(array_diff(['row_key','partition_key','report','row_kind','data_day','last_day','first_seen','last_seen','payload'],$columns)))throw new Fault('storage_unavailable','Estrutura do histórico incompleta.');
        update_option(Config::KEY.'_history_schema',2,true);
    }
    private static function partition(array $p,array $q): string {return hash('sha256',Util::json([SiteOperations::OWNER,$q['connection_id'],$q['channel'],$q['account_id']]));}
    private static function generation(string $p): int {$r=Store::get('history_generation',$p);return $r['value']['generation']??0;}
    private static function bump(string $p): void {$r=Store::get('history_generation',$p);Store::put('history_generation',$p,['generation'=>($r['value']['generation']??0)+1],$r['revision']??0);}
    private static function dayObject($v): ?string {
        if(!is_array($v)||!isset($v['year'],$v['month'],$v['day'])||!checkdate((int)$v['month'],(int)$v['day'],(int)$v['year']))return null;
        return sprintf('%04d-%02d-%02d',$v['year'],$v['month'],$v['day']);
    }
    public static function normalize(array $row,array $data): array {
        $q=$data['selection'];$report=$data['report'];$pivot=null;$identity=[];$metrics=[];
        if($report==='ad_analytics'){
            if(($q['granularity']??'DAILY')!=='DAILY')return ['reason'=>'not_daily'];
            $day=self::dayObject($row['dateRange']['start']??null);$end=self::dayObject($row['dateRange']['end']??null);
            if(!$day||$day!==$end)return ['reason'=>'not_daily'];
            $pivot=$q['pivot']??'ACCOUNT';$identity=$row['pivotValues']??[];
            if(!is_array($identity)||count($identity)!==1||!is_string($identity[0])||!preg_match('/^urn:(?:li:[A-Za-z]+|lla:llaPartnerConversion):[0-9]+$/D',$identity[0]))return ['reason'=>'invalid_identity'];
            $types=['ACCOUNT'=>'sponsoredAccount','CAMPAIGN'=>'sponsoredCampaign','CREATIVE'=>'sponsoredCreative','CAMPAIGN_GROUP'=>'sponsoredCampaignGroup'];
            if($pivot==='CONVERSION'&&!preg_match('/^urn:(?:lla:llaPartnerConversion|li:conversion):[0-9]+$/D',$identity[0]))return ['reason'=>'invalid_identity'];
            if(isset($types[$pivot])&&!str_starts_with($identity[0],'urn:li:'.$types[$pivot].':'))return ['reason'=>'invalid_identity'];
            if($pivot==='ACCOUNT'&&$identity[0]!=='urn:li:sponsoredAccount:'.$data['account_id'])return ['reason'=>'invalid_identity'];
            foreach($row as $k=>$v)if(!in_array($k,['dateRange','pivotValues'],true)&&(is_int($v)||is_float($v)||is_string($v)&&is_numeric($v)))$metrics[$k]=$v;
        }else{
            $start=$row['timeRange']['start']??null;$end=$row['timeRange']['end']??null;
            if(!is_numeric($start)||!is_numeric($end)||((int)$start)%86400000!==0||((int)$end-(int)$start)!==86400000)return ['reason'=>'not_daily'];
            $day=gmdate('Y-m-d',(int)($start/1000));$entity=$row['organization']??$row['organizationalEntity']??('urn:li:organization:'.$data['account_id']);
            if($entity!=='urn:li:organization:'.$data['account_id'])return ['reason'=>'invalid_identity'];
            $identity=[$row['share']??$row['ugcPost']??$entity];
            $roots=match($report){'page_statistics'=>['totalPageStatistics','mobilePageStatistics','desktopPageStatistics'],'share_statistics'=>['totalShareStatistics'],default=>['followerGains']};
            foreach($roots as $root)if(isset($row[$root]))self::flatten($row[$root],$root,$metrics);
        }
        if($day<($q['date_from']??'')||$day>($q['date_to']??'9999-12-31'))return ['reason'=>'outside_requested_range'];
        return ['day'=>$day,'identity'=>$identity,'pivot'=>$pivot,'metrics'=>$metrics,'reason'=>$metrics?null:'no_numeric_metrics'];
    }
    private static function flatten($v,string $path,array &$out): void {
        if(is_int($v)||is_float($v)||is_string($v)&&is_numeric($v)){$out[$path]=$v;return;}
        if(is_array($v)&&!array_is_list($v))foreach($v as $k=>$child)self::flatten($child,$path.'.'.$k,$out);
    }
    public static function ingest(array $data,array $principal,array $c,string $origin): array {
        if(!in_array($data['report']??'',self::REPORTS,true))return ['stored_metrics'=>0,'skipped_rows'=>0,'unsupported_report'=>true];
        foreach(['connection_id','channel','account_id','report'] as $field)if(!isset($data[$field],$data['selection'][$field])||$data[$field]!==$data['selection'][$field])throw new Fault('storage_corrupt','A identidade da página diverge da seleção original.');
        if($data['connection_id']!==$c['id']||($data['channel']==='ads')!==($data['report']==='ad_analytics'))throw new Fault('storage_corrupt','Página de outro contexto.');
        Access::worker($principal,$c,$data['channel'],$data['account_id'],false);
        return Store::lock('history',static function()use($data,$principal,$c,$origin){return ConnectionChanges::transaction(static function()use($data,$principal,$c,$origin){
            global $wpdb;$p=self::partition($principal,$data);$changed=false;$count=0;$skipped=0;$reasons=[];$days=[];
            $observed=strtotime($data['fetched_at'])?:time();$q=$data['selection'];unset($q['cursor']);
            $catalog=array_column(Adapter::fields($data['report']),null,'name');
            foreach($data['rows'] as $row){$n=is_array($row)?self::normalize($row,$data):['reason'=>'invalid_row'];
                if($n['reason']){$skipped++;$reasons[$n['reason']]=($reasons[$n['reason']]??0)+1;continue;}$days[$n['day']]=true;
                foreach($n['metrics'] as $metric=>$value){
                    $key=hash('sha256',Util::json([$p,$data['report'],$n['identity'],$n['pivot'],$n['day'],$metric,$data['currency']]));
                    $old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE row_key=%s',self::table(),$key),ARRAY_A);if($wpdb->last_error)throw new Fault('storage_unavailable','Histórico não pôde ser lido.');
                    $previous=$old?Store::decode($old['payload']):null;
                    if($previous&&(($previous['origin']??'')===$origin||$observed<(int)$old['last_seen']))continue;
                    $first=$old?(int)$old['first_seen']:$observed;$field=$catalog[$metric]??['source_field'=>$metric,'unit'=>'provider_defined','aggregation'=>'preserve_source','formula'=>null];
                    $v=['row_id'=>$key,'connection_id'=>$c['id'],'channel'=>$data['channel'],'account_id'=>$data['account_id'],'report'=>$data['report'],'data_day'=>$n['day'],'temporal'=>'day','first_seen'=>gmdate('c',$first),'last_seen'=>gmdate('c',$observed),'row'=>['metric'=>$metric,'value'=>$value,'entity'=>$n['identity'],'pivot'=>$n['pivot']],'timezone'=>'UTC','currency'=>$data['currency'],'api_version'=>$data['api_version'],'selection'=>$q,'coverage'=>$data['coverage'],'field'=>$field,'origin'=>$origin,'observations'=>($previous['observations']??0)+1];
                    self::put($key,$p,$data['report'],'metric',$n['day'],$n['day'],$first,$observed,$v);$changed=true;$count++;
                }
            }
            $window=$data['window']??['date_from'=>$q['date_from'],'date_to'=>$q['date_to']];
            $receipt=['origin'=>$origin,'report'=>$data['report'],'requested_from'=>$window['date_from'],'requested_to'=>$window['date_to'],'plan_from'=>$q['date_from'],'plan_to'=>$q['date_to'],'returned_days'=>array_keys($days),'skipped_rows'=>$skipped,'reasons'=>$reasons,'provider_coverage'=>$data['coverage'],'observed_at'=>$data['fetched_at'],'empty_is_not_zero'=>true];
            $rk=hash('sha256',Util::json([$p,'coverage',$origin]));
            $exists=$wpdb->get_var($wpdb->prepare('SELECT row_key FROM %i WHERE row_key=%s',self::table(),$rk));if($wpdb->last_error)throw new Fault('storage_unavailable','Cobertura indisponível.');
            if(!$exists){self::put($rk,$p,$data['report'],'coverage',$window['date_from'],$window['date_to'],$observed,$observed,$receipt);$changed=true;}
            if($changed)self::bump($p);Connections::revalidate($c);SiteOperations::administrator($principal);
            return ['stored_metrics'=>$count,'skipped_rows'=>$skipped,'reasons'=>$reasons];
        });});
    }
    private static function put(string $key,string $p,string $report,string $kind,string $day,string $last,int $first,int $at,array $v): void {
        global $wpdb;if($wpdb->replace(self::table(),['row_key'=>$key,'partition_key'=>$p,'report'=>$report,'row_kind'=>$kind,'data_day'=>$day,'last_day'=>$last,'first_seen'=>$first,'last_seen'=>$at,'payload'=>Crypto::seal(Util::json($v))])===false)throw new Fault('storage_unavailable','Histórico não confirmado.');
    }
    public static function migrationComplete(): bool {$m=Store::get('migration','history-0110');return (bool)($m['value']['complete']??false);}
    public static function migrate(array $i=[]): array {
        return Store::lock('history-migration',static function()use($i){
            global $wpdb;$m=Store::get('migration','history-0110');$v=$m['value']??['after'=>'','complete'=>false,'pages'=>0,'blocked_pages'=>0,'stored_metrics'=>0];
            if(!empty($i['restart']))$v=['after'=>'','complete'=>false,'pages'=>0,'blocked_pages'=>0,'stored_metrics'=>0];if($v['complete'])return $v;
            $keys=$wpdb->get_col($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s AND record_key>%s ORDER BY record_key LIMIT 25',Store::table(),'result',$v['after']));if($wpdb->last_error)throw new Fault('storage_unavailable','Migração indisponível.');
            foreach($keys as $key){$blocked=null;
                try{$r=Store::get('result',$key);if(!$r)continue;$old=$r['value'];if(!isset($old['query']['connection_id'],$old['principal']['user_id'],$old['data']['report'],$old['data']['selection'],$old['data']['rows'])||!is_array($old['data']['rows']))throw new Fault('storage_corrupt','Página legada incompleta.');$c=Connections::get($old['query']['connection_id']);$out=self::ingest($old['data'],$old['principal'],$c,$key);$v['stored_metrics']+=$out['stored_metrics'];if($out['skipped_rows']>0)$blocked='daily_identity_unavailable';}
                catch(Fault $e){if(!in_array($e->reason,['not_authorized','asset_access_denied','connection_paused','not_configured','cipher_unreadable','storage_corrupt','invalid_input'],true))throw $e;$blocked=$e->reason;}
                $hold=Store::get('history_hold',$key);
                if($blocked){Store::put('history_hold',$key,['reason'=>$blocked,'at'=>time()],$hold['revision']??0);$v['blocked_pages']++;}
                elseif($hold)Store::remove('history_hold',$key,$hold['revision']);
                $v['after']=$key;$v['pages']++;
            }
            $v['complete']=count($keys)<25;Store::put('migration','history-0110',$v,$m['revision']??0);return $v;
        });
    }
    public static function status(): array {
        Access::admin();global $wpdb;$m=Store::get('migration','history-0110');$count=(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE row_kind=%s',self::table(),'metric'));if($wpdb->last_error)throw new Fault('storage_unavailable','Histórico indisponível.');
        return ['contract'=>'linkedin-history/1.0.0','schema'=>2,'site_projection_ready'=>(bool)get_option('f3_linkedin_history_site_ready'),'site_projection'=>get_option('f3_linkedin_history_site_progress',null),'rows'=>$count,'migration'=>$m['value']??['complete'=>false],'retention'=>['mode'=>'unlimited'],'independent_from_job_retention'=>true,'supported_reports'=>self::REPORTS,'provider_horizon_guaranteed'=>false];
    }
    public static function query(array $i,?array $legacyExportActor=null): array {
        Schemas::validate('history-query',$i);$principal=Access::principal();$c=Connections::get($i['connection_id']);Access::worker($principal,$c,$i['channel'],$i['account_id'],false);$selector=$legacyExportActor??SiteOperations::OWNER;
        if(!$legacyExportActor&&!get_option('f3_linkedin_history_site_ready'))throw new Fault('migration_pending','Acervo em migração automática. Aguarde a próxima passagem.');
        $table=$legacyExportActor?self::legacyTable():self::table();
        $p=hash('sha256',Util::json([$selector,$i['connection_id'],$i['channel'],$i['account_id']]));
        return Store::lock('history',static function()use($i,$principal,$c,$p,$selector,$table){
            global $wpdb;$q=$i;unset($q['cursor']);$binding=hash('sha256',Util::json([$q,$selector,$c['authorization_revision']]));$g=self::generation($p);$after='';
            if(!empty($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding||($cur['generation']??-1)!==$g)throw new Fault('history_changed','O histórico ou a autorização mudou. Reinicie a consulta.');$after=$cur['after'];}
            $where='partition_key=%s';$args=[$p];if(isset($i['report'])){$where.=' AND report=%s';$args[]=$i['report'];}
            if(isset($i['date_from'])){$where.=' AND last_day>=%s AND data_day<=%s';$args[]=$i['date_from'];$args[]=$i['date_to'];}
            $limit=$i['limit']??100;$rows=$wpdb->get_results($wpdb->prepare('SELECT row_key,payload FROM %i WHERE '.$where.' AND row_kind=%s AND row_key>%s ORDER BY row_key LIMIT %d',array_merge([$table],$args,['metric',$after,$limit+1])),ARRAY_A);if($wpdb->last_error)throw new Fault('storage_unavailable','Histórico indisponível.');
            $more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$last=$rows?end($rows)['row_key']:$after;$out=array_map(static fn($r)=>Store::decode($r['payload']),$rows);
            $coverage=$wpdb->get_col($wpdb->prepare('SELECT payload FROM %i WHERE '.$where.' AND row_kind=%s ORDER BY last_seen DESC,row_key LIMIT 21',array_merge([$table],$args,['coverage'])));if($wpdb->last_error)throw new Fault('storage_unavailable','Cobertura indisponível.');
            Access::checkPrincipal($principal);Connections::revalidate($c);
            $result=['contract'=>'linkedin-history/1.0.0','rows'=>$out,'next_cursor'=>$more?Util::cursor(['binding'=>$binding,'generation'=>$g,'after'=>$last,'expires'=>time()+86400]):null,'generation'=>$g,'migration_complete'=>self::migrationComplete(),'retention'=>['mode'=>'unlimited','days'=>null],'coverage'=>['stored_rows_only'=>true,'origin_all_rows_guaranteed'=>false,'empty_is_not_zero'=>true,'receipts_sampled'=>count($coverage)>20,'recent_receipts'=>array_map([Store::class,'decode'],array_slice($coverage,0,20))]];
            if(strlen(Util::json($result))>700000)throw new Fault('response_limit','Reduza o período ou limit da consulta.');return $result;
        });
    }
    public static function backfill(array $i): array {
        Schemas::validate('create-backfill',$i);$q=$i['query'];
        if(!in_array($q['report'],self::REPORTS,true))throw new Fault('unsupported','O acervo diário aceita estatísticas da Página e analytics de anúncios.');
        if(($q['channel']==='ads')!==($q['report']==='ad_analytics')||!in_array($q['channel'],['pages','ads'],true))throw new Fault('invalid_input','Relatório de outro canal.');
        if(empty($q['date_from']))throw new Fault('explicit_start_required','Informe a data inicial desejada.');
        if(isset($q['granularity'])&&$q['granularity']!=='DAILY')throw new Fault('invalid_input','A coleta retroativa exige granularidade diária.');
        $principal=Access::principal();$c=Connections::get($q['connection_id']);Access::worker($principal,$c,$q['channel'],$q['account_id']);
        $key=hash('sha256',Util::json([SiteOperations::OWNER,$i['idempotency_key']]));$request=hash('sha256',Util::json([$q,$i['max_pages']??10000]));
        $old=Store::get('job',$key);
        if($old){if(($old['value']['backfill']['request']??null)!==$request)throw new Fault('idempotency_conflict','A chave já foi usada para outra coleta.');return Jobs::public($key,$old)+['replay'=>true];}
        $q['granularity']='DAILY';$q['date_to']=$q['date_to']??gmdate('Y-m-d',time()-86400);
        if($q['date_to']>=gmdate('Y-m-d'))throw new Fault('invalid_input','A coleta retroativa termina no máximo ontem (UTC).');Util::dates($q,36600);
        $now=new \DateTimeImmutable('today',new \DateTimeZone('UTC'));$floor=null;$ceiling=$now->modify('-1 day')->format('Y-m-d');
        if(in_array($q['report'],['follower_statistics','share_statistics'],true))$floor=$now->modify('-12 months')->format('Y-m-d');
        if($q['report']==='follower_statistics')$ceiling=$now->modify('-2 days')->format('Y-m-d');
        if($q['report']==='ad_analytics')$floor=$now->modify(str_starts_with($q['pivot']??'ACCOUNT','MEMBER_')?'-2 years':'-10 years')->format('Y-m-d');
        $requested=['date_from'=>$q['date_from'],'date_to'=>$q['date_to']];
        if($floor!==null&&$q['date_from']<$floor)$q['date_from']=$floor;if($q['date_to']>$ceiling)$q['date_to']=$ceiling;
        if($q['date_from']>$q['date_to'])throw new Fault('outside_retention_window','O período está fora da janela histórica publicada pelo LinkedIn.',['earliest'=>$floor,'latest'=>$ceiling]);
        $backfill=['request'=>$request,'requested'=>$requested,'effective'=>['date_from'=>$q['date_from'],'date_to'=>$q['date_to']],'window_adjusted'=>$requested['date_from']!==$q['date_from']||$requested['date_to']!==$q['date_to'],'frozen_until'=>$q['date_to'],'daily_only'=>true,'remote_horizon_guaranteed'=>false,'note'=>'Limite de performance não garante granularidade diária: somente dias devolvidos são arquivados; lacunas e agregados permanecem explícitos.'];
        return Jobs::create(['query'=>$q,'idempotency_key'=>$i['idempotency_key'],'max_pages'=>$i['max_pages']??10000,'backfill'=>$backfill]);
    }
}
