<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/**
 * Collection worker supervision (0.8.0). Recovery runs in the worker itself, in the hourly maintenance
 * and in the bootstrap while the queue migration is pending. linkedin/status stays read-only: it reports
 * the observed state and never repairs, schedules or sends e-mail.
 */
final class Worker {
    private const AUTH_CODES=['not_authorized','grant_revoked','credential_revoked','authorization_revoked','asset_access_denied','revision_conflict','credential_revalidation_required'];
    public static function ensure(int $delay=60): bool {
        if(Schedules::active()||Queue::waiting())return Jobs::scheduleTick($delay);
        return true;
    }
    /** Runs on plugins_loaded: no SQL once the migration is confirmed complete under schema 2. */
    public static function bootstrap(): void {
        if(Queue::settled())return;
        if(Queue::pending()){Result::run(static fn()=>Queue::migrate());self::ensure();}else Queue::markSettled();
    }
    public static function maintenance(): void {
        Result::run(static function(){SiteOperations::maintenance();return [];});
        // Recovery precedes credential renewal and retention; neither failure can break the chain.
        $recovery=Result::run(static fn()=>['scheduled'=>self::ensure()]);$credentials=null;$prune=null;
        try{
            Result::run(static fn()=>Management::upgrade());Result::run(static fn()=>['discovery_scheduled'=>LeadDiscovery::ensure()]);
            $credentials=Result::run(static function(){Credentials::tick();return [];});
            Result::run(static fn()=>Queue::migrate());
            $prune=Result::run(static fn()=>['removed'=>Store::prune()]);
        }finally{Result::run(static fn()=>['scheduled'=>self::ensure()]);}
        update_option(Config::KEY.'_last_maintenance',['at'=>time(),'recovery'=>$recovery['success'],'credentials_code'=>$credentials['code']??null,'retention_code'=>$prune['code']??null],false);
    }
    /** The LinkedIn package sends no operational e-mail from the worker: problems are reported by linkedin/status and the Diagnóstico tab. */
    public static function notifySafely(): void {}
    private static function maintenanceResult(): ?array {
        $last=get_option(Config::KEY.'_last_maintenance',null);
        if(!is_array($last))return null;
        $code=$last['credentials_code']??null;
        $allowed=['ok','storage_unavailable','storage_corrupt','cipher_unreadable','internal_error','busy'];
        $last['renewal_result']=$code===null?null:(in_array($code,$allowed,true)?$code:'other_failure');
        return $last;
    }
    private static function discoveryRun(): ?array {
        $run=get_option(Config::KEY.'_lead_discovery_last',null);
        if(!is_array($run))return null;
        $result=$run['result']??[];$data=$result['data']??[];
        return ['at'=>$run['at']??null,'code'=>$result['code']??null,'attempted'=>(int)($data['processed']??0),'errors'=>count($data['errors']??[])];
    }
    public static function health(array $connections=[]): array {
        $now=time();$queue=Queue::health();$issues=[];$active=0;
        foreach($connections as $c){
            if($c['enabled']&&!$c['token_configured']){
                $issues[]=['code'=>'connection_without_token','connection_id'=>$c['connection_id'],'action'=>'Informe o token e valide o aplicativo ou pause a conexão.'];
            }
        }
        foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];$enabled=!empty($v['enabled']);if($enabled)$active++;
            $common=['schedule_id'=>$r['key'],'label'=>$v['label']??$r['key']];$code=$v['last_code']??null;
            if(!empty($v['last_job'])){
                try{$job=Store::get('job',$v['last_job']);if($job&&in_array($job['value']['last_code']??null,self::AUTH_CODES,true))$code=$job['value']['last_code'];}
                catch(Fault $e){
                    if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;
                    $issues[]=$common+['code'=>'schedule_job_unreadable','action'=>'A última coleta desta agenda está ilegível. Confira as chaves do site; o diagnóstico conserva o registro e não faz reparo.'];
                }
            }
            if(in_array($code,self::AUTH_CODES,true))$issues[]=$common+['code'=>'schedule_authorization_failed','last_code'=>$code,'action'=>'Confira a conexão e salve novamente esta agenda com a concessão atual autorizada.'];
            if(!$enabled)continue;
            if(!empty($v['retry_not_before']))$issues[]=$common+['code'=>'schedule_retry_pending','last_code'=>$v['last_code']??null,'retry_not_before'=>(int)$v['retry_not_before'],'action'=>'A agenda mantém a ocorrência original e tentará novamente. Se a falha persistir, confira o armazenamento e as travas do banco.'];
            $lag=max(0,$now-(int)$v['next_at']);if($lag>2*60*(int)$v['interval_minutes'])$issues[]=$common+['code'=>'schedule_overdue','lag_seconds'=>$lag,'action'=>'Confira o cron e a autorização da agenda.'];
        }
        $next=wp_next_scheduled(Config::KEY.'_worker')?:null;$needed=$active>0||Queue::waiting();
        if($needed&&$next===null)$issues[]=['code'=>'worker_missing','action'=>'O worker é rearmado pela manutenção horária e pela próxima passagem; confira o cron do servidor.'];
        if($queue['migration_pending'])$issues[]=['code'=>'queue_migration_pending','action'=>'Aguarde as passagens do worker; consulte a migração se não houver progresso.'];
        if($queue['unreadable_jobs']>0)$issues[]=['code'=>'queue_record_unreadable','count'=>$queue['unreadable_jobs'],'action'=>'Há coletas cifradas que a chave atual do site não abre. Confira as chaves (salts) do wp-config; esses registros não são executados nem apagados automaticamente.'];
        if(!wp_next_scheduled(Config::KEY.'_maintenance'))$issues[]=['code'=>'maintenance_missing','action'=>'A manutenção horária é recriada na próxima requisição do site; confira o cron do servidor.'];
        return ['state'=>$issues?'degraded':'ok','observed_at'=>$now,'issues'=>$issues,'active_schedules'=>$active,'worker_required'=>$needed,'queue'=>$queue,
            'cron_lead_discovery'=>['next'=>wp_next_scheduled(Config::KEY.'_lead_discovery')?:null,'last_schedule_attempt'=>get_option(Config::KEY.'_lead_discovery_schedule_attempt',null),'last_reconciled_removal'=>get_option(Config::KEY.'_lead_discovery_reconciled_removal',null),'last_run'=>self::discoveryRun()],
            'cron_worker'=>['next'=>$next,'last_reconciled_removal'=>get_option(Config::KEY.'_worker_reconciled_removal',null),'last'=>get_option(Config::KEY.'_last_worker',null),'last_schedule_attempt'=>get_option(Config::KEY.'_worker_schedule_attempt',null),'last_schedule_failure'=>get_option(Config::KEY.'_worker_schedule_failure',null)],
            'maintenance'=>['next'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null,'last'=>self::maintenanceResult()],'repair'=>'not_attempted'];
    }
}
