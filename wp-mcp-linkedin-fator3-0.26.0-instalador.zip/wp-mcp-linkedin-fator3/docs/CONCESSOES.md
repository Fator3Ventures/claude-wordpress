# Concessões a consumidores — 0.26.0

O WordPress é o dono. O autor fica na auditoria. Um administrador atual com manage_options mantém a operação quando o autor perde acesso; o consumidor, a conexão, os ativos, a regra e as revisões continuam sendo verificados.

**Como conferir:** como administrador, execute `linkedin/status` com `{}`. Leia `data.consumer_grants.items`. Cada entrada indica consumidor, finalidade, conexão, recurso, revisão, estado, motivo e a operação de regravação. Para a próxima página, envie `{"grants_offset":20,"grants_limit":20}`, substituindo 20 em grants_offset pelo next_offset recebido. O limite padrão é 20; máximo 50. Offset é por tipo de registro; a página combina os dois tipos e pode incluir até duas vezes o limite. Recomece a paginação se outra pessoa alterar as concessões durante a consulta.

**Interpretação:** ready significa que os pré-requisitos locais da concessão foram satisfeitos, sem consultar o LinkedIn. disabled identifica revogação explícita e blocked inclui o código para agir. Sem registros, a lista vem vazia. Remover a capacidade do autor não exige regravação. Sem administrador elegível ou com concessão de domínio revogada, o serviço para.
