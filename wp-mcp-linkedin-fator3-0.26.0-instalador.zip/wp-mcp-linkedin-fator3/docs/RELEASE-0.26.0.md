# Operação do WordPress — Fator3 MCP LinkedIn 0.26.0

A partir da 0.25.0, atualize diretamente. WordPress 7.1.4+, PHP 8.3+ de 64 bits. Pedido 27: agendas, coletas, cargas, exportações e métricas pertencem ao site. A renovação do conector não exige editar as agendas. A revisão pública só muda em uma edição. O serviço de leads e conversões mantém seus escopos e confirmações próprios.

Um administrador pode verificar list-schedules, job-status, history-status e history-query antes e depois da troca. O histórico antigo permanece cifrado. A projeção por site avança automaticamente em lotes de 100 e concilia métricas de partições distintas por identidade e momento de observação. Enquanto incompleta, a leitura nova informa migration_pending. Uma cobertura antiga sem métrica, página ou job identificável é mantida no original e contabilizada como unmapped; não se atribui seu conteúdo a um ativo por suposição. Exportações iniciadas podem terminar contra seu recorte anterior.

Core 1.93.0 recebe as observações por f3base_incidente_publicar_v1. Configure o e-mail técnico no Core. Uma observação entregue ao Core não comprova recebimento na caixa postal. O MCP 0.48.0 mantém os limites de transporte da sessão atual. Não são criadas assinaturas ou conversões pelo upgrade.

Jobs pausados com o código legado not_authorized retomam do checkpoint, sem apagar resultados ou retroceder o cursor. Pausas sem esse código são mantidas. A versão anterior conservava o código de falha ao salvar uma pausa: se uma pausa manual posterior ainda trouxer not_authorized, não há marca distinta no registro e ela também será retomada. Confira essas exceções em list-schedules após atualizar.
