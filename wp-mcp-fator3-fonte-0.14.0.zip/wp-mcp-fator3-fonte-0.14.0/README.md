# WP MCP Fator3 0.14.0

Entrega única da implementação, acompanhada do componente de migração protegida. **Pacote para homologação; publicação em produção permanece bloqueada pelos gates documentados.**

A URL principal é `/wp-json/mcp/wp-mcp-fator3`; `/wp-json/mcp/wp-mcp-ultimate` continua compatível. O plugin conserva a pasta e o entrypoint `wp-mcp-fator3/wp-mcp-fator3.php`.

Consulte `docs/OPERACAO.md` para o contrato efetivo, `docs/GUIA-RELATORIO-0.14.0.md` para instalação, migração, evidência e limites, e `docs/CONTRATOS-INSTALADOS.json` para os schemas exportados do WordPress. O instalador contém ajuda PHP protegida; Markdown e catálogo bruto são distribuídos apenas com os fontes/documentos externos.

`fontes/wp-mcp-fator3` é o runtime; `fontes/wp-mcp-fator3-migrator` é o componente temporário. Core 1.18.0 e Google 0.5.0 em `fontes/` são fixtures atuais de integração, sem novo instalador ou downgrade nesta entrega.

Build reproduzível: `python3 tools/build_packages.py --review`. Fontes: `python3 tools/pack_source.py`. Testes e ambiente isolado ficam em `tools/lab` e `tools/acceptance`. A suíte funcional usa MySQL 8.0.46, PHP 8.3.30 e WordPress 7.1.2. O servidor de desenvolvimento PHP não substitui o aceite Apache/clientes reais.

Documentos da 0.13.0 ficam em `docs/historico/0.13.0`. A matriz vigente contém 33 IDs: 1–15 e 17–34. O item 16 foi retirado. Não houve instalação, limpeza ou revogação na frota.
