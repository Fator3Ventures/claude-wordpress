# Estado da entrega 0.14.0

Código e instaladores para homologação. O estado autoritativo, testes e bloqueios estão em `docs/GUIA-RELATORIO-0.14.0.md` e `evidencias/release-gate.json`. A identificação 0.14.0 não equivale a publicação estável.
