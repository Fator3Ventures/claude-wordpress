<?php
/**
 * A confirmation seals an exact intent and request set, not a claim of human approval.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Confirmation {

	private static ?string $job_id = null;
	private static ?array $capture = null;
	private static ?array $active  = null;
	private static array $observed = array();
	public static function reset_observations(): void {
		self::$observed = array();
	}
	public static function capturing(): bool {
		return null !== self::$capture;
	}
	private static function canonical( $value ) {
		if ( is_array( $value ) ) {
			if ( array_values( $value ) !== $value ) {
				ksort( $value );
			}
			foreach ( $value as &$v ) {
				$v = self::canonical( $v );
			}
			unset( $v );
		}
		return $value;
	}
	private static function hash( $value ): string {
		return hash( 'sha256', wp_json_encode( self::canonical( $value ) ) );
	}
	public static function sensitive( string $name, array $input = array() ): bool {
		if ( 'google/disconnect' === $name ) {
			return ! empty( $input['revoke'] );
		}
		if ( preg_match( '/delete|remove|archive|revoke|access|permission|invite|owner|signals|(?:add|update|remove)-user/i', $name ) ) {
			return true;
		}
		$body = $input['body'] ?? $input;
		if ( isset( $body['eventDataRetention'] ) || isset( $body['userDataRetention'] ) || preg_match( '/retention/i', $name ) ) {
			return true;
		}
		foreach ( $body as $key => $value ) {
			if ( preg_match( '/^(remove|delete|archive)$/i', (string) $key ) || ( 'status' === $key && 'REMOVED' === $value ) ) {
				return true;
			}
			if ( is_array( $value ) || is_object( $value ) ) {
				$value = (array) $value;
				if ( in_array( $key, array( 'operations', 'mutateOperations', 'requests', 'resource_names', 'resources' ), true ) && count( $value ) > 1 ) {
					return true;
				}
				if ( self::sensitive( (string) $key, $value ) ) {
					return true;
				}
			}
		}
		return false;
	}
	public static function intent( string $name, array $input ) {
		unset( $input['confirmation_token'], $input['connection_id'], $input['simular'] );
		if ( array_key_exists( 'dry_run', $input ) && false === $input['dry_run'] ) {
			unset( $input['dry_run'] );
		}
		$revision = null === self::$job_id ? Settings::revision() : Settings::execution_revision();
		if ( is_wp_error( $revision ) ) {
			return $revision;
		}
		return array(
			'job_id'     => self::$job_id,
			'ability'    => $name,
			'input'      => $input,
			'site'       => home_url(),
			'connection' => Connections::id(),
			'actor'      => get_current_user_id(),
			'identity'   => null === self::$job_id ? Auth\Credentials::identity_key() : Auth\Credentials::execution_identity(),
			'revision'   => $revision,
		);
	}
	/** Called before token acquisition for a write; true means locally captured, not sent. */
	public static function before_http( string $method, string $url, ?array $body, array $opts ) {
		if ( 'write' !== ( $opts['mode'] ?? '' ) || 0 === strpos( $url, Http\GoogleClient::HOST_TOKEN . '/token' ) ) {
			return false;
		}
		if ( ! empty( $body['validateOnly'] ) || ! empty( $opts['query']['validateOnly'] ) ) {
			return false;
		}
		$request = array(
			'verb'       => strtoupper( $method ),
			'url'        => $url,
			'query'      => $opts['query'] ?? array(),
			'body'       => $body,
			'media_hash' => isset( $opts['raw_body'] ) ? hash( 'sha256', $opts['raw_body'] ) : null,
		);
		$hash    = self::hash( $request );
		if ( null !== self::$capture ) {
			self::$capture['requests'][] = $hash;
			self::$capture['preview'][]  = Audit::redact( $request );
			return true;
		}
		if ( null !== self::$active ) {
			$revision = empty( self::$active['queued'] ) ? Settings::revision() : Settings::execution_revision();
			if ( is_wp_error( $revision ) || ! hash_equals( self::$active['revision'], $revision ) || get_current_user_id() !== self::$active['actor'] ) {
				return new \WP_Error( 'f3_google_confirmation_changed', 'Contexto alterado antes do despacho.', array( 'operation_outcome' => 'not_applied' ) );
			}
			$index = self::$active['cursor'];
			if ( ( self::$active['requests'][ $index ] ?? null ) !== $hash ) {
				return new \WP_Error( 'f3_google_confirmation_request_changed', 'Pedido diverge do conjunto preparado.', array( 'operation_outcome' => 'not_applied' ) );
			}
			$attempt = array(
				'connection_id'   => Connections::id(),
				'task'            => self::$active['id'],
				'status'          => 'intent_recorded',
				'request_hash'    => $hash,
				'confirmation_id' => self::$active['id'],
				'index'           => $index,
				'created_at'      => time(),
			);
			if ( ! Records::insert( 'attempt', self::$active['id'] . '_' . $index, $attempt ) ) {
				return new \WP_Error( 'f3_google_attempt_persistence', 'Início da tentativa não persistido; envio recusado.', array( 'operation_outcome' => 'not_applied' ) );
			}
			++self::$active['cursor'];
			return false;
		}
		if ( 'DELETE' === strtoupper( $method ) || self::requires( $url, $body ?? array(), $opts ) ) {
			return new \WP_Error(
				'f3_google_confirmation_required',
				'Prepare a operação e envie confirmation_token de uso único.',
				array(
					'operation_outcome' => 'not_applied',
					'retryable'         => false,
				)
			);
		}
		return false;
	}
	public static function read_observed( string $method, string $url, array $data, array $opts ): void {
		if ( 'write' !== ( $opts['mode'] ?? '' ) && str_contains( $url, 'dataRetentionSettings' ) ) {
			self::$observed[ Connections::id() . '|' . explode( '?', $url )[0] ] = $data;
		}
		if ( null !== self::$capture && 'write' !== ( $opts['mode'] ?? '' ) && 0 !== strpos( $url, Http\GoogleClient::HOST_TOKEN ) ) {
			unset( $data['propertyQuota'] );
			foreach ( array_keys( $data['reports'] ?? array() ) as $index ) {
				unset( $data['reports'][ $index ]['propertyQuota'] );
			}
			self::$capture['reads'][] = self::hash( array( $method, $url, $data ) );
		}
	}
	public static function read_failed( string $method, string $url, \WP_Error $error, array $opts ): void {
		if ( null === self::$capture || 'write' === ( $opts['mode'] ?? 'read' ) || str_starts_with( $url, Http\GoogleClient::HOST_TOKEN ) ) {
			return;
		}
		$status                   = (int) ( $error->get_error_data()['status'] ?? 0 );
		self::$capture['reads'][] = self::hash( array( $method, $url, 'error', $error->get_error_code(), $status ) );
		if ( 404 !== $status ) {
			self::$capture['incomplete'] = true;
		}
	}
	public static function authorized(): bool {
		return null !== self::$capture || null !== self::$active;
	}
	public static function require_confirmation(): ?\WP_Error {
		return self::authorized() ? null : new \WP_Error(
			'f3_google_confirmation_required',
			'Prepare a intenção completa e envie confirmation_token.',
			array(
				'operation_outcome' => 'not_applied',
				'retryable'         => false,
			)
		);
	}
	/**
	 * Bind a creation-dependent continuation to an approved semantic template.
	 * Only trusted PHP composers call this: no request parameter enables it.
	 * Its concrete request set is sealed durably after resolving the newly created
	 * resource, and before sending any continuation write.
	 */
	public static function deferred( string $template, array $intent, callable $callback ): array {
		$marker = self::hash(
			array(
				'deferred_template' => $template,
				'intent'            => $intent,
			)
		);
		if ( ! self::authorized() ) {
			return Response::fail( self::require_confirmation() );
		}
		$outer         = self::$capture;
		self::$capture = null;
		try {
			$compiled = self::collect( $callback );
		} finally {
			self::$capture = $outer;
		}
		if ( is_wp_error( $compiled ) ) {
			return Response::fail( $compiled, array( 'operation_outcome' => 'not_applied' ) );
		}
		if ( null !== self::$capture ) {
			self::$capture['requests'][] = $marker;
			self::$capture['preview'][]  = array(
				'template'                => $template,
				'intent'                  => Audit::redact( $intent ),
				'resolved_after_creation' => true,
				'effects'                 => $compiled['preview'],
			);
			return Response::ok(
				array(
					'prepared'          => true,
					'operation_outcome' => 'not_applied',
				)
			);
		}
		$index = self::$active['cursor'];
		if ( ( self::$active['requests'][ $index ] ?? null ) !== $marker ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_request_changed', 'Continuação diverge do modelo aprovado.' ), array( 'operation_outcome' => 'not_applied' ) );
		}
		$id = self::$active['id'] . '_' . $index;
		if ( ! Records::insert(
			'continuation',
			$id,
			array(
				'connection_id'   => Connections::id(),
				'task'            => self::$active['id'],
				'confirmation_id' => self::$active['id'],
				'template'        => $template,
				'intent_hash'     => $marker,
				'requests'        => $compiled['requests'],
				'reads_hash'      => self::hash( $compiled['reads'] ),
				'created_at'      => time(),
			)
		) ) {
			return Response::fail( new \WP_Error( 'f3_google_attempt_persistence', 'Continuação não persistida; envio recusado.' ), array( 'operation_outcome' => 'not_applied' ) );
		}
		array_splice( self::$active['requests'], $index, 1, $compiled['requests'] );
		$result = $callback();
		return is_wp_error( $result ) ? Response::fail( $result ) : $result;
	}
	private static function requires( string $url, array $body, array $opts ): bool {
		if ( str_contains( $url, 'dataRetentionSettings' ) ) {
			$before = self::$observed[ Connections::id() . '|' . explode( '?', $url )[0] ] ?? null;
			unset( self::$observed[ Connections::id() . '|' . explode( '?', $url )[0] ] );
			if ( null === $before ) {
				$read_opts         = $opts;
				$read_opts['mode'] = 'read';
				unset( $read_opts['query'] );
				$read_opts['operation_id'] = 'analyticsadmin.properties.getDataRetentionSettings';
				$before                    = Http\GoogleClient::get( $url, array(), $read_opts );
			}
			return ! is_array( $before ) || Analytics\Profile::reduces( $before, $body );
		}
		return self::sensitive( $url, $body );
	}
	public static function dispatch_started( array $opts ): ?\WP_Error {
		if ( null === self::$active || 'write' !== ( $opts['mode'] ?? '' ) ) {
			return null;
		}
		$id      = self::$active['id'] . '_' . ( self::$active['cursor'] - 1 );
		$attempt = Records::get( 'attempt', $id );
		if ( null === $attempt ) {
			return new \WP_Error( 'f3_google_attempt_persistence', 'Tentativa não registrada.', array( 'operation_outcome' => 'not_applied' ) );
		}
		$attempt['status']        = 'dispatching';
		$attempt['dispatched_at'] = time();
		$saved                    = Records::put( 'attempt', $id, $attempt );
		return $saved['success'] ? null : new \WP_Error( 'f3_google_attempt_persistence', 'Despacho não registrado; envio recusado.', array( 'operation_outcome' => 'not_applied' ) );
	}
	public static function position(): ?array {
		return null === self::$active ? null : array( self::$active['id'], self::$active['cursor'] );
	}
	public static function http_finished( array $opts, $result, ?array $position ): void {
		if ( self::capturing() || null === self::$active || 'write' !== ( $opts['mode'] ?? '' ) || null === $position || $position[0] !== self::$active['id'] || $position[1] + 1 !== self::$active['cursor'] ) {
			return;
		}
		$id      = self::$active['id'] . '_' . ( self::$active['cursor'] - 1 );
		$attempt = Records::get( 'attempt', $id );
		if ( null === $attempt ) {
			return;
		}
		$outcome                      = is_wp_error( $result ) ? ( $result->get_error_data()['operation_outcome'] ?? ( 'dispatching' === $attempt['status'] ? 'unknown' : 'not_applied' ) ) : 'applied';
		$attempt['resources']         = is_array( $result ) ? array_intersect_key( $result, array_flip( array( 'id', 'name', 'spreadsheetId', 'parents', 'driveId' ) ) ) : array();
		$attempt['status']            = 'finished';
		$attempt['operation_outcome'] = $outcome;
		$attempt['finished_at']       = time();
		$attempt['error_code']        = is_wp_error( $result ) ? $result->get_error_code() : null;
		$saved                        = Records::put( 'attempt', $id, $attempt );
		if ( ! $saved['success'] ) {
			self::$active['journal_failure'] = true;
		}
	}
	/** Validate all independent effects before sending the first mutation. */
	public static function validate_calls( array $steps ): ?\WP_Error {
		$prior         = self::$capture;
		self::$capture = array(
			'requests' => array(),
			'reads'    => array(),
			'preview'  => array(),
		);
		try {
			foreach ( $steps as $step ) {
				$r = Generic\ExecuteAction::call( $step['api'], $step['method'], $step['path_params'] ?? array(), $step['query'] ?? array(), $step['body'] ?? null );
				if ( is_wp_error( $r ) ) {
					return $r;
				}
			}
			return null;
		} finally {
			self::$capture = $prior;
		}
	}
	private static function collect( callable $callback ) {
		if ( null !== self::$capture ) {
			return new \WP_Error( 'f3_google_prepare_nested', 'Preparação aninhada não permitida.' );
		}
		self::$capture = array(
			'requests' => array(),
			'reads'    => array(),
			'preview'  => array(),
		);
		try {
			$result  = $callback();
			$capture = self::$capture;
			if ( is_wp_error( $result ) || ! is_array( $result ) || empty( $result['success'] ) || ! empty( $capture['incomplete'] ) ) {
				return new \WP_Error( 'f3_google_prepare_incomplete', 'A prévia não pôde preparar todas as etapas. Confira os parâmetros e o acesso aos recursos.' );
			}
			if ( ! $capture['requests'] ) {
				return new \WP_Error( 'f3_google_prepare_empty', 'A prévia não contém uma mutação remota.' );
			}
			return $capture;
		} finally {
			self::$capture = null;
		}
	}
	public static function prepare( array $input ): array {
		$name   = (string) ( $input['ability'] ?? '' );
		$params = $input['parameters'] ?? array();
		if ( ! is_array( $params ) || ! preg_match( '~^(ga|ads|gsc|sheets|siteverification)/|^google/(execute-action|disconnect|export-to-sheet|audit-to-sheet)$~', $name ) || preg_match( '~/(save|list|profile-schema|inspect-urls|preparar-site|migracao-conferir)~', $name ) ) {
			return Response::fail( new \WP_Error( 'f3_google_prepare_ability', 'Escolha uma habilidade de mutação remota.' ) );
		}
		$ability = wp_get_ability( $name );
		if ( ! $ability ) {
			return Response::fail( new \WP_Error( 'f3_google_prepare_ability', 'Habilidade inexistente.' ) );
		}
		$params = Operation::normalize( $params );
		if ( is_wp_error( $params ) ) {
			return Response::fail( $params );
		}
		if ( Operation::wildcard( $params ) ) {
			return Response::fail( new \WP_Error( 'f3_google_write_wildcard', 'Escritas exigem alvos explícitos.' ) );
		}
		// Deliberately run the real preparation path with a transport capture. This is not Google validateOnly.
		if ( isset( $ability->get_input_schema()['properties']['dry_run'] ) ) {
			$params['dry_run'] = false;
		}
		unset( $params['confirmation_token'] );
		$params['connection_id'] = Connections::id();
		$intent                  = self::intent( $name, $params );
		if ( is_wp_error( $intent ) ) {
			return Response::fail( $intent );
		}
		$capture = self::collect( static fn () => $ability->execute( $params ) );
		if ( is_wp_error( $capture ) ) {
			return Response::fail( $capture );
		}
		$token  = bin2hex( random_bytes( 32 ) );
		$id     = hash( 'sha256', $token );
		$record = array(
			'connection_id' => Connections::id(),
			'job_id'        => self::$job_id,
			'intent_hash'   => self::hash( $intent ),
			'capture_hash'  => self::hash( array( $capture['requests'], $capture['reads'] ) ),
			'requests'      => $capture['requests'],
			'status'        => 'prepared',
			'expires_at'    => time() + 600,
			'created_at'    => time(),
		);
		if ( ! Records::insert( 'confirmation', $id, $record ) ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_persistence', 'Preparação não persistida.' ) );
		}
		return Response::ok(
			array(
				'confirmation_token'         => $token,
				'expires_at'                 => $record['expires_at'],
				'ability'                    => $name,
				'parameters'                 => Audit::redact( $params ),
				'effects'                    => $capture['preview'],
				'preparation'                => 'local_transport_capture',
				'remote_writes_performed'    => false,
				'human_approval_attested'    => false,
				'execution_contract_version' => '2.0.0',
			)
		);
	}
	public static function execute( string $name, array $input, callable $callback ): array {
		if ( null !== self::$capture || null !== self::$active ) {
			return $callback();
		}
		$token = (string) ( $input['confirmation_token'] ?? '' );
		if ( ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_required', 'Token de confirmação inválido ou ausente.' ), array( 'operation_outcome' => 'not_applied' ) );
		}
		return self::execute_record( hash( 'sha256', $token ), $name, $input, $callback );
	}
	private static function execute_record( string $id, string $name, array $input, callable $callback ): array {
		$lock = Lock::acquire( 'confirmation:' . $id, 180 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_busy', 'Confirmação em uso.' ), array( 'operation_outcome' => 'not_applied' ) );
		}
		try {
			$record = Records::get( 'confirmation', $id );
			$intent = self::intent( $name, $input );
			if ( null === $record || is_wp_error( $intent ) || self::hash( $intent ) !== $record['intent_hash'] || ( $record['job_id'] ?? null ) !== self::$job_id || ( 'delegated' !== ( $record['status'] ?? '' ) && $record['expires_at'] < time() ) ) {
				return Response::fail( new \WP_Error( 'f3_google_confirmation_changed', 'Confirmação ausente, expirada ou vinculada a outro contexto.' ), array( 'operation_outcome' => 'not_applied' ) );
			}
			if ( ( null === self::$job_id ? 'prepared' : 'delegated' ) !== $record['status'] ) {
				return Response::fail(
					new \WP_Error( 'f3_google_confirmation_used', 'Confirmação consumida. Consulte o resultado registrado; não repita a escrita.' ),
					array(
						'operation_outcome' => $record['outcome'] ?? 'unknown',
						'previous_result'   => $record['result'] ?? null,
					)
				);
			}
			$capture = self::collect( $callback );
			if ( is_wp_error( $capture ) || self::hash( array( $capture['requests'], $capture['reads'] ) ) !== $record['capture_hash'] ) {
				return Response::fail( new \WP_Error( 'f3_google_confirmation_changed', 'Estado remoto ou pedidos mudaram desde a preparação.' ), array( 'operation_outcome' => 'not_applied' ) );
			}
			$record['status']     = 'consumed';
			$record['started_at'] = time();
			$saved                = Records::put( 'confirmation', $id, $record );
			if ( ! $saved['success'] ) {
				return $saved;
			}
			self::$active = array(
				'id'       => $id,
				'requests' => $record['requests'],
				'cursor'   => 0,
				'revision' => $intent['revision'],
				'actor'    => $intent['actor'],
				'queued'   => null !== self::$job_id,
			);
			try {
				$raw    = $callback();
				$result = Operation::result( is_wp_error( $raw ) ? Response::fail( $raw ) : $raw, 'write' );
				if ( ! empty( $result['success'] ) && count( self::$active['requests'] ) !== self::$active['cursor'] ) {
					$result = Response::fail( new \WP_Error( 'f3_google_confirmation_incomplete', 'Nem todas as etapas preparadas foram executadas.' ), array( 'operation_outcome' => 'partial' ) );
				}
				if ( ! empty( self::$active['journal_failure'] ) ) {
					$result = Response::fail( new \WP_Error( 'f3_google_attempt_persistence', 'Histórico da tentativa não confirmado.' ), array( 'operation_outcome' => 'unknown' ) );
				}
			} catch ( \Throwable $e ) {
				$result = Response::fail( new \WP_Error( 'f3_google_confirmation_interrupted', 'Execução interrompida; reconcilie os alvos.' ), array( 'operation_outcome' => 'unknown' ) );
			} finally {
				self::$active = null;
			}
			$record['outcome'] = $result['operation_outcome'];
			$record['result']  = Audit::redact( $result );
			$record['status']  = 'finished';
			$saved             = Records::put( 'confirmation', $id, $record );
			return $saved['success'] ? $result : Response::fail( new \WP_Error( 'f3_google_confirmation_result_persistence', 'Resultado remoto não pôde ser confirmado no histórico.' ), array( 'operation_outcome' => 'unknown' ) );
		} finally {
			Lock::release( $lock );
		}
	}
	/** A job receives a bound intent, never the reusable bearer token. */
	public static function for_job( string $id, callable $callback ): array {
		$prior        = self::$job_id;
		self::$job_id = $id;
		try {
			return $callback();
		} finally {
			self::$job_id = $prior;
		}
	}
	public static function delegate_job( string $token, string $name, array $params, string $job_id ): array {
		if ( ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_required', 'Token de preparação inválido.' ) );
		}
		$id   = hash( 'sha256', $token );
		$lock = Lock::acquire( 'confirmation:' . $id, 60 );
		if ( null === $lock ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_busy', 'Confirmação em uso.' ) );
		}
		try {
			return self::for_job(
				$job_id,
				static function () use ( $id, $name, $params, $job_id ): array {
					$record = Records::get( 'confirmation', $id );
					$intent = self::intent( $name, $params );
					if ( null === $record || is_wp_error( $intent ) || ( $record['job_id'] ?? null ) !== $job_id || ! hash_equals( $record['intent_hash'], self::hash( $intent ) ) || ( ! in_array( $record['status'], array( 'prepared', 'delegated' ), true ) ) || ( 'prepared' === $record['status'] && $record['expires_at'] < time() ) ) {
						return Response::fail( new \WP_Error( 'f3_google_confirmation_changed', 'Prepare este job novamente com o contexto atual.' ) );
					}
					$record['status']       = 'delegated';
					$record['delegated_at'] = $record['delegated_at'] ?? time();
					$saved                  = Records::put( 'confirmation', $id, $record );
					return $saved + array( 'confirmation_record' => $id );
				}
			);
		} finally {
			Lock::release( $lock );
		}
	}
	public static function execute_job( string $job_id, string $record_id, string $name, array $params, callable $callback ): array {
		if ( ! preg_match( '/^[a-f0-9]{64}$/D', $record_id ) ) {
			return Response::fail( new \WP_Error( 'f3_google_confirmation_required', 'Job exige preparação e aprovação vinculadas.' ), array( 'operation_outcome' => 'not_applied' ) );
		}
		return self::for_job( $job_id, static fn () => self::execute_record( $record_id, $name, $params, $callback ) );
	}
	public static function register(): void {
		Ability::register(
			'google/prepare-operation',
			'any',
			array(
				'label'        => 'Google: preparar operação sensível',
				'description'  => 'Calcula pedidos sem enviá-los e emite token vinculado de uso único. A preparação não atesta aprovação humana.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'ability', 'parameters' ),
					'properties' => array(
						'ability'    => array( 'type' => 'string' ),
						'parameters' => array( 'type' => 'object' ),
					),
				),
				'callback'     => array( self::class, 'prepare' ),
			)
		);
	}
}
