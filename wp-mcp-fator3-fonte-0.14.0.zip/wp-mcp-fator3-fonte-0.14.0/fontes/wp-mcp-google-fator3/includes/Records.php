<?php
/**
 * Independent, non-autoloaded records; unique inserts do not overwrite other writers.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Records {

	public const PREFIX = 'f3_mcp_google_record_';
	public static function key( string $kind, string $id ): string {
		if ( ! preg_match( '/^[a-z]+$/D', $kind ) || ! preg_match( '/^[a-zA-Z0-9_-]{1,100}$/D', $id ) ) {
			throw new \InvalidArgumentException( 'Identificador de registro inválido.' );
		}
		return self::PREFIX . $kind . '_' . $id;
	}
	public static function id(): string {
		return sprintf( '%020d', (int) floor( microtime( true ) * 1000000 ) ) . '_' . bin2hex( random_bytes( 8 ) );
	}
	public static function get( string $kind, string $id ): ?array {
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::active() ) {
			$value = Storage\Repository::get( $kind, $id );
			if ( is_wp_error( $value ) ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception carries a structured internal error; renderers escape it at the output boundary.
				throw new \RuntimeException( $value->get_error_code() );
			}
			return $value;
		}
		$value = get_option( self::key( $kind, $id ), null );
		return is_array( $value ) ? $value : null;
	}
	public static function insert( string $kind, string $id, array $record ): bool {
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::active() ) {
			return Storage\Repository::insert( $kind, $id, $record );
		}
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::paused() ) {
			return false;
		}
		return Options::insert_exclusive( self::key( $kind, $id ), $record );
	}
	public static function put( string $kind, string $id, array $record ): array {
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::active() ) {
			return Storage\Repository::put( $kind, $id, $record );
		}
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::paused() ) {
			return Response::fail( new \WP_Error( 'f3_google_storage_paused', 'Migração em andamento; armazenamento de origem preservado.' ) );
		}
		return Options::write_verified( self::key( $kind, $id ), $record );
	}
	public static function remove( string $kind, string $id ): array {
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::active() ) {
			return Storage\Repository::remove( $kind, $id );
		}
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::paused() ) {
			return Response::fail( new \WP_Error( 'f3_google_storage_paused', 'Migração em andamento.' ) );
		}
		return Options::delete( self::key( $kind, $id ) );
	}
	/** One grouped existence query for limited cron repair; no serialized payload. */
	public static function has_work(): bool {
		global $wpdb;
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::active() ) {
			$work = Storage\Repository::has_work();
			return is_wp_error( $work ) || $work;
		}
		if ( ! isset( $wpdb ) || ! is_callable( array( $wpdb, 'get_col' ) ) ) {
			return false;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s LIMIT 1", $wpdb->esc_like( self::PREFIX . 'job_' ) . '%', $wpdb->esc_like( self::PREFIX . 'schedule_' ) . '%' ) );
		return ! empty( $names );
	}
	/**
	 * Select record identifiers without loading serialized payloads.
	 *
	 * @throws \RuntimeException When identifiers cannot be read reliably.
	 */
	public static function ids( string $kind, int $limit = 1000, bool $newest = true, int $offset = 0 ): array {
		global $wpdb;
		if ( class_exists( Storage\Migration::class ) && Storage\Migration::active() ) {
			$rows = Storage\Repository::select( $kind, array(), $limit, $offset, $newest );
			if ( is_wp_error( $rows ) ) {
				// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Exception carries a structured internal error; renderers escape it at the output boundary.
				throw new \RuntimeException( $rows->get_error_code() );
			}
			return array_column( $rows, 'record_id' );
		}
		self::key( $kind, 'check' );
		if ( ! isset( $wpdb ) || ! is_callable( array( $wpdb, 'get_col' ) ) ) {
			return array();
		}
		$prefix    = self::PREFIX . $kind . '_';
		$direction = $newest ? 'DESC' : 'ASC';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name $direction LIMIT %d OFFSET %d", $wpdb->esc_like( $prefix ) . '%', max( 1, min( 10000, $limit ) ), max( 0, $offset ) ) );
		return array_map( static fn ( $name ) => substr( $name, strlen( $prefix ) ), (array) $names );
	}
	public static function list( string $kind, int $limit = 1000, bool $newest = true ): array {
		$out = array();
		foreach ( self::ids( $kind, $limit, $newest ) as $id ) {
			$value = self::get( $kind, $id );
			if ( null !== $value ) {
				$out[ $id ] = $value;
			}
		}
		return $out;
	}
}
