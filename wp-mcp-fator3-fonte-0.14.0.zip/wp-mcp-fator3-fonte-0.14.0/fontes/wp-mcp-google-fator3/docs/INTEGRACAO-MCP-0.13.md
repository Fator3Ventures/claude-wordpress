# Integração MCP — wp-mcp-google-fator3 0.4.1

Revisão de compatibilidade em validação para a entrega única MCP 0.13.0. Não é declaração de homologação ou publicação.

O plugin declara provedor, versão e `policy_contract:1`. Quando o MCP 0.13.0 está presente, seu perfil por conexão limita a execução sem substituir as permissões nativas. Habilidades de terceiros que não aderem continuam com suas permissões próprias.

A nova anotação é ignorada pela base MCP 0.12.1, permitindo a ordem Core → Google → MCP. Nenhuma credencial é rotacionada durante a atualização; a migração de conectores é operacional. O `Update URI` identifica este pacote no host fator3.com.br; o feed precisa ser configurado e publicado separadamente.

Os manuais e esquemas da base permanecem válidos para os contratos funcionais não alterados. O relatório de testes da base é histórico; o aceite coordenado desta revisão consta no fonte MCP em `docs/VALIDACAO.md`.
