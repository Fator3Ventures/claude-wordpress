<?php
/** Streamed artifacts have a PHP exit envelope, signed metadata and no public download URL. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;
final class PrivateArtifact {
    public static function path(string $id): string {if(!preg_match('/^[a-f0-9]{32}$/D',$id))throw new \InvalidArgumentException('artifact_invalid');return StateStore::directory('artifacts').'/'.$id.'.php';}
    public static function writer(string $format,bool $gzip): array {
        $id=bin2hex(random_bytes(16));$path=self::path($id);$f=fopen($path,'xb');if(!$f)throw new \RuntimeException('artifact_create_failed');chmod($path,0600);self::write_all($f,StateStore::HEADER);
        return ['id'=>$id,'stream'=>$f,'hash'=>hash_init('sha256'),'compressor'=>$gzip?deflate_init(ZLIB_ENCODING_GZIP):null,'bytes'=>0,'rows'=>0,'format'=>$format,'gzip'=>$gzip,'connection_id'=>ConnectionContext::key(),'user_id'=>get_current_user_id()];
    }
    public static function write_all($f,string $bytes): void {for($at=0,$n=strlen($bytes);$at<$n;){$written=fwrite($f,substr($bytes,$at,65536));if(!$written)throw new \RuntimeException('artifact_write_failed');$at+=$written;}}
    public static function append(array &$w,string $bytes): void {
        $free=disk_free_space(dirname(self::path($w['id'])));if($free!==false&&$free<strlen($bytes)+10485760)throw new \RuntimeException('artifact_disk_budget');
        $encoded=$w['compressor']?deflate_add($w['compressor'],$bytes,ZLIB_NO_FLUSH):$bytes;if($encoded===false)throw new \RuntimeException('compression_failed');
        self::write_all($w['stream'],$encoded);hash_update($w['hash'],$encoded);$w['bytes']+=strlen($encoded);
    }
    public static function finish(array &$w,array $extra=[]): array {
        if($w['compressor']){$last=deflate_add($w['compressor'],'',ZLIB_FINISH);if($last===false)throw new \RuntimeException('compression_failed');self::write_all($w['stream'],$last);hash_update($w['hash'],$last);$w['bytes']+=strlen($last);}
        if(!fflush($w['stream']))throw new \RuntimeException('artifact_flush_failed');if(function_exists('fsync'))fsync($w['stream']);fclose($w['stream']);
        $meta=$extra+array_intersect_key($w,array_flip(['id','bytes','rows','format','gzip','connection_id','user_id']))+['sha256'=>hash_final($w['hash']),'status'=>'complete','time'=>time(),'expires'=>$w['format']==='sql'?0:time()+7*DAY_IN_SECONDS];
        Engine::write(self::path($w['id']).'.meta.php',$meta);return $meta;
    }
    public static function meta(string $id,bool $owner=true): array {$m=Engine::read(self::path($id).'.meta.php');if(!$m||($m['status']??'')!=='complete')throw new \RuntimeException('artifact_not_complete');if(!empty($m['expires'])&&$m['expires']<=time())throw new \RuntimeException('artifact_expired');if($owner&&$m['connection_id']!==ConnectionContext::key()&&!ConnectionContext::maintenance())throw new \RuntimeException('artifact_access_denied');return $m;}
    public static function part(array $i): array {
        try{$m=self::meta($i['artifact_id']);$offset=(int)($i['offset_bytes']??0);$n=min(262144,(int)($i['byte_limit']??262144));if($offset<0||$offset>$m['bytes'])return Result::fail('artifact_offset_invalid','Offset fora do arquivo.');
            $f=fopen(self::path($m['id']),'rb');fseek($f,strlen(StateStore::HEADER)+$offset);$bytes=fread($f,$n);fclose($f);if($bytes===false)throw new \RuntimeException('artifact_read_failed');
            return Result::ok(['artifact_id'=>$m['id'],'format'=>$m['format'],'gzip'=>$m['gzip'],'content_base64'=>base64_encode($bytes),'offset_bytes'=>$offset,'bytes'=>strlen($bytes),'total_bytes'=>$m['bytes'],'row_count'=>$m['rows'],'sha256'=>$m['sha256'],'part_sha256'=>hash('sha256',$bytes),'has_more'=>$offset+strlen($bytes)<$m['bytes'],'next_offset_bytes'=>$offset+strlen($bytes)]);
        }catch(\Throwable $e){return Result::fail('artifact_unavailable','Artefato ausente, incompleto ou não autorizado.');}
    }
    public static function lines(string $id): \Generator {
        $m=self::meta($id,false);$f=fopen(self::path($id),'rb');fseek($f,strlen(StateStore::HEADER));$hash=hash_init('sha256');$buffer='';$inflate=$m['gzip']?inflate_init(ZLIB_ENCODING_GZIP):null;
        try{while(!feof($f)){$raw=fread($f,65536);if($raw===false)throw new \RuntimeException('artifact_read_failed');hash_update($hash,$raw);$bytes=$inflate?inflate_add($inflate,$raw,feof($f)?ZLIB_FINISH:ZLIB_SYNC_FLUSH):$raw;if($bytes===false)throw new \RuntimeException('artifact_corrupt');$buffer.=$bytes;while(($p=strpos($buffer,"\n"))!==false){yield substr($buffer,0,$p);$buffer=substr($buffer,$p+1);}}
            if($buffer!=='')yield $buffer;if(!hash_equals($m['sha256'],hash_final($hash)))throw new \RuntimeException('artifact_hash_conflict');
        }finally{fclose($f);}
    }
    public static function verify(string $id): bool {try{foreach(self::lines($id) as $line){}return true;}catch(\Throwable $e){return false;}}
}
