<?php
/** Local evidence and narrowly scoped HTTP-test history; never invent external access. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ConnectionStatus {
    public const TOOLS = ['wp-mcp-ultimate-discover-abilities', 'wp-mcp-ultimate-get-ability-info', 'wp-mcp-ultimate-execute-ability'];
    public static function snapshot(bool $initialize = true): array {
        $core = class_exists('WpMcpUltimate\\Server\\McpAdapter');
        $enabled = (bool)apply_filters('mcp_adapter_create_default_server', true);
        $ready = did_action('init') > 0 && !doing_action('rest_api_init');
        $routes = null; $servers = []; $errors = []; $tool_names = [];
        if ($core && $initialize && $ready) {
            try {
                $routes = rest_get_server()->get_routes();
                $servers = \WpMcpUltimate\Server\McpAdapter::instance()->get_servers();
            } catch (\Throwable $e) { $errors[] = 'mcp_registry_error'; }
        }
        $server = null;
        foreach ($servers as $candidate) if (ConnectionEndpoints::is_owned($candidate)) { $server = $candidate; break; }
        if ($server) $tool_names = array_keys($server->get_tools($server->get_schemas()->forVersion(\WpMcpUltimate\McpSchema\Schemas::V2025_11_25)));
        $entries = ConnectionEndpoints::entries($routes);
        if (!$core) $errors[] = 'mcp_core_missing';
        elseif (!$enabled) $errors[] = 'mcp_server_disabled';
        elseif (null !== $routes) {
            if (!$server) $errors[] = 'mcp_server_missing';
            foreach ($entries as $entry) if (!$entry['registered']) $errors[] = $entry['conflict'] ? 'mcp_route_conflict' : 'mcp_route_missing';
            if (array_diff(self::TOOLS, $tool_names)) $errors[] = 'mcp_tools_missing';
        }
        $loaded = defined('WP_MCP_ULTIMATE_DIR') ? wp_normalize_path(WP_MCP_ULTIMATE_DIR) : '';
        return ['core_loaded' => $core, 'integrated_core_loaded' => $loaded !== '' && str_starts_with($loaded, wp_normalize_path(F3_MCP_FILES_DIR)),
            'server_enabled' => $enabled, 'registry_checked' => null !== $routes, 'server_registered' => null === $routes ? null : (bool)$server,
            'abilities_api' => function_exists('wp_get_abilities'), 'endpoints' => $entries, 'tools' => $tool_names,
            'tools_ready' => null === $routes ? null : !array_diff(self::TOOLS, $tool_names), 'errors' => array_values(array_unique($errors)),
            'observed_connections' => current_user_can('manage_options') ? self::observations() : [], 'checked_at' => gmdate('c'), 'scope' => 'local_registration', 'external_connectivity_tested' => false];
    }
    /** Record successful authenticated protocol requests, never a client-supplied test label. */
    public static function observe(\WP_REST_Request $request, \WP_REST_Response $response): void {
        if (!defined('REST_REQUEST') || !REST_REQUEST || !ConnectionEndpoints::matches($request->get_route())) return;
        if ($response->get_status() < 200 || $response->get_status() >= 300) return;
        $context = ConnectionContext::get();
        if (!$context || !in_array($context['transport'], ['oauth', 'wordpress-application-password'], true) || !empty($context['internal_test'])) return;
        $data = json_decode(wp_json_encode($response->get_data()), true);
        if (!is_array($data) || isset($data['error']) || !isset($data['result'])) return;
        $params = $request->get_json_params();
        $version = $data['result']['protocolVersion'] ?? ($params['params']['_meta']['io.modelcontextprotocol/protocolVersion'] ?? $request->get_header('mcp-protocol-version'));
        if (!in_array($version, ['2025-03-26', '2025-06-18', '2025-11-25', '2026-07-28'], true)) $version = null;
        $id = $context['connection_id'];
        Locks::run(['connection:' . $id => LOCK_EX], static function() use ($id, $request, $version, $context): array {
            $row = Persistence::get('connections', $id);
            if (!$row || ($row['_storage']['status'] ?? '') !== 'active') return [];
            $row['last_protocol_request'] = [
                'observed_at' => time(), 'route' => $request->get_route(),
                'protocol_version' => $version, 'authentication' => $context['transport'],
                'scope' => 'authenticated_connector_request', 'network_origin_verified' => false,
            ];
            Persistence::put('connections', $id, $row);
            return [];
        });
    }
    public static function observations(): array {
        $out = [];
        foreach (Persistence::listing('connections', ['status' => 'active'], 100) as $row) {
            if (empty($row['last_protocol_request']) || !empty($row['internal_test'])) continue;
            $out[] = ['connection_id' => $row['connection_id'], 'profile' => $row['profile']] + $row['last_protocol_request'];
        }
        return $out;
    }
    public static function key(): ?array {
        $uuid = get_user_meta(get_current_user_id(), 'f3_mcp_app_password', true);
        if (!$uuid || !class_exists('WP_Application_Passwords')) return null;
        foreach (\WP_Application_Passwords::get_user_application_passwords(get_current_user_id()) as $item) if ($uuid === $item['uuid']) return $item;
        return null;
    }
    public static function fingerprint(): string {
        return hash('sha256', wp_json_encode([F3_MCP_FILES_VERSION, get_current_blog_id(), ConnectionEndpoints::routes(), array_map([ConnectionEndpoints::class, 'url'], ConnectionEndpoints::routes()),
            get_user_meta(get_current_user_id(), 'f3_mcp_app_password', true), (bool)self::key(), (bool)apply_filters('wp_mcp_ultimate_enable_oauth', true), (bool)apply_filters('mcp_adapter_create_default_server', true)]));
    }
    public static function remember(array $result): void {
        update_user_meta(get_current_user_id(), 'f3_mcp_connection_test', ['result' => $result, 'time' => time(), 'fingerprint' => self::fingerprint()]);
    }
    public static function previous(): ?array {
        $row = get_user_meta(get_current_user_id(), 'f3_mcp_connection_test', true);
        if (!is_array($row) || !isset($row['fingerprint'], $row['time']) || !hash_equals($row['fingerprint'], self::fingerprint()) || $row['time'] < time() - 900) return null;
        return $row['result'];
    }
    public static function label(string $code): string {
        return ['mcp_core_missing' => 'O núcleo MCP não foi carregado.', 'mcp_server_disabled' => 'Servidor desabilitado por filtro de configuração.',
            'mcp_server_missing' => 'O servidor não foi criado no registro MCP.', 'mcp_registry_error' => 'Não foi possível verificar o registro MCP.',
            'mcp_route_missing' => 'Uma rota MCP não foi registrada.', 'mcp_route_conflict' => 'Uma rota já está ocupada por outro callback.',
            'mcp_tools_missing' => 'O servidor não contém os três metatools esperados.'][$code] ?? $code;
    }
}
