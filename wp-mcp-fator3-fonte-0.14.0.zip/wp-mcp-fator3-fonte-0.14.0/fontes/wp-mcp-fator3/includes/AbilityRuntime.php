<?php
/** Cross-cutting contracts for this distribution's abilities. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class AbilityRuntime {
	private const PREFIXES = ['files/', 'db/', 'content/', 'comments/', 'media/', 'menus/', 'widgets/', 'users/', 'options/', 'plugins/', 'themes/', 'system/', 'operations/', 'audit/', 'backups/'];
	public static function init(): void {
		add_filter('wp_register_ability_args', [self::class, 'decorate'], 90, 2);
	}
	public static function decorate(array $args, string $name): array {
		$owned = !empty($args['meta']['fator3']['owned']);
		if (!$owned && isset($args['execute_callback'])) {
			try {
				$cb = $args['execute_callback']; $reflection = is_array($cb) ? new \ReflectionMethod($cb[0], $cb[1]) : new \ReflectionFunction($cb);
				$file = wp_normalize_path((string)$reflection->getFileName());
				$owned = str_starts_with($file, wp_normalize_path(F3_MCP_FILES_DIR));
			} catch (\Throwable $e) { $owned = false; }
		}
		if (str_starts_with($name,'wp-mcp-ultimate/')) { if($owned){require_once F3_MCP_FILES_DIR.'includes/OwnedAbility.php';$args['ability_class']=OwnedAbility::class;$args=ContractLanguage::describe($args,$name);}return $args; }
        // Identify a provider from its registered callback file without changing its callbacks/policy.
        if(!$owned&&!empty($file)&&str_starts_with($file,wp_normalize_path(WP_PLUGIN_DIR).'/')){
            if(!function_exists('get_plugins'))require_once ABSPATH.'wp-admin/includes/plugin.php';
            $relative=substr($file,strlen(wp_normalize_path(WP_PLUGIN_DIR))+1);$slug=explode('/',$relative)[0];
            foreach(get_plugins() as $entry=>$header)if(dirname($entry)===$slug||$entry===$relative){$args['meta']['fator3']['provider']=$slug;if(empty($args['meta']['fator3']['version'])&&!empty($header['Version']))$args['meta']['fator3']['version']=$header['Version'];break;}
        }
		$adherent=ExtensionContract::adheres($name,(array)($args['meta']['fator3']??[]));
        if ((!$owned&&!$adherent) || !isset($args['execute_callback'])) return $args;
        if(!empty($args['meta']['fator3']['decorated']))return $args;
		require_once F3_MCP_FILES_DIR.'includes/OwnedAbility.php';
        if(!isset($args['ability_class']))$args['ability_class']=OwnedAbility::class;
        $args=ContentContracts::schema($args,$name);
        $args=PackageService::schema($args,$name);
        $args=Release014::schema($args,$name);
		$read = !empty($args['meta']['annotations']['readonly']);
		$props = &$args['input_schema']['properties'];
		if (!is_array($props)) $props = [];
		if (!isset($args['input_schema']['type'])) $args['input_schema']['type'] = 'object';
		if (!$read) $props['idempotency_key'] = ['type' => 'string', 'minLength' => 1, 'maxLength' => 128, 'description' => 'Stable operation key. A completed call can be replayed without repeating its side effects.'];
        if (DestructiveActions::supports($name)) $props['confirm_token']=Registry::string('Token opaco da prévia, válido por 10 minutos e vinculado à credencial e pré-imagem.');
        if (in_array($name,['files/write','files/patch','files/delete','files/move','files/fetch','files/restore','plugins/upload','plugins/update'],true)) {
            $props['label']=['type'=>'string','maxLength'=>128]; $props['rotulo']=$props['label'];
        }
        if ('users/delete'===$name) $props['delete_content']=Registry::boolean();
		if (in_array($name, ['files/fetch', 'files/restore'], true)) $props['expected_sha256'] = ['type' => 'string', 'description' => 'Expected current destination SHA-256, checked under its exclusive lock.'];
		if (preg_match('~^(content/(update|patch|delete)-(post|page)|media/(update|delete|regenerate|set-site-icon)|content/(edit-block|restore-revision|update-meta|delete-meta|update-seo))$~', $name)) $props['expected_revision'] = ['type' => 'string', 'description' => 'Opaque revision token from a content/media read. Reject changes since that read.'];
		if (isset($args['output_schema'])) {
			$args['output_schema']['properties'] = ($args['output_schema']['properties'] ?? []) + array_intersect_key(Result::schema()['properties'], array_flip(['success','message','error_code','conflict','retryable'])) + [
				'operation_id' => ['type' => 'string'], 'replayed' => ['type' => 'boolean'], 'revision' => ['type' => 'string'],
				'current_revision' => ['type' => 'string'], 'current_sha256' => ['type' => 'string'], 'retry_after_ms' => ['type' => 'integer'], 'changed'=>['type'=>'boolean'], 'persisted'=>['type'=>['boolean','null']], 'applied'=>['type'=>['boolean','null']], 'request_id'=>['type'=>'string'], 'result_contract'=>['type'=>'integer'],
			];
		}
		if ('files/list' === $name || 'files/backups' === $name) $props += ['offset' => Registry::integer(), 'per_page' => Registry::integer(1, 'files/list' === $name ? 1000 : 200)];
		if ('files/read' === $name) $props += ['compression'=>['type'=>'string','enum'=>['none','gzip','auto'],'default'=>'none'],'cursor' => Registry::string('Byte cursor. Empty string starts at byte zero. Cannot combine with line/tail/grep options.'), 'offset_bytes' => Registry::integer(), 'byte_limit' => Registry::integer(1, PathGuard::max_bytes())];
		if ('files/read' === $name) { $args['output_schema']['properties']['mode']['enum'][] = 'cursor'; }
		if ('db/execute' === $name) $args['output_schema']['properties']['applied']['type'] = ['boolean', 'null'];
        if ('system/toggle-debug'===$name) {$props['expected_sha256']=Registry::string('Hash da configuração verificado sob lock.');$args['execute_callback']=[DebugTools::class,'update'];$args['description']='Altera constantes booleanas de debug com opt-in explícito, raízes do perfil, lock comum, hash, backup, sintaxe PHP, gravação atômica e sonda. Definições ambíguas/dinâmicas são recusadas.';}
        if ('db/schema'===$name) {
            $props+=['exact'=>Registry::boolean(),'contar'=>Registry::boolean(),'offset'=>Registry::integer(),'per_page'=>Registry::integer(1,100)];
            $args['description']='Lista tabelas físicas e estimativas. exact/contar:true acrescenta rows_exact com contagem limitada por tempo; null e count_error indicam resultado inconclusivo. table, offset, per_page limitam a consulta.';
            $args['execute_callback']=[SchemaTools::class,'read'];
        }
        if ('plugins/list'===$name) {
            $fields=['plugin','name','version','active','description','author','plugin_uri','update_available','update_version','requires','requires_php','update_uri'];
            $props['fields']=['type'=>'array','items'=>['type'=>'string','enum'=>$fields],'minItems'=>1,'uniqueItems'=>true];$props['campos']=$props['fields'];
            $props['prefixes']=['type'=>['string','array'],'items'=>Registry::string()];$props['prefixo']=$props['prefixes'];
            $native=$args['execute_callback'];
            $args['execute_callback']=static function($input)use($native){
                $base=$input;unset($base['fields'],$base['prefixes']);$result=$native($base);
                if(empty($result['success'])||!isset($result['plugins']))return $result;
                $result['plugins']=array_values(array_filter($result['plugins'],static function($row)use($input){if(!isset($input['prefixes']))return true;foreach((array)$input['prefixes'] as $prefix)if(str_starts_with((string)($row['plugin']??''),$prefix))return true;return false;}));
                if(isset($input['fields']))$result['plugins']=array_map(static fn($row)=>array_intersect_key($row,array_flip($input['fields'])),$result['plugins']);
                $result['total']=count($result['plugins']);return $result;
            };
        }
		if($name==='plugins/delete'){$native_delete=$args['execute_callback'];$args['execute_callback']=static fn($input)=>PackageService::delete($input,$native_delete);$args['description']='Exclui plugin inativo em duas fases, com pré-imagem da árvore. Remove somente sua entrada em auto_update_plugins após confirmar ausência física; falha auxiliar pode ser retomada pela mesma confirmação sem repetir uninstall.';}
        $callback = $args['execute_callback'];
		$original_permission = $args['permission_callback'] ?? static fn() => false;
		$permission = static function ($input = []) use ($original_permission,$name,$read) {
			try { $input=ContentContracts::aliases($name,is_array($input)?$input:[]); if(is_wp_error($input))return $input; $allowed=$original_permission($input); } catch (\Throwable $error) { return new \WP_Error('permission_denied','A verificação de permissão falhou.'); }
			if (is_wp_error($allowed)||!$allowed) return $allowed;
			return AuthorizationPolicy::check($name,is_array($input)?$input:[],$read);
		};
		$args['permission_callback']=$permission;
		$args['execute_callback'] = static function ($input = []) use ($callback, $permission, $name, $read): array {
			$input = ContentContracts::aliases($name,is_array($input)?$input:[]);
			if(is_wp_error($input)) return Result::error($input);
			$start = microtime(true);
			$id = bin2hex(random_bytes(12));
			try {
				$allowed = $permission($input);
				if (is_wp_error($allowed)) return Result::error($allowed);
				if (!$allowed) return Result::fail('permission_denied', 'Permission denied.');
				$run = static fn() => ExecutionCoordinator::locked($name, $input, $callback);
				$result = !$read && isset($input['idempotency_key']) && (!DestructiveActions::required($name,$input) || !empty($input['confirm_token'])) ? ExecutionCoordinator::once($name, $input, $run, $id) : $run();
				$result = Result::normalize($result); $runtime_evidence=Recovery::evidence();if($runtime_evidence)$result['runtime_verification']=$runtime_evidence; $result['request_id']=$id; $result['result_contract']=2;
				if (!$read) $result['operation_id'] = $result['operation_id'] ?? $id;
				
				Audit::record($name, $input, $result, (int)round((microtime(true) - $start) * 1000));
				return $result;
			} catch (\Throwable $error) {
				$failure = Result::fail('operation_exception', 'A operação falhou; detalhes sensíveis foram omitidos.', ['operation_id' => $id, 'applied' => $read ? false : null, 'persisted' => null]);
				Audit::record($name, $input, $failure, (int)round((microtime(true) - $start) * 1000));
				return $failure;
			}
		};
		$args['meta']['fator3'] = array_replace($args['meta']['fator3']??[], Providers::metadata($name), ['owned'=>$owned,'adherent'=>$adherent,'decorated'=>true]);
		return $owned ? ContractLanguage::describe($args,$name) : $args;
	}
}
