# Adesão de complementos — C06/O10

O complemento registra a própria versão e declara adesão por habilidade. A política do conector é aplicada no permission_callback, inclusive quando a execução vem por outro servidor MCP. A verificação nativa do complemento permanece obrigatória. Sem adesão, o canal não toma posse das habilidades de terceiros; Elementor continua com seu servidor e seus recursos.

```php
add_action('f3_mcp_register_providers', static function ($policy_version) {
    if ($policy_version === 1) {
        \Fator3\McpFiles\ExtensionContract::register(
            'meu-complemento', MINHA_VERSAO, ['meu-prefixo/']
        );
    }
});
// Antes de wp_register_ability($name, $args):
$args['meta']['fator3'] += [
    'provider' => 'meu-complemento',
    'version' => MINHA_VERSAO,
    'policy_contract' => 1,
];
```

A versão é a do provedor. Use `meta.annotations.readonly` somente para callbacks sem efeitos; habilidades que executam outra habilidade por nome devem declarar `meta.fator3.executes_ability=true`. Elas não podem ser alvos de outro executor ou plano. Google execute-action opera uma API Google e continua sujeito ao seu contrato próprio; isso não o transforma em um executor genérico de WP abilities.

Não reutilize prefixos de outro pacote nem redefina o provedor durante o request. O SDK recusa conflitos. O resultado mantém os campos do provedor e acrescenta o contrato Fator3, identificador e auditoria. Campos `idempotency_key`, quando anunciados pelo wrapper, pertencem ao coordenador do canal. O conector não recebe capacidades WordPress adicionais.

Bases localizadas para integração: Core 1.17.0 e Google 0.4.0. Também há um desenvolvimento Google em andamento ainda identificado como 0.4.0; ele não é tratado como release homologada. A incorporação e o teste dos três pacotes permanecem no gate da entrega.
