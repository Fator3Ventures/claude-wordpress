# Testes de desenvolvimento — WP MCP Fator3 0.12.1

A suíte corrente de pacote, HTTP, contratos de autenticação e atualização está em `../../../tools/`. Execute os comandos do [README principal](../../../README.md). Os resultados novos estão em [VALIDACAO.md](../../../docs/VALIDACAO.md).

Este diretório preserva regressões específicas anteriores. Seus números abaixo descrevem o escopo histórico; não são contados como execuções desta entrega. Os documentos antigos citados pertencem ao ZIP original de fontes da rc.2, identificado em [HISTORICO.md](../../../docs/HISTORICO.md).

Os arquivos em `upstream/e2e` são referências históricas do Ultimate. Seus seletores da tela antiga não representam a interface corrente e essa suíte Playwright não foi executada nesta entrega.

Execute scripts que recebem um caminho WordPress somente em instalação descartável, com administrador ID 1, Fator3 como único plugin ativo e canal aberto. Eles criam/removem fixtures e registram auditoria. Para as regressões destrutivas, defina `F3_DELETE_POST_DISPOSABLE_LAB=true` no laboratório. Execute os comandos abaixo a partir deste diretório de testes.

## Preparação da 0.13.0

Testes e resultados históricos abaixo não homologam o código futuro. P07 criará o laboratório reproduzível da pilha real; D05/D06 ligam cada especificação a schema efetivo e execução. Consultar [especificações](../../../docs/ESPECIFICACOES.md) e [checklist](../../../docs/CHECKLIST-RELEASE-0.13.0.md). O gate de atualização da frota é 0.12.1 → 0.13.0 single-site; rc.2/SQLite permanecem somente na reprodução histórica.

A revisão documental de 27/09 acrescenta critérios em F16–F19/N03 e F13. As fixtures de regressão deverão usar tokens sintéticos, recursos nested/legados, processos concorrentes, blocos com filhos e opção de uninstall com entradas concorrentes. Esses testes ainda não foram criados/executados nesta revisão; o relatório documental não conta como aceite funcional.

As novas fixtures da revisão 7 estão em F20–F23/N04–N08, F19/O08/O13 e na matriz de frota. Não foram executadas nesta revisão documental.

## Regressões da 0.9.3

Em uma instalação WordPress descartável, adicione `define('F3_DELETE_POST_DISPOSABLE_LAB', true);` ao `wp-config.php`. Não defina `EMPTY_TRASH_DAYS` nesse arquivo durante estes testes: o runner define a constante antes de carregar o WordPress, em dois processos separados.

```bash
php delete-post-093.php /caminho/wordpress enabled trash-enabled.json
php delete-post-093.php /caminho/wordpress disabled trash-disabled.json
```

Requer o Fator3 ativo e administrador ID 1. Cria e remove somente os registros de teste que o runner registra para limpeza. Usa APIs WordPress reais, incluindo Abilities API e metatools, sete tipos de conteúdo, lixeira/restauração, metadados, comentários, permissões e filtros. São 77 verificações com lixeira ativada e 58 com lixeira desativada. Não usa stubs das funções de conteúdo do WordPress. Os resultados originais estão no arquivo histórico da rc.2, sob a documentação da 0.9.3.

## Regressões da 0.9.2

```bash
php rmdir-092.php rmdir-092.json
```

O runner executa PHP e operações reais de filesystem em uma árvore temporária criada por ele. As funções WordPress são stubs explícitos; esta suíte não substitui a integração em WordPress real. Cobre exclusão de pasta vazia, arquivos/subpastas/ocultos, symlinks, confinamento, capacidades, canal fechado, validações, auditoria, concorrência controlada e preservação da exclusão de arquivos com backup. O teste de concorrência cria um arquivo imediatamente antes da chamada nativa de `rmdir`.

## Regressões da 0.9.1

```bash
php -d memory_limit=64M files-read-delete-091.php /caminho/wordpress regressions-091.json
```

Execute em processo novo: o teste comprova que `request_filesystem_credentials()` ainda não foi carregada antes da primeira exclusão. Exclui somente plugins descartáveis que ele próprio cria e valida o desinstalador real, erros de credenciais/conexão, limpeza de filtros/cache, leitura integral e parcial, filtro literal/PCRE, LF/CRLF, limite de bytes, log de 64 MiB, schemas, metatool e permissões. Requer espaço temporário para esse log.

Os resultados originais estão no arquivo histórico da rc.2, sob a documentação da 0.9.1. A execução local usou WordPress 6.9.4 e PHP 8.3.6, com SQLite Database Integration 3.0.1 somente como banco do laboratório; esse componente não integra o ZIP de produção.

## Suíte herdada da 0.9.0

```bash
php integration.php /caminho/wordpress integration.json
php upstream-regressions.php /caminho/wordpress prs.json
php confine.php /caminho/wordpress wp confine.json
php confine.php /caminho/wordpress edit disallow-edit.json
php confine.php /caminho/wordpress mods disallow-mods.json
```

`integration.php` verifica o inventário original, round-trip de conteúdo e outros campos, arquivos fora de ABSPATH, restauração, SQL em duas fases, gates e o auto-teste. `upstream-regressions.php` verifica as proteções do PR #9 incorporadas pelo upstream. `confine.php` carrega as constantes antes do WordPress.

O relatório histórico `docs/RELATORIO.md`, preservado no arquivo da rc.2, também documenta testes de migração com o desinstalador real, HTTP/Application Password, OAuth completo e mutação realizados no laboratório. Os arquivos em `upstream/` são testes do repositório de origem preservados como referência; a suíte Playwright upstream não foi executada nesta entrega.
