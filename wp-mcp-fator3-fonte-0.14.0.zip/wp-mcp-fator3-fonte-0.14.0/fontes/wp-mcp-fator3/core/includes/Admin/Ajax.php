<?php
declare(strict_types=1);
namespace WpMcpUltimate\Admin;
use Fator3\McpFiles\{Admin,ConnectionEndpoints,ConnectionStatus,ConnectionTest,ConnectionsAdmin,Locks,Result};

class Ajax {
    public static function init(): void {
        foreach (['generate_key','revoke_key','test_connection'] as $action) add_action('wp_ajax_wp_mcp_ultimate_' . $action, [self::class, $action]);
    }
    private static function authorize(): void {
        check_ajax_referer('wp-mcp-ultimate', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => 'Permissão insuficiente.'], 403);
        nocache_headers();
    }
    private static function respond(array $result): void {
        if (empty($result['success'])) wp_send_json_error($result);
        wp_send_json_success($result);
    }
    public static function generate_key(): void {
        self::authorize();
        $result = Locks::run(['credential:' . get_current_blog_id() . ':' . get_current_user_id() => LOCK_EX], static function(): array {
            clean_user_cache(get_current_user_id());
            if (ConnectionStatus::key()) return Result::fail('credential_exists', 'Já existe uma senha cadastrada. Revogue-a explicitamente antes de criar outra.');
            if (!wp_is_application_passwords_available()) return Result::fail('application_password_unavailable', 'Senhas de aplicação indisponíveis. Confira HTTPS e as restrições do site.');
            $profile = isset($_POST['profile']) && is_string($_POST['profile']) ? wp_unslash($_POST['profile']) : 'read';
            if (!in_array($profile, ['read', 'content'], true)) return Result::fail('profile_invalid', 'Selecione Leitura ou Conteúdo; perfis avançados ficam na aba Conectores.');
            $user = wp_get_current_user();
            $created = \WP_Application_Passwords::create_new_application_password($user->ID, ['name' => 'WP MCP Fator3']);
            if (is_wp_error($created)) return Result::fail('credential_create_failed', 'Não foi possível criar a senha de aplicação.');
            [$password, $item] = $created;
            $saved = ConnectionsAdmin::save(['connection_id' => 'app:' . $item['uuid'], 'user_id' => $user->ID, 'profile' => $profile, 'label' => 'WP MCP Fator3']);
            if (empty($saved['success'])) {
                \WP_Application_Passwords::delete_application_password($user->ID, $item['uuid']);
                return $saved;
            }
            update_user_meta($user->ID, 'f3_mcp_app_password', $item['uuid']);
            if (get_user_meta($user->ID, 'f3_mcp_app_password', true) !== $item['uuid']) {
                \WP_Application_Passwords::delete_application_password($user->ID, $item['uuid']);
                return Result::fail('credential_save_failed', 'Não foi possível salvar a referência da credencial.');
            }
            delete_user_meta($user->ID, 'f3_mcp_connection_test');
            return Result::ok(['profile' => $profile, 'connection_id' => 'app:' . $item['uuid'], 'password' => $password, 'username' => $user->user_login, 'base64' => base64_encode($user->user_login . ':' . $password)], 'Senha de aplicação criada.');
        });
        self::respond($result);
    }
    public static function revoke_key(): void {
        self::authorize();
        $result = Locks::run(['credential:' . get_current_blog_id() . ':' . get_current_user_id() => LOCK_EX], static function(): array {
            clean_user_cache(get_current_user_id());
            $user = get_current_user_id(); $item = ConnectionStatus::key();
            if ($item) {
                $deleted = ConnectionsAdmin::save(['intent' => 'revoke', 'connection_id' => 'app:' . $item['uuid'], 'user_id' => $user]);
                if (empty($deleted['success']) || ConnectionStatus::key()) return Result::fail('credential_revoke_failed', 'Não foi possível confirmar a revogação.');
            }
            delete_user_meta($user, 'f3_mcp_app_password');
            if (get_user_meta($user, 'f3_mcp_app_password', true)) return Result::fail('credential_reference_failed', 'A senha foi revogada, mas a referência não foi removida. Atualize a página e tente novamente.');
            delete_user_meta($user, 'f3_mcp_connection_test');
            return Result::ok([], $item ? 'Senha revogada.' : 'Nenhuma senha ativa para revogar.');
        });
        self::respond($result);
    }
    public static function test_connection(): void {
        self::authorize();
        $route = isset($_POST['route']) && is_string($_POST['route']) ? wp_unslash($_POST['route']) : ConnectionEndpoints::route();
        self::respond(ConnectionTest::run($route));
    }
}
