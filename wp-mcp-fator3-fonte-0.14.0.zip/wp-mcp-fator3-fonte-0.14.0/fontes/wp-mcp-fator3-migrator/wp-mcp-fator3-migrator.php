<?php
/**
 * Plugin Name: WP MCP Fator3 — Migração protegida
 * Description: Componente transitório para atualizar o canal antigo para a entrega 0.14.0, com pré-imagem e recuperação independente.
 * Version: 0.14.0
 * Requires at least: 6.9
 * Requires PHP: 8.1
 * Update URI: false
 * License: GPL-2.0-or-later
 */
declare(strict_types=1);
namespace Fator3\Migration014;
if(!defined('ABSPATH'))exit;
if(!class_exists('Fator3\\Migration014Runtime\\Engine',false))require_once __DIR__.'/RecoveryEngine.php';
require_once __DIR__.'/ZipPackage.php';
use Fator3\Migration014Runtime\Engine;

/** Independent from the installed MCP's classes, autoload and persistent schema. */
final class Migrator {
    private const SLUG='wp-mcp-fator3';
    private const ENTRY='wp-mcp-fator3/wp-mcp-fator3.php';
    public static function directory(): string {
        $root=WP_CONTENT_DIR.'/f3-mcp-migration-014';
        if(is_link($root))throw new \RuntimeException('migration_storage_link');
        if(!is_dir($root)&&!mkdir($root,0700,true))throw new \RuntimeException('migration_storage_unavailable');
        if(!is_file($root.'/index.php'))Engine::atomic($root.'/index.php',Engine::HEADER,0600);
        return $root;
    }
    private static function result(bool $ok,string $code,array $data=[]): array {return ['success'=>$ok,'error_code'=>$code]+$data;}
    public static function permission(): bool {return current_user_can('update_plugins')&&current_user_can('activate_plugins')&&current_user_can('manage_options');}
    public static function init(): void {
        add_action('wp_abilities_api_categories_init',static fn()=>wp_register_ability_category('f3-migration',['label'=>'Migração protegida','description'=>'Atualização do canal com pré-imagem independente.']));
        add_action('wp_abilities_api_init',static function(){
            if(!function_exists('wp_register_ability'))return;
            $str=['type'=>'string'];$properties=['url'=>$str,'content_base64'=>$str,'expected_sha256'=>$str,'expected_version'=>$str,'expected_current_version'=>$str,'confirm_token'=>$str];
            foreach(['apply'=>['Prepara/aplica atualização exclusiva do WP MCP Fator3; hash, versão atual e candidata obrigatórios. Duas fases; preserva ativação, cria backup independente e verifica PHP novo.',$properties,['expected_sha256','expected_version','expected_current_version']],'status'=>['Consulta diário independente de migração.',['operation_id'=>$str,'confirm_token'=>$str],[]],'finish'=>['Desativa este componente somente após migração concluída. A sentinela de recuperação permanece.',['operation_id'=>$str],['operation_id']]] as $name=>$spec){
                wp_register_ability('f3-migration/'.$name,['label'=>'Migração '.$name,'description'=>$spec[0],'category'=>'f3-migration','input_schema'=>['type'=>'object','properties'=>$spec[1],'required'=>$spec[2],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>[self::class,'permission'],'execute_callback'=>[self::class,$name],'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>$name==='status','destructive'=>$name!=='status']]]);
            }
        });
        add_action('rest_api_init',static function(){register_rest_route('f3-mcp-migration/v1','/verify',['methods'=>'POST','permission_callback'=>static function($r){$s=self::load((string)$r['id']);return $s&&hash_equals($s['verify_key_sha256']??'',hash('sha256',(string)$r['key']));},'callback'=>static function($r){$s=self::load((string)$r['id']);$routes=rest_get_server()->get_routes();return ['version'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'active'=>in_array(self::ENTRY,(array)get_option('active_plugins',[]),true),'routes'=>isset($routes['/mcp/wp-mcp-fator3'],$routes['/mcp/wp-mcp-ultimate']),'nonce'=>(string)$r['nonce']];}]);});
        if(isset($_GET['f3_migration_probe'])&&preg_match('/^[a-f0-9]{32}$/D',(string)$_GET['f3_migration_probe'])){nocache_headers();header('X-F3-Migration-Probe: '.$_GET['f3_migration_probe']);}
    }
    private static function load(string $id): ?array {if(!preg_match('/^[a-f0-9]{32}$/D',$id))return null;return Engine::read(self::directory().'/'.$id.'.journal.php');}
    private static function sentinel(): void {
        if(!is_dir(WPMU_PLUGIN_DIR)&&!wp_mkdir_p(WPMU_PLUGIN_DIR))throw new \RuntimeException('migration_mu_unavailable');
        Engine::atomic(WPMU_PLUGIN_DIR.'/f3-migration-recovery-014.php',(string)file_get_contents(__DIR__.'/RecoveryEngine.php'),0600);
        $loader="<?php\nif(!defined('ABSPATH'))exit;\nrequire_once __DIR__.'/f3-migration-recovery-014.php';\n\\Fator3\\Migration014Runtime\\Engine::sweep(".var_export(self::directory(),true).");\n";
        Engine::atomic(WPMU_PLUGIN_DIR.'/000-f3-migration-014.php',$loader,0600);
    }
    public static function status(array $i): array {
        if(empty($i['operation_id'])&&!empty($i['confirm_token'])&&preg_match('/^[a-f0-9]{64}$/D',$i['confirm_token'])){$c=Engine::read(self::directory().'/confirm-'.$i['confirm_token'].'.php');if($c&&(int)($c['user_id']??0)===get_current_user_id())$i['operation_id']=$c['operation_id']??'';}$s=self::load($i['operation_id']??'');if(!$s)return self::result(false,'migration_not_found');
        return self::result(true,'',array_intersect_key($s,array_flip(['id','status','before_version','expected_version','before_sha256','after_sha256','time','finished_at','result']))+['operation_id'=>$s['id']]);
    }
    private static function probe(string $url): bool {
        $nonce=bin2hex(random_bytes(16));$r=wp_remote_get(add_query_arg('f3_migration_probe',$nonce,$url),['timeout'=>20,'redirection'=>0,'cookies'=>[],'headers'=>['Cache-Control'=>'no-cache, no-store'],'limit_response_size'=>1048576]);
        return !is_wp_error($r)&&wp_remote_retrieve_response_code($r)===200&&hash_equals($nonce,(string)wp_remote_retrieve_header($r,'x-f3-migration-probe'));
    }
    public static function apply(array $i): array {
        if(!self::permission())return self::result(false,'permission_denied');
        if(count(array_intersect(array_keys($i),['url','content_base64']))!==1)return self::result(false,'package_source_invalid');
        if(!preg_match('/^[a-f0-9]{64}$/D',$i['expected_sha256']))return self::result(false,'package_hash_invalid');
        require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/file.php';
        if(get_filesystem_method()!=='direct')return self::result(false,'filesystem_direct_required');
        $root=self::directory();$lock=fopen($root.'/migration.lock.php','c+b');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){if($lock)fclose($lock);return self::result(false,'migration_busy');}
        $stage=$root.'/'.bin2hex(random_bytes(16)).'.stage';$lease=null;
        try{
            $request_hash=hash('sha256',serialize([$i['expected_sha256'],$i['expected_version'],$i['expected_current_version'],get_current_user_id()]));if(!empty($i['confirm_token'])&&preg_match('/^[a-f0-9]{64}$/D',$i['confirm_token'])){$previous=Engine::read($root.'/confirm-'.$i['confirm_token'].'.php');if($previous&&hash_equals($previous['request_hash']??'',$request_hash)&&!empty($previous['operation_id'])){$known=self::load($previous['operation_id']);if($known&&$known['status']==='complete')return self::result(true,'',($known['result']??[])+['operation_id'=>$known['id'],'backup_id'=>$known['id'],'replayed'=>true]);return self::result(false,'migration_already_started',['operation_id'=>$previous['operation_id'],'status'=>$known['status']??'unknown','applied'=>null,'retryable'=>false]);}}
            $current=get_plugin_data(WP_PLUGIN_DIR.'/'.self::ENTRY,false,false)['Version']??'';
            if($current!==$i['expected_current_version'])return self::result(false,'migration_version_conflict',['current_version'=>$current]);
            if(!is_plugin_active(self::ENTRY))return self::result(false,'migration_channel_inactive');
            if(isset($i['url'])){if(strtolower((string)wp_parse_url($i['url'],PHP_URL_SCHEME))!=='https')return self::result(false,'package_https_required');$r=wp_safe_remote_get($i['url'],['timeout'=>60,'limit_response_size'=>16777217]);if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return self::result(false,'package_download_failed');$bytes=wp_remote_retrieve_body($r);}else $bytes=base64_decode($i['content_base64'],true);
            if($bytes===false||strlen($bytes)>16777216||!hash_equals($i['expected_sha256'],hash('sha256',$bytes)))return self::result(false,'package_hash_conflict');
            mkdir($stage,0700);Engine::atomic($stage.'/package.zip',$bytes,0600);unset($bytes);mkdir($stage.'/expanded',0700);ZipPackage::extract($stage.'/package.zip',$stage.'/expanded');
            $candidate=$stage.'/expanded/'.self::SLUG;
            if(count(array_diff(scandir($stage.'/expanded'),['.','..']))!==1||!is_file($candidate.'/wp-mcp-fator3.php'))return self::result(false,'package_slug_conflict');
            $data=get_plugin_data($candidate.'/wp-mcp-fator3.php',false,false);
            if(($data['Version']??'')!==$i['expected_version']||version_compare($data['Version'],'0.14.0','<'))return self::result(false,'package_version_conflict');
            if(!is_wp_version_compatible($data['RequiresWP'])||!is_php_version_compatible($data['RequiresPHP']))return self::result(false,'package_requirements');
            foreach(['includes/RecoveryEngine.php','includes/SelfUpdate.php','includes/Release014.php','includes/guide-content.php'] as $f)if(!is_file($candidate.'/'.$f))return self::result(false,'package_incomplete');
            $target=WP_PLUGIN_DIR.'/'.self::SLUG;$before=Engine::manifest($target);$before_sha=Engine::digest($before);$after=Engine::digest(Engine::manifest($candidate));
            $intent=hash('sha256',serialize([$i['expected_sha256'],$i['expected_version'],$current,$before_sha,get_current_user_id()]));
            if(empty($i['confirm_token'])){$token=bin2hex(random_bytes(32));Engine::write($root.'/confirm-'.$token.'.php',['intent'=>$intent,'request_hash'=>$request_hash,'user_id'=>get_current_user_id(),'expires'=>time()+600,'status'=>'pending']);return self::result(true,'',['preview'=>true,'applied'=>false,'confirm_token'=>$token,'current_version'=>$current,'version'=>$data['Version'],'tree_sha256'=>$after]);}
            $token=$i['confirm_token'];if(!preg_match('/^[a-f0-9]{64}$/D',$token))return self::result(false,'confirmation_invalid');$cf=$root.'/confirm-'.$token.'.php';$confirmation=Engine::read($cf);
            if(!$confirmation||$confirmation['intent']!==$intent||$confirmation['expires']<time()||$confirmation['status']!=='pending')return self::result(false,'confirmation_invalid');
            if(!self::probe(home_url('/'))||!self::probe(rest_url('/')))return self::result(false,'migration_baseline_failed');
            $size=array_sum(array_column($before['files'],'bytes'));if(disk_free_space($root)<$size*3+33554432)return self::result(false,'migration_disk_budget');
            self::sentinel();$id=bin2hex(random_bytes(16));$journal=$root.'/'.$id.'.journal.php';$pre=$root.'/'.$id.'.preimage';Engine::copy($target,$pre);$key=bin2hex(random_bytes(32));
            $s=['id'=>$id,'status'=>'armed','target'=>$target,'preimage'=>$pre,'before_sha256'=>$before_sha,'after_sha256'=>$after,'lease_until'=>time()+120,'locks'=>[$root.'/migration.lock.php'=>LOCK_EX],'time'=>time(),'plugin'=>self::ENTRY,'active_before'=>true,'network_active_before'=>false,'before_version'=>$current,'expected_version'=>$data['Version'],'verify_key_sha256'=>hash('sha256',$key)];
            Engine::write($journal,$s);$lease=fopen($journal.'.lease','c+b');if(!$lease||!flock($lease,LOCK_EX|LOCK_NB))throw new \RuntimeException('migration_lease_failed');
            $confirmation['status']='running';$confirmation['operation_id']=$id;Engine::write($cf,$confirmation);
            Engine::prepare_install($journal,$candidate);Engine::commit_install($journal);$s=Engine::read($journal);$s['status']='applied';Engine::write($journal,$s);
            $nonce=bin2hex(random_bytes(16));$response=wp_remote_post(rest_url('f3-mcp-migration/v1/verify'),['timeout'=>30,'cookies'=>[],'body'=>['id'=>$id,'key'=>$key,'nonce'=>$nonce]]);$body=is_wp_error($response)?[]:json_decode(wp_remote_retrieve_body($response),true);
            $ok=($body['nonce']??'')===$nonce&&($body['version']??'')===$i['expected_version']&&!empty($body['active'])&&!empty($body['routes'])&&self::probe(home_url('/'))&&self::probe(rest_url('/'));
            if(!$ok){$recovery=Engine::restore($journal,true);return self::result(false,'migration_verification_failed',['operation_id'=>$id,'recovery'=>$recovery,'applied'=>$recovery['status']==='rolled_back'?false:null]);}
            $s=Engine::read($journal);$s['status']='complete';$s['finished_at']=time();$s['result']=['changed'=>true,'active_before'=>true,'active_after'=>true,'version'=>$i['expected_version'],'old_version'=>$current,'verified_in_new_request'=>true];Engine::write($journal,$s);Engine::finish_install($journal);$confirmation['status']='complete';Engine::write($cf,$confirmation);
            return self::result(true,'',$s['result']+['operation_id'=>$id,'backup_id'=>$id]);
        }catch(\Throwable $e){$recovery=isset($journal)?Engine::restore($journal,true):null;return self::result(false,'migration_failed',['operation_id'=>$id??null,'recovery'=>$recovery,'applied'=>$recovery?($recovery['status']==='rolled_back'?false:null):false]);}
        finally{if(is_resource($lease)){flock($lease,LOCK_UN);fclose($lease);}if(is_dir($stage))Engine::remove($stage);flock($lock,LOCK_UN);fclose($lock);}
    }
    public static function finish(array $i): array {
        $s=self::load($i['operation_id']);if(!$s||$s['status']!=='complete')return self::result(false,'migration_not_complete');
        foreach(glob(self::directory().'/*.journal.php')?:[] as $file){$other=Engine::read($file);if(in_array($other['status']??'',['armed','applied','restoring','recovery_required'],true))return self::result(false,'migration_pending');}
        require_once ABSPATH.'wp-admin/includes/plugin.php';deactivate_plugins(plugin_basename(__FILE__),true);return self::result(true,'',['component_deactivated'=>true,'recovery_preserved'=>true]);
    }
}
Migrator::init();
