# Base Site Core Fator3 1.18.0

Instale `base-site-core-fator3-1.18.0.zip` pelo WordPress. O ZIP de fontes e testes não é instalável. Caminhos suportados: instalação nova ou atualização de uma **1.17.0 concluída**. Recuperação e retomada ocorrem na própria 1.18; não há suporte a downgrade.

A medição passa a priorizar conteúdo orgânico, sessões e presença em IA. Páginas e Artigos usam o tipo real do WordPress. Requisições de robôs, visitas encaminhadas por IA e referências com evidência são medidas separadas. O painel oferece jornadas por sessão, tempo e rolagem quando coletados, origem da entrada, HTML/Markdown, exportação e cobertura.

A 1.18 corrige identidade editorial por query, templates confundidos com a home, união de caminhos e totais de descoberta. Reconcilia logs com fontes antigas ausentes, arquiva agregados sobrepostos e publica dias novos. Acrescenta exclusões anotadas por padrão, edição/remoção auditada, saúde da coleta e catálogos de IA ampliados. Corrige P32, orientação de navegação, diagnóstico de consentimento e resposta Markdown sem conversão suportada.

Preferências explícitas são preservadas, incluindo `false`, `0` e `[]`. Tempo ativo continua desligado por padrão. Integrações comerciais existentes continuam opcionais e desligadas em instalação nova. A atualização não dispara envios retroativos ao CRM. Não altera temas, implantador ou sites da frota.

Novos agregados editoriais duram 13 meses por padrão, sem IDs de sessão/visitante. Não ampliam a retenção dos eventos individuais nem dos contatos. Logs diários conservam a política existente. Histórico perdido não é reconstruído por suposição.

Leia [DOCUMENTACAO.md](DOCUMENTACAO.md), [MEDICAO-1.18.md](MEDICAO-1.18.md) e [VALIDACAO.md](VALIDACAO.md). Todos acompanham o plugin e estão disponíveis a administradores por `f3base/documentacao-ler`.
