# Contratos — plugin 1.18.0 / configuração 4.2.0

## Permissões e política

Operações administrativas exigem autenticação e capability. As abilities de relatórios, jornada, documentação e política exigem `manage_options`. O plugin não cria credenciais nem concede administração a outros papéis.

`f3base/config-core-politica-ler` retorna fotografias de `politica` e `gestao`, com valor, existência e revisão. `f3base/config-core-politica-escrever` aceita somente `politica`, `simular` (padrão true) e `revisao_esperada`. A escrita exige revisão atual e gestão por agentes habilitada. A simulação retorna `acrescimos` e `remocoes`. O contrato antigo de lista simples não é aceito por essa operação.

```json
{"politica":{"schema":1,"modo":"selecionadas","lista":["f3base_contato"]},"simular":true}
```

Modos `todas` e `nenhuma` exigem `lista:[]`; `selecionadas` exige itens únicos, elegíveis e não vazios. Uma lista explícita permanece explícita, mesmo se contém todos os itens atuais.

## Captura

POST `/wp-json/f3base/v1/lead` mantém schema fechado, token, quotas e deduplicação. `correlation_id` identifica a ação; a coluna persistida é `correlacao`. Sessão e navegação são 32 hex. O servidor classifica o método pelo destino e obtém IP, user agent e página do contexto da requisição. `cta` é um identificador estável limitado a 80 caracteres; `dispositivo` aceita `movel` ou `desktop` no contexto canônico. Sem medição autorizada, sessão/navegação/dispositivo não são persistidos como contexto analítico.

Formulários usam POST `/formularios/token` e `/formularios/enviar` dentro do mesmo namespace. Sem JS, usam `admin-post.php?action=f3base_formulario`. Token vincula formulário, revisão e página. Com JS, cada instância recebe uma chave nova, inclusive se o HTML veio de cache; retentativas mantêm a chave. O envio inclui atribuição de sessão, navegação e dispositivo quando disponíveis. O registro guarda snapshot da definição dos campos de opções fechadas para análise futura.

POST `/wp-json/f3base/v1/analise` aceita `token`, `medicao:true` e `eventos` (1–20). Limite de corpo: 32 KiB. Tipos: `pagina`, `form_vista`, `form_inicio`, `form_tentativa`, `form_erro`, `vital`. Identificadores: `evento`, `visitante`, `sessao`, `navegacao`; contexto: `caminho`, `formulario`, `formulario_revisao`, `correlacao`, `dispositivo`, `criado_em`, `detalhe`, `valor`, `sequencia`, `atribuicao`. Campos desconhecidos e valores digitados são recusados. O cliente envia lotes limitados por bytes.

Evento igual é idempotente. O mesmo ID com outro conteúdo é conflito, exceto revisão crescente de uma amostra de vital com identidade estável. A atualização é condicional e conserva a maior sequência. Horário fora da janela válida recebe âncora do servidor; a qualidade do horário fica registrada. Há quotas por origem (300 requisições/10 min) e sessão (1.000 eventos na janela). Rotas dinâmicas não devem ser armazenadas pelo cache.

## Relatórios e documentação

`f3base/relatorios-integrados-ler`: `de`, `ate` (YYYY-MM-DD, intervalo inclusivo de 1–90 dias), `visao`, `caminho`, `formulario`, `metodo`, `comparar`, `segmento`, `plataforma`, `conta_id`, `campanha_id`, `grupo_id`, `anuncio_id`, `pagina` e `limite` (1–200). Visões: `resultados`, `campanhas`, `formularios`, `blocos`, `qualidade`, `operacao`, `materiais`, `demanda`, `metodos`. Retorna período/fuso, totais, cobertura, avisos, linhas e próxima página. Filtros de formulário/método restringem contatos; denominadores continuam sessões da página observada. Caminhos externos são recusados.

`f3base/lead-jornada-ler`: `record_id` (32 hex). Até 500 eventos anteriores ao recebimento, com indicação de corte. Sem sessão ou sem eventos, não inventa uma jornada.

`f3base/documentacao-ler`: `arquivo`, `linha`, `limite` (1–200). Sem arquivo, índice. Caminhos não catalogados são recusados. `f3base/arquivos-privados-preparar` cria/testa a raiz configurada, sem enviar mensagens.

As abilities de consulta/gestão de leads e resposta opcional permanecem nos schemas publicados. O importador, o reparador histórico, o destino de gravação Flamingo/CPT e a resolução de destino CAPI anterior à base suportada foram retirados. A leitura do acervo já incorporado continua disponível.

`persisted` confirma armazenamento. `verified` no acesso direto ao cache exige corpo completo vazio com HTTP 200/403/404/410; 403 com HTML falha na expectativa de corpo. Hash igual ao arquivo prova exposição. 5xx, redirecionamento, truncamento e ausência de arquivo permanecem inconclusivos.

## Contratos atuais

`contexto_teste` é booleano; cabeçalho HTTP aceita 0/1. A classe armazenada é `teste` ou `nao_marcado`. Histórico sem marca permanece não marcado. Não existe token temporário para declarar teste. Dados operacionais de controle MCP são distintos de coleta pública; somente sondas explicitamente suportadas propagam o contexto.

Análise responde `confirmados:[{evento,sequencia}]`. Sucesso parcial confirma somente o que foi persistido. 400/409/413 são rejeições identificáveis; 403 token inválido permite uma renovação; 429 aplica Retry-After; 503 sinaliza falha de armazenamento e conserva os itens pendentes. Resposta não JSON não confirma recebimento. O cliente mantém no máximo 100 eventos/24 horas, retentativas com atraso e IDs estáveis, sem coleta antes da permissão. Limites/expiração/rejeição ficam no diagnóstico local. Não há promessa de entrega após encerramento do navegador.

Atribuição possui allowlist publicada em `dados/contrato.json`, limite de 500 caracteres por valor comum (oppref tem exceção opaca de até 8192 bytes), IDs como strings, snapshots de primeiro/último toque e origem da sessão. Não guardar query inteira. `f3_ads_v=1` declara que utm_id identifica campanha e utm_content identifica anúncio. Sem esse contrato, os campos continuam rótulos e não viram IDs por aparência. utm_term é palavra-chave. fbclid sozinho não identifica Facebook versus Instagram. Consulte CRUZAMENTOS-PUBLICIDADE.md.

Relatórios retornam `regra`, `consultado_em`, `fontes`, `limites`, cobertura e linhas. Segmentos: `sem_testes` (padrão), `somente_testes`, `todos`. Os mesmos filtros e definições valem para GUI/ability/CSV. A API de leads vincula cursor ao filtro; reaproveitar cursor com filtro diferente é recusado.

Redirects têm `preservar_query:boolean` (padrão true). Destino externo exige HTTPS e host exato em allowlist; cada salto é revalidado na sonda. Sem prova do ID/name da âncora no HTML final, verificação fica pendente. Leitura do cadastro não executa HTTP.

Servidor usa revisão do arquivo e das preferências, trava de operação e backup privado. Conflito preserva o arquivo. O script de recuperação CLI exige o hash da escrita correspondente e funciona sem WordPress. Interrupção total do processo pode exigir execução manual; não é prometida reversão automática de qualquer timeout.

## Evolução do contrato na 1.18.0

`contract_version` é **4.2.0** nesta versão. O nome `config-core-contrato-v1` permanece como identificador da ability; não indica a versão do conteúdo. Consumidores devem ler input/output schemas instalados.

- `config-core-escrever`: mescla valida delta e dependências; listas são substituídas integralmente. `servicos[]` e `ofertas[]` são fechados nos dois modos. Simulação retorna `simulado:true`, `persisted:false`, `changed:false`, `alteraria` e `campos_removidos`, sem afirmar gravação nem executar efeitos.
- `config-core-ler` e consultas expõem fotografia bruta mascarada, existência, revisão, validade, `erros[]`/`avisos[]` por caminho e herança. `chaves_herdadas:null` significa leitura inconclusiva; `[]` é uma leitura conhecida sem chaves herdadas.
- `config-core-perfil-avaliar`: aceita `perfil_id`, `perfil_revisao` opcional e exceções, ou objeto `perfil`, nunca ambos. ID desconhecido, revisão incompatível e condição duplicada são recusados. `igual`, `presente`, `derivado_do_host`, `contem`, `referencia_valida`, `configurado` e `verificado` têm semânticas distintas. Exceção exige responsável, motivo, expiração, ID/revisão do perfil e `estado_ref`. A avaliação nunca aplica o piso.
- `config-core-verificar`: `compacto:true` mantém status, revisão, efeito, persistência, resumo de verificação pública e `evidencia_id`. `evidencia_id` com ação consultar recupera detalhe sem HTTP. Prova expirada retorna `evidencia_expirada`; ausente retorna `evidencia_ausente`. Um ID não é histórico ilimitado: só provas atualmente conservadas são recuperáveis.
- Respostas de verificação, saúde, ajuda e contrato reúnem conjuntos de tokens em `evidencias_tokens`, uma entrada por SHA-256 do conteúdo exato; `tokens.evidencia_ref` referencia essa entrada. `contrato_evidencias:2` distingue o formato. Tentativa e sucesso diferentes mantêm IDs diferentes. `ok` não significa `verified`.
- R54 usa evidência própria v2 por execução/configuração/contexto e por variante de query. Expiração é individual; cursor e orçamento não transformam cobertura parcial em sucesso. Falha de persistência é explícita.
- Schema de ofertas está em OFERTAS.md e no catálogo. Preço canônico permanece string; `minPrice` emitido é Number. Oferta não comprovada no conteúdo público não é publicada pelo Core.

## Atribuição e CAPI

`fbc`/`fbp` aceitam somente formato `fb.<índice>.<timestamp>.<valor>` e tamanho limitado a 500; cookies legítimos não são fabricados pelo servidor. O navegador pode formar fbc a partir de fbclid atual quando medição e publicidade permitem; não fabrica fbp. Sem medição, ficam somente origem corrente e modelo sessão: toques armazenados, horários e identificadores persistentes são removidos. Sem publicidade, identificadores publicitários são removidos recursivamente. Um true do cliente não amplia a autorização do servidor.

Clique e formulário usam um envelope único montado do registro confirmado. `atribuicao` fica aninhada, contexto de teste/consentimento, horário original, URL, IP/UA e correlação/event ID são preservados na fila. Sem registro confirmado não há agendamento; teste suprimido não entra na fila comercial. A autorização é revalidada no despacho. Não há preenchimento retroativo nem reenvio de acervo histórico. Leia dados/contrato.json e CRUZAMENTOS-PUBLICIDADE.md.

## Cadência

O resultado em `saude.cadencia` tem destino `registro_local_de_atividade`, `envia_mensagens:false`, `corrige_configuracao:false`. Contém estado dos módulos, releitura das options e censo demonstrativo. Retém o **último resultado**, sem histórico completo. Expõe frequência, fuso, quantidade de ajustes acumulados/limiar, próxima execução e última execução com duração/erros. `nenhuma`/zero desligam os gatilhos correspondentes. WP-Cron depende de tráfego ou executor real. Consultar saúde/Operação não executa a cadência nem manda e-mail.


## Contrato 4.2.0

`f3base_navegacao`: objeto fechado `{schema:1,tipo:"tema"|"menu_classico"|"bloco",id:integer}`. `nav_id` não admite escrita. Perfil atual `piso-padrao-3.2`, revisão `2026-09-30-core-1.18.0`; o perfil 3.1 deixa de ser admitido. Erros têm código, caminho e causa desduplicados. Simulação retorna `changed:false`, `persisted:false` e a previsão em `alteraria`.

Segredos são entradas de substituição/remoção, nunca saídas do contrato. Leitura expõe estado de cifra, presença e necessidade de recadastro. Integrações têm schema fechado e revisão; domínio Pipedrive é restrito à empresa em pipedrive.com. APIs só usam HTTPS, host e rotas permitidos, sem seguir redirect com credencial.

`ctas-inventariar`: `apos_id` e `limite` 1–50. Inspeciona HTML salvo, sem HTTP ou renderização. Retorna rejeições sem query/fragmentos, cobertura e próximo ID. `agentes-relatorio` e CSV compartilham filtros/definições em AGENTES-E-BUSCADORES.md. `pipedrive-previa` contém dados privados do contato, acessíveis apenas a operadores autorizados.

`POST /wp-json/f3base/v1/anuncios/google`: HTTPS obrigatório; autenticação pela chave Google no corpo antes de persistir contato; até 128 KiB. HTTP 200 `{}` só após captura/duplicata confirmada ou descarte explícito anterior ao marco; chave inválida 403, conflito 409 e persistência recuperável 503. Leia ORIGENS-ANUNCIOS.md para IDs e equivalência da reconciliação.

## Consulta original em redirects

O WP Super Cache pode retirar parâmetros de rastreamento de `REQUEST_URI` antes de o Core avaliar a rota. O resolvedor usa `QUERY_STRING` quando fornecido pelo servidor para preservar a consulta original; só recorre à URI quando aquela variável não existe. Não use uma URI já normalizada como prova de ausência de parâmetros. Se o proxy/servidor remover os parâmetros das duas variáveis antes do WordPress, o plugin não os pode reconstruir; esse limite precisa ser considerado nas sondas com query e na configuração de cache.


## Correções e serviços da 1.18

- `f3base/medicao-saude-ler`: leitura administrativa de últimos sete dias, endpoint e agenda; nenhuma sonda ou envio é disparado.
- `f3base/acessos-legado-ler`: `de`, `ate`, `pagina`; até 100 registros por página e próxima página. Conteúdo arquivado exige `manage_options` e não integra totais atuais.
- `f3base/medicao-anotacao-excluir`: `id` e `revisao` inteiros positivos, exclusão transacional e auditoria. Revisão divergente é recusada.
- `f3base_medicao_editorial.aplicar_anotacoes`: booleano, padrão `true`. Consultas editoriais e integradas aceitam `anotacoes:false` para comparação. Formulários, contatos e filas não são apagados ou bloqueados por esse filtro.
- `agentes-relatorio.grupo`: `identificados` (padrão), `genericos` ou `todos`. `incluir_tecnico:true` conserva seu escopo explícito. Automação genérica não comprova operador, finalidade nem ataque.
- `ia_fora_conteudo`: contagens separadas de descoberta e rotas sem identidade editorial. Não compõem `conteudos_ia` ou `requisicoes_ia` de conteúdo. Os caminhos continuam consultáveis em agentes-relatorio.
- P32 ignora ordem/duplicatas exclusivamente em `f3base_llms.tipos`. A comparação geral continua sensível à ordem.
- Markdown pendente: 503 e Retry-After apenas com tarefa agendada. Conversão avaliada e incompleta: 404 sem Retry-After, com link da alternativa HTML. Alterar conteúdo ou reprocessar permite nova avaliação.

Nos redirects nativos `redirect_canonical` e `old_slug_redirect_url`, só são repostos parâmetros publicitários/de atribuição reconhecidos pelo contrato. Argumentos consumidos deliberadamente pelo WordPress não são reinseridos. As regras explícitas do Core têm sua própria política `preservar_query`. Esta distinção complementa a ressalva QUERY_STRING acima.
