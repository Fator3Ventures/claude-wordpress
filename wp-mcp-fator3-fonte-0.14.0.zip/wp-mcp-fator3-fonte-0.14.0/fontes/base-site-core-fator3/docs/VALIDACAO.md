# Validação — F3 Base Core 1.18.0

Data: 30/09/2026. Contrato 4.2.0. Instalação nova ou atualização de **1.17.0 concluída**, com retomada na própria versão. Nenhum site de produção foi acessado ou alterado nesta implementação. **Korvena.net.br não foi testado.** Tema e implantador estão fora do escopo.

## Ambiente e resultados

Bancada isolada: WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, Chromium Headless 151 e Playwright. Dados sintéticos; e-mail bloqueado e transporte comercial interceptado. HTTP local com oito workers.

**486 asserções aprovadas**, mais dez etapas de instalação/atualização. Não são 486 cenários independentes. Evidências: `suite/versao-1180/evidencias/` no ZIP de fontes.

| Conjunto | Asserções | Evidência |
|---|---:|---|
| Regressões novas: identidade, arquivo, exclusões e origens | 54 | `revisao.json` |
| Navegação, consentimento, redes reais e permissões | 13 | `diagnosticos-1180.json` |
| Conteúdo, sessões, aquisição, referências IA e GSC | 65 | `editorial.json` |
| Rotas, coortes e histórico | 12 | `integridade.json` |
| Publicação independente, horas e agregados | 11 | `fronteiras.json` |
| Captura, contratos, navegação e segredos | 74 | `core.json` |
| Pipedrive com transporte simulado | 26 | `crm.json` |
| CAPI com transporte simulado | 10 | `capi.json` |
| Bordas de contratos e relatórios | 17 | `bordas.json` |
| Publicação LLMS | 23 | `llms.json` |
| Ofertas, atribuição e agentes | 37 | `novas.json` |
| Paginação de origens | 14 | `origens.json` |
| Concorrência e rotação de credenciais | 9 | `credenciais.json` |
| Volume, limites e orçamento de memória | 9 | `volume.json` |
| P00, mudanças, TTL e executor | 13 | `obrigatorios.json` |
| HTTP local, cache PHP e formulário sem JS | 23 | `http.json` |
| Markdown incompleto versus preparo, GET e HEAD | 8 | `http-1180.json` |
| Redirects e evidência pública local | 21 | `redirects-bordas.json` |
| Documentação instalada e contrato | 21 | `fechamento.json` |
| Telas, sessão, CSV, anotações, filtros, teclado e celular | 26 | `ux-editorial.json` |

Instalação, dados semeados, atualização, repetição e retomada foram verificadas para cada caminho: novo e 1.17.0 real. Baseline SHA-256: `8d352740d70f4d6861e19a0539accd98d0e9467afe89dd4c397c8c5b6c18eee7`. Preferências falsas, listas vazias, contatos, política e credenciais cifradas foram preservados. A nova preferência de anotações preenche somente chave ausente.

Sintaxe: 169 arquivos PHP (plugin e testes) e 22 arquivos JavaScript. Os sete assets minificados foram recompostos e conferidos com Terser fixado. O instalador é conferido byte a byte contra as fontes e contra o manifesto de SHA-256.

## Correções efetivamente verificadas

- Query de CPT não vira home; templates não participam do catálogo; aliases comprovadamente errados são invalidados em lotes retomáveis.
- Histórico sem ID cruza pelo caminho normalizado, conservando `post_id=0`. Descoberta não entra em requisições de conteúdo.
- Dia novo e horas são publicados apesar de fonte antiga perdida. Agregado antigo permanece no arquivo auditável; reentrada e retomada com estado anterior não rearquivam totais novos. Lacuna permanece explícita.
- OAuth/MCP operacional sai do recorte de conteúdo. Robôs genéricos ficam consultáveis em grupo separado.
- Exclusão anotada vem aplicada, aceita desligamento no relatório e no serviço, e alcança o relatório integrado. Exclusão da anotação exige revisão e permissão e deixa auditoria. Nenhum contato é apagado.
- P32 ignora ordem somente no conjunto `f3base_llms.tipos`; arrays ordenados gerais mantêm sua semântica. Navegação inline gera orientação; consentimento explicitamente gravado não recebe o alerta de ausência.
- HTTP real local: Markdown conhecido incompleto responde 404, sem Retry-After, com alternativa HTML; pendente responde 503 com Retry-After; HEAD não leva corpo e HTML permanece 200.
- Catálogo de origens respeita fronteiras de domínio e prioridade de mídia paga. Os quatro JSONs públicos adicionados passaram pelo parser real. Não é prova de identidade de uma requisição.

A interface foi percorrida em 1440 e 360 px, com inspeção visual das capturas. Foram verificados sessão e jornada, exportação, filtros, inclusão/edição/remoção de anotações, foco de teclado, ausência de overflow da página e erros JavaScript. Tabelas largas têm rolagem própria. Datas da bancada usam locale do navegador; resultados e exportação informam fuso/UTC.

## Alcance e pendências externas

Os testes não certificam a hospedagem, SMTP, contas comerciais ou visitantes reais. Mocks de Pipedrive/CAPI/ads não encerram a homologação externa. Search Console continua exigindo fotografia de fonte autorizada. Redes oficiais dependem de disponibilidade futura e de configuração explícita de confiança no IP original; essa confiança continua desligada por padrão.

Itens 50/86: conferir a cobertura e publicação com os arquivos realmente disponíveis na frota. Fontes já perdidas não são reconstruídas. Item 52: observação de sete dias até 05/10 é operacional e permanece aberta; não foi feita visita ao site para esse aceite. Itens 79/88: a bancada valida o produto, mas amostra real e uso na frota ainda precisam ser conferidos.

Item 38: **não houve nova rodada PSI/Lighthouse nesta entrega**. O transporte JavaScript e seu prazo de cinco segundos após load não foram alterados; adiar não garante ausência em toda janela de medição. Não há alegação de ganho de nota ou causalidade. O diagnóstico novo é administrativo e não adiciona script, beacon ou sonda HTTP ao visitante.

As assinaturas MistralAI-User, cohere-ai e YouBot foram nomeadas, mas mantidas genéricas por falta de confirmação primária suficiente de finalidade. Bytespider também não foi promovido automaticamente a treinamento. DNS reverso foi adiado: exige execução assíncrona, confiança no endereço e validação direta/reversa própria. Não deve ser colocado na leitura síncrona de logs.

Erros iniciais das fixtures HTTP (modo inválido, visibilidade e arquivo LLMS concorrente da bancada) foram corrigidos antes dos resultados finais. A aplicação não foi alterada para contornar os contratos dessas fixtures. O percurso de jornada passou a aguardar explicitamente a URL e o cabeçalho da página antes de validar, corrigindo a corrida do teste durante navegação. Fontes públicas consultadas, hashes e limites estão em `fontes-publicas.json`; não se distribuem cópias integrais de páginas de terceiros.
