<?php
/** Contratos da 1.18: preferências explícitas e serviços de medição editorial. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Release_1180 {
    public static function iniciar(): void {
        F3Base_Medicao_Editorial_UI::iniciar();F3Base_Editorial::iniciar();F3Base_Inteligencia::iniciar();F3Base_Redes_Robos::iniciar();
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('acessos-legado-ler','Consultar agregados arquivados fora dos totais atuais',array(F3Base_Acessos_Legado::class,'consultar'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>10000)));
            F3Base_Servicos::ability('medicao-saude-ler','Diagnóstico da coleta e lacunas observadas',array(F3Base_Medicao_Saude::class,'consultar'));
            F3Base_Servicos::ability('llms-reprocessar','Reprocessar manualmente a geração editorial',static fn()=>F3Base_Llms_Cobertura::executar(5,true),array(),array(),false);
            foreach(array('conteudos-relatorio'=>'conteudo','sessoes-listar'=>'sessoes','sessao-detalhar'=>'sessao','aquisicao-relatorio'=>'aquisicao') as $nome=>$visao){$schema=F3Base_Editorial_Relatorios::schema();unset($schema['visao']);F3Base_Servicos::ability($nome,'Medição editorial: '.$visao,static fn($e)=>F3Base_Editorial_Relatorios::consultar(array_merge($e,array('visao'=>$visao))),$schema,$visao==='sessao'?array('sessao'):array());}
            F3Base_Servicos::ability('medicao-editorial','Conteúdo, aquisição e sessões observadas',array(F3Base_Editorial_Relatorios::class,'consultar'),F3Base_Editorial_Relatorios::schema());
        });
    }
    public static function catalogo(array $c): array {
        $p=array('retencao_meses'=>13,'excluir_automacao'=>true,'aplicar_anotacoes'=>true,'redes_oficiais'=>true,'ip_log_confiavel'=>false);
        $campos=array(
            'retencao_meses'=>array('tipo'=>'inteiro','rotulo'=>'Meses de agregados editoriais','descricao'=>'Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.'),
            'excluir_automacao'=>array('tipo'=>'booleano','rotulo'=>'Excluir automação da audiência','descricao'=>'Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.'),
            'aplicar_anotacoes'=>array('tipo'=>'booleano','rotulo'=>'Aplicar exclusões de períodos anotados','descricao'=>'Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.'),
            'redes_oficiais'=>array('tipo'=>'booleano','rotulo'=>'Conferir listas oficiais dos robôs','descricao'=>'Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.'),
            'ip_log_confiavel'=>array('tipo'=>'booleano','rotulo'=>'Log contém o IP de origem confiável','descricao'=>'Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.')
        );
        foreach($campos as &$d){$d['impacto']=$d['descricao'];$d['exemplo']=$d['descricao'];}unset($d);
        $c['f3base_medicao_editorial']=array('rotulo'=>'Conteúdo, audiência e IA','descricao'=>'Retenção e qualidade dos relatórios editoriais.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'grupo','padrao'=>$p,'subcampos'=>$campos,'sanitiza'=>array(F3Base_Evolucao::class,'sanitizar'),'recusa'=>static function($v,$d){$r=F3Base_Evolucao::recusar($v,$d);if($r){return $r;}return isset($v['retencao_meses'])&&(!is_int($v['retencao_meses'])||$v['retencao_meses']<1||$v['retencao_meses']>25)?'Informe de 1 a 25 meses.':'';});
        foreach(array('f3base_editorial_estado','f3base_redes_robos','f3base_nav_prova','f3base_logs_1170') as $n){$c[$n]=array('rotulo'=>$n,'descricao'=>'Estado técnico; não é preferência.','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));}
        $c['f3base_consentimento']['padrao']['painel']='padrao';
        $c['f3base_consentimento']['subcampos']['painel']=array('tipo'=>'enum','rotulo'=>'Apresentação do painel de consentimento','opcoes'=>array('padrao'=>'Padrão do plugin','tema'=>'Estilo fornecido pelo tema'),'descricao'=>'Padrão oferece estilos completos. Tema herda o desenho do site: exige CSS, contraste, foco e navegação por teclado adequados.','impacto'=>'O modo tema não muda consentimento nem categorias.','exemplo'=>'Use tema apenas com estilos conferidos em celular e teclado.');
        if(isset($c['f3base_consentimento']['schema_config']['properties'])){$c['f3base_consentimento']['schema_config']['properties']['painel']=array('type'=>'string','enum'=>array('padrao','tema'),'default'=>'padrao');}
        return $c;
    }
    /** Mescla somente propriedades ausentes. Listas e valores explicitamente falsos são atômicos. */
    public static function completar($atual,$padrao){
        if(!is_array($atual)||!is_array($padrao)||array_is_list($padrao)){return $atual;}
        foreach($padrao as $k=>$v){if(!array_key_exists($k,$atual)){$atual[$k]=$v;}else{$atual[$k]=self::completar($atual[$k],$v);}}return $atual;
    }
    public static function materializar_padroes(): array {
        $alteradas=array();$preservadas=array();foreach(F3Base_Options::catalogo() as $n=>$d){
            if(empty($d['operavel'])||!empty($d['estado_execucao'])||!empty($d['derivada'])||F3Base_Options::e_segredo($n)||!array_key_exists('padrao',$d)){continue;}
            $f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return array('ok'=>false,'codigo'=>'padroes_leitura_falhou','nome'=>$n);}
            $v=$f['existe']?self::completar($f['valor'],$d['padrao']):$d['padrao'];
            if($f['existe']&&$v===$f['valor']){continue;}
            $r=F3Base_Options::gravar($n,$v,F3Base_Options::ORIGEM_PADRAO,$f['revisao']);
            if(empty($r['persisted'])&&$f['existe']&&($r['codigo']??'')==='valor_recusado'){$preservadas[$n]='Configuracao existente fora do contrato; preservada sem mesclar defaults. Corrija explicitamente no painel.';continue;}
            if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'padroes_pendentes','nome'=>$n,'motivo'=>$r['motivo']??$r['codigo']??'');}$alteradas[]=$n;
        }return array('ok'=>true,'alteradas'=>$alteradas,'preservadas_com_diagnostico'=>$preservadas);
    }
}
