# Conteúdo/SEO — 0.14.0

O contrato efetivo está em `OPERACAO.md` e nos schemas `content/*` de `CONTRATOS-INSTALADOS.json`. Preservados: revisão/hash, readback, aliases de parent, proteção de blocos com filhos e imagem destacada durante salvamento. A suíte de integração com Yoast/Elementor usa plugins reais no laboratório; isso não comprova o comportamento dos templates/cache da frota.
