# WP MCP Fator3 — revisão técnica e plano da 0.14.0

Data: 01/10/2026. Revisão: **2**, reconciliada com a lista completa enviada nesta data. Estado: planejamento, com reprodução local de defeitos; implementação da 0.14.0 ainda não iniciada. Versão alvo proposta: **0.14.0**, pela ampliação de contratos e pela mudança de política administrativa. Entrega única com os **33 itens ativos da lista de frota: 1–15 e 17–34**, preservando as funcionalidades anteriores e concluindo as ampliações 25–34. O item 16 continua retirado; 35 é apenas o próximo número disponível. Sem releases intermediárias planejadas.

## 1. Base, fontes e limites da análise

- Entrada principal desta revisão: `Pedidos ao pacote MCP(1).md`, recebida em 01/10/2026, com 33 itens ativos e registros até 30/09. Cópia integral, sem alterações: `PEDIDOS-MCP-RECEBIDO-2026-10-01.md`. Complemento: `Pendências do canal wp-mcp-fator3 após a 0.13.0.md`. A numeração original será preservada nos testes e no relatório de entrega, sem renumerar os IDs históricos F/N/O/E.
- Base examinada: instalador 0.13.0 de homologação entregue nesta conversa, SHA-256 `6236bd8e5a2efe4c959945a5b812421cd7f98ab6c7ad019f58baf7127d155039`. A revisão não altera esse instalador nem converte sua homologação pendente em aprovação.
- O relatório anterior declarava equivalência à revisão 42. Agora há uma cópia completa fornecida pelo usuário, que prevalece como entrada documental desta rodada. Ela não informa número de revisão; não atribuir a ela uma revisão remota não conferida. A cópia de 29/09 continua como histórico. O documento original recebido permanece intacto e nenhum item foi retirado da lista de frota.
- Os dois relatos situam o piloto na 0.13.0 e os outros 13 sites na 0.12.1. A lista completa cita Core 1.18.0 e Google 0.5.0 nos pedidos de integração; o relatório anterior citava Google 0.4.0 no piloto. Registrar essa diferença por site e data na homologação, sem presumir atualização nem fazer downgrade. Não houve nova consulta aos sites nesta rodada.
- Laboratório desta revisão: WordPress 7.1.2, PHP 8.3.30, MySQL 8.0.46, HTTP PHP local, instalação descartável a partir dos ZIPs entregues. Nenhuma operação na frota.
- Core 1.17.1 e Google 0.4.1, presentes no bundle anterior, não serão distribuídos como substitutos de versões mais novas. A entrega MCP terá instalador próprio; complementos só entram como pacotes coordenados quando partirem de seus fontes atuais.

## 2. Resultado da verificação

| Item | Conclusão | Evidência e implicação |
| --- | --- | --- |
| 25 | Pedidos de migração, escopos, erros, descoberta e refresh procedem no fonte | `ConnectionContext`, OAuth e transporte precisam compartilhar o mesmo contrato efetivo. Checar requisitos antes da exclusão exige código executado pela versão antiga ou por um componente independente. |
| 26 | A política atual restringe Manutenção; a mudança pedida é uma decisão de produto | Raízes, escrita SQL, exportação e catálogo são avaliados em pontos diferentes. O perfil pleno exige revisão central e dos serviços, não apenas mudança na tela. |
| 28 | Defeito de agregação reproduzido | `COUNT(*)`, `COUNT(ID)` com GROUP BY e `SUM(ID)` funcionam no SQL original e falham depois de `SqlReadPolicy::validate`. `LOWER()` funciona nos dois. A afirmação de que toda função falha é excessiva. |
| 27 | Exposição reproduzida | Os seis documentos citados responderam HTTP 200 sem cookies. `index.php` não protege URLs de arquivos existentes. |
| 29 | Lacuna real de volume/gramática e contexto da redação | Leitura comum limitada a 2.000 linhas; exportação consistente e assíncrona exige serviço próprio. |
| 30 | Pedido parcialmente descrito como ausência total | Já há `SqlSelection` para um INNER JOIN por igualdade ou uma subconsulta IN, com um alvo. Ambas geraram prévia válida no laboratório. Múltiplos alvos, DDL, INSERT SELECT, upsert, lote e dump/restore continuam como ampliação. |
| 31 | Proteção de options e ausência das operações administrativas tipadas confirmadas | `plugins/cleanup-orphaned-uninstall` já existe; a operação geral de configuração e as demais rotas precisam ser adicionadas. |
| 32 | Novas rotas necessárias | O diagnóstico cron existente não fornece execução, agenda, remoção de transient ou flush do cache de objeto. |
| 33 | Temas/ZIP/limite são ampliações; move/copy já existem | `FileTools::register()` registra dinamicamente `files/copy` e `files/move`; ambas executaram com sucesso. Conferir catálogo, perfil e hash no piloto antes de atribuir sua ausência ao registro. |
| 34 | Novas rotas e correção de apresentação necessárias | Reutilizar o serviço de gestão de conexões, com controle de concorrência e proteção da própria identidade. |

A suíte anterior verificava rejeições SQL e um SELECT simples; seus usos de COUNT para conferir resultados passavam diretamente por `$wpdb`. Isso explica a lacuna de cobertura: os testes não exercitavam a agregação através de `db/query`. A aprovação dos 28 comandos anteriores não demonstrou esse contrato.

A reprodução de sessão usa uma proposta antiga armazenada `2025-11-25` e o cabeçalho `2025-06-18`, correspondente à resposta antiga relatada. O importador conserva a proposta e o validador volta a negociar a partir dela. O teste é sintético e não reproduz a jornada do cliente Claude em produção.

Evidência detalhada: `reproducao-0.13.0.json`; script: `reproduce-report.php`. São registros de diagnóstico da base, não testes de aprovação da versão futura.

### 2.1. Reconciliação da lista completa recebida em 01/10

Os itens 25–34 confirmam o escopo já planejado. Nos itens anteriores, a nova cópia consolida redação e evidências: o pedido de `grep_regex`, antes anexado ao item 19, está corretamente no 18; as projeções e revisões permanecem em 22/23. A revisão 2 torna explícita a cobertura dos itens anteriores na entrega final, sem tratar funcionalidades existentes como desenvolvimento novo.

Conferência estática adicional, contra arquivos idênticos no fonte e no ZIP 0.13.0 identificado acima:

| Item | O que já está no pacote examinado | Tratamento na 0.14.0 |
| --- | --- | --- |
| 7 | `SystemTools.php` expõe `include_legacy`; `Retention.php` monta seleção congelada e valida pares legados. | Preservar e testar pelo MCP, inclusive retomada e conflito. Não anunciar como nova implementação. |
| 11 | `PackageService::delete()` confirma a ausência física antes de `cleanup_auto_update()`; há estado de limpeza pendente. | Preservar e testar remoção exata, concorrência e falha de persistência. Não repetir uninstall para tentar apenas a limpeza. |
| 18 | `FileTools.php` registra `grep_regex` e aceita arquivo regular ou diretório. | Preservar e conferir schema, descrição, erro PCRE e execução pela conexão real. |

A inspeção estática não é uma nova execução de testes nem comprova o catálogo exposto no piloto. `conferencia-documental-2026-10-01.json` registra hashes e alcance. As medições de `reproducao-0.13.0.json` permanecem as da revisão anterior.

**Correção da premissa do item 2:** `Update URI: false` não equivale à ausência do cabeçalho: o mecanismo nativo do WordPress já impede a oferta homônima do wordpress.org nesse caso. Isso não implementa feed próprio, autenticação de origem, hash ou recuperação. Preservar a decisão do dono de manter os três pacotes fora da atualização automática até homologação e decisão posterior; corrigir a justificativa no manual. Referência oficial na seção 8.

### 2.2. Aceite dos itens anteriores preservados

Esta matriz é a referência dos contratos 1–24 na 0.14.0 e liga cada pedido aos IDs históricos de `ESPECIFICACOES.md`. A inspeção de código relatada no anexo indica cobertura da maior parte na 0.13.0; **nenhuma linha abaixo significa homologação no piloto**. Cada linha exige resultado observado no pacote final. Conflitos entre especificações antigas e decisões novas seguem a seção 3 e os itens 25–34; o histórico não pode restabelecer bloqueios rejeitados pelo dono.

| Pedido | IDs históricos | Critério de aceite na entrega única |
| --- | --- | --- |
| 1 | F08, O12 | Upload URL/base64 com hash/slug, pré-imagem recuperável, versões/ativação antes e depois; omissão de `activate` equivale a false; home/REST anônimos e reversão comprovada. Auto-upload segue 25/26. |
| 2 | O14 | Manifesto real por pacote, `Update URI` e handler do host coerentes; verificar SHA-256/requisitos/oferta nativa, sem homônimo nem downgrade. Autoatualização continua desligada por decisão do dono. Coordenação usa fontes atuais Core/Google, não os complementos antigos do bundle. |
| 3 | O13, O17 | Sonda anônima única com método, cabeçalhos, asserções por status/corpo/cabeçalho/hash e resultado por asserção; `http_protection_tested` com evidência. Medir tempo e sinais de cache, sem chamar todo TTFB de tempo de geração PHP nem inferir cache frio sem prova. |
| 4 | F11 | Conflito de revisão, unicidade, `limit` literal/regex, motivo de padrão inválido, readback SHA-256/CHAR_LENGTH e barras preservadas; transformação observada sinaliza `content_filtered`. Não atribuir causa à perda não reproduzida. |
| 5 | O15 | `if_catalog_sha256` responde `unchanged` somente para catálogo efetivo equivalente; `plugins/list` respeita `campos`/`prefixo` e conflitos de aliases. Cache varia conforme perfil/política. |
| 6 | F09 | Leitura integral binária em base64 e roundtrip byte a byte; texto em extensão binária é recusado. Regressão inclui o tamanho do incidente e hashes. |
| 7 | O16, O08 | Rótulo nas quatro mutações, filtros de rótulo/data, inclusão explícita de legados na retenção, prévia e seleção congelada; pares ausentes/alterados ou referenciados não são removidos silenciosamente. |
| 8 | O18 | `contar:true` retorna `rows_exact` junto da estimativa, sem rotular a estimativa como contagem; tempo limite retorna estado identificável. |
| 9 | E06, E07 | Regenerar mídia e definir ícone pelas APIs nativas, conferir recortes/metadados/option e resultado público. Não criar mu-plugin descartável para operar a mídia. |
| 10 | O20 | Plano de operações admite upload com precondições e recuperação de 1; SQL permanece fora. Simulação não instala nada e repetição não duplica efeitos. |
| 11 | F15, F22, F23, C06, O17 | Versão conhecida por provedor, sem inventar versão desconhecida; cron com os três campos pedidos; lock de 2 s documentado; `parent`/`parent_id` com alias e recusa de conflito; seleção JOIN/IN existente preservada; excluir plugin limpa só sua entrada em auto-update. Ampliação SQL em 30. |
| 12 | F14, O12 | Plugin ativo permanece ativo após update, com estados antes/depois, requisição nova para ativação e sonda/reversão na mesma operação. Reproduzir incidente Yoast com fixture e verificar sitemap/metadados. Ambiente de aceite single-site; não criar matriz multisite. |
| 13 | N01 | `offset_bytes` inicia leitura arbitrária, preservando bytes/hash e sem exigir percorrer prefixo; cursor opaco continua válido e combinações conflitantes têm erro claro. |
| 14 | N02 | Atualizar permalink/category/tag ou chamar `rewrite/flush` regenera por APIs nativas com flush soft, contagem e regras antes/depois; não exige SQL. |
| 15 | F16 | Sete recursos Elementor com URI/mimeType aninhados acessíveis; formato legado preservado; recurso inválido gera diagnóstico uma vez por catálogo, inclusive com concorrência. |
| 17 | F17 | `inner_html` em bloco com filhos não os descarta silenciosamente; `children` é o contrato para substituí-los, com prévia/readback e descrição coerentes. |
| 18 | F19, F13, N03 | Arquivo único/diretório e PCRE em busca, limites e erro útil; armazenamento privado explica acesso por serviços e diagnóstico em `system/health`; limpeza tipada de uninstall órfão. `angie_snippet` continua alvo a inventariar/confirmar, sem limpeza automática na instalação. |
| 19 | F18 | Segredos redigidos em prévia/resultado/log/replay de SQL, com `redacted`; backup privado conserva pré-imagem integral para restauração e isso é documentado. Redação contextual ampliada em 29. |
| 20 | F20, O13 | PHP carregado pelo site tem baseline/sonda e restauração após fatal; falta de sintaxe não é teste de execução. Exceção explícita `probe:false` de Manutenção segue 26, sem retirar a proteção padrão. |
| 21 | F21 | `featured_media` efetivo durante hooks de salvamento e revisão final lida após todas as gravações; conferir `og:image` com Yoast sem segunda chamada do agente. |
| 22 | N04 | `get-revision` permite projeção sem conteúdo e SHA-256/CHAR_LENGTH; `list-revisions` inclui hash; omissão de `fields` conserva resposta legada. |
| 23 | N04, N05, N06 | `get-page/get-post` com `fields`, listas com revisão atual, `options/get` com chave literal e distinção de null/ausente, leitura gzip com grep/PCRE sob limite de saída/expansão. |
| 24 | N07, N08, E01 | Excluir menu clássico e options por APIs nativas, prévia/backup e invalidação de cache. Manutenção pode usar `confirm:true` conforme 26 para exclusões tipadas; SQL segue duas fases. Metadados `_twinia_*` só saem após seleção e decisão próprias, sem limpeza de frota pela instalação. |

Para cada pedido, o relatório final registra: versão/hash, cenário, resultado esperado e observado, arquivo de evidência, estado local e estado no piloto. Só a sessão que realizar a conferência no piloto retira o item da lista oficial, citando o registro da rodada. Este plano não executa essa retirada.

## 3. Decisões que substituem o plano anterior

1. **Manutenção pleno.** Credenciais válidas herdadas da 0.12.1, sem escolha explícita de um perfil restrito, recebem Manutenção sem prazo de política. Identidades automaticamente convertidas em Legado pela 0.13.0 também são migradas. A migração não reativa credenciais revogadas nem tokens tecnicamente expirados. Perfis Leitura, Conteúdo e Personalizado escolhidos explicitamente permanecem restritos.
2. **Um usuário de hospedagem por site.** Manutenção alcança os caminhos permitidos ao processo PHP e ao ambiente. Não exige raízes por conexão, marca adicional de escrita SQL ou permissões adicionais de exportação de backups. Capacidades nativas do usuário WordPress e restrições efetivas do sistema operacional continuam observadas.
3. **Administração por MCP.** Gestão de identidades, ajustes do canal, atualizações, banco e arquivos deve ser operável pelo próprio canal. A instalação inicial não dependerá de edição manual de arquivos nem de alteração de configuração da DreamHost.
4. **Risco administrativo aceito.** Manutenção pode instalar código e administrar o banco. Redação reduz exposição acidental na resposta; não será apresentada como isolamento de segredos contra esse administrador.
5. **Exceções intencionais.** `probe:false` para gravação PHP e `confirm:true` para exclusões tipadas ficam explícitos e auditados. `db/execute`, DDL, restauração, lotes SQL e alteração que reduza o acesso da própria conexão conservam duas fases. Não haverá rota de PHP, de frota ou executor aninhado.
6. **Elementor preservado.** Não remover seu servidor nem decorar indiscriminadamente suas habilidades. Para Manutenção, a adesão do provedor não é condição para executar uma habilidade pública autorizada pelo WordPress. Para os perfis restritos, descoberta e execução exigem a mesma classificação confiável.
7. **Documentação corrente separada do plano.** `OPERACAO` descreve somente o runtime efetivo. Este documento concentra as mudanças futuras; o manual instalado não recebe promessas de implementação.

O item 26 b é mais específico que o aviso/prorrogação do Legado pedido em 25 b: a janela automática de sete dias deixa de valer para essas credenciais migradas. Não serão implementadas simultaneamente políticas contraditórias de expiração e acesso permanente. Isso não elimina expiração e rotação normal de tokens OAuth.

## 4. Contratos de implantação por item

### 25 — Entrada da versão e integridade dos contratos

**Migração pelo canal antigo.** Não é possível corrigir retroativamente o `plugins/upload` já carregado da 0.12.1 apenas incluindo uma verificação no pacote novo: sua pasta já terá sido apagada quando esse código executar. A solução planejada é um componente de migração distribuído e testado junto da entrega única, instalado como plugin separado pelo canal antigo. Ele não constitui uma release intermediária do MCP nem um remendo montado no site.

Fluxo do componente:

1. Receber URL/ZIP, SHA-256, slug, entrypoint, versão esperada e identificação da base.
2. Conferir WordPress/PHP, permissões, espaço, pacote completo, capacidade de recuperação e conflito de versão **antes** de alterar a pasta ativa.
3. Preparar pré-imagem e diário fora da árvore substituída; manter executor e recuperação disponíveis sem autoload de arquivos novos no processo antigo.
4. Aplicar a troca preparada, ativar em requisição nova e verificar canal/home/REST. Preservar credenciais e executar migração idempotente de política.
5. Em falha, restaurar a base e seu estado de ativação; registrar resultado recuperado ou inconclusivo. Não repetir automaticamente hooks com efeitos incertos.
6. Concluir e retirar/desativar o componente transitório apenas sem diário pendente. Não remover a sentinela de recuperação necessária às próximas atualizações.

Gate específico: 0.12.1 → 0.14.0 e 0.13.0 → 0.14.0, nas duas URLs MCP, sem intervenção no painel; requisitos incompatíveis deixam a pasta antiga byte a byte intacta. SIGKILL entre renames, fatal na ativação e resposta perdida precisam de ensaio. Não anunciar ausência total de interrupção de requisições em voo.

**OAuth:** interpretar scope como lista de tokens separados por espaço, normalizar repetidos, recusar desconhecidos e registrar o conjunto concedido. Múltiplos escopos solicitados não escolhem Manutenção sozinhos: o consentimento explicita o perfil escolhido dentro do alcance solicitado e das capacidades do usuário. Manutenção fica selecionável para administrador.

**Refresh:** ao converter `legacy-oauth` para `grant`, copiar a política efetiva e ajustes, com lock/transação e precedência da configuração explícita. Registrar a origem e evitar concessões duplicadas em refresh concorrente. Revogar a identidade legada já substituída não revoga implicitamente o grant independente criado e validado, conforme o aceite 34.

**Erros:** `ToolsHandler`, executor e Result devem conservar `error_code`, `data`, `operation_id`, conflito, possibilidade de repetição e estado do efeito. Erros de tool levam `isError:true` e conteúdo estruturado compatível com a revisão MCP negociada. Redigir segredos em `data`; não substituí-la inteira por uma frase. Testar WP_Error, falha em array, falha de permissão e exceção após efeito pelo HTTP MCP.

**Descoberta:** uma única função de elegibilidade deve servir discovery, Get Ability Info, guia e executores. Sem parâmetros, informar `requires_input` para permissões dependentes do alvo. Para Leitura, não listar como executável um provedor recusado por falta de contrato. Cache do catálogo inclui credencial/política/provedores.

### 26 — Paridade de Manutenção

- Centralizar direitos efetivos do perfil. Remover exigências redundantes de raízes, `database_write`, exportação própria/estrangeira e prazo automático para Manutenção; refletir os valores efetivos em capabilities e na interface. Atribuição de perfil não concede capacidades WordPress inexistentes.
- Sessões importadas não podem renegociar a versão a partir da proposta como se fosse a resposta antiga. Persistir a versão efetivamente negociada em sessões novas. Para sessões importadas sem prova dessa versão, responder 404 na rota Fator3 e permitir reinicialização automática. Preservar a credencial e não apagar o armazenamento/sessões do servidor Elementor. Não converter toda falha de cabeçalho em 404.
- `db/query` de Manutenção admite tabelas e views do banco do site, sem filtro PHP adicional para `f3base_*`, Google, Yoast, metadados, options e usuários. Admite JOIN, subconsulta, UNION e metadados pertinentes em `information_schema`. O restante da gramática está em 29. Não haverá liberação de DML por uma rota anunciada como leitura.
- `options/update` permite `auto_update_plugins` e valores antes bloqueados somente por classificação de segredo. A ampliação do item 31 governa a lista final; segredo pode ser gravado, mas é redigido em prévias/resultados/logs.
- `plugins/upload`/base64 do próprio MCP passam pelo mesmo staging, preload, diário, recuperação e verificação usados em `plugins/update`. Não dependem de feed para uma atualização explicitamente enviada. `expected_sha256`, `expected_slug`, versão/ativação antes/depois e backup permanecem.
- `probe:false` em gravações PHP de Manutenção pula baseline e sondas de execução, mantendo validação de sintaxe, lock, pré-condição, pré-imagem e escrita atômica. Resposta e auditoria registram `probe_tested:false` e motivo explícito. A sentinela não pode interpretar uma operação concluída sem sonda como abandonada e revertê-la posteriormente.
- `confirm:true` permite exclusão tipada na mesma chamada para Manutenção. A seleção e a pré-imagem são calculadas sob lock nessa chamada. Não equivale a um token genérico, não dispensa hash/revisão fornecidos e não se estende a SQL ou autorrestrição de conexão.

Aceite: credencial herdada válida continua em Manutenção após D+8 simulado; nenhum ajuste manual na tela. Renovação OAuth, catálogo de complementos, arquivos, options, SQL e autoatualização pelo conector aberto verificados. Reinicialização automática de sessão não exige recriar/autorizá-lo novamente.

### 28 — Agregações SQL e diagnóstico

- Preservar os bytes da instrução validada sempre que nenhuma transformação for necessária. Em reescrita de projeção/LIMIT, utilizar posições do scanner ou emissor de tokens que una função e `(` sem alterar literais. Não aplicar regex global sobre strings SQL nem mudar o `sql_mode` da hospedagem para encobrir o defeito.
- Testar pela rota `db/query`: COUNT(*), COUNT(ID), COUNT DISTINCT, SUM, AVG, MIN, MAX, GROUP BY/HAVING, funções aninhadas, aliases e literais com parênteses. Executar sem IGNORE_SPACE.
- Toda linha de diagnóstico terá código estável, componente/método e correlação quando disponíveis. Ausência de contexto conhecido usa código de fallback identificável, sem inventar causa. Não registrar SQL, token ou texto de exceção arbitrário.

Aceite: comparação com SQL direto no banco sintético e consultas originais do relato no piloto. A coleta de log verifica presença do código e ausência de valores secretos.

### 27 — Documentação disponível apenas pelo canal autorizado

- Retirar do instalador os seis caminhos citados e o catálogo JSON bruto de documentação. Mantê-los no pacote fonte/documentação externa da release.
- Gerar a ajuda embarcada a partir da fonte canônica em recurso PHP protegido por ABSPATH; `system/guide` e wp-admin leem esse recurso. Não remover a ajuda nem depender de `.htaccess` da hospedagem.
- Atualização também elimina arquivos documentais residuais da versão anterior, com inventário e recuperação do pacote. Não executar limpeza genérica fora da própria árvore.
- Conferir HTTP anônimo dos caminhos exatos após instalação nova e atualização: 404. Conferir guia autenticado, versão, hash e conteúdo; contrato consultável por habilidade e perfil.

Publicação de manual público separado é uma decisão editorial independente. Os arquivos citados não contêm necessariamente segredos, mas o requisito de entrega determina sua indisponibilidade nessas URLs.

### 29 — Consulta, exportação e redação

**Leitura:** ampliar a análise MySQL para SELECT e WITH terminando em SELECT, funções de janela, CASE, CAST, JSON_EXTRACT/JSON_UNQUOTE, GROUP_CONCAT, REGEXP e funções de data. Conservar instrução única; tratar comentários/literais/identificadores de modo consistente com o modo SQL. Nenhuma CTE termina em mutação por `db/query`. Saídas binárias preservam bytes com identificação explícita da codificação.

**Volume:** criar exportação de resultado por operação, em CSV ou JSONL, com gzip opcional e leitura em partes. Devolver `operation_id`, estado, contagem, bytes, digest do conteúdo final e digest/offset de cada parte. O limite de 2.000 linhas da resposta interativa não se aplica ao arquivo; permanecem limites declarados de espaço e recursos do servidor, com falha explícita sem apresentar arquivo incompleto como concluído.

**Consistência:** materializar um resultado imutável sob snapshot verificável antes de oferecer suas páginas/partes como exportação concluída. Cursor por chave exige chave e ordenação únicas, inclusive desempate. Cursor isolado sobre tabelas mudando não comprova snapshot; distinguir esses modos na resposta. Para comparar com COUNT, usar a mesma seleção/snapshot ou uma fixture estável.

**Assíncrono:** worker interno com lease, checkpoint, estado e prazo efetivo, consultável por `operations/status`. Disparo por loopback/agenda WordPress, com retomada limitada pelas garantias da consulta. Sem daemon ou configuração adicional na hospedagem. Snapshot de conexão encerrada não pode ser retomado como se fosse o mesmo: reiniciar com nova identidade de exportação e indicar o motivo. Requisição longa continua sujeita aos limites PHP/servidor; nenhuma promessa de tempo ilimitado.

**Redação:** usar origem de coluna, chave projetada e predicado exato comprovado da mesma tabela. `WHERE meta_key='x'` só classifica `meta_value` quando o predicado determina a chave de todas as linhas; OR, JOIN, alias ou expressão ambígua não autorizam essa inferência. `redacted` informa célula, razão e origem/ambiguidade sem revelar o valor. Não anunciar impossibilidade de inferência de segredos por SQL arbitrário sob Manutenção.

Aceite: mais de 2.000 registros, escrita concorrente durante exportação, leitura integral por partes, hash/contagem, cancelamento e expiração; fixture das estruturas Core/Google atuais; CTE/CASE e funções pedidas; falso positivo da chave não secreta e alias de chave secreta.

### 30 — DDL, mutações complexas, transações e restauração

Todas as operações desta seção mantêm prévia e `confirm_token` vinculados à conexão, intenção, schema e seleção. Continuam fora de `operations/plan`; `operations/status` pode acompanhar um job SQL próprio sem transformar o plano em executor SQL.

**30 a — DDL recuperável:** estender o serviço de banco para CREATE/ALTER/DROP/TRUNCATE/RENAME de tabelas e índices do banco do site. Antes da alteração, registrar existência anterior, SHOW CREATE, dados, índices, dependências e hashes. CREATE registra pré-estado ausente. DROP/TRUNCATE/ALTER destrutivo exigem cópia íntegra restaurável e espaço verificado. Recuperação identifica mudanças concorrentes antes de substituir uma tabela.

**30 b — DML complexo:** ampliar a seleção existente para múltiplos alvos de UPDATE/DELETE com JOIN, INSERT SELECT e ON DUPLICATE KEY UPDATE. A prévia enumera cada tabela e efeito; confirmação congela/revalida alvos e fontes, mantém pré-imagem e verifica o resultado. Cobrir duplicidade em JOIN, chaves compostas, valores calculados, colisões de índice único, cascatas e triggers. Efeitos não capturáveis não recebem garantia de restauração integral.

**30 c — Lote transacional:** rota de lote tipado de instruções DML em uma conexão InnoDB fixada. Validar todas antes da execução; primeira falha causa rollback integral. DDL e instruções com commit implícito são recusadas nesse lote antes da primeira escrita. DDL terá recuperação por cópia, separada da transação DML. No laboratório, UPDATE seguido de ALTER e ROLLBACK preservou tanto a atualização quanto a coluna nova: não existe rollback transacional para esse lote misto.

**30 d — Exportar/restaurar:** `db/export` de tabelas escolhidas ou do banco completo, SQL gzip no armazenamento privado, sem shell nem exigência de mysqldump na hospedagem. Manifesto relaciona schema, tabelas, charset, engine, objetos exportados, contagens e hashes. A restauração aceita artefato verificado, com prévia do destino e cópia anterior; preserva um controlador e diário fora do banco afetado. A restauração do próprio estado MCP precisa reconciliar identidade corrente, consumo de operações e revogações antes de liberar o canal, evitando reativação silenciosa de tokens revogados. Triggers/views e ordem de dependências devem estar explícitos no manifesto; dump sem esses objetos não é rotulado como cópia completa.

**30 e — Troca serializada:** rota `db/search-replace` com simulação, colunas/tabelas, contagem, amostras redigidas e confirmação. Recursão preserva tipos e comprimentos de strings serializadas/JSON; não usa substituição crua de SQL sobre valores serializados. Não instancia classes de objetos PHP durante a análise. Valores não suportados são apontados com tabela/coluna/chave, sem alteração parcial silenciosa. Usa lotes, backups e comparação de pré-imagem; uma operação com vários commits informa sua atomicidade real.

Aceite: ciclo criar/alterar/renomear/truncar/apagar/restaurar; JOIN multialvo; colisão em upsert; erro na segunda instrução de lote; dump com bytes binários/NULL/Unicode; restore verificado; URL em estruturas aninhadas; processo interrompido e retomada sem duplicar efeito. Não testar em dados da frota.

### 31 — Administração do WordPress

- Em Manutenção, remover a proibição genérica de options fora da família interna do canal; preservar o controle de `f3_mcp_*` e seus registros internos equivalentes por serviços próprios. Backup, readback e auditoria valem para toda gravação. Escopo da sonda e reversão devem constar no resultado.
- `auto_update_plugins`, registro de uninstall e opções de estado usam APIs WordPress e atualização de cache. Limpar entrada não executa seu callback. Cron, papéis, tema e endereço usam serviços tipados quando houver efeito colateral. `options/update` deve encaminhar ao mesmo serviço quando os dados fornecidos forem suficientes; quando faltar informação indispensável, devolver o contrato exigido e a rota correspondente, sem conservar a recusa genérica de option protegida para Manutenção.
- Endereço `home`/`siteurl`: prévia da troca, combinação com search-replace serializado, URL de retorno e reversão fora da URL substituída. Mudança de domínio pode exigir DNS/TLS que o plugin não controla; o pacote valida disponibilidade antes e não promete criar infraestrutura externa.
- E-mail administrativo: gravar pelo fluxo autorizado solicitado, sem depender de link de confirmação; limpar estado pendente correspondente e conferir valor efetivo. Não prometer entrega de e-mails como consequência do readback.
- Idioma: verificar/instalar pacote oficial compatível antes de atualizar WPLANG; erro mantém o idioma anterior.
- Papéis/capacidades: APIs nativas, backup e controle de revisão. Se a alteração reduzir as capacidades da própria identidade administradora, aplicar a mesma confirmação forte do item 34.

Aceite: admin_email, WPLANG, papel sintético, auto_update_plugins e entrada órfã de uninstall; callbacks/cache e resposta; options internas continuam com orientação para a rota própria.

### 32 — Cron, transients e cache de objeto

- `cron/list`: identidade por hook, timestamp e argumentos, próxima ocorrência, recorrência, atraso e fingerprint. Arguments sensíveis são redigidos.
- `cron/run`: selecionar um evento existente por identidade/revisão, sem aceitar nome de função PHP. Lease impede dois disparos cooperantes. Reproduzir o contexto de execução cron e registrar separadamente o solicitante. Exibir início, fim, reagendamento, exceção e estado incerto após interrupção.
- Conclusão do callback não prova sucesso do negócio: jobs que não devolvem resultado verificável informam execução concluída e `business_result:unknown`.
- `cron/schedule` e `cron/unschedule`: validação de recorrência, argumentos e horário; conferência do estado nativo depois. Evitar duplicações e cancelamento de evento alterado por outro processo.
- `system/delete-transient`: chave exata, modo de armazenamento identificado e conferência posterior. `system/cache-flush`: executar `wp_cache_flush`, devolver retorno observado e escopo de cache de objeto.

Aceite: evento sintético vencido listado, executado uma vez e reagendado; contenção com WP-Cron concorrente; transient removido; teste com cache de objeto realmente ativo quando se declarar cobertura desse backend. Evento Core/Google no piloto exige fixture/efeito previsto e autorizado.

### 33 — Temas, ZIP e arquivos grandes

- `themes/upload`: URL e base64, hash/slug, requisitos e identidade do tema; substituição por árvore preparada, backup e rollback. Registrar tema ativo/stylesheet/template e dependência pai/filho. Tema em uso recebe sonda e recuperação independente do seu PHP.
- `themes/update` usa oferta verificada; `themes/delete` verifica uso e dependentes pelas regras nativas. `themes/rollback` restaura arquivos e estado de ativação; não promete desfazer migrações arbitrárias do tema.
- Preservar `files/move`/`files/copy` existentes. Incluir testes de descoberta, Get Ability Info e execução MCP para todos os perfis relevantes, source/destination hash, overwrite, backup, rótulo e links. A indisponibilidade relatada no piloto permanece pendente até essa conferência.
- `files/archive` e `files/extract`: inventário, caminhos confinados ao destino pedido, proteção contra traversal/links/colisões e expansão controlada. Backup do destino e preparação antes da substituição; conflito preserva alteração concorrente. Roundtrip de binários e nomes Unicode por manifesto de hashes.
- Limite por arquivo configurável para Manutenção por uma rota do próprio canal. Unificar limites em PathGuard, transferências, finalização, backups e arquivo temporário. Separar tamanho do arquivo de tamanho da resposta e de cada parte; permitir 20 MiB sem montar seu base64 inteiro em uma chamada.

Aceite: tema de teste enviado por URL, ativado e revertido; fatal de tema novo; ZIP ida/volta com hashes; casos ZIP malformado e colisão; upload de 20 MiB em partes e conferência de bytes/hash.

### 34 — Autoadministração do canal

- `connections/list`: paginação, identidade não secreta, perfil efetivo, estado, origem, expiração de política, última observação e capacidade de uso; não retorna senhas/tokens.
- `connections/update`: outro vínculo por ID exato e `expected_policy_version`, com readback/auditoria. Usar o mesmo serviço da tela, evitando duas implementações de política.
- `connections/revoke`: revogação exata, família/sessões afetadas explícitas, idempotência e preservação de grants independentes. Não deduzir que todas as credenciais de user_id 1 são a mesma conexão.
- Redução do próprio acesso ou autorrevogação requer prévia e `confirm_token`; `confirm:true` não encurta esse fluxo. Elevação por uma conexão restrita continua proibida.
- Não criar automaticamente uma política administrativa para identidade sem credencial só porque o usuário foi autenticado pelo WordPress. Integração explicitamente configurada continua possível. Registros históricos sem perfil aparecem como **Sem acesso**, com limpeza/revogação por ID.
- Adicionar consulta/alteração tipada das configurações do canal para feed HTTPS, limite de arquivo e bloqueio geral. Isso evita deixar `f3_mcp_*` editável por options e simultaneamente inacessível por MCP. Mudança que corte o acesso atual usa confirmação em duas fases.

Aceite: revogar as identidades legada e de integração relatadas, sem atingir o grant Claude indicado no piloto; revisão concorrente conflita; token revogado não autentica; ajustar limite/feed pelo canal; autorrestrição conserva a confirmação forte.

## 5. Sequência, estimativa e responsáveis

As etapas abaixo são ordem de trabalho interna. A publicação continua única e inclui todo o escopo. Não usar o fim de uma etapa como autorização para instalar código parcial na frota.

| Etapa | Itens | Dependências | Estimativa inicial de esforço | Responsável de execução |
| --- | --- | --- | ---: | --- |
| Contratos e regressões dos incidentes | 25, 26, 28, 27 | Fonte/base e fixtures de migração | 8–12 dias-pessoa | Mantenedor MCP |
| Autoadministração e configuração tipada | 34, 31 | Política Manutenção e revisão por conexão | 6–10 dias-pessoa | Mantenedor MCP |
| Consulta, snapshot e exportação de resultado | 29 | Leitura ampla e jobs duráveis | 6–10 dias-pessoa | Mantenedor MCP |
| DDL, lote, dump/restore e troca serializada | 30 | Backup/snapshot, parser e recuperação | 12–20 dias-pessoa | Mantenedor MCP |
| Cron, transients e cache | 32 | Jobs, lease e contratos de resultado | 2–3 dias-pessoa | Mantenedor MCP |
| Temas, ZIP e arquivo grande | 33 | Recuperação e limite configurável | 4–7 dias-pessoa | Mantenedor MCP |
| Integração final, documentação e homologação | 1–15, 17–34 e gates herdados | Runtime congelado e pacotes atuais | 6–10 dias-pessoa | Mantenedor MCP; aceite do dono/agente do piloto |

A matriz 1–24 explicita regressões e aceite da base já entregues, sem estimar sua reimplementação. A estimativa abaixo pressupõe esse reaproveitamento; defeito adicional comprovado deve atualizar o esforço restante, não desaparecer do escopo.

Total inicial: **44–72 dias-pessoa** de engenharia e verificação, como estimativa de planejamento, sem prazo de calendário contratado. A maior incerteza está em SQL complexo, consistência de exportação e restauração do próprio banco do canal. Reestimar após os protótipos de migração e snapshot; não dividir o total por agentes como se todo trabalho fosse independente. Datas dependem de alocação e disponibilidade do piloto; nenhuma pessoa externa foi designada nesta revisão.

As correções de incidentes vêm primeiro no desenvolvimento, mas permanecem no mesmo compromisso de publicação por decisão de entrega integral. Incidente novo que exija hotfix será relatado com evidência e decisão explícita de publicação; o plano não publica uma versão intermediária automaticamente.

## 6. Gate único com evidência por contrato

1. **Fonte e pacote identificados:** hashes, versões, lista de arquivos distribuídos e manifesto. Conferir hash instalado no piloto; não inferir igualdade apenas de `0.13.0` no cabeçalho.
2. **Migração real de base:** instalar 0.12.1 íntegra, autenticar/conectar antes da troca e atualizar pelo canal. Cobrir também a 0.13.0 com perfis já configurados. Requisitos incompatíveis não removem a base. Testes com relógio controlado verificam D+8 sem esperar oito dias reais.
3. **Transporte completo:** SQL, erro estruturado, descoberta, refresh e chamadas próprias/terceiras atravessam a mesma fronteira HTTP dos clientes. Testes unitários ou invocação direta de classe não encerram esse gate.
4. **Banco MySQL 8 e processos reais:** sucesso e falha das instruções exigidas, rollback DML, recuperação DDL, conflito concorrente, desconexão, timeout, commit incerto e limites de disco. Testar consultas que produzem valor e conferir esse valor, além dos casos recusados.
5. **Arquivos e HTTP:** seis documentos ausentes, ajuda autenticada presente, ZIP/tema/20 MiB, OPcache e recuperação. Conservar os testes anteriores de ENOSPC, SIGKILL e scripts removidos.
6. **Sem dependência operacional nova da hospedagem:** não exigir ajuste de sql_mode, instalação de daemon, cron de sistema, mysqldump ou regras manuais no servidor. O ambiente automatizado Apache é tarefa de engenharia; não é pedido à DreamHost.
7. **Complementos atuais:** validar Core/Google efetivamente usados. Não fazer downgrade para fechar a matriz. Manutenção permite provedores não aderentes; perfis restritos só declaram suporte após conferir adesão atual. Servidor Elementor continua operacional.
8. **Cobertura integral da lista:** todos os 33 IDs ativos com evidência individual; item 16 permanece retirado e nenhum item 35 é criado. Os gates anteriores e recursos da base continuam cobertos, com decisões substituídas explicitamente identificadas.
9. **Piloto e rollout:** somente após pacote completo, teste no Site-Teste e autorização operacional. Retirada de cada item da lista oficial exige registro do aceite correspondente; código presente e teste sintético não retiram a pendência de frota.

Gate anterior da 0.13.0 ainda aberto não desaparece: testes Apache/pool, filesystem efetivamente cheio e clientes reais precisam de evidência aplicável ao pacote final. A reprovação não se transforma em `skipped` aprovado. O relatório diferencia implementado, testado localmente, verificado no piloto e bloqueado, com motivo concreto.

## 7. Documentação e entrega

- Uma referência canônica por pedido de frota: a matriz 2.2 liga os itens 1–24 aos contratos históricos; a seção 4 define 25–34. Schemas, permissão, efeitos, recuperação, erros e teste ficam referenciados, sem copiar definições contraditórias entre manuais. A 0.14.0 precisa consolidar a especificação corrente; documentos 0.13.0 permanecem históricos.
- README/changelog externos, manual de operação efetivo, guia de migração pelo canal, guia embarcado protegido, schemas exportados e matriz de aceite item a item.
- Atualizar o manual de Manutenção: acesso pleno, migração automática, validade de credenciais, opções explícitas, limites físicos e garantia real de cada backup/restauração.
- Relatório apresenta claramente o que já existia na 0.13.0 e foi preservado: move/copy, subconjunto JOIN/IN, grep_regex em busca, retenção de legados, limpeza de auto-update e limpeza tipada de uninstall, entre outros. Não contabilizar essas funções como novas sem mudança demonstrada.
- Instalador MCP e componente de migração do mesmo pacote de entrega; fontes e testes reproduzíveis; manifestos versionados com SHA-256. Feed só é chamado de publicado após URL real responder e bytes serem conferidos. Configuração de feed não liga autoatualização sem pedido.
- Nenhum dos instaladores desta revisão é criado: esta rodada entrega plano e reprodução das pendências, sem editar código de produção.

## 8. Referências técnicas

- WordPress Core, Introducing “Update URI” plugin header in WordPress 5.8: https://make.wordpress.org/core/2021/06/29/introducing-update-uri-plugin-header-in-wordpress-5-8/ — `false` inibe a oferta homônima padrão; feed próprio é uma capacidade distinta. Consultado em 01/10/2026.

- MySQL 8.0, Function Name Parsing and Resolution: https://dev.mysql.com/doc/refman/8.0/en/function-resolution.html — espaçamento afeta funções específicas; preservar a forma da chamada evita dependência de IGNORE_SPACE.
- MySQL 8.0, Atomic DDL: https://dev.mysql.com/doc/refman/8.0/en/atomic-ddl.html — atomicidade de uma instrução DDL não permite compor lote transacional com outras instruções.
- MySQL 8.0, Implicit Commit: https://dev.mysql.com/doc/refman/8.0/en/implicit-commit.html — lista das instruções com commit implícito.
- MCP 2025-06-18, Transports / Session Management: https://modelcontextprotocol.io/specification/2025-06-18/basic/transports — sessão terminada recebe 404 e o cliente inicializa nova sessão; cabeçalho deve refletir a negociação efetiva.

Fontes locais examinadas: `includes/SqlReadPolicy.php`, `SqlGuard.php`, `SqlSelection.php`, `Database.php`, `DatabaseBudget.php`, `DataSafety.php`, `ConnectionContext.php`, `ConnectionsAdmin.php`, `SystemTools.php`, `Guide.php`, `FileTools.php`, `MaintenanceTools.php`, `PackageService.php`, `SelfUpdate.php`, OAuth e transporte em `core/includes/`. As hipóteses sobre o piloto continuam identificadas como relato até nova medição autorizada.
