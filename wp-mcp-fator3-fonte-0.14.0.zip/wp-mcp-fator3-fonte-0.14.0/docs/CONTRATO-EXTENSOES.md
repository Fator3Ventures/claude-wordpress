# Contrato de extensões — 0.14.0

Manutenção acessa habilidades públicas de terceiros respeitando suas permissões nativas. Provedor sem adesão não recebe autorização de Leitura/Conteúdo por inferência. Metadata de versão identificada não significa adesão. O MCP não substitui os callbacks do Elementor nem desativa seu servidor.

As decisões correntes estão no plano revisão 2, itens 25–26, e no manual. Os complementos testados são Core 1.18.0 e Google 0.5.0, sem chamadas às APIs Google neste ensaio.
