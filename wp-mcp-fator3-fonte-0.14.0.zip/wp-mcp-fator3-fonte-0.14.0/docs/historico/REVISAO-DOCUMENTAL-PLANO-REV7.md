# Revisão documental — 29/09/2026, revisão 7

Base executável **0.12.1**; alvo **0.13.0 completa**. O documento de pedidos da frota foi lido integralmente e preservado em `entradas/PEDIDOS-MCP-2026-09-29.md`.

## Alterações

- 74 IDs anteriores preservados e nove acrescentados: F20–F23/N04–N08, total 83. A matriz DEMANDAS-2026-09-29 relaciona todos os números originais e adendos, incluindo o 16 retirado.
- C01/C02/F10/O01 corrigidos para manter o servidor Elementor e suas jornadas autorizadas. A proteção nas habilidades próprias continua com contexto validado; não existe tarefa de desativação dessa porta.
- F11/F19/O08/O13/O14/E01 ampliados com evidência de barras preservadas, regex, retenção legada, sondas, atualização e metadados pendentes. Estimativas e critérios de aceite atualizados.
- OPERACAO descreve somente 0.12.1 e seus limites; especificações/preparação descrevem a release futura. O anexo não sofreu baixa de itens.
- Regra de aguardar o pacote, ordem core → google → canal e decisão do dono para publicação registradas. O marco solicitado de 29/09 não foi apresentado como atendido.
- Código runtime, versão funcional, histórico de releases e evidências históricas continuam iguais à base. Relatórios de 24/09 e 27/09 são históricos; decisões incompatíveis neles são substituídas pela especificação revisão 7.

## Verificação

O relatório do pacote registra verificação de 83 IDs únicos, preservação dos 74 anteriores, concordância de títulos/dependências com o índice, ausência de ciclos explícitos, links/âncoras, JSONs, cópias de plano/manual, manifesto e comparação do runtime com o instalador 0.12.1. A matriz cobre os números 1–24 e adendos sem renumerar a fonte; o anexo preservado é idêntico ao recebido.

A confirmação de runtime inalterado não é correção dos incidentes. Não houve teste funcional novo, migração, integração Elementor/Yoast, execução de SQL nos sites ou publicação. A validação futura exige schemas pós-decoradores, casos positivos/negativos e ensaios concorrentes/de interrupção em P07.

Este é um pacote documental para as fontes. A entrega funcional 0.13.0 continua dependente da implementação e do aceite completo. O relatório `verificacao-documental.json` informa esses limites explicitamente.
