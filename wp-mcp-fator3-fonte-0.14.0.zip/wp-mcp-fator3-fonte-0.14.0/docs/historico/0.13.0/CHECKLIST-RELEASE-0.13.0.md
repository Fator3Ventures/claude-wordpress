# Checklist — release única 0.13.0

Revisão 7 · 29/09/2026 · **Gate funcional pendente.**

Contratos e critérios estão em [ESPECIFICACOES.md](ESPECIFICACOES.md). Este checklist registra a prova de atendimento, sem redefinir parâmetros/comportamentos. Consultar marcos e papéis no [plano](PLANO-PROXIMAS-RELEASES.md).

- [ ] Os 83 IDs têm responsável nominal, status, evidência/commit e pendência rastreável; esforço/previsão recalibrados após P07/P03.
- [ ] P01/P07: ambiente/cliente/frota identificados; laboratório reproduzível roda a suíte com processos concorrentes.
- [ ] F01–F23/N01–N08 e regras comuns aprovados por testes positivos/negativos, não só por inspeção.
- [ ] C01–C06/O01–O03: política e contexto homologados na porta Fator3, alias e servidor de terceiro; nenhuma falta de contexto recebe Legado implícito.
- [ ] C05 e migração 0.12.1: consumo único, emissão transacional, revogação, índices, idempotência e efeitos incertos comprovados.
- [ ] F14/P06/O12–O14/O20: estratégia de ativação, recuperação, sonda/cache, autoatualização e interrupções demonstradas segundo os limites especificados.
- [ ] O04–O11/O15–O19: operação, UX, retenção, exclusões, catálogo, backup, cron, selftest e ajuda completos.
- [ ] E01–E07: cobertura de complementos, metadados/blocos, transferências e mídia validada na pilha.
- [ ] M01–M04: dependências fixadas, migração upstream revisada, testes wire/capacidades e jornadas dos clientes atuais; não assumir equivalência de versões legadas.
- [ ] F16: recursos nested/legados, MIME, permissões e deduplicação entre processos demonstrados; integração dos sete recursos Elementor e regressão após M01 registradas.
- [ ] F17/F19/F13: nenhuma perda silenciosa de filhos; busca em arquivo sem ampliar alvo; recusa de armazenamento privado com orientação útil e sem vazamento de caminho.
- [ ] F18: fixture secreta ausente em preview/resultado/erro/replay/log; pré-imagem íntegra e conflito preservados; exportação de conteúdo autorizada separadamente, incluindo legado e partes E05.
- [ ] N03: somente registro órfão confirmado é removido; corrida, backup, permissão e no-op testados; opção genérica continua protegida; nenhum callback ou post é eliminado por associação de nome.
- [ ] Pendências de operação de N03 têm estado/responsável próprios; sucesso da suíte não é comunicado como limpeza feita na frota.
- [ ] F20: fatal pós-escrita recuperado no fluxo coordenado; PHP novo não é aprovado por resposta servida de cache; falha/interrupção e indisponibilidade do MCP ensaiadas.
- [ ] F21/F22/F23: hooks/imagem/revision final, limpeza de auto-update e seleção SQL complexa limitada com transação/concorrência demonstrados.
- [ ] N04–N08: projeção, tokens de listas, option por key, gzip limitado e exclusões nativas com cache/hooks/backup/estado parcial testados.
- [ ] F19/O08/O13: grep_regex, seleção de backups legados e asserções/cabeçalhos de sonda cobertos.
- [ ] Servidor Elementor e suas jornadas nativas preservados; a exceção do pedido 16 não reaparece como tarefa de desativação.
- [ ] Cada número da matriz 1–24 tem evidência de entrega ou estado explícito; não renumerar nem retirar pendências só por estarem planejadas.
- [ ] D01–D08: schemas pós-decorador, exemplos executados, aliases/defaults/permissões/erros e manual coerentes com a implementação final.
- [ ] OPERACAO descreve apenas a versão efetivamente entregue; preparação/histórico não viram instrução operacional.
- [ ] Mesmos bytes entre cópias autorizadas; links/JSONs válidos; schema↔execução possui evidência separada.
- [ ] VERSION, cabeçalho, constante, README, CHANGELOG, manifestos e nomes concordam; fonte/instalador/docs do mesmo commit, hashes finais corretos.
- [ ] Instalador contém somente runtime; fontes/docs preservam testes e histórico identificado. O pacote documental de preparação não é anunciado como instalador.
- [ ] Aceite em fator3-teste-mcp-1 e pilotos concluído antes da expansão do mesmo pacote completo.
- [ ] Matriz dos 14 conectores preenchida e migração/rotação realizada no prazo do rollout, com recusa das credenciais antigas; exceções administrativas explicitamente aprovadas e expirantes.
- [ ] Data solicitada de 29/09 conciliada com evidência real; publicação autorizada pelo dono, na ordem core → google → canal, com compatibilidade entre etapas. Correções não foram aplicadas como patches avulsos por site.

## Registro de fechamento

| Campo | Estado atual |
| --- | --- |
| Código de referência | 0.12.1 |
| Alvo | 0.13.0 completa |
| IDs obrigatórios | 83 |
| Commit/hashes do instalador e fonte novos | Pendentes |
| Testes funcionais, migração e recuperação | Pendentes |
| Responsáveis nominais, T0 e datas de calendário | A registrar no kickoff |
| Coerência documental desta revisão | Ver REVISAO-DOCUMENTAL e verificação do pacote |
| Autorização de publicação | Não concedida por este checklist |
