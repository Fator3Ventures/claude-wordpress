# Preparação — WP MCP Fator3 0.13.0

Revisão 7 · 29/09/2026 · **Planejado; ainda não entregue.**

A próxima release reúne todo o escopo aprovado em uma única versão. A identificação anterior 0.12.2 foi substituída por 0.13.0. O [plano](PLANO-PROXIMAS-RELEASES.md) define estimativas, responsáveis, marcos, dependências e gate. A [avaliação crítica](AVALIACAO-CRITICA.md) registra evidências, inferências e alternativas não adotadas.

## Onde está cada contrato

Todos os comportamentos futuros têm uma especificação canônica por ID em [ESPECIFICACOES.md](ESPECIFICACOES.md). Não implementar copiando resumos do plano ou do manual. Este documento somente encaminha o trabalho:

| Tema | Especificações |
| --- | --- |
| Frota e infraestrutura de teste | [P01](ESPECIFICACOES.md#p01), [P04](ESPECIFICACOES.md#p04), [P07](ESPECIFICACOES.md#p07) |
| Outras portas e execução indireta | [F10](ESPECIFICACOES.md#f10), [C01](ESPECIFICACOES.md#c01), [C02](ESPECIFICACOES.md#c02), [O03](ESPECIFICACOES.md#o03) |
| SQL, perfis e credenciais | [F01](ESPECIFICACOES.md#f01), [O01](ESPECIFICACOES.md#o01), [O02](ESPECIFICACOES.md#o02) |
| Persistência e concorrência | [C05](ESPECIFICACOES.md#c05), [F02](ESPECIFICACOES.md#f02), [F04](ESPECIFICACOES.md#f04), [F05](ESPECIFICACOES.md#f05), [F07](ESPECIFICACOES.md#f07) |
| Ativação, backup, canal e recuperação | [F08](ESPECIFICACOES.md#f08), [F14](ESPECIFICACOES.md#f14), [P06](ESPECIFICACOES.md#p06), [O12](ESPECIFICACOES.md#o12), [O13](ESPECIFICACOES.md#o13), [O14](ESPECIFICACOES.md#o14), [O20](ESPECIFICACOES.md#o20) |
| Conteúdo, bytes, rewrite, aliases | [F09](ESPECIFICACOES.md#f09), [F11](ESPECIFICACOES.md#f11), [F15](ESPECIFICACOES.md#f15), [N01](ESPECIFICACOES.md#n01), [N02](ESPECIFICACOES.md#n02) |
| Catálogo, backups, contagem, cron/ajuda | [O15](ESPECIFICACOES.md#o15), [O16](ESPECIFICACOES.md#o16), [O17](ESPECIFICACOES.md#o17), [O18](ESPECIFICACOES.md#o18), [O19](ESPECIFICACOES.md#o19) |
| Metadados/SEO, blocos, transferências e mídia | [E01](ESPECIFICACOES.md#e01) a [E07](ESPECIFICACOES.md#e07) |
| Protocolo e clientes | [M01](ESPECIFICACOES.md#m01) a [M04](ESPECIFICACOES.md#m04) |
| Recursos de terceiros e logs | [F16](ESPECIFICACOES.md#f16), regressão pós-[M01](ESPECIFICACOES.md#m01) |
| Edição com filhos | [F17](ESPECIFICACOES.md#f17), [E03](ESPECIFICACOES.md#e03) |
| Segredos em prévia/resultado/backup | [F18](ESPECIFICACOES.md#f18), [F01](ESPECIFICACOES.md#f01), [O01](ESPECIFICACOES.md#o01), [E05](ESPECIFICACOES.md#e05) |
| Busca em arquivo e diagnóstico privado | [F19](ESPECIFICACOES.md#f19), [F13](ESPECIFICACOES.md#f13) |
| Registro órfão e pendências de limpeza | [N03](ESPECIFICACOES.md#n03), [O11](ESPECIFICACOES.md#o11) |
| Sonda PHP / thumbnail / exclusão de plugin / seleção SQL | [F20](ESPECIFICACOES.md#f20) a [F23](ESPECIFICACOES.md#f23) |
| Projeção, options/get por chave, gzip e exclusões | [N04](ESPECIFICACOES.md#n04) a [N08](ESPECIFICACOES.md#n08) |
| Documentação e publicação | [D01](ESPECIFICACOES.md#d01) a [D08](ESPECIFICACOES.md#d08) |

São 83 IDs obrigatórios. A [análise de 27/09](DEMANDAS-2026-09-27.md) distingue o código confirmado dos relatos de produção; não muda o estado das pendências nos sites. Os demais IDs continuam obrigatórios. O índice integral e estado planejado estão em `contratos-planejados.json`; esse arquivo não é export de schema executável.

## Uso dos documentos

- [OPERACAO](OPERACAO.md): somente o contrato instalado 0.12.1, com limitações; não inserir instruções futuras.
- Especificações: fonte normativa do próximo comportamento. Exemplos executáveis só após implementação/schema efetivo.
- [Checklist](CHECKLIST-RELEASE-0.13.0.md): provas a associar ao pacote final, atualmente pendentes.
- [Revisão documental](REVISAO-DOCUMENTAL-0.13.0.md): verificações textuais executadas e seus limites.
- Histórico superado: rastreabilidade; não rege a implementação.

Antes de publicar, exportar schemas após decoradores, executar casos de contrato e gerar o manual da versão entregue. O teste semântico compara schema, defaults/aliases, execução e respostas; hashes iguais de duas cópias do manual comprovam somente sincronização.

A entrega única permanece; aplicar a regra de aguardar o pacote e a decisão de manter o servidor Elementor. A [matriz de frota](DEMANDAS-2026-09-29.md) preserva cada número e registra a data solicitada de 29/09 sem apresentá-la como entrega executada. Nesta preparação não houve construção de código funcional novo, alteração de sites ou rotação de credenciais.
