# Referência documental substituída

O alvo da release completa passou a 0.13.0. Consulte [PREPARACAO-0.13.0.md](PREPARACAO-0.13.0.md). Este arquivo mantém o vínculo antigo e não contém um contrato independente.
