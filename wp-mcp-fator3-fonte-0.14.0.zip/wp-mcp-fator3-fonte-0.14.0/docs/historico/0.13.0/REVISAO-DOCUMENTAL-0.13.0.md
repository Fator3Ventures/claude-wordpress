# Revisão documental da implementação — 30/09/2026

O estado atual é implementação 0.13.0 em desenvolvimento. OPERACAO descreve contratos implementados no fonte; preparação e requisitos de aceite permanecem nos documentos de planejamento. A edição documental de 29/09, anterior ao código, está preservada no histórico.

O runtime mudou em relação à 0.12.1; não se exige mais equivalência byte a byte com a rc.2. O verificador de pacote mede diffs funcionais, exclusão de material de desenvolvimento, documentação incluída, lint, hashes e reconstrução determinística. O gate de release continua pendente.

Schemas são exportados do registro WordPress após decoração. Descrições centrais usam uma camada única em português, derivando a lista de parâmetros do schema efetivo. Isso remove divergências antigas como parent/parent_id e type/post_types sem reescrever identificadores de API.

`tools/check_documentation.py` confere exemplos, aliases, defaults, contratos declarados e cópias embarcadas. `evidencias/documentation-0130.json` registra o resultado. A revisão não se limita à comparação entre cópias, mas tampouco declara prova automática de toda a prosa.

Atualizados: manual de operação, migração/recuperação, cobertura SEO, ajuda embarcada, README de desenvolvimento, changelog não publicado, estado dos 83 IDs e ambiente de aceite. Os três pacotes têm versões fixadas e instaladores de homologação. Pendem revisão editorial integral/links, documentos externos da frota e aceite final. A continuação documenta diagnóstico de recuperação, ENOSPC controlado, OPcache CLI e navegador/editor sintético, preservando os limites de cada evidência. Nenhuma edição de documento equivale a execução das operações descritas.

Atualização de implementação: versões alvo MCP 0.13.0 / Core 1.17.1 / Google 0.4.1. Manual e schemas efetivos identificam 0.13.0; os manuais funcionais das bases Core/Google permanecem como referência dos contratos preservados, com adendo de integração. As evidências antigas não são apresentadas como homologação das revisões novas.
