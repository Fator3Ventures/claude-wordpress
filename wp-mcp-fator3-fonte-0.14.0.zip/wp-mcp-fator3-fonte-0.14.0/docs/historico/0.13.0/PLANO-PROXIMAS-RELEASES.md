# Plano de implantação — WP MCP Fator3 0.13.0, release única

Revisão **7**, 29/09/2026. Base executável: **0.12.1**. Situação: planejamento revisto; implementação e homologação não executadas nesta revisão.

## 1. Decisão de entrega

Manter **uma única próxima release completa**, conforme a decisão do produto. Renumerar o alvo para **0.13.0**, dado o conjunto de funcionalidades e mudanças de contrato. Não haverá uma entrega 0.12.2 parcial programada. Os **74 IDs da revisão 6 foram preservados**; F20–F23 e N04–N08 acrescentam nove contratos: **83 itens**. Os demais acréscimos ampliam IDs existentes. A decisão sobre coexistência Elementor foi corrigida conforme o pedido 16 retirado na lista da frota.

A crítica ao custo de esperar pelo último item é procedente. Ordem de implementação não reduz exposição em produção enquanto o pacote não for publicado. O plano passa a explicitar esforço, dependências, marcos, responsáveis por função e essa janela. Reduzir escopo ou abrir um segundo trem exige mudar expressamente a decisão de entrega; nenhuma dessas mudanças foi presumida.

**Regra vigente da frota:** correções do pacote aguardam o pacote, inclusive as baratas e reversíveis. Não aplicar patches por site nem programar release parcial. Publicação depende de decisão do dono. O anexo registra **29/09/2026** como data solicitada de entrega; nesta revisão há fonte executável 0.12.1 e documentação planejada, sem evidência de implementação/homologação da 0.13.0. Esse marco está sem comprovação de atendimento; as estimativas técnicas abaixo não o substituem por uma nova data acordada.

A numeração 0.x não prova, por si só, violação formal de SemVer. Adotar 0.13.0 comunica melhor as novas funcionalidades, os defaults e a migração de autorização; versões, notas e instruções devem explicitar os contratos alterados.

## 2. Premissas vigentes e evidências

| Premissa | Referência adotada | Limite da evidência |
| --- | --- | --- |
| Frota | Anexo recebido em 29/09 relata reconferência em 27/09: 14 conectores em MCP 0.12.1. | Não houve nova inspeção de produção nesta revisão; P01 anexará inventário nominal/evidências. |
| WordPress/PHP | Relatório: WP 7.1.2 e PHP 8.3.30 em todos. | MySQL 8.0.x exato, Apache/hospedagem/cache precisam ser inventariados; capabilities não prova tudo. |
| Migração obrigatória | 0.12.1 → 0.13.0. | rc.2 sai do gate da frota; se encontrada, tratar explicitamente antes da expansão. |
| Topologia | Single-site padronizado. | Retirar rede/multisite do gate; detectar estado não suportado sem converter ativação. Recusa de rede do Core não é prova universal de topologia. |
| Outras portas MCP | O anexo atribui o servidor adicional ao MCP Adapter/Elementor e registra decisão de mantê-lo. | Não desativar/recusar o servidor; conferir integração e identidade validada para as abilities próprias (C01/C02). |
| Permissões | Relatório: user_id 1 e capacidades amplas/database_write nos 14 conectores. | Mesmo usuário não prova credencial única; mapear concessão/UUID por conector e tarefa. |
| Protocolo upstream | PR #310 merged em 21/09, commit `8bd4a67810da853683ab2e122af394cfe3b7b631`, consultado via GitHub. | Merge não é homologação Fator3; diferenças do fork, schemas e autoload precisam ser testados. |

Preservar pasta/entrypoint, URLs principal e legada, nomes das três ferramentas e dados/backups. O acesso antigo é migrado de forma controlada para perfis reais, sem conceder silenciosamente privilégios a habilidades novas. Alcance irrestrito de PHP permanece possibilidade administrativa explicitamente selecionada, sem promessa de isolamento de dados para esse perfil.

## 3. Especificação e rastreabilidade

A fonte normativa de comportamento futuro passa a ser **[ESPECIFICACOES.md](ESPECIFICACOES.md)**, com uma seção por ID. O documento reúne os critérios anteriores preservados e as decisões da crítica. O plano organiza entrega; o manual descreve somente o código instalado; a preparação remete aos IDs e não cria um contrato paralelo.

| Bloco | IDs obrigatórios |
| --- | --- |
| Preparação/laboratório | P01–P07 |
| Arquitetura e código | C01–C06 e regras comuns de qualidade |
| Correções | F01–F23 |
| Novos contratos | N01–N08 |
| Operação/administração | O01–O20 |
| Conteúdo/arquivos/mídia | E01–E07 |
| Protocolo | M01–M04 |
| Documentação/fechamento | D01–D08 |

O registro anterior foi preservado como histórico superado, sem autoridade sobre contratos atuais. Mudanças de interpretação ficam na [avaliação crítica de 24/09](AVALIACAO-CRITICA.md) e na [análise das novas demandas](DEMANDAS-2026-09-27.md). O manifesto documental identifica os artefatos da preparação; não certifica código funcional novo.

### Novas demandas incorporadas em 27/09

| Demanda de 25/09 | Contrato canônico | Prioridade |
| --- | --- | --- |
| URI/MIME em meta.mcp e erro repetido de recurso | [F16](ESPECIFICACOES.md#f16) | P1 |
| inner_html descarta blocos filhos | [F17](ESPECIFICACOES.md#f17), integração E03 | P1 |
| files/search em arquivo único | [F19](ESPECIFICACOES.md#f19) | P2 |
| f3_private_storage sem orientação | [F13](ESPECIFICACOES.md#f13), documentação D01/D03 | P2 |
| Registros uninstall_plugins órfãos | [N03](ESPECIFICACOES.md#n03), confirmação O11 | P2 |
| Segredo em db/execute e guarda em backup | [F18](ESPECIFICACOES.md#f18), integração F01/O01/O07/E05 | **P0** |

A inspeção da base confirmou os caminhos de código; datas, sete recursos, versões de Elementor e volumes de log permanecem evidência relatada, sem reprodução em produção. A prévia SQL **já chama um redator**, limitado a duas colunas de usuários; ampliar a classificação é necessário. Não basta repetir a chamada de db/query. O post angie_snippet é pendência operacional separada, registrada em N03, sem exclusão automática por instalar a atualização.

### Consolidação do documento de frota recebido em 29/09

A [matriz dos pedidos 1–24](DEMANDAS-2026-09-29.md) preserva os números originais, inclusive o **16 retirado**, e relaciona cada pedido com sua especificação e evidência. A numeração da frota não substitui os IDs internos: F16 trata recurso/URI e corresponde ao pedido 15. O anexo original foi preservado sem baixa de itens.

| Demanda acrescentada | IDs | Prioridade |
| --- | --- | --- |
| Sonda e reversão após escrita de PHP carregado | F20, P06/O13 | P0 |
| Imagem destacada/hook e revisão final | F21 | P1 |
| Limpeza auto_update_plugins após exclusão | F22 | P2 |
| JOIN/subconsulta em seleção de escrita, subconjunto transacional | F23 | P2 |
| Projeções de conteúdo/revisões e tokens em listas | N04 | P2 |
| options/get por key | N05 | P2 |
| Leitura gzip filtrada | N06 | P2 |
| Menus/delete e options/delete | N07/N08, O11 | P2 |
| Regex na busca; retenção legada; asserções da sonda | F19/F11, O08, O13 | P2 |

Correções de interpretação: a perda de barras não se reproduziu no teste relatado de 25/09; o token revision já é calculado após o callback no fonte, exigindo reprodução da divergência; Update URI:false já impede a oferta homônima convencional. A posição textual de uma função PHP, isoladamente, não explica undefined function. Fontes/evidências e seus limites estão na matriz.

## 4. Decisões técnicas e dependências

- **F10/C01/C02/O03:** manter o servidor Elementor e suas jornadas nativas. O adaptador resolve identidade validada para aplicar política às habilidades próprias; não bloquear a porta por falta de header Fator3. A proteção contra execução encadeada e permissões por ação permanece. A regra anterior de desativar o servidor foi substituída.
- **F01/O01:** SQL limitado por fontes/funções permitidas, sem parser completo de linhagem. Testar influência indireta e fazer migração de credenciais/perfis. F01 tem valor local; a garantia de isolamento de um conector depende de seus demais poderes. Credencial administrativa com PHP não é isolada por SQL.
- **C05:** persistência decidida em InnoDB próprio, com dbDelta/migrações, índices e consumo condicional/transacional. Cache/transients deixam de ser a autoridade. Não se transfere atomicidade de transação SQL para filesystem/HTTP.
- **F14:** adotar estratégia B, reativação coordenada em contexto PHP novo, com retorno explícito de falha. Implementar/reproduzir antes de P06/O12/O13; integrar recuperação/sonda no pacote completo. Bulk upgrade permanece alternativa de implementação a comparar, sem uma segunda release planejada.
- **P06:** reutilizar primitivas do WordPress, com diário/sentinela e restauração pré-carregada. Cobrir morte do processo, autoload e fase de bootstrap; a sonda técnica do núcleo não substitui a sonda pública anônima.
- **M01–M04:** integrar o commit upstream já merged e validar os requisitos. Continua no escopo da entrega completa; não aguardar um merge já ocorrido. O servidor atual anuncia 2025-06-18; o PR é dual 2025-11-25/2026-07-28. P01/M04 devem provar negociação/compatibilidade dos clientes atuais antes de trocar a implementação.
- **F12:** reutilizar o serviço interno de patch/lock, mantendo a habilidade desabilitada por padrão. **E02:** levantar cobertura existente antes de criar APIs duplicadas. **E04/E05:** demanda acima de 16 MiB ainda não demonstrada; custo mantido visível por permanecerem no escopo aprovado.
- **F15:** parent canônico na entrada, parent_id como alias validado; saídas preservam parent_id e acrescentam parent coerente. Cobrir list/create/update/get, incluindo zero e conflitos.

- **F18:** correção de sigilo de saída é prioridade interna P0. Separar cópias redigidas dos dados originais usados em conflito/backup; exportar backup íntegro exige permissão explícita de conteúdo. Não tratar base64 como ocultação nem prometer isolamento de um administrador com SQL/PHP.
- **F16/F17/F19/F13:** correções locais independentes do rebase. Validar novamente F16 após M01; F17 integra a homologação de blocos E03. Os critérios detalhados e códigos pertencem à especificação.
- **N03:** manutenção tipada de um registro órfão, com prévia/confirmação e preservação das demais entradas. Não desbloquear uninstall_plugins nem inferir que o nome de um plugin autoriza apagar seu conteúdo.

- **F20:** recuperação de PHP reutiliza diário/restauração P06 e sonda O13; a indisponibilidade do MCP após um fatal faz parte do teste. Não criar endpoint para executar PHP.
- **F21/N04:** revisão final e leitura econômica precisam compartilhar a mesma semântica de token; integrar o fluxo de thumbnail com hooks/SEO e validar cache/concorrência.
- **F23/N07/N08:** manter prévia/confirmação, selecionar alvos de modo preciso e preservar efeitos nativos. JOIN/subconsulta deixa de ser tratado como ajuste pequeno: seu subconjunto exige reconhecimento estrutural e prova transacional.

O caminho de correções locais não espera rebase do protocolo nem a extração completa de classes. O gate final permanece completo pela decisão do produto. As dependências por ID estão na especificação; distinção entre implementar e publicar deve permanecer visível no acompanhamento.

## 5. Estimativa e responsáveis

**Estimativa preliminar de engenharia, não prazo contratado.** Inferida da extensão do código, dependências e cenários do plano; não existe histórico de velocidade da equipe nem pessoas alocadas neste documento. Hipótese de planejamento: dois profissionais PHP/WordPress experientes e QA/infraestrutura com dedicação de 50%, cinco dias úteis por semana. Dia-pessoa significa até oito horas úteis de trabalho técnico. A paralelização abaixo é opção de equipe futura, não delegação executada nesta revisão.

| Pacote de trabalho | Responsável por função | Esforço técnico estimado |
| --- | --- | ---: |
| P01/P02/P03/P07, baseline e laboratório | Responsável técnico + QA/infraestrutura | 4–6 dias-pessoa |
| Correções locais F03/F05/F06/F08–F15, N01/N02, regressões | Engenharia PHP + QA | 8–12 |
| C05, F02/F04/F07, migração de estado | Engenharia de persistência | 6–10 |
| C01/C02/C06, F01/F10, O01–O03 e credenciais | Responsável técnico de segurança + operação | 10–15 |
| P06, O12/O13/O14/O20 e integração F14 | Engenharia PHP + infraestrutura | 9–14 |
| Demais operações, retenção, UX e selftest | Engenharia PHP + QA | 5–8 |
| E01–E03/E06/E07 e cobertura de complementos | Engenharia de integração | 5–8 |
| E04/E05, upload/exportação por partes | Engenharia PHP | 4–7 |
| M01–M04, integração upstream e conectores | Engenharia MCP + QA | 5–8 |
| D01–D08, pacote, testes integrados e aceite | QA/documentação + operação | 6–9 |
| Incremento de 27/09: F16–F19/N03, extensão F13, testes e documentação associados | Engenharia PHP/MCP + segurança + QA | 7–12 |
| Incremento de 29/09: F20–F23/N04–N08 e adendos, incluindo testes/documentação | Engenharia PHP/persistência + segurança + QA | 15–26 |
| **Total preliminar atualizado** |  | **84–135 dias-pessoa** |

Há sobreposição de IDs entre especialidades; o orçamento da linha é pelo trabalho incremental e não duplica o mesmo callback. Reserva explícita de 20% para integração/recuperação: **101–162 dias-pessoa arredondados**. Com a equipe assumida, janela preliminar **12–20 semanas úteis desde T0**, incorporando dependências e aceite. Com uma pessoa ou indisponibilidade de homologação, reestimar; não reduzir a estimativa dividindo mecanicamente pelo número de agentes.

O incremento é estimativa preliminar adicional, sem duplicar os trabalhos de F01/perfis/retenção já orçados: F16 1,5–2,5; F17 0,5–1; F18 2–3; F19/F13 0,5–1; N03 1,5–3; integração documental/aceite 1–1,5 dias-pessoa. Total: 7–12. São faixas de esforço, não compromisso de publicação; a integração Elementor e os testes de autorização podem mudar a previsão em P07.

O incremento de 29/09 é custo adicional estimado sobre os serviços já previstos: F20 3–5; F21 1–2; F22 0,5–1; F23 3–6; N04/N05 1,5–2,5; N06 1,5–3; N07/N08 2–3,5; adendos F19/O08 1–1,5; documentação/integração 1,5 dias-pessoa. Total 15–26. Reestimar após fixtures; não usar o rótulo “pequenos” para esconder a concorrência de SQL ou a recuperação de PHP.

**T0** é o início efetivo com repositório/base, responsáveis nominais, ambiente, acesso autorizado de teste e disponibilidade confirmados. Não foi definido nesta revisão. Até T0+3 dias úteis, registrar nomes, capacidade e datas de calendário; recalibrar estimativas após P07/P03. O responsável técnico mantém uma linha por ID com status/evidência, impedimento, estimativa restante e data revisada. Operação responde por inventário e rotação; QA pelo aceite. Não atribuir conclusão de produção ao autor do código.

## 6. Marcos internos e janela de exposição

| Marco | Meta relativa, sob as hipóteses acima | Saída |
| --- | --- | --- |
| M0 | T0+3 dias úteis | Inventário inicial, responsáveis, datas de calendário, P07 reproduzível e baseline de regressões. |
| M1 | T0+5 a +10 dias úteis | F18 local prioritário e regressões F14/F08/F09/F11/F15/F16/F17; reprodução de F20/F21; F10/C02 com ações permitidas/negadas e uso legítimo do Elementor preservado. Recalibrar a capacidade no M0. Ainda sem publicação parcial. |
| M2 | T0+20 dias úteis | Persistência/migração, contexto e perfis integrados; matriz de credenciais pronta para ensaio. |
| M3 | Semanas 7–12 | Recursos restantes e protocolo integrados, com testes por contrato; demonstrar recuperação. |
| M4 | Semanas 12–20 | Suíte completa, documentação efetiva, piloto/aceite e pacote final pronto. |

As metas não são promessas de conclusão sem validação de P07 e alocação. No marco M0, substituir a janela por previsão com caminho crítico e atualizar semanalmente. Um desvio não autoriza reduzir o escopo sem decisão explícita.

**Exposição operacional:** correções prontas no M1 continuam sem efeito na frota até a publicação autorizada do pacote completo. Registrar incidentes, duração, frequência e custo; decisões futuras sobre alteração dessa regra pertencem ao dono. Até a release, o manual da 0.12.1 registra também os limites de redação SQL/exportação, inner_html com filhos, busca por diretório e recursos Elementor. Essas orientações e as anteriores sobre update/upload/binários não corrigem o runtime instalado. Mudanças operacionais em credenciais dependem do rollout autorizado; o servidor Elementor permanece disponível conforme decisão do dono.

## 7. Gate funcional e gate de implantação

**Gate do artefato completo:** os 83 itens implementados/validados ou, quando forem investigação, com resultado conclusivo ou inconclusivo explicitamente aceito pelo próprio critério; nenhuma funcionalidade obrigatória adiada. Ambiente P07, upgrade 0.12.1, testes de concorrência/fatal/revogação/portas externas, protocolo e contratos; fonte/instalador/docs do mesmo commit.

**Gate operacional da frota:** aceite em fator3-teste-mcp-1, pilotos e expansão do mesmo pacote; matriz conector→perfil preenchida, novas credenciais testadas, antigas revogadas e recusas verificadas. Metas propostas: piloto migrado junto à ativação, demais até D+5 dias úteis do início do rollout, Legado de rotina encerrado até D+7. Exceções administrativas temporárias têm responsável, justificativa e expiração. Não anunciar que O01 protege a frota enquanto todos permanecem Legado.

A ordem de implantação solicitada é **core → google → canal**, sob autorização do dono, com compatibilidade das etapas intermediárias verificada antes de publicar. Conferir cada número da matriz e anexar evidência; só a sessão de conferência da entrega retira itens do backlog da frota. A presente revisão não retira itens nem publica pacotes.

O instalador mantém runtime selecionado. Documentação de uso e de desenvolvimento vai com fontes/artefato separado; ajuda instalada e system/guide refletem os schemas homologados. Em OPERACAO não permanecem instruções de funcionalidade futura. O checklist não considera comparações de bytes entre cópias como prova de coerência de contratos.

## 8. Fontes e estado desta revisão

A revisão 5 analisou o plano revisão 4, manual e fonte 0.12.1; inspeção de AbilityRuntime, Packages, Pages, Database/SqlGuard, inicialização e docs de build. A análise recebida foi tratada como evidência relatada de produção. Nenhuma chamada foi feita aos 14 conectores, nenhuma credencial foi revogada e nenhum plugin foi atualizado.

Fontes oficiais consultadas e diferenças verificadas estão em [AVALIACAO-CRITICA.md](AVALIACAO-CRITICA.md). O [checklist](CHECKLIST-RELEASE-0.13.0.md) continua pendente de implementação/homologação. A revisão 6 relê a versão persistida do plano/manual/pacote, confere a base 0.12.1 por hash e inspeciona o código dos relatos de 25/09. Evidências locais e critérios novos estão em DEMANDAS-2026-09-27.md. Esta revisão altera planejamento e documentação; nenhuma correção funcional foi implementada aqui.

A revisão 7 incorpora o documento de frota recebido em 29/09, inspeciona os callbacks/decoradores e consulta referências oficiais de PHP/WordPress. A matriz DEMANDAS-2026-09-29 registra confirmações, inferências e divergências. A data de entrega solicitada não foi tratada como prova de conclusão.
