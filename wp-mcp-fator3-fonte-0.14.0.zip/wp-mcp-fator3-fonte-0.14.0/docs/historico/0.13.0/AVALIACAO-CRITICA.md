# Avaliação da crítica — WP MCP Fator3

24/09/2026 · Plano revisão 5 · Release única alvo **0.13.0**.

## Conclusão

A crítica identifica falhas reais no plano: premissas de frota antigas, autorização limitada ao transporte, migração de perfis sem prazo, persistência indefinida, falta de laboratório reproduzível e documentação misturando futuro e presente. Foram incorporadas as correções, mantendo todos os requisitos da entrega única determinada pelo produto.

Não foi adotado automaticamente o desdobramento em dois trens. A renumeração para 0.13.0, estimativas e marcos tornam o plano mais explícito; **não eliminam a espera das correções em produção**. Uma exceção de hotfix foi registrada como decisão a aprovar diante de incidente, sem publicação autorizada nesta revisão.

## 1. Premissas e verificação

O inventário de 14 conectores em MCP 0.12.1/WP 7.1.2/PHP 8.3.30 foi adotado como evidência do relatório recebido. Não repeti chamadas aos sites, incluindo a execução indireta que já gerou auditoria. Saem do gate rc.2 e multisite, coerentes com a frota relatada e a padronização. O baseline MySQL/Apache/cache ainda precisa de identificação precisa em P01/P07.

Há uma premissa desatualizada também na crítica: **o PR WordPress/mcp-adapter #310 está merged desde 21/09/2026 às 07:03:05 UTC**. O commit é `8bd4a67810da853683ab2e122af394cfe3b7b631`; seu composer.json usa `wordpress/php-mcp-schema ^0.2.0`. Isso remove a espera pelo merge, mas não a integração e os testes Fator3. A descrição declara explicitamente que MRTR não está incluído nesse PR. [PR #310](https://github.com/WordPress/mcp-adapter/pull/310) · [composer no commit](https://github.com/WordPress/mcp-adapter/blob/8bd4a67810da853683ab2e122af394cfe3b7b631/composer.json).

O fonte 0.12.1 anuncia **2025-06-18** em InitializeHandler e no teste de conexão. O upstream citado implementa **2025-11-25/2026-07-28**: compatibilidade com o cliente atual não pode ser presumida por chamar ambos de “legado”.

## 2. Decisões sobre os onze ajustes

| Ajuste | Avaliação e decisão |
| --- | --- |
| 1 — Gate/prazos | Crítica procedente sobre janela de exposição. Manter escopo único, estimar por pacote, atribuir papéis/datas relativas e explicitar contingência de hotfix sujeita a decisão. Não fingir que prioridade interna publica a correção mais cedo. Alvo passa a 0.13.0. |
| 2 — Outros executores/portas | Incorporado: F10 por comportamento/proveniência; C02 no permission_callback e antes do efeito; contexto validado em qualquer porta. Sem contexto, negar ações sensíveis/mutáveis, sem Legado implícito. P01 identifica registrador e uso do servidor default. |
| 3 — F01/perfis/SQL | Incorporados rotação/migração e aceite conjunto do isolamento. Rejeitada a frase absoluta de que F01 isolado não tem valor. Negar users/views é simplificação útil, mas precisa de subconjunto/allowlist de fontes e funções, incluindo outras tabelas com segredos e influência indireta. |
| 4 — F14 | Adotada estratégia B como implementação principal, com requisição interna autenticada, estado observado e resposta parcial. Corrigir/testar localmente sem esperar rebase ou todo P06; integrar backup/sonda na release completa. Comparar bulk_upgrade no laboratório, sem tratar troca de método como correção suficiente. |
| 5 — P06 | Usar o desenho e primitivas existentes do WordPress. Acrescentar diário, pré-carregamento da recuperação e sentinela/acionamento externo para falhas que o processo original não sobrevive. Não confundir sonda técnica autenticada com a anônima. |
| 6 — MCP | Requisitos detalhados e sessão opcional apenas no modo legado. Upstream já merged; fazer integração fixada. M01–M04 permanecem no gate da entrega completa por decisão vigente, sem dependência de merge futuro. |
| 7 — Persistência | Decidida: tabelas InnoDB próprias, dbDelta/migrações verificadas, índices de revogação e transações para código→token. affected_rows=1 é necessário, mas só o consumo condicional não torna atômica a emissão posterior. |
| 8 — Custo/demanda | F12 reutiliza o serviço interno de patch; não remover habilidade sem decisão de compatibilidade. E04/E05 mantidos com custo explícito e demanda ainda não demonstrada. E02 exige levantamento de cobertura Core/Yoast antes de criar rotas duplicadas. |
| 9 — F15 | Confirmadas três descrições e respostas parent_id. Entrada aceita parent_id como alias de parent, conflito recusado, zero preservado; saída mantém parent_id e acrescenta parent coerente. Cobrir list/create/update/get. |
| 10 — Documentação | Incorporado: OPERACAO só descreve 0.12.1 instalada e limites; futuro vai à preparação/especificações. Uma seção canônica por ID, referenciada pelos demais documentos. Coerência real depende de schema pós-decorador e testes de execução, ainda pendentes. |
| 11 — Testes | P07 incluído: ambiente reproduzível MySQL 8.0/PHP 8.3.30/Apache/WP 7.1.2, concorrência real, fixtures e CI. fator3-teste-mcp-1 fica para aceite. Total passa de 68 a 69 IDs. |

## 3. Correções de precisão

### Execução indireta e fronteira de confiança

AbilityRuntime::decorate da 0.12.1 envolve o **execute_callback** das habilidades identificadas como próprias, invocando a permissão original capturada. Não aplica ainda uma AuthorizationPolicy de perfil ao permission_callback. O prefixo wp-mcp-ultimate é excluído; não há classificação geral de delegadores de terceiros.

A chamada relatada de system/capabilities por mcp-adapter comprova um caminho de delegação. Sendo feita por administrador com amplas capacidades, ela não comprova sozinha escalada de um perfil restrito que ainda não existe. É suficiente para exigir teste de bypass da política futura. A convivência do servidor default com elementor-mcp-composer não identifica quem o registrou.

Mesmo contexto autenticado precisa resistir a falsificação: nome do conector/clientInfo não define identidade. Bloqueio da ability final e do executor externo são defesas complementares. Plugin malicioso no mesmo processo PHP e administrador do host ultrapassam a fronteira que um permission_callback oferece.

### SQL e privilégios administrativos

A base usa nomes de colunas/redação de saída, com lacuna em aliases; o texto de Database.php promete que hash de senha nunca é devolvido. Essa promessa será removida na implementação; o manual atualizado já registra o limite.

A decisão de projeto é restringir SQL a construções que possam ser reconhecidas e autorizadas sem resolver linhagem completa. Identificar a tabela real de usuários, negar views e fontes não permitidas, funções de acesso externo e SQL não compreendido. O teste abrange dados protegidos influenciando ordem, contagem, filtros e erros, além da projeção. Há bloqueios existentes de LOAD_FILE e algumas construções; preservá-los não substitui verificar todas as fontes/funções aceitas.

O exemplo do mu-plugin demonstra uma capacidade administrativa já concedida. F01 corrige exposição por db/query; O01 deve restringir escrita de PHP, instalação de plugins, SQL e leitura de segredos nas credenciais de rotina. Usuário dedicado com menor capacidade também limita outras APIs WordPress fora do canal. Nenhuma descrição anunciará sigilo global de dados para uma credencial que conserva execução administrativa.

### Atualização de plugins e recuperação

O código oficial mostra que upgrade() adiciona o hook de desativação; bulk_upgrade() segue outro fluxo e retorna resultados por plugin. No pacote, Packages::update chama upgrade() com Automatic_Upgrader_Skin e só verifica versão. Isso sustenta a causa do estado inativo; uma troca isolada de método ainda exige ajustar contrato, erros e verificação. [upgrade](https://developer.wordpress.org/reference/classes/plugin_upgrader/upgrade/) · [bulk_upgrade](https://developer.wordpress.org/reference/classes/plugin_upgrader/bulk_upgrade/).

A estratégia B reduz o impacto de falha no carregamento porque a tentativa ocorre em outra requisição. **activate_plugin não é isolamento de processo nem captura universal de fatal**: o coordenador precisa interpretar término abrupto e ler estado; efeitos anteriores de hooks não são transacionais. Resultado inativo/falha mantém HTTP disponível em parte dos cenários, sem assegurar que o site esteja funcionalmente íntegro. [activate_plugin](https://developer.wordpress.org/reference/functions/activate_plugin/).

O WordPress fornece backup/restauração temporária e detecção de fatal em auto-update. Isso não torna toda chamada de Plugin_Upgrader automaticamente coberta pelo fluxo completo. has_fatal_error é método protegido de WP_Automatic_Updater, depende de manutenção e inclui cookies/Basic Auth quando disponíveis; não satisfaz sozinho a sonda anônima solicitada. [WordPress 6.6](https://make.wordpress.org/core/2024/06/25/wordpress-6-6-field-guide/) · [has_fatal_error](https://developer.wordpress.org/reference/classes/wp_automatic_updater/has_fatal_error/) · [restore_temp_backup](https://developer.wordpress.org/reference/classes/wp_upgrader/restore_temp_backup/).

A sentinela mu-plugin precisa ser alcançada pelo bootstrap e acionada por requisição. Afirmar que ela restaura após qualquer morte do processo omite bloqueio por manutenção, fatal anterior ou ausência de tráfego. O ensaio P06 inclui essas falhas e define acionamento externo/contingência quando necessário.

### Protocolo e cache

A crítica sobre a dimensão da mudança é confirmada pelas fontes: 2026-07-28 muda ciclo de vida para requisições autocontidas. Sessões/initialize continuam somente na compatibilidade antiga. O contrato de cabeçalhos é condicional: Mcp-Method em requests; Mcp-Name nas operações em que existe nome/URI correspondente. [Versionamento](https://modelcontextprotocol.io/specification/2026-07-28/basic/versioning) · [Streamable HTTP](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/streamable-http).

ttlMs/cacheScope são exigidos nos resultados completos cacheáveis definidos na revisão, não indiscriminadamente em toda resposta de ferramenta. Listas filtradas por autorização precisam de cache privado. iss é recomendação normativa SHOULD do servidor; DCR permanece compatível apesar da depreciação. [Cache](https://modelcontextprotocol.io/specification/2026-07-28/server/utilities/caching) · [Mudanças](https://modelcontextprotocol.io/specification/2026-07-28/changelog).

## 4. Esforço, alternativas e vieses

O plano agora estima 62–97 dias-pessoa, com reserva de 20% e hipótese de equipe/ambiente explícita. Essa é inferência de engenharia a recalibrar após o laboratório, não previsão baseada em velocidade medida. Responsáveis nominais e T0 não foram inventados. A janela preliminar de 9–14 semanas torna visível o custo da entrega única, que continua sujeito à decisão do produto.

A alternativa de dois trens reduz a espera das correções, mas contraria a decisão anterior de não criar intermediárias. Não foi adotada silenciosamente. O hotfix excepcional também exige decisão, preservando o escopo completo posterior.

- **Falácia do planejamento:** risco presente quando esforço/dependências são omitidos; a faixa não elimina incerteza e será recalibrada com execução.
- **Viés de disponibilidade:** é correto evitar que um incidente obrigue uma plataforma inteira antes de corrigir a causa local. P06/O12/O13 continuam necessários às promessas adicionais de rollback, não à reprodução básica do F14.
- **Correlação e causalidade:** a desativação explica um mecanismo plausível para sumiço de funcionalidades SEO. O teste controlado entre fluxos, versões e ativação comprovará o efeito; não foi executado nesta revisão nem prova ausência de defeito no Yoast novo.
- **Viés de ancoragem:** também afeta a crítica se tratar “PR aberto”, “um método muda uma linha” ou “69 IDs” como medida suficiente de dependência/esforço. Estado e contrato de cada componente foram conferidos separadamente.

## 5. Estado das entregas

Revisados plano, manual e pacote documental; incluídos especificações canônicas, P07, checklist, estimativas e registro de decisões. O código continua 0.12.1. Não houve construção de instalador 0.13.0, teste funcional novo, alteração de produção, rotação de credenciais ou publicação de canal.
