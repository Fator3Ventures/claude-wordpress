# Registro superado — plano revisão 4

Preservado para rastreabilidade. Contratos, versões e gates deste registro foram substituídos pela revisão 5. Não usar como instrução de implementação.

# Plano de evolução e implantação — WP MCP Fator3

Base: 0.12.1 estável. Data inicial: 21/09/2026. Revisão atual: 24/09/2026.

Revisão 4: consolida **todo o plano em uma única próxima versão estável, 0.12.2**, conforme a decisão de 24/09/2026. Inclui os novos pedidos e a totalidade das funcionalidades e melhorias antes distribuídas por várias versões. As divisões abaixo organizam o trabalho interno; não são entregas intermediárias. Documentação e gates de publicação foram sincronizados. A implementação e a homologação continuam pendentes.

Este plano converte a análise `analise-wp-mcp-fator3-0.12.1.md` em entregas implementáveis. Incorpora a orientação de trabalhar exclusivamente no ambiente padronizado da Fator3.

## 1. Decisão de escopo

**Entregar uma única versão estável 0.12.2 com a totalidade do plano. Não haverá releases intermediárias de escopo parcial.** A divisão anterior entre 0.12.2, 0.13.0, 0.14.0 e 0.15.0 está substituída por esta decisão. Preservar todos os IDs e critérios de aceite.

| Bloco interno da mesma release | Escopo obrigatório |
| --- | --- |
| Preparação e qualidade | P01–P06; C01–C06 completos e melhorias de código da seção 4.4. |
| Correções e novos contratos | F01–F15 e N01/N02. |
| Operação, UX e administração | O01–O20 completos: perfis, conexões, executor de leitura configurável, operações, retenção, exclusões, pacotes/canal, sonda, catálogo, backups, selftest/cron, contagem e `system/guide`. |
| Conteúdo, arquivos e mídia | E01–E07 completos: metadados/SEO, blocos, transferência/exportação por partes, regeneração e ícone. |
| Protocolo e conectores | M01–M04 completos, com compatibilidade dos conectores existentes. |
| Documentação e fechamento | D01–D08; fontes, instalador, documentação, notas, contratos e evidências da mesma release. |

Os blocos são dependências de engenharia e homologação, sem publicar versões parciais. A liberação exige o conjunto completo aprovado. Recurso configurável/opcional no produto deve estar implementado e testado; isso não significa implementação opcional. Se algum item obrigatório não estiver concluído, a release aguarda sua conclusão, sem adiamento silencioso para outra versão.

### Ambiente de execução

- Uma instalação WordPress convencional por site; manter a homologação nessa pilha. O pedido de 24/09 acrescenta uma exceção pontual: conservar ativação em rede quando esse estado existir no update, com teste dirigido do ramo. Isso não abre matriz ampla de suporte multisite.
- Uma única pilha homologada: versões efetivamente usadas de WordPress, PHP, banco, servidor HTTP, cache e plugins Fator3.
- Ficam fora do plano adaptações e matrizes de compatibilidade entre MySQL, MariaDB, SQLite, versões alternativas de PHP ou diferentes topologias de hospedagem.
- Consultas SQL, persistência e concorrência serão verificadas somente no banco e na configuração usados pela Fator3.
- A preparação identifica essa configuração a partir do ambiente homologador, sem coletar senhas ou tokens. O uso de SQLite no laboratório da análise anterior não identifica o banco de produção.

O relatório da 0.9.3 informa um ambiente de referência: WordPress 7.1.1, PHP 8.3.30, MySQL 8.0.41, DreamHost compartilhado e ausência de object cache persistente. P01 confirmará essa configuração no homologador; não haverá matriz de bancos adicionais. O outro relatório informa treze sites ainda na 0.12.1-rc.2 por decisão operacional. Essa informação será usada para planejar migração direta da rc.2, sem exigir instalação intermediária da 0.12.1. As instalações da frota não foram consultadas nesta revisão.

**Inferência adotada:** a padronização permite concentrar implementação e validação em uma configuração conhecida. Ações simultâneas continuam ocorrendo nessa configuração; os testes de concorrência permanecem necessários.

### Contratos preservados

Manter a pasta e o arquivo principal do plugin, opções existentes, nomes das habilidades e das três ferramentas atuais, referências externas de conteúdo, backups e credenciais válidas. Preservar as URLs:

- Principal: `/wp-json/mcp/wp-mcp-fator3`.
- Compatibilidade: `/wp-json/mcp/wp-mcp-ultimate`.

Os dois endereços compartilharão identidade de conexão, política de acesso e execução. Alterações de SQL que restrinjam consultas antes aceitas serão documentadas como correção do contrato de proteção de dados. Novos campos de resposta serão aditivos.

Preservar o alcance de arquivos `php_reachable_paths`, registrado como comportamento esperado nos dois relatórios. O confinamento por WordPress continuará opcional. Perfis novos poderão restringir caminhos explicitamente; a atualização não converterá o perfil legado em confinamento por site.

## 2. Preparação e ordem de trabalho

| ID | Trabalho | Saída verificável |
| --- | --- | --- |
| P01 | Registrar a pilha padronizada e os conectores realmente utilizados. Identificar banco, cache e como processos PHP compartilham armazenamento. | Manifesto do ambiente, sem credenciais, e lista de clientes a homologar. |
| P02 | Fixar o fonte 0.12.1 e o instalador de referência. | Base identificada por hash e inventário das 100 habilidades, incluindo as três metahabilidades. |
| P03 | Transformar os probes F01–F07 em testes e acrescentar F08–F15 e os novos contratos N01/N02. | Defeitos reproduzidos falham na base e passam corrigidos; recursos novos têm testes de contrato. Distinguir incidente relatado, inspeção estática e reprodução executada. |
| P04 | Preparar cópia de homologação com dados sintéticos, Elementor quando instalado e atualização real pela interface WordPress. | Migração direta a partir da rc.2 e da 0.12.1, com snapshot para restauração. |
| P05 | Investigar o HTTP 429 relatado em `.well-known` por comparação de requisição, cabeçalhos e logs de hospedagem/plugins. | Origem identificada ou resultado inconclusivo documentado; não atribuir o bloqueio ao MCP sem evidência. |
| P06 | Definir e validar o caminho de recuperação independente antes de implementar atualização com reversão automática. | Decisão técnica com executor fora do pacote substituído, acionamento, autorização, diário persistido e ensaio de falha fatal; dependência de O12/O14. |

Hash do instalador de referência: `ef18f3ac5e18b89362ada4386b5397060cf8714faba44c2c7de32e3156353a53`.

Sequência técnica: correções e persistência → contexto de conexão e autorização → contratos de execução → funcionalidades operacionais → conteúdo/transferências → adaptador de protocolo.

A implementação deve confirmar a primitiva de persistência na pilha de P01. Usar um único armazenamento autoritativo para cada estado; criar somente os adaptadores necessários ao ambiente real.

## 3. Release única 0.12.2 — correções e novos contratos

| ID | Implementação | Critério de aceite |
| --- | --- | --- |
| F01 — SQL | Definir o subconjunto de leitura permitido; resolver origem de tabelas e colunas; ocultar campos protegidos e recusar construções sem origem verificável. Cobrir aliases, curingas, expressões, consultas derivadas, `UNION` e views. Manter limites de linhas, bytes e tempo. | Valores sintéticos das colunas protegidas não são expostos nem usados indiretamente em projeções. Consultas administrativas documentadas continuam funcionando no banco padronizado. |
| F02 — OAuth | Substituir leitura/exclusão separadas por consumo atômico. Validar cliente, PKCE quando aplicável, recurso e expiração dentro da operação protegida; confirmar persistência dos tokens emitidos. Unificar tratamento de chaves atuais e legadas. | Duas trocas válidas simultâneas geram um único consumo; a outra recebe erro reconhecível. Falha de persistência não devolve sucesso. Validar armazenamento e endpoint HTTP. |
| F03 — Permissão | Fazer `false`, `WP_Error` e exceção interromperem a autorização do transporte. Usar a regra padrão quando não houver callback específico. | Um usuário com a capacidade padrão continua bloqueado quando o callback específico recusa ou falha. |
| F04 — Sessões | Evitar atualização concorrente de um array inteiro. Usar registros individuais com gravação atômica e verificação, ou operação condicional equivalente no armazenamento escolhido. Aplicar à criação, atividade, remoção e expiração. | Duas sessões criadas simultaneamente permanecem válidas; excluir uma preserva a outra; nenhuma sessão é anunciada antes de ser persistida. |
| F05 — Clientes | Proteger cadastro/remoção concorrentes; substituir descarte do cliente mais antigo por recusa explícita de novos cadastros ao atingir a capacidade. | O 101º cadastro não remove os 100 anteriores; cliente autorizado permanece utilizável. |
| F06 — Transporte | Centralizar validação de origem, versão e respostas HTTP para ambos os endpoints; permitir clientes sem `Origin`; configurar explicitamente origens aceitas para clientes de navegador. | Origem não permitida é recusada; versão inválida recebe HTTP 400; notificação aceita recebe HTTP 202 sem corpo; clientes homologados continuam conectando. |
| F07 — Auditoria | Criar índice paginado com cursor estável e migrar o histórico de forma incremental. Consultas não dependem de varrer todos os arquivos. | Com mais de 10 mil registros recentes, primeira página e continuação funcionam sem `audit_scan_limit`; filtros utilizam o índice. |
| F08 — Upload de plugin | Respeitar `activate:false` e `overwrite:false` quando omitidos, em upload por URL e base64. Falha de ativação solicitada retorna falha com instalação/efeitos parciais explícitos. Aplicar ao upload a proteção já usada contra atualização do próprio servidor MCP. | Omissão não ativa nem substitui; substituição/ativação explícitas seguem o pedido; falha de ativação não declara a operação completa como sucesso; nenhum caminho de upload contorna a proteção do próprio MCP. |
| F09 — Arquivos binários | Aplicar à leitura integral a representação base64 quando os bytes não são texto UTF-8 válido ou o formato é identificado como binário, com schema e encoding. Tornar a representação de escrita inequívoca e recusar combinações contraditórias. | Leitura e regravação de imagem/fonte/ZIP preservam bytes e SHA-256; texto e SVG textual continuam suportados. |
| F10 — Recursão de metatools | Excluir as metahabilidades do catálogo operacional e impedir seu uso como alvo de qualquer executor, inclusive indireto. Manter as ferramentas expostas normalmente em `tools/list`. | Tentativas de executar o executor dentro dele mesmo falham imediatamente com código estável, inclusive em ambos os aliases e planos. |
| F11 — Patch de conteúdo | Manter `expected_revision`, lock e `wp_slash`; exigir unicidade por padrão, definir `all`/`limit` nos modos literal e regex e comparar o conteúdo persistido. | Regex respeita limite; revisão obsoleta conflita; readback traz SHA-256, bytes e `char_length`; divergência gera `content_filtered` com efeito real explícito. Contrato detalhado em 12.4. |
| F12 — Configuração de debug | Manter a habilidade desabilitada por padrão. Quando habilitada, usar o mesmo bloqueio e mecanismo de backup/gravação verificada de arquivos para `wp-config.php`, preservando permissões e proteção dos temporários. | `system/toggle-debug` disputa o mesmo recurso com `files/write`/`patch`, devolve backup e resultado verificado; não perde atualização concorrente nem expõe o conteúdo da configuração no retorno. |
| F13 — Erros e estados normais | Preservar a propagação de `success:false`/`isError` já existente; distinguir habilidade inexistente de acesso negado e conservar código estruturado. Tratar log ausente/desabilitado como estado normal. Corrigir acesso a campo `error` ausente no handler. | Falha de domínio chega como erro MCP sem warnings PHP; códigos existentes permanecem válidos; log ausente retorna `exists:false`; erro real de leitura continua sendo falha. |
| F14 — Ativação após update | Capturar ativação/versão antes da troca e restaurar o escopo anterior no mesmo fluxo da chamada; verificar estado, novo bootstrap, sonda e cache. | Plugin ativo permanece ativo; inativo permanece inativo; falha de reativação não retorna sucesso. Testar efeitos públicos de SEO/sitemap; detalhes em 12.2. |
| F15 — Contrato de página | Corrigir descrição `parent_id` para `parent`, preservando schema/callback e `expected_revision`. | `parent:0` remove a hierarquia, mantém revisão e persiste; descrição, schema e exemplo concordam. |
| N01 — Leitura por byte | Acrescentar `offset_bytes` como início explícito de leitura por bytes, com `byte_limit`, sem forjar cursor. | Cobrir EOF, offset fora do arquivo, UTF-8 cortado, binários, logs/ZIP e continuação por cursor. |
| N02 — Rewrite | Acrescentar `rewrite/flush` com `flush_rewrite_rules(false)`, estado fresco de permalink e readback das regras. | Regras de categoria/tag e contagens antes/depois; mudança funciona sem SQL, mantendo `rewrite_rules` protegido no editor genérico. |

Para F01, usar análise estruturada do dialeto efetivamente instalado. O contrato especificará as consultas aceitas e os erros para construções não suportadas. A proteção não dependerá apenas do nome apresentado pela coluna de saída.

Para F02, transients deixarão de atuar como garantia de consumo único. Uma reivindicação condicional no armazenamento autoritativo protegerá também a importação de credenciais legadas. Cache será invalidado após mudanças; não decidirá sozinho se uma credencial ainda é válida.

Para F07, o índice será reconstruível. Registros novos entram imediatamente; registros antigos são importados em lotes com checkpoint. Enquanto a migração não terminar, a consulta informa `history_complete: false` e progresso, sem apresentar uma página parcial como histórico completo.

As regras HTTP desta entrega atendem à revisão já declarada pelo servidor. A referência exige validação de origem, rejeição de versão inválida e status adequado para notificações. [Transporte MCP 2025-06-18](https://modelcontextprotocol.io/specification/2025-06-18/basic/transports).

As adições F08–F13 decorrem de inspeção estática nesta revisão; sua reprodução no ambiente homologador integra P03. Documentar as mudanças de comportamento em defaults de upload, patch com múltiplas ocorrências e invocação das metatools como alvo. F11 verificará o resultado sem inserir uma segunda camada de slashing; a causa do incidente de perda de barras relatado permanece a investigar.

F09 exigirá base64 quando a escrita declarar representação binária ou um formato inequivocamente binário. A política distinguirá formatos textuais como SVG; a extensão servirá como evidência auxiliar. F11 lerá o conteúdo persistido com `CHAR_LENGTH` e tamanho em bytes no mesmo readback, em consulta interna parametrizada no banco padronizado; o SHA-256 será calculado sobre os bytes observados. A revisão 24/09 substitui a orientação anterior de calcular somente o comprimento em PHP.

**Condição de liberação:** P01–P06, C01–C06, F01–F15, N01/N02, O01–O20, E01–E07, M01–M04 e D01–D08 concluídos conforme seus critérios, na pilha padronizada; migrações rc.2/0.12.1, jornadas nos dois endpoints e recuperação comprovadas. A revisão textual não conclui os testes. P06 antecede pacotes e canal próprio: a recuperação/autoatualização deve ser entregue com o mecanismo homologado; se ele não estiver pronto, a publicação completa fica pendente. Guardas continuam recusando execução em ambiente sem os pré-requisitos de recuperação.

## 4. Release única 0.12.2 — arquitetura e catálogo operacional

Todos os itens C01–C06 e O01–O20 integram a mesma release. A reorganização completa prevista, os perfis e todos os recursos operacionais serão implementados respeitando as dependências; não se limita esta entrega a um suporte mínimo para os pedidos recentes.

### 4.1 Componentes e dependências

Os nomes abaixo indicam responsabilidades propostas. A implementação poderá aproveitar classes existentes que já desempenhem essas funções.

| ID | Componente | Responsabilidade |
| --- | --- | --- |
| C01 | `ConnectionContext` | Identidade autenticada: usuário, cliente OAuth/concessão ou UUID da senha de aplicação, sessão, protocolo e origem da chamada. |
| C02 | `AuthorizationPolicy` | Interseção entre capacidades WordPress, perfil do conector, habilidade e recursos solicitados. |
| C03 | `ExecutionCoordinator` | Coordenar validação, autorização, idempotência, bloqueios, pré-condições, execução e verificação. |
| C04 | Contratos de resultado | Schemas específicos e tratamento consistente de sucesso, alteração, persistência, conflito e falha parcial. |
| C05 | Repositórios de estado | Operações atômicas e migrações para grants, sessões, planos, auditoria e idempotência na pilha adotada. |
| C06 | Contrato de extensões | Registro explícito de habilidades de complementos e adesão aos contratos Fator3. |

A ordem de execução será: identificar conexão → validar parâmetros → autorizar → verificar idempotência → adquirir bloqueios e verificar pré-condições → executar → verificar resultado persistido → registrar resultado/auditoria → responder.

Revalidar autorização antes de devolver um resultado idempotente e antes de cada passo de um plano. Registrar também recusas e falhas anteriores ao callback. Alterações de política revogada devem impedir novos passos e novas execuções.

Reorganizar `AbilityRuntime`, `Operations`, `ContentTools` e os componentes de suporte por etapas. Expandir instruções concentradas na mesma linha e nomear decisões intermediárias. Conservar o mecanismo de bloqueios já usado por arquivos, incluindo leitura, comparação de hash, backup e substituição na seção protegida.

Os repositórios terão apenas a implementação necessária ao ambiente padronizado. A extração de componentes servirá à compreensão e aos testes das regras do plugin.

### 4.2 Contrato de resultados

| Campo | Semântica proposta |
| --- | --- |
| `success` | A operação cumpriu o contrato solicitado. |
| `changed` | Houve alteração no alvo; `false` distingue operação válida sem mudança. |
| `persisted` | A persistência foi comprovada; usar `null` quando indeterminada e omitir em operações às quais não se aplica. |
| `applied` | Indicação de efeito aplicado, preservando `null` nos casos já tratados como incertos. |
| `error_code` | Código estável, interpretável pelo agente. |
| `conflict` / `retryable` | Orientam reconciliação e repetição; uma falha com efeito incerto não recebe repetição automática. |
| `operation_id` / `request_id` | Correlação entre requisição, execução, resultado e auditoria. |

Preservar os campos existentes e registrar a versão do contrato. Testes compararão schemas com respostas reais, incluindo erro, ausência de alteração, concorrência e persistência parcial. `success: true` dependerá da verificação prevista para cada habilidade.

### 4.3 Funcionalidades e critérios de aceite

| ID | Funcionalidade | Implementação e aceite |
| --- | --- | --- |
| O01 | Perfis por conector | Oferecer Leitura, Conteúdo, Manutenção e Personalizado. Restringir habilidades, tipos de conteúdo, caminhos e SQL. Descoberta, informações, executor genérico, planos e complementos respeitam a mesma política. Perfil nunca amplia capacidades WordPress. |
| O02 | Gestão de conexões | Exibir cliente, usuário, perfil, último acesso, sessões e revogação. Revogar a concessão bloqueia novas chamadas, renovação e próximos passos de planos vinculados. Tratar famílias de refresh e detectar reutilização. |
| O03 | `Execute Readonly Ability` | Ferramenta opcional, com classificação confiável de leitura e recusa de habilidades mutáveis ou não classificadas. O perfil também é aplicado ao executor genérico. Preservar as três ferramentas atuais. |
| O04 | `operations/list` | Listagem paginada de planos acessíveis ao usuário/conexão, com status, progresso e operações relacionadas. |
| O05 | `operations/preview` | Apresentar alvos, diferenças disponíveis, permissões, pré-condições, efeitos externos e capacidade de compensação por passo. Não executar callbacks mutantes para gerar prévia. |
| O06 | `operations/cancel` | Registrar pedido durante a execução e impedir os passos seguintes. Informar o resultado da etapa que já estava em andamento. Repetir o cancelamento não altera o resultado final. |
| O07 | Histórico e backups | Filtros por conector, usuário, habilidade, período e resultado; navegação por `operation_id`; ligação com backup e exportação sem segredos. |
| O08 | Retenção e manutenção | Limpeza incremental por categoria, idade e volume, com simulação, checkpoint, proteção de estados necessários e informações de espaço utilizado. |
| O09 | Diagnóstico e UX | Diferenciar registro local, teste HTTP, teste OAuth e acesso autenticado observado. Exibir versão de protocolo, última falha classificada e escopo de cada teste. JSON recolhível e copiável. |
| O10 | Integração dos complementos | Publicar contrato de registro, autorização, classificação e resultado. Homologar o complemento Google efetivamente instalado; comportamento legado permanece documentado durante a adoção. |
| O11 | Exclusões em duas fases | Prévia e confirmação vinculadas à conexão, alvo, parâmetros, revisão e expiração para exclusões permanentes. Cobrir usuários, mídia, plugins, comentários e conteúdo com `force:true`; manter o comportamento documentado de lixeira. |
| O12 | Atualização e reversão de pacotes — **0.12.2** | Staging, hash/slug esperados, pré-imagem, `plugins/rollback`, versões e ativação antes/depois. Compartilhar serviço com F14, incluindo sonda e cache. |
| O13 | `system/probe` — **0.12.2** | Sonda anônima de mesma origem, asserções e medição com procedência de cache/tempos. Proteção HTTP exige teste específico; critérios em 12.3. |
| O14 | Canal de atualizações Fator3 — **0.12.2** | Manifestos/`Update URI`/oferta nativa dos três pacotes, com dependências coordenadas e preservação do bloqueio de autoatualização até recuperação independente. |
| O15 | Descoberta e inventário econômicos — **0.12.2** | `if_catalog_sha256`, `unchanged`, projeções e `plugins/list` com `campos`/`prefixo`, normalizados para os campos descritos em 12.5. |
| O16 | Backups rotulados — **0.12.2** | `rotulo`/`label` nas mutações com backup, índice e filtros por rótulo/data; registros legados continuam consultáveis. |
| O17 | Diagnósticos explícitos — **0.12.2 completa** | Cron com desabilitação, eventos vencidos e último disparo observado; selftest com `passed`, `failed`, `skipped`, `not_configured`, alcance e contagens. |
| O18 | Contagem de tabelas — **0.12.2** | `db/schema` com tabela selecionada e `contar:true` (alias `exact`) retorna `rows_exact`; preservar estimativa em `rows_estimate` e alias legado `rows`. |
| O19 | Ajuda embarcada | `system/guide` fornece instruções da versão instalada por tema, contratos e exemplos; descrições de habilidades usam português consistente e parâmetros derivados do schema. Identificadores existentes permanecem estáveis. |
| O20 | Planos de atualização — **0.12.2** | Permitir upload/rollback após O12/F14; passos tipados de leitura/assertiva para probe/inventário. `db/execute` permanece fora; não injetar idempotência em schema que a recusa. |

#### Regras de perfis e migração

Conectores existentes recebem **Legado — permissões atuais**, com um registro explícito do acesso já disponível. Novas habilidades não ampliarão esse perfil silenciosamente. Novas conexões recebem um perfil selecionado na configuração da senha de aplicação ou na autorização OAuth.

Construir o perfil legado a partir do catálogo efetivamente exposto após o carregamento dos complementos instalados, preservando as capacidades WordPress e verificações por recurso. Incluir as habilidades Google e demais extensões já utilizadas; a lista de 100 habilidades do pacote principal não define sozinha esse catálogo. O aceite exige preservar o acesso anterior ao complemento Google e bloquear ampliação automática quando uma habilidade nova for adicionada depois.

A identidade virá da autenticação validada pelo servidor. `clientInfo`, nome amigável e parâmetros enviados pelo agente não identificarão a autorização. Credenciais antigas sem vínculo suficiente terão sua abrangência exibida; qualquer revogação com alcance maior será identificada na tela antes de ser executada.

Perfis controlam as chamadas MCP deste plugin. As demais APIs do WordPress seguem suas próprias permissões.

O01 inclui escopos OAuth coerentes com os perfis, anunciados nos metadados e explicados no consentimento. O escopo legado `mcp` permanece reconhecido nas concessões existentes. Restrição de leitura vale também no executor genérico: escolher outra ferramenta não amplia a concessão. Anotações MCP orientam o cliente; a política do servidor decide o acesso. O03 depende explicitamente da proteção F10.

O02 permitirá expirar após 24 horas cadastros que nunca concluíram autorização, desde que nenhuma concessão válida dependa deles. Clientes com concessões ativas não serão removidos para abrir espaço. A troca de transients por estado durável é parte de F02/C05; o risco descrito para Redis não cria uma nova matriz de teste em uma pilha que não o utiliza.

Para arquivos, validar caminhos normalizados, origem, destino, diretórios ainda inexistentes e links simbólicos. Aplicar a política novamente após resolver referências de passos anteriores. Habilidades de execução indireta recebem classificação e verificações próprias.

#### Regras de cancelamento e prévia

O pedido de cancelamento terá estado independente do bloqueio longo de execução do plano. `apply` consultará esse estado antes de iniciar cada passo e não o sobrescreverá ao salvar progresso.

Transição normal: `running` → `cancel_requested` → `cancelled`, após registrar o resultado da etapa em andamento. Se o resultado dessa etapa ficar incerto, a resposta preserva essa condição para reconciliação. `cancelled` não significará reversão dos efeitos já aplicados. Compensação será uma ação identificada, autorizada e limitada às etapas com inversa comprovável.

A prévia marcará cada passo como simulável, dependente de resultado anterior ou sem simulador disponível. Guardará revisão/hash dos alvos conhecidos e identificador da prévia. A aplicação verificará mudanças desde a prévia e pedirá nova avaliação por meio de erro de conflito quando necessário.

#### Regras de idempotência e retenção

O contexto novo poderá distinguir conexões do mesmo usuário. A transição consultará as chaves legadas antes de criar novo registro, com checagem de autorização e fingerprint. Atualização de versão ou alteração da chave de armazenamento não autorizará repetir um efeito antigo.

| Categoria | Tratamento inicial |
| --- | --- |
| Auditoria | Política configurável por idade e volume, com exportação e limpeza em lotes. Proposta inicial: 90 dias. |
| Backups | Exibir ocupação e simulação de limpeza. Preservar referências de planos e compensações. Exclusão automática exige política explicitamente habilitada. |
| Códigos OAuth e sessões expiradas | Remover por expiração, usando o estado autoritativo. |
| Idempotência concluída | Permitir compactar o resultado após a janela documentada, conservando comprovante de consumo/fingerprint que impeça repetição silenciosa. |
| Operação incerta ou plano ativo | Preservar até reconciliação ou encerramento explícito. |
| Referência externa de conteúdo | Preservar o vínculo estável. |
| Arquivos de bloqueio | Excluir da limpeza genérica. |

Os novos controles de retenção iniciarão em modo de simulação. O operador habilitará a política de exclusão após visualizar o alcance. Essa etapa é um comportamento de produto para operações destrutivas sobre o histórico.

#### Organização das telas

Manter **Conexão** e **Configurações** e acrescentar **Conectores**, **Operações** e **Histórico e armazenamento**. A organização final pode usar abas ou seções da página existente, com navegação consistente.

Na conexão: URL principal, alias de compatibilidade, copiar configuração e testar, com detalhes técnicos expansíveis. Não recolocar versão WordPress como pré-requisito visual. Na gestão de conexões: alcance do perfil e da revogação. Nas operações: estado, etapa atual, diferenças, cancelar e resultado parcial. No histórico: filtros, espaço e última manutenção.

Registrar separadamente testes iniciados pelo próprio plugin. “Acesso externo observado” dependerá de uma chamada autenticada identificável como externa; ausência de evidência será exibida como “ainda não observado”.

### 4.4 Qualidade de código

- Introduzir análise estática incremental com definições WordPress e padrões de código, começando pelos módulos alterados. Manter uma lista explícita de pendências antigas; falhas novas bloqueiam a entrega.
- Remover dependência de reflexão do caminho do callback conforme as habilidades adotarem o registro explícito. Preservar um adaptador transitório para habilidades legadas.
- Centralizar sanitização de erros e logs. Mensagens ao agente terão código útil e contexto necessário; tokens, senhas e payloads sensíveis não serão gravados em auditoria.
- Aplicar paginação no armazenamento e limites antes de materializar grandes resultados. Reduzir gravações repetidas de atividade de sessão.
- Fixar dependências, manter fonte revisável em Git e ligar pacote, versão e commit. Conservar a separação entre instalador e fonte/testes.

- Declarar em C06 a origem e versão de cada provedor de habilidades, além do contrato e schema. O núcleo, Google e Core terão registro explícito; provedor desconhecido será identificado como desconhecido. A inferência por caminho de callback não será o mecanismo principal de versão.
- Preservar os códigos de erro já públicos; preencher os casos ainda genéricos. Não renomear todos os códigos apenas para acrescentar um prefixo.
- Consolidar o buffer de auditoria legado com o histórico atual sem duplicar eventos nem fabricar registros ausentes. Acrescentar filtros por alvo/caminho, início e fim, incluindo leituras fora de `ABSPATH`.

### 4.5 Regras para as funcionalidades incorporadas dos relatórios

**Exclusões permanentes — O11.** A chamada de prévia enumera alcance, efeitos e possibilidades reais de restauração. `users/delete` exige `reassign_to` válido ou `delete_content:true` explícito. O token de confirmação é de uso único e perde validade se alvo, revisão, parâmetros ou autorização mudarem. Prévia e execução têm tratamento de idempotência próprio: produzir uma prévia não registra a alteração como concluída. A mesma execução confirmada pode devolver seu resultado anterior sem repetir a exclusão.

Consumo do token, revalidação e início da exclusão compartilham a seção protegida do alvo, com registro da execução antes do efeito. Duas confirmações concorrentes não executam duas exclusões. Interrupção após o efeito mantém estado incerto e a chave idempotente para reconciliação.

Para mídia, guardar originais, derivados e metadados necessários antes de excluir. O plano de restauração precisa tratar identidade/referências e apresentar resultado parcial quando não houver restauração completa. Copiar somente os arquivos não comprova reversibilidade da exclusão do attachment. O11 tem prioridade alta dentro da release única 0.12.2 e documentará a mudança de contrato dos agentes que hoje excluem em chamada única.

**Atualização de pacotes — O12/O14.** Fluxo: validar origem e baixar → conferir `expected_sha256` e `expected_slug` quando fornecidos, obrigatórios no canal de manifestos → inspecionar/extrair em staging → adquirir bloqueio → registrar pré-imagem e estado de ativação → instalar → ativar quando solicitado → verificar → registrar resultado. Qualquer falha anterior à substituição mantém o pacote atual. Uma reversão exige conferir que o destino ainda corresponde à operação revertida.

O rollback declara seu alcance: arquivos e estado de ativação verificados. Migrações de banco, opções e efeitos externos de hooks não são desfeitos automaticamente por restaurar o diretório. `backup_id`, `old_version`, `version`, `changed`, `activated` e resultado da reversão serão retornados conforme o que efetivamente ocorreu.

O manifesto terá identidade do pacote, versão, URL, SHA-256, requisitos e versão homologada. A integração usará `Update URI` e o filtro por hostname, com validação do pacote específico, cache, política de downgrade e HTTPS. Cabeçalhos e publicação dos manifestos de Core/Google são dependências coordenadas das respectivas releases. O hook oficial recebe a identidade, versão e pacote da oferta; declarar apenas o cabeçalho não implementa o atualizador. [API de atualização WordPress](https://developer.wordpress.org/reference/hooks/update_plugins_hostname/).

`plugins/list` devolverá `update_available` e `available_version`, compatíveis com a projeção de O15. Aceite: manifesto superior gera oferta visível, mesma versão não gera oferta e `plugins/update` confirma `old_version`/`version` após a instalação.

**Autoatualização do MCP.** A proteção contra sobrescrever o próprio servidor vale para todas as rotas até existir recuperação homologada que funcione quando o pacote novo não carregar. Um SHA-256 correto verifica o pacote esperado; a recuperação precisa de um caminho de execução independente dele. Até esse aceite, o pacote é oferecido à administração WordPress e o executor MCP recusa sobrescrita de si mesmo. A disponibilidade de oferta não habilita atualização automática sem a escolha operacional correspondente.

P06 deve abranger também um plugin atualizado que impeça o carregamento inteiro do WordPress. O ensaio verificará que o executor escolhido consegue restaurar o pacote nessa condição. Recuperação manual pela hospedagem será documentada como contingência com estado `recovery_required`; a indicação de rollback automático depende do executor independente demonstrado.

**Sonda anônima — O13.** O serviço envia apenas GET/HEAD à mesma origem de `home_url()`, revalida redirects, limita duração/bytes/quantidade e não encaminha cookies, Authorization ou cabeçalhos de autenticação fornecidos pelo cliente. Retorna URL final, status, cabeçalhos permitidos, hash e asserções, sem devolver indiscriminadamente corpos que contenham dados sensíveis.

O12 usa uma referência anterior à alteração e expectativas da pilha; `/` e `/wp-json/` não serão obrigados universalmente a responder 200. Distinguir regressão comprovada de timeout, cache, manutenção ou estado já falho. A política de reversão deve registrar o motivo e a verificação posterior. Provar recuperação de erro fatal em homologação é requisito para anunciar rollback automático nesse cenário.

Regressão comprovada aciona a reversão conforme a política da atualização. Retornar `failure_rolled_back` somente após conferir arquivos, versão e estado de ativação anteriores; falha ou incerteza na reversão retorna estado próprio, preserva backup/evidências e indica recuperação necessária. Esse estado se limita ao alcance de rollback declarado por O12.

`system/health` só marcará proteção HTTP testada após teste explícito de recurso privado com marcador inofensivo e limpeza garantida. HTTP 200 vazio de um envelope PHP não prova bloqueio de acesso a outros arquivos do diretório. Sonda iniciada pelo servidor continua sendo teste local; a prova de conectividade externa mantém estado próprio. Core consumirá o serviço quando presente, com adaptador definido em seu plano, evitando dois testes equivalentes.

**Descoberta — O15.** Acrescentar `if_catalog_sha256`, `unchanged`, `returned` e projeção `names|summary|full`. Índice por namespace será opção explícita; preservar o formato legado quando não houver parâmetros. Hash/cursor representam catálogo autorizado, perfil, filtros e projeção; mudança de política invalida o resultado anterior. O próprio hash condicional não altera a identidade da consulta. `plugins/list.prefixes` será uma lista de prefixos literais.

**Backups e instruções — O16/O19.** A orientação nova usa as habilidades de backup com rótulo e data; não exige criar cópias em `f3-mcp-backups/nomeados/` nem manipular o armazenamento privado por caminho. Backups antigos permanecem consultáveis. A cópia vigente localizada como `conector-wp-mcp (2).md` foi lida e revisada em 23/09/2026, com contratos atuais, alcance aberto, autoteste, erros, conflitos, `resource_busy` e retomada; as correções textuais passam a D01–D08 da 0.12.2. `system/guide`, novos estados de autoteste e rótulos integram integralmente a release única 0.12.2. Só serão recomendados como disponíveis após entrega. A skill operacional e outras cópias embarcadas do implantador requerem leitura da versão vigente no respectivo projeto antes de sua atualização coordenada; não foram modificadas nesta revisão.

O17 preserva compatibilidade dos campos legados do autoteste e documenta sua semântica. As novas contagens não incluem `skipped` ou `not_configured` como testes aprovados. Identidade PHP, raízes e limitações de ambiente só serão afirmadas quando verificáveis.

**Condição do bloco operacional da release única:** concluir C01–C06 e O01–O20, incluindo ampliação de selftest e ajuda embarcada. Conexão legada preservada, revogação efetiva e manutenção incapaz de repetir operações antigas. Para a 0.12.2, P06/O13/O12/F14 precedem a integração O14/O20; autoatualização do próprio MCP continua condicionada à recuperação independente.

## 5. Release única 0.12.2 — conteúdo, arquivos e mídia E01–E07

| ID | Entrega | Critério de aceite |
| --- | --- | --- |
| E01 | Metadados estruturados | Novas habilidades de leitura/atualização de metadados registrados, com tipos, schema, capacidades, campos protegidos, revisão e valor efetivamente salvo. |
| E02 | Adaptador SEO | Integrar os campos do plugin SEO presente na pilha, usando suas APIs. A presença do adaptador é anunciada nas capacidades; ausência do plugin retorna indisponibilidade explícita. |
| E03 | Validação de blocos | Validar estrutura e atributos antes da escrita; verificar conteúdo persistido; informar filtros que alteraram o conteúdo. Validar no editor os blocos usados nos sites da Fator3. |
| E04 | Upload por partes | Criar, enviar parte, consultar estado, finalizar e cancelar transferências. Validar tamanho, hash, propriedade, perfil e destino; permitir retomada e repetir uma parte idêntica com segurança. |
| E05 | Exportação de backup por partes | Exportar por cursor/parte, mantendo identificação e hash do conteúdo; retomar interrupções sem montar toda a exportação em memória. |
| E06 | Regeneração de mídia — **0.12.2** | `media/regenerate` valida attachment, capacidade e revisão; usa mecanismos WordPress e devolve arquivos/tamanhos reais e metadados persistidos. |
| E07 | Ícone do site — **0.12.2** | `media/set-site-icon` valida imagem/dimensões, executa o fluxo Site Icon e verifica opção, derivados e URLs. |

E01 depende de C02, C04 e C06. E02 depende de E01 e da versão homologada do plugin SEO. E03 usa os contratos de revisão e persistência. E04/E05 dependem das permissões por recurso, idempotência e retenção.

Na finalização de upload, montar primeiro o arquivo temporário; adquirir o bloqueio do destino; conferir perfil e `expected_sha256`; criar backup; substituir e verificar a gravação. Limpeza de partes abandonadas respeitará propriedade, atividade e prazo documentado. Uma mudança concorrente no destino retornará conflito sem sobrescrita.

A validação PHP de blocos terá escopo declarado. O aceite no editor verificará que os blocos utilizados não aparecem como inválidos após salvar e reabrir. Blocos de terceiros sem suporte serão identificados individualmente.

E06/E07 reutilizam bloqueios, idempotência e auditoria. Derivar os tamanhos de ícone do núcleo e filtros da instalação homologada; não fixar a quantidade em quatro. O WordPress possui fluxo específico para Site Icon. [Classe WP_Site_Icon](https://developer.wordpress.org/reference/classes/wp_site_icon/). Essas habilidades cobrem o uso relatado que hoje exige código temporário em produção; não será acrescentada uma habilidade genérica de executar PHP.

**Condição de liberação:** conteúdo e metadados persistidos correspondem ao resultado anunciado; transferências retomam sem corrupção e respeitam conflitos/perfis.

## 6. Release única 0.12.2 — evolução do protocolo MCP

| ID | Entrega | Critério de aceite |
| --- | --- | --- |
| M01 | Adaptador por revisão | Separar protocolo, transporte e executor; manter o fluxo de `initialize` para os clientes existentes. |
| M02 | Revisão MCP atual | Implementar os requisitos da revisão fixada para a entrega, incluindo descoberta e metadados por requisição quando exigidos; anunciar somente comportamentos implementados. |
| M03 | Client ID Metadata Documents | Acrescentar o mecanismo para clientes compatíveis, com validação de origem dos metadados, limites de busca e redirects; manter registro dinâmico para os clientes existentes. |
| M04 | Compatibilidade por cliente | Aprovar jornadas completas dos conectores usados pela Fator3, em ambas as URLs: autorização, descoberta, execução, renovação e reconexão. |

A referência revisada no planejamento é 2026-07-28: ela descreve versionamento por requisição, `server/discover` e coexistência com clientes que usam `initialize`. A implementação fixará a revisão e seus testes; a troca do número de versão será acompanhada das mudanças de comportamento correspondentes. [Versionamento MCP](https://modelcontextprotocol.io/specification/2026-07-28/basic/versioning).

O suporte a metadados de cliente será introduzido junto ao registro dinâmico já utilizado. A documentação recomenda Client ID Metadata Documents e mantém o DCR para compatibilidade. [Autorização MCP](https://modelcontextprotocol.io/specification/2026-07-28/basic/authorization).

Este bloco muda a comunicação com os conectores e exige homologação específica, além dos testes WordPress. É parte obrigatória da mesma release; a dependência não justifica versão intermediária ou adiamento do protocolo.

## 7. Migração e reversão

1. **Versionar o estado.** Registrar versão de schema e checkpoints de migração, separados da versão do plugin.
2. **Introduzir estruturas aditivas.** Manter registros anteriores durante a migração; novas estruturas só passam a ser autoritativas após verificação.
3. **Migrar em lotes.** A execução pode parar e continuar. Atualizações concorrentes devem ser reconciliadas por versão/condição, sem reconstruir arrays antigos por cima de dados novos.
4. **Preservar expirações.** Importação de código, token ou sessão não estende a validade original. Reivindicação de credencial legada e consumo novo compartilham a mesma garantia atômica.
5. **Preservar efeitos já executados.** Migrar idempotência, referências externas e vínculos de backups; não repetir uma ação por ausência do registro no novo formato.
6. **Documentar reversão por versão.** Antes de liberar, ensaiar restauração coordenada do plugin e do estado em homologação. Depois de novas operações, preferir correção progressiva quando a restauração do snapshot descartaria alterações válidas.

Tratar também tokens válidos cujos clientes já tenham sido removidos pelo defeito F05. Identificar a conexão como **Cliente legado sem cadastro**, a partir da credencial validada, e preservar sua validade restante e possibilidade de revogação. Não depender da presença na lista antiga para reconhecer essa concessão nem reconstruir URLs de redirecionamento sem comprovação. O teste de migração incluirá esse cenário.

Uma reversão não pode reativar credenciais revogadas nem tornar uma chave consumida disponível para nova execução. Conservar registros antigos auxilia recuperação, mas não autoriza um downgrade simples após mudanças de estado incompatíveis.

## 8. Homologação e implantação

### Testes obrigatórios na pilha padronizada

| Grupo | Cenários |
| --- | --- |
| Correções | Regressões F01–F15, incluindo ativação após update, contrato parent e SQL indireto, OAuth/sessões concorrentes, mais de 10 mil eventos, defaults de upload, recursão, binários, patches e escrita de debug. |
| Identidade e perfis | OAuth e senha de aplicação; dois conectores do mesmo usuário; executor genérico, ferramenta de leitura, planos e complementos. |
| Persistência e interrupção | Falha antes/depois de aplicar o efeito, resposta incerta e retomada. Operação executada antes da atualização e repetida depois com a mesma chave, pelos dois aliases, devolve o resultado anterior sem reaplicar o efeito. |
| Cancelamento | Pedido durante uma etapa, pedido repetido, impedimento da etapa seguinte e apresentação dos efeitos já realizados. |
| Revogação | Token atual, refresh, sessão, plano em andamento e credencial legada. |
| Migração | Atualização nativa, interrupção da migração, retomada, aliases e preservação de dados. |
| Retenção | Simulação, limites por lote, proteção de referências, backups e operações incertas. |
| UX | Configuração, copiar JSON, teclado/foco, estados de carregamento/erro e fidelidade do diagnóstico. |
| Protocolo e clientes | Jornadas reais dos conectores homologados, com ambas as URLs. |
| Pacotes e recuperação | Digesto/slug incorretos, ativação malsucedida, substituição, reversão com conflito e pacote que quebra o carregamento. Atualização de rc.2 e final; jornadas anônimas com Elementor. |
| Catálogo e diagnóstico | Hash inalterado, mudança de perfil, projeções, versões dos complementos, cron ainda não observado, estados do selftest e estimativa/contagem exata. |
| Exclusões e mídia | Confirmação expirada/reutilizada, alvo alterado, usuário sem destino explícito de conteúdo, restauração de mídia e derivados de ícone. |

Concorrência usará processos reais e o cache efetivamente habilitado. A homologação não exige bancos alternativos nem matriz multisite; há apenas o teste dirigido de conservação do escopo de ativação solicitado em F14. A recuperação independente P06 será definida para a hospedagem padronizada. Os testes de sintaxe e qualidade complementam as verificações de comportamento.

### Sequência de implantação da única versão completa

1. Construir instalador e fonte a partir do mesmo commit; conferir conteúdo e hashes.
2. Atualizar o ambiente homologador pelo mecanismo WordPress usado na operação.
3. Executar todos os testes do plano, migração e jornadas dos conectores. Os pilotos recebem o mesmo pacote funcionalmente completo aprovado, sem desdobrar o escopo em versões menores.
4. Na publicação futura, começar pelos dois pilotos com Elementor indicados no relatório, após confirmar quais sites compõem esse grupo e seus critérios de aceite. Manter os recursos novos ativados conforme o perfil definido.
5. Verificar autenticação, execução, renovação/reconexão, erros, conflitos, crescimento de estado e rotina de manutenção aplicáveis à entrega.
6. Expandir para os demais sites após o aceite dos pilotos. O número de instalações será confirmado no inventário; os treze sites são a contagem informada pelo relatório.

A sequência descreve a implantação futura. A elaboração deste plano não executa atualizações nos sites.

## 9. Como o plano foi construído

1. Os defeitos reproduzidos na análise receberam IDs F01–F07; a revisão estática dos relatórios acrescentou F08–F13 e seus testes de reprodução.
2. As funcionalidades foram ligadas aos componentes de identidade, autorização, persistência e resultado de que dependem.
3. A padronização retirou as matrizes de compatibilidade do escopo; o teste da operação real foi mantido como condição de liberação.
4. Recursos que alteram o protocolo foram separados dos recursos WordPress para permitir homologação e reversão próprias.
5. Cada entrega recebeu critérios de aceite, tratamento de migração e sequência de implantação.

O fatiamento anterior foi revogado pela decisão de release única de 24/09. P01–P04 iniciam a implementação, P05 investiga o diagnóstico e P06 antecede pacotes/canal. Os demais blocos se integram em uma única 0.12.2 completa, sem publicação intermediária.

## 10. Avaliação dos relatórios adicionais

Fontes recebidas: **R093**, `relatorio-wp-mcp-fator3-0.9.3.md`; **R121**, `relatorio 1 wp-mcp-fator3.md`. Ambos datados de 21/09/2026. A revisão abaixo confronta as sugestões com o fonte 0.12.1 já identificado por hash. “Existente” significa localizado no código; os incidentes e medições da frota permanecem evidências relatadas pelos autores.

### Relatório R093

| Item | Verificação e decisão | Destino |
| --- | --- | --- |
| 1 — Discovery sem filtros | Superado em parte: já existem `query`, `prefix`, `category`, `readonly`, `per_page`, `cursor`, `compact`, total e hash. Acrescentar projeções, contagens e resposta condicional. | O15 |
| 2 — Executor somente leitura | Pertinente e já previsto. Aplicar restrição no servidor, bloquear execução indireta e usar anotações coerentes nas ferramentas. | O03 + F10 |
| 3 — Exclusões destrutivas | Pertinente: confirmação prévia, destinação explícita do conteúdo do usuário e restauração de mídia com metadados. Debug já é desabilitado por padrão, mas sua escrita ainda precisa compartilhar lock/backup. | O11 + F12 |
| 4 — Escopos OAuth | Integrar aos perfis e à autorização de cada habilidade. Não limitar a proteção à escolha da ferramenta pelo agente. | O01/C02 |
| 5 — Tokens em transients | Já previsto por atomicidade/persistência. Perda por cache foi hipótese não testada nesse ambiente; não será tratada como incidente comprovado nem exigirá testar Redis. | F02/C05 |
| 6 — Poda de clientes | Já previsto; acrescentada expiração dos cadastros nunca autorizados, preservando concessões válidas. | F05/O02 |
| 7 — Envelope e erros | `isError` e propagação de falha já existem na 0.12.1. Completar códigos, distinção de inexistência/permissão e estado normal do debug; preservar contratos existentes. | F13/C04 |
| 8 — Auditoria sem habilidade | Superado: `audit/list` e `audit/prune` existem. Ampliar filtros e observabilidade; não duplicar a mesma função em `files/audit` e `db/audit`. | F07/O07/O08 |
| 9 — Contagem de tabelas | Confirmada a estimativa apresentada em `rows`. Adotar nomes explícitos e contagem exata opcional somente na tabela selecionada. | O18 |
| 10 — Metatools recursivas | Confirmado no código; promovido para correção prioritária. Preservar exposição MCP e recusar essas habilidades como alvo de execução. | F10 |
| 11 — Descrições divergentes | Corrigir textos falsos e parâmetros divergentes na 0.12.2; derivar a referência do schema efetivo. Padronização ampla e ajuda dinâmica integram a mesma 0.12.2. | D03/D05 + O19/C04/C06 |
| 12 — Selftest e alcance | Confirmada contagem de confinamento ausente como aprovado. Acrescentar status e alcance efetivo, mantendo o padrão aberto. | O17 |
| 13 — Skill desatualizada | Adotar ajuda versionada `system/guide`, equivalente funcional da proposta `wp-mcp/como-usar`; revisar os documentos externos vigentes em tarefa coordenada. | O19 |
| Não verificado — HTTP 429 | Causa não demonstrada; investigar hospedagem, regras e plugins antes de alterar código ou permissões. | P05/O09/O13 |

### Relatório R121

| Item | Verificação e decisão | Destino |
| --- | --- | --- |
| §0 — Limpeza de pacote | Já entregue; conservar como verificação de distribuição. Proteções locais do armazenamento existem, mas acessibilidade HTTP ainda exige teste próprio. | Empacotamento + O13 |
| §1 — Alcance aberto | Preservar o contrato e corrigir documentação que afirme confinamento obrigatório. | Contratos preservados + O17/O19 |
| A1 — Upload com reversão | Confirmado: não há pré-imagem; omissão de `activate` ativa. A revisão encontrou também `overwrite` omitido permitindo substituição e falha de ativação retornando sucesso. Corrigir os defaults primeiro e construir rollback com alcance verificável. | F08/O12/O13 |
| A2 — Atualização própria | Incorporar manifestos e ofertas WordPress com dependências nos outros pacotes. Hash não basta para liberar autoatualização do próprio MCP; exigir recuperação independente. | O14 |
| A3 — Sonda anônima | Incorporar. Já existe loopback autenticado pela interface; o recurso novo atende acesso anônimo com asserções. Ajustar a exigência universal de HTTP 200. | O13 |
| A4 — Patches de conteúdo | `expected_revision`, lock e `wp_slash` já existem. Faltam unicidade e conferência persistida. Causa da perda de barras não foi demonstrada; não duplicar slashing. | F11 |
| A5 — Catálogo e inventário compactos | Incorporar comparação condicional de hash, projeção de campos e prefixos literais. | O15 |
| B1 — Binários | Leitura integral com bytes crus confirmada. Adotar base64/encoding e teste por hash; preservar formatos textuais, incluindo SVG. | F09 |
| B2 — Rótulos de backup | Incorporar rótulos/datas. Orientar uso das habilidades sobre armazenamento privado; preservar backups legados sem criar nova árvore de cópias manuais. | O16/O19 |
| B3 — Contagem exata | Incorporar sob demanda e orçamento no banco padronizado, preservando o campo legado durante a transição. | O18 |
| B4 — Regeneração e ícone | Incorporar habilidades tipadas e fluxo específico de Site Icon; tamanhos vêm do núcleo instalado, sem pressupor quatro derivados. | E06/E07 |
| B5 — Planos de pacote | Incorporar upload após rollback e incluir passos de leitura/assertiva, também ausentes hoje. Adotar a conclusão do relatório que mantém `db/execute` fora dos planos. | O20 |
| C — Versão de provedores | Adotar metadados de origem/versão explícitos dos complementos, com desconhecido quando não houver informação confiável. | C06/O10/O15 |
| C — Cron | Incorporar estado de agendamento e último disparo observado, sem inferir execução a partir da simples existência do evento. | O17 |
| C — Espera de lock | A exposição do limite já existe. Documentar `resource_busy`, espera e repetição controlada; não aumentar o timeout como correção genérica. | O19 |

### Propostas ajustadas e limites da revisão

- Não acrescentar execução genérica de PHP, comando de frota que armazene credenciais de outros sites ou SQL mutante em uma única fase.
- Tratar duas fases como controle de confirmação de alcance; reversibilidade depende do backup e da operação específica. A tipagem da habilidade e a existência de um token não garantem, isoladamente, desfazer todos os efeitos.
- O incidente de atualização reforça a prioridade de O12/O13. Sua ocorrência não prova que qualquer HTTP diferente de 200 decorra de regressão do pacote; o desenho usa referência anterior e asserções específicas.
- Não considerar a presença de `.htaccess`, modo 0700 ou envelope PHP como teste HTTP realizado. O diagnóstico continuará distinguindo proteção configurada, proteção testada e acesso externo observado.
- As estimativas de esforço do R093 foram feitas sem leitura integral do código. O plano usa dependências e critérios de aceite, sem converter essas estimativas em compromisso de prazo.

### Evidências de código utilizadas nesta revisão

Referências relativas à raiz do plugin no fonte 0.12.1:

| Área | Referência |
| --- | --- |
| Discovery atual | `includes/SystemTools.php`, `schema()`/`discover()` |
| Erro MCP e execução indireta | `core/includes/Server/Abilities/ExecuteAbilityAbility.php`; `core/includes/Server/Handlers/Tools/ToolsHandler.php`; `core/includes/Server/Abilities/McpAbilityHelperTrait.php` |
| Defaults, exclusão do diretório e ativação no upload | `core/includes/Abilities/Helpers.php::install_plugin_zip`; `core/includes/Abilities/Plugins/Plugins.php` |
| Proteção de autoatualização | `includes/Packages.php` |
| Revisão e bloqueio do patch | `includes/AbilityRuntime.php::decorate`/`locked` |
| Patch e slashing | `core/includes/Abilities/Content/Pages.php`; `core/includes/Abilities/Content/Posts.php` |
| Binários | `includes/Files.php`; `includes/FileTools.php::read_cursor` |
| Usuários, mídia e debug | `core/includes/Abilities/Users/Users.php`; `Media/Media.php`; `System/System.php`; `includes/Domain.php` |
| Auditoria, backups, selftest | `includes/Audit.php`; `Backups.php`; `SelfTest.php` |
| Loopback e planos | `includes/ConnectionTest.php`; `includes/Operations.php` |


## 11. Revisão documental para a 0.12.2 — 23/09/2026

Registro histórico da revisão documental de 23/09. O manual e o pacote foram novamente sincronizados em 24/09 com a seção 12, conforme a seção 13. Isso atualiza a preparação; D01–D08 continuam condicionados à implementação, exemplos reais e conferência do pacote final antes da publicação.

### Resultado e limites

O pacote 0.12.1 documenta corretamente sua entrega de estabilização/empacotamento. O manual externo ainda descrevia a 0.9.1 e apresentava afirmações incompatíveis com o código atual. A revisão leu README, changelog, atualização, validação, testes, manifesto/build, schemas e callbacks correspondentes, além do plano vigente e de `conector-wp-mcp (2).md`.

O fonte corrente foi conferido byte a byte com o ZIP disponível; SHA-256: `dd5d5a4c8ec0e85da65dea5d284015563f9536d73da29005a7a43a1ece89ad7c`. A inspeção desta data não executou novo teste de produção, OAuth ou banco. Os relatórios de homologação da 0.12.1 permanecem históricos e não serão reutilizados como provas da 0.12.2.

**Inferência de planejamento:** as correções F01/F08/F10/F11 mudam contratos usados pelos agentes. Suas instruções e descrições precisam acompanhar a 0.12.2. A revisão de 23/09 permitia adiar O19; essa decisão foi substituída: a ajuda dinâmica é obrigatória na release única, além de corrigir manual e textos existentes.

### Divergências verificadas

| Tema | Evidência na base | Correção documental |
| --- | --- | --- |
| Escopo de arquivos | `PathGuard` e `system/capabilities` usam `php_reachable_paths` por padrão. | Confinamento opcional; identidade do site não limita automaticamente o alcance do PHP. |
| Identificação e inventário | Inventário próprio tem 100 registros, incluindo 3 metahabilidades; não contém `core/get-site-info`. | Identificar servidor por `system/capabilities`; usar habilidades de outro provedor somente após descoberta. Separar contagem do registro, catálogo operacional e `tools/list`. |
| Discovery | Filtros, paginação e hash já existem; `compact` esvazia descrições. | Retirar instrução de sempre trazer catálogo completo. Não antecipar a resposta condicional O15. |
| Patches de conteúdo | `expected_revision` e locks existem em update e patch; substituições podem ser múltiplas. | Retirar garantia genérica de maior segurança de patch; explicar pré-condição, unicidade futura e leitura posterior. |
| Hash parcial | `files/read` pode retornar `sha256_scope:returned_content`. | Usar hash integral de `files/stat` como pré-condição; explicar hash de origem/destino em copy/move. |
| Backups e exclusões | Backup é configurável; pasta vazia não gera backup; restauração de arquivo não recompõe o banco. | Explicitar limites; retirar disciplina de cópias nomeadas ao lado dos arquivos e usar as habilidades privadas. |
| SQL | Descrição promete “hash de senha nunca é devolvido”, apesar de F01; `rows` vem de `SHOW TABLE STATUS`. | Registrar o defeito conhecido e o contrato de proteção a validar; documentar contagem estimada. |
| Upload | `activate`/`overwrite` omitidos contradizem os defaults; ativação falha pode retornar sucesso. | Declarar parâmetros na base e documentar a mudança F08; conferir instalação, versão e ativação separadamente. |
| Diagnóstico e UI | Registro local e teste HTTP são distintos; JSONs já são recolhíveis; selftest usa contagem booleana. | Preservar UX existente, explicar cada prova e os limites do autoteste. |
| Build e evidências | `check_package.py` exige equivalência funcional à rc.2; `lab.py` usa SQLite no laboratório histórico. | Adaptar os critérios para os diffs funcionais da 0.12.2 e a pilha padronizada, sem alegar aprovação por instruções antigas. |

### Trabalho documental obrigatório da 0.12.2

| ID | Entrega | Situação nesta revisão e critério de aceite da release |
| --- | --- | --- |
| D01 | Guia operacional corrigido | Texto sincronizado em 24/09 com os pedidos 1–15 e a distribuição vigente; confirmar exemplos contra o ZIP final e atualizar a versão de referência na publicação. Cobrir URLs, descoberta, arquivos, conteúdo, SQL, pacotes, auditoria e limites. |
| D02 | README, changelog e estado de entrega | Preparação documental feita; manter 0.12.1 como versão do código até implementá-la. Na release, sincronizar `VERSION`, cabeçalho, constante, README, changelog, nomes de artefatos e hashes. Anunciar somente correções entregues. |
| D03 | Descrições e schemas expostos aos agentes | Implementação pendente. Corrigir em conjunto com F01–F15 textos falsos sobre SQL, binários, defaults, alcance e patch; incluir campos injetados pelo runtime. Preservar nomes técnicos, permissões e callbacks fora das mudanças funcionais aprovadas. |
| D04 | Migração e recuperação | Roteiro preparado; documentar formatos realmente adotados por F02/F04/F05/F07, checkpoints, retomada, credenciais preservadas e reversão testada. Não herdar a afirmação de “sem migração” da 0.12.1. |
| D05 | Referência verificável de contratos | Implementação pendente. Exportar schemas após `AbilityRuntime::decorate`, sob usuário/contexto identificados e sem credenciais; registrar versões, filtros e catálogo. Conferir exemplos e respostas reais de sucesso, falha e conflito. |
| D06 | Gates de pacote e homologação | Implementação pendente. Adaptar a comparação à rc.2 para mudanças funcionais esperadas e rastreáveis; manter build determinístico, lint e exclusão de arquivos de desenvolvimento. Executar a totalidade de F/N/C/O/E/M e os critérios P/D deste plano no ambiente padronizado e nos upgrades rc.2/final. |
| D07 | Links, histórico e distribuição | Patch documental sincronizado em 24/09; checklist de release incluído (seção 13). Manter relatórios históricos intactos e identificados; nenhum link de uso corrente deve apontar para documento removido. Documentação permanece nas fontes; `system/guide` exige implementação própria em O19. |
| D08 | Documentação externa coordenada | Manual localizado revisado. Identificar cópias ativas no implantador/skill, comparar a versão vigente e registrar adoção ou pendência com responsável. Não reescrever contratos do Core/Google sem conferir seus fontes e schemas atuais. |

D01/D02/D04/D07 têm texto antecipado; sua conclusão na release depende da implementação e conferência final. D03/D05/D06 são trabalho do código/build. D08 distingue a cópia revisada de outras distribuições do manual.

### Conteúdo mínimo das notas da 0.12.2

- Versões de origem rc.2 e 0.12.1; instalação pela substituição nativa, preservando pasta/arquivo principal, opções, URLs e credenciais compatíveis.
- Mudanças explícitas de defaults de upload, comportamento de patch, bloqueio de metahabilidades como alvo e SQL aceito/recusado.
- Representação efetiva de binários e exemplos válidos; compatibilidade de clientes que antes consumiam apenas `content`.
- Códigos de erro implementados e conduta de conflito/repetição; não inventar códigos antes de sua definição no contrato.
- Migrações de estado, histórico de auditoria parcial/completo e procedimento de retorno baseado no formato efetivamente entregue. Não prometer downgrade apenas pela troca do ZIP quando o estado for incompatível.
- Evidências da rodada no ambiente padronizado, incluindo ambos os endpoints, conexão existente e os pilotos definidos em P04. Resultados não executados devem ser declarados como tais.
- Entrega integral de perfis, gestão/retenção, selftest ampliado, ajuda dinâmica, metadados/SEO, transferências por partes e protocolo, além de pacotes/mídia e demais pedidos. Documentar limites reais de cada recurso sem usar o roadmap antigo para adiar uma funcionalidade obrigatória.

### Regra de publicação

Atualizar documentos no mesmo commit que altera comportamento. Primeiro fixar contrato e código; depois capturar schemas, validar exemplos e registrar os testes; por fim gerar instalador e fonte do mesmo commit. Promover uma afirmação de “previsto” para “disponível” somente quando houver implementação e evidência. A homologação padronizada permanece suficiente; a exceção pontual de ativação em rede está definida em F14, sem matriz ampla de bancos/multisite.


## 12. Pedidos de 24/09/2026 — escopo vigente da próxima release

### 12.1 Decisão e prioridade

**Incluir os itens 1–15 na 0.12.2**, com os ajustes técnicos abaixo. Todo o restante do plano também está incorporado na release única, preservando seus IDs. O item 15 repete a divergência de parent do item 11 e foi consolidado em F15. O item 16 veio sem conteúdo e não gera requisito.

| Pedido | Entrega na 0.12.2 | Prioridade |
| --- | --- | --- |
| 1 — Upload | F08 + O12: defaults, staging, pré-imagem, hash/slug, versões, rollback e sonda. | P0 para defeitos; P1 para fluxo completo |
| 2 — Canal próprio | O14: manifestos/integração nativa dos três pacotes; recuperação independente permanece obrigatória para autoatualização. | P1 |
| 3 — Probe/tempo/health | O13: sonda anônima, asserções, medição com evidência de cache e teste específico de proteção HTTP. | P1 |
| 4 — Patches | F11: revisão já existente; unicidade, limite regex, readback e content_filtered. | P0 |
| 5 — Discovery/list | O15: resposta condicional e projeção/filtro de inventário. | P1 |
| 6 — Binários | F09: base64 integral, representação de escrita e round-trip por hash. | P0 |
| 7 — Rótulos | O16: rótulo nas mutações/backup, datas e filtros, incluindo move. | P1 |
| 8 — Contagem | O18: tabela selecionada, estimativa e contagem exata sob demanda. | P1 |
| 9 — Mídia/ícone | E06/E07 na mesma release completa, usando APIs nativas e persistência verificada. | P1 |
| 10 — Planos | O20 após O12/F14/O13; upload e passos de verificação. SQL mutante permanece excluído. | P1 |
| 11 — Provedores/cron/lock | Identidade/versão de C06/O15, cron e selftest completo de O17; documentar espera efetiva. | P1 |
| 12 — Desativação no update | **F14:** restaurar ativação, verificar bootstrap novo, sonda e cache no mesmo fluxo. | **P0** |
| 13 — Offset por bytes | **N01:** offset_bytes, mantendo cursores existentes. | P1 |
| 14 — Rewrite | **N02:** rewrite/flush por API WordPress e readback. | P1 |
| 15 — parent | **F15 + D03/D05:** descrição/schema/exemplo e parent:0 com revisão. | P0 contratual |

A 0.12.2 reúne todos os itens deste plano, não apenas os pedidos da tabela. O01–O11, O17 completo, O19, E01–E05 e M01–M04 têm o mesmo prazo de entrega dos demais. Os IDs não representam releases já construídas.

Usar os controles atuais de autorização por capacidade/recurso, bloqueios, idempotência e auditoria. Concluir C01–C06 e a interface de perfis antes da publicação; os componentes atuais podem ser reaproveitados, sem reduzir o escopo aprovado.

**Evidências:** Packages::update não captura/verifica/restaura ativação; o retorno se limita à versão. Em Pages.php, schema/callback usam parent e a descrição usa parent_id. Em Pages/Posts, o ramo regex chama o helper sem limite; Helpers::guarded_preg_replace usa -1. files/read não recebe offset inicial por bytes; Options.php protege rewrite_rules e não integra explicitamente o flush.

O incidente Yoast 28.2 → 28.5 em korvena, os aproximadamente três minutos de degradação, a perda de bytes 13.463 → 4.373 e o TTFB de 1,1–2,8 s são **evidências relatadas pelo usuário**, sem reprodução nesta revisão. A inspeção confirma lacunas compatíveis com os relatos; não determina a causa da perda de barras/binários nem do TTFB. O arquivo exato pagespeed-2026-09-23-pacote.md, o Padrão único e o estado da frota não foram localizados com identificação inequívoca nesta revisão. Incorporam-se as referências pelo trecho fornecido, sem declarar conferência de seu conteúdo integral.

### 12.2 Pacotes: ativação, rollback e canal próprio

**F14 entra primeiro na implementação.** A atualização deve preservar ativação: ativo permanece ativo; inativo permanece inativo. Sucesso exige observar esse estado e a versão esperada.

1. Sob o lock compartilhado da árvore de plugins, registrar identificação, versão, hash da pré-imagem e ativação no site/rede quando existente. Validar autorização para atualizar e restaurar esse escopo.
2. Validar oferta/pacote, preparar staging e backup persistido antes de desativar/substituir. Divergência de hash/identidade falha antes da troca.
3. Atualizar e restaurar ativação no fluxo da mesma chamada MCP, sem clique/chamada posterior do agente. Preservar o escopo anterior; não converter ativação local em rede. Usar APIs WordPress, sem SQL sobre active_plugins.
4. Verificar carregamento em contexto PHP novo. O processo que iniciou o update já carregou a versão antiga; incluir arquivos novos nele não prova execução da nova versão e pode causar redeclaração. O executor de P06 deve permitir ativação/verificação isolada e retorno coordenado no fluxo, com recuperação se ocorrer fatal.
5. Confirmar versão e ativação; executar O13 e registrar os efeitos de cache. Falha de reativação ou recuperação retorna falha identificável e estado final observado.
6. Quando houver rollback, conferir destino sob lock, restaurar pré-imagem/ativação e repetir verificações. Recusar reversão que sobrescreveria alteração posterior de outra operação.

O upgrade nativo instala filtros de pré/pós-instalação. Fora do cron, a pré-instalação pode desativar silenciosamente; active_after não restaura ativação nesse caminho. Isso sustenta a correção da coordenação do canal. Referências: [upgrade](https://developer.wordpress.org/reference/classes/plugin_upgrader/upgrade/), [desativação](https://developer.wordpress.org/reference/classes/plugin_upgrader/deactivate_plugin_before_upgrade/), [active_after](https://developer.wordpress.org/reference/classes/plugin_upgrader/active_after/) e [activate_plugin](https://developer.wordpress.org/reference/functions/activate_plugin/).

**Retorno:** preservar old_version, version, changed e activated; acrescentar backup_id, active_before, active_after, escopos antes/depois, resultado da sonda e recuperação. Sem oferta, devolver também ativação observada e changed:false. Os aliases versao_anterior, versao e mudou espelham os canônicos. changed:true não comprova ativação; falha parcial informa arquivos novos/plugin inativo quando esse for o estado real.

**Contratos distintos:** plugins/update preserva ativação anterior; plugins/upload e upload-base64 seguem activate/overwrite, com defaults falsos corrigidos por F08. Upload não ganha ativação implícita por substituir uma versão antes ativa; documentar estado solicitado/observado.

**Cache e SEO:** verificar a home, REST efetivo e, quando SEO estiver presente, sitemap_index.xml, metadados e grafo esperados na referência anterior. Integrar a política de atualização ao cache da pilha: impedir armazenamento de respostas transitórias quando suportado e invalidar páginas afetadas após sucesso/recuperação, antes de aquecer/verificar. Informar se houve bloqueio de geração ou apenas invalidação. Concluir em uma chamada não garante ausência de janela de indisponibilidade. Não limpar caches de outros sites.

**O12:** pré-imagem abrange diretório e metadados necessários à restauração de versão/ativação. expected_sha256 refere-se aos bytes do ZIP baixado/decodificado; expected_slug identifica raiz/plugin esperados. Validar caminhos/estrutura antes da extração/substituição. plugins/rollback recebe backup vinculado à operação e exige destino compatível com sua pós-imagem. Restaurar arquivos não desfaz migrações de banco ou efeitos externos de hooks; declarar esse alcance.

**O14:** schema versionado do manifesto com identidade/arquivo principal, version, url, sha256, requires (WordPress/PHP explicitamente tipados) e tested com procedência de homologação. O filtro update_plugins_<host> transforma o manifesto em oferta nativa. Participam somente identidades/origens configuradas; conferir HTTPS, redirects, cache, versão e digest na instalação, inclusive pelo painel. Apenas declarar Update URI não valida hash.

O método atual de plugins/update consome o transient de ofertas WordPress; não contém a restrição de origem usada por plugins/install. O canal próprio deve alimentar o mecanismo nativo. A afirmação de que todo update é tecnicamente exclusivo de wordpress.org não descreve essa implementação. [Contrato do hook](https://developer.wordpress.org/reference/hooks/update_plugins_hostname/).

Core, Google e MCP precisam de cabeçalhos/manifestos coordenados e testes de oferta. O executor mantém bloqueio do próprio MCP até demonstrar recuperação independente. Para outros plugins, também testar pacote que impede o bootstrap WordPress: recuperação dependente desse bootstrap não satisfaz P06.

### 12.3 Sonda anônima, proteção HTTP e desempenho

system/probe será habilidade administrativa autenticada; suas requisições HTTP serão anônimas, sem cookies/credenciais do usuário. Receber caminhos relativos à origem de home_url(), GET/HEAD, asserções tipadas e limites de quantidade/tempo/bytes. Revalidar origem em cada redirect; não aceitar URL arbitrária nem Authorization. Resolver REST conforme permalinks/subdiretório.

O perfil padrão verifica home e REST; espera HTTP 200 quando esse é o contrato da instalação, documentando redirects canônicos. Medir antes/depois. Verificar corpo: página de erro pode retornar 200; rota previamente protegida pode responder outro status legitimamente.

**Ajuste da reversão solicitada:** não usar “qualquer não-200” isolado como causa automática. Asserção obrigatória já falha antes impede atualização automática por pré-condição falha. Se passa antes e falha depois, confirmar segundo política limitada de tentativas e reverter. Timeout/inconclusão têm estado próprio e não aprovam a operação. Política conservadora pode reverter por impossibilidade de verificar, identificando esse motivo sem atribuir causalidade ao pacote.

**Proteção HTTP:** system/health.http_protection_tested depende de teste específico com marcador inofensivo, mapeamento HTTP seguro do local pertinente, verificação de ausência de exposição e limpeza. Registrar escopo, data e fingerprint. Home/REST aprovados não comprovam proteção do armazenamento. Sem URL mapeável ou resultado conclusivo, manter false com motivo; não inventar URL nem buscar backups reais pela web. Health consulta a última evidência válida; teste novo é explícito e limitado.

**Tempos e cache:**

| Campo | Evidência necessária |
| --- | --- |
| total_ms | Duração observada da requisição HTTP. |
| ttfb_ms | Medição específica do transporte; se indisponível, null com motivo. Não usar tempo total como substituto. |
| generation_ms | Instrumentação PHP comprovada, com início/fim e trecho medido. Não equivale à latência total da rede. |
| cache_status | hit, miss, bypass ou unknown, com procedência de integração/cabeçalhos permitidos. |
| cache_bypass_verified | Verdadeiro somente quando o bypass de cache de página foi comprovado. |

Query aleatória ou Cache-Control:no-cache isolados não provam bypass. Homologar o adaptador de WP Super Cache na pilha e separar cache de página, CDN/proxy, object cache e OPcache. Bypass de página não torna os demais caches frios. Sem prova, classificar cache desconhecido e não anunciar “geração sem cache”.

Usar poucas amostras limitadas, devolver cada amostra/estatísticas e tamanho da amostra; não criar benchmark contínuo nem invalidar cache indiscriminadamente. O relato de 1,1–2,8 s orienta investigação, sem determinar a camada causal.

### 12.4 Conteúdo, encoding e leitura por bytes

**F11:** preservar revisão opaca, lock e wp_slash. Uniformizar literal e regex:

| Entrada | Semântica |
| --- | --- |
| Sem all nem limite positivo explícito | Exigir uma correspondência; zero é no-op, múltiplas recusam escrita. |
| all:true | Autorizar múltiplas; limit positivo limita em ambos os modos; omitido/-1 aplica a todas. |
| limit >= 1 explícito; all omitido | Seleção limitada explicitamente solicitada; mantém o uso anterior de limite. limit:1 não prova unicidade. |
| all:false | Exigir unicidade; limit > 1 é contraditório e será recusado. |
| limit:-1 isolado | Não autoriza substituição em massa; documentar exigência de all:true. |
| limit zero ou menor que -1 | Recusar e documentar a mudança de validação. |

O helper regex recebe limite, conserva guardas PCRE e restaura configurações em finally. Padrão inválido/exaustão não grava. Testar grupos, barras, substituição vazia, Unicode e hífens.

Depois de salvar, ler bytes persistidos por consulta interna parametrizada por ID com CHAR_LENGTH(post_content) e comprimento em bytes. Calcular sha256 desses bytes e comparar com o resultado pretendido; comprimento isolado não prova igualdade. Retornar char_length e bytes distintos. Divergência gera success:false, error_code:content_filtered, hashes esperado/observado e changed/applied/persisted conforme efeito observado. O código identifica divergência; não prova qual filtro a causou. Não repetir automaticamente nem adicionar slashing.

**F15:** parent permanece canônico; corrigir parent_id na descrição. Exemplo: {"id":15,"parent":0,"expected_revision":"<token-da-leitura>"}, com ID ilustrativo. Testar remoção da hierarquia, preservação de irmãos e conflito. Não renomear o schema nem aceitar silenciosamente campo desconhecido.

**F09:** leitura integral usa content_base64/encoding para binários e preserva bytes/hash. Escrita recusa content para lista documentada de formatos binários, exige base64 válido e recusa representações simultâneas. Preservar SVG/JSON/CSS/JS textuais; extensão auxilia classificação, sem provar integridade. Limites cobrem conteúdo decodificado e envelope. Cobrir perda relatada de 13.463 → 4.373 B com original, se disponível, e fixtures independentes com NUL/bytes não UTF-8. Essa medida não localiza a etapa da perda.

**N01 — offset_bytes:**

- Inteiro não negativo, zero-based, início explícito do modo byte, com byte_limit limitado.
- Excluir combinação com cursor, inclusive cursor vazio, e com offset/limit/tail_lines/grep/grep_regex.
- Manter cursor vazio para início legado; a string "0" continua inválida como cursor.
- Offset igual ao tamanho é EOF válido; maior gera erro de intervalo sem ajuste silencioso.
- Fazer seek e leitura limitada sob lock compartilhado, sem percorrer o conteúdo anterior. Retornar offset efetivo, bytes, tamanho observado, representação, hash parcial, sha256_scope:returned_content e cursor seguinte.
- Validar identidade/rotação na continuação. A verificação amostral atual não comprova snapshot integral entre chamadas nem detecta toda edição externa.
- Testar final de ZIP/log, corte UTF-8, truncamento/rotação, arquivo vazio e entradas contraditórias. A interpretação do diretório central do ZIP pertence ao consumidor.

### 12.5 Nomes, backups, cron e mídia

| Nome solicitado | Contrato |
| --- | --- |
| versao_anterior, versao, mudou | Aliases de saída de old_version, version, changed. |
| plugins/list.campos | Lista de campos permitidos; alias fields. Omissão preserva resposta anterior. |
| plugins/list.prefixo | Prefixo literal da identificação do plugin, normalizado para prefixes. Sem regex implícita. |
| rotulo | Alias de label; armazenar uma vez nos metadados. |
| db/schema.contar | Alias de exact; exige table explícita para contar. |
| system/health.cron | wp_cron_desabilitado, eventos_vencidos, ultimo_disparo, data e procedência da observação. |

Recusar aliases de entrada conflitantes; normalizar antes da idempotência/hash/filtros. Hash de descoberta representa catálogo/contexto autorizado, filtros e projeção; excluir if_catalog_sha256 e offset de paginação de sua identidade. Igualdade retorna unchanged:true sem reemitir catálogo; alteração de política/filtros/projeção invalida a reutilização.

**Rótulos:** cobrir files/write, patch, delete e move, além das mutações com backup já previstas. Move distingue origem/destino e IDs. No-op, novo arquivo ou rmdir sem pré-imagem não inventam backup_id. Legados mantêm rótulo ausente. Filtro literal e intervalo UTC com início inclusivo/fim exclusivo, combinável com paginação/caminho. Limitar comprimento e não usar rótulo como caminho físico.

**Contagem:** table válida + contar:true faz contagem exata sob orçamento. Retornar rows_estimate, rows_exact e data; timeout produz rows_exact:null e estado explícito. rows legado permanece estimativa. Não contar todas as tabelas nem extrapolar amostras.

**Provedores:** versão por registro explícito de identidade do plugin/provedor; integrar MCP/Core/Google. Quando não houver metadado confiável, usar desconhecido com motivo. Não preencher versão externa com a versão do MCP nem inferir por nome de função.

**Cron:** wp_cron_desabilitado reflete configuração, sem concluir que agendador externo parou. eventos_vencidos agrega quantidade/atraso com limites e sem expor argumentos dos jobs. ultimo_disparo registra um marcador efetivamente executado, timestamp e escopo; permanece null antes da primeira observação. Marcador executado não prova sucesso de todos os jobs; não usar instalação ou próxima agenda como último disparo.

**Locks:** documentar espera padrão de 2 s e valor efetivo em system/capabilities. Dois agentes recebem conflito/espera identificável. resource_busy permite repetição limitada conforme resposta; não orientar exclusão de lock ou repetição de mutação incerta.

**Mídia:** E06/E07 preservam original, attachment e metadados; retornam derivados produzidos, falhas por tamanho e opção persistida. Reaproveitar locks de attachment/uploads e coordenar site_icon. Derivar tamanhos do WordPress/filtros; não fixar quatro. Testar fonte insuficiente, falha de escrita, derivados existentes, repetição e concorrência. Não excluir arquivo referenciado como limpeza. O fluxo substitui a necessidade relatada de mu-plugin temporário.

### 12.6 Rewrite sem SQL

Adotar **rewrite/flush** como a solução tipada aprovada. Manter rewrite_rules protegido em options/update. Fluxo: alterar permalink_structure/category_base/tag_base pelas habilidades de opção e chamar regeneração explícita.

- Exigir capacidade administrativa e controles de mutação, auditoria e idempotência.
- Lock por configuração de rewrite compartilhado com as escritas dessas três opções, com ordem definida em relação aos locks de opção.
- Ler opções persistidas e renovar o estado de $wp_rewrite antes da geração; não confiar no objeto carregado antes das mudanças do mesmo plano/requisição.
- Executar flush_rewrite_rules(false) após registro das estruturas. O escopo é regenerar a option, sem gravar .htaccess.
- Capturar antes/depois: quantidades, hashes e regras de categoria/tag, limitando a resposta e marcando truncamento. Conferir persistência.
- Flush explícito, sem executá-lo a cada requisição. A resposta de options/update dessas chaves indica necessidade de regenerar enquanto o automático não existir.
- Testar categoria/tag, permalink de página/post, REST e sitemap quando presente; permissão, concorrência e no-op. Preservar estado anterior para recuperação administrativa sem prometer transação de hooks.

A alternativa com setters nativos e flush numa operação única não é uma segunda funcionalidade do escopo: N02 adota a rota explícita acima, que satisfaz o requisito sem SQL. O flush distingue regeneração da option e atualização das regras do servidor: [flush_rewrite_rules](https://developer.wordpress.org/reference/functions/flush_rewrite_rules/). [Setter nativo de permalink](https://developer.wordpress.org/reference/classes/wp_rewrite/set_permalink_structure/).

### 12.7 Ordem e aceite

1. P01–P04/P06: base, ambiente, regressões e execução/recuperação independente; confirmar cache dos pilotos.
2. F14, F08/F09/F11/F15 e demais F01–F13. Priorizar F14 não dispensa as correções anteriores.
3. O13/O12 compartilhados por upload/update/rollback: fatal, ativação falha, conflito de reversão, sonda inconclusiva e cache degradado.
4. O14/O20: manifestos dos três pacotes, planejamento sem efeito, aplicação com backup/ativação/sonda e reconciliação. db/execute permanece excluído.
5. Concluir todos os recursos C01–C06 e O01–O20, N01/N02, E01–E07 e M01–M04; respeitar as dependências de perfis, estado, conteúdo, transferências e protocolo. Esta sequência organiza a implementação, não releases.
6. D01–D08: finalizar os documentos sincronizados em 24/09 com a implementação e capturar catálogo real; executar o checklist documental da seção 13. Não manter contagem fixa de 100 após adicionar habilidades.
7. ZIP final, migração rc.2/0.12.1, pilotos e ambas as URLs; publicar fonte/instalador do mesmo commit, com evidências e recuperação.

**Cenários adicionais obrigatórios:** ativo/inativo; conservação pontual de ativação em rede; update sem oferta; ativação falha; nova versão com fatal; SEO/sitemap após update; HTML 200 degradado; não-200 prévio; cache hit/bypass confirmado/desconhecido; regex limitada; readback divergente; parent:0; seek/EOF; regras de categoria/tag e mídia com escrita parcial.

A próxima release é estável somente após os critérios. Esta revisão não executa updates, não publica manifestos e não apresenta incidentes relatados como testes reproduzidos.

## 13. Documentação distribuída — sincronização de 24/09/2026

### 13.1 Situação atual e fonte de verdade

O pacote documental e `conector-wp-mcp.md` foram alinhados à base 0.12.1 e a todos os pedidos 1–15 da seção 12. O item 15 está consolidado com parent do item 11; o item 16 permanece vazio, sem requisito presumido. Todos os blocos F01–F15, N01/N02, C01–C06, O01–O20, E01–E07, M01–M04, P01–P06 e D01–D08 estão identificados como obrigatórios na **release única 0.12.2**. Nenhuma atualização textual os torna implementados.

O código/schema efetivo define o que já funciona; este plano define o escopo aprovado a implementar. Se houver divergência, corrigir código ou escopo de forma explícita antes da liberação. Não adaptar o manual silenciosamente para transformar uma entrega incompleta em cumprimento do plano.

### 13.2 Documentos e locais de entrega

| Artefato | Conteúdo obrigatório | Distribuição |
| --- | --- | --- |
| README da raiz e do plugin | Versão real, instalação, URLs principal/legada, estrutura e vínculos atuais. | Pacote de fontes. |
| CHANGELOG | Mudanças efetivamente implementadas, mudança de defaults e de comportamento, limitações e data real. | Pacote de fontes e notas da release. |
| `docs/OPERACAO.md` | Contratos atuais, exemplos, erros, limites, concorrência, backup e recuperação; manual externo com os mesmos bytes. | Fontes e documentação entregue junto ao instalador. |
| `docs/ATUALIZACAO.md` | Atualização rc.2/0.12.1, migração, preservação de configuração/credenciais, retorno testado e limites. | Fontes e documentação da release. |
| `docs/PLANO-PROXIMAS-RELEASES.md` | Cópia deste plano, com situação implementada/pendente por item no fechamento. | Fontes. |
| `docs/PREPARACAO-0.12.2.md` e `docs/CHECKLIST-RELEASE-0.12.2.md` | Cobertura dos novos itens, pendências e critérios de liberação, sem aprovação fictícia. | Fontes. |
| Referência exportada e exemplos | Schemas após decoradores, nomes/defaults/aliases, capacidades/contexto, inventário por provedor e exemplos executados. | Fontes/documentação da release, sem credenciais. Gerar durante D05. |
| `docs/VALIDACAO.md`, testes e manifesto | Ambiente, testes realmente executados, origem do fonte, hashes finais e evidências de migração/recuperação. | Fontes, mantendo histórico separado. |
| Ajuda no painel e descriptions das abilities | Mesmo contrato do ZIP, incluindo defaults, parâmetros adicionados pelo runtime e falhas parciais. | Runtime do instalador; alterações junto com a implementação. |

Preservar a seleção de runtime do instalador. A documentação acompanha a publicação em arquivo separado e no fonte, sem expor relatórios, testes ou arquivos de desenvolvimento na pasta pública do plugin. A ajuda dinâmica `system/guide` (O19) integra esta mesma release e deve fornecer instruções da versão instalada.

### 13.3 Cobertura contratual obrigatória

D01/D03/D05 devem cobrir upload/rollback e SHA/slug, preservação de ativação no update, canal dos três pacotes, sonda/HTTP/cache/tempos, patch literal/regex e readback, binários, rótulos/datas, `if_catalog_sha256`, `campos`/`prefixo`, `contar`, mídia/ícone, planos com upload e sem SQL mutante, cron/provedores, lock de 2 s, `offset_bytes`, `rewrite/flush` e `parent:0`. A matriz em `docs/PREPARACAO-0.12.2.md` relaciona os novos pedidos ao contrato e à prova esperada, e a cobertura dos blocos inclui perfis, revogação, operações/retenção, exclusões em duas fases, selftest, ajuda, metadados/SEO, blocos, transferências e protocolo. Nenhum desses grupos é dispensado.

Capturar e validar nome, tipo, default efetivo, obrigatoriedade, aliases, combinações inválidas, pré-condições, efeitos, retorno, código de erro e conduta do agente. Distinguir hash de ZIP/arquivo/trecho, limite de linhas/bytes, estimativa/contagem, TTFB/tempo total/geração e falha sem alteração/falha com efeito persistido. Não publicar exemplos com parâmetros ainda inexistentes como instruções para a base 0.12.1.

### 13.4 Condição de liberação documental

1. Cada item implementado aponta para código, schema efetivo, documentação e evidência do pacote final. Funcionalidade obrigatória faltante impede liberação desta release; retirar do escopo exige decisão explícita.
2. A documentação de operação descreve o conjunto completo entregue; nenhum item obrigatório pode continuar marcado como previsto em versão posterior. Resolver todos os marcadores de preparação nos documentos correntes, mantendo registros históricos identificados.
3. Exportar contratos após os decoradores e confrontar descrições e exemplos. Exercitar sucesso, falha, conflito, permissões e aliases na pilha padronizada; todas as instruções devem corresponder a funcionalidades efetivamente presentes na release completa.
4. Conferir links, JSONs, contagens reais por provedor e igualdade entre cópias do manual/plano. `parent` é canônico; defaults de upload e nomes legados MCP/URLs devem estar consistentes.
5. Código, documentos, notas, fonte e instalador pertencem ao mesmo commit de release, com versões e hashes conferidos. Relatórios históricos não contam como execução atual; evitar hashes autorreferentes no manifesto.
6. Adaptar o build/validador para bloquear divergências de versão, contrato, inventário e cópias documentais. Este bloqueio automático ainda faz parte de D05/D06, não foi implementado nesta revisão textual.
7. Distribuir documentação junto dos artefatos finais e registrar as cópias externas sincronizadas. A atualização do manual conhecido não certifica skills/implantadores nem Core/Google que não tenham sido conferidos.

O checklist acompanha o pacote de preparação com os gates funcionais **pendentes**. Os checks documentais desta revisão não são homologação da 0.12.2.
