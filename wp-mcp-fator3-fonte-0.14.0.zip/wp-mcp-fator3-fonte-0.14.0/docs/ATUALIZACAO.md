# Atualização da 0.14.0

A sequência atual está em `GUIA-RELATORIO-0.14.0.md`, seção Migração. Não substitua diretamente o próprio canal pelo `plugins/upload` da 0.12.1. Use o migrador desta entrega e confira os hashes de `packages.json`. As duas URLs MCP permanecem funcionais.
