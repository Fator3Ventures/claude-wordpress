<?php
/**
 * Plugin Name:       WP MCP Fator3
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Plugin único com servidor MCP, OAuth, conteúdo WordPress, arquivos em qualquer caminho alcançável pelo PHP e banco de dados em duas fases. Substitui o complemento Fator3 e o WP MCP Ultimate separado.
 * Version:           0.12.1
 * Requires at least: 6.7
 * Requires PHP:      8.0
 * Author:            Fator3
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-mcp-fator3
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A versão anterior (pasta `f3-mcp-files`) ainda está ativa?
 *
 * Este plugin mudou de pasta ao ser renomeado, então o WordPress o trata como
 * instalação nova e as duas cópias podem ficar ativas ao mesmo tempo. Como
 * ambas declaram as mesmas classes, carregar as duas seria erro fatal e o site
 * cairia. O WordPress carrega os plugins em ordem alfabética, então a cópia
 * antiga vem primeiro: aqui, a nova percebe e sai de campo com um aviso em vez
 * de derrubar o site.
 */
if ( defined( 'F3_MCP_FILES_VERSION' ) || class_exists( __NAMESPACE__ . '\\PathGuard', false ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p><strong>WP MCP Fator3:</strong> %s</p></div>',
				esc_html__( 'a versão anterior deste plugin (Fator3 MCP Files, pasta f3-mcp-files) continua ativa. Desative e apague aquela cópia; enquanto isso, esta não carrega.', 'wp-mcp-fator3' )
			);
		}
	);
	return;
}

define( 'F3_MCP_FILES_VERSION', '0.12.1' );
define( 'F3_MCP_FILES_DIR', plugin_dir_path( __FILE__ ) );
define( 'F3_MCP_UPSTREAM_VERSION', '2.1.0' );
define( 'F3_MCP_UPSTREAM_COMMIT', 'd5eff50ff3d5609fa491dfb9af7946c261b00c89' );
require_once F3_MCP_FILES_DIR . 'includes/ConnectionEndpoints.php';
require_once F3_MCP_FILES_DIR . 'includes/ConnectionStatus.php';
require_once F3_MCP_FILES_DIR . 'includes/ConnectionTest.php';
add_action('init', static function (): void { $route = ConnectionEndpoints::request_route(); if (null !== $route && ConnectionEndpoints::matches($route)) ConnectionEndpoints::no_cache(); }, 0);
require_once F3_MCP_FILES_DIR . 'includes/Migration.php';
Migration::init();

// Wait until every active plugin has loaded: the legacy entrypoint defines
// unguarded constants. Sharing its runtime temporarily avoids double loading,
// independently of the order of active_plugins or network-active plugins.
add_action( 'plugins_loaded', static function (): void {
	if ( defined( 'WP_MCP_ULTIMATE_DIR' ) ) {
		add_action( 'admin_notices', static function (): void {
			if ( current_user_can( 'activate_plugins' ) ) {
				echo '<div class="notice notice-warning"><p><strong>WP MCP Fator3:</strong> atualização instalada. Desative e exclua o WP MCP Ultimate separado para concluir a migração e usar as correções do núcleo integrado. Mantenha o Fator3 ativo durante a exclusão para preservar as credenciais.</p></div>';
			}
		} );
		return;
	}
	Migration::migrate();
	require_once F3_MCP_FILES_DIR . 'core/bootstrap.php';
}, 1 );


require_once F3_MCP_FILES_DIR . 'includes/PathGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Support.php';
require_once F3_MCP_FILES_DIR . 'includes/Domain.php';
require_once F3_MCP_FILES_DIR . 'includes/Locks.php';
require_once F3_MCP_FILES_DIR . 'includes/Backups.php';
require_once F3_MCP_FILES_DIR . 'includes/Audit.php';
require_once F3_MCP_FILES_DIR . 'includes/AbilityRuntime.php';
require_once F3_MCP_FILES_DIR . 'includes/DatabaseWriter.php';
require_once F3_MCP_FILES_DIR . 'includes/DatabaseBudget.php';
require_once F3_MCP_FILES_DIR . 'includes/ContentTools.php';
require_once F3_MCP_FILES_DIR . 'includes/FileTools.php';
require_once F3_MCP_FILES_DIR . 'includes/Packages.php';
require_once F3_MCP_FILES_DIR . 'includes/Operations.php';
require_once F3_MCP_FILES_DIR . 'includes/SystemTools.php';
AbilityRuntime::init();
require_once F3_MCP_FILES_DIR . 'includes/Http.php';
require_once F3_MCP_FILES_DIR . 'includes/SqlGuard.php';
require_once F3_MCP_FILES_DIR . 'includes/Database.php';
require_once F3_MCP_FILES_DIR . 'includes/SelfTest.php';
require_once F3_MCP_FILES_DIR . 'includes/FileReader.php';
require_once F3_MCP_FILES_DIR . 'includes/Files.php';
require_once F3_MCP_FILES_DIR . 'includes/Admin.php';

/**
 * Registra as habilidades na Abilities API.
 *
 * `wp_abilities_api_init` é disparado tanto pelo WordPress 6.9+ nativo quanto
 * pelo polyfill do núcleo integrado. Uma vez registradas, as
 * habilidades aparecem no `discover-abilities` e podem ser chamadas pelo
 * `execute-ability` do servidor MCP integrado.
 */
add_action(
	'wp_abilities_api_init',
	static function (): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}
		Files::register();
		Database::register();
		ContentTools::register();
		FileTools::register();
		Packages::register();
		Operations::register();
		SystemTools::register();
	}
);

Admin::init();

/**
 * Protege as opções deste plugin contra a habilidade options/update.
 *
 * A lista de proteção padrão do WP MCP Ultimate cobre ~23 nomes fixos e
 * libera todo o resto. Sem isto, o agente poderia reabrir o canal depois de
 * você fechá-lo, ou apagar o próprio log de auditoria, com um options/update.
 *
 * Isto não é contenção contra um agente comprometido — quem tem
 * `install_plugins` já pode instalar PHP arbitrário. É para que o botão
 * "fechar o canal" signifique o que promete no uso normal.
 */
add_filter(
	'wp_mcp_ultimate_protected_options',
	static function ( $protected ) {
		if ( ! is_array( $protected ) ) {
			$protected = array();
		}
		$protected[] = PathGuard::OPTION_ENABLED;
		$protected[] = 'f3_mcp_files_audit';
		$protected[] = Database::OPTION_WRITES;
		$protected[] = Migration::MARKER;
		$protected[] = Migration::CLIENTS;
		$protected[] = 'f3_mcp_settings';
		return $protected;
	}
);

/**
 * Ativar o plugin abre o canal — ativar já é o ato humano explícito.
 */
register_activation_hook(
	__FILE__,
	static function (): void {
		add_option( PathGuard::OPTION_ENABLED, true, '', true );
		add_option( Database::OPTION_WRITES, true, '', true );
	}
);

/**
 * A Abilities API existe nesta instalação?
 *
 * Vem do WordPress 6.9+, ou do polyfill integrado. Sem ela,
 * `wp_abilities_api_init` nunca dispara e este plugin não
 * registra rota nenhuma.
 */
function f3_mcp_files_abilities_api_disponivel(): bool {
	return function_exists( 'wp_register_ability' );
}

/**
 * Existe algum servidor MCP para expor as rotas para fora?
 *
 * Registrar habilidades não basta: elas ficam no WordPress e ninguém de fora as
 * alcança sem um servidor MCP. O núcleo integrado cumpre esse papel;
 * a checagem preserva o filtro de compatibilidade existente.
 */
function f3_mcp_files_servidor_mcp_detectado(): bool {
	return ConnectionStatus::snapshot(false)['core_loaded']
        || (bool) apply_filters('f3_mcp_files_servidor_mcp_detectado', false);
}

/**
 * Avisos no admin — apenas pré-requisito ausente.
 *
 * Não há aviso de estado do canal: ele aparecia em toda visita à tela de
 * Plugins e não informava nada que a própria tela de controle não mostre. O que
 * sobra aqui é só falha silenciosa: sem a Abilities API o plugin ativa, a tela
 * diz "ABERTO" e nada funciona — isso precisa gritar.
 */
add_action(
	'admin_notices',
	static function (): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! f3_mcp_files_abilities_api_disponivel() ) {
			printf(
				'<div class="notice notice-error"><p><strong>WP MCP Fator3:</strong> %s</p></div>',
				esc_html__( 'a Abilities API não foi carregada. O pacote inclui o polyfill para WordPress anterior ao 6.9. Reinstale este ZIP e confira os requisitos de WordPress e PHP.', 'wp-mcp-fator3' )
			);
			return;
		}

		if ( ! f3_mcp_files_servidor_mcp_detectado() ) {
			printf(
				'<div class="notice notice-warning"><p><strong>WP MCP Fator3:</strong> %s</p></div>',
				esc_html__( 'o servidor MCP integrado não foi carregado. Reinstale este ZIP e confira o log de erros do WordPress.', 'wp-mcp-fator3' )
			);
		}
	}
);

/**
 * Atalho "Configurar" na linha do plugin.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	static function ( array $links ): array {
		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=wp-mcp-fator3' ) ) . '">'
				. esc_html__( 'Configurar', 'wp-mcp-fator3' ) . '</a>'
		);
		return $links;
	}
);

/**
 * Desativar o plugin já remove as habilidades do registro; nada a limpar.
 *
 * Os backups são preservados de propósito — desativar não deve destruir a
 * única cópia de um arquivo que alguém pode precisar restaurar.
 */
register_deactivation_hook(
	__FILE__,
	static function (): void {
		// Intencionalmente vazio, e documentado para deixar claro que a
		// preservação dos backups é decisão, não esquecimento.
	}
);
