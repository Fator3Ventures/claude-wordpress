<?php
declare(strict_types=1);
namespace WpMcpUltimate\Admin;
/** Public class preserved for integrations; Fator3 owns the complete admin page. */
class Dashboard {
    public static function init(): void {}
    public static function add_menu_page(): void {}
    public static function render_page(): void { \Fator3\McpFiles\Admin::render(); }
    public static function enqueue_assets(string $hook): void { \Fator3\McpFiles\Admin::assets($hook); }
}
