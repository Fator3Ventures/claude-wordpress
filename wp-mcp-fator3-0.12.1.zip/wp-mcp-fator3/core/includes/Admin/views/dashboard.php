<?php
/** Legacy view entrypoint delegates to the unified page. */
declare(strict_types=1);
defined('ABSPATH') || exit;
\Fator3\McpFiles\Admin::render();
