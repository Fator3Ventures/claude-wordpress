/* global f3McpAdmin */
(function () {
    'use strict';
    function init() {
        const root = document.querySelector('.f3-mcp-admin');
        if (!root || typeof f3McpAdmin === 'undefined') return;
        let credential = null;
        let auth = 'oauth';
        const get = id => root.querySelector('#' + id);
        const feedback = (message, error) => {
            const el = get('f3-feedback');
            el.hidden = false; el.textContent = message;
            el.classList.toggle('is-error', !!error);
        };
        const configs = () => {
            root.querySelectorAll('[data-client]').forEach(panel => {
                const client = panel.dataset.client;
                let entry = {url: f3McpAdmin.endpoint};
                if (client === 'claude-code') entry = {type: 'http', url: f3McpAdmin.endpoint};
                if (auth === 'password') entry.headers = {Authorization: 'Basic ' + (credential || 'BASE64_USUARIO_E_SENHA')};
                if (client === 'desktop') {
                    const args = ['-y', 'mcp-remote', f3McpAdmin.endpoint];
                    if (auth === 'password') args.push('--header', 'Authorization: Basic ' + (credential || 'BASE64_USUARIO_E_SENHA'));
                    entry = {command: 'npx', args};
                }
                get('f3-json-' + client).textContent = JSON.stringify({mcpServers: {'wp-mcp-fator3': entry}}, null, 2);
                panel.querySelector('.f3-config-note').textContent = auth === 'oauth' ? 'Configuração para OAuth: autorize o acesso no cliente.' : credential ? 'Contém a credencial recém-gerada. Guarde em local restrito.' : 'Modelo com campo a preencher: informe o Base64 de usuário:senha. Senhas antigas não são recuperadas nesta tela.';
            });
        };
        const resetSecret = () => {
            credential = null;
            if (get('f3-key-value')) get('f3-key-value').textContent = '';
            if (get('f3-key-output')) get('f3-key-output').hidden = true;
            configs();
        };
        const request = async (action, params) => {
            const response = await fetch(f3McpAdmin.ajaxUrl, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: new URLSearchParams(Object.assign({action: 'wp_mcp_ultimate_' + action, nonce: f3McpAdmin.nonce}, params || {}))});
            let json;
            try { json = await response.json(); } catch (e) { throw new Error('Resposta inválida. Atualize a página para renovar a sessão.'); }
            if (!response.ok || !json.success) throw new Error(json.data && json.data.message || 'Não foi possível concluir a operação. Atualize a página e tente novamente.');
            return json.data;
        };
        const busy = async (button, text, callback) => {
            if (button.disabled) return;
            const label = button.textContent; button.disabled = true; button.textContent = text;
            try { await callback(); } catch (e) { feedback(e.message, true); }
            finally { button.disabled = false; button.textContent = label; }
        };
        async function copy(button) {
            const el = get(button.dataset.copy);
            if (!el) return;
            try {
                if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(el.textContent);
                else {
                    const area = document.createElement('textarea'); area.value = el.textContent; area.style.position = 'fixed'; area.style.opacity = '0'; root.appendChild(area);
                    let ok; try { area.focus(); area.select(); ok = document.execCommand('copy'); } finally { area.remove(); button.focus(); }
                    if (!ok) throw new Error('copy failed');
                }
                const label = button.textContent; button.textContent = 'Copiado';
                feedback('Conteúdo copiado.'); setTimeout(() => { button.textContent = label; }, 1800);
            } catch (e) {
                const range = document.createRange(); range.selectNodeContents(el); const selection = window.getSelection(); selection.removeAllRanges(); selection.addRange(range);
                feedback('Não foi possível copiar automaticamente. O texto foi selecionado para cópia manual.', true);
            }
        }
        const selectAuth = button => {
            auth = button.dataset.auth;
            root.querySelectorAll('[data-auth]').forEach(tab => { const active = tab === button; tab.setAttribute('aria-selected', String(active)); tab.tabIndex = active ? 0 : -1; get(tab.getAttribute('aria-controls')).hidden = !active; });
            configs();
        };
        root.addEventListener('keydown', e => {
            const tab = e.target.closest('[data-auth]'); if (!tab) return;
            if (['ArrowLeft','ArrowRight','Home','End'].includes(e.key)) { e.preventDefault(); const tabs = Array.from(root.querySelectorAll('[data-auth]')); const next = e.key === 'Home' ? tabs[0] : e.key === 'End' ? tabs[tabs.length - 1] : tabs[(tabs.indexOf(tab) + 1) % tabs.length]; selectAuth(next); next.focus(); }
        });
        root.addEventListener('click', e => {
            const button = e.target.closest('button'); if (!button) return;
            if (button.dataset.copy) { copy(button); return; }
            if (button.dataset.auth) { selectAuth(button); return; }
            if (button.id === 'f3-generate') busy(button, 'Gerando…', async () => {
                const data = await request('generate_key'); credential = data.base64;
                get('f3-key-value').textContent = data.password; get('f3-key-output').hidden = false;
                get('f3-key-status').textContent = 'Senha de aplicação cadastrada.'; button.hidden = true; get('f3-revoke').hidden = false;
                configs(); feedback('Senha criada. Copie-a antes de sair desta página.'); get('f3-key-output').querySelector('button').focus();
            });
            if (button.id === 'f3-revoke') { get('f3-revoke-confirm').hidden = false; get('f3-revoke-no').focus(); }
            if (button.id === 'f3-revoke-no') { get('f3-revoke-confirm').hidden = true; get('f3-revoke').focus(); }
            if (button.id === 'f3-revoke-yes') busy(button, 'Revogando…', async () => {
                await request('revoke_key'); resetSecret(); get('f3-revoke-confirm').hidden = true;
                get('f3-key-status').textContent = 'Nenhuma senha de aplicação cadastrada por este plugin.';
                get('f3-revoke').hidden = true; get('f3-generate').hidden = false; get('f3-generate').focus(); feedback('Senha revogada.');
            });
            if (button.id === 'f3-test') busy(button, 'Testando…', async () => {
                const el = get('f3-test-result'); el.textContent = 'Verificando comunicação HTTP…';
                try { const data = await request('test_connection', {route: get('f3-test-route').value}); el.textContent = data.message + ' ' + data.tested_at; }
                catch (error) { el.textContent = error.message + ' Esse resultado se limita ao teste realizado pelo servidor.'; throw error; }
            });
        });
        window.addEventListener('pagehide', resetSecret);
        window.addEventListener('pageshow', e => { if (e.persisted) { resetSecret(); feedback('Página restaurada. Atualize para conferir o estado atual da credencial.'); } });
        configs();
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
