<?php
/** Explicit authenticated loopback test, with per-run disposable credentials. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ConnectionTest {
    public static function run(string $route): array {
        $base = ['route' => $route, 'endpoint' => ConnectionEndpoints::url($route), 'scope' => 'server_loopback', 'auth_method' => 'temporary_application_password',
            'external_connectivity_tested' => false, 'oauth_flow_tested' => false, 'configured_secret_tested' => false, 'tested_at' => gmdate('c')];
        $fail = static fn(string $code, string $message, array $data = []): array => Result::fail($code, $message, $base + $data);
        if (!current_user_can('manage_options')) return $fail('permission_denied', 'Permissão insuficiente.');
        if (!ConnectionEndpoints::matches($route)) return $fail('invalid_endpoint', 'Selecione um endpoint registrado deste site.');
        $snapshot = ConnectionStatus::snapshot();
        $entry = array_values(array_filter($snapshot['endpoints'], static fn($e) => $e['route'] === $route));
        if (empty($entry[0]['registered'])) return $fail('mcp_route_missing', 'A rota escolhida não está registrada neste servidor.');
        $url = $base['endpoint'];
        $origin = static function(string $value): array { $p = wp_parse_url($value); return [strtolower($p['scheme'] ?? ''), strtolower($p['host'] ?? ''), $p['port'] ?? (strtolower($p['scheme'] ?? '') === 'https' ? 443 : 80)]; };
        if ($origin($url) !== $origin(home_url())) return $fail('test_origin_mismatch', 'O teste autenticado exige um endpoint na mesma origem do site.');
        if ('https' !== $origin($url)[0] && !in_array(wp_get_environment_type(), ['local','development'], true)) return $fail('https_required', 'Use HTTPS para executar o teste autenticado.');
        if (!class_exists('WP_Application_Passwords') || !wp_is_application_passwords_available()) return $fail('application_password_unavailable', 'Senhas de aplicação não estão disponíveis neste ambiente. O diagnóstico local continua disponível.');
        $user = wp_get_current_user(); $session = ''; $item = null; $result = null;
        try {
            $created = Locks::run(['credential:' . get_current_blog_id() . ':' . $user->ID => LOCK_EX], static function() use ($user) {
                clean_user_cache($user->ID);
                return \WP_Application_Passwords::create_new_application_password($user->ID, ['name' => 'WP MCP Fator3 teste ' . wp_generate_uuid4()]);
            });
            if (is_wp_error($created) || !isset($created[0], $created[1]['uuid'])) return $fail('test_credential_failed', 'Não foi possível criar a credencial temporária do teste.');
            [$password, $item] = $created;
            $headers = ['Authorization' => 'Basic ' . base64_encode($user->user_login . ':' . $password), 'Content-Type' => 'application/json', 'Accept' => 'application/json, text/event-stream'];
            $rpc = static function(string $method, array $params, ?int $id) use ($url, &$headers) {
                $body = ['jsonrpc' => '2.0', 'method' => $method, 'params' => $params ?: new \stdClass()];
                if (null !== $id) $body['id'] = $id;
                return wp_remote_post($url, ['headers' => $headers, 'body' => wp_json_encode($body), 'timeout' => 10, 'redirection' => 0, 'sslverify' => true, 'limit_response_size' => 1048576]);
            };
            $response = $rpc('initialize', ['protocolVersion' => '2025-06-18', 'capabilities' => new \stdClass(), 'clientInfo' => ['name' => 'Fator3 connection test', 'version' => F3_MCP_FILES_VERSION]], 1);
            if (is_wp_error($response)) $result = self::transport_failure($response, 'initialize', $base);
            else {
                $status = wp_remote_retrieve_response_code($response); $body = self::decode(wp_remote_retrieve_body($response), 1);
                if (200 !== $status || empty($body['result']['serverInfo'])) $result = self::response_failure($status, 'initialize', $base);
                else {
                    $session = (string)wp_remote_retrieve_header($response, 'mcp-session-id');
                    if ($session !== '') $headers['Mcp-Session-Id'] = $session;
                    $headers['MCP-Protocol-Version'] = $body['result']['protocolVersion'] ?? '2025-06-18';
                    $ack = $rpc('notifications/initialized', [], null);
                    if (is_wp_error($ack)) $result = self::transport_failure($ack, 'initialized', $base);
                    elseif (!in_array(wp_remote_retrieve_response_code($ack), [200,202,204], true)) $result = self::response_failure(wp_remote_retrieve_response_code($ack), 'initialized', $base);
                    else {
                        $tools = $rpc('tools/list', [], 2);
                        $body = is_wp_error($tools) ? [] : self::decode(wp_remote_retrieve_body($tools), 2);
                        $names = array_column($body['result']['tools'] ?? [], 'name');
                        if (is_wp_error($tools)) $result = self::transport_failure($tools, 'tools/list', $base);
                        elseif (200 !== wp_remote_retrieve_response_code($tools)) $result = self::response_failure(wp_remote_retrieve_response_code($tools), 'tools/list', $base);
                        elseif (array_diff(ConnectionStatus::TOOLS, $names)) $result = $fail('mcp_tools_missing', 'A inicialização funcionou, mas tools/list não confirmou os três metatools.', ['stage' => 'tools/list']);
                        else $result = Result::ok($base + ['tools_count' => count($names), 'tools' => $names], 'Teste HTTP concluído pelo servidor: autenticação, sessão e três metatools verificados.');
                    }
                }
            }
        } catch (\Throwable $e) { $result = $fail('http_test_failed', 'Não foi possível concluir o teste HTTP.', ['stage' => 'request']); }
        finally {
            if ($session !== '') \WpMcpUltimate\Server\Transport\Infrastructure\SessionManager::delete_session($user->ID, $session);
            if ($item) {
                $removed = Locks::run(['credential:' . get_current_blog_id() . ':' . $user->ID => LOCK_EX], static function() use ($user, $item) {
                    clean_user_cache($user->ID);
                    return \WP_Application_Passwords::delete_application_password($user->ID, $item['uuid']);
                });
                if (true !== $removed) $result = $fail('test_cleanup_failed', 'O teste terminou, mas a credencial temporária não foi removida. Revogue a senha de teste no perfil do usuário.');
            }
        }
        $result = $result ?? $fail('http_test_failed', 'Teste sem resultado conclusivo.');
        ConnectionStatus::remember($result);
        return $result;
    }
    private static function transport_failure(\WP_Error $error, string $stage, array $base): array {
        // Inspect the transport diagnostic only to classify it. Never persist its
        // raw text: HTTP transports and filters may include request information.
        $detail = strtolower(implode(' ', $error->get_error_messages()));
        $kind = 'transport';
        if (preg_match('/curl error (28)\\b|timed? ?out|timeout/', $detail)) $kind = 'timeout';
        elseif (preg_match('/curl error (5|6)\\b|could not resolve|name resolution|getaddrinfo/', $detail)) $kind = 'dns';
        elseif (preg_match('/curl error (35|51|58|60|77|83|90|91)\\b|certificate|ssl|tls/', $detail)) $kind = 'tls';
        $messages = ['timeout' => 'O servidor excedeu o tempo de resposta.', 'dns' => 'O servidor não conseguiu resolver o endereço do site.', 'tls' => 'Não foi possível validar a conexão TLS. Confira o certificado e a cadeia de confiança.', 'transport' => 'Não foi possível estabelecer a comunicação HTTP de retorno.'];
        return Result::fail('http_' . $kind . '_failed', $messages[$kind], $base + ['stage' => $stage, 'failure_type' => $kind]);
    }
    private static function response_failure(int $status, string $stage, array $base): array {
        $code = 'test_initialize_failed'; $message = 'O servidor não concluiu a comunicação MCP esperada.';
        if ($status === 401) { $code = 'test_auth_failed'; $message = 'O endpoint recusou a autenticação temporária (HTTP 401).'; }
        elseif ($status === 403) { $code = 'test_forbidden'; $message = 'O acesso foi bloqueado por permissão ou regra do servidor (HTTP 403).'; }
        elseif ($status === 404) { $code = 'test_route_missing'; $message = 'O endereço não foi encontrado pelo servidor HTTP (404). O registro local pode continuar presente.'; }
        elseif ($status >= 300 && $status < 400) { $code = 'test_redirect_refused'; $message = 'O endpoint respondeu com redirecionamento. O teste não encaminhou a credencial para outro endereço.'; }
        return Result::fail($code, $message, $base + ['stage' => $stage, 'http_status' => $status]);
    }
    private static function decode(string $text, int $id): array {
        $json = json_decode($text, true);
        if (is_array($json)) return $json;
        foreach (preg_split('/\r?\n\r?\n/', $text) as $event) {
            $lines = [];
            foreach (preg_split('/\r?\n/', $event) as $line) if (str_starts_with($line, 'data:')) $lines[] = ltrim(substr($line, 5));
            $json = json_decode(implode("\n", $lines), true);
            if (is_array($json) && ($json['id'] ?? null) === $id) return $json;
        }
        return [];
    }
}
