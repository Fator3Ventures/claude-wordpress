<?php
/** Environment diagnostics and compact capability discovery. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SystemTools {
	public static function register(): void {
		Registry::add('system/capabilities', 'Report the loaded MCP distribution, user capabilities, channel gates, optional components and configured limits.', [], [], [self::class, 'capabilities'], 'edit_posts');
		Registry::add('system/health', 'Read local diagnostics for MCP, PHP, WordPress, private storage and database. Does not claim an external HTTP or OAuth connectivity test.', [], [], [self::class, 'health'], 'manage_options');
		$page = ['offset' => Registry::integer(), 'per_page' => Registry::integer(1, 200)];
		Registry::add('audit/list', 'List operation metadata without request payloads or credentials. Filter by ability prefix, user and result; before is the previous next_cursor.', ['ability' => Registry::string(), 'user' => Registry::integer(1), 'success' => Registry::boolean(), 'before' => Registry::string(), 'per_page' => Registry::integer(1, 200)], [], [Audit::class, 'listing']);
		Registry::add('audit/prune', 'Evaluate or remove audit records older than the chosen age. dry_run defaults to true.', ['older_than_days' => Registry::integer(1, 3650), 'dry_run' => Registry::boolean(true)], [], [Audit::class, 'prune'], 'manage_options', false);
		Registry::add('backups/list', 'List protected file/database backup metadata, including compatible legacy backups.', $page + ['path' => Registry::string()], [], [Backups::class, 'listing'], [FileTools::class, 'permission']);
		Registry::add('backups/export', 'Export one backup as base64 JSON with SHA-256. Binary database cells use explicit base64 encoding.', ['backup_id' => Registry::string()], ['backup_id'], [Backups::class, 'export'], [FileTools::class, 'permission']);
		Registry::add('backups/prune', 'Evaluate retention by age and optional total stored bytes. dry_run defaults to true. Legacy backups are preserved.', ['older_than_days' => Registry::integer(1, 3650), 'max_total_bytes' => Registry::integer(), 'dry_run' => Registry::boolean(true)], [], [Backups::class, 'prune'], [FileTools::class, 'permission'], false);
	}
	public static function capabilities(array $input = []): array {
		global $wp_version;
		$caps = []; foreach (['edit_posts','edit_pages','publish_posts','manage_options','edit_theme_options','switch_themes','install_themes','install_plugins','update_plugins','delete_plugins','edit_files','unfiltered_html'] as $cap) $caps[$cap] = current_user_can($cap);
		$loaded = defined('WP_MCP_ULTIMATE_DIR') ? wp_normalize_path(WP_MCP_ULTIMATE_DIR) : '';
		$integrated = '' !== $loaded && str_starts_with($loaded, wp_normalize_path(F3_MCP_FILES_DIR));
		return Result::ok(['plugin_version' => F3_MCP_FILES_VERSION, 'wordpress' => $wp_version, 'php' => PHP_VERSION, 'site_id' => get_current_blog_id(), 'user_id' => get_current_user_id(), 'endpoint' => ConnectionEndpoints::url(), 'legacy_endpoint' => ConnectionEndpoints::url(ConnectionEndpoints::LEGACY), 'endpoints' => ConnectionEndpoints::entries(), 'metatools' => ['Discover Abilities','Get Ability Info','Execute Ability'], 'integrated_core_loaded' => $integrated, 'upstream_version' => F3_MCP_UPSTREAM_VERSION, 'abilities_api' => version_compare($wp_version, '6.9', '>=') ? 'wordpress-native' : 'bundled-polyfill', 'capabilities' => $caps, 'channels' => ['files' => PathGuard::is_enabled() && PathGuard::can_edit(), 'database_read' => PathGuard::is_enabled() && current_user_can('manage_options'), 'database_write' => PathGuard::is_enabled() && current_user_can('manage_options') && Database::writes_enabled()], 'limits' => ['file_bytes' => PathGuard::max_bytes(), 'sql_rows' => SqlGuard::MAX_ROWS, 'sql_bytes' => 65536, 'db_confirmation_seconds' => 600, 'plan_steps' => 50, 'lock_wait_seconds' => max(0, min(10, (float)apply_filters('f3_mcp_lock_timeout', 2.0)))], 'file_scope' => PathGuard::is_confined() ? 'configured_roots' : 'php_reachable_paths', 'concurrency_scope' => 'Cooperating operations in this plugin and shared lock storage. External writers must use the same lock API.']);
	}
	public static function health(array $input = []): array {
		global $wpdb;
		$checks = ['abilities_api' => function_exists('wp_get_abilities'), 'mcp_adapter' => class_exists('WpMcpUltimate\\Server\\McpAdapter'), 'json' => function_exists('json_encode'), 'random_bytes' => function_exists('random_bytes'), 'flock' => function_exists('flock'), 'rest_configured' => (bool)ConnectionEndpoints::url()];
        $connection = ConnectionStatus::snapshot();
        $checks['mcp_registration'] = $connection['registry_checked'] && !$connection['errors'];
		$storage = [];
		try { $dir = StateStore::directory(); $storage = ['path' => $dir, 'writable' => is_writable($dir), 'free_bytes' => @disk_free_space($dir), 'php_envelopes' => true, 'outside_document_root' => !str_starts_with(wp_normalize_path($dir) . '/', wp_normalize_path(realpath(ABSPATH) ?: ABSPATH)), 'legacy_directory_present' => is_dir(WP_CONTENT_DIR . '/f3-mcp-backups'), 'http_protection_tested' => false]; $checks['private_storage'] = $storage['writable']; }
		catch (\Throwable $e) { $checks['private_storage'] = false; $storage['error'] = $e->getMessage(); }
		$suppress = $wpdb->suppress_errors(true); $one = $wpdb->get_var('SELECT 1'); $checks['database'] = '1' === (string)$one && !$wpdb->last_error; $wpdb->suppress_errors($suppress);
		return Result::ok(['healthy' => !in_array(false, $checks, true), 'checks' => $checks, 'storage' => $storage, 'database_class' => get_class($wpdb), 'environment' => self::capabilities(), 'external_connectivity_tested' => false, 'connection' => $connection]);
	}
}
final class Discovery {
	public static function schema(): array { return ['type' => 'object', 'properties' => ['query' => Registry::string('Search name, label and description.'), 'prefix' => Registry::string(), 'category' => Registry::string(), 'readonly' => Registry::boolean(), 'per_page' => Registry::integer(1, 200), 'cursor' => Registry::string(), 'compact' => Registry::boolean()], 'additionalProperties' => false]; }
	public static function listing(array $abilities, array $input): array {
		$list = [];
		foreach ($abilities as $ability) {
			$meta = $ability->get_meta(); $name = $ability->get_name();
			if (empty($meta['mcp']['public']) || ($meta['mcp']['type'] ?? 'tool') !== 'tool') continue;
			$readonly = (bool)($meta['annotations']['readonly'] ?? false);
			$category = method_exists($ability, 'get_category') ? $ability->get_category() : '';
			if (isset($input['prefix']) && !str_starts_with($name, $input['prefix']) || isset($input['category']) && $category !== $input['category'] || isset($input['readonly']) && $readonly !== $input['readonly']) continue;
			if (!empty($input['query']) && false === stripos($name . ' ' . $ability->get_label() . ' ' . $ability->get_description(), $input['query'])) continue;
			$required = $ability->get_input_schema()['required'] ?? [];
			$available = 'requires_input';
			if (!$required) { try { $p = $ability->check_permissions([]); $available = !is_wp_error($p) && $p ? 'available' : 'permission_denied'; } catch (\Throwable $e) { $available = 'requires_input'; } }
			$list[] = ['name' => $name, 'label' => $ability->get_label(), 'description' => !empty($input['compact']) ? '' : $ability->get_description(), 'category' => $category, 'readonly' => $readonly, 'availability' => $available, 'version' => $meta['fator3']['version'] ?? '', 'schema_sha256' => hash('sha256', serialize([$ability->get_input_schema(), $ability->get_output_schema()]))];
		}
		usort($list, static fn($a, $b) => strcmp($a['name'], $b['name']));
		$hash = hash('sha256', serialize($list)); $offset = 0;
		$filter = $input; unset($filter['cursor']); ksort($filter); $filter_hash = hash('sha256', serialize($filter));
		if (!empty($input['cursor'])) {
			$state = Cursor::decode($input['cursor']); if (is_wp_error($state)) return Result::error($state) + ['abilities' => []];
			if (($state['kind'] ?? '') !== 'abilities' || $state['user'] !== get_current_user_id() || $state['blog'] !== get_current_blog_id() || $state['filter'] !== $filter_hash) return Result::fail('cursor_invalid', 'Discovery cursor belongs to different filters or user.', ['abilities' => []]);
			if ($state['catalog'] !== $hash) return Result::fail('catalog_changed', 'Ability catalog changed. Restart discovery.', ['conflict' => true, 'abilities' => []]);
			$offset = $state['offset'];
		}
		// Empty input preserves the historical complete list for existing clients.
		$limit = isset($input['per_page']) || isset($input['cursor']) ? max(1, min(200, (int)($input['per_page'] ?? 50))) : max(1, count($list));
		$page = array_slice($list, $offset, $limit); $next = $offset + count($page);
		return Result::ok(['abilities' => $page, 'total' => count($list), 'catalog_sha256' => $hash, 'plugin_version' => F3_MCP_FILES_VERSION, 'has_more' => $next < count($list), 'next_cursor' => $next < count($list) ? Cursor::encode(['kind' => 'abilities', 'user' => get_current_user_id(), 'blog' => get_current_blog_id(), 'filter' => $filter_hash, 'catalog' => $hash, 'offset' => $next]) : null]);
	}
}
