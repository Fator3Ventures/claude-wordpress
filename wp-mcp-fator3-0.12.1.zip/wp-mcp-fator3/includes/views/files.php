<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$enabled = PathGuard::is_enabled(); $hard = Admin::hard_block();
?>
<div class="f3-grid">
<section class="f3-card"><div class="f3-card-heading"><h2>Arquivos e banco</h2><?php Admin::badge($enabled, 'Canal habilitado', 'Canal fechado'); ?></div>
    <p>Controla files/* e o acesso ao banco. O servidor MCP e as abilities de conteúdo mantêm suas próprias permissões.</p>
    <?php if ($hard): ?><p class="f3-error">Canal bloqueado por DISALLOW_FILE_EDIT ou DISALLOW_FILE_MODS no wp-config.php.</p><?php elseif (Admin::forced_by_filter()): ?><p class="f3-subtle">Estado controlado também pelo filtro f3_mcp_files_enabled.</p><?php endif; ?>
    <?php Admin::form('channel', (bool)get_option(PathGuard::OPTION_ENABLED, true), $hard); ?>
    <?php if ($enabled): ?><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><?php wp_nonce_field('f3_mcp_settings'); ?><input type="hidden" name="action" value="f3_mcp_save"><input type="hidden" name="section" value="channel"><input type="hidden" name="enable" value="0"><button class="button f3-danger">Fechar canal agora</button><p class="description">Solicita o bloqueio de novas chamadas de arquivos e banco. Confira o estado efetivo após salvar: filtros do site podem sobrepor essa preferência.</p></form><?php endif; ?>
</section>
<section class="f3-card"><div class="f3-card-heading"><h2>Escrita no banco</h2><?php Admin::badge($enabled && Database::writes_enabled(), 'Escrita habilitada', 'Escrita indisponível'); ?></div><p>db/execute exige prévia e token de confirmação. A leitura por db/query e db/schema acompanha o canal geral.</p>
    <?php if (!$enabled): ?><p class="f3-subtle">O canal geral está fechado. A preferência será aplicada quando ele estiver habilitado.</p><?php endif; ?>
    <?php if (has_filter('f3_mcp_db_writes_enabled')): ?><p>O filtro f3_mcp_db_writes_enabled também controla o resultado efetivo.</p><?php endif; ?>
    <?php Admin::form('database', (bool)get_option(Database::OPTION_WRITES, true)); ?>
    <details><summary>Como a confirmação SQL funciona</summary><p>Confira as linhas previstas e envie o token recebido para confirmar. UPDATE/DELETE exigem WHERE. Formas cuja pré-imagem não pode ser garantida são recusadas; resultado incerto exige diagnóstico antes de repetir.</p></details>
</section></div>
<section class="f3-card"><h2>Alcance e limites efetivos</h2><p><?php echo esc_html(PathGuard::is_confined() ? 'O acesso está restrito às raízes configuradas, respeitando as permissões do PHP.' : 'O canal alcança os arquivos permitidos ao usuário do PHP, inclusive arquivos de configuração e credenciais. A autoedição do plugin é bloqueada por padrão.'); ?></p>
<dl class="f3-facts">
<dt>Escopo</dt><dd><?php echo esc_html(PathGuard::is_confined() ? implode(', ', PathGuard::roots()) ?: 'Nenhuma raiz válida: acesso recusado.' : 'Sistema de arquivos alcançável pelo PHP'); ?></dd>
<dt>Limite por arquivo</dt><dd><?php echo esc_html(size_format(PathGuard::max_bytes())); ?></dd>
<dt>Permissão para arquivos</dt><dd><?php Admin::badge(PathGuard::can_edit(), 'Sua conta está autorizada', 'Sua conta não tem permissão'); ?> <span class="description">edit_themes + manage_options</span></dd>
<dt>open_basedir</dt><dd><?php echo esc_html(ini_get('open_basedir') ?: 'Não definido'); ?></dd>
<dt>Extensões permitidas</dt><dd><?php echo esc_html(implode(', ', PathGuard::allowed_extensions()) ?: 'Todas, salvo bloqueios abaixo'); ?></dd>
<dt>Extensões bloqueadas</dt><dd><?php echo esc_html(implode(', ', PathGuard::denied_extensions()) ?: 'Nenhuma regra adicional'); ?></dd>
<dt>Nomes protegidos</dt><dd><?php echo esc_html(implode(', ', PathGuard::denied_basenames()) ?: 'Sem lista adicional de nomes'); ?></dd>
</dl><p class="description">Constantes e filtros do site definem limites adicionais. As gravações concorrentes participantes do plugin usam os mesmos locks por arquivo.</p></section>
