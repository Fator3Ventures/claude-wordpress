<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$key = ConnectionStatus::key();
$oauth = (bool)apply_filters('wp_mcp_ultimate_enable_oauth', true) && class_exists('WpMcpUltimate\\OAuth\\Server');
$app_available = function_exists('wp_is_application_passwords_available') && wp_is_application_passwords_available();
?>
<section class="f3-card f3-connection-card">
    <div class="f3-card-heading"><h2>Conectar um assistente</h2><?php Admin::badge($status['core_loaded'], 'Servidor carregado', 'Servidor ausente'); ?></div>
    <p>Use este endereço para configurar uma nova conexão MCP.</p>
    <div class="f3-copy-row"><code id="f3-endpoint"><?php echo esc_html(ConnectionEndpoints::url()); ?></code><button type="button" class="button" data-copy="f3-endpoint">Copiar URL</button></div>
    <p class="f3-subtle"><?php echo esc_html($status['registry_checked'] && !$status['errors'] ? 'Rotas registradas · 3 metatools disponíveis' : 'Confira o diagnóstico de registro abaixo.'); ?></p>
    <?php foreach ($status['errors'] as $error): ?><p class="f3-error"><?php echo esc_html(ConnectionStatus::label($error)); ?></p><?php endforeach; ?>
    <details><summary>Compatibilidade com conexões existentes</summary><p>Conectores já configurados podem continuar usando este endereço.</p><div class="f3-copy-row"><code id="f3-legacy-endpoint"><?php echo esc_html(ConnectionEndpoints::url(ConnectionEndpoints::LEGACY)); ?></code><button type="button" class="button" data-copy="f3-legacy-endpoint">Copiar URL antiga</button></div></details>
</section>
<section class="f3-card">
    <h2>Autenticação</h2><p>Selecione a forma usada pelo seu cliente. O servidor aceita OAuth e senhas de aplicação simultaneamente.</p>
    <div class="f3-auth-tabs" role="tablist" aria-label="Forma de autenticação">
        <button type="button" id="f3-auth-oauth" role="tab" aria-selected="true" aria-controls="f3-oauth-panel" data-auth="oauth">OAuth</button>
        <button type="button" id="f3-auth-password" role="tab" aria-selected="false" aria-controls="f3-password-panel" tabindex="-1" data-auth="password">Senha de aplicação</button>
    </div>
    <div id="f3-oauth-panel" role="tabpanel" aria-labelledby="f3-auth-oauth" tabindex="0">
        <?php Admin::badge($oauth, 'OAuth habilitado', 'OAuth desabilitado'); ?>
        <p>Informe a URL no conector e autorize o acesso com sua conta WordPress. As ações respeitam as permissões dessa conta.</p>
        <?php if (!$oauth): ?><p>O OAuth foi desabilitado por configuração. Use uma senha de aplicação ou revise o filtro de autenticação com o administrador.</p><?php endif; ?>
        <p class="description">Este fluxo não exige gerar uma senha de aplicação nesta tela.</p>
    </div>
    <div id="f3-password-panel" role="tabpanel" aria-labelledby="f3-auth-password" tabindex="0" hidden>
        <p>Use esta opção em clientes que aceitam o cabeçalho Authorization com usuário e senha de aplicação. A senha pertence à conta conectada ao painel.</p>
        <p id="f3-key-status"><?php echo esc_html($key ? 'Senha de aplicação cadastrada.' : 'Nenhuma senha de aplicação cadastrada por este plugin.'); ?></p>
        <div class="f3-actions"><button type="button" class="button button-primary" id="f3-generate" <?php echo $key ? 'hidden' : ''; ?> <?php disabled(!$app_available); ?>>Gerar senha de aplicação</button><button type="button" class="button f3-danger" id="f3-revoke" <?php echo !$key ? 'hidden' : ''; ?>>Revogar senha</button></div>
        <?php if (!$app_available): ?><p class="f3-error">Senhas de aplicação indisponíveis. Confira HTTPS e as restrições de autenticação deste ambiente.</p><?php endif; ?>
        <div id="f3-revoke-confirm" class="f3-inline-confirm" hidden><p>A revogação interrompe os conectores que usam esta senha de aplicação.</p><div class="f3-actions"><button type="button" class="button f3-danger" id="f3-revoke-yes">Confirmar revogação</button><button type="button" class="button" id="f3-revoke-no">Cancelar</button></div></div>
        <div id="f3-key-output" hidden><p><strong>Copie a senha agora.</strong> Ela não será exibida novamente após sair desta página.</p><div class="f3-copy-row"><code id="f3-key-value"></code><button type="button" class="button" data-copy="f3-key-value">Copiar senha</button></div></div>
    </div>
</section>
<section class="f3-card"><h2>Configuração por cliente</h2><p>Abra apenas o cliente que deseja configurar. Os exemplos acompanham a autenticação selecionada acima.</p>
    <?php foreach (['claude-code' => ['Claude Code', 'Arquivo .mcp.json do projeto; type=http.'], 'cursor' => ['Cursor', 'Arquivo .cursor/mcp.json.'], 'desktop' => ['Claude Desktop / cliente stdio', 'Para clientes que exigem um processo local: modelo com mcp-remote e Node.js instalado. Para conectores remotos nativos, use a URL e OAuth.']] as $id => $client): ?>
    <details class="f3-config" data-client="<?php echo esc_attr($id); ?>"><summary>Ver configuração para <?php echo esc_html($client[0]); ?></summary><p><?php echo esc_html($client[1]); ?></p><p class="f3-config-note">Modelo de configuração.</p><div class="f3-code-actions"><button type="button" class="button" data-copy="f3-json-<?php echo esc_attr($id); ?>">Copiar JSON</button></div><pre tabindex="0"><code id="f3-json-<?php echo esc_attr($id); ?>"></code></pre></details>
    <?php endforeach; ?>
    <noscript><p>Ative JavaScript para gerar e copiar os modelos JSON. A URL acima continua disponível para seleção manual.</p></noscript>
</section>
<section class="f3-card"><h2>Verificar comunicação</h2><?php Admin::test_controls($status); ?><p><a href="<?php echo esc_url(Admin::url('diagnostics')); ?>">Abrir diagnóstico e atividade</a></p></section>
