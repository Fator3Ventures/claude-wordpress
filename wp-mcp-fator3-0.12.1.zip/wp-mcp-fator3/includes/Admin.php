<?php
/** Unified settings UI. Operational status is supplied by ConnectionStatus. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Admin {
    private const SLUG = 'wp-mcp-fator3';
    public static function init(): void {
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'assets']);
        add_action('admin_post_f3_mcp_save', [self::class, 'handle_save']);
        add_action('admin_post_f3_mcp_files_toggle', [self::class, 'handle_toggle']);
        add_action('admin_post_f3_mcp_db_toggle', [self::class, 'handle_db_toggle']);
    }
    public static function menu(): void { add_management_page('WP MCP Fator3', 'MCP Fator3', 'manage_options', self::SLUG, [self::class, 'render']); }
    public static function url(string $tab = 'connection'): string { return add_query_arg(['page' => self::SLUG, 'tab' => $tab], admin_url('tools.php')); }
    public static function forced_by_filter(): bool { return (bool)has_filter('f3_mcp_files_enabled'); }
    public static function hard_block(): bool { return (defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS); }
    public static function assets(string $hook): void {
        if (!in_array($hook, ['tools_page_wp-mcp-fator3','tools_page_wp-mcp-ultimate'], true)) return;
        $base = plugin_dir_url(F3_MCP_FILES_DIR . 'wp-mcp-fator3.php') . 'core/assets/';
        wp_enqueue_style('f3-mcp-admin', $base . 'css/admin.css', [], F3_MCP_FILES_VERSION);
        wp_enqueue_script('f3-mcp-admin', $base . 'js/admin.js', [], F3_MCP_FILES_VERSION, true);
        wp_localize_script('f3-mcp-admin', 'f3McpAdmin', ['ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('wp-mcp-ultimate'), 'endpoint' => ConnectionEndpoints::url()]);
    }
    public static function save(string $section, bool $enable): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied', 'Permissão insuficiente.');
        if (!in_array($section, ['channel','database'], true)) return Result::fail('invalid_section', 'Seção inválida.');
        if ('channel' === $section && $enable && self::hard_block()) return Result::fail('channel_blocked', 'O canal está bloqueado pelo wp-config.php.');
        $option = 'channel' === $section ? PathGuard::OPTION_ENABLED : Database::OPTION_WRITES;
        $result = Locks::run(['option:' . get_current_blog_id() . ':' . $option => LOCK_EX], static fn() => VerifiedOptions::update($option, ['value' => $enable ? '1' : '0']));
        $effective = 'channel' === $section ? PathGuard::is_enabled() : (PathGuard::is_enabled() && Database::writes_enabled());
        $result['effective'] = $effective;
        $result['overridden'] = $effective !== $enable;
        $result['message'] = empty($result['success']) ? 'Não foi possível salvar a configuração. Confira o estado atual e tente novamente.' : ($result['overridden'] ? 'Preferência salva. O estado efetivo depende das restrições indicadas nesta seção.' : (!empty($result['changed']) ? 'Configurações salvas.' : 'Nenhuma alteração necessária.'));
        Audit::record('admin/settings', ['name' => $section], $result, 0);
        return $result;
    }
    private static function submit(string $nonce, ?string $section = null): void {
        if (!current_user_can('manage_options')) wp_die('Permissão insuficiente.', '', ['response' => 403]);
        check_admin_referer($nonce);
        $section = $section ?? (isset($_POST['section']) && is_string($_POST['section']) ? sanitize_key(wp_unslash($_POST['section'])) : '');
        $enable = isset($_POST['enable']) && '1' === $_POST['enable'];
        $result = self::save($section, $enable);
        $key = wp_generate_uuid4();
        set_transient('f3_mcp_notice_' . get_current_user_id() . '_' . $key, ['success' => $result['success'], 'message' => $result['message']], 60);
        wp_safe_redirect(add_query_arg('notice', $key, self::url('files')));
        exit;
    }
    public static function handle_save(): void { self::submit('f3_mcp_settings'); }
    public static function handle_toggle(): void { self::submit('f3_mcp_files_toggle', 'channel'); }
    public static function handle_db_toggle(): void { self::submit('f3_mcp_db_toggle', 'database'); }
    public static function badge(bool $ok, string $yes, string $no): void { echo '<span class="f3-badge ' . ($ok ? 'is-ok' : 'is-muted') . '">' . esc_html($ok ? $yes : $no) . '</span>'; }
    public static function render(): void {
        if (!current_user_can('manage_options')) return;
        $tab = isset($_GET['tab']) && is_string($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'connection';
        if (!in_array($tab, ['connection','files','diagnostics'], true)) $tab = 'connection';
        $status = ConnectionStatus::snapshot();
        echo '<div class="wrap f3-mcp-admin"><header class="f3-header"><div><h1>WP MCP Fator3</h1><p>Conecte seus assistentes e gerencie o acesso ao WordPress.</p></div><span class="f3-version">' . esc_html(F3_MCP_FILES_VERSION) . '</span></header>';
        echo '<nav class="f3-nav" aria-label="Configurações do MCP">';
        foreach (['connection' => 'Conexão','files' => 'Acesso e limites','diagnostics' => 'Diagnóstico e atividade'] as $key => $label) echo '<a ' . ($tab === $key ? 'aria-current="page"' : '') . ' href="' . esc_url(self::url($key)) . '">' . esc_html($label) . '</a>';
        echo '</nav>';
        if (isset($_GET['notice']) && is_string($_GET['notice']) && preg_match('/^[a-f0-9-]{36}$/D', $_GET['notice'])) {
            $key = 'f3_mcp_notice_' . get_current_user_id() . '_' . $_GET['notice']; $notice = get_transient($key); delete_transient($key);
            if (is_array($notice)) echo '<div class="notice ' . ($notice['success'] ? 'notice-success' : 'notice-error') . ' inline"><p>' . esc_html($notice['message']) . '</p></div>';
        }
        echo '<div id="f3-feedback" class="f3-feedback" role="status" aria-live="polite" hidden></div>';
        include F3_MCP_FILES_DIR . 'includes/views/' . $tab . '.php';
        echo '</div>';
    }
    public static function test_controls(array $status): void {
        $previous = ConnectionStatus::previous();
        echo '<label for="f3-test-route">Endereço para testar</label><div class="f3-actions"><select id="f3-test-route">';
        foreach ($status['endpoints'] as $entry) echo '<option value="' . esc_attr($entry['route']) . '">' . esc_html($entry['role'] === 'legacy' ? 'Compatibilidade — wp-mcp-ultimate' : ($entry['role'] === 'primary' ? 'URL principal' : 'Alias Fator3')) . '</option>';
        echo '</select><button type="button" class="button" id="f3-test">Testar comunicação HTTP</button></div><p class="description">O teste parte deste servidor, com uma senha temporária. Verifica autenticação e os três metatools; o acesso do seu conector e o fluxo OAuth precisam ser verificados no próprio cliente.</p>';
        echo '<p id="f3-test-result" role="status" aria-live="polite">' . esc_html($previous ? $previous['message'] . ' Último teste: ' . $previous['tested_at'] . ' — ' . $previous['route'] : 'Comunicação HTTP ainda não verificada.') . '</p>';
    }
    public static function form(string $section, bool $stored, bool $disabled = false): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="f3-settings-form">';
        wp_nonce_field('f3_mcp_settings');
        echo '<input type="hidden" name="action" value="f3_mcp_save"><input type="hidden" name="section" value="' . esc_attr($section) . '"><input type="hidden" name="enable" value="0">';
        echo '<label><input type="checkbox" name="enable" value="1" ' . checked($stored, true, false) . disabled($disabled, true, false) . '> ' . esc_html($section === 'channel' ? 'Habilitar canal de arquivos e banco' : 'Permitir escrita SQL com prévia e confirmação') . '</label><p><button class="button button-primary" ' . disabled($disabled, true, false) . '>Salvar</button></p></form>';
    }
}
