<?php
/** One routing contract for transport, admin, diagnostics and OAuth. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ConnectionEndpoints {
    public const PRIMARY = '/mcp/wp-mcp-fator3';
    public const LEGACY = '/mcp/wp-mcp-ultimate';
    private static ?array $config = null;
    private static array $registration = [];
    private static array $callbacks = [];

    public static function configure(array $config): void { self::$config = $config; }
    public static function config(): array {
        if (null !== self::$config) return self::$config;
        if (method_exists('WpMcpUltimate\\Server\\DefaultServerFactory', 'configuration')) return \WpMcpUltimate\Server\DefaultServerFactory::configuration(false);
        if (class_exists('WpMcpUltimate\\Server\\DefaultServerFactory')) return ['server_id' => 'wp-mcp-ultimate-server', 'server_route_namespace' => 'mcp', 'server_route' => 'wp-mcp-ultimate'];
        return ['server_id' => 'wp-mcp-ultimate-server', 'server_route_namespace' => 'mcp', 'server_route' => 'wp-mcp-fator3'];
    }
    public static function route(): string {
        $c = self::config();
        return '/' . trim((string)$c['server_route_namespace'], '/') . '/' . trim((string)$c['server_route'], '/');
    }
    public static function routes(): array { return array_values(array_unique([self::route(), self::PRIMARY, self::LEGACY])); }
    public static function url(?string $route = null): string { return rest_url(ltrim($route ?? self::route(), '/')); }
    public static function matches(string $route): bool { return in_array('/' . trim($route, '/'), self::routes(), true); }
    public static function is_registered(string $route): bool {
        if (!did_action('rest_api_init') || doing_action('rest_api_init')) return false;
        foreach (self::entries() as $entry) if ($entry['route'] === '/' . trim($route, '/')) return $entry['registered'] === true;
        return false;
    }
    public static function is_owned($server): bool { return $server->get_server_id() === self::config()['server_id']; }
    public static function recorded(string $route, bool $registered, ?array $callback = null): void { self::$registration[$route] = $registered; if ($callback) self::$callbacks[$route] = $callback; }
    public static function entries(?array $registered_routes = null): array {
        if (null === $registered_routes && did_action('rest_api_init') && !doing_action('rest_api_init')) $registered_routes = rest_get_server()->get_routes();
        $out = [];
        foreach (self::routes() as $route) {
            $owned = self::$registration[$route] ?? null;
            if ($registered_routes !== null && isset($registered_routes[$route]) && $owned === true && isset(self::$callbacks[$route])) {
                $actual = false; foreach ($registered_routes[$route] as $endpoint) if (is_array($endpoint) && ($endpoint['callback'] ?? null) === self::$callbacks[$route]) $actual = true;
                $owned = $actual;
            }
            $out[] = ['route' => $route, 'url' => self::url($route), 'role' => $route === self::route() ? 'primary' : ($route === self::LEGACY ? 'legacy' : 'alias'),
                'registered' => null === $registered_routes ? null : (true === $owned && isset($registered_routes[$route])),
                'conflict' => false === $owned];
        }
        return $out;
    }
    /** Match the REST route WordPress will dispatch, not merely the visible URL. */
    public static function request_route(): ?string {
        foreach ([$_POST, $_GET] as $params) {
            if (isset($params['rest_route'])) return is_string($params['rest_route']) ? '/' . trim(wp_unslash($params['rest_route']), '/') : null;
        }
        $path = (string)wp_parse_url(isset($_SERVER['REQUEST_URI']) ? wp_unslash($_SERVER['REQUEST_URI']) : '', PHP_URL_PATH);
        $base = (string)wp_parse_url(rest_url(), PHP_URL_PATH);
        if (!str_contains($base, '/' . rest_get_url_prefix() . '/')) return null;
        if (!str_starts_with($path, $base)) return null;
        return '/' . trim(substr($path, strlen($base)), '/');
    }
    /** Resource aliases are explicitly bound to this site's endpoint URLs. */
    public static function resource($value, string $fallback = '') {
        if (null === $value || '' === $value) return $fallback ?: self::url();
        if (!is_string($value) || strlen($value) > 4096) return new \WP_Error('invalid_target', 'Invalid MCP resource.');
        $normalize = static function(string $url): string {
            $p = wp_parse_url($url);
            if (!is_array($p) || empty($p['scheme']) || empty($p['host']) || isset($p['fragment']) || isset($p['user']) || isset($p['pass'])) return '';
            return strtolower($p['scheme']) . '://' . strtolower($p['host']) . (isset($p['port']) ? ':' . $p['port'] : '') . rtrim($p['path'] ?? '', '/') . (isset($p['query']) ? '?' . $p['query'] : '');
        };
        foreach (self::routes() as $route) if ($normalize($value) !== '' && $normalize($value) === $normalize(self::url($route))) return self::url($route);
        return new \WP_Error('invalid_target', 'This resource is not an MCP endpoint of this site.');
    }
    public static function metadata_path(string $route): string {
        // Advertised explicitly by WWW-Authenticate, also supports query-string REST URLs.
        $path = (string)wp_parse_url(self::url($route), PHP_URL_PATH);
        $query = (string)wp_parse_url(self::url($route), PHP_URL_QUERY);
        $home_path = rtrim((string)wp_parse_url(home_url('/'), PHP_URL_PATH), '/');
        if ($home_path !== '' && str_starts_with($path, $home_path . '/')) $path = substr($path, strlen($home_path));
        return '/.well-known/oauth-protected-resource' . ($query !== '' ? $route : '/' . ltrim($path, '/'));
    }
    public static function metadata_url(string $route): string { return home_url(self::metadata_path($route)); }
    public static function metadata_route(string $relative_path): ?string {
        if ('/.well-known/oauth-protected-resource' === $relative_path) return self::LEGACY;
        foreach (self::routes() as $route) if (self::metadata_path($route) === $relative_path) return $route;
        return null;
    }
    public static function no_cache(): void {
        if (!defined('DONOTCACHEPAGE')) define('DONOTCACHEPAGE', true);
        if (!headers_sent()) nocache_headers();
        do_action('litespeed_control_set_nocache', 'Fator3 MCP authenticated endpoint');
    }
}
