<?php
/** Local service authority is independent of the incidental WordPress user. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class MutationServiceAudit {
    public const CONTRACT='mutation-service-audit/1.0.0';
    private const PROVIDER='wp-mcp-linkedin-fator3';
    private const READER='linkedin/get-service-write-operation';
    private const DESCRIPTOR=['contract'=>self::CONTRACT,'provider'=>self::PROVIDER,
        'event_contract'=>'linkedin-service-mutation/1.0.0','event_hook'=>'f3_linkedin_service_mutation_recorded',
        'reader'=>self::READER,'introspector'=>'f3_linkedin_introspect_service_grant'];
    private static bool $initialized=false;
    private static bool $initializing=false;
    private static bool $registered=false;
    private static ?string $error=null;
    private static bool $panel=false;

    public static function init(): void {
        add_action('wp_loaded',[self::class,'initialize_context'],30);
        add_action('rest_api_init',[self::class,'initialize'],30);
        add_action('wp_abilities_api_init',[self::class,'initialize_catalog'],PHP_INT_MAX);
        add_action(self::DESCRIPTOR['event_hook'],static function($event): void {if(is_array($event))self::record($event);});
    }
    public static function capabilities(): array {
        return ['contract'=>self::CONTRACT,'registration_hook'=>'f3_mcp_register_mutation_service_audit',
            'reader'=>'audit/get-service-operation','storage'=>'reference_only','principal_type'=>'service',
            'registration'=>'local_php_only','retroactive_import'=>false];
    }
    /** Public pages and login do not need the administrative ability catalogue. */
    public static function initialize_context(): void {
        if(is_admin()||wp_doing_cron()||(defined('WP_CLI')&&WP_CLI))self::initialize();
    }
    /** Join a catalogue requested by another consumer, without creating one. */
    public static function initialize_catalog(): void {
        if(!self::$initializing&&wp_has_ability(self::READER))self::initialize();
    }
    public static function initialize(): void {
        if(self::$initialized||self::$initializing||!did_action('init'))return;
        self::$initializing=true;
        try {
            wp_get_abilities();self::$initialized=true;
            try {do_action('f3_mcp_register_mutation_service_audit',self::CONTRACT,[self::class,'register'],[self::class,'receipt']);}
            catch(\Throwable $e){self::$registered=false;self::$error='service_registration_failed';}
        }finally{self::$initializing=false;}
    }
    /** No callback, path, provider registration or emission is accepted over MCP. */
    public static function register(array $descriptor): array {
        if(self::$error!==null||count($descriptor)!==6||$descriptor!=self::DESCRIPTOR||!self::reader()){
            self::$registered=false;self::$error='service_descriptor_invalid';
        }else self::$registered=true;
        return ['contract'=>self::CONTRACT,'provider'=>self::PROVIDER,'registered'=>self::$registered];
    }
    private static function reader(): ?\WP_Ability {
        if(!Providers::known(self::PROVIDER))return null;
        // Check the public entry points, never inspect provider tables/private classes.
        $root=realpath(WP_PLUGIN_DIR.'/'.self::PROVIDER);
        if(!$root)return null;
        foreach(['f3_linkedin_service_audit_descriptor',self::DESCRIPTOR['introspector']] as $function){
            if(!function_exists($function))return null;
            $file=(new \ReflectionFunction($function))->getFileName();
            if(!$file||realpath($file)!==$root.'/includes/ServiceAuditPublic.php')return null;
        }
        $d=\f3_linkedin_service_audit_descriptor();
        if(!is_array($d)||count($d)!==6||$d!=self::DESCRIPTOR)return null;
        $ability=(function_exists('wp_has_ability')&&wp_has_ability(self::READER))?wp_get_ability(self::READER):null;$meta=$ability?$ability->get_meta():[];$f=$meta['fator3']??[];
        if(!$ability||!ExtensionContract::adheres(self::READER,$f)||($f['provider']??'')!==self::PROVIDER
            ||empty($f['decorated'])||empty($meta['mcp']['public'])||($meta['mcp']['type']??'tool')!=='tool'
            ||!AuthorizationPolicy::readonly($ability))return null;
        $schema=$ability->get_input_schema();$keys=array_keys(self::identity_schema());
        if(($schema['additionalProperties']??true)!==false||count($schema['properties']??[])!==5
            ||count($schema['required']??[])!==5||array_diff($keys,$schema['required']))return null;
        foreach($keys as $key)if(($schema['properties'][$key]['type']??'')!=='string')return null;
        return $ability;
    }
    public static function identity_schema(): array {
        $hash=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        return ['provider'=>['type'=>'string','enum'=>[self::PROVIDER]],
            'consumer_id'=>['type'=>'string','enum'=>['site-core-conversions','site-core-quality']],
            'principal_ref'=>$hash,'grant_revision'=>$hash,'operation_id'=>$hash];
    }
    private static function identity_valid(array $identity): bool {
        return count($identity)===5&&!is_wp_error(rest_validate_value_from_schema($identity,
            ['type'=>'object','properties'=>self::identity_schema(),'required'=>array_keys(self::identity_schema()),'additionalProperties'=>false]));
    }
    private static function identity(array $event): array {return array_intersect_key($event,self::identity_schema());}
    public static function reference_id(array $identity): string {
        return 'service:'.hash('sha256',get_current_blog_id()."\0".$identity['provider']."\0".$identity['principal_ref']."\0".$identity['operation_id']);
    }
    public static function digest($value): string {
        $sort=static function($v)use(&$sort){if(is_array($v)){if(!array_is_list($v))ksort($v,SORT_STRING);foreach($v as &$item)$item=$sort($item);unset($item);}return $v;};
        return hash('sha256',json_encode($sort($value),JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
    }
    private static function event_valid(array $event): bool {
        if(count($event)!==10||array_diff(array_keys($event),array_merge(array_keys(self::identity_schema()),['contract','operation','state','before_sha256','after_sha256']))
            ||!self::identity_valid(self::identity($event))||($event['contract']??'')!==self::DESCRIPTOR['event_contract']
            ||!in_array($event['operation']??'', ['send-conversion-event','send-conversion-events'],true)
            ||!in_array($event['state']??'', ['dispatching','confirmed','uncertain','rejected'],true))return false;
        foreach(['before_sha256','after_sha256'] as $key){
            if(!array_key_exists($key,$event))return false;
            if($key==='after_sha256'&&$event[$key]===null)continue;
            if(!is_string($event[$key])||!preg_match('/^[a-f0-9]{64}$/D',$event[$key]))return false;
        }
        return true;
    }
    private static function proof(array $identity): ?array {
        if(!self::$registered||!self::reader()||!self::identity_valid($identity))return null;
        $p=\f3_linkedin_introspect_service_grant($identity);
        if(!is_array($p)||($p['contract']??'')!==self::CONTRACT||($p['valid']??false)!==true
            ||($p['identity']??null)!=$identity||!is_array($p['event']??null)||!self::event_valid($p['event'])
            ||self::identity($p['event'])!=$identity||!is_string($p['event_sha256']??null)
            ||!hash_equals(self::digest($p['event']),$p['event_sha256']))return null;
        return $p;
    }
    public static function status(): array {
        self::initialize();$receipt=self::receipt(self::PROVIDER,[]);
        return self::capabilities()+['providers'=>$receipt['registered']?[self::DESCRIPTOR]:[],'error_code'=>self::$error];
    }
    /** A read-only receipt confirms exact persisted bytes, not merely hook delivery. */
    public static function receipt(string $provider,array $identity=[]): array {
        $out=['contract'=>self::CONTRACT,'provider'=>$provider,'registered'=>false];
        try {
            $out['registered']=$provider===self::PROVIDER&&self::$registered&&self::reader()!==null;
            if(!$identity)return $out;
            $out+=['recorded'=>false,'event_sha256'=>null];
            if(!$out['registered']||!self::identity_valid($identity)||$identity['provider']!==$provider)return $out;
            $p=self::proof($identity);if(!$p)return $out;
            $row=Persistence::get('audit',self::reference_id($identity));
            if(self::matches($row,$identity)&&hash_equals($p['event_sha256'],$row['event_sha256']??'')){
                $out['recorded']=true;$out['event_sha256']=$row['event_sha256'];
            }
        }catch(\Throwable $e){$out['recorded']=false;$out['event_sha256']=null;}
        return $out;
    }
    private static function matches(?array $row,array $identity): bool {
        return $row!==null&&($row['kind']??'')==='service_mutation_reference'&&($row['contract']??'')===self::CONTRACT
            &&($row['site_id']??0)===get_current_blog_id()&&($row['principal_type']??'')==='service'&&($row['user']??-1)===0
            &&($row['_storage']['status']??'active')==='active'&&self::identity($row)==$identity;
    }
    public static function record(array $event) {
        try {
            self::initialize();
            if(!self::event_valid($event))return new \WP_Error('service_event_invalid','Evento de serviço inválido.');
            $identity=self::identity($event);$id=self::reference_id($identity);
            return Locks::run(['mutation-audit:'.$id=>LOCK_EX],static function()use($event,$identity,$id){
                $p=self::proof($identity);
                if(!$p||!hash_equals(self::digest($event),$p['event_sha256']))return new \WP_Error('service_authority_unavailable','Evento ou concessão não comprovados.');
                $previous=Persistence::get('audit',$id);
                if($previous&&!self::matches($previous,$identity))return new \WP_Error('service_reference_conflict','Referência incompatível.');
                if($previous&&hash_equals($previous['event_sha256'],$p['event_sha256']))return ['audit_id'=>$id,'recorded'=>true,'replayed'=>true];
                $row=['id'=>$id,'kind'=>'service_mutation_reference','contract'=>self::CONTRACT,'site_id'=>get_current_blog_id(),
                    'time'=>$previous['time']??gmdate('c'),'updated_at'=>gmdate('c'),'principal_type'=>'service','user'=>0,
                    'connection_id'=>'service:'.$identity['principal_ref'],'ability'=>'linkedin/'.$event['operation'],'target'=>'',
                    'reader'=>self::READER,'event_contract'=>self::DESCRIPTOR['event_contract'],'state'=>$event['state'],
                    'before_sha256'=>$event['before_sha256'],'after_sha256'=>$event['after_sha256'],
                    'event_sha256'=>$p['event_sha256'],'success'=>$event['state']==='confirmed']+$identity;
                if(!Persistence::put('audit',$id,$row))throw new \RuntimeException('Reference not persisted');
                return ['audit_id'=>$id,'recorded'=>true,'replayed'=>false];
            });
        }catch(\Throwable $e){Audit::write_failure();return new \WP_Error('service_persistence_failed','Referência não persistida; consulte o diário do provedor.');}
    }
    public static function allows_panel_reader(string $name): bool {
        return self::$panel&&$name===self::READER&&is_admin()&&current_user_can('manage_options')&&ConnectionContext::native_identity();
    }
    public static function read_panel(array $input): array {
        if(!is_admin()||!current_user_can('manage_options')||!ConnectionContext::native_identity())return Result::fail('service_access_denied','Permissão administrativa necessária.');
        return self::read($input,true);
    }
    public static function get(array $input): array {return self::read($input,false);}
    private static function read(array $identity,bool $panel): array {
        $prior=self::$panel;
        try {
            if(!current_user_can('manage_options'))return Result::fail('service_access_denied','Permissão administrativa necessária.');
            if(!self::identity_valid($identity))return Result::fail('service_identity_invalid','Identidade de serviço inválida.');
            if(!$panel){$policy=AuthorizationPolicy::check('audit/get-service-operation',$identity,true);if(is_wp_error($policy))return Result::error($policy);}
            $row=Persistence::get('audit',self::reference_id($identity));
            if(!self::matches($row,$identity))return Result::fail('service_not_found','Referência não encontrada ou removida pela retenção.');
            self::initialize();$p=self::proof($identity);$reader=self::reader();
            if(!$p||!$reader)return Result::fail('service_authority_unavailable','Leitor, concessão ou revisão de serviço indisponível.');
            self::$panel=$panel;$r=$reader->execute($identity);
            if(is_wp_error($r)||!is_array($r)||empty($r['success']))return Result::fail('service_read_denied','O provedor ou o perfil não autorizou esta consulta.');
            $d=$r['data']??[];
            if(($d['contract']??'')!==self::CONTRACT||($d['principal_type']??'')!=='service'||($d['identity']??null)!=$identity
                ||($d['state']??'')!==$p['event']['state']||($d['event_sha256']??'')!==$p['event_sha256']
                ||!array_key_exists('before',$d)||!array_key_exists('after',$d)
                ||self::digest($d['before'])!==$p['event']['before_sha256']
                ||($d['after']===null?null:self::digest($d['after']))!==$p['event']['after_sha256']
                ||!self::snapshots_valid($d))return Result::fail('service_result_invalid','Recibo técnico incompatível com o contrato.');
            return Result::ok(['contract'=>self::CONTRACT,'audit_id'=>$row['id'],'principal_type'=>'service','identity'=>$identity,
                'state'=>$d['state'],'reference_state'=>$row['state'],'reference_current'=>hash_equals($row['event_sha256'],$p['event_sha256']),
                'snapshot_source'=>'provider_public_reader','redacted'=>true,'before'=>$d['before'],'after'=>$d['after']]);
        }catch(\Throwable $e){return Result::fail('service_read_failed','Não foi possível consultar o recibo do provedor.');}
        finally{self::$panel=$prior;}
    }
    /** Closed technical projections: no contact identifiers or arbitrary free text. */
    private static function snapshots_valid(array $d): bool {
        if($d['before']!==['status'=>'nao_enviado'])return false;
        $a=$d['after'];if($a===null)return in_array($d['state'],['uncertain','dispatching'],true);
        return is_array($a)&&!array_diff(array_keys($a),['status','code','http','non_delivery_proven','retry_after'])
            &&in_array($a['status']??'', ['entregue','recusado','incerto'],true)&&is_string($a['code']??null)
            &&preg_match('/^[a-z][a-z0-9_]{0,99}$/D',$a['code'])&&is_int($a['http']??null)&&$a['http']>=0&&$a['http']<=599
            &&is_bool($a['non_delivery_proven']??null)&&(!isset($a['retry_after'])||is_int($a['retry_after'])&&$a['retry_after']>=0);
    }
}
