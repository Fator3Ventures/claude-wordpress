# Fator3 Site Core 1.30.0

Avisos Slack com manutenção pelo MCP existente; política de publicidade independente da medição; catálogo Pipedrive pelo canal e correções de formulários, conteúdo e cron.

Instalação nova ou atualização de referência 1.29.0, sem trava rígida por versão. Contrato 6.6.0. Matriz: MCP 0.19.0 e MCP Google 0.8.2. Temas/companheiros não são modificados.

[Documentação](docs/DOCUMENTACAO.md) · [Release e limites](docs/RELEASE-1.30.0.md) · [Slack](docs/SLACK-1.30.md) · [Publicidade](docs/PUBLICIDADE-1.30.md) · [Impactos](docs/IMPACTO-1.30.0.md) · [Validação](docs/VALIDACAO.md).
