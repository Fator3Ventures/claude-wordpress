<?php
/** Manutenção restrita aos avisos emitidos e registrados nesta instalação. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Slack_Manutencao {
    private static array $identidades=array();
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_slack_manutencao';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE {$t} (
 id char(64) NOT NULL,
 tipo varchar(16) NOT NULL,
 alvo char(64) NOT NULL DEFAULT '',
 record_id char(32) NOT NULL DEFAULT '',
 teste tinyint NOT NULL DEFAULT 0,
 site char(64) NOT NULL,
 destino char(64) NOT NULL,
 canal varchar(64) NOT NULL DEFAULT '',
 ts varchar(32) NOT NULL DEFAULT '',
 principal char(64) NOT NULL DEFAULT '',
 team_id varchar(64) NOT NULL DEFAULT '',
 bot_id varchar(64) NOT NULL DEFAULT '',
 user_id varchar(64) NOT NULL DEFAULT '',
 estado varchar(32) NOT NULL,
 revisao char(64) NOT NULL,
 payload longtext NOT NULL,
 criado_em bigint NOT NULL,
 atualizado_em bigint NOT NULL,
 PRIMARY KEY  (id),
 KEY registro (record_id,tipo),
 KEY remoto (canal,ts),
 KEY principal (principal),
 KEY tipo (tipo,criado_em)
) ENGINE=InnoDB {$wpdb->get_charset_collate()};");return !$wpdb->last_error;
    }
    private static function site(): string {return hash('sha256',home_url().'|'.wp_salt('auth'));}
    private static function erro(string $s,array $extra=array()): array {return array_merge(array('ok'=>false,'codigo'=>$s),$extra);}
    private static function linha(string $id): ?array {global $wpdb;if(!preg_match('/^[a-f0-9]{64}$/D',$id)){return null;}return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',self::tabela(),$id),ARRAY_A);}
    private static function gravar(array $r,array $data): bool {global $wpdb;$cipher=F3Base_Contato_Comunicacao::cifrar($data);if(!$cipher){return false;}$r['payload']=$cipher;return false!==$wpdb->insert(self::tabela(),$r,array_fill(0,count($r),'%s'));}
    private static function mudar(array $r,array $changes,?array $data=null): bool {global $wpdb;if($data!==null){$changes['payload']=F3Base_Contato_Comunicacao::cifrar($data);if(!$changes['payload']){return false;}}$changes['atualizado_em']=time();return $wpdb->update(self::tabela(),$changes,array('id'=>$r['id'],'revisao'=>$r['revisao']))===1;}
    public static function identidade(): array {
        $rev=F3Base_Slack::destino();if(isset(self::$identidades[$rev])){return self::$identidades[$rev];}$token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);if(!$token){return self::erro('credencial_ausente');}$r=F3Base_Slack::api('auth.test',$token,array());
        if(empty($r['ok'])||empty($r['team_id'])||empty($r['bot_id'])||empty($r['user_id'])){return empty($r['ok'])?$r:self::erro('identidade_bot_incompleta');}self::$identidades[$rev]=$r;return $r;
    }
    /** Persiste classificação antes de enviar; nunca deriva teste de um texto remoto. */
    public static function preparar(array $p,array $message,bool $teste,string $tipo='parte'): array {
        $old=self::linha($p['chave']);if($old){return $old['site']===self::site()&&$old['destino']===F3Base_Slack::destino()?array('ok'=>true,'id'=>$old['id']):self::erro('registro_de_outra_instalacao_ou_destino');}
        $who=self::identidade();if(empty($who['ok'])){return $who;}$r=array('id'=>$p['chave'],'tipo'=>$tipo,'alvo'=>$tipo==='parte'?$p['chave']:'','record_id'=>$p['record_id']??'','teste'=>$teste?1:0,'site'=>self::site(),'destino'=>F3Base_Slack::destino(),'canal'=>$p['canal'],'ts'=>'','principal'=>$p['principal']??'','team_id'=>$who['team_id'],'bot_id'=>$who['bot_id'],'user_id'=>$who['user_id'],'estado'=>'preparado','revisao'=>hash('sha256',wp_json_encode($message)),'criado_em'=>time(),'atualizado_em'=>time());
        return self::gravar($r,array('mensagem'=>$message,'autor'=>get_current_user_id()))?array('ok'=>true,'id'=>$r['id']):self::erro('registro_previo_falhou');
    }
    public static function concluir(string $id,array $res): bool {$r=self::linha($id);if(!$r){return false;}$d=F3Base_Contato_Comunicacao::abrir($r['payload']);$d['aceite']=$res;$changes=array('estado'=>!empty($res['ok'])?'aceito':(!empty($res['recusado'])||!empty($res['permanente'])||!empty($res['retry_after'])?'recusado':'incerto'));if(!empty($res['ok'])){$changes['ts']=$res['ts'];$changes['canal']=$res['canal'];}return self::mudar($r,$changes,$d);}
    public static function teste(): array {
        $c=F3Base_Options::ler('f3base_avisos');$id=hash('sha256',wp_generate_uuid4());$message=array('text'=>'[TESTE] Site Core · '.sanitize_text_field(get_bloginfo('name')).' · verificação solicitada pelo administrador.','blocks'=>array(),'unfurl_links'=>false,'unfurl_media'=>false);$p=array('chave'=>$id,'canal'=>$c['slack_canal_id']);$r=self::preparar($p,$message,true,'teste');if(empty($r['ok'])){return $r;}
        $res=F3Base_Slack::api('chat.postMessage',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),$message+array('channel'=>$p['canal']));$saved=self::concluir($id,$res);return array_merge($res,array('id_local'=>$id,'registro_persistido'=>$saved,'codigo'=>$saved?$res['codigo']:'resultado_incerto_nao_persistido'));
    }
    private static function alvo(string $id): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}$r=self::linha($id);if(!$r||!in_array($r['tipo'],array('parte','teste'),true)){return self::erro('alvo_nao_registrado');}
        if($r['site']!==self::site()||$r['destino']!==F3Base_Slack::destino()){return self::erro('instalacao_ou_destino_divergente');}if($r['estado']==='eliminado'){return self::erro('contato_eliminado');}if(!$r['ts']||!$r['team_id']||!$r['bot_id']||!$r['user_id']){return self::erro('referencia_remota_nao_comprovada');}
        $who=self::identidade();if(empty($who['ok'])){return $who;}foreach(array('team_id','bot_id','user_id') as $k){if($who[$k]!==$r[$k]){return self::erro('autoria_ou_workspace_divergente');}}
        return array('ok'=>true,'registro'=>$r);
    }
    public static function publico(array $r): array {return array_intersect_key($r,array_flip(array('id','tipo','record_id','teste','canal','ts','principal','estado','revisao','criado_em','atualizado_em')))+array('criado_legivel'=>wp_date('d/m/Y H:i:s',(int)$r['criado_em']),'manutencao_disponivel'=>$r['site']===self::site()&&$r['destino']===F3Base_Slack::destino()&&$r['ts']!=='');}
    public static function listar(array $e=array()): array {
        global $wpdb;$where="tipo IN ('parte','teste')";if(!empty($e['record_id'])){$where.=$wpdb->prepare(' AND record_id=%s',$e['record_id']);}if(isset($e['teste'])){$where.=$wpdb->prepare(' AND teste=%d',$e['teste']?1:0);}if(($e['origem']??'')==='teste_conexao'){$where.=" AND tipo='teste'";}elseif(($e['origem']??'')==='contato'){$where.=" AND tipo='parte'";}
        $page=max(1,(int)($e['pagina']??1));$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY criado_em DESC,id LIMIT 51 OFFSET %d",self::tabela(),($page-1)*50),ARRAY_A)?:array();return array('linhas'=>array_map(array(__CLASS__,'publico'),array_slice($rows,0,50)),'proxima_pagina'=>count($rows)>50?$page+1:null);
    }
    private static function remota(array $r,bool $thread=false,string $cursor=''): array {
        $root=$r['principal']?self::linha($r['principal']):$r;if($thread&&(!$root||!$root['ts'])){return self::erro('principal_nao_registrada');}
        $body=$thread?array('channel'=>$r['canal'],'ts'=>$root['ts'],'limit'=>15):array('channel'=>$r['canal'],'oldest'=>$r['ts'],'latest'=>$r['ts'],'inclusive'=>true,'limit'=>1);if($cursor!==''){$body['cursor']=$cursor;}
        $x=F3Base_Slack::api($thread?'conversations.replies':'conversations.history',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),$body);if(empty($x['ok'])){return $x;}
        $msgs=$x['messages'];foreach($msgs as $m){if(!is_array($m)||!is_string($m['ts']??null)||!preg_match('/^[0-9]+\.[0-9]+$/D',$m['ts'])){return self::erro('slack_historico_invalido');}}
        if(!$thread){$msgs=array_values(array_filter($msgs,static fn($m)=>$m['ts']===$r['ts']));if(!$msgs&&($x['has_more']||$x['cursor']!=='')){return self::erro('slack_consulta_incompleta');}}
        return array('ok'=>true,'messages'=>$msgs,'cursor'=>$x['cursor'],'parcial'=>$x['has_more']||$x['cursor']!=='','principal'=>$root['id']??$r['id']);
    }
    private static function hash_remoto(array $m): string {return hash('sha256',wp_json_encode(array($m['text']??'',self::blocos($m['blocks']??array()))));}
    private static function blocos(array $blocks): array {foreach($blocks as &$b){if(is_array($b)){unset($b['block_id']);}}return $blocks;}
    private static function propria(array $m,array $r): bool {return ($m['user']??'')===$r['user_id']&&(!isset($m['bot_id'])||$m['bot_id']===$r['bot_id'])&&(!isset($m['team'])||$m['team']===$r['team_id']);}
    public static function ler(array $e): array {
        if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}try{
            $a=self::alvo((string)($e['id']??''));if(empty($a['ok'])){return $a;}$r=$a['registro'];$thread=!empty($e['incluir_thread']);$cursor=(string)($e['cursor']??'');if(strlen($cursor)>2048||(!$thread&&$cursor!=='')){return self::erro('cursor_invalido');}$x=self::remota($r,$thread,$cursor);
            if(empty($x['ok'])){return $x+array('local'=>self::publico($r),'presenca'=>'nao_verificavel','orientacao'=>($x['codigo']??'')==='slack_missing_scope'?'Autorize channels:history ou groups:history no mesmo aplicativo. A entrega anterior permanece registrada.':'Consulta indisponível; não comprova ausência.');}
            $messages=array();foreach($x['messages'] as $m){$messages[]=array_intersect_key($m,array_flip(array('ts','thread_ts','user','bot_id','text','blocks','reply_count','edited')))+array('horario'=>wp_date('d/m/Y H:i:s',(int)$m['ts']),'propria'=>self::propria($m,$r),'revisao_remota'=>self::hash_remoto($m));}
            $found=array_values(array_filter($x['messages'],static fn($m)=>$m['ts']===$r['ts']));$local=F3Base_Contato_Comunicacao::abrir($r['payload'])['mensagem']??array();$presence=$found&&empty($local)?'confirmada':($found?((($found[0]['text']??'')===($local['text']??'')&&self::blocos($found[0]['blocks']??array())===self::blocos($local['blocks']??array()))?'confirmada':'conteudo_divergente'):($thread?'fora_desta_pagina':'ausente'));
            return array('ok'=>true,'id'=>$r['id'],'local'=>self::publico($r),'aceito_pela_api'=>$r['ts']!=='','presenca'=>$presence,'conformidade'=>empty($local)?'conteudo_local_indisponivel':$presence,'verificado_em'=>time(),'leitura_humana'=>'não comprovada','mensagens'=>$messages,'cursor'=>$x['cursor'],'parcial'=>$x['parcial'],'cobertura'=>$thread?'Página da thread vinculada; completa somente após percorrer todos os cursores.':'Consulta exata da mensagem registrada.');
        }finally{F3Base_Recuperacao::sair();}
    }
    public static function verificar(array $e): array {
        $r=self::ler($e);if(empty($r['ok'])){return $r;}global $wpdb;$source=self::linha((string)$e['id']);$root=$source['principal']?:$source['id'];$rows=$wpdb->get_results($wpdb->prepare("SELECT id,ts,estado FROM %i WHERE id=%s OR principal=%s ORDER BY criado_em,id",self::tabela(),$root,$root),ARRAY_A)?:array();$seen=array_column($r['mensagens'],'ts');$r['partes_esperadas']=array_map(static fn($p)=>array('id'=>$p['id'],'ts'=>$p['ts'],'estado_local'=>$p['estado'],'presenca_nesta_consulta'=>in_array($p['ts'],$seen,true)?'encontrada':'nao_coberta'),$rows);return $r;
    }
    public static function limpo(string $record): bool {global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM %i WHERE record_id=%s AND tipo='parte' AND teste=1 AND estado='apagada' LIMIT 1",self::tabela(),$record));}

    private static function operacao(string $kind,array $e,callable $run): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}$lock=null;try{
            $sim=($e['simular']??true)!==false;if($sim){return $run(true);}$key=(string)($e['chave_operacao']??'');if(!preg_match('/^[A-Za-z0-9._:-]{8,128}$/D',$key)){return self::erro('chave_operacao_obrigatoria');}$id=hash('sha256',$kind.'|'.self::site().'|'.$key);$hash=hash('sha256',wp_json_encode($e));$lock=F3Base_Trava::adquirir('slack-transporte',45);if(!$lock){return self::erro('slack_transporte_ocupado');}
            $old=self::linha($id);if($old){if($old['revisao']!==$hash){return self::erro('chave_operacao_reutilizada');}$saved=F3Base_Contato_Comunicacao::abrir($old['payload']);return ($saved['resultado']??self::erro('operacao_incerta_consulte_antes_de_repetir'))+array('repetida'=>true,'operacao_id'=>$id);}
            $r=array('id'=>$id,'tipo'=>'operacao','alvo'=>(string)($e['id']??''),'site'=>self::site(),'destino'=>F3Base_Slack::destino(),'estado'=>'iniciada','revisao'=>$hash,'criado_em'=>time(),'atualizado_em'=>time());$data=array('acao'=>$kind,'entrada'=>$e,'autor'=>get_current_user_id());if(!self::gravar($r,$data)){return self::erro('auditoria_previa_falhou');}
            $res=$run(false);$data['resultado']=$res;if(!self::mudar($r,array('estado'=>!empty($res['ok'])?'concluida':'interrompida'),$data)){return self::erro('resultado_incerto_nao_persistido',array('operacao_id'=>$id));}return $res+array('operacao_id'=>$id);
        }finally{if($lock){F3Base_Trava::liberar($lock);}F3Base_Recuperacao::sair();}
    }
    private static function mensagem(array $e,array $r): array {
        if(($e['modo']??'')==='substituir'){$text=$e['texto']??null;if(!is_string($text)||trim($text)===''||mb_strlen($text)>39000){return self::erro('texto_vazio_ou_excede_limite');}$blocks=array();foreach(mb_str_split($text,2800) as $s){$blocks[]=array('type'=>'section','text'=>array('type'=>'plain_text','text'=>$s));}$m=array('text'=>$text,'blocks'=>$blocks);}
        elseif(($e['modo']??'')==='regenerar'){
            if($r['tipo']!=='parte'){return self::erro('teste_sem_contato_para_regenerar');}global $wpdb;$p=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',F3Base_Slack::tabela(),$r['id']),ARRAY_A);$lead=F3Base_Leads_Repositorio::obter($r['record_id']);if(!$p||!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){return self::erro('contato_indisponivel');}if((int)$p['sequencia']<0){return self::erro('resumo_compartilhado_use_substituir');}
            $a=F3Base_Contato_Apresentacao::montar($lead);$notice=F3Base_Avisos::linha($p['aviso']);$meta=$notice?F3Base_Avisos::abrir($notice['payload']):array();$shared=$p['principal']?self::linha($p['principal']):null;
            if($p['tipo']==='complemento'){$m=F3Base_Slack::simples('Atualização do contato',F3Base_Contato_Apresentacao::secoes($a),$a['registro_url']);}else{$summary=$shared?(int)$wpdb->get_var($wpdb->prepare('SELECT sequencia FROM %i WHERE chave=%s',F3Base_Slack::tabela(),$shared['id'])):0;$format=$shared&&$summary<0?'completo':($meta['formato']??'thread');$messages=F3Base_Slack::mensagens($a,$format);$m=$messages[(int)$p['sequencia']]??null;if(!$m){return self::erro('parte_sem_equivalente_use_substituir');}}
        }else{return self::erro('modo_invalido');}
        if(count($m['blocks']??array())>50||mb_strlen($m['text']??'')>39000){return self::erro('correcao_excede_uma_mensagem');}unset($m['channel'],$m['ts'],$m['thread_ts']);return array('ok'=>true,'mensagem'=>array('text'=>$m['text'],'blocks'=>$m['blocks']??array()));
    }
    public static function corrigir(array $e): array {return self::operacao('corrigir',$e,static function(bool $sim)use($e){
        $a=self::alvo((string)($e['id']??''));if(empty($a['ok'])){return $a;}$r=$a['registro'];if($r['estado']==='apagada'){return self::erro('mensagem_removida');}if(!hash_equals($r['revisao'],(string)($e['revisao']??''))){return self::erro('revisao_divergente',array('revisao'=>$r['revisao']));}$m=self::mensagem($e,$r);if(empty($m['ok'])){return $m;}$old=F3Base_Contato_Comunicacao::abrir($r['payload']);
        if($sim){return array('ok'=>true,'simular'=>true,'id'=>$r['id'],'revisao'=>$r['revisao'],'antes'=>$old['mensagem']??array(),'depois'=>$m['mensagem'],'preserva_ts'=>$r['ts'],'principal'=>$r['principal']);}
        $remote=self::remota($r);if(!empty($remote['ok'])){if(!$remote['messages']){return self::erro('mensagem_ausente');}$msg=$remote['messages'][0];if(!self::propria($msg,$r)){return self::erro('mensagem_de_outro_autor');}if(!empty($e['revisao_remota'])&&!hash_equals(self::hash_remoto($msg),(string)$e['revisao_remota'])){return self::erro('revisao_remota_divergente');}if(self::hash_remoto($msg)!==self::hash_remoto($old['mensagem']??array())&&empty($e['revisao_remota'])){return self::erro('conteudo_remoto_divergente',array('orientacao'=>'Consulte a mensagem e reconcilie a fonte antes de alterar.'));}}elseif(($remote['codigo']??'')!=='slack_missing_scope'){return $remote;}
        $res=F3Base_Slack::api('chat.update',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$r['canal'],'ts'=>$r['ts'],'text'=>$m['mensagem']['text'],'blocks'=>$m['mensagem']['blocks'],'parse'=>'none'));if(empty($res['ok'])){return $res;}
        $rev=hash('sha256',$r['revisao'].'|'.wp_json_encode($m['mensagem']).'|'.($e['chave_operacao']??''));$old['mensagem']=$m['mensagem'];$old['correcao']=array('em'=>time(),'autor'=>get_current_user_id(),'motivo'=>sanitize_textarea_field($e['motivo']??''));$ok=self::mudar($r,array('estado'=>'corrigida','revisao'=>$rev),$old);return array('ok'=>$ok,'codigo'=>$ok?'mensagem_corrigida':'resultado_incerto_nao_persistido','id'=>$r['id'],'ts'=>$r['ts'],'revisao'=>$rev,'anterior'=>$remote['messages'][0]??null,'depois'=>$m['mensagem']);
    });}
    private static function selecao(array $ids): array {if(!$ids||count($ids)>20||count(array_unique($ids))!==count($ids)){return self::erro('selecao_invalida');}$rows=array();foreach($ids as $id){$a=self::alvo((string)$id);if(empty($a['ok'])){return $a;}if(!(int)$a['registro']['teste']){return self::erro('mensagem_de_producao');}$rows[]=$a['registro'];}usort($rows,static fn($a,$b)=>((int)($b['principal']!==''))<=>((int)($a['principal']!=='')));$versions=array();foreach($rows as $r){$versions[$r['id']]=$r['revisao'].'|'.$r['estado'];}ksort($versions);return array('ok'=>true,'linhas'=>$rows,'revisao'=>hash('sha256',wp_json_encode($versions)));}
    private static function principal_livre(array $r): array {
        $cursor='';$seen=array();for($i=0;$i<20;$i++){$x=self::remota($r,true,$cursor);if(empty($x['ok'])){return $x;}foreach($x['messages'] as $m){if($m['ts']===$r['ts']){continue;}global $wpdb;$known=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE canal=%s AND ts=%s AND tipo IN ('parte','teste') LIMIT 1",self::tabela(),$r['canal'],$m['ts']),ARRAY_A);if(!$known||!(int)$known['teste']||$known['site']!==self::site()||!self::propria($m,$known)){return self::erro('principal_preservada_resposta_humana_ou_producao');}return self::erro('principal_preservada_resposta_ainda_presente');}
            if(!$x['parcial']){return array('ok'=>true);}$cursor=$x['cursor'];if($cursor===''||isset($seen[$cursor])){break;}$seen[$cursor]=true;
        }return self::erro('principal_preservada_thread_incompleta');
    }
    public static function apagar(array $e): array {return self::operacao('apagar',$e,static function(bool $sim)use($e){
        $s=self::selecao(is_array($e['ids']??null)?$e['ids']:array());if(empty($s['ok'])){return $s;}if($sim){return array('ok'=>true,'simular'=>true,'revisao'=>$s['revisao'],'alvos'=>array_map(array(__CLASS__,'publico'),$s['linhas']),'regra'=>'Respostas antes da principal. A principal só é apagada após leitura completa sem respostas restantes.');}if(!hash_equals($s['revisao'],(string)($e['revisao']??''))){return self::erro('selecao_alterada',array('revisao'=>$s['revisao']));}
        $results=array();foreach($s['linhas'] as $r){if($r['estado']==='apagada'){$results[]=array('id'=>$r['id'],'ok'=>true,'codigo'=>'ja_apagada');continue;}$remote=self::remota($r);if(empty($remote['ok'])){$results[]=$remote+array('id'=>$r['id']);continue;}
            if($remote['messages']){if(!self::propria($remote['messages'][0],$r)){$results[]=self::erro('autoria_divergente',array('id'=>$r['id']));continue;}if(!$r['principal']){$safe=self::principal_livre($r);if(empty($safe['ok'])){$results[]=$safe+array('id'=>$r['id']);continue;}}
                $res=F3Base_Slack::api('chat.delete',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$r['canal'],'ts'=>$r['ts']));if(empty($res['ok'])){$results[]=$res+array('id'=>$r['id']);if(($res['codigo']??'')==='slack_resultado_incerto'){break;}continue;}$code='teste_apagado';
            }else{$code='ausencia_comprovada';}
            $d=F3Base_Contato_Comunicacao::abrir($r['payload']);$d['remocao']=array('em'=>time(),'autor'=>get_current_user_id(),'codigo'=>$code);$ok=self::mudar($r,array('estado'=>'apagada'),$d);$results[]=array('id'=>$r['id'],'ok'=>$ok,'codigo'=>$ok?$code:'resultado_incerto_nao_persistido');
            if($ok&&$r['tipo']==='parte'){global $wpdb;$p=$wpdb->get_row($wpdb->prepare('SELECT aviso FROM %i WHERE chave=%s',F3Base_Slack::tabela(),$r['id']),ARRAY_A);if($p){$wpdb->query($wpdb->prepare("UPDATE %i SET estado='suprimido',codigo='teste_limpo',proxima=0 WHERE aviso=%s AND estado IN ('pendente','suspenso')",F3Base_Slack::tabela(),$p['aviso']));}}
        }
        $complete=count($results)===count($s['linhas'])&&!array_filter($results,static fn($x)=>empty($x['ok']));return array('ok'=>$complete,'parcial'=>!$complete,'codigo'=>$complete?'limpeza_concluida':'limpeza_parcial','resultados'=>$results,'entrega_historica_preservada'=>true,'contatos_eliminados'=>0);
    });}
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            $read=array('id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'incluir_thread'=>array('type'=>'boolean'),'cursor'=>array('type'=>'string','maxLength'=>2048));foreach(array('ler','verificar') as $action){F3Base_Servicos::ability('avisos-slack-'.$action,'Consultar presença ou thread de aviso registrado; não comprova leitura humana',array(__CLASS__,$action),$read,array('id'));}
            $write=array('simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'chave_operacao'=>array('type'=>'string','maxLength'=>128),'motivo'=>array('type'=>'string','maxLength'=>500));F3Base_Servicos::ability('avisos-slack-corrigir','Corrigir parte própria registrada, conservando timestamp e thread',array(__CLASS__,'corrigir'),$write+array('id'=>$read['id'],'modo'=>array('type'=>'string','enum'=>array('regenerar','substituir')),'texto'=>array('type'=>'string','maxLength'=>39000),'revisao_remota'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$')),array('id','modo','revisao'),false);
            F3Base_Servicos::ability('avisos-slack-testes-apagar','Apagar somente mensagens emitidas como testes pelo Core; preservar respostas de terceiros',array(__CLASS__,'apagar'),$write+array('ids'=>array('type'=>'array','minItems'=>1,'maxItems'=>20,'uniqueItems'=>true,'items'=>$read['id'])),array('ids'),false);
        });
        add_action('admin_post_f3base_slack_manutencao',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão');}check_admin_referer('f3base-slack-manutencao');$e=array('id'=>sanitize_key($_POST['id']??''),'revisao'=>sanitize_text_field($_POST['revisao']??''),'simular'=>!empty($_POST['simular']),'chave_operacao'=>sanitize_text_field($_POST['chave_operacao']??''),'modo'=>sanitize_key($_POST['modo']??'substituir'),'revisao_remota'=>sanitize_text_field($_POST['revisao_remota']??''),'texto'=>sanitize_textarea_field(wp_unslash($_POST['texto']??'')),'motivo'=>sanitize_textarea_field(wp_unslash($_POST['motivo']??'')),'cursor'=>sanitize_text_field($_POST['cursor']??''));$action=sanitize_key($_POST['operacao']??'ler');if($action==='thread'){$e['incluir_thread']=true;$action='ler';}if($action==='apagar'){$e['ids']=array($e['id']);unset($e['id']);}$r=in_array($action,array('ler','verificar','corrigir','apagar'),true)?self::$action($e):self::erro('acao_invalida');echo '<div class="wrap"><h1>Resultado da manutenção do aviso</h1><pre style="white-space:pre-wrap">'.esc_html(wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre><p><a href="'.esc_url(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=avisos')).'">Voltar aos avisos</a></p></div>';});
        add_action(F3Base_Leads_Notificacoes::EVENTO,static function(){global $wpdb;$wpdb->query($wpdb->prepare("UPDATE %i SET payload='' WHERE estado NOT IN ('preparado','incerto','iniciada') AND atualizado_em<%d AND payload<>''",self::tabela(),time()-90*DAY_IN_SECONDS));});
    }
    public static function eliminar(string $id): void {global $wpdb;$ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM %i WHERE record_id=%s AND tipo='parte'",self::tabela(),$id));foreach($ids as $target){$wpdb->query($wpdb->prepare("UPDATE %i SET payload='',estado='eliminado' WHERE id=%s OR alvo=%s",self::tabela(),$target,$target));}}
    public static function controles(string $id): void {
        $r=self::linha($id);if(!$r){echo '<p>Manutenção indisponível: emissão anterior sem prova de autoria registrada.</p>';return;}$p=self::publico($r);echo '<p>Entrega: '.esc_html($r['estado']).' · '.esc_html($p['criado_legivel']).'. Presença remota e leitura humana são verificações distintas.</p>';if(!$p['manutencao_disponivel']){return;}
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_slack_manutencao"><input type="hidden" name="id" value="'.esc_attr($id).'"><input type="hidden" name="revisao" value="'.esc_attr($r['revisao']).'"><input type="hidden" name="chave_operacao" value="'.esc_attr(wp_generate_uuid4()).'">';wp_nonce_field('f3base-slack-manutencao');echo '<button class="button" name="operacao" value="verificar">Conferir no Slack</button> <button class="button" name="operacao" value="thread">Ver thread</button><label> Cursor da próxima página <input name="cursor"></label><details><summary>Corrigir mensagem</summary><label>Modo <select name="modo"><option value="substituir">Substituir esta parte</option><option value="regenerar">Regenerar pelo contato</option></select></label><p><textarea name="texto" rows="8" cols="80" placeholder="Texto legível, com quebras de linha"></textarea></p><label>Motivo <input name="motivo"></label><label> Revisão remota conferida (opcional) <input name="revisao_remota"></label><label><input type="checkbox" name="simular" value="1" checked> Mostrar prévia</label> <button class="button" name="operacao" value="corrigir">Aplicar correção</button></details></form>';
        if((int)$r['teste']){$s=array('ok'=>true,'revisao'=>hash('sha256',wp_json_encode(array($id=>$r['revisao'].'|'.$r['estado']))));if(!empty($s['ok'])){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_slack_manutencao"><input type="hidden" name="id" value="'.esc_attr($id).'"><input type="hidden" name="revisao" value="'.esc_attr($s['revisao']).'"><input type="hidden" name="chave_operacao" value="'.esc_attr(wp_generate_uuid4()).'">';wp_nonce_field('f3base-slack-manutencao');echo '<label><input type="checkbox" name="simular" value="1" checked> Mostrar prévia da limpeza</label> <button class="button" name="operacao" value="apagar">Apagar teste</button></form>';}}
    }
    public static function tela(): void {echo '<details><summary>Testes e capacidades de manutenção do Slack</summary><p>Usa o mesmo bot e canal. Ler exige channels:history (público) ou groups:history (privado); editar e apagar mensagens próprias usa chat:write. Ausência de escopo aparece no resultado da consulta. Webhooks não permitem manutenção remota. Não há consultas automáticas ao abrir esta tela.</p>';foreach(self::listar(array('origem'=>'teste_conexao'))['linhas'] as $r){echo '<details><summary>'.esc_html($r['criado_legivel'].' · '.$r['estado']).'</summary>';self::controles($r['id']);echo '</details>';}echo '</details>';}
}
