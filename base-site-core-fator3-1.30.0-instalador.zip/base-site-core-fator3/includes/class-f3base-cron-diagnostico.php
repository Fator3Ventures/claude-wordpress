<?php
/** Observa falhas do WP-Cron sem suprimir logs nem alterar ganchos de terceiros. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Cron_Diagnostico {
    private static array $tentativas=array();
    private static bool $retomando=false;
    public static function iniciar(): void {
        add_filter('pre_reschedule_event',static function($pre,$e){if(str_starts_with($e->hook,'f3base_')){$interval=(int)$e->interval;$now=time();$at=(int)$e->timestamp;
            if($interval>0){$at=$at>=$now?$now+$interval:$now+($interval-(($now-$at)%$interval));}
            self::$tentativas['reagendar|'.$e->hook.'|'.md5(serialize($e->args))]=array('timestamp'=>$at,'schedule'=>$e->schedule,'args'=>$e->args);
        }return $pre;},PHP_INT_MAX,2);
        add_filter('pre_unschedule_event',static function($pre,$at,$hook,$args){if(str_starts_with($hook,'f3base_')){self::$tentativas['remover|'.$hook.'|'.md5(serialize($args))]=array('timestamp'=>(int)$at,'args'=>$args,'schedule'=>false);}return $pre;},PHP_INT_MAX,4);
        foreach(array('cron_reschedule_event_error'=>'reagendar','cron_unschedule_event_error'=>'remover') as $hook=>$op){add_action($hook,static fn($error,$name,$data)=>self::observar($op,$error,$name,$data),10,3);}
    }
    public static function observar(string $op,$error,string $hook,array $data): void {
        if(self::$retomando||!str_starts_with($hook,'f3base_')||!in_array($op,array('reagendar','remover'),true)){return;}
        $args=$data['args']??array();$event=self::$tentativas[$op.'|'.$hook.'|'.md5(serialize($args))]??null;
        $proof=$event?self::conferir($op,$hook,$event):null;$code=$proof===true?'estado_desejado_confirmado':($proof===false?'agenda_nao_confirmada':'causa_indeterminada');
        $origin=defined('WP_CLI')&&WP_CLI?'cli':(wp_doing_cron()?'http_cron':'manual');$key=hash('sha256',$op.'|'.$hook.'|'.serialize($event));$at=time();
        F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($op,$hook,$event,$proof,$code,$origin,$key,$error,$at){
            $s['wp_observacoes']=array_values(array_filter($s['wp_observacoes']??array(),static fn($r)=>$r['em']>time()-DAY_IN_SECONDS));
            $s['wp_observacoes'][]=array('em'=>$at,'hook'=>$hook,'operacao'=>$op,'origem'=>$origin,'erro'=>is_wp_error($error)?sanitize_key($error->get_error_code()):'desconhecido','codigo'=>$code,'timestamp'=>$event['timestamp']??null,'concorrencia_comprovada'=>false);
            $s['wp_observacoes']=array_slice($s['wp_observacoes'],-100);
            $h=gmdate('YmdH');$s['wp_contadores'][$h][$hook][$code]=($s['wp_contadores'][$h][$hook][$code]??0)+1;
            foreach(array_keys($s['wp_contadores']) as $old){if((string)$old<gmdate('YmdH',time()-DAY_IN_SECONDS)){unset($s['wp_contadores'][$old]);}}
            if($proof!==true&&$event){$s['wp_retentativas'][$key]=array('hook'=>$hook,'operacao'=>$op,'evento'=>F3Base_Contato_Comunicacao::cifrar($event),'tentar_em'=>time()+60,'tentativas'=>0);}
            return $s;
        });
    }
    private static function conferir(string $op,string $hook,array $event): ?bool {
        global $wpdb;wp_cache_delete('cron','options');wp_cache_delete('alloptions','options');
        $raw=$wpdb->get_var($wpdb->prepare('SELECT option_value FROM %i WHERE option_name=%s',$wpdb->options,'cron'));if($wpdb->last_error){return null;}
        $cron=maybe_unserialize($raw);if(!is_array($cron)){return null;}
        $got=$cron[$event['timestamp']][$hook][md5(serialize($event['args']))]??null;
        if($op==='reagendar'&&$got===null){foreach($cron as $at=>$hooks){$later=$hooks[$hook][md5(serialize($event['args']))]??null;if(is_numeric($at)&&(int)$at>=$event['timestamp']&&$later&&$later['args']===$event['args']&&($later['schedule']??false)===$event['schedule']){return true;}}}
        return $op==='remover'?$got===null:($got!==null&&$got['args']===$event['args']&&($got['schedule']??false)===$event['schedule']);
    }
    public static function retomar(): void {
        if(self::$retomando){return;}self::$retomando=true;
        try {$state=get_option('f3base_agenda',array());$n=0;
            foreach($state['wp_retentativas']??array() as $key=>$job){
                if($n>=3){break;}if($job['tentar_em']>time()||$job['tentativas']>=5){continue;}$n++;
                $lock=F3Base_Trava::adquirir('agenda-'.substr(hash('sha256',$job['hook']),0,32),30);if(!$lock){continue;}
                try{$event=F3Base_Contato_Comunicacao::abrir($job['evento']);$proof=$event?self::conferir($job['operacao'],$job['hook'],$event):null;
                    if($event&&$proof===false){
                        if($job['operacao']==='remover'){wp_unschedule_event($event['timestamp'],$job['hook'],$event['args'],true);}
                        else{wp_schedule_event($event['timestamp'],$event['schedule'],$job['hook'],$event['args'],true);}
                        $proof=self::conferir($job['operacao'],$job['hook'],$event);
                    }
                    F3Base_Options::atualizar_estado('f3base_agenda',static function($s)use($key,$proof){if(!isset($s['wp_retentativas'][$key])){return $s;}if($proof===true){unset($s['wp_retentativas'][$key]);}else{$s['wp_retentativas'][$key]['tentativas']++;$s['wp_retentativas'][$key]['tentar_em']=time()+min(3600,60*2**$s['wp_retentativas'][$key]['tentativas']);}return $s;});
                }finally{F3Base_Trava::liberar($lock);}
            }
        }finally{self::$retomando=false;}
    }
    public static function resumo(): array {
        $s=get_option('f3base_agenda',array());$pending=array();foreach($s['wp_retentativas']??array() as $key=>$r){$pending[]=array('chave'=>$key,'hook'=>$r['hook'],'operacao'=>$r['operacao'],'tentativas'=>$r['tentativas'],'tentar_em'=>$r['tentar_em'],'esgotado'=>$r['tentativas']>=5);}
        return array('observacoes'=>$s['wp_observacoes']??array(),'contagens_por_hora'=>$s['wp_contadores']??array(),'pendencias'=>$pending,'documentacao'=>'docs/CRON-DIAGNOSTICO-1.30.md','explicacao'=>'A linha é emitida pelo WordPress. could_not_set sozinho não comprova perda de agenda nem concorrência benigna; confira o estado após releitura.');
    }
}

