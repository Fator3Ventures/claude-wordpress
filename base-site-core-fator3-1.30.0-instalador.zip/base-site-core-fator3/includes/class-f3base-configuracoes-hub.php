<?php
/** Entrada única das configurações; as telas de trabalho continuam em Contatos e Medição. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Configuracoes_Hub {
    public static function url(string $secao='inicio',string $integracao=''): string {
        $args=array('page'=>F3Base_Admin_Tela::SLUG,'secao'=>$secao);
        if($integracao!==''){$args['integracao']=$integracao;}
        return add_query_arg($args,admin_url('admin.php'));
    }
    public static function iniciar(): void {
        add_action('init',static function(){
            if(is_admin()&&($_GET['page']??'')==='f3base-integracoes'&&($_SERVER['REQUEST_METHOD']??'GET')==='GET'&&current_user_can('manage_options')){
                $args=array_intersect_key(wp_unslash($_GET),array_flip(array('integracao','pagina','estado')));
                wp_safe_redirect(add_query_arg($args,self::url('conexoes')));exit;
            }
        });
        add_action('admin_menu',static function(){remove_submenu_page('f3base-leads','f3base-integracoes');},1000);
    }
    public static function navegar(string $ativa): void {
        echo '<nav class="f3base-config-nav" aria-label="Configurações do site">';
        foreach(F3Base_Interface::ABAS as $key=>$label){$active=$ativa===$key||($key==='medicao'&&isset(F3Base_Interface::MEDICAO[$ativa]));
            echo '<a href="'.esc_url(self::url($key)).'" '.($active?'aria-current="page"':'').'>'.esc_html($label).'</a>';
        }echo '</nav>';
        if(isset(F3Base_Interface::MEDICAO[$ativa])){echo '<nav class="f3base-config-subnav" aria-label="Áreas da medição">';foreach(F3Base_Interface::MEDICAO as $key=>$label){echo '<a href="'.esc_url(self::url($key)).'" '.($ativa===$key?'aria-current="page"':'').'>'.esc_html($label).'</a>';}echo '</nav>';}
    }
    public static function inicio(): void {
        echo '<h2>O que você quer configurar?</h2><p>As configurações do site estão reunidas aqui. Use Contatos para atender pessoas e editar formulários; use Medição para analisar resultados.</p><label for="f3base-busca-config">Buscar uma configuração</label><input type="search" class="regular-text" id="f3base-busca-config" placeholder="Ex.: WhatsApp, Meta, token, retenção"><p id="f3base-busca-status" role="status" aria-live="polite"></p><div class="f3base-config-cards">';
        $cards=array(
            array('contato','','Contato e atendimento','Destinatários de e-mail, WhatsApp, CTAs e confirmação de envio.','telefone formulário aviso destinatário'),
            array('conexoes','avisos','Avisos à equipe','Escolha e-mail, Slack ou webhook; acompanhe falhas e contingência.','slack mensagem resumo'),
            array('conexoes','f3base_pipedrive','Pipedrive','Conecte a conta, escolha campos e alternativas e confira as entregas.','CRM token pessoa lead negociação'),
            array('conexoes','f3base_anuncios_meta','Formulários de anúncios','Importe contatos de páginas e formulários autorizados. Cada site conserva seu próprio mapa.','meta facebook instagram google ads'),
            array('conexoes','qualidade','Qualidade e retorno à Meta','Relacione etapas comerciais a eventos. Regras podem variar por formulário e campanha.','pipedrive funil pipeline conversão dataset'),
            array('medicao-tags','','Tags de anúncios e medição','GA4, GTM, Google Ads e LinkedIn, com controle de carregamento.','analytics contêiner identificador'),
            array('medicao-meta','','Pixel e envio Meta','Dataset, token e transporte das conversões do site.','facebook instagram capi'),
            array('medicao-coleta','','Audiência no próprio site','Coleta, atribuição e retenção para analisar conteúdo e comportamento.','sessão jornada histórico visitantes robôs IA'),
            array('medicao-gsc','','Search Console','Propriedade Google e coleta do desempenho de busca.','orgânico SEO'),
            array('medicao-clarity','','Microsoft Clarity','Projeto, token de exportação e histórico analítico.','mapa calor gravação'),
            array('medicao-testes','','Testes de agentes e equipe','Exclua testes dos resultados comerciais sem perder o diagnóstico.','cookie homologação'),
            array('consentimento','','Consentimento','Categorias, apresentação e escolhas do visitante.','privacidade cookies banner'),
            array('privacidade','','Retenção e proteção','Prazos dos contatos, cabeçalhos e proteção de dados.','segurança exclusão'),
            array('conteudo','','Conteúdo e IA','Índice, navegação, robots.txt e conteúdo para serviços automáticos.','markdown llms arquivo'),
            array('seo','','SEO e identidade','Informações institucionais e dados estruturados.','google organização schema')
        );
        foreach($cards as $c){echo '<article class="f3base-config-card" data-f3base-busca="'.esc_attr(implode(' ',$c)).'"><h3><a href="'.esc_url(self::url($c[0],$c[1])).'">'.esc_html($c[2]).'</a></h3><p>'.esc_html($c[3]).'</p></article>';}
        echo '</div><p>Precisa conferir a execução? Abra <a href="'.esc_url(add_query_arg('aba','operacao',admin_url('admin.php?page='.F3Base_Admin_Tela::SLUG))).'">Operação</a>. As informações técnicas descrevem provas de cache, estrutura e saúde.</p>';
    }
    public static function campanhas(string $name,array $rows): void {
        echo '<table class="widefat" data-f3base-repetidor="campanhas"><thead><tr><th>Plataforma</th><th>ID da conta</th><th>ID da campanha</th><th>Nome para a equipe</th><th>Ação</th></tr></thead><tbody>';
        foreach(array_merge($rows,array(array())) as $i=>$r){echo '<tr>';foreach(array('plataforma','conta','campanha','nome') as $k){$n='f3base['.$name.']['.$i.']['.$k.']';echo '<td>';if($k==='plataforma'){echo '<select aria-label="Plataforma" name="'.esc_attr($n).'">';foreach(array(''=>'Selecione','meta_ads'=>'Meta Ads','google_ads'=>'Google Ads','linkedin_ads'=>'LinkedIn Ads','openai_ads'=>'OpenAI Ads') as $v=>$label){echo '<option value="'.esc_attr($v).'" '.selected($r[$k]??'',$v,false).'>'.esc_html($label).'</option>';}echo '</select>';}else{echo '<input aria-label="'.esc_attr($k).'" name="'.esc_attr($n).'" value="'.esc_attr($r[$k]??'').'">';}echo '</td>';}echo '<td><button type="button" class="button" data-remover-linha>Remover</button></td></tr>';}
        echo '</tbody></table><button type="button" class="button" data-adicionar-linha="campanhas">Adicionar campanha</button>';
    }
    public static function grupos(string $n): array {
        if($n==='f3base_pipedrive'){return array(
            'Conexão e identificação'=>array('ativo','dominio','homologacao','identidade_telefone','pais_telefone','linkedin_modo','sem_nome','modelo_nome'),
            'Responsabilidade e apresentação'=>array('responsavel','rotulo','rotulo_pessoa','unidade','modelo_titulo','site_alternativa'),
            'Campos e respostas'=>array('mapa_campos','mapa_pessoa','mapa_respostas','mapa_servicos','mapa_parceiros','mapa_canais','mapa_pontos'),
            'Atividades'=>array('atividade','atividade_tipo'),
            'Limites operacionais'=>array('orcamento_verificacao_diario','orcamento_local_diario','retencao_entregas_dias'));
        }
        return array('Conexão e autorização'=>array('ativo','proprietario_confirmado','conta_id','versao_api','modo'),'Formulários e campanhas'=>array('paginas','formularios_modo','formularios','campanhas','mapeamento'));
    }
    public static function grupo_ajuda(string $g): string {
        return array('Conexão e identificação'=>'Comece pela conta e pela credencial. Ativar agenda o trabalho; não comprova autorização remota.','Conexão e autorização'=>'Confirme os ativos deste site. A credencial é cifrada e nunca reapresentada.','Responsabilidade e apresentação'=>'Defina quem atende e como o contato aparece no CRM. As alternativas precisam pertencer à conta conectada.','Campos e respostas'=>'Escolha campos do catálogo da conta. Mapeamentos explícitos evitam perder respostas; mudanças no formulário exigem revisar o mapa.','Atividades'=>'Uma atividade cria uma tarefa de acompanhamento para o responsável; desative se a equipe já usa outra automação.','Limites operacionais'=>'Controle consumo e retenção. Limites menores podem aumentar o tempo da fila; não apagam contatos do CRM.','Formulários e campanhas'=>'Selecione apenas os formulários administrados por este site. Lista vazia em Selecionados significa nenhum formulário, não todos.')[$g]??'';
    }
}
