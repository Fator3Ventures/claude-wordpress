<?php
/** Adaptadores de qualidade: recebimento autenticado, leitura do CRM e outbox Meta. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Qualidade_Remota {
    private static float $prazo=0;
    private static function conta(): string {$s=get_option('f3base_pipedrive_estado',array());return ($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??'');}
    private static function trabalho(string $id): ?array {
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE record_id=%s AND conta=%s AND estado NOT IN ('cancelado','cancelando') ORDER BY atualizado_em DESC LIMIT 1",F3Base_Pipedrive_Fila::tabela(),$id,self::conta()),ARRAY_A);if($r){$r['journal']=json_decode($r['journal'],true)?:array();}return $r;
    }
    private static function proprio(string $entity,string $id): ?array {
        global $wpdb;if(!in_array($entity,array('lead','deal'),true)||!preg_match('/^[a-z0-9-]{1,40}$/D',$id)){return null;}
        // JSON_EXTRACT is used only over this site's account. No matching by name/e-mail.
        $path=$entity==='lead'?'$.oportunidade.id':'$.qualidade_negocio';
        $r=$wpdb->get_row($wpdb->prepare("SELECT record_id,journal,chave FROM %i WHERE conta=%s AND estado NOT IN ('cancelado','cancelando') AND JSON_UNQUOTE(JSON_EXTRACT(journal,%s))=%s LIMIT 1",F3Base_Pipedrive_Fila::tabela(),self::conta(),$path,$id),ARRAY_A);
        return $r?:null;
    }
    public static function autenticar(WP_REST_Request $r) {
        if(!self::config()['ativo']){return new WP_Error('integracao_inativa','Integração indisponível.',array('status'=>403));}
        $secret=F3Base_Segredos::abrir('f3base_pipedrive_webhook_segredo');$header=(string)$r->get_header('authorization');
        $given=str_starts_with($header,'Basic ')?base64_decode(substr($header,6),true):false;
        if(!$secret||!is_string($given)||!hash_equals('f3base:'.$secret,$given)){return new WP_Error('credencial_invalida','Credencial inválida.',array('status'=>401));}
        return true;
    }
    public static function receber(WP_REST_Request $r): WP_REST_Response {
        $out=F3Base_Recuperacao::executar(static fn()=>self::receber_interno($r));return $out instanceof WP_REST_Response?$out:new WP_REST_Response(array('ok'=>false,'codigo'=>'core_em_recuperacao'),503);
    }
    private static function receber_interno(WP_REST_Request $r): WP_REST_Response {
        if(strlen($r->get_body())>131072){return new WP_REST_Response(array('ok'=>false,'codigo'=>'corpo_excede_limite'),413);}
        $v=json_decode($r->get_body(),true,32,JSON_BIGINT_AS_STRING);$meta=$v['meta']??array();$data=$v['data']??array();$account=(string)(get_option('f3base_pipedrive_estado',array())['conta_id']??'');
        if(!is_array($v)||!is_array($meta)||!is_array($data)||$account===''||(string)($meta['company_id']??'')!==$account){return new WP_REST_Response(array('ok'=>false,'codigo'=>'conta_ou_formato_invalido'),400);}
        $entity=(string)($meta['entity']??'');$id=(string)($meta['entity_id']??$data['id']??'');$job=self::proprio($entity,$id);
        if(!$job){return new WP_REST_Response(array('ok'=>true,'codigo'=>'fora_do_escopo'),200);}
        if(!F3Base_Leads_Repositorio::quota(hash('sha256','qualidade-webhook|'.$account.'|'.gmdate('YmdHi')),120,time()+120)){return new WP_REST_Response(array('ok'=>false,'codigo'=>'limite_local'),429);}
        $when=$meta['timestamp']??null;$at=is_numeric($when)?(int)$when:(is_string($when)?strtotime($when):false);if(!$at||$at>time()+60){return new WP_REST_Response(array('ok'=>false,'codigo'=>'horario_invalido'),400);}
        $safe=array('entity'=>$entity,'entity_id'=>$id,'at'=>$at,'action'=>sanitize_key($meta['action']??''),'data'=>array_intersect_key($data,array_flip(array('id','pipeline_id','stage_id','status','is_archived','update_time','lost_reason'))));
        $key=hash('sha256',$account.'|'.($meta['id']??wp_json_encode($safe)));global $wpdb;
        $exists=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE chave=%s',self::tabela('recibos'),$key));
        if(!$exists&&$wpdb->insert(self::tabela('recibos'),array('chave'=>$key,'record_id'=>$job['record_id'],'conta'=>$account,'recebido_em'=>time(),'payload'=>F3Base_Capi_Fila::cifrar_payload($safe)))===false){return new WP_REST_Response(array('ok'=>false,'codigo'=>'recibo_nao_persistido'),503);}
        F3Base_Fila::agendar(self::HOOK,time()+1);return new WP_REST_Response(array('ok'=>true,'codigo'=>$exists?'recibo_repetido':'recibo_persistido'),200);
    }
    public static function registrar_webhook(): array {
        if(!F3Base_Integracoes::pipedrive_verificado()){return array('ok'=>false,'codigo'=>'conta_crm_nao_verificada');}
        if(!current_user_can('manage_options')||!is_ssl()||wp_parse_url(rest_url(),PHP_URL_SCHEME)!=='https'){return array('ok'=>false,'codigo'=>'administrador_e_https_necessarios');}
        $secret=F3Base_Segredos::abrir('f3base_pipedrive_webhook_segredo');if($secret===''){$secret=bin2hex(random_bytes(32));$r=F3Base_Options::gravar('f3base_pipedrive_webhook_segredo',$secret,F3Base_Options::ORIGEM_MANUAL,F3Base_Options::revisao('f3base_pipedrive_webhook_segredo'));if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'credencial_nao_persistida');}}
        F3Base_Pipedrive_Api::iniciar_lote();$list=F3Base_Pipedrive_Api::pedir('GET','v1/webhooks');if(empty($list['ok'])){return $list;}$url=rest_url(F3BASE_REST_NAMESPACE.'/pipedrive/qualidade');$ids=array();
        foreach(array('lead','deal') as $entity){$found=false;foreach($list['data'] as $hook){if(($hook['subscription_url']??'')===$url&&($hook['event_object']??'')===$entity&&($hook['version']??'')==='2.0'){$found=true;$ids[]=$hook['id'];break;}}if($found){continue;}$r=F3Base_Pipedrive_Api::pedir('POST','v1/webhooks',array('subscription_url'=>$url,'name'=>'F3Base '.wp_parse_url(home_url(),PHP_URL_HOST).' '.$entity,'event_action'=>'*','event_object'=>$entity,'version'=>'2.0','http_auth_user'=>'f3base','http_auth_password'=>$secret));if(empty($r['ok'])){return array('ok'=>false,'codigo'=>$r['codigo']??'webhook_sem_confirmacao','parcial'=>!empty($ids));}$ids[]=$r['data']['id'];}
        $s=F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($v)=>array_merge($v,array('webhooks'=>array('ids'=>$ids,'conta'=>self::conta(),'em'=>time()))));return array('ok'=>!empty($s['persisted']),'codigo'=>'webhooks_confirmados','ids'=>$ids);
    }
    private static function observar_crm(array $lead,string $entity,array $data,int $at,string $key,array $extra=array()): array {
        $state=$entity==='lead'?(!empty($data['is_archived'])?'lead_arquivado':'lead_criado'):(($data['status']??'')==='won'?'ganho':(($data['status']??'')==='lost'?'perdido':(!empty($data['stage_id'])?'stage:'.$data['stage_id']:'')));
        if($state===''){return array('ok'=>false,'codigo'=>'estado_crm_incompleto');}$account=(string)(get_option('f3base_pipedrive_estado',array())['conta_id']??'');$map=self::resolver($lead,$account,(string)($data['pipeline_id']??''),$state);
        if(empty($map['ok'])){return $map;}return self::registrar($lead,$map['regra']['etapa'],'pipedrive',$at,$key,$extra+array('conta'=>$account,'entidade'=>$entity,'id'=>(string)($data['id']??''),'estado'=>$state,'regra'=>$map['regra'],'motivo_perda'=>mb_substr(sanitize_textarea_field($data['lost_reason']??''),0,1000)));
    }
    private static function recibos(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' ORDER BY recebido_em LIMIT 30",self::tabela('recibos')),ARRAY_A);$n=0;
        foreach($rows as $row){if(microtime(true)>self::$prazo-2){break;}$data=F3Base_Capi_Fila::abrir_payload($row['payload']);$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||!$data||!self::trabalho($row['record_id'])){$r=array('ok'=>false,'codigo'=>'vinculo_ausente');}elseif($data['action']==='delete'){$r=array('ok'=>false,'codigo'=>'exclusao_nao_comprova_arquivamento');}else{$r=self::observar_crm($lead,$data['entity'],$data['data'],(int)$data['at'],$row['chave'],array('cobertura'=>'evento_webhook'));}
            $done=!empty($r['ok'])||in_array($r['codigo']??'',array('vinculo_ausente','etapa_nao_mapeada','mapa_ambiguo','estado_crm_incompleto','exclusao_nao_comprova_arquivamento'),true);
            if($done){$wpdb->update(self::tabela('recibos'),array('estado'=>!empty($r['ok'])?'processado':'revisao','codigo'=>$r['codigo']??'','payload'=>''),array('chave'=>$row['chave']));}$n++;
        }return array('processados'=>$n);
    }
    private static function consultar_crm(string $record=''): array {
        global $wpdb;if(!F3Base_Integracoes::pipedrive_verificado()||empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])){return array('ok'=>true,'codigo'=>'crm_desligado_ou_nao_verificado');}
        $state=get_option('f3base_qualidade_estado',array());$cursor=$record===''?(string)($state['cursor']??''):'';
        $extra=$record!==''?$wpdb->prepare(' AND record_id=%s',$record):$wpdb->prepare(' AND chave>%s',$cursor);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT chave,record_id,journal FROM %i WHERE conta=%s AND estado NOT IN ('cancelado','cancelando') {$extra} ORDER BY chave LIMIT 10",F3Base_Pipedrive_Fila::tabela(),self::conta()),ARRAY_A);$count=0;$errors=array();
        foreach($rows as $row){if(microtime(true)>self::$prazo-6){break;}$j=json_decode($row['journal'],true)?:array();$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||empty($j['oportunidade'])){$cursor=$row['chave'];$count++;continue;}
            $entity=!empty($j['qualidade_negocio'])?'deal':($j['oportunidade']['tipo']==='lead'?'lead':'deal');$id=(string)($j['qualidade_negocio']??$j['oportunidade']['id']);
            $r=F3Base_Pipedrive_Api::pedir('GET',($entity==='lead'?'v1/leads/':'v2/deals/').$id);
            if($entity==='lead'&&!empty($j['nota'])&&(empty($r['ok'])||!empty($r['data']['is_deleted']))&&microtime(true)<self::$prazo-6){
                $note=F3Base_Pipedrive_Api::pedir('GET','v1/notes/'.(int)$j['nota']);$n=$note['data']??array();
                if(!empty($note['ok'])&&!empty($n['deal_id'])&&str_contains(wp_strip_all_tags($n['content']??''),'f3base:'.$row['chave'].':nota')){
                    $entity='deal';$id=(string)$n['deal_id'];$r=F3Base_Pipedrive_Api::pedir('GET','v2/deals/'.$id);
                    if(!empty($r['ok'])&&F3Base_Pipedrive_Fila::travar_linha($row['chave'])){try{$fresh=self::trabalho($row['record_id']);if($fresh){$journal=$fresh['journal'];$journal['qualidade_negocio']=$id;$journal['qualidade_vinculo']=array('nota'=>(int)$j['nota'],'em'=>time());$wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('journal'=>wp_json_encode($journal)),array('chave'=>$row['chave']));}}finally{F3Base_Pipedrive_Fila::liberar_linha($row['chave']);}}
                }
            }
            if(!empty($r['ok'])){$data=$r['data'];$at=strtotime($data['update_time']??$data['add_time']??'')?:0;if($at&&$at<=time()){$observed=self::observar_crm($lead,$entity,$data,$at,hash('sha256',self::conta().'|'.$row['record_id'].'|'.$entity.'|'.$id.'|'.$at.'|'.wp_json_encode(array_intersect_key($data,array_flip(array('stage_id','pipeline_id','status','is_archived'))))),array('cobertura'=>'estado_atual_intermediarias_nao_garantidas'));if(empty($observed['ok'])){$errors[]=$observed['codigo'];}}else{$errors[]='horario_crm_ausente';}}
            else{$errors[]=$r['codigo']??'consulta_falhou';if(!empty($r['pausa'])){break;}}$cursor=$row['chave'];$count++;
        }
        if($record===''){F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($s)=>array_merge($s,array('cursor'=>count($rows)<10&&$count===count($rows)?'':$cursor)));}
        return array('ok'=>!$errors,'processados'=>$count,'parcial'=>$count<count($rows)||count($rows)===10,'codigos'=>array_values(array_unique($errors)));
    }
    private static function graph_qualidade(string $method,string $dataset,string $version,array $body=array(),int $timeout=8): array {
        if(!preg_match('/^[0-9]{1,40}$/D',$dataset)||!preg_match('/^v[0-9]{2}\.0$/D',$version)){return array('ok'=>false,'codigo'=>'dataset_ou_versao_invalido');}
        $token=F3Base_Segredos::abrir(self::credencial());if($token===''){return array('ok'=>false,'codigo'=>'credencial_ausente');}
        $url='https://graph.facebook.com/'.$version.'/'.$dataset.($method==='POST'?'/events':'?fields=id,name');$args=array('method'=>$method,'timeout'=>max(1,min(8,$timeout)),'redirection'=>0,'limit_response_size'=>131072,'headers'=>array('Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'));if($method==='POST'){$args['body']=wp_json_encode($body);}
        $r=wp_remote_request($url,$args);unset($token,$args);if(is_wp_error($r)){return array('ok'=>false,'codigo'=>'transporte_sem_confirmacao','incerto'=>$method==='POST','temporario'=>true);}
        $http=wp_remote_retrieve_response_code($r);$json=json_decode(wp_remote_retrieve_body($r),true,32,JSON_BIGINT_AS_STRING);$ok=$http>=200&&$http<300&&is_array($json)&&empty($json['error'])&&($method==='POST'?($json['events_received']??0)===1:(string)($json['id']??'')===$dataset);
        return array('ok'=>$ok,'http'=>$http,'codigo'=>$ok?($method==='POST'?'meta_aceitou':'leitura_confirmada'):'meta_recusou','incerto'=>$method==='POST'&&($http>=500||($http>=200&&$http<300&&!$ok)),'temporario'=>$http===429||$http>=500,'retry_after'=>max(60,min(86400,(int)wp_remote_retrieve_header($r,'retry-after'))),'code'=>(int)($json['error']['code']??0),'subcode'=>(int)($json['error']['error_subcode']??0),'type'=>sanitize_key($json['error']['type']??''));
    }
    public static function verificar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$cfg=self::config();if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'dataset'=>$cfg['dataset'],'efeito'=>'consulta_de_leitura_sem_conversao');}
        $rev=F3Base_Options::revisao(self::OPCAO);$r=self::graph_qualidade('GET',$cfg['dataset'],$cfg['versao_api']);$r['escrita']='nao_testada';$r['em']=time();$r['revisao']=$rev;$r['credencial_revisao']=F3Base_Options::revisao(self::credencial());
        F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($s)=>array_merge($s,array('meta_verificacao'=>$r)));return $r;
    }
    private static function enviar(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('pendente','incerto','enviando') AND proxima<=%d ORDER BY proxima LIMIT 10",self::tabela('fila'),time()),ARRAY_A);$count=0;
        foreach($rows as $row){if(microtime(true)>self::$prazo-4){break;}$lock=F3Base_Trava::adquirir('qualidade-envio-'.$row['record_id'],30);if(!$lock){continue;}try{
            $fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela('fila'),$row['chave']),ARRAY_A);if(!$fresh||!in_array($fresh['estado'],array('pendente','incerto','enviando'),true)||(int)$fresh['proxima']>time()){continue;}$row=$fresh;$lead=F3Base_Leads_Repositorio::obter($row['record_id']);$stage=self::etapa($row['etapa']);$payload=F3Base_Capi_Fila::abrir_payload($row['payload']);
            $why='';if(!$lead||!$stage||!$payload){$why='contato_etapa_ou_payload_ausente';}elseif((int)$row['expira']<time()){$why='evento_expirado';}elseif($row['config_revisao']!==F3Base_Options::revisao(self::OPCAO)||$row['credencial_revisao']!==F3Base_Options::revisao(self::credencial())){$why='configuracao_alterada_revisar';}elseif(empty(($elig=self::elegibilidade($lead,$stage,(int)$payload['evento']['event_time']))['ok'])){$why=$elig['codigo'];}
            if($why){$wpdb->update(self::tabela('fila'),array('estado'=>'suspenso','codigo'=>$why,'atualizado_em'=>time()),array('chave'=>$row['chave']));continue;}
            if(in_array($row['estado'],array('enviando','incerto'),true)&&time()-(int)$payload['evento']['event_time']>172500){$wpdb->update(self::tabela('fila'),array('estado'=>'revisao','codigo'=>'incerto_fora_janela_deduplicacao'),array('chave'=>$row['chave']));continue;}
            $claimed=$wpdb->update(self::tabela('fila'),array('estado'=>'enviando','tentativas'=>(int)$row['tentativas']+1,'proxima'=>time()+60,'atualizado_em'=>time()),array('chave'=>$row['chave'],'estado'=>$row['estado']));if($claimed!==1){continue;}
            $r=self::graph_qualidade('POST',$row['dataset'],$payload['versao_api'],array('data'=>array($payload['evento'])),(int)(self::$prazo-microtime(true)-1));
            $state=!empty($r['ok'])?'entregue':(!empty($r['incerto'])?'incerto':(!empty($r['temporario'])?'pendente':'falhou'));if((int)$row['tentativas']>=9&&$state!=='entregue'){$state='revisao';}
            $wpdb->update(self::tabela('fila'),array('estado'=>$state,'codigo'=>$r['codigo'].'_'.(int)($r['code']??0).'_'.(int)($r['subcode']??0),'http'=>$r['http']??0,'proxima'=>time()+max((int)($r['retry_after']??60),min(21600,60*2**min(8,(int)$row['tentativas']))),'atualizado_em'=>time()),array('chave'=>$row['chave']));$count++;
        }finally{F3Base_Trava::liberar($lock);}}
        return array('tentativas'=>$count);
    }
    public static function atualizar(array $e=array()): array {
        $internal=!empty($e['interno']);if(!$internal&&!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}if(!$internal&&($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'ordem'=>array('captacao_meta','recibos_crm','consulta_crm','envio_meta'),'limite_segundos'=>20);}
        if(!self::config()['ativo']){return array('ok'=>true,'codigo'=>'qualidade_desligada');}$lock=F3Base_Trava::adquirir('qualidade-lote',30);if(!$lock){return array('ok'=>true,'codigo'=>'execucao_ocupada');}self::$prazo=microtime(true)+min(20,F3Base_Execucoes::restante_ms(1500)/1000);
        try{$out=array();if(!$internal){$record=!empty($e['record_id'])?F3Base_Leads_Repositorio::obter($e['record_id']):null;$native=$record['dados']['origem_nativa']??array();if(empty($e['record_id'])){$out['captacao_meta']=F3Base_Anuncios::consultar(min(self::$prazo-10,microtime(true)+8));}elseif(($native['origem']??'')==='meta'&&(string)($native['conta_id']??'')===(string)(F3Base_Options::ler('f3base_anuncios_meta')['conta_id']??'')){$out['captacao_meta']=F3Base_Anuncios::consultar(min(self::$prazo-10,microtime(true)+8),(string)$native['formulario_id']);}else{$out['captacao_meta']=array('ok'=>true,'codigo'=>'importacao_nao_aplicavel_ao_contato');}}F3Base_Pipedrive_Api::iniciar_lote();F3Base_Pipedrive_Api::limitar_prazo(self::$prazo-3);$out['recibos']=self::recibos();$out['crm']=self::consultar_crm((string)($e['record_id']??''));$out['meta']=self::enviar();$out['ok']=!empty($out['crm']['ok'])&&(!isset($out['captacao_meta'])||!empty($out['captacao_meta']['ok']));$out['parcial']=!empty($out['captacao_meta']['parcial'])||!empty($out['crm']['parcial'])||microtime(true)>self::$prazo-4;$out['codigo']=$out['parcial']?'lote_parcial':($out['ok']?'lote_concluido':'lote_com_pendencias');$out['em']=time();F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($s)=>array_merge($s,array('ultima_passagem'=>$out)));return $out;}
        finally{F3Base_Pipedrive_Api::limitar_prazo(0);F3Base_Meta_Acesso::limitar_prazo(0);F3Base_Fila::agendar(self::HOOK,time()+300);F3Base_Trava::liberar($lock);}
    }
    public static function catalogos_remotos(): array {return F3Base_Qualidade_Catalogo::carregar(array('simular'=>false));}
}
