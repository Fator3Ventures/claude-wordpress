<?php
/** Operações explícitas, com prévia e revisão, sobre etapas e vínculos locais. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Qualidade_Operacoes {
    public static function indicar_lote(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$items=$e['itens']??array();if(!is_array($items)||count($items)>50||!$items){return array('ok'=>false,'codigo'=>'selecione_ate_50_contatos');}
        $out=array();foreach($items as $item){$out[(string)($item['record_id']??'')]=self::indicar(array('record_id'=>(string)($item['record_id']??''),'revisao'=>(string)($item['revisao']??''),'etapa'=>(string)($e['etapa']??''),'ocorreu_em'=>(int)($e['ocorreu_em']??time()),'motivo'=>(string)($e['motivo']??''),'simular'=>($e['simular']??true)!==false));}
        $ok=!array_filter($out,static fn($r)=>empty($r['ok']));return array('ok'=>$ok,'codigo'=>$ok?'etapas_processadas':'lote_com_pendencias','resultados'=>$out);
    }
    public static function reenviar_meta(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela('fila'),(string)($e['chave']??'')),ARRAY_A);if(!$row){return array('ok'=>false,'codigo'=>'envio_ausente');}
        $rev=hash('sha256',wp_json_encode(array($row['estado'],$row['tentativas'],$row['config_revisao'],$row['atualizado_em'])));$lead=F3Base_Leads_Repositorio::obter($row['record_id']);$payload=F3Base_Capi_Fila::abrir_payload($row['payload']);$def=self::etapa($row['etapa']);$cfg=self::config();
        if(!in_array($row['estado'],array('suspenso','falhou'),true)||!$payload||!$lead||!$def||$row['dataset']!==$cfg['dataset']||($payload['evento']['event_name']??'')!==($def['evento_meta']??'')){return array('ok'=>false,'codigo'=>'envio_exige_reconciliacao_ou_destino_divergente','revisao'=>$rev);}
        $elig=self::elegibilidade($lead,$def,(int)$payload['evento']['event_time']);if(empty($elig['ok'])){return $elig+array('revisao'=>$rev);}
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>$rev,'efeito'=>'Mesma etapa, dataset, horário, event_id e payload; nenhuma mudança de destino.');}
        if(($e['revisao']??'')!==$rev){return array('ok'=>false,'codigo'=>'conflito');}$lock=F3Base_Trava::adquirir('qualidade-envio-'.$row['record_id'],30);if(!$lock){return array('ok'=>false,'codigo'=>'contato_ocupado');}
        try{$n=$wpdb->update(self::tabela('fila'),array('estado'=>'pendente','codigo'=>'reativado_explicitamente','proxima'=>time(),'config_revisao'=>F3Base_Options::revisao(self::OPCAO),'credencial_revisao'=>F3Base_Options::revisao(self::credencial()),'atualizado_em'=>time()),array('chave'=>$row['chave'],'estado'=>$row['estado'],'atualizado_em'=>$row['atualizado_em']));if($n===1){F3Base_Fila::agendar(self::HOOK,time()+1);}return array('ok'=>$n===1,'persisted'=>$n===1,'codigo'=>$n===1?'reativado':'conflito');}finally{F3Base_Trava::liberar($lock);}
    }
    public static function vincular_negocio(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}if(!F3Base_Integracoes::pipedrive_verificado()){return array('ok'=>false,'codigo'=>'conta_crm_nao_verificada');}$id=(string)($e['record_id']??'');$remote=(string)($e['negocio_id']??'');$job=self::trabalho($id);if(!$job||!preg_match('/^[1-9][0-9]{0,19}$/D',$remote)){return array('ok'=>false,'codigo'=>'vinculo_invalido');}
        F3Base_Pipedrive_Api::iniciar_lote();$r=F3Base_Pipedrive_Api::pedir('GET','v2/deals/'.$remote);if(empty($r['ok'])||(string)($r['data']['id']??'')!==$remote){return array('ok'=>false,'codigo'=>'negocio_nao_confirmado');}$rev=hash('sha256',wp_json_encode($job['journal']));
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>$rev,'conta'=>self::conta(),'negocio_id'=>$remote,'confirmacao_necessaria'=>'O operador afirma que este negócio corresponde ao contato; a leitura só comprova existência na conta.');}
        if(($e['revisao']??'')!==$rev||empty($e['confirmar'])){return array('ok'=>false,'codigo'=>'conflito_ou_confirmacao_ausente');}if(!F3Base_Pipedrive_Fila::travar_linha($job['chave'])){return array('ok'=>false,'codigo'=>'vinculo_ocupado');}
        try{global $wpdb;$fresh=self::trabalho($id);if(!$fresh||hash('sha256',wp_json_encode($fresh['journal']))!==$rev){return array('ok'=>false,'codigo'=>'conflito');}$j=$fresh['journal'];$j['qualidade_negocio']=$remote;$j['qualidade_vinculo']=array('origem'=>'indicacao_explicita','autor'=>get_current_user_id(),'em'=>time(),'anterior'=>$fresh['journal']['qualidade_negocio']??null,'motivo'=>sanitize_textarea_field($e['motivo']??''));$n=$wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('journal'=>wp_json_encode($j)),array('chave'=>$job['chave']));return array('ok'=>$n!==false,'persisted'=>$n!==false,'codigo'=>'vinculo_registrado');}finally{F3Base_Pipedrive_Fila::liberar_linha($job['chave']);}
    }
    public static function lote_ui(array $leads): void {
        if(!current_user_can('manage_options')||!self::config()['etapas']||!$leads){return;}echo '<details class="f3base-config-grupo"><summary>Indicar qualidade em vários contatos</summary>';self::form('lote');echo '<p><label>Contatos desta página <select name="ids[]" multiple size="5" required>';
        foreach($leads as $l){echo '<option value="'.esc_attr($l['record_id']).'">'.esc_html(($l['nome']?:$l['email']?:substr($l['record_id'],0,8)).' · '.$l['formulario']).'</option>';}echo '</select></label></p>';foreach($leads as $l){echo '<input type="hidden" name="revisoes['.esc_attr($l['record_id']).']" value="'.esc_attr(self::atual($l['record_id'])['revisao']).'">';}
        echo '<p><label>Etapa <select name="etapa">';foreach(self::config()['etapas'] as $s){echo '<option value="'.esc_attr($s['id']).'">'.esc_html($s['nome']).'</option>';}echo '</select></label></p><p><label>Motivo <input name="motivo" maxlength="500" required></label></p><p>O horário será o desta indicação. Cada contato conserva seu histórico e sua própria revisão; pendências de um contato não são aplicadas a outros.</p><button class="button">Registrar nos contatos selecionados</button></form></details>';
    }
}
