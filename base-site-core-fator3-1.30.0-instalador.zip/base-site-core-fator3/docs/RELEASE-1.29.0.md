# Fator3 Site Core 1.29.0

Contrato 6.5.0. Base de implantação: WordPress novo ou Core 1.28.0. Não há trava de versão nem garantia de retorno a uma versão anterior. Matriz dos companheiros: MCP 0.19.0 e MCP Google 0.8.2. Nenhum arquivo desses plugins ou de tema foi alterado.

## Configurar com menos dispersão

Site Core → Configurações abre uma visão por tarefa, com busca e quinze áreas. Contas, canais e mapas estão em Conexões e entregas; detalhes avançados começam recolhidos. Contatos fica para atendimento/formulários, Medição para análise. Links antigos de Integrações redirecionam. Salvar somente GTM não obriga a preencher outros campos. Mapas de campanhas e regras são tabelas editáveis, com escolhas fechadas onde há catálogo. A ajuda explica efeito, exemplo e limitações.

## Retorno comercial genérico

Etapas locais, estados/funis do Pipedrive, formulários e campanhas são relacionados por regras da instalação. Conta explícita, validação de catálogo e recusa de regras ambíguas impedem que um mapa seja aplicado a outro contexto. Nenhum mapa ou identificador de Korvena acompanha os padrões. A função vem desligada, com listas vazias; não habilita publicidade de leads nativos automaticamente.

Qualidade pode vir do webhook Pipedrive, consulta periódica ou indicação manual auditada, com controle de revisão e precedência. Há atualização imediata independente do cron e vínculo explícito a negócio quando a continuidade não foi comprovada. O histórico fica no Core. A saída Meta usa fila própria, identidade estável por etapa, payload cifrado, consentimento reconferido, janela do evento e tratamento distinto para aceite, recusa e resultado incerto. A leitura de dataset não prova permissão de envio. Etapas comerciais não viram aquisições extras no GA4.

## Rastreabilidade dos pedidos

“Implementado” nesta tabela significa código incluído; a prova local e os aceites externos têm escopos diferentes, descritos em VALIDACAO.md.

| Pedido | Implementação | Evidência local principal |
|---|---|---|
| 171 | Tempo ativo zero distinto de ausência; intervalo observado; origem explicável; primeiro/último toque; deduplicação de linhas; histórico e campanhas preservados | comunicacao, historico, browser-banco |
| 173 | Destino e texto do CTA usados no WhatsApp; um formulário sem clone; diálogo opcional; rótulos e Pular configuráveis; auditoria de etapas | complementos, browser-http, browser-advanced |
| 174 | Principal Slack e detalhes com estados próprios; suspensão dependente; contingência; mesma apresentação canônica de e-mail/Pipedrive | slack-app, avisos, comunicacao |
| 175 | Verificação de acesso Meta registrada no bootstrap, com botão e catálogo autenticado | qualidade, novidades |
| 176 | Opção de envio sem nome; papéis por tipo do catálogo; mapas de respostas nativas e grupos compatíveis; reavaliação e marcação de teste | novidades, release |
| 177 | Padrão de 365 dias e perfil 3.4, sem reescrever o 3.3; consulta indexada e limites explícitos | release, historico-volume |
| 178 | Estado por canal no contato e nos relatórios; falha sem contingência | release, avisos |
| 179 | Uma consulta Clarity por passagem, orçamento compartilhado, cota e Retry-After; estado da credencial | operacao-1290 |
| 180 | Blocos dinâmicos de índice de artigo e compartilhamento, sem SDK | novidades |
| 181 | Marca de exclusão de otimização nos scripts Core, preservando defer | release, browser-http |
| 182 | Rearme de captação esgotada em nova revisão, separado de suspensão; diagnóstico de agendador/cobertura e alerta operacional | contratos-1290, operacao |
| 183 | Classificação pendente separada de negativa; finalização vinculada à mesma captura; diagnóstico de transições por página/classe | release, diagnostico-1290, browser-http |
| 184 | Limites de arquivo em linguagem do visitante, texto próprio/oculto; ausência de teto do plugin mantida | release, browser-banco |
| 185 | Mapa genérico; qualidade histórica/manual; webhook autenticado; fila Meta e relatório comercial por campanha | qualidade, release, contratos-1290, operacao-1290 |
| 186 | Impressão comercial separada da renderização; tolerância fixa de 15 min, sem prorrogação por novas edições; preço alterado invalida | operacao-1290 |
| 187 | Conversão por vínculo de contato/sessão/classe; promoção anônima e continuidade de WhatsApp; pessoa diferente separada | release, browser-http |
| 188 | Toque/roda/inércia; profundidade por gesto separada de salto | browser-advanced, browser-banco |
| 189(a,b) | Releitura do cron antes de considerar erro; pendência durável e retomada; falha real continua falha | operacao-1290, operacao |
| 189(c) | Encaminhamento ao MCP Google, sem alterar seu cron | IMPACTO-1.29.0.md |
| 190 | Mensagens finais e botões; resposta HTML/5xx legível; continuação após falha apenas do complemento | browser-advanced, complementos |
| 191 | Resultado relê o estado persistido; pendência/etapas e marca de origem explícitas; retomada em lotes; histórico de qualidade incluído na eliminação | contratos-1290, release |
| UX adicional | Visão por tarefas, busca, grupos recolhidos, redirecionamentos, salvar isolado e mapa visual | browser-advanced, telas |

## Implantação

1. Faça o backup normal do site, banco e pasta privada. Instale o ZIP por WordPress ou MCP autorizado. Documentação está dentro de `base-site-core-fator3/docs/`.
2. A instalação/atualização materializa as novas estruturas e conclui as tarefas em segundo plano. Confira Operação/saúde; abrir diagnóstico não equivale a executar cron. Valores explícitos, listas vazias e procedência são preservados.
3. O mapa comercial é configurado por site em Conexões e entregas → Qualidade e Meta. Verifique a conta Pipedrive antes de carregar funis/campos. Registre autorização dos formulários nativos e confirme dataset antes de ativar envio.
4. Homologue com os responsáveis pelas contas. “Entregue” na fila significa aceite da API; não comprova atribuição ao anúncio, processamento final ou resultado comercial na Meta.

Estruturas novas: `f3base_aquisicoes`, `f3base_qualidade_eventos`, `f3base_qualidade_atual`, `f3base_qualidade_fila`, `f3base_qualidade_recibos`, `f3base_contexto_diagnostico`. Inventário de backup/uninstall e dicionário são distribuídos com o plugin. A retenção do histórico comercial acompanha o contato; os payloads transitórios têm prazo próprio.

## Limites e próximos aceites

- Não houve alteração de site da frota, envio para conta real ou teste em korvena.net.br. APIs remotas foram substituídas por respostas controladas nos ensaios comerciais.
- O polling recupera o estado atual do CRM; não reconstrói etapas intermediárias que nunca foram observadas. Retenção maior não recupera dados apagados antes da atualização.
- Histórico tem até 500 sessões candidatas e 10 mil eventos de origem por montagem; cinco visitas detalhadas. Se exceder, a cobertura é declarada. Não há promessa de desempenho da hospedagem a partir do laboratório.
- Diagnóstico de páginas registra transições observadas, não confirma entrega ao GA4/Meta e não inventa falha a partir de silêncio do navegador. Uma página pode constar em mais de um estado.
- Aceites de sete dias da captação/Clarity/cron, leitura de catálogo e entrega nas contas reais continuam sendo homologação de implantação. Navegadores internos de Instagram e Safari iOS em aparelhos físicos não foram usados.
- A colocação dos blocos de artigo e retirada de componentes duplicados pertence ao tema/implantador. A disputa de agenda do MCP Google tem encaminhamento próprio.
