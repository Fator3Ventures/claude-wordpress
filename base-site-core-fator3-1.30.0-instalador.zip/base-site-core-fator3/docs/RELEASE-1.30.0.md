# Fator3 Site Core 1.30.0

Referência de implantação: WordPress novo ou Core 1.29.0, sem trava rígida por versão e sem compromisso de retorno. Contrato 6.6.0. Matriz: MCP Fator3 0.19.0 e MCP Google 0.8.2; nenhum companheiro/tema alterado.

| Demanda | Entrega |
|---|---|
| Slack da conversa | Leitura de aviso/thread, verificação, correção própria, limpeza de testes e registro durável de teste de conexão, pela integração atual. |
| 173 | Resolvedor de WhatsApp compartilhado pelas duas etapas, preservando URL/texto do CTA. Inventário de gatilhos data-f3base-abrir-formulario. |
| 174 | Causa e orientação dos avisos degradados, descoberta da credencial/abilities; clique simples sem formulário fictício. Regressões de título, reconciliação e partes órfãs. |
| 180 | Hierarquia/classes do índice e compartilhar conforme pedido; IDs somente na composição que usa o índice, inclusive padrões/partes, preservando IDs autorais. |
| 189 | Explicação do aviso WordPress, observação e reconciliação limitada da agenda própria, sem encobrir falhas. |
| 192 | Publicidade pré-autorizada por instalação, distinta de medição e de consentimento individual, com negativa prioritária e persistente. |
| 193 | Catálogo Pipedrive paginado e completo pela tela e MCP, com conta/revisão e preservação em falha. |

## Instalação e dados

Instale o ZIP normal pelo WordPress/MCP. A atualização cria a tabela de manutenção Slack e complementa a opção de publicidade, conservando escolhas, listas vazias e procedência. Não envia mensagens de teste, reativa integrações ou converte autorizações históricas em aceites individuais. Finalização e provas externas seguem o executor existente.

Leia SLACK-1.30.md, PUBLICIDADE-1.30.md, QUALIDADE-CATALOGO-1.30.md, CRON-DIAGNOSTICO-1.30.md e IMPACTO-1.30.0.md. Catálogo e schemas instalados são acessíveis por f3base/documentacao-ler.

## Limites de evidência

Testes de Slack/Pipedrive/Meta usam transportes simulados e validam contratos/estados, não entrega a uma conta real. Homologação do workspace e observação de cron na frota continuam externas. Os fontes dos temas fator3-tech-blocos 3.3.0 e korvena-blocos 2.4.0 não estavam disponíveis; o Site-Teste conectado tem somente F3 Base 1.6.16. O HTML foi alinhado à estrutura descrita no pedido e testado localmente, mas igualdade integral/aparência com os dois temas ainda requer comparação dos seus arquivos/CSS. Não se realizou teste em korvena.net.br nem alteração remota.
