# Instruções aos agentes — Core 1.30.0

Leia DOCUMENTACAO.md e o schema efetivo da ability antes de agir. Base de referência 1.29.0 ou nova; MCP 0.19.0 / Google 0.8.2. A documentação permanece instalada, inclusive os contratos em docs/dados/.

Use o modo de teste já existente ao visitar o site. Nunca peça tokens ao agente quando há campo privado no wp-admin. Para Slack, leia SLACK-1.30.md: opere somente avisos registrados, não conversas gerais. Enviar/corrigir/apagar requer uma solicitação do dono; consultar não prova leitura humana. Simulações mostram efeito; use revisão e chave idempotente. Não repetir resultado incerto às cegas.

Para catálogo CRM, use qualidade-catalogo-carregar e depois qualidade-ler. Configurar regras é etapa separada; não criar mapas de outro cliente por semelhança de nome. Política de publicidade não é consentimento individual; negativas têm precedência. Registre negativa explícita por contato-publicidade-negar; não altere medição para habilitar anúncios.

Cron: could_not_set não identifica sua causa sozinho. Consulte o estado confirmado em vez de suprimir mensagens de log. Não reparar ganchos de companheiros. Preserve o protocolo de recuperação/backup dos três plugins.

Guias AGENTES-1.29.0.md e HISTORICO-1.29.md continuam aplicáveis nos tópicos não substituídos. Não mudar tema/implantador por iniciativa deste pacote.
