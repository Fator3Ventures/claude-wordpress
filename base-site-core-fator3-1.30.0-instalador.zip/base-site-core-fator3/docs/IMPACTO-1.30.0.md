# Encaminhamento aos responsáveis por MCP, Google e temas

## MCP Fator3 0.19.0

Core 1.30.0 registra contrato 6.6.0 e novas abilities `avisos-slack-ler`, `avisos-slack-verificar`, `avisos-slack-corrigir`, `avisos-slack-testes-apagar`, `contato-publicidade-negar`, `qualidade-catalogo-carregar`, `qualidade-ler`. Descoberta dinâmica pelo MCP atual; não requer alteração do plugin MCP. Conferir permissões da concessão e atualizar esquemas em cache do agente. Exclusão Slack é destrutiva e limitada a IDs locais de teste; escrita respeita recuperação/revisão/idempotência. Não fornecer canal/ts arbitrário.

Backup conjunto deve incluir `f3base_slack_manutencao`, opções e sentinela operacional do Core conforme o protocolo existente. Não trocar a guarda ativa por uma cópia antiga. Nenhuma mensagem é reenviada automaticamente após restore.

## MCP Google 0.8.2

Sem mudança de código, credencial ou agenda. A publicidade do Core passa a ter política própria, independente da medição; isto não habilita GA4 por servidor. Consent Mode usa analytics_storage separado de ad_storage/ad_user_data/ad_personalization. GTM precisa manter a separação já declarada. O Core não trata falhas de cron de ganchos do Google.

## Implantador e temas

Item 173: após homologar as duas etapas com o CTA real, o responsável pelo tema pode retirar o workaround de reconstrução de URL em contato.js. O Core conserva número e mensagem do destino validado.

Item 180: os blocos Core usam details.artigo-indice.f3base-secao-indice e summary.f3base-clique-indice; compartilhar é p.artigo-compartilhar.f3base-secao-compartilhar. O indexador só atua no conteúdo principal de composição com índice. Testar antes/depois de post-content, padrões/parts, títulos autorais/repetidos, mouse e teclado. Não duplicar filtros antigos. A comparação com inc/artigos.php e CSS de fator3-tech-blocos 3.3.0 e korvena-blocos 2.4.0 permanece pendente por ausência desses fontes nesta entrega. A substituição de blocos/remoção de arquivos é responsabilidade do implantador, não executada pelo Core.

Não há ação de configuração nos demais plugins provocada pelo catálogo Pipedrive ou pela manutenção Slack. Se faltar leitura Slack, conceder channels:history/groups:history ao aplicativo atual; não criar uma segunda conexão.
