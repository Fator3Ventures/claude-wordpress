# Instrução para agentes — Core 1.29.0

Leia DOCUMENTACAO.md, contratos gerados e o inventário instalado antes de agir. Base de manutenção: 1.28.0 ou WordPress novo; não há gate ou garantia de retorno a release anterior. Companheiros da matriz: MCP 0.19.0 e MCP Google 0.8.2. Não atribua ao Core a implantação do tema.

1. Use leitura local/ability para configuração, saúde, filas e relatórios. Ler não equivale a verificar conta ou executar cron. Horários persistidos são UTC; o admin apresenta o fuso do site quando indicado.
2. Ative `/f3base-teste/` no navegador/origem utilizado e confira a marca. Cookie dura 365 dias; outro navegador/cliente exige sua própria marca. No cliente HTTP, declare `X-F3Base-Teste: 1`. Teste não concede consentimento nem permissão.
3. Segredos entram pela tela do dono. Nunca solicitar token em mensagem ou imprimir valor cifrado/decifrado. Para retorno CRM, confira dataset, conta, autorização e catálogo de campos; mapa de outro site não é padrão.
4. Escritas de configuração e qualidade têm prévia/revisão. Releia em conflito; não substitua revisão para forçar gravação. Não reenvie resultado incerto como se nunca tivesse sido entregue.
5. Consulte estado por canal e use `visao: comercial` para etapas/campanhas. Contatos distintos e ocorrências são medidas diferentes. Campanhas históricas e etapas não são somáveis entre si. Não afirme que Meta atribuiu uma conversão só com HTTP 200.
6. Pausa/drenagem de cada plugin é independente. Backup conjunto inclui tabelas comerciais, qualidade, anexos privados e estado próprio dos companheiros. Restore suspende pendências; reconcilie antes de retomar. Não sobrepor sentinela ativa com snapshot antigo.
7. Use o inventário fechado para propriedade/limpeza. `f3base_*` não é autorização para apagar opções por prefixo. Não limpar `f3_google_cron`, sentinela Google ou dados do MCP como cache Core.

A documentação está no ZIP instalado e acessível por `f3base/documentacao-ler`. A suíte de laboratório fica no fonte de entrega; não é instalada nos sites. Os dados da suíte são sintéticos, e scripts de recriação de banco nunca devem ser executados em produção.

## Classificação e eliminação

Saúde: `classificacao_capturas.paginas_classificacao` traz dia UTC/classe/estado/total, sem URL, IP, UA ou visitante. POST `/contexto-diagnostico` aceita apenas uma identidade aleatória da carga (deduplicada por 15 min, sem perfil persistente) e estados fechados. Origem precisa ser a do site. Um lote curto assíncrono após classificação e outro somente se houver transição/saída; não bloqueia renderização nem carrega SDK. Retenção agregada: 30 dias. Estado liberada significa elegibilidade local; não confirma recebimento em plataforma. Falha de transporte do próprio diagnóstico não cria confirmação fictícia.

`leads-eliminar-registro` relê a persistência. Observe `dados_eliminados`, `pendente`, `etapas_pendentes`, `marca_de_origem_mantida`, `condicao_remocao_marca` e `origem_tipo`. Uma marca nativa sem timestamp não expira automaticamente. Retomada automática percorre até 20 registros pendentes por passagem; reserva ativa continua pendente. A simulação de registro já eliminado é idempotente. Cópias externas têm status separado: não anunciar que Slack, Meta ou CRM foram apagados a partir de eliminação local.
