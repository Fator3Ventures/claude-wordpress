# Instruções do Core

Leia [AGENTES-1.30.0.md](AGENTES-1.30.0.md) e [DOCUMENTACAO.md](DOCUMENTACAO.md). Os schemas gerados documentam a instalação atual. Guias históricos não substituem as políticas da versão 1.30.
