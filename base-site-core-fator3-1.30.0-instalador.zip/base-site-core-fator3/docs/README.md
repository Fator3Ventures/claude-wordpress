# Documentação do pacote

O índice vigente é [DOCUMENTACAO.md](DOCUMENTACAO.md), Core 1.30.0. Guias antigos são históricos; instruções 1.30 prevalecem nos tópicos alterados.
