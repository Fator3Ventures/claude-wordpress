# Encaminhamento aos responsáveis por MCP, MCP Google e tema

## MCP 0.19.0

Nenhum código alterado. A atualização por `plugins/upload-base64` foi exercitada com concessão administrativa sintética; captura e tags continuaram disponíveis antes da finalização assíncrona. Há novas abilities Core de qualidade, leitura de campos nativos e classificação de teste; descobrir pelo catálogo em vez de manter lista fixa. Segredos permanecem na UI do dono. Inclua as quatro tabelas `f3base_qualidade_*` no backup comercial. A guarda Core suspende a nova fila no restore; isso não substitui a guarda MCP.

## MCP Google 0.8.2

Nenhum código alterado. SDK/consumidor GSC real do plugin foi testado com transporte Google simulado, sem impersonar usuário no cron. A reconciliação de agenda da 1.29 trata somente hooks `f3base_`; não corrige disputa em `f3_google_cron`. Para o item 189(c), considerar no Google releitura do evento persistido antes de classificar `could_not_set`, preservando falha real e diagnóstico por hook/origem. Não remover hook ou fila do Google como estado Core.

## Implantação/tema

Nenhum arquivo do tema alterado. Novos blocos dinâmicos: `f3base/artigo-indice` e `f3base/artigo-compartilhar`; o implantador decide colocação e retirada de índices/compartilhadores duplicados. O índice dá IDs determinísticos a headings; compartilhar usa URLs sem SDK. Revisar links de âncoras manuais após a migração de um componente externo.

O diálogo opcional do formulário move o elemento existente. Adaptadores do tema registrados no Core continuam preferidos. Scripts Core têm marca `data-no-optimize`; o otimizador da hospedagem/tema deve respeitá-la. A mudança preserva estratégia do script, mas não controla código de outros plugins.

Configurações de integrações mudaram para Site Core → Configurações → Conexões e entregas. Links administrativos antigos são redirecionados. Relatórios e edição de formulários continuam nos menus de trabalho.

## Homologação no site

Configurar mapas/contas reais, conferir permissões de dataset, observar webhook e conversão lead→negócio no Pipedrive real e conferir recepção no Gerenciador de Eventos. Não houve envio comercial de teste, alteração em site da frota nem teste em korvena.net.br. A autorização do ativo precisa ser resolvida pelo dono; o pacote não concede acesso remoto.
