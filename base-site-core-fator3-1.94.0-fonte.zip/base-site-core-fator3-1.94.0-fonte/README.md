# Fonte do Fator3 Site Core 1.94.0

O instalador contém a árvore `work/plugin/base-site-core-fator3/`. A base de atualização é a 1.93.0. Requisitos de execução: WordPress 7.1.4 ou superior, PHP de 64 bits a partir de 8.3 e instalação única. Leia `RELATORIO-PRE-FECHAMENTO.md` para os resultados e `work/plugin/base-site-core-fator3/docs/RELEASE-1.94.0.md` para o procedimento de operação.

## Reproduzir os arquivos

Execute na raiz desta árvore com Python 3, zlib e PHP CLI. A compressão de referência usa zlib 1.3.2. O verificador compara também cada arquivo descompactado, a ordem das entradas e a raiz do instalador.

```sh
F3BASE_PHP=php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.94.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.94.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.94.0-fonte.zip
```

## Reproduzir os ensaios de WordPress

Use instalações descartáveis com `WP_ENVIRONMENT_TYPE=local`, bancos cujo nome comece em `core_194_` e bloqueio de HTTP externo/correio. A bancada integrada usa as versões de `evidence/1940/conjunto.json`. Para instalação limpa ative apenas o Core em uma instalação nova. Para a migração, instale o Core 1.93.0, execute `tests/194/semear-migracao.php`, atualize com o instalador final usando o Plugin_Upgrader e execute `tests/194/conferir-migracao.php` em processo novo. Confira os campos de atualização, configuração e fila.

1. Coloque `tests/194/ordem-bootstrap.php` como MU-plugin somente nas instalações descartáveis usadas na prova de ordem. Use WP-CLI `eval-file tests/194/ordem-verificar.php`. Com `F3_ORDEM=core`, a base usa `F3_PRECOCE=1 F3_ERROS=mcp_route_missing`. Na versão final use `F3_PRECOCE=0` e omita `F3_ERROS`. O modo `terceiro` e o modo `conflito` estão descritos no encaminhamento em `reference/430-194/`.
2. Com o MCP oficial e sem a variável `F3_ORDEM`, execute `wp --user=1 eval-file tests/194/registro.php`. O ensaio verifica abertura, deduplicação, fase inconclusiva, recuperação e histórico limitado. Os testes `tests/193/entrega.php` e `tests/193/produtores.php` exercitam a central e os produtores.
3. Para a prova pelo painel nativo, defina `F3BASE_SITE` com o caminho absoluto do `wp-load.php` integrado e execute `php -S 127.0.0.1:8090 tests/194/contratos.php`. Consulte `/wp-admin/tools.php` nesse servidor local, guarde o JSON e encerre o processo. Repita o teste com PHP 8.4. Para verificar a permissão no Core isolado, aponte `F3BASE_SITE` para a instalação limpa e execute `php tests/194/permissao.php`.
4. Para a agenda, carregue `tests/194/passagem-cli.php` com `wp --require=... cron event run`. Na mesma chamada, informe os ganchos `f3base_qa193_0` até `f3base_qa193_11`, seguidos de `f3_meta_worker`, `f3_linkedin_worker`, `f3_linkedin_lead_discovery` e `wp_privacy_delete_old_export_files`. A fixture isola as opções em tabela temporária e substitui os callbacks durante o ensaio.
5. A comparação de nomes está em `tests/193/catalogo.py`. Passe como argumentos o fonte 1.91.0, o instalador 1.92.1 e o instalador 1.94.0. O arquivo `evidence/1940/revalidacao-final.json` registra também a igualdade dos 259 arquivos do catálogo entre a 1.93.0 e a 1.94.0.

As provas desta release estão em `evidence/1940/`. Os diretórios anteriores preservam a rastreabilidade da base. O patch do MCP fica em `reference/430-194/mcp-048-registro-tardio.patch`.
