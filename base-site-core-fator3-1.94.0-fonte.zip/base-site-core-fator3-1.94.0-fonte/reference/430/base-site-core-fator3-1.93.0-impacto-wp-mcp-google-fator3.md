# Impacto do Site Core 1.93.0 em Google

Pedido Core 430 · 18/11/2026 · Etapa de entrega, revisão 2. Base Core 1.92.1. Destinatário examinado wp-mcp-google-fator3 0.36.0. Classificação `acao-necessaria`. Situação aberta para incorporação oficial. A proposta de planejamento está em `reference/430/plano.md` no fonte do Core.

Instalador emissor `base-site-core-fator3-1.93.0-instalador.zip`. SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.

## Contrato e consequência

Provas GA4 e Google Ads e resultado da renovação já são lidos por conexão via ConversionDelivery::read(), mesmo com google/alerts desligado. Há uma lacuna separada em Automation/Alerts::observe(). Com o emissor interno desligado ou o evento desmarcado, a função retorna antes de gravar um incidente. Uma leitura posterior pelo Core não consegue recuperar esse fato.

O filtro PHP local `f3base_incidente_publicar_v1` recebe valor inicial null e um array com pacote, código, recurso e estado. Os estados aceitos são aberto e recuperado. O produtor pode informar desde (epoch em segundos), acao_humana (booleano) e a rota administrativa permitida. A central calcula a referência opaca do recurso e reserva o evento antes de wp_mail. Uma integração sem destinatário mantém a fila no WordPress. Na ausência do filtro, o valor inicial null indica que o Core não recebeu o incidente. Uma reserva ocupada pede nova observação com o mesmo recurso.

## Localização e validação

Arquivo do destinatário `includes/Automation/Alerts.php`, SHA-256 `fa219dce5fa8873abe91d81d360bb78d183b61da3f42b6dad377c553fcb773b6`. No Core, a recepção está em `includes/class-f3base-incidentes.php` e a leitura por pacote em `includes/class-f3base-incidentes-provedores.php`.

O teste tests/193/google-desativado.php executou observe(cron_late, recurso, falhou, código, ação) quatro vezes no WordPress isolado. Na 0.36.0 oficial, zero avisos. Com o patch experimental, um aviso de abertura e um de recuperação. O teste interceptou wp_mail e manteve os alertas internos desligados. Testado o retorno sem habilitar o transporte do Google.

## Ação e aceite

Incorporar a publicação local no ramo que hoje descarta a observação. O recurso é connection_id + barra + SHA-256 de connection_id|event|resource_id, idêntico ao registro que o Core lê quando a automação Google está ligada. Preservar o early return de Confirmation::capturing(). O patch não expõe texto, URL, credencial ou resposta do fornecedor. A publicação nativa permanece a cargo do mantenedor Google.

O Core já oferece o contrato e o transporte. Instalar o Core, preencher `f3base_avisos_tecnicos.email` e conferir o recibo com acesso administrativo. O teste do filtro no Site-Teste registrou uma abertura e uma recuperação por origem. O coletor interceptou o transporte antes de sair do ambiente. O aceite da caixa postal e de uma conta real permanece com a frota. O encaminhamento não altera a release oficial do destinatário.

## Patch experimental e reprodução

Aplicar na raiz de uma cópia do plugin 0.36.0 com `patch -p1 < google-alerts-desativados.patch`. O diff está incluído no fonte do Core. Executar o teste com WP-CLI e F3LAB_PATCH=1. A versão oficial do Google não incorpora esta alteração.

```diff
--- a/includes/Automation/Alerts.php
+++ b/includes/Automation/Alerts.php
@@ -152,6 +152,14 @@
         }
         $config = self::config();
         if ( empty( $config['enabled'] ) || ! in_array( $event, $config['events'], true ) ) {
+            if ( in_array( $event, self::EVENTS, true ) && has_filter( 'f3base_incidente_publicar_v1' ) ) {
+                $resource = hash( 'sha256', Connections::id() . '|' . $event . '|' . $resource_id );
+                apply_filters( 'f3base_incidente_publicar_v1', null, [
+                    'pacote' => 'google', 'codigo' => 'integracao_indisponivel',
+                    'recurso' => Connections::id() . '/' . $resource,
+                    'estado' => $failed ? 'aberto' : 'recuperado',
+                ] );
+            }
             return;
         }
         $id = hash( 'sha256', Connections::id() . '|' . $event . '|' . $resource_id );
```
