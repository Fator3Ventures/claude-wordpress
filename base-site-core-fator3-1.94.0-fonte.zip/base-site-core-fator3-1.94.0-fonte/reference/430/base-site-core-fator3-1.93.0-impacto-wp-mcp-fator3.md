# Impacto do Site Core 1.93.0 em canal MCP

Pedido Core 430 · 18/11/2026 · Etapa de entrega, revisão 2. Base Core 1.92.1. Destinatário examinado wp-mcp-fator3 0.46.0. Classificação `validacao-coordenada`. Situação aberta para aceite operacional do responsável. A proposta de planejamento está em `reference/430/plano.md` no fonte do Core.

Instalador emissor `base-site-core-fator3-1.93.0-instalador.zip`. SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.

## Contrato e consequência

O Core examina ConnectionStatus::snapshot(true) no WordPress. Em servidor habilitado, sinaliza erro do registro MCP e fecha o episódio após confirmação local do registro. O próprio WordPress pode iniciar o envio mesmo quando aquele canal MCP deixou de servir requisições.

O filtro PHP local `f3base_incidente_publicar_v1` recebe valor inicial null e um array com pacote, código, recurso e estado. Os estados aceitos são aberto e recuperado. O produtor pode informar desde (epoch em segundos), acao_humana (booleano) e a rota administrativa permitida. A central calcula a referência opaca do recurso e reserva o evento antes de wp_mail. Uma integração sem destinatário mantém a fila no WordPress. Na ausência do filtro, o valor inicial null indica que o Core não recebeu o incidente. Uma reserva ocupada pede nova observação com o mesmo recurso.

## Localização e validação

Arquivo do destinatário `includes/ConnectionStatus.php`, SHA-256 `2d2de8e30b19ec847e7186571491ee9e74161b2ae108ad08d2f5a08a1db8ef14`. No Core, a recepção está em `includes/class-f3base-incidentes.php` e a leitura por pacote em `includes/class-f3base-incidentes-provedores.php`.

O conjunto local carregou o canal 0.46.0 e executou o adaptador com o registro presente. A prova dos cinco produtores abriu e recuperou o episódio sintético de canal. A leitura documental e o novo catálogo de operações passaram pelo canal real do Site-Teste.

## Ação e aceite

O mantenedor deve preservar server_enabled, registry_checked e errors. Uma queda completa de PHP, WordPress ou hospedagem não executa o observador local. Para provar uma interrupção de ponta a ponta, usar um WordPress descartável, observar abertura e restabelecer o registro para verificar a recuperação. Não desabilitar o canal de produção para homologação.

O Core já oferece o contrato e o transporte. Instalar o Core, preencher `f3base_avisos_tecnicos.email` e conferir o recibo com acesso administrativo. O teste do filtro no Site-Teste registrou uma abertura e uma recuperação por origem. O coletor interceptou o transporte antes de sair do ambiente. O aceite da caixa postal e de uma conta real permanece com a frota. O encaminhamento não altera a release oficial do destinatário.
