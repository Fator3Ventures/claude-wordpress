# Impacto do Site Core 1.93.0 em Pipedrive

Pedido Core 430 · 18/11/2026 · Etapa de entrega, revisão 2. Base Core 1.92.1. Destinatário examinado wp-mcp-pipedrive-fator3 0.11.1. Classificação `validacao-coordenada`. Situação aberta para aceite operacional do responsável. A proposta de planejamento está em `reference/430/plano.md` no fonte do Core.

Instalador emissor `base-site-core-fator3-1.93.0-instalador.zip`. SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.

## Contrato e consequência

CoreClient e o Core compartilham a operação da integração. A observação usa o estado de autorização já persistido pelo Core em f3base_pipedrive_estado. Uma integração ativa gera autorização recusada para os códigos documentados no adaptador. A recuperação exige que F3Base_Integracoes::pipedrive_verificado() valide novamente a conta.

O filtro PHP local `f3base_incidente_publicar_v1` recebe valor inicial null e um array com pacote, código, recurso e estado. Os estados aceitos são aberto e recuperado. O produtor pode informar desde (epoch em segundos), acao_humana (booleano) e a rota administrativa permitida. A central calcula a referência opaca do recurso e reserva o evento antes de wp_mail. Uma integração sem destinatário mantém a fila no WordPress. Na ausência do filtro, o valor inicial null indica que o Core não recebeu o incidente. Uma reserva ocupada pede nova observação com o mesmo recurso.

## Localização e validação

Arquivo do destinatário `includes/CoreClient.php`, SHA-256 `9b4a726ee9ab10e925ff0d1f0a84e530a330243e1c990ffadaada47f5f72e656`. No Core, a recepção está em `includes/class-f3base-incidentes.php` e a leitura por pacote em `includes/class-f3base-incidentes-provedores.php`.

O laboratório carregou o cliente 0.11.1, executou a leitura do adaptador e publicou as transições sintéticas pelo contrato da central. Os testes de incidente não criam contatos nem modificam negócios. A integração ligada a conta comercial e a renovação real permanecem por homologar.

## Ação e aceite

O mantenedor pode publicar falhas adicionais do seu próprio domínio com pacote=pipedrive e recurso estável. Para o mesmo episódio de autorização acompanhado pelo Core, usar codigo=autorizacao_recusada e recurso=conta. A falha de uma operação isolada não comprova perda da autorização da conta.

O Core já oferece o contrato e o transporte. Instalar o Core, preencher `f3base_avisos_tecnicos.email` e conferir o recibo com acesso administrativo. O teste do filtro no Site-Teste registrou uma abertura e uma recuperação por origem. O coletor interceptou o transporte antes de sair do ambiente. O aceite da caixa postal e de uma conta real permanece com a frota. O encaminhamento não altera a release oficial do destinatário.
