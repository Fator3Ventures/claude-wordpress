# Impacto do Site Core 1.93.0 em Meta

Pedido Core 430 · 18/11/2026 · Etapa de entrega, revisão 2. Base Core 1.92.1. Destinatário examinado wp-mcp-meta-fator3 0.28.0. Classificação `validacao-coordenada`. Situação aberta para aceite operacional do responsável. A proposta de planejamento está em `reference/430/plano.md` no fonte do Core.

Instalador emissor `base-site-core-fator3-1.93.0-instalador.zip`. SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.

## Contrato e consequência

Worker::health() informa falhas de autorização por conexão ou agenda, orçamento esgotado, atraso e ausência de worker. O Core reconcilia os recursos ativos e usa a ausência na próxima leitura completa para fechar o episódio. A entrada chega pela revisão periódica e pelo caminho de Worker::notify().

O filtro PHP local `f3base_incidente_publicar_v1` recebe valor inicial null e um array com pacote, código, recurso e estado. Os estados aceitos são aberto e recuperado. O produtor pode informar desde (epoch em segundos), acao_humana (booleano) e a rota administrativa permitida. A central calcula a referência opaca do recurso e reserva o evento antes de wp_mail. Uma integração sem destinatário mantém a fila no WordPress. Na ausência do filtro, o valor inicial null indica que o Core não recebeu o incidente. Uma reserva ocupada pede nova observação com o mesmo recurso.

## Localização e validação

Arquivo do destinatário `includes/Worker.php`, SHA-256 `77737eee45b10d729087db32f1a3f972f6e38c53eae70a9dba855df19f82600e`. No Core, a recepção está em `includes/class-f3base-incidentes.php` e a leitura por pacote em `includes/class-f3base-incidentes-provedores.php`.

Em um WordPress local com o Meta oficial, tests/193/produtores.php cria uma agenda sintética, persiste not_authorized e chama Worker::notify(). Repete a leitura, restaura a agenda e chama o worker novamente. A mesma passagem injeta e recupera um atraso de cron. As quatro transições chegaram uma vez ao destino capturado, sem requisição HTTP.

## Ação e aceite

O mantenedor deve preservar o significado de issues, schedule_id, connection_id e last_error.observed_at. Monitorar o recibo da central em f3base/incidentes-tecnicos-ler. O retorno falso do correio anterior indica que aquele transporte foi interceptado e não confirma o resultado do e-mail do Core. Sem mudança exigida para operar a 0.28.0.

O Core já oferece o contrato e o transporte. Instalar o Core, preencher `f3base_avisos_tecnicos.email` e conferir o recibo com acesso administrativo. O teste do filtro no Site-Teste registrou uma abertura e uma recuperação por origem. O coletor interceptou o transporte antes de sair do ambiente. O aceite da caixa postal e de uma conta real permanece com a frota. O encaminhamento não altera a release oficial do destinatário.
