# Plano de integração 430 — 18/11/2026

O Core mantém a identidade do episódio por site, pacote, código e recurso. Os produtores fornecem observações locais, usam o mesmo recurso ao recuperar e mantêm a lógica de autorização em seus próprios pacotes. A abertura, a recuperação, as datas conhecidas e a entrega por wp_mail pertencem ao Core. Acompanhar a adoção por pacote e testar as versões atualmente instaladas no Site-Teste. O transporte aceita um e-mail sem comprovar chegada à caixa.

| Pacote | Ponto de integração | Evidência |
|---|---|---|
| Meta 0.28.0 | Worker::notify, health e agendas | Bloqueio de autorização e posterior retomada por agenda/conexão |
| LinkedIn 0.25.0 | Credentials::status, notice e maintenance | Vencimentos independentes do token e refresh e renovação |
| Google 0.36.0 | ConversionDelivery, prova por destino e incidentes da renovação | Verificação recuperada e prazo de cada prova |
| Pipedrive 0.11.1 | Operations::status e estado de autorização de CoreClient | Falha operacional e primeira confirmação de recuperação |
| Canal 0.46.0 | ConnectionStatus::snapshot | Falha comprovada no registro local do servidor e restabelecimento |

Testar destinatário vazio, recusa do wp_mail, ausência de Slack, repetição, retorno do serviço e aparição de modelos novos. A configuração do site e as provas locais são a fonte da decisão, sem chamadas a provedores durante a conferência.
