# Impacto do Site Core 1.93.0 em LinkedIn

Pedido Core 430 · 18/11/2026 · Etapa de entrega, revisão 2. Base Core 1.92.1. Destinatário examinado wp-mcp-linkedin-fator3 0.25.0. Classificação `validacao-coordenada`. Situação aberta para aceite operacional do responsável. A proposta de planejamento está em `reference/430/plano.md` no fonte do Core.

Instalador emissor `base-site-core-fator3-1.93.0-instalador.zip`. SHA-256 `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8`.

## Contrato e consequência

Credentials::status() projeta enabled, connection_id, token_configured, expires_at, refresh_configured, refresh_expires_at, incident e failures. O Core verifica acesso e renovação em dois episódios, com o mesmo identificador estável da conexão. Uma validade futura que sai da janela fecha o incidente. Validade desconhecida não comprova recuperação.

O filtro PHP local `f3base_incidente_publicar_v1` recebe valor inicial null e um array com pacote, código, recurso e estado. Os estados aceitos são aberto e recuperado. O produtor pode informar desde (epoch em segundos), acao_humana (booleano) e a rota administrativa permitida. A central calcula a referência opaca do recurso e reserva o evento antes de wp_mail. Uma integração sem destinatário mantém a fila no WordPress. Na ausência do filtro, o valor inicial null indica que o Core não recebeu o incidente. Uma reserva ocupada pede nova observação com o mesmo recurso.

## Localização e validação

Arquivo do destinatário `includes/Credentials.php`, SHA-256 `63efe900684271942dd5e27494db4fa30ed6853fa7b5dc851c3391f444c6ef06`. No Core, a recepção está em `includes/class-f3base-incidentes.php` e a leitura por pacote em `includes/class-f3base-incidentes-provedores.php`.

O laboratório chamou Credentials::status() com a versão oficial e ensaiou o contrato de abertura e recuperação. Uma validade fora da janela de sete dias, seguida de validade dentro da janela, repetição e posterior extensão, produziu um aviso e uma recuperação. Sem OAuth externo. A configuração de credenciais do titular não foi alterada.

## Ação e aceite

O mantenedor deve conferir com uma conexão de homologação os prazos reais no painel após renovar. Preservar epoch UTC em segundos, inclusive o vencimento próprio do refresh. Um novo identificador de conexão cria outro recurso. Nenhuma alteração de schema é exigida para a versão vigente.

O Core já oferece o contrato e o transporte. Instalar o Core, preencher `f3base_avisos_tecnicos.email` e conferir o recibo com acesso administrativo. O teste do filtro no Site-Teste registrou uma abertura e uma recuperação por origem. O coletor interceptou o transporte antes de sair do ambiente. O aceite da caixa postal e de uma conta real permanece com a frota. O encaminhamento não altera a release oficial do destinatário.
