# Pedidos core 430 e MCP84 · planejamento de 18/11/2026

Core 1.93.0 → 1.94.0 prevista. Instalador-alvo ainda não gerado. Revisão 1. A pauta também conserva os aceites 423(g) e 429. Repetir a regressão da agenda e comparar byte a byte o índice de aparelhos.

No WordPress 7.1.4/PHP 8.3.6 em WP-CLI, uma observação pelo Core 1.93.0 durante init na prioridade 5 constrói o servidor REST antes do registro do transporte MCP 0.48.0 na prioridade 20. Nesta mesma requisição o MCP informa mcp_route_missing mesmo após wp_loaded. Uma segunda invocação sem observação precoce encontra as rotas. O registro remoto da 1.93.0 não identifica o produtor ou o contexto para atribuir essa causa aos episódios históricos.

Proposta Core: consultar apenas o SDK público e o registro já concluído, distinguir consulta incompleta, registrar contexto local e códigos reconhecidos nas transições do recurso registro-wordpress. Preservar estado, entrega e deduplicação dos históricos anteriores. A prova deve incluir dados anteriores, consulta parcial, rota realmente ausente, repetição e recuperação.

Encaminhamento MCP previsto: HttpTransport instala o callback de rest_api_init na construção. Se outro plugin já concluiu o hook antes de o adaptador CLI criar o transporte, o callback não é executado nessa requisição. Provar em cópia isolada a inscrição tardia, inclusive conflito, preservando callbacks de terceiros. Aceite em conjunto e rastreio da frota no documento de impacto do MCP. Nenhuma alteração solicitada nos contratos Google, Meta, LinkedIn e Pipedrive.
