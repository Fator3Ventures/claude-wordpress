# Impacto do Fator3 Site Core 1.94.0 no Fator3 MCP 0.48.0

**Revisão 2 · Entrega · 18/11/2026 · Ação necessária · Aberto para o mantenedor do MCP.** Referências Core 430 e MCP84. O plano da revisão 1 e o patch estão em `reference/430-194/` do fonte.

| Identidade | Versão | SHA-256 do instalador |
|---|---|---|
| Core de origem | 1.93.0 | `eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8` |
| Core entregue | 1.94.0 | `0eff84a92622b3daa2aebd81437bbb2c33eaea648d1955c46e29ef70aedf9008` |
| MCP oficial examinado | 0.48.0 | `3ace23b8e4405d0444048fcbddd51479ee63dee3c49d4373760151ef8b67d28f` |

## Causa reproduzida

Em WP-CLI, um callback em `init` na prioridade 5 pode inicializar o REST antes de o adaptador criar o transporte. O construtor de `HttpTransport` agenda `register_routes()` em `rest_api_init`, prioridade 16. Se o ponto de inscrição já passou, a rota falta naquela requisição. A próxima requisição pode encontrá-la. O impacto da 0.48.0 registrava alternância na fila do Site-Teste. A reprodução identifica uma causa suficiente em laboratório. O registro anterior à 1.94.0 não identifica quem iniciou o REST em cada ocorrência da frota.

## Parte entregue no Core

`F3Base_Incidentes_Provedores::registro_canal()` usa o SDK público `ServerContract::status()` após a inicialização. O observador conserva o incidente diante de uma leitura inconclusiva. Uma falha verificável pode abrir o incidente e um registro saudável permite recuperá-lo. O filtro `f3base_incidente_publicar_v1` continua recebendo o evento do MCP e a central preserva o histórico das últimas 12 mudanças de estado do recurso `registro-wordpress`. O Core distingue a origem da transição e registra o estado observado na recepção. Filas, deduplicação, reservas e autorização administrativa continuam operando sobre o mesmo recurso.

## Alteração solicitada no MCP

Aplicar a proposta em `core/includes/Server/Transport/HttpTransport.php`, método `__construct()`. Quando `rest_api_init` já terminou, ou está em execução e já chegou à prioridade 16, chamar o método de registro existente imediatamente. Antes disso, manter a inscrição na prioridade 16. A rotina existente verifica as rotas ocupadas e preserva o callback de terceiros.

O patch aplicável está no fonte do Core, em `reference/430-194/mcp-048-registro-tardio.patch`. Na raiz de **uma cópia de desenvolvimento** do MCP 0.48.0, aplique `patch -p1 < /caminho/mcp-048-registro-tardio.patch`. A proposta altera somente o momento do registro. Não introduz migração de banco, permissão ou credencial. O instalador oficial do MCP no Site-Teste continua na versão entregue pelo próprio mantenedor.

## Provas e critério de aceite

WordPress 7.1.4, PHP 8.3.6 e WP-CLI. Dados em `evidence/1940/`, reprodução em `tests/194/ordem-bootstrap.php` e `ordem-verificar.php`. O README do fonte descreve a bancada isolada. A variável `F3_PRECOCE` indica se o hook REST já havia executado durante o callback de prioridade 5. Em cada invocação, a fixture compara os códigos observados a `F3_ERROS` e verifica o registro.

| Origem da leitura precoce | Core | Transporte | Resultado observado |
|---|---|---|---|
| Observador do Core | 1.93.0 | MCP oficial | REST iniciado, `mcp_route_missing` |
| Observador do Core | 1.94.0 | MCP oficial | REST ainda não iniciado pelo observador, registro saudável ao fim |
| Terceiro | 1.94.0 | MCP oficial | REST iniciado, `mcp_route_missing` |
| Terceiro | 1.94.0 | Cópia com patch | REST iniciado, registro e ferramentas saudáveis |
| Terceiro com rota já ocupada | 1.94.0 | Cópia com patch | `mcp_route_conflict`, callback existente preservado |

Com `F3_ORDEM=terceiro F3_PRECOCE=1`, espere `F3_ERROS=mcp_route_missing` no MCP oficial e lista vazia no candidato do MCP. Com `F3_ORDEM=conflito F3_PRECOCE=1`, espere `F3_ERROS=mcp_route_conflict` e `terceiro_preservado=true`. O caso do próprio Core está resolvido na 1.94.0. Para o caso de terceiros, o mantenedor do MCP deve integrar a mudança, repetir os cenários, versionar seu pacote e identificar o instalador aceito. A versão entregue do Core está pronta para essa integração.

## Aceite operacional

Após a troca coordenada, comparar as transições novas de `f3base/incidentes-tecnicos-ler` com `system/health`, horário, produtor e contexto. A fila pode conservar entregas antigas enquanto o destino técnico estiver vazio. Ações de entrega e reconciliação pertencem ao operador que conhece o destino e os recibos do transporte. O proprietário do MCP responde pela incorporação oficial. À frota cabe validar o comportamento nas passagens reais.
