<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME, 'core_194_')) {
    throw new RuntimeException('Somente em instalação descartável de homologação.');
}
update_option('f3base_avisos_tecnicos',['email'=>'','antecedencia_dias'=>11,'atraso_minutos'=>77]);
$e=['pacote'=>'pipedrive','codigo'=>'autorizacao_recusada','recurso'=>'migracao194','estado'=>'aberto'];
$r=F3Base_Incidentes::publicar($e);
if(empty($r['ok']))throw new RuntimeException('semente');
echo wp_json_encode(['antes'=>F3BASE_PLUGIN_VERSAO,'fila'=>$r['estado']]).PHP_EOL;
