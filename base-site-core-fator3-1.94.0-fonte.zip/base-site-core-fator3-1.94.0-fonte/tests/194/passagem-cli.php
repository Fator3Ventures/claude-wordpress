<?php
/** Carregar com wp --require no cron event run de um banco local descartável. */
WP_CLI::add_hook('after_wp_load', static function() {
    if (wp_get_environment_type()!=='local' || !str_starts_with(DB_NAME,'core_194_')) {throw new RuntimeException('Exige laboratório.');}
    WP_CLI::add_hook('before_invoke:cron event run',static function() {
        global $wpdb,$wp_filter,$wp_object_cache;
        if (wp_using_ext_object_cache()) {throw new RuntimeException('Cache não isolado.');}
        $hooks=array_map(static fn($i)=>'f3base_qa193_'.$i,range(0,11));
        $nativos=['f3_meta_worker','f3_linkedin_worker','f3_linkedin_lead_discovery','wp_privacy_delete_old_export_files'];
        $real=$wpdb->options; $tmp=$wpdb->prefix.'qa193_passagem';
        if ($wpdb->query($wpdb->prepare('CREATE TEMPORARY TABLE %i LIKE %i',$tmp,$real))===false) {throw new RuntimeException('Tabela temporária indisponível.');}
        $wpdb->query($wpdb->prepare("INSERT INTO %i SELECT * FROM %i WHERE option_name IN ('home','siteurl','timezone_string','gmt_offset','admin_email')",$tmp,$real));
        $wpdb->options=$tmp; $wp_object_cache=new WP_Object_Cache();
        $n=[]; $medidas=0; $erros=[]; $surpresas=[];
        add_action('f3base_fila_agenda_medida',static function($h,$t,$op,$res) use (&$medidas){
            if (str_starts_with($h,'f3base_qa193_') && $res==='gravado') {
                ++$medidas;
                $cache=wp_load_alloptions();$cache['cron']=serialize(['version'=>2]);wp_cache_set('alloptions',$cache,'options');
            }
        },PHP_INT_MAX,4);
        foreach(['cron_reschedule_event_error','cron_unschedule_event_error'] as $acao){
            add_action($acao,static function($e)use(&$erros){$erros[]=$e->get_error_code();});
        }
        foreach(array_merge($hooks,$nativos) as $h) {
            unset($wp_filter[$h]);
            add_action($h,static function()use($h,&$n,&$surpresas,$wpdb) {
                $n[$h]=1+($n[$h]??0);
                $db=maybe_unserialize($wpdb->get_var($wpdb->prepare("SELECT option_value FROM %i WHERE option_name='cron'",$wpdb->options)));
                if(get_option('cron')!==$db){$surpresas[]=$h;}
            });
            $r=wp_schedule_single_event(time()-10,$h,[],true);
            if($r!==true){throw new RuntimeException('Agendamento recusado para '.$h);}
        }
        WP_CLI::add_hook('after_invoke:cron event run',static function()use(&$medidas,&$n,&$erros,&$surpresas,$wpdb,$real,$hooks,$nativos) {
            $restantes=[];
            foreach (_get_cron_array() as $eventos) {$restantes=array_merge($restantes,array_keys($eventos));}
            $left=array_values(array_intersect($restantes,array_merge($hooks,$nativos)));
            $wpdb->options=$real;wp_cache_flush();
            $ok=$medidas===24 && count($n)===16 && array_unique(array_values($n))===[1] && !$erros && !$surpresas && !$left;
            WP_CLI::line(wp_json_encode(['ok'=>$ok,'origem'=>F3Base_Execucoes::origem(),'escritas'=>$medidas,'execucoes'=>$n,'erros'=>$erros,'divergencias'=>$surpresas,'ganchos_do_ensaio_restantes'=>$left,'outros_ganchos'=>array_values(array_diff($restantes,$left))]));
            if(!$ok){WP_CLI::error('Contagem ou persistência divergente.');}
        });
    });
});
