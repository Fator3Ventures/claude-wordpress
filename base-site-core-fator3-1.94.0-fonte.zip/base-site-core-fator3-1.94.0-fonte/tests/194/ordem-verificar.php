<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_194_')) {throw new RuntimeException('Somente laboratório.');}
$s=\Fator3\McpFiles\ConnectionStatus::snapshot(true);
$real=['modo'=>getenv('F3_ORDEM'),'core'=>F3BASE_PLUGIN_VERSAO,'php'=>PHP_VERSION,'rest_precoce'=>$GLOBALS['f3_194_rest_precoce'],
    'erros'=>$s['errors'],'registro'=>$s['registry_checked'],'servidor'=>$s['server_registered'],'ferramentas'=>$s['tools_ready']];
$esperado=array_filter(explode(',',getenv('F3_ERROS')?:''));
if (getenv('F3_ORDEM') === 'conflito') {
    $callbacks=rest_get_server()->get_routes()['/mcp/wp-mcp-fator3'];
    $real['terceiro_preservado']=in_array('__return_true',array_column($callbacks,'callback'),true);
    if (!$real['terceiro_preservado']) {throw new RuntimeException('Callback de terceiro substituído');}
}
echo wp_json_encode($real).PHP_EOL;
if (array_diff($real['erros'],$esperado) || array_diff($esperado,$real['erros']) || !$real['registro']
    || $real['rest_precoce']!==(int)getenv('F3_PRECOCE')) {throw new RuntimeException('Resultado inesperado');}
