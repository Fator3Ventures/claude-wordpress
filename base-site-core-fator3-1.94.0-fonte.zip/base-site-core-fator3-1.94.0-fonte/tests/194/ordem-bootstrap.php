<?php
/** MU-plugin somente de laboratório. Não envia mensagens e não usa credenciais. */
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_194_')) {return;}
$modo = getenv('F3_ORDEM');
if (!$modo) {return;}
add_action('rest_api_init', static function() use ($modo) {
    if ($modo === 'conflito') {
        register_rest_route('mcp','/wp-mcp-fator3',['methods'=>'GET','callback'=>'__return_true','permission_callback'=>'__return_true']);
    }
}, 3);
add_action('init', static function() use ($modo) {
    if ($modo === 'core') {F3Base_Incidentes_Provedores::canal();}
    if ($modo === 'terceiro' || $modo === 'conflito') {rest_get_server();}
    $GLOBALS['f3_194_rest_precoce'] = did_action('rest_api_init');
}, 5);
