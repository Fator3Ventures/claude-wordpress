<?php
/** Executar por wp eval-file somente em laboratório descartável, com o conjunto atual. */
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_194_')) {
    throw new RuntimeException('Exige banco de laboratório.');
}
function exigir194(bool $valor, string $nome): void {
    if (!$valor) {throw new RuntimeException($nome);}
    $GLOBALS['casos194'][] = $nome;
}
function incidente194(): array {
    $ref = hash_hmac('sha256','registro-wordpress',wp_salt('auth'));
    $apos = '';
    do {
        $pagina = F3Base_Incidentes::listar(['apos'=>$apos]);
        foreach ($pagina['itens'] as $item) {
            if ($item['recurso_ref'] === $ref && $item['codigo'] === 'canal_indisponivel') {return $item;}
        }
        $apos = $pagina['proximo'];
    } while ($apos);
    return [];
}
wp_set_current_user(1);
$destino = '';
add_filter('pre_option_f3base_avisos_tecnicos', static function() use (&$destino) {return ['email'=>$destino];});
$assinatura = hash_hmac('sha256','registro-wordpress',wp_salt('auth'));
$mail = [];
add_filter('pre_wp_mail',static function($pre,$a) use (&$mail,$assinatura) {
    if (str_contains($a['message'],$assinatura)) {$mail[]=$a['subject'];}
    return true;
},999,2);
$snapshot = \Fator3\McpFiles\ConnectionStatus::snapshot(true);
exigir194($snapshot['errors'] === [] && $snapshot['registry_checked'], 'registro completo no MCP original');
$falhar=static function($rotas) {
    unset($rotas['/mcp/wp-mcp-fator3']);
    return $rotas;
};
$base=incidente194();
add_filter('rest_endpoints',$falhar,100);
F3Base_Incidentes_Provedores::canal();
F3Base_Incidentes_Provedores::canal();
$item=incidente194();
exigir194($item['estado']==='aberto','rota removida abre incidente');
exigir194($item['entregas_pendentes']===($base['entregas_pendentes']??0)+1,'dois exames, uma nova entrega');
$rastro=end($item['historico_registro']);
exigir194($rastro['origem']==='observador_core' && $rastro['contexto']==='cli'
    && $rastro['registro_na_recepcao']['erros']===['mcp_route_missing'], 'origem, contexto e código exatos');
exigir194($rastro['versao_canal']==='0.48.0' && $rastro['versao_core']==='1.94.0','identidade dos pacotes');
remove_filter('rest_endpoints',$falhar,100);
// Inconclusivo durante o registro, mesmo quando o snapshot da chamada anterior era completo.
$dentro=static function(){F3Base_Incidentes_Provedores::canal();};
add_action('f3qa194_fase', $dentro);
$GLOBALS['wp_current_filter'][]='rest_api_init';
try {do_action('f3qa194_fase');} finally {array_pop($GLOBALS['wp_current_filter']);}
exigir194(incidente194()===$item,'fase incompleta preserva abertura e fila');
F3Base_Incidentes_Provedores::canal();
F3Base_Incidentes_Provedores::canal();
$item=incidente194();
exigir194($item['estado']==='recuperado' && $item['entregas_pendentes']===($base['entregas_pendentes']??0)+2,'recuperação confirmada apenas uma vez');
$e=['pacote'=>'canal','codigo'=>'canal_indisponivel','recurso'=>'registro-wordpress','desde'=>time()-90,
    'texto_livre'=>'TEXTO_NAO_PERSISTIR','historico_registro'=>['TEXTO_NAO_PERSISTIR']];
for ($i=0;$i<14;$i++) {
    $e['estado']=$i%2?'recuperado':'aberto';
    $r=apply_filters('f3base_incidente_publicar_v1',null,$e);
    exigir194($r['ok']===true,'aceitou transição '.($i+1));
}
$item=incidente194();$hist=$item['historico_registro'];
exigir194(count($hist)===12 && $item['entregas_pendentes']===($base['entregas_pendentes']??0)+16,'limite do histórico independente da fila integral');
$ultimo=end($hist);
exigir194($ultimo['origem']==='publicador_canal' && $ultimo['desde_informado']<$ultimo['recebido_em']
    && $ultimo['registro_na_recepcao']['verificado']===true, 'reentrega distingue recepção e emissão');
exigir194(!str_contains(wp_json_encode($hist),'TEXTO_NAO_PERSISTIR'),'payload livre descartado');
$destino='laboratorio@example.invalid';
F3Base_Incidentes_Provedores::canal();
$item=incidente194();
exigir194(!$item['entregas_pendentes'] && count($mail)===($base['entregas_pendentes']??0)+16 && $item['historico_registro']===$hist,
    'fila completa entregue em transporte interceptado e histórico preservado');
echo wp_json_encode(['aprovados'=>count($GLOBALS['casos194']),'casos'=>$GLOBALS['casos194'],'php'=>PHP_VERSION,'wordpress'=>get_bloginfo('version')], JSON_UNESCAPED_UNICODE).PHP_EOL;
