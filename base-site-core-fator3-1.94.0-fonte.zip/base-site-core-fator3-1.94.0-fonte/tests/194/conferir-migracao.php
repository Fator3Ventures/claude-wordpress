<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME, 'core_194_')) {
    throw new RuntimeException('Somente em instalação descartável de homologação.');
}
F3Base_Zelador::atualizacao_urgente();
$s=F3Base_Instalacao::resumo();
echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'atualizacao'=>$s,'config'=>array_intersect_key((array)get_option('f3base_avisos_tecnicos'),['atraso_minutos'=>true,'antecedencia_dias'=>true]),'pendente_migrada'=>array_values(array_map(static fn($v)=>$v['entregas_pendentes'],array_filter(F3Base_Incidentes::listar()['itens'],static fn($v)=>$v['recurso_ref']===hash_hmac('sha256','migracao194',wp_salt('auth')))))],JSON_UNESCAPED_UNICODE).PHP_EOL;
