<?php
/** Verifica o Core isolado, sem a decoração do MCP, em um banco descartável. */
require getenv('F3BASE_SITE');
if (wp_get_environment_type()!=='local' || !str_starts_with(DB_NAME,'core_194_')) {throw new RuntimeException('Somente laboratório');}
wp_set_current_user(0);
$ability=wp_get_ability('f3base/incidentes-tecnicos-ler');
$resultado=$ability->execute([]);
if ($ability->check_permissions([])!==false || !is_wp_error($resultado) || $resultado->get_error_code()!=='ability_invalid_permissions') {
    throw new RuntimeException('Consulta de visitante deveria falhar no Core isolado.');
}
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'visitante'=>$resultado->get_error_code()]).PHP_EOL;
