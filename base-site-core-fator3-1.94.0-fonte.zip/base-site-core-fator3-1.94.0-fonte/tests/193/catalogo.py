"""Compara todos os nomes nos três pacotes, inclusive casos desconhecidos quando o compilador foi escrito."""
from pathlib import Path
from zipfile import ZipFile
import csv, gzip, hashlib, json, sys, runpy
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'build'))
from criterios_aparelhos import is_market
def indice(path):
    with ZipFile(path) as z:
        return {k:v for n in z.namelist() if '/dados/google-play/' in n and n.endswith('.json.gz')
                for k,v in json.loads(gzip.decompress(z.read(n))).items()}
a,b,c=map(indice,sys.argv[1:4])
assert a.keys()==b.keys()==c.keys() and len(a)==44528
tv=[]; ganhos=[]; adicionais=[]
for k in sorted(a):
    antigo,anterior,novo=a[k][1],b[k][1],c[k][1]
    if antigo!=anterior:
        if antigo.casefold()==k and ' ' in k and not is_market(k):
            assert novo==antigo,(k,antigo,novo)
            tv.append([k,antigo,anterior,novo])
        else:
            assert novo==anterior,(k,antigo,anterior,novo)
            ganhos.append(k)
    elif novo!=anterior:
        adicionais.append([k,anterior,novo])
assert len(tv)==19 and len(ganhos)==272
with ZipFile(sys.argv[3]) as z:
    fichas=json.loads(z.read('base-site-core-fator3/dados/aparelhos-br.json'))
    familias=json.loads(z.read('base-site-core-fator3/dados/google-play/familias.json'))
assert fichas['modelos'][fichas['codigos']['lm-x420']][1]=='LG K40'
assert familias['25062rn2d'][1]=='Redmi 15'
gen=runpy.run_path(str(ROOT/'build/gerar-google-play.py'))
identity=gen['identity']
for code,rows,expected in [
    ('orion 4k android tv',[('Orion','France','p','Orion 4K Android TV'),('Orion','Orion','q','Orion 4K Android TV')],'Orion 4K Android TV'),
    ('nebula smart tv',[('Nebula','Nebula Smart TV','x','Nebula Smart TV'),('Nebula','Smart TV','x','Nebula Smart TV')],'Nebula Smart TV'),
    ('pixel900',[('Orion','Pixel900','p','Pixel900'),('Orion','Orion','p','Pixel900')],'Pixel900'),
    ('zx-123',[('Nebula','Nebula Max 9','p','ZX-123')],'Nebula Max 9'),
]:
    assert identity(code,set(rows),{},set(['nebula','orion']))[1]==expected
res={'modelos':len(a),'tvs':tv,'ganhos_anteriores_preservados':len(ganhos),'outros_rotulos_restituidos':adicionais,'sinteticos':4}
print(json.dumps(res,ensure_ascii=False,indent=2))
