<?php
// Executar com wp eval-file em laboratório local. Recursos e destinatários sintéticos.
if (wp_get_environment_type()!=='local') {throw new RuntimeException('Exige laboratório local.');}
function verificar193($cond,$msg){if(!$cond){throw new RuntimeException($msg);}}
$e=['pacote'=>'meta','codigo'=>'agenda_parada','recurso'=>'qa-'.wp_generate_uuid4(),'estado'=>'aberto'];
$destino=''; $resumo=true; $modo='recusa'; $mensagens=[]; $rede=0;
add_filter('pre_option_f3base_avisos_tecnicos',static function() use (&$destino,&$resumo) {return ['email'=>$destino,'antecedencia_dias'=>7,'resumo_diario'=>$resumo];});
add_filter('pre_http_request',static function($v) use (&$rede){$rede++;return new WP_Error('rede_bloqueada');},PHP_INT_MIN);
add_filter('pre_wp_mail',static function($v,$a) use (&$modo,&$mensagens) {
    $mensagens[]=$a['subject'];
    verificar193($a['to']==='tecnico@example.invalid','destino divergente');
    if($modo==='incerto'){throw new RuntimeException('transporte interrompido');}
    return $modo==='aceito';
},PHP_INT_MAX,2);
$publicar=static fn($e)=>apply_filters('f3base_incidente_publicar_v1',null,$e);
verificar193($publicar($e)['estado']==='aguardando_destino' && !$mensagens,'destino ausente');
$destino='tecnico@example.invalid'; $modo='incerto';
verificar193($publicar($e)['estado']==='incerto','transporte incerto');
verificar193($publicar($e)['estado']==='entrega_incerta' && count($mensagens)===1,'reserva repetida');
$rows=F3Base_Incidentes::listar()['itens'];
$ref=hash_hmac('sha256',$e['recurso'],wp_salt('auth'));
$item=array_values(array_filter($rows,static fn($v)=>$v['recurso_ref']===$ref))[0];
$op=['id'=>$item['id'],'reserva'=>$item['reserva'],'resultado'=>'nao_enviado'];
wp_set_current_user(0); verificar193(F3Base_Incidentes::reconciliar($op)['codigo']==='sem_permissao','permissão');
wp_set_current_user(1); verificar193(F3Base_Incidentes::reconciliar($op)['ok'],'reconciliar');
$modo='aceito'; verificar193($publicar($e)['estado']==='aberto','entrega após conciliação');
verificar193(F3Base_Incidentes::reconciliar($op)['codigo']==='reserva_divergente','reserva obsoleta');
delete_transient('f3base_incidentes_revisados'); F3Base_Incidentes::observar();
delete_transient('f3base_incidentes_revisados'); F3Base_Incidentes::observar();
verificar193(count(array_keys($mensagens,'Resumo diário de incidentes técnicos',true))===1,'resumo duplicado ou ausente');
$e['estado']='recuperado'; verificar193($publicar($e)['estado']==='recuperado','recuperação');
verificar193($publicar($e)['estado']==='recuperado' && count(array_filter($mensagens,static fn($s)=>str_starts_with($s,'Recuperação técnica · meta · agenda_parada')))===1,'recuperação duplicada');
$e['estado']='aberto'; $modo='recusa'; verificar193($publicar($e)['estado']==='falhou','falha confirmada');
verificar193($publicar($e)['estado']==='aguardando_retentativa','repetição imediata');
verificar193($rede===0,'requisição HTTP inesperada');
echo wp_json_encode(['ok'=>true,'cenarios'=>['sem_destino','incerteza','deduplicacao','permissao','reconciliacao','revisao','resumo_diario','recuperacao','falha_confirmada','retentativa'],'http'=>$rede]),PHP_EOL;
