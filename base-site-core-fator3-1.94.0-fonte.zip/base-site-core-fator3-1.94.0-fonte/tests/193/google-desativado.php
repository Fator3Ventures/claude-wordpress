<?php
if (wp_get_environment_type()!=='local') {throw new RuntimeException('Somente laboratório.');}
use Fator3\McpGoogle\Automation\Alerts;
$mensagens=[];
add_filter('pre_option_f3base_avisos_tecnicos',static fn()=>['email'=>'tecnico@example.invalid']);
add_filter('pre_wp_mail',static function($pre,$mail)use(&$mensagens){$mensagens[]=$mail['subject'];return true;},900,2);
if(Alerts::config()['enabled']){throw new RuntimeException('O caso requer google/alerts desligado.');}
$ref='qa/'.wp_generate_uuid4();
foreach([true,true,false,false] as $failed){Alerts::observe('cron_late',$ref,$failed,'qa','fixture');}
$esperado=getenv('F3LAB_PATCH')?['Incidente técnico · google · integracao_indisponivel','Recuperação técnica · google · integracao_indisponivel']:[];
if($mensagens!==$esperado){throw new RuntimeException('Transições divergentes.');}
echo wp_json_encode(['ok'=>true,'avisos'=>$mensagens,'patch'=>(bool)getenv('F3LAB_PATCH')],JSON_UNESCAPED_UNICODE),PHP_EOL;
