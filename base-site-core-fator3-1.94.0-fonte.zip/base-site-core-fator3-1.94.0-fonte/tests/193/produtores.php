<?php
/** Executar com WP-CLI em WordPress local com os cinco acompanhantes vigentes. */
if (wp_get_environment_type()!=='local' || !current_user_can('manage_options')) {throw new RuntimeException('Somente laboratório.');}
$agenda='qa193-'.substr(wp_generate_uuid4(),0,8);
$refs=[
    hash_hmac('sha256',hash('sha256','schedule_authorization_failed|'.$agenda),wp_salt('auth')),
    hash_hmac('sha256','executor-cli',wp_salt('auth')),
];
$dest='tecnico@example.invalid'; $correio=[]; $http=0;
add_filter('pre_option_f3base_avisos_tecnicos',static fn()=>['email'=>$dest,'antecedencia_dias'=>7]);
add_filter('pre_http_request',static function($v)use(&$http){++$http;return new WP_Error('rede_bloqueada');},PHP_INT_MIN);
add_filter('pre_wp_mail',static function($pre,$a)use(&$correio,$dest,$refs){
    if ($pre!==null && $pre!==true) {return $pre;}
    if ($a['to']!==$dest) {throw new RuntimeException('Destinatário inesperado');}
    if (str_contains($a['message'],$refs[0]) || str_contains($a['message'],$refs[1])) {$correio[]=$a['subject'];}
    return true;
},900,2);
$dados=['enabled'=>true,'query'=>['report'=>'media','connection_id'=>'qa193'],'label'=>'QA','interval_minutes'=>60,'next_at'=>time()+3600,'last_code'=>'not_authorized','last_run_status'=>'failed'];
$r=\Fator3\Meta\Store::put('schedule',$agenda,$dados);
try {
    \Fator3\Meta\Worker::notify();
    F3Base_Incidentes_Provedores::meta();
    F3Base_Incidentes_Provedores::cron(['ultima_cli'=>time()-7100]);
    $dados['last_code']=null; $dados['last_run_status']='success';
    $atual=\Fator3\Meta\Store::get('schedule',$agenda);
    \Fator3\Meta\Store::put('schedule',$agenda,$dados,$atual['revision']);
    \Fator3\Meta\Worker::notify(); F3Base_Incidentes_Provedores::meta();
    F3Base_Incidentes_Provedores::cron(['ultima_cli'=>time()]);
    $origens=['linkedin','google','pipedrive','canal'];
    foreach($origens as $fonte) {F3Base_Incidentes_Provedores::$fonte();}
    foreach(['Incidente técnico · meta · agenda_parada','Recuperação técnica · meta · agenda_parada','Incidente técnico · core · cron_sem_passagem','Recuperação técnica · core · cron_sem_passagem'] as $s){
        if(count(array_keys($correio,$s,true))!==1){throw new RuntimeException('Esperado um aviso para '.$s.'; observados '.wp_json_encode($correio));}
    }
    if($http){throw new RuntimeException('Saída HTTP inesperada');}
    echo wp_json_encode(['ok'=>true,'avisos'=>$correio,'http'=>$http,'outros_adaptadores_consultados'=>$origens],JSON_UNESCAPED_UNICODE),PHP_EOL;
} finally {
    $rr=\Fator3\Meta\Store::get('schedule',$agenda);
    if($rr){\Fator3\Meta\Store::remove('schedule',$agenda,$rr['revision']);}
}
