<?php
/** Ensaio de homologação isolado. Só no host de teste. Sem argumentos executáveis, correio ou chamadas externas. */
defined('ABSPATH') || exit;
if (wp_parse_url(home_url(),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com' && !(wp_get_environment_type()==='local' && wp_parse_url(home_url(),PHP_URL_HOST)==='core193.example.invalid')) {return;}
function f3qa193_isolar(callable $fn): array {
    global $wpdb,$wp_object_cache;
    if (wp_using_ext_object_cache()) {throw new RuntimeException('Cache externo ativo, ensaio não isolado.');}
    $real=$wpdb->options; $cache=$wp_object_cache; $tmp=$wpdb->prefix.'qa193_options';
    if (false===$wpdb->query($wpdb->prepare('CREATE TEMPORARY TABLE %i LIKE %i',$tmp,$real))) {throw new RuntimeException('Falha ao isolar options.');}
    $wpdb->query($wpdb->prepare("INSERT INTO %i SELECT * FROM %i WHERE option_name IN ('home','siteurl','timezone_string','gmt_offset','admin_email')",$tmp,$real));
    $wpdb->options=$tmp; $wp_object_cache=new WP_Object_Cache();
    try {return $fn();} finally {$wpdb->options=$real; $wp_object_cache=$cache; $wpdb->query($wpdb->prepare('DROP TEMPORARY TABLE IF EXISTS %i',$tmp));}
}
function f3qa193_agenda(): array {
    return f3qa193_isolar(static function() {
        global $wpdb,$wp_filter;
        $hooks=[]; $at=time()+900; $counts=[]; $medidas=[]; $checks=[];
        $medir=static function($h,$t,$op,$r) use (&$medidas) {if ($r==='gravado') {$medidas[]=$h;}};
        add_action('f3base_fila_agenda_medida',$medir,10,4);
        $sujar=static function($h) { if (str_starts_with($h,'f3base_qa193_')) {
            $op=wp_load_alloptions(); $op['cron']=serialize(['version'=>2]); wp_cache_set('alloptions',$op,'options');
        }};
        add_action('f3base_fila_agenda_medida',$sujar,PHP_INT_MAX);
        if (class_exists('WSAL\\WP_Sensors\\WP_System_Sensor')) {\WSAL\WP_Sensors\WP_System_Sensor::attach_cron_actions();}
        for ($i=0;$i<12;$i++) {$hooks[]='f3base_qa193_'.$i;}
        $nativos=['f3_meta_worker','f3_linkedin_worker','f3_linkedin_lead_discovery','wp_privacy_delete_old_export_files'];
        $backup=[];
        try {
            foreach (array_merge($hooks,$nativos) as $h) {
                $backup[$h]=$wp_filter[$h]??null; unset($wp_filter[$h]);
                add_action($h,static function() use (&$counts,$h) {$counts[$h]=($counts[$h]??0)+1;});
                $r=wp_schedule_single_event($at,$h,[],true); if ($r!==true) {throw new RuntimeException('Agendar '.$h.': '.(is_wp_error($r)?$r->get_error_code():'false'));}
            }
            foreach (array_merge($hooks,$nativos) as $h) {
                $r=wp_unschedule_event($at,$h,[],true);
                if ($r!==true) {throw new RuntimeException('Remover '.$h.': '.(is_wp_error($r)?$r->get_error_code():'false'));}
                do_action($h);
                $db=maybe_unserialize($wpdb->get_var($wpdb->prepare("SELECT option_value FROM %i WHERE option_name='cron'",$wpdb->options)));
                if (get_option('cron')!==$db) {throw new RuntimeException('Cache divergiu em '.$h);}
            }
            if (count($medidas)!==24 || count($counts)!==16 || array_unique(array_values($counts))!==[1] || count(_get_cron_array())!==0) {throw new RuntimeException('Contagens divergentes.');}
            return ['ok'=>true,'origem'=>F3Base_Execucoes::origem(),'ganchos_core'=>12,'nativos'=>$nativos,'escritas_medidas'=>count($medidas),'executados_uma_vez'=>count($counts),'restantes'=>count(_get_cron_array()),'run_id'=>F3Base_Execucoes::atual()['run_id']??null];
        } finally {
            foreach ($backup as $h=>$v) {if ($v===null) {unset($wp_filter[$h]);} else {$wp_filter[$h]=$v;}}
            remove_action('f3base_fila_agenda_medida',$medir,10); remove_action('f3base_fila_agenda_medida',$sujar,PHP_INT_MAX);
        }
    });
}
function f3qa193_mail(): array {
    return f3qa193_isolar(static function() {
        $to='equipe-tecnica@example.invalid'; $recebidos=[]; $http=0;
        $simular=static function($pre,$a) use (&$recebidos) {
            $recebidos[]=['to'=>$a['to'],'subject'=>$a['subject'],'segredo'=>str_contains($a['message'],'segredo-qa')];
            return true;
        };
        $rede=static function($pre) use (&$http) {++$http;return new WP_Error('qa_http','Bloqueado no ensaio');};
        add_filter('pre_wp_mail',$simular,999,2); add_filter('pre_http_request',$rede,PHP_INT_MIN);
        $config=['email'=>$to,'antecedencia_dias'=>7,'resumo_diario'=>false];
        // A leitura normal do Core usa options efetivas; o filtro só injeta o valor de teste.
        $cfg=static function() use (&$config) {return $config;};
        add_filter('pre_option_f3base_avisos_tecnicos',$cfg);
        try {
            $resultados=[];
            foreach (['meta','linkedin','google','pipedrive','canal'] as $p) {
                $e=['pacote'=>$p,'codigo'=>'integracao_indisponivel','recurso'=>'segredo-qa-'.$p,'estado'=>'aberto'];
                foreach (['aberto','aberto','recuperado','recuperado'] as $s) {
                    $e['estado']=$s;$resultados[]=apply_filters('f3base_incidente_publicar_v1',null,$e);
                }
            }
            $agora=time(); F3Base_Incidentes_Provedores::cron(['ultima_cli'=>$agora-7200]);
            F3Base_Incidentes_Provedores::cron(['ultima_cli'=>$agora-7200]);
            F3Base_Incidentes_Provedores::cron(['ultima_cli'=>$agora]);
            foreach ([8,7,1,30] as $d) {F3Base_Incidentes::vencimento('linkedin','token_vencendo','segredo-qa-exp',$agora+$d*DAY_IN_SECONDS);}
            $native=[];
            foreach (['auto_plugin_theme_update_email','auto_core_update_email','recovery_mode_email'] as $hook) {
                $v=apply_filters($hook,['to'=>'admin@example.invalid','subject'=>'QA','message'=>'teste','headers'=>[]],'fail',[],[]);
                $native[$hook]=($v['to']??'')===$to;
            }
            $ok=count($recebidos)===14 && array_values(array_unique(array_column($recebidos,'to')))===[$to] && !in_array(true,array_column($recebidos,'segredo'),true) && $http===0 && !in_array(false,$native,true);
            return ['ok'=>$ok,'emails'=>$recebidos,'http_externo'=>$http,'destino_nativos'=>$native,'resultados'=>$resultados,'destino_efetivo'=>F3Base_Alertas_Operacionais::destinatario()];
        } finally {remove_filter('pre_option_f3base_avisos_tecnicos',$cfg);remove_filter('pre_wp_mail',$simular,999);remove_filter('pre_http_request',$rede,PHP_INT_MIN);}
    });
}
function f3qa193_run(array $e): array {
    if (!current_user_can('manage_options')) {return ['ok'=>false];}
    try {
        switch ($e['ensaio']) {
        case 'lint':
            $zip=new ZipArchive();$p=WP_CONTENT_DIR.'/upgrade/f3core1930.zip';if ($zip->open($p)!==true) {throw new RuntimeException('ZIP pendente.');}
            $n=0;for ($i=0;$i<$zip->numFiles;$i++) {if (str_ends_with($zip->getNameIndex($i),'.php')) {token_get_all($zip->getFromIndex($i),TOKEN_PARSE);++$n;}}$zip->close();
            return ['ok'=>true,'php'=>PHP_VERSION,'arquivos_php'=>$n,'sha256'=>hash_file('sha256',$p)];
        case 'agenda':return f3qa193_agenda();
        case 'email':return f3qa193_mail();
        case 'cli':return ['ok'=>true,'ensaio'=>get_option('f3qa193_cli_real',null)];
        case 'limpar':delete_option('f3qa193_cli_real');return ['ok'=>true];
        case 'estado':return ['ok'=>true,'core'=>F3BASE_PLUGIN_VERSAO,'wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'instalacao'=>F3Base_Instalacao::resumo(),'contrato'=>F3Base_Config_Contrato::VERSAO,'modelos'=>array_map(static fn($k)=>F3Base_Catalogo_Aparelhos::google_play($k),['motorola one macro','jvc 2k android tv','epic android tv','25062rn2da','lm-x420'])];
        }
    } catch(Throwable $ex) {return ['ok'=>false,'erro'=>$ex->getMessage(),'arquivo'=>basename($ex->getFile()),'linha'=>$ex->getLine()];}
    return ['ok'=>false];
}
add_action('wp_abilities_api_init',static function() {F3Base_Servicos::ability('qa-core-1930','Homologação temporária do Core 1.93.0','f3qa193_run',['ensaio'=>['type'=>'string','enum'=>['lint','agenda','email','cli','estado','limpar']]],['ensaio'],false);},90);
if (defined('WP_CLI')&&WP_CLI && class_exists('WP_CLI')) {
    WP_CLI::add_hook('before_invoke:cron event run',static function() {
        if (!defined('F3BASE_PLUGIN_VERSAO') || F3BASE_PLUGIN_VERSAO!=='1.93.0' || get_option('f3qa193_cli_real',false)) {return;}
        try {$r=f3qa193_agenda();} catch(Throwable $ex) {$r=['ok'=>false,'erro'=>$ex->getMessage()];}
        update_option('f3qa193_cli_real',$r+['em'=>time()],false);
    });
}
