# Fator3 Site Core 1.85.1

Versão 1.85.1. Normalização de telefone e e-mail na captura. Consulte docs/RELEASE-1.85.1.md.

Instalação nova ou atualização da 1.85.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
