# Fator3 Site Core 1.85.1 — leia primeiro

Versão 1.85.1. Normalização de telefone e e-mail na captura. Consulte RELEASE-1.85.1.md.

Instalação nova ou atualização da 1.85.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

## Requisitos (cabeçalho do plugin)

- WordPress 7.1.4 ou superior.
- PHP 8.3 ou superior, de 64 bits. Abaixo disso o plugin fica inerte e mostra um aviso no painel.
- Instalação única, sem multisite.

## Por onde começar

1. Abra DOCUMENTACAO.md. Ele lista todos os documentos instalados e diz quando ler cada um.
2. Para operar por MCP, leia AGENTES-1.85.1.md e consulte REFERENCIA-ABILITIES.md.
3. Para saber o que mudou nesta versão, leia RELEASE-1.85.1.md.
4. Para configurar pelo painel, leia GUIA-PAINEL.md.

## Como ler a documentação instalada

- Painel: a tela Configurações do Site Core exibe o guia GUIA-PAINEL.md (`F3Base_Configuracoes_Hub::guia`). Os demais arquivos não têm tela própria.
- MCP: ability `f3base/documentacao-ler`. Sem argumentos, devolve versão, índice e a lista exata de arquivos legíveis. Com `arquivo`, `linha` e `limite` (até 200 linhas; padrão 120), devolve uma página, o `sha256` do arquivo inteiro e `proxima_linha`. Continue até `proxima_linha` ser nulo.
- A leitura é estática: não faz HTTP, não grava configuração e não repara agenda.

Os arquivos com versão no nome (por exemplo `GSC-1.34.md`, `AGENTES-1.78.0.md`) seguem a convenção explicada em DOCUMENTACAO.md. Só `AGENTES-1.85.1.md` e `RELEASE-1.85.1.md` descrevem esta release; os demais guias e notas por versão são histórico.
