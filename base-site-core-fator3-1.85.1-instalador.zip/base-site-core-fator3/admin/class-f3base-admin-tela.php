<?php
/**
 * Tela do wp-admin do Fator3 Site Core.
 *
 * PARA QUEM ESTA TELA É ESCRITA. Para quem opera o site — a pessoa que precisa
 * ligar o WhatsApp, conectar a conta de anúncio, decidir o prazo de guarda e
 * saber se alguém está lendo as páginas. Até a 1.1.3 ela era escrita para quem
 * construiu o pacote: abria falando em registro único de módulos, apresentava
 * as chaves na ordem em que elas foram escritas no catálogo, e mostrava o
 * diagnóstico antes dos campos. Quem chegava para preencher um número lia
 * primeiro um relatório de estado interno.
 *
 * O QUE MUDOU, e por quê:
 *
 * 1. **Primeiro o que se preenche, depois o que se observa.** Os campos vêm
 *    antes; o quadro de comportamento e o diagnóstico dos módulos vêm depois.
 * 2. **Agrupado por assunto, na ordem de instalação de um site:** contato,
 *    medição e anúncios, consentimento, privacidade e retenção. A ordem é
 *    declarada em `F3Base_Options::secoes_da_tela()`, num lugar só, porque ela
 *    é conferida no DOM.
 * 3. **Cada campo diz o IMPACTO e traz um EXEMPLO.** Rótulo é o nome do campo;
 *    descrição é a definição dele. Nenhum dos dois responde à única pergunta de
 *    quem está com o cursor no campo: o que muda no site se eu preencher isto,
 *    e o que acontece enquanto está vazio.
 * 4. **O exemplo NUNCA entra no campo.** Nem em `value`, nem em `placeholder`:
 *    exemplo em placeholder é valor fantasma — o operador o lê como se
 *    estivesse gravado, sai da tela achando que configurou, e a conta continua
 *    sem receber nada.
 * 5. **O diagnóstico continua inteiro.** Módulos, estados, motivos, avisos,
 *    dependências, hooks e options: nada saiu. Ele é o que o suporte e o agente
 *    leem, e é o que responde "por que isto não está funcionando". Só deixou de
 *    ser a primeira coisa que aparece.
 *
 * O QUE NÃO MUDOU, porque é o que garante a verdade da tela: ela continua sendo
 * renderizada a partir do registro único de módulos e do catálogo de options —
 * nunca de lista escrita à mão —, a gravação continua exigindo `manage_options`
 * e nonce, e o valor gravado continua sendo RELIDO do banco e confirmado.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Página de administração do site-core.
 */
final class F3Base_Admin_Tela {

	/**
	 * Slug da página.
	 */
	public const SLUG = 'base-site-core-fator3';

	/**
	 * Ação do formulário.
	 */
	public const ACAO = 'f3base_salvar';

	/**
	 * Nonce do formulário.
	 */
	public const NONCE = 'f3base_salvar_options';

	/**
	 * Blocos de OBSERVAÇÃO da tela, depois dos blocos de preenchimento.
	 */
	public const BLOCO_COMPORTAMENTO = 'comportamento';
	public const BLOCO_DIAGNOSTICO   = 'diagnostico';

	/** Rascunhos não secretos recuperados após conflito, somente nesta renderização. */
	private static array $rascunhos = array();
    private static array $erros = array();

	/**
	 * A ORDEM DOS BLOCOS DA TELA, declarada num lugar só.
	 *
	 * Os blocos de preenchimento saem de `F3Base_Options::secoes_da_tela()`, na
	 * ordem declarada lá; os dois de observação vêm depois, nesta ordem. Esta
	 * função é a fonte que a tela renderiza E que a bancada mede no DOM: duas
	 * listas seriam duas ordens, e a segunda envelheceria calada.
	 *
	 * @return string[]
	 */
	public static function ordem_dos_blocos(): array {
		return array_merge(
			array_keys( F3Base_Options::secoes_da_tela() ),
			array( self::BLOCO_COMPORTAMENTO, self::BLOCO_DIAGNOSTICO )
		);
	}

	/**
	 * Liga a tela.
	 *
	 * @return void
	 */
	public static function iniciar(): void {
		add_action( 'admin_menu', array( __CLASS__, 'registrar_menu' ) );
		add_action( 'admin_post_' . self::ACAO, array( __CLASS__, 'salvar' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enfileirar' ) );add_action('wp_ajax_f3base_email_simular',[F3Base_Email_Contato::class,'simular_painel']);add_action('wp_ajax_f3base_form_renovar',array(F3Base_Admin_Entrada::class,'renovar'));
		add_action( 'admin_enqueue_scripts', static function (): void { if ( ( $_GET['page'] ?? '' ) === self::SLUG ) { wp_enqueue_script( 'f3base-admin1120', F3BASE_PLUGIN_URL . 'admin/assets/f3base-admin1120.js', array(), F3BASE_PLUGIN_VERSAO, true ); } } );
		add_filter( 'plugin_action_links_' . plugin_basename( F3BASE_PLUGIN_ARQUIVO ), array( __CLASS__, 'links_de_acao' ) );
	}

	/** Atalho na linha deste plugin, respeitando a mesma permissão da tela. */
	public static function links_de_acao( array $links ): array {
		if ( current_user_can( 'manage_options' ) ) {
			array_unshift( $links, '<a href="' . esc_url( add_query_arg( 'page', self::SLUG, admin_url( 'admin.php' ) ) ) . '">' . esc_html__( 'Configurações', 'f3base' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * Registra o menu.
	 *
	 * @return void
	 */
	public static function registrar_menu(): void {
		add_menu_page(
			__( 'Fator3 Site Core', 'f3base' ),
			__( 'Site Core', 'f3base' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-shield-alt',
			58
		);
		// O núcleo usa o primeiro submenu como destino do menu principal.
		// A configuração precisa preceder também o CPT de leads sem Flamingo.
		add_submenu_page(
			self::SLUG,
			__( 'Fator3 Site Core', 'f3base' ),
			__( 'Configurações', 'f3base' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render' ),
			0
		);
	}

	/**
	 * Enfileira o estilo da tela.
	 *
	 * @param string $tela Hook da tela atual.
	 * @return void
	 */
	public static function enfileirar( string $tela ): void {
		// O submenu Operação (f3base-operacao) desenha esta mesma tela e precisa da mesma folha.
		if ( 'toplevel_page_' . self::SLUG !== $tela && 'f3base-operacao' !== ( $_GET['page'] ?? '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Só escolhe a folha de estilo.
			return;
		}

		wp_enqueue_style(
			'f3base-admin',
			F3BASE_PLUGIN_URL . 'admin/assets/f3base-admin.css',
			array(),
			F3BASE_PLUGIN_VERSAO
		);
	}

	/**
	 * Trata o envio do formulário.
	 *
	 * @return void
	 */
	public static function salvar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para editar as options do site-core.', 'f3base' ), 403 );
		}

		check_admin_referer( self::NONCE );

		$enviado = isset( $_POST['f3base'] ) && is_array( $_POST['f3base'] )
			? wp_unslash( $_POST['f3base'] )
			: array();

		/*
		 * A CAIXA DE APAGAR VIAJA SEPARADA do valor, e é ela que dá ao operador
		 * a única ação que um campo mascarado não consegue expressar: ESVAZIAR.
		 * No campo de segredo, vazio significa "mantenha o que está gravado" —
		 * sem isso, abrir a tela e gravar qualquer outra coisa apagaria o token,
		 * porque o valor nunca é reimpresso no formulário.
		 */
		$apagar = isset( $_POST['f3base_apagar'] ) && is_array( $_POST['f3base_apagar'] )
			? array_map( 'sanitize_key', array_keys( map_deep( wp_unslash( $_POST['f3base_apagar'] ), 'sanitize_key' ) ) )
			: array();

		$revisoes  = isset( $_POST['f3base_revisao'] ) && is_array( $_POST['f3base_revisao'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['f3base_revisao'] ) ) : array();
		if (!is_string($_POST['secao'] ?? null) || !F3Base_Interface::valida($_POST['secao'])) { wp_die('Seção inválida. Reabra a configuração.',400); }
        $subaba=F3Base_Interface::aba($_POST['secao']);
        if(!F3Base_Interface::permitir_envio($enviado,$subaba)){wp_die('Há campos de outra sub-aba ou não autorizados. Reabra a configuração e tente novamente.',400);}
        $contexto=is_string($_POST['f3base_contexto']??null)?sanitize_text_field(wp_unslash($_POST['f3base_contexto'])):'';
        $fim=is_string($_POST['f3base_fim']??null)?sanitize_text_field(wp_unslash($_POST['f3base_fim'])):'';
        $leituras=self::processar_envio($enviado,$revisoes,$apagar,$contexto,$subaba,$fim);
        $rascunhos=array();$falhou=(bool)array_filter($leituras,static fn($l)=>empty($l['persisted']));
        if($falhou){
            if ($subaba === 'medicao-meta') {
                $falhas = array_column(array_filter($leituras, static fn($l) => empty($l['persisted'])), 'nome');
                $enviado = array_intersect_key($enviado, array_flip($falhas));
            }
            foreach($enviado as $nome=>$v){if(!F3Base_Options::e_segredo($nome)&&strlen((string)wp_json_encode($v))<=32768){$rascunhos[$nome]=$v;}}}
        $retorno=wp_generate_uuid4();
        set_transient('f3base_retorno_'.$retorno,array('usuario'=>get_current_user_id(),'area'=>$subaba,'rascunhos'=>$rascunhos,'leituras'=>$leituras),10*MINUTE_IN_SECONDS);
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'         => self::SLUG,
					'f3base-salvo' => $retorno,
                    'secao' => $subaba,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/** Salva cada option condicionalmente; a seção pode ter resultado parcial. */
    public static function processar_envio(array $enviado,array $revisoes,array $apagar=array(),string $contexto='',string $area='',string $fim=''): array {
        return F3Base_Admin_Entrada::processar($enviado,$revisoes,$apagar,$contexto,$area,$fim);
    }

	/**
	 * Renderiza a tela.
	 *
	 * @return void
	 */
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Sem permissão para ver a tela do site-core.', 'f3base' ), 403 );
		}

		$aba_atual = in_array( $_GET['aba'] ?? '', array( 'tecnica', 'operacao' ), true ) ? $_GET['aba'] : 'configuracoes';
		$tecnica = 'tecnica' === $aba_atual;

		echo '<div class="wrap f3base-tela f3base-tela--configuracoes f3base-tela--' . esc_attr( $aba_atual ) . '">';

		/*
		 * CABEÇALHO NUM BLOCO SÓ (1.79.0): título, versão e abas. O `hr.wp-header-end`
		 * vem depois do bloco porque é ali que o common.js do núcleo reposiciona os
		 * avisos; sem ele, o aviso entrava entre o título e as abas.
		 */
		echo '<div class="f3base-cabecalho">';
		printf(
			'<h1>%s <span class="f3base-versao">%s</span></h1>',
			esc_html__( 'Fator3 Site Core', 'f3base' ),
			esc_html( F3BASE_PLUGIN_VERSAO )
		);

		echo '<nav class="nav-tab-wrapper f3base-abas" aria-label="' . esc_attr( __( 'Áreas do plugin', 'f3base' ) ) . '">';
		foreach ( array(
			'configuracoes' => __( 'Configurações', 'f3base' ),
			'tecnica'       => __( 'Informações técnicas', 'f3base' ),
			'operacao'      => __( 'Operação', 'f3base' ),
		) as $aba => $rotulo ) {
			$ativa = $aba_atual === $aba;
			printf(
				'<a class="nav-tab%s" href="%s"%s>%s</a>',
				$ativa ? ' nav-tab-active' : '',
				esc_url(
					add_query_arg(
						array(
							'page' => self::SLUG,
							'aba'  => $aba,
						),
						admin_url( 'admin.php' )
					)
				),
				$ativa ? ' aria-current="page"' : '',
				esc_html( $rotulo )
			);
		}
		echo '</nav></div><hr class="wp-header-end">';

		if ( 'operacao' === $aba_atual ) {
			echo F3Base_Config_UI::ids_unicos( self::capturar_saida( static function (): void {
				echo '<div class="f3base-principal">';
				if ( ( $_GET['fila'] ?? '' ) === 'entregas' ) {
					F3Base_Integracoes::entregas();
				} elseif ( ( $_GET['fila'] ?? '' ) === 'avisos' ) {
					F3Base_Avisos::fila_tela();
				} else {
					echo '<p><a class="button" href="' . esc_url( add_query_arg( 'fila', 'entregas' ) ) . '">Entregas ao Pipedrive</a> <a class="button" href="' . esc_url( add_query_arg( 'fila', 'avisos' ) ) . '">Avisos à equipe</a></p>';
					F3Base_Admin_Saude::render_execucoes();
					F3Base_Servicos::tela();
				}
				echo '</div>';
			} ), true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML já escapado pelos renderizadores; só os ids repetidos são renomeados.
			echo '</div>';
			return;
		}
		if ( $tecnica ) {
			self::render_tecnica();
			echo '</div>';
			return;
		}

		printf(
			'<p class="f3base-intro">%s</p>',
			esc_html__( 'Use as áreas abaixo para configurar o site. Filas e tarefas ficam em Operação.', 'f3base' )
		);

		$ativa = F3Base_Interface::aba( $_GET['secao'] ?? null );
		F3Base_Configuracoes_Hub::navegar( $ativa );
		self::render_leitura_de_volta();
		$html = F3Base_Config_UI::html( self::capturar_saida( static function () use ( $ativa ): void {
			self::render_formulario();
			F3Base_Config_UI::central_tela( $ativa );
			F3Base_Config_UI::complementos( $ativa );
		} ) );
		echo self::layout( $html, $ativa ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Conteúdo já escapado na origem; o índice é montado com esc_html/esc_attr.
		/*
		 * O QUADRO DE MEDIÇÃO SAIU DAQUI na 1.1.0 e virou o menu Medição. Ficou
		 * o caminho, e não uma cópia menor dele: duas telas somando os mesmos
		 * números divergiriam na primeira vez que uma das duas mudasse de
		 * período.
		 */
		// Relatórios têm entrada própria no menu Site Core.

		echo '</div>';
	}

	/* ------------------------------------------------------------------ *
	 * Layout da área (1.79.0)
	 * ------------------------------------------------------------------ */

	/** Captura a saída de um renderizador; uma exceção atravessa sem deixar buffer aberto. */
	private static function capturar_saida( callable $render ): string {
		ob_start();
		try {
			$render();
		} catch ( Throwable $e ) {
			ob_end_clean();
			throw $e;
		}
		return (string) ob_get_clean();
	}

	/**
	 * Conteúdo da área com o índice dos grupos.
	 *
	 * O índice é montado no servidor a partir dos próprios blocos impressos —
	 * cada um declara `id` e `data-f3base-indice` —, de modo que um link do
	 * índice não existe sem o alvo correspondente. A partir de 1200 px a folha o
	 * coloca ao lado do conteúdo; abaixo disso ele fica no topo, num `details`.
	 */
	private static function layout( string $html, string $ativa ): string {
		$html    = self::marcar_secoes( $html );
		$itens   = 'inicio' === $ativa ? array() : self::itens_do_indice( $html );
		$html    = F3Base_Config_UI::ids_unicos( $html );
		$classes = 'f3base-layout' . ( str_contains( $html, 'class="f3base-savebar"' ) ? ' f3base-layout--barra' : '' );
		if ( array() === $itens ) {
			return '<div class="' . esc_attr( $classes ) . ' f3base-layout--sem-indice"><div class="f3base-layout-conteudo">' . $html . '</div></div>';
		}
		return '<div class="' . esc_attr( $classes ) . '">' . self::indice( $itens, __( 'Grupos desta área', 'f3base' ), __( 'Nesta área', 'f3base' ) ) . '<div class="f3base-layout-conteudo">' . $html . '</div></div>';
	}

	/**
	 * Dá âncora e entrada no índice aos blocos que outras classes imprimem na
	 * área (prévias, formulários de retenção, grupos de Conexões). O `id` sai do
	 * título do bloco: estável entre cargas e legível no endereço.
	 */
	private static function marcar_secoes( string $html ): string {
		$usados = array();
		return (string) preg_replace_callback(
			'~<(details|section)\b([^>]*\bclass="(?:f3base-config-grupo|f3base-secao)\b[^"]*"[^>]*)>(\s*)<(summary|h2)>(.*?)</\4>~s',
			static function ( array $m ) use ( $html, &$usados ): string {
				if ( preg_match( '/\s(?:id|data-f3base-indice)=/', $m[2] ) ) {
					return $m[0];
				}
				$titulo = trim( html_entity_decode( wp_strip_all_tags( $m[5] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
				if ( '' === $titulo ) {
					return $m[0];
				}
				$base = 'grupo-' . sanitize_title( $titulo );
				$id   = $base;
				for ( $n = 2; isset( $usados[ $id ] ) || str_contains( $html, 'id="' . $id . '"' ); ++$n ) {
					$id = $base . '-' . $n;
				}
				$usados[ $id ] = true;
				return '<' . $m[1] . ' id="' . esc_attr( $id ) . '" data-f3base-indice="' . esc_attr( $titulo ) . '"' . $m[2] . '>' . $m[3] . '<' . $m[4] . '>' . $m[5] . '</' . $m[4] . '>';
			},
			$html
		);
	}

	/**
	 * Entradas do índice na ordem do documento.
	 *
	 * @return array<int,array{id:string,titulo:string,nivel:int}>
	 */
	private static function itens_do_indice( string $html ): array {
		$itens = array();
		if ( ! preg_match_all( '~<[a-z][a-z0-9]*\b([^>]*\bdata-f3base-indice="[^"]*"[^>]*)>~', $html, $tags ) ) {
			return $itens;
		}
		foreach ( $tags[1] as $atributos ) {
			if ( ! preg_match( '/\sid="([^"]+)"/', ' ' . $atributos, $id ) || ! preg_match( '/\bdata-f3base-indice="([^"]*)"/', $atributos, $titulo ) ) {
				continue;
			}
			$itens[] = array(
				'id'     => html_entity_decode( $id[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
				'titulo' => html_entity_decode( $titulo[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
				'nivel'  => str_contains( $atributos, 'data-f3base-indice-nivel="2"' ) && array() !== $itens ? 2 : 1,
			);
		}
		return $itens;
	}

	/**
	 * O índice: lista de links dentro de um `details` aberto por padrão. Em
	 * telas estreitas o JavaScript o recolhe ao carregar; sem JavaScript ele
	 * continua recolhível pelo próprio `summary`.
	 *
	 * @param array<int,array{id:string,titulo:string,nivel:int}> $itens Entradas.
	 */
	private static function indice( array $itens, string $nome, string $titulo ): string {
		$lista  = '';
		$aberto = false;
		foreach ( $itens as $i => $item ) {
			$link = '<a href="#' . esc_attr( $item['id'] ) . '">' . esc_html( $item['titulo'] ) . '</a>';
			if ( 2 === $item['nivel'] ) {
				$lista .= ( $aberto ? '' : '<ul>' ) . '<li>' . $link . '</li>';
				$aberto = true;
				continue;
			}
			$lista .= ( $aberto ? '</ul>' : '' ) . ( $i > 0 ? '</li>' : '' ) . '<li>' . $link;
			$aberto = false;
		}
		$lista .= ( $aberto ? '</ul>' : '' ) . '</li>';
		return '<nav class="f3base-indice" aria-label="' . esc_attr( $nome ) . '"><details class="f3base-indice-caixa" open data-f3base-indice-caixa><summary>' . esc_html( $titulo ) . '</summary><p class="f3base-indice-titulo">' . esc_html( $titulo ) . '</p><ul class="f3base-indice-lista">' . $lista . '</ul></details></nav>';
	}

	/* ------------------------------------------------------------------ *
	 * Informações técnicas (1.79.0)
	 * ------------------------------------------------------------------ */

	/**
	 * Abre uma seção recolhível de Informações técnicas.
	 *
	 * Até a 1.78.0 a aba despejava tudo aberto — 62 mil px em 1440 px. Agora cada
	 * seção é um `details` com resumo; só o estado operacional abre por padrão.
	 */
	public static function abrir_secao_tecnica( string $id, string $titulo, string $resumo, bool $aberta = false, string $classe = '' ): string {
		return sprintf(
			'<details class="f3base-tecnica-secao%1$s" id="%2$s" data-f3base-indice="%3$s"%4$s><summary><span class="f3base-tecnica-titulo">%5$s</span> <span class="f3base-tecnica-resumo">%6$s</span></summary><div class="f3base-tecnica-corpo">',
			'' !== $classe ? ' ' . esc_attr( $classe ) : '',
			esc_attr( 'tecnica-' . $id ),
			esc_attr( $titulo ),
			$aberta ? ' open' : '',
			esc_html( $titulo ),
			esc_html( $resumo )
		);
	}

	/** Fecha a seção aberta por abrir_secao_tecnica(). */
	public static function fechar_secao_tecnica(): string {
		return '</div></details>';
	}

	/** A aba Informações técnicas: seções recolhidas e um índice no topo. */
	private static function render_tecnica(): void {
		$saude = F3Base_Saude::resumo();
		$html  = self::capturar_saida( static function () use ( $saude ): void {
			F3Base_Admin_Saude::render( $saude );
			echo self::abrir_secao_tecnica( 'cache', 'Cache e entrega pública', 'Configuração do cache, cabeçalhos públicos, tokens e verificação da entrega ao visitante.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			self::render_cache();
			echo self::fechar_secao_tecnica(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::abrir_secao_tecnica( 'modulos', 'Módulos e registros técnicos', 'Estado de cada módulo, motivos, dependências, ganchos, avisos e options.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			self::render_diagnostico( F3Base_Registro::relatorio() );
			echo self::fechar_secao_tecnica(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::abrir_secao_tecnica( 'fila-conversoes', 'Fila de conversões', 'Situação da fila de conversões enviadas pelo servidor.' ) . '<pre>' . esc_html( (string) wp_json_encode( $saude['fila'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>' . self::fechar_secao_tecnica(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo self::abrir_secao_tecnica( 'tentativas', 'Tentativas de configuração recusadas', 'Gravações recusadas pelo validador, sem os valores enviados.' ) . '<p>As recusas não alteram a procedência da configuração persistida. Este registro não inclui os valores enviados.</p><pre>' . esc_html( (string) wp_json_encode( get_option( F3Base_Options::OPTION_TENTATIVAS, array() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>' . self::fechar_secao_tecnica(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} );
		$itens = self::itens_do_indice( $html );
		echo '<div class="f3base-layout f3base-layout--topo">' . self::indice( $itens, __( 'Seções de Informações técnicas', 'f3base' ), __( 'Seções desta aba', 'f3base' ) ) . '<div class="f3base-layout-conteudo">' . F3Base_Config_UI::ids_unicos( $html, true ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Conteúdo já escapado na origem.
	}

	/* ------------------------------------------------------------------ *
	 * Leitura de volta
	 * ------------------------------------------------------------------ */

	/**
	 * Leitura de volta da última gravação.
	 *
	 * @return void
	 */
	/** Operações explícitas do cache não regravam as preferências do formulário. */
	private static function render_cache( ?array $resumo = null ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return; }
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['f3base_cache_acao'] ) ) {
			$resumo = null; // Ações sempre conferem o resultado após executar, sem reutilizar a leitura anterior.
			check_admin_referer( 'f3base_cache_operacao' );
			$acao    = is_string( $_POST['f3base_cache_acao'] ) ? sanitize_key( wp_unslash( $_POST['f3base_cache_acao'] ) ) : '';
			$revisao = is_string( $_POST['f3base_cache_revisao'] ?? null ) ? wp_unslash( $_POST['f3base_cache_revisao'] ) : '';
			if ( ! hash_equals( F3Base_Options::revisao( 'f3base_cabecalhos' ), $revisao ) ) {
				$acao = '';
				echo '<div class="notice notice-warning inline"><p>A configuração mudou. Confira o estado atualizado antes de repetir a operação.</p></div>'; }
			if ( 'limpar' === $acao ) {
				$ok = F3Base_Cache_Pagina::solicitar() && ! empty( F3Base_Cache_Pagina::limpar()['ok'] );
				echo '<div class="notice notice-' . ( $ok ? 'success' : 'warning' ) . ' inline"><p>' . esc_html( $ok ? 'Limpeza solicitada ao provedor. A confirmação pública aparece abaixo.' : 'A limpeza permanece pendente. Confira o provedor do cache.' ) . '</p></div>';
			}
			if ( in_array( $acao, array( 'limpar', 'verificar' ), true ) ) {
				$sonda = F3Base_Cache_Pagina::verificar_publico( 'limpar' === $acao ? 'atualizar_cache' : 'verificar_publico' );
				if ( empty( $sonda['persisted'] ) ) {
					echo '<div class="notice notice-warning inline"><p>' . esc_html( $sonda['motivo'] ) . '</p></div>'; }
			}
		}
		$r          = $resumo ?? F3Base_Cache_Pagina::resumo();
		$publicacao = F3Base_Llms::responsaveis();
		echo '<p>A configuração salva e a resposta entregue ao visitante são verificadas separadamente.</p>';
		echo '<table class="widefat striped"><tbody>';
		$linhas = array(
			'Cache de página'                       => $r['perfil']['provedor'] . ' — ' . $r['perfil']['modo'],
			'Perfil exigido do cache'               => 'not_required' === $r['requisitos']['status'] ? 'WP Super Cache inativo; requisitos disponíveis para configuração.' : ( 'verified' === $r['requisitos']['status'] ? 'Configuração conferida. A prova de HIT é separada.' : 'Configuração divergente. Confira as entradas faltantes abaixo.' ),
			'Exclusões não encontradas'             => $r['perfil']['ativo'] && $r['requisitos']['exclusoes']['faltantes'] ? implode( ', ', $r['requisitos']['exclusoes']['faltantes'] ) : 'Nenhuma pendência aplicável.',
			'Rastreamento e chave do cache'         => ( $r['requisitos']['rastreamento']['ativado'] ? 'Ignorar parâmetros está ativado.' : 'Ignorar parâmetros está desativado.' ) . ( $r['requisitos']['rastreamento']['faltantes'] ? ' Faltam: ' . implode( ', ', $r['requisitos']['rastreamento']['faltantes'] ) . '.' : '' ) . ( $r['requisitos']['rastreamento']['proibidos_presentes'] ? ' Remova ref da lista de parâmetros ignorados.' : '' ),
			'Atualização do cache'                  => ! empty( $r['estado']['pendente'] ) ? 'Pendente' : 'Sem limpeza pendente',
			'Cabeçalhos públicos'                   => $r['verification']['motivo'],
            'Acesso direto ao cache' => isset( $r['evidencia']['artefato_cache'] ) ? ( $r['evidencia']['artefato_cache']['status'] . ' — ' . $r['evidencia']['artefato_cache']['codigo'] . ' — HTTP ' . $r['evidencia']['artefato_cache']['http'] . ', corpo ' . $r['evidencia']['artefato_cache']['bytes'] . ' bytes' ) : 'Ainda não verificado: é exigido corpo vazio.',
			'Situação da geração atual'             => $r['verification']['status'] . ' — ' . $r['verification']['codigo'],
			'Última tentativa registrada'           => $r['historico']['ultima_verificacao'] ? wp_date( 'd/m/Y H:i:s', $r['historico']['ultima_verificacao'] ) . ' — ' . $r['historico']['ultima_tentativa']['origem'] : 'Sem histórico disponível',
			'Última verificação bem-sucedida'       => $r['historico']['ultima_verificacao_bem_sucedida'] ? wp_date( 'd/m/Y H:i:s', $r['historico']['ultima_verificacao_bem_sucedida'] ) . ( $r['historico']['valida_geracao_atual'] ? ' — válida para a geração atual' : ' — histórica; não valida a geração atual' ) : 'Sem sucesso registrado',
			'Última limpeza solicitada ao provedor' => $r['estado']['limpo_em'] ? wp_date( 'd/m/Y H:i:s', $r['estado']['limpo_em'] ) : 'Sem limpeza registrada',
			'Agendador'                             => $r['agendamento']['codigo'] . ( $r['agendamento']['disparo_por_visitas'] ? ' — disparo por visitas habilitado' : ' — disparo por visitas desabilitado; conferir cron do servidor' ),
			'Próxima verificação'                   => $r['proxima_verificacao'] ? wp_date( 'd/m/Y H:i:s', $r['proxima_verificacao'] ) : 'Sem agendamento',
			'SEO e sitemap'                         => $publicacao['seo'] . ' — ' . ( $publicacao['sitemap']['url'] ?: 'Sitemap desativado' ),
			'llms.txt'                              => $publicacao['llms']['motivo'],
		);
        $tokens=$r['tokens']??array();
        if(!is_array($tokens)||isset($tokens['evidencia_ref'])){$linhas['Tokens públicos']='Evidência indisponível neste formato.';$tokens=array();}
        foreach($tokens as $modulo=>$token){
            $valido=is_array($token)&&is_string($token['status']??null)&&is_array($token['problemas']??null)&&!array_filter($token['problemas'],static fn($v)=>!is_string($v));
            $linhas['Token público — '.$modulo]=!$valido?'Evidência incompleta ou indisponível.':($token['status']==='verified'?'Token confirmado: resposta renovada e sem armazenamento em cache.'.(($r['verification']['status']??'')==='verified'?' Verificação geral confirmada.':' A verificação geral dos cabeçalhos ainda está pendente.'):(($token['status']==='failed'?'Prova individual reprovada':'Prova individual pendente').($token['problemas']?': '.implode(', ',$token['problemas']):'. Ainda sem prova completa.')));
        }
		foreach ( $linhas as $nome => $valor ) {
			echo '<tr><th scope="row">' . esc_html( $nome ) . '</th><td>' . esc_html( $valor ) . '</td></tr>'; }
		echo '</tbody></table><form method="post" class="f3base-acoes">';
		echo '<input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( 'f3base_cache_operacao' ) ) . '">';
		wp_referer_field();
		echo '<input type="hidden" name="f3base_cache_revisao" value="' . esc_attr( F3Base_Options::revisao( 'f3base_cabecalhos' ) ) . '">';
		echo '<p><button class="button button-primary" name="f3base_cache_acao" value="verificar">Verificar entrega pública</button> <button class="button" name="f3base_cache_acao" value="limpar">Atualizar cache</button></p></form>';
		echo '<p class="description">Abrir esta tela apenas consulta o estado. A verificação faz duas leituras anônimas da home e duas por rota de token ativa, mais uma leitura do artefato elegível de cache, até sete no total. Há intervalo mínimo entre tentativas e espera progressiva após falhas. Após a limpeza, a mesma tarefa é antecipada; o agendamento depende de execução pelo WordPress ou cron do servidor. O histórico é preservado mesmo quando deixa de valer para a geração atual.</p>';
		echo '<details class="f3base-ajuda"><summary>Evidências e exclusões para configurar o cache</summary><pre>' . esc_html( wp_json_encode( $r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details>';
	}

    private static function render_leitura_de_volta(): void {
        self::$rascunhos=array();self::$erros=array();$id=$_GET['f3base-salvo']??'';
        if(!is_string($id)||!preg_match('/^[a-f0-9-]{36}$/D',$id)){return;}
        $r=get_transient('f3base_retorno_'.$id);
        if(!is_array($r)||$r['usuario']!==get_current_user_id()||$r['area']!==F3Base_Interface::aba($_GET['secao']??null)){return;}
        self::$rascunhos=$r['rascunhos'];$leituras=$r['leituras'];
        foreach($leituras as $l){if(empty($l['persisted'])){self::$erros[$l['nome']][]=$l;}}
        $aviso=self::confirmacao($leituras);
        echo '<div class="f3base-leitura notice notice-'.esc_attr($aviso['nivel']).'" role="status"><p>'.esc_html($aviso['mensagem']).'</p>';
        if(self::$erros){echo '<ul>';foreach($leituras as $l){if(empty($l['persisted'])){echo '<li><a href="#linha-'.esc_attr($l['nome']).'">'.esc_html($l['rotulo']).'</a>: '.esc_html($l['motivo']).'</li>';}}echo '</ul>';}
        echo '</div>';
    }

	/** Confirma persistência sem publicar valores nem tratar falhas como sucesso. */
	public static function confirmacao( array $leituras ): array {
        if(!$leituras){return array('nivel'=>'info','mensagem'=>'Nenhuma alteração para salvar.');}
		$falhas         = array();
		$salvas         = array();
		$efeitos        = array();
		$cache_pendente = false;
		foreach ( $leituras as $l ) {
			if ( ! empty( $l['persisted'] ) ) {
				$salvas[] = (string) $l['rotulo']; }
			$cache_pendente = $cache_pendente || 'cache_agendado' === ( $l['effect']['codigo'] ?? '' );
			if ( empty( $l['persisted'] ?? $l['ok'] ?? false ) ) {
				$falhas[] = (string) $l['rotulo'] . ': ' . (string) ($l['motivo'] ?? 'Confira o campo.'); } elseif ( 'failed' === ( $l['effect']['status'] ?? '' ) || 'failed' === ( $l['verification']['status'] ?? '' ) ) {
				$efeitos[] = (string) $l['rotulo']; }
		}
		if ( $falhas ) {
			return array(
				'nivel'    => 'error',
				'mensagem' => sprintf( __( 'Não foi possível salvar: %s. Revise esses campos e tente novamente.', 'f3base' ), implode( ', ', $falhas ) ) . ( $salvas ? ' Salvas: ' . implode( ', ', $salvas ) . '.' : '' ),
			); }
		if ( $efeitos ) {
			return array(
				'nivel'    => 'warning',
				'mensagem' => sprintf( __( 'Configurações salvas. Há falhas de funcionamento em: %s. Consulte a aba Informações técnicas.', 'f3base' ), implode( ', ', $efeitos ) ),
			); }
		return array(
			'nivel'    => 'success',
			'mensagem' => count($salvas)===1&&($leituras[0]['nome']??'')==='f3base_gtm_container_id'?'Google Tag Manager: contêiner salvo.':'Salvas: '.implode(', ',$salvas).'.'.($cache_pendente?' Verificação do cache pendente.':''),
		);
	}

	/** A preferência pode estar gravada mesmo quando seu efeito falhou. */
	public static function rotulo_da_gravacao( array $leitura ): string {
		if ( empty( $leitura['persisted'] ?? $leitura['ok'] ?? false ) ) {
			return __( 'configuração não gravada', 'f3base' ); }
		if ( 'failed' === ( $leitura['effect']['status'] ?? '' ) ) {
			return __( 'configuração gravada; falha ao aplicar o efeito', 'f3base' ); }
		if ( 'failed' === ( $leitura['verification']['status'] ?? '' ) ) {
			return __( 'configuração gravada; verificação do comportamento reprovada', 'f3base' ); }
		if ( ! empty( $leitura['verification']['pending'] ) ) {
			return __( 'configuração gravada; verificação do comportamento pendente', 'f3base' ); }
		return __( 'configuração gravada e conferida', 'f3base' );
	}

	/* ------------------------------------------------------------------ *
	 * Formulário, agrupado por assunto
	 * ------------------------------------------------------------------ */

	/**
	 * O formulário inteiro, um bloco por seção declarada.
	 *
	 * @return void
	 */
	private static function render_formulario(): void {
		$secoes    = F3Base_Interface::secoes();
        $ativa=F3Base_Interface::aba($_GET['secao']??null);
        if($ativa==='inicio'){F3Base_Configuracoes_Hub::inicio();return;}
        if($ativa==='conexoes'){F3Base_Integracoes::render();return;}
		$por_secao = array();

		foreach ( F3Base_Options::catalogo() as $nome => $declaracao ) {
			if ( $nome==='f3base_retencao_meses' || ! F3Base_Options::operavel( (string) $nome ) ) {
				continue;
			}

			$secao = F3Base_Interface::grupo((string)$nome,$declaracao);

			if ( ! isset( $secoes[ $secao ] ) ) {
				continue;
			}

			$por_secao[ $secao ][ (string) $nome ] = $declaracao;
		}

		if ( array() === $por_secao ) {
			printf(
				'<p>%s</p>',
				esc_html__( 'Nenhum campo foi liberado para edição neste projeto. Quem opera o site é o agente de manutenção, pelo canal.', 'f3base' )
			);

			return;
		}


		$por_secao=array_intersect_key($por_secao,array($ativa=>true));
        $atalho=$ativa==='contato'?'<p><a class="button" href="'.esc_url(admin_url('admin.php?page=f3base-formularios')).'">Gerenciar formulários</a></p>':'';
        $nomes = array();
		if(isset($por_secao['medicao-clarity'])){$campos=$por_secao['medicao-clarity'];$por_secao['medicao-clarity']=array_replace(array_intersect_key(array_fill_keys(F3Base_Interface::AREAS['medicao-clarity'],null),$campos),$campos);}
		foreach ( $por_secao as $campos ) {
			$nomes = array_merge( $nomes, array_keys( $campos ) );
		}
		$fotos = F3Base_Options::fotografias( $nomes );

		foreach ( $secoes as $secao => $cabecalho ) {
			if ( ! isset( $por_secao[ $secao ] ) ) {
				continue;
			}

            $contexto=F3Base_Admin_Entrada::contexto($ativa,$por_secao[$secao],$fotos);
			printf( '<form method="post" action="%s" class="f3base-form"%s>', esc_url( admin_url( 'admin-post.php' ) ), $ativa === 'medicao-meta' ? ' data-f3base-meta-edicao novalidate' : ''  );
			printf( '<input type="hidden" name="action" value="%s" />', esc_attr( self::ACAO ) );
            echo '<input type="hidden" name="f3base_renovar_nonce" value="'.esc_attr(wp_create_nonce('f3base-form-renovar')).'">';echo '<input type="hidden" name="secao" value="'.esc_attr($ativa).'"><input type="hidden" name="f3base_contexto" value="'.esc_attr($contexto).'">';
			printf( '<input type="hidden" id="%s" name="_wpnonce" value="%s">', esc_attr( 'f3base-nonce-' . $secao ), esc_attr( wp_create_nonce( self::NONCE ) ) );
			printf(
				'<section id="f3base-bloco-%1$s" class="f3base-bloco f3base-bloco-area f3base-bloco--%1$s" data-f3base-bloco="%1$s"><header class="f3base-bloco-cabecalho"><h2>%2$s</h2><p class="f3base-bloco-resumo">%3$s</p><p class="description f3base-regra-salvar">O botão Salvar alterações fica fixo na base da janela e grava somente os campos desta área.</p><p class="description" data-f3base-contexto-aviso>Após duas horas, reabra esta área para continuar a edição.</p>%4$s</header>',
				esc_attr( (string) $secao ),
				esc_html( (string) $cabecalho['titulo'] ),
				esc_html( (string) $cabecalho['resumo'] ),
				$atalho // Montado acima com esc_url.
			);

            // Cada option vira um bloco próprio, com âncora estável (linha-<option>) e entrada no índice.
            $advanced=array('f3base_google_carregamento','f3base_carregamento_destinos','f3base_meta_janela','f3base_classificacao_acessos');
            foreach($por_secao[$secao] as $nome=>$declaracao){if(!in_array($nome,$advanced,true)){self::render_campo($nome,$declaracao,$fotos[$nome]);}}
            $more=array_intersect_key($por_secao[$secao],array_flip($advanced));if($more){
                // Recolhidos por padrão, como até a 1.78.0. Abrem sozinhos quando um deles tem erro ou rascunho recuperado; o índice da área também os abre.
                $abrir=array()!==array_intersect_key(self::$erros+self::$rascunhos,$more);
                echo '<details class="f3base-avancado" id="grupo-ajustes-avancados" data-f3base-indice="Ajustes avançados"'.($abrir?' open':'').'><summary class="f3base-avancado-titulo">Ajustes avançados</summary><p class="f3base-avancado-resumo">Ajustes finos que a maioria dos sites mantém no padrão.</p>';foreach($more as $nome=>$declaracao){self::render_campo($nome,$declaracao,$fotos[$nome],2);}echo '</details>';}
            if($ativa==='medicao-gsc'){F3Base_Gsc::painel();echo '<p><a href="'.esc_url(admin_url('admin.php?page=f3base-medicao&area=aquisicao&visao=gsc')).'">Abrir relatório Search Console</a></p>';}
			echo '</section>';
			/*
			 * BARRA DE SALVAR IMPRESSA PELO SERVIDOR (1.79.0). Até a 1.78.0 ela era
			 * criada por JavaScript e declarada sticky dentro do formulário: no topo
			 * da área o botão ficava milhares de pixels abaixo da janela. Agora é
			 * fixa na base da janela; o `f3base_fim` continua sendo o último campo
			 * enviado, e o espaço que a barra ocupa é reservado no fim da tela.
			 */
            echo '<div class="f3base-savebar"><div class="f3base-savebar-conteudo"><span class="f3base-situacao-edicao" data-f3base-situacao role="status"></span>';
			submit_button( 'Salvar alterações', 'primary', 'submit', false, array( 'id' => 'f3base-salvar-' . $secao ) );
			echo '<input type="hidden" name="f3base_fim" value="'.esc_attr($contexto).'"></div></div></form>';
			if($ativa==='medicao-clarity'){F3Base_Admin_Clarity::render();}
		}
	}

	/**
	 * Campo de uma option operável.
	 *
	 * @param string              $nome       Nome da option.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @return void
	 */
    private static function rascunho_valor(array $d,$raw) {
        $t=$d['tipo']??$d['campo']??'texto';if($t==='grupo'){$r=array();foreach($d['subcampos']??array() as $k=>$child){$r[$k]=self::rascunho_valor($child,$raw[$k]??'');}return $r;}
        if($t==='json' && !empty($d['objeto'])){return (object)array('f3base_rascunho_json'=>is_string($raw)?$raw:'');}
        if($t==='json'){try{return json_decode((string)$raw,true,32,JSON_THROW_ON_ERROR);}catch(JsonException $e){return (object)array('f3base_rascunho_json'=>(string)$raw);}}
        try{return F3Base_Admin_Entrada::converter($d,$raw);}catch(InvalidArgumentException $e){return $raw;}
    }
    private static function json_edicao($valor, bool $objeto = false): string {
        if (is_object($valor) && isset($valor->f3base_rascunho_json)) {
            return $valor->f3base_rascunho_json;
        }
        return (string)wp_json_encode($objeto ? (object)$valor : $valor, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

	private static function render_campo( string $nome, array $declaracao, array $foto, int $nivel = 1 ): void {
		$valor          = $foto['valor'];
		$atual_no_banco = $valor;
		$recuperado     = array_key_exists( $nome, self::$rascunhos ) && ! self::e_segredo( $declaracao );
		if ( $recuperado ) {
			$valor = self::rascunho_valor($declaracao,self::$rascunhos[$nome]); }
		$grupo  = isset( $declaracao['subcampos'] ) && is_array( $declaracao['subcampos'] ) && array() !== $declaracao['subcampos'];
		$rotulo = (string) $declaracao['rotulo'];
		$campo  = (string) ( $declaracao['campo'] ?? '' );
		$titulo_id = 'titulo-' . $nome;
		$descricao = isset( $declaracao['descricao'] ) ? (string) $declaracao['descricao'] : '';

		if ( F3Base_Admin_Entrada::sem_editor( $nome, $declaracao ) ) {
			self::render_somente_leitura( $nome, $declaracao, $atual_no_banco, $nivel );
			return;
		}

		/*
		 * UM RÓTULO POR CAMPO (1.79.0). O título do bloco É o rótulo do controle
		 * quando a option tem um controle só: `label for` apontando para ele, e
		 * nenhum `legend` nem `aria-label` repetindo o mesmo texto. Option com
		 * vários controles (grupo, lista de e-mails, blocos, tabela) tem título
		 * em texto e cada controle mantém o próprio rótulo.
		 */
		$controle_unico = ! $grupo && 'f3base_navegacao' !== $nome && ! in_array( $campo, array( 'emails', 'blocos', 'campanhas', 'booleano' ), true );
		$alvo           = 'segredo' === $campo ? 'f3base-segredo-' . $nome . '-valor' : 'f3base-' . $nome;

		printf(
			'<section class="f3base-grupo-bloco" id="%1$s" data-f3base-indice="%2$s"%3$s>',
			esc_attr( 'linha-' . $nome ),
			esc_attr( $rotulo ),
			$nivel > 1 ? ' data-f3base-indice-nivel="2"' : ''
		);
		if ( 'booleano' === $campo && ! $grupo ) {
			// O valor 0 vem antes da caixa: desmarcada, a caixa não é enviada e o 0 prevalece.
			printf( '<input type="hidden" name="f3base[%s]" value="0">', esc_attr( $nome ) );
			printf(
				'<h3 class="f3base-grupo-titulo f3base-grupo-titulo--opcao" id="%1$s"><label for="%2$s"><input type="checkbox" id="%2$s" name="f3base[%3$s]" value="1" %4$s> %5$s</label></h3>',
				esc_attr( $titulo_id ),
				esc_attr( 'f3base-' . $nome ),
				esc_attr( $nome ),
				checked( (bool) $valor, true, false ),
				esc_html( $rotulo )
			);
		} elseif ( $controle_unico ) {
			printf( '<h3 class="f3base-grupo-titulo" id="%1$s"><label for="%2$s">%3$s</label></h3>', esc_attr( $titulo_id ), esc_attr( $alvo ), esc_html( $rotulo ) );
		} else {
			printf( '<h3 class="f3base-grupo-titulo" id="%1$s">%2$s</h3>', esc_attr( $titulo_id ), esc_html( $rotulo ) );
		}
        if(isset(self::$erros[$nome])){echo '<div class="notice notice-error inline f3base-erro-campo" id="erro-'.esc_attr($nome).'" role="alert">';foreach(self::$erros[$nome] as $e){echo '<p data-caminho="'.esc_attr($e['caminho']).'">'.esc_html($e['motivo']).'</p>';}echo '</div>';}
		printf( '<input type="hidden" name="f3base_revisao[%s]" value="%s">', esc_attr( $nome ), esc_attr( (string) $foto['revisao'] ) );
		if ( $recuperado ) {
			echo '<div class="notice notice-warning inline"><p>Sua edição foi recuperada. Confira o valor atual antes de salvar novamente.</p><details><summary>Valor atual no site</summary><pre>' . esc_html( self::resumir( $atual_no_banco ) ) . '</pre></details>';
            if (in_array($nome, F3Base_Interface::AREAS['medicao-meta'], true)) {
                echo '<p class="hide-if-no-js"><label><input type="checkbox" data-f3base-reaplicar> Incluir este rascunho no próximo salvamento mesmo sem nova edição</label></p>';
            }
            echo '</div>';
		}

        if($nome==='f3base_navegacao'){
			if ( '' !== $descricao ) {
				printf( '<p class="f3base-assunto">%s</p>', esc_html( $descricao ) );
			}
			F3Base_Navegacao::render(is_array($valor)?$valor:array());
		}
		elseif ( $grupo ) {
			if ( '' !== $descricao ) {
				printf( '<p class="f3base-assunto">%s</p>', esc_html( $descricao ) );
			}
			printf( '<fieldset class="f3base-grupo" aria-labelledby="%s">', esc_attr( $titulo_id ) );

			$subcampos = $declaracao['subcampos'];
            if ( 'f3base_contato' === $nome ) {
                $ordem = array( 'registro' => 0, 'whatsapp' => 1, 'instrumentacao' => 2 );
                uasort( $subcampos, static fn( $a, $b ) => ( $ordem[$a['grupo_visual'] ?? 'whatsapp'] ?? 9 ) <=> ( $ordem[$b['grupo_visual'] ?? 'whatsapp'] ?? 9 ) );
            }
            $grupo_anterior = '';
            foreach ( $subcampos as $chave => $sub ) {
                if ( isset( $sub['grupo_visual'] ) && $grupo_anterior !== $sub['grupo_visual'] ) {
                    $grupo_anterior = $sub['grupo_visual'];
                    $titulo_visual  = array( 'registro' => 'Registro e avisos de contato', 'whatsapp' => 'WhatsApp', 'instrumentacao' => 'Instrumentação dos botões' )[$grupo_anterior];
                    printf( '<h4 class="f3base-subgrupo-titulo" id="%1$s" data-f3base-indice="%2$s" data-f3base-indice-nivel="2">%3$s</h4>', esc_attr( 'grupo-' . $nome . '-' . sanitize_key( (string) $grupo_anterior ) ), esc_attr( $titulo_visual ), esc_html( $titulo_visual ) );
                }
				$atual = is_array( $valor ) && array_key_exists( (string) $chave, $valor ) ? $valor[ (string) $chave ] : '';
				self::render_subcampo( $nome, (string) $chave, is_array( $sub ) ? $sub : array(), $atual );
			}

			echo '</fieldset>';
			if ( array() === array_filter( array_keys( $subcampos ), static fn( $chave ): bool => ! F3Base_Config_UI::central_campo( $nome, (string) $chave ) ) ) {
				echo '<p class="description">' . esc_html__( 'Os campos deste grupo são editados no formulário próprio, mais abaixo nesta área.', 'f3base' ) . '</p>';
			}
		} else {
			printf( '<div class="f3base-campo" data-f3base-campo="%s">', esc_attr( $nome ) );
			if ( '' !== $descricao ) {
				printf( '<p class="f3base-assunto">%s</p>', esc_html( $descricao ) );
			}

			if ( 'segredo' === $campo ) {
				self::render_campo_de_segredo( $nome, $declaracao, $valor );
			} elseif(in_array($campo,array('linhas','emails','blocos'),true)){
                self::render_lista_1120('f3base-'.$nome,'f3base['.$nome.']',$rotulo,$campo,$valor,$titulo_id);
                if($nome===F3Base_Email_Contato::OPTION){
                    echo '<div data-email-simulador><label for="f3base-email-amostra">E-mail para simular</label> <input id="f3base-email-amostra" type="text" inputmode="email" maxlength="1024" autocomplete="off"> <button type="button" class="button" data-email-simular="'.esc_attr(wp_create_nonce('f3base_email_simular')).'">Simular correção</button><p role="status" aria-live="polite"></p></div>';
                }
            } elseif($campo==='campanhas'){F3Base_Configuracoes_Hub::campanhas($nome,(array)$valor);
            } elseif($campo==='lista'){
                echo '<textarea id="f3base-'.esc_attr($nome).'" name="f3base['.esc_attr($nome).']" rows="3" class="large-text">'.esc_textarea(is_array($valor)?implode(', ',$valor):(string)$valor).'</textarea>';
            } elseif($campo==='booleano'){
                // A caixa está no título do bloco, junto do rótulo.
            } elseif ( 'inteiro' === $campo ) {
				/*
				 * O MÍNIMO SAI DO CATÁLOGO, e o `0` embutido era metade do
				 * defeito de `f3base_retencao_meses`: a tela CONVIDAVA a digitar
				 * zero num campo em que zero significa o oposto do que parece. O
				 * `min` do navegador não é a garantia — a garantia é a recusa do
				 * gravador único —, mas ele é o que impede o engano antes de
				 * ele acontecer.
				 */
				printf(
					'<input type="number" min="%1$s" step="1" class="small-text" id="%2$s" name="f3base[%3$s]" value="%4$s" />',
					esc_attr( (string) ( isset( $declaracao['minimo'] ) ? (int) $declaracao['minimo'] : 0 ) ),
					esc_attr( 'f3base-' . $nome ),
					esc_attr( $nome ),
					esc_attr( (string) ( is_scalar( $valor ) ? $valor : '' ) )
				);
			} else {
				printf(
					'<input type="text" class="regular-text" id="%1$s" name="f3base[%2$s]" value="%3$s" />',
					esc_attr( 'f3base-' . $nome ),
					esc_attr( $nome ),
					esc_attr( (string) ( is_scalar( $valor ) ? $valor : '' ) )
				);
			}

			self::render_impacto_e_exemplo( $nome, $declaracao, array( $descricao, $rotulo ) );

			echo '</div>';
		}

		echo '<details class="f3base-ajuda f3base-ajuda-tecnica"><summary>' . esc_html__( 'Referência para suporte', 'f3base' ) . '</summary>';
		printf(
			'<p class="description f3base-referencia">%s <code>%s</code></p>',
			esc_html__( 'Nome técnico deste ajuste, para quem opera o site pelo canal de manutenção:', 'f3base' ),
			esc_html( $nome )
		);

		echo '</details></section>';
	}

	/**
	 * Bloco somente leitura de uma option estruturada sem editor nesta tela.
	 * Não imprime campo do formulário nem revisão: a option não entra no envio.
	 *
	 * @param string              $nome       Nome da option.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @param mixed               $valor      Valor atual no site.
	 * @param int                 $nivel      Nível do bloco no índice.
	 * @return void
	 */
	private static function render_somente_leitura( string $nome, array $declaracao, $valor, int $nivel ): void {
		$rotulo    = (string) $declaracao['rotulo'];
		$descricao = isset( $declaracao['descricao'] ) ? (string) $declaracao['descricao'] : '';
		$titulo_id = 'titulo-' . $nome;
		$resumo    = self::resumir( $valor );
		$habilidade = 'f3base_redirects' === $nome ? 'f3base/redirects-escrever' : 'f3base/config-core-escrever';

		printf(
			'<section class="f3base-grupo-bloco f3base-somente-leitura" id="%1$s" data-f3base-indice="%2$s"%3$s>',
			esc_attr( 'linha-' . $nome ),
			esc_attr( $rotulo ),
			$nivel > 1 ? ' data-f3base-indice-nivel="2"' : ''
		);
		printf( '<h3 class="f3base-grupo-titulo" id="%1$s">%2$s</h3>', esc_attr( $titulo_id ), esc_html( $rotulo ) );
		printf( '<div class="f3base-campo" data-f3base-campo="%s">', esc_attr( $nome ) );
		if ( '' !== $descricao ) {
			printf( '<p class="f3base-assunto">%s</p>', esc_html( $descricao ) );
		}
		if ( strlen( $resumo ) > 160 ) {
			echo '<details><summary>' . esc_html__( 'Valor atual no site', 'f3base' ) . '</summary><pre>' . esc_html( $resumo ) . '</pre></details>';
		} else {
			echo '<p class="f3base-valor-atual"><strong>' . esc_html__( 'Valor atual:', 'f3base' ) . '</strong> <code>' . esc_html( '' === $resumo ? '—' : $resumo ) . '</code></p>';
		}
		printf(
			'<p class="description">%s <code>%s</code>.</p>',
			esc_html__( 'Este item tem estrutura própria e não é alterado nesta tela. Quem altera é o agente de manutenção, com a habilidade', 'f3base' ),
			esc_html( $habilidade )
		);
		echo '</div>';
		echo '<details class="f3base-ajuda f3base-ajuda-tecnica"><summary>' . esc_html__( 'Referência para suporte', 'f3base' ) . '</summary>';
		printf(
			'<p class="description f3base-referencia">%s <code>%s</code></p>',
			esc_html__( 'Nome técnico deste ajuste, para quem opera o site pelo canal de manutenção:', 'f3base' ),
			esc_html( $nome )
		);
		echo '</details></section>';
	}

	/**
	 * A declaração é de um SEGREDO?
	 *
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @return bool
	 */
	private static function e_segredo( array $declaracao ): bool {
		return isset( $declaracao['campo'] ) && 'segredo' === (string) $declaracao['campo'];
	}

	/**
	 * O CAMPO DE UM SEGREDO: editável, mascarado, e nunca reimpresso.
	 *
	 * O DEFEITO MEDIDO num WordPress real: o token da Conversions API era
	 * declarado como campo de TEXTO e saía em claro no `value=` de um
	 * `<input type="text">` — visível na tela, no código-fonte da página e em
	 * qualquer captura de tela do painel. A saída NÃO é tirar o campo: quem
	 * grava esse token é quem opera o site, e sem campo ele iria parar num
	 * plugin de terceiro. A saída é este conjunto de quatro regras, e cada uma
	 * fecha um caminho:
	 *
	 * 1. `type="password"` — o navegador não desenha o conteúdo, e o valor
	 *    GRAVADO nunca chega ao HTML: o campo nasce vazio a cada carregamento.
	 * 2. `autocomplete="new-password"` — sem ele, o gerenciador de senhas do
	 *    navegador oferece a senha do WordPress do administrador dentro do campo
	 *    do token, e a próxima gravação a mandaria para a Meta.
	 * 3. VAZIO SIGNIFICA MANTER. Como o valor não é reimpresso, gravar a tela
	 *    sem tocar neste campo apagaria o token — a cada vez que alguém mudasse
	 *    o número do WhatsApp.
	 * 4. A CAIXA DE APAGAR é a única forma de esvaziar, e ela é explícita: zerar
	 *    uma credencial é uma decisão, não um efeito colateral de um campo em
	 *    branco.
	 *
	 * O que a tela DIZ do valor é um marcador — existe ou não existe —, e nunca
	 * o valor nem o tamanho dele.
	 *
	 * @param string              $nome       Nome da option.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @param mixed               $valor      Valor lido do banco.
	 * @return void
	 */
	private static function render_campo_de_segredo( string $nome, array $declaracao, $valor ): void {
        // O rótulo do campo é o título do bloco; a caixa de segredo não repete o texto.
        F3Base_Config_UI::segredo($nome,'f3base['.$nome.']','f3base_apagar['.$nome.']',false);
    }

	/**
	 * O `id` de um sub-campo, produzido num lugar só.
	 *
	 * POR QUE ISTO É UMA FUNÇÃO. O `id` é a ÂNCORA que outra tela usa para
	 * mandar o operador direto ao controle — a tela Medição faz isso com
	 * `f3base_comportamento.ligado`. Montado como literal nos dois lugares, ele
	 * concordaria por coincidência: renomear a option ou a chave manteria o
	 * link existindo e o faria deixar de levar a lugar nenhum, sem erro em
	 * lugar nenhum e sem nada acusando.
	 *
	 * @param string $option Nome da option.
	 * @param string $chave  Chave dentro do grupo.
	 * @return string
	 */
	public static function id_do_subcampo( string $option, string $chave ): string {
		return 'f3base-' . $option . '-' . $chave;
	}

	/**
	 * Sub-campo de uma option em grupo.
	 *
	 * @param string              $option Nome da option.
	 * @param string              $chave  Chave dentro do grupo.
	 * @param array<string,mixed> $sub    Declaração do sub-campo.
	 * @param mixed               $atual  Valor atual.
	 * @return void
	 */
	private static function render_subcampo( string $option, string $chave, array $sub, $atual ): void {
		$id     = str_replace(array('[',']'),'-',self::id_do_subcampo( $option, $chave ));
		$name   = 'f3base[' . $option . '][' . $chave . ']';
		$tipo   = isset( $sub['tipo'] ) ? (string) $sub['tipo'] : 'texto';
		$rotulo = isset( $sub['rotulo'] ) ? (string) $sub['rotulo'] : $chave;

		printf( '<div class="f3base-campo f3base-subcampo" data-f3base-campo="%s">', esc_attr( $option . '.' . $chave ) );

        if(F3Base_Config_UI::central_campo($option,$chave)||(!F3Base_Options::ler('f3base_gtm_container_id')&&(str_contains($chave,'gtm')||str_contains($chave,'datalayer')))){if(is_array($atual)){foreach($atual as $v){echo '<input type="hidden" name="'.esc_attr($name).'[]" value="'.esc_attr($v).'">';}}else{echo '<input type="hidden" name="'.esc_attr($name).'" value="'.esc_attr(is_bool($atual)?($atual?'1':'0'):(string)$atual).'">';}echo '</div>';return;}
        if($chave==='atualizacao_intervalo_segundos'){echo '<p><label for="'.esc_attr($id).'-minutos">Intervalo de atualização em minutos</label> <input id="'.esc_attr($id).'-minutos" type="number" min="1" max="1440" step="any" value="'.esc_attr((float)$atual/60).'" data-f3base-minutos="'.esc_attr($id).'"><input id="'.esc_attr($id).'" type="hidden" name="'.esc_attr($name).'" value="'.esc_attr($atual).'"></p></div>';return;}

		if($tipo==='grupo'){echo '<fieldset><legend>'.esc_html($rotulo).'</legend>';foreach($sub['subcampos']??array() as $k=>$d){self::render_subcampo($option,$chave.']['.$k,$d,is_array($atual)?($atual[$k]??''):'');}echo '</fieldset>';
        } elseif ( in_array( $tipo, array( 'emails', 'linhas', 'blocos' ), true ) ) { self::render_lista_1120( $id, $name, $rotulo, $tipo, $atual );
		} elseif ( 'booleano' === $tipo ) {
			printf( '<input type="hidden" name="%s" value="0" />', esc_attr( $name ) );
			printf(
				'<p><label class="f3base-rotulo" for="%1$s"><input type="checkbox" id="%1$s" name="%2$s" value="1" %3$s /> %4$s</label></p>',
				esc_attr( $id ),
				esc_attr( $name ),
				checked( (bool) $atual, true, false ),
				esc_html( $rotulo )
			);
		} elseif ( 'multiescolha' === $tipo ) {
			// O catálogo é cacheado antes de init; tipos personalizados só existem depois.
			$opcoes       = isset( $sub['opcoes_callback'] ) && is_callable( $sub['opcoes_callback'] )
				? call_user_func( $sub['opcoes_callback'] )
				: ( isset( $sub['opcoes'] ) && is_array( $sub['opcoes'] ) ? $sub['opcoes'] : array() );
			$selecionadas = is_array( $atual ) ? array_map( 'strval', $atual ) : array();
			printf( '<fieldset id="%s" class="f3base-multiescolha"><legend class="f3base-rotulo">%s</legend>', esc_attr( $id ), esc_html( $rotulo ) );
			// A lista vazia precisa ser enviada para permitir desmarcar todas.
			printf( '<input type="hidden" name="%s[]" value="" />', esc_attr( $name ) );
			foreach ( $opcoes as $valor => $texto ) {
				printf( '<label><input type="checkbox" name="%s[]" value="%s" %s /> %s</label>', esc_attr( $name ), esc_attr( (string) $valor ), checked( in_array( (string) $valor, $selecionadas, true ), true, false ), esc_html( (string) $texto ) );
			}
			if ( array() === $opcoes ) {
				echo '<p>' . esc_html__( 'Nenhum tipo de conteúdo público disponível.', 'f3base' ) . '</p>'; }
			echo '</fieldset>';
		} elseif ( in_array( $tipo, array( 'enum', 'select' ), true ) ) {
			$opcoes = isset( $sub['opcoes'] ) && is_array( $sub['opcoes'] ) ? $sub['opcoes'] : array();

			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf( '<select id="%1$s" name="%2$s">', esc_attr( $id ), esc_attr( $name ) );

			if ( '' !== (string) $atual && ! array_key_exists( (string) $atual, $opcoes ) ) { printf( '<option value="%s" selected>Valor atual indisponível: %s</option>', esc_attr( (string) $atual ), esc_html( (string) $atual ) ); }
			foreach ( $opcoes as $chave_opcao => $rotulo_opcao ) {
				printf(
					'<option value="%1$s" %2$s>%3$s</option>',
					esc_attr( (string) $chave_opcao ),
					selected( (string) $atual, (string) $chave_opcao, false ),
					esc_html( (string) $rotulo_opcao )
				);
			}

			echo '</select></p>';
		} elseif ( 'inteiro' === $tipo ) {
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<input type="number" min="0" step="1" class="small-text" id="%1$s" name="%2$s" value="%3$s" /></p>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) ( is_scalar( $atual ) ? $atual : '' ) )
			);
		} elseif ( 'lista' === $tipo ) {
			/*
			 * LISTA DE NOMES numa linha, separados por vírgula. O campo é de
			 * texto porque é assim que ele é editável sem JavaScript, e o
			 * sanitizador aceita as duas formas — a linha da tela e a lista da
			 * configuração —, para que a mesma chave possa vir dos dois lados.
			 */
			$itens = is_array( $atual ) ? array_map( 'strval', $atual ) : array();

			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<input type="text" class="regular-text" id="%1$s" name="%2$s" value="%3$s" /></p>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( implode( ', ', $itens ) )
			);
		} elseif ( 'json' === $tipo ) {
            if($option==='f3base_seo_entidade'&&$chave==='servicos'){self::render_ofertas();echo '<details><summary>Serviços e ofertas</summary><p>A lista enviada substitui a anterior. Preserve as chaves que deseja manter. Use ofertas com IDs estáveis; nomes podem ter alternativas mensais e anuais.</p>';}
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label></p><textarea id="%1$s" name="%3$s" rows="6" class="large-text code" spellcheck="false">%4$s</textarea>', esc_attr( $id ), esc_html( $rotulo ), esc_attr( $name ), esc_textarea( self::json_edicao($atual, !empty($sub['objeto'])) ) );
            if($option==='f3base_seo_entidade'&&$chave==='servicos'){echo '</details>';}
		} elseif ( 'textarea' === $tipo ) {
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label></p>', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<textarea id="%1$s" name="%2$s" rows="3" class="large-text">%3$s</textarea>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_textarea( (string) ( is_scalar( $atual ) ? $atual : '' ) )
			);
		} else {
			printf( '<p><label class="f3base-rotulo" for="%1$s">%2$s</label> ', esc_attr( $id ), esc_html( $rotulo ) );
			printf(
				'<input type="%1$s" class="regular-text" id="%2$s" name="%3$s" value="%4$s" /></p>',
				esc_attr( in_array($sub['html_tipo']??'',array('date','time'),true)?$sub['html_tipo']:('email' === $tipo ? 'email' : 'text') ),
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) ( is_scalar( $atual ) ? $atual : '' ) )
			);
		}

		if ( ! empty( $sub['descricao'] ) ) {
			printf( '<p class="description f3base-campo-descricao">%s</p>', esc_html( (string) $sub['descricao'] ) ); }
		if($option==='f3base_contato'&&$chave==='email_leads'){$email=(string)get_option('admin_email','');if(is_email($email)){echo '<button type="button" class="button" data-f3base-admin-email="'.esc_attr($email).'">Usar e-mail da administração</button>';}else{echo '<p role="status">O e-mail administrativo atual não é válido.</p>';}}
        $sub['chave']=$chave;self::render_impacto_e_exemplo( $option, $sub, array( (string) ( $sub['descricao'] ?? '' ), $rotulo ) );

		echo '</div>';
	}

    private static function render_ofertas(): void {
        $itens=F3Base_Ofertas::consultar()['itens'];$grupos=array();foreach($itens as $i){$grupos[$i['servico'].' — '.$i['nome']][]=$i;}
        echo '<div class="f3base-ofertas"><p>Preços configurados só entram no schema após conferência do conteúdo público. A verificação também informa quando outro emissor ocupa o serviço.</p>';
        if(!$grupos){echo '<p>Nenhuma oferta configurada.</p>';}
        $labels=array('verificacao_pendente'=>'Verificação pendente','publicada'=>'Publicada pelo Core','divergente'=>'Conteúdo não comprovado','ocupado_por_outro_emissor'=>'Ocupada por outro emissor');
        foreach($grupos as $name=>$rows){echo '<details><summary>'.esc_html($name).' ('.count($rows).')</summary><ul>';foreach($rows as $row){echo '<li><strong>'.esc_html($row['oferta']).'</strong>: '.esc_html($labels[$row['estado']]??$row['estado']).' — <a href="'.esc_url(get_permalink($row['pagina'])).'">Ver página</a>';if(!empty($row['conflito'])){echo '<p>Serviço concorrente: <code>'.esc_html($row['conflito']['id']??'ID ausente').'</code>.</p>';}echo '</li>';}echo '</ul></details>';}
        echo '<p class="description">Consulte o procedimento instalado em docs/OFERTAS.md. Conferência pelo canal: f3base/schema-verificar, com as páginas dos planos e a revisão atual. Consultar não executa sondas.</p></div>';
    }

    /**
     * Lista editável (e-mails, linhas ou blocos).
     *
     * Com `$titulo_id`, o rótulo já está no título do bloco: a textarea recebe o
     * `id` que o `label for` do título aponta, e as listas de vários controles
     * viram um grupo nomeado pelo título — sem `legend` repetindo o texto.
     */
    private static function render_lista_1120( string $id, string $name, string $rotulo, string $tipo, $atual, string $titulo_id = '' ): void {
        $valores = is_array( $atual ) ? $atual : ( $atual ? array( (string) $atual ) : array() );
        if ( 'linhas' === $tipo ) {
            if ( '' === $titulo_id ) {
                echo '<p><label class="f3base-rotulo" for="' . esc_attr( $id ) . '">' . esc_html( $rotulo ) . '</label></p>';
            }
            echo '<textarea id="' . esc_attr( $id ) . '" rows="4" class="large-text" name="' . esc_attr( $name ) . '">' . esc_textarea( implode( "\n", $valores ) ) . '</textarea>';
            return;
        }
        echo '' === $titulo_id
            ? '<fieldset id="' . esc_attr( $id ) . '" class="f3base-lista-grupo"><legend class="f3base-rotulo">' . esc_html( $rotulo ) . '</legend>'
            : '<div id="' . esc_attr( $id ) . '" class="f3base-lista-grupo" role="group" aria-labelledby="' . esc_attr( $titulo_id ) . '">';
        if ( 'emails' === $tipo ) {
            for ( $i = 0; $i < max(5,count($valores)); ++$i ) {
                echo '<p><label>Destinatário ' . ( $i + 1 ) . ' <input type="email" class="regular-text" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $valores[$i] ?? '' ) . '"></label></p>';
            }
        } else {
            $opcoes = array();
            foreach ( WP_Block_Type_Registry::get_instance()->get_all_registered() as $n => $block ) { $opcoes[$n] = ( $block->title ?: $n ) . ' (' . $n . ')'; }
            foreach ( $valores as $n ) { if ( ! isset( $opcoes[$n] ) ) { $opcoes[$n] = $n . ' — indisponível neste contexto'; } }
            uksort($opcoes,static fn($a,$b)=>(in_array($b,$valores,true)<=>in_array($a,$valores,true))?:strnatcasecmp($opcoes[$a],$opcoes[$b]));
            echo '<p><label>Buscar bloco <input type="search" data-f3base-buscar-blocos="' . esc_attr( $id ) . '"></label></p><input type="hidden" name="' . esc_attr( $name ) . '[selecionados][]" value=""><div class="f3base-blocos-lista">';
            foreach ( $opcoes as $n => $label ) {
                echo '<label class="f3base-blocos-item" data-f3base-bloco><input type="checkbox" name="' . esc_attr( $name ) . '[selecionados][]" value="' . esc_attr( $n ) . '" ' . checked( in_array( $n, $valores, true ), true, false ) . '> ' . esc_html( $label ) . '</label>';
            }
            echo '</div><details><summary>Adicionar identificadores de blocos registrados somente na página pública</summary><label>Um identificador namespace/bloco por linha<textarea class="large-text" name="' . esc_attr( $name ) . '[adicionais]"></textarea></label></details>';
        }
        echo '' === $titulo_id ? '</fieldset>' : '</div>';
    }

	/**
	 * O IMPACTO e o EXEMPLO de uma folha, e o exemplo nunca entra no campo.
	 *
	 * O exemplo sai em elemento próprio, com marca própria, DEPOIS do controle
	 * — nunca em `value` e nunca em `placeholder`. Placeholder some quando o
	 * operador digita, reaparece quando ele apaga, e é lido como conteúdo do
	 * campo por leitor de tela e por quem tem pressa: é a forma mais barata de
	 * fazer alguém sair da tela convencido de que gravou o que não gravou.
	 *
	 * SEGREDO NÃO TEM EXEMPLO DE VALOR, e a marca diz isso em vez de fingir:
	 * onde os outros campos trazem "Exemplo", o token traz "Onde obter". A
	 * lista de segredos sai da âncora do próprio plugin.
	 *
	 * @param string              $option Option a que a folha pertence.
	 * @param array<string,mixed> $campo  Declaração da folha.
	 * @return void
	 */
	private static function render_impacto_e_exemplo( string $option, array $campo, array $visiveis = array() ): void {
        if(($campo['tipo']??'')==='grupo'){return;}
        $a=F3Base_Interface::ajuda($option,$campo['chave']??'', $campo);
        /*
         * "Como funciona" cai para a descrição (ou para o rótulo) quando o catálogo
         * não declara impacto. Esses textos já estão visíveis acima do controle:
         * repeti-los dentro do detalhe só alonga a tela (1.79.0, A5).
         */
        $normalizar=static fn(string $t): string => trim((string)preg_replace('/\s+/u',' ',$t));
        $ja_visiveis=array_filter(array_map($normalizar,$visiveis));
        if(in_array($normalizar((string)($a['funcionamento']??'')),$ja_visiveis,true)){$a['funcionamento']='';}
        echo '<details class="f3base-ajuda"><summary>Como funciona e exemplo</summary>';
        foreach(array('funcionamento'=>'Como funciona','escolha'=>'Quando escolher','vantagens'=>'Vantagens','limitacoes'=>'Limitações','exemplo'=>'Exemplo','vazio'=>'Ausente ou vazio') as $k=>$label){if(($a[$k]??'')!==''){echo '<p><strong>'.esc_html($label).':</strong> '.esc_html($a[$k]).'</p>';}}
        echo '</details>';
    }

	/* ------------------------------------------------------------------ *
	 * O que as páginas registraram
	 * ------------------------------------------------------------------ */

	/**
	 * O CAMINHO até a medição — uma linha, e não um resumo.
	 *
	 * @return void
	 */
	private static function render_caminho_da_medicao(): void {
		printf(
			'<section class="f3base-bloco f3base-bloco--%1$s" data-f3base-bloco="%1$s"><h2>%2$s</h2>',
			esc_attr( self::BLOCO_COMPORTAMENTO ),
			esc_html__( 'O que as páginas registraram', 'f3base' )
		);

		if ( ! class_exists( 'F3Base_Admin_Medicao' ) ) {
			printf(
				'<p class="f3base-bloco-resumo">%s</p></section>',
				esc_html__( 'A tela de medição não está disponível nesta instalação do plugin.', 'f3base' )
			);

			return;
		}

		printf(
			'<p class="f3base-bloco-resumo"><a href="%1$s">%2$s</a> %3$s</p></section>',
			esc_url( admin_url( 'admin.php?page=' . F3Base_Admin_Medicao::SLUG ) ),
			esc_html__( 'Abrir o menu Medição', 'f3base' ),
			esc_html__( '— os números do site moram lá: quanto da página as pessoas leem, quais blocos são vistos, para onde elas saem, onde clicam repetido sem resposta, o que quebra no navegador delas e quanto tempo a página leva para ficar utilizável. Esta tela ficou com as chaves que produzem esses números.', 'f3base' )
		);
	}

	/* ------------------------------------------------------------------ *
	 * Diagnóstico — inteiro, e depois dos campos
	 * ------------------------------------------------------------------ */

	/**
	 * O diagnóstico: estado de cada parte, motivos, avisos, hooks e options.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_diagnostico( array $relatorio ): void {
		printf(
			'<section class="f3base-bloco f3base-bloco--%1$s" data-f3base-bloco="%1$s"><h2>%2$s</h2>',
			esc_attr( self::BLOCO_DIAGNOSTICO ),
			esc_html__( 'Estado das partes do plugin', 'f3base' )
		);

		printf(
			'<p class="f3base-bloco-resumo">%s</p>',
			esc_html__( 'O que está funcionando, o que está funcionando com ressalva e o que está parado, com o motivo de cada um. É esta parte que responde "por que isto não está acontecendo no site", e é a que o suporte e o agente de manutenção leem.', 'f3base' )
		);

		self::render_resumo( $relatorio );
		self::render_modulos_recusados( $relatorio );
		self::render_modulos( $relatorio );
		self::render_options_sem_modulo( $relatorio );

		echo '</section>';
	}

	/**
	 * O QUE O FILTRO `f3base_modulos` OFERECEU E O REGISTRO NÃO ACEITOU.
	 *
	 * Fica ANTES dos cartões porque a pergunta que ele responde vem primeiro:
	 * quem acrescentou um módulo e não o encontra na lista precisa ler o motivo
	 * antes de procurar o cartão que não existe. Sem item, o bloco inteiro não
	 * é impresso — aviso que sai sempre treina o operador a ignorar aviso.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_modulos_recusados( array $relatorio ): void {
		$recusados = isset( $relatorio['modulos_recusados'] ) && is_array( $relatorio['modulos_recusados'] )
			? $relatorio['modulos_recusados']
			: array();

		if ( array() === $recusados ) {
			return;
		}

		echo '<h3>' . esc_html__( 'Partes que o registro NÃO aceitou', 'f3base' ) . '</h3>';
		printf(
			'<p class="description">%s</p>',
			esc_html__( 'Nomes oferecidos ao registro pelo filtro f3base_modulos e recusados, com o motivo de cada um. Enquanto o nome estiver aqui, aquela parte não registra hook nenhum e não aparece na lista abaixo.', 'f3base' )
		);

		echo '<ul class="f3base-lista f3base-avisos">';

		foreach ( $recusados as $recusado ) {
			if ( ! is_array( $recusado ) ) {
				continue;
			}

			printf(
				'<li><span class="f3base-chip f3base-chip--aviso">%1$s</span> <code>%2$s</code> — %3$s</li>',
				esc_html__( 'RECUSADO', 'f3base' ),
				esc_html( (string) ( $recusado['nome'] ?? '' ) ),
				esc_html( (string) ( $recusado['motivo'] ?? '' ) )
			);
		}

		echo '</ul>';
	}

	/**
	 * Resumo por estado.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_resumo( array $relatorio ): void {
		$resumo = is_array( $relatorio['resumo'] ) ? $relatorio['resumo'] : array();

		echo '<ul class="f3base-resumo">';

		foreach ( array( F3Base_Modulo::ATIVO, F3Base_Modulo::DEGRADADO, F3Base_Modulo::INATIVO ) as $estado ) {
			printf(
				'<li class="f3base-chip f3base-chip--%1$s"><strong>%2$d</strong> %3$s</li>',
				esc_attr( $estado ),
				(int) ( $resumo[ $estado ] ?? 0 ),
				esc_html( self::rotulo_estado( $estado ) )
			);
		}

		echo '</ul>';
	}

	/**
	 * Cartões dos módulos.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_modulos( array $relatorio ): void {
		$modulos = is_array( $relatorio['modulos'] ) ? $relatorio['modulos'] : array();

		foreach ( $modulos as $modulo ) {
			if ( ! is_array( $modulo ) ) {
				continue;
			}

			$estado = (string) $modulo['estado'];

			echo '<div class="f3base-modulo">';

			printf(
				'<h3>%1$s <code>%2$s</code> <span class="f3base-chip f3base-chip--%3$s">%4$s</span></h3>',
				esc_html( (string) $modulo['nome'] ),
				esc_html( (string) $modulo['id'] ),
				esc_attr( $estado ),
				esc_html( self::rotulo_estado( $estado ) )
			);

			printf( '<p class="f3base-descricao">%s</p>', esc_html( (string) $modulo['descricao'] ) );

			if ( '' !== (string) $modulo['motivo'] ) {
				printf(
					'<p class="f3base-motivo"><strong>%1$s</strong> %2$s</p>',
					esc_html__( 'Motivo:', 'f3base' ),
					esc_html( (string) $modulo['motivo'] )
				);
			}

			self::render_avisos( isset( $modulo['avisos'] ) && is_array( $modulo['avisos'] ) ? $modulo['avisos'] : array() );
			self::render_dependencias( is_array( $modulo['dependencias'] ) ? $modulo['dependencias'] : array() );
			self::render_options_do_modulo( is_array( $modulo['options'] ) ? $modulo['options'] : array() );
			self::render_hooks( is_array( $modulo['hooks'] ) ? $modulo['hooks'] : array(), (bool) $modulo['registra_hooks'] );
			self::render_atividade( is_array( $modulo['atividade'] ) ? $modulo['atividade'] : array() );

			echo '</div>';
		}
	}

	/**
	 * Dependências de um módulo.
	 *
	 * @param array<int,mixed> $dependencias Dependências declaradas.
	 * @return void
	 */
	private static function render_dependencias( array $dependencias ): void {
		if ( array() === $dependencias ) {
			return;
		}

		echo '<h4>' . esc_html__( 'Do que depende', 'f3base' ) . '</h4><ul class="f3base-lista">';

		foreach ( $dependencias as $dependencia ) {
			if ( ! is_array( $dependencia ) ) {
				continue;
			}

			printf(
				'<li class="%1$s"><strong>%2$s</strong> — %3$s</li>',
				esc_attr( ! empty( $dependencia['presente'] ) ? 'f3base-ok' : 'f3base-falta' ),
				esc_html( (string) $dependencia['rotulo'] ),
				esc_html( (string) $dependencia['detalhe'] )
			);
		}

		echo '</ul>';
	}

	/**
	 * Options que controlam um módulo.
	 *
	 * @param array<int,mixed> $options Linhas de option.
	 * @return void
	 */
	private static function render_options_do_modulo( array $options ): void {
		if ( array() === $options ) {
			return;
		}

		echo '<h4>' . esc_html__( 'Ajustes que controlam esta parte', 'f3base' ) . '</h4>';
		echo '<table class="widefat striped f3base-options"><thead><tr>';
		printf( '<th>%s</th>', esc_html__( 'Ajuste', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Valor atual', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Última gravação', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Edição', 'f3base' ) );
		echo '</tr></thead><tbody>';

		foreach ( $options as $option ) {
			if ( ! is_array( $option ) ) {
				continue;
			}

			printf(
				'<tr><td><strong>%1$s</strong><br /><code>%2$s</code></td><td><pre>%3$s</pre></td><td>%4$s%5$s</td><td>%6$s</td></tr>',
				esc_html( (string) $option['rotulo'] ),
				esc_html( (string) $option['nome'] ),
				esc_html( (string) $option['valor_texto'] ),
				esc_html( (string) $option['origem_rotulo'] ),
				(int) $option['carimbo'] > 0
					? '<br /><span class="description">' . esc_html( (string) wp_date( 'd/m/Y H:i', (int) $option['carimbo'] ) ) . '</span>'
					: '',
				! empty( $option['operavel'] )
					? esc_html__( 'editável no formulário acima', 'f3base' )
					: esc_html__( 'sem campo nesta tela: é ajuste estrutural', 'f3base' )
			);
		}

		echo '</tbody></table>';
	}

	/**
	 * Hooks declarados por um módulo.
	 *
	 * @param array<int,mixed> $hooks     Hooks declarados.
	 * @param bool             $registrou Se o módulo registrou os hooks.
	 * @return void
	 */
	private static function render_hooks( array $hooks, bool $registrou ): void {
		if ( array() === $hooks ) {
			return;
		}

		printf(
			'<h4>%1$s <span class="description">%2$s</span></h4>',
			esc_html__( 'Onde esta parte se liga ao WordPress', 'f3base' ),
			esc_html(
				$registrou
					? __( 'ligada nesta requisição.', 'f3base' )
					: __( 'não ligada: esta parte está parada, sem endereço, sem tabela e sem arquivo próprio. O item marcado SEMPRE abaixo é a exceção, e ela é declarada.', 'f3base' )
			)
		);

		echo '<ul class="f3base-lista f3base-hooks">';

		foreach ( $hooks as $hook ) {
			if ( ! is_array( $hook ) ) {
				continue;
			}

			printf(
				'<li><code>%1$s</code> %2$s <span class="description">%3$s</span></li>',
				esc_html( (string) $hook['hook'] ),
				esc_html( (string) $hook['tipo'] ),
				esc_html(
					empty( $hook['sempre'] )
						? sprintf(
							/* translators: 1: método, 2: prioridade. */
							__( '%1$s, prioridade %2$d', 'f3base' ),
							(string) $hook['metodo'],
							(int) $hook['prioridade']
						)
						: sprintf(
							/* translators: 1: método, 2: prioridade. */
							__( '%1$s, prioridade %2$d — registrado SEMPRE: a decisão dele é por bloco, e o caso mais importante dela acontece com o módulo inativo.', 'f3base' ),
							(string) $hook['metodo'],
							(int) $hook['prioridade']
						)
				)
			);
		}

		echo '</ul>';
	}

	/**
	 * AVISOS do módulo: funciona, e custa isto.
	 *
	 * Fica ANTES das dependências de propósito: quem abre a tela por causa de um
	 * número que não bate precisa ler primeiro o que continua funcionando com
	 * preço, e não descobrir isso no fim da lista.
	 *
	 * @param array<int,mixed> $avisos Avisos declarados pelo módulo.
	 * @return void
	 */
	private static function render_avisos( array $avisos ): void {
		if ( array() === $avisos ) {
			return;
		}

		echo '<h4>' . esc_html__( 'Funciona, e custa isto', 'f3base' ) . '</h4><ul class="f3base-lista f3base-avisos">';

		foreach ( $avisos as $aviso ) {
			if ( ! is_array( $aviso ) ) {
				continue;
			}

			printf(
				'<li><span class="f3base-chip f3base-chip--aviso">%1$s</span> %2$s</li>',
				esc_html( (string) ( $aviso['estado'] ?? '' ) ),
				esc_html( (string) ( $aviso['motivo'] ?? '' ) )
			);
		}

		echo '</ul>';
	}

	/**
	 * Última atividade relevante.
	 *
	 * @param array<int,mixed> $atividade Frases de atividade.
	 * @return void
	 */
	private static function render_atividade( array $atividade ): void {
		if ( array() === $atividade ) {
			return;
		}

		echo '<h4>' . esc_html__( 'O que aconteceu por último', 'f3base' ) . '</h4><ul class="f3base-lista">';

		foreach ( $atividade as $frase ) {
			printf( '<li>%s</li>', esc_html( (string) $frase ) );
		}

		echo '</ul>';
	}

	/**
	 * Options gerenciadas que nenhum módulo reivindica.
	 *
	 * @param array<string,mixed> $relatorio Relatório do registro.
	 * @return void
	 */
	private static function render_options_sem_modulo( array $relatorio ): void {
		$options = is_array( $relatorio['options_sem_modulo'] ) ? $relatorio['options_sem_modulo'] : array();

		if ( array() === $options ) {
			return;
		}

		echo '<h3>' . esc_html__( 'Ajustes que nenhuma parte reivindica', 'f3base' ) . '</h3>';
		printf(
			'<p class="description">%s</p>',
			esc_html__( 'Gravados pelo implantador ou pelo próprio plugin como estado de execução. Aparecem aqui para que nenhum ajuste do site fique invisível.', 'f3base' )
		);

		echo '<table class="widefat striped f3base-options"><thead><tr>';
		printf( '<th>%s</th>', esc_html__( 'Ajuste', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Valor atual', 'f3base' ) );
		printf( '<th>%s</th>', esc_html__( 'Última gravação', 'f3base' ) );
		echo '</tr></thead><tbody>';

		foreach ( $options as $option ) {
			if ( ! is_array( $option ) ) {
				continue;
			}

			printf(
				'<tr><td><code>%1$s</code><br /><span class="description">%2$s</span></td><td><pre>%3$s</pre></td><td>%4$s</td></tr>',
				esc_html( (string) $option['nome'] ),
				esc_html( (string) $option['descricao'] ),
				esc_html( (string) $option['valor_texto'] ),
				esc_html( (string) $option['origem_rotulo'] )
			);
		}

		echo '</tbody></table>';
	}

	/* ------------------------------------------------------------------ *
	 * Apoio
	 * ------------------------------------------------------------------ */

	/**
	 * Prepara o valor enviado conforme a forma declarada da option.
	 *
	 * @param string              $nome       Nome da option.
	 * @param array<string,mixed> $declaracao Declaração do catálogo.
	 * @param mixed               $enviado    Valor enviado.
	 * @param bool                $apagar     A caixa "apagar o valor gravado" veio marcada.
	 * @return mixed
	 */
    private static function preparar(string $nome,array $d,$v,bool $apagar=false) {
        if(($d['campo']??'')==='segredo'&&($apagar||$v==='')){return $apagar?'':F3Base_Options::ler($nome);}
        return F3Base_Admin_Entrada::converter($d,$v,$nome);
    }

	/**
	 * Resume um valor lido de volta para exibição.
	 *
	 * @param mixed $valor Valor lido.
	 * @return string
	 */
	private static function resumir( $valor ): string {
		if ( is_array( $valor ) ) {
			$json = wp_json_encode( $valor, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

			return is_string( $json ) ? $json : '';
		}

		if ( is_bool( $valor ) ) {
			return $valor ? '1' : '0';
		}

		return (string) $valor;
	}

	/**
	 * Rótulo humano de um estado.
	 *
	 * @param string $estado Estado do módulo.
	 * @return string
	 */
	private static function rotulo_estado( string $estado ): string {
		switch ( $estado ) {
			case F3Base_Modulo::ATIVO:
				return __( 'funcionando', 'f3base' );
			case F3Base_Modulo::DEGRADADO:
				return __( 'funcionando com ressalva', 'f3base' );
			default:
				return __( 'parado', 'f3base' );
		}
	}
}
