# Fator3 Site Core 1.95.0

Leia docs/DOCUMENTACAO.md e docs/RELEASE-1.95.0.md para configurar o destino técnico e conferir agenda e catálogo.
