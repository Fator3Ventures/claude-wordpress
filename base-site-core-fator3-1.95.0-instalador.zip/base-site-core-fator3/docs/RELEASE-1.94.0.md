# Site Core 1.94.0

Instalação nova ou atualização direta da 1.93.0. WordPress 7.1.4 ou superior e PHP 8.3 ou superior, de 64 bits. Instalação única. Contrato administrativo 8.45.0.

## Pedido 430 · registro do canal MCP

O Core usa a leitura passiva ServerContract::status do MCP após wp_loaded e fora da inicialização das abilities, do REST e do adaptador. Uma leitura com registro ainda desconhecido preserva o estado. A observação ativa do canal continua com o MCP 0.48.0. A ausência do plugin acompanhante desativa essa observação. Servidor desabilitado ou núcleo do canal ausente têm códigos próprios. Um registro completo com rota em conflito, rota ausente, servidor ausente ou ferramentas faltando abre o incidente. Um registro verificado saudável permite a recuperação. A verificação tem alcance local ao WordPress.

## Como conferir um episódio

1. Com acesso administrativo, consulte f3base/incidentes-tecnicos-ler. Se proximo tiver valor, use-o como apos na consulta seguinte.
2. Localize o item do pacote canal com codigo canal_indisponivel e historico_registro. Esse campo aparece na primeira transição nova do recurso registro-wordpress após a atualização. Outros recursos seguem com a projeção existente.
3. Percorra as últimas 12 transições, em ordem cronológica. estado e desde_informado vêm do evento. recebido_em e marcos descrevem a requisição que o aceitou. origem identifica observador_core ou publicador_canal. contexto distingue cli, http_cron e web. versao_core e versao_canal identificam os pacotes carregados.
4. Em registro_na_recepcao, verificado informa se as rotas puderam ser examinadas e erros contém códigos locais permitidos. null indica ausência de leitura conclusiva disponível para esse rastro. Uma transição atrasada na fila do MCP pode chegar em outro contexto. Consulte system/health em uma requisição autenticada e compare os horários. O histórico adicional acompanha cada mudança de estado mesmo depois que o e-mail sai da fila.
5. As transições anteriores à instalação conservam seus recibos. O histórico novo começa na primeira mudança observada e não reconstrói a causa de episódios anteriores.

## Configuração e transporte

O destino continua em Site Core, Avisos técnicos por e-mail. Uma opção vazia conserva as entregas pendentes. O observador usa os mesmos identificadores de incidente e respeita as reservas existentes. A abertura e a recuperação seguem pela fila do Core. O rastro omite identificadores de conta, URL, argumentos, tokens e texto de exceção.

## Verificação da atualização

Consulte f3base/como-usar com compacto=true. Confira versao_alvo 1.94.0, estado concluida, zero falhas e a data de confirmação no executor. Consulte f3base/documentacao-ler com arquivo docs/RELEASE-1.94.0.md e siga proxima_linha até o fim. A atualização usa as opções existentes. Falha que exija alterar código é corrigida em uma nova versão.
