# Site Core 1.95.0

Instalação nova ou atualização direta da 1.94.0. Requer WordPress 7.1.4 ou superior, PHP de 64 bits a partir de 8.3 e instalação única. O contrato administrativo continua na versão 8.45.0.

## Registro do canal MCP

O MCP 0.50.0 decide quando abrir e recuperar o incidente de registro pelo método local ChannelIncidents::observeRegistration(). Tanto o observador do Core quanto o do MCP consultam esse mesmo método. A primeira falha web fica como suspeita. Uma segunda requisição HTTP elegível com falha confirma a abertura. Uma leitura saudável posterior recupera o episódio. Repetir os observadores na mesma requisição conta uma vez. WP-CLI e a fase incompleta de inicialização preservam o estado. Sem o método do canal, o Core conserva a fila e continua atendendo os demais produtores.

O Core mantém a fila, as reservas de e-mail e até 12 mudanças de estado em historico_registro. Nas novas transições, origem é publicador_canal. O snapshot passivo registro_na_recepcao descreve o momento em que o Core recebeu o evento. Uma entrega enfileirada no produtor pode ter sido observada antes. As entradas históricas mantêm sua origem original.

## Consulta da validade da chave Google

Se o Google 0.38.0 informar falta de permissão para ler os metadados da chave, o episódio usa pacote google, código autorizacao_recusada e recurso estável da conexão. No aviso de abertura, o assunto indica “validade da chave não consultável”. O corpo identifica a permissão iam.serviceAccountKeys.get e o projeto público informado pelo produtor. Quando o projeto está ausente ou fora do formato esperado, o campo projeto é nulo e o e-mail exibe “não informado”. Consulte no painel Google a conexão e a identidade da conta de serviço.

Na leitura administrativa f3base/incidentes-tecnicos-ler o objeto opcional iam contém permissao e projeto. Os dados IAM ficam restritos a esse tipo de incidente. A API pode continuar retornando métricas do GA4 enquanto a leitura dos metadados da chave está recusada. Depois que o produtor confirmar a recuperação, o mesmo episódio muda para recuperado.

O coletor do Core também pode completar um episódio que já estava aberto na 1.94.0. A abertura que já saiu da fila ganha detalhes no registro e mantém o recibo original. Uma abertura que continua pendente recebe os detalhes antes da entrega. Uma reserva incerta exige reconciliação com o transporte. Uma nova tentativa de coleta conserva a mesma referência e a ordem da fila.

## Conferência pelo operador

1. Consulte f3base/como-usar com compacto=true. Confira versao_alvo 1.95.0, estado concluida, falhas 0 e confirmada_no_executor_em preenchida.
2. Use f3base/documentacao-ler com arquivo docs/RELEASE-1.95.0.md. Siga proxima_linha até o fim e confira o SHA-256.
3. Com acesso administrativo, consulte f3base/incidentes-tecnicos-ler e siga o cursor proximo no argumento apos. Para o canal, observe horário, contexto e origem das novas transições. Para a recusa IAM, confira iam.permissao, iam.projeto e a referência estável do episódio.
4. O destino fica em Site Core → Avisos técnicos por e-mail. Um endereço vazio conserva as entregas pendentes. A confirmação na caixa exige um destinatário autorizado. A release não exige uma credencial nova.
