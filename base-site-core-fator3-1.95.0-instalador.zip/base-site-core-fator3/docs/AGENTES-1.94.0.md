# Operação do Site Core 1.94.0

Leia DOCUMENTACAO.md e RELEASE-1.94.0.md. Consulte f3base/como-usar com compacto=true para conferir a atualização. Use f3base/incidentes-tecnicos-ler com acesso administrativo e percorra o cursor proximo até o fim. No registro do canal, relacione estado, produtor e erros com uma chamada autenticada feita no mesmo período. Os horários são timestamps Unix. Uma entrega reservada exige conferir o transporte antes da reconciliação. O contrato administrativo é 8.45.0.
