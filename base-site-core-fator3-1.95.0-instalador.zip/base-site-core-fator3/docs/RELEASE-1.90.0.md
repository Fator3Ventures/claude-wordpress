# Fator3 Site Core 1.90.0

Instalação nova ou atualização direta da 1.89.2. WordPress 7.1.4 ou superior, PHP 8.3 ou superior de 64 bits. Contrato administrativo 8.42.0.

## Pedidos core 418 e 419

O catálogo comercial passa a 1.350 códigos na revisão 2026-11-16.1. LM-X525 identifica o LG Q60, de 2019, com preço estimado de R$ 259,00 na referência brasileira de seminovos. A ficha indica faixa intermediária e linha premium “não”. Os nomes regionais usados na pesquisa compartilham o Device mmh4p.

O índice complementar contém 44.528 códigos distintos com Model preenchido na lista Google Play de 15/11/2026. O runtime abre um dos 256 fragmentos locais comprimidos quando necessário. A lista tem 43.102 códigos com nome comercial utilizável. Nos 624 casos ambíguos e nos 802 sem nome comercial publicado, o Core conserva o Model técnico e sinaliza o critério. A marca e o Device só são preenchidos quando determinados. A ficha complementar mantém desconhecidos ano, preço, faixa comercial e linha premium. O Slack identifica o modelo e distingue o código técnico dos nomes comerciais.

Com manage_options, leia f3base/aparelhos-sem-nome-ler com limite entre 1 e 200. Continue com proximo_apos como apos até o cursor nulo. sem_nome lista códigos ausentes nas duas bases, sem_ficha_comercial agrega os reconhecidos pela base complementar e itens conserva o conteúdo de sem_nome. A leitura conta perfis retidos. f3base/como-usar informa a data, o total e o SHA-256 do CSV em catalogo_aparelhos.google_play. No fonte, execute python3 build/gerar-google-play.py --google-play reference/417/supported_devices.csv --data AAAA-MM-DD, confira os nomes e execute tests/google-play-integridade.py. A referência congelada tem SHA-256 74f0ced35bdfa216580c030477db29be01f5cc3e62e7196855c7519503d735bd.

## Pedido core 420

Os seis ganchos de fila conciliam somente a ocorrência solicitada na opção cron. A leitura direta e a gravação condicional resolvem a disputa entre HTTP e WP-CLI, conservando alterações concorrentes detectadas e confirmando operações já persistidas. Uma falha efetiva do banco continua visível. Quando a reserva única recusa uma segunda execução, o diário da passagem recusada identifica a origem concorrente e a execução proprietária. Pipedrive registra o resultado da verificação de orçamento, e o LinkedIn agrega os resultados por integração.

A recuperação CAPI conserva a passagem diária. Um registro pendente novo recebe uma tentativa individual. Se a agenda individual falhar e o prazo vencer antes da passagem regular, o Core solicita recuperação antecipada. Repetir a inserção ou ler a fila não antecipa a recuperação. Cancelamentos e revogações com limpeza nova também podem acordar o trabalhador. A resposta distingue a confirmação da agenda diária de uma mudança efetiva da antecipação.

Para o aceite do CTO Office, registre o horário da implantação, leia as duas listas até o fim e, após 24 horas corridas, conte os erros could_not_set dos seis ganchos, as ocorrências duplicadas, os resultados de fila e os motivos das antecipações. O critério é menos de dez erros somados, zero duplicações e filas sem falha.
