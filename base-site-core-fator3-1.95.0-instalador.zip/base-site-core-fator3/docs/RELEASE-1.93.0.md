# Fator3 Site Core 1.93.0

Instalação nova ou atualização da 1.92.1. Requer WordPress 7.1.4+, PHP 8.3+ de 64 bits e instalação única. Contrato administrativo 8.45.0.

## Catálogo de aparelhos

O compilador local rejeita países e regiões, inclusive listas. O Device só fornece outro nome para um Model técnico que ainda exibe seu código, tem formato alfanumérico de SKU, não contém espaço e não contém marca ou série. O catálogo brasileiro curado tem precedência. Entre registros do próprio Model, uma grafia comercial publicada ou um Model comercial com dados conflitantes prevalece sobre marca isolada, classe genérica e codinome sem identificação de variante. O relatório lista cada diferença nos índices. O catálogo compilado vale para códigos consultados pela primeira vez. Uma nova publicação do Google Play requer recompilação.

## Agenda do cron

A opção cron é invalidada antes dos observadores e no encerramento das notificações de uma escrita confirmada. Em f3base/execucoes-ler, dados.gravacoes_proprias_cron conta escritas de agenda confirmadas no banco durante aquela passagem. Operações idempotentes e tentativas concorrentes que perderam a comparação valem zero. Passagens históricas encerradas antes da atualização não têm o campo. Para o aceite, procure passagem CLI com pelo menos dez ganchos Core, confira os nativos no log, duplicação e perda por ocorrência. Uma janela sem passagem elegível é inconclusiva.

## Central de avisos técnicos

No painel de configuração do Site Core, abra o grupo Avisos técnicos por e-mail. Preencha email, salve e releia. O campo antecedencia_dias aceita 1 a 365 dias, padrão 14. Ative resumo_diario para receber a lista de abertos uma vez por dia no fuso WordPress. Com email vazio, o Core guarda as transições em fila. A consulta administrativa f3base/incidentes-tecnicos-ler retorna até 50 itens e um cursor proximo para apos. A referência HMAC identifica o recurso sem expor sua identificação original, credencial, URL fornecida pelo cliente ou informação de lead.

Publique observações locais com o filtro f3base_incidente_publicar_v1, passando null e um array com pacote, codigo, recurso e estado (aberto ou recuperado). desde é um timestamp UTC em segundos, acao_humana é booleano e rota é opcional. A rota deve ser a entrada administrativa registrada em F3Base_Incidentes::ROTAS para o pacote. As categorias permitidas estão em F3Base_Incidentes::CODIGOS. A chave funcional é pacote + código + recurso no site. Use o mesmo recurso na recuperação. Exemplo de falha de uma agenda:

```php
$evento = [
    'pacote' => 'meta', 'codigo' => 'agenda_parada', 'recurso' => $idEstavel,
    'estado' => 'aberto', 'desde' => time(), 'acao_humana' => true,
];
$resposta = apply_filters('f3base_incidente_publicar_v1', null, $evento);
```

Para recuperar, envie estado recuperado. Uma resposta null indica ausência do contrato, ocupado exige nova observação. O Core reserva a transição antes do transporte. A confirmação do wp_mail informa aceitação local. Após recusa confirmada o Core reavalia em cinco minutos. Uma reserva com entrega incerta requer conferência do provedor SMTP antes de qualquer reenvio. A próxima observação periódica ocorre em passagem do zelador ou acesso administrativo. Um WordPress completamente parado precisa de monitor externo para ser observado.

Para prazos conhecidos, use F3Base_Incidentes::vencimento(pacote, codigo, recurso, epoch). As leituras locais abrangem validade do token e do refresh do LinkedIn e prova individual do GA4 e Google Ads. A CAPI usa a versão Graph efetiva e o calendário f3base_graph_fim_versoes, em UTC. A referência da Meta para v21.0 indica 21/01/2027. A agenda CLI entra em atenção depois de uma hora sem passagem e se recupera na passagem seguinte.

E-mails nativos permitidos de atualização de plugins, temas e núcleo e do modo de recuperação usam o destino técnico. Com destino vazio, o painel pede a configuração e o Core guarda a ocorrência de e-mail nativo pendente de destino. Ao configurar o endereço, a equipe recebe a abertura e a recuperação. Para uma chave de recuperação fatal, o WordPress precisa gerar uma nova mensagem. A central não arquiva o conteúdo ou a chave de recuperação. O Slack continua disponível para avisos de contatos nos sites que o configuraram.

Quando uma entrega ficar em `reservado`, confira o log do transporte. Um administrador pode usar `f3base/incidente-entrega-reconciliar` com `id` e `reserva` lidos em `f3base/incidentes-tecnicos-ler`. O resultado `aceito` consome essa transição. `nao_enviado` libera uma nova tentativa pelo zelador. A reserva muda a cada tentativa e o Core rejeita a reutilização. O estado registra o operador e o instante da conferência. O monitoramento de recebimento de eventos da Meta usa o e-mail técnico também nos sites que antes selecionavam Slack.

Calendário da Graph API consultado em 18/11/2026. [Histórico oficial das versões da Meta](https://developers.facebook.com/docs/graph-api/changelog/versions/).
