# Fator3 Site Core 1.92.1

Pedido 428 · 17/11/2026. Instalação nova ou atualização direta da 1.92.0. WordPress 7.1.4+, PHP 8.3+ de 64 bits. Contrato administrativo 8.44.0. Revisão do catálogo 2026-11-17.3, snapshot Google Play de 15/11/2026.

## Como o nome é escolhido

1. A correção local e a ficha brasileira exata têm precedência. O nome obtido para o próprio Model na fonte Google Play é a referência inicial. A classificação de mercado é aplicada também às linhas do próprio Model.
2. Só se avalia outro Model se o nome inicial corresponder exatamente ao código após normalizar caixa e espaços. A comparação preserva pontuação e sufixos. O código precisa ser compacto, conter um algarismo e usar apenas letras ASCII, dígitos e separadores internos hífen ou sublinhado. Um nome com espaço, marca publicada ou palavra de série fica protegido. As marcas vêm do snapshot e o vocabulário de séries inclui termos como Moto, Edge, Galaxy, Blade, Power e Pro. A regra funciona para entradas futuras do compilador.
3. O candidato vem de outro Model. O campo de marketing precisa sustentar uma identidade comercial. Um código compacto de outro aparelho ou uma indicação exclusivamente territorial é insuficiente. O filtro reconhece países, regiões, siglas e listas de mercados, normaliza caixa e pontuação e trata o rótulo completo. Um nome de produto pode conter uma palavra geográfica.
4. A transferência exige uma marca, um Device e concordância entre os nomes candidatos. Um irmão que publica o próprio nome de venda conta como evidência de conflito. Diante de dúvida, o código mantém a identificação própria. O catálogo completo é compilado antes de distribuir o plugin.
5. Para um Model ausente, a regra regional aceita uma única letra final variante se houver dois ou mais irmãos publicados com a mesma marca, Device e nome comercial comprovado. Sem correspondência exata, família válida ou ficha local, o código fica em `sem_nome`. Nenhuma busca externa ocorre durante a visita.
6. Observações antigas com identificação Google Play são resolvidas de novo na leitura. Se uma família perdeu a sustentação, o nome inferido cede lugar ao código observado. A observação original e sua faixa histórica ficam preservadas no banco.

## Conferência

Com `manage_options`, execute `f3base/aparelhos-sem-nome-ler` com `{"apos":"motorola one macq","limite":1}` em um site com o aparelho retido. Confira o código recebido, o nome `motorola one macro` e o Device `lima` em `sem_ficha_comercial`. Uma ficha completa local ou embarcada retira o aparelho dessa lista. O cursor é exclusivo e a consulta cobre somente perfis dentro da retenção.

As fichas brasileiras de `25062rn2da` (Redmi 15) e `lm-x420` (LG K40) têm prioridade. A atualização dispensa reimportação e regravação dos perfis. O relatório de entrega discrimina as 412 decisões da versão anterior.
