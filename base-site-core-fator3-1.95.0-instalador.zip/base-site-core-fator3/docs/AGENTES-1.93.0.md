# Operação do Site Core 1.93.0

Leia DOCUMENTACAO.md e RELEASE-1.93.0.md. Releia o destino de f3base_avisos_tecnicos antes da aceitação. Consulte f3base/incidentes-tecnicos-ler, f3base/execucoes-ler e f3base/aparelhos-sem-nome-ler. A instalação identifica a versão e o contrato 8.45.0.
