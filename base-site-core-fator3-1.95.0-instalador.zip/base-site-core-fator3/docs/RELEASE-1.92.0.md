# Fator3 Site Core 1.92.0

Publicação de 17/11/2026 para instalação nova ou atualização da 1.91.0. WordPress 7.1.4+, PHP 8.3+ de 64 bits. Contrato administrativo 8.44.0; dicionário de dados 8.39.0 (sem alteração física de tabelas).

## Agenda: pedido 426

A agenda própria passa a cobrir o prefixo inteiro `f3base_`, incluindo ocorrências únicas e recorrentes, com argumentos vazios ou preenchidos. Identidade: timestamp, gancho e hash dos argumentos serializados. A gravação aplica somente o delta da ocorrência, com comparação atômica do valor anterior; não sobrescreve as demais ocorrências lidas depois de uma disputa.

Os três filtros são reposicionados no fim de PHP_INT_MAX. Os observadores nulos conhecidos do sensor WP Activity Log 5.7.0 continuam sendo executados; a decisão anterior é conservada se o observador a substituir por null. Isso também reconhece a composição já instalada pelo Meta 0.28.0. O sensor original é devolvido imediatamente antes de sua execução, preservando seu reconhecimento pelos demais plugins nas operações seguintes. False e WP_Error de outros filtros continuam vetando a operação. Falha de banco continua sendo erro. Ganchos de outros plugins conservam seu comportamento.

`f3base/como-usar` (inclusive compacto), bloco `agenda_das_filas`, acrescenta `cobertura: f3base_*`, `ganchos_cobertos`, `eventos_unicos`, `eventos_recorrentes` e `argumentos: identidade_serializada`. A lista reúne o registro de tarefas, agendas auxiliares, ganchos presentes na agenda e os observados no processo. O prefixo declarado também cobre ganchos novos sem exigir atualização de uma lista fixa. As seis filas mantêm a proteção que impede consumir antecipação sem trabalhador carregado.

## Aparelhos: pedido 427

A referência Google Play continua sendo a base publicada em 15/11/2026, com 44.528 códigos Model. A regra de identificação tem revisão `2026-11-17.2`.

Para um nome ainda técnico, o compilador consulta outros modelos com o mesmo Device não vazio. Um nome candidato precisa diferir tanto do código consultado quanto de seu próprio Model. Espaços, pontuação de grafia e sufixos regionais conhecidos não criam nomes diferentes; o sinal + é preservado como variante. Se existir uma única identidade comercial, uma marca e um Device, o resultado usa `nome_google`. Havendo identidades conflitantes, conserva o código técnico com `modelo_ambiguo`. Não escolhe pelo nome mais frequente para esses casos entre modelos.

Um código ausente pode usar `familia_google` se diferir apenas na última letra de um prefixo presente em pelo menos dois irmãos publicados, todos com a mesma marca, Device e nome comercial inequívoco. O índice exato tem precedência. Famílias conflitantes ou com nome técnico não geram inferência. O índice de famílias é local e carregado sob demanda; não há consulta remota na visita.

A compilação registra 1.939 decisões entre modelos: 412 nomes resolvidos e 1.527 ambiguidades. Há 313 famílias aceitas. As listas de auditoria e o CSV integral ficam no pacote fonte, em `reference/427` e `reference/417`; o instalador contém os índices de consulta.

As fichas brasileiras de `25062rn2da` (Redmi 15, 2025, R$ 1.500 estimados) e `lm-x420` (LG K40, 2019, R$ 200 estimados no mercado usado) foram adicionadas. As 30 fichas anteriores da frota permanecem. Preço é estimativa de referência, sem promessa de oferta. Correções locais do site continuam tendo precedência.

## Integrações e aceite

Meta 0.28.0 e LinkedIn 0.25.0 incorporam as correções próprias solicitadas pelo Core 1.91.0. Esta versão não exige mudança adicional nos contratos desses pacotes. O contrato administrativo do Core acrescenta os campos de diagnóstico e documenta o critério `familia_google`.

Confira `f3base/aparelhos-sem-nome-ler`: os dois códigos adicionados devem ter ficha completa. Para a agenda, observe por 24 horas após a troca: nenhum `could_not_set` em qualquer `f3base_*`, nenhuma execução duplicada e migração concluída. O relatório externo da entrega distingue os testes executados da observação de 24 horas ainda pendente. A aceitação anterior do pedido 423 continua independente desta nova janela.
