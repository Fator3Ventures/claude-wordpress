# Operação do Site Core 1.95.0

Comece por DOCUMENTACAO.md e RELEASE-1.95.0.md. Consulte f3base/como-usar com compacto=true para conferir a migração. Use f3base/incidentes-tecnicos-ler com permissão administrativa. Percorra proximo no parâmetro apos. Com o MCP 0.50.0, duas falhas web distintas confirmam o incidente de registro. Com o Google 0.38.0, a recusa da consulta IAM identifica a permissão e o projeto na leitura e no aviso. Consulte a fila e o destino antes de habilitar entrega. Uma reserva incerta exige conferir o transporte. O contrato de configuração é 8.45.0.
