# Fator3 Site Core 1.91.0

Publicação de 17/11/2026 para instalação nova ou atualização da 1.90.0. WordPress 7.1.4+, PHP 8.3+ de 64 bits. Contrato administrativo 8.43.0 e dicionário de dados 8.39.0.

## 421 · Acervo GA4

Cada passagem atende uma página de um dia e recorte até ontem no fuso da propriedade configurado no Core. O coletor alterna a janela recente com o histórico pendente. A primeira página vazia encerra aquele recorte. Antes, o histórico vazio podia voltar depois de 24 horas e havia mais uma chamada para descobrir o fim. Agora o histórico concluído ou sem dados permanece terminal. A janela recente pode voltar no próximo dia local. A continuação cai em um quarto de hora UTC, respeita a cota e cede lugar à coleta diária seguinte se esta já for suficiente. Com N páginas elegíveis, uma passagem diária e max(0, N − 1) continuações atendem o lote quando não há falha nem interrupção. O total diário depende da paginação, janelas e retentativas de cada propriedade.

Leia f3base/como-usar, campo continuacao_ga4, e f3base/ga4-status. Compare cron/list com os horários do executor e os recibos completos em f3base/execucoes-ler.

## 422 · Catálogo

A fonte Google Play de 15/11/2026 contém 44.528 modelos. A compilação examina nomes publicados para o Model no mesmo par de fabricante e Device. Quando existem vários nomes substantivamente diferentes, compara a frequência no Device. Empates e vínculos entre aparelhos distintos conservam o Model com modelo_ambiguo. Pontuação, espaços, capitalização e sufixos regionais equivalentes preservam o nome técnico. Para LM-X525/mmh4p prevalece LG Q60, nome brasileiro solicitado expressamente nos pedidos 418 e 422. A tabela comercial de 1.350 códigos permanece consultável por prioridade. As revisões da base comercial e do índice Google são independentes. O campo google_play.regra identifica a nova compilação. O fonte inclui a decisão de cada modelo em reference/422/auditoria.csv.

## 423 · Agenda das seis filas

O Core registra sua agenda no arquivo principal, antes da seleção do perfil. No fim de wp_loaded e diante de um registro tardio, coloca os callbacks do Core por último nos três filtros pre_schedule_event, pre_reschedule_event e pre_unschedule_event. O próximo timestamp de evento recorrente segue o cálculo do WordPress. Uma mudança confirmada pela comparação e troca da opção cron termina com true. Para a antecipação avulsa vencida, um processo cron sem callback do trabalhador conserva a ocorrência. A escrita concorrente é repetida contra a opção atual, preservando eventos alheios. O diagnóstico agenda_das_filas expõe o perfil e os plugins reposicionados ou ainda posteriores. A leitura de observações de cron inclui o diagnóstico de origem. O comportamento aplica-se aos seis ganchos declarados em F3Base_Fila::RECORRENCIAS.

Quem mantém eventos avulsos Meta ou LinkedIn deve identificar o evento pela combinação de hook, argumentos e horário. Uma ocorrência encontrada sob a mesma chave pode confirmar uma escrita. Uma ocorrência ausente, atrasada para além do prazo ou com argumentos diferentes exige recuperação com o trabalho ainda pendente. Só o executor confirma processamento.

## 424 · Diálogo e eventos de interação

O adaptador abre o diálogo imediatamente. A análise captura o instante do evento e usa a mesma fila em ordem de entrada para cliques, ofertas e formulários. A fila normalmente roda em uma tarefa posterior a requestAnimationFrame e é esvaziada em pagehide e ao ocultar o documento, antes da confirmação por evento e do envio com keepalive. A regra de consentimento é consultada na entrega. Mudanças de consentimento e de modo de teste descartam trabalho pendente do contexto anterior. Texto de link usa textContent. A apresentação, o foco e o teclado são responsabilidade do adaptador do tema. As verificações de consentimento continuam lendo o valor vigente.

## 425 · Recibos de wp_mail

A ability administrativa f3base/email-wordpress-fila-ler apresenta assunto sanitizado, processo, gancho, função chamadora e destinos mascarados. Links, endereços de e-mail e sequências numéricas de 6 a 8 dígitos no assunto são suprimidos. A coluna diagnostico é anulável e separada do conteúdo cifrado, que é esvaziado após o processamento. To/Cc/Bcc válidos exibem até duas letras da parte local e o domínio. Um endereço sintaticamente ilegível pode produzir uma lista vazia. O indicador inclui_propria_caixa permite distinguir um envio legítimo à própria caixa.

Os códigos distinguem destinatário vazio ou sintaticamente inválido, bloqueio em homologação, porta/TLS, sintaxe do servidor, DNS do servidor, endereço de rede bloqueado, política HTTP do WordPress e recusa no envelope. SMTP 5.1.2 identifica domínio sem entrega e 5.7.x bloqueio de política, quando o servidor fornece o código. O canal técnico tenta um aviso por ciclo de instalação, com reserva persistida e recibo de aceite local ou falha. O recebimento na caixa final depende do transporte. Uma linha anterior com smtp_destino_invalido na fase preparo identifica a validação do servidor legado. Para aquela linha, a recuperação de assunto, destinatário e chamador exige um registro contemporâneo independente.
