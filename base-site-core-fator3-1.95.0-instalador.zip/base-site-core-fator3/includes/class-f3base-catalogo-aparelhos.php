<?php
/** Catálogo local de modelos observados; as correções são opções do próprio site. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Catalogo_Aparelhos {
    public const DATA = '2026-11-17';
    public const REVISAO = '2026-11-18.1';
    public const CAMPOS = ['marca','nome_comercial','ano_lancamento','preco_atual_estimado_brl','faixa_sugerida','linha_premium'];

    private static function base(): array {
        static $indice = null;
        if ($indice === null) {
            $indice = json_decode(file_get_contents(F3BASE_PLUGIN_DIR.'dados/aparelhos-br.json'), true, 512, JSON_THROW_ON_ERROR);
        }
        return $indice;
    }

    public static function metadados(): array {
        return ['data'=>self::DATA, 'moeda'=>'BRL', 'revisao'=>self::REVISAO, 'codigos'=>count(self::base()['codigos']), 'leitura_sem_nome'=>'f3base/aparelhos-sem-nome-ler',
            'google_play'=>json_decode(file_get_contents(F3BASE_PLUGIN_DIR.'dados/google-play/base.json'), true, 8, JSON_THROW_ON_ERROR),
            'opcao_local'=>'f3base_medicao_editorial.catalogo_aparelhos'];
    }

    private static function chave(string $s): string {
        return mb_strtolower(trim($s));
    }

    private static function item_local(string $linha): ?array {
        $partes = explode('=', $linha, 2);
        if (count($partes) !== 2) { return null; }
        [$codigo,$valor] = array_map('trim', $partes);
        if (!preg_match('/^[\pL\pN][\pL\pN ._()+\/-]{0,79}$/uD', $codigo)) { return null; }
        $faixas = ['entrada','intermediário','topo'];
        if (in_array($valor,$faixas,true)) { return [self::chave($codigo),$valor]; }
        $campos = array_map('trim',explode('|',$valor));
        if (count($campos)!==6) { return null; }
        [$marca,$nome,$ano,$preco,$faixa,$premium] = $campos;
        foreach ([$marca,$nome] as $texto) {
            if (!preg_match('/^[\pL\pN][\pL\pN ._()+\/-]{0,79}$/uD',$texto)) { return null; }
        }
        if (!preg_match('/^(?:19|20)\d{2}$/D',$ano) || !preg_match('/^\d{1,7}(?:\.\d{1,2})?$/D',$preco)
            || (float)$preco<=0 || !in_array($faixa,$faixas,true) || !in_array($premium,['sim','não'],true)) { return null; }
        $campos[3] = number_format((float)$preco,2,'.','');
        return [self::chave($codigo),array_combine(self::CAMPOS,$campos)];
    }

    public static function validar($linhas): bool {
        if (!is_array($linhas) || !array_is_list($linhas) || count($linhas)>500) { return false; }
        $vistas = [];
        foreach ($linhas as $linha) {
            $item = is_string($linha) ? self::item_local($linha) : null;
            if ($item===null || isset($vistas[$item[0]])) { return false; }
            $vistas[$item[0]]=true;
        }
        return true;
    }

    private static function nome_normalizado(string $valor): string {
        // Preserva os sinais de variante: S9+ e S9, por exemplo, continuam distintos.
        return preg_replace('/[\s()]+/u', '', self::chave($valor)) ?? '';
    }

    /** Null marks an ambiguous normalized name; exact local keys remain usable. */
    private static function indexar_nome(array &$indice, string $nome, $valor): void {
        if ($nome !== '') {
            $indice[$nome] = array_key_exists($nome, $indice) && $indice[$nome] !== $valor ? null : $valor;
        }
    }

    private static function local(array $linhas): array {
        static $anterior = null, $indice = [];
        if ($anterior === $linhas) { return $indice; }
        $indice = ['exatos'=>[], 'nomes'=>[], 'faixas'=>[], 'revisao'=>hash('sha256', wp_json_encode($linhas))];
        foreach ($linhas as $linha) {
            $item = is_string($linha) ? self::item_local($linha) : null;
            if ($item === null) { continue; }
            [$chave, $regra] = $item;
            $indice['exatos'][$chave] = $regra;
            if (is_array($regra)) {
                self::indexar_nome($indice['nomes'], self::nome_normalizado($regra['nome_comercial']), $regra);
            } else {
                self::indexar_nome($indice['faixas'], self::nome_normalizado($chave), $regra);
            }
        }
        $anterior = $linhas;
        return $indice;
    }

    /** Um fragmento por vez na memória, apenas quando a consulta curada não resolve o código. */
    public static function google_play(string $codigo): array {
        static $ultimo = '', $indice = [];
        $chave = preg_replace('/\s+/u', ' ', self::chave($codigo));
        if ($chave === null || $chave === '') { return []; }
        $prefixo = substr(hash('sha256', $chave), 0, 2);
        if ($prefixo !== $ultimo) {
            $arquivo = F3BASE_PLUGIN_DIR.'dados/google-play/'.$prefixo.'.json.gz';
            $indice = json_decode(gzdecode(file_get_contents($arquivo)), true, 8, JSON_THROW_ON_ERROR);
            $ultimo = $prefixo;
        }
        $item = $indice[$chave] ?? null;
        if ($item === null && preg_match('/^([a-z0-9_-]{6,}[0-9][a-z]?)[a-z]$/D', $chave, $familia)) {
            static $familias = null;
            $familias ??= json_decode(file_get_contents(F3BASE_PLUGIN_DIR.'dados/google-play/familias.json'), true, 8, JSON_THROW_ON_ERROR);
            $item = $familias[$familia[1]] ?? null;
        }
        if ($item === null) { return []; }
        [$marca,$nome,$device,$criterio] = $item;
        return ['marca'=>$marca,'nome_comercial'=>$nome,'device'=>$device,
                'identificacao_fonte'=>'google_play','identificacao_criterio'=>$criterio];
    }

    public static function resolver(string $codigo, array $linhas): array {
        $chave = self::chave($codigo);
        if ($chave === '') { return []; }
        $local = self::local($linhas);
        $revisao = ['catalogo_data'=>self::DATA, 'catalogo_revisao'=>self::REVISAO,
                    'catalogo_revisao_local'=>$local['revisao']];
        $regra = $local['exatos'][$chave] ?? null;
        if (is_array($regra)) { return $regra + ['faixa_fonte'=>'catalogo_site'] + $revisao; }

        $base = self::base();
        $id = $base['codigos'][$chave] ?? null;
        $ficha = [];
        $fonte = 'catalogo_embarcado';
        if ($id === null) {
            $nome = self::nome_normalizado($codigo);
            $ficha = $local['nomes'][$nome] ?? [];
            if ($ficha) {
                $fonte = 'catalogo_site';
            } else {
                $ficha = self::google_play($codigo);
                if (!$ficha && preg_match('/^(sm-[a-z]\d{3,4})[a-z]$/D', $chave, $m)) {
                    $id = $base['raizes'][$m[1]] ?? null;
                }
                if (!$ficha && $id === null && !array_key_exists($nome,$local['nomes'])) {
                    $id = $base['nomes'][$nome] ?? null;
                }
            }
        }
        if ($id !== null) { $ficha = array_combine(self::CAMPOS, $base['modelos'][$id]); }
        $nome = self::nome_normalizado($ficha['nome_comercial'] ?? '');
        $faixa = $regra;
        if ($faixa === null && $nome !== '') {
            $faixa = $local['faixas'][$nome] ?? ($local['faixas'][$nome.'4g'] ?? null);
        }
        if (is_string($faixa)) {
            $ficha['faixa_sugerida'] = $faixa;
            $fonte = 'catalogo';
        }
        if (isset($ficha['faixa_sugerida'])) { $ficha['faixa_fonte'] = $fonte; }
        return $ficha + $revisao;
    }

    public static function do_site(): array {
        return F3Base_Options::ler('f3base_medicao_editorial')['catalogo_aparelhos']??F3Base_Perfil_Aparelho::CATALOGO;
    }

    /** Pagina códigos distintos por chave, sem devolver lead, visitante, sessão ou conteúdo do contato. */
    public static function sem_nome(array $entrada=[]): array {
        if (!current_user_can('manage_options')) { return ['ok'=>false,'codigo'=>'sem_permissao']; }
        global $wpdb;
        $limite=max(1,min(200,(int)($entrada['limite']??50)));
        $apos=(string)($entrada['apos']??'');
        $sql=$wpdb->prepare("SELECT codigo,COUNT(*) AS perfis FROM (
            SELECT LOWER(CASE WHEN JSON_VALID(perfil) THEN JSON_UNQUOTE(JSON_EXTRACT(perfil,'$.modelo')) END) AS codigo
            FROM %i WHERE observado_em >= %d) p
            WHERE codigo > %s GROUP BY codigo ORDER BY codigo LIMIT %d",
            F3Base_Perfil_Aparelho::tabela(),F3Base_Editorial::corte_retencao(),$apos,$limite+1);
        $rows=$wpdb->get_results($sql,ARRAY_A);
        if ($wpdb->last_error) { return ['ok'=>false,'codigo'=>'consulta_indisponivel']; }
        $mais=count($rows)>$limite;
        if ($mais) { array_pop($rows); }
        $pendentes=[]; $incompletos=[]; $locais=self::do_site();
        foreach ($rows as $r) {
            $ficha=self::resolver($r['codigo'],$locais);
            if (empty($ficha['nome_comercial'])) {
                $pendentes[]=['codigo'=>$r['codigo'],'perfis'=>(int)$r['perfis']];
            } elseif (($ficha['identificacao_fonte']??'')==='google_play') {
                $incompletos[]=['codigo'=>$r['codigo'],'perfis'=>(int)$r['perfis'],'marca'=>$ficha['marca'],'nome_comercial'=>$ficha['nome_comercial'],'device'=>$ficha['device'],'criterio'=>$ficha['identificacao_criterio']];
            }
        }
        return ['ok'=>true,'itens'=>$pendentes,'sem_nome'=>$pendentes,'sem_ficha_comercial'=>$incompletos,'codigos_examinados'=>count($rows),
            'proximo_apos'=>$mais?end($rows)['codigo']:null,'catalogo_data'=>self::DATA];
    }
}
