<?php
/** Registro fechado dos trabalhos Core; cron nativo, CLI e ability usam o mesmo executor. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Operacao {
    const OPTION='f3base_operacao_estado';const MAX_TRABALHOS=3;const MAX_SEGUNDOS=30;const LEASE_SEGUNDOS=180;
    private static array $callbacks=array();private static array $nativos=array();private static bool $consumindo=false;private static bool $desativando=false;
    /** Align a planned date in the WordPress timezone, preserving its calendar day. */
    public static function alinhar(int $at,string $clock): int {$d=(new DateTimeImmutable('@'.$at))->setTimezone(wp_timezone());[$h,$m]=array_map('intval',explode(':',$clock));$x=$d->setTime($h,$m);if($x->getTimestamp()<=time()){$x=$x->modify('+1 day');}return $x->getTimestamp();}
    public static function reconciliar_horarios(): void {
        $tz=wp_timezone_string();$state=get_option('f3base_agenda',array());if(($state['fuso']??null)===$tz){return;}$ok=true;
        foreach(array('f3base_retencao_limpeza'=>'01:00','f3base_cadencia_relatorio'=>'06:00') as $hook=>$clock){$e=wp_get_scheduled_event($hook);if(!$e){continue;}$at=self::alinhar((int)$e->timestamp,$clock);if($at===$e->timestamp){continue;}$l=F3Base_Trava::adquirir('horario-'.hash('sha256',$hook),30);if(!$l){$ok=false;continue;}try{$deleted=wp_unschedule_event($e->timestamp,$hook,$e->args,true);$new=$deleted===true?wp_schedule_event($at,$e->schedule,$hook,$e->args,true):false;if($new!==true||wp_next_scheduled($hook)!==$at){if($deleted===true){wp_schedule_event($e->timestamp,$e->schedule,$hook,$e->args);}$ok=false;}elseif($hook==='f3base_cadencia_relatorio'){F3Base_Options::atualizar_estado('f3base_cadencia_estado',static fn($s)=>array_merge($s,array('previsto'=>$at)));}}finally{F3Base_Trava::liberar($l);}}
        if($ok){F3Base_Options::atualizar_estado('f3base_agenda',static fn($v)=>array_merge($v,array('fuso'=>$tz,'em'=>time(),'retencao'=>'01:00','cadencia'=>'06:00','cache'=>'minuto 10, antes da validade da prova')));}
    }
    public static function cache_regular(int $expires): int {$d=(new DateTimeImmutable('@'.$expires))->setTimezone(wp_timezone());$d=$d->setTime((int)$d->format('H'),10);if($d->getTimestamp()>$expires){$d=$d->modify('-1 hour');}return max(time()+F3Base_Cache_Evidencia::INTERVALO,$d->getTimestamp());}
    public static function tarefas(): array {
        $r=array(
            'migracao'=>array('Atualização de estrutura',array('f3base_migrar_estrutura')),
            'acessos'=>array('Logs fechados e continuação',array('f3base_acessos_somar','f3base_acessos_continuar')),
            'editorial'=>array('Catálogo e agregados editoriais',array('f3base_editorial_atualizar')),
            'whatsapp_conversa'=>array('Conversas WhatsApp pela ponte Slack',array(F3Base_Whatsapp_Conversa::HOOK)),
            'email_site'=>array('Caixa de e-mail do site',array('f3base_email_site_consultar','f3base_email_site_saude')),
            'email_historico'=>array('Confirmar e-mail no histórico CRM',array(F3Base_Email_Historico::HOOK)),
            'email_novo_lead'=>array('E-mail automático ao novo lead',array('f3base_email_novo_lead_processar')),
            'conversoes_servidor'=>array('Conversões pelo servidor',array('f3base_conversoes_servidor')),
            'clarity'=>array('Acervo Clarity',array('f3base_clarity_coletar','f3base_clarity_retomar')),
            'ga4'=>array('Acervo GA4',array(F3Base_Ga4::HOOK,F3Base_Ga4::CONTINUAR)),
            'meta_monitoramento'=>array('Monitorar recebimento Meta',array(F3Base_Meta_Monitoramento::HOOK)),
            'google_cliques'=>array('Enriquecer cliques Google',array('f3base_google_cliques')),
            'gsc_consultas'=>array('Search Console — consultas',array('f3base_gsc_consultas_coletar','f3base_gsc_consultas_continuar')),
            'gsc'=>array('Search Console',array('f3base_gsc_coletar','f3base_gsc_continuar')),
            'redes_robos'=>array('Redes oficiais dos robôs',array('f3base_redes_robos_atualizar')),
            'llms'=>array('Índices Markdown',array('f3base_llms_converter_lote','f3base_llms_regenerar')),
            'robots'=>array('Entrega de robots',array('f3base_robots_verificar')),
            'servidor'=>array('Prova de regras do servidor',array(F3Base_Servidor::EVENTO)),
            'ofertas'=>array('Verificação de ofertas',array('f3base_ofertas_verificar')),
            'navegacao'=>array('Prova de navegação',array('f3base_navegacao_verificar_cron','f3base_navegacao_rever')),
            'schema'=>array('Dados estruturados',array('f3base_schema_verificar')),
            'reaquecimento'=>array('Reaquecimento de páginas recentes',array(F3Base_Cache_Reaquecimento::EVENTO)),
            'cache'=>array('Cache e diretórios públicos',array('f3base_cache_verificar')),
            'gtm'=>array('Diagnóstico GTM',array('f3base_gtm_verificar')),
            'capi'=>array('Conversões Meta',array('f3base_capi_recuperar','f3base_meta_capi_enviar')),
            'historico_visitas'=>array('Histórico de sessões',array(F3Base_Sessoes::EVENTO)),
            'complementos'=>array('Complementos de formulário',array(F3Base_Formulario_Complementos::EVENTO)),
            'manutencao'=>array('Avisos, respostas e manutenção',array('f3base_leads_resumo')),
            'pipedrive'=>array('Pipedrive e eliminação',array('f3base_pipedrive_processar')),
            'caminho_lead'=>array('Teste sob demanda do caminho do lead',array(F3Base_Caminho_Lead::HOOK)),
            'qualidade_destinos'=>array('Retorno comercial por destino',array(F3Base_Qualidade_Destinos::HOOK)),
            'pos_atualizacao'=>array('Provas após atualização',array(F3Base_Pos_Atualizacao::HOOK)),
            'wp_mail'=>array('E-mail autenticado do WordPress',array(F3Base_Wp_Mail::HOOK)),
            'marcas'=>array('Citações entre marcas',array(F3Base_Marcas::HOOK)),
            'primeira_resposta'=>array('Primeira resposta da equipe',array(F3Base_Primeira_Resposta::HOOK)),
            'qualidade'=>array('Qualidade comercial e retorno Meta',array(F3Base_Qualidade::HOOK)),
            'anuncios'=>array('Anúncios nativos',array('f3base_anuncios_consultar',F3Base_Captacao_Operacao::HOOK,F3Base_Linkedin::EVENTO,F3Base_Linkedin_Webhook::EVENTO,F3Base_Linkedin_Webhook::MANUTENCAO,F3Base_Linkedin_Campanhas::EVENTO)),
            'integracoes'=>array('Verificação de integrações',array('f3base_integracoes_verificar','f3base_integracoes_reverificar')),
            'avisos_crm'=>array('Avisos de entrega ao CRM',array('f3base_pipedrive_alertas')),
            'avisos_contatos'=>array('Avisos de contatos',array(F3Base_Leads_Notificacoes::AVISOS,F3Base_Avisos::EVENTO)),
            'retencao'=>array('Retenção e eliminação',array(F3Base_Modulo_Retencao_Eliminacao::EVENTO,'f3base_intencoes_podar','f3base_cache_podar')),
            'cadencia'=>array('Relatório periódico',array('f3base_cadencia_relatorio')),
        );foreach($r as $id=>$v){$r[$id]=array('rotulo'=>$v[0],'hooks'=>$v[1]);}return $r;
    }
    public static function identificar_hook(string $hook): string {foreach(self::tarefas() as $id=>$t){if(in_array($hook,$t['hooks'],true)){return $id;}}return '';}
    /** Existing module registration stays transparent until all modules have registered. */
    public static function callback(string $hook,$callback): callable {return F3Base_Desempenho::callback($hook,$callback);}
    public static function sanitizar_estado($v,$p=array()): array {return is_array($v)?array_intersect_key($v,self::tarefas()):array();}
    private static function proprio($cb): bool {
        try{$ref=is_array($cb)?new ReflectionMethod($cb[0],$cb[1]):(is_string($cb)&&str_contains($cb,'::')?new ReflectionMethod($cb):new ReflectionFunction($cb));$path=realpath($ref->getFileName()?:'');return $path&&str_starts_with($path,realpath(F3BASE_PLUGIN_DIR).DIRECTORY_SEPARATOR);}catch(Throwable $e){return false;}
    }
    public static function registrar_callbacks(): void {
        global $wp_filter;
        foreach(self::tarefas() as $t){foreach($t['hooks'] as $hook){if(isset(self::$callbacks[$hook])||empty($wp_filter[$hook])){continue;}$entries=array();
            foreach($wp_filter[$hook]->callbacks as $priority=>$callbacks){foreach($callbacks as $entry){if(self::proprio($entry['function'])){$entry['priority']=$priority;$entries[]=$entry;}}}
            if(!$entries){continue;}self::$callbacks[$hook]=$entries;
            foreach($entries as $entry){remove_action($hook,$entry['function'],$entry['priority']);}
            add_action($hook,static function(...$args)use($hook){self::nativo($hook,$args);},min(array_column($entries,'priority')),99);
        }}
    }
    public static function iniciar(): void {
        add_action('f3base_zelador',array(__CLASS__,'reconciliar_horarios'),99);
        F3Base_Execucoes::iniciar_hooks();
        add_action('f3base_zelador',array(__CLASS__,'registrar_callbacks'),PHP_INT_MAX-10);
        add_action('f3base_zelador',array(__CLASS__,'recuperar_agendamentos'),PHP_INT_MAX-5);add_action('f3base_operacao_retomar',static fn()=>self::executar_pendentes(array('simular'=>false)));add_action('f3base_operacao_urgente',static fn()=>self::executar_pendentes(array('simular'=>false)));
        add_filter('pre_unschedule_event',static function($pre,$at,$hook,$args){if(!self::$consumindo&&self::identificar_hook($hook)&&((defined('WP_CLI')&&WP_CLI)||wp_doing_cron())){self::$nativos[$hook.'|'.serialize($args)][]=(int)$at;}return $pre;},10,4);
        add_filter('schedule_event',array(__CLASS__,'alinhar_evento'));
    }
    public static function proximo_horario(string $hhmm,array $hours=array()): int {
        $now=new DateTimeImmutable('now',wp_timezone());$candidates=array();
        foreach($hours?:array($hhmm) as $h){$d=$now->setTime((int)substr($h,0,2),(int)substr($h,3,2),0);if($d<=$now){$d=$d->modify('+1 day');}$candidates[]=$d->getTimestamp();}return min($candidates);
    }
    public static function alinhar_evento($event){
        if(!$event||!empty($event->args)||empty($event->schedule)){return $event;}
        if(in_array($event->hook,array('f3base_retencao_limpeza','f3base_cadencia_relatorio'),true)){$event->timestamp=self::alinhar((int)$event->timestamp,$event->hook==='f3base_retencao_limpeza'?'01:00':'06:00');return $event;}
        $map=array(F3Base_Ga4::HOOK=>F3Base_Ga4::opcoes()['horario'],'f3base_redes_robos_atualizar'=>'02:00','f3base_clarity_coletar'=>'03:00','f3base_gtm_verificar'=>'04:00','f3base_gsc_coletar'=>F3Base_Options::ler('f3base_gsc')['horario']??'05:00');
        if(isset($map[$event->hook])){$event->timestamp=self::proximo_horario($map[$event->hook]);}
        elseif($event->hook==='f3base_navegacao_verificar_cron'){$event->timestamp=self::proximo_horario('00:00',array('00:00','12:00'));}
        elseif($event->hook==='f3base_leads_resumo'){$now=new DateTimeImmutable('now',wp_timezone());$event->timestamp=$now->setTime((int)$now->format('H'),0,0)->modify('+1 hour')->getTimestamp();}
        return $event;
    }
    private static array $prioritarios_vistos=array();
    private static bool $drenando_prioritarios=false;
    public static function prioridade(string $hook): int {
        if($hook===F3Base_Atualizacao::EVENTO){return -2;}if($hook===F3Base_Pos_Atualizacao::HOOK){return -1;}
        if(in_array($hook,array(F3Base_Anuncios::EVENTO,F3Base_Linkedin::EVENTO,F3Base_Linkedin_Webhook::EVENTO,F3Base_Email_Site::HOOK,F3Base_Whatsapp_Conversa::HOOK),true)){return 0;}
        if(in_array($hook,array('f3base_pipedrive_processar',F3Base_Avisos::EVENTO,F3Base_Leads_Notificacoes::AVISOS),true)){return 1;}
        return F3Base_Zelador::rotina($hook)?2:1;
    }
    private static function executar_prioritarios(array $ids): array {
        if(self::$drenando_prioritarios){return array();}self::$drenando_prioritarios=true;$rows=array();
        try{foreach(self::eventos() as $e){if($e['timestamp']<=time()&&self::prioridade($e['hook'])<2&&in_array($e['id'],$ids,true)&&!empty(self::$callbacks[$e['hook']])){$rows[]=self::executar_evento($e);}}}
        finally{self::$drenando_prioritarios=false;}return $rows;
    }
    private static function eventos(): array {
        $r=array();foreach(_get_cron_array()?:array() as $at=>$hooks){foreach($hooks as $hook=>$events){$id=self::identificar_hook($hook);if(!$id){continue;}foreach($events as $event){$r[]=array('id'=>$id,'hook'=>$hook,'timestamp'=>(int)$at,'args'=>$event['args']??array(),'schedule'=>$event['schedule']??false);}}}
        foreach(F3Base_Operacao_Intencoes::listar(1,true) as $event){if(($event['tentar_em']??0)>time()){continue;}$exists=false;foreach($r as $old){if($old['hook']===$event['hook']&&$old['args']===$event['args']&&$old['timestamp']===$event['timestamp']){$exists=true;break;}}if(!$exists){$r[]=$event;}}
        usort($r,static fn($a,$b)=>[self::prioridade($a['hook']),$a['timestamp'],$a['hook'],serialize($a['args'])]<=>[self::prioridade($b['hook']),$b['timestamp'],$b['hook'],serialize($b['args'])]);return $r;
    }
    public static function excecao(Throwable $e,string $etapa='callback',string $tarefa=''): array {
        $raw=$e->getMessage();$checkpoint=str_starts_with($raw,'checkpoint_nao_persistido_');$known=array('checkpoint_nao_persistido','reagendamento_recusado','consumo_agendamento_recusado','checkpoint_falhou','etapa_nao_confirmada','sentinela_gravacao_falhou','linha_nao_persistida','commit_falhou','consulta_falhou','intencao_nao_persistida','intencoes_leitura_falhou');$causas=array('checkpoint_nao_persistido'=>'O banco não confirmou a reserva da tarefa.','reagendamento_recusado'=>'A agenda recusou a próxima recorrência.','consumo_agendamento_recusado'=>'A agenda recusou o consumo da ocorrência.','checkpoint_falhou'=>'O banco não confirmou o checkpoint.','etapa_nao_confirmada'=>'A etapa não confirmou a conclusão.','sentinela_gravacao_falhou'=>'O arquivo da guarda não confirmou a gravação.');$causas+=array('linha_nao_persistida'=>'O banco não confirmou a gravação da linha.','commit_falhou'=>'O banco não confirmou a transação.','consulta_falhou'=>'A consulta ao banco falhou.','intencao_nao_persistida'=>'O banco não confirmou a intenção ou sua reserva.','intencoes_leitura_falhou'=>'A leitura das intenções falhou.');$file=str_replace('\\','/',$e->getFile());$base=rtrim(str_replace('\\','/',F3BASE_PLUGIN_DIR),'/').'/';$interno=str_starts_with($file,$base);$codigo=$interno&&preg_match('/^[a-z][a-z0-9_]{2,63}$/D',$raw)?$raw:null;if($codigo===null&&(($interno&&str_contains(basename($file),'llms'))||str_starts_with($tarefa,'llms'))){$codigo='llms_excecao_nao_catalogada';}$causas+=F3Base_Erros::mensagens();$message=($checkpoint?'O banco não confirmou a reserva da tarefa; o código identifica a etapa de persistência.':null)??$causas[$raw]??($codigo?'Falha local identificada pelo código interno deste retorno.':'Falha local sem mensagem estruturada segura; confira classe, etapa, arquivo e linha deste retorno.');
        foreach(array('Cannot access offset of type'=>'Acesso a índice em tipo incompatível.','Call to undefined method'=>'Método não disponível.','Call to undefined function'=>'Função não disponível.','Undefined array key'=>'Chave de array ausente.','Typed property'=>'Propriedade tipada indisponível.','Argument #'=>'Tipo de argumento incompatível.') as $prefix=>$safe){if(str_starts_with($raw,$prefix)){$message=$safe;break;}}
        $file=str_replace('\\','/',$e->getFile());$base=str_replace('\\','/',F3BASE_PLUGIN_DIR);
        return array('codigo_interno'=>$codigo,'etapa'=>$etapa,'classe'=>get_class($e),'mensagem'=>mb_substr($message,0,300),'arquivo'=>str_starts_with($file,$base)?substr($file,strlen($base)):'fora_do_plugin','linha'=>$e->getLine());
    }
    public static function agenda(): array {
        $state=F3Base_Options::ler(self::OPTION);$events=self::eventos();$r=array();
        foreach(self::tarefas() as $id=>$t){$matches=array_values(array_filter($events,static fn($e)=>$e['id']===$id));$e=$matches[0]??array();$at=$e['timestamp']??0;$v=$state[$id]??array();$registered=(bool)array_intersect($t['hooks'],array_keys(self::$callbacks));
            $r[$id]=array('id'=>$id,'rotulo'=>$t['rotulo'],'hook'=>$e['hook']??'','registrada'=>$registered,'proxima_execucao'=>$at,'proxima_formatada'=>$at?wp_date('d/m/Y H:i:s T',$at):null,'argumentos'=>$e['args']??array(),'ocorrencias'=>count($matches),'atraso_segundos'=>$at?max(0,time()-$at):0,'atrasado'=>$at>0&&$at<=time(),'reservada'=>($v['lease']['ate']??0)>time(),'reserva_ate'=>$v['lease']['ate']??0,'ultima_execucao'=>$v['ultima']??array(),'ultimo_sucesso'=>$v['ultimo_sucesso']??array(),'prova_publica'=>self::prova_publica($id),'saldo'=>self::saldo($id,$v),'recuperacao'=>$v['recuperacao']??array(),'codigo'=>!$registered?'inativa':(!$at?'sem_agendamento':($at<=time()?'atrasada':'agendada')));
        }return $r;
    }
    private static function nativo(string $hook,array $args): void {
        if($hook===F3Base_Atualizacao::EVENTO&&!F3Base_Esquema::pronta('F3Base_Execucoes')){F3Base_Atualizacao::migrar();return;}
        $key=$hook.'|'.serialize($args);$at=!empty(self::$nativos[$key])?array_shift(self::$nativos[$key]):null;
        if(!F3Base_Execucoes::atual()){F3Base_Execucoes::iniciar('cron_nativo');}
        self::executar_prioritarios(array_keys(self::tarefas()));
        self::executar_evento(array('id'=>self::identificar_hook($hook),'hook'=>$hook,'args'=>$args,'timestamp'=>$at,'schedule'=>false),true);
    }
    private static function intencao_chave(array $e): string {return hash('sha256',$e['hook'].'|'.serialize($e['args']).'|'.($e['timestamp']??''));}
    private static function adiar(array $e,string $codigo,bool $falha=false,int $minimo=0): array {
        if($codigo==='ocorrencia_ja_processada'){F3Base_Operacao_Intencoes::concluir($e);return array('id'=>$e['id'],'ok'=>true,'status'=>'concluida','codigo'=>$codigo);}
        if(in_array($codigo,array('trava_banco_falhou','trava_arquivo_inacessivel','trava_arquivo_falhou','diario_indisponivel','tarefa_lancou_excecao','resultado_pendente','diario_persistencia_falhou','diario_leitura_falhou'),true)){$falha=true;}
        return F3Base_Operacao_Intencoes::adiar($e,$codigo,$falha,$minimo);
    }
    private static function tentativa_observada(array $e,array $r): array {$r['observabilidade']=F3Base_Execucoes::tentativa($e['id'],$e['hook'],$e['timestamp'],$r['codigo']??'reserva_indisponivel')?'registrada':'falhou';return $r;}
    private static function disputa(array $e,array $dona): array {
        $r=array('id'=>$e['id'],'ok'=>true,'status'=>'neutro','resultado'=>'neutro','codigo'=>'reserva_ocupada','dona'=>$dona,'execucao_realizada'=>false);
        $r['observabilidade']=F3Base_Execucoes::tentativa($e['id'],$e['hook'],$e['timestamp'],'reserva_ocupada',array('dona'=>$dona))?'registrada':'falhou';return $r;
    }
    private static function outra_dona(array $e,string $excluir=''): ?array {return F3Base_Execucoes::dona($e['id'],$e['hook'],$e['args'],(int)$e['timestamp'],$excluir);}
    /** A confirmação pertence à tarefa, não à fotografia inteira compartilhada. */
    private static function confirmar_resultado(array $e,string $task,array $r,array $persist): array {
        $foto=F3Base_Options::fotografia(self::OPTION);$v=$foto['valor'][$e['id']]??array();
        $medida=$persist['persistencia']??array();
        $medida+=array('etapa'=>$persist['codigo']??'sem_medida','operacao'=>'nenhuma','linhas_afetadas'=>null,'revisao_esperada'=>$persist['revisao']??null,'revisao_lida'=>null,'erro_banco'=>'');
        $medida['revisao_reconferencia']=$foto['erro']?null:$foto['revisao'];
        $medida['lease_esperada']=$task;$medida['lease_lida']=$foto['erro']?null:($v['lease']['token']??null);
        $r['persistencia']=$medida;$r['tentativas_persistencia']=$persist['tentativas']??array();
        $ultima=$v['ultima']??array();$sucesso=$v['ultimo_sucesso']??array();
        $prova=!$foto['erro']&&(($ultima['run_id']??'')===$task&&!empty($ultima['fim'])&&($ultima['codigo']??'')===$r['codigo']||!empty($r['resultado_modulo_confirmado'])&&($sucesso['run_id']??'')===$task&&!empty($sucesso['fim']));
        $r['confirmado_localmente']=$prova;
        if($prova){if(empty($persist['persisted'])){$r['codigo']='checkpoint_confirmado_releitura';$r['persistencia']['causa']='resultado_da_tarefa_persistido';}return $r;}
        if(empty($r['ok'])){$r['persistencia']['causa']=!empty($medida['erro_banco'])?'falha_sql_medida':($medida['etapa']??'resultado_ausente');return $r;}
        $posterior=F3Base_Execucoes::conclusao_posterior($e,$task);
        if($posterior){$r['ok']=true;$r['status']='neutro';$r['resultado']='neutro';$r['codigo']='checkpoint_superado';$r['conclusao_posterior']=$posterior;$r['persistencia']['causa']='conclusao_posterior_comprovada';return $r;}
        $dona=self::outra_dona($e,$task);
        if($dona){$r['ok']=true;$r['status']='neutro';$r['resultado']='neutro';$r['codigo']='reserva_ocupada';$r['dona']=$dona;$r['persistencia']['causa']='outra_reserva_comprovada';return $r;}
        $r['ok']=false;$r['status']='pendente';$r['codigo']='checkpoint_nao_persistido';$r['resultado_modulo_confirmado']=false;
        $r['persistencia']['causa']=$foto['erro']?'releitura_indisponivel':(($v['lease']['token']??'')!==$task?'lease_divergente_sem_conclusao':'resultado_ausente');
        return $r;
    }
    private static function executar_evento(array $e,bool $nativo=false): array {
        if(wp_doing_cron()&&!(defined('WP_CLI')&&WP_CLI)&&F3Base_Zelador::protegido()&&F3Base_Zelador::rotina($e['hook'])){return array('ok'=>true,'id'=>$e['id'],'codigo'=>'aguardando_cron_cli','execucao_realizada'=>false);}
        if ($e['hook'] === F3Base_Email_Historico::HOOK && !F3Base_Email_Historico::aplicavel()) {
            $ok = F3Base_Email_Historico::encerrar_inativa();
            return ['id'=>$e['id'],'ok'=>$ok,'codigo'=>$ok?'nao_aplicavel':'limpeza_pendente','execucao_realizada'=>false];
        }
        $priority=self::prioridade($e['hook']);$start=microtime(true);
        if($priority<2){
            $run=F3Base_Execucoes::atual()['run_id']??'';$key=$run.'|'.$e['hook'];
            if (isset(F3Base_Fila::RECORRENCIAS[$e['hook']])) { $key.='|'.self::intencao_chave($e); }
            if(isset(self::$prioritarios_vistos[$key])){return array('ok'=>true,'id'=>$e['id'],'codigo'=>'prioridade_ja_examinada','execucao_realizada'=>false);}
            self::$prioritarios_vistos[$key]=true;
            $r=F3Base_Execucoes::com_prioridade(static fn()=>F3Base_Execucoes::no_trabalho(static fn()=>self::executar_evento_reservado($e,$nativo)));
        }else{$r=F3Base_Execucoes::no_trabalho(static fn()=>self::executar_evento_reservado($e,$nativo));}
        return $r+array('prioridade'=>$priority<2?($priority===0?'captacao':'entrega'):'manutencao','duracao_ms'=>(int)round((microtime(true)-$start)*1000),'orcamento_proprio_segundos'=>$priority<2?30:null);
    }
    private static function executar_evento_reservado(array $e,bool $nativo=false): array {
        $inicio_medida=microtime(true);$id=$e['id'];$hook=$e['hook'];$args=$e['args'];if($e['timestamp']===null){$e['timestamp']=time();}$dona=self::outra_dona($e);if($dona){
            if($id==='reaquecimento' && $dona['estado']==='executada'){
                if(!F3Base_Operacao_Intencoes::concluir($e)){return array('id'=>$id,'ok'=>false,'codigo'=>'intencao_nao_persistida');}
                if(!$nativo){wp_unschedule_event((int)$e['timestamp'],$hook,$args);}
                F3Base_Cache_Reaquecimento::conferir_agenda_1();
                return array('id'=>$id,'ok'=>true,'codigo'=>'ocorrencia_ja_processada','dona'=>$dona);
            }
            return self::disputa($e,$dona);
        }$apresentada=array('timestamp'=>(int)$e['timestamp'],'schedule'=>$e['schedule']??false);try{$deferred=F3Base_Operacao_Intencoes::obter($e);}catch(Throwable $x){return array('id'=>$id,'ok'=>false,'codigo'=>'intencoes_leitura_falhou','erro'=>self::excecao($x,'intencoes'));}if($deferred){if($e['timestamp']>$deferred['timestamp']){F3Base_Operacao_Intencoes::cobrir($deferred,(int)$e['timestamp']);}$e=array_merge($e,$deferred);}if(in_array($deferred['estado']??'',array('esgotada','suspensa'),true)){return array('ok'=>true,'status'=>$deferred['estado'],'codigo'=>'intencao_'. $deferred['estado'],'id'=>$id,'intencao'=>$deferred['intencao']);}if(($deferred['tentar_em']??0)>time()){return array('ok'=>true,'status'=>'pendente','codigo'=>'aguardando_retomada','id'=>$id,'tentar_em'=>$deferred['tentar_em']);}
        if(self::$desativando||empty(self::$callbacks[$hook])){return array('ok'=>false,'codigo'=>'tarefa_inativa','id'=>$id);}
        if(!F3Base_Recuperacao::entrar()){ $r=$nativo?self::adiar($e,'core_em_recuperacao'):array('ok'=>false,'codigo'=>'core_em_recuperacao','id'=>$id);$r['observabilidade']=F3Base_Execucoes::tentativa($id,$hook,$e['timestamp'],'core_em_recuperacao')?'registrada':'falhou';return $r;}
        global $wpdb;$lock='f3core:'.substr(hash('sha256',DB_NAME.'|'.$wpdb->prefix.'|'.$id),0,48);$locked=false;$fileLock=null;$task=null;$r=array('id'=>$id,'status'=>'pendente','ok'=>false,'codigo'=>'reserva_indisponivel');
        $etapa='reserva';try{
            if(!F3Base_Execucoes::pode_trabalhar()){$r=self::adiar($e,'orcamento_esgotado');return self::tentativa_observada($e,$r);}
            $owner=array('desde'=>time(),'ate'=>time()+F3Base_Execucoes::reserva_segundos(),'run_id'=>F3Base_Execucoes::atual()['run_id'],'passagem_run_id'=>F3Base_Execucoes::atual()['run_id'],'origem'=>F3Base_Execucoes::origem(),'ocorrencia'=>hash('sha256',$hook.'|'.serialize($args).'|'.$e['timestamp']),'estado'=>'reservada');
            $fileLock=F3Base_Recuperacao::reservar_tarefa($id,$owner);if(!$fileLock){$dona=self::outra_dona($e)??F3Base_Recuperacao::dona_tarefa();if($dona){return self::disputa($e,$dona);}$r=self::adiar($e,F3Base_Recuperacao::erro_tarefa());return self::tentativa_observada($e,$r);}
            $dbLock=$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock));$locked=(int)$dbLock===1;if(!$locked){$dona=self::outra_dona($e);if($dona){return self::disputa($e,$dona);}$r=self::adiar($e,$dbLock===null?'trava_banco_falhou':'reserva_ocupada',$dbLock===null);return self::tentativa_observada($e,$r);}
            $task=F3Base_Execucoes::iniciar_tarefa($id,$hook,$args,$e['timestamp']);
            if(!$task){$claim=F3Base_Execucoes::reivindicacao();if(!empty($claim['dona'])){return self::disputa($e,$claim['dona']);}$r=array_merge(self::adiar($e,$claim['codigo']??'diario_indisponivel'),$claim);return self::tentativa_observada($e,$r);}
            $owner['run_id']=$task;F3Base_Recuperacao::identificar_reserva($fileLock,$owner);
            $etapa='checkpoint';if(!F3Base_Operacao_Intencoes::registrar($e)||!F3Base_Operacao_Intencoes::reservar($e,$task)){throw new RuntimeException('intencao_nao_persistida');}$start=time();$save=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($id,$hook,$args,$start,$task,$e){$v[$id]['lease']=array('token'=>$task,'ate'=>$start+F3Base_Execucoes::reserva_segundos());$v[$id]['recuperacao']=array('hook'=>$hook,'args'=>$args,'pendente'=>true,'timestamp'=>$e['timestamp'],'quando'=>$start+F3Base_Execucoes::reserva_segundos());$v[$id]['ultima']=array('origem'=>F3Base_Execucoes::origem(),'inicio'=>$start,'run_id'=>$task,'status'=>'executando');return $v;});
            if(empty($save['persisted'])){$db_error=$save['erro_banco']??$wpdb->last_error;$observed=F3Base_Options::fotografia(self::OPTION);if(!$observed['erro']&&($observed['valor'][$id]['lease']['token']??'')===$task){$save['persisted']=true;}}
            if(empty($save['persisted'])){throw new RuntimeException('checkpoint_nao_persistido_'.sanitize_key($save['codigo']??'sem_codigo')); }
            if(!$nativo&&$e['timestamp']!==null){$etapa='agenda';self::$consumindo=true;try{
                if($e['schedule']&&!F3Base_Cron_Diagnostico::reagendar($e['timestamp'],$e['schedule'],$hook,$args)){throw new RuntimeException('reagendamento_recusado');}
                if(F3Base_Cron_Diagnostico::conferir('remover',$hook,array('timestamp'=>$e['timestamp'],'args'=>$args))!==true&&!wp_unschedule_event($e['timestamp'],$hook,$args)&&F3Base_Cron_Diagnostico::conferir('remover',$hook,array('timestamp'=>$e['timestamp'],'args'=>$args))!==true){throw new RuntimeException('consumo_agendamento_recusado');}
                if($apresentada['timestamp']!==(int)$e['timestamp']&&wp_get_scheduled_event($hook,$args,$apresentada['timestamp'])){
                    if($apresentada['schedule']&&!F3Base_Cron_Diagnostico::reagendar($apresentada['timestamp'],$apresentada['schedule'],$hook,$args)){throw new RuntimeException('reagendamento_recusado');}
                    if(!wp_unschedule_event($apresentada['timestamp'],$hook,$args)&&wp_get_scheduled_event($hook,$args,$apresentada['timestamp'])){throw new RuntimeException('consumo_agendamento_recusado');}
                }
            }finally{self::$consumindo=false;}}
            if(!$nativo){self::$consumindo=true;try{foreach(_get_cron_array()?:array() as $at=>$hooks){if($at>time()||empty($hooks[$hook])){continue;}foreach($hooks[$hook] as $cron){if(($cron['args']??array())!==$args){continue;}if(!empty($cron['schedule'])&&!F3Base_Cron_Diagnostico::reagendar((int)$at,$cron['schedule'],$hook,$args)){throw new RuntimeException('reagendamento_recusado');}if(!wp_unschedule_event($at,$hook,$args)&&wp_get_scheduled_event($hook,$args,$at)){throw new RuntimeException('consumo_agendamento_recusado');}}}}finally{self::$consumindo=false;}}
            $etapa='callback';$results=array();$ok=true;$confirmed=true;$partial=false;$waiting=false;$next=0;
            foreach(self::$callbacks[$hook] as $entry){
                if(F3Base_Execucoes::restante_ms()<1000){$ok=false;$partial=true;$results[]=array('codigo'=>'orcamento_esgotado');break;}
                $argumentos = isset(F3Base_Fila::RECORRENCIAS[$hook]) && $args === F3Base_Fila::ANTECIPAR ? [] : $args;
                $out=call_user_func_array($entry['function'],array_slice($argumentos,0,$entry['accepted_args']));
                if(is_wp_error($out)||$out===false){$ok=false;$results[]=array('ok'=>false,'codigo'=>'callback_recusou');}
                elseif(is_array($out)){$safe=self::resultado_seguro($out);$results[]=$safe;if(($id==='reaquecimento'&&($safe['codigo']??'')==='reserva_ocupada') || in_array($safe['codigo']??'',array('atualizacao_em_recuo','atualizacao_em_lotes','atualizacao_em_execucao','aguardando_servico','aguardando_retomada','consentimento_aguardando_trava','verificacao_em_recuo','verificacao_ocupada','catalogo_em_continuacao','orcamento_execucao','orcamento_local_esgotado','janela_requisicoes','aguarda_limite','limite_api','quota_aguardando','orcamento_esgotado'),true)){$waiting=true;$next=max($next,(int)($out['proxima_tentativa']??$out['tentar_em']??0));}if(isset($safe['ok'])&&!$safe['ok']){$ok=false;}if(!isset($safe['ok'])||isset($safe['resultado_modulo_confirmado'])&&!$safe['resultado_modulo_confirmado']){$confirmed=false;}$partial=$partial||!empty($safe['parcial'])||!empty($safe['incompleto'])||($safe['restantes']??0)>0||($safe['saldo']??0)>0;}
                else{$confirmed=false;$results[]=array('codigo'=>'callback_sem_confirmacao');}
            }
            $r=array('id'=>$id,'ok'=>$ok,'status'=>$ok?($partial?'parcial':($confirmed?'concluido':'executado')):'pendente','codigo'=>$ok?($confirmed?'lote_concluido':'executado_sem_confirmacao'):'resultado_pendente','parcial'=>$partial,'aguardando'=>$waiting,'tentar_em'=>$next,'resultado_modulo_confirmado'=>$confirmed&&$ok&&!$partial,'resultados_modulos'=>$results,'run_id'=>$task,'origem'=>F3Base_Execucoes::origem());if($waiting){$r['ok']=true;$r['status']='aguardando';$r['codigo']='quota_aguardando';$r['resultado_modulo_confirmado']=false;}
        }catch(Throwable $x){$checkpoint=str_starts_with($x->getMessage(),'checkpoint_nao_persistido');$dona=$checkpoint?self::outra_dona($e,$task??''):null;$r=array('id'=>$id,'ok'=>false,'status'=>'falha','codigo'=>$checkpoint?'checkpoint_nao_persistido':'tarefa_lancou_excecao','run_id'=>$task,'origem'=>F3Base_Execucoes::origem(),'erro'=>self::excecao($x,$etapa,$id));$r['persistencia_reserva']=$checkpoint?($save['persistencia']??array('etapa'=>'reserva_sem_medida')):null;$r['erro_banco']=$checkpoint?sanitize_text_field(mb_substr((string)($db_error??''),0,500)):null;if($dona){$r=array('id'=>$id,'ok'=>true,'status'=>'neutro','resultado'=>'neutro','codigo'=>'reserva_ocupada','dona'=>$dona,'execucao_realizada'=>false);}else{@error_log('F3BASE tarefa='.sanitize_key($id).' '.wp_json_encode($r['erro']));}if(!$task){$r['observabilidade']=F3Base_Execucoes::tentativa($id,$hook,$e['timestamp'],$r['codigo'],$r['erro'])?'registrada':'falhou';}}
        finally{
            if($task&&($r['resultado']??'')==='neutro'){F3Base_Execucoes::concluir_tarefa($task,$r);}
            if($task&&($r['resultado']??'')!=='neutro'){if(!F3Base_Operacao_Intencoes::liberar_reserva($e,$task)){$r['ok']=false;$r['codigo']='intencao_nao_persistida';}if(empty($r['ok'])||!empty($r['aguardando'])){$r['recuperacao']=self::adiar($e,!empty($r['aguardando'])?'quota_aguardando':($r['erro']['codigo_interno']??$r['codigo']),empty($r['aguardando']),(int)($r['tentar_em']??0));}$done=time();$persist=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($id,$task,$done,$r){if(($v[$id]['lease']['token']??'')!==$task){return $v;}$v[$id]['lease']=array();if(!empty($r['erro'])){$v[$id]['ultima_falha']=$r['erro'];}$v[$id]['ultima']=array_merge($v[$id]['ultima'],array('fim'=>$done,'status'=>$r['status'],'codigo'=>$r['codigo']));$v[$id]['recuperacao']['pendente']=(empty($r['ok'])||!empty($r['aguardando']))&&empty($r['recuperacao']['intencao_persistida']);$v[$id]['recuperacao']['tipo']=!empty($r['aguardando'])?'espera_programada':(empty($r['ok'])?'interrupcao':'concluida');$v[$id]['recuperacao']['quando']=max($done+60,(int)($r['tentar_em']??0));$v[$id]['ultima']['resultados_modulos']=$r['resultados_modulos']??array();
                if(in_array($id,array('cache','robots'),true)){$v[$id]['ultima']['motivo']=implode(' ',array_filter(array_column($r['resultados_modulos']??array(),'motivo')));}
                if(!empty($r['resultado_modulo_confirmado'])){$v[$id]['ultimo_sucesso']=$v[$id]['ultima'];if(in_array($id,array('cache','robots'),true)){foreach($r['resultados_modulos']??array() as $m){if(!empty($m['resultado_modulo_confirmado'])){$v[$id]['ultimo_sucesso']['codigo']=$m['codigo'];$v[$id]['ultimo_sucesso']['escopo']=$m['escopo'];$v[$id]['ultimo_sucesso']['checked_at']=$m['checked_at'];}}}}return $v;});$r=self::confirmar_resultado($e,$task,$r,$persist);
                $r['prioridade']=self::prioridade($hook)<2?(self::prioridade($hook)<0?'atualizacao':(self::prioridade($hook)===0?'captacao':'entrega')):'manutencao';$r['duracao_ms']=(int)round((microtime(true)-$inicio_medida)*1000);$r['quando']=(int)$e['timestamp'];$r['argumentos_sha256']=hash('sha256',serialize($e['args']));$journal=$r;if(!empty($r['aguardando'])){$journal['ok']=false;}if(empty($r['aguardando'])&&empty($r['resultado_modulo_confirmado'])&&!empty($r['ok'])){unset($journal['ok']);}F3Base_Execucoes::concluir_tarefa($task,$journal);
            }
            if($locked){$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}F3Base_Recuperacao::liberar_tarefa($fileLock);F3Base_Recuperacao::sair();
        }
        if(($r['resultado']??'')==='neutro'){return $r;}
        if(empty($r['ok'])||!empty($r['aguardando'])){if(!isset($r['recuperacao'])){$r['recuperacao']=self::adiar($e,!empty($r['aguardando'])?'quota_aguardando':$r['codigo'],empty($r['aguardando']),(int)($r['tentar_em']??0));}}else{F3Base_Operacao_Intencoes::concluir($e);}return $r;
    }
    public static function executar_uma(string $id,string $origem='administracao',bool $somente_vencida=true,string $hook_especifico=''): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)&&!wp_doing_cron()){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(!isset(self::tarefas()[$id])){return array('ok'=>false,'codigo'=>'tarefa_nao_permitida');}
        if($id==='migracao'&&!F3Base_Esquema::pronta('F3Base_Execucoes')){return F3Base_Atualizacao::migrar()+array('bootstrap_migracao'=>true);}
        self::registrar_callbacks();$own=F3Base_Execucoes::iniciar('executor');if(!F3Base_Execucoes::atual()){return array('ok'=>false,'codigo'=>'diario_indisponivel');}$r=array('id'=>$id,'ok'=>true,'codigo'=>'nenhuma_execucao_vencida','status'=>'sem_pendencia');
        try{$events=array_values(array_filter(self::eventos(),static fn($e)=>$e['id']===$id&&(!$hook_especifico||$e['hook']===$hook_especifico)&&$e['timestamp']<=time()));
            if($events){$r=self::executar_evento($events[0]);}
            elseif(!$somente_vencida){$hook=$hook_especifico?:self::tarefas()[$id]['hooks'][0];$r=self::executar_evento(array('id'=>$id,'hook'=>$hook,'args'=>array(),'timestamp'=>null,'schedule'=>false));}
        }finally{if($own){F3Base_Execucoes::encerrar();}}return $r+array('execucoes'=>F3Base_Execucoes::resumo());
    }
    public static function executar_pendentes(array $entrada=array()): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)&&!wp_doing_cron()){return array('ok'=>false,'codigo'=>'sem_permissao','resultados'=>array());}
        if(!empty($entrada['liberar_reserva_reaquecimento'])){return F3Base_Cache_Reaquecimento::liberar_reserva($entrada);}
        if(!empty($entrada['reconciliar_esperas'])){return self::reconciliar_espera($entrada);}
        $ids=$entrada['tarefas']??array_keys(self::tarefas());
        if(!is_array($ids)||array_diff($ids,array_keys(self::tarefas()))){return array('ok'=>false,'codigo'=>'tarefa_nao_permitida');}
        $react=!empty($entrada['reativar_esgotada']);$intent=array();
        if($react){
            if(count($ids)!==1||empty($entrada['intencao'])){return array('ok'=>false,'codigo'=>'reativacao_exige_tarefa_e_intencao');}
            foreach(F3Base_Operacao_Intencoes::da_tarefa($ids[0]) as $v){if($v['intencao']===$entrada['intencao']){$intent=$v;break;}}
            if(!$intent||$intent['estado']!=='esgotada'){return array('ok'=>false,'codigo'=>'intencao_nao_esgotada');}
        }
        $state=F3Base_Options::ler(self::OPTION);$rev=hash('sha256',wp_json_encode(array($ids,$intent,array_intersect_key($state,array_flip($ids)))));
        if(($entrada['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'persisted'=>false,'execucao_realizada'=>false,'revisao'=>$rev,'tarefas'=>$ids,'intencao'=>$intent['intencao']??null,'efeito'=>$react?'Reativar a intenção esgotada e executar tarefas vencidas, sob as guardas e cotas atuais.':'Executar tarefas vencidas, sob as guardas e cotas atuais.');}
        if(isset($entrada['revisao'])&&!hash_equals($rev,(string)$entrada['revisao'])){return array('ok'=>false,'codigo'=>'conflito','revisao'=>$rev,'persisted'=>false);}
        if($react){if(empty($entrada['revisao'])){return array('ok'=>false,'codigo'=>'revisao_obrigatoria','revisao'=>$rev);}$rr=F3Base_Operacao_Intencoes::reativar($entrada['intencao'],$ids[0],$intent);if(empty($rr['ok'])){return $rr;}}
        // The upgrade creates the journal schema cache, so it must precede that journal's gate.
        if(in_array('migracao',$ids,true)&&!F3Base_Esquema::pronta('F3Base_Execucoes')){return F3Base_Atualizacao::migrar()+array('bootstrap_migracao'=>true,'execucao_realizada'=>true);}
        self::registrar_callbacks();self::recuperar_agendamentos();$limit=F3Base_Execucoes::origem()==='cli'?PHP_INT_MAX:max(1,min(3,(int)($entrada['limite']??3)));$own=F3Base_Execucoes::iniciar('executor');if(!F3Base_Execucoes::atual()){return array('ok'=>false,'codigo'=>'diario_indisponivel','resultados'=>array());}$rows=array();
        if(!empty(F3Base_Recuperacao::ler()['ok'])&&empty(F3Base_Recuperacao::ler()['pausado'])){F3Base_Operacao_Intencoes::retomar();}
        $vistos=array();try{$rows=self::executar_prioritarios($ids);$normal=0;do{$progress=false;foreach(self::eventos() as $e){if(self::prioridade($e['hook'])<2){continue;}if($normal>=$limit||!F3Base_Execucoes::pode_trabalhar()){break;}if($e['timestamp']>time()||!in_array($e['id'],$ids,true)||empty(self::$callbacks[$e['hook']])){continue;}$scope=$e['hook'].'|'.serialize($e['args']).'|'.$e['timestamp'];if(isset($vistos[$scope])){continue;}$vistos[$scope]=true;$rows[]=self::executar_evento($e);++$normal;$progress=true;}}while($progress&&$normal<$limit&&F3Base_Execucoes::pode_trabalhar());}
        catch(Throwable $x){return array('ok'=>false,'codigo'=>'intencoes_leitura_falhou','erro'=>self::excecao($x,'intencoes'));}
        finally{if($own){F3Base_Execucoes::encerrar();}}
        F3Base_Operacao_Intencoes::recuperar();F3Base_Operacao_Intencoes::podar();$agenda=self::agenda();$saldo=count(array_filter($agenda,static fn($a)=>$a['atrasado']&&$a['registrada']));$ok=!array_filter($rows,static fn($r)=>empty($r['ok']));
        if(!empty($entrada['compacto'])){return array('ok'=>$ok,'codigo'=>$saldo||!$ok?'execucao_parcial':'execucao_concluida','resultados'=>array_map(static fn($r)=>array_intersect_key($r,array_flip(array('id','ok','codigo','run_id','status','resultado_modulo_confirmado'))),$rows),'tarefas_vencidas_restantes'=>$saldo,'detalhe'=>'f3base/saude-ler');}
        return array('ok'=>$ok,'codigo'=>$saldo||!$ok?'execucao_parcial':'execucao_concluida','origem'=>F3Base_Execucoes::origem(),'resultados'=>$rows,'agenda'=>$agenda,'tarefas_vencidas_restantes'=>$saldo,'limite_trabalhos'=>$limit,'orcamento_segundos'=>F3Base_Execucoes::orcamento(),'prioridade'=>array('hooks_maximos'=>7,'segundos_por_hook'=>30,'ordem'=>array('captacao','entrega','manutencao'),'limite_trabalhos_aplica'=>'manutencao'),'intencoes'=>F3Base_Operacao_Intencoes::resumo(),'execucoes'=>F3Base_Execucoes::resumo());
    }
    public static function alinhar_agenda(): void {
        $signature=hash('sha256',wp_timezone_string().'|'.(F3Base_Options::ler('f3base_gsc')['horario']??'05:00'));
        if((get_option('f3base_agenda',array())['assinatura']??'')===$signature){return;}$ok=true;
        foreach(self::eventos() as $e){if(!$e['schedule']||$e['args']||$e['timestamp']<=time()){continue;}$o=(object)array('hook'=>$e['hook'],'timestamp'=>$e['timestamp'],'args'=>$e['args'],'schedule'=>$e['schedule']);$new=self::alinhar_evento(clone $o);if($new->timestamp===$o->timestamp){continue;}
            self::$consumindo=true;try{$saved=wp_schedule_event($new->timestamp,$new->schedule,$new->hook,$new->args);if($saved){$ok=wp_unschedule_event($o->timestamp,$o->hook,$o->args)&&$ok;}else{$ok=false;}}finally{self::$consumindo=false;}
        }if($ok){F3Base_Options::atualizar_estado('f3base_agenda',static fn($v)=>array_merge($v,array('assinatura'=>$signature)));}
    }
    public static function recuperar_agendamentos(): void {
        if(self::$desativando||!empty(F3Base_Recuperacao::ler()['pausado'])){return;}
        try{F3Base_Operacao_Intencoes::recuperar();self::alinhar_agenda();}catch(Throwable $x){error_log('F3BASE recuperacao=intencoes_leitura_falhou');return;}
        foreach(F3Base_Options::ler(self::OPTION) as $id=>$s){
            $r=$s['recuperacao']??array();if(empty($r['pendente'])||($s['lease']['ate']??0)>time()||($r['quando']??0)>time()||!isset(self::$callbacks[$r['hook']??''])){continue;}
            $e=array('id'=>$id,'hook'=>$r['hook'],'args'=>$r['args']??array(),'timestamp'=>$r['timestamp']??null);
            try{$intention=F3Base_Operacao_Intencoes::obter($e);}catch(Throwable $x){continue;}
            // A due durable intention must remain due. Public reads never renew its backoff.
            if($intention){if($intention['estado']==='pendente'){F3Base_Operacao_Intencoes::agendar(max(time()+1,$intention['tentar_em']));}continue;}
            if(F3Base_Operacao_Intencoes::da_tarefa($id)){continue;}
            self::adiar($e,'retomada_apos_interrupcao');
        }
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('executar-pendentes','Executar tarefas vencidas do Core sob reserva e orçamento',array(__CLASS__,'executar_pendentes'),array('compacto'=>array('type'=>'boolean','default'=>false),'tarefas'=>array('type'=>'array','maxItems'=>count(self::tarefas()),'items'=>array('type'=>'string','enum'=>array_keys(self::tarefas()))),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>3),'intencao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'liberar_reserva_reaquecimento'=>array('type'=>'boolean'),'motivo'=>array('type'=>'string','minLength'=>5,'maxLength'=>240),'reconciliar_esperas'=>array('type'=>'boolean','default'=>false),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'reativar_esgotada'=>array('type'=>'boolean','default'=>false)),array(),false);
    }
    public static function desativar(): void {wp_unschedule_hook('f3base_operacao_retomar');wp_unschedule_hook('f3base_operacao_urgente');self::$desativando=true;}
    /** Read-only evidence: no rescheduling, no change to the waiting occurrence. */
    public static function esperas(): array {
        $state=F3Base_Options::ler(self::OPTION);$out=array();
        for($page=1;$page<=10;$page++){
            try{$rows=F3Base_Operacao_Intencoes::listar($page);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'intencoes_leitura_falhou','itens'=>$out);}foreach($rows as $row){
                $s=$state[$row['id']]??array();$delay=max(0,time()-(int)$row['tentar_em']);
                $out[]=array('tarefa'=>$row['id'],'intencao'=>$row['intencao'],'ocorrencia_em'=>$row['timestamp'],'estado'=>$row['estado'],'causa'=>$row['codigo'],'inicio_espera'=>$row['criada_em'],'idade_segundos'=>max(0,time()-$row['criada_em']),'tentar_em'=>$row['tentar_em'],'atraso_elegivel_segundos'=>$delay,'parada'=>$row['estado']==='pendente'&&!$row['em_execucao']&&$delay>=900,'reserva_ate'=>$row['reserva_ate'],'ultimo_progresso'=>$s['ultimo_sucesso']['fim']??null,'ultima_execucao'=>$s['ultima']??array(),'ultima_falha'=>$s['ultima_falha']??null,'agenda_confirmada'=>wp_next_scheduled('f3base_operacao_retomar')!==false&&wp_next_scheduled('f3base_operacao_retomar')<=max(time()+1,$row['tentar_em'],$row['reserva_ate']),'fontes'=>self::fontes_espera($row,$s),'acao'=>'Consultar a causa; simular executar-pendentes com reconciliar_esperas para esta tarefa. Quotas e guardas continuam válidas.');
            }if(count($rows)<100){break;}
        }
        return array('itens'=>$out,'limiar_segundos'=>900,'corte'=>$page>10,'somente_leitura'=>true);
    }
    private static function fontes_espera(array $i,array $s): array {
        $r=$s['recuperacao']??array();$scope=isset($r['hook'])?F3Base_Operacao_Intencoes::escopo(array('hook'=>$r['hook'],'args'=>$r['args']??array())):null;
        return array('hook'=>$i['hook'],'escopo_intencao'=>$i['escopo'],'checkpoint_presente'=>!empty($r),'escopo_checkpoint'=>$scope,'concordam'=>$scope!==null&&hash_equals($i['escopo'],$scope),'motivo'=>$scope===null?'checkpoint_ausente':(hash_equals($i['escopo'],$scope)?'escopo_concordante':'escopo_divergente'),'despertador_em'=>wp_next_scheduled('f3base_operacao_retomar')?:null);
    }
    private static function reconciliar_espera(array $e): array {
        $ids=$e['tarefas']??array();if(!is_array($ids)||count($ids)!==1||!isset(self::tarefas()[$ids[0]])){return array('ok'=>false,'codigo'=>'reconciliacao_exige_uma_tarefa');}
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}
        $id=$ids[0];$file=null;$locked=false;global $wpdb;$lock='f3core:'.substr(hash('sha256',DB_NAME.'|'.$wpdb->prefix.'|'.$id),0,48);
        try{
            $file=F3Base_Recuperacao::reservar_tarefa($id);if(!$file){return array('ok'=>false,'codigo'=>'reserva_ocupada');}
            $locked=(int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))===1;if(!$locked){return array('ok'=>false,'codigo'=>'reserva_ocupada_ou_banco_indisponivel');}
            $s=F3Base_Options::ler(self::OPTION)[$id]??array();$r=$s['recuperacao']??array();
            if(($s['lease']['ate']??0)>time()){return array('ok'=>false,'codigo'=>'reserva_ativa');}
            $candidates=F3Base_Operacao_Intencoes::da_tarefa($id);$i=array();
            if(!empty($e['intencao'])){foreach($candidates as $candidate){if(hash_equals($candidate['intencao'],$e['intencao'])){$i=$candidate;break;}}if(!$i){return array('ok'=>false,'codigo'=>'intencao_nao_encontrada');}}
            elseif(count($candidates)>1){return array('ok'=>false,'codigo'=>'selecione_intencao','intencoes'=>array_column($candidates,'intencao'));}
            elseif($candidates){$i=$candidates[0];}
            $hook=$r['hook']??'';
            if(!$i&&self::identificar_hook($hook)!==$id){return array('ok'=>true,'codigo'=>'sem_recuperacao_pendente','persisted'=>false);}
            $event=$i?:array('id'=>$id,'hook'=>$hook,'args'=>$r['args']??array(),'timestamp'=>$r['timestamp']??time());
            if(!empty($i['em_execucao'])){return array('ok'=>false,'codigo'=>'reserva_ativa');}
            $rev=hash('sha256',wp_json_encode(array($s,$i)));$base=array('fontes'=>$i?self::fontes_espera($i,$s):array('motivo'=>'checkpoint_sem_intencao'),'tarefa'=>$id,'revisao'=>$rev,'intencao'=>$i['intencao']??null,'tentar_em'=>$i['tentar_em']??max(time()+1,(int)($r['quando']??0)),'causa'=>$i['codigo']??'interrupcao_sem_intencao','efeito'=>'Conservar ocorrência/prazo, materializar intenção ausente e confirmar despertador. Não executa o callback.');
            if($i&&$i['estado']==='esgotada'){
                $success=(int)($s['ultimo_sucesso']['fim']??0);
                if($id==='integracoes'&&!$i['args']){$account=F3Base_Options::ler('f3base_pipedrive_estado');if(F3Base_Integracoes::pipedrive_verificado($account)){$success=max($success,(int)($account['em']??0));}}
                if(!$i['args']&&$success>(int)$i['atualizada_em']){
                    $base['efeito']='Encerrar a espera esgotada coberta por sucesso posterior do módulo, sem executar callback.';$base['sucesso_posterior_em']=$success;
                    if(($e['simular']??true)!==false){return $base+array('ok'=>true,'simulado'=>true,'persisted'=>false,'execucao_realizada'=>false);}
                    if(!hash_equals($rev,(string)($e['revisao']??''))){return $base+array('ok'=>false,'codigo'=>'conflito');}
                    $n=$wpdb->update(F3Base_Operacao_Intencoes::tabela(),array('estado'=>'concluida','codigo'=>'coberta_por_sucesso_posterior','atualizada_em'=>time(),'reativada_por'=>get_current_user_id()),array('chave'=>$i['intencao'],'estado'=>'esgotada','atualizada_em'=>$i['atualizada_em']));
                    return $base+array('ok'=>$n===1,'codigo'=>$n===1?'espera_encerrada_por_sucesso':'conflito','persisted'=>$n===1,'execucao_realizada'=>false);
                }
            }
            if($i&&in_array($i['estado'],array('suspensa','esgotada'),true)){
                $action=$i['estado']==='esgotada'?array('ability'=>'f3base/executar-pendentes','entrada'=>array('tarefas'=>array($id),'intencao'=>$i['intencao'],'reativar_esgotada'=>true,'simular'=>true),'aplicar'=>'Repetir com simular=false e a revisao devolvida pela simulação.'):array('ability'=>'f3base/operacao-recuperacao','acao'=>'retomar','orientacao'=>'Concluir a reconciliação da restauração e retomar o Core conforme o schema da ability.');
                return $base+array('ok'=>false,'codigo'=>'estado_exige_acao_propria','acao_necessaria'=>$action,'execucao_realizada'=>false,'persisted'=>false);
            }
            if(($e['simular']??true)!==false){return $base+array('ok'=>true,'simulado'=>true);}
            if(!hash_equals($rev,(string)($e['revisao']??''))){return $base+array('ok'=>false,'codigo'=>'conflito');}
            if(!$i&&!F3Base_Operacao_Intencoes::registrar($event,$base['tentar_em'])){return $base+array('ok'=>false,'codigo'=>'intencao_nao_persistida');}
            $save=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($id,$s){if(($v[$id]??array())!==$s){return null;}$v[$id]['recuperacao']['pendente']=false;$v[$id]['recuperacao']['tipo']='espera_duravel';$v[$id]['reconciliada_em']=time();$v[$id]['reconciliada_por']=get_current_user_id();return $v;});
            if(empty($save['persisted'])){return $base+array('ok'=>false,'codigo'=>$save['codigo'],'persisted'=>false);}
            $scheduled=F3Base_Operacao_Intencoes::agendar(max(time()+1,$base['tentar_em']));
            return $base+array('ok'=>$scheduled,'codigo'=>$scheduled?'espera_reconciliada':'agenda_nao_confirmada','persisted'=>true,'agendamento_confirmado'=>$scheduled,'execucao_realizada'=>false);
        }catch(Throwable $erro){return array('ok'=>false,'codigo'=>'reconciliacao_leitura_ou_gravacao_falhou');}finally{if($locked){$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}F3Base_Recuperacao::liberar_tarefa($file);F3Base_Recuperacao::sair();}
    }
	private static function saldo( string $id, array $estado ): array {
		$r = array(
			'conhecido'    => false,
			'quantidade'   => null,
			'observado_em' => null,
			'escopo'       => 'nao_medido',
			'fonte'        => 'nenhuma',
		);
		if ( 'acessos' === $id ) {
			$v           = F3Base_Options::ler( 'f3base_acessos_estado' );
			$r['escopo'] = 'arquivos_pendentes_na_ultima_inspecao';
			$r['fonte']  = 'f3base_acessos_estado';
			if ( ! empty( $v['tentativa'] ) && array_key_exists( 'pendentes', $v ) && empty( $v['erro'] ) && ( $v['config_hash'] ?? '' ) === F3Base_Modulo_Acessos_Servidor::config_hash() ) {
				$r['quantidade']   = max( 0, (int) $v['pendentes'] );
				$r['observado_em'] = (int) $v['tentativa'];
				$r['conhecido']    = true;
			}
		} elseif ( 'capi' === $id && F3Base_Capi_Fila::pronta() ) {
			global $wpdb;
			$linhas      = F3Base_Capi_Fila::resumo();
			$r['escopo'] = 'eventos_nao_terminais_inclui_reconciliacao';
			$r['fonte']  = 'fila_capi_estados';
			if ( '' === $wpdb->last_error ) {
				$r['quantidade'] = 0;
				foreach ( $linhas as $linha ) {
					if ( in_array( $linha['estado'], array( 'pendente', 'reservado', 'enviando', 'cancelando', 'suspenso', 'incerto' ), true ) ) {
						$r['quantidade'] += (int) $linha['eventos']; }
				}
				$r['observado_em'] = time();
				$r['conhecido']    = true;
			}
		} elseif ( ! empty( $estado['saldo_resultado'] ) ) {
			$r = array_merge(
				$r,
				$estado['saldo_resultado'],
				array(
					'conhecido' => true,
					'fonte'     => 'ultimo_resultado_do_modulo',
				)
			);
		}
		return $r;
	}

    public static function prova_publica(string $id): ?array {
        if($id==='cache'){$p=F3Base_Cache_Evidencia::ler()['ultima_tentativa']??array();return array_intersect_key($p,array_flip(array('status','codigo','motivo','checked_at','origem','hit','persisted','artefato_cache')));}
        if($id==='robots'){$p=F3Base_Options::ler(F3Base_Robots_Arquivo::OPTION)['entrega']??array();return array_intersect_key($p,array_flip(array('ok','codigo','erro','verificado_em','modo','esperado_sha256','recebido_sha256')));}
        return null;
    }
	private static function resultado_seguro( array $r ): array {
		$saida = array();
        $error=$r['erro_detalhes']??$r['entrega']['erro_detalhes']??(is_array($r['erro']??null)?$r['erro']:null);if(is_array($error)){$saida['erro']=array_intersect_key($error,array_flip(array('codigo_interno','etapa','classe','mensagem','arquivo','linha')));}
		foreach ( array( 'processados', 'restantes', 'saldo', 'expirados', 'arquivados', 'eliminados', 'falhas_confirmacao', 'limpezas_pendentes', 'ocorrencias', 'formularios_incluidos' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_numeric( $r[ $k ] ) ) {
				$saida[ $k ] = max( 0, (int) $r[ $k ] ); }
		}
		foreach ( array( 'ok', 'parcial', 'reagendado', 'persisted', 'local_confirmado', 'incompleto', 'resultado_modulo_confirmado' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_bool( $r[ $k ] ) ) {
				$saida[ $k ] = $r[ $k ]; }
		}
		if ( isset( $r['codigo'] ) && is_string( $r['codigo'] ) ) {
			$saida['codigo'] = substr( sanitize_key( $r['codigo'] ), 0, 64 ); }
        foreach(array('escopo','motivo') as $k){if(isset($r[$k])&&is_string($r[$k])){$saida[$k]=mb_substr(sanitize_text_field($r[$k]),0,500);}}
        if(isset($r['checked_at'])){$saida['checked_at']=max(0,(int)$r['checked_at']);}
		if ( isset( $r['agenda']['saldo'] ) ) {
			$saida['saldo'] = max( 0, (int) $r['agenda']['saldo'] ); }
		return $saida;
	}

}
