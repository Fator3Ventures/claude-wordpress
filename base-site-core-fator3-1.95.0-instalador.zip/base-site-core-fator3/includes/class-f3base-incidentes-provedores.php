<?php
/** Adaptadores de leitura local para as versões de provedores anteriores ao contrato 1. */
declare(strict_types=1);
defined('ABSPATH') || exit;

final class F3Base_Incidentes_Provedores {
    private const LEGADOS = [
        'Fator3\\Meta\\Worker::notify'=>'meta',
        'Fator3\\LinkedIn\\Credentials::notice'=>'linkedin',
        'Fator3\\McpGoogle\\RenewalNotifications::send_once'=>'google',
        'Fator3\\McpGoogle\\Automation\\Alerts::channel_blocked'=>'google',
        'Fator3\\McpGoogle\\Automation\\Alerts::send'=>'google',
    ];
    private static bool $encaminhando=false;

    public static function cron(array $s): void {
        $ultima=max((int)($s['ultima_cli']??0),(int)($s['iniciado_em']??0));
        if (!$ultima) {return;}
        self::situacao('core','cron_sem_passagem','executor-cli',$ultima<time()-HOUR_IN_SECONDS,$ultima+HOUR_IN_SECONDS);
    }
    private static function situacao(string $p,string $c,string $id,bool $falha,int $desde=0): array {
        return F3Base_Incidentes::publicar(['pacote'=>$p,'codigo'=>$c,'recurso'=>$id,
            'desde'=>min(time(),$desde?:time()),'estado'=>$falha?'aberto':'recuperado']);
    }

    public static function observar(): void {
        if (F3Base_Alertas_Operacionais::destinatario()!=='') {
            self::situacao('core','destino_tecnico_ausente','email-wordpress',false);
        }
        foreach (['cron','meta','linkedin','google','pipedrive','canal','graph'] as $origem) {
            try {
                if ($origem==='cron') {self::cron((array)get_option(F3Base_Zelador::ESTADO,[]));}
                else {self::$origem();}
            } catch (Throwable $erro) {
                // Uma falha ao obter diagnóstico não confirma recuperação nem bloqueia os demais.
                do_action('f3base_incidente_leitura_indisponivel',$origem);
            }
        }
    }

    public static function meta(): void {
        if (!is_callable(['Fator3\\Meta\\Worker','health'])) {return;}
        $key='f3base_incidentes_meta_ativos';
        if (!F3Base_Pipedrive_Fila::travar_linha($key)) {return;}
        try {
            $h=\Fator3\Meta\Worker::health();
            if (!isset($h['issues']) || !is_array($h['issues'])) {return;}
            $ativos=[];
            foreach ($h['issues'] as $i) {
                if (!in_array($i['code'],['connection_authorization_failed','schedule_authorization_failed',
                    'schedule_resource_access_failed','schedule_overdue','schedule_budget_exhausted','worker_missing'],true)) {continue;}
                $id=hash('sha256',$i['code'].'|'.($i['schedule_id']??$i['connection_id']??'worker'));
                $ativos[$id]=true;
                self::situacao('meta','agenda_parada',$id,true,(int)($i['blocked_since']??$i['last_error']['observed_at']??0));
            }
            wp_cache_delete($key,'options');
            $antes=(array)get_option($key,[]);
            foreach (array_diff_key($antes,$ativos) as $id=>$v) {
                $r=self::situacao('meta','agenda_parada',$id,false);
                if (empty($r['ok'])) {$ativos[$id]=true;}
            }
            if ($antes!==$ativos) {update_option($key,$ativos,false);}
        } finally {F3Base_Pipedrive_Fila::liberar_linha($key);}
    }

    public static function linkedin(): void {
        if (!is_callable(['Fator3\\LinkedIn\\Credentials','status'])) {return;}
        foreach (\Fator3\LinkedIn\Credentials::status()['connections']??[] as $c) {
            if (empty($c['enabled'])) {continue;}
            $id=(string)$c['connection_id'];
            if ($c['token_configured']) {F3Base_Incidentes::vencimento('linkedin','token_vencendo',$id,(int)$c['expires_at']);}
            if ($c['refresh_configured']) {F3Base_Incidentes::vencimento('linkedin','refresh_vencendo',$id,(int)$c['refresh_expires_at']);}
            self::situacao('linkedin','credencial_invalida',$id,!empty($c['incident']) || !empty($c['failures']));
        }
    }

    public static function google(): void {
        if (!is_callable(['Fator3\\McpGoogle\\ConversionDelivery','read'])) {return;}
        $conexoes=\Fator3\McpGoogle\Connections::registry_verified();
        if (is_wp_error($conexoes)) {return;}
        foreach (array_keys($conexoes) as $id) {
            \Fator3\McpGoogle\Connections::run($id,static function() use ($id) {
                $c=\Fator3\McpGoogle\ConversionDelivery::read();
                if (is_array($c) && !empty($c['enabled'])) {
                    foreach (['ga4','google_ads'] as $alvo) {
                        $recurso=$id.'/'.$alvo;
                        F3Base_Incidentes::vencimento('google','prova_vencendo',$recurso,(int)($c['verified'][$alvo]['expires']??0));
                        $r=$c['renewal'][$alvo]??[];
                        if (in_array($r['result']??'',['success','failed'],true)) {
                            self::situacao('google','renovacao_falhou',$recurso,$r['result']==='failed',(int)($r['last_at']??0));
                        }
                    }
                }
                $offset=0;
                do {
                    $page=\Fator3\McpGoogle\Automation\Alerts::state(['limit'=>100,'offset'=>$offset]);
                    if (empty($page['available'])) {return;}
                    foreach ($page['incidents'] as $r) {
                        if (($r['event'] ?? '') === 'key_metadata' && ($r['status'] ?? '') === 'open'
                            && ($r['code'] ?? '') === 'key_metadata_permission_denied'
                            && ($r['resource'] ?? '') === 'service-account-key-metadata') {
                            F3Base_Incidentes::publicar([
                                'pacote'=>'google', 'codigo'=>'autorizacao_recusada',
                                'recurso'=>$id.'/service-account-key-metadata', 'estado'=>'aberto',
                                'desde'=>(int)$r['created_at'], 'acao_humana'=>true,
                                'iam'=>['permissao'=>'iam.serviceAccountKeys.get', 'projeto'=>$r['context']['project_id'] ?? null],
                            ]);
                        }
                        if (in_array($r['event']??'',['channel','access','cron_late','sitemap_error','scheduled_check'],true)
                            && in_array($r['status']??'',['open','resolved'],true)) {
                            self::situacao('google','integracao_indisponivel',$id.'/'.$r['id'],$r['status']==='open',(int)$r['created_at']);
                        }
                    }
                    $offset=$page['next_offset'];
                } while ($offset!==null);
            });
        }
    }

    public static function pipedrive(): void {
        if (!class_exists('Fator3\\Pipedrive\\CoreClient')) {return;}
        $s=(array)get_option('f3base_pipedrive_estado',[]);
        if (empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])) {return;}
        $falha=in_array($s['codigo']??'',['credencial_ou_permissao_recusada','credencial_recusada','permissao_recusada','conta_divergente'],true);
        if ($falha || F3Base_Integracoes::pipedrive_verificado($s)) {self::situacao('pipedrive','autorizacao_recusada','conta',$falha);}
    }

    public static function canal(): void {
        F3Base_Incidentes::observar_registro_canal();
    }

    /** Observação passiva. Inicializar o REST antes do adaptador CLI perde as rotas desta requisição. */
    public static function registro_canal(): ?array {
        if (!did_action('wp_loaded') || doing_action('init') || doing_action('rest_api_init')
            || doing_action('f3_mcp_adapter_init') || doing_action('wp_abilities_api_init')
            || !is_callable(['Fator3\\McpFiles\\ServerContract', 'status'])) {
            return null;
        }
        $status = \Fator3\McpFiles\ServerContract::status();
        $codigos = ['mcp_core_missing', 'mcp_server_disabled', 'mcp_server_missing',
            'mcp_route_conflict', 'mcp_route_missing', 'mcp_tools_missing'];
        $erros = array_values(array_intersect($codigos, $status['errors'] ?? []));
        $verificado = ($status['registry_checked'] ?? false) === true;
        if (!$verificado) {
            $erros = array_values(array_intersect($erros, ['mcp_core_missing', 'mcp_server_disabled']));
        }
        if (in_array('mcp_registry_error', $status['errors'] ?? [], true)) {return null;}
        if ($verificado && !$erros && (
            ($status['server_registered'] ?? null) !== true || ($status['tools_ready'] ?? null) !== true
        )) {return null;}
        return ['verificado'=>$verificado, 'erros'=>$erros];
    }

    public static function graph(): void {
        $versao=F3Base_Modulo_Meta_Capi::versao_graph();
        if (F3Base_Modulo_Meta_Capi::token()==='' || F3Base_Modulo_Meta_Capi::pixel_id()==='') {return;}
        $prazos=apply_filters('f3base_graph_fim_versoes',['v21.0'=>strtotime('2027-01-21 00:00:00 UTC')]);
        if (isset($prazos[$versao])) {F3Base_Incidentes::vencimento('meta','graph_vencendo','capi',$prazos[$versao]);}
        
    }

    /** Confere classe e método do produtor. Nunca consulta os argumentos da pilha. */
    private static function origem_legada(): string {
        foreach (debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,18) as $f) {
            $nome=($f['class']??'').'::'.$f['function'];
            if (isset(self::LEGADOS[$nome])) {return $nome;}
        }
        return '';
    }

    public static function email_legado($pre,array $mail) {
        if ($pre!==null || self::$encaminhando) {return $pre;}
        $titulo=$mail['subject']??'';
        if (!is_string($titulo)) {return $pre;}
        if (!preg_match('/^(?:Google: |Fator3 MCP Meta: atenção às coletas|Fator3 MCP LinkedIn — atenção à credencial|Fator3 — Verificação de conversões|Fator3 MCP Google — tarefa bloqueada)/u',$titulo)) {return $pre;}
        $origem=self::origem_legada();
        if ($origem==='') {return $pre;}
        self::$encaminhando=true;
        try {$fonte=self::LEGADOS[$origem]; self::$fonte();}
        catch (Throwable $e) {do_action('f3base_incidente_leitura_indisponivel',$fonte);}
        finally {self::$encaminhando=false;}
        // O transporte antigo não enviou este e-mail. A entrega do Core tem recibo próprio.
        return false;
    }

    public static function webhook_legado($pre,array $args,string $url) {
        if ($pre!==false || strtolower((string)wp_parse_url($url,PHP_URL_HOST))!=='hooks.slack.com') {return $pre;}
        return self::origem_legada()==='Fator3\\McpGoogle\\Automation\\Alerts::channel_blocked'
            ? new WP_Error('canal_tecnico_email','O incidente técnico usa o e-mail do Core.') : $pre;
    }
}
