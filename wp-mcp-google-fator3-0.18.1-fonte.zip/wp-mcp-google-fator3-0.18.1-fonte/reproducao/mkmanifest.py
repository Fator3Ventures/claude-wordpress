"""Write a laboratory manifest with hashed local inputs.

Usage: python3 reproducao/mkmanifest.py <out.json> key=path[@version] ...
Keys: runtime, wordpress, candidate, baseline, mcp, core, baseline_mcp, baseline_core, meta, linkedin.
Compare the resulting hashes with plugin/wp-mcp-google-fator3/evidence/0181/inputs.json.
"""
import sys, json, importlib.util
from pathlib import Path
LAB = Path(__file__).resolve().parent.parent / 'plugin/wp-mcp-google-fator3/tools/lab.py'
spec = importlib.util.spec_from_file_location('lab', LAB); lab = importlib.util.module_from_spec(spec); spec.loader.exec_module(lab)
out = Path(sys.argv[1]); inputs = {}
for arg in sys.argv[2:]:
    k, v = arg.split('=', 1); path, _, ver = v.partition('@'); p = Path(path).resolve()
    inputs[k] = {'path': str(p), 'version': ver, 'sha256': lab.tree_hash(p) if p.is_dir() else lab.sha(p)}
out.write_text(json.dumps({'inputs': inputs}, indent=2) + '\n'); print(out)
