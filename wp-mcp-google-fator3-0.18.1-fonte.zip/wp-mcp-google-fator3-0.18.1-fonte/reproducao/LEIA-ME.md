# Reprodução da revisão Google 0.18.1

O fonte preserva o runtime exato e as evidências finais em `plugin/wp-mcp-google-fator3/evidence/0181`. O instalador é fornecido separadamente; não há ZIP aninhado. `validation0181.json` reúne seis cenários de duas execuções do gate com a mesma identidade. Os relatórios originais de cada execução também estão preservados.

## Dependências

Linux amd64; Python 3; PHP 8.3.6 e MySQL 8.0.46 extraídos dos pacotes oficiais em `runtime-dependencies.json`. Execute `python3 download-runtime.py /caminho/novo/runtime` a partir desta pasta; não instala serviços no sistema. Use `usr/bin/php8.3` com `LD_LIBRARY_PATH` apontando para `usr/lib/x86_64-linux-gnu` do runtime. O laboratório gera o php.ini com os módulos necessários. Para executar PHPUnit e o gate, use um wrapper PHP com os mesmos módulos (ctype, fileinfo, tokenizer, phar, mbstring, mysqlnd, mysqli, pdo, pdo_mysql, dom, xml, simplexml, xmlreader, xmlwriter, curl, zip, iconv e posix).

WordPress: https://wordpress.org/wordpress-7.1.2.tar.gz e https://wordpress.org/wordpress-7.1.3.tar.gz. WP-CLI 2.12.0: https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar — conferir o hash registrado, pois a URL pode avançar. Os hashes usados nesta revisão constam de `evidence/0181/inputs.json`. Obtenha os instaladores Google 0.17.0 e 0.18.0, MCP 0.28.0, Core 1.48.0, Meta 0.6.0 e LinkedIn 0.7.0 das entregas correspondentes. A convivência adicional foi executada com Meta 0.7.0 e LinkedIn 0.8.1.

## Execução

1. Em `plugin/wp-mcp-google-fator3`, execute `composer install` usando o lock fornecido e `php vendor/bin/phpunit --log-junit /caminho/evidence/unit.xml`. PHPUnit executado nesta revisão: 9.6.37, 1160 testes, 14271 asserções.
2. Execute `npm ci --prefix reproducao/jsdom` a partir da raiz do fonte; exporte `NODE_PATH` com o diretório `node_modules` resultante.
3. Use `mkmanifest.py` para gerar três manifestos com caminhos locais: mínimo 7.1.2/base 0.17.0; atual 7.1.3/base 0.17.0; atualização direta 7.1.3/base 0.18.0. Declare `runtime`, `wordpress`, `candidate`, `baseline`, `mcp`, `core`, `baseline_mcp`, `baseline_core`, `meta`, `linkedin` e `wp_cli`. O runtime é um diretório; os demais são arquivos. Todos recebem SHA-256.
4. Execute `python3 tools/release0181.py --manifest min.json --manifest-current atual.json --manifest-upgrade upgrade018.json --work-base /caminho/novo/labs --evidence /caminho/novo/evidence --php /caminho/php-wrapper`. Pode dividir os cenários com `--only clean --only clean-713` e, em outra execução, `--only upgrade --only upgrade-018 --only google-first --only isolated`. Não reutilize diretórios não vazios.
5. O laboratório usa bancos novos, transporte MCP HTTP local e respostas Google sintéticas. Bloqueia HTTP externo e e-mail. Não usa credenciais reais. Os processos são encerrados no final. O teste CLI exige o arquivo WP-CLI declarado e verificado por hash.

## Prova negativa e limites

`negative-0180.json` registra cinco cenários que falharam no diagnóstico original. `readiness0181.php` cobre esses casos e cinco controles adicionais; as suites finais registram 40 verificações cada. `preliminary-observations.json` preserva interferências de fixtures e do diretório sincronizado observadas antes da matriz final, sem tratá-las como aprovação. Uma repetição independente do rollback, fora desse diretório, também passou com inventário exato.

Os testes não homologam atribuição comercial nem credenciais Google reais. A inspeção do DOM não é uma validação visual de navegador. Nenhum site remoto foi alterado.
