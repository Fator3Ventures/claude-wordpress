"""Download and extract the exact official runtime packages into a new directory."""
from pathlib import Path
import concurrent.futures, hashlib, json, subprocess, sys, urllib.request

base = Path(__file__).resolve().parent
target = Path(sys.argv[1]).resolve()
if target.exists() and any(target.iterdir()):
    raise ValueError('Use an empty runtime directory')
target.mkdir(parents=True, exist_ok=True)
cache = target.parent / (target.name + '-downloads')
cache.mkdir(exist_ok=True)

def download(item):
    path = cache / item['url'].rsplit('/', 1)[-1]
    if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
        data = urllib.request.urlopen(item['url'], timeout=90).read()
        if hashlib.sha256(data).hexdigest() != item['sha256']:
            raise ValueError('Hash mismatch: ' + item['name'])
        temporary = path.with_suffix('.part')
        temporary.write_bytes(data)
        temporary.replace(path)
    return path

with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    for path in pool.map(download, json.loads((base / 'runtime-dependencies.json').read_text())):
        process = subprocess.Popen(['dpkg-deb', '--fsys-tarfile', str(path)], stdout=subprocess.PIPE)
        subprocess.run(['tar', '--no-same-owner', '-xf', '-', '-C', str(target)], stdin=process.stdout, check=True)
        process.stdout.close()
        if process.wait() != 0:
            raise RuntimeError('Extraction failed: ' + path.name)
print(target)
