# Validação — 0.18.1

Revisão independente da 0.18.0, comparada à 0.17.0. A suíte original de 1160 testes passou, mas cinco regressões de diagnóstico foram reproduzidas em WordPress real. A correção acrescenta a suíte `readiness0181` com provas negativas e controles de conexão, paginação e integração desabilitada.

`tools/release0181.py` valida o instalador exato, lint, contratos, documentação por MCP HTTP e seis cenários: limpo em WordPress 7.1.2 e 7.1.3; atualização da 0.17.0; atualização direta da 0.18.0; ativação do Google antes dos acompanhantes; Google isolado. As atualizações exercitam rollback e reaplicação com inventário exato e preservação de configurações, segredos, tarefas e dados sociais. PHP 8.3.6 e MySQL 8.0.46. A matriz de referência usa MCP 0.28.0, Core 1.48.0, Meta 0.6.0 e LinkedIn 0.7.0, sem alteração.

A documentação e os dados de configuração continuam locais; Google e e-mail são simulados. O teste de entrega altera o ID de medição durante a verificação e exige recusa antes da coleta. O diagnóstico não executa reparo nem transporte remoto. O DOM autenticado verifica interações, sem equivaler a inspeção visual em navegador.

Evidências correntes em `evidence/0181`; evidências de outras versões são históricas. O relatório externo registra os resultados finais e a combinação adicional dos acompanhantes disponíveis. Não comprova atribuição comercial, propagação na Data Manager, credenciais reais, renovação de dois dias, multisite ou PHP-FPM. O Site-Teste remoto não recebe instalação por esta revisão.
