# Fechamento documental — 0.18.1

Patch da revisão independente da 0.18.0. Mantém as 287 habilidades, 36 opções, oito checks e contratos públicos. Corrige somente a classificação da prontidão, a consulta de incidentes abertos e a mensagem do painel, com documentação e testes correspondentes. Nenhum arquivo de runtime novo ou removido em relação à 0.18.0.

O instalador entregue deve corresponder byte a byte à árvore e ao candidato validados. O relatório externo é canônico e contém o hash do fonte; a cópia interna precede seu fechamento. Evidências históricas são preservadas em seus diretórios. Não há modificação de Core ou outros plugins, nem impacto técnico que exija encaminhamento a seus mantenedores.
