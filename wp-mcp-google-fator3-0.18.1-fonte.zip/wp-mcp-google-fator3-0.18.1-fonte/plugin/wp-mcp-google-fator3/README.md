# Fator3 MCP Google 0.18.1

Integra Analytics 4, Ads, Search Console, Tag Manager, Site Verification, Sheets e Drive pela Abilities API e Fator3 MCP. **Service Account é o padrão**, com OAuth em aba separada e uma identidade ativa por conexão. O plugin é genérico; não depende de um padrão de agência externo.

**287 habilidades: 112 de leitura e 175 de escrita.** Todas publicam `meta.fator3.version:0.18.1`. Configuração **4.0.0**, 36 opções; execução **2.0.0**; catálogo **3.0.0**; armazenamento e manutenção **2.0.0**; leitor PHP **search-console-reader/1.0.0**.

## Mudanças da 0.18.1

Ordem do dono de 22/10/2026, sem pedido numerado aberto. Base direta 0.17.0; nenhum contrato público ou identificador mudou. Dos schemas das 286 habilidades existentes, seis mudaram só por acréscimo: descrições nos parâmetros de `google/mcp-read`/`google/mcp-write` (M1) e campos já devolvidos declarados nas saídas (M6).

- **M1 — Descrições em português.** As 106 habilidades `gtm/*` geradas do documento Discovery do Tag Manager passam a publicar descrição revisada em português, do mesmo catálogo `docs/labels-pt-br.json` (seção `descriptions`). Nenhuma habilidade publica rótulo ou descrição em inglês. Os parâmetros `ability` e `parameters` de `google/mcp-read` e `google/mcp-write` (ferramentas `google-mcp-read`/`google-mcp-write` do MCP) ganham descrição em português. As descrições dos campos dos schemas de entrada gerados do Discovery continuam as do Google.
- **M2 — `google/readiness-status`.** Nova leitura local: veredito `ready`, `attention` ou `blocked` da conexão, com cada verificação (credencial, armazenamento, recuperação, executor, entrega GA4 e Ads com validade e renovação, incidentes abertos e Site Core) e a ação a tomar. Não consulta o Google, não repara e não envia e-mail. Também em `wp mcp-google readiness` e num cartão no topo da aba Conversões.
- **M3 — Leitura de estado mais leve.** `google/conversion-delivery-status`, `google/status` e a tela Conversões leem a fotografia de medição do Site Core uma vez por chamada. No laboratório com Core 1.48.0, `google/conversion-delivery-status` caiu de 358 para cerca de 174 consultas SQL. Entrega e verificação continuam lendo o Core de novo dentro das próprias cercas.
- **M4 — Seleção da conexão GA4 pelo fluxo.** Desde a 0.16.0 o ID de medição vem do Site Core e é igual em todas as conexões. A seleção da conexão que entrega GA4 usava esse ID e marcava `ambiguous_connection` sempre que duas conexões tinham entrega habilitada (por exemplo, uma para GA4 e outra para Ads). Agora a conexão GA4 é a que tem o fluxo (`stream`) configurado.
- **M5 — Executor mais robusto.** A reconciliação do diário do executor aceita passagens gravadas sem `connection_id` (atribui a conexão lida) e a cobertura trata resposta inesperada de `SHOW CREATE TABLE` como cobertura desconhecida, em vez de supor sequência 1.
- **M6 — Schemas de saída completos.** `google/status` e as três habilidades de entrega de conversões passam a declarar campos que já devolviam (`message`, `ads_eligibility_source`, `verification_pending`, as duas formas de `core_transport` e `cron.work_observation`). Nenhum campo removido ou renomeado.

## Capacidades existentes

- Coleta completa optativa GA4/GSC, limitada por páginas, linhas, bytes e tempo, com cursor opaco e retomada de jobs. A resposta descreve todos os recortes e preserva metadados nativos por página.
- Calendário por semana ISO, mês, trimestre e ano: consultas agregadas na origem, política explícita para períodos parciais e ausência de soma de usuários únicos.
- Exportação exige extração completa por padrão. `allow_partial` é explícito; recibos distinguem extração, escrita e releitura. Append usa confirmação vinculada à intenção e não repete uma operação já confirmada.
- Contexto de medição e catálogo de eventos pelo SDK público do Core; seleção de distribuição e bridges pelos SDKs públicos MCP. Nenhum acesso Google a opções privadas Core/MCP.
- Schemas completos de diagnóstico, armazenamento e cache. Bancada parametrizada e atualização direta das bases definidas, sem rotinas intermediárias no runtime.
- Incorporadas as mudanças preparadas na 0.8.5, que não foi instalada: armazenamento corrente, `google/maintenance`, retirada dos importadores e das rotas de migração/transição históricas.

Continuam configuração assistida, múltiplas conexões, perfis GA4 genéricos, vínculo opcional pelo Measurement ID do Core, preparação/migração de sites GSC, sitemap, inspeção em lote, filas, relatórios, políticas por recurso, confirmações, GTM v2, modelos, alertas e auditoria/exportação. Migração de sites GSC é uma funcionalidade corrente; não é migração interna de versões do plugin.

## Instalar e configurar

Use `wp-mcp-google-fator3-0.18.1-instalador.zip` em WordPress limpo ou substitua a **0.17.0**, sem desinstalar. Essas bases delimitam os ensaios e a manutenção. **Não há bloqueio de instalação, ativação ou atualização por versão/presença/ordem dos plugins acompanhantes.** Operações dependentes de uma capacidade ausente retornam diagnóstico específico. Permissões, identidade e contratos continuam sendo conferidos.

Em **Ferramentas → Fator3 MCP Google**, escolha a conexão, importe a credencial candidata, teste e ative explicitamente. Selecione os serviços e recursos necessários. Ads exige developer token. Consulte o [guia](docs/GUIA-0.18.1.md) e a [atualização/recuperação](docs/MIGRACAO.md).

Requisitos próprios: PHP 8.3.6+, WordPress 7.1.2+ com Abilities API, OpenSSL e MySQL/MariaDB; cURL para resolução pública/atualização. O servidor MCP é separado. As combinações da rodada são **Google 0.17.0 → 0.18.1, MCP 0.28.0 e Core 1.48.0**, com Meta 0.6.0 e LinkedIn 0.7.0 no upgrade; WordPress 7.1.2 (mínimo declarado) e 7.1.3. As versões identificam os insumos da bancada; o relatório externo registra os resultados efetivos e limites.

URL MCP preferida: `/wp-json/mcp/wp-mcp-fator3`. O alias `/wp-json/mcp/wp-mcp-ultimate` e a identidade SDK `wp-mcp-ultimate-server` pertencem ao canal atual. Callback OAuth Google: `/wp-json/wp-mcp-google-fator3/v1/oauth/callback`.

## Documentação e distribuição

- [Coleta e exportação](docs/ANALYTICS.md), [contratos públicos](docs/CONTRATOS-PUBLICOS.md) e [receitas](docs/RECEITAS.md).
- [Contratos](CONTRACTS.md), [catálogo](docs/CATALOGO.md), [SDK PHP](docs/SDK-PHP.md) e [cron](docs/ACOMPANHAMENTO-CRON.md).
- [Schemas](docs/ability-catalog.json), [opções](docs/configuration-definitions.json), [exemplos](docs/examples.json) e [perfil GA4](docs/profile-schema.json).
- [Validação](docs/VALIDACAO.md), [fechamento documental](docs/FECHAMENTO-DOCUMENTAL.md), [bancada](tools/README.md) e [changelog](CHANGELOG.md).

No instalador, documentos e script Cloud Shell são dados PHP protegidos, com download autenticado no painel. Todas as pastas têm índice silencioso. Não são distribuídos Markdown, `docs/`, `reference/`, testes, ferramentas ou `.htaccess` no diretório instalado. O ZIP fonte contém os documentos, o script revisado e o original de referência. Nenhum script Cloud Shell é executado pelo plugin ou pelo build.

## Desenvolvimento

```sh
composer install
composer test
php build/export-contracts.php
python3 build/compile-documents.py
python3 build/check-docs.py
python3 build/build.py candidate --output /candidatos/google-0.18.1.zip
```

Siga [tools/README.md](tools/README.md) para validar o candidato e promover exatamente os mesmos bytes. Evidências ficam fora do runtime. Homologação Google real e publicação na frota são etapas externas à validação local.

## Capacidades preservadas da 0.12.0

Documentação instalada: descubra `google/documentation`, leia o índice e continue com offset/hash. O [guia para agentes](docs/AGENT-GUIDE.md) descreve o contrato completo. O painel usa a mesma fonte compilada. A ajuda é estática, exige administração e funciona sem credencial.

Consultas públicas têm teto de 1 MiB JSON. Jobs paginam também cobertura e evidências de qualidade, com limite de bytes e manifesto de seções. Dados internos e exportações permanecem completos. Canal habilitado e credencial legível são estados locais; o último diagnóstico informa os acessos efetivamente testados. Permissões filtradas são restrições adicionais à administração.
