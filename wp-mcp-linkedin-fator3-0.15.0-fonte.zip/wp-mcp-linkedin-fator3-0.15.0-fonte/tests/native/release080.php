<?php
/**
 * LinkedIn 0.8.0 — Melhorias M1–M6 (ordem do dono de 22/10/2026). Runs inside suite.php (check/expect/ncall available).
 * Each check names the defect or feature it proves; the worker checks fail on the 0.7.0 base.
 */
use Fator3\LinkedIn as L;
require_once __DIR__.'/lab-helpers.php';
if(!class_exists(L\Worker::class)){check('080 worker supervision present',function(){expect(false,'Fator3\\LinkedIn\\Worker ausente');});return;}
global $wpdb;wp_set_current_user(1);
$q080=['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'];

check('080 M1 schema 2 adds runnable projection and index to the LinkedIn table',function(){
 global $wpdb;$t=L\Store::table();$cols=$wpdb->get_col("SHOW COLUMNS FROM $t");$idx=$wpdb->get_results("SHOW INDEX FROM $t WHERE Key_name='runnable'",ARRAY_A);
 expect((int)get_option('f3_linkedin_schema')===2&&in_array('queue_state',$cols,true)&&in_array('queue_next',$cols,true)&&count($idx)===4);
});
check('080 M1 hourly schedule job completes on the first pass behind 2000 completed jobs',function()use($q080){
 global $wpdb;resetHttp();$t=L\Store::table();
 $template=['query'=>$q080,'principal'=>L\Access::principal(),'connection_revision'=>1,'status'=>'complete','pages'=>0,'rows'=>0,'created_at'=>time()-400*86400,'updated_at'=>time()-400*86400,'next_at'=>0,'last_code'=>null,'errors'=>[]];
 for($n=0;$n<2000;$n++)L\Store::put('job','0000000000000000qa080_done_'.str_pad((string)$n,4,'0',STR_PAD_LEFT),$template);
 L\Schedules::save(['schedule_id'=>'qa080_hourly','label'=>'QA 080 horária','query'=>$q080,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()-60]);
 $explain=$wpdb->get_row($wpdb->prepare("EXPLAIN SELECT record_key,queue_next FROM %i WHERE bucket='job' AND queue_state='queued' AND queue_next<=%d ORDER BY queue_next,record_key LIMIT 20",$t,time()),ARRAY_A);
 expect(($explain['key']??'')==='runnable'&&!str_contains($explain['Extra']??'','filesort'),wp_json_encode($explain));
 $dueBefore=count(L\Queue::due());wp_clear_scheduled_hook('f3_linkedin_worker');do_action('f3_linkedin_worker');
 $s=L\Store::get('schedule','qa080_hourly');$job=L\Store::get('job',$s['value']['last_job']??'missing');
 expect($job&&$job['value']['status']==='complete',wp_json_encode($job['value']??null));
 $w=get_option('f3_linkedin_last_worker');expect(($w['processed']??-1)===min(20,$dueBefore+1)&&($w['state']??'')==='ok',wp_json_encode($w).' due_before='.$dueBefore);
 expect($s['value']['next_at']>time()&&wp_next_scheduled('f3_linkedin_worker')!==false);
});
check('080 M1 exception inside a worker pass still rearms the next pass',function(){
 $seen=0;$boom=static function($sql)use(&$seen){if(str_starts_with($sql,'SELECT record_key FROM')&&str_contains($sql,"bucket='schedule' ORDER")&&++$seen===2)throw new RuntimeException('synthetic worker exception');return $sql;};
 wp_clear_scheduled_hook('f3_linkedin_worker');add_filter('query',$boom);try{do_action('f3_linkedin_worker');}finally{remove_filter('query',$boom);}
 expect((get_option('f3_linkedin_last_worker')['state']??'')==='failed'&&wp_next_scheduled('f3_linkedin_worker')!==false,wp_json_encode(get_option('f3_linkedin_last_worker')));
});
check('080 M1 concurrent worker pass cannot process or overwrite the checkpoint',function(){
 global $wpdb;[$h,$p,$sock]=$wpdb->parse_db_host(DB_HOST);$other=new mysqli($h,DB_USER,DB_PASSWORD,DB_NAME,(int)($p?:3306),$sock?:null);
 $name='f3s:'.substr(hash('sha256',DB_NAME.'|'.L\Store::table().'|worker-pass'),0,55);$other->query("SELECT GET_LOCK('".$other->real_escape_string($name)."',0)");
 $prior=get_option('f3_linkedin_last_worker');try{L\Jobs::tick();expect(get_option('f3_linkedin_last_worker')===$prior);}finally{$other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($name)."')");$other->close();}
});
check('080 M1 status is read-only: reports worker_missing and does not repair',function(){
 wp_clear_scheduled_hook('f3_linkedin_worker');$r=L\Api::dispatch('status');expect($r['success'],wp_json_encode($r));$d=$r['data'];
 expect($d['state']==='degraded'&&in_array('worker_missing',array_column($d['issues'],'code'),true)&&$d['repair']==='not_attempted');
 expect(wp_next_scheduled('f3_linkedin_worker')===false,'status must not reschedule');
 expect(isset($d['access_lifecycle'],$d['service_audit'],$d['cron']['traffic_required']),'0.7.0 status fields preserved');
 if(function_exists('wp_get_ability')){$a=wp_get_ability('linkedin/status');expect($a->get_meta()['annotations']['readonly']===true&&$a->get_meta()['fator3']['local_effect']==='none');}
});
check('080 M1 status through REST and ability writes only the local audit row (no repair, schedule or HTTP)',function(){
 global $wpdb;$t=L\Store::table();wp_clear_scheduled_hook('f3_linkedin_worker');$n=count($GLOBALS['requests']??[]);
 [$rest,$w]=lab_writes(static function(){$q=new WP_REST_Request('POST','/f3-linkedin/v1/status');$q->set_header('Content-Type','application/json');$q->set_body('{}');return rest_do_request($q);});
 expect($rest->get_status()===200&&lab_audit_inserts($w,$t)===1&&lab_non_audit_writes($w,$t,'f3_linkedin')===[]&&wp_next_scheduled('f3_linkedin_worker')===false,wp_json_encode(lab_non_audit_writes($w,$t,'f3_linkedin')));
 if(function_exists('wp_get_ability')&&!class_exists('Fator3\\McpFiles\\ConnectionContext')){[$a,$w]=lab_writes(static fn()=>wp_get_ability('linkedin/status')->execute([]));expect(is_array($a)&&$a['success']&&lab_audit_inserts($w,$t)===1&&lab_non_audit_writes($w,$t,'f3_linkedin')===[]&&wp_next_scheduled('f3_linkedin_worker')===false,wp_json_encode(lab_non_audit_writes($w,$t,'f3_linkedin')));}
 expect(count($GLOBALS['requests']??[])===$n,'no provider HTTP');
});
check('080 M1 hourly maintenance restores the missing worker event',function(){
 wp_clear_scheduled_hook('f3_linkedin_worker');do_action('f3_linkedin_maintenance');
 expect(wp_next_scheduled('f3_linkedin_worker')!==false);$m=get_option('f3_linkedin_last_maintenance');expect(($m['recovery']??false)===true&&array_key_exists('credentials_code',$m));
});
check('080 M1 an unreadable legacy job no longer blocks migration of the others',function(){
 global $wpdb;$t=L\Store::table();$wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='',queue_next=0 WHERE bucket='job' AND record_key LIKE %s",$t,'0000000000000000qa080_done_%'));
 $wpdb->insert($t,['bucket'=>'job','record_key'=>'0000000000000000000qa080_bad','revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
 for($pass=0;$pass<30&&L\Queue::pending();$pass++)L\Queue::migrate();
 expect(!L\Queue::pending(),'migration stuck behind unreadable record');
 $state=$wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,'0000000000000000000qa080_bad'));expect($state===L\Queue::UNREADABLE);
 $h=L\Worker::health();expect($h['queue']['unreadable_jobs']===1&&in_array('queue_record_unreadable',array_column($h['issues'],'code'),true));
 expect(!in_array('0000000000000000000qa080_bad',array_column(L\Queue::due(),'record_key'),true));
});
check('080 M1 retention skips an unreadable expired job instead of aborting',function(){
 global $wpdb;$t=L\Store::table();$wpdb->query($wpdb->prepare("UPDATE %i SET expires_at=%d WHERE bucket='job' AND record_key=%s",$t,time()-10,'0000000000000000000qa080_bad'));
 $ok=['query'=>['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'],'principal'=>['user_id'=>1,'channel'=>null],'connection_revision'=>1,'status'=>'complete','pages'=>0,'rows'=>0,'created_at'=>time()-400*86400,'updated_at'=>time()-400*86400,'next_at'=>0,'last_code'=>null,'errors'=>[]];
 L\Store::put('job','0000000000000000000qa080_old',$ok,0,time()-10);
 $removed=L\Store::prune();expect($removed>=1);expect(L\Store::get('job','0000000000000000000qa080_old')===null);
 expect($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND record_key=%s",$t,'0000000000000000000qa080_bad'))==='1','unreadable record kept for diagnosis');
 $wpdb->delete($t,['bucket'=>'job','record_key'=>'0000000000000000000qa080_bad']);$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'0000000000000000qa080_done_%'));
 $s=L\Store::get('schedule','qa080_hourly');$v=$s['value'];$v['enabled']=false;L\Store::put('schedule','qa080_hourly',$v,$s['revision']);
});
check('080 M5 retention reaches a readable expired job behind 150 unreadable expired jobs',function(){
 global $wpdb;$t=L\Store::table();
 $ok=['query'=>['connection_id'=>'qa','channel'=>'pages','account_id'=>'111','report'=>'organization'],'principal'=>['user_id'=>1,'channel'=>null],'connection_revision'=>1,'status'=>'complete','pages'=>0,'rows'=>0,'created_at'=>time()-400*86400,'updated_at'=>time()-400*86400,'next_at'=>0,'last_code'=>null,'errors'=>[]];
 for($n=0;$n<150;$n++)$wpdb->insert($t,['bucket'=>'job','record_key'=>'000000000000000000qa080_bad_'.str_pad((string)$n,3,'0',STR_PAD_LEFT),'revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>time()-10,'queue_state'=>'unreadable','queue_next'=>0]);
 L\Store::put('job','000000000000000000qa080_zold',$ok,0,time()-10);L\Store::prune();expect(L\Store::get('job','000000000000000000qa080_zold')===null,'one pass with marked unreadable');
 $wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='invalid' WHERE bucket='job' AND record_key LIKE %s",$t,'000000000000000000qa080_bad_%'));
 L\Store::put('job','000000000000000000qa080_zold',$ok,0,time()-10);L\Store::prune();L\Store::prune();expect(L\Store::get('job','000000000000000000qa080_zold')===null,'two passes with unmarked unreadable');
 expect((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND queue_state='unreadable' AND record_key LIKE %s",$t,'000000000000000000qa080_bad_%'))===150);
 $wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'000000000000000000qa080_bad_%'));
});
check('080 M5 a fresh request runs no SQL of the package during bootstrap (options autoloaded, queue settled)',function(){
 $q=lab_bootstrap_sql(L\Store::table(),'f3_linkedin_');expect($q===[],wp_json_encode($q));
 $all=wp_load_alloptions(true);expect(isset($all['f3_linkedin_schema'],$all['f3_linkedin_queue_settled'])&&L\Queue::settled());
});
check('080 M3 hourly maintenance event self-heals on the next request',function(){
 wp_clear_scheduled_hook('f3_linkedin_maintenance');expect(wp_next_scheduled('f3_linkedin_maintenance')===false);
 $c=lab_child('echo json_encode(["next"=>wp_next_scheduled("f3_linkedin_maintenance")]);');expect($c['rc']===0&&!empty($c['json']['next']),wp_json_encode($c));
 wp_cache_delete('cron','options');wp_cache_delete('alloptions','options');expect(wp_next_scheduled('f3_linkedin_maintenance')!==false);
});
check('080 M2 consumers register on init (before WP-Cron), never during plugins_loaded',function(){
 $c=lab_child('echo json_encode(["pl"=>$GLOBALS["qa080_pl"]??null,"init"=>$GLOBALS["qa080_init"]??null,"cron_priority"=>has_action("init","wp_cron")]);',[['plugins_loaded',PHP_INT_MAX,'$GLOBALS["qa080_pl"]=did_action("f3_linkedin_register_consumers");'],['init',5,'$GLOBALS["qa080_init"]=did_action("f3_linkedin_register_consumers");']]);
 expect($c['rc']===0&&$c['json']['pl']===0&&$c['json']['init']===1&&$c['json']['cron_priority']>5,wp_json_encode($c));
});
if(class_exists('F3Base_Linkedin_Cliente'))check('080 M2 integrated: a fresh request with Site Core loads no f3base translation too early',function(){
 $before=count(array_filter(lab_debug_lines(),static fn($l)=>str_contains($l,'<code>f3base</code> domain was triggered too early')));
 $c=lab_child('do_action("template_redirect");echo json_encode(["ok"=>1]);');expect($c['rc']===0,wp_json_encode($c));
 $after=count(array_filter(lab_debug_lines(),static fn($l)=>str_contains($l,'<code>f3base</code> domain was triggered too early')));
 expect($after===$before,'f3base notices: '.($after-$before));
 expect(L\PublicApi::registered(F3Base_Linkedin_Integracoes::consumer())||!F3Base_Linkedin_Integracoes::colecao(),'Core consumer still registered');
});
// M4 — CAPI diagnosis. Restore the fixture used by release060/070 for the grant scenarios.
add_filter('pre_http_request',$capiFixture,0,3);
check('080 M4 diagnose-conversions lists each unmet requirement with its action, locally',function(){
 global $wpdb;$n=count($GLOBALS['capiCalls']);$writes=[];$spy=static function($sql)use(&$writes){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE)/i',$sql))$writes[]=$sql;return $sql;};add_filter('query',$spy);
 try{$d=L\Conversions::diagnose([]);}finally{remove_filter('query',$spy);}
 expect($writes===[]&&count($GLOBALS['capiCalls'])===$n,'diagnosis must not write or call the provider');
 $by=array_column($d['checks'],null,'id');expect(!$d['ready']&&$by['account_selected']['ok']===false&&is_string($by['account_selected']['action'])&&$d['remote_checked']===false,wp_json_encode($d));
 expect($d['ready']===L\Conversions::capabilities()['ready']);
});
check('080 M4 diagnose-conversions through REST and ability writes only the local audit row and calls no provider',function(){
 global $wpdb;$t=L\Store::table();$n=count($GLOBALS['capiCalls']);
 [$rest,$w]=lab_writes(static function(){$q=new WP_REST_Request('POST','/f3-linkedin/v1/diagnose-conversions');$q->set_header('Content-Type','application/json');$q->set_body('{"conversion_id":"67890"}');return rest_do_request($q);});
 expect($rest->get_status()===200&&($rest->get_data()['success']??false)&&lab_audit_inserts($w,$t)===1&&lab_non_audit_writes($w,$t,'f3_linkedin')===[],wp_json_encode(lab_non_audit_writes($w,$t,'f3_linkedin')));
 if(function_exists('wp_get_ability')&&!class_exists('Fator3\\McpFiles\\ConnectionContext')){[$a,$w]=lab_writes(static fn()=>wp_get_ability('linkedin/diagnose-conversions')->execute([]));expect(is_array($a)&&$a['success']&&lab_audit_inserts($w,$t)===1&&lab_non_audit_writes($w,$t,'f3_linkedin')===[]);}
 expect(count($GLOBALS['capiCalls'])===$n,'no provider HTTP');$au=ncall('audit');expect(in_array('diagnose-conversions',array_column($au['events'],'operation'),true));
});
check('080 M4 diagnose-conversions is ready exactly when capabilities is ready',function(){
 $c=L\Connections::get('conversions');ncall('save-connection',['connection_id'=>'conversions','expected_revision'=>$c['revision'],'assets'=>['ads'=>['222']]]);
 $g=L\Conversions::grant();ncall('save-conversion-grant',['consumer_id'=>L\Conversions::CONSUMER,'expected_revision'=>$g['revision'],'enabled'=>true,'connection_id'=>'conversions','account_id'=>'222','conversion_id'=>'67890','expected_connection_revision'=>L\Connections::get('conversions')['revision']]);
 $d=ncall('diagnose-conversions');expect($d['ready']&&$d['blocking_count']===0&&L\Conversions::capabilities()['ready'],wp_json_encode($d));
 expect($d['grant']['conversion_id']==='67890'&&$d['scope_proof']['checked']===true&&$d['core_rule_match']===null);
});
check('080 M4 Site Core server rule different from the grant is a blocking mismatch',function(){
 $d=ncall('diagnose-conversions',['conversion_id'=>'99999']);$by=array_column($d['checks'],null,'id');
 expect(!$d['ready']&&$d['core_rule_match']===false&&$by['core_rule_matches_grant']['code']==='regra_divergente'&&str_contains($by['core_rule_matches_grant']['action'],'67890'));
 $d=ncall('diagnose-conversions',['conversion_id'=>'67890']);expect($d['ready']&&$d['core_rule_match']===true);
});
check('080 M4 Insight Tag rule recorded in the grant is reported as not API source',function(){
 $r=L\Store::get('conversion_grant',L\Conversions::CONSUMER);$v=$r['value'];$old=$v;$v['rule']['conversion_method']='INSIGHT_TAG';L\Store::put('conversion_grant',L\Conversions::CONSUMER,$v,$r['revision']);
 try{$d=ncall('diagnose-conversions');$by=array_column($d['checks'],null,'id');expect(!$d['ready']&&$by['rule_api_source']['code']==='regra_sem_fonte_api');}
 finally{$now=L\Store::get('conversion_grant',L\Conversions::CONSUMER);L\Store::put('conversion_grant',L\Conversions::CONSUMER,$old,$now['revision']);}
});
check('080 M4 diagnose-conversions is read-only, administrator-only and has no remote effect',function(){
 if(function_exists('wp_get_ability')){$a=wp_get_ability('linkedin/diagnose-conversions');expect($a!==null);$m=$a->get_meta();
 expect($m['annotations']['readonly']===true&&$m['fator3']['mode']==='read'&&$m['fator3']['remote_effect']==='none'&&$m['fator3']['local_effect']==='none',wp_json_encode($m));
 expect(str_starts_with($a->get_label(),'LinkedIn: ')&&!str_contains($a->get_label(),'diagnose-conversions'));}
 wp_set_current_user($GLOBALS['editor']);try{$r=L\Api::dispatch('diagnose-conversions');expect(!$r['success']&&$r['code']==='not_authorized');$req=new WP_REST_Request('POST','/f3-linkedin/v1/diagnose-conversions');$req->set_header('Content-Type','application/json');$req->set_body('{}');expect(rest_do_request($req)->get_status()===403);}finally{wp_set_current_user(1);}
});
remove_filter('pre_http_request',$capiFixture,0);
check('080 M5 audit lists newest first and filters by since',function(){
 global $wpdb;$t=L\Store::table();$base=time()+1000;
 foreach([10,30,20] as $k=>$age){$key='0000qa080audit'.$k;L\Store::put('audit',$key,['operation'=>'qa080-'.$age,'actor'=>['type'=>'user','id'=>1],'transport'=>'local_sdk','connection_id'=>null,'code'=>'ok','at'=>$base-$age],0,time()+86400);$wpdb->update($t,['updated_at'=>$base-$age],['bucket'=>'audit','record_key'=>$key]);}
 $all=ncall('audit',['since'=>$base-60]);$ops=array_column($all['events'],'operation');
 expect($all['order']==='newest_first'&&$ops===['qa080-10','qa080-20','qa080-30'],wp_json_encode($ops));
 $r=ncall('audit',['since'=>$base-25]);expect(array_column($r['events'],'operation')===['qa080-10','qa080-20']);
 $first=ncall('audit');$at=array_column($first['events'],'at');for($k=1;$k<count($at);$k++)expect($at[$k-1]>=$at[$k]-1,'default page is newest first');
});
check('080 M6 81 abilities, labels in Portuguese, closed schemas',function(){
 $ops=array_keys(L\Schemas::all());expect(count($ops)===(version_compare(lab_version(),'0.15.0','>=')?97:(version_compare(lab_version(),'0.12.0','>=')?93:(version_compare(lab_version(),'0.11.0','>=')?90:81)))&&in_array('diagnose-conversions',$ops,true));
 $labels=[];foreach($ops as $op){$l=L\Labels::get($op);$labels[]=$l[0];expect(str_starts_with($l[0],'LinkedIn: ')&&$l[1]!=='');}
 expect(count(array_unique($labels))===(version_compare(lab_version(),'0.15.0','>=')?97:(version_compare(lab_version(),'0.12.0','>=')?93:(version_compare(lab_version(),'0.11.0','>=')?90:81))));expect(L\Schemas::all()['audit']['properties']['since']===['type'=>'integer','minimum'=>0]);
});
check('080 list-connections paginates from a single read',function(){
 $r=ncall('list-connections');expect(is_array($r['connections'])&&count($r['connections'])<=50&&$r['next_offset']===null);
 foreach($r['connections'] as $c)expect(!isset($c['token'])&&!isset($c['client_secret'])&&!isset($c['refresh_token']));
});
