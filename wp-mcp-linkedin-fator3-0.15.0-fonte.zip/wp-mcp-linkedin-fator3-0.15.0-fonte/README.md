# Fator3 MCP LinkedIn 0.15.0 — fonte da entrega

Implementação dos pedidos 18–21 sobre a base aceita 0.14.0. Rejeições de criação com saída explícita, correção do finder de assinaturas, normalização de respostas textuais e descoberta automática de formulários mediante autorização. O contrato aditivo linkedin-lead-reader/1.2.0 precisa ser adotado pelo Core para completar a integração comercial automática. Leia o relatório e o impacto Core.

## Organização

- `plugin/wp-mcp-linkedin-fator3/`: runtime byte a byte igual ao instalador.
- `build/`: fontes autorais, documentação instalada e build determinístico exclusivo do LinkedIn.
- `tests/native/`: testes WordPress/MySQL; `requests018021.php`, `upgrade0150.php` e `ui0150.*` cobrem esta rodada. Fornecedor sintético, sem contatos/anúncios reais.
- `tools/lab.py`, `tools/lab-release0150.example.json`: laboratório descartável com dependências externas verificadas por SHA-256.
- `evidence/release0150/`: contraste da base, atualização, regressão, mínimo, DOM, documentação MCP e Site-Teste.
- `inputs/0.15.0/`: pedidos e relatórios recebidos; telefone removido da cópia dos pedidos, originais identificados por hash. As normas da base permanecem preservadas.
- `planning/PLANO-0.15.0.md` e `impacts/wp-mcp-linkedin-fator3-0.15.0-impacto-base-site-core-fator3.md`: plano, decisões e encaminhamento pertinente.
- `history/`: relatórios anteriores, sem alteração retroativa das versões entregues.

## Reprodução

Mínimos próprios: WordPress 6.4, PHP 8.1.2 de 64 bits, banco InnoDB com bloqueios nomeados e criptografia autenticada. Bancada atual: WordPress 7.1.4, PHP 8.3.6 e MySQL 8.0.46. Integrados originais: Core 1.67.0, MCP 0.38.0, Google 0.26.0 e Meta 0.19.0. Pipedrive 0.5.0 foi extraído, mas não ativado na bancada por exigir PHP 8.3.36; está ativo no Site-Teste.

Execute `python3 build/build.py` com PHP disponível no PATH ou em `F3_SOCIAL_PHP`. Saída `build/dist/wp-mcp-linkedin-fator3-0.15.0-instalador.zip`, 345084 bytes, SHA-256 `e12b2b468b71c53d7ecc67c55f758ee1af5ba2b24082f9b12046c66944169e85`. `build/dist` não integra o ZIP fonte.

Copie o manifesto de exemplo, ajuste caminhos e credenciais de um MySQL descartável. O runner cria seu próprio schema e exige diretório de trabalho vazio. WordPress, PHP, MySQL e plugins acompanhantes são externos; nenhum está aninhado no fonte. Os hashes de árvores PHP correspondem ao conjunto de módulos indicado; obtenha os pacotes pelos scripts/locks de runtime e prepare a árvore descrita no manifesto. Não aponte a bancada para um site existente.

```bash
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li015-upgrade --order linkedin-integrated --origin upgrade --tests upgrade0150.php,request01617.php,mcp-request01617.php,suite.php,request012.php,request013.php,request014.php,mcp-history011.php,request015.php,stages012.php,mcp-stages012.php,mcp-request015.php,requests018021.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li015-clean --order linkedin-integrated --tests requests018021.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li015-min --order linkedin-only --wordpress wordpress_minimum --php php81 --tests requests018021.php,suite.php
```

DOM: instale as dependências de `tests/dom/package-lock.json` em pasta externa, configure `F3_JSDOM` para o módulo jsdom 27.4.0 e `CODEX_PRIMARY_RUNTIME_NODE` para Node 24.22.1. Execute `ui0150.php` sozinho em laboratório limpo com `--order linkedin-integrated`. O teste usa HTML/JS reais e REST autenticado; não constitui inspeção visual em navegador. Espera a renderização assíncrona antes de verificar o incidente de credenciais. A prova do Registro percorre suas páginas; não pressupõe evento recente na primeira página quando vários registros compartilham o mesmo segundo.

`python3 tools/package-source.py --output-dir /diretorio/externo` confere igualdade de `plugin/` com o instalador e fecha a raiz versionada, sem ZIP aninhado. O relatório interno antecede o fechamento; o relatório externo canônico contém o tamanho/hash final do fonte. Não alterar o instalador entregue sem nova versão.
