<?php
/**
 * Plugin Name: Fator3 MCP Pipedrive
 * Plugin URI: https://github.com/Fator3Ventures/claude-wordpress
 * Description: Operação da conta Pipedrive pelo agente, com o token guardado no Fator3 Site Core. Configuração: Ferramentas → Fator3 MCP Pipedrive.
 * Version: 0.11.1
 * Requires at least: 7.1.4
 * Requires PHP: 8.3
 * Author: Fator3
 * Author URI: https://www.fator3.com.br
 * License: GPL-2.0-or-later
 * Text Domain: wp-mcp-pipedrive-fator3
 * Update URI: https://fator3.com.br/plugins/wp-mcp-pipedrive-fator3
 */
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
const VERSION = '0.11.1';
const SLUG = 'wp-mcp-pipedrive-fator3';
const CONTRACT = 'pipedrive-api-client/1.0.0';
const ROOT = __DIR__;
// Keep public requests small. Only known package classes may resolve to local files.
spl_autoload_register(static function (string $class): void {
    static $files = ['Fault'=>'Support','Support'=>'Support','Policy'=>'Policy','CoreClient'=>'CoreClient',
        'Retention'=>'Retention','Store'=>'Store','Operations'=>'Operations','Documentation'=>'Documentation',
        'Report'=>'Report','Configuration'=>'Configuration','Collection'=>'Collection','Rules'=>'Rules','WhatsAppNote'=>'WhatsAppNote',
        'Progress'=>'Progress','Cadence'=>'Cadence','Insights'=>'Insights','Workflows'=>'Workflows','Extension'=>'Extension',
        'Api'=>'Api','Admin'=>'Admin','AdminList'=>'AdminList','AdminRules'=>'AdminRules','AdminDocument'=>'AdminDocument','AdminForms'=>'AdminForms',
        'Recovery'=>'Recovery','AdminRecovery'=>'AdminRecovery'];
    $prefix=__NAMESPACE__.'\\';
    if(str_starts_with($class,$prefix)&&isset($files[$name=substr($class,strlen($prefix))]))require_once ROOT.'/includes/'.$files[$name].'.php';
});
register_activation_hook(__FILE__, static function ($network = false) {
    if ($network || is_multisite()) { wp_die('Fator3 MCP Pipedrive exige WordPress de site único.'); }
    if (PHP_INT_SIZE < 8 || !function_exists('openssl_encrypt')) { wp_die('PHP de 64 bits com OpenSSL é obrigatório.'); }
    Store::install();
});
add_action('f3base_register_pipedrive_consumers', [CoreClient::class, 'register'], 10, 2);
add_action('f3_mcp_register_providers', static function ($version = 1) {
    if ($version === 1 && class_exists('\\Fator3\\McpFiles\\ExtensionContract')) {
        \Fator3\McpFiles\ExtensionContract::register(SLUG, VERSION, ['pipedrive/']);
    }
});
add_action('wp_abilities_api_categories_init', static function () {
    if (function_exists('wp_register_ability_category')) {
        wp_register_ability_category('pipedrive', ['label'=>'Fator3 MCP Pipedrive','description'=>'Operações administrativas com prévia e confirmação.']);
    }
});
add_action('wp_abilities_api_init', [Api::class, 'abilities'], 20);
add_action('rest_api_init', [Api::class, 'routes']);
add_action('admin_menu', [Admin::class, 'menu']);
