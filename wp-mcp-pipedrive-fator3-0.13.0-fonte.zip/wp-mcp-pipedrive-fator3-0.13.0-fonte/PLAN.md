# Plano da versão 0.13.0 — 20/11/2026

Base imutável: 0.12.0. Normas lidas: instruções de agentes e padrão completo, revisão 5 de 02/11/2026. Pedido: ajustes de tela de 20/11/2026 (18 itens, sem novo número), Guia Visual e Folha comum. Referências integrais em reference/0130.

1. Carregar f3-ui.css 1.0.0 sem alteração antes do CSS de domínio. Substituir os componentes locais pelos componentes comuns. Preservar os seis destinos, nomes, ações, permissões, opções e 23 schemas públicos.
2. Corrigir cabeçalho e divisor de avisos; adotar grupos/subabas, cartões, estados, métricas, filtros, tabelas e barra de revisão comuns. Melhorar associação de rótulos, ajuda, estados de retorno e navegação com teclado e sem JavaScript.
3. Testar instalação limpa e atualização de 0.12.0, regressões funcionais, documentação paginada e convivência com Core 1.100.1, MCP 0.54.0, Google 0.42.0, Meta 0.31.0 e LinkedIn 0.26.0. Capturar as seis subabas a 360/768/1440 px com aviso emitido por outro plugin local; conferir os 12 critérios do guia.
4. Atualizar documentação instalada, evidências e relatório de oito seções; gerar instalador e fonte, verificar hashes e paridade. A distribuição da frota permanece separada da geração do pacote.

Limite conhecido: a folha comum fixa certos campos em 36 px, enquanto o guia exige 40 px no celular. Preservar seus bytes, medir o resultado e registrar o aceite parcial com encaminhamento ao mantenedor da folha. Não declarar conformidade integral antes de verificar. A bancada usa dados sintéticos e bloqueia tráfego de fornecedores/e-mail. Não alterar produção nem registros comerciais.

Na conferência final, o Site-Teste avançou o LinkedIn para 0.27.0 por ação externa a esta rodada. O instalador atual foi recuperado e a matriz de convivência repetida com essa versão. A versão 0.26.0 caracteriza apenas o inventário inicial.
