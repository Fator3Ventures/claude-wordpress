# Checklist de encerramento — 0.13.0

Conferido em 20/11/2026. Status final: com-pendencias.

| Situação | Item |
|---|---|
| Concluído | Normas centrais revisão 5 lidas integralmente e identificadas; referências preservadas. |
| Concluído | Base 0.12.0, alvo 0.13.0, conjuntos inicial/final e hashes explícitos. |
| Concluído | Requisitos WP 7.1.4 e PHP 8.3; teste real em WP 7.1.4/PHP 8.3.6. |
| Concluído | Nenhuma obrigação de suportar combinações históricas; correções posteriores por nova versão. |
| Concluído | Instalador runtime-only e fonte singular, sem ZIP interno; relatório canônico externo. |
| Pendente compartilhado | Folha 1.0.0 mantém 36 px em certos campos móveis; proposta comum testada em cópia e restaurada. |
| Concluído | Impacto preliminar registrado no PLAN; impacto individual com diagnóstico, patch, hash, teste e responsável. |
| Concluído | Contratos próprios preservados; 23 schemas com igualdade estrutural à base; sem patch de acompanhantes. |
| Concluído | Instalação limpa, migração, reinício, políticas, documentos e matriz original conferidos. |
| Concluído | 12 documentos finais lidos integralmente pelo executor MCP nativo; 88 páginas e hashes conferidos. |
| Concluído | Permissões, confirmações, estado e dados comparados; sem credencial nova. |
| Concluído | Aviso externo ativo nas capturas; seis subabas, três larguras, foco e troca de esquema. |
| Limite declarado | Com JS desligado, o aviso externo sintético extrapola o documento; conteúdo Pipedrive e navegação cabem. |
| Pendente frota | URL raw e instalação da 0.13.0 no Site-Teste; nenhuma mutação no compartilhado nesta rodada. |
| Concluído | Nenhum segredo real, fixture ativa ou ferramenta de QA no instalador; banco e capturas sintéticos. |
| Pendente dono/frota | Aceite em conta real e entrega postal não são provados por transporte interceptado. |
| Concluído | Logs finais vazios, limpeza de fixture de navegador e restauração da folha experimental conferidas. |
