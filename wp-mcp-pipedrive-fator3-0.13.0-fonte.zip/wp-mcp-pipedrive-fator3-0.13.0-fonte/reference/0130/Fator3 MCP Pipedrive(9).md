# Fator3 MCP Pipedrive — ajustes de tela

O Fator3 MCP Pipedrive 0.12.0 tem a estrutura do guia com prefixo próprio (`f3pd-`) e uma paleta própria, azul-petróleo: largura de 1120 px, título de 28 px e peso 650, cor de destaque em três tons fixos, selos sem borda e cartão com sombra. Num telefone de 360 px a página abre com 641 px. Slug, capacidade, rotas e options não mudam.

## Navegação

Os grupos já têm os nomes e a ordem do guia (Operação · Configurar · Suporte), e a tela já abre em Operação › Visão geral. Muda só o desenho (ajustes 4 e 5).

## Ajustes

| # | onde | hoje | muda para |
| --- | --- | --- | --- |
| 1 | carga da folha (`includes/Admin.php` linha 37) | só `assets/admin.css` | `assets/f3-ui.css` antes da folha própria |
| 2 | raiz `div.wrap.f3pd` | `max-width:1120px`; `--f3pd-accent:#185c65` e `--f3pd-muted` | acrescentar `f3-ui`; sem largura própria; as variáveis `--f3pd-*` saem |
| 3 | cabeçalho `header.f3pd-head` (linha 50) | h1 de 28 px (22 px abaixo de 782 px), peso 650, cor `#152d42`, dentro de `div`; descrição de 14 px `#465663`; selo `span.f3pd-version` (`#edf4f8`, borda `#c7d8e1`, raio 20 px, 12 px/600); sem `hr.wp-header-end` | `header.f3-heading` sem `div`, h1 nativo, descrição de 13 px, `span.f3-version` e `hr.wp-header-end` depois |
| 4 | grupos `nav.f3pd-groups` (linha 50) | pílula de 37 px, raio 24 px, borda `#b7c8d3`, texto `#264b63`, ativa `#1c4765` | `div.f3-groups` dentro de `nav.f3-nav` |
| 5 | subabas `nav.f3pd-subtabs` (linha 52) | traço de 3 px `#1d6689`, texto `#495c69`, ativa `#134c69`, 20 px entre itens, 35 px de altura | `div.f3-subtabs` |
| 6 | cartão `.f3pd-panel` | borda `#ced8de`, sombra, 20×24 px; h2 de 19 px na cor `#18374c` | `f3-section`; h2 de 1,3 em na cor do texto |
| 7 | selos `.f3pd-chip` com `f3pd-ok`, `f3pd-atencao`, `f3pd-info` e `f3pd-erro` (sem borda, raio 30 px, peso 650), e `.f3pd-pill` (raio 4 px, `#e9f2f1`) | dois desenhos | `f3-pill` com `is-ok`, `is-warn`, `is-info` ou `is-error` |
| 8 | regras `.f3pd-tabs .nav-tab` da folha | abas nativas do WordPress com traço `#185c65` | saem da folha |
| 9 | fichas `.f3pd-facts` | rótulo de 12 px e valor de 15 px com peso 600, entre duas linhas | `f3-stats` com `f3-stat` |
| 10 | avisos `.f3pd-group-nav` (fundo `#eaf3f3`, barra `#185c65`), `.f3pd-contents` (barra, fundo `#f6f7f7`) e `.f3pd-attention` (barra `#8a650b`) | três desenhos | `f3-callout` com o estado; o índice de âncoras vira lista simples de links |
| 11 | escolhas `.f3pd-help-nav` e `.f3pd-mode` | item ativo com fundo `#e9f2f1` | `f3-switch` |
| 12 | barra `.f3pd-toolbar` | presa ao pé, com sombra | `f3-savebar` |
| 13 | linhas de edição `.f3pd-row` | borda `#c3c4c7`, raio 5 px | `f3-card` |
| 14 | listas: `.f3pd-filter`, `.f3pd-local-controls` e `.f3pd-pager` | busca, total e paginação já existem | `f3-list-tools` e `f3-list-total` |
| 15 | tabela em `.f3pd-table` | largura mínima de 540 px, ou 430 px abaixo de 640 px | `f3-table-scroll` |
| 16 | pesos e cores de texto | peso 650 em título, rótulo e selo; textos `#152d42`, `#18374c`, `#465663` | peso 600; `--f3-text` e `--f3-muted` |
| 17 | fonte de código | `ui-monospace,monospace` | Consolas, Monaco, monospace |
| 18 | itens de navegação abaixo de 782 px | 35 px | 44 px, pela folha comum |

## Já está conforme

- Nomes, ordem e endereço dos grupos; tela de entrada em Operação › Visão geral.
- Descrição no cabeçalho e selo "Versão X.Y.Z".
- Rótulo acima do campo; listas com busca, total e paginação.

## Aceite

A conferência da seção 7 do guia preenchida por subaba, com as capturas a 360, 768 e 1440 px; a 360 px, `scrollWidth` igual a 360 com um aviso de outro plugin ativo; nenhuma classe `f3pd-` com função de componente comum.
