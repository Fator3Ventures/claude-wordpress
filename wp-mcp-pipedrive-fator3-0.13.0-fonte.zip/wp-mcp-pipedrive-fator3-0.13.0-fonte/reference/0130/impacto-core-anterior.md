# Impacto de Fator3 MCP Pipedrive 0.12.0 em Fator3 Site Core

Data: 2026-11-18T16:29:00-03:00 · Revisão: 2 · Etapa: entrega · Situação: alinhado.
Base: Pipedrive 0.11.1; alvo entregue: 0.12.0.
Classificação: validacao-coordenada. Natureza: consumo do contrato público de incidentes.
Referência: Pedido Core 430; impacto recebido base-site-core-fator3-1.93.0-impacto-wp-mcp-pipedrive-fator3.md, revisão 2.

Instalador emissor: wp-mcp-pipedrive-fator3-0.12.0-instalador.zip, 489789 bytes, SHA-256 813923a62af52c58a3f39bfa658f51fab75a87ba0b3327ac76133d3aad6b5792.
Destinatário examinado: Core 1.93.0 oficial, SHA-256 eec2ee1fda142863966de9568b61ee5f6914ebb1af371207d8074e7c77f9c1a8. MCP acompanhante: 0.48.0.

## Mudança e consequência

A 0.12.0 acrescenta pipedrive/incidentes-ler e resumo em Suporte → Pendências. Consulta f3base/incidentes-tecnicos-ler, aplica sua permissão e projeta somente incidentes do pacote pipedrive. O quadro permanece acessível ao administrador quando a operação comercial no CRM está indisponível.

O adaptador de autorização do Core já identifica o cliente Pipedrive; adicionar outro produtor criaria duas origens para o mesmo episódio. Conservou-se a publicação e recuperação no Core, com recurso conta e código autorizacao_recusada. Uma falha isolada de operação não prova revogação da conta. O leitor não publica, envia, reconcilia, modifica options privadas nem importa classes internas do destinatário.

## Contrato e implementação

No Core: includes/class-f3base-incidentes.php, métodos listar e reconciliar; includes/class-f3base-incidentes-provedores.php, adaptador pipedrive. No emissor: includes/Incidents.php, Api.php e AdminRecovery.php.

A central pagina até 50 registros globais. O leitor preserva proximo como proximo_apos, inclusive quando a página filtrada está vazia; somente cursor nulo conclui a consulta. O resumo limita-se a 20 páginas e identifica contagens parciais. Retorno inválido, cursor sem avanço, recusa de permissão e erro posterior não viram um diagnóstico de recuperação.

A projeção inclui identificadores opacos, código, estado, datas, ação humana, contagem, próxima entrega e reserva incerta. Não inclui destinatário, token, corpo do aviso ou identidade comercial. A reserva permite reconciliação explícita em f3base/incidente-entrega-reconciliar depois de conferir o transporte.

O consumo preserva a política MCP. No wp-admin, NativeAdminCall da 0.48.0 permite leitura administrativa nativa. No teste CLI, uma concessão sintética existe somente no banco descartável e é removida; não integra o runtime.

## Evidência e aceite técnico

Usou-se o Core oficial, sem patch. Em WordPress 7.1.4 com PHP 8.3.6 e 8.4.27, incidentes-core0120 passou 14 asserções por execução: abertura, fila sem destino, deduplicação, leitura sem efeitos, desativação sem recuperação falsa, diagnóstico inconclusivo, recuperação comprovada, transporte interceptado, incerteza, ausência de reenvio e reconciliação por reserva. Três contatos sintéticos com transporte: duas aceitações e uma exceção controlada; nenhum e-mail real.

incidentes0120 passou 18 asserções por runtime. integrated passou 62, incluindo descoberta, política e leitura integral dos 12 documentos. O quadro com Core/MCP originais passou 18 verificações de navegador em 360/768/1440 px e sem JavaScript. Evidências: evidence/0120/matrix, evidence/0120/php83/matrix e browser0120-matrix.json.

## Prontidão e ações restantes

O emissor está pronto para consumir o contrato vigente. Nenhum patch no Core é necessário. Instalar o Core vigente antes de consultar a central; sua ausência afeta somente esse diagnóstico, mantendo documentação e configuração local disponíveis.

Frota: publicar instalador/relatório, conferir bytes da URL raw oficial e instalar no Site-Teste. O compartilhado permaneceu na 0.11.1; nenhuma mutação foi executada nele.
Dono/frota: homologar conta, destinatário técnico e recebimento postal. Transporte interceptado não comprova entregabilidade.
Mantenedores: revalidar a fronteira quando o schema público ou a política nativa mudar.

## Evolução e encerramento

Revisão 1: proposta e plano de validação coordenada.
Revisão 2: implementação fechada, aceite técnico com Core original e identidade do emissor; publicação, implantação compartilhada e aceite operacional permanecem pendentes. Impacto recebido preservado em inputs/. Encaminhamento entregue ao dono, sem envio a terceiros.
