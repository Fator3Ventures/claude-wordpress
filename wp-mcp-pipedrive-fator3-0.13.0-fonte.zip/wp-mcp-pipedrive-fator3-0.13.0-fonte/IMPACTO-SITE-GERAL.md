# Impacto de Fator3 MCP Pipedrive 0.13.0 em Site Geral | Todos

Data: 2026-11-20 · Revisão: 1 · Etapa: entrega · Situação: aberto
Versão-base: Pipedrive 0.12.0 oficial; versão-alvo: 0.13.0.
Instalador emissor: wp-mcp-pipedrive-fator3-0.13.0-instalador.zip; SHA-256 a460c89705de5ed7b5e2b839f115bc9df6a0316edb3036d451e3e189465467db.
Destinatário: Guia Visual de 20/11/2026 e f3-ui 1.0.0, SHA-256 15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b.
Natureza: divergência entre critério visual e folha compartilhada. Classificação: validacao-coordenada.
Pedido: ajustes de tela de 20/11/2026, sem novo número atribuído.

## Mudança e consequência

O Pipedrive usa a folha comum sem modificar seus bytes. O guia exige campos de pelo menos 40 px no celular. A seção 5 fixa min-height:36px para campos e a seção 6 faz o mesmo com buscas; a seção 7 define --f3-touch:40px apenas para o token e os botões. A regra mais específica mantém os inputs em 36 px. Cinco subabas ficam pendentes no critério 10. A navegação tem 44 px e as três larguras solicitadas não apresentam rolagem horizontal da página com JavaScript ativo.

## Ação ou decisão do responsável

Site Geral | Todos: incorporar a regra do patch na próxima revisão oficial da folha, definir sua versão/hash e distribuir os mesmos bytes aos pacotes. Aceite: campos e buscas >=40 px em 360 e 768 px, sem alterar a largura global ou o desktop. O relatório Core 1.100.1 também registra essa divergência. Não foi criada uma variante oficial no pacote Pipedrive.

## Diagnóstico e alteração proposta no destinatário

Patch aplicável com `patch -p1 < f3-ui-1.0.0-mobile.patch` sobre a folha de hash acima. Em @media(max-width:782px), imediatamente após --f3-touch:40px, acrescenta:

```css
.f3-ui .f3-field>:is(input:not([type=checkbox]):not([type=radio]),select,textarea),.f3-ui .f3-list-tools input[type=search]{min-height:var(--f3-touch)}
```

O patch integral está em reference/0130/f3-ui-1.0.0-mobile.patch no fonte. Não muda dados, permissões, APIs, seletores públicos nem regras de negócio. SHA-256 da cópia experimental: 54e5e5f9ec672b5a4a8811f5643403e3a76fae201d6e53f29a083ce5eaf7fd3d.

## Prontidão do emissor

A marcação do emissor já usa os seletores que a correção alcança. A troca futura da folha oficial dispensa ajuste de PHP/JavaScript para este contrato. Como altera o artefato, a incorporação deverá gerar uma nova versão do pacote após a aprovação compartilhada. A 0.13.0 entregue conserva a folha 1.0.0 e os campos em 36 px.

## Compatibilidade e sequência

Conjunto final: Core 1.100.1, MCP 0.54.0, Google 0.42.0, Meta 0.31.0 e LinkedIn 0.27.0. A revisão é de apresentação. A publicação de uma nova folha exige identidade comum e validação coordenada dos consumidores; não exige migração de banco ou mudança de credenciais.

## Validação e evidência

WordPress 7.1.4, PHP 8.3.6, Chromium 142.0.7444.175. Folha oficial: 67/72 critérios aprovados nas seis subabas; cinco pendências no critério 10. Cópia experimental: 10/10 medições aprovadas, cinco subabas em duas larguras, incluindo ausência de transbordamento da página. O teste shared0130.py restaura o arquivo em finally e confere seu hash. Evidências: browser0130.json e common-proposal.json. Essa prova local não constitui aceite ou release oficial do mantenedor.

## Resposta esperada

Informar a revisão/hash oficiais ou uma solução alternativa que preserve o critério móvel. O encaminhamento é entregue ao dono neste documento; não foi enviado a terceiros.

## Evolução e encerramento

A divergência foi registrada no planejamento da 0.13.0 antes da alteração da interface. Esta revisão agrega diagnóstico, patch e prova experimental. Permanece aberta para o mantenedor comum. A entrega é com-pendencias.
