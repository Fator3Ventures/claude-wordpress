# Fator3 MCP Pipedrive — fonte 0.13.0

Normas: revisão 5 de 02/11/2026. Base: 0.12.0. Referências e pedidos em reference/0130; planejamento em PLAN.md; resultados sanitizados em evidence/0130. Runtime instalável somente em plugin/wp-mcp-pipedrive-fator3.

## Gerar e verificar

Use Python 3 e PHP 8.3+ com OpenSSL, mbstring e extensões WordPress. `python3 build/package.py installer` gera o ZIP determinístico. `python3 build/verify.py --installer ../dist/wp-mcp-pipedrive-fator3-0.13.0-instalador.zip --php /caminho/php` confere lint, schemas, identidade, inventário e reprodução. Para fechar o fonte, use `python3 build/package.py source`. Não inclua credenciais, configurações de WordPress nem ZIPs na árvore fonte.

## Bancada

`build/lab.py --help` descreve os argumentos. Exige uma distribuição limpa do WordPress, os instaladores 0.12.0 e 0.13.0, um banco MySQL vazio com prefixo f3pipqa_0900_, F3_QA_USER e F3_QA_PASSWORD no ambiente, porta local e diretório novo fora do fonte. Cenários clean, upgrade e matrix; este último também exige a pasta dos cinco instaladores identificados em evidence/0130/companion-installers.json. Cada resultado é gravado em results no diretório da bancada. O bloqueio HTTP/e-mail permanece ativo.

`build/browser.py` exige c-clean, o banco descartável f3pipqa_0900_r13c_clean, PHP e Chromium headless. Gera uma senha efêmera, ativa um plugin local de aviso externo e remove ambos ao terminar. Executa os 12 critérios por tela, buscas/páginas, edição/validação/simulação/confirmação, leitura documental e teste da proposta experimental da folha comum. Esse último restaura os bytes oficiais mesmo em erro. Playwright Python é necessário. Não execute os testes em site compartilhado.

O relatório externo é canônico. Sua cópia no fonte é anterior ao fechamento e não contém o hash do próprio arquivo fonte. As capturas usam dados exclusivamente sintéticos.
