<?php
use Fator3\Pipedrive\{Api,Incidents,Fault};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))exit(3);
$checks=[];$ok=static function($n,$v)use(&$checks){$checks[$n]=(bool)$v;};
wp_set_current_user(1);$name='f3base/incidentes-tecnicos-ler';$ok('ausencia_isola_diagnostico',Api::dispatch('incidentes-ler')['code']==='incidentes_indisponiveis');
$reply=['ok'=>true,'itens'=>[],'proximo'=>null,'destino_configurado'=>false];$allowed=true;$calls=0;$factory=null;
$install=static function(bool $readonly=true)use(&$reply,&$allowed,&$calls,&$factory,$name){
 if(wp_has_ability($name))wp_unregister_ability($name);
 WP_Abilities_Registry::get_instance()->register($name,['label'=>'Synthetic central','description'=>'Disposable contract fixture','category'=>'pipedrive','input_schema'=>['type'=>'object'],'output_schema'=>['type'=>'object'],'permission_callback'=>static function()use(&$allowed){return $allowed;},'execute_callback'=>static function($i)use(&$reply,&$calls,&$factory){++$calls;return $factory?$factory($i):$reply;},'meta'=>['annotations'=>['readonly'=>$readonly]]]);
};
$install();$ok('pagina_vazia_explicita',Api::dispatch('incidentes-ler')['data']['fim']===true);
$mk=static fn($n,$p='pipedrive')=>['pacote'=>$p,'id'=>sprintf('%064x',$n),'recurso_ref'=>str_repeat('a',64),'codigo'=>'autorizacao_recusada','estado'=>'aberto','acao_humana'=>true,'entregas_pendentes'=>1,'proxima_entrega'=>'pendente','desde'=>time()-90,'alterado_em'=>time(),'email'=>'privado@example.test','dados'=>'CANARY-PRIVATE'];
$reply['itens']=[$mk(1),$mk(2,'meta')];$r=Api::dispatch('incidentes-ler');$ok('somente_pipedrive',count($r['data']['itens'])===1);$ok('projecao_sem_campo_privado',!str_contains(json_encode($r),'CANARY')&&!str_contains(json_encode($r),'@'));
$reply['itens']=[$mk(1,'meta')];$reply['proximo']=sprintf('%064x',1);$r=Api::dispatch('incidentes-ler');$ok('pagina_vazia_com_cursor',!$r['data']['fim']&&$r['data']['itens']===[]&&$r['data']['proximo_apos']===$reply['proximo']);
$reply['itens']=[$mk(2)];$reply['proximo']=null;$reply['itens'][0]['proxima_entrega']='reservado';$reply['itens'][0]['reserva']=wp_generate_uuid4();$r=Api::dispatch('incidentes-ler');$ok('incerteza_com_referencia',($r['data']['itens'][0]['entrega_incerta']??false)&&$r['data']['itens'][0]['reserva']===$reply['itens'][0]['reserva']);
$reply['proximo']=sprintf('%064x',1);$ok('cursor_sem_avanco_recusado',Api::dispatch('incidentes-ler',['apos'=>$reply['proximo']])['code']==='incidentes_contrato_invalido');
$reply['proximo']=null;$valid=$reply;
foreach(['estado'=>['qualquer'],'id'=>'invalido','desde'=>-1,'reserva'=>'SEGREDO','entregas_pendentes'=>-1] as $k=>$value){$reply=$valid;$reply['itens'][0][$k]=$value;$ok('recusa_'.$k,Api::dispatch('incidentes-ler')['code']==='incidentes_contrato_invalido');}
$reply=$valid;$install(false);$before=$calls;$ok('contrato_de_leitura_exigido',Api::dispatch('incidentes-ler')['code']==='incidentes_contrato_invalido'&&$calls===$before);$install();
$allowed=false;$before=$calls;$ok('permissao_destinatario',Api::dispatch('incidentes-ler')['code']==='incidentes_leitura_falhou'&&$calls===$before);$allowed=true;
wp_set_current_user(0);$before=$calls;$ok('anonimo_sem_leitura',Api::dispatch('incidentes-ler')['code']==='nao_autorizado'&&$calls===$before);wp_set_current_user(1);
$factory=static function($i)use($mk){$n=isset($i['apos'])?intval($i['apos'],16)+1:1;return ['ok'=>true,'destino_configurado'=>false,'itens'=>[$mk($n)],'proximo'=>sprintf('%064x',$n)];};
$s=Incidents::summary();$ok('limite_sem_total_falso',!$s['completo']&&$s['abertos']===20&&$s['proximo_apos']===sprintf('%064x',20));
$factory=static function($i)use($mk){if($i)return ['ok'=>false,'codigo'=>'leitura_indisponivel'];return ['ok'=>true,'destino_configurado'=>true,'itens'=>[$mk(1)],'proximo'=>sprintf('%064x',1)];};
try{Incidents::summary();$ok('falha_posterior_sem_recuperacao_falsa',false);}catch(Fault $e){$ok('falha_posterior_sem_recuperacao_falsa',$e->reason==='incidentes_leitura_falhou');}
$factory=static fn()=>throw new RuntimeException('CANARY-SECRET');$r=Api::dispatch('incidentes-ler');$ok('excecao_sanitizada',$r['code']==='incidentes_leitura_falhou'&&!str_contains(json_encode($r),'CANARY'));
wp_unregister_ability($name);
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count(array_filter($checks,fn($v)=>!$v))];
