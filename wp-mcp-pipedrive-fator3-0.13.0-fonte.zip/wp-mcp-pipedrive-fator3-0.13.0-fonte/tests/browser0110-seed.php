<?php
/** Run only with WP loaded in the isolated browser installation created by build/lab.py. */
if(PHP_SAPI!=='cli'||DB_NAME!=='f3pipqa_0900_r13c_clean'||WP_HOME!=='http://127.0.0.1:18491'||!WP_HTTP_BLOCK_EXTERNAL)exit(3);
wp_set_current_user(1);wp_set_password(getenv('F3_BROWSER_PASSWORD'),1);
delete_option(Fator3\Pipedrive\Configuration::OPTION);
// Reset synthetic regression leftovers before the deterministic browser sample.
$wpdb->query('DELETE FROM '.Fator3\Pipedrive\Store::table('ops'));
$wpdb->query('DELETE FROM '.Fator3\Pipedrive\Store::table('journal'));
foreach($wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",$wpdb->esc_like(Fator3\Pipedrive\Store::PENDING_PREFIX).'%')) as $key)delete_option($key);
$table=Fator3\Pipedrive\Store::table('journal');
for($n=1;$n<=45;$n++){
 $id=substr(hash('sha256','browser0110/'.$n),0,32);
 $op=$n===1?'lead-original':($n%4===0?'lead-encerrar':'whatsapp-registrar');
 $state=$n%8===0?'resultado_parcial_ou_incerto':($n%9===0?'operacao_recusada':'operacao_concluida');
 $meta=['previa_id'=>$id,'caminho'=>'pipedrive/'.$op,'status'=>$state,'classe'=>'registro','metodo'=>'POST','chaves_alteradas'=>['nota'],'entidade'=>'deal','registro_id'=>(string)(11000+$n),'etapas'=>[['etapa'=>'conferencia','code'=>'ok']]];
 $wpdb->replace($table,['previa_id'=>$id,'created'=>1794643200+$n*90,'metadata'=>wp_json_encode($meta)]);
}
require_once __DIR__.'/fixture050.php';
(new ReflectionProperty(Fator3\Pipedrive\CoreClient::class,'client'))->setValue(null,new ReleaseFixture());
$s=Fator3\Pipedrive\CoreClient::status();$ops=Fator3\Pipedrive\Store::table('ops');
for($n=1;$n<=12;$n++){
 $target=21000+$n;$id=substr(hash('sha256','pendencia0110/'.$n),0,32);$seal=Fator3\Pipedrive\Support::seal(['workflow'=>'negocio-perder','input'=>['negocio_id'=>$target]]);
 $wpdb->replace($ops,['previa_id'=>$id,'actor_id'=>1,'binding'=>Fator3\Pipedrive\CoreClient::binding($s),'state'=>'running','created'=>1794643200,'expires'=>1794644100,'retain_until'=>PHP_INT_MAX,'payload'=>$seal,'result'=>'']);
 $key=Fator3\Pipedrive\Store::CANONICAL_PENDING.hash('sha256',Fator3\Pipedrive\Support::digest($s['conta']).':deal:'.$target);update_option($key,$id,false);
 $wpdb->replace($table,['previa_id'=>$id,'created'=>1794643200,'metadata'=>wp_json_encode(['previa_id'=>$id,'metodo'=>'PUT','caminho'=>'pipedrive/negocio-perder','classe'=>'registro','status'=>'resultado_parcial_ou_incerto','entidade'=>'deal','registro_id'=>(string)$target])]);
}
