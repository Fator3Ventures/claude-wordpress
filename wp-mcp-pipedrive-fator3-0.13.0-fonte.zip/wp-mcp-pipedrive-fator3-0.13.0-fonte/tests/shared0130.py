"""Experimental common-CSS proposal; restore the official file in all outcomes."""
import os,json,hashlib,difflib
from pathlib import Path
from playwright.sync_api import sync_playwright
r=Path(__file__).resolve().parents[1];f=Path(os.environ['F3_WP_ROOT'])/'wp-content/plugins/wp-mcp-pipedrive-fator3/assets/f3-ui.css';original=f.read_bytes()
assert hashlib.sha256(original).hexdigest()=='15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b'
patch='.f3-ui .f3-field>:is(input:not([type=checkbox]):not([type=radio]),select,textarea),.f3-ui .f3-list-tools input[type=search]{min-height:var(--f3-touch)}\n'
candidate=original.decode().replace('.f3-ui{--f3-touch:40px}\n','.f3-ui{--f3-touch:40px}\n'+patch).encode();assert candidate!=original
(r/'reference/0130/f3-ui-1.0.0-mobile.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True),candidate.decode().splitlines(True),fromfile='a/f3-ui.css',tofile='b/f3-ui.css')))
checks={};base=os.environ['F3_BROWSER_URL']
try:
 f.write_bytes(candidate)
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ['F3_CHROMIUM'],args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']);ctx=b.new_context();page=ctx.new_page()
  page.goto(base+'/wp-login.php');page.locator('#user_login').fill('qa_admin');page.locator('#user_pass').fill(os.environ['F3_BROWSER_PASSWORD']);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**')
  for width in [360,768]:
   page.set_viewport_size({'width':width,'height':900})
   for tab in ['diario','regras','retencao','pendencias','ajuda']:
    page.goto(base+'/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3&aba='+tab)
    checks[f'{tab}-{width}']=page.locator('.f3-ui input:not([type=hidden]):not([type=checkbox]):not([type=submit]),.f3-ui select,.f3-ui textarea').evaluate_all('es=>es.filter(e=>e.getClientRects().length).every(e=>e.getBoundingClientRect().height>=40)') and page.evaluate('document.documentElement.scrollWidth')==width
  b.close()
finally:f.write_bytes(original)
report={'base_sha256':hashlib.sha256(original).hexdigest(),'experimental_sha256':hashlib.sha256(candidate).hexdigest(),'checks':checks,'passed':sum(checks.values()),'failed':sum(not x for x in checks.values()),'official_restored':f.read_bytes()==original}
(r/'evidence/0130/common-proposal.json').write_text(json.dumps(report,indent=2));print(report);assert report['failed']==0 and report['official_restored']
