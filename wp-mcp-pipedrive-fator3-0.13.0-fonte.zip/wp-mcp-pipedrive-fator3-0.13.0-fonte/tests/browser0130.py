"""Visual acceptance: real WP, six routes, three widths, foreign notice, keyboard and theme."""
import os,json,sys,hashlib,re,subprocess
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1];out=root/'evidence/0130/visual';out.mkdir(parents=True,exist_ok=True)
runtime=root/'plugin/wp-mcp-pipedrive-fator3';css=(runtime/'assets/admin.css').read_text()
base=os.environ['F3_BROWSER_URL'];entry=base+'/wp-admin/tools.php?page=wp-mcp-pipedrive-fator3'
tabs={'visao':'operacao','diario':'operacao','regras':'configurar','retencao':'configurar','pendencias':'suporte','ajuda':'suporte'}
measurements={};criteria={t:{str(i):True for i in range(1,13)} for t in tabs};checks={};errors=[]
def php(code):subprocess.run([os.environ['F3_PHP'],'-r','require $argv[1];'+code,str(Path(os.environ['F3_WP_ROOT'])/'wp-load.php')],check=True,capture_output=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=os.environ['F3_CHROMIUM'],args=['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']);ctx=b.new_context(locale='pt-BR',timezone_id='America/Sao_Paulo');page=ctx.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(base+'/wp-login.php');page.locator('#user_login').fill('qa_admin');page.locator('#user_pass').fill(os.environ['F3_BROWSER_PASSWORD']);page.locator('#wp-submit').click();page.wait_for_url('**/wp-admin/**')
 for w,h in [(360,800),(768,1024),(1440,1000)]:
  page.set_viewport_size({'width':w,'height':h})
  for tab,group in tabs.items():
   page.goto(entry+'&aba='+tab);page.wait_for_selector('.f3-nav');page.locator('.f3-ui').evaluate('e=>e.scrollIntoView()');page.evaluate('scrollTo(0,0)')
   m=page.evaluate(r'''() => {const root=document.querySelector('.f3-ui'),head=root.querySelector('.f3-heading'),visible=e=>!!e.getClientRects().length;
    const inputs=[...root.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio]):not([type=submit]),select,textarea')].filter(visible);
    return {width:document.documentElement.scrollWidth,viewport:innerWidth,head:[...head.children].map(e=>e.tagName),notice:!!root.querySelector(':scope>.notice[data-f3pd-foreign]'),foreignInside:!!head.querySelector('.notice'),divider:head.nextElementSibling.matches('hr.wp-header-end'),headingFont:getComputedStyle(head.querySelector('h1')).fontSize,headingWeight:getComputedStyle(head.querySelector('h1')).fontWeight,groupNames:[...root.querySelectorAll('.f3-groups a')].map(e=>e.textContent),navHeights:[...root.querySelectorAll('.f3-nav a')].map(e=>e.getBoundingClientRect().height),inputs:inputs.map(e=>({id:e.id,height:e.getBoundingClientRect().height,label:!!root.querySelector('label[for="'+e.id+'"]')})),buttonHeights:[...root.querySelectorAll('.button,button')].filter(visible).map(e=>e.getBoundingClientRect().height),tables:[...root.querySelectorAll('table')].every(e=>!!e.closest('.f3-table-scroll')),pills:[...root.querySelectorAll('.f3-pill')].every(e=>/^f3-pill( is-(ok|warn|info|error))?$/.test(e.className)),badClass:[...root.querySelectorAll('[class]')].some(e=>/f3pd-(panel|chip|pill|head|groups|subtabs|table|facts|row|filter|pager|toolbar)(\s|$)/.test(e.className)),nativeForm:!root.querySelector('.form-table'),navCurrent:root.querySelectorAll('.f3-nav [aria-current]').length===2,accent:getComputedStyle(root).getPropertyValue('--f3-accent').trim(),groupColor:getComputedStyle(root.querySelector('.f3-groups [aria-current]')).backgroundColor};}''')
   name=f'{tab}-{w}';measurements[name]=m
   common=page.request.get(page.locator('#f3-pipedrive-ui-css').get_attribute('href')).body()
   criteria[tab]['1'] &= hashlib.sha256(common).hexdigest()=='15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b'
   criteria[tab]['2'] &= m['head']==['H1','P','SPAN'] and m['headingFont']=='23px' and m['headingWeight']=='400'
   criteria[tab]['3'] &= m['notice'] and not m['foreignInside'] and m['divider']
   criteria[tab]['4'] &= m['groupNames']==['Operação','Configurar','Suporte'] and m['navCurrent']
   criteria[tab]['6'] &= m['pills'] and not m['badClass']
   criteria[tab]['7'] &= m['nativeForm'] and all(x['label'] for x in m['inputs'])
   criteria[tab]['8'] &= m['tables'] and (tab not in ['diario','pendencias'] or page.locator('nav.f3-list-tools .f3-list-total').count()==1)
   criteria[tab]['9'] &= m['width']==w
   if w<=782:criteria[tab]['10'] &= min(m['navHeights'])>=44 and all(x['height']>=40 for x in m['inputs']) and all(x>=40 for x in m['buttonHeights'])
   page.keyboard.press('Tab');page.locator('.f3-groups a').first.focus();page.keyboard.press('Tab');focus=page.locator(':focus');criteria[tab]['11'] &= focus.evaluate('e=>getComputedStyle(e).outlineWidth')=='2px'
   criteria[tab]['12'] &= not re.search(r'#[0-9a-fA-F]{3,8}\b|\d+px|--f3pd-',css)
   page.screenshot(path=str(out/(name+'.png')),full_page=True,animations='disabled')
   page.locator('.f3-ui details').evaluate_all('nodes=>nodes.forEach(e=>e.open=true)')
   checks[name+'_expanded_width']=page.evaluate('document.documentElement.scrollWidth')==w
 # Scheme setting belongs only to the synthetic administrator.
 php("update_user_option(1,'admin_color','coffee',true);")
 page.set_viewport_size({'width':1440,'height':1000})
 for tab in tabs:
  page.goto(entry+'&aba='+tab);color=page.locator('.f3-groups [aria-current]').evaluate('e=>getComputedStyle(e).backgroundColor');criteria[tab]['5']=color!=measurements[tab+'-1440']['groupColor']
 page.screenshot(path=str(out/'ajuda-cafe-1440.png'),full_page=True)
 php("update_user_option(1,'admin_color','fresh',true);")
 # No-script navigation and server forms still render, including the foreign notice.
 nj=b.new_context(java_script_enabled=False,storage_state=ctx.storage_state(),viewport={'width':360,'height':800});np=nj.new_page()
 for tab in tabs:
  np.goto(entry+'&aba='+tab);measurements[tab+'_nojs']={'document_width':np.evaluate('document.documentElement.scrollWidth'),'root_width':np.locator('.f3-ui').evaluate('e=>e.scrollWidth')};checks[tab+'_nojs_nav_fits']=np.locator('.f3-nav').evaluate('e=>e.getBoundingClientRect().right<=innerWidth');checks[tab+'_nojs_nav']=np.locator('.f3-subtabs [aria-current]').count()==1
 nj.close()
 page.goto(entry+'&aba=regras');page.get_by_label('Fuso horário',exact=True).fill('Fuso/Invalido');page.get_by_role('button',name='Validar campos',exact=True).click();page.wait_for_selector('.f3-result');measurements['result_feedback']=page.locator('.f3-result').evaluate_all('es=>es.map(e=>({role:e.getAttribute("role"),text:e.textContent}))');checks['result_alert']=page.locator('.f3-result[role=alert]').count()==1;page.get_by_role('button',name='Dispensar',exact=True).click();checks['dismiss_result']=page.locator('.f3-result').count()==0 and page.locator(':focus').evaluate('e=>e.tagName')=='H2'
 page.get_by_role('button',name='Adicionar texto',exact=True).click();checks['dynamic_labels_unique']=page.locator('[data-rows=textos] input').evaluate_all('es=>new Set(es.map(e=>e.id).filter(Boolean)).size===es.filter(e=>e.id).length')
 page.on('dialog',lambda d:d.accept());page.goto(base+'/wp-admin/index.php');checks['assets_scoped']=page.locator('#f3-pipedrive-ui-css,#f3-pipedrive-admin-css').count()==0
 checks['javascript_errors']=not errors;version=b.version;b.close()
failed=[f'{tab}:{k}' for tab,row in criteria.items() for k,v in row.items() if not v];unexpected=[x for x in failed if not x.endswith(':10')]+[k for k,v in checks.items() if not v]
report={'chromium':version,'criteria':criteria,'criteria_passed':72-len(failed),'criteria_pending':failed,'checks':checks,'checks_passed':sum(checks.values()),'unexpected_failures':unexpected,'measurements':measurements,'errors':errors}
(out.parent/'browser0130.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['criteria_passed','criteria_pending','checks_passed','unexpected_failures']},ensure_ascii=False));sys.exit(bool(unexpected))
