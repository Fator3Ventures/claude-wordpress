<?php
if(PHP_SAPI!=='cli'||DB_NAME!=='f3pipqa_0900_r13c_matrix'||WP_HOME!=='http://127.0.0.1:18491'||!WP_HTTP_BLOCK_EXTERNAL)exit(3);
wp_set_current_user(1);wp_set_password(getenv('F3_BROWSER_PASSWORD'),1);
update_option('f3base_pipedrive',['ativo'=>false,'dominio'=>'fixture.pipedrive.com'],false);
update_option('f3base_avisos_tecnicos',['email'=>'qa0120@example.test','antecedencia_dias'=>14,'resumo_diario'=>false],false);
add_filter('pre_wp_mail',static fn()=>throw new RuntimeException('Synthetic uncertain transport'),999);
apply_filters('f3base_incidente_publicar_v1',null,['pacote'=>'pipedrive','codigo'=>'autorizacao_recusada','recurso'=>'conta','estado'=>'aberto','acao_humana'=>true]);
