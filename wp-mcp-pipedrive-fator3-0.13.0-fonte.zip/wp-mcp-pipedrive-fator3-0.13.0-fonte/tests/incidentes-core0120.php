<?php
use Fator3\Pipedrive\{Api,Incidents};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0900'))exit(3);
wp_set_current_user(1);$checks=[];$ok=static function($n,$v)use(&$checks){$checks[$n]=(bool)$v;};$mails=0;$http=0;$uncertain=false;
$block=static function($pre,$args,$url)use(&$http){++$http;return new WP_Error('fixture','HTTP disabled');};add_filter('pre_http_request',$block,999,3);
$mail=static function($pre,$m)use(&$mails,&$uncertain){++$mails;if($uncertain)throw new RuntimeException("Synthetic uncertain transport");return true;};add_filter('pre_wp_mail',$mail,999,2);
$grant='qa-incidentes-'.bin2hex(random_bytes(6));
\Fator3\McpFiles\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'qa-0120','profile'=>'maintenance','status'=>'active']);
\Fator3\McpFiles\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'qa-0120','profile'=>'maintenance']);
$keys=['f3base_pipedrive','f3base_pipedrive_token','f3base_pipedrive_estado','f3base_avisos_tecnicos'];$saved=[];foreach($keys as $key)$saved[$key]=get_option($key,null);
try{
 $set=static function($key,$value){update_option($key,$value,false);wp_cache_delete($key,'options');};
 $cfg=F3Base_Options::ler('f3base_pipedrive');$cfg['ativo']=true;$cfg['dominio']='fixture.pipedrive.com';$set('f3base_pipedrive',$cfg);
 $set('f3base_pipedrive_token',F3Base_Segredos::cifrar('f3base_pipedrive_token',str_repeat('a9',20)));
 $set('f3base_avisos_tecnicos',['email'=>'','antecedencia_dias'=>14,'resumo_diario'=>false]);
 $set('f3base_pipedrive_estado',['codigo'=>'credencial_recusada']);F3Base_Incidentes_Provedores::pipedrive();
 $r=Api::dispatch('incidentes-ler');if(!$r['success'])throw new RuntimeException(json_encode($r));
 $items=$r['data']['itens'];$ok('core_real_abertura',count($items)===1&&$items[0]['estado']==='aberto'&&$items[0]['codigo']==='autorizacao_recusada');
 $ok('sem_destino_fica_na_fila',$items[0]['entregas_pendentes']===1&&$mails===0&&!$r['data']['destino_configurado']);
 F3Base_Incidentes_Provedores::pipedrive();$ok('episodio_unico',Api::dispatch('incidentes-ler')['data']['itens'][0]['entregas_pendentes']===1);
 $prefix='f3base_incidente_v1_';$snapshot=static fn()=>$GLOBALS['wpdb']->get_results("SELECT option_name,option_value FROM {$GLOBALS['wpdb']->options} WHERE option_name LIKE 'f3base_incidente_v1_%' ORDER BY option_name",ARRAY_A);
 $before=$snapshot();$n=$mails;Api::dispatch('incidentes-ler');Incidents::summary();Api::dispatch('status');$ok('leituras_nao_alteram_ou_enviam',$snapshot()===$before&&$mails===$n&&$http===0);
 $cfg['ativo']=false;$set('f3base_pipedrive',$cfg);F3Base_Incidentes_Provedores::pipedrive();$ok('desativar_nao_fabrica_recuperacao',Api::dispatch('incidentes-ler')['data']['itens'][0]['estado']==='aberto');
 $cfg['ativo']=true;$set('f3base_pipedrive',$cfg);$set('f3base_pipedrive_estado',['codigo'=>'timeout']);F3Base_Incidentes_Provedores::pipedrive();$ok('falha_isolada_nao_recupera',Api::dispatch('incidentes-ler')['data']['itens'][0]['estado']==='aberto');
 $state=['estado'=>'verificado','conta_id'=>'12345','usuario_id'=>1234,'dominio'=>$cfg['dominio'],'instalacao'=>'qa0120','revisao'=>F3Base_Options::revisao('f3base_pipedrive'),'credencial_revisao'=>F3Base_Options::revisao('f3base_pipedrive_token')];$state['identidade_conta']=F3Base_Integracoes::identidade_pipedrive($state);$set('f3base_pipedrive_estado',$state);F3Base_Incidentes_Provedores::pipedrive();
 $r=Api::dispatch('incidentes-ler');$ok('somente_prova_core_recupera',$r['data']['itens'][0]['estado']==='recuperado'&&$r['data']['itens'][0]['entregas_pendentes']===0);
 $set('f3base_avisos_tecnicos',['email'=>'qa0120@example.test','antecedencia_dias'=>14,'resumo_diario'=>false]);
 F3Base_Incidentes_Provedores::pipedrive();$r=Api::dispatch('incidentes-ler');$ok('episodio_nao_notificado_recupera_sem_email',$mails===0&&$r['data']['itens'][0]['entregas_pendentes']===0);
 F3Base_Incidentes_Provedores::pipedrive();$ok('repeticao_sem_email_duplicado',$mails===0);
 $uncertain=true;$set('f3base_pipedrive_estado',['codigo'=>'credencial_recusada']);F3Base_Incidentes_Provedores::pipedrive();
 $item=Api::dispatch('incidentes-ler')['data']['itens'][0];$ok('core_reserva_incerta_preservada',$item['entrega_incerta']&&$item['reconciliacao']==='f3base/incidente-entrega-reconciliar'&&isset($item['reserva']));
 $n=$mails;F3Base_Incidentes_Provedores::pipedrive();Incidents::summary();$ok('incerta_nao_reenvia',$mails===$n);
 $reconcile=wp_get_ability('f3base/incidente-entrega-reconciliar');
 $bad=$reconcile->execute(['id'=>$item['id'],'reserva'=>wp_generate_uuid4(),'resultado'=>'aceito']);$ok('reserva_divergente_nao_reconcilia',empty($bad['ok'])&&Api::dispatch('incidentes-ler')['data']['itens'][0]['entrega_incerta']);
 $rr=$reconcile->execute(['id'=>$item['id'],'reserva'=>$item['reserva'],'resultado'=>'aceito']);$ok('reconciliacao_publica_explicita',!empty($rr['ok'])&&Api::dispatch('incidentes-ler')['data']['itens'][0]['entregas_pendentes']===0&&$mails===$n);
 $uncertain=false;$set('f3base_pipedrive_estado',$state);F3Base_Incidentes_Provedores::pipedrive();
 $ok('recuperacao_de_abertura_reconciliada_aceita',$mails===2&&Api::dispatch('incidentes-ler')['data']['itens'][0]['estado']==='recuperado');
 F3Base_Incidentes_Provedores::pipedrive();$ok('recuperacao_enviada_nao_duplica',$mails===2);
 $ok('consulta_sem_crm',$http===0);
}finally{
 \Fator3\McpFiles\Persistence::delete('connections','grant:'.$grant);\Fator3\McpFiles\Persistence::delete('oauth-grants',$grant);\Fator3\McpFiles\ConnectionContext::restore_identity(null,1);
 foreach($saved as $k=>$v){if($v===null)delete_option($k);else update_option($k,$v,false);}
 foreach($wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'f3base_incidente_v1_%'") as $k)delete_option($k);
 remove_filter('pre_http_request',$block,999);remove_filter('pre_wp_mail',$mail,999);
}
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count(array_filter($checks,fn($v)=>!$v)),'mails_intercepted'=>$mails,'supplier_http'=>$http];
