# Testes da 0.12.0

Requisitos declarados: WordPress >= 7.1.4 e PHP >= 8.3 de 64 bits com OpenSSL, mysqli, zlib, mbstring e DOM. Bancada desta rodada: WordPress 7.1.4, PHP 8.3.6 e 8.4.27 e MariaDB 11.8.6. O site-teste foi somente consultado; permaneceu na 0.11.1. A suíte destrutiva não é executada no site compartilhado.

## Reprodução isolada

1. Tenha uma distribuição WordPress com raiz wordpress/ sem wp-config.php, os instaladores Pipedrive 0.11.1 e 0.12.0 e os hashes do relatório. Para a matriz, reúna os cinco instaladores exatos de evidence/0120/companion-installers.json: Core 1.93.0, MCP 0.48.0, Google 0.36.0, Meta 0.28.0 e LinkedIn 0.26.0.
2. Crie três bancos vazios em 127.0.0.1, com prefixo f3pipqa_0900_. Defina F3_QA_USER e F3_QA_PASSWORD para usuário restrito à bancada. O script recusa bancos contendo tabelas e diretórios de trabalho existentes. Ele não cria nem remove bancos.
3. Execute na raiz do fonte, substituindo caminhos e hash:

    python3 build/lab.py --scenario clean --db f3pipqa_0900_r12c_clean --work /bancada/c-clean --wordpress /pacotes/wordpress.zip --base /pacotes/wp-mcp-pipedrive-fator3-0.11.1-instalador.zip --candidate /pacotes/wp-mcp-pipedrive-fator3-0.12.0-instalador.zip --candidate-sha256 SHA256 --php /caminho/php --port 3306

Para atualização, use scenario upgrade com outro banco e diretório novos. Para a matriz, use scenario matrix e --companions /pacotes, também com banco e diretório próprios. Exporte PHPRC absoluto e as bibliotecas necessárias aos subprocessos quando usar PHP isolado.

Cada suíte roda em processo PHP novo. A instalação usa Plugin_Upgrader nativo. A atualização semeia regras, recibo, progresso, diário, pendência e retenção sintéticos na base 0.11.1 e verifica preservação e replay na 0.12.0. Os JSON em results/ contêm asserções; exception ou failed invalida a suíte. Não confunda instalação bem-sucedida com suíte completa.

O MU-plugin network-fence.php bloqueia HTTP e e-mail externos. Nenhuma fixture deve ser instalada no site compartilhado. As suítes usam respostas sintéticas; não provam entregabilidade nem autorização no CRM real.

## Novas regressões

incidentes0120 testa paginação filtrada, dados malformados, reserva incerta, projeção sem dados privados, ausência do Core, permissões, limite do resumo e falha depois da primeira página. incidentes-core0120 usa o Core original para abertura, recuperação comprovada, deduplicação, fila sem destinatário, transporte interceptado, incerteza e reconciliação explícita. A conexão MCP sintética é criada e removida dentro do banco descartável. integrated confirma descoberta, política e documentação pelo executor original.

## Navegador

Depois da instalação clean acima, exporte F3_QA_DB=f3pipqa_0900_r12c_clean e as variáveis do banco. Execute:

    python3 build/browser.py --work /bancada/c-clean --php /caminho/php --chromium /caminho/chromium

Requer Playwright Python e Chromium. Usa porta local 18491, redefine exclusivamente a senha do administrador sintético e as regras locais, aplica cliente CRM sintético e remove os arquivos temporários ao sair. Captura as seis abas em 360, 768 e 1440 px e verifica paginação, busca, formulários, JavaScript e uso sem JavaScript. browser0120-matrix.py verifica o novo quadro com Core e MCP originais e dados sintéticos na bancada de matriz; build/browser-matrix.py prepara esse cenário.

Preserve apenas evidências sanitizadas. Encerre os servidores e remova bancos e segredos descartáveis ao fim. Nenhuma credencial, dump ou log privado pertence ao fonte distribuído.
