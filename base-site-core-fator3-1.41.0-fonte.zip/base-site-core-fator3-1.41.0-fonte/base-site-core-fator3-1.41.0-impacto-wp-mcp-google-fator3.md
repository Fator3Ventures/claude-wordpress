# Impacto de base-site-core-fator3 1.41.0 em wp-mcp-google-fator3

20/10/2026 · Revisão 2 · Etapa: entrega · Situação: aberto para incorporação/homologação.
Base Core 1.40.0 → alvo entregue 1.41.0. Google examinado: 0.14.0.
Classificação: acao-necessaria. Natureza: dependência de código e validação da integração.
Instalador Core: `base-site-core-fator3-1.41.0-instalador.zip`, SHA-256 `66ae54be3b0ec7a066187455b8358fc3c3431a47de8fc6aa8ac8c5efa3510919`.

## Alteração implementada

Core fixa destination_ref no aceite e despacha exclusivamente por `sendBound(array $payload, string $destinationRef)`. A existência do método negocia a extensão; não são acrescentados campos incompatíveis ao contrato site-conversion-delivery/1.0.0. O send() anterior continua disponível para consumidores antigos.

A dependência Google implementada confere a referência recebida dentro do lock comum a configuração/envio e no guard de execução. Divergência comprovada antes do despacho resulta em recusado/non_delivery_proven com código destination_mismatch. Core conserva códigos seguros e continua sem repetir resultados incertos.

## Repasse e ordem

Pacote: `wp-mcp-google-fator3-dependencia-core-1.41.0.zip`, 14152 bytes; SHA-256 `9854091bd070a0791f81a1fe453fd96272c0933b62977a6ebd7d7be39698c160`.

Contém arquivo alterado, diff, hashes-base, instruções e teste. Código implementado nesta frente, sem aguardar resposta Google. O mantenedor deve incorporá-lo em sua próxima versão, com seus próprios artefatos e número de release. Não instalar uma 0.14.0 alterada mantendo a identidade pública publicada.

Core 1.41 + Google 0.14 publicado: navegador disponível; novas ativações servidor recusadas e filas servidor bloqueadas com destination_binding_unsupported. Após incorporar a dependência e verificar as credenciais, o fluxo servidor pode ser homologado. Não há necessidade de parar a implementação Core para aguardar incorporação.

## Aceite e evidência

39 verificações próprias com adaptador Google real em WordPress e fornecedor simulado: verificação de configuração, sendBound com referência correta/divergente, ausência de HTTP na divergência, recusa após alteração, códigos, estados e worker Core com entrega única. Evidência: google-bound-1410.json no fonte.

Sessão GA4: Core captura evidência da tag nativa e aplica janela de 24 horas; identidade opaca histórica é bloqueada. Atribuição analítica real e cenários de inatividade não foram homologados. Não cabe marcar esse aceite como concluído só por HTTP 2xx.

## Evolução

Revisão 1 planejou a validação da fronteira. Revisão 2 entrega a dependência mínima necessária, fechando a espera de desenvolvimento nesta frente. Permanecem com o mantenedor a incorporação/publicação Google e a validação comercial em ativos autorizados. Nenhuma resposta do destinatário é presumida.
