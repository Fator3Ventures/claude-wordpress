> Revisão 3 — implementação em 20/10/2026. Relatório 1.41.0 e RELEASE-1.41.0.md são a descrição vigente. Extensão sendBound implementada no repasse Google. Homologação real de sessão GA4, navegador e instalação remota permanecem pendentes. Texto abaixo preserva o planejamento e não é evidência de testes.

# Plano — Fator3 Site Core 1.41.0

Revisão 2 · 20/10/2026 · America/Sao_Paulo · Etapa: planejamento.
Base: `base-site-core-fator3` 1.40.0. Alvo previsto: 1.41.0, sem instalador gerado.
Acompanhante examinado: `wp-mcp-google-fator3` 0.14.0.
Origem: pedido “Planeje a próxima versão com esses pontos”, após revisão de compatibilidade. Sem novo número de pedido central atribuído; os três itens abaixo são referências locais deste plano, vinculadas à correção do fluxo do pedido Core 236.

## 1. Objetivo e limites

Corrigir a vinculação do destino, preservar diagnósticos do adaptador e atender ao requisito de atribuição à sessão original no GA4. Preservar a escolha navegador/servidor por contato, consentimento, deduplicação e bloqueio de reenvio incerto.

A implementação parte da 1.40.0 publicada, com instalação limpa e atualização direta 1.40.0 → 1.41.0. Não ampliar a janela histórica nesta rodada. Permanecem as identidades públicas, integrações e comportamento de Meta, materiais e C0. Não incluir valores comerciais Ads configuráveis, Data Manager, consultas assíncronas de recibos nem novas funcionalidades de relatório.

A compatibilidade atual de entrega `site-conversion-delivery/1.0.0` está preservada. Leitura `site-conversion-purposes/1.0.0` e `1.1.0` permanece negociada, sem acrescentar campos incompatíveis a schemas fechados.

## 2. Destino imutável desde o aceite

### Problema comprovado

`F3Base_Conversoes_Servidor::capturar()` cria a linha com `destino_ref` vazio. `processar()` fixa o destino apenas imediatamente antes de `send()`. Na revisão local, a troca A → B antes da primeira tentativa fez um contato existente seguir para B.

### Implementação prevista

- Persistir junto ao contato a identidade opaca do destino selecionado para cada transporte servidor. Obter a identidade por `capabilities()` local, sem HTTP no aceite.
- Criar/reconciliar a fila a partir desse snapshot; repetir a captura não substitui a identidade. A mudança de configuração vale para novos contatos.
- Se a identidade não estiver disponível no aceite, manter o contato e a propriedade servidor, com entrega bloqueada e diagnóstico específico. Não atribuir silenciosamente a configuração encontrada depois.
- Comparar a identidade persistida com a do adaptador antes de cada tentativa. Mudança bloqueia o envio; restauração da identidade original permite reavaliação, respeitando consentimento, prazo e estado.
- Testar a troca concorrente entre verificação e envio. A proteção precisa alcançar o destino realmente usado pelo adaptador. Se o contrato atual não permitir essa garantia, implementar a menor adaptação negociada necessária no Google e entregar código/testes ao mantenedor, conforme autorização já dada; não aguardar retorno para implementar. Não anunciar uma versão de contrato nova sem necessidade demonstrada.

### Migração e recuperação

- Preservar referências já gravadas, tentativas e estados; `entregue` e `incerto` nunca voltam automaticamente à fila.
- Pendências da 1.40 sem referência não permitem inferir o destino histórico pela configuração atual. Permanecem bloqueadas até vinculação administrativa explícita e auditada, pelo fluxo de recuperação existente, com confirmação de não entrega quando aplicável.
- A recuperação não muda transporte nem ignora prazos, consentimento ou resultados incertos. Evitar novo painel quando a operação existente puder cobrir a ação com validação administrativa.

### Aceite

A → B antes do primeiro envio, durante tentativa e após recusa não entrega em B um contato vinculado a A. Reconciliação, repetição de submissão e crash não perdem o vínculo. Renovação de credencial da mesma identidade segue a semântica de identidade publicada pelo Google; mudança de principal/destino não é tratada como simples renovação.

## 3. Diagnóstico específico preservado

### Problema comprovado

O Core substitui `capabilities().reason` por `adaptador_indisponivel` e `send().code` pelo estado genérico. A revisão reproduziu a perda de `verification_required` e `ga4_prevalidation_failed`.

### Implementação prevista

- Separar estado da entrega de motivo operacional. Preservar códigos seguros retornados por `capabilities()` e `send()`, com limites de tamanho/formato e fallback genérico para ausência ou conteúdo inválido.
- Disponibilizar o motivo na leitura administrativa de entregas e na configuração/contexto pertinentes, mantendo as respostas compatíveis com os schemas publicados.
- Documentar motivos de configuração ausente, verificação expirada, autorização revogada, destino alterado, prevalidação recusada e confirmação Ads divergente. Não persistir respostas brutas, tokens ou dados pessoais.
- Manter `non_delivery_proven` como condição para recusa reenviável. Um código específico não transforma resultado incerto em falha comprovada.
- Manter explícito que GA4 `entregue` significa recepção HTTP; processamento analítico exige homologação externa. Não criar um sistema novo de recibos para resolver diagnóstico.

### Aceite

Os motivos específicos chegam íntegros à consulta administrativa após processamento. Códigos inválidos recebem fallback; dados privados não vazam. Recusa comprovada, entrega e incerteza preservam suas regras de repetição. Leitura de estado não chama fornecedor nem altera fila.

## 4. Sessão original no GA4

### Requisito e limite identificado

O prazo de coleta de 72 horas não basta para atribuição à sessão original. A documentação oficial exige `session_id`, envio até 24 horas após o início da sessão e `timestamp_micros` dentro da sessão. Fonte consultada na revisão: https://developers.google.com/analytics/devguides/collection/protocol/ga4/use-cases .

O Core já captura identidade GA4, mas a revisão não demonstrou uma fonte confiável para os limites temporais da sessão. A existência de `session_id` não autoriza convertê-lo implicitamente em timestamp.

### Implementação prevista

1. Examinar a captura atual e determinar a fonte verificável do início da sessão e da ocorrência do contato dentro dela. Registrar origem e limites da evidência; primeira observação local isolada não prova que a sessão começou naquele instante.
2. Persistir o contexto temporal com o contato, sem coleta sem consentimento e sem inventar valores. Validar coerência temporal no servidor; dados enviados pelo navegador continuam sujeitos a validação, e não constituem prova absoluta do fornecedor.
3. Aplicar, antes de cada tentativa, a janela de atribuição da sessão além da janela de coleta. Informação insuficiente bloqueia a entrega que depende desse requisito com motivo específico; prazo encerrado impede recuperação automática tardia.
4. Preservar `occurred_at`, `timestamp_micros`, `client_id`, `session_id` e `event_id`. Não retimar o evento para fazê-lo caber na janela e não recorrer automaticamente ao navegador.
5. Manter `engagement_time_msec` somente quando houver medição real e necessária ao aceite de Realtime/engajamento. Sua ausência, isoladamente, não invalida o protocolo nem justifica um valor sintético.
6. Se a inspeção demonstrar que a captura disponível não sustenta o requisito, registrar a limitação como bloqueio desse aceite e entregar a menor captura necessária. Não declarar sessão original homologada apenas pela presença dos identificadores.

### Aceite

Fixtures cobrem limite de 24 horas, evento fora da sessão, atraso da fila, relógio incoerente, contexto ausente, mudança de sessão e consentimento negado. No fornecedor, um contato de homologação autorizado deve aparecer uma única vez, vinculado à sessão esperada. HTTP 2xx, debug e Realtime isoladamente não encerram essa prova.

## 5. Sequência e testes da implementação

1. Congelar fixtures dos três defeitos e revisar schemas/identidade, incluindo a troca concorrente.
2. Implementar snapshot do destino, migração e recuperação; depois diagnóstico.
3. Implementar a evidência temporal GA4 e os bloqueios necessários; adaptar Google somente se a fronteira exigir.
4. Validar instalação limpa e atualização da 1.40.0 em WordPress descartável. Preservar configurações, registros, filas e autorizações.
5. Validar integração Core 1.41 + Google 0.14, isolamento sem Google, modos mistos e ausência de duplicação navegador/servidor. Se houver patch Google, testar também o comportamento seguro com a versão publicada anterior.
6. Se a captura JavaScript mudar, verificar navegador real, página em cache, WebView Android/Instagram e orçamento existente de quatro scripts de contato, sem requisições adicionais de carga e soma HTTP comprimida ≤21.517 bytes.
7. Atualizar documentação instalada, schemas/exemplos afetados, operação e recuperação. Conferir leitura completa/versionada pelo MCP e recusa de acesso administrativo indevido.
8. Homologar no Site-Teste com inventário antes/depois e destinos de teste autorizados. Credenciais/ativos indisponíveis geram pendência explícita; não impedem desenvolvimento e testes simulados.

Esses testes são previstos. As provas existentes pertencem à revisão da 1.40.0: quatro verificações dirigidas reproduziram os problemas de destino/diagnóstico, dentro de execução local com 16 verificações. Não houve envio Google real.

## 6. Impacto e responsabilidades

Encaminhamento único: `base-site-core-fator3-1.41.0-impacto-wp-mcp-google-fator3.md`, classificação `validacao-coordenada`. Há consequência concreta para identidade do destino, diagnósticos e prova analítica integrada.

Core responde pela implementação, migração, fila, captura e testes. Google continua dono de APIs, credenciais e adaptação do fornecedor. Eventual dependência necessária será implementada nesta frente e repassada com código, testes e contrato, sem espera por outro ciclo de impacto. Não publicar ou renumerar um pacote Google alheio silenciosamente.

MCP e Implantador: nenhum novo requisito de desenvolvimento identificado no escopo; interfaces administrativas afetadas precisam manter compatibilidade. Meta/LinkedIn/C0: fora das alterações. Não foi realizada auditoria geral desses pacotes.

O dono fornece ativos e autorizações de homologação quando necessários. A frota continua responsável pela distribuição. Este planejamento não instala, publica nem envia mensagens externas.

## 7. Dados, reversão e entrega

Migração aditiva e idempotente. Fazer backup antes da troca; preservar diário e evidências. Voltar somente os arquivos à 1.40 reintroduz as lacunas de identidade e diagnóstico: suspender o processamento servidor antes de qualquer reversão e avaliar a compatibilidade dos dados, sem apagar histórico. Efeitos já enviados não são revertidos por rollback.

Na implementação, entregar `base-site-core-fator3-1.41.0-fonte.zip`, `base-site-core-fator3-1.41.0-instalador.zip` e `base-site-core-fator3-1.41.0-relatorio.md`, com documentação instalada, evidências e hashes reais. Atualizar o mesmo impacto, distinguindo prova local, WordPress e fornecedor.

Nesta rodada são entregues plano, relatório documental e impacto. ZIPs 1.40.0 são a base inalterada, identificada no relatório. Não existem fonte/instalador 1.41.0.


## 8. Revisão das descrições de configuração — acréscimo de 20/10/2026

Pedido direto do dono: tornar as descrições dos itens das páginas de configuração mais explicativas. Referência recebida: `Fator3 Site Core(9).md`. Sem atribuir novo número à lista central.

Adicionar à 1.41.0 a revisão editorial de todas as páginas e telas especializadas: rótulos, introduções, descrições, ajudas, alternativas e exemplos. Explicar finalidade, escolha, comportamento vazio/desligado, formato, precedência e dependências quando aplicáveis. Eliminar frases genéricas, repetição do título e contradições; conferir os textos no HTML e na documentação gerada.

O documento `base-site-core-fator3-1.41.0-revisao-descricoes.md` contém o diagnóstico, redações propostas para as páginas e campos prioritários e os critérios de aceite. O catálogo examinado possui 70 opções e 129 subcampos declarados; telas especializadas precisam de conferência complementar. Não apresentar o inventário como revisão visual já concluída.

O item 241 orienta os nomes funcionais da interface. Os itens 238–241 do anexo envolvem também alterações de comportamento, configuração e migração: continuam pendências recebidas, não são considerados implementados nem integralmente incluídos por este pedido editorial. A redação deve acompanhar somente capacidades efetivamente entregues. Identificadores técnicos e migrações não mudam por mera revisão de texto.

Não há novo impacto externo identificado para a revisão editorial compatível. O impacto Google já previsto permanece restrito à integração. Nenhum runtime publicado foi modificado nesta rodada.
