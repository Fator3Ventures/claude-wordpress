<?php
require __DIR__.'/bootstrap.php';
check(F3BASE_PLUGIN_VERSAO==='1.41.0','version');F3Base_Conversoes_Servidor::instalar();
$wpdb->query('DELETE FROM '.F3Base_Conversoes_Servidor::tabela());
$adapter=new class {
 public string $ref='A';public bool $ready=true;public string $reason='verification_required';public string $status='recusado';public string $code='ga4_prevalidation_failed';public int $calls=0;public bool $race=false;public bool $proof=true;
 public function capabilities(){return array('contract'=>F3Base_Conversoes_Servidor::CONTRATO,'ready'=>$this->ready,'reason'=>$this->reason,'destination_ref'=>$this->ref);}
 public function send($p){throw new Exception('unbound_send_forbidden');}
 public function sendBound($p,$expected){if($this->race){$this->ref='B';}if($expected!==$this->ref){return array('status'=>'recusado','non_delivery_proven'=>true,'code'=>'destination_mismatch');}++$this->calls;return array('status'=>$this->status,'code'=>$this->code,'non_delivery_proven'=>$this->proof);}
};
add_filter('f3base_conversoes_adaptador',static fn($a,$t)=>$adapter,999,2);
raw('f3base_conversoes_transporte',array('ga4'=>'servidor','google_ads'=>'navegador'));
function lead141(): array {
 global $wpdb;
 $result=F3Base_Leads_Repositorio::guardar(array('nome'=>'Synthetic','email'=>wp_generate_uuid4().'@example.test','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture141','contexto_teste'=>false,'notificar'=>false));check(!empty($result['persisted']),'record_saved_'.$result['record_id']);$lead=F3Base_Leads_Repositorio::obter($result['record_id']);$d=$lead['dados'];
 $d['audiencia_excluida']=false;$d['consentimento_snapshot']=array('medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao());
 $d['ga4']=array('client_id'=>'123.456','session_id'=>(string)(time()-60),'measurement_id'=>'G-TEST141','session_evidence'=>array('source'=>'google_tag_native','started_at'=>time()-60,'observed_at'=>time(),'received_at'=>time()));
 $wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d),'classe_trafego'=>'nao_marcado'),array('record_id'=>$lead['record_id']));return F3Base_Leads_Repositorio::obter($lead['record_id']);
}
function row141($id){return F3Base_Conversoes_Servidor::ler(array('record_id'=>$id))['entregas'][0];}
function due141($id){global $wpdb;$wpdb->update(F3Base_Conversoes_Servidor::tabela(),array('proxima'=>time()-1),array('record_id'=>$id));}
$l=lead141();$id=$l['record_id'];F3Base_Conversoes_Servidor::capturar($l);check(row141($id)['destino_ref']==='A','pinned_at_acceptance');
$adapter->ref='B';F3Base_Conversoes_Servidor::processar();check($adapter->calls===0&&row141($id)['codigo']==='destino_alterado','change_before_first_dispatch_blocked');
$adapter->ref='A';due141($id);F3Base_Conversoes_Servidor::processar();check($adapter->calls===1&&row141($id)['codigo']==='ga4_prevalidation_failed','send_diagnostic_preserved');
$adapter->ready=false;due141($id);F3Base_Conversoes_Servidor::processar();check(row141($id)['codigo']==='verification_required','worker_readiness_reason');check(F3Base_Conversoes_Transporte::capacidade('ga4')['reason']==='verification_required','config_readiness_reason');
$adapter->reason='private token !';due141($id);F3Base_Conversoes_Servidor::processar();check(row141($id)['codigo']==='adaptador_indisponivel','unsafe_code_dropped');
$adapter->ready=true;$adapter->race=true;due141($id);F3Base_Conversoes_Servidor::processar();check($adapter->calls===1&&row141($id)['codigo']==='destination_mismatch','race_bound_send_refused');
$adapter->race=false;$adapter->ref='A';$adapter->status='entregue';due141($id);F3Base_Conversoes_Servidor::processar();$calls=$adapter->calls;due141($id);F3Base_Conversoes_Servidor::processar();check($calls===$adapter->calls&&row141($id)['estado']==='entregue','delivered_never_retried');
$l=lead141();$id=$l['record_id'];$adapter->status='recusado';$adapter->proof=false;F3Base_Conversoes_Servidor::processar();check(row141($id)['estado']==='incerto','refusal_without_proof_uncertain');$calls=$adapter->calls;due141($id);F3Base_Conversoes_Servidor::processar();check($calls===$adapter->calls,'uncertain_never_retried');
$l=lead141();$id=$l['record_id'];$d=$l['dados'];unset($d['conversoes_transporte']['referencias']);$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d)),array('record_id'=>$id));$wpdb->delete(F3Base_Conversoes_Servidor::tabela(),array('record_id'=>$id));F3Base_Conversoes_Servidor::processar();check(row141($id)['destino_ref']===''&&row141($id)['codigo']==='destino_historico_ausente','legacy_not_inferred');
$req=array('record_id'=>$id,'vincular_destinos'=>array('ga4'=>'A'),'nao_entregues_confirmados'=>array('ga4'));
$r=F3Base_Conversoes_Servidor::recuperar($req);check($r['destinos']['ga4']['elegivel']&&row141($id)['destino_ref']==='','binding_dry_run');
wp_set_current_user(0);check(!F3Base_Conversoes_Servidor::recuperar($req+array('confirmar'=>true))['ok'],'binding_admin_gate');wp_set_current_user(1);
$r=F3Base_Conversoes_Servidor::recuperar($req+array('confirmar'=>true));check(row141($id)['destino_ref']==='A','explicit_binding_saved');$bound=F3Base_Leads_Repositorio::obter($id);check($bound['dados']['conversoes_transporte']['vinculos_administrativos']['ga4']['usuario']===1,'binding_audited');
$wpdb->delete(F3Base_Conversoes_Servidor::tabela(),array('record_id'=>$id));F3Base_Conversoes_Servidor::capturar($bound);check(row141($id)['destino_ref']==='A','reconciliation_preserves_binding');
$g=$bound['dados']['ga4'];check(F3Base_Ga4_Sessao::validar($g,time())==='','native_session_valid');$bad=$g;unset($bad['session_evidence']);check(F3Base_Ga4_Sessao::validar($bad,time())==='ga4_sessao_sem_evidencia','opaque_session_not_cast');
$bad=$g;$bad['session_evidence']['observed_at']=time()+100;check(F3Base_Ga4_Sessao::validar($bad,time())==='ga4_sessao_tempo_invalido','browser_clock_checked');
$bad=$g;$bad['session_id']=(string)(time()-86401);$bad['session_evidence']['started_at']=(int)$bad['session_id'];check(F3Base_Ga4_Sessao::validar($bad,time())==='ga4_sessao_expirada','24h_expired');
$bad=$g;$bad['session_id']=(string)(time()-86400);$bad['session_evidence']['started_at']=(int)$bad['session_id'];check(F3Base_Ga4_Sessao::validar($bad,time())==='','24h_boundary');
$bad=$g;$bad['session_id']='123';check(F3Base_Ga4_Sessao::validar($bad,time())==='ga4_sessao_tempo_invalido','session_identity_consistent');
$l['dados']['consentimento_snapshot']['medicao']=false;check(F3Base_Conversoes_Servidor::preparar($l,'ga4')['codigo']==='consentimento_nao_permite','consent_before_session');
$catalog=F3Base_Options::catalogo();check($catalog['f3base_c0']['rotulo']==='E-mail automático ao novo lead','functional_label');check(F3Base_Interface::grupo('f3base_conversoes_transporte',$catalog['f3base_conversoes_transporte'])==='medicao-tags','transport_visible_in_tags');
foreach($catalog as $name=>$c){if(empty($c['operavel']))continue;check(!empty($c['descricao']),'description_'.$name);foreach($c['subcampos']??array() as $key=>$field){$help=F3Base_Interface::ajuda($name,$key,$field);check(!str_contains(wp_json_encode($help),'Escolha conforme o fluxo descrito'),'specific_help_'.$name.'.'.$key);}}
$legacyAdapter=new class {public function capabilities(){return array('contract'=>F3Base_Conversoes_Servidor::CONTRATO,'ready'=>true,'destination_ref'=>'A');}public function send($p){throw new Exception('must_not_dispatch');}};
$legacyFilter=static fn()=>$legacyAdapter;add_filter('f3base_conversoes_adaptador',$legacyFilter,1000,2);
check(F3Base_Conversoes_Transporte::capacidade('ga4')['reason']==='destination_binding_unsupported','old_adapter_safe_block');
check(F3Base_Conversoes_Transporte::validar(array('ga4'=>'servidor','google_ads'=>'navegador'))!=='','old_adapter_activation_refused');
remove_filter('f3base_conversoes_adaptador',$legacyFilter,1000);
$badAdapter=new class {public function capabilities(){return new WP_Error('broken');}public function send($p){}};$badFilter=static fn()=>$badAdapter;add_filter('f3base_conversoes_adaptador',$badFilter,1000,2);
check(!F3Base_Conversoes_Transporte::capacidade('ga4')['ready'],'malformed_capability_safe');remove_filter('f3base_conversoes_adaptador',$badFilter,1000);
evidence('release-1410');
