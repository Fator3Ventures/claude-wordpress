# Dependência Google para Core 1.41.0

Base: wp-mcp-google-fator3 0.14.0. Este pacote é um repasse de código, não um instalador e não uma nova release Google.

Incorporar `includes/ConversionDelivery.php` na próxima versão mantida do Google, preservando as demais alterações do mantenedor. O arquivo adiciona sendBound(payload, destinationRef), mantém send(payload) e confere a identidade sob o lock da configuração e no guard de execução. Core 1.41 exige o método por negociação de capacidade PHP; o contrato básico site-conversion-delivery/1.0.0 não muda. Com Google 0.14 publicado, servidor fica bloqueado; navegador mantém funcionamento.

Confira o hash do arquivo-base abaixo antes de aplicar o patch. Se o mantenedor já tiver alterado esse arquivo, fazer integração consciente, sem sobrescrever seu trabalho. Executar os testes de identidade, recusa, expiração/revogação e integração Core. As 39 verificações desta entrega usam WordPress real e HTTP simulado; não comprovam homologação Google comercial.

Arquivo original SHA-256: 0f9a232f9b3c46ccb6dbb4b5261c3d623c73a072e01ff9335715974df6b089ef
Arquivo alterado SHA-256: 9023ad782ec40f1734e1695f163fafbf96e752b7c0d5247808775c50d0027545

Teste reproduzível e ambiente completos no fonte Core em tests/google-bound-1410.php e google-dependency/. Não há publicação, alteração de versão Google nem instalação remota nesta rodada.
