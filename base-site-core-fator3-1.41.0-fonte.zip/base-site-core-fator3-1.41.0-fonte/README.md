# Fator3 Site Core 1.41.0 — fonte

Código em work/plugin/base-site-core-fator3/. Instruções em build/README.md. Consulte o relatório: entrega com pendências de homologação e navegador disponível; servidor exige incorporação da extensão Google e homologação. As pendências constam no relatório. Este ZIP não é instalável no WordPress.
