# Fator3 MCP 0.55.0 — painel e valor padrão dos avisos técnicos

## Operar o painel no computador e no telefone

Em **Ferramentas → Fator3 MCP**, abra o grupo Operação, Configurar ou Suporte. Os endereços salvos continuam abrindo a subaba correspondente. A folha comum 1.0.0 utiliza a cor do esquema escolhido no perfil WordPress. Os avisos dos demais plugins ficam depois do cabeçalho e tabelas extensas permitem rolagem dentro do cartão. Para conferir a instalação, abra a Visão geral e leia o selo de versão. O pedido oficial de interface é **Pedidos MCP 91**. A menção a 91 na entrega anterior identificava a solicitação do Core 439.

## Conferir o contrato da carência

**Pedidos MCP 92.** Com o Site Core 1.100.1 ativo e uma conexão autorizada, leia a opção completa:

```json
{"ability_name":"f3base/config-core-ler","parameters":{"nome":"f3base_avisos_tecnicos"}}
```

Abra a opção em `opcoes.f3base_avisos_tecnicos`. Nos objetos `schema` e `schema_entrada`, confira o campo `properties.carencia_por_codigo_minutos.properties.token_vencendo.default`. Ambos devem informar o padrão em minutos como inteiro. A política padrão fornecida pelo Core indica 30. O valor efetivo pode divergir quando o administrador configura a opção. Para o mapa efetivo, consulte `valor_efetivo.carencia_por_codigo_minutos`. Somente inteiros entre 0 e 10.080, inclusive, são elegíveis nesse campo do schema. Outros nomes, tipos ou caminhos sensíveis conservam a proteção existente. O argumento `nome` faz parte da identificação da chamada.

## Instalação e recuperação

Instale em WordPress 7.1.4 ou superior com PHP 8.3 ou superior, em instalação nova ou em atualização direta da 0.54.0. Após ativar, abra uma nova requisição de `system/health` com `compact=true` e confira `plugin_version`, `healthy` e o marcador de cron. O painel e a consulta do prazo usam as permissões existentes. A atualização utiliza o schema de persistência 2 e preserva a configuração do site. Para consultar esta nota por partes, use `system/guide` com `document=release-0550` e devolva o cursor de cada página até o fim. Uma falha após a instalação exige correção em nova versão.
