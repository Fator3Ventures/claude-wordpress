# Entrega 0.55.0

Pedidos MCP 91 (padronização da interface) e 92 (valor padrão da carência no schema). Atualização direta da 0.54.0. Consulte [notas da versão](RELEASE-0550.md) e os resultados em `evidencias/0550/`. O relatório externo identifica os ZIPs finais.
