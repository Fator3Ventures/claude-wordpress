# Fator3 MCP 0.55.0 — fonte

WordPress >= 7.1.4 e PHP >= 8.3. Base direta 0.54.0. Runtime em fontes/wp-mcp-fator3. Em uma cópia de desenvolvimento, rode python3 tools/sync_docs.py e python3 tools/build_packages.py --out dist. O catálogo canônico é exportado a partir do WordPress com tools/release0390/contracts.php. Ensaios e instruções em tools/release0550, resultados em evidencias/0550. python3 tools/pack_source.py empacota o fonte após a cópia interna do relatório.
