<?php
/** Exact, generated ownership inventory. Never returns option values or credentials. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Estado_Inventario {
    const TERCEIROS=array('f3base_journal','f3base_log','f3base_checkpoint','f3base_estado_aplicacao','f3base_fases','f3base_release','f3base_base_merge','f3base_medicoes','f3base_vereditos');
    public static function transientes(): array {
        return array(
            'f3base_(?:operacao_resultado|integracao_resultado|politica_resultado|avisos_resultado|perfil|forms)_[0-9]+'=>'Resultados e contextos administrativos; TTL de 5 minutos a 2 horas',
            'f3base_(?:retorno|clarity_retorno|form)_[a-f0-9-]{36}'=>'Rascunhos e retornos administrativos; TTL finito até 2 horas',
            'f3base_confirmacao_[a-f0-9]{32,64}'=>'Confirmação de envio; TTL de 10 minutos',
            'f3base_publico_[a-f0-9]{64}'=>'Conteúdo público; 300 segundos, orçamento de 32 entradas/8 MiB',
            'f3base_publico_geracao'=>'Token de geração; TTL de um dia',
            'f3base_llms_item_[a-f0-9]{64}'=>'Cobertura Markdown por conteúdo; TTL de um dia',
            'f3base_rl_[a-f0-9]{32}'=>'Contingência de rate limit; janela finita do endpoint',
            'f3base_dedup_[a-f0-9]{40}'=>'Deduplicação de contingência; prazo do endpoint',
            'f3base_(?:leads_migrando|retencao_recuperando|comportamento_migrando|cadencia_recuperando|vitais_limpeza)'=>'Reservas legadas do esquema atual; 1 a 60 minutos',
            'f3base_acessos_fotografia'=>'Fotografia temporária de acessos; TTL de um dia',
        );
    }
    public static function documento(): array {$p=F3BASE_PLUGIN_DIR.'dados/estado-inventario.json';return is_readable($p)?(json_decode((string)file_get_contents($p),true)?:array()):array();}
    public static function iniciar(): void {add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('estado-inventario-ler','Inventário fechado de estado, propriedade, backup, retenção e desinstalação',array(__CLASS__,'consultar')));}
    public static function consultar(): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$d=self::documento();return array('ok'=>!empty($d),'versao'=>F3BASE_PLUGIN_VERSAO,'proprietario'=>'Fator3 Site Core','inventario'=>$d,'excluidas_de_propriedade'=>self::TERCEIROS,'valores_expostos'=>false,'observacao'=>'Catálogo distribuído com a versão. Famílias dinâmicas são expressões fechadas, não autorização para apagar por prefixo. Estado dos companheiros tem inventário próprio.');
    }
    public static function apagar_transientes(): void {
        global $wpdb;$pattern='^_transient_(timeout_)?('.implode('|',array_keys(self::transientes())).')$';
        do{$names=$wpdb->get_col($wpdb->prepare('SELECT option_name FROM %i WHERE option_name REGEXP %s LIMIT 500',$wpdb->options,$pattern));if($wpdb->last_error){return;}
            foreach($names as $name){$key=preg_replace('/^_transient_(?:timeout_)?/','',$name);delete_transient($key);delete_option('_transient_'.$key);delete_option('_transient_timeout_'.$key);}
        }while(count($names)===500);
        // No enumeration or global flush in persistent object cache. Only the bounded local index is available.
        foreach((get_option(F3Base_Cache_Orcamento::OPTION,array())['entradas']??array()) as $key=>$v){if(preg_match('/^f3base_publico_[a-f0-9]{64}$/D',$key)){delete_transient($key);}}
        foreach(array('f3base_publico_geracao','f3base_acessos_fotografia','f3base_leads_migrando','f3base_retencao_recuperando','f3base_comportamento_migrando','f3base_cadencia_recuperando','f3base_vitais_limpeza') as $key){delete_transient($key);}
    }
}
