<?php
/** Closed budget for public generated content, never a global object-cache flush. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Cache_Orcamento {
    const OPTION='f3base_cache_publico_indice';
    const MAX_ENTRADAS=32;
    const MAX_BYTES=8388608;
    const METADADOS_RESERVADOS=16384;
    public static function iniciar(): void {add_action('f3base_retencao_limpeza',array(__CLASS__,'limpar'));}
    private static function indice(): array {$v=get_option(self::OPTION,array());return is_array($v)?$v:array();}
    private static function salvar(array $v): bool {return !empty(F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$v)['persisted']);}
    private static function valida(string $key): bool {return (bool)preg_match('/^f3base_publico_[a-f0-9]{64}$/D',$key);}
    public static function guardar(string $key,$valor,string $geracao): bool {
        if(!self::valida($key)){return false;}$data=array('valor'=>$valor);$bytes=strlen(serialize($data))+strlen($key)+128;
        if($bytes>F3Base_Modulo_Cache_Publico::MAX_BYTES){return false;}
        if(!F3Base_Recuperacao::entrar()){return false;}$l=F3Base_Trava::adquirir('cache-publico-orcamento',30);if(!$l){F3Base_Recuperacao::sair();return false;}
        try{
            $i=self::indice();$entries=$i['entradas']??array();$evicted=0;
            foreach($entries as $n=>$m){if(!self::valida((string)$n)){unset($entries[$n]);continue;}if(($m['expira']??0)<=time()||($m['geracao']??'')!==$geracao){delete_transient($n);unset($entries[$n]);$evicted++;}}
            unset($entries[$key]);uasort($entries,static fn($a,$b)=>($a['criado']??0)<=>($b['criado']??0));
            while(count($entries)>=self::MAX_ENTRADAS||array_sum(array_column($entries,'bytes'))+$bytes+self::METADADOS_RESERVADOS>self::MAX_BYTES){$n=array_key_first($entries);if($n===null){return false;}delete_transient($n);unset($entries[$n]);$evicted++;}
            $entries[$key]=array('bytes'=>$bytes,'criado'=>time(),'expira'=>time()+F3Base_Modulo_Cache_Publico::TTL,'geracao'=>$geracao);
            $i=array('entradas'=>$entries,'eviccoes'=>(int)($i['eviccoes']??0)+$evicted,'atualizado_em'=>time());
            // Durable reservation comes before cache write, including when cache is external.
            if(strlen(serialize($i))>self::METADADOS_RESERVADOS||!self::salvar($i)){return false;}
            if($geracao!==F3Base_Modulo_Cache_Publico::geracao()){unset($i['entradas'][$key]);self::salvar($i);return false;}
            if(!set_transient($key,$data,F3Base_Modulo_Cache_Publico::TTL)){unset($i['entradas'][$key]);self::salvar($i);return false;}return true;
        }finally{F3Base_Trava::liberar($l);F3Base_Recuperacao::sair();}
    }
    public static function limpar(): array {
        $l=F3Base_Trava::adquirir('cache-publico-orcamento',30);if(!$l){return array('ok'=>true,'codigo'=>'reserva_ocupada');}
        try{
            global $wpdb;$i=self::indice();$entries=$i['entradas']??array();$removed=0;$g=get_transient(F3Base_Modulo_Cache_Publico::GERACAO);
            foreach($entries as $key=>$m){if(!self::valida((string)$key)){unset($entries[$key]);continue;}if(($m['expira']??0)<=time()||($m['geracao']??'')!==$g||get_transient($key)===false){delete_transient($key);unset($entries[$key]);$removed++;}}
            uasort($entries,static fn($a,$b)=>($a['criado']??0)<=>($b['criado']??0));
            while(count($entries)>self::MAX_ENTRADAS||array_sum(array_column($entries,'bytes'))+self::METADADOS_RESERVADOS>self::MAX_BYTES){$key=array_key_first($entries);if($key===null){break;}delete_transient($key);unset($entries[$key]);$removed++;}
            // Exact SHA-256 family: bounded SQL scan also removes old DB residues after a backend switch.
            $names=$wpdb->get_col($wpdb->prepare("SELECT option_name FROM %i WHERE option_name REGEXP '^_transient_(timeout_)?f3base_publico_[a-f0-9]{64}$' ORDER BY option_id LIMIT 256",$wpdb->options));
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'cache_inventario_indisponivel');}
            foreach($names as $name){$key=preg_replace('/^_transient_(?:timeout_)?/','',$name);if(isset($entries[$key])){continue;}
                delete_transient($key);delete_option('_transient_'.$key);delete_option('_transient_timeout_'.$key);$removed++;
            }
            $timeout=get_option('_transient_timeout_'.F3Base_Modulo_Cache_Publico::GERACAO,0);
            if((get_option('_transient_'.F3Base_Modulo_Cache_Publico::GERACAO,false)!==false&&(!$timeout||(int)$timeout<time()))||($timeout&&get_option('_transient_'.F3Base_Modulo_Cache_Publico::GERACAO,false)===false)){delete_option('_transient_'.F3Base_Modulo_Cache_Publico::GERACAO);delete_option('_transient_timeout_'.F3Base_Modulo_Cache_Publico::GERACAO);}
            $i=array('entradas'=>$entries,'eviccoes'=>(int)($i['eviccoes']??0)+$removed,'atualizado_em'=>time());$ok=self::salvar($i);
            if(count($names)===256){F3Base_Fila::agendar('f3base_cache_podar',time()+60);}
            return array('ok'=>$ok,'removidas'=>$removed,'saldo'=>count($names)===256?1:0);
        }finally{F3Base_Trava::liberar($l);}
    }
    public static function resumo(): array {
        $i=self::indice();$entries=$i['entradas']??array();$bytes=array_sum(array_column($entries,'bytes'))+strlen(serialize($i));
        return array('backend'=>wp_using_ext_object_cache()?'object_cache':'options','entradas_reservadas'=>count($entries),'bytes_reservados_e_metadados'=>$bytes,'teto_entradas'=>self::MAX_ENTRADAS,'teto_bytes'=>self::MAX_BYTES,'reserva_metadados_bytes'=>self::METADADOS_RESERVADOS,'teto_entrada_bytes'=>F3Base_Modulo_Cache_Publico::MAX_BYTES,'ttl_segundos'=>300,'geracao_ttl_segundos'=>DAY_IN_SECONDS,'eviccoes'=>$i['eviccoes']??0,'ultima_manutencao_em'=>$i['atualizado_em']??null,'familia'=>'f3base_publico_<sha256>','cobertura'=>'Índice próprio de reservas; inclui envelope, nomes e margem de metadados. Não mede overhead interno do backend. Chaves externas à família não são inspecionadas. A geração é um único token separado com TTL de um dia. Chaves não indexadas de object cache anterior vencem em até 300 segundos.');
    }
}
