<?php
/** Read-only inspection of saved content and resolved reusable components. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conteudo_Instrumentacao {
    public static function iniciar(): void {add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('conteudo-instrumentacao-ler','Auditoria de seções, CTAs e formulários do conteúdo publicado',array(__CLASS__,'consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>25),'tipo'=>array('type'=>'string','enum'=>array('page','post')),'post_id'=>array('type'=>'integer','minimum'=>1))));}
    public static function consultar($e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$e=is_array($e)?$e:array();$lim=max(1,min(25,(int)($e['limite']??10)));$pag=max(1,(int)($e['pagina']??1));
        $args=array('post_type'=>isset($e['tipo'])&&in_array($e['tipo'],array('page','post'),true)?$e['tipo']:array('page','post'),'post_status'=>'publish','has_password'=>false,'posts_per_page'=>$lim,'paged'=>$pag,'orderby'=>'ID','order'=>'ASC');if(!empty($e['post_id'])){$args['p']=(int)$e['post_id'];}
        $q=new WP_Query($args);$lines=array();foreach($q->posts as $p){$lines[]=self::analisar($p);}
        return array('ok'=>true,'fonte'=>'conteudo_salvo_e_componentes_resolvidos','somente_leitura'=>true,'pagina'=>$pag,'proxima_pagina'=>$q->max_num_pages>$pag?$pag+1:null,'total_conteudos'=>(int)$q->found_posts,'linhas'=>$lines,'limites'=>array('blocos_por_conteudo'=>2000,'profundidade'=>12),'cobertura'=>'Inspeção do conteúdo salvo, blocos sincronizados e template parts referenciados. Não é renderização da página nem prova visual. Componentes dinâmicos e templates adicionados pelo tema fora do conteúdo têm cobertura explicitamente incompleta. Não altera tema nem gera visita.');
    }
    public static function analisar(WP_Post $p): array {
        $r=array('post_id'=>$p->ID,'tipo'=>$p->post_type,'url'=>get_permalink($p),'primeiro_nivel_sem_secao'=>array(),'secoes_aninhadas'=>array(),'secoes_repetidas'=>array(),'textos_whatsapp_repetidos'=>array(),'formularios'=>array(),'conflitos_superficie'=>array(),'componentes_nao_inspecionados'=>array(),'componentes_resolvidos'=>array(),'blocos_examinados'=>0);
        $seen=array();$texts=array();self::blocos(parse_blocks($p->post_content),array(),array(),0,$r,$seen,$texts,'conteudo');
        foreach($seen as $name=>$paths){if(count($paths)>1){$r['secoes_repetidas'][]=array('secao'=>$name,'ocorrencias'=>$paths);}}
        foreach($texts as $text=>$paths){if(count($paths)>1){$r['textos_whatsapp_repetidos'][]=array('texto'=>$text,'ocorrencias'=>$paths);}}
        $intro=array();foreach($r['formularios'] as $f){if($f['regime']==='whatsapp'&&$f['texto_efetivo']!==''){$intro[$f['texto_efetivo']][]=$f['caminho'].'@'.$f['id'];}}$r['introducoes_whatsapp_repetidas']=array();foreach($intro as $text=>$paths){if(count($paths)>1){$r['introducoes_whatsapp_repetidas'][]=array('texto'=>$text,'ocorrencias'=>$paths);}}
        $r['cobertura_completa']=empty($r['componentes_nao_inspecionados']);$r['composicao_tema_inspecionada']=false;return $r;
    }
    private static function blocos(array $blocks,array $parents,array $refs,int $depth,array &$r,array &$seen,array &$texts,string $base): void {
        foreach($blocks as $i=>$b){$path=$base.'.'.$i;if(++$r['blocos_examinados']>2000||$depth>12){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'limite_de_inspecao');return;}
            if(empty($b['blockName'])&&trim($b['innerHTML']??'')===''){continue;}$attr=$b['attrs']??array();$class=(string)($attr['className']??'');$names=array();preg_match_all('/(?:^|\s)f3base-secao-([a-z][a-z0-9_-]{0,79})(?=\s|$)/',$class,$matches);$names=$matches[1];
            if(($b['blockName']??'')==='f3base/formulario'&&!empty($attr['secao'])&&preg_match('/^[a-z][a-z0-9_-]{0,79}$/D',(string)$attr['secao'])){$names[]=$attr['secao'];}
            $names=array_values(array_unique($names));if(!$parents&&$depth===0&&!$names){$r['primeiro_nivel_sem_secao'][]=array('caminho'=>$path,'bloco'=>$b['blockName']??'html');}
            foreach($names as $n){$seen[$n][]=$path;if($parents){$r['secoes_aninhadas'][]=array('secao'=>$n,'ancestrais'=>$parents,'caminho'=>$path);}}
            if(($b['blockName']??'')==='f3base/formulario'){self::formulario((string)($attr['id']??''),$r,$path);}
            // innerHTML omits the child block markup: no double counting across nesting.
            self::links((string)($b['innerHTML']??''),$texts,$path,$r);self::shortcodes((string)($b['innerHTML']??''),$r,$path);
            $kind=$b['blockName']??'';$ref='';$content=null;
            if($kind==='core/block'){$ref='bloco:'.(int)($attr['ref']??0);$obj=get_post((int)($attr['ref']??0));if($obj&&$obj->post_type==='wp_block'&&$obj->post_status==='publish'&&!$obj->post_password){$content=$obj->post_content;}}
            elseif($kind==='core/template-part'){$ref='parte:'.($attr['theme']??get_stylesheet()).'//'.($attr['slug']??'');$obj=get_block_template(substr($ref,6),'wp_template_part');if($obj&&($obj->status??'publish')==='publish'){$content=$obj->content;}}
            if($ref!==''){
                if(in_array($ref,$refs,true)){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'ciclo','componente'=>$ref);}
                elseif($content===null){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'referencia_indisponivel','componente'=>$ref);}
                else{$r['componentes_resolvidos'][]=$ref;self::blocos(parse_blocks($content),array_merge($parents,$names),array_merge($refs,array($ref)),$depth+1,$r,$seen,$texts,$path.'@'.$ref);}
            }else{$type=WP_Block_Type_Registry::get_instance()->get_registered($kind);if($type&&$type->is_dynamic()&&!in_array($kind,array('f3base/formulario','core/group','core/paragraph','core/buttons','core/button'),true)){$r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'componente_dinamico','bloco'=>$kind);}}
            if(!empty($b['innerBlocks'])){self::blocos($b['innerBlocks'],array_merge($parents,$names),$refs,$depth+1,$r,$seen,$texts,$path);}
        }
    }
    private static function links(string $html,array &$texts,string $path,array &$r): void {
        if($html===''||!class_exists('DOMDocument')){return;}$dom=new DOMDocument();$old=libxml_use_internal_errors(true);$dom->loadHTML('<?xml encoding="UTF-8"><html><body>'.$html.'</body></html>',LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);
        $xp=new DOMXPath($dom);foreach($xp->query('//*[@class or @data-f3base-superficie]') as $el){$valid=array('conteudo','menu','flutuante','elementor','cabecalho','barra_fixa');$decl=array();$attr=$el->getAttribute('data-f3base-superficie');if(in_array($attr,$valid,true)&&!$el->hasAttribute('data-f3base-superficie-inferida')){$decl[]=$attr;}preg_match_all('/(?:^|\s)f3base-superficie-([a-z_]+)(?=\s|$)/',$el->getAttribute('class'),$m);$decl=array_values(array_unique(array_merge($decl,array_intersect($m[1],$valid))));if(count($decl)>1){$r['conflitos_superficie'][]=array('caminho'=>$path,'elemento'=>$el->tagName,'valores'=>$decl,'regra'=>'atributo explícito, depois primeira classe válida; corrigir conteúdo');}}
        foreach($dom->getElementsByTagName('a') as $node){$url=$node->getAttribute('href');$d=F3Base_Leads_Contexto::destino($url);if(empty($d['valido'])||($d['tipo']??'')!=='whatsapp'){continue;}$text=trim(preg_replace('/\s+/u',' ',$node->textContent));if($text!==''){$texts[$text][]=$path;}}
    }
    private static function shortcodes(string $content,array &$r,string $path): void {if(preg_match_all('/\[f3base_formulario\b([^\]]*)\]/',$content,$m)){foreach($m[1] as $x){$a=shortcode_parse_atts($x);self::formulario((string)($a['id']??''),$r,$path.'@shortcode');}}}
    private static function formulario(string $id,array &$r,string $path): void {
        foreach(F3Base_Options::ler('f3base_formularios') as $f){if(($f['id']??'')!==$id){continue;}$cfg=F3Base_Options::ler('f3base_contato');$own=trim((string)($f['mensagem_whatsapp']??''));$r['formularios'][]=array('id'=>$id,'caminho'=>$path,'regime'=>$f['regime'],'texto_efetivo'=>$own!==''?$own:trim((string)($cfg['mensagem_padrao']??'')),'herdado'=>$own==='','continuacao_automatica'=>!empty($f['whatsapp_automatico']));return;}
        $r['componentes_nao_inspecionados'][]=array('caminho'=>$path,'motivo'=>'formulario_ausente','id'=>$id);
    }
}
