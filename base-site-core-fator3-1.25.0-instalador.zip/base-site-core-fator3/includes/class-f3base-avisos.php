<?php
/** Independent durable Slack delivery. An HTTP timeout is not proof of non-delivery. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Avisos {
    const EVENTO='f3base_avisos_processar';
    const SEGREDO='f3base_slack_webhook';
    const ESTADOS=array('pendente','reservado','enviando','entregue','falhou','incerto','cancelado','suprimido','suspenso');
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_avisos_fila';}
    public static function catalogo(array $c): array {
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>array('canal'=>array('type'=>'string','enum'=>array('email','slack','ambos'))));
        $c['f3base_avisos']=array('rotulo'=>'Canal dos avisos internos','descricao'=>'E-mail, Slack ou ambos; novas capturas guardam a escolha. Regras de clique e formulário são comuns. Contatos anteriores não são reenviados ao mudar o canal.','operavel'=>true,'campo'=>'grupo','padrao'=>array('canal'=>'email'),'autoload'=>false,'sanitiza'=>static fn($v,$p)=>is_array($v)?array_replace($p,$v):$p,'schema_config'=>$schema,'schema_entrada'=>$schema,'recusa'=>static fn($v)=>is_wp_error(rest_validate_value_from_schema($v,$schema))?'Escolha E-mail, Slack ou Ambos.':'');
        return $c;
    }
    public static function url_valida(string $url): bool {
        $p=wp_parse_url($url);return is_array($p)&&($p['scheme']??'')==='https'&&($p['host']??'')==='hooks.slack.com'&&!isset($p['port'])&&!isset($p['user'])&&!isset($p['pass'])&&!isset($p['query'])&&!isset($p['fragment'])&&(bool)preg_match('~^/services/[A-Za-z0-9]+/[A-Za-z0-9]+/[A-Za-z0-9]+$~D',$p['path']??'');
    }
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE $t (
 chave char(64) NOT NULL,
 record_id char(32) NOT NULL,
 destino char(64) NOT NULL,
 ciclo int unsigned NOT NULL DEFAULT 1,
 estado varchar(16) NOT NULL DEFAULT 'pendente',
 codigo varchar(64) NOT NULL DEFAULT '',
 payload longtext NOT NULL,
 tentativas smallint unsigned NOT NULL DEFAULT 0,
 proxima bigint unsigned NOT NULL DEFAULT 0,
 criada_em bigint unsigned NOT NULL,
 atualizada_em bigint unsigned NOT NULL,
 enviada_em bigint unsigned NOT NULL DEFAULT 0,
 reserva char(36) NOT NULL DEFAULT '',
 reserva_ate bigint unsigned NOT NULL DEFAULT 0,
 lote char(36) NOT NULL DEFAULT '',
 contingencia varchar(32) NOT NULL DEFAULT '',
 classe varchar(16) NOT NULL DEFAULT 'nao_marcado',
 autor bigint unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (chave),
 UNIQUE KEY contato_ciclo (record_id,ciclo),
 KEY vencidas (estado,proxima),
 KEY destino (destino,enviada_em)
) ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function iniciar(): void {
        add_action('f3base_lead_persistido',array(__CLASS__,'capturado'));
        add_action('f3base_lead_eliminando',static fn($id)=>self::cancelar($id));
        add_action(self::EVENTO,array(__CLASS__,'processar'));add_action('f3base_leads_resumo',array(__CLASS__,'recuperar'));
        add_action('f3base_retencao_limpeza',array(__CLASS__,'podar'));
        add_action('admin_post_f3base_avisos_salvar',array(__CLASS__,'salvar'));
        add_action('admin_post_f3base_avisos_reenviar',array(__CLASS__,'reenviar_tela'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('avisos-fila-ler','Avisos Slack e contingência por e-mail, sem payload nem segredo',array(__CLASS__,'consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'estado'=>array('type'=>'string','enum'=>self::ESTADOS)));
            F3Base_Servicos::ability('avisos-reenviar','Prévia e reenvio explícito de aviso Slack; incerto exige aceite de duplicação',array(__CLASS__,'reenviar'),array('chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true),'aceitar_possivel_duplicacao'=>array('type'=>'boolean'),'usar_destino_atual'=>array('type'=>'boolean')),array('chave'),false);
        });
    }
    public static function intencao(bool $elegivel): array {
        $canal=F3Base_Options::ler('f3base_avisos')['canal']??'email';return array('canal'=>$canal,'elegivel'=>$elegivel,'ciclo'=>1,'destino'=>F3Base_Options::revisao(self::SEGREDO));
    }
    private static function cifrar(array $a): string {$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return 'f3av:v1:'.base64_encode($nonce.sodium_crypto_secretbox(wp_json_encode($a),$nonce,hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:avisos:v1')));}
    private static function abrir(string $c): ?array {if(!str_starts_with($c,'f3av:v1:')){return null;}$r=base64_decode(substr($c,8),true);if(!$r||strlen($r)<40){return null;}try{$x=sodium_crypto_secretbox_open(substr($r,24),substr($r,0,24),hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:avisos:v1'));$a=$x!==false?json_decode($x,true):null;return is_array($a)?$a:null;}catch(Throwable $e){return null;}}
    private static function texto(string $s): string {return str_replace(array('&','<','>'),array('&amp;','&lt;','&gt;'),preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/u','',$s));}
    public static function payload(array $lead): array {
        $a=F3Base_Contato_Apresentacao::montar($lead,false);$sections=F3Base_Contato_Apresentacao::secoes($a);$test=($lead['classe_trafego']??'')==='teste';
        $title=($test?'[TESTE] ':'').get_bloginfo('name').' · '.F3Base_Relatorios::rotulo((string)$lead['metodo']).' · '.($lead['nome']?:'Visitante');$title=preg_replace('/\s+/u',' ',wp_strip_all_tags($title));
        $blocks=array(array('type'=>'header','text'=>array('type'=>'plain_text','text'=>mb_substr($title,0,150),'emoji'=>false)));$cut=false;
        foreach(array('Contato','Acontecimento','Origem') as $section){$text='*'.$section."*\n";foreach($sections[$section]??array() as $k=>$v){$line=self::texto((string)$k).': '.self::texto(is_array($v)?implode("\n",array_map(static fn($v)=>is_scalar($v)?(string)$v:'',(array)$v)):(string)$v)."\n";
                while(mb_strlen($text.$line)>2900){$space=max(1,2900-mb_strlen($text));$text.=mb_substr($line,0,$space);$line=mb_substr($line,$space);$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>$text,'verbatim'=>true));$text='';if(count($blocks)>=18){$cut=true;break 2;}}
                $text.=$line;}
            if(!$cut&&$text!==''){$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>$text,'verbatim'=>true));}if(count($blocks)>=18){$cut=true;break;}}
        if($cut){$blocks[]=array('type'=>'section','text'=>array('type'=>'plain_text','text'=>'Resumo limitado. Consulte o registro para ver os demais dados.'));}
        $url=admin_url('admin.php?page=f3base-leads&record_id='.$lead['record_id']);$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>'<'.self::texto($url).'|Consultar contato no WordPress>','verbatim'=>true));
        return array('text'=>mb_substr(self::texto($title),0,500),'blocks'=>array_slice($blocks,0,20),'unfurl_links'=>false,'unfurl_media'=>false,'link_names'=>false);
    }
    public static function capturado(array $lead): void {try{self::enfileirar($lead);}catch(Throwable $e){/* The intent remains in the saved lead for bounded recovery. */}}
    private static function enfileirar(array $lead,int $ciclo=1,?string $destino=null): bool {
        $i=$lead['dados']['aviso_intencao']??array();if(empty($i['elegivel'])||!in_array($i['canal']??'',array('slack','ambos'),true)||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])||$lead['captura']==='suspeito'){return false;}
        $destino=$destino??($i['destino']??'');$key=hash('sha256',$lead['record_id'].'|slack|'.$ciclo);$test=$lead['classe_trafego']==='teste';$state=$test&&F3Base_Testes::politica('slack','teste')==='suprimir'?'suprimido':(!empty($i['reconciliacao_necessaria'])&&$ciclo===1?'suspenso':'pendente');
        global $wpdb;$row=array('chave'=>$key,'record_id'=>$lead['record_id'],'destino'=>$destino,'ciclo'=>$ciclo,'estado'=>$state,'codigo'=>$state==='suprimido'?'suprimido_teste':($state==='suspenso'?'restauracao_requer_reconciliacao':'intencao_recebida'),'payload'=>self::cifrar(self::payload($lead)),'proxima'=>time(),'criada_em'=>time(),'atualizada_em'=>time(),'classe'=>$lead['classe_trafego'],'autor'=>$ciclo>1?get_current_user_id():0);
        $old=$wpdb->suppress_errors(true);try{$ok=$wpdb->insert(self::tabela(),$row);if(!$ok){return (bool)$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE chave=%s',self::tabela(),$key));}}finally{$wpdb->suppress_errors($old);}
        if($state==='pendente'){F3Base_Fila::agendar(self::EVENTO);}return true;
    }
    public static function recuperar(): array {
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}
        global $wpdb;try{$rows=$wpdb->get_col($wpdb->prepare("SELECT l.record_id FROM %i l LEFT JOIN %i q ON q.record_id=l.record_id AND q.ciclo=1 WHERE q.chave IS NULL AND l.lixeira=0 AND l.eliminacao_pendente=0 AND l.criado_em>=%s AND JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(l.dados),l.dados,'{}'),'$.aviso_intencao.elegivel'))='true' AND JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.aviso_intencao.canal')) IN ('slack','ambos') ORDER BY l.id LIMIT 50",F3Base_Leads_Repositorio::tabela(),self::tabela(),gmdate('Y-m-d H:i:s',time()-90*DAY_IN_SECONDS)));$ok=!$wpdb->last_error;
            foreach($rows??array() as $id){$r=F3Base_Leads_Repositorio::obter($id);if($r){$ok=self::enfileirar($r)&&$ok;}}
            self::agendar_proxima();return array('ok'=>$ok,'recuperadas'=>count($rows??array()));
        }finally{F3Base_Recuperacao::sair();}
    }
    private static function linha(string $key): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);}
    private static function revisao(array $r): string {return hash('sha256',wp_json_encode(array($r['chave'],$r['estado'],$r['tentativas'],$r['atualizada_em'],$r['contingencia'])));}
    private static function agendar_proxima(): void {global $wpdb;$at=$wpdb->get_var($wpdb->prepare("SELECT MIN(CASE WHEN estado='pendente' THEN proxima ELSE reserva_ate END) FROM %i WHERE estado IN ('pendente','reservado','enviando')",self::tabela()));if($at!==null){F3Base_Fila::agendar(self::EVENTO,max(time()+1,(int)$at));}}
    private static function terminar(array $rows,string $state,string $code,int $next=0): bool {
        global $wpdb;$ok=true;foreach($rows as $r){$n=$wpdb->update(self::tabela(),array('estado'=>$state,'codigo'=>$code,'proxima'=>$next,'atualizada_em'=>time(),'reserva'=>'','reserva_ate'=>0),array('chave'=>$r['chave'],'reserva'=>$r['reserva'],'estado'=>$r['estado']));$ok=$n===1&&$ok;if($n===1&&in_array($state,array('falhou','incerto'),true)){self::contingencia($r['chave']);}}return $ok;
    }
    private static function contingencia(string $key): void {
        global $wpdb;$r=self::linha($key);if(!$r||$r['contingencia']!==''||!in_array($r['estado'],array('falhou','incerto'),true)){return;}$lead=F3Base_Leads_Repositorio::obter($r['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){return;}
        if($wpdb->update(self::tabela(),array('contingencia'=>'reservada'),array('chave'=>$key,'contingencia'=>''))!==1){return;}
        if(in_array($lead['aviso'],array('processado','resumo_processado','enviando','incerto'),true)){$result='email_ja_processado_ou_incerto';}
        else{
            if(in_array($lead['aviso'],array('slack','suprimido_teste'),true)){$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('aviso'=>'pendente'),array('record_id'=>$lead['record_id'],'aviso'=>$lead['aviso'],'eliminacao_pendente'=>0));}
            $result=F3Base_Leads_Notificacoes::enviar($lead['record_id'])['codigo']??'email_nao_confirmado';
        }
        $wpdb->update(self::tabela(),array('contingencia'=>substr($result,0,32)),array('chave'=>$key,'contingencia'=>'reservada'));
    }
    public static function processar(): array {
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('avisos-slack-envio',45);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>true,'codigo'=>'reserva_ocupada');}
        global $wpdb;try{
            $expired=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('reservado','enviando') AND reserva_ate<%d LIMIT 50",self::tabela(),time()),ARRAY_A);
            foreach($expired??array() as $row){self::terminar(array($row),$row['estado']==='enviando'?'incerto':'pendente',$row['estado']==='enviando'?'resposta_nao_confirmada':'reserva_expirada',time());}
            $r=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' AND proxima<=%d ORDER BY proxima,criada_em,chave LIMIT 1",self::tabela(),time()),ARRAY_A);if(!$r){return array('ok'=>!$wpdb->last_error,'examinados'=>0);}
            $lead=F3Base_Leads_Repositorio::obter($r['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){self::cancelar($r['record_id']);return array('ok'=>true,'codigo'=>'cancelado');}
            $lease=wp_generate_uuid4();$rows=array($r);
            if($r['codigo']==='aguarda_resumo'){$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' AND codigo='aguarda_resumo' AND proxima<=%d AND destino=%s AND classe=%s ORDER BY criada_em,chave LIMIT 50",self::tabela(),time(),$r['destino'],$r['classe']),ARRAY_A);}
            $held=array();foreach($rows as $row){if($wpdb->update(self::tabela(),array('estado'=>'reservado','reserva'=>$lease,'reserva_ate'=>time()+45),array('chave'=>$row['chave'],'estado'=>'pendente'))===1){$row['estado']='reservado';$row['reserva']=$lease;$held[]=$row;}}
            if(!$held){return array('ok'=>true,'codigo'=>'reserva_ocupada');}$r=$held[0];
            if($r['classe']==='teste'&&F3Base_Testes::politica('slack','teste')==='suprimir'){self::terminar($held,'suprimido','suprimido_teste');return array('ok'=>true,'codigo'=>'suprimido_teste');}
            $secret=F3Base_Segredos::abrir(self::SEGREDO);if($secret===''||!self::url_valida($secret)||!hash_equals($r['destino'],F3Base_Options::revisao(self::SEGREDO))){self::terminar($held,'falhou',$secret===''?'credencial_ausente':'destino_alterado_ou_invalido');return array('ok'=>true,'codigo'=>'contingencia_email');}
            $last=(int)$wpdb->get_var($wpdb->prepare('SELECT MAX(enviada_em) FROM %i WHERE destino=%s',self::tabela(),$r['destino']));if($last>=time()){self::terminar($held,'pendente',$r['codigo'],time()+1);return array('ok'=>true,'codigo'=>'cadencia_local');}
            $hour=(int)floor(time()/HOUR_IN_SECONDS)*HOUR_IN_SECONDS;$used=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT lote) FROM %i WHERE destino=%s AND classe=%s AND enviada_em>=%d AND lote<>''",self::tabela(),$r['destino'],$r['classe'],$hour));
            if($r['codigo']!=='aguarda_resumo'&&$used>=30){self::terminar($held,'pendente','aguarda_resumo',$hour+HOUR_IN_SECONDS);return array('ok'=>true,'codigo'=>'aguarda_resumo');}
            $payload=self::abrir($r['payload']);if(!$payload){self::terminar($held,'falhou','payload_indisponivel');return array('ok'=>true,'codigo'=>'contingencia_email');}
            if($r['codigo']==='aguarda_resumo'){
                $title=($r['classe']==='teste'?'[TESTE] ':'').get_bloginfo('name').' · Resumo de '.count($held).' contatos';
                $blocks=array(array('type'=>'section','text'=>array('type'=>'plain_text','text'=>mb_substr($title,0,3000))));$text='';
                foreach($held as $row){$line='<'.self::texto(admin_url('admin.php?page=f3base-leads&record_id='.$row['record_id'])).'|Consultar contato '.substr($row['record_id'],0,8).'>';
                    if(mb_strlen($text."\n".$line)>2800&&$text!==''){$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>$text,'verbatim'=>true));$text='';}
                    if(count($blocks)>=18){$text='Demais contatos no WordPress.';break;}$text.=($text!==''?"\n":'').$line;
                }
                if($text!==''){$blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>$text,'verbatim'=>true));}
                $blocks[]=array('type'=>'section','text'=>array('type'=>'mrkdwn','text'=>'<'.self::texto(admin_url('admin.php?page=f3base-leads')).'|Consultar todos os contatos>','verbatim'=>true));
                $payload=array('text'=>self::texto($title),'blocks'=>$blocks,'unfurl_links'=>false,'unfurl_media'=>false);
            }
            // Recheck deletion immediately before handing anything to the transport.
            foreach($held as $row){$current=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$current||$current['lixeira']||$current['eliminacao_pendente']){self::terminar($held,'pendente','captura_alterada',time()+60);return array('ok'=>true,'codigo'=>'captura_alterada');}}
            foreach($held as &$row){if($wpdb->update(self::tabela(),array('estado'=>'enviando','enviada_em'=>time(),'tentativas'=>(int)$row['tentativas']+1,'lote'=>$lease),array('chave'=>$row['chave'],'reserva'=>$lease,'estado'=>'reservado'))!==1){return array('ok'=>false,'codigo'=>'envio_nao_reservado');}$row['estado']='enviando';$row['tentativas']++;}unset($row);
            try{$res=wp_safe_remote_post($secret,array('timeout'=>8,'redirection'=>0,'sslverify'=>true,'headers'=>array('Content-Type'=>'application/json; charset=utf-8'),'body'=>wp_json_encode($payload),'limit_response_size'=>1024));}
            catch(Throwable $e){$res=new WP_Error('transporte_incerto');}
            $state='incerto';$code='resposta_nao_confirmada';$next=0;
            if(!is_wp_error($res)){$http=(int)wp_remote_retrieve_response_code($res);if($http===200&&trim(wp_remote_retrieve_body($res))==='ok'){$state='entregue';$code='slack_confirmou';}
                elseif($http===429){$state='pendente';$code='limite_slack';$retry=wp_remote_retrieve_header($res,'retry-after');$delay=ctype_digit((string)$retry)?(int)$retry:max(1,(int)strtotime((string)$retry)-time());$next=time()+max(1,$delay);}
                elseif($http>=500&&$http<=599){$state='pendente';$code='slack_indisponivel';$next=time()+min(3600,60*2**min(5,(int)$held[0]['tentativas']-1));}
                elseif($http>=300&&$http<=499){$state='falhou';$code='slack_recusou';}}
            if($state==='pendente'&&(int)$held[0]['tentativas']>=5){$state='falhou';$code='tentativas_esgotadas';$next=0;}
            $saved=self::terminar($held,$state,$code,$next);return array('ok'=>$saved,'codigo'=>$saved?$code:'resultado_nao_persistido_entrega_incerta','examinados'=>count($held),'estado'=>$state);
        }finally{self::agendar_proxima();F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function cancelar(string $id): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET estado='cancelado',codigo='contato_eliminado',payload='',reserva='',reserva_ate=0,atualizada_em=%d WHERE record_id=%s",self::tabela(),time(),$id))!==false;}
    public static function suspender(): bool {global $wpdb;return $wpdb->query($wpdb->prepare("UPDATE %i SET estado='suspenso',codigo='reinstalacao_requer_reconciliacao',reserva='',reserva_ate=0 WHERE estado IN ('pendente','reservado','enviando','incerto')",self::tabela()))!==false;}
    public static function podar(): void {global $wpdb;$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE estado IN ('entregue','falhou','incerto','cancelado','suprimido') AND atualizada_em<%d LIMIT 500",self::tabela(),time()-90*DAY_IN_SECONDS));}
    public static function resumo(): array {global $wpdb;$old=$wpdb->suppress_errors(true);$rows=$wpdb->get_results($wpdb->prepare('SELECT estado,contingencia,COUNT(*) quantidade,MIN(criada_em) primeira_em FROM %i GROUP BY estado,contingencia',self::tabela()),ARRAY_A);$ok=!$wpdb->last_error;$wpdb->suppress_errors($old);return array('ok'=>$ok,'canal'=>F3Base_Options::ler('f3base_avisos')['canal']??'email','segredo'=>F3Base_Segredos::status(self::SEGREDO),'contagens'=>$rows?:array(),'proxima_execucao'=>wp_next_scheduled(self::EVENTO)?:null,'prazo'=>'Até um minuto depende de executor nessa cadência e dos limites externos; WP-Cron por visita não garante prazo.','retencao_terminal_dias'=>90,'limite_externo'=>'Webhook não confirma idempotência nem permite apagar mensagens já entregues.');}
    public static function consultar($e=array()): array {if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$e=is_array($e)?$e:array();global $wpdb;$where='1=1';$args=array(self::tabela());if(!empty($e['estado'])){if(!in_array($e['estado'],self::ESTADOS,true)){return array('ok'=>false,'codigo'=>'estado_invalido');}$where.=' AND estado=%s';$args[]=$e['estado'];}$pag=max(1,(int)($e['pagina']??1));$args[]=($pag-1)*50;$rows=$wpdb->get_results($wpdb->prepare("SELECT chave,record_id,ciclo,estado,codigo,tentativas,proxima,criada_em,atualizada_em,contingencia,classe,autor FROM %i WHERE $where ORDER BY criada_em DESC,chave LIMIT 51 OFFSET %d",$args),ARRAY_A);$ok=!$wpdb->last_error;$rows=$rows?:array();foreach($rows as &$r){$r['revisao']=self::revisao($r);}unset($r);return array('ok'=>$ok,'saude'=>self::resumo(),'pagina'=>$pag,'proxima_pagina'=>count($rows??array())>50?$pag+1:null,'linhas'=>array_slice($rows??array(),0,50));}
    public static function reenviar($e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$r=self::linha((string)($e['chave']??''));if(!$r||!in_array($r['estado'],array('falhou','incerto','suspenso'),true)){return array('ok'=>false,'codigo'=>'estado_nao_reenviavel');}
        $rev=self::revisao($r);$changed=!hash_equals($r['destino'],F3Base_Options::revisao(self::SEGREDO));if($e['simular']??true){return array('ok'=>true,'simulado'=>true,'revisao'=>$rev,'exige_aceite_duplicacao'=>in_array($r['estado'],array('incerto','suspenso'),true),'exige_destino_atual'=>$changed,'proximo_ciclo'=>(int)$r['ciclo']+1);}
        if(!hash_equals($rev,(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'conflito');}if(in_array($r['estado'],array('incerto','suspenso'),true)&&empty($e['aceitar_possivel_duplicacao'])){return array('ok'=>false,'codigo'=>'aceite_duplicacao_necessario');}if($changed&&empty($e['usar_destino_atual'])){return array('ok'=>false,'codigo'=>'destino_alterado_exige_confirmacao');}
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}try{$lead=F3Base_Leads_Repositorio::obter($r['record_id']);$ok=$lead&&self::enfileirar($lead,(int)$r['ciclo']+1,F3Base_Options::revisao(self::SEGREDO));return array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$ok?'novo_ciclo_agendado':'intencao_nao_persistida');}finally{F3Base_Recuperacao::sair();}
    }
    public static function salvar(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-avisos');$canal=sanitize_key($_POST['canal']??'');$token=trim((string)wp_unslash($_POST['credencial']??''));$r=array('ok'=>false,'codigo'=>'canal_invalido');
        if(in_array($canal,array('email','slack','ambos'),true)&&($token===''||self::url_valida($token))){$r=F3Base_Options::pelo_canal('tela',static function()use($canal,$token){if($token!==''||!empty($_POST['apagar'])){$s=F3Base_Options::gravar(self::SEGREDO,!empty($_POST['apagar'])?'':$token,F3Base_Options::ORIGEM_MANUAL,(string)($_POST['segredo_revisao']??''));if(empty($s['persisted'])){return $s;}}return F3Base_Options::gravar('f3base_avisos',array('canal'=>$canal),F3Base_Options::ORIGEM_MANUAL,(string)($_POST['revisao']??''));});}
        elseif($token!==''){$r['codigo']='webhook_invalido';}set_transient('f3base_avisos_resultado_'.get_current_user_id(),array('ok'=>!empty($r['persisted']),'codigo'=>$r['codigo']??'gravacao_nao_confirmada'),300);wp_safe_redirect(admin_url('admin.php?page=f3base-integracoes&integracao=avisos'));exit;
    }
    public static function reenviar_tela(): void {if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-avisos-reenviar');$r=self::reenviar(array('chave'=>sanitize_text_field($_POST['chave']??''),'revisao'=>sanitize_text_field($_POST['revisao']??''),'simular'=>false,'aceitar_possivel_duplicacao'=>!empty($_POST['aceitar_possivel_duplicacao']),'usar_destino_atual'=>!empty($_POST['usar_destino_atual'])));set_transient('f3base_avisos_resultado_'.get_current_user_id(),array_intersect_key($r,array_flip(array('ok','codigo'))),300);wp_safe_redirect(admin_url('admin.php?page=f3base-integracoes&integracao=avisos'));exit;}
    public static function render(): void {
        $f=F3Base_Options::fotografia('f3base_avisos');$result=get_transient('f3base_avisos_resultado_'.get_current_user_id());if($result){echo '<p role="status">'.esc_html(($result['ok']?'Concluído: ':'Atenção: ').$result['codigo']).'</p>';delete_transient('f3base_avisos_resultado_'.get_current_user_id());}
        echo '<h2>Avisos de novos contatos</h2><p>Escolha onde sua equipe recebe as próximas capturas. As regras de clique e formulário em Configurações → Contato valem para todos os canais; anúncio nativo aceito segue a regra de formulário. Registros antigos conservam o destino.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_avisos_salvar"><input type="hidden" name="revisao" value="'.esc_attr($f['revisao']).'"><input type="hidden" name="segredo_revisao" value="'.esc_attr(F3Base_Options::revisao(self::SEGREDO)).'">';wp_nonce_field('f3base-avisos');echo '<p><label>Canal <select name="canal">';foreach(array('email'=>'E-mail','slack'=>'Slack','ambos'=>'E-mail e Slack') as $k=>$label){echo '<option value="'.$k.'" '.selected($f['valor']['canal']??'email',$k,false).'>'.esc_html($label).'</option>';}echo '</select></label></p><p><label>Webhook de entrada do Slack <input class="large-text" type="password" name="credencial" value="" autocomplete="new-password"></label></p><p>Segredo: <strong>'.esc_html(F3Base_Segredos::status(self::SEGREDO)['presente']?'definido':'ausente').'</strong>. Vazio mantém o atual; o valor nunca é reapresentado.</p><label><input type="checkbox" name="apagar" value="1"> Apagar o webhook deste site</label>';submit_button('Salvar avisos');echo '</form><details><summary>Como funciona, vantagens e limites</summary><p>O dono cria um Incoming Webhook no aplicativo Slack e cola a URL HTTPS de hooks.slack.com. O canal pertence a esse webhook. O Core cifra o segredo, grava uma intenção junto ao contato e envia pela fila, fora da resposta do formulário. Vantagem: a equipe vê contato, acontecimento e origem no canal. Limites: cron, cotas externas e rede podem atrasar a mensagem; uma resposta perdida fica incerta e exige reconciliação antes de reenviar. Em falha terminal do Slack, o aviso cai no e-mail uma vez, respeitando destinatários e política de testes. Em ambos, o e-mail já enviado não se repete. Até 30 mensagens individuais por hora/classe/destino; excesso entra no resumo da hora seguinte. A cópia já entregue ao Slack não é apagada pela eliminação local.</p><p>Configure o destino Slack de testes em Site Core → Testes. O padrão suprime; marcar identifica [TESTE]. Cadência de um minuto depende do executor; só visitas não garantem prazo.</p></details>';
        $r=self::consultar(array('pagina'=>max(1,(int)($_GET['pagina']??1))));echo '<h3>Fila e contingência</h3><p>'.esc_html($r['saude']['prazo']).'</p><table class="widefat striped"><thead><tr><th>Contato / ciclo</th><th>Estado</th><th>Motivo / e-mail</th><th>Horário / tentativas</th><th>Ação</th></tr></thead><tbody>';
        foreach($r['linhas'] as $row){echo '<tr><td><a href="'.esc_url(admin_url('admin.php?page=f3base-leads&record_id='.$row['record_id'])).'">'.esc_html(substr($row['record_id'],0,12)).'</a> / '.(int)$row['ciclo'].'</td><td>'.esc_html($row['estado']).'</td><td>'.esc_html($row['codigo'].' · '.($row['contingencia']?:'sem contingência')).'</td><td>'.esc_html(wp_date('d/m/Y H:i:s T',(int)$row['atualizada_em'])).' / '.(int)$row['tentativas'].'</td><td>';
            if(in_array($row['estado'],array('falhou','incerto','suspenso'),true)){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_avisos_reenviar"><input type="hidden" name="chave" value="'.esc_attr($row['chave']).'"><input type="hidden" name="revisao" value="'.esc_attr($row['revisao']).'">';wp_nonce_field('f3base-avisos-reenviar');echo '<p><label><input type="checkbox" name="aceitar_possivel_duplicacao" value="1"> Aceito possível duplicação se já entregue</label></p><p><label><input type="checkbox" name="usar_destino_atual" value="1"> Usar o webhook atual se mudou</label></p><button class="button">Criar novo ciclo</button></form>';}echo '</td></tr>';}
        echo '</tbody></table>';if(!$r['linhas']){echo '<p>Nenhum aviso Slack registrado.</p>';}if($r['proxima_pagina']){echo '<a href="'.esc_url(add_query_arg('pagina',$r['proxima_pagina'])).'">Próxima página</a>';}
        echo '<h3>Prévia sem envio</h3><form method="get"><input type="hidden" name="page" value="f3base-integracoes"><input type="hidden" name="integracao" value="avisos"><label>ID do contato <input name="previa" pattern="[a-f0-9]{32}"></label> <button class="button">Ver prévia</button></form>';$id=sanitize_text_field($_GET['previa']??'');if(preg_match('/^[a-f0-9]{32}$/D',$id)){$lead=F3Base_Leads_Repositorio::obter($id);if($lead&&!$lead['lixeira']&&!$lead['eliminacao_pendente']){$payload=self::payload($lead);echo '<div class="card"><p><strong>'.esc_html($payload['text']).'</strong></p>';foreach($payload['blocks'] as $b){echo '<p style="white-space:pre-wrap">'.esc_html($b['text']['text']??'').'</p>';}echo '</div>';}}
    }
}
