<?php
/** Aggregated, explicitly declared technical requests. Not an audience source. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Sondas_Http {
    private static ?array $pendente=null;
    private static int $status=0;
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_sondas_http';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();
        dbDelta("CREATE TABLE $t (
 dia date NOT NULL,
 chave char(64) NOT NULL,
 caminho varchar(190) NOT NULL,
 metodo varchar(8) NOT NULL,
 status smallint unsigned NOT NULL DEFAULT 0,
 classe varchar(16) NOT NULL,
 fonte varchar(32) NOT NULL,
 quantidade bigint unsigned NOT NULL DEFAULT 0,
 primeiro_em bigint unsigned NOT NULL,
 ultimo_em bigint unsigned NOT NULL,
 PRIMARY KEY  (dia,chave),
 KEY caminho (caminho)
) ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function iniciar(): void {
        add_action('init',array(__CLASS__,'preparar'),99);
        add_action('f3base_retencao_limpeza',array(__CLASS__,'podar'));
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('medicao-sondas-ler','Sondas e requisições técnicas observadas pelo WordPress',array(__CLASS__,'consultar'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1),'caminho'=>array('type'=>'string','maxLength'=>190),'metodo'=>array('type'=>'string','enum'=>array('GET','HEAD')),'status'=>array('type'=>'integer','minimum'=>0,'maximum'=>599),'classe'=>array('type'=>'string','enum'=>array('teste','nao_marcado','invalida')))));
    }
    public static function caminho(string $uri): string {
        $path=F3Base_Analise::caminho($uri);$base=wp_parse_url(home_url('/'),PHP_URL_PATH)?:'/';
        $rel='/'.ltrim(substr($path,str_starts_with($path,$base)?strlen($base):0),'/');
        if(preg_match('~^/(wp-admin|wp-content|wp-includes)(?:/|$)~i',$rel,$m)){return '/@'.strtolower($m[1]);}
        if(str_starts_with($rel,'/wp-json/')){return '/@api';}
        if(preg_match('~(?:download|arquivo|concessao|privado|token|reset|senha)~i',$rel)){return '/@rota-privada';}
        // Dynamic public paths can contain credentials too. Retain only known public permalinks.
        if($rel==='/'){return '/';}
        if(in_array(rtrim($rel,'/'),array('/robots.txt','/llms.txt','/llms-full.txt','/f3base-teste','/wp-login.php','/wp-cron.php'),true)){return rtrim($rel,'/');}
        $post_id=get_queried_object_id();if(is_singular()&&$post_id&&get_post_status($post_id)==='publish'){return F3Base_Analise::caminho((string)get_permalink($post_id));}
        return is_404()?'/@404':'/@rota-nao-editorial';
    }
    public static function preparar(): void {
        // The overwhelmingly common branch does no collector read or write.
        if(!array_key_exists('HTTP_X_F3BASE_TESTE',$_SERVER)||!in_array($_SERVER['REQUEST_METHOD']??'',array('GET','HEAD'),true)){return;}
        if(!F3Base_Testes::config()['habilitado']){return;}
        $guard=F3Base_Recuperacao::ler();if(empty($guard['ok'])||!empty($guard['pausado'])){return;}
        $r=F3Base_Testes::resolver();self::$pendente=array('metodo'=>$_SERVER['REQUEST_METHOD'],'classe'=>!empty($r['ok'])?$r['classe_trafego']:'invalida','fonte'=>!empty($r['ok'])?'cabecalho_declarado':'cabecalho_invalido');
        add_filter('status_header',static function($text,$code){self::$status=(int)$code;return $text;},PHP_INT_MAX,2);
        add_action('shutdown',array(__CLASS__,'registrar'),0);
    }
    public static function registrar(): void {
        if(self::$pendente===null){return;}$r=self::$pendente;self::$pendente=null;
        if(!F3Base_Recuperacao::entrar()){return;}
        global $wpdb;$previous=$wpdb->suppress_errors(true);
        try{
            $s=self::$status?:http_response_code();$status=is_int($s)&&$s>=100&&$s<=599?$s:0;
            $path=$r['classe']==='invalida'?'/@marca-invalida':self::caminho(wp_unslash($_SERVER['REQUEST_URI']??'/'));
            $dia=wp_date('Y-m-d');$t=self::tabela();$key=hash('sha256',wp_json_encode(array($path,$r['metodo'],$status,$r['classe'],$r['fonte'])));
            $lock=F3Base_Trava::adquirir('sondas-http',10);if(!$lock){return;}
            try{
                $n=$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE dia=%s',$t,$dia));if($wpdb->last_error){return;}
                if((int)$n>=4997&&!$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE dia=%s AND chave=%s',$t,$dia,$key))){$path='/@excedentes';$r['metodo']='';$status=0;$key=hash('sha256','overflow|'.$r['classe']);}
                $wpdb->query($wpdb->prepare('INSERT INTO %i (dia,chave,caminho,metodo,status,classe,fonte,quantidade,primeiro_em,ultimo_em) VALUES (%s,%s,%s,%s,%d,%s,%s,1,%d,%d) ON DUPLICATE KEY UPDATE quantidade=quantidade+1,ultimo_em=VALUES(ultimo_em)',$t,$dia,$key,$path,$r['metodo'],$status,$r['classe'],$r['fonte'],time(),time()));
            }finally{F3Base_Trava::liberar($lock);}
        }catch(Throwable $e){/* Technical observation must not affect the response. */}
        finally{$wpdb->suppress_errors($previous);F3Base_Recuperacao::sair();}
    }
    public static function podar(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia<%s LIMIT 5000',self::tabela(),wp_date('Y-m-d',time()-90*DAY_IN_SECONDS)));}
    public static function consultar($e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$e=is_array($e)?$e:array();
        try{$j=F3Base_Relatorios::janela($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$where='dia BETWEEN %s AND %s';$args=array(self::tabela(),$j['de'],$j['ate']);
        foreach(array('caminho','metodo','status','classe') as $k){if(isset($e[$k])&&$e[$k]!==''){$where.=' AND '.$k.'=%s';$args[]=(string)$e[$k];}}
        $pag=max(1,(int)($e['pagina']??1));$args[]=($pag-1)*100;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT dia,caminho,metodo,status,classe,fonte,quantidade,primeiro_em,ultimo_em FROM %i WHERE $where ORDER BY dia DESC,ultimo_em DESC,chave LIMIT 101 OFFSET %d",$args),ARRAY_A);$ok=!$wpdb->last_error;
        return array('ok'=>$ok,'codigo'=>$ok?'consulta_concluida':'estrutura_ou_leitura_indisponivel','habilitado'=>F3Base_Testes::config()['habilitado'],'fonte'=>'f3base_sondas_http','unidade'=>'requisicoes_tecnicas_observadas_pelo_wordpress','periodo'=>$j,'retencao_dias'=>90,'limite_chaves_dia'=>5000,'pagina'=>$pag,'proxima_pagina'=>count($rows??array())>100?$pag+1:null,'linhas'=>array_slice($rows??array(),0,100),'cobertura'=>'Cabeçalho explícito declarativo, sem prova de autoria. Não inclui respostas de cache/CDN/arquivos servidos antes do WordPress. Pode sobrepor logs e diagnóstico 404; não somar com audiência. Status 0 é desconhecido. Rotas não editoriais são agrupadas para não guardar segredos de caminho.');
    }
    public static function render(array $e): void {
        foreach(array('metodo','classe','status') as $k){if(isset($_GET[$k])){$e[$k]=sanitize_text_field(wp_unslash($_GET[$k]));}}
        echo '<form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="tecnico"><input type="hidden" name="visao" value="sondas">';
        foreach(array('de','ate','caminho') as $k){echo '<label>'.esc_html(array('de'=>'De','ate'=>'Até','caminho'=>'Caminho')[$k]).' <input name="'.esc_attr($k).'" type="'.($k==='caminho'?'text':'date').'" value="'.esc_attr($e[$k]??'').'"></label> ';}
        foreach(array('metodo'=>array(''=>'Todos os métodos','GET'=>'GET','HEAD'=>'HEAD'),'classe'=>array(''=>'Todas as classes','teste'=>'Teste declarado','nao_marcado'=>'Não marcado','invalida'=>'Marca inválida')) as $k=>$opts){echo '<label>'.esc_html(ucfirst($k)).' <select name="'.esc_attr($k).'">';foreach($opts as $v=>$label){echo '<option value="'.esc_attr($v).'" '.selected($e[$k]??'',$v,false).'>'.esc_html($label).'</option>';}echo '</select></label> ';}
        echo '<label>Status HTTP <input type="number" min="0" max="599" name="status" value="'.esc_attr($e['status']??'').'" placeholder="Todos"></label> <button class="button">Filtrar sondas</button></form>';
        $r=self::consultar($e);echo '<p>'.esc_html($r['cobertura']??$r['codigo']).'</p>';
        if(empty($r['ok'])){echo '<p role="alert">Leitura indisponível; ausência de linhas não comprova coleta funcionando.</p>';return;}
        echo '<table class="widefat striped"><thead><tr><th>Caminho observado</th><th>Método / HTTP</th><th>Classe declarada</th><th>Quantidade</th><th>Primeiro / último horário</th></tr></thead><tbody>';
        foreach($r['linhas'] as $l){echo '<tr><td>'.esc_html($l['caminho']).'</td><td>'.esc_html($l['metodo'].' / '.($l['status']?:'desconhecido')).'</td><td>'.esc_html($l['classe']).'</td><td>'.(int)$l['quantidade'].'</td><td>'.esc_html(wp_date('d/m/Y H:i:s T',(int)$l['primeiro_em']).' — '.wp_date('d/m/Y H:i:s T',(int)$l['ultimo_em'])).'</td></tr>';}
        echo '</tbody></table>';if(!$r['linhas']){echo '<p>Nenhuma requisição técnica observada no recorte.</p>';}if($r['proxima_pagina']){echo '<a class="button" href="'.esc_url(add_query_arg('pagina',$r['proxima_pagina'])).'">Próxima página</a>';}
    }
}
