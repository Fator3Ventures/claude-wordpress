<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Erros {
    public static function mensagens(): array {static $m=null;if($m===null){$m=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'dados/erros-operacao.json'),true)?:array();}return $m;}
}
