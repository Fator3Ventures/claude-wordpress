<?php
/** Regras explicáveis de aquisição e automação. Nenhum sinal concede privilégio. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Audiencia {
    const FAIXAS_LARGURA=array('ate_359'=>359,'360_479'=>479,'480_767'=>767,'768_1023'=>1023,'1024_1439'=>1439,'1440_mais'=>PHP_INT_MAX);
    const NAVEGADORES=array('instagram','facebook','linkedin','chrome','safari','outro');
    public static function faixa_largura(int $px): string {if($px<1){return '';}foreach(self::FAIXAS_LARGURA as $nome=>$max){if($px<=$max){return $nome;}}return '';}
    public static function navegador(?string $ua=null): string {
        $ua=$ua??(string)($_SERVER['HTTP_USER_AGENT']??'');if($ua===''){return 'outro';}
        if(preg_match('/\bInstagram\b/i',$ua)){return 'instagram';}
        if(preg_match('/FBAN\/|FBAV\/|FB_IAB|FB4A|FBIOS/i',$ua)){return 'facebook';}
        if(stripos($ua,'LinkedInApp')!==false){return 'linkedin';}
        if(preg_match('/(?:Chrome|CriOS)\/\d/',$ua)&&!preg_match('/Edg(?:A|iOS)?\/|OPR\/|SamsungBrowser\/|YaBrowser\/|UCBrowser\/|; wv\)/',$ua)){return 'chrome';}
        if(preg_match('/Version\/[\d.]+ (?:Mobile\/\w+ )?Safari\//',$ua)&&!preg_match('/Android|Chrome\/|CriOS\/|FxiOS\/|EdgiOS\//',$ua)){return 'safari';}return 'outro';
    }
    const SISTEMAS=array('Android','iOS','Windows','macOS','Linux','outro');
    const RETORNOS=array('novo','recorrente');
    const DIMENSOES=array('largura_faixa','navegador','sistema','retorno','aparelho');
    public static function dimensoes_schema(): array {return array('largura_faixa'=>array('type'=>'string','enum'=>array_keys(self::FAIXAS_LARGURA)),'navegador'=>array('type'=>'string','enum'=>self::NAVEGADORES),'sistema'=>array('type'=>'string','enum'=>self::SISTEMAS),'retorno'=>array('type'=>'string','enum'=>self::RETORNOS),'aparelho'=>array('type'=>'string','enum'=>array('celular','tablet','computador','nao_identificado')));}
    public static function sistema(?string $ua=null,array $h=array()): string {
        $ua=$ua??(string)($_SERVER['HTTP_USER_AGENT']??'');
        if(preg_match('/Android/i',$ua)){return 'Android';}
        if(preg_match('/iPhone|iPad|iPod/i',$ua)||(stripos($ua,'Macintosh')!==false&&($h['max_touch_points']??0)>1)){return 'iOS';}
        foreach(array('Windows NT'=>'Windows','Macintosh'=>'macOS','Linux'=>'Linux') as $p=>$s){if(stripos($ua,$p)!==false){return $s;}}return 'outro';
    }
    /** Fixed dimensions use the earliest retained observation; absent history stays absent. */
    public static function normalizar_sessoes(array $rows): array {
        $first=array();foreach($rows as &$r){$k=($r['classe_trafego']??'nao_marcado').'|'.($r['sessao']??'');if(empty($r['sessao'])){continue;}
            if(!isset($first[$k])){$first[$k]=array_intersect_key($r,array_flip(self::DIMENSOES));}
            foreach(self::DIMENSOES as $d){$r[$d]=$first[$k][$d]??'';}}
        unset($r);return $rows;
    }
    public static function dimensoes_contato(array $d): array {
        if(!empty($d['origem_nativa'])){return array_fill_keys(self::DIMENSOES,'');}$c=$d['contexto']??array();$ua=$c['user_agent']??'';$h=$c['client_hints']??array();$a=$c['audiencia']??array();
        return $a+array('largura_faixa'=>self::faixa_largura((int)($c['largura_janela']??0)),'navegador'=>$ua!==''?self::navegador($ua):'','sistema'=>$ua!==''?self::sistema($ua,$h):'','retorno'=>'','aparelho'=>$ua!==''?F3Base_Contato_Apresentacao::aparelho($ua,$h,!empty($d['origem_nativa']))['tipo']:'');
    }
    public static function editor(): bool {
        $id=get_current_user_id();
        // REST without a nonce clears current_user. Validate only for exclusion, never grant privileges.
        if(!$id&&defined('LOGGED_IN_COOKIE')&&!empty($_COOKIE[LOGGED_IN_COOKIE])){$id=wp_validate_auth_cookie((string)$_COOKIE[LOGGED_IN_COOKIE],'logged_in');}
        return $id&&(user_can($id,'edit_posts')||user_can($id,'edit_pages')||user_can($id,'manage_options'));
    }
    public static function registrar_contexto(): void {
        register_rest_route(F3BASE_REST_NAMESPACE,'/contexto-publico',array('methods'=>'GET','permission_callback'=>'__return_true','callback'=>static function($req){
            $origin=$req->get_header('origin');$home=wp_parse_url(home_url());$expected=$home['scheme'].'://'.$home['host'].(isset($home['port'])?':'.$home['port']:'');if($origin&&rtrim($origin,'/')!==$expected){return new WP_Error('origem_invalida','Origem inválida.',array('status'=>403));}
            $r=new WP_REST_Response(array('ok'=>true,'excluida'=>self::editor(),'motivo'=>self::editor()?'editor':'visitante'));
            $r->header('Cache-Control','private, no-store, max-age=0');$r->header('Vary','Cookie');$r->header('X-Robots-Tag','noindex, nofollow');return $r;
        }));
    }
    public static function pagina_excluida(): bool {return is_admin()||is_404()||self::editor();}
    public static function caminho_tecnico(string $path): bool {return (bool)preg_match('~^/(?:wp-admin(?:/|$)|wp-login\.php(?:/|$)|wp-content/|wp-includes/)~i',$path);}
    public static function rotulos_dimensoes(): array {return array('largura_faixa'=>'Largura da janela','navegador'=>'Navegador','sistema'=>'Sistema operacional','retorno'=>'Visitante novo ou recorrente','aparelho'=>'Aparelho estimado');}
    public static function rotulo_dimensao(string $dim,string $v): string {return array('ate_359'=>'Até 359 px','360_479'=>'360–479 px','480_767'=>'480–767 px','768_1023'=>'768–1023 px','1024_1439'=>'1024–1439 px','1440_mais'=>'1440 px ou mais','novo'=>'Novo neste navegador','recorrente'=>'Recorrente neste navegador','nao_identificado'=>'Não identificado',''=>'Indisponível')[$v]??ucfirst($v);}
    const REGRA='audiencia-1.18.0-1';
    public static function automacao(array $s=array(),?string $ua=null): array {
        $ua=$ua??(string)($_SERVER['HTTP_USER_AGENT']??'');$motivos=array();$estado='nao_identificada';
        if(preg_match('/Chrome-Lighthouse|PageSpeed|F3Base-(?:Sonda|Prova)|F3Base\/(?:sonda|verificacao)|UptimeRobot|Pingdom|Site24x7/i',$ua)){$estado='declarada';$motivos[]='assinatura_tecnica';}
        elseif(preg_match('/GPTBot|OAI-SearchBot|ChatGPT-User|ClaudeBot|Claude-SearchBot|Claude-User|PerplexityBot|Googlebot|bingbot/i',$ua)){$estado='declarada';$motivos[]='assinatura_robo';}
        if(preg_match('/HeadlessChrome/i',$ua)){$motivos[]='headless_chrome';if($estado==='nao_identificada'){$estado='provavel';}}
        if(($s['webdriver']??false)===true){$motivos[]='webdriver_declarado';if($estado==='nao_identificada'){$estado='provavel';}}
        return array('automacao'=>$estado,'automacao_motivos'=>implode(',',$motivos),'automacao_regra'=>self::REGRA);
    }
    public static function sinais_validos($s): bool {return is_array($s)&&!array_diff(array_keys($s),array('webdriver'))&&(!isset($s['webdriver'])||is_bool($s['webdriver']));}
    public static function provedores(): array {
        static $catalogo=null;if($catalogo===null){$v=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'dados/origens-ia.json'),true);$catalogo=array();foreach($v['provedores']??array() as $p){$catalogo[$p['id']]=$p;}}return $catalogo;
    }
    public static function origem(string $valor,bool $utm=false): string {
        $valor=strtolower(rtrim(trim($valor),'.'));if($valor===''||strlen($valor)>253){return '';}
        foreach(self::provedores() as $id=>$p){if($utm&&in_array($valor,$p['aliases_utm'],true)){return $id;}
            foreach($p['dominios'] as $d){if($valor===$d['host']||(!empty($d['subdominios'])&&str_ends_with($valor,'.'.$d['host'])&&preg_match('/^[a-z0-9.-]+$/D',$valor))){return $id;}}
        }return '';
    }
    public static function ia(array $a): string {return self::origem((string)($a['utm_source']??''),true)?:self::origem((string)($a['referrer']??''));}
    public static function canal(array $a): array {
        $src=strtolower($a['utm_source']??'');$m=strtolower($a['utm_medium']??'');$ref=strtolower($a['referrer']??'');$ia=self::ia($a);$iu=self::ia(array('utm_source'=>$src));$ir=self::ia(array('referrer'=>$ref));$conflicts=array();if($iu&&$ir&&$iu!==$ir){$conflicts[]='provedor_utm_diverge_referrer';}if($m==='organic'&&(!empty($a['gclid'])||!empty($a['oppref']))){$conflicts[]='meio_organico_com_identificador_pago';}
        $r=array('canal'=>'direto_desconhecido','origem_ia'=>$ia,'regra'=>self::REGRA,'evidencia'=>'sem_origem_observavel','conflitos'=>implode(',',$conflicts));
        if(!empty($a['oppref'])||!empty($a['gclid'])||!empty($a['gbraid'])||!empty($a['wbraid'])||in_array($m,array('paid','cpc','ppc','cpm','display','paid_social','paid-social','paidsocial','paid_search','paid-search'),true)){return array_replace($r,array('canal'=>'pago','evidencia'=>'identificador_ou_meio_pago'));}
        if($ia){return array_replace($r,array('canal'=>'ia','evidencia'=>$iu?'utm_ia':'referenciador_ia'));}
        if(in_array($m,array('email','e-mail','newsletter'),true)){return array_replace($r,array('canal'=>'email','evidencia'=>'meio_email'));}
        if($m==='organic'||preg_match('/^(?:www\.)?(?:google\.(?:com|com\.br|pt)|bing\.com|duckduckgo\.com|search\.yahoo\.com|yahoo\.com|search\.brave\.com)$/D',$ref)){return array_replace($r,array('canal'=>'busca_organica','evidencia'=>$m==='organic'?'utm_organic':'referenciador_buscador'));}
        if(in_array($m,array('social','social-organic','organic_social'),true)||in_array($src,array('facebook','instagram','ig','fb','linkedin','tiktok','twitter','x'),true)||preg_match('/^(?:www\.|l\.|lm\.|m\.)?(?:facebook\.com|instagram\.com|linkedin\.com|t\.co|twitter\.com|x\.com|tiktok\.com)$/D',$ref)){return array_replace($r,array('canal'=>'social','evidencia'=>'origem_social_sem_prova_pago'));}
        if($m==='referral'||$ref!==''){return array_replace($r,array('canal'=>'referencia','evidencia'=>'referenciador_externo'));}
        if($src!==''||$m!==''){return array_replace($r,array('canal'=>'outro_identificado','evidencia'=>'utm_outro'));}return $r;
    }
    public static function canais(): array {return array('busca_organica'=>'Busca orgânica','ia'=>'Referências de IA','social'=>'Social','pago'=>'Mídia paga','email'=>'E-mail','referencia'=>'Outros sites','outro_identificado'=>'Outra origem identificada','direto_desconhecido'=>'Direto / desconhecido');}
}
