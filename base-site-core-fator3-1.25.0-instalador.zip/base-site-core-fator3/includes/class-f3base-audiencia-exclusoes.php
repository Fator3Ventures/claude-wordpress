<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Audiencia_Exclusoes {
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_audiencia_404';}
    public static function instalar(): bool {global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE $t (
 dia date NOT NULL,
 caminho varchar(190) NOT NULL,
 contagem bigint unsigned NOT NULL DEFAULT 0,
 amostras bigint unsigned NOT NULL DEFAULT 0,
 ultimo_em bigint unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (dia,caminho)
) ".$wpdb->get_charset_collate().';');return !$wpdb->last_error&&!array_diff(array('dia','caminho','contagem','amostras','ultimo_em'),$wpdb->get_col('SHOW COLUMNS FROM '.$t));}
    public const FATOR=100;
    public static function sorteada(): bool {return wp_rand(1,self::FATOR)===1;}
    public static function registrar(): void {if(!is_404()||is_admin()||strtoupper($_SERVER['REQUEST_METHOD']??'GET')!=='GET'||!self::sorteada()){return;}if(!F3Base_Recuperacao::entrar()){return;}try{global $wpdb;$t=self::tabela();$dia=wp_date('Y-m-d');$path=F3Base_Analise::caminho(wp_unslash($_SERVER['REQUEST_URI']??'/'));if(!$path){return;}
        // Bounded cardinality; overflow remains visible in one explicit bucket.
        if((int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE dia=%s',$t,$dia))>=5000&&!$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE dia=%s AND caminho=%s',$t,$dia,$path))){$path='/@outros-404';}
        $wpdb->query($wpdb->prepare('INSERT INTO %i (dia,caminho,amostras,ultimo_em) VALUES (%s,%s,1,%d) ON DUPLICATE KEY UPDATE amostras=amostras+1,ultimo_em=VALUES(ultimo_em)',$t,$dia,$path,time()));}finally{F3Base_Recuperacao::sair();}
    }
    public static function podar(): void {global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia<%s LIMIT 5000',self::tabela(),wp_date('Y-m-d',time()-90*DAY_IN_SECONDS)));}
    public static function relatorio(string $de,string $ate): array {global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT caminho,SUM(contagem) historico_exato,SUM(amostras) quantidade_amostrada,SUM(contagem)+100*SUM(amostras) requisicoes_estimadas,MAX(ultimo_em) ultimo_observado_em FROM %i WHERE dia BETWEEN %s AND %s GROUP BY caminho ORDER BY requisicoes_estimadas DESC,caminho LIMIT 200',self::tabela(),$de,$ate),ARRAY_A);return array('fonte'=>'f3base_audiencia_404','unidade'=>'estimativa_requisicoes_404_no_wordpress','regime'=>'historico_exato_mais_amostra_1_em_100','fator_amostra'=>self::FATOR,'retencao_dias'=>90,'max_caminhos_dia'=>5000,'limite_linhas'=>200,'linhas'=>$rows?:array(),'ok'=>$wpdb->last_error==='','observacao'=>'Estimativa: histórico exato + amostras × 100. Sorteio anterior à consulta/gravação; caminhos raros podem não aparecer. Horário é o último observado na amostra. Separado da audiência; inclui robôs e editores. Respostas sem executar WordPress não entram. Sem IP, user agent ou pseudônimo.');}
}
