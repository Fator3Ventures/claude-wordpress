# Encaminhamento ao MCP — Site Core 1.25.0 / MCP 0.18.0

O código do MCP recebido não foi alterado. Pacote fonte conferido: SHA-256 `d73f4765f71b23000040daf704516e90941f07d82a83d76786b23d27183228f4`.

## Contratos

- Core registra novas leituras `f3base/estado-inventario-ler`, `f3base/conteudo-instrumentacao-ler`, `f3base/sondas-http-ler` e operações de aviso documentadas no catálogo executável. Respeitam capacidade/política do canal. Não expor credenciais Slack nem valores do inventário.
- A requisição marcada pelo conector como teste não entra na audiência. GET/HEAD com marcador HTTP explícito produz somente agregado técnico por caminho, método, status e classe. Não inferir humanos/agentes pela hora/IP; o Core não detecta uma requisição que nem chega ao WordPress.
- Guardas de Core/Google continuam independentes. Sem permissão de leitura na guarda, Core só anuncia atendimento quando a estrutura existente permite captura; geração desconhecida não equivale a prontidão de restore.
- Backup conjunto inclui acervos/intenções e salts. Nove options do implantador continuam fora da propriedade do Core. Não apagar dados por `f3base_*`.

## Validação e ação

Arquivos reais MCP 0.18.0 e Google 0.8.1 foram carregados com Core em instalação nova e upgrade, em processos frios e ordem inversa. Registro, autorização e pausas/retomadas independentes passaram. Não foi feita chamada MCP remota autenticada em produção.

Nenhuma correção obrigatória foi identificada no MCP 0.18.0. Ao atualizar documentação/roteiros do conector, usar o catálogo distribuído da 1.25 e manter a ordem de restore: preparar Core → Google; retomar Google → Core, sem retomar a guarda alheia.
