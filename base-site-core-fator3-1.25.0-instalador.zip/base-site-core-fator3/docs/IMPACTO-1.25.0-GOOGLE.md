# Encaminhamento ao MCP Google — Site Core 1.25.0 / Google 0.8.1

O código do Google recebido não foi alterado. Pacote fonte conferido: SHA-256 `b1723f275d4042a0f2b33a814aa712ddcc6e239293292c5a96f5e9fcaaacbb3b`.

## Contratos e estado

Core exige `effective_status` no diagnóstico do SDK. Não faz fallback silencioso à conexão padrão quando a concessão pertence a outra conexão. A consulta revalida a autorização; resumo é leitura local. Instalação/cron sem usuário autenticado preservam o consumidor registrado. Mínimos de contrato permanecem estáveis; a matriz desta entrega é MCP 0.18.0 / Google 0.8.1, sem gate de igualdade de versão.

A correção GA4 direto + GTM pertence ao CoreBinding do Google 0.8.1 recebido. Core mantém os slots de emissão e não aplica workaround no companheiro. Desligar evento direto não impede um contêiner GTM de encaminhá-lo; seleção independente e ajuda existem no Core.

O backup conjunto precisa incluir `f3_google_cron`, conexões/concessões e a guarda `f3-google-state`. `f3-google-cache` permanece cache descartável do Google; o Core não o limpa. Preparar Core → Google, drenar e reconciliar; retomar Google → Core com geração atual. Retomar uma guarda não retoma a outra.

## Provas e limites

SDK real 0.8.1 carregado nas duas ordens. Exercitados diagnóstico efetivo, concessão não padrão, ambiguidade/revogação/armazenamento ilegível, execução com usuário 0, resumo sem rede e falha estrutural. Respostas OAuth/HTTP foram simuladas localmente: isso não homologa uma propriedade Google real. Não foi alterada a agenda Google para forçar sucesso.

Nenhuma alteração obrigatória adicional foi identificada no pacote Google 0.8.1. Atualizar os roteiros de backup/restore e consumir os contratos distribuídos é a ação operacional recomendada.
