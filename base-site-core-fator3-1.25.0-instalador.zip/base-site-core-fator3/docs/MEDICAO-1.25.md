# Medição e conteúdo — Core 1.25

## Audiência e atendimento

Cada página medida faz uma consulta mínima, privada e sem cache, a `contexto-publico`, compartilhada entre scripts. Ela não grava audiência nem chama fornecedor. Serve para excluir editor com cookie WordPress válido mesmo quando o HTML veio do cache. Não bloqueia renderização, consentimento ou contato. Tags/coletores aguardam classificação; falha/timeout não os libera. Revalida ao voltar do bfcache, ao recuperar foco e ao tornar a aba visível. Cookie de teste continua durando 365 dias, separado de autenticação/consentimento.

404 e editores ficam fora da audiência e dos destinos geridos pelo Core; o contato fica salvo, com `dados.audiencia_excluida`, sem jornada inventada e sem virar teste automaticamente. Aviso/CRM usam regras de atendimento. O Core não controla tags inseridas diretamente por terceiros.

## Eventos e unidades

Configurações → Coleta no site → Destinos dos eventos: seleções independentes para GA4 direto e dataLayer. O local permanece coletado conforme consentimento e configuração. Padrão dos quatro eventos: habilitados, inclusive na complementação do upgrade. Desligar o slot GA4 direto não controla um contêiner GTM. Para excluir também no GTM, desligue publicação no dataLayer e confira gatilhos/tags do contêiner.

| Evento | Gatilho | Parâmetro e uso |
|---|---|---|
| f3base_saida | ocultar/sair; última marca cumulativa por navegação | f3base_visivel_ms: métrica em milissegundos; f3base_profundidade: métrica percentual (0–100) |
| f3base_rolagem_salto | profundidade alcançada sem gesto recente, âncora ou salto programático | f3base_marco: marco percentual; não prova leitura |
| f3base_clique_interno | ação interna fora de contato/consentimento/formulário | f3base_clique e f3base_clique_origem: dimensões; origem 1 declarada, 2 contextual, 3 genérica |
| f3base_clique_inerte | clique em conteúdo sem ação observada após janela local | f3base_secao: dimensão; contagem separada, fora da soma de fricção |

GA4 continua via tag. Criar definições personalizadas compatíveis com a unidade quando necessário; dimensão categoriza, métrica agrega números. Não cadastrar milissegundos como segundos sem conversão. `superficie` no generate_lead é uma dimensão. Dados locais não exigem essas definições remotas.

Gesto de roda, toque ou tecla de rolagem nos dois segundos anteriores prevalece sobre a heurística de velocidade. Âncora não comprova gesto. Tempo visível começa na primeira visibilidade autorizada; não soma fundo ou período pré-consentimento. Saída é observação, não prova de abandono. Duração por campanha/anúncio conserva a cobertura da saída e difere de engajamento GA4.

## Técnico

404: sorteio 1:100 antes de acessar a tabela, com teto de caminhos e retenção de 90 dias. `contagem` conserva histórico exato; `amostras` contém somente sorteadas. Estimativa = histórico exato + 100 × amostras. Caminhos raros podem desaparecer; horário é último observado, não última requisição absoluta. Não somar como audiência.

Medição → Técnico → Sondas e requisições técnicas e `f3base/medicao-sondas-ler`: GET/HEAD com X-F3Base-Teste explícito chegando ao WordPress, classes teste/não marcado/inválida, método, status, caminho seguro e horários. Status zero é desconhecido. A assinatura não autentica autoria. Sem IP, UA, cookie, query ou corpo. Caminhos privados/técnicos recebem rótulos sem identificadores. Até 5.000 chaves/dia, excedentes agrupados, 90 dias. Sem cabeçalho não há consulta/escrita desse coletor. Cache/CDN/arquivo servido antes do WordPress não entra. Pode sobrepor logs/404; não somar fontes.

## Superfícies e formulários

`conteudo`, `menu`, `flutuante`, `elementor`, `cabecalho`, `barra_fixa`. Declaração válida mais próxima vence a inferência: atributo explícito; depois classe `f3base-superficie-<nome>` no elemento/ascendente. Conflitos no mesmo elemento são apontados pela auditoria. Header/template part header é inferido, nav é menu. Position fixed sozinho não infere barra. Histórico sem prova permanece não informado.

Filtrar `superficie` em `relatorios-integrados-ler`; visão `superficies` quebra contatos. Não confundir número de contatos com pessoas. Os denominadores de audiência de página não provam exposição a cada superfície.

Shortcode: `[f3base_formulario id="contato" secao="fale-conosco"]`. Bloco oferece Seção. CSS entra no head quando há formulário configurado, sem inserir style antes do form. `mensagem_whatsapp` vazia herda contato.mensagem_padrao; ambas vazias começam no primeiro campo. Só preenchidos, pelo rótulo, incluindo zero; anexos não vão ao texto. `whatsapp_automatico` (padrão false) navega na mesma aba após persistência; botão de reserva usa `mensagens.continuar_whatsapp`. Não promete abertura de app instalado.

`conteudo-instrumentacao-ler` pagina conteúdo publicado, resolve blocos sincronizados e template parts referenciados com limite 12 níveis/2.000 blocos. Lista seções ausentes/aninhadas/repetidas, textos WhatsApp iguais, formulários e texto herdado/efetivo, conflitos de superfície. Somente leitura; não visita site. Conteúdo dinâmico ou composição do tema fora do post é cobertura incompleta explícita. Core não altera tema para zerar relatório.
