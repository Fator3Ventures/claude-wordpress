# Entrega — Fator3 Site Core 1.25.0

Data: 08/10/2026. Código, documentação instalada, instalador e fontes com testes. Referência de implantação: WordPress novo ou Core 1.24.0, sem trava por número da origem. Companheiros conferidos: MCP 0.18.0 e MCP Google 0.8.1. Nenhuma alteração nos outros plugins, no tema ou no implantador.

## Resultado

Incluídos os pedidos do escopo consolidado: captura independente da audiência e editor em cache; atendimento com guarda ilegível; eventos/visibilidade/gesto; estimativa de 404; avisos Slack; apresentação única da origem; formulário/WhatsApp/superfícies; controle de custo CRM; poda de intenções/quota; perfil 3.3; cache finito; provas de servidor/proteção de HTML de templates; ofertas; inventário e consolidação; contratos finais dos companheiros. A rastreabilidade por número está em RELEASE-1.25.0.md e a evidência efetivamente executada em VALIDACAO.md.

O segredo Slack é informado pelo dono em Contatos → Integrações → Avisos. E-mail continua padrão; habilitar Slack não redispara história. Após restaurar, pendências Slack ficam suspensas até reconciliação/reenvio explícito. O adaptador JSON/HMAC genérico do 17(f) permanece adiado conforme alternativa aprovada: exige contrato de destino/assinatura próprio, e não é anunciado como pronto.

## Instalação

1. Fazer backup do banco, salts, conteúdo e arquivos privados conforme ESTADO-1.25.md. Para restauração coordenada, seguir AGENTES-1.25.0.md.
2. Instalar `base-site-core-fator3-1.25.0-instalador.zip` no WordPress. O ZIP fonte contém documentação de teste e não é o instalador.
3. Conferir versão, conclusão da atualização, saúde e destinatários. Em Apache, conferir a prova pública após reconciliação das regras; Nginx depende da regra equivalente da hospedagem.
4. Homologar um contato em modo de teste, segundo políticas explícitas de destinos; conferir captura, origem, aviso e CRM. Não marcar transporte simulado como teste da conta real.

Não é necessário apagar opções para migrar. Escolhas false/lista vazia e procedência permanecem. Não há promessa de converter schemas anteriores à base 1.24 nem de downgrade.

## Limites da entrega

Nenhum site de produção foi alterado. Contas reais Slack/Pipedrive/Google, SMTP, DebugView, Safari/Chrome de aparelhos físicos e infraestrutura da frota exigem homologação do dono. Chromium e Apache reais locais foram usados; respostas de provedores e dados são sintéticos. O handshake de exclusão acrescenta uma consulta pequena privada por carregamento, compartilhada entre scripts; não bloqueia renderização/atendimento. Scripts de terceiros fora do Core permanecem sob controle de seus proprietários.
