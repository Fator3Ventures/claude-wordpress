# Validação — Core 1.25.0

Executada em 08/10/2026. PHP 8.3, WordPress local com MariaDB, Chromium 140.0.7339.80 e Apache real local. Dados sintéticos e transportes remotos bloqueados, com respostas específicas simuladas. Nenhuma conta ou site de produção foi alterado. Esta distinção vale para todos os resultados abaixo.

Os artefatos citados ficam no ZIP fonte, em `suite/versao-1250/evidencias/`. Documentos de versões anteriores são históricos, não evidências desta entrega.

| Pedidos / área | Cenário executado e resultado | Evidência |
|---|---|---|
| Base nova/1.24, 159–161 | Instalação nova e atualização real da 1.24 com 130 contatos, JSON bruto/escalar/inválido, pendências, procedência, nove opções do implantador, false/lista vazia; segunda requisição idempotente. Passaram. | ciclo-instalacao.json |
| 139, 150.7 | Pasta sem travessia, sentinela sem leitura, pausa confirmada e requisição após reparo. Captura persistida na estrutura pronta; sem migração/transportes; geração desconhecida nula. Passaram. | permissoes.json |
| 148, 150.1 | Chromium com GA4/GTM/Meta/LinkedIn/Clarity configurados, fonte e minificado: visitante, editor em HTML compartilhado, 404, falha de contexto, consentimento negado. Contato capturado em todos; exclusões sem requests analíticos/tags. Cookie WordPress validado em REST sem nonce, sem promoção do usuário. Passaram. | exclusao-navegador.json, funcional.json |
| 140, 150.2/3/6/7 | Fonte/minificado: sessão nova/recorrente, tempo autorizado, saída deduplicada, bfcache, salto/âncora, gesto rápido precede velocidade, aba inicialmente oculta → visível, consentimento tardio sem tempo retroativo. Passaram. | navegador.json, navegador-payloads.json |
| 150.5 | 100 requisições não sorteadas: zero SQL na tabela 404; uma sorteada: duas operações. Sorteio controlado deterministicamente no teste. Estimativa 1:100 e histórico separados. Passou. | funcional.json |
| 149, 152–154 | Superfície inferida/declarada, atributo prioritário e carimbo idempotente; auditoria de aninhamento/textos; WhatsApp com rótulos, zero e sem vazios/anexos. Chromium fonte/minificado: duplo submit, aceitação, continuação manual e automática opt-in na mesma aba. Passaram. | funcional.json, formularios-navegador.json |
| 151 | Origem com até oito linhas, sem blocos iguais; último toque diferente preservado. Fonte comum aos canais. Passou. | render.json |
| 17 g–j | Segredo cifrado/mascarado, URL estrita, payload/limites sem menção, intenção idempotente, sucesso, 403 com fallback único, 429/Retry-After, 5xx/backoff, timeout incerto sem retry cego, reenvio com aceite, eliminação, suspensão, resumo de 50 com links íntegros, ambos sem duplicar e-mail. Passaram. | avisos.json |
| 17 concorrência | Três processos PHP no mesmo banco, uma chamada ao transporte simulado. Passou. | concorrencia.json |
| 150.4 | Duas verificações manuais reais na camada HTTP simulada, sem zerar orçamento; automáticas reaproveitam; anúncio não invalida; mudança de credencial invalida. Passou. | funcional.json |
| 146, 150.7 | Cron com usuário 0: 610 intenções antigas em lotes 500 + 110, pendência preservada; vigésimo adiamento de quota usa contador próprio e não vira falha/loop. Passou. | funcional.json |
| 152(a), 155 | Instalação com defaults novos; upgrade mantém false e lista vazia. Catálogo de Testes separado dos oito seletores de eventos. Passou. | ciclo-instalacao.json, render.json |
| 156, 162 | Apache real, raiz/subdiretório, templates/parts/patterns HTML e DirectoryIndex bloqueados, páginas/CSS/JS acessíveis, marcador externo preservado. Passou. A prova HTTP da hospedagem continua distinta. | apache.json, servidor-bloco*.txt |
| 157 | Três ofertas com referências cruzadas: verificadas; preço divergente: recusado. Passou. | funcional.json |
| 158 | 42 entradas/300 KB, teto de 32/8 MiB, órfãos, backend de object cache emulado, seis processos concorrentes. Passou. | funcional.json, concorrencia.json |
| 160–161 | Desinstalação real local confrontada com as 43 tabelas do inventário; contatos, filas, arquivo de intenções e nove opções externas preservados; família própria removida, transiente externo intacto. Passou. | desinstalacao.json |
| MCP/Google | Pacotes finais reais, ordens inversas/processos frios, nova/upgrade, registro, autorização, guardas independentes; retomada Google → Core. Passou. | companheiros-reais.json |
| SDK Google | Concessão não padrão, ambígua/revogada/ilegível, execução sem humano, resumo sem rede, falha estrutural e contexto restaurado. SDK real; OAuth/HTTP simulado. Passou. | google-sdk.json, google-resolucoes.json |
| UX / token cache | Render PHP das três abas com prova sintética de tokens; Coleta, Testes, Avisos, superfícies, sondas, fricção, resumo e formulários. Sem warnings/fatal do plugin. Capturas distintas em Chromium. | render.json, telas.json, telas/ |
| Distribuição | Lint PHP, manifesto fonte/minificado, CRC, extração e comparação integral do instalador; ciclo usando conteúdo extraído do ZIP fechado. | lint.json, pacote.json, zip-fechado.json |

## Limites que não foram tratados como aprovados

- Não houve homologação real de Pipedrive, Slack, SMTP, Google OAuth/propriedades ou GA4 DebugView. `pre_wp_mail=true` prova a intenção e montagem, não entrega/leitura humana.
- O teste de permissão roda como UID 0 dentro de namespace sem qualquer capability (`CapEff=0`), com negação efetiva de `os.access`. Não usa o bypass DAC do root. Não equivale ao usuário não-root exato da hospedagem; esse cenário permanece na homologação da frota.
- Object cache externo foi emulado na API WordPress; nenhum Redis/Memcached real foi homologado. APK/WebView, iOS Safari e Android físicos também não.
- As screenshots derivam de HTML emitido pelo WordPress e assets locais. Não provam todas as combinações de conteúdo, tema e extensão de terceiros. A aba técnica é extensa por reunir diagnóstico; não foi anunciado redesenho completo dela.
- 404 é estimativa e pode omitir caminhos raros. Sondas só observam o que chega ao WordPress e contém marcador explícito; não provam identidade e não se somam à audiência.
- Sem confirmação remota, Slack pode ter entregue: estado incerto permanece visível e exige reconciliação. Um minuto depende de executor em cadência suficiente.

A correção da aba Testes foi encontrada na inspeção visual e coberta por assertivas de catálogo. Resultado de processo zero, isoladamente, não é usado como aceite. O adaptador genérico HMAC é o item funcional adiado, conforme RELEASE-1.25.0.md.
