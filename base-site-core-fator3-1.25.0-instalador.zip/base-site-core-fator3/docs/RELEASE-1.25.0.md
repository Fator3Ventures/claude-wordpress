# Release 1.25.0 — 08/10/2026

## Instalação e preservação

Instalação nova e atualização de uma base 1.24.0 são os cenários de referência. A origem é informativa; ausência ou alteração do marcador antigo não bloqueia por versão. A instalação verifica estrutura real e confirma checkpoints. Uma falha de banco não significa site vazio. A atualização não reimporta CF7/Flamingo nem reexecuta conversores anteriores. Os dados existentes na 1.24, inclusive pendências produzidas em versões anteriores, permanecem.

Marcadores versionados anteriores só saem da lista exata após commit da 1.25. Um recibo em `f3base_release_1250.consolidacao` conserva hashes, revisões, datas e referências transferidas. Progresso incompleto é preservado. `coleta_adicional_desde` conserva o início histórico conhecido. `f3base_release` sem sufixo pertence ao implantador e não é removida. Não apague marcadores para forçar atualização.

## Mudanças

| Pedidos | Implementação |
|---|---|
| 139, 150.7 | Guarda sem leitura/travessia informa estado desconhecido. Atendimento mantém captura na estrutura pronta; tarefas, migração, gravação administrativa e transportes continuam bloqueados. Não inventa geração nem prontidão para restore. |
| 148, 150.1 | Leads dependem de contexto/consentimento, sem dependência obrigatória do tracking. Editor/404 não viram audiência, mas contatos, aviso e CRM seguem sua política. Handshake privado valida cookie WordPress também em HTML cacheado; falha não libera tags. |
| 150.2, 150.3, 150.5, 150.6 | Seleção independente dos quatro eventos para GA4 e dataLayer; clique inerte separado de fricção; gesto antes da heurística temporal; 404 amostrado 1:100 antes do SQL. |
| 140, 150.7 | Tempo visível começa também quando aba inicialmente oculta fica visível; não conta período pré-consentimento. Mantém saída cumulativa e duração por campanha/anúncio. |
| 151 | Origem principal apresentada uma vez; toques iguais resumidos em uma linha, diferenças preservadas. Fonte comum para tela, e-mail, CRM e Slack. |
| 17 g–j | Avisos por e-mail, Slack ou ambos. E-mail permanece padrão. Fila Slack própria, cifrada, deduplicada, com contingência e estado incerto explícito. |
| 149, 152 b–d, 153, 154 | Cabeçalho/barra fixa; superfície declarada mais próxima; seção do formulário; CSS no head; texto WhatsApp por formulário; continuação opcional na mesma aba após aceitação; auditoria somente leitura. |
| 150.4 | Automáticas CRM compartilham sucesso recente por 15 minutos; manual faz consulta real com saldo. Mudança de anúncios não reverifica CRM. Conta/credencial invalida a prova; mapas usam catálogo recente. |
| 146, 150.7 | Poda de intenções por cron em lotes de 500; contador de quota separado de falhas, espera prolongada a partir de 20; códigos internos estruturados. Arquivo de origem das intenções entra no backup. |
| 152 a, 155 | Piso 3.3: tempo ativo e bloqueio de listagem ligados por padrão; classes CTA vazias. False/lista vazia explícitos permanecem no upgrade. |
| 156, 157, 162 | Prova de listagem exige controle 200/token e diretório 403/404; cron revalida sem reaplicar. Bloco próprio protege HTML cru de templates/parts/patterns. Associação explícita de ofertas permite menções cruzadas, mas não preço errado. |
| 158–161 | Cache público com 32 entradas/8 MiB totais, 4 MiB individual, TTL 300 s; limpeza de órfãos e orçamento concorrente. Inventário fechado e consolidação segura de marcadores. |
| Integração MCP/Google | Observação agregada de GET/HEAD com cabeçalho de teste explícito. SDK Google exige effective_status; concessão não padrão preservada. GA4 direto + GTM corrigido no Google 0.8.1, sem mudar a emissão do Core. |

## Operação

Servidor Apache: preferência ligada recebe reconciliação controlada na ativação/atualização com backup e controles; ambiente sem suporte confirmado fica pendente. Revalidação cron não escreve regras. Nginx precisa de configuração equivalente na hospedagem. Não alterar tema para satisfazer o plugin.

Preparação de restauração: Core → Google, conferir drenagem; restaurar dados segundo o inventário e reconciliar efeitos externos; retomar Google → Core com gerações atuais. Fila Slack restaurada permanece suspensa, sem replay cego. Uma retomada não libera a outra guarda.

## Limites

Adaptador genérico HMAC do item 17(f) permanece adiado, conforme a alternativa do pedido. Não há promessa de entrega Slack exatamente uma vez quando a confirmação se perde. Um minuto exige executor nessa cadência. Tags externas inseridas por tema/outro plugin não são controladas pelo Core. Citação/recomendação por IA não é inferida de requisição HTTP. Homologação real de contas, SMTP, DebugView, Slack e aparelhos móveis é distinta dos testes locais; veja VALIDACAO.md.
