# Fator3 Site Core 1.25.0

Matriz de implantação: WordPress novo ou atualização da 1.24.0. É uma referência de manutenção e teste, **sem bloqueio de instalação por número de versão de origem**. Guardas, permissões, revisão e pré-condições estruturais continuam obrigatórias. Não há conversão prometida para schemas anteriores nem downgrade.

Matriz conferida: **MCP 0.18.0 e MCP Google 0.8.1**, arquivos finais fornecidos. A detecção usa os contratos estáveis exigidos; não altera os companheiros, o tema ou o implantador.

[Documentação instalada](DOCUMENTACAO.md) · [Release](RELEASE-1.25.0.md) · [Agentes](AGENTES-1.25.0.md) · [Slack](AVISOS-SLACK-1.25.md) · [Medição](MEDICAO-1.25.md) · [Inventário](ESTADO-1.25.md) · [Validação](VALIDACAO.md).

Esta versão corrige captura em páginas excluídas da audiência, classificação dinâmica do editor em HTML cacheado, superfícies de contato, medição, verificação automática do CRM, operação, cache e proteção de templates. Acrescenta Slack e observação separada das sondas técnicas.

Documentação disponível dentro do plugin e por `f3base/documentacao-ler`, com `manage_options`, inclusive em recuperação. O proprietário cola os segredos na tela; eles não devem transitar pelo agente. Arquivos com versões anteriores no nome são histórico, não a instrução corrente.
