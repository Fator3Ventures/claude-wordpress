# Inventário de estado — 1.25.0

Fonte distribuída: `dados/estado-inventario.json` na raiz do plugin. Leitura sem valores pela ability `f3base/estado-inventario-ler`. O catálogo é fechado e não autoriza limpeza por prefixo. O dicionário SQL completo está em `docs/dados/contrato.json`.

## Backup e restauração

Preservar banco, opções e arquivos privados de negócio. Segredos e payloads são cifrados com material derivado dos salts do WordPress: restauração sem os salts corretos deixa o conteúdo indecifrável. Não exportar plaintext para compensar. Preparar Core → Google e drenar; reconciliar efeitos externos; retomar Google → Core, cada um com sua geração atual. Não sobrepor as sentinelas ativas por cópias antigas. Incluir `f3_google_cron` e o estado próprio dos dois companheiros no backup conjunto. `f3-google-cache` é cache do Google, nunca alvo de limpeza pelo Core.

O arquivo `f3base_intencoes_origem_<12 hex>` é história preservada. Não é trava nem cache. Pendências de entrega e anexos/concessões também não são descartáveis. Desinstalar conserva contatos e filas comerciais, suspende Slack pendente e remove somente estruturas explicitamente descritas abaixo. Desinstalação não é backup.

As opções `f3base_journal`, `f3base_log`, `f3base_checkpoint`, `f3base_estado_aplicacao`, `f3base_fases`, `f3base_release`, `f3base_base_merge`, `f3base_medicoes` e `f3base_vereditos` pertencem ao implantador. Não são lidas como marcadores de release nem apagadas. `f3base_nav_id` é projeção de leitura de `f3base_navegacao`; não reivindica opção do tema.

## Tabelas

Todos os nomes abaixo recebem `$wpdb->prefix` do site. Todas entram no backup. Retenções configuráveis devem ser conferidas nas opções antes de reduzir prazos. GSC preserva acervo; Clarity tem retenção própria (0 preserva); agregados editoriais usam meses configurados, e eventos brutos usam `retencao_eventos_dias` (30 por padrão). 404/sondas têm 90 dias; intenções concluídas, 7 dias; terminais Slack, 90 dias. Não somar janelas móveis de Clarity.

| Sufixo | Finalidade | Desinstalação |
|---|---|---|
| `f3base_acessos` | Uma combinação de dia, classificação de agente/caminho, caminho, HTTP e método. | remover_tabela |
| `f3base_acessos_contribuicoes` | Contribuição por arquivo/fonte e chave agregada, com versão de regra. | remover_tabela |
| `f3base_acessos_horas` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_acessos_horas_fontes` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_acessos_legado` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_analise` | Um evento por evento; vital conserva a última sequência dessa identidade. | remover_tabela |
| `f3base_anuncios_recibos` | Histórico/captura/entrega de contatos | preservar_tabela |
| `f3base_arquivos_blobs` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_arquivos_leads` | Um arquivo físico privado identificado por ID/hash. | preservar_tabela |
| `f3base_arquivos_operacoes` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_atendimento_historico` | Uma mudança operacional por record_id e revisão. | preservar_tabela |
| `f3base_audiencia_404` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_avisos_fila` | Uma intenção de Slack por contato, destino e ciclo; payload cifrado não integra relatórios públicos. | preservar_e_suspender_pendentes |
| `f3base_capi_fila` | Uma entrega durável por chave idempotente (Lead ou PageView); vínculo de captura por evento_hash. | remover_tabela |
| `f3base_clarity` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_clarity_coletas` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_comportamento` | Uma combinação de dia, caminho, métrica, detalhe, classe e regra/fuso. | remover_tabela |
| `f3base_concessoes` | Uma concessão de material/versão para um lead, com quota e validade. | preservar_tabela |
| `f3base_consentimento_decisoes` | Uma referência de decisão de consentimento e validade. | remover_tabela |
| `f3base_consentimento_reparos` | Pendência de projeção da referência por lead; após três conflitos exige revisão. | remover_tabela |
| `f3base_contatos_legados` | Registro histórico preservado; nenhum importador é executado nesta release. | preservar_tabela |
| `f3base_conteudo_rotas` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_conteudos` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_editorial_diario` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_editorial_dias` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_eventos` | Uma ocorrência detalhada da sessão/caminho/métrica; qualidade temporal por linha. | remover_tabela |
| `f3base_execucoes` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_gsc_coletas` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_gsc_diario` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_gsc_lacunas` | Um estado de cobertura por universo/dia. Consulta sem linhas resolve a lacuna sem inferir visitas zero. | remover_tabela |
| `f3base_gsc_linhas` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_inteligencia_auditoria` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_leads` | Um contato ou intenção registrada. Cliques não são formulários aceitos. | preservar_tabela |
| `f3base_leads_dedup` | Uma reserva/chave técnica de deduplicação, sem valor comercial isolado. | remover_tabela |
| `f3base_leads_janelas` | Uma quota técnica com prazo de expiração. | preservar_tabela |
| `f3base_leads_recusas` | Um total de recusas por motivo e dia, sem dados pessoais. | remover_tabela |
| `f3base_medicao_anotacoes` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_meta_eventos` | Medição, evidência ou execução do Core | preservar_tabela |
| `f3base_operacao_intencoes` | Uma intenção durável por ocorrência; estados concluída/esgotada não apagam histórico. | remover_tabela |
| `f3base_pipedrive_fila` | Histórico/captura/entrega de contatos | preservar_tabela |
| `f3base_referencias_ia` | Medição, evidência ou execução do Core | remover_tabela |
| `f3base_sondas_http` | Agregado por dia, caminho saneado, método GET/HEAD, status HTTP, classe e origem explicitamente declarada. Sem IP, user agent ou query string. | remover_tabela |
| `f3base_vitais` | Uma amostra de vital atualizada por sequência; sem sessão vinculável. | remover_tabela |

## Opções próprias

| Nome | Tipo / finalidade | Backup | Desinstalação |
|---|---|---|---|
| `f3base_contato` | configuracao / Contato, avisos e WhatsApp | sim | preservar |
| `f3base_ga4_measurement_id` | configuracao / Google Analytics 4 — ID da métrica | sim | preservar |
| `f3base_gtm_container_id` | configuracao / Google Tag Manager — ID do contêiner | sim | preservar |
| `f3base_google_ads` | configuracao / Google Ads — conversão | sim | preservar |
| `f3base_meta_pixel_id` | configuracao / Meta — Pixel | sim | preservar |
| `f3base_meta_capi_token` | segredo / Meta — token do envio de servidor | sim | preservar |
| `f3base_linkedin_partner_id` | configuracao / LinkedIn — identificador de parceiro | sim | preservar |
| `f3base_linkedin_conversion_id` | configuracao / LinkedIn — conversão | sim | preservar |
| `f3base_atribuicao` | configuracao / Origem do contato | sim | preservar |
| `f3base_verificacao_google` | configuracao / Verificação de domínio — Google | sim | preservar |
| `f3base_verificacao_meta` | configuracao / Verificação de domínio — Meta | sim | preservar |
| `f3base_consentimento` | configuracao / Consentimento | sim | preservar |
| `f3base_retencao_meses` | configuracao / Guarda dos contatos recebidos (meses) | sim | preservar |
| `f3base_acessos` | configuracao / Acessos do servidor | sim | preservar |
| `f3base_acessos_estado` | estado_execucao / Estado da soma de acessos | sim | remover_estado |
| `f3base_sessao` | configuracao / Sessão de login | sim | preservar |
| `f3base_comportamento` | configuracao / Resumo de comportamento no próprio site | sim | preservar |
| `f3base_origem_confiavel` | configuracao / Como o site descobre o endereço do visitante | sim | preservar |
| `f3base_robots` | configuracao / Robots.txt do plugin | sim | preservar |
| `f3base_robots_backup` | estado_execucao / Backup do robots.txt original | sim | preservar |
| `f3base_llms` | configuracao / Arquivo llms.txt para leitores automáticos | sim | preservar |
| `f3base_redirects` | configuracao / Redirects declarados | sim | preservar |
| `f3base_auditoria_pendente` | estado_execucao / Tentativas de auditoria | sim | remover_estado |
| `f3base_llms_arquivo_estado` | estado_execucao / Arquivo llms gerenciado | sim | remover_estado |
| `f3base_schema_evidencia` | estado_execucao / Verificação pública do schema | sim | remover_estado |
| `f3base_google_carregamento` | configuracao / Carregamento das tags Google | sim | preservar |
| `f3base_seo_entidade` | configuracao / Entidade de SEO | sim | preservar |
| `f3base_cabecalhos` | configuracao / Cabeçalhos de resposta | sim | preservar |
| `f3base_nav_id` | projecao / ID da navegação | recriável | preservar |
| `f3base_mcp_files_audit` | estado_execucao / Auditoria de escritas do canal MCP | sim | remover_estado |
| `f3base_atividade` | estado_execucao / Última atividade relevante | sim | remover_estado |
| `f3base_journal_eliminacao` | estado_execucao / Journal de eliminação | sim | preservar |
| `f3base_cadencia` | configuracao / Cadência do modo somente-relatório | sim | preservar |
| `f3base_cadencia_estado` | estado_execucao / Estado da cadência | sim | remover_estado |
| `f3base_cache_estado` | estado_execucao / Estado da integração de cache | sim | remover_estado |
| `f3base_cache_evidencia` | estado_execucao / Evidência pública do cache | sim | remover_estado |
| `f3base_cache_travas` | estado_execucao / Leases do cache | sim | remover_estado |
| `f3base_endpoint_segredo` | segredo / Segredo do token efêmero | sim | remover_estado |
| `f3base_estrutura_estado` | estado_execucao / Atualização da estrutura | sim | remover_estado |
| `f3base_operacao_estado` | estado_execucao / Agenda e execução | sim | remover_estado |
| `f3base_publicacao_evidencias` | estado_execucao / Evidências de publicação | sim | remover_estado |
| `f3base_redirects_evidencia` | estado_execucao / f3base_redirects_evidencia | sim | preservar |
| `f3base_redirects_evidencia_v2` | estado_execucao / f3base_redirects_evidencia_v2 | sim | preservar |
| `f3base_leads_estrutura` | estado_execucao / f3base_leads_estrutura | sim | preservar |
| `f3base_leads_privado` | estado_execucao / f3base_leads_privado | sim | preservar |
| `f3base_leads_notificacoes_estado` | estado_execucao / f3base_leads_notificacoes_estado | sim | preservar |
| `f3base_operaveis` | configuracao / Política de opções operáveis | sim | remover_estado |
| `f3base_politica_canal` | configuracao / Gestão de política pelo canal | sim | preservar |
| `f3base_formularios` | configuracao / Formulários próprios | sim | preservar |
| `f3base_eventos_destinos` | configuracao / Eventos de comportamento por destino | sim | preservar |
| `f3base_testes` | configuracao / Testes de agentes e operadores | sim | preservar |
| `f3base_protecao` | configuracao / Proteção pública | sim | preservar |
| `f3base_servidor` | configuracao / Diretórios do servidor | sim | preservar |
| `f3base_carregamento_destinos` | configuracao / Carregamento por destino | sim | preservar |
| `f3base_redirects_hosts` | configuracao / Hosts HTTPS permitidos nos redirects | sim | preservar |
| `f3base_classificacao_acessos` | configuracao / Classificação de acessos | sim | preservar |
| `f3base_ofertas_evidencia_v2` | estado_execucao / f3base_ofertas_evidencia_v2 | sim | preservar |
| `f3base_analise_saude` | estado_execucao / f3base_analise_saude | sim | preservar |
| `f3base_servidor_estado` | estado_execucao / f3base_servidor_estado | sim | preservar |
| `f3base_acessos_repeticao` | estado_execucao / f3base_acessos_repeticao | sim | preservar |
| `f3base_llms_geracoes` | estado_execucao / f3base_llms_geracoes | sim | preservar |
| `f3base_llms_geracao_publicada` | estado_execucao / f3base_llms_geracao_publicada | sim | preservar |
| `f3base_llms_trava` | estado_execucao / f3base_llms_trava | sim | preservar |
| `f3base_navegacao` | configuracao / Navegação do site | sim | preservar |
| `f3base_pipedrive` | configuracao / Pipedrive | sim | preservar |
| `f3base_anuncios_meta` | configuracao / Meta — formulários nativos | sim | preservar |
| `f3base_anuncios_google` | configuracao / Google Ads — formulários nativos | sim | preservar |
| `f3base_anuncios_linkedin` | configuracao / LinkedIn — acesso à API necessário | sim | preservar |
| `f3base_slack_webhook` | segredo / Credencial de slack webhook | sim | preservar |
| `f3base_clarity_api_token` | segredo / Token de exportação do Clarity | sim | preservar |
| `f3base_pipedrive_token` | segredo / Credencial de pipedrive token | sim | preservar |
| `f3base_anuncios_meta_token` | segredo / Credencial de anuncios meta token | sim | preservar |
| `f3base_anuncios_google_chave` | segredo / Credencial de anuncios google chave | sim | preservar |
| `f3base_anuncios_linkedin_token` | segredo / Credencial de anuncios linkedin token | sim | preservar |
| `f3base_integracoes_estado` | estado_execucao / f3base_integracoes_estado | sim | preservar |
| `f3base_pipedrive_estado` | estado_execucao / f3base_pipedrive_estado | sim | preservar |
| `f3base_pipedrive_orcamento` | estado_execucao / f3base_pipedrive_orcamento | sim | preservar |
| `f3base_anuncios_estado` | estado_execucao / f3base_anuncios_estado | sim | preservar |
| `f3base_avisos` | configuracao / Canal dos avisos internos | sim | preservar |
| `f3base_medicao_editorial` | configuracao / Conteúdo, audiência e IA | sim | preservar |
| `f3base_gtm_evidencia` | estado_execucao / f3base_gtm_evidencia | sim | preservar |
| `f3base_editorial_estado` | estado_execucao / f3base_editorial_estado | sim | preservar |
| `f3base_redes_robos` | estado_execucao / f3base_redes_robos | sim | preservar |
| `f3base_nav_prova` | estado_execucao / f3base_nav_prova | sim | preservar |
| `f3base_logs_1170` | estado_execucao / f3base_logs_1170 | sim | preservar |
| `f3base_meta_auto_config` | configuracao / Configuração automática do Pixel Meta | sim | preservar |
| `f3base_clarity_project_id` | configuracao / Projeto Microsoft Clarity | sim | preservar |
| `f3base_confirmacao_hosts` | configuracao / Hosts externos de confirmação autorizados | sim | preservar |
| `f3base_clarity` | configuracao / Histórico analítico do Clarity | sim | preservar |
| `f3base_clarity_estado` | estado_execucao / Estado Clarity | sim | preservar |
| `f3base_meta_capi_pixel_id` | configuracao / Pixel/dataset da Meta no servidor | sim | preservar |
| `f3base_meta_transporte` | configuracao / Transporte dos eventos Meta | sim | preservar |
| `f3base_meta_homologacao` | estado_execucao / Prova de homologação Meta | sim | preservar |
| `f3base_meta_janela` | configuracao / Janelas externas da Meta conferidas | sim | preservar |
| `f3base_agenda` | estado_execucao / f3base_agenda | sim | preservar |
| `f3base_cache_publico_indice` | estado_execucao / f3base_cache_publico_indice | sim | preservar |
| `f3base_release_1250` | estado_execucao / f3base_release_1250 | sim | preservar |
| `f3base_configuracao_avisos` | estado_execucao / f3base_configuracao_avisos | sim | preservar |
| `f3base_consentimento_indice` | estado_execucao / f3base_consentimento_indice | sim | preservar |
| `f3base_integracoes_verificacao` | estado_execucao / f3base_integracoes_verificacao | sim | preservar |
| `f3base_pipedrive_verificacao_orcamento` | estado_execucao / f3base_pipedrive_verificacao_orcamento | sim | preservar |
| `f3base_config_complementacoes` | estado_execucao / f3base_config_complementacoes | sim | preservar |
| `f3base_gsc_prova_local` | estado_execucao / f3base_gsc_prova_local | sim | preservar |
| `f3base_aparelho_migracao` | estado_execucao / f3base_aparelho_migracao | sim | preservar |
| `f3base_pipedrive_alerta_conta` | estado_execucao / f3base_pipedrive_alerta_conta | sim | preservar |
| `f3base_gsc_estado` | estado_execucao / f3base_gsc_estado | sim | preservar |
| `f3base_gsc_property` | configuracao / Propriedade do Google Search Console | sim | preservar |
| `f3base_gsc` | configuracao / Coleta orgânica do Search Console | sim | preservar |
| `f3base_pipedrive_reparo_cursor` | estado_execucao / Cursor de reparo CRM | sim | preservar |

## Famílias dinâmicas e transientes

Expressões fechadas, com TTL/retencão declarado. Object cache não admite varredura global: somente chaves próprias conhecidas; demais expiram.

| Padrão | Finalidade / retenção | Backup |
|---|---|---|
| `^f3base_trava_[a-f0-9]{64}$` | Reservas atômicas por tarefa — 15–900 segundos; liberação por proprietário | não |
| `^f3base_intencoes_origem_[a-f0-9]{12}$` | Arquivo de origem preservado da transferência de intenções — Sem expiração automática; prova histórica | sim |
| `^f3base_clarity_cota_[a-f0-9]{64}$` | Cota de consultas Clarity por projeto e tipo — Janela diária; não zerar em teste | sim |
| `^f3base_(?:operacao_resultado&#124;integracao_resultado&#124;politica_resultado&#124;avisos_resultado&#124;perfil&#124;forms)_[0-9]+$` | Resultados e contextos administrativos; TTL de 5 minutos a 2 horas — Resultados e contextos administrativos; TTL de 5 minutos a 2 horas | não |
| `^f3base_(?:retorno&#124;clarity_retorno&#124;form)_[a-f0-9-]{36}$` | Rascunhos e retornos administrativos; TTL finito até 2 horas — Rascunhos e retornos administrativos; TTL finito até 2 horas | não |
| `^f3base_confirmacao_[a-f0-9]{32,64}$` | Confirmação de envio; TTL de 10 minutos — Confirmação de envio; TTL de 10 minutos | não |
| `^f3base_publico_[a-f0-9]{64}$` | Conteúdo público; 300 segundos, orçamento de 32 entradas/8 MiB — Conteúdo público; 300 segundos, orçamento de 32 entradas/8 MiB | não |
| `^f3base_publico_geracao$` | Token de geração; TTL de um dia — Token de geração; TTL de um dia | não |
| `^f3base_llms_item_[a-f0-9]{64}$` | Cobertura Markdown por conteúdo; TTL de um dia — Cobertura Markdown por conteúdo; TTL de um dia | não |
| `^f3base_rl_[a-f0-9]{32}$` | Contingência de rate limit; janela finita do endpoint — Contingência de rate limit; janela finita do endpoint | não |
| `^f3base_dedup_[a-f0-9]{40}$` | Deduplicação de contingência; prazo do endpoint — Deduplicação de contingência; prazo do endpoint | não |
| `^f3base_(?:leads_migrando&#124;retencao_recuperando&#124;comportamento_migrando&#124;cadencia_recuperando&#124;vitais_limpeza)$` | Reservas legadas do esquema atual; 1 a 60 minutos — Reservas legadas do esquema atual; 1 a 60 minutos | não |
| `^f3base_acessos_fotografia$` | Fotografia temporária de acessos; TTL de um dia — Fotografia temporária de acessos; TTL de um dia | não |

## Consolidação

Após commit da instalação, só os marcadores exatos de `marcadores_retired` saem. O recibo `f3base_release_1250.consolidacao` conserva revisão/hash/data, e progresso incompleto não é apagado. A ausência de um marcador anterior não reexecuta conversores. Agenda usa `f3base_agenda`. Não há escrita própria de site_option nesta versão. Não exigir número de versão anterior no bootstrap.
