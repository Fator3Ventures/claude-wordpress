# Documentação instalada — Core 1.25.0

Índice: wp-content/plugins/base-site-core-fator3/docs/DOCUMENTACAO.md. Pelo canal: `f3base/documentacao-ler`, depois arquivo/linha/limite (até 200). SHA-256 e continuação acompanham a leitura; exige manage_options, inclusive em recuperação.

| Documento | Conteúdo |
|---|---|
| RELEASE-1.25.0.md | Mudanças, instalação e limites |
| AGENTES-1.25.0.md / INSTRUCOES-DO-PLUGIN.md | Operação e contratos atuais |
| MEDICAO-1.25.md | Exclusão, eventos, sondas, superfícies e formulários |
| AVISOS-SLACK-1.25.md | Configuração, fila e contingência |
| ESTADO-1.25.md | Inventário, backup, cache e propriedade |
| ENTREGA-1.25.0.md / VALIDACAO.md | Rastreabilidade e provas locais |
| IMPACTO-1.25.0-MCP.md / IMPACTO-1.25.0-GOOGLE.md | Relatórios aos companheiros |
| AJUDA-OPCOES.md / dados/ajuda-opcoes.json | Ajuda gerada do catálogo |
| dados/configuracao-schema.json / dados/abilities-*.json | Schemas executáveis |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas e semântica |
| PIPEDRIVE.md / ORIGENS-ANUNCIOS.md | CRM e anúncios nativos |
| perfis/piso-padrao-3.3.json | Piso atual; 3.2 preservado para história |

Documentos nomeados com outras versões são históricos e não sobrepõem os guias correntes. A presença do guia não implica ativação de serviço externo. Não existem credenciais reais nos documentos distribuídos.
