# Contratos públicos — 0.8.0

Namespace REST preservado: `/wp-json/f3-meta/v1/{operation}`, POST JSON autenticado. Cookie administrativo exige nonce REST; credenciais MCP também passam pela política do transporte. Abilities preservam prefixo `meta/`. Consulte `contracts` e `input-schemas.json`; todos os objetos de entrada são fechados e parâmetros desconhecidos são recusados. IDs remotos são strings, não números de ponto flutuante.

Envelope: `success`, `code`, `provider`, `version` e `data` em sucesso. Falha: `error_code`, `message`, `conflict`, `retryable`, `details`, `data=null`. Um sucesso local não implica homologação externa. `not_authorized` é HTTP 403 em REST; os demais códigos de domínio usam envelope estruturado.

Relatórios mantêm contrato social-reporting/1.0.0; Meta estende para social-reporting/1.1.0 com linhas diárias e disponibilidade. Nenhum campo anterior é removido. Preserve seleção e next_cursor até esgotar. `coverage.complete` exige fim do plano e nenhuma indisponibilidade registrada; `all_rows_guaranteed` pode ser null. Inventário completo da resposta não comprova todo o histórico remoto.

Revisões são obrigatórias para configuração, agendas, concessões e controle de tarefas. Chaves idempotentes locais têm no máximo 64 caracteres; o transporte pode ter limites próprios. Não reutilize uma chave para outra intenção. Listagens administrativas usam `offset` e `next_offset`; get-connection/get-grant permitem releitura de uma configuração precisa. A falta de uma página não autoriza inferir que os outros registros não existem.

Erros estáveis incluem invalid_input, not_authorized, asset_access_denied, revision_conflict, credential_revalidation_required, rate_limited, upstream_error, operation_uncertain, history_changed, response_limit, storage_unavailable e persistence_unconfirmed. Não trate resultado incerto como autorização para reenviar uma mutação.

## Diagnóstico aditivo da 0.3.0

`details` de falhas Graph conserva `http_status` inteiro, `provider_code` e `provider_subcode` inteiro ou null e `provider_is_transient` booleano ou null. Nenhuma mensagem bruta, URL ou token é devolvida. Em falhas por métrica, `coverage.errors[]` e `rows[].diagnostic` conservam os mesmos campos, com `cause=provider_rejected` e `reason` do transporte. O código legado `unsupported_for_asset_or_version` permanece por compatibilidade; o código remoto deve ser consultado antes de atribuir a causa. Vazio de sucesso usa `cause=undetermined` e códigos remotos null. `multiple_source_buckets` sinaliza mais de um bucket em uma janela diária, preservados em source_values sem soma ou escolha arbitrária.

`job-status`, `list-jobs` e `run-job` acrescentam `last_error`: null ou objeto sanitizado da última tentativa abortada, incluindo erro remoto quando presente. Ao concluir uma página com sucesso, last_error volta a null; indisponibilidades por métrica continuam em errors. Contratos social-reporting/1.0.0 e 1.1.0 e entradas permanecem.

`validate-connection` com channel=facebook acrescenta `proof.page_permissions`, referente apenas ao account_id selecionado: page_id, source, status, permissions_verified, scopes, read_insights_granted, pages_read_engagement_granted, is_valid, checked_at e diagnostic_error opcional. Booleano false significa permissão ausente quando status=verified; null significa não determinada. `insights_read` continua false: inspeção de escopos não consulta nem homologa métricas.

## Administração aditiva da 0.4.0

`meta/admin-options` exige administrador em painel, REST e MCP. `kind=users` lista nomes locais (50 por página, `offset/next_offset`, busca por nome/login ou até 100 IDs selecionados). Não retorna e-mail nem credencial. Os demais tipos exigem conexão e canal: `assets` usa descoberta com cursor assinado; `selected` resolve nomes de até 10 ativos já permitidos por página; `objects` projeta nome/ID de mídias, publicações, vídeos (Meta) ou campanhas (LinkedIn); `forms` e `journal` são exclusivos do LinkedIn. Formulários exigem conta selecionada e proprietário remoto idêntico. Diário mostra somente operações administrativas locais comprovadas pelo SDK; não adota recibos de consumidores.

Listas de nomes não alteram seleção. Falha de obtenção de nome deixa `name=null`, `name_status=unavailable` e motivo; resposta bem-sucedida de metadados não homologa relatórios. `connection_revision` identifica a revisão lida; alterações concorrentes invalidam a resposta. Os esquemas instalados enumeram todas as entradas. O limite por requisição continua Meta 40 / LinkedIn 15 e 25 segundos; descoberta LinkedIn pede 10 contas para comportar leitura de nomes.

`save-schedule` aceita `label` (até 120 caracteres) e `next_at` (Unix UTC) opcionais. Sem `next_at`, preserva o valor anterior; agenda nova usa agora + 60 segundos. Mantém último job e código. A interface não altera a consulta ao editar agenda: para consulta diferente, crie outra agenda. Contratos públicos de relatórios e Lead Reader não mudaram.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.

## Alterações de contrato na 0.7.0

- Nova `meta/health` (POST `/wp-json/f3-meta/v1/health`, entrada `{}` fechada): leitura, administrador, mode=read, local_effect=none, remote_effect=none. Saída: identidade do pacote, `state` ok/degraded, `issues[]` (`code`, `action`, e `schedule_id/label/lag_seconds/last_code/count` quando aplicável), `active_schedules`, `worker_required`, `queue` (`oldest_due_at`, `oldest_due_lag_seconds`, `migration_pending`, `unreadable_jobs`, `migration`), `cron`, `maintenance`, `notification`, `repair=not_attempted`.
- `meta/audit`: entrada aceita `since` opcional (inteiro ≥ 0, Unix em segundos); saída acrescenta `order=newest_first` e `since`. Paginação por `offset/next_offset` mantida (50 por página).
- Códigos novos de diagnóstico: `queue_record_unreadable`, `maintenance_missing`. Demais operações, schemas e envelopes iguais aos da 0.6.0.
- `meta/documentation`: o teto de `offset` passa de 100000 para 16777216 bytes. Antes, um documento maior que 100 KB (o `input-schemas.json` do LinkedIn tem cerca de 117 KB) não podia ser lido até o fim em páginas pequenas pela operação.
- Auditoria e efeitos: toda operação despachada pelo painel, REST, ability ou MCP grava uma linha no registro de auditoria local (bucket `audit`, retenção de 30 dias) e atualiza `f3_meta_audit_health` quando muda; a leitura documental é a única exceção. `local_effect` descreve o estado operacional (configuração, fila, agendas, credenciais, histórico) e não conta essa linha: `none` significa que nada disso muda.


## Correção 0.7.1 — registros ilegíveis

Jobs cujo ciphertext ou JSON interno não pode ser lido são isolados com `queue_state=unreadable`, sem reescrever payload, revisão, timestamps ou retenção. O worker trata também jobs já indexados; eles deixam de ocupar repetidamente as 20 posições executáveis. Migração e retenção usam a mesma trava e conferência de revisão/payload; registros legíveis, alterados concorrentemente ou com falha transitória de banco não recebem essa marca.

Se a agenda aponta para um job ilegível, `meta/health` e `meta/status` retornam diagnóstico degradado com `schedule_job_unreadable` e nome da agenda. Health continua sem reparo operacional e status mantém a recuperação explícita do evento. O aviso de ilegibilidade permanece no diagnóstico, fora do e-mail horário. `queue_record_unreadable` informa a contagem já isolada.

A restauração dos salts ou a reparação de dados exige avaliação do administrador. Registros isolados não voltam automaticamente à fila e não são apagados pela retenção; não há reautorização ou exportação automática de conteúdo ilegível.

## Revisão 0.8.0

Os 34 IDs e schemas públicos são idênticos à 0.7.1. `Store::decode` é um auxiliar de implementação que centraliza as regras existentes de JSON/cifra, sem novo endpoint. O isolamento usa o snapshot exato sob lock e CAS; não altera formato de registros, schema SQL ou códigos de erro. Com MCP 0.29.1, falha retryable sem prova explícita de ausência de efeito permanece conservada pelo transporte. Não inferir applied=false nem mudar a chave para contornar efeito incerto.
