# Segurança e dados — 0.8.0

Credenciais, resultados, cursores, diários e exportações são cifrados com chave derivada dos salts do site e do blog. Backup deve incluir banco e salts. Não há URL pública de exportação. Nunca coloque tokens em tickets, documentação ou capturas de tela. Trocar salts pode tornar os dados cifrados ilegíveis.

Ativos vazios significam nenhum ativo autorizado. Todas as entradas humanas exigem manage_options. Tarefas revalidam o usuário de origem, concessão do transporte, seleção e contexto antes do HTTP e antes da entrega persistente. Revogação suspende a coleta e impede leitura local. SDK de consumidor explicitamente concedido não depende de usuário WordPress autenticado.

HTTP usa hosts fixos, caminhos permitidos, TLS, nenhuma redireção, limite de tempo/bytes e quota local por conexão. Dados da API nunca são interpretados como instruções ou caminhos executáveis. CSV neutraliza prefixos de fórmula. Auditoria guarda operação, identidade e código; não guarda token, secret ou payload de leads.

Desativação e desinstalação preservam dados cifrados; removem somente cron deste plugin. Remoção definitiva de dados exige procedimento administrativo deliberado com backup. Não há limpeza automática de dados de outros plugins.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.
