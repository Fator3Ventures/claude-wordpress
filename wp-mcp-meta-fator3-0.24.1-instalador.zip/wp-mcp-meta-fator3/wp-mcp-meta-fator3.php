<?php
/**
 * Plugin Name: Fator3 MCP Meta
 * Plugin URI: https://github.com/Fator3Ventures/claude-wordpress
 * Description: Instagram profissional e Páginas do Facebook pelo Facebook Login: perfil, mídias, Stories, insights, demografia e histórico, com coletas agendadas e exportação em CSV e JSON, pela Abilities API e pelo Fator3 MCP. Meta Ads somente leitura, com histórico diário e SDK local. Pixel, CAPI e contatos ficam no Fator3 Site Core. Configuração em Ferramentas → Fator3 MCP Meta.
 * Version: 0.24.1
 * Requires at least: 7.1.4
 * Requires PHP: 8.3
 * Author: Fator3
 * Author URI: https://www.fator3.com.br
 * License: GPL-2.0-or-later
 * Text Domain: wp-mcp-meta-fator3
 * Update URI: https://fator3.com.br/plugins/wp-mcp-meta-fator3
 */
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
if(class_exists(__NAMESPACE__.'\\Config',false))return;
require_once __DIR__.'/includes/Config.php';
require_once __DIR__.'/includes/Support.php';
require_once __DIR__.'/includes/Connections.php';
require_once __DIR__.'/includes/ProviderDiagnostic.php';
require_once __DIR__.'/includes/Http.php';
require_once __DIR__.'/includes/Queue.php';
require_once __DIR__.'/includes/ExecutionBudget.php';
require_once __DIR__.'/includes/Ads.php';
require_once __DIR__.'/includes/AdOrigin.php';
require_once __DIR__.'/includes/AdsReader.php';
require_once __DIR__.'/includes/Monitoring.php';
require_once __DIR__.'/includes/MonitoringReader.php';
require_once __DIR__.'/includes/Worker.php';
require_once __DIR__.'/includes/AbilityLabels.php';
require_once __DIR__.'/includes/Catalog.php';
require_once __DIR__.'/includes/InsightDiagnostics.php';
require_once __DIR__.'/includes/StoryArchive.php';
require_once __DIR__.'/includes/MessagePrivacy.php';
require_once __DIR__.'/includes/Messaging.php';
require_once __DIR__.'/includes/Credentials.php';
require_once __DIR__.'/includes/ConnectionChanges.php';
require_once __DIR__.'/includes/CollectionState.php';
require_once __DIR__.'/includes/History.php';
require_once __DIR__.'/includes/HistoryExport.php';
require_once __DIR__.'/includes/Retention.php';
require_once __DIR__.'/includes/Adapter.php';
require_once __DIR__.'/includes/Schemas.php';
require_once __DIR__.'/includes/Query.php';
require_once __DIR__.'/includes/Export.php';
require_once __DIR__.'/includes/Documentation.php';
require_once __DIR__.'/includes/Api.php';
require_once __DIR__.'/includes/Admin.php';
register_activation_hook(__FILE__,static function($network=false){if($network)wp_die('Ative a integração individualmente em cada site.');if(PHP_INT_SIZE<8)wp_die('PHP de 64 bits necessário.');if(!Crypto::available())wp_die('Criptografia autenticada necessária.');Store::install();History::install();Result::run(static function(){if(!History::migrationComplete()&&!Store::scan("result","",1))History::migrate();return [];});if(!wp_next_scheduled(Config::KEY.'_maintenance'))wp_schedule_event(time()+3600,'hourly',Config::KEY.'_maintenance');Worker::bootstrap();Worker::ensure();});
register_deactivation_hook(__FILE__,static function(){wp_clear_scheduled_hook(Config::KEY.'_worker');wp_clear_scheduled_hook(Config::KEY.'_maintenance');wp_unschedule_hook(Config::KEY."_messages");});
add_action('plugins_loaded',static function(){if((int)Util::boot(Config::KEY.'_schema',0)!==2){try{Store::install();}catch(\Throwable $e){add_action('admin_notices',static function(){if(current_user_can('manage_options'))echo '<div class="notice notice-error"><p>Fator3 MCP Meta: armazenamento indisponível. Reative o plugin após verificar o banco.</p></div>';});}}},10);
add_action('plugins_loaded',static function(){if((int)Util::boot('f3_meta_history_schema',0)!==1)History::install();Result::run(static function(){Worker::bootstrap();Retention::upgrade();return [];});},11);
add_action('f3_mcp_register_providers',static function($version=1){if($version===1&&class_exists('\\Fator3\\McpFiles\\ExtensionContract'))\Fator3\McpFiles\ExtensionContract::register(Config::SLUG,Config::VERSION,[Config::PREFIX.'/']);});
add_action('wp_abilities_api_categories_init',static function(){if(function_exists('wp_register_ability_category'))wp_register_ability_category(Config::PREFIX,['label'=>Config::NAME,'description'=>'Integração social independente Fator3.']);});
add_action('wp_abilities_api_init',[Api::class,'abilities'],20);
add_action('rest_api_init',[Api::class,'routes']);
add_action('plugins_loaded',static function(){do_action('f3_meta_register_messaging_consumers',Messaging::class);do_action('f3_meta_register_ads_consumers',AdsReader::class,AdsReader::CONTRACT);do_action('f3_meta_register_monitoring_consumers',MonitoringReader::class,MonitoringReader::CONTRACT);},20);add_action(Config::KEY.'_messages',[Messaging::class,'tick'],10,3);
add_action('admin_menu',[Admin::class,'menu']);
add_action('admin_enqueue_scripts',[Admin::class,'assets']);
add_action(Config::KEY.'_maintenance',static function(){Worker::maintenance();});
add_action('init',static function(){if(!wp_next_scheduled(Config::KEY.'_maintenance'))Result::run(static fn()=>Store::lock('maintenance-event',static function(){if(!wp_next_scheduled(Config::KEY.'_maintenance'))wp_schedule_event(time()+300,'hourly',Config::KEY.'_maintenance');update_option(Config::KEY.'_maintenance_rearmed',['at'=>time(),'next'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null],false);return [];}));},20);
add_action(Config::KEY.'_worker',static function(){try{Jobs::tick();}catch(\Throwable $e){update_option(Config::KEY.'_last_worker',['at'=>time(),'state'=>'failed'],false);}});

if(defined('WP_CLI')&&WP_CLI){
 \WP_CLI::add_command('f3-meta run',static function(){Jobs::tick();\WP_CLI::line(Util::json(get_option(Config::KEY.'_last_worker',[])));});
 \WP_CLI::add_command('f3-meta selftest',static function(){$r=Result::run(static fn()=>SelfTest::run());\WP_CLI::line(Util::json($r));if(!$r['success'])\WP_CLI::halt(1);});
}
