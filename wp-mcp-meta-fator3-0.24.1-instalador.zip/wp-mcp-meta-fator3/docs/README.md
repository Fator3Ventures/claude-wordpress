# Fator3 MCP Meta — índice da documentação

Esta documentação acompanha a versão instalada 0.24.1 do plugin `wp-mcp-meta-fator3` (nome exibido **Fator3 MCP Meta**). Ela descreve o estado atual do pacote. O histórico de versões fica só em CHANGELOG.md.

## O que é o plugin

O Fator3 MCP Meta lê dados do Instagram profissional, de Páginas do Facebook e de contas de anúncios da Meta, guarda o resultado cifrado no WordPress e oferece coletas agendadas, histórico e exportação CSV/JSON. Ele expõe 47 operações com prefixo `meta/`, pelo painel, pela REST `f3-meta/v1`, pela Abilities API e pelo Fator3 MCP.

O plugin é de leitura em relação à Meta: não publica, não altera anúncios e não gasta verba. Pixel/CAPI, contatos e Meta Lead Ads ficam no Fator3 Site Core. Gestão e escrita de anúncios ficam no MCP oficial da Meta. SPECIFICATION.md detalha responsabilidades e limites.

## Como ler

**No painel.** Abra **Ferramentas → Fator3 MCP Meta → Ajuda**. A lista mostra os documentos por tema, com título e resumo. Escolha um documento e use **Ler documento completo**; a leitura termina com o aviso de leitura completa. Abrir a ajuda não consulta a Meta e não exige token.

**Pelo MCP ou pela REST.** Chame `meta/documentation` com `{"document":"index"}`. O índice traz, para cada um dos 32 documentos instalados, nome, tamanho, SHA-256, título, resumo e tema, além do mapa de temas. Para ler um documento, envie `document`, `offset` e `limit_bytes`; continue por `next_offset` repetindo `expected_revision`. As regras completas de leitura estão em CONTRACTS.md, seção “Leitura da documentação”.

Toda leitura exige um usuário com `manage_options`. A leitura documental não consulta a Meta, não grava auditoria e não lê caminhos fora do índice.

## Mapa dos documentos lógicos

| Documento lógico | Arquivo principal | Complementos |
|---|---|---|
| Índice | README.md | — |
| Especificação | SPECIFICATION.md | SECURITY.md, RETENTION.md |
| Configuração | CONFIGURATION.md | ADMINISTRATION.md |
| Uso | USAGE.md | EXAMPLES.md, ADMINISTRATION.md |
| Contratos | CONTRACTS.md | REFERENCE.md, input-schemas.json, output-schema.json, abilities-pt-br.json, SDK-PHP.md |
| Guia para agentes | AGENTS.md | TROUBLESHOOTING.md |
| Operação | OPERATIONS.md | WORKER.md, EXECUTION-BUDGET.md, MIGRATION.md, RETENTION.md |
| Notas da versão | CHANGELOG.md | MIGRATION.md |

REFERENCE.md e EXAMPLES.md são gerados no build: o primeiro a partir do registro de operações do código, o segundo a partir de execuções reais em WordPress de laboratório. Os quatro arquivos JSON também são gerados.

## Roteiro por tarefa

| Tarefa | Leia |
|---|---|
| Entender o que o plugin faz e não faz | SPECIFICATION.md |
| Instalar ou atualizar | MIGRATION.md, depois OPERATIONS.md |
| Cadastrar a primeira conexão | CONFIGURATION.md, depois USAGE.md (sequência 1) |
| Usar o painel | ADMINISTRATION.md |
| Escolher ativos e fazer a primeira consulta | USAGE.md (sequências 2 e 3) |
| Criar coletas e agendas | USAGE.md (sequência 4), WORKER.md |
| Consultar o histórico e exportar | USAGE.md (sequência 5) |
| Operar por agente (MCP) | AGENTS.md, CONTRACTS.md, REFERENCE.md |
| Investigar uma falha | TROUBLESHOOTING.md, COLLECTION-DIAGNOSTICS.md |
| Entender `budget_exhausted` | EXECUTION-BUDGET.md |
| Conferir quanto tempo os dados ficam guardados | RETENTION.md |
| Ler Meta Ads | META-ADS.md; consumidor local em META-ADS-READER.md |
| Monitorar atividades e datasets | MONITORING.md; integração com o Site Core em CORE-MONITORING.md |
| Configurar conversas do Instagram | INSTAGRAM-MESSAGING.md; eliminação em MESSAGE-PRIVACY.md |
| Arquivar Stories | STORY-ARCHIVE.md |
| Diagnosticar insights de Páginas | PAGE-DIAGNOSTICS.md, PAGE-VIEWS.md |
| Integrar outro plugin pelo SDK local | SDK-PHP.md |
| Saber o que mudou nesta versão | CHANGELOG.md |

## Guias por recurso

- ADMINISTRATION.md — painel: abas, primeiros passos, formulários e efeitos de cada botão.
- TROUBLESHOOTING.md — sintomas, causas prováveis e ação.
- SECURITY.md — cifragem, autorização, guarda das chamadas HTTP e privacidade.
- MIGRATION.md — instalação limpa e atualização direta.
- RETENTION.md — política de preservação dos dados.
- WORKER.md — fila, worker, manutenção horária, saúde e avisos por e-mail.
- EXECUTION-BUDGET.md — orçamento local de chamadas e tempo por execução.
- COLLECTION-DIAGNOSTICS.md — resultado parcial, erros do fornecedor e estado das agendas.
- META-ADS.md e META-ADS-READER.md — leitura de Meta Ads e consumidor local.
- MONITORING.md e CORE-MONITORING.md — atividades de anúncios, qualidade de datasets e integração com o Site Core.
- INSTAGRAM-MESSAGING.md e MESSAGE-PRIVACY.md — conversas, webhook, entrega ao Site Core e eliminação local.
- STORY-ARCHIVE.md — métricas de Stories e arquivo privado.
- PAGE-DIAGNOSTICS.md e PAGE-VIEWS.md — insights de Páginas.
- SDK-PHP.md — os três SDKs locais e seus ganchos de registro.
- messaging-privacy-schema.json — schema gerado do contrato de eliminação.
