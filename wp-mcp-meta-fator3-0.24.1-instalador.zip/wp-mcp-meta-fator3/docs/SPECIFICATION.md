# Especificação do Fator3 MCP Meta

Este documento descreve o objetivo do plugin, o que ele faz, o que deliberadamente não faz, os dados que guarda, os efeitos de cada tipo de operação e os limites fixos. Vale para a versão instalada 0.24.1.

## Objetivo

Dar ao administrador do site e aos agentes autorizados uma leitura auditável dos dados da Meta (Instagram profissional, Páginas do Facebook, Meta Ads e datasets), com preservação local de longo prazo. O plugin funciona sozinho: o painel, o histórico e a documentação não dependem de outro plugin Fator3. O Fator3 MCP é necessário apenas para o acesso remoto pelo protocolo MCP.

## Responsabilidades

| Área | O plugin faz |
|---|---|
| Conexões | Guarda conexões cifradas (aplicativo, token, validade, ativos selecionados, usuários associados, retenção, versão da Graph API). Confere a credencial na Meta antes de gravar uma credencial nova. |
| Relatórios | Consulta uma página por vez de relatórios do Instagram, do Facebook, de Meta Ads e de datasets, por um catálogo fechado de campos. |
| Coletas | Cria coletas persistentes (jobs), executa uma página por passo, retoma após interrupção e agenda execuções periódicas pelo cron do WordPress. |
| Histórico | Mantém um histórico cifrado, deduplicado por chave lógica, independente da retenção das coletas. Consulta e exporta em CSV ou JSON. |
| Conversas | Lê metadados de conversas do Instagram (sem texto), recebe webhook assinado e entrega a primeira mensagem disponível ao consumidor local do Site Core, quando autorizado. |
| Stories | Arquiva metadados e miniatura reduzida de Stories observados nas coletas. |
| SDKs locais | Oferece três contratos PHP para outros plugins do mesmo site: leitor de Meta Ads, leitor de monitoramento e mensagens. Cada consumidor precisa de concessão explícita. |
| Diagnóstico | Mostra saúde local, estado da fila e das agendas, auditoria e diagnóstico sanitizado das recusas da Meta. |
| Documentação | Serve esta documentação pelo painel e por `meta/documentation`. |

## O que o plugin não faz

- Não cria, edita, pausa, publica nem gasta em anúncios. A gestão de anúncios fica no MCP oficial da Meta, usado pelo agente.
- Não publica conteúdo, não responde nem envia mensagens.
- Não implementa Pixel, Conversions API, Meta Lead Ads nem contatos: isso fica no Fator3 Site Core.
- Não faz OAuth interativo. A credencial é um token informado manualmente.
- Não baixa vídeo completo, texto de mensagens ou anexos.
- Não exporta para Google Sheets ou BigQuery e não cria URL pública de arquivo.
- Não lê opções nem tabelas privadas de outros plugins.
- Não comprova sozinho que uma métrica existe para todo ativo: a disponibilidade depende do ativo, das permissões, da aprovação do aplicativo e da versão da API.

## O que exige algo de fora do plugin

| Recurso | Exige |
|---|---|
| Qualquer leitura remota | Token válido, aplicativo da Meta, escopos concedidos e ativo selecionado na conexão |
| Insights de Páginas | `read_insights` e `pages_read_engagement` concedidos para a Página |
| Meta Ads e datasets | `ads_read` na conta de anúncios; qualidade de dataset pode exigir permissões adicionais na Meta (MONITORING.md) |
| Conversas do Instagram | Produto de mensagens, App Review e acesso avançado a `instagram_manage_messages` aprovados pela Meta (INSTAGRAM-MESSAGING.md) |
| Criação de contatos a partir de conversas | Consumidor registrado pelo Site Core e autorização explícita nos dois plugins |
| Acesso pelo protocolo MCP | Fator3 MCP ativo e perfil de transporte com a operação autorizada |
| Coletas agendadas | Cron do WordPress acionado por tráfego ou pelo agendador do servidor |

## Dados guardados

Tudo o que é de negócio fica cifrado com chave derivada dos salts do WordPress (SECURITY.md).

| Onde | O quê |
|---|---|
| Tabela `{prefixo}f3_meta_records` | Conexões, agendas, coletas, páginas de resultado, auditoria, exportações, concessões de consumidores, configuração de mensagens, diário de mensagens, bloqueios e recibos de eliminação, arquivo de Stories, diagnósticos de falha, quota remota |
| Tabela `{prefixo}f3_meta_history` | Histórico de métricas por dia, deduplicado |
| Opções `f3_meta_*` | Marcas de schema e migração, estado do worker e da manutenção, saúde da auditoria, aviso operacional e a chave de privacidade de mensagens (cifrada) |
| Cron | Eventos `f3_meta_worker`, `f3_meta_maintenance` e `f3_meta_messages` |

A política de prazo de cada tipo de dado está em RETENTION.md.

## Efeitos das operações

Cada operação declara no registro `mode` (`read` ou `write`), `local_effect` e `remote_effect`. REFERENCE.md traz a tabela gerada do código para todas as 47 operações. As regras gerais são:

- **Remoto.** Toda chamada à Meta é `GET` em host e caminhos fixos. `remote_effect=read` indica que a operação consulta a Meta; nenhuma operação escreve na Meta. A única com `remote_effect=write` é `meta/process-messages`, porque a entrega ao consumidor local pode criar contatos no Site Core.
- **Local.** `local_effect=write` indica que a operação altera configuração, fila, agendas, credenciais, histórico ou concessões. `none` significa que nada disso muda.
- **Auditoria.** Toda operação despachada grava uma linha de auditoria local, inclusive as leituras. A leitura documental é a única exceção. Essa linha não conta como `local_effect`.
- **Diagnóstico.** `meta/health` só observa. `meta/status` observa e, se faltar o evento do worker, rearma o agendamento; por isso é uma operação de escrita local.

## Limites fixos

| Limite | Valor |
|---|---|
| Conexões por site | 100 |
| Agendas por site | 100 |
| Ativos conferidos na gravação de uma credencial | 12 por conexão |
| Chamadas à Meta por operação pública | 40 em 25 segundos (EXECUTION-BUDGET.md) |
| Tempo máximo por chamada HTTP | 8 segundos, sem redirecionamento |
| Corpo de resposta da Meta | menor que 1,8 milhão de bytes |
| Dados devolvidos por operação | 900.000 bytes de JSON; acima disso, `response_limit` |
| Linhas por página de relatório | 1 a 100 |
| Páginas por coleta | até 10.000 |
| Exportação de coleta | 8 MiB de dados |
| Exportação do histórico | 64 MiB |
| Página de documentação | 256 a 65.536 bytes |
| Chave de idempotência | até 64 caracteres, `[A-Za-z0-9][A-Za-z0-9_.-]*` |

## Requisitos de runtime

WordPress 7.1.4 ou superior, PHP 8.3 ou superior de 64 bits, banco com InnoDB e travas nomeadas (`GET_LOCK`), e criptografia autenticada (sodium ou OpenSSL AES-256-GCM). A ativação em rede (multisite) é recusada: ative em cada site.
