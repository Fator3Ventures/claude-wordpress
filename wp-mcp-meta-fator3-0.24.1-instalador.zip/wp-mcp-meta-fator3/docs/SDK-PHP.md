# SDKs locais

Outros plugins do mesmo site podem ler dados do Meta por contratos PHP locais, sem REST, sem MCP e sem token. Este guia reúne os contratos, as regras comuns e os códigos de erro dos consumidores. Cada guia específico detalha seu contrato.

## Contratos

| Contrato | Classe | Gancho | Uso | Guia |
|---|---|---|---|---|
| `meta-ads-reader/1.0.0` | `Fator3\Meta\AdsReader` | `f3_meta_register_ads_consumers` | Ler o acervo diário de Meta Ads | META-ADS-READER.md |
| `meta-ads-monitoring/1.0.0` | `Fator3\Meta\MonitoringReader` | `f3_meta_register_monitoring_consumers` | Ler atividades, contagens e EMQ | MONITORING.md, CORE-MONITORING.md |
| `instagram-first-message/1.0.0` | `Fator3\Meta\Messaging` | `f3_meta_register_messaging_consumers` | Receber a primeira mensagem disponível | INSTAGRAM-MESSAGING.md |
| `instagram-message-erasure/1.0.0` | `Fator3\Meta\Messaging` | (mesmo SDK) | Eliminar dados locais de um remetente | MESSAGE-PRIVACY.md |

Os ganchos são disparados em `plugins_loaded` com prioridade 20. `meta/capabilities` informa os contratos disponíveis na instalação.

## Regras comuns

- **Registro explícito.** O consumidor se registra no gancho e guarda o cliente devolvido. Nada é registrado automaticamente.
- **Concessão explícita.** Os leitores de anúncios e de monitoramento só leem depois que um administrador grava a concessão (`meta/save-ads-grant` ou `meta/save-monitoring-grant`). A entrega de mensagens exige autorização de contatos nos dois plugins.
- **Origem dos dados.** As consultas ao acervo são locais. A extensão meta-ad-origin/1.0.0 faz leituras na Meta, com permissão separada (META-ADS-READER.md). O consumidor não recebe o token.
- **Revalidação.** A origem administrativa da concessão, a conexão, a seleção e as revisões são conferidas antes e depois de cada leitura.
- **Sem acesso privado.** O consumidor não lê tabelas nem opções do Meta e não chama o MCP para ler o próprio site.
- **Envelope.** As respostas usam o envelope do Meta (CONTRACTS.md). Erro ou ausência nunca é zero.

Relatórios e exportações para administradores usam as operações públicas REST ou MCP, não estes SDKs.

## Códigos dos consumidores

| Código | Significado |
|---|---|
| `consumer_unavailable` | Consumidor não registrado ou configuração indisponível |
| `consumer_not_ready` | Configuração incompleta (conexão, conta, revisão, relatórios ou datasets) |
| `consumer_conflict` | ID já registrado neste processo |
| `contract_mismatch` | Contrato pedido diferente do oferecido |
| `consumer_scope_mismatch` | Leitura ou concessão fora da seleção do consumidor |
| `grant_revoked` | Concessão ausente, revogada ou sem o relatório pedido |

## Fronteiras

Pixel/CAPI e Meta Lead Ads ficam no Site Core; gestão e escrita de anúncios ficam no MCP oficial da Meta. O Core mantém ingestão, deduplicação comercial, consentimento, privacidade e avisos. Não há exportação para Sheets ou BigQuery.
