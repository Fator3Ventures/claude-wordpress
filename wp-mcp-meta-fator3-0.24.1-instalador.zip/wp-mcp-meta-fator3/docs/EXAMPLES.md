# Exemplos capturados

Documento gerado pelo build a partir de execução real do plugin 0.24.1 em WordPress de laboratório isolado (captura em 2026-11-11T05:28:51Z), sem acesso à rede: a chamada ao fornecedor do exemplo parcial foi simulada no laboratório. Identificadores, nomes e contas são sintéticos. Não edite à mão.

## Gravar conexão sem credencial

- Tipo: sucesso
- Operação: `meta/save-connection`

Entrada:

```json
{
  "connection_id": "exemplo-alfa",
  "expected_revision": 0,
  "label": "Exemplo Alfa",
  "enabled": false,
  "retention_mode": "finite",
  "retention_days": 90,
  "assets": {
    "instagram": [
      "17841400000000001"
    ]
  },
  "users": [
    1
  ]
}
```

Saída:

```json
{
  "success": true,
  "code": "ok",
  "provider": "wp-mcp-meta-fator3",
  "version": "0.24.1",
  "data": {
    "persisted": true,
    "connection": {
      "id": "exemplo-alfa",
      "label": "Exemplo Alfa",
      "client_id": "",
      "application_id": "",
      "enabled": false,
      "expires_at": 0,
      "users": [
        1
      ],
      "assets": {
        "instagram": [
          "17841400000000001"
        ],
        "facebook": [],
        "ads": [],
        "dataset": []
      },
      "forms": [],
      "api_version": "v24.0",
      "created_by": 1,
      "created_at": 1794374931,
      "retention_days": 90,
      "remote_proof": null,
      "retention_mode": "finite",
      "authorization_revision": 2,
      "credential_generation": 1,
      "token_identity": null,
      "token_configured": false,
      "secret_configured": false,
      "updated_by": 1,
      "updated_at": 1794374931,
      "revision": 1,
      "identity": null
    },
    "schedules_rebased": 0,
    "schedules_requiring_review": []
  },
  "avisos": []
}
```

## Ler uma conexão

- Tipo: sucesso
- Operação: `meta/get-connection`

Entrada:

```json
{
  "connection_id": "exemplo-alfa"
}
```

Saída:

```json
{
  "success": true,
  "code": "ok",
  "provider": "wp-mcp-meta-fator3",
  "version": "0.24.1",
  "data": {
    "connection": {
      "id": "exemplo-alfa",
      "label": "Exemplo Alfa",
      "client_id": "",
      "application_id": "",
      "enabled": false,
      "expires_at": 0,
      "users": [
        1
      ],
      "assets": {
        "instagram": [
          "17841400000000001"
        ],
        "facebook": [],
        "ads": [],
        "dataset": []
      },
      "forms": [],
      "api_version": "v24.0",
      "created_by": 1,
      "created_at": 1794374931,
      "retention_days": 90,
      "remote_proof": null,
      "retention_mode": "finite",
      "authorization_revision": 2,
      "credential_generation": 1,
      "token_identity": null,
      "token_configured": false,
      "secret_configured": false,
      "updated_by": 1,
      "updated_at": 1794374931,
      "revision": 1,
      "identity": null
    }
  }
}
```

## Listar agendas sem nenhuma cadastrada

- Tipo: vazio
- Operação: `meta/list-schedules`

Entrada:

```json
{}
```

Saída:

```json
{
  "success": true,
  "code": "ok",
  "provider": "wp-mcp-meta-fator3",
  "version": "0.24.1",
  "data": {
    "schedules": []
  }
}
```

## Recusa de schema com parâmetro identificado

- Tipo: erro
- Operação: `meta/create-job`

Entrada:

```json
{
  "query": {
    "connection_id": "exemplo-alfa",
    "channel": "instagram",
    "account_id": "17841400000000001",
    "report": "relatorio-inexistente"
  },
  "idempotency_key": "exemplo-1"
}
```

Saída:

```json
{
  "success": false,
  "code": "invalid_input",
  "error_code": "invalid_input",
  "provider": "wp-mcp-meta-fator3",
  "message": "Parâmetro query.report com valor não permitido (fora da lista aceita ou repetido).",
  "conflict": false,
  "retryable": false,
  "data": null,
  "details": {
    "schema": "create-job",
    "validation_code": "rest_not_in_enum",
    "field": "query.report",
    "problem": "invalid_value"
  }
}
```

## Consulta a ativo não selecionado na conexão

- Tipo: erro
- Operação: `meta/query`

Entrada:

```json
{
  "connection_id": "exemplo-alfa",
  "channel": "instagram",
  "account_id": "17841400000000002",
  "report": "profile"
}
```

Saída:

```json
{
  "success": false,
  "code": "asset_access_denied",
  "error_code": "asset_access_denied",
  "provider": "wp-mcp-meta-fator3",
  "message": "Ativo não selecionado nesta conexão.",
  "conflict": false,
  "retryable": false,
  "data": null,
  "details": []
}
```

## Gravação com revisão desatualizada

- Tipo: erro
- Operação: `meta/save-connection`

Entrada:

```json
{
  "connection_id": "exemplo-alfa",
  "expected_revision": 0,
  "label": "Exemplo Alfa renomeada"
}
```

Saída:

```json
{
  "success": false,
  "code": "revision_conflict",
  "error_code": "revision_conflict",
  "provider": "wp-mcp-meta-fator3",
  "message": "A conexão mudou. Reabra a conexão antes de salvar.",
  "conflict": true,
  "retryable": false,
  "data": null,
  "details": [],
  "avisos": []
}
```

## Consulta de dataset com parte indisponível

- Tipo: resultado parcial
- Operação: `meta/query`
- Recorte: data.field_catalog reduzido ao primeiro de 9 itens; demais campos da saída completos.

Entrada:

```json
{
  "connection_id": "exemplo-dataset",
  "channel": "dataset",
  "account_id": "19002",
  "ads_account_id": "19001",
  "report": "dataset_quality",
  "date_from": "2026-11-10",
  "date_to": "2026-11-10"
}
```

Saída:

```json
{
  "success": true,
  "code": "ok",
  "provider": "wp-mcp-meta-fator3",
  "version": "0.24.1",
  "data": {
    "contract": "social-reporting/1.1.0",
    "provider": "wp-mcp-meta-fator3",
    "channel": "dataset",
    "connection_id": "exemplo-dataset",
    "connection_revision": 3,
    "account_id": "19002",
    "api_version": "v24.0",
    "request_id": "440e0504-54e7-4c8c-8429-1829fcf00d22",
    "fetched_at": "2026-11-11T05:28:51+00:00",
    "report": "dataset_quality",
    "selection": {
      "connection_id": "exemplo-dataset",
      "channel": "dataset",
      "account_id": "19002",
      "ads_account_id": "19001",
      "report": "dataset_quality",
      "date_from": "2026-11-10",
      "date_to": "2026-11-10"
    },
    "fields": [
      "record_kind",
      "event_name",
      "browser_count",
      "server_count",
      "count_coverage",
      "emq",
      "emq_observed_at",
      "optimized_by",
      "zero_confirmed"
    ],
    "field_catalog": [
      {
        "name": "record_kind",
        "source_field": "record_kind",
        "catalog_revision": "2026-10-29.1",
        "api_version": "v24.0",
        "availability": "requires_remote_validation",
        "historical_horizon_days": null,
        "history_requires_explicit_start": true,
        "retention": "unlimited",
        "aggregation": "preserve_source",
        "temporal": "daily_counts_and_observed_emq"
      }
    ],
    "rows": [
      {
        "id": "41991970466df6f4a1d5ea164520d587a277b913a47cf292b3cb90be093daf96",
        "entity_id": "41991970466df6f4a1d5ea164520d587a277b913a47cf292b3cb90be093daf96",
        "record_kind": "event_counts",
        "dataset_id": "19002",
        "ads_account_id": "19001",
        "event_name": "Lead",
        "date": "2026-11-10",
        "browser_count": 5,
        "server_count": 7,
        "count_coverage": {
          "browser": true,
          "server": true
        },
        "optimized_by": [
          {
            "adset_id": "19003",
            "name": "Conjunto sintético"
          }
        ],
        "optimization_observed_at": "2026-11-11T05:28:51+00:00",
        "zero_confirmed": false,
        "emq": null,
        "emq_status": "separate_observed_snapshot",
        "availability": "available",
        "unavailable_fields": []
      }
    ],
    "timezone": "America/Sao_Paulo",
    "currency": "BRL",
    "temporal": "daily",
    "coverage": {
      "successful_rows": 1,
      "page_successful_rows": 1,
      "unavailable_metrics": [
        "emq"
      ],
      "complete": false,
      "plan_complete": true,
      "all_rows_guaranteed": false,
      "stop_reason": "fields_unavailable",
      "pages": 1,
      "requested_from": "2026-11-10",
      "requested_to": "2026-11-10",
      "errors": [
        {
          "field": "emq",
          "date": "2026-11-10",
          "code": "upstream_validation",
          "http_status": 400,
          "provider_code": 100,
          "provider_subcode": null,
          "observed_at": 1794374931,
          "provider_message": "(#[redigido]) [redigido] de [redigido]: permissão [redigido]",
          "provider_error_user_msg": null,
          "provider_message_redacted": true,
          "provider_type": "OAuthException",
          "request_stage": "emq",
          "provider_api_version": "v24.0",
          "provider_call": "GET /dataset_quality",
          "diagnostic_action": "O código 100 não identifica sozinho a causa. Confira provider_message, provider_call e a versão da API; verifique o parâmetro recusado e a atribuição do dataset usando a mesma credencial."
        }
      ],
      "error_count": 1,
      "errors_sampled": false,
      "last_error": {
        "field": "emq",
        "date": "2026-11-10",
        "code": "upstream_validation",
        "http_status": 400,
        "provider_code": 100,
        "provider_subcode": null,
        "observed_at": 1794374931,
        "provider_message": "(#[redigido]) [redigido] de [redigido]: permissão [redigido]",
        "provider_error_user_msg": null,
        "provider_message_redacted": true,
        "provider_type": "OAuthException",
        "request_stage": "emq",
        "provider_api_version": "v24.0",
        "provider_call": "GET /dataset_quality",
        "diagnostic_action": "O código 100 não identifica sozinho a causa. Confira provider_message, provider_call e a versão da API; verifique o parâmetro recusado e a atribuição do dataset usando a mesma credencial."
      }
    },
    "warnings": [
      "Navegador e servidor podem conter o mesmo evento; não somar como eventos únicos. Cada contagem soma buckets horários distintos de aggregation=event; cobertura integral exige todas as horas do dia.",
      "Ausência, erro ou janela incompleta não significam zero. Zero exige dois valores explícitos e cobertura confirmada.",
      "EMQ é snapshot atual em registro separado, sem reconstrução para o dia das contagens. Conjuntos ativos também são observados na coleta.",
      "Stats documenta sete dias; dados anteriores devolvidos pela origem não comprovam cobertura completa."
    ],
    "next_cursor": null
  }
}
```
