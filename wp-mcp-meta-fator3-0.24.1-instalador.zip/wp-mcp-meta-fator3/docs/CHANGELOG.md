# Notas da versão

A primeira seção descreve a versão instalada. As seções seguintes são **histórico**: registram o que mudou em versões substituídas e não descrevem o comportamento atual. O comportamento atual está nos demais documentos.

## 0.24.1 — 11/11/2026

Na atualização direta de 0.24.0, o catálogo do MCP passa a distinguir a gravação local da concessão da consulta externa por ID. O parâmetro opcional descreve o efeito antes de salvar. A troca preserva as permissões existentes.

## Histórico — 0.24.0 — 11/11/2026

Base da funcionalidade: 0.23.0. O Core pode consultar o anúncio de origem e as mídias vinculadas pela extensão descrita em META-ADS-READER.md. A concessão de consulta por ID é independente da leitura do histórico e começa desligada. Não há mudança de tabelas nem de retenção.

## Histórico — 0.23.0 — 10/11/2026

A atualização direta partia de 0.22.1. Requer WordPress 7.1.4 e PHP 8.3 de 64 bits.

- O diagnóstico de recuperação do cron informa o retorno da tentativa e a manutenção registra quando o worker continua sem evento.
- Primeiros passos verifica token, validade, estado e ativos na mesma conexão. O seletor de conta de anúncios explica como as seleções de datasets são conservadas.
- A descoberta de datasets abandona páginas e respostas atrasadas ao trocar a conta, inclusive ao voltar para a conta anterior.

## Histórico — 0.22.1 — 10/11/2026

Base direta: 0.22.0. Requisitos: WordPress 7.1.4 e PHP 8.3 de 64 bits. Conjunto do Site-Teste: Core 1.80.0, MCP 0.44.0, Google 0.31.0, LinkedIn 0.20.0 e Pipedrive 0.9.0.

- O transporte REST recusa corpos de tipo inválido antes de executar operações, inclusive o reparo de agendamento. A auditoria mantém o evento de recusa sem guardar o identificador enviado em entradas inválidas.
- O Diagnóstico descarta respostas de uma seleção anterior e mantém o resultado da ação mais recente. Voltar à lista limpa as credenciais digitadas, inclusive no formulário de renovação. O atalho de primeiros passos abre um editor visível.
- A atualização preserva configuração, histórico e retenção; não altera tabelas nem os contratos dos consumidores locais.

## Histórico — 0.22.0 — 10/11/2026

**Base de migração:** 0.21.0, por atualização direta (MIGRATION.md). Instalação limpa também suportada. Sem downgrade.

**Conjunto vigente observado no Site-Teste em 10/11/2026:** Core 1.78.0, MCP 0.43.0, Google 0.31.0, LinkedIn 0.19.0, Pipedrive 0.8.0 e, antes da troca, Meta 0.21.0.

**Requisitos de runtime:** WordPress ≥ 7.1.4 e PHP ≥ 8.3 de 64 bits.

### Correções de comportamento

- Recusas de schema identificam o parâmetro: a mensagem nomeia o campo, e `details` passa a trazer `field` (notação de ponto) e `problem`, além de `schema` e `validation_code`. O valor enviado nunca aparece.
- `meta/documentation`: pedir uma página com `offset` maior que zero sem `expected_revision` passa a ser `invalid_input`, com `details.field=expected_revision` e `details.problem=missing_required`. Revisão divergente continua `revision_conflict`.
- No painel, a busca de usuários não envia mais o formulário da conexão ao pressionar Enter, e digitar nela não marca alterações.
- A mensagem de resultado do painel vira aviso fixo e visível, com variantes de sucesso e erro, botão de dispensar e anúncio acessível; some ao trocar de aba.
- Sessão expirada no painel mostra mensagem própria, informando que nada foi gravado.
- Diagnóstico com rótulo em português para todo campo de `health`, `status` e `selftest`, instantes em data e hora UTC e códigos conhecidos traduzidos, com bloco-resumo no topo.
- Em instalação limpa, a ativação conclui a marca de migração do histórico quando não há páginas a migrar. Em atualização, marca e progresso existentes são preservados.
- Rótulo de `meta/status`: “Meta: verificar estado e recuperar agendamento”. ID, schema e descrição inalterados.

### Painel

- Navegação em dois níveis: grupos Configurar, Dados e Suporte, e abaixo só as abas do grupo ativo. Conversas fica em Dados. Os endereços das dez abas não mudaram.
- Conexão em duas subvisões: lista (faixa Primeiros passos enquanto faltar conexão com token ou ativo, cartões com selos e ações **Editar conexão** e **Escolher ativos**, configuração da versão da API) e editor (blocos recolhíveis com resumo do valor atual, **Voltar à lista**).
- Ativos com um canal por vez e um único **Salvar ativos selecionados** para todos os canais.
- Coletas com subvisões Coletas e Agendas; Conversas com subvisões Consulta e Configuração da recepção.
- Diagnóstico com resumo em cartões, detalhes recolhidos e ações separadas por efeito: somente leitura local, altera estado local, consulta a Meta. A versão da API saiu do Diagnóstico e foi para a Conexão.
- Ajuda com lista por tema, título e resumo, e leitura formatada.
- Sem rolagem horizontal nas larguras de tela testadas; nomes acessíveis e foco visível.
- Os textos dos botões existentes não mudaram. ADMINISTRATION.md descreve o painel.

### Documentação

- Manuais reescritos pelo estado atual, organizados por assunto e tarefa; histórico apenas neste arquivo.
- Novos documentos: SPECIFICATION.md, USAGE.md, REFERENCE.md (gerado do registro de operações) e EXAMPLES.md (gerado de execuções reais em laboratório).
- README.md passa a ser índice, com mapeamento para os oito documentos lógicos do padrão Fator3.
- Índice de `meta/documentation` com `title`, `summary` e `topic` por documento e o mapa `topics`; a leitura de um documento devolve `title`.
- Versão e contagens entram nos manuais pelo build; o build reprova documentação inconsistente.

### Contratos alterados

Todos aditivos ou restritos a chamadas que já eram recusadas:

- `invalid_input.details` ganha `field` e `problem`.
- `meta/documentation` sem `expected_revision` em continuação passa de `revision_conflict` para `invalid_input`.
- Índice documental ganha `title`, `summary`, `topic` e `topics`; leitura ganha `title`.
- Rótulo de `meta/status` alterado.

Nenhum schema de entrada mudou. Nenhuma tabela, coluna ou opção de negócio nova. Os efeitos declarados de cada operação são os mesmos da versão-base. SDKs locais inalterados.

### Limites e pendências

- Pedido MCP Meta 27 (coleta e diagnóstico de datasets): aceite externo pendente nos sites korvena.com.br e ctooffice.com.br, com as credenciais desses sites. Não reaberto nesta versão.
- O fornecedor real (Meta) não foi exercitado nesta versão; as provas usam simulador da Graph API.
- Toda operação despachada, inclusive leituras do painel, grava uma linha de auditoria sem expiração; o crescimento é ilimitado por decisão de projeto.

## Histórico — 0.21.0 — 05/11/2026

- Remover a conta de anúncios vinculada a um dataset passou a impedir novas leituras do resultado já armazenado, inclusive partes de exportação preparadas antes.
- Falha de confirmação ao gravar uma parte do histórico deixou a exportação recuperável com o mesmo ID, sem avançar contadores antes da persistência.
- No painel, mudanças de conexão, conta ou consulta passaram a invalidar resultados, cursores e downloads em andamento daquele contexto.
- O índice da ajuda passou a trazer nomes, tamanhos e hashes fixados no build, abrindo e conferindo só o manual pedido.
- Base de migração: 0.20.0.

## Histórico — 0.20.0 — 05/11/2026

- Conexão organizada por tarefa, instruções junto dos campos e remoção de credenciais separada da edição.
- Diagnóstico passou a abrir em modo de observação local; reparo de cron e validação remota viraram ações explícitas.
- Ajuda passou a identificar o documento e a conclusão da leitura.
- PHP mínimo 8.3 e WordPress mínimo 7.1.4. Base de migração: 0.19.0.

## Histórico — 0.19.0 — 01/11/2026 — Pedido 27

- Vínculo de dataset pela conta selecionada (`/act_{conta}/adspixels`), contagens por fonte, projeção mínima de EMQ e preservação independente de dados parciais.
- Diagnóstico sanitizado (`provider_message`, `provider_type`, `fbtrace_id`, `provider_call`, `request_stage`, `diagnostic_action`) em coletas, agendas, auditoria e `health.datasets.diagnostics`.
- Cobertura horária por evento (`count_coverage`) para impedir falso zero.
- Revisão técnica em 01/11/2026 com o SDK oficial e metadados do conector oficial da Meta; páginas de developers.facebook.com retornaram HTTP 429. A correção foi testada com fixtures; o aceite com os tokens dos dois sites do pedido permaneceu pendente.

## Histórico — 0.18.0 — 31/10/2026 — Pedido 26

- `last_error_at`, `last_error_superseded` e `last_error_state` em `meta/list-schedules` e `health.schedules`, calculados na leitura, sem migração.
- O aceite real em korvena.com.br ficou com a frota.

## Histórico — 0.17.0 — 30/10/2026 — Pedido 25

- Corrigido o orçamento herdado no despacho de agendas de Ads e datasets: a 0.16.0 podia despachar com estado de uma fase anterior, já esgotado ou vencido; a 0.17.0 passou a alocar orçamento novo antes do despacho.
- Prioridade às últimas coletas de agendas ativas; cargas retroativas usam o tempo restante.
- Consumo e prazo por fase em `health` e `list-schedules`; incidente com e-mail após 24 horas de bloqueio local.

## Histórico — 0.16.0 — 29/10/2026

- Documentação operacional do consumidor de monitoramento do Site Core (pedidos Core 340/341). Corrigida a indicação anterior de que esse consumidor estava pendente. Base: 0.15.0.

## Histórico — 0.15.0 — 29/10/2026 — Pedidos 22 a 24

- Avisos estruturados de credenciais (`avisos`) em sucesso e erro; formatos incomuns conferidos na Meta em vez de recusados.
- Coletas diárias `ads_activity` e `dataset_quality`, acervo cifrado sem prazo e EMQ observado à parte.
- Novo SDK `meta-ads-monitoring/1.0.0` com concessão explícita. Base: 0.14.0.

## Histórico — 0.14.0 — Pedido 22

- Removida a exigência de prefixo fixo no token. A mesma validação passou a valer para salvar, renovar e trocar identidade. Base: 0.13.0.

## Histórico — 0.13.0 — 28/10/2026 — Pedidos 20 e 21

- Canal `ads` somente leitura (`ads_read`), insights diários em quatro níveis, histórico sem prazo, revisita de atribuição, carga retroativa, exportação e SDK `meta-ads-reader/1.0.0`. Três operações de concessão acrescentadas.
- Coletas passaram a preservar métricas disponíveis quando outras estão ausentes, suprimidas ou recusadas.
- Referências consultadas em 28/10/2026: SDK oficial em Python da Meta e parâmetros públicos do Insights; developers.facebook.com limitou a leitura automatizada (HTTP 429).
- Nota operacional da época: o contorno A-METASEG-2710 podia ser recomposto pela frota depois da implantação; o pacote não altera agendas de produção.
- A comparação de Ads com o Gerenciador de Anúncios nas contas de korvena.com.br e ctooffice.com.br ficou como aceite externo da frota.

## Histórico — 0.12.0 — 26/10/2026

- Contrato `instagram-message-erasure/1.0.0` para eliminação local por remetente ou evento, com bloqueio durável e recibo. A detecção de transação ativa foi exercitada no MySQL 8.0.41 do Site-Teste.

## Histórico — 0.11.1 — 26/10/2026

- Correção documental após a instalação da 0.11.0: referências a auditoria de 30 dias e exportações de 24 horas removidas.

## Histórico — 0.11.0 — 26/10/2026 — Pedidos 18 e 19

- Seis operações de conversas, configuração, contatos e arquivo; webhook assinado; entrega da primeira mensagem ao Site Core, desligada por padrão.
- Novas métricas e detalhamentos de Stories; arquivo cifrado de Stories com miniatura privada.
- Política de preservação: histórico, arquivo, recibos, auditoria e exportações sem expiração automática. A política substituiu o plano inicial de arquivo de 30 dias e de diário com teto de quantidade.

## Histórico — 0.10.1 e 0.10.0 — 24/10/2026 — Pedidos 16 e 17

- `meta/switch-identity` ganhou `label`. A prévia de troca de identidade passou a aparecer junto do formulário que a pediu.
- Códigos próprios para Stories indisponíveis; conferência em `/me` antes de declarar revogação da conexão; aviso único por incidente com a causa medida. O aviso passou a usar o mapa `active` na opção `f3_meta_operation_notice`.

## Histórico — 0.9.0 — 23/10/2026 — Pedido 15

- Conferência da credencial na Meta antes de gravar; identidade, aplicativo, validade e permissões visíveis.
- Nova operação `meta/switch-identity`, com simulação e confirmação vinculada.

## Histórico — 0.8.0 e 0.7.1 — 23/10/2026

- Isolamento de coletas ilegíveis decidido sobre o mesmo conteúdo lido sob trava; `schedule_job_unreadable`; o worker deixou de reprocessar coletas ilegíveis.
- Orientação de idempotência: `retryable` não comprova ausência de efeito.

## Histórico — 0.7.0 — 22/10/2026

- Nova `meta/health` (leitura). `meta/audit` em ordem do mais recente, com `since`.
- Marcas de schema lidas pelo autoload, sem consulta própria por requisição.
- Coletas ilegíveis isoladas; manutenção ausente recriada na requisição seguinte.
- Teto de `offset` de `meta/documentation` elevado para 16 MiB.

## Histórico — 0.6.0 — 22/10/2026 — Pedidos 13 e 14

- Recuperação do evento do worker na manutenção e no status; aviso por e-mail; fila indexada por estado e vencimento (schema 2), com migração dos registros da 0.5.0 em lotes de 100.

## Histórico — 0.5.0 — 22/10/2026 — Pedido 12

- Rótulos em português e descrições específicas para todas as habilidades; catálogo publicado em abilities-pt-br.json.

## Histórico — 0.4.1 e 0.4.0

- Abas por assunto com endereço próprio; seleção de usuários, contas e objetos pelo nome; operação `meta/admin-options`; agendas com nome e próxima execução.
- `page_views_total` aceito em `page_insights` (Meta 11). A frota informou o aceite da comparação diária com outra fonte nas Páginas de CTO Office e Korvena em 21/10/2026.

## Histórico — 0.3.0

- Erros da Graph com código e subcódigo preservados; inspeção de permissões do token de cada Página; consulta individual para grupos vazios; múltiplos buckets explicitados.

## Histórico — 0.2.0

- Permissão `manage_options` em todas as entradas; documentação instalada com índice e leitura paginada; canal Facebook; histórico cifrado; carga retroativa; exportação em partes; renovação validada de token.
