<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Config {
 public const VERSION='0.24.1'; public const SLUG='wp-mcp-meta-fator3'; public const NAME='Fator3 MCP Meta';
 public const KEY='f3_meta'; public const TABLE='f3_meta_records'; public const PREFIX='meta';
 public const REST='f3-meta/v1'; public const CHANNELS=['instagram','facebook','ads','dataset'];
 public const API_VERSION='v24.0'; public const API_PATTERN='/^v[0-9]{1,2}\.[0-9]{1,2}$/D';
 public const DIR=__DIR__.'/../'; public const FILE=__DIR__.'/../wp-mcp-meta-fator3.php';
}
