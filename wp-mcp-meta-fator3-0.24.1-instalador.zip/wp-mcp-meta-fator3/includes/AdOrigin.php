<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Project one authorized ad. Only provider-derived identifiers can trigger secondary GETs. */
final class AdOrigin {
    public const CONTRACT='meta-ad-origin/1.0.0';
    private const FIELDS='id,account_id,name,adset_id,campaign_id,adset{id,name},campaign{id,name},creative{id,body,title,link_url,object_url,call_to_action,call_to_action_type,object_type,object_story_spec,asset_feed_spec,image_url,image_hash,thumbnail_url,video_id,effective_object_story_id,instagram_permalink_url}';
    private static function text($s): ?string {return is_string($s)&&trim($s)!==''?wp_strip_all_tags($s):null;}
    private static function id($s): ?string {return is_string($s)&&preg_match('/^[0-9]{1,40}$/D',$s)?$s:null;}
    private static function hash($s): ?string {return is_string($s)&&preg_match('/^[a-fA-F0-9]{32}$/D',$s)?$s:null;}
    private static function url($s,bool $media=false): ?string {
        if(!is_string($s)||strlen($s)>16384||preg_match('/[\x00-\x20\\\\]/',$s))return null;
        $p=wp_parse_url($s);if(!$p||($p['scheme']??'')!=='https'||empty($p['host'])||isset($p['user'])||isset($p['pass'])||isset($p['port']))return null;
        $host=strtolower($p['host']);if(!preg_match('/^(?:[a-z0-9-]+\.)+[a-z]{2,63}$/D',$host)||preg_match('/(?:^|\.)(?:local|localhost|internal)$/D',$host))return null;
        if($media&&!preg_match('/(?:^|\.)(?:fbcdn\.net|cdninstagram\.com|facebook\.com|fbsbx\.com)$/D',$host))return null;
        if(preg_match('/(?:^|[?&#;])(?:access_token|appsecret_proof|client_secret|app_secret|input_token)=/i',rawurldecode($s)))return null;
        return $s;
    }
    private static function address($s): ?array {
        $url=self::url($s,true);if(!$url)return null;
        $query=(string)wp_parse_url($url,PHP_URL_QUERY);$expiry=null;
        if(preg_match('/(?:^|&)oe=([0-9a-f]{8})(?:&|$)/i',$query,$m))$expiry=(int)hexdec($m[1]);
        return ['url'=>$url,'expires_at'=>$expiry?gmdate('c',$expiry):null,'expiry_source'=>$expiry?'cdn_oe_hint':'unknown'];
    }
    private static function item(array $d): array {
        $cta=is_array($d['call_to_action']??null)?$d['call_to_action']:[];
        return ['primary_text'=>self::text($d['message']??$d['body']??null),'title'=>self::text($d['name']??$d['title']??null),
            'description'=>self::text($d['description']??$d['link_description']??null),'button'=>self::text($cta['type']??$d['call_to_action_type']??null),
            'destination'=>self::url($cta['value']['link']??$d['link']??$d['link_url']??$d['object_url']??null),
            'image_hash'=>self::hash($d['image_hash']??$d['hash']??null),'image'=>self::address($d['image_url']??$d['picture']??null),
            'video_id'=>self::id($d['video_id']??null),'thumbnail'=>self::address($d['thumbnail_url']??null),'playback'=>null];
    }
    /** Inherit without assigning assets from one dynamic variant to another. */
    private static function fill(array $a,array $b): array {foreach($a as $k=>$v)if($v===null&&isset($b[$k]))$a[$k]=$b[$k];return $a;}
    public static function read(array $c,string $account,string $id,callable $guard): array {
        $notices=[];$now=gmdate('c');$calls=0;$deadline=microtime(true)+25;
        // Respect the transport budget of the caller; also bound this SDK call independently.
        $get=static function(string $path,array $q)use($c,$guard,&$calls,$deadline){
            if(++$calls>8||microtime(true)>$deadline-2)throw new Fault('budget_exhausted','Limite da consulta do anúncio atingido.');
            return Http::request($c,$path,$q,'GET',null,$guard)['body'];
        };
        $optional=static function(string $path,array $q,string $part)use($get,&$notices){
            try{return $get($path,$q);}catch(Fault $e){
                if(!in_array($e->reason,['asset_access_denied','resource_not_found','upstream_validation','upstream_error','budget_exhausted'],true))throw $e;
                $notices[]=$part.':'.$e->reason;return [];
            }
        };
        $page=$get('act_'.$account.'/ads',['fields'=>self::FIELDS,'filtering'=>Util::json([['field'=>'ad.id','operator'=>'IN','value'=>[$id]]]),'limit'=>2]);
        $rows=$page['data']??null;if(!is_array($rows)||!array_is_list($rows)||count($rows)>1)throw new Fault('upstream_invalid','Resposta de seleção de anúncio inconsistente.');
        if(!$rows)throw new Fault('resource_not_found','Anúncio não encontrado nesta conta.');$ad=$rows[0];
        if(($ad['id']??null)!==$id||($ad['account_id']??null)!==$account)throw new Fault('asset_access_denied','O anúncio não pertence à conta autorizada.');
        $entity=static function(string $k)use($ad){
            $v=$ad[$k]??[];$id=self::id($ad[$k.'_id']??$v['id']??null);
            if(isset($v['id'],$ad[$k.'_id'])&&$v['id']!==$id)throw new Fault('upstream_invalid','A hierarquia do anúncio é inconsistente.');
            return ['id'=>$id,'name'=>self::text($v['name']??null)];
        };
        $campaign=$entity('campaign');$adset=$entity('adset');$cr=is_array($ad['creative']??null)?$ad['creative']:[];
        $spec=$cr['object_story_spec']??[];$d=$spec['video_data']??$spec['link_data']??$spec['photo_data']??$spec['template_data']??[];
        $main=self::fill(self::item((array)$d),self::item($cr));$feed=$cr['asset_feed_spec']??[];$variants=[];$cards=[];
        foreach(['bodies'=>'primary_text','titles'=>'title','descriptions'=>'description','link_urls'=>'destination','call_to_action_types'=>'button'] as $key=>$field){
            $variants[$field]=[];$list=$feed[$key]??[];if(!is_array($list))continue;
            if(count($list)>50)$notices[]='variant_limit';
            foreach(array_slice($list,0,50) as $x){
                $v=$field==='destination'?self::url($x['website_url']??null):self::text(is_array($x)?($x['text']??null):$x);
                if($v!==null&&!in_array($v,$variants[$field],true))$variants[$field][]=$v;
            }
            if($main[$field]===null&&count($variants[$field])===1)$main[$field]=$variants[$field][0];
        }
        $media=[];foreach(['images','videos'] as $k){$list=$feed[$k]??[];if(!is_array($list))continue;if(count($list)>50)$notices[]='variant_limit';foreach(array_slice($list,0,50) as $x)if(is_array($x))$media[]=self::item($x);}
        $children=$d['child_attachments']??[];if(is_array($children)){if(count($children)>50)$notices[]='variant_limit';foreach(array_slice($children,0,50) as $x)if(is_array($x))$cards[]=self::item($x);}
        $story=$cr['effective_object_story_id']??null;if(!is_string($story)||!preg_match('/^[0-9]{1,40}(?:_[0-9]{1,40})?$/D',$story))$story=null;
        if($story&&!$main['primary_text']&&!$variants['primary_text']){
            $post=$optional($story,['fields'=>'id,message,attachments{title,description,media,type,target}'],'story');
            if(($post['id']??null)===$story){$aa=$post['attachments']['data']??[];$att=is_array($aa)&&count($aa)===1?$aa[0]:[];$main=self::fill($main,self::item(['message'=>$post['message']??null,'title'=>$att['title']??null,'description'=>$att['description']??null,'image_url'=>$att['media']['image']['src']??null]));}
        }
        $items=array_merge([$main],$cards,$media);$hashes=[];$videos=[];
        foreach($items as $x){if($x['image_hash']&&!$x['image'])$hashes[$x['image_hash']]=true;if($x['video_id'])$videos[$x['video_id']]=true;}
        $images=[];if($hashes){
            $requested=array_slice(array_keys($hashes),0,50);if(count($hashes)>50)$notices[]='image_lookup_limit';
            $r=$optional('act_'.$account.'/adimages',['fields'=>'hash,url','hashes'=>Util::json($requested),'limit'=>50],'images');
            foreach($r['data']??[] as $x)if(is_array($x)&&isset($hashes[$x['hash']??'']))$images[$x['hash']]=self::address($x['url']??null);
        }
        $streams=[];if(count($videos)>4)$notices[]='video_lookup_limit';
        foreach(array_slice(array_keys($videos),0,4) as $vid){$vid=(string)$vid;$v=$optional($vid,['fields'=>'id,source,picture,thumbnails{uri,is_preferred}'],'video');
            if(($v['id']??null)!==$vid)continue;$thumb=self::address($v['picture']??null);
            foreach($v['thumbnails']['data']??[] as $t)if(!empty($t['is_preferred'])||!$thumb)$thumb=self::address($t['uri']??null)??$thumb;
            $streams[$vid]=[self::address($v['source']??null),$thumb];}
        $enrich=static function(array $x)use($images,$streams){$x['image']??=$images[$x['image_hash']??'']??null;
            if($x['video_id']){[$x['playback'],$thumb]=$streams[$x['video_id']]??[null,null];$x['thumbnail']??=$thumb??$x['image'];}return $x;};
        $main=$enrich($main);$media=array_map($enrich,$media);$cards=array_map($enrich,$cards);
        if(count($media)===1&&!$cards)$main=self::fill($main,$media[0]);
        $kind=$cards?'carousel':(count($media)>1?'dynamic':($main['video_id']?'video':($main['image']||$main['image_hash']?'image':strtolower(self::text($cr['object_type']??null)??'unknown'))));
        if(!$cr)$notices[]='creative_unavailable';
        $urls=static fn(array $x): array=>$x+['image_url'=>$x['image']['url']??null,'thumbnail_url'=>$x['thumbnail']['url']??null,'playback_url'=>$x['playback']['url']??null];
        $main=$urls($main);$media=array_map($urls,$media);$cards=array_map($urls,$cards);
        $main+=['id'=>self::id($cr['id']??null),'media_type'=>$kind,'variants'=>$variants,'media_variants'=>$media,'cards'=>$cards,'effective_object_story_id'=>$story,'instagram_permalink_url'=>self::url($cr['instagram_permalink_url']??null)];
        return ['contract'=>self::CONTRACT,'account_id'=>$account,'ad'=>['id'=>$id,'name'=>self::text($ad['name']??null)],'adset'=>$adset,'campaign'=>$campaign,
            'creative'=>$main,'ads_manager_url'=>'https://adsmanager.facebook.com/adsmanager/manage/ads?act='.$account.'&selected_ad_ids='.$id,
            'fetched_at'=>$now,'notices'=>array_values(array_unique($notices))];
    }
}
