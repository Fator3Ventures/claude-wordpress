# Fonte do Fator3 Site Core 1.98.0

O código instalável fica em `work/plugin/base-site-core-fator3/`. O ponto de partida é o fonte oficial da 1.97.2. O histórico das versões anteriores permanece nos diretórios de evidências e referência. Os ensaios e a homologação do pedido 438 estão em `tests/198/` e `evidence/1980/`. Os pedidos e o retorno do MCP 0.52.0 estão em `reference/1980/`. O relatório interno é `RELATORIO-PRE-FECHAMENTO.md`.

## Reprodução dos pacotes

Execute na raiz deste fonte, com Python 3, zlib 1.3.2 e PHP de 64 bits a partir de 8.3.

```sh
F3BASE_PHP=php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.98.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.98.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.98.0-fonte.zip
```

Com o Core ativo num WordPress local, os geradores `build/gerar-catalogo-abilities.php` e `build/gerar-referencia-abilities.php` aceitam `--check`. Configure `F3BASE_SITE` com o caminho do wp-load.php e `F3BASE_HOST` com o host local. As verificações comparam o registro em execução à documentação.

## Repetir o ensaio de ofertas

Use WordPress 7.1.4 ou superior na instalação descartável `core_198_troca`, com `WP_ENVIRONMENT_TYPE=local`, permalink `/%postname%/`, o mesmo banco no servidor HTTP e no WP-CLI, e um tema que chame wp_head. Use loopback na porta 34198, intercepte o envio de e-mail e bloqueie requisições externas. Copie `tests/198/emissor-local.php` para mu-plugins no laboratório. Esse adaptador produz um grafo pelo filtro público do Yoast e serve um perfil de ensaio com HTTP 403. No Site-Teste foi usado o Yoast instalado.

Execute cada ação em uma invocação separada de `F3_438_ACAO=ACAO wp --user=1 eval-file tests/198/ofertas.php`. Salve cada JSON no diretório de resultados.

1. Na 1.97.2 execute preparar, observado1 e observado2. Salve como `antigo-ACAO.json`.
2. Atualize para a 1.98.0 e confirme o ciclo com `F3Base_Zelador::atualizacao_urgente()`. Execute nova1, nova2, editar, apos-edicao, confirmar, divergir, retira, confirma-retirada e vencer. Salve como `novo-ACAO.json`.
3. Execute preparar, reiniciar-prova, cron, cron e verificar-403. Para as duas passagens do cron, use `borda-cron.json` e `borda-cron2.json`. Salve a última como `borda-verificar-403.json`.
4. Execute `wp --user=1 eval-file tests/198/controles.php` e salve o resultado como `controles.json`. Rode `python3 tests/198/conferir.py DIRETORIO`. É possível repetir a última conferência com os JSONs entregues em `evidence/1980/local/`.

A cópia do relatório no fonte precede seu fechamento. O relatório externo identifica ambos os ZIPs finais.
