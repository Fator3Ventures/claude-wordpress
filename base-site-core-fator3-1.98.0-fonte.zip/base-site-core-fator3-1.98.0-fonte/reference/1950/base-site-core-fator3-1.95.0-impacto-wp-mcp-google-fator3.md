# Core 1.95.0 e Fator3 MCP Google 0.38.0

Revisão 2 de entrega, 18/11/2026. Destinatário técnico: mantenedor do Fator3 MCP Google. Referência: pedido MCP Google 56. Classificação: validação coordenada do contrato de incidentes técnicos. Incorporação oficial e aceite em bancada concluídos. A confirmação com a conta Google e a caixa postal de destino pertence aos operadores.

| Artefato | SHA-256 |
|---|---|
| Core 1.94.0, instalador de base | `0eff84a92622b3daa2aebd81437bbb2c33eaea648d1955c46e29ef70aedf9008` |
| Core 1.95.0, instalador entregue | `6971df93ecf39e14e584e0fc3dc802aee77ab4f2d58eb5b8ce35d6a503a4c21c` |
| Google 0.38.0, instalador usado | `1ddeb8ef6aa734a3f8c6a95baadd2c3b6256d84e4bbbdb55d781300b8f407e33` |
| Proposta recebida `reference/1950/google-038-proposta.patch` | `67ddd34f19af85c7ddf409c43d0bc77ca144ebdc0fbe348abf2fc4c95d2a62e6` |

## Contrato incorporado

O Google 0.38.0 publica `autorizacao_recusada` no recurso `<conexão>/service-account-key-metadata` quando a consulta IAM da validade da chave retorna recusa de permissão. O Core 1.94.0 recebia o episódio, porém descartava o detalhe. Na 1.95.0, `F3Base_Incidentes::publicar()` valida o identificador da conexão, a operação, a permissão exata e o formato do projeto. `iam.permissao` recebe `iam.serviceAccountKeys.get` e `iam.projeto` recebe o identificador público válido ou nulo. O Core gera a mesma referência opaca para publicação direta e coleta. Um novo episódio começa com o contexto recebido nessa abertura.

`F3Base_Incidentes_Provedores::google()` percorre a projeção paginada da conexão e filtra por evento, estado, código e recurso. O registro já notificado recebe os dados sem uma segunda abertura ou entrega. Se a abertura do episódio atual ainda aguarda envio, somente o seu item recebe o contexto. Reservas incertas preservam o conteúdo original. O e-mail de abertura identifica “validade da chave não consultável” e o corpo apresenta permissão e projeto. A recuperação usa a mesma referência. A leitura administrativa expõe o par no campo opcional `iam`.

## Aceite e reprodução

- **Conta de teste sintética.** Com os pacotes oficiais em WordPress, o 403 simulado gerou um aviso e uma mensagem interceptada com o projeto e a permissão. A leitura GA4 autenticada simulada retornou dados. Ao restabelecer a consulta IAM, o mesmo episódio recuperou. API desativada, indisponibilidade e recusa da autenticação do token foram exercitadas separadamente. A repetição do 403 e a coleta não duplicaram avisos. A fixture original passou nas 16 verificações.
- **Migração de episódio.** Abrimos e consumimos a mensagem no Core 1.94.0. Depois da atualização com o instalador oficial, o coletor preservou identidade, data e recibo e acrescentou o bloco IAM. Duas coletas geraram zero e-mails. Uma requisição MCP HTTP autenticada leu os campos na 1.95.0. As provas estão em `evidence/1950/google.json`, `migracao-iam.json` e `aceite-google-mcp.json`.
- **Fila.** Onze verificações em cada versão PHP, 8.3.6 e 8.4.27, cobriram filas com datas iguais, isolamento entre episódios, tentativa com entrega incerta, campos inválidos, repetição e controle de acesso. A reprodução completa fica no README do fonte do Core.
- **Mantenedor do Google.** A 0.38.0 oficial já emite o contrato consumido. O retorno ao pedido 56 está pronto para registro.
- **Frota e dono da conta.** Distribuir Google 0.38.0 e Core 1.95.0, conferir a leitura do episódio e o aviso em caixa autorizada e, após a concessão IAM adequada à conta, reconsultar e confirmar a recuperação. O Site-Teste compartilhado confirmou o Core 1.95.0 com Google 0.37.0. O aceite integrado da versão 0.38.0 ocorreu no WordPress de bancada.

A revisão 1 consta de `reference/1950/planejamento-wp-mcp-google-fator3.md`. O fonte preserva o impacto recebido e o diff original para comparação.
