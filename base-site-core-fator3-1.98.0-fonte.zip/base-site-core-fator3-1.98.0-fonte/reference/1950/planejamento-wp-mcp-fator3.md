# Impacto do Core 1.95.0 no Fator3 MCP
Revisão 1 de planejamento, 18/11/2026. Core 1.94.0 → 1.95.0 prevista. Instalador em preparação. Classificação validação coordenada. Pedidos Core 430, MCP84 e MCP 86. Validar delegação exclusiva à 0.50.0, quórum web, CLI e histórico. Critérios em reference/1950/plano.md.
