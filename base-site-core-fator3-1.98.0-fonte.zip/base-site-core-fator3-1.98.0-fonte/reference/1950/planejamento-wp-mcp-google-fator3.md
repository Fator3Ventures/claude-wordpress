# Impacto do Core 1.95.0 no Fator3 MCP Google
Revisão 1 de planejamento, 18/11/2026. Core 1.94.0 → 1.95.0 prevista. Instalador em preparação. Classificação validação coordenada. Pedido MCP Google 56 e Core 430. Receber o bloco IAM da 0.38.0, verificar enriquecimento, projeção e correio com incidente novo e existente. Critérios em reference/1950/plano.md.
