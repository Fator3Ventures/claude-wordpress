# Core 1.95.0 e Fator3 MCP 0.50.0

Revisão 2 de entrega, 18/11/2026. Destinatário técnico: mantenedor do Fator3 MCP. Classificação: validação coordenada. Referências: pedido Core 430 e pedidos MCP 84 e 86. A edição oficial do Core incorpora a delegação. O aceite em bancada está concluído. A observação em produção pertence à frota.

## Versões e proposta

| Artefato | SHA-256 |
|---|---|
| Core 1.94.0, instalador de base | `0eff84a92622b3daa2aebd81437bbb2c33eaea648d1955c46e29ef70aedf9008` |
| Core 1.95.0, instalador entregue | `6971df93ecf39e14e584e0fc3dc802aee77ab4f2d58eb5b8ce35d6a503a4c21c` |
| MCP 0.50.0, instalador usado | `97f6c6a233c2210e24cdef205a66a41c95e20eca9ad8f3644e518bc8ed4ee95f` |
| Proposta recebida `reference/1950/mcp-050-proposta.patch` | `99b4aca6a4772469be132454216d9779143e3f8d319dfdad8ca359b18edbe790` |

Na 1.94.0, o canal já podia tratar a primeira falha como suspeita enquanto o observador próprio do Core publicava a abertura. O mantenedor reproduziu a divergência na combinação 1.94.0/0.50.0. A correção anterior de inscrição tardia de rota, pedido 84, já entrou no MCP 0.49.0 e integra a base 0.50.0. O pedido 86 fecha a segunda origem de transições.

`F3Base_Incidentes::observar_registro_canal()`, em `includes/class-f3base-incidentes.php`, chama `ChannelIncidents::observeRegistration()`. O método do canal filtra fase de inicialização, contexto, repetição por requisição e falha consecutiva. Se o componente estiver ausente, o Core não produz uma decisão substituta. O filtro `f3base_incidente_publicar_v1` continua recebendo as mudanças confirmadas. O Core guarda até 12 transições, a versão e os hooks no instante da recepção. O instante de recepção pode ser posterior à observação do produtor. Os registros históricos conservam a origem que tinham na gravação.

## Aceite e ação por responsável

- **Bancada do Core.** WordPress 7.1.4, PHP 8.3.6, instaladores oficiais. Seis requisições HTTP com a fase precoce e os dois observadores na mesma requisição. Uma falha isolada seguida de saúde deixou zero aberturas. A segunda das duas falhas seguintes gerou uma abertura em cron HTTP. Outra falha preservou o episódio. Uma resposta saudável gerou uma recuperação web. O Core gravou exatamente duas transições com origem `publicador_canal`. Consultas por WP-CLI antes e depois conservaram o estado. Provas reproduzíveis em `tests/195/`, `evidence/1950/registro-http.json` e `historico.json`.
- **Site-Teste.** O MCP 0.50.0 já estava ativo antes da chegada do Core 1.95.0. O executor confirmou a troca. O registro do canal continuou recuperado, com uma transição histórica e zero entregas pendentes. As falhas controladas ocorreram somente na bancada.
- **Mantenedor do MCP.** A parte de código solicitada ao Core está incorporada. A versão e o resultado acima fecham o retorno dos pedidos 84 e 86 no Core.
- **Frota.** Para o aceite de campo, ativar MCP 0.50.0 antes do Core 1.95.0 e acompanhar os 11 sites por 24 horas, confrontando mudanças naturais com as passagens de WP-CLI a cada 15 minutos e com a saúde do canal no mesmo período. Onde houver acúmulo, comparar a redução da fila, o horário da última execução e as janelas de manutenção.

A revisão 1 está no fonte em `reference/1950/planejamento-wp-mcp-fator3.md`. O relato e os patches do mantenedor estão ao lado dessa revisão.
