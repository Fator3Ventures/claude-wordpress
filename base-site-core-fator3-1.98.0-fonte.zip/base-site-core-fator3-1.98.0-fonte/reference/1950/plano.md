# Core 1.95.0 · Planejamento de 18/11/2026

Base oficial 1.94.0. Pedidos Core 430, MCP 86 e MCP Google 56. O retorno da 0.49.0 resolve o encaminhamento MCP84 da rodada anterior. Validar o comportamento em duas frentes antes da implantação no Site-Teste. Instalador-alvo em preparação.

| Destinatário | Proposta e aceite coordenado |
|---|---|
| MCP 0.50.0 | Delegar a decisão a ChannelIncidents::observeRegistration. Testar duas requisições web distintas, repetição intrarrequisito, CLI sem transição, recuperação única e independência sem o MCP. Manter o histórico de recepção, reservas e fila. |
| Google 0.38.0 | Permitir apenas o diagnóstico tipado do recurso de metadados da chave IAM. Testar o produtor oficial, coletor, registro, página administrativa via MCP e correio interceptado. Enriquecer episódio já enviado sem repostar e garantir que episódios passados não adquiram o projeto atual. |

A confirmação nas instalações da frota e a validação em caixa real continuam com seus operadores.
