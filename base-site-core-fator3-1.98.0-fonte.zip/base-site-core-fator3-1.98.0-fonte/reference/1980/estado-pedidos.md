# Pedidos do Site Core após a entrega da 1.98.0

A lista recebida em 19/11/2026 às 21:04 UTC contém o pedido 438. A implementação foi entregue e homologada no Site-Teste. A lista de desenvolvimento desta rodada está encerrada. O próximo número disponível é 439.

O aceite de campo segue com a frota Engagia. Os identificadores, a evidência de origem e o procedimento de conferência constam do relatório. O retorno oficial do MCP 0.52.0 encerrou a dependência de código do pedido 433. A observação operacional de 72 horas desse pedido segue na frota.
