# Pedidos — Fator3 Site Core (base-site-core-fator3)

Oct 21, 2026 · @Fator3

Pedidos de funcionalidade e correção em aberto no pacote **base-site-core-fator3**. Cite como "Pedidos core N". Próximo número: 432; número retirado fica vago.

## base-site-core-fator3 — pendentes

### 431. Aviso `prova_vencendo` da prova de 24 h fica aberto para sempre (aberto em 18/11/2026)

**Causa e mecanismo.** Na 1.95.0, `F3Base_Incidentes_Provedores::google()` publica `prova_vencendo` com `vence_em` igual a `verified[ga4|google_ads].expires` da conexão Google, e `F3Base_Incidentes::vencimento()` abre o aviso quando `time() >= vence_em − antecedencia_dias × 86400` (padrão 14 dias). A prova de conversão do GA4 e do Google Ads vale 24 h e o executor do Google a renova 12 h depois. O vencimento nunca fica mais de 24 h à frente, então o limiar de 14 dias está sempre no passado: o aviso abre na primeira observação e nunca recupera, mesmo com a renovação em dia. Falha real de renovação já tem aviso próprio (`renovacao_falhou`, mesma função).

**Extrato da frota (ctooffice, 18/11/2026).** `google/readiness-status` às 20:51: `conversion_ga4` verificada às 13:58, vence em 19/11 às 13:58, próxima renovação às 01:58, `failures` 0; `conversion_google_ads` verificada às 10:56, vence em 19/11 às 10:56, próxima renovação às 22:56, `failures` 0. `f3base/incidentes-tecnicos-ler`: dois `prova_vencendo` `aberto` com `desde` 05/11 às 10:56 e às 13:58 (o limiar calculado), `acao_humana` true, e-mail de abertura aceito em 18/11 às 19:00. Nenhum outro site da frota tem a entrega de conversões do Google ligada.

**Pedido.** Antecedência própria para validade curta: o aviso de prova abre só quando a renovação deixou de acontecer no prazo, por exemplo com menos de 6 h para o vencimento (ou uma fração da validade da prova, nunca maior que a margem de renovação do executor). `antecedencia_dias` continua valendo para token e refresh do LinkedIn, versão da Graph na CAPI e demais validades longas. Os avisos abertos indevidamente passam a `recuperado` na primeira observação depois da troca, com um e-mail de recuperação.

**Aceite.** Em ctooffice, com a renovação em dia, os dois `prova_vencendo` passam a `recuperado` na primeira observação depois da troca e não reabrem em 72 h. Com renovação impedida (Site-Teste ou simulação), o aviso abre antes do vencimento. O critério vale para qualquer validade de prova (não só 24 h) e para qualquer número de destinos e de conexões.
