# Planejamento da 1.96.0
Base oficial 1.95.0. Core 431 e Google 57/58. Conferir as margens de provas temporárias por conexão, preservar validades longas e recuperar os avisos antigos na primeira observação. Incorporar e testar a retentativa Ads vinculada nas duas filas. MCP 0.51.0 consome o contrato existente. A resposta preliminar ao Google está em planejamento-google.md.

Fechamento. Revisão 2 do retorno ao Google em base-site-core-fator3-1.96.0-impacto-wp-mcp-google-fator3.md. As versões oficiais passaram nas verificações de bancada e estão ativas com o MCP 0.51.0 no Site-Teste. CTO Office segue com o aceite de campo após distribuição.
