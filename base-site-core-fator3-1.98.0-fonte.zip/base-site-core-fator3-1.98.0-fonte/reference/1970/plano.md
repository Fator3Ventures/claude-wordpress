# Core 1.97.0 · escopo e integração

Partida no Core 1.96.0. Pedidos 432 a 437. Reutilizar o acervo e os adaptadores 1.0/1.1 do Google 0.40.0, a política de agenda de Meta 0.29.0 e LinkedIn 0.26.0 e a fila da caixa. Testar instalação limpa, migração, curto-circuito do cron, relatórios com dados, geração pública e aprovação. MCP 0.51.0 mantém contagens próprias do canal em system/health. Proposta de integração de leitura em impacto separado. O aceite 431 depende de observações naturais até 22/11 02h20.
