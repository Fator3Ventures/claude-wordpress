# Pedidos do Site Core · extrato técnico de 19/11/2026

Fonte do proprietário: Fator3 Site Core(20261119-123636).md. O original mantém os registros operacionais.

- 431. As duas provas recuperaram após a instalação da 1.96.0. Conferir ausência de reabertura em 22/11 às 02h20.
- 432. GCLID elegível sem sessão deve seguir ao Ads pela fila vinculada. GA4 identifica ausência de sessão.
- 433. Diagnosticar could_not_set na passagem CLI, recompor workers Meta/LinkedIn e registrar incidente por gancho/dia.
- 434. Consultar formulários e resumo em 30 dias, com memória limitada e continuação.
- 435. Converter shortcode público e parte de modelo. Publicar conteúdo remanescente com avisos.
- 436. Catalogar estado interno de incidentes e uniformizar avisos nas duas rotas.
- 437. Aplicar política de sinais da caixa na captura, na aprovação e em todos os canais de aviso.
