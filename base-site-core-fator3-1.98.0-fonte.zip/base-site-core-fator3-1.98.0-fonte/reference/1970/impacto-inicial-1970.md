# Impacto de base-site-core-fator3 1.97.0 em wp-mcp-fator3

**Destinatário** Fator3 MCP. **Base conferida** 0.51.0. **Pedido relacionado** Core 433. **Estado** proposta testada em cópia isolada, aguardando incorporação oficial.

## Mudança e consequência

O Core registra falhas could_not_set de ganchos Fator3 e suas recuperações. Na edição oficial do canal, Diagnostics::health usa o histórico do próprio marcador de cron para incidents_24h. Uma resposta vazia nesse grupo é possível durante incidente de um worker de Meta ou LinkedIn.

## Ação solicitada

Acrescentar a projeção opcional pacotes_fator3 em incidents_24h quando o Core disponibilizar contagem. Preservar o histórico e as categorias do marcador do canal. O operador encontrará o total de episódios abertos nas últimas 24 horas, o instante do último e a rota de detalhes.

## Diagnóstico e alteração proposta

Aplicar o patch reference/1970/mcp-051-diagnostico.patch do fonte desta entrega em includes/Diagnostics.php da 0.51.0. O ponto de inserção é o método health, antes de project. O filtro f3base_cron_incidentes_24h_v1 recebe null. No WordPress com Core 1.97.0 e administrador, devolve episodios (inteiro), ultimo_em (epoch ou null) e detalhe (rota). A consulta usa o diário local e o índice temporal. A resposta compacta conserva o limite de tamanho do canal. Se o filtro devolver null, a resposta do canal mantém o formato anterior.

## Prontidão e sequência

A edição oficial 1.97.0 já publica a projeção. Com MCP 0.51.0 oficial, o detalhe está disponível em f3base/incidentes-tecnicos-ler e f3base/execucoes-ler. O responsável pelo MCP pode incorporar o patch na sua rodada. O Core instalado independe dessa incorporação para observar e recuperar workers.

## Validação e aceite

No laboratório, foi aberto um incidente pela recusa de um evento Meta, houve rearme do worker e a cópia modificada de Diagnostics::health apresentou um episódio, o instante e a rota. Evidência em evidence/1970/impacto-canal.json. O pacote MCP oficial foi reposto no laboratório após a prova. Conferir projeções completa e compacta, limite de 1.850 bytes, permissão administrativa, ausência do filtro e acesso pela conexão do Site-Teste na versão candidata do canal.

## Resposta esperada

Informar a versão oficial que incorpora a projeção, o nome efetivo do campo e a evidência do Site-Teste. Se a equipe mantiver o escopo do diagnóstico exclusivamente no marcador, documentar essa abrangência na própria leitura.
