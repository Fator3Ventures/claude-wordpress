<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_197_')) {
    throw new RuntimeException('Requer laboratório descartável');
}
wp_set_current_user(1);
$a = wp_get_ability('f3base/como-usar');
$input = ['compacto'=>true, 'incluir'=>['saude']];
$resposta = F3Base_Como_Usar::responder($input);
$validade = rest_validate_value_from_schema($resposta, $a->get_output_schema(), 'output');
if (is_wp_error($validade) || $resposta['agenda_das_filas']['cobertura'] !== 'f3base_*' ||
    $resposta['agenda_das_filas']['prefixos_cobertos'] !== F3Base_Agenda_Filas::PREFIXOS_COBERTOS) {
    throw new RuntimeException(is_wp_error($validade) ? $validade->get_error_message() : 'Cobertura divergente');
}
$r = F3Base_Llms_Cobertura::executar(2,true);
$cursores = [];
for ($n = 0; $n < 25 && ($r['codigo'] ?? '') === 'preparacao_parcial'; $n++) {
    $cursor = $r['cursor'];
    if ($cursores && $cursor <= end($cursores)) { throw new RuntimeException('Cursor reiniciado'); }
    $cursores[] = $cursor;
    $r = F3Base_Llms_Cobertura::executar(2,true);
}
if (($r['codigo'] ?? '') !== 'geracao_publicada' || empty($r['ok']) ||
    $r['cobertura']['geracao_publicada'] !== $r['geracao']) {
    throw new RuntimeException('Geração não publicada: '.($r['codigo'] ?? 'desconhecida'));
}
echo wp_json_encode(['ability'=>'f3base/como-usar','prefixos'=>$resposta['agenda_das_filas']['prefixos_cobertos'],
    'geracao'=>$r['codigo'],'cursores'=>$cursores,'itens'=>$r['cobertura']['total']]);
