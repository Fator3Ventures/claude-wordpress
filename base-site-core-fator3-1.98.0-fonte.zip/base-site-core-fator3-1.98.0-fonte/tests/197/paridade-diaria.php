<?php
// Executar depois de volume.php no WordPress descartável.
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_197_clean') {
    throw new RuntimeException('Banco de teste obrigatório');
}
global $wpdb;
wp_set_current_user(1);
$analise = F3Base_Analise::tabela();
$path = '/ensaio-paridade-197/';
$wpdb->delete($analise, ['caminho' => $path]);
for ($day = 1; $day <= 30; ++$day) {
    $date = sprintf('2026-09-%02d', $day);
    $stamp = strtotime($date . ' 12:00 UTC');
    $id = md5($date);
    $row = ['evento' => $id, 'visitante' => $id, 'sessao' => $id,
        'navegacao' => $id, 'tipo' => 'pagina', 'caminho' => $path,
        'dispositivo' => 'desktop', 'navegador' => 'chrome', 'classe_trafego' => 'nao_marcado',
        'criado_em' => $stamp, 'recebido_em' => $stamp, 'qualidade' => 'normal',
        'atribuicao' => '{}', 'payload_hash' => hash('sha256', $id)];
    if ($wpdb->insert($analise, $row) !== 1) {
        throw new RuntimeException('Falha ao gravar a visita sintética');
    }
}
$resultados = [];
foreach (['formularios', 'resumo'] as $view) {
    $periodo = ['de'=>'2026-09-01','ate'=>'2026-09-30','segmento'=>'sem_testes','visao'=>$view];
    $cursor = null;
    $soma = 0;
    for ($day = 1; $day <= 30; ++$day) {
        $date = sprintf('2026-09-%02d', $day);
        $filtros = array_merge($periodo, ['de'=>$date,'ate'=>$date]);
        $referencia = F3Base_Relatorios::consultar($filtros);
        $fatia = F3Base_Relatorios::consultar_api($periodo + ($cursor ? ['cursor'=>$cursor] : []));
        if (empty($referencia['ok']) || empty($fatia['ok']) || ($fatia['dia'] ?? null) !== $date ||
            $referencia['totais'] != $fatia['totais'] || $referencia['linhas'] != $fatia['linhas']) {
            throw new RuntimeException($view . ' divergiu em ' . $date . ' ' . wp_json_encode([
                $referencia['codigo'] ?? null, $fatia['codigo'] ?? null,
                $referencia['totais'] ?? null, $fatia['totais'] ?? null]));
        }
        $soma += $fatia['totais']['visualizacoes'];
        $cursor = $fatia['proximo_cursor'];
    }
    if ($cursor !== null || $soma !== 30) {
        throw new RuntimeException('Última página ou total de visitas divergente: ' . $soma);
    }
    $resultados[$view] = ['dias_conferidos'=>30,'visualizacoes'=>$soma,'linhas_e_totais_iguais'=>true];
}
echo wp_json_encode($resultados, JSON_UNESCAPED_UNICODE), PHP_EOL;
