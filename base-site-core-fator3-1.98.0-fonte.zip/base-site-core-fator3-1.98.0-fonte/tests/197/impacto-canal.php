<?php
if (wp_get_environment_type()!=='local'||!str_starts_with(DB_NAME,'core_197_')) throw new RuntimeException('Somente laboratório');
wp_set_current_user(1);
$d=['success'=>true,'healthy'=>true,'environment'=>['plugin_version'=>'0.51.0','mutation_audit'=>true],'recovery'=>['status'=>'ok'],'cron'=>['scheduling'=>['contract'=>'fixture','current_state'=>'present','desired_state'=>'present','readback'=>['consistent'=>true],'incidents'=>[],'history_complete'=>true]]];
$r=\Fator3\McpFiles\Diagnostics::health($d,['compact'=>true]);
$x=$r['data']['incidents_24h']['pacotes_fator3']??$r['incidents_24h']['pacotes_fator3']??null;
if (!is_array($x)||$x['episodios']<1) throw new RuntimeException(wp_json_encode($r));
echo wp_json_encode(['ok'=>true,'f3base'=>$x,'interceptacao'=>'cópia local do MCP 0.51.0']),PHP_EOL;
