<?php
if (wp_get_environment_type()!=='local' || !str_starts_with(DB_NAME,'core_197_')) { throw new RuntimeException('Requer laboratório descartável'); }
wp_set_current_user(1);
$checks=[];
$ok=static function($cond,$label,$detail=null)use(&$checks){if(!$cond){throw new RuntimeException($label.' '.wp_json_encode($detail));}$checks[]=$label;};
global $wpdb;
switch(getenv('CASO197')){
case 'cron':
    $hook='f3_meta_worker'; $agenda=wp_generate_uuid4();
    \Fator3\Meta\Store::put('schedule',$agenda,['enabled'=>true,'query'=>['report'=>'media','connection_id'=>'fixture'],'label'=>'Teste','interval_minutes'=>60,'next_at'=>time()+3600]);
    wp_clear_scheduled_hook($hook);
    $veto=static fn($pre,$evento)=>$evento->hook===$hook?new WP_Error('could_not_set','fixture'):$pre;
    add_filter('pre_schedule_event',$veto,30,2);
    $err=wp_schedule_single_event(time()+10,$hook,[],true);$ok(is_wp_error($err),'Recusa preservada');
    wp_schedule_single_event(time()+10,$hook,[],true);
    $ref=hash_hmac('sha256',$hook.'|'.wp_date('Y-m-d'),wp_salt('auth'));
    $inc=static fn()=>array_values(array_filter(F3Base_Incidentes::listar()['itens'],static fn($r)=>$r['recurso_ref']===$ref));
    $rows=$inc();$ok(count($rows)===1&&$rows[0]['estado']==='aberto','Um incidente por gancho/dia',$rows);
    remove_filter('pre_schedule_event',$veto,30);
    F3Base_Agenda_Filas::conferir_trabalhadores();
    $ok(wp_next_scheduled($hook)!==false && $inc()[0]['estado']==='recuperado','Worker Meta rearmado e incidente recuperado');
    $ok($wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE hook=%s AND codigo='worker_rearmado'",F3Base_Execucoes::tabela(),$hook))>0,'Rearme registrado no diário');
    \Fator3\LinkedIn\Store::put('schedule',$agenda,['enabled'=>true,'query'=>[],'label'=>'Teste','interval_minutes'=>60,'next_at'=>time()+3600]);
    wp_clear_scheduled_hook('f3_linkedin_worker');F3Base_Agenda_Filas::conferir_trabalhadores();
    $ok(wp_next_scheduled('f3_linkedin_worker')!==false,'Worker LinkedIn rearmado');
    break;
case 'catalogo':
    $name='f3base_incidente_v1_'.str_repeat('a',64);update_option($name,['estado'=>'aberto'],false);
    update_option('f3base_incidente_v1_invalido',1,false);
    $c=F3Base_Options::catalogo_ausentes();$ok(!in_array($name,$c['nomes'],true)&&in_array('f3base_incidente_v1_invalido',$c['nomes'],true),'Família exata de estado interno',$c);
    $a=F3Base_Resumo_Operacional::ler(['campos'=>['avisos']]);
    $b=F3Base_Como_Usar::responder(['compacto'=>true]);
    $ok(!is_wp_error($b)&&($a['avisos']['codigos']??$a['codigos']??null)===array_keys($b['avisos_configuracao']??[]),'Mesmos avisos nas duas rotas',[$a,is_wp_error($b)?$b->get_error_message():array_keys($b)]);
    delete_option('f3base_incidente_v1_invalido');delete_option($name);break;
case 'email':
    $opt=F3Base_Formulario_Antispam::OPTION;$config=F3Base_Options::ler($opt);$ok($config['email_suspeito']['suspeito']&&!$config['email_suspeito']['aviso'],'Padrão de suspeita sem aviso');
    $config['email_suspeito']['aviso']=true;
    $args=['nome'=>$opt,'valor'=>$config,'revisao_esperada'=>F3Base_Options::revisao($opt),'simular'=>true];
    $sim=F3Base_Core_Config_Mcp::escrever($args);
    $ok(!is_wp_error($sim)&&!empty($sim['ok'])&&!F3Base_Options::ler($opt)['email_suspeito']['aviso'],'Simulação não alterou a política',is_wp_error($sim)?$sim->get_error_message():$sim);
    $apply=F3Base_Core_Config_Mcp::escrever(array_merge($args,['simular'=>false]));
    $ok(!empty($apply['ok'])&&F3Base_Options::ler($opt)['email_suspeito']['aviso'],'Política aplicada e relida');
    $config['email_suspeito']['aviso']=false;
    $rev=F3Base_Core_Config_Mcp::escrever(['nome'=>$opt,'valor'=>$config,'simular'=>false,'revisao_esperada'=>F3Base_Options::revisao($opt)]);
    $ok(!empty($rev['ok'])&&!F3Base_Options::ler($opt)['email_suspeito']['aviso'],'Política restabelecida');
    $id=wp_generate_uuid4();$msg=['uidvalidity'=>197,'uid'=>random_int(1,2147483646),'recebida_em'=>time()];
    $p=['classe'=>'suspeito','motivo'=>'autenticacao_nao_confirmada','autenticacao'=>['aceito'=>false,'dmarc'=>'fail','dkim'=>'fail','spf'=>'fail'],'nome'=>'Pessoa de teste','email'=>'gerencia@example.invalid','remetente'=>'gerencia@example.invalid','nome_substituto'=>false,'assunto'=>'Mensagem sintética','texto'=>'Mensagem','anexos_nomes'=>[],'message_id'=>'<'.$id.'@example.invalid>'];
    $cfg=F3Base_Email_Site::cfg();$cfg['endereco']='caixa@example.invalid';$cfg['authserv_ids']=['mx.example.invalid'];$cfg['dominios_ignorados']=[];
    $domain='ensaio197.example.invalid';
    set_transient('f3edns2_'.hash('sha256','TXT|_dmarc.'.$domain),['rows'=>[['value'=>'v=DMARC1; p=none','ttl'=>60]],'exists'=>true],120);
    $raw="From: Ana <ana@$domain>\r\nTo: caixa@example.invalid\r\nAuthentication-Results: mx.example.invalid; dmarc=fail header.from=$domain; spf=fail; dkim=fail\r\nMessage-ID: <$id@example.invalid>\r\nSubject: Contato sintetico\r\n\r\nPedido de contato.";
    $p=F3Base_Email_Mime::parse($raw,$cfg);$ok($p['classe']==='suspeito' && $p['autenticacao']['dmarc']==='fail','MIME com falha DMARC classificada pelo importador',$p['autenticacao']??[]);
    $fake='https://hooks.slack.com/services/FIXTURE/ONLY/LOCAL';
    $cipher=F3Base_Segredos::cifrar(F3Base_Avisos::SEGREDO,$fake);
    add_filter('pre_option_'.F3Base_Avisos::SEGREDO,static fn()=>$cipher);
    $calls=0;add_filter('pre_http_request',static function($pre,$args,$url)use($fake,&$calls){if($url!==$fake)return $pre;++$calls;return ['headers'=>[],'response'=>['code'=>200,'message'=>'OK'],'body'=>'ok','cookies'=>[]];},PHP_INT_MAX,3);
    add_filter('pre_option_f3base_avisos',static fn()=>['canal'=>'slack','slack_transporte'=>'webhook']);
    $r=F3Base_Email_Site::persistir($msg,$p,hash('sha256','teste'));$ok(!empty($r['ok']),'Mensagem materializada',$r);
    $read=static fn()=>F3Base_Leads_Repositorio::obter($r['record_id']);
    $lead=$read();$ok($lead['captura']==='suspeito'&&empty($lead['dados']['suspeito_aviso']),'Entrada suspeita aguarda aprovação');
    $count=static fn()=>(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE record_id=%s',F3Base_Avisos::tabela(),$r['record_id']));
    F3Base_Email_Site::continuacoes();$ok($count()===0&&(int)F3Base_Email_Site::row($r['chave'])['aviso_em']===0,'Nenhum aviso na fila antes da aprovação');
    if (getenv('F3_EMAIL_UI197') === 'preparar') {
        echo wp_json_encode(['registro'=>$r['record_id'],'antes'=>$count(),'captura'=>$lead['captura']]);
        return;
    }
    $a=F3Base_Leads_Repositorio::atualizar(['record_id'=>$r['record_id'],'revisao_esperada'=>(int)$lead['revisao'],'simular'=>false,'entregar'=>true,'alteracoes'=>['captura'=>'aceito']]);
    F3Base_Email_Site::continuacoes();F3Base_Email_Site::continuacoes();
    $ok($read()['captura']==='aceito'&&$count()===1,'Aprovação enfileirou um único aviso de Slack',[$a,$count()]);
    F3Base_Avisos::processar();F3Base_Avisos::processar();
    $estado=$wpdb->get_var($wpdb->prepare('SELECT estado FROM %i WHERE record_id=%s',F3Base_Avisos::tabela(),$r['record_id']));
    $ok($estado==='entregue'&&$calls>=1,'Receptor Slack simulado aceitou o aviso',[$estado,$calls]);break;
case 'markdown':
    update_option('blog_public','1');$id=wp_insert_post(['post_type'=>'page','post_title'=>'Perfil','post_status'=>'publish']);
    $part=wp_insert_post(['post_type'=>'wp_template_part','post_name'=>'servico197','post_title'=>'Serviço','post_status'=>'publish','post_content'=>'<!-- wp:paragraph --><p>Descrição do serviço</p><!-- /wp:paragraph -->']);
    wp_set_object_terms($part,get_stylesheet(),'wp_theme');
    $body='<!-- wp:shortcode -->[perfil197]<!-- /wp:shortcode --><!-- wp:shortcode -->[perfil197]<!-- /wp:shortcode --><!-- wp:template-part {"slug":"servico197"} /--><!-- wp:shortcode -->[desconhecido197]<!-- /wp:shortcode -->';
    wp_update_post(['ID'=>$id,'post_content'=>$body]);
    $chamadas=0;
    add_filter('pre_http_request',static function($prev,$args) use (&$chamadas) {
        if (isset($args['body']['f3base_llms_render'])) { ++$chamadas; }
        return $prev;
    },11,2);
    $r=F3Base_Llms_Conversor::converter($body,get_permalink($id),3,$id);
    $ok($r['completo']&&str_contains($r['texto'],'Perfil público')&&str_contains($r['texto'],'Descrição do serviço')&&in_array('shortcode_indisponivel',$r['avisos'],true),'Perfil anônimo, modelo e aviso residual',$r);
    $ok($chamadas===1 && substr_count($r['texto'],'Perfil público')===2,'Dois blocos preservados em um único pedido anônimo', $r);
    $z=F3Base_Llms_Conversor::converter('<!-- wp:shortcode -->[desconhecido197]<!-- /wp:shortcode -->',get_permalink($id),3,$id);
    $ok(!$z['completo']&&$z['texto']==='','Página sem texto continua incompleta');break;
}
echo wp_json_encode(['caso'=>getenv('CASO197'),'testes'=>$checks,'wp'=>get_bloginfo('version'),'php'=>PHP_VERSION],JSON_UNESCAPED_UNICODE),PHP_EOL;
