<?php
if (wp_get_environment_type()!=='local'||DB_NAME!=='core_197_clean') throw new RuntimeException('Banco descartável obrigatório');
global $wpdb;wp_set_current_user(1);
$periodo=['de'=>'2026-09-01','ate'=>'2026-09-30','segmento'=>'sem_testes'];$table=F3Base_Modulo_Comportamento::nome_tabela_eventos();
$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE caminho=%s",$table,'/fixture197'));
for($i=0;$i<30;$i++){
    $dia=gmdate('Y-m-d',strtotime('2026-09-01 UTC')+$i*DAY_IN_SECONDS);
    $stamp=strtotime($dia.' 12:00 UTC');$values=[];
    for($n=0;$n<560;$n++){$h=md5((string)($i*560+$n));$values[]=$wpdb->prepare('(%s,%s,%s,%s,%s,%s,%d)',$h,$h,$h,$dia,'/fixture197','f3base_teste',$stamp+$n);}
    if($wpdb->query("INSERT INTO $table (visitante,sessao,navegacao,dia,caminho,metrica,criado_em) VALUES ".implode(',',$values))!==560)throw new RuntimeException('Fixture SQL');
}
$tab=F3Base_Leads_Repositorio::tabela();$id=F3Base_Leads_Repositorio::guardar(['nome'=>'Teste 197','email'=>'volume197@example.invalid','metodo'=>'formulario','captura'=>'aceito','formulario'=>'volume197','notificar'=>false])['record_id'];
$wpdb->update($tab,['criado_em'=>'2026-09-06 15:00:00','classe_trafego'=>'nao_marcado'],['record_id'=>$id]);
$evid=['eventos'=>16800,'memoria_entrada'=>memory_get_usage(true)];
foreach(['formularios','resumo'] as $v){
    $q=$periodo+['visao'=>$v];$cursor=null;$dias=[];$counts=[];$t=microtime(true);
    do{$r=F3Base_Relatorios::consultar_api($q+($cursor?['cursor'=>$cursor]:[]));if(empty($r['ok'])||isset($dias[$r['dia']??''])||empty($r['dia']))throw new RuntimeException($v.' '.wp_json_encode(array_intersect_key($r,array_flip(['codigo','diagnostico','dia']))));
        $dias[$r['dia']]=true;foreach(['envios','registros','visualizacoes'] as $k){if(isset($r['totais'][$k]))$counts[$k]=($counts[$k]??0)+$r['totais'][$k];}
        if($r['dia']==='2026-09-06'&&$v==='formularios'){
            $daily=F3Base_Relatorios::consultar(['de'=>$r['dia'],'ate'=>$r['dia'],'segmento'=>'sem_testes','visao'=>$v]);
            if(empty($daily['ok'])||$daily['linhas']!=$r['linhas']||$daily['totais']!=$r['totais'])throw new RuntimeException('Divergência entre dia integral e continuação '.wp_json_encode([$daily['codigo']??null,$daily['totais']??[],$r['totais']]));
        }
        $cursor=$r['proximo_cursor']??null;
        if(count($dias)===1&&F3Base_Relatorios::consultar_api(array_merge($q,['cursor'=>$cursor,'segmento'=>'somente_testes']))['codigo']!=='cursor_invalido')throw new RuntimeException('Vínculo do cursor');
    }while($cursor&&count($dias)<=30);
    if(count($dias)!==30 || ($v==='formularios'&&($counts['envios']??0)<1))throw new RuntimeException('Soma dos dias');
    $evid[$v]=['dias'=>count($dias),'totais'=>$counts,'ms'=>round(1000*(microtime(true)-$t))];
}
$evid['memoria_pico']=memory_get_peak_usage(true);echo wp_json_encode($evid),PHP_EOL;
