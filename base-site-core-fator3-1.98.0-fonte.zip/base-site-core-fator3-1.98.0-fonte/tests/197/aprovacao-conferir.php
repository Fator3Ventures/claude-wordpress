<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_197_')) {
    throw new RuntimeException('Somente laboratório');
}
global $wpdb;
$id = getenv('F3_REGISTRO_UI197');
$contato = F3Base_Leads_Repositorio::obter($id);
if (($contato['captura'] ?? '') !== 'aceito') { throw new RuntimeException('Aprovação não persistiu'); }
F3Base_Email_Site::continuacoes();
F3Base_Email_Site::continuacoes();
F3Base_Avisos::processar();
F3Base_Avisos::processar();
$estados = $wpdb->get_col($wpdb->prepare('SELECT estado FROM %i WHERE record_id=%s', F3Base_Avisos::tabela(), $id));
if ($estados !== ['entregue']) { throw new RuntimeException('Entrega inesperada '.wp_json_encode($estados)); }
echo wp_json_encode(['antes'=>['captura'=>'suspeito','avisos'=>0], 'depois'=>['captura'=>'aceito','avisos'=>1,'estado'=>$estados[0]], 'acao'=>'Salvar no wp-admin', 'receptor'=>'Slack simulado']);
