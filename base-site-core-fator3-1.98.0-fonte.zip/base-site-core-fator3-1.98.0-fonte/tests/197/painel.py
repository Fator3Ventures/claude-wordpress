"""Inspecionar a tela administrativa real do WordPress descartável em loopback."""
import json, os
from urllib.parse import urlsplit
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(os.environ['LAB197'])
assert os.environ['F3LAB_DB'].startswith('core_197_')
out=root/'ui'
out.mkdir(exist_ok=True)
auth=json.loads((root/'browser-local.json').read_text())
origin=urlsplit(auth['url'])
assert origin.scheme == 'http' and origin.hostname == '127.0.0.1'
rows=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ.get('F3_QA_CHROME', '/usr/bin/chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for width in (360,768,1440):
        ctx=browser.new_context(viewport={'width':width,'height':900})
        ctx.add_cookies([{'name':k,'value':v,'url':origin.scheme+'://'+origin.netloc} for k,v in auth['cookies'].items()])
        pg=ctx.new_page()
        pg.goto(auth['url'],wait_until='domcontentloaded',timeout=25000)
        signal=pg.locator('input[name="sinais[email_suspeito][aviso]"]')
        signal.wait_for(state='attached',timeout=8000)
        signal.evaluate("""e=>{for(let n=e.parentElement;n;n=n.parentElement){if(n.tagName==='DETAILS')n.open=true;}e.scrollIntoView({block:'center'});}""")
        row=signal.locator('xpath=ancestor::tr')
        pg.screenshot(path=str(out/f'email-{width}.png'))
        result={'largura':width,'documento':pg.evaluate('document.documentElement.scrollWidth'),'visivel':signal.is_visible(),'aviso':signal.is_checked(),'suspeito':row.locator('input[name*="[suspeito]"]').is_checked()}
        assert result['visivel'] and result['suspeito'] and not result['aviso'],result
        rows.append(result); ctx.close()
    browser.close()
(out/'resultado.json').write_text(json.dumps(rows,indent=2))
