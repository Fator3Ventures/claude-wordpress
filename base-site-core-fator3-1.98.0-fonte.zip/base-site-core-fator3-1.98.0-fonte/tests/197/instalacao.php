<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_197_')) throw new RuntimeException('Laboratório obrigatório');
F3Base_Incidentes::observar_registro_canal();
F3Base_Zelador::atualizacao_urgente();
$r=F3Base_Instalacao::resumo();
if ($r['versao_alvo'] !== '1.97.2' || $r['estado'] !== 'concluida' || $r['falhas'] !== 0 || empty($r['confirmada_no_executor_em'])) throw new RuntimeException(wp_json_encode($r));
echo wp_json_encode(['wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'resumo'=>$r], JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
