"""Submeter o formulário de aprovação usando apenas a interface do laboratório."""
import json
import os
import re
from pathlib import Path
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright

lab = Path(os.environ['LAB197'])
auth = json.loads((lab / 'browser-local.json').read_text())
fixture = json.loads((lab / 'email-painel-fixture.json').read_text())
assert fixture['captura'] == 'suspeito' and fixture['antes'] == 0
assert re.fullmatch(r'[a-f0-9]{32}', fixture['registro'])
origin = urlsplit(auth['url'])
assert origin.scheme == 'http' and origin.hostname == '127.0.0.1'
base = origin.scheme + '://' + origin.netloc
with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'], headless=True, args=['--no-sandbox'])
    page = browser.new_page()
    page.context.add_cookies([{'name': k, 'value': v, 'url': base} for k, v in auth['cookies'].items()])
    page.goto(base + '/wp-admin/admin.php?page=f3base-leads&record_id=' + fixture['registro'])
    form = page.locator('form').filter(has=page.locator('input[name="aprovar"]'))
    form.locator('[name="aprovar"]').check()
    form.locator('[name="entregar"]').check()
    with page.expect_navigation(wait_until='domcontentloaded'):
        form.get_by_role('button', name='Salvar').click()
    browser.close()
