<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME, 'core_197_')) { return; }
add_filter('pre_http_request',static fn($pre,$args,$url)=>wp_parse_url($url,PHP_URL_HOST)==='127.0.0.1' ? $pre : new WP_Error('offline','lab'),1,3);
add_filter('pre_wp_mail','__return_true',1);
add_shortcode('perfil197',static fn()=>'<h2>Nome de ensaio</h2><p>'.(is_user_logged_in()?'privado':'Perfil público').' Cargo, biografia e artigos</p>');
