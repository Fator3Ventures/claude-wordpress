import os,json,urllib.request
from pathlib import Path
from lxml import html
root=Path(os.environ['LAB197']); cfg=json.loads((root/'browser-local.json').read_text())
from urllib.parse import urlsplit
local=urlsplit(cfg['url'])
assert local.scheme=='http' and local.hostname=='127.0.0.1' and local.path.startswith('/wp-admin/')
req=urllib.request.Request(cfg['url'],headers={'Cookie':'; '.join(k+'='+v for k,v in cfg['cookies'].items())})
with urllib.request.urlopen(req,timeout=20) as resp: data=resp.read()
tree=html.fromstring(data)
rules={}
for name in ['email_suspeito','email_aceito','autenticacao_nao_confirmada','remetente_ausente','isca_comentario']:
    controls={}
    for field in ['suspeito','aviso','spam']:
        node=tree.xpath(f'//input[@name="sinais[{name}][{field}]"]')
        assert len(node)==1,(name,field)
        controls[field]='checked' in node[0].attrib
    rules[name]=controls
assert rules['email_suspeito']=={'suspeito':True,'aviso':False,'spam':False}
print(json.dumps({'titulo':tree.findtext('.//title'),'sinais':rules,'campos_conferidos':15},ensure_ascii=False))
