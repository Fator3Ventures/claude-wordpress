<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_197_aceite_troca') { return; }
add_action('plugins_loaded', static function() {
    $fake='https://hooks.slack.com/services/FIXTURE/ONLY/LOCAL';
    $cipher=F3Base_Segredos::cifrar(F3Base_Avisos::SEGREDO,$fake);
    add_filter('pre_option_'.F3Base_Avisos::SEGREDO,static fn()=>$cipher);
    add_filter('pre_option_f3base_avisos',static fn()=>['canal'=>'slack','slack_transporte'=>'webhook']);
    add_filter('pre_http_request',static fn($pre,$args,$url)=>$url===$fake?['headers'=>[],'response'=>['code'=>200,'message'=>'OK'],'body'=>'ok','cookies'=>[]]:$pre,PHP_INT_MAX,3);
},100);
