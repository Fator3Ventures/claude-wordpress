<?php
if (wp_get_environment_type()!=='local' || !str_starts_with(DB_NAME,'core_197_')) throw new RuntimeException('Somente laboratório');
$opt=F3Base_Formulario_Antispam::OPTION;
$c=F3Base_Config_Contrato::consultar(['nome'=>$opt]);$row=$c['opcoes'][$opt]??reset($c['opcoes']);
if (!isset($row['schema']['properties']['email_suspeito'])) throw new RuntimeException('Catálogo em execução incompatível');
echo wp_json_encode(['item'=>array_intersect_key($row,array_flip(['rotulo','descricao','schema','schema_entrada','campos','padrao'])),'operaveis'=>count(array_filter(F3Base_Options::nomes(),['F3Base_Options','operavel'])),'abilities'=>count(array_filter(array_keys(wp_get_abilities()),static fn($k)=>str_starts_with($k,'f3base/'))),'piso'=>F3Base_Config_Perfil::ID],JSON_UNESCAPED_UNICODE);
