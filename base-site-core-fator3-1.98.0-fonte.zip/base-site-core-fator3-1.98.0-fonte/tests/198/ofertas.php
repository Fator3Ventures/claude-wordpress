<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_198_troca') {
    throw new RuntimeException('Use a instalação integrada descartável.');
}
$acao = getenv('F3_438_ACAO');
$slug = 'precos';
$pagina = get_page_by_path($slug);
if ($acao === 'preparar') {
    $html = '<section data-f3base-oferta="plano-engagia"><h2>Plano Engagia</h2><p>R$ 497 por perfil de LinkedIn, por mês</p></section>'
        .'<section data-f3base-oferta="ghostwriter"><h2>Adicional Ghostwriter</h2><p>R$ 1.500 por perfil, por mês</p></section>';
    $id = wp_insert_post(['ID'=>$pagina->ID ?? 0, 'post_title'=>'Preços','post_name'=>$slug,'post_type'=>'page','post_status'=>'publish','post_content'=>$html], true);
    if (is_wp_error($id)) { throw new RuntimeException($id->get_error_message()); }
    $cfg = F3Base_Options::ler('f3base_seo_entidade');
    $cfg['servicos'] = [['nome'=>'Plataforma Engagia','ofertas'=>[
        ['id'=>'plano-engagia','nome'=>'Plano Engagia','pagina'=>$id,'modalidade'=>'fixo','moeda'=>'BRL','periodo'=>'mes','preco'=>'497'],
        ['id'=>'ghostwriter','nome'=>'Adicional Ghostwriter','pagina'=>$id,'modalidade'=>'fixo','moeda'=>'BRL','periodo'=>'mes','preco'=>'1500'],
    ]]];
    update_option('f3base_seo_entidade', $cfg);
    F3Base_Perfil_Publico::atualizar(false);
    flush_rewrite_rules(false);
    echo wp_json_encode(['pagina'=>$id,'url'=>get_permalink($id)]);
    return;
}
if (!$pagina) { throw new RuntimeException('Página de ensaio ausente'); }
$url = get_permalink($pagina);
if ($acao === 'reiniciar-prova') {
    F3Base_Options::atualizar_estado(F3Base_Ofertas::ESTADO, static fn($s) => []);
    return;
}
if ($acao === 'verificar-403') {
    $resultado = F3Base_Schema_Verificacao::verificar([$url], F3Base_Options::revisao('f3base_seo_entidade'));
    $pagina_verificada = $resultado['paginas'][0] ?? [];
    $avisos = array_values(array_filter($pagina_verificada['avisos'] ?? [], static fn($v) => ($v['url'] ?? '') === home_url('/perfil-externo-ensaio/')));
    echo wp_json_encode(['status'=>$resultado['status'], 'avisos'=>$avisos, 'estados'=>array_column($pagina_verificada['ofertas']['itens'] ?? [], 'estado')],JSON_UNESCAPED_SLASHES);
    return;
}
if ($acao === 'cron') {
    F3Base_Ofertas::cron();
    echo wp_json_encode(array_column(F3Base_Ofertas::consultar()['itens'], 'estado','oferta'));
    return;
}
if ($acao === 'editar') {
    wp_update_post(['ID'=>$pagina->ID,'post_content'=>str_replace('por perfil de LinkedIn', 'por perfil profissional', $pagina->post_content)]);
    return;
}
if ($acao === 'divergir') {
    wp_update_post(['ID'=>$pagina->ID,'post_content'=>str_replace('R$ 497', 'R$ 597', $pagina->post_content)]);
    return;
}
if ($acao === 'vencer') {
    F3Base_Options::atualizar_estado(F3Base_Ofertas::ESTADO, static function ($estado) {
        foreach ($estado['itens'] as &$item) { $item['em'] = time() - 90000; }
        return $estado;
    });
}
$resp = wp_remote_get($url, ['timeout'=>10]);
if (is_wp_error($resp) || 200 !== wp_remote_retrieve_response_code($resp)) { throw new RuntimeException('GET público falhou para '.$url); }
$html = wp_remote_retrieve_body($resp);
preg_match_all('~<script\b[^>]*type=["\']application/ld\+json["\'][^>]*>(.*?)</script>~is', $html, $blocks);
$offers=[];
$walk=static function ($node) use (&$walk,&$offers) {
    if (!is_array($node)) { return; }
    if (($node['@type']??'') === 'Offer') { $offers[] = ['id'=>$node['@id'],'preco'=>$node['priceSpecification']['price']??null]; }
    foreach ($node as $sub) { if (is_array($sub)) { $walk($sub); } }
};
foreach ($blocks[1] as $block) { $walk(json_decode($block,true)); }
$result = F3Base_Ofertas::observar($html,$url);
$itens=[];
foreach ($result['itens']??[] as $item) {
    $itens[$item['oferta']]=[$item['estado'],$item['conteudo'],$item['emissor_confirmado']];
}
echo wp_json_encode(['acao'=>$acao,'versao'=>F3BASE_PLUGIN_VERSAO,'http'=>200,'nos'=>$offers,'marcador'=>str_contains($html,'<!-- f3base-ofertas-v2 '),'itens'=>$itens],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
