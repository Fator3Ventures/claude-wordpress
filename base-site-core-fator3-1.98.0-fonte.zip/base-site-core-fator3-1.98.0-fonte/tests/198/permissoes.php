<?php
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME,'core_198_')) { throw new RuntimeException('Laboratório obrigatório'); }
$entradas = ['f3base/schema-verificar'=>['acao'=>'consultar'], 'f3base/documentacao-ler'=>[]];
$saida = [];
foreach ([1,0] as $id) {
    wp_set_current_user($id);
    foreach ($entradas as $nome => $entrada) {
        $ability = wp_get_ability($nome);
        if (!$ability) { throw new RuntimeException('Habilidade ausente'); }
        $resultado = $ability->check_permissions($entrada);
        $permitido = $resultado === true;
        if ($permitido !== ($id === 1 && DB_NAME === 'core_198_clean')) { throw new RuntimeException($nome.' permissão inesperada'); }
        $saida[$id ? 'administrador' : 'anonimo'][$nome] = is_wp_error($resultado) ? $resultado->get_error_code() : $permitido;
    }
}
echo wp_json_encode($saida,JSON_UNESCAPED_SLASHES);
