<?php
if (wp_get_environment_type() !== 'local' || DB_NAME !== 'core_198_troca') { throw new RuntimeException('Laboratório obrigatório'); }
$url = get_permalink(get_page_by_path('precos'));
$html = wp_remote_retrieve_body(wp_remote_get($url));
$ler = static function($html) use($url) {
    return array_column(F3Base_Ofertas::observar($html,$url)['itens'], 'estado');
};
$ver = static function($lista,$estado) {
    if ($lista !== [$estado,$estado]) { throw new RuntimeException($estado.' '.wp_json_encode($lista)); }
};
$ver($ler($html),'publicada');
$sem = preg_replace('~<!-- f3base-ofertas-v2 [A-Za-z0-9+/=]+ -->~','',$html);
$ver($ler($sem),'verificacao_pendente');
$cache = F3Base_Cache_Pagina::estado()['geracao'];
$ver($ler($sem),'verificacao_pendente');
if ($cache !== F3Base_Cache_Pagina::estado()['geracao']) { throw new RuntimeException('Segunda leitura repetiu a limpeza'); }
$terceiro = '<script type="application/ld+json">'.wp_json_encode(['@type'=>'Service','@id'=>$url.'#terceiro','name'=>'Plataforma Engagia']).'</script>';
$ver($ler($html.$terceiro),'ocupado_por_outro_emissor');
$ver(array_column(F3Base_Ofertas::consultar()['itens'],'estado'),'ocupado_por_outro_emissor');
$servico=F3Base_Options::ler('f3base_seo_entidade')['servicos'][0];
if (F3Base_Ofertas::emitir($servico, get_page_by_path('precos')->ID)) { throw new RuntimeException('Conflito permitiu emissão'); }
echo wp_json_encode(['sem_marcador'=>'pendente','segunda_leitura'=>'sem_nova_limpeza','conflito'=>'preservado_na_consulta','emissao_com_conflito'=>0]);
