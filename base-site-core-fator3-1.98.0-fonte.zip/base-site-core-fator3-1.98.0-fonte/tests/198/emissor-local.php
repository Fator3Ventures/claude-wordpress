<?php
/** Somente no WordPress descartável sem Yoast. Exercita o filtro real do Core no wp_head. */
if (wp_get_environment_type() !== 'local' || !str_starts_with(DB_NAME, 'core_198_')) { return; }
add_filter('http_allowed_safe_ports', static fn($ports) => array_merge($ports, [34198]));
add_action('template_redirect', static function () {
    if (wp_parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) === '/perfil-externo-ensaio/') {
        status_header(403);
        exit;
    }
}, 0);
add_action('wp_head', static function () {
    if (defined('WPSEO_VERSION') || !is_singular('page')) { return; }
    $grafo = apply_filters('wpseo_schema_graph', [['@type'=>'WebPage','@id'=>get_permalink()], ['@type'=>'Organization','@id'=>home_url('/#organization'),'name'=>'Organização de ensaio','sameAs'=>[home_url('/perfil-externo-ensaio/')]]]);
    echo '<script type="application/ld+json">'.wp_json_encode(['@context'=>'https://schema.org','@graph'=>$grafo]).'</script>';
}, 10);
