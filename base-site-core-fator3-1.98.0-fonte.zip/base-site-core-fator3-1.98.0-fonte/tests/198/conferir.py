"""Valida os resultados JSON das passagens independentes de HTTP e WP-CLI."""
import json
from pathlib import Path
import sys
base = Path(sys.argv[1])
def read(name):
    return json.loads((base / (name + '.json')).read_text())
for name in ('antigo-observado1', 'antigo-observado2'):
    v = read(name)
    assert v['nos'] == [] and all(s == ['verificacao_pendente','verified',False] for s in v['itens'].values())
for name in ('novo-nova1', 'novo-nova2', 'novo-apos-edicao', 'novo-confirmar'):
    v = read(name)
    assert [x['id'].split('#')[-1] for x in v['nos']] == ['f3base-offer-05c2ec61956d4673ea24d319','f3base-offer-505a0b0361d204ac5c993cee']
    assert [x['preco'] for x in v['nos']] == ['497','1500'] and v['marcador']
    assert list(v['itens'].values()) == [['publicada','verified',True]] * 2
v = read('novo-confirma-retirada')
assert len(v['nos']) == 1 and v['itens']['plano-engagia'][0] == 'divergente' and v['itens']['ghostwriter'][0] == 'publicada'
assert not read('novo-vencer')['nos']
assert list(read('borda-cron').values()) == ['verificacao_pendente'] * 2
assert list(read('borda-cron2').values()) == ['publicada'] * 2
v = read('borda-verificar-403')
assert v['status'] == 'inconclusivo' and v['estados'] == ['publicada'] * 2
assert any(a['http'] == 403 and a['categoria'] == 'inconclusivo' for a in v['avisos'])
assert read('controles')['emissao_com_conflito'] == 0
print('Casos de publicação, edição, retirada, expiração, cron, conflito, marcador e sameAs aprovados.')
