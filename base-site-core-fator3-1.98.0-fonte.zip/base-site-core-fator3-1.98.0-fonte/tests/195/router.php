<?php
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);
if ($path === '/wp-json' || str_starts_with($path,'/wp-json/')) {
    $_GET['rest_route']=substr($path,8) ?: '/';
    require getcwd().'/index.php';
    return;
}
return false;
