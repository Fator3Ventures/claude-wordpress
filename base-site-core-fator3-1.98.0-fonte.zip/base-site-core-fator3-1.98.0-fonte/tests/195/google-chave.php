<?php
/** Run only on a disposable loopback WordPress. Provider traffic and mail are intercepted. */
use Fator3\McpGoogle\{Auth\KeyStatus, Auth\Credentials, Options, Settings, Connections, Policy, Http\GoogleClient, Automation\Alerts, Readiness};
if (wp_parse_url(home_url(), PHP_URL_HOST) !== '127.0.0.1') throw new RuntimeException('Loopback required');
wp_set_current_user(1);
$phase = getenv('F3_PHASE38');
$iam = 'denied';
$rejectToken = false;
$mail = [];
$calls = [];
$checks = [];
$assert = static function ($ok, $label) use (&$checks) {
    if (!$ok) throw new RuntimeException($label);
    $checks[] = $label;
};
add_filter('pre_wp_mail', static function ($unused, $args) use (&$mail) {
    $mail[] = $args;
    return true;
}, PHP_INT_MAX, 2);
add_filter('pre_http_request', static function ($unused, $args, $url) use (&$iam, &$rejectToken, &$calls) {
    $host = wp_parse_url($url, PHP_URL_HOST);
    $calls[] = $host;
    $code = 200;
    if ($host === 'oauth2.googleapis.com') {
        $code = $rejectToken ? 400 : 200;
        $data = $rejectToken ? ['error'=>'invalid_grant'] : ['access_token'=>'synthetic-lab038','expires_in'=>3600];
    } elseif ($host === 'iam.googleapis.com') {
        [$code,$data] = match ($iam) {
            'denied'=>[403,['error'=>['status'=>'PERMISSION_DENIED','message'=>'Permission iam.serviceAccountKeys.get denied']]],
            'disabled'=>[403,['error'=>['status'=>'PERMISSION_DENIED','details'=>[['reason'=>'SERVICE_DISABLED']]]]],
            'unavailable'=>[503,['error'=>['status'=>'UNAVAILABLE']]],
            default=>[200,['name'=>'projects/lab-038/serviceAccounts/lab@lab-038.iam.gserviceaccount.com/keys/k038','validBeforeTime'=>'2099-01-01T00:00:00Z','disabled'=>false]]
        };
    } elseif ($host === 'analyticsdata.googleapis.com') {
        $data = ['rowCount'=>1,'rows'=>[['metricValues'=>[['value'=>'12']]]]];
    } else {
        return new WP_Error('unexpected_http', 'Unrecognized host in lab');
    }
    return ['response'=>['code'=>$code],'body'=>wp_json_encode($data),'headers'=>[]];
}, 1, 3);
function open_google038(): array {
    $all = F3Base_Incidentes::listar();
    if (empty($all['ok']) || $all['proximo'] !== null) throw new RuntimeException('Unexpected Core page');
    return array_values(array_filter($all['itens'], static fn($r)=>$r['pacote']==='google' && $r['estado']==='aberto'));
}
if ($phase !== 'upgrade') {
    $private = openssl_pkey_new(['private_key_bits'=>2048]);
    openssl_pkey_export($private,$pem);
    $key = ['type'=>'service_account','project_id'=>'lab-038','private_key_id'=>'k038','private_key'=>$pem,
        'client_email'=>'lab@lab-038.iam.gserviceaccount.com','token_uri'=>'https://oauth2.googleapis.com/token'];
    update_option('f3base_avisos_tecnicos',['email'=>'lab@example.invalid']);
    $write = Options::batch_verified([Options::ENABLED=>true, Options::GA_ENABLED=>true, Options::AUTH_MODE=>'service_account',
        Settings::AUTH_READY=>true, Connections::SERVICES=>['ga'=>'read'],Policy::OPTION=>['mode'=>'identity','services'=>[]]],
        [Options::SA_JSON=>wp_json_encode($key)]);
    $assert($write['success'],'Test identity configured');
}
if ($phase === 'base') {
    $assert(F3_MCP_GOOGLE_VERSION==='0.37.0','Original 0.37.0');
    KeyStatus::refresh([]);
    $codes=array_column(open_google038(),'codigo');sort($codes);
    $assert($codes===['credencial_invalida','integracao_indisponivel'],'Both original false positives reproduced');
    update_option('qa38-origin-hash',hash('sha256',serialize(Options::stored(Options::storage_name(Options::SA_JSON)))));
} else {
    $assert(F3_MCP_GOOGLE_VERSION==='0.38.0','Installed target');
    if ($phase==='upgrade') {
        $assert(get_option('qa38-origin-hash') === hash('sha256',serialize(Options::stored(Options::storage_name(Options::SA_JSON)))),'Ciphertext survived direct upgrade');
        KeyStatus::refresh_due();
    } else KeyStatus::refresh([]);
    $status = KeyStatus::status();
    $assert($status['metadata_state']==='permission_denied' && $status['project_id']==='lab-038' && $status['required_permission']==='iam.serviceAccountKeys.get','403 identifies permission and project');
    $assert(array_column(open_google038(),'codigo')===['autorizacao_recusada'],'One active Core notice, no invalid credential');
    $incidents=Alerts::state([],true)['incidents'];
    $assert(count($incidents)===1 && $incidents[0]['event']==='key_metadata' && str_contains($incidents[0]['action'],'lab-038'),'One actionable local incident');
    $ready=Readiness::read([]);
    $assert(str_contains(wp_json_encode($ready),'key_metadata_permission_denied') && !str_contains(wp_json_encode($ready),'http_403'),'Readiness reports the IAM event only');
    if ($phase==='capture') return;
    $num=count($mail);
    $action=GoogleClient::request('POST','https://analyticsdata.googleapis.com/v1beta/properties/123:runReport',['metrics'=>[['name'=>'sessions']]],['connector'=>'ga','mode'=>'read','scopes'=>Credentials::scopes_for('ga')]);
    $assert(is_array($action) && $action['rowCount']===1,'Authenticated GA4 report still succeeds');
    KeyStatus::refresh([]);Alerts::dispatch(); F3Base_Incidentes_Provedores::google();
    $assert(count($mail)===$num && count(open_google038())===1,'Repeated 403 and Core collector do not duplicate notice');
    if ($phase==='patch') {
        $row=open_google038()[0];
        $assert($row['iam']===['permissao'=>'iam.serviceAccountKeys.get','projeto'=>'lab-038'],'Experimental Core exposes bounded diagnostic');
        $assert(count(array_filter($mail,static fn($m)=>str_contains($m['subject'],'não consultável') && str_contains($m['message'],'iam.serviceAccountKeys.get') && str_contains($m['message'],'lab-038')))===1,'Experimental mail carries permission and project once');
    }
    $iam='ok';KeyStatus::refresh([]);
    $assert(open_google038()===[] && KeyStatus::status()['known'],'Verified metadata closes episode');
    $iam='disabled';KeyStatus::refresh([]);
    $assert(KeyStatus::status()['metadata_state']==='unavailable' && KeyStatus::status()['required_permission']===null && KeyStatus::status()['known'],'Disabled API preserves last validity and distinct diagnosis');
    $iam='unavailable';KeyStatus::refresh([]);
    $assert(!in_array('credencial_invalida',array_column(open_google038(),'codigo'),true),'IAM outage is not invalid authentication');
    $rejectToken=true;Credentials::invalidate_cache();$before=count(array_filter($calls,static fn($h)=>$h==='iam.googleapis.com'));KeyStatus::refresh([]);
    $assert(KeyStatus::status()['metadata_state']==='token_rejected' && array_column(open_google038(),'codigo')===['credencial_invalida'],'Token endpoint invalid_grant opens credential notice');
    $assert($before===count(array_filter($calls,static fn($h)=>$h==='iam.googleapis.com')),'Rejected token prevents IAM dispatch');
    $rejectToken=false;$iam='ok';KeyStatus::refresh([]);
    $assert(open_google038()===[],'Successful retry closes credential episode');
}
file_put_contents(getenv('F3_RESULT38'),wp_json_encode(['phase'=>$phase,'version'=>F3_MCP_GOOGLE_VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'passed'=>$checks,'count'=>count($checks),'failures'=>0,'google_http'=>'intercepted','mail'=>'intercepted'],JSON_PRETTY_PRINT));
echo count($checks)." checks passed\n";
