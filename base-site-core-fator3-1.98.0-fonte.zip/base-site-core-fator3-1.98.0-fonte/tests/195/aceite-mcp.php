<?php
/** Observe the Core acceptance criterion using the authenticated MCP transport. */
if (wp_parse_url(home_url(), PHP_URL_HOST) !== '127.0.0.1') throw new RuntimeException('Loopback required');
wp_set_current_user(1);
require __DIR__.'/rpc.php';
$credential = rpc_identityLab();
$GLOBALS['auth'] = $credential['auth'];
try {
    $response = rpcLab('f3base/incidentes-tecnicos-ler');
    if (empty($response['ok']) || !array_key_exists('proximo', $response) || $response['proximo'] !== null) {
        throw new RuntimeException('Core listing incomplete '.implode(',', array_keys($response)));
    }
    $open = array_values(array_filter($response['itens'], static fn($row) => $row['pacote'] === 'google' && $row['estado'] === 'aberto'));
    if (array_column($open, 'codigo') !== ['autorizacao_recusada']) throw new RuntimeException('Unexpected open Google records');
    $details = $open[0]['iam'] ?? null;
    $patched = F3BASE_PLUGIN_VERSAO === '1.95.0';
    if (($patched && $details !== ['permissao'=>'iam.serviceAccountKeys.get', 'projeto'=>'lab-038']) || (!$patched && $details !== null)) {
        throw new RuntimeException('Unexpected Core IAM context');
    }
    $results = ['core'=>F3BASE_PLUGIN_VERSAO, 'transport'=>'MCP HTTP loopback', 'complete'=>true,
        'open_google_codes'=>array_column($open, 'codigo'), 'iam'=>$details];
    $user = wp_insert_user(['user_login'=>'qa038-ordinary', 'user_pass'=>wp_generate_password(), 'role'=>'subscriber']);
    if (is_wp_error($user)) throw new RuntimeException($user->get_error_code());
    try {
        wp_set_current_user($user);
        foreach (['google/service-account-key-status','google/refresh-service-account-key-status'] as $name) {
            $op = wp_get_ability($name);
            if (!$op || $op->check_permissions([]) === true) throw new RuntimeException('Unexpected authorization for '.$name);
            $results['subscriber'][$name] = 'denied';
        }
    } finally {
        wp_set_current_user(1);
        require_once ABSPATH.'wp-admin/includes/user.php';
        wp_delete_user($user);
    }
    file_put_contents(getenv('F3_RESULT38'), wp_json_encode($results,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
} finally {
    WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
    Fator3\McpFiles\Persistence::delete('connections',$credential['id']);
}
