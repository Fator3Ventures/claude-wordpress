<?php
/** Local test fixture. Never part of the installer. */
if (wp_get_environment_type() !== 'local' || !is_file(ABSPATH.'f3-disposable-lab.marker')) return;
if (is_file(ABSPATH.'f3-test-disable-server')) add_filter('f3_mcp_create_default_server','__return_false');
add_filter('f3base_incidente_publicar_v1',static function($result,$event) {
    if ($event['recurso']==='registro-wordpress') {
        $context=defined('WP_CLI') && WP_CLI ? 'cli' : (wp_doing_cron() ? 'http_cron':'web');
        file_put_contents(ABSPATH.'f3-test-events.jsonl',wp_json_encode(['version'=>F3_MCP_FILES_VERSION,
            'context'=>$context,'state'=>$event['estado']]).PHP_EOL,FILE_APPEND|LOCK_EX);
    }
    return $result;
},90,2);
add_action('shutdown',static function() {
    if (PHP_SAPI==='cli' || !is_file(ABSPATH.'f3-test-core-observer')) return;
    F3Base_Incidentes::observar_registro_canal();
    Fator3\McpFiles\ChannelIncidents::observeRegistration(true);
    F3Base_Incidentes::observar_registro_canal();
});
if (is_file(ABSPATH.'f3-test-early')) {
    add_action('f3_mcp_adapter_init',static function() {
        Fator3\McpFiles\ChannelIncidents::observe(true);
    }, 0);
}
