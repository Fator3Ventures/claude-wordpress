"""Run with the local PHP web server pointed at a disposable site and with WP-Cron spawning disabled."""
import argparse,json,urllib.request
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--site',type=Path,required=True)
parser.add_argument('--port',type=int,required=True)
parser.add_argument('--out',type=Path,required=True)
args=parser.parse_args()
site=args.site
assert (site/'f3-disposable-lab.marker').is_file()
path=site/'f3-test-events.jsonl'
def events():
    return [json.loads(x) for x in path.read_text().splitlines()] if path.exists() else []
cases=[]
def visit(mode,broken,expected_count,expected_change):
    flag=site/'f3-test-disable-server'
    if broken: flag.touch()
    else: flag.unlink(missing_ok=True)
    cron=site/'f3-test-http-cron'
    if mode=='http_cron':cron.touch()
    else:cron.unlink(missing_ok=True)
    before=len(events())
    with urllib.request.urlopen('http://127.0.0.1:'+str(args.port)+'/registration.php',timeout=40) as resp:
        value=json.load(resp)
    new=events()[before:]
    assert value['count']==expected_count and value['context']==mode,(value,new)
    assert [x['state'] for x in new]==expected_change and all(x['context']==mode for x in new),(value,new)
    cases.append(dict(context=mode,broken=broken,failures=expected_count,transitions=expected_change))
visit('web',True,1,[])
visit('http_cron',False,0,['recuperado'])
visit('web',True,1,[])
visit('http_cron',True,2,['aberto'])
visit('web',True,2,[])
visit('web',False,0,['recuperado'])
args.out.write_text(json.dumps(cases,indent=2)+'\n')
