<?php
if (DB_NAME !== 'core_195_migracao' || wp_get_environment_type() !== 'local') throw new RuntimeException('Laboratório obrigatório');
$aviso = static function () {
    $itens = F3Base_Incidentes::listar()['itens'];
    $alvos = array_values(array_filter($itens, static fn($r) => $r['pacote'] === 'google' && $r['codigo'] === 'autorizacao_recusada' && $r['estado'] === 'aberto'));
    if (count($alvos) !== 1) throw new RuntimeException('Esperada uma abertura Google');
    return $alvos[0];
};
if (F3BASE_PLUGIN_VERSAO === '1.94.0') {
    $r = $aviso();
    if (isset($r['iam']) || $r['entregas_pendentes'] !== 0 || ($r['ultimo_envio']['fase'] ?? '') !== 'aberto') throw new RuntimeException('Pré-condição da migração');
    update_option('qa195-antes', array_intersect_key($r,array_flip(['id','desde','ultimo_envio','recurso_ref'])), false);
    echo "Abertura consumida confirmada na 1.94.0\n";
    return;
}
$mails = 0;
add_filter('pre_wp_mail',static function ($r) use (&$mails) {++$mails; return true;}, PHP_INT_MAX);
F3Base_Zelador::atualizacao_urgente();
F3Base_Incidentes_Provedores::google();
F3Base_Incidentes_Provedores::google();
$r = $aviso();
$antes = get_option('qa195-antes');
$preservado = array_intersect_key($r,$antes) === $antes;
if (!$preservado || $r['entregas_pendentes'] !== 0 || $mails !== 0 || $r['iam'] !== ['permissao'=>'iam.serviceAccountKeys.get','projeto'=>'lab-038']) throw new RuntimeException('Falha no enriquecimento em migração');
echo wp_json_encode(['origem'=>'1.94.0','versao'=>F3BASE_PLUGIN_VERSAO,'nova_entrega'=>$mails,'identidade_data_recibo_preservados'=>$preservado,'pendentes'=>0,'iam'=>$r['iam']], JSON_PRETTY_PRINT);
