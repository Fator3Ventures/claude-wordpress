<?php
// Copy beside wp-load.php in the disposable laboratory. Returns only test measurements.
if (!is_file(__DIR__.'/f3-disposable-lab.marker') || !in_array($_SERVER['REMOTE_ADDR'] ?? '',['127.0.0.1','::1'],true)) {
    http_response_code(403); exit;
}
if (is_file(__DIR__.'/f3-test-http-cron')) define('DOING_CRON',true);
require __DIR__.'/wp-load.php';
Fator3\McpFiles\ChannelIncidents::observe(true);
$sample=Fator3\McpFiles\StateStore::get('automation','registration-sample');
header('Content-Type: application/json');
echo wp_json_encode(['version'=>F3_MCP_FILES_VERSION,'count'=>$sample['failures']??null,'context'=>wp_doing_cron()?'http_cron':'web']);
