<?php
if (DB_NAME !== 'core_195_canal' || wp_get_environment_type() !== 'local') throw new RuntimeException('Somente em laboratório');
F3Base_Incidentes::observar_registro_canal();
F3Base_Incidentes::observar_registro_canal();
$ref = hash_hmac('sha256','registro-wordpress',wp_salt('auth'));
$rows = array_values(array_filter(F3Base_Incidentes::listar()['itens'],static fn($r) => $r['recurso_ref'] === $ref));
if (getenv('F3_ANTES') === '1') {
    if ($rows) throw new RuntimeException('CLI gerou episódio antes do primeiro HTTP');
    return;
}
if (count($rows) !== 1) throw new RuntimeException('Registro não é único');
$r = $rows[0];
$h = $r['historico_registro'];
if (array_column($h,'estado') !== ['aberto','recuperado'] || array_column($h,'origem') !== ['publicador_canal','publicador_canal']
    || array_column($h,'contexto') !== ['http_cron','web'] || $r['estado'] !== 'recuperado' || $r['entregas_pendentes'] !== 2) throw new RuntimeException(wp_json_encode($h));
echo wp_json_encode(['estados'=>array_column($h,'estado'),'contextos'=>array_column($h,'contexto'),'produtores'=>array_column($h,'origem'),'pendentes_sinteticos'=>$r['entregas_pendentes'],'cli_antes_depois'=>'sem transição'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
