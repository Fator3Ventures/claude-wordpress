<?php
/** F3BASE_SITE deve apontar para wp-load.php do laboratório integrado. */
define('WP_ADMIN', true);
$_SERVER['REQUEST_METHOD']='GET';
$_SERVER['HTTP_HOST']='127.0.0.1:33795';
$_SERVER['REQUEST_URI']='/wp-admin/tools.php';
require getenv('F3BASE_SITE');
if (wp_get_environment_type()!=='local' || !str_starts_with(DB_NAME,'core_196_')) {throw new RuntimeException('Somente banco de ensaio');}
wp_set_current_user(1);
$dest='prova194@example.invalid';
$id=wp_generate_uuid4(); $mail=[];$externas=0;
add_filter('pre_option_f3base_avisos_tecnicos', static fn()=>['email'=>$dest,'antecedencia_dias'=>14]);
add_filter('pre_wp_mail', static function($pre,$a) use (&$mail,$dest) {
    if ($a['to']!==$dest) {throw new RuntimeException('Destino inesperado');}
    $mail[]=$a['subject'];return true;
},999,2);
add_filter('pre_http_request',static function()use(&$externas){$externas++;return new WP_Error('bloqueada');},999,3);
foreach ([true,true,false,false] as $aberto) {
    $g=\Fator3\McpGoogle\TechnicalNotices::publish('integracao_indisponivel',$id,$aberto);
    if (empty($g['ok'])) {throw new RuntimeException('Google recusado');}
    \Fator3\LinkedIn\SiteOperations::incident('agenda_parada',$id,$aberto);
}
foreach (['google'=>'integracao_indisponivel','linkedin'=>'agenda_parada'] as $p=>$c) {
    foreach (['Incidente técnico','Recuperação técnica'] as $fase) {
        if(count(array_keys($mail,"$fase · $p · $c"))!==1) {throw new RuntimeException('Contagem incorreta para '.$p);}
    }
}
// Recurso sintético exclusivo deste teste, independente do estado do laboratório.
$evento=['pacote'=>'pipedrive','codigo'=>'autorizacao_recusada','recurso'=>$id,'estado'=>'aberto'];
$publicado=apply_filters('f3base_incidente_publicar_v1', null, $evento);
if (empty($publicado['ok'])) {throw new RuntimeException('Incidente sintético do Pipedrive recusado');}
$leitura=\Fator3\Pipedrive\Incidents::read();
$ref=hash_hmac('sha256',$id,wp_salt('auth'));
$linhas=$leitura['itens'];
while (!$leitura['fim']) {
    $leitura=\Fator3\Pipedrive\Incidents::read(['apos'=>$leitura['proximo_apos']]);
    $linhas=array_merge($linhas,$leitura['itens']);
}
$projecao=array_filter($linhas,static fn($i)=>$i['codigo']==='autorizacao_recusada' && $i['recurso_ref']===$ref && $i['estado']==='aberto');
if ($externas || count($projecao)!==1) {throw new RuntimeException('Projeção Pipedrive ou HTTP inesperado');}
wp_set_current_user(0);
$a=wp_get_ability('f3base/incidentes-tecnicos-ler');
$resultado=$a->execute([]);
if (get_current_user_id()!==0 || $a->check_permissions([])!==false || !is_array($resultado)
    || ($resultado['success']??null)!==false || ($resultado['error_code']??'')!=='permission_denied'
    || isset($resultado['itens']) || isset($resultado['data'])) {throw new RuntimeException('Resultado inesperado para visitante no MCP');}
echo wp_json_encode(['wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'entregas'=>$mail,'pipedrive'=>count($projecao),'http'=>$externas,'visitante'=>$resultado['error_code']],JSON_UNESCAPED_UNICODE).PHP_EOL;
