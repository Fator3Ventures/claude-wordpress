<?php
use Fator3\McpGoogle\{Connections,ConversionDelivery,Options};
if (wp_get_environment_type()!=='local' || DB_NAME!=='core_196_migracao') throw new RuntimeException('Exige banco descartável');
wp_set_current_user(1);
$checks=[]; $mails=[];
$assert=static function($ok,$label) use (&$checks) { if (!$ok) throw new RuntimeException($label); $checks[]=$label; };
add_filter('pre_wp_mail',static function($v,$args) use (&$mails) {$mails[]=$args; return true;}, PHP_INT_MAX,2);
update_option('f3base_avisos_tecnicos',['email'=>'fixture@example.invalid','antecedencia_dias'=>14]);
function gravar196($id,$provas,$renovacoes) {
    Connections::run($id,static function() use ($provas,$renovacoes) {
        $r=Options::set(ConversionDelivery::CONFIG,['enabled'=>true,'verified'=>$provas,'renewal'=>$renovacoes]);
        if (empty($r['success'])) throw new RuntimeException('Gravação da configuração de prova');
    });
}
function prova196($idade,$duracao) {$t=time()-$idade;return ['at'=>$t,'expires'=>$t+$duracao];}
function linha196($recurso,$codigo='prova_vencendo') {
    $ref=hash_hmac('sha256',$recurso,wp_salt('auth'));
    foreach(F3Base_Incidentes::listar()['itens'] as $r) if($r['codigo']===$codigo && $r['recurso_ref']===$ref) return $r;
    return [];
}
function assuntos196($mails) {return array_column($mails,'subject');}
$prova=prova196(100,86400);
$normal=['result'=>'success','last_at'=>$prova['at'],'next_attempt'=>$prova['at']+43200];
if (F3BASE_PLUGIN_VERSAO==='1.95.0') {
    gravar196('default',['ga4'=>$prova,'google_ads'=>$prova],['ga4'=>$normal,'google_ads'=>$normal]);
    F3Base_Incidentes_Provedores::google();
    foreach (['ga4','google_ads'] as $alvo) $assert(linha196('default/'.$alvo)['estado']==='aberto','Falso positivo reproduzido '.$alvo);
    $assert(count(array_keys(assuntos196($mails),'Incidente técnico · google · prova_vencendo'))===2,'Duas mensagens na base');
    update_option('f3qa196_refs',array_map(static fn($a)=>linha196('default/'.$a)['id'],['ga4','google_ads']));
    echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'verificacoes'=>$checks]); return;
}
F3Base_Incidentes_Provedores::google();
foreach (['ga4','google_ads'] as $i=>$alvo) {
    $r=linha196('default/'.$alvo);
    $assert($r['estado']==='recuperado' && $r['id']===get_option('f3qa196_refs')[$i] && $r['entregas_pendentes']===0,'Primeira coleta recupera a referência anterior '.$alvo);
}
$assert(count(array_keys(assuntos196($mails),'Recuperação técnica · google · prova_vencendo'))===2,'Uma recuperação enviada por destino');
$n=count($mails);
for($hora=0;$hora<=72;$hora++) {
    // Idade da prova na hora correspondente com renovação normal a cada 12 horas.
    $p=prova196(($hora%12)*3600,86400);
    gravar196('default',['ga4'=>$p,'google_ads'=>['at'=>$p['at'],'expires'=>null]],['ga4'=>['result'=>'success','last_at'=>$p['at'],'next_attempt'=>$p['at']+43200]]);
    F3Base_Incidentes_Provedores::google();
    if(linha196('default/ga4')['estado']!=='recuperado' || linha196('default/google_ads')['estado']!=='recuperado') throw new RuntimeException('Reabertura '.$hora);
}
$assert(count($mails)===$n,'73 observações horárias simuladas, zero reaberturas e zero novos e-mails');
$criada=Connections::create('secundaria196','Secundária');$assert(!empty($criada['success']),'Segunda conexão');
$p=prova196(19*3600,86400); $curta=prova196(7*3600,8*3600);$longa=prova196(3*86400,20*86400);
gravar196('secundaria196',['ga4'=>$p,'curta'=>$curta,'longa'=>$longa,'renova_tarde'=>$curta],['ga4'=>['result'=>'failed','last_at'=>time()-10,'next_attempt'=>time()+43200],'renova_tarde'=>['result'=>'success','last_at'=>$curta['at'],'next_attempt'=>$curta['expires']-60]]);
F3Base_Incidentes_Provedores::google();
$r=linha196('secundaria196/ga4');
$assert($r['estado']==='aberto' && $r['desde']===$p['expires']-21600 && $r['vence_em']>time(),'Prova 24h atrasada abre seis horas antes de vencer; backoff não posterga');
$assert(linha196('secundaria196/ga4','renovacao_falhou')['estado']==='aberto','Falha real de renovação tem episódio próprio');
$assert(linha196('secundaria196/curta')['desde']===$curta['expires']-7200 && !linha196('secundaria196/longa') && !linha196('secundaria196/renova_tarde'),'Validades de 8 horas e 20 dias; margem respeita renovação tardia');
$assert(linha196('default/ga4')['estado']==='recuperado','Isolamento por conexão');
gravar196('secundaria196',['curta'=>['expires'=>null]],[]);F3Base_Incidentes_Provedores::google();
$assert(linha196('secundaria196/curta')['estado']==='aberto','Leitura sem início preserva episódio');
gravar196('secundaria196',['curta'=>['at'=>time()-10,'expires'=>null]],[]);F3Base_Incidentes_Provedores::google();
$assert(linha196('secundaria196/curta')['estado']==='recuperado','Validade explicitamente sem prazo recupera o destino');
F3Base_Incidentes::vencimento('linkedin','token_vencendo','qa196-longo',time()+13*86400);
$assert(linha196('qa196-longo','token_vencendo')['estado']==='aberto','Antecedência de 14 dias mantida para credencial');
echo wp_json_encode(['versao'=>F3BASE_PLUGIN_VERSAO,'wp'=>get_bloginfo('version'),'php'=>PHP_VERSION,'verificacoes'=>$checks,'horas_simuladas'=>72,'observacoes_horarias'=>73,'novos_emails_durante_renovacoes'=>0],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);
