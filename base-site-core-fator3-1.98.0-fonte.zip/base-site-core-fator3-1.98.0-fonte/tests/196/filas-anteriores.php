<?php
// Executado dentro do ensaio do produtor, após a prova de aquisição e etapa na mesma conexão.
$novo = static function($consent=true) use ($d,$age,$ref,$wpdb) {
    $rr=F3Base_Leads_Repositorio::guardar(['nome'=>'Ensaio legado','email'=>'legado'.bin2hex(random_bytes(4)).'@example.invalid','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture','contexto_teste'=>false,'notificar'=>false]);
    $id=$rr['record_id']; $dados=$d; $dados['consentimento_snapshot']['publicidade']=$consent;
    $wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($dados),'criado_em'=>gmdate('Y-m-d H:i:s',$age),'classe_trafego'=>'nao_marcado'],['record_id'=>$id]);
    $lead=F3Base_Leads_Repositorio::obter($id);F3Base_Conversoes_Servidor::capturar($lead,'google_ads'); return $lead;
};
foreach (['recusado','incerto','revogado'] as $cenario) {
    $novoLead=$novo($cenario!=='revogado');$id=$novoLead['record_id'];$f=['record_id'=>$id,'destino'=>'google_ads'];
    $wpdb->update($qtab,['estado'=>$cenario==='recusado'?'recusado':'incerto','codigo'=>$cenario==='recusado'?'ads_terms_refused':'ads_retry_same_transaction','tentativas'=>10,'proxima'=>time()-1],$f);
    F3Base_Execucoes::encerrar();F3Base_Conversoes_Servidor::processar();
    $row=$wpdb->get_row($wpdb->prepare('SELECT estado,codigo FROM %i WHERE record_id=%s AND destino=%s',$qtab,$id,'google_ads'),ARRAY_A);
    if ($cenario==='revogado') $ok($row['estado']==='cancelado' && empty($actions[$id]),'Aquisição antiga revalida consentimento antes do envio',$row);
    else $ok($row['estado']==='incerto' && ($actions[$id]??[])===['ok'],'Aquisição antiga, décima tentativa, vínculo original, estado '.$cenario,$row);
}
foreach (['recusado','destino_alterado','incerto_generico'] as $cenario) {
    $leadEtapa=$novo();$id=$leadEtapa['record_id'];$keyEtapa=hash('sha256',get_current_blog_id().'|'.$id.'|google_ads|qualificado');
    F3Base_Qualidade_Destinos::registrar($leadEtapa,'qualificado',$age+30);
    $campos=['estado'=>$cenario==='incerto_generico'?'incerto':'recusado','codigo'=>$cenario==='incerto_generico'?'envio_iniciado':'ads_terms_refused','atualizado_em'=>time()-7200];
    if ($cenario==='destino_alterado') $campos['destino_ref']='fixture-outro-destino';
    $wpdb->update($tbl,$campos,['chave'=>$keyEtapa]);
    F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();
    $row=$wpdb->get_row($wpdb->prepare('SELECT estado,codigo FROM %i WHERE chave=%s',$tbl,$keyEtapa),ARRAY_A);
    if($cenario==='recusado') $ok($row['estado']==='incerto' && ($actions['f3q-'.$keyEtapa]??[])===['ok'],'Etapa recusada pela base anterior retoma pelo mesmo evento',$row);
    else $ok(empty($actions['f3q-'.$keyEtapa]) && in_array($row['estado'],['bloqueado','incerto'],true),'Etapa sem redespacho, motivo '.$cenario,$row);
}
$ok(!F3Base_Conversoes_Servidor::retomar_ads('google_ads',['status'=>'recusado','code'=>'ads_terms_refused','non_delivery_proven'=>false])
    && !F3Base_Conversoes_Servidor::retomar_ads('linkedin',['status'=>'incerto','code'=>'ads_retry_same_transaction'])
    && !F3Base_Conversoes_Servidor::retomar_ads('google_ads',['status'=>'incerto','code'=>'data_manager_pending']),'Retentativa restrita ao código, destino e prova de não entrega previstos');
