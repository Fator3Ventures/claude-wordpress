<?php
/** Run in an isolated loopback WordPress. No Google traffic or external mail. */
use Fator3\McpGoogle\{Options as O,Connections as C,Policy,Settings,ConversionDelivery as D,StageConversionDelivery as S,Readiness,Ads\PlannerAccess as P};
if (wp_parse_url(home_url(),PHP_URL_HOST)!=='127.0.0.1') throw new RuntimeException('Loopback required');
wp_set_current_user(1);
$phase=getenv('F3_PHASE39');$checks=[];$ga='ok';$ads='ok';$mail=0;$calls=[];$actions=[];
$ok=static function($condition,$name,$detail=null)use(&$checks){if(!$condition)throw new RuntimeException($name.' '.wp_json_encode($detail));$checks[]=$name;};
add_filter('pre_wp_mail',static function()use(&$mail){++$mail;return true;},PHP_INT_MAX);
add_filter('pre_http_request',static function($pre,$args,$url)use(&$ga,&$ads,&$calls,&$actions){
 $code=200;$body=[];$host=wp_parse_url($url,PHP_URL_HOST);$path=wp_parse_url($url,PHP_URL_PATH);$raw=$args['body']??[];$q=is_string($raw)?(json_decode($raw,true)?:[]):$raw;
 if($host==='oauth2.googleapis.com')$body=['access_token'=>'synthetic039','expires_in'=>3600];
 elseif($host==='analyticsadmin.googleapis.com'){
  if($ga==='503'){$code=503;$body=['error'=>['status'=>'UNAVAILABLE']];}
  elseif(str_contains($path,'measurementProtocolSecrets'))$body=['measurementProtocolSecrets'=>[['secretValue'=>$ga==='wrong'?'other':'lab-secret']]];
  else $body=['name'=>'properties/123/dataStreams/456','webStreamData'=>['measurementId'=>'G-LAB039']];
 }elseif(str_contains($path,'/debug/mp/collect')) {
  if($ga==='503'){$code=503;$body=['error'=>['status'=>'UNAVAILABLE']];}else $body=['validationMessages'=>[]];
 }elseif(str_contains($path,'/mp/collect')){$code=204;$calls[]='GA4 collect';}
 elseif(str_contains($path,'googleAds:search')){
  if(str_contains($q['query']??'','FROM conversion_action')){preg_match('~customers/\d+/conversionActions/\d+~',$q['query'],$m);$body=['results'=>[['conversionAction'=>['resourceName'=>$m[0],'type'=>'UPLOAD_CLICKS','status'=>'ENABLED','valueSettings'=>['defaultValue'=>0,'defaultCurrencyCode'=>'BRL']]]]];}
  else $body=['results'=>[['customer'=>['id'=>'1234567890','conversionTrackingSetting'=>['acceptedCustomerDataTerms'=>true,'enhancedConversionsForLeadsEnabled'=>true]]]]];
 }elseif(str_contains($path,'events:ingest')){
  if(!empty($q['validateOnly'])){$calls[]='Ads verification';}
  else{$id=$q['events'][0]['transactionId'];$actions[$id][]=$ads;
   if($ads==='denied'){$code=400;$body=['error'=>['status'=>'INVALID_ARGUMENT','details'=>[['fieldViolations'=>[['field'=>'events[0].destination_references[0]','reason'=>'NOT_FOUND']]]]]];}
   elseif($ads==='terms'){$code=400;$body=['error'=>['status'=>'INVALID_ARGUMENT','details'=>[['reason'=>'DESTINATION_ACCOUNT_ENHANCED_CONVERSIONS_TERMS_NOT_SIGNED']]]];}
   elseif($ads==='network')return new WP_Error('lab_network','Tempo esgotado no laboratório');
   elseif(in_array($ads,['503','429'],true)){$code=(int)$ads;$body=['error'=>['status'=>$ads==='503'?'UNAVAILABLE':'RESOURCE_EXHAUSTED']];}
   else $body=['requestId'=>'lab-'.$id];}
 }elseif(str_contains($path,'requestStatus:retrieve')){$body=['requestStatusPerDestination'=>[['destination'=>['operatingAccount'=>['accountType'=>'GOOGLE_ADS','accountId'=>'1234567890'],'productDestinationId'=>'789'],'requestStatus'=>'SUCCESS','eventsIngestionStatus'=>['recordCount'=>'1']]]];}
 else return new WP_Error('lab_external_denied','Somente fixtures locais');
 return ['response'=>['code'=>$code],'headers'=>[],'body'=>$code===204?'':wp_json_encode($body)];
},PHP_INT_MAX,3);
function setup39(){
 O::batch_verified([O::ENABLED=>true,O::GA_ENABLED=>true,O::ADS_ENABLED=>true,O::AUTH_MODE=>'oauth',O::OAUTH_CLIENT_ID=>'fixture.apps.googleusercontent.com',C::SERVICES=>['ga'=>'write','ads'=>'write'],Policy::OPTION=>['mode'=>'identity','services'=>[]],Settings::AUTH_READY=>true],[O::OAUTH_CLIENT_SECRET=>'fixture',O::OAUTH_REFRESH_TOKEN=>'fixture',O::ADS_DEVELOPER_TOKEN=>'fixture']);
 O::set(P::OPTION,['scope'=>P::scope(),'level'=>'basic']);
 return D::configure(['expected_revision'=>D::revision(),'config'=>['enabled'=>true,'stream'=>'properties/123/dataStreams/456','customer_id'=>'1234567890','conversion_action'=>'customers/1234567890/conversionActions/789'],'mp_secret'=>'lab-secret']);
}
function verify39($target){return D::verify(['target'=>$target,'expected_revision'=>D::revision()]);}
function age39($target,$days){$c=O::get(D::CONFIG);$c['verified'][$target]['at']=time()-($days+1)*DAY_IN_SECONDS;$c['verified'][$target]['expires']=time()-$days*DAY_IN_SECONDS;$c['renewal'][$target]['next_attempt']=time()-1;O::set(D::CONFIG,$c);}
function payload39($id,$target){$at=time()-8;$rid=md5($id);$p=['record_id'=>$rid,'event_id'=>$rid,'occurred_at'=>gmdate('c',$at)];return $p+($target==='ga4'?['measurement_id'=>'G-LAB039','event_name'=>'generate_lead','client_id'=>'1.23','session_id'=>'12','timestamp_micros'=>$at*1000000]:['click_ids'=>['gclid'=>'lab-click'],'order_id'=>$rid,'ad_user_data'=>'GRANTED']);}
function testcode39(){return array_values(array_filter(F3Base_Incidentes::listar()['itens'],static fn($r)=>$r['pacote']==='google'&&$r['estado']==='aberto'));}
update_option('f3base_ga4_measurement_id','G-LAB039');
update_option('f3base_avisos_tecnicos',['email'=>'lab@example.invalid']);
if($phase!=='upgrade'){
 $r=setup39();$ok($r['success'],'Configured bound destinations',$r);
 foreach(['ga4','google_ads']as $t){$r=verify39($t);$ok(!empty($r['success']),'Initial proof '.$t,$r);}
}
$g=new D('ga4');$a=new D('google_ads');$action='customers/1234567890/conversionActions/222';
if($phase==='base'){
 age39('ga4',10);age39('google_ads',3);$ga='503';$r=verify39('ga4');
 $ok(empty($g->capabilities()['ready']),'0.38 blocks GA4 after transient failure');$ok(empty($a->capabilities()['ready']),'0.38 expires Ads');
 update_option('lab039-cipher',hash('sha256',serialize(O::stored(O::storage_name(O::OAUTH_REFRESH_TOKEN)))));
}else{
 if($phase==='upgrade')$ok(get_option('lab039-cipher')===hash('sha256',serialize(O::stored(O::storage_name(O::OAUTH_REFRESH_TOKEN)))),'Ciphertext preserved on direct upgrade');
 $ga='503';age39('ga4',400);age39('google_ads',3);$num=count($calls);$r=D::renew_due();
 $ok(isset($r['ga4'])&&!isset($r['google_ads']),'Only GA4 executor re-verifies after 72 hours',$r);
 $cap=$g->capabilities();$ok($cap['ready']&&$cap['proof_status']==='stale_transient'&&$cap['renewal']['transient_since']>0,'GA4 usable after 400-day transient period',$cap);
 $stored=O::get(D::CONFIG);$stored['renewal']['ga4']['transient_since']=time()-390*DAY_IN_SECONDS;$stored['renewal']['ga4']['next_attempt']=time()-1;O::set(D::CONFIG,$stored);
 $since=$stored['renewal']['ga4']['transient_since'];D::renew_due();
 $ok($g->capabilities()['ready']&&$g->capabilities()['renewal']['transient_since']===$since,'Repeated outage preserves the start across 390 simulated days');
 $read=Readiness::read([]);$ok(str_contains(wp_json_encode($read),'stale_transient'),'Readiness reports transient state');
 $ok(($g->send(payload39('ga','ga4'))['status']??'')==='entregue' && in_array('GA4 collect',$calls,true),'GA4 dispatched even when debug API returns 503');
 $ok(in_array('renovacao_falhou',array_column(testcode39(),'codigo'),true),'Core receives renewal notice');
 $ga='wrong';$r=verify39('ga4');$ok(empty($g->capabilities()['ready'])&&$g->send(payload39('ga','ga4'))['status']==='recusado','First conclusively missing secret blocks');
 $ga='503';verify39('ga4');$ok(empty($g->capabilities()['ready']),'Later outage cannot resurrect invalid proof');
 $ga='ok';$r=verify39('ga4');$ok($g->capabilities()['ready'] && abs($g->capabilities()['renewal']['next_attempt']-time()-43200)<6,'GA4 recovers with 12-hour schedule');
 $cap=$a->capabilities();$ok($cap['ready']&&$cap['verification_expires_at']===null&&$cap['renewal']['next_attempt']===null,'Ads evergreen');
 $ok(F3Base_Google_Conversoes::pronta(array_merge($cap,['contract'=>F3Base_Google_Conversoes::CONTRACT])),'Core 1.95 accepts enhanced leads');
 $ref=$cap['destination_ref'];$p=payload39('ad','ads');$ads='denied';$r=$a->sendBound($p,$ref);
 $ok($r['status']==='recusado'&&$r['code']==='ads_action_unavailable'&&!$a->capabilities()['ready'],'Missing conversion action rejects send and revokes proof',$r);
 $ok(in_array('autorizacao_recusada',array_column(testcode39(),'codigo'),true),'Core received Ads refusal');
 $attempts=count($actions[$p['order_id']]);$r=$a->sendBound($p,$ref);$ok($r['status']==='recusado'&&count($actions[$p['order_id']])===$attempts,'Further sends held');
 $ads='ok';verify39('google_ads');$r=$a->sendBound($p,$ref);$ok($r['code']==='data_manager_pending'&&$actions[$p['order_id']]===['denied','ok'],'Same order accepted after new proof',$r);
 foreach(['429','503','network'] as $failure){$p=payload39($failure,'ads');$ads=$failure;$r=$a->sendBound($p,$ref);$ok($r['code']==='ads_retry_same_transaction'&&$a->capabilities()['ready'],'Transient '.$failure.' keeps proof',$r);$ads='ok';$r=$a->sendBound($p,$ref);$ok($r['code']==='data_manager_pending'&&count($actions[$p['order_id']])===2,'Retry identical transaction '.$failure);}
 $stage=S::configure(['action'=>$action,'enabled'=>true,'expected_revision'=>D::revision()]);$ok(!empty($stage['success']),'Stage configured',$stage);
 $stage=S::verify(['action'=>$action,'expected_revision'=>D::revision()]);$ok(!empty($stage['success']),'Stage proof',$stage);
 $sa=S::select(['consumer_id'=>S::CONSUMER,'purpose'=>S::PURPOSE,'action'=>$action]);
 $scap=$sa->capabilities();$ok($scap['ready']&&$scap['actions'][$action]['renewal']['next_attempt']===null,'Independent stage action has no renewal');
 $sp=['contract'=>S::CONTRACT,'purpose'=>S::PURPOSE,'stage_id'=>'qualificado','action'=>$action,'record_id'=>md5('stage'),'event_id'=>'stage039','order_id'=>'stage039','occurred_at'=>gmdate('c',time()-40*DAY_IN_SECONDS),'click_ids'=>['gclid'=>'lab-stage'],'ad_user_data'=>'GRANTED','value'=>0,'currency'=>'BRL'];
 $ads='terms';$r=$sa->sendBound($sp,$scap['actions'][$action]['destination_ref']);
 $ok($r['code']==='ads_terms_refused'&&!$sa->capabilities()['ready']&&$a->capabilities()['ready'],'Stage terms refusal isolated from acquisition',$r);
 $ads='ok';S::verify(['action'=>$action,'expected_revision'=>D::revision()]);$ok($sa->sendBound($sp,$scap['actions'][$action]['destination_ref'])['code']==='data_manager_pending','40-day stage resumes same order');
 if(in_array($phase,['core-official','core-patch'],true)){
    global $wpdb;
    $leadRecord=F3Base_Leads_Repositorio::guardar(['nome'=>'Fixture','email'=>'lab039@example.invalid','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture039','contexto_teste'=>false,'notificar'=>false]);
    $ok(!empty($leadRecord['persisted']),'Core persists synthetic fixture');
    $rid=$leadRecord['record_id'];$lead=F3Base_Leads_Repositorio::obter($rid);$d=$lead['dados'];
    $d['conversoes_transporte']['destinos']=['google_ads'=>'servidor'];$d['conversoes_transporte']['referencias']=['google_ads'=>$ref];$d['audiencia_excluida']=false;
    $d['consentimento_snapshot']=['medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:'.F3Base_Modulo_Consentimento::politica_versao()];
    $d['atribuicao']=['gclid'=>'lab-click','ultimo_toque_em'=>strtotime($lead['criado_em'].' UTC')-15];
    $wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($d),'classe_trafego'=>'nao_marcado'],['record_id'=>$rid]);
    $lead=F3Base_Leads_Repositorio::obter($rid);
    F3Base_Conversoes_Servidor::capturar($lead,'google_ads');
    $where=['record_id'=>$rid,'destino'=>'google_ads'];
    $tick=static function()use($wpdb,$where,$rid){$wpdb->update(F3Base_Conversoes_Servidor::tabela(),['proxima'=>time()-1],$where);F3Base_Execucoes::encerrar();F3Base_Conversoes_Servidor::processar();return $wpdb->get_row($wpdb->prepare("SELECT estado,codigo,tentativas FROM %i WHERE record_id=%s AND destino=%s",F3Base_Conversoes_Servidor::tabela(),$rid,'google_ads'),ARRAY_A);};
    $ads='denied';$row=$tick();
    $ok($row['codigo']==='ads_action_unavailable' && !$a->capabilities()['ready'],'Core queue retains conclusive rejection',$row);
    $row=$tick();$ok($row['estado']==='bloqueado'&&count($actions[$rid])===1,'Core holds pending proof without another send',$row);
    $ads='ok';verify39('google_ads');$row=$tick();$ok($row['estado']==='incerto'&&count($actions[$rid])===2,'Core reoffers same record after new proof',$row);
    $receiptId=hash('sha256',C::id().'|'.$rid);$stored=Fator3\McpGoogle\Records::get('conversion',$receiptId);$stored['next_attempt']=time()-1;Fator3\McpGoogle\Records::put('conversion',$receiptId,$stored);
    $row=$tick();$ok($row['estado']==='entregue' && count($actions[$rid])===2,'Core receipt confirmed without a third dispatch',$row);
    if ($phase==='core-patch') {
       $ok(method_exists('F3Base_Conversoes_Servidor','retomar_ads'),'Experimental Core active');
       $again=F3Base_Leads_Repositorio::guardar(['nome'=>'Fixture 2','email'=>'lab2@example.invalid','metodo'=>'formulario','captura'=>'aceito','formulario'=>'fixture','contexto_teste'=>false,'notificar'=>false]);
       $other=$again['record_id'];$age=time()-45*DAY_IN_SECONDS;$d['atribuicao']['ultimo_toque_em']=$age-30;
       $wpdb->update(F3Base_Leads_Repositorio::tabela(),['dados'=>wp_json_encode($d),'criado_em'=>gmdate('Y-m-d H:i:s',$age),'classe_trafego'=>'nao_marcado'],['record_id'=>$other]);
       $otherLead=F3Base_Leads_Repositorio::obter($other);F3Base_Conversoes_Servidor::capturar($otherLead,'google_ads');
       $qtab=F3Base_Conversoes_Servidor::tabela();$w=['record_id'=>$other,'destino'=>'google_ads'];
       $wpdb->update($qtab,['tentativas'=>9,'proxima'=>time()-1],$w);$ads='503';F3Base_Execucoes::encerrar();F3Base_Conversoes_Servidor::processar();
       $row=$wpdb->get_row($wpdb->prepare('SELECT estado,tentativas,codigo FROM %i WHERE record_id=%s AND destino=%s',$qtab,$other,'google_ads'),ARRAY_A);
       $ok($row['estado']==='pendente' && (int)$row['tentativas']===9 && $row['codigo']==='ads_retry_same_transaction','Core retries ambiguous 503 without exhausting queue',$row);
       $ads='ok';$wpdb->update($qtab,['proxima'=>time()-1],$w);F3Base_Execucoes::encerrar();F3Base_Conversoes_Servidor::processar();
       $ok(($actions[$other]??[])===['503','ok'],'Same 45-day order reoffered after 503');
       $qc=F3Base_Qualidade::padrao();$qc['ativo']=true;$qc['etapas']=[['id'=>'qualificado','nome'=>'Qualificado']];
       update_option(F3Base_Qualidade::OPCAO,$qc);$qc=F3Base_Qualidade_Destinos::padroes();$qc['google_ads']=['ativo'=>true,'acoes'=>['qualificado'=>$action]];update_option(F3Base_Qualidade_Destinos::OPTION,$qc);
       $ok(F3Base_Qualidade_Destinos::registrar($otherLead,'qualificado',$age+60),'45-day stage enqueued');
       $key=hash('sha256',get_current_blog_id().'|'.$other.'|google_ads|qualificado');$tbl=F3Base_Qualidade_Destinos::tabela();
       $step=static function()use($wpdb,$key,$tbl){$wpdb->update($tbl,['atualizado_em'=>time()-7200],['chave'=>$key]);F3Base_Execucoes::encerrar();F3Base_Qualidade_Destinos::processar();return $wpdb->get_row($wpdb->prepare('SELECT estado,codigo FROM %i WHERE chave=%s',$tbl,$key),ARRAY_A);};
       $ads='terms';$row=$step();$ok($row['codigo']==='ads_terms_refused','Stage queue retains the conclusively refused event',$row);
       $step();$ads='ok';S::verify(['action'=>$action,'expected_revision'=>D::revision()]);$row=$step();$ok(($actions['f3q-'.$key]??[])===['terms','ok'] && $row['estado']==='incerto','45-day old stage dispatched after reproof',$row);
       if (getenv('F3_EXTRA196')) require getenv('F3_EXTRA196');
    }
 }
 $created=C::create('second039','Segunda');$ok(!empty($created['success']),'Second connection created');
 C::run('second039',static function()use($ok){$r=setup39();$ok($r['success']&&!((new D('google_ads'))->capabilities()['ready']),'No inherited proof in second connection');verify39('google_ads');$ok((new D('google_ads'))->capabilities()['ready'],'Second connection independently verified');});
 $c=O::get(D::CONFIG);$c['stream']='properties/123/dataStreams/567';O::set(D::CONFIG,$c);$ok(!$g->capabilities()['ready'],'Revision change invalidates GA4 immediately');
}
file_put_contents(getenv('F3_RESULT39'),wp_json_encode(['version'=>F3_MCP_GOOGLE_VERSION,'wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'phase'=>$phase,'checks'=>$checks,'count'=>count($checks),'google'=>'intercepted','mail'=>'intercepted'],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));echo count($checks)." checks passed\n";
