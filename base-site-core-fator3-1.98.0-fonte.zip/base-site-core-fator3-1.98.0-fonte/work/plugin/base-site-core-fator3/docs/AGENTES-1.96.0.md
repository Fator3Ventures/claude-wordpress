# Operação do Core 1.96.0

Consulte DOCUMENTACAO.md e RELEASE-1.96.0.md. Verifique a atualização por f3base/como-usar. Para o pedido 431, confira o estado, a data de vencimento e o último envio de cada prova por f3base/incidentes-tecnicos-ler. No Google, compare com o instante da última verificação e a próxima renovação. Nas conversões Ads, use a fila existente e o identificador já vinculado ao registro. O coletor e a consulta do recibo preservam as regras de consentimento e a referência de destino. A verificação em produção usa observações naturais.
