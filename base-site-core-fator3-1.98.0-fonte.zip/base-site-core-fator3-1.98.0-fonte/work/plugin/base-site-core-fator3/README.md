# Fator3 Site Core 1.98.0

Consulte docs/DOCUMENTACAO.md e docs/RELEASE-1.98.0.md. O fluxo de verificação das ofertas está em docs/OFERTAS.md.
