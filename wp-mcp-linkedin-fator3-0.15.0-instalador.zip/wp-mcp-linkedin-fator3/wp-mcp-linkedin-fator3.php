<?php
/**
 * Plugin Name: Fator3 MCP LinkedIn
 * Plugin URI: https://github.com/Fator3Ventures/claude-wordpress
 * Description: LinkedIn Pages, Ads, Lead Sync e Conversions API: gestão de anúncios e publicações, relatórios, renovação de acesso, coletas agendadas, exportação em CSV e JSON e notificações verificadas, pela Abilities API e pelo Fator3 MCP. A captação de leads para os contatos do site é do Fator3 Site Core. Configuração em Ferramentas → Fator3 MCP LinkedIn.
 * Version: 0.15.0
 * Requires at least: 6.4
 * Requires PHP: 8.1.2
 * Author: Fator3
 * Author URI: https://www.fator3.com.br
 * License: GPL-2.0-or-later
 * Text Domain: wp-mcp-linkedin-fator3
 * Update URI: https://fator3.com.br/plugins/wp-mcp-linkedin-fator3
 */
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
if(class_exists(__NAMESPACE__.'\\Config',false))return;
require_once __DIR__.'/includes/Config.php';
require_once __DIR__.'/includes/Support.php';
require_once __DIR__.'/includes/Connections.php';
require_once __DIR__.'/includes/Http.php';
require_once __DIR__.'/includes/Queue.php';
require_once __DIR__.'/includes/Worker.php';
require_once __DIR__.'/includes/Adapter.php';
require_once __DIR__.'/includes/Schemas.php';
require_once __DIR__.'/includes/Query.php';
require_once __DIR__.'/includes/Export.php';
require_once __DIR__.'/includes/Documentation.php';
require_once __DIR__.'/includes/History.php';
require_once __DIR__.'/includes/HistoryExport.php';
require_once __DIR__.'/includes/Retention.php';
require_once __DIR__.'/includes/LeadDiscovery.php';
require_once __DIR__.'/includes/LeadReader.php';
require_once __DIR__.'/includes/Credentials.php';
require_once __DIR__.'/includes/ConnectionChanges.php';
require_once __DIR__.'/includes/Management.php';
require_once __DIR__.'/includes/ManagementSchemas.php';
require_once __DIR__.'/includes/Labels.php';
require_once __DIR__.'/includes/AdminManagement.php';
require_once __DIR__.'/includes/CentralAudit.php';
require_once __DIR__.'/includes/Conversions.php';
require_once __DIR__.'/includes/StageConversions.php';
require_once __DIR__.'/includes/ConversionSchemas.php';
require_once __DIR__.'/includes/FieldHelp.php';
require_once __DIR__.'/includes/ServiceAudit.php';
require_once __DIR__.'/includes/ServiceAuditPublic.php';
require_once __DIR__.'/includes/Api.php';
require_once __DIR__.'/includes/Admin.php';
register_activation_hook(__FILE__,static function($network=false){if($network)wp_die('Ative a integração individualmente em cada site.');if(PHP_INT_SIZE<8)wp_die('PHP de 64 bits necessário.');if(!Crypto::available())wp_die('Criptografia autenticada necessária.');Store::install();History::install();if(!wp_next_scheduled(Config::KEY.'_maintenance'))wp_schedule_event(time()+3600,'hourly',Config::KEY.'_maintenance');Worker::bootstrap();Worker::ensure();LeadDiscovery::ensure();});
register_deactivation_hook(__FILE__,static function(){wp_clear_scheduled_hook(Config::KEY.'_worker');wp_clear_scheduled_hook(Config::KEY.'_maintenance');wp_clear_scheduled_hook(Config::KEY.'_lead_discovery');});
add_action('plugins_loaded',static function(){if((int)Util::boot(Config::KEY.'_schema',0)!==2){try{Store::install();}catch(\Throwable $e){add_action('admin_notices',static function(){if(current_user_can('manage_options'))echo '<div class="notice notice-error"><p>Fator3 MCP LinkedIn: armazenamento indisponível. Reative o plugin após verificar o banco.</p></div>';});}}},10);
add_action('plugins_loaded',static function(){Result::run(static function(){if((int)Util::boot(Config::KEY.'_history_schema',0)!==1)History::install();Retention::upgrade();Management::upgrade();Worker::bootstrap();return [];});},11);
add_action('f3_mcp_register_providers',static function($version=1){if($version===1&&class_exists('\\Fator3\\McpFiles\\ExtensionContract'))\Fator3\McpFiles\ExtensionContract::register(Config::SLUG,Config::VERSION,[Config::PREFIX.'/']);});
add_action('wp_abilities_api_categories_init',static function(){if(function_exists('wp_register_ability_category'))wp_register_ability_category(Config::PREFIX,['label'=>Config::NAME,'description'=>'Integração social independente Fator3.']);});
add_action('wp_abilities_api_init',[Api::class,'abilities'],20);
add_action('rest_api_init',[Api::class,'routes']);
add_action('admin_menu',[Admin::class,'menu']);
add_action('admin_enqueue_scripts',[Admin::class,'assets']);
add_action(Config::KEY.'_maintenance',static function(){Worker::maintenance();});
add_action('init',static function(){if(!wp_next_scheduled(Config::KEY.'_maintenance'))Result::run(static fn()=>Store::lock('maintenance-event',static function(){if(!wp_next_scheduled(Config::KEY.'_maintenance'))wp_schedule_event(time()+300,'hourly',Config::KEY.'_maintenance');update_option(Config::KEY.'_maintenance_rearmed',['at'=>time(),'next'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null],false);return [];}));},20);
add_action(Config::KEY.'_worker',static function(){try{Jobs::tick();}catch(\Throwable $e){update_option(Config::KEY.'_last_worker',['at'=>time(),'state'=>'failed'],false);}});
add_action('init',static function(){do_action('f3_linkedin_register_consumers',PublicApi::class);},1);

add_action(Config::KEY.'_lead_discovery',[LeadDiscovery::class,'tick']);
CentralAudit::boot();
ServiceAudit::boot();
Conversions::boot();
add_action('admin_post_f3_linkedin_oauth_callback',[Credentials::class,'callback']);
if(defined('WP_CLI')&&WP_CLI){
 \WP_CLI::add_command('f3-linkedin run',static function(){Jobs::tick();\WP_CLI::line(Util::json(get_option(Config::KEY.'_last_worker',[])));});
 \WP_CLI::add_command('f3-linkedin selftest',static function(){$r=Result::run(static fn()=>SelfTest::run());\WP_CLI::line(Util::json($r));if(!$r['success'])\WP_CLI::halt(1);});
}
