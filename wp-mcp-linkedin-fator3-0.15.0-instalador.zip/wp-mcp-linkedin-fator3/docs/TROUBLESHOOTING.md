# Diagnóstico — 0.11.0

`status` informa versão, banco, criptografia e execução do cron. `selftest` realiza verificações locais; não valida credenciais externas. `validate-connection` lê identidade do ativo, sem prometer todas as métricas. Consulte auditoria paginada para códigos sanitizados.

- not_authorized: confirme manage_options ou a concessão vigente do consumidor SDK.
- revision_conflict: releia a configuração; uma revisão não é intercambiável com outra.
- token_expired/token_rejected: renove e valide a credencial; resultados históricos locais não dependem de token válido.
- rate_limited: aguarde retry_after; o agendador aplica adiamento.
- upstream_validation: confirme versão, campo, produto e aprovação do aplicativo.
- operation_uncertain: consulte e reconcilie o diário; não gere outra chave para contornar o bloqueio.
- history_changed: a visão paginada mudou; reinicie consulta/exportação com nova chave.
- response_limit: reduza campos ou limit. Não considere uma resposta truncada completa.
- cipher_unreadable: confira salts e restauração; não tente regravar sobre dado ilegível.
- storage_unavailable/persistence_unconfirmed: verifique banco, espaço e bloqueios; preserve o backup.

Cron depende de visitas se não houver agendador do servidor. Execução alternativa: `wp f3-meta run` / `wp f3-linkedin run`. Cada passo tem orçamento; grandes coletas exigem múltiplas execuções. O usuário que criou uma agenda precisa continuar autorizado.

## Novos códigos e ações

scope_missing: reautorize o app com a permissão requerida; não altere somente rótulos locais. application_required: configure ID e segredo para introspecção. targeting_ambiguous: escolha um resultado da busca e mantenha search_offset. preview_required/preview_stale: releia e gere prévia. revision_conflict: confronte a versão atual antes de nova decisão. operation_uncertain/verification_pending: consulte operation_id e reconcilie sem reenviar. refresh_unavailable/refresh_expired: aplicativo não emitiu refresh ou prazo venceu; reautorize. oauth_rejected: conferir app, produto e credenciais. O token atual é preservado em falha de refresh.

## Serviço CAPI
service_principal_unsupported é esperado sem o Fator3 MCP ou com MCP anterior à 0.28.0: falta consumidor central, não credencial LinkedIn. service_record_unconfirmed exige conferir persistência/digest no canal compatível, sem repetir POST. service_authority_unavailable ou service_identity_mismatch exige verificar concessão/revisão, ativo e prova local; não vincular automaticamente referência antiga a grant novo. service_operation_unbound identifica diário legado. Consulte SERVICE-AUDIT.md.

## Códigos novos da 0.8.0

`worker_missing`, `schedule_overdue`, `schedule_authorization_failed`, `queue_migration_pending`, `queue_record_unreadable` e `maintenance_missing` aparecem em `linkedin/status.issues`; a tabela de ações está em WORKER.md. `regra_divergente` em `diagnose-conversions` indica que a regra de servidor do Site Core difere da regra concedida.

## Histórico 0.14.0 — pedidos 16/17

token_rejected no retorno OAuth: o diagnóstico distingue inactive, client_id_mismatch e expired. HTTP200/active=false pode indicar vínculo token/aplicativo incorreto. Não há prova da causa histórica sem novo retorno. Nunca exponha corpo bruto. identity_change_required com token válido é incidente de confirmação; use Renovar agora e siga CREDENTIALS.md, sem repetir tentativas automáticas.

Criação 4xx sem recibo: consulte `state:rejected`, HTTP e mensagem sanitizada; nova chave pode seguir após corrigir a causa. `app_account_not_listed`: Developers → aplicativo → Products → Advertising API → View Ad Accounts → Add Ad Account. `operation_uncertain` bloqueia apenas a mesma intenção, não todo o site. Quando não há recibo conciliável, `close-write-operation` exige decisão explícita, revisão e risco de duplicação aceito; veja MANAGEMENT.md. Não apague diário nem confunda `closed/unknown` com ausência comprovada.

Lead Sync: `leadNotifications` usa `q=criteria` e `owner.value`; `leadFormResponses` continua `q=owner`. Falha anterior ao POST informa `remote_effect:none` e fase/motivo; recibo incerto já existente preserva `unknown`. Para novos formulários, confira LEAD-DISCOVERY.md, ambas as seleções, contrato do consumidor, callback e `lead-discovery-status`. Core 1.67.0 ainda não incorpora automaticamente formulários: requer implementação do consumidor; não é solucionado alterando options privadas.
