# Fator3 MCP LinkedIn 0.15.0

Pedidos 18–21. Base direta 0.14.0, instalação nova preservada. Mesma identidade, tabelas, credenciais e contratos comerciais; Lead Reader 1.2 aditivo, 1.0/1.1 preservados. 97 operações com schemas fechados.

- Criações recusadas por 400/401/403/404/422, em envelope sem objeto/recibo, encerram rejected/none com diagnóstico. 5xx e falhas ambíguas continuam incertas. Preview de grupo exige schedule.start. Código app_account_not_listed orienta a liberação da conta no aplicativo.
- close-write-operation simula encerramento de intenção incerta e exige revisão, motivo e risco reconhecido para confirmar. Preserva diário e efeito desconhecido. A trava é somente da mesma intenção. Migração conservadora libera rejeições legadas comprováveis; os incidentes 422/403 recebidos têm identificação delimitada, sem adivinhar outros upstream_error.
- leadNotifications corrigido para q=criteria/owner.value, incluindo o finder anterior à criação. Falha antes do POST informa remote_effect:none; repetição de recibo enviado conserva seu efeito.
- Getter/finder aplicam trim apenas às bordas de respostas textuais; espaços internos e respostas de outros tipos são preservados. Não há reprocessamento de contatos históricos.
- all_forms_accounts, seleção por conta com simulação tanto na conexão quanto na concessão. Descoberta periódica, callback/assinatura idempotente na mesma passagem, catálogo e eventos duráveis por consumidor, Registro local e recuperação pelo SDK. Leia LEAD-DISCOVERY.md.

O Core 1.67.0 recebido ainda usa seleção explícita própria. A parte do produtor está disponível; ingestão automática de formulário novo pelo Core exige sua adoção do contrato/evento e aceite coordenado. Nenhum documento/código Core ou MCP foi alterado. Contatos, deduplicação, callback e efeitos comerciais permanecem no consumidor.

Não confundir fixtures locais com homologação no LinkedIn. Aceites reais de ctooffice, quatro assinaturas e correção temporária de respostas vieram no pedido; a implantação desta versão e o próximo lead real devem ser conferidos pela frota. Diagnósticos de OAuth/refresh, gestão/Conversions API e demais aceites reais anteriores continuam com suas pendências. Relatório externo contém testes, identidade e situação efetivamente observados nesta rodada.

Leia MIGRATION.md para migração, backup e limitações de rollback. Ausência de MCP ou Core não impede uso e ajuda locais. Instalar somente o ZIP LinkedIn; não atualizar acompanhantes para fabricar aprovação.
