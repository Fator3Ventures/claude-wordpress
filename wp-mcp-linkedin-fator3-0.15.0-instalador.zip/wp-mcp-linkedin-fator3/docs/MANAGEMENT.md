# Gestão de anúncios e publicações — 0.11.0

## Escopo e condições

Contrato `linkedin-management/1.0.0`. Tela em Ferramentas → Fator3 MCP LinkedIn → Anúncios e publicações; REST e abilities usam os mesmos schemas e autorização. Exige administrador e conexão ativa com ativo selecionado. O aplicativo precisa de ID e chave secreta para introspecção; escopos digitados ou deduzidos não comprovam autorização. Antes de cada escrita (inclusive prévia) consulta-se a introspecção oficial. Anúncios exigem `rw_ads`; publicações, comentários e envio de mídia exigem `w_organization_social` e `r_organization_social`. Leitura Ads exige `r_ads` ou `rw_ads`. Direitos do membro na conta/Página e aprovação dos produtos também são exigidos pelo LinkedIn.

| Recurso | Operações `linkedin/` | Comportamento |
| --- | --- | --- |
| Grupo | get/create/update/activate/delete-campaign-group | Nome, orçamento total, datas e estado; cria DRAFT |
| Campanha | get/create/update/activate/delete-campaign | Tipo, custo, objetivo, formato, otimização, estratégia, valores, datas, idioma, país, entrega fora da rede, expansão e segmentação; cria DRAFT |
| Anúncio | get/create/update/activate/delete-creative | Publicação de Página selecionada, campanha da conta, formulário selecionado e chamada; edição de estado; cria DRAFT |
| Conta/Página | get-ad-account, get-organization | Retorna objeto e revisão SHA-256 |
| Publicação | get/create/update/delete-post | Cria texto, imagem, vídeo ou artigo; atualização muda texto conforme Posts API |
| Comentário | create-comment | Página selecionada comenta uma publicação sua |
| Mídia | initialize-image-upload, initialize-video-upload | Inicia upload e devolve recibo; não transfere bytes nem finaliza vídeo |
| Segmentação | search-targeting, search-locations | Busca nomes; resultado selecionado vira URN sem montagem pelo operador |
| Diário | get-write-operation, reconcile-write-operation | Consulta antes/depois e reconcilia por GET, sem reenviar |

Listagens permanecem em `query`, canal ads com campaign_groups/campaigns/creatives e canal pages com posts. Paginação continua por `next_cursor`. Não se pode inferir ausência pela primeira página. O painel pagina objetos e percorre as listas de grupos/campanhas/publicações vinculadas.

## Duas fases e revisão

1. Leia o recurso `get-*`. Criação usa revisão de `get-ad-account` ou `get-organization`; comentário usa `get-post`; iniciar mídia usa `get-organization`. `revision` é SHA-256 da representação remota canônica, não ETag.
2. Escolha uma `request_key` estável, única por intenção (até 64 caracteres). Envie campos e `expected_revision`, com `dry_run:true` (padrão). A prévia retorna `before`, `proposed`, `confirm_token` e validade de 10 minutos. Não há mutação no LinkedIn; há introspecção/leitura e armazenamento local cifrado da confirmação.
3. Após conferir, repita exatamente o conteúdo e a mesma `request_key`, com `dry_run:false`, `confirm:true` e `confirm_token`. Mudanças de conteúdo, revisão, usuário ou geração da credencial invalidam a prévia. A seleção e autorização são verificadas novamente antes do envio.
4. A resposta de sucesso com `state=confirmed` exige releitura e comparação. Guarde `data.operation_id`. No MCP, `operation_id` exterior pode pertencer ao transporte; o diário usa o identificador de domínio em `data`.

O MCP 0.25.0 acrescenta `idempotency_key` opcional do transporte. Para estas novas operações omita essa chave e use `request_key`, ou use chaves de transporte diferentes por fase. Usar a mesma chave do transporte para prévia e aplicação produz conflito, pois o conteúdo muda. Operações anteriores mantêm sua própria `idempotency_key` sem alteração.

Exemplo de criação de grupo (valores sintéticos; não executar em produção sem ordem):

```json
{"connection_id":"exemplo","account_id":"222","expected_revision":"<revision de get-ad-account>","request_key":"grupo-exemplo-001","dry_run":true,"fields":{"name":"Grupo de teste","schedule":{"start":1793660400000},"total_budget":{"amount":"100.00","currency":"BRL"}}}
```

Substitua o marcador por hash real de 64 hexadecimais. O schema rejeita o marcador literal. Para aplicar, acrescente o `confirm_token` retornado, `confirm:true` e mude `dry_run` para false. Criações Ads nunca aceitam ACTIVE: use a operação activate separada, com nova leitura, chave e prévia. Ativar pode iniciar gasto. Edição de estado aceita PAUSED/ARCHIVED; ativação é sempre separada.

Exclusão de grupo/campanha/anúncio DRAFT envia DELETE. Nos demais estados, envia alteração para PENDING_DELETION; o diário confirma essa marca, sem afirmar exclusão física. Publicação envia DELETE e espera 404 na releitura. Exclusões, ativações, publicação, edição de publicação e comentários têm anotação destrutiva.

## Segmentação e mídias

Facetas: local, setor, empresa, cargo, funcao, senioridade, competencia, interesse e segmento. Cada item recebe `name`, `facet`, `exclude` e, quando houver ambiguidade, `selected_urn` e `search_offset` devolvidos pela busca. A aplicação refaz a busca e confere o resultado, inclusive resultados de páginas posteriores. Um nome sem seleção só é aceito se o resultado for único e não houver próxima página. Sempre inclua ao menos um local. Inclusões da mesma faceta usam OR; facetas diferentes usam AND; exclusões são OR. Na alteração, `targeting` substitui a segmentação inteira. O painel mostra inclusões/exclusões na prévia.

IDs e moeda são strings; valores monetários são decimais em `amount`, não centavos; moeda deve corresponder à conta. Datas da campanha são milissegundos Unix; validade de token é segundos Unix. `schedule.end` deve ser posterior a start. Combinações de objetivo, custo e formato continuam sujeitas à validação do fornecedor.

Imagem/vídeo precisam estar AVAILABLE e pertencer à Página. Inicialização devolve instruções do fornecedor, acessíveis somente ao administrador no painel/REST. Transfira os bytes e finalize o vídeo por cliente autorizado; esta versão não implementa envio/finalização. URLs assinadas e uploadToken são segredos temporários: não cole em relatório/log. O filtro de saída do MCP 0.25.0 pode redigir o uploadToken; use o painel/REST autorizado para essa etapa, sem enfraquecer a proteção do transporte. A edição de publicação troca apenas commentary; não substitui mídia, artigo nem autoria. Para outro conteúdo, prepare uma nova publicação.

## Diário, falhas e concorrência

O registro cifrado conserva principal, contexto selecionado, pedido, antes, recibo, depois e revisões. Estados: prepared → dispatching → awaiting_verification → confirmed. Falha durante envio vira uncertain. Resposta recebida mas sem releitura permanece awaiting_verification. `get-write-operation` pode ser usado mesmo com token expirado, desde que o usuário/ativo ainda estejam autorizados.

Repetir a mesma chave retorna o diário; conteúdo diferente dá idempotency_conflict. Uma intenção incerta bloqueia somente a mesma intenção: operação, conta, Página, publicação, alvo e corpo iguais, inclusive com outra chave ou conexão neste site. Outras intenções continuam disponíveis. Use reconcile-write-operation com expected_operation_revision; reconciliação só lê. Criação sem ID remoto não é declarada concluída. Uma lista vazia não prova ausência de efeito. O administrador pode encerrar explicitamente pelo procedimento abaixo, assumindo o risco e preservando o diário. Não apague registros para repetir escrita. O diário de mutações e o índice de intenções são conservados sem expiração automática; preveja espaço e backup cifrado.

Travas de banco serializam conexão e alvo dentro do WordPress. O fornecedor não oferece transação condicional nesta integração: uma alteração externa entre a releitura e o envio ainda é possível. `expected_revision` detecta divergências observadas, não elimina essa janela externa. Gestão dispõe de até 30 chamadas REST e 25 segundos; orçamento insuficiente pode exigir reconciliação se o envio já ocorreu.

O evento próprio `f3_linkedin_mutation_recorded`, contrato `linkedin-mutation/1.0.0`, expõe provider, operation_id, operation, state, hashes antes/depois e reader `linkedin/get-write-operation`. Não inclui snapshots, textos nem URLs de upload. Não depende das classes privadas do MCP. O MCP 0.27.0 oferece mutation-audit/1.0.0. A versão 0.6.0 registra explicitamente o descritor; central_audit é registered somente quando o MCP admite o leitor. Principal, administrador e ativo selecionado continuam obrigatórios. Envios SDK usam o evento separado de serviço descrito em SERVICE-AUDIT.md; o MCP 0.27.0 ainda não o consome. O contrato humano e seus gates permanecem inalterados.

## Rejeição e encerramento (pedido 18)

`create-campaign-group` exige `fields.schedule.start` (epoch em milissegundos) na prévia. Criação com resposta 400/401/403/404/422 em envelope de erro sem id/objeto/recibo termina `rejected`, `remote_effect:none` e `requires_reconciliation:false`. O diário conserva `last_error` com HTTP, código e mensagem sanitizada. Outra chave para a intenção pode seguir; repetir a mesma chave devolve o recibo anterior. 5xx, timeout, resposta perdida ou resposta contendo objeto/recibo permanecem incertos. Atualizações/exclusões não recebem automaticamente a regra de rejeição de criação.

`app_account_not_listed` indica o 403 específico de conta não liberada: LinkedIn Developers → aplicativo → Products → Advertising API → View Ad Accounts → Add Ad Account. Corrija a conta no aplicativo e gere nova prévia/chave.

Para resultado incerto, leia `get-write-operation`, pesquise o objeto no fornecedor e tente `reconcile-write-operation` quando houver recibo. Se decidir liberar a intenção, use `close-write-operation` com `operation_id`, `expected_operation_revision`, `reason:provider_rejected|absent_after_search`, `note` e `accept_duplicate_risk:true`. O padrão é `dry_run:true`; depois de revisar o aviso, envie `dry_run:false` com a revisão lida. A operação exige administrador/proprietário atual e lock da intenção/conexão, funciona mesmo sem token válido, não chama o fornecedor e não apaga registros. Estado `closed` libera outra chave, mas conserva o efeito remoto anterior (inclusive `unknown`); é uma decisão do administrador, não prova de ausência. A revisão antiga é recusada.

A atualização migra apenas criações sem id/after com diagnóstico persistido de rejeição sem recibo, ou os dois incidentes do pedido 18. Estes são identificados por prefixo do recibo, operação, conexão e conta; o 422 também confere nome/ausência de agenda, e o 403 confere presença de início. Códigos genéricos do diário antigo não provam ausência de objeto na resposta e não são liberados por inferência. O HTTP não era guardado na 0.14.0: `migration` identifica inferência/evidência recebida, sem inventar resposta remota. `upstream_error` genérico, timeouts e recibos presentes ficam preservados para análise. Migração em lotes de 50, retomada no bootstrap/manutenção, com marca autoload ao concluir.
