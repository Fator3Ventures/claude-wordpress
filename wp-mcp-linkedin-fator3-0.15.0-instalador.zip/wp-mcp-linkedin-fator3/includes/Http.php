<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Http {
    private static int $calls=0;
    private static float $until=0;
    public static function budget(int $calls=15,int $seconds=25): void {self::$calls=$calls;self::$until=microtime(true)+$seconds;}
    public static function remaining(int $calls=1): bool {return self::$calls>=$calls&&microtime(true)<self::$until-3;}
    public static function request(array $c,string $path,array $query=[],string $method='GET',?array $body=null,?callable $beforeDispatch=null): array {
        Connections::usable($c);Connections::revalidate($c);
        if(!Adapter::allowed($path,$method))throw new Fault('endpoint_forbidden','Endpoint não permitido.');
        if(self::$until===0)self::budget();
        if(self::$calls--<=0||microtime(true)>self::$until-2)throw new Fault('budget_exhausted','Orçamento da execução atingido.');
        $quota=Store::get('quota',$c['id']);if(($quota['value']['until']??0)>time())throw new Fault('rate_limited','A conexão aguarda a janela de quota.',['retry_after'=>$quota['value']['until']-time()]);
        $url=Adapter::base($c).$path;if($query)$url.='?'.Adapter::encode($query);
        $headers=['Authorization'=>'Bearer '.$c['token'],'Accept'=>'application/json'];
        if(Config::KEY==='f3_linkedin')$headers+=['LinkedIn-Version'=>$c['api_version'],'X-Restli-Protocol-Version'=>'2.0.0'];
        if(Config::KEY==='f3_linkedin'&&isset($query['q']))$headers['X-RestLi-Method']='FINDER';
        if($body!==null)$headers['Content-Type']='application/json';
        if(Config::KEY==='f3_linkedin'){if($method==='DELETE')$headers['X-RestLi-Method']='DELETE';elseif($method==='POST')$headers['X-RestLi-Method']=isset($query['action'])?'ACTION':(isset($body['patch'])?'PARTIAL_UPDATE':'CREATE');}
        $args=['method'=>$method,'headers'=>$headers,'timeout'=>min(8,max(1,(int)(self::$until-microtime(true)))),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1800000];
        if($body!==null)$args['body']=Util::json($body);
        // Guard runs after all local checks and immediately before the remote side effect.
        if(Config::KEY==='f3_linkedin'&&$path==='conversionEvents'&&isset($body['elements']))$args['headers']['X-RestLi-Method']='BATCH_CREATE';
        if($beforeDispatch)$beforeDispatch();
        $r=wp_remote_request($url,$args);unset($args,$headers);
        if(is_wp_error($r))throw new Fault($method==='GET'?'upstream_error':'operation_uncertain','Não houve confirmação do fornecedor.');
        $http=wp_remote_retrieve_response_code($r);$raw=wp_remote_retrieve_body($r);
        if(strlen($raw)>=1800000)throw new Fault('response_limit','Resposta excedeu o orçamento de bytes.');
        $data=$raw===''?[]:json_decode($raw,true,96,JSON_BIGINT_AS_STRING);
        $graphCode=is_array($data)?(int)($data['error']['code']??0):0;
        if($http===429||(Config::KEY==='f3_meta'&&in_array($graphCode,[4,17,32,613],true))){$ra=(string)wp_remote_retrieve_header($r,'retry-after');$retry=ctype_digit($ra)?(int)$ra:max(60,(int)strtotime($ra)-time());$retry=max(60,min(86400,$retry));
            Store::lock('quota:'.$c['id'],static function()use($c,$retry){$q=Store::get('quota',$c['id']);Store::put('quota',$c['id'],['until'=>time()+$retry],$q['revision']??0);});
            throw new Fault('rate_limited','Limite remoto atingido.',['retry_after'=>$retry,'http_status'=>$http]+(Config::KEY==='f3_linkedin'?self::providerDetails($data,$c,[$query,$body]):[]));}
        if($http<200||$http>=300){$code=$http===401?'token_rejected':($http===403?'asset_access_denied':($http===404?'resource_not_found':(in_array($http,[400,422],true)?'upstream_validation':'upstream_error')));
            if(Config::KEY==='f3_meta'&&in_array($graphCode,[190,102],true))$code='token_rejected';
            if(Config::KEY==='f3_meta'&&in_array($graphCode,[10,200],true))$code='asset_access_denied';
            if($method!=='GET'&&$http>=500)$code='operation_uncertain';
            $providerCode=is_array($data)?($data['error']['code']??$data['serviceErrorCode']??null):null;
            $details=['http_status'=>$http,'provider_code'=>is_numeric($providerCode)?(int)$providerCode:null]+(Config::KEY==='f3_linkedin'?self::providerDetails($data,$c,[$query,$body]):[]);
            if(Config::KEY==='f3_linkedin'){
                // Empty response or a parseable error envelope without an object/receipt. Ambiguity stays uncertain.
                $details['creation_rejected']=in_array($http,[400,401,403,404,422],true)&&is_array($data)&&($data===[]||is_string($data['message']??null)||is_string($data['error_description']??null))&&wp_remote_retrieve_header($r,'x-restli-id')===''&&!array_diff(array_keys($data),['message','status','serviceErrorCode','code','error','error_description']);
                if($http===403&&is_string($data['message']??null)&&stripos($data['message'],'application is not configured to access the related advertiser account')!==false){$code='app_account_not_listed';$details['action']='LinkedIn Developers → aplicativo → Products → Advertising API → View Ad Accounts → Add Ad Account';}
            }
            throw new Fault($code,$http===401&&Config::KEY==='f3_linkedin'?'O LinkedIn recusou o Access Token. Confira Token de acesso (Access Token), validade e aplicativo de origem.':'O fornecedor recusou a operação.',$details);}
        if(!is_array($data))throw new Fault($method==='GET'?'upstream_invalid':'operation_uncertain','Resposta inválida do fornecedor.');
        if($method==='GET')Connections::revalidate($c);
        // A successful write receipt must reach its durable journal even if access changed in flight.
        return ['body'=>$data,'status'=>$http,'id'=>(string)wp_remote_retrieve_header($r,'x-restli-id')];
    }
    public static function providerDetails($data,array $c,?array $body): array {
        $data=is_array($data)?$data:[];$message=$data['message']??$data['error_description']??$data['error']['message']??'';
        if(!is_string($message))$message='';
        $sensitive=[];foreach(['token','client_secret','refresh_token','client_id','application_id'] as $k)if(!empty($c[$k]))$sensitive[]=$c[$k];
        $collect=static function($value)use(&$collect,&$sensitive){if(is_array($value)){foreach($value as $x)$collect($x);}elseif(is_string($value)&&strlen($value)>2)$sensitive[]=$value;};$collect($body);
        usort($sensitive,static fn($a,$b)=>strlen($b)<=>strlen($a));foreach($sensitive as $value)$message=str_replace($value,'[redigido]',$message);
        $message=strip_tags($message);
        $message=preg_replace('~https?://[^\s<>]+|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|(?:Bearer|Basic)\s+\S+~i','[redigido]',$message);
        $message=preg_replace('~[a-f0-9]{32,}|\b[0-9]{7,}\b~i','[redigido]',$message);
        $message=preg_replace('~["\'][^"\']*["\']~u','[valor redigido]',$message);
        $message=mb_substr(sanitize_text_field($message),0,1000);
        $code=$data['serviceErrorCode']??null;
        return ['provider_message'=>$message?:null,'serviceErrorCode'=>is_numeric($code)?(int)$code:null,'provider_message_sanitized'=>true];
    }

}
