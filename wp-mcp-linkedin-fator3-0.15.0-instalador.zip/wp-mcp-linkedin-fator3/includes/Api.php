<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Api {
    public static function writes(string $op): bool {return (Config::KEY==='f3_linkedin'&&(Management::writes($op)||Conversions::writes($op)))||in_array($op,['lead-run-discovery','save-retention','save-connection','validate-connection','create-job','run-job','control-job','save-schedule','export','save-grant','lead-create-subscription','lead-delete-subscription','lead-reconcile-subscription','rotate-token','history-migrate','create-backfill','history-export','history-export-step'],true);}
    public static function adminOnly(string $op): bool {return true;}
    public static function capabilities(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'contract'=>'social-reporting/1.0.0','reporting_contracts'=>Config::KEY==='f3_meta'?['social-reporting/1.0.0','social-reporting/1.1.0']:['social-reporting/1.0.0'],'channels'=>Config::CHANNELS,'reports'=>Adapter::reports(),'independent'=>true,'mcp_optional'=>true,'api_version_default'=>Config::API_VERSION,'documentation'=>['operation'=>Config::PREFIX.'/documentation','entry'=>'index','max_bytes'=>65536],'human_capability'=>'manage_options','remote_homologation'=>'requires_authorized_credentials','exports'=>['csv','json'],'commercial_ingestion'=>false,'management_contract'=>'linkedin-management/1.0.0','writes_default'=>'dry_run','central_audit'=>CentralAudit::status(),'conversions_contract'=>'site-conversion-delivery/1.0.0','conversions_supported_contracts'=>[Conversions::CONTRACT,StageConversions::CONTRACT],'service_audit'=>ServiceAudit::capabilities(),'history_contract'=>'linkedin-history/1.0.0','historical_retention'=>'unlimited','oauth_optional'=>true,'automatic_refresh'=>true,'local_sdk'=>Config::KEY==='f3_linkedin'?PublicApi::capabilities():null];
    }
    public static function dispatch(string $op,array $i=[],bool $channel=false): array {
        $result=Result::run(static function()use($op,$i,$channel){
            Access::human();Schemas::validate($op,$i);if(self::adminOnly($op))Access::admin();
            if($channel&&class_exists('\\Fator3\\McpFiles\\AuthorizationPolicy')){$check=\Fator3\McpFiles\AuthorizationPolicy::check(Config::PREFIX.'/'.$op,$i,!self::writes($op));if($check!==true)throw new Fault('not_authorized','Política do transporte recusou esta habilidade.');}
            Http::budget(Config::KEY==='f3_meta'?40:15,25);
            if(Config::KEY==='f3_linkedin'&&Conversions::handles($op))return Conversions::dispatch($op,$i);
            if(Config::KEY==='f3_linkedin'&&Management::handles($op))return Management::dispatch($op,$i);
            if($op==='lead-discovery-status')return LeadDiscovery::status($i['connection_id']);
            if($op==='lead-run-discovery'){$run=LeadDiscovery::tick();if(!$run['success'])throw new Fault($run['code'],'Descoberta indisponível.');return $run['data'];}
            if($op==='lead-list-form-events'){if(empty($i['consumer_id']))throw new Fault('invalid_input','Informe consumer_id para ler os eventos administrativos.');$result=PublicApi::lead_reader($i['consumer_id'])->list_form_events($i);if(!$result['success'])throw new Fault($result['code'],$result['message']??'Falha ao ler eventos.',$result['details']??[]);return $result['data'];}
            if(str_starts_with($op,'lead-')){
                if($op==='lead-discover-forms'){$c=Connections::get($i['connection_id']);Access::connection($c,'leads',$i['account_id']);Connections::usable($c);$start=$i['offset']??0;$r=Http::request($c,'leadForms',['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'start'=>$start,'count'=>50])['body'];$rows=Adapter::elements($r);foreach($rows as $row)if(($row['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('upstream_invalid','Proprietário divergente.');return ['forms'=>$rows,'next_offset'=>Adapter::more($r,$start,count($rows),50)?$start+count($rows):null,'selection_required'=>true];}
                $method=str_replace('-','_',substr($op,5));$r=PublicApi::lead_reader('')->$method($i);if(!$r['success'])throw new Fault($r['code'],$r['message'],$r['details']);return $r['data'];
            }
            return match($op){
                'capabilities'=>self::capabilities(),
                'status'=>['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(self::connections()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'cron'=>['next'=>wp_next_scheduled(Config::KEY.'_worker')?:null,'last'=>get_option(Config::KEY.'_last_worker',null),'traffic_required'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON)],'audit_health'=>get_option(Config::KEY.'_audit_health','unknown'),'service_audit'=>ServiceAudit::capabilities(),'access_lifecycle'=>Config::KEY==='f3_linkedin'?Credentials::status():null]+Worker::health(),
                'selftest'=>SelfTest::run(),
                'configuration-schema'=>['contract'=>'social-configuration/1.0.0','schema'=>Schemas::all()['save-connection'],'credential_input'=>'manual_token','empty_secret_keeps_existing'=>true,'scope_empty_means_none'=>true,'revision_required'=>true,'retention_schema'=>Schemas::all()['save-retention'],'retention'=>Retention::get()],
                'contracts'=>['input'=>Schemas::all(),'output'=>['envelope'=>['success'=>'boolean','code'=>'string','data'=>'object on success; null on failure','error_code'=>'stable failure code','conflict'=>'true for revision_conflict'],'report'=>'social-reporting/1.0.0'],'capabilities'=>self::capabilities()],
                'documentation'=>Documentation::read($i),
                'admin-options'=>Admin::options($i),
                'list-connections'=>(static function()use($i){$at=$i['offset']??0;$rows=Connections::list($at,51);return ['connections'=>array_slice($rows,0,50),'next_offset'=>count($rows)>50?$at+50:null];})(),
                'get-connection'=>['connection'=>Connections::public(Connections::get($i['connection_id']))],
                'audit'=>Audit::list($i),
                'save-connection'=>Connections::save($i),
                'validate-connection'=>Query::validate($i),
                'list-accounts'=>Query::accounts($i),
                'list-fields'=>Config::KEY==='f3_meta'?Catalog::metrics($i):['report'=>$i['report'],'fields'=>Adapter::fields($i['report'])],
                'rotate-token'=>Credentials::rotate($i),
                'history-status'=>History::status(),
                'history-migrate'=>History::migrate($i),
                'get-retention'=>Retention::get(),
                'save-retention'=>Retention::save($i),
                'history-query'=>History::query($i),
                'create-backfill'=>History::backfill($i),
                'history-export'=>HistoryExport::create($i),
                'history-export-step'=>HistoryExport::step($i),
                'history-export-read'=>HistoryExport::read($i),
                'query'=>Query::execute($i),
                'create-job'=>Jobs::create($i),
                'list-jobs'=>Jobs::list($i),
                'job-status'=>Jobs::status($i['job_id']),
                'run-job'=>Jobs::run($i['job_id']),
                'control-job'=>Jobs::control($i),
                'job-results'=>Jobs::results($i),
                'save-schedule'=>Schedules::save($i),
                'list-schedules'=>['schedules'=>Schedules::list()],
                'export'=>Export::create($i),
                'export-read'=>Export::read($i),
                'save-grant'=>PublicApi::grant($i),
                'list-grants'=>PublicApi::grantsPage($i),
                'get-grant'=>PublicApi::grantProjection($i),
                default=>throw new Fault('unsupported','Operação não implementada.')
            };
        });
        if(isset($result['data'])&&strlen(Util::json($result['data']))>900000)$result=Result::fail(new Fault('response_limit','Resposta excedeu o orçamento.'));
        if(isset($result['data']['operation_id'])){$result['operation_id']=$result['data']['operation_id'];$result['replayed']=$result['data']['replayed']??false;}elseif(isset($result['details']['operation_id']))$result['operation_id']=$result['details']['operation_id'];
        if(!in_array($op,['documentation','get-service-write-operation'],true))Audit::record($op,$i,$result,null,$channel?'ability':'rest_or_local');
        return $result;
    }
    private static function connections(): array {return array_values(array_filter(Connections::list(),static fn($c)=>current_user_can('manage_options')||in_array(get_current_user_id(),$c['users'],true)));}
        public static function abilities(): void {
        if(!function_exists('wp_register_ability'))return;
        foreach(Schemas::all() as $op=>$schema){$write=self::writes($op);wp_register_ability(Config::PREFIX.'/'.$op,['label'=>Labels::get($op)[0],'description'=>Labels::get($op)[1],'category'=>Config::PREFIX,'input_schema'=>$schema,'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean'],'code'=>['type'=>'string'],'data'=>['type'=>['object','null']]]],'permission_callback'=>static fn()=>is_user_logged_in()&&current_user_can(self::adminOnly($op)?'manage_options':'read'),'execute_callback'=>static fn($i=[])=>self::dispatch($op,(array)$i,true),'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>!$write,'destructive'=>Management::destructive($op)||in_array($op,['lead-delete-subscription','save-connection','save-grant','save-retention'],true),'idempotent'=>!$write],'fator3'=>['provider'=>Config::SLUG,'version'=>Config::VERSION,'policy_contract'=>1,'mode'=>$write?'write':'read','remote_effect'=>in_array($op,['close-write-operation','lead-discovery-status','lead-list-form-events'],true)?'none':(Conversions::handles($op)?(str_starts_with($op,'send-')?'write':(in_array($op,['list-conversion-rules','save-conversion-grant','save-stage-conversion-grant'],true)?'read':'none')):(Management::handles($op)?(Management::writes($op)?'write':'read'):(str_starts_with($op,'lead-')&&$write?'write':(in_array($op,['save-connection','query','list-accounts','validate-connection','run-job','admin-options'],true)||str_starts_with($op,'lead-')?'read':'none')))),'local_effect'=>$write?'write':'none','execution_contract_version'=>'1.0.0']]]);}
    }
    private static function description(string $op): string {
        return match($op){'query'=>'Consulta uma página. Preserve seleção e next_cursor; complete e ausência de métricas não equivalem a acesso integral.','save-connection'=>'Salva conexão cifrada com expected_revision. Token vazio mantém o atual. Ativos vazios não concedem acesso.','create-job'=>'Admite coleta persistente de leitura; use run-job/status/resultados. Idempotência vinculada à identidade.','lead-create-subscription'=>'Cria assinatura exclusivamente do consumidor/conta/formulário. Resultado incerto não repete POST.','lead-delete-subscription'=>'Remove somente assinatura com autoria local confirmada e contexto vigente.','selftest'=>'Diagnóstico local, sem consultas externas. Não homologa credenciais ou escopos remotos.',default=>'Operação '.$op.' do plugin '.Config::NAME.'. Consulte contracts e documentation para schema e limites.'};
    }
    public static function routes(): void {
        foreach(Schemas::all() as $op=>$schema)register_rest_route(Config::REST,'/'.$op,['methods'=>'POST','permission_callback'=>static fn()=>current_user_can(self::adminOnly($op)?'manage_options':'read'),'callback'=>static function($r)use($op){$input=$r->get_json_params();if(!is_array($input))$input=[];$v=self::dispatch($op,$input);$response=new \WP_REST_Response($v,($v['code']??'')==='not_authorized'?403:200);$response->header('Cache-Control','private, no-store');return $response;}]);
    }
}
final class SelfTest {
    public static function run(): array {
        $checks=[];$test=static function($name,$fn)use(&$checks){try{$ok=$fn();$checks[]=['name'=>$name,'state'=>$ok?'ok':'failed'];}catch(\Throwable $e){$checks[]=['name'=>$name,'state'=>'failed'];}};
        $test('storage',static fn()=>Store::ready());$test('authenticated_encryption',static fn()=>Crypto::open(Crypto::seal('f3-selftest'))==='f3-selftest');
        $test('cursor_roundtrip',static fn()=>Util::uncursor(Util::cursor(['expires'=>time()+30,'value'=>'x']))['value']==='x');
        $test('endpoint_allowlist',static fn()=>!Adapter::allowed('https://example.com/','GET')&&!Adapter::allowed('../secrets','GET'));
        $test('closed_schema',static function(){try{Schemas::validate('status',['unknown'=>1]);return false;}catch(Fault $e){return $e->reason==='invalid_input';}});
        $test('empty_scope_denied',static function(){try{Access::asset(['assets'=>[]],Config::CHANNELS[0],'123');return false;}catch(Fault $e){return $e->reason==='asset_access_denied';}});
        $test('csv_formula_protection',static fn()=>Export::safeCell('=1+1')==="'=1+1");
        $test('history_storage',static function(){global $wpdb;$t=History::table();return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;});
        $test('schema_catalog',static fn()=>count(Schemas::all())>=20);
        $failed=count(array_filter($checks,static fn($x)=>$x['state']!=='ok'));
        if($failed)throw new Fault('selftest_failed','Diagnóstico local reprovado.',['checks'=>$checks]);
        return ['execution_success'=>true,'local_checks_ok'=>true,'checks'=>$checks,'external_checks'=>'not_run','remote_homologated'=>false];
    }
}

final class Audit {
    public static function record(string $op,array $i,array &$result,?string $consumer=null,string $transport='local_sdk',array $diagnostic=[]): void {
        try {if(Store::ready()){Store::put('audit',wp_generate_uuid4(),['operation'=>$op,'actor'=>['type'=>$consumer?'plugin':'user','id'=>$consumer?:get_current_user_id()],'transport'=>$transport,'connection_id'=>$i['connection_id']??null,'code'=>$result['code']??'unknown','at'=>time()]+($op==='oauth-finish'&&$diagnostic?['authorization_diagnostic'=>$diagnostic]:[])+($op==='lead-form-discovered'&&$diagnostic?['form_discovery'=>$diagnostic]:[]),0,Retention::auditExpiry());update_option(Config::KEY.'_audit_health','ok',false);}}
        catch(\Throwable $e){$result['audit_warning']='audit_write_failed';update_option(Config::KEY.'_audit_health','failed',false);}
    }
    public static function list(array $i): array {Access::admin();$offset=$i['offset']??0;$since=$i['since']??0;$rows=Store::recent('audit',$offset,51,$since);$page=array_slice($rows,0,50);return ['events'=>array_map(static fn($r)=>['event_id'=>$r['key']]+$r['value'],$page),'next_offset'=>count($rows)>50?$offset+50:null,'order'=>'newest_first','since'=>$since?:null,'retention_mode'=>Retention::get()['audit_mode'],'retention_days'=>Retention::get()['audit_mode']==='unlimited'?null:Retention::get()['audit_days']];}
}
