<!-- gerado:inicio=carimbo -->
# Memória de decisões — Base Site Core Fator3 1.5.1

> Este bloco é **gerado** por leitura de disco na primeira etapa do comando único, antes de o zip ser
> montado, e conferido por `estatica.carimbo_de_release_nos_documentos`. Nenhum número destes documentos
> é digitado à mão: número digitado está certo no dia em que foi escrito e é contradito pela rodada
> seguinte, sem nada acusando. O que não pode ser medido no momento da escrita sai como pendência
> nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Nome do artefato | `Base Site Core Fator3` |
| Versão, lida do cabeçalho | `1.5.1` |
| Pasta instalada | `base-site-core-fator3` |
| WordPress mínimo · PHP mínimo | `6.4` · `8.1` |
| Plataforma declarada no cabeçalho | `EXIGE PHP DE 64 BITS` |
| Escopo de instalação declarado no cabeçalho | `INSTALAÇÃO ÚNICA, NÃO MULTISITE` |
| Arquivos na fonte do plugin | 46 |
| Arquivos vindos de `partilhado/` | 5 |
| Arquivos no repositório (fora de `dist/` e dos produtos da rodada) | 366 |
| Checagens declaradas por classe de evidência | `analise-estatica/build` 34 · `leitura-de-volta/producao` 1 · `medida/build` 1 · `medida/campo` 1 · `medida/producao` 2 · `pendencia-externa/local` 3 · `pendencia-externa/producao` 2 · `teste-funcional/build` 82 · `wp-real/build` 48 |
| Detectores com piso em disco | 28 |
| Ramos de piso em disco (negativa + positiva) | 56 |
| Passos da bancada WordPress com mutante declarado | 47 |
| Checagens com piso declarado em sonda | 126 |
| Artefato publicado | `base-site-core-fator3-1.5.1.zip` |
| Época declarada de cada entrada do zip | `1980-01-01 00:00:00 UTC` |
<!-- gerado:fim=carimbo -->

Registro das decisões deste plugin. Cada entrada traz o que foi **decidido**, **o defeito
medido** que a originou, **a checagem que prova** que ele não volta, **o que custa** e
**como reverter**. Decisão sem custo escrito é decisão não examinada; decisão sem caminho de
reversão é decisão que só pode ser paga uma vez.

<!-- gerado:inicio=contagem -->
> Este bloco é **gerado** pela leitura deste próprio arquivo: as decisões são contadas a partir dos
> títulos que existem nele, e não de um número escrito ao lado. Uma memória que declara quantas
> decisões tem e conta outra coisa é a primeira frase que alguém confere e a última em que confia.

| Fato medido | Valor |
|---|---|
| Decisões nesta memória | 97 |
| Herdadas do implantador, transcritas verbatim | 38 |
| Nascidas nesta release | 59 |
| Herdadas com nota de superação | 12 |
<!-- gerado:fim=contagem -->

Escopo: valem para ESTE artefato. O que o plugin faz está em
`fontes/plugin/INSTRUCOES-DO-PLUGIN.md`; como se instala e se publica está em `README.md`; o
que é contrato e o que é fato observado está em `MANIFESTO.md`.

Convenção de estados: os mesmos seis estados fechados do relatório da suíte, sem inventar um
sétimo.

## Parte I — decisões herdadas, transcritas

O plugin nasceu dentro do implantador e saiu de lá com identidade própria. As decisões que
governam o que ele FAZ foram tomadas antes desta release, e elas continuam valendo: a
separação de repositório não as revogou, e escrever "a decisão é a mesma" sem o texto dela
deixaria quem lê sem o motivo, sem o custo e sem o caminho de reversão — que é a única coisa
que uma memória de decisões tem para dar.

**Elas são TRANSCRIÇÃO, palavra por palavra**, e o bloco abaixo está delimitado por isso.
Reescrever uma decisão herdada para "atualizá-la" inventaria um passado que não aconteceu:
ela foi tomada com aquelas palavras, sobre aquele pacote, e o valor dela para quem lê hoje é
justamente não ter sido ajustada depois. O título de cada uma declara a origem — o pacote, a
versão e o número que ela tinha lá —, e a numeração daqui é a deste arquivo.

**Dentro de uma decisão transcrita, a referência a outra decisão é da numeração DE
ORIGEM.** Ela foi escrita quando aquele pacote tinha aquela numeração, e reescrevê-la para
apontar para o índice daqui seria editar a transcrição — que é justamente o que este bloco
existe para não permitir. O título de cada decisão traz o número que ela tinha lá, e é por
ele que se encontra o alvo dessas referências na memória de origem.

**Decisão herdada que esta release SUPEROU não é apagada.** Ela recebe, no fim, uma nota com
a forma declarada, apontando para a decisão que a superou. Apagar o texto de uma decisão
superada esconde o que se sabia quando ela foi tomada, e é justamente isso que explica por
que ela foi tomada assim.

O que a prosa acima diz sobre a forma, `doc.numero_digitado` cobra: dentro do bloco
transcrito, toda seção precisa declarar a origem, o índice de cada decisão precisa ser a
posição dela, e a nota de superação precisa apontar para uma decisão que existe neste
documento.

<!-- transcrito:inicio -->

## 1. Consentimento pré-aprovado, com controle no rodapé e aviso de primeira visita desligado (origem: implantador 1.7.4, decisão nº 3)

**Decidido.** `consentimento.padrao` é `pre-aprovado`: as tags carregam na chegada,
sem banner bloqueante. O instrumento do titular é o controle de revisão no rodapé,
presente em toda página publicada — inclusive 404 e páginas de confirmação, porque
ele mora na part do rodapé. A negativa desliga as tags na mesma sessão e persiste por
`ttl_dias`, hoje 180; o novo aceite religa. A chave `aviso_primeira_visita` existe,
tem consumidor no JavaScript do `site-core` e nasce **desligada**.

**Por quê.** A pré-aprovação é a política declarada da operação, e o controle
permanente no rodapé é o que a torna revisável em qualquer momento, em vez de uma
decisão tomada uma vez num banner e nunca mais alcançável. O aviso de primeira visita
nasce desligado porque ligá-lo é decisão de projeto — o caso que a pede é o cliente
cujo jurídico exige informação antes da carga.

**O que custa.** O custo é jurídico e está declarado sem maquiagem: o guia de cookies
da ANPD, de 2022, orienta consentimento prévio para cookies não essenciais, e
pré-aprovação **sem** aviso na primeira visita é a leitura mais exposta de uma posição
já contestada na LGPD. Com o aviso desligado, a transparência se apoia inteiramente na
política publicada e no controle do rodapé — e o relatório de entrega precisa dizer
isso com todas as letras, nunca "o visitante foi informado". Custo secundário: sem
JavaScript o controle não opera, e essa perda é declarada como a do fluxo de WhatsApp.

**Como reverter.** Duas reversões diferentes, e elas não são a mesma coisa. Mitigação
parcial: ligar `consentimento.aviso_primeira_visita`, que acrescenta o aviso não
bloqueante apontando a política e o controle do rodapé, sem mudar a política de carga.
Reversão completa: trocar `consentimento.padrao` para negado, e então as tags só
carregam após o aceite, com o controle do rodapé seguindo como caminho de revisão — a
estrutura é a mesma, os quatro caminhos testados apenas se invertem.

> **Superada na 1.0.0** — ver decisão nº 42.

---

## 2. Rota de origem obrigatória no `site-core` (origem: implantador 1.7.4, decisão nº 9)

**Decidido.** O módulo `rota-origem` é obrigatório, não opcional. Ele expõe uma rota
que faz o próprio servidor pedir a própria URL pública e devolve status, cabeçalhos e
corpo, com o resultado carimbado com a fase `origem`. Restrição fechada: apenas
caminho do próprio `home_url()`, host validado, redirecionamento não seguido, destino
livre recusado pelo nome.

**Por quê.** A regra de leitura de volta precisa de mecanismo quando a rede do agente
é barrada — firewall de aplicação, TLS reiniciado para cliente sem navegador, resposta
de excesso de requisições. Regra sem mecanismo é lembrete, e foi por isso que a rota
virou módulo obrigatório em vez de recomendação.

**O que custa.** Dois custos, e o segundo é o importante. O primeiro: uma rota a mais
na superfície do site, mitigada por capability `manage_options` e nonce ou credencial
do canal. O segundo: o resultado dela é evidência de **origem**, nunca do que o
visitante recebe — o loopback tende a bater na origem e a pular exatamente a camada de
cache ou CDN que produz o defeito mais caro deste tipo de projeto. Apresentar
resultado dessa rota como evidência de visitante é reprovação por desenho, e existe
piso para isso.

**Como usar o custo a favor.** A diferença entre a leitura de origem e a leitura
externa é o próprio diagnóstico de cache: tamanhos e hashes iguais nas duas apontam
para valor que varia por requisição; diferentes apontam para cache servindo versão
velha. O relatório imprime o discriminante em vez de escolher a causa.

**Como reverter.** Remover o módulo do registro único do `site-core`. A consequência
precisa ser declarada junto: sem ele, quando a rede do agente estiver barrada, a
leitura de volta não tem segundo caminho e o item correspondente fecha BLOCKED até um
verificador externo fechá-lo. Não é reversão barata — é troca de um instrumento
limitado e rotulado por nenhum instrumento.

---

## 3. O limite de campo é medido na unidade que o cliente corta (origem: implantador 1.7.4, decisão nº 34)

**Decidido.** O endpoint de leads mede limite de campo em **caracteres**, e o cliente
(`fontes/site-core/assets/f3base-leads.js`) corta em **caracteres**. O número continua
saindo de um lugar só — `limites_publicos()` —, e agora a UNIDADE também.

**Por quê.** O servidor media `strlen()`, que conta bytes; o cliente media `texto.length`,
que conta unidades UTF-16. Os dois recebiam o MESMO número. Com acentuação — isto é, em
português, sempre — o navegador aprovava um nome de 120 caracteres e o servidor devolvia
`400 f3base_limite_excedido` sobre 130 bytes. A recusa é dura por desenho ("recusado,
nunca truncado em silêncio"), então o lead se perdia inteiro, e a página que o aprovou era
a mesma que o pacote publica.

Caracteres, e não bytes nem unidades UTF-16, porque é a unidade que o humano que escreve
o nome percebe, e é a que o texto de recusa nomeia. O corte do cliente passou a andar por
`Array.from()`: cortar por `slice()` no meio de um par substituto devolveria metade de um
caractere, e o servidor receberia texto que ninguém escreveu.

**O que custa.** `mb_strlen()` no servidor (com queda para `preg_match_all('/./us')` onde
mbstring não existir) e uma alocação de array por campo no cliente. Um site que hoje
guarda nomes cortados em 120 bytes passa a aceitar até 120 caracteres — mais bytes na
coluna, o que é o comportamento que o limite declarado sempre prometeu.

**Como reverter.** Trocar `self::comprimento()` por `strlen()` reintroduz o defeito, e
`leads.limite_por_caractere` reprova no mesmo instante — o piso planta o texto acentuado
no limite exato e afirma, antes de medir, que ele EXCEDE em bytes.

---

## 4. Reserva de deduplicação nasce pendente, confirma depois da persistência e é compensada na falha (origem: implantador 1.7.4, decisão nº 35)

**Decidido.** `reservar()` insere a correlação com estado `pendente`; a reserva vira
`firme` só depois de o lead estar gravado; e, quando nenhum destino aceita o lead, ela é
APAGADA. O caminho de contingência por transiente tem a mesma disciplina, com TTL curto
enquanto pendente.

**Por quê.** O `INSERT` acontecia em autocommit e não havia `DELETE` compensatório em
caminho nenhum. Bastava `wp_insert_post()` falhar uma vez para a correlação ficar
reservada por **30 dias**: a tentativa seguinte do MESMO visitante recebia
`200 {"ok":true,"registrado":false,"duplicado":true}` e o lead sumia sem que nada no site
dissesse que tinha sumido. A reserva existia para decidir empate entre replay e duplo
clique — e passou a decidir contra o visitante que tentou de novo.

Junto veio a retomada da reserva ABANDONADA: uma requisição interrompida entre a reserva e
a gravação não deixa ninguém para compensar, e o `UPDATE` condicionado ao carimbo lido faz
com que dois pedidos concorrentes disputando a mesma reserva morta produzam uma retomada
só — o banco decide o empate, como no `INSERT`.

**O que custa.** Três colunas a mais na tabela (`tipo`, `estado`, `contador`,
`expira_em`), uma migração por `dbDelta` e uma instrução a mais por lead aceito. A tabela
antiga continua respondendo ao `SHOW TABLES`, então a prontidão passou a ser medida pelas
COLUNAS: sem elas, o módulo cai para o transiente e reporta DEGRADADO com o motivo.

**Como reverter.** Tirar a chamada a `liberar_reserva()` devolve o defeito, e
`leads.reserva_compensada` reprova: o piso prova que a segunda tentativa depois de uma
falha de armazenamento é ACEITA, e que o replay de uma correlação já gravada continua
recusado.

---

## 5. O ouvinte da cadência mora no site-core, e as recorrências que faltam são registradas (origem: implantador 1.7.4, decisão nº 36)

**Decidido.** O módulo `cadencia-relatorio` do `site-core` engancha
`f3base_cadencia_relatorio`, registra as recorrências `f3base_quinzenal` (15 dias) e
`f3base_mensal` (30 dias), executa o modo somente-relatório registrando última execução,
próxima, duração, resultado, erro e atraso, e conta os ajustes de
`cadencia_relatorio.apos_n_ajustes` — contando de verdade, e disparando.

**Por quê.** Três defeitos do mesmo tronco, medidos na 1.0.17:

- `f3base_cadencia_relatorio` aparecia **uma vez** no pacote inteiro
  (`includes/class-f3base-imp-lotes.php`, a variável `$hook`) e **zero** `add_action` o
  escutava. O evento disparava, o WP-Cron o reagendava, e nada acontecia. Pior: o único
  lugar que conhecia o nome do hook era o implantador, que **se autodesativa** — o
  ouvinte precisava morar no componente que sobrevive a isso.
- `mensal` degradava para `daily` porque `monthly` não existe no núcleo do WordPress, e
  `quinzenal` degradava para `weekly`, **dobrando a frequência**. As duas em silêncio.
- `apos_n_ajustes` era gravado na option `f3base_cadencia`, que **ninguém lia**, e o
  relatório imprimia "gatilho alternativo: após N ajustes" sobre um contador inexistente.

É o próprio pacote cometendo a regra que o documento mestre enuncia: **gravar não é
configurar**. A saída tinha duas formas honestas — ou a chave conta e dispara, ou ela sai
da configuração. Escolhemos a primeira, porque a chave já estava publicada em documento
entregável e chave que não faz nada é pior que chave ausente: ela produz confiança.

**O que custa.** Um módulo a mais no registro único, duas options novas
(`f3base_cadencia`, lida, e `f3base_cadencia_estado`, de execução) e três hooks de option
(`updated_option`, `added_option`, `deleted_option`) enquanto o gatilho por ajustes estiver
ligado. A reentrância é guardada: as escritas da própria execução — carimbo de atividade,
estado da cadência, procedência e journal — NÃO contam como ajuste, senão o gatilho
dispararia sozinho e o disparo gravaria de novo. "Mensal" no WP-Cron é intervalo de trinta
dias, não mês de calendário, e isso está escrito no nome legível da recorrência em vez de
virar surpresa em fevereiro.

**O que ficou de fora, e é do implantador.** A etapa `cadencia` de
`includes/class-f3base-imp-lotes.php` continua mapeando `quinzenal` para `weekly` e
`mensal` para `monthly` com queda para `daily`, e continua imprimindo o gatilho por
ajustes sem dizer que quem o mantém é o site-core. Ela precisa passar a agendar
`f3base_quinzenal` e `f3base_mensal`, a NOMEAR a degradação quando a recorrência declarada
não existir no momento do agendamento, e a parar de prometer mecanismo que não existe.

**Como reverter.** Tirar o módulo do registro único de `F3Base_Registro::classes()`
devolve o estado anterior — e `cadencia.ouvinte_registrado` reprova dizendo, com o nome do
hook, que ninguém escuta.

> **Superada na 1.0.0** — ver decisão nº 69.

---

## 6. A origem do rate limit é declarada, e nunca lida do próprio pedido (origem: implantador 1.7.4, decisão nº 37)

**Decidido.** O balde do rate limit conta por `REMOTE_ADDR` até que
`cabecalhos.origem_confiavel` declare um cabeçalho de proxy e quantos saltos confiáveis
existem à frente do site. Declarado, o valor é lido descontando esses saltos da direita da
cadeia — a única parte que o proxy da frente escreveu. Vazio é o padrão, e vazio significa
NUNCA confiar.

**Por quê.** Dois defeitos somados. O incremento era `get_transient()` +
`set_transient()` sem lock: N requisições concorrentes liam o mesmo valor e gravavam o
mesmo valor mais um, e o balde de 20 por 10 minutos deixava passar quantas coubessem na
janela. E a chave saía só de `REMOTE_ADDR`: atrás de CDN ou proxy reverso, `REMOTE_ADDR` é
o mesmo para todos os visitantes, e o balde inteiro virava um só — o limite deixava de
proteger e passava a atrapalhar.

O incremento passou a ser uma instrução só, com o banco somando
(`INSERT ... ON DUPLICATE KEY UPDATE` com `LAST_INSERT_ID()`), pela mesma razão que a
deduplicação já usava chave única: **o banco decide o empate, não o PHP**. E o cabeçalho é
declarado porque cabeçalho de proxy é declaração do CLIENTE: aceitar um sem declaração é
deixar o visitante escolher em que balde ele conta — spoofing de limite.

**O que custa.** Uma chave a mais na configuração e uma option a mais no `site-core`
(`f3base_origem_confiavel`), ambas vazias por padrão. Sem a tabela pronta, o balde cai
para o transiente — declaradamente não atômico —, e o módulo reporta DEGRADADO com o
motivo.

**Como reverter.** Fazer `incrementar_janela()` cair sempre no transiente devolve o
defeito, e `leads.rate_limit_atomico` reprova: o piso congela a leitura, prova que o
caminho de ler-modificar-gravar devolve 1 e 1, e exige 1, 2, 3, 4, 5 do caminho do banco.

> **Superada na 1.0.0** — ver decisão nº 53.

---

## 7. O pacote deixa de pedir ao canal que recuse a escrita do agente (origem: implantador 1.7.4, decisão nº 50)

**Decidido.** O módulo `guarda-options-mcp` sai INTEIRO: o arquivo, a linha do autoload, o
nome na lista do registro único e a linha do inventário. Com ele saem os quatro filtros do
servidor MCP em que ele registrava as options do catálogo
(`wp_mcp_ultimate_protected_options` e três irmãos). No lugar fica um detector com piso —
`estatica.sem_recusa_de_escrita_do_agente` — que reprova qualquer literal de nome de filtro
de options protegidas no runtime do pacote.

**Por quê.** A premissa desta release, nas palavras de quem a definiu: *"Após a instalação,
todas as futuras modificações serão realizadas por um agente através de MCP. Então o
template e plugins não devem tentar evitar que futuras modificações sejam realizadas. Elas
serão permitidas."* O módulo fazia exatamente o contrário, e não por acidente: ele
registrava as vinte options do catálogo — `f3base_contato`, `f3base_tracking`,
`f3base_consentimento`, todas — nos filtros pelos quais o servidor decide o que recusar.
O agente que precisasse gravar um número de WhatsApp encontraria a recusa vinda do próprio
pacote que ele acabara de instalar.

O módulo já declarava, em comentário, que a lista protegida **não** é fronteira de
segurança: as rotas de arquivo do canal alcançam o código que a implementa. Ou seja: ela
não protegia contra quem quisesse mudar, e atrapalhava quem tinha o direito de mudar. A
fronteira real continua onde sempre esteve — usuário dedicado, Application Password e as
travas do canal.

**O que custa.** Some a trava contra acidente. Uma escrita distraída pelo canal sobre
`f3base_nav_id` ou `f3base_endpoint_segredo` deixa de encontrar qualquer resistência. O
que continua existindo é o registro: toda escrita passa pelo gravador único, a procedência
fica gravada em `f3base_proveniencia`, e a cadência do modo somente-relatório relê as
options e reporta o que divergiu. Trocamos recusa por rastro — e rastro é o que serve a
quem opera por agente.

**Como reverter.** Devolver o arquivo, a linha do autoload e o nome no registro.
`estatica.sem_recusa_de_escrita_do_agente` reprova, nomeando arquivo e linha de cada
literal de filtro; a fixture negativa dele é um módulo que registra exatamente esses
nomes. Reverter começa por tirar a checagem, e essa é uma decisão que fica escrita.

---

## 8. O sanitizador normaliza o que conhece e preserva o que não conhece (origem: implantador 1.7.4, decisão nº 51)

**Decidido.** Todo sanitizador de option de grupo passa por
`F3Base_Options::preservar_desconhecidas()`: a chave declarada continua sendo normalizada
como sempre, e a chave que o pacote não conhece é PRESERVADA — sanitizada como dado (texto,
número, booleano ou lista deles) e com o nome reduzido ao alfabeto de um nome de chave. Nas
options em lista (`f3base_redirects`, `f3base_journal_eliminacao`) a preservação vale
DENTRO de cada entrada. Piso em `options.chave_desconhecida_preservada`, que varre o
catálogo inteiro e não uma option escolhida a dedo.

**Por quê.** O defeito estava medido e é silencioso, que é o pior tipo. Até a 1.0.19 cada
sanitizador RECONSTRUÍA o array a partir das chaves declaradas — `sanitiza_contato`
devolvia três chaves fixas, `sanitiza_tracking` uma, `sanitiza_consentimento` quatro. O
agente acrescentava `telefone` a `f3base_contato` pelo canal; a escrita entrava no banco; a
primeira LEITURA devolvia o valor sem a chave. Sem erro, sem log, sem ninguém para acusar —
e a leitura de volta conferia contra o valor que a própria sanitização tinha imposto, então
até o gate de gravação dizia que estava tudo certo.

Sob a premissa de que toda modificação futura é do agente, um sanitizador que descarta o
que não conhece é um sanitizador que desfaz trabalho alheio a cada leitura.

**O que custa.** A option deixa de ter forma fechada. Um erro de digitação do agente —
`telefonee` — passa a viver na option para sempre, e ninguém o remove por ele. A garantia
que fica é mais fraca e mais honesta: as chaves QUE O PACOTE LÊ continuam com forma
garantida, e o resto é dado de quem escreveu. O segundo custo é de tamanho: option
autoload que cresce sem teto pesa em toda requisição, e o pacote não impõe teto porque não
sabe o que a chave desconhecida vale para quem a gravou.

**Como reverter.** Tirar as chamadas de `preservar_desconhecidas()` dos sanitizadores.
`options.chave_desconhecida_preservada` reprova, e o piso dela é o reconstrutor de chaves
fixas da 1.0.19 escrito na própria bancada: ele existe ali para provar que a bancada
enxerga o descarte, e não para ser usado.

> **Superada na 1.0.0** — ver decisão nº 59.

---

## 9. O CTA só some quando não tem destino, e o `href` só é reescrito quando é do modelo (origem: implantador 1.7.4, decisão nº 52)

**Decidido.** `promover_cta()` ganha dois lados que não se cruzam. **Supressão**: o bloco
deixa de ser publicado apenas quando não tem destino nenhum — `href` vazio, `#` ou o
marcador do modelo, E número vazio. **Promoção**: o `href` só é reescrito quando é do
modelo; `tel:`, landing, formulário próprio e qualquer outro destino ficam como estão. A
mesma regra vale no clique, dentro de `f3base-leads.js`, que também reescrevia o `href` sem
olhar. O `<a>` que o pacote promoveu recebe o carimbo `data-f3base-numero`, e é ele que diz
ao cliente que aquele destino é do pacote. Piso nos quatro quadrantes, em
`leads.cta_preserva_destino`.

**Por quê.** Este era o mecanismo mais forte do pacote contra o agente, e ele agia duas
vezes por página: `promover_cta()` suprimia **qualquer** bloco com a classe
`f3base-acao-contato` quando o número estava vazio, e reescrevia o `href` sem checar quando
estava preenchido. Um CTA que o agente tivesse apontado para uma landing de campanha sumia
do HTML servido — sem erro, sem log, com o relatório verde. Um CTA apontado para um `tel:`
voltava a ser `wa.me` a cada render, e voltava a ser `wa.me` de novo a cada clique.

A decisão nº 46 continua de pé no que ela realmente mediu: publicar um botão que não leva a
lugar nenhum é pior que não ter botão. O que mudou é o alcance — "não leva a lugar nenhum"
passou a ser medido no `href`, em vez de presumido pela classe.

**A REGRA PASSOU A RODAR, e essa é a segunda metade desta decisão.** A medição que a
motivou: a supressão **nunca chegou a rodar**, desde a 1.0.19. `promover_cta()` está no
filtro `render_block`, e `F3Base_Site_Core::registrar()` pulava todos os hooks de módulo
inativo; com `contato.whatsapp_e164` vazia o módulo fecha INATIVO, então o filtro só era
registrado quando havia número — isto é, quando a condição da supressão já não podia
acontecer. As duas condições eram mutuamente exclusivas. Medido por sonda: `estado()`
devolvia `inativo`, `deve_registrar()` devolvia `false`, e `hooks()` declarava um
`render_block` que ninguém registrava. Três documentos afirmavam a regra; o que ia ao ar
era o botão morto do pattern, com o `href` do modelo, em toda instalação sem número.

A afirmação estava certa e o código, não — então o código mudou. `hooks()` ganhou a chave
opcional **`sempre`**, e `registrar()` passa a registrar o item marcado mesmo com o módulo
inativo. A marca alcança UM hook em todo o pacote, e o motivo é que a decisão dele é POR
BLOCO e não pelo estado do módulo: o caso mais importante dela — CTA sem número e com o
`href` do modelo — acontece justamente no estado inativo. A invariante continua de pé para
tudo o mais: módulo inativo não enfileira asset, não registra endpoint e não cria tabela, e
`cta.regra_de_publicacao_registrada` mede isso no mesmo bloco em que mede os quadrantes.

A alternativa recusada foi mudar o ESTADO do módulo para ativo: ela alcançaria a supressão
pelo caminho errado, misturando "o regime existe" com "esta regra decide", e deixaria o
apagamento dependente de qualquer futura mudança na conta do estado. A exceção declarada
por hook diz exatamente o que faz, no lugar onde alguém a lê.

E o apagamento que ela torna alcançável é o único que esta release aceita: **o do bloco sem
destino nenhum**. É a mesma chave que decide, não uma chave de outro regime; e publicar um
botão que não leva a lugar nenhum continua sendo pior que não ter botão.

**O que custa.** O reconhecimento do "destino do modelo" depende de um LITERAL declarado:
`/contato/`, o `href` que o pattern do tema entrega. Não há como derivá-lo — depois que o
conteúdo entra no banco, o bloco renderizado não carrega nenhuma marca de quem escreveu
aquele `href`, e o do pattern e o que o agente digitou chegam iguais ao filtro. Quem trocar
o pattern e não declarar o novo valor em `f3base_cta_hrefs_do_modelo` terá um CTA que o
pacote nunca promove: ele passa a ser tratado como destino de alguém. É o erro seguro dos
dois possíveis.

**Como reverter.** Tirar a leitura de `tem_destino_proprio()` do ramo da supressão e a de
`e_do_modelo()` do laço da promoção. `leads.cta_preserva_destino` reprova nos quadrantes 2
e 4, e `js.conversao_multicanal` reprova o clique que reescreve o `href` do agente.

---

## 10. O cabeçalho emitido é o valor gravado, e o preço sai nomeado (origem: implantador 1.7.4, decisão nº 54)

**Decidido.** `sanitiza_cabecalhos()` deixa de devolver `coop` como literal e passa a LER o
valor armazenado, dentro do vocabulário fechado do cabeçalho; o módulo emite a lista por
`lista_de_cabecalhos()`, que devolve nome→valor e é o que a suíte mede. `Referrer-Policy:
no-referrer` continua sendo aceito e passa a sair com um AVISO em WARN, nomeando os quatro
canais que perdem a origem do clique. Pisos em `seguranca.coop_do_valor_gravado` e
`seguranca.referrer_policy_avisa_atribuicao`.

**Por quê.** O COOP era travado em `same-origin-allow-popups` em dois lugares — na
sanitização e no emissor —, e o efeito era o pior possível para quem opera por agente:
gravar outro valor pelo canal *funcionava*, a leitura de volta *conferia*, e o cabeçalho
saía com o valor do pacote. A option existia e não tinha efeito nenhum. O pacote continua
sabendo qual valor o fluxo de leads precisa; o que ele passou a fazer é NOMEAR a
consequência — o CTA abre a conversa em janela nova, e fora de `same-origin-allow-popups` o
navegador corta a relação com ela — em vez de decidir pelo projeto.

O `Referrer-Policy` é o caso simétrico, e ele importa por causa da segunda premissa desta
release: *"O site será usado com GA4 e Ads, além de também ser utilizado para receber
tráfego do LinkedIn Ads e Meta Ads."* `no-referrer` apaga o referenciador de toda saída, e
com ele some a origem que o GA4 usa para classificar a sessão e que Google Ads, Meta Ads e
LinkedIn Ads usam para reconhecer o próprio tráfego quando o clique chega sem parâmetro de
campanha. Recusar o valor seria decidir por quem grava; deixá-lo passar calado seria
entregar uma campanha sem atribuição e sem explicação.

**O que custa.** Um COOP mal escolhido passa a chegar ao navegador. `same-origin` quebra o
retorno da janela do WhatsApp, e quem gravar isso vai descobrir pelo comportamento — o
estado do módulo fica degradado, mas estado degradado não impede nada. O aviso do
`Referrer-Policy` acrescenta uma linha amarela na tela para uma configuração que pode ser
deliberada; ele só existe no ramo adverso, e com o valor padrão nenhum aviso sai.

**Como reverter.** Voltar o literal ao sanitizador e a constante ao emissor.
`seguranca.coop_do_valor_gravado` reprova em quatro asserções, e o piso dela grava um valor
diferente do padrão justamente para que o literal não possa passar por acaso.

> **Superada na 1.0.0** — ver decisão nº 67.

---

## 11. Tracking dirigido por valores: um caminho só, um portão só, e nenhum Site Kit (origem: implantador 1.7.4, decisão nº 55)

**Decidido.** O site-core passa a emitir as tags de GA4, Google Ads, Meta e LinkedIn a
partir de IDs gravados em options — `f3base_gtm_container_id`,
`f3base_ga4_measurement_id`, `f3base_google_ads`, `f3base_meta_pixel_id`,
`f3base_linkedin_partner_id` e `f3base_linkedin_conversion_id` —, todas nascendo vazias e
inertes. `f3base_gtm_container_id` preenchido decide o caminho: sai o contêiner e mais
nada, e os IDs diretos **nem chegam ao navegador**. Vazio, saem as tags diretas dos IDs
presentes. As quatro passam pelo MESMO `permite_tags()` no servidor e pelo mesmo
`permiteTags()` no navegador. O clique do CTA é a conversão do site e sai nos quatro
canais, de `f3base-leads.js`. Pisos em `tracking.caminho_unico`,
`tracking.consentimento_gateia_tudo`, `leads.click_ids_no_schema` e
`js.conversao_multicanal`.

**Por quê.** O que existia era medição que PARECIA existir, e isso é pior que medição
ausente: ninguém procura o que o console não acusa. O pacote não tinha uma única ocorrência
de measurement ID, de `gtag.js`, de `AW-`, de `send_to`, de `fbq`, de `gclid`, de `fbclid`
ou de `li_fat_id`. O único `gtag` era o STUB do Consent Mode, que torna
`typeof gtag === 'function'` verdadeiro em toda página — então os eventos do CTA entravam
no `dataLayer` como arrays de comando e ficavam lá, esperando um consumidor que nada
carregava. E o evento que saía era `select_content`: `generate_lead` exigia formulário
preenchido, e o template não tem formulário nenhum.

O caminho por Site Kit foi recusado com medida: o OAuth dele é passo humano, e sob a
premissa de que quem opera é um agente, 100% do GA4 e do Google Ads dependeria de alguém
sentar na frente da tela. Valor gravado em option é o que um agente escreve pelo canal.

O caminho único é ESTRUTURAL, e não um `if` no cliente: no caminho do container os IDs
diretos não são publicados. Disparar em dobro deixa de ser um ramo esquecido e passa a ser
impossível, porque não há com o que disparar. Conversão contada duas vezes não é um número
errado num relatório — ela reescreve o lance do leilão.

**O que custa.** Seis options novas para manter, cada uma com forma de fornecedor que pode
mudar. O pacote NÃO recusa ID fora da forma: ele preserva o valor e emite um WARN nomeando
a forma esperada, porque apagar em silêncio é o que esta release inteira parou de fazer — o
preço é que um `G-` faltando produz uma tag que carrega e uma conta que não recebe nada, e
o operador só descobre pelo aviso. As Enhanced Conversions do Google nascem inertes: elas
só têm o que hashear quando um formulário associado fornece e-mail ou telefone, e o
template não tem formulário. O telefone só entra em E.164, com `+` e código do país —
adivinhar o país pelo idioma do site seria inventar um número.

**Como reverter.** Esvaziar as options faz o site voltar a não emitir nada, sem release
nova: é o mesmo mecanismo do slot inerte. Remover o desenho é outra coisa — apagar
`class-f3base-modulo-tracking.php` e `assets/f3base-tracking.js` reprova quatro checagens,
e `tracking.caminho_unico` nomeia o disparo em dobro como o defeito que a estrutura impede.

---

## 12. O contrato de copy sai do catálogo do site-core (origem: implantador 1.7.4, decisão nº 56)

**Decidido.** `f3base_copy_contrato` sai do catálogo de options do site-core, junto com
`sanitiza_copy_contrato()`. A suíte continua conferindo o contrato de copy contra o pacote
por `copy.contrato`, lendo `config/site.json`; o SITE deixa de carregar o contrato.

**Por quê.** Nenhum módulo o lia. A varredura é curta e conclusiva: `copy_contrato` aparecia
no catálogo, no sanitizador e em mais lugar nenhum do site-core. Era artefato de build para
o conteúdo do template — e vira falso no instante em que o agente troca o conteúdo, que é
exatamente o que a premissa desta release diz que vai acontecer. Uma option que ninguém lê
e que envelhece sozinha é pior que uma option ausente: ela dá ao próximo leitor a impressão
de que alguma coisa está sendo conferida dentro da instância.

**O que custa.** Quem quisesse conferir o contrato de copy DENTRO de um site publicado
perde o espelho. Ninguém fazia isso, e quem quiser fazer tem a suíte, que mede o pacote
inteiro e não só as frases que couberam numa option.

**Como reverter.** Devolver a entrada ao catálogo e o sanitizador. Nada reprova por si —
esta é uma remoção sem detector próprio, e está escrita aqui por isso.

**PENDENTE PARA A PARTE 2 DESTA RELEASE.** A escrita continua existindo em
`includes/class-f3base-imp-lotes.php`: a option é gravada no lote de options do site-core e
relida logo abaixo para a linha `copy.contrato_espelhado`. As duas precisam sair, junto com
a entrada de `f3base_copy_contrato` na lista literal de `options_gerenciadas()` em
`includes/class-f3base-imp-relatorio.php`. Enquanto não saírem, o implantador grava uma
option que o site não lê — que é o defeito descrito acima, um nível acima.

---

## 13. O que FICA como está, e por quê (origem: implantador 1.7.4, decisão nº 57)

Três mecanismos foram examinados sob a premissa do agente e **não** mudam. Estão aqui
porque decisão de não mudar também é decisão, e porque a próxima leitura vai fazer a mesma
pergunta.

- **O CPT de leads fechado ao REST fica fechado.** `show_in_rest => false` no CPT de
  contingência não é impedir modificação: é não expor dado pessoal de titular a toda
  credencial autenticada do site, que é o que abrir o REST faria. O agente lê os leads
  pelas rotas de banco do canal, que são credenciadas e auditadas. A saída existe e é
  documentada; o que não existe é a exposição por padrão.
- **A regra dinâmica de `noindex` em categoria rasa fica.** Ela já tem saída declarada, e a
  saída é do agente: gravar `wpseo_noindex = 'index'` no termo faz a categoria passar a ser
  indexada, e o módulo honra o valor do termo em vez de recalcular. Nenhuma release é
  necessária, nenhum arquivo é editado — é uma escrita de meta pelo canal.
- **O contador de ajustes da cadência fica.** Sob a premissa, ele é útil justamente por ser
  o que é: edição do agente conta como ajuste, e ao alcançar o alvo declarado dispara o
  relatório. Um agente que edita muito produz mais relatórios, e é isso que se quer de um
  site cuja manutenção é feita por quem não abre a tela.

---

## 14. A metade de servidor da conversão da Meta, e o preço que já era pago sem ela (origem: implantador 1.7.4, decisão nº 67)

**Decidido.** O `site-core` ganha o módulo `meta-capi`. Depois da persistência CONFIRMADA
de um lead — a mesma transação lógica que a 1.0.18 declarou: reserva firme porque o lead
está gravado —, o endpoint agenda o envio do evento `Lead` para a Conversions API da Meta,
com o **mesmo `event_id`** que o navegador já manda no Pixel. O token de acesso é a option
`f3base_meta_capi_token`, e ele **não existe** no `config/site.json` nem no schema.

**Por quê.** O defeito estava medido dentro do próprio pacote, e ele é do tipo mais caro:
uma metade construída pagando o preço da outra. A 1.1.0 gera o `event_id` no clique do CTA
e o manda em `fbq('track','Lead',{},{eventID})` — *exatamente* para deduplicar contra um
evento de servidor. Esse evento nunca era enviado. O pacote carregava um identificador a
mais em toda conversão, escrevia a palavra "deduplicação" em três documentos, e a cobertura
que ela existe para dar não existia: o pixel de navegador é a metade que iOS e bloqueadores
cortam, e não havia nada preenchendo o buraco.

**O TOKEN É OPTION, E ESSA É A METADE DA DECISÃO QUE MAIS IMPORTA.** `config/site.json`
viaja dentro do zip: a suíte o lê, o empacotador o embute, o bundle vai para quem faz o
upload, e a cópia fica no repositório de artefatos. Um token declarado ali é um token
copiado para todo lugar por onde o pacote passou — e a cópia sobrevive a qualquer rotação
da credencial, porque ninguém volta ao zip para apagá-la. A ausência dele no arquivo único
é a declaração, e ausência sem detector é só esquecimento com boa intenção: por isso a
release traz `estatica.segredo_fora_da_configuracao`, com âncora no próprio pacote
(`F3Base_Options::segredos_do_site()`) e fixture negativa que planta os três defeitos de uma
vez — a chave na configuração, a chave no schema e o lote do implantador gravando o valor.
`f3base_endpoint_segredo` entrou na mesma âncora, pelo mesmo motivo.

**O MEIO DO ENVIO PÓS-RESPOSTA, e por que ele não é `shutdown`.** A escolha foi o evento
único do agendador — `wp_schedule_single_event()` —, e as duas alternativas foram recusadas
com motivo. `shutdown` roda no MESMO processo: sem `fastcgi_finish_request()` a conexão
fica aberta e o worker fica ocupado pelo tempo inteiro da chamada à Meta, inclusive pelo
timeout dela; a resposta já foi escrita, mas a requisição não terminou, e sob rajada de
leads é a fila do servidor que paga. `fastcgi_finish_request()` resolveria isso e não é
portátil — depender dela seria um caminho que funciona no laboratório e desaparece na
hospedagem do cliente, em silêncio. O evento único roda em OUTRA requisição, disparada pelo
próprio WordPress, e é o mesmo mecanismo que a cadência deste pacote já usa.

**O PAYLOAD NÃO VIAJA NOS ARGUMENTOS DO EVENTO**, e essa é a segunda metade da escolha. Os
argumentos de um evento agendado são serializados dentro da option `cron`, que é AUTOLOAD:
cada lead pendente passaria a carregar hashes, IP e user agent em toda requisição do site,
até o evento rodar. O argumento é só o `record_id`; o payload mora num transiente com prazo,
que não é autoload e some sozinho se o evento nunca rodar. O piso mede isso — ele procura o
hash e o IP dentro dos argumentos serializados e reprova se os encontrar.

**A NORMALIZAÇÃO É A DA META, E NÃO A DO GOOGLE.** O arquivo do cliente já traz a
normalização de e-mail das Enhanced Conversions, que remove pontos e sufixos para os
domínios que o Google nomeia. Aplicá-la aqui produziria um hash que a Meta não casa com
nada: a regra dela é espaço fora e minúsculas, e só. Para o telefone são dígitos com código
de país, sem símbolo e sem o `+` — e telefone SEM código de país não é enviado, porque
completar o país pelo idioma do site inventaria um número, que é a mesma decisão que o lado
do navegador já toma. IP e user agent vão em claro porque a Meta os pede assim e porque são
a chave de correspondência que sobra quando o navegador não colabora — que é o caso que
este módulo existe para cobrir. Nome e mensagem do lead **não entram** no payload, e não
entram porque a Meta não os pede.

**O que custa.** Três preços, e nenhum é pequeno.

O primeiro é a **versão da Graph API**. A Meta aposenta versões por calendário, e nenhuma
release nossa adivinha qual é a vigente no dia em que o site estiver no ar. A versão é
constante declarada com filtro ao lado — trocá-la não exige release —, e quando a atual
expirar a chamada passa a responder erro. O que o pacote garante é que o erro sai NOMEADO:
código HTTP, mensagem da Meta e `fbtrace_id` na atividade, e o módulo fecha degradado. Ele
não garante que alguém vá ler.

O segundo é a **dependência do agendador**. Com `DISABLE_WP_CRON` ligada e sem cron de
sistema, o evento fica agendado e não roda: o lead continua gravado e o que atrasa é a
metade de servidor da conversão. A dependência sai nomeada na tela do módulo, e é o erro
seguro dos dois possíveis — o outro seria segurar o worker.

O terceiro é o **transiente órfão**. Se o evento nunca rodar, o payload expira sozinho; se
rodar depois da expiração, o envio fecha "payload expirou" e a conversão daquele lead se
perde do lado do servidor. Perder a metade de servidor de um lead é melhor que enviar um
corpo vazio para a Meta, e a escolha está escrita no ramo.

**Como reverter.** Esvaziar `f3base_meta_capi_token` faz o envio voltar a não existir, sem
release nova: é o mesmo mecanismo do slot inerte, e o módulo passa a fechar inativo
nomeando a option. Remover o desenho é outra coisa: apagar o módulo reprova `leads.capi_meta`
em todos os ramos, e apagar a âncora de segredos reprova `estatica.segredo_fora_da_configuracao`
com a mensagem de que uma regra sem escopo nunca acusa nada.

> **Superada na 1.0.0** — ver decisão nº 49.

---

## 15. Verificação de posse do domínio: duas options, e o que elas destravam (origem: implantador 1.7.4, decisão nº 68)

**Decidido.** Duas options novas no `site-core` — `f3base_verificacao_google` e
`f3base_verificacao_meta` —, vazias por padrão, cada uma emitindo a `<meta>` correspondente
no `<head>` quando preenchida. Vazias, nada é emitido, e a condição sai declarada em
`verificacao.dominio_declarada`. As chaves existem também no arquivo único
(`verificacao_dominio.google` e `verificacao_dominio.meta`) para que um site cujo operador
já tenha os tokens nasça verificado.

**Por quê.** A varredura é curta e conclusiva: ZERO ocorrências de `google-site-verification`
e de `facebook-domain-verification` no pacote inteiro. As duas não são enfeite. A
verificação do Search Console é o que dá à operação uma propriedade do domínio — sem ela não
há relatório de busca e não há a que ligar o GA4. A verificação de domínio da Meta é o que
decide **quem pode editar o link e a criativa** dos anúncios que apontam para este site;
sem ela, um domínio reivindicado por outra conta é um problema que se descobre tarde. As
duas eram passo humano no console **e** passo humano no HTML — e o segundo não precisava
ser, porque ele é exatamente o que uma option resolve.

**O DESENHO É O DOS SLOTS DE MEDIÇÃO, de propósito.** Vazio é inerte; preenchido emite; quem
grava é o agente, pelo canal. Um segundo mecanismo para o mesmo tipo de dado seria uma
segunda coisa para manter e uma segunda chance de divergir.

**VALOR FORA DA FORMA É PRESERVADO E AVISADO.** O token é opaco: o alfabeto é do fornecedor,
e ele pode mudá-lo sem avisar ninguém. O sanitizador desta option, ao contrário do de ID de
tag, **não reduz o alfabeto** — filtrar caractere aqui apagaria metade de um valor válido e
produziria uma verificação que nunca fecha, sem uma linha dizendo por quê. O que sai fora da
forma conhecida é preservado, emitido **escapado** no atributo, e nomeado num WARN com a
forma esperada. O engano mais comum é colar a tag inteira em vez do conteúdo dela, e é
exatamente ali que ele cai.

**O que custa.** Duas options a mais no catálogo, e um valor errado que o pacote não
recusa: a tag existe no HTML, o fornecedor não reconhece o token, e a verificação nunca
fecha. O aviso é a única defesa, e ele só aparece para quem abre a tela do site-core ou lê
o relatório da cadência. Recusar seria decidir por quem grava, e apagar em silêncio é o que
esta operação parou de fazer.

**Como reverter.** Esvaziar as duas options faz o site voltar a não emitir nada. Remover o
desenho reprova `verificacao.tag_do_valor_gravado` nos dois ramos — o do slot vazio e o do
valor preservado com aviso.

---

## 16. `tracking.eventos_ga4` sai, e com ela a option que existia só para carregá-la (origem: implantador 1.7.4, decisão nº 71)

**Decidido.** `tracking.eventos_ga4` sai da configuração, do schema, do catálogo do
`site-core` e dos dois leitores. Com ela sai a option `f3base_tracking`, que não tinha outro
subcampo. A chave entra em `suite/chaves-removidas.tsv`, com os tokens `eventos_ga4` e
`eventosGa4`, e `estatica.sem_residuo_de_chave_removida` prova que não sobrou nada em
configuração, schema, código ou documento.

**Por quê.** Aplicado o teste da 1.0.19 — *o que muda se eu mudar isto?* — a resposta é:
nada que outra coisa já não decidisse. A chave era lida em dois lugares
(`class-f3base-modulo-leads-whatsapp.php` e `class-f3base-modulo-tracking.php`), viajava
para o navegador como `eventosGa4` e governava uma guarda que já tinha a resposta ao lado:

```
if (!dados.eventosGa4 || typeof window.gtag !== 'function') { return; }
```

Sem `f3base_ga4_measurement_id` gravado, nada carrega o `gtag.js` — e sem `gtag.js`,
`typeof window.gtag !== 'function'` já barra o disparo. Com o ID gravado, não há por que não
disparar: quem gravou o measurement ID pediu a medição. A chave só podia discordar do
próprio dado, e é o mesmo caso do `formularios[].ativo` da 1.0.19 — dois fatos sobre a mesma
coisa, e um deles sem consequência.

**A OPTION SAIU JUNTO, e essa é a metade que a decisão 56 nos ensinou.** `f3base_tracking`
era um grupo com exatamente um subcampo: o interruptor. Sem ele, ela seria uma option de
grupo sem nenhuma chave — gravada pelo implantador, presente no catálogo, lida por ninguém.
Option que ninguém lê é pior que option ausente: ela dá ao próximo leitor a impressão de que
alguma coisa está sendo conferida ali dentro.

**O que custa.** Some a capacidade de ter GA4 carregado e os eventos recomendados
desligados. Ela existia no papel e não tinha caso de uso declarado: quem não quer o evento
esvazia o measurement ID, e quem quer o `gtag.js` sem `generate_lead` está pedindo uma
combinação que este pacote nunca ofereceu de propósito — o clique do CTA é a conversão deste
site desde a decisão 55.

**Como reverter.** Tirar a linha de `suite/chaves-removidas.tsv` e devolver a chave à
configuração, ao schema, ao catálogo e aos dois leitores. Enquanto a linha estiver lá,
`estatica.sem_residuo_de_chave_removida` reprova o token em configuração, schema, código e
documento — e a narrativa declarada é este arquivo.

---

## 17. O site nasce instrumentado para comportamento, e não só para conversão (origem: implantador 1.7.4, decisão nº 75)

**Decidido.** O carregador de tracking passa a instalar **seis coletores de
comportamento**, todos pelo MESMO portão de consentimento das quatro tags e emitidos nos
DOIS formatos que a 1.1.0 estabeleceu: marcos de rolagem, seção vista, clique em link
externo, fricção, erro de JavaScript do próprio site e Core Web Vitals de campo. Nome,
parâmetro, teto por página e limiar moram num arquivo só —
`fontes/site-core/dados/eventos-comportamento.tsv`. Pisos em
`js.comportamento_instrumentado` e `tracking.eventos_de_comportamento_declarados`.

**Por quê.** A premissa nova, nas palavras de quem a definiu: *"o site no WordPress já deve
nascer instrumentado para validar e avaliar o comportamento dos usuários no site."* A
varredura do que existia é curta: `generate_lead`, `form_start` e `select_content` — tudo
em torno da conversão. Nada dizia se a página era lida, onde o visitante parava, o que ele
tentava clicar nem qual era a experiência real de carregamento. Um site que só mede
conversão só sabe responder sobre quem converteu, e quem não converteu é a maioria.

**A DECLARAÇÃO É ÚNICA, E O CLIENTE NÃO ESCREVE NOME NENHUM.** O gatilho é a chave de
junção — `rolagem`, `interseccao`, `clique-externo`, `clique-repetido`, `erro`,
`desempenho` —, e o coletor entrega os valores POSICIONALMENTE: o servidor os casa com a
coluna `parametros`, na ordem em que ela está escrita. Isso torna o nome do evento
renomeável num lugar só, sem tocar em uma linha de JavaScript, e
`tracking.eventos_de_comportamento_declarados` reprova qualquer literal de nome declarado
dentro do JavaScript do pacote — foi ele que reprovou a primeira versão desta implementação,
que escrevia os seis nomes no cliente. O motivo é quem lê: um agente comparando períodos.
Para ele, nome que muda entre releases não é erro visível — é o relatório do mês seguinte
vazio, sem ninguém saber se o site parou de medir ou se os visitantes pararam de rolar.

**OS LIMIARES E OS TETOS, com o motivo de cada um.**

| Evento | Teto | Limiar | Por que este número |
|---|---|---|---|
| rolagem | 4 | 25/50/75/90 | O teto é igual à quantidade de marcos DE PROPÓSITO: um quinto evento de rolagem na mesma página só pode ser rajada, porque não há um quinto marco. 90 e não 100 porque o fim absoluto quase ninguém alcança em página com rodapé alto |
| seção vista | 12 | 50% visível | Meia seção porque uma faixa que aparece de raspão na borda não foi vista por ninguém. Teto de 12 porque o template mais longo desta base tem 5 seções nomeadas, e o dobro já é folga; acima disso é página montada por laço, e ali a leitura útil acabou |
| link externo | 10 | — | A décima saída já respondeu a pergunta que o evento faz |
| fricção | 3 | 4 cliques · 1200 ms · 24 px · alvo interativo | Ver abaixo |
| erro do site | 3 | origem = site | Contados por `arquivo:linha` DISTINTOS. Erro em laço de render dispara milhares de vezes e são sempre o mesmo defeito |
| web vital | 4 | LCP, CLS, INP, TTFB · 16 ms | Um por métrica, no primeiro ocultamento da página |

Teto somado: **36 disparos por página**, e ele existe porque sem teto uma única página faz
o volume de um dia — e aí a conta de medição amostra ou descarta o excesso em silêncio, sem
dizer o que perdeu. O descarte passa a ser NOSSO e declarado.

**O LIMIAR DA FRICÇÃO, e a prova de que uso normal não dispara.** Quatro cliques, e não
dois nem três: **duplo clique é gesto normal de sistema** e **triplo clique é o gesto
normal de selecionar um parágrafo**. Um limiar em 2 ou em 3 marcaria como frustração o uso
comum de qualquer página de texto — o falso positivo mais barato de cometer e o mais caro
de descobrir, porque ele chega ao relatório com cara de dado. A janela de 1200 ms fica
acima da janela de múltiplo clique dos navegadores (na casa dos 500 ms) e abaixo do
reclique deliberado, que é nova tentativa e não raiva. O raio de 24 px existe porque o
mesmo ponto precisa ser o mesmo ponto: sem ele, percorrer uma lista de links acumularia
cliques de lugares diferentes. E o alvo tem de ser um CONTROLE, porque o gesto de seleção
de texto pousa em texto.

O piso prova os cinco casos normais que **não** disparam — duplo clique, triplo clique,
cliques espalhados além do raio, cliques em controles diferentes e cliques repetidos num
parágrafo — e o caso que dispara.

**A RECUSA DECLARADA: o "dead click" não é implementado.** O outro sinal de fricção —
clique em elemento não interativo — foi examinado e recusado com motivo. Numa página de
texto, todo triplo clique para selecionar um parágrafo, todo duplo clique acidental num
título e todo toque para fechar o teclado no celular pousam em elemento não interativo.
Separar isso de frustração exigiria um modelo de intenção que este pacote não tem, e um
falso positivo ali polui exatamente o relatório que a medição existe para produzir. Sinal
que não se sabe medir sem falso positivo é recusa declarada, nunca implementação torta.

**A ORIGEM DO ERRO É O PORTÃO, E NÃO UM PARÂMETRO.** Só o que classifica como `site` vira
evento; `terceiro` e `ambiente` não saem. É por isso que um bloqueador de anúncio não
enche o relatório: ele quebra o script do fornecedor, não o nosso. Um parâmetro de origem
seria peso morto — ele só poderia dizer `site` —, e chave que nunca pode discordar do
próprio dado é a mesma doença que a decisão 71 tirou do módulo de tracking.
`unhandledrejection` **não é ouvido**, também com motivo: promessa rejeitada não carrega
arquivo nem linha em navegador nenhum, então a origem dela não é decidível — e evento cuja
origem não é decidível é exatamente o que enche o relatório.

**NENHUM EVENTO CARREGA DADO PESSOAL, e cada recusa tem um lugar onde ela pode falhar.**
Do link externo sai o **host** e nada mais: caminho e query são onde mora o identificador
— `/perfil/joao-silva` no caminho, `?email=` ou `?token=` na query, e um `utm_content` que
a campanha de outra pessoa preencheu com o id do lead. Do erro sai o caminho sem query e
sem fragmento, e **a mensagem não sai**: ela carrega o valor interpolado que produziu o
erro, e esse valor pode ser o que o titular digitou. A segunda defesa é estrutural: os
parâmetros são casados com a declaração, e um valor a mais do que ela prevê é descartado
antes do `dataLayer` — a porta é a lista, não a boa intenção de quem escreve o coletor. O
piso varre o payload inteiro, como o da CAPI faz.

**A SEÇÃO É NOMEADA PELO MARKUP, E SEM NOME NÃO É MEDIDA.** O tema carimba
`f3base-secao-<nome>` como `className` nos cinco patterns — e como `className`, nunca como
atributo cru: um `data-` avulso no `<div>` de um `core/group` quebraria a validação do
bloco no editor. Derivar o nome de um título produziria uma série histórica que muda
sozinha na primeira revisão de copy, com uma seção nova e uma seção que sumiu sem que nada
tivesse mudado na página.

**CORE WEB VITALS SEM BIBLIOTECA, E O VALOR SAI CRU.** `PerformanceObserver` nativo para
LCP, CLS e INP, e `PerformanceNavigationTiming` para o TTFB: a política de origem declarada
não admite CDN de terceiro e o peso do carregamento é pago pelo visitante. Os quatro são
relatados uma vez, no primeiro ocultamento da página — que é quando LCP, CLS e INP têm
valor final. **A classificação de bom/precisa-melhorar/ruim foi recusada**: os cortes são
do fornecedor e mudam por calendário, e embuti-los aqui faria o relatório deste site
discordar do console do fornecedor no dia em que eles se movessem, sem uma linha dizendo
por quê. Quem classifica no destino tem o corte vigente, que nós não temos.

**`desempenho.core_web_vitals` CONTINUA BLOCKED, e essa é a metade que a release não fecha
por otimismo.** Coleta existir não é o mesmo que o dado ter chegado. Core Web Vitals de
campo são a distribuição sobre visitas REAIS: antes de haver visitante não há valor, nem
distribuição, nem estabilidade. Fechar OK porque o coletor existe seria trocar "o
instrumento está instalado" por "a medida foi tomada" — o tipo exato de afirmação que esta
suíte existe para não fazer. O que a linha ganhou foi PRECISÃO na pré-condição: até a
1.1.2 faltavam a coleta **e** o tráfego; agora falta só o tráfego, e o BLOCKED diz qual dos
dois.

**O que custa.** Quatro preços, e nenhum é pequeno.

O primeiro é de **volume**: 36 eventos a mais por página, no teto, contra os três que o
pacote emitia. Numa conta gratuita do GA4 isso conta para o limite de eventos, e quem
operar um site de tráfego alto vai querer baixar os tetos — que é uma edição de uma coluna
do TSV, sem release.

O segundo é a **ordem dos parâmetros virar contrato**. Como o cliente os entrega
posicionalmente, trocar a ordem de dois parâmetros na declaração troca o significado dos
dois no relatório, em silêncio. É o preço de o cliente não escrever nome nenhum, e está
declarado nos dois arquivos.

O terceiro é o **custo de execução no navegador do visitante**: um ouvinte de rolagem
(passivo), um `IntersectionObserver`, dois ouvintes de clique em captura, um ouvinte de
erro e três `PerformanceObserver`. Nenhum deles é caro sozinho; todos juntos são trabalho
que a página não fazia, e ele é pago por quem visita.

O quarto é de **manutenção da plataforma**: `interactionId`, `hadRecentInput` e
`durationThreshold` são superfície de especificação em evolução. Uma mudança de navegador
pode degradar uma métrica sem erro nenhum — o coletor continua rodando e o número passa a
significar outra coisa. A mitigação é que o valor sai cru: quem compara com o console do
fornecedor vê a divergência.

**Como reverter.** Esvaziar `f3base_ga4_measurement_id` e o container faz toda a
instrumentação voltar a não existir, sem release — é o mesmo slot vazio → inerte das tags.
Baixar um teto ou tirar uma linha do TSV desliga um coletor, também sem release. Remover o
desenho é outra coisa: apagar a declaração reprova
`tracking.eventos_de_comportamento_declarados` na primeira asserção, e apagar os coletores
reprova `js.comportamento_instrumentado` em todos os tetos.

---

## 18. Todo campo operável diz o que MUDA no site, e o exemplo nunca é um valor que funciona (origem: implantador 1.7.4, decisão nº 77)

**Decidido.** Toda folha operável do catálogo do `site-core` passa a declarar duas chaves
obrigatórias além do rótulo: **`impacto`** — o que muda no site quando o campo é preenchido, e
o que acontece enquanto ele está vazio — e **`exemplo`** — um valor ilustrativo e
obviamente ilustrativo. O detector `estatica.campo_operavel_tem_impacto_e_exemplo` cobra as
duas, com o catálogo como âncora, e cobra mais duas recusas: **segredo não tem exemplo de
valor** (nenhuma corrida de 16 ou mais caracteres alfanuméricos no exemplo de uma option
declarada em `segredos_do_site()`) e **identificador de fornecedor sai na FORMA que o próprio
pacote declara** em `F3Base_Modulo_Tracking::formas()` — `G-XXXXXXXXXX`, `GTM-XXXXXXX`,
`AW-000000000`, `somente dígitos`.

**Por quê.** O pedido, nas palavras de quem o fez: *"para cada campo, apresente uma
explicação do impacto de preencher aquele campo, assim como um exemplo de preenchimento."*
A varredura do que existia é curta e conclusiva: toda option tinha `rotulo`, **algumas**
tinham `descricao`, e **nenhuma** tinha impacto ou exemplo. Rótulo é o nome da coisa;
descrição é a definição dela. *"Número de WhatsApp em E.164"* é definição — e ela não diz o
que quem está com o cursor no campo precisa saber: que **enquanto aquele campo estiver
vazio o botão de contato não é publicado em página nenhuma**. A pessoa que abre a tela não
quer saber o que o campo é; quer saber o que acontece se ela preencher.

**AS DUAS RECUSAS DO EXEMPLO, e por que elas são medidas e não recomendadas.** Copiar um ID
de medição real para dentro do pacote manda os dados do cliente para a conta de outra
pessoa — em todo site que instalar este pacote, de uma vez. E um exemplo que **funciona
colado sem pensar** é a mesma coisa com mais passos: alguém copia, grava, a tag carrega, o
console do fornecedor fica mudo e ninguém sabe por quê. A forma com dígitos genéricos é a
que o próprio fornecedor usa na documentação dele — ela ensina o formato e não pode ser
usada. Para o token da Conversions API não existe forma segura: o campo passa a trazer
**onde obtê-lo** e o aviso de que ele nunca viaja no arquivo de configuração, e a marca na
tela deixa de dizer "Exemplo" e passa a dizer "Onde obter".

**O QUE A EXIGÊNCIA DE IMPACTO ENCONTROU: um campo sem impacto nenhum.**
`f3base_contato.email_leads` estava no formulário desde a 1.0.0, e a varredura de
consumidores em runtime é conclusiva — **nenhum módulo deste plugin lê essa subchave**. O
destino do regime por e-mail mora dentro da entrada de formulário desde a decisão 62. O
impacto honesto daquele campo seria "preencher não muda nada", e um campo assim não é campo:
é armadilha na tela de quem opera. Ele **saiu do formulário** e **continua no padrão e no
sanitizador**, para que o valor que o agente gravar ali pelo canal continue sendo preservado
como qualquer chave desconhecida.

**O que custa.** Três coisas. A primeira é **volume de texto**: o catálogo cresceu, e cada
campo novo passa a exigir duas frases escritas — o detector reprova o campo que nascer sem
elas, e isso é de propósito. A segunda é que **as frases envelhecem**: um impacto escrito
hoje descreve o comportamento de hoje, e nada mede se ele continua verdadeiro amanhã — o
detector cobra a EXISTÊNCIA da frase, não a verdade dela. A terceira é que a forma
ilustrativa vira contrato: mudar `formas()` sem mudar o exemplo reprova a rodada.

**Como reverter.** Apagar `impacto` e `exemplo` de uma folha reprova
`estatica.campo_operavel_tem_impacto_e_exemplo` no primeiro ramo, nomeando o campo, e
`tela.campo_diz_impacto_e_exemplo` no DOM. Devolver `email_leads` ao formulário é
acrescentar a entrada em `subcampos` — e aí ela passa a precisar de um impacto que hoje não
existe.

---

## 19. A tela é agrupada por assunto, escrita para quem opera, e o diagnóstico desce (origem: implantador 1.7.4, decisão nº 78)

**Decidido.** A tela do `F3 Base Site Core` passa a ter **quatro blocos de preenchimento**
— Contato, Medição e anúncios, Consentimento, Privacidade e retenção — seguidos de **dois
blocos de leitura**: o resumo de comportamento e o estado das partes do plugin. A ordem é
declarada num lugar só (`F3Base_Options::secoes_da_tela()` mais
`F3Base_Admin_Tela::ordem_dos_blocos()`) e é MEDIDA no DOM por
`tela.campo_diz_impacto_e_exemplo`. O vocabulário interno do projeto — "operável",
"estrutural", "registro único", "leitura de volta", "gate" — sai da superfície da tela; os
conceitos continuam valendo por dentro, e o nome técnico de cada option aparece como
referência secundária, para quem opera pelo canal.

**Por quê.** O texto que abria a tela até a 1.1.3 era este: *"Esta tela renderiza o registro
único de módulos — a mesma fonte que registra os hooks e monta o relatório da implantação. O
que é operável se edita aqui; o que é estrutural aparece com estado e motivo."* Ele é
verdadeiro e é escrito para quem construiu o pacote. Quem abre a tela quer resolver uma
coisa — ligar o WhatsApp, conectar a conta de anúncio, decidir um prazo — e encontrava
primeiro um relatório de estado interno, com os campos apresentados na ordem em que alguém
os escreveu no catálogo. **A ordem dos blocos é a ordem em que alguém instala um site**, e
por isso ela é declaração, não acaso.

**O DIAGNÓSTICO NÃO ENCOLHEU.** Módulos, estados, motivos, avisos, dependências, hooks,
options que controlam cada parte e as options sem módulo: tudo continua, e
`tela.campo_diz_impacto_e_exemplo` mede que continua. Ele é o que o suporte e o agente leem,
e é o que responde "por que isto não está acontecendo no site". O que mudou é a posição:
primeiro o que se preenche, depois o que se observa.

**O EXEMPLO NUNCA ENTRA NO CAMPO, e o piso é o `placeholder`.** Exemplo em `placeholder` é
valor fantasma: ele some quando o operador digita, reaparece quando ele apaga, e é lido como
conteúdo do campo por leitor de tela e por quem tem pressa. É a forma mais barata de fazer
alguém sair da tela convencido de que gravou o que não gravou. A bancada reprova
**qualquer** `placeholder=` no HTML da tela, e reprova qualquer exemplo que apareça dentro de
um `value` do formulário.

**O que custa.** A tela ficou **mais longa**: quatro blocos com cabeçalho e resumo, e duas a
três linhas de texto por campo. Quem já sabe o que quer preencher passa a rolar mais. A
compensação declarada é que o campo fica ao lado do assunto dele, e não a doze linhas de
distância de outro assunto. O segundo preço é que **a ordem virou contrato**: acrescentar
uma option operável exige declarar a seção dela, e o detector estático reprova quem não
declarar.

**Como reverter.** Trocar a ordem em `secoes_da_tela()` muda a tela e a asserção junto —
elas leem a mesma função. Voltar ao formato de lista única é apagar os blocos, e aí
`tela.campo_diz_impacto_e_exemplo` reprova na asserção da ordem, nomeando o observado e o
declarado.

---

## 20. O site passa a guardar o próprio resumo de comportamento, e vira um destino (origem: implantador 1.7.4, decisão nº 79)

**Decidido.** O `site-core` ganha o módulo `comportamento`: ao **sair** de cada página, o
navegador manda **uma vez**, por `sendBeacon`, os **totais agregados** daquela visita, e o
servidor os soma numa **tabela própria** — `<prefixo>f3base_comportamento`, uma linha por
dia, caminho, evento e detalhe, com contagem e soma. A leitura é dupla: um quadro na tela do
plugin e a mesma tabela por rota de banco do canal, sem depender de credencial de fornecedor
nenhum. A retenção é declarada em `f3base_comportamento.retencao_dias` e executada pela
rotina de retenção que já existia.

**Por quê.** A pergunta, nas palavras de quem a fez: *"O site nasce instrumentado, onde
posso ver os dados desta instrumentação."* A medição da resposta, antes de respondê-la:
`grep` dos seis nomes de evento de comportamento dentro do plugin devolve **zero** — eles
saem do navegador direto para a conta de medição —, e `f3base_atividade` guarda só o que
passa pelo servidor. Com `f3base_ga4_measurement_id` vazio, os eventos **não eram emitidos**:
não existiam em lugar nenhum. A 1.1.2 nomeou essa lacuna como "opção não tomada"; esta
release a toma.

**O PRÓPRIO SITE VIROU UM DESTINO, e é essa a mudança de fundo.** A guarda da 1.1.3 dizia:
sem slot de medição preenchido, nada é instalado e nada é emitido — porque emitir
comportamento sem uma conta para recebê-lo é emitir para lugar nenhum. Com a tabela
existindo, "lugar nenhum" deixou de ser verdade. O portão do enfileiramento passou de "há
ID?" para **"há destino?"** (`F3Base_Modulo_Tracking::ha_destino()`), e a guarda antiga
continua inteira dentro dele: **sem os dois destinos, nada é instalado e nada é emitido**, e
`tracking.caminho_unico` mede exatamente isso, agora com a condição escrita. A recusa que
NÃO se moveu: com o slot vazio, `emitir()` **não** empurra nada no `dataLayer` — alimentar um
container que ninguém carregou seria mandar dados para uma conta que este pacote nunca soube
que existia.

**AS QUATRO RECUSAS DO PAYLOAD, cada uma com onde ela pode falhar.**

1. **Nenhum identificador de visitante.** Não há id de sessão, não há cookie e nada é
   gravado no armazenamento do navegador: a sessão vive na memória da aba e existe só para
   não enviar duas vezes. O piso varre `localStorage`, `sessionStorage` e `document.cookie`.
2. **Nenhuma URL com query.** O que viaja é `location.pathname`. A URL da bancada tem
   `utm_content` e um e-mail dentro de propósito — é ali que a campanha de outra pessoa cola
   o identificador do lead.
3. **Nenhum texto livre.** O detalhe passa por um **alfabeto fechado** sem barra, arroba,
   dois-pontos nem espaço: host de destino, nome de seção, marco de rolagem e nome de
   métrica passam; caminho de arquivo, endereço e mensagem não têm como passar. É por isso
   que o **erro de JavaScript entra como contagem e sem o arquivo** — a página já é a chave, e
   o arquivo interpolado é onde mora o valor que o titular digitou.
4. **Nenhum evento sem declaração.** O cliente manda o **gatilho**; quem resolve o nome é o
   servidor, contra `dados/eventos-comportamento.tsv`. É a mesma regra da 1.1.3, e ela é o
   que permite renomear um evento num lugar só sem quebrar a série histórica.

**O PORTÃO É O MESMO DO CONSENTIMENTO, e a tela declara o que isso significa.** Sem
consentimento o navegador não envia; o servidor não tem como conferir o consentimento de
quem não mandou nada. Por isso o quadro diz, ao lado dos números, que eles contam **só as
sessões em que o consentimento permitiu medição** — quem lê um total sem essa frase acha que
está vendo o universo.

**A TABELA, E NÃO UMA OPTION.** Contador diário cresce todo dia; uma option com o resumo
dentro cresceria sem teto e, sendo autoload, seria lida em **toda** requisição do site. A
migração é por `dbDelta`, e a prontidão é medida **pelas colunas** — o padrão que a 1.0.18
estabeleceu —, porque tabela antiga responde ao `SHOW TABLES` e faz o `INSERT` desta versão
falhar em silêncio. Sem a tabela pronta, a rota responde **503 nomeando a perda** e o módulo
fecha degradado: a perda é declarada, nunca silenciosa.

**O DESVIO DO ROTEIRO, declarado com a medição.** O roteiro pedia que, com
`ga4_measurement_id` vazio, a tela dissesse que "os eventos não estão sendo emitidos para
lugar nenhum". Depois desta release isso deixou de ser verdade: eles passam a ser somados na
tabela do próprio site. A tela diz então a frase exata: **nenhum evento chega ao Google
Analytics, a análise completa não existe em lugar nenhum, e o quadro abaixo é tudo o que
há** — seguida do campo que precisa ser preenchido para mudar isso. Escrever a frase pedida
ao pé da letra seria imprimir na tela uma afirmação que a própria release tornou falsa.

**O que custa.** Cinco preços, e nenhum é pequeno.

O primeiro é **escrita no banco em toda visita**: uma requisição REST por sessão e até
trinta e seis linhas de `INSERT … ON DUPLICATE KEY UPDATE`. Em site de tráfego alto isso é
carga nova, e quem não a quiser desliga a chave — sem release.

O segundo é **crescimento de tabela**: dia × caminho × evento × detalhe. Um site com muitas
páginas e muitos domínios de saída gera muitas linhas, e é por isso que a retenção é
declarada e tem teto de 730 dias no sanitizador.

O terceiro é a **sessão que se perde**. O envio é um só, no primeiro ocultamento da página:
quem troca de aba no meio da leitura e volta tem o resto da visita não contado. E onde não
há `sendBeacon` a sessão inteira se perde — a alternativa seria uma requisição disputando a
saída do visitante com a navegação dele, e um agregado perdido é mais barato que uma saída
travada. As duas perdas são declaradas aqui e medidas no piso.

O quarto é que **os números do quadro e os do Google Analytics não vão bater**. Contam
universos diferentes — este conta sessões com consentimento que chegaram ao fim do
`visibilitychange`; o fornecedor conta o que a conta dele recebeu, com amostragem própria.
A tela diz que este resumo não substitui o relatório do fornecedor, e é por isso que ela diz.

O quinto é **superfície nova de escrita pública**: mais uma rota que aceita POST sem
autenticação. Ela paga o mesmo pedágio do endpoint de leads — schema fechado com recusa
nomeada, teto de tamanho, token efêmero assinado e o MESMO balde atômico —, e a reutilização
é deliberada: uma segunda implementação de limite de taxa seria a segunda a ficar para trás.

**Como reverter.** Desligar `f3base_comportamento.ligado` faz o navegador parar de enviar, a
rota recusar com 409 nomeado e o quadro dizer o que ligar — sem release, e sem tocar no envio
para a conta de medição. Desinstalar o plugin remove a tabela. Remover o desenho é outra
coisa: apagar o módulo reprova `comportamento.resumo_agregado` e `tela.resumo_de_comportamento`,
e apagar o envio do cliente reprova `js.resumo_da_sessao` em todos os tetos.

> **Superada na 1.0.0** — ver decisão nº 41.

---

## 21. A estratégia de carga do consentimento é decidida pela política, e não é fixa (origem: implantador 1.7.4, decisão nº 81)

**Decidido.** `F3Base_Modulo_Consentimento::estrategia_de_carga()` passa a decidir como o
script de consentimento é enfileirado, e quem decide é `consentimento.padrao`:
**pré-aprovado → `defer`**, fora do caminho crítico; **negado por padrão → BLOQUEANTE no
`<head>`**. Nos dois modos o script continua no cabeçalho — é a posição no documento que o
põe antes do carregador de tags do rodapé. **Não há chave de configuração para isso**: a
condição decide, como no resto do pacote. Pisos em
`consentimento.estrategia_pela_politica` e em `js.ordem_do_consentimento`.

**Por quê.** A justificativa que estava escrita no docblock era legítima e **incompleta**:
*"Precisa ser bloqueante e vir antes de qualquer tag: o `default` do Consent Mode só vale
se chegar antes do gtag.js."* O `gtag.js` **não é carregado pelo WordPress**. Quem o
injeta é `f3base-tracking.js`, que é `'strategy' => 'defer'` no rodapé
(`class-f3base-modulo-tracking.php`) e declara dependência do handle do consentimento. E
`defer` executa **depois do parse e na ordem do documento** — então o consentimento no
`<head>` continuaria rodando antes do carregador no rodapé sem bloquear o parser.

A hipótese foi **medida, não deduzida**, e o veredito tem duas metades.

**Confirmada para os dois scripts DESTE pacote.** `js.ordem_do_consentimento` roda os dois
clientes reais contra um escalonador que é o modelo da especificação e lê uma linha do
tempo. Com o consentimento **bloqueante**:

```
execucao:f3base-consentimento > consent-default > execucao:f3base-tracking > script-externo:f3base-gtag
```

Com o consentimento **adiado**, a linha do tempo é **idêntica**, caractere a caractere — e
é essa igualdade que a bancada afirma. O `default` continua chegando antes do `gtag.js`.
**Não há visita inicial rastreada sem consentimento no caminho padrão**, e o bloqueio não
estava comprando ordem nenhuma: estava comprando 5.085 bytes gzip no caminho crítico.

**Insuficiente contra quem não é nosso, e é isso que salva o outro modo.** `defer` ordena
`defer`; ele **não ordena `async`**. Um `gtag.js` de um plugin de console — a classe que
`plugins.emissor_concorrente` e `tracking.emissor_unico` já medem desde a 1.1.1 — ou um
snippet colado no cabeçalho executa antes de qualquer `defer` da página. Medido, no modo
opt-in com o consentimento adiado:

```
execucao:emissor-concorrente > script-externo:emissor-concorrente > page_view > execucao:f3base-consentimento > consent-default
```

O `page_view` sai vendo `ausente` — e ausência de `default` é, para o fornecedor, o mesmo
que `granted`. Com o consentimento bloqueante, o mesmo cenário mede
`consent-default` (denied) **antes** do `page_view`.

**A AUTORIZAÇÃO DO USUÁRIO, E POR QUE ELA NÃO SE APLICA NO MODO OPT-IN.** A autorização,
nas palavras de quem a deu: *"Estamos aceitando que quando o usuário entra no site, ele por
padrão está com a utilização dos cookies permitida. Podemos considerar que é aceitável que
o bloqueio dos cookies seja ativado somente após a página carregada, mesmo que isso acabe
rastreando uma visita inicial."* Ela descreve **o cenário de pré-aprovação** — e, medido,
naquele cenário **o custo autorizado não existe**: o `default` que chega é `granted`, que é
materialmente o que o gtag faz sem Consent Mode nenhum. Chegar tarde com `granted` não muda
o que foi enviado, e a bancada afirma as duas metades disso (o emissor concorrente chega
antes, E o default que chegaria é `granted`).

No modo de **negativa por padrão** a mesma permissividade custaria o primeiro `page_view`
com consentimento pleno de quem ainda não consentiu. Ela **não foi autorizada ali** —
foi autorizada descrevendo o outro regime —, e por isso não é aplicada ali.

**O GANHO MEDIDO, e o que continua no caminho crítico.** No modo padrão saem **5.085 bytes
gzip** (14.256 crus): o arquivo inteiro de `f3base-consentimento.js`, que era o **único**
script bloqueante do pacote. Continuam lá, nomeados: `fontes/tema/style.css`, **6.720
bytes gzip** (20.716 crus), que bloqueia a renderização como toda folha de estilo; e o
bloco de dados que `wp_localize_script` imprime antes do script, **831 bytes** de JSON
(450 gzip), inline no cabeçalho — atribuição de variável, sem ida à rede.
`f3base-leads.js` (7.769 gzip) e `f3base-tracking.js` (11.715 gzip) já estavam fora, no
rodapé e com `defer`.

**O PISO MEDE ORDEM DE EXECUÇÃO, NÃO A STRING DO ATRIBUTO**, e essa distinção é a metade
técnica desta decisão. Conferir `'strategy' => 'defer'` no enfileiramento responde outra
pergunta — a que interessa é se o `consent default` chegou ao `dataLayer` antes de o
`gtag.js` ser pedido. A bancada roda os arquivos e lê a linha do tempo; a única coisa ali
que não sai de um arquivo do pacote é o escalonador, e ele é o modelo da especificação, com
as três regras escritas no topo dele. Os pisos: **inverter a decisão** — `defer` no modo
opt-in — tem de aparecer como o primeiro `page_view` saindo antes do `denied`, nomeando
isso; e o carregador rodando antes do consentimento tem de aparecer como `gtag.js` pedido
sem `default` nenhum, com `permiteTags()` caindo na decisão de reserva do servidor. Do lado
do servidor, `consentimento.estrategia_pela_politica` tem o piso do **valor fixo** (as duas
políticas não podem devolver a mesma estratégia) e o do **interruptor** (mudar rodapé,
aviso e prazo não pode mexer nela).

**O que custa.** Três preços. O primeiro é que **o modo opt-in continua pagando os 5 KB**,
e agora paga por um motivo escrito no lugar onde a decisão acontece — o que é melhor que
pagar por um motivo que descrevia outro carregador, mas continua sendo o mesmo pagamento.

O segundo é que **a garantia do modo padrão passou a depender da especificação e do
WordPress**. `defer` preservar a ordem do documento é regra da plataforma; e o WordPress só
mantém `defer` num script cujos dependentes também sejam adiáveis — hoje o único dependente
é `f3base-tracking`, que é `defer`. Um plugin que pendure um script bloqueante sobre o
handle do consentimento faz o núcleo rebaixá-lo para bloqueante, o que é o erro seguro dos
dois; um plugin que enfileire um `gtag.js` próprio continua fora de qualquer ordem que este
pacote possa impor, e é por isso que `tracking.emissor_unico` existe.

O terceiro é de **cache de página**. Numa instalação opt-in com cache de HTML, uma página
gerada para quem tinha aceitado pode ser servida a quem não decidiu nada. O script continua
bloqueante ali justamente por isso: ele roda antes de qualquer coisa e o
`permiteTags()` do carregador encontra o objeto do consentimento já definido, em vez de cair
na decisão de reserva do servidor — que é o piso 2 desta checagem.

**Como reverter.** Devolver o literal ao enfileiramento — `array( 'in_footer' => false )` e
nada mais. `consentimento.estrategia_pela_politica` reprova em cinco asserções, entre elas
o teto do caminho crítico, que nomeia `f3base-consentimento` como o script que voltou a
bloquear o cabeçalho no modo padrão. Fazer o contrário — `defer` nos dois modos — reprova
em outras cinco, e o piso do opt-in nomeia o primeiro `page_view` saindo antes do `denied`.

---

## 22. A negativa tardia passa a alcançar Pixel e Insight Tag, e o que ela não desfaz fica escrito (origem: implantador 1.7.4, decisão nº 82)

**Decidido.** Os dois disparos de terceiro de `f3base-leads.js` — `fbq('track','Lead')` e
`lintrk('track')` — passam pelo mesmo `permiteTags()` que o carregador de tags usa, com a
mesma decisão de reserva (objeto ausente → o servidor já decidiu, e ele vale). O
`generate_lead` no `dataLayer` e a conversão do Google **continuam saindo**. A assimetria
passa a estar escrita em dois lugares que a pessoa lê: o **impacto** de
`f3base_consentimento.padrao` na tela e a **política de privacidade** do template. Piso em
`js.conversao_multicanal`.

**Por quê.** O roteiro desta release pedia para NOMEAR o que a negativa tardia não desfaz,
com a frase *"o que a negativa faz é impedir os envios seguintes"*. A medição do que o
código fazia contradiz a frase, e é por isso que o código mudou em vez de o texto: a
condição dos dois disparos era `typeof window.fbq === 'function'` e
`typeof window.lintrk === 'function'` — **a presença da função**, que continua verdadeira
depois da recusa, porque negar não descarrega script nenhum. Sob a política pré-aprovada
isso significa que quem chegasse, fosse medido, abrisse o controle do rodapé e recusasse
**continuava mandando `Lead` à Meta e `track` ao LinkedIn a cada clique no CTA**. A bancada
mediu 1 e 1 sobre o código da 1.1.4, e é esse o piso que ficou escrito nela.

Escrever na política de privacidade que os envios seguintes são impedidos, com o código
fazendo o contrário, seria exatamente o defeito que a decisão 44 existe para impedir —
afirmação de documento refutada pelo código dentro do mesmo zip.

**O QUE FICA DE PÉ, E É DO FORNECEDOR.** Três coisas foram medidas e continuam verdadeiras,
e a política as descreve como mecanismo, nunca como promessa jurídica:

- **GA4 e Google Ads têm `consent update`.** A negativa vale do clique em diante; o que já
  foi enviado **permanece com o Google**. É o que o Consent Mode faz, e está correto.
- **Pixel e Insight Tag não têm equivalente.** Se o arquivo já carregou, ele **fica na
  página** até a navegação seguinte. Nada — nem este pacote nem ninguém — descarrega
  arquivo já carregado.
- **Na navegação seguinte eles não voltam.** `permite_tags()` no servidor decide o
  enfileiramento, e com a decisão gravada em `denied` o carregador não vai ao HTML.

**POR QUE O `generate_lead` CONTINUA SAINDO.** Calar o `dataLayer` na negativa seria decidir
duas vezes a mesma coisa, e a segunda vez sem mecanismo: quem decide o que o Google faz com
o evento depois do `denied` é o Consent Mode, que já recebeu o `update`. E o registro do
lead **no próprio site** também continua: recusar medição não é recusar o contato, e o
`consentimento: false` viaja no registro como sempre viajou.

**O que custa.** Dois preços. O primeiro é que a conversão de campanha **deixa de ser
contada** para quem recusou depois de ter sido medido — o que é o comportamento correto e
é, ainda assim, uma perda de dado que alguém vai notar no relatório do fornecedor sem
saber de onde veio; está escrito aqui e no impacto do campo. O segundo é que `permiteTags()`
passou a existir em **dois arquivos de cliente**, com a mesma semântica escrita duas vezes.
A alternativa era o de leads chamar o do tracking, e ela é pior: o arquivo de leads é
enfileirado sem depender do de tracking — o CTA existe em site sem medição nenhuma —, e
uma chamada cruzada criaria uma dependência que o enfileiramento não declara.

**Como reverter.** Tirar o `if (!permiteTags())` de `converter()`.
`js.conversao_multicanal` reprova no piso da negativa tardia, dizendo quantos envios
saíram para cada um dos dois canais depois da recusa.

---

## 23. O vocabulário passa a ser um só, e o cruzamento é o que torna duas fontes seguras (origem: implantador 1.7.4, decisão nº 89)

**Decidido.** `F3Base_Vocabulario` passou a existir: classe sem pai e sem dependência que
viaja dentro do `site-core` e que o implantador alcança pela cópia de origem, exatamente
como `F3Base_Chaves_Seo`. Ela guarda o CONJUNTO de valores que os dois runtimes
reconhecem — modelos de atribuição, modos da lista do `llms.txt`, políticas de frame, COOP,
referrer e permissões, e o slug do plugin de cada papel. Oito literais distintos saíram de
oito arquivos do `site-core`, em dezesseis ocorrências.

**Qual era o defeito.** O implantador ESCOLHE, no catálogo; o `site-core` RECONHECE, no
sanitizador e no módulo. Enquanto os dois lados escreviam o mesmo literal cada um por sua
conta, eles concordavam por COINCIDÊNCIA: o catálogo podia trocar de modelo de atribuição
e o sanitizador continuaria devolvendo o antigo como padrão; o plugin de SEO podia trocar
no catálogo e o módulo de noindex continuaria procurando o slug antigo. Nada quebra nesses
casos — é essa a parte ruim. A medição some, a exclusão nunca dispara, e a única evidência
é um número que não aparece no relatório de ninguém.

**O que torna duas fontes seguras não é uni-las: é cruzá-las.** O `site-core` não pode ler
`config/decisoes.tsv` — ele não viaja com o catálogo —, então o slug precisa estar na
classe. O que impede a divergência é `decisoes.fonte_unica` exigir que toda decisão que o
vocabulário governa valha um dos valores que ele declara, e que todo papel que ele fixa
ache no catálogo uma entrada com exatamente aquele slug. A classe declara o que governa em
`decisoes_governadas()` e `papeis_governados()`, e é por esse mapa que a checagem cruza —
sem uma segunda lista, que seria o mesmo problema com outro nome.

**O JavaScript recebe o token em vez de escrevê-lo.** `f3base-leads.js` comparava o modelo
de atribuição com o literal `'first-touch'`, numa linguagem onde nenhuma constante do PHP
alcança. Agora o token viaja no objeto localizado, e o script compara o que recebeu com o
que recebeu. Sem token, nada é primeiro toque — o lado seguro, em que a atribuição
sobrescreve e nenhuma origem é inventada.

**Um defeito grave descoberto pelo próprio piso.** Todo arquivo de origem do `site-core`
abre com `if ( ! defined( 'ABSPATH' ) ) { exit; }`. Num processo de linha de comando sem a
constante, esse `exit` **não lança exceção e não imprime nada**: encerra o processo inteiro
com status ZERO, no meio da rodada. Quando o cruzamento nasceu, a suíte e o piso passaram a
parar calados na checagem anterior à que carrega a classe — saída sem resumo, sem erro e
sem FALHA, e o `grep` por FALHA voltava vazio como se tudo estivesse bem. Sucesso
silencioso pela metade é pior que falha barulhenta. O carregador define a constante antes
do `require`, e o comentário no lugar existe para a próxima classe compartilhada não
repetir o caminho.

**A varredura dos pisos amarrados a valor de projeto**, feita depois do achado de
`preflight.artefato_do_pacote_e_baseline`. Quatro casos, todos corrigidos:
`config.schema_valida` fixava a ESCOLHA de `cabecalhos.hsts` em vez de provar de onde o
valor veio; `projeto.schema_valida` fixava o fuso do template, e um template entregue a
cliente em outro fuso reprovaria a suíte sem defeito nenhum; `plugins.https_em_todo_salto`
partia da URL da entrada de índice 2 do catálogo, e uma reordenação exercitaria a cadeia a
partir de string vazia; e `plugins.autoupdate_caminho_separado` montava o caso do plugin
operacional lendo o arquivo do projeto — que nasce vazio, de modo que a regra deixara de
ser exercitada sem que nada dissesse isso. Os quatro passaram a declarar os próprios dados
ou a medir a FORMA em vez do valor.

**O que custa.** Uma classe a mais no `site-core` e um cruzamento a mais na checagem. E
cria uma dependência de carga: quem monta o catálogo de options precisa da classe antes,
o que já custou uma sonda morrendo por classe não encontrada.

**Como reverter.** Os literais voltam para cada arquivo do `site-core`, a classe sai, e o
cruzamento sai de `decisoes.fonte_unica` com ela. O que NÃO volta é o literal no
JavaScript: o token localizado é mais barato que a duplicação, mesmo sem a classe.

---

## 24. A seção entra e sai pela MESMA linha, e a bancada ganha geometria (origem: implantador 1.7.4, decisão nº 90)

**Decidido.** O observador de seções passa a ser armado com os thresholds `[0, visivel]` e a
decidir por `entrada.intersectionRatio >= visivel` — a mesma linha declarada nos dois
sentidos. `isIntersecting === false` continua valendo como saída, porque é assim que chega o
alvo removido da árvore. E a bancada de comportamento da suíte ganha GEOMETRIA: cada seção do
documento falso tem topo e altura, `rolarAte()` calcula a razão de interseção contra a janela
e entrega o retorno do observador a quem mudou de faixa de threshold ou de estado de
sobreposição — que é o que o navegador faz.

**Qual era o defeito.** A ENTRADA e a SAÍDA usavam linhas DIFERENTES. Entrava-se quando a
razão cruzava `visivel` (0,5) para cima, que é o threshold declarado; só se saía quando
`isIntersecting` virava falso, que na especificação é razão ZERO. Quando a razão cai de 0,6
para 0,4 o navegador DISPARA o retorno — o índice de threshold mudou de 1 para 0 —, mas
`isIntersecting` continua VERDADEIRO, porque ainda há sobreposição. O código caía em
`if (dentroDaVista[secao]) continue;` e não rearmava. A seção só voltava a contar se saísse
INTEIRA da tela, o que em página curta não acontece nunca.

O resultado medido em produção, em `wp_2zsugm_f3base_eventos`: **80 linhas, todas com
`ocorrencia = 1`, nenhuma reentrada em nenhuma visita**. A coluna "vez" da tela existia, a
tabela tinha o dado, e o dado era sempre 1 — a releitura de bloco, que é a pergunta inteira
que a 1.2.1 foi feita para responder, não existia.

**POR QUE ISSO SOBREVIVEU: a bancada era mais fácil que o mundo.** `bancadaDeComportamento`
expunha `verSecao(i)` e `esconderSecao(i)`, que disparavam `{ isIntersecting: true|false }` À
MÃO — sem razão de interseção e sem nenhuma relação com a posição de rolagem. `rolarAte(95)`
não movia seção nenhuma. O retorno intermediário do navegador — `isIntersecting: true` com
razão 0,4 — nunca era produzido, e por isso a bancada aprovou um rearme que o navegador quase
nunca alcança. Uma bancada que só sabe dizer "entrou" e "saiu" não pode reprovar um código
que erra exatamente entre os dois.

O conserto da bancada é METADE do trabalho, e não um detalhe: sem ele, o conserto do cliente
seria uma afirmação sem medida. A geometria padrão são faixas iguais ao longo do documento,
com a seção nunca mais alta que a janela — uma seção de duas telas jamais alcançaria meia
seção visível, e a bancada padrão passaria a medir o caso em que nada dispara. Quem precisa
de layout específico declara `geometria`. `verSecao`/`esconderSecao` continuam existindo para
os testes que só precisam do bloco entrando e saindo; o que não pode mais acontecer é um
teste de RELEITURA ser dirigido por eles.

**O PISO NOVO, em `js.sessao_com_releitura`.** Um ciclo dirigido só por `rolarAte` — desce até
o fim, volta ao topo e desce de novo — numa página curta de duas telas, em que dois dos três
blocos NUNCA saem inteiros do campo de visão. Ele exige `ocorrencia` 1 e 2 para os três blocos
e para os quatro marcos. E planta a MUTAÇÃO correspondente: o código de hoje — `threshold:
visivel` com a saída decidida por `isIntersecting` — tem de deixar os dois blocos presos numa
ocorrência só. Sem essa mutação o piso não provaria nada, porque foi exatamente esse código
que passou na bancada anterior. O terceiro bloco, que SAI inteiro da tela, continua sendo
registrado duas vezes no mutante — é o caso fácil, o único que o código antigo acertava, e ele
fica no piso para separar a assimetria de um defeito qualquer.

**O que custa.** Três preços.

O primeiro é **mais retornos de observador no navegador do visitante**: com dois thresholds,
o navegador avisa na entrada, na saída e na travessia da linha, em vez de só na travessia. É
trabalho pago por quem visita, e ele é pequeno perto do que já se paga por observar as seções.

O segundo é **mais linhas no registro detalhado**. Uma visita que sobe e desce numa página
curta passa a gravar cada passagem, e o teto por sessão — que agora vale 20, e não 6 — é o que
segura isso. O agregado continua contando uma vez por carregamento: as duas leituras convivem
de propósito.

O terceiro é que a **entrada sintética precisa de tratamento**. `intersectionRatio` pode vir
`undefined` — em bancada, em polyfill —, e tratar a ausência como zero rearmaria a seção a
cada retorno, fazendo contar duas vezes quem hoje conta uma. A ausência é tratada como
`isIntersecting ? visivel : 0`, que preserva o comportamento antigo exatamente onde não há
razão a ler.

**Como reverter.** Voltar `{ threshold: visivel }` e a decisão por `isIntersecting` reprova
`js.sessao_com_releitura` em dois tetos, com a frase do caso real. Tirar a geometria da
bancada faz o piso da assimetria não encontrar o defeito e reprovar por conta própria — a
reversão é possível e não é silenciosa.

---

## 25. A fronteira do marco ganha banda, e a declaração passa a defender o número que declara (origem: implantador 1.7.4, decisão nº 91)

**Decidido.** `histerese_pp=5` entra no limiar da `rolagem` em
`fontes/site-core/dados/eventos-comportamento.tsv`, e o marco só rearma abaixo de
`marco - histerese_pp` — nunca na própria linha. E o motivo escrito na declaração passa a
defender `travessias_por_sessao=20`, que é o que ela sempre declarou; o padrão de reserva do
cliente, que valia 6, passa a valer 20.

**Qual era o defeito, nas duas metades.**

A primeira é o FLAPPING. `instrumentarRolagem` rearmava `dentro[marco]` no instante em que o
percentual caía abaixo do marco. Um tremor de um pixel na fronteira — o dedo que segura a
página, o cabeçalho que recolhe, a imagem que entra e empurra a altura do documento — fabrica
uma travessia que ninguém fez, e ela chega ao relatório com cara de releitura. Fronteira sem
banda transforma tremor em leitura. Cinco pontos porque é muito mais que o tremor (na altura
de uma página comum, um pixel não chega a um décimo de ponto, e um cabeçalho que recolhe fica
na casa de três) e muito menos que o menor vão entre dois marcos, que é quinze: uma banda
maior que o vão engoliria a travessia do marco vizinho.

**Para a SEÇÃO não há um segundo número, e isso é decisão e não esquecimento.** A banda
`[0, visivel]` do observador já É a histerese: a folga entre a razão zero e o limiar declarado
é exatamente o que separa a entrada da saída. Um `histerese_pp` para a interseção seria um
número que ninguém revisaria junto com o `visivel` que ele protege.

A segunda metade é a DECLARAÇÃO QUE DISCORDAVA DO PRÓPRIO MOTIVO. O TSV declarava
`travessias_por_sessao=20` na `rolagem` e na `interseccao`, e o motivo ao lado argumentava
*"Seis porque duas ou tres releituras sao leitura de verdade e a partir da sexta o padrao ja
esta estabelecido"*. O cliente, por sua vez, usava 6 como padrão de reserva. Três respostas
para o mesmo teto, e a mais visível — o motivo — defendia justamente a que a declaração não
usava. Ficou 20, que é o pedido literal de quem encomendou a coluna: TODOS os acionamentos,
inclusive do mesmo visitante na mesma visita. O motivo foi reescrito para defender 20, e a
reserva do cliente subiu para 20, porque reserva menor que a declaração aperta o teto em
silêncio no dia em que o arquivo se corromper.

**O que custa.** A banda tem um preço real: uma travessia curta e legítima — o visitante que
sobe três pontos percentuais e desce de novo — deixa de ser contada. É o lado certo de errar:
travessia perdida é um número menor, travessia fabricada é um número que descreve um
comportamento que não houve. E o teto em 20 é mais linha no registro detalhado por visita
inquieta, cortada pelo mesmo excedente somado que já existia.

**Como reverter.** Tirar `histerese_pp` da declaração faz o cliente cair no padrão de reserva
`0`, que é o comportamento antigo — e reprova `js.sessao_com_releitura` no teto da declaração,
que exige a banda declarada. Baixar o teto é editar uma coluna do TSV, sem release.

> **Superada na 1.0.0** — ver decisão nº 47.

---

## 26. O desligamento da medição vira encontrável, e não ganha chave nova (origem: implantador 1.7.4, decisão nº 92)

**Decidido.** O menu **Medição** passa a dizer, ANTES de qualquer número, onde a medição se
desliga e o que o desligamento faz, com link para a tela de configuração e âncora no próprio
campo. Com `f3base_comportamento.ligado` falso, a PRIMEIRA coisa da tela é a frase do
desligamento. Nenhuma chave nova foi criada.

**Por quê.** O pedido, nas palavras de quem o fez: *"Permita também que essa medição possa ser
desativada na área de configuração do plugin."* A medição da resposta, antes de respondê-la: a
chave JÁ EXISTIA — `f3base_comportamento.ligado`, na seção de privacidade, honrada em três
pontos de `class-f3base-modulo-comportamento.php`. Criar um interruptor novo seria duplicar
uma decisão que já tem lugar, e a regra 29 proíbe exatamente isso: duas chaves para "esta
instalação mede?" divergem na primeira vez que alguém mexer numa e não na outra, e o site
passa a ter duas respostas para a mesma pergunta.

O que faltava não era o controle: era ele ser ENCONTRÁVEL. Quem abre a tela Medição não tem
por que saber que a chave que a desliga mora na tela ao lado, embaixo de um título sobre
privacidade. E, desligada, a tela mostrava o desligamento no MEIO de uma lista, depois do
parágrafo de abertura: o que o operador via primeiro era uma tela sem número nenhum — que é
indistinguível de um site sem visita.

**A ÂNCORA TEM PRODUTOR ÚNICO.** O `id` do sub-campo saiu de literal montado dentro de
`render_subcampo()` e virou `F3Base_Admin_Tela::id_do_subcampo()`. Montado como literal nos
dois lugares, ele concordaria por coincidência: renomear a option ou a chave manteria o link
existindo e o faria deixar de levar a lugar nenhum, sem erro e sem nada acusando. O piso
cruza os dois lados — a tela Medição aponta para uma âncora, e a tela de configuração precisa
ter um campo com aquele `id`.

**O que custa.** Um parágrafo a mais no topo de uma tela que já era longa, e ele aparece
também quando está tudo funcionando — que é o caso comum. É o preço de o controle ser
encontrável antes de alguém precisar dele: uma frase que só aparecesse com a medição
desligada ensinaria onde desligar só a quem já tivesse desligado.

**Como reverter.** Tirar a linha do topo reprova `medicao.menu_proprio` no teto do controle
encontrável, e tirar a frase do desligamento reprova o piso do desligamento nomeado, que mede
a posição dela em relação ao primeiro quadro da tela.

---

## 27. O contador de travessias sai do carregamento e passa a viver na visita (origem: implantador 1.7.4, decisão nº 93)

**Decidido.** O contador de travessias — o número que vira a coluna **vez** da tabela bruta —
deixa de ser variável do carregamento e passa a morar no registro da VISITA, no
`localStorage`, sob a mesma chave `f3base_sessao` que já atravessa páginas. A chave de cada
contador é `caminho | gatilho | detalhe`. O total de **cortadas** vai junto, pelo mesmo
motivo. O estado ARMADO — `dentro`, dos marcos, e `dentroDaVista`, das seções — continua
sendo do carregamento, e isso é decisão, não esquecimento. O agregado continua contando uma
vez por carregamento. Nenhum número mudou de valor: `travessias_por_sessao` continua 20.

**Qual era o defeito, e como ele foi medido.** A pergunta de quem opera: *"ao navegar no
site, as triggers só estão sendo gravadas na primeira vez que eu passo. É possível gravar
todas as vezes que eu passo por um bloco na mesma visita?"*

Site `fator3-teste-mcp-1`, tabela `wp_2zsugm_f3base_eventos`, visita
`8bb0a2d5528a9336111ca5be06178284`, já com o conserto da 1.3.3 aplicado. Dois carregamentos
de `/` na MESMA visita, 34 segundos entre eles:

| Carregamento | Bloco `pecas` | Marco de 25% |
|---|---|---|
| A (`f3base_pagina_vista` em ms 1057) | oc 1 em ms 10378, **oc 2** em ms 24911 | oc 1 em ms 10412, **oc 2** em ms 25228 |
| B (`f3base_pagina_vista` em ms 865) | oc **1** em ms 8329 | oc **1** em ms 8329 |

O rearme da 1.3.3 funciona: dentro do carregamento A a segunda passagem apareceu como
segunda. O que estava errado era o CONTADOR. `travessias`, `travessiasDaSecao`, `dentro`,
`dentroDaVista` e `cortadasNaVisita` eram variáveis do carregamento: nasciam zeradas a cada
página e morriam na navegação. O visitante que passa pelo bloco `pecas`, vai para
`/arquitetura/` e volta é registrado três vezes como se fosse a primeira.

E o limiar se chama `travessias_por_SESSAO`. O nome prometia visita e a implementação
entregava carregamento — **uma declaração que mente sobre o que mede é pior que um número
errado, porque ninguém vai conferir.**

**Por que a chave inclui o CAMINHO.** `pecas` em `/` e `pecas` em `/arquitetura/` são seções
diferentes com o mesmo nome. Somá-las responderia uma pergunta que ninguém fez — *"quantas
vezes este NOME de bloco foi visto no site inteiro?"* — e esconderia as duas, porque nenhuma
das duas páginas teria mais a própria contagem. A chave `caminho | gatilho | detalhe` é a
mesma granularidade que a tabela do servidor já usa para somar, e é a mesma pela qual o
operador filtra.

**Por que o estado ARMADO não persiste, e por que essa é a metade que quebra se for feita
errado.** Uma página nova começa com nada em vista e nada rolado. Persistir "já estou dentro"
junto com o contador — que é o erro natural de quem faz o conserto pela metade — faria a
primeira entrada do carregamento seguinte ser engolida: o bloco que já está no topo da página
para a qual o visitante acabou de navegar não produziria linha nenhuma, e ele perderia
justamente a passagem que acabou de fazer. Trocaria um defeito por outro, com o agravante de
o segundo ser mais difícil de ver — uma linha a menos não chama atenção como uma linha
errada. Persiste o CONTADOR; o armado nasce zerado a cada carregamento, e o piso 4 de
`js.sessao_com_releitura` existe só para isso.

**O que o agregado NÃO passa a fazer.** `emitir()`, `vistos` e `vistas` continuam uma vez por
carregamento. O total do painel responde *"quantas visitas viram este bloco"*; a tabela
responde *"quantas vezes cada uma passou"*. Somar releitura no agregado inventaria audiência
que não existe, e as duas leituras convivem de propósito desde a 1.2.1.

**Uma assimetria consertada de passagem.** O coletor de rolagem somava a travessia acima do
teto num mapa `excedentes` que ninguém lia e que não viajava para lugar nenhum, enquanto o
coletor de seções, ao lado, já somava em `cortadasNaVisita` — que sai NOMEADA no corpo. O
comentário ao lado do `excedentes` prometia que *"a última linha registrada daquele marco
carrega quantas travessias houve"*, e a última linha registrada carregava o TETO, nunca o
total: era corte silencioso com cara de contabilidade. As duas travessias que estouram teto
agora contam no mesmo lugar, e o piso 5 mede o excedente saindo nomeado.

**O teto do mapa é `maximoVisita`, e não um número novo.** O mapa existe para servir o
registro, e o registro tem orçamento de `maximoVisita` linhas na visita inteira (200,
`F3Base_Modulo_Comportamento::MAX_POR_VISITA`). Uma chave além desse orçamento é
armazenamento gasto no aparelho de alguém para contar uma passagem que nunca virará linha.
Passando do teto, a passagem conta em cortadas e não cria chave nova. Escrever `200` dentro
do JavaScript daria dois números para revisar onde há uma decisão só, e é a mesma regra que
mantém todo limiar deste coletor fora do cliente.

**O que custa.** Três coisas, e as três estão medidas.

A primeira é ESCRITA NO NAVEGADOR: o registro da visita é regravado a cada travessia contada,
e não mais só a cada linha registrada. É uma gravação de poucas centenas de bytes por
travessia, e a travessia já é limitada pela banda de histerese e pela geometria — nenhum gesto
humano produz rajada aqui. A gravação acontece na hora de propósito: a saída de página não é
um instante confiável, e travessia contada só na memória é travessia perdida na navegação.

A segunda é DADO A MAIS NO APARELHO DO VISITANTE. O registro da visita ganhou dois campos, e o
piso do identificador em `js.resumo_da_sessao` passou a exigir a forma de cada chave do mapa:
`caminho|gatilho|detalhe`, com o detalhe pelo mesmo alfabeto fechado do payload. Nenhum texto
livre, nenhuma query, nenhuma mensagem de erro. O caminho é o de uma página deste site — que o
histórico do próprio navegador já tem — e o registro inteiro é removido do aparelho na recusa,
pela mesma chamada que remove o apelido.

A terceira é a SÉRIE HISTÓRICA. A coluna `ocorrencia` das linhas gravadas antes desta release
conta carregamento; as de agora contam visita. Um agente comparando períodos vai ver a
ocorrência média subir sem que o comportamento tenha mudado. Não há migração possível — o dado
antigo não guarda de qual carregamento cada linha veio —, e por isso a tela Medição passou a
declarar, em português comum e antes da tabela, sobre que janela a coluna conta.

**Como reverter.** Fazer `travessiasDaVisita` nascer vazio em `carregar()` devolve o
comportamento de 1.3.3 — e reprova `js.sessao_com_releitura` no teto da travessia entre
carregamentos, que é a mutação plantada. Tirar os dois campos do registro guardado reprova o
piso do identificador em `js.resumo_da_sessao`, que declara o conjunto EXATO de campos.
Reverter não apaga o que já foi gravado no servidor: as linhas com ocorrência de visita
continuam lá, e a série passa a ter três regimes em vez de dois.

---

## 28. O contador e a linha passam a ter a MESMA durabilidade (origem: implantador 1.7.4, decisão nº 94)

**Decidido.** O envio do resumo passa a CONFIRMAR a entrega — `fetch` com `keepalive`, e o
lote só é esquecido com resposta 2xx —, e a linha passa a ser tão durável quanto o contador:
o acumulado ainda não selado e os lotes já selados moram no `localStorage`, dentro do registro
da visita, ao lado do contador. Cada lote leva um SELO sorteado, e o servidor recusa um selo
que já gravou para a mesma visita respondendo 2xx assim mesmo. Sem `keepalive`, o envio
continua acontecendo por `sendBeacon` — degradado e declarado. O corte deixa de morrer na
resposta da rota e passa a ser gravado, e a tela Medição o mostra.

**Qual era o defeito, e como ele foi medido.** A pergunta de quem opera: *"os gatilhos estão
aparecendo mais de uma vez, mas alguns estão sendo perdidos."*

Site `fator3-teste-mcp-1`, tabela `wp_2zsugm_f3base_eventos`, visita
`8cac18da62ed056004242bee737457db`, já com a 1.3.4 instalada. UM único carregamento de `/`
— um só `f3base_pagina_vista`, em ms 984. As linhas que chegaram, por lote:

| Lote | Linhas, por `ms` |
|---|---|
| 1 (16:17:40) | 984 `pagina_vista` · 1746 `abertura` oc1 · 2658 LCP, CLS, TTFB |
| 2 (16:17:49) | 10087 `pecas` oc1 · 10504 `rolagem25` oc1 |
| 3 (16:18:05) | 24780 `pecas` oc2 · 24813 `rolagem25` oc2 · 25080 `comando-unico` oc1 · 25113 `rolagem50` oc1 · 26063 `rolagem75` oc1 · 26080 `faq` oc1 |
| 4 (16:19:02) | 79925 `comando-unico` **oc3** · 79958 `rolagem50` oc2 · 81525 `rolagem75` oc2 · 81542 `faq` oc2 · 81592 `rolagem90` oc1 |

`comando-unico` pula de 1 para 3. Todos os outros gatilhos são contínuos. Entre os ms 26080 e
79925 o visitante SUBIU a página: a subida faz `comando-unico` reentrar em vista — uma
ocorrência — e não dispara marco nenhum, porque marco só conta na descida. O lote despachado
naquele instante tinha UMA linha só, e é essa que sumiu.

**A causa, e ela é da 1.3.4.** Ali o CONTADOR virou durável e a LINHA ficou volátil.
`contarTravessia()` incrementa e grava no `localStorage` na hora; a linha vai para
`registroDaSessao`, que é memória do carregamento; e `enviarResumo()` limpava esse registro
quando `sendBeacon` devolvia `true`.

**E `sendBeacon` devolvendo `true` significa ENFILEIRADO, nunca ENTREGUE.** A especificação é
explícita: o retorno diz que o agente de usuário aceitou a carga para transferência. Se a
requisição morre depois disso — rede caindo, servidor respondendo erro, aba encerrada antes de
o envio sair —, nada avisa a página, e as linhas já foram jogadas fora.

Resultado: qualquer lote que não chega avança o contador sem produzir linha. Antes da 1.3.4
isso perdia linhas em silêncio; depois dela o buraco na sequência de `ocorrencia` tornou a
perda VISÍVEL, que é exatamente o que o operador viu.

**O invariante quebrado é o nome do conserto: numa visita, as ocorrências de um mesmo gatilho
no mesmo caminho formam uma sequência SEM BURACOS. Qualquer mecanismo que avance o contador
sem produzir linha reprova.**

### As quatro metades, e por que nenhuma delas fecha sozinha

**A. Confirmar a entrega, em vez de confiar no enfileiramento.** O despacho é
`fetch(endpoint, { method: 'POST', keepalive: true, … })`, que sobrevive ao descarregamento da
página como o beacon e, ao contrário dele, DEVOLVE resposta. O acumulado é limpo só com 2xx.
`keepalive` é o discriminante, e não `fetch`: um navegador com `fetch` e sem `keepalive`
cancelaria a requisição na saída, que é pior que o beacon.

**B. Tornar a linha tão durável quanto o contador.** O registro da visita ganhou dois campos,
e eles **não são redundância**: cada um segura um caso que o outro não alcança.

- `acumulado` é o que ainda não foi selado, com o CAMINHO a que pertence. Ele socorre a página
  que morre **sem ter selado nada** — a aba encerrada pelo sistema, o aparelho sem memória, o
  navegador descartando a página. `pagehide` não é promessa, e um lote selado só na saída
  nunca chega a ser selado.
- `pendentes` é a fila de lotes selados e ainda não confirmados. Ela socorre a página que
  morre **depois** de selar: ocultou, o lote foi selado e despachado, o servidor recusou de
  forma transitória, e só então a aba foi encerrada. Nesse instante o `acumulado` está VAZIO —
  ele foi selado —, e quem segura as linhas é a fila, e só ela.

A distinção não é teórica: ela é o que os dois pisos medem separadamente, e é por isso que as
duas mutações são plantadas **isoladas**. Uma mutação que apagasse os dois campos de uma vez
derrubaria os dois cenários e não diria qual campo responde por qual — seria um piso que só
sabe falhar quando dois defeitos acontecem juntos, e um piso assim não prova nenhum dos dois.
Com elas separadas, apagar a gravação do acumulado derruba só o primeiro cenário e apagar a
gravação da fila derruba só o segundo.

A metade A sozinha não fecha, porque a página pode morrer entre contar e enviar; a metade B
sozinha não fecha, porque o beacon aceito-e-perdido limparia o pendente do mesmo jeito.

**O acumulado herdado é SELADO na carga seguinte, e não continuado.** Ele pertence ao caminho
da página que morreu, e o carregamento corrente pode ser de outra: continuá-lo faria linhas de
`/` serem gravadas como se tivessem acontecido em `/arquitetura/`, sem erro nenhum e com a
tabela parecendo certa. E a retentativa acontece NA CARGA, não no próximo ocultamento —
esperar pelo ocultamento faria a recuperação depender de o visitante produzir mais uma saída
de página, e o carregamento que acabou de morrer é justamente a prova de que a saída é o que
não se pode contar.

**C. Reenvio não pode duplicar.** Confirmar implica reenviar, e reenviar sem identificador
conta duas vezes. Cada lote leva um SELO sorteado de 32 hexadecimais — a mesma forma fechada
dos apelidos, e pela mesma razão. O servidor recusa um selo que já gravou para a mesma visita
e responde **2xx assim mesmo**: para quem envia, *"já tenho isto"* e *"acabei de gravar"*
precisam ser a mesma resposta boa, porque qualquer outro status faria o cliente reter e
reenviar para sempre justamente o lote que o servidor já tem.

**O lote é SELADO, e selado significa IMUTÁVEL.** Atividade nova forma um lote novo: um lote
que crescesse mantendo o selo teria o crescimento recusado como repetição e descartado pelo
próprio 2xx, e as linhas acrescentadas sumiriam sem que nada acusasse. É por isso que o
pendente é uma FILA, e não um lote só.

**O mecanismo do selo é o MESMO da reserva de deduplicação do lead** — decisão 35 —, e pelas
três etapas dele: inserção atômica na chave única, confirmação depois da persistência e
compensação quando nada foi gravado. Uma marca simples não bastaria: marcando o selo e
gravando em seguida, uma escrita que FALHA deixaria o selo queimado, a retentativa receberia
"já gravei isto", o cliente esqueceria o lote e as linhas sumiriam — o mesmo buraco de
sequência que esta release existe para fechar, agora vindo do próprio conserto. Uma segunda
implementação seria uma segunda regra para o mesmo risco, e a segunda é a que fica para trás.
O prazo virou parâmetro de `reservar()` porque trinta dias é o prazo do LEAD: um lote de
medição vive o tempo de uma visita.

**A janela do selo é a MESMA da visita, e as duas pontas leem a mesma declaração.**
`inatividade_min` responde, dos dois lados, à mesma pergunta — até quando duas coisas ainda são
a mesma visita. No navegador ela decide se o carregamento continua a visita e se um lote
pendente ainda é retentativa; no servidor, por quanto tempo o selo é lembrado. Um número
escrito de um lado divergiria do outro na primeira vez que alguém mexesse num só, e a
divergência apareceria como linha contada duas vezes: o cliente reenviando um lote cujo selo o
servidor já esqueceu.

**D. Orçamento do que fica pendente, e ele NÃO é número novo.** Toda linha que entra num lote
passou por `registrar()`, que já gasta o teto de `maximoVisita` da VISITA inteira — que
atravessa carregamentos desde a 1.3.0. A fila é, por construção, um subconjunto desse
orçamento: uma visita não consegue deixar pendente mais do que ela podia registrar. O
excedente conta em CORTADAS, como já contava. Armazenamento bloqueado ou recusado degrada para
o comportamento de hoje — pendente só em memória, e o carregamento que morre o perde —, e é a
mesma degradação declarada do contador.

### O caminho de reserva, e a perda que ele mantém

Sem `fetch` com `keepalive`, o despacho continua por `sendBeacon`. Nesse caminho o lote
enfileirado-e-perdido continua sendo perda, **porque não há como saber** — o lote é esquecido
sobre o enfileiramento, e reter o que não se pode confirmar seria uma fila que nunca drena.

O que ele ganha de qualquer forma são as outras duas metades: o pendente é GRAVADO antes do
despacho, então a página que morre antes de o envio sair não perde nada, e o selo impede que a
retentativa do carregamento seguinte conte duas vezes. **Um conserto que só funcionasse no
navegador moderno e emudecesse o antigo seria pior que o defeito**, porque o site pararia de
medir uma fatia inteira do público sem que nada acusasse: tela vazia e tela sem visitante são
a mesma tela.

### Recusa transitória e recusa permanente, e por que a distinção teve de existir

O pedido era reter em qualquer coisa que não fosse 2xx. Reter sem critério tem um preço que só
aparece depois: **um corpo que o servidor nunca vai aceitar fica na fila para sempre e bloqueia
atrás dele tudo o que veio depois** — o pendente eterno é a forma que a perda assume quando se
retém sem separar.

A lista de permanentes é curta e é sobre o CORPO: **400** (schema fechado — campo desconhecido,
detalhe fora do alfabeto, caminho com query, gatilho não declarado) e **413** (teto de
tamanho). Nenhum dos dois muda por esperar. Nesses dois casos as linhas contam em CORTADAS
nomeadas, e não somem em silêncio. Tudo o mais é transitório e o lote fica: rede caindo, 403 de
token expirado — o carregamento seguinte leva um fresco, e é por isso que o token NÃO viaja
selado dentro do lote —, 409 de medição desligada, 429 de balde cheio, 503 de migração em
curso, 5xx do servidor.

E o 413 ficou improvável por construção, em vez de só declarado: **o teto de corpo do endpoint
passou a ser publicado ao cliente** (`maximoBytes`), e o selamento parte o registro em quantos
lotes forem precisos para caber nele. A partição acontece no SELAMENTO e nunca no despacho —
partir um lote já selado mudaria o conteúdo sob o mesmo selo. Escrito no cliente, o número
seria uma segunda verdade sobre o mesmo limite, divergindo no dia em que alguém mexesse no do
endpoint.

### Os dois amplificadores medidos, e o que mudou em cada um

**O 503 da migração.** `garantir_estrutura()` punha o transiente
`f3base_comportamento_migrando` por **quinze minutos** e a rota respondia 503 enquanto a
estrutura não estivesse pronta. `set_transient()` devolve `false` quando o valor gravado é o
mesmo que já estava lá, e era por essa devolução que a função saía cedo: um `dbDelta` que
falhasse punha o site em quinze minutos de 503 **sem uma única nova tentativa no meio**. O
transiente foi medido vivo neste site. Com o cliente descartando cada lote recusado, isso era
perda garantida com o contador andando o tempo todo.

Ficou **um minuto**, e a trava mudou de natureza: ela é trava da TENTATIVA, e não espera pelo
fracasso. Um minuto é folgadamente mais que um `dbDelta` de duas tabelas pequenas e
folgadamente menos que a janela em que um lote pendente ainda é retentativa — que é a janela da
visita, e é isso que garante que a migração terminada alcance o lote antes de ele vencer.
Repetir a tentativa a cada minuto num site que nunca vai conseguir criar a tabela custa um
`dbDelta` por minuto; ficar quinze minutos calado custa a medição de quinze minutos. **E a
trava cai no sucesso**: criada a estrutura, não há mais o que travar.

**O teto de pedidos por janela. O EIXO NÃO MUDA, e o número muda.** A alternativa foi medida
antes de ser recusada: um balde por VISITANTE seria um balde cuja chave quem bate na porta
escolhe. O apelido do visitante é sorteado dentro do navegador, e trocá-lo custa uma linha de
JavaScript — o limite recusaria exatamente quem não tem nada a esconder e não recusaria mais
ninguém. É a mesma razão da decisão 45: **controle chaveado por declaração do cliente não é
controle.**

O número, sim, estava errado para esta rota. Sessenta por dez minutos nasceu quando o envio era
UM por sessão de página; com envio por lote, um leitor atento produz um lote por ocultamento —
e ocultamento acontece toda vez que a aba perde o foco, não só na saída. Atrás de CDN, com
`f3base_origem_confiavel` vazia (o caso medido neste site), a origem é a MESMA para todo mundo,
e um visitante intenso esgotava o balde do site inteiro. O novo valor é `MAX_POR_VISITA`, e ele
não é número novo: é o teto de linhas que UMA visita pode escrever. **Um balde que não cabe uma
visita inteira recusa o leitor mais atento do site antes de recusar qualquer abuso.**

E o que o balde passou a custar mudou junto: antes, cada 429 era um lote perdido em silêncio;
agora ele é retentativa. O balde deixou de decidir o que é MEDIDO e passou a decidir QUANDO.

**O que continua sem resposta, e fica escrito:** atrás de CDN o balde é do site inteiro, e
nenhum número conserta isso. A resposta certa é declarar `f3base_origem_confiavel`, que já
existe e já é ensinada na tela de configuração — o que faltava era alguém dizer que ESTA rota
depende dela tanto quanto a de leads.

### O corte passa a ser gravado, e a tela passa a dizer que a tabela está incompleta

O corte sempre foi nosso e sempre foi contado — o cliente conta o que estourou o orçamento da
visita, o servidor conta o que estourou o teto do corpo — e saía NOMEADO na resposta da rota.
Só que **a resposta da rota morre no navegador**: quem abria o menu Medição via uma tabela e
não tinha como saber que faltava alguma coisa nela. Somava achando que tinha tudo, e essa é a
pior forma de um número errado — a que não parece errada.

Ele é somado na MESMA tabela do resumo, sob `F3Base_Modulo_Comportamento::METRICA_CORTADAS`,
porque tem exatamente a granularidade dela (dia, caminho) e exatamente o prazo dela: uma tabela
nova seria uma segunda migração, uma segunda poda e um segundo prazo para manter, para guardar
um inteiro por dia e por página. **E ele fica FORA do total, fora da lista de páginas e fora da
lista de eventos**: somá-lo ao total faria a tela afirmar ter recebido justamente o que se
perdeu, e listá-lo entre os acionamentos faria quem lê somar descarte com acontecimento. Ninguém
"cortou" nada — foi o pacote que descartou. O nome tem produtor único, e todo leitor do resumo o
exclui por ele.

Na tela, o quadro sai no *Estado da coleta*, ANTES de qualquer tabela, com o total e as páginas
em que o descarte aconteceu — descarte concentrado numa página é outra conversa que descarte
espalhado, e sem o caminho as duas são o mesmo número. **Zero não imprime nada**: um quadro
dizendo "0 descartadas" em todo site saudável ocuparia a atenção de quem abre a tela para não
responder nada.

### O que a bancada ganhou, e o que ela não sabia fazer

Três lacunas fecharam, e duas delas estavam declaradas desde a 1.3.4:

1. **A bancada não sabia recusar um envio nem devolver código de resposta.** Enquanto o
   despacho era `sendBeacon`, o único desfecho observável era "o navegador aceitou a carga", e
   a diferença entre ENFILEIRADO e ENTREGUE — que é a release inteira — não tinha como ser
   exercitada. Ela ganhou `fetch` com resposta declarada (número, função ou `'rede'`) e uma
   promessa que resolve na hora, porque a bancada é síncrona e uma `Promise` de verdade só
   entregaria o retorno depois de a checagem ter terminado.
2. **`pagehide` sempre chegava.** Ganhou `morrer()`: o carregamento que acaba sem evento de
   saída nenhum. É o único caso em que a única coisa que sobrevive é o que já estava GRAVADO.
3. **Ela nunca recusava escrita no `localStorage`.** Ganhou a recusa, e com ela o ramo da
   degradação declarada deixou de ser só uma frase de comentário.

**As três mutações plantadas**, cada uma acusada pelo piso que ela existe para exercitar:
limpar o acumulado sem conferir a resposta reprova o piso do envio recusado; manter o pendente
só em memória reprova o piso do carregamento que morre; e o selo sorteado a cada despacho —
mais o servidor sem memória do selo, no lado de lá — reprova o piso do reenvio.

### Os dois tetos deixaram de ter a mesma resposta

Esta é a última rota pela qual o contador andava sem a linha chegar, e ela sobreviveu ao
conserto principal. `registrar()` recusava a linha em duas condições somadas na mesma
expressão: o orçamento da VISITA (`maximoVisita`) e o teto de linhas de UM CORPO
(`maximoLog`). As duas somavam em cortadas, e tratá-las igual era o defeito.

**Passar do orçamento da visita termina a série.** A visita não grava mais nada, e a contagem
de cada gatilho simplesmente para. Truncar o fim de uma série é visível e legítimo: quem lê vê
onde a contagem terminou, e o excedente sai nomeado.

**Encher um corpo não termina nada.** Depois do selamento o registro volta a aceitar, e a
linha recusada por ali ficava no MEIO da série, com o contador já avançado e as linhas
seguintes chegando normalmente. É exatamente o buraco que esta release existe para eliminar,
sobrevivendo por outro caminho — e é o mesmo desenho de defeito da visita `8cac18da`, só que
produzido pelo nosso próprio teto em vez de pelo despacho perdido.

**E ele é alcançável sem nada de anormal.** Cento e vinte acionamentos entre dois ocultamentos
é um leitor inquieto numa página longa que não troca de aba. O caso de rajada — o erro de
JavaScript em laço de render — nunca foi este: ele tem teto próprio de 3 na declaração do
evento.

**Então o teto do corpo passou a SELAR o lote, em vez de cortar a linha.** O lote cheio vira
lote pendente na hora, a linha entra no lote seguinte, e a série não abre buraco. O teto do
endpoint continua valendo — nenhum corpo sai com mais linhas que ele —, e o que mudou é o
desfecho de encostar nele. Cortar continua existindo onde não há alternativa: o orçamento da
visita, e a linha que sozinha não cabe no corpo em `selar()`. O que deixou de existir é o
corte como resposta normal a um leitor atento.

O piso é a página do defeito: um trecho longo sem trocar de aba, um ocultamento no meio, outro
trecho longo. O ocultamento é o que separa TRUNCAR de ABRIR BURACO — sem ele, o mutante que
corta produziria uma série truncada, que é outro defeito. Com ele, o mutante entrega o bloco
do topo como `[1,4]`: a mesma assinatura de `comando-unico` saindo com 1 e 3 em produção.

### O que custa

**Escrita no navegador.** O registro da visita passou a ser regravado também a cada linha e a
cada total, e não só a cada travessia contada. Ele ficou maior: contador, acumulado e fila
pendente, todos limitados pelo mesmo orçamento de `maximoVisita`. A gravação acontece na hora
de propósito, e pela razão de sempre: a saída de página não é um instante confiável.

**Mais requisições.** A fila inteira é despachada a cada tentativa, e não um lote por vez.
Numa visita saudável a fila tem zero ou um lote e nada muda; numa visita com o servidor
recusando, ela produz mais requisições em troca de recuperar mais rápido quando ele voltar.

**Dado a mais no aparelho do visitante.** Dois campos, e nenhum deles é dado NOVO sobre a
pessoa: o que eles guardam é exatamente o que já viajava no corpo despachado — gatilho
declarado, detalhe pelo alfabeto fechado, caminho de uma página deste site, carimbo relativo ao
carregamento. Os dois são removidos do aparelho na recusa, com o apelido, pela mesma chamada.

**As rotas pelas quais o contador ainda pode andar sem a linha chegar**, e todas ficam
declaradas. Nenhuma delas é silêncio: as três somam em cortadas, e as cortadas agora chegam à
tela.

1. **Recusa PERMANENTE (400 ou 413).** Só acontece se o nosso cliente produzir um corpo que o
   nosso servidor recusa — defeito do par, não condição de runtime.
2. **Lote pendente vencido**, mais velho que a janela da visita. Exige uma visita viva por mais
   tempo que a janela com o despacho falhando o tempo todo; a trava da migração, agora de um
   minuto, cabe folgadamente dentro dela.
3. **Linha que sozinha não cabe no corpo**, em `selar()`. Inalcançável na prática — uma linha
   tem cerca de 80 bytes contra um teto de 8192 —, e o ramo existe porque sem ele o laço de
   selamento não avançaria.

E duas que NÃO produzem buraco, e por isso não reprovam o invariante: o teto por travessia e o
orçamento da visita **truncam** o fim da série, e o armazenamento que passa a recusar escrita no
meio da visita faz as ocorrências **repetirem** em vez de faltarem — é a degradação declarada,
e a bancada agora sabe produzi-la.

**Como reverter.** Trocar o despacho por `sendBeacon` puro reprova o piso do envio recusado em
`js.sessao_com_releitura`, que é a mutação plantada. Parar de gravar `acumulado` reprova o piso
do carregamento que morre SEM ter selado; parar de gravar `pendentes` reprova o do que morre
DEPOIS de selar — cada um sozinho, que é como as duas mutações são plantadas. Voltar o teto do
corpo a cortar a linha em vez de selar o lote reprova o piso do teto do corpo. Tirar a reserva do selo
reprova `comportamento.lote_idempotente` nos três ramos. Voltar o transiente da migração para
quinze minutos reprova o piso da trava. Reverter não apaga o que já foi gravado no servidor: as
linhas com buraco de ocorrência continuam lá, e nenhuma migração as recupera — o dado que não
chegou não existe em lugar nenhum.

---

## 29. A seção ganha linha de saída própria, e a banda passa a ser declarada (origem: implantador 1.7.4, decisão nº 95)

**Decidido.** `saida=0.2` entra no limiar de `f3base_secao_vista` em
`fontes/site-core/dados/eventos-comportamento.tsv`, ao lado de `visivel=0.5`. O observador
passa a ser armado com `{ threshold: [ 0, saida, visivel ] }`. A seção **entra** quando a
razão alcança `visivel` e **rearma** quando ela cai abaixo de `saida`; entre as duas, nada
muda de estado. `saida` ausente, não numérica, negativa ou maior/igual a `visivel` volta ao
comportamento simétrico (`saida = visivel`), que é o de antes desta release.

**O que isso separa do defeito da 1.3.3.** Lá a saída era a razão ZERO e **não estava
declarada em lugar nenhum**: ela era o efeito colateral de `isIntersecting`, e ninguém podia
discordar de um número que não existia. Aqui a saída é um número no TSV, na mesma célula de
limiar do `visivel` que ela protege, revisável na mesma leitura, e a banda existe de
propósito. O argumento da decisão 90 — *"um limiar de histerese próprio seria um número que
ninguém revisaria junto com o `visivel`"* — não foi abandonado: ele foi respondido pelo LUGAR
do número.

**O que a banda faz, medido.** Com uma linha só, a razão oscilando em torno de 0,5 rearma e
reentra a cada oscilação: a seção de uma tela parada na fronteira do campo de visão fabrica
ocorrência 2, 3 e 4 sem que ninguém tenha relido nada. Com a banda, a oscilação entre 0,2 e
0,5 não muda estado nenhum, e só a passagem que de fato tirou o bloco do campo de visão volta
a contar. É a mesma disciplina do `histerese_pp` do marco, aplicada à seção.

**O QUE ELA NÃO FAZ, e isto precisa estar escrito porque foi a premissa do pedido.** A banda
NÃO passa a registrar releitura que hoje não é registrada — ela registra MENOS, nunca mais.
Uma linha de saída mais BAIXA exige um movimento MAIOR para rearmar, não menor. A hipótese de
que o problema era *"o tamanho do movimento que o rearme exige"* leva ao conserto oposto —
saída ACIMA da entrada —, e esse conserto é o que a defesa do cliente recusa: com a saída
acima da entrada, o bloco rearma enquanto ainda está mais visível do que a entrada exige, e
cada oscilação vira ocorrência até o teto por visita cortar, gravando travessias que ninguém
fez.

**E a premissa também não se sustenta na medição.** A sonda de navegador desta release rodou
o cliente 1.3.5 e o 1.3.6 nos dois percursos, no mesmo Chromium, contra a mesma página: as
sequências saíram **idênticas**. No percurso curto — o do relatório, subir três passos perto
do fim e descer de novo — as duas releases entregam `abertura [1]`, `pecas [1]`,
`comando-unico [1,2]`, `faq [1,2]`, com zero cortada. Os dois blocos do topo saem com uma
ocorrência porque **ninguém voltou a eles**; ausência de reentrada não é perda, e quem
responderia por perda é o contador de cortadas, medido em zero.

**O que custa.** Uma reentrada curta e legítima — quem tira o bloco até a razão 0,3 e o traz
de volta — deixa de ser contada. É o lado certo de errar: ocorrência perdida é um número
menor, ocorrência fabricada é um número que descreve um comportamento que não houve. E custou
uma mudança de geometria na bancada: o bloco `meio` da página curta de `js.sessao_com_releitura`
descia só até 0,4 e voltava, e com a banda ele não rearma mais. Ele foi movido para onde
CRUZA a linha declarada, e o caso que ele media virou um quarto bloco, `banda`, que oscila
entre 0,233 e 0,533 e tem de sair com UMA ocorrência. Trocar a geometria sem deixar o caso
antigo medido em algum lugar seria ajustar a bancada ao código.

**Como reverter.** Tirar `saida` do limiar faz o cliente cair no comportamento simétrico — e
reprova o teto da declaração em `js.sessao_com_releitura`, que exige a banda declarada e menor
que a entrada. Trocar `razao < saida` por `razao < visivel` no cliente reprova o piso da banda
nos dois lados: o bloco `banda` passa a contar mais de uma vez, e o percurso inteiro grava mais
linhas de interseção do que o pacote.

---

## 30. O plugin deixa de ser construído pelo implantador e vira artefato próprio (origem: implantador 1.7.4, decisão nº 98)

**Decidido.** `f3base-site-core` passa a se chamar **`Base Site Core Fator3`**, pasta
`base-site-core-fator3`, arquivo principal `base-site-core-fator3.php`, e a numeração dele
**recomeça em `1.0.0`**. Ele deixa de ser construído pelo implantador: é artefato único, com
identidade única, publicado como zip e instalado em qualquer site desta operação como qualquer
outro plugin de catálogo. A fonte dele sai de `fontes/site-core/` para `fontes/plugin/`, e
**não viaja mais dentro do bundle do implantador** — o bundle leva só
`assets/plugins/base-site-core-fator3-<versão>.zip`.

**Por quê, e o defeito é medido.** `ferramentas/renomear-prefixo.php` varria a raiz inteira do
pacote e renomeava **também** `fontes/site-core/`: slug do plugin, prefixo das classes, prefixo
das options, text domain. Ou seja: cada site produzia um **fork** do plugin, com options
`<prefixo>_ga4_measurement_id` em vez de `f3base_ga4_measurement_id`. Um plugin com release
própria cujo nome de option muda por site não é um plugin — são N plugins parecidos, e nenhuma
correção publicada alcança nenhum deles. O fork era silencioso: cada site ficava internamente
coerente, e só a operação inteira ficava incoerente.

**POR QUE A NUMERAÇÃO RECOMEÇA, e por que isso fica escrito.** Herdar o `1.3.7` afirmaria que
este é o mesmo artefato de antes com uma correção a mais. Ele não é: o que mudou foi o que ele
**é**. O `1.0.0` é a afirmação de que a série `1.3.x` pertence a outro objeto — um plugin que
o implantador montava — e de que a série nova pertence a um artefato que se publica sozinho.
Quem estiver na série antiga não "atualiza": migra, e a migração está na decisão 100.

**O QUE NÃO MUDOU, E É A METADE QUE IMPORTA.** O prefixo interno `f3base` continua exatamente
como está: nomes de option (`f3base_ga4_measurement_id`, `f3base_comportamento`, …), nomes das
tabelas (`f3base_comportamento`, `f3base_eventos`, `f3base_leads_dedup`), nomes de evento
(`f3base_rolagem`, `f3base_secao_vista`, …), namespace REST (`f3base/v1`), prefixo das classes
PHP e text domain. Essas chaves **apontam para dado vivo** em sites que já rodam. Renomear a
option orfana o valor sem apagar nada e sem erro nenhum; renomear a tabela apaga a série
histórica; renomear o evento quebra a série na conta de medição do fornecedor, onde não há
reparo depois. **Nome de pasta é endereço; nome de option é chave de dado.** Trocar o primeiro
é grátis, trocar o segundo é perda de dado calada.

**AS CONSTANTES VIRARAM `F3BASE_PLUGIN_*`, e a versão passou a sair do cabeçalho.** As antigas
`F3BASE_SITE_CORE_VERSAO`, `_DIR`, `_URL`, `_ARQUIVO`, `_PHP_MINIMO` são símbolos, não chaves de
dado: renomear é grátis e o nome antigo apontava para um artefato que mudou de nome. Junto veio
uma correção que não estava no roteiro: `F3BASE_SITE_CORE_VERSAO` era um LITERAL `'1.3.5'` ao
lado de um cabeçalho que dizia `Version: 1.3.6`. As duas eram verdadeiras isoladamente e ninguém
acusava — é exatamente a armadilha que o MANIFESTO descreve para o tema. Agora a constante sai
de `get_file_data()` sobre o próprio cabeçalho.

**A FONTE DO PLUGIN NÃO VIAJA, e isso fecha um resíduo declarado na 1.6.6** (decisão 96, último
parágrafo do custo). Com o plugin desacoplado, entregar a fonte dele dentro do bundle seria
entregar uma cópia que ninguém deve editar e que diverge da release publicada no instante
seguinte — e era essa cópia que dava à renomeação algo para renomear. `pacote.plugin_so_como_zip`
confere no ARTEFATO montado, pela lista de entradas do zip, que nenhum caminho
`implantador-base/fontes/plugin/` viaja e que a reserva viaja.

**A FONTE FICA A DOIS NÍVEIS DA RAIZ, e o nome do diretório mudou mas a PROFUNDIDADE não pode
mudar.** `fontes/plugin/` e não `plugin/`: um arquivo com `Plugin Name:` a UM nível da raiz do
pacote está dentro do alcance de `get_plugins()`, a tela de instalação ordena por Name, e o
link "Ativar plugin" passa a apontar para um caminho de dois níveis que `validate_plugin()` não
enxerga — o defeito medido que `pacote.sem_cabecalho_de_plugin_aninhado` guarda desde a 1.0.x.

**O que custa.** Três coisas, e nenhuma é pequena. (1) O nome do zip publicado mudou: quem
publica no GitHub precisa subir `base-site-core-fator3.zip` no endereço declarado em
`config/decisoes.tsv`; o `f3base-site-core.zip` antigo deixa de ser lido por alguém. (2) A
pasta `fontes/plugin/` do repositório **não é instalável como está** — faltam cinco arquivos,
que são o contrato compartilhado e entram no zip pela cópia do empacotamento (decisão 99); é
aceitável porque o plugin é artefato construído, e `pacote.plugin_completo_no_zip` confere o
zip contra a lista de autoload em toda rodada. (3) O bundle ficou com um artefato a mais para
manter coerente — a reserva —, e `pacote.reserva_identica_ao_avulso` prova, por sha256 sobre a
cópia extraída do bundle, que ela é byte a byte o zip publicado.

**Como reverter.** Tirar `fontes/plugin/` de `f3b_fora_do_bundle()` devolve a fonte ao bundle;
tirar as duas linhas de `ferramentas/excecoes-de-prefixo.tsv` devolve o plugin à renomeação. As
duas reversões são possíveis e **não são silenciosas**: `renomeacao.plugin_intacto` e
`pacote.plugin_so_como_zip` passam a reprovar, cada uma nomeando o que está em jogo.

---

## 31. O contrato compartilhado ganha casa própria, e a dependência muda de sentido (origem: implantador 1.7.4, decisão nº 99)

**Decidido.** As quatro regras que os dois runtimes leem — `F3Base_Chaves_Seo`,
`F3Base_Vocabulario`, `F3Base_Emissores`, `F3Base_Censo_Demonstrativo` — e a declaração
`emissores-conhecidos.tsv` saem de dentro da fonte do plugin e passam a morar em
`partilhado/`, no mesmo caminho relativo que terão dentro do plugin. O empacotamento copia
`partilhado/` para dentro do zip do plugin; o implantador lê de `partilhado/` quando o plugin
ainda não existe na instalação, e do **plugin instalado** quando ele existe.

**Por quê.** A dependência estava no sentido errado, e era ela que sustentava o acoplamento que
a decisão 98 desfaz: o IMPLANTADOR alcançava para dentro da árvore do PLUGIN para carregar
regras de que precisa **antes** de o plugin existir — o preflight roda antes de instalar
qualquer coisa. Enquanto essa leitura existisse, a fonte do plugin **tinha** de viajar dentro
do bundle, e enquanto ela viajasse, a renomeação tinha o que renomear. Mover o contrato para um
lugar neutro corrige a causa; excluir o diretório da renomeação teria corrigido só o sintoma.

**Uma cópia de cada lado foi recusada, e o motivo é o de sempre:** duas cópias da mesma regra
divergem na primeira condição acrescentada, e divergem em silêncio — quem ESCREVE a meta e quem
a LÊ passariam a usar nomes diferentes sem que nada acusasse.

**O que custa.** A pasta `fontes/plugin/` deixa de ser instalável por cópia: cinco arquivos do
autoload dela só existem depois do build. É o mesmo tipo de custo que a decisão 96 já pagou —
lá o entregue difere da fonte por não ter comentário, aqui difere por ter cinco arquivos a
mais —, e ele é coberto por `pacote.plugin_completo_no_zip`, cujo piso planta a ausência de um
arquivo do autoload dentro do zip.

**Como reverter.** Mover os cinco arquivos de volta para `fontes/plugin/` e fazer
`carregar_do_site_core()` apontar para lá. A reversão traz de volta a obrigação de a fonte do
plugin viajar no bundle, e `pacote.plugin_so_como_zip` passa a reprovar — a reversão é
possível e não é silenciosa.

> **Superada na 1.0.0** — ver decisão nº 70.

---

## 32. Duas cópias do mesmo plugin ativas não podem existir, e quem resolve é a ativação (origem: implantador 1.7.4, decisão nº 100)

**Decidido.** Ao ATIVAR, `Base Site Core Fator3` procura outras cópias ATIVAS de si mesmo e as
**desativa**, registrando o que fez num transiente que a tela lê uma vez e apaga. O
discriminante não é o nome da pasta: é o arquivo principal do plugin ativo **declarar o mesmo
namespace REST** (`F3BASE_REST_NAMESPACE`), lido nos mesmos 8 KiB que `get_file_data()` lê.

**Por quê, e o caso é real.** Existe pelo menos um site em produção com o plugin na pasta
antiga (`f3base-site-core`, 1.3.6). Instalar a pasta nova ali produz **duas cópias do mesmo
plugin ativas ao mesmo tempo**: dois registros de hooks, dois `register_rest_route` para o
mesmo endereço, dois coletores enfileirados na mesma página, contagem em dobro na conta de
medição. O WordPress não impede isso e não avisa — não aparece como erro, aparece como número
errado semanas depois, sem nada que aponte para a causa.

**NÃO HÁ DADO A MIGRAR, e é exatamente por isso que o prefixo interno não mudou.** As options
são as mesmas `f3base_*` e as tabelas são as mesmas `f3base_comportamento`,
`f3base_eventos` e `f3base_leads_dedup`. A cópia nova encontra a configuração do site inteira,
no lugar onde ela sempre esteve. O que mudou foi o **endereço** do código, e endereço não
guarda dado.

**POR QUE DESATIVAR A OUTRA, E NÃO RECUSAR ATIVAR ESTA.** A alternativa foi considerada e é
pior por três razões. (1) Recusar deixa o site rodando a cópia ANTIGA — o artefato que esta
release existe para substituir — e transfere a correção para alguém ler uma mensagem; a
instalação é feita pelo implantador, sem ninguém olhando, e a mensagem chegaria a um relatório
enquanto o site seguiria como estava. (2) O dano das duas cópias já existe no instante da
ativação, e recusar não o desfaz: ele apenas não fica pior. Desativar a antiga é a única ação
que devolve o site a UMA cópia. (3) Desativar plugin alheio seria atrevimento — mas este não é
alheio: é uma cópia mais velha DESTE MESMO plugin, reconhecida pela reivindicação do mesmo
namespace, e o WordPress não tem como servir as duas.

**O HOOK DE DESATIVAÇÃO DA CÓPIA ANTIGA NÃO RODA**, e a escolha é medida: aquele hook
desinstala os módulos — desagenda a cadência, remove regras de reescrita — e são os MESMOS
agendamentos e as MESMAS regras que a cópia nova acabou de instalar, porque as chaves são as
mesmas. Rodá-lo desfaria a ativação em curso e deixaria o site com o plugin ativo e a cadência
desagendada, calado.

**O que custa.** Um plugin ativo é desativado sem que ninguém tenha clicado, e isso é uma
mudança de estado do site feita por nós. O custo é contido por três limites escritos no código:
nada é apagado do disco, nenhuma option e nenhuma tabela é tocada, e a ação é **reversível por
um clique**. E ela é registrada: o aviso nomeia o arquivo desativado e diz por quê.

**O piso é o falso positivo, que aqui é o dano maior.** `migracao.copia_anterior_desativada`
monta um `wp-content/plugins/` de verdade em disco e roda a função REAL contra ele: plugin de
terceiro ativo não é tocado; um plugin cujo NOME parece o da cópia velha mas que não traz a
marca não é tocado; cópia velha INATIVA não é tocada; e num site só com a cópia nova nada é
desativado e nada é registrado.

**Como reverter.** Remover a chamada de `desativar_copias_do_mesmo_plugin()` em `ativar()`
devolve o comportamento anterior — e devolve junto o silêncio das duas cópias ativas, que é o
que esta decisão existe para impedir.

---

## 33. O que a renomeação de prefixo NÃO toca vira regra declarada, em dois arquivos (origem: implantador 1.7.4, decisão nº 101)

**Decidido.** A renomeação de prefixo passa a ter duas listas declaradas, cada uma com o motivo
por linha, e nenhum `if` escondido:

- `ferramentas/excecoes-de-prefixo.tsv` ganha `fontes/plugin/` e `partilhado/` — **caminhos que
  a ferramenta não atravessa**;
- `fontes/plugin/dados/contrato-de-nomes.tsv` — **grafias que sobrevivem em qualquer arquivo**,
  inclusive nos que SÃO renomeados.

**Por que as duas, e não só a primeira.** Excluir o caminho resolve metade. O IMPLANTADOR
continua sendo renomeado, e é ele quem GRAVA as options que o plugin LÊ, quem agenda o hook que
o plugin ouve e quem chama as classes compartilhadas pelo nome. Com só a exclusão de caminho, o
site ficaria com o implantador gravando `acme_ga4_measurement_id` e o plugin lendo
`f3base_ga4_measurement_id` — **pior** que o fork, porque o fork ao menos era internamente
coerente.

**A SEGUNDA LISTA É DERIVADA, E A TABELA SOZINHA NÃO BASTAVA.** A primeira tentativa desta
release preservou só as grafias escritas à mão no contrato, e o pacote renomeado mostrou o
tamanho real da fronteira em três camadas: `suite/inventario.tsv` foi reescrito e o
empacotamento **abortou** com trinta arquivos "FORA DO INVENTÁRIO"; o implantador passou a
gravar `acme_operaveis` enquanto o plugin continuava lendo `f3base_operaveis`; e as bancadas de
JavaScript passaram a procurar o handle `acme-tracking` num cliente que se registra como
`f3base-tracking`. Foram **quatorze** checagens em FALHA no pacote renomeado. A regra que
resolve é uma frase só, e ela é derivada de disco em
`ferramentas/nomes-preservados.php`: **o plugin não é renomeado, então tudo que ele escreve
continua escrito assim** — nome de arquivo, de classe, de handle, de atributo de DOM, de classe
de CSS, de variável de JavaScript, de código de erro, de option, de tabela e de evento. São 321
grafias, e nenhuma delas é digitada.

**O QUE A DERIVAÇÃO NÃO PRESERVA é o que a mantém honesta:** a grafia NUA do prefixo, e a nua
com um separador colado. `f3base` sozinho continua sendo trocado, e `f3base-` também — o plugin
monta nomes em tempo de execução (`'f3base-' . $sufixo` para um transiente), e preservar aquele
token fazia TODO caminho do pacote que começasse por `f3base-` sobreviver: medido, a renomeação
caiu de 154 caminhos para UM. É por isso que `estatica.sem_residuo_de_prefixo` continua tendo
dentes: um arquivo que a ferramenta esqueceu carrega `F3Base_Imp_Plugins` ou um `f3base` nu no
caminho, nenhum dos dois está no vocabulário do plugin, e ele aparece.

**A TABELA DECLARADA CONTINUA EXISTINDO**, e por duas razões: a derivação não alcança o que não
tem forma de identificador (`f3base/v1` tem uma barra), e ela é onde o MOTIVO de cada grafia
está escrito. A derivação é mecânica; a declaração é o que se lê.

**A EXCEÇÃO QUE A EXCLUSÃO CRIOU, e como ela foi resolvida.** A classe que marca seção medida é
`f3base-secao-<nome>`, carimbada pelos **patterns do tema** e pelo **conteúdo** — os dois
renomeados — e procurada pelo **coletor do plugin**, que não é. Com o tema carimbando
`<prefixo>-secao-abertura` e o plugin observando `f3base-secao-`, o observador é instalado, não
recebe alvo nenhum, e a medição de seções morre calada em todo site renomeado: o evento
`f3base_secao_vista` continua declarado, continua ocupando linha no relatório, e responde
"nada" para sempre. A saída é a que o problema já indicava: **o prefixo de seção é contrato do
PLUGIN, não identidade do site.** Ele fica `f3base-secao-` em todo lugar e está no contrato de
nomes. Não é decisão de estilo — o tema estiliza `f3base-faixa-escura`, que É identidade e É
renomeada; `f3base-secao-` não aparece em CSS nenhum, é marca de medição, e marca de medição
pertence a quem mede.

**A PRESERVAÇÃO É POR MÁSCARA, e não por uma entrada identidade no mapa.** `str_replace()` com
arrays aplica cada par sobre o texto INTEIRO, um depois do outro: um par
`f3base-secao- => f3base-secao-` não protegeria nada, porque a substituição seguinte
(`f3base => acme`) voltaria a encontrar o que a primeira acabou de reescrever igual. A máscara
tira a grafia do texto antes de qualquer substituição e a devolve depois — é a única forma de o
resultado não depender da ordem do mapa. O sentinela é `\0<índice>\0`: byte nulo porque nenhuma
extensão de texto declarada o carrega, e só dígitos no meio porque toda grafia do mapa é de
letras.

**O CONTRATO NÃO É LISTA ESCRITA À MÃO QUE NINGUÉM CONFERE.**
`renomeacao.contrato_de_nomes_completo` deriva o que ele precisa cobrir do **catálogo de options
do próprio plugin** e da **declaração de eventos de comportamento**, e reprova o que falta. Sem
isso, a primeira option nova acrescentada ao plugin voltaria a ser reescrita pela renomeação, e
o defeito voltaria calado exatamente onde estava.

**O que custa.** Um site derivado deste template carrega, para sempre, grafias `f3base_*` que
não são o prefixo dele: nas options do plugin, nas tabelas, nos eventos e na classe de seção. É
uma inconsistência visível para quem abre o banco, e ela é o preço de o plugin ser **um**
artefato. A alternativa — cada site com o próprio nome de option — é exatamente o defeito que
esta release corrige.

**Duas correções vieram junto, e as duas são de piso.** A fixture negativa de
`estatica.option_gravada_sem_leitor` plantava a option `f3base_cadencia`, que é do PLUGIN e
portanto preservada: no pacote renomeado ela caía FORA do escopo do detector — que delimita
pelo `site.prefixo_tecnico` — e o piso negativo deixava de acusar. O literal virou
`f3base_piso_da_cadencia`, que é do namespace do implantador e acompanha a renomeação; o
defeito narrado continua sendo o de 1.0.17. E a fixture de
`pacote.js_entregue_sem_comentario` usava o símbolo `f3baseArmadilhaDeStrip`: no pacote
renomeado o arquivo solto era reescrito e o zip da fixture, que é binário, não — e o piso
positivo passava a acusar o caso correto. Esse já reprovava na 1.6.6, e só aparecia para quem
rodasse o piso sobre um pacote renomeado.

**Como reverter.** Apagar `fontes/plugin/dados/contrato-de-nomes.tsv` faz a ferramenta RECUSAR
renomear, com a razão escrita: renomear sem o contrato é pior do que não renomear. Remover
também a recusa e neutralizar a derivação de `ferramentas/nomes-preservados.php` devolve o
comportamento da 1.6.6 — e é exatamente o par de mutantes que os pisos de
`renomeacao.plugin_intacto` e `renomeacao.secao_medida_apos_renomear` plantam, em toda rodada.

> **Superada na 1.0.0** — ver decisão nº 63.

---

## 34. O carimbo de cada acionamento é o instante dele, e não a hora em que o lote chegou (origem: implantador 1.7.4, decisão nº 105)

**Decidido.** O cliente passa a enviar a **origem temporal do carregamento** — uma vez por lote,
dentro do lote SELADO — e o servidor grava `criado_em` de cada linha do registro como
`origem + ms`, em vez de `time()`. A origem do visitante passa por uma **guarda do relógio**; o
que não passa cai numa **âncora derivada do servidor** (`chegada − maior ms do lote`). Qual das
duas âncoras carimbou cada linha vira **coluna** (`ancora`), com três valores fechados, e a tela
diz isso. As linhas já gravadas **não são reescritas**.

**O que foi medido.** No banco de um site em produção, agrupando `wp_de3awa_f3base_eventos` por
`criado_em`:

```
criado_em    linhas  ms_min  ms_max  janela_ms
1788610945      33     724   10816      10092
1788610820       7   35732   37231       1499
1788610688      12     925    4122       3197
```

Trinta e três acionamentos espalhados por dez segundos de navegação, todos gravados no MESMO
segundo. Na tela, as vinte e cinco linhas da primeira página saíam todas com `09:22:25` na coluna
Horário. `registrar_evento()` gravava `'criado_em' => time()`, que é o instante em que o LOTE
CHEGOU ao servidor — e um lote carrega dezenas de acionamentos acumulados ao longo de segundos ou
minutos de navegação.

**A leitura de quem relatou estava errada e o sintoma era real.** O relato foi *"a tela altera a
linha anterior em vez de incluir uma nova, e isso só acontece quando um trigger inédito dispara"*.
As linhas SEMPRE foram distintas, cada uma com `id` próprio, e nada nunca foi reescrito. Mas
indistinguíveis no tempo elas parecem a mesma linha; e como o lote só parte quando algo novo
acontece, o bloco inteiro só aparece quando um gatilho novo dispara. As duas frases descreviam
exatamente o que a tela mostrava. **O defeito era nosso.**

**E a coluna `ms` estava gravada, certa, e não era usada para nada.** Ela existe desde o pedido
literal: *"Inclua também o horário de disparo de cada trigger, para podermos entender o tempo que o
visitante levou para percorrer a página."* Guardávamos o dado e mostrávamos outro.

**Por quê a origem viaja dentro do SELO.** Um lote que não conseguiu ser entregue fica na fila
pendente e parte no carregamento SEGUINTE, que tem outra origem — a dele. Lida na hora do despacho,
a origem seria a da página errada, e as linhas do lote retomado sairiam carimbadas no futuro delas.
Selado é imutável pela mesma razão que as linhas: a retentativa leva o mesmo corpo sob o mesmo selo.

**Por quê a guarda do relógio, e onde os limites moram.** A origem vem do aparelho de quem navegou.
Origem ausente, não numérica, no futuro além de `TOLERANCIA_RELOGIO_MS` (cinco minutos: a folga que
cobre o aparelho sem sincronização de rede e a latência entre carregamento e despacho) ou mais
velha que a janela de retenção do registro **não** é usada. Os dois limites são decisões de pacote e
moram onde as outras do plugin moram — constante com motivo escrito, ao lado de `MAX_MS`,
`MAX_EVENTOS` e `MAX_BYTES` —, e o segundo NÃO ganhou número próprio: ele é
`f3base_comportamento.retencao_eventos_dias`, porque uma origem além dela gravaria uma linha que a
próxima poda apaga, e dois números divergiriam na primeira vez que alguém mexesse num só.

**O limite da segunda âncora está escrito.** `chegada − maior ms do lote` dá o mesmo espaçamento
relativo sem confiar em relógio nenhum. Mas um lote entregue com atraso chega muito depois de ter
sido selado: **a ORDEM e o ESPAÇAMENTO ficam certos nos dois caminhos; o ABSOLUTO só é exato no
primeiro.** Prometer o absoluto nos dois seria a documentação mentindo sobre a medição.

**Por quê a procedência é COLUNA, e não contador nem linha de diagnóstico.** A pergunta "quanto vale
este horário?" é de CADA LINHA, e as três qualidades convivem na mesma tela: um site que sobe hoje
tem linha da chegada ao lado de linha do visitante ao lado de linha do servidor. Um contador diria
quantas são de cada tipo e não diria QUAL linha é qual — que é exatamente o que quem lê a tabela
precisa saber. A coluna custa uma migração, que o pacote já sabe fazer e já cobra
(`migracao.sobre_site_existente` deriva o conjunto do que é novo por EXECUÇÃO, e a coluna entra
sozinha na varredura).

**Por quê a âncora é truncada ao segundo inteiro.** `criado_em` é contado em SEGUNDOS — é o que ele
sempre foi, é o que as linhas já gravadas têm e é o que todo leitor espera — e a tela precisa da
fração para distinguir dois acionamentos do mesmo segundo. Truncada a âncora, o instante gravado é
sempre `ancora_seg * 1000 + ms`, e a fração dele é exatamente `ms % 1000`: derivável de cada linha
sozinha, sem coluna nova para transportar dez bits. O preço é um erro menor que um segundo no
ABSOLUTO, **igual para todas as linhas do lote** — não move ordem nem espaçamento — e muito menor
que a incerteza do relógio de onde a âncora veio.

**O que a tela faz com as linhas antigas.** Nada as reescreve. Sem a origem daqueles lotes, qualquer
carimbo derivado seria inventado, e carimbo inventado é pior que carimbo grosseiro declarado. Elas
ficam com `ancora` vazia, a coluna Horário as marca com "(chegada)", a leitura não devolve fração de
segundo para elas, e a linha de diagnóstico abaixo da tabela diz quantas são e por que elas não
respondem em que ordem nem a que distância os acionamentos aconteceram. A retenção do registro as
leva no prazo dela.

**Existe uma derivação honesta possível, e ela fica como PROPOSTA.** As linhas antigas trazem o
`criado_em` da chegada e o `ms`, e a regra da âncora do servidor é exatamente
`chegada − maior ms do lote`. Agrupando por `(sessao, caminho, criado_em)` — que é a assinatura de
um lote que chegou naquele segundo —, dá para aplicar a MESMA regra retroativamente e devolver a
elas ordem e espaçamento corretos, com o absoluto errando pelo tempo de fila, exatamente como no
caminho `servidor`. **Não foi feito, e o argumento contra é o agrupamento:** ele é INFERIDO, não
registrado. Dois lotes de carregamentos DIFERENTES da mesma visita e do mesmo caminho chegando no
mesmo segundo seriam fundidos, e a âncora comum poria as linhas do primeiro dezenas de segundos
antes do que aconteceu — um erro maior que o que ela conserta, agora com cara de dado bom. As
linhas afetadas são oitenta e sete, em um site, com prazo de retenção de trinta dias. Se o operador
quiser, a migração é uma consulta e uma decisão dele; ela não entra numa release por conta própria.

**O que custa.** Uma coluna a mais no registro, com a migração que ela implica: até `init` rodar
`dbDelta` no site atualizado, `eventos_prontos()` responde falso e a rota devolve `503` nomeado —
que é a degradação declarada do módulo, e não silêncio. Um campo a mais no corpo despachado, dentro
do teto de bytes que já existia. E um erro declarado menor que um segundo no absoluto de cada lote.

**Como reverter.** Devolver `'criado_em' => time()` e `'dia' => gmdate( 'Y-m-d' )` a
`registrar_evento()`, tirar `origem` de `campos()` e do lote selado no cliente, e apagar a coluna
`ancora` de `COLUNAS_EVENTOS` e do `CREATE TABLE`. A tela volta a mostrar `H:i:s` sem fração. O
defeito volta inteiro, com a assinatura conhecida: acionamentos de segundos de navegação caindo no
mesmo segundo, e linhas distintas parecendo a mesma sendo reescrita.

> **Superada na 1.0.0** — ver decisão nº 43.

---

## 35. Cada quadro do menu Medição diz de qual das duas tabelas ele vem (origem: implantador 1.7.4, decisão nº 106)

**Decidido.** Os quadros do menu Medição passam a trazer, cada um, uma linha dizendo **de qual das
duas tabelas** ele lê e **o que aquela tabela responde**. A frase de cada tabela tem produtor único,
`F3Base_Modulo_Comportamento::proposito_das_tabelas()`, e nenhuma delas é escrita dentro do PHP da
tela.

**O que foi medido.** A tela mostrava a tabela bruta de acionamentos e os quadros do agregado sem
dizer, em lugar nenhum, que são DUAS tabelas com propósitos diferentes. Quem opera foi ao banco para
entender o que via, encontrou `f3base_comportamento` — que soma na mesma linha por desenho, uma
linha por dia, caminho, evento e detalhe — e concluiu que o registro estava sendo reescrito. Não
estava: as linhas de `f3base_eventos` são distintas, cada uma com `id` próprio. A conclusão errada
foi produzida pela ausência de uma linha de texto.

**Por quê produtor único.** Escrita quatro vezes na tela, a frase divergiria na primeira edição
apressada, e a tela passaria a descrever a mesma tabela de dois jeitos — que é a forma de um
documento sobre dois dados virar um terceiro dado errado. É a mesma regra que já vale para a frase
de cada evento, que mora na declaração e nunca na tela.

**O quadro de profundidade é o único que mistura as duas, e ele diz isso.** Os totais de cada marco
e o denominador saem do agregado; o tempo típico, a releitura e "pessoas diferentes" saem do
registro. Sem a linha, quem comparasse esse quadro com a tabela bruta encontraria números que não
fecham e concluiria que um dos dois está errado.

**A linha do quadro de saídas vem ANTES do ramo do vazio.** O quadro vazio é justamente aquele em
que quem lê vai procurar de onde o número deveria ter vindo.

**O que custa.** Cinco linhas de texto a mais numa tela que já é densa. A alternativa medida foi pior:
quem lê vai ao banco e volta com uma conclusão errada sobre o próprio produto.

**Como reverter.** Remover as chamadas a `render_de_qual_tabela()` e o produtor. A tela fica mais
curta e volta a deixar as duas tabelas indistinguíveis para quem só a lê.

---

## 36. Um fato, uma linha, um veredito: a versão do `site-core` (origem: implantador 1.7.4, decisão nº 107)

**Decidido.** `release.versao_site_core` **sai**. `plugins.site_core_versao` passa a ser a
derivação ÚNICA do fato "a versão do plugin que ficou instalada é a que este pacote
carrega?", e o ramo em que a instalada está ATRÁS passa de **WARN para FALHA**. A segunda
saída escrita para o operador — instalar a cópia embutida à mão — passa a carregar o
ENDEREÇO da cópia, e some quando não há endereço resolvido.

**Por quê.** Numa execução real da 1.7.2, num site que já rodava, o zip publicado no
catálogo era o 1.0.0 e o pacote carregava o 1.0.1. Detectar isso está certo. O que estava
errado é que o MESMO fato saiu em duas linhas com severidades DIFERENTES:

```
WARN   plugins.site_core_versao   "O site ficou com o site-core 1.0.0, e este pacote carrega a 1.0.1…"
FALHA  release.versao_site_core   "a configuração declara 1.0.1 e o artefato instalado responde 1.0.0"
```

Não eram dois fatos parecidos: as duas linhas chamavam **as mesmas duas funções** —
`F3Base_Imp_Plugins::versao_embarcada_do_site_core()` e
`F3Base_Imp_Plugins::versao_instalada()`. É a mesma duplicidade que a decisão 17 fechou
para os vereditos de canal, reaparecendo num par que ninguém tinha olhado.

**Qual das duas sobreviveu, e por quê.** A que ficou é a que mede certo e diz mais.

- **A regra.** `release.versao_site_core` comparava com `===`. Isso acusa também o caso
  CORRETO: um site cuja URL do catálogo entregou uma versão MAIS NOVA que a reserva
  embutida. O manifesto declara que este pacote não rebaixa artefato mais novo, e a linha
  removida chamava esse acerto de FALHA. `plugins.site_core_versao` usa `version_compare`
  com quatro ramos nomeados, e o ramo "à frente" fecha OK.
- **A mensagem.** A linha removida afirmava duas coisas falsas para este par: que *"a
  configuração declara"* o número — ele sai do NOME do artefato resolvido, não de
  `config/site.json`, desde que a fonte do plugin deixou de viajar no bundle na 1.7.0 — e
  que *"é ele que o `?ver=` publica"*, que é verdade do par do TEMA, de onde a frase foi
  copiada. Um plugin não publica `?ver=` nenhum.
- **O que ela dizia ao operador.** Nada: sem frase de tela, sem saída. A que ficou tem as
  duas, e tem a causa escrita — a URL do catálogo à frente da reserva é o que faz TODA
  implantação instalar a versão velha com sucesso.
- **Onde ela mora.** Na classe que é dona do fato, ao lado da instalação que o produziu.

**Por que FALHA, e não WARN.** WARN é *"mediu e sobrou achado adverso"*; FALHA é *"mediu e
reprovou"*. A entrega promete que o site fica com o `site-core` que este pacote carrega.
A promessa foi medida por leitura de volta do cabeçalho instalado e **não foi cumprida**:
as correções da versão que o pacote traz não estão no site. Isso é reprovação, e chamar de
aviso o que é reprovação é a mesma classe de defeito que esta base combate desde a 1.0.14,
com o sinal trocado.

**E é FALHA que mantém a ferramenta de correção no ar** — o desfecho que precisava
continuar acontecendo. `SUCESSO_APLICACAO` é a primeira das três condições de
`pode_autodesativar()`, e FALHA derruba o estado para `FALHA_PARCIAL`. Um site que ficou
com uma versão superada do plugin, com correções ausentes, não pode ver o implantador sair
de cena. Antes desta release o desfecho era o mesmo pelo caminho errado: quem derrubava o
estado era a linha removida, declarada como gate de fase — e é dessa contradição que
tratam as decisões 108 e 109.

**A cópia embutida existe, e faltava o endereço.** A frase mandava *"instalar a cópia
embutida à mão pela tela de plugins"* sem dizer onde ela está. Ela existe: o bundle leva
`assets/plugins/base-site-core-fator3-<versão>.zip`, conferido por
`pacote.reserva_identica_ao_avulso`, e depois da instalação o arquivo fica em disco. Mas
quem envia o implantador envia o bundle **sem abri-lo**, e uma saída que o leitor não sabe
seguir é uma saída que não existe. A mensagem passou a imprimir o caminho —
`wp-content/plugins/<pasta>/assets/plugins/<slug>-<versão>.zip` —, a dizer que ele também
está dentro do zip que o operador enviou, e a nomear o percurso do wp-admin. Quando o
resolvedor não devolve caminho, a segunda saída **não é prometida**: é o caso do zip sem
número que o operador embute por decisão própria.

**Um slug, e não dois.** A versão INSTALADA era lida no slug do catálogo e a EMBARCADA no
slug de `site.site_core_slug` — duas fontes que ninguém cruza. Iguais nesta base, e nada
garantia que continuassem: divergindo, a linha compararia dois plugins diferentes e
chamaria isso de versão. Os dois lados passaram a sair do MESMO resolvedor. Quem cobra que
o catálogo tenha instalado onde a configuração declara é `entrega.site_core`, que é o lugar
daquela pergunta.

**O que custa.** Uma linha a menos no relatório, e um estado a mais capaz de derrubar a
execução: um site cujo catálogo não foi atualizado deixa de fechar
`SUCESSO_APLICACAO`. É o preço certo, e ele já estava sendo pago — pela linha errada. O
outro preço é de processo: cortar uma release do plugin sem publicar o zip no endereço
declarado passa a ter consequência visível na execução seguinte, em vez de um amarelo que
alguém aprende a ignorar.

**Como reverter.** Devolver o par ao mapa de `conferir_versoes_declaradas()` reabre os dois
vereditos, e `plugins.veredito_de_versao_do_site_core` reprova nomeando os dois emissores;
devolver o ramo "atrás" a WARN reprova no piso que diz, com todas as letras, que WARN não
derruba o estado e por isso deixaria a ferramenta de correção sair do ar num site com o
plugin superado; e apagar o endereço da frase reprova no piso da segunda saída.

> **Superada na 1.0.0** — ver decisão nº 72.

---

## 37. O zip do plugin passa a ser reprodutível, e o hash do pacote volta a fechar duas vezes igual (origem: implantador 1.7.4, decisão nº 111)

> **CORRIGIDA NA 1.7.4, E O ERRO TEM NOME: esta decisão chamou de "reprodutível" um
> artefato que era estável por UM DIA e só dentro do MESMO VOLUME.** Ela mediu duas rodadas
> seguidas, viu `6075ca9d…` e `6075ca9d…`, e concluiu reprodutibilidade a partir de um
> experimento que não movia nenhuma das duas variáveis que quebram o artefato — o relógio
> e o sistema de arquivos. Pior: ela declarou que `TZ=UTC` resolvia o caso de "duas
> máquinas", quando o fuso era só uma das portas e a ORDEM das entradas era a outra,
> aberta e não medida. Medido na 1.7.4: a mesma árvore em 05/09 e 06/09 dá `693ca754…` e
> `aeb40cad…`; a mesma árvore no MESMO dia dá `693ca754…` num ext4 e `855fabbb…` num
> tmpfs. **O que esta decisão fez de errado não foi errar a régua: foi aplicar a régua da
> decisão 84 — precisão de DIA — a um objeto para o qual ela não serve, e depois medir o
> resultado com um experimento que não podia acusar nada.** A decisão 112 substitui o
> conteúdo desta; o que fica aqui é o registro do erro, porque decisão apagada é decisão
> que volta.

**Decidido.** O estágio do zip do plugin recebe carimbo de tempo FIXO — meia-noite UTC do
dia da montagem, a mesma régua que a decisão 84 declarou para o registro de fases — antes
de o `zip` ser chamado, e as duas chamadas (`touch` e `zip`) rodam com `TZ=UTC`.

**Por quê.** Medido nesta release, e é uma afirmação de documento que tinha deixado de ser
verdadeira. Duas rodadas seguidas sobre uma árvore **byte a byte idêntica** — conferido por
`sha256sum` de todo arquivo fora de `dist/`, sem uma linha de diferença — produziam hashes
de pacote diferentes:

```
5e31845a…  →  80dfdfb6…  →  f8465960…  →  6e690f9a…
```

A causa não era a árvore. Era este arquivo: o estágio do plugin é copiado a cada montagem,
as cópias nascem com a hora de agora, e o formato zip guarda a hora de cada entrada dentro
do arquivo. O CONTEÚDO do plugin não mudava — o digest de conteúdo do zip ficou em
`171c62b0…` o tempo todo, com as mesmas 47 entradas —, mas os BYTES do arquivo que o embala
mudavam. E desde a 1.7.0 a reserva viaja DENTRO do bundle, enquanto o hash do pacote soma o
`sha256` de cada entrada dele: o número mudava a cada rodada.

A decisão 84 escreveu, ao explicar por que o registro de fases carimba o DIA e não o
segundo: *"Um operador comparando dois digests legítimos concluiria adulteração, que é
exatamente o mal-entendido que o MANIFESTO existe para evitar"*, e afirmou que *"a árvore
reverificada no mesmo dia dá o MESMO hash"*. Isso era verdade quando foi escrito e deixou
de ser na 1.7.0, sem que nada acusasse — porque a coisa que passou a viajar no bundle
naquela release é justamente um artefato de build.

**`TZ=UTC` nas duas chamadas, e não só o `touch`.** O formato zip guarda a hora LOCAL da
entrada. Fixar o mtime sem fixar o fuso deixaria a mesma árvore montada em duas máquinas
produzindo bytes diferentes — o mesmo defeito com outro nome, e mais difícil de achar
porque só aparece quando duas pessoas comparam.

**Medido depois.** Duas rodadas seguidas: `6075ca9d…` e `6075ca9d…`.

**O que custa.** Os arquivos dentro do zip do plugin chegam ao site com a data da montagem
às 00:00 UTC em vez do instante exato da cópia. Nenhum caminho do pacote lê essa data —
quem responde "qual versão é esta" é o cabeçalho do plugin, e quem responde "o artefato
mudou" é o `sha256` do lock. E uma dependência a mais do build em duas ferramentas de linha
de comando que ele já usava (`find` e `touch`), com o achado nomeado quando qualquer uma
delas falha.

**Como reverter.** Tirar o `touch` devolve os bytes instáveis, e
`pacote.reserva_identica_ao_avulso` reprova dizendo que as entradas têm carimbos
diferentes; tirar o `TZ=UTC` não é acusado por esta bancada — ela roda numa máquina só —, e
é por isso que o motivo está escrito no código, ao lado da chamada.

---

## 38. O carimbo do artefato publicado sai do relógio de vez, e a ordem das entradas sai do sistema de arquivos (origem: implantador 1.7.4, decisão nº 112)

**Decidido.** O zip do plugin deixa de ter qualquer entrada tirada do ambiente. Duas
metades, e uma sem a outra continua produzindo o mesmo defeito com outro nome:

- **O carimbo de cada entrada é uma ÉPOCA FIXA DECLARADA** — `1980-01-01 00:00:00 UTC` —,
  produzida por `f3b_epoca_do_zip()`, em `suite/lib/empacotar.php`, com o motivo ao lado.
  Ela é lida por dois lugares e só existe num: o empacotamento, que a aplica com `touch`, e
  `suite/lib/sonda-bundle.php`, que confere o artefato MONTADO contra ela.
- **A ordem das entradas é DECLARADA**, crescente por byte. A lista é montada em PHP por
  `f3b_entradas_do_zip()`, ordenada com `sort( …, SORT_STRING )` e entregue ao `zip` por
  `-@`, no lugar do `zip -qrX` que recursava sozinho.

**Por quê. O defeito tem dois braços, e os dois foram medidos.**

O primeiro é o relógio. A 1.7.3 declarou o zip reprodutível e o que ela entregou durava um
dia: o carimbo era `gmdate( 'Y-m-d', floor( time() / 86400 ) * 86400 )`, o relógio
arredondado ao dia. Uma árvore foi empacotada, arquivada inteira, extraída noutro lugar e
reempacotada — `diff -r` limpo, conteúdo byte a byte idêntico — e os bytes do zip mudaram:

```
entregue em 05/09     693ca754ab5bc337e8786c4959c346c6342dd04804f577d597bf57fea3d42a31
reconstruído em 06/09 aeb40cadf2598e87814c5adaaae1a80138c89434d1f364f25fc142356a3bf94c

carimbo da 1ª entrada   2026-09-05 00:00
carimbo da 1ª entrada   2026-09-06 00:00
```

O segundo é o sistema de arquivos, e ele nunca tinha sido medido. `zip -r` grava as
entradas na ordem em que o diretório as devolve, e essa ordem é do VOLUME: num ext4 ela vem
do hash do nome com a semente daquele volume, num tmpfs vem da ordem de criação. Medido
nesta bancada, mesma árvore, MESMO dia, dois volumes da MESMA máquina:

```
ext4    693ca754ab5bc337e8786c4959c346c6342dd04804f577d597bf57fea3d42a31
tmpfs   855fabbbf41416640542b25e7aa262bef8980a002a0a993893e4fc0b02ed7d15
```

A 1.7.3 escreveu que `TZ=UTC` fazia "a mesma árvore montada em duas máquinas" dar os mesmos
bytes. O fuso era uma das portas. Esta era a outra, e ela estava aberta.

**POR QUE ISSO É MAIS GRAVE DO QUE "o hash do pacote não fecha duas vezes igual", QUE FOI
COMO A 1.7.3 LEU O PROBLEMA.** Este zip é PUBLICADO no catálogo — `plugins.instalaveis.0`,
origem `url`, sem `sha256` declarado — e `F3Base_Imp_Plugins::veredito_do_digest()` **FIXA
o digesto dele na primeira observação** e reprova a execução seguinte quando ele muda, com
a frase invertida: *"a origem não mudou entre as execuções"* vira *"DIGESTO DIVERGENTE do
fixado … NADA foi instalado"*. Republicar amanhã um zip de conteúdo idêntico, reconstruído
da mesma fonte, faz **toda implantação seguinte falhar acusando troca de artefato que não
houve** — em todo site que já observou o artefato uma vez.

**A RÉGUA DA DECISÃO 84 FOI APLICADA E O PROPÓSITO DELA FOI DERROTADO.** O comentário da
1.7.3 invoca a decisão 84 e diz que a régua dela — precisão de DIA, em UTC — é a que se
aplica aqui. A decisão 84 existe para que um operador comparando dois digests legítimos não
conclua adulteração; a aplicação literal dela produziu exatamente esse falso alarme, e
automatizado, dentro do gate que instala plugin. **Precisão de dia serve a um registro que
alguém LÊ. Não serve a um artefato cujo digesto é a chave de uma comparação entre
execuções.** Ali qualquer granularidade tirada do relógio é uma bomba com pavio de 24
horas, e a única resposta certa é o relógio não entrar.

**POR QUE ÉPOCA FIXA, E NÃO CARIMBO DERIVADO DO CONTEÚDO.** As duas saídas foram pesadas.

O carimbo derivado — o mtime mais novo entre os arquivos-fonte, por exemplo — carrega
alguma informação, e foi **recusado**: mtime de arquivo é reescrito por qualquer cópia de
árvore. `git clone`, `cp` sem `-a`, extração de um tar, um checkout de CI: em todos, os
mtimes passam a ser a hora da cópia, e o carimbo volta a dizer "quando esta máquina tocou
nestes arquivos" em vez de "o que estes arquivos são". É a MESMA classe de defeito que
criou o problema original — o estágio nascia com a hora de agora —, movida de lugar. E o
argumento de que ele "carrega informação" não sobrevive à pergunta seguinte: informação
para quem? Nenhum caminho deste pacote lê a data das entradas deste zip. Quem responde
"qual versão é esta" é o cabeçalho do plugin; quem responde "o artefato mudou" é o `sha256`
do lock e o digesto fixado no host.

A época fixa é o que sobra, e ela é honesta pela mesma razão que parece um defeito: **o
carimbo deixa de dizer qualquer coisa sobre quando o pacote foi montado, e ele já não
dizia** — até a 1.7.3 ele dizia "meia-noite do dia da montagem", um instante que nunca
existiu, e que o operador poderia ler como hora de build.

**O INSTANTE ESCOLHIDO É `1980-01-01 00:00:00 UTC`, E A ESCOLHA É PARTE DA DECISÃO.** Ele é
o zero do formato zip — a menor data que o carimbo DOS representa. Uma época plausível
(`2020-01-01`, digamos) reintroduziria pela metade o mal-entendido que esta decisão fecha:
alguém leria aquilo como uma data. O zero do formato não é lido como data por ninguém.

**A VARREDURA DOS OUTROS ARTEFATOS EMPACOTADOS, e o que ficou de fora COM MOTIVO.**

- **`dist/implantador-base-<versão>.zip`, o bundle.** As entradas dele continuam com o
  carimbo da cópia do estágio, e ele NÃO é reprodutível byte a byte — nem entre dias, nem
  dentro do mesmo dia. **Fica como está**, e o motivo é o teste desta decisão: o digesto do
  bundle não é chave de comparação entre execuções. Ninguém o busca por URL, ninguém o fixa
  na primeira observação; o operador faz upload dele, e a integridade do que chegou é
  medida pelo `hash do pacote` sobre a ÁRVORE INSTALADA, contra o `suite/rodada.json` que
  viajou dentro dela. Fixar a época das entradas dele compraria zero e custaria uma coisa
  cara: um sinal de "reprodutível" num artefato que não é, porque ele carrega, por desenho,
  dois registros que respondem *quando* — `suite/rodada.json` (precisão de segundo) e
  `suite/fases.json` (precisão de dia).
- **O zip que `suite/lib/sonda-instalacao.php` monta** para exercitar o caminho de
  instalação. Ele nasce e morre dentro da rodada, nunca é publicado e nunca é fixado por
  ninguém. Fica como está.
- **Os zips de `suite/fixtures/`.** São arquivos estáticos da árvore, não saída de build.

**O QUE FOI MEDIDO SOBRE O SELO, E O QUE SOBRA DE VARIAÇÃO — NOMEADO.** O `hash do pacote`
soma o `sha256` de cada arquivo do corpo do bundle, e a reserva do plugin viaja lá dentro:
com o zip estabilizado, aquela entrada parou de mexer o número. **Sobra uma fonte, e ela é
`suite/fases.json`**, que está dentro da soma e traz `"em": <dia>` mais o dia da última
execução de cada fase. Medido, com a árvore idêntica e o relógio movido de verdade: a
rodada cujo registro trazia `2026-09-06` fechou em `c4f76e82…`; a primeira rodada depois de
o registro passar a trazer `2026-09-20` fechou em `c1c9a21a…`; a rodada seguinte, no mesmo
dia, repetiu `c1c9a21a…`. **O número muda uma vez por dia, uma rodada DEPOIS de o dia
virar** — porque o registro que entra no bundle é o da rodada anterior, que é o quinto
preço já declarado na decisão 84.

**E ISSO FICA COMO ESTÁ, PELO MESMO CRITÉRIO QUE MOVEU O ZIP.** `suite/fases.json` é um
registro que alguém LÊ: ele responde "quando a fase de navegador rodou pela última vez", e
isso é pergunta de calendário. O digesto que ele move não é fixado contra nenhum artefato
REPUBLICADO — o host compara a árvore instalada com o registro que viajou dentro dela, e as
duas coisas mudam juntas. Apagar o dia dali para "estabilizar o hash" tiraria a única
informação que aquele arquivo existe para dar.

**O PISO MOVE O MUNDO EM VOLTA DO BUILD, E ESSA É A METADE QUE FALTAVA NA 1.7.3.** O piso
antigo era uma lista mutante de carimbos passada a uma função pura — ele provava que a
regra sabia reprovar, e não provava nada sobre o artefato. O piso desta release roda o
EMPACOTAMENTO REAL de novo, quatro vezes, com as duas alavancas que só existem de fora do
processo:

- **o relógio**, movido por `faketime`, que move `time()` do PHP e o `touch` do coreutils
  juntos: montar em `2026-09-05` e em `2029-02-17` tem de dar os mesmos bytes;
- **o volume**, trocado apontando a saída para outro sistema de arquivos (`/dev/shm`):
  montar no ext4 e no tmpfs tem de dar os mesmos bytes.

**E O MUTANTE É O QUE PROVA QUE A ALAVANCA TEM DENTE.** `suite/lib/sonda-bundle.php` copia
o `suite/lib/empacotar.php` REAL, troca UMA linha e roda o empacotamento por essa cópia:
com o carimbo de volta ao relógio — o código da 1.7.3 —, as duas montagens PRECISAM
divergir e o teto PRECISA acusá-las; com a ordem de volta ao `readdir`, as montagens nos
dois volumes PRECISAM divergir e o teto da ordem PRECISA acusá-las. Se o mutante passa, o
piso está medindo a si mesmo, e a linha sai dizendo isso com todas as letras: *"o relógio
não se moveu de verdade e todo este piso está medindo a si mesmo, não o empacotamento"*.
**Medido:** com o `faketime` retirado da chamada, essa exata linha aparece — é assim que se
sabe que o piso não é encenação.

**O que custa.** Cinco preços.

O primeiro: **`faketime` virou pré-condição do comando único**, ao lado de `php`, `node`,
`zip` e `unzip`. Máquina sem ele fecha `BLOCKED suite.ambiente` com o recurso nomeado, e a
rodada inteira não acontece. É caro, e é a única forma honesta: o piso que sustenta a
afirmação central desta release não pode ser opcional, porque uma afirmação de
reprodutibilidade sem piso já durou um dia e quebraria a implantação seguinte de todo site.

O segundo: **a bancada precisa de um segundo sistema de arquivos gravável** para a metade
que mede a ordem. Ela procura `/dev/shm`, `/run/shm` e o temporário do sistema, e quando
nenhum está noutro dispositivo a linha sai dizendo, com o nome, que aquela metade **não
rodou**. Não é silêncio, e também não é BLOCKED: é achado, porque escopo vazio não aprova.

O terceiro: **o carimbo das entradas do zip mente sobre o tempo, de propósito.** Quem abrir
o zip vê 1980. É o preço de o carimbo não dizer nada em vez de dizer algo errado, e ele só
não dói porque nenhum caminho do pacote lê essa data.

O quarto: **a ordem das entradas do zip mudou**, e com ela os bytes do artefato. O CONTEÚDO
não mudou — `diff -r` limpo entre o extraído da 1.7.3 e o desta release, as mesmas 47
entradas, o mesmo digesto de conteúdo. Mas o digesto dos BYTES mudou uma última vez:
`693ca754…` → `1748c984…`. **Todo site que já observou o artefato anterior vai reprovar na
próxima execução**, com a mensagem de digesto divergente do fixado — e a saída está escrita
nela: declarar o novo `sha256` na entrada, ou apagar o registro fixado daquele slug e
reexecutar. É a última vez que isso acontece, e é justamente o que esta decisão existe para
não acontecer de novo.

O quinto: **o empacotamento ganhou dependência de mais uma leitura de disco** — a lista de
entradas do estágio — e um arquivo de trabalho em `dist/`, apagado logo em seguida. A lista
é montada em PHP e não por `find | sort` por uma razão medida: `exec()` roda por `sh`, o
`sh` desta base é o `dash`, o `dash` não tem `pipefail`, e num cano o código de saída é o do
ÚLTIMO comando — um `find` que falhasse deixaria o `zip` fechar um arquivo incompleto com
código 0.

**Como reverter.** Devolver o carimbo ao relógio — trocar `f3b_epoca_do_zip()` por
`gmdate( 'Y-m-d', … time() … )` — reprova em três frentes: o teto do carimbo acusa que o
carimbo veio do relógio e não da declaração, o piso das duas montagens acusa que a mesma
árvore em dois dias deu bytes diferentes, e o mutante do carimbo deixa de divergir e a
linha diz que o piso passou a medir a si mesmo. Devolver a ordem ao `readdir` — tirar o
`sort( $entradas, SORT_STRING )` — reprova pelo teto da ordem e pelo piso dos dois volumes.
Tirar `faketime` da lista de pré-condições não é acusado por nenhuma checagem, porque a
ausência dele já é BLOCKED antes de qualquer checagem rodar: é o próprio comando único que
recusa, e é por isso que o motivo está escrito ali, ao lado do laço.

---

<!-- transcrito:fim -->

## Parte II — as decisões desta release

Cada uma abaixo nasceu de um DEFEITO MEDIDO, e a frase do caso real está transcrita no lugar
onde ela foi produzida — no registro da frente, no log da bancada ou no veredito da revisão.
Nenhuma delas é uma linha do registro de correções: uma linha é um achado, e o que vira
decisão é a REGRA que o achado obrigou a escrever. Onde uma regra fechou vários achados, eles
estão citados juntos.

## 39. A suíte do plugin é EXTRAÍDA, e a rodada zero é a prova da extração

**Decidido.** A suíte deste repositório não foi escrita: ela foi **extraída** da suíte do
implantador, levando as checagens cujo OBJETO é o plugin e deixando as outras onde elas
estão. A extração só é aceitável com três provas, e as três moram no repositório:

- **`suite/excluidas.tsv`** — toda checagem da referência que NÃO entrou aqui, com a
  categoria e o motivo em uma frase. Os motivos são de OBJETO (a checagem mede o
  implantador, o tema ou o conteúdo editorial), de ÂNCORA (a regra é geral, mas o ponto de
  partida dela não existe aqui), de ESCOPO VAZIO (a mesma função, apontada para a árvore do
  plugin, mede zero unidade) e de TABELA (a declaração que a alimenta não tem nenhuma linha
  sobre o plugin);
- **`suite/correcoes/rodada-0.diff.tsv`** — nome, estado na referência, estado nesta suíte e
  se são iguais, para toda checagem do conjunto extraído, rodando sobre a fonte INTACTA;
- **`suite/correcoes/rodada-0.mutacoes.md`** — três defeitos plantados na cópia, um por vez,
  com o comando, a linha que acusou e a reversão byte a byte.

**O defeito medido.** A frase que originou tudo isto está no veredito da revisão, e ela é
sobre o instrumento, não sobre o produto:

```
O plugin não está OK para distribuição. […] A suíte fecha 224 linhas com 0 FALHA sobre
esse mesmo código.
```

Uma suíte que fecha verde sobre uma desinstalação que morre em erro fatal e sobre uma rota
pública que responde erro de servidor não está medindo o que ela diz medir. Extrair essa
suíte sem provar o que sobrou seria carregar a mesma cegueira para um repositório novo, com
o agravante de que ninguém mais teria a referência ao lado para comparar. A terceira prova
é a que fecha o argumento: **detector que nunca foi visto acusando é uma afirmação sobre a
intenção de quem o escreveu**, e a mutação que a produziu deixou esta linha:

```
FALHA   js.ciclo_de_vida_da_pagina   — TETO do envio único (só pagehide, o navegador que
não emite o outro): a aba mandou 0 resumo(s). Um por carregamento, sempre
```

**A checagem que prova.** `manifesto.bidirecional` e `armadilhas.mapeadas`, que cruzam nos
dois sentidos o que a rodada emitiu com o que as tabelas declaram — rótulo emitido sem
requisito nem armadilha que o justifique é achado, e requisito apontando para checagem que a
rodada não emitiu também. E `estatica.piso_em_sonda_declarado`, que recusa declarar coberta
uma checagem cuja sonda não traz os dois ramos escritos.

**O que custa.** A cobertura encolheu, e o número está na região gerada `excluidas` do
`MANIFESTO.md`. O que se perde é a medição do PAR: uma regra compartilhada continua sendo
medida dos dois lados, mas por duas suítes que podem divergir. O conserto para isso é do
repositório do implantador, e está escrito lá.

**Como reverter.** Uma checagem de `excluidas.tsv` volta junto com o objeto dela, ou junto
com a mudança de detector que a faz medir alguma coisa aqui — e mudança de detector vem com
o piso que a prova. Não existe caminho de "trazer de volta para aumentar a contagem".

---

## 40. A bancada WordPress real é uma classe de evidência, e não um teste a mais

**Decidido.** O comando único ganha uma etapa que instala o zip recém-montado num
**WordPress de verdade**, descartável, com SQLite pelo drop-in, e pergunta ao produto o que
ele faz. Cada passo emite uma linha `wp.<passo>` na classe de evidência **`wp-real`**, e o
piso de cada um é um **plugin instalado com o defeito dentro** — um patch sobre a fonte,
declarado em `suite/bancada-wp/pisos.tsv`.

A classe de evidência é o ponto. Sem ela, o relatório não distingue "rodou contra um `wpdb`
de mentira" de "rodou contra o WordPress", e as duas linhas verdes parecem a mesma coisa.

**O defeito medido.** Oito defeitos que a suíte inteira não via, e que apareceram na
primeira vez que o plugin foi instalado num núcleo de verdade. Três deles, com a frase do
caso:

```
com o plugin desativado (como o WordPress roda o uninstall):
  Class "F3Base_Vocabulario" not found — "There has been a critical error"

full=true + uma página com conteúdo → GET /llms-full.txt HTTP 500
  debug.log: preg_split(): Argument #3 ($limit) must be of type int, float given

wp_get_abilities() só devolve as três do núcleo; simulando o gancho certo, o núcleo ainda
recusa: "The ability properties must contain a `category` string"
```

Nenhum deles é sutil. Todos eram invisíveis porque a bancada anterior roda o código real
sobre um `wpdb` de mentira e stubs do núcleo: o stub de `wp_trim_words` declara
`(string, int)` e não reproduz o estouro, e `wp_register_ability` simplesmente não existia
ali.

**A checagem que prova.** As linhas `wp.*` da bancada, cada uma com o mutante declarado, e
`bancada.ambiente`, que fecha **BLOCKED nomeando o recurso** quando o cache não tem o insumo
e a rede não o entrega. Ambiente que não pôde medir não aprova pacote, e por isso a etapa
não tem ramo de "pulou e está tudo bem": o interruptor `F3BASE_SEM_BANCADA` põe cada passo
em N/A dizendo, com todas as letras, que quem chamou o comando a desligou.

**O que custa.** A rodada ficou mais lenta e passou a depender de insumos de fora — núcleo,
drop-in e `wp-cli` —, que vivem num cache fora do repositório. Numa máquina sem cache e sem
rede, a etapa inteira fecha BLOCKED, e a rodada deixa de poder aprovar o pacote.

**Como reverter.** Tirando a etapa de `suite/verificar.sh` e movendo as linhas `wp.*` para
`suite/excluidas.tsv` com o motivo. É reversível e não deveria ser revertido: os oito
defeitos acima são a medida do que se perde.

---

## 41. Lote com eventos e sem métricas é o caso NORMAL, e não a saída curta

**Decidido.** A rota de comportamento valida o registro **antes** da resposta curta, e "nada
a somar" passa a exigir as DUAS listas vazias — os agregados e os acionamentos. A falha de
gravação passa a responder por lista, para que um lote só de acionamentos não seja reprovado
por não ter somado um agregado que ele não trouxe.

**O defeito medido.** Este é o mais caro da release, porque ele descarta dado em rota normal
e o cliente coopera com o descarte:

```
POST com `eventos` e `metricas:[]` → HTTP 200, f3base_eventos fica em 0
o mesmo lote com uma métrica    → 201 e 1 linha
```

O cliente manda `metricas: []` em toda partição depois da primeira e em todo lote posterior
ao primeiro selamento do carregamento. Com resposta `2xx` ele apaga o lote. Ou seja: a
segunda, a terceira e a quarta ocorrência de cada visita — exatamente a série que a medição
de comportamento existe para produzir — eram descartadas em silêncio, com a tela mostrando
verde e a tabela crescendo devagar demais para alguém desconfiar.

**A checagem que prova.** `wp.lote_sem_metricas_gravado`, na bancada real, com o mutante
`suite/bancada-wp/mutantes/lote_sem_metricas_gravado.patch`, que descreve o defeito na
linguagem de quem opera:

```
faz a rota sair com 200 "nada a somar" assim que metricas vem vazia, sem olhar para
eventos: o lote que o cliente despacha em toda particao depois da primeira e descartado,
e com 2xx o cliente o apaga
```

O passo saiu de `positivo-pendente-de-correcao` para `coberto` com esta correção: antes
dela, o mutante era a própria fonte.

**O que custa.** A rota faz mais trabalho antes de responder — a validação do registro passou
para antes da saída curta —, e o corpo da resposta ganhou um campo por lista. Nada disso é
mensurável no tempo de resposta de um beacon.

**Como reverter.** Devolvendo a saída curta ao topo da rota. O mutante já faz exatamente
isso, e é por isso que ele existe: a reversão é uma linha, e a linha está escrita.

---

## 42. O apelido do visitante nasce DEPOIS de uma decisão, e o portão negado o apaga

**Decidido.** Três metades da mesma regra:

1. **O apelido só nasce com decisão explícita do titular, com política de negativa por
   padrão, ou no modo pré-aprovado COM o aviso de primeira visita ligado.** Quem decide é
   `podeIdentificar()`, no cliente, a partir do que o servidor publica: a política vigente e
   se o aviso existe.
2. **O portão negado APAGA o apelido guardado**, e a exclusão é disparada no carregamento,
   lendo o apelido do armazenamento e não da memória.
3. **`aviso_primeira_visita` passa a nascer LIGADO** no padrão da option de consentimento, e
   o impacto do campo diz por quê: com a política pré-aprovada, é este aviso que autoriza o
   apelido a nascer.

**O defeito medido.** Dois achados que se combinam num terceiro:

```
A-13  `pre-aprovado` sem banner grava apelido e registro antes de qualquer decisão;
      a tela diz "sessões com consentimento"
A-14  portão negado não apaga f3base_visitante; o re-aceite religa o histórico anterior
```

O primeiro é uma afirmação falsa na tela sobre dado pessoal: o quadro dizia "sessões com
consentimento" contando sessões em que ninguém consentiu. O segundo é pior e é silencioso:
quem recusou continuava com o apelido no navegador, e um aceite posterior — meses depois —
religava a série inteira de antes da recusa, como se a recusa nunca tivesse existido.

A terceira metade nasceu da correção das duas primeiras: com o aviso entregue DESLIGADO, um
site pré-aprovado passaria a somar o agregado e a não produzir registro detalhado nenhum. A
regra estaria certa e o site sairia cego.

**A checagem que prova.** `js.resumo_da_sessao` (os quatro casos da regra, mais a decisão
explícita pelo evento de consentimento), `consentimento.estrategia_pela_politica`,
`medicao.menu_proprio` (a tela diz qual política vigora, lida do módulo) e
`estatica.campo_operavel_tem_impacto_e_exemplo` (o impacto do sub-campo explica a
dependência).

**O que custa.** Um site pré-aprovado que decidir desligar o aviso passa a não ter registro
detalhado — e isso é correto, mas é uma perda de medição que alguém pode não esperar. O
custo está declarado no impacto do campo, que é onde quem for desligá-lo vai ler.

**Como reverter.** O padrão do sub-campo é uma linha do catálogo de options, e a política é
uma chave do site. Reverter a regra do apelido, porém, é reverter a decisão nº 1 na direção
oposta à que ela mesma declarou como exposta.

> **Revertida na `1.0.0` de distribuição por decisão do operador** — ver decisão nº 74.

---

## 43. O dia das DUAS tabelas sai do MESMO carimbo

**Decidido.** A âncora do lote é calculada ANTES da primeira escrita e o dia entra como
parâmetro em `somar()`: a linha do agregado e a linha do registro detalhado do mesmo lote
caem no mesmo dia.

**O defeito medido.**

```
A-7  somar() usa gmdate('Y-m-d') (chegada) enquanto registrar_evento() usa
     gmdate('Y-m-d', $criado_em) (acionamento); o docblock promete o contrário
```

Um lote selado às vinte e três e cinquenta e oito e entregue depois da virada — o caso comum
de quem fecha a aba e o navegador despacha na retomada — somava no agregado de HOJE e
registrava o acionamento em ONTEM. As duas tabelas da mesma tela passavam a discordar sobre
o mesmo lote, e a discordância só aparece perto da virada, que é onde ninguém procura.

**A checagem que prova.** `medicao.carimbo_do_acionamento`, com um lote da véspera na sonda:
origem de ontem, chegada de agora, e o dia exigido igual nas duas tabelas.

**O que custa.** `somar()` deixou de decidir o próprio dia e passou a receber o de quem
chamou — o que é mais acoplamento, e é a troca certa: o dia é do LOTE, e não de quem o
grava.

**Como reverter.** Devolvendo a chamada de calendário para dentro de `somar()`. A decisão
nº 34, herdada, já pagou a metade desta conta no registro detalhado; esta a estendeu ao
agregado.

---

## 44. O agregado é PÚBLICO, e por isso tem teto por entrada e orçamento de visita

**Decidido.** Todo campo numérico de uma entrada do corpo tem teto DECLARADO, e não só a
lista tem tamanho máximo: a contagem tem o teto por página do evento, o valor e a soma têm o
teto por medida declarado em `dados/vitais.tsv`, e as cortadas têm o orçamento da visita. A
fila de lotes pendentes no cliente ganhou teto próprio, descartando os MAIS ANTIGOS e
contando as linhas deles como cortadas.

**O defeito medido.**

```
A-12  contagem/soma/valor sem teto: qualquer visitante envenena o agregado com o token
      público
A-16  guardarVisita() serializa a fila inteira a cada evento; sem teto de lotes
```

A rota é pública e autorizada por um token efêmero impresso em toda página. Sem teto por
entrada, uma única requisição escreve um número arbitrário na coluna de soma, e o quadro da
tela — que é média — passa a mostrar qualquer coisa. O envenenamento não deixa rastro de
erro: ele é uma linha válida com um número grande.

**A checagem que prova.** `comportamento.teto_por_entrada`, com os dois ramos em cada campo —
o limite exato passa, o limite mais um é recusado PELO NOME e com o limite na resposta — e
`js.resumo_da_sessao` para o orçamento da visita no cliente.

**O que custa.** Medição legítima acima do teto é recusada. É por isso que o teto da soma é
o do valor VEZES a contagem, e não um número escolhido: um teto apertado demais recusaria a
página que de fato rolou muito.

**Como reverter.** Os tetos são declarados — o teto por página em
`dados/eventos-comportamento.tsv`, o teto por medida em `dados/vitais.tsv` —, e afrouxá-los é
editar a declaração, não o código.

---

## 45. A tela Medição declara o recorte que a consulta FEZ

**Decidido.** A tela deixa de afirmar recorte que a consulta não fez. Filtro fora da forma do
apelido é descartado na tela e ANUNCIADO como ignorado; o aviso de período só aparece quando
o painel de fato passa do prazo do registro, com os dois números e a escolha declarada; a
frase do fuso tem produtor único no módulo; e o quadro das medidas de carregamento passou a
existir de verdade, com a explicação e a régua de cada sigla lidas da declaração.

**O defeito medido.** Quatro achados da mesma família — a tela dizendo mais do que mediu:

```
A-11  filtro `visitante` inválido na tela: frase afirma o recorte, consulta devolve tudo
A-17  dias_no_painel não é amarrado a retencao_eventos_dias: dois quadros da mesma coisa
      divergem sem frase
A-18  vitais_declarados(), resumo()['vitais'], chaves_do_periodo(), visitantes_por_dia()
      sem chamador — a tela de vitais prometida não existe
A-9   média dos vitais exclui linhas com soma=0 e o balde ignora `metrica`
```

O primeiro é o mais caro: "Mostrando apenas o visitante joao@exe" impresso acima de uma
tabela com TODOS os visitantes. Quem lê conclui que aquela pessoa fez tudo aquilo.

**A checagem que prova.** `medicao.tela_declara_o_recorte`, `medicao.quadro_de_vitais` e
`medicao.menu_proprio`, todas com piso na própria sonda: o filtro bem formado recorta e é
anunciado, o mal formado não é anunciado como recorte e sai NOMEADO como ignorado, e nenhuma
explicação declarada aparece escrita dentro do PHP da tela.

**O que custa.** Quatro funções sem chamador foram REMOVIDAS em vez de ganharem um. A
alternativa — escrever a tela que elas prometiam — era maior do que a release, e código sem
chamador é pior do que ausência: ele parece cobertura.

**Como reverter.** As funções removidas estão no histórico, e a tela de vitais que a
correção construiu lê a declaração — quem quiser outra tela troca a tela, não a declaração.

---

## 46. Um despacho por lote, e o que não foi confirmado não é esquecido

**Decidido.** O cliente mantém uma lista de lotes EM VOO por identidade e recusa despachar de
novo um lote cuja resposta ainda não chegou; o lote sai da lista na resposta, no erro e no
ramo que cai para o beacon. O pedido de exclusão passa a usar `fetch` com `keepalive` e
confirmação, com o beacon como reserva só onde `keepalive` não existe: as chaves locais só
somem com resposta confirmada, e o pedido não confirmado fica guardado e é reenviado no
carregamento seguinte.

**O defeito medido.**

```
A-2  guarda `resumoEnviado` sobe e desce na mesma execução; visibilitychange+pagehide
     despacham o mesmo lote duas vezes
A-5  esquecerVisitante() só usa sendBeacon, sem confirmação, e apaga o apelido local
     antes de saber se o servidor apagou
```

Os dois são o mesmo erro em direções opostas: o primeiro conta duas vezes o que aconteceu
uma, e o segundo declara apagado o que talvez não tenha sido. O segundo é o mais grave, e é
sobre dado pessoal: o titular vê a confirmação, o servidor não recebeu o pedido, e não sobra
nada que diga isso a ninguém.

**A checagem que prova.** `js.ciclo_de_vida_da_pagina` e `js.resumo_da_sessao`, com a bancada
respondendo `pendente` — a resposta que NÃO chega. Sem esse ramo, todo despacho concluía
antes do evento seguinte e o defeito era invisível na bancada e visível no navegador.

**O que custa.** O cliente guarda mais estado, e a fila de pendentes ocupa espaço no
armazenamento local — limitado pelo orçamento da decisão nº 44.

**Como reverter.** Removendo a lista de lotes em voo. O piso desta decisão é exatamente
essa remoção, feita em memória contra a bancada.

---

## 47. A reserva do cliente é o NÚMERO da declaração

**Decidido.** As reservas de `histerese_pp`, `cliques`, `janela_ms` e `raio_px` no cliente
passam a ser os números da declaração de eventos, e a regra "reserva igual à declaração"
virou detector com fixture em disco.

**O defeito medido.**

```
A-24  reserva 0 de histerese_pp é a menos conservadora (remove a banda)
```

A declaração ganhou banda de histerese para que o marco de rolagem não rearmasse na própria
linha — o defeito que a decisão nº 25 fechou. A reserva do cliente, para o caso de o limiar
não vir declarado, era zero: exatamente o comportamento que a banda existe para impedir.
Reserva não é um valor neutro; ela é o que vale quando a declaração falha, e escolhê-la na
direção menos conservadora desfaz a decisão sem tocar nela.

**A checagem que prova.** `tracking.eventos_de_comportamento_declarados`, com a fixture
negativa plantando a reserva zero contra a declaração de cinco.

**O que custa.** A regra vale para o NÚMERO. A reserva vazia de `limiar()` continua sendo a
decisão declarada de não emitir, e isso é uma exceção que precisa continuar escrita para não
virar achado.

**Como reverter.** A reserva é lida da declaração; mudar o número é mudar
`dados/eventos-comportamento.tsv`, que é onde ele deve ser mudado.

---

## 48. O token do endpoint tem ESCOPO e vida curta, e a página em cache tem tratamento

**Decidido.** A assinatura do token efêmero passa a cobrir a rota e o caminho da página — sem
a query —, com vida de uma hora e teto no filtro. Nasce uma rota GET de emissão, sem nonce
porque o token é público por natureza, limitada pelo MESMO balde do registro; o cliente troca
o token e reenvia uma vez. E a recusa por token passa a CARIMBAR a atividade com a página.

**O defeito medido.**

```
B-5  token efêmero assina só a expiração, 12 h, impresso em toda página: bearer público;
     página em cache > 12 h faz todo beacon voltar 403 sem sinal na tela; o mesmo token
     autoriza `esquecer`
```

São três defeitos numa chave só. Um token sem escopo colhido em qualquer página autorizava
qualquer POST por meio dia. Uma página servida de um cache mais velho que o prazo fazia TODO
beacon voltar recusado — e o módulo continuava verde na tela, de modo que um site podia estar
perdendo lead há semanas sem sinal nenhum. E o mesmo token que autoriza registrar autorizava
APAGAR.

**A checagem que prova.** `leads.token_com_escopo` e `js.conversao_multicanal`. O mutante
devolve escopo constante, prazo de doze horas e carimbo removido, e o passo acusa os três; a
fonte anterior do cliente não pede token novo nem reenvia.

**O que custa.** Uma rota pública a mais, e um caminho de reenvio no cliente. A barra final e
a query NÃO distinguem escopo, e a segunda é a que importa: incluir a query faria todo lead
de tráfego pago voltar recusado.

**Como reverter.** O prazo é filtro e o escopo é uma função do módulo. Reverter o escopo
devolve o bearer público.

---

## 49. A conversão de SERVIDOR passa pelo MESMO portão do navegador

**Decidido.** O agendamento do evento de servidor da Meta recebe o portão do consentimento
como primeiro parâmetro e recusa, NOMEANDO o motivo, quando ele não permite tags. O endpoint
mede o estado uma vez e passa a resposta.

**O defeito medido.**

```
B-1  endpoint-leads.php:481 agenda F3Base_Modulo_Meta_Capi::agendar() sem consultar
     consentimento; agendar() só confere token e pixel. O payload leva `em`, `ph`,
     `client_ip_address`, `fbc`, `fbp`
```

O navegador respeitava a recusa e o servidor não. Quem recusou medição via o Pixel calar e o
evento sair mesmo assim, por trás, com o e-mail e o telefone em hash, o endereço de rede e os
cookies de atribuição. Não é uma falha de tag: é o dado do titular saindo por um caminho que
a decisão dele não alcançava.

**A checagem que prova.** `leads.capi_meta`, com o mutante que faz o agendamento voltar a
ignorar o consentimento — o passo acusa o agendamento sob recusa.

**O que custa.** O site perde a metade de servidor da conversão para quem recusou, que é
exatamente o que a recusa pede. O portão é o MESMO do navegador, respondido a partir do
estado já medido na requisição: duas leituras do mesmo cookie na mesma requisição podem
divergir.

**Como reverter.** Tirando o parâmetro do agendamento. Reverter isto é reabrir o caminho que
a decisão nº 14 dizia estar fechado.

---

## 50. O carregador é SEMPRE servido, e o portão fica no cliente

**Decidido.** O enfileiramento do carregador de tags deixa de ler o cookie: ele é servido
sempre que há destino, e o portão das tags de fornecedor fica no cliente. O cliente do CTA
passa a declarar dependência do script de consentimento.

**O defeito medido.**

```
B-12  o <script> de tracking depende de $_COOKIE no render, sem Vary/DONOTCACHEPAGE:
      cache de página congela a decisão do primeiro visitante
B-11  f3base-leads sem dependência declarada do script de consentimento
```

Uma página em cache é servida a todo mundo com a decisão de quem a gerou. O primeiro
visitante recusa e o site inteiro para de medir; o primeiro visitante aceita e quem recusar
depois continua sendo medido até o cache expirar. As duas saídas conhecidas custam caro:
`Vary: Cookie` fragmenta o cache em três versões por visitante, e `DONOTCACHEPAGE` desliga o
cache da página — as duas pagam com desempenho de todos por uma decisão que o navegador sabe
tomar.

**A checagem que prova.** `tracking.consentimento_gateia_tudo`, com o mutante que devolve a
guarda ao enfileiramento — o passo acusa o carregador ausente — e outro que esvazia a lista
de dependências.

**O que custa.** O carregador é baixado por quem recusou. Ele é inerte, e o preço é um
arquivo pequeno; o preço da alternativa é o cache do site inteiro.

**Como reverter.** Devolvendo a guarda ao enfileiramento, que é o mutante.

---

## 51. O consentimento arquivado é o estado MEDIDO, num vocabulário de três valores

**Decidido.** O estado do consentimento gravado no lead passa a vir de um vocabulário fechado
de três valores — decisão de sim, decisão de não, e a ausência de decisão sob a política
pré-aprovada. O valor declarado pelo cliente entra só pela metade restritiva, e os dois
destinos de lead recebem o mesmo.

**O defeito medido.**

```
B-10  consentimento: true (default sem f3baseConsentimento, e granted no pré-aprovado sem
      decisão) vira _f3base_consentimento = sim em todo lead
```

O campo booleano que o cliente manda é o PORTÃO das tags, e ele vale verdadeiro quando
ninguém decidiu. Arquivá-lo como "sim" põe em todo lead do site uma decisão do titular que
nunca existiu — e é esse campo que alguém leria numa auditoria para saber se havia
consentimento.

**A checagem que prova.** `leads.registro_fiel_ao_recebido` e `leads.booleano_explicito`, com
o mutante que devolve o ternário de dois valores: o passo acusa os três casos e a perda de
distinção.

**O que custa.** Um valor a mais para quem lê o registro. Ausência de decisão sob política de
negativa por padrão continua sendo "não", e não um quarto valor: ali não há consentimento
nenhum.

**Como reverter.** O vocabulário é uma função do módulo de consentimento, com produtor único.

---

## 52. Limite publicado é limite APLICADO

**Decidido.** A rota publica apenas os limites que ela aplica. O máximo da atribuição passou a
ser a quantidade de chaves do schema, e é conferido.

**O defeito medido.**

```
B-15  limites_publicos() publica limites que ninguém aplica
```

Um cliente que respeita um limite publicado e um servidor que não o recusa formam um contrato
que só existe de um lado. No dia em que outro cliente — ou o mesmo, com um defeito — passar
do limite, nada acontece, e a descoberta é pela tabela crescendo com o que não deveria caber.

**A checagem que prova.** `leads.limite_por_caractere`, que varre TODO campo publicado e exige
recusa no limite mais um: um limite publicado a mais no futuro cai nela sozinho.

**O que custa.** Publicar menos. O que sai da lista publicada é exatamente o que não era
verdade.

**Como reverter.** A lista publicada é uma função do módulo, e a checagem passa a cobrar
qualquer entrada nova nela.

---

## 53. A origem confiável exige FAIXA declarada, e chave ausente é nunca confiar

**Decidido.** A declaração de origem confiável ganha as redes confiáveis, e o cabeçalho de
proxy só é lido quando o endereço que chegou está numa delas. Chave ausente é nunca confiar,
e a comparação é em binário. A frase que descreve os saltos passou a dizer que é POSIÇÃO
contada do fim.

**O defeito medido.**

```
B-8   cabeçalho de proxy confiável sem lista de IPs de proxy: quem contorna a CDN escolhe
      o balde e o client_ip_address da Meta
B-18  frase de `saltos` descreve count - saltos - 1; código faz count - saltos
```

Um cabeçalho de proxy é escrito por qualquer cliente. Sem conferir de ONDE a requisição
chegou, quem alcança a origem por fora da CDN escolhe o próprio endereço — e com isso escolhe
o balde do limite de taxa, que passa a ser contornável, e o endereço que viaja para o
fornecedor no evento de servidor.

**A checagem que prova.** `leads.origem_declarada`, com o mutante que desliga a conferência
da faixa: o passo acusa o cabeçalho lido de um pedido que contornou a CDN.

**O que custa.** Um site atrás de CDN precisa declarar as faixas dela. Sem faixa declarada o
cabeçalho NÃO é lido — e essa é a posição segura, porque a falha fecha em vez de abrir.

**Como reverter.** A lista de faixas é uma option do catálogo, sanitizada pelo ponto único do
módulo. Esvaziá-la volta a contar pelo endereço direto.

> **Alterada na `1.0.0` de distribuição por decisão do operador** — ver decisão nº 75.

---

## 54. Reserva que falha SEM reserva anterior é falha, e não duplicata

**Decidido.** A reserva de deduplicação que falha sem reserva anterior atrás dela responde com
erro NOMEADO, com a reserva compensada e a atividade carimbada. O discriminante é a
EXISTÊNCIA da reserva anterior.

**O defeito medido.**

```
B-7  INSERT da reserva com suppress_errors falhando por outro motivo vira
     200 duplicado:true, record_id:""
```

O erro do banco era lido como "já existe": qualquer falha de escrita virava uma duplicata
inventada, com resposta de sucesso e sem identificador. O cliente recebe confirmação, o lead
não existe em lugar nenhum, e não há linha de log dizendo isso.

**A checagem que prova.** `leads.reserva_compensada`, com o mutante que desliga o ramo novo:
o passo acusa a resposta de sucesso duplicada com identificador vazio.

**O que custa.** Um caminho de erro a mais na rota. A duplicata de verdade continua sendo
duplicata, e isso tem piso próprio.

**Como reverter.** Removendo o ramo. A decisão nº 4, herdada, declarou a disciplina da
reserva; esta fechou o caso em que ela mentia.

---

## 55. A leitura pela origem devolve o cabeçalho COMO ELE VEIO

**Decidido.** Cabeçalho repetido sai como LISTA e escalar sai como texto. O destino de
conveniência aponta para o primeiro endereço de redirecionamento.

**O defeito medido.**

```
B-6  rota-origem: array_map('strval') sobre cabeçalhos repetidos → "Array" + warning
```

A palavra `Array` no lugar do valor, e um aviso no log. Quem lê essa rota é um agente
diagnosticando o próprio site: ele recebe a palavra `Array` onde deveria estar o conjunto de
cookies que o servidor mandou, e não tem como saber que houve mais de um.

**A checagem que prova.** `origem.cabecalho_como_veio`, com o mutante que devolve a conversão
antiga — o passo acusa a palavra `Array`.

**O que custa.** Quem consome a rota passa a receber dois formatos no mesmo campo. Achatar a
lista numa cadeia com vírgula seria uma terceira forma, que nem o servidor emitiu nem a
camada de transporte entregou.

**Como reverter.** Uma função do módulo, com produtor único.

---

## 56. Desinstalar leva as TRÊS tabelas, e o que fica é declarado

**Decidido.** `uninstall.php` carrega o ARQUIVO PRINCIPAL do plugin — que é onde a lista de
arquivos mora —, e o bootstrap desse arquivo não registra hook nenhum quando a constante de
desinstalação está definida. As três tabelas próprias saem, e os nomes delas vêm das
constantes dos módulos que as criam. A lista de options descartáveis passa a ser declarada no
catálogo, pelas âncoras do gravador único.

**O defeito medido.** Dois achados que se somam no pior desfecho possível de uma
desinstalação:

```
C-1     uninstall.php faz require_once só de class-f3base-options.php; catalogo()
        referencia F3Base_Vocabulario e F3Base_Llms sem autoload → fatal
        com o plugin desativado (como o WordPress roda o uninstall):
          Class "F3Base_Vocabulario" not found, "There has been a critical error"

A-3/C-3 uninstall.php derruba f3base_leads_dedup e f3base_comportamento e não
        f3base_eventos — a tabela com visitante, sessao, criado_em
```

A desinstalação morria antes de remover coisa nenhuma, e a tabela que sobrevivia é a que
guarda o apelido do visitante, o identificador de sessão e o carimbo de cada acionamento.
Uma tabela órfã com dado pessoal pseudonimizado, sem plugin nenhum para lê-la, apagá-la ou
responder por ela.

**A checagem que prova.** `wp.desinstalacao_limpa`, na bancada real, rodando a desinstalação
como o núcleo a roda — plugin inativo, processo novo, constante definida — com o mutante
`desinstalacao_limpa.patch`, que devolve o require de uma classe só.

**O que custa.** A desinstalação carrega o plugin inteiro. É mais trabalho num processo que
roda uma vez, e é a única forma de a lista de arquivos ser UMA: uma segunda lista de require
aqui adiaria o mesmo defeito para o dia em que um padrão do catálogo citasse mais uma classe.

**Como reverter.** FICA por decisão declarada, e a declaração está no cabeçalho do arquivo:
os registros de lead, o journal de eliminação e as options de configuração. Desinstalar um
plugin não é um pedido de eliminação de dado pessoal, e a remoção do que fica tem rota
própria, com capability e journal.

---

## 57. Segredo é campo MASCARADO e EDITÁVEL, e a máscara alcança as duas saídas

**Decidido.** O catálogo ganha o tipo de campo `segredo`, e ele é renderizado como campo de
senha com preenchimento automático desligado: o valor nunca é reimpresso, vazio no envio
significa manter, e existe uma caixa própria para apagar. A leitura de volta e o relatório
mostram um MARCADOR.

**O defeito medido.**

```
C-2/D-7  f3base_meta_capi_token declarado com campo => 'texto'; a máscara de segredo testa
         'segredo' === campo
         token gravado aparece em claro em F3Base_Registro::relatorio() (servido por
         GET /wp-json/f3base/v1/relatorio) e no value= do <input> da tela
```

O token da Conversions API é uma credencial de longa duração da conta de anúncios. Ele saía
em claro no HTML da tela de administração e no corpo de uma rota de relatório — duas
superfícies diferentes, cada uma com o seu próprio conjunto de quem consegue lê-las.

**A checagem que prova.** `wp.token_capi_mascarado`, na bancada real, com o mutante que
devolve o tipo `texto` ao catálogo: a máscara deixa de cobri-lo e o valor volta a sair nas
duas saídas.

**O que custa.** Um tipo de campo a mais no catálogo e um caminho de "manter o que está" no
gravador. O marcador NÃO diz o tamanho: comprimento de credencial é informação sobre a
credencial.

**Como reverter.** É uma linha do catálogo, e o mutante já a escreve.

---

## 58. As três habilidades MCP existem num WordPress real

**Decidido.** O gancho passa a ser o do núcleo, com prefixo; nasce uma categoria própria,
registrada no gancho de categorias com rótulo e descrição e declarada nas três habilidades; o
schema de entrada passa a ser objeto e o de saída é declarado campo a campo; as chamadas de
permissão e de execução aceitam entrada nula. O manual do agente passa a DERIVAR do registro
o nome de toda option que cita, e a habilidade de escrita obedece às travas de sistema de
arquivos do núcleo e recusa, nomeando os dois, quando há mais de um implantador instalado.

**O defeito medido.** Dois defeitos independentes, e nenhum deles produzia erro visível:

```
as três habilidades f3base/como-usar, f3base/config-ler, f3base/config-escrever não existem
  wp_get_abilities() só devolve as três do núcleo; simulando o gancho certo, o núcleo ainda
  recusa: "The ability properties must contain a `category` string"

C-5  como-usar manda gravar f3base_tracking e f3base_leads, options que não existem
```

O canal MCP é o caminho pelo qual o site é modificado depois da entrega. As três habilidades
que o plugin registra para esse canal simplesmente não existiam: o gancho tinha a grafia
errada — que não existe no núcleo, de modo que a chamada de registro nunca acontecia — e, com
o gancho certo, o núcleo recusava uma a uma por falta de categoria. E o manual que o agente
lê antes de mexer mandava gravar duas options inexistentes: gravar uma option que módulo
nenhum lê não falha, não avisa e não muda nada.

**A checagem que prova.** `wp.habilidades_registradas`, com DOIS mutantes — um planta o gancho
sem prefixo, o outro tira só a categoria —, porque um mutante que plantasse os dois juntos não
provaria que o passo enxerga cada um. Mais `mcp.como_usar_sai_do_registro`, que deixou de
medir substring e passou a exigir a grafia exata, e `mcp.options_citadas_existem`, que cruza
toda grafia de option citada no manual com o catálogo declarado.

**O que custa.** Uma categoria própria no registro do núcleo, e o manual passa a depender do
registro de módulos — módulo novo aparece nele sozinho, e nome digitado deixa de ser possível.

**Como reverter.** Os dois mutantes são as duas reversões, e as duas estão em disco.

> **Corrigida na `1.0.0` de distribuição** — a forma que esta decisão deu ao schema de entrada derrubava duas das três habilidades ao serem chamadas; ver decisão nº 77.

---

## 59. O gravador único AVISA, RECUSA, PRESERVA e é IDEMPOTENTE

**Decidido.** Quatro regras no mesmo ponto de escrita:

1. **Recusa o valor fora da faixa declarada**, mantendo o anterior e nomeando o que o valor
   recusado faria. O mínimo passa a sair do catálogo, e é ele que a tela usa.
2. **Preserva a chave desconhecida DENTRO dos itens**, e não só no primeiro nível.
3. **Avisa por CAMPO**, nomeando os campos normalizados, e não só para escalares.
4. **É idempotente**: gravar compara o que sanitizou com o que releu, e a releitura sanitiza
   de novo — a segunda passagem tem de dar o mesmo resultado.

**O defeito medido.** Quatro achados, e o primeiro apaga dado do titular:

```
C-6   retencao_meses aceita 0 na tela (min="0"), o sanitizador eleva a 1 em silêncio e o
      cron do dia seguinte apaga leads
C-7   preservação de chave desconhecida só no 1º nível: ponto_de_contato[], servicos[],
      itens de llms perdem chaves
C-11  aviso de normalização só para escalares: 13 options de grupo descartam em silêncio
C-9   sanitiza_llms não é idempotente (politica_privacidade ausente → [] → objeto) e a
      leitura de volta acusa divergência
```

O primeiro é o mais caro e o mais silencioso: zero é o pedido de "não apagar nada", e ele era
elevado ao prazo mais CURTO possível — o oposto do que zero pede —, com a rotina do dia
seguinte apagando todo contato mais velho que um mês.

**A checagem que prova.** `options.normalizacao_avisa`, `options.chave_desconhecida_preservada`
e `options.sanitizador_idempotente`, com os pisos na própria sonda: gravar o valor bom, gravar
zero e exigir que a leitura devolva o valor bom e que o motivo diga RECUSADA; o reconstrutor
de chaves fixas tem de perder a chave desconhecida e a conhecida tem de continuar
normalizada; gravação limpa não pode produzir aviso.

**O que custa.** A escrita ficou mais cara — ela sanitiza, relê e compara — e o operador passa
a receber recusa onde antes recebia silêncio. As duas coisas são o ponto.

**Como reverter.** Cada regra é uma cláusula do gravador, e a decisão nº 8, herdada, declarava
só a metade da preservação. A exceção à preservação — o journal — está na decisão nº 61.

---

## 60. A PROVENIÊNCIA é de configuração, e não de toda escrita

**Decidido.** A option de proveniência passa a ser gravada sem carregamento automático,
registrada SÓ em gravação de configuração — estado de execução declarado no catálogo fica de
fora —, e a entrada preserva o resumo do valor e a marca do implantador quando o valor não
mudou.

**O defeito medido.**

```
C-10  toda gravar() reescreve f3base_proveniencia com autoload=true — inclusive a rota
      pública do beacon —, invalidando alloptions por visitante e apagando valor_hash/
      release gravados pelo implantador
```

Dois danos de naturezas diferentes na mesma linha. O de desempenho: a rota do beacon é a mais
chamada do pacote, e cada chamada dela invalidava o conjunto de options carregadas
automaticamente do site inteiro. O de registro: a marca de quem gravou cada valor — que é
para o que a proveniência existe — era apagada por uma escrita de carimbo de atividade, de
modo que o registro passava a dizer que ninguém tinha gravado nada.

**A checagem que prova.** `options.proveniencia_de_configuracao`, com os três ramos na sonda:
o registro de atividade não pode reescrever a option, o carregamento automático gravado tem
de ser falso, e a marca do implantador tem de sair quando o valor MUDA.

**O que custa.** A proveniência deixa de cobrir escrita de estado de execução — e ela nunca
deveria: o que ela responde é "quem configurou isto assim".

**Como reverter.** A distinção é declarada no catálogo, option por option. A classe de
atividade passou a gravar sem proveniência por consequência da declaração, sem que uma linha
dela fosse editada — o ponto único da decisão é o gravador.

---

## 61. O journal corta na ESCRITA, e o corte deixa entrada

**Decidido.** O sanitizador do journal DESCARTA campo desconhecido, como o docblock sempre
prometeu — é a exceção declarada à regra da decisão nº 59 —, e o teto deixa de ser aplicado na
leitura: ele é aplicado na ESCRITA, com o teto declarado no catálogo e uma entrada de corte
que diz QUANTAS saíram e DESDE QUANDO. A auditoria de escritas do canal ganhou o mesmo
tratamento e deixou de ser carregada automaticamente.

**O defeito medido.**

```
C-8   sanitiza_journal PRESERVA campos desconhecidos (o docblock diz que descarta) e corta
      em 500 descartando as mais antigas na leitura
C-22  f3base_mcp_files_audit sem teto e com autoload=true
```

Cortar na leitura deixa a lista inteira no banco e mostra um recorte dela: quem lê acha que
está vendo tudo. E o corte descartava as MAIS ANTIGAS, que numa lista de auditoria são
exatamente as que alguém procuraria. A auditoria do canal, sem teto e carregada
automaticamente, crescia a cada escrita e viajava dentro do conjunto de options em toda página
do site.

**A checagem que prova.** `options.journal_corta_na_escrita`, com a lista acima do teto
plantada no banco: ela tem de ser LIDA inteira, e a escrita tem de cortar e registrar a
entrada de corte.

**O que custa.** A exceção à regra "preserva o desconhecido" precisa continuar declarada, ou
ela vira contradição. O motivo é o que a sustenta: o journal existe para provar que o conteúdo
saiu, e campo desconhecido dentro dele é conteúdo que ninguém sabe de onde veio.

**Como reverter.** O teto é do catálogo e o corte é uma função do gravador.

---

## 62. O filtro de módulos NOMEIA a recusa

**Decidido.** Cada nome recusado pelo filtro de módulos sai por aviso do núcleo e como linha
do relatório e da tela, com o motivo e o que fazer. Módulo EMBUTIDO retirado pelo filtro
também sai nomeado.

**O defeito medido.**

```
C-24  filtro f3base_modulos descarta nome inválido em silêncio
```

O `continue` silencioso fazia quem acrescentasse um módulo pelo filtro descobrir o problema
pelo efeito que não aconteceu, dias depois. O filtro é o ponto de extensão do plugin; um
ponto de extensão que recusa sem dizer nada ensina quem o usa a desconfiar dele.

**A checagem que prova.** `modulos.callbacks_executam` e `wp.home_servida`, mais o relatório e
a tela nomeando a recusa.

**O que custa.** Uma linha a mais no relatório de um site que usa o filtro. É o preço de o
ponto de extensão responder.

**Como reverter.** É o ramo de recusa do registro único.

---

## 63. O contrato de nomes é FRONTEIRA lida e escrita, e a renomeação sai de cena

**Decidido.** A option de proveniência e a de chaves operáveis entram no contrato de nomes
como FRONTEIRA lida e escrita, com o motivo; o cabeçalho deixa de dizer que ninguém do outro
lado as lê. E o prefixo interno do plugin **não muda mais**: o arquivo principal declara isso
com o motivo, e a renomeação de prefixo deixa de ser um caminho vivo neste artefato.

**O defeito medido.**

```
C-20  contrato declara f3base_proveniencia como "ninguém do outro lado lê" — o plugin lê e
      escreve; f3base_operaveis (gravada pelo implantador, lida pelo plugin) ausente do
      contrato
```

Renomear qualquer uma delas de um lado só faz a procedência inteira virar "padrão embutido"
na tela e a tela abrir TODOS os campos operáveis do catálogo — sem erro nenhum. É o mesmo
defeito que a decisão nº 33 fechou para as options do catálogo, aparecendo nas duas chaves que
ninguém tinha olhado porque elas não são configuração.

A segunda metade é uma subtração: o achado que pedia derivar o prefixo do censo pressupunha o
fork por site, e ele não existe mais. Nome de pasta é ENDEREÇO, nome de option é CHAVE DE
DADO, nome de tabela apaga série histórica e nome de evento quebra a série na conta do
fornecedor. O prefixo fica.

**A checagem que prova.** `renomeacao.contrato_de_nomes_completo`, que lê o que o contrato
precisa cobrir do catálogo do próprio plugin e da declaração de eventos — nada de lista
escrita à mão —, e `estatica.sem_residuo_de_prefixo`. O piso é a mesma função contra um
contrato de onde uma grafia exigida foi tirada.

**O que custa.** Um site derivado não pode mais trocar o prefixo interno. Ele pode trocar
tudo o que é apresentação; o que não pode é trocar a chave do dado.

**Como reverter.** O contrato é um TSV do plugin, lido por três lugares. Reabrir a renomeação
exigiria de volta a ferramenta e as duas listas de exceção, que estão na decisão nº 33.

---

## 64. O `llms.txt` cruza a chave com o plugin ATIVO, e o texto integral não publica o protegido

**Decidido.** Quatro correções no mesmo assunto:

1. **Quem responde "o plugin de SEO está ativo?" é um produtor único**, e as duas regras que
   dependiam disso passam a perguntar a ele em vez de repetirem a leitura da chave.
2. **A enumeração pede conteúdo sem senha** e descarta no laço o que tem.
3. **O texto integral não passa mais um corte de palavras infinito** para a função do núcleo.
4. **Cada rota tem carimbo de atividade e mecanismo próprios**, e a precedência da primeira
   frase é a que a tela promete.

**O defeito medido.**

```
D-1  llms-full-txt.php chama resumo_limpo($corpo, PHP_INT_MAX) → wp_trim_words →
     preg_split($limit = PHP_INT_MAX + 1) = float → TypeError fatal (PHP 8.1+)
     full=true + uma página com conteúdo → GET /llms-full.txt HTTP 500

D-2  concorrente_de_llms()/sitemap_medido() leem só a option wpseo, que sobrevive à
     desativação do Yoast: /llms.txt vira 404 permanente com estado "ativo"

D-9  enumerar() sem has_password => false: post protegido entra no llms.txt e no
     llms-full.txt
```

O terceiro é o mais grave dos três, e é de privacidade: o corpo inteiro de uma página
protegida por senha saía em texto puro numa rota pública, para leitores automáticos.

**A checagem que prova.** `wp.llms_full_responde` e `wp.llms_nao_publica_protegido`, na
bancada real, com mutante cada um; `seo.llms_emissor_cruza_plugin`, `seo.llms_carimbo_por_rota`
e `seo.llms_primeira_frase_declarada` na sonda.

**O que custa.** A leitura do estado do plugin de SEO passou a cruzar a chave gravada com a
lista de plugins ativos, que é uma leitura a mais por requisição das duas rotas.

**Como reverter.** Os mutantes de cada uma estão em disco, e cada um desfaz exatamente uma
das correções.

---

## 65. O redirect não gira, e a resposta de removido TERMINA a requisição

**Decidido.** A normalização vira regra pura e pública, e o comparador normaliza os DOIS lados
e recusa o par que normaliza igual, nomeando-o. A recusa foi para a ESCRITA — o gravador único
recusa o par que gira —, e não para o sanitizador de leitura: leitura que descarta apaga em
silêncio o que alguém gravou. E o ramo de conteúdo removido passou a terminar a requisição,
com corpo mínimo de texto puro.

**O defeito medido.**

```
D-3   sanitizador de f3base_redirects recusa de === para em texto cru; casar_declarado()
      normaliza barra final e query → par /servicos/ → /servicos passa e gira para sempre
      GET /servicos/ → 301 /servicos → 301 /servicos … cinco redirecionamentos e continua

D-20  ramo 410 sem exit: corpo da página servido com status 410
```

O primeiro é o que o navegador chama de "redirecionamentos demais": a página deixa de existir
para o visitante e para o buscador, e o sanitizador tinha aceitado o par porque comparava os
textos crus. O segundo é o inverso — a página inteira servida sob o status que diz que ela foi
removida.

**A checagem que prova.** `wp.redirect_nao_gira` e `wp.redirect_410_termina`, na bancada real,
com mutantes; `redirects.par_que_gira_recusado` na sonda. O mutante do primeiro desfaz as DUAS
metades, porque uma metade sozinha não reproduz o laço.

**O que custa.** Um par legítimo que difira só pela barra final passa a ser recusado na
escrita, com o motivo. Ele não era legítimo.

**Como reverter.** A normalização é uma função pura do módulo, chamada pelo gravador.

---

## 66. A retenção cumpre o prazo que DECLARA, e registra o que apaga

**Decidido.** Seis correções na mesma rotina:

1. **O corte conta meses de CALENDÁRIO**, e a frase de estado diz a data de corte.
2. **Sem lixeira disponível a rota recusa o regime operacional**, nomeando a constante do
   núcleo, e a rotina não arquiva.
3. **A eliminação definitiva em lote registra entrada no journal**, com o prazo reversível
   zerado.
4. **O exportador e o eliminador do núcleo PAGINAM**, e o fim só é declarado na página
   incompleta.
5. **A rotina devolve os restantes**, com teto declarado, e o módulo degrada enquanto houver
   fila.
6. **Os laços de desagendamento têm teto declarado** e conferem o retorno.

**O defeito medido.**

```
D-21  MONTH_IN_SECONDS é trinta dias: "12 meses" viravam 360 dias, e o registro era apagado
      cinco dias antes do prazo
D-4   com EMPTY_TRASH_DAYS em zero, wp_trash_post() apaga em definitivo e a rota respondia
      reversivel:true sobre registro que já não existia
D-5   a única escrita irreversível da rotina não deixava linha no journal
D-12  eraser/exporter do núcleo limitados a 500 registros com done => true: o titular
      recebia resposta incompleta declarada completa pelo próprio núcleo
D-22  o lote de 200/dia carimbava o mesmo número todo dia como se estivesse em dia
```

Os cinco são sobre a mesma coisa: uma rotina que apaga dado pessoal afirmando prazos que ela
não cumpre. O quarto é o mais delicado, porque quem declara a resposta completa é o núcleo do
WordPress respondendo a um pedido do titular.

**A checagem que prova.** `wp.retencao_sem_lixeira`, `wp.retencao_definitiva_no_journal`,
`wp.retencao_declara_o_backlog` e `wp.privacidade_pagina_o_titular` na bancada real, cada uma
com mutante; `retencao.corte_em_calendario` e `retencao.desagendamento_com_teto` na sonda.

**O que custa.** O prazo passou a ser maior em dias do que era — meses de calendário são mais
longos que meses de trinta dias —, e a rotina deixou de declarar-se em dia quando não está.
Um módulo degradado aparece na tela, e é o que se quer.

**Como reverter.** Cada uma das seis é local e tem mutante ou ramo de sonda próprio.

> **Alterada na `1.0.0` de distribuição por decisão do operador** — ver decisão nº 76.

---

## 67. Os cabeçalhos COMPÕEM, validam a forma e alcançam o REST

**Decidido.** A decisão de emissão vira regra pura: a política de conteúdo sai compondo com o
que já está lá, e os demais só saem quando ausentes. O que foi cedido a outro emissor é
carimbado e sai nomeado nos avisos. A forma da diretiva de ancestrais de quadro é validada, e
o módulo não emite o cabeçalho fora dela — preservando o valor gravado e avisando. O
vocabulário passa a declarar os conjuntos das duas chaves que faltavam, e o gravador único
recusa o valor fora deles, nomeando o campo. E os cabeçalhos passam a ser emitidos também nas
respostas da API, com o recorte que faz sentido em JSON.

**O defeito medido.**

```
D-13  header() com $replace padrão substitui CSP/Referrer/Permissions de outro emissor
D-14  csp_frame_ancestors por sanitize_text_field: `;` injeta diretivas CSP
D-15  permissions_policy e csp_frame_ancestors fora do vocabulário no runtime
D-27  send_headers não cobre REST: o corpo JSON saía sem nosniff
```

O primeiro derruba a proteção de quem chegou antes — um plugin de segurança instalado no site
tem os cabeçalhos dele substituídos pelos nossos, em silêncio. O segundo é injeção: um ponto e
vírgula no valor gravado acrescenta diretivas à política inteira.

**A checagem que prova.** `seguranca.cabecalho_cede_a_quem_chegou_antes`,
`seguranca.frame_ancestors_na_forma`, `seguranca.cabecalhos_alcancam_rest` e
`vocabulario.cabecalhos_governados`, todas com piso na sonda.

**O que custa.** O carimbo do que foi cedido só é gravado quando o CONJUNTO cedido muda: essa
função roda em toda resposta, e escrever uma option por visitante seria trocar um cabeçalho
por uma escrita.

**Como reverter.** A decisão de emissão é uma função pura, e a decisão nº 10 declarava a
metade dela — o valor emitido é o valor gravado. Esta acrescentou quem cede a quem.

---

## 68. O FAQ só é lido em requisição SINGULAR, e a lista de perfis é UNIÃO

**Decidido.** A leitura do FAQ ganha guarda de requisição singular quando o identificador não
é informado; com identificador explícito, a leitura fora do laço continua valendo. E o
docblock da extensão de organização passou a dizer que a lista de perfis é UNIÃO, e que a
regra de "só chave ausente" vale para as demais propriedades.

**O defeito medido.**

```
D-8   faq_da_pagina() sem is_singular(): em arquivo de termo/autor emite FAQ de outro post
      o id do TERMO e o do AUTOR colidem com id de post: o arquivo da categoria 12 emitia
      o FAQ do post 12

D-24  sameAs sempre reescrito, docblock diz "só chave ausente"
```

O primeiro publica, no dado estruturado de uma página de categoria, as perguntas e respostas
de um artigo que não tem nada a ver com ela — e o buscador lê isso como declaração do site. O
segundo é uma incoerência entre o que o código faz e o que ele diz fazer: as DUAS leituras
estavam erradas, e a certa é a união.

**A checagem que prova.** `schema.faq_so_no_singular` e `schema.same_as_une`, na sonda.

**O que custa.** Nada de comportamento no segundo caso — a correção foi da descrição. No
primeiro, uma guarda a mais numa leitura que roda em toda página.

**Como reverter.** Cada uma é local ao módulo de extensão de schema.

---

## 69. A ativação agenda no PRÓPRIO processo

**Decidido.** A instalação registra o filtro de recorrências no PROCESSO da ativação, e os
dois módulos que agendam só gravam a previsão quando o agendamento devolve verdadeiro.

**O defeito medido.**

```
D-10  cron_schedules é registrado em init:5; activate_{plugin} dispara depois →
      wp_schedule_event('f3base_mensal') devolve false, e guardar_previsao() grava
      `previsto` mesmo assim
      no processo da ativação: next_scheduled=false, estado.previsto=1788728997,
      f3base_mensal existe? false
```

No processo da ativação o núcleo conhece só as recorrências dele, e a nossa não existe ainda.
O agendamento falhava, a previsão era gravada sobre um agendamento que devolveu falso, e a
tela passava a mostrar uma data de próxima execução para um evento que não estava agendado.
Ele se autocorrigia na requisição seguinte — o que torna o defeito ainda pior, porque ele
some antes de alguém investigar.

**A checagem que prova.** `wp.cron_na_ativacao`, na bancada real, num processo em que o plugin
NASCE inativo — a única forma de observar a ordem real entre a inicialização e a ativação —,
com o mutante que tira o registro das recorrências do gancho de ativação. Mais
`cadencia.previsao_so_com_evento` na sonda.

**O que custa.** O filtro de recorrências passa a ser registrado em dois lugares: no ciclo
normal e no processo da ativação. É a mesma função, chamada de dois pontos.

**Como reverter.** O mutante desfaz exatamente isto, e a decisão nº 5 declarava as
recorrências sem dizer em que processo elas nascem.

---

## 70. As quatro classes partilhadas VÊM PARA CASA, e a dependência inverte

**Decidido.** As quatro regras que os dois runtimes leem — o contrato de chaves de SEO, o
vocabulário comum, a regra do emissor concorrente e o censo de conteúdo demonstrativo — e a
declaração de emissores conhecidos passam a MORAR neste repositório. Elas vêm todas guardadas
por verificação de classe existente, os docblocks passam a dizer que o implantador VENDORIZA
uma cópia, e a afirmação de que o censo não usa nada do WordPress saiu — ele usa.

**O defeito medido.**

```
D-18  class-f3base-censo-demonstrativo.php sem class_exists: fatal quando os dois runtimes
      carregam caminhos diferentes
D-19  quatro arquivos partilhados afirmam morar em fontes/plugin/includes/; moram em
      partilhado/; o vocabulário diz que o censo "não usa WordPress" e ele usa $wpdb
```

O primeiro é um erro fatal: um processo que carregue os dois runtimes morre em "Cannot declare
class". Era a única das quatro sem a guarda. O segundo é o documento e o código discordando
sobre onde as classes moram — e, com a mudança de repositório, as duas frases ficaram falsas
de um jeito novo.

**A checagem que prova.** `partilhado.contrato_declarado`, na sonda, e
`pacote.plugin_completo_no_zip`, que confere que TODO arquivo da lista de autoload está dentro
do zip: cinco deles são estes.

**O que custa.** O implantador passa a depender de uma cópia vendorizada, que diverge se
ninguém a conferir. Conferi-la contra o zip publicado é trabalho do repositório dele, e está
declarado lá. A decisão nº 31 apontava a dependência no sentido oposto.

**Como reverter.** Devolver as classes a um diretório do implantador reabre o problema que a
decisão nº 31 fechou, agora com o plugin sendo artefato próprio — ele deixaria de poder ser
montado sozinho.

---

## 71. O que fica de FORA desta release, e por quê

**Decidido.** Cinco achados não foram corrigidos, e cada um tem o motivo escrito no registro
da frente. Decisão de não mudar também é decisão.

- **Inteiro de trinta e dois bits.** O carimbo de milissegundo estoura num PHP menor. Em vez
  de carregar uma segunda representação do instante atravessando três funções e uma coluna do
  banco, a PLATAFORMA passou a ser exigida: o cabeçalho declara `EXIGE PHP DE 64 BITS`, e a
  declaração entra no carimbo gerado dos três documentos do repositório.
- **Multisite.** A desinstalação limpa o site corrente; não há laço por blog. Em vez de
  prometer uma limpeza que ela não sabe fazer, a ativação em rede é RECUSADA com o motivo, e o
  cabeçalho declara `INSTALAÇÃO ÚNICA, NÃO MULTISITE`.
- **Forks anteriores à separação do artefato.** A marca de cópia anterior é o namespace REST
  literal, e um fork renomeado não casa. O conserto não é código: um fork renomeado já não
  reivindica o mesmo namespace, e por isso as duas cópias não colidem nas rotas. O que resta é
  instrução manual, e inventar aqui uma lista de nomes de pasta só reconheceria o que alguém
  lembrou de escrever nela.
- **Dois achados que dependem do Yoast instalado.** As metatags de verificação sem medir
  emissor concorrente, e a duplicação de meta robots. Separar o caso real do hipotético exige
  o plugin de terceiro NA BANCADA, e a bancada desta release sobe sem plugin de terceiro.

**O defeito medido.** O achado que originou o primeiro item está escrito assim:

```
A-21  time()*1000 estoura em PHP 32 bits
```

**A checagem que prova.** As duas primeiras exigências são declaradas no cabeçalho e chegam
aos documentos pelo carimbo gerado, conferido por
`estatica.carimbo_de_release_nos_documentos`; a recusa da ativação em rede é exercitada por
`wp.ativacao_sem_aviso` e `wp.desinstalacao_limpa`. As duas últimas não têm checagem, e é
exatamente isso que o registro declara.

**O que custa.** Um site em PHP de trinta e dois bits e um multisite não podem usar este
plugin. Os dois estão escritos onde o WordPress os mostra: no cabeçalho.

**Como reverter.** Cada item tem o caminho escrito. O do Yoast é o mais barato: instalar o
plugin de terceiro na bancada e escrever os dois passos.

---

## 72. A `1.0.0` sucede a `1.0.1` por BYTES, e não por número

**Decidido.** A versão de distribuição chama-se `1.0.0`. As duas anteriores — a `1.0.0` de
teste e a `1.0.1` — nunca saíram desta máquina, e o que distingue a release publicada é o
CONTEÚDO do artefato, medido pelo `sha256` que a rodada sela, e não a ordem dos números.

**O defeito medido.** A consequência foi medida antes de a decisão ser tomada, e ela é o custo:

```
version_compare não distingue a 1.0.0 nova da 1.0.0 de teste. O implantador troca mesmo
assim: artefato_identico() exige versão igual E hash do diretório igual, e o zip novo tem
outro hash. O atualizador do WordPress nunca verá a nova como atualização — só o
implantador a instala.
```

E a segunda consequência, que é a que precisa estar escrita para não surpreender ninguém: a
linha que compara a versão instalada com a que o pacote carrega fecha OK com versão igual —
**ela deixa de ser capaz de acusar uma instalação de teste**.

**A checagem que prova.** `pacote.zip_reprodutivel`, que é o que torna o `sha256` uma chave
utilizável: sem reprodutibilidade, "por bytes" não seria um critério, seria uma loteria. E o
selo em `suite/rodada.json`, que grava o digesto do artefato que a rodada montou, lido de
volta do disco depois de gravado.

**O que custa.** Todo site que já executou o implantador fixou o digesto de uma das duas
anteriores. Publicar bytes novos no mesmo endereço reprova a execução seguinte com "digesto
divergente do fixado" até que o novo seja declarado no catálogo — o que é o comportamento
certo, e o passo está no `README.md`.

**Como reverter.** Numerar a próxima como sucessora desta. A decisão nº 36 declarava a
derivação única do fato "a versão instalada é a que este pacote carrega", e ela continua de
pé — o que esta decisão registra é que, nesta release, aquela linha não acusa.

---

## 73. Os QUATRO documentos entregáveis são gerados, e a memória tem duas partes

**Decidido.** `README.md`, `MANIFESTO.md`, `MEMORIA-DECISOES.md` e
`fontes/plugin/INSTRUCOES-DO-PLUGIN.md` são ENTREGÁVEIS, e os quatro carregam regiões
GERADAS por leitura de disco na primeira etapa do comando único. Nenhum número fora delas é
digitado à mão. E esta memória tem duas partes explicitamente delimitadas: um bloco
TRANSCRITO, com as decisões herdadas copiadas palavra por palavra e com a origem declarada em
cada título, e as decisões desta release.

**O defeito medido.** Dois, e o segundo é o que explica a forma:

```
E   26 números digitados fora dos blocos gerados apesar da frase "nenhum número é digitado";
    10 contradições internas entre o documento e o código dentro do mesmo zip

(implantador) da 1.0.6 à 1.0.13 os três documentos ficaram carimbados 1.0.6, afirmando
uma decisão superada como se fosse a vigente. Sete releases passaram por cima disso sem
que nada acusasse.
```

O primeiro é o documento do plugin afirmando, em prosa, que não tem número digitado — e tendo
vinte e seis. O segundo é a razão de a região gerada existir: correção pontual de número
envelhece de novo na release seguinte, e já envelheceu sete vezes.

A transcrição verbatim é a outra metade da decisão. Reescrever uma decisão herdada para
"atualizá-la" inventaria um passado que não aconteceu: ela foi tomada com aquelas palavras,
sobre aquele pacote, e o valor dela para quem lê hoje é justamente não ter sido ajustada
depois. O que esta release acrescenta a uma decisão herdada é uma NOTA no fim, com a forma
declarada, apontando para a decisão que a superou — sem apagar uma linha do texto.

**A checagem que prova.** `estatica.carimbo_de_release_nos_documentos`, que compara cada
região com a medição de agora nos quatro documentos, com piso em disco que planta uma região
divergente em cada um; `doc.numero_digitado`, que varre a prosa dos quatro com a regra do
número e cobra a forma do índice de decisão, da nota de superação e da declaração de origem
dentro do bloco transcrito; `doc.afirmacao_conferida`, que mede as afirmações de comportamento
declaradas contra o que o pacote faz; e `pacote.instrucoes_do_plugin_no_zip`, que continua
sendo só sobre o documento que viaja dentro do zip.

**O que custa.** Escrever prosa nestes quatro documentos ficou mais caro: número em prosa é
recusado, e o que é limite do código sai em vão de código com a grafia da fonte. É o preço de
o documento não poder mentir sem que alguém saiba.

**Como reverter.** A lista de documentos e regiões é uma função só, em
`suite/lib/documentos.php`, e o detector cobra por ela. Tirar um documento da lista é tirá-lo
do alcance do gerador — que é exatamente o estado em que os três estavam quando o defeito
aconteceu sete vezes.

---

## 74. O apelido do visitante nasce com a POLÍTICA, e a frase da tela é que estava errada

**Decidido.** Revertidas as decisões nº 42 e a parte dela que mexeu no padrão da option de
consentimento. O apelido volta a nascer sempre que o portão do consentimento permite:

1. **Política pré-aprovada** — nasce no primeiro carregamento.
2. **Política de negativa por padrão** — nasce no aceite, e no instante dele.
3. **Recusa no controle do rodapé** — apaga o apelido no navegador e pede a exclusão do
   registro no servidor.
4. **Chegada com o portão já fechado** — não apaga nada, e não pede exclusão nenhuma.

`podeIdentificar()` continua existindo com esse nome — `suite/afirmacoes.tsv` amarra a frase
do documento a ela — e passa a responder só pelo portão. `aviso_primeira_visita` volta a
nascer desligado e volta a governar uma coisa só: a faixa mostrada na primeira visita. O
servidor deixa de publicar o aviso ao cliente e continua publicando a política.

**O que originou.** A decisão do operador, sobre um pacote que ele opera. O raciocínio dela:
a política pré-aprovada é decisão de projeto, declarada em `config/decisoes.tsv` pelo
implantador; o controle de recusa existe no rodapé de TODA página publicada; e a política de
privacidade do site descreve a coleta. Exigir, além disso, um banner para que o identificador
possa existir deixava o site cego POR OMISSÃO — o agregado somando e o registro detalhado
inexistente — sem que a política tivesse mudado, e sem que ninguém ligasse a ausência de dado
à caixa desmarcada em outra tela.

**O que se corrige, e é o único resíduo que fica.** A tela Medição afirmava, em todo site, que
contavam "só as sessões com consentimento". Num site pré-aprovado ninguém consentiu nada: a
frase prometia uma decisão do visitante que não houve. Ela passa a dizer que contam as sessões
em que a política vigente — nomeada, lida do módulo de consentimento — permitiu medir, e que
quem recusou no controle do rodapé fica de fora. Era uma AFIRMAÇÃO falsa, e afirmação se
corrige onde ela está escrita.

**A checagem que prova.** `js.resumo_da_sessao`, com os quatro casos acima e o mutante do
apelido nascendo sob o portão negado — as duas guardas removidas de uma vez, porque o portão
guarda o nascimento em dois lugares de propósito; `medicao.menu_proprio`, que exige a frase
nova nas duas políticas e recusa a volta da palavra que prometia consentimento; e
`navegador.comportamento_real`, que roda o cliente entregue num Chromium com o aviso
DESLIGADO — o caso exato em que a regra revertida e a anterior discordam.

**O que custa.** Duas coisas, e as duas foram aceitas por escrito. A primeira: num site
pré-aprovado o identificador do visitante passa a existir antes de qualquer clique dele, e o
que o justifica é a política declarada, não uma decisão individual. A segunda é consequência
da reversão da decisão nº 42 junto com a nº 14 daquela mesma frente: **quando o consentimento
voltar a permitir, o mesmo apelido religa a navegação nova ao histórico anterior**, porque ele
continua gravado no navegador. Quem quer o corte tem o controle do rodapé, que apaga dos dois
lados.

**Como reverter.** `podeIdentificar()` é o ponto único da regra, e ela cabe em uma linha. A
reversão completa acrescenta de volta a consulta ao aviso publicado pelo servidor, religa o
padrão do subcampo e reescreve os quatro casos da checagem — e reverte também a frase da tela,
que é a parte desta decisão que NÃO é sobre comportamento.

---

## 75. A faixa de proxy VAZIA confia como antes, e avisa

**Decidido.** Alterada a decisão nº 53. `f3base_origem_confiavel.redes_confiaveis` continua no
catálogo, com sanitizador por ponto único e comparação em binário, e continua sendo a proteção
que fecha o cabeçalho de proxy. O que muda é o que a lista VAZIA significa:

1. **Preenchida** — o cabeçalho declarado só é lido quando `REMOTE_ADDR` está numa das faixas;
   fora delas, a contagem volta ao endereço da conexão.
2. **Vazia** — o cabeçalho declarado é lido de qualquer conexão, como sempre foi, e `avisos()`
   do módulo de leads emite um WARN nomeando o risco e o campo que o fecha.

O módulo deixa de fechar DEGRADADO nesse caso: ele faz exatamente o que a configuração pede, e
degradado é reservado ao que está pior que o desenho.

**O que originou.** A recomendação escrita no plano da rodada, aceita pelo operador: **nenhuma
configuração existente quebra.** "Vazio é nunca confiar" é a posição segura para um pacote
novo, e é uma quebra silenciosa para um pacote que já está instalado. Um site com `cabecalho`
declarado e nenhuma faixa — que é o estado de toda instalação anterior a `1.0.1`, porque a
chave não existia — passaria, na atualização, a contar todos os visitantes no mesmo balde do
limite de envios e a mandar o endereço da CDN ao fornecedor de anúncio. Sem erro, sem aviso e
sem ninguém ter mexido em nada.

**A checagem que prova.** `leads.origem_declarada`, com os três ramos medidos um contra o
outro e dois mutantes opostos: "vazio = nunca confiar", que é o comportamento que esta decisão
reverte, e "preenchido e fora, ainda lê", que é o defeito que a decisão nº 53 fechou e que
continua fechado. Os dois foram plantados na árvore real e acusados — o registro está em
`suite/correcoes/R-mutacoes.md`.

**O que custa.** O risco de quem não declarou a faixa continua existindo: quem alcança a
origem por fora da CDN escolhe o balde do limite e o endereço enviado ao fornecedor. O preço
dele deixa de ser a proteção automática e passa a ser um aviso na tela, com o nome do campo
que o fecha — e o aviso tem ramo adverso, isto é, some quando a faixa é declarada.

**Como reverter.** A decisão inteira é a condição que testa se a lista está vazia, em
`origem()`, e ela cabe numa linha. Tirá-la volta ao comportamento da decisão nº 53, e o
mutante que a suíte já roda é exatamente esse.

---

## 76. Sem lixeira, a eliminação acontece e sai DECLARADA como definitiva

**Decidido.** Alterada a decisão nº 66, no ponto em que ela mandava recusar. Com
`EMPTY_TRASH_DAYS` em zero — a lixeira do WordPress desligada — o regime operacional da rota
de eliminação e a rotina diária PROSSEGUEM, apagando em definitivo, e dizem isso:

1. A resposta sai com `reversivel: false` e **sem** `reversivel_ate`.
2. A entrada do journal sai com regime operacional, `reversivel_ate` zerado e o motivo
   `sem lixeira neste host`.
3. A frase de estado do módulo diz que a eliminação neste site é definitiva e por quê, **sem**
   fechar degradado.

A recusa com o código de conflito sai. `lixeira_disponivel()` e `dias_de_lixeira()` ficam: é
por elas que as três coisas acima sabem o que dizer.

**O que originou.** A recomendação escrita no plano, aceita pelo operador. A recusa trocava um
defeito por outro, e o segundo é pior: para não escrever `reversivel: true` sobre um registro
que já não existia, ela deixava de apagar — e o prazo de retenção que a política de
privacidade do site PROMETE passava a não ser cumprido, com dado pessoal vencido guardado
indefinidamente e a rotina diária carimbando execução normal. Prometer uma janela que não
existe e guardar o que devia ter sido apagado são os dois lados errados; declarar o que foi
feito é o lado certo.

**A checagem que prova.** `wp.retencao_sem_lixeira`, na bancada WordPress real, exigindo as
quatro coisas — resposta bem-sucedida com `reversivel: false`, o registro fora do banco, a
entrada de journal marcada como definitiva e o módulo não degradado — e com DOIS mutantes
declarados em `suite/bancada-wp/pisos.tsv`, cada um plantando um dos lados errados: responder
`reversivel: true` sem lixeira, que é o defeito da `1.0.1`, e recusar sem eliminar nada, que é
o comportamento que esta decisão reverte.

**O que custa.** Num host sem lixeira, o regime operacional deixa de ter janela de reversão —
e ele passa a apagar sem volta em resposta a um pedido que, em outro host, seria reversível.
Quem opera precisa ler a resposta, e é por isso que ela e o journal e a tela dizem a mesma
coisa em três lugares. O journal ganhou um campo para isso: zero em `reversivel_ate` significa
duas coisas diferentes — a janela venceu, ou este host nunca teve janela —, e o motivo é o que
distingue as duas para quem lê meses depois. Ele diz por que, nunca o quê.

**Como reverter.** O ramo é uma condição em `eliminar()` e outra em `arquivar_expirados()`, as
duas perguntando a `lixeira_disponivel()`. Voltar à recusa é o mutante
`retencao_sem_lixeira_recusa.patch`, que a suíte já roda — e ele mostra, na mesma execução, o
que a reversão custaria: o registro vencido continua no banco.

---

## 77. O `properties` dos schemas de entrada é ARRAY, e a habilidade prova que executa

**Decidido.** Nos três schemas de entrada, `properties` é um array PHP com chaves de texto — e
em `como-usar`, que não recebe entrada, a chave não existe: `additionalProperties: false`
sozinho já diz "nenhum campo". A bancada WordPress real ganha o passo
`wp.habilidades_de_config_executam`, que chama `config-ler` e `config-escrever` com a entrada
que o próprio schema pede, como administrador e sem usuário, e chama `como-usar` com um campo
que o schema não declara.

**O defeito medido.** Nasceu na decisão nº 58, nesta release, e a bancada não o via:

```
f3base/config-ler com {"arquivo":"projeto"}, como administrador:
  Error — Cannot use object of type stdClass as array (rest-api.php:2445)
f3base/config-escrever, mesma entrada válida: o mesmo Error, antes do callback
f3base/como-usar com um campo fora do schema: o mesmo Error, onde devia haver recusa de schema
```

A decisão nº 58 moldou `properties` como objeto (`stdClass`) para que o mapa VAZIO de
`como-usar` serializasse como `{}` e não como `[]`, e a mesma forma foi copiada para os dois
mapas que não são vazios. O núcleo indexa `properties` como array ao validar cada campo da
entrada (`rest_validate_object_value_from_schema`), e um `stdClass` ali derruba a chamada com
`Error` antes de o callback existir. `wp.habilidades_registradas` executa só `como-usar`, sem
entrada — e sem entrada o laço que indexa `properties` não roda —, e das outras duas conferia
a presença no registro: duas habilidades estavam no registro e morriam com a entrada que o
próprio schema pede. Foi encontrado na conferência à mão do zip final, fora da suíte, ao
executar `config-ler` num WordPress real — o que a suíte nunca tinha feito.

**A checagem que prova.** `wp.habilidades_de_config_executam`, na bancada WordPress real: o
passo planta um par `projeto.json`/`projeto.schema.json` numa pasta de plugin, exige que sem
usuário a recusa seja do portão (e não de schema nem de exceção), que como administrador a
leitura devolva o conteúdo plantado, que a escrita chegue ao callback e responda estruturado
sem tocar no arquivo quando responde `ok: false`, e que `como-usar` recuse pelo schema o campo
que não declara. Mutante em `suite/bancada-wp/pisos.tsv`: o `stdClass` de volta nos três
schemas. A escrita é medida até o callback; gravar de verdade depende do validador do
implantador, e se mede na suíte dele.

**O que custa.** Um passo a mais na bancada, e a bancada passa a criar e remover uma pasta de
plugin. Toda chamada de habilidade que a suíte afirma que funciona passa a ser uma chamada
que a suíte fez.

**Como reverter.** O mutante `habilidades_de_config_executam.patch` é a reversão, e a suíte
o roda a cada piso.

## 78. Acessos como módulo do plugin persistente

A evolução sucede a versão anterior por número. O recurso pertence ao plugin base e usa seu catálogo, registro, estado e tela. O servidor mede somente requisições que chegaram ao host; tráfego atendido exclusivamente pela CDN fica fora dessa fonte.

## 79. A família é declarada, sem verificação de identidade

A classificação aceita a marca HTTP, sem resolver DNS nem confirmar faixa de IP. O TSV conserva a fonte consultada e distingue marcas atuais de marcas legadas sem confirmação. Google-Extended e Applebot-Extended são controles de uso em robots.txt, sem crawler HTTP independente; apresentá-los como visitas próprias inventaria uma separação que o log não contém.

## 80. Humanos são requisições de agentes sem marca de robô

Humano significa agente que não se declarou robô. Requisições humanas e visitantes distintos têm unidades diferentes: a diferença entre essas colunas não identifica automação. Repetições, consentimento, cache, retenção e calendário também alteram os números; a tela declara essas limitações.

## 81. Administração, MCP e recursos contam sem caminho

As exclusões precedem as demais classes, incluindo aliases sem barra final, rotas codificadas, REST por query e instalação em subdiretório. Os totais permanecem no rodapé; o detalhe administrativo e estático não é persistido. As outras APIs ficam separadas das páginas, junto aos acessos de descoberta.

## 82. A substituição é do dia inteiro

Arquivos são agrupados por dia antes da transação. O arquivo de rotação com sufixo zero, comprimidos e o dia corrente não entram; aliases do mesmo inode são deduplicados. O padrão nasce restrito ao domínio de home_url e recusa múltiplas pastas, porque combined não identifica o domínio. Falha de escrita reverte o dia e conserva seu checkpoint.

## 83. Ausência de fonte não é atividade confirmada

Sem arquivo legível, formato conhecido ou trava disponível, o estado é degradado e nomeia a causa. Soma antiga e importação pendente são visíveis. A confirmação do agendamento é conferida; uma continuação recusada pelo núcleo não pode ser apresentada como agendada.

## 84. O agregado reduz dados, mas caminhos não são necessariamente anônimos

IP, referer e User-Agent bruto não são persistidos. Queries são descartadas; caminhos com e-mail ou tokens evidentes perdem o detalhe. Caminhos públicos ainda podem conter dados pessoais e exigem exclusões do operador. A retenção é por calendário, com padrão de vinte e cinco meses. A rotina não alimenta o journal individual de formulários; isso descreve o escopo daquele journal, sem afirmar anonimato universal.

## 85. Volume tem limites explícitos

A cardinalidade por dia e família tem teto; caminhos excedentes viram totais sem detalhe. Há limites de tamanho do arquivo, tempo de leitura e quantidade de agregados. Um dia que não cabe é recusado por inteiro com diagnóstico, preservando o anterior. Volumes maiores exigem coletor externo; o plugin não deve tornar toda requisição PHP uma importação sem fim.

## 86. A atualização não depende de reativação

A primeira requisição cria a tabela e agenda a rotina quando faltam. A bancada instala o ZIP anterior de verdade, confirma que está ativo e sem a estrutura nova, substitui os arquivos pelo ZIP da rodada e chama a home antes do roteiro de asserções. Um observador de ativação confirma que a atualização não usou esse gancho.

## 87. A primeira soma alcança o histórico disponível

A ativação e a atualização iniciam a soma no próprio processo. O orçamento entre dias agenda continuação quando necessário; a tela mostra a importação parcial. A janela de noventa dias cresce com o acúmulo. O relato do host no plano descreve cerca de uma semana em disco; não foi usado como garantia de que este ambiente ou outro site tenha esses mesmos arquivos. Dias apagados não são reconstruídos.

## 88. Novas sessões têm prazo longo e revogação no núcleo

O padrão é de noventa dias, para todo usuário do formulário nativo; a duração aceita vai de um dia a um ano. Um cookie roubado permite acesso até expirar ou ser revogado. A tela apresenta o prazo e o controle “Sair de todos os outros dispositivos”. Mudar a configuração não altera retroativamente os tokens já emitidos.

## 89. O prazo também precisa chegar ao navegador

O filtro de duração cobre as duas formas de login. O POST nativo recebe rememberme antes de wp_signon, e o formulário de tema recebe value_remember marcado; remember apenas exibe a caixa. Desligado, o próximo login volta às regras do núcleo e dos demais plugins. A bancada confere cookie e token por HTTP, incluindo o controle com o módulo desligado.

## 90. O estado da sessão mede o valor efetivo

O diagnóstico executa a cadeia real de filtros uma vez para o usuário consultado e identifica o último grupo que alterou o prazo. Quando callbacks compartilham prioridade, seus nomes aparecem juntos: a atribuição individual não é presumida. Filtros condicionais podem produzir outro prazo em outro usuário ou contexto; a configuração sozinha não prova o resultado.

## 91. O índice anuncia o texto integral disponível

Optional contém o link para o texto integral quando o emissor do plugin serve a seleção habilitada. O endereço nasce em home_url. O teste lê ambos por HTTP e confere a ausência do link com o texto integral desligado. Nenhum desses arquivos é acrescentado ao sitemap e o robots.txt permanece na fase do implantador.

## 92. Notas históricas preservam a release em que ocorreram

O detector antigo exigia que toda nota de superação tivesse a versão corrente, mesmo quando narrava uma mudança passada. Essa regra obrigaria a reescrever o histórico a cada release. O detector passa a recusar versões futuras, conservando notas verdadeiras de releases anteriores; suas fixtures exercitam os dois sentidos.

## 93. Configuração é o destino explícito do menu principal

O núcleo abre o primeiro submenu ao clicar no menu pai. Sem Flamingo, o CPT de contingência ocupava esse lugar e escondia a entrada da configuração, embora a tela existisse. A configuração passa a ser o primeiro submenu explícito; a lista de contingência é preservada. A bancada usa apenas o plugin ativo, lê o destino no HTML do painel, navega por ele e grava um campo via HTTP com nonce. Reverter a entrada reproduz o defeito.

## 94. O diretório dos logs não herda o alias público www

O padrão usa o host da home em minúsculas, retirando apenas o prefixo www. O caminho anterior é reconhecido por igualdade exata e migrado na inicialização, mesmo com a soma desligada, conservando outras opções e sua procedência. Caminhos personalizados não são substituídos. O custo é assumir a convenção de diretório descrita pelo operador; outro host pode configurar um caminho próprio. Dois mutantes retiram separadamente a normalização e a migração; ambos precisam falhar.

## 95. A resolução de til valida a pasta completa sem exigir HOME

O host de teste permitiu listar e ler os logs pelo caminho absoluto, enquanto a configuração por til falhava antes da busca. A resolução passa a consultar HOME do SAPI e do ambiente local, os diretórios POSIX do usuário efetivo e do proprietário da instalação e os ascendentes lexicais e reais de ABSPATH, limitados a dezesseis níveis. Só a pasta completa do padrão é procurada; não há busca por contas vizinhas. Links simbólicos são resolvidos e aliases deduplicados. Mais de uma pasta real exige configuração absoluta. Sem pasta encontrada, o diagnóstico apresenta a condição observada de HOME e os caminhos tentados. A ausência de arquivos datados permanece distinta. O custo são consultas adicionais ao sistema de arquivos durante cada soma; a descoberta não roda na mera consulta dos agregados. O piso remove separadamente os ascendentes e a recusa de ambiguidade.

## 96. Hoje é uma leitura parcial separada do histórico

A operação precisa acompanhar acessos recentes sem transformar um arquivo aberto em dia definitivamente armazenado. Atualizar combina o histórico com uma fotografia limitada do arquivo atual, filtra timestamps pelo fuso do WordPress e descarta a linha incompleta final. Novas linhas só entram na próxima leitura. A união acontece antes do limite de páginas e famílias; um caminho fora dos líderes históricos pode entrar com tráfego novo. O custo é reler o arquivo a cada atualização e não recuperar trechos que já rotacionaram. Ausência, formato inválido e limites geram aviso específico sem apagar histórico. A bancada confere datas, fuso, atualização, filtros, ordenação e ausência de persistência; seu piso desativa o filtro de data.

## 97. A coleta diária tem agenda observável e a mesma regra do botão

Coletar e Armazenar Logs conserva a operação existente sobre arquivos datados fechados. O evento diário já existia; sua próxima execução passa a aparecer com o fuso local e os limites do acionamento por tráfego. A bancada remove e recupera a agenda, exige uma ocorrência diária, executa sua ação e verifica a exclusão do arquivo atual, do numérico e do datado de hoje. Repetição não duplica o histórico; desligar remove a agenda. O piso relaxa a barreira de data e precisa falhar. O cron do servidor é uma opção operacional para sites sem tráfego, não uma garantia dada pelo plugin.

## Publicação textual com seleção pública compartilhada

O índice, o texto integral e as alternativas Markdown usam a mesma seleção. Curadoria manual não é exceção às restrições de publicação, senha e noindex do conteúdo local identificado. Títulos e descrições são escapados como texto Markdown. O corpo Markdown usa somente conteúdo salvo, sem executar shortcodes ou blocos dinâmicos. Isso reduz diferenças de seleção e impede que uma rota textual contorne a proteção por senha. A publicação automática é suspensa pela visibilidade do site. As checagens `wp.publicacao_llms` e `wp.publicacao_markdown` medem esses comportamentos por HTTP. A opção de Markdown permite desativar as alternativas sem remover o índice.

## Robots como complemento do núcleo

O módulo complementa o arquivo virtual, preserva políticas existentes e anuncia o sitemap disponível. Usa a API de sitemap do núcleo e respeita seus filtros. A rota de reserva encaminha somente o caminho de robots na raiz para o gerador do WordPress quando os permalinks simples não o reconhecem. Arquivo físico conserva a precedência e tem diagnóstico explícito: regras editoriais ou restrições de bots não são substituídas silenciosamente. `wp.publicacao_robots` mede preservação, precedência e respostas HTTP. Desligar o módulo mantém os demais emissores responsáveis.

## Robots físico: transferência de responsabilidade com restauração

A escolha explícita do gerador passa a controlar a presença do arquivo físico. Confirmar o backup no banco antecede qualquer retirada. O rename no mesmo diretório conserva o original como reserva; o hard link publica a restauração completa apenas em um caminho livre. A reserva é conferida antes da limpeza. Interrupção após o rename recupera os bytes efetivamente movidos, inclusive uma edição externa entre a primeira leitura e a transferência.

Preferência e backup são relidos dentro da trava, invalidando o cache de opções da requisição. A desativação registra suspensão antes de restaurar, de modo que uma requisição antiga não recapture o arquivo restaurado. Reativar retoma a preferência. O efeito ocorre após a gravação conferida da opção e também no carregamento para cobrir atualizações sem reativação. Estado pendente nomeia a falha e mantém as cópias disponíveis.

Os testes `wp.robots_troca`, `wp.robots_falhas` e `wp.robots_ciclo` exercitam formulário e HTTP reais, falhas de persistência, conflitos externos, recuperação, concorrência e ciclo do plugin. Esta decisão substitui a precedência física permanente documentada na revisão anterior.

## O full conserva o corpo, com a estrutura do Markdown

O mesmo conversor das alternativas por página serve o corpo integral, com nível de títulos ajustado à seção do item. Não há redução por palavras. A normalização de linhas ocorre entre nós, preservando linhas internas dos blocos de código. A seleção compartilhada continua a impedir a publicação de conteúdo protegido. `wp.llms_full_estruturado` lê o endpoint, exige o marcador final de um texto longo e confere estrutura, exclusões e métodos HTTP.

## Entrega pública do robots.txt

A publicação é confirmada pelo conteúdo da resposta HTTP. O gerador preserva os filtros tardios do Yoast e deduplica referências ao mesmo sitemap. Hospedagens que interceptam a rota virtual recebem um arquivo gerenciado, atualizado automaticamente pelo WP-Cron. O original permanece em backup, e edições externas são preservadas na atualização e na desativação. A ausência de arquivo físico, isoladamente, deixa o diagnóstico pendente. Consulte as instruções do plugin para periodicidade, recuperação e limites operacionais.


## Interface de configuração e intervalo entre eventos

O operador pediu opções visíveis no llms.txt e separação dos dados técnicos. O formulário passa
a enumerar os tipos públicos reais, preservando o contrato de gravação e enviando seleção vazia.
Abas navegáveis por URL funcionam sem JavaScript e o diagnóstico deixa de pesar na abertura inicial.

O intervalo da tabela segue eventos de uso da mesma visita e visitante, mesmo quando o anterior
está fora da paginação. A ordenação considera milissegundos antes do identificador para lidar com
lotes recebidos fora de ordem. Dados legados e horários estimados não sustentam duração exata.
O texto da coluna declara a diferença entre intervalo observado e atenção contínua ao bloco.

A ampliação dos orçamentos foi solicitada pelo operador. Aplicou-se o fator de uma vez e meia,
com arredondamento para cima, mantendo os critérios de medição e os prazos de retenção. A revisão
também removeu a saída antecipada de lotes contendo somente o contador de descartes.

## Existência de conteúdo no filtro de acessos

A classe pagina do coletor é residual: uma URL desconhecida também pode receber essa classe.
O filtro da tela consulta os links permanentes de páginas e artigos publicados e mantém
a home e os arquivos de descoberta. A restrição entra antes do limite do ranking e da
contagem de caminhos. Filtrar somente as linhas já limitadas faria um pico de scans esconder
conteúdo válido e produziria um denominador incorreto. Mostrar todos libera os caminhos
disponíveis e mantém os filtros de período e status. A seleção não altera o histórico
ou a API de leitura; os totais gerais continuam identificados separadamente.

As classificações distinguem conteúdo publicado, arquivos de descoberta, feeds, APIs e
outros caminhos. Caminhos inexistentes usa apenas respostas `404` e `410` do período;
um caminho sem post correspondente pode ser uma rota válida. Esta seleção inclui os
erros necessários automaticamente e evita somar respostas bem-sucedidas do mesmo caminho.
