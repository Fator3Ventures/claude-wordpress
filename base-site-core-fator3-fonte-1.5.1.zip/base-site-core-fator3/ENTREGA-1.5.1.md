# Base Site Core Fator3 — 1.5.1

## Alteração

Em Medição → Acessos, o checkbox **Mostrar todos** começa desmarcado. Nesse estado, as tabelas mostram a página inicial, os endereços atuais de páginas e artigos publicados e os arquivos de descoberta: robots.txt, sitemaps XML (inclusive compactados), llms.txt e llms-full.txt.

Marcar Mostrar todos e clicar em Atualizar restaura os demais caminhos disponíveis no relatório, incluindo URLs inexistentes, arquivos de categoria, tipos personalizados, feeds e APIs. O filtro de status e o limite de linhas continuam sendo respeitados.

O filtro é aplicado antes do ranking e dos denominadores exibidos. Caminhos desconhecidos com muitos acessos não ocupam as vagas destinadas ao conteúdo publicado. O mesmo filtro vale para o histórico e para o log de hoje. Período, status e Mostrar todos são preservados ao usar Coletar e Armazenar Logs.

## Classificações

| Seleção | O que mostra |
|---|---|
| Páginas, artigos e descoberta | Padrão: home, páginas e artigos publicados e arquivos relevantes. |
| Somente páginas e artigos | Home e links atuais de páginas e artigos publicados. |
| Arquivos de descoberta | robots.txt, sitemaps XML ou XML.gz, llms.txt e llms-full.txt. |
| Caminhos inexistentes (404/410) | Somente acessos respondidos com 404 ou 410, incluindo esses erros automaticamente. |
| Feeds | Rotas de feeds do site e de conteúdos. |
| APIs | Rotas classificadas como API pelo coletor. |
| Outros caminhos | Demais caminhos disponíveis, incluindo arquivos de categoria e rotas de plugins, sem respostas 404/410. |

Mostrar todos prevalece sobre a classificação selecionada. A tela identifica qual visão está aplicada. Seleção, período e filtros são mantidos ao coletar logs.

Uma resposta 404/410 descreve aquele acesso e não comprova que a URL continue inexistente. A ausência de um post cadastrado também não comprova inexistência. Um mesmo caminho pode ter respostas bem-sucedidas e respostas 404/410; a visão de inexistentes conta somente estas últimas. As visões por conteúdo usam o cadastro atual do WordPress.

## Critério e limites

- A existência de conteúdo é determinada pelos links permanentes de posts dos tipos `page` e `post`, com status `publish`, incluindo páginas filhas. A página inicial é incluída também quando mostra a lista de artigos.
- A seleção acompanha publicações, remoções e alterações de endereço na próxima atualização da tela. Conteúdo com noindex permanece elegível; esta seleção segue a existência de conteúdo publicado.
- Endereços com ou sem barra final são considerados; instalações em subdiretório usam o caminho da própria instalação. Slugs antigos sem correspondência atual ficam disponíveis em Mostrar todos.
- O checkbox controla a visualização. Não modifica a coleta, a retenção, os arquivos de log nem a API MCP de acessos.
- Os totais gerais de exclusões, estáticos e excedentes permanecem identificados separadamente. Caminhos descartados pelo coletor não podem ser recuperados por Mostrar todos.
- Parâmetros de URL já são removidos na coleta. Com links permanentes baseados em query string, acessos a conteúdos diferentes podem estar agrupados no mesmo caminho; o filtro respeita essa granularidade existente.

## Validação

- Suíte completa: 161 verificações aprovadas, zero falhas e zero bloqueios. Treze verificações ficaram sem execução, relativas ao navegador e a fases de aplicação ou serviços externos. A renderização visual em navegador não foi validada nesta rodada.
- WordPress real na bancada: sete classificações, checkbox padrão, conteúdo publicado e páginas filhas, arquivos de descoberta, feeds, APIs, status 404/410 versus 500, respostas diferentes para o mesmo caminho, ranking antes do teto, histórico e hoje, publicação/remoção de conteúdo, subdiretório e preservação dos filtros no retorno da coleta.
- Cinco defeitos deliberados foram detectados nos testes de regressão.
- Versão 1.5.1 instalada e ativada no WordPress fator3-teste. Arquivo principal, tela de acessos e instruções conferidos por SHA-256 contra o instalador; módulos de comportamento, acessos, llms e robots ativos após a atualização.

O pacote completo contém fontes, suíte, histórico Git em bundle e evidências em `dist/validacao-1.5.1/`. SHA-256 do instalador validado: `67fd11f55e2ddc164e4938db7f1cedf2f51208cfb6471a370aba9ed4153bf4e9`.
