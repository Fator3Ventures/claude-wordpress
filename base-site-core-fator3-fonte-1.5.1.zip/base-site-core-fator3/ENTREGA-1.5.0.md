# Base Site Core Fator3 — 1.5.0

## Alterações

- llms.txt: caixas de seleção com os tipos públicos registrados no WordPress, inclusive tipos personalizados. Mantém a seleção atual e permite desmarcar todas as opções; a API aceita também o formato de texto anterior.
- Configuração: duas abas por URL, Configurações (principal) e Informações técnicas. Todo o diagnóstico Estado das partes do plugin está na segunda aba, sem duplicar o formulário.
- Medição: coluna Desde o anterior, entre eventos de uso da mesma visita e visitante, com precisão de milissegundos. O predecessor é procurado também fora da página e do período visível, dentro do histórico retido. Ordenação cronológica inclui a fração de segundo, mesmo com lotes recebidos fora de ordem.
- Horários legados ou estimados e ausência de predecessor produzem um traço. Eventos simultâneos podem produzir zero. O intervalo sucede o evento anterior; inatividade e outras abas impedem interpretá-lo como atenção contínua ao bloco.
- Lotes contendo somente descartes agora são persistidos com a deduplicação dos agregados.

## Orçamentos

Aumento de 50%, com arredondamento para cima em contagens indivisíveis.

| Limite | Antes | Agora |
|---|---:|---:|
| Registro detalhado por visita | 200 | 300 |
| Eventos por lote recebido | 120 | 180 |
| Corpo do envio | 8 KiB | 12 KiB |
| Requisições por origem em dez minutos, padrão | 200 | 300 |
| Passagens por marco/seção, página e visita | 20 | 30 |
| Teto de abertura de página por carregamento | 1 | 2 |
| Teto de rolagem por carregamento | 4 | 6 |
| Seções no agregado por carregamento | 12 | 18 |
| Links externos por carregamento | 10 | 15 |
| Fricção e erros, cada um por carregamento | 3 | 5 |
| Desempenho por carregamento | 4 | 6 |
| Arquivo de log | 64 MiB | 96 MiB |
| Leitura de um dia de log | 8 s | 12 s |
| Orçamento para iniciar dias em uma execução | 10 s | 15 s |
| Caminhos por família e dia | 500 | 750 |
| Combinações agregadas por dia | 50.000 | 75.000 |
| Linhas por consulta MCP de acessos | 1.000 | 1.500 |
| Limite máximo da consulta de acionamentos | 500 | 750 |
| Páginas no ranking de acessos | 200 | 300 |
| Entradas no cache de títulos de acessos | 1.000 | 1.500 |

O período de sessão, a retenção, os quatro marcos de rolagem e os critérios de detecção permanecem. O coletor continua emitindo uma única abertura por carregamento e uma medida por vital disponível; ampliar o teto não cria acontecimentos extras. Filtros externos de rate limit continuam prevalecendo. Limites de leitura são reduzidos quando necessário para respeitar o tempo de execução do PHP. O orçamento do lote de dias é verificado entre dias, portanto não é um timeout rígido da requisição inteira.

## Verificação

- Suíte completa: 160 verificações aprovadas, zero falhas e zero bloqueios. Treze verificações ficaram sem execução: uma de navegador (Chromium indisponível neste ambiente) e doze de fases de aplicação ou serviços externos. A renderização visual em navegador não foi validada nesta rodada.
- O WordPress da bancada verificou o formulário por HTTP: abas separadas, tipos personalizados públicos, preservação da seleção existente, gravação de múltiplas escolhas, exclusão de tipos privados e possibilidade de desmarcar tudo.
- Os intervalos foram verificados no banco com paginação, eventos fora de ordem, virada do período, páginas diferentes, visitantes e visitas diferentes, simultaneidade e horários legados ou estimados.
- O endpoint aceitou 180 eventos em um lote e preservou descartes enviados isoladamente, sem duplicá-los no reenvio.
- Oito defeitos deliberados foram detectados pelos cenários de regressão, incluindo remoção da aba técnica, mistura de visitantes, retorno ao teto antigo e perda de lotes somente com descartes.
- Instalado e ativado no WordPress fator3-teste. Versão 1.5.0 confirmada; seis arquivos principais conferidos por SHA-256 contra o instalador. A consulta de predecessores também foi executada, somente para leitura, no banco da hospedagem. Medição, acessos, llms.txt, llms-full.txt e robots.txt permaneceram ativos após a revalidação automática.

O pacote de fontes inclui a suíte, o histórico Git em bundle e as evidências em `dist/validacao-1.5.0/`. O instalador validado tem SHA-256 `aecad9d5d689c925a24e646440604122f0f47dd97ed6286f060b2f0902121b9a`.
