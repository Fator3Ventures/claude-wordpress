<?php
/** Filtro de conteúdo sobre o histórico e o dia corrente, antes do ranking. */
declare( strict_types = 1 );

function f3b_a_filtro(): array {
	global $wpdb, $wp_rewrite;
	[ $m, , $ontem, , $dir ] = f3b_e_fixture(); $m->somar();
	$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
	$estrutura = get_option( 'permalink_structure' ); $get = $_GET; $ids = array();
	$wp_rewrite->set_permalink_structure( '/%postname%/' ); $wp_rewrite->flush_rules( false );
	register_post_type( 'f3b_projeto', array( 'public' => true, 'rewrite' => array( 'slug' => 'projetos' ) ) );
	$criar = static function ( string $nome, string $tipo = 'page', string $status = 'publish', int $pai = 0 ) use ( &$ids ): int {
		$id = wp_insert_post( array( 'post_title' => $nome, 'post_name' => $nome, 'post_type' => $tipo, 'post_status' => $status, 'post_parent' => $pai ), true );
		f3b_e_exige( ! is_wp_error( $id ), 'Não foi possível criar conteúdo da fixture.' ); $ids[] = (int) $id; return (int) $id;
	};
	$inserir = static function ( string $p, int $n = 1, int $status = 200 ) use ( $wpdb, $t, $ontem ): void {
		[ $classe, $caminho ] = F3Base_Modulo_Acessos_Servidor::caminho( $p, F3Base_Modulo_Acessos_Servidor::EXCLUIDOS );
		f3b_e_exige( false !== $wpdb->insert( $t, array( 'dia' => $ontem, 'agente' => 'humano', 'classe_caminho' => $classe, 'caminho' => $caminho, 'status' => $status, 'metodo' => 'GET', 'contagem' => $n ) ), 'Acesso da fixture não foi gravado.' );
	};
	$tem = static fn( $x, string $p ) => $x->query( '//tr[td/code="' . $p . '"]' )->length > 0;
	try {
		$pagina = $criar( 'filtro-pagina' ); $artigo = $criar( 'filtro-artigo', 'post' );
		$pai = $criar( 'filtro-pai' ); $criar( 'filtro-filha', 'page', 'publish', $pai );
		$rascunho = $criar( 'filtro-rascunho', 'post', 'draft' ); $criar( 'filtro-privada', 'page', 'private' );
		$criar( 'filtro-projeto', 'f3b_projeto' ); $criar( 'filtro-anexo', 'attachment', 'inherit' );
		$wpdb->query( 'DELETE FROM ' . $t );
		$visiveis = array( '/', '/filtro-pagina/', '/filtro-artigo/', '/filtro-pai/filtro-filha/', '/robots.txt', '/sitemap_index.xml', '/post-sitemap2.xml', '/wp-sitemap-posts-post-1.xml', '/sitemap.xml.gz', '/llms.txt', '/llms-full.txt' );
		$ocultos = array( '/inexistente/', '/filtro-rascunho/', '/filtro-privada/', '/projetos/filtro-projeto/', '/filtro-anexo/', '/category/geral/', '/feed/', '/wp-json/wp/v2/posts', '/lixo.xml.gz', '/llms-outro.txt' );
		foreach ( array_merge( $visiveis, $ocultos ) as $p ) { $inserir( $p ); }
		$inserir( '/filtro-pagina', 2, 404 ); $inserir( '/inexistente-404/', 2, 404 );
		// Mais caminhos desconhecidos do que o teto da tabela, todos à frente do conteúdo real.
		for ( $i = 0; $i <= F3Base_Admin_Acessos::TETO_PAGINAS; ++$i ) { $inserir( '/scan-' . $i . '/', 20 ); }
		file_put_contents( $dir . '/access.log', f3b_a_log( '/filtro-pagina/' ) . f3b_a_log( '/somente-hoje/' ) . f3b_a_log( '/llms-full.txt' ) . f3b_a_log( '/feed/' ) );
		$antes = f3b_e_rows();
		$html = f3b_a_html( 2 ); $x = f3b_c_dom( $html );
		foreach ( $visiveis as $p ) { f3b_e_exige( $tem( $x, $p ), 'Filtro escondeu conteúdo/arquivo relevante: ' . $p ); }
		foreach ( array_merge( $ocultos, array( '/scan-0/', '/somente-hoje/', '/filtro-pagina', '/inexistente-404/' ) ) as $p ) { f3b_e_exige( ! $tem( $x, $p ), 'Filtro padrão deixou outro caminho aparecer: ' . $p ); }
		f3b_e_exige( $x->query( '//input[@type="checkbox" and @name="mostrar_todos" and not(@checked)]' )->length === 1, 'Mostrar todos deve começar desmarcado.' );
		f3b_e_exige( $x->evaluate( 'string(//tr[td/code="/filtro-pagina/"]/td[2])' ) === '2' && $x->evaluate( 'string(//tr[td/code="/llms-full.txt"]/td[4])' ) === '2', 'Filtro perdeu a união entre histórico e hoje.' );
		f3b_e_exige( str_contains( $html, 'Exibindo 5 de 5 caminhos' ) && str_contains( $html, 'Exibindo 6 de 6 combinações' ), 'Denominador do ranking inclui caminhos ocultos.' );
		$com_erros = f3b_c_dom( f3b_a_html( 2, true ) );
		f3b_e_exige( $tem( $com_erros, '/filtro-pagina' ) && ! $tem( $com_erros, '/inexistente-404/' ), 'Filtro de conteúdo foi desfeito pelo filtro de status.' );
		$so_hoje = f3b_c_dom( f3b_a_html( 1 ) );
		f3b_e_exige( $tem( $so_hoje, '/filtro-pagina/' ) && ! $tem( $so_hoje, '/filtro-artigo/' ) && ! $tem( $so_hoje, '/somente-hoje/' ), 'Período de um dia não respeitou o filtro.' );
		$todos = f3b_c_dom( f3b_a_html( 2, true, true ) );
		f3b_e_exige( $tem( $todos, '/scan-0/' ) && $tem( $todos, '/feed/' ) && $tem( $todos, '/wp-json/wp/v2/posts' ) && $todos->query( '//input[@type="checkbox" and @name="mostrar_todos" and @checked]' )->length === 1, 'Mostrar todos não restaurou os caminhos.' );
		f3b_e_exige( f3b_e_rows() === $antes, 'Alternar filtros alterou os dados coletados.' );
		// O limite ainda existe. Remova apenas a massa de ranking da fixture para conferir cada classe.
		$wpdb->query( "DELETE FROM {$t} WHERE caminho LIKE '/scan-%'" );
		$sem_scans = f3b_e_rows(); $todos = f3b_c_dom( f3b_a_html( 2, true, true ) );
		foreach ( array_merge( $ocultos, array( '/somente-hoje/', '/inexistente-404/' ) ) as $p ) { f3b_e_exige( $tem( $todos, $p ), 'Mostrar todos escondeu caminho disponível: ' . $p ); }
		f3b_e_exige( f3b_e_rows() === $sem_scans, 'Visualização alterou os dados coletados.' );
		// Classificações usam conteúdo, famílias de arquivos e os status realmente registrados.
		$inserir( '/falha-servidor/', 7, 500 ); $inserir( '/removido/', 3, 410 );
		$inserir( '/resposta-mista/', 9, 200 ); $inserir( '/resposta-mista/', 4, 404 );
		$inserir( '/filtro-pagina/feed/' );
		file_put_contents( $dir . '/access.log', f3b_a_log( '/filtro-pagina/' ) . f3b_a_log( '/somente-hoje/' ) . f3b_a_log( '/llms-full.txt' ) . f3b_a_log( '/feed/' ) . f3b_a_log( '/erro-atual/', '', 404 ) . f3b_a_log( '/resposta-mista/', '', 404 ) );
		$categorias = array(
			'paginas' => array( array( '/', '/filtro-pagina/', '/filtro-artigo/' ), array( '/llms.txt', '/inexistente/', '/wp-json/wp/v2/posts', '/feed/' ) ),
			'descoberta' => array( array( '/robots.txt', '/sitemap.xml.gz', '/llms.txt', '/llms-full.txt' ), array( '/', '/filtro-artigo/', '/feed/', '/wp-json/wp/v2/posts' ) ),
			'feeds' => array( array( '/feed/', '/filtro-pagina/feed/' ), array( '/', '/filtro-pagina/', '/llms.txt', '/wp-json/wp/v2/posts' ) ),
			'apis' => array( array( '/wp-json/wp/v2/posts' ), array( '/', '/inexistente/', '/feed/', '/llms.txt' ) ),
			'inexistentes' => array( array( '/inexistente-404/', '/filtro-pagina', '/removido/', '/erro-atual/', '/resposta-mista/' ), array( '/', '/inexistente/', '/falha-servidor/', '/somente-hoje/', '/llms.txt' ) ),
			'outros' => array( array( '/inexistente/', '/category/geral/', '/projetos/filtro-projeto/', '/somente-hoje/', '/falha-servidor/', '/resposta-mista/' ), array( '/', '/filtro-artigo/', '/llms.txt', '/feed/', '/filtro-pagina/feed/', '/wp-json/wp/v2/posts', '/inexistente-404/', '/removido/' ) ),
		);
		foreach ( $categorias as $categoria => [ $presentes, $ausentes ] ) {
			$cx = f3b_c_dom( f3b_a_html( 2, 'outros' === $categoria, false, $categoria ) );
			foreach ( $presentes as $p ) { f3b_e_exige( $tem( $cx, $p ), $categoria . ' perdeu ' . $p ); }
			foreach ( $ausentes as $p ) { f3b_e_exige( ! $tem( $cx, $p ), $categoria . ' incluiu ' . $p ); }
			if ( 'inexistentes' === $categoria ) { f3b_e_exige( $cx->evaluate( 'string(//tr[td/code="/resposta-mista/"]/td[2])' ) === '5', 'Inexistentes somou respostas 200 ou perdeu 404 de hoje.' ); }
			if ( 'outros' === $categoria ) { f3b_e_exige( $cx->evaluate( 'string(//tr[td/code="/resposta-mista/"]/td[2])' ) === '9', 'Outros somou respostas 404.' ); }
		}
		$forcado = f3b_c_dom( f3b_a_html( 2, true, true, 'paginas' ) );
		f3b_e_exige( $tem( $forcado, '/inexistente-404/' ) && $tem( $forcado, '/feed/' ) && $tem( $forcado, '/filtro-artigo/' ), 'Mostrar todos não prevaleceu sobre a classificação.' );
		$invalido = f3b_c_dom( f3b_a_html( 2, false, false, 'desconhecida' ) );
		f3b_e_exige( $tem( $invalido, '/filtro-artigo/' ) && $tem( $invalido, '/llms.txt' ) && ! $tem( $invalido, '/inexistente/' ), 'Classificação inválida não voltou ao padrão.' );
		// Consulta HTTP administrativa sem parâmetro deve carregar o filtro padrão.
		$login = wp_remote_post( f3b_bancada_url( '/wp-login.php' ), array( 'redirection' => 0, 'body' => array( 'log' => 'admin', 'pwd' => 'admin' ) ) );
		$cookies = wp_remote_retrieve_cookies( $login );
		$url = f3b_bancada_url( '/wp-admin/admin.php?page=f3base-medicao&aba=acessos&dias=2' );
		$r = wp_remote_get( $url, array( 'cookies' => $cookies, 'timeout' => 20 ) );
		f3b_e_exige( ! is_wp_error( $r ), 'Consulta HTTP administrativa: ' . ( is_wp_error( $r ) ? $r->get_error_message() : '' ) );
		$body = wp_remote_retrieve_body( $r ); $http = f3b_c_dom( $body );
		f3b_p_evidencia( 'acessos-filtro', array( 'codigo' => 200, 'cabecalhos' => array(), 'corpo' => $body ) );
		f3b_e_exige( wp_remote_retrieve_response_code( $r ) === 200 && $tem( $http, '/filtro-artigo/' ) && ! $tem( $http, '/inexistente/' ) && $http->query( '//input[@type="checkbox" and @name="mostrar_todos" and not(@checked)]' )->length === 1, 'Padrão HTTP diferente da tela local: ' . wp_json_encode( array( 'status' => wp_remote_retrieve_response_code( $r ), 'artigo' => $tem( $http, '/filtro-artigo/' ), 'desconhecido' => $tem( $http, '/inexistente/' ), 'checkbox' => $http->query( '//input[@type="checkbox" and @name="mostrar_todos" and not(@checked)]' )->length ) ) );
		wp_update_post( array( 'ID' => $rascunho, 'post_status' => 'publish' ) ); wp_trash_post( $artigo );
		$alterado = f3b_c_dom( f3b_a_html( 2 ) );
		f3b_e_exige( $tem( $alterado, '/filtro-rascunho/' ) && ! $tem( $alterado, '/filtro-artigo/' ), 'Filtro manteve estado antigo após publicar ou remover conteúdo.' );
		$home = get_option( 'home' ); $sub = static fn() => $home . '/sub'; add_filter( 'pre_option_home', $sub );
		try {
			$inserir( '/sub/filtro-pagina/' ); $inserir( '/sub/robots.txt' ); $inserir( '/sub/wp-sitemap.xml' );
			$subdir = f3b_c_dom( f3b_a_html( 2 ) );
			f3b_e_exige( $tem( $subdir, '/sub/filtro-pagina/' ) && $tem( $subdir, '/sub/robots.txt' ) && $tem( $subdir, '/sub/wp-sitemap.xml' ) && ! $tem( $subdir, '/filtro-pagina/' ) && ! $tem( $subdir, '/robots.txt' ), 'Filtro não respeitou a instalação em subdiretório.' );
		} finally { remove_filter( 'pre_option_home', $sub ); }
		// Recolher os logs mantém o filtro que já estava aplicado, inclusive os outros campos.
		foreach ( array( '0', '1' ) as $valor ) {
			$r = wp_remote_get( $url . '&incluir_erros=1&classificacao=paginas&mostrar_todos=' . $valor, array( 'cookies' => $cookies, 'timeout' => 20 ) ); $x = f3b_c_dom( wp_remote_retrieve_body( $r ) );
			$campos = array(); foreach ( $x->query( '//form[@method="post"]//input' ) as $input ) { $campos[$input->getAttribute('name')] = $input->getAttribute('value'); }
			f3b_e_exige( $campos['mostrar_todos'] === $valor, 'Formulário de coleta perdeu o filtro aplicado.' );
			$r = wp_remote_post( f3b_bancada_url( '/wp-admin/admin-post.php' ), array( 'cookies' => $cookies, 'redirection' => 0, 'body' => $campos, 'timeout' => 20 ) );
			parse_str( (string) wp_parse_url( wp_remote_retrieve_header( $r, 'location' ), PHP_URL_QUERY ), $query );
			f3b_e_exige( wp_remote_retrieve_response_code( $r ) === 302 && $query['mostrar_todos'] === $valor && $query['dias'] === '2' && $query['incluir_erros'] === '1' && $query['classificacao'] === 'paginas', 'Retorno da coleta perdeu período ou filtros.' );
		}
	} finally {
		foreach ( $ids as $id ) { wp_delete_post( $id, true ); }
		unregister_post_type( 'f3b_projeto' ); $wp_rewrite->set_permalink_structure( $estrutura ); $wp_rewrite->flush_rules( false ); $_GET = $get;
	}
	return array( 'OK', 'Filtro padrão, sete classificações e Mostrar todos: conteúdo publicado, arquivos, respostas 404/410, erros 500, ranking antes do teto, hoje, HTTP, publicação/remoção, subdiretório e retorno da coleta.' );
}
