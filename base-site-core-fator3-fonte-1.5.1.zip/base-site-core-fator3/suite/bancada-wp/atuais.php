<?php
/** Dia corrente efêmero e execução do coletor pela ação agendada no WordPress real. */
declare( strict_types = 1 );
function f3b_a_log( string $caminho, string $dia = '', int $status = 200, string $ua = 'Chrome', string $hora = '12:00:00', string $offset = '+0000' ): string {
	$dia = $dia ?: wp_date( 'Y-m-d' );
	$data = ( new DateTimeImmutable( $dia ) )->format( 'd/M/Y' ) . ':' . $hora . ' ' . $offset;
	return str_replace( '06/Sep/2026:12:00:00 +0000', $data, f3b_e_log( $ua, $caminho, $status ) );
}
function f3b_a_html( int $dias, bool $erros = false, bool $todos = false, string $classificacao = 'conteudo' ): string {
	require_once ABSPATH . 'wp-admin/includes/template.php';
	wp_set_current_user( 1 ); $_GET = array( 'aba' => 'acessos', 'dias' => $dias, 'incluir_erros' => $erros ? '1' : '0', 'mostrar_todos' => $todos ? '1' : '0', 'classificacao' => $classificacao );
	ob_start(); F3Base_Admin_Acessos::render(); return ob_get_clean();
}
function f3b_a_atuais(): array {
	global $wpdb;
	[ $m, $datado, $ontem, , $dir ] = f3b_e_fixture(); $m->somar();
	$antes = f3b_e_rows(); $estado = F3Base_Options::ler( 'f3base_acessos_estado' );
	$atual = $dir . '/access.log';
	file_put_contents( $atual, f3b_a_log( '/antigo-no-atual/', $ontem ) . str_repeat( f3b_a_log( '/pagina-a/?privado=apagar' ), 2 ) . f3b_a_log( '/so-hoje/' ) . f3b_a_log( '/erro-hoje/', '', 404 ) . f3b_a_log( '/llms-full.txt', '', 200, 'GPTBot' ) . f3b_a_log( '/wp-admin/' ) . rtrim( f3b_a_log( '/linha-incompleta/' ) ) );
	$r = F3Base_Acessos_Atuais::ler();
	f3b_e_exige( ! $r['erro'] && array_sum( array_column( $r['linhas'], 'contagem' ) ) === 6, 'Hoje deve contar apenas seis linhas completas: ' . wp_json_encode( $r ) );
	$json = wp_json_encode( $r );
	foreach ( array( '192.0.2', 'referer-privado', 'Chrome', 'privado=apagar', '/antigo-no-atual/', '/linha-incompleta/' ) as $proibido ) { f3b_e_exige( ! str_contains( $json, $proibido ), 'Snapshot contém dado indevido: ' . $proibido ); }
	$html = f3b_a_html( 2, false, true ); $x = f3b_c_dom( $html );
	f3b_e_exige( $x->evaluate( 'string(//tr[td/code="/pagina-a/"]/td[2])' ) === '6', 'Histórico e hoje não foram unidos na página.' );
	f3b_e_exige( $x->evaluate( 'string(//tr[td/code="/llms-full.txt"]/td[4])' ) === '3', 'Descoberta não uniu histórico e hoje.' );
	foreach ( array( 'excluídos 16', 'Atualizar', 'Coletar e Armazenar Logs', 'Hoje (', 'parcial', 'incluindo hoje' ) as $frase ) { f3b_e_exige( str_contains( $html, $frase ), 'Tela sem ' . $frase ); }
	f3b_e_exige( ! str_contains( $html, '/erro-hoje/' ) && str_contains( f3b_a_html( 1, true, true ), '/erro-hoje/' ), 'Filtro de erros não foi aplicado a hoje.' );
	$opcoes = array(); foreach ( $x->query( '//select[@name="dias"]/option' ) as $n ) { $opcoes[] = (int) $n->getAttribute( 'value' ); }
	f3b_e_exige( $opcoes === array( 1,2,3,4,5,6,7,15,30,60,90 ), 'Períodos solicitados ausentes.' );
	foreach ( $opcoes as $n ) { $r = F3Base_Modulo_Acessos_Servidor::consultar( $n, '', '', false, 0, true ); f3b_e_exige( $r['fim'] === wp_date( 'Y-m-d' ) && ( new DateTimeImmutable( $r['inicio'] ) )->diff( new DateTimeImmutable( $r['fim'] ) )->days === $n - 1, 'Janela inválida para ' . $n ); }
	$x = f3b_c_dom( f3b_a_html( 1, false, true ) );
	f3b_e_exige( $x->evaluate( 'string(//tr[td/code="/pagina-a/"]/td[2])' ) === '2' && ! str_contains( $x->document->saveHTML(), 'googlebot: 3' ), 'Um dia deve exibir somente hoje.' );
	file_put_contents( $atual, "\n" . f3b_a_log( '/so-hoje/' ), FILE_APPEND );
	$r = F3Base_Acessos_Atuais::ler();
	f3b_e_exige( ! $r['erro'] && array_sum( array_column( $r['linhas'], 'contagem' ) ) === 8, 'Atualização não incorporou duas novas linhas completas.' );
	f3b_e_exige( f3b_e_rows() === $antes && F3Base_Options::ler( 'f3base_acessos_estado' ) === $estado, 'Consulta atual alterou histórico/checkpoints.' );
	// Horário UTC na madrugada pertence ao dia anterior no fuso do site.
	$fuso = static fn() => 'America/Sao_Paulo'; add_filter( 'pre_option_timezone_string', $fuso );
	try {
		file_put_contents( $atual, f3b_a_log( '/madrugada/', '', 200, 'Chrome', '01:00:00' ) . f3b_a_log( '/meio-dia/' ) );
		$r = F3Base_Acessos_Atuais::ler(); f3b_e_exige( ! $r['erro'] && count( $r['linhas'] ) === 1 && $r['linhas'][0]['caminho'] === '/meio-dia/', 'Filtro de data ignorou fuso do WordPress.' );
	} finally { remove_filter( 'pre_option_timezone_string', $fuso ); }
	// A página fora dos duzentos líderes históricos deve subir ao receber acessos hoje.
	$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
	$wpdb->query( 'DELETE FROM ' . $t );
	for ( $i = 0; $i < F3Base_Admin_Acessos::TETO_PAGINAS + 2; ++$i ) { $wpdb->insert( $t, array( 'dia' => $ontem, 'agente' => 'humano', 'classe_caminho' => 'pagina', 'caminho' => sprintf( '/ranking-%03d/', $i ), 'status' => 200, 'metodo' => 'GET', 'contagem' => $i < F3Base_Admin_Acessos::TETO_PAGINAS + 1 ? 10 : 1 ) ); }
	file_put_contents( $atual, str_repeat( f3b_a_log( sprintf( '/ranking-%03d/', F3Base_Admin_Acessos::TETO_PAGINAS + 1 ) ), 20 ) );
	$x = f3b_c_dom( f3b_a_html( 2, false, true ) );
	f3b_e_exige( $x->evaluate( 'string(//table[1]/tbody/tr[1]/td/code)' ) === sprintf( '/ranking-%03d/', F3Base_Admin_Acessos::TETO_PAGINAS + 1 ) && $x->evaluate( 'string(//table[1]/tbody/tr[1]/td[2])' ) === '21', 'Ranking limitou antes de unir hoje.' );
	unlink( $atual ); $html = f3b_a_html( 2, false, true );
	f3b_e_exige( str_contains( $html, 'Hoje indisponível' ) && str_contains( $html, '/ranking-000/' ), 'Falta do log atual escondeu histórico ou não foi diagnosticada.' );
	file_put_contents( $atual, "formato desconhecido\n" ); f3b_e_exige( F3Base_Acessos_Atuais::ler()['erro'] !== '', 'Formato inválido aceito como zero.' );
	$f = fopen( $atual, 'w' ); ftruncate( $f, F3Base_Modulo_Acessos_Servidor::MAX_BYTES_ARQUIVO + 1 ); fclose( $f );
	f3b_e_exige( str_contains( F3Base_Acessos_Atuais::ler()['erro'], '96 MiB' ), 'Leitura atual ilimitada.' );
	return array( 'OK', 'Hoje sem persistência: data/fuso, linha parcial, atualização, filtros, períodos, união/ranking, privacidade e falhas de leitura conferidos.' );
}
function f3b_a_cron(): array {
	[ $m, $datado, $ontem, , $dir ] = f3b_e_fixture();
	$m->inicializar(); wp_clear_scheduled_hook( F3Base_Modulo_Acessos_Servidor::EVENTO ); $m->inicializar(); $m->inicializar();
	$eventos = array(); foreach ( _get_cron_array() as $ts => $hooks ) { if ( isset( $hooks[ F3Base_Modulo_Acessos_Servidor::EVENTO ] ) ) { $eventos[] = wp_get_scheduled_event( F3Base_Modulo_Acessos_Servidor::EVENTO, array(), $ts ); } }
	f3b_e_exige( count( $eventos ) === 1 && $eventos[0]->schedule === 'daily' && $eventos[0]->interval === DAY_IN_SECONDS && gmdate( 'H:i', $eventos[0]->timestamp ) === '09:00', 'Agenda diária não foi recuperada ou está duplicada.' );
	file_put_contents( $datado, f3b_a_log( '/coletado-pelo-cron/', $ontem ) );
	foreach ( array( 'access.log', 'access.log.0', 'access.log.' . wp_date( 'Y-m-d' ) ) as $nome ) { file_put_contents( $dir . '/' . $nome, f3b_a_log( '/nao-armazenar-hoje/' ) ); }
	clearstatcache(); do_action( F3Base_Modulo_Acessos_Servidor::EVENTO ); $r = f3b_e_rows();
	f3b_e_exige( count( $r ) === 1 && $r[0]['dia'] === $ontem && $r[0]['caminho'] === '/coletado-pelo-cron/', 'Ação agendada não coletou apenas o arquivo fechado datado: ' . wp_json_encode( array( 'linhas' => $r, 'estado' => F3Base_Options::ler( 'f3base_acessos_estado' ), 'hook' => has_action( F3Base_Modulo_Acessos_Servidor::EVENTO ) ) ) );
	do_action( F3Base_Modulo_Acessos_Servidor::EVENTO ); f3b_e_exige( f3b_e_rows() === $r, 'Cron repetido duplicou dados.' );
	F3Base_Options::gravar( 'f3base_acessos', array( 'ligado' => false, 'padrao_do_log' => $dir . '/access.log.*' ) ); $m->inicializar();
	f3b_e_exige( ! wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::EVENTO ) && ! wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::CONTINUAR ) && f3b_e_rows() === $r, 'Desligar não removeu eventos ou perdeu histórico.' );
	f3b_e_exige( F3Base_Acessos_Atuais::ler()['erro'] !== '', 'Módulo desligado ainda lê hoje.' );
	return array( 'OK', 'Agenda única diária, recuperação, execução pela ação do cron, somente datas fechadas, idempotência e desativação conferidas.' );
}
