<?php
/**
 * Sonda do SITE-CORE: as classes REAIS do plugin persistente, exercitadas.
 *
 * Subprocesso por desenho, como as outras sondas: esta monta um WordPress de
 * mentira — `wpdb` com as linhas em memória, options, transientes, hooks e
 * agendamentos — e roda o `class-f3base-modulo-endpoint-leads.php` e o
 * `class-f3base-modulo-cadencia-relatorio.php` de verdade contra ele. Nada é
 * copiado para cá: o que a sonda mede é o arquivo que viaja no pacote.
 *
 * Cada bloco tem TETO e PISO. O piso NÃO é "um caso inválido reprovou": é o
 * DEFEITO MEDIDO reproduzido na bancada, e a afirmação de que a bancada
 * realmente o reproduz sai junto. Um piso que não consegue plantar o defeito
 * prova que a bancada é cega, não que o código está certo — foi a lição que a
 * 1.0.15 pagou na sonda de instalação.
 *
 * A honestidade do limite: a bancada de banco entende as instruções que este
 * módulo emite, e só elas. Ela não é um MySQL. O que ela mede é a SEMÂNTICA
 * declarada — quantas instruções o incremento gasta, quem decide o empate, o
 * que sobra na tabela depois da falha —, e é essa semântica que os defeitos da
 * 1.0.17 violavam.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

function site_url( string $path = '' ): string { return home_url( $path ); }
function wp_cache_delete( $key, $group = '' ): bool { return true; }
function wp_generate_uuid4(): string { $b = bin2hex( random_bytes( 16 ) ); return substr( $b,0,8 ) . '-' . substr( $b,8,4 ) . '-4' . substr( $b,13,3 ) . '-a' . substr( $b,17,3 ) . '-' . substr( $b,20,12 ); }
class WP_Http {
	public static function make_absolute_url( string $url, string $base ): string {
		if ( str_contains( $url, '://' ) ) { return $url; }
		$p = parse_url( $base ); return ( $p['scheme'] ?? 'https' ) . '://' . ( $p['host'] ?? 'exemplo.test' ) . '/' . ltrim( $url, '/' );
	}
}
function get_temp_dir(): string { return sys_get_temp_dir() . '/'; }

$GLOBALS['f3b_bench'] = array(
	'options'     => array(),
	/* O autoload de cada option gravada: ele é medido, e não descartado. */
	'autoload'    => array(),
	'transientes' => array(),
	'congelados'  => null,
	'hooks'       => array(),
	'eventos'     => array(),
	'posts'       => 0,
	'ultimo_post' => array(),
	'insert_ok'   => true,
	'post_types'  => array(),
	'posts_por_tipo' => array(),
	'insert_id_cego' => false,
	'rotas'       => array(),
	'servidor'    => array( 'REMOTE_ADDR' => '203.0.113.7' ),
	'fita'        => array(),
	'scripts'     => array(),
	'ssl'         => false,
	'suportes_do_tema' => array( 'f3base-consentimento-rodape' ),
	/*
	 * PÁGINAS PUBLICADAS DA BANCADA. O censo do conteúdo demonstrativo pergunta
	 * ao BANCO, e por isso a bancada precisa ter páginas: medir a regra só pela
	 * função pura provaria a aritmética e não a consulta.
	 */
	'paginas'     => array(),
	/*
	 * A REDE DA BANCADA. `wp_remote_post()` não sai daqui: a resposta é
	 * declarada por quem monta o caso, e a última requisição fica registrada
	 * para que o piso possa medir o QUE foi enviado — que é onde mora a regra
	 * do dado pessoal em claro.
	 */
	'http'        => array(
		'resposta'  => array(
			'codigo' => 200,
			'corpo'  => '{"events_received":1,"fbtrace_id":"A0-bancada"}',
			'erro'   => '',
		),
		'requisicao' => array(),
		'chamadas'   => 0,
	),
	'agendados'   => array(),
);

/*
 * A REQUISIÇÃO DA BANCADA tem origem e user agent, porque o payload do evento
 * de servidor os carrega. Sem eles a bancada mediria o caminho degradado — o
 * que o pacote faz quando o servidor não informa nada — e nunca o normal.
 */
$_SERVER['REMOTE_ADDR']     = '203.0.113.7';
$_SERVER['HTTP_USER_AGENT'] = 'Mozilla/5.0 (bancada)';

/*
 * A raiz do WordPress de mentira fica fora do pacote: `criar_tabela()` faz
 * `require_once ABSPATH . 'wp-admin/includes/upgrade.php'`, e o arquivo precisa
 * existir. O stub é vazio — quem responde por `dbDelta()` é a bancada, logo
 * abaixo.
 */
$abspath = sys_get_temp_dir() . '/f3base-sonda-site-core-' . getmypid() . '-wp/';

if ( ! is_dir( $abspath . 'wp-admin/includes' ) ) {
	mkdir( $abspath . 'wp-admin/includes', 0777, true );
}

file_put_contents( $abspath . 'wp-admin/includes/upgrade.php', "<?php
" );

file_put_contents( $abspath . 'index.php', '<?php' );
define( 'ABSPATH', $abspath );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'MONTH_IN_SECONDS', 30 * 86400 );
define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
define( 'F3BASE_PLUGIN_URL', 'https://exemplo.test/wp-content/plugins/base-site-core-fator3/' );
/*
 * O DIRETÓRIO DO PLUGIN NA BANCADA é a árvore de FONTES, e não uma pasta de
 * mentira: é dele que sai a declaração de emissores conhecidos que o módulo
 * lê. Apontar para um diretório vazio faria a lista chegar vazia e o ramo do
 * segundo emissor nunca ser exercitado — a bancada aprovando por não medir.
 */
define( 'F3BASE_PLUGIN_DIR', $raiz . '/fontes/plugin/' );
/*
 * A versão sai do ANDAIME, não de literal: `suite/lib/andaime-config.php` guarda
 * o retrato do que `config/site.json` do implantador devolvia por
 * `release.site_core`, que é a string vazia — a chave nunca existiu no arquivo
 * entregue. Ler aqui o cabeçalho do plugin daria outro valor e faria esta
 * bancada medir outra coisa.
 */
require_once __DIR__ . '/andaime-config.php';
define( 'F3BASE_PLUGIN_VERSAO', F3Base_Andaime_Config::versao_do_plugin() );
define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
define( 'F3BASE_PREFIXO', 'f3base' );
define( 'ARRAY_A', 'ARRAY_A' );

/* ---------------------------------------------------------------------------
 * Núcleo de mentira: só o que estas classes chamam.
 * ------------------------------------------------------------------------ */

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * Sanitização de e-mail do núcleo: entrada inválida devolve string VAZIA.
 *
 * É esse retorno vazio, não conferido, que fazia o lead entrar sem endereço.
 *
 * @param string $email E-mail bruto.
 * @return string
 */
function sanitize_email( string $email ): string {
	$email = trim( $email );

	return false !== filter_var( $email, FILTER_VALIDATE_EMAIL ) ? $email : '';
}

/**
 * Sanitização de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_text_field( string $texto ): string {
	$texto = strip_tags( $texto );
	$texto = preg_replace( '/[\r\n\t]+/', ' ', $texto );

	return trim( is_string( $texto ) ? $texto : '' );
}

/**
 * Sanitização de área de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_textarea_field( string $texto ): string {
	return trim( strip_tags( $texto ) );
}

/**
 * Sanitização de chave do núcleo.
 *
 * @param string $chave Chave.
 * @return string
 */
function sanitize_key( string $chave ): string {
	$limpo = preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $chave ) );

	return is_string( $limpo ) ? $limpo : '';
}

/**
 * Escape de URL do núcleo.
 *
 * @param string $url URL.
 * @return string
 */
function esc_url_raw( string $url ): string {
	return trim( $url );
}

/**
 * Remoção das barras que o núcleo acrescenta.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function wp_unslash( $valor ) {
	return is_string( $valor ) ? stripslashes( $valor ) : $valor;
}

/**
 * URL do site.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function home_url( string $caminho = '' ): string {
	return 'https://exemplo.test' . $caminho;
}

/**
 * Parser de URL do núcleo.
 *
 * @param string $url        URL.
 * @param int    $componente Componente.
 * @return array<string,mixed>|string|int|null|false
 */
function wp_parse_url( string $url, int $componente = -1 ) {
	return -1 === $componente ? parse_url( $url ) : parse_url( $url, $componente );
}

/**
 * Sal do núcleo.
 *
 * @param string $esquema Esquema.
 * @return string
 */
function wp_salt( string $esquema = 'auth' ): string {
	return 'sal-de-bancada-' . $esquema;
}

/**
 * Aleatório do núcleo.
 *
 * @param int $minimo Mínimo.
 * @param int $maximo Máximo.
 * @return int
 */
function wp_rand( int $minimo = 0, int $maximo = 0 ): int {
	return random_int( $minimo, max( $minimo, $maximo ) );
}

/**
 * Data formatada do núcleo.
 *
 * @param string   $formato  Formato.
 * @param int|null $carimbo  Carimbo.
 * @return string
 */
function wp_date( string $formato, ?int $carimbo = null ): string {
	return gmdate( $formato, null === $carimbo ? time() : $carimbo );
}

/**
 * Diferença legível do núcleo.
 *
 * @param int $de  Início.
 * @param int $ate Fim.
 * @return string
 */
function human_time_diff( int $de, int $ate = 0 ): string {
	return (string) abs( $ate - $de ) . 's';
}

/**
 * Erro do núcleo.
 */
class WP_Error {

	/**
	 * Mensagem do erro.
	 *
	 * @var string
	 */
	public string $mensagem;

	/**
	 * Constrói o erro.
	 *
	 * @param string $codigo   Código.
	 * @param string $mensagem Mensagem.
	 */
	public function __construct( string $codigo = '', string $mensagem = '' ) {
		$this->mensagem = $codigo . ': ' . $mensagem;
	}

	/**
	 * Mensagem legível do erro.
	 *
	 * @return string
	 */
	public function get_error_message(): string {
		return $this->mensagem;
	}
}

/**
 * Predicado de erro do núcleo.
 *
 * @param mixed $valor Valor.
 * @return bool
 */
function is_wp_error( $valor ): bool {
	return $valor instanceof WP_Error;
}

/* ---------------------------------------------------------------------------
 * Options, transientes e hooks
 * ------------------------------------------------------------------------ */

/**
 * Leitura de option.
 *
 * @param string $nome   Nome.
 * @param mixed  $padrao Padrão.
 * @return mixed
 */
function get_option( string $nome, $padrao = false ) {
	return array_key_exists( $nome, $GLOBALS['f3b_bench']['options'] ) ? $GLOBALS['f3b_bench']['options'][ $nome ] : $padrao;
}

/**
 * Escrita de option, com os hooks que o núcleo dispara.
 *
 * @param string $nome     Nome.
 * @param mixed  $valor    Valor.
 * @param bool   $autoload Autoload.
 * @return bool
 */
function update_option( string $nome, $valor, bool $autoload = true ): bool {
	$existia = array_key_exists( $nome, $GLOBALS['f3b_bench']['options'] );
	$antigo  = $existia ? $GLOBALS['f3b_bench']['options'][ $nome ] : null;

	$GLOBALS['f3b_bench']['options'][ $nome ] = $valor;

	/*
	 * O AUTOLOAD É GUARDADO, e não descartado. Ele decide se a option viaja
	 * dentro do `alloptions` — a consulta que o núcleo faz uma vez por
	 * requisição e serve de cache —, e uma escrita sobre option autoloaded
	 * INVALIDA esse cache para o site inteiro. É um custo por requisição de
	 * visitante, e sem guardá-lo aqui a bancada não teria como medi-lo.
	 */
	$GLOBALS['f3b_bench']['autoload'][ $nome ] = $autoload;

	if ( ! $existia ) {
		do_action( 'added_option', $nome, $valor );

		return true;
	}

	if ( $antigo !== $valor ) {
		do_action( 'updated_option', $nome, $antigo, $valor );
	}

	return true;
}

/**
 * Remoção de option.
 *
 * @param string $nome Nome.
 * @return bool
 */
function delete_option( string $nome ): bool {
	unset( $GLOBALS['f3b_bench']['options'][ $nome ] );
	do_action( 'deleted_option', $nome );

	return true;
}

/**
 * Leitura de transiente.
 *
 * Quando a bancada está com os transientes CONGELADOS, a leitura devolve o
 * retrato tirado antes das gravações: é assim que duas requisições concorrentes
 * enxergam o mesmo valor, que é o defeito do balde por ler-modificar-gravar.
 *
 * @param string $chave Chave.
 * @return mixed
 */
function get_transient( string $chave ) {
	$fonte = null === $GLOBALS['f3b_bench']['congelados']
		? $GLOBALS['f3b_bench']['transientes']
		: $GLOBALS['f3b_bench']['congelados'];

	return array_key_exists( $chave, $fonte ) ? $fonte[ $chave ] : false;
}

/**
 * Escrita de transiente.
 *
 * @param string $chave Chave.
 * @param mixed  $valor Valor.
 * @param int    $ttl   TTL.
 * @return bool
 */
function set_transient( string $chave, $valor, int $ttl = 0 ): bool {
	$GLOBALS['f3b_bench']['transientes'][ $chave ] = $valor;

	return true;
}

/**
 * Remoção de transiente.
 *
 * @param string $chave Chave.
 * @return bool
 */
function delete_transient( string $chave ): bool {
	unset( $GLOBALS['f3b_bench']['transientes'][ $chave ] );

	return true;
}

/**
 * Registra um filtro.
 *
 * @param string   $hook       Hook.
 * @param callable $callback   Callback.
 * @param int      $prioridade Prioridade.
 * @param int      $args       Argumentos.
 * @return bool
 */
function add_filter( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	$GLOBALS['f3b_bench']['hooks'][ $hook ][] = array(
		'callback' => $callback,
		'args'     => $args,
	);

	return true;
}

/**
 * Registra uma ação.
 *
 * @param string   $hook       Hook.
 * @param callable $callback   Callback.
 * @param int      $prioridade Prioridade.
 * @param int      $args       Argumentos.
 * @return bool
 */
function add_action( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	return add_filter( $hook, $callback, $prioridade, $args );
}

/**
 * Aplica um filtro.
 *
 * @param string $hook  Hook.
 * @param mixed  $valor Valor.
 * @param mixed  ...$extras Extras.
 * @return mixed
 */
function apply_filters( string $hook, $valor, ...$extras ) {
	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		$argumentos = array_slice( array_merge( array( $valor ), $extras ), 0, max( 1, (int) $registro['args'] ) );
		$valor      = call_user_func_array( $registro['callback'], $argumentos );
	}

	return $valor;
}

/**
 * Dispara uma ação.
 *
 * @param string $hook  Hook.
 * @param mixed  ...$argumentos Argumentos.
 * @return void
 */
function do_action( string $hook, ...$argumentos ): void {
	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		call_user_func_array( $registro['callback'], array_slice( $argumentos, 0, max( 0, (int) $registro['args'] ) ) );
	}
}

/**
 * Há ouvinte registrado neste hook?
 *
 * @param string $hook Hook.
 * @return int Quantos ouvintes.
 */
function has_action( string $hook ): int {
	return count( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() );
}

/* ---------------------------------------------------------------------------
 * Agendamentos
 * ------------------------------------------------------------------------ */

/**
 * Recorrências do núcleo, ANTES de qualquer filtro.
 *
 * A lista é exatamente a do WordPress: `monthly` não existe, e `quinzenal`
 * tampouco. É esta ausência que fazia "mensal" cair em `daily` e "quinzenal"
 * cair em `weekly`, com o dobro da frequência, em silêncio.
 *
 * @return array<string,array{interval:int,display:string}>
 */
function f3b_recorrencias_do_nucleo(): array {
	return array(
		'hourly'     => array(
			'interval' => HOUR_IN_SECONDS,
			'display'  => 'Once Hourly',
		),
		'twicedaily' => array(
			'interval' => 12 * HOUR_IN_SECONDS,
			'display'  => 'Twice Daily',
		),
		'daily'      => array(
			'interval' => DAY_IN_SECONDS,
			'display'  => 'Once Daily',
		),
		'weekly'     => array(
			'interval' => 7 * DAY_IN_SECONDS,
			'display'  => 'Once Weekly',
		),
	);
}

/**
 * Recorrências disponíveis, já com os filtros aplicados.
 *
 * @return array<string,array{interval:int,display:string}>
 */
function wp_get_schedules(): array {
	return (array) apply_filters( 'cron_schedules', f3b_recorrencias_do_nucleo() );
}

/**
 * Próxima execução agendada de um hook.
 *
 * @param string $hook Hook.
 * @return int|false
 */
function wp_next_scheduled( string $hook ) {
	return isset( $GLOBALS['f3b_bench']['eventos'][ $hook ] )
		? (int) $GLOBALS['f3b_bench']['eventos'][ $hook ]['timestamp']
		: false;
}

/**
 * Evento agendado, com a recorrência.
 *
 * @param string $hook Hook.
 * @return object|false
 */
function wp_get_scheduled_event( string $hook ) {
	if ( ! isset( $GLOBALS['f3b_bench']['eventos'][ $hook ] ) ) {
		return false;
	}

	return (object) $GLOBALS['f3b_bench']['eventos'][ $hook ];
}

/**
 * Agenda um evento recorrente.
 *
 * O núcleo RECUSA recorrência que não exista na lista: é aí que o agendamento
 * sem quem registre `f3base_mensal` fracassa em vez de degradar em silêncio.
 *
 * @param int    $quando      Carimbo.
 * @param string $recorrencia Recorrência.
 * @param string $hook        Hook.
 * @return bool|WP_Error
 */
function wp_schedule_event( int $quando, string $recorrencia, string $hook ) {
	$agendas = wp_get_schedules();

	if ( ! isset( $agendas[ $recorrencia ] ) ) {
		return new WP_Error( 'invalid_schedule', 'recorrência inexistente: ' . $recorrencia );
	}

	$GLOBALS['f3b_bench']['eventos'][ $hook ] = array(
		'hook'      => $hook,
		'timestamp' => $quando,
		'schedule'  => $recorrencia,
		'interval'  => (int) $agendas[ $recorrencia ]['interval'],
		'args'      => array(),
	);

	return true;
}

/**
 * Desagenda um evento.
 *
 * @param int    $quando Carimbo.
 * @param string $hook   Hook.
 * @return bool
 */
function wp_unschedule_event( int $quando, string $hook ): bool {
	unset( $GLOBALS['f3b_bench']['eventos'][ $hook ] );

	return true;
}

/* ---------------------------------------------------------------------------
 * Conteúdo
 * ------------------------------------------------------------------------ */

/**
 * Registro de tipo de conteúdo: inerte na bancada.
 *
 * @param string              $tipo      Tipo.
 * @param array<string,mixed> $argumentos Argumentos.
 * @return void
 */
function register_post_type( string $tipo, array $argumentos = array() ): void {
	/*
	 * OS ARGUMENTOS FICAM GUARDADOS. A visibilidade da listagem do CPT de
	 * contingência é um argumento deste registro — `show_ui` —, e um stub que
	 * jogasse fora o que recebe não teria como distinguir "a listagem existe"
	 * de "a listagem sumiu do menu com os leads dentro".
	 */
	$GLOBALS['f3b_bench']['post_types'][ $tipo ] = $argumentos;
}

/**
 * Registro de rota REST: inerte na bancada.
 *
 * @param string              $espaco    Namespace.
 * @param string              $rota      Rota.
 * @param array<string,mixed> $argumentos Argumentos.
 * @return void
 */
function register_rest_route( string $espaco, string $rota, array $argumentos = array() ): void {
	unset( $espaco, $argumentos );

	$GLOBALS['f3b_bench']['rotas'][] = $rota;
}

/**
 * Inserção de conteúdo, com o interruptor de falha da bancada.
 *
 * @param array<string,mixed> $dados Dados.
 * @param bool                $erro  Devolver WP_Error.
 * @return int|WP_Error
 */
function wp_insert_post( array $dados, bool $erro = false ) {
	if ( ! $GLOBALS['f3b_bench']['insert_ok'] ) {
		return new WP_Error( 'db_insert_error', 'a bancada recusou a inserção, como o banco cheio recusaria' );
	}

	++$GLOBALS['f3b_bench']['posts'];

	$GLOBALS['f3b_bench']['ultimo_post'] = $dados;

	/*
	 * A CONTAGEM POR TIPO existe para a pergunta "há lead de contingência
	 * gravado?", que é o que decide se a listagem deles aparece no menu.
	 */
	$tipo = (string) ( $dados['post_type'] ?? '' );

	$GLOBALS['f3b_bench']['posts_por_tipo'][ $tipo ] = (int) ( $GLOBALS['f3b_bench']['posts_por_tipo'][ $tipo ] ?? 0 ) + 1;

	return $GLOBALS['f3b_bench']['posts'];
}

/**
 * Migração de tabela do núcleo: a bancada já cria a tabela completa.
 *
 * @param string $sql SQL.
 * @return array<int,string>
 */
function dbDelta( string $sql ): array { // phpcs:ignore WordPress.NamingConventions
	global $wpdb;

	$wpdb->criar_do_sql( $sql );

	return array();
}

/* ---------------------------------------------------------------------------
 * REST
 * ------------------------------------------------------------------------ */

/**
 * Requisição REST de bancada.
 */
class WP_REST_Request {

	/**
	 * Corpo como JSON.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $json;

	/**
	 * Corpo como formulário.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $form;

	/**
	 * Constrói a requisição.
	 *
	 * @param array<string,mixed>|null $json Corpo JSON.
	 * @param array<string,mixed>|null $form Corpo urlencoded.
	 */
	public function __construct( ?array $json = null, ?array $form = null ) {
		$this->json = $json;
		$this->form = $form;
	}

	/**
	 * Corpo JSON.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_json_params() {
		return $this->json;
	}

	/**
	 * Corpo urlencoded.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_body_params() {
		return $this->form;
	}

	/**
	 * Corpo cru, como o endpoint que mede tamanho o lê.
	 *
	 * @return string
	 */
	public function get_body(): string {
		$corpo = null !== $this->json ? $this->json : ( null !== $this->form ? $this->form : array() );
		$json  = wp_json_encode( $corpo );

		return is_string( $json ) ? $json : '';
	}

	/**
	 * Parâmetro solto.
	 *
	 * @param string $nome Nome.
	 * @return mixed
	 */
	public function get_param( string $nome ) {
		/*
		 * O PARÂMETRO SAI DO CORPO DA REQUISIÇÃO. Devolver `null` sempre fazia a
		 * bancada aprovar qualquer rota que LESSE o próprio parâmetro: a de
		 * emissão de token nasce com um — o caminho da página que define o
		 * escopo —, e sem isto ela seria medida sempre com o escopo vazio.
		 */
		$corpo = null !== $this->json ? $this->json : ( null !== $this->form ? $this->form : array() );

		return array_key_exists( $nome, $corpo ) ? $corpo[ $nome ] : null;
	}

	/**
	 * Cabeçalho.
	 *
	 * @param string $nome Nome.
	 * @return string|null
	 */
	public function get_header( string $nome ) {
		return null;
	}
}

/**
 * Resposta REST de bancada.
 */
class WP_REST_Response {

	/**
	 * Corpo.
	 *
	 * @var array<string,mixed>
	 */
	public array $data;

	/**
	 * Status HTTP.
	 *
	 * @var int
	 */
	public int $status;

	/**
	 * Constrói a resposta.
	 *
	 * @param array<string,mixed> $data   Corpo.
	 * @param int                 $status Status.
	 */
	public function __construct( array $data = array(), int $status = 200 ) {
		$this->data   = $data;
		$this->status = $status;
	}
}

/* ---------------------------------------------------------------------------
 * wpdb de bancada
 * ------------------------------------------------------------------------ */

/**
 * Banco de bancada: linhas em memória, com a semântica das instruções emitidas.
 *
 * Ela entende as instruções que o módulo emite, e só elas. O que importa medir
 * aqui é QUEM decide: a chave primária recusa o segundo `INSERT`, o
 * `ON DUPLICATE KEY UPDATE` soma numa instrução só, e o `UPDATE` condicionado ao
 * carimbo lido faz a retomada da reserva morta acontecer uma vez só.
 */
class F3Base_Bench_Wpdb {

	/**
	 * Prefixo das tabelas.
	 *
	 * @var string
	 */
	public string $prefix = 'wp_';

	/**
	 * Nome da tabela de posts, como o núcleo o expõe.
	 *
	 * @var string
	 */
	public string $posts = 'wp_posts';

	/**
	 * Último id gerado por LAST_INSERT_ID().
	 *
	 * @var int
	 */
	public int $insert_id = 0;

	/**
	 * Tabelas: nome => array{colunas:string[],linhas:array<string,array<string,mixed>>}.
	 *
	 * @var array<string,array<string,mixed>>
	 */
	public array $tabelas = array();

	/**
	 * Fita de instruções executadas.
	 *
	 * @var array<int,string>
	 */
	public array $fita = array();

	/**
	 * Cria a tabela a partir do CREATE TABLE do módulo.
	 *
	 * @param string $sql SQL.
	 * @return void
	 */
	public function criar_do_sql( string $sql ): void {
		if ( ! preg_match( '/CREATE TABLE ([A-Za-z0-9_]+) \((.*)\)\s*;?\s*$/s', trim( $sql ), $achado ) ) {
			return;
		}

		$nome    = $achado[1];
		$colunas = array();

		foreach ( explode( "\n", $achado[2] ) as $linha ) {
			$linha = trim( $linha );

			if ( '' === $linha || preg_match( '/^(PRIMARY KEY|KEY|UNIQUE)/i', $linha ) ) {
				continue;
			}

			if ( preg_match( '/^([a-z_]+)\s/i', $linha, $coluna ) ) {
				$colunas[] = $coluna[1];
			}
		}

		$anteriores = $this->tabelas[ $nome ]['linhas'] ?? array();

		$this->tabelas[ $nome ] = array(
			'colunas' => $colunas,
			'linhas'  => $anteriores,
		);
	}

	/**
	 * Interpola a instrução como o núcleo interpola.
	 *
	 * @param string $sql  SQL com marcadores.
	 * @param mixed  ...$argumentos Argumentos.
	 * @return string
	 */
	public function prepare( string $sql, ...$argumentos ): string {
		if ( 1 === count( $argumentos ) && is_array( $argumentos[0] ) ) {
			$argumentos = $argumentos[0];
		}

		$saida = '';
		$i     = 0;
		$n     = strlen( $sql );

		while ( $i < $n ) {
			$c = $sql[ $i ];

			if ( '%' === $c && $i + 1 < $n && in_array( $sql[ $i + 1 ], array( 's', 'd', 'f' ), true ) ) {
				$argumento = array_shift( $argumentos );

				if ( 's' === $sql[ $i + 1 ] ) {
					$saida .= "'" . addslashes( (string) $argumento ) . "'";
				} elseif ( 'f' === $sql[ $i + 1 ] ) {
					$saida .= sprintf( '%F', (float) $argumento );
				} else {
					$saida .= (string) (int) $argumento;
				}

				$i += 2;
				continue;
			}

			$saida .= $c;
			++$i;
		}

		return $saida;
	}

	/**
	 * Silenciamento de erro: a bancada nunca imprime.
	 *
	 * @param bool $silenciar Silenciar.
	 * @return bool
	 */
	public function suppress_errors( bool $silenciar = true ): bool {
		return false;
	}

	/**
	 * Escape de LIKE.
	 *
	 * @param string $texto Texto.
	 * @return string
	 */
	public function esc_like( string $texto ): string {
		return $texto;
	}

	/**
	 * Collate do núcleo.
	 *
	 * @return string
	 */
	public function get_charset_collate(): string {
		return '';
	}

	/**
	 * Valor único.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return string|null
	 */
	/**
	 * INSERT simples numa tabela de registro — aqui nada soma.
	 *
	 * A tabela agregada tem chave própria e `ON DUPLICATE KEY UPDATE`; o
	 * registro de eventos não tem chave de negócio nenhuma, de propósito: cada
	 * travessia é uma linha, e é essa granularidade que responde se o visitante
	 * voltou e leu de novo.
	 *
	 * @param string              $tabela  Nome da tabela.
	 * @param array<string,mixed> $dados   Colunas e valores.
	 * @param array<int,string>   $formato Formatos.
	 * @return int|false
	 */
	public function insert( string $tabela, array $dados, array $formato = array() ) {
		unset( $formato );

		$this->tabelas[ $tabela ] = $this->tabelas[ $tabela ] ?? array( 'linhas' => array(), 'proximo_id' => 1 );

		$id = (int) ( $this->tabelas[ $tabela ]['proximo_id'] ?? 1 );

		$this->tabelas[ $tabela ]['linhas'][ 'id-' . $id ] = array_merge( array( 'id' => $id ), $dados );
		$this->tabelas[ $tabela ]['proximo_id']            = $id + 1;
		$this->insert_id                                   = $id;

		return 1;
	}

	public function get_var( string $sql ) {
		$this->fita[] = $sql;

		if ( preg_match( "/SHOW TABLES LIKE '([^']+)'/", $sql, $achado ) ) {
			return isset( $this->tabelas[ $achado[1] ] ) ? $achado[1] : null;
		}

		/* Existe ao menos um post daquele tipo? É a pergunta da listagem de contingência. */
		if ( preg_match( "/SELECT ID FROM [A-Za-z0-9_]* WHERE post_type = '([^']*)' LIMIT 1/", $sql, $tipo_pedido ) ) {
			$quantos = (int) ( $GLOBALS['f3b_bench']['posts_por_tipo'][ $tipo_pedido[1] ] ?? 0 );

			return $quantos > 0 ? '1' : null;
		}

		if ( preg_match( "/SELECT contador FROM ([A-Za-z0-9_]+) WHERE chave = '([^']*)'/", $sql, $achado ) ) {
			$linha = $this->tabelas[ $achado[1] ]['linhas'][ $achado[2] ] ?? null;

			return null === $linha ? null : (string) $linha['contador'];
		}

		if ( preg_match( "/SELECT COUNT\(\*\) FROM wp_posts WHERE post_status = '([^']*)' AND post_type IN \( ([^)]*) \)/", $sql, $achado ) ) {
			return (string) count( self::filtrar_paginas( $achado[1], self::lista_de_tipos( $achado[2] ), null ) );
		}

		/*
		 * A CONTAGEM DA TABELA BRUTA, com os filtros opcionais de visitante e de
		 * visita. É ela que a paginação usa para saber quantas páginas há.
		 */
		if ( preg_match( "/SELECT COUNT\\(\\*\\) FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)'(.*)$/", $sql, $conta_bruta ) ) {
			return (string) count( self::filtrar_acionamentos( $this->tabelas[ $conta_bruta[1] ]['linhas'] ?? array(), $conta_bruta[2], $conta_bruta[3] ) );
		}

		/*
		 * O DIA MAIS ANTIGO DA TABELA DO RESUMO. É a resposta de
		 * `coletando_desde()`, e é o que a tela do menu Medição imprime quando
		 * o total é baixo — "faz quanto tempo?" é a primeira pergunta de quem
		 * vê um número pequeno.
		 */
		if ( preg_match( '/SELECT MIN\(dia\) FROM ([A-Za-z0-9_]+)/', $sql, $achado ) ) {
			$dias = array();

			foreach ( (array) ( $this->tabelas[ $achado[1] ]['linhas'] ?? array() ) as $linha ) {
				if ( isset( $linha['dia'] ) && '' !== (string) $linha['dia'] ) {
					$dias[] = (string) $linha['dia'];
				}
			}

			if ( array() === $dias ) {
				return null;
			}

			sort( $dias );

			return (string) $dias[0];
		}

		return null;
	}

	/**
	 * Tipos declarados no `IN (...)` de uma instrução já interpolada.
	 *
	 * @param string $trecho Trecho entre parênteses.
	 * @return array<int,string>
	 */
	private static function lista_de_tipos( string $trecho ): array {
		preg_match_all( "/'([^']*)'/", $trecho, $achados );

		return $achados[1];
	}

	/**
	 * As linhas do registro que casam com o dia e com os filtros da tela.
	 *
	 * @param array<string,array<string,mixed>> $linhas Linhas da tabela.
	 * @param string                            $desde  Dia de corte.
	 * @param string                            $extras Resto da cláusula WHERE já interpolada.
	 * @return array<int,array<string,mixed>>
	 */
	private static function filtrar_acionamentos( array $linhas, string $desde, string $extras ): array {
		$visitante = '';
		$sessao    = '';

		if ( preg_match( "/visitante = '([^']*)'/", $extras, $quem ) ) {
			$visitante = $quem[1];
		}

		if ( preg_match( "/sessao = '([^']*)'/", $extras, $qual ) ) {
			$sessao = $qual[1];
		}

		/*
		 * A LISTA DE MÉTRICAS ACEITAS. É por ela que a tabela de acionamentos
		 * mostra só comportamento de uso: a bancada precisa aplicá-la, senão
		 * aprovaria uma consulta que trouxesse tudo.
		 */
		$aceitas = array();

		if ( preg_match( '/metrica IN \( ([^)]*) \)/', $extras, $lista ) ) {
			preg_match_all( "/'([^']*)'/", $lista[1], $nomes_aceitos );

			$aceitas = $nomes_aceitos[1];
		}

		$saida = array();

		foreach ( $linhas as $linha ) {
			if ( (string) ( $linha['dia'] ?? '' ) < $desde ) {
				continue;
			}

			if ( '' !== $visitante && (string) ( $linha['visitante'] ?? '' ) !== $visitante ) {
				continue;
			}

			if ( '' !== $sessao && (string) ( $linha['sessao'] ?? '' ) !== $sessao ) {
				continue;
			}

			if ( array() !== $aceitas && ! in_array( (string) ( $linha['metrica'] ?? '' ), $aceitas, true ) ) {
				continue;
			}

			$saida[] = $linha;
		}

		return $saida;
	}

	/**
	 * As páginas da bancada que casam com status, tipo e (opcional) conteúdo.
	 *
	 * @param string      $status Status exigido.
	 * @param array<int,string> $tipos Tipos aceitos.
	 * @param string|null $marca  Trecho exigido no conteúdo, ou null.
	 * @return array<int,array<string,mixed>>
	 */
	private static function filtrar_paginas( string $status, array $tipos, ?string $marca ): array {
		$saida = array();

		foreach ( (array) ( $GLOBALS['f3b_bench']['paginas'] ?? array() ) as $pagina ) {
			if ( (string) ( $pagina['post_status'] ?? '' ) !== $status ) {
				continue;
			}

			if ( ! in_array( (string) ( $pagina['post_type'] ?? '' ), $tipos, true ) ) {
				continue;
			}

			if ( null !== $marca && ! str_contains( (string) ( $pagina['post_content'] ?? '' ), $marca ) ) {
				continue;
			}

			$saida[] = $pagina;
		}

		usort( $saida, static fn( array $a, array $b ): int => (int) $a['ID'] <=> (int) $b['ID'] );

		return $saida;
	}

	/**
	 * Conjunto de linhas — hoje, só a consulta do censo de conteúdo demonstrativo.
	 *
	 * @param string $sql   SQL já interpolada.
	 * @param string $saida Formato.
	 * @return array<int,array<string,mixed>>
	 */
	public function get_results( string $sql, string $saida = ARRAY_A ): array {
		$this->fita[] = $sql;

		/* A LEITURA DO RESUMO DE COMPORTAMENTO, agregada por caminho, evento e detalhe. */
		if ( preg_match( "/SELECT caminho, metrica, detalhe, SUM\(contagem\) AS total, SUM\(soma\) AS acumulado FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)'/", $sql, $agregado ) ) {
			$grupos = array();

			foreach ( $this->tabelas[ $agregado[1] ]['linhas'] ?? array() as $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $agregado[2] ) {
					continue;
				}

				$chave = $linha['caminho'] . '|' . $linha['metrica'] . '|' . $linha['detalhe'];

				$grupos[ $chave ] = $grupos[ $chave ] ?? array(
					'caminho'   => (string) $linha['caminho'],
					'metrica'   => (string) $linha['metrica'],
					'detalhe'   => (string) $linha['detalhe'],
					'total'     => 0,
					'acumulado' => 0.0,
				);

				$grupos[ $chave ]['total']     += (int) $linha['contagem'];
				$grupos[ $chave ]['acumulado'] += (float) $linha['soma'];
			}

			return array_values( $grupos );
		}

		/* A TABELA BRUTA: linha a linha, da mais recente para a mais antiga. */
		if ( preg_match( "/SELECT id, visitante, sessao, dia, criado_em, ms, ancora, caminho, metrica, detalhe, ocorrencia FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)'(.*) ORDER BY criado_em (ASC|DESC), CASE WHEN ancora = '' THEN 0 ELSE MOD\\(ms, 1000\\) END (ASC|DESC), id (ASC|DESC) LIMIT (\\d+) OFFSET (\\d+)/", $sql, $bruta ) ) {
			$linhas_brutas = self::filtrar_acionamentos( $this->tabelas[ $bruta[1] ]['linhas'] ?? array(), $bruta[2], $bruta[3] );

			/*
			 * A DIREÇÃO SAI DA INSTRUÇÃO, e não do gosto da bancada. Ordenar
			 * aqui sempre do mais recente para o mais antigo faria a bancada
			 * aprovar um `ORDER BY` invertido no código real — ela estaria
			 * medindo a própria ordenação, e não a do pacote.
			 */
			$sinal_do_carimbo = 'DESC' === $bruta[4] ? -1 : 1;
			$sinal_da_fracao  = 'DESC' === $bruta[5] ? -1 : 1;
			$sinal_do_id      = 'DESC' === $bruta[6] ? -1 : 1;

			usort(
				$linhas_brutas,
				static function ( array $a, array $b ) use ( $sinal_do_carimbo, $sinal_da_fracao, $sinal_do_id ): int {
					$por_carimbo = ( (int) $a['criado_em'] <=> (int) $b['criado_em'] ) * $sinal_do_carimbo;

					$fa = '' === ( $a['ancora'] ?? '' ) ? 0 : (int) $a['ms'] % 1000;
					$fb = '' === ( $b['ancora'] ?? '' ) ? 0 : (int) $b['ms'] % 1000;
					return $por_carimbo ?: ( ( $fa <=> $fb ) * $sinal_da_fracao ?: ( ( (int) $a['id'] <=> (int) $b['id'] ) * $sinal_do_id ) );
				}
			);

			return array_slice( $linhas_brutas, (int) $bruta[8], (int) $bruta[7] );
		}

		/* AS ABERTURAS DE PÁGINA, para o quadro de visitas por página. */
		if ( preg_match( "/SELECT caminho, visitante FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)' AND metrica = '([^']*)'/", $sql, $aberturas ) ) {
			$saida_das_aberturas = array();

			foreach ( $this->tabelas[ $aberturas[1] ]['linhas'] ?? array() as $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $aberturas[2] ) {
					continue;
				}

				if ( (string) ( $linha['metrica'] ?? '' ) !== $aberturas[3] ) {
					continue;
				}

				$saida_das_aberturas[] = array(
					'caminho'   => (string) $linha['caminho'],
					'visitante' => (string) $linha['visitante'],
				);
			}

			return $saida_das_aberturas;
		}

		/* OS APELIDOS DISTINTOS do período, para os filtros da tela. */
		if ( preg_match( "/SELECT DISTINCT visitante, sessao FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)'/", $sql, $distintos ) ) {
			$pares = array();

			foreach ( $this->tabelas[ $distintos[1] ]['linhas'] ?? array() as $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $distintos[2] ) {
					continue;
				}

				$pares[ $linha['visitante'] . '|' . $linha['sessao'] ] = array(
					'visitante' => (string) $linha['visitante'],
					'sessao'    => (string) $linha['sessao'],
				);
			}

			return array_values( $pares );
		}

		/* O REGISTRO DE EVENTOS, linha a linha — aqui nada é agregado. */
		if ( preg_match( "/SELECT caminho, metrica, detalhe, ocorrencia, ms, visitante FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)'/", $sql, $pedido_do_registro ) ) {
			$saida_do_registro = array();

			foreach ( $this->tabelas[ $pedido_do_registro[1] ]['linhas'] ?? array() as $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $pedido_do_registro[2] ) {
					continue;
				}

				$saida_do_registro[] = array(
					'caminho'    => (string) $linha['caminho'],
					'metrica'    => (string) $linha['metrica'],
					'detalhe'    => (string) $linha['detalhe'],
					'ocorrencia' => (int) $linha['ocorrencia'],
					'ms'         => (int) $linha['ms'],
					'visitante'  => (string) $linha['visitante'],
				);
			}

			return $saida_do_registro;
		}

		/* PESSOAS DIFERENTES POR DIA, contadas pelo apelido. */
		if ( preg_match( "/SELECT dia, COUNT\(DISTINCT visitante\) AS visitantes FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)'/", $sql, $pedido_do_dia ) ) {
			$por_dia = array();

			foreach ( $this->tabelas[ $pedido_do_dia[1] ]['linhas'] ?? array() as $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $pedido_do_dia[2] ) {
					continue;
				}

				$por_dia[ (string) $linha['dia'] ][ (string) $linha['visitante'] ] = true;
			}

			$saida_do_dia = array();

			foreach ( $por_dia as $dia_lido => $apelidos ) {
				$saida_do_dia[] = array(
					'dia'        => (string) $dia_lido,
					'visitantes' => count( $apelidos ),
				);
			}

			return $saida_do_dia;
		}

		/*
		 * A LEITURA DA PROFUNDIDADE POR PÁGINA. Ela é uma consulta própria — e
		 * não a agregada acima — porque pede DUAS métricas nomeadas: a rolagem
		 * e o contador de carregamentos, que é o denominador da proporção.
		 */
		if ( preg_match( "/SELECT caminho, metrica, detalhe, SUM\(contagem\) AS total FROM ([A-Za-z0-9_]+) WHERE dia >= '([^']*)' AND metrica IN \( ([^)]*) \)/", $sql, $pedido ) ) {
			$aceitas = self::lista_de_tipos( $pedido[3] );
			$grupos  = array();

			foreach ( $this->tabelas[ $pedido[1] ]['linhas'] ?? array() as $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $pedido[2] ) {
					continue;
				}

				if ( ! in_array( (string) $linha['metrica'], $aceitas, true ) ) {
					continue;
				}

				$chave = $linha['caminho'] . '|' . $linha['metrica'] . '|' . $linha['detalhe'];

				$grupos[ $chave ] = $grupos[ $chave ] ?? array(
					'caminho' => (string) $linha['caminho'],
					'metrica' => (string) $linha['metrica'],
					'detalhe' => (string) $linha['detalhe'],
					'total'   => 0,
				);

				$grupos[ $chave ]['total'] += (int) $linha['contagem'];
			}

			return array_values( $grupos );
		}

		if ( ! preg_match( "/SELECT ID, post_title, post_type FROM wp_posts WHERE post_status = '([^']*)' AND post_type IN \( ([^)]*) \) AND post_content LIKE '%([^']*)%'/", $sql, $achado ) ) {
			return array();
		}

		$linhas = array();

		foreach ( self::filtrar_paginas( $achado[1], self::lista_de_tipos( $achado[2] ), $achado[3] ) as $pagina ) {
			$linhas[] = array(
				'ID'         => (int) $pagina['ID'],
				'post_title' => (string) $pagina['post_title'],
				'post_type'  => (string) $pagina['post_type'],
			);
		}

		return $linhas;
	}

	/**
	 * Coluna inteira.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return array<int,string>
	 */
	public function get_col( string $sql ): array {
		$this->fita[] = $sql;

		if ( preg_match( '/SHOW COLUMNS FROM ([A-Za-z0-9_]+)/', $sql, $achado ) ) {
			return $this->tabelas[ $achado[1] ]['colunas'] ?? array();
		}

		return array();
	}

	/**
	 * Uma linha.
	 *
	 * @param string $sql   SQL já interpolada.
	 * @param string $saida Formato.
	 * @return array<string,mixed>|null
	 */
	public function get_row( string $sql, string $saida = ARRAY_A ) {
		$this->fita[] = $sql;

		if ( ! preg_match( '/FROM ([A-Za-z0-9_]+)/', $sql, $tabela ) ) {
			return null;
		}

		if ( ! preg_match( "/WHERE chave = '([^']*)'/", $sql, $chave ) ) {
			return null;
		}

		return $this->tabelas[ $tabela[1] ]['linhas'][ $chave[1] ] ?? null;
	}

	/**
	 * Instrução de escrita.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return int|false Linhas afetadas.
	 */
	public function query( string $sql ) {
		$this->fita[] = $sql;

		if ( str_starts_with( ltrim( $sql ), 'INSERT INTO' ) ) {
			return $this->inserir( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'UPDATE' ) ) {
			return $this->atualizar( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'DELETE' ) ) {
			return $this->apagar( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'DROP' ) ) {
			return 0;
		}

		return false;
	}

	/**
	 * INSERT, com e sem ON DUPLICATE KEY UPDATE.
	 *
	 * @param string $sql SQL.
	 * @return int|false
	 */
	private function inserir( string $sql ) {
		if ( ! preg_match( '/INSERT INTO ([A-Za-z0-9_]+) \(([^)]*)\) VALUES \(([^)]*)\)/', $sql, $achado ) ) {
			return false;
		}

		$tabela = $achado[1];

		if ( ! isset( $this->tabelas[ $tabela ] ) ) {
			return false;
		}

		$colunas = array_map( 'trim', explode( ',', $achado[2] ) );
		$valores = $this->argumentos( $achado[3] );

		if ( count( $colunas ) !== count( $valores ) ) {
			return false;
		}

		$linha = array_combine( $colunas, $valores );
		$chave = (string) $linha['chave'];

		if ( ! isset( $this->tabelas[ $tabela ]['linhas'][ $chave ] ) ) {
			$this->tabelas[ $tabela ]['linhas'][ $chave ] = $linha;

			return 1;
		}

		if ( ! str_contains( $sql, 'ON DUPLICATE KEY UPDATE' ) ) {
			/* A CHAVE PRIMÁRIA DECIDE O EMPATE: o segundo INSERT não entra. */
			return false;
		}

		$atual = $this->tabelas[ $tabela ]['linhas'][ $chave ];

		/*
		 * A SOMA DO RESUMO DE COMPORTAMENTO: duas sessões na mesma linha do dia,
		 * numa instrução só. É esta forma que a bancada precisa entender para
		 * que "duas sessões somam" seja medido, e não afirmado.
		 */
		if ( preg_match( '/contagem = contagem \+ (\d+), soma = soma \+ (-?[\d.]+), atualizado_em = (\d+)/', $sql, $soma ) ) {
			$atual['contagem']      = (int) $atual['contagem'] + (int) $soma[1];
			$atual['soma']          = (float) $atual['soma'] + (float) $soma[2];
			$atual['atualizado_em'] = (int) $soma[3];

			$this->tabelas[ $tabela ]['linhas'][ $chave ] = $atual;

			return 2;
		}

		if ( ! preg_match( '/contador = LAST_INSERT_ID\( IF\( expira_em < (\d+), 1, contador \+ 1 \) \)/', $sql, $conta ) ) {
			return false;
		}

		if ( ! preg_match( '/expira_em = IF\( expira_em < (\d+), (\d+), expira_em \)/', $sql, $prazo ) ) {
			return false;
		}

		$expirou = (int) $atual['expira_em'] < (int) $conta[1];

		$atual['contador']  = $expirou ? 1 : (int) $atual['contador'] + 1;
		$atual['expira_em'] = (int) $atual['expira_em'] < (int) $prazo[1] ? (int) $prazo[2] : (int) $atual['expira_em'];

		$this->tabelas[ $tabela ]['linhas'][ $chave ] = $atual;

		/* Driver que não devolve LAST_INSERT_ID(): o interruptor da bancada. */
		$this->insert_id = $GLOBALS['f3b_bench']['insert_id_cego'] ? 0 : (int) $atual['contador'];

		return 2;
	}

	/**
	 * UPDATE, nas duas formas que o módulo emite.
	 *
	 * @param string $sql SQL.
	 * @return int|false
	 */
	private function atualizar( string $sql ) {
		if ( ! preg_match( '/UPDATE ([A-Za-z0-9_]+) SET/', $sql, $achado ) ) {
			return false;
		}

		$tabela = $achado[1];

		if ( ! preg_match( "/WHERE chave = '([^']*)'/", $sql, $chave ) || ! isset( $this->tabelas[ $tabela ]['linhas'][ $chave[1] ] ) ) {
			return 0;
		}

		$linha = $this->tabelas[ $tabela ]['linhas'][ $chave[1] ];

		if ( preg_match( "/AND estado = '([^']*)'/", $sql, $estado ) && (string) $linha['estado'] !== $estado[1] ) {
			return 0;
		}

		if ( preg_match( '/AND criado_em = (\d+)/', $sql, $carimbo ) && (int) $linha['criado_em'] !== (int) $carimbo[1] ) {
			return 0;
		}

		if ( preg_match( "/SET record_id = '([^']*)', criado_em = (\d+), expira_em = (\d+)/", $sql, $set ) ) {
			$linha['record_id'] = $set[1];
			$linha['criado_em'] = (int) $set[2];
			$linha['expira_em'] = (int) $set[3];
		} elseif ( preg_match( "/SET estado = '([^']*)'/", $sql, $set ) ) {
			$linha['estado'] = $set[1];
		} else {
			return false;
		}

		$this->tabelas[ $tabela ]['linhas'][ $chave[1] ] = $linha;

		return 1;
	}

	/**
	 * DELETE, nas duas formas que o módulo emite.
	 *
	 * @param string $sql SQL.
	 * @return int
	 */
	private function apagar( string $sql ): int {
		if ( ! preg_match( '/DELETE FROM ([A-Za-z0-9_]+)/', $sql, $achado ) || ! isset( $this->tabelas[ $achado[1] ] ) ) {
			return 0;
		}

		$tabela = $achado[1];

		if ( preg_match( "/WHERE chave = '([^']*)' AND estado = '([^']*)'/", $sql, $par ) ) {
			$linha = $this->tabelas[ $tabela ]['linhas'][ $par[1] ] ?? null;

			if ( null === $linha || (string) $linha['estado'] !== $par[2] ) {
				return 0;
			}

			unset( $this->tabelas[ $tabela ]['linhas'][ $par[1] ] );

			return 1;
		}

		/* O ESQUECIMENTO DE UM VISITANTE: só as linhas dele, e as dos outros ficam. */
		if ( preg_match( "/WHERE visitante = '([^']*)'/", $sql, $quem ) ) {
			$removidas = 0;

			foreach ( $this->tabelas[ $tabela ]['linhas'] as $chave => $linha ) {
				if ( (string) ( $linha['visitante'] ?? '' ) === $quem[1] ) {
					unset( $this->tabelas[ $tabela ]['linhas'][ $chave ] );
					++$removidas;
				}
			}

			return $removidas;
		}

		/* A PODA DO RESUMO DE COMPORTAMENTO: tudo o que é de antes do corte sai. */
		if ( preg_match( "/WHERE dia < '([^']*)'/", $sql, $corte ) ) {
			$removidas = 0;

			foreach ( $this->tabelas[ $tabela ]['linhas'] as $chave => $linha ) {
				if ( (string) ( $linha['dia'] ?? '' ) < $corte[1] ) {
					unset( $this->tabelas[ $tabela ]['linhas'][ $chave ] );
					++$removidas;
				}
			}

			return $removidas;
		}

		if ( ! preg_match( "/WHERE criado_em < (\d+) OR \( expira_em > 0 AND expira_em < (\d+) \) OR \( estado = '([^']*)' AND criado_em < (\d+) \)/", $sql, $poda ) ) {
			return 0;
		}

		$removidas = 0;

		foreach ( $this->tabelas[ $tabela ]['linhas'] as $chave => $linha ) {
			$velha     = (int) $linha['criado_em'] < (int) $poda[1];
			$expirada  = (int) $linha['expira_em'] > 0 && (int) $linha['expira_em'] < (int) $poda[2];
			$abandonada = (string) $linha['estado'] === $poda[3] && (int) $linha['criado_em'] < (int) $poda[4];

			if ( $velha || $expirada || $abandonada ) {
				unset( $this->tabelas[ $tabela ]['linhas'][ $chave ] );
				++$removidas;
			}
		}

		return $removidas;
	}

	/**
	 * Valores literais de um trecho de instrução, na ordem em que aparecem.
	 *
	 * @param string $trecho Trecho.
	 * @return array<int,mixed>
	 */
	private function argumentos( string $trecho ): array {
		preg_match_all( "/'((?:[^'\\\\]|\\\\.)*)'|(-?\d+\.\d+)|(-?\d+)/", $trecho, $achados, PREG_SET_ORDER );

		$saida = array();

		foreach ( $achados as $achado ) {
			if ( isset( $achado[3] ) && '' !== $achado[3] ) {
				$saida[] = (int) $achado[3];
				continue;
			}

			if ( isset( $achado[2] ) && '' !== $achado[2] ) {
				$saida[] = (float) $achado[2];
				continue;
			}

			$saida[] = stripslashes( $achado[1] );
		}

		return $saida;
	}
}

$wpdb = new F3Base_Bench_Wpdb();

/**
 * Plural do núcleo: eco, escolhendo pela contagem.
 *
 * @param string $singular Forma singular.
 * @param string $plural   Forma plural.
 * @param int    $numero   Contagem.
 * @param string $dominio  Domínio.
 * @return string
 */
function _n( string $singular, string $plural, int $numero, string $dominio = '' ): string {
	return 1 === $numero ? $singular : $plural;
}

/**
 * HTTPS na requisição — declarado pela bancada.
 *
 * O valor mora no estado da bancada e não num literal: é ele que separa o ramo
 * em que o HSTS sai do ramo em que ele não sai, e um literal aqui apagaria um
 * dos dois.
 *
 * @return bool
 */
function is_ssl(): bool {
	return (bool) ( $GLOBALS['f3b_bench']['ssl'] ?? false );
}

/**
 * Contexto administrativo: a bancada mede o front-end.
 *
 * @return bool
 */
function is_admin(): bool {
	return false;
}

/**
 * Suporte declarado pelo tema — declarado pela bancada.
 *
 * O valor mora no estado da bancada porque ele separa dois ramos reais: o tema
 * desta base fornece o controle de consentimento na part do rodapé, e o
 * site-core imprime o dele quando o tema não fornece.
 *
 * @param string $suporte Nome do suporte.
 * @return bool
 */
function current_theme_supports( string $suporte ): bool {
	return in_array( $suporte, (array) ( $GLOBALS['f3b_bench']['suportes_do_tema'] ?? array() ), true );
}

/**
 * Registro de enfileiramento: a bancada guarda o que foi para a página.
 *
 * @param string              $handle Handle.
 * @param string              $src    Origem.
 * @param array<int,string>   $deps   Dependências.
 * @param mixed               $ver    Versão.
 * @param array<string,mixed> $args   Argumentos.
 * @return void
 */
function wp_enqueue_script( string $handle, string $src = '', array $deps = array(), $ver = false, $args = array() ): void {
	$GLOBALS['f3b_bench']['scripts'][ $handle ] = array(
		'src'   => $src,
		'deps'  => $deps,
		'ver'   => $ver,
		'args'  => $args,
		'dados' => array(),
	);
}

/**
 * Dados localizados de um script já enfileirado.
 *
 * @param string             $handle Handle.
 * @param string             $objeto Nome do objeto global.
 * @param array<string,mixed> $dados Dados.
 * @return bool
 */
function wp_localize_script( string $handle, string $objeto, array $dados ): bool {
	if ( ! isset( $GLOBALS['f3b_bench']['scripts'][ $handle ] ) ) {
		return false;
	}

	$GLOBALS['f3b_bench']['scripts'][ $handle ]['dados'][ $objeto ] = $dados;

	return true;
}

/**
 * Escape de atributo do núcleo.
 *
 * A bancada precisa dele de verdade — e não como eco — porque a regra do valor
 * fora da forma é: PRESERVAR e escapar, nunca apagar. Um eco aqui deixaria o
 * piso do markup passar sobre um valor que, em produção, sairia como markup.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_attr( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES, 'UTF-8' );
}

/**
 * Tipos de post públicos — declarados pela bancada, nunca literais na regra.
 *
 * @param array<string,mixed> $argumentos Filtros.
 * @param string              $saida      Formato.
 * @return array<int,string>
 */
function get_post_types( array $argumentos = array(), string $saida = 'names' ): array {
	unset( $argumentos );
	if ( 'objects' === $saida ) { return array( 'post' => (object) array( 'labels' => (object) array( 'name' => 'Posts' ) ), 'page' => (object) array( 'labels' => (object) array( 'name' => 'Páginas' ) ) ); }
	return array( 'post' => 'post', 'page' => 'page' );
}

/**
 * Agendamento de evento ÚNICO: a bancada guarda hook e argumentos.
 *
 * @param int               $quando Carimbo.
 * @param string            $hook   Hook.
 * @param array<int,mixed>  $args   Argumentos.
 * @return bool
 */
function wp_schedule_single_event( int $quando, string $hook, array $args = array() ) {
	if ( ! empty( $GLOBALS['f3b_bench']['agendamento_recusado'] ) ) {
		return false;
	}

	$GLOBALS['f3b_bench']['agendados'][] = array(
		'quando' => $quando,
		'hook'   => $hook,
		'args'   => $args,
	);

	return true;
}

/**
 * A rede da bancada: nada sai daqui, e o que SERIA enviado fica registrado.
 *
 * Registrar a requisição é o que torna o piso do dado pessoal mensurável: a
 * pergunta "saiu e-mail em claro?" só tem resposta olhando o corpo que a
 * chamada montou.
 *
 * @param string              $url  Endereço.
 * @param array<string,mixed> $args Argumentos.
 * @return array<string,mixed>|WP_Error
 */
function wp_remote_post( string $url, array $args = array() ) {
	$GLOBALS['f3b_bench']['http']['requisicao'] = array(
		'url'  => $url,
		'args' => $args,
	);
	++$GLOBALS['f3b_bench']['http']['chamadas'];

	$declarada = $GLOBALS['f3b_bench']['http']['resposta'];

	if ( '' !== (string) $declarada['erro'] ) {
		return new WP_Error( 'http_request_failed', (string) $declarada['erro'] );
	}

	return array(
		'response' => array( 'code' => (int) $declarada['codigo'] ),
		'body'     => (string) $declarada['corpo'],
	);
}

/**
 * Código HTTP de uma resposta da bancada.
 *
 * @param mixed $resposta Resposta.
 * @return int
 */
function wp_remote_retrieve_response_code( $resposta ): int {
	return is_array( $resposta ) ? (int) ( $resposta['response']['code'] ?? 0 ) : 0;
}

/**
 * Corpo de uma resposta da bancada.
 *
 * @param mixed $resposta Resposta.
 * @return string
 */
function wp_remote_retrieve_body( $resposta ): string {
	return is_array( $resposta ) ? (string) ( $resposta['body'] ?? '' ) : '';
}

/* ---------------------------------------------------------------------------
 * As classes REAIS do pacote
 * ------------------------------------------------------------------------ */

$fonte = $raiz . '/fontes/plugin/includes/';

/* ---------------------------------------------------------------------------
 * O MÍNIMO DO WP-ADMIN, para rodar a TELA REAL contra o DOM.
 *
 * A tela é o entregável da 1.1.4: ela deixou de ser lista na ordem do catálogo
 * e passou a ser blocos por assunto com impacto e exemplo por campo. Medir isso
 * lendo o arquivo com expressão regular seria conferir a intenção; o que estas
 * funções permitem é conferir o HTML QUE O OPERADOR RECEBE.
 * ------------------------------------------------------------------------ */

/**
 * Consulta de posts do núcleo: a bancada não tem lixeira a arquivar.
 *
 * A rotina de retenção percorre dois eixos — os leads que passaram do prazo e
 * as linhas do resumo de comportamento —, e é o SEGUNDO que esta bancada mede.
 * O primeiro precisa de um WP_Query de verdade, e prometer que a bancada o
 * exercita seria afirmar mais do que ela faz.
 *
 * @param array<string,mixed> $argumentos Argumentos.
 * @return array<int,mixed>
 */
function get_posts( array $argumentos = array() ): array {
	$declarado = (array) ( $GLOBALS['f3b_bench']['conteudo'] ?? array() );

	if ( array() === $declarado ) {
		return array();
	}

	$tipos  = (array) ( $argumentos['post_type'] ?? array() );
	$estados = array_map( 'strval', (array) ( $argumentos['post_status'] ?? 'publish' ) );
	$saida  = array();

	foreach ( $declarado as $post ) {
		if ( array() !== $tipos && ! in_array( $post->post_type, array_map( 'strval', $tipos ), true ) ) {
			continue;
		}

		if ( array() !== $estados && ! in_array( (string) $post->post_status, $estados, true ) ) {
			continue;
		}

		$saida[] = $post;
	}

	usort( $saida, static fn ( $a, $b ): int => strcmp( (string) $b->post_date_gmt, (string) $a->post_date_gmt ) );

	$teto = (int) ( $argumentos['numberposts'] ?? 0 );

	return $teto > 0 ? array_slice( $saida, 0, $teto ) : $saida;
}

/**
 * Envio para a lixeira: sem post na bancada, nada é enviado.
 *
 * @param int $id Identificador.
 * @return bool
 */
function wp_trash_post( int $id ): bool {
	return false;
}

/**
 * Eliminação definitiva: idem.
 *
 * @param int  $id      Identificador.
 * @param bool $forcar  Forçar.
 * @return bool
 */
function wp_delete_post( int $id, bool $forcar = false ): bool {
	return false;
}

/**
 * Existência de um tipo de post na bancada.
 *
 * @param string $tipo Tipo.
 * @return bool
 */
function post_type_exists( string $tipo ): bool {
	return in_array( $tipo, get_post_types(), true );
}

/**
 * Escape de HTML.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_html( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES, 'UTF-8' );
}

/**
 * Escape de HTML com tradução.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function esc_html__( string $texto, string $dominio = '' ): string {
	return esc_html( $texto );
}

/**
 * Escape de textarea.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_textarea( string $texto ): string {
	return esc_html( $texto );
}

/**
 * Escape de URL para atributo.
 *
 * @param string $url URL.
 * @return string
 */
function esc_url( string $url ): string {
	return esc_url_raw( $url );
}

/**
 * Endereço da política de privacidade publicada.
 *
 * A bancada precisa dele porque, a partir da 1.1.5, ela roda o enfileiramento
 * REAL do módulo de consentimento — e é ali que o endereço da política viaja
 * para o navegador, junto dos textos do banner.
 *
 * @return string
 */
function get_privacy_policy_url(): string {
	return (string) ( $GLOBALS['f3b_bench']['politica_url'] ?? '' );
}

/**
 * Endereço de uma rota REST.
 *
 * @param string $caminho Caminho da rota.
 * @return string
 */
function rest_url( string $caminho = '' ): string {
	return 'https://exemplo.test/wp-json/' . ltrim( $caminho, '/' );
}

/**
 * Endereço do wp-admin.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function admin_url( string $caminho = '' ): string {
	return 'https://exemplo.test/wp-admin/' . ltrim( $caminho, '/' );
}

/**
 * Acréscimo de argumentos a uma URL.
 *
 * @param array<string,mixed> $argumentos Argumentos.
 * @param string              $url        URL.
 * @return string
 */
function add_query_arg( array $argumentos, string $url = '' ): string {
	return $url . '?' . http_build_query( $argumentos );
}

/**
 * Atributo checked do núcleo.
 *
 * @param mixed $atual    Valor atual.
 * @param mixed $esperado Valor esperado.
 * @param bool  $imprimir Imprimir.
 * @return string
 */
function checked( $atual, $esperado = true, bool $imprimir = true ): string {
	return $atual === $esperado ? " checked='checked'" : '';
}

/**
 * Atributo selected do núcleo.
 *
 * @param mixed $atual    Valor atual.
 * @param mixed $esperado Valor esperado.
 * @param bool  $imprimir Imprimir.
 * @return string
 */
function selected( $atual, $esperado = true, bool $imprimir = true ): string {
	return $atual === $esperado ? " selected='selected'" : '';
}

/**
 * Botão de envio do núcleo.
 *
 * @param string $texto Texto.
 * @return void
 */
function submit_button( string $texto = '' ): void {
	echo '<p class="submit"><input type="submit" class="button button-primary" value="' . esc_attr( $texto ) . '" /></p>';
}

/**
 * Campo de nonce do núcleo.
 *
 * @param string $acao Ação.
 * @return void
 */
function wp_nonce_field( string $acao = '' ): void {
	echo '<input type="hidden" name="_wpnonce" value="bancada" />';
}

/**
 * Capability do núcleo: a bancada declara quem está olhando.
 *
 * @param string $capacidade Capacidade.
 * @return bool
 */
function current_user_can( string $capacidade ): bool {
	return (bool) ( $GLOBALS['f3b_bench']['pode'] ?? true );
}

/**
 * Id do usuário atual.
 *
 * @return int
 */
function get_current_user_id(): int {
	return 1;
}

/**
 * Morte do núcleo: na bancada ela vira exceção nomeada.
 *
 * @param string $mensagem Mensagem.
 * @param int    $status   Status.
 * @return void
 * @throws RuntimeException Sempre.
 */
function wp_die( string $mensagem = '', int $status = 0 ): void {
	throw new RuntimeException( 'wp_die:' . $status . ':' . $mensagem );
}

/**
 * Número formatado do núcleo.
 *
 * @param float $numero Número.
 * @param int   $casas  Casas decimais.
 * @return string
 */
function number_format_i18n( float $numero, int $casas = 0 ): string {
	return number_format( $numero, $casas, ',', '.' );
}

/**
 * Enfileiramento de estilo: a bancada só registra que aconteceu.
 *
 * @param string $handle Handle.
 * @param string $src    Origem.
 * @param array  $deps   Dependências.
 * @param mixed  $ver    Versão.
 * @return void
 */
function wp_enqueue_style( string $handle, string $src = '', array $deps = array(), $ver = false ): void {
	$GLOBALS['f3b_bench']['estilos'][] = $handle;
}

/* ---------------------------------------------------------------------------
 * Núcleo de apoio ao arquivo llms.txt.
 *
 * São funções do WordPress que a bancada precisa ter para que as REGRAS do
 * pacote possam rodar contra ela. Nenhuma delas é regra deste pacote: o que se
 * mede aqui é o que `F3Base_Llms` e os dois módulos decidem, não a fidelidade
 * destas cópias.
 * ------------------------------------------------------------------------ */

/**
 * Barra final, como o núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function trailingslashit( string $texto ): string {
	return rtrim( $texto, '/\\' ) . '/';
}

/**
 * Remoção de shortcodes: a bancada declara os que existem.
 *
 * @param string $conteudo Conteúdo.
 * @return string
 */
function strip_shortcodes( string $conteudo ): string {
	return (string) preg_replace( '/\[\/?[a-z0-9_-]+[^\]]*\]/i', '', $conteudo );
}

/**
 * Remoção de todas as tags, preservando o texto de dentro — como o núcleo.
 *
 * @param string $texto     Texto.
 * @param bool   $quebras   Remover quebras.
 * @return string
 */
function wp_strip_all_tags( string $texto, bool $quebras = false ): string {
	$texto = (string) preg_replace( '@<(script|style)[^>]*?>.*?</\1>@si', '', $texto );
	$texto = strip_tags( $texto );

	return $quebras ? trim( (string) preg_replace( '/[\r\n\t ]+/', ' ', $texto ) ) : trim( $texto );
}

/**
 * Corte em PALAVRAS, como o núcleo.
 *
 * @param string $texto    Texto.
 * @param int    $palavras Quantidade.
 * @param string $mais     Sufixo.
 * @return string
 */
function wp_trim_words( string $texto, int $palavras = 55, string $mais = '' ): string {
	$partes = preg_split( '/\s+/u', trim( $texto ) ) ?: array();

	if ( count( $partes ) <= $palavras ) {
		return implode( ' ', $partes );
	}

	return implode( ' ', array_slice( $partes, 0, $palavras ) ) . $mais;
}

/**
 * Meta de post: a bancada guarda por id e chave.
 *
 * @param int    $id     Identificador.
 * @param string $chave  Chave.
 * @param bool   $unico  Único.
 * @return mixed
 */
function get_post_meta( int $id, string $chave = '', bool $unico = false ) {
	$metas = $GLOBALS['f3b_bench']['metas'][ $id ] ?? array();

	if ( '' === $chave ) {
		return $metas;
	}

	$valor = $metas[ $chave ] ?? '';

	return $unico ? $valor : array( $valor );
}

/**
 * Tipo de um post declarado na bancada.
 *
 * @param int $id Identificador.
 * @return string|false
 */
function get_post_type( int $id = 0 ) {
	foreach ( (array) ( $GLOBALS['f3b_bench']['conteudo'] ?? array() ) as $post ) {
		if ( (int) $post->ID === $id ) {
			return (string) $post->post_type;
		}
	}

	return false;
}

/**
 * Permalink declarado na bancada.
 *
 * @param mixed $post Post.
 * @return string
 */
function get_permalink( $post = 0 ): string {
	$id = is_object( $post ) ? (int) $post->ID : (int) $post;

	return home_url( '/' ) . 'conteudo-' . $id . '/';
}

/**
 * Título declarado na bancada.
 *
 * @param mixed $post Post.
 * @return string
 */
function get_the_title( $post = 0 ): string {
	if ( is_object( $post ) && isset( $post->post_title ) ) {
		return (string) $post->post_title;
	}

	return '';
}

/**
 * Objeto de post do núcleo, na forma que o pacote lê.
 */
class WP_Post {

	/**
	 * Campos lidos pelo pacote.
	 *
	 * @var mixed
	 */
	public $ID = 0;

	/**
	 * Título.
	 *
	 * @var string
	 */
	public $post_title = '';

	/**
	 * Tipo.
	 *
	 * @var string
	 */
	public $post_type = 'page';

	/**
	 * Situação.
	 *
	 * @var string
	 */
	public $post_status = 'publish';
	public $post_password = '';

	/**
	 * Data em GMT.
	 *
	 * @var string
	 */
	public $post_date_gmt = '';

	/**
	 * Corpo.
	 *
	 * @var string
	 */
	public $post_content = '';

	/**
	 * Resumo declarado.
	 *
	 * @var string
	 */
	public $post_excerpt = '';
}

/**
 * Decodificação de entidades, como o núcleo.
 *
 * @param string $texto Texto.
 * @param int    $quotes Flags.
 * @return string
 */
function wp_specialchars_decode( string $texto, int $quotes = 0 ): string {
	return html_entity_decode( $texto, ENT_QUOTES, 'UTF-8' );
}

/**
 * Informação do site declarada pela bancada.
 *
 * @param string $campo Campo.
 * @return string
 */
function get_bloginfo( string $campo = 'name' ): string {
	$dados = (array) ( $GLOBALS['f3b_bench']['bloginfo'] ?? array() );

	return (string) ( $dados[ $campo ] ?? ( 'name' === $campo ? 'Site da bancada' : '' ) );
}

/**
 * Instalação em rede: a bancada é sempre site único.
 *
 * @return bool
 */
function is_multisite(): bool {
	return false;
}

/**
 * O sitemap do núcleo está habilitado nesta bancada?
 *
 * @return bool
 */
function wp_sitemaps_get_server() {
	return new class {
		public $index;
		public function __construct() { $this->index = new class { public function get_index_url(): string { return home_url( '/wp-sitemap.xml' ); } }; }
		public function sitemaps_enabled(): bool { return ! empty( $GLOBALS['f3b_bench']['sitemap_do_nucleo'] ); }
	};
}


/* ---------------------------------------------------------------------------
 * A FORMA DA REQUISIÇÃO, na bancada.
 *
 * Sem estas funções, `is_singular()` e as irmãs não existiam aqui — e por isso
 * NENHUM callback de módulo tinha sido chamado uma vez sequer. A suíte fechava
 * verde com 197 checagens enquanto o filtro `wp_robots` derrubava toda página
 * singular do site em produção, no meio do `<head>`.
 *
 * O ramo que um módulo toma depende da forma da requisição. Medir uma forma só
 * — ou nenhuma, que era o caso — deixa os outros ramos sem execução, e ramo sem
 * execução é ramo sem teste, por mais checagens que a suíte tenha.
 * ------------------------------------------------------------------------ */

$GLOBALS['f3b_forma'] = array(
	'singular' => false,
	'tipo'     => '',
	'id'       => 0,
	'tax'      => false,
	'termo'    => null,
	'busca'    => false,
	'404'      => false,
	'home'     => false,
	'front'    => false,
	'autor'    => false,
	'data'     => false,
);

/**
 * Declara a forma da requisição da bancada.
 *
 * @param array<string,mixed> $forma Campos a sobrescrever.
 * @return void
 */
function f3b_forma( array $forma = array() ): void {
	$GLOBALS['f3b_forma'] = array_merge(
		array(
			'singular' => false,
			'tipo'     => '',
			'id'       => 0,
			'tax'      => false,
			'termo'    => null,
			'busca'    => false,
			'404'      => false,
			'home'     => false,
			'front'    => false,
			'autor'    => false,
			'data'     => false,
		),
		$forma
	);
}

/**
 * Lê um campo da forma corrente.
 *
 * @param string $campo Campo.
 * @return mixed
 */
function f3b_forma_de( string $campo ) {
	return $GLOBALS['f3b_forma'][ $campo ] ?? null;
}

/**
 * É requisição singular?
 *
 * @param mixed $tipos Tipos aceitos.
 * @return bool
 */
function is_singular( $tipos = '' ): bool {
	if ( ! (bool) f3b_forma_de( 'singular' ) ) {
		return false;
	}

	if ( '' === $tipos || array() === $tipos ) {
		return true;
	}

	return in_array( (string) f3b_forma_de( 'tipo' ), array_map( 'strval', (array) $tipos ), true );
}

/**
 * É arquivo de taxonomia?
 *
 * @return bool
 */
function is_tax(): bool {
	return (bool) f3b_forma_de( 'tax' );
}

/**
 * É arquivo de categoria?
 *
 * @return bool
 */
function is_category(): bool {
	return false;
}

/**
 * É arquivo de tag?
 *
 * @return bool
 */
function is_tag(): bool {
	return false;
}

/**
 * É busca?
 *
 * @return bool
 */
function is_search(): bool {
	return (bool) f3b_forma_de( 'busca' );
}

/**
 * É 404?
 *
 * @return bool
 */
function is_404(): bool {
	return (bool) f3b_forma_de( '404' );
}

/**
 * É a listagem de posts?
 *
 * @return bool
 */
function is_home(): bool {
	return (bool) f3b_forma_de( 'home' );
}

/**
 * É a página inicial?
 *
 * @return bool
 */
function is_front_page(): bool {
	return (bool) f3b_forma_de( 'front' );
}

/**
 * É arquivo de qualquer tipo?
 *
 * @return bool
 */
function is_archive(): bool {
	return (bool) f3b_forma_de( 'tax' );
}

/**
 * É feed?
 *
 * @return bool
 */
function is_feed(): bool {
	return false;
}

/**
 * É paginação?
 *
 * @return bool
 */
function is_paged(): bool {
	return false;
}

/**
 * O objeto consultado.
 *
 * @return mixed
 */
function get_queried_object() {
	return f3b_forma_de( 'termo' );
}

/**
 * O id do objeto consultado.
 *
 * @return int
 */
function get_queried_object_id(): int {
	return (int) f3b_forma_de( 'id' );
}

/**
 * O usuário está logado?
 *
 * @return bool
 */
function is_user_logged_in(): bool {
	return false;
}

/**
 * É requisição AJAX?
 *
 * @return bool
 */
function wp_doing_ajax(): bool {
	return false;
}

/**
 * Quantas vezes uma ação rodou.
 *
 * @param string $gancho Gancho.
 * @return int
 */
function did_action( string $gancho ): int {
	unset( $gancho );

	return 0;
}

/**
 * É arquivo de autor?
 *
 * @return bool
 */
function is_author(): bool {
	return (bool) f3b_forma_de( 'autor' );
}

/**
 * É arquivo de data?
 *
 * @return bool
 */
function is_date(): bool {
	return (bool) f3b_forma_de( 'data' );
}

/**
 * O objeto de post declarado na bancada.
 *
 * @param mixed $post Id ou objeto.
 * @return WP_Post|null
 */
function is_post_publicly_viewable( $post ): bool { return 'publish' === ( $post->post_status ?? 'publish' ); }
function url_to_postid( string $url ): int {
	foreach ( (array) ( $GLOBALS['f3b_bench']['conteudo'] ?? array() ) as $post ) { if ( get_permalink( $post ) === $url ) { return (int) $post->ID; } }
	return 0;
}

function get_post( $post = 0 ) {
	$id = is_object( $post ) ? (int) $post->ID : (int) $post;

	if ( $id <= 0 ) {
		$id = (int) get_queried_object_id();
	}

	foreach ( (array) ( $GLOBALS['f3b_bench']['conteudo'] ?? array() ) as $declarado ) {
		if ( (int) $declarado->ID === $id ) {
			return $declarado;
		}
	}

	return null;
}

/**
 * É arquivo de tipo de conteúdo?
 *
 * @param mixed $tipo Tipo.
 * @return bool
 */
function is_post_type_archive( $tipo = '' ): bool {
	unset( $tipo );

	return (bool) f3b_forma_de( 'arquivo_de_tipo' );
}

/**
 * Variável da consulta.
 *
 * @param string $chave  Nome.
 * @param mixed  $padrao Valor quando ausente.
 * @return mixed
 */
function get_query_var( string $chave, $padrao = '' ) {
	return $GLOBALS['f3b_bench']['query_vars'][ $chave ] ?? $padrao;
}

/**
 * Option de rede: na bancada de site único é a mesma tabela.
 *
 * @param string $nome   Nome.
 * @param mixed  $padrao Padrão.
 * @return mixed
 */
function get_site_option( string $nome, $padrao = false ) {
	return get_option( $nome, $padrao );
}

/**
 * Grava meta de post.
 *
 * @param int    $id    Identificador.
 * @param string $chave Chave.
 * @param mixed  $valor Valor.
 * @return bool
 */
function update_post_meta( int $id, string $chave, $valor ): bool {
	$GLOBALS['f3b_bench']['metas'][ $id ][ $chave ] = $valor;

	return true;
}

/**
 * Aplica um callback recursivamente.
 *
 * @param mixed    $valor    Valor.
 * @param callable $callback Função.
 * @return mixed
 */
function map_deep( $valor, $callback ) {
	if ( is_array( $valor ) ) {
		foreach ( $valor as $chave => $item ) {
			$valor[ $chave ] = map_deep( $item, $callback );
		}

		return $valor;
	}

	return $callback( $valor );
}

/**
 * Um plugin está ativo? A bancada declara a lista.
 *
 * @param string $arquivo Caminho relativo do plugin.
 * @return bool
 */
function is_plugin_active( string $arquivo ): bool {
	return in_array( $arquivo, (array) ( $GLOBALS['f3b_bench']['plugins_ativos'] ?? array() ), true );
}

/**
 * Caminho relativo de um arquivo de plugin.
 *
 * @param string $arquivo Caminho absoluto.
 * @return string
 */
function plugin_basename( string $arquivo ): string {
	return basename( dirname( $arquivo ) ) . '/' . basename( $arquivo );
}

/**
 * URL do diretório de um plugin.
 *
 * @param string $arquivo Caminho do arquivo principal.
 * @return string
 */
function plugin_dir_url( string $arquivo ): string {
	return home_url( '/' ) . 'wp-content/plugins/' . basename( dirname( $arquivo ) ) . '/';
}

/**
 * Desagenda todas as ocorrências de um gancho.
 *
 * @param string $hook Gancho.
 * @return int
 */
function wp_unschedule_hook( string $hook ): int {
	$antes = count( $GLOBALS['f3b_bench']['agendados'] ?? array() );

	unset( $GLOBALS['f3b_bench']['agendados'][ $hook ] );

	return $antes - count( $GLOBALS['f3b_bench']['agendados'] ?? array() );
}

/**
 * Uma URL de destino é aceitável?
 *
 * @param string $url      Destino.
 * @param string $reserva  Alternativa.
 * @return string
 */
function wp_validate_redirect( string $url, string $reserva = '' ): string {
	$host = (string) ( wp_parse_url( $url, PHP_URL_HOST ) ?: '' );

	if ( '' === $host || $host === (string) ( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ?: '' ) ) {
		return $url;
	}

	return $reserva;
}

/**
 * Registra o redirecionamento em vez de emiti-lo.
 *
 * @param string $url    Destino.
 * @param int    $status Código.
 * @return bool
 */
function wp_safe_redirect( string $url, int $status = 302 ): bool {
	$GLOBALS['f3b_bench']['redirecionamento'] = array( 'url' => $url, 'status' => $status );

	return true;
}

/**
 * Redirecionamento do núcleo por slug antigo: na bancada não redireciona.
 *
 * @return void
 */
function wp_old_slug_redirect(): void {}

/**
 * Blocos de um conteúdo, na forma que o núcleo devolve.
 *
 * Um parser de verdade, e não uma lista pronta: o módulo de schema desce pelos
 * blocos internos atrás dos `core/details`, e uma lista pronta responderia a
 * pergunta que a bancada quer fazer sem que o código do módulo a respondesse.
 *
 * @param string $conteudo Conteúdo do post.
 * @return array<int,array<string,mixed>>
 */
function parse_blocks( string $conteudo ): array {
	$posicao = 0;

	return f3b_blocos( $conteudo, $posicao, '' );
}

/**
 * Passo recursivo de `parse_blocks()`.
 *
 * @param string $conteudo Conteúdo.
 * @param int    $posicao  Cursor, por referência.
 * @param string $ate      Nome do bloco cujo fechamento encerra este nível.
 * @return array<int,array<string,mixed>>
 */
function f3b_blocos( string $conteudo, int &$posicao, string $ate ): array {
	$blocos = array();

	while ( $posicao < strlen( $conteudo ) ) {
		if ( ! preg_match( '/<!--\s+(\/?)wp:([a-z0-9\/-]+)\s*(\{.*?\})?\s*(\/)?-->/s', $conteudo, $marca, PREG_OFFSET_CAPTURE, $posicao ) ) {
			break;
		}

		$inicio  = (int) $marca[0][1];
		$fim     = $inicio + strlen( $marca[0][0] );
		$fechada = '' !== $marca[1][0];
		$bloco   = (string) $marca[2][0];
		$attrs   = isset( $marca[3][0] ) && '' !== $marca[3][0] ? (array) json_decode( (string) $marca[3][0], true ) : array();
		$vazia   = isset( $marca[4][0] ) && '/' === $marca[4][0];

		if ( $fechada ) {
			$posicao = $fim;

			if ( $bloco === $ate ) {
				return $blocos;
			}

			continue;
		}

		if ( $vazia ) {
			$posicao  = $fim;
			$blocos[] = array(
				'blockName'    => $bloco,
				'attrs'        => $attrs,
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			);

			continue;
		}

		$posicao = $fim;
		$corpo   = $posicao;
		$dentro  = f3b_blocos( $conteudo, $posicao, $bloco );
		$html    = substr( $conteudo, $corpo, max( 0, $posicao - $corpo ) );

		$blocos[] = array(
			'blockName'    => $bloco,
			'attrs'        => $attrs,
			'innerBlocks'  => $dentro,
			'innerHTML'    => (string) preg_replace( '/<!--\s+\/?wp:.*?-->/s', '', $html ),
			'innerContent' => array( (string) preg_replace( '/<!--\s+\/?wp:.*?-->/s', '', $html ) ),
		);
	}

	return $blocos;
}

/*
 * A CONFIGURAÇÃO DA BANCADA VEM DO ANDAIME, e o que mudou ao sair do
 * implantador é a ORIGEM dos valores, não os valores. Lá esta bancada carregava
 * `includes/class-f3base-imp-{config,decisoes,projeto}.php` e lia
 * `config/{site.json,projeto.json,decisoes.tsv}` — arquivos do implantador, que
 * neste repositório não existem. Aqui ela lê o RETRATO daqueles mesmos valores,
 * em `suite/fixtures/config/site-core.json`, por um leitor só
 * (`F3Base_Andaime_Config`) que ABORTA na chave ausente em vez de devolver
 * padrão. `modulos.nascem_ativos` continua medindo o site COM OS VALORES
 * ENTREGUES, que é a única coisa que ela sempre mediu.
 */

/*
 * Os arquivos do plugin, lidos da lista que o PRÓPRIO plugin declara.
 *
 * A bancada mantinha aqui uma lista escrita à mão, e ela tinha envelhecido: o
 * registro declara 16 módulos, a bancada carregava 13, e `F3Base_Registro`
 * descarta em silêncio a classe que não existe (`class_exists`). Resultado: três
 * módulos nunca foram exercitados aqui, e ninguém tinha como perceber, porque a
 * lista curta não acusa o que falta. Lendo a lista do plugin, módulo novo entra
 * na bancada sozinho — que é a mesma razão pela qual `F3Base_Registro` existe.
 */
$lista_do_plugin = (string) file_get_contents( $raiz . '/fontes/plugin/base-site-core-fator3.php' );
$arquivos_do_plugin = array();

if ( preg_match( '/\$arquivos\s*=\s*array\((.*?)\);/s', $lista_do_plugin, $bloco_arquivos ) ) {
	if ( preg_match_all( "/'([^']+\\.php)'/", $bloco_arquivos[1], $achados_arquivos ) ) {
		$arquivos_do_plugin = $achados_arquivos[1];
	}
}

if ( count( $arquivos_do_plugin ) < 20 ) {
	fwrite( STDERR, "bancada: não consegui ler a lista de arquivos de base-site-core-fator3.php\n" );
	exit( 1 );
}

/*
 * UMA ORIGEM SÓ, e é a diferença deste repositório. No implantador, cinco
 * arquivos desta lista não moravam na fonte do plugin: eram CONTRATO
 * COMPARTILHADO, moravam em `partilhado/` e o empacotamento os copiava para
 * dentro do zip no mesmo caminho relativo — a bancada refazia essa resolução
 * para carregar o plugin como ele ficaria montado. Aqui a fonte do plugin JÁ É
 * o que fica montado: os cinco moram em `fontes/plugin/`, no mesmo caminho
 * relativo de sempre. Quem prova que o zip saiu completo continua sendo
 * `pacote.plugin_completo_no_zip`, contra o zip de verdade.
 */
foreach ( $arquivos_do_plugin as $relativo_do_plugin ) {
	require_once $raiz . '/fontes/plugin/' . $relativo_do_plugin;
}

/* ---------------------------------------------------------------------------
 * Registro dos achados
 * ------------------------------------------------------------------------ */

$resultado = array();

/**
 * Registra um achado.
 *
 * @param string $checagem Checagem.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]              = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Conta uma unidade medida.
 *
 * @param string $checagem Checagem.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Afirma, contando a medida.
 *
 * @param string $checagem Checagem.
 * @param bool   $condicao Condição medida.
 * @param string $falha    Texto do achado quando a condição não vale.
 * @return void
 */
function afirmar( string $checagem, bool $condicao, string $falha ): void {
	medir( $checagem );

	if ( ! $condicao ) {
		anotar( $checagem, $falha );
	}
}

/**
 * Zera a bancada entre cenários.
 *
 * @return void
 */
function bancada_limpa(): void {
	global $wpdb;

	$GLOBALS['f3b_bench']['options']     = array();
	$GLOBALS['f3b_bench']['autoload']    = array();
	$GLOBALS['f3b_bench']['transientes'] = array();
	$GLOBALS['f3b_bench']['congelados']  = null;
	$GLOBALS['f3b_bench']['posts']       = 0;
	$GLOBALS['f3b_bench']['ultimo_post']  = array();
	$GLOBALS['f3b_bench']['post_types']   = array();
	$GLOBALS['f3b_bench']['posts_por_tipo'] = array();
	$GLOBALS['f3b_bench']['insert_ok']   = true;
	$GLOBALS['f3b_bench']['insert_id_cego'] = false;
	$GLOBALS['f3b_bench']['rotas']       = array();
	$GLOBALS['f3b_bench']['servidor']    = array( 'REMOTE_ADDR' => '203.0.113.7' );
	$GLOBALS['f3b_bench']['scripts']     = array();
	$GLOBALS['f3b_bench']['ssl']         = false;
	$GLOBALS['f3b_bench']['suportes_do_tema'] = array( 'f3base-consentimento-rodape' );
	$GLOBALS['f3b_bench']['paginas']     = array();
	$GLOBALS['f3b_bench']['agendados']   = array();
	$GLOBALS['f3b_bench']['agendamento_recusado'] = false;
	$GLOBALS['f3b_bench']['http']        = array(
		'resposta'   => array(
			'codigo' => 200,
			'corpo'  => '{"events_received":1,"fbtrace_id":"A0-bancada"}',
			'erro'   => '',
		),
		'requisicao' => array(),
		'chamadas'   => 0,
	);

	$wpdb->tabelas   = array();
	$wpdb->fita      = array();
	$wpdb->insert_id = 0;

	requisicao_nova();
	F3Base_Modulo_Endpoint_Leads::criar_tabela();
}

/**
 * Simula uma REQUISIÇÃO NOVA, zerando os memos de requisição.
 *
 * Os memos existem para não repetir trabalho DENTRO de uma requisição — o
 * registro de módulos e a prontidão da tabela. Numa bancada que encadeia vários
 * cenários no mesmo processo eles atravessariam a fronteira que no site real não
 * existe, e o cenário seguinte mediria o estado do anterior.
 *
 * @return void
 */
function requisicao_nova(): void {
	/*
	 * OS MEMOS SÃO VARRIDOS, e não nomeados um a um. A lista escrita à mão
	 * tinha dois nomes e o plugin já tinha três: `eventos_prontos` nasceu na
	 * 1.2.0 e ninguém a acrescentou aqui, então a bancada carregava para o
	 * cenário seguinte a resposta de que a tabela de registro estava pronta —
	 * e um cenário que a apagasse continuaria achando que ela existia. É a
	 * mesma classe de defeito que esta release inteira trata: estrutura nova
	 * que ninguém lembrou de acrescentar numa lista.
	 *
	 * A convenção do pacote é clara o bastante para virar regra: memo de
	 * requisição é propriedade ESTÁTICA e ANULÁVEL. Zerar todas elas nas
	 * classes do registro cobre a próxima sem que ninguém precise lembrar.
	 */
	$classes = array_merge( array( 'F3Base_Registro' ), F3Base_Registro::classes() );

	foreach ( $classes as $classe ) {
		if ( ! class_exists( (string) $classe ) ) {
			continue;
		}

		foreach ( ( new ReflectionClass( (string) $classe ) )->getProperties( ReflectionProperty::IS_STATIC ) as $propriedade ) {
			$tipo = $propriedade->getType();

			if ( ! $tipo instanceof ReflectionNamedType || ! $tipo->allowsNull() ) {
				continue;
			}

			$propriedade->setAccessible( true );
			$propriedade->setValue( null, null );
		}
	}
}

/**
 * Quantos ouvintes de um hook pertencem a uma CLASSE de módulo.
 *
 * `has_action()` conta todo mundo, e nesta bancada há mais de um módulo ativo
 * enfileirando script. A pergunta que a regra do CTA faz é outra — "o filtro
 * DESTE módulo está registrado?" —, e responder com a contagem geral seria medir
 * o hook do vizinho.
 *
 * @param string $hook   Nome do hook.
 * @param string $classe Nome da classe do módulo.
 * @return int
 */
function ouvintes_da_classe( string $hook, string $classe ): int {
	$conta = 0;

	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		$callback = $registro['callback'];

		if ( is_array( $callback ) && isset( $callback[0] ) && is_object( $callback[0] ) && $callback[0] instanceof $classe ) {
			++$conta;
		}
	}

	return $conta;
}

/**
 * Linhas da tabela de chaves com um tipo, e opcionalmente um estado.
 *
 * @param string $tipo   Tipo da linha.
 * @param string $estado Estado da reserva; vazio aceita qualquer um.
 * @return int
 */
function linhas_do_tipo( string $tipo, string $estado = '' ): int {
	global $wpdb;

	$tabela = F3Base_Modulo_Endpoint_Leads::nome_tabela();
	$conta  = 0;

	foreach ( $wpdb->tabelas[ $tabela ]['linhas'] ?? array() as $linha ) {
		if ( (string) $linha['tipo'] !== $tipo ) {
			continue;
		}

		if ( '' !== $estado && (string) $linha['estado'] !== $estado ) {
			continue;
		}

		++$conta;
	}

	return $conta;
}

/**
 * Payload mínimo aceito pelo endpoint.
 *
 * @param array<string,mixed> $extra Campos a acrescentar ou trocar.
 * @return array<string,mixed>
 */
function carga( array $extra = array() ): array {
	$corpo = array_merge(
		array( 'correlation_id' => 'correlacao-de-bancada-1' ),
		$extra
	);

	/*
	 * O TOKEN NASCE COM O ESCOPO DA PÁGINA DESTE PAYLOAD. A assinatura passou a
	 * cobrir a rota e o caminho da página em que o token foi impresso — antes
	 * ela cobria só a expiração, e um token colhido em qualquer página valia
	 * para qualquer POST. A bancada emite pela mesma função que o servidor usa
	 * no enfileiramento, e o caso que manda um token EXPLÍCITO continua mandando
	 * o dele: é assim que os pisos do token inválido continuam de pé.
	 */
	if ( ! array_key_exists( 'token', $corpo ) ) {
		$corpo['token'] = F3Base_Modulo_Endpoint_Leads::emitir_token(
			F3Base_Modulo_Endpoint_Leads::caminho_interno( isset( $corpo['pagina'] ) && is_scalar( $corpo['pagina'] ) ? (string) $corpo['pagina'] : '' )
		);
	}

	return $corpo;
}

/**
 * Exercita o endpoint com um corpo JSON.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Endpoint_Leads();

	return $modulo->receber( new WP_REST_Request( $corpo, null ) );
}

/**
 * Exercita o endpoint com um corpo de formulário — onde tudo chega string.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar_form( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Endpoint_Leads();

	return $modulo->receber( new WP_REST_Request( null, $corpo ) );
}

bancada_limpa();

/* ==========================================================================
 * leads.limite_por_caractere
 * ======================================================================= */

$nome = 'leads.limite_por_caractere';

$limites = F3Base_Modulo_Endpoint_Leads::limites_publicos();
$max     = (int) $limites['nome'];

/* PISO: a bancada reproduz o defeito? O texto acentuado no limite EXCEDE em bytes. */
$acentuado = str_repeat( 'ção', (int) floor( $max / 3 ) );
$acentuado .= str_repeat( 'á', $max - mb_strlen( $acentuado, 'UTF-8' ) );

afirmar(
	$nome,
	mb_strlen( $acentuado, 'UTF-8' ) === $max,
	'piso: a bancada não conseguiu montar um nome com exatamente ' . $max . ' caracteres acentuados, e sem ele o defeito não é reproduzido'
);

afirmar(
	$nome,
	strlen( $acentuado ) > $max,
	'piso: o texto acentuado no limite NÃO excede o limite em bytes — a bancada não está reproduzindo o defeito de unidade da 1.0.17, e o teto abaixo aprovaria por acaso'
);

/* TETO: o mesmo texto é aceito, porque a unidade agora é a que o cliente corta. */
$resposta = postar( carga( array( 'nome' => $acentuado ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: nome com ' . $max . ' caracteres acentuados foi recusado com status ' . $resposta->status . ' e código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — o navegador aprovou e o servidor recusou, que é o lead perdido em português'
);

/* PISO da regra: um caractere ACIMA do limite continua sendo recusado. */
bancada_limpa();
$resposta = postar( carga( array( 'nome' => $acentuado . 'ç' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_limite_excedido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso: um caractere acima do limite passou — a regra deixou de recusar, e "recusado, nunca truncado em silêncio" virou letra morta'
);

afirmar(
	$nome,
	'caracteres' === (string) ( $resposta->data['unidade'] ?? '' ),
	'a recusa não NOMEIA a unidade medida: o cliente precisa saber em que unidade o limite foi contado para cortar na mesma'
);

/* A unidade também vale dentro de atribuicao, que repetia a mesma medida. */
bancada_limpa();
$referrer = 'https://exemplo.test/' . str_repeat( 'é', 500 );
$resposta = postar( carga( array( 'atribuicao' => array( 'fonte' => str_repeat( 'ã', 120 ) ) ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto de atribuicao: 120 caracteres acentuados em atribuicao.fonte foram recusados com status ' . $resposta->status . ' — a segunda medida em bytes continuou de pé'
);

bancada_limpa();
$resposta = postar( carga( array( 'atribuicao' => array( 'fonte' => str_repeat( 'ã', 121 ) ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'atribuicao.fonte' === (string) ( $resposta->data['campo'] ?? '' ),
	'piso de atribuicao: 121 caracteres passaram, ou a recusa não nomeou a chave'
);

/* Um limite por campo, e ele é o do schema: `pagina` no limite chega inteira. */
bancada_limpa();

$caminho  = '/contato/?origem=' . str_repeat( 'ã', 100 );
$resposta = postar( carga( array( 'pagina' => 'https://exemplo.test' . $caminho ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto de pagina: uma URL interna com acentuação dentro do limite foi recusada com status ' . $resposta->status
);

$meta = $GLOBALS['f3b_bench']['ultimo_post']['meta_input'] ?? array();
$corpo_do_post = (string) ( $GLOBALS['f3b_bench']['ultimo_post']['post_content'] ?? '' );

afirmar(
	$nome,
	str_contains( $corpo_do_post, $caminho ),
	'a URL interna acentuada foi CORTADA na normalização: um segundo limite, em outra unidade, é uma segunda fonte para o mesmo fato'
);

/* ==========================================================================
 * leads.email_conclusivo
 * ======================================================================= */

$nome = 'leads.email_conclusivo';

/* PISO: a bancada reproduz o defeito? sanitize_email() devolve VAZIO, não erro. */
afirmar(
	$nome,
	'' === sanitize_email( 'joao arroba exemplo' ),
	'piso: a bancada não reproduz o retorno vazio de sanitize_email() para entrada inválida, e sem ele o teto aprovaria por acaso'
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => 'joao arroba exemplo' ) ) );

afirmar(
	$nome,
	400 === $resposta->status,
	'piso: e-mail inválido foi ACEITO com status ' . $resposta->status . ' — o lead entra sem endereço nenhum e a resposta diz que deu certo'
);

afirmar(
	$nome,
	'email' === (string) ( $resposta->data['campo'] ?? '' ),
	'a recusa do e-mail inválido não nomeia o campo'
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => 'pessoa@exemplo.test' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: e-mail válido foi recusado com status ' . $resposta->status
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => '' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto do falso positivo: e-mail VAZIO é campo opcional ausente, não e-mail inválido, e foi recusado com status ' . $resposta->status
);

/* ==========================================================================
 * leads.booleano_explicito
 * ======================================================================= */

$nome = 'leads.booleano_explicito';

/* PISO: a bancada reproduz o defeito? O molde da linguagem faz "false" valer true. */
afirmar(
	$nome,
	true === (bool) 'false',
	'piso: nesta versão de PHP (bool) "false" não é true, e o defeito medido não é reproduzível aqui'
);

afirmar(
	$nome,
	false === (bool) '0',
	'piso: a assimetria entre "0" e "false" não é reproduzível aqui'
);

$tabela_booleana = array(
	array( 'false', false, 'a string "false" precisa valer FALSO, e era ela que arquivava consentimento inexistente' ),
	array( '0', false, 'a string "0"' ),
	array( '', false, 'a string vazia' ),
	array( 'no', false, 'a string "no"' ),
	array( 'nao', false, 'a string "nao"' ),
	array( 'off', false, 'a string "off"' ),
	array( '1', true, 'a string "1"' ),
	array( 'true', true, 'a string "true"' ),
	array( 'sim', true, 'a string "sim"' ),
	array( 'on', true, 'a string "on"' ),
);

foreach ( $tabela_booleana as $caso ) {
	bancada_limpa();
	$resposta = postar_form( carga( array( 'consentimento' => $caso[0] ) ) );

	afirmar(
		$nome,
		201 === $resposta->status,
		'valor booleano "' . $caso[0] . '" foi recusado com status ' . $resposta->status
	);

	$gravado = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

	afirmar(
		$nome,
		array() !== $gravado,
		'valor booleano "' . $caso[0] . '" não chegou a gravar lead nenhum'
	);

	/*
	 * O VALOR QUE FOI ARQUIVADO, e não só o status da resposta: é o meta
	 * `_f3base_consentimento` que o Flamingo e o CPT guardam, e era ele que
	 * dizia "sim" para quem tinha mandado a string "false".
	 */
	$meta = $GLOBALS['f3b_bench']['ultimo_post']['meta_input'] ?? array();

	/*
	 * O ESPERADO MUDOU COM O VOCABULÁRIO FECHADO, e a mudança é o assunto do
	 * defeito irmão deste: `true` do cliente NÃO é `sim`. Nesta bancada não há
	 * cookie de decisão e a política é a pré-aprovada, então o valor verdadeiro
	 * arquiva `padrao-pre-aprovado` — ausência de decisão, dita pelo nome. O
	 * valor FALSO continua arquivando `nao`, e é ele que este caso existe para
	 * proteger: era a string "false" virando consentimento que motivou o parser.
	 */
	$esperado_do_estado = $caso[1]
		? F3Base_Modulo_Consentimento::ESTADO_PADRAO
		: F3Base_Modulo_Consentimento::ESTADO_NAO;

	afirmar(
		$nome,
		$esperado_do_estado === (string) ( $meta['_f3base_consentimento'] ?? '' ),
		'o valor "' . $caso[0] . '" foi ARQUIVADO como consentimento "' . (string) ( $meta['_f3base_consentimento'] ?? '' ) . '" em vez de "' . $esperado_do_estado . '": ' . $caso[2]
	);
}

/* O valor lido é conferido no meta, que é o que o Flamingo arquiva como consentimento. */
foreach ( $tabela_booleana as $caso ) {
	medir( $nome );

	$lido = F3Base_Modulo_Endpoint_Leads::interpretar_booleano( $caso[0] );

	if ( $caso[1] !== $lido ) {
		anotar( $nome, $caso[2] . ' foi interpretada como ' . var_export( $lido, true ) . ' e devia ser ' . var_export( $caso[1], true ) );
	}
}

/* Estrutura no lugar de escalar: a guarda que o `continue` do booleano pulava. */
bancada_limpa();
$resposta = postar( carga( array( 'consentimento' => array() ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_tipo_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso da estrutura: {"consentimento":{}} devolveu status ' . $resposta->status . ' com código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — array vazio virando consentimento verdadeiro é o defeito que o ramo próprio do booleano escondia'
);

bancada_limpa();
$resposta = postar( carga( array( 'consentimento' => (object) array( 'a' => 1 ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_tipo_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso da estrutura: objeto em consentimento devolveu status ' . $resposta->status
);

/* O limite de 8 do schema deixou de ser letra morta. */
bancada_limpa();
$resposta = postar_form( carga( array( 'consentimento' => 'verdadeiro-demais' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_limite_excedido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso do limite: valor de 17 caracteres no campo booleano de max 8 devolveu status ' . $resposta->status . ' com código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — o ramo próprio do booleano pulava a checagem de limite e o max era letra morta'
);

/* Vocabulário fechado: valor que ninguém sabe ler é recusado, nunca adivinhado. */
bancada_limpa();
$resposta = postar_form( carga( array( 'consentimento' => 'talvez' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_valor_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso do vocabulário: "talvez" foi aceito com status ' . $resposta->status . ' — consentimento adivinhado é consentimento inventado'
);

/* ==========================================================================
 * leads.reserva_compensada
 * ======================================================================= */

$nome = 'leads.reserva_compensada';

bancada_limpa();

$tabela = F3Base_Modulo_Endpoint_Leads::nome_tabela();

/* PISO: a bancada reproduz a reserva? A primeira tentativa DEIXA a linha lá. */
$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	503 === $resposta->status,
	'a gravação recusada devolveu status ' . $resposta->status . ', e não 5xx — 201 Created com ok:false diz que o recurso existe'
);

afirmar(
	$nome,
	0 === linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP ),
	'piso: a reserva SOBREVIVEU à falha de gravação (' . linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP ) . ' linha(s) de deduplicação na tabela). É exatamente ela que, na 1.0.17, bloqueava por 30 dias o visitante que tentasse de novo'
);

/* TETO: a tentativa seguinte com o MESMO correlation_id é ACEITA. */
$GLOBALS['f3b_bench']['insert_ok'] = true;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	201 === $resposta->status && true === ( $resposta->data['registrado'] ?? false ),
	'teto: depois de uma falha de armazenamento, a segunda tentativa com o mesmo correlation_id devolveu status ' . $resposta->status . ' e registrado=' . var_export( $resposta->data['registrado'] ?? null, true ) . ' — ela precisa ser ACEITA'
);

/* PISO da deduplicação: com a gravação BEM-SUCEDIDA, o replay continua recusado. */
$resposta = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	200 === $resposta->status && true === ( $resposta->data['duplicado'] ?? false ),
	'piso da deduplicação: o replay de uma correlação JÁ GRAVADA passou — a compensação não pode ter apagado a reserva firme'
);

/* Exatamente uma reserva FIRME, e o balde do rate limit não se confunde com ela. */
$firmes = linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME );

afirmar(
	$nome,
	1 === $firmes,
	'a tabela ficou com ' . $firmes . ' reserva(s) firme(s) depois de uma gravação aceita; esperava exatamente uma'
);

afirmar(
	$nome,
	linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_LIMITE ) > 0 && 0 === linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_LIMITE, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME ),
	'a linha do balde do rate limit está gravada com estado de RESERVA: balde não é reserva, e misturá-los faz qualquer contagem por estado mentir'
);

/* Reserva PENDENTE abandonada é retomada, e uma vez só. */
bancada_limpa();

$chave = F3Base_Modulo_Endpoint_Leads::chave_de_dedup( 'correlacao-abandonada' );

$wpdb->tabelas[ $tabela ]['linhas'][ $chave ] = array(
	'chave'     => $chave,
	'tipo'      => F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP,
	'estado'    => F3Base_Modulo_Endpoint_Leads::RESERVA_PENDENTE,
	'record_id' => 'registro-abandonado',
	'contador'  => 0,
	'expira_em' => time() + 100000,
	'criado_em' => time() - ( F3Base_Modulo_Endpoint_Leads::ttl_reserva_pendente() + 60 ),
);

$retomada = F3Base_Modulo_Endpoint_Leads::reservar( 'correlacao-abandonada', 'registro-novo' );

afirmar(
	$nome,
	true === $retomada['novo'] && 'registro-novo' === $retomada['record_id'],
	'a reserva pendente abandonada não foi retomada: uma requisição interrompida entre a reserva e a gravação bloquearia a correlação até o fim do TTL'
);

$segunda = F3Base_Modulo_Endpoint_Leads::reservar( 'correlacao-abandonada', 'registro-terceiro' );

afirmar(
	$nome,
	false === $segunda['novo'],
	'piso da retomada: a reserva recém-retomada foi retomada DE NOVO — o UPDATE precisa casar o carimbo lido para que dois pedidos concorrentes produzam uma retomada só'
);

/* A contingência por transiente tem a mesma compensação. */
bancada_limpa();
$wpdb->tabelas = array();

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::tabela_pronta(),
	'piso da contingência: sem tabela, tabela_pronta() continuou dizendo que está pronta'
);

$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	503 === $resposta->status,
	'contingência: a gravação recusada devolveu status ' . $resposta->status
);

$GLOBALS['f3b_bench']['insert_ok'] = true;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'contingência: a segunda tentativa depois da falha devolveu status ' . $resposta->status . ' — o caminho de transiente tinha o MESMO defeito e precisa da mesma compensação'
);

$resposta = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	200 === $resposta->status && true === ( $resposta->data['duplicado'] ?? false ),
	'contingência: o replay de correlação já gravada passou'
);

/* ==========================================================================
 * leads.atividade_so_com_persistencia
 * ======================================================================= */

$nome = 'leads.atividade_so_com_persistencia';

bancada_limpa();

$GLOBALS['f3b_bench']['insert_ok'] = false;
postar( carga( array( 'correlation_id' => 'correlacao-sem-persistencia' ) ) );

$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );
$falha  = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );

afirmar(
	$nome,
	array() === $aceito,
	'piso: a atividade "último registro aceito" foi carimbada mesmo sem persistência — a tela do site-core passa a apontar para onde nada foi escrito'
);

afirmar(
	$nome,
	array() !== $falha && '' !== (string) ( $falha['destino'] ?? '' ),
	'a recusa não deixou carimbo próprio: o ramo adverso não pode simplesmente sumir da tela'
);

afirmar(
	$nome,
	str_contains( (string) ( $falha['motivo'] ?? '' ), F3Base_Modulo_Endpoint_Leads::CPT ),
	'o carimbo da recusa não NOMEIA os destinos que recusaram'
);

/* TETO: com persistência, o carimbo sai e aponta para o destino real. */
$GLOBALS['f3b_bench']['insert_ok'] = true;
postar( carga( array( 'correlation_id' => 'correlacao-com-persistencia' ) ) );

$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::CPT === (string) ( $aceito['destino'] ?? '' ),
	'teto: a gravação aceita não carimbou o destino real'
);

/* O estado do módulo reflete a recusa mais recente, em vez de calar. */
bancada_limpa();
$GLOBALS['f3b_bench']['insert_ok'] = false;
postar( carga( array( 'correlation_id' => 'correlacao-degradada' ) ) );

$estado = ( new F3Base_Modulo_Endpoint_Leads() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" com a última tentativa recusada: gravação que não aconteceu não pode sair verde na tela'
);

/* ==========================================================================
 * leads.status_da_gravacao
 * ======================================================================= */

$nome = 'leads.status_da_gravacao';

bancada_limpa();

$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-do-status' ) ) );

/* PISO: 201 Created com ok:false diz que o recurso existe. Não pode voltar. */
afirmar(
	$nome,
	201 !== $resposta->status,
	'piso: nenhum destino aceitou o lead e a resposta saiu 201 Created — o cliente é informado de que o recurso foi criado quando nada foi escrito'
);

afirmar(
	$nome,
	$resposta->status >= 500 && $resposta->status < 600,
	'a gravação indisponível saiu com status ' . $resposta->status . ', e falha de armazenamento do servidor é 5xx'
);

afirmar(
	$nome,
	false === ( $resposta->data['ok'] ?? true ) && false === ( $resposta->data['registrado'] ?? true ),
	'a resposta da gravação recusada não diz ok=false e registrado=false'
);

afirmar(
	$nome,
	'' !== (string) ( $resposta->data['codigo'] ?? '' ),
	'a resposta da gravação recusada não traz código: erro sem código é erro que o cliente não sabe distinguir'
);

foreach ( array( 'reenviar', 'WhatsApp' ) as $instrucao ) {
	afirmar(
		$nome,
		str_contains( (string) ( $resposta->data['motivo'] ?? '' ), $instrucao ),
		'a resposta da gravação recusada não diz ao visitante o que fazer: falta "' . $instrucao . '" no motivo'
	);
}

/* TETO: a gravação aceita responde 201 com registrado verdadeiro. */
bancada_limpa();
$resposta = postar( carga( array( 'correlation_id' => 'correlacao-do-status-ok' ) ) );

afirmar(
	$nome,
	201 === $resposta->status && true === ( $resposta->data['registrado'] ?? false ),
	'teto: a gravação aceita saiu com status ' . $resposta->status . ' e registrado=' . var_export( $resposta->data['registrado'] ?? null, true )
);

afirmar(
	$nome,
	'' !== (string) ( $resposta->data['record_id'] ?? '' ),
	'a gravação aceita não devolveu o record_id nascido no servidor'
);

/* ==========================================================================
 * leads.rate_limit_atomico
 * ======================================================================= */

$nome = 'leads.rate_limit_atomico';

bancada_limpa();

$chave_limite = hash( 'sha256', 'limite-de-bancada' );

/*
 * PISO: a bancada reproduz o defeito? Com os transientes CONGELADOS — que é o
 * que duas requisições concorrentes enxergam —, o caminho de ler-modificar-
 * gravar precisa PERDER o incremento.
 */
$GLOBALS['f3b_bench']['congelados'] = $GLOBALS['f3b_bench']['transientes'];

$perdido_a = F3Base_Modulo_Endpoint_Leads::incrementar_por_transiente( $chave_limite, 600 );
$perdido_b = F3Base_Modulo_Endpoint_Leads::incrementar_por_transiente( $chave_limite, 600 );

afirmar(
	$nome,
	1 === $perdido_a && 1 === $perdido_b,
	'piso: sob leitura congelada o caminho de transiente devolveu ' . $perdido_a . ' e ' . $perdido_b . ' — a bancada não está reproduzindo a perda de incremento, e o teto abaixo aprovaria por acaso'
);

/* TETO: o incremento no banco não perde nada sob a MESMA leitura congelada. */
$atomico = array();

for ( $i = 0; $i < 5; $i++ ) {
	$atomico[] = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_limite, 600 );
}

$GLOBALS['f3b_bench']['congelados'] = null;

afirmar(
	$nome,
	array( 1, 2, 3, 4, 5 ) === $atomico,
	'teto: cinco incrementos concorrentes devolveram ' . implode( ',', $atomico ) . ' — quem soma tem de ser o banco, numa instrução só, senão N requisições leem o mesmo valor e o balde deixa de segurar'
);

/* Uma instrução por incremento: o balde não tem leitura separada da escrita. */
$instrucoes = 0;

foreach ( $wpdb->fita as $linha ) {
	if ( str_contains( $linha, 'ON DUPLICATE KEY UPDATE' ) ) {
		++$instrucoes;
	}
}

afirmar(
	$nome,
	5 === $instrucoes,
	'os cinco incrementos gastaram ' . $instrucoes . ' instrução(ões) de soma no banco: o incremento tem de ser UMA instrução, sem SELECT antes'
);

/*
 * PISO do driver cego: sem LAST_INSERT_ID() o incremento JÁ aconteceu, e devolver
 * 1 daria um balde que nunca fecha — limite que nunca fecha é pior que limite
 * nenhum, porque parece que existe.
 */
bancada_limpa();
$chave_cega = hash( 'sha256', 'limite-com-driver-cego' );

F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_cega, 600 );
$GLOBALS['f3b_bench']['insert_id_cego'] = true;

$cegos = array();

for ( $i = 0; $i < 3; $i++ ) {
	$cegos[] = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_cega, 600 );
}

$GLOBALS['f3b_bench']['insert_id_cego'] = false;

afirmar(
	$nome,
	array( 2, 3, 4 ) === $cegos,
	'piso do driver cego: sem LAST_INSERT_ID() a contagem devolveu ' . implode( ',', $cegos ) . ' — devolver 1 aqui é um balde que nunca fecha'
);

/* A janela expirada zera o balde, em vez de somar para sempre. */
bancada_limpa();
$chave_curta = hash( 'sha256', 'limite-de-janela-curta' );

F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_curta, 1 );
$linha_curta = $wpdb->tabelas[ $tabela ]['linhas'][ $chave_curta ];
$wpdb->tabelas[ $tabela ]['linhas'][ $chave_curta ]['expira_em'] = time() - 10;

$depois = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_curta, 600 );

afirmar(
	$nome,
	1 === $depois,
	'a janela vencida devolveu ' . $depois . ' em vez de reiniciar o balde em 1'
);

/* ==========================================================================
 * leads.origem_declarada
 * ======================================================================= */

$nome = 'leads.origem_declarada';

bancada_limpa();

/*
 * A cadeia que UM proxy confiável produz: ele acrescenta o IP de quem falou com
 * ele, e o visitante que não mandou nada deixa a lista com um elemento só.
 */
$servidor_com_proxy = array(
	'REMOTE_ADDR'          => '198.51.100.10',
	'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
);

/* PISO: sem declaração, o cabeçalho é IGNORADO. */
$origem = F3Base_Modulo_Endpoint_Leads::origem( $servidor_com_proxy );

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'piso: sem cabeçalho declarado a origem saiu ' . $origem['valor'] . ' por ' . $origem['fonte'] . ' — cabeçalho de proxy aceito sem declaração é o visitante escolhendo o balde em que conta'
);

/* TETO: declarado, o cabeçalho é lido descontando os saltos confiáveis. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho'        => 'X-Forwarded-For',
		'saltos'           => 1,
		/*
		 * A FAIXA DO PROXY entrou na declaração porque é ela que LIGA a conferência
		 * da conexão — sem faixa o cabeçalho é lido de qualquer lugar, e esta
		 * seção mede a leitura sob a proteção ligada. O REMOTE_ADDR de toda ela é
		 * 198.51.100.10, que está dentro da faixa declarada aqui.
		 */
		'redes_confiaveis' => array( '198.51.100.0/24' ),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$origem = F3Base_Modulo_Endpoint_Leads::origem( $servidor_com_proxy );

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'] && 'cabecalho-declarado' === $origem['fonte'],
	'teto: com o cabeçalho declarado a origem saiu ' . $origem['valor'] . ' por ' . $origem['fonte'] . ', e devia ser o IP do visitante'
);

/* PISO do spoofing: o visitante empurra um valor a mais e não escolhe o balde. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'balde-inventado, 203.0.113.99',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'],
	'piso do spoofing: o valor que o visitante empurrou na frente da cadeia virou a origem (' . $origem['valor'] . '), e com ela ele escolhe em que balde conta'
);

/* Dois proxies confiáveis: a declaração desconta os dois saltos, não um. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho'        => 'X-Forwarded-For',
		'saltos'           => 2,
		'redes_confiaveis' => array( '198.51.100.0/24' ),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99, 198.51.100.20',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'],
	'com dois saltos declarados a origem saiu ' . $origem['valor'] . ' em vez do IP do visitante'
);

/* Cadeia mais curta que a declaração não vira origem: ela volta a REMOTE_ADDR. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
	)
);

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'cadeia mais curta que os saltos declarados virou origem (' . $origem['valor'] . ') em vez de voltar para REMOTE_ADDR'
);

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho'        => 'X-Forwarded-For',
		'saltos'           => 1,
		/*
		 * A FAIXA DO PROXY entrou na declaração porque é ela que LIGA a conferência
		 * da conexão — sem faixa o cabeçalho é lido de qualquer lugar, e esta
		 * seção mede a leitura sob a proteção ligada. O REMOTE_ADDR de toda ela é
		 * 198.51.100.10, que está dentro da faixa declarada aqui.
		 */
		'redes_confiaveis' => array( '198.51.100.0/24' ),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

/* Cadeia mais curta que a declaração, ou valor que não é IP: volta a REMOTE_ADDR. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'nao-e-um-ip',
	)
);

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'valor que não é IP no cabeçalho declarado virou origem (' . $origem['valor'] . ') em vez de voltar para REMOTE_ADDR'
);

$origem = F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10' ) );

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'],
	'cabeçalho declarado e AUSENTE na requisição não voltou para REMOTE_ADDR'
);

/* O nome do cabeçalho vira variável de servidor, com e sem o prefixo. */
foreach ( array( 'X-Forwarded-For' => 'HTTP_X_FORWARDED_FOR', 'CF-Connecting-IP' => 'HTTP_CF_CONNECTING_IP', 'HTTP_CF_CONNECTING_IP' => 'HTTP_CF_CONNECTING_IP', '' => '' ) as $declarado => $esperado ) {
	afirmar(
		$nome,
		$esperado === F3Base_Modulo_Endpoint_Leads::chave_de_servidor( $declarado ),
		'o cabeçalho declarado "' . $declarado . '" virou "' . F3Base_Modulo_Endpoint_Leads::chave_de_servidor( $declarado ) . '" em vez de "' . $esperado . '"'
	);
}

/* O balde muda com a origem: dois visitantes atrás do mesmo proxy não se somam. */
bancada_limpa();

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho'        => 'X-Forwarded-For',
		'saltos'           => 1,
		/*
		 * A FAIXA DO PROXY entrou na declaração porque é ela que LIGA a conferência
		 * da conexão — sem faixa o cabeçalho é lido de qualquer lugar, e esta
		 * seção mede a leitura sob a proteção ligada. O REMOTE_ADDR de toda ela é
		 * 198.51.100.10, que está dentro da faixa declarada aqui.
		 */
		'redes_confiaveis' => array( '198.51.100.0/24' ),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$um    = hash( 'sha256', 'limite|' . F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10', 'HTTP_X_FORWARDED_FOR' => '203.0.113.1' ) )['valor'] . '|' . wp_salt( 'nonce' ) );
$outro = hash( 'sha256', 'limite|' . F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10', 'HTTP_X_FORWARDED_FOR' => '203.0.113.2' ) )['valor'] . '|' . wp_salt( 'nonce' ) );

afirmar(
	$nome,
	$um !== $outro,
	'dois visitantes distintos atrás do mesmo proxy caíram na MESMA chave de balde: é o balde único de 20 por 10 minutos para o proxy inteiro'
);

/* ==========================================================================
 * cadencia.ouvinte_registrado
 * ======================================================================= */

$nome = 'cadencia.ouvinte_registrado';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

/* PISO: o núcleo do WordPress não tem as recorrências que a configuração pede. */
$nucleo = f3b_recorrencias_do_nucleo();

afirmar(
	$nome,
	! isset( $nucleo['monthly'] ),
	'piso: a bancada inventou uma recorrência "monthly" no núcleo — sem a ausência dela, a degradação silenciosa não é reproduzível'
);

afirmar(
	$nome,
	! isset( $nucleo[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ] ) && ! isset( $nucleo[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ),
	'piso: as recorrências do módulo já existiam no núcleo da bancada'
);

/* PISO: sem ouvinte, o evento dispara e ninguém escuta — que é a 1.0.17. */
afirmar(
	$nome,
	0 === has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
	'piso: a bancada começou com ouvinte no hook da cadência, e não há como provar que é o registro que o cria'
);

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 3,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

/* TETO: o registro único enganchou o ouvinte. */
afirmar(
	$nome,
	has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ) > 0,
	'teto: depois do registro único NINGUÉM escuta ' . F3Base_Modulo_Cadencia_Relatorio::HOOK . ' — o evento dispara, o WP-Cron o reagenda, e nada acontece'
);

$agendas = wp_get_schedules();

afirmar(
	$nome,
	isset( $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ) && 30 * DAY_IN_SECONDS === (int) $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ]['interval'],
	'teto: a recorrência mensal não foi registrada com trinta dias de intervalo, e "mensal" volta a cair em daily'
);

afirmar(
	$nome,
	isset( $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ] ) && 15 * DAY_IN_SECONDS === (int) $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ]['interval'],
	'teto: a recorrência quinzenal não foi registrada com quinze dias, e "quinzenal" volta a cair em weekly, com o DOBRO da frequência'
);

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL === F3Base_Modulo_Cadencia_Relatorio::recorrencia_declarada(),
	'a periodicidade "mensal" da configuração não resolveu para a recorrência mensal registrada'
);

/* O agendamento acontece com a recorrência DECLARADA, não com a mais próxima. */
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL === F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada(),
	'o evento ficou agendado com "' . F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada() . '" e a configuração declara mensal'
);

/* O estado NOMEIA a divergência quando quem agendou não conhecia a recorrência. */
$GLOBALS['f3b_bench']['eventos'][ F3Base_Modulo_Cadencia_Relatorio::HOOK ]['schedule'] = 'daily';

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'] && str_contains( $estado['motivo'], 'daily' ),
	'a degradação de mensal para daily saiu como "' . $estado['estado'] . '" sem nomear a recorrência observada: era exatamente isso que acontecia em silêncio'
);

/* ==========================================================================
 * cadencia.execucao_registrada
 * ======================================================================= */

$nome = 'cadencia.execucao_registrada';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks']   = array();
$GLOBALS['f3b_bench']['eventos'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'quinzenal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

$modulo = new F3Base_Modulo_Cadencia_Relatorio();
$modulo->garantir_agendamento();

/*
 * DUAS execuções: a primeira CRIA as options de estado que ela mesma grava, e
 * comparar a contagem da primeira com a medição de agora compararia dois
 * momentos diferentes. Da segunda em diante o conjunto é estável, e é sobre ele
 * que a conferência do número tem sentido.
 */
$modulo->executar_por_cron();
$modulo->executar_por_cron();

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

foreach ( array( 'em', 'gatilho', 'resultado', 'duracao_ms', 'atraso_segundos', 'proxima', 'modulos', 'options' ) as $campo ) {
	afirmar(
		$nome,
		array_key_exists( $campo, $carimbo ),
		'a execução não registrou o campo "' . $campo . '": cadência que roda sem deixar última execução, próxima, duração, resultado e erro é cadência que ninguém sabe se rodou'
	);
}

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RESULTADO_OK === (string) ( $carimbo['resultado'] ?? '' ),
	'a execução limpa terminou em "' . (string) ( $carimbo['resultado'] ?? '' ) . '"'
);

afirmar(
	$nome,
	'' === (string) ( $carimbo['erro'] ?? 'x' ),
	'a execução limpa registrou erro: ' . (string) ( $carimbo['erro'] ?? '' )
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['modulos'] ?? '' ), 'cadencia-relatorio' ),
	'o relatório não NOMEIA os módulos que mediu: contagem por estado sem a lista de nomes responde "quantos" e a pergunta é "quais"'
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['options'] ?? '' ), 'divergentes' ),
	'o relatório não diz quais options divergiram na releitura'
);

/* Nenhum número inventado: a contagem de options relidas bate com a medição. */
$relidas = 0;

foreach ( F3Base_Options::nomes() as $option ) {
	if ( F3Base_Options::existe( $option ) ) {
		++$relidas;
	}
}

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['options'] ?? '' ), (string) $relidas . ' relida' ),
	'a contagem de options relidas no texto do relatório não bate com a medição de agora (' . $relidas . '): número em texto de relatório sai de medição, nunca de estimativa'
);

/* PISO do atraso: previsão no passado precisa virar atraso medido e degradação. */
$atrasado = time() - ( F3Base_Modulo_Cadencia_Relatorio::atraso_tolerado() + 3600 );

F3Base_Options::gravar(
	'f3base_cadencia_estado',
	array(
		'ajustes'  => 0,
		'previsto' => $atrasado,
	),
	F3Base_Options::ORIGEM_MANUAL
);

$modulo->executar_por_cron();
$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	(int) ( $carimbo['atraso_segundos'] ?? 0 ) > F3Base_Modulo_Cadencia_Relatorio::atraso_tolerado(),
	'piso do atraso: a execução atrasada registrou atraso de ' . (int) ( $carimbo['atraso_segundos'] ?? 0 ) . 's — evento atrasado que não é medido é evento que ninguém sabe que atrasou'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" com a última execução acima da tolerância de atraso'
);

/* PISO do erro: a medição que explode vira resultado erro NOMEADO, nunca sucesso. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

add_filter(
	'f3base_site_core_relatorio',
	static function ( $relatorio ) {
		throw new RuntimeException( 'a medição do relatório falhou na bancada' );
	}
);

( new F3Base_Modulo_Cadencia_Relatorio() )->executar_por_cron();

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RESULTADO_ERRO === (string) ( $carimbo['resultado'] ?? '' ),
	'piso do erro: a medição que explodiu registrou resultado "' . (string) ( $carimbo['resultado'] ?? '' ) . '"'
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['erro'] ?? '' ), 'a medição do relatório falhou na bancada' ),
	'piso do erro: o erro não foi registrado com a mensagem que o produziu'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" depois de uma execução que terminou em erro'
);

$GLOBALS['f3b_bench']['hooks'] = array();

/* ==========================================================================
 * cadencia.contador_de_ajustes
 * ======================================================================= */

$nome = 'cadencia.contador_de_ajustes';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks']   = array();
$GLOBALS['f3b_bench']['eventos'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'nenhuma',
		'apos_n_ajustes' => 3,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

afirmar(
	$nome,
	3 === F3Base_Modulo_Cadencia_Relatorio::apos_n_ajustes(),
	'piso: a chave apos_n_ajustes gravada pelo implantador não é LIDA por ninguém — era exatamente esse o defeito: o relatório prometia um gatilho sobre um contador inexistente'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o contador não começou em zero'
);

F3Base_Options::gravar( 'f3base_retencao_meses', 7, F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	1 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'teto: a escrita numa option gerenciada não foi contada como ajuste (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* PISO da reentrância: a própria atividade não pode contar como ajuste. */
F3Base_Atividade::registrar( F3Base_Atividade::ULTIMO_LEAD, array( 'record_id' => 'apenas-atividade' ) );

afirmar(
	$nome,
	1 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'piso da reentrância: o carimbo de atividade contou como ajuste (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ') — o site mudar porque rodou não é alguém ter ajustado alguma coisa, e contá-lo faz o gatilho disparar sozinho'
);

F3Base_Options::gravar( 'f3base_linkedin_partner_id', '123456', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	2 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o segundo ajuste não foi contado (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* TETO: ao alcançar o alvo, o gatilho DISPARA e zera o contador. */
F3Base_Options::gravar( 'f3base_retencao_meses', 9, F3Base_Options::ORIGEM_MANUAL );

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::GATILHO_AJUSTES === (string) ( $carimbo['gatilho'] ?? '' ),
	'teto: o terceiro ajuste NÃO disparou a execução (gatilho registrado: "' . (string) ( $carimbo['gatilho'] ?? 'nenhum' ) . '") — chave que não faz nada é pior que chave ausente, porque produz confiança'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o contador não foi zerado depois do disparo (ficou em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* PISO do gatilho desligado: alvo zero não mantém contador nem promete nada. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();
F3Base_Options::gravar( 'f3base_retencao_meses', 11, F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'piso do gatilho desligado: com apos_n_ajustes em zero o contador andou mesmo assim'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	str_contains( $estado['motivo'], 'zero' ),
	'com o gatilho desligado o estado do módulo não diz que nada promete disparar por ele: "' . $estado['motivo'] . '"'
);

/* Sem periodicidade e sem gatilho, o módulo é INERTE e declara por quê. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'nenhuma',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => '',
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$modulo = new F3Base_Modulo_Cadencia_Relatorio();

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo->estado()['estado'] && ! $modulo->deve_registrar(),
	'sem periodicidade e sem gatilho o módulo continuou registrando hooks: módulo inativo é inerte de verdade'
);

requisicao_nova();
F3Base_Site_Core::registrar();

afirmar(
	$nome,
	0 === has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
	'o módulo inativo enganchou o hook mesmo assim'
);

/* ---------- cta.publicado_pela_presenca_do_numero: teto e piso ---------- */

/*
 * A REGRA DA 1.0.19, e ela tem um lado só: a PRESENÇA do número decide se o
 * regime existe. Não há mais interruptor `ativo` ao lado do destino — havia
 * dois fatos podendo discordar, e eles discordavam.
 *
 * TETO: com número gravado, o bloco do CTA é publicado.
 * PISO: sem número, o bloco NÃO é publicado — nem no comportamento degradado.
 * Publicar um botão que não leva a lugar nenhum é pior que não ter botão, e era
 * isso que a base entregava: "Falar com a equipe" apontando para a própria
 * página de contato.
 *
 * O DISCRIMINANTE É A CLASSE, que mora no arquivo do pattern, e não o atributo,
 * que é carimbo de render e depende de `WP_HTML_Tag_Processor`. Decidir pelo
 * atributo deixaria o botão publicado justamente na instalação onde o
 * processador não existe — e é isso que o último ramo mede: esta bancada NÃO
 * tem o processador, e o CTA continua não sendo publicado.
 */

$nome = 'cta.publicado_pela_presenca_do_numero';

bancada_limpa();

$modulo_cta = new F3Base_Modulo_Leads_Whatsapp();

$bloco_do_cta = '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
	. '<a class="wp-block-button__link wp-element-button" href="/contato/" '
	. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';

$bloco_alheio = '<div class="wp-block-button"><a class="wp-block-button__link" href="/blog/">Ler o blog</a></div>';

/* PISO: número vazio — a option nasce assim no template. */
afirmar(
	$nome,
	'' === $modulo_cta->promover_cta( $bloco_do_cta, array() ),
	'piso da publicação: sem número em f3base_contato o bloco do CTA foi PUBLICADO — um botão que não leva a lugar nenhum é pior que não ter botão, e é isso que a presença do valor passou a decidir'
);

afirmar(
	$nome,
	$bloco_alheio === $modulo_cta->promover_cta( $bloco_alheio, array() ),
	'piso do alcance: um bloco que não é o CTA foi alterado — a regra vale para o CTA e para mais nada'
);

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo_cta->estado()['estado'],
	'piso do estado: sem número o módulo fechou "' . $modulo_cta->estado()['estado'] . '" em vez de inativo — regime que não existe não está degradado, e degradado é reservado ao que está PIOR que o desenho'
);

afirmar(
	$nome,
	str_contains( $modulo_cta->estado()['motivo'], 'não é publicado' ),
	'piso do estado: o motivo não diz que o CTA não é publicado — o operador precisa saber o que aconteceu com o botão, não só que falta um número'
);

/* TETO: com número gravado, o bloco do CTA É publicado. */
F3Base_Options::gravar(
	'f3base_contato',
	array( 'whatsapp_e164' => '5511999999999' ),
	F3Base_Options::ORIGEM_MANUAL
);

$modulo_com_numero = new F3Base_Modulo_Leads_Whatsapp();

afirmar(
	$nome,
	'' !== $modulo_com_numero->promover_cta( $bloco_do_cta, array() ),
	'teto da publicação: com número gravado o CTA deixou de ser publicado — preencher a chave tem de fazer o botão existir na página seguinte, sem passo manual'
);

afirmar(
	$nome,
	str_contains( $modulo_com_numero->promover_cta( $bloco_do_cta, array() ), F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA ),
	'teto da publicação: o bloco publicado perdeu a classe do CTA'
);

/*
 * PISO DO DISCRIMINANTE: esta bancada NÃO tem WP_HTML_Tag_Processor, e é
 * justamente aí que decidir pelo atributo carimbado deixaria o botão publicado.
 */
afirmar(
	$nome,
	! class_exists( 'WP_HTML_Tag_Processor' ),
	'piso do discriminante: a bancada passou a ter WP_HTML_Tag_Processor, e sem a ausência dele este ramo não reproduz a instalação em que o atributo nunca é carimbado'
);

bancada_limpa();

$modulo_sem_atributo = new F3Base_Modulo_Leads_Whatsapp();

afirmar(
	$nome,
	'' === $modulo_sem_atributo->promover_cta(
		'<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
			. '<a class="wp-block-button__link" href="/contato/">Falar com a equipe</a></div>',
		array()
	),
	'piso do discriminante: sem o atributo carimbado — que é o que acontece quando WP_HTML_Tag_Processor não existe — o CTA voltou a ser publicado sem número'
);

/* ==========================================================================
 * cta.regra_de_publicacao_registrada
 *
 * O ALCANCE, medido pelo CAMINHO REAL. As afirmações acima chamam
 * `promover_cta()` direto; num site quem a chama é o filtro `render_block`, e é
 * ele que precisa existir para decidir. Da 1.0.19 à 1.1.0 o filtro só era
 * registrado com o módulo ATIVO — isto é, com número gravado —, e aí a condição
 * da supressão (número vazio) já não podia acontecer: a regra estava escrita em
 * três documentos e não rodava em site nenhum, e o botão morto do pattern ia ao
 * ar. A marca `sempre` no item do hook é o que corrigiu isso.
 *
 * Daqui para baixo NADA é chamado direto: tudo passa por `apply_filters()`, com
 * o módulo no estado que ele terá em produção.
 * ======================================================================= */

$nome = 'cta.regra_de_publicacao_registrada';

bancada_limpa();
F3Base_Site_Core::registrar();

$modulo_inativo = new F3Base_Modulo_Leads_Whatsapp();

/* PISO: a bancada reproduz o estado de produção? Número vazio, módulo INATIVO. */
afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo_inativo->estado()['estado'] && ! $modulo_inativo->deve_registrar(),
	'piso: a bancada não reproduz o estado de produção — com f3base_contato vazia o módulo tem de fechar inativo, e é justamente nesse estado que a regra de publicação precisa rodar'
);

/* TETO DO REGISTRO: o filtro existe MESMO com o módulo inativo. */
afirmar(
	$nome,
	ouvintes_da_classe( 'render_block', 'F3Base_Modulo_Leads_Whatsapp' ) > 0,
	'teto do registro: o filtro render_block NÃO foi registrado com o módulo inativo — foi este o defeito medido da 1.0.19 à 1.1.0: a regra de publicação do CTA existia, estava afirmada em três documentos e não rodava, porque só era registrada quando a condição dela já não podia acontecer'
);

afirmar(
	$nome,
	1 === count(
		array_filter(
			$modulo_inativo->hooks(),
			static fn ( array $hook ): bool => ! empty( $hook['sempre'] )
		)
	),
	'teto do registro: a exceção deixou de ser declarada por hook — sem a marca no item, quem lê o módulo não sabe qual hook escapa da regra do inativo, e a exceção vira comportamento escondido'
);

/* PISO DA EXCEÇÃO: ela alcança UM hook. O enfileiramento continua inerte. */
afirmar(
	$nome,
	0 === ouvintes_da_classe( 'wp_enqueue_scripts', 'F3Base_Modulo_Leads_Whatsapp' ),
	'piso da exceção: um hook sem a marca foi registrado com o módulo inativo — a exceção é por hook, e "módulo inativo é inerte" continua valendo para asset, endpoint e tabela'
);

/* OS QUATRO QUADRANTES, agora pelo filtro e não pela chamada direta. */
$pelo_filtro = static function ( string $html ): string {
	return (string) apply_filters( 'render_block', $html, array( 'blockName' => 'core/button' ) );
};

$cta_do_modelo = '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
	. '<a class="wp-block-button__link wp-element-button" href="' . F3Base_Modulo_Leads_Whatsapp::HREF_DO_MODELO . '" '
	. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';

$cta_do_agente = '<div class="wp-block-button ' . F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA . '">'
	. '<a class="wp-block-button__link wp-element-button" href="https://campanha.exemplo.test/lp-outubro" '
	. F3Base_Modulo_Leads_Whatsapp::ATRIBUTO . '="cta">Falar com a equipe</a></div>';

afirmar(
	$nome,
	'' === $pelo_filtro( $cta_do_modelo ),
	'quadrante 1 pelo filtro: sem número, o CTA com o href do modelo FOI publicado — é o botão morto do pattern indo ao ar, que é exatamente o que a regra existe para impedir e o que ela não impedia'
);

afirmar(
	$nome,
	$cta_do_agente === $pelo_filtro( $cta_do_agente ),
	'quadrante 2 pelo filtro: sem número, o CTA com destino próprio foi suprimido ou alterado — apagar o destino que alguém escolheu é o inverso da premissa desta release'
);

F3Base_Options::gravar( 'f3base_contato', array( 'whatsapp_e164' => '5511999999999' ), F3Base_Options::ORIGEM_MANUAL );
requisicao_nova();
$GLOBALS['f3b_bench']['hooks'] = array();
F3Base_Site_Core::registrar();

afirmar(
	$nome,
	( new F3Base_Modulo_Leads_Whatsapp() )->deve_registrar() && ouvintes_da_classe( 'wp_enqueue_scripts', 'F3Base_Modulo_Leads_Whatsapp' ) > 0,
	'teto do estado: com número gravado o módulo continua fechando inativo, ou o hook normal dele não foi registrado — a marca sempre não pode ter substituído a regra, só aberto uma exceção nela'
);

afirmar(
	$nome,
	'' !== $pelo_filtro( $cta_do_modelo ) && str_contains( $pelo_filtro( $cta_do_modelo ), F3Base_Modulo_Leads_Whatsapp::CLASSE_CTA ),
	'quadrante 3 pelo filtro: com número gravado o CTA do modelo deixou de ser publicado'
);

afirmar(
	$nome,
	str_contains( $pelo_filtro( $cta_do_agente ), 'https://campanha.exemplo.test/lp-outubro' ),
	'quadrante 4 pelo filtro: com número gravado o destino do agente foi sobrescrito — o pacote preenche quando falta e não manda no que já tem dono'
);

/* ==========================================================================
 * options.chave_desconhecida_preservada
 *
 * O DEFEITO MEDIDO na 1.0.19: todo sanitizador de grupo RECONSTRUÍA o array a
 * partir das chaves declaradas. O agente acrescentava `telefone` a
 * `f3base_contato` pelo canal, a escrita entrava no banco, e a primeira LEITURA
 * devolvia o valor sem a chave — apagada em silêncio.
 * ======================================================================= */

$nome = 'options.chave_desconhecida_preservada';

bancada_limpa();

/* PISO: a bancada reproduz o defeito? O reconstrutor de chaves fixas PERDE a chave. */
$reconstrutor_da_1_0_19 = static function ( array $bruto ): array {
	return array(
		'whatsapp_e164'   => (string) ( $bruto['whatsapp_e164'] ?? '' ),
		'email_leads'     => (string) ( $bruto['email_leads'] ?? '' ),
		'mensagem_padrao' => (string) ( $bruto['mensagem_padrao'] ?? '' ),
	);
};

$do_agente = array(
	'whatsapp_e164' => '+55 (11) 99999-9999',
	'telefone'      => '+55 11 3333-4444',
	'horario'       => array( 'seg_sex' => '09:00-18:00' ),
);

afirmar(
	$nome,
	! array_key_exists( 'telefone', $reconstrutor_da_1_0_19( $do_agente ) ),
	'piso: a bancada não reproduz o descarte da 1.0.19 — o reconstrutor de chaves fixas devolveu a chave desconhecida, e sem esse descarte o teto abaixo aprovaria por acaso'
);

F3Base_Options::gravar( 'f3base_contato', $do_agente, F3Base_Options::ORIGEM_MANUAL );
$lido_contato = F3Base_Options::ler( 'f3base_contato' );

afirmar(
	$nome,
	is_array( $lido_contato ) && '+55 11 3333-4444' === (string) ( $lido_contato['telefone'] ?? '' ),
	'teto: a chave que o agente acrescentou a f3base_contato NÃO sobreviveu à leitura — é o apagamento silencioso da 1.0.19, e ele é o inverso da premissa desta release'
);

afirmar(
	$nome,
	is_array( $lido_contato ) && '09:00-18:00' === (string) ( $lido_contato['horario']['seg_sex'] ?? '' ),
	'teto aninhado: a lista desconhecida foi achatada ou perdida — preservar chave desconhecida vale para a estrutura, não só para o escalar'
);

/* PISO da normalização: preservar o desconhecido não é parar de normalizar o conhecido. */
afirmar(
	$nome,
	is_array( $lido_contato ) && '5511999999999' === (string) ( $lido_contato['whatsapp_e164'] ?? '' ),
	'piso da normalização: a chave CONHECIDA deixou de ser normalizada — preservar o desconhecido virou aceitar qualquer coisa, que é o defeito oposto'
);

/* TETO do catálogo: a regra vale para TODA option de grupo, e não para uma. */
foreach ( F3Base_Options::catalogo() as $option_do_catalogo => $declaracao_do_catalogo ) {
	$padrao_do_catalogo = $declaracao_do_catalogo['padrao'];

	if ( 'grupo' !== (string) $declaracao_do_catalogo['campo'] || ! is_array( $padrao_do_catalogo ) || array() === $padrao_do_catalogo ) {
		continue;
	}

	if ( array_keys( $padrao_do_catalogo ) === range( 0, count( $padrao_do_catalogo ) - 1 ) ) {
		continue;
	}

	$com_desconhecida = $padrao_do_catalogo;
	$com_desconhecida['chave_de_bancada'] = 'valor-do-agente';

	$normalizado = F3Base_Options::sanitizar( $option_do_catalogo, $com_desconhecida );

	afirmar(
		$nome,
		is_array( $normalizado ) && 'valor-do-agente' === (string) ( $normalizado['chave_de_bancada'] ?? '' ),
		'teto do catálogo: ' . $option_do_catalogo . ' descartou a chave desconhecida na leitura — a regra é do catálogo inteiro, e uma option de fora dela é a próxima a apagar trabalho do agente'
	);
}

/* TETO das options em LISTA: a chave desconhecida sobrevive DENTRO da entrada. */
$redirects_do_agente = F3Base_Options::sanitizar(
	'f3base_redirects',
	array(
		array(
			'de'    => '/antigo',
			'para'  => '/novo',
			'status' => 301,
			'nota'  => 'motivo escrito pelo agente',
		),
	)
);

afirmar(
	$nome,
	'motivo escrito pelo agente' === (string) ( $redirects_do_agente[0]['nota'] ?? '' ),
	'teto de lista: f3base_redirects apagou a chave desconhecida da regra — a entrada é reconstruída, e reconstruir é apagar'
);

/*
 * O JOURNAL É A EXCEÇÃO DECLARADA, e ela tem que ser medida como exceção — não
 * esquecida. A regra da 1.1.0 protege CONFIGURAÇÃO: o agente acrescenta uma
 * chave a um ajuste do site e o pacote não a apaga. O journal de eliminação não
 * é configuração: é o registro do que já foi apagado, e o docblock dele promete
 * que ele NUNCA guarda o conteúdo eliminado. Preservar campo desconhecido ali
 * seria a porta pela qual o conteúdo do lead volta para dentro da option que
 * existe justamente para provar que ele saiu. Até esta release o sanitizador
 * PRESERVAVA enquanto o próprio docblock prometia descartar; das duas, a
 * promessa é a que está certa.
 */
$journal_do_agente = F3Base_Options::sanitizar(
	'f3base_journal_eliminacao',
	array(
		array(
			'regime'    => 'operacional',
			'contagem'  => 3,
			'chamado'   => 'OS-4471',
		),
	)
);

afirmar(
	$nome,
	! array_key_exists( 'chamado', (array) ( $journal_do_agente[0] ?? array() ) ),
	'exceção declarada: f3base_journal_eliminacao PRESERVOU a chave desconhecida — é por essa porta que o conteúdo eliminado volta para a option que prova que ele saiu, e o docblock dela promete o contrário'
);

afirmar(
	$nome,
	3 === (int) ( $journal_do_agente[0]['contagem'] ?? 0 ),
	'piso da exceção: descartar o desconhecido virou descartar a entrada — os campos DECLARADOS do journal continuam obrigatórios'
);

/*
 * TETO DO SEGUNDO NÍVEL: a preservação valia SÓ no primeiro nível da option.
 *
 * O DEFEITO MEDIDO: `preservar_desconhecidas()` cobria a option inteira, e cada
 * item de `ponto_de_contato[]`, de `servicos[]`, de `llms.livres[]` e o objeto
 * de `politica_privacidade` continuava sendo RECONSTRUÍDO a partir das chaves
 * declaradas. É o apagamento silencioso da 1.0.19 acontecendo um nível abaixo, e
 * o caso é o mesmo: o agente acrescenta `whatsapp` a um ponto de contato pelo
 * canal, a escrita entra no banco e a primeira LEITURA a devolve sem a chave.
 */
$entidade_do_agente = F3Base_Options::sanitizar(
	'f3base_seo_entidade',
	array(
		'nome'             => 'Exemplo',
		'ponto_de_contato' => array(
			array(
				'tipo'     => 'customer support',
				'telefone' => '+55 11 3333-4444',
				'whatsapp' => '+55 11 99999-9999',
			),
		),
		'servicos'         => array(
			array(
				'nome'              => 'Diagnóstico de linha',
				'preco_a_partir_de' => 'sob consulta',
			),
		),
	)
);

afirmar(
	$nome,
	'+55 11 99999-9999' === (string) ( $entidade_do_agente['ponto_de_contato'][0]['whatsapp'] ?? '' ),
	'teto do segundo nível: a chave desconhecida DENTRO de um ponto_de_contato foi apagada — a regra da 1.1.0 vale para o item da lista, não só para o primeiro nível da option'
);

afirmar(
	$nome,
	'sob consulta' === (string) ( $entidade_do_agente['servicos'][0]['preco_a_partir_de'] ?? '' ),
	'teto do segundo nível: a chave desconhecida DENTRO de um serviço foi apagada'
);

afirmar(
	$nome,
	'customer support' === (string) ( $entidade_do_agente['ponto_de_contato'][0]['tipo'] ?? '' ),
	'piso do segundo nível: a chave CONHECIDA do item deixou de ser normalizada — preservar o desconhecido virou aceitar qualquer coisa dentro do item'
);

$llms_do_agente = F3Base_Options::sanitizar(
	'f3base_llms',
	array(
		'politica_privacidade' => array(
			'url'      => 'https://exemplo.test/privacidade',
			'revisada' => '2026-01-10',
		),
		'livres'               => array(
			array(
				'url'    => 'https://exemplo.test/manual',
				'idioma' => 'pt-BR',
			),
		),
	)
);

afirmar(
	$nome,
	'2026-01-10' === (string) ( $llms_do_agente['politica_privacidade']['revisada'] ?? '' ),
	'teto do segundo nível: a chave desconhecida dentro de politica_privacidade foi apagada'
);

afirmar(
	$nome,
	'pt-BR' === (string) ( $llms_do_agente['livres'][0]['idioma'] ?? '' ),
	'teto do segundo nível: a chave desconhecida dentro de um item de llms.livres foi apagada'
);

/* PISO da chave impossível: nome que não sobra ao alfabeto não vira chave vazia. */
$com_chave_torta = F3Base_Options::sanitizar(
	'f3base_contato',
	array(
		'whatsapp_e164' => '5511999999999',
		'<b>'           => 'valor',
	)
);

afirmar(
	$nome,
	! array_key_exists( '', $com_chave_torta ),
	'piso da chave impossível: um nome que não sobrou à redução virou a chave vazia — gravar sob "" é perder o valor de outro jeito'
);

/* ==========================================================================
 * seguranca.coop_do_valor_gravado
 *
 * O DEFEITO MEDIDO: `sanitiza_cabecalhos()` devolvia `coop` como LITERAL,
 * ignorando o valor armazenado, e o emissor mandava a constante da classe. Quem
 * gravasse outro valor lia de volta o do pacote — e a leitura de volta conferia
 * contra o que a própria sanitização tinha imposto.
 * ======================================================================= */

$nome = 'seguranca.coop_do_valor_gravado';

bancada_limpa();

$cabecalhos_padrao = ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos();

/* PISO: a bancada parte do valor do pacote? Sem isso, a troca abaixo não prova nada. */
afirmar(
	$nome,
	F3Base_Modulo_Cabecalhos::COOP_EXIGIDO === (string) ( $cabecalhos_padrao['Cross-Origin-Opener-Policy'] ?? '' ),
	'piso: o padrão embutido não é o valor recomendado do pacote, e sem essa diferença a troca abaixo não distingue o valor gravado do literal'
);

F3Base_Options::gravar( 'f3base_cabecalhos', array( 'coop' => 'same-origin' ), F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	'same-origin' === (string) ( F3Base_Options::ler( 'f3base_cabecalhos' )['coop'] ?? '' ),
	'teto da leitura: o valor gravado não sobreviveu à sanitização — é o literal da 1.0.19 vencendo a option, e quem gravou não tem como saber por quê'
);

$cabecalhos_gravados = ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos();

afirmar(
	$nome,
	'same-origin' === (string) ( $cabecalhos_gravados['Cross-Origin-Opener-Policy'] ?? '' ),
	'teto da emissão: o cabeçalho emitido não é o valor gravado — a option existia e não tinha efeito nenhum'
);

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Cabecalhos() )->estado()['estado'],
	'o módulo não NOMEIA a consequência do valor gravado: emitir o que pediram sem dizer o preço é a outra metade da honestidade'
);

afirmar(
	$nome,
	str_contains( ( new F3Base_Modulo_Cabecalhos() )->estado()['motivo'], 'janela' ),
	'o motivo não diz o que se perde: o operador precisa ler que a janela aberta pelo CTA perde a relação com esta aba'
);

/* PISO do vocabulário: valor que o navegador não conhece cai no padrão declarado. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_cabecalhos', array( 'coop' => 'valor-que-nao-existe' ), F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	F3Base_Modulo_Cabecalhos::COOP_EXIGIDO === (string) ( F3Base_Options::ler( 'f3base_cabecalhos' )['coop'] ?? '' ),
	'piso do vocabulário: valor fora do vocabulário do cabeçalho foi emitido — cabeçalho que o navegador ignora em silêncio é pior que cabeçalho ausente'
);

/* ==========================================================================
 * seguranca.referrer_policy_avisa_atribuicao
 * ======================================================================= */

$nome = 'seguranca.referrer_policy_avisa_atribuicao';

bancada_limpa();

/* PISO do ramo adverso: com o valor padrão, NÃO sai aviso nenhum. */
afirmar(
	$nome,
	array() === ( new F3Base_Modulo_Cabecalhos() )->avisos(),
	'piso do ramo adverso: o aviso saiu com o valor padrão gravado — aviso que sai sempre treina o operador a ignorar aviso, e foi a lição que a 1.0.14 pagou'
);

F3Base_Options::gravar(
	'f3base_cabecalhos',
	array( 'referrer_policy' => F3Base_Modulo_Cabecalhos::REFERRER_SEM_ORIGEM ),
	F3Base_Options::ORIGEM_MANUAL
);

$avisos_do_referrer = ( new F3Base_Modulo_Cabecalhos() )->avisos();

afirmar(
	$nome,
	1 === count( $avisos_do_referrer ),
	'teto: Referrer-Policy no-referrer gravado e nenhum aviso emitido — é o cabeçalho que apaga a origem dos quatro canais pagos, e ele passou calado'
);

afirmar(
	$nome,
	'WARN' === (string) ( $avisos_do_referrer[0]['estado'] ?? '' ),
	'o aviso não fecha em WARN: a lista de estados do contrato tem seis nomes, e este é o único que cabe em "funciona, e custa isto"'
);

$motivo_do_referrer = (string) ( $avisos_do_referrer[0]['motivo'] ?? '' );

afirmar(
	$nome,
	str_contains( $motivo_do_referrer, 'GA4' ) && str_contains( $motivo_do_referrer, 'Meta Ads' ) && str_contains( $motivo_do_referrer, 'LinkedIn Ads' ),
	'o aviso não NOMEIA a consequência nos canais: sem os nomes, ele é um alerta genérico sobre um cabeçalho de segurança'
);

/* TETO: avisar não é recusar. O valor continua sendo emitido. */
afirmar(
	$nome,
	F3Base_Modulo_Cabecalhos::REFERRER_SEM_ORIGEM === (string) ( ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos()['Referrer-Policy'] ?? '' ),
	'teto: o cabeçalho gravado deixou de ser emitido por causa do aviso — avisar é nomear o preço, e recusar seria decidir pelo projeto'
);

/* ==========================================================================
 * tracking.caminho_unico
 * ======================================================================= */

$nome = 'tracking.caminho_unico';

bancada_limpa();

/* PISO do slot vazio SEM destino nenhum: nasce inerte, e inerte é NADA no HTML. */
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => false ), F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_NENHUM === F3Base_Modulo_Tracking::caminho(),
	'piso do slot vazio: o catálogo nasce sem ID nenhum e o caminho não é "nenhum" — slot vazio que emite alguma coisa emite um placeholder'
);

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === ( new F3Base_Modulo_Tracking() )->estado()['estado'],
	'piso do slot vazio: o módulo não fecha inativo com o catálogo vazio — regime que não existe não está degradado'
);

( new F3Base_Modulo_Tracking() )->enfileirar();

afirmar(
	$nome,
	array() === $GLOBALS['f3b_bench']['scripts'],
	'piso do slot vazio: sem ID de medição E com o resumo do próprio site DESLIGADO não existe destino nenhum, e alguma coisa foi enfileirada assim mesmo'
);

/*
 * TETO DO SEGUNDO DESTINO — a metade que a 1.1.4 acrescenta, e a razão de a
 * asserção acima ter ganhado a condição do resumo. Com o resumo LIGADO o site
 * passa a ter para onde mandar o comportamento mesmo sem conta de medição, e o
 * carregador é enfileirado. O que NÃO pode acontecer é um ID vazar junto: sem
 * slot preenchido, o navegador continua recebendo o caminho "nenhum" e nenhum
 * identificador, e o módulo continua INATIVO para tags.
 */
bancada_limpa();
requisicao_nova();
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true ), F3Base_Options::ORIGEM_MANUAL );

( new F3Base_Modulo_Tracking() )->enfileirar();

afirmar(
	$nome,
	array( F3Base_Modulo_Tracking::HANDLE ) === array_keys( $GLOBALS['f3b_bench']['scripts'] ),
	'teto do segundo destino: com o resumo do próprio site ligado, o carregador NÃO foi enfileirado — e sem ele nenhuma página registra comportamento, que é a pergunta que esta release responde'
);

$medicao_sem_slot = F3Base_Modulo_Tracking::dados_de_medicao();

afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_NENHUM === (string) $medicao_sem_slot['caminho']
		&& '' === (string) $medicao_sem_slot['ga4']
		&& '' === (string) $medicao_sem_slot['gtm']
		&& '' === (string) $medicao_sem_slot['meta']['pixelId']
		&& '' === (string) $medicao_sem_slot['linkedin']['partnerId'],
	'piso do segundo destino: o resumo local abriu o portão e um identificador de medição viajou junto — o resumo é destino do SITE, e ele não pode fazer nascer uma conta que ninguém gravou'
);

afirmar(
	$nome,
	! empty( $medicao_sem_slot['resumo']['ativo'] ) && '' !== (string) $medicao_sem_slot['resumo']['endpoint'],
	'teto do segundo destino: o endereço do resumo não chegou ao navegador, e sem ele o beacon não tem para onde ir'
);

/*
 * O ESTADO SEGUE O DESTINO, e não o slot de fornecedor. Esta asserção media o
 * contrário até a 1.3.2 — exigia INATIVO sem ID — e era ela que sustentava o
 * defeito medido em produção: módulo inativo não registra hook, o
 * `wp_enqueue_scripts` nunca era registrado, `enfileirar()` nunca era chamado, e
 * um site sem ID de fornecedor ficava sem NENHUMA medição, inclusive a própria.
 * A tabela ficou em zero linha e o script não apareceu no HTML.
 */
afirmar(
	$nome,
	F3Base_Modulo::ATIVO === ( new F3Base_Modulo_Tracking() )->estado()['estado'],
	'TETO do site sem fornecedor: sem ID de fornecedor e com o resumo do próprio site ligado, o módulo de tracking fechou "'
		. ( new F3Base_Modulo_Tracking() )->estado()['estado']
		. '" em vez de ativo. Módulo inativo NÃO REGISTRA HOOK: o wp_enqueue_scripts não é registrado, enfileirar() nunca roda, e o site inteiro fica sem medição nenhuma — foi exatamente este o estado medido em produção'
);

/*
 * PISO do mesmo teto: sem NENHUM dos dois destinos o módulo volta a ser inerte.
 * Sem ele a regra nova teria virado "sempre ativo", que é o outro extremo — o
 * carregador no HTML de um site que não tem para onde mandar nada.
 */
bancada_limpa();
requisicao_nova();
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => false ), F3Base_Options::ORIGEM_MANUAL );

$GLOBALS['f3b_bench']['scripts'] = array();
( new F3Base_Modulo_Tracking() )->enfileirar();

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === ( new F3Base_Modulo_Tracking() )->estado()['estado']
		&& array() === $GLOBALS['f3b_bench']['scripts'],
	'PISO do site sem fornecedor: sem ID de fornecedor E com o resumo do próprio site DESLIGADO, o módulo não ficou inerte — não há destino nenhum, e um carregador no HTML sobre nada é peso sem medida'
);

bancada_limpa();
requisicao_nova();
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true ), F3Base_Options::ORIGEM_MANUAL );

bancada_limpa();
requisicao_nova();

/* TETO do caminho direto: os IDs presentes chegam ao navegador. */
F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar(
	'f3base_google_ads',
	array(
		'conversion_id'    => 'AW-123456789',
		'conversion_label' => 'AbC-D_efGhIjKlM',
	),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_DIRETO === F3Base_Modulo_Tracking::caminho(),
	'teto do caminho direto: com IDs gravados e sem container, o caminho deixou de ser o direto'
);

$medicao_direta = F3Base_Modulo_Tracking::dados_de_medicao();

afirmar(
	$nome,
	'G-ABCDEF1234' === (string) $medicao_direta['ga4']
		&& '123456789012345' === (string) $medicao_direta['meta']['pixelId']
		&& 'AW-123456789' === (string) $medicao_direta['ads']['id'],
	'teto do caminho direto: um dos IDs gravados não chegou ao navegador'
);

afirmar(
	$nome,
	'' === (string) $medicao_direta['gtm'],
	'teto do caminho direto: o container viajou junto das tags diretas, e é assim que a mesma conversão sai duas vezes'
);

/* TETO do container: ele decide, e os IDs diretos NEM CHEGAM ao navegador. */
F3Base_Options::gravar( 'f3base_gtm_container_id', 'GTM-ABC1234', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_GTM === F3Base_Modulo_Tracking::caminho(),
	'teto do container: com GTM gravado, o caminho não virou o do container'
);

$medicao_gtm = F3Base_Modulo_Tracking::dados_de_medicao();

afirmar(
	$nome,
	'GTM-ABC1234' === (string) $medicao_gtm['gtm'],
	'teto do container: o container não chegou ao navegador'
);

afirmar(
	$nome,
	'' === (string) $medicao_gtm['ga4']
		&& '' === (string) $medicao_gtm['meta']['pixelId']
		&& '' === (string) $medicao_gtm['ads']['id']
		&& '' === (string) $medicao_gtm['ads']['label']
		&& '' === (string) $medicao_gtm['linkedin']['partnerId']
		&& '' === (string) $medicao_gtm['linkedin']['conversionId'],
	'piso do disparo em dobro: no caminho do container os IDs diretos ainda chegam ao navegador — enquanto chegarem, uma linha esquecida no cliente conta a mesma conversão duas vezes, e conversão em dobro reescreve o lance do leilão'
);

/* PISO da forma: ID fora da forma é PRESERVADO e AVISADO, nunca apagado. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	'ABCDEF1234' === (string) F3Base_Options::ler( 'f3base_ga4_measurement_id' ),
	'piso da forma: o measurement ID fora da forma foi APAGADO pela sanitização — apagar em silêncio é o que esta release parou de fazer'
);

$avisos_de_forma = ( new F3Base_Modulo_Tracking() )->avisos();

afirmar(
	$nome,
	array() !== $avisos_de_forma && str_contains( (string) $avisos_de_forma[0]['motivo'], 'G-XXXXXXXXXX' ),
	'piso da forma: o ID fora da forma passou calado — a tag carrega, a conta não recebe nada, e não há erro no console para procurar'
);

/* ==========================================================================
 * tracking.consentimento_gateia_tudo
 * ======================================================================= */

$nome = 'tracking.consentimento_gateia_tudo';

bancada_limpa();

F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_linkedin_partner_id', '1234567', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_linkedin_conversion_id', '7654321', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'negado' ), F3Base_Options::ORIGEM_MANUAL );

/* PISO: a bancada reproduz a negativa? Sem ela, o ramo do portão não é medido. */
afirmar(
	$nome,
	! F3Base_Modulo_Consentimento::permite_tags(),
	'piso: a bancada não reproduz a negativa de consentimento, e sem ela o teto abaixo aprovaria por acaso'
);

( new F3Base_Modulo_Tracking() )->enfileirar();

/*
 * O PORTÃO MUDOU DE LUGAR, e o motivo é o CACHE DE PÁGINA. O enfileiramento
 * lia `$_COOKIE` para decidir se o `<script>` entra no HTML, sem `Vary` e sem
 * `DONOTCACHEPAGE`: a decisão do primeiro visitante a gerar aquela página
 * ficava congelada no cache para todos os seguintes — um que recusou apagava a
 * medição do site inteiro, e um que aceitou entregava o carregador a quem
 * tinha recusado. O carregador agora é o MESMO bytes para todo visitante, e
 * por isso é cacheável; quem confere o consentimento é o cliente, no navegador
 * em que a decisão foi tomada, e é ele que não carrega tag nenhuma de
 * fornecedor sob negativa (medido em `js.ordem_do_consentimento` e em
 * `js.conversao_multicanal`).
 */
afirmar(
	$nome,
	array_key_exists( F3Base_Modulo_Tracking::HANDLE, $GLOBALS['f3b_bench']['scripts'] ),
	'teto do cache: com o consentimento negado o carregador NÃO foi enfileirado — o HTML voltou a depender do cookie do visitante, e cache de página congela essa decisão para quem vier depois'
);

afirmar(
	$nome,
	in_array( F3Base_Modulo_Consentimento::HANDLE, $GLOBALS['f3b_bench']['scripts'][ F3Base_Modulo_Tracking::HANDLE ]['deps'] ?? array(), true ),
	'piso do portão no cliente: o carregador servido sob negativa não declara dependência do script de consentimento — sem essa ordem, o portão que passou a decidir tudo pode não existir quando o carregador rodar'
);

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Tracking() )->estado()['estado'],
	'piso do portão: o módulo não conta que a negativa desligou as quatro tags'
);

/* TETO: com consentimento, as quatro saem por UM carregador só. */
F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'pre-aprovado' ), F3Base_Options::ORIGEM_MANUAL );
$GLOBALS['f3b_bench']['scripts'] = array();

( new F3Base_Modulo_Tracking() )->enfileirar();

$scripts_do_tracking = $GLOBALS['f3b_bench']['scripts'];

afirmar(
	$nome,
	isset( $scripts_do_tracking[ F3Base_Modulo_Tracking::HANDLE ] ),
	'teto: com consentimento vigente e IDs gravados, nenhuma tag foi enfileirada'
);

afirmar(
	$nome,
	1 === count( $scripts_do_tracking ),
	'piso do portão único: mais de um carregador foi enfileirado — quatro tags atrás de quatro portões é a garantia de que um deles vai ficar para trás'
);

$dados_no_navegador = $scripts_do_tracking[ F3Base_Modulo_Tracking::HANDLE ]['dados']['f3baseTrackingDados'] ?? array();

afirmar(
	$nome,
	in_array( F3Base_Modulo_Consentimento::HANDLE, $scripts_do_tracking[ F3Base_Modulo_Tracking::HANDLE ]['deps'], true ),
	'teto: o carregador das tags não depende do script de consentimento — sem essa ordem, a tag decide antes de o Consent Mode ter default'
);

afirmar(
	$nome,
	'G-ABCDEF1234' === (string) ( $dados_no_navegador['ga4'] ?? '' )
		&& '123456789012345' === (string) ( $dados_no_navegador['meta']['pixelId'] ?? '' )
		&& '1234567' === (string) ( $dados_no_navegador['linkedin']['partnerId'] ?? '' )
		&& '7654321' === (string) ( $dados_no_navegador['linkedin']['conversionId'] ?? '' ),
	'teto: um dos quatro canais não chegou ao carregador único'
);

/*
 * O CLIENTE DO CTA TAMBÉM PASSA PELO PORTÃO, e ele não declarava a dependência.
 * `f3base-leads.js` consulta `window.f3baseConsentimento` para decidir se manda
 * a conversão a Meta e LinkedIn, se grava o `_fbc` e se guarda a atribuição — e
 * a AUSÊNCIA do objeto cai na decisão de reserva, que é PERMITIR. Sem a
 * dependência declarada, os dois eram só dois `defer` cuja ordem dependia da
 * posição no documento: um clique que chegasse antes do consentimento executar
 * disparava a conversão de quem tinha recusado.
 */
$GLOBALS['f3b_bench']['scripts'] = array();

F3Base_Options::gravar(
	'f3base_contato',
	array( 'whatsapp_e164' => '5511999999999' ),
	F3Base_Options::ORIGEM_MANUAL
);

( new F3Base_Modulo_Leads_Whatsapp() )->enfileirar();

afirmar(
	$nome,
	in_array( F3Base_Modulo_Consentimento::HANDLE, $GLOBALS['f3b_bench']['scripts'][ F3Base_Modulo_Leads_Whatsapp::HANDLE ]['deps'] ?? array(), true ),
	'piso do portão: o cliente do CTA não declara dependência do script de consentimento — o portão dele consulta um objeto que pode ainda não existir, e a ausência do objeto PERMITE'
);

/* ==========================================================================
 * leads.click_ids_no_schema
 *
 * O DEFEITO QUE ISTO IMPEDE: o schema do endpoint é FECHADO e recusa campo
 * desconhecido com 400 nomeando a chave. Acrescentar `gclid` só no cliente faria
 * TODO lead de tráfego pago voltar recusado — o pior modo de falhar que este
 * endpoint tem, porque falha exatamente no tráfego que foi pago.
 * ======================================================================= */

$nome = 'leads.click_ids_no_schema';

bancada_limpa();

$aceitos_na_atribuicao = F3Base_Modulo_Endpoint_Leads::campos_atribuicao();

foreach ( array( 'gclid', 'gbraid', 'wbraid', 'msclkid', 'fbclid', 'fbc', 'fbp', 'li_fat_id' ) as $chave_de_clique ) {
	afirmar(
		$nome,
		isset( $aceitos_na_atribuicao[ $chave_de_clique ] ),
		'teto do schema: ' . $chave_de_clique . ' não está no conjunto aceito de atribuicao, e o cliente que o enviar receberá 400 com o nome da chave'
	);
}

$resposta = postar(
	carga(
		array(
			'atribuicao' => array(
				'gclid'     => 'CjwKCAjw-bancada-de-teste',
				'fbclid'    => 'IwAR0bancadaDeTeste',
				'li_fat_id' => '4f8b1c2d-bancada',
				'msclkid'   => 'bancada0msclkid',
			),
		)
	)
);

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: lead com identificador de clique foi recusado com status ' . $resposta->status . ' e código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — é o lead de tráfego pago voltando 400 por causa do campo que o próprio pacote passou a enviar'
);

$atribuicao_gravada = (string) ( $GLOBALS['f3b_bench']['ultimo_post']['meta_input']['_f3base_atribuicao'] ?? '' );

afirmar(
	$nome,
	str_contains( $atribuicao_gravada, 'CjwKCAjw-bancada-de-teste' ) && str_contains( $atribuicao_gravada, 'IwAR0bancadaDeTeste' ),
	'teto da gravação: o identificador de clique foi aceito e não chegou ao registro do lead — aceitar sem gravar é perder a campanha que comprou o lead'
);

/* PISO: o conjunto continua FECHADO. Campo de fora segue recusado pelo nome. */
bancada_limpa();
$resposta = postar( carga( array( 'atribuicao' => array( 'ttclid' => 'de-outra-plataforma' ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'atribuicao.ttclid' === (string) ( $resposta->data['campo'] ?? '' ),
	'piso: chave fora do conjunto passou, ou a recusa não nomeou a chave — acrescentar campos não pode ter aberto o schema'
);

/* ==========================================================================
 * leads.capi_meta — teto e piso do evento de SERVIDOR da Meta
 * ======================================================================= */

/*
 * O DEFEITO MEDIDO, e ele era de metade faltando. A 1.1.0 já gerava o
 * `event_id` no clique e o mandava no `eventID` do Pixel — para deduplicar
 * contra um evento de servidor que NUNCA era enviado. O pacote pagava o preço
 * da deduplicação e não recebia a cobertura: o pixel de navegador é a metade
 * que iOS e bloqueadores cortam.
 *
 * Quatro pisos, e todos foram declarados antes de o código existir: com token o
 * payload leva o event_id DO NAVEGADOR e os hashes certos; sem token nada é
 * enviado; falha HTTP da Meta não muda o status do lead; e dado pessoal EM
 * CLARO no payload é achado.
 */

$nome = 'leads.capi_meta';

$email_conhecido    = 'Jose.Da.Silva@Exemplo.TEST';
$hash_esperado      = hash( 'sha256', 'jose.da.silva@exemplo.test' );
$telefone_conhecido = '+55 (11) 99999-0000';
$hash_do_telefone   = hash( 'sha256', '5511999990000' );

/* PISO: sem token, NADA é enviado e o motivo NOMEIA a option. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_IMPLANTADOR );

$resposta = postar(
	carga(
		array(
			'correlation_id' => 'correlacao-capi-sem-token',
			'email'          => $email_conhecido,
		)
	)
);

medir( $nome );

if ( array() !== $GLOBALS['f3b_bench']['agendados'] ) {
	anotar( $nome, 'piso: sem token gravado o envio de servidor foi agendado assim mesmo — o pacote passaria a falar com a Meta sem credencial de ninguém' );
}

medir( $nome );

if ( 201 !== $resposta->status ) {
	anotar( $nome, 'teto: sem token o lead deixou de ser aceito (status ' . $resposta->status . ') — a Conversions API não pode ter voto sobre o registro do lead' );
}

$carimbo_sem_token = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

medir( $nome );

if ( ! str_contains( (string) ( $carimbo_sem_token['meta_capi'] ?? '' ), F3Base_Modulo_Meta_Capi::OPTION_TOKEN ) ) {
	anotar( $nome, 'piso: a ausência de envio não NOMEOU a option que falta — "nada aconteceu" sem nome é indistinguível de "nada foi medido": ' . (string) ( $carimbo_sem_token['meta_capi'] ?? '' ) );
}

medir( $nome );

$estado_sem_token = ( new F3Base_Modulo_Meta_Capi() )->estado();

if ( F3Base_Modulo::INATIVO !== $estado_sem_token['estado'] || ! str_contains( $estado_sem_token['motivo'], F3Base_Modulo_Meta_Capi::OPTION_TOKEN ) ) {
	anotar( $nome, 'piso: sem token o módulo fechou "' . $estado_sem_token['estado'] . '" sem nomear a option — ' . $estado_sem_token['motivo'] );
}

/* PISO DA DEPENDÊNCIA: com token e SEM Pixel ID não há destino, e isso sai nomeado. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_meta_capi_token', 'TOKEN-DE-BANCADA', F3Base_Options::ORIGEM_MANUAL );

$resposta = postar( carga( array( 'correlation_id' => 'correlacao-capi-sem-pixel' ) ) );

medir( $nome );

if ( array() !== $GLOBALS['f3b_bench']['agendados'] ) {
	anotar( $nome, 'piso: com o Pixel ID vazio o envio foi agendado — o endpoint é /<pixel-id>/events e não existe destino a montar' );
}

medir( $nome );

$estado_sem_pixel = ( new F3Base_Modulo_Meta_Capi() )->estado();

if ( F3Base_Modulo::DEGRADADO !== $estado_sem_pixel['estado'] || ! str_contains( $estado_sem_pixel['motivo'], 'f3base_meta_pixel_id' ) ) {
	anotar( $nome, 'piso: com token e sem Pixel ID o módulo fechou "' . $estado_sem_pixel['estado'] . '" sem nomear a dependência — ' . $estado_sem_pixel['motivo'] );
}

/* TETO: com token e Pixel, o envio é agendado e o payload leva o event_id DO NAVEGADOR. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_meta_capi_token', 'TOKEN-DE-BANCADA', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_IMPLANTADOR );

$resposta = postar(
	carga(
		array(
			'correlation_id' => 'correlacao-capi-completa',
			'email'          => $email_conhecido,
			'telefone'       => $telefone_conhecido,
			'nome'           => 'Jose da Silva',
			'pagina'         => '/contato/',
			'atribuicao'     => array(
				'fbc' => 'fb.1.1700000000000.IwAR0bancada',
				'fbp' => 'fb.1.1700000000000.1234567890',
			),
		)
	)
);

medir( $nome );

if ( 201 !== $resposta->status ) {
	anotar( $nome, 'teto: o lead com token gravado voltou ' . $resposta->status . ' — o envio de servidor não pode mudar o status do lead' );
}

medir( $nome );

if ( 1 !== count( $GLOBALS['f3b_bench']['agendados'] ) ) {
	anotar( $nome, 'teto: com token e Pixel o envio não foi agendado exatamente uma vez (' . count( $GLOBALS['f3b_bench']['agendados'] ) . ')' );
}

$agendado = $GLOBALS['f3b_bench']['agendados'][0] ?? array( 'hook' => '', 'args' => array() );

medir( $nome );

if ( F3Base_Modulo_Meta_Capi::HOOK !== (string) $agendado['hook'] ) {
	anotar( $nome, 'teto: o evento agendado não é o hook do módulo — ' . (string) $agendado['hook'] );
}

/*
 * O PAYLOAD NÃO VIAJA NOS ARGUMENTOS DO EVENTO, e este é o piso da escolha do
 * meio: a option `cron` é AUTOLOAD, e cada lead pendente carregaria hashes, IP
 * e user agent em toda requisição do site até o evento rodar.
 */
medir( $nome );

$argumentos_json = (string) wp_json_encode( $agendado['args'] );

if ( str_contains( $argumentos_json, $hash_esperado ) || str_contains( $argumentos_json, '203.0.113.7' ) ) {
	anotar( $nome, 'piso: o payload viajou nos argumentos do evento agendado, e a option cron é autoload — todo lead pendente passaria a pesar em toda requisição do site: ' . $argumentos_json );
}

$record_id = (string) ( $resposta->data['record_id'] ?? '' );
$guardado  = get_transient( F3Base_Modulo_Meta_Capi::TRANSIENTE . $record_id );

medir( $nome );

if ( ! is_array( $guardado ) || ! isset( $guardado['data'][0] ) ) {
	anotar( $nome, 'teto: o payload não ficou guardado para o evento agendado consumir' );
}

$evento = is_array( $guardado ) && isset( $guardado['data'][0] ) ? $guardado['data'][0] : array();

/*
 * O `event_id` É O DO NAVEGADOR, e essa identidade é a regra inteira: gerar um
 * identificador novo aqui produziria dois eventos `Lead` na Meta em vez de um
 * deduplicado — conversão contada duas vezes, que reescreve o lance do leilão.
 */
medir( $nome );

if ( 'correlacao-capi-completa' !== (string) ( $evento['event_id'] ?? '' ) ) {
	anotar( $nome, 'piso: o event_id do payload NÃO é o correlation_id recebido do navegador ("' . (string) ( $evento['event_id'] ?? '' ) . '") — sem essa identidade a Meta conta o Lead duas vezes, uma por caminho' );
}

foreach ( array(
	'event_name'    => F3Base_Modulo_Meta_Capi::EVENTO,
	'action_source' => F3Base_Modulo_Meta_Capi::ACTION_SOURCE,
) as $campo_fechado => $esperado_fechado ) {
	medir( $nome );

	if ( $esperado_fechado !== (string) ( $evento[ $campo_fechado ] ?? '' ) ) {
		anotar( $nome, 'teto: ' . $campo_fechado . ' saiu como "' . (string) ( $evento[ $campo_fechado ] ?? '' ) . '" e a especificação da Meta fecha esse vocabulário' );
	}
}

medir( $nome );

if ( (int) ( $evento['event_time'] ?? 0 ) <= 0 ) {
	anotar( $nome, 'teto: event_time ausente ou zerado — sem ele a Meta não sabe quando a conversão aconteceu' );
}

medir( $nome );

if ( 'https://exemplo.test/contato/' !== (string) ( $evento['event_source_url'] ?? '' ) ) {
	anotar( $nome, 'teto: event_source_url não é a página do clique — ' . (string) ( $evento['event_source_url'] ?? '' ) );
}

$user = isset( $evento['user_data'] ) && is_array( $evento['user_data'] ) ? $evento['user_data'] : array();

medir( $nome );

if ( array( $hash_esperado ) !== ( $user['em'] ?? array() ) ) {
	anotar( $nome, 'piso: o hash do e-mail conhecido não bate com SHA-256 do valor normalizado pela regra da Meta (espaço fora, minúsculas) — ' . wp_json_encode( $user['em'] ?? null ) );
}

medir( $nome );

if ( array( $hash_do_telefone ) !== ( $user['ph'] ?? array() ) ) {
	anotar( $nome, 'piso: o hash do telefone não bate com SHA-256 dos dígitos com código de país e sem o "+" — ' . wp_json_encode( $user['ph'] ?? null ) );
}

foreach ( array( 'client_ip_address' => '203.0.113.7', 'fbc' => 'fb.1.1700000000000.IwAR0bancada', 'fbp' => 'fb.1.1700000000000.1234567890' ) as $campo_da_meta => $esperado_da_meta ) {
	medir( $nome );

	if ( $esperado_da_meta !== (string) ( $user[ $campo_da_meta ] ?? '' ) ) {
		anotar( $nome, 'teto: ' . $campo_da_meta . ' não chegou ao user_data — ele é a chave de correspondência que sobra quando o navegador não colabora' );
	}
}

/*
 * DADO PESSOAL EM CLARO NO PAYLOAD É FALHA, e a medição é sobre o payload
 * INTEIRO serializado: procurar campo a campo deixaria passar o dia em que
 * alguém acrescentasse um campo novo.
 */
$payload_serializado = (string) wp_json_encode( $guardado );

foreach ( array( $email_conhecido, 'jose.da.silva@exemplo.test', 'Jose da Silva', '99999-0000' ) as $em_claro ) {
	medir( $nome );

	if ( str_contains( $payload_serializado, $em_claro ) ) {
		anotar( $nome, 'FALHA de privacidade: "' . $em_claro . '" viajaria EM CLARO para a Meta. A especificação pede SHA-256 do valor normalizado, e o que a Meta não pede não sai daqui' );
	}
}

medir( $nome );

if ( 'Mozilla/5.0 (bancada)' !== (string) ( $user['client_user_agent'] ?? '' ) ) {
	anotar( $nome, 'teto: client_user_agent não chegou ao user_data' );
}

/*
 * PISO DO IP QUE NÃO É IP: `origem()` devolve a palavra `desconhecida` quando o
 * servidor não informa `REMOTE_ADDR`, e mandar essa palavra no campo de
 * endereço seria inventar um dado de correspondência.
 */
$payload_sem_ip = F3Base_Modulo_Meta_Capi::montar_payload(
	array(
		'correlation_id' => 'correlacao-sem-ip',
		'email'          => '',
		'telefone'       => '',
		'atribuicao'     => array(),
	),
	'desconhecida',
	'',
	'',
	time()
);

medir( $nome );

if ( array_key_exists( 'client_ip_address', $payload_sem_ip['data'][0]['user_data'] ) ) {
	anotar( $nome, 'piso: a palavra "desconhecida" foi enviada como client_ip_address — lixo com cara de endereço casa, ou deixa de casar, por um motivo que ninguém escreveu' );
}

/*
 * PISO DO TELEFONE SEM PAÍS: a Meta pede dígitos COM código de país, e
 * completar o país pelo idioma do site inventaria um telefone que ninguém
 * digitou. Sem o prefixo, o campo simplesmente não vai.
 */
medir( $nome );

if ( '' !== F3Base_Modulo_Meta_Capi::hash_telefone( '11999990000' ) ) {
	anotar( $nome, 'piso: um telefone SEM código de país foi hasheado assim mesmo — adivinhar o país pelo idioma do site é inventar um número' );
}

/* TETO DO ENVIO: a resposta aceita vira carimbo com HTTP, events_received e fbtrace_id. */
$envio = F3Base_Modulo_Meta_Capi::enviar( $record_id );

medir( $nome );

if ( ! $envio['ok'] || 200 !== $envio['http'] ) {
	anotar( $nome, 'teto: o envio aceito não fechou ok — HTTP ' . $envio['http'] . ' ' . $envio['motivo'] );
}

$carimbo_capi = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_CAPI );

foreach ( array( 'http' => 200, 'events_received' => 1 ) as $campo_do_carimbo => $esperado_do_carimbo ) {
	medir( $nome );

	if ( $esperado_do_carimbo !== ( $carimbo_capi[ $campo_do_carimbo ] ?? null ) ) {
		anotar( $nome, 'teto: o carimbo do envio aceito não registrou ' . $campo_do_carimbo . ' — resultado que não é registrado é resultado que ninguém confere' );
	}
}

medir( $nome );

if ( 'A0-bancada' !== (string) ( $carimbo_capi['fbtrace_id'] ?? '' ) ) {
	anotar( $nome, 'teto: o fbtrace_id da Meta não foi registrado, e é ele que o suporte da Meta pede quando um evento não aparece' );
}

/*
 * O TOKEN VAI NO CORPO, NUNCA NA URL: segredo em URL entra em log de proxy, de
 * CDN e de servidor — lugares que ninguém audita.
 */
$requisicao = $GLOBALS['f3b_bench']['http']['requisicao'];

medir( $nome );

if ( str_contains( (string) ( $requisicao['url'] ?? '' ), 'TOKEN-DE-BANCADA' ) ) {
	anotar( $nome, 'piso: o token de acesso saiu na URL da chamada — segredo em URL é segredo copiado para todo log do caminho' );
}

medir( $nome );

if ( ! str_contains( (string) ( $requisicao['url'] ?? '' ), '/123456789012345/events' ) ) {
	anotar( $nome, 'teto: o endereço de destino não é montado do Pixel ID gravado — ' . (string) ( $requisicao['url'] ?? '' ) );
}

/* PISO DA FALHA DA META: o lead já está gravado, e recusa de lá não muda nada aqui. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_meta_capi_token', 'TOKEN-DE-BANCADA', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_IMPLANTADOR );

$resposta = postar( carga( array( 'correlation_id' => 'correlacao-capi-recusada', 'email' => $email_conhecido ) ) );
$record_id_recusado = (string) ( $resposta->data['record_id'] ?? '' );

$GLOBALS['f3b_bench']['http']['resposta'] = array(
	'codigo' => 400,
	'corpo'  => '{"error":{"message":"Invalid parameter","fbtrace_id":"A1-bancada"}}',
	'erro'   => '',
);

$envio_recusado = F3Base_Modulo_Meta_Capi::enviar( $record_id_recusado );

medir( $nome );

if ( $envio_recusado['ok'] || 400 !== $envio_recusado['http'] ) {
	anotar( $nome, 'piso: a recusa da Meta não foi reconhecida como recusa — ' . wp_json_encode( $envio_recusado ) );
}

medir( $nome );

if ( 201 !== $resposta->status || true !== ( $resposta->data['registrado'] ?? false ) ) {
	anotar( $nome, 'piso: a resposta do lead mudou por causa da Meta — o lead foi gravado ANTES do envio e a Meta não tem voto sobre ele' );
}

medir( $nome );

if ( 1 !== linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME ) ) {
	anotar( $nome, 'piso: a recusa da Meta mexeu na reserva de deduplicação do lead — a transação lógica do lead terminou antes, e nada de lá pode desfazê-la' );
}

$carimbo_recusa = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_CAPI );

medir( $nome );

if ( 400 !== ( $carimbo_recusa['http'] ?? null ) || ! str_contains( (string) ( $carimbo_recusa['motivo'] ?? '' ), 'Invalid parameter' ) ) {
	anotar( $nome, 'piso: a recusa da Meta não saiu NOMEADA na atividade, com código HTTP e mensagem — recusa que some é indistinguível de recusa que nunca aconteceu' );
}

medir( $nome );

$estado_recusado = ( new F3Base_Modulo_Meta_Capi() )->estado();

if ( F3Base_Modulo::DEGRADADO !== $estado_recusado['estado'] ) {
	anotar( $nome, 'teto: com a recusa mais recente sem aceite depois dela o módulo fechou "' . $estado_recusado['estado'] . '"' );
}

/* PISO DO PAYLOAD EXPIRADO: sem transiente, nada é enviado e o motivo sai nomeado. */
$GLOBALS['f3b_bench']['http']['chamadas'] = 0;
$envio_orfao = F3Base_Modulo_Meta_Capi::enviar( 'record-que-nao-existe' );

medir( $nome );

if ( $envio_orfao['ok'] || 0 !== $GLOBALS['f3b_bench']['http']['chamadas'] ) {
	anotar( $nome, 'piso: sem payload guardado a chamada à Meta aconteceu assim mesmo — enviar um corpo vazio é pior que não enviar' );
}

/* ==========================================================================
 * verificacao.tag_do_valor_gravado — teto e piso das metatags de domínio
 * ======================================================================= */

/*
 * O BURACO MEDIDO: zero ocorrências de `google-site-verification` e de
 * `facebook-domain-verification` no pacote inteiro. As duas são o passo que
 * autoriza a operação a mexer no que este pacote já emite, e elas eram passo
 * humano no console E passo humano no HTML — o segundo não precisava ser.
 */

$nome = 'verificacao.tag_do_valor_gravado';

/* PISO DO SLOT VAZIO: sem valor, NENHUMA tag existe e o módulo fecha inativo nomeando as options. */
bancada_limpa();

medir( $nome );

if ( '' !== F3Base_Modulo_Verificacao_Dominio::markup( F3Base_Modulo_Verificacao_Dominio::tokens() ) ) {
	anotar( $nome, 'piso: com as duas options vazias saiu markup no <head> — slot vazio é inerte, e uma metatag de verificação com conteúdo vazio é uma reivindicação de posse que não fecha' );
}

medir( $nome );

$estado_verificacao = ( new F3Base_Modulo_Verificacao_Dominio() )->estado();

if ( F3Base_Modulo::INATIVO !== $estado_verificacao['estado'] ) {
	anotar( $nome, 'piso: com as duas options vazias o módulo fechou "' . $estado_verificacao['estado'] . '"' );
}

foreach ( array_keys( F3Base_Modulo_Verificacao_Dominio::tags() ) as $option_vazia ) {
	medir( $nome );

	if ( ! str_contains( $estado_verificacao['motivo'], $option_vazia ) ) {
		anotar( $nome, 'piso: o estado inativo não NOMEIA a option ' . $option_vazia . ' que falta preencher' );
	}
}

medir( $nome );

if ( ( new F3Base_Modulo_Verificacao_Dominio() )->deve_registrar() ) {
	anotar( $nome, 'piso: com os dois slots vazios o módulo registraria o hook de wp_head — módulo inativo é inerte' );
}

/* TETO: com valor gravado, a tag existe com o valor gravado e só ela. */
bancada_limpa();
F3Base_Options::gravar( 'f3base_verificacao_google', 'abc123_DEF-456', F3Base_Options::ORIGEM_IMPLANTADOR );

$markup = F3Base_Modulo_Verificacao_Dominio::markup( F3Base_Modulo_Verificacao_Dominio::tokens() );

medir( $nome );

if ( ! str_contains( $markup, '<meta name="google-site-verification" content="abc123_DEF-456" />' ) ) {
	anotar( $nome, 'teto: a metatag do Google não saiu com o valor gravado — ' . $markup );
}

medir( $nome );

if ( str_contains( $markup, 'facebook-domain-verification' ) ) {
	anotar( $nome, 'piso: a metatag da Meta saiu com a option dela VAZIA — cada slot responde só por si' );
}

medir( $nome );

if ( array() !== ( new F3Base_Modulo_Verificacao_Dominio() )->avisos() ) {
	anotar( $nome, 'piso do ramo adverso: valor DENTRO da forma produziu aviso, e WARN só sai com achado adverso' );
}

/* TETO DOS DOIS: cada option preenchida emite a sua tag, e só a sua. */
F3Base_Options::gravar( 'f3base_verificacao_meta', 'zz99meta', F3Base_Options::ORIGEM_IMPLANTADOR );

$markup_dois = F3Base_Modulo_Verificacao_Dominio::markup( F3Base_Modulo_Verificacao_Dominio::tokens() );

foreach ( array( 'google-site-verification" content="abc123_DEF-456', 'facebook-domain-verification" content="zz99meta' ) as $par_esperado ) {
	medir( $nome );

	if ( ! str_contains( $markup_dois, $par_esperado ) ) {
		anotar( $nome, 'teto: falta o par ' . $par_esperado . ' no markup emitido' );
	}
}

/*
 * PISO DA PRESERVAÇÃO: valor com caractere fora do que a tag aceita continua
 * gravado, continua sendo emitido ESCAPADO, e sai um WARN nomeando a forma.
 * Apagar em silêncio é o que este pacote parou de fazer na 1.1.0.
 */
bancada_limpa();
F3Base_Options::gravar( 'f3base_verificacao_google', 'valor "com aspas" e espaco', F3Base_Options::ORIGEM_MANUAL );

medir( $nome );

if ( 'valor "com aspas" e espaco' !== (string) F3Base_Options::ler( 'f3base_verificacao_google' ) ) {
	anotar( $nome, 'piso: o valor fora da forma foi ALTERADO pela sanitização — apagar em silêncio é exatamente o que esta release parou de fazer: ' . (string) F3Base_Options::ler( 'f3base_verificacao_google' ) );
}

$avisos_verificacao = ( new F3Base_Modulo_Verificacao_Dominio() )->avisos();

medir( $nome );

if ( 1 !== count( $avisos_verificacao ) || 'WARN' !== (string) ( $avisos_verificacao[0]['estado'] ?? '' ) ) {
	anotar( $nome, 'piso: o valor fora da forma não produziu exatamente um WARN — ' . wp_json_encode( $avisos_verificacao ) );
}

foreach ( array( 'f3base_verificacao_google', 'google-site-verification', F3Base_Modulo_Verificacao_Dominio::FORMA_DIZ ) as $trecho_do_aviso ) {
	medir( $nome );

	if ( ! str_contains( (string) ( $avisos_verificacao[0]['motivo'] ?? '' ), $trecho_do_aviso ) ) {
		anotar( $nome, 'piso: o aviso não nomeia "' . $trecho_do_aviso . '" — aviso sem o nome da chave e da forma esperada não diz o que fazer' );
	}
}

$markup_estranho = F3Base_Modulo_Verificacao_Dominio::markup( F3Base_Modulo_Verificacao_Dominio::tokens() );

medir( $nome );

if ( str_contains( $markup_estranho, 'content="valor "com aspas"' ) ) {
	anotar( $nome, 'piso: o valor com aspas saiu SEM escape e quebrou o atributo — preservar não é imprimir cru' );
}

medir( $nome );

if ( ! str_contains( $markup_estranho, 'valor &quot;com aspas&quot; e espaco' ) ) {
	anotar( $nome, 'teto: o valor preservado não saiu escapado no atributo — ' . $markup_estranho );
}

medir( $nome );

if ( F3Base_Modulo::ATIVO !== ( new F3Base_Modulo_Verificacao_Dominio() )->estado()['estado'] ) {
	anotar( $nome, 'teto: com um token gravado o módulo não fechou ativo — aviso não é estado, e valor fora da forma continua sendo emitido' );
}

/* ==========================================================================
 * conteudo.demonstrativo_no_site — teto e piso do censo no BANCO
 * ======================================================================= */

/*
 * O DEFEITO MEDIDO E PERMANENTE: `conteudo.demonstrativo` mora no arquivo
 * único, o agente troca o conteúdo pelo canal e nunca toca nele — a flag fica
 * `true` para sempre e o aviso sobrevive ao template ter sumido inteiro. A
 * pergunta passa a ser feita ao BANCO, pela marca que já viaja dentro de cada
 * página publicada desde a 1.0.15.
 */

$nome = 'conteudo.demonstrativo_no_site';

$marca_da_bancada = F3Base_Censo_Demonstrativo::marca( F3BASE_PREFIXO );

medir( $nome );

if ( 'f3base:conteudo-demonstrativo' !== $marca_da_bancada ) {
	anotar( $nome, 'a marca não é montada do PREFIXO declarado: uma marca literal aqui seria a marca do template sobrevivendo dentro do site do cliente — ' . $marca_da_bancada );
}

/*
 * A FIXTURE: uma página publicada AINDA MARCADA e outra já substituída. O teto
 * exige o WARN nomeando só a primeira; nomear a segunda seria acusar o trabalho
 * que o agente já fez.
 */
bancada_limpa();

$GLOBALS['f3b_bench']['paginas'] = array(
	array(
		'ID'           => 11,
		'post_title'   => 'Como esta operação constrói sites',
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_content' => '<!-- ' . $marca_da_bancada . ' — arquivo do site demonstrativo -->' . "\n" . '<p>prosa do método</p>',
	),
	array(
		'ID'           => 12,
		'post_title'   => 'Serviços do cliente',
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_content' => '<p>texto que o agente escreveu pelo canal</p>',
	),
);

$censo = F3Base_Censo_Demonstrativo::medir( F3BASE_PREFIXO, true );

medir( $nome );

if ( 'WARN' !== $censo['estado'] ) {
	anotar( $nome, 'teto: com uma página publicada ainda marcada o censo fechou "' . $censo['estado'] . '" — o site do template no ar com o endereço de outra pessoa é achado adverso' );
}

medir( $nome );

if ( 1 !== $censo['marcadas'] ) {
	anotar( $nome, 'teto: o censo contou ' . $censo['marcadas'] . ' página(s) marcada(s) onde a fixture tem exatamente uma' );
}

medir( $nome );

if ( ! str_contains( $censo['motivo'], 'Como esta operação constrói sites' ) ) {
	anotar( $nome, 'teto: o aviso não NOMEIA a página que ainda carrega a marca — contagem sem nome não responde à pergunta do operador, que é "quais?"' );
}

medir( $nome );

if ( str_contains( $censo['motivo'], 'Serviços do cliente' ) ) {
	anotar( $nome, 'piso: o aviso nomeou a página JÁ SUBSTITUÍDA — acusar o trabalho que o agente já fez é o defeito que este censo existe para não repetir' );
}

medir( $nome );

if ( 2 !== $censo['medidas'] ) {
	anotar( $nome, 'teto: o denominador não é o total de páginas publicadas (' . $censo['medidas'] . ') — sem ele "nenhuma marcada" é indistinguível de "nenhuma medida"' );
}

/*
 * PISO DA FLAG: com NENHUMA página marcada e a flag ainda `true` — que é o
 * estado permanente de todo site que o agente substituiu pelo canal — a regra
 * precisa CALAR. Era exatamente aqui que o aviso ficava preso para sempre.
 */
$GLOBALS['f3b_bench']['paginas'] = array(
	array(
		'ID'           => 21,
		'post_title'   => 'Home do cliente',
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_content' => '<p>tudo substituído pelo canal</p>',
	),
);

$censo_limpo = F3Base_Censo_Demonstrativo::medir( F3BASE_PREFIXO, true );

medir( $nome );

if ( 'OK' !== $censo_limpo['estado'] ) {
	anotar( $nome, 'piso: com zero páginas marcadas e a flag em true o censo continuou avisando ("' . $censo_limpo['estado'] . '") — é o WARN preso para sempre que esta regra existe para desarmar' );
}

medir( $nome );

if ( 0 !== $censo_limpo['marcadas'] || 1 !== $censo_limpo['medidas'] ) {
	anotar( $nome, 'piso: a contagem do caso limpo saiu errada — marcadas ' . $censo_limpo['marcadas'] . ', medidas ' . $censo_limpo['medidas'] );
}

/*
 * PISO DO RASCUNHO: página NÃO publicada com a marca não conta. O aviso é sobre
 * o que está NO AR — um rascunho do template não põe a prosa do método no
 * endereço de ninguém.
 */
$GLOBALS['f3b_bench']['paginas'][] = array(
	'ID'           => 22,
	'post_title'   => 'Rascunho do template',
	'post_type'    => 'page',
	'post_status'  => 'draft',
	'post_content' => '<!-- ' . $marca_da_bancada . ' -->',
);

$censo_rascunho = F3Base_Censo_Demonstrativo::medir( F3BASE_PREFIXO, true );

medir( $nome );

if ( 0 !== $censo_rascunho['marcadas'] ) {
	anotar( $nome, 'piso: um rascunho com a marca entrou na contagem — a medição é do que está PUBLICADO, e um rascunho não está no ar' );
}


/*
 * QUEM ESCREVEU A PÁGINA MARCADA — a correção da 1.1.7. O log de produção dizia
 * "7 de 9 página(s) publicada(s) ainda carrega(m) a marca", e as sete tinham
 * sido publicadas por AQUELA MESMA execução, minutos antes, porque publicar o
 * conteúdo declarado é o que o implantador faz: a unidade `entrega` fechava
 * WARN por ter cumprido o próprio desenho.
 *
 * TETO: toda página marcada escrita por quem está medindo => OK, nomeando-as.
 * PISO: sobra página marcada que quem mede NÃO escreveu => WARN nomeando só
 * ela. E o padrão VAZIO — a chamada do site-core na cadência, em que ninguém
 * escreveu nada — continua avisando, que é onde a pergunta vale.
 */
bancada_limpa();

$GLOBALS['f3b_bench']['paginas'] = array(
	array(
		'ID'           => 31,
		'post_title'   => 'Home recém-implantada',
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_content' => '<!-- ' . $marca_da_bancada . ' -->' . "\n" . '<p>prosa do método</p>',
	),
	array(
		'ID'           => 32,
		'post_title'   => 'Arquitetura recém-implantada',
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_content' => '<!-- ' . $marca_da_bancada . ' -->' . "\n" . '<p>prosa do método</p>',
	),
);

$censo_recem = F3Base_Censo_Demonstrativo::medir( F3BASE_PREFIXO, true, array( 31, 32 ) );

medir( $nome );

if ( 'OK' !== $censo_recem['estado'] ) {
	anotar( $nome, 'teto: as duas páginas marcadas foram escritas por ESTA execução e o censo fechou "' . $censo_recem['estado'] . '" — o instrumento estaria acusando o trabalho que ele mesmo acabou de fazer' );
}

medir( $nome );

if ( 2 !== $censo_recem['recem_publicadas'] || 0 !== $censo_recem['sobreviventes'] ) {
	anotar( $nome, 'teto: a separação por quem escreveu saiu errada — recém-publicadas ' . $censo_recem['recem_publicadas'] . ', sobreviventes ' . $censo_recem['sobreviventes'] );
}

foreach ( array( 'Home recém-implantada', 'Arquitetura recém-implantada', 'acabou de ser implantado' ) as $trecho_recem ) {
	medir( $nome );

	if ( ! str_contains( $censo_recem['motivo'], $trecho_recem ) ) {
		anotar( $nome, 'teto: o ramo OK não traz "' . $trecho_recem . '" — o conteúdo do template no ar precisa sair NOMEADO mesmo quando não é achado' );
	}
}

/*
 * PISO: a MESMA fixture, com só uma das duas escrita por esta execução. O aviso
 * volta, e nomeia SÓ a que sobreviveu.
 */
$censo_sobrevivente = F3Base_Censo_Demonstrativo::medir( F3BASE_PREFIXO, true, array( 31 ) );

medir( $nome );

if ( 'WARN' !== $censo_sobrevivente['estado'] ) {
	anotar( $nome, 'piso: uma página marcada que esta execução NÃO escreveu fechou "' . $censo_sobrevivente['estado'] . '" — texto de template que sobreviveu a quem deveria tê-lo substituído é achado adverso com dono e ação' );
}

medir( $nome );

if ( 1 !== $censo_sobrevivente['sobreviventes'] || 1 !== $censo_sobrevivente['recem_publicadas'] ) {
	anotar( $nome, 'piso: a separação saiu errada no caso misto — sobreviventes ' . $censo_sobrevivente['sobreviventes'] . ', recém-publicadas ' . $censo_sobrevivente['recem_publicadas'] );
}

medir( $nome );

if ( ! str_contains( $censo_sobrevivente['motivo'], 'Arquitetura recém-implantada' ) ) {
	anotar( $nome, 'piso: o aviso não NOMEIA a página que sobreviveu — contagem sem nome não responde à pergunta do operador' );
}

medir( $nome );

if ( str_contains( $censo_sobrevivente['motivo'], 'Home recém-implantada' ) ) {
	anotar( $nome, 'piso: o aviso nomeou a página que ESTA execução acabou de escrever — acusar o próprio trabalho é o defeito que esta discriminação existe para não repetir' );
}

/*
 * PISO DO PADRÃO VAZIO, e é ele que mantém a regra útil no site-core: sem
 * conjunto de escritas — a cadência, um mês depois — toda página marcada volta
 * a ser achado. Silenciar aqui apagaria a única pergunta que sobra: o texto do
 * template ainda está no ar?
 */
$censo_da_cadencia = F3Base_Censo_Demonstrativo::medir( F3BASE_PREFIXO, null );

medir( $nome );

if ( 'WARN' !== $censo_da_cadencia['estado'] || 2 !== $censo_da_cadencia['sobreviventes'] ) {
	anotar( $nome, 'piso: sem conjunto de escritas o censo deixou de avisar ("' . $censo_da_cadencia['estado'] . '") — é a chamada do site-core na cadência, e ali ninguém escreveu nada' );
}

/* PISO DO ESCOPO: sem prefixo não há marca, e "nada encontrado" seria mentira. */
$censo_sem_prefixo = F3Base_Censo_Demonstrativo::medir( '', true );

medir( $nome );

if ( 'WARN' !== $censo_sem_prefixo['estado'] || ! str_contains( $censo_sem_prefixo['motivo'], 'não aconteceu' ) ) {
	anotar( $nome, 'piso: sem prefixo declarado o censo aprovou por não ter medido nada — escopo vazio não aprova' );
}



/* ==========================================================================
 * llms.txt — as sete perguntas do arquivo, cada uma com teto e piso
 * ======================================================================= */

/**
 * Grava a configuração do llms.txt na bancada, pelo gravador único.
 *
 * @param array<string,mixed> $chaves Chaves declaradas.
 * @return void
 */
function f3b_llms_config( array $chaves ): void {
	F3Base_Options::gravar(
		'f3base_llms',
		array_merge(
			array(
				'ligado'               => true,
				'introducao'           => '',
				'apresentacao'         => '',
				'modo'                 => F3Base_Llms::MODO_MISTO,
				'tipos'                => array( 'page', 'post' ),
				'full'                 => false,
				'indexavel'            => true,
				'politica_privacidade' => array(),
				'livres'               => array(),
			),
			$chaves
		),
		F3Base_Options::ORIGEM_IMPLANTADOR
	);
}

/**
 * Declara um conteúdo publicado na bancada, com meta e corpo.
 *
 * @param int                 $id       Identificador.
 * @param string              $titulo   Título.
 * @param string              $tipo     Tipo.
 * @param string              $data     Data GMT.
 * @param string              $conteudo Corpo.
 * @param string              $resumo   Resumo declarado.
 * @param array<string,string> $metas   Metas do plugin de SEO.
 * @return void
 */
function f3b_llms_conteudo( int $id, string $titulo, string $tipo, string $data, string $conteudo, string $resumo = '', array $metas = array() ): void {
	$post = new WP_Post();

	$post->ID            = $id;
	$post->post_title    = $titulo;
	$post->post_type     = $tipo;
	$post->post_status   = 'publish';
	$post->post_date_gmt = $data;
	$post->post_content  = $conteudo;
	$post->post_excerpt  = $resumo;

	$GLOBALS['f3b_bench']['conteudo'][]     = $post;
	$GLOBALS['f3b_bench']['metas'][ $id ]   = $metas;
}

/* ---------- seo.llms_emissor_unico ---------- */

/*
 * UM ENDEREÇO, UM DONO. A precedência é declarada: arquivo físico na raiz vence,
 * emissor concorrente medido vem em seguida, e só então a nossa rota. É a mesma
 * regra de tracking.emissor_unico, e o motivo é o mesmo: duas respostas para a
 * mesma URL é o defeito, e quem cala é quem chegou depois.
 *
 * TETO: sem arquivo e sem concorrente, a rota serve.
 * PISO: com o plugin de SEO publicando o arquivo, a rota NÃO serve e o motivo
 * NOMEIA o outro emissor.
 */
$nome = 'seo.llms_emissor_unico';

$sozinho = F3Base_Llms::veredito_do_emissor( false, '', false, '' );

afirmar( $nome, true === $sozinho['serve'], 'teto: sem arquivo físico e sem concorrente a rota deixou de servir — o endereço ficaria sem dono nenhum' );
afirmar( $nome, F3Base_Llms::QUEM_NOSSA_ROTA === $sozinho['quem'], 'teto: quem responde saiu como "' . $sozinho['quem'] . '"' );

$com_concorrente = F3Base_Llms::veredito_do_emissor( false, '', true, 'o plugin de SEO, pela chave enable_llms_txt' );

afirmar( $nome, false === $com_concorrente['serve'], 'piso: com um emissor concorrente medido a rota continuou servindo — duas respostas para a mesma URL é exatamente o defeito' );
afirmar( $nome, F3Base_Llms::QUEM_CONCORRENTE === $com_concorrente['quem'], 'piso: quem responde saiu como "' . $com_concorrente['quem'] . '" em vez do concorrente' );
afirmar( $nome, str_contains( $com_concorrente['motivo'], 'enable_llms_txt' ), 'piso: o motivo não NOMEIA o outro emissor — aviso sem nome não diz onde desligar' );

/* PRECEDÊNCIA: o arquivo físico vence até o concorrente. */
$com_arquivo = F3Base_Llms::veredito_do_emissor( true, '/var/www/llms.txt', true, 'o plugin de SEO' );

afirmar( $nome, F3Base_Llms::QUEM_ARQUIVO === $com_arquivo['quem'] && false === $com_arquivo['serve'], 'piso da precedência: com arquivo físico e concorrente ao mesmo tempo, quem responde tem de ser o arquivo' );

/* E o módulo LÊ essa medição em vez de decidir por conta própria. */
bancada_limpa();
$GLOBALS['f3b_bench']['conteudo'] = array();
$GLOBALS['f3b_bench']['metas']    = array();
f3b_llms_conteudo( 5, 'Home', 'page', '2026-09-10', 'Apresentação pública' );
f3b_llms_config( array( 'livres' => array( array( 'id' => 5, 'titulo' => 'Home', 'url' => 'https://exemplo.test/' ) ) ) );

$estado_sozinho = ( new F3Base_Modulo_Llms_Txt_Reserva() )->estado();

afirmar( $nome, F3Base_Modulo::ATIVO === $estado_sozinho['estado'], 'teto: sem concorrente o módulo não fechou ativo — ' . $estado_sozinho['motivo'] );

/*
 * O EMISSOR CONCORRENTE PRECISA DAS DUAS METADES: a chave gravada E o plugin
 * ATIVO. Declarar só a chave aqui mediria a option ÓRFÃ — a que sobrevive à
 * desativação do Yoast —, que é justamente o caso em que o endereço deixou de
 * ser cedido. Quem prova esse recorte é `seo.llms_emissor_cruza_plugin`.
 */
$GLOBALS['f3b_bench']['options']['wpseo']          = array( 'enable_llms_txt' => true );
$GLOBALS['f3b_bench']['options']['active_plugins'] = array( F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO ) . '/wp-seo.php' );
requisicao_nova();

$estado_com_concorrente = ( new F3Base_Modulo_Llms_Txt_Reserva() )->estado();

afirmar( $nome, str_contains( $estado_com_concorrente['motivo'], 'EMISSOR CONCORRENTE MEDIDO' ), 'piso: com o plugin de SEO publicando o arquivo, o estado do módulo não declara o emissor concorrente — ' . $estado_com_concorrente['motivo'] );
afirmar( $nome, false === F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'], 'piso: o módulo continuaria servindo com o concorrente ligado' );

$GLOBALS['f3b_bench']['options']['wpseo']          = array();
$GLOBALS['f3b_bench']['options']['active_plugins'] = array();
requisicao_nova();

/* ---------- seo.llms_noindex_respeitado ---------- */

/*
 * O QUE ESTÁ EM NOINDEX NÃO ENTRA NO ARQUIVO, e o fato tem UM produtor:
 * F3Base_Modulo_Noindex_Honrado. O módulo do llms.txt pergunta a ele em vez de
 * ler a meta por conta própria — dois leitores da mesma chave é como uma
 * exclusão passa a nunca disparar sem que nada acuse.
 *
 * TETO: sem noindex, a página entra nos dois arquivos.
 * PISO: marcar a página como noindex tira-a dos dois.
 */
$nome = 'seo.llms_noindex_respeitado';

$fonte_do_llms = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-llms.php' );
$fonte_do_modulo_llms = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-llms-txt-reserva.php' );

afirmar(
	$nome,
	str_contains( $fonte_do_llms, 'F3Base_Modulo_Noindex_Honrado::post_e_noindex(' ),
	'teto: a seleção do llms.txt não PERGUNTA ao módulo de noindex — sem isso ela decidiria o mesmo fato por conta própria'
);

foreach ( array( $fonte_do_llms, $fonte_do_modulo_llms ) as $indice_da_fonte => $fonte_medida ) {
	afirmar(
		$nome,
		! str_contains( $fonte_medida, 'meta-robots-noindex' ),
		'piso do segundo leitor: o arquivo ' . ( 0 === $indice_da_fonte ? 'da regra' : 'do módulo' ) . ' do llms.txt escreve a chave de meta do noindex por conta própria — um segundo leitor do mesmo fato é como a exclusão passa a nunca disparar'
	);
}

/*
 * QUEM ESCREVE E QUEM LÊ COMPARTILHAM FONTE, e deste par só o LEITOR mora
 * aqui. O implantador ESCREVE a meta de cada conteúdo e o site-core a LÊ;
 * enquanto os dois não saíam do mesmo vocabulário, uma renomeação do fornecedor
 * quebrava cada um no seu lugar, sem erro e sem aviso.
 *
 * AS DUAS AFIRMAÇÕES SOBRE O GRAVADOR FICARAM NO IMPLANTADOR — elas liam
 * `includes/class-f3base-imp-seo.php`, que é arquivo dele. O que sobra aqui é a
 * metade que este repositório pode medir e é dona: que as constantes do módulo
 * de noindex SAEM do vocabulário compartilhado, e que o conjunto declarado de
 * metas de conteúdo contém as duas que os dois lados tocam. É o mesmo contrato,
 * medido do lado que o publica — `partilhado/class-f3base-chaves-seo.php`
 * viajou para dentro da fonte deste plugin justamente por isso.
 */
afirmar(
	$nome,
	F3Base_Chaves_Seo::NOINDEX === F3Base_Modulo_Noindex_Honrado::META_NOINDEX
		&& F3Base_Chaves_Seo::DESCRICAO === F3Base_Modulo_Noindex_Honrado::META_DESCRICAO,
	'piso da fonte comum: as constantes do módulo de noindex deixaram de sair do vocabulário compartilhado — duas declarações do mesmo nome divergem na primeira renomeação'
);

afirmar(
	$nome,
	in_array( F3Base_Chaves_Seo::NOINDEX, F3Base_Chaves_Seo::metas_de_conteudo(), true )
		&& in_array( F3Base_Chaves_Seo::DESCRICAO, F3Base_Chaves_Seo::metas_de_conteudo(), true ),
	'teto da fonte comum: o conjunto declarado de metas de conteúdo não contém as duas que os dois lados tocam'
);

/* A REGRA PURA do noindex, nos três ramos. */
afirmar( $nome, 'noindex' === F3Base_Modulo_Noindex_Honrado::decidir_por_post( '1', false ), 'piso: a meta que manda não indexar não produziu noindex' );
afirmar( $nome, 'index' === F3Base_Modulo_Noindex_Honrado::decidir_por_post( '2', true ), 'teto: a meta que manda indexar não venceu o padrão do tipo — quem escreveu a meta decidiu depois' );
afirmar( $nome, 'noindex' === F3Base_Modulo_Noindex_Honrado::decidir_por_post( '', true ), 'piso: o padrão do tipo que manda não indexar foi ignorado' );
afirmar( $nome, 'default' === F3Base_Modulo_Noindex_Honrado::decidir_por_post( '', false ), 'teto: sem meta e sem padrão a decisão deixou de ser do WordPress' );

/* E a SELEÇÃO honra o fato medido, nos dois arquivos. */
$candidatos = array(
	array( 'id' => 11, 'titulo' => 'Página aberta', 'url' => 'https://exemplo.test/a/', 'tipo' => 'page', 'data' => '2026-01-02', 'origem' => F3Base_Llms::ORIGEM_AUTOMATICO, 'noindex' => false ),
	array( 'id' => 12, 'titulo' => 'Página fora de índice', 'url' => 'https://exemplo.test/b/', 'tipo' => 'page', 'data' => '2026-01-03', 'origem' => F3Base_Llms::ORIGEM_AUTOMATICO, 'noindex' => true ),
);

$selecao_com_noindex = F3Base_Llms::selecionar( array(), $candidatos, array() );
$ids_selecionados    = array_map( static fn ( array $item ): int => (int) $item['id'], $selecao_com_noindex['itens'] );

afirmar( $nome, in_array( 11, $ids_selecionados, true ), 'teto: a página sem noindex ficou fora da seleção' );
afirmar( $nome, ! in_array( 12, $ids_selecionados, true ), 'piso: a página marcada como noindex ENTROU no arquivo — a exclusão não disparou' );
afirmar( $nome, array( 12 ) === $selecao_com_noindex['excluidos']['noindex'], 'piso: a exclusão por noindex não sai NOMEADA por ID' );

/* DEDUPE POR ID, e não por URL: URL muda quando o slug muda. */
$curado_igual = array( array( 'id' => 11, 'titulo' => 'Página aberta', 'url' => 'https://exemplo.test/endereco-antigo/', 'tipo' => 'page', 'origem' => F3Base_Llms::ORIGEM_CURADO, 'noindex' => false ) );
$selecao_dedupe = F3Base_Llms::selecionar( $curado_igual, $candidatos, array() );

afirmar( $nome, 1 === count( array_filter( $selecao_dedupe['itens'], static fn ( array $i ): bool => 11 === (int) $i['id'] ) ), 'piso do dedupe: o mesmo conteúdo saiu duas vezes porque a URL mudou — o dedupe é por ID' );

/* A EXCLUSÃO DECLARADA continua valendo no eixo automático. */
$selecao_declarada = F3Base_Llms::selecionar( array(), $candidatos, array( 11 ) );

afirmar( $nome, array( 11 ) === $selecao_declarada['excluidos']['declarado'], 'piso: a exclusão declarada não alcançou o eixo automático — a página que a curadoria deixou de fora voltaria pela enumeração' );

/* ---------- seo.llms_sitemap_medido ---------- */

/*
 * O ENDEREÇO DO SITEMAP É MEDIDO, nunca fixo. Com o sitemap do plugin de SEO
 * ligado, o núcleo DESATIVA o endereço dele: imprimir wp-sitemap.xml ali aponta
 * para um arquivo que ninguém serve.
 *
 * TETO: cada fonte devolve o endereço dela.
 * PISO: com o sitemap do plugin ligado, wp-sitemap.xml reprova; e sem nenhum
 * dos dois, a seção é OMITIDA.
 */
$nome = 'seo.llms_sitemap_medido';

$sitemap_do_seo = F3Base_Llms::endereco_do_sitemap( true, true, 'https://exemplo.test/' );

afirmar( $nome, 'https://exemplo.test/sitemap_index.xml' === $sitemap_do_seo['url'], 'teto: com o sitemap do plugin de SEO ligado o endereço saiu ' . $sitemap_do_seo['url'] );
afirmar( $nome, ! str_contains( $sitemap_do_seo['url'], 'wp-sitemap.xml' ), 'piso: com o sitemap do plugin de SEO ligado o arquivo imprimiu wp-sitemap.xml — o núcleo desativa esse endereço, e a última linha apontaria para um sitemap que não existe' );

$sitemap_do_nucleo = F3Base_Llms::endereco_do_sitemap( false, true, 'https://exemplo.test/' );

afirmar( $nome, 'https://exemplo.test/wp-sitemap.xml' === $sitemap_do_nucleo['url'], 'teto: sem o plugin de SEO o endereço do núcleo deixou de ser impresso' );

$sitemap_nenhum = F3Base_Llms::endereco_do_sitemap( false, false, 'https://exemplo.test/' );

afirmar( $nome, '' === $sitemap_nenhum['url'], 'piso: sem sitemap nenhum servido o arquivo continuou imprimindo um endereço — afirmar um endereço que ninguém responde é afirmar mais do que se mediu' );
afirmar( $nome, 'nenhum' === $sitemap_nenhum['fonte'], 'piso: a fonte do sitemap não sai nomeada quando não há nenhum' );

/*
 * PISO DA BARRA: a função é PURA e não pode confiar no formato do argumento.
 * Com o home SEM barra final, a concatenação produz
 * "https://exemplo.testsitemap_index.xml" — endereço que nada serve, impresso
 * como se fosse medido, que é o mesmo defeito do endereço fixo entrando pela
 * outra porta. A garantia mora na função, e não no chamador: o chamador de
 * hoje passa com barra, e é o segundo chamador que paga.
 */
foreach ( array(
	array( true, true, 'sitemap_index.xml' ),
	array( false, true, 'wp-sitemap.xml' ),
) as $caso_da_barra ) {
	$sem_barra = F3Base_Llms::endereco_do_sitemap( (bool) $caso_da_barra[0], (bool) $caso_da_barra[1], 'https://exemplo.test' );

	afirmar(
		$nome,
		'https://exemplo.test/' . $caso_da_barra[2] === $sem_barra['url'],
		'piso da barra: com o home SEM barra final o endereço de ' . $caso_da_barra[2] . ' saiu "' . $sem_barra['url'] . '" — função pura que confia no formato do argumento imprime um endereço que ninguém serve'
	);

	afirmar(
		$nome,
		1 === substr_count( $sem_barra['url'], '/' . $caso_da_barra[2] ),
		'piso da barra: o endereço de ' . $caso_da_barra[2] . ' não tem exatamente uma barra antes do nome do arquivo — "' . $sem_barra['url'] . '"'
	);
}

/* E a barra a mais também não pode virar barra dupla. */
$barra_dobrada = F3Base_Llms::endereco_do_sitemap( true, false, 'https://exemplo.test//' );

afirmar(
	$nome,
	'https://exemplo.test/sitemap_index.xml' === $barra_dobrada['url'],
	'piso da barra: o home com barra a mais produziu "' . $barra_dobrada['url'] . '" — normalizar num sentido só deixa o outro aberto'
);

/* E a medição do site lê as DUAS fontes. */
bancada_limpa();
$GLOBALS['f3b_bench']['conteudo'] = array();
$GLOBALS['f3b_bench']['metas']    = array();
$GLOBALS['f3b_bench']['sitemap_do_nucleo'] = true;
/* As DUAS metades também aqui: a chave gravada e o plugin ativo para servi-la. */
$GLOBALS['f3b_bench']['options']['wpseo']          = array( 'enable_xml_sitemap' => true );
$GLOBALS['f3b_bench']['options']['active_plugins'] = array( F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO ) . '/wp-seo.php' );

afirmar( $nome, str_contains( F3Base_Llms::sitemap_medido()['url'], 'sitemap_index.xml' ), 'piso: com as duas fontes ligadas, a medição do site não preferiu a do plugin de SEO' );

$GLOBALS['f3b_bench']['options']['wpseo']          = array();
$GLOBALS['f3b_bench']['options']['active_plugins'] = array();
$GLOBALS['f3b_bench']['sitemap_do_nucleo'] = false;

afirmar( $nome, '' === F3Base_Llms::sitemap_medido()['url'], 'piso: sem sitemap nenhum a medição do site continuou devolvendo endereço' );

/* ---------- seo.llms_descricao_fonte ---------- */

/*
 * A DESCRIÇÃO TEM CADEIA E A CADEIA TEM ORDEM: meta do plugin de SEO, resumo
 * declarado no conteúdo, e só então o corte do corpo. A função devolve o texto E
 * a fonte, porque sem a fonte não há como provar que a primeira foi preferida —
 * um resumo bom vindo do lugar errado continua sendo medição de outra coisa.
 *
 * TETO: com meta escrita, é a meta que sai, e a fonte é nomeada.
 * PISO: cair no corte do conteúdo existindo meta reprova.
 */
$nome = 'seo.llms_descricao_fonte';

$com_meta = F3Base_Llms::descricao_do_item( 'Diagnóstico de linha para fábricas de médio porte.', 'resumo declarado', '<p>corpo da página</p>', 20 );

afirmar( $nome, 'Diagnóstico de linha para fábricas de médio porte.' === $com_meta['texto'], 'piso: existindo meta descrição do plugin de SEO, a descrição saiu de outro lugar — foi assim que onze descrições escritas à mão foram ignoradas' );
afirmar( $nome, F3Base_Llms::FONTE_META === $com_meta['fonte'], 'teto: a fonte da descrição não sai NOMEADA como a meta do plugin de SEO' );

$com_resumo = F3Base_Llms::descricao_do_item( '', 'resumo declarado no conteúdo', '<p>corpo da página</p>', 20 );

afirmar( $nome, 'resumo declarado no conteúdo' === $com_resumo['texto'] && F3Base_Llms::FONTE_RESUMO === $com_resumo['fonte'], 'teto: sem meta, o resumo declarado no conteúdo deixou de ser preferido ao corte do corpo' );

$so_conteudo = F3Base_Llms::descricao_do_item( '', '', '<p>corpo da página com texto suficiente</p>', 20 );

afirmar( $nome, F3Base_Llms::FONTE_CONTEUDO === $so_conteudo['fonte'] && '' !== $so_conteudo['texto'], 'teto: sem meta e sem resumo, o corte do corpo deixou de responder' );

$sem_nada = F3Base_Llms::descricao_do_item( '', '', '   ', 20 );

afirmar( $nome, F3Base_Llms::FONTE_NENHUMA === $sem_nada['fonte'] && '' === $sem_nada['texto'], 'piso: sem fonte nenhuma a função inventou descrição — descrição inventada é o instrumento afirmando o que não leu' );

/* E a enumeração do site LÊ a meta pela constante do módulo de noindex. */
bancada_limpa();
$GLOBALS['f3b_bench']['conteudo'] = array();
$GLOBALS['f3b_bench']['metas']    = array();
f3b_llms_conteudo( 21, 'Página com meta', 'page', '2026-02-01', '<p>corpo qualquer</p>', 'resumo declarado', array( F3Base_Modulo_Noindex_Honrado::META_DESCRICAO => 'descrição escrita no plugin de SEO' ) );

$enumerados_com_meta = F3Base_Llms::enumerar( array( 'page' ), 20, 10 );

afirmar( $nome, 1 === count( $enumerados_com_meta ), 'teto: a enumeração não devolveu o conteúdo publicado da bancada' );
afirmar( $nome, 'descrição escrita no plugin de SEO' === (string) ( $enumerados_com_meta[0]['descricao'] ?? '' ), 'piso: a enumeração ignorou a meta descrição gravada e caiu no corte do conteúdo' );
afirmar( $nome, F3Base_Llms::FONTE_META === (string) ( $enumerados_com_meta[0]['fonte'] ?? '' ), 'teto: a enumeração não carrega a FONTE da descrição, e sem ela não há como provar qual respondeu' );

/* ---------- seo.llms_sem_interface_no_resumo ---------- */

/*
 * O RESUMO É DO ASSUNTO, NÃO DA INTERFACE. Tirar só as tags preserva o texto de
 * dentro, e o texto de dentro de um formulário de busca é o rótulo do botão: o
 * resumo terminaria descrevendo a interface do site.
 *
 * TETO: o texto do conteúdo sobrevive, e blocos separados não colam numa frase.
 * PISO: conteúdo com form/button não pode vazar rótulo de interface.
 */
$nome = 'seo.llms_sem_interface_no_resumo';

$com_formulario = '<h2>Tecnologia, Tendências e Gestão</h2>'
	. '<form role="search"><label>Buscar por:</label><input type="search" /><button type="submit">Search Buscar</button></form>'
	. '<p>Análises sobre operação industrial e indicadores de linha.</p>';

$resumo_limpo = F3Base_Llms::resumo_limpo( $com_formulario, 30 );

afirmar( $nome, ! str_contains( $resumo_limpo, 'Search Buscar' ), 'piso: o rótulo do botão de busca vazou para o resumo — o resumo passaria a descrever a interface do site: ' . $resumo_limpo );
afirmar( $nome, ! str_contains( $resumo_limpo, 'Buscar por' ), 'piso: o rótulo do campo de busca vazou para o resumo: ' . $resumo_limpo );
afirmar( $nome, str_contains( $resumo_limpo, 'Análises sobre operação industrial' ), 'teto: o texto do conteúdo sumiu junto com a interface — a limpeza levou o que ela existe para preservar: ' . $resumo_limpo );
afirmar( $nome, ! str_contains( $resumo_limpo, 'GestãoAnálises' ) && ! str_contains( $resumo_limpo, 'Gestão Análises' ), 'piso: o título e o corpo colaram numa frase só, sem pontuação: ' . $resumo_limpo );

/*
 * A TAG DE SCRIPT DA FIXTURE É MONTADA POR PEDAÇOS de propósito: escrita
 * inteira, este arquivo conteria uma tag de script com corpo e
 * `estatica.detector_codigo_em_string` acusaria a própria bancada — o detector
 * que grita por causa de si é tão inútil quanto o que nunca grita.
 */
$abre_script  = '<' . 'script>';
$fecha_script = '</' . 'script>';

$com_script = F3Base_Llms::resumo_limpo( $abre_script . 'var a = "clique aqui";' . $fecha_script . '<p>Texto de verdade da página.</p>', 30 );

afirmar( $nome, ! str_contains( $com_script, 'clique aqui' ), 'piso: o corpo de um script entrou no resumo: ' . $com_script );

$com_shortcode = F3Base_Llms::resumo_limpo( '[contact-form id="4"]<p>Texto de verdade da página.</p>', 30 );

afirmar( $nome, ! str_contains( $com_shortcode, 'contact-form' ), 'piso: um shortcode não renderizado virou texto literal no resumo: ' . $com_shortcode );

afirmar( $nome, '' === F3Base_Llms::resumo_limpo( '<form><button>Buscar</button></form>', 30 ), 'piso: um conteúdo que é SÓ interface produziu resumo — resumo de nada é pior que resumo nenhum' );

/* ---------- seo.llms_ordem ---------- */

/*
 * A PÁGINA INICIAL PRIMEIRO, depois a curadoria NA ORDEM DECLARADA, e só então
 * o enumerado — páginas antes de posts, por data decrescente. Ordenar tudo por
 * data joga a página inicial para o rodapé, depois de qualquer artigo: o que
 * define o site não pode sair por último.
 *
 * TETO: a ordem declarada da curadoria sobrevive.
 * PISO: a home fora da primeira posição reprova.
 */
$nome = 'seo.llms_ordem';

$para_ordenar = array(
	array( 'id' => 31, 'titulo' => 'Artigo novo', 'url' => 'https://exemplo.test/n/', 'tipo' => 'post', 'data' => '2026-05-01', 'origem' => F3Base_Llms::ORIGEM_AUTOMATICO ),
	array( 'id' => 32, 'titulo' => 'Arquitetura', 'url' => 'https://exemplo.test/arq/', 'tipo' => 'page', 'data' => '', 'origem' => F3Base_Llms::ORIGEM_CURADO ),
	array( 'id' => 33, 'titulo' => 'Página avulsa', 'url' => 'https://exemplo.test/av/', 'tipo' => 'page', 'data' => '2026-04-01', 'origem' => F3Base_Llms::ORIGEM_AUTOMATICO ),
	array( 'id' => 34, 'titulo' => 'Início', 'url' => 'https://exemplo.test/', 'tipo' => 'page', 'data' => '2020-01-01', 'origem' => F3Base_Llms::ORIGEM_HOME ),
	array( 'id' => 35, 'titulo' => 'Contato', 'url' => 'https://exemplo.test/c/', 'tipo' => 'page', 'data' => '', 'origem' => F3Base_Llms::ORIGEM_CURADO ),
	array( 'id' => 36, 'titulo' => 'Artigo antigo', 'url' => 'https://exemplo.test/a/', 'tipo' => 'post', 'data' => '2026-03-01', 'origem' => F3Base_Llms::ORIGEM_AUTOMATICO ),
);

$ordenados = F3Base_Llms::ordenar( $para_ordenar );
$ids_em_ordem = array_map( static fn ( array $i ): int => (int) $i['id'], $ordenados );

afirmar( $nome, 34 === ( $ids_em_ordem[0] ?? 0 ), 'piso: a página inicial não saiu em PRIMEIRO — ordenar tudo por data a joga para o rodapé, depois de qualquer artigo. Ordem obtida: ' . implode( ', ', $ids_em_ordem ) );
afirmar( $nome, array( 32, 35 ) === array_slice( $ids_em_ordem, 1, 2 ), 'teto: a curadoria não veio logo depois da home NA ORDEM DECLARADA: ' . implode( ', ', $ids_em_ordem ) );
afirmar( $nome, 33 === ( $ids_em_ordem[3] ?? 0 ), 'teto: no eixo automático a página não veio antes dos artigos: ' . implode( ', ', $ids_em_ordem ) );
afirmar( $nome, array( 31, 36 ) === array_slice( $ids_em_ordem, 4, 2 ), 'teto: os artigos não saíram por data decrescente: ' . implode( ', ', $ids_em_ordem ) );

/* ---------- seo.llms_full_servido ---------- */

/*
 * O TEXTO INTEGRAL SÓ EXISTE COM A CHAVE LIGADA. Desligada, o módulo fecha
 * INATIVO: nenhum hook é registrado, a rota não existe e não há superfície
 * pública nenhuma — a mesma física da chave-mestra.
 *
 * TETO: ligada, o módulo fica ativo e o corpo traz o texto integral com URL.
 * PISO: desligada, o módulo é inativo e não registra hook.
 */
$nome = 'seo.llms_full_servido';

bancada_limpa();
$GLOBALS['f3b_bench']['conteudo'] = array();
$GLOBALS['f3b_bench']['metas']    = array();
f3b_llms_conteudo( 41, 'Página do texto integral', 'page', '2026-02-02', '<p>Primeiro parágrafo do corpo.</p><p>Segundo parágrafo do corpo.</p>' );

f3b_llms_config( array( 'full' => false ) );
requisicao_nova();

$full_desligado = ( new F3Base_Modulo_Llms_Full_Txt() )->estado();

afirmar( $nome, F3Base_Modulo::INATIVO === $full_desligado['estado'], 'piso: com a chave desligada o módulo do texto integral não fechou INATIVO — inativo é o que impede o hook de ser registrado, e sem isso a rota existiria assim mesmo' );
afirmar( $nome, false === ( new F3Base_Modulo_Llms_Full_Txt() )->deve_registrar(), 'piso: com a chave desligada o módulo continuou registrando hook — a superfície pública existiria sem ninguém ter ligado nada' );

f3b_llms_config( array( 'full' => true ) );
requisicao_nova();

$full_ligado = ( new F3Base_Modulo_Llms_Full_Txt() )->estado();

afirmar( $nome, F3Base_Modulo::ATIVO === $full_ligado['estado'], 'teto: com a chave ligada o módulo não ficou ativo — ' . $full_ligado['motivo'] );
afirmar( $nome, true === ( new F3Base_Modulo_Llms_Full_Txt() )->deve_registrar(), 'teto: com a chave ligada o módulo não registra hook, e a rota não existiria' );

$itens_do_full = F3Base_Modulo_Llms_Txt_Reserva::selecao( F3Base_Options::ler( 'f3base_llms' ) );
$corpo_do_full = F3Base_Modulo_Llms_Full_Txt::montar( $itens_do_full, F3Base_Options::ler( 'f3base_llms' ) );

afirmar( $nome, str_contains( $corpo_do_full, 'URL: ' ), 'teto: o texto integral não traz a URL de cada item' );
afirmar( $nome, str_contains( $corpo_do_full, 'Primeiro parágrafo do corpo' ) && str_contains( $corpo_do_full, 'Segundo parágrafo do corpo' ), 'teto: o texto integral cortou o corpo — ele existe justamente para não cortar: ' . $corpo_do_full );
afirmar( $nome, str_contains( $corpo_do_full, 'Data: 2026-02-02' ), 'teto: o texto integral não traz a data de cada item' );

/* A MESMA SELEÇÃO dos dois arquivos: o que sai de um sai do outro. */
$itens_do_indice = ( new F3Base_Modulo_Llms_Txt_Reserva() )->itens();

afirmar(
	$nome,
	array_map( static fn ( array $i ): int => (int) $i['id'], $itens_do_indice ) === array_map( static fn ( array $i ): int => (int) $i['id'], $itens_do_full ),
	'piso: o índice curto e o texto integral listaram conjuntos DIFERENTES — dois vereditos sobre o mesmo site'
);

/* E o cabeçalho de indexação sai do valor GRAVADO. */
afirmar( $nome, true === (bool) F3Base_Options::ler( 'f3base_llms' )['indexavel'], 'teto: a chave de indexação não é lida de volta com o valor gravado' );

f3b_llms_config( array( 'full' => true, 'indexavel' => false ) );

afirmar( $nome, false === (bool) F3Base_Options::ler( 'f3base_llms' )['indexavel'], 'piso: desligar a indexação não sobreviveu à leitura de volta — o cabeçalho X-Robots-Tag deixaria de ser controlável' );


/* ==========================================================================
 * comportamento.resumo_agregado
 *
 * O QUE SE MEDE AQUI. A rota que recebe o resumo da sessão, com as regras que o
 * endpoint de leads já estabeleceu — schema fechado, teto de tamanho, limite de
 * taxa atômico e status coerente com o corpo — e com as três que são desta
 * release: dado pessoal não atravessa, duas sessões somam na MESMA linha do
 * dia, e a retenção apaga o que passou do prazo.
 * ======================================================================= */

$nome = 'comportamento.resumo_agregado';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

/**
 * Corpo mínimo aceito pela rota do resumo.
 *
 * @param array<string,mixed> $extra Campos a acrescentar ou trocar.
 * @return array<string,mixed>
 */
function carga_de_comportamento( array $extra = array() ): array {
	return array_merge(
		array(
			'token'    => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'caminho'  => '/pagina-de-bancada/',
			'metricas' => array(
				array(
					'gatilho'  => 'rolagem',
					'detalhe'  => '75',
					'contagem' => 1,
				),
			),
		),
		$extra
	);
}

/**
 * Exercita a rota do resumo com um corpo JSON.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar_comportamento( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Comportamento();

	return $modulo->receber( new WP_REST_Request( $corpo, null ) );
}

/**
 * Linhas do resumo na tabela da bancada.
 *
 * @return array<int,array<string,mixed>>
 */
function linhas_do_resumo(): array {
	global $wpdb;

	return array_values( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela() ]['linhas'] ?? array() );
}

/* PISO da bancada: a tabela nasce pronta, senão tudo abaixo mediria o 503. */
afirmar(
	$nome,
	F3Base_Modulo_Comportamento::tabela_pronta(),
	'piso da bancada: a tabela do resumo não ficou pronta com as colunas desta versão, e sem ela nada abaixo mede o que promete'
);

/* TETO: o resumo de uma sessão entra, e responde 201 com a contagem. */
$r = postar_comportamento( carga_de_comportamento() );

afirmar(
	$nome,
	201 === $r->status && true === $r->data['registrado'] && 1 === (int) $r->data['linhas'],
	'teto: a sessão válida não foi somada — status ' . $r->status . ', registrado ' . var_export( $r->data['registrado'] ?? null, true )
);

afirmar(
	$nome,
	1 === count( linhas_do_resumo() ) && 1 === (int) linhas_do_resumo()[0]['contagem'],
	'teto: a primeira sessão não produziu exatamente uma linha com contagem 1'
);

/* TETO: DUAS SESSÕES SOMAM NA MESMA LINHA DO DIA. */
postar_comportamento( carga_de_comportamento() );

afirmar(
	$nome,
	1 === count( linhas_do_resumo() ) && 2 === (int) linhas_do_resumo()[0]['contagem'],
	'teto: a segunda sessão no mesmo dia, caminho e evento não somou na mesma linha — observado ' . count( linhas_do_resumo() ) . ' linha(s)'
);

/* TETO: o nome do evento sai da DECLARAÇÃO, e o cliente manda só o gatilho. */
$declarados_bancada = F3Base_Modulo_Tracking::eventos_de_comportamento();
$nome_da_rolagem    = '';

foreach ( $declarados_bancada as $evento_declarado => $dados_declarados ) {
	if ( 'rolagem' === (string) $dados_declarados['gatilho'] ) {
		$nome_da_rolagem = (string) $evento_declarado;
	}
}

afirmar(
	$nome,
	'' !== $nome_da_rolagem && $nome_da_rolagem === (string) linhas_do_resumo()[0]['metrica'],
	'teto: a linha não foi gravada com o nome DECLARADO do evento. O cliente manda o gatilho e quem resolve o nome é o servidor — é isso que permite renomear num lugar só sem quebrar a série'
);

/*
 * PISO: campo desconhecido no corpo é RECUSADO pelo nome.
 *
 * O campo usado aqui era `visitante` até a 1.2.0 do site-core, quando ele
 * passou a ser um campo LEGÍTIMO do schema. Trocá-lo por um nome que continua
 * fora é o que mantém este piso medindo a regra, e não uma versão do schema.
 */
$r = postar_comportamento( carga_de_comportamento( array( 'impressao_digital' => 'abc' ) ) );

afirmar(
	$nome,
	400 === $r->status && 'f3base_campo_desconhecido' === (string) $r->data['codigo'] && 'impressao_digital' === (string) $r->data['campo'],
	'piso do schema fechado: um campo fora do schema entrou em silêncio — schema que ignora o desconhecido é schema que aceita qualquer coisa'
);

/*
 * PISO DO PSEUDÔNIMO: o campo é legítimo e a FORMA é fechada. Um campo que
 * aceitasse texto livre aceitaria um e-mail, e o site passaria a guardar dado
 * direto no lugar do apelido sorteado sem que nada acusasse.
 */
$r = postar_comportamento( carga_de_comportamento( array( 'visitante' => 'joao@exemplo.test' ) ) );

afirmar(
	$nome,
	400 === $r->status && 'f3base_pseudonimo_invalido' === (string) $r->data['codigo'] && 'visitante' === (string) $r->data['campo'],
	'piso do pseudônimo: o apelido do visitante aceitou um valor fora do hexadecimal sorteado. É esta forma fechada que impede um e-mail de entrar pelo campo do apelido'
);

/*
 * TETO DO PSEUDÔNIMO AUSENTE: sem apelido, o corpo continua sendo aceito e o
 * AGREGADO continua somando. Navegador com armazenamento bloqueado não pode
 * derrubar a medição inteira — medição parcial é melhor que medição nenhuma.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$r = postar_comportamento( carga_de_comportamento() );

afirmar(
	$nome,
	201 === $r->status && (int) $r->data['linhas'] > 0 && 0 === (int) $r->data['registro'],
	'teto do pseudônimo ausente: sem apelido do visitante o corpo deixou de somar no resumo. Quem bloqueia o armazenamento local tem de continuar contando no agregado, e perder só o registro detalhado'
);

/* PISO: campo desconhecido DENTRO da lista também é recusado. */
$r = postar_comportamento(
	carga_de_comportamento(
		array(
			'metricas' => array(
				array(
					'gatilho'  => 'rolagem',
					'detalhe'  => '75',
					'contagem' => 1,
					'usuario'  => 'joao',
				),
			),
		)
	)
);

afirmar(
	$nome,
	400 === $r->status && 'f3base_campo_desconhecido' === (string) $r->data['codigo'],
	'piso do schema fechado DENTRO da lista: um campo novo numa entrada passou, e é ali que um identificador entraria sem ninguém ter decidido que ele podia existir'
);

/* PISO DO DADO PESSOAL: nada com forma de identificador atravessa o detalhe. */
$pessoais = array(
	'joao@exemplo.test',
	'/perfil/joao-silva',
	'+5511900000000',
	'sessao 8f3c1d',
	'https://exemplo.test/x?email=joao',
);

foreach ( $pessoais as $pessoal ) {
	$r = postar_comportamento(
		carga_de_comportamento(
			array(
				'metricas' => array(
					array(
						'gatilho'  => 'rolagem',
						'detalhe'  => $pessoal,
						'contagem' => 1,
					),
				),
			)
		)
	);

	afirmar(
		$nome,
		400 === $r->status && 'f3base_detalhe_invalido' === (string) $r->data['codigo'],
		'piso do dado pessoal: "' . $pessoal . '" foi aceito como detalhe. O alfabeto fechado é a porta, e ela não tem exceção para o que parece inofensivo'
	);
}

/* PISO DO DADO PESSOAL no caminho: query e fragmento não entram. */
foreach ( array( '/pagina/?email=joao@exemplo.test', '/pagina/#nome', 'https://exemplo.test/pagina/', '/../etc/senha' ) as $caminho_ruim ) {
	$r = postar_comportamento( carga_de_comportamento( array( 'caminho' => $caminho_ruim ) ) );

	afirmar(
		$nome,
		400 === $r->status && 'f3base_caminho_invalido' === (string) $r->data['codigo'],
		'piso do dado pessoal: o caminho "' . $caminho_ruim . '" foi aceito. É na query que a campanha de outra pessoa cola o identificador do lead'
	);
}

/* PISO: nenhum valor pessoal sobreviveu à varredura da tabela inteira. */
$serializado = wp_json_encode( linhas_do_resumo() );

foreach ( array( 'joao', '@exemplo.test', 'perfil', 'email=' ) as $vestigio ) {
	afirmar(
		$nome,
		! str_contains( (string) $serializado, $vestigio ),
		'piso do dado pessoal: "' . $vestigio . '" sobreviveu dentro da tabela do resumo — a varredura é do payload inteiro, como a da CAPI'
	);
}

/* PISO: gatilho fora da declaração não vira linha. */
$r = postar_comportamento(
	carga_de_comportamento(
		array(
			'metricas' => array(
				array(
					'gatilho'  => 'inventado',
					'contagem' => 1,
				),
			),
		)
	)
);

afirmar(
	$nome,
	400 === $r->status && 'f3base_gatilho_nao_declarado' === (string) $r->data['codigo'],
	'piso da declaração: um gatilho que não está no arquivo único virou medição — nome que nasce fora da declaração é série histórica que ninguém sabe ler'
);

/* PISO: token inválido é 403, e nada é somado. */
$linhas_antes = count( linhas_do_resumo() );
$r            = postar_comportamento( carga_de_comportamento( array( 'token' => 'invalido.invalido' ) ) );

afirmar(
	$nome,
	403 === $r->status && $linhas_antes === count( linhas_do_resumo() ),
	'piso do token: corpo sem token válido foi aceito, ou somou alguma coisa antes de recusar'
);

/* PISO: mais totais que o teto somado da declaração é recusado. */
$excesso = array();
$teto    = F3Base_Modulo_Comportamento::maximo_de_metricas();

for ( $i = 0; $i <= $teto; $i++ ) {
	$excesso[] = array(
		'gatilho'  => 'rolagem',
		'detalhe'  => (string) ( 100 + $i ),
		'contagem' => 1,
	);
}

$r = postar_comportamento( carga_de_comportamento( array( 'metricas' => $excesso ) ) );

afirmar(
	$nome,
	400 === $r->status && 'f3base_metricas_demais' === (string) $r->data['codigo'] && $teto === (int) $r->data['limite'],
	'piso do teto: uma sessão com mais totais que o teto somado da declaração foi aceita — sem teto, uma página faz o volume de um dia'
);

afirmar(
	$nome,
	$teto === array_sum( array_map( static fn( array $dados ): int => (int) $dados['teto'], $declarados_bancada ) ),
	'piso do teto: o máximo de linhas por sessão não é a SOMA dos tetos declarados — um número escrito no módulo seria uma segunda verdade que envelhece na primeira linha nova do arquivo'
);

/* TETO DOS VITAIS: soma e contagem separadas, para média sem guardar amostra. */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

foreach ( array( 1800.0, 2200.0 ) as $valor_do_vital ) {
	postar_comportamento(
		carga_de_comportamento(
			array(
				'metricas' => array(
					array(
						'gatilho'  => 'desempenho',
						'detalhe'  => 'LCP',
						'contagem' => 1,
						'soma'     => $valor_do_vital,
					),
				),
			)
		)
	);
}

$linha_do_vital = linhas_do_resumo()[0] ?? array();

afirmar(
	$nome,
	2 === (int) ( $linha_do_vital['contagem'] ?? 0 ) && 4000.0 === (float) ( $linha_do_vital['soma'] ?? 0 ),
	'teto dos vitais: soma e contagem não acumularam separadas (observado contagem ' . (int) ( $linha_do_vital['contagem'] ?? 0 ) . ', soma ' . (float) ( $linha_do_vital['soma'] ?? 0 ) . ') — sem as duas não há média sem guardar amostra'
);

$resumo_do_periodo = F3Base_Modulo_Comportamento::resumo();

afirmar(
	$nome,
	array() !== $resumo_do_periodo['vitais'] && 2000.0 === (float) $resumo_do_periodo['vitais'][0]['media'] && 2 === (int) $resumo_do_periodo['vitais'][0]['amostra'],
	'teto dos vitais: a média do período não saiu de soma dividida por contagem'
);

/* TETO DA RETENÇÃO: o que passou do prazo é apagado pela rotina que já existe. */
global $wpdb;

$tabela_do_resumo = F3Base_Modulo_Comportamento::nome_tabela();
$dia_antigo       = gmdate( 'Y-m-d', time() - ( ( F3Base_Modulo_Comportamento::retencao_dias() + 5 ) * DAY_IN_SECONDS ) );
$chave_antiga     = F3Base_Modulo_Comportamento::chave_da_linha( $dia_antigo, '/velha/', 'f3base_rolagem', '25' );

$wpdb->tabelas[ $tabela_do_resumo ]['linhas'][ $chave_antiga ] = array(
	'chave'         => $chave_antiga,
	'dia'           => $dia_antigo,
	'caminho'       => '/velha/',
	'metrica'       => 'f3base_rolagem',
	'detalhe'       => '25',
	'contagem'      => 9,
	'soma'          => 0.0,
	'atualizado_em' => time(),
);

$antes_da_poda = count( linhas_do_resumo() );
$podadas       = F3Base_Modulo_Comportamento::podar();

afirmar(
	$nome,
	1 === $podadas && ( $antes_da_poda - 1 ) === count( linhas_do_resumo() ),
	'teto da retenção: a linha mais velha que o prazo declarado não foi apagada — painel sem prazo vira arquivo histórico que ninguém declarou guardar'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Comportamento::podar(),
	'piso da retenção: a segunda poda apagou alguma coisa dentro do prazo'
);

/* TETO DA ROTINA ÚNICA: quem poda é a rotina de retenção que já existe. */
( new F3Base_Modulo_Retencao_Eliminacao() )->executar_limpeza();

afirmar(
	$nome,
	array() !== F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_PODA_COMPORTAMENTO ),
	'teto da rotina única: a limpeza de retenção rodou e não carimbou a poda do resumo — prazo cumprido por uma segunda rotina é prazo que se cumpre pela metade no dia em que ela não roda'
);

/* PISO DO LIMITE DE TAXA: o mesmo balde atômico do endpoint de leads. */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

add_filter( 'f3base_comportamento_rate_limit_maximo', static fn(): int => 2 );

$status_da_janela = array();

for ( $i = 0; $i < 3; $i++ ) {
	$status_da_janela[] = postar_comportamento( carga_de_comportamento() )->status;
}

afirmar(
	$nome,
	array( 201, 201, 429 ) === $status_da_janela,
	'teto do limite de taxa: a terceira sessão da mesma origem, com o teto declarado em 2, devolveu ' . implode( ', ', $status_da_janela ) . '. O balde é o MESMO do endpoint de leads — uma instrução, e quem soma é o banco —, e uma segunda implementação aqui seria a segunda a ficar para trás'
);

afirmar(
	$nome,
	2 === (int) ( linhas_do_resumo()[0]['contagem'] ?? 0 ),
	'piso do limite de taxa: a sessão recusada por limite somou alguma coisa antes de ser recusada'
);

/* O filtro do teto sai daqui: bancada_limpa() zera dados, não ouvintes. */
unset( $GLOBALS['f3b_bench']['hooks']['f3base_comportamento_rate_limit_maximo'] );

/* PISO DO DESLIGADO: com a chave desligada nada entra, e o status diz isso. */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => false ), F3Base_Options::ORIGEM_MANUAL );

$r = postar_comportamento( carga_de_comportamento() );

afirmar(
	$nome,
	409 === $r->status && false === $r->data['registrado'] && array() === linhas_do_resumo(),
	'piso do desligado: com o resumo desligado a rota gravou alguma coisa, ou respondeu como se tivesse gravado'
);

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === ( new F3Base_Modulo_Comportamento() )->estado()['estado'],
	'piso do desligado: o módulo não fecha inativo com o resumo desligado'
);

/* PISO DA TABELA AUSENTE: 503 nomeado, nunca 201 sobre nada gravado. */
bancada_limpa();
requisicao_nova();
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true ), F3Base_Options::ORIGEM_MANUAL );
unset( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela() ] );

$reflexo_da_tabela = new ReflectionProperty( 'F3Base_Modulo_Comportamento', 'tabela_pronta' );
$reflexo_da_tabela->setAccessible( true );
$reflexo_da_tabela->setValue( null, null );

$r = postar_comportamento( carga_de_comportamento() );

afirmar(
	$nome,
	503 === $r->status && 'f3base_armazenamento_indisponivel' === (string) $r->data['codigo'],
	'piso do armazenamento: sem a tabela pronta a rota respondeu ' . $r->status . ' — 201 sobre nada gravado é o status contradizendo o corpo'
);

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Comportamento() )->estado()['estado'],
	'piso do armazenamento: sem a tabela pronta o módulo não fecha degradado, e a perda fica invisível'
);

/*
 * TETO DA MIGRAÇÃO: o gancho de ativação NÃO roda numa ATUALIZAÇÃO de plugin.
 * Um site que sai da 1.1.3 para a 1.1.4 sem desativar e reativar nunca chamaria
 * instalar(), e ficaria com a rota respondendo 503 para sempre. Quem fecha esse
 * buraco é garantir_estrutura(), na requisição seguinte — e como o módulo fecha
 * DEGRADADO (e não inativo) sem a tabela, os hooks dele continuam registrados,
 * que é o que faz o gancho chegar a rodar.
 */
afirmar(
	$nome,
	( new F3Base_Modulo_Comportamento() )->deve_registrar(),
	'piso da migração: sem a tabela o módulo deixou de registrar hooks, e aí o próprio gancho que criaria a tabela nunca roda'
);

( new F3Base_Modulo_Comportamento() )->garantir_estrutura();

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::tabela_pronta(),
	'teto da migração: garantir_estrutura() não criou a tabela na requisição seguinte — a atualização de plugin não passa pelo gancho de ativação'
);

$r = postar_comportamento( carga_de_comportamento() );

afirmar(
	$nome,
	201 === $r->status,
	'teto da migração: depois de a estrutura ter sido garantida a rota continuou recusando'
);

/* ==========================================================================
 * comportamento.lote_idempotente
 *
 * O QUE SE MEDE AQUI, e por que este bloco existe. Até a 1.3.4 o cliente
 * despachava por `sendBeacon` e limpava o acumulado quando ele devolvia
 * `true` — e `true` significa ENFILEIRADO, nunca ENTREGUE. Medido em produção
 * na visita `8cac18da62ed056004242bee737457db` de `fator3-teste-mcp-1`, num
 * único carregamento de `/`: `comando-unico` saiu com as ocorrências 1 e 3, e o
 * lote de uma linha só — a subida da página, que faz o bloco reentrar em vista
 * e não dispara marco nenhum — nunca chegou.
 *
 * O cliente passou a CONFIRMAR a entrega, e confirmar implica REENVIAR: uma
 * resposta perdida no caminho de volta faz o mesmo lote chegar de novo. É este
 * lado que precisa reconhecê-lo. O que se cobra aqui:
 *
 * 1. o mesmo lote entregue duas vezes produz UMA linha de cada;
 * 2. a repetição responde 2XX — qualquer outro código faria o cliente reter e
 *    reenviar para sempre justamente o lote que o servidor já tem;
 * 3. o selo é reservado antes da escrita e DEVOLVIDO quando nada foi gravado,
 *    senão a retentativa recebe "já gravei isto" sobre um banco que recusou;
 * 4. o corte deixa de morrer na resposta e passa a ser GRAVADO, para que a
 *    tela possa dizer que a tabela está incompleta.
 * ======================================================================= */

$nome = 'comportamento.lote_idempotente';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

/**
 * Corpo SELADO: com os dois apelidos, o selo do lote e uma linha de registro.
 *
 * @param string              $lote  Selo sorteado do lote.
 * @param array<string,mixed> $extra Campos a acrescentar ou trocar.
 * @return array<string,mixed>
 */
function carga_selada( string $lote, array $extra = array() ): array {
	return carga_de_comportamento(
		array_merge(
			array(
				'visitante' => str_repeat( 'a1', 16 ),
				'sessao'    => str_repeat( 'b2', 16 ),
				'lote'      => $lote,
				'eventos'   => array(
					array(
						'gatilho'    => 'interseccao',
						'detalhe'    => 'comando-unico',
						'valor'      => 0,
						'ocorrencia' => 2,
						'ms'         => 79925,
					),
				),
			),
			$extra
		)
	);
}

/**
 * Linhas do REGISTRO detalhado na tabela da bancada.
 *
 * @return array<int,array<string,mixed>>
 */
function linhas_do_registro(): array {
	global $wpdb;

	return array_values( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela_eventos() ]['linhas'] ?? array() );
}

$selo = str_repeat( 'c3', 16 );

$primeira = postar_comportamento( carga_selada( $selo ) );

afirmar(
	$nome,
	201 === $primeira->status && 1 === (int) $primeira->data['registro'],
	'teto do selo: o primeiro envio de um lote selado não gravou o registro — status ' . $primeira->status
);

afirmar(
	$nome,
	1 === count( linhas_do_registro() ),
	'teto do selo: o primeiro envio produziu ' . count( linhas_do_registro() ) . ' linha(s) de registro, e o esperado é uma'
);

/* PISO 3: O MESMO LOTE ENTREGUE DUAS VEZES PRODUZ UMA LINHA DE CADA. */
$repetida = postar_comportamento( carga_selada( $selo ) );

afirmar(
	$nome,
	1 === count( linhas_do_registro() ),
	'PISO do reenvio: o mesmo lote entregue duas vezes gravou ' . count( linhas_do_registro() ) .
		' linha(s) de registro. Confirmar a entrega implica reenviar — uma resposta perdida no caminho de volta faz o lote voltar —, e sem o selo o relatório conta duas vezes'
);

afirmar(
	$nome,
	1 === (int) ( linhas_do_resumo()[0]['contagem'] ?? 0 ),
	'PISO do reenvio: o AGREGADO somou de novo no lote repetido. O painel e a tabela contam a mesma coisa por caminhos diferentes, e um deles dobrando é a divergência que ninguém consegue explicar depois'
);

afirmar(
	$nome,
	$repetida->status >= 200 && $repetida->status < 300 && 'f3base_lote_repetido' === (string) $repetida->data['codigo'],
	'PISO do reenvio: a repetição respondeu status ' . $repetida->status . ' com o código "' . (string) ( $repetida->data['codigo'] ?? '' ) .
		'", e o esperado é um 2xx nomeando f3base_lote_repetido. ' .
		'Para quem envia, "já tenho isto" e "acabei de gravar" precisam ser a mesma resposta boa: qualquer outro status faz o cliente reter o lote e reenviá-lo para sempre'
);

/* TETO: outro selo na MESMA visita continua entrando — a recusa é do lote. */
$outro = postar_comportamento( carga_selada( str_repeat( 'd4', 16 ) ) );

afirmar(
	$nome,
	201 === $outro->status && 2 === count( linhas_do_registro() ),
	'teto do selo: um lote com selo DIFERENTE na mesma visita foi recusado — status ' . $outro->status .
		', ' . count( linhas_do_registro() ) . ' linha(s). O selo identifica UM lote, e não a visita: recusar por visita apagaria tudo depois do primeiro lote'
);

/*
 * MUTAÇÃO — O SERVIDOR ACEITA O MESMO SELO DUAS VEZES.
 *
 * O mutante é o servidor sem memória do selo: a linha da reserva é apagada,
 * como se ela nunca tivesse sido gravada. É exatamente o que aconteceria com um
 * mecanismo que não reservasse nada, e sem ele o piso acima não prova nada —
 * ele passaria num servidor que simplesmente nunca recebeu o mesmo lote duas
 * vezes.
 */
global $wpdb;

$chave_do_selo = F3Base_Modulo_Endpoint_Leads::chave_de_dedup(
	F3Base_Modulo_Comportamento::correlacao_do_lote( str_repeat( 'b2', 16 ), $selo )
);

$tabela_de_selos = F3Base_Modulo_Endpoint_Leads::nome_tabela();
$antes_do_mutante = count( linhas_do_registro() );

afirmar(
	$nome,
	isset( $wpdb->tabelas[ $tabela_de_selos ]['linhas'][ $chave_do_selo ] ),
	'piso da mutação: o selo do lote não ficou gravado na tabela de reservas, e sem ele não há o que apagar — a bancada estaria medindo um mecanismo que não existe'
);

unset( $wpdb->tabelas[ $tabela_de_selos ]['linhas'][ $chave_do_selo ] );

postar_comportamento( carga_selada( $selo ) );

afirmar(
	$nome,
	count( linhas_do_registro() ) > $antes_do_mutante,
	'PISO do reenvio: com o selo esquecido, o mesmo lote entregue de novo continuou produzindo ' . count( linhas_do_registro() ) .
		' linha(s) — ele deveria ter gravado DE NOVO, que é o defeito. A bancada não reproduz a contagem dobrada, e um piso que não sabe falhar não prova que o selo está fazendo alguma coisa'
);

/*
 * PISO DA COMPENSAÇÃO: nada gravado, selo DEVOLVIDO.
 *
 * Marcar o selo e gravar em seguida parece bastar e não basta: uma escrita que
 * FALHA deixaria o selo queimado, a retentativa receberia "já gravei isto", o
 * cliente esqueceria o lote e as linhas sumiriam — o mesmo buraco de sequência
 * que esta release existe para fechar, agora vindo do próprio conserto.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$selo_do_503 = str_repeat( 'e5', 16 );

/*
 * O BANCO RECUSA A ESCRITA, e a bancada o reproduz do jeito que o site o vive:
 * a prontidão da tabela já foi medida NESTA requisição — ela é memorizada de
 * propósito, para não repetir a consulta — e a tabela some depois disso. É
 * exatamente a corrida real: a rota passa da guarda de prontidão e o `INSERT`
 * volta falso. Zerar o memo aqui mediria o outro ramo, o do 503 por tabela
 * ausente, que já tem piso próprio logo acima.
 */
postar_comportamento( carga_selada( str_repeat( '9', 32 ) ) );

$tabela_que_some = F3Base_Modulo_Comportamento::nome_tabela();
$linhas_gravadas = $wpdb->tabelas[ $tabela_que_some ];

unset( $wpdb->tabelas[ $tabela_que_some ] );

$falhou = postar_comportamento( carga_selada( $selo_do_503 ) );

afirmar(
	$nome,
	503 === $falhou->status && 'f3base_gravacao_indisponivel' === (string) $falhou->data['codigo'],
	'teto da bancada: com a escrita recusada pelo banco a rota respondeu ' . $falhou->status . ', e o esperado é 503'
);

$wpdb->tabelas[ $tabela_que_some ] = $linhas_gravadas;

$retentativa = postar_comportamento( carga_selada( $selo_do_503 ) );

afirmar(
	$nome,
	201 === $retentativa->status && 1 === (int) $retentativa->data['registro'],
	'PISO da compensação: a retentativa do lote cuja escrita falhou respondeu ' . $retentativa->status .
		' com ' . (int) ( $retentativa->data['registro'] ?? 0 ) . ' linha(s) de registro. O selo é reservado antes da escrita e DEVOLVIDO quando nada foi gravado: ' .
		'sem essa compensação, o lote fica marcado como recebido sobre um banco que o recusou, e a retentativa é respondida "já tenho isto" sobre nada'
);

/*
 * TETO DO SELO AUSENTE: sem gerador criptográfico o navegador não tem selo, e o
 * corpo continua entrando. É a mesma escolha já feita para o pseudônimo
 * ausente: recusar por causa dele trocaria medição parcial por medição nenhuma.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$sem_selo = postar_comportamento( carga_selada( '', array( 'lote' => '' ) ) );

afirmar(
	$nome,
	201 === $sem_selo->status && 1 === (int) $sem_selo->data['registro'],
	'teto do selo ausente: sem selo o corpo foi recusado — status ' . $sem_selo->status .
		'. Sem gerador criptográfico não há selo, e também não há apelido nem visita gravada: não existe retentativa para deduplicar, e recusar aqui seria trocar medição parcial por medição nenhuma'
);

/* PISO: selo fora da forma fechada é recusado pelo nome, como os apelidos. */
$selo_torto = postar_comportamento( carga_selada( 'lote-de-joao@exemplo.test' ) );

afirmar(
	$nome,
	400 === $selo_torto->status && 'f3base_pseudonimo_invalido' === (string) $selo_torto->data['codigo'] && 'lote' === (string) $selo_torto->data['campo'],
	'piso do selo: o selo aceitou um valor fora do hexadecimal sorteado. É a mesma forma fechada dos apelidos, e pela mesma razão — um campo que aceitasse texto livre aceitaria um e-mail'
);

/*
 * A JANELA DO SELO É A MESMA DA VISITA, e as duas pontas leem a MESMA
 * declaração. Um número escrito de um lado divergiria do outro na primeira vez
 * que alguém mexesse num só, e a divergência apareceria como linha contada duas
 * vezes: o cliente reenviando um lote cujo selo o servidor já esqueceu.
 */
$janela_declarada = 0;

foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $declaracao_da_janela ) {
	if ( 'pagina' === (string) $declaracao_da_janela['gatilho'] ) {
		$janela_declarada = (int) ( $declaracao_da_janela['limiar']['inatividade_min'][0] ?? 0 );
	}
}

afirmar(
	$nome,
	$janela_declarada > 0 && F3Base_Modulo_Comportamento::janela_da_visita() === $janela_declarada * MINUTE_IN_SECONDS,
	'piso da janela: a janela do selo é ' . F3Base_Modulo_Comportamento::janela_da_visita() . 's e a declarada em inatividade_min é ' .
		$janela_declarada . ' min. Ela responde, dos dois lados, à mesma pergunta — até quando duas coisas ainda são a mesma visita —, e um número escrito aqui seria a segunda verdade que diverge sozinha'
);

/*
 * PISO DO CORTE GRAVADO — e este é o que a tela precisa.
 *
 * O corte sempre foi nosso e sempre foi contado, e saía NOMEADO na resposta da
 * rota. Só que a resposta morre no navegador: quem abre o menu Medição via uma
 * tabela e não tinha como saber que faltava alguma coisa nela, e somava achando
 * que tinha tudo.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

postar_comportamento( carga_selada( str_repeat( 'f6', 16 ), array( 'cortados' => 3 ) ) );

$com_corte = F3Base_Modulo_Comportamento::resumo();

afirmar(
	$nome,
	3 === (int) $com_corte['cortadas'],
	'PISO do corte gravado: o resumo do período diz ' . (int) $com_corte['cortadas'] .
		' cortada(s), e o corpo declarou 3. O corte que só existe na resposta da rota morre no navegador, e quem lê a tabela soma achando que tem tudo'
);

afirmar(
	$nome,
	1 === (int) $com_corte['total'],
	'PISO do corte gravado: o descarte entrou no TOTAL do período (' . (int) $com_corte['total'] .
		'). Somá-lo ao total faria a tela afirmar ter recebido justamente o que se perdeu'
);

afirmar(
	$nome,
	array() !== $com_corte['cortadas_paginas'] && '/pagina-de-bancada/' === (string) $com_corte['cortadas_paginas'][0]['caminho'],
	'PISO do corte gravado: o descarte saiu sem o caminho em que aconteceu. Descarte concentrado numa página é outra conversa que descarte espalhado, e sem o caminho as duas são o mesmo número'
);

foreach ( F3Base_Modulo_Comportamento::resumo_por_evento() as $por_evento_com_corte ) {
	afirmar(
		$nome,
		F3Base_Modulo_Comportamento::METRICA_CORTADAS !== (string) $por_evento_com_corte['evento'],
		'PISO do corte gravado: o descarte apareceu na lista de EVENTOS. Ninguém "cortou" nada — foi o pacote que descartou —, e listá-lo entre os acionamentos faz quem lê somar descarte com acontecimento'
	);
}

/*
 * O BALDE CABE UMA VISITA INTEIRA, e o número não é novo: ele é o teto de
 * linhas que uma visita pode escrever. Sessenta por dez minutos nasceu quando o
 * envio era UM por sessão de página; com envio por lote, e atrás de CDN — com
 * `f3base_origem_confiavel` vazia, que é o caso medido —, a origem é a mesma
 * para todo mundo e um leitor atento esgotava o balde do site inteiro.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$status_no_balde = array();

for ( $i = 0; $i < 3; $i++ ) {
	$status_no_balde[] = postar_comportamento( carga_selada( str_repeat( (string) $i, 32 ) ) )->status;
}

afirmar(
	$nome,
	array( 201, 201, 201 ) === $status_no_balde,
	'teto do balde: três lotes seguidos da mesma origem devolveram ' . implode( ', ', $status_no_balde ) .
		'. O balde precisa caber uma visita inteira: um teto que recusa o leitor mais atento do site antes de recusar qualquer abuso não está protegendo nada'
);

/*
 * A TRAVA DA MIGRAÇÃO CAI NO SUCESSO. Ela existe para impedir requisições
 * simultâneas de dispararem `dbDelta` umas por cima das outras, e não para
 * castigar o site pela falha: os quinze minutos que estavam ali punham o site
 * em quinze minutos de 503 sem uma única nova tentativa no meio, e o transiente
 * foi medido VIVO em `fator3-teste-mcp-1`.
 */
bancada_limpa();
requisicao_nova();
unset( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela() ] );
unset( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela_eventos() ] );

$reflexo_da_migracao = new ReflectionProperty( 'F3Base_Modulo_Comportamento', 'tabela_pronta' );
$reflexo_da_migracao->setAccessible( true );
$reflexo_da_migracao->setValue( null, null );

( new F3Base_Modulo_Comportamento() )->garantir_estrutura();

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::tabela_pronta() && false === get_transient( 'f3base_comportamento_migrando' ),
	'PISO da trava da migração: criada a estrutura, a trava continuou de pé. Ela é trava da TENTATIVA, e não espera pelo fracasso: mantida, o site fica preso a um prazo que já não protege nada'
);

/* ==========================================================================
 * tela.campo_diz_impacto_e_exemplo
 *
 * A TELA É MEDIDA NO DOM QUE O OPERADOR RECEBE, e não no arquivo que a produz.
 * O que se cobra: todo campo operável renderiza rótulo, impacto e exemplo; o
 * exemplo NÃO entra no `value` nem em `placeholder`; e a ordem dos blocos é a
 * declarada, com o preenchimento antes da observação.
 * ======================================================================= */

$nome = 'tela.campo_diz_impacto_e_exemplo';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

ob_start();
F3Base_Admin_Tela::render();
$html_configuracoes = (string) ob_get_clean();
$_GET['aba'] = 'tecnica';
ob_start(); F3Base_Admin_Tela::render(); $html_tecnica = (string) ob_get_clean();
unset( $_GET['aba'] );
afirmar( $nome, ! str_contains( $html_configuracoes, 'Estado das partes do plugin' ) && ! str_contains( $html_tecnica, 'class="f3base-form"' ), 'Abas não separam formulário e diagnóstico.' );
$html_da_tela = $html_configuracoes . $html_tecnica;

afirmar(
	$nome,
	'' !== $html_da_tela,
	'piso da bancada: a tela não produziu HTML nenhum, e sem HTML nada abaixo mede o que promete'
);

$folhas_da_tela = F3Base_Options::folhas_operaveis();

afirmar(
	$nome,
	array() !== $folhas_da_tela,
	'piso da bancada: o catálogo não declarou folha operável nenhuma — escopo vazio não aprova'
);

foreach ( $folhas_da_tela as $folha ) {
	$identificador = '' === $folha['chave'] ? $folha['option'] : $folha['option'] . '.' . $folha['chave'];
	$declaracao    = $folha['declaracao'];

	$posicao = strpos( $html_da_tela, 'data-f3base-campo="' . $identificador . '"' );

	afirmar(
		$nome,
		false !== $posicao,
		'teto: o campo operável "' . $identificador . '" não aparece na tela. Campo declarado operável e ausente do formulário é uma chave que o operador não tem como gravar'
	);

	if ( false === $posicao ) {
		continue;
	}

	$fim    = strpos( $html_da_tela, 'data-f3base-campo="', $posicao + 20 );
	$trecho = false === $fim ? substr( $html_da_tela, $posicao ) : substr( $html_da_tela, $posicao, $fim - $posicao );

	foreach ( array( 'rotulo' => 'f3base-rotulo', 'impacto' => 'f3base-impacto', 'exemplo' => 'f3base-exemplo' ) as $peca => $classe ) {
		afirmar(
			$nome,
			str_contains( $trecho, $classe ),
			'teto: o campo "' . $identificador . '" não renderiza o ' . $peca . '. Rótulo é o nome do campo, impacto é o que muda no site quando ele é preenchido, e exemplo é a forma esperada — os três, em todo campo'
		);
	}

	foreach ( array( 'impacto', 'exemplo' ) as $peca ) {
		$texto = isset( $declaracao[ $peca ] ) ? (string) $declaracao[ $peca ] : '';

		afirmar(
			$nome,
			'' !== $texto && str_contains( $trecho, esc_html( $texto ) ),
			'teto: o ' . $peca . ' declarado de "' . $identificador . '" não chegou ao HTML — texto no catálogo que a tela não imprime é documentação que ninguém lê'
		);
	}
}

/* PISO DO VALOR FANTASMA: o exemplo não entra em placeholder nem em value. */
afirmar(
	$nome,
	! str_contains( $html_da_tela, 'placeholder=' ),
	'piso do valor fantasma: a tela usa placeholder. Ele some quando o operador digita, volta quando ele apaga, e é lido como conteúdo do campo — é a forma mais barata de fazer alguém sair da tela achando que gravou o que não gravou'
);

preg_match_all( '/value="([^"]*)"/', $html_da_tela, $valores_da_tela );

foreach ( $folhas_da_tela as $folha ) {
	$exemplo_da_folha = isset( $folha['declaracao']['exemplo'] ) ? (string) $folha['declaracao']['exemplo'] : '';

	if ( '' === $exemplo_da_folha ) {
		continue;
	}

	$dentro_do_value = false;

	foreach ( $valores_da_tela[1] as $valor_no_html ) {
		if ( '' !== $valor_no_html && str_contains( esc_html( $exemplo_da_folha ), $valor_no_html ) && strlen( $valor_no_html ) > 3 ) {
			$dentro_do_value = true;
		}
	}

	afirmar(
		$nome,
		! $dentro_do_value,
		'piso do valor fantasma: o exemplo de "' . $folha['option'] . '" apareceu dentro de um value do formulário — exemplo dentro do campo é valor que o operador acha que está gravado'
	);
}

/* TETO DA ORDEM: os blocos saem na ordem declarada, preenchimento antes de leitura. */
preg_match_all( '/data-f3base-bloco="([^"]+)"/', $html_da_tela, $blocos_no_dom );

afirmar(
	$nome,
	F3Base_Admin_Tela::ordem_dos_blocos() === $blocos_no_dom[1],
	'teto da ordem: a ordem dos blocos no DOM é [' . implode( ', ', $blocos_no_dom[1] ) . '] e a declarada é [' . implode( ', ', F3Base_Admin_Tela::ordem_dos_blocos() ) . ']. A ordem é a de instalar um site, e ela é declarada num lugar só'
);

$posicao_do_formulario = strpos( $html_da_tela, 'data-f3base-bloco="' . F3Base_Options::SECAO_CONTATO . '"' );
$posicao_do_diagnostico = strpos( $html_da_tela, 'data-f3base-bloco="' . F3Base_Admin_Tela::BLOCO_DIAGNOSTICO . '"' );

afirmar(
	$nome,
	false !== $posicao_do_formulario && false !== $posicao_do_diagnostico && $posicao_do_formulario < $posicao_do_diagnostico,
	'teto da ordem: o diagnóstico vem antes dos campos. Ele continua inteiro, e continua sendo o que o suporte lê — só deixou de ser a primeira coisa que quem vem preencher um número encontra'
);

/* TETO: o diagnóstico continua COMPLETO — nada saiu com a reorganização. */
foreach ( array( 'Estado das partes do plugin', 'f3base-modulo', 'f3base-hooks', 'f3base-resumo' ) as $peca_do_diagnostico ) {
	afirmar(
		$nome,
		str_contains( substr( $html_da_tela, (int) $posicao_do_diagnostico ), $peca_do_diagnostico ),
		'teto do diagnóstico: "' . $peca_do_diagnostico . '" sumiu da tela. O diagnóstico mudou de lugar, não de tamanho'
	);
}

/* TETO: a marca de origem por option e a leitura de volta continuam. */
afirmar(
	$nome,
	str_contains( $html_da_tela, 'f3base-origem' ),
	'teto: a marca de origem da última gravação sumiu de cada campo'
);

afirmar(
	$nome,
	str_contains( $html_da_tela, 'sem campo nesta tela: é ajuste estrutural' ),
	'teto: a tela deixou de distinguir o que tem campo de edição do que não tem'
);

/* PISO DA CAPABILITY: sem manage_options, a tela não renderiza e não grava. */
$GLOBALS['f3b_bench']['pode'] = false;

$morreu_ao_ver = false;

try {
	ob_start();
	F3Base_Admin_Tela::render();
	ob_end_clean();
} catch ( RuntimeException $erro_da_tela ) {
	$morreu_ao_ver = str_contains( $erro_da_tela->getMessage(), 'wp_die:403' );
}

afirmar(
	$nome,
	$morreu_ao_ver,
	'piso da capability: a tela renderizou para quem não tem manage_options'
);

$morreu_ao_gravar = false;

try {
	F3Base_Admin_Tela::salvar();
} catch ( RuntimeException $erro_da_gravacao ) {
	$morreu_ao_gravar = str_contains( $erro_da_gravacao->getMessage(), 'wp_die:403' );
}

afirmar(
	$nome,
	$morreu_ao_gravar,
	'piso da capability: a GRAVAÇÃO aceitou quem não tem manage_options. Ver a tela e escrever nela são duas permissões, e a segunda é a que muda o site'
);

$GLOBALS['f3b_bench']['pode'] = true;

/* PISO DO SEGREDO: o token traz "Onde obter", nunca "Exemplo" com valor. */
foreach ( F3Base_Options::segredos_do_site() as $segredo_do_site ) {
	if ( ! F3Base_Options::operavel( $segredo_do_site ) ) {
		continue;
	}

	$posicao_do_segredo = strpos( $html_da_tela, 'data-f3base-campo="' . $segredo_do_site . '"' );

	afirmar(
		$nome,
		false !== $posicao_do_segredo && str_contains( substr( $html_da_tela, (int) $posicao_do_segredo, 4000 ), 'Onde obter' ),
		'piso do segredo: o campo "' . $segredo_do_site . '" apresenta o texto como EXEMPLO em vez de dizer ONDE OBTER. Segredo não tem exemplo de valor, e a marca precisa dizer isso em vez de fingir'
	);
}

/* ==========================================================================
 * medicao.menu_proprio
 *
 * O MENU MEDIÇÃO, medido no DOM que o operador recebe.
 *
 * A TELA FOI CORTADA PELO USUÁRIO depois de vê-la, e o que sobrou é o que ele
 * pediu: a TABELA BRUTA DE ACIONAMENTOS — uma linha por vez que algo foi
 * acionado, com visitante, visita, data, horário, página e o gatilho em
 * português comum —, a profundidade por página, e as saídas para fora. Saíram
 * profundidade em bloco próprio, fricção, carregamento, erros de JavaScript,
 * páginas com mais registro e "o que não está nesta tela".
 *
 * BLOCO CORTADO É BLOCO REMOVIDO, e não escondido: um quadro vazio ocupa a
 * atenção de quem abre a tela e não responde nada. É o que o piso mede.
 *
 * O VAZIO CONTINUA SENDO RESPOSTA: site novo não tem dado, e uma tabela de
 * zeros parece medição feita.
 * ======================================================================= */

$nome = 'medicao.menu_proprio';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

ob_start();
F3Base_Admin_Medicao::render();
$medicao_vazia = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $medicao_vazia, 'Ainda não há nenhuma visita registrada' )
		&& str_contains( $medicao_vazia, 'ausência de registro' ),
	'TETO do vazio: com zero registro a tela não diz que não há dado nenhum, e que isso é ausência de REGISTRO e não audiência zero'
);

afirmar(
	$nome,
	! str_contains( $medicao_vazia, 'f3base-totais' ),
	'PISO do vazio: a tela montou tabela sem ter dado nenhum'
);

/*
 * A TELA DIZ QUEM É CONTADO SEM PROMETER CONSENTIMENTO, e esta é a frase medida.
 *
 * O DEFEITO: ela afirmava, em todo site, que os números contavam "só as sessões
 * com consentimento" — uma descrição do modo de NEGATIVA POR PADRÃO escrita como
 * se valesse sempre. No modo PRÉ-APROVADO, que é o padrão deste pacote, ninguém
 * consentiu nada: a medição começa na chegada por decisão declarada do projeto,
 * e quem lia aquela frase concluía que estava vendo só quem tinha dito sim.
 *
 * A FORMA VERDADEIRA É EXIGIDA AQUI EM DUAS METADES, e as duas importam: a tela
 * diz que contam as sessões em que a POLÍTICA VIGENTE permitiu medir — com a
 * política nomeada, lida do módulo de consentimento — e diz QUEM FICA DE FORA,
 * que é quem recusou no controle do rodapé. Sem a segunda metade a frase deixa
 * de responder à única pergunta que o leitor tem sobre o recorte.
 *
 * A frase tem produtor único no módulo, e é de lá que ela vem — escrita aqui,
 * seria a terceira descrição da mesma política.
 */
afirmar(
	$nome,
	str_contains( $medicao_vazia, F3Base_Modulo_Comportamento::quem_e_contado() ),
	'TETO da política declarada: a tela não traz a frase do módulo sobre quem é contado — e sem ela afirma um recorte que a coleta pode não ter feito'
);

afirmar(
	$nome,
	str_contains( $medicao_vazia, 'a política vigente (pre-aprovado) permitiu medir' )
		&& str_contains( $medicao_vazia, 'quem recusou no controle do rodapé fica de fora' ),
	'TETO da frase verdadeira: a tela não diz que contam as sessões em que a POLÍTICA VIGENTE permitiu medir, nomeando-a, nem diz que quem recusou no controle do rodapé fica de fora. Dizer "sessões com consentimento" num site pré-aprovado é afirmar uma decisão do visitante que não houve'
);

afirmar(
	$nome,
	! str_contains( $medicao_vazia, 'com consentimento' ),
	'PISO da frase verdadeira: a tela voltou a prometer consentimento onde há política declarada do projeto'
);

F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'negado' ), F3Base_Options::ORIGEM_MANUAL );

ob_start();
F3Base_Admin_Medicao::render();
$medicao_com_opt_in = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $medicao_com_opt_in, F3Base_Modulo_Comportamento::quem_e_contado() )
		&& str_contains( $medicao_com_opt_in, 'a política vigente (negado) permitiu medir' )
		&& ! str_contains( $medicao_com_opt_in, '(pre-aprovado)' ),
	'PISO da política declarada: trocada a política do site, a tela continuou dizendo a mesma coisa. Frase fixa sobre uma política que muda é a tela descrevendo outro site'
);

F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'pre-aprovado' ), F3Base_Options::ORIGEM_MANUAL );

/*
 * O CONTROLE PRECISA SER ENCONTRÁVEL. O pedido: *"Permita também que essa
 * medição possa ser desativada na área de configuração do plugin."* A chave já
 * existia — `f3base_comportamento.ligado`, na privacidade — e não ganhou irmã:
 * o que faltava era quem abre esta tela saber que ela existe e onde fica.
 */
$ancora_do_controle = F3Base_Admin_Tela::id_do_subcampo( 'f3base_comportamento', 'ligado' );

afirmar(
	$nome,
	str_contains( $medicao_vazia, '#' . $ancora_do_controle ),
	'TETO do controle encontrável: a tela Medição não leva ao lugar onde a medição se desliga. Quem abre esta tela não tem por que adivinhar que a chave que a desliga mora na tela ao lado, embaixo de um título sobre privacidade'
);

afirmar(
	$nome,
	str_contains( $html_da_tela, 'id="' . $ancora_do_controle . '"' ),
	'PISO do controle encontrável: a âncora para onde a tela Medição aponta não existe na tela de configuração. Link que continua existindo e deixa de levar a lugar nenhum é pior que link nenhum, porque ninguém o vê quebrar'
);

/*
 * PISO DO DESLIGAMENTO NOMEADO: com a medição desligada, a PRIMEIRA coisa da
 * tela é o desligamento — e não uma tela sem número nenhum, que é
 * indistinguível de um site sem visita.
 */
F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => false ), F3Base_Options::ORIGEM_MANUAL );

ob_start();
F3Base_Admin_Medicao::render();
$medicao_desligada = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $medicao_desligada, 'A medição está desligada nesta instalação' )
		&& str_contains( $medicao_desligada, 'Nada é coletado e nada é guardado' ),
	'PISO do desligamento nomeado: com a medição desligada a tela não diz que está desligada. Tabela vazia sem explicação devolve o operador ao ponto de partida — ele não tem como saber se o site não teve visita ou se ninguém está medindo'
);

afirmar(
	$nome,
	str_contains( $medicao_desligada, '#' . $ancora_do_controle ),
	'PISO do desligamento nomeado: a tela diz que a medição está desligada e não diz onde ligá-la de volta'
);

$posicao_do_desligamento = strpos( $medicao_desligada, 'A medição está desligada nesta instalação' );
$primeiro_quadro         = strpos( $medicao_desligada, '<h2>' );

afirmar(
	$nome,
	false !== $posicao_do_desligamento
		&& ( false === $primeiro_quadro || $posicao_do_desligamento < $primeiro_quadro ),
	'PISO do desligamento nomeado: a frase do desligamento aparece DEPOIS do primeiro quadro da tela. Ela é a resposta à primeira pergunta de quem abre uma tela de medição sem números, e por isso vem antes deles'
);

afirmar(
	$nome,
	! str_contains( $medicao_desligada, 'f3base-totais' ),
	'PISO do desligamento nomeado: com a medição desligada a tela montou tabela. Sem coleta a tabela só pode estar vazia, e tabela vazia silenciosa é o que esta tela existe para não fazer'
);

afirmar(
	$nome,
	str_contains( $medicao_desligada, 'A coleta está DESLIGADA' )
		&& str_contains( $medicao_desligada, 'Privacidade e retenção' ),
	'PISO do que falta: com a coleta desligada a tela não nomeou a falta com o lugar de resolvê-la. Tela que só diz "sem dados" devolve o operador ao ponto de partida'
);

F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true ), F3Base_Options::ORIGEM_MANUAL );

/*
 * A TABELA BRUTA, com o caso que o usuário descreveu: o MESMO visitante, na
 * MESMA visita, acionando o MESMO bloco três vezes.
 */
$visitante_da_tela = str_repeat( 'ab12', 8 );
$visita_da_tela    = str_repeat( 'cd34', 8 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/home/',
			'visitante' => $visitante_da_tela,
			'sessao'    => $visita_da_tela,
			'metricas'  => array( array( 'gatilho' => 'interseccao', 'detalhe' => 'abertura', 'contagem' => 1 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'interseccao', 'detalhe' => 'abertura', 'ocorrencia' => 1, 'ms' => 1000 ),
				array( 'gatilho' => 'interseccao', 'detalhe' => 'abertura', 'ocorrencia' => 2, 'ms' => 9000 ),
				array( 'gatilho' => 'interseccao', 'detalhe' => 'abertura', 'ocorrencia' => 3, 'ms' => 21000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 500 ),
			),
		)
	)
);

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_acionamentos = (string) ob_get_clean();

$acionamentos_lidos = F3Base_Modulo_Comportamento::acionamentos();

afirmar(
	$nome,
	4 === count( $acionamentos_lidos['linhas'] ) && 4 === (int) $acionamentos_lidos['total'],
	'TETO da tabela bruta: a leitura devolveu ' . count( $acionamentos_lidos['linhas'] ) . ' linha(s) para quatro acionamentos gravados. É uma linha POR ACIONAMENTO, inclusive quando é o mesmo visitante na mesma visita no mesmo bloco — foi esse o pedido'
);

/*
 * A ORDEM É DO MAIS RECENTE PARA O MAIS ANTIGO. Numa tabela que cresce por
 * acionamento, a linha que interessa é a última, e ela precisa estar em cima.
 */
/*
 * A ORDEM É MEDIDA NO DESEMPATE, e não só no carimbo: quatro acionamentos de uma
 * visita caem no mesmo segundo, e uma asserção sobre o carimbo sozinho passaria
 * com a ordem invertida — foi o que aconteceu na primeira versão deste piso.
 */
$chaves_lidas = array_map(
	static fn ( array $linha ): array => array( (int) $linha['criado_em'], (int) $linha['id'] ),
	$acionamentos_lidos['linhas']
);
$em_ordem = $chaves_lidas;
usort(
	$em_ordem,
	static function ( array $a, array $b ): int {
		$por_carimbo = $b[0] <=> $a[0];

		return 0 !== $por_carimbo ? $por_carimbo : ( $b[1] <=> $a[1] );
	}
);

afirmar(
	$nome,
	$chaves_lidas === $em_ordem,
	'TETO da ordem: a tabela bruta não sai do mais recente para o mais antigo. Numa tabela que cresce por acionamento, a linha que interessa é a última — e dentro do mesmo segundo quem ordena é o desempate, não o carimbo'
);

/* O GATILHO EM PORTUGUÊS COMUM, e a frase sai da DECLARAÇÃO. */
afirmar(
	$nome,
	str_contains( $tela_com_acionamentos, 'bloco abertura' ) && str_contains( $tela_com_acionamentos, 'passou de 25%' ),
	'TETO do português comum: a tabela imprime o nome técnico do gatilho em vez de "bloco abertura" e "passou de 25%". O operador não tem obrigação de saber o que é f3base_secao_vista'
);

afirmar(
	$nome,
	str_contains( $tela_com_acionamentos, '1ª' ) && str_contains( $tela_com_acionamentos, '3ª' ),
	'TETO da vez: a tabela não mostra qual passagem foi cada linha. É a coluna que distingue a leitura da releitura, e sem ela três linhas iguais parecem defeito'
);

/*
 * A COLUNA DIZ SOBRE QUE JANELA ELA CONTA, e isso é da 1.3.4. O contador de
 * travessias passou a viver na VISITA, atravessando carregamentos: sem uma
 * frase dizendo isso, quem abre a tabela lê "1ª" e "2ª" e não sabe se a
 * segunda é a mesma página relida ou a mesma pessoa voltando de outra página —
 * e soma errado nos dois sentidos.
 */
afirmar(
	$nome,
	str_contains( $tela_com_acionamentos, 'passagens DA VISITA INTEIRA' )
		&& str_contains( $tela_com_acionamentos, 'recomeça na 1ª' ),
	'TETO da janela da vez: a tela não diz, em português comum, que a coluna "vez" conta as passagens DA VISITA e não as de um carregamento, nem que cada endereço tem a contagem dele. Coluna que não declara a própria janela é coluna que cada leitor soma de um jeito'
);

afirmar(
	$nome,
	str_contains( $tela_com_acionamentos, substr( $visitante_da_tela, 0, 8 ) )
		&& str_contains( $tela_com_acionamentos, substr( $visita_da_tela, 0, 8 ) ),
	'TETO da identificação: a tabela não mostra o apelido do visitante e o da visita, que é como o usuário pediu que as linhas fossem identificadas'
);

/* O FILTRO por visitante é o que torna a tabela utilizável com tráfego. */
postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/home/',
			'visitante' => str_repeat( 'ef56', 8 ),
			'sessao'    => str_repeat( '7890', 8 ),
			'eventos'   => array( array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'ocorrencia' => 1, 'ms' => 700 ) ),
		)
	)
);

$so_do_primeiro = F3Base_Modulo_Comportamento::acionamentos( array( 'visitante' => $visitante_da_tela ) );

afirmar(
	$nome,
	4 === (int) $so_do_primeiro['total'],
	'TETO do filtro: filtrando por um visitante vieram ' . (int) $so_do_primeiro['total'] . ' de 4 acionamentos dele. Sem filtro, esta tela fica inútil no primeiro site com tráfego'
);

$so_da_visita = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $visita_da_tela ) );

afirmar(
	$nome,
	4 === (int) $so_da_visita['total'],
	'TETO do filtro por visita: vieram ' . (int) $so_da_visita['total'] . ' de 4'
);

/* A PAGINAÇÃO existe e corta de verdade. */
$primeira_pagina = F3Base_Modulo_Comportamento::acionamentos( array( 'limite' => 2, 'salto' => 0 ) );
$segunda_pagina  = F3Base_Modulo_Comportamento::acionamentos( array( 'limite' => 2, 'salto' => 2 ) );

afirmar(
	$nome,
	2 === count( $primeira_pagina['linhas'] )
		&& 2 === count( $segunda_pagina['linhas'] )
		&& 5 === (int) $primeira_pagina['total']
		&& $primeira_pagina['linhas'][0]['criado_em'] >= $segunda_pagina['linhas'][0]['criado_em'],
	'TETO da paginação: a leitura não pagina, ou o total não reflete o conjunto inteiro. Uma linha por acionamento cresce rápido, e uma tela que despejasse tudo seria inútil onde ela mais importa'
);

/*
 * PISO DA FONTE ÚNICA DA FRASE: nenhuma frase de gatilho pode estar escrita
 * dentro do PHP da tela. Escrita ali, ela vira uma segunda descrição do mesmo
 * evento e diverge da declaração na primeira edição apressada.
 */
$fonte_da_tela_de_medicao = (string) file_get_contents( $raiz . '/fontes/plugin/admin/class-f3base-admin-medicao.php' );

foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $evento_declarado => $declaracao_do_evento ) {
	$frase_declarada = (string) ( $declaracao_do_evento['frase'] ?? '' );

	afirmar(
		$nome,
		'' !== $frase_declarada,
		'TETO da frase: o evento ' . $evento_declarado . ' não declara como aparece na tabela, e a tela cai no nome técnico'
	);

	afirmar(
		$nome,
		'' === $frase_declarada || ! str_contains( $fonte_da_tela_de_medicao, $frase_declarada ),
		'PISO da fonte única: a frase do evento ' . $evento_declarado . ' está escrita dentro do PHP da tela. Ela mora na declaração dos eventos — duas descrições do mesmo evento divergem sem que nada acuse'
	);
}

/*
 * PISO DO CORTE DA TELA: o que o usuário tirou não pode voltar como bloco
 * vazio. Quadro que não responde nada ocupa a atenção de quem abre a tela.
 */
/*
 * A LISTA MUDOU, e a mudança é a decisão do usuário e não uma leitura minha.
 *
 * "Páginas com mais registro" saiu da lista de proibidos porque o quadro de
 * página VOLTOU — mas voltou respondendo outra pergunta. O antigo somava toda a
 * atividade: uma página longa e lida até o fim produzia mais registro que uma
 * curta com o mesmo público, e o número não respondia nada. O novo conta
 * ABERTURAS e PESSOAS, que é o que ele pediu. A proibição virou exigência de
 * forma, logo abaixo, em vez de sumir.
 *
 * Os outros quatro continuam fora.
 */
foreach (
	array(
		'Pessoas diferentes, por dia',
		'Como a página carrega',
		'O que não está nesta tela',
		'O que aconteceu nas páginas',
	) as $bloco_cortado
) {
	afirmar(
		$nome,
		! str_contains( $tela_com_acionamentos, $bloco_cortado ),
		'PISO do corte: o bloco "' . $bloco_cortado . '" voltou à tela. O usuário o tirou depois de vê-la, e bloco cortado é bloco REMOVIDO — não escondido, não vazio'
	);
}

/* OS TRÊS QUE FICAM continuam lá. */
foreach (
	array(
		'Cada acionamento, um por linha',
		'Quantas vezes cada página foi visitada',
		'Até onde as pessoas descem, em cada página',
		'Saídas para fora do site',
	) as $bloco_que_fica
) {
	afirmar(
		$nome,
		str_contains( $tela_com_acionamentos, $bloco_que_fica ),
		'TETO do que fica: o bloco "' . $bloco_que_fica . '" sumiu da tela. O corte tirou o que o usuário rejeitou, e não o que ele pediu'
	);
}

/*
 * A AMOSTRA DO SITE REAL: carregamento é MAIORIA. Trinta das sessenta e duas
 * linhas do primeiro site eram medida técnica, e elas dominavam a ordenação por
 * horário — quem abria a tabela via TTFB, CLS e LCP empurrando para baixo a
 * rolagem e os blocos que tinha ido procurar, e concluía que o coletor estava
 * quebrado. O dado estava lá; o que faltava era ele aparecer.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$eventos_da_amostra = array();

foreach ( array( 'TTFB', 'CLS', 'LCP', 'INP', 'TTFB', 'CLS', 'LCP' ) as $vital_da_amostra ) {
	$eventos_da_amostra[] = array( 'gatilho' => 'desempenho', 'detalhe' => $vital_da_amostra, 'ocorrencia' => 1, 'ms' => 400 );
}

$eventos_da_amostra[] = array( 'gatilho' => 'pagina', 'ocorrencia' => 1, 'ms' => 10 );
$eventos_da_amostra[] = array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 2000 );
$eventos_da_amostra[] = array( 'gatilho' => 'interseccao', 'detalhe' => 'abertura', 'ocorrencia' => 1, 'ms' => 2500 );
$eventos_da_amostra[] = array( 'gatilho' => 'erro', 'detalhe' => 'app.js', 'ocorrencia' => 1, 'ms' => 3000 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/home/',
			'visitante' => $visitante_da_tela,
			'sessao'    => $visita_da_tela,
			'metricas'  => array( array( 'gatilho' => 'pagina', 'contagem' => 1 ) ),
			'eventos'   => $eventos_da_amostra,
		)
	)
);

$tabela_da_amostra = F3Base_Modulo_Comportamento::acionamentos();
$metricas_na_tabela = array_unique( array_map( static fn ( array $linha ): string => (string) $linha['metrica'], $tabela_da_amostra['linhas'] ) );

$tecnicos_na_tabela = array();

foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $evento_da_amostra => $declaracao_da_amostra ) {
	if ( 'tecnica' === (string) ( $declaracao_da_amostra['natureza'] ?? '' ) && in_array( (string) $evento_da_amostra, $metricas_na_tabela, true ) ) {
		$tecnicos_na_tabela[] = (string) $evento_da_amostra;
	}
}

afirmar(
	$nome,
	array() === $tecnicos_na_tabela,
	'TETO da natureza: a tabela de acionamentos trouxe medição TÉCNICA — ' . implode( ', ', $tecnicos_na_tabela )
		. '. Carregamento e erro de script não são comportamento de uso: eles continuam sendo coletados e continuam no resumo, e dominando a ordenação por horário eles soterram a rolagem e os blocos que o operador foi procurar'
);

afirmar(
	$nome,
	in_array( F3Base_Modulo_Comportamento::evento_do_gatilho( 'rolagem' ), $metricas_na_tabela, true )
		&& in_array( F3Base_Modulo_Comportamento::evento_do_gatilho( 'interseccao' ), $metricas_na_tabela, true ),
	'TETO do que tem de aparecer: numa amostra em que a medição técnica é maioria, a rolagem e o bloco NÃO chegaram à tabela — vieram ' . implode( ', ', $metricas_na_tabela )
		. '. É exatamente o sintoma que o usuário relatou, e a causa era ordenação, não coletor'
);

afirmar(
	$nome,
	3 === count( $tabela_da_amostra['linhas'] ) && 3 === (int) $tabela_da_amostra['total'],
	'TETO da contagem: das onze linhas da amostra, três são comportamento de uso — abertura, rolagem e bloco — e a tabela trouxe ' . count( $tabela_da_amostra['linhas'] ) . '. O total também precisa refletir o filtro, senão a paginação promete páginas que não existem'
);

/*
 * PISO DA CLASSIFICAÇÃO: ela mora na DECLARAÇÃO, e todo evento precisa dela.
 * Sem esta cobrança, um evento novo entraria pelo silêncio — e o silêncio não
 * pode decidir se algo é comportamento de alguém.
 */
$sem_natureza = array();

foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $evento_declarado => $declaracao_do_evento ) {
	if ( ! in_array( (string) ( $declaracao_do_evento['natureza'] ?? '' ), array( 'uso', 'tecnica' ), true ) ) {
		$sem_natureza[] = (string) $evento_declarado;
	}
}

afirmar(
	$nome,
	array() === $sem_natureza,
	'PISO da classificação: estes eventos não declaram se são comportamento de uso ou medição técnica: ' . implode( ', ', $sem_natureza )
		. '. Evento novo entra classificado, ou entra pelo silêncio numa tabela que ninguém decidiu que ele podia ocupar'
);

$naturezas_declaradas = array_unique(
	array_map(
		static fn ( array $declaracao ): string => (string) ( $declaracao['natureza'] ?? '' ),
		F3Base_Modulo_Tracking::eventos_de_comportamento()
	)
);

afirmar(
	$nome,
	2 === count( $naturezas_declaradas ),
	'PISO da classificação: todos os eventos declararam a MESMA natureza (' . implode( ', ', $naturezas_declaradas )
		. '). Uma classificação de um valor só não separa nada — ou a tabela mostra tudo, ou não mostra nada'
);

/*
 * PISO DA FONTE ÚNICA: nenhum nome de evento técnico pode estar escrito no PHP
 * da tela nem no da leitura. A decisão mora na declaração; uma lista de nomes no
 * código envelhece no primeiro evento acrescentado.
 */
$fonte_da_leitura = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-comportamento.php' );

foreach ( F3Base_Modulo_Tracking::eventos_de_comportamento() as $evento_declarado => $declaracao_do_evento ) {
	if ( 'tecnica' !== (string) ( $declaracao_do_evento['natureza'] ?? '' ) ) {
		continue;
	}

	afirmar(
		$nome,
		! str_contains( $fonte_da_tela_de_medicao, (string) $evento_declarado )
			&& ! str_contains( $fonte_da_leitura, (string) $evento_declarado ),
		'PISO da fonte única: o nome do evento técnico ' . $evento_declarado . ' está escrito no código da tela ou da leitura. A decisão de o que aparece na tabela mora na declaração — lista de nomes no PHP envelhece no primeiro evento acrescentado e passa a esconder o errado sem que nada acuse'
	);
}

/*
 * O RODAPÉ DA PAGINAÇÃO APARECE SEMPRE, e é a correção do sintoma: com cem por
 * página e sessenta e duas linhas, nenhum controle surgia — o operador via a
 * tabela e não tinha como saber se estava vendo tudo.
 */
ob_start();
F3Base_Admin_Medicao::render();
$tela_da_amostra = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $tela_da_amostra, 'Mostrando de' ) && str_contains( $tela_da_amostra, 'f3base-paginacao' ),
	'TETO da paginação visível: com poucas linhas o rodapé sumiu. Paginação que só aparece quando transborda deixa quem lê sem saber se está vendo tudo, e foi assim que a tabela pareceu truncada'
);

afirmar(
	$nome,
	str_contains( $tela_da_amostra, 'página 1 de 1' ),
	'TETO da paginação visível: o rodapé não diz em que página o operador está quando tudo cabe numa só'
);

/*
 * O QUADRO DE VISITAS POR PÁGINA VOLTOU, e responde outra pergunta: aberturas e
 * pessoas, não soma de atividade. O antigo somava tudo — uma página longa lida
 * até o fim produzia mais registro que uma curta com o mesmo público.
 */
$visitas_lidas = F3Base_Modulo_Comportamento::visitas_por_pagina();

afirmar(
	$nome,
	1 === count( $visitas_lidas ) && '/home/' === (string) $visitas_lidas[0]['caminho'] && 1 === (int) $visitas_lidas[0]['visitas'] && 1 === (int) $visitas_lidas[0]['pessoas'],
	'TETO das visitas por página: o quadro não conta as aberturas por página. O denominador é o evento de abertura, que existe para isso — contar linhas da tabela daria soma de atividade de novo'
);

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/home/',
			'visitante' => $visitante_da_tela,
			'sessao'    => str_repeat( '4444', 8 ),
			'eventos'   => array( array( 'gatilho' => 'pagina', 'ocorrencia' => 1, 'ms' => 10 ) ),
		)
	)
);

$visitas_do_mesmo = F3Base_Modulo_Comportamento::visitas_por_pagina();

afirmar(
	$nome,
	2 === (int) $visitas_do_mesmo[0]['visitas'] && 1 === (int) $visitas_do_mesmo[0]['pessoas'],
	'PISO das visitas por página: o MESMO visitante abrindo a página duas vezes contou como duas pessoas. A distância entre visitas e pessoas é a única medida de quem volta que esta tela tem'
);

/*
 * O ZERO COM CAUSA das saídas: sem link publicado, o quadro não está zerado —/*
 * O ZERO COM CAUSA das saídas: sem link publicado, o quadro não está zerado —
 * ele não tem o que contar. Foi um zero sem explicação que fez o usuário achar
 * que o coletor estava quebrado.
 */
afirmar(
	$nome,
	str_contains( $tela_com_acionamentos, 'não há o que clicar' ),
	'TETO do zero com causa: sem nenhum link para fora nas páginas publicadas, a tela mostrou um zero seco em vez de dizer que não há o que clicar. A diferença entre "ninguém clicou" e "não há onde clicar" é a diferença entre um número e uma resposta'
);

/* PISO: COM link publicado, a frase muda — senão ela seria desculpa fixa. */
f3b_llms_conteudo(
	900,
	'Parceiros',
	'page',
	'2026-09-01 10:00:00',
	'<p><a href="https://parceiro.test/algo">parceiro</a></p>'
);

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_link = (string) ob_get_clean();

afirmar(
	$nome,
	! str_contains( $tela_com_link, 'não há o que clicar' )
		&& str_contains( $tela_com_link, 'ninguém clicou neles até agora' ),
	'PISO do zero com causa: com link para fora publicado, a tela continuou dizendo que não há o que clicar. A frase precisa sair da MEDIÇÃO do conteúdo, senão ela é desculpa fixa e esconderia um coletor de verdade quebrado'
);

/* ==========================================================================
 * consentimento.estrategia_pela_politica
 *
 * O QUE ESTA CHECAGEM MEDE, e por que ela é da POLÍTICA e não do atributo.
 * Até a 1.1.4 o script de consentimento era enfileirado bloqueante, sempre,
 * com uma justificativa escrita que era legítima e incompleta: *"o `default`
 * do Consent Mode só vale se chegar antes do gtag.js"*. O `gtag.js` não é
 * carregado pelo WordPress — quem o injeta é o carregador de tags deste
 * pacote, que é `defer` no rodapé e declara dependência deste handle. Entre
 * dois `defer` a ordem do documento vale, e `js.ordem_do_consentimento` mede
 * isso rodando os dois clientes reais: a linha do tempo com o consentimento
 * bloqueante é a MESMA que com ele adiado.
 *
 * O que sobrou de verdadeiro na justificativa é o modo OPT-IN, e é ele que
 * esta checagem protege: ali o `default` é `denied`, `defer` não ordena
 * `async`, e um emissor concorrente disparando antes do `denied` é o primeiro
 * `page_view` de quem ainda não consentiu.
 * ======================================================================= */

$nome = 'consentimento.estrategia_pela_politica';

bancada_limpa();

/* TETO do modo padrão: pré-aprovado sai ADIADO, e continua no cabeçalho. */
F3Base_Options::gravar(
	'f3base_consentimento',
	array(
		'padrao'                => 'pre-aprovado',
		'controle_rodape'       => true,
		'aviso_primeira_visita' => false,
		'ttl_dias'              => 180,
	),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar(
	$nome,
	'defer' === F3Base_Modulo_Consentimento::estrategia_de_carga( 'pre-aprovado' ),
	'teto do modo padrão: a política pré-aprovada não devolveu defer. É o modo do template, e é dele que saem os 5.085 bytes gzip do caminho crítico do parser'
);

( new F3Base_Modulo_Consentimento() )->enfileirar();

$enfileirado_pre = $GLOBALS['f3b_bench']['scripts'][ F3Base_Modulo_Consentimento::HANDLE ] ?? array();

afirmar(
	$nome,
	'defer' === (string) ( $enfileirado_pre['args']['strategy'] ?? '' ),
	'teto do modo padrão: o script foi enfileirado sem strategy defer — a decisão da política não chegou ao enfileiramento, e o que decide o HTML é o enfileiramento'
);

afirmar(
	$nome,
	false === ( $enfileirado_pre['args']['in_footer'] ?? null ),
	'teto do modo padrão: o script saiu do cabeçalho. É a POSIÇÃO NO DOCUMENTO que põe o consentimento antes do carregador de tags entre dois defer; no rodapé, depois dele, a ordem se inverteria'
);

/* TETO do modo opt-in: negado por padrão sai BLOQUEANTE, no cabeçalho. */
bancada_limpa();
requisicao_nova();

F3Base_Options::gravar(
	'f3base_consentimento',
	array(
		'padrao'                => 'negado',
		'controle_rodape'       => true,
		'aviso_primeira_visita' => false,
		'ttl_dias'              => 180,
	),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar(
	$nome,
	'' === F3Base_Modulo_Consentimento::estrategia_de_carga( 'negado' ),
	'teto do opt-in: a política de negativa por padrão não devolveu bloqueante. Aqui a ordem é a garantia inteira: o default é denied, e o que dispara antes dele é um primeiro page_view com consentimento pleno de quem ainda não consentiu'
);

( new F3Base_Modulo_Consentimento() )->enfileirar();

$enfileirado_optin = $GLOBALS['f3b_bench']['scripts'][ F3Base_Modulo_Consentimento::HANDLE ] ?? array();

afirmar(
	$nome,
	! isset( $enfileirado_optin['args']['strategy'] ),
	'piso do opt-in: o script foi enfileirado com strategy no modo de negativa por padrão. Inverter a decisão aqui custa o primeiro page_view saindo antes do denied — defer ordena defer, e não ordena o gtag.js async de um emissor concorrente'
);

afirmar(
	$nome,
	false === ( $enfileirado_optin['args']['in_footer'] ?? null ),
	'teto do opt-in: o script bloqueante saiu do cabeçalho — bloquear no rodapé paga o preço do bloqueio e não compra a ordem que ele existe para comprar'
);

/* PISO DO INTERRUPTOR: quem decide é a POLÍTICA, e não uma chave ao lado dela. */
afirmar(
	$nome,
	F3Base_Modulo_Consentimento::estrategia_de_carga( 'pre-aprovado' ) !== F3Base_Modulo_Consentimento::estrategia_de_carga( 'negado' ),
	'piso do valor fixo: as duas políticas devolveram a MESMA estratégia. Uma decisão que não muda com a condição não é decisão: é o literal de antes, com um nome de função em volta'
);

$estrategias_com_o_resto_mudado = array();

foreach ( array( true, false ) as $rodape ) {
	foreach ( array( true, false ) as $aviso ) {
		foreach ( array( 30, 365 ) as $ttl ) {
			F3Base_Options::gravar(
				'f3base_consentimento',
				array(
					'padrao'                => 'pre-aprovado',
					'controle_rodape'       => $rodape,
					'aviso_primeira_visita' => $aviso,
					'ttl_dias'              => $ttl,
				),
				F3Base_Options::ORIGEM_MANUAL
			);

			$estrategias_com_o_resto_mudado[] = F3Base_Modulo_Consentimento::estrategia_de_carga();
		}
	}
}

afirmar(
	$nome,
	array( 'defer' ) === array_values( array_unique( $estrategias_com_o_resto_mudado ) ),
	'piso do interruptor: mudar controle do rodapé, aviso de primeira visita e prazo mexeu na estratégia de carga. Só a política pode decidi-la — a condição decide, e não um interruptor ao lado dela; foi por isso que esta release não criou chave de configuração nenhuma para o assunto'
);

/* TETO DA ORDEM POSSÍVEL: sem estas três coisas, defer não ordenaria nada. */
bancada_limpa();
requisicao_nova();

F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'pre-aprovado', 'controle_rodape' => true ), F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-ABCDEF1234', F3Base_Options::ORIGEM_MANUAL );

( new F3Base_Modulo_Consentimento() )->enfileirar();
( new F3Base_Modulo_Tracking() )->enfileirar();

$scripts_da_pagina = $GLOBALS['f3b_bench']['scripts'];
$do_tracking       = $scripts_da_pagina[ F3Base_Modulo_Tracking::HANDLE ] ?? array();

afirmar(
	$nome,
	'defer' === (string) ( $do_tracking['args']['strategy'] ?? '' ) && true === ( $do_tracking['args']['in_footer'] ?? null ),
	'teto da ordem possível: o carregador de tags deixou de ser defer no rodapé. É essa a outra metade da ordem: consentimento adiado no cabeçalho, carregador adiado no rodapé, e a especificação executando os dois na ordem do documento'
);

afirmar(
	$nome,
	in_array( F3Base_Modulo_Consentimento::HANDLE, (array) ( $do_tracking['deps'] ?? array() ), true ),
	'teto da ordem possível: o carregador de tags deixou de declarar dependência do handle do consentimento — é ela que impede o WordPress de considerar o consentimento adiável abaixo do que o dependente permite, e é ela que o imprime primeiro'
);

/*
 * TETO DO CAMINHO CRÍTICO VAZIO, no modo padrão. A forma durável do ganho
 * desta release: no modo pré-aprovado NENHUM script deste plugin fica no
 * cabeçalho sem estratégia de carga. O número de bytes envelhece a cada edição
 * de arquivo; a invariante, não.
 */
$bloqueantes_no_cabecalho = array();

foreach ( $scripts_da_pagina as $handle => $registro ) {
	$no_cabecalho = false === ( $registro['args']['in_footer'] ?? null );
	$sem_estrategia = '' === (string) ( $registro['args']['strategy'] ?? '' );

	if ( $no_cabecalho && $sem_estrategia ) {
		$bloqueantes_no_cabecalho[] = (string) $handle;
	}
}

afirmar(
	$nome,
	array() === $bloqueantes_no_cabecalho,
	'teto do caminho crítico: no modo pré-aprovado ainda há script bloqueando o parser no cabeçalho: ' . implode( ', ', $bloqueantes_no_cabecalho ) . '. Este era o único, e tirá-lo de lá é o entregável desta release'
);

/* PISO do mesmo teto: no modo opt-in ele VOLTA, e volta de propósito. */
bancada_limpa();
requisicao_nova();

F3Base_Options::gravar( 'f3base_consentimento', array( 'padrao' => 'negado', 'controle_rodape' => true ), F3Base_Options::ORIGEM_MANUAL );

( new F3Base_Modulo_Consentimento() )->enfileirar();

$bloqueante_no_optin = array();

foreach ( $GLOBALS['f3b_bench']['scripts'] as $handle => $registro ) {
	if ( false === ( $registro['args']['in_footer'] ?? null ) && '' === (string) ( $registro['args']['strategy'] ?? '' ) ) {
		$bloqueante_no_optin[] = (string) $handle;
	}
}

afirmar(
	$nome,
	array( F3Base_Modulo_Consentimento::HANDLE ) === $bloqueante_no_optin,
	'piso do caminho crítico: no modo de negativa por padrão o consentimento PRECISA estar bloqueando o cabeçalho, e a bancada encontrou "' . implode( ', ', $bloqueante_no_optin ) . '". Sem esse bloqueio a regra desta release não teria dois lados — teria virado "nunca bloquear", que é a permissividade aplicada onde ela não foi autorizada'
);

/* TETO DA LEITURA: sem argumento, a decisão sai da option gravada. */
afirmar(
	$nome,
	'' === F3Base_Modulo_Consentimento::estrategia_de_carga(),
	'teto da leitura: chamada sem argumento, a estratégia não seguiu a política gravada na option. Duas respostas para a mesma pergunta é o defeito que a fonte única existe para impedir'
);


/* ---------------------------------------------------------------------------
 * modulos.callbacks_executam
 *
 * POR QUE ESTA CHECAGEM EXISTE. A suíte fechou verde com 197 checagens enquanto
 * o plugin servia 141 bytes em TODA página do site. Uma variável sombreada fez
 * `F3Base_Modulo_Noindex_Honrado::decidir()` devolver `false` de uma função que
 * promete `array`; o TypeError estourava dentro do filtro `wp_robots`, no meio
 * do `<head>`, e derrubava a página inteira. Nenhuma checagem pegou porque
 * NENHUMA CHAMAVA A FUNÇÃO — a bancada montava stubs do WordPress, lia o código
 * como texto e media estado, e o callback nunca era executado uma vez sequer.
 * Teste que não executa o código não testa nada.
 *
 * O que ela faz: para CADA módulo do registro e CADA hook que ele declara,
 * INVOCA o callback e prova duas coisas — não lança, e o valor devolvido honra
 * o tipo. As duas provas saem de REFLEXÃO, não de tabela escrita à mão: tabela
 * envelhece e o módulo novo entra sem cobertura, que é o defeito de fundo.
 *
 *   1) o tipo de retorno vem de `ReflectionMethod::getReturnType()`;
 *   2) FILTRO DEVOLVE O QUE RECEBEU: um filtro que recebe array e devolve
 *      string quebra quem o consome, mesmo sem tipo declarado na assinatura.
 *      Dois dos callbacks daqui não declaram retorno nenhum, e é esta regra —
 *      derivada, não tabelada — que os cobre.
 *
 * E varre as FORMAS DE REQUISIÇÃO que trocam de ramo, porque ramo não exercido
 * é ramo sem teste: página singular, post singular, arquivo de taxonomia, busca,
 * 404 e home — nos dois estados que um site real tem, recém-instalado (options
 * vazias) e configurado. É a matriz que teria pegado o defeito no primeiro dia.
 *
 * O que ela NÃO cobre, declarado: os três callbacks de `template_redirect` que
 * SERVEM conteúdo terminam em `exit` por desenho (llms.txt, llms-full.txt e o
 * redirecionamento 301/410). Aqui eles rodam com a URL da forma corrente, que
 * exercita a DECISÃO — a parte que roda em toda visita do site e é a que pode
 * derrubar toda página. O ramo que serve e sai é medido pelas sondas de llms.
 * ------------------------------------------------------------------------ */

$nome = 'modulos.callbacks_executam';

/**
 * Um termo, para a forma de arquivo de taxonomia.
 *
 * A classe não existia na bancada — e sem ela o ramo de taxonomia do módulo de
 * noindex era impossível de alcançar, porque ele começa com um `instanceof`.
 */
if ( ! class_exists( 'WP_Term' ) ) {
	// phpcs:ignore
	class WP_Term {
		public int $term_id = 0;
		public string $name = '';
		public string $slug = '';
		public string $taxonomy = 'category';
		public int $count = 0;
		public int $parent = 0;
		public string $description = '';

		/**
		 * @param array<string,mixed> $campos Campos do termo.
		 */
		public function __construct( array $campos = array() ) {
			foreach ( $campos as $campo => $valor ) {
				if ( property_exists( $this, $campo ) ) {
					$this->$campo = $valor;
				}
			}
		}
	}
}

if ( ! function_exists( 'status_header' ) ) {
	/**
	 * @param int $codigo Código HTTP.
	 * @return void
	 */
	function status_header( int $codigo ): void {
		$GLOBALS['f3b_bench']['status'] = $codigo;
	}
}

if ( ! function_exists( 'nocache_headers' ) ) {
	/**
	 * @return void
	 */
	function nocache_headers(): void {}
}

if ( ! function_exists( 'get_term_meta' ) ) {
	/**
	 * @param int    $id    Id do termo.
	 * @param string $chave Chave.
	 * @param bool   $unico Um valor só.
	 * @return mixed
	 */
	function get_term_meta( int $id, string $chave = '', bool $unico = false ) {
		$valor = $GLOBALS['f3b_bench']['term_meta'][ $id ][ $chave ] ?? '';

		return $unico ? $valor : array( $valor );
	}
}

if ( ! function_exists( 'get_term' ) ) {
	/**
	 * @param int    $id         Id do termo.
	 * @param string $taxonomia  Taxonomia.
	 * @return WP_Term|null
	 */
	function get_term( int $id, string $taxonomia = '' ) {
		unset( $taxonomia );

		return $GLOBALS['f3b_bench']['termos'][ $id ] ?? null;
	}
}

if ( ! function_exists( 'get_queried_object' ) ) {
	/**
	 * @return mixed
	 */
	function get_queried_object() {
		return f3b_forma_de( 'termo' );
	}
}

/**
 * O valor devolvido honra o TIPO DECLARADO na assinatura?
 *
 * @param ReflectionMethod $metodo  Método invocado.
 * @param mixed            $valor   Valor devolvido.
 * @return string Vazio quando honra; a violação, quando não.
 */
function f3b_viola_retorno( ReflectionMethod $metodo, $valor ): string {
	$tipo = $metodo->getReturnType();

	if ( ! $tipo instanceof ReflectionNamedType ) {
		return '';
	}

	$declarado = $tipo->getName();

	if ( null === $valor ) {
		return ( $tipo->allowsNull() || 'void' === $declarado || 'mixed' === $declarado )
			? ''
			: 'devolveu null onde a assinatura promete ' . $declarado;
	}

	$de_fato = strtolower( gettype( $valor ) );
	$de_fato = str_replace( array( 'boolean', 'integer', 'double' ), array( 'bool', 'int', 'float' ), $de_fato );

	if ( 'mixed' === $declarado || 'void' === $declarado ) {
		return '';
	}

	if ( 'object' === $de_fato ) {
		return ( $valor instanceof $declarado ) ? '' : 'devolveu ' . get_class( $valor ) . ' onde a assinatura promete ' . $declarado;
	}

	if ( $de_fato === $declarado ) {
		return '';
	}

	if ( 'float' === $declarado && 'int' === $de_fato ) {
		return '';
	}

	return 'devolveu ' . $de_fato . ' onde a assinatura promete ' . $declarado;
}

/**
 * Argumentos plausíveis para um callback, a partir dos TIPOS REFLETIDOS.
 *
 * A semente por hook é REFINO, não requisito: quando ela não existe, o valor sai
 * do tipo declarado do parâmetro. É o que impede esta função de virar a tabela
 * à mão que deixa o hook novo sem cobertura.
 *
 * @param ReflectionMethod $metodo Método a invocar.
 * @param string           $hook   Nome do hook.
 * @return array<int,mixed>
 */
function f3b_argumentos_do_hook( ReflectionMethod $metodo, string $hook ): array {
	$sementes = array(
		'auth_cookie_expiration' => array( 14 * DAY_IN_SECONDS, 1, true ),
		'cron_schedules'                     => array( f3b_recorrencias_do_nucleo() ),
		'wp_robots'                          => array( array( 'follow' => true, 'max-image-preview' => 'large' ) ),
		'render_block'                       => array(
			'<p>Fale com a gente pelo WhatsApp.</p>',
			array(
				'blockName'    => 'core/paragraph',
				'attrs'        => array( 'className' => 'f3base-cta-whatsapp' ),
				'innerBlocks'  => array(),
				'innerHTML'    => '<p>Fale com a gente pelo WhatsApp.</p>',
				'innerContent' => array( '<p>Fale com a gente pelo WhatsApp.</p>' ),
			),
		),
		'wp_privacy_personal_data_exporters' => array( array( 'wordpress-comments' => array( 'exporter_friendly_name' => 'Comentários', 'callback' => '__return_empty_array' ) ) ),
		'wp_privacy_personal_data_erasers'   => array( array( 'wordpress-comments' => array( 'eraser_friendly_name' => 'Comentários', 'callback' => '__return_empty_array' ) ) ),
		'wpseo_schema_organization'          => array( array( '@type' => 'Organization', '@id' => 'https://exemplo.com.br/#organization', 'name' => 'Exemplo' ) ),
		'wpseo_schema_graph'                 => array( array( array( '@type' => 'WebPage', '@id' => 'https://exemplo.com.br/#webpage' ) ) ),
		'updated_option'                     => array( 'f3base_tracking' ),
		'added_option'                       => array( 'f3base_tracking' ),
		'deleted_option'                     => array( 'f3base_tracking' ),
	);

	$semente = $sementes[ $hook ] ?? array();
	$args    = array();
	$indice  = 0;

	foreach ( $metodo->getParameters() as $parametro ) {
		if ( array_key_exists( $indice, $semente ) ) {
			$args[] = $semente[ $indice ];
			++$indice;
			continue;
		}

		$tipo = $parametro->getType();
		$qual = ( $tipo instanceof ReflectionNamedType ) ? $tipo->getName() : '';

		switch ( $qual ) {
			case 'array':
				$args[] = array();
				break;
			case 'int':
				$args[] = 1;
				break;
			case 'float':
				$args[] = 1.0;
				break;
			case 'bool':
				$args[] = false;
				break;
			case 'string':
				$args[] = '';
				break;
			default:
				$args[] = $parametro->isDefaultValueAvailable() ? $parametro->getDefaultValue() : '';
				break;
		}

		++$indice;
	}

	return $args;
}

/*
 * As formas de requisição. Cada uma leva o site por um ramo diferente, e a URL
 * acompanha porque os callbacks de `template_redirect` decidem por ela.
 */
$formas_da_requisicao = array(
	'página singular'      => array(
		'forma' => array( 'singular' => true, 'tipo' => 'page', 'id' => 101 ),
		'uri'   => '/contato/',
	),
	'post singular'        => array(
		'forma' => array( 'singular' => true, 'tipo' => 'post', 'id' => 102 ),
		'uri'   => '/blog/primeiro-post/',
	),
	'post fora do índice'  => array(
		'forma' => array( 'singular' => true, 'tipo' => 'post', 'id' => 103 ),
		'uri'   => '/blog/post-fora-do-indice/',
	),
	'arquivo de taxonomia' => array(
		'forma' => array(
			'tax'   => true,
			'termo' => new WP_Term( array( 'term_id' => 7, 'name' => 'Notícias', 'slug' => 'noticias', 'taxonomy' => 'category', 'count' => 1 ) ),
		),
		'uri'   => '/categoria/noticias/',
	),
	'busca'                => array(
		'forma' => array( 'busca' => true ),
		'uri'   => '/?s=orcamento',
	),
	'404'                  => array(
		'forma' => array( '404' => true ),
		'uri'   => '/pagina-que-nao-existe/',
	),
	'home'                 => array(
		'forma' => array( 'home' => true, 'front' => true ),
		'uri'   => '/',
	),
	'arquivo de autor'     => array(
		'forma' => array( 'autor' => true ),
		'uri'   => '/autor/redacao/',
	),
	'arquivo de data'      => array(
		'forma' => array( 'data' => true ),
		'uri'   => '/2026/09/',
	),
);

/*
 * Os dois estados que um site real tem. Módulo inativo toma outro ramo, e o
 * site recém-instalado é o estado em que a maior parte dos operadores está no
 * primeiro minuto — se o plugin derruba a página ali, ninguém chega ao resto.
 */
$estados_do_site = array(
	'recém-instalado' => array(),
	'configurado'     => array(
		'f3base_tracking'      => array( 'ga4_measurement_id' => 'G-BANCADA01', 'gtm_id' => 'GTM-BANCADA' ),
		'f3base_consentimento' => array( 'padrao' => 'concedido', 'controle_rodape' => true ),
		'f3base_whatsapp'      => array( 'numero' => '5511999990000', 'mensagem' => 'Olá! Vim pelo site.' ),
		'f3base_cabecalhos'    => array( 'coop' => 'same-origin-allow-popups', 'referrer_policy' => 'strict-origin-when-cross-origin' ),
		'f3base_llms'          => array( 'ativo' => true ),
	),
);

$invocacoes         = 0;
$modulos_exercitados = array();
$hooks_exercitados   = array();
$violacoes           = array();
$lancamentos         = array();

foreach ( $estados_do_site as $rotulo_do_estado => $options_do_estado ) {
	foreach ( $formas_da_requisicao as $rotulo_da_forma => $desenho ) {
		bancada_limpa();
		requisicao_nova();

		foreach ( $options_do_estado as $option => $valor ) {
			F3Base_Options::gravar( $option, $valor, F3Base_Options::ORIGEM_MANUAL );
		}

		/*
		 * CONTEÚDO DE VERDADE. Sem os posts declarados, `get_post()` devolve
		 * null e metade dos callbacks sai pela porta do começo sem ter feito
		 * nada — a bancada mais fácil que o mundo de novo, só que por dentro.
		 */
		f3b_llms_conteudo(
			101,
			'Contato',
			'page',
			'2026-08-01 12:00:00',
			'<!-- wp:paragraph --><p>Fale com a gente.</p><!-- /wp:paragraph -->'
			. '<!-- wp:details {"summary":"Qual o prazo?"} --><div class="wp-block-details"><summary>Qual o prazo?</summary>'
			. '<!-- wp:paragraph --><p>Cinco dias úteis.</p><!-- /wp:paragraph --></div><!-- /wp:details -->',
			'Página de contato.',
			array( '_yoast_wpseo_meta-robots-noindex' => '', '_yoast_wpseo_meta-robots-nofollow' => '' )
		);

		/*
		 * O post SEM meta gravada é o caso que apagou o site: é ele que chega ao
		 * `return` do array neutro no fim do ramo singular. O post COM a meta
		 * gravada sai antes, por um `return` de array literal — e foi assim que
		 * o defeito passou por qualquer teste que só olhasse o caso configurado.
		 */
		f3b_llms_conteudo(
			102,
			'Primeiro post',
			'post',
			'2026-08-15 09:30:00',
			'<!-- wp:paragraph --><p>Texto do post.</p><!-- /wp:paragraph -->',
			'Resumo do primeiro post.',
			array( '_yoast_wpseo_meta-robots-noindex' => '' )
		);

		f3b_llms_conteudo(
			103,
			'Post fora do índice',
			'post',
			'2026-08-20 09:30:00',
			'<!-- wp:paragraph --><p>Texto que não deve ser indexado.</p><!-- /wp:paragraph -->',
			'',
			array( '_yoast_wpseo_meta-robots-noindex' => '1', '_yoast_wpseo_meta-robots-nofollow' => '1' )
		);

		$GLOBALS['f3b_bench']['termos'][7] = $desenho['forma']['termo'] ?? null;
		$_SERVER['REQUEST_URI']            = $desenho['uri'];

		f3b_forma( $desenho['forma'] );

		foreach ( F3Base_Registro::instanciar() as $id_do_modulo => $modulo ) {
			$modulos_exercitados[ $id_do_modulo ] = true;

			foreach ( $modulo->hooks() as $declaracao ) {
				$hook   = (string) $declaracao['hook'];
				$metodo = (string) $declaracao['metodo'];
				$tipo   = (string) $declaracao['tipo'];
				$chave  = $id_do_modulo . '::' . $metodo . '@' . $hook;

				$hooks_exercitados[ $chave ] = true;

				if ( ! method_exists( $modulo, $metodo ) ) {
					$violacoes[] = $chave . ' — o módulo declara o hook mas o método não existe; o registro chamaria o que não está lá';
					continue;
				}

				$reflexo = new ReflectionMethod( $modulo, $metodo );
				$args    = f3b_argumentos_do_hook( $reflexo, $hook );

				$onde = $chave . ' [' . $rotulo_do_estado . ' / ' . $rotulo_da_forma . ']';

				++$invocacoes;

				ob_start();

				try {
					$devolvido = $reflexo->invokeArgs( $modulo, $args );
				} catch ( Throwable $erro ) {
					ob_end_clean();

					$lancamentos[] = $onde . ' — ' . get_class( $erro ) . ': ' . $erro->getMessage()
						. ' (' . basename( $erro->getFile() ) . ':' . $erro->getLine() . ')';
					continue;
				}

				ob_end_clean();

				$violado = f3b_viola_retorno( $reflexo, $devolvido );

				if ( '' !== $violado ) {
					$violacoes[] = $onde . ' — ' . $violado;
					continue;
				}

				/*
				 * FILTRO DEVOLVE O QUE RECEBEU. Sem tipo declarado na assinatura
				 * — e há callbacks aqui sem ele — esta é a única prova de que o
				 * valor continua servindo a quem o consome do outro lado.
				 */
				if ( 'filter' === $tipo && array() !== $args ) {
					$recebido = strtolower( gettype( $args[0] ) );
					$saiu     = strtolower( gettype( $devolvido ) );

					if ( $recebido !== $saiu ) {
						$violacoes[] = $onde . ' — filtro recebeu ' . $recebido . ' e devolveu ' . $saiu
							. '; quem consome o filtro recebe um valor que não sabe usar';
					}
				}
			}
		}
	}
}

/* Cada invocação é uma MEDIDA: o número no relatório é quantas vezes o código rodou de verdade. */
for ( $conta_medida = 0; $conta_medida < $invocacoes; $conta_medida++ ) {
	medir( $nome );
}

afirmar(
	$nome,
	array() === $lancamentos,
	'TETO: callback de módulo LANÇOU ao ser invocado — em produção isto é a página inteira em branco, porque o hook roda no meio da resposta: ' . implode( ' | ', $lancamentos )
);

afirmar(
	$nome,
	array() === $violacoes,
	'TETO: callback de módulo devolveu valor que não honra o tipo — o consumidor do outro lado quebra: ' . implode( ' | ', $violacoes )
);

/*
 * PISO DA COBERTURA. Sem ele a checagem passaria de graça no dia em que a
 * bancada deixasse de carregar um módulo — que é exatamente o que estava
 * acontecendo: o registro declarava 16 e a bancada carregava 13.
 */
$declarados = count( F3Base_Registro::classes() );

afirmar(
	$nome,
	20 === $declarados,
	'PISO da cobertura: o registro devolveu ' . $declarados . ' módulos, e a bancada esperava os 20 do plugin. Módulo que não carrega aqui é módulo sem nenhuma execução, e `F3Base_Registro` descarta em silêncio a classe que não existe'
);

afirmar(
	$nome,
	count( $modulos_exercitados ) === $declarados,
	'PISO da cobertura: ' . count( $modulos_exercitados ) . ' módulos exercitados para ' . $declarados . ' declarados no registro'
);

$hooks_declarados = 0;

foreach ( F3Base_Registro::instanciar() as $modulo ) {
	$hooks_declarados += count( $modulo->hooks() );
}

afirmar(
	$nome,
	count( $hooks_exercitados ) === $hooks_declarados,
	'PISO da cobertura: ' . count( $hooks_exercitados ) . ' hooks exercitados para ' . $hooks_declarados . ' declarados pelos módulos'
);

$esperadas = $hooks_declarados * count( $formas_da_requisicao ) * count( $estados_do_site );

afirmar(
	$nome,
	$invocacoes === $esperadas,
	'PISO da matriz: ' . $invocacoes . ' invocações para ' . $esperadas . ' esperadas (' . $hooks_declarados . ' hooks x ' . count( $formas_da_requisicao ) . ' formas x ' . count( $estados_do_site ) . ' estados). Matriz que encolhe sozinha é ramo que deixou de ser exercitado sem ninguém pedir'
);

/*
 * PISO DO PODER DE ACUSAÇÃO. A checagem acima só vale se ela ACUSA — e o defeito
 * que ela existe para pegar é um retorno de tipo errado dentro de um filtro. O
 * módulo abaixo reproduz a FORMA REAL do defeito: um filtro registrado como os
 * outros, cuja decisão devolve booleano de uma função que promete array.
 */
$mutante = new class() extends F3Base_Modulo {
	public function id(): string {
		return 'bancada-mutante';
	}

	public function nome(): string {
		return 'Mutante da bancada';
	}

	public function descricao(): string {
		return 'Reproduz a forma do defeito que apagou o site: retorno de tipo errado dentro de um filtro.';
	}

	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'filter',
				'hook'       => 'wp_robots',
				'metodo'     => 'aplicar',
				'prioridade' => 20,
				'args'       => 1,
			),
		);
	}

	protected function calcular_estado(): array {
		return array( 'estado' => self::ATIVO, 'motivo' => 'existe só para o piso desta checagem.' );
	}

	/**
	 * @param array<string,mixed> $robots Diretivas.
	 * @return array<string,mixed>
	 */
	public function aplicar( array $robots ): array {
		$decisao = $this->decidir();

		if ( 'noindex' === ( $decisao['indexacao'] ?? '' ) ) {
			$robots['noindex'] = true;
		}

		return $robots;
	}

	/**
	 * A sombra: `$padrao` nasce array e é sobrescrito por um booleano.
	 *
	 * @return array<string,string>
	 */
	private function decidir(): array {
		$padrao = array( 'indexacao' => 'default', 'motivo' => '' );

		if ( is_singular() ) {
			$padrao = 'noindex' === get_post_meta( get_queried_object_id(), '_f3b_bancada', true );

			return $padrao;
		}

		return $padrao;
	}
};

$acusou = '';

f3b_forma( array( 'singular' => true, 'tipo' => 'page', 'id' => 101 ) );

$reflexo_mutante = new ReflectionMethod( $mutante, 'aplicar' );

try {
	$reflexo_mutante->invokeArgs( $mutante, f3b_argumentos_do_hook( $reflexo_mutante, 'wp_robots' ) );
} catch ( Throwable $erro ) {
	$acusou = get_class( $erro );
}

afirmar(
	$nome,
	'TypeError' === $acusou,
	'PISO: replantado o defeito que apagou o site — a variável do array neutro sombreada por um booleano dentro de um filtro —, a invocação devolveu "' . ( '' === $acusou ? 'nada, passou limpo' : $acusou ) . '" em vez de TypeError. Uma checagem que invoca o callback e não acusa este retorno é a mesma checagem que fechou verde enquanto toda página do site servia 141 bytes'
);

/* PISO do outro lado: o mesmo callback SEM a sombra passa limpo, senão a regra acusaria qualquer coisa. */
f3b_forma( array( 'home' => true ) );

$passou_limpo = true;

try {
	$reflexo_mutante->invokeArgs( $mutante, f3b_argumentos_do_hook( $reflexo_mutante, 'wp_robots' ) );
} catch ( Throwable $erro ) {
	$passou_limpo = false;
}

afirmar(
	$nome,
	$passou_limpo,
	'PISO ao contrário: o ramo que NÃO tem a sombra também acusou. Regra que acusa os dois lados não distingue defeito de código são'
);




/* ==========================================================================
 * medicao.profundidade_por_pagina
 *
 * "A PROFUNDIDADE DE REGISTRO DEVE SER MEDIDA E EXIBIDA INDIVIDUALMENTE PARA
 * CADA PÁGINA", nas palavras do usuário. Somada, ela não responde nada: a
 * página que ninguém termina e a que todo mundo termina entram no mesmo total,
 * e é justamente qual das duas está longa demais que o operador precisa saber.
 *
 * E ela só é legível como PROPORÇÃO: "2 chegaram a 90%" pode ser 2 de 2 ou 2 de
 * 200, e as duas leituras levam a decisões opostas sobre o tamanho da página. O
 * denominador é um evento DECLARADO — o contador de carregamentos —, e não uma
 * inferência a partir do TTFB: inferir seria uma segunda verdade sobre uma
 * contagem, divergindo no primeiro navegador que não reporte Navigation Timing.
 * ======================================================================= */

$nome = 'medicao.profundidade_por_pagina';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$gatilho_de_rolagem = F3Base_Modulo_Comportamento::evento_do_gatilho( 'rolagem' );
$gatilho_de_pagina  = F3Base_Modulo_Comportamento::evento_do_gatilho( 'pagina' );

afirmar(
	$nome,
	'' !== $gatilho_de_rolagem && '' !== $gatilho_de_pagina,
	'TETO da declaração: falta o evento de rolagem ("' . $gatilho_de_rolagem . '") ou o contador de carregamentos ("' . $gatilho_de_pagina . '") na declaração única. Sem o segundo, a profundidade não tem denominador e vira número solto'
);

/*
 * DUAS PÁGINAS COM COMPORTAMENTOS OPOSTOS, e é essa diferença que a tela existe
 * para mostrar: uma curta, lida até o fim por quase todo mundo; uma longa, em
 * que a maioria para no meio.
 */
foreach ( range( 1, 4 ) as $visita_curta ) {
	postar_comportamento(
		carga_de_comportamento(
			array(
				'caminho'  => '/curta/',
				'metricas' => array(
					array( 'gatilho' => 'pagina', 'contagem' => 1 ),
					array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 1 ),
					array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'contagem' => 1 ),
					array( 'gatilho' => 'rolagem', 'detalhe' => '75', 'contagem' => 1 ),
					array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'contagem' => 1 ),
				),
			)
		)
	);
}

foreach ( range( 1, 10 ) as $visita_longa ) {
	$metricas_da_longa = array(
		array( 'gatilho' => 'pagina', 'contagem' => 1 ),
		array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 1 ),
	);

	if ( $visita_longa <= 2 ) {
		$metricas_da_longa[] = array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'contagem' => 1 );
	}

	postar_comportamento( carga_de_comportamento( array( 'caminho' => '/longa/', 'metricas' => $metricas_da_longa ) ) );
}

$profundidade = F3Base_Modulo_Comportamento::profundidade_por_pagina();
$por_caminho  = array();

foreach ( $profundidade as $linha_de_profundidade ) {
	$por_caminho[ (string) $linha_de_profundidade['caminho'] ] = $linha_de_profundidade;
}

afirmar(
	$nome,
	isset( $por_caminho['/curta/'] ) && isset( $por_caminho['/longa/'] ),
	'TETO por página: a profundidade saiu somada em vez de separada por página — vieram ' . implode( ', ', array_keys( $por_caminho ) ) . '. É a separação que responde "nesta página, até onde as pessoas descem?"'
);

if ( isset( $por_caminho['/curta/'], $por_caminho['/longa/'] ) ) {
	afirmar(
		$nome,
		4 === (int) $por_caminho['/curta/']['carregamentos'] && 10 === (int) $por_caminho['/longa/']['carregamentos'],
		'TETO do denominador: os carregamentos por página vieram ' . (int) $por_caminho['/curta/']['carregamentos'] . ' e ' . (int) $por_caminho['/longa/']['carregamentos'] . ', e foram enviados 4 e 10. Sem o denominador certo, toda proporção da tela está errada'
	);

	$noventa_da_longa = null;

	foreach ( $por_caminho['/longa/']['marcos'] as $marco_da_longa ) {
		if ( '90' === (string) $marco_da_longa['marco'] ) {
			$noventa_da_longa = $marco_da_longa;
		}
	}

	afirmar(
		$nome,
		null !== $noventa_da_longa && 2 === (int) $noventa_da_longa['total'] && 0.2 === round( (float) $noventa_da_longa['proporcao'], 3 ),
		'TETO da proporção: na página longa, 2 de 10 carregamentos chegaram a 90% e a proporção medida foi ' . ( null === $noventa_da_longa ? 'nenhuma' : (string) $noventa_da_longa['proporcao'] ) . '. "2 chegaram a 90%" sozinho pode ser 2 de 2 ou 2 de 200, e as duas leituras levam a decisões opostas sobre o tamanho da página'
	);

	$marcos_da_curta = array();

	foreach ( $por_caminho['/curta/']['marcos'] as $marco_da_curta ) {
		$marcos_da_curta[] = (string) $marco_da_curta['marco'];
	}

	afirmar(
		$nome,
		array( '25', '50', '75', '90' ) === $marcos_da_curta,
		'TETO da ordem: os marcos saíram em ' . implode( ', ', $marcos_da_curta ) . ' em vez da ordem numérica. Fora de ordem, uma queda de leitura é lida como subida, e ninguém confere a ordem de uma tabela pequena'
	);
}

/*
 * PISO DO DENOMINADOR AUSENTE: sem carregamento registrado, a proporção é NULA
 * e não zero. Zero seria lido como "ninguém chegou", que é o contrário do que a
 * ausência significa — e é o erro que uma divisão desatenta cometeria.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'  => '/sem-denominador/',
			'metricas' => array( array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'contagem' => 3 ) ),
		)
	)
);

$sem_denominador = F3Base_Modulo_Comportamento::profundidade_por_pagina();

afirmar(
	$nome,
	1 === count( $sem_denominador )
		&& 0 === (int) $sem_denominador[0]['carregamentos']
		&& null === $sem_denominador[0]['marcos'][0]['proporcao'],
	'PISO do denominador ausente: sem carregamento registrado a proporção não veio nula. Zero ali seria lido como "ninguém chegou", que é o contrário do que a ausência significa'
);

ob_start();
F3Base_Admin_Medicao::render();
$tela_sem_denominador = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $tela_sem_denominador, 'não medido' ) && ! str_contains( $tela_sem_denominador, 'de 0%' ),
	'PISO do denominador ausente na tela: a tela inventou uma porcentagem sobre um total que não foi medido, ou deixou de dizer que ele não foi medido. Uma porcentagem falsa é pior que número nenhum, porque parece proporção'
);

/* ==========================================================================
 * medicao.registro_por_visitante
 *
 * "MANTENHA OS DADOS SEPARADOS POR DATA E POR VISITANTE", e o registro é a
 * tabela que faz isso. Ela existe ao lado da agregada, e não no lugar dela: são
 * dois dados de naturezas diferentes, com prazos diferentes, e é a diferença de
 * prazo que obriga as duas a existirem. Derivar o resumo do registro faria a
 * série do painel evaporar junto com o log na primeira execução da retenção.
 *
 * O QUE MUDA NA POSTURA DE PRIVACIDADE, dito aqui porque é aqui que se mede: o
 * registro guarda apelido do visitante, apelido da visita e carimbo em
 * milissegundos, e isso é DADO PESSOAL PSEUDONIMIZADO. Por isso o prazo dele é
 * próprio e mais curto, e por isso a forma do apelido é fechada.
 * ======================================================================= */

$nome = 'medicao.registro_por_visitante';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$visitante_a = str_repeat( 'a1b2', 8 );
$visitante_b = str_repeat( 'c3d4', 8 );
$sessao_a    = str_repeat( '0f0e', 8 );
$sessao_b    = str_repeat( '9a9b', 8 );

/*
 * DOIS VISITANTES NA MESMA PÁGINA NO MESMO DIA. É o caso que a tabela agregada
 * funde por desenho — ela soma — e que o registro tem de manter separado.
 */
postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/longa/',
			'visitante' => $visitante_a,
			'sessao'    => $sessao_a,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'contagem' => 1 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 1200 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'ocorrencia' => 1, 'ms' => 9000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'ocorrencia' => 2, 'ms' => 21000 ),
			),
		)
	)
);

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/longa/',
			'visitante' => $visitante_b,
			'sessao'    => $sessao_b,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 1 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 3000 ),
			),
		)
	)
);

$registro_lido = F3Base_Modulo_Comportamento::registro_por_pagina();

afirmar(
	$nome,
	isset( $registro_lido['/longa/'] ) && 2 === (int) $registro_lido['/longa/']['visitantes'],
	'TETO dos dois visitantes: a página registrou ' . ( isset( $registro_lido['/longa/'] ) ? (int) $registro_lido['/longa/']['visitantes'] : 0 ) . ' pessoa(s) diferentes para dois apelidos distintos no mesmo dia. Fundir dois visitantes num só faz a contagem de pessoas medir outra coisa'
);

afirmar(
	$nome,
	isset( $registro_lido['/longa/']['marcos']['90'] )
		&& 1 === (int) $registro_lido['/longa/']['marcos']['90']['primeira']
		&& 1 === (int) $registro_lido['/longa/']['marcos']['90']['releitura'],
	'TETO da releitura: o marco de 90% não separou a primeira descida da segunda. É a ocorrência que distingue "chegou ao fim" de "voltou e leu de novo", e sem a separação as duas viram o mesmo número'
);

afirmar(
	$nome,
	isset( $registro_lido['/longa/']['marcos']['25'] )
		&& 2100 === (int) $registro_lido['/longa/']['marcos']['25']['mediana'],
	'TETO do tempo: a mediana do tempo até 25% saiu ' . ( isset( $registro_lido['/longa/']['marcos']['25']['mediana'] ) ? (string) $registro_lido['/longa/']['marcos']['25']['mediana'] : 'nenhuma' ) . ' e as amostras foram 1200 e 3000 ms. É este número que responde quanto tempo o visitante levou para percorrer a página'
);

/*
 * PISO DA MEDIANA CONTRA A MÉDIA. Uma aba esquecida aberta é o caso comum, e
 * ela move a média da página inteira sem mover a mediana. Medir com média aqui
 * faria a tela relatar minutos de leitura onde houve segundos.
 */
postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/longa/',
			'visitante' => str_repeat( 'beef', 8 ),
			'sessao'    => str_repeat( 'feed', 8 ),
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 1 ) ),
			'eventos'   => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 10800000 ) ),
		)
	)
);

$com_aba_esquecida = F3Base_Modulo_Comportamento::registro_por_pagina();
$mediana_resistiu  = (int) $com_aba_esquecida['/longa/']['marcos']['25']['mediana'];
$media_seria       = (int) round( ( 1200 + 3000 + 10800000 ) / 3 );

afirmar(
	$nome,
	3000 === $mediana_resistiu,
	'PISO da mediana: uma aba esquecida por três horas moveu o tempo típico para ' . $mediana_resistiu . ' ms. A mediana das amostras 1200, 3000 e 10800000 é 3000; a média seria ' . $media_seria . ' ms, e a tela estaria relatando três horas de leitura onde houve três segundos'
);

/*
 * PISO DO PRAZO: o registro é apagado ANTES do resumo, e o prazo dele nunca
 * passa o do resumo — é a única razão de as duas tabelas existirem.
 */
F3Base_Options::gravar(
	'f3base_comportamento',
	array( 'ligado' => true, 'retencao_dias' => 90, 'retencao_eventos_dias' => 365, 'dias_no_painel' => 28 ),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::retencao_eventos_dias() <= F3Base_Modulo_Comportamento::retencao_dias(),
	'PISO do prazo: o registro detalhado ficou com prazo de ' . F3Base_Modulo_Comportamento::retencao_eventos_dias() . ' dias contra ' . F3Base_Modulo_Comportamento::retencao_dias() . ' do resumo. Guardar o dado que IDENTIFICA por mais tempo que o anônimo inverte a única razão de as duas tabelas existirem, e o operador conseguiria fazê-lo digitando um número maior num campo'
);

/*
 * PISO DO ESQUECIMENTO: o direito de exclusão alcança o registro, e alcança
 * SÓ o visitante que pediu.
 */
F3Base_Options::gravar(
	'f3base_comportamento',
	array( 'ligado' => true, 'retencao_dias' => 90, 'retencao_eventos_dias' => 30, 'dias_no_painel' => 28 ),
	F3Base_Options::ORIGEM_MANUAL
);

$apagadas = F3Base_Modulo_Comportamento::esquecer_visitante( $visitante_a );
$depois   = F3Base_Modulo_Comportamento::registro_por_pagina();

afirmar(
	$nome,
	3 === $apagadas,
	'TETO do esquecimento: o pedido de exclusão apagou ' . $apagadas . ' linha(s) do visitante, e ele tinha 3. Um pseudônimo que não é apagável de verdade é um pseudônimo que a política descreve errado'
);

afirmar(
	$nome,
	isset( $depois['/longa/'] ) && 2 === (int) $depois['/longa/']['visitantes'],
	'PISO do esquecimento: a exclusão de um visitante levou junto o registro dos outros — sobraram ' . ( isset( $depois['/longa/'] ) ? (int) $depois['/longa/']['visitantes'] : 0 ) . ' de 2. O direito de um não pode apagar o dado de outro'
);

/*
 * PISO DO CORTE DECLARADO: acima do teto de eventos por corpo, o excedente é
 * NOMEADO na resposta em vez de sumir. Corte silencioso faz o total do agregado
 * não bater com o registro, sem nada em lugar nenhum dizendo por quê.
 */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$eventos_demais = array();

for ( $i = 0; $i < F3Base_Modulo_Comportamento::MAX_EVENTOS + 7; $i++ ) {
	$eventos_demais[] = array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 100 + $i );
}

$r = postar_comportamento(
	carga_de_comportamento(
		array(
			'visitante' => $visitante_a,
			'sessao'    => $sessao_a,
			'eventos'   => $eventos_demais,
		)
	)
);

afirmar(
	$nome,
	201 === $r->status && F3Base_Modulo_Comportamento::MAX_EVENTOS === (int) $r->data['registro'] && 7 === (int) $r->data['cortados'],
	'PISO do corte declarado: acima do teto de eventos por corpo o excedente não saiu nomeado na resposta — vieram ' . (int) $r->data['registro'] . ' registradas e ' . (int) $r->data['cortados'] . ' cortadas. Corte silencioso faz o total do painel não bater com o registro sem nada dizendo por quê'
);

/* ==========================================================================
 * medicao.carimbo_do_acionamento
 *
 * O CARIMBO É DO ACIONAMENTO, E NÃO DA CHEGADA DO LOTE.
 *
 * O DEFEITO, MEDIDO NO BANCO DE UM SITE REAL. `registrar_evento()` gravava
 * `criado_em => time()`, que é o instante em que o LOTE CHEGOU ao servidor. Um
 * lote carrega dezenas de acionamentos acumulados ao longo de segundos ou
 * minutos de navegação, e todos recebiam o carimbo da chegada. Agrupando por
 * `criado_em` em `wp_de3awa_f3base_eventos`, uma linha só respondia por 33
 * acionamentos com `ms` de 724 a 10816 — dez segundos de leitura gravados no
 * mesmo segundo. Na tela, as 25 linhas da primeira página saíam todas com o
 * mesmo `09:22:25`: indistinguíveis no tempo, elas pareciam a mesma linha sendo
 * reescrita, e como o lote só parte quando algo novo acontece, o bloco inteiro
 * só aparecia quando um gatilho novo disparava.
 *
 * A LEITURA DE QUEM RELATOU ESTAVA ERRADA E O SINTOMA ERA REAL: as linhas SÃO
 * distintas, cada uma com `id` próprio, e nada nunca foi reescrito. O que
 * existia era um carimbo que não distinguia o que precisava ser distinguido — e
 * a coluna `ms`, o deslocamento exato desde o carregamento, gravada, certa, e
 * usada por ninguém.
 *
 * O QUE ESTA CHECAGEM MEDE, e por que os quatro pisos são quatro:
 *
 * 1. UM LOTE COM ACIONAMENTOS SEPARADOS NO TEMPO PRODUZ CARIMBOS SEPARADOS, na
 *    ordem certa e com o espaçamento dos `ms`. O mutante é o código de ontem:
 *    os mesmos acionamentos carimbados com a chegada.
 * 2. A ORDENAÇÃO DA TELA CONTINUA CERTA com carimbos que agora se repartem —
 *    e o caso plantado é o de dois acionamentos no MESMO segundo, em que quem
 *    ordena é o desempate por `id`, não o carimbo.
 * 3. A GUARDA DO RELÓGIO: origem no futuro, velha demais e ausente caem na
 *    âncora do servidor, e o espaçamento continua certo.
 * 4. LOTE ENTREGUE COM ATRASO não embaralha a ordem dentro dele.
 * ======================================================================= */

$nome = 'medicao.carimbo_do_acionamento';

/**
 * REGRA PURA: os carimbos de um conjunto de linhas se repartem como os `ms`.
 *
 * A FORMA DA REGRA É "EXISTE UMA BASE ÚNICA". Com o carimbo certo, toda linha
 * satisfaz `criado_em = base + intdiv( ms, 1000 )` para a MESMA base — que é a
 * âncora do lote em segundos. Com o carimbo da chegada, `criado_em` é igual em
 * todas e o `ms` não é: cada linha implica uma base diferente, e a regra acusa.
 *
 * É por isso que ela não testa "os carimbos são diferentes": dois acionamentos
 * separados por trezentos milissegundos caem legitimamente no mesmo segundo, e
 * uma regra sobre distinção reprovaria o caso certo.
 *
 * @param array<int,array<string,mixed>> $linhas Linhas lidas do registro.
 * @return array<int,string> Achados.
 */
function f3b_carimbos_se_repartem( array $linhas ): array {
	if ( count( $linhas ) < 2 ) {
		return array();
	}

	$base       = null;
	$carimbos   = array_map( static fn ( array $linha ): int => (int) $linha['criado_em'], $linhas );
	$deslocados = array_map( static fn ( array $linha ): int => (int) $linha['ms'], $linhas );

	foreach ( $linhas as $linha ) {
		$desta = (int) $linha['criado_em'] - intdiv( (int) $linha['ms'], 1000 );
		$base  = null === $base ? $desta : $base;

		if ( $desta !== $base ) {
			return array(
				'o carimbo das linhas NÃO se reparte como os deslocamentos: ' . count( $linhas ) . ' acionamento(s) espalhados por '
					. ( max( $deslocados ) - min( $deslocados ) ) . ' ms de navegação couberam em '
					. ( max( $carimbos ) - min( $carimbos ) ) . ' segundo(s) de carimbo. É o defeito medido no banco do site: '
					. '33 acionamentos espalhados por 10 segundos saíram todos no mesmo segundo, e na tela as 25 linhas da página '
					. 'traziam o mesmo 09:22:25 — indistinguíveis no tempo, elas parecem a mesma linha sendo reescrita',
			);
		}
	}

	return array();
}

/**
 * REGRA PURA: a lista lida está em ordem cronológica real, da mais recente
 * para a mais antiga.
 *
 * O DESEMPATE É PARTE DA ORDEM, e não um detalhe: com o carimbo em segundos,
 * dois acionamentos separados por menos de mil milissegundos têm o MESMO
 * `criado_em`, e quem os ordena é o `id`. Uma afirmação sobre o carimbo sozinho
 * passaria com os dois invertidos.
 *
 * @param array<int,array<string,mixed>> $linhas Linhas lidas, na ordem em que vieram.
 * @return array<int,string> Achados.
 */
function f3b_ordem_cronologica( array $linhas ): array {
	$anterior = null;

	foreach ( $linhas as $posicao => $linha ) {
		$chave = array( (int) $linha['criado_em'], (int) $linha['id'] );

		if ( null !== $anterior && $chave >= $anterior ) {
			return array(
				'a linha ' . $posicao . ' (carimbo ' . $chave[0] . ', id ' . $chave[1] . ') não é mais antiga que a anterior (carimbo '
					. $anterior[0] . ', id ' . $anterior[1] . '): a tabela não sai do mais recente para o mais antigo. '
					. 'Dentro do mesmo segundo quem ordena é o desempate por id, e não o carimbo',
			);
		}

		$anterior = $chave;
	}

	return array();
}

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true ), F3Base_Options::ORIGEM_MANUAL );

/*
 * O CASO REAL, REPRODUZIDO: 33 acionamentos de UMA visita, espalhados por dez
 * segundos de leitura, entregues num lote só. É a linha que o banco do site
 * mostrou agrupada por `criado_em`.
 */
$visitante_do_carimbo = str_repeat( '5a5b', 8 );
$visita_do_carimbo    = str_repeat( '6c6d', 8 );
$origem_do_lote       = ( time() - 30 ) * 1000 + 250;

$acionamentos_do_caso = array();
$ms_do_caso           = array();

for ( $i = 0; $i < 33; $i++ ) {
	$ms_do_caso[] = 724 + (int) round( $i * ( 10816 - 724 ) / 32 );
}

foreach ( $ms_do_caso as $indice_do_caso => $ms_do_acionamento ) {
	$acionamentos_do_caso[] = array(
		'gatilho'    => 'rolagem',
		'detalhe'    => '25',
		'ocorrencia' => $indice_do_caso + 1,
		'ms'         => $ms_do_acionamento,
	);
}

$r = postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/longa/',
			'visitante' => $visitante_do_carimbo,
			'sessao'    => $visita_do_carimbo,
			'origem'    => $origem_do_lote,
			/*
			 * O AGREGADO DESTE CASO É O PADRÃO, e não uma contagem de 33. A
			 * contagem de um total passou a ter o teto POR PÁGINA do evento como
			 * limite por entrada, e nenhum cliente consegue emitir a mesma
			 * rolagem 33 vezes num carregamento — o que este bloco mede é o
			 * REGISTRO, com uma linha por travessia, e ele não depende do total.
			 */
			'eventos'   => $acionamentos_do_caso,
		)
	)
);

afirmar(
	$nome,
	201 === $r->status && 33 === (int) $r->data['registro'],
	'piso da bancada: o lote de 33 acionamentos não entrou inteiro — status ' . $r->status . ', registro ' . (int) ( $r->data['registro'] ?? 0 ) . '. Sem ele nada abaixo mede o que promete'
);

$lidos_do_caso = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $visita_do_carimbo, 'limite' => 100 ) );

/* TETO 1: os carimbos se repartem como os deslocamentos. */
afirmar(
	$nome,
	array() === f3b_carimbos_se_repartem( $lidos_do_caso['linhas'] ),
	'TETO do carimbo repartido: ' . implode( '; ', f3b_carimbos_se_repartem( $lidos_do_caso['linhas'] ) )
);

$carimbos_do_caso = array();

foreach ( $lidos_do_caso['linhas'] as $linha_do_caso ) {
	$carimbos_do_caso[ (int) $linha_do_caso['criado_em'] ] = true;
}

afirmar(
	$nome,
	count( $carimbos_do_caso ) >= 10,
	'TETO da separação: 33 acionamentos espalhados por dez segundos couberam em ' . count( $carimbos_do_caso ) . ' segundo(s) distinto(s) de carimbo. Dez segundos de navegação são dez segundos na tabela — foi por eles caberem em UM que as 25 linhas da primeira página saíam todas com o mesmo 09:22:25'
);

/* TETO 1b: o carimbo é o do ACIONAMENTO, e não o da chegada. */
afirmar(
	$nome,
	(int) $lidos_do_caso['linhas'][0]['criado_em'] === intdiv( $origem_do_lote, 1000 ) + intdiv( max( $ms_do_caso ), 1000 ),
	'TETO da âncora do visitante: o carimbo do acionamento mais recente saiu ' . (int) $lidos_do_caso['linhas'][0]['criado_em']
		. ' e a origem declarada mais o deslocamento dele dão ' . ( intdiv( $origem_do_lote, 1000 ) + intdiv( max( $ms_do_caso ), 1000 ) )
		. '. Com a origem aceita, o absoluto de cada linha é o instante em que aquele acionamento aconteceu'
);

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::ANCORA_VISITANTE === (string) $lidos_do_caso['linhas'][0]['ancora'],
	'TETO da procedência gravada: a linha não diz de onde veio o carimbo dela — observado "' . (string) $lidos_do_caso['linhas'][0]['ancora']
		. '". A tela não pode afirmar um horário sem que nada saiba de onde ele veio'
);

/*
 * PISO 1 — A MUTAÇÃO PLANTADA: o código de ontem. As MESMAS linhas, carimbadas
 * com a hora em que o lote chegou. É a forma exata do defeito medido, e a regra
 * precisa acusá-la com a frase do caso real.
 */
$mutante_da_chegada = array();

foreach ( $lidos_do_caso['linhas'] as $linha_do_caso ) {
	$linha_do_caso['criado_em'] = time();
	$mutante_da_chegada[]       = $linha_do_caso;
}

$acusacao_da_chegada = f3b_carimbos_se_repartem( $mutante_da_chegada );

afirmar(
	$nome,
	array() !== $acusacao_da_chegada,
	'PISO CEGO do carimbo repartido: carimbadas todas as 33 linhas com a hora da CHEGADA do lote — que é exatamente o código de ontem —, a regra continuou em silêncio'
);

afirmar(
	$nome,
	array() !== $acusacao_da_chegada && str_contains( $acusacao_da_chegada[0], '33 acionamentos espalhados por 10 segundos saíram todos no mesmo segundo' )
		&& str_contains( $acusacao_da_chegada[0], '25 linhas da página' )
		&& str_contains( $acusacao_da_chegada[0], '09:22:25' ),
	'PISO do caso nomeado: a regra acusou o carimbo da chegada sem citar o caso que ela existe para impedir. Achado sem o caso medido é achado que o leitor seguinte não sabe onde foi visto'
);

/* ---- PISO 2: a ordenação da tela, com dois acionamentos no MESMO segundo ---- */

/*
 * O CASO PLANTADO É O EMPATE. Dois acionamentos separados por 300 ms caem no
 * mesmo `criado_em` por construção — o carimbo é em segundos —, e é aí que
 * `ORDER BY criado_em DESC, id DESC` precisa entregar a ordem cronológica real.
 */
$visita_do_empate = str_repeat( '7e7f', 8 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/empate/',
			'visitante' => $visitante_do_carimbo,
			'sessao'    => $visita_do_empate,
			'origem'    => $origem_do_lote,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'contagem' => 3 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 5100 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'ocorrencia' => 1, 'ms' => 5400 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '75', 'ocorrencia' => 1, 'ms' => 5900 ),
			),
		)
	)
);

$lidos_do_empate = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $visita_do_empate, 'limite' => 100 ) );

afirmar(
	$nome,
	3 === count( $lidos_do_empate['linhas'] )
		&& 1 === count( array_unique( array_map( static fn ( array $l ): int => (int) $l['criado_em'], $lidos_do_empate['linhas'] ) ) ),
	'piso da bancada do empate: os três acionamentos separados por menos de um segundo não caíram no mesmo carimbo, e sem o empate o desempate não é exercido'
);

afirmar(
	$nome,
	array() === f3b_ordem_cronologica( $lidos_do_empate['linhas'] ),
	'TETO da ordem no empate: ' . implode( '; ', f3b_ordem_cronologica( $lidos_do_empate['linhas'] ) )
);

afirmar(
	$nome,
	3 === count( $lidos_do_empate['linhas'] ) && 5900 === (int) $lidos_do_empate['linhas'][0]['ms'] && 5100 === (int) $lidos_do_empate['linhas'][2]['ms'],
	'TETO da ordem real: dentro do mesmo segundo a tabela não saiu do acionamento mais recente para o mais antigo — observado ' . implode( ', ', array_map( static fn ( array $l ): string => (string) (int) $l['ms'], $lidos_do_empate['linhas'] ) ) . ' ms'
);

/*
 * PISO 2 — A MUTAÇÃO: a mesma leitura ordenada SÓ pelo carimbo, que é o que
 * sobra quando alguém tira o desempate do `ORDER BY`. Empatadas no segundo, as
 * três podem sair em qualquer ordem, e a regra precisa acusar.
 */
$mutante_sem_desempate = array_reverse( $lidos_do_empate['linhas'] );

afirmar(
	$nome,
	array() !== f3b_ordem_cronologica( $mutante_sem_desempate ),
	'PISO CEGO da ordem: invertidas as três linhas empatadas no mesmo segundo — que é o que sobra quando o desempate por id sai do ORDER BY —, a regra continuou em silêncio'
);

/* ---- PISO 3: a guarda do relógio ---- */

/*
 * A GUARDA É EXERCITADA NA FUNÇÃO PURA, contra uma chegada CONHECIDA. Só assim
 * é possível apresentar a ela uma origem no futuro e outra velha demais sem
 * mover o relógio do processo inteiro.
 */
$chegada_de_bancada = 1788610945000;
$retencao_de_bancada = F3Base_Modulo_Comportamento::retencao_eventos_dias();

$ancora_boa = F3Base_Modulo_Comportamento::ancora_do_lote( $chegada_de_bancada - 30000, 10816, $chegada_de_bancada, $retencao_de_bancada );

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::ANCORA_VISITANTE === $ancora_boa['de']
		&& intdiv( $chegada_de_bancada - 30000, 1000 ) === $ancora_boa['segundo'],
	'TETO da origem boa: uma origem trinta segundos no passado foi recusada ou truncada errado — procedência "' . $ancora_boa['de'] . '", segundo ' . $ancora_boa['segundo']
);

foreach (
	array(
		'no futuro além da tolerância' => $chegada_de_bancada + F3Base_Modulo_Comportamento::TOLERANCIA_RELOGIO_MS + 1000,
		'velha demais'                 => $chegada_de_bancada - ( ( $retencao_de_bancada + 1 ) * DAY_IN_SECONDS * 1000 ),
		'ausente'                      => null,
		'não numérica'                 => 'ontem',
		'zerada'                       => 0,
		'negativa'                     => -1,
	) as $caso_do_relogio => $origem_recusada
) {
	$ancora_ruim = F3Base_Modulo_Comportamento::ancora_do_lote( $origem_recusada, 10816, $chegada_de_bancada, $retencao_de_bancada );

	afirmar(
		$nome,
		F3Base_Modulo_Comportamento::ANCORA_SERVIDOR === $ancora_ruim['de'],
		'PISO da guarda do relógio: a origem ' . $caso_do_relogio . ' foi ACEITA como âncora — procedência "' . $ancora_ruim['de'] . '". Relógio de visitante que não passa na guarda carimba linha no futuro, fora do período que o painel soma e fora do alcance da retenção'
	);

	afirmar(
		$nome,
		intdiv( $chegada_de_bancada - 10816, 1000 ) === $ancora_ruim['segundo'],
		'TETO da âncora do servidor: com a origem ' . $caso_do_relogio . ' recusada, a âncora não saiu de "chegada − maior ms do lote" — observado ' . $ancora_ruim['segundo'] . ' contra ' . intdiv( $chegada_de_bancada - 10816, 1000 )
	);
}

/*
 * O ESPAÇAMENTO CONTINUA CERTO NOS DOIS CAMINHOS, e é esta a afirmação que
 * sustenta a promessa escrita: a âncora do servidor erra o ABSOLUTO de um lote
 * atrasado e não erra a distância entre as linhas dele.
 */
$ancora_tolerada = F3Base_Modulo_Comportamento::ancora_do_lote( 'ontem', 10816, $chegada_de_bancada, $retencao_de_bancada );
$espacado_do_servidor = array();
$espacado_do_visitante = array();

foreach ( $ms_do_caso as $ms_espacado ) {
	$espacado_do_servidor[]  = $ancora_tolerada['segundo'] + intdiv( $ms_espacado, 1000 );
	$espacado_do_visitante[] = $ancora_boa['segundo'] + intdiv( $ms_espacado, 1000 );
}

afirmar(
	$nome,
	array_map( static fn ( int $c ): int => $c - $espacado_do_servidor[0], $espacado_do_servidor )
		=== array_map( static fn ( int $c ): int => $c - $espacado_do_visitante[0], $espacado_do_visitante ),
	'PISO do espaçamento na âncora do servidor: com a origem recusada, a distância entre os carimbos deixou de ser a distância entre os deslocamentos. A ORDEM e o ESPAÇAMENTO precisam ficar certos nos dois caminhos; é só o absoluto que fica exato apenas no primeiro'
);

/* ---- PISO 3b: a guarda, ponta a ponta, pela rota ---- */
$visita_do_relogio = str_repeat( '8081', 8 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/relogio/',
			'visitante' => $visitante_do_carimbo,
			'sessao'    => $visita_do_relogio,
			'origem'    => ( time() + 86400 ) * 1000,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 2 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 1000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'ocorrencia' => 1, 'ms' => 9000 ),
			),
		)
	)
);

$lidos_do_relogio = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $visita_do_relogio, 'limite' => 100 ) );

afirmar(
	$nome,
	2 === count( $lidos_do_relogio['linhas'] )
		&& F3Base_Modulo_Comportamento::ANCORA_SERVIDOR === (string) $lidos_do_relogio['linhas'][0]['ancora']
		&& array() === f3b_carimbos_se_repartem( $lidos_do_relogio['linhas'] ),
	'PISO do relógio adiantado ponta a ponta: um lote com origem um dia no futuro não caiu na âncora do servidor, ou o espaçamento se perdeu no caminho. Um carimbo no futuro sai do período que o painel soma e a retenção não o alcança pelo prazo'
);

afirmar(
	$nome,
	2 === count( $lidos_do_relogio['linhas'] ) && (int) $lidos_do_relogio['linhas'][0]['criado_em'] <= time(),
	'PISO do carimbo no futuro: a linha foi gravada com carimbo depois de agora. A âncora do servidor nunca pode ir para o futuro — ela é a chegada menos um deslocamento não negativo'
);

/* ---- PISO 4: o lote entregue COM ATRASO ---- */

/*
 * A FILA PENDENTE RETOMADA. O lote foi selado num carregamento que não
 * conseguiu entregá-lo e parte no carregamento seguinte, minutos depois: a
 * origem viaja SELADA dentro dele, e é ela — não a chegada — que carimba as
 * linhas. Sem a origem no selo, o lote retomado sairia carimbado com a hora da
 * página que o encontrou.
 */
$visita_atrasada = str_repeat( '9293', 8 );
$origem_atrasada = ( time() - 900 ) * 1000;

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/atrasada/',
			'visitante' => $visitante_do_carimbo,
			'sessao'    => $visita_atrasada,
			'origem'    => $origem_atrasada,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 3 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 2000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'ocorrencia' => 1, 'ms' => 17000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'ocorrencia' => 1, 'ms' => 41000 ),
			),
		)
	)
);

$lidos_atrasados = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $visita_atrasada, 'limite' => 100 ) );

afirmar(
	$nome,
	3 === count( $lidos_atrasados['linhas'] )
		&& array() === f3b_ordem_cronologica( $lidos_atrasados['linhas'] )
		&& array() === f3b_carimbos_se_repartem( $lidos_atrasados['linhas'] ),
	'PISO do lote atrasado: um lote selado quinze minutos antes de chegar embaralhou a ordem ou perdeu o espaçamento das linhas dele. A origem viaja DENTRO do selo justamente para sobreviver à fila pendente e ao reenvio'
);

afirmar(
	$nome,
	3 === count( $lidos_atrasados['linhas'] )
		&& (int) $lidos_atrasados['linhas'][2]['criado_em'] === intdiv( $origem_atrasada, 1000 ) + 2,
	'TETO do lote atrasado: o carimbo do acionamento mais antigo do lote atrasado não é o instante em que ele aconteceu. Ele saiu ' . (int) $lidos_atrasados['linhas'][2]['criado_em'] . ' e a origem selada mais o deslocamento dão ' . ( intdiv( $origem_atrasada, 1000 ) + 2 )
);

/*
 * O MESMO LOTE ATRASADO, SEM ORIGEM: é o caminho em que a âncora do servidor
 * erra o absoluto — e é onde a promessa escrita precisa valer mesmo assim, com
 * a ORDEM e o ESPAÇAMENTO intactos.
 */
$visita_atrasada_cega = str_repeat( '9495', 8 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/atrasada-cega/',
			'visitante' => $visitante_do_carimbo,
			'sessao'    => $visita_atrasada_cega,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 3 ) ),
			'eventos'   => array(
				array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'ocorrencia' => 1, 'ms' => 2000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '50', 'ocorrencia' => 1, 'ms' => 17000 ),
				array( 'gatilho' => 'rolagem', 'detalhe' => '90', 'ocorrencia' => 1, 'ms' => 41000 ),
			),
		)
	)
);

$lidos_cegos = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => $visita_atrasada_cega, 'limite' => 100 ) );

afirmar(
	$nome,
	3 === count( $lidos_cegos['linhas'] )
		&& array() === f3b_ordem_cronologica( $lidos_cegos['linhas'] )
		&& array() === f3b_carimbos_se_repartem( $lidos_cegos['linhas'] )
		&& F3Base_Modulo_Comportamento::ANCORA_SERVIDOR === (string) $lidos_cegos['linhas'][0]['ancora'],
	'PISO do lote atrasado SEM origem: sem origem selada, a âncora do servidor embaralhou a ordem ou perdeu o espaçamento. É o caminho em que o absoluto erra pelo tempo de fila, e ele é o único que pode errar'
);

/* ---- A TELA: o horário com precisão, e de onde ele veio ---- */

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_carimbo = (string) ob_get_clean();

$horario_esperado = wp_date( 'H:i:s', (int) $lidos_do_caso['linhas'][0]['criado_em'] ) . ',' . str_pad( (string) ( (int) $lidos_do_caso['linhas'][0]['ms'] % 1000 ), 3, '0', STR_PAD_LEFT );

afirmar(
	$nome,
	str_contains( $tela_com_carimbo, $horario_esperado ),
	'TETO da precisão na tela: o horário saiu sem a fração de segundo, e dois acionamentos separados por trezentos milissegundos voltam a aparecer com o mesmo valor — que é o sintoma que esta release existe para eliminar. Esperado ' . $horario_esperado
);

afirmar(
	$nome,
	str_contains( $tela_com_carimbo, 'De onde vem o horário nesta página da tabela' )
		&& str_contains( $tela_com_carimbo, 'medido no próprio carregamento da página' ),
	'PISO da procedência na tela: a tela afirma um horário sem dizer de onde ele veio. As três procedências têm qualidades diferentes, e sem a linha elas aparecem iguais'
);

/*
 * A LINHA DA CHEGADA: as linhas gravadas antes desta versão NÃO são reescritas,
 * e a tela precisa marcá-las em vez de fingir que elas são como as outras.
 */
global $wpdb;

$wpdb->insert(
	F3Base_Modulo_Comportamento::nome_tabela_eventos(),
	array(
		'visitante'  => $visitante_do_carimbo,
		'sessao'     => str_repeat( 'a6a7', 8 ),
		'dia'        => gmdate( 'Y-m-d' ),
		'caminho'    => '/antiga/',
		'metrica'    => 'f3base_rolagem',
		'detalhe'    => '25',
		'valor'      => 0.0,
		'ocorrencia' => 1,
		'ms'         => 7321,
		'criado_em'  => time(),
		'ancora'     => F3Base_Modulo_Comportamento::ANCORA_CHEGADA,
	)
);

$lidas_antigas = F3Base_Modulo_Comportamento::acionamentos( array( 'sessao' => str_repeat( 'a6a7', 8 ), 'limite' => 100 ) );

afirmar(
	$nome,
	1 === count( $lidas_antigas['linhas'] ) && null === $lidas_antigas['linhas'][0]['fracao_ms'],
	'PISO da linha da chegada: a leitura devolveu fração de segundo para uma linha cujo carimbo é a hora da CHEGADA do lote. Somar o deslocamento a um carimbo que não é o do carregamento produz um número com cara de precisão e nenhum significado'
);

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_antiga = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $tela_com_antiga, '(chegada)' ) && str_contains( $tela_com_antiga, 'gravadas por uma versão anterior deste plugin' ),
	'PISO da linha antiga na tela: a linha gravada com o carimbo da chegada aparece sem marca nenhuma, indistinguível das que trazem o instante do acionamento'
);

/* ---- AS DUAS TABELAS, ditas em cada quadro ---- */

$tabelas_da_tela = F3Base_Modulo_Comportamento::proposito_das_tabelas();

afirmar(
	$nome,
	str_contains( $tela_com_antiga, $tabelas_da_tela['agregado']['tabela'] )
		&& str_contains( $tela_com_antiga, $tabelas_da_tela['registro']['tabela'] ),
	'PISO das duas tabelas: a tela mostra a tabela bruta e os quadros do agregado sem nomear as DUAS tabelas de onde eles vêm. Foi essa ausência que fez quem opera abrir o banco, encontrar o agregado — que soma na mesma linha por desenho — e concluir que o registro estava sendo reescrito'
);

afirmar(
	$nome,
	str_contains( $tela_com_antiga, 'Ele SOMA por desenho' )
		&& str_contains( $tela_com_antiga, 'Aqui nada soma e nada é reescrito' ),
	'PISO do que cada tabela responde: os quadros nomeiam a tabela e não dizem o que ela responde. Nome de tabela sem o propósito dela devolve quem lê exatamente ao ponto em que ele foi ao banco procurar'
);

afirmar(
	$nome,
	substr_count( $tela_com_antiga, 'f3base-de-qual-tabela' ) >= 4,
	'TETO da cobertura: apenas ' . substr_count( $tela_com_antiga, 'f3base-de-qual-tabela' ) . ' quadro(s) da tela dizem de qual tabela vêm. Um quadro sem a linha é o quadro em que a confusão volta'
);

/*
 * PISO DA FONTE ÚNICA DA FRASE DAS TABELAS: ela não pode estar escrita dentro
 * do PHP da tela. Escrita ali, seria uma segunda descrição da mesma tabela,
 * divergindo desta na primeira edição apressada.
 */
$fonte_da_tela_do_carimbo = (string) file_get_contents( $raiz . '/fontes/plugin/admin/class-f3base-admin-medicao.php' );

foreach ( $tabelas_da_tela as $chave_da_tabela => $dados_da_tabela ) {
	afirmar(
		$nome,
		! str_contains( $fonte_da_tela_do_carimbo, $dados_da_tabela['responde'] ),
		'PISO da fonte única: a frase do que a tabela ' . $chave_da_tabela . ' responde está escrita dentro do PHP da tela. Ela mora no módulo, e duas descrições da mesma tabela divergem sem que nada acuse'
	);
}

/* ==========================================================================
 * migracao.sobre_site_existente
 *
 * A BANCADA TESTAVA INSTALAÇÃO LIMPA, e o defeito mora na ATUALIZAÇÃO.
 *
 * O caso medido: `garantir_estrutura()` do módulo de comportamento perguntava
 * `if ( self::tabela_pronta() ) { return; }` — e `tabela_pronta()` olha só o
 * RESUMO. Num site que já tinha o resumo, isto é, em TODO SITE JÁ ENTREGUE, a
 * função saía cedo e a tabela de registro nunca nascia. `eventos_prontos()`
 * existia na mesma classe e não era consultado. Instalação limpa passava; a
 * subida sobre site existente ficava sem a estrutura nova, sem erro nenhum, e a
 * tela mostrava "pessoas diferentes" em branco para sempre.
 *
 * A REGRA É GERAL, e o conjunto do que é "novo" NÃO é uma lista escrita à mão —
 * ela envelheceria exatamente como a lista que produziu o defeito. O conjunto
 * é DERIVADO POR EXECUÇÃO: uma instalação limpa roda o caminho de instalação
 * inteiro, e o que ela cria É o que a versão exige. Depois, para CADA estrutura
 * desse conjunto, a bancada monta um site que tem todas as outras e não tem
 * aquela — que é a forma de um site rodando a versão anterior — roda só o
 * caminho de ATUALIZAÇÃO, e exige que ela nasça.
 *
 * Tabela nova, coluna nova ou tabela renomeada entram nessa varredura sozinhas,
 * porque entram na instalação limpa sozinhas.
 * ======================================================================= */

$nome = 'migracao.sobre_site_existente';

/**
 * O caminho de INSTALAÇÃO: o que o plugin faz ao ser ativado.
 *
 * @return void
 */
function f3b_instalacao_do_plugin(): void {
	foreach ( F3Base_Registro::instanciar() as $modulo_a_instalar ) {
		$modulo_a_instalar->instalar();
	}
}

/**
 * O caminho de ATUALIZAÇÃO: o que roda numa requisição comum, sem ativação.
 *
 * É ESTE o caminho que um site já entregue percorre quando o plugin é
 * atualizado por cima: ninguém reativa nada, o WordPress só carrega a versão
 * nova e dispara `init`. Uma estrutura que só nasce na ativação é uma estrutura
 * que a atualização não cria.
 *
 * @return void
 */
function f3b_atualizacao_do_plugin(): void {
	foreach ( F3Base_Registro::instanciar() as $modulo_a_subir ) {
		foreach ( $modulo_a_subir->hooks() as $gancho ) {
			if ( 'init' === (string) $gancho['hook'] && 'garantir_estrutura' === (string) $gancho['metodo'] ) {
				$modulo_a_subir->garantir_estrutura();
			}
		}
	}
}

/**
 * As estruturas que a versão corrente EXIGE, medidas numa instalação limpa.
 *
 * @return array<string,array<int,string>> Tabela para colunas.
 */
function f3b_estruturas_exigidas(): array {
	global $wpdb;

	bancada_limpa();
	requisicao_nova();

	$wpdb->tabelas = array();

	f3b_instalacao_do_plugin();

	$exigidas = array();

	foreach ( $wpdb->tabelas as $tabela => $dados ) {
		$exigidas[ (string) $tabela ] = array_map( 'strval', (array) ( $dados['colunas'] ?? array() ) );
	}

	ksort( $exigidas );

	return $exigidas;
}

$exigidas = f3b_estruturas_exigidas();

afirmar(
	$nome,
	count( $exigidas ) >= 3,
	'TETO do conjunto exigido: a instalação limpa criou ' . count( $exigidas ) . ' tabela(s), e esta versão declara três (resumo, registro e reserva de leads). Um conjunto menor que o real faz esta checagem varrer menos do que existe — e ela deixaria de cobrir justamente a estrutura nova'
);

$sem_nascer = array();

/*
 * UM SITE POR ESTRUTURA AUSENTE. Cada volta monta a forma de um site que rodava
 * a versão anterior: tudo o que já existia está lá, e só a peça nova falta.
 */
foreach ( $exigidas as $tabela_ausente => $colunas_exigidas ) {
	global $wpdb;

	bancada_limpa();
	requisicao_nova();

	$wpdb->tabelas = array();

	f3b_instalacao_do_plugin();

	unset( $wpdb->tabelas[ $tabela_ausente ] );

	requisicao_nova();
	f3b_atualizacao_do_plugin();

	if ( ! isset( $wpdb->tabelas[ $tabela_ausente ] ) ) {
		$sem_nascer[] = 'tabela ' . $tabela_ausente;

		continue;
	}

	$nasceram = array_map( 'strval', (array) ( $wpdb->tabelas[ $tabela_ausente ]['colunas'] ?? array() ) );

	if ( array() !== array_diff( $colunas_exigidas, $nasceram ) ) {
		$sem_nascer[] = 'tabela ' . $tabela_ausente . ' nasceu sem ' . implode( ', ', array_diff( $colunas_exigidas, $nasceram ) );
	}
}

afirmar(
	$nome,
	array() === $sem_nascer,
	'TETO da atualização: num site que já rodava a versão anterior, a subida NÃO criou: ' . implode( ' | ', $sem_nascer )
		. '. É o defeito da 1.5.0 inteiro: instalação limpa passa, site já entregue fica sem a estrutura nova, sem erro nenhum'
);

/*
 * A COLUNA NOVA numa tabela que JÁ EXISTIA. É a forma mais traiçoeira do mesmo
 * defeito: a tabela existe, uma guarda que só pergunte "a tabela existe?" sai
 * cedo, e a coluna nunca é acrescentada — a escrita passa a falhar em silêncio
 * numa coluna que não está lá.
 */
$sem_coluna = array();

foreach ( $exigidas as $tabela_velha => $colunas_exigidas ) {
	foreach ( $colunas_exigidas as $coluna_nova ) {
		global $wpdb;

		bancada_limpa();
		requisicao_nova();

		$wpdb->tabelas = array();

		f3b_instalacao_do_plugin();

		$wpdb->tabelas[ $tabela_velha ]['colunas'] = array_values(
			array_diff( $wpdb->tabelas[ $tabela_velha ]['colunas'], array( $coluna_nova ) )
		);

		requisicao_nova();
		f3b_atualizacao_do_plugin();

		if ( ! in_array( $coluna_nova, array_map( 'strval', (array) $wpdb->tabelas[ $tabela_velha ]['colunas'] ), true ) ) {
			$sem_coluna[] = $tabela_velha . '.' . $coluna_nova;
		}
	}
}

afirmar(
	$nome,
	array() === $sem_coluna,
	'TETO da coluna nova: numa tabela que JÁ existia, a subida não acrescentou: ' . implode( ', ', $sem_coluna )
		. '. Uma guarda que pergunta só "a tabela existe?" sai cedo, a coluna nunca chega, e a escrita passa a falhar em silêncio numa coluna que não está lá'
);

/*
 * AS OPTIONS de um site antigo: as que a versão nova acrescentou não existem no
 * banco dele. Elas não precisam ser criadas — precisam RESOLVER, pelo padrão do
 * catálogo. Uma option nova sem padrão devolveria null e o consumidor dela
 * quebraria só no site antigo, que é onde ninguém testa.
 */
bancada_limpa();
requisicao_nova();

$GLOBALS['f3b_bench']['options'] = array();

$sem_padrao = array();

foreach ( F3Base_Options::nomes() as $option_do_catalogo ) {
	if ( null === F3Base_Options::ler( $option_do_catalogo ) ) {
		$sem_padrao[] = $option_do_catalogo;
	}
}

afirmar(
	$nome,
	array() === $sem_padrao,
	'TETO da option nova: num site que nunca as gravou, estas devolveram null em vez do padrão declarado: ' . implode( ', ', $sem_padrao )
		. '. Option nova sem padrão quebra só no site antigo, que é exatamente onde ninguém testa'
);

/*
 * AS SUBCHAVES novas dentro de uma option que já existia. O site antigo tem a
 * option gravada com as chaves de ANTES; o sanitizador precisa completar as
 * novas com o padrão, senão o consumidor delas lê vazio para sempre num site
 * que parece configurado.
 */
bancada_limpa();
requisicao_nova();

F3Base_Options::gravar( 'f3base_comportamento', array( 'ligado' => true, 'retencao_dias' => 90, 'dias_no_painel' => 28 ), F3Base_Options::ORIGEM_IMPLANTADOR );

$comportamento_antigo = F3Base_Options::ler( 'f3base_comportamento' );

afirmar(
	$nome,
	isset( $comportamento_antigo['retencao_eventos_dias'] ) && (int) $comportamento_antigo['retencao_eventos_dias'] > 0,
	'TETO da subchave nova: uma option gravada pela versão ANTERIOR, sem a subchave que a nova acrescentou, leu "'
		. ( isset( $comportamento_antigo['retencao_eventos_dias'] ) ? (string) $comportamento_antigo['retencao_eventos_dias'] : 'nada' )
		. '" em vez do padrão. O site antigo parece configurado e o consumidor da chave nova lê vazio para sempre'
);

/*
 * AS ROTAS: toda rota declarada em constante é registrada quando o módulo
 * registra as dele. A lista sai das CONSTANTES da própria classe — rota nova
 * ganha constante nova e entra nesta varredura sozinha.
 */
bancada_limpa();
requisicao_nova();

$GLOBALS['f3b_bench']['rotas'] = array();

foreach ( F3Base_Registro::instanciar() as $modulo_de_rota ) {
	foreach ( $modulo_de_rota->hooks() as $gancho_de_rota ) {
		if ( 'rest_api_init' === (string) $gancho_de_rota['hook'] ) {
			$modulo_de_rota->{$gancho_de_rota['metodo']}();
		}
	}
}

$rotas_ausentes = array();

foreach ( F3Base_Registro::classes() as $classe_de_rota ) {
	foreach ( ( new ReflectionClass( $classe_de_rota ) )->getConstants() as $constante => $valor_da_rota ) {
		if ( 0 !== strpos( (string) $constante, 'ROTA' ) || ! is_string( $valor_da_rota ) ) {
			continue;
		}

		if ( ! in_array( (string) $valor_da_rota, (array) $GLOBALS['f3b_bench']['rotas'], true ) ) {
			$rotas_ausentes[] = $classe_de_rota . '::' . $constante . ' (' . $valor_da_rota . ')';
		}
	}
}

afirmar(
	$nome,
	array() === $rotas_ausentes,
	'TETO da rota nova: estas rotas são declaradas em constante e não foram registradas: ' . implode( ', ', $rotas_ausentes )
		. '. Rota declarada e não registrada responde 404 no site inteiro, e a constante faz parecer que ela existe'
);

/*
 * PISO DA REGRA: replantada a guarda que só pergunta pela tabela antiga, a
 * varredura tem de ACUSAR. Sem este lado, tudo acima passaria de graça no dia
 * em que a guarda voltasse a ser de uma tabela só — que foi o que aconteceu.
 */
global $wpdb;

bancada_limpa();
requisicao_nova();

$wpdb->tabelas = array();

f3b_instalacao_do_plugin();

unset( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela_eventos() ] );

requisicao_nova();

/*
 * A GUARDA DEFEITUOSA, reproduzida: pergunta só pelo resumo e sai cedo. É
 * literalmente a linha que a 1.5.0 tinha.
 */
if ( ! F3Base_Modulo_Comportamento::tabela_pronta() ) {
	F3Base_Modulo_Comportamento::criar_tabela();
}

afirmar(
	$nome,
	! F3Base_Modulo_Comportamento::eventos_prontos(),
	'PISO da regra: com a guarda defeituosa replantada — a que pergunta só pela tabela do resumo —, a tabela de registro nasceu mesmo assim. A bancada não reproduz o defeito, e um teto que não sabe falhar não protege nada'
);

/* ==========================================================================
 * modulos.nascem_ativos
 *
 * "O SITE DEVE NASCER COM TUDO ATIVADO." A checagem que prova isso, e ela é a
 * resposta a um defeito medido em produção: com `projeto.json` intocado, o
 * módulo de tracking fechava INATIVO porque nenhum ID de fornecedor tinha sido
 * gravado — e módulo inativo NÃO REGISTRA HOOK. O `wp_enqueue_scripts` nunca
 * era registrado, o carregador não chegava ao HTML, e o coletor de comportamento
 * do PRÓPRIO site — que não depende de fornecedor nenhum — morria junto. A
 * tabela do resumo ficou em zero linha, e nenhuma das 198 checagens percebeu.
 *
 * A REGRA, e ela não é uma lista de módulos permitidos. Módulo que não fecha
 * ATIVO num site recém-entregue tem de NOMEAR, no próprio motivo, uma option
 * que está VAZIA neste site. É a única inércia legítima: falta um dado que só o
 * operador tem — número de WhatsApp, token da CAPI, token de verificação de
 * domínio. Qualquer outra inércia é decisão NOSSA de entregar o site com uma
 * parte desligada, e é ela que esta checagem existe para acusar.
 *
 * A lista de options nasce do arquivo REAL do implantador, lida por expressão
 * regular sobre `etapa_options_site_core()`: option acrescentada lá e esquecida
 * aqui faz esta checagem cair, em vez de passar a medir um site menor que o
 * entregue.
 * ======================================================================= */

$nome = 'modulos.nascem_ativos';

/*
 * O QUE O IMPLANTADOR ESCREVE NUM SITE NOVO, com o `config/projeto.json` e o
 * `config/decisoes.tsv` ENTREGUES — os valores saem dos produtores únicos, e
 * não de números digitados aqui: uma decisão trocada no catálogo tem de mudar o
 * que esta checagem mede, senão ela estaria medindo outro pacote.
 */
$payload_de_entrega = array(
	'f3base_contato'                => array( 'whatsapp_e164' => (string) F3Base_Andaime_Config::projeto( 'contato.whatsapp_e164', '' ), 'mensagem_padrao' => '' ),
	'f3base_consentimento'          => array(
		'padrao'                => (string) F3Base_Andaime_Config::decisao( 'consentimento.padrao' ),
		'controle_rodape'       => (bool) F3Base_Andaime_Config::decisao( 'consentimento.controle_rodape' ),
		'aviso_primeira_visita' => (bool) F3Base_Andaime_Config::decisao( 'consentimento.aviso_primeira_visita' ),
		'ttl_dias'              => (int) F3Base_Andaime_Config::decisao( 'consentimento.ttl_dias' ),
	),
	'f3base_atribuicao'             => array( 'modelo' => (string) F3Base_Andaime_Config::decisao( 'atribuicao.modelo' ), 'ttl_dias' => (int) F3Base_Andaime_Config::decisao( 'atribuicao.ttl_dias' ) ),
	'f3base_retencao_meses'         => (int) F3Base_Andaime_Config::projeto( 'fato_juridico.retencao_leads_meses', 0 ),
	'f3base_comportamento'          => array(
		'ligado'         => (bool) F3Base_Andaime_Config::decisao( 'comportamento.ligado' ),
		'retencao_dias'  => (int) F3Base_Andaime_Config::decisao( 'comportamento.retencao_dias' ),
		'dias_no_painel' => (int) F3Base_Andaime_Config::decisao( 'comportamento.dias_no_painel' ),
	),
	'f3base_linkedin_partner_id'    => (string) F3Base_Andaime_Config::projeto( 'tracking.linkedin_partner_id', '' ),
	'f3base_llms'                   => array(
		'ligado'    => (bool) F3Base_Andaime_Config::decisao( 'bots_ia.llms_txt' ),
		'modo'      => (string) F3Base_Andaime_Config::decisao( 'bots_ia.llms_txt_modo' ),
		'tipos'     => array_map( 'strval', (array) F3Base_Andaime_Config::decisao( 'bots_ia.llms_txt_tipos' ) ),
		'full'      => (bool) F3Base_Andaime_Config::decisao( 'bots_ia.llms_full_txt' ),
		'indexavel' => (bool) F3Base_Andaime_Config::decisao( 'bots_ia.llms_indexavel' ),
		'livres'    => array(),
	),
	'f3base_redirects'              => array(),
	'f3base_seo_entidade'           => array( 'nome' => 'Bancada', 'faq_schema' => (bool) F3Base_Andaime_Config::decisao( 'seo.organizacao.faq_schema' ) ),
	'f3base_cabecalhos'             => array(
		'x_content_type_options' => (bool) F3Base_Andaime_Config::decisao( 'cabecalhos.x_content_type_options' ),
		'x_frame_options'        => (string) F3Base_Andaime_Config::decisao( 'cabecalhos.x_frame_options' ),
		'csp_frame_ancestors'    => (string) F3Base_Andaime_Config::decisao( 'cabecalhos.csp_frame_ancestors' ),
		'referrer_policy'        => (string) F3Base_Andaime_Config::decisao( 'cabecalhos.referrer_policy' ),
		'coop'                   => (string) F3Base_Andaime_Config::decisao( 'cabecalhos.coop' ),
		'permissions_policy'     => (string) F3Base_Andaime_Config::decisao( 'cabecalhos.permissions_policy' ),
		'hsts'                   => (bool) F3Base_Andaime_Config::decisao( 'cabecalhos.hsts' ),
		'hsts_max_age'           => (int) F3Base_Andaime_Config::decisao( 'cabecalhos.hsts_max_age' ),
	),
	'f3base_origem_confiavel'       => array( 'cabecalho' => (string) F3Base_Andaime_Config::projeto( 'origem_confiavel.cabecalho', '' ), 'saltos' => (int) F3Base_Andaime_Config::projeto( 'origem_confiavel.saltos', 1 ) ),
	'f3base_gtm_container_id'       => (string) F3Base_Andaime_Config::projeto( 'tracking.gtm_container_id', '' ),
	'f3base_ga4_measurement_id'     => (string) F3Base_Andaime_Config::projeto( 'tracking.ga4_measurement_id', '' ),
	'f3base_google_ads'             => array( 'conversion_id' => (string) F3Base_Andaime_Config::projeto( 'tracking.google_ads.conversion_id', '' ), 'conversion_label' => (string) F3Base_Andaime_Config::projeto( 'tracking.google_ads.conversion_label', '' ) ),
	'f3base_meta_pixel_id'          => (string) F3Base_Andaime_Config::projeto( 'tracking.meta_pixel_id', '' ),
	'f3base_linkedin_conversion_id' => (string) F3Base_Andaime_Config::projeto( 'tracking.linkedin_conversion_id', '' ),
	'f3base_verificacao_google'     => (string) F3Base_Andaime_Config::projeto( 'verificacao_dominio.google', '' ),
	'f3base_verificacao_meta'       => (string) F3Base_Andaime_Config::projeto( 'verificacao_dominio.meta', '' ),
);

/*
 * O PISO DO ELENCO FICOU NO IMPLANTADOR, e a saída é de posse, não de rigor.
 * Ele lia `includes/class-f3base-imp-lotes.php::etapa_options_site_core()` e
 * exigia que as options desta bancada fossem exatamente as que o lote real
 * escreve — cruzamento entre dois pacotes, cuja segunda ponta não existe aqui.
 * O que continua sendo medido é a pergunta que é do PLUGIN: com estas options
 * gravadas, todo módulo do registro nasce ATIVO, e o que não nasce nomeia uma
 * option VAZIA como razão. A lista gravada não é digitada: ela sai do retrato
 * declarado em `suite/fixtures/config/site-core.json`, que é o que o
 * implantador entregava.
 */

/**
 * Aplica o site recém-entregue à bancada.
 *
 * @param array<string,mixed> $payload Options a gravar.
 * @return void
 */
function f3b_site_recem_entregue( array $payload ): void {
	bancada_limpa();
	requisicao_nova();
	F3Base_Modulo_Comportamento::criar_tabela();

	foreach ( $payload as $option => $valor ) {
		F3Base_Options::gravar( $option, $valor, F3Base_Options::ORIGEM_IMPLANTADOR );
	}

	/*
	 * A CADÊNCIA É GRAVADA PELA ETAPA DELA, e por isso entra aqui à parte: o
	 * módulo lê `f3base_cadencia` para decidir o próprio estado, e sem a option
	 * ele fecharia inativo por uma razão que não é do site entregue.
	 */
	F3Base_Options::gravar(
		'f3base_cadencia',
		array(
			'periodicidade'  => (string) F3Base_Andaime_Config::decisao( 'cadencia_relatorio.periodicidade' ),
			'apos_n_ajustes' => (int) F3Base_Andaime_Config::decisao( 'cadencia_relatorio.apos_n_ajustes' ),
			'mecanismo'      => 'wp-cron',
			'hook'           => 'f3base_cadencia_relatorio',
		),
		F3Base_Options::ORIGEM_IMPLANTADOR
	);

	wp_schedule_event( time() + DAY_IN_SECONDS, 'f3base_mensal', 'f3base_cadencia_relatorio' );

	/*
	 * OS DOIS PLUGINS QUE O CATÁLOGO INSTALA. Sem eles a bancada mediria um
	 * site em que a hospedagem não instalou nada — e dois módulos fechariam
	 * degradado por ausência que o implantador resolve na etapa de plugins.
	 */
	$slug_do_seo = F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO );

	/*
	 * A LISTA DE PLUGINS ATIVOS É ESTADO DO WORDPRESS, e não option do pacote:
	 * ela entra direto no armazenamento da bancada. Passar pelo gravador de
	 * options seria pedir ao ponto único de escrita do pacote que escrevesse
	 * uma option que não é dele.
	 */
	$GLOBALS['f3b_bench']['options']['active_plugins'] = array(
		$slug_do_seo . '/' . $slug_do_seo . '.php',
		'flamingo/flamingo.php',
		'contact-form-7/wp-contact-form-7.php',
	);

	/*
	 * O FLAMINGO É DETECTADO PELA CLASSE, e não pela lista de plugins ativos —
	 * é a classe que o módulo de leads chama para gravar. Declará-la aqui é o
	 * que faz a bancada medir o site que o implantador entrega, e não um site
	 * em que a etapa de plugins não rodou.
	 */
	f3b_flamingo_na_bancada();

	requisicao_nova();
}

/**
 * A CAIXA DE LEADS que o catálogo de plugins instala.
 *
 * O módulo de leads a detecta pela CLASSE, e não pela lista de plugins ativos —
 * é a classe que ele chama para gravar. Sem ela a bancada mediria um site em
 * que a etapa de plugins não rodou, e o módulo fecharia degradado por uma
 * ausência que o implantador resolve.
 */
if ( ! class_exists( 'Flamingo_Inbound_Message' ) ) {
	// phpcs:ignore
	class Flamingo_Inbound_Message {

		/**
		 * @param array<string,mixed> $dados Campos da mensagem.
		 * @return int
		 */
		public static function add( array $dados ) {
			$GLOBALS['f3b_bench']['flamingo'][] = $dados;

			return count( (array) ( $GLOBALS['f3b_bench']['flamingo'] ?? array() ) );
		}
	}
}

/**
 * Declara a caixa de leads presente nesta bancada.
 *
 * @return void
 */
function f3b_flamingo_na_bancada(): void {
	$GLOBALS['f3b_bench']['flamingo'] = array();
}

/**
 * As options que estão VAZIAS neste site — o único álibi de um módulo inerte.
 *
 * Vazio é medido no valor inteiro: string vazia, zero, lista vazia, ou array
 * cujas folhas são todas vazias. `f3base_contato` com o WhatsApp em branco é
 * vazia, e é assim que o regime de WhatsApp tem álibi sem que ninguém precise
 * escrever o nome dele numa lista de exceções.
 *
 * @return array<int,string>
 */
function f3b_options_vazias(): array {
	$vazias = array();

	foreach ( F3Base_Options::nomes() as $option ) {
		if ( f3b_valor_vazio( F3Base_Options::ler( $option ) ) ) {
			$vazias[] = $option;
		}
	}

	return $vazias;
}

/**
 * O valor é vazio em todas as folhas?
 *
 * @param mixed $valor Valor lido.
 * @return bool
 */
function f3b_valor_vazio( $valor ): bool {
	if ( is_array( $valor ) ) {
		foreach ( $valor as $folha ) {
			if ( ! f3b_valor_vazio( $folha ) ) {
				return false;
			}
		}

		return true;
	}

	if ( is_bool( $valor ) ) {
		return ! $valor;
	}

	return '' === (string) $valor || '0' === (string) $valor;
}

f3b_site_recem_entregue( $payload_de_entrega );

$vazias_no_site = f3b_options_vazias();
$sem_alibi      = array();

foreach ( F3Base_Registro::instanciar() as $id_do_modulo => $modulo_entregue ) {
	$estado_entregue = $modulo_entregue->estado();

	if ( F3Base_Modulo::ATIVO === $estado_entregue['estado'] ) {
		continue;
	}

	$alibi = false;
	if ( F3Base_Modulo::DEGRADADO === $estado_entregue['estado'] ) {
		foreach ( $modulo_entregue->dependencias() as $dependencia ) { if ( empty( $dependencia['presente'] ) ) { $alibi = true; } }
	}

	foreach ( $vazias_no_site as $option_vazia ) {
		if ( str_contains( $estado_entregue['motivo'], $option_vazia ) ) {
			$alibi = true;
			break;
		}
	}

	if ( ! $alibi ) {
		$sem_alibi[] = $id_do_modulo . ' (' . $estado_entregue['estado'] . '): ' . $estado_entregue['motivo'];
	}
}

afirmar(
	$nome,
	array() === $sem_alibi,
	'TETO: num site recém-entregue, com o projeto.json intocado, há módulo que não nasce ativo e cuja inércia NÃO é falta de dado do operador — é decisão nossa de entregar o site com uma parte desligada: ' . implode( ' | ', $sem_alibi )
);

/*
 * O CASO DE PRODUÇÃO, e ele é o piso mais caro desta release: site SEM NENHUM
 * ID de fornecedor tem de servir o coletor de comportamento E gravar linha na
 * tabela. Era exatamente isto que não acontecia, com todas as options certas.
 */
afirmar(
	$nome,
	F3Base_Modulo_Tracking::CAMINHO_NENHUM === F3Base_Modulo_Tracking::caminho(),
	'TETO do caso de produção: a bancada não está medindo um site sem ID de fornecedor — o caminho é "' . F3Base_Modulo_Tracking::caminho() . '", e o caso que apagou a medição em produção deixou de ser exercitado'
);

$GLOBALS['f3b_bench']['scripts'] = array();

foreach ( F3Base_Registro::instanciar() as $modulo_do_hook ) {
	if ( ! $modulo_do_hook->deve_registrar() ) {
		continue;
	}

	foreach ( $modulo_do_hook->hooks() as $hook_declarado ) {
		if ( 'wp_enqueue_scripts' === (string) $hook_declarado['hook'] ) {
			$modulo_do_hook->{$hook_declarado['metodo']}();
		}
	}
}

afirmar(
	$nome,
	array_key_exists( F3Base_Modulo_Tracking::HANDLE, $GLOBALS['f3b_bench']['scripts'] ),
	'TETO do caso de produção: sem nenhum ID de fornecedor, o carregador NÃO chegou ao HTML — e com ele morre o coletor de comportamento do próprio site, que não depende de fornecedor nenhum. Foi assim que a tabela do resumo ficou em zero linha num site em que tudo estava configurado'
);

postar_comportamento(
	carga_de_comportamento(
		array(
			'metricas' => array(
				array(
					'gatilho'  => 'rolagem',
					'detalhe'  => '50',
					'contagem' => 2,
				),
			),
		)
	)
);

afirmar(
	$nome,
	(int) F3Base_Modulo_Comportamento::resumo()['linhas'] > 0,
	'TETO do caso de produção: sem nenhum ID de fornecedor, o resumo enviado pelo navegador não virou linha na tabela — servir o coletor e não gravar o que ele manda é a mesma cegueira por outro caminho'
);

/*
 * PISO DO TETO ACIMA: desligada a coleta do próprio site — e continuando sem ID
 * de fornecedor —, o carregador NÃO pode ser servido. Sem este lado a regra
 * teria virado "sempre servir", que é peso no HTML de um site sem destino.
 */
$payload_sem_coleta                             = $payload_de_entrega;
$payload_sem_coleta['f3base_comportamento']     = array( 'ligado' => false, 'retencao_dias' => 90, 'dias_no_painel' => 28 );

f3b_site_recem_entregue( $payload_sem_coleta );

$GLOBALS['f3b_bench']['scripts'] = array();
( new F3Base_Modulo_Tracking() )->enfileirar();

afirmar(
	$nome,
	! array_key_exists( F3Base_Modulo_Tracking::HANDLE, $GLOBALS['f3b_bench']['scripts'] ),
	'PISO do caso de produção: sem ID de fornecedor E com a coleta do próprio site desligada, o carregador foi servido mesmo assim — não há destino nenhum, e um carregador no HTML sobre nada é peso sem medida'
);

/*
 * PISO DA REGRA DO ÁLIBI: uma decisão do pacote que desliga um módulo tem de
 * ser ACUSADA. Sem isto, a regra passaria de graça em qualquer entrega — e ela
 * existe justamente para impedir que uma parte do site nasça desligada por
 * escolha nossa.
 */
$payload_com_llms_desligado                = $payload_de_entrega;
$payload_com_llms_desligado['f3base_llms'] = array_merge( $payload_de_entrega['f3base_llms'], array( 'ligado' => false, 'full' => false ) );

f3b_site_recem_entregue( $payload_com_llms_desligado );

$vazias_com_llms_desligado = f3b_options_vazias();
$acusados_pelo_piso        = array();

foreach ( F3Base_Registro::instanciar() as $id_mutante => $modulo_mutante ) {
	$estado_mutante = $modulo_mutante->estado();

	if ( F3Base_Modulo::ATIVO === $estado_mutante['estado'] ) {
		continue;
	}

	$tem_alibi = false;

	foreach ( $vazias_com_llms_desligado as $option_vazia ) {
		if ( str_contains( $estado_mutante['motivo'], $option_vazia ) ) {
			$tem_alibi = true;
			break;
		}
	}

	if ( ! $tem_alibi ) {
		$acusados_pelo_piso[] = $id_mutante;
	}
}

afirmar(
	$nome,
	in_array( 'llms-txt-reserva', $acusados_pelo_piso, true ) && in_array( 'llms-full-txt', $acusados_pelo_piso, true ),
	'PISO da regra do álibi: desligado o llms.txt por decisão do pacote, os dois módulos que ele controla continuaram passando. A regra não distingue "falta dado do operador" de "nós entregamos desligado", e nesse estado ela não protege nada — acusou: ' . implode( ', ', $acusados_pelo_piso )
);


/* ==========================================================================
 * comportamento.estrutura_declarada
 *
 * O QUE SE MEDE AQUI. As DUAS tabelas do módulo são declaradas e conferidas do
 * MESMO jeito, e a estrutura delas é comparável pelo `dbDelta`.
 *
 * O DEFEITO. A prontidão de `f3base_eventos` não entrava em `dependencias()`,
 * não entrava em `calcular_estado()` e não era conferida em `receber()`. Um site
 * com a tabela do resumo criada e a do registro não — o caso de toda ATUALIZAÇÃO
 * cuja migração parou no meio — mostrava o módulo ATIVO, a rota respondia 201 e
 * `registrar_evento()` descartava cada linha devolvendo `false` em silêncio: o
 * cliente apagava o lote ao ver 2xx e a tela dizia "não medido" para sempre.
 *
 * E A LARGURA DE EXIBIÇÃO NO DDL. `bigint(20)` e `int(10)` nunca tiveram efeito
 * sobre o que a coluna guarda, e desde o MySQL 8.0.19 o servidor as DESCARTA ao
 * criar a tabela. `dbDelta()` compara a definição declarada com a que o banco
 * devolve: a declarada traz a largura, a devolvida não, e ele emite um `ALTER
 * TABLE` a cada chamada — em toda requisição que passe por `garantir_estrutura()`,
 * para sempre, sem que nada mude.
 * ======================================================================= */

$nome = 'comportamento.estrutura_declarada';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$modulo_da_estrutura = new F3Base_Modulo_Comportamento();
$rotulos_declarados  = array();

foreach ( $modulo_da_estrutura->dependencias() as $dependencia_declarada ) {
	$rotulos_declarados[] = (string) $dependencia_declarada['rotulo'];
}

/* TETO: as DUAS tabelas aparecem entre as dependências do módulo. */
afirmar(
	$nome,
	in_array( F3Base_Modulo_Comportamento::nome_tabela(), $rotulos_declarados, true )
		&& in_array( F3Base_Modulo_Comportamento::nome_tabela_eventos(), $rotulos_declarados, true ),
	'teto das dependências: a tela de diagnóstico lista ' . implode( ', ', $rotulos_declarados )
		. ' e precisa listar as DUAS tabelas. Estrutura que não aparece nas dependências é estrutura que ninguém confere antes de o site começar a perder linha'
);

afirmar(
	$nome,
	F3Base_Modulo::ATIVO === $modulo_da_estrutura->estado()['estado'],
	'teto do estado: com as duas tabelas prontas o módulo não fecha ATIVO'
);

/* PISO: sem o registro pronto, o módulo degrada e as DUAS rotas recusam. */
global $wpdb;

unset( $wpdb->tabelas[ F3Base_Modulo_Comportamento::nome_tabela_eventos() ] );
requisicao_nova();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Comportamento() )->estado()['estado'],
	'piso do registro ausente: sem a tabela do registro o módulo continuou ATIVO. Módulo ativo sobre uma tabela que não existe é a perda ficando invisível'
);

$r = postar_comportamento(
	carga_de_comportamento(
		array(
			'visitante' => str_repeat( 'a', 32 ),
			'sessao'    => str_repeat( 'b', 32 ),
			'eventos'   => array(
				array(
					'gatilho'    => 'rolagem',
					'detalhe'    => '50',
					'ocorrencia' => 1,
					'ms'         => 1000,
				),
			),
		)
	)
);

afirmar(
	$nome,
	503 === $r->status && 'f3base_registro_indisponivel' === (string) ( $r->data['codigo'] ?? '' ),
	'piso do registro ausente: a rota respondeu ' . $r->status . ' em vez de 503 nomeando a tabela. Com 2xx o cliente apaga o lote, e o registro daquele carregamento some sem erro em lugar nenhum'
);

$r = ( new F3Base_Modulo_Comportamento() )->esquecer(
	new WP_REST_Request(
		array(
			'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'visitante' => str_repeat( 'a', 32 ),
		),
		null
	)
);

afirmar(
	$nome,
	503 === $r->status && false === $r->data['apagado'],
	'piso do registro ausente na exclusão: a rota respondeu ' . $r->status . ' com apagado = ' . var_export( $r->data['apagado'] ?? null, true )
		. '. Confirmar um apagamento que nem chegou a ser tentado é pior que recusar: quem exerceu o direito não tem por que pedir de novo'
);

/* TETO do DDL: nenhuma coluna inteira declara largura de exibição. */
$fonte_do_modulo = (string) @file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-comportamento.php' );
$ddl_do_modulo   = '';

if ( preg_match_all( '/CREATE TABLE \{\$[a-z_]+\} \((.*?)\) \{\$collate\}/s', $fonte_do_modulo, $blocos_do_ddl ) ) {
	$ddl_do_modulo = implode( "\n", $blocos_do_ddl[1] );
}

afirmar(
	$nome,
	'' !== $ddl_do_modulo,
	'piso da bancada: as declarações CREATE TABLE do módulo não foram encontradas, e sem elas nada abaixo mede o que promete'
);

afirmar(
	$nome,
	1 !== preg_match( '/\b(?:tiny|small|medium|big)?int\(\d+\)/', $ddl_do_modulo ),
	'teto do DDL comparável: uma coluna inteira ainda declara largura de exibição. O MySQL 8 a descarta ao criar a tabela, e o dbDelta compara a definição declarada com a devolvida: ele passa a emitir um ALTER TABLE a cada chamada, para sempre, sem que nada mude'
);

afirmar(
	$nome,
	1 === preg_match( '/\b(?:tiny|small|medium|big)?int\(\d+\)/', (string) preg_replace( '/\bbigint unsigned/', 'bigint(20) unsigned', $ddl_do_modulo, 1 ) ),
	'piso do DDL comparável: reposta a largura numa coluna, a regra continuou em silêncio — detector cego'
);

/* ==========================================================================
 * comportamento.teto_por_entrada
 *
 * O QUE SE MEDE AQUI. Cada CAMPO NUMÉRICO de uma entrada do corpo tem teto
 * DECLARADO, e não só a lista tem tamanho máximo.
 *
 * O DEFEITO. O teto da lista existia — a soma dos tetos declarados — e limita
 * quantas ENTRADAS cabem no corpo. Nenhum número limitava o que cada uma carrega
 * dentro: `contagem`, `soma` e `valor` só precisavam ser "finitos e não
 * negativos", e `cortados` só precisava ser positivo. Esta rota é pública,
 * autorizada por um token efêmero impresso em toda página — uma requisição só
 * envenenava o total de uma página no painel para sempre, e o operador via um
 * número absurdo sem nada em lugar nenhum dizendo de onde ele veio.
 *
 * OS NÚMEROS SÃO OS DECLARADOS: o teto POR PÁGINA do evento para a contagem (é,
 * por construção, o máximo de vezes que o cliente consegue emiti-lo num
 * carregamento) e o teto por medida de `dados/vitais.tsv` para o valor e para a
 * soma.
 * ======================================================================= */

$nome = 'comportamento.teto_por_entrada';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$declaracao_do_teto = F3Base_Modulo_Tracking::eventos_de_comportamento();
$teto_da_rolagem    = 0;
$nome_do_desempenho = F3Base_Modulo_Comportamento::evento_do_gatilho( 'desempenho' );

foreach ( $declaracao_do_teto as $dados_do_teto ) {
	if ( 'rolagem' === (string) $dados_do_teto['gatilho'] ) {
		$teto_da_rolagem = (int) $dados_do_teto['teto'];
	}
}

afirmar(
	$nome,
	$teto_da_rolagem > 0 && '' !== $nome_do_desempenho && array() !== F3Base_Modulo_Comportamento::tetos_dos_vitais(),
	'piso da bancada: a declaração de eventos ou a de medidas de carregamento não trouxe os tetos, e sem eles nada abaixo mede o que promete'
);

$tetos_das_medidas = F3Base_Modulo_Comportamento::tetos_dos_vitais();
$teto_do_lcp       = (float) ( $tetos_das_medidas['LCP'] ?? 0.0 );

/**
 * Um corpo com um total só, para exercitar os tetos por entrada.
 *
 * @param array<string,mixed> $total Campos do total.
 * @return WP_REST_Response
 */
function postar_total_unico( array $total ): WP_REST_Response {
	return postar_comportamento( carga_de_comportamento( array( 'metricas' => array( $total ) ) ) );
}

/* TETO: a contagem no limite declarado passa. */
$r = postar_total_unico(
	array(
		'gatilho'  => 'rolagem',
		'detalhe'  => '50',
		'contagem' => $teto_da_rolagem,
	)
);

afirmar(
	$nome,
	201 === $r->status,
	'teto da contagem: um total com a contagem exatamente no teto por página declarado foi recusado com ' . $r->status . '. O teto é o que o cliente consegue emitir num carregamento, e recusá-lo jogaria fora medição legítima'
);

/* PISO: um a mais que o teto declarado é recusado pelo nome. */
$r = postar_total_unico(
	array(
		'gatilho'  => 'rolagem',
		'detalhe'  => '50',
		'contagem' => $teto_da_rolagem + 1,
	)
);

afirmar(
	$nome,
	400 === $r->status && 'f3base_contagem_demais' === (string) ( $r->data['codigo'] ?? '' ) && $teto_da_rolagem === (int) ( $r->data['limite'] ?? 0 ),
	'piso da contagem: um total acima do teto por página declarado entrou — status ' . $r->status . ', código ' . (string) ( $r->data['codigo'] ?? '' )
		. '. Sem este teto, uma requisição só envenena o total daquela página no painel para sempre'
);

/* PISO: a soma acima do teto declarado da medida é recusada pelo nome. */
$r = postar_total_unico(
	array(
		'gatilho'  => 'desempenho',
		'detalhe'  => 'LCP',
		'contagem' => 1,
		'soma'     => $teto_do_lcp + 1.0,
	)
);

afirmar(
	$nome,
	400 === $r->status && 'f3base_soma_demais' === (string) ( $r->data['codigo'] ?? '' ),
	'piso da soma: uma soma acima do teto declarado daquela medida entrou — status ' . $r->status . ', código ' . (string) ( $r->data['codigo'] ?? '' )
		. '. É por ela que a média de carregamento do site inteiro vira um número que ninguém consegue interpretar'
);

/* TETO: a soma dentro do teto, multiplicada pela contagem, continua passando. */
$r = postar_total_unico(
	array(
		'gatilho'  => 'desempenho',
		'detalhe'  => 'LCP',
		'contagem' => 2,
		'soma'     => $teto_do_lcp * 2,
	)
);

afirmar(
	$nome,
	201 === $r->status,
	'teto da soma: duas medidas no teto somam o dobro do teto e foram recusadas com ' . $r->status . '. A soma é `contagem` valores somados, e um teto que não multiplicasse pela contagem recusaria medição legítima'
);

/* PISO: o valor de uma linha do registro tem o mesmo teto declarado. */
$r = postar_comportamento(
	carga_de_comportamento(
		array(
			'visitante' => str_repeat( 'c', 32 ),
			'sessao'    => str_repeat( 'd', 32 ),
			'eventos'   => array(
				array(
					'gatilho'    => 'desempenho',
					'detalhe'    => 'LCP',
					'valor'      => $teto_do_lcp + 1.0,
					'ocorrencia' => 1,
					'ms'         => 10,
				),
			),
		)
	)
);

afirmar(
	$nome,
	400 === $r->status && 'f3base_valor_demais' === (string) ( $r->data['codigo'] ?? '' ),
	'piso do valor: uma linha do registro com valor acima do teto declarado entrou — status ' . $r->status . ', código ' . (string) ( $r->data['codigo'] ?? '' )
);

/* PISO: o corte declarado pelo cliente é aparado no orçamento da visita. */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

postar_comportamento( carga_de_comportamento( array( 'cortados' => 999999999 ) ) );

$cortadas_gravadas = 0;

foreach ( linhas_do_resumo() as $linha_gravada ) {
	if ( F3Base_Modulo_Comportamento::METRICA_CORTADAS === (string) $linha_gravada['metrica'] ) {
		$cortadas_gravadas = (int) $linha_gravada['contagem'];
	}
}

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::MAX_POR_VISITA === $cortadas_gravadas,
	'piso do corte declarado: o cliente disse ter cortado 999999999 e a tabela guardou ' . $cortadas_gravadas
		. '. O teto é o orçamento da VISITA — o mesmo número que o cliente usa para parar de contar —, e sem ele a tela anuncia que milhões de acionamentos foram descartados numa página que teve três visitas'
);

/* TETO: detalhe fora da declaração de medidas usa o MAIOR teto declarado. */
afirmar(
	$nome,
	F3Base_Modulo_Comportamento::teto_do_valor( 'nao-declarado' ) === (float) max( $tetos_das_medidas ),
	'teto do detalhe não declarado: o teto de um detalhe que não nomeia medida nenhuma precisa ser o MAIOR declarado — inventar um número aqui seria a segunda verdade que a declaração existe para impedir'
);

/* ==========================================================================
 * medicao.quadro_de_vitais
 *
 * O QUE SE MEDE AQUI. O quadro das medidas de carregamento existe na tela, com
 * a explicação e a régua ao lado de cada sigla — e a média delas é média.
 *
 * OS DOIS DEFEITOS. O primeiro é de AUSÊNCIA: `resumo()['vitais']` já era
 * calculado, `dados/vitais.tsv` já trazia a explicação e o limiar, e nenhuma
 * linha da tela chamava qualquer um dos dois. Quatro medidas eram coletadas em
 * toda visita, gravadas, somadas — e lidas por ninguém.
 *
 * O segundo é de CONTA. O balde dos vitais agrupava por `detalhe` sozinho, sem
 * olhar a métrica: o marco `50` da rolagem e o bloco `faq` disputavam o quadro
 * com as siglas. E ele excluía as linhas de soma zero, que são justamente o CLS
 * perfeito de uma página firme e o TTFB de um cache que respondeu na hora — a
 * média subia por descartar os melhores carregamentos, e a amostra ao lado dizia
 * menos visitas do que houve.
 * ======================================================================= */

$nome = 'medicao.quadro_de_vitais';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$declaradas_do_quadro = F3Base_Modulo_Tracking::vitais_declarados();

afirmar(
	$nome,
	array() !== $declaradas_do_quadro,
	'piso da bancada: a declaração das medidas de carregamento veio vazia, e sem ela nada abaixo mede o que promete'
);

/* Uma medida de soma ZERO — a página firme — e duas de soma positiva. */
foreach ( array( 0.0, 0.0, 0.0 ) as $cls_medido ) {
	postar_total_unico(
		array(
			'gatilho'  => 'desempenho',
			'detalhe'  => 'CLS',
			'contagem' => 1,
			'soma'     => $cls_medido,
		)
	);
}

foreach ( array( 1800.0, 2200.0 ) as $lcp_medido ) {
	postar_total_unico(
		array(
			'gatilho'  => 'desempenho',
			'detalhe'  => 'LCP',
			'contagem' => 1,
			'soma'     => $lcp_medido,
		)
	);
}

/* Um evento de USO com um detalhe que tem o nome de uma medida. */
postar_total_unico(
	array(
		'gatilho'  => 'rolagem',
		'detalhe'  => 'LCP',
		'contagem' => 1,
	)
);

$vitais_do_quadro = array();

foreach ( F3Base_Modulo_Comportamento::resumo()['vitais'] as $vital_lido ) {
	$vitais_do_quadro[ (string) $vital_lido['metrica'] ] = $vital_lido;
}

/* TETO: a linha de soma ZERO entra, e a média dela é zero com a amostra certa. */
afirmar(
	$nome,
	isset( $vitais_do_quadro['CLS'] ) && 3 === (int) $vitais_do_quadro['CLS']['amostra'] && 0.0 === (float) $vitais_do_quadro['CLS']['media'],
	'teto da soma zero: o CLS de três páginas firmes saiu com amostra ' . (int) ( $vitais_do_quadro['CLS']['amostra'] ?? 0 )
		. ' e média ' . (float) ( $vitais_do_quadro['CLS']['media'] ?? -1 )
		. '. Excluir a linha de soma zero é descartar justamente o melhor carregamento, e a média sobe sozinha'
);

afirmar(
	$nome,
	isset( $vitais_do_quadro['LCP'] ) && 2 === (int) $vitais_do_quadro['LCP']['amostra'] && 2000.0 === (float) $vitais_do_quadro['LCP']['media'],
	'teto da média: o LCP de duas visitas não saiu como soma dividida por contagem'
);

/* PISO: um detalhe com nome de medida, vindo de OUTRO evento, não entra. */
afirmar(
	$nome,
	2 === (int) $vitais_do_quadro['LCP']['amostra'],
	'piso da métrica: uma rolagem com o detalhe "LCP" entrou no quadro das medidas de carregamento. Quem decide o que é medida de carregamento é o GATILHO declarado, e não o texto do detalhe'
);

/* TETO da tela: o quadro é renderizado com a sigla, a explicação e o limiar. */
ob_start();
F3Base_Admin_Medicao::render();
$tela_com_vitais = (string) ob_get_clean();

$faltando_no_quadro = array();

foreach ( $declaradas_do_quadro as $sigla_declarada => $declaracao_da_medida ) {
	if ( ! str_contains( $tela_com_vitais, (string) $sigla_declarada ) ) {
		$faltando_no_quadro[] = 'a sigla ' . $sigla_declarada;
	}

	if ( ! str_contains( $tela_com_vitais, esc_html( (string) $declaracao_da_medida['explicacao'] ) ) ) {
		$faltando_no_quadro[] = 'a explicação de ' . $sigla_declarada;
	}
}

afirmar(
	$nome,
	array() === $faltando_no_quadro,
	'teto do quadro: a tela não imprime ' . implode( ', ', $faltando_no_quadro )
		. '. Sigla nua com um número ao lado não decide nada: quem opera o site não tem obrigação de saber o que significa LCP, e um número sem régua é enfeite'
);

/* PISO do produtor único: a explicação NÃO está escrita dentro do PHP da tela. */
$fonte_da_tela_de_medicao = (string) @file_get_contents( $raiz . '/fontes/plugin/admin/class-f3base-admin-medicao.php' );
$explicacoes_na_tela      = array();

foreach ( $declaradas_do_quadro as $sigla_declarada => $declaracao_da_medida ) {
	if ( str_contains( $fonte_da_tela_de_medicao, (string) $declaracao_da_medida['explicacao'] ) ) {
		$explicacoes_na_tela[] = (string) $sigla_declarada;
	}
}

afirmar(
	$nome,
	array() === $explicacoes_na_tela,
	'piso do produtor único: a explicação de ' . implode( ', ', $explicacoes_na_tela )
		. ' está escrita dentro do PHP da tela. Escrita ali, ela é uma segunda descrição da mesma medida e diverge da declaração na primeira vez que alguém mexer numa e não na outra'
);

/* ==========================================================================
 * medicao.tela_declara_o_recorte
 *
 * O QUE SE MEDE AQUI. A tela não afirma recorte que a consulta não fez, e diz
 * qual é o período e qual é o fuso do dia.
 *
 * OS TRÊS DEFEITOS. Um filtro fora da forma do apelido era DESCARTADO pela
 * consulta e ANUNCIADO pela tela: "Mostrando apenas o visitante joao@exe" sobre
 * uma tabela com todos os visitantes. `dias_no_painel` e `retencao_eventos_dias`
 * são chaves independentes, e com o painel somando mais dias do que o registro
 * guarda os quadros de uma tabela e os da outra cobriam períodos diferentes
 * dizendo o mesmo número. E o corte por dia é UTC nas duas tabelas enquanto a
 * coluna Horário sai no fuso do site — a diferença é real perto da virada, e a
 * tela não a declarava em lugar nenhum.
 * ======================================================================= */

$nome = 'medicao.tela_declara_o_recorte';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$visitante_do_recorte = str_repeat( 'e', 32 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'visitante' => $visitante_do_recorte,
			'sessao'    => str_repeat( 'f', 32 ),
			'eventos'   => array(
				array(
					'gatilho'    => 'rolagem',
					'detalhe'    => '50',
					'ocorrencia' => 1,
					'ms'         => 1200,
				),
			),
		)
	)
);

/* TETO do fuso: a frase é impressa e tem produtor único. */
$_GET = array();

ob_start();
F3Base_Admin_Medicao::render();
$tela_sem_filtro = (string) ob_get_clean();

afirmar(
	$nome,
	str_contains( $tela_sem_filtro, esc_html( F3Base_Modulo_Comportamento::fuso_do_dia() ) ),
	'teto do fuso declarado: a tela não diz que o corte por DIA é em UTC enquanto a data e o horário saem no fuso do site. Perto da virada os dois quadros discordam por algumas horas, e quem soma conclui que um deles está errado'
);

/* PISO do filtro inválido: a tela NÃO afirma o recorte que a consulta recusou. */
$_GET = array( 'visitante' => 'joao@exemplo.test' );

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_filtro_ruim = (string) ob_get_clean();

$_GET = array();

afirmar(
	$nome,
	! str_contains( $tela_com_filtro_ruim, 'Mostrando apenas o visitante' ),
	'piso do filtro inválido: a tela anunciou o recorte por visitante com um valor que não tem a forma de um apelido. A consulta o descarta e traz TODOS — e quem lê a frase conclui que aquele visitante fez tudo aquilo'
);

afirmar(
	$nome,
	str_contains( $tela_com_filtro_ruim, 'IGNORADO' ),
	'teto do filtro inválido: a tela descartou o filtro e não disse que descartou. Recorte que some sem aviso é a mesma tabela respondendo a duas perguntas diferentes'
);

/* TETO do filtro válido: com um apelido de verdade, o recorte é anunciado. */
$_GET = array( 'visitante' => $visitante_do_recorte );

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_filtro_bom = (string) ob_get_clean();

$_GET = array();

afirmar(
	$nome,
	str_contains( $tela_com_filtro_bom, 'Mostrando apenas o visitante' ) && ! str_contains( $tela_com_filtro_bom, 'IGNORADO' ),
	'piso do filtro válido: um apelido bem formado deixou de recortar a tabela, ou foi anunciado como ignorado'
);

/* PISO do período: o painel somando mais dias do que o registro guarda avisa. */
$config_do_periodo = F3Base_Options::ler( 'f3base_comportamento' );

F3Base_Options::gravar(
	'f3base_comportamento',
	array_merge(
		is_array( $config_do_periodo ) ? $config_do_periodo : array(),
		array( 'dias_no_painel' => 28, 'retencao_eventos_dias' => 7 )
	),
	F3Base_Options::ORIGEM_MANUAL
);

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_periodo_maior = (string) ob_get_clean();

afirmar(
	$nome,
	F3Base_Modulo_Comportamento::dias_no_painel() > F3Base_Modulo_Comportamento::retencao_eventos_dias()
		&& str_contains( $tela_com_periodo_maior, 'não cobrem o mesmo período' ),
	'piso do período: com o painel somando mais dias do que o registro guarda, a tela não avisou. Os quadros que vêm do registro cobrem uma janela menor e dizem o mesmo número de dias dos outros — dois períodos com um nome só'
);

F3Base_Options::gravar(
	'f3base_comportamento',
	array_merge(
		is_array( $config_do_periodo ) ? $config_do_periodo : array(),
		array( 'dias_no_painel' => 7, 'retencao_eventos_dias' => 7 )
	),
	F3Base_Options::ORIGEM_MANUAL
);

ob_start();
F3Base_Admin_Medicao::render();
$tela_com_periodo_igual = (string) ob_get_clean();

afirmar(
	$nome,
	! str_contains( $tela_com_periodo_igual, 'não cobrem o mesmo período' ),
	'teto do período: com o painel dentro do prazo do registro a tela avisou assim mesmo. Aviso que aparece sempre deixa de ser lido'
);

/* ==========================================================================
 * medicao.carimbo_do_acionamento — O DIA DAS DUAS TABELAS SAI DO MESMO CARIMBO.
 *
 * O DEFEITO. `registrar_evento()` gravava `dia` a partir do ACIONAMENTO —
 * `gmdate('Y-m-d', $criado_em)` — e `somar()` gravava `gmdate('Y-m-d')`, que é o
 * dia da CHEGADA do lote. Um lote entregue depois da virada do dia — a fila
 * pendente retomada no carregamento seguinte, que é o caminho normal desde a
 * 1.3.4 — punha o TOTAL num dia e o ACIONAMENTO no outro. Os dois quadros da
 * tela deixavam de fechar, e o docblock ao lado prometia o contrário.
 * ======================================================================= */

$nome = 'medicao.carimbo_do_acionamento';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

/* Um lote da véspera: a origem é de ontem e a chegada é de agora. */
$origem_de_ontem = ( time() - DAY_IN_SECONDS ) * 1000;
$dia_de_ontem    = gmdate( 'Y-m-d', intdiv( $origem_de_ontem, 1000 ) );
$dia_de_hoje     = gmdate( 'Y-m-d' );

postar_comportamento(
	carga_de_comportamento(
		array(
			'caminho'   => '/vespera/',
			'visitante' => str_repeat( '1', 32 ),
			'sessao'    => str_repeat( '2', 32 ),
			'origem'    => $origem_de_ontem,
			'metricas'  => array( array( 'gatilho' => 'rolagem', 'detalhe' => '25', 'contagem' => 1 ) ),
			'eventos'   => array(
				array(
					'gatilho'    => 'rolagem',
					'detalhe'    => '25',
					'ocorrencia' => 1,
					'ms'         => 500,
				),
			),
		)
	)
);

$dias_do_agregado = array();

foreach ( linhas_do_resumo() as $linha_da_vespera ) {
	$dias_do_agregado[] = (string) $linha_da_vespera['dia'];
}

afirmar(
	$nome,
	array( $dia_de_ontem ) === array_values( array_unique( $dias_do_agregado ) ),
	'teto do dia único: o lote da véspera foi somado no dia ' . implode( ', ', array_unique( $dias_do_agregado ) )
		. ' e o acionamento aconteceu em ' . $dia_de_ontem
		. '. O dia sai da MESMA âncora do lote nas duas tabelas — derivá-lo da chegada põe o total num dia e o acionamento no outro, e os dois quadros da tela deixam de fechar'
);

afirmar(
	$nome,
	$dia_de_ontem !== $dia_de_hoje,
	'piso da bancada: a véspera e hoje caíram no mesmo dia UTC, e sem dois dias distintos nada acima mede o que promete'
);

/* ==========================================================================
 * medicao.registro_por_visitante — A PORTA DA EXCLUSÃO, e o que ela não conta.
 *
 * O DEFEITO. A resposta devolvia `linhas: N`, a contagem do `DELETE`. A rota não
 * pede prova de posse de coisa nenhuma — o apelido é o único segredo —, então a
 * contagem transformava a porta da exclusão num VERIFICADOR de pseudônimos: quem
 * chuta apelidos descobre, pela diferença entre zero e não-zero, quais existem no
 * banco deste site. E `apagado` era o literal `true`, inclusive quando a tabela
 * não estava pronta e nada tinha sido tentado.
 *
 * AS DUAS GUARDAS DA PORTA CONTINUAM SENDO AS DO LEAD, e é isso que esta parte
 * fixa: o token efêmero vigente e o MESMO balde atômico por origem. Uma rota de
 * exclusão sem token é um apagador anônimo de registro alheio; um balde próprio
 * seria uma segunda regra para o mesmo risco.
 * ======================================================================= */

$nome = 'medicao.registro_por_visitante';

bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

$apelido_da_porta = str_repeat( '3', 32 );

postar_comportamento(
	carga_de_comportamento(
		array(
			'visitante' => $apelido_da_porta,
			'sessao'    => str_repeat( '4', 32 ),
			'eventos'   => array(
				array(
					'gatilho'    => 'rolagem',
					'detalhe'    => '50',
					'ocorrencia' => 1,
					'ms'         => 900,
				),
			),
		)
	)
);

/**
 * Exercita a rota de exclusão com um corpo.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar_esquecimento( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Comportamento();

	return $modulo->esquecer( new WP_REST_Request( $corpo, null ) );
}

$r = postar_esquecimento(
	array(
		'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
		'visitante' => $apelido_da_porta,
	)
);

afirmar(
	$nome,
	200 === $r->status && true === $r->data['apagado'] && ! array_key_exists( 'linhas', $r->data ),
	'teto da resposta constante: a exclusão devolveu ' . wp_json_encode( $r->data )
		. '. Contar o que foi apagado é o ORÁCULO DE EXISTÊNCIA que esta rota diz evitar: sem prova de posse, a diferença entre zero e não-zero diz a quem chuta apelidos quais existem neste banco'
);

$r = postar_esquecimento(
	array(
		'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
		'visitante' => str_repeat( '9', 32 ),
	)
);

afirmar(
	$nome,
	200 === $r->status && true === $r->data['apagado'] && ! array_key_exists( 'linhas', $r->data ),
	'piso do oráculo: um apelido que nunca existiu recebeu resposta diferente da de um que existia. Duas respostas distintas são a mesma informação que a contagem dava'
);

$r = postar_esquecimento(
	array(
		'token'     => 'invalido.invalido',
		'visitante' => $apelido_da_porta,
	)
);

afirmar(
	$nome,
	403 === $r->status && 'f3base_token_invalido' === (string) ( $r->data['codigo'] ?? '' ),
	'piso do token: a porta da exclusão aceitou um corpo sem token válido — status ' . $r->status
		. '. Sem o token vigente ela é um apagador anônimo do registro de qualquer apelido'
);

/* PISO do balde: é o MESMO da rota de entrada, por origem, e ele fecha. */
bancada_limpa();
requisicao_nova();
F3Base_Modulo_Comportamento::criar_tabela();

add_filter( 'f3base_comportamento_rate_limit_maximo', static fn(): int => 2 );

$status_do_balde = array();

for ( $i = 0; $i < 3; $i++ ) {
	$status_do_balde[] = postar_esquecimento(
		array(
			'token'     => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'visitante' => $apelido_da_porta,
		)
	)->status;
}

unset( $GLOBALS['f3b_bench']['hooks']['f3base_comportamento_rate_limit_maximo'] );

afirmar(
	$nome,
	array( 200, 200, 429 ) === $status_do_balde,
	'piso do balde: a porta da exclusão devolveu ' . implode( ', ', $status_do_balde )
		. ' com o teto declarado em 2. Ela usa o MESMO balde atômico por ORIGEM da rota de entrada — um balde próprio seria uma segunda regra para o mesmo risco, e a segunda é a que fica para trás'
);


/* ==========================================================================
 * ACRÉSCIMOS DA FRENTE B — cada bloco fecha um achado da análise 1.0.1.
 *
 * Eles vêm no fim da seção de propósito: nenhum reordena o que já estava aqui,
 * e cada um começa por `bancada_limpa()` com o cenário que ele mede.
 * ======================================================================= */

/* --------------------------------------------------------------------------
 * leads.capi_meta — o evento de SERVIDOR também passa pelo consentimento
 * ----------------------------------------------------------------------- */

$nome = 'leads.capi_meta';

/*
 * O DEFEITO MEDIDO: `agendar()` conferia token e Pixel ID e mais nada. O
 * payload leva `em`, `ph`, `client_ip_address`, `fbc` e `fbp` — e o visitante
 * que desligava a medição no controle do rodapé via o Pixel calar no navegador
 * enquanto o servidor mandava a mesma conversão, com mais dado do que o Pixel
 * levava, pelo caminho que ele não podia ver.
 */
bancada_limpa();
F3Base_Options::gravar( 'f3base_meta_capi_token', 'TOKEN-DE-BANCADA', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_IMPLANTADOR );

$_COOKIE[ F3Base_Modulo_Consentimento::COOKIE ] = 'denied';

$resposta_sem_consentimento = postar(
	carga(
		array(
			'correlation_id' => 'correlacao-capi-sem-consentimento',
			'email'          => 'jose@exemplo.test',
			'consentimento'  => false,
		)
	)
);

afirmar(
	$nome,
	array() === $GLOBALS['f3b_bench']['agendados'],
	'piso do consentimento: com a medição RECUSADA o envio de servidor foi agendado assim mesmo (' . count( $GLOBALS['f3b_bench']['agendados'] ) . ' evento(s)) — o payload da Conversions API leva e-mail, telefone, IP e os cookies da Meta, e ele saía pelo caminho que o visitante não tem como ver'
);

afirmar(
	$nome,
	201 === $resposta_sem_consentimento->status,
	'teto do consentimento: a recusa de medição mudou o status do lead (' . $resposta_sem_consentimento->status . ') — recusar medição não é recusar o contato'
);

$carimbo_sem_consentimento = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

afirmar(
	$nome,
	str_contains( (string) ( $carimbo_sem_consentimento['meta_capi'] ?? '' ), 'consentimento' ),
	'piso do consentimento: a ausência de envio não NOMEOU o consentimento como motivo — "nada aconteceu" sem nome é indistinguível de "nada foi medido": ' . (string) ( $carimbo_sem_consentimento['meta_capi'] ?? '' )
);

/* TETO: sem decisão nenhuma e sob política pré-aprovada, o envio volta a acontecer. */
unset( $_COOKIE[ F3Base_Modulo_Consentimento::COOKIE ] );
bancada_limpa();
F3Base_Options::gravar( 'f3base_meta_capi_token', 'TOKEN-DE-BANCADA', F3Base_Options::ORIGEM_MANUAL );
F3Base_Options::gravar( 'f3base_meta_pixel_id', '123456789012345', F3Base_Options::ORIGEM_IMPLANTADOR );

postar( carga( array( 'correlation_id' => 'correlacao-capi-pre-aprovada', 'email' => 'jose@exemplo.test' ) ) );

afirmar(
	$nome,
	1 === count( $GLOBALS['f3b_bench']['agendados'] ),
	'teto do consentimento: sob a política pré-aprovada e sem decisão do titular o envio deixou de ser agendado (' . count( $GLOBALS['f3b_bench']['agendados'] ) . ') — o portão do servidor precisa ser o MESMO do navegador, e lá a pré-aprovação permite'
);

/* --------------------------------------------------------------------------
 * leads.registro_fiel_ao_recebido — o que o navegador manda chega ao registro
 * ----------------------------------------------------------------------- */

$nome = 'leads.registro_fiel_ao_recebido';

/*
 * DOIS DEFEITOS COM A MESMA FORMA: um campo do schema fechado é VALIDADO e
 * depois jogado fora, e outro é gravado com um valor que não é o que foi
 * medido.
 *
 * O primeiro é o CARIMBO DO CLIQUE. `clicado_em` e `clicado_em_ms` estão no
 * schema, têm formato declarado e são recusados quando não casam — e nenhum dos
 * dois era gravado em lugar nenhum. O que ficava no registro era
 * `_f3base_registrado_em`, o relógio do SERVIDOR na hora da chegada: outro
 * fuso, outro instante, e o comentário do schema dizia que a correlação com a
 * conversa do WhatsApp é feita por data e hora — a data e hora que não estava
 * gravada.
 *
 * O segundo é o CONSENTIMENTO. `consentimento: true` virava `sim` em TODO
 * lead, e `true` é o que o cliente responde quando NINGUÉM decidiu e a política
 * é pré-aprovada: o arquivo do lead afirmava uma decisão do titular que não
 * existiu.
 */
bancada_limpa();
f3b_flamingo_na_bancada();

$carimbo_legivel = '2026-09-06T14:32:05.123Z';
$carimbo_em_ms   = '1788712325123';

postar(
	carga(
		array(
			'correlation_id' => 'correlacao-do-carimbo',
			'nome'           => 'Jose da Silva',
			'clicado_em'     => $carimbo_legivel,
			'clicado_em_ms'  => $carimbo_em_ms,
		)
	)
);

/*
 * NESTE TRECHO DO ARQUIVO A CAIXA DE LEADS EXISTE — a classe do Flamingo é
 * declarada acima —, e por isso o destino medido aqui é ela. O metadado é o
 * MESMO dos dois destinos: `meta()` é chamada pelos dois caminhos, e o CPT de
 * contingência está medido em `leads.booleano_explicito`, que roda antes da
 * declaração da classe.
 */
$gravado_no_flamingo = $GLOBALS['f3b_bench']['flamingo'][0] ?? array();
$meta_do_clique      = $gravado_no_flamingo['meta'] ?? array();

afirmar(
	$nome,
	$carimbo_legivel === (string) ( $meta_do_clique['_f3base_clicado_em'] ?? '' ),
	'piso do carimbo: `clicado_em` foi validado e NÃO chegou ao registro ("' . (string) ( $meta_do_clique['_f3base_clicado_em'] ?? '' ) . '") — é por data e hora que se casa a conversa que chegou no WhatsApp com o clique que a originou, e o que sobrava era o relógio do servidor'
);

afirmar(
	$nome,
	$carimbo_em_ms === (string) ( $meta_do_clique['_f3base_clicado_em_ms'] ?? '' ),
	'piso do carimbo: `clicado_em_ms` foi validado e NÃO chegou ao registro — é a forma que serve a quem casa as duas listas por programa'
);

$corpo_do_lead = (string) wp_json_encode( $gravado_no_flamingo['fields'] ?? array() );

afirmar(
	$nome,
	str_contains( $corpo_do_lead, $carimbo_legivel ),
	'teto do carimbo: a hora do clique não sai LEGÍVEL na caixa de leads, ao lado dos outros campos — quem faz o casamento está olhando as duas listas'
);

afirmar(
	$nome,
	'' !== (string) ( $meta_do_clique['_f3base_registrado_em'] ?? '' ),
	'piso do carimbo: a hora de CHEGADA no servidor sumiu do registro — as duas existem e respondem perguntas diferentes'
);

/* O ESTADO REAL DO CONSENTIMENTO, nos três valores do vocabulário fechado. */
$vocabulario_medido = array();

foreach (
	array(
		array( 'granted', true, F3Base_Modulo_Consentimento::ESTADO_SIM, 'decisão explícita de permitir' ),
		array( 'denied', false, F3Base_Modulo_Consentimento::ESTADO_NAO, 'decisão explícita de recusar' ),
		array( '', true, F3Base_Modulo_Consentimento::ESTADO_PADRAO, 'nenhuma decisão, sob a política pré-aprovada' ),
	) as $indice_do_caso => $caso_de_consentimento
) {
	bancada_limpa();
	f3b_flamingo_na_bancada();

	if ( '' === $caso_de_consentimento[0] ) {
		unset( $_COOKIE[ F3Base_Modulo_Consentimento::COOKIE ] );
	} else {
		$_COOKIE[ F3Base_Modulo_Consentimento::COOKIE ] = $caso_de_consentimento[0];
	}

	postar(
		carga(
			array(
				'correlation_id' => 'correlacao-consentimento-' . $indice_do_caso,
				'consentimento'  => $caso_de_consentimento[1],
			)
		)
	);

	$meta_do_consentimento = ( $GLOBALS['f3b_bench']['flamingo'][0] ?? array() )['meta'] ?? array();
	$gravado_no_registro   = (string) ( $meta_do_consentimento['_f3base_consentimento'] ?? '' );

	$vocabulario_medido[] = $gravado_no_registro;

	afirmar(
		$nome,
		$caso_de_consentimento[2] === $gravado_no_registro,
		'piso do estado real: com ' . $caso_de_consentimento[3] . ' o lead foi arquivado como "' . $gravado_no_registro . '" em vez de "' . $caso_de_consentimento[2] . '" — registro de consentimento que afirma decisão que não houve não prova nada'
	);
}

unset( $_COOKIE[ F3Base_Modulo_Consentimento::COOKIE ] );

afirmar(
	$nome,
	3 === count( array_unique( $vocabulario_medido ) ),
	'piso do vocabulário: os três casos produziram ' . count( array_unique( $vocabulario_medido ) ) . ' valor(es) distinto(s) — se dois deles são o mesmo, o registro deixou de distinguir a decisão da ausência dela'
);

foreach ( $vocabulario_medido as $valor_medido ) {
	afirmar(
		$nome,
		in_array( $valor_medido, F3Base_Modulo_Consentimento::vocabulario_do_estado(), true ),
		'teto do vocabulário: o valor "' . $valor_medido . '" está fora da lista fechada de três valores'
	);
}

/* --------------------------------------------------------------------------
 * leads.token_com_escopo — o token efêmero deixou de ser bearer universal
 * ----------------------------------------------------------------------- */

$nome = 'leads.token_com_escopo';

/*
 * O DEFEITO MEDIDO: a assinatura cobria SÓ a expiração. Um token colhido em
 * qualquer página — ele é impresso no HTML de todas — valia para qualquer POST
 * de registro, e valia por doze horas. Assinatura que só cobre o prazo autoriza
 * tudo o que couber dentro do prazo.
 *
 * O outro lado da decisão é a PÁGINA EM CACHE, e ele é tratado, não torcido:
 * com prazo curto, o HTML servido de um cache mais velho que o token faria todo
 * beacon voltar 403. A rota de emissão existe para isso, e a recusa por token
 * passou a CARIMBAR — antes ela era muda, e um site inteiro podia estar
 * perdendo lead há semanas com o módulo verde na tela.
 */
bancada_limpa();

$token_da_home = F3Base_Modulo_Endpoint_Leads::emitir_token( '/' );

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::validar_token( $token_da_home, '/' ),
	'teto do escopo: o token emitido para a home não valeu na própria home'
);

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::validar_token( $token_da_home, '/servicos/' ),
	'piso do escopo: o token emitido para a home valeu num POST que diz vir de OUTRA página — assinatura que cobre só o prazo é bearer universal enquanto o prazo durar'
);

/* A barra final e a query não distinguem página: elas fariam o escopo errar. */
afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::validar_token( F3Base_Modulo_Endpoint_Leads::emitir_token( '/contato/' ), '/contato' ),
	'teto do escopo: a barra final da página passou a distinguir escopo, e o servidor imprime uma forma enquanto o navegador manda a outra'
);

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::validar_token( F3Base_Modulo_Endpoint_Leads::emitir_token( '/lp/' ), '/lp/?utm_source=google&gclid=X' ),
	'piso da campanha: a query da URL entrou no escopo — TODO lead de tráfego pago voltaria recusado, que é o pior modo de falhar que este endpoint tem'
);

/* A VIDA DECLARADA É CURTA, e o filtro não pode desfazer a decisão inteira. */
afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::ttl_token() <= HOUR_IN_SECONDS,
	'piso do prazo: o token vive ' . F3Base_Modulo_Endpoint_Leads::ttl_token() . ' segundos — um bearer público impresso em toda página não pode durar meio dia'
);

add_filter(
	'f3base_token_lead_ttl',
	static function (): int {
		return 30 * DAY_IN_SECONDS;
	}
);

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::ttl_token() <= DAY_IN_SECONDS,
	'piso do teto do filtro: o filtro devolveu trinta dias e o módulo aceitou ' . F3Base_Modulo_Endpoint_Leads::ttl_token() . ' — um filtro sem teto é uma porta para desfazer a decisão inteira sem que nada acuse'
);

unset( $GLOBALS['f3b_bench']['hooks']['f3base_token_lead_ttl'] );

/* A ROTA DE EMISSÃO existe, é pública e devolve token do escopo pedido. */
bancada_limpa();

$modulo_do_token = new F3Base_Modulo_Endpoint_Leads();
$modulo_do_token->registrar_rota();

afirmar(
	$nome,
	in_array( F3Base_Modulo_Endpoint_Leads::ROTA_TOKEN, $GLOBALS['f3b_bench']['rotas'], true ),
	'piso da página em cache: a rota de emissão de token não foi registrada — sem ela, a página servida de um cache mais velho que o prazo perde TODO lead, em silêncio'
);

$emitido = $modulo_do_token->emitir( new WP_REST_Request( null, array( 'pagina' => '/servicos/' ) ) );

afirmar(
	$nome,
	200 === $emitido->status && F3Base_Modulo_Endpoint_Leads::validar_token( (string) ( $emitido->data['token'] ?? '' ), '/servicos/' ),
	'teto da rota de emissão: o token devolvido não vale para a página pedida (status ' . $emitido->status . ')'
);

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::validar_token( (string) ( $emitido->data['token'] ?? '' ), '/outra/' ),
	'piso da rota de emissão: o token da rota nasceu sem escopo — a rota pública passaria a emitir o bearer universal que a assinatura acabou de fechar'
);

/* O MESMO BALDE do registro protege a rota: ela não é uma porta sem limite. */
$estourou_o_balde = false;

for ( $tentativa = 0; $tentativa < 40; $tentativa++ ) {
	if ( 429 === $modulo_do_token->emitir( new WP_REST_Request( null, array( 'pagina' => '/' ) ) )->status ) {
		$estourou_o_balde = true;
		break;
	}
}

afirmar(
	$nome,
	$estourou_o_balde,
	'piso do balde: a rota de emissão respondeu quarenta pedidos seguidos da mesma origem sem recusar — rota pública sem limite é rota que se usa para outra coisa'
);

/* A RECUSA POR TOKEN CARIMBA, e o módulo deixa de ficar verde sobre ela. */
bancada_limpa();

$recusado_por_token = postar(
	array(
		'token'          => '1.assinatura-que-nao-e-nossa',
		'correlation_id' => 'correlacao-com-token-alheio',
		'pagina'         => '/contato/',
	)
);

afirmar(
	$nome,
	403 === $recusado_por_token->status && 'f3base_token_invalido' === (string) ( $recusado_por_token->data['codigo'] ?? '' ),
	'teto da recusa: um token que não é deste site passou (status ' . $recusado_por_token->status . ')'
);

$falha_de_token = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );

afirmar(
	$nome,
	array() !== $falha_de_token && str_contains( (string) ( $falha_de_token['destino'] ?? '' ), 'token' ),
	'piso do silêncio: a recusa por token NÃO deixou carimbo. Uma página em cache mais velha que o token faz todo beacon voltar 403, e sem carimbo o módulo continua verde enquanto o site perde lead há semanas'
);

afirmar(
	$nome,
	'/contato/' === (string) ( $falha_de_token['pagina'] ?? '' ),
	'piso do diagnóstico: o carimbo da recusa não NOMEIA a página — é ela que diz de qual cache o problema veio'
);

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === ( new F3Base_Modulo_Endpoint_Leads() )->estado()['estado'],
	'piso do estado: com a recusa por token mais recente que qualquer aceite o módulo continuou fora de DEGRADADO'
);

afirmar(
	$nome,
	str_contains( (string) ( $recusado_por_token->data['rota'] ?? '' ), F3Base_Modulo_Endpoint_Leads::ROTA_TOKEN ),
	'teto da recusa: a resposta 403 não diz ao cliente ONDE pedir um token novo, e sem isso o reenvio não tem como acontecer'
);

/* --------------------------------------------------------------------------
 * leads.reserva_compensada — falha de banco não é duplicata
 * ----------------------------------------------------------------------- */

$nome = 'leads.reserva_compensada';

/*
 * O DEFEITO MEDIDO: o `INSERT` da reserva roda com os erros silenciados porque
 * a colisão de chave única é o caminho ESPERADO. Quando ele falhava por OUTRO
 * motivo — tabela ausente, disco cheio, coluna divergente depois de uma
 * migração pela metade —, não havia linha nenhuma para ler, e a rota respondia
 * `200 duplicado:true` com `record_id` VAZIO. O cliente apaga o lead da fila ao
 * receber 2xx: o registro sumia, e a tela do operador continuava verde.
 */
bancada_limpa();

/*
 * A TABELA SOME DEPOIS de o memo de prontidão já ter dito que ela está lá — é
 * assim que se reproduz o `INSERT` que falha por motivo de BANCO e não por
 * chave repetida, sem o módulo cair para o caminho de contingência.
 */
afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::tabela_pronta(),
	'piso da falha de banco: a bancada não conseguiu memoizar a tabela como pronta, e sem isso o cenário medido é o da contingência, que é outro'
);

$wpdb->tabelas = array();

$falha_de_banco = postar( carga( array( 'correlation_id' => 'correlacao-com-banco-quebrado' ) ) );

afirmar(
	$nome,
	200 !== $falha_de_banco->status,
	'piso da falha de banco: a reserva falhou por motivo de BANCO e a rota respondeu 200 — e o cliente apaga o lead da fila ao receber 2xx'
);

afirmar(
	$nome,
	true !== ( $falha_de_banco->data['duplicado'] ?? false ),
	'piso da falha de banco: a rota chamou de DUPLICATA uma correlação que nunca foi gravada — não havia reserva anterior nenhuma para ela colidir'
);

afirmar(
	$nome,
	503 === $falha_de_banco->status && 'f3base_reserva_indisponivel' === (string) ( $falha_de_banco->data['codigo'] ?? '' ),
	'teto da falha de banco: a recusa do armazenamento saiu com status ' . $falha_de_banco->status . ' e código ' . (string) ( $falha_de_banco->data['codigo'] ?? '' ) . ' — falha de armazenamento do servidor é 5xx com código próprio'
);

$carimbo_da_reserva = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );

afirmar(
	$nome,
	array() !== $carimbo_da_reserva && str_contains( (string) ( $carimbo_da_reserva['motivo'] ?? '' ), 'armazenamento' ),
	'piso da falha de banco: a recusa do armazenamento não deixou carimbo NOMEADO — recusa que some da tela é indistinguível de recusa que nunca aconteceu'
);

/* PISO DO PISO: a duplicata de verdade continua sendo duplicata. */
bancada_limpa();

postar( carga( array( 'correlation_id' => 'correlacao-duplicada-de-verdade' ) ) );
$replay_verdadeiro = postar( carga( array( 'correlation_id' => 'correlacao-duplicada-de-verdade' ) ) );

afirmar(
	$nome,
	200 === $replay_verdadeiro->status && true === ( $replay_verdadeiro->data['duplicado'] ?? false )
		&& '' !== (string) ( $replay_verdadeiro->data['record_id'] ?? '' ),
	'piso da duplicata: o replay de uma correlação JÁ GRAVADA deixou de ser reconhecido como duplicata (status ' . $replay_verdadeiro->status . ') — o que distingue os dois casos é a EXISTÊNCIA da reserva anterior, e ela existe aqui'
);

/* --------------------------------------------------------------------------
 * leads.origem_declarada — a faixa do proxy LIGA a proteção, e vazia avisa
 * ----------------------------------------------------------------------- */

$nome = 'leads.origem_declarada';

/*
 * TRÊS RAMOS, e cada um é uma decisão diferente sobre o mesmo cabeçalho:
 *
 * 1. FAIXA PREENCHIDA e a conexão vem DE DENTRO dela: o cabeçalho é lido. É o
 *    caso da CDN configurada, e é para ele que o campo existe.
 * 2. FAIXA PREENCHIDA e a conexão vem DE FORA: o cabeçalho é IGNORADO. Cabeçalho
 *    é texto que qualquer cliente manda, e alcançar a origem por fora da CDN —
 *    pelo IP, o que costuma responder — é trivial: sem esta recusa, quem faz
 *    isso escolhe o balde do rate limit e o `client_ip_address` que o servidor
 *    manda à Meta.
 * 3. FAIXA VAZIA: o cabeçalho é lido de qualquer conexão, como sempre foi, e o
 *    módulo AVISA nomeando o risco e o campo que o fecha.
 *
 * POR QUE O RAMO 3 NÃO É "NUNCA CONFIAR". Houve uma versão em que era, e ela
 * quebrava em silêncio toda instalação já entregue: quem tinha `cabecalho`
 * declarado e nunca ouviu falar de faixa passava, na atualização, a contar todos
 * os visitantes no mesmo balde e a mandar o endereço da CDN ao fornecedor de
 * anúncio — sem erro, sem aviso e sem ninguém ter mexido em nada. A proteção
 * existe e é ligada por quem declara a faixa; o preço de não declarar é o aviso.
 */
bancada_limpa();

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho'        => 'X-Forwarded-For',
		'saltos'           => 1,
		'redes_confiaveis' => array( '198.51.100.0/24' ),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

/* RAMO 1: preenchida e a conexão vem de dentro — lê. */
$por_dentro_da_cdn = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $por_dentro_da_cdn['valor'] && 'cabecalho-declarado' === $por_dentro_da_cdn['fonte'],
	'teto da faixa: a conexão veio de dentro da faixa declarada e o cabeçalho NÃO foi lido (' . $por_dentro_da_cdn['valor'] . ' por ' . $por_dentro_da_cdn['fonte'] . ')'
);

/* RAMO 2: preenchida e a conexão vem de fora — ignora. */
$por_fora_da_cdn = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '203.0.113.200',
		'HTTP_X_FORWARDED_FOR' => '10.0.0.1',
	)
);

afirmar(
	$nome,
	'203.0.113.200' === $por_fora_da_cdn['valor'] && 'remote_addr' === $por_fora_da_cdn['fonte'],
	'piso do contorno da CDN: com a faixa DECLARADA, um pedido que chegou DIRETO ao servidor teve o cabeçalho lido (' . $por_fora_da_cdn['valor'] . ' por ' . $por_fora_da_cdn['fonte'] . ') — quem alcança a origem por fora escolhe o balde do rate limit e o endereço que o servidor manda à Meta'
);

/* E COM A FAIXA DECLARADA NÃO HÁ AVISO: o ramo adverso do aviso é o caso normal. */
afirmar(
	$nome,
	array() === ( new F3Base_Modulo_Endpoint_Leads() )->avisos(),
	'piso do aviso: com a faixa de proxy declarada o módulo avisou assim mesmo. Aviso que sai sempre treina quem opera o site a ignorar aviso, e o que ele nomeia aqui é uma porta que já está fechada'
);

/* RAMO 3: faixa VAZIA — lê como antes, e avisa. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$sem_faixa_declarada = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '203.0.113.200',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $sem_faixa_declarada['valor'] && 'cabecalho-declarado' === $sem_faixa_declarada['fonte'],
	'teto da faixa vazia: sem faixa de proxy declarada o cabeçalho DEIXOU de ser lido (' . $sem_faixa_declarada['valor'] . ' por ' . $sem_faixa_declarada['fonte'] . ') — é o comportamento que toda instalação já entregue tem, e trocá-lo numa atualização faz cada uma delas passar a contar todos os visitantes no mesmo balde sem ninguém ter mexido em nada'
);

$modulo_sem_faixa = new F3Base_Modulo_Endpoint_Leads();
$avisos_sem_faixa = $modulo_sem_faixa->avisos();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO !== $modulo_sem_faixa->estado()['estado'],
	'piso do estado: sem faixa declarada o módulo fechou DEGRADADO. Ele faz exatamente o que a configuração pede; o que existe ali é risco de configuração, e risco com o principal funcionando é aviso'
);

afirmar(
	$nome,
	1 === count( $avisos_sem_faixa )
		&& 'WARN' === (string) ( $avisos_sem_faixa[0]['estado'] ?? '' )
		&& str_contains( (string) ( $avisos_sem_faixa[0]['motivo'] ?? '' ), 'redes_confiaveis' )
		&& str_contains( (string) ( $avisos_sem_faixa[0]['motivo'] ?? '' ), 'X-Forwarded-For' ),
	'teto do aviso: com o cabeçalho declarado e nenhuma faixa, o módulo não avisou nomeando o risco E o campo que o fecha. Ler o cabeçalho de qualquer conexão é uma escolha declarada, e escolha declarada sem o preço dito na tela é a mesma coisa que escolha escondida'
);

/* A comparação é BINÁRIA: prefixo casado por texto aceitaria o vizinho. */
afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::em_rede_confiavel( '10.0.0.1', array( '10.0.0.1/32' ) ),
	'teto da faixa: o endereço exato não casou com a própria faixa de 32 bits'
);

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::em_rede_confiavel( '10.0.0.10', array( '10.0.0.1/32' ) ),
	'piso do prefixo de texto: 10.0.0.10 casou com 10.0.0.1/32 — é o que um str_starts_with faria, e ele deixa o vizinho entrar'
);

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::em_rede_confiavel( '198.51.100.10', array() ),
	'piso da lista vazia: sem faixa nenhuma declarada a comparação disse SIM'
);

afirmar(
	$nome,
	array( '198.51.100.0/24' ) === F3Base_Modulo_Endpoint_Leads::redes_declaradas( '198.51.100.0/24, nao-e-um-ip, 300.1.2.3' ),
	'piso da faixa ilegível: um valor que não é IP nem CIDR sobreviveu à limpeza — faixa ilegível não pode virar faixa que aceita tudo'
);

/*
 * `saltos` É POSIÇÃO CONTADA DO FIM, e a frase que descrevia outra conta saiu
 * junto: quem tem uma CDN e lê "descontando um salto" escreve 2, e o site passa
 * a ler a ponta que o próprio visitante escreveu.
 */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho'        => 'X-Forwarded-For',
		'saltos'           => 1,
		'redes_confiaveis' => array( '198.51.100.0/24' ),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$ultimo_da_cadeia = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'inventado, 203.0.113.99',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $ultimo_da_cadeia['valor'],
	'teto da posição: com saltos=1 a origem não é o ÚLTIMO elemento da cadeia (' . $ultimo_da_cadeia['valor'] . '), que é o que o proxy da frente escreveu'
);

$estado_com_faixa = ( new F3Base_Modulo_Endpoint_Leads() )->estado();

afirmar(
	$nome,
	! str_contains( $estado_com_faixa['motivo'], 'descontando' ),
	'piso da frase: o estado ainda descreve a leitura como "descontando N saltos da direita", que é a conta com um elemento a menos do que a que o código faz'
);

afirmar(
	$nome,
	str_contains( $estado_com_faixa['motivo'], 'posição' ) && str_contains( $estado_com_faixa['motivo'], 'fim' ),
	'teto da frase: o estado não diz que `saltos` é POSIÇÃO contada do fim, e é isso que o operador precisa para escolher o número'
);

/* --------------------------------------------------------------------------
 * leads.limite_por_caractere — limite publicado é limite aplicado
 * ----------------------------------------------------------------------- */

$nome = 'leads.limite_por_caractere';

/*
 * O DEFEITO MEDIDO: a lista publicada ao navegador trazia `atribuicao => 8`, e
 * o servidor não conferia nada com aquele número — o ramo do sub-objeto sai do
 * laço antes da guarda de comprimento. Limite publicado que ninguém aplica é
 * pior que limite nenhum: o cliente corta por ele achando que evita a recusa, e
 * a recusa que ele evitaria não existia.
 */
foreach ( F3Base_Modulo_Endpoint_Leads::limites_publicos() as $campo_publicado => $limite_publicado ) {
	bancada_limpa();

	$acima_do_limite = str_repeat( 'a', $limite_publicado + 1 );
	$recusa_esperada = postar_form( carga( array( $campo_publicado => $acima_do_limite ) ) );

	afirmar(
		$nome,
		400 === $recusa_esperada->status && 'f3base_limite_excedido' === (string) ( $recusa_esperada->data['codigo'] ?? '' ),
		'piso do limite publicado: o campo `' . $campo_publicado . '` publica limite de ' . $limite_publicado .
			' e um valor com um caractere a mais devolveu status ' . $recusa_esperada->status . ' com código "' .
			(string) ( $recusa_esperada->data['codigo'] ?? '' ) . '" — a lista publicada só pode trazer o que o servidor APLICA'
	);
}

/* O limite da atribuição existe e é aplicado — só não é um número de caracteres. */
bancada_limpa();

afirmar(
	$nome,
	! array_key_exists( 'atribuicao', F3Base_Modulo_Endpoint_Leads::limites_publicos() ),
	'piso da lista publicada: `atribuicao` continua na lista de limites em CARACTERES, e o valor dela nunca foi medido em caracteres'
);

afirmar(
	$nome,
	count( F3Base_Modulo_Endpoint_Leads::campos_atribuicao() ) === (int) F3Base_Modulo_Endpoint_Leads::campos()['atribuicao']['max'],
	'piso do limite aplicado: o `max` de `atribuicao` não é a quantidade de chaves que o schema fechado aceita — número que não descreve nada é número que ninguém confere'
);

/* --------------------------------------------------------------------------
 * leads.atividade_so_com_persistencia — o carimbo é SUBSTITUÍDO, não mesclado
 * ----------------------------------------------------------------------- */

$nome = 'leads.atividade_so_com_persistencia';

/*
 * O DEFEITO MEDIDO: `F3Base_Atividade::registrar()` mesclava com o carimbo
 * anterior. Um carimbo descreve UMA execução: a que falhou gravava `erro`, e a
 * seguinte, bem-sucedida, gravava `status: 200` sem `erro` — e a mescla mantinha
 * o `erro` da anterior ao lado do sucesso da atual. A tela dizia "status 200,
 * erro: http_request_failed" e ninguém tinha como saber qual metade era desta
 * vez.
 */
bancada_limpa();

F3Base_Atividade::registrar( F3Base_Atividade::ULTIMA_ORIGEM, array( 'caminho' => '/', 'status' => 0, 'erro' => 'http_request_failed' ) );
F3Base_Atividade::registrar( F3Base_Atividade::ULTIMA_ORIGEM, array( 'caminho' => '/', 'status' => 200, 'bytes' => 1024 ) );

$carimbo_substituido = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_ORIGEM );

afirmar(
	$nome,
	! array_key_exists( 'erro', $carimbo_substituido ),
	'piso da mescla: o `erro` da execução ANTERIOR sobreviveu ao carimbo da execução bem-sucedida — a tela passa a mostrar status 200 e um erro ao lado, e nada diz qual das duas metades é desta vez'
);

afirmar(
	$nome,
	200 === ( $carimbo_substituido['status'] ?? null ) && 1024 === ( $carimbo_substituido['bytes'] ?? null ),
	'teto da substituição: o carimbo da execução atual perdeu campo próprio ao substituir o anterior'
);

/* A ACUMULAÇÃO CONTINUA POSSÍVEL, e agora ela é decisão de quem chama. */
F3Base_Atividade::registrar( F3Base_Atividade::REDIRECTS_SERVIDOS, array( 'de' => '/velho', 'para' => '/novo' ) );
F3Base_Atividade::incrementar( F3Base_Atividade::REDIRECTS_SERVIDOS, 'total' );
F3Base_Atividade::incrementar( F3Base_Atividade::REDIRECTS_SERVIDOS, 'total' );

$contador = F3Base_Atividade::ler( F3Base_Atividade::REDIRECTS_SERVIDOS );

afirmar(
	$nome,
	2 === ( $contador['total'] ?? null ) && '/novo' === (string) ( $contador['para'] ?? '' ),
	'teto do contador: substituir o carimbo apagou o que `incrementar()` precisa acumular — a acumulação mudou de lugar, não pode ter sumido'
);

/* --------------------------------------------------------------------------
 * origem.cabecalho_como_veio — cabeçalho repetido não vira a palavra "Array"
 * ----------------------------------------------------------------------- */

$nome = 'origem.cabecalho_como_veio';

/*
 * O DEFEITO MEDIDO: a rota de leitura pela origem devolvia os cabeçalhos por
 * `array_map( 'strval', … )`. Cabeçalho REPETIDO — `Link`, `Set-Cookie`,
 * `Vary` de emissores diferentes, `Cache-Control` de CDN — chega da camada HTTP
 * como LISTA, e `strval()` de um array devolve a string `"Array"` e emite um
 * aviso do PHP. O instrumento cujo papel inteiro é dizer o que o servidor
 * emitiu apagava justamente o cabeçalho emitido duas vezes, que é o caso que se
 * vai ler quando se desconfia de emissor concorrente.
 */
$cabecalhos_da_origem = F3Base_Modulo_Rota_Origem::cabecalhos_legiveis(
	array(
		'content-type' => 'text/html; charset=UTF-8',
		'link'         => array( '<https://exemplo.test/a>; rel="preload"', '<https://exemplo.test/b>; rel="preconnect"' ),
		'location'     => array( '/primeiro', '/segundo' ),
	)
);

afirmar(
	$nome,
	'text/html; charset=UTF-8' === ( $cabecalhos_da_origem['content-type'] ?? null ),
	'teto do escalar: o cabeçalho de valor único deixou de sair como texto'
);

afirmar(
	$nome,
	'Array' !== ( $cabecalhos_da_origem['link'] ?? null ),
	'piso do cabeçalho repetido: o cabeçalho emitido DUAS VEZES virou a palavra "Array" — o instrumento de leitura pela origem apagou exatamente o caso que se vai ler quando se desconfia de emissor concorrente'
);

afirmar(
	$nome,
	is_array( $cabecalhos_da_origem['link'] ?? null ) && 2 === count( $cabecalhos_da_origem['link'] ),
	'teto do cabeçalho repetido: os dois valores emitidos não chegaram inteiros ao resultado'
);

afirmar(
	$nome,
	'/primeiro' === F3Base_Modulo_Rota_Origem::primeiro_valor( $cabecalhos_da_origem['location'] ?? '' ),
	'piso do redirecionamento: o destino de conveniência não aponta para o primeiro Location emitido — `(string)` de uma lista devolveria "Array" também aqui'
);

afirmar(
	$nome,
	'/unico' === F3Base_Modulo_Rota_Origem::primeiro_valor( '/unico' ),
	'teto do redirecionamento: o Location de valor único deixou de sair como texto'
);


/* --------------------------------------------------------------------------
 * leads.contingencia_visivel — o lead de contingência não some do menu
 * ----------------------------------------------------------------------- */

$nome = 'leads.contingencia_visivel';

/*
 * O DEFEITO MEDIDO: a listagem do CPT de contingência só aparecia quando o
 * Flamingo NÃO estava presente. O percurso normal de um site é o contrário — a
 * caixa única entra depois, na etapa de plugins ou no dia em que o operador
 * decide organizar os leads. No instante em que ela é ativada, os leads que a
 * contingência gravou continuam no banco, com dado pessoal dentro, e a única
 * listagem que os mostrava desaparece do menu. Eles não migram, ninguém é
 * avisado, e não há por onde lê-los nem por onde apagá-los.
 *
 * Este trecho roda com a caixa de leads PRESENTE — a classe é declarada acima
 * neste mesmo arquivo —, que é exatamente o cenário do defeito.
 */
bancada_limpa();

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::flamingo_presente(),
	'piso do cenário: a caixa de leads não está presente nesta parte da bancada, e sem ela o defeito — "ativar o Flamingo esconde os leads já gravados" — não é reproduzível'
);

( new F3Base_Modulo_Endpoint_Leads() )->registrar_cpt();

$registro_sem_lead = $GLOBALS['f3b_bench']['post_types'][ F3Base_Modulo_Endpoint_Leads::CPT ] ?? array();

afirmar(
	$nome,
	array() !== $registro_sem_lead,
	'piso do registro: o tipo de conteúdo de contingência não foi registrado — sem ele não há nem listagem nem lugar onde gravar'
);

afirmar(
	$nome,
	false === ( $registro_sem_lead['show_ui'] ?? null ),
	'teto do silêncio: com a caixa única presente e NENHUM lead de contingência gravado, a listagem apareceu no menu — listagem sem nada para mostrar é ruído ao lado da caixa que tem tudo'
);

/*
 * Agora o site que já tinha leads de contingência quando a caixa única entrou.
 * O post é inserido direto: é o estado em que a instalação ficou, e não uma
 * gravação que este cenário provoca.
 */
wp_insert_post(
	array(
		'post_type'   => F3Base_Modulo_Endpoint_Leads::CPT,
		'post_status' => 'private',
		'post_title'  => 'WhatsApp — lead gravado antes de a caixa entrar',
	),
	true
);

delete_transient( 'f3base_leads_no_cpt' );

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::ha_lead_no_cpt(),
	'piso da leitura: com um lead de contingência no banco a pergunta "há lead gravado?" respondeu não'
);

$GLOBALS['f3b_bench']['post_types'] = array();

( new F3Base_Modulo_Endpoint_Leads() )->registrar_cpt();

$registro_com_lead = $GLOBALS['f3b_bench']['post_types'][ F3Base_Modulo_Endpoint_Leads::CPT ] ?? array();

afirmar(
	$nome,
	true === ( $registro_com_lead['show_ui'] ?? null ),
	'piso do dado escondido: existe lead de contingência gravado e a listagem NÃO aparece no menu — ativar a caixa única fez sumir da vista o dado pessoal que continua no banco, sem migrar nada e sem avisar ninguém'
);

afirmar(
	$nome,
	'base-site-core-fator3' === ( $registro_com_lead['show_in_menu'] ?? null ),
	'teto do lugar: a listagem visível não foi para o menu do plugin, que é onde o operador vai procurar'
);

afirmar(
	$nome,
	false === ( $registro_com_lead['public'] ?? null ) && false === ( $registro_com_lead['show_in_rest'] ?? null ),
	'piso da exposição: tornar a listagem visível no wp-admin abriu o tipo ao público ou ao REST — o conteúdo dele é dado pessoal, e a visibilidade que se pediu é a do operador'
);




/* ==========================================================================
 * FRENTE D — os módulos restantes e o contrato partilhado.
 *
 * Cada bloco abaixo tem TETO e PISO, e o piso é o DEFEITO MEDIDO na 1.0.1
 * reproduzido aqui. Onde o defeito é de TEXTO — um docblock que afirma o que o
 * código não faz, um comentário de tradução que descreve o argumento errado —,
 * o piso roda a MESMA função de leitura contra a frase antiga: é assim que se
 * prova que o leitor sabe acusar, sem precisar sujar a fonte.
 * ======================================================================= */

/* ---------- seo.llms_emissor_cruza_plugin ---------- */

/*
 * OPTION SOBREVIVE À DESATIVAÇÃO, E É POR ISSO QUE ELA NÃO DECIDE SOZINHA.
 *
 * `enable_llms_txt` e `enable_xml_sitemap` moram na option `wpseo`, e a option
 * fica no banco depois de o plugin ser desativado. Lendo só a chave, este
 * pacote cedia o endereço público a um emissor que já não emite: `/llms.txt`
 * virava 404 permanente com o módulo dizendo ATIVO, e o rodapé do arquivo
 * apontava um sitemap que ninguém serve.
 *
 * TETO: chave ligada E plugin ativo => há concorrente, e a rota sai de cena.
 * PISO: chave ligada e plugin DESATIVADO => não há concorrente nenhum.
 */
$nome = 'seo.llms_emissor_cruza_plugin';

bancada_limpa();
$GLOBALS['f3b_bench']['conteudo'] = array();
$GLOBALS['f3b_bench']['metas']    = array();

$arquivo_do_seo = F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO ) . '/wp-seo.php';

$GLOBALS['f3b_bench']['options']['wpseo'] = array(
	'enable_llms_txt'    => true,
	'enable_xml_sitemap' => true,
);
$GLOBALS['f3b_bench']['options']['active_plugins'] = array();
$GLOBALS['f3b_bench']['sitemap_do_nucleo']         = false;
requisicao_nova();

afirmar( $nome, false === F3Base_Llms::plugin_de_seo_ativo(), 'piso: com o plugin de SEO fora da lista de ativos a medição disse que ele está rodando' );
afirmar( $nome, false === F3Base_Llms::concorrente_de_llms()['ligado'], 'piso: a option órfã — chave ligada, plugin DESATIVADO — foi contada como emissor concorrente, e o endereço público ficaria sem dono nenhum' );
afirmar( $nome, true === F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'], 'piso: a rota saiu de cena por causa de uma option que sobreviveu à desativação do plugin' );
afirmar( $nome, '' === F3Base_Llms::sitemap_medido()['url'], 'piso: o rodapé do arquivo apontaria sitemap_index.xml sobre uma chave órfã — endereço que ninguém serve, impresso como se fosse medido' );

$GLOBALS['f3b_bench']['options']['active_plugins'] = array( $arquivo_do_seo );
requisicao_nova();

afirmar( $nome, true === F3Base_Llms::plugin_de_seo_ativo(), 'teto: com o plugin de SEO na lista de ativos a medição não o reconheceu — o slug sai do vocabulário compartilhado' );
afirmar( $nome, true === F3Base_Llms::concorrente_de_llms()['ligado'], 'teto: com a chave ligada E o plugin ativo o emissor concorrente deixou de ser medido' );
afirmar( $nome, false === F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve'], 'teto: com emissor concorrente de verdade a rota continuou servindo — duas respostas para o mesmo endereço' );
afirmar( $nome, str_contains( F3Base_Llms::sitemap_medido()['url'], 'sitemap_index.xml' ), 'teto: com o plugin ativo e o sitemap dele ligado o endereço medido não foi o do plugin' );

$GLOBALS['f3b_bench']['options']['wpseo']          = array();
$GLOBALS['f3b_bench']['options']['active_plugins'] = array();
requisicao_nova();

/* ---------- seo.llms_primeira_frase_declarada ---------- */

/*
 * A ORDEM DAS TRÊS FRASES É A DA TELA, e ela estava invertida no código.
 *
 * O campo `introducao` se chama "Primeira frase do arquivo" e diz, no texto que
 * o operador lê, que ela é a primeira frase que um leitor automático encontra e
 * que, vazia, o site usa a apresentação abaixo. O código lia `apresentacao`
 * primeiro: quem preenchesse os dois campos publicava o que a tela chamava de
 * reserva, e nada acusava.
 *
 * TETO: com os dois preenchidos, sai a introdução — nos DOIS arquivos.
 * PISO: a apresentação só aparece quando a introdução está vazia, e a descrição
 * do WordPress só quando as duas estão.
 */
$nome = 'seo.llms_primeira_frase_declarada';

afirmar( $nome, 'A introducao' === F3Base_Modulo_Llms_Txt_Reserva::primeira_frase( array( 'introducao' => 'A introducao', 'apresentacao' => 'A apresentacao' ), 'A tagline' ), 'piso: com os dois campos preenchidos saiu a apresentação, e a tela promete a primeira frase' );
afirmar( $nome, 'A apresentacao' === F3Base_Modulo_Llms_Txt_Reserva::primeira_frase( array( 'introducao' => '   ', 'apresentacao' => 'A apresentacao' ), 'A tagline' ), 'teto: introdução vazia não caiu para a apresentação' );
afirmar( $nome, 'A tagline' === F3Base_Modulo_Llms_Txt_Reserva::primeira_frase( array(), 'A tagline' ), 'teto: sem os dois campos o arquivo deixou de usar a descrição cadastrada no WordPress' );
afirmar( $nome, '' === F3Base_Modulo_Llms_Txt_Reserva::primeira_frase( array(), '' ), 'piso: sem nada a dizer o arquivo inventou uma frase' );

/* E O TEXTO INTEGRAL SEGUE A MESMA REGRA: dois arquivos com duas ordens seriam dois vereditos. */
$corpo_com_as_duas = F3Base_Modulo_Llms_Full_Txt::montar(
	array( array( 'url' => 'https://exemplo.test/', 'titulo' => 'Home', 'conteudo' => '<p>corpo</p>' ) ),
	array( 'introducao' => 'A introducao', 'apresentacao' => 'A apresentacao' )
);

afirmar( $nome, str_contains( $corpo_com_as_duas, '> A introducao' ), 'piso: o texto integral abriu com a apresentação enquanto o índice curto abre com a introdução — dois arquivos, duas ordens' );
afirmar( $nome, ! str_contains( $corpo_com_as_duas, '> A apresentacao' ), 'piso: o texto integral imprimiu as duas frases' );

/* E A TELA DIZ ISSO: a precedência do código é a que o campo promete ao operador. */
$declaracao_do_llms = F3Base_Options::declaracao( 'f3base_llms' );
$impacto_introducao = (string) ( $declaracao_do_llms['subcampos']['introducao']['impacto'] ?? '' );

afirmar( $nome, str_contains( $impacto_introducao, 'primeira frase' ), 'teto: o campo introducao deixou de prometer ser a primeira frase, e a precedência do código passou a não ter texto que a sustente — ' . $impacto_introducao );
afirmar( $nome, str_contains( $impacto_introducao, 'apresenta' ), 'teto: o campo introducao não diz mais que, vazia, o site usa a apresentação' );

/* ---------- seo.llms_carimbo_por_rota ---------- */

/*
 * DOIS ENDEREÇOS PÚBLICOS SÃO DUAS ATIVIDADES.
 *
 * Até a 1.0.1 `/llms.txt` e `/llms-full.txt` gravavam o MESMO carimbo: a
 * resposta de um apagava a do outro, e a tela mostrava uma linha de "última
 * resposta" que ora falava do índice, ora do texto integral, sem dizer qual. E
 * o cabeçalho `X-F3Base-Mecanismo` saía com o literal `rota-reserva` nos dois —
 * um cabeçalho de diagnóstico que não distingue nada.
 *
 * TETO: carimbos e mecanismos distintos, e cada módulo descreve o seu.
 * PISO: o carimbo do índice curto não pode responder pelo texto integral.
 */
$nome = 'seo.llms_carimbo_por_rota';

bancada_limpa();
requisicao_nova();

afirmar( $nome, F3Base_Atividade::ULTIMO_LLMS !== F3Base_Modulo_Llms_Full_Txt::ATIVIDADE, 'piso: os dois módulos gravam no MESMO carimbo — a resposta de um endereço apaga a do outro' );
afirmar( $nome, F3Base_Llms::QUEM_NOSSA_ROTA !== F3Base_Modulo_Llms_Full_Txt::MECANISMO, 'piso: os dois endereços carimbam o MESMO mecanismo no cabeçalho de diagnóstico' );

F3Base_Atividade::registrar( F3Base_Atividade::ULTIMO_LLMS, array( 'respondeu' => F3Base_Llms::QUEM_NOSSA_ROTA ) );

$atividade_do_indice = ( new F3Base_Modulo_Llms_Txt_Reserva() )->atividade();
$atividade_do_full   = ( new F3Base_Modulo_Llms_Full_Txt() )->atividade();

afirmar( $nome, ! str_contains( (string) $atividade_do_indice[0], 'sem registro até agora' ), 'teto: o índice curto respondeu e a atividade dele continuou dizendo que nunca houve resposta' );
afirmar( $nome, str_contains( (string) $atividade_do_full[0], 'sem registro até agora' ), 'piso: a resposta do índice curto apareceu como resposta do TEXTO INTEGRAL, que não respondeu nada' );

/* O MECANISMO É ARGUMENTO, e não literal: sem isso o cabeçalho volta a ser fixo. */
$parametros_do_responder = ( new ReflectionMethod( 'F3Base_Modulo_Llms_Txt_Reserva', 'responder' ) )->getParameters();
$nomes_do_responder      = array_map( static fn ( ReflectionParameter $p ): string => $p->getName(), $parametros_do_responder );

afirmar( $nome, in_array( 'mecanismo', $nomes_do_responder, true ), 'piso: responder() não recebe quem respondeu — o cabeçalho X-F3Base-Mecanismo volta a ser um literal igual nos dois endereços' );

/**
 * O que falta à rota do texto integral para responder por si. Regra pura sobre
 * o corpo do método, para que o piso possa rodar o MESMO leitor contra a forma
 * antiga sem sujar a fonte.
 *
 * @param string $fonte Código do arquivo, ou o método isolado.
 * @return string[] O que falta; vazio quando a rota carimba e se identifica.
 */
function f3b_rota_do_texto_integral( string $fonte ): array {
	if ( 1 !== preg_match( '/function\s+talvez_servir\s*\(\s*\)\s*:\s*void\s*\{(.*?)\n\t\}/s', $fonte, $achou ) ) {
		return array( 'não há método talvez_servir() a medir' );
	}

	$corpo  = (string) $achou[1];
	$faltam = array();

	if ( ! str_contains( $corpo, 'self::ATIVIDADE' ) ) {
		$faltam[] = 'a rota carimba a atividade numa chave que não é a dela: a resposta de um endereço apaga a do outro';
	}

	if ( ! str_contains( $corpo, 'self::MECANISMO' ) ) {
		$faltam[] = 'a rota não diz a responder() quem respondeu: o cabeçalho X-F3Base-Mecanismo volta a ser o mesmo literal nos dois endereços';
	}

	return $faltam;
}

$rota_do_full = f3b_rota_do_texto_integral( (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-llms-full-txt.php' ) );

afirmar( $nome, array() === $rota_do_full, 'teto: a rota do texto integral não responde por si — ' . implode( '; ', $rota_do_full ) );

/* PISO: o MESMO leitor contra a forma que rodou até a 1.0.1. */
$rota_antiga = "	public function talvez_servir(): void {\n\t\tF3Base_Atividade::registrar(\n\t\t\tF3Base_Atividade::ULTIMO_LLMS,\n\t\t\tarray()\n\t\t);\n\n\t\tF3Base_Modulo_Llms_Txt_Reserva::responder( \$conteudo, \$config );\n\t}\n";

afirmar( $nome, 2 === count( f3b_rota_do_texto_integral( $rota_antiga ) ), 'piso: o leitor não acusou a rota antiga, que carimbava na chave do índice curto e servia sem dizer quem respondeu: ' . wp_json_encode( f3b_rota_do_texto_integral( $rota_antiga ) ) );

/* ---------- schema.faq_so_no_singular ---------- */

/*
 * `get_queried_object_id()` DEVOLVE UM ID EM TODA REQUISIÇÃO — o do TERMO num
 * arquivo de categoria, o do AUTOR num arquivo de autor —, e esses ids colidem
 * com ids de post. Sem a guarda de `is_singular()`, o arquivo da categoria 12
 * emitia o FAQ do post 12: um FAQPage afirmando sobre uma página que não está
 * sendo exibida.
 *
 * TETO: numa página singular o FAQ sai.
 * PISO: num arquivo de termo, com o MESMO id consultado, ele não sai.
 */
$nome = 'schema.faq_so_no_singular';

$conteudo_com_faq = '<!-- wp:core/details {"summary":"Qual o prazo?"} --><div class="wp-block-details"><!-- wp:core/paragraph --><p>Cinco dias uteis.</p><!-- /wp:core/paragraph --></div><!-- /wp:core/details -->';

bancada_limpa();
$GLOBALS['f3b_bench']['conteudo'] = array();
$GLOBALS['f3b_bench']['metas']    = array();
f3b_llms_conteudo( 12, 'Pagina com FAQ', 'page', '2026-03-03', $conteudo_com_faq );

$GLOBALS['f3b_forma'] = array( 'singular' => true, 'tipo' => 'page', 'id' => 12 );

$faq_singular = F3Base_Modulo_Schema_Extensao::faq_da_pagina();

afirmar( $nome, 1 === count( $faq_singular ), 'teto: numa página singular com bloco core/details o FAQ deixou de ser lido — ' . wp_json_encode( $faq_singular ) );
afirmar( $nome, 'Qual o prazo?' === (string) ( $faq_singular[0]['pergunta'] ?? '' ), 'teto: a pergunta lida do bloco saiu "' . (string) ( $faq_singular[0]['pergunta'] ?? '' ) . '"' );

$GLOBALS['f3b_forma'] = array(
	'tax'   => true,
	'id'    => 12,
	'termo' => new WP_Term( array( 'term_id' => 12, 'name' => 'Notícias', 'slug' => 'noticias', 'taxonomy' => 'category', 'count' => 9 ) ),
);

$faq_no_arquivo = F3Base_Modulo_Schema_Extensao::faq_da_pagina();

afirmar( $nome, array() === $faq_no_arquivo, 'piso: o arquivo de termo emitiu o FAQ do POST de mesmo id — schema afirmando sobre uma página que não está sendo exibida' );

$GLOBALS['f3b_forma'] = array( 'autor' => true, 'id' => 12 );

afirmar( $nome, array() === F3Base_Modulo_Schema_Extensao::faq_da_pagina(), 'piso: o arquivo de autor emitiu o FAQ do post de mesmo id' );

/* O ARGUMENTO EXPLÍCITO passa por cima da guarda: é assim que o filtro e a bancada leem fora do laço. */
afirmar( $nome, 1 === count( F3Base_Modulo_Schema_Extensao::faq_da_pagina( 12 ) ), 'teto: com o id informado a leitura fora do laço deixou de funcionar — o filtro f3base_faq_detalhes perderia o conteúdo' );

$GLOBALS['f3b_forma'] = array();

/* ---------- schema.same_as_une ---------- */

/*
 * `sameAs` É LISTA DE PERFIS, e a resposta certa é o conjunto dos dois lados. O
 * docblock dizia "só grava chave ausente" e o código sempre reescrevia: quem
 * lesse a promessa acreditaria que o valor do plugin de SEO vencia, e quem
 * lesse o código veria a lista da configuração no lugar dela. As duas leituras
 * estavam erradas, porque o certo é a união — e agora é o que o texto diz.
 *
 * TETO: os perfis dos dois lados saem, sem repetição.
 * PISO: nenhum dos dois lados pode sumir, e a chave já emitida pelo plugin
 * continua valendo para as demais propriedades.
 */
$nome = 'schema.same_as_une';

bancada_limpa();
requisicao_nova();

F3Base_Options::gravar(
	'f3base_seo_entidade',
	array(
		'nome'          => 'Bancada',
		'same_as'       => array( 'https://exemplo.test/perfil-declarado', 'https://exemplo.test/ja-emitido' ),
		'area_servida'  => array( 'Brasil' ),
		'conhece_sobre' => array(),
		'ponto_de_contato' => array(),
		'organizacao_mae'  => '',
		'servicos'      => array(),
		'faq_schema'    => false,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$organizacao = ( new F3Base_Modulo_Schema_Extensao() )->estender_organizacao(
	array(
		'@type'      => 'Organization',
		'sameAs'     => array( 'https://exemplo.test/ja-emitido', 'https://exemplo.test/do-plugin' ),
		'areaServed' => array( 'Portugal' ),
	)
);

$perfis = is_array( $organizacao['sameAs'] ?? null ) ? array_values( $organizacao['sameAs'] ) : array();

afirmar( $nome, in_array( 'https://exemplo.test/do-plugin', $perfis, true ), 'piso: o perfil que o plugin de SEO já emitia SUMIU do grafo — reescrever a chave inteira apaga o que o outro emissor tinha posto' );
afirmar( $nome, in_array( 'https://exemplo.test/perfil-declarado', $perfis, true ), 'piso: o perfil declarado na configuração não entrou no grafo' );
afirmar( $nome, 3 === count( $perfis ), 'piso: a união repetiu o perfil que existia dos dois lados — ' . wp_json_encode( $perfis ) );
afirmar( $nome, array( 'Portugal' ) === array_values( (array) ( $organizacao['areaServed'] ?? array() ) ), 'teto: areaServed já emitida pelo plugin foi sobrescrita — a regra das demais propriedades é só gravar chave AUSENTE' );

/* E O DOCBLOCK DIZ O QUE O CÓDIGO FAZ. */
$fonte_do_schema = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-schema-extensao.php' );

afirmar( $nome, 1 === preg_match( '/`sameAs` é UNIÃO/u', $fonte_do_schema ), 'piso: o docblock de estender_organizacao() não diz que sameAs é união, e um leitor continuaria acreditando que a chave já emitida vence' );

/* ---------- seguranca.cabecalho_cede_a_quem_chegou_antes ---------- */

/*
 * `header()` COM O `$replace` PADRÃO SUBSTITUI o que outro emissor já pôs.
 *
 * Num site com CSP emitida por um plugin de segurança, a política inteira dele
 * era trocada pela nossa linha de `frame-ancestors`; uma `Permissions-Policy`
 * mais restritiva de outro emissor era afrouxada para a nossa. A regra tem duas
 * metades, porque os cabeçalhos têm duas naturezas: a CSP COMPÕE — o navegador
 * aplica a interseção —, e os demais só saem quando ausentes.
 *
 * TETO: sem ninguém antes, tudo sai, e a CSP sai compondo.
 * PISO: com Referrer-Policy e Permissions-Policy já postos, os dois são CEDIDOS
 * e saem nomeados; a CSP continua saindo, porque compor só aperta.
 */
$nome = 'seguranca.cabecalho_cede_a_quem_chegou_antes';

$lista_de_teste = array(
	'X-Content-Type-Options'    => 'nosniff',
	'Referrer-Policy'           => F3Base_Vocabulario::REFERRER_ESTRITO_ENTRE_SITES,
	'Permissions-Policy'        => F3Base_Vocabulario::PERMISSOES_NEGADAS,
	'Content-Security-Policy'   => "frame-ancestors 'self'",
	'Cross-Origin-Opener-Policy' => F3Base_Vocabulario::COOP_PERMITE_POPUP,
);

$sozinho_na_resposta = F3Base_Modulo_Cabecalhos::decidir_emissao( $lista_de_teste, array() );

afirmar( $nome, count( $lista_de_teste ) === count( $sozinho_na_resposta['emitir'] ), 'teto: sem outro emissor na resposta, algum cabeçalho declarado deixou de sair' );
afirmar( $nome, array() === $sozinho_na_resposta['cedidos'], 'teto: sem outro emissor a lista de cedidos veio preenchida' );

$compostos = array_values( array_filter( $sozinho_na_resposta['emitir'], static fn ( array $i ): bool => $i['compoe'] ) );

afirmar( $nome, 1 === count( $compostos ) && F3Base_Modulo_Cabecalhos::CABECALHO_QUE_COMPOE === $compostos[0]['nome'], 'teto: o único cabeçalho que compõe tem de ser a CSP — ' . wp_json_encode( array_column( $compostos, 'nome' ) ) );

$com_outro_emissor = F3Base_Modulo_Cabecalhos::decidir_emissao(
	$lista_de_teste,
	array(
		'referrer-policy: no-referrer',
		'Permissions-Policy: geolocation=(self)',
		"Content-Security-Policy: default-src 'self'",
	)
);

$emitidos_com_outro = array_column( $com_outro_emissor['emitir'], 'nome' );

afirmar( $nome, ! in_array( 'Referrer-Policy', $emitidos_com_outro, true ), 'piso: Referrer-Policy já posta por outro emissor foi SUBSTITUÍDA — a política de quem chegou antes foi apagada' );
afirmar( $nome, ! in_array( 'Permissions-Policy', $emitidos_com_outro, true ), 'piso: Permissions-Policy já posta por outro emissor foi substituída, afrouxando uma política mais restritiva' );
afirmar( $nome, in_array( 'Content-Security-Policy', $emitidos_com_outro, true ), 'teto: a CSP deixou de ser emitida por já existir outra — ela COMPÕE, e a segunda política só aperta a primeira' );
afirmar( $nome, in_array( 'X-Content-Type-Options', $emitidos_com_outro, true ), 'teto: um cabeçalho que ninguém tinha posto deixou de sair' );
afirmar( $nome, array( 'Referrer-Policy', 'Permissions-Policy' ) === $com_outro_emissor['cedidos'], 'piso: o que foi cedido não sai NOMEADO — ceder em silêncio é a mesma cegueira ao contrário: ' . wp_json_encode( $com_outro_emissor['cedidos'] ) );

/* O NOME É COMPARADO SEM CASO, como o HTTP manda. */
afirmar(
	$nome,
	in_array( 'Referrer-Policy', F3Base_Modulo_Cabecalhos::decidir_emissao( array( 'Referrer-Policy' => 'origin' ), array( 'X-Outro: 1' ) )['emitir'][0]['nome'] ? array( 'Referrer-Policy' ) : array(), true ),
	'teto: cabeçalho de nome diferente do que já estava posto deixou de ser emitido'
);

/* E O ESTADO REGISTRA quem mandou no cabeçalho deste site. */
bancada_limpa();
requisicao_nova();
F3Base_Atividade::registrar( F3Base_Modulo_Cabecalhos::ATIVIDADE, array( 'cedidos' => 'Referrer-Policy' ) );

$avisos_dos_cabecalhos = ( new F3Base_Modulo_Cabecalhos() )->avisos();
$texto_dos_avisos      = implode( ' | ', array_column( $avisos_dos_cabecalhos, 'motivo' ) );

afirmar( $nome, str_contains( $texto_dos_avisos, 'CEDEU' ) && str_contains( $texto_dos_avisos, 'Referrer-Policy' ), 'piso: outro emissor mandando no cabeçalho deste site não aparece no estado — ' . $texto_dos_avisos );

/* ---------- seguranca.frame_ancestors_na_forma ---------- */

/*
 * `sanitize_text_field()` PRESERVA O PONTO E VÍRGULA, e o ponto e vírgula
 * ENCERRA a diretiva: `frame-ancestors 'self'; script-src 'unsafe-inline'` é um
 * CSP inteiro escrito pelo campo da moldura, com efeito sobre o carregamento de
 * todo script da página. O valor é validado na FORMA antes de virar cabeçalho,
 * e o que está fora da forma é preservado, avisado e NÃO emitido.
 *
 * TETO: as formas da especificação passam.
 * PISO: o ponto e vírgula, o esquema http, o `'none'` acompanhado e o lixo não
 * passam — e o cabeçalho não é emitido enquanto o valor estiver assim.
 */
$nome = 'seguranca.frame_ancestors_na_forma';

foreach ( array( "'self'", "'none'", "'self' https://app.exemplo.test", 'https://exemplo.test:8443', "'self' https://*.exemplo.test" ) as $forma_boa ) {
	afirmar( $nome, true === F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma( $forma_boa ), 'teto: a forma declarada "' . $forma_boa . '" foi recusada, e o cabeçalho deixaria de ser emitido num site correto' );
}

foreach ( array(
	"'self'; script-src 'unsafe-inline'" => 'o ponto e vírgula abre uma diretiva NOVA — um CSP inteiro pelo campo errado',
	"'none' 'self'"                      => "'none' acompanhado de outra fonte é uma lista que se contradiz",
	'http://exemplo.test'                => 'origem sem https',
	'exemplo.test'                       => 'origem sem esquema',
	'self'                               => 'a palavra sem as aspas simples não é a palavra-chave da especificação',
	'*'                                  => 'o curinga solto não é a forma que este campo aceita',
) as $forma_ruim => $por_que ) {
	afirmar( $nome, false === F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma( (string) $forma_ruim ), 'piso: "' . $forma_ruim . '" passou na forma — ' . $por_que );
}

bancada_limpa();
requisicao_nova();

F3Base_Options::gravar( 'f3base_cabecalhos', array( 'csp_frame_ancestors' => "'self'" ), F3Base_Options::ORIGEM_IMPLANTADOR );

afirmar( $nome, array_key_exists( F3Base_Modulo_Cabecalhos::CABECALHO_QUE_COMPOE, ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos() ), 'teto: com o valor na forma o cabeçalho de moldura deixou de ser emitido' );

/*
 * O VALOR FORA DA FORMA ENTRA SEM PASSAR PELO GRAVADOR, pela mesma razão do
 * bloco dos redirects: desde que `sanitiza_cabecalhos()` passou a exigir a forma
 * do módulo, um valor NOVO com ponto e vírgula não substitui mais um valor bom.
 * O que este bloco mede é o valor que JÁ ESTÁ gravado — de uma release anterior
 * ou escrito à mão —, e ele precisa continuar PRESERVADO, não emitido e
 * nomeado. A recusa da escrita nova é fato de `options.normalizacao_avisa`.
 */
$GLOBALS['f3b_bench']['options']['f3base_cabecalhos'] = array_merge(
	(array) $GLOBALS['f3b_bench']['options']['f3base_cabecalhos'],
	array( 'csp_frame_ancestors' => "'self'; script-src 'unsafe-inline'" )
);
requisicao_nova();

$lista_fora_da_forma = ( new F3Base_Modulo_Cabecalhos() )->lista_de_cabecalhos();
$avisos_fora_da_forma = implode( ' | ', array_column( ( new F3Base_Modulo_Cabecalhos() )->avisos(), 'motivo' ) );

afirmar( $nome, ! array_key_exists( F3Base_Modulo_Cabecalhos::CABECALHO_QUE_COMPOE, $lista_fora_da_forma ), 'piso: o valor com ponto e vírgula virou cabeçalho — a diretiva injetada passa a valer para todo script da página' );
afirmar( $nome, str_contains( $avisos_fora_da_forma, 'fora da forma' ), 'piso: o valor fora da forma foi ignorado em SILÊNCIO — apagar ou ignorar sem dizer é o que este pacote parou de fazer: ' . $avisos_fora_da_forma );
afirmar( $nome, "'self'; script-src 'unsafe-inline'" === (string) ( F3Base_Options::ler( 'f3base_cabecalhos' )['csp_frame_ancestors'] ?? '' ), 'teto: o valor fora da forma foi APAGADO do que estava gravado, em vez de preservado' );

/* ---------- seguranca.cabecalhos_alcancam_rest ---------- */

/*
 * `send_headers` NÃO RODA em toda resposta da API REST: o corpo JSON saía sem
 * `nosniff`, sem `Referrer-Policy` e sem HSTS. O recorte é decisão declarada —
 * vão para o REST os cabeçalhos que governam a RESPOSTA; ficam de fora COOP e
 * `Permissions-Policy`, que governam um contexto de navegação de topo que um
 * corpo JSON não abre.
 *
 * TETO: o filtro está declarado, devolve o que recebeu, e o recorte leva os que
 * fazem sentido.
 * PISO: COOP e Permissions-Policy não podem entrar no recorte, e o filtro não
 * pode decidir pelo núcleo se o corpo já foi servido.
 */
$nome = 'seguranca.cabecalhos_alcancam_rest';

$ganchos_dos_cabecalhos = ( new F3Base_Modulo_Cabecalhos() )->hooks();
$hooks_declarados       = array_column( $ganchos_dos_cabecalhos, 'hook' );

afirmar( $nome, in_array( 'rest_pre_serve_request', $hooks_declarados, true ), 'piso: o módulo não declara gancho na API REST — a resposta JSON continua saindo sem nenhum cabeçalho de segurança' );
afirmar( $nome, in_array( 'send_headers', $hooks_declarados, true ), 'teto: o gancho do front-end sumiu junto' );

$recorte_do_rest = F3Base_Modulo_Cabecalhos::cabecalhos_para_rest( $lista_de_teste );

afirmar( $nome, array_key_exists( 'X-Content-Type-Options', $recorte_do_rest ), 'piso: nosniff ficou fora da resposta JSON — a mesma superfície que o HTML tem' );
afirmar( $nome, array_key_exists( 'Referrer-Policy', $recorte_do_rest ), 'piso: Referrer-Policy ficou fora da resposta JSON' );
afirmar( $nome, array_key_exists( F3Base_Modulo_Cabecalhos::CABECALHO_QUE_COMPOE, $recorte_do_rest ), 'piso: a CSP de frame-ancestors ficou fora da resposta JSON' );
afirmar( $nome, ! array_key_exists( 'Cross-Origin-Opener-Policy', $recorte_do_rest ), 'piso: COOP entrou na resposta JSON — ele governa um contexto de navegação de topo, que um corpo JSON não abre' );
afirmar( $nome, ! array_key_exists( 'Permissions-Policy', $recorte_do_rest ), 'piso: Permissions-Policy entrou na resposta JSON, pelo mesmo motivo' );

afirmar( $nome, true === ( new F3Base_Modulo_Cabecalhos() )->emitir_no_rest( true ), 'piso: o filtro do REST trocou o valor que recebeu — quem decide se o corpo já foi servido é o núcleo' );
afirmar( $nome, false === ( new F3Base_Modulo_Cabecalhos() )->emitir_no_rest( false ), 'piso: o filtro do REST trocou o valor falso que recebeu' );

/* ---------- vocabulario.cabecalhos_governados ---------- */

/*
 * GOVERNAR NO VOCABULÁRIO E NÃO RECONHECER NO RUNTIME é pior que não governar.
 * `cabecalhos.permissions_policy` estava declarada como governada e o
 * sanitizador a aceitava por `sanitize_text_field`, isto é, aceitava qualquer
 * coisa; `cabecalhos.csp_frame_ancestors` não estava declarada e também não era
 * conferida em lugar nenhum. As duas metades andam juntas ou o vocabulário vira
 * documentação sobre uma recusa que não acontece.
 *
 * TETO: as duas chaves são governadas, e todo valor que o vocabulário aceita
 * passa na forma que o módulo exige.
 * PISO: o que o vocabulário NÃO aceita não pode passar na forma do módulo.
 */
$nome = 'vocabulario.cabecalhos_governados';

$governadas = F3Base_Vocabulario::decisoes_governadas();

foreach ( array( 'cabecalhos.permissions_policy', 'cabecalhos.csp_frame_ancestors' ) as $chave_governada ) {
	afirmar( $nome, array_key_exists( $chave_governada, $governadas ), 'piso: "' . $chave_governada . '" saiu do vocabulário — o site-core deixa de declarar o conjunto que reconhece, e o sanitizador do outro lado passa a aceitar qualquer coisa sem contradizer ninguém' );
}

foreach ( F3Base_Vocabulario::ancestrais_de_frame() as $ancestral_aceito ) {
	if ( '' === $ancestral_aceito ) {
		continue;
	}

	afirmar( $nome, true === F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma( $ancestral_aceito ), 'piso: o vocabulário aceita "' . $ancestral_aceito . '" e o módulo recusa a forma — o implantador gravaria um valor que este runtime nunca emite' );
}

afirmar( $nome, false === F3Base_Modulo_Cabecalhos::frame_ancestors_na_forma( "'self'; script-src 'unsafe-inline'" ), 'piso: um valor que o vocabulário não declara passou na forma do módulo' );
afirmar( $nome, in_array( "'self'", F3Base_Vocabulario::ancestrais_de_frame(), true ), 'teto: o valor que o catálogo escolhe saiu do conjunto que o site-core reconhece' );
afirmar( $nome, in_array( F3Base_Vocabulario::PERMISSOES_NEGADAS, F3Base_Vocabulario::politicas_de_permissoes(), true ), 'teto: a Permissions-Policy que o catálogo escolhe saiu do conjunto declarado' );

$padrao_dos_cabecalhos = F3Base_Options::declaracao( 'f3base_cabecalhos' )['padrao'] ?? array();

afirmar( $nome, in_array( (string) ( $padrao_dos_cabecalhos['csp_frame_ancestors'] ?? 'x' ), F3Base_Vocabulario::ancestrais_de_frame(), true ), 'piso: o PADRÃO gravado do campo de moldura está fora do vocabulário que o próprio pacote declara' );
afirmar( $nome, in_array( (string) ( $padrao_dos_cabecalhos['permissions_policy'] ?? 'x' ), F3Base_Vocabulario::politicas_de_permissoes(), true ), 'piso: o PADRÃO gravado de Permissions-Policy está fora do vocabulário que o próprio pacote declara' );

/* ---------- retencao.corte_em_calendario ---------- */

/*
 * `MONTH_IN_SECONDS` É TRINTA DIAS, e o prazo declarado é em MESES: "guardar
 * por 12 meses" virava 360 dias — cinco dias e pouco a menos por ano, sem que
 * nada dissesse isso. Registro apagado cinco dias antes do prazo é apagado
 * antes do prazo.
 *
 * TETO: doze meses de calendário caem no mesmo dia do ano anterior.
 * PISO: a conta por trinta dias erra, e o estado diz a data de corte.
 */
$nome = 'retencao.corte_em_calendario';

$referencia = gmmktime( 12, 0, 0, 3, 15, 2026 );

afirmar( $nome, '2025-03-15 12:00:00' === F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 12, $referencia ), 'piso: doze meses de calendário não caíram em 15/03/2025 — saiu ' . F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 12, $referencia ) );
afirmar( $nome, '2025-09-15 12:00:00' === F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 6, $referencia ), 'piso: seis meses de calendário saíram em ' . F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 6, $referencia ) );
afirmar( $nome, gmdate( 'Y-m-d H:i:s', $referencia - ( 12 * MONTH_IN_SECONDS ) ) !== F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 12, $referencia ), 'piso: o corte continua sendo doze vezes trinta dias — 360 dias apagam o registro cinco dias antes do prazo declarado' );
afirmar( $nome, F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 0, $referencia ) === F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 1, $referencia ), 'teto: prazo zero não caiu no mínimo de um mês, e o corte cairia no instante da execução' );

bancada_limpa();
requisicao_nova();
F3Base_Options::gravar( 'f3base_retencao_meses', 12, F3Base_Options::ORIGEM_IMPLANTADOR );
$GLOBALS['f3b_bench']['eventos'][ F3Base_Modulo_Retencao_Eliminacao::EVENTO ] = array(
	'hook'      => F3Base_Modulo_Retencao_Eliminacao::EVENTO,
	'timestamp' => time() + DAY_IN_SECONDS,
	'schedule'  => 'daily',
	'interval'  => DAY_IN_SECONDS,
	'args'      => array(),
);

$estado_da_retencao = ( new F3Base_Modulo_Retencao_Eliminacao() )->estado();

afirmar( $nome, str_contains( $estado_da_retencao['motivo'], F3Base_Modulo_Retencao_Eliminacao::corte_de_retencao( 12 ) ), 'piso: a frase de estado não diz a DATA de corte, e "12 meses" continua podendo significar 360 dias sem ninguém saber — ' . $estado_da_retencao['motivo'] );

/* ---------- retencao.desagendamento_com_teto ---------- */

/*
 * `wp_unschedule_event()` PODE FALHAR devolvendo `false` COM O EVENTO AINDA LÁ —
 * outro processo mexendo no array do cron, um filtro de terceiro recusando, um
 * cron object corrompido. Um laço que só pergunta `while ( false !==
 * wp_next_scheduled() )` recebe de volta o mesmo carimbo para sempre: a
 * desativação do plugin não termina, e o operador vê a tela do wp-admin
 * pendurada até o limite de tempo do PHP.
 *
 * TETO: com o evento agendado, a desinstalação o remove e devolve o controle.
 * PISO: os dois laços têm teto declarado E conferem o retorno — o mesmo leitor
 * roda contra a forma antiga, que não tinha nem um nem outro.
 */
$nome = 'retencao.desagendamento_com_teto';

/**
 * O laço de desagendamento de um arquivo é limitado e confere o retorno?
 *
 * Regra pura sobre o texto do método, para que o piso possa rodar o MESMO
 * leitor contra a forma antiga sem sujar a fonte.
 *
 * @param string $fonte Código do arquivo.
 * @return string[] O que falta; vazio quando o laço está fechado.
 */
function f3b_laco_de_desagendamento( string $fonte ): array {
	if ( 1 !== preg_match( '/function\s+desinstalar\s*\(\s*\)\s*:\s*void\s*\{(.*?)\n\t\}/s', $fonte, $achou ) ) {
		return array( 'não há método desinstalar() a medir' );
	}

	$corpo  = (string) $achou[1];
	$faltam = array();

	if ( ! str_contains( $corpo, 'TETO_DE_DESAGENDAMENTO' ) ) {
		$faltam[] = 'o laço não tem teto declarado de voltas';
	}

	if ( ! str_contains( $corpo, 'true !== wp_unschedule_event' ) ) {
		$faltam[] = 'o retorno de wp_unschedule_event() não é conferido: desagendamento que falha devolve o MESMO carimbo, e o laço não termina';
	}

	return $faltam;
}

foreach ( array(
	'class-f3base-modulo-retencao-eliminacao.php',
	'class-f3base-modulo-cadencia-relatorio.php',
) as $arquivo_com_laco ) {
	$faltando_no_laco = f3b_laco_de_desagendamento( (string) file_get_contents( $raiz . '/fontes/plugin/includes/' . $arquivo_com_laco ) );

	afirmar( $nome, array() === $faltando_no_laco, 'teto: em ' . $arquivo_com_laco . ' — ' . implode( '; ', $faltando_no_laco ) );
}

/* PISO: o MESMO leitor contra a forma antiga, que é a que rodou até a 1.0.1. */
$laco_antigo = "	public function desinstalar(): void {\n\t\t\$timestamp = wp_next_scheduled( self::EVENTO );\n\n\t\twhile ( false !== \$timestamp ) {\n\t\t\twp_unschedule_event( (int) \$timestamp, self::EVENTO );\n\t\t\t\$timestamp = wp_next_scheduled( self::EVENTO );\n\t\t}\n\t}\n";

afirmar( $nome, 2 === count( f3b_laco_de_desagendamento( $laco_antigo ) ), 'piso: o leitor não acusou o laço SEM teto e SEM conferência do retorno — que é a forma que rodou até a 1.0.1: ' . wp_json_encode( f3b_laco_de_desagendamento( $laco_antigo ) ) );

/* E ele funciona: com o evento agendado, a desinstalação o remove. */
bancada_limpa();
requisicao_nova();
$GLOBALS['f3b_bench']['eventos'][ F3Base_Modulo_Retencao_Eliminacao::EVENTO ] = array(
	'hook'      => F3Base_Modulo_Retencao_Eliminacao::EVENTO,
	'timestamp' => time() + DAY_IN_SECONDS,
	'schedule'  => 'daily',
	'interval'  => DAY_IN_SECONDS,
	'args'      => array(),
);

( new F3Base_Modulo_Retencao_Eliminacao() )->desinstalar();

afirmar( $nome, false === wp_next_scheduled( F3Base_Modulo_Retencao_Eliminacao::EVENTO ), 'teto: a desinstalação deixou o evento agendado — o teto do laço não pode custar o desagendamento' );

/* ---------- redirects.par_que_gira_recusado ---------- */

/*
 * O PAR QUE GIRA É RECUSADO NA HORA DE SERVIR, e não só no sanitizador: o par
 * pode ter sido gravado por uma versão anterior deste pacote, por outro agente
 * ou à mão no banco. Quem serve a requisição é o módulo, e é ele que não pode
 * devolver o visitante ao mesmo endereço.
 *
 * TETO: par de verdade continua valendo, e a normalização é a mesma dos dois lados.
 * PISO: `/servicos/ -> /servicos` é recusado e sai NOMEADO no estado.
 */
$nome = 'redirects.par_que_gira_recusado';

afirmar( $nome, '/servicos' === F3Base_Modulo_Redirects::normalizar( '/servicos/' ), 'teto: a normalização não tira a barra final — ' . F3Base_Modulo_Redirects::normalizar( '/servicos/' ) );
afirmar( $nome, '/servicos' === F3Base_Modulo_Redirects::normalizar( '/servicos?utm_source=x' ), 'teto: a normalização não tira a query' );
afirmar( $nome, true === F3Base_Modulo_Redirects::par_gira( '/servicos/', '/servicos' ), 'piso: o par que difere só pela barra final não foi reconhecido como laço — é ele que gira para sempre e o navegador corta com ERR_TOO_MANY_REDIRECTS' );
afirmar( $nome, true === F3Base_Modulo_Redirects::par_gira( '/servicos', '/servicos/?utm=1' ), 'piso: o par que difere só pela query não foi reconhecido como laço' );
afirmar( $nome, false === F3Base_Modulo_Redirects::par_gira( '/antigo', '/novo' ), 'teto: um par de verdade foi tratado como laço, e o redirecionamento declarado deixaria de existir' );

bancada_limpa();
requisicao_nova();

/*
 * O PAR ENTRA NO BANCO SEM PASSAR PELO GRAVADOR, e é assim que ele chega a um
 * site real. Desde que `sanitiza_redirects()` passou a usar a normalização do
 * COMPARADOR, o gravador único não aceita mais um par que gira — e é por isso
 * que esta bancada o planta direto na option: o que este bloco mede é o par que
 * JÁ ESTÁ gravado, escrito por uma versão anterior deste pacote, por outro
 * agente ou à mão no banco. A recusa da ESCRITA é outro fato, e tem linha
 * própria em `options.normalizacao_avisa`.
 */
$GLOBALS['f3b_bench']['options']['f3base_redirects'] = array(
	array(
		'de'     => '/servicos/',
		'para'   => '/servicos',
		'status' => 301,
	),
	array(
		'de'     => '/antigo',
		'para'   => '/novo',
		'status' => 301,
	),
);

$avisos_dos_redirects = implode( ' | ', array_column( ( new F3Base_Modulo_Redirects() )->avisos(), 'motivo' ) );

afirmar( $nome, str_contains( $avisos_dos_redirects, '/servicos/ → /servicos' ), 'piso: o par que gira ficou gravado e o estado NÃO o nomeia — o operador não teria como saber qual endereço parou de redirecionar: ' . $avisos_dos_redirects );
afirmar( $nome, ! str_contains( $avisos_dos_redirects, '/antigo' ), 'piso: o par de verdade entrou no aviso junto com o que gira' );

/* ---------- partilhado.contrato_declarado ---------- */

/*
 * AS QUATRO CLASSES PARTILHADAS rodam em DOIS runtimes que não se enxergam, e o
 * docblock de cada uma é o que explica por quê. Dois defeitos de texto moravam
 * ali, e os dois enganam quem for mexer:
 *
 * 1. Elas diziam que o implantador as alcança por `require_once` da "cópia de
 *    origem" em `fontes/plugin/includes/`. Neste repositório elas MORAM aqui, e
 *    quem carrega uma cópia é o implantador, que a vendoriza na árvore dele.
 * 2. Elas diziam que `F3Base_Censo_Demonstrativo` "não usa nada do WordPress".
 *    Ele usa `$wpdb->prepare()` e `get_post_types()`. O que as quatro têm em
 *    comum é não ter PAI nem dependência interna, e não abstinência de núcleo.
 *
 * E a guarda de `class_exists` faltava justamente no censo — a única das quatro
 * sem ela. Sem a guarda, um processo que carregue os dois runtimes morre em
 * `Cannot declare class`.
 *
 * TETO: as quatro estão guardadas e nenhuma afirma o que o código contradiz.
 * PISO: o MESMO leitor contra as frases antigas tem de acusar as duas.
 */
$nome = 'partilhado.contrato_declarado';

/**
 * As classes partilhadas e o que cada arquivo precisa dizer e não dizer.
 *
 * @return array<string,string> Arquivo => nome da classe.
 */
function f3b_classes_partilhadas(): array {
	return array(
		'class-f3base-chaves-seo.php'          => 'F3Base_Chaves_Seo',
		'class-f3base-vocabulario.php'         => 'F3Base_Vocabulario',
		'class-f3base-emissores.php'           => 'F3Base_Emissores',
		'class-f3base-censo-demonstrativo.php' => 'F3Base_Censo_Demonstrativo',
	);
}

/**
 * O que falta a um arquivo partilhado. Regra pura sobre o texto.
 *
 * @param string $fonte  Código do arquivo.
 * @param string $classe Nome da classe declarada nele.
 * @return string[] O que falta; vazio quando o arquivo está em ordem.
 */
function f3b_partilhada_pendente( string $fonte, string $classe ): array {
	$faltam = array();

	if ( ! str_contains( $fonte, "if ( ! class_exists( '" . $classe . "' ) ) {" ) ) {
		$faltam[] = $classe . ' não vem guardada por class_exists: os dois runtimes a alcançam por caminhos de arquivo diferentes, e require_once não os reconhece como o mesmo';
	}

	if ( str_contains( $fonte, 'cópia de origem em' ) ) {
		$faltam[] = $classe . ' afirma que o implantador lê a "cópia de origem" daqui: neste repositório o arquivo MORA aqui, e quem carrega uma cópia é o implantador, que a vendoriza';
	}

	if ( str_contains( $fonte, 'F3Base_Censo_Demonstrativo' ) && 1 === preg_match( '/N[ÃA]O usa nada do WordPress[^.]*F3Base_Censo_Demonstrativo/su', $fonte ) ) {
		$faltam[] = $classe . ' afirma que o censo não usa nada do WordPress, e ele usa $wpdb e get_post_types()';
	}

	if ( ! str_contains( mb_strtolower( $fonte ), 'vendoriza' ) ) {
		$faltam[] = $classe . ' não diz que o implantador VENDORIZA uma cópia: sem isso, quem editar a cópia de lá acha que editou esta';
	}

	return $faltam;
}

$fonte_do_censo = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-censo-demonstrativo.php' );

afirmar( $nome, str_contains( $fonte_do_censo, '$wpdb->prepare(' ), 'teto: o censo deixou de usar $wpdb, e a frase que este bloco confere passaria a descrever outra coisa' );

foreach ( f3b_classes_partilhadas() as $arquivo_partilhado => $classe_partilhada ) {
	$pendente = f3b_partilhada_pendente( (string) file_get_contents( $raiz . '/fontes/plugin/includes/' . $arquivo_partilhado ), $classe_partilhada );

	afirmar( $nome, array() === $pendente, 'teto: em ' . $arquivo_partilhado . ' — ' . implode( '; ', $pendente ) );
}

/* PISO: o MESMO leitor contra o texto que estava nas quatro até a 1.0.1. */
$docblock_antigo = " * A classe NÃO tem pai e NÃO usa nada do WordPress, pelo mesmo motivo de\n * `F3Base_Emissores` e de `F3Base_Censo_Demonstrativo`: ela roda em dois runtimes\n * que não se enxergam. O implantador a alcança por `require_once` da cópia de origem em\n * `fontes/plugin/includes/`.\n\nfinal class F3Base_Chaves_Seo {\n";
$pendente_antigo = implode( ' | ', f3b_partilhada_pendente( $docblock_antigo, 'F3Base_Chaves_Seo' ) );

foreach ( array(
	'guardada por class_exists' => 'a falta da guarda',
	'cópia de origem'           => 'o endereço errado do arquivo',
	'não usa nada do WordPress' => 'a abstinência de WordPress que o censo nunca teve',
	'VENDORIZA'                 => 'o silêncio sobre a cópia que o implantador carrega',
) as $trecho_antigo => $o_que_e ) {
	afirmar( $nome, str_contains( $pendente_antigo, (string) $trecho_antigo ), 'piso: o leitor não acusou ' . $o_que_e . ' no texto que estava nas quatro até a 1.0.1 — ' . $pendente_antigo );
}

/* ---------- cadencia.frase_nomeia_o_evento ---------- */

/*
 * O COMENTÁRIO DE TRADUÇÃO DESCREVE O ARGUMENTO, e o desta frase descrevia
 * outros três: dizia "1: recorrência declarada, 2: data e hora previstas, 3:
 * gatilho por ajustes" sobre uma chamada que passa o NOME DO EVENTO, a
 * RECORRÊNCIA e a DATA. Quem traduz o pacote reordena a frase pelo comentário —
 * e o resultado é uma frase de estado que troca o nome do evento pela data.
 *
 * TETO: a frase nomeia o evento, a recorrência e a data, nessa ordem, e o
 * comentário diz isso.
 * PISO: o MESMO leitor contra o comentário antigo tem de acusar.
 */
$nome = 'cadencia.frase_nomeia_o_evento';

/**
 * O comentário de tradução da frase de estado descreve os argumentos certos?
 *
 * @param string $fonte Código do arquivo, ou o comentário isolado.
 * @return string[] O que está errado; vazio quando o comentário confere.
 */
function f3b_translators_da_cadencia( string $fonte ): array {
	if ( 1 !== preg_match( '#/\* translators: ([^*]*?) \*/\s*__\( \'escutando #u', $fonte, $achou ) ) {
		return array( 'não há comentário de tradução na frase de estado da cadência' );
	}

	$itens = preg_split( '/\s*\d+:\s*/u', trim( (string) $achou[1] ) );
	$itens = is_array( $itens ) ? array_values( array_filter( array_map( 'trim', $itens ) ) ) : array();

	if ( 3 !== count( $itens ) ) {
		return array( 'o comentário descreve ' . count( $itens ) . ' argumento(s) e a frase tem três' );
	}

	$esperado = array( 'evento', 'recorrência', 'data' );
	$errados  = array();

	foreach ( $esperado as $posicao => $palavra ) {
		if ( ! str_contains( mb_strtolower( $itens[ $posicao ] ), $palavra ) ) {
			$errados[] = 'o argumento ' . ( $posicao + 1 ) . ' é ' . $palavra . ' e o comentário diz "' . $itens[ $posicao ] . '"';
		}
	}

	return $errados;
}

$fonte_da_cadencia = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-cadencia-relatorio.php' );
$translators_hoje  = f3b_translators_da_cadencia( $fonte_da_cadencia );

afirmar( $nome, array() === $translators_hoje, 'teto: o comentário de tradução da frase de estado da cadência descreve o argumento errado — ' . implode( '; ', $translators_hoje ) );

$comentario_antigo = "/* translators: 1: recorrência declarada, 2: data e hora previstas, 3: gatilho por ajustes. */ __( 'escutando %1\$s com recorrência %2\$s; próxima execução prevista para %3\$s.', 'f3base' )";

afirmar( $nome, 3 === count( f3b_translators_da_cadencia( $comentario_antigo ) ), 'piso: o leitor não acusou o comentário antigo, que descrevia os três argumentos trocados: ' . wp_json_encode( f3b_translators_da_cadencia( $comentario_antigo ) ) );

/* E A FRASE QUE SAI é a que o comentário descreve, nessa ordem. */
bancada_limpa();
requisicao_nova();
F3Base_Options::gravar( 'f3base_cadencia', array( 'periodicidade' => 'mensal', 'apos_n_ajustes' => 0, 'mecanismo' => '', 'hook' => '' ), F3Base_Options::ORIGEM_IMPLANTADOR );
$GLOBALS['f3b_bench']['eventos'][ F3Base_Modulo_Cadencia_Relatorio::HOOK ] = array(
	'hook'      => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	'timestamp' => time() + DAY_IN_SECONDS,
	'schedule'  => F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL,
	'interval'  => 30 * DAY_IN_SECONDS,
	'args'      => array(),
);

$frase_da_cadencia = (string) ( new F3Base_Modulo_Cadencia_Relatorio() )->estado()['motivo'];

$onde_evento     = mb_strpos( $frase_da_cadencia, F3Base_Modulo_Cadencia_Relatorio::HOOK );
$onde_recorrencia = mb_strpos( $frase_da_cadencia, F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL );

afirmar( $nome, false !== $onde_evento, 'piso: a frase de estado não nomeia o evento escutado — ' . $frase_da_cadencia );
afirmar( $nome, false !== $onde_recorrencia && $onde_recorrencia > $onde_evento, 'piso: a recorrência não vem depois do nome do evento, que é a ordem que o comentário de tradução declara — ' . $frase_da_cadencia );
afirmar( $nome, 1 === preg_match( '#\d{2}/\d{2}/\d{4}#', $frase_da_cadencia ), 'piso: a frase de estado não traz a data prevista no terceiro lugar — ' . $frase_da_cadencia );

/* ---------- cadencia.previsao_so_com_evento ---------- */

/*
 * PREVISÃO SEM EVENTO É UM HORÁRIO QUE NINGUÉM VAI CUMPRIR.
 *
 * `wp_schedule_event()` devolve `false` quando a recorrência não existe no
 * núcleo daquele processo — e é exatamente o que acontece na ATIVAÇÃO, em que
 * `init` já passou sem o plugin. Gravar `previsto` mesmo assim faz o
 * carregamento seguinte medir atraso contra um horário inventado, encontrar
 * horas de atraso e degradar o módulo por uma execução que nunca foi agendada.
 *
 * TETO: com a recorrência conhecida, agenda e grava a previsão.
 * PISO: com a recorrência desconhecida, não agenda e NÃO grava a previsão.
 */
$nome = 'cadencia.previsao_so_com_evento';

bancada_limpa();
requisicao_nova();
/*
 * O FILTRO DAS RECORRÊNCIAS PRÓPRIAS SAI DAQUI, e é ele o ponto do bloco: o
 * processo da ativação é justamente aquele em que ninguém o registrou.
 */
$GLOBALS['f3b_bench']['hooks']['cron_schedules'] = array();
$GLOBALS['f3b_bench']['eventos']                 = array();
F3Base_Options::gravar( 'f3base_cadencia', array( 'periodicidade' => 'mensal', 'apos_n_ajustes' => 0, 'mecanismo' => '', 'hook' => '' ), F3Base_Options::ORIGEM_IMPLANTADOR );

/* SEM o filtro das recorrências próprias — que é o estado do processo da ativação. */
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();

afirmar( $nome, false === wp_next_scheduled( F3Base_Modulo_Cadencia_Relatorio::HOOK ), 'teto: a bancada não reproduziu o processo da ativação — sem as recorrências próprias registradas o núcleo tem de recusar f3base_mensal' );
afirmar( $nome, 0 === F3Base_Modulo_Cadencia_Relatorio::previsto(), 'piso: a previsão foi gravada sobre um agendamento que FRACASSOU — o carregamento seguinte mede atraso contra um horário que evento nenhum vai cumprir' );

/* COM as recorrências registradas — que é o que a correção faz no gancho de ativação. */
$modulo_da_cadencia = new F3Base_Modulo_Cadencia_Relatorio();
add_filter( 'cron_schedules', array( $modulo_da_cadencia, 'registrar_recorrencias' ), 10, 1 );

$modulo_da_cadencia->garantir_agendamento();

afirmar( $nome, false !== wp_next_scheduled( F3Base_Modulo_Cadencia_Relatorio::HOOK ), 'teto: com as recorrências próprias registradas o evento continuou sem agendamento' );
afirmar( $nome, F3Base_Modulo_Cadencia_Relatorio::previsto() > 0, 'teto: agendou e não gravou a previsão — sem ela o atraso da execução seguinte deixa de ser medido' );

$fonte_do_instalar = (string) file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-cadencia-relatorio.php' );

afirmar( $nome, 1 === preg_match( "/function instalar\(\): void \{.*?add_filter\( 'cron_schedules'/s", $fonte_do_instalar ), 'piso: o gancho de ativação não registra as recorrências próprias, e o agendamento da ativação volta a devolver false num núcleo que só conhece hourly, twicedaily, daily e weekly' );

$GLOBALS['f3b_bench']['hooks']['cron_schedules'] = array();

/* ---------- options.normalizacao_avisa ---------- */

/*
 * QUEM GRAVA PRECISA SABER O QUE FICOU GRAVADO, e o aviso só saía para valor
 * ESCALAR: `gravar()` testava `is_scalar( $valor )` antes de dizer que a
 * sanitização tinha mudado alguma coisa, e treze das options deste catálogo são
 * GRUPO. Quem gravasse um grupo com um campo fora da forma recebia `ok: true` e
 * silêncio — a leitura de volta CONFERIA, porque ela compara o normalizado com o
 * normalizado; quem discordava era a ENTRADA, e ninguém a comparava.
 *
 * TETO: o aviso sai para grupo e NOMEIA o campo normalizado; a gravação limpa
 * continua saindo sem aviso nenhum.
 * PISO: `retencao_meses = 0` é RECUSADO com o prazo anterior de pé — a elevação
 * silenciosa a 1 fazia a rotina do dia seguinte apagar lead —, o par de redirect
 * que gira não entra e sai nomeado, e o `csp_frame_ancestors` fora da forma não
 * substitui um valor bom.
 */
$nome = 'options.normalizacao_avisa';

bancada_limpa();
requisicao_nova();

/* TETO: gravação sem nada a normalizar não produz aviso — aviso que sai sempre deixa de ser lido. */
$limpa = F3Base_Options::gravar(
	'f3base_comportamento',
	array(
		'ligado'                => true,
		'retencao_dias'         => 90,
		'retencao_eventos_dias' => 30,
		'dias_no_painel'        => 28,
	),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar( $nome, true === $limpa['ok'], 'teto: a gravação de um grupo bem formado foi recusada' );
afirmar( $nome, '' === (string) $limpa['motivo'], 'teto: gravação sem nada a normalizar produziu aviso — aviso que sai sempre treina quem opera a ignorar aviso: ' . $limpa['motivo'] );

/* TETO do grupo: o campo normalizado é NOMEADO. */
$com_campo_torto = F3Base_Options::gravar(
	'f3base_comportamento',
	array(
		'ligado'                => true,
		'retencao_dias'         => 90,
		'retencao_eventos_dias' => 3000,
		'dias_no_painel'        => 28,
	),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar( $nome, str_contains( (string) $com_campo_torto['motivo'], 'retencao_eventos_dias' ), 'teto do grupo: o campo normalizado NÃO foi nomeado no aviso — "algo mudou" não serve a quem precisa descobrir qual dos quatro campos não entrou como ele escreveu: ' . $com_campo_torto['motivo'] );
afirmar( $nome, ! str_contains( (string) $com_campo_torto['motivo'], 'dias_no_painel' ), 'teto do grupo: um campo que NÃO mudou entrou na lista de normalizados' );

/* PISO do escalar: o aviso do valor escalar não pode ter sumido junto. */
$id_torto = F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-ABC/DEF', F3Base_Options::ORIGEM_MANUAL );

afirmar( $nome, '' !== (string) $id_torto['motivo'], 'piso do escalar: o aviso de normalização de valor escalar sumiu junto com a mudança' );

/* PISO da recusa: zero é RECUSADO e o prazo anterior fica de pé. */
F3Base_Options::gravar( 'f3base_retencao_meses', 12, F3Base_Options::ORIGEM_IMPLANTADOR );

$zero = F3Base_Options::gravar( 'f3base_retencao_meses', 0, F3Base_Options::ORIGEM_MANUAL );

afirmar( $nome, false === $zero['ok'], 'piso da recusa: o prazo de retenção ZERO foi aceito — ele era elevado a 1 em silêncio, que é o prazo mais curto possível, e a rotina do dia seguinte apagava todo contato com mais de um mês' );
afirmar( $nome, 12 === (int) F3Base_Options::ler( 'f3base_retencao_meses' ), 'piso da recusa: a recusa REESCREVEU o valor gravado — recusar é deixar como estava, e o prazo anterior tem de continuar valendo' );
afirmar( $nome, str_contains( (string) $zero['motivo'], 'RECUSADA' ), 'piso da recusa: a recusa não diz que recusou' );
afirmar( $nome, str_contains( (string) $zero['motivo'], 'apagaria' ) || str_contains( (string) $zero['motivo'], 'apagar' ), 'piso da recusa: o motivo não diz o que o zero faria — recusa sem consequência nomeada é ignorada pelo primeiro que tiver pressa: ' . $zero['motivo'] );

/* PISO do teto do formulário: a tela não pode oferecer o valor que o gravador recusa. */
$declaracao_da_retencao = F3Base_Options::declaracao( 'f3base_retencao_meses' );

afirmar( $nome, 1 === (int) ( $declaracao_da_retencao['minimo'] ?? 0 ), 'piso do formulário: o catálogo não declara mínimo para f3base_retencao_meses, e a tela volta a oferecer min="0" — convidando a digitar o valor que o gravador recusa' );

/* PISO do par que gira: ele não entra, e sai NOMEADO. */
bancada_limpa();
requisicao_nova();

$com_par_que_gira = F3Base_Options::gravar(
	'f3base_redirects',
	array(
		array(
			'de'     => '/servicos/',
			'para'   => '/servicos',
			'status' => 301,
		),
		array(
			'de'     => '/antigo',
			'para'   => '/novo',
			'status' => 301,
		),
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$redirects_gravados = (array) F3Base_Options::ler( 'f3base_redirects' );

afirmar( $nome, 1 === count( $redirects_gravados ), 'piso do par que gira: o par cuja origem e destino normalizam igual foi GRAVADO — ele casa na hora de servir e devolve o visitante ao mesmo endereço para sempre' );
afirmar( $nome, '/antigo' === (string) ( $redirects_gravados[0]['de'] ?? '' ), 'piso do par que gira: a recusa levou junto o par de verdade — recusar um par não é recusar a lista' );
afirmar( $nome, str_contains( (string) $com_par_que_gira['motivo'], '/servicos/' ), 'piso do par que gira: o par recusado não foi NOMEADO — quem gravou não teria como saber qual regra não vale: ' . $com_par_que_gira['motivo'] );

/* PISO da forma do CSP: o valor novo fora da forma não substitui um valor bom. */
bancada_limpa();
requisicao_nova();

F3Base_Options::gravar( 'f3base_cabecalhos', array( 'csp_frame_ancestors' => "'self'" ), F3Base_Options::ORIGEM_IMPLANTADOR );

$csp_injetado = F3Base_Options::gravar(
	'f3base_cabecalhos',
	array( 'csp_frame_ancestors' => "'self'; script-src 'unsafe-inline'" ),
	F3Base_Options::ORIGEM_MANUAL
);

afirmar( $nome, "'self'" === (string) ( F3Base_Options::ler( 'f3base_cabecalhos' )['csp_frame_ancestors'] ?? '' ), 'piso da forma: o valor com ponto e vírgula ENTROU no lugar do valor bom — o ponto e vírgula encerra a diretiva, e o que vem depois vira uma política nova para todo script da página' );
afirmar( $nome, str_contains( (string) $csp_injetado['motivo'], 'csp_frame_ancestors' ), 'piso da forma: a recusa do campo não o NOMEIA: ' . $csp_injetado['motivo'] );

/* ---------- options.sanitizador_idempotente ---------- */

/*
 * SANITIZAR DUAS VEZES TEM DE DAR O MESMO QUE SANITIZAR UMA, e o defeito medido
 * era `sanitiza_llms()`: `politica_privacidade` AUSENTE virava `array()` na
 * primeira passagem e, na segunda, a chave EXISTIA e virava o objeto de quatro
 * campos vazios. Isso não é elegância: `gravar()` compara o que sanitizou com o
 * que RELEU do banco — e a releitura sanitiza de novo. Um sanitizador não
 * idempotente faz a leitura de volta acusar divergência numa gravação que não
 * tinha nada de errado, e o operador vê "o valor lido de volta não é o valor
 * gravado" sem ter feito nada.
 *
 * TETO: para TODA option do catálogo, sanitizar o padrão duas vezes dá o mesmo.
 * PISO: o mesmo vale para o valor QUE VEIO DO BANCO depois de uma gravação —
 * que é o caminho em que o defeito acontecia.
 */
$nome = 'options.sanitizador_idempotente';

bancada_limpa();
requisicao_nova();

foreach ( F3Base_Options::catalogo() as $option_idem => $declaracao_idem ) {
	$uma  = F3Base_Options::sanitizar( (string) $option_idem, $declaracao_idem['padrao'] );
	$duas = F3Base_Options::sanitizar( (string) $option_idem, $uma );

	afirmar(
		$nome,
		F3Base_Options::equivalente( $uma, $duas ),
		'teto do padrão: sanitizar o padrão de ' . $option_idem . ' duas vezes deu resultado diferente de sanitizar uma — a leitura de volta de gravar() vai acusar divergência numa gravação correta'
	);
}

/* PISO: o caminho real — gravar o padrão e sanitizar o que o banco devolveu. */
foreach ( F3Base_Options::catalogo() as $option_idem => $declaracao_idem ) {
	if ( 'segredo' === (string) $declaracao_idem['campo'] ) {
		continue;
	}

	$resultado_da_gravacao = F3Base_Options::gravar( (string) $option_idem, $declaracao_idem['padrao'], F3Base_Options::ORIGEM_PADRAO );

	afirmar(
		$nome,
		true === $resultado_da_gravacao['ok'],
		'piso do caminho real: gravar o PADRÃO de ' . $option_idem . ' fez a leitura de volta divergir — é exatamente o sintoma de um sanitizador que não é idempotente: ' . $resultado_da_gravacao['motivo']
	);
}

/* PISO da bancada: o defeito medido é reproduzível, e sem isso o teto aprovaria por acaso. */
$nao_idempotente = static function ( $bruto ) {
	$valor = is_array( $bruto ) ? $bruto : array();

	return array(
		'politica_privacidade' => isset( $valor['politica_privacidade'] )
			? F3Base_Options::sanitiza_item_llms( $valor['politica_privacidade'] )
			: array(),
	);
};

$uma_vez_da_1_0_19  = $nao_idempotente( array() );
$duas_vezes_da_1_0_19 = $nao_idempotente( $uma_vez_da_1_0_19 );

afirmar(
	$nome,
	! F3Base_Options::equivalente( $uma_vez_da_1_0_19, $duas_vezes_da_1_0_19 ),
	'piso: a bancada não reproduz o defeito medido — a forma antiga de politica_privacidade tem de dar resultado diferente na segunda passagem, e sem isso o teto acima aprovaria por acaso'
);

/* ---------- options.proveniencia_de_configuracao ---------- */

/*
 * A PROCEDÊNCIA RESPONDE "QUEM ESCOLHEU ESTE VALOR", e a pergunta não se aplica
 * a um carimbo de cron: ninguém ESCOLHEU que a última limpeza foi às 3h12. Três
 * defeitos moravam nisso.
 *
 * 1. TODA gravação registrava procedência — inclusive `f3base_atividade`, que a
 *    rota PÚBLICA do beacon de comportamento escreve a cada visita. A option de
 *    procedência era reescrita uma vez por visitante.
 * 2. Ela era escrita com `autoload = true`, e `update_option` sobre uma option
 *    autoloaded INVALIDA o `alloptions` do site inteiro. Somando com o item 1,
 *    isso é uma invalidação do cache de options por visitante.
 * 3. A entrada era RECONSTRUÍDA com `origem` e `em`, apagando `valor_hash` e
 *    `release` — as chaves com que o implantador sabe se a option continua sendo
 *    a que ele escreveu. Ele passava a tratar como "alterada à mão" uma chave que
 *    ele mesmo tinha gravado.
 *
 * TETO: gravação de CONFIGURAÇÃO continua carimbando origem e carimbo.
 * PISO: carimbo de atividade não escreve procedência nenhuma; a option não é
 * autoloaded; e as chaves do implantador sobrevivem quando o valor não mudou.
 */
$nome = 'options.proveniencia_de_configuracao';

bancada_limpa();
requisicao_nova();

F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-TETO000000', F3Base_Options::ORIGEM_IMPLANTADOR );

afirmar( $nome, F3Base_Options::ORIGEM_IMPLANTADOR === F3Base_Options::proveniencia( 'f3base_ga4_measurement_id' ), 'teto: a gravação de CONFIGURAÇÃO deixou de carimbar a procedência — a tela perde a resposta a "quem escreveu isto"' );
afirmar( $nome, F3Base_Options::carimbo( 'f3base_ga4_measurement_id' ) > 0, 'teto: a gravação de configuração não deixou carimbo de quando' );

$proveniencia_antes = get_option( F3Base_Options::OPTION_PROVENIENCIA, array() );

F3Base_Atividade::registrar( F3Base_Atividade::ULTIMO_COMPORTAMENTO, array( 'status' => 201 ) );

afirmar(
	$nome,
	F3Base_Options::equivalente( $proveniencia_antes, get_option( F3Base_Options::OPTION_PROVENIENCIA, array() ) ),
	'piso do carimbo: registrar ATIVIDADE reescreveu a option de procedência — é a rota pública do beacon fazendo isso uma vez por visitante, e carimbando "edição manual" sobre uma execução automática'
);

afirmar(
	$nome,
	in_array( 'f3base_atividade', F3Base_Options::estado_de_execucao(), true ),
	'piso da declaração: f3base_atividade não está declarada como estado de execução, e a exclusão da procedência volta a depender de alguém lembrar'
);

/* PISO do autoload: a option de procedência não pode viajar no alloptions. */
afirmar(
	$nome,
	false === ( $GLOBALS['f3b_bench']['autoload'][ F3Base_Options::OPTION_PROVENIENCIA ] ?? true ),
	'piso do autoload: a procedência foi gravada com autoload ligado — ela é lida por duas telas e por mais ninguém, e cada escrita dela invalida o cache de options do site inteiro'
);

/* PISO das chaves do implantador: elas sobrevivem quando o valor não mudou. */
$registro_do_implantador                              = get_option( F3Base_Options::OPTION_PROVENIENCIA, array() );
$registro_do_implantador['f3base_ga4_measurement_id'] = array(
	'origem'     => F3Base_Options::ORIGEM_IMPLANTADOR,
	'em'         => 1700000000,
	'valor_hash' => hash( 'sha256', (string) wp_json_encode( F3Base_Options::ler( 'f3base_ga4_measurement_id' ) ) ),
	'release'    => '1.7.4',
);

$GLOBALS['f3b_bench']['options'][ F3Base_Options::OPTION_PROVENIENCIA ] = $registro_do_implantador;

F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-TETO000000', F3Base_Options::ORIGEM_MANUAL );

$depois_da_regravacao = (array) get_option( F3Base_Options::OPTION_PROVENIENCIA, array() );

afirmar(
	$nome,
	'1.7.4' === (string) ( $depois_da_regravacao['f3base_ga4_measurement_id']['release'] ?? '' ),
	'piso do implantador: uma gravação que NÃO mudou o valor apagou a release que o implantador carimbou — e ele passa a tratar como alterada à mão uma chave que ele mesmo escreveu'
);
afirmar(
	$nome,
	'' !== (string) ( $depois_da_regravacao['f3base_ga4_measurement_id']['valor_hash'] ?? '' ),
	'piso do implantador: o valor_hash do implantador foi apagado por uma gravação que não mudou valor nenhum'
);

/* TETO da mudança: quando o valor MUDA, a marca do implantador sai — ela deixou de valer. */
F3Base_Options::gravar( 'f3base_ga4_measurement_id', 'G-OUTRO00000', F3Base_Options::ORIGEM_MANUAL );

$depois_da_mudanca = (array) get_option( F3Base_Options::OPTION_PROVENIENCIA, array() );

afirmar(
	$nome,
	! array_key_exists( 'valor_hash', (array) ( $depois_da_mudanca['f3base_ga4_measurement_id'] ?? array() ) ),
	'teto da mudança: o valor MUDOU e a marca do implantador ficou — preservar ali é afirmar que a chave continua sendo a que ele escreveu, e ela não é'
);

/* ---------- options.journal_corta_na_escrita ---------- */

/*
 * O JOURNAL DE ELIMINAÇÃO EXISTE PARA PROVAR O QUE FOI APAGADO E QUANDO, e ele
 * tinha dois defeitos que se somavam.
 *
 * O CORTE ACONTECIA NA LEITURA. `sanitiza_journal()` cortava em 500 entradas, e
 * o sanitizador roda também em `ler()`: a option continuava INTEIRA no banco e o
 * que a tela mostrava era um recorte dela. Pior, o corte descartava as MAIS
 * ANTIGAS — numa lista que existe para auditoria, a prova mais velha é
 * justamente a que alguém procuraria — e não deixava marca nenhuma.
 *
 * E O CAMPO DESCONHECIDO ERA PRESERVADO enquanto o docblock prometia descartar.
 * Preservar ali é abrir a porta para o conteúdo do lead voltar para dentro da
 * option que existe para provar que ele saiu.
 *
 * TETO: o campo desconhecido é descartado e os declarados ficam.
 * PISO: a leitura NÃO corta uma lista acima do teto; a escrita corta e deixa uma
 * entrada dizendo QUANTAS saíram e DESDE QUANDO; e a entrada de corte sobrevive
 * à leitura seguinte.
 */
$nome = 'options.journal_corta_na_escrita';

bancada_limpa();
requisicao_nova();

$teto_do_journal = F3Base_Options::teto_de_entradas( 'f3base_journal_eliminacao', 500 );

afirmar( $nome, $teto_do_journal > 10, 'teto: o journal não declara teto de entradas, e uma option sem teto cresce sem limite' );

/* PISO da leitura: uma lista acima do teto, plantada no banco, é lida INTEIRA. */
$journal_grande = array();

for ( $i = 0; $i < $teto_do_journal + 20; $i++ ) {
	$journal_grande[] = array(
		'regime'         => 'operacional',
		'identificador'  => 'lead-' . $i,
		'contagem'       => 1,
		'em'             => 1700000000 + $i,
		'operador'       => 'bancada',
		'reversivel_ate' => 0,
	);
}

$GLOBALS['f3b_bench']['options']['f3base_journal_eliminacao'] = $journal_grande;

afirmar(
	$nome,
	count( (array) F3Base_Options::ler( 'f3base_journal_eliminacao' ) ) === count( $journal_grande ),
	'piso da leitura: a LEITURA cortou o journal — a option continua inteira no banco e a tela mostra um recorte dela, sem dizer que é um recorte'
);

/* PISO da escrita: a escrita corta, e a entrada de corte diz quantas saíram e desde quando. */
$gravou_grande = F3Base_Options::gravar( 'f3base_journal_eliminacao', $journal_grande, F3Base_Options::ORIGEM_MANUAL );
$journal_lido  = (array) F3Base_Options::ler( 'f3base_journal_eliminacao' );

afirmar( $nome, true === $gravou_grande['ok'], 'piso da escrita: a leitura de volta divergiu depois do corte — a entrada de corte não sobreviveu ao sanitizador, e o corte voltou a ser silencioso' );
afirmar( $nome, count( $journal_lido ) <= $teto_do_journal, 'piso da escrita: a ESCRITA não cortou no teto declarado, e a option cresce sem limite' );

$entrada_de_corte = null;

foreach ( $journal_lido as $entrada_lida ) {
	if ( ! empty( $entrada_lida['corte'] ) ) {
		$entrada_de_corte = $entrada_lida;
		break;
	}
}

afirmar( $nome, is_array( $entrada_de_corte ), 'piso da escrita: o corte não deixou entrada nenhuma — cortar em silêncio uma lista de auditoria é apagar a prova mais velha sem registrar o apagamento' );
afirmar( $nome, (int) ( $entrada_de_corte['saiu'] ?? 0 ) > 0, 'piso da escrita: a entrada de corte não diz QUANTAS entradas saíram' );
afirmar( $nome, 1700000000 === (int) ( $entrada_de_corte['desde'] ?? 0 ), 'piso da escrita: a entrada de corte não diz DESDE QUANDO — sem os dois números, quem lê não sabe se está vendo tudo' );

/* TETO do descarte: campo desconhecido sai, campos declarados ficam. */
$journal_com_conteudo = F3Base_Options::sanitizar(
	'f3base_journal_eliminacao',
	array(
		array(
			'regime'        => 'titular',
			'identificador' => 'titular@exemplo.test',
			'contagem'      => 2,
			'em'            => 1700000500,
			'corpo_do_lead' => 'mensagem inteira que o titular escreveu',
		),
	)
);

afirmar( $nome, ! array_key_exists( 'corpo_do_lead', (array) ( $journal_com_conteudo[0] ?? array() ) ), 'teto do descarte: o journal PRESERVOU um campo desconhecido — é por essa porta que o conteúdo eliminado volta para a option que prova que ele saiu' );
afirmar( $nome, 'titular@exemplo.test' === (string) ( $journal_com_conteudo[0]['identificador'] ?? '' ), 'piso do descarte: descartar o desconhecido virou descartar a entrada' );

/* PISO da auditoria do canal: mesmo teto, mesmo corte registrado, e sem autoload. */
bancada_limpa();
requisicao_nova();

$teto_da_auditoria = F3Base_Options::teto_de_entradas( 'f3base_mcp_files_audit', 200 );
$auditoria_grande  = array();

for ( $i = 0; $i < $teto_da_auditoria + 5; $i++ ) {
	$auditoria_grande[] = array(
		'arquivo' => 'wp-content/themes/exemplo/style.css',
		'em'      => 1700000000 + $i,
	);
}

F3Base_Options::gravar( 'f3base_mcp_files_audit', $auditoria_grande, F3Base_Options::ORIGEM_MANUAL );

afirmar( $nome, count( (array) F3Base_Options::ler( 'f3base_mcp_files_audit' ) ) <= $teto_da_auditoria, 'piso da auditoria: a lista de auditoria do canal não tem teto na escrita, e ela cresce a cada escrita do agente' );
afirmar( $nome, false === ( $GLOBALS['f3b_bench']['autoload']['f3base_mcp_files_audit'] ?? true ), 'piso da auditoria: a lista de auditoria foi gravada com autoload ligado — uma lista que cresce sem parar, carregada em toda requisição do site' );


echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
