<?php
/**
 * Checagens funcionais: as funções puras do pacote, exercitadas de verdade.
 *
 * Rodam em subprocesso (`lib/sonda-funcional.php` e `lib/sonda-gravador.php`)
 * para não contaminar o processo que imprime os estados. Cada uma devolve
 * achados por nome de checagem; quem imprime e conta continua sendo `estado()`.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Roda uma sonda de subprocesso e devolve o veredito por checagem.
 *
 * @param string $sonda Caminho da sonda.
 * @param string $raiz  Raiz do pacote.
 * @return array<string,array{ok:bool,achados:array<int,string>,medidas:int}>
 */
function f3b_rodar_sonda( string $sonda, string $raiz ): array {
	$saida  = array();
	$codigo = 0;
	exec( 'php ' . escapeshellarg( $sonda ) . ' ' . escapeshellarg( $raiz ) . ' 2>&1', $saida, $codigo );

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) ) {
		return array(
			basename( $sonda, '.php' ) => array(
				'ok'      => false,
				'achados' => array( 'a sonda não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
				'medidas' => 0,
			),
		);
	}

	$saida_final = array();

	foreach ( $json as $nome => $dados ) {
		$achados = array_map( 'strval', (array) ( $dados['achados'] ?? array() ) );

		$saida_final[ (string) $nome ] = array(
			'ok'      => array() === $achados,
			'achados' => $achados,
			'medidas' => (int) ( $dados['medidas'] ?? 0 ),
		);
	}

	return $saida_final;
}

/**
 * Veredito de todas as checagens funcionais.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array<string,array{ok:bool,achados:array<int,string>,medidas:int}>
 */
function f3b_ck_funcionais( string $raiz, string $suite ): array {
	return array_merge(
		/*
		 * A sonda FUNCIONAL sobrou com duas checagens: as outras quarenta e três
		 * exercitavam classes do implantador, e saíram com ele.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-funcional.php', $raiz ),
		/*
		 * A sonda do SITE-CORE roda em processo próprio: ela monta um wpdb de
		 * mentira e roda o endpoint de leads e a cadência REAIS contra ele. O
		 * `$wpdb` global e as options em memória não podem vazar para nenhuma
		 * outra sonda.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-site-core.php', $raiz ),
		/*
		 * A sonda do CTA roda em processo próprio por um motivo que a do
		 * site-core torna visível: lá o piso do CTA depende de
		 * `WP_HTML_Tag_Processor` NÃO existir, e aqui a regra que
		 * preenche-quando-falta só existe quando ele existe. As duas bancadas
		 * não cabem no mesmo processo.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-tema.php', $raiz ),
		/*
		 * A sonda do CONTRATO DE NOMES roda em processo próprio pela herança da
		 * que a antecedeu: ela media a ferramenta de renomeação copiando a
		 * árvore do pacote três vezes. O que sobrou não copia nada, e o processo
		 * próprio deixou de custar.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-renomeacao.php', $raiz ),
		/*
		 * A sonda da MIGRAÇÃO monta um `wp-content/plugins/` de mentira em disco
		 * e declara `get_plugins()`, `is_plugin_active()` e `deactivate_plugins()`
		 * como funções globais: nenhuma outra bancada pode conviver com elas.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-migracao.php', $raiz ),
		/*
		 * A sonda do ARTEFATO lê o ZIP montado — o que se publica —, e não a
		 * árvore de origem. Ela roda depois do empacotamento, que é a primeira
		 * etapa do comando único.
		 */
		f3b_rodar_sonda( $suite . '/lib/sonda-bundle.php', $raiz )
	);
}

/**
 * Roda um modo da sonda de JavaScript sob o Node de verdade.
 *
 * @param string $modo  Modo da sonda.
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_rodar_js( string $modo, string $raiz, string $suite ): array {
	$saida  = array();
	$codigo = 0;
	exec(
		'node ' . escapeshellarg( $suite . '/checagens/js.mjs' ) . ' ' . escapeshellarg( $modo ) . ' ' . escapeshellarg( $raiz ) . ' 2>&1',
		$saida,
		$codigo
	);

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) || ! isset( $json['achados'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'sonda js.mjs (modo ' . $modo . ') não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', $json['achados'] ),
	);
}



/**
 * O CORTE do cliente de leads, na unidade que o servidor publica.
 *
 * A função pura sai do arquivo REAL, extraída dele em tempo de execução, e a
 * sonda mede a MESMA unidade dos dois lados: o defeito medido na 1.0.17 era o
 * servidor contando bytes e o cliente contando unidades UTF-16, com o mesmo
 * número publicado para os dois.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_limite_do_cliente( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'leads', $raiz, $suite );
}

/**
 * A CONVERSÃO DO CLIQUE, medida no cliente REAL sob o Node.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_conversao( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'conversao', $raiz, $suite );
}


/**
 * A INSTRUMENTAÇÃO DE COMPORTAMENTO, medida no `dataLayer`.
 *
 * A bancada roda o carregador REAL contra uma plataforma de mentira —
 * `IntersectionObserver`, `PerformanceObserver`, rolagem, clique, erro e
 * ocultamento — e lê o que a conta de medição receberia. O piso é o FALSO
 * POSITIVO: duplo clique, triplo clique, cliques espalhados e erro de terceiro
 * não podem produzir evento nenhum.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_comportamento( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'comportamento', $raiz, $suite );
}

/**
 * `js.resumo_da_sessao` — o SEGUNDO DESTINO do comportamento, medido no envio.
 *
 * A bancada roda o carregador REAL contra a plataforma de mentira e lê o corpo
 * que o `sendBeacon` levaria: é exatamente o que o servidor receberia. Os pisos
 * são as recusas — sem consentimento nada sai, nenhum identificador de visitante
 * é gravado, o caminho vai sem a query que a URL da bancada tem de propósito,
 * nenhum nome de evento declarado viaja no cliente, a aba que vai e volta manda
 * uma vez, e sem `sendBeacon` a sessão se perde sem levar a instrumentação junto.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_resumo( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'resumo', $raiz, $suite );
}

/**
 * `js.ciclo_de_vida_da_pagina` — cada métrica contada UMA vez, na saída REAL.
 *
 * Sair de uma página não é um evento: numa navegação normal o navegador emite
 * `visibilitychange` para hidden E `pagehide`, no mesmo carregamento. Até esta
 * release a bancada só sabia ocultar — o caso comum, os dois eventos juntos,
 * nunca foi exercitado, e é exatamente ele que expõe um relator sem trava.
 *
 * As quatro formas de saída estão medidas, cada uma com e sem interação do
 * visitante: sem interação não há INP, sobra folga sob o teto por página, e é
 * essa folga que torna a repetição VISÍVEL — com as quatro métricas o próprio
 * teto absorveria o segundo relato e a trava removida passaria despercebida.
 *
 * A profundidade de rolagem entra aqui pelo mesmo motivo: o marco sai da altura
 * DAQUELA página, e a página que cresce depois de carregar não pode ter os
 * marcos queimados antes de as imagens entrarem.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_ciclo( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'ciclo', $raiz, $suite );
}

/**
 * `js.sessao_com_releitura` — o ciclo que o usuário descreveu, medido.
 *
 * Carrega, desce até o fim, volta ao topo, desce de novo, sai. Até a 1.1.1 o
 * marco alcançado ficava marcado para o resto do carregamento e a segunda
 * descida não produzia nada: a pergunta "ela releu?" não tinha como ser
 * respondida porque o dado não existia.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_releitura( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'releitura', $raiz, $suite );
}

/**
 * `js.ordem_do_consentimento` — a ORDEM DE EXECUÇÃO, e não a string do atributo.
 *
 * A bancada roda os DOIS clientes reais contra um escalonador que é o modelo da
 * especificação — bloqueante na posição do parser, `defer` depois do parse e na
 * ordem do documento, `async` sem ordem com nada — e lê uma LINHA DO TEMPO. A
 * pergunta medida é a única que importa: o `consent default` chegou ao
 * `dataLayer` antes de o `gtag.js` ser pedido?
 *
 * Os pisos: inverter a decisão — `defer` no modo de negativa por padrão — tem de
 * aparecer como o primeiro `page_view` do emissor concorrente saindo ANTES do
 * `denied`; e o carregador rodando antes do consentimento tem de aparecer como
 * `gtag.js` pedido sem `default` nenhum no `dataLayer`.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_ordem( string $raiz, string $suite ): array {
	return f3b_rodar_js( 'ordem', $raiz, $suite );
}

/**
 * `navegador.comportamento_real` — o cliente ENTREGUE, num Chromium de verdade.
 *
 * POR QUE ESTA CHECAGEM EXISTE, e a resposta é uma contagem de releases. Quatro
 * seguidas a bancada aprovou o que o navegador reprovou:
 *
 * - **1.3.3** — o retorno intermediário do observador. A bancada disparava
 *   `{ isIntersecting: true|false }` à mão, sem razão de interseção; o navegador
 *   entrega uma RAZÃO e avisa a cada travessia de linha declarada, inclusive na
 *   queda abaixo dela com o alvo ainda sobreposto. A bancada nunca produzia esse
 *   retorno, e aprovou um rearme que o navegador quase nunca alcançava: 80
 *   linhas em produção, todas com `ocorrencia = 1`.
 * - **1.3.4** — o contador entre carregamentos, durável de um lado e volátil do
 *   outro; a bancada media um carregamento só e não via o buraco.
 * - **1.3.5** — o envio confirmando ENFILEIRAMENTO em vez de ENTREGA, com três
 *   lacunas listadas na própria release.
 * - **1.3.6** — esta, com a banda da seção.
 *
 * A bancada SIMULA `IntersectionObserver`; o navegador TEM um. Nenhum comentário
 * conserta essa diferença, e nenhuma quantidade de asserção sobre uma simulação
 * prova o que a implementação de verdade faz.
 *
 * O QUE ELA MEDE, e cada peça responde por uma coisa:
 *
 * - as sequências de ocorrência por gatilho nos DOIS percursos — o longo, que é
 *   a leitura inteira, e o curto, que é o percurso do relatório do usuário;
 * - zero erro de página e zero acionamento cortado;
 * - que o lote CHEGOU ao servidor, e não só que o cliente o despachou.
 *
 * O QUE ELA EXERCITA É O ARQUIVO ENTREGUE — o de `dist/entregue/`, sem
 * comentário —, que é o que o visitante baixa. E a declaração publicada ao
 * navegador é GERADA do TSV na hora, pelo mesmo leitor das bancadas: uma cópia
 * versionada diverge da declaração na primeira edição, e a sonda passaria a
 * medir um limiar que o site não usa mais.
 *
 * O PISO É A ASSIMETRIA DA 1.3.3 PLANTADA NO CLIENTE. Se a sonda calar sobre o
 * defeito que a bancada não sabia ver, ela não vale o que custa.
 *
 * SEM CHROMIUM ELA FECHA N/A COM A CONDIÇÃO DECLARADA, nunca OK: um ambiente sem
 * navegador não é um pacote aprovado, e uma linha verde sobre uma medição que
 * não aconteceu é o instrumento mentindo com a melhor cara possível.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>,medidas:int,ambiente:string,condicao:string}
 */
function f3b_ck_navegador_real( string $raiz, string $suite ): array {
	$ausente = static function ( string $condicao ): array {
		return array(
			'ok'       => false,
			'achados'  => array(),
			'medidas'  => 0,
			'ambiente' => 'ausente',
			'condicao' => $condicao,
		);
	};

	$chromium = f3b_chromium_declarado( $suite );

	if ( '' === $chromium ) {
		return $ausente(
			'não há Chromium neste ambiente. A sonda dirige um navegador de verdade porque a bancada SIMULA IntersectionObserver e o navegador TEM um — foi essa diferença que deixou passar a 1.3.3, a 1.3.4 e a 1.3.5. '
			. 'Os caminhos procurados estão declarados em suite/sonda-navegador/sonda.mjs (CHROMIUM_CANDIDATOS). Instalar o navegador faz a checagem passar a medir na execução seguinte, sem release'
		);
	}

	$verifica = array();
	$codigo   = 0;
	exec( 'node -e ' . escapeshellarg( 'require("playwright")' ) . ' 2>&1', $verifica, $codigo );

	if ( 0 !== $codigo ) {
		return $ausente(
			'o Chromium existe em ' . $chromium . ', mas o módulo playwright não resolve neste Node: ' . f3b_amostra( $verifica, 1 )
			. '. Sem ele não há como dirigir o navegador, e uma sonda que não dirige nada não pode fechar OK'
		);
	}

	$achados = array();
	$piso    = f3b_sonda_navegador( $raiz, $suite, $chromium, false );

	if ( isset( $piso['falha'] ) ) {
		return array(
			'ok'       => false,
			'achados'  => array( 'a sonda de navegador não devolveu veredito analisável: ' . $piso['falha'] ),
			'medidas'  => 1,
			'ambiente' => 'presente',
			'condicao' => '',
		);
	}

	/*
	 * AS SEQUÊNCIAS ESPERADAS, e elas são geometria — não sorteio. A página tem
	 * quatro seções de uma tela cada; os percursos são declarados em PIXELS
	 * exatos da faixa rolável, e por isso a razão de interseção de cada seção em
	 * cada parada é a mesma em toda execução.
	 *
	 * NO PERCURSO CURTO, `abertura` e `pecas` saem com UMA ocorrência, e isso
	 * está CERTO: o visitante subiu três passos perto do fim e nunca voltou até
	 * elas. Ausência de reentrada não é perda — o que provaria perda seria
	 * `cortadas` acima de zero, e ela é medida logo abaixo.
	 */
	$esperado = array(
		'longo' => array(
			'interseccao|abertura'      => array( 1, 2 ),
			'interseccao|pecas'         => array( 1, 2, 3 ),
			'interseccao|comando-unico' => array( 1, 2, 3 ),
			'interseccao|faq'           => array( 1, 2 ),
			'rolagem|25'                => array( 1, 2 ),
			'rolagem|50'                => array( 1, 2 ),
			'rolagem|75'                => array( 1, 2 ),
			'rolagem|90'                => array( 1, 2 ),
			'pagina|'                   => array( 1 ),
		),
		'curto' => array(
			'interseccao|abertura'      => array( 1 ),
			'interseccao|pecas'         => array( 1 ),
			'interseccao|comando-unico' => array( 1, 2 ),
			'interseccao|faq'           => array( 1, 2 ),
			'rolagem|25'                => array( 1 ),
			'rolagem|50'                => array( 1 ),
			'rolagem|75'                => array( 1 ),
			'rolagem|90'                => array( 1, 2 ),
			'pagina|'                   => array( 1 ),
		),
	);

	foreach ( $esperado as $percurso => $sequencias ) {
		$medido = $piso[ $percurso ] ?? null;

		if ( ! is_array( $medido ) ) {
			$achados[] = 'o percurso ' . $percurso . ' não produziu medição nenhuma';
			continue;
		}

		foreach ( (array) $medido['erros'] as $erro ) {
			$achados[] = 'teto do percurso ' . $percurso . ': erro de página no navegador — ' . $erro;
		}

		if ( (int) $medido['lotes'] < 1 ) {
			$achados[] = 'teto do percurso ' . $percurso . ': nenhum lote CHEGOU ao servidor. Despachar não é entregar, e a sonda mede o que o servidor recebeu';
		}

		foreach ( (array) $medido['cortadas'] as $cortadas ) {
			if ( (int) $cortadas > 0 ) {
				$achados[] = 'piso do corte no navegador, percurso ' . $percurso . ': ' . (int) $cortadas . ' acionamento(s) cortado(s). O corte é do orçamento da visita e não deveria acontecer numa leitura normal — quando ele acontece, a sequência de ocorrências deixa de responder pelo que o visitante fez';
			}
		}

		foreach ( $sequencias as $chave => $vezes ) {
			$saiu = array_map( 'intval', (array) ( $medido['ocorrencias'][ $chave ] ?? array() ) );

			if ( $saiu !== $vezes ) {
				$achados[] = 'teto da sequência, percurso ' . $percurso . ', ' . $chave . ': ocorrências ' . f3b_lista_em_texto( $saiu )
					. ' contra ' . f3b_lista_em_texto( $vezes ) . ' esperadas';
			}
		}
	}

	/*
	 * O PISO: a assimetria da 1.3.3 plantada no cliente ENTREGUE. A sonda tem de
	 * ACUSAR. Se ela calar sobre o defeito que a bancada não media, ela é uma
	 * segunda bancada com um navegador dentro.
	 */
	$mutante = f3b_sonda_navegador( $raiz, $suite, $chromium, true );

	if ( isset( $mutante['nao-plantou'] ) ) {
		$achados[] = 'piso da assimetria: não foi possível plantar a assimetria da 1.3.3 no cliente entregue — ' . $mutante['nao-plantou']
			. '. Ou a decisão do observador mudou de forma e o piso deixou de provar o que promete, ou ela sumiu, e nesse caso os tetos acima é que deveriam ter acusado';
	} elseif ( isset( $mutante['falha'] ) ) {
		$achados[] = 'piso da assimetria: a sonda de navegador não rodou contra o cliente com a assimetria plantada: ' . $mutante['falha'];
	} else {
		$preso = array_map( 'intval', (array) ( $mutante['curto']['ocorrencias']['interseccao|faq'] ?? array() ) );

		if ( array( 1 ) !== $preso ) {
			$achados[] = 'piso da assimetria no navegador: com a saída decidida por isIntersecting e o `0` ainda na lista de faixas, '
				. 'o bloco "faq" saiu do percurso curto com ' . f3b_lista_em_texto( $preso ) . ' e deveria ter ficado preso em [1]. '
				. 'A razão dele desce a 0,1 sem nunca zerar, e é exatamente aí que a assimetria prende o bloco em uma ocorrência só — '
				. 'uma sonda que não acusa isso não mede o que a bancada não media, e não vale o que custa';
		}
	}

	return array(
		'ok'       => array() === $achados,
		'achados'  => $achados,
		'medidas'  => count( $esperado ),
		'ambiente' => 'presente',
		'condicao' => '',
	);
}

/**
 * O Chromium declarado pela sonda, se ele existir neste ambiente.
 *
 * A LISTA MORA NA SONDA, e é lida daqui — nunca escrita duas vezes. A sonda
 * precisa dela para rodar à mão; esta função precisa dela para decidir entre
 * medir e fechar N/A. Duas listas divergiriam, e a divergência apareceria como
 * um N/A sobre um navegador que está instalado.
 *
 * @param string $suite Diretório da suíte.
 * @return string Caminho do executável, ou vazio.
 */
function f3b_chromium_declarado( string $suite ): string {
	$declarado = (string) getenv( 'F3BASE_CHROMIUM' );
	if ( '' !== $declarado && is_file( $declarado ) && is_executable( $declarado ) ) { return $declarado; }
	$fonte = (string) @file_get_contents( $suite . '/sonda-navegador/sonda.mjs' );

	if ( 1 !== preg_match( '/CHROMIUM_CANDIDATOS\s*=\s*\[(.*?)\]/s', $fonte, $achou ) ) {
		return '';
	}

	if ( 0 === preg_match_all( "/'([^']+)'/", $achou[1], $caminhos ) ) {
		return '';
	}

	foreach ( $caminhos[1] as $caminho ) {
		if ( is_file( $caminho ) && is_executable( $caminho ) ) {
			return $caminho;
		}
	}

	return '';
}

/**
 * Monta o `pub/`, sobe o servidor, roda a sonda e devolve o JSON dela.
 *
 * @param string $raiz     Raiz do pacote.
 * @param string $suite    Diretório da suíte.
 * @param string $chromium Executável do navegador.
 * @param bool   $plantar  Plantar a assimetria da 1.3.3 no cliente entregue.
 * @return array<string,mixed>
 */
function f3b_sonda_navegador( string $raiz, string $suite, string $chromium, bool $plantar ): array {
	$pub = sys_get_temp_dir() . '/f3base-sonda-' . ( $plantar ? 'mutante' : 'pacote' ) . '-' . getmypid();

	if ( ! is_dir( $pub ) && ! mkdir( $pub, 0700, true ) && ! is_dir( $pub ) ) {
		return array( 'falha' => 'não foi possível preparar ' . $pub );
	}

	/*
	 * O CLIENTE É O ENTREGUE. Se `dist/entregue/` não existir — clone que ainda
	 * não empacotou —, a fonte responde: a ausência do entregue é achado de
	 * `pacote.js_entregue_sem_comentario`, e não desta linha.
	 */
	$entregue = $raiz . '/dist/entregue/base-site-core-fator3/assets/f3base-tracking.js';
	$alvo     = is_file( $entregue ) ? $entregue : $raiz . '/fontes/plugin/assets/f3base-tracking.js';
	$cliente  = (string) @file_get_contents( $alvo );

	if ( '' === $cliente ) {
		return array( 'falha' => 'cliente de comportamento ausente em ' . $alvo );
	}

	if ( $plantar ) {
		/*
		 * O DEFEITO PLANTADO É A SAÍDA POR `isIntersecting` COM O `0` NA LISTA DE
		 * FAIXAS, e a lista NÃO é trocada — a precisão aqui é o piso inteiro.
		 *
		 * Medido em Chromium 1194: `isIntersecting` NÃO é sobreposição
		 * geométrica, é o ÍNDICE DE FAIXA. Com `threshold: 0.5` sozinho, a razão
		 * 0,2 chega com `isIntersecting: false`, e decidir a saída por ele dá o
		 * MESMO resultado de decidir por `razao < visivel` — trocar o threshold
		 * junto não plantaria defeito nenhum. Com o `0` na lista, qualquer
		 * sobreposição faz `isIntersecting` verdadeiro, a linha de saída vira a
		 * razão ZERO, e o bloco que nunca sai inteiro da tela não rearma nunca.
		 * É esse o defeito da 1.3.3, e é esse que a sonda tem de acusar.
		 */
		$assimetrico = str_replace(
			array(
				'if (!entradas[j].isIntersecting || razao < saida) {',
				"\t\t\t\tif (razao < visivel) {\n\t\t\t\t\tcontinue;\n\t\t\t\t}\n\n",
			),
			array(
				'if (!entradas[j].isIntersecting) {',
				'',
			),
			$cliente
		);

		if ( $assimetrico === $cliente || str_contains( $assimetrico, 'razao < saida' ) || str_contains( $assimetrico, 'razao < visivel' ) ) {
			return array( 'nao-plantou' => 'as duas peças da decisão do observador não foram encontradas no cliente entregue' );
		}

		$cliente = $assimetrico;
	}

	file_put_contents( $pub . '/f3base-tracking.js', $cliente );

	$declaracao = array();
	$codigo     = 0;
	exec(
		'node ' . escapeshellarg( $suite . '/checagens/js.mjs' ) . ' eventos ' . escapeshellarg( $raiz ) . ' 2>/dev/null',
		$declaracao,
		$codigo
	);

	$eventos = json_decode( implode( '', $declaracao ), true );

	if ( ! is_array( $eventos ) || array() === $eventos ) {
		return array( 'falha' => 'a declaração de eventos não pôde ser GERADA do TSV (js.mjs eventos)' );
	}

	$dados = array(
		'caminho'       => 'nenhum',
		'comportamento' => array(
			'eventos'      => $eventos,
			'prefixoSecao' => f3b_prefixo_de_secao( $raiz ),
		),
		'resumo'        => array(
			'ativo'        => true,
			'endpoint'     => '/wp-json/f3base/v1/comportamento',
			'esquecer'     => '/wp-json/f3base/v1/comportamento/esquecer',
			'token'        => 'token-da-sonda',
			'maximo'       => 40,
			'maximoLog'    => 180,
			'maximoVisita' => 300,
			'maximoBytes'  => 12288,
			/*
			 * A POLÍTICA É PUBLICADA PELO SERVIDOR, e o APELIDO SEGUE O PORTÃO —
			 * nunca o banner. O `aviso` fica aqui DESLIGADO de propósito: ele é o
			 * campo que uma versão anterior deste cliente exigia ligado para o
			 * apelido poder nascer no modo pré-aprovado, e com ele em falso o
			 * navegador de verdade responde à pergunta que a bancada não responde
			 * — o registro detalhado existe sem banner nenhum. Se aquela regra
			 * voltar, esta sonda para de receber lote e a linha cai na hora.
			 */
			'politica'     => 'pre-aprovado',
			'aviso'        => false,
		),
	);

	file_put_contents( $pub . '/dados.json', (string) json_encode( $dados ) );

	$porta = f3b_porta_livre();

	$servidor = proc_open(
		'exec node ' . escapeshellarg( $suite . '/sonda-navegador/servidor.mjs' ) . ' ' . escapeshellarg( $pub ) . ' ' . (string) $porta,
		array( 1 => array( 'file', '/dev/null', 'w' ), 2 => array( 'file', '/dev/null', 'w' ) ),
		$canos
	);

	if ( ! is_resource( $servidor ) ) {
		return array( 'falha' => 'não foi possível subir o servidor da sonda' );
	}

	$pronto = false;

	for ( $tentativa = 0; $tentativa < 50; $tentativa++ ) {
		usleep( 100000 );
		$teste = @fsockopen( '127.0.0.1', $porta, $erro_n, $erro_s, 0.2 );

		if ( false !== $teste ) {
			fclose( $teste );
			$pronto = true;
			break;
		}
	}

	if ( ! $pronto ) {
		proc_terminate( $servidor );
		proc_close( $servidor );

		return array( 'falha' => 'o servidor da sonda não respondeu na porta ' . $porta );
	}

	$saida  = array();
	$codigo = 0;
	exec(
		'node ' . escapeshellarg( $suite . '/sonda-navegador/sonda.mjs' ) . ' ' . (string) $porta . ' ' . escapeshellarg( $chromium ) . ' 2>/dev/null',
		$saida,
		$codigo
	);

	proc_terminate( $servidor );
	proc_close( $servidor );

	$json = json_decode( implode( "\n", $saida ), true );

	f3b_apagar( $pub );

	if ( ! is_array( $json ) ) {
		return array( 'falha' => 'saída não analisável da sonda: ' . f3b_amostra( $saida, 2 ) );
	}

	return $json;
}

/**
 * O PREFIXO DE CLASSE DAS SEÇÕES, lido da constante do módulo que o publica.
 *
 * Ele sai de `F3Base_Modulo_Tracking::PREFIXO_SECAO`, que é a mesma constante
 * que o site publica ao navegador em `prefixoSecao`. Escrevê-lo aqui faria a
 * página da sonda carregar uma classe que o tema não carimba, e o observador
 * não receberia alvo nenhum — com todas as linhas em OK, porque uma página sem
 * seção nomeada não emite evento de seção e não contradiz nada.
 *
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_prefixo_de_secao( string $raiz ): string {
	$fonte = (string) @file_get_contents( $raiz . '/fontes/plugin/includes/class-f3base-modulo-tracking.php' );

	return 1 === preg_match( "/const\s+PREFIXO_SECAO\s*=\s*'([^']+)'/", $fonte, $achou ) ? $achou[1] : '';
}

/**
 * Uma porta TCP livre, para que duas rodadas simultâneas não briguem.
 *
 * @return int
 */
function f3b_porta_livre(): int {
	$socket = @stream_socket_server( 'tcp://127.0.0.1:0', $erro_n, $erro_s );

	if ( false === $socket ) {
		return 8731;
	}

	$nome = (string) stream_socket_get_name( $socket, false );
	fclose( $socket );

	return (int) substr( $nome, strrpos( $nome, ':' ) + 1 );
}

/**
 * JSON compacto de uma lista de inteiros, para achado legível.
 *
 * @param array<int,int> $lista Lista.
 * @return string
 */
function f3b_lista_em_texto( array $lista ): string {
	return '[' . implode( ',', array_map( 'strval', $lista ) ) . ']';
}

/* -------------------------------------------------------------------------
 * BANCADA WORDPRESS REAL — a etapa que carrega o núcleo.
 *
 * Tudo acima nesta suíte mede o pacote SEM WordPress: análise da árvore, funções
 * puras em subprocesso, o cliente entregue num Chromium. A bancada é a única
 * etapa que instala o zip desta rodada num WordPress de verdade e pergunta ao
 * produto o que ele faz. O runner não sabe montar nada disso: ele chama
 * `suite/bancada-wp/bancada.sh`, lê uma linha JSON por veredito e emite cada uma
 * por `estado()` — o contador continua morando lá, e nenhuma linha desta etapa
 * é impressa por outro caminho.
 * ---------------------------------------------------------------------- */

/**
 * OS PASSOS DECLARADOS DA BANCADA, lidos da tabela que também declara o piso.
 *
 * Fonte única: `suite/bancada-wp/pisos.tsv`. O runner precisa da lista para
 * saber o que esperar emitido — e para fechar N/A em CADA passo quando o
 * interruptor desliga a etapa. Uma segunda lista escrita à mão aqui divergiria
 * da tabela no primeiro passo acrescentado.
 *
 * @param string $suite Diretório da suíte.
 * @return array<string,string> Nome da checagem => situação declarada do piso.
 */
function f3b_bancada_passos( string $suite ): array {
	$saida = array();

	foreach ( f3b_tsv( $suite . '/bancada-wp/pisos.tsv' ) as $linha ) {
		$passo = trim( $linha[0] ?? '' );

		if ( '' === $passo || count( $linha ) < 3 ) {
			continue;
		}

		$saida[ 'wp.' . $passo ] = trim( $linha[2] ?? '' );
	}

	return $saida;
}

/**
 * A CONDIÇÃO DECLARADA que desliga a etapa da bancada.
 *
 * Existe como função para que a frase saia idêntica na linha do ambiente e na
 * de cada passo — e para que ela seja uma CONDIÇÃO, e não uma desculpa: quem
 * desligou foi o operador, com uma variável de ambiente, e o relatório diz isso
 * com todas as letras em vez de mostrar verde sobre medição que não houve.
 *
 * @return string Vazio quando a etapa deve rodar.
 */
function f3b_bancada_desligada(): string {
	if ( '1' !== (string) getenv( 'F3BASE_SEM_BANCADA' ) ) {
		return '';
	}

	return 'F3BASE_SEM_BANCADA=1 no ambiente desta rodada: a etapa da bancada WordPress foi desligada por quem chamou o comando. '
		. 'Nada foi montado, nada foi instalado e nada foi medido — e por isso nenhuma destas linhas pode sair OK. '
		. 'Rodar sem o interruptor volta a medi-las';
}

/**
 * Roda a bancada e devolve os vereditos que ela produziu.
 *
 * SUBPROCESSO QUE NÃO RODOU NÃO ABSOLVE NINGUÉM: script ausente, saída ilegível
 * ou passo declarado que não voltou fecham BLOCKED com o recurso nomeado. É a
 * mesma regra da sonda de fases e pela mesma razão.
 *
 * @param string $suite Diretório da suíte.
 * @param string $zip   Zip do plugin que ESTA rodada montou.
 * @param string $modo  `rodada` ou `piso`.
 * @param string $alvo  Raiz do pacote, quando o modo é `piso`.
 * @return array{linhas:array<int,array<string,string>>,erro:string}
 */
function f3b_rodar_bancada( string $suite, string $zip, string $modo = 'rodada', string $alvo = '' ): array {
	$script = $suite . '/bancada-wp/bancada.sh';

	if ( ! is_file( $script ) ) {
		return array(
			'linhas' => array(),
			'erro'   => 'o roteiro da bancada não existe: ' . $script,
		);
	}

	if ( 'rodada' === $modo && ! is_file( $zip ) ) {
		return array(
			'linhas' => array(),
			'erro'   => 'o zip do plugin desta rodada não existe: ' . ( '' === $zip ? '(não montado)' : $zip ),
		);
	}

	$argumento = 'rodada' === $modo ? $zip : $alvo;
	$saida     = array();
	$codigo    = 0;

	exec(
		'bash ' . escapeshellarg( $script ) . ' ' . escapeshellarg( $modo ) . ' ' . escapeshellarg( $argumento ) . ' 2>/dev/null',
		$saida,
		$codigo
	);

	$linhas = array();

	foreach ( $saida as $bruta ) {
		$json = json_decode( (string) $bruta, true );

		if ( ! is_array( $json ) || ! isset( $json['estado'], $json['nome'], $json['mensagem'] ) ) {
			continue;
		}

		$linhas[] = array(
			'estado'   => (string) $json['estado'],
			'nome'     => (string) $json['nome'],
			'mensagem' => (string) $json['mensagem'],
		);
	}

	if ( array() === $linhas ) {
		return array(
			'linhas' => array(),
			'erro'   => 'a bancada terminou com código ' . $codigo . ' sem devolver veredito analisável: '
				. f3b_amostra( array_slice( $saida, -3 ), 3 ),
		);
	}

	return array(
		'linhas' => $linhas,
		'erro'   => '',
	);
}
