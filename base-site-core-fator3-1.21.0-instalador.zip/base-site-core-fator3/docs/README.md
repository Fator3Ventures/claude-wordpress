# Fator3 Site Core 1.21.0

Instale **base-site-core-fator3-1.21.0-instalador.zip** em WordPress novo ou atualize a partir da **1.20.0**. Não há migração de bases anteriores nem procedimento de downgrade. O ZIP de fontes é para desenvolvimento, não para instalação pelo WordPress.

Esta versão corrige o salvamento de campos intocados e o erro fatal da aba técnica com prova de tokens; divide Medição e anúncios em seis áreas; amplia o cookie de teste para 365 dias. Acrescenta recuperação explícita, diagnóstico de tarefas, lacunas persistidas do Search Console, aparelho e apresentação comum da jornada dos contatos. Atualiza identificação, mapeamento, notas, alertas e retomada do Pipedrive.

Contrato Core **5.1.0**, schema leads **6**, política MCP **1**. Histórico, listas vazias e preferências existentes são preservados. Integrações externas continuam sujeitas à configuração e autorização do site.

Leia [RELEASE-1.21.md](RELEASE-1.21.md), [DOCUMENTACAO.md](DOCUMENTACAO.md) e [VALIDACAO.md](VALIDACAO.md). Toda a documentação acompanha o plugin em `docs/`, acessível por arquivo ou pela ability autenticada `f3base/documentacao-ler`. Relatórios para MCP e MCP Google estão incluídos. Nenhum desses plugins, tema ou implantador foi alterado.
