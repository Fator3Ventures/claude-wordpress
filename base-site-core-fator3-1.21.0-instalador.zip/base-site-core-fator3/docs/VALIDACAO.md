# Validação — Fator3 Site Core 1.21.0

06/10/2026. Base: instalação nova ou atualização da 1.20.0. WordPress 7.1.2, PHP 8.3.6, MariaDB 10.11.14, Chrome Headless Shell 154.0.8037.97 e Playwright, em laboratório isolado. Somente dados sintéticos. APIs externas e e-mails interceptados; nenhum envio real, alteração na frota ou teste em korvena.net.br.

## Evidência desta versão

| Conjunto | Verificações/casos registrados | Arquivo no fonte |
|---|---:|---|
| regressoes | 41 | `suite/versao-1210/evidencias/regressoes.json` |
| ui | 14 | `suite/versao-1210/evidencias/ui.json` |
| tecnica | 4 | `suite/versao-1210/evidencias/tecnica.json` |
| operacao-jornada | 12 | `suite/versao-1210/evidencias/operacao-jornada.json` |
| crm | 14 | `suite/versao-1210/evidencias/crm.json` |
| crm-adicional | 12 | `suite/versao-1210/evidencias/crm-adicional.json` |
| apresentacao-ui | 5 | `suite/versao-1210/evidencias/apresentacao-ui.json` |
| avisos | 4 | `suite/versao-1210/evidencias/avisos.json` |
| gsc-opcional | 9 | `suite/versao-1210/evidencias/gsc-opcional.json` |
| google-sdk | 12 | `suite/versao-1210/evidencias/google-sdk.json` |
| mcp | 15 | `suite/versao-1210/evidencias/mcp.json` |
| documentacao | 98 | `suite/versao-1210/evidencias/documentacao.json` |
| upgrade | 8 | `suite/versao-1210/evidencias/upgrade.json` |

As contagens são verificações/casos, não cenários independentes nem percentual de cobertura. Documentação compara 90 input schemas com o registro real e confere acesso autenticado. UI envia o formulário real até o redirecionamento, nas seis áreas, com JavaScript ligado/desligado. Atualização prepara a base real 1.20.0 e confere preservação de GTM, lista vazia e contato histórico, classificação e idempotência.

Concorrência: três processos PHP reais disputam a mesma ocorrência no banco; um reivindica e dois ficam ocupados, sem erro SQL. As constantes de origem cli/http_cron/manual são controladas no fixture; esse teste não é execução de crontab de hospedagem nem comando WP-CLI nativo. Sintaxe de 153 arquivos PHP e 26 JavaScript e reprodução de nove assets minificados conferidas. As telas foram vistas em 1440 e 390 px. Os tokens do ensaio técnico são fixtures locais de cabecalhos_comprovados, não sondas bem-sucedidas de um site público.

MCP 0.15.0 e Google 0.7.0 reais foram ativados somente na bancada e passaram os testes de convivência com rede simulada. A extensão effective_status de Google 0.7.1 foi simulada conforme contrato; não se declara homologação do pacote futuro. Detalhes/hashes em IMPACTO-1.21-MCP.md e IMPACTO-1.21-GOOGLE.md.

## Limites que permanecem para homologação

Não houve acesso ao Site-Teste ou à conta Pipedrive/Google real. Falta conferir catálogos, IDs e entrega efetiva nas contas de destino; SMTP simulado não prova recebimento. Medir início de processamento em até 60 segundos depende de cron/loopback aptos; agenda e despacho são expostos separadamente. A observação de sete dias sem Duplicate entry nos 14 sites é acompanhamento após implantação. A abertura da aba técnica e seu error.log na hospedagem real permanecem verificação do dono.

Os casos executados cobrem os riscos centrais, sem afirmar que toda permutação da matriz de planejamento foi ensaiada. Drenagem conjunta com futura versão Google/MCP, falta real de espaço/disco, todos os cenários de interrupção, corrida distribuída entre instalações e comportamento de provedores reais não são certificados pela bancada. Não há garantia de unicidade distribuída de pessoas nem compare-and-swap remoto no Pipedrive.

Falhas de fixtures encontradas durante desenvolvimento não integram aprovação final. Evidências de sintaxe, execução final e intervalo de logs acompanham a suite; não se afirma que o arquivo histórico completo de log esteja vazio.
