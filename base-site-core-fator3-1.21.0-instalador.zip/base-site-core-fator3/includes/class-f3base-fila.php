<?php
/** Primitivas comuns; cada destino conserva seu contrato, retenção e estados. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Fila {
    private static array $acordar=array();
    /** O adaptador fornece SQL fechado e valores; retorno estrito evita duas posses. */
    public static function reservar_condicional(string $sql,array $args): bool {global $wpdb;return $wpdb->query($wpdb->prepare($sql,...$args))===1;}
    public static function possui(?array $row,string $coluna,string $token,array $estados): bool {return $row&&$token!==''&&isset($row[$coluna])&&hash_equals($token,(string)$row[$coluna])&&in_array($row['estado'],$estados,true);}
    public static function lease(): string {return wp_generate_uuid4();}
    public static function restante(float $inicio,int $segundos): int {return max(0,(int)floor(max(1,min(30,$segundos))-(microtime(true)-$inicio)));}
    public static function agendar(string $hook,int $quando=0): bool {
        return !empty(self::agendar_detalhe($hook,$quando)['agendado']);
    }
    public static function agendar_detalhe(string $hook,int $quando=0): array {
        $quando=$quando?:time();$lock=F3Base_Trava::adquirir('agenda-'.substr(hash('sha256',$hook),0,32),30);
        if(!$lock){return array('ok'=>false,'agendado'=>false,'codigo'=>'agenda_ocupada','proxima_execucao'=>wp_next_scheduled($hook)?:null,'despacho'=>'nao_tentado');}
        try {
            $old=wp_get_scheduled_event($hook);$atual=$old?(int)$old->timestamp:0;$ok=$atual&&$atual<=$quando;$code=$ok?'agenda_ja_antecipada':'agenda_pendente';
            if(!$ok){
                $removed=!$old||wp_unschedule_event($old->timestamp,$hook,$old->args,true)===true;
                $scheduled=$removed?wp_schedule_single_event($quando,$hook,array(),true):false;
                $ok=$scheduled===true&&wp_next_scheduled($hook)===$quando;
                $code=$ok?'agenda_antecipada':($removed?'agenda_gravacao_falhou':'agenda_remocao_falhou');
                if(!$ok&&$removed&&$old){$restored=$old->schedule?wp_schedule_event($old->timestamp,$old->schedule,$hook,$old->args,true):wp_schedule_single_event($old->timestamp,$hook,$old->args,true);$code.=$restored===true?'_anterior_restaurada':'_restauracao_falhou';}
            }
            $dispatch='aguardando_horario';$external=defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON;
            if($ok&&$external){$dispatch='aguardando_executor_externo';}
            elseif($ok&&$quando<=time()+1){$dispatch='solicitacao_no_shutdown';if(!isset(self::$acordar[$hook])){self::$acordar[$hook]=true;add_action('shutdown',static function(){if(!get_transient('f3base_filas_acordando')){set_transient('f3base_filas_acordando',1,15);spawn_cron();}});}}
            return array('ok'=>(bool)$ok,'agendado'=>(bool)$ok,'codigo'=>$code,'proxima_execucao'=>wp_next_scheduled($hook)?:null,'despacho'=>$dispatch,'processamento_confirmado'=>false);
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function percentil(array $v,float $p): ?int {if(!$v){return null;}sort($v,SORT_NUMERIC);return (int)$v[max(0,(int)ceil(count($v)*$p)-1)];}
}
