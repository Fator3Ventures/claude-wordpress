<?php
/** Consumidor do contrato público search-console-reader/1.0.0. Sem credenciais próprias. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Gsc {
    const EVENTO='f3base_gsc_coletar';const CONTINUAR='f3base_gsc_continuar';const CONTRATO='search-console-reader/1.0.0';
    private static $client=null;private static array $capabilities=array();private static string $registro='sdk_ausente';
    public static function instalar(): bool {return F3Base_Gsc_Acervo::instalar()&&F3Base_Gsc_Lacunas::instalar();}
    public static function data_valida(string $v): bool {$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);return $d&&$d->format('Y-m-d')===$v;}
    public static function propriedade_cobre(string $p): bool {
        $p=F3Base_Dominio::propriedade($p);if(strlen($p)>250||preg_match('/[\x00-\x20]/',$p)){return false;}$h=wp_parse_url(home_url('/'));$host=F3Base_Dominio::host($h['host']??'');
        if(str_starts_with($p,'sc-domain:')){$d=strtolower(substr($p,10));return !F3Base_Dominio::sufixo_publico($d)&&(bool)preg_match('/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9-]{2,63}$/D',$d)&&($host===$d||str_ends_with($host,'.'.$d));}
        $u=wp_parse_url($p);if(!$u||!in_array($u['scheme']??'',array('http','https'),true)||isset($u['user'])||isset($u['pass'])||isset($u['query'])||isset($u['fragment'])||strtolower($u['host']??'')!==$host||($u['scheme']??'')!==($h['scheme']??'')){return false;}
        $port=static fn($x)=>(int)($x['port']??($x['scheme']==='https'?443:80));$path=rtrim($u['path']??'/','/');$hp=rtrim($h['path']??'/','/');return $port($u)===$port($h)&&($path===''||$hp===$path||str_starts_with($hp,$path.'/'))&&!preg_match('~(?:^|/)\.\.?(/|$)|%2f|%5c~i',$path);
    }
    public static function configuracao(): array {
        $p=(string)F3Base_Options::ler('f3base_gsc_property');$c=F3Base_Options::ler('f3base_gsc');$rev=hash('sha256',F3Base_Options::revisao('f3base_gsc_property').'|'.F3Base_Options::revisao('f3base_gsc').'|'.(F3Base_Recuperacao::ler()['geracao']??0));
        $s=get_option(F3Base_Instalacao::OPTION,array());return array('property'=>$p,'revision'=>$rev,'ready'=>!empty($c['ativo'])&&$p!==''&&self::propriedade_cobre($p)&&!empty($s['concluido_em'])&&F3Base_Gsc_Acervo::pronta()&&empty(F3Base_Recuperacao::ler()['pausado']));
    }
    /** Bound at file load, before Google's plugins_loaded priority 30. */
    public static function descobrir($sdk,string $contract): void {
        if($contract!==self::CONTRATO||!is_object($sdk)||!is_callable(array($sdk,'capabilities'))||!is_callable(array($sdk,'register_consumer'))){self::$registro='contrato_incompativel';return;}
        try {
        $caps=$sdk::capabilities();if(($caps['contract']??'')!==self::CONTRATO||!in_array('gsc.page-day.read',$caps['capabilities']??array(),true)){self::$registro='capacidade_ausente';return;}
        $client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,self::CONTRATO,array(__CLASS__,'configuracao'));
        if(is_wp_error($client)){self::$registro=$client->get_error_code();return;}self::$client=$client;self::$capabilities=$caps;self::$registro='registrado';
        } catch(Throwable $e){self::$client=null;self::$registro='sdk_incompativel';}
    }
    public static function iniciar(): void {
        add_action('init',array(__CLASS__,'agendar'),120);add_action(self::EVENTO,array(__CLASS__,'coletar'));add_action(self::CONTINUAR,array(__CLASS__,'coletar'));add_action('wp_abilities_api_init',array(__CLASS__,'registrar'));
        add_action('updated_option',static function($name){if(in_array($name,array('f3base_gsc_property','f3base_gsc','timezone_string','gmt_offset'),true)){self::invalidar_curso('configuracao_alterada');F3Base_Options::atualizar_estado('f3base_gsc_estado',static fn($s)=>array_merge($s,array('proxima_tentativa'=>0)));wp_clear_scheduled_hook(self::EVENTO);self::agendar();}},210,1);
    }
    public static function agendar(): void {
        $c=self::configuracao();if(!$c['ready']||!self::$client){wp_clear_scheduled_hook(self::EVENTO);wp_clear_scheduled_hook(self::CONTINUAR);return;}
        if(!wp_next_scheduled(self::EVENTO)){wp_schedule_event(F3Base_Operacao::proximo_horario(F3Base_Options::ler('f3base_gsc')['horario']??'05:00'),'daily',self::EVENTO);}
    }
    public static function invalidar_curso(string $motivo): bool {
        global $wpdb;$t=F3Base_Gsc_Acervo::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t){return false!==$wpdb->query($wpdb->prepare("UPDATE %i SET estado='reiniciar',`cursor`='',codigo=%s,atualizado_em=%d WHERE estado IN ('em_curso','aguardando')",$t,$motivo,time()));}return !$wpdb->last_error;
    }
    public static function resumo(): array {
        $r=array('ok'=>true,'sdk'=>self::$registro,'contrato'=>self::CONTRATO,'configuracao'=>self::configuracao(),'estado'=>F3Base_Options::ler('f3base_gsc_estado'),'calendario_dados'=>'America/Los_Angeles','horario_execucao'=>F3Base_Options::ler('f3base_gsc')['horario']??'05:00','fuso_execucao'=>wp_timezone_string(),'retencao'=>'sem_expiracao_automatica','all_rows_guaranteed'=>false,'status_sdk_escopo'=>'A consulta resolve a concessão única. O status do SDK mostra somente a conexão corrente e não é usado como veto global.');
        $r['lacunas']=F3Base_Gsc_Lacunas::resumo();
        if(self::$client){
            $methods=self::$capabilities['client_methods']??array();$effective=is_array($methods)&&in_array('effective_status',$methods,true);
            try{
                if($effective){
                    if(!is_callable(array(self::$client,'effective_status'))){throw new RuntimeException('capacidade_inconsistente');}
                    $status=self::$client->effective_status();
                    if(!is_array($status)||!in_array($status['resolution']??'',array('resolved','not_granted','ambiguous','unreadable'),true)||($status['resolution']==='resolved'&&(!is_string($status['connection_id']??null)||$status['connection_id']===''))){throw new RuntimeException('diagnostico_invalido');}
                    $r['servico']=array_intersect_key($status,array_flip(array('resolution','connection_id','local_status')));if($status['resolution']!=='resolved'){$r['servico']['connection_id']=null;}
                    $r['status_sdk_escopo']='Conexão efetiva resolvida localmente. Não comprova acesso remoto nem persistência das métricas; query reavalia a autorização.';
                }else{$r['servico']=self::$client->status();}
            }catch(Throwable $e){$r['servico']=array('resolution'=>'unreadable','connection_id'=>null,'codigo'=>'diagnostico_sdk_indisponivel');$r['status_sdk_escopo']='Diagnóstico do SDK indisponível. Não é veto global à consulta, que reavalia os próprios controles.';}
        }return $r;
    }
    private static function dia_elegivel(string $property): ?array {
        global $wpdb;$t=F3Base_Gsc_Acervo::tabela();$universe=F3Base_Gsc_Acervo::universo($property);$today=new DateTimeImmutable('today',new DateTimeZone('America/Los_Angeles'));$last=$today->modify('-3 days');$initial=F3Base_Options::ler('f3base_gsc')['inicio']??'';$start=$initial?new DateTimeImmutable($initial,new DateTimeZone('America/Los_Angeles')):$last->modify('-29 days');
        $ongoing=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE universo=%s AND origem='automatico' AND estado IN ('em_curso','aguardando') AND proxima_tentativa<=%d ORDER BY criado_em LIMIT 1",$t,$universe,time()),ARRAY_A);if($ongoing){return array('coleta'=>$ongoing);}
        $seen=$wpdb->get_results($wpdb->prepare("SELECT dia,MAX(IF(estado='concluida',atualizado_em,0)) confirmado,MAX(IF(estado IN ('limitada','aguardando','reiniciar'),GREATEST(proxima_tentativa,atualizado_em+86400),0)) bloqueio FROM %i WHERE universo=%s AND origem='automatico' AND dia BETWEEN %s AND %s GROUP BY dia",$t,$universe,$start->format('Y-m-d'),$last->format('Y-m-d')),OBJECT_K);
        $backlog=null;$recent=null;
        for($day=$start;$day<=$last;$day=$day->modify('+1 day')){$d=$day->format('Y-m-d');$s=$seen[$d]??null;if(!$s||(!(int)$s->confirmado&&(int)$s->bloqueio<=time())){$backlog=$d;break;}}
        for($day=$last->modify('-2 days');$day<=$last;$day=$day->modify('+1 day')){if($day<$start){continue;}$d=$day->format('Y-m-d');$s=$seen[$d]??null;if(!$s||((int)$s->confirmado<$today->getTimestamp()&&(int)$s->bloqueio<=time())){$recent=$d;break;}}
        $state=F3Base_Options::ler('f3base_gsc_estado');$useRecent=$recent&&(!$backlog||($state['ultima_faixa']??'')==='lacunas');$selected=$useRecent?$recent:$backlog;if(!$selected){return null;}
        return array('dia'=>$selected,'faixa'=>$useRecent?'revisita':'lacunas');
    }
    public static function coletar(): array {
        $cfg=self::configuracao();if(!$cfg['ready']||!self::$client){return array('ok'=>true,'codigo'=>!self::$client?'sdk_ausente':'coleta_desconfigurada');}
        if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}
        $own=F3Base_Execucoes::iniciar('gsc');global $wpdb;$lock='f3gsc:'.substr(hash('sha256',$wpdb->prefix),0,48);$locked=false;
        try{
            $locked=(int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))===1;if(!$locked){return array('ok'=>false,'codigo'=>'coleta_em_curso');}
            if(!F3Base_Gsc_Lacunas::inventariar($cfg['property'])){return array('ok'=>false,'codigo'=>'inventario_lacunas_falhou');}
            $s=F3Base_Options::ler('f3base_gsc_estado');if((int)($s['proxima_tentativa']??0)>time()){return array('ok'=>true,'codigo'=>'aguardando_servico','proxima_tentativa'=>$s['proxima_tentativa']);}
            $selection=self::dia_elegivel($cfg['property']);if(!$selection){return array('ok'=>true,'codigo'=>'nenhum_dia_pendente');}
            $limit=min(1000,max(1,(int)(self::$capabilities['limit_max']??1000)));$c=$selection['coleta']??null;
            if($c&&($c['revision']!==$cfg['revision']||(int)$c['limite']!==$limit||(int)$c['criado_em']<time()-DAY_IN_SECONDS)){F3Base_Gsc_Acervo::falhar($c,'contexto_ou_cursor_expirado',time(),true);$selection['dia']=$c['dia'];$c=null;}
            if(!$c){$c=F3Base_Gsc_Acervo::criar($cfg['property'],$selection['dia'],$cfg['revision'],$limit);}
            if(!$c){return array('ok'=>false,'codigo'=>'coleta_nao_persistida');}
            $budget=min(20000,F3Base_Execucoes::restante_ms(2000));if($budget<3000){self::continuar(time()+60);return array('ok'=>true,'parcial'=>true,'codigo'=>'orcamento_insuficiente');}
            $run=F3Base_Execucoes::atual()['run_id']??wp_generate_uuid4();
            $input=array('contract_version'=>'1.0.0','property'=>$cfg['property'],'consumer_revision'=>$cfg['revision'],'date'=>$c['dia'],'run_id'=>$run,'trigger'=>F3Base_Execucoes::origem(),'budget_ms'=>$budget,'limit'=>$limit);if($c['cursor']!==''){$input['cursor']=$c['cursor'];}
            $response=self::$client->query($input);
            if(empty($response['success'])){
                $code=(string)($response['error_code']??'falha_sdk');$next=max(time()+(!empty($response['retryable'])?300:DAY_IN_SECONDS),(int)($response['next_eligible_at']??0),time()+(int)ceil((int)($response['retry_after_ms']??0)/1000));$restart=(bool)preg_match('/cursor|context_changed|consumer_changed/',$code);
                $r=F3Base_Gsc_Acervo::falhar($c,$code,$next,$restart);
                F3Base_Options::atualizar_estado('f3base_gsc_estado',static function($s)use($response,$next,$code){$s['ultima_tentativa']=time();$s['codigo']=$code;$s['proxima_tentativa']=$next;$s['ultimo_recibo']=array_intersect_key($response,array_flip(array('error_code','retryable','retry_after_ms','next_eligible_at','remote_dispatched','audit_success','request_id','run_id','connection_id')));return $s;});
                self::continuar($next);return $r;
            }
            if(self::configuracao()!==$cfg){return F3Base_Gsc_Acervo::falhar($c,'configuracao_alterada',time()+60,true);}
            $r=F3Base_Gsc_Acervo::receber($c,$response);
            F3Base_Options::atualizar_estado('f3base_gsc_estado',static function($s)use($r,$selection,$response){$s['ultima_tentativa']=time();$s['codigo']=$r['codigo'];$s['ultima_coleta']=$r['coleta']??null;$s['proxima_tentativa']=$r['proxima_tentativa']??0;if(!empty($selection['faixa'])){$s['ultima_faixa']=$selection['faixa'];}$s['ultimo_recibo']=array_intersect_key($response,array_flip(array('success','remote_dispatched','audit_success','request_id','run_id','connection_id','extracted_at','coverage')));return $s;});
            if(!empty($r['parcial'])||self::dia_elegivel($cfg['property'])){self::continuar(max(time()+60,(int)($r['proxima_tentativa']??0)));}return $r;
        }finally{if($locked){$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}if($own){F3Base_Execucoes::encerrar();}F3Base_Recuperacao::sair();}
    }
    private static function continuar(int $at): void {if(!wp_next_scheduled(self::CONTINUAR)){wp_schedule_single_event($at,self::CONTINUAR);}}
    public static function registrar(): void {
        F3Base_Servicos::ability('gsc-lacunas-ler','Inventário persistido de dias pendentes e resolvidos',array(F3Base_Gsc_Lacunas::class,'listar'),array('propriedade'=>array('type'=>'string','maxLength'=>250),'pagina'=>array('type'=>'integer','minimum'=>1),'estado'=>array('type'=>'string','enum'=>array('pendente','resolvida'))));
        F3Base_Servicos::ability('gsc-status','Estado e cobertura da coleta Search Console',array(__CLASS__,'resumo'));
        F3Base_Servicos::ability('gsc-coletar','Executar uma página da coleta autorizada Search Console',static fn()=>F3Base_Operacao::executar_uma('gsc','manual',false),array(),array(),false);
        F3Base_Servicos::ability('gsc-historico','Fotografias Search Console e dados arquivados',array(F3Base_Gsc_Acervo::class,'historico'),array('propriedade'=>array('type'=>'string','maxLength'=>250),'dia'=>array('type'=>'string','format'=>'date'),'id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'pagina'=>array('type'=>'integer','minimum'=>1),'pagina_linhas'=>array('type'=>'integer','minimum'=>1)));
    }
    private static function tabela_analitica(array $rows): void {
        $cols=array('url','cliques','impressoes','ctr_pct','posicao_media','primeira_data','ultima_data','dias_com_linhas','post_id','pesquisa','escopo','filtros');$shown=array();
        foreach($rows as $row){$display=array();foreach($cols as $col){if(array_key_exists($col,$row)){$display[$col]=$row[$col];}}$shown[]=$display;}
        F3Base_Relatorios::tabela($shown);
    }
    public static function render(array $e): void {
        $status=self::resumo();$cfg=$status['configuracao'];$history=F3Base_Gsc_Acervo::historico(array('propriedade'=>(string)($e['gsc_propriedade']??$cfg['property']),'pagina'=>max(1,(int)($_GET['historico_pagina']??1))));$r=F3Base_Inteligencia::gsc($e);
        echo '<section class="f3m-card"><h2>Desempenho na busca Google</h2><p>Propriedade da coleta automática: <strong>'.esc_html($cfg['property']?:'Não configurada').'</strong> · SDK: '.esc_html($status['sdk']).'</p><p>Coleta diária às '.esc_html($status['horario_execucao'].' — '.$status['fuso_execucao']).'. Os dados usam dias de Los Angeles. Histórico preservado sem expiração automática.</p><p><a class="button" href="'.esc_url(admin_url('admin.php?page=base-site-core-fator3&secao=medicao-gsc')).'">Configurar propriedade e coleta</a></p>';
        if(empty($cfg['ready'])){echo '<p role="status">A coleta aguarda configuração, estrutura pronta e autorização no MCP Google. O acervo existente permanece disponível.</p>';}
        echo '<h3>Totais do universo selecionado</h3>';self::tabela_analitica($r['linhas']??array());echo '<h3>Páginas e artigos</h3>';self::tabela_analitica($r['paginas']??array());
        echo '<h3>Histórico de coletas e cobertura</h3><p>Todas as datas da propriedade selecionada; as tabelas de desempenho acima usam o período informado.</p><div style="overflow:auto;max-width:100%" tabindex="0" role="region" aria-label="Histórico de coletas"><table class="widefat striped"><thead><tr><th>Dia GSC</th><th>Estado</th><th>Linhas</th><th>Origem</th><th>Extração no fuso local</th><th>Publicada</th></tr></thead><tbody>';
        foreach($history['linhas']??array() as $row){echo '<tr><td>'.esc_html($row['dia']).'</td><td>'.esc_html($row['estado'].($row['codigo']?' · '.$row['codigo']:'')).'</td><td>'.(int)$row['linhas'].'</td><td>'.esc_html($row['origem']).'</td><td>'.esc_html($row['extraido_formatado']??'—').'</td><td>'.(!empty($row['publicado'])?'Sim':'Não').'</td></tr>';}
        echo '</tbody></table></div>';if(!empty($history['proxima_pagina'])){echo '<p><a href="'.esc_url(add_query_arg('historico_pagina',$history['proxima_pagina'])).'">Próxima página do histórico</a></p>';}
        echo '<details><summary>Como interpretar e consultar por agente</summary><p>Conclusão da paginação não garante todas as linhas existentes no Google. Dias sem linhas são recibos de consulta, não visitas zero. CTR é cliques/impressões; posição é ponderada por impressões. URLs de outros hosts ficam no acervo sem associação forçada ao conteúdo deste site. Não há vínculo entre linhas GSC e pessoas, sessões ou citações de IA.</p><p>Use f3base/gsc-status e f3base/gsc-historico. O importador manual continua disponível. Leia docs/OPERACAO-GSC-1.20.md.</p><pre>'.esc_html(wp_json_encode($status['estado'],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details></section>';
    }
}
