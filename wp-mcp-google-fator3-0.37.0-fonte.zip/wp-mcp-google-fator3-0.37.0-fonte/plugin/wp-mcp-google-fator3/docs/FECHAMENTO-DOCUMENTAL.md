# Fechamento documental · 0.37.0

O índice instalado publica oito documentos lógicos em 26 arquivos. Catálogo de 311 habilidades, schemas e opções são gerados do runtime. O guia vigente descreve o Pedido 55 e as fronteiras da autorização pelo WordPress, do transporte MCP e do destino técnico Core.

O instalador contém dados PHP protegidos com a documentação. O fonte inclui editáveis, geradores, testes e evidências sanitizadas. Evidências históricas permanecem identificadas por versão. O relatório interno antecede o fechamento do fonte; tamanho e SHA-256 finais do fonte pertencem ao relatório externo. Nenhum ZIP contém outro ZIP.
