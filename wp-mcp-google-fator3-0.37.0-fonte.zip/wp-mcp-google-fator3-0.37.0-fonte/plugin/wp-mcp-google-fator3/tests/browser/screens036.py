"""Run against a disposable WordPress with F3_URL, F3_PASSWORD_FILE and F3_CHROMIUM."""
import json, os, sys
from pathlib import Path
from urllib.parse import urlencode, urlsplit
from playwright.sync_api import sync_playwright
base = os.environ['F3_URL']
assert urlsplit(base).hostname == '127.0.0.1'
out = Path(sys.argv[1])
out.mkdir(exist_ok=True, parents=True)
sections = {'overview':'Suporte','connection':'Configurar','conversions':'Configurar','archive':'Dados','gsc':'Dados','gtm':'Configurar','incidents':'Suporte','advanced':'Configurar','help':'Suporte'}
variants = {'connection':[('identity','service_account'),('identity','oauth'),('services',None),('permissions',None)],'advanced':[(key,None) for key in ['limits','diagnostics','operations','templates','credentials','contract']]}
def url(section, **more):
    return base + '/wp-admin/tools.php?' + urlencode(dict(page='wp-mcp-google-fator3',connection_id='lab36',section=section,**more))
rows, errors, interactions = [], [], []
with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ['F3_CHROMIUM'], args=['--no-zygote','--single-process','--disable-dev-shm-usage'])
    page = browser.new_page()
    page.route('**/*',lambda route: route.continue_() if urlsplit(route.request.url).hostname == '127.0.0.1' else route.abort())
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.goto(base+'/wp-login.php')
    page.locator('#user_login').fill('administrador')
    page.locator('#user_pass').fill(Path(os.environ['F3_PASSWORD_FILE']).read_text().strip())
    page.locator('#wp-submit').click()
    for width,height in [(360,800),(768,1024),(1440,900)]:
        page.set_viewport_size(dict(width=width,height=height))
        for section,group in sections.items():
            for panel,method in variants.get(section,[(None,None)]):
                params={}
                if panel: params[section+'_panel']=panel
                if method: params['method']=method
                res=page.goto(url(section,**params),wait_until='load')
                root=page.locator('.f3-google')
                root.wait_for(timeout=10000)
                name='-'.join(str(v) for v in [section,panel,method] if v)
                dest=out/str(width)/(name+'.png');dest.parent.mkdir(exist_ok=True)
                a=root.evaluate("""r=>({group:r.querySelector('.f3-groups [aria-current]').textContent, tabs:r.querySelectorAll('.f3-tabs a').length, section:new URL(r.querySelector('.f3-tabs [aria-current]').href).searchParams.get('section'), current:r.querySelector('.f3-subnav [aria-current]')?.textContent, navigation:[...r.querySelectorAll('nav')].every(n=>n.scrollWidth<=n.clientWidth+1), viewport:document.documentElement.scrollWidth<=innerWidth, card:!!r.querySelector('.f3-context #f3-connection'), labelErrors:[...r.querySelectorAll('input:not([type=hidden]),select,textarea')].filter(e=>e.getBoundingClientRect().width>0 && !e.labels?.length && !e.hasAttribute('aria-label') && !e.hasAttribute('aria-labelledby')).map(e=>e.name),tables:[...r.querySelectorAll('table')].every(t=>t.closest('.f3-table-wrap'))})""")
                issues=[]
                for ok,label in [(res.status==200,'HTTP'),(a['group']==group,'grupo'),(a['section']==section,'aba'),(a['navigation'],'navegação'),(a['viewport'],'largura'),(a['card'],'seletor'),(not a['labelErrors'],'rótulos'),(a['tables'],'tabelas')]:
                    if not ok: issues.append(label)
                page.screenshot(path=str(dest),full_page=True,animations='disabled',timeout=20000)
                rows.append(dict(width=width,page=name,issues=issues,**a))
    page.goto(url('incidents'))
    pages=page.get_by_role('navigation',name='Paginação',exact=True)
    assert '1–20 de 45' in pages.inner_text()
    pages.get_by_text('Próxima').click()
    assert '21–40 de 45' in pages.inner_text()
    pages.get_by_text('Anterior').click()
    page.locator('[name=incident_search]').fill('homologação 45');page.get_by_role('button',name='Buscar',exact=True).click()
    assert '1–1 de 1' in pages.inner_text()
    interactions+=['Incidentes: próxima e anterior sobre 45 registros','Busca global encontrou registro da terceira página']
    page.goto(url('advanced',advanced_panel='operations',job_search='ui036-45'))
    assert '1–1 de 1' in page.get_by_role('navigation',name='Paginação',exact=True).first.inner_text()
    interactions.append('Busca por ID de tarefa em toda a conexão')
    page.goto(url('help'))
    field=page.get_by_label('Buscar documento')
    field.fill('CRON');assert page.locator('.f3-doc-list li:visible').count() >= 1
    field.fill('nenhum-documento-correspondente');assert page.locator('.f3-doc-list li:visible').count()==0
    field.fill('');assert page.locator('.f3-doc-list li:visible').count()==20
    interactions.append('Busca de documentos com e sem resultados e restauração da página')
    page.locator('.f3-groups a',has_text='Dados').click()
    assert page.locator('.f3-tabs [aria-current]').inner_text()=='Acervo Ads'
    page.locator('.f3-tabs a',has_text='Search Console').click()
    assert page.locator('#f3-connection').input_value()=='lab36'
    interactions.append('Navegação entre grupos e subabas mantém a conexão')
    version=browser.version;browser.close()
report=dict(browser=version,captures=len(rows),interactions=interactions,errors=errors,pages=rows)
(out/'checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
bad=[(r['width'],r['page'],r['issues'],r['labelErrors']) for r in rows if r['issues']]
print(json.dumps(dict(captures=len(rows),bad=bad,errors=errors),ensure_ascii=False))
if bad or errors: sys.exit(1)
