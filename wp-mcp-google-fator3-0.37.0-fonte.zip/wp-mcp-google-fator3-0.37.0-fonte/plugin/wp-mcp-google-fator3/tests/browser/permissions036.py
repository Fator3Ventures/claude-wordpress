"""Verify the settings form with two local disposable WordPress roles."""
import json
import os
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright

base = os.environ["F3_URL"]
assert urlsplit(base).hostname == "127.0.0.1"
url = base + "/wp-admin/tools.php?page=wp-mcp-google-fator3&section=connection&connection_id=lab36"
password = Path(os.environ["F3_PASSWORD_FILE"]).read_text().strip()
checks = []

with sync_playwright() as pw:
    for user in ["leitor036", "administrador"]:
        browser = pw.chromium.launch(executable_path=os.environ["F3_CHROMIUM"], args=["--no-zygote", "--single-process", "--disable-dev-shm-usage"])
        page = browser.new_page()
        context = page.context
        page.route("**/*", lambda r: r.continue_() if urlsplit(r.request.url).hostname == "127.0.0.1" else r.abort())
        page.goto(base + "/wp-login.php")
        page.locator("#user_login").fill(user)
        page.locator("#user_pass").fill(password)
        page.locator("#wp-submit").click()
        assert any(c["name"].startswith("wordpress_logged_in_") for c in context.cookies())
        res = page.goto(url)
        if user == "leitor036":
            assert res.status == 403
            checks.append("Acesso à tela recusado ao assinante")
            res = context.request.post(base + "/wp-admin/admin-post.php", form={"action":"f3_mcp_google_rename_connection", "connection_id":"lab36", "connection_label":"inacessivel"})
            assert "Permissão insuficiente" in res.text()
            checks.append("Gravação recusada ao assinante")
        else:
            assert res.status == 200
            field = page.locator('input[name="connection_label"]')
            original = field.input_value()
            invalid = context.request.post(base + "/wp-admin/admin-post.php", form={"action":"f3_mcp_google_rename_connection","connection_id":"lab36","connection_label":"invalido","_wpnonce":"invalido"})
            assert invalid.status == 403
            page.goto(url)
            assert field.input_value() == original
            checks.append("Nonce inválido recusado antes de gravar")
            for label in ["Teste de nome 036", original]:
                page.locator("details > summary").filter(has_text="Nome da conexão").first.click()
                field.fill(label)
                page.get_by_role("button", name="Salvar nome").click()
                page.goto(url)
                assert field.input_value() == label
            checks.append("Administrador salvou e restaurou o nome pelo formulário")

        browser.close()

print(json.dumps({"checks":checks}, ensure_ascii=False, indent=2))
