<?php
/** Durable producer outbox. Core owns recipients, reservation and delivery. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
defined('ABSPATH') || exit;

final class TechnicalNotices {
    public static function publish(string $code, string $resource, bool $failed, array $details = []): array {
        if (Confirmation::capturing()) return ['ok'=>false, 'codigo'=>'simulation'];
        $id = hash('sha256', Connections::id().'|'.$code.'|'.$resource);
        $lock = Lock::acquire('technical:'.$id, 30);
        if ($lock === null) return ['ok'=>false, 'codigo'=>'occupied'];
        try {
            $old = Records::get('technicalnotice', $id);
            if (!$old && !$failed) return ['ok'=>true, 'estado'=>'sem_incidente'];
            $event = ['pacote'=>'google', 'codigo'=>$code,
                'recurso'=>Connections::id().'/'.$resource,
                'estado'=>$failed?'aberto':'recuperado',
                'acao_humana'=>$details['human_action']??true];
            if (isset($details['expires'])) $event['vence_em'] = $details['expires'];
            $queue = $old['queue'] ?? [];
            if (($old['event']??null) !== $event) {
                $event['desde'] = $failed ? time() : (int)($old['since']??time());
                $queue[] = $event;
                $new = ['id'=>$id, 'connection_id'=>Connections::id(), 'event'=>array_diff_key($event,['desde'=>true]),
                    'since'=>$event['desde'], 'queue'=>$queue, 'status'=>'pending', 'task'=>'core_notice', 'run_after'=>time()];
                $saved = Records::put('technicalnotice',$id,$new);
                if (empty($saved['success'])) return ['ok'=>false, 'codigo'=>'outbox_not_saved'];
                $old = $new;
            }
            return self::flush($id, $old);
        } finally { Lock::release($lock); }
    }

    private static function flush(string $id, array $row): array {
        if (empty($row['queue'])) return $row['receipt']??['ok'=>true,'estado'=>'aceito'];
        $result = ['ok'=>false, 'codigo'=>'core_contract_unavailable'];
        if (!has_filter('f3base_incidente_publicar_v1')) return $result;
        foreach ($row['queue'] as $event) {
            try { $result = apply_filters('f3base_incidente_publicar_v1', null, $event); }
            catch (\Throwable $error) { $result = ['ok'=>false, 'codigo'=>'core_contract_failed']; }
            if (!is_array($result) || empty($result['ok'])) break;
            array_shift($row['queue']);
            $row['status'] = $row['queue'] ? 'pending' : 'accepted';
            $row['receipt'] = array_intersect_key($result,array_flip(['ok','estado','codigo']));
            if (empty(Records::put('technicalnotice',$id,$row)['success'])) return ['ok'=>false,'codigo'=>'outbox_receipt_not_saved'];
        }
        return is_array($result)?$result:['ok'=>false,'codigo'=>'core_contract_unavailable'];
    }

    public static function dispatch(): void {
        $rows = Storage\Repository::select('technicalnotice',['state'=>'pending'],100);
        if (is_wp_error($rows)) return;
        foreach ($rows as $entry) {
            $id=$entry['record_id'];
            $lock=Lock::acquire('technical:'.$id,30);
            if ($lock===null) continue;
            try {
                $row=Records::get('technicalnotice',$id);
                if ($row) self::flush($id,$row);
            } finally { Lock::release($lock); }
        }
    }

    public static function observe(): void {
        if (Confirmation::capturing() || Recovery::guard() || Storage\State::guard()) return;
        $registry=Connections::registry_verified();
        if (is_wp_error($registry)) return;
        foreach (array_keys($registry) as $connection) {
            Connections::run($connection,static function() {
                if (!Options::is_enabled()) return;
                $state=Automation\Executor::status();
                self::publish('agenda_parada','executor',($state['health']??'unknown')==='degraded');
                foreach ([Ads\Archive::CONFIG,Integration\AdsServiceApi::GRANTS,Integration\Ga4ServiceApi::GRANTS,Integration\QueryServiceApi::GRANTS] as $option) {
                    foreach ((array)Options::get($option,[]) as $grant) {
                        if (is_array($grant) && !empty($grant['enabled'])) SiteAuthority::observe((int)($grant['granted_by']??0));
                    }
                }
                Auth\KeyStatus::observe();
            });
        }
        self::dispatch();
    }
}
