<?php
/**
 * Opt-in operational incidents. Transport acceptance is not delivery confirmation.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;
use Fator3\McpGoogle\{
    Ability, Audit, Connections, Lock, Options, Records, Response, Settings
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Alerts {
    public const OPTION = 'f3_mcp_google_alerts';
    public const EVENTS = array( 'access', 'cron_late', 'sitemap_error', 'scheduled_check' );
    public const MAX_RECIPIENTS = 10;
    public const MIN_INTERVAL = 60;
    public const MAX_INTERVAL = 604800;
    public static function schema(): array {
        return array(
            'type' => 'object',
            'additionalProperties' => false,
            'properties' => array(
                'enabled' => array(
                    'type' => 'boolean',
                    'default' => false,
                ),
                'email_enabled' => array(
                    'type' => 'boolean',
                    'default' => false,
                    'description' => 'Exige ao menos um destinatário válido.',
                ),
                'recipients' => array(
                    'type' => 'array',
                    'maxItems' => self::MAX_RECIPIENTS,
                    'items' => array(
                        'type' => 'string',
                        'format' => 'email',
                    ),
                ),
                'events' => array(
                    'type' => 'array',
                    'items' => array(
                        'type' => 'string',
                        'enum' => self::EVENTS,
                    ),
                    'uniqueItems' => true,
                ),
                'minimum_interval' => array(
                    'type' => 'integer',
                    'minimum' => self::MIN_INTERVAL,
                    'maximum' => self::MAX_INTERVAL,
                    'default' => 3600,
                ),
            ),
        );
    }
    public static function save_slack(string $url, bool $clear, ?string $revision): array {
        return Response::fail(new \WP_Error('f3_google_technical_destination','Configure o destino técnico no Site Core.'));
    }
    public static function channel_blocked(array $job, ?string $reason): void {
        if (!in_array($reason,['f3_google_channel_revoked','f3_google_channel_changed'],true)) return;
        Connections::run($job['connection_id'], static function() use($job,$reason) {
            self::observe('channel','job/'.$job['id'],true,$reason,'O executor revalida a autorização do WordPress.');
        });
    }

    public static function close_channel_incident(array $job): void {
        if (!in_array($job['blocked_reason'] ?? '', ['f3_google_channel_changed','f3_google_channel_revoked'], true)) { return; }
        $id = hash('sha256', $job['connection_id'].'|channel|job/'.$job['id']);
        $row = Records::get('incident',$id);
        if ($row && $row['status'] === 'open') {
            $row['status']='resolved';
            $row['updated_at']=time();
            Records::put('incident',$id,$row);
            \Fator3\McpGoogle\TechnicalNotices::publish('integracao_indisponivel',$id,false);
        }
    }

    public static function config(): array {
        return (array) Options::get(
            self::OPTION,
            array(
                'enabled' => false,
                'email_enabled' => false,
                'recipients' => array(),
                'events' => self::EVENTS,
                'minimum_interval' => 3600,
            )
        );
    }
    public static function configure( array $input ): array {
        $v = $input['configuration'] ?? null;
        if ( ! is_array( $v ) || array_diff( array_keys( $v ), array( 'enabled', 'email_enabled', 'recipients', 'events', 'minimum_interval' ) ) ) {
            return Response::fail( new \WP_Error( 'f3_google_alert_input', 'Configuração de alertas inválida.' ) );
        }
        $v = array_merge( self::config(), $v );
        if ( ! is_bool( $v['enabled'] ) || ! is_bool( $v['email_enabled'] ) || ! is_array( $v['recipients'] ) || count( $v['recipients'] ) > self::MAX_RECIPIENTS || ! is_array( $v['events'] ) || array_diff( $v['events'], self::EVENTS ) || ! is_int( $v['minimum_interval'] ) || $v['minimum_interval'] < self::MIN_INTERVAL || $v['minimum_interval'] > self::MAX_INTERVAL ) {
            return Response::fail( new \WP_Error( 'f3_google_alert_input', 'Confira tipos, eventos e intervalo de 60–604800 segundos.' ) );
        }
        foreach ( $v['recipients'] as $email ) {
            if ( ! is_string( $email ) || ! is_email( $email ) ) {
                return Response::fail( new \WP_Error( 'f3_google_alert_recipient', 'E-mail inválido.' ) );
            }
        }
        if ( $v['email_enabled'] && ! $v['recipients'] ) {
            return Response::fail( new \WP_Error( 'f3_google_alert_recipient', 'Configure destinatários antes de ativar e-mail.' ) );
        }
        return Settings::save( array( self::OPTION => $v ), array(), array(), $input['expected_revision'] ?? null );
    }
    public static function observe( string $event, string $resource_id, bool $failed, string $code, string $action ): void {
        if ( \Fator3\McpGoogle\Confirmation::capturing() ) {
            return;
        }
        $config = self::config();
        if (!in_array($event,array_merge(self::EVENTS,['channel']),true)) return;
        $id = hash( 'sha256', Connections::id() . '|' . $event . '|' . $resource_id );
        $lock = Lock::acquire( 'incident:' . $id, 60 );
        if ( null === $lock ) {
            return;
        }
        try {
            $old = Records::get( 'incident', $id );
            if ( null === $old && ! $failed ) {
                return;
            }
            $state = $failed ? 'open' : 'resolved';
            if ( $old && $old['status'] === $state ) {
                \Fator3\McpGoogle\TechnicalNotices::publish('integracao_indisponivel',$id,$failed);
                return;
            }
            $incident = array(
                'id' => $id,
                'connection_id' => Connections::id(),
                'event' => $event,
                'resource' => substr( $resource_id, 0, 512 ),
                'status' => $state,
                'code' => $code,
                'action' => $action,
                'created_at' => $old['created_at'] ?? time(),
                'updated_at' => time(),
                'generation' => ( $old['generation'] ?? 0 ) + 1,
                'email_state' => 'pending',
                'notification_transport' => 'core/incident-v1',
                'last_notified_at' => $old['last_notified_at'] ?? 0,
                'next_notification_at' => max( time(), ( $old['last_notified_at'] ?? 0 ) + $config['minimum_interval'] ),
            );
            $incident['task'] = 'pending' === $incident['email_state'] ? 'notify_pending' : 'notify_disabled';
            $incident['run_after'] = $incident['next_notification_at'];
            $saved = Records::put( 'incident', $id, $incident );
            if ( ! $saved['success'] ) { return; }
            \Fator3\McpGoogle\TechnicalNotices::publish('integracao_indisponivel',$id,$failed);
        }
        catch ( \Throwable $e ) {
            \Fator3\McpGoogle\Cache::set( 'f3_mcp_google_alert_error_' . Connections::id(), time(), 86400 );
        }
        finally {
            Lock::release( $lock );
        }
    }
    public static function dispatch(): int {
        $page=self::state(['limit'=>100]);
        $count=0;
        foreach ($page['incidents']??[] as $incident) {
            if (!in_array($incident['event']??'',array_merge(self::EVENTS,['channel']),true)) continue;
            $r=\Fator3\McpGoogle\TechnicalNotices::publish('integracao_indisponivel',$incident['id'],$incident['status']==='open');
            if (!empty($r['ok'])) ++$count;
        }
        \Fator3\McpGoogle\TechnicalNotices::dispatch();
        return $count;
    }
    public static function result( string $event, string $resource_id, array $result ): void {
        if ( \Fator3\McpGoogle\Confirmation::capturing() ) {
            return;
        }
        $failed = empty( $result['success'] ) || false === ( $result['all_checks_passed'] ?? true );
        self::observe( $event, $resource_id, $failed, $result['error_code'] ?? ( $failed ? 'check_failed' : 'recovered' ), 'Consultar diagnóstico e conferir o recurso antes de repetir alterações.' );
    }
    /** The optional internal filter selects open incidents before pagination for readiness. */
    public static function state( array $input = array(), bool $open_only = false, ?string $admin_search = null ): array {
        $out = array();
        $limit = max( 1, min( 100, (int) ( $input['limit'] ?? 30 ) ) );
        $offset = max( 0, (int) ( $input['offset'] ?? 0 ) );
        $base = array(
            'configuration' => self::config(),
            'transport_acceptance_is_delivery' => false,
            'self_monitoring_limit' => 'O Site Core observa o executor Google nas passagens do zelador e em visitas administrativas. A entrega exige execução do WordPress e destino técnico configurado.',
        );
        try {
            $filters = array( 'connection_id' => Connections::id() );
            if ( $open_only ) {
                $filters['state'] = 'open';
            }
            if ( ! empty( $input['dispatch'] ) ) {
                $filters += array(
                    'task' => 'notify_pending',
                    'due_before' => time(),
                );
            }
            if ($admin_search !== null) {
                $filters['admin_search'] = $admin_search;
                $total = \Fator3\McpGoogle\Storage\Repository::count_filtered('incident', $filters);
                if (is_wp_error($total)) return $base + ['available'=>false, 'error_code'=>$total->get_error_code(), 'incidents'=>[]];
                $base['total'] = $total;
            }
            $rows = \Fator3\McpGoogle\Storage\Repository::select( 'incident', $filters, $limit + 1, $offset, false );
            if ( is_wp_error( $rows ) ) {
                return $base + array(
                    'available' => false,
                    'error_code' => $rows->get_error_code(),
                    'incidents' => array(),
                );
            }
            $more = count( $rows ) > $limit;
            foreach ( array_slice( $rows, 0, $limit ) as $row ) {
                $incident = Records::get( 'incident', $row['record_id'] );
                if ( null !== $incident ) {
                    $out[] = $incident;
                } elseif ( $open_only ) {
                    return $base + array( 'available' => false, 'error_code' => 'f3_google_incident_read', 'incidents' => array() );
                }
            }
            return $base + array(
                'available' => true,
                'incidents' => $out,
                'next_offset' => $more ? $offset + count( $out ) : null,
            );
        }
        catch ( \Throwable $error ) {
            return $base + array(
                'available' => false,
                'error_code' => 'f3_google_incident_read',
                'incidents' => array(),
            );
        }
    }
    public static function register(): void {
        Ability::register(
            'google/alerts',
            'any',
            array(
                'label' => 'Google: alertas operacionais',
                'description' => 'Consulta configuração e incidentes locais. Não envia mensagens.',
                'input_schema' => array(
                    'properties' => array(
                        'offset' => array(
                            'type' => 'integer',
                            'minimum' => 0,
                        ),
                        'limit' => array(
                            'type' => 'integer',
                            'minimum' => 1,
                            'maximum' => 100,
                        ),
                    ),
                ),
                'callback' => static fn ( array $input ) => Response::ok( self::state( $input ) ),
            )
        );
        Ability::register(
            'google/configure-alerts',
            'any',
            array(
                'label' => 'Google: configurar alertas',
                'description' => 'Mantém preferências locais de observação. Avisos técnicos são encaminhados ao destino do Site Core independentemente destas preferências.',
                'mode' => 'write',
                'input_schema' => array(
                    'required' => array( 'configuration', 'expected_revision' ),
                    'properties' => array(
                        'configuration' => self::schema(),
                        'expected_revision' => array( 'type' => 'string' ),
                    ),
                ),
                'callback' => array( self::class, 'configure' ),
            )
        );
    }
}
