# 0.9.0 — 10/11/2026

Instalação limpa ou atualização direta **0.8.0 → 0.9.0**. WordPress 7.1.4 ou superior, PHP 8.3 ou superior de 64 bits, OpenSSL, mbstring e InnoDB. A atualização preserva regras, retenção, progresso e evidências de escritas. Não ativa cadência nem concede acesso ao fornecedor. Confira o estado instalado em nova requisição; para uma falha após a troca, preserve os dados para correção em nova versão.

| Mudança | Como verificar |
| --- | --- |
| Resultado de escrita incerto | Um 2xx com corpo inválido ou grande demais não prova recusa. Confira o recibo e o bloqueio antes de agir. |
| Fila acima de 200 leads | Avalie uma página e continue com o cursor. O filtro de devidos pode retornar zero sem atingir o fim. |
| Regras | Simule com amostra delimitada, confira os valores antes/depois e só então aplique. Autorização, revisão, titular e validade continuam obrigatórios. |
| Recuperação | Consulte as pendências e gere uma prévia; confirme apenas a resolução oferecida. Uma decisão local não repete a mutação no fornecedor. |
| Trava e retenção | O expurgo não mantém a trava local durante o transporte. A atuação em entidades diferentes continua sujeita à trava própria do Core. |
| Painel e documentação | Configure a sequência de toques e seus textos pelo formulário. Leia guias extensos por partes e use o catálogo para conferir parâmetros e permissões. |

O contrato com o Core é `pipedrive-api-client/1.0.0`. A lista agora reúne 22 operações: as três novas são `pendencias-ler`, `recuperacao-previa` e `recuperacao-confirmar`. Os 12 IDs documentais foram preservados; leia o índice e os schemas instalados. No conjunto de referência do planejamento, o Core estava na 1.78.0 e o MCP na 0.43.0. O relatório de entrega identifica as versões efetivamente verificadas na instalação e os limites da homologação. Uma bancada sintética não encerra o aceite em conta real do Pedido MCP Pipedrive 11.

## Histórico da 0.8.0 — 06/11/2026

Atualização direta da **0.7.0**, para o Pedido MCP Pipedrive 11. As 19 operações, os 12 IDs de documentação, o contrato Core `pipedrive-api-client/1.0.0`, o schema 1 e as regras existentes são preservados.

- Novos registros de WhatsApp não acrescentam códigos de progresso à nota. O progresso privado é persistido atomicamente com o recibo; a leitura dos marcadores antigos permanece.
- Na criação da atividade, a pessoa vinculada ao lead é enviada como participante principal no formato da API v2. Ausência de pessoa impede a criação antes do envio. Participantes de atividades existentes são preservados.
- Releitura confere nota, vínculo e estado; na criação, também confere o participante principal. Divergências mantêm o bloqueio para reconciliação.
- Testes cobrem nota limpa, continuidade, repetição, persistência após reinício/limpeza, falha transacional, isolamento por conta e histórico alterado.

Requisitos: WordPress 7.1.4+, PHP 8.3+ de 64 bits, OpenSSL, mbstring e InnoDB. Conjunto da rodada, conforme o relatório de entrega: Site Core 1.72.1 no início e 1.73.0 na conferência final da fronteira, MCP 0.41.0, Google 0.30.0, Meta 0.21.0 e LinkedIn 0.19.0. O relatório distingue os testes sintéticos no Site-Teste do aceite comercial solicitado em korvena.com.br, que permanece pendente.

## 0.7.0 — 05/11/2026

Atualização direta da **0.6.0**. O plugin conserva as 19 operações públicas e os 12 IDs de documentação. Mantém o contrato Core `pipedrive-api-client/1.0.0`, o schema 1 das tabelas e as opções em vigor. A atualização não modifica regras, não expurga o diário e não concede autorização para operar o CRM.

| O que mudou | Como usar |
| --- | --- |
| Revisão das regras no painel | Uma frase incorreta ou a falta da ordem do dono pode ser corrigida na própria prévia de configuração, enquanto ela estiver válida e pertencer ao administrador. O erro de confirmação não exige repetir a leitura paga da conta. |
| Ajuda local | Guias Markdown completos de até 24.000 bytes são apresentados com títulos, listas, tabelas e exemplos. Documentos maiores e JSON mantêm leitura em texto com paginação e hash. Consulte o ID `painel`. |
| Auditoria | `itens` reúne ocorrências confirmadas. `itens_nao_avaliados` identifica as regras para as quais faltou evidência. Falha ao ler atividades não basta para marcar um lead sem próxima atividade. Consulte `uso` para um exemplo parcial. |
| Contagem por campo | Uma opção ilegível conserva o registro no total observado e deixa seus grupos sem contagem; o motivo `opcao_ilegivel` identifica a limitação. |
| Idempotência e recuperação | A ordem das propriedades JSON deixou de produzir outra identidade da mensagem. A reexecução reconhece o recibo da base na operação de origem; se houver ambiguidade, exige reconciliação. Um checkpoint que não se confirmou impede a próxima escrita. A retenção preserva recibos e diário enquanto houver bloqueio pendente. Consulte `fluxos` e `operacao`. |

Requisitos: WordPress 7.1.4+, PHP 8.3+ de 64 bits, OpenSSL, mbstring e InnoDB. Conjunto de referência da rodada: Site Core 1.71.0, MCP 0.40.0, Google 0.28.0, Meta 0.21.0 e LinkedIn 0.18.0. Apenas o Core fornece o cliente Pipedrive; MCP é o transporte remoto. Veja no relatório de entrega os **pacotes e ambientes efetivamente testados** e os resultados por cenário. Os testes com dados sintéticos não homologam a conta do fornecedor. Falhas posteriores à instalação são tratadas em nova versão, preservando o estado alcançado.

UUIDs de lead que diferem apenas na caixa usam a mesma trava. A guarda reconhece marcadores legados com grafia mista e recusa uma escrita quando não consegue descartar o vínculo.

## Histórico
### 0.6.0 — 05/11/2026

Painel por tarefa, edição guiada de calendário e motivos, validação local e simulação com confirmação exclusiva de regras. Guarda de revisão no SQL, tipos consistentes, verificação de identidade do registro e da conta da simulação, indexação de atividades por lead e carregamento de classes sob demanda. Mantidos 19 nomes públicos, schema das tabelas 1 e contrato Core pipedrive-api-client/1.0.0. Guia novo: `painel`.

Base direta 0.5.0. Requisitos: WordPress 7.1.4 ou superior e PHP 8.3 ou superior, 64 bits, OpenSSL, mbstring e InnoDB. A atualização preserva opções e recibos; correções após a instalação exigem nova versão.

### 0.5.0 — 30/10/2026

Pedidos MCP Pipedrive 10. Activities v2 envia prazo HH:MM; nota com prefixo, fuso e autor. Auditoria usa add_time quando stage_change_time é nulo e separa coleta de avaliação. Modelo aditivo de minutos úteis, feriados, variantes, variáveis, restrições por canal, espera de entrega e adoção explícita de notas. Atualização direta 0.4.0; sem migração/regravação de regras, tabelas ou recibos. Consulte fluxos e schemas. Aceite com fornecedor real é separado da prova sintética.

### 0.4.0 — 29/10/2026

Pedidos4–9: configuração com simulação/revisão, fila, WhatsApp idempotente, encerramento/perda, edição arquivada com compensação, auditoria e contagem. Dez rotas novas; nove preservadas. Core1.60.0/MCP0.36.0, contrato pipedrive-api-client/1.0.0 preservado. Sem migração de tabelas/cron; regras começam pendentes. Recibos WhatsApp sem expurgo automático. Leia fluxos para limites e reconciliação.

### 0.3.0 — 28/10/2026

Pedidos MCP Pipedrive 3: relatório agregado com paginação interna, datas/fuso, códigos sem texto pessoal, negócios ativos/arquivados, completude e custo. Limite do plano informado pelo chamador; motivo de ganho customizado; não é snapshot histórico. Atualização direta de 0.2.0. Core contrato 1.0.0 preservado. Sem migração ou novas credenciais. Aceite da conta real depende de conferência de 30 dias em korvena.com.br.

### 0.2.0 — 26/10/2026

26/10/2026, America/Sao_Paulo. Base direta: 0.1.0. Pedido MCP Pipedrive 2(a–d).

Diário sem prazo por padrão, configurável no painel e pelas novas retencao-ler/retencao-configurar. Status exibe a política mesmo com Core desautorizado. Prazo finito exige ciência explícita; escrita usa revisão, geração e releitura, compartilhando trava com a limpeza. Recibos conservam 180 dias, prévias 15 minutos; diário deixa de depender da existência do recibo. Upgrade não apaga nem redata linhas e preserva a configuração posterior.

O contrato pipedrive-api-client/1.0.0 está presente no Core 1.56.0; documentação deixa de tratá-lo como proposta futura. MCP 0.33.0 oferece transporte/política genéricos. Meta 0.12.0, Google 0.19.0 e LinkedIn 0.10.1 não são dependências do pacote. Nenhum plugin acompanhante foi modificado.

Sem cron, webhook, token ou HTTP próprios. Oito abilities; nenhum campo de credencial novo. Conferir o relatório externo para provas executadas, limitações, estado do Site-Teste e hashes finais.

### 0.1.0 — 23/10/2026

Primeira versão: cinco operações de domínio, documentação paginada, REST/painel administrativos, listas fechadas, prévia de 15 minutos, proteção de opções/estrutura, revalidação, aplicação única, recibos cifrados e auditoria. A aba de pedidos atual registra sua homologação posterior pela frota nos sites-porta; essa é evidência recebida, não nova execução comercial desta release.
