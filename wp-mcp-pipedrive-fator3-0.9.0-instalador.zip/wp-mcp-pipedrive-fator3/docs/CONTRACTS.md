# Contratos — 0.9.0

## Core: pipedrive-api-client/1.0.0

O plugin consome o contrato `pipedrive-api-client/1.0.0`, fornecido pelo Fator3 Site Core. A versão do Core usada em cada prova está no relatório de entrega. Não há leitura de opções privadas do Core nem HTTP próprio. Atualizar o plugin muda a revisão do consumidor: prévias criadas antes da troca devem ser refeitas.

**Registro.** No gancho `f3base_register_pipedrive_consumers($registry, 'pipedrive-api-client/1.0.0')`, o plugin chama `$registry->register_consumer('wp-mcp-pipedrive-fator3', '0.9.0', 'pipedrive-api-client/1.0.0', $configuration)`. O callback `$configuration` devolve `{ready:true, revision:'0.9.0', provider:'wp-mcp-pipedrive-fator3'}`. O retorno é o cliente ou um `WP_Error`. Registro não é autorização.

**Cliente.** Precisa expor `capabilities()`, `status()` e `request(metodo, caminho, query, corpo, contexto)`. `capabilities()` devolve `{contract:'pipedrive-api-client/1.0.0'}`. Nem `capabilities()` nem `status()` fazem HTTP.

**Status.** Exemplo sintético:

```json
{"success":true,"code":"ok","message":"Estado local.","data":{"contract":"pipedrive-api-client/1.0.0","autorizado":true,"conta":{"dominio":"exemplo.pipedrive.com","conta_id":1,"usuario_id":2},"revisao":"revisao-nao-secreta","orcamento":{"teto":3000,"consumido":0,"reservado":0},"saldo_conta":{"restante":15000,"lido_em":"2026-10-23T20:00:00Z"}}}
```

O plugin exige domínio `*.pipedrive.com`, `conta_id` e `usuario_id` numéricos, `revisao` não vazia de até 200 caracteres e orçamento com inteiros não negativos; qualquer divergência vira `contrato_invalido`. `revisao` muda em troca de conta, credencial ou autorização. `saldo_conta` pode ser `null`.

**Request.** O contexto leva `provider`, `consumer` (`operacao`), `contract`, `actor_id`, `revisao_esperada` e, nas mutações, `previa_id`. O Core verifica revisão e autorização e reserva orçamento antes de despachar. Resposta:

```json
{"success":true,"code":"ok","message":"Consulta concluída.","remote_dispatched":true,"data":{"http_status":200,"body":{"success":true,"data":[]},"saldo_conta":{"restante":14980,"lido_em":"2026-10-23T20:01:00Z"}}}
```

Falha anterior ao despacho usa `success:false` com `remote_dispatched:false` explícito. Um `WP_Error` só é tratado como "não enviado" se trouxer esse booleano em seus dados; sem ele, exceção, resposta fora do formato ou HTTP 5xx tornam a tentativa `resultado_incerto`. Depois de um despacho, HTTP 2xx com JSON ilegível ou resposta superior a 512 KiB não prova recusa do fornecedor. Em leitura, reduza a página dentro do orçamento; em escrita, confira o recibo e reconcilie antes de outra tentativa. Mensagens e corpos de erro do cliente nunca são repassados. Nas recusas anteriores ao despacho, os códigos específicos aceitos são: `saldo_conta_baixo`, `operacao_nao_autorizada`, `core_em_recuperacao`, `orcamento_esgotado`, `pipedrive_orcamento_esgotado`, `pausa_remota`, `rate_limit`, `credencial_invalida`, `revisao_conflitante`, `contexto_alterado` e `core_indisponivel`. Qualquer outro vira `core_recusou`.

## Transporte e autorização

Provider `wp-mcp-pipedrive-fator3`, prefixo `pipedrive/`, `policy_contract` 1, registrado em `f3_mcp_register_providers`. A Abilities API registra as 22 operações na categoria `pipedrive`. Sem o Fator3 MCP, o REST e o painel continuam disponíveis.

Toda operação confere `manage_options` no próprio plugin, além da política da conexão MCP. Pelo MCP, uma entrada fora do schema é recusada antes de chegar ao plugin. Um envelope com `success:false` pode chegar ao agente como erro da ferramenta: o envelope do plugin vem dentro de `data`, e é `data.code` que decide o próximo passo. A chave de idempotência do transporte MCP é independente do `previa_id` e da `chave_idempotencia` do domínio; não use outra chave de transporte para contornar um recibo incerto.

## REST

Namespace `/wp-json/f3-pipedrive/v1/`, uma rota por operação, com o mesmo nome.

| Método | Operações |
| --- | --- |
| GET, parâmetros na query | `status`, `documentacao-ler`, `registro-ler`, `retencao-ler`, `pendencias-ler`, `configuracao-ler`, `cadencia-fila`, `auditoria`, `contar-por-campo`, `relatorio` |
| POST, corpo JSON | `recuperacao-previa`, `recuperacao-confirmar`, `retencao-configurar`, `configuracao-simular`, `whatsapp-registrar`, `lead-encerrar`, `negocio-perder`, `lead-arquivado-editar`, `operacao-aplicar`, `api-ler`, `api-previa`, `api-aplicar` |

Autenticação do WordPress com `manage_options`. Cookie administrativo exige o nonce `wp_rest`; senhas de aplicativo exigem HTTPS. As respostas levam `Cache-Control: private, no-store`. O status HTTP é 200 inclusive quando `success` é `false`; só `nao_autorizado` devolve 403. Decida pelo campo `code`.

## Envelope

Toda operação devolve `success`, `code`, `message` e `data`. Conforme a operação, vêm também `remote_dispatched` e `applied` (`true`, `false` ou `null` quando incerto), `previa_id`, `changed` e `persisted`. Os schemas de entrada e o envelope estão em `schemas`.

## Códigos de retorno

**Sucesso.** `ok`, `previa_criada`, `simulacao_criada`, `configuracao_salva`, `operacao_concluida`, `retencao_configurada`, `sem_alteracao`, `recuperacao_revisada` e `recuperacao_confirmada`.

**Sucesso parcial** (`success:true`). `coleta_parcial` e `relatorio_parcial`: leia `data.coleta_completa`, `data.motivos` ou `data.pendencias` antes de usar qualquer número.

| Código | Situação | Próximo passo |
| --- | --- | --- |
| `entrada_invalida`, `corpo_invalido`, `corpo_excedeu_limite`, `json_invalido`, `formulario_incompleto`, `previa_invalida` | Entrada fora do schema ou dos limites. | Corrija e repita. Nada foi enviado. |
| `cursor_invalido` | Cursor da fila expirado, adulterado ou de outro escopo. | Recomece pela primeira página; não misture conta, filtro, limite, instante ou revisão. |
| `parte_invalida` | Parte da ajuda fora do intervalo. | Volte ao índice e abra o início do documento vigente. |
| `formulario_invalido`, `formulario_ocupado`, `entrada_excessiva` | Tentativa do formulário inválida, em andamento ou grande demais. | Confira o resultado no painel antes de abrir outra tentativa; reduza uma entrada que excedeu o tamanho. |
| `catalogo_indisponivel` | O catálogo de sugestões não foi lido. | Verifique o status e as permissões; valide os códigos antes de aplicar. |
| `texto_invalido`, `toque_invalido` | Falta código, mensagem ou referência válida na sequência guiada. | Corrija a linha indicada e valide os campos antes de simular. |
| `caminho_fora_da_lista` | Caminho, método, parâmetro ou chave fora das listas fechadas. | Use `especificacao`. Nada foi enviado. |
| `configuracao_invalida` | Regras fora do schema ou incoerentes. | Corrija o objeto de regras. |
| `configuracao_pendente` | Cadência desabilitada ou sem tipo de atividade. | Configure e habilite as regras. |
| `motivo_invalido` | Motivo fora da lista aprovada das regras. | Use um motivo da lista ou altere as regras. |
| `canal_protegido` | As regras do canal impedem encerrar ou arquivar. | Não contorne por outra rota. |
| `estado_incompativel` | O registro não está no estado exigido pela operação. | Confira o registro. |
| `lead_sem_pessoa` | Criar a atividade exige pessoa vinculada ao lead. | Vincule a pessoa e repita. |
| `toque_incompativel`, `toque_de_encerramento` | O toque não é o próximo reconhecido, ou pede encerramento. | Leia a fila; para encerrar use `lead-encerrar`. |
| `atividade_concluida`, `atividade_whatsapp_duplicada` | Atividade de WhatsApp concluída, ou mais de uma no lead. | Revise as atividades do lead na conta. |
| `opcao_desconhecida`, `opcao_seria_apagada`, `campo_indisponivel`, `registro_nao_encontrado` | Opção ou campo não confere com o catálogo. | Releia o catálogo e ajuste o corpo. |
| `confirmacao_ausente` | Frase literal ausente ou diferente, ou ciência de expurgo não informada. | Copie a frase da prévia depois da ordem do dono. |
| `idempotencia_conflitante` | A chave já pertence a outra mensagem. | Confira a entrada; não troque a chave para reenviar. |
| `operacao_invalida` | A prévia ou o recibo pertence a outra operação. | Use a operação de origem. |
| `documento_invalido`, `documento_indisponivel`, `documento_alterado`, `offset_invalido`, `revisao_exigida` | Leitura de documentação. | Recomece do offset zero com um ID do índice. |
| `revisao_conflitante`, `contexto_alterado`, `estado_alterado` | Regras, conta, autorização ou registro mudaram depois da leitura. | Releia e gere nova prévia. |
| `previa_expirada`, `previa_inexistente`, `previa_indisponivel`, `previa_de_outro_usuario` | A prévia venceu, não existe ou é de outro administrador. | Gere outra com o mesmo usuário. |
| `nao_autorizado` | Falta `manage_options` ou a política da conexão recusou. | Confira o usuário e o perfil da conexão. |
| `core_indisponivel`, `contrato_invalido`, `operacao_nao_autorizada`, `credencial_invalida`, `core_recusou` | O Core não entregou o cliente, não autorizou ou recusou. | Siga o diagnóstico do Core; não tente obter o token. |
| `saldo_conta_baixo`, `orcamento_esgotado`, `pipedrive_orcamento_esgotado`, `core_em_recuperacao`, `pausa_remota`, `rate_limit` | Orçamento, saldo ou pausa. | Aguarde ou ajuste no Core. |
| `coleta_incompleta`, `estado_incompleto`, `resposta_incompleta`, `resposta_excedeu_limite`, `limite_de_leitura` | Resposta incompleta, grande demais ou sem a evidência necessária. | Em GET, confira orçamento e tamanho da página. Após despacho de escrita, preserve o bloqueio; um HTTP 2xx ilegível não prova que nada foi aplicado. |
| `operacao_ocupada`, `retencao_ocupada` | Outra escrita deste plugin está em andamento. | Nada foi enviado. Repita depois de alguns segundos. |
| `fornecedor_recusou`, `operacao_recusada` | O fornecedor recusou com resposta definitiva (HTTP 4xx). | Leia o recibo e as etapas. Só prepare outra tentativa se a recusa e a ausência de efeito estiverem confirmadas. |
| `resultado_incerto`, `resultado_parcial_ou_incerto`, `atividade_nao_confirmada`, `reconciliacao_necessaria` | Pode ter havido efeito na conta. | **Não repita.** Siga `operacao`. |
| `recuperacao_inconclusiva` | A evidência disponível não autoriza realinhamento nem liberação. | Preserve a pendência; confira o registro, as etapas e o acesso da conta. |
| `progresso_divergente`, `progresso_incompativel` | A atividade, sua nota ou as regras mudaram depois do último registro. | Siga `operacao`. |
| `persistencia_falhou` | A prévia não foi gravada. | Nada foi enviado. Repita. |
| `persistencia_incerta` | Uma gravação local não foi confirmada. | Releia o estado antes de repetir. |
| `armazenamento_indisponivel`, `cifra_indisponivel`, `registro_ilegivel`, `retencao_invalida`, `falha_interna` | Banco, OpenSSL, salts ou registro local. | Preserve os dados; confira banco, salts e diário antes de qualquer escrita. |

Em `data.motivos` (fila, auditoria, contagem, simulação) e em `data.pendencias` (relatório) aparecem ainda: `limite_de_coleta`, `limite_de_saida`, `limite_de_grupos`, `paginacao_incompleta`, `colecao_concorrente`, `identidade_ilegivel`, `opcao_ilegivel`, `limite_chamadas`, `limite_tempo`, `limite_registros`, `limite_grupos`, `pagina_invalida`, `paginacao_invalida`, `paginacao_sem_progresso`, além dos códigos do Core. Os motivos por item da fila, entre eles `calendario_sem_prazo`, estão em `fluxos`.

Um código de falha não prova ausência de efeito: confira `remote_dispatched` e `applied`, que podem ser `null`.

## Recibos e repetição

O recibo pertence à operação que o produziu. Para repetir uma aplicação concluída, use a mesma operação: `api-aplicar` para a prévia de `api-previa`; `operacao-aplicar` para a prévia de regras ou de operação composta; `whatsapp-registrar` com a mesma chave e a mesma entrada. A origem é conferida no recibo cifrado, mesmo depois que a linha do diário expirou. Origem diferente devolve `operacao_invalida`; recibo ilegível devolve `registro_ilegivel`.

Em `whatsapp-registrar`, a identidade da mensagem não depende da ordem das propriedades JSON nem da caixa do UUID. O recibo pertence ao administrador que registrou e à conta e revisão do Core daquele momento: outro usuário recebe `previa_de_outro_usuario`, e mudança de conta ou autorização devolve `contexto_alterado`.

## Retenção local

`pipedrive/retencao-ler {}` devolve `diario_dias` (de 0 a 36.500), `diario_sem_prazo`, `recibos_dias` (180), `previas_segundos` (900), `revisao`, `origem` (`padrao` ou `configurado`), `alterado_em` e `alterado_por`. `status` publica o mesmo objeto em `data.retencao`. `registro-ler` devolve `retencao_dias` e `sem_prazo`.

`pipedrive/retencao-configurar` exige `diario_dias` e `revisao_esperada`; prazo positivo exige `confirmar_expurgo: true`. A resposta traz `changed`, `persisted` e a política relida; o mesmo valor devolve `sem_alteracao`. A revisão inclui uma geração aleatória e detecta até o retorno ao valor anterior. Configuração e limpeza compartilham uma trava de banco com espera de 1 segundo.

## Guardas de leitura e de configuração

A simulação vincula a prévia à conta lida. A gravação das regras só substitui os bytes que produziram a revisão analisada: uma prévia criada sobre uma revisão antiga devolve `revisao_conflitante`. Booleanos e inteiros aceitos pelo validador REST são interpretados pelo valor. A leitura de um registro individual exige que o ID devolvido seja o solicitado.

## Referências do fornecedor

Documentação oficial de Leads, LeadLabels, DealFields, Notes, Filters e Activities, e o guia de migração da API v2, consultados entre 23/10/2026 e 06/11/2026:

- [Leads](https://developers.pipedrive.com/docs/api/v1/Leads)
- [LeadLabels](https://developers.pipedrive.com/docs/api/v1/LeadLabels)
- [DealFields](https://developers.pipedrive.com/docs/api/v1/DealFields)
- [Notes](https://developers.pipedrive.com/docs/api/v1/Notes)
- [Filters](https://developers.pipedrive.com/docs/api/v1/Filters)
- [Activities](https://developers.pipedrive.com/docs/api/v1/Activities)
- [Guia de migração da API v2](https://pipedrive.readme.io/docs/pipedrive-api-v2-migration-guide)

Leads e etiquetas usam UUID; etiquetas são lidas pela coleção. A consulta à documentação não equivale a homologação na conta real.
