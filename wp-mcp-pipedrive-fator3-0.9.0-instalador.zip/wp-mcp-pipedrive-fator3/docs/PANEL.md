# Configurar o Pipedrive pelo WordPress — 0.9.0

Abra **Ferramentas → Fator3 MCP Pipedrive** como administrador. Comece na **Visão geral** para conferir a conta e a autorização; a tela não faz uma consulta comercial. Para mudar a sequência de contato, abra **Regras de operação**. Para investigar uma tentativa, use **Diário e retenção**. A **Ajuda** reúne a documentação da versão instalada, mesmo sem acesso ao CRM.

## Habilitar a primeira cadência

1. Na Visão geral, confirme que o Core reconhece o consumidor e que a conta é a esperada. Se a operação estiver desautorizada, siga [Configuração](CONFIGURATION.md). É possível montar o rascunho e validar campos localmente; a simulação usa leituras pelo Core.
2. Em Regras de operação, abra o editor guiado. Escolha fuso, dias úteis, janela e ao menos um período dentro dela. Por exemplo: segunda a sexta, 09:00–18:00, período `manha` às 09:30. Cadastre feriados que devem ser pulados.
3. Informe o **código do tipo de atividade** usado para WhatsApp nessa conta. Não copie o ID numérico nem um rótulo traduzido. Registrar mensagem no plugin grava na atividade; o envio ao contato é feito pelo canal.
4. Cadastre um **texto aprovado**, com código único, por exemplo `abertura`. Cadastre seu primeiro **toque**, com código `primeiro`, base `entrada`, atraso zero e referência ao código `abertura`. Para um segundo contato, adicione outro texto e outro toque, na ordem de execução. Deixe a etiqueta vazia se não há uma etiqueta aprovada para esse toque.
5. Marque para habilitar a cadência e **valide os campos** antes de simular. O validador local confere janela, códigos e referências. Se o texto de um toque não existir, corrija a referência ou cadastre o texto correspondente. Validação local não garante que um tipo ou ID exista no Pipedrive.

Para mais linhas de textos/toques, use **Adicionar linhas para edição**; o fluxo está disponível sem JavaScript. Na área avançada, edite um grupo de regras por vez, ou abra o JSON completo. As variantes de toques existentes são preservadas pelo editor guiado. Em **Consultar tipos, etiquetas e campos na conta**, a consulta é por iniciativa do operador: até três GETs, estimados em 60 unidades locais, com até 100 sugestões por catálogo. Uma lista de sugestões incompleta não prova ausência no CRM.

### Exemplo completo de regras

No editor JSON, leia primeiro a configuração atual. A aplicação substitui o objeto inteiro: omitir exclusões, motivos ou grupos opcionais pode mudar a operação além do desejado. O exemplo abaixo serve para uma instalação de teste; substitua fuso, textos, códigos e motivos pelos aprovados para a sua conta.

```json
{
  "habilitada": true,
  "fuso": "America/Sao_Paulo",
  "dias": [
    1,
    2,
    3,
    4,
    5
  ],
  "janela": {
    "inicio": "09:00",
    "fim": "18:00"
  },
  "periodos": [
    {
      "codigo": "manha",
      "hora": "09:30"
    },
    {
      "codigo": "tarde",
      "hora": "14:30"
    }
  ],
  "toques": [
    {
      "codigo": "primeiro",
      "atraso_minutos": 0,
      "base": "entrada",
      "texto_id": "abertura",
      "etiqueta_id": ""
    },
    {
      "codigo": "segundo",
      "atraso_minutos": 1440,
      "base": "ultimo_registro",
      "texto_id": "retorno",
      "etiqueta_id": ""
    }
  ],
  "textos": [
    {
      "codigo": "abertura",
      "texto": "Texto aprovado da primeira mensagem."
    },
    {
      "codigo": "retorno",
      "texto": "Texto aprovado da segunda mensagem."
    }
  ],
  "tipo_whatsapp": "whatsapp",
  "exclusoes": {
    "etiquetas": [],
    "campos": []
  },
  "archive_reasons": [
    "Sem resposta após cadência"
  ],
  "lost_reasons": [],
  "auditoria": {
    "campos_origem": [],
    "separador_titulo": "",
    "etapas": [],
    "tipos_reuniao": []
  }
}
```

Veja o [guia de fluxos](WORKFLOWS.md) para exclusões, variáveis, regras de canal, calendário e adoção de histórico. A instalação nova começa desabilitada. Os motivos de arquivamento iniciais estão em `regras-iniciais`; nenhum texto de contato ou tipo de atividade vem habilitado.

## Revisar e aplicar

**Validar campos** confere o rascunho sem consultar o fornecedor nem mudar as regras. A página de resultado de um envio pode guardar dados temporários da sua sessão.

**Simular na conta** avalia uma amostra de até 20 leads, com as regras candidatas. Confira quantos leads foram avaliados, quantos têm ação devida, o custo e a validade. Zero devidos em uma amostra não representa necessariamente a conta inteira. Uma leitura insuficiente, falha de autorização ou troca de conta impede a emissão da prévia. A simulação cria apenas uma prévia local.

**Aplicar** grava somente as regras simuladas. Compare os valores em vigor e os propostos, confirme a ordem do responsável e aplique antes do vencimento de 15 minutos. No painel não é preciso digitar a frase de confirmação das **regras**; o MCP e o REST continuam exigindo-a. Editar o rascunho não altera uma prévia já emitida. Para aplicar outros valores, simule outra vez.

Depois do envio, o painel abre o resultado por uma página de leitura. Atualizar a página não reenvia a simulação. O reenvio da mesma tentativa também não cria outra prévia. Se o resultado ainda não estiver disponível, confira o estado e o diário antes de iniciar uma nova ação.

| Situação | Próximo passo |
| --- | --- |
| Revisão conflitante | Outras regras foram salvas; releia, reaplique só a diferença desejada e simule novamente. |
| Coleta incompleta | Veja os motivos da leitura: orçamento, tamanho da resposta, dependência ausente ou limite do pedido. Repetir sem corrigir a causa pode consumir novamente a cota. |
| Prévia expirada, de outro operador ou de conta alterada | Confira a conta na visão geral e gere nova prévia com seu próprio administrador. |
| Resultado incerto em operação comercial | Preserve o recibo; nunca gere outra tentativa para verificar “se foi”. Siga [Operação e recuperação](OPERATIONS.md). |

## Diário, pendências e retenção

Os filtros do diário atuam sobre a página apresentada. Leia a data no fuso local e confira o UTC em caso de dúvida. Expanda as etapas e examine as pendências antes de alterar os dias de conservação. O diário descreve a tentativa; uma atividade ou registro no Pipedrive mostra o estado da conta. Confira alvo, hora, resultado e etapas. Uma linha antiga pode não identificar o registro. Ausência de linha após o prazo de retenção não prova ausência de efeito remoto.

Para uma operação composta bloqueada, consulte as pendências, revise a evidência e confirme apenas a resolução oferecida. Para uma nota de WhatsApp editada, use o UUID do lead. Se não houver prova suficiente ou se a atividade tiver sido substituída, a pendência permanece. A conferência consome GETs; a confirmação registra a decisão neste WordPress e não reenvia a escrita no CRM. O [guia de recuperação](OPERATIONS.md) explica os casos possíveis.

Deixe **Dias de conservação** em 0 para manter o diário sem prazo. Para um prazo finito, informe de 1 a 36.500 dias e confirme a exclusão futura. Salvar não exclui linhas de imediato; aumentar o prazo depois não recupera o que já foi removido. Prévias valem 15 minutos. Recibos comuns duram 180 dias; os de WhatsApp e o progresso permanecem para evitar duplicação.

## Ajuda e uso remoto

Em **Ajuda**, escolha um guia e navegue entre as partes. O JSON de schemas é a referência de parâmetros por operação. A leitura é local e não consome orçamento do Core.

Pelo MCP: `pipedrive/configuracao-ler {}` → `pipedrive/configuracao-simular {regras, revisao_esperada}` → conferir a amostra e os valores → `pipedrive/operacao-aplicar {previa_id, confirmacao}`. Releia a configuração para verificar o resultado. Para obter este guia completo: `pipedrive/documentacao-ler {"documento":"painel"}` e siga os offsets e hashes.
