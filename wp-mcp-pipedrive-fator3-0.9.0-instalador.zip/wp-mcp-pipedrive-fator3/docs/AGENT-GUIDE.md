# Guia para agentes — 0.9.0

Este plugin registra e lê; não envia WhatsApp, não agenda nada e não repete escritas sozinho. Toda operação exige um usuário com `manage_options` e a autorização da conexão MCP.

## Sequência de trabalho

1. **Descobrir.** Liste `pipedrive/*` no catálogo e leia o schema da operação que vai usar.
2. **Ler a ajuda.** `pipedrive/documentacao-ler {}` devolve o índice; leia `contratos` para os códigos de retorno e `fluxos` para as regras.
3. **Diagnosticar.** `pipedrive/status {}` é local. Confira `registro_cliente`, a conta, o usuário, a revisão e o orçamento. `saldo_conta: null` significa saldo desconhecido.
4. **Ler antes de escrever.** Leia o estado do registro e o catálogo de campos. Uma chave personalizada tem 40 hexadecimais; o ID numérico de um campo ou de uma opção não a substitui.
5. **Preparar.** Gere a prévia e confira corpo, efeito e reversibilidade. Para estrutura e para regras, obtenha a ordem do dono antes de copiar a frase de confirmação.
6. **Aplicar uma vez.** Guarde `previa_id`, `code` e as etapas. A repetição usa o mesmo `previa_id`, ou a mesma chave em `whatsapp-registrar`.
7. **Verificar.** Releia o registro e `pipedrive/registro-ler`. Remova, no mesmo trabalho, os registros sintéticos que criou.

## Qual operação usar

| Tarefa | Operações, em ordem |
| --- | --- |
| Saber quem deve receber mensagem agora | `cadencia-fila` |
| Registrar uma mensagem já enviada | `whatsapp-registrar` |
| Encerrar um lead com mensagem final e arquivamento | `lead-encerrar` → `operacao-aplicar` |
| Marcar um negócio como perdido | `negocio-perder` → `operacao-aplicar` |
| Editar um lead arquivado | `lead-arquivado-editar` → `operacao-aplicar` |
| Alterar as regras | `configuracao-ler` → `configuracao-simular` → `operacao-aplicar` |
| Ler um registro ou um catálogo | `api-ler` |
| Alterar campo de lead, nota, etiqueta, filtro ou campo personalizado | `api-previa` → `api-aplicar` |
| Apontar anomalias em leads e negócios | `auditoria` |
| Contar registros por valor de um campo | `contar-por-campo` |
| Agregar leads e negócios de um período | `relatorio` |
| Investigar uma escrita | `registro-ler` |
| Conferir uma pendência ou uma nota divergente | `pendencias-ler` → `recuperacao-previa` → revisar → `recuperacao-confirmar` |
| Ver ou mudar a conservação do diário | `retencao-ler`, `retencao-configurar` |

## Regras que não mudam

- Só chame `whatsapp-registrar` depois que o envio foi confirmado pelo canal. O plugin registra o que já aconteceu.
- Use uma chave de idempotência por mensagem e repita com a mesma chave e os mesmos valores. Trocar a chave para contornar um erro pode duplicar o registro.
- Diante de `resultado_incerto`, `resultado_parcial_ou_incerto`, `atividade_nao_confirmada` ou `reconciliacao_necessaria`, não repita e não gere outra prévia equivalente. Siga o guia `operacao`.
- Não edite a nota da atividade de WhatsApp de um lead em cadência e não exclua essa atividade. Qualquer das duas coisas bloqueia os próximos toques com `progresso_divergente`.
- Use o procedimento de reconciliação do guia `operacao`. Não apague marcadores nem altere opções, recibos ou progresso no banco.
- Não tente obter o token nem chamar a API do Pipedrive por fora do Core. Com `core_indisponivel` ou `operacao_nao_autorizada`, relate ao responsável pelo Core.
- A frase de confirmação não prova a ordem do dono. Tenha a ordem antes de copiá-la.
- Não use a tela de regras para aplicar uma prévia comercial; ela só aplica prévias de configuração.
- Não registre em relatórios, logs ou exemplos os textos devolvidos pela fila: depois das variáveis, eles podem conter dados pessoais.
- Não envie e-mails, avisos, campanhas ou assinaturas como teste.

## Ler respostas parciais

Na fila, verifique `pagina_completa`, `fim_da_fila` e `proximo_cursor`. O filtro `devidos` pode devolver uma lista vazia e ainda haver páginas. Na simulação, leia o alcance em `data.simulacao`; uma prévia válida não prova que toda a conta foi avaliada. Se a leitura da origem falhar, não converta a falha em “zero devidos”. Veja exemplos em [Uso](USAGE.md).

Na auditoria, confira `data.coleta_completa` e `data.avaliacao_completa`: `itens` contém ocorrências confirmadas e `itens_nao_avaliados` identifica as regras sem evidência. No relatório, confira `completo`, `coleta_completa`, `pendencias` e `fontes`. Um contador com sufixo `_observados` pode ser subtotal.

## Custo

Cada GET enviado consome 20 unidades **locais** do orçamento de operação do Core; cada escrita, 10. A quantidade de consultas depende dos registros, do tamanho das respostas e da necessidade de ler detalhes. Confira o custo de cada página. Aumentar `max_chamadas` não amplia o orçamento da conta.

## Depois de um erro

| Código | Onde está o procedimento |
| --- | --- |
| Qualquer um | Tabela de códigos em `contratos` |
| `resultado_incerto`, `resultado_parcial_ou_incerto`, `reconciliacao_necessaria`, `atividade_nao_confirmada` | `operacao`, seção Recuperação |
| `progresso_divergente`, `progresso_incompativel`, `historico_sem_marcador` | `operacao`, seção Recuperação, e `fluxos` |
| `operacao_ocupada`, `retencao_ocupada` | Confira recibo e despacho; aguarde a liberação da trava. Não repita uma etapa externa cujo efeito seja incerto. |
| `revisao_conflitante`, `contexto_alterado`, `estado_alterado` | Releia e gere nova prévia |

## Retenção

Comece por `retencao-ler`. O padrão é `diario_dias: 0`, sem prazo; não proponha prazo menor por economia de espaço. Havendo ordem de prazo finito, explique que o corte usa a data original da linha e envie `confirmar_expurgo: true` com a revisão lida. A configuração não exige autorização comercial e não a concede.

## O que não é prova

Testes com transporte interceptado mostram que o plugin conversa com o cliente do Core; não são aceite da API real. O aceite em conta real é registrado no relatório de entrega. Este pacote não habilita a operação no Core nem a cadência.
