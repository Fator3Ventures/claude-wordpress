# Regras, cadência e operações — 0.9.0

Operações dos Pedidos MCP Pipedrive 4 a 11. Todas exigem administrador, pelo MCP, pelo REST `f3-pipedrive/v1` ou pelo painel. Os tipos completos estão em `schemas`; os códigos de retorno, em `contratos`; a recuperação, em `operacao`.

## Alterar as regras

1. `pipedrive/configuracao-ler {}` devolve `regras`, `revisao` e `origem` (`padrao_pendente` ou `configurado`). Ler não grava as regras iniciais.
2. Monte o objeto `regras` inteiro e chame `configuracao-simular` com `revisao_esperada`. Opcionais: `agora` (RFC3339 UTC), `max_chamadas` e `tempo_maximo_segundos`.
3. A simulação avalia até 20 leads com as regras candidatas. Se a amostra terminar com evidência suficiente (inclusive conta visível comprovadamente vazia), devolve `previa_id`, `expira_em_utc`, `confirmacao_exigida`, regras validadas e `simulacao`. O administrador pode aplicar mesmo que existam outros leads fora da amostra. Autorização ausente, troca de conta ou leitura incompleta não geram prévia.
4. Depois da ordem do dono, chame `operacao-aplicar` com `previa_id` e a frase literal em `confirmacao`.

A aplicação grava somente as regras: não cria etiquetas, atividades nem campos. As regras ficam na opção `f3_pipedrive_operation_rules`. Uma prévia criada sobre uma revisão que já mudou devolve `revisao_conflitante`. Repetir uma aplicação concluída devolve o recibo.

## Grupos de regras

Os doze primeiros grupos são obrigatórios no objeto; os seis últimos são opcionais e, omitidos, saem da configuração.

| Grupo | Conteúdo | Observações |
| --- | --- | --- |
| `habilitada` | booleano | Habilitar exige `dias`, `periodos`, `toques` e `tipo_whatsapp`. |
| `fuso` | identificador IANA | Vale para calendário e para a data da nota. |
| `dias` | lista de 1 (segunda) a 7 (domingo) | Dias úteis da cadência. |
| `janela` | `inicio` e `fim`, `HH:MM` | Mesmo dia; os dois extremos pertencem à janela. |
| `periodos` | até 24 de `{codigo, hora}` | Cada hora dentro da janela. |
| `toques` | até 50, em sequência | `codigo`, `atraso_minutos`, `base` (`entrada` ou `ultimo_registro`), `texto_id`, `etiqueta_id` (UUID ou vazio); opcionais `prazo`, `acao`, `variantes`. |
| `textos` | até 50 de `{codigo, texto}` | Mensagens aprovadas, até 4.000 caracteres. |
| `tipo_whatsapp` | código do tipo de atividade | A existência na conta não é verificada. |
| `exclusoes` | `etiquetas` (UUIDs) e `campos` (`{campo, valores, regra}`) | Lead com etiqueta ou valor listado sai da fila; `regra` vira o motivo. |
| `archive_reasons` | até 100 textos | Motivos aceitos para arquivar lead. |
| `lost_reasons` | até 100 textos | Motivos aceitos para perder negócio; lista vazia impede a perda. |
| `auditoria` | `campos_origem` (até 4 chaves), `separador_titulo`, `etapas` (`{id, alerta_minutos, primeira}`), `tipos_reuniao`; opcional `nome_pessoa` | Parâmetros de `pipedrive/auditoria`. |
| `feriados` | até 366 datas `AAAA-MM-DD` | Dias fora da cadência. |
| `nota` | `prefixo`, `formato`, `autor` | Ausente: `[IA]`, dia/mês e hora, `nós`. |
| `variaveis` | até 50 de `{codigo, campo, parte}` | `parte`: `inteiro` ou `primeiro_nome`. |
| `canais` | até 30 de `{codigo, condicao, permitir_encerramento, permitir_arquivamento}` | As restrições de todas as regras que casam se acumulam. |
| `espera_entrega` | `habilitada`, `condicao`, `campo_desde`, `rever_minutos`, `encerrar_minutos` | A revisão precede o encerramento. |
| `adocao` | `habilitada`, `prefixo`, `autor`, `max_idade_dias`, `toques_por_texto` | Reconhece linhas antigas da nota. |

Uma `condicao` é `{campo, operador, valores}`, com operador `igual`, `presente` ou `ausente`. `igual` compara valores e IDs de opção pela representação textual; `presente` e `ausente` consideram nulo, texto vazio e lista vazia. `campo` é a chave do lead (nativa ou personalizada de 40 hexadecimais), nunca o rótulo. Nenhuma regra comercial de minutos, horas ou dias está fixa no código.

Formatos de `nota.formato`, como devem ser escritos no JSON: `d/m H\\hi`, `d/m/Y H\\hi` e `Y-m-d\\TH:i:sP`.

## Prazos

| `prazo` do toque | Vencimento |
| --- | --- |
| `periodo` (padrão) | Primeiro período, em dia útil, igual ou posterior à base mais `atraso_minutos` corridos. |
| `minutos_uteis` | Base mais `atraso_minutos` contados só dentro da janela, em dias úteis e fora de feriados, sem arredondar a um período. |
| `primeiro_periodo_dia_util_seguinte` | Primeiro período do dia útil seguinte à data local da base; exige `atraso_minutos` zero. |

A base é `add_time` do lead (`entrada`) ou o instante do último registro reconhecido (`ultimo_registro`). Um item só fica devido quando o vencimento já passou **e** o instante consultado está em dia útil, dentro da janela. A busca no calendário cobre dez anos.

## Textos, variantes e variáveis

`variantes` de um toque é uma lista ordenada de `{condicao, texto_id}`: vale a primeira condição que casa; sem nenhuma, vale o `texto_id` do toque. Com `variaveis` presente, cada `{codigo}` do texto é trocado, em uma única passagem, pelo valor do campo mapeado no lead (escalar ou lista de escalares), inteiro ou só o primeiro nome. Variável sem valor bloqueia o item com `variavel_indisponivel`; texto final acima de 16.000 bytes, com `texto_excedeu_limite`. A configuração recusa texto com variável não mapeada. Sem o grupo `variaveis`, os textos são literais. O texto preenchido pode conter dados pessoais.

## Fila

Comece com `pipedrive/cadencia-fila {"limite":20,"filtro":"todos"}`. O limite, de 1 a 200 (padrão 200), conta **leads avaliados**, não mensagens devidas. Para receber somente os devidos, use `filtro:"devidos"`. `agora` fixa o instante RFC3339 UTC. `max_chamadas` (1–120, padrão 100) e `tempo_maximo_segundos` (1–120, padrão 45) limitam a consulta.

Uma página completa traz `avaliados`, `devidos`, `motivos_pagina`, `pagina_completa` e `fim_da_fila`. Se `proximo_cursor` existir, use-o como `cursor` na próxima chamada, mantendo o escopo. Uma página pode avaliar menos leads do que o limite. O cursor é opaco e tem validade de 15 minutos: não o fabrique, não o passe a outro operador e não misture contas, revisões de regra, filtros ou instantes. A lista é consultada ao vivo. Se a posição do último lead mudar, recomece; a paginação não garante uma fotografia imutável da conta.

A quantidade de itens pode ser menor que `limite` por tempo, chamadas ou tamanho da resposta. Ao consultar atividades, o plugin pode aproveitar uma lista curta ou restringir as leituras aos leads da página, sem descartar atividades concluídas. Uma conta pequena e outra com notas longas podem consumir valores diferentes para avaliar o mesmo número de leads.

| Campo do item | Conteúdo |
| --- | --- |
| `lead_id` | UUID do lead. |
| `toque`, `texto_id`, `texto_aprovado` | Próximo toque e seu texto; o texto é nulo quando o item não está devido por falta de variável ou por coleta parcial. |
| `devido`, `devido_em_utc`, `periodo` | Se deve ser contatado agora, o vencimento e o período. |
| `acao` | `mensagem`, `encerrar` ou `verificar_entrega`. |
| `motivo` | Nulo quando devido; caso contrário, um dos códigos abaixo. |
| `politica_canal` | `encerramento`, `arquivamento` e os códigos das regras de canal que casaram. |
| `origem_progresso` | De onde veio o último toque reconhecido. |
| `estado_espera`, `rever_em_utc`, `limite_em_utc` | Presentes na espera de entrega. |

| `motivo` | Significado |
| --- | --- |
| `aguardando_prazo`, `fora_da_janela` | O vencimento ainda não chegou, ou o instante consultado está fora do dia útil ou da janela. |
| `configuracao_pendente` | Cadência desabilitada. |
| `lead_arquivado`, `etiqueta_excluida` | Lead arquivado ou com etiqueta de exclusão. O código de uma regra de `exclusoes.campos` aparece do mesmo modo. |
| `atividade_concluida`, `atividade_whatsapp_duplicada` | A atividade de WhatsApp está concluída, ou há mais de uma. |
| `reconciliacao_necessaria` | Uma escrita anterior tem efeito ainda indeterminado. Consulte as pendências da conta; não contate novamente o lead. |
| `historico_sem_marcador` | A atividade tem nota e nenhum progresso reconhecido. |
| `cadencia_concluida` | Não há toque seguinte. |
| `instante_base_indisponivel`, `instante_entrega_indisponivel` | Falta a data de entrada, do último registro ou do campo da espera. |
| `variavel_indisponivel`, `texto_excedeu_limite` | O texto não pôde ser montado. |
| `canal_protegido` | A ação seria encerrar e o canal não permite. |
| `progresso_divergente`, `progresso_incompativel` | Ver `operacao`. |
| `calendario_sem_prazo` | Não há data possível no calendário configurado. |
| `coleta_incompleta` | A coleta foi parcial: nenhum item é devido. |

Uma página completa com zero devidos pode ser apenas o intervalo que você acabou de avaliar. Se houver falha de fonte, confira os motivos e não use os resultados para contato. `total_visivel` só identifica o alcance observado ao percorrer a fila até o fim; registros que a credencial não enxerga ficam fora. Veja [exemplos de paginação](USAGE.md).

## Progresso da cadência

`origem_progresso` informa a fonte do último toque reconhecido.

| Valor | Fonte |
| --- | --- |
| `registro_local` | Progresso cifrado neste site, gravado junto com o recibo de `whatsapp-registrar`. É a fonte dos registros feitos a partir da 0.8.0. |
| `marcador` | Marcador `[F3PD1:…]` assinado na nota, escrito por versões anteriores. Continua sendo lido e não é removido. |
| `etiqueta_ou_inicio` | Etiqueta de toque (`etiqueta_id`) no lead, ou nenhum toque. A etiqueta indica o toque concluído, sem fornecer o instante. |
| `nota_adotada` | Linha antiga reconhecida pela regra `adocao`. |

O progresso local guarda o ID da atividade e um resumo do texto da nota. Atividade excluída ou substituída, ou texto da nota alterado, produz `progresso_divergente`; a comparação ignora diferenças de HTML e de espaços. Código de toque removido das regras produz `progresso_incompativel`.

**Adoção.** Com `adocao.habilitada`, reconhece linhas de saída no formato `prefixo dd/mm HHhMM, autor: conteúdo`, com ano opcional (`dd/mm/aaaa`). Sem ano, usa o ano atual, ou o anterior quando a data cairia no futuro. Respeita `add_time` e `max_idade_dias` e escolhe a linha válida mais recente. `toques_por_texto` liga um trecho exclusivo a um toque; sem trecho, vale a etiqueta de toque. Texto ambíguo, data inválida, autor diferente ou toque desconhecido não avançam a cadência. A adoção só lê: não altera a nota.

## Espera de entrega

Com `espera_entrega.habilitada` e a condição satisfeita, o item deixa a sequência de toques. O início da espera é o valor de `campo_desde` no lead ou, se vazio, o último registro reconhecido.

| Momento | `acao` | `estado_espera` |
| --- | --- | --- |
| Antes de `rever_minutos` | `verificar_entrega` | `aguardando_verificacao` |
| De `rever_minutos` a `encerrar_minutos` | `verificar_entrega` | `verificar_sem_entrega` |
| A partir de `encerrar_minutos` | `encerrar` | `limite_sem_entrega` |

Os prazos são corridos; a indicação de devido obedece ao calendário. O plugin não conhece recibos de entrega do WhatsApp: quem atualiza o campo é o operador.

## Registrar uma mensagem

`pipedrive/whatsapp-registrar {lead_id, mensagem, toque, chave_idempotencia}`. Use só depois de confirmar o envio pelo canal.

Condições: cadência habilitada; `toque` igual ao próximo toque reconhecido; ação do toque diferente de `encerrar`; no máximo uma atividade do tipo `tipo_whatsapp` no lead, não concluída; sem pendência no lead. Para criar a atividade, o lead precisa de pessoa vinculada (`lead_sem_pessoa`).

O que é escrito:

- Atividade existente: PATCH com a nota anterior mais uma linha e o novo prazo. Os participantes são preservados.
- Atividade ausente: POST com assunto `WhatsApp`, tipo, lead, nota, prazo e `participants: [{person_id, primary: true}]`. `primary` é o parâmetro de escrita da API v2; a resposta pode trazer `primary_flag`.
- A linha tem a forma `prefixo data, autor: mensagem`, com HTML escapado, e não leva marcador nem código.
- O prazo (`due_date` e `due_time`, em UTC) é o vencimento do toque seguinte; depois do último toque, o próximo período.

Depois da escrita, uma leitura confere lead, tipo, nota e conclusão; na criação, confere ainda que a atividade é única e que a pessoa é o único participante principal. Divergência devolve `atividade_nao_confirmada` e deixa pendência. Confirmada a escrita, recibo, diário e progresso são gravados na mesma transação.

A mesma chave, conta e entrada devolvem o recibo original, sem nova escrita. Texto, lead ou toque diferente com a mesma chave devolve `idempotencia_conflitante`. Mais de um recibo possível devolve `reconciliacao_necessaria`. A trava vale entre operações deste plugin: quem escreve direto no fornecedor não a compartilha.

## Encerrar, perder e editar arquivado

As três operações criam uma prévia de 15 minutos; `operacao-aplicar {previa_id}` revalida conta, regras e estado e executa.

| Operação | Exige | Etapas |
| --- | --- | --- |
| `lead-encerrar {lead_id, mensagem, archive_reason}` | Motivo em `archive_reasons`; lead aberto; canal que permita encerrar e arquivar | Linha final e conclusão da atividade (criada se não existir); arquivamento do lead. |
| `negocio-perder {negocio_id, lost_reason}` | Motivo em `lost_reasons`; negócio aberto e fora do arquivo | PATCH com `status: lost`. |
| `lead-arquivado-editar {lead_id, campos}` | Lead arquivado com motivo e data; `campos` da lista do lead, sem `is_archived` nem `archive_reason` | Desarquivar; editar; rearquivar com o motivo original; reler. |

Não há transação entre etapas no fornecedor: uma falha depois da primeira etapa deixa efeito parcial, descrito etapa por etapa no recibo, com `reconciliacao_necessaria: true`. Em `lead-arquivado-editar`, se a edição for recusada, o plugin ainda tenta rearquivar; o recibo traz `rearquivado`, a data original e a nova. As datas de arquivo não são restauradas.

## Auditoria

`pipedrive/auditoria` devolve `itens` (ocorrência confirmada) e `itens_nao_avaliados` (faltou evidência), cada um com `entidade`, `id` e `regra`, sem nomes, e-mails, telefones ou títulos.

| `regra` | Ocorrência |
| --- | --- |
| `origem_ausente_1` a `origem_ausente_4` | Campo de origem vazio, na ordem de `campos_origem`. |
| `sem_proxima_atividade` | Lead sem atividade aberta com data. |
| `titulo_fora_do_padrao` | Título sem as duas partes separadas por `separador_titulo`. |
| `nome_igual_pessoa` | Organização com o mesmo nome da pessoa vinculada. |
| `nome_pessoa_vinculada` | Com `nome_pessoa` habilitada: o nome da organização parece o de uma pessoa vinculada. |
| `etapa_sem_avanco` | Negócio aberto parado além de `alerta_minutos`; a data usada vem em `datas_etapas`. |
| `reuniao_vencida_primeira_etapa` | Reunião passada com o negócio ainda na primeira etapa. |

Motivos de não avaliação: `colecao_atividades_incompleta`, `dados_atividade_invalidos`, `dados_reuniao_invalidos`, `titulo_ilegivel`, `nome_vinculado_indisponivel` e `data_etapa_indisponivel`. Em `motivos` podem aparecer `quatro_campos_origem_nao_configurados`, `regra_titulo_nao_configurada`, `alertas_etapas_nao_configurados`, `etapa_sem_regra`, `contato_vinculado_nao_visivel` e `vinculo_atividade_ilegivel`.

`coleta_completa` indica a cobertura da leitura; `avaliacao_completa` exige também que nenhuma regra tenha ficado sem avaliação. Uma lista de atividades incompleta não prova que um lead esteja sem próxima atividade. Se `stage_change_time` for nulo, a entrada na etapa é `add_time`.

## Contagem por campo

`pipedrive/contar-por-campo {entidade, campo}` aceita `leads`, `negocios`, `pessoas` e `organizacoes`. Leads e negócios somam a coleção ativa e a arquivada. Opções saem como `opcao:ID`; texto livre, como `categoria:` seguido de um HMAC estável por site, conta, entidade e campo; vazio é o grupo `vazio`. Em múltipla escolha cada opção conta uma vez por registro, e a soma pode passar de `total_observado`. Registro com opção ilegível entra no total e em nenhum grupo, com `opcao_ilegivel` em `motivos`.

## Completude e custo

Toda leitura devolve `coleta_completa`, `motivos` e `custo` (`chamadas`, `estimativa_unidades` e `gasto_observado`, que pode incluir consumo concorrente). Estouro de limite, paginação sem fim declarado, cursor repetido, registro repetido, orçamento ou erro tornam a coleta parcial; nenhum total é completado por estimativa. Os limites estão em `especificacao`.

## Interrupção

O recibo de uma operação composta traz `etapas` (com HTTP e código), `entrada_digest` e `reconciliacao_necessaria`. Uma queda pode deixar a operação `running`. Em nenhum caso reexecute às cegas: siga `operacao`.
