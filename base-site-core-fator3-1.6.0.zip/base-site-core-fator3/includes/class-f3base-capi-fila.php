<?php
/** Fila persistente de conversões: reserva atômica, retentativas limitadas e expiração. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Capi_Fila {
	public const TABELA = 'f3base_capi_fila';
	public const EVENTO = 'f3base_capi_recuperar';
	public const TETO_PENDENTES = 1000;
	public const MAX_TENTATIVAS = 6;
	public const PRAZO_RESERVA = 120;
	public const HISTORICO_DIAS = 7;
	public static function tabela(): string { global $wpdb; return $wpdb->prefix . self::TABELA; }
	public static function pronta(): bool {
		global $wpdb; $t = self::tabela();
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) === $t;
	}
	public static function instalar(): bool {
		if ( self::pronta() ) { return true; }
		global $wpdb; $t = self::tabela();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( "CREATE TABLE {$t} (
			record_id varchar(128) NOT NULL,
			payload longtext NOT NULL,
			estado varchar(16) NOT NULL,
			tentativas int unsigned NOT NULL DEFAULT 0,
			proxima bigint unsigned NOT NULL DEFAULT 0,
			expira bigint unsigned NOT NULL,
			atualizado bigint unsigned NOT NULL,
			reserva varchar(64) NOT NULL DEFAULT '',
			http int NOT NULL DEFAULT 0,
			PRIMARY KEY  (record_id),
			KEY pendentes (estado,proxima),
			KEY expiracao (expira)
		) {$wpdb->get_charset_collate()};" );
		return self::pronta();
	}
	public static function planejar(): void {
		if ( ! wp_next_scheduled( self::EVENTO ) ) { wp_schedule_event( time() + MINUTE_IN_SECONDS, 'hourly', self::EVENTO ); }
	}
	public static function inserir( string $id, array $payload, int $ttl ): bool {
		if ( '' === $id || strlen( $id ) > 128 || ! self::instalar() ) { return false; }
		global $wpdb; $t = self::tabela(); $agora = time();
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT record_id FROM {$t} WHERE record_id = %s", $id ) ) ) { return true; }
		if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE payload <> ''" ) >= self::TETO_PENDENTES ) { return false; }
		$ok = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$t} (record_id,payload,estado,tentativas,proxima,expira,atualizado,reserva,http) VALUES (%s,%s,'pendente',0,%d,%d,%d,'',0)", $id, wp_json_encode( $payload ), $agora, $agora + $ttl, $agora ) );
		if ( false !== $ok ) { self::planejar(); }
		return false !== $ok;
	}
	public static function ler( string $id ): ?array {
		if ( ! self::pronta() ) { return null; }
		global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tabela() . ' WHERE record_id = %s', $id ), ARRAY_A ) ?: null;
	}
	public static function reservar( string $id ): ?array {
		if ( ! self::pronta() ) { return null; }
		global $wpdb; $t = self::tabela(); $agora = time(); $reserva = wp_generate_uuid4();
		$ok = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET estado='enviando',reserva=%s,proxima=%d,tentativas=tentativas+1,atualizado=%d WHERE record_id=%s AND estado IN ('pendente','enviando') AND proxima<=%d AND expira>%d AND tentativas<%d", $reserva, $agora + self::PRAZO_RESERVA, $agora, $id, $agora, $agora, self::MAX_TENTATIVAS ) );
		if ( 1 !== $ok ) { return null; }
		$r = self::ler( $id );
		return $r && hash_equals( $reserva, $r['reserva'] ) ? $r : null;
	}
	public static function concluir( array $r, int $http, bool $aceito, bool $temporario ): void {
		global $wpdb; $t = self::tabela(); $agora = time();
		$proxima = $agora + min( 1800, 30 * ( 2 ** max( 0, (int) $r['tentativas'] - 1 ) ) );
		$repetir = ! $aceito && $temporario && (int) $r['tentativas'] < self::MAX_TENTATIVAS && $proxima < (int) $r['expira'];
		$estado = $aceito ? 'entregue' : ( $repetir ? 'pendente' : 'falhou' );
		$ok = $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET estado=%s,payload=%s,proxima=%d,atualizado=%d,http=%d,reserva='' WHERE record_id=%s AND estado='enviando' AND reserva=%s", $estado, $repetir ? $r['payload'] : '', $proxima, $agora, $http, $r['record_id'], $r['reserva'] ) );
		if ( 1 === $ok && $repetir ) { wp_schedule_single_event( $proxima, F3Base_Modulo_Meta_Capi::HOOK, array( $r['record_id'] ) ); }
	}
	public static function recuperar(): void {
		if ( ! self::pronta() ) { return; }
		global $wpdb; $t = self::tabela(); $agora = time();
		$wpdb->query( $wpdb->prepare( "UPDATE {$t} SET estado='expirado',payload='',reserva='',atualizado=%d WHERE estado IN ('pendente','enviando') AND (expira<=%d OR (tentativas>=%d AND proxima<=%d))", $agora, $agora, self::MAX_TENTATIVAS, $agora ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE payload='' AND atualizado<%d", $agora - self::HISTORICO_DIAS * DAY_IN_SECONDS ) );
		if ( '' === F3Base_Modulo_Meta_Capi::token() ) { return; }
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT record_id FROM {$t} WHERE estado IN ('pendente','enviando') AND proxima<=%d AND expira>%d ORDER BY proxima LIMIT 20", $agora, $agora ) ) as $id ) {
			if ( ! wp_next_scheduled( F3Base_Modulo_Meta_Capi::HOOK, array( $id ) ) ) { wp_schedule_single_event( $agora + 1, F3Base_Modulo_Meta_Capi::HOOK, array( $id ) ); }
		}
	}
	/** Diagnóstico administrativo sem o corpo do evento ou credenciais. */
	public static function resumo(): array {
		if ( ! self::pronta() ) { return array(); }
		global $wpdb; $t = self::tabela();
		return (array) $wpdb->get_results( "SELECT estado,COUNT(*) AS eventos,MAX(atualizado) AS ultima_atividade FROM {$t} GROUP BY estado", ARRAY_A );
	}
	public static function remover(): void {
		wp_unschedule_hook( self::EVENTO ); wp_unschedule_hook( F3Base_Modulo_Meta_Capi::HOOK );
		global $wpdb; $wpdb->query( 'DROP TABLE IF EXISTS ' . self::tabela() );
	}
}
