<?php
/** Leitura incremental e temporária do dia atual; nenhuma linha entra no histórico. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Acessos_Atuais {
	public const CACHE = 'f3base_acessos_fotografia';
	public const BYTES_POR_LEITURA = 8388608;
	public const MAX_BYTES_CACHE = 8388608;
	public static function ler(): array {
		$c = F3Base_Modulo_Acessos_Servidor::config();
		$saida = array( 'dia' => wp_date( 'Y-m-d' ), 'atualizado' => time(), 'linhas' => array(), 'erro' => '', 'ignoradas' => 0, 'bytes_lidos' => 0, 'bytes_pendentes' => 0, 'incremental' => false );
		if ( empty( $c['ligado'] ) ) { $saida['erro'] = 'Leitura de hoje desligada junto com a coleta de acessos.'; return $saida; }
		$f = null; $lock = null;
		try {
			$padrao = F3Base_Modulo_Acessos_Servidor::resolver_padrao( $c['padrao_do_log'] ); $pastas = array();
			foreach ( @glob( dirname( $padrao ), GLOB_ONLYDIR ) ?: array() as $pasta ) { $real = @realpath( $pasta ); if ( false !== $real ) { $pastas[ $real ] = true; } }
			if ( count( $pastas ) !== 1 ) { throw new RuntimeException( 'O log atual exige um único diretório acessível deste site. Verifique o padrão de log.' ); }
			$arquivo = key( $pastas ) . '/access.log';
			if ( ! @is_file( $arquivo ) || ! @is_readable( $arquivo ) ) { throw new RuntimeException( 'Log atual ausente ou sem leitura: ' . $arquivo ); }
			$lock = @fopen( get_temp_dir() . 'f3base-atual-' . hash( 'sha256', ABSPATH . $arquivo ) . '.lock', 'c' );
			if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) { throw new RuntimeException( 'Atualização em curso ou trava temporária indisponível. Atualize novamente.' ); }
			$f = @fopen( $arquivo, 'rb' );
			if ( ! $f ) { throw new RuntimeException( 'Não foi possível abrir o log atual.' ); }
			$stat = fstat( $f ); if ( ! $stat ) { throw new RuntimeException( 'Não foi possível inspecionar o log atual.' ); }
			$chave = hash( 'sha256', wp_json_encode( array( $arquivo, $c, $saida['dia'], wp_timezone_string(), F3BASE_PLUGIN_VERSAO ) ) );
			$e = get_transient( self::CACHE );
			$valido = is_array( $e ) && ( $e['chave'] ?? '' ) === $chave && ( $e['ino'] ?? -1 ) === $stat['ino'] && ( $e['dev'] ?? -1 ) === $stat['dev'] && ( $e['offset'] ?? PHP_INT_MAX ) <= $stat['size'];
			if ( $valido ) { $valido = hash_equals( $e['assinatura'], self::assinatura( $f, $e['offset'] ) ); }
			if ( ! $valido ) { $e = array( 'chave' => $chave, 'ino' => $stat['ino'], 'dev' => $stat['dev'], 'offset' => 0, 'agregados' => array(), 'caminhos' => array(), 'n' => 0, 'ignoradas' => 0 ); }
			$saida['incremental'] = $valido;
			$inicio = $e['offset']; fseek( $f, $inicio );
			$restam = min( self::BYTES_POR_LEITURA, $stat['size'] - $inicio );
			$limite = (int) ini_get( 'max_execution_time' );
			$prazo = microtime( true ) + ( $limite > 0 ? max( 1, min( F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA, intdiv( $limite, 3 ) ) ) : F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA );
			$longa = false;
			while ( $restam > 0 && microtime( true ) <= $prazo ) {
				$bruta = fgets( $f, min( 32769, $restam + 1 ) );
				if ( false === $bruta ) { throw new RuntimeException( 'Log atual truncado ou leitura interrompida. Atualize novamente.' ); }
				$restam -= strlen( $bruta ); $saida['bytes_lidos'] += strlen( $bruta );
				if ( ! str_ends_with( $bruta, "\n" ) ) { $longa = true; continue; }
				$e['offset'] = ftell( $f ); ++$e['n'];
				if ( $longa ) { ++$e['ignoradas']; $longa = false; continue; }
				$data = false;
				if ( preg_match( '~^\S+ \S+ \S+ \[([^\]]+)\] ~', $bruta, $m ) ) { $data = DateTimeImmutable::createFromFormat( '!d/M/Y:H:i:s O', $m[1] ); }
				$falhas = DateTimeImmutable::getLastErrors();
				if ( false === $data || ( $falhas && ( $falhas['warning_count'] || $falhas['error_count'] ) ) ) { ++$e['ignoradas']; continue; }
				if ( $data->setTimezone( wp_timezone() )->format( 'Y-m-d' ) !== $saida['dia'] ) { continue; }
				$r = F3Base_Modulo_Acessos_Servidor::linha( $bruta, $c['caminhos_excluidos'] );
				if ( null === $r ) { ++$e['ignoradas']; continue; }
				$a = $r['agente']; $p = $r['caminho'];
				if ( '' !== $p ) {
					if ( ! isset( $e['caminhos'][ $a ][ $p ] ) && count( $e['caminhos'][ $a ] ?? array() ) >= F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA ) { $r['caminho'] = ''; $r['classe_caminho'] = 'outro'; }
					else { $e['caminhos'][ $a ][ $p ] = true; }
				}
				$k = wp_json_encode( array_slice( $r, 0, 5 ) );
				if ( isset( $e['agregados'][ $k ] ) ) { ++$e['agregados'][ $k ]['contagem']; } else { $e['agregados'][ $k ] = $r; }
				if ( count( $e['agregados'] ) > F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS ) { throw new RuntimeException( 'Teto de agregados do log atual excedido. Use coleta externa para este volume.' ); }
			}
			if ( $e['offset'] === $inicio && $saida['bytes_lidos'] >= self::BYTES_POR_LEITURA ) { throw new RuntimeException( 'Linha incompleta excedeu o orçamento de leitura do log atual.' ); }
			clearstatcache( true, $arquivo ); $agora = @stat( $arquivo );
			if ( ! $agora || $agora['ino'] !== $stat['ino'] || $agora['dev'] !== $stat['dev'] || $agora['size'] < $stat['size'] || wp_date( 'Y-m-d' ) !== $saida['dia'] ) { delete_transient( self::CACHE ); throw new RuntimeException( 'Log atual rotacionado, truncado ou dia alterado durante a leitura. Atualize novamente.' ); }
			if ( $e['ignoradas'] > $e['n'] / 2 ) { throw new RuntimeException( 'Formato do log atual não reconhecido na maioria das linhas.' ); }
			$e['assinatura'] = self::assinatura( $f, $e['offset'] );
			if ( strlen( serialize( $e ) ) <= self::MAX_BYTES_CACHE ) { set_transient( self::CACHE, $e, DAY_IN_SECONDS ); }
			else { delete_transient( self::CACHE ); throw new RuntimeException( 'Fotografia temporária excedeu o limite de memória; use coleta externa para este volume.' ); }
			$saida['linhas'] = array_values( $e['agregados'] ); $saida['ignoradas'] = $e['ignoradas'];
			$saida['bytes_pendentes'] = max( 0, $stat['size'] - $e['offset'] );
		} catch ( Throwable $erro ) { $saida['erro'] = $erro->getMessage(); }
		finally { if ( is_resource( $f ) ) { fclose( $f ); } if ( is_resource( $lock ) ) { flock( $lock, LOCK_UN ); fclose( $lock ); } }
		return $saida;
	}
	/** Confere começo e fronteira já lida; identifica rotação por cópia e truncamento. */
	private static function assinatura( $f, int $offset ): string {
		fseek( $f, 0 ); $primeiro = $offset > 0 ? fread( $f, min( 256, $offset ) ) : '';
		fseek( $f, max( 0, $offset - 256 ) ); $ultimo = $offset > 0 ? fread( $f, min( 256, $offset ) ) : '';
		return hash( 'sha256', $primeiro . '|' . $ultimo );
	}
}
