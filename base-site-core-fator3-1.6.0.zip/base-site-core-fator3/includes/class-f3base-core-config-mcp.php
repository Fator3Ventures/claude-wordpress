<?php
/** Configuração persistente do Core, com schema, simulação e revisão concorrente. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Core_Config_Mcp {
	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) { return; }
		$nomes = array_keys( array_filter( F3Base_Options::catalogo(), static fn( $d ) => ! empty( $d['operavel'] ) ) );
		$nome = array( 'type' => 'string', 'enum' => $nomes );
		$comum = array( 'category' => F3BASE_PREFIXO, 'permission_callback' => static fn( $entrada = null ) => current_user_can( 'manage_options' ), 'output_schema' => array( 'type' => 'object' ) );
		wp_register_ability( 'f3base/config-core-ler', array_merge( $comum, array(
			'label' => 'Ler configuração persistente do Core',
			'description' => 'Lê valores operáveis, revisão opaca, origem e schema do próprio Core; segredos são mascarados. Independe do implantador.',
			'input_schema' => array( 'type' => 'object', 'properties' => array( 'nome' => $nome ), 'additionalProperties' => false ),
			'execute_callback' => array( __CLASS__, 'ler' ),
		) ) );
		wp_register_ability( 'f3base/config-core-escrever', array_merge( $comum, array(
			'label' => 'Simular ou aplicar configuração persistente do Core',
			'description' => 'Altera uma option por chamada. Envie o valor completo e a revisão retornada pela leitura. Simular é o padrão; simular=false aplica por comparação atômica. Normalizações são mostradas; segredos nunca são devolvidos.',
			'input_schema' => array( 'type' => 'object', 'properties' => array( 'nome' => $nome, 'valor' => array( 'description' => 'Valor completo conforme o schema da option.' ), 'revisao_esperada' => array( 'type' => 'string', 'pattern' => '^[a-f0-9]{64}$' ), 'simular' => array( 'type' => 'boolean', 'default' => true ) ), 'required' => array( 'nome', 'valor', 'revisao_esperada' ), 'additionalProperties' => false ),
			'execute_callback' => array( __CLASS__, 'escrever' ),
		) ) );
	}
	public static function ler( $entrada = array() ): array {
		if ( ! current_user_can( 'manage_options' ) ) { return array( 'ok' => false, 'codigo' => 'sem_permissao' ); }
		$saida = array(); $pedido = is_array( $entrada ) ? (string) ( $entrada['nome'] ?? '' ) : '';
		foreach ( F3Base_Options::catalogo() as $nome => $d ) {
			if ( ! F3Base_Options::operavel( $nome ) || ( '' !== $pedido && $pedido !== $nome ) ) { continue; }
			$schema = array_intersect_key( $d, array_flip( array( 'rotulo', 'descricao', 'campo', 'subcampos', 'opcoes', 'impacto', 'exemplo' ) ) );
			$foto = F3Base_Options::fotografia( $nome );
			$saida[ $nome ] = array( 'valor' => self::visivel( $nome, $foto['valor'] ), 'revisao' => $foto['revisao'], 'origem' => F3Base_Options::proveniencia( $nome ), 'schema' => self::schema_valor( $d ), 'campos' => $schema );
		}
		return array( 'ok' => '' === $pedido || isset( $saida[ $pedido ] ), 'opcoes' => $saida );
	}
	private static function schema_valor( array $d ): array {
		$tipo = $d['tipo'] ?? ( $d['campo'] ?? 'texto' );
		if ( 'grupo' === $tipo ) {
			$props = array(); foreach ( $d['subcampos'] ?? array() as $k => $campo ) { $props[ $k ] = self::schema_valor( $campo ); }
			return array( 'type' => 'object', 'properties' => $props, 'additionalProperties' => true );
		}
		if ( 'booleano' === $tipo ) { return array( 'type' => 'boolean' ); }
		if ( 'inteiro' === $tipo ) { return array( 'type' => 'integer' ); }
		if ( in_array( $tipo, array( 'lista','lista_texto','tipos_conteudo','multiselect','multiescolha','json' ), true ) ) { return array( 'type' => 'array' ); }
		return array( 'type' => 'string' );
	}

	private static function visivel( string $nome, $valor ) {
		return F3Base_Options::e_segredo( $nome ) ? array( 'configurado' => '' !== (string) $valor, 'mascarado' => true ) : $valor;
	}
	public static function escrever( $entrada ): array {
		if ( ! current_user_can( 'manage_options' ) ) { return array( 'ok' => false, 'codigo' => 'sem_permissao' ); }
		$nome = is_array( $entrada ) && is_string( $entrada['nome'] ?? null ) ? $entrada['nome'] : '';
		if ( ! F3Base_Options::operavel( $nome ) || ! array_key_exists( 'valor', $entrada ) ) { return array( 'ok' => false, 'codigo' => 'option_nao_operavel' ); }
		$foto = F3Base_Options::fotografia( $nome ); $revisao = $foto['revisao']; $esperada = $entrada['revisao_esperada'] ?? '';
		if ( ! is_string( $esperada ) || ! hash_equals( $revisao, $esperada ) ) { if ( false === ( $entrada['simular'] ?? true ) ) { F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'conflito' ); } return array( 'ok' => false, 'codigo' => 'conflito', 'motivo' => 'A configuração mudou; leia novamente antes de aplicar.' ); }
		$d = F3Base_Options::declaracao( $nome );
		$validacao = rest_validate_value_from_schema( $entrada['valor'], self::schema_valor( $d ), $nome );
		if ( is_wp_error( $validacao ) ) {
			if ( false === ( $entrada['simular'] ?? true ) ) { F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'tipo_invalido' ); }
			return array( 'ok' => false, 'codigo' => 'tipo_invalido', 'motivo' => 'Tipo incompatível com o schema da option.' );
		}
		$recusa = F3Base_Options::recusar( $nome, $entrada['valor'], $d );
		if ( '' !== $recusa ) {
			if ( false === ( $entrada['simular'] ?? true ) ) { F3Base_Options::registrar_tentativa_recusada( $nome, F3Base_Options::ORIGEM_MANUAL, 'valor_recusado' ); }
			return array( 'ok' => false, 'codigo' => 'valor_recusado', 'motivo' => F3Base_Options::e_segredo( $nome ) ? 'Valor secreto recusado.' : $recusa );
		}
		$ajuste = F3Base_Options::ajustar_na_escrita( $nome, F3Base_Options::sanitizar( $nome, $entrada['valor'] ), $d );
		$valor = $ajuste['valor'];
		if ( $entrada['simular'] ?? true ) {
			return array( 'ok' => true, 'simulado' => true, 'nome' => $nome, 'revisao' => $revisao, 'antes' => self::visivel( $nome, $foto['valor'] ), 'depois' => self::visivel( $nome, $valor ), 'motivo' => F3Base_Options::e_segredo( $nome ) ? 'Valor secreto preservado na simulação.' : trim( implode( ' ', $ajuste['avisos'] ) . ' ' . F3Base_Options::aviso_de_normalizacao( $nome, $entrada['valor'], $valor ) ) );
		}
		$r = F3Base_Options::gravar( $nome, $entrada['valor'], F3Base_Options::ORIGEM_MANUAL, $esperada );
		$r['lido'] = self::visivel( $nome, $r['lido'] ); $r['revisao'] = F3Base_Options::revisao( $nome );
		if ( F3Base_Options::e_segredo( $nome ) && ! empty( $r['ok'] ) ) { $r['motivo'] = ''; }
		return $r;
	}
}
