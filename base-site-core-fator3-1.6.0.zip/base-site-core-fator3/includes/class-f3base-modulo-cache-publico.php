<?php
/** Cache versionado de conteúdo público, invalidado pelas mudanças do WordPress. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Modulo_Cache_Publico extends F3Base_Modulo {
	public const GERACAO = 'f3base_publico_geracao';
	public const TTL = 300;
	public const MAX_BYTES = 4194304;
	public function id(): string { return 'cache-publico'; }
	public function nome(): string { return 'Cache de conteúdo público'; }
	public function descricao(): string { return 'Atualiza o índice de caminhos e os textos llms quando conteúdo, visibilidade ou configuração mudam.'; }
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}
	protected function calcular_estado(): array { return $this->ativo( 'Cache com invalidação por publicação, exclusão, metadados, taxonomias e opções de conteúdo.' ); }
	public function hooks(): array {
		return array(
			array( 'tipo' => 'action', 'hook' => 'save_post', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'deleted_post', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'trashed_post', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'untrashed_post', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'added_post_meta', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'updated_post_meta', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'deleted_post_meta', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'set_object_terms', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'edited_term', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'delete_term', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'switch_theme', 'metodo' => 'invalidar', 'prioridade' => 100, 'args' => 0 ),
			array( 'tipo' => 'action', 'hook' => 'updated_option', 'metodo' => 'opcao_alterada', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'added_option', 'metodo' => 'opcao_alterada', 'prioridade' => 100, 'args' => 1 ),
			array( 'tipo' => 'action', 'hook' => 'deleted_option', 'metodo' => 'opcao_alterada', 'prioridade' => 100, 'args' => 1 ),
		);
	}
	public function opcao_alterada( string $nome ): void {
		if ( in_array( $nome, array( 'home', 'siteurl', 'blogname', 'blogdescription', 'blog_public', 'show_on_front', 'page_on_front', 'page_for_posts', 'permalink_structure', 'category_base', 'tag_base', 'active_plugins', 'f3base_llms', 'f3base_robots', 'f3base_redirects' ), true ) || str_starts_with( $nome, 'wpseo' ) ) { self::invalidar(); }
	}
	public static function invalidar(): void { set_transient( self::GERACAO, wp_generate_uuid4(), DAY_IN_SECONDS ); }
	public static function geracao(): string {
		$g = get_transient( self::GERACAO );
		if ( ! is_string( $g ) || '' === $g ) { self::invalidar(); $g = get_transient( self::GERACAO ); }
		return is_string( $g ) ? $g : wp_generate_uuid4();
	}
	public static function lembrar( string $chave, callable $gerar ) {
		$g = self::geracao();
		$contexto = array( $g, F3BASE_PLUGIN_VERSAO, home_url( '/' ), get_locale(), get_option( 'permalink_structure' ), apply_filters( 'f3base_cache_contexto', '' ) );
		$nome = 'f3base_publico_' . hash( 'sha256', $chave . wp_json_encode( $contexto ) );
		$cache = get_transient( $nome );
		if ( is_array( $cache ) && array_key_exists( 'valor', $cache ) ) { return $cache['valor']; }
		$valor = $gerar();
		if ( $g === self::geracao() && strlen( serialize( $valor ) ) <= self::MAX_BYTES ) { set_transient( $nome, array( 'valor' => $valor ), self::TTL ); }
		return $valor;
	}
}
