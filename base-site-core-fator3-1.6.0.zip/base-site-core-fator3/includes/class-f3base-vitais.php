<?php
/** Amostras de Web Vitals por carregamento, atualizáveis e sem identidade de visitante. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Vitais {
	public const TABELA = 'f3base_vitais';
	public const BIBLIOTECA = '6.2.1-f3.1';
	public const TETO_AMOSTRAS = 75000;
	public const MAX_ATUALIZACOES = 60;
	public static function tabela(): string { global $wpdb; return $wpdb->prefix . self::TABELA; }
	public static function pronta(): bool {
		global $wpdb; $t = self::tabela();
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) === $t;
	}
	public static function instalar(): void {
		global $wpdb; $t = self::tabela();
		if ( ! self::pronta() ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( "CREATE TABLE {$t} (
				amostra char(64) NOT NULL,
				dia date NOT NULL,
				caminho varchar(760) NOT NULL,
				metrica varchar(8) NOT NULL,
				dispositivo varchar(16) NOT NULL,
				sequencia int unsigned NOT NULL,
				valor double NOT NULL,
				PRIMARY KEY  (amostra),
				KEY periodo (dia,metrica,dispositivo),
				KEY pagina (caminho(190))
			) {$wpdb->get_charset_collate()};" );
		}
		if ( ! get_transient( 'f3base_vitais_limpeza' ) && self::pronta() ) {
			$corte = gmdate( 'Y-m-d', time() - ( F3Base_Modulo_Comportamento::retencao_eventos_dias() - 1 ) * DAY_IN_SECONDS );
			if ( false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE dia<%s", $corte ) ) ) { set_transient( 'f3base_vitais_limpeza', true, HOUR_IN_SECONDS ); }
		}
	}
	public static function amostra_valida( $a ): bool {
		return is_array( $a ) && count( $a ) === 3 && is_string( $a['id'] ?? null ) && preg_match( '/^[a-zA-Z0-9_-]{8,80}$/D', $a['id'] ) && in_array( $a['dispositivo'] ?? '', array( 'movel', 'desktop' ), true ) && is_int( $a['sequencia'] ?? null ) && $a['sequencia'] >= 1 && $a['sequencia'] <= self::MAX_ATUALIZACOES;
	}
	public static function gravar( string $dia, string $caminho, array $linha ): bool {
		if ( ! self::pronta() ) { return false; }
		global $wpdb; $t = self::tabela(); $a = $linha['amostra'];
		$id = hash( 'sha256', $caminho . '|' . $linha['detalhe'] . '|' . $a['id'] );
		$existe = $wpdb->get_var( $wpdb->prepare( "SELECT amostra FROM {$t} WHERE amostra=%s", $id ) );
		if ( ! $existe ) {
			if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t}" ) >= self::TETO_AMOSTRAS ) { return false; }
			$ok = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$t} (amostra,dia,caminho,metrica,dispositivo,sequencia,valor) VALUES (%s,%s,%s,%s,%s,%d,%f)", $id, $dia, $caminho, $linha['detalhe'], $a['dispositivo'], $a['sequencia'], $linha['soma'] ) );
			if ( false === $ok ) { return false; }
			if ( 1 === $ok ) { return true; }
		}
		// Retransmissões e lotes fora de ordem não aumentam a amostra nem substituem o valor mais novo.
		return false !== $wpdb->query( $wpdb->prepare( "UPDATE {$t} SET valor=%f,sequencia=%d WHERE amostra=%s AND sequencia<%d", $linha['soma'], $a['sequencia'], $id, $a['sequencia'] ) );
	}
	public static function estatisticas( int $dias, string $caminho = '', string $dispositivo = '' ): array {
		if ( ! self::pronta() ) { return array(); }
		global $wpdb; $t = self::tabela();
		$dias = max( 1, min( $dias, F3Base_Modulo_Comportamento::retencao_eventos_dias() ) );
		$where = $wpdb->prepare( 'dia >= %s AND dia <= %s', gmdate( 'Y-m-d', time() - ( $dias - 1 ) * DAY_IN_SECONDS ), gmdate( 'Y-m-d' ) );
		if ( '' !== $caminho ) { $where .= $wpdb->prepare( ' AND caminho=%s', $caminho ); }
		if ( in_array( $dispositivo, array( 'movel','desktop' ), true ) ) { $where .= $wpdb->prepare( ' AND dispositivo=%s', $dispositivo ); }
		$out = array();
		foreach ( (array) $wpdb->get_results( "SELECT metrica,COUNT(*) AS amostras FROM {$t} WHERE {$where} GROUP BY metrica", ARRAY_A ) as $r ) {
			$offset = max( 0, (int) ceil( (int) $r['amostras'] * 0.75 ) - 1 );
			$r['p75'] = (float) $wpdb->get_var( $wpdb->prepare( "SELECT valor FROM {$t} WHERE {$where} AND metrica=%s ORDER BY valor,amostra LIMIT 1 OFFSET %d", $r['metrica'], $offset ) );
			$r['amostras'] = (int) $r['amostras']; $out[] = $r;
		}
		return $out;
	}
	public static function render( int $dias ): void {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		if ( ! self::pronta() ) { echo '<div class="notice notice-error inline"><p>Armazenamento de Web Vitals indisponível. As amostras permanecem pendentes no navegador dentro do prazo da visita.</p></div>'; return; }
		$caminho = isset( $_GET['vital_pagina'] ) && is_string( $_GET['vital_pagina'] ) ? substr( wp_unslash( $_GET['vital_pagina'] ), 0, 760 ) : '';
		$dispositivo = isset( $_GET['vital_dispositivo'] ) && in_array( $_GET['vital_dispositivo'], array( 'movel','desktop' ), true ) ? $_GET['vital_dispositivo'] : '';
		echo '<section class="f3base-bloco"><h2>Web Vitals — percentil 75</h2><form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="dias" value="' . esc_attr( (string) $dias ) . '"><label>Caminho <input name="vital_pagina" placeholder="/servicos/" value="' . esc_attr( $caminho ) . '"></label> <label>Tela <select name="vital_dispositivo">';
		foreach ( array( ''=>'Todas', 'movel'=>'Móvel', 'desktop'=>'Desktop' ) as $k=>$v ) { printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $dispositivo,$k,false ), esc_html( $v ) ); }
		echo '</select></label> <button class="button">Atualizar</button></form><p>Um último valor por métrica e carregamento, calculado pela biblioteca oficial. Retentativas não duplicam amostras. O dispositivo é estimado pela largura da tela. O período respeita a retenção do registro detalhado; dados antigos sem amostras individuais não permitem reconstruir percentis.</p><table class="widefat striped"><thead><tr><th>Métrica</th><th>Percentil 75</th><th>Amostras</th></tr></thead><tbody>';
		$rows = self::estatisticas( $dias, $caminho, $dispositivo );
		foreach ( $rows as $r ) { printf( '<tr><td>%s</td><td>%s%s</td><td>%d</td></tr>', esc_html( $r['metrica'] ), esc_html( number_format_i18n( $r['p75'], 'CLS' === $r['metrica'] ? 3 : 0 ) ), 'CLS' === $r['metrica'] ? '' : ' ms', $r['amostras'] ); }
		if ( ! $rows ) { echo '<tr><td colspan="3">Sem amostras neste filtro.</td></tr>'; }
		echo '</tbody></table></section>';
	}
	public static function remover(): void { global $wpdb; $wpdb->query( 'DROP TABLE IF EXISTS ' . self::tabela() ); }
}
