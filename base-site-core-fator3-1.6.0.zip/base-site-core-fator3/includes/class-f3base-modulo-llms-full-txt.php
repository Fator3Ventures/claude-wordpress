<?php
/**
 * Módulo llms-full-txt.
 *
 * Rota virtual `/llms-full.txt` com o TEXTO INTEGRAL de cada item selecionado.
 * Mesma seleção, mesmas exclusões e mesma precedência de emissor do índice
 * curto: a regra mora em `F3Base_Llms` e no módulo `llms-txt-reserva`, e este
 * módulo a CONSULTA — dois arquivos que listassem conjuntos diferentes seriam
 * dois vereditos sobre o mesmo site.
 *
 * DESLIGADO POR PADRÃO, e a chave é `bots_ia.llms_full_txt`. Com ela desligada o
 * módulo fecha INATIVO: nenhum hook é registrado, a rota não existe e não há
 * superfície pública nenhuma — a mesma física da chave-mestra do llms.txt. O
 * arquivo reúne o corpo integral dos itens selecionados em Markdown, sem
 * aplicar o limite de palavras do índice. A chave operável é f3base_llms.full.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Texto integral em /llms-full.txt.
 */
final class F3Base_Modulo_Llms_Full_Txt extends F3Base_Modulo {

	/**
	 * Caminho público do recurso.
	 */
	public const CAMINHO = '/llms-full.txt';

	/**
	 * CARIMBO PRÓPRIO desta rota, e o carimbo do índice curto é outro.
	 *
	 * Até a 1.0.1 as duas rotas gravavam `F3Base_Atividade::ULTIMO_LLMS`: a
	 * resposta de um endereço apagava a do outro, e a tela mostrava uma única
	 * linha de "última resposta" que ora falava do índice, ora do texto
	 * integral, sem dizer qual. Dois endereços públicos são duas atividades.
	 */
	public const ATIVIDADE = 'ultimo_llms_full_servido';

	/**
	 * Quem respondeu, para o cabeçalho `X-F3Base-Mecanismo`.
	 */
	public const MECANISMO = 'rota-texto-integral';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'llms-full-txt';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Texto integral em llms-full.txt', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Serve /llms-full.txt com o conteúdo integral em Markdown de cada item que o llms.txt lista — mesma seleção, mesmas exclusões e mesma precedência de emissor. Desligado por padrão. Reúne os textos completos dos itens selecionados, sem o corte de palavras usado no índice.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_servir',
				'prioridade' => 0,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$emissor = self::emissor();

		return array(
			array(
				'rotulo'   => __( 'Endereço público sem outro dono', 'f3base' ),
				'presente' => (bool) $emissor['serve'],
				'detalhe'  => (string) $emissor['motivo'],
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( self::ATIVIDADE, __( 'Última resposta pela rota de texto integral', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( ! F3Base_Llms::site_publico() ) { return $this->inativo( 'Publicação de llms suspensa pela visibilidade do site.' ); }
		if ( empty( $config['ligado'] ) ) {
			return $this->inativo(
				__( 'recurso llms.txt desligado na configuração de bots de IA: sem o índice curto não há texto integral a publicar, e nenhum hook é registrado.', 'f3base' )
			);
		}

		if ( empty( $config['full'] ) ) {
			return $this->inativo(
				__( 'texto integral desligado na configuração: nenhum hook, nenhuma rota e nenhuma superfície pública. O arquivo publica uma segunda cópia integral do site em texto puro — o custo é certo e o ganho é hipótese —, e ligar a chave o faz existir na requisição seguinte, sem release nova.', 'f3base' )
			);
		}

		$emissor = self::emissor();

		if ( ! $emissor['serve'] ) {
			return $this->ativo( (string) $emissor['motivo'] );
		}

		$itens = F3Base_Modulo_Llms_Txt_Reserva::selecao( $config );

		if ( array() === $itens ) {
			return $this->degradado(
				__( 'ligado e sem item nenhum a publicar: a rota responderia só com o cabeçalho do site. Preencha a seleção curada ou publique conteúdo dos tipos declarados.', 'f3base' )
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: número de itens com texto integral. */
				_n( 'respondendo no endereço público com o texto integral de %d item.', 'respondendo no endereço público com o texto integral de %d itens.', count( $itens ), 'f3base' ),
				count( $itens )
			)
		);
	}

	/**
	 * Serve a rota quando ela é a responsável pelo endereço.
	 *
	 * @return void
	 */
	public function talvez_servir(): void {
		if ( ! F3Base_Modulo_Llms_Txt_Reserva::requisicao_de( self::CAMINHO ) ) {
			return;
		}

		$config = $this->config();

		if ( empty( $config['ligado'] ) || empty( $config['full'] ) || ! F3Base_Llms::site_publico() ) {
			return;
		}

		if ( ! self::emissor()['serve'] ) {
			return;
		}

		$itens    = F3Base_Modulo_Llms_Txt_Reserva::selecao( $config );
		$conteudo = F3Base_Modulo_Cache_Publico::lembrar( 'llms-full:' . hash( 'sha256', wp_json_encode( array( $itens, $config ) ) ), static fn() => self::montar( $itens, $config ) );

		F3Base_Atividade::registrar(
			self::ATIVIDADE,
			array(
				'bytes'     => strlen( $conteudo ),
				'itens'     => count( $itens ),
				'respondeu' => self::MECANISMO,
			)
		);

		if ( ! headers_sent() ) { header( 'Link: <' . F3Base_Llms::url_markdown( home_url( '/llms.txt' ) ) . '>; rel="describedby"', false ); }
		F3Base_Modulo_Llms_Txt_Reserva::responder( $conteudo, $config, self::MECANISMO );
	}

	/**
	 * Monta o texto integral. Regra pura sobre itens já selecionados.
	 *
	 * Cada item sai com título, URL, data e o corpo em Markdown, SEM CORTE: formulário, script, estilo,
	 * navegação, botão e SVG não são texto do site.
	 *
	 * O CORTE NÃO É PEDIDO COM UM TETO ENORME, e é aí que morava o defeito: até
	 * a 1.0.1 esta função chamava `resumo_limpo( $corpo, PHP_INT_MAX )`, e
	 * `wp_trim_words()` repassa `$palavras + 1` a `preg_split()` — `PHP_INT_MAX
	 * + 1` é float, e o PHP 8.1+ derruba a requisição com `TypeError`. A rota
	 * pública respondia 500 assim que a chave `full` era ligada. Quem não corta
	 * chama `F3Base_Llms::markdown()`, que preserva a estrutura sem corte.
	 *
	 * @param array<int,array<string,mixed>> $itens  Itens selecionados e ordenados.
	 * @param array<string,mixed>            $config Configuração normalizada.
	 * @return string
	 */
	public static function montar( array $itens, array $config ): string {
		$linhas   = array();
		$linhas[] = '# ' . ( F3Base_Llms::texto_markdown( (string) get_bloginfo( 'name' ) ) ?: 'Site' );
		$linhas[] = '';

		/* A MESMA precedência do índice curto, e ela mora num lugar só. */
		$frase = F3Base_Modulo_Llms_Txt_Reserva::primeira_frase( $config, (string) get_bloginfo( 'description' ) );

		if ( '' !== $frase ) {
			$linhas[] = '> ' . F3Base_Llms::texto_markdown( $frase );
			$linhas[] = '';
		}

		foreach ( $itens as $item ) {
			$url = F3Base_Llms::url_markdown( (string) ( $item['url'] ?? '' ) );

			if ( '' === $url ) {
				continue;
			}

			$titulo = isset( $item['titulo'] ) ? trim( (string) $item['titulo'] ) : '';

			$linhas[] = '## ' . F3Base_Llms::texto_markdown( '' !== $titulo ? $titulo : $url );
			$linhas[] = 'URL: ' . F3Base_Llms::url_markdown( $url );

			$data = isset( $item['data'] ) ? trim( (string) $item['data'] ) : '';

			if ( '' !== $data ) {
				$linhas[] = 'Data: ' . F3Base_Llms::texto_markdown( $data );
			}

			$linhas[] = '';

			$corpo = isset( $item['conteudo'] ) ? (string) $item['conteudo'] : '';
			$corpo = '' !== trim( $corpo )
				? F3Base_Llms::markdown( $corpo, $url, 3 )
				: F3Base_Llms::texto_markdown( (string) ( $item['descricao'] ?? '' ) );

			if ( '' !== $corpo ) {
				$linhas[] = $corpo;
				$linhas[] = '';
			}
		}

		return implode( "\n", $linhas ) . "\n";
	}

	public static function emissor(): array {
		$fisico = F3Base_Llms::arquivo_publico( 'llms-full.txt' );
		if ( '' !== $fisico ) { return F3Base_Llms::veredito_do_emissor( true, $fisico, false, '' ); }
		return F3Base_Modulo_Llms_Txt_Reserva::emissor();
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_llms' );

		return is_array( $config ) ? $config : array();
	}
}
