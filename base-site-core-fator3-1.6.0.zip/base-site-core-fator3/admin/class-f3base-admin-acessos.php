<?php
/** Aba Acessos: consultas limitadas, com totais independentes do limite da tela. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Admin_Acessos {
	public const TETO_PAGINAS = 300;
	public const PERIODOS = array( 1, 2, 3, 4, 5, 6, 7, 15, 30, 60, 90 );
	public const CLASSIFICACOES = array( 'conteudo' => 'Páginas, artigos e descoberta', 'paginas' => 'Somente páginas e artigos', 'descoberta' => 'Arquivos de descoberta', 'inexistentes' => 'Caminhos inexistentes (404/410)', 'feeds' => 'Feeds', 'apis' => 'APIs', 'outros' => 'Outros caminhos' );
	private static function classificacao( $valor ): string {
		return is_string( $valor ) && isset( self::CLASSIFICACOES[ $valor ] ) ? $valor : 'conteudo';
	}
	private static function periodo( $valor ): int {
		return is_scalar( $valor ) && in_array( (int) $valor, self::PERIODOS, true ) ? (int) $valor : 90;
	}
	public static function abas(): void {
		$ativa = isset( $_GET['aba'] ) && 'acessos' === $_GET['aba'];
		echo '<nav class="nav-tab-wrapper" aria-label="Medição">';
		foreach ( array( 'comportamento' => 'Comportamento', 'acessos' => 'Acessos' ) as $slug => $nome ) {
			$url = add_query_arg( array( 'page' => F3Base_Admin_Medicao::SLUG, 'aba' => $slug ), admin_url( 'admin.php' ) );
			printf( '<a class="nav-tab%s" href="%s">%s</a>', ( $ativa === ( 'acessos' === $slug ) ) ? ' nav-tab-active' : '', esc_url( $url ), esc_html( $nome ) );
		}
		echo '</nav>';
	}
	public static function somar(): void {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Sem permissão.', '', array( 'response' => 403 ) ); }
		check_admin_referer( 'f3base_acessos_somar' );
		( new F3Base_Modulo_Acessos_Servidor() )->somar();
		wp_safe_redirect( add_query_arg( array( 'page' => F3Base_Admin_Medicao::SLUG, 'aba' => 'acessos', 'dias' => self::periodo( $_POST['dias'] ?? 90 ), 'incluir_erros' => isset( $_POST['incluir_erros'] ) && '1' === $_POST['incluir_erros'] ? '1' : '0', 'mostrar_todos' => isset( $_POST['mostrar_todos'] ) && '1' === $_POST['mostrar_todos'] ? '1' : '0', 'classificacao' => self::classificacao( $_POST['classificacao'] ?? '' ) ), admin_url( 'admin.php' ) ) );
		exit;
	}
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		$dias = self::periodo( $_GET['dias'] ?? 90 );
		$todos = isset( $_GET['mostrar_todos'] ) && '1' === $_GET['mostrar_todos'];
		$classificacao = self::classificacao( $_GET['classificacao'] ?? '' );
		$modo = $todos ? 'todos' : $classificacao;
		$erros = ( isset( $_GET['incluir_erros'] ) && '1' === $_GET['incluir_erros'] ) || 'inexistentes' === $modo;
		$r = F3Base_Modulo_Acessos_Servidor::consultar( $dias, '', '', $erros, 0, true );
		$hoje = F3Base_Acessos_Atuais::ler();
		$vivo = array_values( array_filter( $hoje['linhas'], static fn( $l ) => $l['status'] >= 200 && $l['status'] <= ( $erros ? 599 : 399 ) ) );
		foreach ( $vivo as $l ) { if ( isset( $r['totais'][ $l['classe_caminho'] ] ) ) { $r['totais'][ $l['classe_caminho'] ] += $l['contagem']; } }
		echo '<h2>Acessos por caminho</h2>';
		printf( '<p><strong>%s</strong>: %s</p>', esc_html( $r['estado']['estado'] ), esc_html( $r['estado']['motivo'] ) );
		foreach ( ( new F3Base_Modulo_Acessos_Servidor() )->avisos() as $aviso ) { printf( '<p class="notice notice-warning">%s</p>', esc_html( $aviso['motivo'] ) ); }
		echo '<form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="aba" value="acessos"><label>Período <select name="dias">';
		foreach ( self::PERIODOS as $n ) { printf( '<option value="%d" %s>%d dias</option>', $n, selected( $dias, $n, false ), $n ); }
		echo '</select></label> ';
		echo '<label>Classificação <select name="classificacao" aria-describedby="f3base-acessos-filtro">';
		foreach ( self::CLASSIFICACOES as $valor => $rotulo ) { printf( '<option value="%s" %s>%s</option>', esc_attr( $valor ), selected( $classificacao, $valor, false ), esc_html( $rotulo ) ); }
		echo '</select></label> ';
		printf( '<label><input type="checkbox" name="incluir_erros" value="1" %s> Incluir 4xx/5xx</label> ', checked( $erros, true, false ) );
		printf( '<label><input type="checkbox" name="mostrar_todos" value="1" %s aria-describedby="f3base-acessos-filtro"> Mostrar todos</label> ', checked( $todos, true, false ) );
		submit_button( 'Atualizar', 'secondary', '', false );
		echo '</form><p id="f3base-acessos-filtro" class="description">Desmarque Mostrar todos para aplicar a classificação escolhida e clique em Atualizar. A seleção padrão reúne a página inicial, páginas e artigos publicados, robots.txt, sitemaps, llms.txt e llms-full.txt. Mostrar todos exibe todas as classificações, respeitando o período e o filtro de status.</p>';
		printf( '<p><strong>Visualização: %s.</strong></p>', esc_html( $todos ? 'Todos os caminhos disponíveis' : self::CLASSIFICACOES[ $modo ] ) );
		if ( 'inexistentes' === $modo ) { echo '<p>Esta classificação conta somente respostas 404 ou 410, incluindo esses erros automaticamente. Ela descreve a resposta registrada no log; o caminho pode ter sido criado ou corrigido depois.</p>'; }
		if ( 'outros' === $modo ) { echo '<p>Demais caminhos disponíveis, incluindo arquivos de categorias e rotas de plugins. Respostas 404 e 410 ficam em Caminhos inexistentes. Um caminho sem página ou artigo cadastrado pode ser uma rota válida do site.</p>'; }
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="f3base_acessos_somar">';
		printf( '<input type="hidden" name="dias" value="%d"><input type="hidden" name="incluir_erros" value="%d"><input type="hidden" name="mostrar_todos" value="%d">', $dias, $erros ? 1 : 0, $todos ? 1 : 0 );
		printf( '<input type="hidden" name="classificacao" value="%s">', esc_attr( $classificacao ) );
		wp_nonce_field( 'f3base_acessos_somar' );
		submit_button( 'Coletar e Armazenar Logs', 'secondary' );
		echo '</form>';
		printf( '<p>Período: %s a %s, incluindo hoje. Dias armazenados: %d de %d anteriores. Último dia armazenado: %s.</p>', esc_html( $r['inicio'] ), esc_html( $r['fim'] ), $r['dias_somados'], $dias - 1, esc_html( $r['ultimo_dia'] ?: 'nenhum' ) );
		if ( $hoje['erro'] ) { printf( '<p class="notice notice-warning">Hoje indisponível: %s. Os totais abaixo contêm apenas o histórico disponível.</p>', esc_html( $hoje['erro'] ) ); }
		else { printf( '<p>Hoje (%s): parcial. Leitura atualizada em %s (%s); %d linhas ignoradas.</p>', esc_html( $hoje['dia'] ), esc_html( wp_date( 'd/m/Y H:i:s', $hoje['atualizado'] ) ), esc_html( wp_timezone_string() ), $hoje['ignoradas'] ); }
		echo '<p>Atualizar lê os novos trechos do access.log e recalcula esta tela. Hoje usa uma fotografia temporária e não entra no histórico. A contagem considera as linhas completas de hoje ainda presentes no arquivo atual; a rotação e o atraso de escrita do servidor podem reduzir a cobertura. Clique novamente para acompanhar novas requisições.</p>';
		if ( ! empty( $hoje['bytes_pendentes'] ) ) { printf( '<p class="notice notice-warning">Leitura parcial: %s bytes ainda aguardam processamento ou o término de uma linha. Atualize para continuar.</p>', esc_html( number_format_i18n( $hoje['bytes_pendentes'] ) ) ); }
		self::agendamento();
		echo '<p>No histórico, a data é o dia do arquivo rotacionado do servidor. Hoje usa o horário de cada requisição convertido ao fuso do WordPress. A classificação aceita o User-Agent declarado. Humanos são requisições; pessoas medidas são identificadores distintos registrados no navegador. Repetições, consentimento, retenção e cache afetam essa comparação. A diferença não mede quantos robôs existem.</p>';
		$c = F3Base_Options::ler( 'f3base_comportamento' );
		printf( '<p>O registro detalhado guarda até %d dias e usa dias UTC. Períodos sem registro detalhado disponível aparecem como “—”; a cobertura dos logs depende dos arquivos ainda disponíveis no host.</p>', (int) $c['retencao_eventos_dias'] );
		self::tabelas( $r, $erros, $vivo, $modo );
		echo '<p>Família declarada pelo agente, não verificada. Humano = agente que não se declarou robô.</p>';
		printf( '<p>Totais fora das páginas, com o mesmo filtro de status: excluídos %d; estáticos %d; outros/excedentes %d.</p>', $r['totais']['excluido'], $r['totais']['estatico'], $r['totais']['outro'] );
		echo '<p class="description">Esses totais gerais independem da classificação escolhida. Caminhos eliminados na coleta por exclusões ou limites permanecem apenas nos totais.</p>';
		echo '<p>' . esc_html( F3Base_Atividade::descrever( 'ultima_soma_acessos', 'Última soma' ) ) . '</p>';
		echo '<p>A janela cresce com os dias somados. Dias que o host apagou e acessos atendidos exclusivamente pela CDN não entram no histórico. As classes busca, treino e resposta representam a finalidade declarada, sem comprovar o uso posterior do conteúdo.</p>';
	}
	private static function agendamento(): void {
		if ( empty( F3Base_Modulo_Acessos_Servidor::config()['ligado'] ) ) { echo '<p>Coleta automática desligada.</p>'; return; }
		$proximo = wp_next_scheduled( F3Base_Modulo_Acessos_Servidor::EVENTO );
		printf( '<p>Coleta automática diária às 09:00 UTC. Próxima execução prevista: %s. Coleta e armazena somente logs datados de dias anteriores; ignora access.log, access.log.0 e arquivos datados de hoje.</p>', esc_html( $proximo ? wp_date( 'd/m/Y H:i:s', $proximo ) . ' (' . wp_timezone_string() . ')' : 'agendamento não confirmado' ) );
		if ( $proximo && $proximo < time() ) { echo '<p class="notice notice-warning">Coleta agendada em atraso; verifique o acionamento do WP-Cron.</p>'; }
		echo '<p>O WP-Cron depende de requisições ao site; em sites sem tráfego, use uma tarefa cron do servidor para acioná-lo regularmente.</p>';
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) { echo '<p>Acionamento automático do WP-Cron desabilitado nesta instalação: a tarefa cron do servidor precisa estar configurada.</p>'; }
	}
	/** Endereços atuais de conteúdo publicado; a classe do log não prova a existência da página. */
	private static function caminhos_publicados(): array {
		return F3Base_Modulo_Cache_Publico::lembrar( 'caminhos-publicados', static fn() => self::montar_caminhos_publicados() );
	}
	private static function montar_caminhos_publicados(): array {
		$caminhos = array();
		$adicionar = static function ( string $url ) use ( &$caminhos ): void {
			[ , $p ] = F3Base_Modulo_Acessos_Servidor::caminho( $url, array() );
			if ( '' === $p ) { return; }
			foreach ( array_unique( array( $p, rawurldecode( $p ) ) ) as $variante ) {
				$sem_barra = rtrim( $variante, '/' );
				$caminhos[ $sem_barra ?: '/' ] = true;
				$caminhos[ $sem_barra . '/' ] = true;
			}
		};
		$adicionar( home_url( '/' ) );
		// Lê em lotes e não mantém objetos de todos os artigos no cache desta requisição.
		for ( $pagina = 1; ; ++$pagina ) {
			$posts = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'posts_per_page' => 200, 'paged' => $pagina, 'orderby' => 'ID', 'order' => 'ASC', 'cache_results' => false, 'update_post_meta_cache' => false, 'update_post_term_cache' => false ) );
			foreach ( $posts as $post ) { $adicionar( (string) get_permalink( $post ) ); }
			if ( count( $posts ) < 200 ) { break; }
		}
		return $caminhos;
	}
	/** Reconhece famílias de arquivos; a ausência de post não define inexistência. */
	private static function classe_de_arquivo( string $caminho ): string {
		$base = rtrim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$p = rawurldecode( $caminho );
		if ( '' !== $base && ! str_starts_with( $p, $base . '/' ) ) { return ''; }
		$p = substr( $p, strlen( $base ) );
		if ( preg_match( '~^/(?:robots\.txt|llms(?:-full)?\.txt|(?:[^/]+/)*[^/]*sitemap[^/]*\.xml(?:\.gz)?)/?$~iD', $p ) ) { return 'descoberta'; }
		if ( preg_match( '~^/(?:[^/]+/)*feed(?:/(?:feed|rdf|rss|rss2|atom))?/?$~iD', $p ) ) { return 'feeds'; }
		return '';
	}
	/** Une os líderes históricos a TODOS os grupos de hoje antes de limitar. */
	private static function ranking( string $where, array $vivo, bool $desc, ?array $permitidos = null, bool $excluir = false ): array {
		global $wpdb;
		$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$grupo = $desc ? 'caminho,classe_caminho,agente' : 'caminho';
		$soma = $desc ? 'SUM(contagem)' : "SUM(CASE WHEN agente = 'humano' THEN contagem ELSE 0 END)";
		$where .= $desc ? " AND classe_caminho IN ('descoberta','api')" : " AND classe_caminho = 'pagina'";
		if ( null !== $permitidos ) {
			$where .= $permitidos ? $wpdb->prepare( ' AND caminho ' . ( $excluir ? 'NOT IN' : 'IN' ) . ' (' . implode( ',', array_fill( 0, count( $permitidos ), '%s' ) ) . ')', array_keys( $permitidos ) ) : ( $excluir ? '' : ' AND 1 = 0' );
		}
		$chave = static fn( $l ) => wp_json_encode( $desc ? array( $l['caminho'], $l['classe_caminho'], $l['agente'] ) : array( $l['caminho'] ) );
		$atuais = array(); $caminhos = array(); $historico = array(); $total = 0;
		foreach ( $vivo as $l ) {
			if ( null !== $permitidos && isset( $permitidos[ $l['caminho'] ] ) === $excluir ) { continue; }
			if ( ! in_array( $l['classe_caminho'], $desc ? array( 'descoberta', 'api' ) : array( 'pagina' ), true ) ) { continue; }
			$k = $chave( $l ); $caminhos[ $l['caminho'] ] = true;
			if ( ! isset( $atuais[ $k ] ) ) { $atuais[ $k ] = $l; $atuais[ $k ]['total'] = 0; }
			$atuais[ $k ]['total'] += $desc || 'humano' === $l['agente'] ? (int) $l['contagem'] : 0;
		}
		if ( F3Base_Modulo_Acessos_Servidor::tabela_pronta() ) {
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM (SELECT 1 FROM {$t} WHERE {$where} GROUP BY {$grupo}) f3base_ranking" );
			$sql = "SELECT {$grupo},{$soma} AS total FROM {$t} WHERE {$where}";
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( "{$sql} GROUP BY {$grupo} ORDER BY total DESC,{$grupo} LIMIT %d", self::TETO_PAGINAS ), ARRAY_A ) as $l ) { $historico[ $chave( $l ) ] = $l; }
			// Um grupo com novos acessos pode entrar no topo mesmo estando fora do limite histórico.
			foreach ( array_chunk( array_keys( $caminhos ), 200 ) as $lote ) {
				$in = implode( ',', array_fill( 0, count( $lote ), '%s' ) );
				foreach ( (array) $wpdb->get_results( $wpdb->prepare( "{$sql} AND caminho IN ({$in}) GROUP BY {$grupo}", $lote ), ARRAY_A ) as $l ) { $historico[ $chave( $l ) ] = $l; }
			}
		}
		foreach ( $atuais as $k => $l ) {
			if ( isset( $historico[ $k ] ) ) { $historico[ $k ]['total'] = (int) $historico[ $k ]['total'] + $l['total']; }
			else { $historico[ $k ] = $l; ++$total; }
		}
		usort( $historico, static function ( $a, $b ) use ( $desc ): int {
			return ( (int) $b['total'] <=> (int) $a['total'] ) ?: strcmp( $a['caminho'], $b['caminho'] ) ?: ( $desc ? ( strcmp( $a['classe_caminho'], $b['classe_caminho'] ) ?: strcmp( $a['agente'], $b['agente'] ) ) : 0 );
		} );
		return array( array_slice( $historico, 0, self::TETO_PAGINAS ), $total );
	}
	private static function tabelas( array $r, bool $erros, array $vivo, string $modo ): void {
		global $wpdb;
		$t = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$where = $wpdb->prepare( 'dia >= %s AND dia < %s', $r['inicio'], $r['fim'] ) . ( $erros ? ' AND status BETWEEN 200 AND 599' : ' AND status BETWEEN 200 AND 399' );
		$permitidos = null; $excluir = false;
		if ( in_array( $modo, array( 'inexistentes', 'outros', 'apis' ), true ) ) {
			$where .= 'inexistentes' === $modo ? ' AND status IN (404,410)' : ( 'outros' === $modo ? " AND status NOT IN (404,410) AND classe_caminho = 'pagina'" : " AND classe_caminho = 'api'" );
			$vivo = array_values( array_filter( $vivo, static fn( $l ) => 'inexistentes' === $modo ? in_array( (int) $l['status'], array( 404, 410 ), true ) : ( 'outros' === $modo ? ! in_array( (int) $l['status'], array( 404, 410 ), true ) && 'pagina' === $l['classe_caminho'] : 'api' === $l['classe_caminho'] ) ) );
		}
		if ( in_array( $modo, array( 'conteudo', 'paginas', 'descoberta', 'feeds', 'outros' ), true ) ) {
			$publicados = in_array( $modo, array( 'conteudo', 'paginas', 'outros' ), true ) ? self::caminhos_publicados() : array();
			if ( $publicados ) {
				$observados = F3Base_Modulo_Acessos_Servidor::tabela_pronta() ? (array) $wpdb->get_col( "SELECT DISTINCT caminho FROM {$t} WHERE {$where} AND classe_caminho='pagina'" ) : array();
				foreach ( $vivo as $l ) { $observados[] = $l['caminho']; }
				$publicados = array_intersect_key( $publicados, array_fill_keys( $observados, true ) );
			}
			$arquivos = array( 'descoberta' => array(), 'feeds' => array() );
			// Inclui XML compactado e feeds de conteúdo que o coletor anterior classifica como página.
			$candidatos = F3Base_Modulo_Acessos_Servidor::tabela_pronta() ? (array) $wpdb->get_col( "SELECT DISTINCT caminho FROM {$t} WHERE {$where} AND (classe_caminho = 'descoberta' OR LOWER(caminho) LIKE '%.xml.gz%' OR LOWER(caminho) LIKE '%feed%')" ) : array();
			foreach ( $vivo as $l ) { $candidatos[] = $l['caminho']; }
			foreach ( array_unique( $candidatos ) as $p ) {
				$classe = self::classe_de_arquivo( $p );
				if ( '' !== $classe ) { $arquivos[ $classe ][ $p ] = true; }
			}
			$permitidos = in_array( $modo, array( 'descoberta', 'feeds' ), true ) ? $arquivos[ $modo ] : $publicados;
			if ( in_array( $modo, array( 'conteudo', 'outros' ), true ) ) { $permitidos += $arquivos['descoberta']; }
			if ( 'outros' === $modo ) { $permitidos += $arquivos['feeds']; $excluir = true; }
		}
		[ $ranking, $total ] = self::ranking( $where, $vivo, false, $permitidos, $excluir );
		$paginas = array_column( $ranking, 'caminho' );
		$mapa = array();
		foreach ( $paginas as $p ) { $mapa[ $p ] = array( 'humano' => 0, 'busca' => 0, 'treino-ia' => 0, 'resposta-ia' => 0, 'outros' => 0, 'familias' => array() ); }
		$pessoas = array();
		if ( $paginas ) {
			$in = implode( ',', array_fill( 0, count( $paginas ), '%s' ) );
			$linhas = F3Base_Modulo_Acessos_Servidor::tabela_pronta() ? $wpdb->get_results( $wpdb->prepare( "SELECT caminho,agente,SUM(contagem) AS contagem FROM {$t} WHERE {$where} AND classe_caminho = 'pagina' AND caminho IN ({$in}) GROUP BY caminho,agente", $paginas ), ARRAY_A ) : array();
			foreach ( $vivo as $l ) { if ( 'pagina' === $l['classe_caminho'] && isset( $mapa[ $l['caminho'] ] ) ) { $linhas[] = $l; } }
			$familias = array();
			foreach ( (array) $linhas as $l ) { $k = wp_json_encode( array( $l['caminho'], $l['agente'] ) ); if ( isset( $familias[ $k ] ) ) { $familias[ $k ]['contagem'] += (int) $l['contagem']; } else { $familias[ $k ] = $l; } }
			$linhas = array_values( $familias );
			foreach ( (array) $linhas as $l ) {
				$classe = F3Base_Modulo_Acessos_Servidor::classe_agente( $l['agente'] );
				$coluna = in_array( $classe, array( 'humano', 'busca', 'treino-ia', 'resposta-ia' ), true ) ? $classe : 'outros';
				$mapa[ $l['caminho'] ][ $coluna ] += (int) $l['contagem'];
				$mapa[ $l['caminho'] ]['familias'][] = $l['agente'] . ': ' . $l['contagem'];
			}
			if ( F3Base_Modulo_Comportamento::eventos_prontos() ) {
				$eventos = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS;
				foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT caminho,COUNT(DISTINCT visitante) AS pessoas FROM {$eventos} WHERE dia >= %s AND dia <= %s AND visitante <> '' AND caminho IN ({$in}) GROUP BY caminho", array_merge( array( $r['inicio'], $r['fim'] ), $paginas ) ), ARRAY_A ) as $l ) { $pessoas[ $l['caminho'] ] = (int) $l['pessoas']; }
			}
		}
		$titulos = get_transient( 'f3base_acessos_titulos' );
		$titulos = is_array( $titulos ) ? $titulos : array();
		echo '<table class="widefat striped"><thead><tr><th>Página ou caminho</th><th>Humanos (log)</th><th>Pessoas medidas</th><th>Busca</th><th>Treino IA</th><th>Resposta IA</th><th>Outros robôs</th></tr></thead><tbody>';
		foreach ( $mapa as $p => $m ) {
			if ( ! array_key_exists( $p, $titulos ) ) {
				$origin = wp_parse_url( home_url() );
				$url = $origin['scheme'] . '://' . $origin['host'] . ( isset( $origin['port'] ) ? ':' . $origin['port'] : '' ) . $p;
				$id = url_to_postid( $url ); $titulos[ $p ] = $id ? get_the_title( $id ) : '';
			}
			printf( '<tr><td>%s<br><code>%s</code><details><summary>Por família</summary>%s</details></td><td>%d</td><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td title="%s">%d</td></tr>', esc_html( $titulos[ $p ] ), esc_html( $p ), esc_html( implode( '; ', $m['familias'] ) ), $m['humano'], esc_html( isset( $pessoas[ $p ] ) ? (string) $pessoas[ $p ] : '—' ), $m['busca'], $m['treino-ia'], $m['resposta-ia'], esc_attr( implode( '; ', $m['familias'] ) ), $m['outros'] );
		}
		if ( ! $mapa ) { echo '<tr><td colspan="7">Nenhum caminho encontrado nesta tabela com os filtros aplicados.</td></tr>'; }
		echo '</tbody></table>';
		set_transient( 'f3base_acessos_titulos', array_slice( $titulos, -1500, null, true ), DAY_IN_SECONDS );
		printf( '<p>Exibindo %d de %d caminhos; ordenação por requisições humanas. Detalhamento e paginação do histórico até ontem disponíveis em f3base/acessos-ler.</p>', count( $mapa ), $total );
		[ $desc, $total_desc ] = self::ranking( $where, $vivo, true, $permitidos, $excluir );
		$rotulo = 'apis' === $modo ? 'APIs por família' : ( 'feeds' === $modo ? 'Feeds por família' : ( in_array( $modo, array( 'conteudo', 'paginas', 'descoberta' ), true ) ? 'Arquivos de descoberta por família' : 'Descoberta, feeds e APIs por família' ) );
		echo '<h2>' . esc_html( $rotulo ) . '</h2><table class="widefat striped"><thead><tr><th>Caminho</th><th>Classe</th><th>Família</th><th>Requisições</th></tr></thead><tbody>';
		foreach ( $desc as $l ) { printf( '<tr><td><code>%s</code></td><td>%s</td><td>%s</td><td>%d</td></tr>', esc_html( $l['caminho'] ), esc_html( $l['classe_caminho'] ), esc_html( $l['agente'] ), (int) $l['total'] ); }
		if ( ! $desc ) { echo '<tr><td colspan="4">Nenhum acesso de descoberta ou API no período.</td></tr>'; }
		echo '</tbody></table>';
		printf( '<p>Exibindo %d de %d combinações de caminho e família.</p>', count( $desc ), $total_desc );
	}
}
