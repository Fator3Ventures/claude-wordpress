

(function (window, document) {
	'use strict';

	var dados = window.f3baseLeadsDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CAMPOS = ['nome', 'email', 'telefone', 'mensagem'];
	var LIMITES = dados.limites && typeof dados.limites === 'object' ? dados.limites : {};
	var ATRIBUICAO = dados.atribuicao && typeof dados.atribuicao === 'object' ? dados.atribuicao : {};
	var CHAVE_ATRIBUICAO = String(ATRIBUICAO.chave || 'f3base_atribuicao');
	var TTL_ATRIBUICAO = parseInt(ATRIBUICAO.ttlDias, 10) > 0 ? parseInt(ATRIBUICAO.ttlDias, 10) : 30;
	

	var TOKEN_PRIMEIRO_TOQUE = String(ATRIBUICAO.primeiroToque || '');
	var PRIMEIRO_TOQUE = TOKEN_PRIMEIRO_TOQUE !== '' && String(ATRIBUICAO.modelo || '') === TOKEN_PRIMEIRO_TOQUE;
	var ATRIBUTO_NUMERO = String(dados.atributoNumero || 'data-f3base-numero');
	var HREFS_DO_MODELO = Array.isArray(dados.hrefsDoModelo) ? dados.hrefsDoModelo.map(String) : ['', '#'];
	var MEDICAO = dados.medicao && typeof dados.medicao === 'object' ? dados.medicao : {};
	var CAMINHO = String(MEDICAO.caminho || 'nenhum');
	var ADS = MEDICAO.ads && typeof MEDICAO.ads === 'object' ? MEDICAO.ads : {};
	var META = MEDICAO.meta && typeof MEDICAO.meta === 'object' ? MEDICAO.meta : {};
	var LINKEDIN = MEDICAO.linkedin && typeof MEDICAO.linkedin === 'object' ? MEDICAO.linkedin : {};
	

	var JANELA_CORRELACAO = parseInt(dados.janelaCorrelacao, 10) > 0 ? parseInt(dados.janelaCorrelacao, 10) : 60;

	var registrados = {};
	var iniciados = {};

	window.dataLayer = window.dataLayer || [];

	function correlationId() {
		var bytes = new Uint8Array(8);
		var saida = '';
		var i;

		if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
			window.crypto.getRandomValues(bytes);
		} else {
			for (i = 0; i < bytes.length; i++) {
				bytes[i] = Math.floor(Math.random() * 256);
			}
		}

		for (i = 0; i < bytes.length; i++) {
			saida += ('0' + bytes[i].toString(16)).slice(-2);
		}

		return saida;
	}

	

	function caracteres(texto) {
		return Array.from(texto);
	}

	

	function limitar(nome, valor) {
		var limite = parseInt(LIMITES[nome], 10);
		var texto = String(valor == null ? '' : valor);
		var letras;

		if (limite > 0) {
			letras = caracteres(texto);

			if (letras.length > limite) {
				return letras.slice(0, limite).join('');
			}
		}

		return texto;
	}

	

	function normalizarHref(href) {
		return String(href == null ? '' : href).trim().replace(/\/+$/, '');
	}

	

	function eDoModelo(href) {
		if (href == null) {
			return true;
		}

		return HREFS_DO_MODELO.indexOf(normalizarHref(href)) !== -1;
	}

	

	function temDestinoProprio(gatilho) {
		 
		 
		return !gatilho.getAttribute(ATRIBUTO_NUMERO);
	}

	

	function agora() {
		return String(Math.floor(Date.now() / 1000));
	}

	function lerCookie(nome) {
		var partes = String(document.cookie || '').split(';');
		var i;
		var atual;

		for (i = 0; i < partes.length; i++) {
			atual = partes[i].replace(/^\s+/, '');
			if (atual.indexOf(nome + '=') === 0) {
				return decodeURIComponent(atual.substring(nome.length + 1));
			}
		}

		return '';
	}

	

	function gravarFbc(fbclid) {
		if (!fbclid || lerCookie('_fbc')) {
			return lerCookie('_fbc');
		}

		var valor = 'fb.1.' + Date.now() + '.' + fbclid;
		var seguro = window.location.protocol === 'https:' ? '; Secure' : '';

		try {
			document.cookie = '_fbc=' + encodeURIComponent(valor) +
				'; Max-Age=' + (TTL_ATRIBUICAO * 86400) +
				'; Path=/; SameSite=Lax' + seguro;
		} catch (erro) {
			 
		}

		return valor;
	}

	function lerAtribuicaoGuardada() {
		try {
			var cru = window.localStorage.getItem(CHAVE_ATRIBUICAO);

			if (!cru) {
				return null;
			}

			var guardado = JSON.parse(cru);

			if (!guardado || typeof guardado !== 'object') {
				return null;
			}

			if (parseInt(guardado.expira, 10) < Math.floor(Date.now() / 1000)) {
				window.localStorage.removeItem(CHAVE_ATRIBUICAO);
				return null;
			}

			return guardado.valor && typeof guardado.valor === 'object' ? guardado.valor : null;
		} catch (erro) {
			return null;
		}
	}

	function guardarAtribuicao(valor) {
		try {
			window.localStorage.setItem(CHAVE_ATRIBUICAO, JSON.stringify({
				expira: Math.floor(Date.now() / 1000) + (TTL_ATRIBUICAO * 86400),
				valor: valor
			}));
		} catch (erro) {
			 
		}
	}

	

	function atribuicaoDaUrl() {
		var busca = new URLSearchParams(window.location.search);
		var mapa = {
			fonte: 'utm_source',
			meio: 'utm_medium',
			campanha: 'utm_campaign',
			termo: 'utm_term',
			conteudo: 'utm_content',
			gclid: 'gclid',
			gbraid: 'gbraid',
			wbraid: 'wbraid',
			msclkid: 'msclkid',
			fbclid: 'fbclid',
			li_fat_id: 'li_fat_id'
		};
		var saida = {};
		var chave;
		var valor;

		for (chave in mapa) {
			if (Object.prototype.hasOwnProperty.call(mapa, chave)) {
				valor = busca.get(mapa[chave]);
				if (valor) {
					saida[chave] = String(valor);
				}
			}
		}

		if (document.referrer && document.referrer.indexOf(window.location.origin) !== 0) {
			saida.referrer = document.referrer;
		}

		return saida;
	}

	

	function cookiesDaMeta(escolhida) {
		

		if (!permiteTags()) {
			return escolhida;
		}

		var fbc = gravarFbc(escolhida.fbclid || '');
		var fbp = lerCookie('_fbp');

		if (fbc) {
			escolhida.fbc = fbc;
		}

		if (fbp) {
			escolhida.fbp = fbp;
		}

		return escolhida;
	}

	

	function esquecerAtribuicao() {
		try {
			window.localStorage.removeItem(CHAVE_ATRIBUICAO);
		} catch (erro) {
			 
		}

		try {
			document.cookie = '_fbc=; Max-Age=0; Path=/; SameSite=Lax' +
				(window.location.protocol === 'https:' ? '; Secure' : '');
		} catch (erro) {
			 
		}
	}

	function atribuicao() {
		

		if (!permiteTags()) {
			esquecerAtribuicao();

			var somenteDesta = atribuicaoDaUrl();
			somenteDesta.modelo = String(ATRIBUICAO.modelo || '');

			return somenteDesta;
		}

		var guardada = lerAtribuicaoGuardada();
		var atual = atribuicaoDaUrl();
		var temAtual = Object.keys(atual).length > 0;
		var escolhida;

		if (PRIMEIRO_TOQUE) {
			escolhida = guardada || atual;
		} else {
			escolhida = temAtual ? atual : (guardada || {});
		}

		if (!escolhida.primeiro_toque_em) {
			escolhida.primeiro_toque_em = guardada && guardada.primeiro_toque_em
				? String(guardada.primeiro_toque_em)
				: agora();
		}

		escolhida.modelo = String(ATRIBUICAO.modelo || '');

		if (!guardada || (!PRIMEIRO_TOQUE && temAtual)) {
			guardarAtribuicao(escolhida);
		}

		return cookiesDaMeta(escolhida);
	}

	function formularioDe(gatilho) {
		var seletor = gatilho.getAttribute('data-f3base-form');

		if (!seletor) {
			return null;
		}

		try {
			return document.querySelector(seletor);
		} catch (erro) {
			return null;
		}
	}

	function valorDoCampo(escopo, nome) {
		var elemento = escopo.querySelector('[data-f3base-campo="' + nome + '"]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="' + nome + '"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function honeypotDe(escopo) {
		var elemento = escopo.querySelector('[data-f3base-honeypot]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="website"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function coletar(gatilho) {
		var escopo = formularioDe(gatilho);
		var carga = {};
		var i;
		var nome;

		if (escopo) {
			for (i = 0; i < CAMPOS.length; i++) {
				nome = CAMPOS[i];
				carga[nome] = limitar(nome, valorDoCampo(escopo, nome));
			}
			carga.website = honeypotDe(escopo);
		}

		return carga;
	}

	function temContato(carga) {
		var i;

		for (i = 0; i < CAMPOS.length; i++) {
			if (carga[CAMPOS[i]]) {
				return true;
			}
		}

		return false;
	}

	

	function mensagemDe(gatilho) {
		var propria = gatilho.getAttribute('data-f3base-mensagem');

		return propria || String(dados.mensagem || '');
	}

	function urlWhatsapp(gatilho) {
		var numero = gatilho.getAttribute(ATRIBUTO_NUMERO) || String(dados.numero || '');
		var texto = mensagemDe(gatilho);

		if (!texto) {
			return 'https://wa.me/' + encodeURIComponent(numero);
		}

		return 'https://wa.me/' + encodeURIComponent(numero) + '?text=' + encodeURIComponent(texto);
	}

	

	function tokenVencido(token) {
		var expira = parseInt(String(token == null ? '' : token).split('.')[0], 10);

		return !(expira > 0) || expira <= Math.floor(Date.now() / 1000);
	}

	

	function renovarToken(aoTer) {
		var rota = String(dados.rotaToken || '');

		if (!rota || typeof window.fetch !== 'function') {
			aoTer('');
			return;
		}

		var alvo = rota + (rota.indexOf('?') === -1 ? '?' : '&') +
			'pagina=' + encodeURIComponent(window.location.pathname);

		try {
			window.fetch(alvo, { method: 'GET', credentials: 'same-origin' }).then(function (resposta) {
				return resposta && resposta.ok ? resposta.json() : null;
			}).then(function (corpo) {
				aoTer(corpo && corpo.token ? String(corpo.token) : '');
			}).catch(function () {
				aoTer('');
			});
		} catch (erro) {
			aoTer('');
		}
	}

	

	function enviar(carga, jaRenovou) {
		var corpo = JSON.stringify(carga);
		var entregue = false;

		try {
			if (navigator && typeof navigator.sendBeacon === 'function') {
				entregue = navigator.sendBeacon(String(dados.endpoint), new Blob([corpo], { type: 'application/json' }));
			}
		} catch (erro) {
			entregue = false;
		}

		if (entregue) {
			return;
		}

		if (typeof window.fetch !== 'function') {
			return;
		}

		try {
			window.fetch(String(dados.endpoint), {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: corpo,
				keepalive: true,
				credentials: 'same-origin'
			}).then(function (resposta) {
				if (jaRenovou || !resposta || resposta.status !== 403) {
					return;
				}

				renovarToken(function (token) {
					if (!token) {
						return;
					}

					carga.token = token;
					enviar(carga, true);
				});
			}).catch(function () {
				 
			});
		} catch (erro) {
			 
		}
	}

	

	function registrar(carga) {
		if (!tokenVencido(carga.token)) {
			enviar(carga, false);
			return;
		}

		renovarToken(function (token) {
			carga.token = token || carga.token;
			enviar(carga, true);
		});
	}

	

	function evento(nome, parametros) {
		if (CAMINHO === 'gtm') {
			var objeto = { event: nome };
			var chave;

			for (chave in parametros) {
				if (Object.prototype.hasOwnProperty.call(parametros, chave)) {
					objeto[chave] = parametros[chave];
				}
			}

			try {
				window.dataLayer.push(objeto);
			} catch (erro) {
				 
			}

			return;
		}

		if (typeof window.gtag !== 'function') {
			return;
		}

		try {
			window.gtag('event', nome, parametros);
		} catch (erro) {
			 
		}
	}

	

	function normalizarEmail(email) {
		var limpo = String(email || '').trim().toLowerCase();
		var partes = limpo.split('@');

		if (partes.length !== 2) {
			return '';
		}

		if (partes[1] === 'gmail.com' || partes[1] === 'googlemail.com') {
			partes[0] = partes[0].split('+')[0].replace(/\./g, '');
		}

		return partes[0] + '@' + partes[1];
	}

	

	function normalizarTelefone(telefone) {
		var bruto = String(telefone || '').trim();

		if (bruto.indexOf('+') !== 0) {
			return '';
		}

		var digitos = bruto.replace(/[^0-9]/g, '');

		return digitos ? '+' + digitos : '';
	}

	function sha256(texto) {
		if (!window.crypto || !window.crypto.subtle || typeof window.crypto.subtle.digest !== 'function') {
			return null;
		}

		try {
			return window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(texto)).then(function (buffer) {
				var bytes = new Uint8Array(buffer);
				var saida = '';
				var i;

				for (i = 0; i < bytes.length; i++) {
					saida += ('0' + bytes[i].toString(16)).slice(-2);
				}

				return saida;
			});
		} catch (erro) {
			return null;
		}
	}

	

	function dadosDoUsuario(carga) {
		

		if (!permiteTags()) {
			return null;
		}

		if (!ADS.id || typeof window.gtag !== 'function') {
			return null;
		}

		var email = normalizarEmail(carga.email);
		var telefone = normalizarTelefone(carga.telefone);

		if (!email && !telefone) {
			return null;
		}

		var pendentes = [];
		var chaves = [];

		if (email) {
			pendentes.push(sha256(email));
			chaves.push('sha256_email_address');
		}

		if (telefone) {
			pendentes.push(sha256(telefone));
			chaves.push('sha256_phone_number');
		}

		if (pendentes.indexOf(null) !== -1) {
			return null;
		}

		return Promise.all(pendentes).then(function (hashes) {
			var user = {};
			var i;

			for (i = 0; i < hashes.length; i++) {
				user[chaves[i]] = hashes[i];
			}

			window.gtag('set', 'user_data', user);
		});
	}

	

	function permiteTags() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	

	function converter(formulario, id, carga) {
		evento('generate_lead', {
			form_id: formulario,
			correlation_id: id,
			method: carga && temContato(carga) ? 'formulario' : 'cta'
		});

		if (CAMINHO === 'gtm') {
			return;
		}

		var pendente = dadosDoUsuario(carga || {});

		if (pendente && typeof pendente.then === 'function') {
			pendente.then(function () {
				conversaoDoAds(id);
			}).catch(function () {
				conversaoDoAds(id);
			});
		} else {
			conversaoDoAds(id);
		}

		

		if (!permiteTags()) {
			return;
		}

		if (META.pixelId && typeof window.fbq === 'function') {
			try {
				window.fbq('track', 'Lead', {}, { eventID: id });
			} catch (erro) {
				 
			}
		}

		if (LINKEDIN.conversionId && typeof window.lintrk === 'function') {
			try {
				window.lintrk('track', { conversion_id: Number(LINKEDIN.conversionId) });
			} catch (erro) {
				 
			}
		}
	}

	

	function conversaoDoAds(id) {
		if (!ADS.id || !ADS.label || typeof window.gtag !== 'function') {
			return;
		}

		try {
			window.gtag('event', 'conversion', {
				send_to: String(ADS.id) + '/' + String(ADS.label),
				transaction_id: id
			});
		} catch (erro) {
			 
		}
	}

	function marcarInicio(gatilho) {
		var id = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';

		if (iniciados[id]) {
			return;
		}

		iniciados[id] = true;
		evento('form_start', { form_id: id });
	}

	

	function correlacaoDo(gatilho) {
		var guardada = gatilho.getAttribute('data-f3base-correlation');
		var carimbo = parseInt(gatilho.getAttribute('data-f3base-correlation-em'), 10);
		var segundos = Math.floor(Date.now() / 1000);

		if (guardada && carimbo > 0 && (segundos - carimbo) <= JANELA_CORRELACAO) {
			gatilho.setAttribute('data-f3base-correlation-em', String(segundos));

			return guardada;
		}

		var nova = correlationId();

		gatilho.setAttribute('data-f3base-correlation', nova);
		gatilho.setAttribute('data-f3base-correlation-em', String(segundos));

		return nova;
	}

	function aoClicar(gatilho) {
		var id = correlacaoDo(gatilho);
		var formulario = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';
		var carga = coletar(gatilho);
		var numero = gatilho.getAttribute(ATRIBUTO_NUMERO) || String(dados.numero || '');

		

		if (numero && !temDestinoProprio(gatilho)) {
			gatilho.setAttribute('href', urlWhatsapp(gatilho));
			gatilho.setAttribute('target', '_blank');
			gatilho.setAttribute('rel', 'noopener');
		}

		if (registrados[id]) {
			return;
		}

		registrados[id] = true;

		carga.token = String(dados.token || '');
		carga.correlation_id = id;

		

		carga.clicado_em = new Date().toISOString();
		carga.clicado_em_ms = Date.now();
		carga.formulario = limitar('formulario', formulario);
		carga.pagina = limitar('pagina', window.location.pathname + window.location.search);
		carga.consentimento = permiteTags();
		carga.atribuicao = atribuicao();

		if (typeof carga.website === 'undefined') {
			carga.website = '';
		}

		registrar(carga);
		converter(formulario, id, carga);
	}

	function ligar() {
		var seletor = String(dados.seletor || '[data-f3base-lead]');

		

		document.addEventListener('f3base-consentimento', function () {
			if (!permiteTags()) {
				esquecerAtribuicao();
			}
		});

		document.addEventListener('click', function (ev) {
			var alvo = ev.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(seletor)) {
					aoClicar(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		}, true);

		document.addEventListener('input', function (ev) {
			var alvo = ev.target;

			if (!alvo || alvo.nodeType !== 1 || !alvo.closest) {
				return;
			}

			var formulario = alvo.closest('form');

			if (!formulario) {
				return;
			}

			var gatilhos = document.querySelectorAll(seletor);
			var i;

			for (i = 0; i < gatilhos.length; i++) {
				if (formularioDe(gatilhos[i]) === formulario) {
					marcarInicio(gatilhos[i]);
					return;
				}
			}
		}, true);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', ligar);
	} else {
		ligar();
	}
}(window, document));
