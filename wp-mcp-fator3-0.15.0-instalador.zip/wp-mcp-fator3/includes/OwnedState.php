<?php
/** Explicit ownership, separate from the broader protection of options/update. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class OwnedState {
    public const OPTIONS=['f3_mcp_014_credential_ids','f3_mcp_schema_version','f3_mcp_release_version','f3_mcp_policy_installed_at','f3_mcp_legacy_catalog',
        'f3_mcp_ultimate_migrated','f3_mcp_settings','f3_mcp_oauth_clients','f3_mcp_files_enabled','f3_mcp_database_writes_enabled',
        'f3_mcp_db_writes','f3_mcp_file_bytes','f3_mcp_files_audit','f3_mcp_update_channels','f3_mcp_allowed_origins','f3_mcp_last_cron_observed'];
    public static function tables(): array {
        global $wpdb;return array_map(static fn($s)=>$wpdb->prefix.'f3_mcp_'.$s,
            ['clients','grants','authorization_codes','tokens','legacy_sessions','idempotency','audit','operations','operation_steps','migration_checkpoints','state']);
    }
    public static function option_where(): string {
        $names=implode(',',array_map(static fn($v)=>"'".$v."'",self::OPTIONS));
        return "(option_name IN ($names) OR option_name REGEXP '^_transient_(timeout_)?(f3_mcp_oauth_|mcp_oauth_|f3_mcp_notice_)')";
    }
    public static function user_where(): string {
        return "meta_key IN ('_application_passwords','session_tokens','f3_mcp_app_password','f3_mcp_connection_test','mcp_adapter_sessions')";
    }
    public static function manifest(): array {
        return ['contract'=>'preserved-state/1','tables'=>self::tables(),'options'=>self::OPTIONS,
            'option_families'=>['_transient_[timeout_]f3_mcp_oauth_*','_transient_[timeout_]mcp_oauth_*','_transient_[timeout_]f3_mcp_notice_*'],
            'usermeta'=>['_application_passwords','session_tokens','f3_mcp_app_password','f3_mcp_connection_test','mcp_adapter_sessions'],
            'wordpress_credentials_preserved'=>true,'other_providers'=>'restore_snapshot'];
    }
}
