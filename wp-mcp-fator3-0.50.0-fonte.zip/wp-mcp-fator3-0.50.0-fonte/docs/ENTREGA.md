# Entrega 0.50.0

Pedidos MCP 85 e 86. Base direta 0.49.0. Consulte RELEASE-0500.md para o uso, IMPACTO-CORE-0500.md para a coordenação e evidencias/0500 para os testes. O relatório externo identifica os arquivos finais e as pendências da frota.
