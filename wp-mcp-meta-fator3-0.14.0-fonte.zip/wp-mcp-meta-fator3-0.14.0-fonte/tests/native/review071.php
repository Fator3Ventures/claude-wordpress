<?php
require_once __DIR__.'/seed-connection090.php';
/** Independent adversarial review: corrupt jobs must not take down diagnostics or starve valid work. */
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
require_once __DIR__.'/lab-helpers.php';
use Fator3\Meta as M;
wp_set_current_user(1);global $wpdb;$t=M\Store::table();$checks=[];$calls=0;$mail=0;
function review_check($name,$ok,$details=[]){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok,'details'=>$details];echo wp_json_encode(end($checks))."\n";}
add_filter('pre_http_request',function($pre,$args,$url)use(&$calls){$calls++;return ['headers'=>[],'body'=>wp_json_encode(['id'=>'888071','name'=>'QA review','username'=>'qa071','followers_count'=>2]),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];},1,3);
add_filter('pre_wp_mail',function($pre,$atts)use(&$mail){$mail++;return true;},1,2);
lab_seed_connection090(['connection_id'=>'review071','expected_revision'=>0,'token'=>'synthetic-review-token','assets'=>['instagram'=>['888071']],'users'=>[1]]);
$query=['connection_id'=>'review071','channel'=>'instagram','account_id'=>'888071','report'=>'profile'];
M\Schedules::save(['schedule_id'=>'review071','label'=>'QA unreadable latest job','query'=>$query,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+3600]);
$bad='000071_corrupt';$payload='s1.'.base64_encode(random_bytes(80));
$wpdb->insert($t,['bucket'=>'job','record_key'=>$bad,'revision'=>7,'payload'=>$payload,'updated_at'=>time()-5,'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
$s=M\Store::get('schedule','review071');$v=$s['value'];$v['last_job']=$bad;M\Store::put('schedule','review071',$v,$s['revision']);
M\Queue::migrate();wp_clear_scheduled_hook('f3_meta_worker');
[$h,$writes]=lab_writes(static fn()=>M\Api::dispatch('health'));
review_check('R1 health survives a quarantined last_job and names the affected schedule',$h['success']&&$h['data']['state']==='degraded'&&in_array('review071',array_column($h['data']['issues'],'schedule_id'),true),['code'=>$h['code']]);
review_check('R1 health does not repair or send provider/mail effects',lab_non_audit_writes($writes,$t,'f3_meta')===[]&&wp_next_scheduled('f3_meta_worker')===false&&$calls===0&&$mail===0);
$status=M\Api::dispatch('status');
review_check('R1 status still recovers missing worker despite unreadable last_job',$status['success']&&$status['data']['recovery']['attempted']&&wp_next_scheduled('f3_meta_worker')!==false,['code'=>$status['code']]);
M\Store::remove('schedule','review071',M\Store::get('schedule','review071')['revision']);$wpdb->delete($t,['bucket'=>'job','record_key'=>$bad]);wp_clear_scheduled_hook('f3_meta_worker');

// Twenty already-projected queued jobs with corrupt ciphertext precede a valid job indefinitely in 0.7.0.
for($i=0;$i<20;$i++)$wpdb->insert($t,['bucket'=>'job','record_key'=>'000071_starve_'.str_pad((string)$i,2,'0',STR_PAD_LEFT),'revision'=>7,'payload'=>$payload,'updated_at'=>123,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
$valid=M\Jobs::create(['query'=>$query,'idempotency_key'=>'review071_valid']);
M\Jobs::tick();M\Jobs::tick();$r=M\Store::get('job',$valid['job_id']);
$marked=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND record_key LIKE %s AND queue_state='unreadable'",$t,'000071_starve_%'));
review_check('R2 corrupt due jobs leave runnable selection; valid job completes by next pass',$marked===20&&$r['value']['status']==='complete',['quarantined'=>$marked,'valid_status'=>$r['value']['status']]);
$saved=$wpdb->get_row($wpdb->prepare("SELECT payload,revision,updated_at,expires_at FROM %i WHERE bucket='job' AND record_key=%s",$t,'000071_starve_00'),ARRAY_A);
review_check('R2 quarantine preserves ciphertext revision timestamp and retention',$saved['payload']===$payload&&(int)$saved['revision']===7&&(int)$saved['updated_at']===123&&(int)$saved['expires_at']===0);
$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'000071_starve_%'));

// Independent failure/concurrency cases for the isolation guard added in 0.7.1.
if(method_exists(M\Queue::class,'isolate')){
 $guardKey='000071_guard';
 $wpdb->insert($t,['bucket'=>'job','record_key'=>$guardKey,'revision'=>7,'payload'=>$payload,'updated_at'=>123,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
 $denyRead=static function($sql)use($guardKey){if(str_starts_with($sql,'SELECT revision,payload')&&str_contains($sql,$guardKey))throw new M\Fault('storage_unavailable','synthetic read outage');return $sql;};
 add_filter('query',$denyRead);$caught=null;try{M\Queue::isolate($guardKey);}catch(M\Fault $e){$caught=$e->reason;}finally{remove_filter('query',$denyRead);}
 $raw=$wpdb->get_row($wpdb->prepare("SELECT queue_state,revision,payload FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey),ARRAY_A);
 review_check('R3 transient storage error never quarantines a record',$caught==='storage_unavailable'&&$raw['queue_state']==='queued'&&(int)$raw['revision']===7&&$raw['payload']===$payload);
 $fresh=$r['value'];$fresh['status']='queued';$fresh['next_at']=time()+600;
 $raceDone=false;$race=static function($sql)use(&$raceDone,$guardKey,$fresh){if(!$raceDone&&str_starts_with($sql,'UPDATE ')&&str_contains($sql,$guardKey)&&str_contains($sql,"'unreadable'")){$raceDone=true;M\Store::put('job',$guardKey,$fresh,7);}return $sql;};
 add_filter('query',$race);try{$isolated=M\Queue::isolate($guardKey);}finally{remove_filter('query',$race);}
 $raw=$wpdb->get_row($wpdb->prepare("SELECT queue_state,revision,payload FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey),ARRAY_A);
 review_check('R4 CAS cannot overwrite the projection of a newer readable revision',$raceDone&&!$isolated&&$raw['queue_state']==='queued'&&(int)$raw['revision']===8&&M\Store::get('job',$guardKey)['value']===$fresh);
 review_check('R4 a readable job is never isolated',M\Queue::isolate($guardKey)===false);
 $wpdb->delete($t,['bucket'=>'job','record_key'=>$guardKey]);
 $wpdb->insert($t,['bucket'=>'job','record_key'=>$guardKey,'revision'=>7,'payload'=>$payload,'updated_at'=>123,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
 [$host,$port,$sock]=$wpdb->parse_db_host(DB_HOST);$other=new mysqli($host,DB_USER,DB_PASSWORD,DB_NAME,$port??3306,$sock);
 $lock='f3s:'.substr(hash('sha256',DB_NAME.'|'.$t.'|job:'.$guardKey),0,55);$other->query("SELECT GET_LOCK('".$other->real_escape_string($lock)."',0)");
 $busy=null;try{M\Queue::isolate($guardKey);}catch(M\Fault $e){$busy=$e->reason;}finally{$other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($lock)."')");$other->close();}
 review_check('R5 isolation respects the real job lock held by another DB connection',$busy==='busy'&&$wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey))==='queued');
 review_check('R5 isolation succeeds after the competing lock is released',M\Queue::isolate($guardKey));
 $wpdb->delete($t,['bucket'=>'job','record_key'=>$guardKey]);
 $brokenJson=M\Crypto::seal('{invalid-json');$wpdb->insert($t,['bucket'=>'job','record_key'=>$guardKey,'revision'=>4,'payload'=>$brokenJson,'updated_at'=>456,'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
 $migration=M\Queue::migrate();$raw=$wpdb->get_row($wpdb->prepare("SELECT queue_state,revision,payload,updated_at FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey),ARRAY_A);
 review_check('R6 malformed decrypted JSON is isolated without changing business bytes',$migration['unreadable']===1&&$raw['queue_state']==='unreadable'&&(int)$raw['revision']===4&&$raw['payload']===$brokenJson&&(int)$raw['updated_at']===456);
 $wpdb->delete($t,['bucket'=>'job','record_key'=>$guardKey]);
}

$result=['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'http_fixture_calls'=>$calls,'mail_intercepted'=>$mail];
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/review071.json',wp_json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo wp_json_encode(['total'=>$result['total'],'failed'=>$result['failed']])."\n";
if($result['failed'])exit(1);
