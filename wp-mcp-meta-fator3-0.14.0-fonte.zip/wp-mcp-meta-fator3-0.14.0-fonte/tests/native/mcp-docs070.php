<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require_once __DIR__.'/lab-helpers.php';wp_set_current_user(1);
if(!class_exists('WpMcpUltimate\\Server\\Abilities\\ExecuteAbilityAbility'))exit(0);
use Fator3\McpFiles as C;
$grant='qa070docs_'.bin2hex(random_bytes(8));$http=0;$reads=[];$checks=[];
C\Persistence::put('oauth-grants',$grant,['grant_id'=>$grant,'user_id'=>1,'client_id'=>'qa070docs','profile'=>'maintenance','status'=>'active']);C\ConnectionContext::oauth(['user_id'=>1,'grant_id'=>$grant,'client_id'=>'qa070docs','profile'=>'maintenance']);
add_filter('pre_http_request',function()use(&$http){$http++;return new WP_Error('blocked','No provider access');},1);
function doc070(array $input): array {$r=\WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility::execute(['ability_name'=>'meta/documentation','parameters'=>$input]);if(empty($r['success'])||empty($r['data']['success']))throw new RuntimeException('MCP document failed: '.wp_json_encode($r));return $r['data']['data'];}
try{
 $index=doc070(['document'=>'index']);foreach($index['documents'] as $item){$offset=0;$text='';$pages=0;do{$p=doc070(['document'=>$item['document'],'offset'=>$offset,'limit_bytes'=>16384,'expected_revision'=>$item['sha256']]);$text.=$p['content'];$offset=$p['next_offset'];$pages++;}while($offset!==null);
  $ok=hash('sha256',$text)===$item['sha256']&&strlen($text)===$item['bytes']&&$text===file_get_contents(\Fator3\Meta\Config::DIR.'docs/'.$item['document']);$checks[]=['name'=>'native MCP complete '.$item['document'],'passed'=>$ok];$reads[]=$item+['pages'=>$pages];
 }
 $checks[]=['name'=>'MCP documentation no provider access','passed'=>$http===0];
 $r=['transport'=>'actual MCP native executor ('.(lab_companion('wp-mcp-fator3/wp-mcp-fator3.php')??'?').'), in real local WordPress; no remote HTTP session','documents'=>$reads,'pages'=>array_sum(array_column($reads,'pages')),'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed']))];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/mcp-docs070.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));echo json_encode(['mcp_docs'=>count($reads),'pages'=>$r['pages'],'failed'=>$r['failed']])."\n";
}finally{C\Persistence::delete('connections','grant:'.$grant);C\Persistence::delete('oauth-grants',$grant);C\ConnectionContext::restore_identity(null,1);}
if($r['failed'])exit(1);
