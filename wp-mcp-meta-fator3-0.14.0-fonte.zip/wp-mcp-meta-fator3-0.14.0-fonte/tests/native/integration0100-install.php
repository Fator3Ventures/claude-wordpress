<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/plugin.php';wp_set_current_user(1);
$slugs=['base-site-core-fator3','wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-linkedin-fator3','wp-mcp-pipedrive-fator3'];
foreach($slugs as $slug){$r=activate_plugin($slug.'/'.$slug.'.php');if(is_wp_error($r))throw new RuntimeException($slug.':'.$r->get_error_code());}
echo wp_json_encode(['activated'=>get_option('active_plugins')]);
