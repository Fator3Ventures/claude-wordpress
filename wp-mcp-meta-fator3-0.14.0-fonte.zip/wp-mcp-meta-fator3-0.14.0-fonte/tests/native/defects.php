<?php
/**
 * Defect probes that run unchanged against the base and the candidate installer (same public/internal API present in both).
 * Output: one JSON line per probe with "fixed" true/false; never fails the run. Used to prove "falha na base, passa no alvo".
 */
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/plugin.php';require_once __DIR__.'/lab-helpers.php';
$provider=str_contains((string)getenv('F3_SOURCE_ROOT'),'linkedin')?'LinkedIn':'Meta';$ns='Fator3\\'.$provider.'\\';$key=$provider==='Meta'?'f3_meta':'f3_linkedin';
$S=$ns.'Store';$C=$ns.'Connections';$Sch=$ns.'Schedules';$A=$ns.'Access';$Api=$ns.'Api';
wp_set_current_user(1);global $wpdb;$t=$S::table();$out=[];
$report=static function(string $id,bool $fixed,$detail=null)use(&$out){$out[]=['probe'=>$id,'fixed'=>$fixed,'detail'=>$detail];echo json_encode(end($out),JSON_UNESCAPED_UNICODE)."\n";};
add_filter('pre_http_request',static function($pre,$args,$url){$id=basename((string)parse_url($url,PHP_URL_PATH));return ['headers'=>[],'body'=>wp_json_encode(['id'=>$id,'name'=>'probe','localizedName'=>'probe','username'=>'probe','followers_count'=>1]),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];},1,3);
$meta=$provider==='Meta';
$C::save(['connection_id'=>'probe','expected_revision'=>0,'token'=>'probe-synthetic-not-a-token','assets'=>$meta?['instagram'=>['888']]:['pages'=>['888']],'users'=>[1]]);
$q=$meta?['connection_id'=>'probe','channel'=>'instagram','account_id'=>'888','report'=>'profile']:['connection_id'=>'probe','channel'=>'pages','account_id'=>'888','report'=>'organization'];
$Sch::save(['schedule_id'=>'probe_hourly','label'=>'Probe','query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()-60]);
// D1 — a worker pass that throws must still leave the next pass scheduled.
$seen=0;$boom=static function($sql)use(&$seen){if(str_starts_with($sql,'SELECT record_key FROM')&&str_contains($sql,"bucket='schedule' ORDER")&&++$seen===1)throw new RuntimeException('probe exception');return $sql;};
wp_clear_scheduled_hook($key.'_worker');add_filter('query',$boom);try{do_action($key.'_worker');}catch(Throwable $e){}finally{remove_filter('query',$boom);}
$report('D1 worker pass with exception keeps the next pass scheduled',wp_next_scheduled($key.'_worker')!==false,get_option($key.'_last_worker'));
// D2 — 2000 completed jobs must not delay the hourly schedule job.
$template=['query'=>$q,'principal'=>$A::principal(),'connection_revision'=>1,'status'=>'complete','pages'=>0,'rows'=>0,'created_at'=>time()-86400,'updated_at'=>time()-86400,'next_at'=>0,'last_code'=>null,'errors'=>[]];
for($n=0;$n<2000;$n++)$S::put('job','0000000000000000probe_done_'.str_pad((string)$n,4,'0',STR_PAD_LEFT),$template);
$s=$S::get('schedule','probe_hourly');$v=$s['value'];$v['next_at']=time()-60;$S::put('schedule','probe_hourly',$v,$s['revision']);
wp_clear_scheduled_hook($key.'_worker');do_action($key.'_worker');
$s=$S::get('schedule','probe_hourly');$job=$S::get('job',(string)($s['value']['last_job']??'missing'));
$report('D2 hourly job completes on the first pass behind 2000 completed jobs',(bool)($job&&$job['value']['status']==='complete'),$job['value']['status']??null);
$v=$S::get('schedule','probe_hourly');$vv=$v['value'];$vv['enabled']=false;$S::put('schedule','probe_hourly',$vv,$v['revision']);
// D3 — the hourly maintenance event comes back on the next request.
wp_clear_scheduled_hook($key.'_maintenance');$c=lab_child('echo json_encode(["next"=>wp_next_scheduled("'.$key.'_maintenance")]);');
$report('D3 missing hourly maintenance self-heals on the next request',!empty($c['json']['next']),$c['json']);
if(!wp_next_scheduled($key.'_maintenance'))wp_schedule_event(time()+3600,'hourly',$key.'_maintenance');
// D4 — 150 expired jobs that the site key cannot open, ordered first, must not keep a readable expired job from retention.
$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'0000000000000000probe_done_%'));
$cols=$wpdb->get_col("SHOW COLUMNS FROM $t");
for($n=0;$n<150;$n++){$row=['bucket'=>'job','record_key'=>'000000000000000000probe_bad_'.str_pad((string)$n,3,'0',STR_PAD_LEFT),'revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>time()-10];if(in_array('queue_state',$cols,true))$row+=['queue_state'=>'unreadable','queue_next'=>0];$wpdb->insert($t,$row);}
$S::put('job','000000000000000000probe_zold',$template,0,time()-10);$err=null;try{$S::prune();}catch(Throwable $e){$err=($e->reason??get_class($e));}
$report('D4 retention reaches a readable expired job behind 150 unreadable expired jobs',$err===null&&$S::get('job','000000000000000000probe_zold')===null,$err);
$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'000000000000000000probe_%'));
// D5 — audit listing returns the newest events first.
$base=time()+1000;foreach(['0000probe_a'=>30,'0000probe_b'=>20,'0000probe_c'=>10] as $k=>$age){$S::put('audit',$k,['operation'=>'probe-'.$age,'actor'=>['type'=>'user','id'=>1],'transport'=>'local_sdk','connection_id'=>null,'code'=>'ok','at'=>$base-$age],0,time()+86400);$wpdb->update($t,['updated_at'=>$base-$age],['bucket'=>'audit','record_key'=>$k]);}
$r=$Api::dispatch('audit',[]);$ops=array_slice(array_column($r['data']['events']??[],'operation'),0,3);
$report('D5 audit lists the newest events first',$ops===['probe-10','probe-20','probe-30'],$ops);
// D6 — a fresh request runs no SQL of its own for the package bootstrap once the queue is settled (options or table).
if(in_array('queue_state',$cols,true)){
 $needle=var_export([$t,$key.'_'],true);
 $probe=[['query',10,'foreach('.$needle.' as $n)if(str_contains((string)$a[0],$n)){$GLOBALS["pkgq"][]=substr((string)$a[0],0,160);break;}return $a[0];']];
 lab_child('echo json_encode(["ok"=>1]);',$probe);lab_child('echo json_encode(["ok"=>1]);',$probe);$c=lab_child('echo json_encode(["queries"=>$GLOBALS["pkgq"]??[]]);',$probe);
 $report('D6 settled bootstrap runs no package SQL per request',($c['json']['queries']??['?'])===[],$c['json']);
 // D7 — one unreadable legacy job must not block the migration of the others.
 $wpdb->query($wpdb->prepare("UPDATE %i SET queue_state='',queue_next=0 WHERE bucket='job'",$t));
 $wpdb->insert($t,['bucket'=>'job','record_key'=>'000000000000000000probe_bad2','revision'=>1,'payload'=>'s1.'.base64_encode(random_bytes(80)),'updated_at'=>time(),'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
 $Q=$ns.'Queue';$e2=null;for($i=0;$i<5;$i++){try{$Q::migrate();}catch(Throwable $e){$e2=$e->reason??get_class($e);}}
 $pending=(bool)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND queue_state='' AND record_key<>%s",$t,'000000000000000000probe_bad2'));
 $report('D7 unreadable legacy job does not block migration of the others',!$pending,$e2);
 $wpdb->delete($t,['bucket'=>'job','record_key'=>'000000000000000000probe_bad2']);
}
// D9 — every installed document can be read to the end through the public operation with 16 KiB pages.
$idx=$Api::dispatch('documentation',['document'=>'index']);$bad=[];
foreach($idx['data']['documents']??[] as $doc){$o=0;$txt='';do{$r=$Api::dispatch('documentation',['document'=>$doc['document'],'offset'=>$o,'limit_bytes'=>16384,'expected_revision'=>$doc['sha256']]);if(empty($r['success'])){$bad[]=$doc['document'].'@'.$o.':'.($r['code']??'');break;}$txt.=$r['data']['content'];$o=$r['data']['next_offset'];}while($o!==null);if($o===null&&hash('sha256',$txt)!==$doc['sha256'])$bad[]=$doc['document'].':hash';}
$report('D9 documentation readable to the end with 16 KiB pages through the operation',$bad===[],$bad);
if($provider==='LinkedIn'&&class_exists('F3Base_Linkedin_Cliente')){
 $n=static fn()=>count(array_filter(lab_debug_lines(),static fn($l)=>str_contains($l,'<code>f3base</code> domain was triggered too early')));$b=$n();lab_child('echo json_encode(["ok"=>1]);');
 $report('D8 a request with Site Core active loads no f3base translation too early',$n()===$b,$n()-$b);
}
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/defects-'.getenv('F3_LAB_VERSION').'.json',wp_json_encode(['version'=>getenv('F3_LAB_VERSION'),'probes'=>$out],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
