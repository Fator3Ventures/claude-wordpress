<?php
$_SERVER['HTTP_HOST']='example.invalid';$_SERVER['SERVER_NAME']='example.invalid';$_SERVER['REQUEST_URI']='/';
define('WP_INSTALLING',true);require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
if(is_blog_installed())throw new RuntimeException('Expected fresh tables');
wp_install('Meta isolated review','qa071admin','qa071@example.invalid',false,'',bin2hex(random_bytes(20)),'pt_BR');
wp_set_current_user(1);$r=activate_plugin('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');if(is_wp_error($r))throw new RuntimeException($r->get_error_code());
echo json_encode(['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>Fator3\Meta\Config::VERSION,'active_plugins'=>get_option('active_plugins'),'installed'=>true])."\n";
if(Fator3\Meta\Config::VERSION==='0.12.0')require __DIR__.'/isolated0130-seed.php';
