<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
use Fator3\Meta as M;
wp_set_current_user(1);$checks=[];$mode='valid';$calls=0;$mails=[];$tokenA='EAA'.str_repeat('A',110);$tokenB='EAA'.str_repeat('B',110);$app='123456789012345';$secret=str_repeat('a',32);$id='qa0100';
function ck100($name,$ok,$detail=[]){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok,'details'=>$detail];echo wp_json_encode(end($checks))."\n";}
function call100($op,$i=[]){return M\Api::dispatch($op,$i);}
function tick100($sid){$r=M\Store::get('schedule',$sid);$v=$r['value'];static $tick=0,$origin=null;$origin=$origin??time();$v['next_at']=$origin-1-(++$tick);M\Store::put('schedule',$sid,$v,$r['revision']);M\Schedules::tick();$s=M\Store::get('schedule',$sid)['value'];return M\Jobs::run($s['last_job'],true);}
$http=static function($pre,$args,$url)use(&$mode,&$calls,$tokenB,$app){
 $calls++;$path=preg_replace('~^/v[0-9.]+/~','',parse_url($url,PHP_URL_PATH));parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);$token=$q['input_token']??substr($args['headers']['Authorization']??'',7);$subject=$token===$tokenB?'902':'901';
 $err=static fn($code,$sub,$status)=>['headers'=>[],'body'=>wp_json_encode(['error'=>['code'=>$code,'error_subcode'=>$sub,'message'=>'SECRET_MARKER_NEVER_LOG','is_transient'=>false]]),'response'=>['code'=>$status],'cookies'=>[]];
 if($mode==='revoked')return $err(190,463,400);
 if($path==='debug_token')$body=['data'=>['is_valid'=>true,'app_id'=>$app,'application'=>'QA app','user_id'=>$subject,'expires_at'=>0,'scopes'=>M\Credentials::READ_SCOPES]];
 elseif($path==='me'){if($mode==='uncertain')return new WP_Error('qa_network');$body=['id'=>$subject,'name'=>'QA identity '.$subject];}
 elseif($path==='910/stories'){
  if($mode==='inventory_denied')return $err(200,201,403);
  $body=['data'=>[['id'=>'555','timestamp'=>gmdate('c',time()-($mode==='expired'?90000:300)),'media_type'=>'IMAGE','media_product_type'=>'STORY']]];
 }elseif($path==='555/insights'){
  if(in_array($mode,['expired','denied','uncertain'],true))return $err(200,33,403);
  if($mode==='notfound')return $err(100,33,400);
  if($mode==='limited')return $err(4,0,429);
  if($mode==='network')return new WP_Error('qa_network');
  $body=['data'=>$mode==='empty'?[]:[['name'=>$q['metric'],'period'=>'lifetime','values'=>[['value'=>8]]]]];
 }elseif($path==='910'){
  if($mode==='resource_denied')return $err(200,99,403);
  $body=['id'=>'910','username'=>'qa0100'];
 }else return new WP_Error('qa_unexpected_http');
 return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200],'cookies'=>[]];
};add_filter('pre_http_request',$http,1,3);$mail=static function($pre,$attrs)use(&$mails){$mails[]=$attrs;return true;};add_filter('pre_wp_mail',$mail,1,2);
try{
 $new=call100('save-connection',['connection_id'=>$id,'expected_revision'=>0,'label'=>'Old name','client_id'=>$app,'client_secret'=>$secret,'token'=>$tokenA,'assets'=>['instagram'=>['910']]]);
 ck100('Validated initial identity persisted',$new['success']);if(!$new['success'])throw new RuntimeException('fixture creation failed');
 foreach(['stories','stories_insights','profile'] as $report)M\Schedules::save(['schedule_id'=>'qa0100-'.$report,'query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>$report]+($report==='stories_insights'?['fields'=>['reach']]:[]),'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+7200]);
 $c=M\Connections::get($id);$switch=['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$tokenB,'label'=>'New name','dry_run'=>true];
 $before=M\Store::get('connection',$id);$schedules=M\Schedules::list();$r=call100('switch-identity',$switch);
 ck100('Preview returns proposed name and makes no connection or schedule change',$r['success']&&$r['data']['connection_label']==='New name'&&M\Store::get('connection',$id)===$before&&M\Schedules::list()===$schedules);
 $changed=call100('switch-identity',array_replace($switch,['dry_run'=>false,'label'=>'Unreviewed name','confirmation'=>$r['data']['confirmation']]));ck100('Name is bound to confirmation',$changed['code']==='confirmation_mismatch'&&M\Store::get('connection',$id)===$before);
 $result=call100('switch-identity',array_replace($switch,['dry_run'=>false,'confirmation'=>$r['data']['confirmation']]));$c=M\Connections::get($id);
 ck100('Identity and name commit in one connection revision',$result['success']&&$c['label']==='New name'&&$c['token_identity']['subject_id']==='902'&&$c['revision']===$before['revision']+1);
 ck100('Every schedule rebased in same operation',$result['data']['schedules_rebased']===3&&count(array_filter(M\Schedules::list(),static fn($s)=>str_starts_with($s['schedule_id'],'qa0100-')&&$s['connection_revision']===$c['revision']))===3);
 $s=M\Store::get('schedule','qa0100-profile');$v=$s['value'];$v['enabled']=false;M\Store::put('schedule','qa0100-profile',$v,$s['revision']);
 foreach(['expired'=>'story_expired','denied'=>'story_insights_unavailable','empty'=>'story_insights_unavailable','notfound'=>'story_insights_unavailable','uncertain'=>'story_insights_unavailable'] as $scenario=>$expected){
  $mode=$scenario;$job=tick100('qa0100-stories_insights');$s=M\Store::get('schedule','qa0100-stories_insights')['value'];
  ck100($scenario.' is partial, classified, and keeps schedule enabled',$job['status']==='partial'&&$job['last_code']===$expected&&$s['last_code']===$expected&&$s['enabled'],['job_status'=>$job['status'],'job_code'=>$job['last_code'],'schedule_code'=>$s['last_code']]);
  ck100($scenario.' retains timestamp and nullable numeric diagnostic',$s['last_error']['code']===$expected&&is_int($s['last_error']['observed_at'])&&array_key_exists('provider_subcode',$s['last_error']));
  M\Worker::notify();ck100($scenario.' never raises authorization issue or sends mail',!array_filter(M\Worker::health()['issues'],static fn($i)=>str_contains($i['code'],'authorization'))&&count($mails)===0);
  if($scenario==='expired'){$events=M\Audit::list([])['events'];$event=array_values(array_filter($events,static fn($e)=>$e['operation']==='collection-run'&&$e['job_id']===$job['job_id']))[0]??[];
   ck100('Graph status, code and subcode survive to collection audit',($event['last_error']['http_status']??null)===403&&($event['last_error']['provider_code']??null)===200&&($event['last_error']['provider_subcode']??null)===33);
  }
 }
 $mode='inventory_denied';$job=tick100('qa0100-stories');ck100('Stories inventory denial remains a resource unavailability',$job['last_code']==='story_insights_unavailable');M\Worker::notify();ck100('Inventory denial sends no mail',count($mails)===0);
 $mode='valid';$job=tick100('qa0100-stories_insights');$s=M\Store::get('schedule','qa0100-stories_insights')['value'];ck100('Recovery clears current code while retaining historical last error',$job['status']==='complete'&&$s['last_code']===null&&$s['last_error']['code']==='story_insights_unavailable'&&$s['last_success_at']>0);
 $mode='revoked';$job=tick100('qa0100-stories');$c=M\Connections::get($id);$failure=M\CollectionState::connectionFailure($c);
 ck100('Revoked token confirmed by connection probe becomes not_authorized',$job['last_code']==='not_authorized'&&$failure['auth_scope']==='connection'&&$failure['provider_code']===190&&$failure['provider_subcode']===463&&$failure['connection_validation']['provider_code']===190);
 $schedules=array_values(array_filter(M\Schedules::list(),static fn($s)=>str_starts_with($s['schedule_id'],'qa0100-')));
 ck100('Confirmed revocation records all schedules, including paused, without changing selection',count(array_filter($schedules,static fn($s)=>$s['last_code']==='not_authorized'&&$s['last_error']['provider_subcode']===463))===3&&!M\Store::get('schedule','qa0100-profile')['value']['enabled']);
 ck100('Health aggregates connection incident once',count(array_filter(M\Worker::health()['issues'],static fn($i)=>$i['code']==='connection_authorization_failed'))===1&&count(array_filter(M\Worker::health()['issues'],static fn($i)=>$i['code']==='schedule_authorization_failed'))===0);
 M\Worker::notify();M\Worker::notify();$notice=get_option('f3_meta_operation_notice');$notice['attempted_at']=time()-7200;update_option('f3_meta_operation_notice',$notice,false);M\Worker::notify();
 ck100('Exactly one mail attempt for persistent connection incident beyond one hour',count($mails)===1);
 ck100('Mail contains measured cause and correct connection action',str_contains($mails[0]['message'],'190/463')&&str_contains($mails[0]['message'],'Renove o token')&&!str_contains($mails[0]['message'],'salve novamente esta agenda'));
 $mode='valid';$job=tick100('qa0100-stories');M\Worker::notify();ck100('Successful fresh collection resolves incident without recovery mail',M\CollectionState::connectionFailure(M\Connections::get($id))===null&&count($mails)===1&&!array_filter(M\Worker::health()['issues'],static fn($i)=>str_contains($i['code'],'authorization')));
 $s=M\Store::get('schedule','qa0100-profile')['value'];ck100('Recovery preserves last revocation evidence on other schedule',$s['last_code']===null&&$s['last_error']['provider_code']===190);
 $mode='revoked';tick100('qa0100-stories');M\Worker::notify();ck100('A distinct incident after recovery gets one new notice',count($mails)===2);
 $mode='valid';$c=M\Connections::get($id);$rot=call100('rotate-token',['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>'EAA'.str_repeat('C',110)]);
 // Same identity in fixture: token C resolves to identity A, so this deliberately needs guided confirmation.
 ck100('Credential identity protection remains active',$rot['code']==='credential_identity_mismatch');
 $c=M\Connections::get($id);$switch=['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$tokenA,'dry_run'=>true];$preview=call100('switch-identity',$switch);$done=call100('switch-identity',array_replace($switch,['dry_run'=>false,'confirmation'=>$preview['data']['confirmation']]));
 ck100('Accepted replacement supersedes stale connection incident',$done['success']&&M\CollectionState::connectionFailure(M\Connections::get($id))===null);
 M\Worker::notify();ck100('Old job does not reintroduce authorization alarm after replacement',!array_filter(M\Worker::health()['issues'],static fn($i)=>str_contains($i['code'],'authorization'))&&count($mails)===2);
 $mode='resource_denied';$manual=M\Jobs::create(['query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'idempotency_key'=>'qa0100-resource']);$job=M\Jobs::run($manual['job_id']);ck100('Single non-Story resource denial is not global revocation',$job['last_code']==='asset_access_denied'&&M\CollectionState::connectionFailure(M\Connections::get($id))===null);
 $mode='network';$job=tick100('qa0100-stories_insights');ck100('Network failure retains retry semantics',$job['status']==='retry'&&$job['last_code']==='upstream_error');
 $mode='limited';$job=tick100('qa0100-stories_insights');ck100('Rate limit retains retry and measured 429',$job['status']==='retry'&&$job['last_code']==='rate_limited'&&$job['last_error']['http_status']===429);
 $gone=M\Connections::get($id);unset($gone['revision']);$gone['id']='qa0100-gone';M\Store::put('connection',$gone['id'],$gone);$lost=M\Jobs::create(['query'=>['connection_id'=>$gone['id'],'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'idempotency_key'=>'qa0100-gone-'.wp_generate_uuid4()]);global $wpdb;$wpdb->delete(M\Store::table(),['bucket'=>'connection','record_key'=>$gone['id']]);$lostResult=M\Jobs::run($lost['job_id']);ck100('Deleted connection keeps paused job result and collection audit',$lostResult['status']==='paused'&&$lostResult['last_code']==='not_configured');$wpdb->delete(M\Store::table(),['bucket'=>'job','record_key'=>$lost['job_id']]);
 $json=wp_json_encode(M\Schedules::list()).wp_json_encode(M\Audit::list([])).wp_json_encode($mails);ck100('No provider message or secret escapes diagnostics',!str_contains($json,'SECRET_MARKER_NEVER_LOG')&&!str_contains($json,$tokenA)&&!str_contains($json,$secret));
 $user=wp_insert_user(['user_login'=>'qa0100subscriber','user_pass'=>wp_generate_password(),'role'=>'subscriber']);wp_set_current_user($user);ck100('Subscriber cannot read schedule error or audit',call100('list-schedules')['code']==='not_authorized'&&call100('audit')['code']==='not_authorized');wp_set_current_user(1);
}catch(Throwable $e){ck100('Suite completed',false,['exception'=>get_class($e),'message'=>$e->getMessage()]);}
finally{wp_set_current_user(1);remove_filter('pre_http_request',$http,1);remove_filter('pre_wp_mail',$mail,1);global $wpdb;$rows=M\Store::list('schedule',0,100);foreach($rows as $row)if(str_starts_with($row['key'],'qa0100-'))$wpdb->delete(M\Store::table(),['bucket'=>'schedule','record_key'=>$row['key']]);foreach(['connection','collection_failure','quota'] as $bucket)$wpdb->delete(M\Store::table(),['bucket'=>$bucket,'record_key'=>$id]);foreach(M\Store::list('job',0,1000) as $row)if(in_array($row['value']['query']['connection_id']??'',[$id,'qa0100-gone'],true)){$wpdb->delete(M\Store::table(),['bucket'=>'job','record_key'=>$row['key']]);$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE bucket=%s AND record_key LIKE %s',M\Store::table(),'result',$wpdb->esc_like($row['key'].':').'%'));}if(isset($user)&&is_int($user)){require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($user);}delete_option('f3_meta_operation_notice');}
$r=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),'synthetic_http_calls'=>$calls,'mail_attempts_intercepted'=>count($mails),'real_provider_calls'=>0,'real_mail'=>0];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/release0100.json',wp_json_encode($r));echo wp_json_encode($r)."\n";if($r['failed'])exit(1);
