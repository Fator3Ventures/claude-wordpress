<?php
/** Only fixtures for unrelated worker/queue regressions. New credentials are tested through public routes in release090. */
function lab_seed_connection090(array $i): array {
 $row=\Fator3\Meta\Store::get('connection',$i['connection_id']);
 if($row)return \Fator3\Meta\Connections::save($i);
 $token=$i['token']??'';unset($i['token']);
 $result=\Fator3\Meta\Connections::save($i);
 $row=\Fator3\Meta\Store::get('connection',$i['connection_id']);$v=$row['value'];$v['token']=$token;$v['token_configured']=$token!=='';
 \Fator3\Meta\Store::put('connection',$i['connection_id'],$v,$row['revision']);
 return ['persisted'=>true,'connection'=>\Fator3\Meta\Connections::public(\Fator3\Meta\Connections::get($i['connection_id']))];
}
