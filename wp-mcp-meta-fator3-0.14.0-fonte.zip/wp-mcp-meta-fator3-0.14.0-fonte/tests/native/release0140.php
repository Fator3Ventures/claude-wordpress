<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
use Fator3\Meta as M;
wp_set_current_user(1);global $wpdb;
$checks=[];$httpCalls=0;$mailCalls=0;$mode='valid';$paths=[];
$id='qa0140-token';$account='140';$app='123456789012345';$secret=str_repeat('a',32);
$token='E'.str_repeat('B7',99);$otherIdentity='E'.str_repeat('N8',99);$tokens=[$token,$otherIdentity];
function ck140(string $name,bool $ok,array $details=[]): void {global $checks;$checks[]=['name'=>$name,'passed'=>$ok,'details'=>$details];if(!$ok)throw new RuntimeException($name);}
function call140(string $op,array $i): array {M\Http::budget(40,25);return M\Api::dispatch($op,$i);}
function snap140(): array {global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE bucket IN (%s,%s) ORDER BY bucket,record_key',M\Store::table(),'connection','schedule'),ARRAY_A);}
function change140(string $op,string $token,array $extra=[]): array {global $id;$c=M\Connections::get($id);$i=['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$token]+$extra;if($op==='switch-identity'&&!isset($i['dry_run']))$i['dry_run']=true;return call140($op,$i);}
$http=static function($pre,$args,$url)use(&$httpCalls,&$mode,&$paths,$app,$otherIdentity,$account){
 $httpCalls++;$path=basename(parse_url($url,PHP_URL_PATH));$paths[]=$path;parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);$candidate=$q['input_token']??substr($args['headers']['Authorization']??'',7);$subject=$candidate===$otherIdentity?'902':'901';
 if($path==='debug_token'){
  if($mode==='190')return ['headers'=>[],'body'=>wp_json_encode(['error'=>['code'=>190,'message'=>'private fixture '.$candidate]]),'response'=>['code'=>401],'cookies'=>[]];
  $body=['data'=>['is_valid'=>$mode!=='invalid','type'=>'SYSTEM_USER','app_id'=>$mode==='app'?'999999999999999':$app,'application'=>'QA App','user_id'=>$subject,'expires_at'=>$mode==='expired'?time()-1:0,'scopes'=>$mode==='ads_missing'?array_values(array_diff(M\Credentials::READ_SCOPES,['ads_read'])):M\Credentials::READ_SCOPES]];
 }elseif($path==='me')$body=['id'=>$mode==='subject'?'999':$subject,'name'=>$subject==='902'?'QA Novo':'QA Original'];
 elseif($path==='910')$body=['id'=>'910','username'=>'qa0140'];
 elseif($path==='act_'.$account)$body=['id'=>'act_'.$account,'account_id'=>$account,'name'=>'QA Conta','currency'=>'BRL','timezone_name'=>'America/Sao_Paulo'];
 else return new WP_Error('qa0140_unexpected_http');
 return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200],'cookies'=>[]];
};
$mail=static function()use(&$mailCalls){$mailCalls++;return true;};add_filter('pre_http_request',$http,1,3);add_filter('pre_wp_mail',$mail,1);
$input=['connection_id'=>$id,'expected_revision'=>0,'token'=>$token,'client_id'=>$app,'client_secret'=>$secret,'assets'=>['instagram'=>['910'],'ads'=>[$account]]];
try {
 ck140('Fixture is alphanumeric, 199 bytes, E without EAA',strlen($token)===199&&ctype_alnum($token)&&str_starts_with($token,'E')&&!str_starts_with($token,'EAA'));
 if(M\Config::VERSION==='0.13.0'){
  $before=snap140();$r=call140('save-connection',$input);ck140('Baseline reproduces prefix refusal before provider',$r['code']==='invalid_token_format'&&$httpCalls===0&&str_contains($r['message'],'EAA'));ck140('Baseline refusal preserves business bytes',snap140()===$before);
 }else{
  ck140('Candidate version',M\Config::VERSION==='0.14.0');
  $req=new WP_REST_Request('POST','/f3-meta/v1/save-connection');$req->set_header('Content-Type','application/json');$req->set_body(wp_json_encode($input));M\Http::budget(40,25);$response=rest_do_request($req);$r=$response->get_data();
  ck140('Native REST save accepts non-EAA only after Graph proof',$response->get_status()===200&&$r['success']&&in_array('debug_token',$paths,true)&&in_array('me',$paths,true)&&in_array('act_'.$account,$paths,true));
  $c=M\Connections::get($id);ck140('Persisted identity, exact token, generation and ads_read',$c['token']===$token&&$c['credential_generation']===2&&$c['token_identity']['subject_id']==='901'&&$c['token_identity']['app_verified']&&$c['token_identity']['validated_generation']===2&&$c['expires_at']===0&&in_array('ads_read',$c['token_identity']['scopes'],true));
  M\Schedules::save(['schedule_id'=>'qa0140-active','query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'enabled'=>true,'interval_minutes'=>60,'expected_revision'=>0,'next_at'=>time()+7200]);
  M\Schedules::save(['schedule_id'=>'qa0140-paused','query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'enabled'=>false,'interval_minutes'=>60,'expected_revision'=>0,'next_at'=>time()+7201]);
  $beforeSchedules=M\Schedules::list();$auth=$c['authorization_revision'];
  foreach([['rotate-token','Z'.str_repeat('C',198)],['save-connection','EAA'.str_repeat('D',110)],['rotate-token','E'.str_repeat('G',198)]] as $index=>[$op,$value]){
   $tokens[]=$value;$r=change140($op,$value);$c=M\Connections::get($id);ck140($op.' accepts verified candidate generation '.($index+3),$r['success']&&$c['token']===$value&&$c['credential_generation']===$index+3&&$c['token_identity']['validated_generation']===$index+3&&$r['data']['schedules_rebased']===2);
  }
  ck140('Acceptance generation 4 to 5 is incremental with ads_read',$c['credential_generation']===5&&in_array('ads_read',$c['token_identity']['scopes'],true));
  $afterSchedules=M\Schedules::list();ck140('Renewals preserve authorizations, paused schedule and dates',$c['authorization_revision']===$auth&&array_column($beforeSchedules,'enabled')===array_column($afterSchedules,'enabled')&&array_column($beforeSchedules,'next_at')===array_column($afterSchedules,'next_at'));
  foreach(['save-connection','rotate-token','switch-identity'] as $op){
   foreach(['app_secret'=>$secret,'short'=>str_repeat('X',99),'space'=>'E'.str_repeat('X',100).' X','tab'=>'E'.str_repeat('X',100)."\tX",'newline'=>'E'.str_repeat('X',100)."\nX",'control'=>'E'.str_repeat('X',100)."\0X",'oversize'=>str_repeat('X',16385)] as $kind=>$value){
    $before=snap140();$n=$httpCalls;$r=change140($op,$value);ck140($op.' refuses '.$kind.' before HTTP and persistence',!$r['success']&&in_array($r['code'],['invalid_token_format','invalid_input'],true)&&$httpCalls===$n&&snap140()===$before);
    if($kind==='app_secret')ck140($op.' identifies App Secret',str_contains($r['message'],'Chave Secreta'));
   }
  }
  foreach(['100'=>str_repeat('Q',100),'16384'=>str_repeat('Q',16384)] as $length=>$value){$r=M\Result::run(static function()use($value,$app,$secret){M\Credentials::format(['token'=>$value,'client_id'=>$app,'client_secret'=>$secret]);return [];});ck140('Local bounds allow '.$length.' bytes without prefix',$r['success']);}
  foreach(['invalid'=>'token_rejected','190'=>'token_rejected','app'=>'credential_app_mismatch','subject'=>'credential_identity_mismatch','expired'=>'token_expired','ads_missing'=>'ads_read_required'] as $scenario=>$code){
   $mode=(string)$scenario;$before=snap140();$n=$httpCalls;$r=change140('rotate-token','E'.str_repeat('R',198));ck140('Provider '.$scenario.' refusal preserves old credential and schedules',$r['code']===$code&&$httpCalls>$n&&snap140()===$before&&!str_contains(wp_json_encode($r),'private fixture'));$mode='valid';
  }
  foreach(['save-connection','rotate-token'] as $op){$before=snap140();$r=change140($op,$otherIdentity);ck140($op.' still refuses identity change',$r['code']==='credential_identity_mismatch'&&snap140()===$before);}
  $before=snap140();$r=change140('switch-identity',$otherIdentity);$confirmation=$r['data']['confirmation']??'';ck140('Non-EAA switch preview proves identity without persistence',$r['success']&&!$r['data']['persisted']&&$r['data']['identity']['subject_id']==='902'&&snap140()===$before);
  $bad=change140('switch-identity',$token,['dry_run'=>false,'confirmation'=>$confirmation]);ck140('Confirmation cannot authorize another candidate',$bad['code']==='confirmation_mismatch'&&snap140()===$before);
  $r=change140('switch-identity',$otherIdentity,['dry_run'=>false,'confirmation'=>$confirmation]);$c=M\Connections::get($id);ck140('Non-EAA explicit switch commits once and rebases both schedules',$r['success']&&$c['token']===$otherIdentity&&$c['token_identity']['subject_id']==='902'&&$c['credential_generation']===6&&$r['data']['schedules_rebased']===2&&$c['authorization_revision']===$auth+1);
  $before=snap140();$n=$httpCalls;$r=call140('rotate-token',['connection_id'=>$id,'expected_revision'=>$c['revision']-1,'token'=>$token]);ck140('Stale revision refused before provider',$r['code']==='revision_conflict'&&$httpCalls===$n&&snap140()===$before);
  wp_set_current_user(0);$n=$httpCalls;foreach(['save-connection','rotate-token','switch-identity'] as $op){$r=change140($op,$token);ck140($op.' denies anonymous caller',$r['code']==='not_authorized'&&$httpCalls===$n);}wp_set_current_user(1);
  $_GET['tab']='connections';ob_start();M\Admin::screen();$html=ob_get_clean();ck140('Rendered help removes prefix requirement and describes remote proof',!str_contains($html,'Começa com EAA')&&str_contains($html,'De 100 a 16384 caracteres')&&str_contains($html,'A validade e a identidade são conferidas na Meta.'));
  $public=M\Api::dispatch('get-connection',['connection_id'=>$id]);$audit=M\Audit::list([]);$output=wp_json_encode([$public,$audit,$r]);$safe=true;foreach(array_merge($tokens,[$secret]) as $value)if(str_contains($output,$value))$safe=false;ck140('Public result and audit do not expose fixture credentials',$safe);
  ck140('No mail from credential paths',$mailCalls===0);
 }
}catch(Throwable $e){$checks[]=['name'=>'Suite completes','passed'=>false,'details'=>['exception'=>get_class($e),'message'=>$e->getMessage()]];}
finally{wp_set_current_user(1);remove_filter('pre_http_request',$http,1);remove_filter('pre_wp_mail',$mail,1);foreach(['schedule','connection'] as $bucket)foreach(M\Store::list($bucket,0,100) as $row)if($row['key']===$id||str_starts_with($row['key'],'qa0140-'))M\Store::remove($bucket,$row['key'],$row['revision']);}
$out=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),'intercepted_http'=>$httpCalls,'mail_calls'=>$mailCalls,'provider_homologation'=>false];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/release0140.json',wp_json_encode($out));echo wp_json_encode(['total'=>$out['total'],'failed'=>$out['failed']]);exit($out['failed']?1:0);
