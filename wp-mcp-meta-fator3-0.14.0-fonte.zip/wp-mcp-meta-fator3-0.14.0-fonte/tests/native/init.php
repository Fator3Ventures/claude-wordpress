<?php
$lab=getenv('F3_LAB_ROOT');$owner=json_decode(file_get_contents($lab.'/.social-lab.json'),true);if($owner['id']!==getenv('F3_LAB_ID'))throw new RuntimeException('Owned laboratory required');
$_SERVER['HTTP_HOST']='example.com';$_SERVER['SERVER_NAME']='example.com';define('WP_INSTALLING',true);require $lab.'/wordpress/wp-load.php';require_once ABSPATH.'wp-admin/includes/upgrade.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
wp_install('Social release tests','social_admin','qa@example.invalid',false,'',bin2hex(random_bytes(24)));update_option('home','https://example.com');update_option('siteurl','https://example.com');wp_set_current_user(1);
$order=getenv('F3_LAB_ORDER');$p=['wp-mcp-meta-fator3/wp-mcp-meta-fator3.php'];if($order==='linkedin-first')$p=array_reverse($p);if(str_ends_with($order,'-only'))$p=[$p[$order==='meta-only'?0:1]];
$trio=['wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php','base-site-core-fator3/base-site-core-fator3.php','wp-mcp-fator3/wp-mcp-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php'];if(in_array($order,['trio-first','meta-integrated'],true))$p=array_merge($trio,$p);if($order==='social-first')$p=array_merge($p,$trio);
foreach($p as $plugin){$r=activate_plugin($plugin);if(is_wp_error($r))throw new RuntimeException($r->get_error_code().':'.$r->get_error_message());}update_option('active_plugins',$p);
echo json_encode(['installed'=>true,'wp'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'plugins'=>$p])."\n";
