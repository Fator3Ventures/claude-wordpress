<?php
/** Shared test helpers for the social native suites (lab only; never shipped). */
if(!function_exists('lab_companion')){
/** Version of an extracted companion plugin (plugin file => version), from the lab environment. */
function lab_companion(string $file): ?string {$c=json_decode((string)getenv('F3_LAB_COMPANIONS'),true);return is_array($c)?($c[$file]??null):null;}
/** Version of the package under test, from build/build.py. */
function lab_version(): string {return (string)getenv('F3_LAB_VERSION');}
/**
 * Runs PHP code in a fresh process that loads this lab's WordPress.
 * $hooks are pre-initialized before WordPress loads (name => [priority, php code body]); the code may echo JSON.
 */
function lab_child(string $code,array $hooks=[]): array {
 $root=getenv('F3_LAB_ROOT');$file=$root.'/child-'.bin2hex(random_bytes(6)).'.php';$pre='';
 foreach($hooks as $i=>[$hook,$priority,$body])$pre.='$GLOBALS["wp_filter"]['.var_export($hook,true).']['.(int)$priority.'][]=["function"=>static function(...$a){'.$body.'},"accepted_args"=>9];';
 file_put_contents($file,'<?php $_SERVER["HTTP_HOST"]="example.com";$_SERVER["SERVER_NAME"]="example.com";$_SERVER["REQUEST_URI"]="/";'.$pre.'require '.var_export($root.'/wordpress/wp-load.php',true).';'.$code);
 $cmd=json_decode((string)getenv('F3_LAB_PHP'),true)?:[PHP_BINARY];$p=proc_open(array_merge($cmd,[$file]),[1=>['pipe','w'],2=>['pipe','w']],$pipes);$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$rc=proc_close($p);@unlink($file);
 return ['rc'=>$rc,'out'=>$out,'err'=>$err,'json'=>(static function($o){$l=preg_split('/\R/',trim($o));return json_decode((string)end($l),true);})($out)];
}
/** Debug log lines of this lab. */
function lab_debug_lines(): array {$f=getenv('F3_LAB_ROOT').'/wordpress/wp-content/debug.log';return is_file($f)?file($f,FILE_IGNORE_NEW_LINES):[];}
/** Runs $fn and returns [result, write statements] issued through $wpdb while it ran. */
function lab_writes(callable $fn): array {$w=[];$spy=static function($sql)use(&$w){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE|ALTER|CREATE|DROP|TRUNCATE)/i',$sql))$w[]=$sql;return $sql;};add_filter('query',$spy);try{$r=$fn();}finally{remove_filter('query',$spy);}return [$r,$w];}
/** Writes other than the one local audit row (records table, bucket audit) and the audit health option. */
function lab_non_audit_writes(array $writes,string $table,string $key): array {return array_values(array_filter($writes,static fn($s)=>!(preg_match('/^\s*INSERT IGNORE INTO `?'.preg_quote($table,'/').'`? \(bucket,record_key/i',$s)&&str_contains($s,"VALUES ('audit',"))&&!str_contains($s,"'".$key."_audit_health'")));}
function lab_audit_inserts(array $writes,string $table): int {return count(array_filter($writes,static fn($s)=>(bool)preg_match('/^\s*INSERT IGNORE INTO `?'.preg_quote($table,'/').'`? \(bucket,record_key/i',$s)&&str_contains($s,"VALUES ('audit',")));}
/** Package SQL (its table or its own options) issued while a fresh request loads WordPress, after two warm-up requests. */
function lab_bootstrap_sql(string $table,string $prefix): array {$needle=var_export([$table,$prefix],true);$probe=[['query',10,'foreach('.$needle.' as $n)if(str_contains((string)$a[0],$n)){$GLOBALS["pkgq"][]=substr((string)$a[0],0,160);break;}return $a[0];']];lab_child('echo json_encode(["ok"=>1]);',$probe);lab_child('echo json_encode(["ok"=>1]);',$probe);$c=lab_child('echo json_encode(["queries"=>$GLOBALS["pkgq"]??[]]);',$probe);return $c['json']['queries']??['child_failed:'.$c['err']];}
}
