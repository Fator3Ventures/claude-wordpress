<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);require __DIR__.'/snapshot080-cases.php';$r=snapshot080_cases();file_put_contents(getenv('F3_LAB_ROOT').'/evidence/snapshot080.json',json_encode($r));echo json_encode($r)."\n";if($r['failed'])exit(1);
