<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
require __DIR__.'/worker-cases.php';
$r=meta060_worker_cases();file_put_contents(getenv('F3_LAB_ROOT').'/evidence/release060.json',wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));echo json_encode($r)."\n";if($r['failed'])exit(1);
