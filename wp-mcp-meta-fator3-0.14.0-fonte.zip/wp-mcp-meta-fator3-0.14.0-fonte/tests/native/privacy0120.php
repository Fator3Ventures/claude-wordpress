<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';require __DIR__.'/seed-connection090.php';
use Fator3\Meta as M;
wp_set_current_user(1);$checks=[];$httpCalls=0;$mail=0;$callbacks=0;$now=time();$secret=str_repeat('c',32);$connection='privacy0120';$account='9120';$page='9220';$sender='777120';$mid='privacy-message-120';$mode='normal';$reentrant=false;
function pcheck($name,$passed){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$passed];if(!$passed)echo 'FAILED '.$name."\n";}
function ptarget($sender,$connection='privacy0120',$account='9120'){return ['connection_id'=>$connection,'account_id'=>$account,'sender_id'=>$sender];}
function pseed($sender,$state='persisted',$connection='privacy0120',$account='9120'){
 $key=hash('sha256',$connection.'|'.$account.'|'.$sender);$r=M\Store::get('message_event',$key);
 M\Store::put('message_event',$key,['event_id'=>$key,'idempotency_key'=>$key,'connection_id'=>$connection,'account_id'=>$account,'sender_id'=>$sender,'message_id'=>'personal-message-'.$sender,'record_id'=>'contact-private-'.$sender,'origin'=>['ref'=>'private-origin-'.$sender],'timestamp'=>time(),'authorization_revision'=>1,'delivery'=>$state],$r['revision']??0,0);return $key;
}
function prequest($target,$key){return $target+['expected_revision'=>M\Messaging::privacyStatus($target)['revision'],'idempotency_key'=>$key];}
function presult($fn){return M\Result::run($fn);}
function pbody(){global $sender,$account,$mid,$now;return wp_json_encode(['object'=>'instagram','entry'=>[['id'=>$account,'messaging'=>[['sender'=>['id'=>$sender],'recipient'=>['id'=>$account],'timestamp'=>($now+1)*1000,'message'=>['mid'=>$mid,'text'=>'NEVER_RETAIN_CHAT_TEXT']]]]]]);}
function preceive(){global $connection,$account,$secret;$raw=pbody();return M\Result::run(static fn()=>M\Messaging::receive($connection,$account,$raw,'sha256='.hash_hmac('sha256',$raw,$secret)));}
$http=static function($pre,$args,$url)use(&$httpCalls,&$mode,&$sender,&$mid,&$now,$page,$account){
 $httpCalls++;$path=rawurldecode(preg_replace('~^/v[0-9.]+/~','',parse_url($url,PHP_URL_PATH)));$body=null;
 if($path===$page)$body=['id'=>$page,'access_token'=>'synthetic-page-token','instagram_business_account'=>['id'=>$account]];
 if($path==='debug_token')$body=['data'=>['is_valid'=>true,'app_id'=>'123456789012345','type'=>'PAGE','profile_id'=>$page,'scopes'=>M\Messaging::SCOPES,'granular_scopes'=>[]]];
 if($path===$page.'/conversations')$body=['data'=>[['id'=>'t:privacy']]];
 if($path==='t:privacy/messages'){
  if($mode==='erase_during_query'){$mode='long';$t=ptarget($sender);M\Messaging::eraseLocalData(prequest($t,'privacy-query-race-120'));}
  $body=['data'=>[['id'=>$mid,'created_time'=>gmdate('c',$now+1),'from'=>['id'=>$sender]]]];
  if($mode==='long')$body['paging']=['next'=>'https://example.invalid/not-followed','cursors'=>['after'=>'next-page']];
 }
 if($body===null)throw new RuntimeException('Unexpected synthetic HTTP path');return ['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>200],'cookies'=>[]];
};
add_filter('pre_http_request',$http,10,3);add_filter('pre_wp_mail',static function()use(&$mail){$mail++;return true;},10);
try{
 $contract=M\Messaging::privacyContract();pcheck('Additive privacy contract leaves ingestion 1.0.0 unchanged',$contract['contract']==='instagram-message-erasure/1.0.0'&&M\Messaging::CONTRACT==='instagram-first-message/1.0.0'&&count(M\Schemas::all())===44);
 $before=get_option('f3_meta_message_privacy_key',false);$none=M\Messaging::privacyStatus(ptarget('700000'));pcheck('Read-only status on absent connection creates no privacy key',$none['state']==='absent'&&get_option('f3_meta_message_privacy_key',false)===$before);
 foreach(['pending','reserved','uncertain','persisted','suppressed','evidence_changed'] as $n=>$state){
  $s='70012'.$n;$event=pseed($s,$state);$target=$n%2?['connection_id'=>$connection,'account_id'=>$account,'event_id'=>$event]:ptarget($s);$request=prequest($target,'privacy-state-'.$state.'-120');$a=M\Messaging::eraseLocalData($request);$b=M\Messaging::eraseLocalData($request);
  pcheck('Erases '.$state.' with stable replay and public receipt',$a===$b&&$a===M\Messaging::erasureReceipt($request['idempotency_key'])&&M\Store::get('message_event',$event)===null&&M\Messaging::privacyStatus($target)['state']==='erased');
 }
 pcheck('Privacy calls did not contact Graph',$httpCalls===0);
 $t=ptarget('700120');$r=prequest($t,'privacy-new-operation-120');$out=M\Messaging::eraseLocalData($r);
 pcheck('Receipt is minimal and explicitly local',array_keys($out)===$contract['receipt_fields']&&!$out['external_copies_erased']&&!isset($out['sender_id'],$out['event_id'],$out['record_id'],$out['connection_id'],$out['account_id']));
 $conflict=presult(static fn()=>M\Messaging::eraseLocalData(prequest(ptarget('700999'),'privacy-new-operation-120')));pcheck('Idempotency key cannot be reused for another target',$conflict['code']==='idempotency_conflict');
 foreach([ptarget('700888')+['event_id'=>str_repeat('a',64)],ptarget('700888')+['event_id'=>null],['connection_id'=>$connection,'account_id'=>$account],ptarget('700888')+['extra'=>true]] as $bad)pcheck('Rejects ambiguous or open target '.count($checks),presult(static fn()=>M\Messaging::privacyStatus($bad))['code']==='invalid_input');
 $e=pseed('700777');$wrong=['connection_id'=>'other','account_id'=>$account,'event_id'=>$e];pcheck('Cross-connection event selector denied',presult(static fn()=>M\Messaging::privacyStatus($wrong))['code']==='not_authorized'&&M\Store::get('message_event',$e)!==null);
 $wrong=['connection_id'=>$connection,'account_id'=>'99999','event_id'=>$e];pcheck('Cross-account event selector denied',presult(static fn()=>M\Messaging::privacyStatus($wrong))['code']==='not_authorized');
 $other=pseed('700777','persisted','other',$account);$otherAccount=pseed('700777','persisted',$connection,'99999');M\Messaging::eraseLocalData(prequest(ptarget('700777'),'privacy-isolation-120'));
 pcheck('Elimination preserves other connection and account',M\Store::get('message_event',$other)!==null&&M\Store::get('message_event',$otherAccount)!==null);
 $e=pseed('700666');$req=prequest(ptarget('700666'),'privacy-stale-revision-120');pseed('700666','uncertain');pcheck('Stale revision cannot erase changed event',presult(static fn()=>M\Messaging::eraseLocalData($req))['code']==='revision_conflict'&&M\Store::get('message_event',$e)!==null);
 global $wpdb;$wpdb->query('START TRANSACTION');$wpdb->query('SAVEPOINT privacy_caller');$tx=presult(static fn()=>M\Messaging::eraseLocalData(prequest(ptarget('700666'),'privacy-transaction-120')));$still=$wpdb->query('RELEASE SAVEPOINT privacy_caller');$wpdb->query('ROLLBACK');pcheck('SDK rejects caller transaction without commit or rollback',$tx['code']==='transaction_active'&&$still!==false&&M\Store::get('message_event',$e)!==null);
 $s='700555';$e=pseed($s);$req=prequest(ptarget($s),'privacy-delete-failure-120');
 $fail=static function($sql)use($e){return str_starts_with($sql,'DELETE FROM')&&str_contains($sql,"bucket='message_event'")&&str_contains($sql,$e)?$sql.' AND 1=0':$sql;};add_filter('query',$fail,99);$failed=presult(static fn()=>M\Messaging::eraseLocalData($req));remove_filter('query',$fail,99);
 pcheck('Partial deletion failure is not success and suppression already durable',!$failed['success']&&M\Messaging::privacyStatus(ptarget($s))['state']==='erasure_incomplete'&&M\MessagePrivacy::blocked($connection,$account,$e));
 pcheck('Partial deletion creates no conclusive receipt',presult(static fn()=>M\Messaging::erasureReceipt($req['idempotency_key']))['code']==='not_found');
 $recovered=M\Messaging::eraseLocalData($req);pcheck('Exact same request resumes partial deletion',$recovered['state']==='erased'&&M\Store::get('message_event',$e)===null);
 $s='700444';$e=pseed($s);$req=prequest(ptarget($s),'privacy-receipt-failure-120');$fail=static fn($sql)=>str_starts_with($sql,'INSERT IGNORE')&&str_contains($sql,"'message_erasure_receipt'")?'SELECT 1':$sql;add_filter('query',$fail,99);$failed=presult(static fn()=>M\Messaging::eraseLocalData($req));remove_filter('query',$fail,99);
 pcheck('Receipt failure preserves erasure and permits exact recovery',!$failed['success']&&M\Store::get('message_event',$e)===null&&M\Messaging::eraseLocalData($req)['state']==='erased');
 // Restore a row out of band to prove a historical receipt cannot falsely confirm current absence.
 pseed($s);$changed=presult(static fn()=>M\Messaging::eraseLocalData($req));pcheck('Out-of-band restored event invalidates replay confirmation',$changed['code']==='erasure_state_changed');M\Messaging::eraseLocalData(prequest(ptarget($s),'privacy-restored-erasure-120'));
 $subscriber=wp_create_user('privacy0120sub',wp_generate_password(),'privacy0120sub@example.invalid');(new WP_User($subscriber))->set_role('subscriber');
 foreach([0,$subscriber] as $uid){wp_set_current_user($uid);foreach(['privacyContract'=>[], 'privacyStatus'=>[ptarget('700120')], 'eraseLocalData'=>[$r], 'erasureReceipt'=>['privacy-new-operation-120']] as $method=>$args)pcheck('Current authorization denies '.$uid.' '.$method,presult(static fn()=>M\Messaging::$method(...$args))['code']==='not_authorized');}wp_set_current_user(1);
 // Real message paths with synthetic Graph and consumer; privacy can operate before or after revocation.
 lab_seed_connection090(['connection_id'=>$connection,'expected_revision'=>0,'token'=>'synthetic-token','client_id'=>'123456789012345','client_secret'=>$secret,'assets'=>['instagram'=>[$account],'facebook'=>[$page]]]);
 M\Messaging::registerConsumer('site-core',M\Messaging::CONTRACT,static function($payload)use(&$callbacks,&$reentrant){$callbacks++;if($reentrant)M\Messaging::eraseLocalData(prequest(['connection_id'=>$payload['connection_id'],'account_id'=>$payload['account_id'],'event_id'=>$payload['event_id']],'privacy-reentrant-120'));return ['persisted'=>true,'record_id'=>'synthetic-core-record','idempotency_key'=>$payload['idempotency_key']];});
 $now=time();$ctx=['connection_id'=>$connection,'account_id'=>$account];M\Http::budget();M\Messaging::save($ctx+['expected_revision'=>0,'enabled'=>true,'contacts_enabled'=>true,'page_id'=>$page,'verify_token'=>'synthetic-verify-privacy-120']);
 pcheck('Signed fixture event received',preceive()['data']['stored']===1);$e=hash('sha256',$connection.'|'.$account.'|'.$sender);
 $cursor=M\Util::cursor(['state'=>['sender_id'=>$sender,'message_id'=>$mid],'expires'=>time()+3600]);wp_schedule_single_event(time()+500,'f3_meta_messages',[$connection,$account,$cursor]);wp_schedule_single_event(time()+501,'f3_meta_messages',[$connection,'999',$cursor]);
 $r=M\Store::get('connection',$connection);$v=$r['value'];$v['enabled']=false;$v['token']='';$v['authorization_revision']++;M\Store::put('connection',$connection,$v,$r['revision']);$beforeHttp=$httpCalls;
 $req=prequest(ptarget($sender),'privacy-revoked-connection-120');$erased=M\Messaging::eraseLocalData($req);pcheck('Erasure works after token revocation without Graph',$erased['state']==='erased'&&$httpCalls===$beforeHttp);
 pcheck('Only affected account continuation removed',!wp_next_scheduled('f3_meta_messages',[$connection,$account,$cursor])&&wp_next_scheduled('f3_meta_messages',[$connection,'999',$cursor]));
 $r=M\Store::get('connection',$connection);$v=$r['value'];$v['enabled']=true;$v['token']='synthetic-token';$v['authorization_revision']--;M\Store::put('connection',$connection,$v,$r['revision']);
 pcheck('Signed replay after erasure is not stored',preceive()['data']['stored']===0&&M\Store::get('message_event',$e)===null);M\Http::budget();$run=M\Messaging::process($ctx);pcheck('Processor does not deliver erased sender',$callbacks===0&&$run['deliveries'][0]['state']==='suppressed');
 pcheck('Legacy reconciliation cannot recreate deleted payload',!presult(static fn()=>M\Messaging::reconcileReceipt($connection,$account,$e,1,['persisted'=>true,'record_id'=>'attempt','idempotency_key'=>$e]))['success']&&M\Store::get('message_event',$e)===null);
 // A deletion during a long HTTP query changes the epoch before tick can schedule its cursor.
 $sender='777121';$mid='privacy-race-message';preceive();$mode='erase_during_query';M\Messaging::tick($connection,$account);$scheduled=false;foreach(_get_cron_array()?:[] as $hooks)foreach($hooks['f3_meta_messages']??[] as $event){$args=$event['args'];if(($args[0]??null)===$connection&&($args[1]??null)===$account&&isset($args[2]))$scheduled=true;}
 pcheck('Worker cannot schedule cursor computed before concurrent erasure',!$scheduled);$mode='normal';
 $sender='777122';$mid='privacy-reentrant-message';preceive();$reentrant=true;M\Http::budget();$race=presult(static fn()=>M\Messaging::process($ctx));$reentrant=false;$key=hash('sha256',$connection.'|'.$account.'|'.$sender);
 pcheck('Reentrant erasure during consumer callback cannot resurrect payload',!$race['success']&&M\Store::get('message_event',$key)===null&&M\Messaging::privacyStatus(ptarget($sender))['state']==='erased');
 // Corrupted encrypted key must never silently become a new key or permit ingest.
 $original=get_option('f3_meta_message_privacy_key');update_option('f3_meta_message_privacy_key','corrupted',true);$blocked=preceive();pcheck('Unreadable privacy key fails closed',$blocked['code']==='privacy_key_unavailable');update_option('f3_meta_message_privacy_key',$original,true);delete_option('f3_meta_message_privacy_key');$missingKey=preceive();pcheck('Missing privacy key with retained blocks fails closed and is not recreated',$missingKey['code']==='privacy_key_unavailable'&&get_option('f3_meta_message_privacy_key',false)===false);add_option('f3_meta_message_privacy_key',$original,'',true);unset($original);
 $missing='removed0120';$event=pseed('700333','persisted',$missing);M\Messaging::eraseLocalData(prequest(ptarget('700333',$missing),'privacy-missing-connection-120'));pcheck('Missing connection does not prevent local erasure',M\Store::get('message_event',$event)===null);
 $protected=[];foreach(['message_suppression','message_erasure_receipt','message_privacy_scope'] as $bucket)foreach(M\Store::scan($bucket,'',100) as $row){$protected[]=$bucket.'|'.$row['key'];$encoded=wp_json_encode($row);pcheck('Protected '.$bucket.' has no raw identity '.count($checks),$row['expires_at']===0&&!str_contains($encoded,'personal-message-')&&!str_contains($encoded,'private-origin-')&&!str_contains($encoded,'contact-private-')&&!str_contains($encoded,'sender_id')&&!str_contains($encoded,'record_id')&&!str_contains($encoded,'connection_id')&&!str_contains($encoded,'message_id'));}
 foreach(M\Store::scan('message_event','',100) as $row)M\Store::remove('message_event',$row['key'],$row['revision']);M\Store::prune();pcheck('Journal cleanup and retention preserve suppression',M\MessagePrivacy::blocked($connection,$account,$e)&&count($protected)>0);
 $sender='777120';$mid='privacy-message-120';file_put_contents(getenv('F3_LAB_ROOT').'/privacy-restart.json',wp_json_encode(['connection'=>$connection,'account'=>$account,'sender'=>$sender,'mid'=>$mid,'timestamp'=>($now+1)*1000,'idempotency_key'=>'privacy-revoked-connection-120']));
 pcheck('No unsolicited mail',$mail===0);
}catch(Throwable $e){pcheck('Unexpected exception',false);echo get_class($e).':'.$e->getMessage()."\n".$e->getTraceAsString()."\n";}
$out=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($c)=>!$c['passed'])),'synthetic_http_calls'=>$httpCalls,'synthetic_callbacks'=>$callbacks,'real_provider_calls'=>0,'real_mail'=>0];file_put_contents(getenv('F3_LAB_ROOT').'/evidence/privacy0120.json',wp_json_encode($out));echo wp_json_encode(['total'=>$out['total'],'failed'=>$out['failed']]);if($out['failed'])exit(1);
