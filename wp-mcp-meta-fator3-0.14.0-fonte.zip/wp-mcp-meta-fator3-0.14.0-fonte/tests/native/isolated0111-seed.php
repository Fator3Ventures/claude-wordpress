<?php
require_once __DIR__.'/seed-connection090.php';
use Fator3\Meta as M;
require __DIR__.'/isolated0111-state.php';
lab_seed_connection090(['connection_id'=>'upgrade071','expected_revision'=>0,'token'=>'synthetic-upgrade-not-a-token','assets'=>['instagram'=>['777071']],'users'=>[1]]);
$q=['connection_id'=>'upgrade071','channel'=>'instagram','account_id'=>'777071','report'=>'profile'];
M\Schedules::save(['schedule_id'=>'upgrade071','label'=>'Upgrade preservation','query'=>$q,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+3600]);
add_filter('pre_http_request',static fn()=>['headers'=>[],'body'=>'{"id":"777071","name":"Synthetic upgrade"}','response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]],1);
$j=M\Jobs::create(['query'=>$q,'idempotency_key'=>'upgrade071']);M\Jobs::run($j['job_id'],true);
M\Store::put('job','upgrade080_paused',['query'=>$q,'principal'=>M\Access::principal(),'connection_revision'=>1,'status'=>'paused','pages'=>2,'rows'=>5,'next_at'=>0,'cursor'=>'synthetic-checkpoint'],0,time()+86400);update_option('f3_meta_operation_notice',['state'=>'accepted','at'=>123,'sentinel'=>'upgrade080'],false);$s=isolated0111_state();file_put_contents(getenv('F3_LAB_ROOT').'/baseline-state.sha256',hash('sha256',serialize($s)));file_put_contents(getenv('F3_LAB_ROOT').'/baseline-state.json',json_encode($s));
echo json_encode(['seeded_version'=>M\Config::VERSION,'record_buckets'=>array_count_values(array_column($s['records'],'bucket')),'history_rows'=>count($s['history']),'options'=>count($s['options'])])."\n";
