const fs=require('fs'),assert=require('assert'),{JSDOM}=require('jsdom');
const [,,input,script,fieldsFile,output]=process.argv;const fixture=JSON.parse(fs.readFileSync(input)),fields=JSON.parse(fs.readFileSync(fieldsFile));
const dom=new JSDOM(fixture.html,{url:'https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3',runScripts:'outside-only'}),w=dom.window,d=w.document;
w.F3Social=fixture.config;let conn=structuredClone(fixture.config.bootstrap.connections[0]);const calls=[],checks=[];let action='mismatch';
w.fetch=async(url,options)=>{const op=url.split('/').pop(),i=JSON.parse(options.body);calls.push({op,i});let data={},success=true,code='ok',message='';
 if(op==='admin-options')data={rows:[{id:1,name:'QA Admin',can_administer:true}],next_offset:null};
 else if(op==='list-connections')data={connections:[conn],next_offset:null};
 else if(op==='save-connection'||op==='rotate-token'){success=false;code=action==='invalid'?'invalid_token_format':'credential_identity_mismatch';message=action==='invalid'?"Isto parece a Chave Secreta do Aplicativo, não um token. Copie o token na janela 'Token criado' do usuário do sistema.":"O token novo é de outra identidade (QA Novo). Para trocar, use 'Trocar identidade e regravar agendas': o token é conferido, a seleção de ativos é mantida e as agendas são regravadas na nova revisão.";}
 else if(op==='switch-identity'){const identity={...(conn.identity||conn.token_identity),subject_id:'902',subject_name:'QA Novo',remote_expires_at:1796000000,extra_scopes:['ads_management']};
  if(i.dry_run)data={persisted:false,identity,schedules:['a','b'],confirmation:'qa-opaque-confirmation',message:'Confira e confirme a identidade.'};
  else{conn={...conn,revision:8,token_identity:identity,identity,expires_at:identity.remote_expires_at};data={connection:conn,schedules_rebased:2,persisted:true};}
 }
 return {ok:true,status:200,json:async()=>({success,code,message,data,version:'0.9.0'})};};
const tick=()=>new Promise(r=>setTimeout(r,20));const check=(n,ok)=>{checks.push({name:n,passed:!!ok});assert(ok,n)};
const clickText=(root,text)=>{const b=[...root.querySelectorAll('button')].find(b=>b.textContent===text);assert(b,'Missing '+text);b.click();};
(async()=>{w.eval(fs.readFileSync(script,'utf8'));await tick();
 for(const [k,[label,help]] of Object.entries(fields)){const node=d.querySelector('#f3-connection [name="'+k+'"]');check('Exact visible help '+k,node.parentElement.firstChild.textContent===label&&node.parentElement.querySelector('.f3-field-help').textContent===help&&!node.closest('[hidden]'));}
 check('Name placeholder',d.querySelector('[name="label"]').placeholder==='usuário do sistema · app');
 check('Saved identity shown above editor',d.querySelector('#f3-connection-list').textContent.includes('Token de: QA Sistema · App: QA App (123456789012345) · Validade: não expira · Permissões:'));
 clickText(d,'Editar conexão');await tick();const cf=d.querySelector('#f3-connection');cf.elements.token.value='a'.repeat(32);action='invalid';cf.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();check('Invalid token reason displayed and candidate retained',d.querySelector('#f3-message').textContent.includes('Isto parece a Chave Secreta')&&cf.elements.token.value==='a'.repeat(32));
 check('Invalid token does not expose identity switch',d.querySelector('#f3-switch-save').hidden);
 action='mismatch';cf.elements.token.value='EAA'+'B'.repeat(110);cf.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();check('Identity mismatch offers explicit switch',!d.querySelector('#f3-switch-save').hidden);
 d.querySelector('#f3-switch-save').click();await tick();const preview=d.querySelector('#f3-identity-preview');check('Preview has identity, app, count and excess scope warning',!preview.hidden&&preview.textContent.includes('QA Novo')&&preview.textContent.includes('2 agendas')&&preview.textContent.includes('ads_management'));
 check('Preview is not a commit',calls.filter(c=>c.op==='switch-identity').every(c=>c.i.dry_run===true));
 clickText(preview,'Confirmar troca de identidade e regravar agendas');await tick();const commit=calls.find(c=>c.op==='switch-identity'&&!c.i.dry_run);check('Commit binds confirmation, same candidate and expected revision',commit?.i.confirmation==='qa-opaque-confirmation'&&commit.i.expected_revision===7&&commit.i.token==='EAA'+'B'.repeat(110));
 check('Successful switch clears candidate secrets and preview',cf.elements.token.value===''&&d.querySelector('#f3-identity-preview').hidden);
 check('Expiry field reflects provider UTC and current revision',cf.elements.expected_revision.value==='8'&&cf.elements.expires.value===new Date(1796000000*1000).toISOString().slice(0,16));
 check('Updated identity and excess permissions visible',d.querySelector('#f3-connection-list').textContent.includes('QA Novo')&&d.querySelector('#f3-connection-list').textContent.includes('ads_management'));
 const rf=d.querySelector('#f3-rotate');rf.elements.token.value='EAA'+'C'.repeat(110);rf.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();check('Rotate mismatch has its own guided button',!d.querySelector('#f3-switch-rotate').hidden);d.querySelector('#f3-switch-rotate').click();await tick();check('Rotate preview preserves its own candidate',calls.filter(c=>c.op==='switch-identity').at(-1).i.token===rf.elements.token.value);
 rf.dispatchEvent(new w.Event('input',{bubbles:true}));check('Changing candidate dismisses confirmation',preview.hidden);
 fs.writeFileSync(output,JSON.stringify({checks,total:checks.length,failed:checks.filter(c=>!c.passed).length,scope:'jsdom interaction; provider and REST simulated'},null,2));console.log(JSON.stringify({total:checks.length,failed:0}));dom.window.close();})().catch(e=>{console.error(e);fs.writeFileSync(output,JSON.stringify({checks,error:e.message},null,2));process.exit(1)});
