<?php
/** Fixed, temporary integration checks; no supplied SQL, paths or PHP. */
use Fator3\Meta as M80;
use Fator3\McpFiles as C80;
function meta_companions080_cases(){
 M80\Access::admin();if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||M80\Config::VERSION!=='0.8.0')return new WP_Error('forbidden');
 $checks=[];$check=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};$u=get_current_user_id();$old=C80\ConnectionContext::transport_identity();$id='qa080_'.bin2hex(random_bytes(10));$keys=[];$http=0;$mail=0;
 $h=static function($pre)use(&$http){$http++;return new WP_Error('qa080_external_blocked');};$m=static function()use(&$mail){$mail++;return true;};add_filter('pre_http_request',$h,1);add_filter('pre_wp_mail',$m,1);
 try{
  C80\Persistence::put('oauth-grants',$id,['grant_id'=>$id,'user_id'=>$u,'client_id'=>'qa080','profile'=>'maintenance','status'=>'active']);C80\ConnectionContext::oauth(['user_id'=>$u,'grant_id'=>$id,'client_id'=>'qa080','profile'=>'maintenance']);C80\ConnectionContext::get();
  foreach(['busy','upstream_error','rate_limited'] as $reason){$r=M80\Result::fail(new M80\Fault($reason,'synthetic'));$check($reason.' unknown effects are not transient',$r['retryable']&&!array_key_exists('applied',$r)&&!C80\ExecutionCoordinator::transient($r));}
  $check('explicit retryable non-applied failure remains transient',C80\ExecutionCoordinator::transient(['success'=>false,'retryable'=>true,'applied'=>false]));
  $n=0;$input=['idempotency_key'=>$id];$key=C80\ConnectionContext::key().':'.$u.':meta/status:'.$id;$keys[]=$key;
  $run=static function()use(&$n){$n++;return M80\Result::fail(new M80\Fault('busy','synthetic busy with unknown effects'));};
  $a=C80\ExecutionCoordinator::once('meta/status',$input,$run,'qa080_first');$b=C80\ExecutionCoordinator::once('meta/status',$input,$run,'qa080_second');
  $check('unknown-effect Meta failure keeps receipt and replays once',$n===1&&!$a['success']&&!$b['success']&&($b['replayed']??false)&&($b['error_code']??'')==='busy');
  $policy=C80\Persistence::get('connections','grant:'.$id);$policy['profile']='read';C80\Persistence::put('connections','grant:'.$id,$policy);
  $health=M80\Api::dispatch('health',[],true);$status=M80\Api::dispatch('status',[],true);$check('read profile allows health and denies status',$health['success']&&!$status['success']&&$status['code']==='not_authorized');
  $policy['profile']='custom';$policy['abilities']=['meta/health'];C80\Persistence::put('connections','grant:'.$id,$policy);$status=M80\Api::dispatch('status',[],true);$check('custom profile without status cannot repair',!$status['success']&&$status['code']==='not_authorized');
  $policy['profile']='maintenance';C80\Persistence::put('connections','grant:'.$id,$policy);$status=M80\Api::dispatch('status',[],true);$check('maintenance profile allows status',$status['success']);
 }finally{foreach($keys as $key)C80\StateStore::delete('idempotency',$key);C80\Persistence::delete('connections','grant:'.$id);C80\Persistence::delete('oauth-grants',$id);C80\ConnectionContext::restore_identity($old,$u);remove_filter('pre_http_request',$h,1);remove_filter('pre_wp_mail',$m,1);}
 $check('original connection identity restored',C80\ConnectionContext::transport_identity()===$old);$check('no provider or email calls',$http===0&&$mail===0);
 $expected=json_decode('__EXPECTED_HASHES__',true);$integrity=[];
 foreach($expected as $slug=>$files){$mismatches=[];foreach($files as $path=>$sha){$file=WP_PLUGIN_DIR.'/'.$slug.'/'.$path;if(!is_file($file)||hash_file('sha256',$file)!==$sha)$mismatches[]=$path;}$integrity[$slug]=['files'=>count($files),'mismatches'=>$mismatches];$check($slug.' matches provided runtime',!$mismatches);}
 $check('isolated lab manifest removed',get_option('f3_meta_qa080_lab')===false);
 return ['version'=>M80\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),'integrity'=>$integrity,'callback_runs'=>$n,'http_calls'=>$http,'mail_calls'=>$mail,'retry_fixture'=>'ExecutionCoordinator::once with real Meta failure envelope and synthetic callback; no provider operation'];
}
add_action('wp_abilities_api_init',static function(){if(!class_exists(M80\Config::class,false))return;wp_register_ability('meta/qa-companions080',['label'=>'Meta: integração temporária 080','description'=>'Casos fixos do contrato MCP e integridade dos acompanhantes, sem fornecedor.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>new stdClass(),'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'meta_companions080_cases','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>M80\Config::VERSION,'mode'=>'write','policy_contract'=>1,'remote_effect'=>'none','local_effect'=>'write']]]);},30);
