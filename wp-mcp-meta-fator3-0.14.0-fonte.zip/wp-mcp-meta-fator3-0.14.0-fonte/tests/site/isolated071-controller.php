<?php
/** Temporary Site-Teste-only isolated release lab. No supplied paths, PHP or SQL. */
function f3lab071_manifest(){return get_option('f3_meta_qa071_lab',[]);}
function f3lab071_valid($m){return isset($m['root'],$m['prefix'],$m['php'])&&preg_match('/^f3qa071_[a-f0-9]{12}_$/D',$m['prefix'])&&$m['root']===sys_get_temp_dir().'/'.$m['prefix']&&in_array($m['php'],['/usr/local/php81/bin/php','/usr/local/php83/bin/php'],true);}
function f3lab071_copy($a,$b){if(is_dir($a)){if(!is_dir($b))mkdir($b,0700,true);foreach(new DirectoryIterator($a) as $p)if(!$p->isDot())f3lab071_copy($p->getPathname(),$b.'/'.$p->getFilename());}elseif(!copy($a,$b))throw new RuntimeException('lab copy failed');}
function f3lab071_rm($p){if(is_link($p)||is_file($p)){if(!unlink($p))throw new RuntimeException('lab unlink failed');}elseif(is_dir($p)){foreach(new DirectoryIterator($p) as $i)if(!$i->isDot())f3lab071_rm($i->getPathname());if(!rmdir($p))throw new RuntimeException('lab rmdir failed');}}
function f3lab071_exec($m,$script){
 if(!f3lab071_valid($m))throw new RuntimeException('invalid lab manifest');
 $env=['PATH'=>'/usr/bin:/bin','F3_LAB_ROOT'=>$m['root'],'F3_LAB_PHP'=>json_encode([$m['php']]),'F3_LAB_VERSION'=>'0.7.1','F3_LAB_ORIGIN'=>'clean'];
 $p=proc_open([$m['php'],'-d','display_errors=stderr','-d','memory_limit=256M',$m['root'].'/'.$script],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,$m['root'],$env);
 if(!is_resource($p))throw new RuntimeException('CLI unavailable');fclose($pipes[0]);stream_set_blocking($pipes[1],false);stream_set_blocking($pipes[2],false);$out='';$err='';$start=microtime(true);$rc=null;
 do{$out.=stream_get_contents($pipes[1]);$err.=stream_get_contents($pipes[2]);$s=proc_get_status($p);if(!$s['running']){$rc=$s['exitcode'];break;}if(microtime(true)-$start>50){proc_terminate($p);$err.='lab timeout';$rc=124;break;}usleep(20000);}while(true);
 $out.=stream_get_contents($pipes[1]);$err.=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$closed=proc_close($p);if($rc===null||$rc<0)$rc=$closed;
 foreach([DB_PASSWORD,DB_USER,DB_HOST,DB_NAME,$m['root']] as $secret)if(is_string($secret)&&$secret!==''){$out=str_replace($secret,'[redacted]',$out);$err=str_replace($secret,'[redacted]',$err);}
 return ['exit_code'=>$rc,'stdout'=>substr($out,-150000),'stderr'=>substr($err,-15000),'seconds'=>round(microtime(true)-$start,3)];
}
function f3lab071_run($args){
 if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com')return new WP_Error('forbidden');
 $op=$args['operation'];$m=f3lab071_manifest();
 if($op==='setup'){
  if($m)return new WP_Error('lab_exists','Clean previous lab first');$flavor=$args['flavor']??'current';$prefix='f3qa071_'.bin2hex(random_bytes(6)).'_';$root=sys_get_temp_dir().'/'.$prefix;$m=['root'=>$root,'prefix'=>$prefix,'php'=>$flavor==='minimum'?'/usr/local/php81/bin/php':'/usr/local/php83/bin/php','flavor'=>$flavor];
  if(!mkdir($root,0700)||!add_option('f3_meta_qa071_lab',$m,'',false))throw new RuntimeException('lab setup failed');mkdir($root.'/evidence',0700);mkdir($root.'/wordpress',0700);
  if($flavor==='minimum'){
   $zip=$root.'/wp.zip';$resp=wp_remote_get('https://wordpress.org/wordpress-6.4.zip',['timeout'=>40,'stream'=>true,'filename'=>$zip]);
   if(is_wp_error($resp)||wp_remote_retrieve_response_code($resp)!==200||hash_file('sha256',$zip)!=='91b2ea1843541e58baca15fa0545f098c8cc5496572e1fa08c0b5f2a630a59ed')throw new RuntimeException('official WP 6.4 download/hash failed');
   $z=new ZipArchive();if($z->open($zip)!==true)throw new RuntimeException('WP archive failed');$z->extractTo($root);$z->close();unlink($zip);
  }else{foreach(['wp-admin','wp-includes'] as $d)if(!symlink(ABSPATH.$d,$root.'/wordpress/'.$d))throw new RuntimeException('lab code link failed');foreach(glob(ABSPATH.'*.php') as $p)if(basename($p)!=='wp-config.php')copy($p,$root.'/wordpress/'.basename($p));}
  $content=$root.'/wordpress/wp-content';if(!is_dir($content))mkdir($content,0700);if(!is_dir($content.'/plugins'))mkdir($content.'/plugins',0700);if(!is_dir($content.'/mu-plugins'))mkdir($content.'/mu-plugins',0700);
  file_put_contents($content.'/mu-plugins/no-external.php','<?php add_filter("pre_http_request",static fn($pre)=>$pre!==false?$pre:new WP_Error("lab_external_blocked"),PHP_INT_MAX);add_filter("pre_wp_mail",static fn()=>true,PHP_INT_MAX);');
  $config='<?php ';foreach(['DB_NAME','DB_USER','DB_PASSWORD','DB_HOST','DB_CHARSET','DB_COLLATE'] as $k)$config.='define('.var_export($k,true).','.var_export(defined($k)?constant($k):'',true).');';
  foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $k)$config.='define('.var_export($k,true).','.var_export(bin2hex(random_bytes(48)),true).');';
  $config.='$table_prefix='.var_export($prefix,true).';define("DISABLE_WP_CRON",true);define("WP_HOME","https://example.invalid");define("WP_SITEURL","https://example.invalid");define("WP_DEBUG",true);define("WP_DEBUG_DISPLAY",false);define("WP_DEBUG_LOG",true);define("WP_HTTP_BLOCK_EXTERNAL",true);define("ABSPATH",__DIR__."/");require ABSPATH."wp-settings.php";';file_put_contents($root.'/wordpress/wp-config.php',$config);chmod($root.'/wordpress/wp-config.php',0600);unset($config);
  $bundle=json_decode(gzdecode(base64_decode('__LAB_BUNDLE__')),true,512,JSON_THROW_ON_ERROR);foreach($bundle as $name=>$bytes){if(str_contains($name,'..')||str_starts_with($name,'/'))throw new RuntimeException('bundle path');$file=$root.'/'.$name;if(!is_dir(dirname($file)))mkdir(dirname($file),0700,true);file_put_contents($file,base64_decode($bytes,true));}
  $plugin=$content.'/plugins/wp-mcp-meta-fator3';f3lab071_copy($flavor==='upgrade'?$root.'/baseline/wp-mcp-meta-fator3':WP_PLUGIN_DIR.'/wp-mcp-meta-fator3',$plugin);
  return ['flavor'=>$flavor,'install'=>f3lab071_exec($m,'tests/native/isolated071-install.php')];
 }
 if(!f3lab071_valid($m))return new WP_Error('lab_missing');
 if($op==='suite'){$name=$args['suite']??'review071';$allowed=['release060','release070','release070-metadata','review071','isolated071-upgrade','isolated071-smoke'];if(!in_array($name,$allowed,true))return new WP_Error('suite_invalid');$r=f3lab071_exec($m,'tests/native/'.$name.'.php');$e=$m['root'].'/evidence/'.$name.'.json';return ['flavor'=>$m['flavor'],'run'=>$r,'evidence'=>is_file($e)?json_decode(file_get_contents($e),true):null];}
 if($op==='upgrade'){if($m['flavor']!=='upgrade')return new WP_Error('not_upgrade_lab');$dest=$m['root'].'/wordpress/wp-content/plugins/wp-mcp-meta-fator3';f3lab071_rm($dest);f3lab071_copy(WP_PLUGIN_DIR.'/wp-mcp-meta-fator3',$dest);return f3lab071_exec($m,'tests/native/isolated071-upgrade.php');}
 if($op==='cleanup'){global $wpdb;$tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($m['prefix']).'%'));foreach($tables as $t){if(!str_starts_with($t,$m['prefix'])||!preg_match('/^[a-zA-Z0-9_]+$/D',$t))throw new RuntimeException('unsafe lab table');if($wpdb->query('DROP TABLE `'.$t.'`')===false)throw new RuntimeException('lab drop failed');}$remaining=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($m['prefix']).'%'));f3lab071_rm($m['root']);delete_option('f3_meta_qa071_lab');return ['tables_dropped'=>count($tables),'remaining_tables'=>count($remaining),'directory_removed'=>!file_exists($m['root']),'manifest_removed'=>!get_option('f3_meta_qa071_lab')];}
 return new WP_Error('operation_invalid');
}
add_action('wp_abilities_api_init',static function(){if(!class_exists('Fator3\\Meta\\Config',false))return;wp_register_ability('meta/qa-lab071',['label'=>'Meta: laboratório isolado temporário','description'=>'Testa instalação limpa e atualização com tabelas e diretório exclusivos; sem fornecedores.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>['operation'=>['type'=>'string','enum'=>['setup','suite','upgrade','cleanup']],'flavor'=>['type'=>'string','enum'=>['current','minimum','upgrade']],'suite'=>['type'=>'string','enum'=>['release060','release070','release070-metadata','review071','isolated071-upgrade','isolated071-smoke']]],'required'=>['operation'],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'f3lab071_run','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>true,'idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>'0.7.1','mode'=>'write','policy_contract'=>1,'remote_effect'=>'none','local_effect'=>'write']]]);},30);
