<?php
/** Temporary, fixed QA; no arbitrary code or parameters. Only the explicitly authorized Site-Teste. */
use Fator3\Meta as M;
function lab_writes(callable $fn): array {$w=[];$spy=static function($sql)use(&$w){if(preg_match('/^\s*(INSERT|UPDATE|DELETE|REPLACE|ALTER|CREATE|DROP|TRUNCATE)/i',$sql))$w[]=$sql;return $sql;};add_filter('query',$spy);try{$r=$fn();}finally{remove_filter('query',$spy);}return [$r,$w];}
/** Writes other than the one local audit row (records table, bucket audit) and the audit health option. */
function lab_non_audit_writes(array $writes,string $table,string $key): array {return array_values(array_filter($writes,static fn($s)=>!(preg_match('/^\s*INSERT IGNORE INTO `?'.preg_quote($table,'/').'`? \(bucket,record_key/i',$s)&&str_contains($s,"VALUES ('audit',"))&&!str_contains($s,"'".$key."_audit_health'")));}

function meta_review071_probe(){
 $GLOBALS['meta_review_phase']='guard';M\Access::admin();global $wpdb;
 if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||!in_array(M\Config::VERSION,['0.7.0','0.7.1'],true))return ['guard'=>'environment','host'=>parse_url(home_url('/'),PHP_URL_HOST),'version'=>M\Config::VERSION];
 $t=M\Store::table();if((int)$wpdb->get_var("SELECT COUNT(*) FROM $t WHERE bucket NOT IN ('audit','migration')")>0)return ['guard'=>'data','buckets'=>$wpdb->get_results("SELECT bucket,COUNT(*) AS total FROM $t GROUP BY bucket",ARRAY_A)];
 $beforeOptions=$wpdb->get_results("SELECT option_name,option_value,autoload FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%'",ARRAY_A);
 $beforeHistory=$wpdb->get_col('SELECT row_key FROM '.M\History::table());$beforeCron=wp_get_scheduled_event('f3_meta_worker');
 $GLOBALS['meta_review_phase']='identity';$user=get_current_user_id();$identity=\Fator3\McpFiles\ConnectionContext::resume('integration:user:'.$user,$user);
 try{
global $wpdb;$t=M\Store::table();$checks=[];$calls=0;$mail=0;
$verify=static function($name,$ok,$details=[])use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok,'details'=>$details];};
add_filter('pre_http_request',function($pre,$args,$url)use(&$calls){$calls++;return ['headers'=>[],'body'=>wp_json_encode(['id'=>'888071','name'=>'QA review','username'=>'qa071','followers_count'=>2]),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];},1,3);
add_filter('pre_wp_mail',function($pre,$atts)use(&$mail){$mail++;return true;},1,2);
$GLOBALS['meta_review_phase']='connection';M\Connections::save(['connection_id'=>'review071','expected_revision'=>0,'token'=>'synthetic-review-token','assets'=>['instagram'=>['888071']],'users'=>[get_current_user_id()]]);
$query=['connection_id'=>'review071','channel'=>'instagram','account_id'=>'888071','report'=>'profile'];
M\Schedules::save(['schedule_id'=>'review071','label'=>'QA unreadable latest job','query'=>$query,'expected_revision'=>0,'enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+3600]);
$bad='000071_corrupt';$payload='s1.'.base64_encode(random_bytes(80));
$wpdb->insert($t,['bucket'=>'job','record_key'=>$bad,'revision'=>7,'payload'=>$payload,'updated_at'=>time()-5,'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
$s=M\Store::get('schedule','review071');$v=$s['value'];$v['last_job']=$bad;M\Store::put('schedule','review071',$v,$s['revision']);
$GLOBALS['meta_review_phase']='migration';M\Queue::migrate();wp_clear_scheduled_hook('f3_meta_worker');
[$h,$writes]=lab_writes(static fn()=>M\Api::dispatch('health'));
$verify('R1 health survives a quarantined last_job and names the affected schedule',$h['success']&&$h['data']['state']==='degraded'&&in_array('review071',array_column($h['data']['issues'],'schedule_id'),true),['code'=>$h['code']]);
$verify('R1 health does not repair or send provider/mail effects',lab_non_audit_writes($writes,$t,'f3_meta')===[]&&wp_next_scheduled('f3_meta_worker')===false&&$calls===0&&$mail===0);
$status=M\Api::dispatch('status');
$verify('R1 status still recovers missing worker despite unreadable last_job',$status['success']&&$status['data']['recovery']['attempted']&&wp_next_scheduled('f3_meta_worker')!==false,['code'=>$status['code']]);
M\Store::remove('schedule','review071',M\Store::get('schedule','review071')['revision']);$wpdb->delete($t,['bucket'=>'job','record_key'=>$bad]);wp_clear_scheduled_hook('f3_meta_worker');

$GLOBALS['meta_review_phase']='starvation';
// Twenty already-projected queued jobs with corrupt ciphertext precede a valid job indefinitely in 0.7.0.
for($i=0;$i<20;$i++)$wpdb->insert($t,['bucket'=>'job','record_key'=>'000071_starve_'.str_pad((string)$i,2,'0',STR_PAD_LEFT),'revision'=>7,'payload'=>$payload,'updated_at'=>123,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
$GLOBALS['meta_review_phase']='valid-job';$valid=M\Jobs::create(['query'=>$query,'idempotency_key'=>'review071_valid']);
$GLOBALS['meta_review_phase']='worker';M\Jobs::tick();M\Jobs::tick();$r=M\Store::get('job',$valid['job_id']);
$marked=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE bucket='job' AND record_key LIKE %s AND queue_state='unreadable'",$t,'000071_starve_%'));
$verify('R2 corrupt due jobs leave runnable selection; valid job completes by next pass',$marked===20&&$r['value']['status']==='complete',['quarantined'=>$marked,'valid_status'=>$r['value']['status']]);
$saved=$wpdb->get_row($wpdb->prepare("SELECT payload,revision,updated_at,expires_at FROM %i WHERE bucket='job' AND record_key=%s",$t,'000071_starve_00'),ARRAY_A);
$verify('R2 quarantine preserves ciphertext revision timestamp and retention',$saved['payload']===$payload&&(int)$saved['revision']===7&&(int)$saved['updated_at']===123&&(int)$saved['expires_at']===0);
$wpdb->query($wpdb->prepare("DELETE FROM %i WHERE bucket='job' AND record_key LIKE %s",$t,'000071_starve_%'));

// Independent failure/concurrency cases for the isolation guard added in 0.7.1.
if(method_exists(M\Queue::class,'isolate')){
 $guardKey='000071_guard';
 $wpdb->insert($t,['bucket'=>'job','record_key'=>$guardKey,'revision'=>7,'payload'=>$payload,'updated_at'=>123,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
 $denyRead=static function($sql)use($guardKey){if(str_starts_with($sql,'SELECT revision,payload')&&str_contains($sql,$guardKey))throw new M\Fault('storage_unavailable','synthetic read outage');return $sql;};
 add_filter('query',$denyRead);$caught=null;try{M\Queue::isolate($guardKey);}catch(M\Fault $e){$caught=$e->reason;}finally{remove_filter('query',$denyRead);}
 $raw=$wpdb->get_row($wpdb->prepare("SELECT queue_state,revision,payload FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey),ARRAY_A);
 $verify('R3 transient storage error never quarantines a record',$caught==='storage_unavailable'&&$raw['queue_state']==='queued'&&(int)$raw['revision']===7&&$raw['payload']===$payload);
 $fresh=$r['value'];$fresh['status']='queued';$fresh['next_at']=time()+600;
 $raceDone=false;$race=static function($sql)use(&$raceDone,$guardKey,$fresh){if(!$raceDone&&str_starts_with($sql,'UPDATE ')&&str_contains($sql,$guardKey)&&str_contains($sql,"'unreadable'")){$raceDone=true;M\Store::put('job',$guardKey,$fresh,7);}return $sql;};
 add_filter('query',$race);try{$isolated=M\Queue::isolate($guardKey);}finally{remove_filter('query',$race);}
 $raw=$wpdb->get_row($wpdb->prepare("SELECT queue_state,revision,payload FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey),ARRAY_A);
 $verify('R4 CAS cannot overwrite the projection of a newer readable revision',$raceDone&&!$isolated&&$raw['queue_state']==='queued'&&(int)$raw['revision']===8&&M\Store::get('job',$guardKey)['value']===$fresh);
 $verify('R4 a readable job is never isolated',M\Queue::isolate($guardKey)===false);
 $wpdb->delete($t,['bucket'=>'job','record_key'=>$guardKey]);
 $wpdb->insert($t,['bucket'=>'job','record_key'=>$guardKey,'revision'=>7,'payload'=>$payload,'updated_at'=>123,'expires_at'=>0,'queue_state'=>'queued','queue_next'=>1]);
 [$host,$port,$sock]=$wpdb->parse_db_host(DB_HOST);$other=new mysqli($host,DB_USER,DB_PASSWORD,DB_NAME,$port??3306,$sock);
 $lock='f3s:'.substr(hash('sha256',DB_NAME.'|'.$t.'|job:'.$guardKey),0,55);$other->query("SELECT GET_LOCK('".$other->real_escape_string($lock)."',0)");
 $busy=null;try{M\Queue::isolate($guardKey);}catch(M\Fault $e){$busy=$e->reason;}finally{$other->query("SELECT RELEASE_LOCK('".$other->real_escape_string($lock)."')");$other->close();}
 $verify('R5 isolation respects the real job lock held by another DB connection',$busy==='busy'&&$wpdb->get_var($wpdb->prepare("SELECT queue_state FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey))==='queued');
 $verify('R5 isolation succeeds after the competing lock is released',M\Queue::isolate($guardKey));
 $wpdb->delete($t,['bucket'=>'job','record_key'=>$guardKey]);
 $brokenJson=M\Crypto::seal('{invalid-json');$wpdb->insert($t,['bucket'=>'job','record_key'=>$guardKey,'revision'=>4,'payload'=>$brokenJson,'updated_at'=>456,'expires_at'=>0,'queue_state'=>'','queue_next'=>0]);
 $migration=M\Queue::migrate();$raw=$wpdb->get_row($wpdb->prepare("SELECT queue_state,revision,payload,updated_at FROM %i WHERE bucket='job' AND record_key=%s",$t,$guardKey),ARRAY_A);
 $verify('R6 malformed decrypted JSON is isolated without changing business bytes',$migration['unreadable']===1&&$raw['queue_state']==='unreadable'&&(int)$raw['revision']===4&&$raw['payload']===$brokenJson&&(int)$raw['updated_at']===456);
 $wpdb->delete($t,['bucket'=>'job','record_key'=>$guardKey]);
}

$result=['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'http_fixture_calls'=>$calls,'mail_intercepted'=>$mail];
return $result;

 }finally{
  $GLOBALS['meta_review_previous_phase']=$GLOBALS['meta_review_phase'];$GLOBALS['meta_review_phase']='cleanup';
  foreach($wpdb->get_results('SELECT bucket,record_key,revision FROM '.M\Store::table(),ARRAY_A) as $r){$id=$r['record_key'];if($r['bucket']==='audit')continue;if($id==='review071'||str_starts_with($id,'000071_')||(!empty($valid['job_id'])&&str_starts_with($id,$valid['job_id'])))M\Store::remove($r['bucket'],$id,(int)$r['revision']);}
  foreach($wpdb->get_col('SELECT row_key FROM '.M\History::table()) as $id)if(!in_array($id,$beforeHistory,true))$wpdb->delete(M\History::table(),['row_key'=>$id]);
  $options=[];foreach($beforeOptions as $r)$options[$r['option_name']]=$r;
  foreach($wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%'") as $key){if($key==='f3_meta_audit_health')continue;if(isset($options[$key]))update_option($key,maybe_unserialize($options[$key]['option_value']),in_array($options[$key]['autoload'],['yes','on','auto','auto-on'],true));else delete_option($key);}
  wp_clear_scheduled_hook('f3_meta_worker');if($beforeCron)wp_schedule_single_event($beforeCron->timestamp,'f3_meta_worker',$beforeCron->args);
  \Fator3\McpFiles\ConnectionContext::restore_identity($identity,$user);
 }
}
// Covers concurrent cron requests while the temporary QA exists; no provider or real mail effects.
add_filter('pre_http_request',static function($pre,$args,$url){if(preg_match('~^https://graph[.]facebook[.]com/v[0-9.]+/888071(?:[/?]|$)~',$url))return ['headers'=>[],'body'=>wp_json_encode(['id'=>'888071','name'=>'QA synthetic','username'=>'qa071','followers_count'=>2]),'response'=>['code'=>200,'message'=>'fixture'],'cookies'=>[]];return $pre;},1,3);
add_filter('pre_wp_mail',static fn($pre,$atts)=>($atts['subject']??'')==='Fator3 MCP Meta: atenção às coletas'?true:$pre,1,2);
add_action('wp_abilities_api_init',static function(){if(!class_exists(M\Config::class,false))return;wp_register_ability('meta/qa-review071',['label'=>'Meta: revisão sintética temporária','description'=>'Casos fixos de registros ilegíveis, sem fornecedor, com limpeza de dados próprios.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>new stdClass(),'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>static function(){try{return meta_review071_probe();}catch(Throwable $e){return ['qa_error'=>$e instanceof M\Fault?$e->reason:get_class($e),'phase'=>$GLOBALS['meta_review_phase']??null,'previous_phase'=>$GLOBALS['meta_review_previous_phase']??null];}},'meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>M\Config::VERSION,'mode'=>'write','policy_contract'=>1,'remote_effect'=>'none','local_effect'=>'write']]]);},30);
