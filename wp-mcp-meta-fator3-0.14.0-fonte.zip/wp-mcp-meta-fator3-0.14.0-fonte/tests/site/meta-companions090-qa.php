<?php
/** Fixed, temporary integration checks; no supplied SQL, paths or PHP. */
use Fator3\Meta as M90;
use Fator3\McpFiles as C90;
function meta_companions090_cases(){
 M90\Access::admin();if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||M90\Config::VERSION!=='0.9.0')return new WP_Error('forbidden');
 $checks=[];$check=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};$u=get_current_user_id();$old=C90\ConnectionContext::transport_identity();$id='qa090_'.bin2hex(random_bytes(10));$keys=[];$http=0;$mail=0;
 $h=static function($pre)use(&$http){$http++;return new WP_Error('qa090_external_blocked');};$m=static function()use(&$mail){$mail++;return true;};add_filter('pre_http_request',$h,1);add_filter('pre_wp_mail',$m,1);
 try{
  C90\Persistence::put('oauth-grants',$id,['grant_id'=>$id,'user_id'=>$u,'client_id'=>'qa090','profile'=>'maintenance','status'=>'active']);C90\ConnectionContext::oauth(['user_id'=>$u,'grant_id'=>$id,'client_id'=>'qa090','profile'=>'maintenance']);C90\ConnectionContext::get();
  foreach(['busy','upstream_error','rate_limited'] as $reason){$r=M90\Result::fail(new M90\Fault($reason,'synthetic'));$check($reason.' unknown effects are not transient',$r['retryable']&&!array_key_exists('applied',$r)&&!C90\ExecutionCoordinator::transient($r));}
  $check('explicit retryable non-applied failure remains transient',C90\ExecutionCoordinator::transient(['success'=>false,'retryable'=>true,'applied'=>false]));
  $n=0;$input=['idempotency_key'=>$id];$key=C90\ConnectionContext::key().':'.$u.':meta/status:'.$id;$keys[]=$key;
  $run=static function()use(&$n){$n++;return M90\Result::fail(new M90\Fault('busy','synthetic busy with unknown effects'));};
  $a=C90\ExecutionCoordinator::once('meta/status',$input,$run,'qa090_first');$b=C90\ExecutionCoordinator::once('meta/status',$input,$run,'qa090_second');
  $check('unknown-effect Meta failure keeps receipt and replays once',$n===1&&!$a['success']&&!$b['success']&&($b['replayed']??false)&&($b['error_code']??'')==='busy');
  $policy=C90\Persistence::get('connections','grant:'.$id);$policy['profile']='read';C90\Persistence::put('connections','grant:'.$id,$policy);
  $health=M90\Api::dispatch('health',[],true);$status=M90\Api::dispatch('status',[],true);$check('read profile allows health and denies status',$health['success']&&!$status['success']&&$status['code']==='not_authorized');
  $policy['profile']='custom';$policy['abilities']=['meta/health'];C90\Persistence::put('connections','grant:'.$id,$policy);$status=M90\Api::dispatch('status',[],true);$check('custom profile without status cannot repair',!$status['success']&&$status['code']==='not_authorized');
  $policy['profile']='maintenance';C90\Persistence::put('connections','grant:'.$id,$policy);$status=M90\Api::dispatch('status',[],true);$check('maintenance profile allows status',$status['success']);
 }finally{foreach($keys as $key)C90\StateStore::delete('idempotency',$key);C90\Persistence::delete('connections','grant:'.$id);C90\Persistence::delete('oauth-grants',$id);C90\ConnectionContext::restore_identity($old,$u);remove_filter('pre_http_request',$h,1);remove_filter('pre_wp_mail',$m,1);}
 $check('original connection identity restored',C90\ConnectionContext::transport_identity()===$old);$check('no provider or email calls',$http===0&&$mail===0);
 $public=M90\Connections::public(['token'=>'synthetic-secret','client_secret'=>'synthetic-app-secret','token_identity'=>['subject_id'=>'901','subject_name'=>'QA Sistema','app_verified'=>true,'application_id'=>'123456789012345','application_name'=>'QA App','scopes'=>['read_insights'],'remote_expires_at'=>0]]);
 $safe=C90\SafeOutput::value($public);$check('public identity survives real MCP secret filter',($safe['identity']['subject_name']??null)==='QA Sistema'&&!isset($safe['token'],$safe['client_secret'])&&($safe['token_identity']??null)==='[redigido]');
 $preview=C90\SafeOutput::value(['confirmation'=>'synthetic-confirmation','identity'=>$public['identity']]);$check('identity switch preview and confirmation survive real MCP filter',$preview['confirmation']==='synthetic-confirmation'&&$preview['identity']['application_name']==='QA App');
 $check('new operation is discovered and declares read provider/write local',$a=wp_get_ability('meta/switch-identity')&&M90\Api::writes('switch-identity'));
 $li=wp_get_ability('linkedin/capabilities');$liResult=$li?$li->execute([]):null;$liVersion=is_array($liResult)?($liResult['version']??null):null;$check('current LinkedIn independently callable with matching loaded version',is_array($liResult)&&!empty($liResult['success'])&&$liVersion===\Fator3\LinkedIn\Config::VERSION);
 $expected=json_decode('__EXPECTED_HASHES__',true);$integrity=[];
 foreach($expected as $slug=>$files){$mismatches=[];foreach($files as $path=>$sha){$file=WP_PLUGIN_DIR.'/'.$slug.'/'.$path;if(!is_file($file)||hash_file('sha256',$file)!==$sha)$mismatches[]=$path;}$integrity[$slug]=['files'=>count($files),'mismatches'=>$mismatches];$check($slug.' matches provided runtime',!$mismatches);}
 $check('isolated lab manifest removed',get_option('f3_meta_qa090_lab')===false);
 return ['version'=>M90\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),'integrity'=>$integrity,'linkedin_observed_version'=>$liVersion,'callback_runs'=>$n,'http_calls'=>$http,'mail_calls'=>$mail,'retry_fixture'=>'ExecutionCoordinator::once with real Meta failure envelope and synthetic callback; no provider operation'];
}
add_action('wp_abilities_api_init',static function(){if(!class_exists(M90\Config::class,false))return;wp_register_ability('meta/qa-companions090',['label'=>'Meta: integração temporária 090','description'=>'Casos fixos do contrato MCP e integridade dos acompanhantes, sem fornecedor.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>new stdClass(),'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'meta_companions090_cases','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>M90\Config::VERSION,'mode'=>'write','policy_contract'=>1,'remote_effect'=>'none','local_effect'=>'write']]]);},30);
