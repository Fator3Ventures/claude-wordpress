<?php
use Fator3\Meta as M90Q;
function meta_credentials090_qa(){
 M90Q\Access::admin();if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||M90Q\Config::VERSION!=='0.9.0')return new WP_Error('forbidden');
 if(M90Q\Store::list('connection',0,1)||M90Q\Store::list('schedule',0,1)||M90Q\Queue::waiting())return new WP_Error('qa_requires_empty_meta');
 $id='qa090-live-'.bin2hex(random_bytes(8));$checks=[];$mode='valid';$calls=0;$a='EAA'.str_repeat('A',110);$b='EAA'.str_repeat('B',110);$secret=str_repeat('a',32);$app='123456789012345';$cron=wp_get_scheduled_event('f3_meta_worker');$options=[];
 foreach(['f3_meta_worker_schedule_attempt','f3_meta_worker_schedule_failure'] as $key)$options[$key]=get_option($key,null);
 $check=static function($n,$ok)use(&$checks){$checks[]=['name'=>$n,'passed'=>(bool)$ok];};
 $call=static fn($op,$i)=>M90Q\Api::dispatch($op,$i,true);
 $http=static function($pre,$args,$url)use(&$mode,&$calls,$a,$b,$app){$calls++;parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);$path=basename(parse_url($url,PHP_URL_PATH));$token=$q['input_token']??substr($args['headers']['Authorization'],7);$subject=$token===$b?'902':'901';
 if($path==='debug_token'){
  if($mode==='190')return ['headers'=>[],'response'=>['code'=>401],'body'=>'{"error":{"code":190}}','cookies'=>[]];
  $body=['data'=>['is_valid'=>true,'app_id'=>$app,'application'=>'QA App','user_id'=>$subject,'expires_at'=>0,'scopes'=>M90Q\Credentials::READ_SCOPES]];
 }elseif($path==='me')$body=['id'=>$subject,'name'=>$subject==='902'?'QA Novo':'QA Original'];
 elseif($path==='910')$body=['id'=>'910','username'=>'qa090'];else return new WP_Error('qa_unexpected_http');
 return ['headers'=>[],'response'=>['code'=>200],'body'=>wp_json_encode($body),'cookies'=>[]];};
 add_filter('pre_http_request',$http,1,3);add_filter('pre_wp_mail','__return_true',1);
 try{
  $r=$call('save-connection',['connection_id'=>$id,'expected_revision'=>0,'client_id'=>$app,'client_secret'=>$secret,'token'=>$a,'assets'=>['instagram'=>['910']]]);$check('validated candidate saves through actual MCP policy',$r['success']);if(!$r['success'])return ['checks'=>$checks,'error'=>$r['code']];
  $c=M90Q\Connections::get($id);for($n=1;$n<=2;$n++){M90Q\Schedules::save(['schedule_id'=>$id.'-'.$n,'query'=>['connection_id'=>$id,'channel'=>'instagram','account_id'=>'910','report'=>'profile'],'expected_revision'=>0,'enabled'=>$n===1,'interval_minutes'=>60,'next_at'=>time()+86400]);}
  $snapshot=M90Q\Store::get('connection',$id);$count=$calls;$r=$call('save-connection',['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$secret]);$check('App Secret exact refusal and token preserved',$r['code']==='invalid_token_format'&&$r['message']==="Isto parece a Chave Secreta do Aplicativo, não um token. Copie o token na janela 'Token criado' do usuário do sistema."&&M90Q\Store::get('connection',$id)===$snapshot&&$count===$calls);
  $mode='190';$r=$call('save-connection',['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$b]);$check('190 preserves saved credential and revision',$r['code']==='token_rejected'&&M90Q\Store::get('connection',$id)===$snapshot);$mode='valid';
  $r=$call('save-connection',['connection_id'=>$id,'expected_revision'=>$c['revision'],'label'=>'QA Novo rótulo']);$c=M90Q\Connections::get($id);$check('label change rebases both agendas',$r['success']&&$r['data']['schedules_rebased']===2);
  $r=$call('rotate-token',['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$b]);$check('different identity cannot rotate silently',$r['code']==='credential_identity_mismatch');
  $args=['connection_id'=>$id,'expected_revision'=>$c['revision'],'token'=>$b,'dry_run'=>true];$before=M90Q\Store::get('connection',$id);$preview=$call('switch-identity',$args);$check('simulation preserves connection and lists both agendas',$preview['success']&&M90Q\Store::get('connection',$id)===$before&&count($preview['data']['schedules'])===2);
  if(!$preview['success'])throw new RuntimeException('Preview failed');
  $r=$call('switch-identity',array_replace($args,['dry_run'=>false,'confirmation'=>$preview['data']['confirmation']]));$c=M90Q\Connections::get($id);$check('confirmed switch persists validated identity and both agenda revisions',$r['success']&&$c['token_identity']['subject_id']==='902'&&$r['data']['schedules_rebased']===2);
  foreach([1,2] as $n){$s=M90Q\Store::get('schedule',$id.'-'.$n)['value'];$test=M90Q\Result::run(static function()use($s,$c){M90Q\Connections::checkPlan($s,$c);return [];});$check('agenda '.$n.' has current revision and preserved enabled state',$s['connection_revision']===$c['revision']&&$s['enabled']===($n===1)&&$test['success']);}
  $safe=\Fator3\McpFiles\SafeOutput::value($call('get-connection',['connection_id'=>$id]));$check('real transport redactor exposes names and validity but no secret',($safe['data']['connection']['identity']['subject_name']??null)==='QA Novo'&&($safe['data']['connection']['identity']['application_name']??null)==='QA App'&&!str_contains(wp_json_encode($safe),$b)&&!str_contains(wp_json_encode($safe),$secret));
 }finally{
  remove_filter('pre_http_request',$http,1);remove_filter('pre_wp_mail','__return_true',1);
  foreach([1,2] as $n){$s=M90Q\Store::get('schedule',$id.'-'.$n);if($s)M90Q\Store::remove('schedule',$id.'-'.$n,$s['revision']);}$c=M90Q\Store::get('connection',$id);if($c)M90Q\Store::remove('connection',$id,$c['revision']);
  wp_clear_scheduled_hook('f3_meta_worker');if($cron)wp_schedule_single_event($cron->timestamp,'f3_meta_worker',$cron->args);
  foreach($options as $key=>$v){if($v===null)delete_option($key);else update_option($key,$v,false);}
 }
 $check('synthetic connection and schedules removed',!M90Q\Store::get('connection',$id)&&!M90Q\Store::get('schedule',$id.'-1')&&!M90Q\Store::get('schedule',$id.'-2'));
 return ['version'=>M90Q\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),'http_intercepted'=>$calls,'real_provider_calls'=>0];
}
add_action('wp_abilities_api_init',static function(){if(!class_exists(M90Q\Config::class,false))return;wp_register_ability('meta/qa-credentials090',['label'=>'Meta: conferir credenciais sintéticas','description'=>'Casos fixos do Pedido 15, somente Site-Teste sem conexões Meta; remove seus dados.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>new stdClass(),'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'meta_credentials090_qa','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>M90Q\Config::VERSION,'mode'=>'write','policy_contract'=>1,'remote_effect'=>'none','local_effect'=>'write']]]);},30);
