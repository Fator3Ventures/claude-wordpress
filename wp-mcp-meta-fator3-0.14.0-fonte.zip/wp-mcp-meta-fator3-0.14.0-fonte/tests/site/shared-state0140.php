<?php
/** Temporary read-only, exact Site-Teste boundary. Never returns stored payloads or options. */
function f3qa0140_shared_state(){
 if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||!current_user_can('manage_options'))return new WP_Error('forbidden');
 global $wpdb;require_once ABSPATH.'wp-admin/includes/plugin.php';$out=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'db'=>$wpdb->db_version(),'meta_version'=>\Fator3\Meta\Config::VERSION];
 foreach(['records'=>\Fator3\Meta\Store::table(),'history'=>\Fator3\Meta\History::table()] as $kind=>$table){
  $hash=hash_init('sha256');$count=0;$complete=false;
  for($at=0;$at<50000;$at+=200){$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i '.($kind==='records'?"WHERE bucket<>'audit' ":'').'ORDER BY '.($kind==='records'?'bucket,record_key':'row_key').' LIMIT 200 OFFSET %d',$table,$at),ARRAY_A);if($wpdb->last_error)return new WP_Error('snapshot_unavailable');foreach($rows as $r){hash_update($hash,wp_json_encode($r)."\n");$count++;}if(count($rows)<200){$complete=true;break;}}
  $out[$kind]=['rows'=>$count,'sha256'=>hash_final($hash),'complete'=>$complete];
 }
 $options=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%' AND option_name NOT LIKE 'f3_meta_qa0140%' AND option_name<>'f3_meta_audit_health' ORDER BY option_name",ARRAY_A);if($wpdb->last_error)return new WP_Error('snapshot_unavailable');$out['options']=['count'=>count($options),'sha256'=>hash('sha256',wp_json_encode($options))];$out['option_hashes']=[];foreach($options as $o)$out['option_hashes'][$o['option_name']]=hash('sha256',$o['option_value']);unset($options);
 $out['plugins']=[];$plugins=get_plugins();
 foreach(['base-site-core-fator3','wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-linkedin-fator3','wp-mcp-pipedrive-fator3','wp-mcp-meta-fator3'] as $slug){$root=WP_PLUGIN_DIR.'/'.$slug;$files=[];foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $f)if($f->isFile())$files[substr($f->getPathname(),strlen($root)+1)]=hash_file('sha256',$f->getPathname());ksort($files);$hash=hash_init('sha256');foreach($files as $path=>$sha)hash_update($hash,$path."\0".$sha."\n");$out['plugins'][$slug]=['version'=>$plugins[$slug.'/'.$slug.'.php']['Version']??null,'active'=>is_plugin_active($slug.'/'.$slug.'.php'),'files'=>count($files),'tree_sha256'=>hash_final($hash)];}
 return $out;
}
add_action('wp_abilities_api_init',static function(){wp_register_ability('meta/qa-state0140',['label'=>'Meta: estado temporário de integridade','description'=>'Digests locais sem payload de negócio; restrito ao Site-Teste.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>[],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'f3qa0140_shared_state','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>true],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>'0.14.0','policy_contract'=>1,'mode'=>'read','remote_effect'=>'none','local_effect'=>'none']]]);},30);
