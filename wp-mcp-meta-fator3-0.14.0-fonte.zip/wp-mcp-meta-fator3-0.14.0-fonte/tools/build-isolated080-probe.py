from pathlib import Path
import argparse,base64,gzip,json
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parents[1]
bundle={}
for root,prefix in [(r/'tests/native','tests/native'),(a.baseline,'baseline/wp-mcp-meta-fator3'),(a.candidate,'candidate/wp-mcp-meta-fator3')]:
 for f in root.rglob('*'):
  if f.is_file():bundle[prefix+'/'+f.relative_to(root).as_posix()]=base64.b64encode(f.read_bytes()).decode()
bundle['tests/baseline-input-schemas.json']=base64.b64encode((r/'tests/baseline-input-schemas.json').read_bytes()).decode()
a.output.write_text((r/'tests/site/isolated080-controller.php').read_text().replace('__LAB_BUNDLE__',base64.b64encode(gzip.compress(json.dumps(bundle).encode(),mtime=0)).decode()))
print(a.output.stat().st_size)
