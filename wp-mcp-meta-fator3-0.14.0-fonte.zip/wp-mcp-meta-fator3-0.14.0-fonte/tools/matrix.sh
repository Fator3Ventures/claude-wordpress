#!/bin/bash
# matrix.sh <fonte-dir> <provider> <base-zip> <previous-candidate-zip>
# Final local matrix; copies sanitized evidence into <fonte>/evidence/final/<scenario>/. Needs F3_LAB_DB_PASSWORD.
set -u
F=$1; P=$2; BASE=$3; PREV=$4; L=/home/claude/w/labs/social-final-$P; mkdir -p $L
cd $F
run(){ name=$1; shift; rm -rf "${L:?}"/"${name:?}"; python3 tools/lab.py --workdir $L/$name "$@" > $L/$name.log 2>&1; rc=$?; echo "$name rc=$rc $(tail -1 $L/$name.log | cut -c1-230)"; mkdir -p evidence/final/$name; cp $L/$name/evidence/*.json evidence/final/$name/ 2>/dev/null; cp $L/$name.log evidence/final/$name/run.log; }
R="--manifest tools/lab-rodada.json"; O="--manifest tools/lab-local.json"
run clean-isolated $R --order $P-only
run clean-integrated-rodada $R --order $P-integrated
run upgrade-integrated-rodada $R --order $P-integrated --origin upgrade
run clean-integrated-frota $O --order $P-integrated
if [ $P = meta ]; then run minimum-wp64-php812 $R --order meta-only --wordpress wordpress_minimum --php php81 --tests release060.php,release070.php,suite.php; else run minimum-wp64-php812 $R --order linkedin-only --wordpress wordpress_minimum --php php81 --tests suite.php; fi
run defects-base $R --order $P-integrated --tests defects.php --candidate $BASE
run defects-candidate1 $R --order $P-integrated --tests defects.php --candidate $PREV
run defects-candidate $R --order $P-integrated --tests defects.php
