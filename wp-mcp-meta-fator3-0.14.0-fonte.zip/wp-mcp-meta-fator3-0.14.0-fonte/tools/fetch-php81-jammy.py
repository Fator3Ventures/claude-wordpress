"""PHP 8.1.2 (Ubuntu 22.04 jammy) for the minimum-runtime matrix, from the official Ubuntu archive.

Indices: dists/{jammy,jammy-updates,jammy-security}/Release, verified with gpgv against the Ubuntu archive keyring,
then Packages SHA-256 from Release, then each .deb SHA-256 from Packages. Packages are extracted with dpkg-deb into
$F3_RUNTIME_DOWNLOAD_ROOT/root (outside the source tree). The versions used in this round are pinned in php81-lock.json.
"""
import hashlib, json, os, re, subprocess, urllib.request, gzip
from pathlib import Path
here = Path(__file__).resolve().parent
dest = Path(os.environ['F3_RUNTIME_DOWNLOAD_ROOT']).resolve()
if dest == here.parent or here.parent in dest.parents:
    raise SystemExit('Destination must be outside the source tree')
(dest / 'debs').mkdir(parents=True, exist_ok=True)
ARCHIVE = 'http://archive.ubuntu.com/ubuntu/'
KEYRING = '/usr/share/keyrings/ubuntu-archive-keyring.gpg'
lock = json.loads((here / 'php81-lock.json').read_text())
idx = {}
for pocket in ['jammy', 'jammy-updates', 'jammy-security']:
    rel = dest / f'Release-{pocket}'
    sig = dest / f'Release-{pocket}.gpg'
    rel.write_bytes(urllib.request.urlopen(ARCHIVE + f'dists/{pocket}/Release', timeout=120).read())
    sig.write_bytes(urllib.request.urlopen(ARCHIVE + f'dists/{pocket}/Release.gpg', timeout=120).read())
    subprocess.run(['gpgv', '--keyring', KEYRING, str(sig), str(rel)], check=True, capture_output=True)
    text = rel.read_text()
    sha = dict((l.split()[2], l.split()[0]) for l in text.split('SHA256:')[1].splitlines() if len(l.split()) == 3)
    for comp in ['main', 'universe']:
        raw = gzip.decompress(urllib.request.urlopen(ARCHIVE + f'dists/{pocket}/{comp}/binary-amd64/Packages.gz', timeout=300).read())
        if hashlib.sha256(raw).hexdigest() != sha[f'{comp}/binary-amd64/Packages']:
            raise SystemExit(f'Packages hash mismatch: {pocket}/{comp}')
        for block in raw.decode('utf-8', 'replace').split('\n\n'):
            f = dict(re.findall(r'^([A-Za-z0-9-]+): (.*)$', block, re.M))
            if f.get('Package'):
                idx[(f['Package'], f['Version'])] = f
for item in lock:
    f = idx.get((item['package'], item['version']))
    if not f or f['SHA256'] != item['sha256']:
        raise SystemExit('Pinned package not in signed indices: ' + item['package'] + ' ' + item['version'])
    deb = dest / 'debs' / Path(f['Filename']).name
    if not deb.exists():
        deb.write_bytes(urllib.request.urlopen(ARCHIVE + f['Filename'], timeout=300).read())
    if hashlib.sha256(deb.read_bytes()).hexdigest() != item['sha256']:
        raise SystemExit('Hash mismatch: ' + item['package'])
    subprocess.run(['dpkg-deb', '-x', str(deb), str(dest / 'root')], check=True)
print(json.dumps({'root': str(dest / 'root'), 'php': str(dest / 'root/usr/bin/php8.1'), 'packages': len(lock)}))
