"""Build a private deployment probe. Inputs: immutable 0.7.0 runtime directory, output outside source.
Never ship the generated probe in the installer. No credentials are read or embedded here.
"""
from pathlib import Path
import argparse,base64,gzip,json
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parents[1]
names=['lab-helpers.php','worker-cases.php','release060.php','release070.php','release070-metadata.php','review071.php','isolated071-install.php','isolated071-state.php','isolated071-seed.php','isolated071-upgrade.php','isolated071-smoke.php']
bundle={f'tests/native/{n}':base64.b64encode((r/'tests/native'/n).read_bytes()).decode() for n in names}
bundle['tests/baseline-input-schemas.json']=base64.b64encode((r/'tests/baseline-input-schemas.json').read_bytes()).decode()
for f in a.baseline.rglob('*'):
 if f.is_file():bundle['baseline/wp-mcp-meta-fator3/'+f.relative_to(a.baseline).as_posix()]=base64.b64encode(f.read_bytes()).decode()
a.output.write_text((r/'tests/site/isolated071-controller.php').read_text().replace('__LAB_BUNDLE__',base64.b64encode(gzip.compress(json.dumps(bundle).encode(),mtime=0)).decode()))
print(a.output.stat().st_size)
