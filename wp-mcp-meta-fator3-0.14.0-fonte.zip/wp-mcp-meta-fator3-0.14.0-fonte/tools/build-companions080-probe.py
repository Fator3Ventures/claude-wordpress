"""Build the fixed temporary Site-Teste probe from the accepted runtime hashes."""
from pathlib import Path
import argparse, json
root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser()
p.add_argument('--output', type=Path, required=True)
args = p.parse_args()
hashes = json.loads((root / 'evidence/release080/runtime-manifests.json').read_text())
template = (root / 'tests/site/meta-companions080-qa.php').read_text()
args.output.write_text(template.replace('__EXPECTED_HASHES__', json.dumps(hashes, separators=(',', ':'))))
