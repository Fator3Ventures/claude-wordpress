# Fator3 MCP Meta 0.8.0

Versão corrente: **0.8.0**, instalada e ativa no Site-Teste. Base aceita: 0.7.1. A revisão dos novos pacotes identificou uma janela entre duas leituras no isolamento de jobs. A correção decide pela mesma cópia do payload usada no CAS. Não muda schema, IDs, permissões ou configuração, nem reativa registros já isolados.

Código canônico: `build/common` e `build/meta`; documentação instalada: `build/docs/meta`. Runtime em `plugin/wp-mcp-meta-fator3`, idêntico ao instalador testado. Evidências próprias: `evidence/release080`. Entradas e provas anteriores mantêm nomes históricos e não representam testes novos. O relatório externo `wp-mcp-meta-fator3-0.8.0-relatorio.md` é canônico; a cópia dentro do fonte antecede o fechamento.

## Build

```sh
F3_SOCIAL_PHP=/caminho/absoluto/php python3 build/build.py
```

Saída testada: `build/dist/wp-mcp-meta-fator3-0.8.0-instalador.zip`, 153819 bytes, SHA-256 `36e4e098955576c3d43ea1b1bd2c14fe68608472b8666a652e84da5165ce25e1`. `tools/package-source.py --output-dir <diretorio-externo>` confere o runtime e recusa sobrescrever um fonte fechado. `build/dist` não entra no ZIP fonte; nenhum ZIP da entrega contém outro ZIP.

## Validação e reprodução

- `tests/native/snapshot080-cases.php`: oito verificações de snapshot, SQL, cifra/JSON e preservação. A base 0.7.1 falha em dois checks esperados; a 0.8.0 passa nos oito.
- `tests/site/isolated080-controller.php` e `tools/build-isolated080-probe.py`: laboratório remoto privado com WordPress e prefixo exclusivo de tabelas. Gerar com `--baseline <runtime-071> --candidate <runtime-080> --output <fora-do-fonte>`. Operações fixas `setup`, `suite`, `upgrade`, `cleanup`; `php812` extrai privadamente os pacotes oficiais fixados em `tools/php81-lock.json`, e `reinstall812` refaz a instalação limpa. Nunca instalar esses auxiliares em produção.
- `tests/site/meta-regression080-qa.php`, `meta-review080-qa.php`, `meta-snapshot080-qa.php`: regressões integradas com dados sintéticos e limpeza. A guarda de revisão permite o marcador técnico `history_generation` e continua recusando dados de negócio preexistentes.
- `tests/site/meta-companions080-qa.php` e `tools/build-companions080-probe.py --output <fora-do-fonte>`: contratos de retry/perfis MCP e integridade dos runtimes. Replay usa callback sintético e envelope real de falha Meta, sem operação de fornecedor.

Site-Teste integrado: 168 checks aprovados, mais selftest com oito checks e 17 documentos lidos integralmente em 21 chamadas MCP. WordPress 6.4/PHP **8.1.2-1ubuntu2.28**, sem acompanhantes: instalação limpa e 137 checks aprovados. Atualização direta 0.7.1 → 0.8.0: cinco checks de preservação e 101 de metadados/documentação. MySQL 8.0.41; PHP de 64 bits. A matriz completa está no relatório.

Credenciais do laboratório permanecem no servidor. Sondas não integram o instalador e devem ser removidas antes de trocar o plugin e depois dos testes. Todos os laboratórios e sondas desta rodada foram removidos; backups operacionais do MCP e auditoria legítima permanecem. O aviso inicial de PCRE JIT restrito ao laboratório foi resolvido no harness com `pcre.jit=0`; suites finais sem stderr. Não houve homologação de API social nem entrega real de e-mail.

## Pedidos e impactos

`inputs/0.8.0` conserva os documentos recebidos; `planning/RELEASE-080.md` registra o planejamento anterior ao código. A aba Meta(6) não traz pedidos abertos, portanto não se cria número 15. O impacto MCP 0.29.1 foi aplicado à orientação documental e validado sem inventar `applied=false`. O impacto próprio original 0.7.1 → LinkedIn foi encerrado na revisão 4 em `impacts/`, preservando histórico. Nenhum código de acompanhante ou documento central foi alterado.
