# Entrega — Fator3 MCP Meta 0.7.0

> Cópia anterior ao fechamento do fonte. Relatório externo canônico: `wp-mcp-meta-fator3-0.7.0-relatorio.md`, entregue ao lado deste ZIP, com o tamanho e o SHA-256 do próprio fonte.

Revisão: 1 · Data/hora: 2026-10-23T02:10-03:00 · Rodada: implementação (melhorias por ordem do dono de 22/10/2026, rodada conjunta dos cinco pacotes Fator3). Candidato corrigido após revisão independente interna, antes de qualquer entrega ao dono.
Slug: `wp-mcp-meta-fator3` · Versão/build: 0.7.0 / build determinístico de `build/build.py`
Status: `com-pendencias` — apta no escopo testado em laboratório local; instalação no Site-Teste e na frota e homologação na Meta real ficam pendentes (seção 6).

## 1. De onde esta versão entra

Instalação nova em WordPress limpo e atualização direta da **0.6.0**, sem versão intermediária. Base recebida e preservada byte a byte: `wp-mcp-meta-fator3-0.6.0-instalador.zip`, 134999 bytes, SHA-256 `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69`; fonte 405780 bytes, SHA-256 `7f5454c7b7fe9f66f080a602d7fad69c5cd2bc051a41933b243fad057af8c7da`. O build do fonte-base reproduziu o instalador 0.6.0 byte a byte antes de qualquer mudança.

Identidade preservada: nome Fator3 MCP Meta, slug/pasta/provider, basename `wp-mcp-meta-fator3/wp-mcp-meta-fator3.php`, namespace `Fator3\Meta`, Text Domain, Update URI, rota REST `f3-meta/v1`, tabela `wp_f3_meta_records`, opções `f3_meta_*`, hooks e os 33 IDs `meta/*`. Incremento minor (normas comuns revisão 4).

Requisitos comprovados nesta rodada: **WordPress 6.4 com PHP 8.1.2** (instalação limpa, sem Abilities API, portanto sem MCP) e **WordPress 7.1.3 com PHP 8.3.6**, MySQL 8.0.46, PHP de 64 bits. Os mínimos do cabeçalho (6.4 e 8.1.2) deixam de ser apenas herdados: foram exercitados. PHP 8.1.2 veio do arquivo oficial do Ubuntu 22.04 (`8.1.2-1ubuntu2.28`, índices com assinatura conferida por gpgv); WordPress 6.4 e 7.1.3 dos ZIPs oficiais com SHA-1 conferido.

## 2. Convivência e encaminhamentos

| Pacote | Conjunto da rodada (versões novas) | Conjunto hoje na frota |
|---|---|---|
| Fator3 Site Core | 1.49.0, `64a80ede90d8cc4a555ba39a016eae217898191a6275cb9cdaaed71388af8657` | 1.48.0, `91097a3819cce15fcc66adfa5d8503537cacdb51cfd3ad04ba73e5f7c27a18de` |
| Fator3 MCP | 0.29.0, `1720f2db05c5a6ee90d1269ebdc764c14fb6b60e2878f765cf1183093ef1fb2a` | 0.28.0, `d1d297d8aaee0e5188b92fe9eae20a9dcc07e79d639baae25f267bf64f7243b0` |
| Fator3 MCP Google | 0.18.0, `b1ce908558502c8edf2c6928112d5a772b3690810cfc11405dcfe0547f2baea9` | 0.17.0, `42bd11080b518c82e0960753fa7b08d7adae28743cfcd3e96f9b83bf3f4709b0` |
| Fator3 MCP LinkedIn | 0.8.0, `035a84fea5a02480c933c626cda994c49e58649ab4fb192f90b1f526238e8c35` | 0.7.0, `85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515` |

A 0.7.0 foi validada com os dois conjuntos (seção 4). Nenhuma ordem de troca é exigida. Por ordem do dono, esta entrega tem só três arquivos; as consequências para outros pacotes ficam aqui:

- **Encerramento do impacto `wp-mcp-meta-fator3-0.6.0-impacto-wp-mcp-fator3.md` (revisão 3, `validacao-coordenada`/`alerta-tecnico`) — situação `resolvido`.** O impacto ficou aberto porque, com `meta/status` passando a escrita local na 0.6.0, o perfil read do Fator3 MCP perdeu o diagnóstico Meta e os perfis da frota precisariam de revisão. A 0.7.0 resolve no próprio pacote com `meta/health` (mode=read, local_effect=none, remote_effect=none), mesmo diagnóstico sem reparo. Provado com o MCP 0.28.0 e com o MCP 0.29.0 reais: perfil read executa `meta/health` e continua recusado em `meta/status`. Não há ação requerida no MCP nem revisão obrigatória de perfis; recuperação por agente continua exigindo maintenance ou custom com `meta/status`. O registro de encerramento também está na cópia do impacto dentro do fonte (`impacts/`).
- Fator3 MCP LinkedIn: código comum convergido com a 0.8.0 (`Support.php`, `Query.php`, `Queue.php`, `Documentation.php`, `Export.php` idênticos em texto); builds e versões independentes.
- Site Core: o aviso `_load_textdomain_just_in_time` do domínio `f3base` visto no conjunto de hoje vem do LinkedIn 0.7.0 com o Core 1.48.0; não é do Meta e não aparece com o conjunto da rodada.

Escopo avaliado: registro de abilities e categoria, descoberta e perfis MCP, documentação pelo executor MCP, auditoria local, cron, opções e tabela. Implantador não recebido: `nao-avaliado`.

## 3. Mudanças e evidência

Pedidos numerados abertos: nenhum (aba Meta em 22/10/2026: "nada pendente"). Itens desta rodada: Melhorias M1–M5, origem ordem do dono de 22/10/2026. As sondas `tests/native/defects.php` rodam iguais na base, no primeiro candidato e no candidato final.

Convenção de efeitos (documentada em CONTRACTS.md): toda operação despachada pelo painel, REST, ability ou MCP grava uma linha no registro de auditoria local (`meta/audit`, retenção de 30 dias) e atualiza `f3_meta_audit_health` quando muda; a leitura documental é a única exceção. `local_effect` descreve o estado operacional (configuração, fila, agendas, credenciais, histórico) e não conta essa linha.

| Item | Problema na 0.6.0 | Mudança | Resultado e evidência |
|---|---|---|---|
| M1 — `meta/health` | Desde a 0.6.0 `meta/status` é escrita local (rearma o worker); agentes com perfil read perderam o diagnóstico. | Nova `meta/health`: mesmo diagnóstico, sem rearmar, sem e-mail, sem chamar a Meta; grava só a linha de auditoria, como toda operação despachada. mode=read, local_effect=none, remote_effect=none. `meta/status` mantém contrato e recuperação. | `implementado`, `validado-wordpress`: pelo REST e pela ability, as únicas escritas são a linha de auditoria e `f3_meta_audit_health`, sem reagendamento, e-mail ou HTTP; perfil read do MCP real chama `meta/health` e é recusado em `meta/status`; assinante recebe 403. |
| M2 — Carregamento sem SQL do pacote | A cada requisição do site, o bootstrap consultava `f3_meta_schema`, `f3_meta_history_schema` (opções sem autoload) e a tabela (migração pendente). | As marcas lidas em toda requisição ficam no autoload: `f3_meta_schema` e `f3_meta_history_schema` passam a autoload uma única vez (`wp_set_option_autoload`, WordPress 6.4+), e a nova `f3_meta_queue_settled=2` (autoload) dispensa a consulta de migração. | Sonda D6 conta toda consulta do pacote (tabela ou opção `f3_meta_*`) numa requisição nova: 0.6.0 = 3 consultas; primeiro candidato 0.7.0 = 3 (ainda lia opções sem autoload); final = 0. Marcas conferidas no autoload. |
| M3 — Registro ilegível | Registro de coleta que a chave atual do site não abre parava a migração no primeiro lote e abortava a retenção de todas as coletas. | Projeção `unreadable`: não executa, não apaga, não bloqueia a migração dos demais e sai da seleção da retenção; a retenção que encontra um ilegível não marcado o marca e segue. Diagnóstico `queue_record_unreadable`, fora do e-mail horário. | Sonda D4 (150 coletas ilegíveis vencidas antes de uma legível vencida): falha na 0.6.0 e no primeiro candidato, passa no final em uma passagem; com ilegíveis não marcados, a segunda passagem alcança a legível e as 150 ficam marcadas. Sonda D7 (migração) falha na 0.6.0 e passa. |
| M4 — Manutenção autorreparável | Se `f3_meta_maintenance` sumisse do cron, nada a recriava até reativar o plugin; a recuperação do worker depende dela. | Em `init` (20), sob trava de banco, reagenda a manutenção ausente; diagnóstico `maintenance_missing`. | Sonda D3: base não recria; 0.7.0 recria na requisição seguinte (processo PHP novo). |
| M5 — Registro e listagens | `meta/audit` saía em ordem de UUID (aleatória). `list-connections` decifrava as conexões duas vezes por página. | `meta/audit` do mais recente, com `since` opcional (Unix). `list-connections` com uma leitura de 51 registros. | Sonda D5 falha na base e passa; `since` filtra e recusa negativo; paginação conferida com 52 conexões, sem segredo na saída. |
| Leitura documental | `documentation` recusava `offset` acima de 100000 (no Meta nenhum documento passa de 41 KB; o defeito aparecia no LinkedIn). | Teto de `offset` elevado a 16777216. | Sonda D9 aprovada; 17 documentos lidos integralmente pelo executor MCP real. |
| Testes | Suítes fixavam versões antigas dos acompanhantes e chamavam a Abilities API sem guarda; o primeiro candidato espionava só a função interna das leituras novas. | Versões lidas dos instaladores extraídos; checagens de ability `nao-aplicavel` sem a API; escritas medidas pelo caminho publicado (REST e ability); sondas base × candidatos. | Linha de base: 0.6.0 integrado reprovava 1 checagem por versão fixa; 0.7.0 aprova todas. |

Contrato: 34 operações (33 preservadas + `meta/health`). Schemas de entrada iguais aos da 0.6.0, exceto `meta/audit` (acrescenta `since` opcional) e `meta/documentation` (teto de `offset`). Rótulos e descrições em português; `abilities-pt-br.json` gerado do registro. Arquivos de runtime: 42 (21 PHP, 17 documentos); 1 acrescentado (`includes/Queue.php`), nenhum removido.

## 4. Instalação e prova da troca

Procedimento para a frota: publicar o instalador e este relatório na raiz `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`, conferir os bytes servidos e instalar com `plugins/upload` usando a URL raw, `expected_slug: wp-mcp-meta-fator3` e o SHA-256 da seção 8. Prova da troca, em requisição nova: `meta/health` com `version=0.7.0`, `state=ok` (ou issues coerentes com o site), `queue.migration_pending=false`; `meta/selftest` aprovado; descoberta com 34 operações `meta/*`; `meta/documentation` com `document=index`.

| Cenário | Ambiente | Resultado | Evidência no fonte |
|---|---|---|---|
| Instalação limpa isolada | WP 7.1.3, PHP 8.3.6, MySQL 8.0.46, só o Meta | metadados 101, worker 27, release070 23, regressão 48; zero falhas | `evidence/final/clean-isolated/` |
| Instalação limpa, conjunto da rodada | + Core 1.49.0, MCP 0.29.0, Google 0.18.0, LinkedIn 0.8.0 | metadados 103, worker 30, release070 23, regressão 50, documentação MCP 18 (17 documentos, 19 páginas); zero falhas; `debug.log` vazio | `evidence/final/clean-integrated-rodada/` |
| Atualização direta 0.6.0 → 0.7.0, conjunto da rodada | dados semeados na 0.6.0 | metadados 135 (registros, histórico, opções e ciphertext idênticos), worker 30, release070 23, regressão 51, documentação MCP 18; zero falhas | `evidence/final/upgrade-integrated-rodada/` |
| Instalação limpa, conjunto de hoje na frota | + Core 1.48.0, MCP 0.28.0, Google 0.17.0, LinkedIn 0.7.0 | metadados 103, worker 30, release070 23, regressão 50, documentação MCP 18; zero falhas | `evidence/final/clean-integrated-frota/` |
| Mínimos do cabeçalho | WP 6.4, PHP 8.1.2, só o Meta | worker 26, release070 20, regressão 48; zero falhas; Abilities API ausente (checagens de ability não aplicáveis) | `evidence/final/minimum-wp64-php812/` |
| Sondas base × candidatos | conjunto da rodada | 0.6.0: D3–D7 falham; primeiro candidato: D4 e D6 falham; final: D1–D7 e D9 aprovadas | `evidence/final/defects-base/`, `defects-candidate1/`, `defects-candidate/` |

As contagens são por suíte e têm regressões comuns; não são casos únicos somáveis. Em todos os cenários: instalador idêntico ao instalado (inventário por SHA-256) e nenhuma linha de notice/warning/deprecation/fatal atribuída ao Meta no `debug.log`. No conjunto de hoje aparece um aviso de tradução antecipada do domínio `f3base`, provocado pelo LinkedIn 0.7.0 com o Core 1.48.0 (seção 2). Fornecedor e e-mail interceptados; nenhuma chamada real à Meta e nenhum e-mail real.

Documentação: índice e leitura integral por `meta/documentation` (painel, REST e executor MCP real), revisão SHA-256 conferida, recusa de travessia e de revisão obsoleta, leitura sem HTTP nem gravação. Documentos atualizados: README, CHANGELOG, WORKER, CONTRACTS, AGENTS, TROUBLESHOOTING, MIGRATION e títulos de versão dos demais.

Estado final: laboratórios locais descartáveis, bancos removidos ao final de cada execução. Nenhum site da frota nem o Site-Teste foi alterado.

## 5. Banco e volta de versão

Sem tabela nova e sem mudança de schema (continua 2). A atualização não altera registros, cifra, revisões, datas, agendas, conexões, concessões nem histórico (provado por hash do estado antes/depois). Gravações novas, sob demanda: opção `f3_meta_queue_settled` (autoload), `f3_meta_maintenance_rearmed`, campos `unreadable`/`unreadable_total` em `f3_meta_queue_migration`, projeção `queue_state=unreadable` apenas para registros que a chave atual não abre, e a coluna `autoload` de `f3_meta_schema` e `f3_meta_history_schema` passa a ligada na primeira requisição (valores inalterados).

Volta à 0.6.0: os arquivos da base funcionam com o mesmo banco; perdem `meta/health`, o autorreparo da manutenção e o isolamento de registro ilegível (a migração e a retenção voltam a parar no primeiro registro ilegível). Projeções `unreadable` permanecem e não são executadas; as opções em autoload continuam válidas. Restaurar arquivos não desfaz coletas nem avisos enviados. Preserve banco e salts com o backup; não desinstale para simular rollback. Downgrade não foi ensaiado nesta rodada.

## 6. O que permanece pendente

| Pendência | Responsável |
|---|---|
| Instalar no Site-Teste e repetir a prova da seção 4 em WordPress real compartilhado | Site Geral \| Todos / dono (este projeto não grava no Site-Teste fora do teste do caminho do lead) |
| Publicar e distribuir na frota com `expected_sha256` e `expected_slug` | Dono / frota |
| Homologação externa: rotação real de token, exportação de histórico real, Story expirada com insight guardado, entrega real de e-mail | Dono / frota (pendência 20 do estado da frota) |
| Atualização a partir da 0.6.0 no WordPress 6.4/PHP 8.1.2 | Não executada; o mínimo foi provado em instalação limpa |
| Revisão visual em navegador | Não aplicável: JavaScript e telas não mudaram |

## 7. Credenciais e configuração do dono

Nenhum campo ou segredo novo. Tokens e seleção de ativos continuam em Ferramentas → Fator3 MCP Meta. Não recrie credenciais para atualizar. Para agentes com perfil read no Fator3 MCP, `meta/health` já está disponível; para recuperação do worker, o perfil precisa de `meta/status` (maintenance ou custom). Destinatário dos avisos operacionais: e-mail de administração em Configurações → Geral, como na 0.6.0.

## 8. Identidade dos arquivos

| Artefato | Nome final | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | `wp-mcp-meta-fator3-0.7.0-instalador.zip` | 145728 | `727fab33a1b8e43c2d8980a1b6ca8deb8af39762b334ac1f524471f9d6bbfaa8` |
| Fonte | `wp-mcp-meta-fator3-0.7.0-fonte.zip` | a preencher no relatório externo após empacotamento | a preencher no relatório externo após empacotamento |

Somente o instalador é instalável (raiz `wp-mcp-meta-fator3/`). O fonte tem raiz `wp-mcp-meta-fator3-0.7.0-fonte/`, runtime idêntico ao instalador, build, testes, ferramentas, evidências sanitizadas e a cópia deste relatório anterior ao fechamento. Nenhum ZIP contém outro ZIP. O instalador foi gerado duas vezes a partir do fonte com bytes idênticos. Este candidato substitui o primeiro (SHA-256 `9763582399f4c3e4c38dcf6c81070c47c8afd08abc457f3bba4e9ff12420b905`), que não foi entregue.
