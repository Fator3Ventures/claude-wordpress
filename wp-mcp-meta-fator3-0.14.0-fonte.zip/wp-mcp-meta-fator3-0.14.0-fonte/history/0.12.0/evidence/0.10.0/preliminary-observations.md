# Observações preliminares

- MySQL local não iniciou: socket Unix recusado pelo ambiente. Nenhum teste funcional local de banco é alegado. Provas funcionais executadas em laboratório com tabelas/diretório próprios no Site-Teste autorizado.
- A primeira rodada 16/17 teve 39/40 verificações: duas execuções do harness usaram a mesma janela de agenda na virada do segundo e reutilizaram o job anterior. O relógio sintético foi fixado para gerar janelas distintas; 40/40 passaram sem alteração de classificação por causa desse caso.
- Regressões antigas comparavam literalmente Versão 0.9.0 e “salve novamente”, instrução substituída pelo pedido 17. Expectativas atualizadas para a versão efetiva e a orientação “salve a agenda” para falha de concessão local.
- A dependência DOM da sessão anterior não estava mais disponível. jsdom 27.4.0 foi instalado novamente em diretório privado, fora do instalador/fonte.

- A primeira adaptação do teste integrado consultava o LinkedIn depois de restaurar um contexto MCP inexistente no CLI. A consulta foi colocada dentro da concessão temporária de manutenção do laboratório. O Pipedrive é conferido pela recusa administrativa esperada (operacao_nao_autorizada), nunca por sucesso comercial. Nenhum acompanhante foi alterado.

- O teste adicional de conexão removida durante a vida de um job encontrou uma recusa indevida do novo registro diagnóstico: o código legado é not_configured, não not_found. Corrigido para preservar o resultado pausado do job e ainda registrar a auditoria, antes de fechar/instalar o pacote compartilhado.
