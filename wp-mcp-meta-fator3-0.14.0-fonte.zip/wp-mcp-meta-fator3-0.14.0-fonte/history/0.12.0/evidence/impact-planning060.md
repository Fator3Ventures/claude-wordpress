# Impacto de Fator3 MCP Meta 0.6.0 em Fator3 MCP

Revisão 1 · 22/10/2026 · planejamento · situação aberto · validacao-coordenada / alerta-tecnico.

Emissor: Meta, base 0.5.0, alvo previsto 0.6.0. Destinatário: MCP 0.28.0 e mantenedor/frota. Instalador-alvo ainda não gerado. Referência: Pedidos MCP Meta 13(a,d) e 14; normas comuns revisão 4.

## Mudança e consequência

O pedido explícito exige que meta/status recupere o evento local ausente. A operação passa a declarar mode=write, local_effect=write, remote_effect=none e readonly=false. Preserva nome e entrada vazia. O diagnóstico registra o estado observado antes do reparo e o resultado da tentativa, sem consultar o fornecedor, executar coletas ou reatribuir concessões. Isso é exceção solicitada à regra de diagnóstico sem reparo. Documentação continua sem efeitos.

Perfis somente leitura podem deixar de autorizar meta/status; o transporte deve respeitar a declaração efetiva. Perfis que precisam desse diagnóstico devem autorizar a operação e escrita local. Não se amplia automaticamente um perfil. O usuário pode consultar a documentação estática sem essa concessão operacional. Revogação de concessão continua bloqueando as agendas: o Meta apenas indica a necessidade de salvar novamente com identidade autorizada.

## Ação e aceite previstos

Meta implementa e valida registro, política real do MCP, rejeição de assinante, descrição atualizada e leitura documental completa. Mantenedor MCP não precisa alterar código se o contrato atual já aceitar os efeitos declarados. Dono/frota revisa perfis personalizados e distribui o pacote após aceite. Sem publicação ou mensagem externa nesta tarefa.

Testar com MCP 0.28.0, LinkedIn 0.7.0, Core 1.47.0 e Google 0.17.0. Instalação independente do Meta permanece suportada. Não há contrato novo com os demais pacotes nem consumo de auditoria LinkedIn de serviço.

## Evolução

Revisão 1 emitida antes da implementação. A revisão de entrega informará contrato efetivo, evidências, hash e pendências sem apagar esta decisão.
