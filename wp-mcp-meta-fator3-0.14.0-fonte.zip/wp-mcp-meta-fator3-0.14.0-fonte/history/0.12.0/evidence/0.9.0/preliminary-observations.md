# Observações preliminares resolvidas

- Rótulos/helpers: o primeiro build acusou divergência no catálogo porque o novo rótulo não havia sido inserido pelo script de edição; corrigido antes dos testes.
- Smoke reaproveitado esperava 34 operações; passou a verificar 35. Sua repetição também precisou reutilizar o usuário sintético já criado, para não confundir WP_Error de nome duplicado com usuário válido. Não se alterou a política do plugin.
- Snapshot solicitado com nome antigo foi recusado pelo schema fixo do laboratório; a suíte 090 executou os mesmos oito casos e passou.
- O redator real do MCP ocultava token_identity no resultado. Corrigido no Meta com projeção pública identity; filtros de segredo e nomes legados preservados. DOM e integração real repetidos e aprovados.
- A adaptação do controlador 080 para 090 havia substituído também um trecho de hash do DEB php8.1-mysql. A guarda recusou a instalação. O hash foi restaurado do lock original e o arquivo conferido com a origem oficial; todos os pacotes foram verificados antes de ativar PHP 8.1.2. Nenhum pacote divergente foi executado.
- O acompanhante LinkedIn mudou de 0.10.0 para 0.10.1 enquanto a primeira checagem de convivência fixava 0.10.0. A repetição verifica a versão carregada e registra 0.10.1; o endpoint funcionou. Não foi alteração ou regressão produzida pelo Meta.

As provas iniciais permanecem identificadas e não são contadas como aprovação. Nenhum achado conhecido permanece aberto nos cenários exercitados.
