# Planejamento e decisões — Fator3 MCP Meta 0.6.0

Rodada de 22/10/2026, normas comuns revisão 4. Base 0.5.0 imutável; pedidos 13 e 14. O impacto revisão 1 foi emitido em `impacts/wp-mcp-meta-fator3-0.6.0-impacto-wp-mcp-fator3.md` antes da implementação da fronteira MCP.

1. Corrigir recuperação via manutenção/status e reagendamento verificado. O pedido explícito de reparo em status exige classificar a operação como escrita local, com antes/depois observáveis.
2. Expor atrasos e falhas de autorização por agenda; aviso ao administrador configurado, com limitação de frequência. Nunca reassociar concessão automaticamente.
3. Substituir varredura dos jobs por projeção indexada na própria linha. Alternativa de uma segunda tabela de fila foi descartada para preservar atomicidade entre payload e estado por uma única gravação CAS, sem obrigação de reconciliar órfãos entre tabelas.
4. Migrar registros antigos em lotes de 100, mantendo seleção imediata de registros novos e estado de cobertura incompleta. Falhas permanecem observáveis; não descartar dados ilegíveis.
5. Testar WordPress real limpo e upgrade direto com Core 1.47.0, MCP 0.28.0, Google 0.17.0 e LinkedIn 0.7.0; simular fornecedor e e-mail. Conferir 2.000 jobs concluídos, revogação real de concessão MCP, índice, locks, CAS, recuperação, documentos e tela.
6. Site-Teste foi inspecionado; tentativa de instalação foi rejeitada pela revisão automática de aprovação por falta de autorização explícita de deploy. Nenhuma mutação remota ocorreu. A entrega continua concreta e testada localmente; o aceite remoto depende do dono autorizar.

Nenhum desenvolvimento adicional requerido dos acompanhantes foi identificado além do efeito sobre perfis/consumo de meta/status. Implantador não recebido: não avaliado. Não se implementa o canal de serviço LinkedIn no Meta, nem tags/Ads/CAPI/leads do Core. Documentos centrais e pacotes alheios preservados.
