# Impacto de Fator3 MCP Meta 0.13.0 em Fator3 Site Core

28/10/2026 · Revisão 2 · Etapa entrega · Situação demanda-aberta.  
Emissor: wp-mcp-meta-fator3, base 0.12.0, alvo 0.13.0. Instalador: 284069 bytes, SHA-256 3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1. Base: SHA-256 b519203886d0964fa531c70cd0a66e2f8e199ff04700f0c3c5fa946d6d83e880.  
Destinatário: base-site-core-fator3 1.57.1, SHA-256 ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62.  
Natureza: novo contrato de leitura/integração analítica. Classificação: acao-necessaria. Referência: Pedidos MCP Meta 20(e), linha 95 item (5) de Para a frota/Growth Campanhas. Nenhum novo número de pedido Core foi inventado.

## Mudança e consequência

Meta conserva Ads Insights diários cifrados, por conta/campanha/conjunto/anúncio, sem expiração automática. Contrato PHP público meta-ads-reader/1.0.0, hook f3_meta_register_ads_consumers, AdsReader::register_consumer e cliente opaco com query/status. Callback do consumidor informa connection_id, account_id, revision e ready. A leitura consulta o acervo local, não faz Graph e não fornece tokens. Requer concessão explícita e corrente por consumidor/conexão/conta; cursor vincula revisão de configuração/concessão, autorização da conexão, seleção e geração do acervo. A origem administrativa e o transporte que concedeu acesso precisam continuar autorizados; cron sem usuário funciona somente com o objeto registrado e concedido.

Precisão contratual desta revisão: a identidade do registro inclui moeda e fuso, além de conexão/conta/nível/entidade/dia/atribuição. Valores monetários são strings decimais, ausências são null e resultados preservam os tipos do fornecedor. Não somar lead agregado com leads de formulário/site nem inferir resultado principal. last_available_fields guarda o último valor não nulo de cada campo, com instante próprio; ele é anterior quando o campo corrente vier ausente e não pode ser apresentado como nova confirmação. Há também última observação integral bem-sucedida. Um dia sem linhas não apaga observações anteriores nem cria zeros: o consumidor deve conferir last_seen e coverage.

O Core1.57.1 não registra esse consumidor nem relaciona automaticamente esses dados aos contatos. O pacote Meta fornece fatos analíticos e proveniência; relação com parceiro/contato, atribuição e prevenção de somas entre níveis pertencem ao Core. Alcance/frequência não são somáveis entre dias/entidades; ações podem se sobrepor; moeda/fuso/nível/atribuição devem acompanhar todo valor.

## Pedido ao mantenedor Core

Registrar consumidor próprio, persistir configuração e revisão, obter concessão pelo fluxo administrativo Meta e ler páginas do contrato público. Relacionar campanhas por IDs estáveis/conta/plataforma e configuração explícita do parceiro; nomes são rótulos e não chaves de atribuição. Apresentar lacunas, revisão/instante e moedas separadas. Reconsultar os dias recentes substituindo a observação anterior, sem somar revisitas nem misturar totais de conta, campanha, conjunto e anúncio. Tratar history_changed/revision_conflict reiniciando a leitura consistente; não concatenar páginas de gerações diferentes. Não ler Store/options/tokens privados do Meta.

Aceite coordenado: negar antes da concessão; ler acervo sintético de 30 dias por campanha e comparar gasto/impressões/cliques; reconciliação de dia revisto sem duplicação; preservar tipos de resultado/lead e indisponibilidade; rejeitar conta/consumidor/cursor divergente, revogação e alteração de identidade. A homologação real dos 30 dias em korvena.com.br/ctooffice.com.br depende de credencial/ativo e implantação autorizada pela frota.

## Compatibilidade e validação prevista

Contrato aditivo; SDKs instagram-first-message/1.0.0 e instagram-message-erasure/1.0.0 preservados. Meta pode ser atualizado antes do consumidor Core; concessão desligada por padrão. Não há obrigação nova para LinkedIn/Google/Pipedrive. A validação coordenada requerida inclui consumidor Core real, além de fixture de registro, executor MCP atual e HTTP sintético. Especificação executável: plugin/wp-mcp-meta-fator3/includes/AdsReader.php; documentação instalada META-ADS-READER.md e META-ADS.md. A revisão 1 emitida no planejamento permanece em planning/IMPACTO-CORE-0130-rev1.md.

Respostas, comprovações de atendimento e encerramentos devem constar nos relatórios principais dos responsáveis. Este arquivo somente recebe revisão se houver mudança substantiva da consequência técnica, contrato ou pedido.
