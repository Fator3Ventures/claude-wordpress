# Entrega — Fator3 MCP Meta 0.11.1

Revisão 1 · 26/10/2026 · Fuso America/Sao_Paulo. Rodada de implementação dos Pedidos MCP Meta 18 e 19, ampliação da retenção e correção documental. **Cópia interna anterior ao fechamento do fonte**: a identidade final desse ZIP consta somente no relatório externo.

Estado: implementado e instalado no Site-Teste, com pendências de homologação real na Meta e do consumidor Core309. A 0.11.1 passa a ser a versão corrente desta entrega. Não houve implantação na frota nem alteração de outro plugin.

## 1. Bases aceitas

Base funcional aceita: **0.10.1**, conforme `Fator3 MCP Meta(10).md`. Atualização direta para a 0.11.1 comprovada; a 0.11.0 não é pré-requisito. A 0.11.0 foi implementada e instalada durante esta rodada; após a instalação, a inspeção encontrou referências documentais antigas à auditoria de 30 dias/exportação de 24 horas. A correção do conteúdo instalado motivou o patch 0.11.1, conforme a orientação de incrementar patch ao corrigir uma versão já instalada.

| Base Meta | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-meta-fator3-0.10.1-instalador.zip | 192114 | `f80d934fe1851bc887a0174190b42d73b36a8637f2f4824bdb5cfeb7a674ee95` |
| wp-mcp-meta-fator3-0.10.1-fonte.zip | 1476729 | `e333d22a82599e08c015002bb2ea6536a98ddacbfc68ede82a422733e135e908` |

Aplicadas as instruções comuns **revisão 5, de 23/10/2026**, que prevalecem sobre a revisão 4 reanexada. Considerados os pedidos 18/19, os novos pacotes/relatórios, impactos recebidos e as duas orientações explícitas para maximizar a retenção, inclusive das funcionalidades já existentes. As entradas estão em `inputs/0.11.0`; os planos em `planning/RELEASE-0110.md` e `planning/PATCH-0111.md`. A lista central de pedidos não foi modificada nem encerrada.

Preservados slug, basename, namespace, provider, Text Domain, Update URI, prefixos e os 35 IDs anteriores. O catálogo passa a **41 operações**, com seis adições: `meta/messaging-status`, `meta/save-messaging-settings`, `meta/conversations`, `meta/process-messages`, `meta/story-archive` e `meta/story-archive-thumbnail`.

## 2. Convivência e encaminhamentos

Os relatórios recebidos foram considerados como evidência de seus mantenedores. A prova própria desta rodada é a ativação conjunta e a execução das fronteiras listadas abaixo em WordPress real isolado no Site-Teste. Não representa homologação de todas as funções comerciais de cada acompanhante.

| Pacote examinado e testado | Versão | SHA-256 do instalador |
|---|---|---|
| base-site-core-fator3 | 1.55.0 | `1d7e54fb86ea4c61de5e58df22e81b5e93aad3018bc5802fb3fd86ff48dd41a0` |
| wp-mcp-fator3 | 0.33.0 | `f16ee3e31e4143ffb42c566ea6da4f2da81d3771a01a0f90b5d34e3d02ac8caa` |
| wp-mcp-google-fator3 | 0.19.0 | `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1` |
| wp-mcp-linkedin-fator3 | 0.10.1 | `6182ea63bff6788f5d2637467e7ab29d58568e37283d6ece82d3e58ee41c13bc` |
| wp-mcp-pipedrive-fator3 | 0.1.0 | `3366d83ca8908e407a0736812d30b8fa1506a8c1458a28cfb47eda6fd8f3c54f` |

A suíte integrada do patch passou **22/22** verificações: identidade e integridade dos runtimes acompanhantes, autorização, perfis read/maintenance, idempotência e resultados incertos, redação de dados, descoberta, chamada de leitura LinkedIn e gate do Pipedrive. Metadados/documentação/painel MCP passaram **121/121**. Os hashes dos arquivos acompanhantes estão em `tests/companion-hashes0110.json`. Não foi identificada regressão no LinkedIn nas interfaces examinadas; seu pacote não foi alterado.

| Impacto recebido/anterior | Pedido e responsável | Tratamento e evidência própria |
|---|---|---|
| `impacto-mcp-0.29.1-para-wp-mcp-meta-fator3.md`, revisão 2 | R1, MCP/Meta: não repetir mutação de efeito incerto; fronteira health/status | Preservado no MCP 0.33.0: retryable não comprova ausência de efeito, recibo incerto não autoriza repetição; health permitido em read, status exige escrita. Suíte integrada 22/22 no patch. |
| `wp-mcp-linkedin-fator3-0.8.1-impacto-wp-mcp-meta-fator3.md`, revisão 2 | R1/R2, Meta: isolamento de job ilegível e diagnóstico | Regressão 11/11 na 0.11.0: isolamento preserva payload/revisão/datas e diagnóstico continua legível. Código funcional byte a byte idêntico na 0.11.1, exceto identificação de versão. Não se declara nova execução desses 11 no patch. |

**Único novo encaminhamento:** `wp-mcp-meta-fator3-0.11.1-impacto-base-site-core-fator3.md`, revisão técnica 3, demanda aberta, ação necessária ao mantenedor Core, Pedidos MCP Meta 18(b)/Core309. Foi preparado desde o planejamento da 0.11.0 e refinado pelo contrato de reconciliação e pela retenção ilimitada; o alvo final foi ajustado para 0.11.1 antes da entrega. O documento preserva a etapa em que o instalador ainda não estava fechado; a identidade efetivamente entregue está neste relatório. Não foi enviado a pessoas ou sistemas.

O Core **1.55.0 não possui** o consumidor `instagram-first-message/1.0.0`. `f3base/contato-externo-registrar` é o fluxo administrativo/manual 302, sem equivalência demonstrada com ingestão automática Instagram; não foi usado como substituto. A criação automática permanece desligada e indisponível sem consumidor compatível. Não se declara Core309 atendido. Respostas e acompanhamento permanecem neste relatório; nenhum impacto histórico foi reemitido para anunciar encerramento.

## 3. Mudanças por pedido e evidência

| Pedido | Implementação e resultado | Limite explícito |
|---|---|---|
| 18(a), conversas | Leitura por conexão/conta, metadados sem texto, paginação limitada e continuação, primeira mensagem disponível e contagem por dia UTC. Origem Story/anúncio/ig.me somente quando a referência é fornecida e comprovada; ausência é `unknown`. | Primeira disponível não comprova primeiro contato vitalício. A API pode omitir pedidos sem atividade por 30 dias. Uma página informa sua própria cobertura, sem declarar total global. |
| 18(b), contatos | Webhook próprio com HMAC do corpo bruto, challenge exato, seleção de conta, autorização atual, proteção contra replay/echo/saída e diário cifrado mínimo. SDK opcional para Core, reserva durável antes do callback, recibo/reconciliação e ausência de retry automático em incerteza. | Fluxo comercial depende do consumidor Core309. Fixtures exercitaram callback sintético; nenhum contato real foi criado. |
| 18(c), diagnóstico | Health e tela indicam escopos ausentes/não comprovados, seleção profissional/Page, autorização e estado declarado da Análise do App. Escopo ausente produz `scope_missing` legível. | Declaração do operador não vira aprovação verificada. App Review e novo token são passos do dono. |
| 19(1–2), insights | Stories: follows, profile_visits, shares, total_interactions, link_clicks e profile_activity; posts/álbuns: profile_visits, follows e profile_activity. Detalhes action_type e story_navigation_action_type quando aplicáveis. | Não consulta filhos como álbum nem inventa buckets ausentes. Disponibilidade real depende do ativo/Graph. |
| 19(3), tipo de mídia | reach/views da conta aceitam `media_product_type` explicitamente na Graph v24.0. | Tipo de mídia não separa automaticamente orgânico/pago nem atribui contato a post por proximidade temporal. |
| 19(4), arquivo de Stories | Coletas arquivam data, tipo, permalink, legenda e miniatura antes dos insights. Agenda horária pelo painel, sem congelar janela de datas. Consulta simples não grava arquivo. | Arquivo privado cifrado; não armazena vídeo completo. Thumbnail limitada a JPEG reprocessado, 256 px/32 KiB; download HTTPS de CDN permitida, sem bearer, redirecionamento ou URL arbitrária. |
| 19(5), diagnóstico de supressão | Erro 10 com mensagem exata de audiência insuficiente vira `provider_suppressed`, valor null; códigos genéricos não são tratados como comprovação de limiar. Expiração de Story e revogação da conexão mantêm distinção anterior. | `empty_or_suppressed` em follows não prova público abaixo de 100; diagnóstico preserva causa não confirmada quando falta evidência. |

**Retenção também das funcionalidades existentes:**

| Dados | Política entregue |
|---|---|
| Conexões novas e já existentes | Padrão unlimited; migração inicial amplia conexões existentes. Escolha futura deliberada de prazo finito para métricas continua disponível. |
| Coletas/jobs completos, parciais ou cancelados; resultados e histórico | Sem expiração automática. Registros ainda presentes têm expires_at ampliado para zero. |
| Auditoria administrativa, commits de conexão e worker | Sem expiração automática, substituindo a janela de 30 dias. |
| Exportações de coletas e de histórico, inclusive partes | Sem expiração automática, substituindo a validade de 24 horas. Exportação antiga retida continua legível sob autorização atual. |
| Arquivo privado de Stories | Sem expiração por idade e sem teto total de quantidade ou armazenamento; limites por imagem permanecem. |
| Metadados mínimos de primeira mensagem e recibos | Sem expiração e sem teto total de candidatos. Não passa a guardar todo o chat. |
| Cursores, confirmações, prévias, tokens e quota | Mantêm prazos e limites técnicos/de segurança. Não são tratados como histórico a preservar. |

A ampliação não recupera registros já apagados nem concede acesso a dados órfãos. O histórico normalizado continua representando o valor mais recente por chave lógica/período; páginas brutas de resultados das coletas permanecem retidas. Não foi criado um histórico de cada edição de configuração, nem ampliado o escopo para texto/anexos das conversas. Exclusão administrativa e processos de privacidade continuam decisões explícitas do responsável.

Correção funcional feita antes de instalar a 0.11.0: thumbnails já pequenas passam diretamente ao reprocessamento, evitando erro do editor WordPress ao tentar redimensionar sem necessidade. No patch 0.11.1, **nenhum código funcional, JavaScript, CSS ou schema mudou**: somente Config/cabeçalho, documentação instalada/compilada e manifestos. A comparação normalizada está em `evidence/patch0111-diff.json`; a comparação contra a base em `runtime-diff0111.json`.

Referências primárias consultadas: documentação Meta de [webhooks Instagram](https://developers.facebook.com/documentation/business-messaging/instagram-messaging/webhooks), [conversas](https://developers.facebook.com/documentation/business-messaging/messenger-platform/conversations), [ig.me](https://developers.facebook.com/documentation/business-messaging/instagram-messaging/features/ig-me-links), [exemplos](https://developers.facebook.com/documentation/instagram-platform/webhooks/examples), [insights de mídia](https://developers.facebook.com/documentation/instagram-platform/reference/instagram-media/insights) e [insights da conta](https://developers.facebook.com/documentation/instagram-platform/api-reference/instagram-user/insights). Algumas aberturas completas retornaram 429; foram usados também trechos indexados, sem afirmar leitura integral de páginas bloqueadas. Os testes de Graph são sintéticos; o aceite real permanece pendente.

## 4. Instalação, testes e prontidão

Laboratório descartável no Site-Teste, com tabelas/prefixo/diretório próprios; não foi apagado o banco compartilhado. HTTP de fornecedores e e-mail bloqueados nos ambientes de teste. WordPress real, banco MySQL 8.0.41. A prova mínima final foi executada após reinstalação limpa com **WordPress 6.4 e PHP 8.1.2-1ubuntu2.28**, não com o PHP 8.1.34 usado apenas na preparação.

| Prova | Versão exercitada | Resultado e evidência em evidence/ |
|---|---|---|
| Lint de todos os PHP + sintaxe JS | 0.11.1, PHP local 8.3.6 | 27 PHP válidos; admin.js válido |
| Instalação limpa, REST/admin/subscriber e 21 documentos | 0.11.1, WP 7.1.3/PHP 8.3.36 | 28/28, patch0111-current-isolated0111-smoke.json |
| Mensagens, webhook, insights, arquivo, retenção e exportações | 0.11.1, WP 7.1.3/PHP 8.3.36 | 77/77, patch0111-current-release0110.json; inclui miniatura real com editor GD/Imagick |
| Instalação limpa no mínimo exato | 0.11.1, WP 6.4/PHP 8.1.2 | 28/28, patch0111-minimum-isolated0111-smoke.json |
| Funcionalidade no mínimo exato | 0.11.1, WP 6.4/PHP 8.1.2 | 75/75, patch0111-minimum-release0110.json; duas provas de imagem ausentes por não haver editor nesse runtime, com diagnóstico explícito testado |
| Atualização direta 0.10.1 → 0.11.1 | WP 7.1.3/PHP 8.3.36 | 9/9, patch0111-upgrade.json; dados e opções preservados, exceto ampliação intencional de prazos/política |
| Integração com os cinco acompanhantes | 0.11.1, WP 7.1.3/PHP 8.3.36 | 22/22, patch0111-integrated-integration0110.json |
| Metadados, autorização, documentação paginada e UI MCP | 0.11.1 com acompanhantes | 121/121, patch0111-integrated-release090-metadata.json |
| Identidade/Story/alertas anteriores | 0.11.0 funcionalmente idêntica ao patch | 41/41, current-release0100.json |
| Credenciais, CAS, transação, rollback e troca guiada | 0.11.0 com acompanhantes | 55/55, integrated-release090.json |
| Worker/fila; health/recuperação; corrupção/quarentena | 0.11.0 com acompanhantes | 30/30, 23/23, 11/11 em integrated-release060.json, integrated-release070.json, integrated-review071.json |
| Painel de credenciais e novas funções | HTML WordPress da 0.11.0 + jsdom 27.4.0 | 25/25 e 17/17 em dom-credentials0110.json e dom-features0110.json. REST simulado; não é inspeção visual em navegador |
| Site-Teste compartilhado após instalação | 0.11.1 | health ok, 8 autotestes locais, 21 documentos completos iguais ao instalador, patch0111-mcp-docs.json |

Os testes cobrem assinatura falsa, alvo incorreto, replay, echo, origem desconhecida, referral posterior que não altera origem inicial, paginação longa, cursor vinculado/expirado, permissão e principal revogados, consumidor ausente, recibo incerto/tombstone, acesso de assinante negado, SSRF e limites de miniatura, leitura após expiração do Story, preservação por idade/quantidade, exportações legadas e atuais. O teste final de 77 verificações registrou 71 chamadas HTTP sintéticas e dois callbacks sintéticos; **zero chamadas reais à Meta, contatos reais ou e-mails**.

Ajustes de fixtures durante a rodada corrigiram contagens antigas de operações/documentos, reutilização de usuário/e-mail e chave ausente em fixture de registro; os resultados finais acima passaram. Evidências de desenvolvimento/pré-retenção e releases antigas são identificadas como históricas no fonte. Não devem ser confundidas com a matriz final.

**Instalação compartilhada:** primeiro 0.10.1 → 0.11.0, operação `3ce80c91a538fda0a2027baa`, backup `21f9179dabe1b83c5f245bdd`. Depois 0.11.0 → **0.11.1**, operação `df0cda0c4cdb5fd13570d82c`, operação de pacote `9a3b00b5c26fda99db26fa2556471745`, backup `2e58432628ad54c1672f65d8`. Upload com expected_sha256 e expected_slug, reativação silenciosa em requisição PHP nova. Sondas home/REST retornaram 200 antes/depois, com cache bypass verificado. São sondas same-origin, não prova de acesso externo nem de prontidão comercial.

Estado final: Meta 0.11.1 ativo; health ok, issues vazio, storage/crypto disponíveis, fila sem migração pendente/ilegíveis; zero conexões e zero agendas ativas no site compartilhado. Core 1.55.0, MCP 0.33.0, Google 0.19.0, LinkedIn 0.10.1 e Pipedrive 0.1.0 continuam ativos e inalterados. DreamHost 1.0.0, WP Super Cache 3.1.4 e Yoast 28.7 mantiveram seus estados.

Os três laboratórios do patch foram removidos: 89 tabelas do integrado, 14 do upgrade e 14 do mínimo; nenhuma tabela própria restante, diretórios e manifestos removidos. MU temporário `f3-meta-qa0111.php` excluído com verificação de hash, operação `4c0f156d3911dfa2ad875933`; o laboratório 0.11.0 também foi removido. Recursos de recuperação preexistentes não foram alterados. Evidências de instalação/limpeza estão no fonte, sem dados de login.

## 5. Banco e reversão

Mantidos schema 2 da tabela cifrada de registros e schema 1 do histórico. Novos buckets na tabela existente: `messaging_config`, `message_event` e `story_archive`. Não há tabela nova. Marca `f3_meta_retention0110` controla a ampliação da retenção na primeira carga da série 0.11. A rotina usa travas e só registra conclusão após sucesso; manutenção executa a migração antes da limpeza. Falha permite retomar em outra carga. Conexão ilegível exige recuperação da chave para completar a política.

Conexões existentes mudam para unlimited; a revisão aumenta quando a política muda. Credenciais, escopos, geração, autorização, ativos e agendas são preservados. Expiração de dados históricos retidos, inclusive órfãos, vira zero; isso não lhes concede acesso. A quarentena de fila ilegível continua sem reescrever payload/revisão/datas. A ampliação de retenção é uma mudança de dados solicitada, não uma regressão.

Antes de instalar: backup de arquivos, banco e salts; conferir hash; usar somente o instalador, sem desinstalar. Após instalar, conferir versão em PHP novo, health/selftest e documentação. Instalação direta da 0.10.1 é suportada pela prova desta rodada. Não é necessária troca dos acompanhantes para leitura/insights/arquivo; criação de contatos exige implementação futura do consumidor Core.

Voltar de 0.11.1 a 0.11.0 apenas restaura identificação/documentação anterior, sem reversão de dados. Voltar à 0.10.1 remove novas interfaces: desligar recepção/contatos, remover assinatura no painel Meta e parar agendas novas antes. Buckets permanecem, mas a base não os administra. Restaurar arquivos **não restaura os prazos finitos**, não desfaz contatos eventualmente criados pelo Core e não substitui backup coordenado. Desativação/desinstalação preserva dados e remove eventos próprios. Não restaurar banco antigo por cima de coletas em andamento.

## 6. Pendências

| Pendência | Responsável e condição |
|---|---|
| Acesso avançado Instagram Messaging, produtos/permissões e token novo | Dono/operador Meta: concluir App Review e conceder escopos/ativos; estado declarado não é prova de aprovação. |
| Conversas de um dia comparadas com caixa real em ctooffice | Dono/operador após autorização; não feito porque Site-Teste está sem credencial real e a rodada não autoriza produção. |
| Core309 / criação opcional de contato | Mantenedor Core: implementar consumidor, recibos, dedupe, consentimento/privacidade e tombstones, validar com Meta. Ver impacto específico. Permanece desligada. |
| Story novo antes/depois do vencimento, post com profile_visits e diagnóstico real de follows | Operador com ativo autorizado; fixtures não comprovam disponibilidade da métrica na conta real. |
| Aceites reais anteriores de credenciais/troca/rotate-token/exportação/aviso | Pendência 20 recebida na aba; não encerrada por esta rodada. Envio real de e-mail não executado. |
| Implantação na frota e publicação raw | Dono/mantenedor da frota: receber artefatos, conferir SHA-256 e seguir processo do projeto. Nenhum push ou deploy fora do Site-Teste foi feito. |
| Funções comerciais completas dos acompanhantes e cargas de produção | Não avaliadas além das fronteiras testadas. Retenção ilimitada aumenta o volume; consultas mantêm paginação e limites, mas não se declara benchmark de banco de grande porte. |

Não foi encontrada regressão no escopo testado. Essa conclusão não significa ausência universal de impacto: a ampliação intencional da retenção muda a política dos dados, e a integração comercial tem dependência concreta no Core.

## 7. Credenciais

Nenhum token real foi recebido, criado, extraído ou incluído nos artefatos. Site-Teste compartilhado possui zero conexões Meta. Testes usam identificadores, tokens e secrets sintéticos dentro de laboratório isolado, com tráfego externo bloqueado.

Configuração real permanece responsabilidade do operador: token manual do Facebook Login, app/secret e ativos selecionados; permissões de mensagens e produtos correspondentes devem ser concedidos e verificados. Page token derivado não é persistido pelo fluxo de mensagens. Segredos não são devolvidos na configuração, documentação ou recibos. Preserve salts/chaves do WordPress para continuar lendo os dados cifrados.

## 8. Arquivos finais

| Arquivo | Bytes | SHA-256 |
|---|---:|---|
| wp-mcp-meta-fator3-0.11.1-instalador.zip | 235017 | `b084bf2498eddc0eb93410c04efdd166ba84b2831541e2b5a2acf8dcfe3aa6c1` |
| wp-mcp-meta-fator3-0.11.1-fonte.zip | preenchido no relatório externo após fechamento | preenchido no relatório externo após fechamento |

O instalador tem raiz `wp-mcp-meta-fator3/` e é o único ZIP instalável. O fonte tem raiz `wp-mcp-meta-fator3-0.11.1-fonte/`, inclui código canônico/build, runtime idêntico ao instalador, testes, entradas, planejamento, evidências sanitizadas e esta cópia anterior ao fechamento. Nenhum ZIP contém outro ZIP da entrega.

Relatório principal externo: `wp-mcp-meta-fator3-0.11.1-relatorio.md`. Único complemento de encaminhamento: `wp-mcp-meta-fator3-0.11.1-impacto-base-site-core-fator3.md`. O relatório externo registra a identidade final do fonte sem circularidade. Não foram gerados impactos para simples resposta, aceite ou encerramento.
