# Impacto de Fator3 MCP Meta 0.7.1 em Fator3 MCP LinkedIn

Estado vigente: **encerrado na revisão 4**, abaixo. As revisões anteriores ficam preservadas como histórico.

Revisão 1 · 23/10/2026 · planejamento · situação aberto · alerta-tecnico / validacao-coordenada.

Emissor: Meta 0.7.0 → 0.7.1 prevista. Instalador alvo ainda não gerado. Destinatário examinado: LinkedIn 0.8.0, SHA-256 035a84fea5a02480c933c626cda994c49e58649ab4fb192f90b1f526238e8c35. Base Meta 0.7.0: SHA-256 727fab33a1b8e43c2d8980a1b6ca8deb8af39762b334ac1f524471f9d6bbfaa8.

## Consequência e correção proposta

A revisão própria reproduziu no Meta 0.7.0, em WordPress real, 20 jobs queued já indexados com ciphertext ilegível ocupando continuamente os 20 candidatos; um job válido continua queued após duas passagens. Queue::migrate isola somente projeções vazias, e Jobs::tick não retira os jobs ilegíveis já projetados. O código comum Query.php/Queue.php/Support.php é compartilhado em texto com LinkedIn 0.8.0; a consequência no LinkedIn é uma inferência da implementação comum, não uma prova executada no seu domínio nesta revisão.

Além disso, a retenção marca unreadable após liberar a trava do job, sem conferir a revisão/payload; uma gravação concorrente pode receber projeção incorreta. A proposta no Meta é centralizar o isolamento em Queue::isolate, sob trava do job, relendo o ciphertext e usando CAS de revisão e payload exato. Worker, migração e retenção reutilizam essa guarda. Sem mudança de schema, ID público ou autorização; o payload ilegível é conservado.

## Ação do responsável

Mantenedor LinkedIn: conferir se a versão corrente mantém o mesmo comportamento, reproduzir o cenário de 20 jobs ilegíveis seguidos de um válido e incorporar a guarda equivalente quando aplicável. Validar também falha transitória de banco e alteração concorrente: nenhuma delas pode isolar um job legível. Nenhuma alteração no pacote LinkedIn foi feita por esta tarefa. Documento preparado, não enviado.

## Validação prevista

No Meta: falha reproduzida na 0.7.0, aprovação na 0.7.1; preservação de ciphertext/revisão/timestamps/retenção, CAS, fluxo de fila e diagnóstico. Registrar identidade final e resultado na revisão de entrega. Sem homologação de API social real. Não é necessária ordem de troca entre os pacotes.

## Revisão 2 — documento LinkedIn 0.8.1 recebido em 23/10/2026

Etapa: implementação. Situação: alinhado quanto aos dois defeitos comuns; validação do Meta pendente. A revisão 1 acima registra o planejamento anterior à chegada desse documento.

O impacto LinkedIn 0.8.1 → Meta (revisão 1, SHA do instalador declarado 172081883af66b8c4b61676396d85066d4be0778b7ca06fb22262b30a4d2374a) informa correções equivalentes de fila e diagnóstico. Portanto, a solicitação anterior de incorporar essas duas correções no LinkedIn deixa de ser uma nova demanda: já consta como atendida pelo mantenedor de origem. Seus testes não foram repetidos por esta revisão.

Resposta do Meta: ambos os defeitos foram reproduzidos no Meta 0.7.0, instalador SHA-256 727fab33a1b8e43c2d8980a1b6ca8deb8af39762b334ac1f524471f9d6bbfaa8. Na sonda própria, 3 de 5 verificações falharam (health, status e avanço de fila), com zero chamadas de fornecedor e zero e-mails. Evidência: evidence/review071/site-review070.json. A candidata 0.7.1 trata os dois pontos e acrescenta guarda de revisão/payload na retenção. Seu instalador tem SHA-256 0adbea179f3a89cd66b6dce289fa8658e1723f4a9b38568794fc7c3aea5963f2, 150734 bytes. Ainda falta executar os testes da correção; não se encerra o aceite do Meta.

A proteção concorrente na retenção permanece como orientação de conferência, não como falha confirmada na versão LinkedIn 0.8.1, cujo código não foi examinado nesta revisão. Nenhum patch integral do template LinkedIn foi copiado; R4 e CAPI R3 específicos do LinkedIn não foram transferidos. Não há exigência de troca coordenada dos plugins nem novo ticket atribuído.

## Revisão 3 — entrega de 23/10/2026

Etapa: entrega. Emissor efetivo Meta **0.7.1**, instalador `wp-mcp-meta-fator3-0.7.1-instalador.zip`, 150734 bytes, SHA-256 `0adbea179f3a89cd66b6dce289fa8658e1723f4a9b38568794fc7c3aea5963f2`. Destinatário efetivamente instalado e examinado: **LinkedIn 0.8.1**. Classificação: `alerta-tecnico`; situação: resposta Meta concluída para R1/R2, avaliação pelo mantenedor LinkedIn aberta quanto à concorrência. Ticket: não atribuído.

**Resposta ao impacto recebido:** R1/R2 do documento LinkedIn correspondem, respectivamente, a R2/R1 das provas Meta. A reprodução própria na 0.7.0 falhou nos três resultados esperados (health, status e progresso da fila). Na 0.7.1, as 11 verificações adversariais passaram no Site-Teste e foram repetidas em WordPress limpo 7.1.3/PHP 8.3.36 e WordPress 6.4/PHP 8.1.34. Incluem vinte jobs cifrados ilegíveis seguidos de job válido, preservação dos bytes e revisão, falha transitória de armazenamento, conflito de revisão e trava real de outra conexão MySQL. As demais regressões, permissões e atualização completam 392 verificações próprias, sem falhas no candidato. As correções R1/R2 solicitadas ao Meta estão atendidas; não se atribui esse resultado aos testes declarados pelo LinkedIn.

**Achado complementar após examinar os bytes da 0.8.1 instalada:** `Queue::migrate` ainda marca a projeção ilegível sem a trava individual do job e sem comparar revisão/payload. Em `Store::prune`, o catch fica fora de `Store::lock`, e o UPDATE da projeção usa somente bucket e chave. Uma gravação concorrente após a leitura ilegível pode deixar um registro agora legível com projeção `unreadable`. A constatação é de revisão estática dessas rotas; não houve reprodução concorrente no domínio LinkedIn nesta tarefa. Não se generaliza o achado à rota do worker, cuja trava do chamador precisa ser considerada.

Evidências de leitura: `evidence/review071/linkedin081-queue-reviewed.json` (Queue.php, 5878 bytes, SHA-256 `aa8c9b6b42bc4a918abd50c64ee86c0c247e846cae451f4c1f473e475aacc9f3`) e `linkedin081-support-reviewed.json` (conteúdo integral de Support.php). Essas leituras atualizam a limitação da revisão 2, quando o código da 0.8.1 ainda não havia sido examinado.

**Ação do mantenedor LinkedIn:** reproduzir a concorrência na migração e retenção e, se confirmada, centralizar o isolamento com releitura sob `job:<id>` e UPDATE condicional da mesma revisão/ciphertext. Aceite: uma revisão nova legível não pode ser isolada; falha transitória do banco deve propagar sem quarentena; trava ocupada não autoriza alterar projeção; bytes cifrados, revisão, timestamps e retenção devem permanecer intactos. Usar `tests/native/review071.php` do fonte Meta como referência adaptada, sem copiar o template inteiro.

Não há mudança de SDK público, schema, IDs, autorização ou necessidade de troca coordenada. Core, MCP e Google não receberam mudanças nem novos encaminhamentos sem consequência técnica. R4 de agenda e R3 CAPI específicos do LinkedIn não foram transferidos. Documento entregue ao dono, sem mensagem externa e sem declarar concluída a manutenção do destinatário.


## Revisão 4 — encerramento durante a entrega Meta 0.8.0

23/10/2026 · entrega · situação **encerrado**. Mantida a identidade da emissão original Meta 0.7.1; não se cria impacto novo apenas para anunciar versão. Destinatário atual: LinkedIn 0.9.0, instalador 236277 bytes, SHA-256 `d4857927ebacfca9321b79d13bc15f15c6969ae67047fd1793e509524b7a60f8`.

A revisão 2 do documento recebido LinkedIn 0.8.1 → Meta encerra R1/R2 pela resposta do Meta e informa que o alerta inverso de concorrência virou **pedido LinkedIn 12**, atendido na 0.9.0. A revisão estática própria da 0.9.0 confirma `Queue::isolateUnreadable` com trava individual, decodificação do mesmo payload usado no CAS de revisão/cifra, além da reutilização por migração e retenção. Os testes específicos de LinkedIn são provas recebidas de seu mantenedor; não foram reexecutados por esta rodada Meta. A verificação própria de convivência confirmou os 59 arquivos do runtime LinkedIn instalado iguais ao pacote recebido, sem divergências.

Na revisão da fronteira, foi encontrado um caso mais estreito ainda presente no Meta 0.7.1: duas leituras podiam discordar se um gravador externo alterasse e restaurasse exatamente revisão/ciphertext entre elas. A 0.8.0 passou a decidir pelo snapshot único, preservando o CAS existente. A 0.9.0 do LinkedIn já adota essa abordagem; não há nova ação para o destinatário. O gravador normal do Meta não reduz revisão; a reprodução usa restauração externa determinística, não demonstra frequência em produção.

Aceite próprio Meta: oito verificações do snapshot e onze regressões adversariais passaram no Site-Teste integrado e no WordPress 6.4/PHP 8.1.2; a atualização direta 0.7.1 → 0.8.0 preservou dados de negócio. Instalador Meta 0.8.0: 153819 bytes, SHA-256 `36e4e098955576c3d43ea1b1bd2c14fe68608472b8666a652e84da5165ce25e1`. Evidências: `evidence/release080/negative071.json`, `r080-site-snapshot.json`, `r080-site-review-final.json` e `r080-site-companions.json`.

Não há mudança de contrato público, ordem obrigatória de troca ou ação pendente deste encaminhamento. Encerramento documental baseado na resposta recebida e inspeção própria, sem declarar outros itens do backlog LinkedIn concluídos. Documento entregue ao dono, sem envio a terceiros.
