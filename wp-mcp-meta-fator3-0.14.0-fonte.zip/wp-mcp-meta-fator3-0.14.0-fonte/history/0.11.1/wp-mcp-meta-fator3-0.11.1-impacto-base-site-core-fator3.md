# Impacto de Fator3 MCP Meta 0.11.1 em base-site-core-fator3

26/10/2026 · Revisão 3 · Etapa implementação · Situação demanda-aberta · Classificação **acao-necessaria**.

Emissor: mantenedor Meta. Base aceita Meta 0.10.1; alvo **0.11.1 previsto**, instalador ainda não fechado. Destinatário: mantenedor Site Core; versão examinada **1.55.0**, instalador SHA-256 `1d7e54fb86ea4c61de5e58df22e81b5e93aad3018bc5802fb3fd86ff48dd41a0`. Pedidos existentes: **MCP Meta 18(b)**, com referência do pedido recebido a **Core 309**; sem novo ID inventado.

## Consequência e pedido

O Meta passa a receber metadados mínimos de mensagens Instagram e referências verificadas por assinatura. A entrada opcional da primeira mensagem como contato depende de política e consumidor do Core. O Core 1.55.0 publicado não possui esse consumidor; sua ability `f3base/contato-externo-registrar` (pedido 302) representa registro administrativo/manual, sem identidade Instagram nativa ou deduplicação comercial por remetente. Não será usada como substituição silenciosa do fluxo 309.

Solicita-se ao Core implementar/validar o consumidor do contrato local **`instagram-first-message/1.0.0`**, com ativação explícita por conexão/ativo e desligada por padrão. O Meta será responsável pela assinatura, seleção do ativo, paginação/evidência da primeira mensagem disponível, projeção mínima, checkpoint, limite de tentativas e idempotência de entrega local. Core mantém criação/classificação de contato, consentimento/privacidade, deduplicação comercial, avisos e Pipedrive.

O evento proposto contém event_id/idempotency_key estáveis, connection_id, account_id, sender_id escopado, message_id, primeira data disponível, data observada, origem e referências fornecidas (Story/ad_id/ref/source/type), cobertura e origem da prova. Não contém texto, anexos, token, email/telefone inferidos ou UTM inventada. Ausência de referência não equivale a espontâneo. O Core não deve atribuir sessão, anúncio ou post por proximidade temporal.

A API de conversas pode omitir pedidos sem atividade por 30 dias; “primeira disponível” não comprova primeiro contato de toda a vida. O consumidor deve aceitar essa cobertura explícita e não converter evento antigo/backfill em nova captura automática. O Meta não despacha enquanto o consumidor compatível não se registrar e a opção local não estiver autorizada. Em remoção/revogação do consumidor, interrompe novas entregas.

## Contrato e aceite esperado

O SDK e exemplos estão em `docs/INSTAGRAM-MESSAGING.md` do Meta. Registro local com contrato/versão e callback; apenas um consumidor `site-core` ativo. Callback recebe somente evento mínimo; o Meta preserva e revalida o principal internamente e retorna recibo mínimo `persisted=true`, record_id e chave idempotente correspondente, ou recusa/resultado incerto explícito. Incerteza não autoriza repetição automática. O Core deve usar o mesmo identificador para reconciliar, inclusive após reinício, e impedir reimportação de contato eliminado conforme sua política de privacidade.

Aceites coordenados: desligado por padrão; sem consumidor não grava contato; evento válido novo gera no máximo um contato; replay e reentrega não duplicam; conta/conexão diferente não se mistura; echo/saída e mensagem anterior à ativação não captam; retirada de permissão interrompe; resultado incerto exige reconciliação; eliminação impede reimportação; texto/credenciais ausentes da auditoria. Testes com fixtures e destinos de homologação. A homologação externa depende do dono aprovar `instagram_manage_messages` e fornecer token com escopos adequados.

Este documento apresenta uma dependência e pedido ao Core. Não afirma implementação do Core309, não encerra pedidos e não foi enviado a pessoas ou sistemas. A implementação autônoma de leitura/insights/arquivo de Stories no Meta pode ser entregue com a integração comercial explicitamente indisponível até o aceite do consumidor.

## Refinamento substantivo do contrato — revisão 2

Registro por hook f3_meta_register_messaging_consumers; SDK Fator3\Meta\Messaging. O principal não é entregue ao consumidor. Reservas são duráveis; callbacks sem recibo conclusivo ficam uncertain, sem repetição. Reconciliação administrativa usa deliveryReceipt e reconcileReceipt com revisão esperada; permite persisted com recibo real ou suppressed para impedimento de reimportação, nunca novo callback automático. Core deve guardar sua deduplicação/tombstone independentemente da retenção e de eventual limpeza administrativa do diário Meta. Os eventos trazem primeira disponível com histórico vitalício não comprovado. Essas definições refinam a implementação solicitada ao Core; não representam aceite ou encerramento.

## Alteração substantiva — revisão 3, retenção solicitada pelo responsável

O diário mínimo de mensagens/recibos passa a ser mantido sem expiração automática nem limite total de candidatos. O Core deve definir exclusão e impedimento de reimportação de forma coordenada, inclusive para metadados correspondentes no Meta, quando seu processo de privacidade exigir eliminação. A maior retenção não autoriza guardar texto do chat nem inferir consentimento. Manter a deduplicação própria durável: a ausência do diário após limpeza/reinstalação não prova ausência de contato anterior.
