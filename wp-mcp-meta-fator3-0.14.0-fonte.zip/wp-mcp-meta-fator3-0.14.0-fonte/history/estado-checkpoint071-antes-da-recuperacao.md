# Estado da revisão — Meta 0.7.1 candidata

Data: 23/10/2026. Trabalho interrompido por indisponibilidade do canal de administração do Site-Teste. Não é relatório de entrega nem homologação.

## Bases e documento adicional

Meta 0.7.0 recebido: instalador de 145728 bytes, SHA-256 727fab33a1b8e43c2d8980a1b6ca8deb8af39762b334ac1f524471f9d6bbfaa8. Build reproduzido byte a byte. Comparado com Meta 0.6.0, SHA-256 36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69. Documento LinkedIn 0.8.1 recebido e preservado em inputs/0.7.1; seus R1/R2 correspondem aos dois defeitos comprovados no Meta.

## Evidências próprias

Site-Teste: WordPress 7.1.3 / PHP 8.3.36, MCP 0.28.0, Core 1.48.0, Google 0.17.0, LinkedIn 0.7.0. A instalação de Meta 0.7.0 sobre 0.6.0 passou com probes home/REST HTTP 200. A sonda sobre 0.7.0 executou 5 verificações, com 3 falhas: health e status retornam cipher_unreadable ao ler last_job; vinte jobs ilegíveis permanecem executáveis e impedem o job válido após duas passagens. Os dois controles de efeitos/preservação passaram. Zero HTTP de fornecedor, zero e-mails. Dados sintéticos da execução foram limpos no finally.

## Correções preparadas

Queue::isolate usa a trava do job, nova leitura e atualização condicional por revisão e payload binário. Worker, migração e retenção usam a guarda; ciphertext, revisão, datas e retenção permanecem preservados. Health informa schedule_job_unreadable sem quebrar o diagnóstico; status mantém sua recuperação explícita. Documentação instalada atualizada. Nenhum contrato público ou schema alterado.

## Incidente e estado do Site-Teste

Na troca para 0.7.1, a sonda temporária instalada por esta revisão acessou Config durante registro de abilities, quando o Meta estava temporariamente inativo. A ativação retornou HTTP 500. Os arquivos foram aplicados; o retorno declarou active=false e verification_pending. O conector passou a retornar erro interno, inclusive para remover a sonda. Esse incidente pertence ao mecanismo de teste, não é prova de falha do runtime candidato.

Arquivo a retirar: wp-content/mu-plugins/f3-meta-review071-qa.php. SHA-256 remoto conhecido: 9bc7bd359eb42465397acda3dddb1df0cb38727435da5e864ce4036f94011fb1. O arquivo local tests/site/meta-review071-qa.php já contém class_exists antes de acessar Config; essa guarda ainda não chegou ao servidor. A sonda também mantém interceptação restrita a um ativo sintético e a avisos operacionais do Meta enquanto permanece instalada; precisa ser removida.

Operação do pacote: 3c05de7665aff130cd226dc329be6b0c. Execução: 800ff0ebab3a4ae6e49db622. Backup de 0.7.0: 30a6e1d56ff784d097e1c54e. Não repetir upload incerto. Recuperar o acesso administrativo, remover a sonda, conferir plugins/operation-status e reconciliar plugins/reconcile com esse identificador. Reativar Meta conforme o estado observado. Em seguida conferir home, REST, saúde e inventário.

## Pendências de validação

Executar as 11 verificações preparadas para 0.7.1, inclusive outra conexão MySQL segurando a trava, falha transitória, CAS e JSON malformado. Rodar regressões, documentação MCP e autorização; confirmar limpeza da sonda e estado final. Instalação limpa e runtime mínimo continuam pendentes: laboratório local não iniciou porque criação de socket foi bloqueada. Aprovação automática rejeitou a tentativa de escalada; nenhum contorno foi executado. Lint não comprova esses testes.

## Entrega

O instalador candidato de 150734 bytes tem SHA-256 0adbea179f3a89cd66b6dce289fa8658e1723f4a9b38568794fc7c3aea5963f2. Não está homologado, e a 0.7.0 não foi aceita sem correções. Este checkpoint conserva fonte editável, runtime, testes, documentos e evidências sanitizadas, sem ZIPs aninhados, banco ou segredos. Os três artefatos finais só serão fechados após a revisão e a recuperação.
