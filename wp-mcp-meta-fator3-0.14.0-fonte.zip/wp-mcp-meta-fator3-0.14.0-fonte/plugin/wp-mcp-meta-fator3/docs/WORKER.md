# Coletas, recuperação e alertas — 0.13.0

Histórico e comportamento atual das coletas: Pedidos MCP Meta 13, 14 e 17. O catálogo atual tem 41 operações públicas: 35 anteriores e seis acrescentadas na série 0.11. A série 0.10 acrescentou `label` opcional à entrada de `meta/switch-identity`.

## Estado e efeitos

`meta/status` exige administrador e, pelo MCP, perfil maintenance ou custom com a operação autorizada. Os perfis read/content não permitem esta escrita local. Metadados: mode=write, readonly=false, local_effect=write, remote_effect=none. O estado observado aparece em `state` (ok/degraded), `issues`, `observed_at` e `cron.observed_next`. Se faltar evento e houver agenda ativa, coleta queued/retry (inclusive futura) ou migração pendente, tenta rearmar o worker. `recovery.attempted/scheduled/code` e `cron.next` mostram o resultado, sem ocultar a degradação inicialmente observada. A consulta seguinte pode retornar ok. Não executa uma coleta, não muda o proprietário de agendas e não consulta o fornecedor; também mantém a auditoria local existente. O efeito de reparo é exceção explicitamente solicitada à regra comum de diagnóstico somente leitura.

`queue.oldest_due_lag_seconds` informa atraso em segundos da coleta queued/retry vencida mais antiga, ou zero sem vencidas; `oldest_due_at` é null sem vencidas. Durante a migração o atraso cobre apenas registros já indexados; `migration_pending=true` sinaliza cobertura incompleta. `audit_health` trata apenas auditoria e não substitui `state`.

A aba Diagnóstico carrega esse estado e contém botão para atualizar. Problemas mostram nome/ID da agenda, código e ação. Agenda ativa cujo next_at venceu há mais de duas vezes interval_minutes × 60 é degradada. Autorização recusada no last_code da agenda ou de sua última coleta também degrada. Falha local de concessão exige restaurar acesso administrativo ou salvar a agenda pela concessão válida. Revogação confirmada da conexão é agregada em `connection_authorization_failed` e exige renovar a credencial ou restaurar permissões do app, sem regravar individualmente as agendas. Recusa isolada de Story usa código próprio, sem alerta de autorização ou e-mail; consulte `COLLECTION-DIAGNOSTICS.md`. O alerta só desaparece quando a passagem seguinte comprova a retomada. Trocar concessão OAuth não transfere propriedade nem libera resultados antigos.

## Recuperação

Manutenção horária `f3_meta_maintenance` confere o evento antes da retenção e novamente ao sair. O worker pré-agenda a próxima passagem e repete a conferência em finally, inclusive após exceção. A gravação do evento usa retorno WP_Error e confirmação de presença; últimas tentativa/falha ficam em cron.last_schedule_attempt/last_schedule_failure, sem mensagens com segredos. A falha histórica permanece após recuperar, mas não mantém o estado degradado se o problema atual foi resolvido. Há trava de banco para impedir passagens concorrentes e outra para o reagendamento.

O cron precisa ser acionado pelo servidor ou tráfego. O watchdog horário é a recuperação programada até a próxima manutenção efetivamente executada, não uma garantia de relógio se todo o cron estiver parado. Uma nova consulta de status também pode recuperar. Verifique o agendador do servidor quando nenhum hook roda. WP-Cron usa uma lista global: escrita concorrente por código alheio ainda pode apagar um evento após a conferência; o watchdog reduz a falha persistente, sem prometer atomicidade global do WordPress.

## Fila e migração

Schema 2 adiciona `queue_state`, `queue_next` e índice `runnable(bucket,queue_state,queue_next,record_key)` na tabela de registros. Apenas estado técnico e vencimento ficam nessa projeção; consulta, resultado e identidade continuam cifrados. A mesma instrução CAS grava payload e projeção. O worker seleciona até 20 candidatos, por duas buscas indexadas limitadas (queued/retry), ordenadas por next_at e chave. Não percorre coletas concluídas. Revalida estado, prazo e autoridade sob a trava da coleta. Agendas vencidas são materializadas antes dessa seleção; orçamento de 22 segundos entre coletas, com orçamento HTTP de cada coleta preservado.

A base 0.5.0 é migrada em lotes de 100 registros por passagem/entrada durante o bootstrap, sem alterar ciphertext, revisão, retenção ou identidade. Registros novos entram imediatamente no índice; migração pendente mantém o worker necessário. Falha de cifra/banco não é convertida em sucesso: progresso para e diagnóstico segue degradado. Não apague registros para destravar; preserve banco e salts e corrija a causa. Retenção remove a projeção junto do registro, sem índice separado órfão.

## E-mail operacional

Worker e manutenção enviam problemas atuais (worker ausente, atraso de agenda, autorização) ao `admin_email` configurado em Configurações → Geral do WordPress. O status não envia e-mail. Conteúdo: endereço do site, nome/ID da agenda e ação; sem token, concessão opaca, payload ou dados coletados. Não há destinatário de cliente nem envio ao fornecedor. Uma trava e uma reserva persistida permitem uma tentativa por incidente ativo, inclusive quando o resultado do envio é incerto. O mesmo incidente não repete aviso na hora seguinte. Quando a recuperação é observada, a chave é encerrada; nova falha posterior permite outro aviso. `notification.state=accepted` significa que wp_mail aceitou, não entrega comprovada. `failed/sending` exigem conferir o serviço de e-mail. Não há confirmação de leitura ou retry imediato.

## Atualização e reversão

A base aceita desta rodada é a 0.12.0, com atualização direta para 0.13.0, sem nova tabela nem reescrita automática de conexões. Preserve banco e salts. Consulte MIGRATION.md para sequência e reversão. Voltar aos arquivos anteriores não desfaz essa ampliação nem efeitos já realizados.

Histórico 0.5.0 → 0.6.0: instale o ZIP 0.6.0 sobre a 0.5.0; não desinstale. Migração aditiva preserva dados. Backup de arquivos não cobre banco; guarde backup de banco e salts. Voltar aos arquivos 0.5.0 conserva colunas extras, mas perde fila indexada, alertas e recuperação. A 0.5.0 redefine seu marcador schema=1 no bootstrap; ao voltar à 0.6.0, projeções são reconstruídas e a migração pode ficar pendente. Não há promessa de execução de jobs durante downgrade; pause o cron durante a troca e verifique o estado depois. Nenhum rollback desfaz consultas/avisos já executados.

## Histórico — Mudanças da 0.7.0

`meta/health` devolve o mesmo estado observado (`state`, `issues`, `queue`, `cron`, `notification`) e ainda `maintenance.next/last` e `repair=not_attempted`. Não rearma eventos, não envia e-mail e não chama a Meta. Como toda operação despachada (exceto a leitura documental), grava uma linha no registro de auditoria local (`meta/audit`, retenção sem expiração automática) e mantém `f3_meta_audit_health`; não altera configuração, fila, agendas nem credenciais. O perfil read do MCP permite a chamada. Para recuperar, use `meta/status` (perfil maintenance ou custom com a operação) ou aguarde a manutenção horária.

A manutenção horária é conferida em `init` (prioridade 20): se `f3_meta_maintenance` não estiver no cron, é reagendada para 5 minutos depois, sob trava de banco; a opção `f3_meta_maintenance_rearmed` guarda o último reagendamento. Diagnóstico `maintenance_missing` enquanto o evento falta.

Migração da fila: registros de coleta ilegíveis recebem `queue_state=unreadable` e entram em `queue.unreadable_jobs` e na issue `queue_record_unreadable`; os demais seguem migrando em lotes de 100. Esses registros não são executados nem apagados automaticamente e saem da seleção da retenção, que continua para os demais (um registro ilegível encontrado pela retenção também é marcado `unreadable`). Confira as chaves (salts) do wp-config; restaurar a chave correta e reconstruir as projeções (troca de schema) devolve o estado real. Depois de confirmada a migração, a marca `f3_meta_queue_settled=2` (autoload) dispensa a consulta de migração; `f3_meta_schema` e `f3_meta_history_schema` também passam ao autoload na primeira requisição. Resultado: nenhuma consulta SQL própria do pacote no carregamento de uma requisição comum. Um retorno à 0.5.0 e nova atualização apaga a marca e reconstrói as projeções.

O e-mail operacional não inclui `queue_migration_pending`, `queue_record_unreadable` nem `maintenance_missing`.


## Correção 0.7.1 — registros ilegíveis

Jobs cujo ciphertext ou JSON interno não pode ser lido são isolados com `queue_state=unreadable`, sem reescrever payload, revisão, timestamps ou retenção. O worker trata também jobs já indexados; eles deixam de ocupar repetidamente as 20 posições executáveis. Migração e retenção usam a mesma trava e conferência de revisão/payload; registros legíveis, alterados concorrentemente ou com falha transitória de banco não recebem essa marca.

Se a agenda aponta para um job ilegível, `meta/health` e `meta/status` retornam diagnóstico degradado com `schedule_job_unreadable` e nome da agenda. Health continua sem reparo operacional e status mantém a recuperação explícita do evento. O aviso de ilegibilidade permanece no diagnóstico, fora dos avisos por e-mail. `queue_record_unreadable` informa a contagem já isolada.

A restauração dos salts ou a reparação de dados exige avaliação do administrador. Registros isolados não voltam automaticamente à fila e não são apagados pela retenção; não há reautorização ou exportação automática de conteúdo ilegível.

## Isolamento na 0.9.0

A rotina adquire a trava do job, lê revisão e payload uma vez, decodifica esse payload e compara os mesmos bytes/revisão no UPDATE. Não mistura a decisão de corrupção de uma segunda leitura com o snapshot da primeira. Isso protege inclusive o ciclo de alteração/restauração de um gravador externo que não respeite a trava consultiva. Apenas a projeção muda. O teste é sintético e não prova frequência desse cenário em produção.


## Histórico — Versão 0.10.0 — Pedidos MCP Meta 16 e 17

A prévia de troca de identidade aparece junto do formulário que a pediu; a origem Renovar token abre o bloco automaticamente. A prévia recebe foco e anúncio acessível. A recusa de identidade fica junto de Salvar conexão e aponta o botão de troca. `meta/switch-identity` aceita `label` opcional (até 120 caracteres): o nome é incluído na prévia (`connection_label`), vinculado à confirmação e salvo junto da credencial e das agendas na mesma revisão/transação. Sem label, preserva o nome salvo. Editar a candidata invalida a prévia; resposta assíncrona obsoleta não a reabre.

Stories indisponíveis têm códigos próprios; revogação da conexão exige confirmação independente. Agendas e auditoria guardam código Graph, subcódigo, HTTP e instante. O aviso passa a uma tentativa por incidente e mostra a causa medida. Consulte `COLLECTION-DIAGNOSTICS.md` para códigos, efeitos, recuperação, persistência e limites. Na série 0.10, os 35 IDs de operações foram preservados e label foi acrescentado a switch-identity. Na série 0.11, somam-se seis operações, totalizando 41.

## Preservação na série 0.11

A auditoria de chamadas, commits de conexão e worker é mantida sem expiração automática. Jobs completos, parciais e cancelados também; resultados/histórico usam unlimited por padrão e conexões existentes são ampliadas na primeira carga. Exportações deixam de vencer após 24 horas. Cursores, confirmações e quota mantêm seus prazos técnicos. Mensagens usam evento f3_meta_messages, somente com consumidor Core compatível e autorização explícita; não substitui o worker de relatórios. Leia RETENTION.md e INSTAGRAM-MESSAGING.md.

## Continuação de mensagens e privacidade

A eliminação administrativa na 0.12.0 retira continuações com cursor da conta afetada. O worker só agenda a continuação se a geração de privacidade ainda for aquela observada antes da consulta. Webhooks e entregas consultam o bloqueio sob a mesma trava; o bloqueio permanece mesmo após falha parcial. MESSAGE-PRIVACY.md descreve recuperação e limites.


## Pedido21 — coletas parciais na 0.13.0

Campos vazios/suprimidos, null e recusas específicas são diagnosticados individualmente; dados úteis dos pares permanecem. Zero é valor válido. Recusa de permissão por métrica só é localizada depois de conferir a conexão em /me; revogação global, quota ou transporte continuam interrompendo/retentando conforme seus códigos.

coverage acrescenta successful_rows acumulado, page_successful_rows e unavailable_metrics. Jobs acrescentam successful_rows, unavailable_metrics e outcome. Mantém status=partial terminal por compatibilidade quando há lacunas; outcome=failed distingue término sem nenhuma linha útil. Não houve sucesso só por gravar linhas com value=null. Agendas acrescentam last_run_status, last_successful_rows, unavailable_metrics e last_partial_at. last_success_at avança após persistência de linhas úteis (inclusive parcial); last_partial_at registra término parcial com dados. Falha global não se transforma em parcial. Health conta partial_schedules e failed_schedules separadamente entre agendas ativas; issue schedule_partial não dispara novo e-mail.

O workaround A-METASEG-2710 pode ser recomposto pelo operador da frota depois da implantação e conferência do recorte real; o pacote não altera agendas de produção automaticamente.
