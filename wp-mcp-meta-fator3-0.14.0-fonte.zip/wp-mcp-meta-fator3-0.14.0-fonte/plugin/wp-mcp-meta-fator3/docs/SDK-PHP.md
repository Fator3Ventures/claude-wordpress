# Integração local — Meta 0.13.0

Relatórios e exportações usam os contratos públicos REST/abilities, com administrador autorizado. O SDK local de mensagens é `Fator3\Meta\Messaging`, contrato `instagram-first-message/1.0.0`, com registro explícito do consumidor `site-core`. Leia INSTAGRAM-MESSAGING.md para evento mínimo, autorização, recibo, incerteza e reconciliação. Não leia tabelas cifradas, opções internas ou tokens por conta própria.

O Core 1.56.0 implementa o consumidor; a criação automática exige autorização explícita nos dois pacotes e permanece desligada por padrão. Core mantém ingestão, deduplicação comercial, consentimento, privacidade e avisos. O Meta não chama o registro manual de contato externo como substituto do contrato.

Pixel/CAPI e ingestão de Lead Ads continuam no Core; gestão/escrita de anúncios Meta fica no MCP oficial Meta. Leitura de Meta Ads e acervo diário estão neste pacote; consulte META-ADS.md e META-ADS-READER.md. Google mantém suas integrações. Não há exportação nova para Sheets/BigQuery nem migração Porter. Retenção máxima e prazos de segurança estão em RETENTION.md. A documentação local é lida por meta/documentation, com índice, paginação e integridade.

## Eliminação explícita na 0.12.0

O SDK Messaging acrescenta privacyContract, privacyStatus, eraseLocalData e erasureReceipt, contrato instagram-message-erasure/1.0.0. A eliminação administrativa solicitada prevalece sobre retenção ilimitada; bloqueios pseudônimos e recibos permanecem. Nenhum processo automático apaga dados nem habilita contatos. Leia MESSAGE-PRIVACY.md para revisão, autorização atual, falhas parciais, cron e preservação de chaves.


## Meta Ads na 0.13.0

Pedido20 inclui leitura Ads: seleção explícita/ads_read, dias completos no fuso da conta, acervo cifrado sempre sem prazo, agendas e CSV/JSON. Canal ads, relatório ads_insights, nível selecionável. Consumidores locais exigem registro e concessão explícita, desligada por padrão. Leia META-ADS.md e META-ADS-READER.md. Nenhuma escrita em anúncios, alteração do LinkedIn ou ingestão comercial implícita. Pedido21 distingue coleta parcial de falha em COLLECTION-DIAGNOSTICS.md.
