# SDK local meta-ads-reader/1.0.0

Somente acervo cifrado local, sem Graph ou token. O consumidor mantém sua seleção, regras comerciais, associação campanha/parceiro/contato e deduplicação. Não ler tabelas/options privadas nem chamar MCP para ler o próprio site. A disponibilidade do leitor não autoriza automaticamente um consumidor.

## Registro e configuração

Registrar durante o hook abaixo e guardar o objeto retornado no próprio consumidor. O objeto exato constitui o cliente registrado; um AdsReaderClient fabricado é recusado. Um ID só pode ser registrado uma vez por processo. Configuration retorna {connection_id:string, account_id:string, revision:int|string, ready:true}; revisão limitada a 128 caracteres, estável até a configuração mudar. O callback não deve fazer HTTP nem alterar estado. O consumidor deve expor sua seleção própria e devolver ready=false enquanto incompleto.

```php
add_action('f3_meta_register_ads_consumers', static function ($sdk, $contract) {
    if ($contract !== 'meta-ads-reader/1.0.0') return;
    MeuConsumidor::$metaAds = $sdk::register_consumer(
        'meu-consumidor', '1.0.0', $contract,
        static fn() => MeuConsumidor::configuracaoMetaAds(),
        'Meu consumidor de anúncios'
    );
}, 10, 2);
```

Administrador autoriza em Ferramentas → Fator3 MCP Meta → Consumidores de anúncios. Operações fechadas: ads-consumers({}) lista registrados e concessões; get-ads-grant({consumer_id,connection_id,account_id}) retorna revision/enabled; save-ads-grant acrescenta expected_revision (0 ao criar) e enabled boolean. A revisão não deve ser presumida. Revogar é possível mesmo com consumidor/conexão removidos. Os efeitos são locais; saves exigem escrita na política MCP. Recusa de concessão remota nunca vira sessão administrativa local.

## Leitura

`$client->status(['connection_id'=>..., 'account_id'=>...])` informa ready, versões de concessão/autorização/configuração e contrato. `$client->query(...)` aceita somente connection_id, account_id, ads_level opcional, date_from/date_to juntas e válidas, limit (1–100, padrão100) e cursor opcional. Não aceita escolha de outra conexão/conta além da configuração registrada. Resposta é envelope Meta {success, code, provider, version, data}; falhas têm dados nulos, código e mensagem sanitizados. Tratar envelope antes de usar linhas.

Data de query contém contract, rows (registros meta-history com row_id, row, data_day, first_seen, last_seen, observations, timezone/currency, selection e coverage), next_cursor, generation, retention e grant_revision. Ver META-ADS.md para métricas e last_available_fields. Preserve a seleção ao continuar; cursor inclui identidade do consumidor, revisão da concessão/configuração, autorização da conexão e geração do acervo. history_changed ou revision_conflict exige recomeçar uma leitura consistente, não concatenar conjuntos de gerações diferentes.

A origem administrativa da concessão deve continuar existindo e ter manage_options e concessão de transporte ativa, quando usada no consentimento. A conexão deve permanecer ativa e a conta selecionada; mudança de identidade/ativos exige revisão. Token vencido não impede leitura local concedida. Cliente registrado e concedido pode operar em cron sem usuário corrente; o SDK revalida origem/concessão/configuração antes e depois de ler. Revogar e reautorizar não revive cursores antigos. Leitura e falhas geram auditoria local sem payload de anúncios/credenciais.

Erros: consumer_unavailable, consumer_not_ready, contract_mismatch, consumer_conflict, consumer_scope_mismatch, grant_revoked, not_authorized, asset_access_denied, connection_paused, revision_conflict, history_changed, invalid_input, invalid_cursor/cursor_expired, storage_unavailable, response_limit. Não interpretar erro ou ausência como zero. Contrato aditivo, sem alteração de instagram-first-message/1.0.0, instagram-message-erasure/1.0.0, GA4 Reader ou LinkedIn Lead Reader.

O Core1.59.0 examinado registra esse leitor como base-site-core-fator3. Sua seleção fica em f3base_meta_ads e exige configuração/revisão e concessão explícita no Meta; instalar não concede acesso. f3base/meta-ads-status e f3base/meta-ads-relatorio-ler expõem a integração local. O histórico do pedido Meta20(e) consta do relatório principal. Critérios preservados: concessão explícita, leitura local paginada, IDs estáveis/moeda separada, atualização por substituição de observações revisadas e bloqueio de seleção/cursor revogados.
