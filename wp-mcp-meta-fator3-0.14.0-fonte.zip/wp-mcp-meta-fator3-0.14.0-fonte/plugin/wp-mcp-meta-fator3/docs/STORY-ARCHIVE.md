# Métricas e arquivo de Stories — Meta 0.13.0

Pedido MCP Meta 19. Catálogo 2026-10-26.1, Graph v24.0 como versão padrão. Campos catalogados continuam sujeitos ao ativo, tipo de mídia, permissões e disponibilidade do fornecedor.

## Métricas

| Relatório | Campos acrescentados | Detalhamento |
|---|---|---|
| stories_insights | follows, profile_visits, shares, total_interactions, link_clicks, profile_activity | profile_activity usa action_type; navigation usa story_navigation_action_type |
| media_insights | profile_visits, follows, profile_activity | profile_activity usa action_type; usar post/álbum pai |
| account_insights | reach/views já existentes | `breakdown=media_product_type`, explicitamente pedido, v24.0 |

Consultas de media_insights verificam proprietário. A captura pelo inventário percorre posts/álbuns da conta; não percorre filhos do carrossel como se fossem posts independentes. Se um filho for informado manualmente e o fornecedor recusar, preserva a recusa por métrica e orienta o álbum pai. Não substitui valores ausentes por zero.

`media_product_type` separa tipos de mídia, **não** comprova separação orgânico/anúncio. Buckets retornados são preservados, sem repartição artificial do total. Se o fornecedor devolver apenas total, a linha informa `breakdown_not_returned`. `profile_activity` e `navigation` usam consultas com seus respectivos breakdowns; grupos diários são separados por tipo de métrica/detalhamento.

A mensagem exata do fornecedor `(#10) Not enough viewers for the media to show insights` é classificada como supressão de Story, com valor null, sem concluir revogação da conexão. Erro 10 genérico não prova menos de cinco espectadores. Resposta vazia informa causa não confirmada; algumas métricas de público têm limiar de seguidores/amostra, mas `follows_and_unfollows` vazio não é atribuído automaticamente a menos de 100 seguidores. Código/HTTP medidos permanecem nos erros; texto arbitrário do fornecedor não é guardado.

## Captura e consulta do arquivo

Na aba Arquivo de Stories, selecione conexão e conta Instagram e use **Criar agenda horária de Stories**. Cria uma agenda comum, sem filtro fixo de datas, com métricas do pedido. É possível revisar/pausar pela aba Coletas. A ferramenta evita duplicar uma agenda horária equivalente ativa. O cron depende de execução do WordPress; configure cron real quando necessário. Stories podem expirar entre execuções, e a API não reconstrói os que nunca foram observados.

Coletas persistentes de `stories` e `stories_insights` capturam data de publicação, tipo, permalink, legenda e miniatura antes de pedir insights. Consulta simples `meta/query` permanece sem gravação de arquivo. Miniatura indisponível não apaga os metadados nem transforma a coleta em falha de autenticação. O estado da miniatura indica a causa local. Enquanto o Story ainda aparecer em coletas, uma miniatura ausente pode ser tentada novamente após cinco minutos; metadados anteriores são preservados.

| Limite | Política |
|---|---|
| Retenção | Sem expiração automática |
| Registros | Sem limite total nem descarte por quantidade |
| Armazenamento | Sem teto total imposto pelo plugin |
| Origem da imagem | HTTPS, apenas subdomínios cdninstagram.com/fbcdn.net, sem redirecionamento, credenciais ou porta |
| Download | Máximo 1 MiB, 5 segundos, sem bearer token |
| Imagem | JPEG/PNG/WebP, até 4.096 px por lado e 12 megapixels |
| Miniatura persistida | JPEG reprocessado, até 256 px, qualidade 60, máximo 32 KiB |

Exige editor de imagem WordPress funcional (GD ou Imagick) para produzir miniatura. Sem editor/arquivo válido, mantém metadados e diagnóstico `thumbnail_editor_unavailable` ou a causa correspondente. Vídeo completo nunca é baixado: usa `thumbnail_url`; imagem usa miniatura ou `media_url`. Arquivos temporários são removidos; não há attachment nem arquivo em uploads. A base64 fica cifrada no banco. Permalink é reduzido a HTTPS Instagram sem query. Legenda limitada a 2.200 caracteres sanitizados.

Não há remoção automática por idade, quantidade ou tamanho total. A manutenção não apaga registros com expires_at=0. A preservação depende da continuidade do banco e das chaves criptográficas; mantenha backups próprios. Mudança de autorização invalida acesso aos registros capturados sob a revisão anterior; a seleção atual e administrador são conferidos também ao ler a miniatura.

`meta/story-archive`: connection_id, account_id, datas opcionais em par, limit 1–25 e cursor. Retorna metadados e disponibilidade; páginas podem ficar vazias após filtro de data, portanto siga a continuação. `meta/story-archive-thumbnail` recebe connection_id/account_id/story_id e retorna JPEG base64 em resposta privada autenticada. Não disponibiliza URL pública. A tela apresenta a mesma leitura.

Exemplo de coleta:

```json
{"query":{"connection_id":"minha-conexao","channel":"instagram","account_id":"CONTA_NUMERICA","report":"stories_insights","fields":["reach","views","profile_activity","navigation","link_clicks"]},"idempotency_key":"stories-20261026"}
```

Use `meta/create-job`, depois `meta/run-job` até terminar. O resultado do arquivo pode ser lido após as 24 horas de vida do Story sem prazo de expiração automática. Métricas só existem se coletadas enquanto o fornecedor as disponibilizava.

Referências primárias consultadas em 26/10/2026:

- https://developers.facebook.com/documentation/instagram-platform/reference/instagram-media/insights
- https://developers.facebook.com/documentation/instagram-platform/api-reference/instagram-user/insights

A comprovação local com fixtures é separada da homologação externa: postar Story, coletar antes da expiração, ler após expirar e comparar insights/post e conta reais depende dos ativos e credenciais do operador.
