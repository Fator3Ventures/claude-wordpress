# Versão 0.14.0 — Pedido MCP Meta 22

Base direta 0.13.0. Removida a exigência de prefixo EAA do token; mantidos 100–16384 caracteres, ausência de espaços/controles, recusa de App Secret e inspeção remota antes de persistir. A mesma validação atende salvar, renovar e trocar identidade. Ajuda de campo corrigida, sem novo schema, ability, contrato SDK, banco ou retenção. Documentação registra o consumidor Ads já presente no Core1.59.0 examinado.

# 0.13.0 — 28/10/2026

Base 0.12.0; pedidos20/21. Canal Ads somente leitura/ads_read, insights diários em quatro níveis, histórico cifrado sem prazo, revisita de atribuição, retroativo, exportação e SDK local meta-ads-reader/1.0.0 com concessão explícita. Três abilities aditivas (44). Nenhuma mudança em outros plugins ou gestão de anúncios.

Coletas preservam métricas disponíveis quando pares estão ausentes/suprimidos/recusados; null não é sucesso, zero é válido. Agendas registram successful_rows, unavailable_metrics, last_run_status, last_success_at e last_partial_at; health separa parciais de falhas. Recusas globais, quota, transporte e autorização mantêm guardas anteriores. Documentação atualiza a integração de exclusão já presente no Core1.57.1.

# 0.12.0 — 26/10/2026

Contrato local instagram-message-erasure/1.0.0 para eliminação por remetente/evento escopado. Autorização administrativa/concessão atual, sem exigir conexão/token Meta; revisão opaca, idempotência, recibo mínimo, bloqueio HMAC durável antes da remoção e retomada de falha parcial. Continuações agendadas da conta são limpas; geração impede worker de reagendar cursor anterior. Rejeita transação SQL ativa sem confirmá-la. Contrato de ingestão 1.0.0, 41 abilities e retenção ilimitada preservados. Core1.56.0 possui consumidor de ingestão e deve integrar a eliminação. Docs e schema do SDK instalados.

# 0.11.1 — 26/10/2026

Patch documental após a instalação da 0.11.0 no Site-Teste: remove referências correntes a auditoria de 30 dias/exportações de 24 horas, corrige catálogo para 41 operações, guia de atualização e descrição do SDK de mensagens. Nenhuma mudança de código funcional, JavaScript ou schemas; Config/cabeçalho e documentação compilada identificam a versão atual.

# 0.11.0 — 26/10/2026

Base direta 0.10.1. Pedidos 18/19: seis operações aditivas de conversas/configuração/contatos/arquivo, webhook assinado e mínimo, origem por evidência e primeira mensagem disponível; SDK do Core opcional e desligado. Métricas e breakdowns novos, diagnósticos de supressão com causa comprovada, arquivo cifrado limitado de Stories com miniatura privada. Orientação adicional de retenção: histórico, arquivo, recibos, auditoria e exportações sem expiração automática; arquivo/diário sem descarte por quantidade. Nenhuma alteração em pacote acompanhante. Leia INSTAGRAM-MESSAGING.md e STORY-ARCHIVE.md.

# Alterações

## 0.10.1 — 24/10/2026

Correção documental encontrada na conferência final: CONFIGURATION descreve a gravação atômica do nome na troca de identidade; WORKER informa as 35 operações atuais, distingue concessão local de revogação da conexão e marca a reversão 0.5/0.6 como histórica; TROUBLESHOOTING orienta a ação pelo escopo da falha. Código funcional e schemas são idênticos aos da 0.10.0. Incremento de patch porque o instalador 0.10.0 já havia sido instalado no Site-Teste.

## Versão 0.10.0 — Pedidos MCP Meta 16 e 17

A prévia de troca de identidade aparece junto do formulário que a pediu; a origem Renovar token abre o bloco automaticamente. A prévia recebe foco e anúncio acessível. A recusa de identidade fica junto de Salvar conexão e aponta o botão de troca. `meta/switch-identity` aceita `label` opcional (até 120 caracteres): o nome é incluído na prévia (`connection_label`), vinculado à confirmação e salvo junto da credencial e das agendas na mesma revisão/transação. Sem label, preserva o nome salvo. Editar a candidata invalida a prévia; resposta assíncrona obsoleta não a reabre.

Stories indisponíveis têm códigos próprios; revogação da conexão exige confirmação independente. Agendas e auditoria guardam código Graph, subcódigo, HTTP e instante. O aviso passa a uma tentativa por incidente e mostra a causa medida. Consulte `COLLECTION-DIAGNOSTICS.md` para códigos, efeitos, recuperação, persistência e limites. Os 35 IDs de operações permanecem; somente o campo label de switch-identity é acrescentado ao schema de entrada.

## 0.9.0 — 23/10/2026

Pedido MCP Meta 15: formato de credenciais e inspeção antes da gravação; identidade/app/validade/permissões visíveis; nova operação `meta/switch-identity` com simulação e confirmação vinculada; regravação atômica das revisões das agendas nas mudanças compatíveis. Mantém os 34 IDs anteriores e acrescenta uma operação administrativa. A gravação/rotação agora consulta a Meta e pode recusar sem alterar a configuração. Mudanças de seleção/autorização e jobs de outra identidade continuam exigindo revisão explícita. Base direta 0.8.0, sem migração destrutiva ou tabela nova.

0.8.0 — 23/10/2026

- Isolamento de job decide a legibilidade do mesmo snapshot cifrado usado no CAS, sob a trava individual. Corrige a janela entre duas leituras diante de restauração externa que repõe revisão e bytes anteriores. A gravação normal via Store::put não reduz revisões; a reprodução usa gravador externo que ignora a trava consultiva.
- Store::get e Queue::isolate compartilham a decodificação e os mesmos códigos de erro, sem segunda consulta para isolamento. Payload, revisão, timestamps e retenção preservados; nenhuma reativação automática de unreadable.
- Compatibilidade conferida com MCP 0.29.1, Core 1.49.1, Google 0.18.1 e LinkedIn 0.9.0. IDs, schemas, autorização e dados preservados.
- Orientação de idempotência atualizada: retryable não comprova ausência de efeito; resultados incertos conservados; observar health sem chave de idempotência.

## 0.7.1 — revisão independente, 23/10/2026

- Diagnóstico e recuperação continuam disponíveis quando a última coleta da agenda está ilegível; issue `schedule_job_unreadable` identifica a agenda sem expor conteúdo. Esse aviso não dispara e-mail horário.
- O worker isola também jobs ilegíveis já indexados, liberando as passagens seguintes para outros jobs. Uma passagem continua limitada a 20 candidatos.
- Migração, worker e retenção usam a mesma guarda: trava do job, releitura e CAS de revisão e ciphertext exato. Falha de banco não é tratada como corrupção. Payload, revisão, datas e retenção são preservados.
- Sem novo schema, ID público ou permissão. Base direta 0.7.0; validada também a entrada da 0.6.0 conforme relatório.

# 0.7.0 — 22/10/2026

Melhorias M1–M5 por ordem do dono de 22/10/2026 (rodada conjunta dos pacotes Fator3):

- M1 — `meta/health`: diagnóstico de leitura (mode=read, local_effect=none, remote_effect=none), liberado ao perfil de leitura do MCP; grava só a linha de auditoria local, como toda operação despachada. `meta/status` mantém o contrato de escrita local e recuperação.
- M2 — Bootstrap sem SQL próprio por requisição: as marcas lidas em toda requisição (`f3_meta_schema`, `f3_meta_history_schema` e a nova `f3_meta_queue_settled`) passam ao autoload do WordPress (uma única troca por `wp_set_option_autoload`), e a consulta de migração pendente deixa de rodar depois de confirmada a migração.
- M3 — Registro de coleta ilegível (chave do site diferente) vira projeção `unreadable`: não trava a migração dos demais, sai da seleção da retenção (que segue para as coletas legíveis), não é executado nem apagado; diagnóstico `queue_record_unreadable` sem e-mail horário.
- M4 — A manutenção horária ausente é recriada na requisição seguinte (trava de banco, uma escrita só quando falta); diagnóstico `maintenance_missing`.
- M5 — `meta/audit` em ordem do mais recente, com `since` opcional; `list-connections` faz uma leitura só por página.
- Leitura documental: teto de `offset` de `meta/documentation` elevado a 16 MiB; documentos acima de 100 KB passam a ser lidos até o fim com páginas pequenas.
- Código comum com o Fator3 MCP LinkedIn 0.8.0 convergido (`Support`, `Query`, `Queue`). Testes ajustados às versões reais dos acompanhantes e à matriz mínima WordPress 6.4/PHP 8.1.2.

# 0.6.0 — 22/10/2026

Pedidos MCP Meta 13 e 14: recuperação do evento ausente na manutenção e no status; reagendamento verificado e protegido; diagnóstico de agendas atrasadas/autorização e aviso por e-mail; seleção indexada por estado/vencimento antes dos históricos concluídos. Schema 2, projeção técnica atômica e migração de registros 0.5.0 em lotes de 100. Nenhuma credencial ou concessão é alterada automaticamente.

# Alterações — Fator3 MCP Meta 0.5.0

## 0.5.0 — 22/10/2026

- Pedidos MCP Meta 12(a,b,c): rótulos em português e descrições específicas para as 33 habilidades públicas.
- Catálogo único em `AbilityLabels.php`, também publicado como `abilities-pt-br.json` na documentação instalada; compilação recusa cobertura incompleta ou rótulos duplicados.
- Identificadores `meta/*`, schemas, callbacks, autorização, contratos e dados preservados. Não exige novas credenciais nem reconfiguração.
- Atualização direta da 0.4.1; funções próprias independem do MCP. O transporte e suas telas exibem os metadados registrados pelo Meta.
- Aceites Meta 10/11 mantidos conforme documento de pedidos de 21/10/2026. Provas externas de rotação, histórico e Story continuam sob responsabilidade da frota; esta release não altera essas rotinas.

## Histórico anterior

# Alterações — 0.4.1

- Tradução dos rótulos e estados de diagnóstico, cobertura e concessões; campos técnicos não catalogados usam rótulo em português e conservam a chave em dica técnica. Códigos de API continuam íntegros nos contratos.
- A 0.4.0 foi um marco intermediário instalado no Site-Teste. Seus ZIPs não foram reescritos. O patch 0.4.1 segue a orientação do dono para revisões dentro do mesmo ciclo. Esta entrega atualiza diretamente 0.3.0 e 0.4.0.

## Implementação da 0.4.0

# Alterações — 0.4.0

Atualização direta da 0.3.0, sem migração de tabela ou mudança de identidade.

- Meta 10: abas por assunto com URL própria; conexões locais na abertura; usuários, contas, objetos e formulários selecionados pelo nome; carregamento e falhas por seção; versão da API em Diagnóstico > configuração avançada.
- Agendas: nome, próxima execução em UTC e edição com revisão; edição preserva consulta, horário exato e último recibo quando não alterados.
- Nova operação administrativa `admin-options`, com seleção explícita e revalidação de autorização/revisão. Contratos de relatórios e SDK preservados.
- Meta 11: `page_views_total` aceito em `page_insights`, inclusive série diária; nenhuma substituição por visualização de mídia. Prova com fornecedor real depende de ativo/token e versão.

## Histórico da 0.3.0

# Alterações — 0.3.0

Atualização direta da 0.2.0; nenhuma migração de banco, seleção ou autorização.

- Pedido MCP Meta 1: Description exata com local de configuração.
- Pedido MCP Meta 9: erros Graph numéricos e subcódigos preservados em consultas/coletas; inspeção de permissões do token derivado de cada Página; fallback individual para grupos vazios; ausência e múltiplos buckets explicitados.

## Histórico da 0.2.0

# 0.2.0

- Gate manage_options em todas as entradas humanas e revalidação de tarefas.
- Documentação completa instalada, índice, paginação UTF-8 e revisão/hash.
- Catálogo versionado, séries diárias e grupos de métricas compatíveis.
- Canal Facebook, tokens de Página privados e propriedade de objetos.
- Histórico cifrado independente de jobs, retenção sem expiração, migração, deduplicação e exportação em partes.
- Backfill com início explícito, janela final congelada e retomada.
- Capturas periódicas de mídias/Stories e rotação validada de token.
- Desinstalação conserva dados.

Homologação de métricas reais, disponibilidade de dois anos e comportamento por tipo de mídia dependem dos ativos/escopos do dono; não são deduzidos dos testes simulados.
