# Configuração Meta — 0.14.0

Ferramentas → Fator3 MCP Meta → Conexão. Preencha o nome no formato `usuário do sistema · app`, o **ID do Aplicativo (App ID)** (15 a 17 dígitos), a **Chave Secreta do Aplicativo (App Secret)** (32 caracteres hexadecimais) e o **Token de acesso do usuário do sistema** (de 100 a 16384 caracteres, sem espaços ou caracteres de controle). O prefixo não determina a validade: save-connection, rotate-token e switch-identity conferem a candidata na Meta antes de gravar, conforme Pedido 22. Permanecem a recusa de App Secret, a prova de app/identidade/escopos/ativos e as revisões existentes. Não cole a chave no campo de token. Token/chave vazios preservam o valor cifrado; remover exige a opção explícita.

Encontre ID e chave em Meta for Developers → Meus apps → seu app → Configurações do app → Básico. Para a chave, clique Mostrar. Gere o token em Meta Business Suite → Configurações → Usuários → Usuários do sistema → usuário → Gerar token; escolha o mesmo app, a expiração Nunca e pages_show_list, pages_read_engagement, read_insights, instagram_basic, instagram_manage_insights. Copie o token da janela Token criado antes de fechá-la. Não use Anular tokens: uma revogação pode também derrubar usos da mesma credencial no Site Core. O Meta não grava nem revoga as credenciais próprias do Core.

Ao informar um token novo ou alterar o par de aplicativo, `save-connection` consulta `debug_token` autenticado com esse aplicativo e `/me?fields=id,name`, antes de persistir. Confere is_valid, app_id, identidade, expiração e cada ativo selecionado. Falhas preservam bytes da conexão e agendas. Limite de 12 ativos por conexão, até 40 chamadas/25 segundos por operação; tempo ou orçamento insuficiente recusa a candidata sem gravação. Auditoria técnica da chamada pode existir mesmo numa recusa ou simulação; não alegar ausência universal de efeitos locais.

O campo **Validade do token (UTC)** é substituído por `debug_token.expires_at`; zero significa não expira por prazo. Tokens ainda podem ser revogados. A identidade pública contém subject_id, subject_name (de `/me`), application_id, application_name (de `debug_token`), remote_expires_at, scopes e extra_scopes. Os nomes ausentes são mostrados como indisponíveis; não são inferidos do rótulo digitado. A prova é uma observação datada, não garantia permanente de acesso. O resumo não consulta a Meta ao abrir a tela. Permissões além das cinco são avisadas, inclusive public_profile, sem revogação automática.

## Renovação e outra identidade

`rotate-token` usa o mesmo validador da gravação normal, com expected_revision obrigatório. Aplicativo, principal e identidade devem coincidir, sem perder permissões anteriores. A credencial antiga expirada pode ser substituída com base numa identidade já comprovada. Sem prova antiga, tenta inspecionar a credencial salva com o par informado; se não conseguir comprovar a continuidade, exige a troca guiada. Não exige revogar o token anterior.

A tela oferece **Trocar identidade e regravar agendas** após credential_identity_mismatch. A prévia mostra identidade, app, validade, permissões e quantidade de agendas. A confirmação grava a credencial/identidade, o par de app informado e o nome digitado em Editar conexão, junto das agendas na mesma transação. Na renovação ou sem `label`, preserva o nome salvo. Os demais campos não salvos do formulário devem ser gravados separadamente. Nenhuma seleção é ampliada. A rota `meta/switch-identity` tem `dry_run` obrigatório. Na simulação, receba `confirmation`; em até dez minutos, repita a mesma candidata e revisão com dry_run=false e esse comprovante. A confirmação vincula credencial, app, identidade, nome, permissões, expiração, site, ator/concessão, revisão da conexão e revisões das agendas. Nova revisão, candidata, autorização ou agenda exige nova simulação. A execução revalida o fornecedor.

## Revisões e agendas

Revisão de configuração (CAS), authorization_revision e credential_generation são contadores distintos. Alterações de nome, validade, retenção ou aplicativo verificado e rotação da mesma identidade regravam as agendas compatíveis na revisão atual. Conexão, agendas e evento de auditoria são gravados numa única transação InnoDB; falha desfaz todas essas alterações. O evento fica em `meta/audit`, com revisões antiga/nova e IDs das agendas, sem expiração automática. Não se mistura esse diário técnico com métricas do Histórico.

Preservam-se principal/concessão de origem, pausa, próxima data, frequência, consulta, último job e resultados. Concessão revogada continua recusada. Agendas já incompatíveis por seleção/autorização anterior são listadas em schedules_requiring_review, sem reautorização silenciosa. A troca guiada exige que todas ainda usem ativos atualmente selecionados e regrava suas revisões; conserva o principal. Jobs/cursors iniciados sob outra identidade permanecem intactos e não são autorizados para a nova. Mudanças de ativos, usuários associados, API ou enabled continuam invalidando os planos anteriores; revise e salve as agendas explicitamente.

## Ativos e histórico

Depois de cadastrar a conexão, escolha Instagram profissional e/ou Páginas por nome na aba Ativos. Facebook Login exige Página vinculada. Descoberta nunca concede acesso nem marca seleção sozinha. A versão Graph padrão permanece v24.0, em Diagnóstico → configuração avançada. Facebook usa token de Página derivado apenas de Página selecionada, cifrado e ligado à geração da credencial, nunca público. A candidata prova que pode derivar e ler a Página sem gravar cache; Instagram é conferido diretamente. Acesso a metadados não prova disponibilidade de toda métrica: valide relatórios/escopos com a conta real.

Na série 0.11, novas conexões usam unlimited; a primeira carga amplia também conexões e dados existentes, conforme RETENTION.md. Uma escolha posterior explícita pode usar prazo finito. `retention_days` aceita 1–3650 e só governa métricas em modo finite. `retention_mode=unlimited` retira a expiração automática do histórico existente e das próximas páginas; não recupera dados apagados. Usuários WordPress são selecionados pelo nome e não recebem manage_options por isso. Mudanças de retenção preservam o diário e a seleção. Recarregue uma aba administrativa aberta antes da atualização para carregar o JavaScript e a versão atuais.

A projeção pública `connection.identity` repete apenas os metadados de identidade, para permanecer legível sob o redator do MCP. O campo legado token_identity é mantido por compatibilidade; o MCP pode ocultá-lo pelo nome. Não se altera a política de segredos do transporte.


## Histórico — Versão 0.10.0 — Pedidos MCP Meta 16 e 17

A prévia de troca de identidade aparece junto do formulário que a pediu; a origem Renovar token abre o bloco automaticamente. A prévia recebe foco e anúncio acessível. A recusa de identidade fica junto de Salvar conexão e aponta o botão de troca. `meta/switch-identity` aceita `label` opcional (até 120 caracteres): o nome é incluído na prévia (`connection_label`), vinculado à confirmação e salvo junto da credencial e das agendas na mesma revisão/transação. Sem label, preserva o nome salvo. Editar a candidata invalida a prévia; resposta assíncrona obsoleta não a reabre.

Stories indisponíveis têm códigos próprios; revogação da conexão exige confirmação independente. Agendas e auditoria guardam código Graph, subcódigo, HTTP e instante. O aviso passa a uma tentativa por incidente e mostra a causa medida. Consulte `COLLECTION-DIAGNOSTICS.md` para códigos, efeitos, recuperação, persistência e limites. Na série 0.10, os 35 IDs de operações foram preservados e label foi acrescentado a switch-identity. Na série 0.11, somam-se seis operações, totalizando 41.


## Complemento 0.11.0 — pedidos 18/19

Consulte INSTAGRAM-MESSAGING.md para as operações administrativas de conversas, configuração, escopos, webhook e contrato local instagram-first-message/1.0.0. Core 1.56.0 registra o consumidor de ingestão; contatos exigem opt-in explícito nos dois pacotes. A eliminação coordenada é descrita em MESSAGE-PRIVACY.md; Core1.57.1 já integra esse SDK. Consulte STORY-ARCHIVE.md para novos campos/breakdowns, limites do arquivo privado, agenda horária e diagnóstico de supressão. Os 35 IDs anteriores são preservados e há seis operações aditivas (41).


## Meta Ads na 0.13.0

Pedido20 inclui leitura Ads: seleção explícita/ads_read, dias completos no fuso da conta, acervo cifrado sempre sem prazo, agendas e CSV/JSON. Canal ads, relatório ads_insights, nível selecionável. Consumidores locais exigem registro e concessão explícita, desligada por padrão. Leia META-ADS.md e META-ADS-READER.md. Nenhuma escrita em anúncios, alteração do LinkedIn ou ingestão comercial implícita. Pedido21 distingue coleta parcial de falha em COLLECTION-DIAGNOSTICS.md.
