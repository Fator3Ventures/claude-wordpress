# Conversas do Instagram — Meta 0.13.0

Pedidos MCP Meta 18(a–c). Facebook Login, contas profissionais e Página explicitamente selecionada. Não há envio de mensagens. As seis operações de mensagens/Stories da série 0.11 preservam seus IDs; a série 0.13 acrescenta três operações de concessão do leitor Ads, totalizando 44.

## Configuração e aprovação

1. Salve e valide a conexão como administrador. Selecione a conta Instagram e sua Página Facebook na aba Ativos.
2. O responsável pelo aplicativo deve conferir os produtos de mensagens, App Review e acesso avançado a `instagram_manage_messages` no painel Meta. Os escopos requeridos por este cliente são `instagram_basic`, `instagram_manage_messages` e `pages_manage_metadata`; mantenha também os escopos necessários à descoberta de Páginas e aos relatórios existentes. A Meta pode impor requisitos adicionais à situação do aplicativo.
3. Na aba Conversas, carregue a configuração e escolha a Página autorizada pelo nome. O vínculo Página/Instagram é conferido antes de habilitar a recepção. A declaração de acesso avançado é do administrador; `app_review.verified` permanece false porque escopos não comprovam App Review.
4. Defina um token de verificação de 16–128 caracteres e habilite recepção. O segredo do aplicativo já salvo valida HMAC SHA-256. Configure no painel Meta a URL exibida e os eventos de mensagens pertinentes; nenhuma assinatura remota é criada automaticamente pelo plugin. Campo de verificação vazio mantém o segredo existente.
5. Consulte `meta/messaging-status` e `meta/health`. O estado local usa a última validação do token; a leitura de conversas inspeciona novamente o token derivado da Página. `scope_missing` mostra os escopos ausentes, `scope_unverified` significa prova insuficiente. Sem aprovação/token válidos, a homologação externa permanece pendente.

`meta/save-messaging-settings` usa `expected_revision` e seleção por conexão/conta. A configuração guarda a autorização humana/MCP de origem. Alterações da autorização ou da seleção invalidam a recepção até nova gravação explícita. A rotação validada que conserva autorização pode continuar. A conexão deve estar ativa; a recepção e contatos começam desligados. A interface e todas as operações administrativas exigem `manage_options` no servidor.

## Consulta somente leitura

```json
{"connection_id":"minha-conexao","account_id":"CONTA_INSTAGRAM_NUMERICA","page_id":"PAGINA_NUMERICA","date_from":"2026-10-01","date_to":"2026-10-26","limit":5}
```

Use essa entrada em `meta/conversations`. `page_id` pode ser omitido quando já salvo na configuração. Datas opcionais devem vir em par. A operação deriva o token apenas da Página autorizada, confere seu vínculo e escopos, consulta conversas com `platform=instagram` e mensagens com `id,created_time,from,to,reply_to`. Não solicita `message`, texto ou anexos. Nunca segue `paging.next` como URL; usa apenas o cursor no endpoint fixo. Limites: até 10 chamadas de paginação por execução, 100 mensagens por página remota e 1–10 conversas concluídas por página local. A continuação cifrada expira em uma hora e vincula filtros, conta, principal, revisão de autorização e geração da credencial.

`first_available_message_at` é a mensagem mais antiga **disponível**, após esgotar as páginas daquela conversa. Conversa ainda incompleta não entra na contagem. `started_per_day_in_page` agrupa por dia UTC apenas as linhas desta página; some todas as páginas da mesma consulta. Não soma automaticamente páginas em consultas diferentes. A API pode omitir pedidos da pasta Requests inativos há mais de 30 dias. Não é possível garantir histórico integral nem a primeira conversa de toda a vida. Compare com a caixa de entrada respeitando essas diferenças; não apresente esses números como homologados antes do teste com credencial real.

Origem comprovada usa `message.reply_to.story.id` → `story_reply`; referral com `source=ADS` e `ad_id` → `ad`; referral com `source=SHORTLINK` e `ref` → `ig_me`. Outras referências permanecem `referral`; ausência → `unknown`. Nenhuma ausência é convertida em espontâneo. Uma notificação `messaging_referral` de conversa já existente não substitui a origem da primeira mensagem. Os campos `ref`, `source`, `type` e `ad_id` são preservados em projeção limitada, sem título/descrição do anúncio ou URL de mídia. A associação entre leitura e webhook exige o mesmo ID de mensagem, remetente, conta e autorização.

## Webhook e armazenamento

Endpoint próprio `GET|POST /wp-json/f3-meta/v1/messaging-webhook/<conexao>/<conta>`. GET valida token e retorna o challenge numérico literalmente. POST exige `X-Hub-Signature-256` do corpo bruto, máximo 256 KiB, envelope Instagram, conta/recipient selecionados e autorização atual. Echo, saída, eventos sem mensagem e eventos anteriores à habilitação são ignorados. Repetição por remetente/conta/conexão não duplica; evento anterior recebido fora de ordem ajusta o candidato enquanto ainda não entregue. Depois de reserva/entrega, evidência anterior exige reconciliação e não dispara novo contato.

Só metadados mínimos são cifrados em `message_event`; sem texto, anexos, cookies ou segredo. Retenção sem expiração automática e sem teto de quantidade de candidatos. Não há descarte automático por capacidade. O SDK de contatos abaixo é independente do arquivamento de Stories.

## SDK local para o Site Core

O **Core 1.56.0 registra este consumidor**. Pedido 18(b)/Core309 exige opt-in explícito nos dois pacotes e homologação externa. O Core1.57.1 integra o contrato de eliminação acrescentado na 0.12.0; consulte MESSAGE-PRIVACY.md. A opção de contatos não pode ser habilitada sem consumidor compatível. Não usar `f3base/contato-externo-registrar` como substituto automático do fluxo manual existente.

No carregamento do Core, antes de `plugins_loaded` prioridade 20:

```php
add_action('f3_meta_register_messaging_consumers', static function (string $sdk): void {
    $sdk::registerConsumer('site-core', 'instagram-first-message/1.0.0',
        static function (array $event): array {
            // Implementação do Core: revalidar política, deduplicar e persistir
            // contato/recibo na mesma unidade durável. Não usar este exemplo
            // como confirmação de gravação: retornar SOMENTE o recibo real.
            return CoreInstagramConsumer::ingest($event);
        }
    );
});
```

`CoreInstagramConsumer` é nome ilustrativo, não classe implementada pelo pacote. Há um único consumidor por processo, sem auto-registro se o Core não o fornecer. O callback recebe `contract`, `event_id`, `idempotency_key`, `connection_id`, `account_id`, `sender_id`, `message_id`, `first_available_message_at`, `observed_at`, `origin` e `coverage`. O principal não é exposto no evento: o Meta o preserva e revalida internamente antes de cada entrega. A chave é estável por conexão/conta/remetente. Não são inferidos nome, email, telefone, UTM, sessão ou consentimento.

O Meta compara o candidato assinado com a primeira mensagem disponível na API antes de chamar o consumidor; só mensagens posteriores à autorização de contatos são elegíveis. `coverage` ressalta que isso **não comprova primeiro contato de toda a vida**. O Core precisa de deduplicação comercial persistente pelo identificador Instagram escopado, inclusive após reinstalação ou limpeza administrativa explícita, e bloqueio de reimportação quando um contato tiver sido eliminado. Não deve tratar ausência de origem como espontâneo nem disparar avisos/CRM sem sua própria autorização. Mudanças de política do Core são revalidadas pelo próprio callback, além da autorização Meta.

Recibo aceito: `['persisted'=>true,'record_id'=><id real>,'idempotency_key'=><mesma chave>]`. Reserva persistida antes do callback; exceção/recibo ambíguo → `uncertain`, sem repetição automática. Reinício após reserva também não autoriza repetição. `meta/process-messages` processa uma página; preserve `next_cursor`. Recepção de evento elegível agenda execução local e continua páginas pelo cron; falha de fornecedor precisa de nova execução administrativa após diagnóstico. Não há garantia de processamento se o cron não executar.

Reconciliação administrativa pelo SDK: `Messaging::deliveryReceipt($connection,$account,$event)` retorna estado/revisão; após conferir o recibo ou impedimento de reimportação no Core, `Messaging::reconcileReceipt($connection,$account,$event,$expectedRevision,$receipt)` aceita persistência real com mesma chave ou `suppressed=true`. Exige administrador, consumidor presente e autorização atual; não repete callback. Não existe botão que declare sucesso sem prova do Core. Sem recibo conclusivo, preserve a incerteza e investigue no Core.

## Referências primárias consultadas em 26/10/2026

- https://developers.facebook.com/documentation/business-messaging/messenger-platform/conversations
- https://developers.facebook.com/documentation/business-messaging/instagram-messaging/webhooks
- https://developers.facebook.com/documentation/business-messaging/instagram-messaging/features/ig-me-links
- https://developers.facebook.com/documentation/instagram-platform/webhooks/examples

Consulta por índices de pesquisa oficiais; alguns acessos completos retornaram HTTP 429. Fixtures exercitam o contrato implementado; não substituem teste de fornecedor com aplicativo aprovado.
