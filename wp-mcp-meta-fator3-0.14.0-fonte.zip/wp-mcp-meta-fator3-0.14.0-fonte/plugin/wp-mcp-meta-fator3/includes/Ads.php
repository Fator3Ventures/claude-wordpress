<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Bounded GET-only Marketing API reader. Amounts and counts retain provider decimal strings. */
final class Ads {
    public const ATTRIBUTION=['use_unified_attribution_setting'=>true,'action_report_time'=>'mixed'];
    private const BASE=['account_id','account_name','account_currency','campaign_id','campaign_name','adset_id','adset_name','ad_id','ad_name','date_start','date_stop','spend','impressions','reach','frequency','clicks','inline_link_clicks','actions','cost_per_action_type'];
    public static function names(): array {return array_merge(self::BASE,['results','cost_per_result','creative_id','creative_name','leads_native','leads_website']);}
    public static function fields(string $version): array {
        return array_map(static fn($f)=>['name'=>$f,'source_field'=>in_array($f,['leads_native','leads_website'],true)?'actions':$f,'catalog_revision'=>Catalog::REVISION,'api_version'=>$version,'api_family'=>'marketing','availability'=>'requires_remote_validation','periods'=>['day'],'temporal'=>'daily','aggregation'=>in_array($f,['reach','frequency'],true)?'never_sum_across_entities_or_days':'preserve_source','unit'=>'provider_defined','historical_horizon_days'=>null,'history_requires_explicit_start'=>true,'compatibility'=>'catalogued_candidate'],self::names());
    }
    public static function scope(array $c): void {
        $proof=$c['token_identity']??[];
        if(($proof['validated_generation']??0)!==$c['credential_generation']||empty($proof['app_verified'])||!in_array('ads_read',$proof['scopes']??[],true))throw new Fault('ads_read_required','Valide um token com ads_read antes de consultar contas de anúncios.');
    }
    public static function account(array $c,string $id,bool $inspect=false): array {
        Util::numeric($id);if(!$inspect)Access::asset($c,'ads',$id);$query=['fields'=>'id,account_id,name,currency,timezone_name'];
        $r=($inspect?Http::inspect($c,'act_'.$id,$query):Http::request($c,'act_'.$id,$query))['body'];
        if((string)($r['account_id']??'')!==$id||($r['id']??'')!=='act_'.$id)throw new Fault('asset_access_denied','A Meta retornou outra conta de anúncios.');
        if(!is_string($r['currency']??null)||!preg_match('/^[A-Z]{3}$/D',$r['currency'])||!is_string($r['timezone_name']??null))throw new Fault('upstream_invalid','Moeda ou fuso da conta de anúncios ausente.');
        try{new \DateTimeZone($r['timezone_name']);}catch(\Throwable $e){throw new Fault('upstream_invalid','Fuso da conta de anúncios inválido.');}
        return ['id'=>$id,'account_id'=>$id,'name'=>is_string($r['name']??null)?sanitize_text_field($r['name']):null,'currency'=>$r['currency'],'timezone'=>$r['timezone_name'],'checked_at'=>gmdate('c')];
    }
    public static function accounts(array $c,array $i): array {
        self::scope($c);$q=['fields'=>'id,account_id,name,currency,timezone_name','limit'=>50];if(isset($i['after']))$q['after']=$i['after'];
        $r=Http::request($c,'me/adaccounts',$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Lista de contas de anúncios inválida.');$rows=[];
        foreach($r['data'] as $a){$id=Util::numeric((string)($a['account_id']??''));if(($a['id']??'')!=='act_'.$id)throw new Fault('upstream_invalid','Conta de anúncios inconsistente.');$rows[]=['id'=>$id,'name'=>is_string($a['name']??null)?sanitize_text_field($a['name']):null,'currency'=>$a['currency']??null,'timezone'=>$a['timezone_name']??null];}
        return ['rows'=>$rows,'continuation'=>self::after($r),'limitation'=>'A descoberta não autoriza contas; selecione explicitamente os ativos.'];
    }
    private static function after(array $r): ?string {
        if(empty($r['paging']['next']))return null;$after=$r['paging']['cursors']['after']??null;
        if(!is_string($after)||$after===''||strlen($after)>8192)throw new Fault('coverage_incomplete','Continuação de anúncios sem cursor seguro.');return $after;
    }
    public static function yesterday(array $c,string $account): string {self::scope($c);$meta=self::account($c,$account);return (new \DateTimeImmutable('yesterday',new \DateTimeZone($meta['timezone'])))->format('Y-m-d');}
    public static function page(array $c,array $i,array $s): array {
        self::scope($c);$meta=self::account($c,$i['account_id']);$dates=Util::dates($i,3660);$day=$s['day']??$i['date_to'];$level=$i['ads_level']??'campaign';
        if(!is_string($day)||$day<$i['date_from']||$day>$i['date_to'])throw new Fault('invalid_cursor','Dia fora do período solicitado.');
        $today=(new \DateTimeImmutable('today',new \DateTimeZone($meta['timezone'])))->format('Y-m-d');
        if($i['date_to']>=$today)throw new Fault('invalid_input','Meta Ads exige dias completos no fuso da conta.');
        $limit=min($i['limit']??50,$level==='ad'?10:100);
        $q=['fields'=>implode(',',array_merge(self::BASE,['results','cost_per_result'])),'level'=>$level,'time_increment'=>1,'time_range'=>Util::json(['since'=>$day,'until'=>$day]),'limit'=>$limit,'use_unified_attribution_setting'=>'true','action_report_time'=>'mixed'];if(isset($s['after']))$q['after']=$s['after'];
        $errors=[];$missing=[];$optional=[];
        try{$r=Http::request($c,'act_'.$i['account_id'].'/insights',$q)['body'];}
        catch(Fault $e){
            // Optional result fields vary by provider version. Retry the same bounded page without them.
            if($e->reason!=='upstream_validation')throw $e;
            $q['fields']=implode(',',self::BASE);$r=Http::request($c,'act_'.$i['account_id'].'/insights',$q)['body'];
            foreach(['results','cost_per_result'] as $f){
                $one=$q;$one['fields'].=','.$f;
                try{$part=Http::request($c,'act_'.$i['account_id'].'/insights',$one)['body'];if(!is_array($part['data']??null)||count($part['data'])!==count($r['data']??[])||self::after($part)!==self::after($r))throw new Fault('coverage_incomplete','Página de resultado opcional mudou.');$values=[];foreach($part['data'] as $row){if((string)($row['account_id']??'')!==$i['account_id']||($row['date_start']??'')!==$day||($row['date_stop']??'')!==$day)throw new Fault('upstream_invalid','Resultado opcional de outro recorte.');$values[(string)($row[$level.'_id']??'')]=$row[$f]??null;}foreach($r['data'] as $row)if(!array_key_exists((string)($row[$level.'_id']??''),$values))throw new Fault('coverage_incomplete','Entidades mudaram entre consultas opcionais.');$optional[$f]=$values;}
                catch(Fault $fieldError){if(!in_array($fieldError->reason,['upstream_validation','coverage_incomplete'],true))throw $fieldError;$missing[]=$f;$errors[]=['field'=>$f,'date'=>$day,'code'=>$fieldError->reason==='coverage_incomplete'?'optional_page_changed':'unsupported_for_asset_or_version','observed_at'=>time()]+$fieldError->details;}
            }
        }
        if(!is_array($r['data']??null)||count($r['data'])>$limit)throw new Fault('upstream_invalid','Página de anúncios inválida.');$rows=[];
        foreach($r['data'] as $raw){
            if(!is_array($raw)||(string)($raw['account_id']??'')!==$i['account_id']||($raw['date_start']??'')!==$day||($raw['date_stop']??'')!==$day||($raw['account_currency']??'')!==$meta['currency'])throw new Fault('upstream_invalid','Conta, dia ou moeda divergente nos insights.');
            $entity=Util::numeric((string)($raw[$level.'_id']??''));foreach($optional as $field=>$values)$raw[$field]=$values[$entity]??null;foreach($missing as $field)unset($raw[$field]);$row=array_fill_keys(self::names(),null);
            foreach(self::BASE as $f)if(array_key_exists($f,$raw))$row[$f]=$raw[$f];
            foreach(['account_id','campaign_id','adset_id','ad_id'] as $idField)if($row[$idField]!==null)$row[$idField]=Util::numeric((string)$row[$idField]);
            foreach(['spend','impressions','reach','frequency','clicks','inline_link_clicks'] as $f){if(isset($row[$f])&&(!is_string($row[$f])||!preg_match('/^[0-9]+(?:\.[0-9]+)?$/D',$row[$f])))throw new Fault('upstream_invalid','Valor numérico de anúncio inválido.');}
            if($row['spend']===null||$row['impressions']===null||$row['clicks']===null)throw new Fault('upstream_invalid','Métricas básicas de anúncios ausentes.');
            foreach(['actions','cost_per_action_type','results','cost_per_result'] as $f){if(isset($raw[$f])){if(!is_array($raw[$f]))throw new Fault('upstream_invalid','Resultados tipados inválidos.');$row[$f]=$raw[$f];}}
            $unavailable=$missing;foreach(['reach','frequency','inline_link_clicks','results','cost_per_result'] as $f)if($row[$f]===null&&!in_array($f,$unavailable,true)){$unavailable[]=$f;$errors[]=['field'=>$f,'entity_id'=>$entity,'date'=>$day,'code'=>'value_unavailable','observed_at'=>time()];}
            // Do not sum aggregate "lead" with native/site actions: they overlap.
            foreach($row['actions']??[] as $action){if(!is_array($action)||!is_string($action['action_type']??null)||!is_string($action['value']??null)||!preg_match('/^[0-9]+(?:\.[0-9]+)?$/D',$action['value']))throw new Fault('upstream_invalid','Ação de anúncio inválida.');if($action['action_type']==='onsite_conversion.lead_grouped')$row['leads_native']=$action['value'];if($action['action_type']==='offsite_conversion.fb_pixel_lead')$row['leads_website']=$action['value'];}
            $row['creative_availability']=$level==='ad'?'unavailable':'not_applicable';
            if($level==='ad'){
                try{$ad=Http::request($c,$entity,['fields'=>'id,account_id,creative{id,name}'])['body'];if((string)($ad['id']??'')!==$entity||(string)($ad['account_id']??'')!==$i['account_id'])throw new Fault('asset_access_denied','Anúncio de outra conta.');if(!empty($ad['creative']['id'])){$row['creative_id']=Util::numeric((string)$ad['creative']['id']);$row['creative_name']=is_string($ad['creative']['name']??null)?$ad['creative']['name']:null;$row['creative_availability']='available';}else throw new Fault('resource_not_found','Criativo indisponível.');}
                catch(Fault $e){$e=CollectionState::classify($e,$c);if(!in_array($e->reason,['resource_not_found','upstream_validation','asset_access_denied'],true))throw $e;$unavailable[]='creative_id';$errors[]=['field'=>'creative_id','entity_id'=>$entity,'date'=>$day,'code'=>'creative_unavailable','observed_at'=>time()]+$e->details;}
            }
            $rows[]=$row+['id'=>$entity,'entity_id'=>$entity,'date'=>$day,'ads_level'=>$level,'attribution'=>self::ATTRIBUTION,'availability'=>'available','unavailable_fields'=>$unavailable,'lead_action_types'=>['native'=>'onsite_conversion.lead_grouped','website'=>'offsite_conversion.fb_pixel_lead'],'results_semantics'=>'typed_provider_values; no_primary_result_inferred'];
        }
        $after=self::after($r);$next=$after?['day'=>$day,'after'=>$after]:($day>$i['date_from']?['day'=>gmdate('Y-m-d',strtotime($day.' UTC')-86400)]:null);
        return ['rows'=>$rows,'next'=>$next,'fields'=>self::names(),'errors'=>$errors,'warnings'=>['Ausência não equivale a zero. Leads agregados podem se sobrepor aos tipos nativo/site.','Reach e frequency são valores únicos do recorte; não somar dias ou entidades.','Metadados de nomes/criativo são observados na coleta; não reconstituem versões históricas.','O limite histórico depende do fornecedor; período vazio não prova cobertura integral.'],'origin_complete'=>false,'timezone'=>$meta['timezone'],'currency'=>$meta['currency'],'temporal'=>'daily'];
    }
}
