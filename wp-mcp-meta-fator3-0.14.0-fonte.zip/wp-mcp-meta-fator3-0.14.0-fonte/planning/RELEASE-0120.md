# Plano — Fator3 MCP Meta 0.12.0

26/10/2026, America/Sao_Paulo. Base aceita 0.11.1: instalador b084bf2498eddc0eb93410c04efdd166ba84b2831541e2b5a2acf8dcfe3aa6c1; fonte e12e1d6f3a9b9daa8907840bdda40903ec307596971cdff458e7de88a25415b1. Alvo minor 0.12.0 previsto, ainda não instalado. Instruções comuns revisão 5 prevalecem sobre r4 reanexada e preservam a ordem explícita de usar impactos para consequências/pedidos, não respostas.

Entrada nova: impacto Core 1.56.0 → Meta, revisão 1, MCP Meta18(b)/Core309. Core 1.56.0 implementou o consumidor instagram-first-message/1.0.0, mas solicita exclusão pública dos identificadores locais do Meta após eliminar contato, inclusive com token revogado ou conexão removida. O código e os relatórios recebidos são examinados separadamente de prova própria. Site-Teste já possui Core1.56.0 e Meta0.11.1; nenhuma instalação alheia é necessária.

## Implementação prevista

Contrato aditivo instagram-message-erasure/1.0.0 pelo SDK Fator3\Meta\Messaging: introspecção/schema, estado/revisão opaca, eliminação por conexão/conta + exatamente um event_id ou sender_id, consulta de recibo. Autorização administrativa e concessão MCP corrente quando presente; sem exigir token, vínculo remoto ou existência da conexão, sem Graph. Manter contrato de ingestão e 41 abilities.

Antes de remover o registro message_event, persistir bloqueio durável com HMAC escopado, sem identificadores de remetente/mensagem/contato. Trava comum com receive/process; revisão, idempotência e recibo verificáveis; falha não é conclusão e repetição autorizada retoma a mesma requisição. Não iniciar transação que possa confirmar transação alheia. Continuações de cron da conta são removidas, e geração de privacidade impede um worker concorrente de agendar cursor anterior à exclusão. Bloqueios/recibos não sofrem limpeza por retenção e sobrevivem à limpeza do diário de eventos; chaves e backup coordenado são necessários. Não apagar dado no Core, Graph, backups ou respostas já entregues ao cliente.

A retenção sem expiração continua como padrão. A eliminação explícita prevalece sobre retenção; não há exclusão automática nem reativação de contatos. Documentar limites: escopo conexão/conta, reuso de mesmo escopo permanece bloqueado, nova identidade de conexão não é inferida; dados remotos lidos novamente não são promessa de exclusão Graph.

## Provas

Instalação limpa no WP/PHP corrente e mínimo exato; atualização direta 0.11.1 preservando dados/configurações; casos pending/reserved/uncertain/persisted/suppressed/evidence_changed; repetição/conflito de chave/revisão; isolamento entre remetentes/contas/conexões; ausência/revogação de conexão; rejeição a assinante/anônimo; falha de banco e retomada; tentativa concorrente/reentrante; limpeza do diário + reinício; remoção de cron e bloqueio do agendamento obsoleto. Integração com consumidor Core1.56.0 real e HTTP sintético, sem contatos/avisos reais. Conferir 41 abilities e documentação completa via MCP, preservar acompanhantes, limpar laboratório.

## Encaminhamentos

Não emitir novo impacto apenas como resposta ao SDK solicitado. Implementação, schema/versão e evidências serão registrados no relatório principal com referência ao impacto Core recebido. Core1.56.0 não chama a futura exclusão: sua integração posterior e confirmação de privacidade continuam com o mantenedor Core. Só emitir impacto novo se surgir consequência/pedido distinto durante implementação. Nenhum contato a terceiros, push ou implantação na frota.

## Resultado da rodada

Implementado e instalado no Site-Teste em 26/10/2026: 0.12.0, instalador SHA-256 b519203886d0964fa531c70cd0a66e2f8e199ff04700f0c3c5fa946d6d83e880. Provas e tratamento do impacto Core recebido estão no relatório principal. Não surgiu encaminhamento técnico adicional independente do pedido recebido; nenhum novo arquivo de impacto. Core1.56.0 continua pendente de integrar a chamada automática de exclusão. Laboratórios e controlador temporário removidos; 23 documentos instalados lidos integralmente e comparados ao pacote.
