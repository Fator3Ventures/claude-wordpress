# Plano — Fator3 MCP Meta 0.13.0

28/10/2026, America/Sao_Paulo. Base aceita 0.12.0, instalador SHA-256 b519203886d0964fa531c70cd0a66e2f8e199ff04700f0c3c5fa946d6d83e880. Alvo minor 0.13.0 previsto; instalador ainda não gerado. Pedidos MCP Meta 20 e 21 no documento recebido de 28/10/2026. A instrução expressa do item 20 inclui Meta Ads de leitura no pacote e prevalece sobre a exclusão desse domínio nos padrões antigos. Instruções comuns revisão 5 preservadas no fonte-base; a ordem do dono para impactos somente com consequências/pedidos continua prevalecendo sobre a r4 reanexada.

## Implementação

20: canal/ativo ads nas conexões existentes, ads_read e GETs allowlisted, sem escrita em anúncios. Relatório ads_insights por account/campaign/adset/ad, time_increment=1, moeda/fuso originais, ações/resultados com tipos, nomes/IDs e metadados de criativo quando disponíveis. Valores de contagem/moeda como strings, ausência como null, sem somar ações sobrepostas nem inventar resultado principal. Calendário da conta; atribuição declarada no payload. Usar histórico cifrado existente, identidade estável dia/nível/entidade/atribuição, sem prazo e revisita sem dupla contagem; backfill explícito paginado e retomável, limite real do fornecedor informado, cobertura sem sucesso presumido. Agendas diárias, CSV/JSON, filtros de nível no acervo e interface existente.

SDK local meta-ads-reader/1.0.0: consumidor registrado por identidade de objeto e callback {connection_id,account_id,revision,ready}; concessão administrativa explícita por consumidor/conexão/conta, default desligado. Leitura do acervo sem token exposto nem chamadas Graph. Cursor vinculado a consumidor, concessão, seleção e geração do acervo; revogação e alteração de identidade impedem continuação. Conexão/conta ligam gasto a contatos apenas no consumidor Core, sem atribuição comercial inferida no Meta. Novo impacto Core emitido antes do código do SDK: impacts/wp-mcp-meta-fator3-0.13.0-impacto-base-site-core-fator3.md.

21: preservar métricas disponíveis e registrar lacunas/recusas por métrica. Distinguir falhas de campo de revogação, quota e transporte. Coleta parcial informa successful_rows e métricas indisponíveis; last_success_at avança somente depois de persistência útil; last_partial_at separado. Health conta parciais e falhas separadamente. Guardas existentes de autorização, credenciais, revisão e incidentes continuam.

## Validação

Reproduzir métrica vazia/suprimida/recusada junto de métricas válidas, todos os campos sem dado, falha global, múltiplas páginas e retomada. Ads: conta ausente, ads_read ausente, escopo cruzado, 30 dias sintéticos nos quatro níveis, valores monetários, resultados por tipo, criativo indisponível, paginação, revisão, quota, acervo/retroativo/revisita/sem expiração, exportação, agendas e SDK com concessão/revogação/identidade/cursor. Atualização direta preserva dados da 0.12.0. Regressão da exclusão com Core1.57.1 original. Matrizes WP7.1.3/PHP8.3.36 e WP6.4/PHP8.1.2; UI, documentação MCP integral e integridade dos acompanhantes. Produção/frota não serão alteradas nesta rodada; aceite real Ads Manager permanece com operador/frota após implantação autorizada.

## Atualização dos acompanhantes durante a rodada

O inventário inicial tinha Google0.20.0/Pipedrive0.2.0; antes da integração isolada, o Site-Teste recebeu Google0.21.0/Pipedrive0.3.0 por outras rodadas. Os novos instaladores, fontes e relatórios foram recuperados e examinados, incluindo impacto Google39/Core316. Alterações restritas a conversões/diagnóstico Google e relatório agregado Pipedrive, sem pedido adicional ao Meta. Manifesto integrado atualizado para os pacotes novos; nenhum downgrade ou alteração de acompanhante. Diferenças iniciais de hashes ficam registradas como mudança concorrente do ambiente, não regressão Meta.

## Fechamento da implementação

Instalador 0.13.0 congelado e instalado: 284069 bytes, SHA-256 3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1. O texto inicial deste plano registra a condição de planejamento; não é o estado final. Nenhum runtime alterado após instalação. Evidências finais, pendências e respostas no relatório principal.

MCP avançou a 0.34.0 antes da instalação final. Guia instalado 69–73 examinado (diagnóstico, logs, recibos de upload, pré-imagens/poda e sonda served), fronteiras de identidade/autorização preservadas; a fonte instalada de ConnectionContext é igual à base recebida 0.33.0. Não apareceu pacote 0.34.0 nas duas buscas realizadas: tratou-se o runtime observado como evidência distinta de ZIP recebido. A suíte integrada passou 27/27 com essa versão, incluindo recibos e perfis, além da instalação e leitura documental reais pelo transporte. Não se identificou novo pedido de mudança ao Meta nessa fronteira.

Impacto Core revisão 2 detalha identidade moeda/fuso, valores anteriores com data, geração do cursor e origem administrativa da concessão. A revisão não comunica encerramento; o consumidor Core segue por implementar pelo responsável. Nenhum impacto novo ao LinkedIn foi identificado no escopo exercitado.
