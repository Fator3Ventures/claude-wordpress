# Meta 0.8.0 — plano de revisão e implementação

23/10/2026. Base corrente 0.7.1, instalador SHA-256 0adbea179f3a89cd66b6dce289fa8658e1723f4a9b38568794fc7c3aea5963f2. Alvo previsto 0.8.0; instalador ainda não gerado. Pedido desta rodada: considerar novos pacotes, pedidos e impactos e implementar nova versão. A aba Meta(6) diz nenhum pedido aberto; não foi criado número de backlog.

Acompanhantes recebidos e já ativos: Core 1.49.1, MCP 0.29.1, Google 0.18.1, LinkedIn 0.9.0. Hashes conferidos contra seus relatórios. Impacto MCP: conservar efeitos incertos e não inferir applied=false de retryable; nenhuma alteração de envelope por suposição. Impacto LinkedIn 0.8.1 revisão 2 encerra R1/R2 pela resposta Meta; o pedido LinkedIn 12 foi implementado na 0.9.0, com decodificação do snapshot exato.

Hipótese a reproduzir no Meta 0.7.1: Queue::isolate lê revisão/payload e depois Store::get faz outra leitura para decidir legibilidade. Um gravador externo que não respeite a trava e restaure o snapshot anterior entre as leituras e o UPDATE pode fazer o CAS aceitar um payload legível. A gravação normal Store::put não reduz revisão; o cenário é de restauração/gravador externo. Testar em tabela exclusiva, com outra conexão MySQL e interleaving determinístico, antes de alterar runtime. Se reproduzido, decodificar o mesmo snapshot usado no CAS, preservando todos os códigos/guards. A 0.9.0 do LinkedIn já faz isso; não há nova demanda a esse destinatário.

Validação: reprodução negativa; candidato com snapshot exato, erro SQL/cifra/JSON, locks/CAS, sem reativação; regressões existentes; atualização direta 0.7.1, clean e mínimos quando executáveis; integração real com os quatro pacotes; documentação MCP completa; limpeza e versão final. Sem fornecedor/e-mail real. Sem alterações em código alheio, docs centrais ou frota.

Impactos: nenhum novo encaminhamento necessário até aqui; manter e encerrar a emissão própria 0.7.1 → LinkedIn com a resposta recebida e revisão estática do código 0.9.0. Registrar descobertas que afetem contratos antes de implementar a parte dependente.

## Confirmação e implementação

A reprodução 0.7.1 no Site-Teste, WP 7.1.3/PHP 8.3.36, confirmou o achado: snapshot final legível, revisão/payload restaurados, projeção indevida unreadable. Oito checks: duas falhas esperadas (comportamento e duas leituras), seis controles passaram. Prova em evidence/release080/negative071.json. A tabela exclusiva e a sonda foram removidas. Implementação limitada a decodificação comum e uso do snapshot exato; documentação do MCP atualizada sem mudança de envelope. Nova rodada usa minor 0.8.0 conforme padrão; não cria pedido 15.

## Validação e entrega

0.8.0 instalada no Site-Teste: 168 checks integrados, 137 no mínimo WordPress 6.4/PHP 8.1.2-1ubuntu2.28, cinco de atualização direta 0.7.1 com dados e 101 de metadados após atualização. Selftest oito checks; 17 documentos via MCP em 21 chamadas, bytes/hashes iguais ao instalador. Nenhum fornecedor/e-mail real. Instalador final 153819 bytes, SHA-256 36e4e098955576c3d43ea1b1bd2c14fe68608472b8666a652e84da5165ce25e1. As demais execuções intermediárias ficam identificadas no relatório.

Impacto próprio 0.7.1 → LinkedIn encerrado na revisão 4 por resposta recebida e inspeção da 0.9.0; nenhum novo encaminhamento necessário. Read/custom/maintenance e recibo de efeito desconhecido confirmados com MCP 0.29.1. Runtimes dos cinco pacotes conferidos, zero divergências. Sondas, laboratórios e fixtures removidos; Meta saudável e ativo. Não houve atualização de frota, publicação ou alteração de documento central.
