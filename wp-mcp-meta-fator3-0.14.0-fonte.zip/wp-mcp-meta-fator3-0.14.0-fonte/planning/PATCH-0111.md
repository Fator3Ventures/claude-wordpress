# Patch 0.11.1

A inspeção documental após instalar a 0.11.0 encontrou instruções correntes antigas (auditoria 30 dias, exportação 24h, 35 operações e ausência genérica de SDK). Corrigir somente documentação e identificação da versão, preservar código funcional/JS/schemas. Incremento de patch porque o pacote anterior já foi instalado. A base funcional de referência continua 0.10.1, testada diretamente; a 0.11.0 não é pré-requisito. Repetir comparação normalizada de runtime, lint, mínimo/upgrade e documentação MCP do patch. O único impacto técnico desta rodada permanece a demanda ao Core309; a correção documental não cria outro encaminhamento.

Identidade final do encaminhamento originalmente planejado na 0.11.0: impacts/wp-mcp-meta-fator3-0.11.1-impacto-base-site-core-fator3.md (revisão técnica 3, demanda Core309 aberta; alvo final ajustado antes da entrega). O relato de implementação e instalação fica no relatório principal.
