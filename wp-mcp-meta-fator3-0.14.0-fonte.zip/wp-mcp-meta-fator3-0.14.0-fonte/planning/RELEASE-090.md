# Plano — Fator3 MCP Meta 0.9.0

23/10/2026 · Implementação do Pedido MCP Meta 15 / D-20261023-50.
Base aceita 0.8.0; instalador 153819 bytes, SHA-256 36e4e098955576c3d43ea1b1bd2c14fe68608472b8666a652e84da5165ce25e1. Alvo previsto 0.9.0; instalador ainda não fechado.

## Escopo e sequência

1. Conferir fontes/pacotes e instruções revisão 5. Site-Teste observado: Core 1.50.0, MCP 0.29.1, Google 0.19.0, LinkedIn 0.9.0 e Meta 0.8.0 ativos.
2. Validar formato e debug_token com o aplicativo antes de qualquer persistência de credenciais. Confirmar identidade por /me, expiração e acesso aos ativos selecionados; preservar tudo em recusa.
3. Gravar conexão, revisões de agendas e evento de histórico de alteração numa transação InnoDB sob travas; preservar principal, estado, datas e progresso. Mudanças de seleção/autorização continuam exigindo revisão explícita. Nunca reautorizar concessão revogada.
4. Acrescentar meta/switch-identity com dry_run, expected_revision e confirmação temporária vinculada ao candidato, ator, conexão e agendas. Prévia sem alteração de configuração; revalidar no commit. Jobs já iniciados de outra identidade ficam sujeitos à revisão anterior; não misturar cursores/identidades.
5. Rótulos e ajudas literais do pedido, resumo de identidade, escopos excedentes, validade remota e atualização de versão da tela. Mensagens em português, sem segredos.
6. Testes negativos, falha de persistência, concorrência e autorização; instalação limpa e atualização direta 0.8.0, mínimos, interface/DOM, regressões afetadas, convivência e documentação pelo MCP. HTTP do fornecedor interceptado, sem contas reais disponíveis.
7. Instalar somente no Site-Teste, retirar auxiliares e entregar fonte, instalador e relatório com hashes.

## Fronteiras e impactos

Avaliação inicial: mudanças internas do Meta e operação aditiva descoberta pelo MCP existente. Nenhuma adaptação obrigatória identificada em Core, LinkedIn, Google ou MCP. Credenciais e ingestão comercial do Core permanecem próprias; não revogar tokens na Meta. Nenhum arquivo de impacto será emitido apenas para responder/encerrar pedidos, anunciar versão ou declarar ausência de ação. Tratamento dos impactos recebidos e históricos ficará no relatório principal, conforme revisão 5. Novos achados com consequência real serão documentados antes de implementar a fronteira afetada.

## Limites previstos

Sem homologação em fornecedor real, sem publicação em repositório ou atualização da frota. Pendências 20/88 da frota não são encerradas. Formatos locais do token/App ID são os exigidos pelo pedido, não uma garantia universal da Meta. Nomes ausentes no fornecedor não serão inventados.

## Fechamento executado

Candidato final: 173724 bytes; SHA-256 e26aede1591426e06b8a69b5ad405cf13cb70c28d41b607346188c9d21a15662. Instalação direta e mínimo comprovados; relatório final descreve as provas e a pendência de fornecedor. Acompanhante LinkedIn foi atualizado por outro responsável durante a rodada: 0.9.0 → 0.10.0 → 0.10.1. Convivência final em 0.10.1 via catálogo, documentação e chamada real, sem artefato final recebido para comparar seus bytes. O contrato aditivo do Meta não exigiu adaptação; a projeção identity resolve o filtro do MCP no próprio emissor. Não há novo relatório de impacto.
