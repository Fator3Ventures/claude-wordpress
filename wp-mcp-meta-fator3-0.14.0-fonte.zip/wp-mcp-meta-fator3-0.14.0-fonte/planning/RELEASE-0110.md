# Plano — Meta 0.11.0

26/10/2026. Base aceita Meta 0.10.1 (instalador f80d934fe1851bc887a0174190b42d73b36a8637f2f4824bdb5cfeb7a674ee95; fonte e333d22a82599e08c015002bb2ea6536a98ddacbfc68ede82a422733e135e908). Alvo previsto 0.11.0, instalador ainda não fechado. Pedidos MCP Meta 18 e 19; instruções revisão 5 prevalecem sobre revisão 4 reanexada.

## Implementação

- 18: consulta paginada somente leitura de conversas/mensagens sem solicitar ou guardar texto. Datas e contagem por dia têm cobertura explícita: primeira mensagem disponível na API, nunca promessa de histórico integral. Referências de anúncio, Story e ig.me só com evidência entregue; ausência permanece desconhecida. Webhook dedicado com assinatura do app, verificação de challenge, alvo selecionado, replay idempotente, projeção mínima cifrada e retenção limitada. Configuração separada por conexão/ativo, revisões, principal e aprovação do app declarada separadamente da prova técnica. Health/tela informam escopos ausentes e aprovação não comprovada.
- 18(b): contrato local de eventos mínimos para consumidor Site Core, autorização explícita e desligado por padrão. Core 1.55.0 não implementa o pedido 309. O contrato de contato externo 302 é administrativo/manual e não comprova deduplicação por identidade Instagram nem política de ingresso automático. Não apresentar essa integração como operacional antes do consumidor; encaminhamento técnico ao Core antes da implementação da fronteira.
- 19: catálogo aditivo de follows/profile_visits/profile_activity/shares/total_interactions/link_clicks para Stories e métricas de post/carrossel; detalhamento action_type/story_navigation_action_type e media_product_type quando solicitado e suportado. Sem somar buckets ou inferir orgânico/pago. Não consultar filhos de carrossel como álbum.
- 19: arquivo privado cifrado de Stories apenas em coletas (consulta simples continua sem gravação de arquivo): data/tipo/permalink/legenda e miniatura reduzida, com limites por item, total e prazo independente da retenção ilimitada de métricas. Nenhum arquivo público de mídia. Diagnósticos distinguem regra conhecida comprovada, supressão possível e causa desconhecida; erro 10 genérico não prova limiar de audiência.

## Acompanhantes e impacto

Core 1.55.0 e MCP 0.33.0 anexados; Google 0.19.0, LinkedIn 0.10.1, Pipedrive 0.1.0 observados no Site-Teste. Fronteiras de autorização/redação/descoberta serão testadas. Novo encaminhamento: `wp-mcp-meta-fator3-0.11.0-impacto-base-site-core-fator3.md`, acao-necessaria para 18(b)/Core309. Nenhuma mudança em pacote alheio. Impactos históricos ficam no relatório principal, sem reemissão de encerramento.

## Provas

Fixtures de Graph/webhooks, assinatura errada, cross-account, replay, echo, permissões/principal revogados, paginação interrompida e origem desconhecida; leitura sem texto e sem gravações de domínio; ausência do Core/consumidor; prévias e fluxo de contato somente com consumidor sintético. Métricas por tipo, breakdown, limiar confirmado versus erro genérico, carrossel filho, download privado seguro/limites, retenção e leitura após expiração do Story. Instalação limpa no mínimo exato, atualização direta 0.10.1, integração com acompanhantes, painel DOM, health/documentação pelo MCP e limpeza do laboratório. Credenciais reais/aprovação Meta e validação ctooffice continuam com operador; só Site-Teste é mutável nesta tarefa.

## Alteração explícita de escopo em 26/10/2026 — retenção máxima

O responsável pediu aumentar ao máximo a retenção. Substituir limites temporais/totais iniciais por preservação ilimitada de histórico, resultados, auditoria, exportações, Stories e metadados/recibos de conversas. Manter limites por requisição, imagem e prazos de segurança (cursores/confirmações/tokens), sem ampliar coleta para texto de chats. Upgrade direto amplia prazos dos dados existentes e política das conexões; testar essa mudança intencional e preservação das demais configurações. Não há pacote final publicado/instalado: permanece candidato 0.11.0.
