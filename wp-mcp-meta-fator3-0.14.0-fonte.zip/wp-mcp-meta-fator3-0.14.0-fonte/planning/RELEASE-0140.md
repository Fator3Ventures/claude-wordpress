# Plano — Fator3 MCP Meta 0.14.0

28/10/2026, America/Sao_Paulo. Implementação do Pedido MCP Meta 22 sobre a base aceita 0.13.0, instalador SHA-256 3ecd6ee6f277c7581adc05b4fa38c46611e3232b4400bb4a4421956c9fba8ac1. Alvo minor 0.14.0 previsto; instalador ainda não gerado. Instruções revisão 5 preservadas no fonte prevalecem sobre as cópias r4 reanexadas, especialmente a orientação expressa de impactos somente para consequências e pedidos.

## Escopo

Remover a exigência local de prefixo EAA em Credentials::format, compartilhada por save-connection, rotate-token e switch-identity. Preservar limites de 100–16384 bytes, ausência de espaço/controle, recusa de App Secret, prova de app/identidade/escopos/ativos, CAS, confirmação da troca e gravação atômica das agendas. Atualizar ajuda e documentação sem alterar schemas públicos, contratos SDK, banco, retenção ou concessões. Não fixar credential_generation em 5: ela deve avançar uma unidade a partir da geração real; o aceite indicado começa em 4.

## Novos pacotes e fronteiras

Core 1.59.0, MCP 0.35.0, Google 0.22.0 e LinkedIn 0.12.0 recebidos e observados ativos no Site-Teste; Pipedrive 0.3.0 preservado. Fontes/relatórios/instaladores conferidos. Core examinado já registra o consumidor meta-ads-reader/1.0.0; corrigir a documentação corrente que tratava sua implementação como pendente. O impacto Meta0.13→Core será acompanhado no relatório principal, sem reemissão de encerramento. MCP0.35 atende o consumidor comercial LinkedIn; Google/Core têm reconciliação comercial própria, sem alterar a fronteira Meta.

Não há novo impacto técnico identificado que exija adaptação de outro pacote: a correção interna admite tokens opacos somente após a conferência remota já existente. Não gerar arquivos de impacto por aviso de versão ou resposta. Testar os contratos integrados pertinentes com os pacotes originais e registrar limites de fornecedor separadamente.

## Provas previstas

Reproduzir recusa na base com token sintético alfanumérico de 199 caracteres começando com E e não EAA. Na candidata, provar salvamento, renovação e prévia/confirmação de troca; geração 4→5, identidade e ads_read, preservação de agendas. Tokens EAA continuam válidos; tamanho, espaços/controles, App Secret, token revogado, app/identidade/escopos divergentes, confirmação/revisão inválida e permissões insuficientes continuam recusados sem mudar dados. Provar interface e REST/MCP pertinente, sem segredo nos retornos/auditoria.

Instalação limpa e upgrade direto 0.13.0→0.14.0 com dados/credenciais/agendas/Ads/grants preservados. WP7.1.3/PHP8.3.36 e mínimo WP6.4/PHP8.1.2; regressões de credenciais, Ads/parcial e SDK Core. Instalador final, inventário antes/depois, selftest e leitura integral dos 25 documentos pelo MCP. Limpar apenas laboratório e controladores próprios.

Homologação do token real e geração observada em ctooffice.com.br pertence ao operador/frota; não acessar seu token nem alterar produção nesta rodada. Nenhum contato, mensagem, anúncio ou notificação real será enviado. Autorizações anteriores cobrem Site-Teste, arquivos e banco isolado.

## Ambiente observado

O Site-Teste já está em WordPress7.1.4/PHP8.3.36, observado antes de qualquer troca Meta. A matriz corrente usa essa versão em vez de7.1.3, mantendo o mínimo6.4/8.1.2. A reprodução na0.13.0 confirmou recusa sem HTTP. A primeira fixture nova esperava geração inicial1, mas a base normaliza em1 e o primeiro token validado resulta em2; a expectativa foi corrigida para preservar a semântica existente, sem alterar o runtime. A sequência exercita depois4→5.

## Fechamento executado

0.14.0 instalada no Site-Teste, instalador de 286331 bytes, SHA-256 43e8947ac0ffaf3da52c62b0515db826e6df266553d64f5561c0d3b87b7eb318. Matriz efetiva: WP7.1.4/PHP8.3.36 e WP6.4/PHP8.1.2-1ubuntu2.28, MySQL8.0.41. O seed do upgrade prova registros, histórico, configuração e agenda; Ads/grants foram testados em regressão/integração separada, não como seed desse upgrade.

Pedido22: 53/53 em cada runtime. Core Ads1.59.0: 41/41 na primeira chamada em laboratório recém-criado, após corrigir somente a fixture para recarregar o usuário depois de alterar suas capacidades. Core privacidade:20/20. Documentação25/25 e catálogo44/44 por MCP; auxiliares e laboratório removidos. Sem novo impacto; resposta ao Core no relatório principal. Provas e limites detalhados no relatório; homologação real/implantação de frota permanecem com os respectivos responsáveis.
