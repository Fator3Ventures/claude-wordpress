# Plano — Meta 0.10.0

24/10/2026. Implementação dos Pedidos MCP Meta 16 e 17, base aceita 0.9.0 (instalador e26aede1591426e06b8a69b5ad405cf13cb70c28d41b607346188c9d21a15662). Instalador-alvo ainda não fechado.

Pedido 16: prévia junto da origem, foco/anúncio acessível, erro local, label vinculado à confirmação e à transação conexão/agendas.

Pedido 17: distinguir indisponibilidade de Story de revogação confirmada da conexão; diagnóstico estruturado e durável nas agendas e auditoria das coletas; um aviso por incidente com causa e ação medidas. Não deduzir revogação a partir de falha isolada de recurso.

Acompanhantes: Core 1.51.0, MCP 0.30.1, Google 0.19.0, LinkedIn 0.10.1 e Pipedrive 0.1.0. Não há consequência técnica identificada que exija alteração destes pacotes; nenhuma emissão de impacto prevista. Revisar contratos de descoberta/redação e isolamento, inclusive Pipedrive. Impactos históricos recebidos são acompanhamento no relatório principal. Regra de impactos revisão 5 e instrução explícita do dono prevalecem sobre a revisão 4 reanexada.

Provas: WordPress descartável atual e mínimos exatos, atualização 0.9.0, regressões de credenciais/fila, duas identidades sintéticas, Stories vencidos/rejeitados/sem métrica, token revogado, persistência de códigos, incidentes e recuperação, DOM real do painel, integração e documentação pelo MCP do Site-Teste. HTTP e correio sintéticos. Não alterar frota, regra central nem plugins alheios.
