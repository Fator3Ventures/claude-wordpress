# Fator3 MCP Meta 0.14.0

Base direta aceita: 0.13.0. Pedido MCP Meta 22, de 28/10/2026. A validação local do token deixa de exigir EAA em save-connection, rotate-token e switch-identity. Mantém tamanho de 100–16384 bytes, recusa de espaços/controles e App Secret, prova remota de app/identidade/permissões/ativos, revisão, confirmação e transações. A geração avança a partir do estado real; não foi fixada em 5.

A retenção ampliada, Stories, mensagens, privacidade, Meta Ads somente leitura e coletas parciais permanecem. Core 1.59.0 já registra meta-ads-reader/1.0.0. A resposta ao pedido anterior foi validada e documentada no relatório principal. Não houve novo impacto técnico que exigisse adaptação dos acompanhantes; impactos não são usados para respostas ou encerramentos.

Código canônico: build/common, build/meta e build/assets. Documentação instalada: build/docs/meta. Runtime plugin/wp-mcp-meta-fator3 idêntico ao instalador testado: 59 arquivos, 30 PHP, 25 documentos e 44 operações. inputs/0.14.0 contém novos pedidos, relatórios e hashes. A revisão 5 das instruções, preservada em inputs/0.12.0, prevalece sobre a r4 reanexada. Plano em planning/RELEASE-0140.md. History contém evidências históricas, não novas provas.

Build: F3_SOCIAL_PHP=/caminho/php python3 build/build.py. Empacotamento: python3 tools/package-source.py --output-dir /diretorio/externo. Apenas o instalador entra no WordPress. O fonte não contém ZIP aninhado, banco, tokens reais nem node_modules. O relatório interno é anterior ao fechamento; bytes/hash final do fonte constam no relatório externo. O instalador instalado não deve ser regenerado silenciosamente.

Reprodução nativa: python3 tools/build-isolated0140-probe.py --baseline <runtime-0130> --candidate <runtime-0140> --output <fora-do-fonte>. Controlador restrito ao Site-Teste, diretório e prefixo SQL exclusivos. Fixtures bloqueiam fornecedores e e-mail; não instalar auxiliares em produção. PHP mínimo reproduzido com pacotes oficiais e hashes de tools/php81-lock.json. A ferramenta de estado compartilhado retorna apenas contagens/digests, sem conteúdo de negócio.

Matriz executada: WP 7.1.4/PHP 8.3.36 e WP 6.4/PHP 8.1.2-1ubuntu2.28, MySQL 8.0.41. Atualização direta 0.13.0→0.14.0 conserva registros, ciphertext, histórico, configurações, agendas e políticas de retenção do seed. Ads/grants são exercitados separadamente nas regressões e integração, sem alegar seed de upgrade que não existiu. Core 1.59.0, MCP 0.35.0, Google 0.22.0, LinkedIn 0.12.0 e Pipedrive 0.3.0 conferidos contra os runtimes dos pacotes recebidos.

Evidências atuais em evidence; nomes históricos das suítes indicam sua origem, não a versão carregada. Development0140 conserva falhas de fixtures: geração inicial esperada incorretamente e cache de capacidades do usuário após mudança de papel no teste Core Ads. Corrigidas somente nos testes; cenário Core Ads repetido do zero com 41/41. Não houve teste nativo MariaDB, inspeção visual em navegador ou homologação de fornecedor real. UI: 25 verificações com HTML WordPress e jsdom/REST simulado.

A 0.14.0 está ativa no Site-Teste. Registros, histórico, sete opções e cinco acompanhantes foram comparados imediatamente antes/depois; sem alterações de negócio. A homologação do token real do CTO Office, o confronto Ads de 30 dias e a próxima execução agendada ficam com operador/frota. Nenhum ambiente de produção foi alterado, anúncio escrito ou contato/notificação real enviado.

Rollback para 0.13.0 não exige reversão de banco. Preserve banco, salts, chave de privacidade, recibos, bloqueios e retenção. O pacote anterior mantém os dados gravados, mas volta a rejeitar novas provas/renovações de token sem EAA. Não restaure token revogado nem apague acervo para resolver falha de credencial.


Fechamento: os 25 documentos instalados foram lidos integralmente pelo MCP e comparados ao instalador (220502 bytes); 44 operações finais, sem QA. Laboratórios, tabelas exclusivas, dois controladores e bundle foram removidos. Ver evidence/documentation0140-proof.json e catalog0140-final.json.
