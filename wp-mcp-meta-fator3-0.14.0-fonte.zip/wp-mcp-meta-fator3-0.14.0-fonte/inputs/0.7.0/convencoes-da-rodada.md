# Convenções da rodada (ordem do dono, 22/10/2026, chat do Orquestrador | Geral)

Pedido do dono: analisar em conjunto os cinco pacotes e, para cada um, elaborar nova versão com melhorias no código e nos testes, melhorias de funcionalidade e funcionalidades novas pertinentes. Saída por pacote: exatamente três arquivos (relatório, instalador, fonte).

## Versões
| Pacote | Slug | Base (instalador recebido) | Alvo |
|---|---|---|---|
| Fator3 Site Core | base-site-core-fator3 | 1.48.0 (sha256 91097a38…, 2217146 B) | 1.49.0 |
| Fator3 MCP | wp-mcp-fator3 | 0.28.0 (d1d297d8…, 853885 B) | 0.29.0 |
| Fator3 MCP Google | wp-mcp-google-fator3 | 0.17.0 (42bd1108…, 767299 B) | 0.18.0 |
| Fator3 MCP Meta | wp-mcp-meta-fator3 | 0.6.0 (36f5cfe9…, 134999 B) | 0.7.0 |
| Fator3 MCP LinkedIn | wp-mcp-linkedin-fator3 | 0.7.0 (85b1cc8d…, 207524 B) | 0.8.0 |

Frota hoje (Pedidos, 22/10): MCP 0.28.0, Google 0.17.0, Meta 0.6.0, LinkedIn 0.7.0 nos 12 sites; Core 1.47.0 nos 11 sites-alvo e 1.48.0 só no Site-Teste.

## Regras
- Normas: 01-instrucoes (rev 4) e 02-padrao (rev 4), lidas em `inputs/` dos fontes. Exceção registrada por ordem do dono: entregar só os três arquivos; consequência para outro pacote vai na seção 2 do relatório (sem arquivo de impacto separado).
- Identidade preservada (slug, pasta, basename, namespaces, Text Domain, Update URI, prefixos, tabelas, options, hooks, IDs de abilities). Mudanças aditivas; nenhum contrato público quebrado.
- Itens da rodada citados como "Melhoria M<n>" com origem "ordem do dono de 22/10/2026". Nenhum pedido numerado aberto nos Pedidos (todos os pacotes "nada pendente" em 22/10). Respeitar "Decidido não fazer": sem rota de execução de PHP, sem rota frota, sem db/execute em uma fase, sem fonte de atualização publicada, sem mover tag/consentimento ao Google, sem DNS reverso de robôs.
- Fronteiras (padrão §10) preservadas. Nova ability: nome ação+objeto no namespace do pacote, gate `manage_options` (ou capacidade exclusiva de admin) no servidor, rótulo e descrição em português, schema fechado, documentação instalada atualizada.
- Sem efeito externo real: nenhum HTTP a fornecedor, nenhum e-mail real, nenhuma gravação em site da frota nem no Site-Teste, nenhum documento Claude Docs editado, nenhum push. Leitura de conectores só se indispensável. Instalação no Site-Teste e na frota = pendência do Site Geral | Todos / dono.
- Laboratório local real: MySQL 8.0.46 em 127.0.0.1:3306, usuário `wp`/`wp` (servidor iniciado pelo orquestrador; se cair, reinicie com Bash `run_in_background` e comando `exec mysqld --defaults-file=/home/claude/w/mysql/my.cnf`). WordPress 7.1.3 e 7.1.2 em /home/claude/w/wp/*.zip (sha1 conferido com wordpress.org). PHP 8.3.6 do sistema (/usr/bin/php). Helper: /home/claude/w/lab/wplab.py (create/php/eval/unzip-plugin/drop), lab-guard MU (bloqueia HTTP externo, captura wp_mail), /home/claude/w/lab/serve.sh <dir> <porta> (php -S com 4 workers e router). Nunca use `pkill -f` com padrão que case com o próprio shell; pare servidores pelo .server.pid.
- Portas e bancos por frente: Core 8101–8119 / bancos `core_*`; MCP 8201–8219 / `mcp_*`; Google 8301–8319 / `google_*`; Sociais 8401–8419 / `social_*`. Labs em /home/claude/w/labs/<frente>-<nome>. O lab `joint-base` (porta 8080, banco joint_base) é do orquestrador: não alterar.
- Trabalho em /home/claude/w/work/<slug>-<alvo>-fonte (cópia do fonte base, adaptada). Instaladores-base originais em /mnt/user-data/attachments/1184cc33-602e-5442-b0e7-db9a3c0e049c/ (somente leitura; nunca modificar).
- Saída final em /home/claude/w/out/: `<slug>-<alvo>-instalador.zip`, `<slug>-<alvo>-fonte.zip`, `<slug>-<alvo>-relatorio.md`. Instalador determinístico com raiz `<slug>/`; fonte com raiz `<slug>-<alvo>-fonte/`, cópia do relatório marcada "anterior ao fechamento do fonte"; hash/bytes do fonte só no relatório externo; nenhum ZIP dentro de ZIP; sem segredo, banco, cookie, log pessoal.
- Provas mínimas: lint de todo PHP; testes novos que falham na base e passam no alvo (quando o item é defeito); suíte de regressão pertinente reexecutada; instalação limpa em WordPress 7.1.3 real (e no mínimo declarado no cabeçalho quando executável aqui); atualização direta da base com preservação de dados/opções; plugin isolado; convivência com os acompanhantes atuais (bases); documentação instalada lida integralmente e por paginação pela operação documental do pacote; debug.log sem notice/warning/deprecation do pacote. Declarar o que não foi exercitado.
- Relatório: modelo §12 do padrão, em português, frases diretas, sem linguagem evasiva nem elogio. Status honesto (`apta-no-escopo-testado` ou `com-pendencias`).

## Achados conjuntos já medidos (orquestrador, lab joint-base, WordPress 7.1.3, as cinco bases ativas)
1. Core: `_load_textdomain_just_in_time` para `f3base` em toda requisição (front, REST, admin: 6–14 notices por rodada de páginas). Cadeia: LinkedIn `plugins_loaded:20` → `do_action('f3_linkedin_register_consumers')` → `F3Base_Linkedin_Cliente::registrar` → `F3Base_Linkedin_Integracoes::colecao` → `F3Base_Options::fotografia_bruta/declaracao/catalogo/catalogo_interno` → `__()` em `trait-f3base-options-catalogo.php:32`, antes de `init`. É o mesmo aviso relatado nos laboratórios Meta 0.6.0 e LinkedIn 0.7.0.
2. Core: a tela `admin.php?page=f3base-leads` faz três requisições HTTP de loopback síncronas a cada abertura (`/` duas vezes e `/wp-json/f3base/v1/token`), além do disparo de cron; 1,2–2,3 s com banco vazio.
3. Google: aceite do pedido 35 registrou descrições de parte das abilities `gtm/*` ainda em inglês.
4. Meta e LinkedIn: cabeçalho declara WordPress 6.4 / PHP 8.1.2 por herança, nunca exercitados. Core 1.48.0 declara WordPress 7.1.2 sem reexecução nessa rodada.
5. Meta e LinkedIn têm `build/common` copiado e já divergente (Admin, Api, Connections, Http, Schemas, Support).
