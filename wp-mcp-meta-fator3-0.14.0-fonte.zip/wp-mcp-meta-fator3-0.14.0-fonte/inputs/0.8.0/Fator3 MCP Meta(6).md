# Pedidos — Fator3 MCP Meta (wp-mcp-meta-fator3)

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no pacote **wp-mcp-meta-fator3** (rotas `meta/*`). Em outros documentos, cite como "Pedidos MCP Meta N". Serve também de documento para o responsável pelo pacote. Base: 0.7.1. A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba.

**Escopo do pacote (0.7.1).** Instagram profissional e Páginas do Facebook pelo Facebook Login: perfil, mídias, Stories, insights, demografia e histórico cifrado, com painel em Ferramentas → Fator3 MCP Meta, conexões isoladas e cifradas (`meta/save-connection` com `expected_revision`; ativos `instagram` e `facebook`), coletas, agendas, fila de coletas por índice, recuperação do worker, aviso de operação ao `admin_email`, exportação CSV e JSON e 34 operações públicas (entre elas `meta/health`, leitura do estado), com rótulo e descrição em português. Fora do pacote: Meta Ads, tags de navegador, CAPI e as integrações comerciais do Site Core (pixel, CAPI e leads nativos da Meta seguem no Site Core). Requisitos declarados: WordPress 6.4 e PHP 8.1.2 de 64 bits e travas nomeadas no banco (a 0.7.1 foi provada em WordPress 7.1.3 com PHP 8.3.36 e em WordPress 6.4 com PHP 8.1.34). Atualização por ZIP manual.

**Situação em 23/10/2026: nenhum pedido aberto.** Versão instalada nos 12 sites da frota: 0.7.1 (ZIP `wp-mcp-meta-fator3-0.7.1-instalador.zip`, 150.734 bytes, sha256 `0adbea17…`, igual ao relatório; no `main` com a fonte `17d3b8e2…` e o relatório, commit `e40e162`), direto sobre a 0.6.0 (a 0.7.0 não foi instalada): no Site-Teste pelo agente do pacote e nos outros 11 pela frota em 23/10/2026 entre 13:40 e 14:17 −03, depois do Google 0.18.1 e antes do LinkedIn 0.8.1 em cada site, com `applied` e sondas 200 antes e depois. Novo na 0.7.x: `meta/health` (leitura do estado, sem reparo nem escrita: `state`, `issues`, `queue.oldest_due_lag_seconds`, `queue.unreadable_jobs`, `maintenance` e `cron`), ao lado de `meta/status`, que segue escrita local (rearma o worker; o perfil Leitura recusa); a recuperação da manutenção horária ausente; o isolamento de registro ilegível na fila (`unreadable`, sem apagar nem reexecutar, sob a trava do job e com comparação da revisão e do payload); o diagnóstico `schedule_job_unreadable` sem derrubar `health` e `status`; a auditoria do mais recente com `since`. Lido depois da troca nos 12: `meta/health` com `state` `ok`, `issues` vazio e `unreadable_jobs` 0; nas três conexões, 11 agendas ativas e fila sem atraso. Sem exercício em produção: o aviso por e-mail ao `admin_email`, `rotate-token`, a exportação do histórico, o Story com insights guardados depois de expirar e o 403 a um assinante (pendência 20). Conexões em ctooffice, korvena.com.br e fator3.com.br, cada uma com o Instagram e a Página do site; twinia sem conexão (estado da frota, pendência 88). Próxima entrega sem data.

**Numeração.** Item novo recebe o próximo número (hoje, 15) e vai no fim; item retirado deixa o número vago.

## wp-mcp-meta-fator3 — pendentes

Nada pendente.

## Decidido não fazer

Nada registrado.
