# Impacto de wp-mcp-google-fator3 0.21.0 em base-site-core-fator3

Data: 28/10/2026, America/Sao_Paulo · Revisão 1 · Etapa: planejamento · Situação: demanda-aberta.
Base Google 0.20.0; alvo previsto 0.21.0. Instalador-alvo ainda não gerado. Base SHA-256 `8c2456de80896dc7078321248a1df01c89745fc7f80a2c6e769ef1b6d543bbfd`.
Core examinado: 1.57.1, instalador SHA-256 `ee1c0eb8f46b7640a69e6b4e71697d5fc43bc9cd77f147c6219de1a410c5af62`.
Classificação: acao-necessaria · Natureza: contrato e integração · Pedidos MCP Google 39 / Pedidos core 316.

## Contrato e consequência

`site-conversion-delivery/1.1.0` acrescenta `user_data` opcional, somente `email` e `telefone` textuais; telefone com DDI E.164. Google valida, normaliza por `Ads\\WriteAbilities::normalize_user()` e calcula SHA-256. Consentimento `ad_user_data=GRANTED`, identidade/idempotência, destino vinculado e limites temporais continuam obrigatórios. Nenhum identificador pessoal ou hash entra no diário Google.

O adaptador negocia 1.0.0 quando solicitado pelo Core atual e mantém o campo `contract` nessa versão, pois o Core compara igualdade estrita. A capacidade nova é anunciada em `supported_contracts` e `enhanced_leads`, com suporte de payload, conta, ação, prontidão, motivo, instante e validade da observação. A verificação explícita consulta termos e habilitação pela Ads API; `capabilities()`/`google/status` não fazem HTTP. Ausência/falha/expiração não equivalem a prontidão.

Com clique, o fluxo atual é preservado; dados pessoais adicionais exigem prontidão para leads. Sem clique, exige identificador pessoal válido e prontidão; caso contrário, `enhanced_leads_not_ready` com não entrega comprovada. Mais de um clique permanece ambíguo.

A 0.20.0 usa Data Manager, não ClickConversion. Os identificadores normalizados `hashedEmail`/`hashedPhoneNumber` são traduzidos para os campos Data Manager `userData.userIdentifiers[].emailAddress/phoneNumber`, `encoding=HEX`. Preservar um evento por pedido, recibo durável e `site-conversion-reconcile/1.0.0`; não adicionar fallback que possa duplicar conversões.

## Ação do Core e aceite

Implementar Core 316: detectar a capacidade antes de construir o payload; ler dados elegíveis do registro somente no worker; incluir `user_data` com consentimento no aceite e atual; permitir ausência de clique somente na capacidade nova, sem contornar tráfego de teste, exclusão, prazo, destino ou estados incertos. Não copiar dados pessoais/hashes para o diário de entregas. Preservar a operação com adaptadores 1.0.0 antigos e com LinkedIn. Propagar códigos de recusa Google no diário Core.

Instalar primeiro Google 0.21.0, depois a versão Core que implementar 316. Core 1.57.1 conserva sua operação por clique e GA4. Google não muda tags, consentimento nem acervo Core. Validação prevista: matriz de negociação 1.0/1.1, clique+dados/sem clique, conta não pronta, revogação, dados inválidos, idempotência e privacidade; depois primeiro contato autorizado de ctooffice confirmado pelo Google. Mantenedor Core implementa consumidor; dono/frota homologa o contato real. Respostas e encerramento serão registrados no relatório principal conforme norma revisão 5.
