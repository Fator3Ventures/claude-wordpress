# Entrega — Fator3 MCP Google 0.21.0

Revisão 1 · 28/10/2026 · America/Sao_Paulo. Slug `wp-mcp-google-fator3`; base direta **0.20.0**. Pedidos MCP Google **39–42**.

**Implementada e ativa no Site-Teste.** Esta é a versão corrente da entrega. Os testes abaixo não identificaram regressões nas fronteiras exercitadas. O aceite comercial de conversões otimizadas depende do consumidor Core 316 e de conta Google autorizada. Não houve publicação no GitHub nem implantação na frota.

**Relatório externo canônico, fechado após o fonte.** A cópia interna é identificada como anterior ao fechamento e remete a este relatório para a identidade final do ZIP. Runtime e evidências são idênticos; não há hash circular.

## 1. Bases aceitas

Base exata Google 0.20.0: instalador 822.259 bytes, SHA-256 `8c2456de80896dc7078321248a1df01c89745fc7f80a2c6e769ef1b6d543bbfd`; fonte 4.890.228 bytes, SHA-256 `42c410ddcdf3fc2c1208a738e3ff3ecee1c6be09d1c7884c1bb558d21bba5e00`. Ambos permaneceram inalterados. Os pedidos constam de `inputs/021/Fator3 MCP Google(10).md`.

Foram lidos e comparados os pacotes/relatórios novos Core 1.57.1, LinkedIn 0.11.0 e Pipedrive 0.2.0; MCP 0.33.0 e Meta 0.12.0 permanecem acompanhantes. Identidades completas dos recebidos em `evidence/021/inputs-received.json`, manifestos dos laboratórios em `validation021.json`. Os fontes e instaladores fornecidos foram conferidos por SHA-256.

Aplicada a norma comum revisão 5, presente nos pacotes atuais, que prevalece sobre a revisão 4 avulsa quanto a respostas e fechamento de impactos. O plano `history/021/PLANO.md` e o impacto Core foram produzidos antes da implementação da fronteira afetada.

Mínimos Google comprovados: WordPress 7.1.2 e PHP 8.3.6, com OpenSSL e MySQL 8.0.46 no laboratório. Identidade, pasta, basename, namespaces, prefixos, permissões, Text Domain e Update URI preservados. **290 abilities, 112 de leitura e 178 de escrita; 38 opções; configuração 4.0.0; execução e armazenamento 2.0.0.**

## 2. Convivência e encaminhamentos

**Nenhum código do Core ou dos outros plugins foi modificado.** O Google entrega sua parte do pedido 39 sem aguardar outra release: negocia `site-conversion-delivery/1.1.0` e mantém `1.0.0` quando solicitado. Isso é necessário porque o Core 1.57.1 compara a versão exata do contrato. Clique, GA4, destino vinculado, recibos e reconciliação existentes continuam operando. O Core atual ainda não constrói o payload `user_data` do pedido 316.

Impacto emitido: `wp-mcp-google-fator3-0.21.0-impacto-base-site-core-fator3.md`, revisão 1, planejamento, ação necessária, pedidos Google 39/Core 316. O documento define capacidade, payload, consentimento, proteção de dados, ordem Google→Core e aceite. Seu estado original de planejamento foi preservado conforme norma 5; este relatório registra o desfecho: **lado Google implementado e provado; consumidor Core 316 e primeiro contato real pendentes**. O arquivo está preparado para encaminhamento; nenhuma mensagem externa foi enviada.

O impacto anterior Google 38/Core 313 foi atendido pelo Core 1.57.0/1.57.1 e pelo aceite da frota informado na nova lista de pedidos. O coletor está presente no código Core examinado. Portanto, não foi reemitida a antiga demanda de implementação de acervo GA4. A coleta real de 20/10 e a concessão nos 11 sites são evidências recebidas, não execução comercial desta rodada.

| Acompanhante | Prova desta rodada |
|---|---|
| Core 1.57.1 e MCP 0.33.0 | Limpa, atualização, Google primeiro, contratos, SDKs, filas/reconciliação legadas e documentação MCP. Pacotes originais, sem patches. |
| Meta 0.12.0 e LinkedIn 0.11.0 | Ativação conjunta, inventário de arquivos e conservação das sentinelas/dados cifrados no upgrade; versões ativas remotas preservadas. |
| Pipedrive 0.2.0 recebido | Pacote e relatório examinados. Não ativado no PHP 8.3.6 local, inferior ao mínimo próprio 8.3.36. |
| Pipedrive 0.3.0 observado | O Site-Teste avançou para 0.3.0 durante a rodada. Índice e changelog instalados lidos: relatório agregado novo, contrato Core 1.0.0 preservado. Versão ativa conservada antes/depois do Google. ZIP/fonte 0.3.0 não foram recebidos; não se atribui inspeção desses bytes nem homologação Pipedrive. |

O impacto MCP sobre escritas incertas continua respeitado: `retryable` não autoriza reenvio. Os impactos recebidos relativos a mensagens, credenciais LinkedIn e API Pipedrive não exigem mudança adicional no Google nesta entrega. Não foram emitidos avisos de versão como impactos.

## 3. Mudanças por pedido e evidência

| Pedido | Implementação | Evidência |
|---|---|---|
| 39 | `user_data` opcional aceita somente email/telefone textuais. Reutiliza normalização e SHA-256 existentes; normaliza Gmail e exige telefone E.164. Envia junto de um clique ou sem clique, mediante prontidão. Consentimento GRANTED permanece obrigatório. | Casos válidos/invalidade, três tipos de clique, ausência/ambiguidade, consentimento, expiração, revogação, idempotência e não persistência de dados/hashes. |
| 39 | Verificação explícita consulta por GAQL termos aceitos e habilitação de conversões otimizadas. Capacidade informa suporte, conta, ação, motivo, instante e validade; status não consulta Google. Ausência, resposta inválida ou prova vencida não concedem prontidão. | Conta habilitada, termos recusados, recurso desligado e prova vencida; Core 1.57.1 continua negociando 1.0.0. No Site-Teste, recusa própria sem HTTP. |
| 40 | `google/configuration-schema` aceita `compact` e `fields`; cada opção retorna nome, tipo, padrão e valor efetivo. Campos desconhecidos são recusados e segredos continuam redigidos. `google/status` aceita compact, inclusive por conjunto de conexões. | Três opções em **690 bytes UTF-8 de JSON**, já incluindo metadados MCP do resultado, no Site-Teste. Valores iguais aos da leitura completa. |
| 41 | `google/list-connections` e `google/integration-status` expõem `client_email`/`project_id` da chave de serviço salva, por conexão. Não retornam private_key/private_key_id. Ausência/chave ilegível resulta em null. | Chave sintética salva em conexão de laboratório, isolamento e gates administrativos; identidade presente mesmo quando OAuth é o modo selecionado. No Site-Teste sem chave, ambos null. |
| 42 | Renovação GA4 informa fase, HTTP, status, motivo e mensagem sanitizada nos incidentes e em renewal. Fases distinguem leitura do fluxo, segredo, comparação, debug e exceção de execução. | Falhas forçadas 403 no fluxo/segredo, validação e exceção; diagnóstico sanitizado e incidente resolvido na recuperação. Não se inventa causa para incidentes antigos. |
| 42 | Cada tentativa registra `conversion:verification` em `google/audit`, com origem executor/administrador, instante, código e resultado. Renewal projeta tentativas, referência de auditoria e tempo conhecido sem prova vigente. | Ciclo com quatro falhas e recuperação, cinco tentativas; preservação da causa/histórico e auditoria SQL nativa. Falha de auditoria fica explícita em audit_success. |

**Adaptação técnica do pedido 39:** a base 0.20.0 já usa Data Manager API, enquanto o texto recebido cita ClickConversion. Foi preservado o transporte vigente: hashes intermediários `hashedEmail`/`hashedPhoneNumber` tornam-se `userData.userIdentifiers[].emailAddress/phoneNumber`, com `encoding=HEX`. Não há upload legado adicional nem fallback que duplique conversão. Continua um evento por pedido, recibo durável, resultado inicialmente incerto e confirmação por `site-conversion-reconcile/1.0.0`.

Referências oficiais consultadas: [envio de eventos](https://developers.google.com/data-manager/api/devguides/events/send-events), [UserData](https://developers.google.com/data-manager/api/reference/rest/v1/UserData), [events.ingest](https://developers.google.com/data-manager/api/reference/rest/v1/events/ingest), [flags de conversão offline](https://developers.google.com/google-ads/api/docs/conversions/upload-offline) e [restrição de novos integradores no endpoint legado](https://ads-developers.googleblog.com/2026/05/changes-to-offline-click-conversion.html).

Dados pessoais e hashes permanecem somente em memória durante normalização/envio; não entram no recibo, diário Google ou mensagem de erro. O Core deverá preservar essa fronteira ao montar seu payload. A identidade da conta de serviço é metadado administrativo da chave salva; não comprova que ela está selecionada, válida ou autorizada no fornecedor.

Renewal mantém no máximo 50 tentativas do ciclo atual; `attempt_count`, `attempts_omitted` e `attempts_complete` informam a cobertura. O diário paginado é a fonte do histórico completo, sujeito à retenção escolhida pelo operador. O ciclo bem-sucedido permanece visível até começar o próximo. Duração sem prova usa expiração conhecida; sem prova anterior, retorna null, não zero inventado. Prontidão também depende de concessão/configuração, além da validade temporal.

Comparação com 0.20.0: **12 arquivos de runtime alterados/adicionados**, um novo `EnhancedLeads.php`. Catálogo capturado com o mesmo MCP 0.33.0: identidades, efeitos e campos obrigatórios anteriores preservados. Seis schemas recebem campos aditivos: configuration-schema, status, integration-status, conversion-delivery-status, configure-conversion-delivery e verify-conversion-delivery. Lista e hashes em runtime-changes.json; registros dinâmicos de conexões também recebem os dois metadados administrativos.

## 4. Instalação, testes e prontidão

| Prova | Resultado |
|---|---:|
| PHPUnit 9.6.37 / PHP 8.3.6 | **1.224 testes; 14.739 asserções; zero falhas/erros/skips** |
| Casos unitários novos 39–42, incluídos acima | 25 testes; 147 asserções |
| Limpa WordPress 7.1.2 | 2.748 verificações |
| Limpa WordPress 7.1.3 | 2.689 verificações |
| Upgrade direto 0.20.0→0.21.0, rollback e reaplicação | 2.715 verificações |
| Google primeiro, WordPress 7.1.3 | 1.274 verificações |
| Google isolado, WordPress 7.1.2 | 1.107 verificações |
| Total nativo nos cinco grupos | **10.533 verificações** |
| Contratos de conversão ausente/incompleto/matriz/resposta, adicionais | 60 verificações |
| Lint do runtime | 160 PHP válidos; instalador com 164 arquivos |
| Documentação estática | 47 documentos de origem, 47 exemplos e 157 links conferidos; 20 documentos instalados |

Os cenários nativos usam WordPress e MySQL reais, fornecedores simulados e bloqueio de HTTP externo/e-mail. A suíte nova tem 71 verificações por ambiente integrado; o caso isolado declara a ausência Core para o teste de renovação GA4. Cada grupo confere bytes instalados e inventários de acompanhantes. Os cinco grupos finais são a consolidação de duas execuções parciais, com igualdade comprovada da identidade runtime/testes/ferramentas e do candidato. Os processos foram encerrados; zero avisos/erros PHP Google nos grupos finais. As contagens incluem comparação individual de eventos retidos e schemas, não conversões reais.

Documentação foi reconstruída integralmente via MCP HTTP autenticado no laboratório, com hashes dos 20 documentos. Painel foi exercitado por renderização PHP e jsdom 27.4.0; não houve inspeção visual em navegador. README, GUIA-0.21.0 e CONTRACTS foram também lidos integralmente pelo conector do Site-Teste, byte a byte iguais ao fonte.

Tentativas preliminares corrigiram cobertura de schemas, referência do guia e expectativas do harness. A regressão antiga passou a localizar validateOnly pela URL, pois a consulta GAQL acrescentada deixou de torná-lo a última chamada. Essas tentativas interrompidas não são contadas como aprovadas. A primeira transferência remota recebeu Base64 truncado pelo limite de saída e foi rejeitada **antes de aplicar qualquer arquivo**; a leitura em blocos foi conferida e o upload seguinte validou o hash integral.

**Site-Teste:** WordPress 7.1.3, PHP 8.3.36, MCP 0.33.0. Google atualizado por `plugins/upload-base64`, com slug e SHA-256 esperados. Operação `fbd10c90bce703c11bd7084d`, pacote `4f77896ece20fa9cd9b08dc657d01594`, backup `ccba5ed6f0f091e0264c1b55`; `applied:true`, versão final 0.21.0, ativa e verificada em novo processo PHP. Sondas de `/` e `/wp-json/`: **200 antes e depois**, bypass de cache confirmado. Escopo interno de mesma origem; não comprova acesso público externo nem readiness comercial. `system/health`: healthy=true.

Revisão de configuração antes/depois idêntica: `12a9d64f8d91a1292ddcd7e6ac497362abe1b9b6cf7c489699d7f6b7b37c3efe`. As três retenções continuam em zero. Os **80 eventos Google anteriores permanecem idênticos**, sem novos dados pessoais ou hashes da sonda. Nenhuma configuração Google foi gravada nesta implantação.

Aceite 39 remoto: capacidade anuncia suporte, ready=false, motivo integration_disabled; envio sintético sem clique retornou `recusado/enhanced_leads_not_ready`, non_delivery_proven=true, **zero HTTP** e configuração inalterada. Foi usada sonda administrativa temporária, protegida por manage_options e bloqueio de rede, fora do instalador. Criação `8167ded29838a2eca7d038d2`; exclusão com guarda SHA-256 `1e2e502c4845c0d08a47bf37`; ausência da ability confirmada. O código reproduzível está em reproducao/site-test-refusal.php. Nenhuma fixture Google permanece ativa.

## 5. Banco, conservação e reversão

Sem novas tabelas nem migração destrutiva. As estruturas existentes recebem observação de prontidão e histórico limitado da renovação; credenciais e dados dos acompanhantes permanecem. Não há ativação automática de conversões otimizadas, concessão, conta ou consentimento.

Atualização direta, retorno de arquivos à base 0.20.0 e reaplicação foram exercitados com sentinelas/configuração/recibos. Rollback de arquivos não desfaz envios remotos nem restaura dados excluídos. Preservar banco, salts e backup. A base 0.20.0 mantém as retenções sem prazo, mas não oferece o novo payload nem o diagnóstico; antes de reverter após Core316, suspender novos envios aprimorados e conferir a negociação antiga. Preferir correção adiante. Não reapresentar um registro incerto com nova identidade.

## 6. Pendências e responsáveis

1. **Core 316:** consumir capacidade e payload 1.1.0, incluindo dados somente no worker elegível, com consentimento no aceite e atual. Preservar tráfego de teste, exclusão, prazo, destino e estados incertos. O contrato Google e seu impacto estão entregues; o consumidor Core não foi alterado nesta rodada.
2. **Frota/dono:** após instalar Google e Core compatível, homologar primeiro contato real de ctooffice aceito pelo Google com userData. O Site-Teste não possui credencial Google; os envios aceitos no laboratório são simulações. Não declarar entrega comercial a partir de ingestão pendente.
3. **Frota:** usar client_email/project_id para renomear as conexões autorizadas; nenhuma conexão de produção foi renomeada nesta tarefa. O próximo incidente real de renovação em ctooffice deve fornecer causa observada; o incidente antigo não pode ser reconstituído retroativamente. Permanece o aceite de credenciais da pendência 20 recebida.
4. **Distribuição:** publicação raw/GitHub e instalação nos demais sites não executadas. Conferir SHA-256 antes de instalar; apenas o ZIP instalador é instalável.
5. **Limites:** Pipedrive0.3 observado por documentação/inventário, não por fonte recebido; testes comerciais dos acompanhantes, outros bancos e inspeção visual em navegador não realizados. Isso não bloqueia a operação Google demonstrada.

## 7. Credenciais e permissões

Nenhum segredo novo exigido ou emitido. Permanecem chave de serviço/OAuth, developer token Ads e segredo Measurement Protocol, conforme o conector configurado; valores não integram o relatório nem evidências. A nova prontidão consulta conta Ads com credencial/autorização existente. Leitura de configuração e identidade exige acesso administrativo no servidor. Documentação estática conserva seu gate e não chama o fornecedor.

No Site-Teste, configured=false; client_email/project_id=null. O laboratório usou exclusivamente identidades sintéticas. A mudança não substitui autenticação, concessão do Core, consentimento individual ou aceite de termos Google.

## 8. Arquivos finais

| Artefato | Nome | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | wp-mcp-google-fator3-0.21.0-instalador.zip | 836718 | `25da9ef78e303f30ce2f73b8f98743a26e09b8ed238177474e4a956578a63814` |
| Fonte completo | wp-mcp-google-fator3-0.21.0-fonte.zip | 5345878 | `ebbd0be2946eb3b32240c2390c04d3887f55f3a7a15ac1deda38759e3d661c81` |

Artefatos adicionais: `wp-mcp-google-fator3-0.21.0-relatorio.md` e `wp-mcp-google-fator3-0.21.0-impacto-base-site-core-fator3.md`. O fonte contém runtime idêntico, documentação editável, build, testes, insumos de referência, evidências sanitizadas e este relatório anterior ao fechamento. Não contém ZIP aninhado, vendor/node_modules, banco ou credenciais reais. Reprodução em `reproducao/LEIA-ME.md`; identidade fechada em `evidence/021/validation021.json`.
