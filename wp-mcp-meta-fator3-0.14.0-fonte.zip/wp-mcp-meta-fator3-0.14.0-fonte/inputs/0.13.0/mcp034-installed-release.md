# Fator3 MCP 0.34.0 — Pedidos MCP 69–73

Base direta 0.33.0. Mínimos preservados: WordPress 7.1.2 e PHP 8.3.6. Entradas analisadas: Site Core 1.57.1, Google 0.20.0, Meta 0.12.0, LinkedIn 0.11.0, Pipedrive 0.2.0. Os acompanhantes permanecem independentes; Pipedrive exige PHP 8.3.36. A validação efetivamente executada e as pendências constam do relatório externo.

## 69 — Diagnóstico compacto

`system/health` aceita `compact:true` e `fields`, uma lista de blocos. O resumo preserva `healthy`, `plugin_version`, `mutation_audit`, `cron.scheduling` (contract/current_state/desired_state/readback.consistent), `recovery` e `incidents_24h`. Exemplo: `{"compact":true,"fields":["healthy","plugin_version","cron","recovery"]}`. A resposta comum fica abaixo de 2 KiB; se os próprios blocos solicitados excederem o orçamento, retorna `diagnostic_compact_limit`, pedindo menos blocos, sem cortar valores silenciosamente. A leitura integral continua disponível sem compact.

Incidentes de cron novos são indexados sem o antigo limite de 100. A contagem considera as últimas 24 horas, agrupada por operação, com o último horário/status/código. O histórico anterior é combinado por identidade. `counts_complete:false` declara lacunas anteriores, falhas de persistência ou período ainda sem cobertura; não se inventam os incidentes perdidos antes da atualização. O detalhe antigo de 100 entradas continua preservado. `system/oauth-diagnostics` oferece compact/fields, contagem por categoria e último ID/horário; mantém a retenção das últimas 128 falhas e explicita cobertura incompleta quando essa janela está saturada. Diagnostics não corrige agendas nem faz teste externo.

## 70 — Logs da hospedagem

`system/error-log` exige administrador, canal de arquivos e autorização de leitura da raiz real. Localiza `logs/<domínio de home_url>/https` nos pais do WordPress, inclusive a estrutura com links da hospedagem. Só lê `error.log`, `error.log.AAAA-MM-DD` e variantes `.gz`; não recebe um caminho arbitrário. Valida gzip, CRC e todos os membros concatenados antes de aceitar contagens.

Filtros: since/until RFC 3339, since inclusivo e until exclusivo (padrão últimas 24 h, máximo 31 dias); level fatal/warning/notice/deprecated; text literal sobre a mensagem já mascarada; per_page 1–30 e cursor. O fuso dos arquivos sem offset é America/Los_Angeles, com horário de verão; a primeira/última ocorrência sai no fuso configurado no WordPress. A hora repetida na transição de fim do horário de verão não pode ser desambiguada se o próprio log omitir o offset.

A agregação cobre toda a janela aprovada, por nível/mensagem normalizada/arquivo/linha. Cada página fica abaixo de 8 KiB. IDs de grupo ligam as páginas; o cursor expira em 15 minutos e recusa troca de conexão, filtros ou inventário. Limites: 128 arquivos, 32 MiB descomprimidos, 16 MiB comprimidos por arquivo, 5 segundos e 5.000 grupos. Ao exceder, a chamada falha sem apresentar uma contagem parcial como completa; reduza a janela. Linhas não reconhecidas aparecem em unparsed_lines; mensagens grandes são sinalizadas como truncadas na apresentação. Senha de banco, salts/chaves conhecidas, credenciais nomeadas, Authorization e formatos reconhecíveis são mascarados antes de agrupar/filtrar/devolver. Não há fallback de exposição bruta.

## 71 — Upload e repetição

Para `plugins/upload` e `plugins/upload-base64`, use idempotency_key estável e expected_sha256. O recibo é criado antes do download e seu package_operation_id é ligado ao diário antes da troca. Mesma chave/digest/intenção de activate/overwrite/expected_slug devolve o recibo ou estado observado do diário, sem novo download, sonda ou substituição. A origem do ZIP pode mudar na repetição; o digest continua a identidade do conteúdo. Outro digest ou intenção com a mesma chave causa idempotency_conflict. A permissão atual é revalidada inclusive no replay.

Falha inicial também consome a chave: para uma nova tentativa deliberada após corrigir o ambiente, use outra chave. Interrupção antes do diário retorna package_operation_interrupted; interrupção depois dos arquivos permite leitura do estado pelo replay e reconciliação explícita. Chamadas sem expected_sha256 preservam o contrato genérico anterior. Os recibos de pacote não entram na compactação genérica de idempotência. Chaves já consumidas pela base 0.33.0 continuam respeitando o recibo anterior e a comparação estrita dos parâmetros originais; estados incertos ou compactados nunca viram nova intenção.

baseline_timeout_seconds configura a sonda inicial, padrão 5, intervalo 1–30 segundos por requisição (home e REST, orçamento total 2×timeout+2). package_baseline_failed inclui baseline_duration_ms e baseline_timeout_seconds. probe_timeout_seconds continua controlando ativação/sonda posterior; timeout posterior preserva a pré-imagem e exige plugins/reconcile. Não há execução automática de migrações repetidas pelo replay.

## 72 — Pré-imagens e poda

As novas pré-imagens e os registros auditáveis de troca mostram plugin, version_before, version_after, package_operation_id e zip_sha256. O alvo da auditoria é o entrypoint. Replays continuam auditáveis com replayed:true; não são uma segunda troca. O índice antigo é enriquecido a partir do diário assinado quando a identidade pode ser comprovada; digest indisponível fica null e o envelope original não é reescrito.

`backups/list` aceita type (package_preimage/snapshot/file/database), plugin (entrypoint exato), since/until e filtros anteriores. `backups/prune` aceita `policy:"package_preimages"`, `plugin` opcional e `older_than_days:N`: seleciona a pré-imagem sucedida por uma troca posterior concluída do mesmo plugin OU anterior ao limite de idade. Exemplo seguro de prévia: `{"policy":"package_preimages","plugin":"wp-mcp-fator3/wp-mcp-fator3.php","older_than_days":2}`. Para aplicar, use dry_run:false e o expected_selection_sha256 recebido. Não combinar essa política com IDs, volume ou quantidade; exclude_ids continua disponível.

A seleção é congelada. Referências ativas e operações pendentes seguem protegidas. A ordem de novas trocas usa o início fracionário registrado; diários antigos sem precisão subsegundo não provam sucessão entre duas operações no mesmo segundo. O registro de trocas concluídas permanece após a poda. Um marcador privado de exclusão complementa o tombstone SQL e impede reimportação de envelope obsoleto mesmo após perda do índice. A atualização não executa poda automática.

## 73 — Cópia servida

`system/probe` aceita `cache:"served"`. Faz GET/HEAD da URL pública como visitante anônimo, sem cookie, Authorization, query anticache, assinatura de execução ou X-F3Base-Teste. Aceita as mesmas asserções de corpo/cabeçalhos/status. Marca de teste e cabeçalhos anticache são recusados nesse modo. O padrão continua cache:bypass.

cache_status, page_cache_hit, cache_evidence, cache_age_seconds e cache_age_source distinguem cabeçalho de HIT, marcador de cópia estática e corpo igual a artefato WPSC estável antes/depois. O rodapé de geração, isoladamente, não prova HIT. Age HTTP ou mtime de artefato cujo corpo coincide fornecem a idade; sem vínculo observável, idade e HIT ficam null/unknown. body_sha256 cobre o corpo retornado, com body_complete indicando o limite. O alcance continua internal_same_origin e external_access_proven:false; não certifica a navegação de fora da hospedagem nem todos os pontos de um CDN.

Referências primárias de comportamento WPSC consultadas em 28/10/2026: https://github.com/Automattic/wp-super-cache/blob/trunk/readme.txt e https://github.com/Automattic/wp-super-cache/blob/trunk/wp-cache-phase2.php. Os testes do pacote verificam os sinais e a cópia efetivamente observados; não pressupõem que toda instalação envie cabeçalhos de HIT.
