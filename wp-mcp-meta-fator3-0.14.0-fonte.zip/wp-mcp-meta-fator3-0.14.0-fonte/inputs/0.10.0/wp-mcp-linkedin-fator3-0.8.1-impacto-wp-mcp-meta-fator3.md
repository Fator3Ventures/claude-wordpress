# Impacto de Fator3 MCP LinkedIn 0.8.1 em wp-mcp-meta-fator3

Data: 2026-10-23 · Revisão: 2 · Etapa: encerramento · Situação: resolvido (resposta do responsável recebida).
Natureza: possível bug em código copiado entre builds independentes. Classificação: alerta-tecnico.
Base LinkedIn: 0.8.0 recebida; alvo entregue: 0.8.1. Instalador: `wp-mcp-linkedin-fator3-0.8.1-instalador.zip`, SHA-256 `172081883af66b8c4b61676396d85066d4be0778b7ca06fb22262b30a4d2374a`, 232544 bytes.
Destinatário examinado estaticamente: Meta 0.6.0, instalador SHA-256 `36f5cfe9a20db272fc80d3cdd8fd46da823c4eeac856e31d911e41754fd19f69`. O relatório recebido declara código comum convergido com Meta 0.7.0, mas os bytes desse instalador não estavam disponíveis nesta revisão.

## Registro original — revisão 1

As seções abaixo preservam o contexto da emissão 0.8.1; o estado atual está no encerramento ao final.

## Mudança e consequência

A revisão reproduziu no LinkedIn 0.8.0 dois problemas pertinentes ao Meta: R1, jobs já indexados como queued/retry cujo ciphertext se torna ilegível ocupam repetidamente o lote de 20 e impedem trabalho válido; R2, a leitura direta de last_job ilegível derruba o diagnóstico inteiro. A 0.8.1 isola somente a projeção da coleta sob a trava job:<id>, preservando payload, revisão, datas e retenção; health apresenta issue sem reparar ou gravar.

A inspeção de `includes/Query.php` e `includes/Worker.php` do Meta 0.6.0 encontrou os pontos equivalentes: Store::get antes do tratamento na execução do job e leitura desprotegida de last_job no health. Isso é indício técnico, não reprodução executada no Meta. R4 do LinkedIn não é automaticamente transferível: a ramificação de desativação da agenda distingue f3_meta. A correção CAPI R3 é específica do LinkedIn.

## Ação do responsável e aceite

Mantenedor Meta: reproduzir R1/R2 na versão corrente efetiva; conferir as diferenças locais antes de portar a correção. Aceite: vinte jobs cifrados ilegíveis indexados não impedem um job válido; concorrente que não possui a trava não altera a projeção; nenhum payload/revisão/datas é reescrito; health continua respondendo sem HTTP, reparo ou escrita. Usar os casos `tests/native/review081.php` do fonte LinkedIn como referência, adaptados ao domínio Meta. Não há novo número de pedido atribuído por esta revisão.

## Compatibilidade e sequência

Builds autônomos: atualizar LinkedIn não corrige nem modifica Meta. Os quatro plugins acompanhantes permaneceram em suas versões do Site-Teste. Nenhuma mudança de SDK ou implantação conjunta é exigida; LinkedIn 0.8.1 pode seguir independentemente. Não copiar cegamente o template comum completo.

## Validação e limite

LinkedIn 0.8.0: quatro novas reproduções falharam e as 127 regressões existentes passaram. LinkedIn 0.8.1: sete novas verificações e as demais regressões passaram; instalação isolada, integração, duas bases de atualização e mínimo declarados no relatório. Meta: somente inspeção estática e convivência, sem execução específica dos dois defeitos. Não afirmar que Meta 0.7.0 foi validado nesta rodada.

## Evolução e resposta esperada

Avaliação de impacto prevista em `planning/REVISAO-081.md`, antes da implementação; indício confirmado estaticamente na entrega. Aguardam-se reprodução ou descarte fundamentado pelo responsável Meta, indicando versão/hash e evidência. Alerta entregue ao dono; nenhuma mensagem externa enviada. Não encerra pedidos do Meta nem declara release dele corrigida.


## Encerramento — revisão 2, durante a entrega LinkedIn 0.9.0

O responsável Meta respondeu no impacto recebido `wp-mcp-meta-fator3-0.7.1-impacto-wp-mcp-linkedin-fator3(1).md`, revisão 3, e no relatório Meta 0.7.1. A resposta declara reprodução de R1/R2, correção, 11 casos adversariais e bateria de 392 verificações. Essas provas são **recebidas do mantenedor Meta**, não foram reexecutadas integralmente pelo LinkedIn. O fonte e o instalador Meta 0.7.1 foram disponibilizados nesta rodada; a inspeção do isolamento central e a convivência com o LinkedIn 0.9.0 são compatíveis com a resposta.

Instalador Meta 0.7.1: 150734 bytes, SHA-256 `0adbea179f3a89cd66b6dce289fa8658e1723f4a9b38568794fc7c3aea5963f2`. SHA-256 do documento de resposta recebido: `51fac0defe1d879c57a6e42c837dd5f487ad6680855fe10b9f7eeb070c919c46`.

Encerra-se o encaminhamento original R1/R2 pela resposta técnica do responsável. Não se renomeia a emissão original 0.8.1, não se altera o documento recebido do Meta e não se declara encerrado o backlog desse outro plugin. O novo alerta inverso de concorrência foi tratado como **pedido LinkedIn 12** na 0.9.0, com provas próprias em `tests/native/request012-cases.php` e `evidence/release090/`.

A avaliação atual não identificou nova ação necessária para Meta, Core, MCP ou Google: contratos, schema e fronteiras de integração foram preservados. Nenhuma mensagem externa foi enviada.
