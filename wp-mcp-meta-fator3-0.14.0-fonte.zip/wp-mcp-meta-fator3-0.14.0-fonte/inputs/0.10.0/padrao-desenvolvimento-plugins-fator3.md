# Padrão de desenvolvimento e entrega — plugins Fator3

Revisão 5 — 23/10/2026 — fuso de referência America/Sao_Paulo.

**Alteração desta revisão:** relatórios de impacto apresentam consequências técnicas relevantes e pedidos dirigidos a outros plugins. Respostas, aceites, comprovações de atendimento, cancelamentos e encerramentos ficam no relatório principal da rodada, com referência ao documento/pedido original. Não gerar, revisar nem reentregar um relatório de impacto apenas para comunicar esses desfechos. A emissão desde o planejamento permanece; revisões do impacto exigem mudança substantiva no conteúdo técnico ou no pedido ao destinatário. Esta orientação substitui a regra anterior de registrar o encerramento no próprio documento de impacto.

Aplicável aos responsáveis por Fator3 Site Core, Fator3 MCP, Fator3 MCP Google, Fator3 MCP Meta, Fator3 MCP LinkedIn e Fator3 Implantador. Este documento estabelece instruções comuns para as próximas rodadas. Sua criação não altera os plugins instalados.

**Origem das regras:** nomenclatura, artefatos por rodada, impactos individuais, documentação instalada, ambiente de testes, compatibilidade e incremento de versão decorrem da solicitação do usuário. Os detalhes de empacotamento, evidência, descoberta e coordenação abaixo operacionalizam essas exigências e preservam decisões anteriores do projeto.

**Referência adicional incorporada:** o usuário forneceu `Regra comum.md`, intitulado “Padrão de entrega dos pacotes Fator3”, datado de 16/10/2026. Seu conteúdo foi lido integralmente e conciliado nesta revisão. O endereço Claude continuou inacessível; a análise usa o anexo recebido, sem afirmar que ele contém outras abas ou todo o conteúdo remoto. O arquivo original não foi alterado.

## 1. Aplicação e precedência

1. Aplicar este padrão junto ao pedido específico da rodada, à regra comum mantida por “Site Geral | Todos”, à aba do pacote e aos contratos públicos efetivamente publicados. Esta revisão complementa a regra comum com as exigências expressas do usuário.
2. Uma instrução explícita do usuário para a rodada prevalece sobre o padrão. Registrar a exceção, o motivo e quais artefatos/testes ela afeta; não solicitar novamente uma autorização já concedida.
3. Cada agente mantém o plugin sob sua responsabilidade. Mudanças necessárias em outro plugin devem ser descritas no relatório de impacto correspondente; não modificar nem publicar o pacote do outro responsável sem atribuição para isso.
4. Preservar IDs de tarefas, decisões de arquitetura, permissões e contratos não alterados pelo escopo.
5. Distinguir requisito planejado, código implementado, prova local, prova em WordPress real e homologação no fornecedor. A presença de código ou de uma ferramenta descoberta não prova acesso externo.
6. Classificar a rodada como implementação, correção, homologação ou planejamento. Rodadas que produzem uma nova versão de software devem entregar o conjunto completo da seção 4. Em revisão de um candidato, manter todos os artefatos coerentes com aquele candidato.
7. Mesmo em rodada exclusivamente documental/de homologação, disponibilizar fonte e instalador da versão examinada, quando disponíveis, junto ao relatório e aos impactos pertinentes conforme a seção 6; identificá-los como base sem alteração. No planejamento, os impactos não dependem da existência do instalador da versão-alvo. Não inventar binários, renumerar software sem alteração ou declarar uma implementação inexistente. Se a base não estiver acessível, registrar exatamente o artefato faltante e a pendência da entrega.

## 2. Identidade e nomenclatura

### 2.1 Identidades estáveis

| ID de coordenação | Nome do plugin | Slug/pasta estável |
|---|---|---|
| core | Fator3 Site Core | `base-site-core-fator3` |
| mcp | Fator3 MCP | `wp-mcp-fator3` |
| google | Fator3 MCP Google | `wp-mcp-google-fator3` |
| meta | Fator3 MCP Meta | `wp-mcp-meta-fator3` |
| linkedin | Fator3 MCP LinkedIn | `wp-mcp-linkedin-fator3` |
| implantador | Fator3 Implantador | Confirmar no pacote instalado/aba do responsável; não inventar ou renomear |

O anexo inclui o Implantador, mas não informa seu slug nem basename: o responsável deve registrar esses valores existentes antes de gerar arquivos ou impactos destinados a ele. Preservar o basename principal já publicado, identidades de atualização, provider IDs, text domains, namespaces, tabelas, options, hooks e nomes de abilities. Não renomear essas interfaces apenas para uniformizar a aparência. A pasta interna do instalador permanece o slug, sem versão; duas pastas para o mesmo plugin causam duplicidade de instalação.

Novos arquivos de entrega: minúsculas, ASCII, hífens, sem espaços, acentos ou sufixos como `final`, `novo`, `corrigido`, `(1)` ou `(2)`. Cópias renomeadas pela plataforma não alteram a identidade: confirmar versão e SHA-256. Referências a software entregue devem incluir slug, versão e hash do instalador. No planejamento, identificar slug, versão-base e versão-alvo prevista; citar o hash da base quando disponível e registrar o instalador-alvo como ainda não gerado, sem exigir ou inventar seu hash.

### 2.2 Arquivos de entrega

Usar `<slug>` da tabela, `<versao>` no formato `X.Y.Z`, sem sufixo, e `<destino>` igual ao slug existente do pacote destinatário. Homologação, validação, tentativa e hash ficam nos metadados/relatório, não no nome público da versão.

| Artefato | Nome | Obrigação |
|---|---|---|
| Fonte completo | `<slug>-<versao>-fonte.zip` | Principal, obrigatório |
| Instalador WordPress | `<slug>-<versao>-instalador.zip` | Principal, obrigatório; único ZIP instalável |
| Relatório da rodada | `<slug>-<versao>-relatorio.md` | Principal, obrigatório, em português |
| Impacto individual | `<slug>-<versao>-impacto-<destino>.md` | Obrigatório somente para apresentar impacto técnico relevante ou pedido ao destinatário; desde o planejamento, conforme a seção 6; respostas e encerramentos ficam no relatório principal |
| Manifesto externo | `<slug>-<versao>-manifesto.json` | Complementar, quando útil à automação |
| Checksums | `<slug>-<versao>-sha256.txt` | Complementar, quando útil à conferência em lote |

Os três artefatos principais são autossuficientes. Manifesto/checksums não substituem nome, tamanho e SHA-256 do fonte e do instalador no relatório. Complementos devem acrescentar função, como automação ou encaminhamento individual, sem reproduzir integralmente os artefatos principais. Nenhum ZIP contém outro ZIP da entrega.

Markdown é o formato canônico dos relatórios. HTML/PDF podem ser representações adicionais, sem substituir o Markdown. Cada pacote possui seus próprios fonte, instalador e relatório, inclusive quando um agente produz dois pacotes. O plano e o relatório trazem referências aos impactos e pedidos emitidos, quando houver; os detalhes técnicos desses encaminhamentos ficam nos respectivos arquivos, sem duas cópias independentes do mesmo texto. Respostas, aceites, atendimento e encerramentos são registrados no relatório principal, vinculados ao documento/pedido original. Sem impacto relevante identificado, basta registrar essa conclusão e o escopo avaliado no plano/relatório, sem arquivos individuais nem matriz vazia.

Exemplo de impacto: `wp-mcp-linkedin-fator3-0.2.0-impacto-base-site-core-fator3.md`. A versão é a versão-alvo do emissor, identificada como prevista no planejamento; as versões do destinatário examinadas aparecem dentro do documento. Manter o mesmo documento durante o ciclo e revisar etapa/conteúdo apenas quando houver mudança substantiva no impacto ou pedido, conforme a seção 6. Se a versão-alvo do plano mudar, atualizar nome e referências, preservando o vínculo com o encaminhamento anterior. O relatório cita sempre o nome final exato dos arquivos recebidos pelo dono. Versão já publicada não é renomeada retroativamente para aderir a este padrão. Encerramento de pedido anterior não gera nova edição ou reentrega de seu arquivo de impacto.

### 2.3 Identificadores técnicos novos

Usar identificadores estáveis e específicos do domínio; manter os prefixos públicos existentes: `f3base/*` no Core, os namespaces administrativos registrados no MCP, `google/*`, `ga/*`, `gsc/*`, `ads/*`, `gtm/*` e `siteverification/*` no Google, `meta/*` e `linkedin/*` nos sociais. A lista Google descreve a base examinada; o catálogo vivo é a autoridade de descoberta.

Novas operações devem ter nomes que expressem ação e objeto, seguindo a convenção do namespace existente. Não criar aliases conflitantes, executor irrestrito ou nomes iguais com semânticas diferentes. Não confundir um prefixo de ability com o provider ID completo do plugin.

### 2.4 Cabeçalho e tela administrativa

| Campo | Regra |
|---|---|
| Plugin Name | Nome exibido da tabela, começando por `Fator3` |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | Descrição específica da aba do pacote: função e local de configuração; não copiar a de outro pacote |
| Version | `X.Y.Z`, igual à versão dos arquivos |
| Requires at least / Requires PHP | Mínimos comprovados no relatório; não declarar suporte menor apenas por inferência |
| Author | `Fator3` |
| Author URI | `https://www.fator3.com.br` |
| License | `GPL-2.0-or-later` |
| Text Domain | Identificador atual do pacote, preservado |
| Update URI | `https://fator3.com.br/plugins/<slug>`, preservando o valor existente; não criar serviço de atualização automática |

Em Ferramentas ou no menu próprio já existente, usar o nome exibido no título. Não criar menu duplicado por padronização. A tela exige `manage_options` ou capacidade própria atribuída somente a administradores. Toda operação que lê dados de conta conectada ou grava configuração aplica a mesma restrição no servidor, tanto no painel quanto por MCP/REST; `read` não é autorização suficiente. Sanitizar dados retornados, inclusive diagnósticos e logs.

Manter slug, pasta, arquivo principal, Text Domain, Update URI, prefixos de options/tabelas/rotas e ferramentas MCP já consumidos pelos sites. Corrigir nome exibido e texto de tela sem alterar essas identidades. Se um campo está ausente, preenchê-lo; divergência de identidade publicada exige encaminhamento, não renomeação silenciosa.

## 3. Versionamento e janela de compatibilidade

### 3.1 Regra de versão do plugin

- Regra geral: `X.Y.Z` passa para `X.(Y+1).0`.
- Incrementar major ou patch somente mediante solicitação explícita do usuário.
- Exemplos aritméticos: `1.33.0 → 1.34.0`, `0.22.0 → 0.23.0`, `0.9.0 → 0.10.0`, `0.1.0 → 0.2.0`. Estes exemplos não designam a próxima versão efetiva de um projeto em andamento; conferir a base da rodada.
- A política de numeração é do projeto. O número minor não autoriza quebrar contratos públicos nem demonstra compatibilidade.
- Versão do plugin, schema de configuração, schema de dados, contratos SDK/API, revisão de documentação e identificador de build são campos distintos. Alterar somente os que realmente mudaram.
- Uma mudança incompatível deve ser declarada e resolvida por evolução compatível ou decisão explícita de contrato/escopo. Não alterar major por iniciativa própria para contornar a regra.

Antes de empacotar, conferir a mesma versão no cabeçalho PHP, constante, metadados, catálogo público, documentação da release e manifesto, quando emitido. Registrar o build de forma interna para rastrear tentativas; não usar sufixos na versão pública ou nos nomes fixos dos três artefatos.

Após uma entrega declarada final, seu conteúdo é imutável. Código/instalador alterados exigem nova versão pela regra vigente, salvo instrução explícita para revisar o mesmo candidato. Antes da entrega final, correções no candidato podem manter a versão-alvo, atualizando build/hash e reexecutando as verificações afetadas. Relatórios externos podem receber revisão documental com histórico explícito, sem alterar os ZIPs certificados.

### 3.2 Base suportada

Por padrão, garantir:

1. Instalação nova do plugin em WordPress limpo, dentro dos requisitos de WordPress/PHP/banco declarados.
2. Atualização direta a partir da versão imediatamente anterior de referência do plugin.

Registrar `versao_base`, `versao_alvo` e a origem da base antes de implementar. Usar a versão anterior liberada para operação, não inferir a base apenas pelo maior número de um plano ou candidato. Instruções de salto explícito prevalecem; por exemplo, uma versão não instalada pode ser excluída pelo usuário do percurso exigido.

Se a versão instalada estiver fora da base suportada, diagnosticar e informar o percurso disponível. Não executar atualização destrutiva, presumir compatibilidade, exigir versões intermediárias sem fundamento ou converter uma instalação existente em instalação limpa. Preservar os dados e pedir definição apenas quando a base não puder ser determinada pelas evidências disponíveis.

Compatibilidade com versões mais antigas não é obrigação desta rodada, salvo pedido específico. Isso não autoriza apagar dados existentes ou remover rotinas ainda necessárias à base suportada. Recursos de instalação limpa não podem depender da execução prévia de versões históricas.

### 3.3 Compatibilidade entre plugins

Detectar contratos/capacidades na operação integrada. Instalação e funções próprias permanecem independentes de presença, ordem ou número de versão dos acompanhantes, conforme a arquitetura do projeto. A ausência de um contrato desabilita somente a capacidade que o exige.

Registrar quais versões reais dos acompanhantes foram testadas e quais contratos são aceitos. Testar a combinação operacional pertinente e, quando a interface mudou, o percurso de atualização independente que ficará temporariamente misto. Não exigir um produto cartesiano de todas as versões nem declarar combinações não testadas como homologadas. Dependências nativas de WordPress/PHP/Abilities API devem ser declaradas separadamente.

## 4. Entrega obrigatória por rodada

Para uma release, entregar **três artefatos principais: fonte, instalador e relatório**. Acrescentar um relatório de impacto por outro pacote efetivamente afetado, conforme a seção 6. A quantidade é variável e pode ser zero; não depende do total de plugins. Manifesto e lista de checksums são complementares. A documentação operacional integra o instalador e a árvore de runtime no fonte. Os impactos pertinentes devem existir já no planejamento da próxima versão, sem aguardar empacotamento ou implementação.

### 4.1 Fonte

O ZIP de fonte deve conter:

- Código-fonte completo do plugin e a árvore de runtime usada no instalador.
- Documentação editável e schemas que correspondem à versão.
- Scripts de build/empacotamento, instruções de reprodução e versões de ferramentas/dependências utilizadas.
- Lockfiles e informações de licença quando aplicáveis.
- Testes relevantes e fixtures sem segredos; evidências sanitizadas da rodada e instruções de execução.
- Cópia do relatório, identificada conforme a regra de fechamento da seção 4.3.

Usar uma única raiz `<slug>-<versao>-fonte/`, com diretórios documentados como `plugin/<slug>/`, `build/`, `tests/` e `evidence/`. Adaptar o build existente preservando reprodutibilidade; não reestruturar o runtime por estética. Dependências necessárias à execução devem estar incluídas no instalador ou ser um pré-requisito declarado, nunca depender de ferramenta de desenvolvimento no servidor.

### 4.2 Instalador

O ZIP deve conter somente uma raiz `<slug>/`, com arquivo principal `<slug>/<slug>.php`, runtime, assets, dependências de execução, licenças, documentação e metadados necessários. Se o basename efetivamente publicado for diferente, preservá-lo e registrar a exceção; não quebrar a identidade instalada para atender ao nome teórico. Excluir repositório Git, caches, credenciais, bancos de laboratório, ferramentas de QA, fixtures de execução e dependências exclusivamente de desenvolvimento.

Gerar a partir da árvore de runtime validada. Conferir os arquivos comuns entre fonte, instalador e instalação testada; diferenças geradas pelo build precisam estar documentadas e reproduzíveis. Atualização nativa e instalação inicial devem ser exercitadas em requisição/processo novo, conforme o mecanismo do WordPress e o contrato MCP disponível.

Nunca executar build do pacote final a partir de um diretório que contenha alterações de teste não revertidas. Código temporário de QA não pode sobreviver no instalador.

### 4.3 Identidade, relatório interno e fechamento

O relatório externo identifica instalador e fonte pelo nome final, tamanho em bytes e SHA-256. Esses campos são obrigatórios no próprio relatório. Os hashes correspondem aos bytes entregues e usados nos testes; alterar o instalador depois da homologação exige reavaliar e repetir as provas afetadas.

**Evitar a circularidade do hash do fonte:** não é possível fechar convencionalmente um ZIP que contenha, em seu relatório, o hash final desse mesmo ZIP. Adotar a sequência explícita abaixo:

1. Fechar runtime e documentação; gerar o instalador final, medir tamanho e SHA-256.
2. Preparar o relatório com resultados, pendências, encaminhamentos e identidade final do instalador.
3. Incluir no fonte uma cópia marcada “cópia anterior ao fechamento do fonte”, com referência ao nome exato do relatório externo. Nessa cópia, tamanho/hash do próprio fonte são `a preencher no relatório externo após empacotamento`, nunca valores simulados. O conteúdo funcional/evidências permanece igual ao da entrega externa.
4. Gerar o fonte uma única vez e calcular tamanho/SHA-256.
5. Completar a tabela de identidade no relatório externo canônico; não reabrir o ZIP fonte para inserir seu próprio hash. Registrar no relatório principal os resultados, respostas e encerramentos relativos a impactos anteriores. Revisar arquivos de impacto somente se houver mudança substantiva no impacto ou pedido ao destinatário, conforme a seção 6, e fechar os complementos utilizados.

Esta distinção entre cópia interna e relatório final é o ajuste técnico necessário para cumprir a cópia documental e a integridade exigidas no anexo; fica declarada nos dois relatórios. Revisões posteriores do relatório externo não alteram retroativamente a cópia congelada dentro do fonte.

Quando houver manifesto externo, registrar slug, nome, versão, build, base suportada, data/hora ISO 8601, requisitos, contratos, arquivos/tamanhos/hashes, commit quando disponível, ambiente e status. Um manifesto interno não contém hash do próprio ZIP. A lista de checksums, se emitida, inclui os artefatos e o manifesto externo, excluindo a si própria. Não inventar commit, hash ou teste.

### 4.4 Entrega ao dono e publicação pela frota

1. O agente entrega os três artefatos principais e os impactos pertinentes ao dono, com nomes finais e identidades conferidas.
2. A frota confere o SHA-256 do instalador contra o relatório e publica instalador e relatório na raiz de `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`, conforme a autorização operacional aplicável. O repositório é público; revisar os arquivos destinados a ele para segredos e dados pessoais.
3. Antes do primeiro `plugins/upload`, conferir os bytes efetivamente servidos pela URL raw e seu SHA-256. A instalação usa essa URL com `expected_sha256` e `expected_slug`, consultando o schema real da ferramenta. Se o contrato não estiver disponível, registrar o bloqueio; não omitir a verificação.
4. Na troca seguinte, a frota retira da árvore atual de `main` o instalador e relatório da versão anterior, preservando o histórico Git. Não renomear entregas antigas nem reescrever o histórico.
5. O fonte fica com o dono. Sua publicação no repositório público depende da decisão pendente 89 citada no anexo. Este padrão não autoriza publicar fonte, evidências privadas ou impactos sem destino definido.

O agente do pacote prepara a entrega; a frota responde pela publicação e distribuição. Esta descrição de fluxo não realiza nem autoriza, por si só, push, remoção, upload ou envio externo durante uma tarefa documental. Testes locais podem usar os bytes locais; a instalação via frota no WordPress compartilhado segue a verificação acima.

## 5. Relatório obrigatório da rodada

O relatório é autossuficiente, em português, e segue a ordem da regra comum:

1. **Título:** `Entrega — <nome exibido> <versao>`, seguido de revisão, data, natureza da rodada e status.
2. **De onde a versão entra:** WordPress limpo, versão anterior aceita diretamente, origem da base e eventual intermediária que não deve ser instalada. Não inventar uma versão intermediária.
3. **Convivência:** versões dos outros pacotes efetivamente validadas e ordem de troca quando um contrato comum exigir. Relacionar os impactos e pedidos emitidos pela rodada somente para destinatários afetados, com classificação, situação da demanda, ticket quando existente e referência ao documento individual. Em bloco separado no mesmo relatório principal, registrar respostas, aceites, atendimento, cancelamentos e encerramentos de impactos recebidos ou anteriores, citando documento/revisão, pedido, responsável, resultado e evidência. Sem impacto relevante identificado, registrar essa conclusão e o escopo avaliado; lacunas de avaliação permanecem explícitas.
4. **Mudanças e evidência:** item por item, com ID exato do pedido (`Pedidos core N`, `Pedidos MCP N` etc.), problema, resultado e prova. Abranger interfaces/schemas, configuração, banco, jobs, callback, permissões e efeitos pertinentes.
5. **Instalação e prova de prontidão:** passos, rota/ability real, parâmetros, estado esperado e observado. Incluir acesso à documentação instalada, testes realizados e estado final do ambiente. Ferramenta listada não basta como prova funcional.
6. **Banco e volta de versão:** dados gravados, migração/retomada, preservação, backup e limites da reversão; restaurar arquivos não desfaz banco nem efeitos externos.
7. **Pendências de validação:** o que não foi exercitado/homologado, incluindo conta real, API, navegador, instalação limpa ou mínimos de runtime; motivo e responsável.
8. **Credenciais:** nomes dos campos, tela, tipo de token/escopo/ativo e o que o dono deve preencher; nunca valores secretos.
9. **Identidade dos arquivos:** nome final, tamanho em bytes e SHA-256 do instalador e do fonte, seus links e a distinção da cópia interna anterior ao fechamento. Referenciar complementos quando houver.

Estados por item: `implementado`, `validado-localmente`, `validado-wordpress`, `homologado-fornecedor`, `pendente`, `bloqueado`, `nao-aplicavel`. São dimensões de evidência, não um único “OK”. Classificar a entrega como `apta-no-escopo-testado`, `com-pendencias` ou `bloqueada`, indicando exatamente o que pode ser usado.

Lint, fixtures, HTTP 200, registro de cron e ferramenta listada são provas específicas; não certificam sozinhos execução funcional, entrega remota ou permissão do aplicativo. Os mínimos de WordPress/PHP declarados no cabeçalho precisam da validação correspondente; se faltarem, registrar a pendência e não tratar o suporte como comprovado.

## 6. Impactos e pedidos dirigidos a outros plugins

### 6.1 Finalidade e quando emitir

O relatório de impacto apresenta consequências técnicas relevantes e pedidos dirigidos ao responsável por outro plugin. Avaliar as fronteiras pertinentes em cada rodada e gerar um documento por destinatário quando houver esse conteúdo. São exemplos: funcionalidade que exige adaptação; bug ou regressão que afeta outro pacote; mudança de contrato, API, schema ou comportamento; alteração de configuração, permissões, dados ou dependência; conflito de responsabilidade; ou teste coordenado necessário.

O relatório também cabe diante de risco técnico concreto que dependa de confirmação ou decisão conjunta. Uma consequência relevante para uso, configuração, diagnóstico ou teste justifica o encaminhamento mesmo sem mudança de código no destinatário. Consolidar os impactos e pedidos da mesma versão-alvo para o mesmo destinatário em um documento. O critério de emissão é a consequência ou solicitação dirigida a esse destinatário.

**Não gerar, revisar ou reentregar relatórios de impacto para respostas, aceites, comprovações de atendimento, cancelamentos ou encerramentos.** Esses registros pertencem ao relatório principal da rodada, conforme a seção 6.4. Também não emitir arquivos individuais para simples aviso de versão, repetição de status, informação sem consequência técnica relevante ou declaração de “sem ação/sem impacto”. Não existe quantidade fixa nem obrigação de relatório para todos os outros plugins. Mudanças estritamente internas ficam no relatório principal.

Quando não houver impacto relevante identificado, registrar brevemente a conclusão e o escopo avaliado no plano ou relatório principal. Uma interface pertinente não examinada deve constar como `nao-avaliado`, com motivo, nas pendências; isso não equivale a ausência de impacto nem exige, por si só, arquivo individual. Havendo risco concreto que precise de coordenação, emitir o encaminhamento com essa incerteza explícita.

### 6.2 Planejamento e revisões técnicas

1. **Planejamento da próxima versão:** gerar os impactos e pedidos pertinentes assim que forem identificados, antes de implementar a alteração que afeta a fronteira entre plugins. Explicitar proposta, consequências, conflitos, decisões necessárias, responsáveis e critérios de aceite. Referenciar os documentos no plano para que os envolvidos possam alinhar contratos e resolver conflitos antecipadamente. Não esperar código pronto, testes finais ou instalador-alvo para documentar o impacto.
2. **Implementação:** atualizar o mesmo documento quando houver mudança substantiva na consequência técnica, no contrato proposto, no risco, no pedido ou na orientação ao destinatário. Acrescentar as evidências que fundamentam essa mudança. Impacto novo descoberto durante o desenvolvimento deve ser registrado assim que identificado. Resolver conflitos que condicionem uma interface antes de implementar a parte afetada; atividades independentes podem prosseguir.
3. **Entrega:** conferir se o impacto ou pedido dirigido ao destinatário mudou em relação ao planejamento. Se mudou, revisar seu conteúdo técnico, compatibilidade, evidências e identidade do instalador existente. Se houve somente execução da solução, resposta, aceite ou encerramento, registrar o resultado no relatório principal. Não emitir revisão de impacto apenas para mudar etapa, informar versão/hash ou anunciar conclusão.

Revisões técnicas mantêm a identidade do documento durante o ciclo, com data e histórico conciso das alterações no impacto ou pedido. Preservar documentos anteriores como histórico. Um impacto resolvido, cancelado ou que deixe de se aplicar recebe o registro desse desfecho no relatório principal, referenciando a emissão original; não atualizar nem reentregar seu arquivo apenas para comunicar o encerramento.

Ao tratar um pedido recebido, uma nova consequência técnica ou solicitação para outro plugin pode justificar um encaminhamento próprio. Nesse caso, o documento deve apresentar concretamente esse novo impacto ou pedido; o simples atendimento ao documento recebido não justifica uma emissão de retorno.

### 6.3 Conteúdo do encaminhamento

| Campo | Conteúdo obrigatório |
|---|---|
| Identificação | Slug emissor, versão-base, versão-alvo prevista/entregue, destinatário, versões examinadas, etapa, data e revisão. Hash do instalador entregue quando existir; no planejamento, indicar que o alvo ainda não foi gerado |
| Etapa e situação | Etapa `planejamento`, `implementacao` ou `entrega`; situação `demanda-aberta` ou `alerta-tecnico-vigente`. Respostas e desfechos são registrados no relatório principal |
| Natureza | Desenvolvimento, bug/regressão, contrato, configuração, dados, segurança, dependência ou outra consequência técnica descrita concretamente |
| Classificação | `acao-necessaria`, `decisao-necessaria`, `validacao-coordenada`, `alerta-tecnico` ou `bloqueio`; explicar a consequência relevante, especialmente em alertas sem ação imediata |
| Mudança e consequência | Comportamento atual e proposto/entregue, nomes públicos exatos, cenário afetado, risco e limites conhecidos |
| Pedido ou orientação | Providência, questão a resolver ou orientação técnica pertinente; responsável, ticket quando existente e critérios de aceite. No planejamento, incluir alternativas e restrições quando houver conflito |
| Compatibilidade e sequência | Combinações verificadas ou previstas, transição, dependência real e ponto que exige alinhamento antes da implementação; sem bloqueio global artificial |
| Evidência do impacto | Base da análise, incertezas e provas que fundamentam a consequência técnica ou o pedido; testes/validações previstos quando ainda não executados |
| Alterações técnicas da revisão | Mudanças substantivas no impacto ou no pedido desde a revisão anterior; não usar este campo para resposta, aceite ou encerramento |

O emissor descreve a consequência técnica e o que solicita ou orienta ao destinatário. Não marca como implementada uma alteração de outro agente. Conflitos devem ficar explícitos no planejamento e ser resolvidos antes da implementação da parte dependente.

Preparar arquivos encaminháveis não equivale a enviá-los a pessoas ou sistemas. Publicação, envio de mensagens e alterações em outros projetos dependem da autorização aplicável; o pedido de gerar impactos já autoriza a criação desses documentos.

### 6.4 Respostas e acompanhamento no relatório principal

O destinatário incorpora a solicitação pertinente ao próprio plano. Registra no relatório principal da rodada sua resposta, aceite, alternativa, impedimento, implementação e validação; enquanto a rodada estiver somente em planejamento, usa o plano. O emissor registra também nesse local o acompanhamento e eventual encerramento dos pedidos que havia encaminhado. Um ticket existente pode ser referenciado como apoio, sem inventar IDs nem presumir autorização para comunicação externa.

Para cada registro, identificar documento original e revisão, emissor/destinatário, ID do pedido quando existir, responsável, resposta ou desfecho, versão/evidência, limites da prova e pendências restantes. Distinguir prova própria de informação recebida. Não declarar concluído trabalho de outro responsável sem a evidência correspondente.

Esses registros não geram arquivo `-impacto-<destino>.md` nem revisão de um impacto anterior. O relatório principal deve distinguir **impactos e pedidos emitidos** de **tratamento de impactos recebidos e anteriores**. Documentos antigos permanecem como histórico e não devem ser apresentados como novos encaminhamentos da entrega apenas porque seu pedido foi atendido ou encerrado.

## 7. Documentação obrigatória dentro do instalador

### 7.1 Conteúdo mínimo

Manter documentação textual legível por máquina dentro do plugin, preferencialmente em `docs/`. Usar UTF-8 e Markdown como fonte; schemas e catálogos estruturados usam JSON. A versão instalada deve bastar para orientar o uso, mesmo sem acesso ao repositório, ao relatório externo ou a um link de conversa.

| Documento lógico | Conteúdo |
|---|---|
| Índice | Identidade, versão, mapa de documentos, contratos e formas de leitura |
| Especificação | Objetivo, responsabilidades, comportamento, dados, efeitos, limites e recursos indisponíveis |
| Configuração | Pré-requisitos, campos/defaults, credenciais, escopos/ativos, passos de conexão, validação e revogação |
| Uso | Operações principais, sequências completas e exemplos de sucesso, vazio, erro e resultado parcial |
| Contratos | Schemas de entrada/saída, SDKs, callbacks, erros, revisões, permissões e integrações |
| Guia para agentes | Descobrir → ler → diagnosticar → configurar/consultar → verificar; confirmação e retomada |
| Operação | Cron/jobs, cotas, retenção, logs, recuperação, instalação, atualização e desinstalação |
| Notas da versão | Mudanças, base suportada, incompatibilidades, limites e pendências da release |

Mapeamento recomendado para novos documentos: `docs/README.md`, `SPECIFICATION.md`, `CONFIGURATION.md`, `USAGE.md`, `CONTRACTS.md`, `AGENT-GUIDE.md`, `OPERATIONS.md`, `CHANGELOG.md`, `schemas/` e `examples/`. Documentos existentes podem cobrir vários tópicos; publicar o mapeamento no índice, sem criar cópias divergentes só para cumprir nomes. O índice Core `docs/DOCUMENTACAO.md` permanece válido.

Gerar o catálogo de operações/schemas a partir do registro do próprio código quando possível. Redigir e revisar as explicações de semântica, pré-requisitos e exemplos. Se houver conteúdo compilado em PHP/JSON para leitura segura, produzi-lo no build a partir da mesma fonte e conferir a correspondência com a documentação empacotada.

Histórico deve estar identificado como histórico. O guia corrente descreve a release instalada; planos futuros e propostas não aparecem como capacidades disponíveis. Indicar explicitamente o que exige credencial, aprovação de produto ou contrato de outro plugin.

### 7.2 Acesso no WordPress e pelo MCP

Cada plugin, inclusive o Implantador, deve disponibilizar sua documentação no painel administrativo e por uma operação de leitura descoberta no catálogo MCP. O próprio plugin é dono do conteúdo e da autorização de domínio; o MCP fornece o transporte. A documentação local e o painel continuam acessíveis sem conexão ao fornecedor.

Requisitos funcionais comuns, preservando envelopes e nomes públicos existentes:

1. **Descoberta:** uma operação/documento inicial retorna índice, IDs permitidos, descrição e instruções reais de leitura. Deve ser encontrada pela descoberta usual de ferramentas, sem conhecer previamente caminhos de arquivos.
2. **Leitura completa:** obter documento ou seção por ID, com paginação para conteúdo extenso; nenhuma truncagem silenciosa. Limitar por bytes e/ou linhas com teto declarado, abaixo do limite do transporte após decoração.
3. **Identidade:** retornar slug, versão instalada, revisão ou hash do conteúdo, documento/seção, origem local e dados de continuação. Durante paginação, detectar alteração de revisão para evitar juntar versões diferentes.
4. **Schema:** documentar parâmetros, limites, erros e autorização. Quando o contrato de saída existente não puder mudar, acrescentar metadados de forma compatível ou publicar adaptação explícita.
5. **Confinamento:** usar IDs/allowlist do índice. Recusar travessia de diretórios, caminhos arbitrários, arquivos de credenciais, URLs externas e symlinks que saiam do conteúdo permitido.
6. **Leitura sem efeitos:** não consultar APIs dos fornecedores, criar conexão, renovar token, reparar agenda, instalar nada ou conceder permissões ao abrir ajuda.
7. **Autorização:** tela administrativa exige `manage_options` ou capacidade exclusiva de administrador. Leitura MCP de documentação exclusivamente estática usa o gate documental explícito do pacote, sem acesso genérico a arquivos. Se a operação incluir configuração efetiva, diagnósticos de conexão ou dados de conta, aplica-se também o gate administrativo, nunca somente `read`. Não reduzir a permissão de operação existente para facilitar a leitura.
8. **Atualidade:** a leitura reflete o pacote instalado. Conteúdo compilado/cacheado deve invalidar pela versão/hash; não misturar manual antigo com runtime novo.
9. **Privacidade:** somente exemplos sanitizados; nenhum segredo, dado de contato, dump real ou valor privado de configuração. A documentação serve como informação, sem executar seu texto como instrução privilegiada.

A pesquisa textual por assunto é recomendada; índice e leitura integral paginada são obrigatórios. Um link externo ou a possibilidade de usar `files/read` não substitui a operação de documentação do plugin. A leitura pelo MCP exige o MCP ativo e autorizado; isso não cria dependência de instalação do plugin de domínio.

### 7.3 Critério de aceite documental

Em uma nova sessão de agente, usando somente MCP autorizado e o plugin instalado:

1. Descobrir a operação de documentação e ler seu schema.
2. Obter índice e instruções de configuração.
3. Ler um documento completo, inclusive todas as páginas de um documento longo, conferindo revisão/hash e fim da leitura.
4. Identificar pré-requisitos, permissões, uma consulta válida, uma ação de configuração, seus efeitos e como verificar o resultado.
5. Conferir que a versão e os exemplos correspondem ao pacote e ao schema instalados.
6. Repetir a leitura após atualizar da base suportada, verificando que o conteúdo novo substituiu o antigo sem cache obsoleto.
7. Demonstrar recusa de acesso indevido a arquivos e ausência de chamadas ao fornecedor durante leitura.
8. Com perfil sem autorização administrativa, comprovar recusa de leitura de conta conectada e de configuração, no painel e nas operações remotas afetadas; documentação estática não pode servir como desvio para dados privados.

Um teste com inspeção do fonte ou apenas com o arquivo fora do WordPress não encerra esse aceite.

## 8. Testes e ambiente compartilhado

Ambiente permitido para testes: `https://fator3-teste-mcp-1.dreamhosters.com/`, por meio do conector **WP MCP fator3-teste**. A disponibilidade desse ambiente autoriza seu uso no escopo de testes solicitado; não exige instalação durante uma rodada exclusivamente de elaboração de instruções.

### 8.1 Coordenação

- Ler estado e versões/hash disponíveis antes de modificar o site; registrar data/hora e escopo.
- Como vários responsáveis utilizam o mesmo WordPress, coordenar uma janela de alteração. Manter uma única operação de instalação/atualização por vez e evitar testes concorrentes que mudem plugins, configuração, cron ou banco. Detectar mudanças de terceiros e interromper a sequência incompatível sem sobrescrevê-las.
- Preservar dados, credenciais, filas e configurações alheios. Gerar backup recuperável do que será alterado; registrar o que ele cobre.
- Executar instalação limpa em WordPress descartável/local ou em contexto isolado que realmente represente estado limpo. Não apagar o banco do site compartilhado para fabricar essa prova.
- Acesso ao site de teste não autoriza gastos em Ads, envios a clientes, publicação, assinaturas reais ou ingestão comercial em produção. Usar fixtures e destinos de homologação dentro da autorização existente.
- Identificar dados sintéticos e limpar somente os recursos criados pela própria rodada. Documentar qualquer resíduo ou estado deixado no site.

### 8.2 Matriz mínima por release

| Cenário | Aceite |
|---|---|
| Sintaxe e empacotamento | Runtime válido; árvore correta, dependências e docs presentes; nenhum segredo/QA no instalador |
| Instalação limpa | Ativar e usar funções próprias sem depender de estado histórico; primeira leitura anterior a qualquer reparo |
| Atualização da base anterior | Dados, opções, permissões, pausas e progresso preservados; novo processo confirma versão efetiva |
| Plugin isolado | Ausência de acompanhantes não derruba painel, bootstrap ou funções próprias |
| Integrações afetadas | Contratos corretos, permissões, indisponibilidade e atualização independente das fronteiras alteradas |
| Funcionalidade alterada | Resultado persistido/observável e erros pertinentes; teste deve verificar comportamento útil |
| Documentação pelo MCP | Descoberta e leitura completas conforme seção 7.3 |
| Encerramento | Saúde do WordPress, limpeza de fixtures e inventário final das versões instaladas |

Acrescentar testes conforme o risco concreto: repetição/idempotência, execução concorrente, interrupção e retomada para jobs; token revogado e troca de contexto para integrações; interface real quando o painel/JavaScript mudar; recuperação após falha para instalação; operação em versões mínimas quando se declarar suporte a elas. Publicar os limites quando não houver matriz executada.

“Bootstrap sem acompanhantes numa requisição” e “instalação isolada limpa” são provas diferentes. “Atualizar o mesmo ZIP sobre si” e “atualizar da versão anterior” também são provas distintas. Registrar o cenário real, inclusive quando a versão é a primeira release e não há anterior: nesse caso, atualização anterior é `nao-aplicavel`.

Mocks e fixtures devem ficar restritos ao teste e não alterar políticas globais de rede/segurança ou código publicado. APIs reais exigem tokens/ativos autorizados; falta de acesso é pendência de homologação, não resultado aprovado. Testar somente o necessário para riscos, contratos e critérios de aceite da rodada; evitar repetição ampla sem causa.

## 9. Preservação de dados, autorização e recuperação

1. Atualização não reseta configurações, importa dados, ativa conexões ou agenda efeitos comerciais por conveniência. Novos defaults devem ser distinguidos de escolhas já persistidas.
2. Manter proteção de segredos, permissões de leitura/escrita, revisão otimista e restrição por ativo. Tela, leitura de dados de conta conectada e escrita de configuração exigem `manage_options` ou capacidade exclusiva de administrador; validar no servidor, inclusive MCP e REST. Registro de ferramenta não concede acesso ao alvo.
3. Diagnósticos e leitura de estado não fazem reparos silenciosos. Operações com efeito declaram o efeito real, inclusive quando o método remoto usa GET ou quando a ação é chamada “teste”.
4. Repetição de uma operação confirmada não deve duplicar o efeito. Resultado externo incerto exige reconciliação antes de repetir.
5. Jobs preservam origem e autorização, revisão da seleção, locks, checkpoint e pausa. Não avançar cursor comercial antes da persistência correspondente.
6. Desativação e desinstalação têm comportamentos documentados; remoção destrutiva de dados exige ação explícita no escopo autorizado.
7. Reversão deve explicar limites do banco e de efeitos externos. Restaurar arquivos não desfaz automaticamente alterações de schema, mensagens ou chamadas remotas.
8. Logs, relatórios, fontes e exemplos entregues devem estar sanitizados. Não publicar credenciais, dados pessoais ou dumps de produção em evidências.

## 10. Fronteiras específicas preservadas

- **Core:** medição, consentimento, eventos, contatos, atribuição, pipeline comercial e histórico editorial GSC em seu recorte. Meta Lead Ads e Pixel/CAPI permanecem nele.
- **Google:** APIs e credenciais Google, GA4/GSC e recursos Google existentes. Configuração Google Ads e homologação devem ser comprovadas na instalação; presença de código não basta.
- **MCP:** transporte, autenticação, descoberta e administração WordPress. Não incorporar clientes das APIs sociais nem regras comerciais dos provedores.
- **Meta:** Instagram Insights, conexões e histórico próprios. Meta Ads e anúncios Instagram continuam no MCP oficial da Meta, utilizado pelo agente; não reimplementar esse conector nem criar cliente MCP remoto dentro do WordPress.
- **LinkedIn:** Pages, Ads e cliente/SDK Lead Sync próprios. Cliente Lead Sync Core e cliente do plugin LinkedIn convivem, com escolha explícita por integração; um cliente ativo por fluxo, sem duas ingestões/assinaturas equivalentes. Core mantém callback, contatos, deduplicação e efeitos. Ausência do selecionado pausa o fluxo; mudança para o outro é explícita.
- **Implantador:** manter seu domínio de implantação/configuração operacional e as pontes já publicadas. Inventariar contratos na própria aba/fonte antes de alterar; este padrão não transfere para ele clientes sociais, métricas ou regras comerciais.
- **Conexões sociais:** token manual é o padrão; aprovação de app, escopos, ativos e validade continuam necessários. Não impor OAuth interativo no plugin como requisito comum. OAuth do servidor MCP possui seu próprio domínio.
- **Escopo excluído nesta etapa:** BigQuery, migração Porter e nova exportação social para Google Sheets. CSV/JSON próprios permanecem. Sheets social só volta ao plano mediante solicitação; recursos Sheets existentes no Google são preservados.

Compartilhar schemas/fixtures e utilitários versionados quando isso reduzir trabalho, mantendo builds autônomos. Não introduzir novo plugin obrigatório de infraestrutura, leitura de options privadas ou importação de classes internas de outro plugin. Acoplamentos legados conhecidos, como adaptadores do Implantador, devem ser inventariados e tratados por encaminhamento específico; não removê-los fora do escopo por imposição genérica do padrão. Interfaces publicadas como contrato, inclusive recibos públicos, podem ser consumidas conforme a especificação.

## 11. Sequência de trabalho de cada agente

1. Ler pedido, padrão, última entrega, fonte-base, impactos recebidos e contratos relevantes.
2. Identificar versão-base/alvo, escopo, evidências existentes, requisitos nativos e acompanhantes efetivamente disponíveis.
3. Avaliar os impactos no planejamento e emitir documentos somente para os destinatários com consequências técnicas relevantes. Alinhar contratos e resolver conflitos antes de implementar a parte afetada, conforme a seção 6; referenciar os encaminhamentos no plano.
4. Implementar no próprio plugin, mantendo instalação limpa e atualização da base suportada.
5. Atualizar documentação, exemplos, schemas e leitor documental dentro do runtime.
6. Executar testes necessários, incluindo WordPress real e consulta documental pelo MCP quando a release estiver em homologação; registrar bloqueios concretos.
7. Fechar runtime/instalador; conferir correspondência e testar a identidade final ou demonstrar correspondência byte a byte com a árvore testada.
8. Preparar o relatório principal, incluindo respostas e desfechos de impactos recebidos ou anteriores. Revisar os documentos de impacto emitidos no planejamento somente quando mudarem substantivamente as consequências técnicas ou os pedidos ao destinatário, distinguindo proposta, prova própria e informação recebida. Sem impacto relevante identificado, registrar conclusão e escopo avaliado no relatório, sem arquivo de impacto para resposta ou encerramento. Fechar fonte e relatório na sequência da seção 4.3.
9. Conferir nomes finais, tamanhos e SHA-256 no relatório, cabeçalho, documentação, conteúdo dos ZIPs e ausência de arquivos privados. Gerar manifesto/checksums somente quando úteis.
10. Disponibilizar todos os artefatos e informar o estado final do site. Uma pendência real deve aparecer no relatório e na resposta final; não substituir prova faltante por linguagem de conclusão.

## 12. Modelo do relatório de entrega

```markdown
# Entrega — <nome exibido> <versao>

Revisão: <n> · Data/hora: <ISO 8601> · Rodada: <tipo>
Slug: <slug> · Versão/build: <versao> / <build>
Status: <apta-no-escopo-testado | com-pendencias | bloqueada>

## 1. De onde esta versão entra

<WordPress limpo; versão-base aceita diretamente; origem da base;
intermediária que não se instala, somente se aplicável.>
Requisitos validados: WordPress <versao>, PHP <versao>, <outros>.

## 2. Convivência e encaminhamentos

<Versões reais dos acompanhantes testadas; contratos; ordem de troca se necessária.>

### Impactos e pedidos emitidos nesta rodada

| Destinatário | Versão examinada | Classificação / situação da demanda | Ticket | Impacto individual / revisão |
|---|---|---|---|---|
<Somente impactos técnicos relevantes ou pedidos dirigidos aos destinatários.
Se nenhum impacto foi identificado, substituir a tabela por conclusão breve e escopo
avaliado. Registrar lacunas de avaliação nas pendências.>

### Tratamento de impactos recebidos e anteriores

<Para cada item pertinente: documento original/revisão, emissor, ID do pedido quando
existente, resposta ou desfecho, responsável, versão/evidência e pendência restante.
Registrar aqui aceites, atendimento, cancelamentos e encerramentos. Não gerar nem
revisar arquivo de impacto para essas respostas. Omitir este bloco se não houver itens.>

## 3. Mudanças e evidência

| Pedido exato | Problema | Mudança | Resultado e evidência |
|---|---|---|---|

<Contratos, configuração, dados, jobs e permissões afetados.>

## 4. Instalação e prova da troca

<Procedimento; URL raw final; expected_slug; SHA-256 da seção 8;
rota/ability de prontidão, parâmetros, estado esperado e observado.>

| ID | Ambiente | Cenário | Resultado | Evidência | Limite |
|---|---|---|---|---|---|

Documentação: <índice local, operação MCP, schema, versão/hash e leitura completa>.
Estado final do teste: <versões, limpeza e resíduos>.

## 5. Banco e volta de versão

<Gravações/migrações, retomada, backup, preservação e o que restaurar arquivos não desfaz.>

## 6. O que permanece pendente

<Provas não realizadas, falhas, conta/API/navegador/runtime, motivo e responsável.>

## 7. Credenciais e configuração do dono

<Tela, campos e tipo/escopos/ativos; nenhum segredo.>

## 8. Identidade dos arquivos

| Artefato | Nome final e link | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | <slug>-<versao>-instalador.zip | <n> | <hash> |
| Fonte | <slug>-<versao>-fonte.zip | <n> | <hash> |

<Relatório externo canônico. A cópia no fonte é anterior ao fechamento;
seu próprio tamanho/hash só são preenchidos aqui após empacotamento.>
<Complementos, se emitidos; impactos pertinentes referenciados na seção 2.>
```

O título e as oito seções seguintes correspondem aos nove itens ordenados da seção 5. Preencher somente fatos apurados; marcadores não preenchidos representam pendências, não uma entrega conforme.

## 13. Modelo de impacto individual

Usar somente para apresentar impacto técnico relevante ou pedido ao destinatário. Respostas e desfechos seguem a seção 6.4 e o bloco correspondente do relatório principal.

```markdown
# Impacto de <emissor> <versao-alvo> em <destinatario>

Data/hora: <ISO 8601> · Revisão: <n>
Etapa: <planejamento | implementacao | entrega>
Situação: <demanda-aberta | alerta-tecnico-vigente>
Versão-base: <versao e origem> · Versão-alvo: <versao; prevista ou entregue>
Instalador emissor: <nome e SHA-256, quando existir;
no planejamento: alvo ainda não gerado; hash da base quando disponível>
Destinatário examinado: <versao/hash ou não disponível>
Natureza: <desenvolvimento | bug/regressão | contrato | outra, especificada>
Classificação: <acao-necessaria | decisao-necessaria | validacao-coordenada | alerta-tecnico | bloqueio>

## Mudança e consequência

<Contrato/campo/ability exatos, comportamento atual e proposto/entregue,
cenário afetado, consequência técnica relevante, risco e incertezas.>

## Pedido ou orientação ao destinatário

<Providência ou questão a resolver, responsável, ticket quando existente e critérios de aceite.
No planejamento: conflito, alternativas/restrições e decisão necessária antes
da implementação afetada. Em alerta técnico: consequência e orientação pertinente.>

## Compatibilidade e sequência

<Combinações previstas ou verificadas, limitações, transição, dependência real
e ponto que aguarda alinhamento; atividades independentes que podem prosseguir.>

## Validação e evidência

<Planejamento: base da análise, testes/validações previstos e pendências.
Implementação/entrega: contrato real, testes executados, resultado e limites.
Não apresentar teste planejado como prova realizada.>

## Alterações técnicas desta revisão

<Somente mudanças substantivas no impacto, contrato proposto, pedido ou orientação
que justificam a revisão. Omitir na primeira emissão. Não registrar respostas,
aceites, comprovações de atendimento, cancelamentos ou encerramentos neste arquivo.>
```

## 14. Checklist de encerramento

- [ ] Versão-base/alvo explícitas; incremento minor por padrão.
- [ ] Fonte, instalador e relatório próprios entregues.
- [ ] Impactos avaliados; documentos emitidos somente para consequências técnicas relevantes, ou ausência de impacto identificado registrada com escopo avaliado.
- [ ] Impactos pertinentes gerados já no planejamento e conflitos resolvidos antes da implementação da parte dependente; sem exigir instalador/hash futuro.
- [ ] Arquivos de impacto revisados somente por mudança substantiva na consequência técnica ou no pedido ao destinatário, com evidências e referência no plano/relatório.
- [ ] Respostas, aceites, atendimento, cancelamentos e encerramentos registrados no relatório principal, vinculados ao documento/pedido original; nenhum arquivo de impacto gerado, revisado ou reentregue apenas para esses desfechos.
- [ ] Nomes finais, tamanhos e SHA-256 de fonte/instalador no próprio relatório.
- [ ] Fonte no singular, pasta fonte correta, cópia do relatório identificada; nenhum ZIP contém outro ZIP.
- [ ] Cabeçalho, título de tela e permissões administrativas conferidos.
- [ ] Fluxo raw/expected_sha256/expected_slug comprovado quando houver instalação pela frota; fonte fora do repositório público enquanto a decisão 89 estiver pendente.
- [ ] Documentação da release dentro do instalador e da árvore fonte.
- [ ] Agente consegue descobrir e ler integralmente essa documentação pelo MCP.
- [ ] Instalação limpa e atualização da base anterior verificadas, ou pendência/não aplicabilidade explicitada.
- [ ] Funções próprias e integrações afetadas verificadas com limites declarados.
- [ ] Configurações, dados, credenciais, pausas e permissões preservados.
- [ ] Nenhum segredo, fixture ativa ou ferramenta temporária no instalador.
- [ ] Aprovações e acessos remotos separados de testes simulados.
- [ ] Estado final do WordPress e limpeza registrados.
- [ ] Não foi alterado outro plugin, enviado relatório ou produzido efeito externo fora da autorização existente.

Um item obrigatório não atendido deixa a entrega `com-pendencias` ou `bloqueada`, conforme o efeito. Não marcar o item como concluído para fechar a rodada.
