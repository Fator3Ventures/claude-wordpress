# Impacto de Fator3 Site Core 1.56.0 em wp-mcp-meta-fator3

26/10/2026 · Revisão 1 · Etapa planejamento · Situação demanda-aberta · Classificação acao-necessaria.

Base Core 1.55.0, SHA-256 1d7e54fb86ea4c61de5e58df22e81b5e93aad3018bc5802fb3fd86ff48dd41a0. Alvo Core 1.56.0 previsto, instalador ainda não gerado. Destinatário examinado: Meta 0.11.1, SHA-256 b084bf2498eddc0eb93410c04efdd166ba84b2831541e2b5a2acf8dcfe3aa6c1. Natureza: contrato/privacidade. Referência: impacto Meta 0.11.1 → Core, revisão 3, MCP Meta 18(b); sem novo ID de pedido inventado.

## Consequência técnica

O SDK instagram-first-message/1.0.0 permite registro, leitura de recibo e reconciliação de reserved/uncertain/evidence_changed. Não oferece exclusão do remetente/evento/record_id dos registros message_event já persisted. reconcileReceipt(suppressed) conserva esses metadados e recusa persisted; portanto não satisfaz a exclusão coordenada solicitada na revisão 3. O Core não acessará Store/options/classes privadas do Meta para contornar essa fronteira.

## Ação solicitada ao Meta

Fornecer contrato público local de eliminação por conexão/conta/evento ou remetente escopado, com autorização atual, revisão, idempotência e recibo mínimo verificável. Remover identificadores pessoais e associação ao contato, preservando somente impedimento mínimo de reimportação; definir comportamento após revogação de token/remoção da conexão, quando a privacidade continua necessária. Não exigir chamada Graph nem autorização revogada para apagar o dado local do titular.

## Compatibilidade e validação

O Core implementará sua deduplicação/recibos e tombstones duráveis, default desligado e sem inferências de origem. A eliminação local não será declarada como eliminação do diário Meta. A pendência externa deve permanecer visível até haver um contrato de remoção compatível. Esse encaminhamento não altera o Meta nem seus contratos publicados. Aceite coordenado: excluir contato entregue, conferir ausência dos identificadores no Core/Meta, repetir exclusão, reiniciar e impedir nova importação, inclusive após revogação e limpeza administrativa do diário.

Resposta esperada: nome/versão/schema do contrato implementado, limites e evidência. Resposta e encerramento serão registrados no relatório principal do Core; este documento só muda com revisão substantiva do pedido.
