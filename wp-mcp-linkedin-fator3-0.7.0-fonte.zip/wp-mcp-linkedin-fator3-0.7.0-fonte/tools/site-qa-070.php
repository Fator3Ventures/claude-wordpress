<?php
/** Temporary Site-Teste callback. Never part of the installable plugin. */
declare(strict_types=1);
defined('ABSPATH')||exit;
function f3_linkedin_070_acceptance(): array {
 $ns='Fator3\\LinkedIn\\';$config=$ns.'Config';$store=$ns.'Store';$api=$ns.'Api';$conv=$ns.'Conversions';$connections=$ns.'Connections';
 if(!current_user_can('manage_options')||!class_exists($config)||$config::VERSION!=='0.7.0')return ['success'=>false,'code'=>'wrong_context'];
 if($store::list('connection',0,1)||$store::get('conversion_grant','site-core-conversions'))return ['success'=>false,'code'=>'requires_empty_linkedin_configuration'];
 $serviceEvents=[];$captureService=static function($event)use(&$serviceEvents){$serviceEvents[]=$event;};add_action('f3_linkedin_service_mutation_recorded',$captureService);
 $prefix='qa070-'.bin2hex(random_bytes(6));$checks=[];$previews=[];$operations=[];$mode='normal';$posts=0;$blocked=0;$failure=null;
 $response=static fn($body,$status=200)=>['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>$status,'message'=>'Synthetic fixture'],'cookies'=>[]];
 $http=static function($pre,$args,$url)use(&$mode,&$posts,&$blocked,$response){
  $path=parse_url($url,PHP_URL_PATH);$method=$args['method']??'GET';
  if(str_ends_with($path,'/introspectToken'))return $response(['active'=>true,'client_id'=>'qa-app','scope'=>$mode==='deny'?'r_ads':'rw_conversions,r_ads','expires_at'=>time()+7200]);
  if($path==='/rest/adAccountUsers')return $response(['elements'=>[['account'=>'urn:li:sponsoredAccount:222','role'=>'ACCOUNT_MANAGER']],'paging'=>['start'=>0,'total'=>1]]);
  $rule=['id'=>67890,'account'=>'urn:li:sponsoredAccount:222','enabled'=>true,'conversionMethod'=>'CONVERSIONS_API','name'=>'Regra de teste sintética'];
  if($path==='/rest/conversions')return $response(['elements'=>[$rule],'paging'=>['start'=>0,'total'=>1]]);
  if($path==='/rest/conversions/67890')return $response($rule);
  if(str_starts_with((string)$path,'/rest/networkSizes/')){parse_str(parse_url($url,PHP_URL_QUERY)??'',$q);return ($q['edgeType']??'')==='COMPANY_FOLLOWED_BY_MEMBER'?$response(['firstDegreeSize'=>4321]):$response([],400);}
  if($path==='/rest/conversionEvents'&&$method==='POST'){$posts++;$body=json_decode($args['body'],true);if(isset($body['record_id'],$body['contract']))return $response([],400);if($mode==='timeout')return new WP_Error('synthetic_timeout','No receipt');return $response([],201);}
  $blocked++;return new WP_Error('qa_network_blocked','No real network allowed in acceptance callback');
 };
 $mail=static fn()=>true;$call=static function($op,$i=[])use($api){$r=$api::dispatch($op,$i);if(!$r['success'])throw new RuntimeException($op.':'.$r['code']);return $r['data'];};
 $assert=static function($ok,$name)use(&$checks){if(!$ok)throw new RuntimeException($name);$checks[]=['name'=>$name,'passed'=>true];};
 add_filter('pre_http_request',$http,-10000,3);add_filter('pre_wp_mail',$mail,-10000);
 try {
  $call('save-connection',['connection_id'=>$prefix,'expected_revision'=>0,'token'=>'synthetic-qa-token','client_id'=>'qa-app','client_secret'=>'synthetic-qa-secret','expires_at'=>time()+86400,'assets'=>['ads'=>['222'],'pages'=>['111']]]);
  $g=['consumer_id'=>'site-core-conversions','expected_revision'=>0,'enabled'=>true,'connection_id'=>$prefix,'account_id'=>'222','conversion_id'=>'67890','expected_connection_revision'=>$connections::get($prefix)['revision']];
  $mode='deny';$r=$api::dispatch('save-conversion-grant',$g);$assert(!$r['success']&&$r['code']==='sem_escopo'&&$posts===0,'Escopo ausente recusa antes de qualquer evento');$mode='normal';
  $g=$call('save-conversion-grant',$g);$cap=$conv::capabilities();$assert($cap['ready']&&$cap['conversion_id']==='67890','Concessão explícita e capabilities local');
  $p=['contract'=>'site-linkedin-conversion/1.0.0','record_id'=>$prefix.'-record','event_id'=>$prefix.'-event','eventId'=>$prefix.'-event','conversion'=>'urn:lla:llaPartnerConversion:67890','conversionHappenedAt'=>time()*1000,'user'=>['userIds'=>[['idType'=>'SHA256_EMAIL','idValue'=>str_repeat('a',64)]]]];
  $i=['destination_ref'=>$g['destination_ref'],'payload'=>$p];$prev=$call('send-conversion-event',$i);$previews[]=hash('sha256',$prev['confirm_token']);$assert($prev['dry_run']&&$posts===0&&!str_contains(wp_json_encode($prev),str_repeat('a',64)),'Prévia sem evento nem identificação pessoal');
  $r=wp_get_ability('linkedin/send-conversion-event')->execute($i+['dry_run'=>false,'confirm'=>true,'confirm_token'=>$prev['confirm_token']]);$assert($r['success']&&$r['data']['status']==='entregue'&&$posts===1,'Escrita MCP simulada com aceite HTTP');$id=$r['data']['operation_id'];$operations[]=$id;
  $audit=wp_get_ability('audit/get-operation')->execute(['provider'=>$config::SLUG,'operation_id'=>$id]);$assert($audit['success']&&str_contains(wp_json_encode($audit),'nao_enviado')&&!str_contains(wp_json_encode($audit),str_repeat('a',64)),'Registro central lê antes/depois sem PII');
  $panel=static function($input)use($config){$request=new WP_REST_Request('POST','/'.$config::REST.'/send-conversion-event');$request->set_header('Content-Type','application/json');$request->set_body(wp_json_encode($input));return rest_do_request($request)->get_data();};
  $p['event_id']=$p['eventId']=$prefix.'-panel';$i=['destination_ref'=>$g['destination_ref'],'payload'=>$p];$prev=$panel($i);if(empty($prev['success']))throw new RuntimeException('Panel preview refused');$previews[]=hash('sha256',$prev['data']['confirm_token']);
  $r=$panel($i+['dry_run'=>false,'confirm'=>true,'confirm_token'=>$prev['data']['confirm_token']]);$assert($r['success']&&$r['data']['status']==='entregue'&&$posts===2,'Rota administrativa do painel confirma escrita simulada');$id=$r['data']['operation_id'];$operations[]=$id;
  $audit=wp_get_ability('audit/get-operation')->execute(['provider'=>$config::SLUG,'operation_id'=>$id]);$assert($audit['success']&&str_contains(wp_json_encode($audit),'nao_enviado')&&!str_contains(wp_json_encode($audit),str_repeat('a',64)),'Registro central lê antes/depois da rota do painel sem PII');
  $mode='timeout';$p['event_id']=$p['eventId']=$prefix.'-unknown';$actor=get_current_user_id();wp_set_current_user(0);try{$r=$conv::sendBound($p,$g['destination_ref']);$assert(get_current_user_id()===0,'Serviço conserva usuário zero');}finally{wp_set_current_user($actor);}$operations[]=$r['operation_id'];$n=$posts;$again=$conv::sendBound($p,$g['destination_ref']);$assert($r['status']==='incerto'&&$again['replayed']&&$posts===$n,'SDK conserva incerteza e impede reenvio');$mode='normal';
  $assert($r['central_audit']==='service_principal_unsupported','MCP 0.27 sem consumidor não é anunciado como integrado');
  $identity=$store::get('conversion_event',$r['operation_id'])['value']['service_identity'];$proof=f3_linkedin_introspect_service_grant($identity);$assert($proof['valid']&&count($serviceEvents)===1,'Introspector público valida evento de serviço persistido');
  $read=wp_get_ability('linkedin/get-service-write-operation')->execute($identity);$assert(!is_wp_error($read)&&$read['success']&&$read['data']['principal_type']==='service'&&$read['data']['after']===null,'Leitor público mostra snapshot técnico incerto');
  $clean=wp_json_encode([$serviceEvents,$proof,$read]);$assert(!str_contains($clean,str_repeat('a',64))&&!str_contains($clean,'synthetic-qa-token')&&!str_contains($clean,'userIds'),'Evento e leitura sem payload ou identificador pessoal');
  $bad=$identity;$bad['grant_revision']=str_repeat('f',64);$assert(!f3_linkedin_introspect_service_grant($bad)['valid'],'Revisão divergente falha fechada');
  $r=$call('query',['connection_id'=>$prefix,'channel'=>'pages','account_id'=>'111','report'=>'follower_total']);$assert($r['rows'][0]['firstDegreeSize']===4321,'Total de seguidores usa enum atual');
  $assert(\Fator3\LinkedIn\CentralAudit::status()==='registered','Descritor explícito admitido pelo MCP vigente');
  $grant=$conv::grant();$call('save-conversion-grant',['consumer_id'=>'site-core-conversions','expected_revision'=>$grant['revision'],'enabled'=>false]);$assert(!f3_linkedin_introspect_service_grant($identity)['valid']&&$store::get('conversion_event',$rServiceId=$identity['operation_id'])!==null,'Revogação bloqueia detalhe e conserva diário');
  $assert($blocked===0,'Nenhuma chamada de rede real');
 }catch(Throwable $e){$failure=$e instanceof \Fator3\LinkedIn\Fault?$e->reason:$e->getMessage();}
 finally {
  remove_action('f3_linkedin_service_mutation_recorded',$captureService);
  remove_filter('pre_http_request',$http,-10000);remove_filter('pre_wp_mail',$mail,-10000);
  foreach(['connection','token_proof','credential','credential_health'] as $bucket){$r=$store::get($bucket,$prefix);if($r)$store::remove($bucket,$prefix,$r['revision']);}
  $g=$store::get('conversion_grant','site-core-conversions');if($g&&($g['value']['connection_id']??'')===$prefix)$store::remove('conversion_grant','site-core-conversions',$g['revision']);
  foreach($previews as $key){$r=$store::get('conversion_preview',$key);if($r)$store::remove('conversion_preview',$key,$r['revision']);}
  foreach($operations as $key){$r=$store::get('conversion_event',$key);if($r&&$r['value']['connection_id']===$prefix)$store::remove('conversion_event',$key,$r['revision']);}
 }
 return ['success'=>$failure===null,'version'=>$config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'failure'=>$failure,'synthetic_posts'=>$posts,'real_provider_calls'=>0,'configuration_remaining'=>count($store::list('connection',0,100)),'audit_references_retained'=>true,'operation_ids'=>$operations];
}
add_action('wp_abilities_api_init',static function(){wp_register_ability('linkedin-qa/run-070',['label'=>'LinkedIn: executar aceite sintético da versão','description'=>'Valida CAPI, diário, Registro e seguidores com rede interceptada, sem credenciais reais e somente com configuração LinkedIn vazia; remove os dados próprios.','category'=>'linkedin','input_schema'=>['type'=>'object','properties'=>[],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>'f3_linkedin_070_acceptance','meta'=>['mcp'=>['public'=>true],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false]]]);},40);
