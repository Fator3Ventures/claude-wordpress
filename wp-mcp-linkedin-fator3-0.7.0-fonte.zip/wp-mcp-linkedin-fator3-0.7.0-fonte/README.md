# Fonte — Fator3 MCP LinkedIn 0.7.0

Fonte exclusivo de `wp-mcp-linkedin-fator3`, atualização direta da base imutável 0.6.0. Rodada de implementação de Pedidos MCP LinkedIn 8(d), parte de domínio da auditoria de serviço. Instale apenas o ZIP instalador entregue separadamente. Runtime exato em `plugin/`; código gerador e documentação em `build/`; testes em `tests/`; evidências sanitizadas desta rodada em `evidence/`; referências recebidas em `inputs/`; decisões e impactos em `planning/`. Arquivos antigos estão identificados pelo número da versão e representam história. Não há ZIP aninhado, credenciais reais, banco de laboratório ou capturas de navegador.

## Reprodução

Use Python 3 e PHP de 64 bits. Execute `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. O instalador determinístico em `build/dist/` deve ter **207524 bytes**, SHA-256 **85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515**. O build valida a sintaxe de 26 arquivos PHP; os 53 arquivos em `plugin/wp-mcp-linkedin-fator3/` são idênticos ao instalador. O manifesto interno lista os hashes dos arquivos de runtime.

Ambiente local efetivamente testado: WordPress 7.1.3, PHP 8.3.6 de 64 bits, MySQL 8.0.46. `tools/runtime-dependencies.json` contém os pins PHP 8.3.6 Ubuntu `.13` e dependências recebidos na rodada anterior; `tools/fetch-runtime.py` permite buscá-los para `F3_RUNTIME_DOWNLOAD_ROOT` fora do projeto. Os binários, WordPress e instaladores acompanhantes devem ser fornecidos separadamente. O auxiliar PHP 8.1 e os arquivos de navegador herdados não constituem prova desta matriz.

Copie `tools/dependencies.example.json` ou `tools/integrated-dependencies.example.json`, ajustando somente caminhos. O runner confere SHA-256. Para diretórios, o digest é SHA-256 da sequência ordenada de caminho relativo UTF-8, byte zero e SHA-256 binário de cada arquivo. Dependências sempre ficam fora da árvore fonte.

```sh
python3 tools/lab.py --manifest /caminho/manifest-isolado.json --workdir /caminho/lab-novo --order linkedin-only
python3 tools/lab.py --manifest /caminho/manifest-integrado.json --workdir /caminho/lab-upgrade-novo --order linkedin-integrated --origin upgrade
```

O segundo comando usa LinkedIn 0.6.0, Core 1.47.0, MCP 0.27.0, Google 0.17.0 e Meta 0.4.1. O laboratório cria banco e processos descartáveis, intercepta HTTP/e-mail e encerra somente seus processos. Não use diretório de laboratório já existente. Não altere nem misture os ZIPs originais das dependências. Seus hashes estão no manifesto.

## Evidências desta rodada

Instalação limpa isolada: **105 verificações**, zero falhas. Atualização direta integrada: **139**, zero falhas, incluindo preservação byte a byte da concessão CAPI, prova local de escopos, prévia e diário antigo sem vínculo de serviço, além das demais regressões. São execuções com verificações comuns, não casos únicos somáveis. Os resultados completos estão em `evidence/clean` e `evidence/upgrade`.

`tests/native/release070.php` contém 19 verificações novas: esquema fechado, introspecção e leitura sem HTTP/escrita, usuário zero e incidental, propriedade/perfil, revisão/escopos/revogação/ativo, identidade falsa, replay/incerteza e resposta a recibo central ausente, divergente ou com exceção. `ServiceAuditContractFixture` é consumidor central **simulado**, somente nos testes. O MCP 0.27.0 real permanece sem o contrato de serviço e não foi alterado. A prova simulada não encerra o aceite do Pedido 8(d).

Site-Teste: WordPress 7.1.3/PHP 8.3.36, atualização 0.6.0→0.7.0 com backup e sondas 200; 18 verificações simuladas, oito autotestes, 80 abilities e 21 documentos conferidos integralmente em 22 páginas MCP. Meta 0.5.0 foi observado no site antes da instalação; o pacote local recebido e testado é Meta 0.4.1. Não se atribui a esta entrega a atualização do Meta.

`tools/site-qa-070.php` é auxiliar temporário para Site-Teste autorizado e configuração LinkedIn vazia; requer administrador, intercepta toda rede/e-mail e remove apenas seus dados. Foi removido após a prova; zero abilities de QA no catálogo final. Permanecem referências centrais sintéticas humanas e backups gerados pelo MCP. Não instalar esse auxiliar em produção nem incorporá-lo ao instalador. Os auxiliares 0.5/0.6 são históricos.

Sem mudança de interface ou JavaScript nesta rodada; a regressão HTML executada no WordPress passou. Os testes de navegador da base não foram repetidos e não são contados como evidência 0.7.0. Logs finais não registraram erros LinkedIn; três avisos de tradução antecipada `f3base` apareceram no laboratório integrado, sem falhar testes. O relatório diferencia isso de homologação funcional completa de acompanhantes.

## Limites e fechamento

Entrega `com-pendencias`: MCP deve confirmar/adaptar o handshake e implementar o consumidor central real. Conversão real entregue e contada, concessão de produto `rw_conversions`, conexão nova e erro de segredo pela tela do dono permanecem nos aceites externos 20/92 da frota. A decisão 116 sobre Insight Tag/regra API continua com dono/Core. Itens 9, 10 e 11 e 8(a,b,c,e) foram aceitos na aba recebida, não reabertos nesta rodada. WordPress 6.4/PHP 8.1.2 são mínimos herdados não exercitados; suporte nesses mínimos não é comprovado por esta entrega.

Prepare a pasta `wp-mcp-linkedin-fator3-0.7.0-fonte` e execute `python3 tools/package-source.py --output-dir /caminho/fora-do-fonte`. O script recusa sobrescrever fonte fechado. A cópia interna do relatório é anterior ao fechamento e não contém hash circular deste ZIP; bytes e SHA-256 finais constam do relatório externo canônico. Publicação/distribuição da frota e alterações em outros pacotes não integram esta entrega.
