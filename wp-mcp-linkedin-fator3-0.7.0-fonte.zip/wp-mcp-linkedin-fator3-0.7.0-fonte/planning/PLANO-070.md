# Plano — Fator3 MCP LinkedIn 0.7.0

2026-10-22 · etapa planejamento · base 0.6.0, instalador edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e. Nova rodada minor, sem intermediária. Único pedido aberto: Pedidos MCP LinkedIn 8(d), coordenação com Pedidos MCP 65. MCP recebido 0.27.0, Core 1.47.0, Google 0.17.0, Meta 0.4.1. Os aceites 9/10/11 e 8(a,b,c,e) informados na aba atual são evidência recebida, não nova prova própria.

Confirmar a separação de mutation-service-audit/1.0.0 proposta pelo MCP, concretizando descritor PHP, introspector local por identidade opaca e leitor administrativo de snapshots técnicos. Fornecer emissão do adaptador real com usuário zero ou incidental, independente da identidade corrente; preservar contrato humano, payload CAPI, fila Core e idempotência. O MCP 0.27.0 não implementa o consumidor: manter fallback honesto e não declarar aceite central concluído.

Fronteira antes do código: impacto wp-mcp-linkedin-fator3-0.7.0-impacto-wp-mcp-fator3.md revisão 1. O mecanismo PHP exato de registro/recibo é contraproposta concreta, testável por fixture de contrato; não é capacidade atribuída ao MCP 0.27.0. Não modificar MCP ou instalar simulador de central em site compartilhado. Nenhum novo contrato obrigatório ao Core. A decisão prévia sobre IDs de conversão continua com dono/Core (pendência 116 da frota), sem nova alteração nessa fronteira.

Provas previstas: instalação limpa isolada, atualização direta preservando 0.6.0, coexistência real com MCP 0.27.0; serviço com usuário zero/incidental, leitura/recusa administrativa e por perfil, revisão divergente, revogação, troca de ativo, replay, incerteza, ausência do central, falha/recibo divergente do consumidor simulado, ausência de PII e zero HTTP em introspecção/leitura. Site-Teste deve provar parte de domínio e fallback real; aceite central fica condicionado ao runtime futuro. Documentação integral por MCP e verificação de hashes. Não alterar JS/painel nesta rodada salvo diagnóstico necessário já acessível em capabilities/status.

## Resultado da rodada

Etapa entrega: domínio implementado e validado nos cenários previstos; impacto MCP atualizado para revisão 3, aberto para confirmação/implementação do consumidor central. Instalador final 0.7.0 SHA-256 85b1cc8d16ab972e9acc2ad90bf81f0806b30a66e0833be311e33bf4a6b1d515. Acompanhantes não alterados. Leia o relatório 0.7.0 e as evidências atuais; o planejamento acima permanece como histórico.
