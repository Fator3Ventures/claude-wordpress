# Plano — Fator3 MCP LinkedIn 0.6.0
22/10/2026 · revisão 1 · implementação planejada
Base direta 0.5.0 (instalador dcef9a7b236bdb84055baa4aa6db73ba2fcd3bdd9a7cea30905c2e771a563199). Alvo minor 0.6.0; instalador ainda não gerado.
Pedidos MCP LinkedIn 8–11. Preservar identidade, configuração, permissões, SDK Lead Sync, gestão e diário 0.5.0. Core 1.47.0 e MCP 0.26.1 recebidos e hashes conferidos; Google 0.17.0 e Meta 0.4.1 mantidos.

1. Implementar adapter CAPI com concessão explícita site-core-conversions, vínculo opaco à conexão/conta/regra, capabilities local, introspecção no despacho, fonte API comprovada, idempotência por evento e diário sem PII; envio unitário/lote com resultados individuais e prévia administrativa.
2. Corrigir edgeType de follower_total e erros remotos sanitizados.
3. Registrar descritor mutation-audit/1.0.0 mantendo leitor/controle/evento. Detectar capacidade efetiva.
4. Documentar nomes e localização das credenciais/ativos; ajuda junto aos campos e tabela na aba Ajuda; erros OAuth contextualizados.
5. Testar WordPress limpo, upgrade direto 0.5.0, convivência atual, gates, vínculo/replay/incerto, DOM e Site-Teste com fornecedor simulado. Não enviar conversão real nem editar outro plugin.

Impactos emitidos antes do código: wp-mcp-linkedin-fator3-0.6.0-impacto-base-site-core-fator3.md e wp-mcp-linkedin-fator3-0.6.0-impacto-wp-mcp-fator3.md. Google/Meta sem fronteira alterada. Implantador fora das fronteiras afetadas.
Homologação real depende rw_conversions/aprovação e ordem do dono; igualdade de follower_total com tela das duas páginas e caminhos em sessões autenticadas permanecem a provar, sem inventar aceites.

## Encerramento técnico da rodada
Entrega 0.6.0 com pendências externas, instalador imutável edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e. Instalação limpa 86/0, upgrade integrado 119/0, Chromium 8/0, Site-Teste 11/0 e autoteste 8/0. Documentação MCP: 19 documentos / 20 páginas, conteúdo integral idêntico. Impactos Core revisão 4 e MCP revisão 3 atualizados para etapa entrega. Sem mudança nos pacotes acompanhantes, sem envio de evento real, sem distribuição à frota. Fonte e relatório fechados conforme norma, com cópia interna anterior ao hash final.
