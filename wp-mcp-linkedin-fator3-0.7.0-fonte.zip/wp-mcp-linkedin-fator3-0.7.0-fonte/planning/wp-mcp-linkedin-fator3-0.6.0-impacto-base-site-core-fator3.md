# Impacto de Fator3 MCP LinkedIn 0.6.0 em base-site-core-fator3
Data 2026-10-22 · revisão 4 · etapa entrega · situação com-pendencias · validacao-coordenada / decisao-necessaria.
Emissor wp-mcp-linkedin-fator3; base aceita 0.5.0; versão entregue 0.6.0. Instalador wp-mcp-linkedin-fator3-0.6.0-instalador.zip, 189130 bytes, SHA-256 edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e. Destinatário examinado 1.47.0; Pedido LinkedIn 8 / Core 285.

## Proposta e consequência
Contrato site-conversion-delivery/1.0.0; site-linkedin-conversion/1.0.0. Implementar filtro f3base_conversoes_adaptador no destino linkedin e contexto site-core-conversions. Capabilities local, destination_ref opaco, conversion_id string. sendBound preserva eventId/tempo, remove campos internos, responde entregue/recusado/incerto sem PII. Concessão CAPI separada do Lead Sync; mudança de contexto invalida vínculo. Core conserva fila, consentimento e decisão de retry; incerto nunca é reenviado. Testar contrato público com Core recebido. Frota/dono homologam regra API e contagem única após aprovação rw_conversions e ordem explícita.

## Compatibilidade e validação prevista
Funções próprias permanecem autônomas. Não editar pacote destinatário. Instalação limpa e atualização direta 0.5.0, combinação recebida e ausência de acompanhantes. HTTP LinkedIn simulado, permissões/revogação, idempotência, recusa e incerteza. Homologação real separada.

## Responsabilidade e encerramento
LinkedIn implementa adaptador/descritor e entrega evidência; destinatário mantém seu domínio. Revisor/dono confere o aceite. Documento criado antes do código da fronteira, atualizar na implementação e entrega, sem envio a terceiros.

## Revisão 2 — conflito identificado antes da implementação
Classificação acrescida: decisao-necessaria. A documentação oficial Conversions API Use Case (consulta 22/10/2026) orienta regras distintas para cada fonte (Insight Tag e servidor), deduplicando pelo mesmo eventId. O Core 1.47.0 exige conversion_id do adaptador igual ao ID do navegador/configuração. Não foi encontrado contrato oficial para transformar em API a regra Insight Tag existente ou adicionar fonte API ao mesmo ID. Não inventar endpoint ou mudar regra comercial silenciosamente.
LinkedIn implementará seleção/vínculo apenas de regra enabled=true com conversionMethod=CONVERSIONS_API, recusando regra_sem_fonte_api. O responsável Core precisa avaliar IDs separados browser/server mantendo eventId/tempo, ou apresentar prova oficial de regra única utilizável pelas duas fontes. Aceite da regra 31692506 fica bloqueado até resolver esta divergência e obter rw_conversions. Fonte: https://learn.microsoft.com/en-us/linkedin/marketing/conversions/conversions-usecase?view=li-lms-2026-09 .

## Revisão 3 — compatibilidade conferida no código consumidor
O texto do impacto recebido dizia record_id=event_id=eventId, mas F3Base_Linkedin_Conversoes::montar da 1.47.0 conserva record_id do contato e usa event_id/eventId da fotografia/aquisição, que podem ser diferentes. LinkedIn aceita a referência interna distinta, exige event_id=eventId e envia apenas eventId original. Também aceita li_fat_id de até 500 caracteres no formato [A-Za-z0-9._~-] do Core. A prova integrada usa montar() e adaptador() reais do Core recebido, sem modificar esse pacote. O responsável Core deve corrigir a redação do contrato para coincidir com sua implementação.

## Revisão 4 — resultado entregue
Adaptador, concessão explícita independente, capabilities local, sendBound e as seis abilities de conversão estão implementados. Preservam eventId/tempo, vinculam conta/regra/principal, revalidam escopo/papel/fonte API e impedem reenvio incerto. A prova integrada utilizou montar() e adaptador() reais do Core 1.47.0; 119 verificações passaram em atualização direta da 0.5.0. O modo isolado teve 86 aprovações. Site-Teste com Core 1.47.0: 11 cenários simulados aprovados e configuração temporária removida. Zero eventos reais enviados. Evidências no fonte, evidence/upgrade e evidence/site-teste-060.json.

Implementação própria concluída no escopo testado; destinatário ainda não confirmou resolução da regra Insight Tag/API nem corrigiu o texto de record_id. Fila, consentimento, captura de identificadores e política de até dez tentativas continuam responsabilidade do Core. Não implementado contrato opcional de reconciliação: resultado incerto permanece bloqueado. Não houve alteração do Core nem entrega de componente que lhe pertença. A homologação de 31692506 permanece bloqueada pelos motivos das revisões 2 e 3 e aprovação do fornecedor/ordem do dono. Não fechar esse aceite como entregue ao LinkedIn.
