# Impacto de Site Core 1.47.0 em Fator3 MCP LinkedIn

Data: 22/10/2026 · revisão 2 · etapa entrega · aberto · acao-necessaria.
Emissor base-site-core-fator3, base direta 1.46.1, alvo entregue 1.47.0. Instalador: base-site-core-fator3-1.47.0-instalador.zip, SHA-256 dd16cb720e57c2d448e78a744eb0fd761d6aff04aadeeed8309b6b5003b417c1.
Destinatário examinado: wp-mcp-linkedin-fator3 0.5.0, SHA-256 dcef9a7b236bdb84055baa4aa6db73ba2fcd3bdd9a7cea30905c2e771a563199. Natureza: contrato e desenvolvimento. Pedidos Core 285 / MCP LinkedIn 8.

## Mudança e consequência

O consumidor Core está implementado. O filtro público existente `f3base_conversoes_adaptador` recebe adaptador, destino `linkedin`, contrato `site-conversion-delivery/1.0.0` e quarto argumento de contexto `consumer_id=site-core-conversions`. Não há HTTP nem credencial LinkedIn no consumidor. O plugin LinkedIn 0.5.0 não oferece este adaptador; a fila indica bloqueio e não envia.

O adaptador fornece `capabilities()`, `send(payload)` e `sendBound(payload,destination_ref)`. O Core despacha somente por sendBound. Capabilities é leitura local e retorna contract, ready boolean, reason simbólico, destination_ref opaco e conversion_id **string** da regra comprovada. Core exige a regra do navegador/configuração atual. Conexão/regra/conta trocada bloqueia o vínculo antigo; não se aproveita concessão de Lead Sync como CAPI.

Payload específico `site-linkedin-conversion/1.0.0`: record_id, event_id, eventId (iguais ao ID aleatório congelado pelo Core), conversion (`urn:lla:llaPartnerConversion:<id>`), conversionHappenedAt em milissegundos e user. `user.userIds` leva SHA256_EMAIL normalizado e/ou LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID observado. `user.userInfo` leva nome/sobrenome juntos e, quando disponíveis, companyName, title e countryCode. Sem inferência de país pelo IP. `conversionValue` é opcional, currencyCode e amount, fotografado pelo filtro confiável do servidor `f3base_linkedin_valor_conversao(array(),form_id)`, com retorno valor/moeda. Não interpretar texto do visitante como receita. O provedor deve mapear somente o schema da API, sem encaminhar as chaves internas contract/record_id/event_id.

`sendBound` retorna status `entregue`, `recusado` ou `incerto`, code simbólico, http numérico e, quando pertinente, retry_after e non_delivery_proven. O código deve identificar a causa do LinkedIn sem incluir o corpo da API ou dado pessoal. Recusa comprovada permite até 10 tentativas dentro de 90 dias; incerto não repete automaticamente. Reconciliação opcional: `site-conversion-reconcile/1.0.0`. A recuperação administrativa exige confirmação explícita de não entrega e vínculo atual à mesma regra. Nenhum novo event_id ou horário no retry.

## Ação do responsável LinkedIn

Implementar adaptador e concessão explícita a site-core-conversions; verificar conexão, conta/regra, acesso rw_conversions e r_ads conforme API e papel na conta, fonte API comprovada localmente e autorização revalidada no despacho. Tokens, refresh, transporte, versão da API e tratamento do fornecedor ficam no LinkedIn. ready=false distingue sem_conexao, sem_escopo, regra_sem_fonte_api e demais causas. Não logar payload, nomes, e-mail, hashes de contato ou li_fat_id.

## Compatibilidade e sequência

Core 1.47.0 convive com LinkedIn 0.5.0: funções existentes permanecem; CAPI aguarda provedor. Testes, homologação, spam e ausência/revogação de consentimento publicitário não despacham. Novos formulários configurados capturam ambos; eventos anteriores não são transferidos e referência de destino ausente não é preenchida silenciosamente depois. Core mostra rota core_server/transporte ambos e aviso linkedin_server_<motivo>. Preserva o schema público de medição 1.0.0 consumido pelo Google 0.17.0.

## Validação e evidência

38 verificações de consumidor, oito em Chromium 153 com bundle real e 11 de convivência. Regra congelada vence HTML de cache antigo; lintrk usa conversion_id e event_id. Testados indisponibilidade/escopo/regra, troca de destino, recusa comprovada, incerto, teste/spam/consentimento e diário sem PII. Prévia `f3base/linkedin-conversao-previa` no Site-Teste retornou payload sintético com o mesmo ID e ms, envio_realizado=false e trafego_suprimido; o registro foi eliminado.

## Resposta esperada e encerramento

Responsável LinkedIn entrega versão/contrato, adapter e provas de autorização/envio. A frota, com escopo concedido e ordem do dono, homologa ctooffice: regra 31692506 com fonte API e contato contado uma vez no Campaign Manager. Reafirmar os IDs atuais por config-core-escrever registra procedência atual, sem fabricar autoria antiga.

Revisão 1 foi emitida no planejamento antes da implementação da fronteira. Revisão 2 registra contrato entregue e testes, acrescenta conversion_id string, HTTP, user.userInfo e recuperação vinculada. O Core foi concluído sem aguardar o provedor. Encaminhamento permanece aberto para implementação e aceite externo; documento entregue ao dono, sem transmissão a terceiros nesta rodada.
