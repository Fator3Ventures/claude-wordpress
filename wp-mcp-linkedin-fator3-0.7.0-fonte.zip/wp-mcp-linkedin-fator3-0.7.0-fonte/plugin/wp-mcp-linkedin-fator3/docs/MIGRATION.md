# Atualização 0.6.0 → 0.7.0

Substitua o ZIP de raiz wp-mcp-linkedin-fator3 e confirme 0.7.0, selftest, documentação, manutenção e service_audit no status. Core 1.47.0, MCP 0.27.0, Google 0.17.0 e Meta 0.4.1 são a combinação examinada. Não exige desativar acompanhantes ou alterar a fila Core.

Schema SQL permanece 1. Conexões, credenciais sobrepostas, concessões Lead Sync/CAPI, agendas, prévias, cursores e diários são preservados. Não cria nem reconfirma concessão na atualização. Novos diários de envio SDK recebem service_identity antes do POST; diários 0.6.0 sem vínculo permanecem legados, não são importados ou reemitidos automaticamente. Nenhum novo cron de auditoria é criado.

Reconfirmação/revogação da concessão altera sua revisão e bloqueia detalhes de referências antigas no leitor de serviço. Mudança de token exige prova local de escopos correspondente para ler. A referência central histórica, quando existir, permanece sob a retenção do MCP; diário local não é apagado por revogação. Veja SERVICE-AUDIT.md.

Voltar os arquivos à 0.6.0 remove descritor/introspector/leitor e emissão de serviço, preservando dados; o canal deve falhar fechado se o leitor ficar indisponível. CAPI e auditoria humana da base continuam existentes. Faça backup de arquivos, banco e salts e coordene a fila/escritores. Restaurar arquivos não desfaz conversões aceitas nem banco. Não recrie IDs para reenviar eventos confirmados/incertos. Desativação remove somente os hooks agendados próprios; desinstalação conserva dados.
