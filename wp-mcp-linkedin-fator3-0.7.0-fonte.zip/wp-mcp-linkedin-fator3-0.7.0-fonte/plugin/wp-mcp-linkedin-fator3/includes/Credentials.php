<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Credential material is stored only in the encrypted provider store. */
final class Credentials {
    public const SCOPES=['r_ads','rw_ads','r_ads_reporting','r_organization_social','w_organization_social','r_organization_admin','rw_organization_admin','r_marketing_leadgen_automation','rw_conversions'];
    public static function binding(array $c): string {return hash('sha256',Util::json([$c['token'],$c['client_id'],$c['client_secret']]));}
    public static function effective(array $c): array {
        $r=Store::get('credential',$c['id']);
        if($r&&hash_equals($r['value']['binding'],self::binding($c)))foreach(['token','refresh_token','expires_at','refresh_expires_at','credential_generation'] as $k)if(isset($r['value'][$k]))$c[$k]=$r['value'][$k];
        return $c+['refresh_token'=>'','refresh_expires_at'=>0];
    }
    private static function request(string $endpoint,array $body): array {
        if(!in_array($endpoint,['accessToken','introspectToken'],true))throw new Fault('endpoint_forbidden','Endpoint de autorização não permitido.');
        $r=wp_remote_post('https://www.linkedin.com/oauth/v2/'.$endpoint,['body'=>http_build_query($body,'','&',PHP_QUERY_RFC3986),'headers'=>['Content-Type'=>'application/x-www-form-urlencoded','Accept'=>'application/json'],'redirection'=>0,'sslverify'=>true,'timeout'=>12,'limit_response_size'=>65536]);
        if(is_wp_error($r))throw new Fault('oauth_unavailable','O LinkedIn não confirmou a solicitação de credencial.');
        $http=wp_remote_retrieve_response_code($r);$raw=wp_remote_retrieve_body($r);$v=json_decode($raw,true);
        if($http<200||$http>=300||strlen($raw)>=65536||!is_array($v))throw new Fault('oauth_rejected',$endpoint==='introspectToken'?'O LinkedIn recusou o par Client ID e Primary Client Secret na introspecção. Confira esses dois campos em Developers → aplicativo → Auth → Application credentials; copie o segredo pelo botão ao lado do valor.':'O LinkedIn recusou a autorização OAuth. Confira Client ID, Primary Client Secret e o Refresh Token ou código de autorização usado.',['http_status'=>$http,'credential_context'=>$endpoint==='introspectToken'?'client_id_and_primary_client_secret':'oauth_authorization','fields_to_check'=>$endpoint==='introspectToken'?['client_id','client_secret']:['client_id','client_secret','refresh_token']]);
        return $v;
    }
    private static function app(array $c): void {if(empty($c['client_id'])||empty($c['client_secret']))throw new Fault('application_required','Informe Client ID e Primary Client Secret (Developers → aplicativo → Auth → Application credentials) para verificar as permissões.');}
    public static function inspect(array $c): array {
        Connections::usable($c);self::app($c);
        $r=self::request('introspectToken',['client_id'=>$c['client_id'],'client_secret'=>$c['client_secret'],'token'=>$c['token']]);
        if(($r['active']??false)!==true||(!empty($r['client_id'])&&!hash_equals($c['client_id'],(string)$r['client_id']))||(!empty($r['expires_at'])&&(int)$r['expires_at']<=time()))throw new Fault('token_rejected','O Access Token está inativo, expirado ou pertence a outro Client ID. Confira o campo Token de acesso (Access Token) e a validade no LinkedIn Token Generator.');
        $scopes=array_values(array_filter(preg_split('/[\s,]+/',(string)($r['scope']??''))));
        return ['active'=>true,'scopes'=>$scopes,'expires_at'=>(int)($r['expires_at']??$c['expires_at']),'checked_at'=>time(),'source'=>'linkedin_introspection'];
    }
    public static function requireScopes(array $c,array $needed): array {
        $proof=self::inspect($c);$missing=array_values(array_diff($needed,$proof['scopes']));
        if($missing)throw new Fault('scope_missing','O token não recebeu as permissões necessárias. Autorize o aplicativo novamente.',['required_scopes'=>$needed,'missing_scopes'=>$missing,'remote_write_sent'=>false]);
        return $proof;
    }
    public static function inspectOperation(array $i): array {
        $c=Connections::get($i['connection_id']);Access::admin();$proof=self::inspect($c);
        Store::lock('token-proof:'.$c['id'],static function()use($c,$proof){Connections::revalidate($c);$r=Store::get('token_proof',$c['id']);Store::put('token_proof',$c['id'],$proof+['binding'=>self::binding($c)],$r['revision']??0);});
        return $proof;
    }
    public static function status(): array {
        $out=[];foreach(Store::list('connection',0,100) as $row){$c=Connections::get($row['key']);$h=Store::get('credential_health',$c['id']);$proof=Store::get('token_proof',$c['id']);$v=$h['value']??[];
            $out[]=['connection_id'=>$c['id'],'enabled'=>$c['enabled'],'days_remaining'=>$c['expires_at']?(int)ceil(($c['expires_at']-time())/86400):null,'expires_at'=>$c['expires_at'],'refresh_configured'=>!empty($c['refresh_token']),'refresh_expires_at'=>$c['refresh_expires_at'],'credential_generation'=>$c['credential_generation'],'last_refresh_at'=>$v['last_refresh_at']??null,'last_result'=>$v['last_result']??'not_attempted','failures'=>$v['failures']??0,'next_attempt'=>$v['next_attempt']??($c['expires_at']&&!empty($c['refresh_token'])?max(time(),$c['expires_at']-3*86400):null),'incident'=>$v['incident']??null,'notices'=>$v['notices']??[],'scopes'=>$proof&&hash_equals($proof['value']['binding'],self::binding($c))?$proof['value']['scopes']:[]];}
        return ['connections'=>$out,'next_maintenance'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null,'oauth_callback'=>self::callbackUrl(),'refresh_requires_provider_approval'=>true,'conversion_access'=>Conversions::scopeStatus()];
    }
    private static function health(string $id,array $patch): void {$r=Store::get('credential_health',$id);Store::put('credential_health',$id,array_replace($r['value']??[],$patch),$r['revision']??0);}
    public static function refresh(array $i,bool $automatic=false): array {
        if(!$automatic)Access::admin();
        return Store::lock('connection:'.$i['connection_id'],static function()use($i,$automatic){
            $c=Connections::get($i['connection_id']);if(!$automatic&&$c['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a conexão antes de renovar.');
            if(!$c['enabled'])throw new Fault('connection_paused','Conexão pausada.');
            if(empty($c['refresh_token']))throw new Fault('refresh_unavailable','Este aplicativo não forneceu token de renovação. Autorize novamente.');
            $admin=get_userdata((int)$c['updated_by']);if(!$admin||!user_can($admin,'manage_options'))throw new Fault('not_authorized','Administrador da conexão não está autorizado.');
            try{
                self::app($c);if($c['refresh_expires_at']&&$c['refresh_expires_at']<=time())throw new Fault('refresh_expired','A autorização de renovação expirou.');
                $v=self::request('accessToken',['grant_type'=>'refresh_token','refresh_token'=>$c['refresh_token'],'client_id'=>$c['client_id'],'client_secret'=>$c['client_secret']]);
                $new=self::tokens($v,$c);Connections::revalidate($c);
                // Overlay keeps the authorization revision used by Core, grants and subscription journals stable.
                $raw=Store::get('connection',$c['id']);$old=Store::get('credential',$c['id']);
                Store::put('credential',$c['id'],$new+['binding'=>self::binding($raw['value']),'credential_generation'=>$c['credential_generation']+1],$old['revision']??0);
                self::health($c['id'],['last_refresh_at'=>time(),'last_result'=>'refreshed','failures'=>0,'next_attempt'=>max(time()+3600,$new['expires_at']-3*86400),'incident'=>null,'notices'=>[]]);
                return ['refreshed'=>true,'grants_preserved'=>true,'credential_revision'=>$c['revision'],'expires_at'=>$new['expires_at'],'credential_generation'=>$c['credential_generation']+1];
            }catch(Fault $e){$h=Store::get('credential_health',$c['id']);$fails=($h['value']['failures']??0)+1;
                self::health($c['id'],['last_result'=>$e->reason,'failures'=>$fails,'next_attempt'=>time()+min(86400,300*(2**min($fails-1,8))),'incident'=>['code'=>$e->reason,'opened_at'=>$h['value']['incident']['opened_at']??time(),'last_at'=>time()]]);
                self::notice($c,'refresh_failure');throw $e;
            }
        });
    }
    private static function tokens(array $v,array $old): array {
        if(!is_string($v['access_token']??null)||$v['access_token']===''||strlen($v['access_token'])>16384||preg_match('/[\x00-\x20]/',$v['access_token'])||!is_numeric($v['expires_in']??null)||(int)$v['expires_in']<1)throw new Fault('oauth_invalid_response','A resposta de renovação não contém token e validade utilizáveis.');
        $refresh=$v['refresh_token']??$old['refresh_token'];if(!is_string($refresh)||strlen($refresh)>16384||preg_match('/[\x00-\x20]/',$refresh))throw new Fault('oauth_invalid_response','Token de renovação inválido.');
        return ['token'=>$v['access_token'],'expires_at'=>time()+(int)$v['expires_in'],'refresh_token'=>$refresh,'refresh_expires_at'=>isset($v['refresh_token_expires_in'])?time()+max(0,(int)$v['refresh_token_expires_in']):($old['refresh_expires_at']??0)];
    }
    private static function notice(array $c,string $kind): void {
        $h=Store::get('credential_health',$c['id']);$v=$h['value']??[];$notices=$v['notices']??[];$key=$kind.':'.$c['expires_at'];
        if(isset($notices[$key])&&($notices[$key]['sent']||$notices[$key]['at']>time()-86400))return;
        $destination=get_option('admin_email');$sent=false;
        if(is_email($destination))$sent=(bool)wp_mail($destination,'Fator3 MCP LinkedIn — atenção à credencial','A conexão '.$c['label'].' exige atenção: '.match($kind){'refresh_failure'=>'a renovação automática falhou. O token atual será preservado até seu vencimento.','expires_14'=>'o token vence em até 14 dias.','expires_3'=>'o token vence em até 3 dias.',default=>'o token está vencido.'}.' Acesse Ferramentas → Fator3 MCP LinkedIn → Conexão.');
        $notices[$key]=['at'=>time(),'sent'=>$sent];self::health($c['id'],['notices'=>$notices]);
    }
    public static function tick(): void {
        $until=microtime(true)+20;
        foreach(Store::list('connection',0,100) as $row){if(microtime(true)>$until)break;
            try{$c=Connections::get($row['key']);if(!$c['enabled']||!$c['token']||!$c['expires_at'])continue;
                $h=Store::get('credential_health',$c['id']);$remaining=$c['expires_at']-time();
                if(!empty($c['refresh_token'])&&$remaining<=3*86400&&($h['value']['next_attempt']??0)<=time())self::refresh(['connection_id'=>$c['id']],true);
                elseif(empty($c['refresh_token'])&&$remaining<=14*86400)Store::lock('connection:'.$c['id'],static function()use($c,$remaining){self::notice($c,$remaining<=0?'expired':($remaining<=3*86400?'expires_3':'expires_14'));});
            }catch(\Throwable $e){/* Failure state is available through status. Other connections continue. */}
        }
    }
    public static function callbackUrl(): string {return admin_url('admin-post.php?action=f3_linkedin_oauth_callback');}
    public static function start(array $i): array {
        Access::admin();$c=Connections::get($i['connection_id']);self::app($c);if($c['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a conexão.');
        if(wp_parse_url(self::callbackUrl(),PHP_URL_SCHEME)!=='https')throw new Fault('https_required','O retorno de autorização exige HTTPS.');
        $state=bin2hex(random_bytes(32));$key=hash('sha256',$state);
        Store::put('oauth_state',$key,['connection_id'=>$c['id'],'revision'=>$c['revision'],'user'=>get_current_user_id(),'session'=>hash('sha256',wp_get_session_token()),'expires'=>time()+600,'scopes'=>$i['scopes'],'used'=>false],0,time()+600);
        return ['consent_url'=>'https://www.linkedin.com/oauth/v2/authorization?'.http_build_query(['response_type'=>'code','client_id'=>$c['client_id'],'redirect_uri'=>self::callbackUrl(),'scope'=>implode(' ',$i['scopes']),'state'=>$state],'','&',PHP_QUERY_RFC3986),'expires_at'=>time()+600,'callback_url'=>self::callbackUrl()];
    }
    public static function finish(string $state,string $code): array {
        Access::admin();if(!preg_match('/^[a-f0-9]{64}$/D',$state)||$code===''||strlen($code)>4096)throw new Fault('oauth_state_invalid','Retorno de autorização inválido.');
        $key=hash('sha256',$state);
        return Store::lock('oauth:'.$key,static function()use($key,$code){$r=Store::get('oauth_state',$key);$v=$r['value']??[];
            if(!$r||($v['used']??true)||($v['expires']??0)<time()||($v['user']??0)!==get_current_user_id()||!hash_equals($v['session'],hash('sha256',wp_get_session_token())))throw new Fault('oauth_state_invalid','Retorno expirado, já usado ou de outra sessão.');
            $v['used']=true;Store::put('oauth_state',$key,$v,$r['revision'],$v['expires']);
            return Store::lock('connection:'.$v['connection_id'],static function()use($v,$code){$c=Connections::get($v['connection_id']);if($c['revision']!==$v['revision'])throw new Fault('revision_conflict','A conexão mudou durante a autorização.');self::app($c);
                $reply=self::request('accessToken',['grant_type'=>'authorization_code','code'=>$code,'client_id'=>$c['client_id'],'client_secret'=>$c['client_secret'],'redirect_uri'=>self::callbackUrl()]);
                // New authorization is never silently attached to the old refresh credential.
                $tokens=self::tokens($reply,['refresh_token'=>'','refresh_expires_at'=>0]);
                $new=array_replace($c,$tokens);unset($new['revision']);$new['token_configured']=true;$new['credential_generation']=($c['credential_generation']??1)+1;$new['remote_proof']=null;$new['updated_at']=time();$new['updated_by']=get_current_user_id();
                Store::put('connection',$c['id'],$new,$c['revision']);self::health($c['id'],['last_result'=>'authorized','failures'=>0,'next_attempt'=>max(time()+3600,$tokens['expires_at']-3*86400),'incident'=>null,'notices'=>[]]);
                return ['authorized'=>true,'connection_id'=>$c['id'],'refresh_configured'=>$tokens['refresh_token']!=='','grants_preserved'=>true,'consumer_reconfirmation_required'=>true];
            });
        });
    }
    public static function callback(): void {
        nocache_headers();header('Referrer-Policy: no-referrer');
        $r=Result::run(static fn()=>self::finish((string)($_GET['state']??''),(string)($_GET['code']??'')));
        set_transient('f3_linkedin_oauth_notice_'.get_current_user_id(),['success'=>$r['success'],'code'=>$r['code']],300);
        wp_safe_redirect(admin_url('tools.php?page='.Config::SLUG.'&tab=connections'));exit;
    }
}
