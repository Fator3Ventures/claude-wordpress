<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);
foreach(['Meta','LinkedIn'] as $name){$ns='Fator3\\'.$name.'\\';$config=$ns.'Config';if(!class_exists($config))continue;if(!in_array($config::VERSION,[$name==='LinkedIn'?'0.6.0':'0.4.1'],true))throw new RuntimeException('Expected immutable direct baseline');$conn=$ns.'Connections';$store=$ns.'Store';$p=['user_id'=>1,'channel'=>null];$meta=$name==='Meta';$channel=$meta?'instagram':'pages';
$assets=$meta?['instagram'=>['111']]:['pages'=>['111'],'ads'=>['222'],'leads'=>['222']];$i=['connection_id'=>'legacy','expected_revision'=>0,'token'=>'synthetic-baseline-token','assets'=>$assets,'retention_days'=>365];if(!$meta)$i+=['forms'=>['222'=>['633']],'application_id'=>'app-legacy','client_id'=>'client-legacy'];$conn::save($i);
$q=['connection_id'=>'legacy','channel'=>$channel,'account_id'=>'111','report'=>$meta?'profile':'organization'];$job=str_repeat($meta?'a':'b',64);$data=['contract'=>'social-reporting/1.0.0','connection_id'=>'legacy','channel'=>$channel,'account_id'=>'111','report'=>$q['report'],'api_version'=>$config::API_VERSION,'selection'=>$q,'fetched_at'=>gmdate('c',time()-100*86400),'rows'=>[['id'=>'111','name'=>'Legacy retained']],'fields'=>['id','name'],'coverage'=>['complete'=>true,'errors'=>[]],'temporal'=>'snapshot','timezone'=>'provider_defined','currency'=>null,'next_cursor'=>null];
$store::put('job',$job,['query'=>$q,'principal'=>$p,'connection_revision'=>1,'status'=>'complete','pages'=>1,'rows'=>1,'created_at'=>time()-100*86400,'updated_at'=>time()-100*86400,'next_at'=>0,'last_code'=>null,'errors'=>[]],0,time()-1);
$store::put('result',$job.':000000',['principal'=>$p,'connection_revision'=>1,'query'=>$q,'data'=>$data],0,time()+200*86400);
$store::put('schedule','legacy',['query'=>$q,'principal'=>$p,'connection_revision'=>1,'enabled'=>true,'interval_minutes'=>1440,'lookback_days'=>7,'next_at'=>time()+86400,'last_job'=>null,'last_code'=>null]);
if(!$meta){$want=['webhook'=>'https://example.com/consumer','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:222'],'versionedForm'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:633,1)','leadType'=>'SPONSORED'];$store::put('subscription',str_repeat('c',64),['consumer'=>'qa','connection_id'=>'legacy','credential_revision'=>1,'wanted'=>$want,'state'=>'creating','remote_id'=>null,'created_at'=>time()-3600]);}
}
echo "{\"baseline_seeded\":true}\n";

if(class_exists('Fator3\\LinkedIn\\Conversions')){
 $ns='Fator3\\LinkedIn\\';$store=$ns.'Store';$c=($ns.'Connections')::get('legacy');
 $g=['consumer_id'=>'site-core-conversions','enabled'=>true,'connection_id'=>'legacy','connection_revision'=>$c['revision'],'account_id'=>'222','conversion_id'=>'67890','rule'=>['id'=>'67890','account_id'=>'222','enabled'=>true,'conversion_method'=>'CONVERSIONS_API','checked_at'=>time()],'scopes'=>['rw_conversions','r_ads'],'principal'=>['user_id'=>1,'channel'=>null],'destination_ref'=>str_repeat('7',64),'created_at'=>time()];
 $store::put('conversion_grant','site-core-conversions',$g,0);
 $store::put('token_proof','legacy',['active'=>true,'scopes'=>['rw_conversions','r_ads'],'checked_at'=>time(),'expires_at'=>time()+10000,'binding'=>($ns.'Credentials')::binding($c)],0);
 $store::put('conversion_preview',str_repeat('8',64),['digest'=>str_repeat('9',64),'expires'=>time()+600],0,time()+600);
 $result=['status'=>'entregue','code'=>'linkedin_http_201','http'=>201,'non_delivery_proven'=>false];
 $store::put('conversion_event',str_repeat('a0',32),['connection_id'=>'legacy','account_id'=>'222','conversion_id'=>'67890','principal'=>['user_id'=>1,'channel'=>null],'service'=>true,'payload_digest'=>str_repeat('b0',32),'state'=>'confirmed','created_at'=>time(),'before'=>['status'=>'nao_enviado'],'after'=>$result,'operation'=>'send-conversion-event','result'=>$result],0);
 $hashes=[];foreach([['conversion_grant','site-core-conversions'],['token_proof','legacy'],['conversion_preview',str_repeat('8',64)],['conversion_event',str_repeat('a0',32)]] as [$bucket,$key])$hashes[]=['bucket'=>$bucket,'key'=>$key,'sha256'=>hash('sha256',wp_json_encode($store::get($bucket,$key)))];
 file_put_contents(getenv('F3_LAB_ROOT').'/baseline-capi070.json',wp_json_encode($hashes));
}
