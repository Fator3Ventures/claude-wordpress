<?php
if(getenv('F3_LAB_ORIGIN')!=='upgrade'||!class_exists('Fator3\\LinkedIn\\ServiceAudit'))return;
check('070 direct 0.6 upgrade preserves CAPI grant, proof, preview and unbound service journal exactly',function(){
 $saved=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/baseline-capi070.json'),true);
 foreach($saved as $item){$r=\Fator3\LinkedIn\Store::get($item['bucket'],$item['key']);expect(hash('sha256',wp_json_encode($r))===$item['sha256'],$item['bucket']);}
 $s=\Fator3\LinkedIn\Conversions::capabilities();expect($s['ready']&&$s['destination_ref']===str_repeat('7',64));
 $i=['provider'=>'wp-mcp-linkedin-fator3','consumer_id'=>'site-core-conversions','principal_ref'=>str_repeat('1',64),'grant_revision'=>str_repeat('2',64),'operation_id'=>str_repeat('a0',32)];
 expect(f3_linkedin_introspect_service_grant($i)['code']==='service_operation_unbound');
 // Remove only this seeded grant to allow the independent fresh-grant regression scenarios.
 $r=\Fator3\LinkedIn\Store::get('conversion_grant','site-core-conversions');\Fator3\LinkedIn\Store::remove('conversion_grant','site-core-conversions',$r['revision']);
});
