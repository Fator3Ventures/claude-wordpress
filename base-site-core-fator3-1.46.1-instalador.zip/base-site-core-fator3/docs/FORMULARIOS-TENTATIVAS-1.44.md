> Atualização 1.45.0: retenções e migração em RETENCAO-1.45.md; telefone em TELEFONE-1.45.md; recuperação e demais mudanças em RELEASE-1.45.0.md. As unidades e os padrões anteriores abaixo são históricos.

# Tentativas barradas — pedido 263

## Uso

Em **Site Core → Configurações → Privacidade e segurança → Retenção**, escolha **Tentativas barradas — guardar o valor digitado** e **Dias de guarda das tentativas**. Padrão: ligado, 30 dias; intervalo de 1–90 dias. Desligar impede novas capturas de valores tanto no navegador quanto no servidor. Dados anteriores continuam sob retenção e eliminação. É diagnóstico operacional local de uma ação explícita de envio; não grava o que é digitado a cada tecla. Sem sessão de medição disponível, usa uma sessão operacional aleatória apenas na memória da página, sem criar identificador persistente de navegação.

## Leitura

`f3base/formularios-tentativas-ler` exige **f3base_ler_leads**, inclusive para administrador; manage_options sozinho não substitui essa permissão. Administradores recebem a capacidade no fluxo administrativo já existente do Core. Entrada: formulário, sessão, instância, de/até (datas no fuso do site), dias (1–90), segmento, após_id e limite (1–100). Retorna proximo_id; continue enquanto for diferente de zero. Ordene a sequência por instância e sequencia; criado_em é o recebimento no servidor e ocorrido_ms é horário declarado pelo navegador, sujeito ao relógio dele.

Exemplo de entrada sintética:

```json
{"formulario":"contato-whatsapp","de":"2026-10-21","ate":"2026-10-21","limite":100,"segmento":"todos"}
```

Cada campo traz nome, estado (`vazio`, `preenchido`, `invalido`), regras e, se capturado, valor. Regras: valueMissing, typeMismatch, tooShort, tooLong, patternMismatch, rangeUnderflow, rangeOverflow, stepMismatch, badInput, customError, exigir-um-de, telefone_formato e arquivo_limite. O motivo do telefone distingue sem_ddd, ddd_invalido, quantidade_digitos, prefixo_invalido, caracteres_invalidos, formato_internacional e formato_pais. Regra e estado são a observação do navegador, não certificação de identidade ou de intenção.

Tipos: `recusado` (fotografia), `correcao` (campo antes recusado tornou-se válido no change, sem valor), `envio` (record_id verificado pelo servidor; etapa 2 exige complemento registrado) e `saida` (fechamento/saída observado). Saída não comprova abandono definitivo; pode haver retorno. Falta de envio não equivale a abandono comprovado. Captura pode faltar se JavaScript/rede estiver bloqueado ou a página for encerrada antes da requisição.

`f3base/comportamento-ler` acrescenta `recusas_por_campo`, com contagem por formulário/campo/regra, período, formulário e sessão. Não descriptografa valores. Quando usados nessa rota, formulário e sessão delimitam somente esse bloco, pois as linhas agregadas históricas não contêm essas dimensões. As contagens não se igualam necessariamente aos eventos antigos f3base_form_recusado: uma tentativa contém vários campos/regras e o acervo detalhado nasce na 1.44.0. A soma é exata até 50.000 tentativas consultadas; acima disso retorna corte e contagens_exatas=false.

## Salvaguardas

- Tabela isolada por site; valores JSON cifrados por sodium secretbox com nonce aleatório e chave derivada do salt secure_auth para esta finalidade. Trocar o salt impede ler cifras antigas; backup do WordPress deve conservar a chave com acesso restrito, pelo ciclo próprio do backup.
- O servidor aceita somente nomes declarados na etapa e regras de lista fechada. Não captura token, honeypot, campos escondidos, senhas, arquivos nem seus nomes. Valores com mais de 4.000 unidades de texto, ou excedentes do orçamento de 59 KB por fotografia, são truncados com valor_truncado=true. Essa limitação não altera o envio do formulário.
- Endpoint público com token/revisão de formulário, mesma origem quando declarada, idempotência por evento, bloqueio de concorrência, limite de corpo 64 KiB, 180 registros por origem/10 minutos e 200 por sessão/dia. Falha no diagnóstico não impede o envio do contato; nenhum valor é repetido na resposta de erro.
- Retenção oculta registros vencidos em qualquer leitura e apaga fisicamente no cron de retenção/notificações do Core. Atraso do WP-Cron pode atrasar a remoção física, mas não estende a janela legível.
- `f3base/leads-eliminar-registro` usa a eliminação canônica: inclui todas as tentativas da sessão e demais instâncias nela. Falha impede declarar a eliminação concluída. Marcadores opacos em leads_janelas impedem reaparecimento por repetição tardia durante 91 dias, sem guardar valores ou identificação legível. O eraser de privacidade WordPress busca pelo HMAC do e-mail capturado e apaga as sessões mesmo quando não houve contato aceito. Se nenhum e-mail foi digitado, o vínculo para atendimento ao titular deve ser a sessão/contato conhecida; não é possível inferir a pessoa a partir de formulário anônimo vazio.
- Não grava valores nas tabelas de lead/apresentação, logs de medição, Slack, e-mail, webhook, Pipedrive ou anúncios. Nenhum novo evento GA4, Meta ou Clarity contém o valor. A ability privada devolve o valor ao operador autorizado para atender ao pedido de leitura; não o publica nem o encaminha automaticamente.

## Aceite

No teste, enviar vazio; testar 98765-4321 (sem DDD) e (11) 98765-432 (quantidade de dígitos), corrigir, concluir etapa 1/2, consultar por sessão e eliminar o contato. Confirmar a ausência de todas as tentativas daquela sessão e preservação de outra sessão. Só considerar o aceite específico do ctooffice cumprido após implantar e ler fatos posteriores à troca nesse site. Não reconstruir valores de recusas anteriores.
