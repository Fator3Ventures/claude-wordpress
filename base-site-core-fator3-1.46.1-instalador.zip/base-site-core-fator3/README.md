# Fator3 Site Core 1.46.1

Instalação nova ou atualização direta da base 1.46.0. Contrato administrativo 8.11.0. Leia docs/DOCUMENTACAO.md e docs/RELEASE-1.46.1.md. Correção do reaquecimento no WP Super Cache com cabeçalhos; evidências e limites no relatório externo.
