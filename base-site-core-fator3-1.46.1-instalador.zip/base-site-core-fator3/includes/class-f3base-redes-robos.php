<?php
/** Listas oficiais em cache. O IP existe somente na pilha da verificação. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Redes_Robos {
    const EVENTO='f3base_redes_robos_atualizar';
    const FONTES=array(
        'nuvem-aws'=>'https://ip-ranges.amazonaws.com/ip-ranges.json',
        'nuvem-google'=>'https://www.gstatic.com/ipranges/cloud.json',
        'nuvem-azure'=>'https://www.microsoft.com/en-us/download/details.aspx?id=56519',
        'duckassistbot'=>'https://duckduckgo.com/duckassistbot.json',
        'perplexitybot'=>'https://www.perplexity.com/perplexitybot.json',
        'perplexity-user'=>'https://www.perplexity.com/perplexity-user.json',
        'bingbot'=>'https://www.bing.com/toolbox/bingbot.json',
        'oai-searchbot'=>'https://openai.com/searchbot.json',
        'gptbot'=>'https://openai.com/gptbot.json',
        'chatgpt-user'=>'https://openai.com/chatgpt-user.json',
        'oai-adsbot'=>'https://openai.com/adsbot.json',
        'claude'=>'https://claude.com/crawling/bots.json',
        'google-agent'=>'https://developers.google.com/static/crawling/ipranges/user-triggered-agents.json',
        'googlebot'=>'https://developers.google.com/static/crawling/ipranges/common-crawlers.json',
        'google-user'=>'https://developers.google.com/static/crawling/ipranges/user-triggered-fetchers-google.json'
    );
    private static ?array $listas=null;
    public static function iniciar(): void {
        add_action(self::EVENTO,F3Base_Operacao::callback(self::EVENTO,array(__CLASS__,'atualizar')));
        add_action('init',static function(){if(!empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])&&!wp_next_scheduled(self::EVENTO)){wp_schedule_event(time()+60,'daily',self::EVENTO);}},110);
    }
    public static function estado_fontes(): array {
        $s=F3Base_Options::ler('f3base_redes_robos');$out=array();
        foreach(self::FONTES as $key=>$url){$l=$s['listas'][$key]??array();$out[$key]=array('fonte'=>$url,'obtida_em'=>$l['obtida_em']??null,'valida_ate'=>$l['valida_ate']??null,'estado'=>empty($l)?'sem_lista':(($l['valida_ate']??0)<time()?'expirada':'atual'),'ultima_tentativa'=>$s['tentativas'][$key]??null);}
        return array('fontes'=>$out,'coleta'=>'Todas as fontes, inclusive nuvens, são tentadas diariamente em lotes de duas. Fontes indisponíveis aguardam pelo menos uma hora entre tentativas; continuações dependem do cron.','proxima_atualizacao'=>wp_next_scheduled(self::EVENTO),'historico'=>'Atualizar a lista vale para novas verificações. Registros antigos preservam a classificação e a data da lista usada na coleta.');
    }
    public static function validar(string $body): ?array {
        if(strlen($body)>1048576){return null;}$v=json_decode($body,true);if(!is_array($v)||!is_array($v['prefixes']??null)||!$v['prefixes']||count($v['prefixes'])>10000){return null;}$out=array();
        foreach($v['prefixes'] as $p){if(!is_array($p)){return null;}$s=$p['ipv4Prefix']??$p['ipv6Prefix']??null;if(!is_string($s)||!self::cidr_valido($s)){return null;}$out[]=$s;}
        $out=array_values(array_unique($out));sort($out);return array('prefixos'=>$out,'versao'=>is_string($v['creationTime']??null)?substr($v['creationTime'],0,64):'nao_informada','sha256'=>hash('sha256',wp_json_encode($out)));
    }
    private static function cidr_valido(string $s): bool {$a=explode('/',$s);if(count($a)!==2||!ctype_digit($a[1])||!filter_var($a[0],FILTER_VALIDATE_IP)){return false;}return (int)$a[1]<=strlen(inet_pton($a[0]))*8;}
    public static function contem(string $ip,string $cidr): bool {
        if(!self::cidr_valido($cidr)||!filter_var($ip,FILTER_VALIDATE_IP)){return false;}[$net,$n]=explode('/',$cidr);$ip=inet_pton($ip);$net=inet_pton($net);if(strlen($ip)!==strlen($net)){return false;}$bits=(int)$n;$bytes=intdiv($bits,8);$rest=$bits%8;
        return substr($ip,0,$bytes)===substr($net,0,$bytes)&&(!$rest||((ord($ip[$bytes])&(255<<(8-$rest)))===(ord($net[$bytes])&(255<<(8-$rest)))));
    }
    public static function azure_url(string $html): string {
        $html=str_replace('\\/','/',html_entity_decode($html,ENT_QUOTES|ENT_HTML5,'UTF-8'));
        if(!preg_match('~https://download\.microsoft\.com/download/[A-Za-z0-9/-]+/ServiceTags_Public_[0-9]{8}\.json~',$html,$m)){return '';}
        return $m[0];
    }
    public static function validar_nuvem(string $key,string $body): ?array {
        if(strlen($body)>8388608){return null;}$v=json_decode($body,true);if(!is_array($v)){return null;}$cidrs=array();$version='';
        if($key==='nuvem-azure'){$version=(string)($v['changeNumber']??'');foreach($v['values']??array() as $tag){if(($tag['name']??'')==='AzureCloud'){$cidrs=$tag['properties']['addressPrefixes']??array();break;}}}
        elseif($key==='nuvem-aws'){$version=(string)($v['createDate']??'');foreach(array_merge($v['prefixes']??array(),$v['ipv6_prefixes']??array()) as $r){if(($r['service']??'')==='AMAZON'){$cidrs[]=$r['ip_prefix']??$r['ipv6_prefix']??'';}}}
        elseif($key==='nuvem-google'){$version=(string)($v['creationTime']??'');foreach($v['prefixes']??array() as $r){if(($r['service']??'')==='Google Cloud'){$cidrs[]=$r['ipv4Prefix']??$r['ipv6Prefix']??'';}}}
        if(!$cidrs||count($cidrs)>60000){return null;}foreach($cidrs as $cidr){if(!is_string($cidr)||!self::cidr_valido($cidr)){return null;}}$cidrs=array_values(array_unique($cidrs));sort($cidrs);
        return array('prefixos'=>$cidrs,'versao'=>substr($version,0,64),'sha256'=>hash('sha256',wp_json_encode($cidrs)));
    }
    /** Uses only the already configured trust boundary; no raw IP is retained. */
    public static function nuvem(string $ip,?array $listas=null): array {
        if($listas===null){if(empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])){return array();}$listas=F3Base_Options::ler('f3base_redes_robos')['listas']??array();}
        foreach(array('nuvem-aws','nuvem-google','nuvem-azure') as $key){$l=$listas[$key]??array();if(($l['valida_ate']??0)<time()){continue;}foreach($l['prefixos']??array() as $cidr){if(self::contem($ip,$cidr)){return array('provedor'=>$key,'lista_sha256'=>$l['sha256'],'lista_em'=>$l['obtida_em'],'lista_versao'=>$l['versao']);}}}return array();
    }
    /** Only explicit official equivalents cross hosts; no suffix/registrable-domain guess. */
    private static function redirecionamento_permitido(string $origem,string $destino): bool {
        $from=wp_parse_url($origem);$to=wp_parse_url($destino);
        if(!is_array($to)||($to['scheme']??'')!=='https'||empty($to['host'])||isset($to['user'])||isset($to['pass'])||(isset($to['port'])&&(int)$to['port']!==443)){return false;}
        $a=strtolower($from['host']??'');$b=strtolower($to['host']);
        return $a===$b||(in_array($a,array('www.perplexity.com','www.perplexity.ai'),true)&&in_array($b,array('www.perplexity.com','www.perplexity.ai'),true));
    }
    /** Manual redirect handling preserves diagnostics even when a destination is refused. */
    private static function obter_fonte(string $url,int $limite): array {
        $inicio=microtime(true);$diag=array('url'=>$url,'url_final'=>$url,'http_status'=>null,'redirecionamentos'=>array());$visited=array();
        for($hop=0;$hop<=2;$hop++){
            $visited[$url]=true;$remaining=6-(microtime(true)-$inicio);
            if($remaining<=0){$diag['erro_transporte']='tempo_total_excedido';return array(null,$diag);}
            $r=wp_safe_remote_get($url,array('timeout'=>$remaining,'redirection'=>0,'limit_response_size'=>$limite,'sslverify'=>true,'cookies'=>array(),'headers'=>array('Accept'=>'application/json'),'user-agent'=>'F3Base-Rede/1.46.0'));
            $diag['url_final']=$url;
            if(is_wp_error($r)){$diag['erro_transporte']=sanitize_key((string)$r->get_error_code());return array(null,$diag);}
            $status=(int)wp_remote_retrieve_response_code($r);$diag['http_status']=$status;
            if($status<300||$status>=400){return array($r,$diag);}
            $location=(string)wp_remote_retrieve_header($r,'location');$destino=$location?WP_Http::make_absolute_url($location,$url):'';
            $permitido=in_array($status,array(301,302),true)&&$destino&&self::redirecionamento_permitido($url,$destino)&&$hop<2&&!isset($visited[$destino]);
            $diag['destino_redirecionamento']=substr(esc_url_raw($destino),0,2048);
            $diag['redirecionamentos'][]=array('http_status'=>$status,'origem'=>$url,'destino'=>$diag['destino_redirecionamento'],'seguido'=>(bool)$permitido);
            if(!$permitido){$diag['erro']='redirecionamento_nao_seguido';return array($r,$diag);}
            $url=$destino;
        }
        return array(null,$diag);
    }
    private static function agendar_continuacao(int $quando): bool {
        $args=array('continuacao');$old=wp_next_scheduled(self::EVENTO,$args);
        if($old&&$old<=$quando){return true;}
        if($old&&!wp_unschedule_event($old,self::EVENTO,$args)){return false;}
        if(wp_schedule_single_event($quando,self::EVENTO,$args)){return true;}
        if($old){wp_schedule_single_event($old,self::EVENTO,$args);}return false;
    }
    public static function atualizar(): array {
        if(empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])){return array('ok'=>true,'codigo'=>'desligado');}
        $lock=F3Base_Trava::adquirir('redes-oficiais',30);if(!$lock){return array('ok'=>false,'codigo'=>'atualizacao_em_execucao');}
        try{$state=F3Base_Options::ler('f3base_redes_robos');$now=time();$due=array();$retry=0;
            foreach(self::FONTES as $key=>$url){
                $list=$state['listas'][$key]??array();$attempt=$state['tentativas'][$key]??array();
                $failed=!empty($attempt)&&($attempt['resultado']??'')!=='atualizada';
                $needed=empty($list['prefixos'])||($list['valida_ate']??0)<=$now||$failed||($list['obtida_em']??0)<=$now-DAY_IN_SECONDS;
                if(!$needed){continue;}$next=(int)($attempt['em']??0)+HOUR_IN_SECONDS;
                if($next<=$now){$due[]=$key;}else{$retry=$retry?min($retry,$next):$next;}
            }
            // Oldest attempted source first: a failing/missing list never starves another source.
            usort($due,static fn($a,$b)=>(($state['tentativas'][$a]['em']??0)<=>($state['tentativas'][$b]['em']??0))?:strcmp($a,$b));$results=array();
            foreach(array_slice($due,0,2) as $key){
                $url=self::FONTES[$key];[$r,$diag]=self::obter_fonte($url,str_starts_with($key,'nuvem-')?8388609:1048577);
                if($key==='nuvem-azure'&&$r&&($diag['http_status']??0)===200){
                    $link=self::azure_url(wp_remote_retrieve_body($r));
                    if($link){$catalogo=$diag;[$r,$diag]=self::obter_fonte($link,8388609);$diag['catalogo']=$catalogo;}
                    else{$r=null;$diag['erro']='lista_azure_ausente';}
                }
                $parsed=$r&&($diag['http_status']??0)===200?(str_starts_with($key,'nuvem-')?self::validar_nuvem($key,wp_remote_retrieve_body($r)):self::validar(wp_remote_retrieve_body($r))):null;
                if($parsed){$state['listas'][$key]=$parsed+array('url'=>$diag['url_final'],'obtida_em'=>time(),'valida_ate'=>time()+7*DAY_IN_SECONDS);$results[$key]='atualizada';}
                else{$results[$key]='fonte_indisponivel';$retry=$retry?min($retry,time()+HOUR_IN_SECONDS):time()+HOUR_IN_SECONDS;}
                $result=$parsed?'atualizada':('fonte_indisponivel_'.(!empty($diag['erro_transporte'])?'transporte_'.$diag['erro_transporte']:'http_'.(int)($diag['http_status']??0)));
                if(!$parsed&&($diag['http_status']??0)===200&&empty($diag['erro'])){$diag['erro']='conteudo_invalido';}
                $state['tentativas'][$key]=array('em'=>time(),'resultado'=>$result,'codigo'=>$results[$key])+$diag;
            }
            $state['cursor']=0;$state['atualizado_em']=time();$saved=F3Base_Options::atualizar_estado('f3base_redes_robos',static fn()=>$state);self::$listas=null;
            $pending=max(0,count($due)-count($results));$next=$pending?time()+10:$retry;$scheduled=!$next||self::agendar_continuacao($next);
            return array('ok'=>!empty($saved['persisted'])&&$scheduled,'codigo'=>$scheduled?($pending?'atualizacao_em_lotes':'lote_concluido'):'continuacao_nao_agendada','fontes'=>$results,'pendentes'=>$pending,'restantes'=>$pending,'parcial'=>$pending>0,'proxima_tentativa'=>$next?:null);
        }finally{F3Base_Trava::liberar($lock);}
    }

    public static function verificar(string $familia,string $ip,bool $confiavel,?int $em=null,?array $listas=null): array {
        $key=in_array($familia,array('claudebot','claude-searchbot','claude-user'),true)?'claude':(in_array($familia,array('googlebot','googlebot-image'),true)?'googlebot':($familia==='google-gemini-notebook'?'google-user':$familia));
        $r=array('rede_estado'=>'sem_fonte_oficial','rede_lista'=>'','rede_data'=>0,'rede_versao'=>'');
        if($listas===null&&empty(F3Base_Options::ler('f3base_medicao_editorial')['redes_oficiais'])){$r['rede_estado']='nao_verificada';return $r;}
        if(!isset(self::FONTES[$key])){return $r;}
        if(!$confiavel||!filter_var($ip,FILTER_VALIDATE_IP)){$r['rede_estado']='ip_nao_confiavel';return $r;}
        if($listas===null){if(self::$listas===null){self::$listas=F3Base_Options::ler('f3base_redes_robos')['listas']??array();}$listas=self::$listas;}
        $list=$listas[$key]??array();$r['rede_data']=(int)($list['obtida_em']??0);$r['rede_versao']=(string)($list['versao']??'');$r['rede_lista']=(string)($list['sha256']??'');if(!$list||($list['valida_ate']??0)<time()){$r['rede_estado']='fonte_expirada';return $r;}
        $r['rede_lista']=$list['sha256'];$r['rede_data']=(int)$list['obtida_em'];$r['rede_versao']=$list['versao'];$r['rede_estado']='fora_das_faixas';
        foreach($list['prefixos'] as $cidr){if(self::contem($ip,$cidr)){$r['rede_estado']='rede_compativel';break;}}
        // A data da lista é preservada; não afirma autenticação na data histórica do acesso.
        return $r;
    }
}
