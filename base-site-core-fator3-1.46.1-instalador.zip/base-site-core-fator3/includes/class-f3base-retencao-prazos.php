<?php
/** Monthly retention policy. Query windows and provider delivery deadlines are separate. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Retencao_Prazos {
    private static bool $migrando=false;
    const OPTION='f3base_retencoes_tecnicas';
    const LEGADO=array('f3base_comportamento'=>array('retencao_dias'=>'retencao_meses','retencao_eventos_dias'=>'retencao_eventos_meses'),'f3base_acessos'=>array('retencao_horaria_dias'=>'retencao_horaria_meses'),'f3base_pipedrive'=>array('retencao_entregas_dias'=>'retencao_entregas_meses'),'f3base_formulario_tentativas'=>array('retencao_dias'=>'retencao_meses'));
    const TECNICAS=array('avisos'=>'Avisos concluídos e partes do Slack','meta_capi'=>'Histórico das conversões da Meta pelo servidor','recusas'=>'Recusas de envio por motivo','404'=>'Páginas não encontradas amostradas','sondas'=>'Sondas de teste','diagnostico'=>'Diagnóstico de captura','operacoes'=>'Operações internas concluídas');
    const CAMPOS=array('f3base_comportamento'=>array('retencao_meses'=>'Resumo de comportamento','retencao_eventos_meses'=>'Comportamento detalhado'),'f3base_acessos'=>array('retencao_meses'=>'Acessos do servidor','retencao_horaria_meses'=>'Acessos do servidor por hora'),'f3base_medicao_editorial'=>array('retencao_meses'=>'Agregados editoriais'),'f3base_pipedrive'=>array('retencao_entregas_meses'=>'Histórico das entregas ao Pipedrive'),'f3base_formulario_tentativas'=>array('retencao_meses'=>'Tentativas barradas'),'f3base_clarity'=>array('retencao_meses'=>'Acervo do Clarity'));
    /** Clamp to the last day of the destination month, avoiding PHP month overflow. */
    public static function deslocar(int $meses,int $agora=0): int {
        $d=(new DateTimeImmutable('@'.($agora?:time())))->setTimezone(wp_timezone());
        $first=$d->modify('first day of this month')->modify(($meses<0?'':'+').$meses.' months');
        return $first->setDate((int)$first->format('Y'),(int)$first->format('m'),min((int)$d->format('d'),(int)$first->format('t')))->getTimestamp();
    }
    public static function converter_dias(int $dias,int $agora=0): int {
        $agora=$agora?:time();$m=max(1,(int)ceil($dias/30));
        while(self::deslocar(-$m,$agora)>$agora-$dias*DAY_IN_SECONDS){++$m;}
        return $m;
    }
    public static function converter(string $nome,$v) {
        if(!is_array($v)){return $v;}
        foreach(self::LEGADO[$nome]??array() as $old=>$new){if(array_key_exists($old,$v)){if(!array_key_exists($new,$v)){$v[$new]=self::converter_dias((int)$v[$old]);}unset($v[$old]);}}
        if($nome==='f3base_clarity'&&isset($v['retencao_meses'])&&(int)$v['retencao_meses']===0){$v['retencao_meses']=120;}
        return $v;
    }
    public static function catalogo(array $c): array {
        $range=array('type'=>'integer','minimum'=>1,'maximum'=>120);
        $c['f3base_retencao_meses']['padrao']=60;$c['f3base_retencao_meses']['rotulo']='Contatos — guarda em meses';
        $c['f3base_retencao_meses']['descricao']='Padrão de 60 meses em instalações novas. Escolha de 1 a 120 meses. Reduzir o prazo elimina dados vencidos na próxima limpeza.';
        $c['f3base_retencao_meses']['schema_config']=$range;$c['f3base_retencao_meses']['schema_entrada']=$range;
        foreach(self::CAMPOS as $name=>$fields){foreach($fields as $key=>$label){
            $c[$name]['padrao'][$key]=60;
            $c[$name]['subcampos'][$key]=array('tipo'=>'inteiro','rotulo'=>$label.' — meses de guarda','minimo'=>1,'maximo'=>120,'descricao'=>'Escolha de 1 a 120 meses de calendário. Padrão de 60 meses em instalação nova. A atualização converte o prazo existente; reduzir o valor permite eliminar os dados vencidos.');
            foreach(array('schema_config','schema_entrada') as $s){if(isset($c[$name][$s])){$c[$name][$s]['properties'][$key]=array_replace($c[$name][$s]['properties'][$key]??array(),$range);}}
        }}
        foreach(self::CAMPOS as $name=>$items){$anterior=$c[$name]['recusa']??null;$c[$name]['recusa']=static function($v,$d,$nome='')use($items,$anterior){foreach($items as $key=>$label){if(is_array($v)&&array_key_exists($key,$v)&&(filter_var($v[$key],FILTER_VALIDATE_INT)===false||(int)$v[$key]<1||(int)$v[$key]>120)){return $label.': escolha de 1 a 120 meses.';}}return is_callable($anterior)?(string)call_user_func($anterior,$v,$d,$nome):'';};}
        $p=array();$fields=array();$props=array();foreach(self::TECNICAS as $key=>$label){$k='retencao_'.$key.'_meses';$p[$k]=$key==='operacoes'?6:60;$fields[$k]=array('tipo'=>'inteiro','rotulo'=>$label.' — meses de guarda','minimo'=>1,'maximo'=>120,'descricao'=>'De 1 a 120 meses. Padrão: '.$p[$k].' meses. Não muda o prazo de envio nem elimina operações em andamento.');$props[$k]=$range;}
        $c[self::OPTION]=array('rotulo'=>'Históricos e diagnósticos','descricao'=>'Prazos próprios de armazenamento. Consentimento, aquisições, deduplicação e limites de envio dos fornecedores mantêm suas regras.','operavel'=>true,'secao'=>F3Base_Options::SECAO_PRIVACIDADE,'campo'=>'grupo','padrao'=>$p,'subcampos'=>$fields,'schema_config'=>array('type'=>'object','additionalProperties'=>false,'properties'=>$props),'sanitiza'=>array(F3Base_Evolucao::class,'sanitizar'),'recusa'=>static function($v,$d){$e=F3Base_Evolucao::recusar($v,$d);if($e){return $e;}foreach($v as $x){if(filter_var($x,FILTER_VALIDATE_INT)===false||(int)$x<1||(int)$x>120){return 'Escolha de 1 a 120 meses.';}}return '';});
        return F3Base_Telefone::catalogo($c);
    }
    public static function meses(string $nome,string $campo='retencao_meses'): int {$v=F3Base_Options::ler($nome);return max(1,(int)(is_array($v)?($v[$campo]??60):$v));}
    public static function corte(string $nome,string $campo='retencao_meses',int $agora=0): int {return self::deslocar(-self::meses($nome,$campo),$agora);}
    public static function tecnico(string $key): int {return self::corte(self::OPTION,'retencao_'.$key.'_meses');}
    public static function dias(string $nome,string $campo='retencao_meses'): int {return (int)ceil((time()-self::corte($nome,$campo))/DAY_IN_SECONDS);}
    public static function somente_unidades(string $nome,$antes,$depois): bool {
        if(!self::$migrando||!isset(self::CAMPOS[$nome])||!is_array($antes)||!is_array($depois)||$antes===$depois||$depois!==self::converter($nome,$antes)){return false;}
        foreach(self::CAMPOS[$nome] as $key=>$unused){if(isset($depois[$key])&&(!is_int($depois[$key])||$depois[$key]<1||$depois[$key]>120)){return false;}}return true;
    }
    public static function migrar(): bool {
        self::$migrando=true;try{foreach(array_keys(self::CAMPOS) as $name){$f=F3Base_Options::fotografia_bruta($name);if($f['erro']){return false;}if(!$f['existe']){continue;}
            $r=F3Base_Options::complementar_padrao($name,F3Base_Options::declaracao($name)['padrao'],F3BASE_PLUGIN_VERSAO,static fn($v)=>self::converter($name,$v));if(empty($r['ok'])||empty($r['persisted'])){return false;}
        }
        return true;}finally{self::$migrando=false;}
    }
}
