<?php
/** Sinais de captura; conteúdo de iscas cifrado e restrito ao WordPress. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Formulario_Antispam {
    const ISCAS=array('website','ctodesenvolvimentofator3','comentario');
    public static function html(): string {return '<div class="f3base-isca" aria-hidden="true"><input name="ctodesenvolvimentofator3" tabindex="-1" autocomplete="off"></div><div class="f3base-isca" aria-hidden="true"><label>Website<input name="website" tabindex="-1" autocomplete="off"></label></div><div class="f3base-isca" aria-hidden="true"><label>Comentário<textarea name="comentario" tabindex="-1" autocomplete="off"></textarea></label></div>';}
    public static function iscas(array $e,array $campos,int $etapa=1): array {
        $meta=array();$values=array();foreach(self::ISCAS as $name){$v=$e[$name]??'';if(!is_string($v)){return array('ok'=>false,'codigo'=>'isca_invalida');}if(strlen($v)>20000){return array('ok'=>false,'codigo'=>'isca_excedida');}$v=wp_check_invalid_utf8($v);if(trim($v)===''){continue;}
            $same=array();foreach($campos as $field=>$value){if(is_scalar($value)&&trim((string)$value)!==''&&trim((string)$value)===trim($v)){$same[]=$field;}}
            $types=array();if(filter_var(trim($v),FILTER_VALIDATE_URL)){$types[]='url';}if($same){$types[]='igual_a_outro_campo';}if(!$types){$types[]='texto_livre';}
            $meta[$name]=array('tipos'=>$types,'campos_iguais'=>$same,'bytes'=>strlen($v),'etapa'=>$etapa);$values[$name]=$v;
        }
        $capture=!empty(F3Base_Options::ler(F3Base_Formulario_Tentativas::OPTION)['capturar_valores']);
        return array('ok'=>true,'suspeito'=>isset($meta['comentario'])||isset($meta['ctodesenvolvimentofator3']),'iscas'=>array('em'=>time(),'etapa'=>$etapa,'campos'=>$meta,'valores'=>$capture&&$values?F3Base_Contato_Comunicacao::cifrar($values):null,'captura_valores'=>$capture));
    }
    public static function contato_valido(array $d): bool {return trim((string)($d['nome']??''))!==''&&(is_email($d['email']??'')||F3Base_Pipedrive_Api::telefone((string)($d['telefone']??''))!=='');}
    public static function privado(array $lead): array {
        if(!current_user_can('f3base_ler_leads')){return array();}$out=array();
        foreach($lead['dados']['iscas_privadas']??array() as $row){if((int)($row['em']??0)<F3Base_Retencao_Prazos::corte(F3Base_Formulario_Tentativas::OPTION)){continue;}$values=F3Base_Contato_Comunicacao::abrir((string)($row['valores']??''))??array();unset($row['valores']);foreach($row['campos'] as $name=>&$field){if(array_key_exists($name,$values)){$field['valor']=$values[$name];}}unset($field);$out[]=$row;}return $out;
    }
    public static function projetar(array $lead): array {$lead['iscas']=self::privado($lead);unset($lead['dados']['iscas_privadas']);return $lead;}
    public static function limpar(): void {
        global $wpdb;$cut=F3Base_Retencao_Prazos::corte(F3Base_Formulario_Tentativas::OPTION);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT record_id,dados FROM %i WHERE JSON_CONTAINS_PATH(dados,'one','$.iscas_privadas') AND CAST(JSON_UNQUOTE(JSON_EXTRACT(dados,'$.iscas_privadas[0].em')) AS UNSIGNED)<%d LIMIT 100",F3Base_Leads_Repositorio::tabela(),$cut),ARRAY_A);
        foreach($rows??array() as $r){$d=json_decode($r['dados'],true);$d['iscas_privadas']=array_values(array_filter($d['iscas_privadas']??array(),static fn($x)=>(int)($x['em']??0)>=$cut));if(!$d['iscas_privadas']){unset($d['iscas_privadas']);}$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d)),array('record_id'=>$r['record_id'],'dados'=>$r['dados']));}
    }
}
