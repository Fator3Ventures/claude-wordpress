<?php
/** Qualidade comercial local, com mapa por site e outbox independente da aquisição. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/trait-f3base-qualidade-operacoes.php';
require_once __DIR__.'/trait-f3base-qualidade-interface.php';
require_once __DIR__.'/trait-f3base-qualidade-remota.php';
final class F3Base_Qualidade {
    use F3Base_Qualidade_Remota;
    use F3Base_Qualidade_Operacoes;
    use F3Base_Qualidade_Interface;
    const OPCAO='f3base_qualidade';
    const HOOK='f3base_qualidade_processar';
    public static function padrao(): array {return array('credencial'=>'compartilhada','ativo'=>false,'meta_ativo'=>false,'dataset'=>'','versao_api'=>'v24.0','precedencia'=>'mais_recente','etapas'=>array(),'regras'=>array(),'consentimentos_nativos'=>array(),'campo_meta_id'=>'');}
    public static function credencial(): string {return self::config()['credencial']==='propria'?'f3base_meta_crm_token':'f3base_meta_capi_token';}
    public static function config(): array {return array_replace(self::padrao(),(array)F3Base_Options::ler(self::OPCAO));}
    public static function catalogo(array $c): array {
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>array('credencial'=>array('type'=>'string','enum'=>array('compartilhada','propria')),'ativo'=>array('type'=>'boolean'),'meta_ativo'=>array('type'=>'boolean'),'dataset'=>array('type'=>'string','pattern'=>'^[0-9]{0,40}$'),'versao_api'=>array('type'=>'string','pattern'=>'^v[0-9]{2}\.0$'),'precedencia'=>array('type'=>'string','enum'=>array('mais_recente','manual_ate_retirar')),'etapas'=>array('type'=>'array','maxItems'=>100,'items'=>array('type'=>'object')),'regras'=>array('type'=>'array','maxItems'=>200,'items'=>array('type'=>'object')),'consentimentos_nativos'=>array('type'=>'object'),'campo_meta_id'=>array('type'=>'string')));
        $c[self::OPCAO]=array('rotulo'=>'Qualidade e retorno à Meta','descricao'=>'Mapa exclusivo deste site: etapas locais, funis Pipedrive e eventos Meta. Nenhum mapa comercial é aplicado automaticamente.','operavel'=>true,'campo'=>'grupo','padrao'=>self::padrao(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'schema_config'=>$schema,'schema_entrada'=>$schema,'recusa'=>array(__CLASS__,'validar'));
        foreach(array('f3base_qualidade_estado','f3base_qualidade_catalogo') as $n){$c[$n]=array('rotulo'=>$n,'operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));}return $c;
    }
    public static function validar($v): string {
        if(!is_array($v)||array_diff(array_keys($v),array_keys(self::padrao()))){return 'Configuração de qualidade inválida.';}
        $v=array_replace(self::padrao(),$v);
        if(!in_array($v['credencial'],array('compartilhada','propria'),true)||!is_bool($v['ativo'])||!is_bool($v['meta_ativo'])||!preg_match('/^[0-9]{0,40}$/D',(string)$v['dataset'])||!preg_match('/^v[0-9]{2}\.0$/D',(string)$v['versao_api'])||!in_array($v['precedencia'],array('mais_recente','manual_ate_retirar'),true)){return 'Confira ativação, dataset, versão da API e precedência.';}
        if(!is_array($v['etapas'])||count($v['etapas'])>100||!is_array($v['regras'])||count($v['regras'])>200||!is_array($v['consentimentos_nativos'])){return 'Informe listas de etapas e regras dentro dos limites.';}
        $ids=array();foreach($v['etapas'] as $e){if(!is_array($e)||array_diff(array_keys($e),array('id','nome','evento_meta'))||!preg_match('/^[a-z][a-z0-9_-]{0,59}$/D',(string)($e['id']??''))||!is_string($e['nome']??null)||trim($e['nome'])===''||mb_strlen($e['nome'])>100||!preg_match('/^[A-Za-z][A-Za-z0-9_]{0,59}$|^$/D',(string)($e['evento_meta']??''))||in_array($e['id'],$ids,true)){return 'Cada etapa precisa de código único, nome e evento Meta opcional, sem espaços.';}$ids[]=$e['id'];}
        $scopes=array();foreach($v['regras'] as $r){if(!is_array($r)||array_diff(array_keys($r),array('conta','pipeline','estado','formulario','campanha','etapa'))||!in_array($r['etapa']??null,$ids,true)||!preg_match('/^(lead_criado|lead_arquivado|ganho|perdido|stage:[1-9][0-9]*)$/D',(string)($r['estado']??''))){return 'Regra inválida: selecione estado e etapa cadastrada.';}foreach(array('conta','pipeline') as $k){if(!is_string($r[$k]??null)||!preg_match('/^[0-9]{1,40}$/D',$r[$k])&&!(($r[$k]??'')===''&&$k==='pipeline')){return 'Conta precisa ser explícita; funil pode ficar vazio para leads ainda sem negócio.';}}foreach(array('formulario','campanha') as $k){if(!is_string($r[$k]??'')||mb_strlen($r[$k]??'')>100){return 'Formulário ou campanha inválidos.';}}$scope=wp_json_encode(array_map(static fn($k)=>(string)($r[$k]??''),array('conta','pipeline','estado','formulario','campanha')));if(isset($scopes[$scope])){return 'Existem duas regras para o mesmo escopo.';}$scopes[$scope]=true;}
        foreach($v['regras'] as $i=>$a){foreach(array_slice($v['regras'],$i+1) as $b){if($a['conta']!==$b['conta']||$a['estado']!==$b['estado']){continue;}$score=static fn($r)=>(int)($r['pipeline']!=='')+2*(int)(($r['formulario']??'')!=='')+2*(int)(($r['campanha']??'')!=='');if($score($a)!==$score($b)){continue;}$overlap=true;foreach(array('pipeline','formulario','campanha') as $k){if(($a[$k]??'')!==''&&($b[$k]??'')!==''&&$a[$k]!==$b[$k]){$overlap=false;}}if($overlap){return 'Regras igualmente específicas se sobrepõem. Defina um escopo único por estado do CRM.';}}}
        if($v['ativo']&&$v['regras']){$cat=get_option('f3base_qualidade_catalogo',array());$account=(string)(get_option('f3base_pipedrive_estado',array())['conta_id']??'');if(($cat['conta']??'')!==self::conta()||$account===''){return 'Carregue os funis da conta Pipedrive antes de ativar as regras.';}$pipelines=array_map('strval',array_column($cat['funis']??array(),'id'));$funis=array_column($cat['funis']??array(),null,'id');$stages=array_column($cat['etapas']??array(),null,'id');foreach($v['regras'] as $rule){if(($funis[$rule['pipeline']]['active']??null)===false){return 'O funil escolhido está inativo no catálogo.';}if($rule['conta']!==$account||($rule['pipeline']!==''&&!in_array($rule['pipeline'],$pipelines,true))){return 'Uma regra usa conta ou funil diferente do catálogo carregado.';}if(str_starts_with($rule['estado'],'stage:')){$id=substr($rule['estado'],6);if(($stages[$id]['active']??null)===false){return 'A etapa escolhida está inativa no catálogo.';}if(!isset($stages[$id])||($rule['pipeline']!==''&&(string)$stages[$id]['pipeline_id']!==$rule['pipeline'])){return 'A etapa do CRM precisa pertencer ao funil escolhido.';}}}}
        foreach($v['consentimentos_nativos'] as $k=>$proof){if(!preg_match('/^meta:[0-9]+:[0-9]+$/D',(string)$k)||!is_array($proof)||($proof['publicidade']??null)!==true||empty($proof['referencia'])||!is_string($proof['referencia'])||strlen($proof['referencia'])>500||!is_int($proof['desde']??null)||$proof['desde']>time()){return 'Autorização nativa precisa de origem:conta:formulário, referência e data inicial.';}}
        if($v['campo_meta_id']!==''&&!preg_match('/^[a-f0-9]{40}$/D',(string)$v['campo_meta_id'])){return 'Selecione a chave do campo de texto para ID Meta.';}
        if($v['campo_meta_id']!==''&&$v['ativo']){$fields=get_option('f3base_pipedrive_estado',array())['catalogos']['campos']??array();$found=false;foreach($fields as $field){if(($field['field_code']??$field['key']??'')===$v['campo_meta_id']&&in_array($field['field_type']??'',array('text','varchar','varchar_auto'),true)){$found=true;}}if(!$found){return 'O campo ID Meta precisa ser um campo textual do catálogo da conta atual.';}}
        if($v['meta_ativo']&&(!$v['ativo']||$v['dataset']===''||!$ids)){return 'Para enviar à Meta, ative a qualidade, escolha um dataset e cadastre etapas.';}return '';
    }
    public static function tabela(string $tipo='eventos'): string {global $wpdb;return $wpdb->prefix.'f3base_qualidade_'.$tipo;}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();
        $sql=array('eventos'=>"id bigint unsigned NOT NULL AUTO_INCREMENT,\nchave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\netapa varchar(60) NOT NULL,\norigem varchar(20) NOT NULL,\nocorreu_em bigint unsigned NOT NULL,\nrecebido_em bigint unsigned NOT NULL,\nautor bigint unsigned NOT NULL DEFAULT 0,\nconfig_revisao char(64) NOT NULL,\ndados longtext NOT NULL,\nPRIMARY KEY  (id),\nUNIQUE KEY identidade (chave),\nKEY contato (record_id,ocorreu_em),\nKEY etapa (etapa,ocorreu_em)",
        'atual'=>"record_id char(32) NOT NULL,\nevento_id bigint unsigned NOT NULL,\netapa varchar(60) NOT NULL,\norigem varchar(20) NOT NULL,\nocorreu_em bigint unsigned NOT NULL,\nmanual_fixo tinyint NOT NULL DEFAULT 0,\nrevisao char(64) NOT NULL,\nPRIMARY KEY  (record_id),\nKEY etapa (etapa)",
        'fila'=>"chave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\netapa varchar(60) NOT NULL,\nevento_id bigint unsigned NOT NULL,\ndataset varchar(40) NOT NULL,\ncredencial_revisao char(64) NOT NULL,\nconfig_revisao char(64) NOT NULL,\npayload longtext NOT NULL,\nestado varchar(20) NOT NULL,\ncodigo varchar(80) NOT NULL DEFAULT '',\nproxima bigint unsigned NOT NULL,\ntentativas smallint unsigned NOT NULL DEFAULT 0,\nexpira bigint unsigned NOT NULL,\nhttp smallint NOT NULL DEFAULT 0,\natualizado_em bigint unsigned NOT NULL,\nPRIMARY KEY  (chave),\nKEY agenda (estado,proxima),\nKEY contato (record_id)",
        'recibos'=>"chave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\nconta varchar(40) NOT NULL,\nrecebido_em bigint unsigned NOT NULL,\npayload longtext NOT NULL,\nestado varchar(20) NOT NULL DEFAULT 'pendente',\ncodigo varchar(80) NOT NULL DEFAULT '',\nPRIMARY KEY  (chave),\nKEY fila (estado,recebido_em),\nKEY contato (record_id)");
        foreach($sql as $suffix=>$body){$t=self::tabela($suffix);dbDelta("CREATE TABLE {$t} (\n{$body}\n) ENGINE=InnoDB {$cc};");if($wpdb->last_error||$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t){return false;}}return true;
    }
    public static function iniciar(): void {F3Base_Qualidade_Catalogo::iniciar();F3Base_Captura_Contexto::iniciar();add_action(F3Base_Leads_Notificacoes::EVENTO,array(__CLASS__,'limpar_transitorios'));
        add_action(self::HOOK,static function(){F3Base_Recuperacao::executar(static fn()=>self::atualizar(array('interno'=>true)));});
        add_action('init',static function(){F3Base_Recuperacao::executar(static function(){if(!empty(self::config()['ativo'])&&!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}});},95);
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/pipedrive/qualidade',array('methods'=>'POST','permission_callback'=>array(__CLASS__,'autenticar'),'callback'=>array(__CLASS__,'receber'))));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('contatos-qualidade-ler','Etapas atuais, histórico e estado do retorno à Meta',array(__CLASS__,'ler'),array('record_id'=>array('type'=>'string'),'pagina'=>array('type'=>'integer','minimum'=>1),'etapa'=>array('type'=>'string')));
            F3Base_Servicos::ability('contato-qualidade-indicar','Indicar etapa comercial; simulação por padrão',array(__CLASS__,'indicar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'etapa'=>array('type'=>'string'),'ocorreu_em'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','maxLength'=>500),'revisao'=>array('type'=>'string'),'retirar_fixa'=>array('type'=>'boolean'),'cancelar_pendentes'=>array('type'=>'boolean'),'simular'=>array('type'=>'boolean')),array('record_id','etapa'),false);
            F3Base_Servicos::ability('contatos-qualidade-atualizar','Atualizar captação, CRM e retorno em lote limitado',array(__CLASS__,'atualizar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'simular'=>array('type'=>'boolean')),array(),false);
            F3Base_Servicos::ability('contatos-qualidade-indicar-lote','Indicar etapas em até cinquenta contatos, com revisões individuais',array(__CLASS__,'indicar_lote'),array('itens'=>array('type'=>'array','maxItems'=>50,'items'=>array('type'=>'object','properties'=>array('record_id'=>array('type'=>'string'),'revisao'=>array('type'=>'string')))),'etapa'=>array('type'=>'string'),'ocorreu_em'=>array('type'=>'integer'),'motivo'=>array('type'=>'string','maxLength'=>500),'simular'=>array('type'=>'boolean')),array('itens','etapa'),false);
            F3Base_Servicos::ability('qualidade-meta-reenviar','Reativar explicitamente um envio suspenso, preservando o destino',array(__CLASS__,'reenviar_meta'),array('chave'=>array('type'=>'string'),'revisao'=>array('type'=>'string'),'simular'=>array('type'=>'boolean')),array('chave'),false);
            F3Base_Servicos::ability('qualidade-crm-vincular','Associar negócio existente por decisão explícita do operador',array(__CLASS__,'vincular_negocio'),array('record_id'=>array('type'=>'string'),'negocio_id'=>array('type'=>'string'),'revisao'=>array('type'=>'string'),'confirmar'=>array('type'=>'boolean'),'motivo'=>array('type'=>'string','maxLength'=>500),'simular'=>array('type'=>'boolean')),array('record_id','negocio_id'),false);
            F3Base_Servicos::ability('meta-crm-verificar','Verificar leitura do dataset sem enviar conversão',array(__CLASS__,'verificar'),array('simular'=>array('type'=>'boolean')),array(),false);
        });
        add_action('admin_post_f3base_qualidade',array(__CLASS__,'post'));
    }
    public static function atual(string $id): array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',self::tabela('atual'),$id),ARRAY_A)?:array('revisao'=>'ausente');}
    public static function etapa(string $id): ?array {foreach(self::config()['etapas'] as $e){if($e['id']===$id){return $e;}}return null;}
    public static function resolver(array $lead,string $conta,string $pipeline,string $estado): array {
        $matches=array();$score=-1;$campaign=(string)($lead['dados']['atribuicao']['campanha_id']??$lead['dados']['atribuicao']['utm_id']??'');$form=(string)($lead['dados']['origem_nativa']['formulario_id']??$lead['formulario']??'');
        foreach(self::config()['regras'] as $r){if($r['conta']!==$conta||$r['estado']!==$estado||($r['pipeline']!==''&&$r['pipeline']!==$pipeline)||(($r['formulario']??'')!==''&&$r['formulario']!==$form)||(($r['campanha']??'')!==''&&$r['campanha']!==$campaign)){continue;}$n=(int)($r['pipeline']!=='')+(int)(($r['formulario']??'')!=='')*2+(int)(($r['campanha']??'')!=='')*2;if($n>$score){$matches=array();$score=$n;}if($n===$score){$matches[]=$r;}}
        return count($matches)===1?array('ok'=>true,'regra'=>$matches[0]):array('ok'=>false,'codigo'=>$matches?'mapa_ambiguo':'etapa_nao_mapeada');
    }
    public static function indicar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $id=(string)($e['record_id']??'');$lead=F3Base_Leads_Repositorio::obter($id);$stage=self::etapa((string)($e['etapa']??''));$at=(int)($e['ocorreu_em']??time());$old=self::atual($id);
        if(!$lead||!$stage||$at<1||$at>time()){return array('ok'=>false,'codigo'=>'contato_etapa_ou_horario_invalido');}
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>$old['revisao'],'etapa'=>$stage,'ocorreu_em'=>$at,'meta'=>self::elegibilidade($lead,$stage,$at),'enviados_nao_sao_desfeitos'=>true);}
        if(($e['revisao']??'')!==$old['revisao']){return array('ok'=>false,'codigo'=>'conflito','revisao'=>$old['revisao']);}
        $sendLock=null;if(!empty($e['cancelar_pendentes'])){$sendLock=F3Base_Trava::adquirir('qualidade-envio-'.$id,30);if(!$sendLock){return array('ok'=>false,'codigo'=>'envio_ocupado');}}try{return self::registrar($lead,$stage['id'],'manual',$at,hash('sha256',$id.'|'.$old['revisao'].'|'.$stage['id'].'|'.$at),array('motivo'=>sanitize_textarea_field($e['motivo']??''),'autor'=>get_current_user_id(),'retirar_fixa'=>!empty($e['retirar_fixa']),'cancelar_pendentes'=>!empty($e['cancelar_pendentes'])), $old['revisao']);}finally{if($sendLock){F3Base_Trava::liberar($sendLock);}}
    }
    public static function elegibilidade(array $lead,array $stage,int $at): array {
        $cfg=self::config();$no=static fn($s)=>array('ok'=>false,'codigo'=>$s);
        if(!$cfg['meta_ativo']||!$cfg['ativo']){return $no('meta_desligada');}if(empty($stage['evento_meta'])){return $no('etapa_somente_local');}
        if(!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])||in_array($lead['captura']??'',array('eliminando','eliminado'),true)){return $no('contato_eliminado');}
        if(!empty($lead['dados']['contexto_teste'])||($lead['classe_trafego']??'')==='teste'){return $no('contato_de_teste');}
        if($at>time()||$at<time()-604800||$at<(strtotime($lead['dados']['origem_nativa']['nativo_em']??$lead['criado_em'].' UTC')?:0)){return $no('evento_fora_da_janela');}
        $native=$lead['dados']['origem_nativa']??array();$user=array();if(!F3Base_Publicidade::resolver($lead['dados'])['permitida']){return $no('publicidade_nao_permitida_ou_revogada');}
        if(($native['origem']??'')==='meta'){
            $key='meta:'.($native['conta_id']??'').':'.($native['formulario_id']??'');$proof=$cfg['consentimentos_nativos'][$key]??array();
            // Evidência por formulário é complementar; a política da instalação e a negativa do contato decidem.
            if(preg_match('/^[0-9]{1,40}$/D',(string)($native['lead_id']??''))){$user['lead_id']=(string)$native['lead_id'];}
        }else{
            // Medição não é requisito para retorno publicitário.
            foreach(array('fbc','fbp') as $k){$v=$lead['dados'][$k]??$lead['dados']['atribuicao'][$k]??'';if(is_string($v)&&preg_match('/^fb\.[0-9]{1,2}\.[0-9]{13}\.[A-Za-z0-9_-]{1,200}$/D',$v)){$user[$k]=$v;}}
        }
        $email=strtolower(trim($lead['email']??''));if(is_email($email)){$user['em']=array(hash('sha256',$email));}$phone=F3Base_Pipedrive_Api::telefone((string)($lead['dados']['telefone']??''));if($phone){$user['ph']=array(hash('sha256',preg_replace('/\D/','',$phone)));}
        if(!$user){return $no('sem_identificadores_elegiveis');}
        if($stage['evento_meta']==='Lead'&&empty($native)){return $no('aquisicao_web_ja_tratada');}
        return array('ok'=>true,'codigo'=>'elegivel','user_data'=>$user);
    }
    public static function registrar(array $lead,string $stage,string $source,int $at,string $key,array $data=array(),string $expected=''): array {
        global $wpdb;$id=$lead['record_id'];$lock=F3Base_Trava::adquirir('qualidade-'.$id,30);if(!$lock){return array('ok'=>false,'codigo'=>'contato_ocupado');}
        try{
            $lead=F3Base_Leads_Repositorio::obter($id);if(!$lead||!empty($lead['eliminacao_pendente'])||in_array($lead['captura']??'',array('eliminado','eliminando'),true)){return array('ok'=>false,'codigo'=>'contato_indisponivel');}$old=self::atual($id);if($expected!==''&&$old['revisao']!==$expected){return array('ok'=>false,'codigo'=>'conflito');}$cfg=self::config();$def=self::etapa($stage);if(!$def){return array('ok'=>false,'codigo'=>'etapa_ausente');}
            $exists=$wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE chave=%s',self::tabela(),$key));if($exists){return array('ok'=>true,'codigo'=>'evento_ja_registrado','evento_id'=>(int)$exists);}
            $wins=empty($old['evento_id'])||((empty($old['manual_fixo'])||$source==='manual')&&($at>(int)$old['ocorreu_em']||($at===(int)$old['ocorreu_em']&&($source==='manual'||$old['origem']!=='manual'))));
            $rev=F3Base_Options::revisao(self::OPCAO);$elig=self::elegibilidade($lead,$def,$at);$safe=$data;unset($safe['user_data']);$safe['anterior']=array_intersect_key($old,array_flip(array('etapa','origem','ocorreu_em','revisao')));$safe['envio_codigo']=$wins?$elig['codigo']:'historico_fora_de_ordem';
            if($wpdb->query('START TRANSACTION')===false){return array('ok'=>false,'codigo'=>'banco_indisponivel');}
            if($wpdb->insert(self::tabela(),array('chave'=>$key,'record_id'=>$id,'etapa'=>$stage,'origem'=>$source,'ocorreu_em'=>$at,'recebido_em'=>time(),'autor'=>(int)($data['autor']??0),'config_revisao'=>$rev,'dados'=>F3Base_Capi_Fila::cifrar_payload($safe)))===false){throw new RuntimeException('historico_nao_persistido');}$event=(int)$wpdb->insert_id;
            if($wins){$current=array('record_id'=>$id,'evento_id'=>$event,'etapa'=>$stage,'origem'=>$source,'ocorreu_em'=>$at,'manual_fixo'=>$source==='manual'&&$cfg['precedencia']==='manual_ate_retirar'&&empty($data['retirar_fixa'])?1:0,'revisao'=>hash('sha256',$key.'|'.$event));if($wpdb->replace(self::tabela('atual'),$current)===false){throw new RuntimeException('estado_nao_persistido');}}
            if($wins&&!empty($data['cancelar_pendentes'])){if($wpdb->query($wpdb->prepare("UPDATE %i SET estado='cancelado',codigo='correcao_manual',payload='',atualizado_em=%d WHERE record_id=%s AND etapa<>%s AND tentativas=0 AND estado IN ('pendente','suspenso')",self::tabela('fila'),time(),$id,$stage))===false){throw new RuntimeException('cancelamento_nao_persistido');}}
            if($wins&&!empty($elig['ok'])){
                $queueKey=hash('sha256',get_current_blog_id().'|'.$id.'|'.$cfg['dataset'].'|'.$stage);
                $payload=array('event_name'=>$def['evento_meta'],'event_time'=>$at,'event_id'=>'f3q-'.$queueKey,'action_source'=>'system_generated','user_data'=>$elig['user_data'],'custom_data'=>array('event_source'=>'crm','lead_event_source'=>$source==='manual'?'F3Base':'Pipedrive'));
                $row=array('chave'=>$queueKey,'record_id'=>$id,'etapa'=>$stage,'evento_id'=>$event,'dataset'=>$cfg['dataset'],'credencial_revisao'=>F3Base_Options::revisao(self::credencial()),'config_revisao'=>$rev,'payload'=>F3Base_Capi_Fila::cifrar_payload(array('evento'=>$payload,'versao_api'=>$cfg['versao_api'])),'estado'=>'pendente','codigo'=>'','proxima'=>time(),'expira'=>$at+604800,'atualizado_em'=>time());
                // The unique key is semantic: revisiting a stage never creates another conversion.
                $found=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE chave=%s',self::tabela('fila'),$queueKey));if(!$found&&$wpdb->insert(self::tabela('fila'),$row)===false){throw new RuntimeException('fila_nao_persistida');}
            }
            if($wpdb->query('COMMIT')===false){throw new RuntimeException('commit_nao_confirmado');}
            if(!empty($cfg['ativo'])){F3Base_Fila::agendar(self::HOOK,time()+5);}
            return array('ok'=>true,'persisted'=>true,'codigo'=>$wins?'etapa_atualizada':'historico_registrado_sem_regressao','evento_id'=>$event,'revisao'=>self::atual($id)['revisao'],'meta_codigo'=>$safe['envio_codigo']);
        }catch(Throwable $e){$wpdb->query('ROLLBACK');return array('ok'=>false,'codigo'=>sanitize_key($e->getMessage()));}finally{F3Base_Trava::liberar($lock);}
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;$page=max(1,(int)($e['pagina']??1));$where='1=1';if(!empty($e['record_id'])){$where.=$wpdb->prepare(' AND record_id=%s',$e['record_id']);}if(!empty($e['etapa'])){$where.=$wpdb->prepare(' AND etapa=%s',$e['etapa']);}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$where} ORDER BY ocorreu_em DESC,id DESC LIMIT 51 OFFSET %d",self::tabela(),($page-1)*50),ARRAY_A);$more=count($rows)>50;foreach($rows as &$r){$r['dados']=F3Base_Capi_Fila::abrir_payload($r['dados']);}unset($r);
        $queue=!empty($e['record_id'])?$wpdb->get_results($wpdb->prepare('SELECT chave,etapa,dataset,estado,codigo,proxima,tentativas,http FROM %i WHERE record_id=%s',self::tabela('fila'),$e['record_id']),ARRAY_A):array();
        return array('ok'=>!$wpdb->last_error,'atual'=>!empty($e['record_id'])?self::atual($e['record_id']):null,'historico'=>array_slice($rows,0,50),'envios'=>$queue,'proxima_pagina'=>$more?$page+1:null,'operacao'=>get_option('f3base_qualidade_estado',array()));
    }
    public static function relatorio(array $leads): array {
        if(!$leads){return array();}global $wpdb;$ids=array_column($leads,'record_id');$in=implode(',',array_fill(0,count($ids),'%s'));$historico=array();$fila=array();$atual=array();
        foreach($wpdb->get_results($wpdb->prepare('SELECT record_id,etapa,COUNT(*) ocorrencias FROM %i WHERE record_id IN ('.$in.') GROUP BY record_id,etapa',array_merge(array(self::tabela()),$ids)),ARRAY_A)?:array() as $r){$historico[$r['record_id']][$r['etapa']]=(int)$r['ocorrencias'];}
        foreach($wpdb->get_results($wpdb->prepare('SELECT record_id,etapa,estado,COUNT(*) quantidade FROM %i WHERE record_id IN ('.$in.') GROUP BY record_id,etapa,estado',array_merge(array(self::tabela('fila')),$ids)),ARRAY_A)?:array() as $r){$fila[$r['record_id']][$r['etapa']][$r['estado']]=(int)$r['quantidade'];}
        foreach($wpdb->get_results($wpdb->prepare('SELECT record_id,etapa FROM %i WHERE record_id IN ('.$in.')',array_merge(array(self::tabela('atual')),$ids)),ARRAY_A)?:array() as $r){$atual[$r['record_id']]=$r['etapa'];}
        $rows=array();foreach($leads as $lead){$id=$lead['record_id'];$d=is_string($lead['dados'])?json_decode($lead['dados'],true):$lead['dados'];$a=F3Base_Atribuicao::normalizar($d['atribuicao']??array());$stages=array_keys($historico[$id]??array('nao_indicada'=>0));foreach($stages as $stage){$intent=($lead['metodo']??'')==='conteudo'?'material':'contato';$key=wp_json_encode(array($intent,$stage,$a['plataforma'],$a['conta_id'],$a['campanha_id'],$a['utm_campaign']));if(!isset($rows[$key])){$rows[$key]=array('intencao'=>$intent,'etapa'=>$stage,'etapa_nome'=>self::etapa($stage)['nome']??'Não indicada','plataforma'=>$a['plataforma'],'conta_id'=>$a['conta_id'],'campanha_id'=>$a['campanha_id'],'campanha'=>$a['utm_campaign'],'contatos_distintos'=>0,'contatos_atualmente'=>0,'ocorrencias'=>0,'meta_aceitos'=>0,'meta_pendentes'=>0,'meta_bloqueados_ou_revisao'=>0,'sem_envio_meta'=>0);}$r=&$rows[$key];$r['contatos_distintos']++;$r['contatos_atualmente']+=(($atual[$id]??'nao_indicada')===$stage?1:0);$r['ocorrencias']+=$historico[$id][$stage]??0;$states=$fila[$id][$stage]??array();$r['meta_aceitos']+=$states['entregue']??0;$r['meta_pendentes']+=($states['pendente']??0)+($states['enviando']??0)+($states['incerto']??0);$r['meta_bloqueados_ou_revisao']+=($states['suspenso']??0)+($states['falhou']??0)+($states['revisao']??0)+($states['cancelado']??0);$r['sem_envio_meta']+=!$states?1:0;unset($r);}}
        return array_values($rows);
    }
    public static function resumo(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT estado,codigo,COUNT(*) quantidade FROM %i GROUP BY estado,codigo',self::tabela('fila')),ARRAY_A);
        return array('ativo'=>self::config()['ativo'],'meta_ativo'=>self::config()['meta_ativo'],'credencial'=>F3Base_Segredos::status(self::credencial()),'dataset'=>self::config()['dataset'],'fila'=>$rows?:array(),'operacao'=>get_option('f3base_qualidade_estado',array()),'proxima'=>wp_next_scheduled(self::HOOK)?:null,'mapa_padrao'=>'vazio; configuração própria de cada site','cobertura'=>'Webhook preserva mudanças recebidas; consulta periódica observa estado atual e não comprova etapas intermediárias.');
    }
    public static function limpar_transitorios(): void {
        global $wpdb;$corte=time()-7*DAY_IN_SECONDS;
        // A fila de transporte e os recibos têm sete dias; o histórico comercial continua junto ao contato.
        $wpdb->query($wpdb->prepare("DELETE FROM %i WHERE expira<%d",self::tabela('fila'),time()));
        $wpdb->query($wpdb->prepare("DELETE FROM %i WHERE recebido_em<%d",self::tabela('recibos'),$corte));
    }
    public static function cancelar(string $id,bool $eliminar=false): bool {global $wpdb;$lock=F3Base_Trava::adquirir('qualidade-envio-'.$id,30);if(!$lock){return false;}$recordLock=F3Base_Trava::adquirir('qualidade-'.$id,30);if(!$recordLock){F3Base_Trava::liberar($lock);return false;}try{if($eliminar){foreach(array('fila','recibos','atual','eventos') as $t){if($wpdb->delete(self::tabela($t),array('record_id'=>$id))===false){return false;}}return true;}return $wpdb->query($wpdb->prepare("UPDATE %i SET estado='cancelado',codigo='titular',payload='' WHERE record_id=%s AND estado<>'entregue'",self::tabela('fila'),$id))!==false;}finally{F3Base_Trava::liberar($recordLock);F3Base_Trava::liberar($lock);}}
}
