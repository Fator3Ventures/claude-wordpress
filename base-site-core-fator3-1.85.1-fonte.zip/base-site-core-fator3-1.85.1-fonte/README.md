# Fonte do Fator3 Site Core 1.85.1

Árvore instalável em work/plugin/base-site-core-fator3. Notas e guias estão em docs/ nessa árvore. A base 1.85.0 está em history/1.85.0-runtime. Veja PLANO-1.85.1.md e RELATORIO-PRE-FECHAMENTO.md. Evidência da rodada em evidence/1851; arquivos de rodadas anteriores permanecem identificados.

Reconstrução: build/assets-1851.py (Terser fixado no build/node), tests/verificar-entrega.py, build/reproduzir-instalador.py e build/conferir-instalador.py. Para testar em WordPress descartável, execute tests/run-1851.py com F3BASE_PHASE=fresh ou upgrade. O banco e o diretório de laboratório precisam ser exclusivos.

Pedidos 400 e 401 em tests/400-401.php. Evidências em evidence/1851.
