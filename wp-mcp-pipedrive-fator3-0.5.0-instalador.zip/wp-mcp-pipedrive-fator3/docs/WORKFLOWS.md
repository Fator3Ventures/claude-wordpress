# Operações e regras — 0.5.0

Pedidos MCP Pipedrive 4–9, 28/10/2026. Todas as rotas exigem administrador, via MCP ou REST `f3-pipedrive/v1`. Há 19 rotas preservadas da 0.4.0; a 0.5.0 amplia os parâmetros de regras. Consulte `schemas` para os tipos completos. Sem cron, envio de WhatsApp, token ou transporte HTTP próprio.

## Configuração e simulação

`pipedrive/configuracao-ler {}` retorna `regras`, `revisao` e `origem`. A ausência de option não grava defaults. A cadência começa desabilitada; horários, dias, textos, tipos e IDs reais não foram presumidos. A lista inicial de arquivamento é exatamente a do pedido 6. A lista de perda começa vazia porque a referência comercial não veio nos anexos.

Preencha o objeto inteiro `regras` segundo o schema e chame `configuracao-simular` com `revisao_esperada` e, opcionalmente, `agora` RFC3339 UTC. A simulação lê a conta no orçamento operacao, não modifica a conta nem salva regras. Coleta parcial não gera prévia aplicável. Retorna fila, regras candidatas, `previa_id` por 15 minutos e `confirmacao_exigida`. Revise os dados; após ordem do dono use `operacao-aplicar` com esse ID e a frase literal. Alterar motivos também exige esse fluxo. Revisão divergente recusa a gravação; repetição de uma aplicação concluída devolve recibo. A configuração fica na option `f3_pipedrive_operation_rules`, JSON não autoload. Não a edite por SQL/rotas genéricas: isso perde a guarda de simulação.

`fuso` é IANA. `dias` usa ISO 1=segunda a 7=domingo. `janela` começa e termina no mesmo dia. Cada `periodo` possui código e hora dentro dela. O próximo vencimento é o primeiro horário de período igual ou posterior à base mais o prazo, respeitando dias úteis configurados. `toques` é uma sequência, cada um com código, prazo em minutos, base `entrada` (add_time do lead) ou `ultimo_registro`, texto_id e etiqueta_id opcional. Não há regra comercial de 30 minutos, 28 horas ou dias da semana fixa no PHP.

`textos` contém mensagens aprovadas. A interpolação só ocorre com o mapa explícito `variaveis` da 0.5.0 descrito abaixo. `exclusoes.etiquetas` contém UUIDs; `exclusoes.campos` aceita campo, valores exatos e código da regra, servindo para unidade, ponto de conversão, canal e outros campos mapeados. Valores numéricos são comparados pela representação textual. A aplicação apenas salva parâmetros; não cria etiquetas, atividades ou campos.

`auditoria.campos_origem` deve conter as quatro chaves reais; `separador_titulo` representa a separação esperada entre Empresa e Unidade; `etapas` contém ID, alerta_minutos e primeira; `tipos_reuniao` contém os tipos da conta. A auditoria sinaliza configuração ausente ou etapa não mapeada como cobertura incompleta. Não presume o significado de nomes comerciais de campos.

## Fila e registros de WhatsApp

`cadencia-fila` aceita `agora`, max_chamadas (1–120, padrão100), tempo_maximo_segundos (1–120, padrão45). Retorna IDs, próximo toque, devido_em_utc, período, texto_aprovado e motivo. Fora da janela, exclusões, atividade concluída, duplicidade ou histórico desconhecido impedem envio devido. Texto aprovado vem exclusivamente da option. O objeto não exporta campos brutos; o texto preenchido pode conter dados pessoais dos campos explicitamente mapeados. Não registrar textos da fila em logs, relatórios ou evidências públicas.

Progresso é reconhecido por marcadores HMAC escritos pelo plugin na nota da atividade ou etiquetas explicitamente configuradas. Sem `adocao` habilitada, atividade antiga com nota e sem marcador/etiqueta reconhecido resulta `historico_sem_marcador`. A adoção configurada abaixo permite reconhecer uma linha datada. Etiqueta de toque indica toque já concluído; ela sozinha não fornece o instante para `ultimo_registro`. Preservar salts mantém os marcadores verificáveis. Trocar códigos de toques pode exigir mapeamento explícito do histórico.

`whatsapp-registrar` recebe `lead_id` UUID, `mensagem`, `toque` e `chave_idempotencia` (8–128 caracteres). Use somente depois de confirmar o envio por seu canal: este plugin registra, não envia. O toque deve ser o próximo reconhecido. Consulta todas as atividades do lead, considera o tipo exato `tipo_whatsapp`, recusa mais de uma e não cria outra se uma já existe. Acrescenta uma linha escapada à nota e programa a atividade em UTC conforme o prazo do toque seguinte, incluindo minutos úteis ou primeiro período do próximo dia útil. O corpo v2 usa `due_time` HH:MM; o recibo usa RFC3339. Um toque com acao=encerrar exige lead-encerrar. Depois do último toque, programa o próximo período para revisão; a fila retorna cadencia_concluida e não inventa mensagem adicional. Atividade já concluída não é reaberta automaticamente.

A mesma chave na mesma conta retorna o recibo, sem nova escrita. Outro corpo com a chave é conflito. Os recibos de mensagem não têm expurgo automático, independentemente dos 180 dias dos recibos comuns. A retenção do diário continua separada. Chaves são representadas por HMAC local; conteúdo de mensagem nunca entra no diário. Recibos pertencem ao administrador original e à conta/revisão Core; uma mudança de contexto bloqueia reuso, exigindo reconciliação. A unicidade é serializada entre operações cooperantes deste plugin; agentes escrevendo diretamente no fornecedor ou por outros plugins não compartilham essa trava. Reconsulta após criação detecta duplicidade concorrente, sem apagar atividade alheia.

## Prévias de encerramento, perda e edição arquivada

`lead-encerrar {lead_id,mensagem,archive_reason}` prepara a operação. O motivo precisa estar em archive_reasons; inválido recusa antes de qualquer escrita. `operacao-aplicar {previa_id}` revalida conta, revisão e estado. Uma chamada de atividade acrescenta a linha final e marca done; outra arquiva o lead. Atividade ausente é criada única, concluída, antes de arquivar. Não é transação distribuída: falha posterior pode deixar a atividade concluída com lead aberto, explicitamente no recibo. Não se envia mensagem externa.

`negocio-perder {negocio_id,lost_reason}` prepara perda somente de negócio aberto não arquivado; motivo precisa estar em lost_reasons. Aplicar usa PATCH v2 com status=lost. A rota de prévia genérica também passa a validar archive_reason e exigir motivo ao arquivar lead, fechando o desvio da lista por essa rota.

`lead-arquivado-editar {lead_id,campos}` prepara desarquivar, editar e rearquivar. `campos` usa a allowlist anterior do lead, exceto is_archived/archive_reason, preservados pelo fluxo. Exige motivo original e archive_time disponível. Após edição recusada, tenta rearquivar com o motivo original, inclusive legado; o recibo registra sucesso/falha e data original/nova. Falha/timeout de desarquivamento não autoriza adivinhar o estado nem repetir. Falha da compensação mantém bloqueio persistente. Datas não são restauradas artificialmente.

## Leitura e completude

`auditoria` retorna entidade, id e regra: quatro origens ausentes, sem próxima atividade com data, formato de título, organização com nome igual ao contato ligado, negócio aberto com stage_change_time além do limite (usa add_time se stage_change_time é nulo) e reunião vencida na primeira etapa configurada. Nomes são comparados somente em memória; não são retornados. Reunião passada conta mesmo se concluída quando o negócio continua na primeira etapa.

`contar-por-campo {entidade,campo}` aceita leads, negocios, pessoas, organizacoes e chave do catálogo correspondente. Leads/negócios juntam coleções ativa e arquivada; contatos não possuem coleção de arquivo nesta API, e excluídos não são incluídos. Opções retornam `opcao:ID`, nunca labels; múltipla escolha conta cada opção uma vez por registro (soma pode exceder total). Vazio é grupo explícito. Demais tipos viram categoria HMAC estável por site, conta, entidade e campo; não é hash público reversível por dicionário.

Fila até200 itens, auditoria até1000 ocorrências, contagem até200 grupos e coleta até12000 registros. Estouro, paginação sem fim declarado, cursor repetido, duplicidade, orçamento ou erro geram coleta_completa=false e motivos; não há total completo inventado. A fila parcial suprime texto e marca todos os itens sem envio devido. Resultados refletem visibilidade da credencial e não são snapshot transacional da conta. Custo declara chamadas, estimativa do contrato Core (GET20/escrita10) e, nas leituras, delta observado, que pode incluir consumo concorrente. Unidades locais não são tokens oficiais de todos os endpoints.

## Interrupção e reconciliação

Recibo tem etapas, HTTP/código, entrada_digest HMAC, dados mínimos e reconciliacao_necessaria. Cada resposta de etapa é persistida no diário antes da seguinte. Uma queda pode deixar state=running e checkpoint; nunca reexecute cegamente. Trava persistente `f3_pd_pending_<hash>` impede novos fluxos no registro, inclusive escrita genérica em lead, até revisão de manutenção. Recibos prontos não repetem etapas, mesmo após falha.

Para resolver: consulte registro-ler e o fornecedor por IDs, confronte cada efeito e preserve o recibo/checkpoint. Com ordem explícita do dono e comprovação do estado final, manutenção pode retirar somente a trava correspondente ao recibo, mantendo a operação e sua chave consumida. Não apague tabelas, recibos ou salts; não reutilize a chave para reenviar uma mensagem. Esta versão não oferece liberação automática nem reconciliação automática de efeitos remotos. Uma prévia ainda pronta pode ser refeita se expirada/alterada; estado running exige conferência.

## Referências técnicas

Referências da base, com Activities e Deals consultadas novamente em 30/10/2026: https://developers.pipedrive.com/docs/api/v1/Activities ; https://developers.pipedrive.com/docs/api/v1/Leads ; https://developers.pipedrive.com/docs/api/v1/Deals ; https://developers.pipedrive.com/docs/api/v1/Persons ; https://pipedrive.readme.io/docs/pipedrive-api-v2-migration-guide . O motivo do contorno para arquivados está em https://developers.pipedrive.com/changelog/post/breaking-change-archived-deals-and-leads-will-not-be-returned-in-existing-endpoints-and-will-not-be-editable . Consulta documental não é homologação com dados reais.

## Regras adicionais da 0.5.0 — Pedido 10

Os campos novos são opcionais. Configuração 0.4.0 é lida com os mesmos bytes/revisão, sem migração. Defaults comerciais continuam desabilitados. Para habilitar recursos, envie o objeto inteiro pela simulação e aplique com a frase; não altere valores reais por inferência. Os exemplos são sintéticos, sem chaves reais da conta.

| Campo | Efeito e ausência |
| --- | --- |
| `toques[].prazo` | `periodo` preserva minutos corridos arredondados ao período; `minutos_uteis` soma apenas tempo na janela/dias/feriados sem arredondar; `primeiro_periodo_dia_util_seguinte` usa a primeira hora configurada do próximo dia útil, com atraso_minutos=0. Ausente: periodo. |
| `toques[].acao` | mensagem ou encerrar; ausente: mensagem. A fila nunca envia/encerra automaticamente. |
| `feriados` | Datas YYYY-MM-DD exatas, até366; ausência: nenhum feriado. Manter calendário de anos futuros pela simulação. |
| `toques[].variantes` | Lista ordenada de `{condicao,texto_id}`. Primeira condição correspondente vence; sem correspondência usa texto_id do toque. |
| `variaveis` | Lista `{codigo,campo,parte}`; `parte` inteiro ou primeiro_nome. Substitui `{codigo}` em uma única passagem, sem executar conteúdo. Campo raiz/custom_fields do lead, valor escalar ou lista escalar. Falta/vazio/objeto não suportado bloqueia texto e devido. Máximo final16KiB. Ausente preserva textos literais antigos. |
| `canais` | Lista `{codigo,condicao,permitir_encerramento,permitir_arquivamento}`. Restrições de todas as regras correspondentes acumulam. Ausente: sem restrição adicional. |
| `nota` | `{prefixo,formato,autor}`. Formatos permitidos: `d/m H\hi`, `d/m/Y H\hi`, `Y-m-d\TH:i:sP` (escape JSON como abaixo). Ausente: [IA], dd/mm hhhmm, nós. Fuso é o geral das regras. |
| `espera_entrega` | habilitada, condicao, campo_desde, rever_minutos, encerrar_minutos. Prazos corridos, revisão antes do limite; exemplo30/1680. Estado e instante vêm do campo do lead; campo_desde vazio usa último registro reconhecido. Ausente/desligada: sem espera adicional. |
| `adocao` | habilitada, prefixo, autor, max_idade_dias e toques_por_texto. Desligada por ausência. Requer correspondência da linha e do toque conforme abaixo. |
| `auditoria.nome_pessoa` | habilitada, palavras_empresa, ignorar_palavras, minimo_tokens(2–10). Ausente: só a comparação legada de nomes iguais. |

Uma `condicao` é `{campo,operador,valores}`; operador igual, presente ou ausente. Igual compara escalar/elementos por representação textual, incluindo IDs de opções; presente/ausente usa null, string vazia e lista vazia. Nunca consulta campos por rótulo. Textos/variáveis/condições são conteúdo, não instruções executáveis.

Exemplos de propriedades a mesclar no objeto completo retornado por configuracao-ler:

```json
{
  "feriados": ["2026-11-02"],
  "nota": {"prefixo":"[IA]","formato":"d/m H\\hi","autor":"nós"},
  "variaveis": [{"codigo":"nome","campo":"campo_nome","parte":"primeiro_nome"},{"codigo":"resumo","campo":"campo_respostas","parte":"inteiro"}],
  "canais": [{"codigo":"linkedin","condicao":{"campo":"campo_canal","operador":"igual","valores":["linkedin"]},"permitir_encerramento":false,"permitir_arquivamento":false}],
  "espera_entrega": {"habilitada":true,"condicao":{"campo":"campo_entrega","operador":"igual","valores":["sem_entrega"]},"campo_desde":"campo_inicio_espera","rever_minutos":30,"encerrar_minutos":1680},
  "adocao": {"habilitada":true,"prefixo":"[IA]","autor":"nós","max_idade_dias":366,"toques_por_texto":[{"trecho":"trecho exclusivo da primeira mensagem aprovada","toque":"primeiro"}]}
}
```

Para primeira mensagem até1hora útil: toque com base=entrada, atraso_minutos=60 e prazo=minutos_uteis. Lead às10h vence11h mesmo com períodos09h30/14h30. Entrada sexta17h30 com feriado segunda vence terça09h30. Fora da janela ou em feriado nenhum item fica devido; o vencimento original continua informado. O primeiro período útil seguinte é calculado a partir da data local da base, sem substituir por360minutos. Limite de busca do calendário: dez anos, erro explícito por item se insuficiente.

Variantes permitem três textos da primeira mensagem, por exemplo respostas presentes, origem de um canal e texto-base. Mapeie os campos reais; nomes e resumo são interpolados somente quando disponíveis. A configuração recusa texto com variável não mapeada quando `variaveis` está presente. A simulação devolve os textos preenchidos e pode conter dados pessoais; acesso administrativo permanece obrigatório.

Espera de entrega: antes do prazo de revisão, estado aguardando_verificacao; no prazo, acao=verificar_entrega e estado verificar_sem_entrega; no limite, acao=encerrar e estado limite_sem_entrega. `rever_em_utc`/`limite_em_utc` são explícitos. Relógios são corridos; a indicação de ação devida obedece ao calendário. O plugin não conhece recibos do WhatsApp: o operador atualiza os campos pela fonte autorizada. Não inferir entrega do conteúdo da nota. Canal protegido bloqueia o encerramento na fila, prévia/aplicação e arquivamento genérico; nenhum fluxo automático ignora essa política.

Adoção: somente linhas de saída `prefixo dd/mm[ /aaaa] hhhmm, autor: conteúdo`, sem o espaço antes de /aaaa. Aceita HTML de parágrafo/div/br, preservando a nota original. Sem ano escolhe o ano atual, ou anterior quando a data estaria no futuro; respeita add_time e max_idade_dias. Escolhe o último registro válido de saída. O trecho configurado identifica um único toque; se não houver trecho, uma etiqueta de toque já configurada pode fornecer o índice. Texto ambíguo, data inválida/futura/antiga, autor divergente ou toque desconhecido não avançam a cadência. Marcador autenticado tem preferência; a leitura de adoção não grava marcador nem altera a nota. Novo registro pelo plugin acrescenta o marcador e conserva o histórico. O mapa não deve usar trechos comuns a vários toques.

Auditoria: se stage_change_time é nulo/ausente, usa add_time como entrada na etapa; valores não nulos inválidos não são substituídos silenciosamente. Fonte/data dos alertas em `datas_etapas`. Item sem data fica em `itens_nao_avaliados`, com `avaliacao_completa=false`; coleta dos demais continua e `coleta_completa` pode ser true. A regra de organização considera todas as pessoas visíveis ligadas por org_id e o vínculo explícito do lead, compara nome/sobrenome e mínimo de tokens sem distinguir caixa. Termos de empresa excluem a regra; partículas ignoradas são configuráveis. Não presume que todo nome curto é uma pessoa. IDs e regras são retornados, sem nomes.

Recibos 0.4.0 recusados não são apagados/reexecutados pela atualização. Depois de conferir uma recusa definitiva400 sem efeito, uma nova tentativa usa nova chave; nunca troque a chave para contornar resultado incerto ou trava. A correção do formato foi validada com fornecedor sintético; HTTP200 e idempotência em conta real continuam sujeitos ao roteiro de aceite do pedido10.
