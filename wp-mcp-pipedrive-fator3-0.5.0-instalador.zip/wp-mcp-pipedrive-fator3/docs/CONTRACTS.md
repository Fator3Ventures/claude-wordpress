> Versão corrente 0.5.0: consulte também `pipedrive/documentacao-ler {"documento":"fluxos"}` para pedidos 4–10, regras, rotas e limites. As listas de motivos substituem o aceite irrestrito anterior de archive_reason.

# Contratos — 0.5.0

## Core: pipedrive-api-client/1.0.0

A assinatura abaixo é publicada pelo Core desde 1.51.0 e foi conferida no fonte 1.60.0 recebido. Não há leitura de options privadas nem HTTP próprio. A retenção local não altera esse contrato. A atualização do provider muda sua revisão; prévias criadas antes da troca devem ser refeitas, pois o Core vincula sua revisão à versão do consumidor.

Hook: `f3base_register_pipedrive_consumers($registry, 'pipedrive-api-client/1.0.0')`, depois do carregamento dos plugins. O Pipedrive chama `$registry->register_consumer('wp-mcp-pipedrive-fator3','0.5.0','pipedrive-api-client/1.0.0',$configuration)`. Callback configuration retorna `{ready:true,revision:'0.5.0',provider:'wp-mcp-pipedrive-fator3'}`. Registro não é autorização. Retorno: objeto ou WP_Error.

Cliente deve expor capabilities(), status(), request(metodo,caminho,query,corpo,contexto). capabilities retorna `{contract:'pipedrive-api-client/1.0.0'}`. Nenhuma chamada de capabilities/status envolve HTTP.

Status:
```json
{"success":true,"code":"ok","message":"Estado local.","data":{"contract":"pipedrive-api-client/1.0.0","autorizado":true,"conta":{"dominio":"exemplo.pipedrive.com","conta_id":1,"usuario_id":2},"revisao":"revisao-nao-secreta","orcamento":{"teto":3000,"consumido":0,"reservado":0},"saldo_conta":{"restante":15000,"lido_em":"2026-10-23T20:00:00Z"}}}
```

revisao muda em troca de conta/credencial/autorização. Saldo pode ser null se nunca lido. Não usar chave que inclua token no nome para metadados públicos: o MCP redige chaves sensíveis.

request recebe contexto com provider, consumer=operacao, contract, actor_id, revisao_esperada e previa_id nas mutações. O Core deve verificar revisão/autorização e reservar orçamento imediatamente antes de despachar. Resposta:
```json
{"success":true,"code":"ok","message":"Consulta concluída.","remote_dispatched":true,"data":{"http_status":200,"body":{"success":true,"data":[]},"saldo_conta":{"restante":14980,"lido_em":"2026-10-23T20:01:00Z"}}}
```

Falha anterior ao despacho usa success=false e remote_dispatched=false explícito. WP_Error pode conter esse booleano em error_data; sem ele a tentativa de escrita é incerta. Exceções e mensagens do cliente nunca são copiadas ao usuário. Códigos admitidos: saldo_conta_baixo, operacao_nao_autorizada, core_em_recuperacao, orcamento_esgotado, pipedrive_orcamento_esgotado, pausa_remota, rate_limit, credencial_invalida, revisao_conflitante, contexto_alterado e core_indisponivel. Desconhecidos viram core_recusou sem a mensagem privada.

## Transporte e autorização

Provider `wp-mcp-pipedrive-fator3`, prefixo `pipedrive/`, policy_contract=1 via f3_mcp_register_providers/ExtensionContract. Abilities API nativa registra dezenove operações. Sem MCP, REST e painel continuam disponíveis; MCP é necessário só para o transporte remoto.

api-previa é escrita local/GET remoto; api-aplicar escrita local/remota. api-ler consulta remota com efeito de orçamento no Core. status, registro, retenção-ler e documentação são observacionais. retencao-configurar grava apenas política local e exige perfil MCP de escrita. Todos exigem manage_options também no dispatcher, além da política MCP. Idempotency_key acrescentada pelo MCP é independente do previa_id; usar o previa_id da operação de domínio e não contornar recibos incertos com outra chave.

Schemas de entrada e envelope gerados em schemas.json. Caminhos, parâmetros e corpos têm validação de domínio em Policy.php. Limites: corpo 65.536 bytes, resposta 524.288 bytes, documentos 24.000 bytes/página, auditoria 100 itens/página, catálogo atual 20 páginas de 500 itens. Query vazia e corpo vazio representam objetos JSON vazios.

## Evidência técnica do fornecedor

Consultadas em 23/10/2026: documentação oficial de Leads, LeadLabels, DealFields, Notes e filtros. Leads/etiquetas usam UUID; etiquetas são lidas pela coleção. A API também documenta campos v2, mas o pedido condiciona sua adoção à prova na conta. Mantida a allowlist v1 solicitada.

- https://developers.pipedrive.com/docs/api/v1/Leads
- https://developers.pipedrive.com/docs/api/v1/LeadLabels
- https://developers.pipedrive.com/docs/api/v1/DealFields
- https://developers.pipedrive.com/docs/api/v1/Notes
- https://developers.pipedrive.com/docs/api/v1/Filters
- https://pipedrive.readme.io/docs/working-with-labels


## Retenção local — contrato herdado da 0.2.0

`pipedrive/retencao-ler {}` retorna diario_dias (0–36500), diario_sem_prazo, recibos_dias=180, previas_segundos=900, revisao SHA-256, origem (padrao/configurado), alterado_em UTC e alterado_por. status.data.retencao publica o mesmo objeto, inclusive quando o Core recusa operação. registro-ler.retencao_dias é inteiro; 0 agora indica sem prazo e sem_prazo torna esse significado explícito.

`pipedrive/retencao-configurar` exige diario_dias e revisao_esperada. Prazo positivo também exige confirmar_expurgo=true. Zero é o padrão tanto para instalação limpa quanto para upgrade da 0.2.0 sem configuração prévia. Salvar não chama fornecedor nem limpa dados. Resposta confirma changed, persisted e a política efetiva relida. Mesmo valor já persistido retorna sem_alteracao. Após timeout, reler; a revisão antiga não deve ser usada para sobrescrever uma escolha posterior.

Erros: entrada_invalida, confirmacao_ausente, revisao_conflitante, retencao_invalida (sem expurgo), retencao_ocupada e persistencia_incerta. Revisão inclui geração aleatória, detectando inclusive voltar ao mesmo valor (ABA). Configuração e limpeza compartilham mutex MySQL com timeout de 1 s; leitura não obtém trava nem grava estado. A limpeza que adquiriu a trava primeiro usa a política então vigente; salvar aguarda ou recusa e não pode ressuscitar linhas já removidas. Código externo/SQL direto não participa desse protocolo.

REST: GET /wp-json/f3-pipedrive/v1/retencao-ler e POST /wp-json/f3-pipedrive/v1/retencao-configurar, JSON pelos schemas instalados, autenticação WordPress e manage_options. Autenticação por cookie exige nonce REST nativo; formulário administrativo exige nonce próprio. Não há opção de conceder autorização ao Core por estas rotas.

## Funcionalidade herdada da 0.3.0

A 0.3.0 acrescentou `pipedrive/relatorio`, somente leitura, `remote_effect: read`, e GET de coleções `/api/v2/deals` e `/api/v2/deals/archived` em `api-ler`, apenas limit/cursor. Contrato Core 1.0.0 inalterado. `schemas.json` é gerado do registro. Relatório parcial usa success true, code relatorio_parcial; data.completo e data.coleta_completa precisam ser conferidos. Custos e códigos de categorias estão em USAGE.md.


Atualização 0.5.0, Pedido10: consulte `fluxos`/WORKFLOWS.md para os campos opcionais de calendário, textos, canais, espera, notas e adoção. Regras0.4.0 não são regravadas. Textos interpolados podem conter dados pessoais; não os inclua em logs. Auditoria distingue coleta_completa de avaliacao_completa.
