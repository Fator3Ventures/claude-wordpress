<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Durable logical operations. Remote partial effects are reported, never silently retried. */
final class Workflows {
    public static function lock(string $scope,callable $fn){global $wpdb;$name='f3pd_'.substr(hash('sha256',DB_NAME.'|'.$wpdb->prefix.'|'.$scope),0,55);if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,1)',$name))!=='1')throw new Fault('operacao_ocupada','Outra operação está usando este registro.');try{return $fn();}finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$name));}}
    private static function fingerprint(array $i): string {return hash_hmac('sha256',Support::json($i),wp_salt('auth'));}
    private static function pending(string $scope): string {return 'f3_pd_pending_'.hash('sha256',$scope);}
    private static function scope(string $op,array $i,array $status): string {return Support::digest($status['conta']).':'.($op==='negocio-perder'?'deal:':'lead:').($i['lead_id']??$i['negocio_id']??'config');}
    private static function snapshot(string $op,array $i,Collection $r,array $c): array {
        if($op==='negocio-perder'){Configuration::reason('lost_reasons',$i['lost_reason']);$d=$r->one('/api/v2/deals/'.$i['negocio_id']);if(($d['status']??null)!=='open'||!empty($d['is_archived']))throw new Fault('estado_incompativel','O negócio precisa estar aberto e fora do arquivo.');return ['registro'=>$d];}
        $lead=$r->one('/v1/leads/'.$i['lead_id']);
        if($op==='lead-arquivado-editar'){
            if(($lead['is_archived']??false)!==true||!is_string($lead['archive_reason']??null)||Collection::instant($lead['archive_time']??null)===null)throw new Fault('estado_incompativel','Exige lead arquivado com motivo e data de arquivo disponíveis.');
            if(array_intersect(array_keys($i['campos']),['is_archived','archive_reason']))throw new Fault('corpo_invalido','Motivo e estado de arquivo são preservados pela operação.');
            Policy::route('PATCH','/v1/leads/'.$i['lead_id'],[],$i['campos']);return ['registro'=>$lead];
        }
        if($op==='lead-encerrar')Rules::closure($lead,$c);
        if(!empty($lead['is_archived']))throw new Fault('estado_incompativel','O lead já está arquivado.');
        if($c['tipo_whatsapp']==='')throw new Fault('configuracao_pendente','Configure o tipo da atividade WhatsApp.');
        $activities=$r->all('/api/v2/activities',['lead_id'=>$i['lead_id']]);$r->complete();
        $wa=array_values(array_filter($activities,static fn($a)=>($a['type']??null)===$c['tipo_whatsapp']));
        if(count($wa)>1)throw new Fault('atividade_whatsapp_duplicada','Mais de uma atividade WhatsApp no lead; nenhuma escrita enviada.');
        $a=isset($wa[0])?$r->one('/api/v2/activities/'.(int)$wa[0]['id']):null;
        if($a&&(($a['lead_id']??null)!==$i['lead_id']||!array_key_exists('note',$a)))throw new Fault('estado_incompleto','A atividade não confirmou vínculo e nota completos.');
        return ['registro'=>$lead,'atividade'=>$a];
    }
    public static function preview(string $op,array $i): array {
        $cfg=Configuration::read();if($op==='lead-encerrar')Configuration::reason('archive_reasons',$i['archive_reason']);if($op==='negocio-perder')Configuration::reason('lost_reasons',$i['lost_reason']);
        Store::ready();$r=new Collection();$snapshot=self::snapshot($op,$i,$r,$cfg['regras']);$id=bin2hex(random_bytes(16));
        $p=['workflow'=>$op,'input'=>$i,'config_revision'=>$cfg['revisao'],'snapshot_hash'=>Support::digest($snapshot),'fingerprint'=>self::fingerprint($i)];Store::create($id,CoreClient::binding($r->status),$p);
        return ['success'=>true,'code'=>'previa_criada','message'=>'Revise e use pipedrive/operacao-aplicar em até 15 minutos.','data'=>['previa_id'=>$id,'operacao'=>$op,'classe'=>'registro','id'=>$i['lead_id']??$i['negocio_id'],'chaves'=>array_keys($i['campos']??[]),'config_revisao'=>$cfg['revisao'],'arquivo_data_original'=>$snapshot['registro']['archive_time']??null,'mutacoes_estimadas'=>$op==='lead-arquivado-editar'?3:($op==='lead-encerrar'?2:1),'atomicidade'=>'Operação lógica com recibo por etapa; o fornecedor não oferece transação entre endpoints.','custo_previa_unidades'=>$r->calls*20]];
    }
    public static function simulate(array $i): array {
        $cfg=Configuration::read();if(!hash_equals($cfg['revisao'],$i['revisao_esperada']))throw new Fault('revisao_conflitante','Releia a configuração.');$c=Configuration::validate($i['regras']);$simulation=Cadence::queue($i,$c);if(!$simulation['data']['coleta_completa'])return $simulation;
        Store::ready();$s=CoreClient::status();$id=bin2hex(random_bytes(16));$phrase='Confirmo por ordem do dono a configuração '.substr(self::fingerprint($c),0,16).' da prévia '.$id;
        Store::create($id,CoreClient::binding($s),['workflow'=>'configuracao','input'=>$c,'config_revision'=>$cfg['revisao'],'confirmacao'=>$phrase]);
        return ['success'=>true,'code'=>'simulacao_criada','message'=>'Simulação sem salvar regras ou escrever no fornecedor.','data'=>['previa_id'=>$id,'confirmacao_exigida'=>$phrase,'revisao_esperada'=>$cfg['revisao'],'regras'=>$c,'simulacao'=>$simulation['data']]];
    }
    private static function prior(string $id,array $status,?string $fingerprint=null): ?array {
        try{$row=Store::get($id);}catch(Fault $e){if($e->reason==='previa_inexistente')return null;throw $e;}
        if(!hash_equals($row['binding'],CoreClient::binding($status)))throw new Fault('contexto_alterado','A conta/autorização mudou; reconcilie antes de repetir.');
        if($row['state']==='done'){$r=Support::open($row['result']);if($fingerprint!==null&&!hash_equals($r['data']['entrada_digest']??'',$fingerprint))throw new Fault('idempotencia_conflitante','A chave já corresponde a outra mensagem.');return $r;}
        if($row['state']==='running')throw new Fault('resultado_incerto','Tentativa já iniciada; reconcilie pelo recibo.');
        return null;
    }
    public static function whatsapp(array $i): array {
        $s=CoreClient::status();$id=substr(hash_hmac('sha256',Support::json([$s['conta'],$i['chave_idempotencia']]),wp_salt('auth')),0,32);$fingerprint=self::fingerprint($i);
        return self::lock('message:'.$id,static function()use($i,$s,$id,$fingerprint){
            $prior=self::prior($id,$s,$fingerprint);if($prior!==null)return $prior;
            $scope=self::scope('whatsapp-registrar',$i,$s);
            return self::lock($scope,static function()use($i,$s,$id,$fingerprint,$scope){return Retention::locked(static function()use($i,$s,$id,$fingerprint,$scope){
                self::checkPending($scope);$cfg=Configuration::read();$c=$cfg['regras'];if(!$c['habilitada'])throw new Fault('configuracao_pendente','Configure e habilite a cadência antes de registrar com próximo período.');
                $r=new Collection();$snapshot=self::snapshot('whatsapp-registrar',$i,$r,$c);$a=$snapshot['atividade'];$lead=$snapshot['registro'];$progress=Cadence::progress($lead,$a,$c);
                if($progress['ambiguo']||!isset($c['toques'][$progress['indice']])||($c['toques'][$progress['indice']]['codigo']!==$i['toque']))throw new Fault('toque_incompativel','Toque não corresponde ao próximo estado reconhecido.');
                if(($c['toques'][$progress['indice']]['acao']??'mensagem')==='encerrar')throw new Fault('toque_de_encerramento','Use lead-encerrar para este toque.');
                if($a&&!empty($a['done']))throw new Fault('atividade_concluida','Atividade concluída; reabertura exige revisão explícita.');
                $p=['workflow'=>'whatsapp-registrar','input'=>$i,'config_revision'=>$cfg['revisao'],'fingerprint'=>$fingerprint];
                Store::ready();try{$existing=Store::get($id);$old=Support::open($existing['payload']);if(($old['fingerprint']??null)!==$fingerprint)throw new Fault('idempotencia_conflitante','Chave já usada por outra mensagem.');}catch(Fault $e){if($e->reason!=='previa_inexistente')throw $e;Store::create($id,CoreClient::binding($s),$p);}
                // Message receipts must outlive ordinary preview receipt retention.
                global $wpdb;if($wpdb->update(Store::table('ops'),['retain_until'=>PHP_INT_MAX],['previa_id'=>$id])===false)throw new Fault('persistencia_falhou','Não foi possível preservar idempotência.');
                return self::execute($id,$p,$snapshot,$s,$scope,$c);
            });});
        });
    }
    public static function checkPending(string $scope): void {global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",self::pending($scope)));if($wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Falha na trava persistente.');if($v!==null)throw new Fault('reconciliacao_necessaria','Há operação sem conclusão confirmada neste registro.',['previa_id'=>(string)$v]);}
    public static function rawGuard(array $i,callable $fn): array {
        $row=Store::get($i['previa_id']);if($row['state']!=='ready')return $fn();$p=Support::open($row['payload']);$route=$p['route']??[];
        if(($route['resource']??null)!=='leads')return $fn();$s=CoreClient::status();$scope=self::scope('raw',['lead_id'=>$route['id']],$s);
        return self::lock($scope,static function()use($scope,$fn,$route){return Retention::locked(static function()use($scope,$fn,$route){self::checkPending($scope);if(($route['corpo']['is_archived']??false)===true){$lead=(new Collection())->one('/v1/leads/'.$route['id']);Rules::closure($lead,Configuration::read()['regras'],true);}return $fn();});});
    }
    public static function apply(array $i): array {
        Store::ready();$row=Store::get($i['previa_id']);$s=CoreClient::status();$prior=self::prior($i['previa_id'],$s);if($prior!==null)return $prior;
        if($row['state']!=='ready'||(int)$row['expires']<=time())throw new Fault('previa_expirada','Gere nova prévia.');$p=Support::open($row['payload']);$op=$p['workflow']??null;
        if(!in_array($op,['configuracao','lead-encerrar','negocio-perder','lead-arquivado-editar'],true))throw new Fault('operacao_invalida','Esta prévia não pertence a uma operação composta.');
        $scope=self::scope($op,$p['input'],$s);
        return self::lock($scope,static function()use($i,$p,$op,$s,$scope){return Retention::locked(static function()use($i,$p,$op,$s,$scope){
            if(!hash_equals(Configuration::read()['revisao'],$p['config_revision']))throw new Fault('revisao_conflitante','Regras alteradas; refaça a prévia.');
            if($op==='configuracao'){
                if(!hash_equals($p['confirmacao'],$i['confirmacao']??''))throw new Fault('confirmacao_ausente','Copie a frase da simulação após ordem do dono.');$meta=self::meta($i['previa_id'],$p);
                if(!Store::claim($i['previa_id'],$meta))throw new Fault('resultado_incerto','Prévia já adquirida.');
                try{$data=Configuration::save($p['input'],$p['config_revision']);$result=['success'=>true,'code'=>'configuracao_salva','message'=>'Regras persistidas e relidas.','data'=>$data];}catch(Fault $e){$result=Support::fail($e);}
                $meta['status']=$result['code'];Store::finish($i['previa_id'],$result,$meta);return $result;
            }
            self::checkPending($scope);$r=new Collection();$c=Configuration::read()['regras'];$snapshot=self::snapshot($op,$p['input'],$r,$c);
            if(!hash_equals($p['snapshot_hash'],Support::digest($snapshot)))throw new Fault('estado_alterado','O estado mudou; gere nova prévia.');
            return self::execute($i['previa_id'],$p,$snapshot,$s,$scope,$c);
        });});
    }
    private static function meta(string $id,array $p): array {return ['previa_id'=>$id,'metodo'=>'WORKFLOW','caminho'=>'pipedrive/'.$p['workflow'],'classe'=>$p['workflow']==='configuracao'?'estrutura':'registro','status'=>'em_execucao','chaves_alteradas'=>array_keys($p['input']),'etapas'=>[]];}
    private static function execute(string $id,array $p,array $snapshot,array $s,string $scope,array $c): array {
        $meta=self::meta($id,$p);$op=$p['workflow'];$i=$p['input'];$record=$snapshot['registro'];$activity=$snapshot['atividade']??null;
        if(!Store::claim($id,$meta))throw new Fault('resultado_incerto','Operação adquirida ou expirada. Não repita.');
        if(!add_option(self::pending($scope),$id,'',false))throw new Fault('persistencia_incerta','Trava persistente não confirmada; nenhuma escrita iniciada.');
        $steps=[];$safe=true;$output=['entrada_digest'=>$p['fingerprint'],'operacao'=>$op,'id'=>$i['lead_id']??$i['negocio_id'],'etapas'=>[]];
        $send=static function(string $label,string $method,string $path,array $body)use(&$steps,&$safe,$s,$id){
            if(strlen(Support::json($body))>65536)throw new Fault('corpo_excedeu_limite','Nota excedeu 64 KiB; nenhuma nova escrita enviada.');
            try{$r=CoreClient::request($method,$path,[],$body,$s,$id);}catch(Fault $e){$r=Support::fail($e)+['remote_dispatched'=>false];}
            $certain=$r['success']||($r['remote_dispatched']??null)===false||($r['code']==='fornecedor_recusou');if(!$certain)$safe=false;
            $steps[]=['etapa'=>$label,'success'=>$r['success'],'code'=>$r['code'],'http_status'=>$r['data']['http_status']??null,'remote_dispatched'=>$r['remote_dispatched']??null];
            global $wpdb;$checkpoint=['previa_id'=>$id,'metodo'=>'WORKFLOW','classe'=>'registro','status'=>'em_execucao','etapas'=>$steps];
            if($wpdb->update(Store::table('journal'),['metadata'=>Support::json($checkpoint)],['previa_id'=>$id])===false)throw new Fault('persistencia_incerta','Checkpoint indisponível após etapa; reconcilie.');
            return $r;
        };
        $ok=false;
        try{
            if($op==='negocio-perder'){$r=$send('perder','PATCH','/api/v2/deals/'.$i['negocio_id'],['status'=>'lost','lost_reason'=>$i['lost_reason']]);$ok=$r['success'];}
            elseif($op==='lead-arquivado-editar'){
                $path='/v1/leads/'.$i['lead_id'];$output['arquivo_data_original']=$record['archive_time'];$r=$send('desarquivar','PATCH',$path,['is_archived'=>false]);
                if($r['success']){
                    try{$edit=$send('editar','PATCH',$path,$i['campos']);}catch(\Throwable $e){$edit=['success'=>false];$steps[]=['etapa'=>'editar','success'=>false,'code'=>'falha_local'];}
                    $archive=$send('rearquivar','PATCH',$path,['is_archived'=>true,'archive_reason'=>$record['archive_reason']]);$ok=$edit['success']&&$archive['success'];$output['rearquivado']=$archive['success'];$output['arquivo_data_nova']=$archive['data']['body']['data']['archive_time']??null;if(!$archive['success'])$safe=false;
                    if($archive['success']){$verify=(new Collection())->one($path);$output['rearquivado']=($verify['is_archived']??false)===true&&($verify['archive_reason']??null)===$record['archive_reason'];$output['arquivo_data_nova']=$verify['archive_time']??null;$ok=$ok&&$output['rearquivado']&&Collection::instant($output['arquivo_data_nova'])!==null;if(!$output['rearquivado'])$safe=false;}
                }elseif(!$safe){$output['rearquivado']=null;}
            }else{
                $now=time();$note=(string)($activity['note']??'');$line=Rules::noteLine($i['mensagem'],$now,$c);$note.='<p>'.$line;
                if($op==='whatsapp-registrar')$note.=' '.Cadence::marker($i['lead_id'],$i['toque'],$now,$i['chave_idempotencia']);$note.='</p>';
                $body=['note'=>$note,'done'=>$op==='lead-encerrar'];
                if($op==='whatsapp-registrar'){
                    $progress=Cadence::progress($record,['note'=>$note],$c);$next=$c['toques'][$progress['indice']]??null;
                    $slot=$next?Rules::deadline($next['base']==='entrada'?(Collection::instant($record['add_time']??null)??$now):$now,$next,$c):Cadence::slot($now+60,$c);$body['due_date']=gmdate('Y-m-d',$slot['instante']);$body['due_time']=gmdate('H:i',$slot['instante']);$output['proximo_periodo_utc']=gmdate('Y-m-d\TH:i:s\Z',$slot['instante']);
                }
                if($activity){$r=$send('atualizar_whatsapp','PATCH','/api/v2/activities/'.(int)$activity['id'],$body);$output['atividade_id']=$activity['id'];}
                else{$body+=['subject'=>'WhatsApp','type'=>$c['tipo_whatsapp'],'lead_id'=>$i['lead_id']];$r=$send('criar_whatsapp','POST','/api/v2/activities',$body);$output['atividade_id']=$r['data']['body']['data']['id']??null;if($r['success']&&!is_numeric($output['atividade_id'])){$safe=false;$r['success']=false;}}
                $ok=$r['success'];
                if($ok&&!$activity){$verifyReader=new Collection();$rows=$verifyReader->all('/api/v2/activities',['lead_id'=>$i['lead_id']]);$verifyReader->complete();$same=array_filter($rows,static fn($a)=>($a['type']??null)===$c['tipo_whatsapp']);if(count($same)!==1){$safe=false;$ok=false;$steps[]=['etapa'=>'verificar_unicidade','success'=>false,'code'=>'atividade_whatsapp_duplicada'];}}
                if($ok&&$op==='lead-encerrar'){$r=$send('arquivar','PATCH','/v1/leads/'.$i['lead_id'],['is_archived'=>true,'archive_reason'=>$i['archive_reason']]);$ok=$r['success'];if(!$ok)$safe=false;}
            }
        }catch(Fault $e){$steps[]=['etapa'=>'interrompida','success'=>false,'code'=>$e->reason];$safe=false;$ok=false;}
        catch(\Throwable $e){$steps[]=['etapa'=>'interrompida','success'=>false,'code'=>'resultado_incerto'];$safe=false;$ok=false;}
        $output['etapas']=$steps;$output['reconciliacao_necessaria']=!$safe;
        $result=['success'=>$ok,'code'=>$ok?'operacao_concluida':($safe?'operacao_recusada':'resultado_parcial_ou_incerto'),'message'=>$ok?'Operação concluída; recibo persistido.':'Confira as etapas; efeitos parciais não são repetidos automaticamente.','previa_id'=>$id,'applied'=>$ok?true:null,'data'=>$output];
        $meta['status']=$result['code'];$meta['etapas']=$steps;Store::finish($id,$result,$meta);
        if($safe)delete_option(self::pending($scope));return $result;
    }
}
