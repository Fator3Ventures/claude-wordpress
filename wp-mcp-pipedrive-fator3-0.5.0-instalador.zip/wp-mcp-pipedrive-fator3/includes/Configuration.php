<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Versioned business rules. No initialization on reads; save only an approved simulation. */
final class Configuration {
    public const OPTION='f3_pipedrive_operation_rules';
    public static function schema(): array {
        $s=['type'=>'string','maxLength'=>500];$code=['type'=>'string','pattern'=>'^[a-z0-9_-]{1,40}$'];$field=['type'=>'string','pattern'=>'^(?:[a-f0-9]{40}|[a-z][a-z0-9_]{0,49})$'];
        $list=static fn($item,$max=100)=>['type'=>'array','items'=>$item,'maxItems'=>$max,'uniqueItems'=>true];
        $obj=static fn($p)=>['type'=>'object','properties'=>$p,'required'=>array_keys($p),'additionalProperties'=>false];
        $clock=['type'=>'string','pattern'=>'^(?:[01][0-9]|2[0-3]):[0-5][0-9]$'];
        $schema=$obj([
            'habilitada'=>['type'=>'boolean'],'fuso'=>['type'=>'string','maxLength'=>60],
            'dias'=>$list(['type'=>'integer','minimum'=>1,'maximum'=>7],7),
            'janela'=>$obj(['inicio'=>$clock,'fim'=>$clock]),
            'periodos'=>$list($obj(['codigo'=>$code,'hora'=>$clock]),24),
            'toques'=>$list($obj(['codigo'=>$code,'atraso_minutos'=>['type'=>'integer','minimum'=>0,'maximum'=>525600], 'base'=>['type'=>'string','enum'=>['entrada','ultimo_registro']], 'texto_id'=>$code,'etiqueta_id'=>['type'=>'string','maxLength'=>36]]),50),
            'textos'=>$list($obj(['codigo'=>$code,'texto'=>['type'=>'string','minLength'=>1,'maxLength'=>4000]]),50),
            'tipo_whatsapp'=>['type'=>'string','maxLength'=>100,'pattern'=>'^[a-zA-Z0-9_-]*$'],
            'exclusoes'=>$obj(['etiquetas'=>$list(['type'=>'string','pattern'=>'^[a-fA-F0-9-]{36}$']), 'campos'=>$list($obj(['campo'=>$field,'valores'=>$list(['type'=>['string','integer'],'maxLength'=>500]),'regra'=>$code]))]),
            'archive_reasons'=>$list($s,100),'lost_reasons'=>$list($s,100),
            'auditoria'=>$obj(['campos_origem'=>$list($field,4),'separador_titulo'=>['type'=>'string','maxLength'=>20],
                'etapas'=>$list($obj(['id'=>['type'=>'integer','minimum'=>1],'alerta_minutos'=>['type'=>'integer','minimum'=>1,'maximum'=>525600],'primeira'=>['type'=>'boolean']]),100),
                'tipos_reuniao'=>$list(['type'=>'string','pattern'=>'^[a-zA-Z0-9_-]{1,100}$'],30)])
        ]);
        $condition=$obj(['campo'=>$field,'operador'=>['type'=>'string','enum'=>['igual','presente','ausente']],'valores'=>$list(['type'=>['string','integer'],'maxLength'=>500])]);
        $touch=&$schema['properties']['toques']['items']['properties'];
        $touch['prazo']=['type'=>'string','enum'=>['periodo','minutos_uteis','primeiro_periodo_dia_util_seguinte']];
        $touch['acao']=['type'=>'string','enum'=>['mensagem','encerrar']];
        $touch['variantes']=$list($obj(['condicao'=>$condition,'texto_id'=>$code]),30);
        $schema['properties'] += [
            'feriados'=>$list(['type'=>'string','pattern'=>'^\\d{4}-\\d{2}-\\d{2}$'],366),
            'nota'=>$obj(['prefixo'=>['type'=>'string','maxLength'=>40],'formato'=>['type'=>'string','enum'=>['d/m H\\hi','d/m/Y H\\hi','Y-m-d\\TH:i:sP']],'autor'=>['type'=>'string','minLength'=>1,'maxLength'=>80]]),
            'variaveis'=>$list($obj(['codigo'=>$code,'campo'=>$field,'parte'=>['type'=>'string','enum'=>['inteiro','primeiro_nome']]]),50),
            'canais'=>$list($obj(['codigo'=>$code,'condicao'=>$condition,'permitir_encerramento'=>['type'=>'boolean'],'permitir_arquivamento'=>['type'=>'boolean']]),30),
            'espera_entrega'=>$obj(['habilitada'=>['type'=>'boolean'],'condicao'=>$condition,'campo_desde'=>['type'=>'string','pattern'=>'^(?:|[a-f0-9]{40}|[a-z][a-z0-9_]{0,49})$'],'rever_minutos'=>['type'=>'integer','minimum'=>1,'maximum'=>525600],'encerrar_minutos'=>['type'=>'integer','minimum'=>1,'maximum'=>525600]]),
            'adocao'=>$obj(['habilitada'=>['type'=>'boolean'],'prefixo'=>['type'=>'string','maxLength'=>40],'autor'=>['type'=>'string','minLength'=>1,'maxLength'=>80],'max_idade_dias'=>['type'=>'integer','minimum'=>1,'maximum'=>366],'toques_por_texto'=>$list($obj(['trecho'=>['type'=>'string','minLength'=>1,'maxLength'=>500],'toque'=>$code]),50)])
        ];
        $schema['properties']['auditoria']['properties']['nome_pessoa']=$obj(['habilitada'=>['type'=>'boolean'],'palavras_empresa'=>$list(['type'=>'string','minLength'=>1,'maxLength'=>100]),'ignorar_palavras'=>$list(['type'=>'string','minLength'=>1,'maxLength'=>50]),'minimo_tokens'=>['type'=>'integer','minimum'=>2,'maximum'=>10]]);
        return $schema;
    }
    public static function defaults(): array {
        return json_decode((string)file_get_contents(ROOT.'/docs/regras-iniciais.json'),true,512,JSON_THROW_ON_ERROR);
    }
    public static function validate(array $v): array {
        if(is_wp_error(rest_validate_value_from_schema($v,self::schema(),'regras')) || strlen(Support::json($v))>65536) throw new Fault('configuracao_invalida','Confira o schema da configuração (máximo 64 KiB).');
        try { new \DateTimeZone($v['fuso']); } catch(\Throwable $e){throw new Fault('configuracao_invalida','Fuso IANA inválido.');}
        if($v['janela']['inicio']>=$v['janela']['fim']) throw new Fault('configuracao_invalida','A janela deve começar antes de terminar, no mesmo dia.');
        foreach(['periodos','toques','textos'] as $key){$codes=array_column($v[$key],'codigo');if(count(array_unique($codes))!==count($codes))throw new Fault('configuracao_invalida','Códigos duplicados.');}
        foreach($v['periodos'] as $p){if($p['hora']<$v['janela']['inicio']||$p['hora']>$v['janela']['fim'])throw new Fault('configuracao_invalida','Período fora da janela.');}
        foreach($v['toques'] as $p){if(!in_array($p['texto_id'],array_column($v['textos'],'codigo'),true))throw new Fault('configuracao_invalida','Toque sem texto aprovado.');if($p['etiqueta_id']!==''&&!preg_match('/^[a-fA-F0-9]{8}(?:-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12}$/D',$p['etiqueta_id']))throw new Fault('configuracao_invalida','Etiqueta deve ser UUID.');}
        if($v['habilitada']&&(!$v['dias']||!$v['periodos']||!$v['toques']||$v['tipo_whatsapp']===''))throw new Fault('configuracao_invalida','Cadência habilitada exige dias, períodos, toques e tipo WhatsApp.');
        foreach(['archive_reasons','lost_reasons'] as $k)foreach($v[$k] as $reason)if(trim($reason)!==$reason||$reason==='')throw new Fault('configuracao_invalida','Motivos não podem ser vazios ou conter espaços externos.');
        foreach($v['feriados']??[] as $day){$d=\DateTimeImmutable::createFromFormat('!Y-m-d',$day);if(!$d||$d->format('Y-m-d')!==$day)throw new Fault('configuracao_invalida','Feriado inválido.');}
        foreach($v['toques'] as $t)if(($t['prazo']??'')==='primeiro_periodo_dia_util_seguinte'&&$t['atraso_minutos']!==0)throw new Fault('configuracao_invalida','Primeiro período do dia seguinte exige atraso_minutos zero.');
        $texts=array_column($v['textos'],'texto','codigo');$variables=array_column($v['variaveis']??[],'codigo');
        if(count($variables)!==count(array_unique($variables)))throw new Fault('configuracao_invalida','Variável duplicada.');
        foreach($v['toques'] as $t)foreach($t['variantes']??[] as $rule)if(!isset($texts[$rule['texto_id']]))throw new Fault('configuracao_invalida','Variante sem texto aprovado.');
        // Existing literal templates remain valid until the substitution feature is explicitly configured.
        if(array_key_exists('variaveis',$v))foreach($texts as $text){preg_match_all('/\{([a-z0-9_-]{1,40})\}/',$text,$m);foreach($m[1] as $key)if(!in_array($key,$variables,true))throw new Fault('configuracao_invalida','Texto com variável não mapeada.');}
        $wait=$v['espera_entrega']??null;if($wait&&$wait['rever_minutos']>=$wait['encerrar_minutos'])throw new Fault('configuracao_invalida','Revisão de entrega deve preceder o encerramento.');
        foreach($v['adocao']['toques_por_texto']??[] as $m)if(!in_array($m['toque'],array_column($v['toques'],'codigo'),true))throw new Fault('configuracao_invalida','Adoção aponta para toque inexistente.');
        return $v;
    }
    public static function read(): array {
        global $wpdb;Support::admin();
        $raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",self::OPTION));
        if($wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Falha ao ler regras.');
        $v=$raw===null?self::defaults():json_decode($raw,true);
        if(!is_array($v))throw new Fault('configuracao_invalida','Regras ilegíveis; restaure sem apagar dados.');
        return ['regras'=>self::validate($v),'revisao'=>Support::digest([$wpdb->options,self::OPTION,$raw]),'origem'=>$raw===null?'padrao_pendente':'configurado'];
    }
    public static function reason(string $kind,string $reason): void {
        if(!in_array($reason,self::read()['regras'][$kind],true))throw new Fault('motivo_invalido','Motivo fora da lista aprovada. Nenhuma escrita foi enviada.');
    }
    public static function save(array $v,string $revision): array {
        return Retention::locked(static function()use($v,$revision){
            global $wpdb;$old=self::read();if(!hash_equals($old['revisao'],$revision))throw new Fault('revisao_conflitante','As regras mudaram. Simule novamente.');
            $raw=Support::json(self::validate($v));
            if($old['origem']==='padrao_pendente')$n=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'off')",self::OPTION,$raw));
            else $n=$wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s WHERE option_name=%s",$raw,self::OPTION));
            wp_cache_delete(self::OPTION,'options');wp_cache_delete('notoptions','options');wp_cache_delete('alloptions','options');
            if($n===false||self::read()['regras']!==$v)throw new Fault('persistencia_incerta','Releia a configuração antes de repetir.');
            return self::read();
        });
    }
}
