"""Isolated native WordPress tests. Requires an explicit dependency manifest; never edits another lab."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, signal, socket, subprocess, tarfile, time, uuid, zipfile, tempfile
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tree_digest(path):
    h=hashlib.sha256()
    for p in sorted(path.rglob('*')):
        if p.is_file():h.update(p.relative_to(path).as_posix().encode()+b'\0'+bytes.fromhex(digest(p)))
    return h.hexdigest()
def extract_zip(p,target):
    with zipfile.ZipFile(p) as z:
        for x in z.infolist():
            name=Path(x.filename)
            if name.is_absolute() or '..' in name.parts or (x.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe archive')
        z.extractall(target)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--manifest',required=True,type=Path);ap.add_argument('--workdir',required=True,type=Path);ap.add_argument('--origin',choices=['clean','upgrade'],default='clean');ap.add_argument('--ui',action='store_true');ap.add_argument('--ui-only',action='store_true');ap.add_argument('--order',choices=['meta-first','linkedin-first','meta-only','linkedin-only','trio-first','social-first'],default='meta-first');a=ap.parse_args()
    if a.ui_only and not a.ui:ap.error('--ui-only requires --ui')
    inputs=json.loads(a.manifest.read_text());paths={}
    for name,item in inputs.items():
        p=Path(item['path']);p=(p if p.is_absolute() else a.manifest.parent/p).resolve()
        if (tree_digest(p) if p.is_dir() else digest(p))!=item['sha256']:raise ValueError('Dependency hash mismatch: '+name)
        if not p.exists():raise ValueError('Missing input: '+name)
        paths[name]=p
    lab=a.workdir.resolve()
    if lab.exists() and any(lab.iterdir()):raise ValueError('Workdir must be new/empty')
    lab.mkdir(parents=True,mode=0o700,exist_ok=True);identity=uuid.uuid4().hex;(lab/'.social-lab.json').write_text(json.dumps({'id':identity,'path':str(lab)}))
    rt=paths['runtime'];php_rt=paths.get('php_runtime',rt);php_version=inputs.get('php_runtime',{}).get('php_version','8.3');php=php_rt/('usr/bin/php'+php_version)
    modules=['ctype','fileinfo','tokenizer','phar','mbstring','mysqlnd','mysqli','pdo','pdo_mysql','dom','xml','simplexml','xmlreader','xmlwriter','curl','zip','iconv','posix']
    (lab/'php.ini').write_text('extension_dir='+str(php_rt/('usr/lib/php/'+('20210902' if php_version=='8.1' else '20230831')))+'\n'+''.join('extension='+x+'.so\n' for x in modules)+'memory_limit=512M\ndate.timezone=UTC\n')
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    env=os.environ.copy();env.update(LD_LIBRARY_PATH=str(php_rt/'usr/lib/x86_64-linux-gnu')+':'+str(rt/'usr/lib/x86_64-linux-gnu'),PHPRC=str(lab/'php.ini'),F3_LAB_ROOT=str(lab),F3_LAB_ID=identity,F3_LAB_ORIGIN=a.origin,F3_LAB_ORDER=a.order,F3_SOURCE_ROOT=str(ROOT))
    def run(script):return subprocess.run([str(php),'-c',str(lab/'php.ini'),str(script)],env=env,check=True)
    with tarfile.open(paths['wordpress']) as t:
        for x in t.getmembers():
            if Path(x.name).is_absolute() or '..' in Path(x.name).parts or x.issym() or x.islnk():raise ValueError('Unsafe WordPress archive')
        t.extractall(lab,filter='data')
    wp=lab/'wordpress';plugins=wp/'wp-content/plugins';plugins.mkdir(exist_ok=True,parents=True);(lab/'evidence').mkdir();(lab/'mysql').mkdir();(lab/'mysql-files').mkdir();(lab/'private').mkdir()
    selected=['meta','linkedin'];selected=selected[::-1] if a.order=='linkedin-first' else selected
    if a.order.endswith('-only'):selected=[a.order.split('-')[0]]
    candidate_dir=ROOT/'dist' if (ROOT/'dist').is_dir() else ROOT/'build/dist'
    packages={name:paths['baseline_'+name] if a.origin=='upgrade' else candidate_dir/('wp-mcp-'+name+'-fator3-0.4.1-instalador.zip') for name in selected}
    for p in packages.values():extract_zip(p,plugins)
    if a.order in ['trio-first','social-first']:
        for name in ['core','mcp','google']:extract_zip(paths[name],plugins)
    mu=wp/'wp-content/mu-plugins';mu.mkdir(exist_ok=True)
    (mu/'lab.php').write_text("<?php add_filter('pre_wp_mail',static fn()=>true);add_filter('pre_http_request',static fn($pre)=>$pre!==false?$pre:new WP_Error('lab_network_blocked','Only test fixtures are allowed'),PHP_INT_MAX);\n")
    dbroot=Path(tempfile.mkdtemp(prefix='f3-social-mysql-'));dbname='social_'+identity[:12];mysql=rt/'usr/sbin/mysqld';base=[str(mysql),'--no-defaults','--user='+str(os.getuid()),'--basedir='+str(rt/'usr'),'--datadir='+str(dbroot)]
    with open(lab/'mysql-init.log','w') as log:subprocess.run(base+['--initialize-insecure'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
    db=None;web=None
    try:
        with open(lab/'mysql.log','w') as log:db=subprocess.Popen(base+['--bind-address=127.0.0.1','--port='+str(port),'--socket=','--mysqlx=0','--pid-file='+str(lab/'mysql.pid'),'--secure-file-priv='+str(lab/'mysql-files')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        for attempt in range(200):
            if db.poll() is not None:raise RuntimeError('MySQL stopped')
            try:
                with socket.create_connection(('127.0.0.1',port),.2) as c:
                    if c.recv(8)[4:5]==b'\x0a':break
            except OSError:pass
            time.sleep(.1)
        create=lab/'create.php';create.write_text("<?php $db=new mysqli('127.0.0.1','root','',null,"+str(port)+");$db->query('CREATE DATABASE "+dbname+" CHARACTER SET utf8mb4');")
        run(create)
        config="<?php define('DB_NAME',%r);define('DB_USER','root');define('DB_PASSWORD','');define('DB_HOST',%r);define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');$table_prefix='wp_';define('DISABLE_WP_CRON',true);define('WP_DEBUG',true);define('WP_DEBUG_LOG',true);define('WP_DEBUG_DISPLAY',false);define('FS_METHOD','direct');define('F3_MCP_PRIVATE_ROOT',%r);\n"%(dbname,'127.0.0.1:'+str(port),str(lab/'private'))
        config+=''.join("define('%s','%s');\n"%(k,os.urandom(32).hex()) for k in ['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'])
        # use each salt/key exactly once
        lines=config.splitlines();seen=set();config='\n'.join(x for x in lines if not (x.startswith("define('") and (x.split("'")[1] in seen or seen.add(x.split("'")[1]))))
        config+="\nif(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';"
        (wp/'wp-config.php').write_text(config);(wp/'wp-config.php').chmod(0o600)
        run(ROOT/'tests/native/init.php')
        if a.origin=='upgrade':
            run(ROOT/'tests/native/seed.php')
            for name in selected:
                path=plugins/('wp-mcp-'+name+'-fator3');shutil.rmtree(path);extract_zip(candidate_dir/('wp-mcp-'+name+'-fator3-0.4.1-instalador.zip'),plugins)
        if not a.ui_only:run(ROOT/'tests/native/suite.php')
        if a.ui:
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));ui_port=sock.getsockname()[1]
            env.update(F3_CHROME=str(ROOT/'dependencies/chrome/chrome-linux64/chrome'),F3_UI_PASSWORD=uuid.uuid4().hex,F3_UI_URL='http://127.0.0.1:'+str(ui_port),PLAYWRIGHT_BROWSERS_PATH=str(ROOT/'dependencies/browsers'),F3_JSDOM=os.environ.get('F3_JSDOM',str(ROOT/'dependencies/dom/node_modules/jsdom')))
            shutil.copy2(ROOT/'tests/native/ui-fixtures.php',mu/'ui-fixtures.php')
            run(ROOT/'tests/native/ui-init.php')
            with open(lab/'php-web.log','w') as log:web=subprocess.Popen([str(php),'-c',str(lab/'php.ini'),'-S','127.0.0.1:'+str(ui_port),'-t',str(wp),str(ROOT/'tests/native/router.php')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            for _ in range(100):
                try:
                    with socket.create_connection(('127.0.0.1',ui_port),.2):break
                except OSError:time.sleep(.05)
            subprocess.run(['node',str(ROOT/'tests/native/ui-dom.cjs')],env=env,check=True)
        inventory={}
        for name in selected:
            archive=candidate_dir/('wp-mcp-'+name+'-fator3-0.4.1-instalador.zip');slug='wp-mcp-'+name+'-fator3'
            with zipfile.ZipFile(archive) as z:expected={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if not n.endswith('/')}
            actual={p.relative_to(plugins).as_posix():digest(p) for p in (plugins/slug).rglob('*') if p.is_file()}
            if expected!=actual:raise RuntimeError('Installed package differs: '+name)
            inventory[name]={'sha256':digest(archive),'files':len(actual),'exact':True}
        (lab/'evidence/environment.json').write_text(json.dumps({'origin':a.origin,'order':a.order,'ui_only':a.ui_only,'inputs':inputs,'packages':inventory,'runtime':subprocess.run([str(php),'-v'],env=env,capture_output=True,text=True).stdout},indent=2))
    finally:
        if web and web.poll() is None:
            os.killpg(web.pid,signal.SIGTERM);web.wait(timeout=5)
        if db and db.poll() is None:
            os.killpg(db.pid,signal.SIGTERM)
            try:db.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(db.pid,signal.SIGKILL);db.wait()
        shutil.rmtree(dbroot)
        (lab/'.social-lab.json').write_text(json.dumps({'id':identity,'path':str(lab),'stopped':True}))
if __name__=='__main__':main()
