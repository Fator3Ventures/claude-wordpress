# Plano Meta e LinkedIn 0.4.0

21/10/2026. Base imutável 0.3.0, fontes e instaladores recuperados e hashes conferidos. Alvo previsto 0.4.0, instaladores ainda não gerados. Normas revisão 4.

## Pedidos

Meta 10: navegação por assunto com URL, estados locais de carga, usuários e ativos por nome, objetos em listas, português, formulário estruturado, API fora da tela comum. Meta 11: page_views_total diária catalogada, sem inventar substituta ou retirada global; validação por API ou registro de recusa com versão/motivo. LinkedIn 4: navegação equivalente, usuários/contas/formulários em listas, agrupamentos traduzidos, nenhum editor JSON, estados e datas legíveis.

## Fronteiras examinadas

Core 1.43.0, MCP 0.24.0 e Google 0.16.0 recebidos e já presentes no fator3-teste. Adotar navegação em pílulas com links nativos. Manter SDK LinkedIn e responsabilidades do Core; nenhuma alteração no cliente Core ou Google. Operações administrativas novas/aditivas usam os gates atuais. Não foi identificado encaminhamento técnico necessário a outro plugin neste planejamento. A falta de descoberta completa no cliente externo Core 249 é limite do consumidor recebido, não será declarada corrigida pelo novo painel LinkedIn. Implantador não fornecido, não-avaliado.

## Implementação e provas

1. Bootstrap local sem fornecedor; carregamento remoto por seção, erros e vazio explícitos; nenhum segredo pré-preenchido.
2. Seleção de usuários por nome sem elevar privilégios. Descoberta não concede ativos automaticamente. Preservar seleções existentes se a descoberta falhar; revisão obrigatória ao salvar.
3. Reutilizar catálogos/consultas confinadas; nomes LinkedIn por metadados da mesma conta/organização; paginação acessível. Formulários e grants por caixas de seleção, valores JSON somente no transporte.
4. Meta: incluir a métrica solicitada como candidata sujeita à validação remota; preservar código/subcódigo e ausência como nulo; não substituir visualizações de perfil por visualizações de mídia.
5. Atualizar docs/schemas. Testar WordPress limpo, isolado e atualização 0.3.0 com preservação; executar navegador real sobre WordPress local, permissões/nonce, estados vazios/falhas e opções.
6. Site-Teste: instalação serial dos sociais somente, pré-imagens/hashes/sondas e documentação MCP. Não publicar na frota ou criar efeitos comerciais. Aceite ctooffice somente leitura autorizada quando os contratos disponíveis permitirem; sem copiar credenciais.
7. Entrega separada por plugin: fonte, instalador e relatório; evidências sanitizadas. Impactos apenas se surgir consequência concreta sobre outro pacote, antes de implementar essa fronteira.

## Revisão final 21/10/2026 — alvo 0.4.1

O navegador do Site-Teste mostrou chaves em inglês no diagnóstico da 0.4.0. Corrigir a apresentação em versão nova, mantendo os ZIPs 0.4.0 intactos. Sem mudança de contrato, permissão, dados ou impacto em outro pacote. Validar tradução, dados de fornecedor preservados, atualização 0.4.0→0.4.1 e salto da base recebida 0.3.0→0.4.1.

## Regra do dono nesta rodada

Após a 0.4.0 intermediária, revisões no mesmo ciclo incrementam PATCH. Alvo final: 0.4.1 para ambos os plugins, conforme orientação explícita do dono. O candidato local 0.5.0 não foi instalado nem publicado e foi descartado da entrega. Não alterar as instruções centrais anexadas; aplicar esta decisão no pacote e nas próximas revisões do mesmo ciclo.

## Fechamento do ciclo — 0.4.1

Implementação e seis cenários nativos concluídos: 407 verificações sem falha, mais 20 fluxos DOM/REST. O Chrome local não iniciou por restrição de socket; a revisão visual ocorreu no navegador do Site-Teste autorizado, separada dos testes DOM. Ambos os plugins estão ativos em 0.4.1 no Site-Teste. Os 28 documentos instalados foram lidos integralmente pelo MCP em 37 páginas e comparados byte a byte com os instaladores. Zero conexões no site; homologação de fornecedores e comparação Porter permanecem pendentes. Evidências atuais estão em `evidence/`; `history-040/` registra somente o marco anterior. Nenhum impacto adicional surgiu sobre Core, MCP ou Google.
