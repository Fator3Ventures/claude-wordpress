# Fonte — Fator3 MCP Social 0.4.1

Cada entrega fonte contém somente o runtime/build do respectivo provedor. `plugin/<slug>/` é o código instalado; `build/` reproduz o ZIP determinístico; `tests/` contém testes com WordPress real e respostas externas controladas. O fonte não é instalável.

## Reprodução do instalador

Requisitos de desenvolvimento: Python 3, PHP de 64 bits 8.1.2+; runtime validado PHP 8.3.6. Execute `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. O ZIP sai em `build/dist`. O hash deve coincidir com o instalador do relatório. O script copia docs e compila o catálogo documental sem depender de symlinks.

## Testes nativos reproduzíveis

1. Obtenha os instaladores-base 0.3.0 (base recebida) ou 0.4.0 (marco intermediário do Site-Teste) e os acompanhantes indicados nos manifests de exemplo. Eles não estão aninhados neste fonte.
2. Execute `F3_RUNTIME_DOWNLOAD_ROOT=/caminho/externo python3 tools/fetch-runtime.py`; os downloads oficiais têm SHA-256 fixado. Para o mínimo: `tools/fetch-php81.py` com a mesma variável. Mantenha dependências fora do fonte.
3. Obtenha WordPress de https://wordpress.org/wordpress-7.1.3.tar.gz ou https://wordpress.org/wordpress-6.4.tar.gz e confira hashes em `tools/*dependencies.example.json`.
4. Copie e ajuste os paths do manifest. Hash de diretório = SHA-256 da sequência ordenada de caminho relativo UTF-8 + byte zero + SHA-256 binário de cada arquivo; o runner verifica todos.
5. `python3 tools/lab.py --manifest /caminho/manifest.json --workdir /caminho/novo --order meta-only` ou `linkedin-only`. No fonte de um único provedor, use a opção correspondente. Para a matriz conjunta, reúna os dois builds/dist ou runtimes de fonte e reconstrua os dois instaladores; use `--order trio-first`, `social-first` ou `linkedin-first`. Atualização acrescenta `--origin upgrade` e exige a base.
6. Os testes inicializam MySQL/WordPress descartáveis e encerram apenas seus processos. Não usar o banco compartilhado do site de testes. Toda chamada externa do laboratório é bloqueada ou atendida por fixture; SMTP não envia.
7. Teste de interface/DOM: instale as dependências de `tests/dom` com `npm ci --prefix tests/dom --ignore-scripts --no-audit --no-fund`, passe `F3_JSDOM=/caminho/tests/dom/node_modules/jsdom` e `--ui` ao runner. Este fluxo usa HTML/JS do WordPress e REST autenticada real; não é prova visual. O teste respeita meta-only/linkedin-only; na matriz conjunta, os dois plugins precisam estar disponíveis. A prova visual manual é registrada separadamente em `evidence/site-browser.json`.

`tools/fetch-browser.py` é auxiliar opcional de desenvolvimento. O Chrome local não iniciou no ambiente desta rodada por socket indisponível; a revisão visual foi feita no navegador do site autorizado. Não inclua binários/dependências, banco, credenciais, sessões ou screenshots pessoais na distribuição.

## Fechamento

`tools/package-source.py --output-dir /caminho/fora-do-fonte` fecha este fonte uma única vez, após relatório interno identificado como anterior ao fechamento. O relatório externo traz SHA-256 final. Nenhum ZIP da entrega é incluído dentro de outro. Evidências JSON são sanitizadas; fixtures não comprovam produtos/permissões dos fornecedores.
