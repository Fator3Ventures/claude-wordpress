<?php
/**
 * Contrato de copy: o que precisa aparecer e o que não pode voltar.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Texto do pacote inteiro, por arquivo, para a varredura de frase.
 *
 * O bloco `copy_contrato` do `config/site.json` é REMOVIDO antes da busca, e
 * essa é a única isenção: é ali que a frase proibida está DECLARADA como
 * proibida. Sem essa isenção a regra se autorrefuta — o arquivo que proíbe a
 * frase seria a primeira reprovação.
 *
 * @param string $raiz Raiz.
 * @return array<string,string>
 */
function f3b_texto_do_pacote( string $raiz ): array {
	$saida      = array();
	$extensoes  = array( 'php', 'html', 'json', 'md', 'css', 'js', 'mjs', 'txt', 'tsv', 'sh' );

	foreach ( f3b_arquivos( $raiz, $extensoes, f3b_excluidos() ) as $rel ) {
		$texto = (string) file_get_contents( $raiz . '/' . $rel );

		if ( 'config/site.json' === $rel ) {
			$json = json_decode( $texto, true );

			if ( is_array( $json ) ) {
				unset( $json['copy_contrato'] );
				$texto = (string) json_encode( $json, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
			}
		}

		$saida[ $rel ] = $texto;
	}

	return $saida;
}

/**
 * Página publicada de uma `ref`, pelo arquivo de conteúdo.
 *
 * @param string $raiz Raiz.
 * @param string $ref  Referência.
 * @return string|null
 */
function f3b_pagina_por_ref( string $raiz, string $ref ): ?string {
	$arquivo = $raiz . '/content/pages/' . $ref . '.html';

	return is_file( $arquivo ) ? (string) file_get_contents( $arquivo ) : null;
}

/**
 * Frases obrigatórias presentes onde foram declaradas; proibidas em lugar nenhum.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_copy_contrato( string $raiz ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou inválido na raiz varrida' ),
		);
	}

	$contrato = (array) ( $config['copy_contrato'] ?? array() );
	$achados  = array();
	$medidas  = 0;

	foreach ( (array) ( $contrato['devem_aparecer'] ?? array() ) as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}

		$id      = (string) ( $item['id'] ?? '(sem id)' );
		$grafias = array_map( 'strval', (array) ( $item['grafias'] ?? array() ) );
		$ondes   = array_map( 'strval', (array) ( $item['onde'] ?? array() ) );

		if ( array() === $grafias || array() === $ondes ) {
			$achados[] = $id . ': declarado sem grafia ou sem página de destino';
			continue;
		}

		foreach ( $ondes as $onde ) {
			$html = f3b_pagina_por_ref( $raiz, $onde );

			if ( null === $html ) {
				$achados[] = $id . ': página "' . $onde . '" declarada em `onde` e sem arquivo content/pages/' . $onde . '.html';
				continue;
			}

			foreach ( $grafias as $grafia ) {
				$medidas++;

				if ( ! str_contains( $html, $grafia ) ) {
					$achados[] = $id . ': grafia "' . $grafia . '" ausente em ' . $onde;
				}
			}
		}
	}

	foreach ( (array) ( $contrato['nao_podem_voltar'] ?? array() ) as $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}

		$id      = (string) ( $item['id'] ?? '(sem id)' );
		$grafias = array_map( 'strval', (array) ( $item['grafias'] ?? array() ) );

		foreach ( f3b_texto_do_pacote( $raiz ) as $rel => $texto ) {
			$baixo = mb_strtolower( $texto );

			foreach ( $grafias as $grafia ) {
				if ( '' === $grafia ) {
					continue;
				}

				$medidas++;

				if ( str_contains( $baixo, mb_strtolower( $grafia ) ) ) {
					$achados[] = $id . ': "' . $grafia . '" reapareceu em ' . $rel;
				}
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}
