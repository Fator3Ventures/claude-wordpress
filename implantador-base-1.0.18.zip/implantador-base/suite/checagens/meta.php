<?php
/**
 * Cruzamentos da própria suíte: manifesto e mapa de armadilhas.
 *
 * Ambos são calculados dos RÓTULOS EFETIVAMENTE EMITIDOS na rodada — nunca de
 * uma lista escrita à mão, nunca de `check(true)`. Uma suíte que afirma cobrir
 * um requisito por causa de uma linha de tabela é a mesma coisa que uma suíte
 * cega, com documentação melhor.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * DUAS FORMAS DE PISO, e as duas precisam de evidência.
 *
 * A forma antiga é a fixture em disco: uma árvore negativa que reproduz o
 * defeito e uma positiva que preserva o correto. Ela serve a detector de
 * análise estática, e é a única que existia até a 1.0.15.
 *
 * A forma que faltava é a da SONDA FUNCIONAL, cujo caso negativo não é uma
 * árvore de arquivos: é um mutante do próprio pacote, exercitado dentro da
 * sonda. `suite/pisos-em-sonda.tsv` declara quais checagens são dessas, e a
 * declaração NÃO absolve: só vale quando a sonda declarada existe e traz, para
 * aquela checagem, ramo de TETO e ramo de PISO escritos. Sonda cega não os
 * teria, e é isso que separa uma das outras.
 *
 * @param string $suite Diretório da suíte.
 * @param string $nome  Nome da checagem.
 * @return bool
 */
function f3b_tem_piso( string $suite, string $nome ): bool {
	$base = $suite . '/fixtures/' . $nome;

	if ( is_dir( $base . '/negativa' ) && is_dir( $base . '/positiva' ) ) {
		return true;
	}

	return array() === f3b_piso_em_sonda_pendente( $suite, $nome );
}

/**
 * Piso declarado em sonda: o que FALTA para a declaração valer.
 *
 * Devolve lista vazia quando a declaração se sustenta. Fora isso, cada item é o
 * que falta — e é o mesmo texto que o detector do piso da regra imprime.
 *
 * @param string $suite Diretório da suíte.
 * @param string $nome  Nome da checagem.
 * @return array<int,string>
 */
function f3b_piso_em_sonda_pendente( string $suite, string $nome ): array {
	$declaracao = f3b_pisos_em_sonda( $suite );

	if ( ! isset( $declaracao[ $nome ] ) ) {
		return array( 'não está declarada em suite/pisos-em-sonda.tsv nem tem fixture negativa e positiva em disco' );
	}

	$sonda   = $declaracao[ $nome ];
	$caminho = $suite . '/' . $sonda;

	if ( ! is_file( $caminho ) ) {
		return array( 'a sonda declarada não existe: ' . $sonda );
	}

	$fonte  = (string) file_get_contents( $caminho );
	$faltam = array();

	if ( ! str_contains( $fonte, $nome ) ) {
		$faltam[] = $sonda . ' não menciona a checagem ' . $nome . ': declaração que absolve sem medir é pior que nenhuma';
	}

	foreach ( array( 'teto', 'piso' ) as $ramo ) {
		if ( 1 !== preg_match( '/[\'"]' . $ramo . '\b/u', $fonte ) ) {
			$faltam[] = $sonda . ' não tem nenhuma afirmação de ' . $ramo . ': uma sonda sem os dois ramos não provou saber reprovar nada';
		}
	}

	return $faltam;
}

/**
 * A declaração de pisos em sonda, lida do TSV.
 *
 * @param string $suite Diretório da suíte.
 * @return array<string,string> Checagem => caminho da sonda, relativo à suíte.
 */
function f3b_pisos_em_sonda( string $suite ): array {
	$mapa = array();

	foreach ( f3b_tsv( $suite . '/pisos-em-sonda.tsv' ) as $linha ) {
		$nome  = trim( $linha[0] ?? '' );
		$sonda = trim( $linha[1] ?? '' );

		if ( '' !== $nome && '' !== $sonda ) {
			$mapa[ $nome ] = $sonda;
		}
	}

	return $mapa;
}

/**
 * PISO DA REGRA DO PISO: toda declaração de piso em sonda se sustenta.
 *
 * Sem este detector, `suite/pisos-em-sonda.tsv` seria uma linha de tabela capaz
 * de declarar coberta qualquer checagem — exatamente a doença que
 * `armadilhas.mapeadas` existe para impedir, um nível acima.
 *
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_piso_em_sonda_declarado( string $suite ): array {
	$achados = array();
	$medidas = 0;

	foreach ( f3b_pisos_em_sonda( $suite ) as $nome => $sonda ) {
		++$medidas;

		foreach ( f3b_piso_em_sonda_pendente( $suite, $nome ) as $falta ) {
			$achados[] = $nome . ' (' . $sonda . '): ' . $falta;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * AFIRMAÇÃO DE DOCUMENTO conferida contra COMPORTAMENTO MEDIDO.
 *
 * O detector que faltava, e a fresta por onde passaram cinco dos vinte e dois
 * achados da auditoria da 1.0.17: os detectores desta suíte conferem identidade
 * de release e números gerados, e nenhum conferia uma afirmação de
 * COMPORTAMENTO. Três frases de `README.md` e `MANIFESTO.md` eram refutadas pela
 * configuração e pelo código DENTRO DO MESMO ZIP, e nada acusava.
 *
 * Ele não entende prosa, e não precisa: o elo entre a frase e o fato é
 * DECLARADO em `suite/afirmacoes.tsv`, e são dois achados possíveis —
 *
 * - **frase declarada que sumiu do documento**: a afirmação mudou e a amarração
 *   ficou para trás, então a linha da tabela deixou de proteger alguma coisa e
 *   passa a mentir sobre cobertura, que é a doença que `armadilhas.mapeadas`
 *   combate um nível acima;
 * - **fato que não bate com o esperado**: a frase continua no documento e o
 *   pacote faz outra coisa — exatamente os três achados de 1.0.17.
 *
 * A tabela é lida da ÁRVORE VARRIDA, não da suíte que executa: é isso que
 * permite ao piso ter uma fixture com a sua própria declaração e o seu próprio
 * documento.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_afirmacoes( string $raiz ): array {
	$tabela = f3b_tsv( $raiz . '/suite/afirmacoes.tsv' );

	if ( array() === $tabela ) {
		return array(
			'ok'      => false,
			'achados' => array( 'suite/afirmacoes.tsv vazio ou ausente na raiz varrida: sem o elo declarado entre frase e fato, nenhuma afirmação de comportamento é conferida — e foi por essa fresta que passaram cinco dos vinte e dois achados da 1.0.17' ),
			'medidas' => 0,
		);
	}

	$achados = array();
	$medidas = 0;

	foreach ( $tabela as $linha ) {
		$documento = trim( $linha[0] ?? '' );
		$frase     = trim( $linha[1] ?? '' );
		$regra     = trim( $linha[2] ?? '' );
		$argumento = trim( $linha[3] ?? '' );
		$esperado  = strtolower( trim( $linha[4] ?? '' ) );

		if ( '' === $documento || '' === $frase ) {
			continue;
		}

		++$medidas;

		if ( '' === $regra || '' === $argumento || ! in_array( $esperado, array( 'sim', 'nao' ), true ) ) {
			$achados[] = $documento . ': a afirmação "' . f3b_recorte( $frase ) . '" está declarada sem regra, sem argumento ou com esperado fora de {sim,nao} — declaração que não mede nada é pior que declaração nenhuma';
			continue;
		}

		$caminho = $raiz . '/' . $documento;

		if ( ! is_file( $caminho ) ) {
			$achados[] = $documento . ': o documento declarado não existe na raiz varrida, e a afirmação "' . f3b_recorte( $frase ) . '" não tem onde ser conferida';
			continue;
		}

		if ( ! str_contains( (string) file_get_contents( $caminho ), $frase ) ) {
			$achados[] = $documento . ': a frase declarada NÃO está mais no documento — "' . f3b_recorte( $frase ) . '". A amarração ficou para trás da redação: ou a frase voltou a valer e precisa ser reescrita, ou a linha sai da tabela. Amarração órfã afirma cobertura que não existe';
			continue;
		}

		$medicao = f3b_medir_afirmacao( $raiz, $regra, $argumento );

		if ( '' !== $medicao['erro'] ) {
			$achados[] = $documento . ' / "' . f3b_recorte( $frase ) . '": ' . $medicao['erro'];
			continue;
		}

		if ( $medicao['observado'] !== $esperado ) {
			$achados[] = $documento . ' AFIRMA "' . f3b_recorte( $frase ) . '" e o pacote MEDE o contrário: regra ' . $regra
				. ' sobre "' . $argumento . '" esperava "' . $esperado . '" e observou "' . $medicao['observado'] . '" — ' . $medicao['detalhe'];
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Recorte de uma frase para caber na mensagem sem perder a identidade.
 *
 * @param string $frase Frase declarada.
 * @return string
 */
function f3b_recorte( string $frase ): string {
	return mb_strlen( $frase ) > 90 ? mb_substr( $frase, 0, 90 ) . '…' : $frase;
}

/**
 * MEDE o fato que sustenta uma afirmação, pela regra declarada.
 *
 * @param string $raiz      Raiz a varrer.
 * @param string $regra     Nome da regra.
 * @param string $argumento Argumento da regra.
 * @return array{observado:string,detalhe:string,erro:string}
 */
function f3b_medir_afirmacao( string $raiz, string $regra, string $argumento ): array {
	if ( 'config.vazio' === $regra || 'config.igual' === $regra ) {
		$arquivo = $raiz . '/config/site.json';

		if ( ! is_file( $arquivo ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/site.json ausente na raiz varrida' );
		}

		$config = json_decode( (string) file_get_contents( $arquivo ), true );

		if ( ! is_array( $config ) ) {
			return array( 'observado' => '', 'detalhe' => '', 'erro' => 'config/site.json não analisa' );
		}

		if ( 'config.vazio' === $regra ) {
			$valor  = f3b_valor_do_caminho( $config, $argumento );
			$vazio  = null === $valor || '' === $valor || array() === $valor;
			$conta  = is_array( $valor ) ? count( $valor ) : 0;

			return array(
				'observado' => $vazio ? 'sim' : 'nao',
				'detalhe'   => $vazio
					? 'a chave ' . $argumento . ' está vazia ou ausente em config/site.json'
					: 'a chave ' . $argumento . ' está PREENCHIDA em config/site.json' . ( $conta > 0 ? ' com ' . $conta . ' entrada(s)' : ': ' . f3b_recorte( is_scalar( $valor ) ? (string) $valor : (string) json_encode( $valor ) ) ),
				'erro'      => '',
			);
		}

		$partes = explode( '=', $argumento, 2 );
		$valor  = f3b_valor_do_caminho( $config, trim( $partes[0] ) );
		$igual  = is_scalar( $valor ) && (string) $valor === trim( $partes[1] ?? '' );

		return array(
			'observado' => $igual ? 'sim' : 'nao',
			'detalhe'   => 'a chave ' . trim( $partes[0] ) . ' vale "' . ( is_scalar( $valor ) ? (string) $valor : (string) json_encode( $valor ) ) . '" em config/site.json',
			'erro'      => '',
		);
	}

	if ( 'codigo.chamada' === $regra || 'codigo.emite_estado' === $regra ) {
		$onde = array();

		foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
			$onde[ $rel ] = f3b_codigo_php( $raiz . '/' . $rel );
		}

		if ( 'codigo.chamada' === $regra ) {
			foreach ( $onde as $rel => $src ) {
				if ( 1 === preg_match( '/' . str_replace( '/', '\/', $argumento ) . '/u', $src ) ) {
					return array( 'observado' => 'sim', 'detalhe' => 'a expressão casa em ' . $rel, 'erro' => '' );
				}
			}

			return array(
				'observado' => 'nao',
				'detalhe'   => 'a expressão NÃO casa em nenhum .php de includes/ nem de fontes/ — a afirmação descreve um comportamento que o pacote não tem',
				'erro'      => '',
			);
		}

		$partes   = explode( '=', $argumento, 2 );
		$checagem = trim( $partes[0] );
		$estado   = strtoupper( trim( $partes[1] ?? '' ) );
		$estados  = f3b_estados_emitidos_para( $onde, $checagem );

		return array(
			'observado' => in_array( $estado, $estados, true ) ? 'sim' : 'nao',
			'detalhe'   => array() === $estados
				? 'nenhuma emissão da checagem "' . $checagem . '" foi encontrada no pacote: a afirmação promete um item de relatório que não existe'
				: 'a checagem "' . $checagem . '" só é emitida em: ' . implode( ', ', $estados ),
			'erro'      => '',
		);
	}

	return array( 'observado' => '', 'detalhe' => '', 'erro' => 'regra declarada desconhecida: ' . $regra );
}

/**
 * Valor de um caminho pontilhado dentro do config decodificado.
 *
 * @param array<string,mixed> $config   Config.
 * @param string              $caminho  Caminho pontilhado.
 * @return mixed Null quando não existe.
 */
function f3b_valor_do_caminho( array $config, string $caminho ) {
	$atual = $config;

	foreach ( explode( '.', $caminho ) as $parte ) {
		if ( ! is_array( $atual ) || ! array_key_exists( $parte, $atual ) ) {
			return null;
		}

		$atual = $atual[ $parte ];
	}

	return $atual;
}

/**
 * ESTADOS que uma checagem pode fechar, lidos das emissões do pacote.
 *
 * Lê o prefixo de argumentos de cada emissão cujo nome literal é a checagem
 * procurada: `emitir( <estado>, '<nome>', … )` traz o estado antes do nome, e
 * `avaliar()`/`condicional()` trazem os estados implícitos do par que decidem.
 *
 * @param array<string,string> $fontes  Caminho relativo => código PHP.
 * @param string               $checagem Nome da checagem.
 * @return array<int,string> Estados, sem repetição.
 */
function f3b_estados_emitidos_para( array $fontes, string $checagem ): array {
	$estados  = array();
	$fechados = array( 'OK', 'FALHA', 'BLOCKED', 'N/A', 'NA', 'WAIVED', 'WARN' );

	foreach ( $fontes as $src ) {
		$posicao = 0;

		while ( true ) {
			$encontrado = strpos( $src, "'" . $checagem . "'", $posicao );

			if ( false === $encontrado ) {
				break;
			}

			$posicao = $encontrado + 1;
			$inicio  = max( 0, $encontrado - 1200 );
			$antes   = substr( $src, $inicio, $encontrado - $inicio );

			/*
			 * O nome de cada emissora é montado com o parêntese à parte, e não
			 * é estilo: escrito colado, este arquivo conteria a marca que
			 * `estatica.estados_fechados` procura — `saida( '…'` — e o detector
			 * acusaria a própria tabela de nomes como se fosse uma emissão com
			 * estado fora da lista fechada.
			 */
			foreach ( array( 'avaliar', 'condicional', 'emitir', 'emitir_unidade', 'saida' ) as $emissora ) {
				$chamada = $emissora . '(';
				$abre    = strrpos( $antes, $chamada );

				if ( false === $abre ) {
					continue;
				}

				$prefixo = substr( $antes, $abre + strlen( $chamada ) );

				if ( 'avaliar' === $emissora || 'condicional' === $emissora ) {
					$estados['OK']    = true;
					$estados['FALHA'] = true;

					if ( 'condicional' === $emissora ) {
						$estados['N/A'] = true;
					}
				}

				foreach ( $fechados as $fechado ) {
					if ( 1 === preg_match( '/(?:Relatorio::' . ( 'N/A' === $fechado ? 'NA' : $fechado ) . '\b|[\'"]' . preg_quote( $fechado, '/' ) . '[\'"])/', $prefixo ) ) {
						$estados[ 'NA' === $fechado ? 'N/A' : $fechado ] = true;
					}
				}

				break;
			}
		}
	}

	return array_keys( $estados );
}

/**
 * Checagens com piso em disco.
 *
 * @param string $suite Diretório da suíte.
 * @return array<int,string>
 */
function f3b_com_piso( string $suite ): array {
	$saida = array();

	foreach ( glob( $suite . '/fixtures/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
		$nome = basename( $dir );

		if ( f3b_tem_piso( $suite, $nome ) ) {
			$saida[] = $nome;
		}
	}

	sort( $saida );

	return $saida;
}

/**
 * Cruzamento bidirecional entre manifesto e rodada.
 *
 * Dois sentidos, e os dois reprovam:
 *
 * - Requisito aplicável cuja checagem não foi emitida: o manifesto promete
 *   cobertura que a rodada não entregou.
 * - Checagem emitida sem requisito nem armadilha que a justifique: rótulo
 *   órfão, que engorda a contagem sem responder a nada.
 *
 * @param string            $suite    Diretório da suíte.
 * @param array<int,string> $emitidas Nomes emitidos nesta rodada.
 * @return array{ok:bool,achados:array<int,string>,requisitos:int}
 */
function f3b_ck_manifesto_bidirecional( string $suite, array $emitidas ): array {
	$linhas = f3b_tsv( $suite . '/manifesto.tsv' );

	if ( array() === $linhas ) {
		return array(
			'ok'         => false,
			'achados'    => array( 'suite/manifesto.tsv vazio ou ausente' ),
			'requisitos' => 0,
		);
	}

	$achados     = array();
	$cobertas    = array();
	$requisitos  = 0;

	foreach ( $linhas as $n => $linha ) {
		$requisito = trim( $linha[0] ?? '' );
		$checagem  = trim( $linha[1] ?? '' );
		$ambiente  = trim( $linha[2] ?? '' );
		$evidencia = trim( $linha[3] ?? '' );

		if ( '' === $requisito ) {
			continue;
		}

		$requisitos++;

		if ( '' === $checagem ) {
			$achados[] = 'requisito sem checagem: ' . $requisito;
			continue;
		}

		if ( '' === $ambiente || '' === $evidencia ) {
			$achados[] = 'linha ' . ( $n + 1 ) . ' (' . $checagem . '): ambiente ou evidência em branco';
		}

		$cobertas[ $checagem ] = true;

		if ( ! in_array( $checagem, $emitidas, true ) ) {
			$achados[] = 'requisito "' . $requisito . '" aponta para ' . $checagem . ', que a rodada não emitiu';
		}
	}

	$armadilhas = array();

	foreach ( f3b_tsv( $suite . '/armadilhas.tsv' ) as $linha ) {
		$checagem = trim( $linha[1] ?? '' );

		if ( '' !== $checagem && '—' !== $checagem ) {
			$armadilhas[ $checagem ] = true;
		}
	}

	foreach ( $emitidas as $nome ) {
		if ( isset( $cobertas[ $nome ] ) || isset( $armadilhas[ $nome ] ) ) {
			continue;
		}

		$achados[] = 'checagem órfã, sem requisito nem armadilha que a justifique: ' . $nome;
	}

	return array(
		'ok'         => array() === $achados,
		'achados'    => $achados,
		'requisitos' => $requisitos,
	);
}

/**
 * Mapa armadilha → checagem, calculado da rodada.
 *
 * Três resultados possíveis, e eles não são intercambiáveis:
 *
 * - Armadilha mapeada para checagem emitida E com piso em disco: coberta.
 * - Armadilha sem checagem: PENDÊNCIA DECLARADA. Ela aparece no relatório com
 *   o nome, e não some.
 * - Mapeamento cuja checagem não tem piso: BLOCKED, não OK — mapear para uma
 *   checagem que nunca provou saber reprovar é afirmar cobertura sem evidência.
 *
 * @param string            $suite    Diretório da suíte.
 * @param array<int,string> $emitidas Nomes emitidos.
 * @return array{estado:string,mensagem:string}
 */
function f3b_ck_armadilhas_mapeadas( string $suite, array $emitidas ): array {
	$linhas = f3b_tsv( $suite . '/armadilhas.tsv' );

	if ( array() === $linhas ) {
		return array(
			'estado'   => 'FALHA',
			'mensagem' => 'suite/armadilhas.tsv vazio ou ausente: não há mapa de armadilhas para calcular.',
		);
	}

	$cobertas   = array();
	$pendentes  = array();
	$ausentes   = array();
	$sem_piso   = array();

	foreach ( $linhas as $linha ) {
		$armadilha = trim( $linha[0] ?? '' );
		$checagem  = trim( $linha[1] ?? '' );

		if ( '' === $armadilha ) {
			continue;
		}

		if ( '' === $checagem || '—' === $checagem ) {
			$pendentes[] = $armadilha;
			continue;
		}

		if ( ! in_array( $checagem, $emitidas, true ) ) {
			$ausentes[] = $armadilha . ' → ' . $checagem;
			continue;
		}

		if ( ! f3b_tem_piso( $suite, $checagem ) ) {
			$sem_piso[] = $armadilha . ' → ' . $checagem;
			continue;
		}

		$cobertas[] = $armadilha;
	}

	$resumo = sprintf(
		'%d armadilha(s) mapeada(s) com piso, %d pendência(s) declarada(s)',
		count( $cobertas ),
		count( $pendentes )
	);

	if ( array() !== $ausentes ) {
		return array(
			'estado'   => 'FALHA',
			'mensagem' => 'mapeamento para checagem que a rodada não emitiu: ' . f3b_amostra( $ausentes ) . '.',
		);
	}

	if ( array() !== $sem_piso ) {
		return array(
			'estado'   => 'BLOCKED',
			'mensagem' => 'mapeamento sem piso — falta a fixture negativa e a positiva de: ' . f3b_amostra( $sem_piso ) . '.',
		);
	}

	return array(
		'estado'   => 'OK',
		'mensagem' => $resumo . ( array() === $pendentes ? '.' : '; pendências: ' . f3b_amostra( $pendentes, 4 ) . '.' ),
	);
}
