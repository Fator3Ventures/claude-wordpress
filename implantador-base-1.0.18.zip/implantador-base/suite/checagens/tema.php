<?php
/**
 * Checagens do tema. Funções puras sobre uma raiz — a mesma que o piso aponta
 * para a fixture e o runner aponta para o pacote.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Arquivos do tema por extensão, dentro da raiz varrida.
 *
 * @param string            $raiz       Raiz.
 * @param array<int,string> $extensoes  Extensões.
 * @return array<int,string> Caminhos relativos.
 */
function f3b_arquivos_tema( string $raiz, array $extensoes ): array {
	$saida = array();

	foreach ( f3b_arquivos( $raiz, $extensoes, f3b_excluidos() ) as $rel ) {
		if ( str_starts_with( $rel, 'fontes/tema/' ) ) {
			$saida[] = $rel;
		}
	}

	return $saida;
}

/**
 * Markup do tema já resolvido: arquivos `.html` crus e patterns EXECUTADOS.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array<string,string> rótulo => markup.
 */
function f3b_markup_tema( string $raiz, string $suite ): array {
	$saida = array();

	foreach ( f3b_arquivos_tema( $raiz, array( 'html' ) ) as $rel ) {
		$saida[ $rel ] = (string) file_get_contents( $raiz . '/' . $rel );
	}

	foreach ( f3b_arquivos_tema( $raiz, array( 'php' ) ) as $rel ) {
		if ( ! str_contains( $rel, '/patterns/' ) ) {
			continue;
		}

		$linhas = array();
		$codigo = 0;
		exec(
			'php ' . escapeshellarg( $suite . '/lib/render-pattern.php' ) . ' ' . escapeshellarg( $raiz . '/' . $rel ) . ' 2>/dev/null',
			$linhas,
			$codigo
		);

		$saida[ $rel . ' (executado)' ] = 0 === $codigo ? implode( "\n", $linhas ) : '';
	}

	return $saida;
}

/**
 * `theme.json` da raiz, analisado.
 *
 * @param string $raiz Raiz.
 * @return array<string,mixed>|null
 */
function f3b_theme_json( string $raiz ): ?array {
	$arquivo = $raiz . '/fontes/tema/theme.json';

	if ( ! is_file( $arquivo ) ) {
		return null;
	}

	$json = json_decode( (string) file_get_contents( $arquivo ), true );

	return is_array( $json ) ? $json : null;
}

/* -------------------------------------------------------------------------
 * tema.zero_com_unidade
 * ---------------------------------------------------------------------- */

/**
 * Zero sem unidade em valor que vira custom property.
 *
 * `0` cru sai do `theme.json` como `--wp--preset--…: 0` e o `calc()` que o
 * consome quebra sem erro visível. `"0px"` é o valor correto.
 *
 * ESCOPO ESTREITO, declarado: `styles.blocks.*` fica de fora — ali o valor não
 * vira custom property de preset, e proibir zero cru naquele ramo seria a
 * checagem inventando regra que o contrato não tem.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_zero_com_unidade( string $raiz, string $suite ): array {
	$achados = array();
	$json    = f3b_theme_json( $raiz );

	if ( null === $json ) {
		return array(
			'ok'      => false,
			'achados' => array( 'fontes/tema/theme.json ausente ou inválido na raiz varrida' ),
		);
	}

	$anda = static function ( $valor, string $caminho ) use ( &$anda, &$achados ): void {
		if ( is_array( $valor ) ) {
			foreach ( $valor as $chave => $filho ) {
				$anda( $filho, '' === $caminho ? (string) $chave : $caminho . '.' . $chave );
			}

			return;
		}

		if ( str_starts_with( $caminho, 'styles.blocks.' ) ) {
			return;
		}

		$cru = ( is_int( $valor ) || is_float( $valor ) ) && 0 === (int) $valor && ! is_bool( $valor );

		if ( is_string( $valor ) && '0' === trim( $valor ) ) {
			$cru = true;
		}

		if ( $cru ) {
			$achados[] = 'fontes/tema/theme.json ' . $caminho . ' = ' . var_export( $valor, true ) . ' (zero sem unidade)';
		}
	};

	$anda( $json, '' );

	$medidas = 0;

	/* O mesmo zero cru dentro do atributo `style` de um bloco publicado. */
	foreach ( f3b_markup_tema( $raiz, $suite ) as $rotulo => $markup ) {
		$medidas++;

		if ( ! preg_match_all( '/<!--\s*wp:[a-z0-9\/-]+\s*(\{.*?\})\s*\/?-->/s', $markup, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$attrs = json_decode( $m[1], true );

			if ( ! is_array( $attrs ) || ! isset( $attrs['style'] ) || ! is_array( $attrs['style'] ) ) {
				continue;
			}

			$anda_attr = static function ( $valor, string $caminho ) use ( &$anda_attr, &$achados, $rotulo ): void {
				if ( is_array( $valor ) ) {
					foreach ( $valor as $chave => $filho ) {
						$anda_attr( $filho, '' === $caminho ? (string) $chave : $caminho . '.' . $chave );
					}

					return;
				}

				if ( is_bool( $valor ) ) {
					return;
				}

				if ( ( is_int( $valor ) || is_float( $valor ) ) && 0 === (int) $valor ) {
					$achados[] = $rotulo . ' style.' . $caminho . ' = 0 (zero sem unidade)';
					return;
				}

				if ( is_string( $valor ) && '0' === trim( $valor ) ) {
					$achados[] = $rotulo . ' style.' . $caminho . ' = "0" (zero sem unidade)';
				}
			};

			$anda_attr( $attrs['style'], '' );
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas + 1,
	);
}

/* -------------------------------------------------------------------------
 * Presets: declaração e consumo
 * ---------------------------------------------------------------------- */

/**
 * Presets declarados no `theme.json`, como `tipo|slug`.
 *
 * @param array<string,mixed> $json theme.json.
 * @return array<int,string>
 */
function f3b_presets_declarados( array $json ): array {
	$mapa = array(
		'color'       => array( 'settings', 'color', 'palette' ),
		'gradient'    => array( 'settings', 'color', 'gradients' ),
		'spacing'     => array( 'settings', 'spacing', 'spacingSizes' ),
		'font-size'   => array( 'settings', 'typography', 'fontSizes' ),
		'font-family' => array( 'settings', 'typography', 'fontFamilies' ),
		'shadow'      => array( 'settings', 'shadow', 'presets' ),
	);

	$saida = array();

	foreach ( $mapa as $tipo => $caminho ) {
		$no = $json;

		foreach ( $caminho as $passo ) {
			if ( ! is_array( $no ) || ! isset( $no[ $passo ] ) ) {
				$no = null;
				break;
			}

			$no = $no[ $passo ];
		}

		if ( ! is_array( $no ) ) {
			continue;
		}

		foreach ( $no as $preset ) {
			if ( is_array( $preset ) && isset( $preset['slug'] ) ) {
				$saida[] = $tipo . '|' . $preset['slug'];
			}
		}
	}

	return $saida;
}

/**
 * Referências a preset encontradas no tema.
 *
 * Devolve dois conjuntos: as referências EXPLÍCITAS (forma canônica, que
 * autoriza acusar preset inexistente) e o conjunto ampliado com as classes
 * utilitárias (que só serve para provar consumo). A separação existe porque
 * `has-text-color` e `has-background` são classes do núcleo, não presets, e
 * tratá-las como referência produziria acusação falsa.
 *
 * @param string              $raiz  Raiz.
 * @param string              $suite Diretório da suíte.
 * @param array<string,mixed> $json  theme.json.
 * @param array<int,string>   $declarados Presets declarados.
 * @return array{explicitas:array<string,array<int,string>>,consumo:array<string,array<int,string>>}
 */
function f3b_presets_referencias( string $raiz, string $suite, array $json, array $declarados ): array {
	$explicitas = array();
	$consumo    = array();

	$fontes = f3b_markup_tema( $raiz, $suite );

	foreach ( f3b_arquivos_tema( $raiz, array( 'css', 'php', 'svg' ) ) as $rel ) {
		$fontes[ $rel ] = (string) file_get_contents( $raiz . '/' . $rel );
	}

	/* Do próprio theme.json entram só os `styles`: a declaração não é consumo. */
	if ( isset( $json['styles'] ) ) {
		$fontes['fontes/tema/theme.json (styles)'] = (string) wp_suite_json( $json['styles'] );
	}

	$anota = static function ( array &$alvo, string $chave, string $onde ): void {
		$alvo[ $chave ]   = $alvo[ $chave ] ?? array();
		$alvo[ $chave ][] = $onde;
	};

	foreach ( $fontes as $onde => $texto ) {
		if ( preg_match_all( '/var:preset\|([a-z-]+)\|([A-Za-z0-9_-]+)/', $texto, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$anota( $explicitas, $m[1] . '|' . $m[2], $onde );
				$anota( $consumo, $m[1] . '|' . $m[2], $onde );
			}
		}

		if ( preg_match_all( '/var\(\s*--wp--preset--([a-z-]+?)--([A-Za-z0-9_-]+)\s*[,)]/', $texto, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$anota( $explicitas, $m[1] . '|' . $m[2], $onde );
				$anota( $consumo, $m[1] . '|' . $m[2], $onde );
			}
		}

		$atributos = array(
			'color'       => array( 'backgroundColor', 'textColor', 'overlayBackgroundColor', 'overlayTextColor', 'borderColor', 'iconBackgroundColor' ),
			'font-size'   => array( 'fontSize' ),
			'font-family' => array( 'fontFamily' ),
			'gradient'    => array( 'gradient' ),
		);

		foreach ( $atributos as $tipo => $chaves ) {
			foreach ( $chaves as $chave ) {
				if ( preg_match_all( '/"' . $chave . '"\s*:\s*"([A-Za-z0-9_-]+)"/', $texto, $ms ) ) {
					foreach ( $ms[1] as $slug ) {
						$anota( $explicitas, $tipo . '|' . $slug, $onde );
						$anota( $consumo, $tipo . '|' . $slug, $onde );
					}
				}
			}
		}

		/* Classes utilitárias: só provam consumo de preset já declarado. */
		$classes = array(
			'/has-([a-z0-9-]+)-background-color/' => 'color',
			'/has-([a-z0-9-]+)-color/'            => 'color',
			'/has-([a-z0-9-]+)-font-size/'        => 'font-size',
			'/has-([a-z0-9-]+)-font-family/'      => 'font-family',
			'/has-([a-z0-9-]+)-gradient-background/' => 'gradient',
		);

		foreach ( $classes as $re => $tipo ) {
			if ( ! preg_match_all( $re, $texto, $ms ) ) {
				continue;
			}

			foreach ( $ms[1] as $slug ) {
				$chave = $tipo . '|' . $slug;

				if ( in_array( $chave, $declarados, true ) ) {
					$anota( $consumo, $chave, $onde );
				}
			}
		}
	}

	return array(
		'explicitas' => $explicitas,
		'consumo'    => $consumo,
	);
}

/**
 * Serialização JSON estável para varredura de texto.
 *
 * @param mixed $valor Valor.
 * @return string
 */
function wp_suite_json( $valor ): string {
	return (string) json_encode( $valor, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
}

/**
 * Todo preset declarado tem consumidor no tema.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_preset_ocioso( string $raiz, string $suite ): array {
	$json = f3b_theme_json( $raiz );

	if ( null === $json ) {
		return array(
			'ok'      => false,
			'achados' => array( 'fontes/tema/theme.json ausente ou inválido na raiz varrida' ),
		);
	}

	$declarados = f3b_presets_declarados( $json );
	$refs       = f3b_presets_referencias( $raiz, $suite, $json, $declarados );
	$achados    = array();

	foreach ( $declarados as $preset ) {
		if ( ! isset( $refs['consumo'][ $preset ] ) ) {
			$achados[] = $preset . ' declarado e sem consumidor no tema';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $declarados ),
	);
}

/**
 * Nenhuma referência a preset que não existe.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_preset_inexistente( string $raiz, string $suite ): array {
	$json = f3b_theme_json( $raiz );

	if ( null === $json ) {
		return array(
			'ok'      => false,
			'achados' => array( 'fontes/tema/theme.json ausente ou inválido na raiz varrida' ),
		);
	}

	$declarados = f3b_presets_declarados( $json );
	$refs       = f3b_presets_referencias( $raiz, $suite, $json, $declarados );
	$achados    = array();

	foreach ( $refs['explicitas'] as $preset => $ondes ) {
		if ( in_array( $preset, $declarados, true ) ) {
			continue;
		}

		$achados[] = $preset . ' referenciado em ' . f3b_amostra( array_unique( $ondes ), 2 ) . ' e não declarado';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $refs['explicitas'] ),
	);
}

/* -------------------------------------------------------------------------
 * tema.sem_cor_literal
 * ---------------------------------------------------------------------- */

/**
 * Nenhuma cor literal nos arquivos do tema que produzem saída.
 *
 * Cobre `.css`, `.html`, `.php` e `.svg` — INCLUSIVE dentro de SVG inline, que
 * é onde a cor literal costuma se esconder da varredura de CSS.
 *
 * FORA DO ESCOPO, com o motivo declarado: `fontes/tema/CONTRASTE.md` é documentação,
 * não artefato servido. Os hexadecimais existem lá para que a conta de
 * contraste possa ser refeita e conferida; os valores canônicos moram no
 * `theme.json` e nenhum byte daquele arquivo chega ao navegador.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_sem_cor_literal( string $raiz ): array {
	$nomeadas = array(
		'aliceblue', 'antiquewhite', 'aqua', 'aquamarine', 'azure', 'beige', 'bisque', 'black', 'blanchedalmond',
		'blue', 'blueviolet', 'brown', 'burlywood', 'cadetblue', 'chartreuse', 'chocolate', 'coral', 'cornflowerblue',
		'cornsilk', 'crimson', 'cyan', 'darkblue', 'darkcyan', 'darkgoldenrod', 'darkgray', 'darkgreen', 'darkgrey',
		'darkkhaki', 'darkmagenta', 'darkolivegreen', 'darkorange', 'darkorchid', 'darkred', 'darksalmon',
		'darkseagreen', 'darkslateblue', 'darkslategray', 'darkturquoise', 'darkviolet', 'deeppink', 'deepskyblue',
		'dimgray', 'dodgerblue', 'firebrick', 'floralwhite', 'forestgreen', 'fuchsia', 'gainsboro', 'ghostwhite',
		'gold', 'goldenrod', 'gray', 'green', 'greenyellow', 'grey', 'honeydew', 'hotpink', 'indianred', 'indigo',
		'ivory', 'khaki', 'lavender', 'lawngreen', 'lightblue', 'lightcoral', 'lightgreen', 'lightgrey', 'lightpink',
		'lime', 'limegreen', 'linen', 'magenta', 'maroon', 'midnightblue', 'mintcream', 'navy', 'oldlace', 'olive',
		'orange', 'orangered', 'orchid', 'peru', 'pink', 'plum', 'powderblue', 'purple', 'rebeccapurple', 'red',
		'salmon', 'sandybrown', 'seagreen', 'seashell', 'sienna', 'silver', 'skyblue', 'slateblue', 'snow',
		'springgreen', 'steelblue', 'tan', 'teal', 'thistle', 'tomato', 'turquoise', 'violet', 'wheat', 'white',
		'whitesmoke', 'yellow', 'yellowgreen',
	);

	$props = array(
		'color', 'background-color', 'background', 'border-color', 'border', 'border-top-color', 'border-right-color',
		'border-bottom-color', 'border-left-color', 'border-block-end', 'border-block-start', 'border-inline-end',
		'border-inline-start', 'outline', 'outline-color', 'fill', 'stroke', 'stop-color', 'flood-color',
		'lighting-color', 'caret-color', 'accent-color', 'text-decoration-color', 'column-rule-color', 'box-shadow',
		'text-shadow',
	);

	$achados = array();
	$alvos   = f3b_arquivos_tema( $raiz, array( 'css', 'html', 'php', 'svg' ) );

	foreach ( $alvos as $rel ) {
		$texto = (string) file_get_contents( $raiz . '/' . $rel );

		if ( preg_match_all( '/#[0-9a-fA-F]{3,8}(?![0-9A-Za-z_-])/', $texto, $ms, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $ms[0] as $m ) {
				$achados[] = $rel . ':' . ( substr_count( substr( $texto, 0, (int) $m[1] ), "\n" ) + 1 ) . ' hexadecimal ' . $m[0];
			}
		}

		if ( preg_match_all( '/\b(rgba?|hsla?|hwb|lab|lch|oklab|oklch|color-mix)\s*\(/i', $texto, $ms, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $ms[0] as $m ) {
				$achados[] = $rel . ':' . ( substr_count( substr( $texto, 0, (int) $m[1] ), "\n" ) + 1 ) . ' função de cor ' . rtrim( $m[0], '(' );
			}
		}

		$re_prop = '/(?<![A-Za-z-])(' . implode( '|', array_map( static fn( string $p ): string => preg_quote( $p, '/' ), $props ) ) . ')\s*[:=]\s*"?\'?([^;"\'\n{}]+)/i';

		if ( preg_match_all( $re_prop, $texto, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $ms as $m ) {
				$valor = strtolower( trim( $m[2][0] ) );

				foreach ( $nomeadas as $nome ) {
					if ( preg_match( '/(?<![A-Za-z0-9-])' . $nome . '(?![A-Za-z0-9-])/', $valor ) ) {
						$achados[] = $rel . ':' . ( substr_count( substr( $texto, 0, (int) $m[0][1] ), "\n" ) + 1 ) . ' cor nomeada "' . $nome . '" em ' . $m[1][0];
						break;
					}
				}
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * tema.wp_html_declarado
 * ---------------------------------------------------------------------- */

/**
 * Todo `wp:html` do tema consta das exceções declaradas, com motivo.
 *
 * Navegação nunca entra: `wp:html` dentro de um bloco de navegação é achado
 * mesmo que o arquivo esteja na lista.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_wp_html_declarado( string $raiz, string $suite ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou inválido na raiz varrida' ),
		);
	}

	$excecoes = array();

	foreach ( (array) ( $config['tema']['wp_html_excecoes'] ?? array() ) as $entrada ) {
		if ( ! is_array( $entrada ) || ! isset( $entrada['arquivo'] ) ) {
			continue;
		}

		$excecoes[ (string) $entrada['arquivo'] ] = trim( (string) ( $entrada['motivo'] ?? '' ) );
	}

	$achados = array();

	foreach ( f3b_markup_tema( $raiz, $suite ) as $rotulo => $markup ) {
		$rel_tema = preg_replace( '#^fontes/tema/#', '', str_replace( ' (executado)', '', $rotulo ) ) ?? $rotulo;
		$re       = '/<!--\s*(\/?)wp:([a-z0-9\/-]+)\s*(\{.*?\})?\s*(\/?)-->/s';

		if ( ! preg_match_all( $re, $markup, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		$pilha = array();

		foreach ( $ms as $m ) {
			$fechando = '' !== $m[1];
			$bloco    = $m[2];
			$sozinho  = '' !== ( $m[4] ?? '' );

			if ( $fechando ) {
				array_pop( $pilha );
				continue;
			}

			if ( 'html' === $bloco ) {
				if ( in_array( 'navigation', $pilha, true ) ) {
					$achados[] = $rotulo . ': wp:html dentro de wp:navigation — navegação nunca entra';
				} elseif ( ! array_key_exists( $rel_tema, $excecoes ) ) {
					$achados[] = $rotulo . ': wp:html sem declaração em tema.wp_html_excecoes';
				} elseif ( '' === $excecoes[ $rel_tema ] ) {
					$achados[] = $rotulo . ': wp:html declarado sem motivo';
				}
			}

			if ( ! $sozinho ) {
				$pilha[] = $bloco;
			}
		}
	}

	foreach ( $excecoes as $arquivo => $motivo ) {
		if ( '' === $motivo ) {
			$achados[] = 'tema.wp_html_excecoes: ' . $arquivo . ' declarado sem motivo';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( f3b_markup_tema( $raiz, $suite ) ),
	);
}

/* -------------------------------------------------------------------------
 * tema.main_layout_default
 * ---------------------------------------------------------------------- */

/**
 * `main` nunca com `constrained`.
 *
 * `layout: constrained` no `main` mata o `alignfull` de tudo que estiver dentro:
 * a faixa de largura total passa a caber na medida de conteúdo, sem erro nenhum.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_main_layout_default( string $raiz, string $suite ): array {
	$achados   = array();
	$encontrou = false;
	$medidas   = 0;

	foreach ( f3b_markup_tema( $raiz, $suite ) as $rotulo => $markup ) {
		if ( ! preg_match_all( '/<!--\s*wp:group\s*(\{.*?\})\s*-->/s', $markup, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$attrs = json_decode( $m[1], true );

			if ( ! is_array( $attrs ) || 'main' !== ( $attrs['tagName'] ?? '' ) ) {
				continue;
			}

			$encontrou = true;
			$medidas++;
			$tipo      = (string) ( $attrs['layout']['type'] ?? '' );

			if ( 'default' !== $tipo ) {
				$achados[] = $rotulo . ': main com layout "' . ( '' === $tipo ? '(ausente)' : $tipo ) . '"';
			}
		}
	}

	if ( ! $encontrou ) {
		$achados[] = 'nenhum bloco com tagName "main" encontrado no tema — não há o que medir';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * tema.versao_assets
 * ---------------------------------------------------------------------- */

/**
 * Nenhuma constante PHP com o número literal da versão do tema.
 *
 * O caso medido: o `style.css` subiu de versão, a constante ficou para trás, o
 * enqueue publicou o CSS novo com o `?ver=` antigo, e navegador e cache
 * seguiram servindo o arquivo velho. A versão deriva de `wp_get_theme()`.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_versao_assets( string $raiz ): array {
	$style = $raiz . '/fontes/tema/style.css';

	if ( ! is_file( $style ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'fontes/tema/style.css ausente na raiz varrida' ),
		);
	}

	if ( ! preg_match( '/^\s*Version:\s*(\S+)\s*$/mi', (string) file_get_contents( $style ), $m ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'fontes/tema/style.css sem cabeçalho Version: — não existe fonte única da versão' ),
		);
	}

	$versao  = trim( $m[1] );
	$achados = array();

	foreach ( f3b_arquivos_tema( $raiz, array( 'php' ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( preg_match_all( '/(?:define\s*\(\s*[\'"]([A-Za-z0-9_]+)[\'"]\s*,\s*|const\s+([A-Za-z0-9_]+)\s*=\s*)[\'"]([^\'"]+)[\'"]/', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $c ) {
				if ( trim( $c[3] ) !== $versao ) {
					continue;
				}

				$nome      = '' !== $c[1] ? $c[1] : $c[2];
				$achados[] = $rel . ': constante ' . $nome . ' com o número literal ' . $versao;
			}
		}
	}

	$funcoes = $raiz . '/fontes/tema/functions.php';

	if ( ! is_file( $funcoes ) || ! str_contains( f3b_codigo_php( $funcoes ), 'wp_get_theme()' ) ) {
		$achados[] = 'fontes/tema/functions.php não deriva a versão de wp_get_theme()';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( f3b_arquivos_tema( $raiz, array( 'php' ) ) ),
	);
}
