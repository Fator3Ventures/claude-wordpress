<?php
/**
 * Checagens do conteúdo publicado.
 *
 * Conteúdo publicado, aqui, é o que chega ao visitante: `content/`,
 * `fontes/tema/patterns` (executados), `fontes/tema/templates` e `fontes/tema/parts`.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Markup publicado da raiz: conteúdo editorial e markup do tema já resolvido.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array<string,string> rótulo => markup.
 */
function f3b_markup_publicado( string $raiz, string $suite ): array {
	$saida = f3b_markup_tema( $raiz, $suite );

	foreach ( f3b_arquivos( $raiz, array( 'html' ), f3b_excluidos() ) as $rel ) {
		if ( str_starts_with( $rel, 'content/' ) ) {
			$saida[ $rel ] = (string) file_get_contents( $raiz . '/' . $rel );
		}
	}

	ksort( $saida );

	return $saida;
}

/* -------------------------------------------------------------------------
 * conteudo.sem_estilo_avulso
 * ---------------------------------------------------------------------- */

/**
 * O valor é referência a preset?
 *
 * @param string $valor Valor.
 * @return bool
 */
function f3b_valor_de_preset( string $valor ): bool {
	$valor = trim( $valor );

	if ( '' === $valor ) {
		return true;
	}

	if ( preg_match( '/^var:preset\|[a-z-]+\|[A-Za-z0-9_-]+$/', $valor ) ) {
		return true;
	}

	$resto = preg_replace( '/var\(\s*--wp--preset--[a-z-]+--[A-Za-z0-9_-]+\s*\)/', '', $valor ) ?? $valor;

	return '' === trim( (string) preg_replace( '/[\s,\/]+/', '', $resto ) );
}

/**
 * Conteúdo publicado só referencia preset — nenhum valor avulso.
 *
 * O lockdown do `theme.json` fecha a UI do editor, mas não alcança quem grava
 * markup direto. Esta checagem é o que cobre esse caminho: cor, tamanho e
 * espaçamento no conteúdo vêm de `var:preset|…` ou de
 * `var(--wp--preset--…)`, nunca de um literal.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_sem_estilo_avulso( string $raiz, string $suite ): array {
	$achados = array();
	$medidas = 0;

	foreach ( f3b_markup_publicado( $raiz, $suite ) as $rotulo => $markup ) {
		$medidas++;

		if ( preg_match_all( '/\sstyle="([^"]*)"/', $markup, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				foreach ( explode( ';', $m[1] ) as $decl ) {
					if ( '' === trim( $decl ) ) {
						continue;
					}

					list( $prop, $valor ) = array_pad( explode( ':', $decl, 2 ), 2, '' );

					if ( ! f3b_valor_de_preset( (string) $valor ) ) {
						$achados[] = $rotulo . ': estilo inline avulso ' . trim( $prop ) . ':' . trim( (string) $valor );
					}
				}
			}
		}

		if ( ! preg_match_all( '/<!--\s*wp:[a-z0-9\/-]+\s*(\{.*?\})\s*\/?-->/s', $markup, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$attrs = json_decode( $m[1], true );

			if ( ! is_array( $attrs ) || ! isset( $attrs['style'] ) || ! is_array( $attrs['style'] ) ) {
				continue;
			}

			$anda = static function ( $valor, string $caminho ) use ( &$anda, &$achados, $rotulo ): void {
				if ( is_array( $valor ) ) {
					foreach ( $valor as $chave => $filho ) {
						$anda( $filho, '' === $caminho ? (string) $chave : $caminho . '.' . $chave );
					}

					return;
				}

				if ( is_bool( $valor ) || null === $valor ) {
					return;
				}

				/* Fora do escopo de preset: os controles booleanos e de estilo puro. */
				if ( preg_match( '/(textDecoration|fontWeight|fontStyle|textTransform|letterSpacing|lineHeight|style|position)$/', $caminho ) ) {
					return;
				}

				if ( ! f3b_valor_de_preset( (string) $valor ) ) {
					$achados[] = $rotulo . ': atributo de bloco avulso style.' . $caminho . ' = ' . (string) $valor;
				}
			};

			$anda( $attrs['style'], '' );
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * conteudo.headings
 * ---------------------------------------------------------------------- */

/**
 * Níveis de heading, em ordem de documento.
 *
 * Conta as origens reais de heading em tema de blocos: `wp:heading`,
 * `wp:post-title`/`wp:query-title` com `level`, e a tag literal.
 *
 * ARMADILHA MEDIDA: o bloco `wp:heading` já serializa a própria tag `<hN>` logo
 * abaixo do comentário. Contar as duas coisas dobrava todo heading do arquivo,
 * e o template com um H1 correto era acusado de ter dois. Aqui a tag literal só
 * conta quando está FORA da região de um bloco de heading.
 *
 * @param string $markup Markup.
 * @return array<int,int>
 */
function f3b_niveis_heading( string $markup ): array {
	$achados = array();
	$regioes = array();

	$re_bloco = '/<!--\s*wp:(heading|post-title|query-title|site-title)\s*(\{.*?\})?\s*(\/?)-->/s';

	if ( preg_match_all( $re_bloco, $markup, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
		foreach ( $ms as $m ) {
			$tipo  = $m[1][0];
			$attrs = '' !== ( $m[2][0] ?? '' ) ? json_decode( $m[2][0], true ) : array();
			$pos   = (int) $m[0][1];

			$nivel = is_array( $attrs ) && isset( $attrs['level'] ) ? (int) $attrs['level'] : ( 'heading' === $tipo ? 2 : 1 );

			if ( 'site-title' === $tipo ) {
				$nivel = is_array( $attrs ) && isset( $attrs['level'] ) ? (int) $attrs['level'] : 0;
			}

			if ( 'heading' === $tipo ) {
				$fecha = strpos( $markup, '<!-- /wp:heading -->', $pos );
				$regioes[] = array( $pos, false === $fecha ? $pos + strlen( $m[0][0] ) : $fecha + 20 );
			}

			if ( $nivel >= 1 && $nivel <= 6 ) {
				$achados[ $pos ] = $nivel;
			}
		}
	}

	if ( preg_match_all( '/<h([1-6])[\s>]/', $markup, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
		foreach ( $ms as $m ) {
			$pos    = (int) $m[0][1];
			$dentro = false;

			foreach ( $regioes as $faixa ) {
				if ( $pos >= $faixa[0] && $pos < $faixa[1] ) {
					$dentro = true;
					break;
				}
			}

			if ( ! $dentro ) {
				$achados[ $pos ] = (int) $m[1][0];
			}
		}
	}

	ksort( $achados );

	return array_values( $achados );
}

/**
 * Um H1 por template, sem salto de nível, conteúdo começando em H2.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_headings( string $raiz, string $suite ): array {
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos_tema( $raiz, array( 'html' ) ) as $rel ) {
		if ( ! str_contains( $rel, '/templates/' ) ) {
			continue;
		}

		$medidas++;
		$niveis = f3b_niveis_heading( (string) file_get_contents( $raiz . '/' . $rel ) );
		$h1     = count( array_filter( $niveis, static fn( int $n ): bool => 1 === $n ) );

		if ( 1 !== $h1 ) {
			$achados[] = $rel . ': ' . $h1 . ' H1 no template (a regra é exatamente um)';
		}
	}

	foreach ( f3b_arquivos( $raiz, array( 'html' ), f3b_excluidos() ) as $rel ) {
		if ( ! str_starts_with( $rel, 'content/' ) ) {
			continue;
		}

		$medidas++;
		$niveis = f3b_niveis_heading( (string) file_get_contents( $raiz . '/' . $rel ) );

		if ( array() === $niveis ) {
			$achados[] = $rel . ': nenhum heading no conteúdo';
			continue;
		}

		if ( in_array( 1, $niveis, true ) ) {
			$achados[] = $rel . ': H1 no conteúdo (o H1 vem do template)';
		}

		if ( 2 !== $niveis[0] ) {
			$achados[] = $rel . ': conteúdo começa em H' . $niveis[0] . ' e deveria começar em H2';
		}

		$anterior = $niveis[0];

		foreach ( array_slice( $niveis, 1 ) as $nivel ) {
			if ( $nivel > $anterior + 1 ) {
				$achados[] = $rel . ': salto de nível H' . $anterior . ' → H' . $nivel;
			}

			$anterior = $nivel;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * conteudo.demonstrativo · conteudo.marca_demonstrativa
 * ---------------------------------------------------------------------- */

/**
 * Censo do conteúdo demonstrativo: o que a configuração declara e o que o disco diz.
 *
 * FONTE ÚNICA das duas checagens abaixo. A marca é montada do prefixo técnico
 * DECLARADO, nunca de um literal: este pacote é template de criação de sites, e
 * uma marca literal aqui seria a marca do template sobrevivendo dentro do site
 * do cliente.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{declarado:bool,ambiente:string,marca:string,com_marca:array<int,string>,sem_marca:array<int,string>,total:int}
 */
function f3b_censo_demonstrativo( string $raiz ): array {
	$config = f3b_config( $raiz ) ?? array();

	$prefixo = trim( (string) ( $config['site']['prefixo_tecnico'] ?? '' ) );
	$marca   = '' !== $prefixo ? $prefixo . ':conteudo-demonstrativo' : '';

	$com_marca = array();
	$sem_marca = array();

	foreach ( f3b_arquivos( $raiz, array( 'html' ), f3b_excluidos() ) as $rel ) {
		if ( ! str_starts_with( $rel, 'content/' ) ) {
			continue;
		}

		$texto = (string) file_get_contents( $raiz . '/' . $rel );

		if ( '' !== $marca && str_contains( $texto, $marca ) ) {
			$com_marca[] = $rel;
			continue;
		}

		$sem_marca[] = $rel;
	}

	return array(
		'declarado' => (bool) ( $config['conteudo']['demonstrativo'] ?? false ),
		'ambiente'  => (string) ( $config['ambiente']['tipo'] ?? '' ),
		'marca'     => $marca,
		'com_marca' => $com_marca,
		'sem_marca' => $sem_marca,
		'total'     => count( $com_marca ) + count( $sem_marca ),
	);
}

/**
 * Conteúdo do template ainda declarado, com o ambiente declarado como produção.
 *
 * O USO CORRETO DE WARN, e ele existe em oposição às nove emissões que a 1.0.14
 * gastou em avisos sem achado. Aqui há achado: `conteudo.demonstrativo = true`
 * diz que as páginas ainda são as do template — a prosa do método, escrita para
 * documentar o próprio método — e `ambiente.tipo = "producao"` diz que o
 * destino é um site de produção. Publicar esse par põe no ar, com o endereço do
 * cliente, um site que fala sobre outra coisa. Não é FALHA porque o pacote está
 * íntegro e a decisão é do projeto; é aviso porque o resultado, se ninguém
 * agir, é um site de cliente com o texto errado.
 *
 * O ramo silencioso é igualmente medido: conteúdo demonstrativo declarado fora
 * de produção é o estado normal deste template, e conteúdo já substituído
 * (`demonstrativo = false`) fecha OK nomeando quantos arquivos foram medidos.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{ok:bool,achados:array<int,string>,medidas:int,estado:string,motivo:string}
 */
function f3b_ck_conteudo_demonstrativo( string $raiz ): array {
	$censo = f3b_censo_demonstrativo( $raiz );

	if ( '' === $censo['marca'] ) {
		return array(
			'ok'      => false,
			'achados' => array( 'site.prefixo_tecnico não está declarado, e sem ele não existe marca de conteúdo demonstrativo a procurar' ),
			'medidas' => $censo['total'],
			'estado'  => 'WARN',
			'motivo'  => 'site.prefixo_tecnico não está declarado, e sem ele não existe marca de conteúdo demonstrativo a procurar.',
		);
	}

	if ( $censo['declarado'] && 'producao' === $censo['ambiente'] ) {
		return array(
			'ok'      => false,
			'achados' => $censo['com_marca'],
			'medidas' => $censo['total'],
			'estado'  => 'WARN',
			'motivo'  => sprintf(
				'conteudo.demonstrativo = true e ambiente.tipo = "producao": %d arquivo(s) de conteúdo continuam sendo os do TEMPLATE e iriam ao ar como o site — %s. '
					. 'O site demonstrativo fica no pacote de propósito, como padrão funcionante que o agente copia; publicá-lo como site de cliente põe a prosa do método no ar '
					. 'com o endereço de outra pessoa. A saída está em TEMPLATE.md: substituir o conteúdo e desligar conteudo.demonstrativo — os dois no mesmo passo.',
				count( $censo['com_marca'] ),
				array() === $censo['com_marca'] ? 'nenhum arquivo carrega a marca' : implode( ', ', $censo['com_marca'] )
			),
		);
	}

	if ( $censo['declarado'] ) {
		return array(
			'ok'      => true,
			'achados' => array(),
			'medidas' => $censo['total'],
			'estado'  => 'OK',
			'motivo'  => sprintf(
				'conteudo.demonstrativo = true e ambiente.tipo = "%s", que não é produção: o conteúdo do template continua sendo o conteúdo, e é assim que ele deve ficar enquanto o site não for de cliente. '
					. '%d arquivo(s) de content/ medidos, %d com a marca.',
				'' !== $censo['ambiente'] ? $censo['ambiente'] : '(não declarado)',
				$censo['total'],
				count( $censo['com_marca'] )
			),
		);
	}

	return array(
		'ok'      => true,
		'achados' => array(),
		'medidas' => $censo['total'],
		'estado'  => 'OK',
		'motivo'  => sprintf(
			'conteudo.demonstrativo = false: o conteúdo declarado é o deste site, não o do template. %d arquivo(s) de content/ medidos, e nenhum deles é do template pela marca declarada.',
			$censo['total']
		),
	);
}

/**
 * A declaração e o disco dizem a mesma coisa sobre CADA arquivo.
 *
 * A outra metade da regra, e a que impede a saída barata: desligar
 * `conteudo.demonstrativo` sem trocar o conteúdo cala o aviso e deixa o site do
 * template no ar afirmando ser o do cliente. Aqui isso é achado, arquivo por
 * arquivo. O ramo inverso também é: com a chave ligada, arquivo de `content/`
 * SEM a marca não diz a quem o abre que é substituível, e a marcação incompleta
 * é uma marcação em que não se pode confiar.
 *
 * @param string $raiz Raiz do pacote.
 * @return array{ok:bool,achados:array<int,string>,medidas:int,estado:string,motivo:string}
 */
function f3b_ck_marca_demonstrativa( string $raiz ): array {
	$censo   = f3b_censo_demonstrativo( $raiz );
	$achados = array();

	if ( '' === $censo['marca'] ) {
		$achados[] = 'site.prefixo_tecnico não está declarado, e sem ele a marca não pode ser montada';
	} elseif ( $censo['declarado'] ) {
		foreach ( $censo['sem_marca'] as $rel ) {
			$achados[] = $rel . ': conteudo.demonstrativo = true e o arquivo NÃO abre com a marca "' . $censo['marca']
				. '" — quem abrir este arquivo não tem como saber que ele é do template e substituível';
		}
	} else {
		foreach ( $censo['com_marca'] as $rel ) {
			$achados[] = $rel . ': conteudo.demonstrativo = false e o arquivo ainda abre com a marca "' . $censo['marca']
				. '" — a configuração afirma que este conteúdo é deste site e o arquivo afirma que é do template; uma das duas está mentindo';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $censo['total'],
		'estado'  => array() === $achados ? 'OK' : 'WARN',
		'motivo'  => array() === $achados
			? sprintf(
				'a declaração e o disco dizem a mesma coisa em %d arquivo(s) de content/: com conteudo.demonstrativo = %s, %d arquivo(s) carregam a marca declarada e %d não.',
				$censo['total'],
				$censo['declarado'] ? 'true' : 'false',
				count( $censo['com_marca'] ),
				count( $censo['sem_marca'] )
			)
			: sprintf(
				'%d divergência(s) entre conteudo.demonstrativo e a marca no arquivo: %s',
				count( $achados ),
				f3b_amostra( $achados, 4 )
			),
	);
}
