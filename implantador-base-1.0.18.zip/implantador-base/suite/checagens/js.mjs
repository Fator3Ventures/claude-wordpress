/**
 * Sonda de JavaScript. Roda sob o Node de verdade e devolve JSON.
 *
 * Dois modos:
 *
 * - `lint <raiz>`: `node --check` em todo `.js`/`.mjs` da raiz. Analisar
 *   JavaScript com expressão regular de PHP seria inferência disfarçada de
 *   medição; quem analisa é o próprio motor.
 * - `extrator <raiz>`: exercita as funções PURAS de
 *   `includes/assets/implantador.js` — as mesmas do arquivo servido, extraídas
 *   dele em tempo de execução, nunca copiadas. A armadilha medida é que a
 *   resposta real de um erro fatal é "HTML + JSON": a página de erro do
 *   WordPress já saiu quando o `shutdown` roda, e o objeto está no FIM do corpo.
 *
 * Esta sonda nunca imprime estado nem conta: quem imprime e conta é `estado()`,
 * no PHP, em um lugar só.
 */

import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, extname } from 'node:path';
import { execFileSync } from 'node:child_process';

const EXCLUIDOS = [ 'suite/fixtures/', 'dist/' ];

function arquivos( raiz, extensoes ) {
	const saida = [];

	function andar( dir ) {
		let itens;

		try {
			itens = readdirSync( dir );
		} catch {
			return;
		}

		for ( const item of itens.sort() ) {
			const caminho = join( dir, item );
			const rel = relative( raiz, caminho ).split( '\\' ).join( '/' );

			if ( EXCLUIDOS.some( ( p ) => rel.startsWith( p ) ) ) {
				continue;
			}

			const st = statSync( caminho );

			if ( st.isDirectory() ) {
				andar( caminho );
				continue;
			}

			if ( extensoes.includes( extname( item ).toLowerCase() ) ) {
				saida.push( rel );
			}
		}
	}

	andar( raiz );

	return saida.sort();
}

function lint( raiz ) {
	const achados = [];
	const alvos = arquivos( raiz, [ '.js', '.mjs' ] );

	for ( const rel of alvos ) {
		try {
			execFileSync( process.execPath, [ '--check', join( raiz, rel ) ], { stdio: [ 'ignore', 'ignore', 'pipe' ] } );
		} catch ( e ) {
			const detalhe = String( e.stderr || e.message ).split( '\n' ).filter( Boolean ).slice( 0, 3 ).join( ' | ' );
			achados.push( rel + ': ' + detalhe );
		}
	}

	return { achados, medidas: alvos.length };
}

/**
 * Extrai as duas funções puras do arquivo REAL e as exercita.
 *
 * Teto e piso na mesma sonda: o que precisa achar, acha; o que precisa devolver
 * `null`, devolve — em vez de fingir sucesso sobre um corpo truncado.
 */
function extrator( raiz ) {
	const alvo = join( raiz, 'includes/assets/implantador.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'includes/assets/implantador.js ausente na raiz varrida' ] };
	}

	const inicioTentar = fonte.indexOf( '\tfunction tentarAnalisar(' );
	const fimTentar = fonte.indexOf( '\t/**', inicioTentar );
	const inicioExtrair = fonte.indexOf( '\tfunction extrairJson(' );
	const fimExtrair = fonte.indexOf( '\t/**', inicioExtrair );

	if ( inicioTentar < 0 || inicioExtrair < 0 ) {
		return { achados: [ 'as funções puras não foram encontradas no arquivo real (contrato de extração quebrado)' ] };
	}

	const codigo =
		'let sentinela = "";\n' +
		fonte.slice( inicioTentar, fimTentar ) + '\n' +
		fonte.slice( inicioExtrair, fimExtrair ) + '\n' +
		'return { extrairJson, definir: ( s ) => { sentinela = s; } };';

	let extrairJson;
	let definir;

	try {
		( { extrairJson, definir } = new Function( codigo )() );
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	const SENT = '<<<F3BASE-JSON>>>';
	const jsonOk = '{"ok":true,"lote":3,"estado":"OK"}';
	const paginaDeErro =
		'<!DOCTYPE html><html><body><h1>Erro crítico { do WordPress }</h1>' +
		'<p>{"isto":"nao e a resposta"}</p></body></html>' +
		'\n' + SENT + '\n' + '{"ok":false,"fatal":{"linha":1624}}';

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	definir( SENT );
	afirmar( extrairJson( SENT + '\n' + jsonOk )?.lote === 3, 'teto: resposta limpa com sentinela não foi lida' );
	afirmar( extrairJson( paginaDeErro )?.fatal?.linha === 1624, 'teto: HTML+JSON — não achou o objeto no FIM do corpo' );

	definir( '' );
	afirmar( extrairJson( paginaDeErro )?.fatal?.linha === 1624, 'teto: sem sentinela, a varredura de trás para frente falhou' );

	definir( SENT );
	afirmar( extrairJson( '<!DOCTYPE html><html><body>Sem JSON nenhum</body></html>' ) === null, 'piso: corpo sem JSON não devolveu null' );
	afirmar( extrairJson( SENT + '\n{"quebrado": ' ) === null, 'piso: JSON truncado depois da sentinela fingiu sucesso' );
	afirmar( extrairJson( '[1,2,3]' ) === null, 'piso: array no corpo passou por objeto de resposta' );

	return { achados };
}

/**
 * Extrai UMA função pura do arquivo real, pelo contrato de fatiamento.
 *
 * O contrato é o mesmo do extrator: a função mora a um nível de indentação e é
 * seguida por um bloco `/**`. Copiar o corpo para dentro desta sonda provaria
 * que a cópia funciona, não que o cliente funciona.
 */
function fatiar( fonte, nome ) {
	const inicio = fonte.indexOf( '\tfunction ' + nome + '(' );

	if ( inicio < 0 ) {
		return null;
	}

	const fim = fonte.indexOf( '\t/**', inicio );

	return fonte.slice( inicio, fim < 0 ? fonte.length : fim );
}

/**
 * As DECISÕES do cliente, exercitadas contra a execução que reprovou.
 *
 * Alimenta a checagem `js.decisoes_do_cliente`, cujo piso mora AQUI e não numa
 * fixture em disco: o caso negativo destas regras é um mutante do próprio
 * cliente, não uma árvore de arquivos. É por isso que ela está declarada em
 * `suite/pisos-em-sonda.tsv`, e é `estatica.piso_em_sonda_declarado` que confere
 * que esta sonda de fato traz os dois ramos.
 *
 * O caso medido: o operador executou, deu erro, executou de novo, e a tela
 * entrou em laço — 163 linhas idênticas de rejeição de lock em 90 segundos,
 * `Etapa 94 de 40` na barra, `estado da aplicação:` vazio no rodapé e um
 * encerramento dizendo "163 BLOCKED" ao lado de "BLOCKED: nenhum".
 *
 * As quatro regras que nasceram daí têm teto e piso aqui, e o laço é SIMULADO:
 * a sonda alimenta a decisão de avanço com a resposta real de rejeição de lock
 * e conta quantas requisições o cliente faria.
 */
function cliente( raiz ) {
	const alvo = join( raiz, 'includes/assets/implantador.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'includes/assets/implantador.js ausente na raiz varrida' ] };
	}

	const nomes = [ 'nomeDaLinha', 'dentroDoPlano', 'planoAvancou', 'proximoLote', 'rejeicaoDeLock', 'fechoDaAplicacao' ];
	const pedacos = [];

	for ( const nome of nomes ) {
		const corpo = fatiar( fonte, nome );

		if ( ! corpo ) {
			return { achados: [ 'a função pura ' + nome + '() não foi encontrada no arquivo real (contrato de extração quebrado)' ] };
		}

		pedacos.push( corpo );
	}

	let api;

	try {
		api = new Function( pedacos.join( '\n' ) + '\nreturn { ' + nomes.join( ', ' ) + ' };' )();
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	/* Estados de aplicação aceitos, como o servidor os declara para a tela. */
	const FECHADOS_CLIENTE = [ 'PRONTO', 'EXECUTANDO', 'SUCESSO_APLICACAO', 'FALHA_PARCIAL', 'FALHA', 'REVERTIDO', 'BLOCKED' ];

	/* A resposta REAL da rejeição de lock, como o servidor a monta. */
	const rejeicao = {
		ok: false,
		concluido: true,
		parou: true,
		lote: 0,
		etapa: 'lote',
		rotulo: 'lote.lock_ocupado',
		estado: 'BLOCKED',
		aplicacao: 'BLOCKED',
		motivo: 'execução concorrente rejeitada…',
		lock: { dono: 'exec6890', idade: 38, ttl: 90, abandonado_em: 1756000000, abandonado_as: '2026-08-31 21:31:29' }
	};

	/* ---------- 1. o laço de 163 requisições não pode existir ---------- */

	const TOTAL = 40;
	let indice = 0;
	let requisicoes = 1;
	let passo = api.proximoLote( rejeicao, indice, TOTAL );

	while ( passo.enviar && requisicoes < 500 ) {
		indice = passo.indice;
		requisicoes++;
		passo = api.proximoLote( rejeicao, indice, TOTAL );
	}

	afirmar( requisicoes === 1, 'piso do laço: a rejeição de lock produziu ' + String( requisicoes ) + ' requisições; ela não é resultado de unidade nenhuma e tem de parar na PRIMEIRA' );
	afirmar( passo.parada === 'plano-nao-avancou', 'piso do laço: a parada não foi nomeada como plano-não-avançou, e sim "' + String( passo.parada ) + '"' );
	afirmar( indice + 1 <= TOTAL, 'piso do contador: a etapa visível chegou a ' + String( indice + 1 ) + ' com total ' + String( TOTAL ) + ' — Etapa N de M com N maior que M é o contador contando requisição, não unidade' );

	/* ---------- 1b. o payload EXATO da 1.0.15, sem nenhum campo novo ---------- */

	/*
	 * ESTA É A PROVA QUE IMPORTA: o cliente tem de parar sozinho, mesmo contra
	 * um servidor que não manda `parou`, `concluido`, `lote`, `rotulo` nem
	 * `aplicacao` — que era exatamente a resposta da 1.0.15. Um piso que só
	 * exercitasse o payload novo estaria medindo a correção do servidor duas
	 * vezes e a do cliente nenhuma.
	 */
	const rejeicao1015 = { ok: false, estado: 'BLOCKED', motivo: 'execução concorrente rejeitada: o lock pertence a exec6890, com heartbeat há 38 segundos (TTL 90s).' };

	let indiceVelho = 0;
	let requisicoesVelhas = 1;
	let passoVelho = api.proximoLote( rejeicao1015, indiceVelho, TOTAL );

	while ( passoVelho.enviar && requisicoesVelhas < 500 ) {
		indiceVelho = passoVelho.indice;
		requisicoesVelhas++;
		passoVelho = api.proximoLote( rejeicao1015, indiceVelho, TOTAL );
	}

	afirmar( requisicoesVelhas === 1, 'piso do laço da 1.0.15: contra a resposta antiga o cliente fez ' + String( requisicoesVelhas ) + ' requisições; ele tem de parar sozinho, sem depender de o servidor mandar campo novo' );
	afirmar( indiceVelho + 1 <= TOTAL, 'piso do contador da 1.0.15: a etapa visível chegou a ' + String( indiceVelho + 1 ) + ' com total ' + String( TOTAL ) );
	afirmar( api.nomeDaLinha( String( rejeicao1015.estado ), rejeicao1015.rotulo, 'lote.linha_sem_nome' ) !== '', 'piso do nome da 1.0.15: a resposta antiga não traz rótulo e a linha saiu anônima' );
	afirmar( api.fechoDaAplicacao( rejeicao1015, FECHADOS_CLIENTE, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho da 1.0.15: a resposta antiga não traz estado da aplicação e o rodapé fechou vazio' );

	/* ---------- 2. teto: a resposta de unidade AVANÇA ---------- */

	const unidade = { ok: true, concluido: false, lote: 7, total: TOTAL, estado: 'OK', rotulo: 'preflight', aplicacao: 'EXECUTANDO' };
	const avanco = api.proximoLote( unidade, 7, TOTAL );

	afirmar( avanco.enviar === true && avanco.indice === 8, 'teto do avanço: resposta de unidade que rodou tinha de avançar para o lote seguinte' );
	afirmar( api.planoAvancou( unidade, 7 ) === true, 'teto do avanço: planoAvancou() não reconheceu a resposta da própria unidade' );

	/* BLOCKED de UNIDADE continua avançando: a regra da 1.0.13 não foi enfraquecida. */
	const bloqueada = { ok: false, concluido: false, lote: 7, total: TOTAL, estado: 'BLOCKED', rotulo: 'plugins.mcp', aplicacao: 'EXECUTANDO' };
	afirmar( api.proximoLote( bloqueada, 7, TOTAL ).enviar === true, 'teto do BLOCKED: unidade que MEDIU pré-condição ausente não pode parar a execução inteira — a regra de 1.0.13 continua valendo' );

	/* Resposta sobre OUTRO lote não avança: foi assim que o contador se soltou do plano. */
	afirmar( api.planoAvancou( { concluido: false, lote: 3 }, 7 ) === false, 'piso do avanço: resposta sobre outro lote foi tratada como avanço' );
	afirmar( api.planoAvancou( { concluido: false }, 7 ) === false, 'piso do avanço: resposta sem lote foi tratada como avanço' );
	afirmar( api.planoAvancou( null, 0 ) === false, 'piso do avanço: resposta nula foi tratada como avanço' );

	/* ---------- 3. a guarda de índice ---------- */

	afirmar( api.dentroDoPlano( 0, TOTAL ) === true, 'teto da guarda: o primeiro lote cabe no plano' );
	afirmar( api.dentroDoPlano( TOTAL - 1, TOTAL ) === true, 'teto da guarda: o último lote cabe no plano' );
	afirmar( api.dentroDoPlano( TOTAL, TOTAL ) === false, 'piso da guarda: índice igual ao total não existe no plano' );
	afirmar( api.dentroDoPlano( 93, TOTAL ) === false, 'piso da guarda: o índice 93 com 40 unidades é o Etapa 94 de 40 da tela' );
	afirmar( api.dentroDoPlano( -1, TOTAL ) === false, 'piso da guarda: índice negativo passou' );
	afirmar( api.proximoLote( { concluido: false, lote: TOTAL - 1 }, TOTAL - 1, TOTAL ).enviar === false, 'piso da guarda: o avanço depois da última unidade tinha de parar' );

	/* ---------- 4. rejeição de lock reconhecida com os quatro fatos ---------- */

	const lock = api.rejeicaoDeLock( rejeicao );

	afirmar( lock !== null, 'teto do lock: a rejeição não foi reconhecida' );
	afirmar( lock && lock.dono === 'exec6890', 'teto do lock: o dono não saiu na linha' );
	afirmar( lock && lock.idade === '38', 'teto do lock: a idade do heartbeat não saiu na linha' );
	afirmar( lock && lock.ttl === '90', 'teto do lock: o TTL não saiu na linha' );
	afirmar( lock && lock.abandonadoAs === '2026-08-31 21:31:29', 'teto do lock: o HORÁRIO em que o lock passa a ser abandonado não saiu na linha, e é ele que responde "quanto esperar"' );
	afirmar( api.rejeicaoDeLock( unidade ) === null, 'piso do lock: resposta de unidade comum foi lida como rejeição de lock' );
	afirmar( api.rejeicaoDeLock( null ) === null, 'piso do lock: resposta nula foi lida como rejeição de lock' );

	/* ---------- 5. linha que não fecha OK é NOMEADA ---------- */

	afirmar( api.nomeDaLinha( 'BLOCKED', '', 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: linha BLOCKED sem rótulo ficou anônima — foi assim que "163 BLOCKED" saiu ao lado de "BLOCKED: nenhum"' );
	afirmar( api.nomeDaLinha( 'FALHA', null, 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: linha FALHA sem rótulo ficou anônima' );
	afirmar( api.nomeDaLinha( 'WARN', '   ', 'lote.linha_sem_nome' ) === 'lote.linha_sem_nome', 'piso do nome: rótulo só de espaço passou por nome' );
	afirmar( api.nomeDaLinha( 'BLOCKED', 'lote.lock_ocupado', 'lote.linha_sem_nome' ) === 'lote.lock_ocupado', 'teto do nome: o rótulo do servidor foi substituído pelo de reserva' );
	afirmar( api.nomeDaLinha( 'OK', '', 'lote.linha_sem_nome' ) === '', 'teto do nome: OK sem rótulo continua resumido, por desenho' );

	/*
	 * E a contagem por estado não pode divergir da lista de nomes: com a linha
	 * nomeada, uma contagem de N linhas BLOCKED tem pelo menos um nome.
	 */
	const renderizadas = {};
	const nomesRenderizados = {};

	for ( let i = 0; i < 163; i++ ) {
		const estado = 'BLOCKED';
		renderizadas[ estado ] = ( renderizadas[ estado ] || 0 ) + 1;

		if ( ! nomesRenderizados[ estado ] ) {
			nomesRenderizados[ estado ] = [];
		}

		const nome = api.nomeDaLinha( estado, '', 'lote.linha_sem_nome' );

		if ( nome !== '' && nomesRenderizados[ estado ].indexOf( nome ) === -1 ) {
			nomesRenderizados[ estado ].push( nome );
		}
	}

	afirmar(
		renderizadas.BLOCKED > 0 && nomesRenderizados.BLOCKED.length > 0,
		'piso da contagem-com-nomes: ' + String( renderizadas.BLOCKED ) + ' linha(s) BLOCKED e ' + String( nomesRenderizados.BLOCKED.length ) + ' nome(s) — o mesmo escopo se contradizendo em duas frases seguidas'
	);

	/* ---------- 6. o rodapé nunca fecha vazio ---------- */

	const FECHADOS = FECHADOS_CLIENTE;

	afirmar( api.fechoDaAplicacao( { aplicacao: 'SUCESSO_APLICACAO' }, FECHADOS, 'BLOCKED' ) === 'SUCESSO_APLICACAO', 'teto do fecho: o estado que o servidor mandou não foi impresso' );
	afirmar( api.fechoDaAplicacao( rejeicao, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'teto do fecho: execução que nunca adquiriu o lock tinha de fechar BLOCKED' );
	afirmar( api.fechoDaAplicacao( {}, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: resposta sem estado da aplicação fechou vazio, e vazio não é estado fechado' );
	afirmar( api.fechoDaAplicacao( { aplicacao: '' }, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: estado vazio foi impresso como se fosse fechado' );
	afirmar( api.fechoDaAplicacao( null, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: sem resposta nenhuma o rodapé fechou vazio' );
	afirmar( api.fechoDaAplicacao( { aplicacao: 'INVENTADO' }, FECHADOS, 'BLOCKED' ) === 'BLOCKED', 'piso do fecho: estado fora da lista declarada passou por fechado' );
	afirmar( FECHADOS.indexOf( api.fechoDaAplicacao( { aplicacao: 'QUALQUER' }, FECHADOS, 'BLOCKED' ) ) !== -1, 'piso do fecho: o fecho de reserva não é um estado fechado' );

	return { achados };
}

/**
 * O CORTE DO CLIENTE DE LEADS, na unidade que o servidor publica.
 *
 * Alimenta a checagem `js.limite_do_cliente`, cujo piso mora AQUI: o caso
 * negativo é um mutante do próprio cliente — o corte por unidade UTF-16 —, e
 * não uma árvore de arquivos. Declarada em `suite/pisos-em-sonda.tsv`.
 *
 * O defeito medido na 1.0.17: o servidor contava BYTES (`strlen`) e o cliente
 * contava unidades UTF-16 (`texto.length`), com o MESMO número publicado por
 * `limites_publicos()`. Em português, com acentuação, o navegador aprovava e o
 * servidor devolvia 400 — e a recusa é dura, nunca truncamento em silêncio.
 * Os dois lados agora contam CARACTERES, e é isso que esta sonda mede.
 */
function limiteDoCliente( raiz ) {
	const alvo = join( raiz, 'fontes/site-core/assets/f3base-leads.js' );
	const achados = [];
	let fonte;

	try {
		fonte = readFileSync( alvo, 'utf8' );
	} catch {
		return { achados: [ 'fontes/site-core/assets/f3base-leads.js ausente na raiz varrida' ] };
	}

	const nomes = [ 'caracteres', 'limitar' ];
	const pedacos = [];

	for ( const nome of nomes ) {
		const corpo = fatiar( fonte, nome );

		if ( ! corpo ) {
			return { achados: [ 'a função pura ' + nome + '() não foi encontrada no arquivo real (contrato de extração quebrado)' ] };
		}

		pedacos.push( corpo );
	}

	let api;

	try {
		api = new Function( 'LIMITES', pedacos.join( '\n' ) + '\nreturn { ' + nomes.join( ', ' ) + ' };' )( { nome: 120, mensagem: 2000 } );
	} catch ( e ) {
		return { achados: [ 'as funções puras não avaliaram: ' + String( e.message ) ] };
	}

	function afirmar( ok, nome ) {
		if ( ! ok ) {
			achados.push( nome );
		}
	}

	/* Um nome de 120 CARACTERES acentuados: o caso que o servidor recusava. */
	const acentuado = 'ção'.repeat( 40 );

	/* PISO: a sonda reproduz o defeito? Em bytes o mesmo texto EXCEDE o limite. */
	afirmar(
		Buffer.byteLength( acentuado, 'utf8' ) > 120,
		'piso: o texto acentuado no limite não excede 120 bytes, e sem isso a divergência de unidade não é reproduzível aqui'
	);

	afirmar(
		api.caracteres( acentuado ).length === 120,
		'piso: o texto de bancada não tem 120 caracteres — ele tem ' + String( api.caracteres( acentuado ).length )
	);

	/* TETO: o cliente NÃO corta o que o servidor aceita. */
	afirmar(
		api.limitar( 'nome', acentuado ) === acentuado,
		'teto: o cliente CORTOU um nome de 120 caracteres que o servidor aceita — corte de um lado e recusa do outro, com o mesmo número publicado'
	);

	/* PISO da regra: um caractere acima do limite ainda é cortado, em caracteres. */
	afirmar(
		api.caracteres( api.limitar( 'nome', acentuado + 'ç' ) ).length === 120,
		'piso: o corte de 121 caracteres não devolveu 120 caracteres — o corte é por caractere, e nunca por unidade UTF-16'
	);

	/*
	 * PISO do par substituto: cortar por unidade UTF-16 no meio de um emoji
	 * devolveria metade de um caractere, e o servidor receberia texto que
	 * ninguém escreveu.
	 */
	const comEmoji = 'a'.repeat( 119 ) + '🙂';

	afirmar(
		comEmoji.length === 121 && api.caracteres( comEmoji ).length === 120,
		'piso do par substituto: o texto de bancada não tem 121 unidades UTF-16 e 120 caracteres, e sem isso a diferença entre as unidades não é reproduzível'
	);

	afirmar(
		api.limitar( 'nome', comEmoji ) === comEmoji,
		'teto do par substituto: o cliente cortou um texto de 120 caracteres porque ele tem 121 unidades UTF-16'
	);

	afirmar(
		! api.limitar( 'nome', comEmoji + 'b' ).includes( '\uFFFD' ) && api.caracteres( api.limitar( 'nome', comEmoji + 'b' ) ).length === 120,
		'piso do par substituto: o corte partiu um caractere ao meio'
	);

	/* Campo sem limite publicado sai intacto: limite ausente não é limite zero. */
	afirmar(
		api.limitar( 'inexistente', acentuado ) === acentuado,
		'piso do limite ausente: campo sem limite publicado foi cortado — limite ausente não é limite zero'
	);

	return { achados };
}

const modo = process.argv[ 2 ] || '';
const raiz = process.argv[ 3 ] || '';

if ( 'lint' === modo ) {
	process.stdout.write( JSON.stringify( lint( raiz ) ) );
} else if ( 'extrator' === modo ) {
	process.stdout.write( JSON.stringify( extrator( raiz ) ) );
} else if ( 'cliente' === modo ) {
	process.stdout.write( JSON.stringify( cliente( raiz ) ) );
} else if ( 'leads' === modo ) {
	process.stdout.write( JSON.stringify( limiteDoCliente( raiz ) ) );
} else {
	process.stdout.write( JSON.stringify( { achados: [ 'modo desconhecido: ' + modo ] } ) );
}
