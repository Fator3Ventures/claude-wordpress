<?php
/**
 * Checagens estáticas — rodam neste ambiente (PHP 8.4, Node 22, sem WordPress).
 *
 * Cada checagem é uma FUNÇÃO PURA que devolve `array( 'ok' => bool,
 * 'achados' => array<string> )` a partir de uma raiz. O runner e o piso chamam a
 * MESMA função: o piso aponta a fixture, o runner aponta o pacote. Nenhuma
 * regra é reimplementada no piso.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/* -------------------------------------------------------------------------
 * estatica.php_lint
 * ---------------------------------------------------------------------- */

/**
 * `php -l` em todo `.php` da raiz.
 *
 * Defeito medido que esta checagem existe para não repetir: a versão anterior
 * imprimia FALHA e saía com código 0. Aqui o resultado volta ao runner, que
 * conta pela `estado()` e devolve código de saída diferente de zero.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_php_lint( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$saida  = array();
		$codigo = 0;
		exec( 'php -l ' . escapeshellarg( $raiz . '/' . $rel ) . ' 2>&1', $saida, $codigo );

		if ( 0 !== $codigo ) {
			$achados[] = $rel . ': ' . trim( preg_replace( '/\s+/', ' ', implode( ' ', $saida ) ) ?? '' );
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.json_valido
 * ---------------------------------------------------------------------- */

/**
 * Todo `.json` da raiz analisa.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_json_valido( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'json' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$bruto = (string) file_get_contents( $raiz . '/' . $rel );
		json_decode( $bruto, true );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			$achados[] = $rel . ': ' . json_last_error_msg();
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.js_lint
 * ---------------------------------------------------------------------- */

/**
 * `node --check` em todo `.js` e `.mjs` da raiz.
 *
 * A análise roda na sonda `checagens/js.mjs`, sob o Node de verdade: analisar
 * JavaScript com expressão regular de PHP seria inferência disfarçada de
 * medição. A sonda devolve JSON; quem imprime e conta continua sendo `estado()`.
 *
 * @param string $raiz  Raiz a varrer.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_js_lint( string $raiz, string $suite ): array {
	$cmd = 'node ' . escapeshellarg( $suite . '/checagens/js.mjs' ) . ' lint ' . escapeshellarg( $raiz ) . ' 2>&1';

	$saida  = array();
	$codigo = 0;
	exec( $cmd, $saida, $codigo );

	$json = json_decode( implode( "\n", $saida ), true );

	if ( ! is_array( $json ) || ! isset( $json['achados'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'sonda js.mjs não devolveu veredito analisável: ' . f3b_amostra( $saida, 3 ) ),
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', $json['achados'] ),
		'medidas' => (int) ( $json['medidas'] ?? 0 ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.wp_comentarios_balanceados
 * ---------------------------------------------------------------------- */

/**
 * Analisa um documento de blocos: balanceamento e JSON de atributo.
 *
 * @param string $rotulo Nome que aparece no achado.
 * @param string $texto  Markup.
 * @return array<int,string> Achados.
 */
function f3b_blocos_analisar( string $rotulo, string $texto ): array {
	$achados = array();
	$pilha   = array();
	$re      = '/<!--\s*(\/?)wp:([a-z0-9-]+(?:\/[a-z0-9-]+)?)\s*(\{.*?\})?\s*(\/?)-->/s';

	if ( preg_match_all( $re, $texto, $ms, PREG_SET_ORDER ) ) {
		foreach ( $ms as $m ) {
			$fechando = '' !== $m[1];
			$bloco    = $m[2];
			$attrs    = $m[3] ?? '';
			$sozinho  = '' !== ( $m[4] ?? '' );

			if ( '' !== $attrs ) {
				json_decode( $attrs, true );

				if ( JSON_ERROR_NONE !== json_last_error() ) {
					$achados[] = $rotulo . ': JSON de atributo inválido em wp:' . $bloco . ' (' . json_last_error_msg() . ')';
				}
			}

			if ( $fechando ) {
				if ( array() === $pilha ) {
					$achados[] = $rotulo . ': fechamento sem abertura /wp:' . $bloco;
					continue;
				}

				$topo = array_pop( $pilha );

				if ( $topo !== $bloco ) {
					$achados[] = $rotulo . ': fechamento fora de ordem, esperava /wp:' . $topo . ' e veio /wp:' . $bloco;
				}

				continue;
			}

			if ( $sozinho ) {
				continue;
			}

			$pilha[] = $bloco;
		}
	}

	if ( array() !== $pilha ) {
		$achados[] = $rotulo . ': bloco aberto sem fechamento: wp:' . implode( ', wp:', $pilha );
	}

	return $achados;
}

/**
 * `wp:` balanceados e JSON de atributo válido em todo markup de bloco.
 *
 * Cobre `templates/`, `parts/` e `content/` no arquivo cru, e os
 * `patterns/*.php` DEPOIS DE EXECUTADOS: o defeito que importa nasce na saída,
 * não no arquivo antes das chamadas de i18n.
 *
 * @param string $raiz  Raiz a varrer.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_wp_comentarios( string $raiz, string $suite ): array {
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'html' ), f3b_excluidos() ) as $rel ) {
		if ( ! preg_match( '#(^|/)(templates|parts|content)/#', '/' . $rel ) ) {
			continue;
		}

		$medidas++;
		$achados = array_merge( $achados, f3b_blocos_analisar( $rel, (string) file_get_contents( $raiz . '/' . $rel ) ) );
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		if ( ! preg_match( '#(^|/)patterns/#', '/' . $rel ) ) {
			continue;
		}

		$saida  = array();
		$codigo = 0;
		exec(
			'php ' . escapeshellarg( $suite . '/lib/render-pattern.php' ) . ' ' . escapeshellarg( $raiz . '/' . $rel ) . ' 2>&1',
			$saida,
			$codigo
		);

		$render = implode( "\n", $saida );

		if ( 0 !== $codigo ) {
			$achados[] = $rel . ' (executado): o pattern não renderizou — ' . f3b_amostra( $saida, 2 );
			continue;
		}

		$medidas++;
		$achados = array_merge( $achados, f3b_blocos_analisar( $rel . ' (executado)', $render ) );
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_escrita_unica
 * ---------------------------------------------------------------------- */

/**
 * Nenhuma escrita direta de option fora do gravador único.
 *
 * Varre o PACOTE INTEIRO, inclusive a própria suíte. Os dois gravadores
 * declarados — um no implantador, outro no `site-core` — são os únicos arquivos
 * dispensados, e a lista deles é declarada aqui, não inferida.
 *
 * Comentário não conta: a varredura mede o que EXECUTA (ver `f3b_codigo_php()`).
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_escrita_unica( string $raiz ): array {
	$gravadores = array(
		'includes/class-f3base-imp-gravador.php',
		'fontes/site-core/includes/class-f3base-options.php',
	);

	$nomes = array(
		'update_option',
		'add_option',
		'delete_option',
		'update_site_option',
		'add_site_option',
		'delete_site_option',
		'set_theme_mod',
		'remove_theme_mod',
	);

	$re      = '/(?<![A-Za-z0-9_$>])(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '/';
	$achados = array();
	$medidas = 0;

	/*
	 * DEFINIR a função do núcleo não é ESCREVER uma option. A regra fala de
	 * chamada: `update_option( ... )` fora do gravador tira a escrita do journal
	 * e da procedência. Uma bancada de sonda, que roda fora do WordPress, PRECISA
	 * declarar `function update_option()` para que o código real do pacote tenha
	 * onde cair — e num WordPress de verdade essa declaração nem existiria, porque
	 * redeclarar função do núcleo é erro fatal. A definição sai da linha antes do
	 * teste, e o que sobrar dela continua sendo medido: `function f( ... ) {
	 * update_option( ... ); }` na mesma linha continua sendo achado.
	 */
	$re_definicao = '/(?<![A-Za-z0-9_$>])function\s+&?\s*(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '/';

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		if ( in_array( $rel, $gravadores, true ) ) {
			continue;
		}

		$medidas++;

		$linhas = preg_split( '/\R/', f3b_codigo_php( $raiz . '/' . $rel ) ) ?: array();

		foreach ( $linhas as $n => $linha ) {
			$sem_definicao = preg_replace( $re_definicao, '', $linha );
			$sem_definicao = is_string( $sem_definicao ) ? $sem_definicao : $linha;

			if ( preg_match( $re, $sem_definicao, $m ) ) {
				$achados[] = $rel . ':' . ( $n + 1 ) . ' ' . $m[1] . '()';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_version_compare
 * ---------------------------------------------------------------------- */

/**
 * `version_compare()` só com operador da lista fechada.
 *
 * `===` não é operador de `version_compare()`: em PHP 8 ele explode em runtime,
 * e o defeito só aparece no caminho que executa aquela linha. Operador ausente
 * também é achado — sem operador a função devolve int, nunca bool.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_version_compare( string $raiz ): array {
	$permitidos = array( '<', 'lt', '<=', 'le', '>', 'gt', '>=', 'ge', '==', '=', 'eq', '!=', '<>', 'ne' );
	$achados    = array();
	$medidas    = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		foreach ( f3b_chamadas( f3b_codigo_php( $raiz . '/' . $rel ), 'version_compare' ) as $args ) {
			$medidas++;
			$partes = array_map( 'trim', explode( ',', $args ) );

			if ( count( $partes ) < 3 ) {
				$achados[] = $rel . ': operador ausente (sem operador a função devolve int, nunca bool)';
				continue;
			}

			$operador = trim( (string) end( $partes ), " '\"" );

			if ( ! in_array( $operador, $permitidos, true ) ) {
				$achados[] = $rel . ": operador '" . $operador . "' fora da lista fechada";
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_condicao_literal
 * ---------------------------------------------------------------------- */

/**
 * Bloco `{ ... }` que contém a posição dada.
 *
 * @param string $src Código.
 * @param int    $pos Posição.
 * @return array{0:int,1:int}|null Abertura e fechamento, ou null.
 */
function f3b_bloco_envolvente( string $src, int $pos ): ?array {
	$pilha = array();
	$abre  = null;

	for ( $i = 0; $i < strlen( $src ); $i++ ) {
		if ( '{' === $src[ $i ] ) {
			$pilha[] = $i;
		} elseif ( '}' === $src[ $i ] ) {
			$ini = array_pop( $pilha );

			if ( null !== $ini && $ini < $pos && $i > $pos ) {
				if ( null === $abre || $ini > $abre[0] ) {
					$abre = array( $ini, $i );
				}
			}
		}
	}

	return $abre;
}

/**
 * Condição literal em checagem, COM ESCOPO.
 *
 * `check(true, …)`, `estado(true, …)` e `assert(1, …)` são proibidos: a linha
 * imprime um veredito decidido no código-fonte, não observado.
 *
 * O escopo é o que separa o defeito do idioma legítimo: literal dentro de um
 * ramo de `if`/`else` cujo ramo IRMÃO emite outro veredito não é condição
 * constante — o que decide ali é o `if`, e o literal só nomeia qual dos dois
 * lados aquele ramo é. Por isso o piso desta checagem tem os dois lados.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_condicao_literal( string $raiz ): array {
	$nomes   = array( 'check', 'estado', 'assert', 'avaliar', 'afirmar', 'condicional', 'verificar' );
	$re      = '/(?<![A-Za-z0-9_$>])(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '\s*(true|false|TRUE|FALSE|1|0)\s*,/';
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( $re, $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$pos     = (int) $m[0][1];
			$chamada = $m[1][0] . '(' . $m[2][0] . ', …)';
			$linha   = substr_count( substr( $src, 0, $pos ), "\n" ) + 1;

			if ( f3b_literal_legitimo( $src, $pos, $nomes, $m[2][0] ) ) {
				continue;
			}

			$achados[] = $rel . ':' . $linha . ' ' . $chamada;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/**
 * O literal está num ramo cujo IRMÃO emite outro veredito?
 *
 * @param string            $src     Código.
 * @param int               $pos     Posição do literal.
 * @param array<int,string> $nomes   Nomes de função de checagem.
 * @param string            $literal Literal encontrado.
 * @return bool
 */
function f3b_literal_legitimo( string $src, int $pos, array $nomes, string $literal ): bool {
	$bloco = f3b_bloco_envolvente( $src, $pos );

	if ( null === $bloco ) {
		return false;
	}

	list( $abre, $fecha ) = $bloco;

	$antes  = rtrim( substr( $src, 0, $abre ) );
	$depois = ltrim( substr( $src, $fecha + 1 ) );

	$e_if   = (bool) preg_match( '/(?<![A-Za-z0-9_])(if|elseif)\s*\)?\s*$/', $antes ) || (bool) preg_match( '/\)\s*$/', $antes ) && (bool) preg_match( '/(?<![A-Za-z0-9_])(if|elseif)\s*\(/', $antes );
	$e_else = (bool) preg_match( '/(?<![A-Za-z0-9_])else\s*$/', $antes );

	if ( ! $e_if && ! $e_else ) {
		return false;
	}

	$irmao = '';

	if ( $e_if && preg_match( '/^else\b/', $depois ) ) {
		$sub = f3b_bloco_envolvente( $depois . '}', strpos( $depois, '{' ) + 1 );

		if ( null !== $sub ) {
			$irmao = substr( $depois, $sub[0], $sub[1] - $sub[0] );
		}
	}

	if ( $e_else ) {
		$corte = substr( $src, 0, $abre );
		$ini   = strrpos( $corte, '}' );

		if ( false !== $ini ) {
			$par = f3b_bloco_envolvente( substr( $src, 0, $ini + 1 ), $ini - 1 );

			if ( null !== $par ) {
				$irmao = substr( $src, $par[0], $par[1] - $par[0] );
			}
		}
	}

	if ( '' === $irmao ) {
		return false;
	}

	$re = '/(?<![A-Za-z0-9_$>])(' . implode( '|', $nomes ) . ')\s*' . preg_quote( '(', '/' ) . '\s*(true|false|TRUE|FALSE|1|0)\s*,/';

	if ( ! preg_match_all( $re, $irmao, $ms, PREG_SET_ORDER ) ) {
		return false;
	}

	$normaliza = static function ( string $v ): string {
		return in_array( strtolower( $v ), array( 'true', '1' ), true ) ? 'v' : 'f';
	};

	foreach ( $ms as $m ) {
		if ( $normaliza( $m[2] ) !== $normaliza( $literal ) ) {
			return true;
		}
	}

	return false;
}

/* -------------------------------------------------------------------------
 * estatica.detector_codigo_em_string
 * ---------------------------------------------------------------------- */

/**
 * O texto parece JavaScript, SQL ou shell?
 *
 * @param string $texto Texto.
 * @return string Linguagem detectada, ou string vazia.
 */
function f3b_linguagem_em_texto( string $texto ): string {
	$js = array( '<script', 'document.', 'window.', 'addEventListener', 'querySelector', 'function (', 'function(', '=>', 'console.log' );

	foreach ( $js as $marca ) {
		if ( false !== stripos( $texto, $marca ) ) {
			return 'javascript';
		}
	}

	if ( preg_match( '/\b(SELECT\b.+\bFROM|INSERT\s+INTO|DELETE\s+FROM|UPDATE\b.+\bSET|DROP\s+TABLE|CREATE\s+TABLE)\b/is', $texto ) ) {
		return 'sql';
	}

	if ( preg_match( '/(#!\/bin\/|\brm\s+-rf\b|\bshell_exec\b|\bpassthru\b|\bsudo\s|\|\s*grep\b|&&\s*\w+\s)/i', $texto ) ) {
		return 'shell';
	}

	return '';
}

/**
 * Nenhum JS, SQL ou shell dentro de heredoc ou de concatenação PHP.
 *
 * Escopo declarado: heredoc/nowdoc de qualquer conteúdo executável, string
 * literal montada por CONCATENAÇÃO (`.`) e `<script>` inline com corpo.
 * `<script src="…">` sem corpo fica de fora — é referência a arquivo, que é
 * exatamente o que a regra manda fazer. SQL entregue direto a
 * `$wpdb->prepare()` também fica de fora: é a forma sancionada, e o que a regra
 * proíbe é a montagem por pedaços.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_codigo_em_string( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$tokens   = token_get_all( (string) file_get_contents( $raiz . '/' . $rel ) );
		$heredoc  = false;
		$corpo    = '';
		$linha_hd = 0;
		$anterior = null;

		foreach ( $tokens as $token ) {
			if ( is_array( $token ) && T_START_HEREDOC === $token[0] ) {
				$heredoc  = true;
				$corpo    = '';
				$linha_hd = $token[2];
				continue;
			}

			if ( is_array( $token ) && T_END_HEREDOC === $token[0] ) {
				$lingua = f3b_linguagem_em_texto( $corpo );

				if ( '' !== $lingua ) {
					$achados[] = $rel . ':' . $linha_hd . ' heredoc com ' . $lingua;
				}

				$heredoc = false;
				continue;
			}

			if ( $heredoc ) {
				$corpo .= is_array( $token ) ? $token[1] : $token;
				continue;
			}

			if ( is_array( $token ) && in_array( $token[0], array( T_COMMENT, T_DOC_COMMENT, T_WHITESPACE ), true ) ) {
				continue;
			}

			if ( is_array( $token ) && T_CONSTANT_ENCAPSED_STRING === $token[0] ) {
				$conteudo = substr( $token[1], 1, -1 );
				$lingua   = f3b_linguagem_em_texto( $conteudo );

				if ( '' !== $lingua && '.' === $anterior ) {
					$achados[] = $rel . ':' . $token[2] . ' concatenação com ' . $lingua;
				}

				/*
				 * A expressão e a mensagem são montadas por pedaços de propósito:
				 * escritas inteiras, elas conteriam o próprio marcador e este
				 * detector reprovaria a si mesmo — o detector que grita por
				 * causa de si é tão inútil quanto o que nunca grita.
				 */
				$re_inline = '/<' . 'script(?![^>]*\bsrc=)[^>]*>\s*\S/i';

				if ( 'javascript' === $lingua && preg_match( $re_inline, $conteudo ) ) {
					$achados[] = $rel . ':' . $token[2] . ' tag de script inline com corpo';
				}
			}

			$anterior = is_array( $token ) ? $token[1] : $token;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_chave_sem_consumidor
 * ---------------------------------------------------------------------- */

/**
 * Cabeçalho de uma leitura de configuração: qualquer classe terminada em
 * `Config`, seguida de `::obter`, `::lista` ou `::existe` e do parêntese.
 */
const F3B_RE_CONFIG = '/(?<![A-Za-z0-9_])[A-Za-z0-9_\\\\]*Config::(?:obter|lista|existe)\s*\(/';

/**
 * Caminhos de configuração lidos por código, na raiz inteira.
 *
 * Resolve três formas: literal puro, literal concatenado com variável (o índice
 * dinâmico vira `*`) e a função intermediária — aquela que recebe um caminho
 * por parâmetro e lê sufixos a partir dele. A terceira forma é resolvida pelos
 * literais dos CHAMADORES, senão a chave lida por dentro de um agrupador ficaria
 * eternamente órfã.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,string>
 */
function f3b_caminhos_lidos( string $raiz ): array {
	$lidas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_chamadas_regex( $src, F3B_RE_CONFIG ) as $args ) {
			$caminho = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args ) ) );

			if ( '' !== $caminho && ! str_starts_with( $caminho, '*' ) ) {
				$lidas[ $caminho ] = true;
			}
		}

		/* Funções intermediárias: parâmetro de caminho + sufixos literais. */
		if ( preg_match_all( '/function\s+(\w+)\s*\(\s*string\s+(\$\w+)[^)]*\)\s*:\s*\w+\s*\{/', $src, $fs, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $fs as $f ) {
				$nome  = $f[1][0];
				$param = $f[2][0];
				$bloco = f3b_bloco_envolvente( $src, (int) $f[0][1] + strlen( $f[0][0] ) );

				if ( null === $bloco ) {
					continue;
				}

				$corpo    = substr( $src, $bloco[0], $bloco[1] - $bloco[0] );
				$sufixos  = array();

				foreach ( f3b_chamadas_regex( $corpo, F3B_RE_CONFIG ) as $args ) {
					$primeiro = trim( f3b_primeiro_argumento( $args ) );

					if ( ! str_starts_with( $primeiro, $param ) ) {
						continue;
					}

					$resto     = trim( substr( $primeiro, strlen( $param ) ) );
					$sufixos[] = f3b_expressao_para_caminho( $resto );
				}

				if ( array() === $sufixos ) {
					continue;
				}

				foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel2 ) {
					$src2 = f3b_codigo_php( $raiz . '/' . $rel2 );

					$re_sitio = '/(?<![A-Za-z0-9_])(?:(?:self|static|parent|[A-Za-z0-9_\\\\]+)::)?' . preg_quote( $nome, '/' ) . '\s*\(/';

					foreach ( f3b_chamadas_regex( $src2, $re_sitio ) as $args2 ) {
						$base = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args2 ) ) );

						if ( '' === $base || str_starts_with( $base, '*' ) ) {
							continue;
						}

						foreach ( $sufixos as $sufixo ) {
							$lidas[ f3b_caminho_normalizado( $base . $sufixo ) ] = true;
						}
					}
				}
			}
		}
	}

	return array_keys( $lidas );
}

/**
 * Primeiro argumento de uma lista de argumentos, respeitando aninhamento.
 *
 * @param string $args Argumentos.
 * @return string
 */
function f3b_primeiro_argumento( string $args ): string {
	$nivel = 0;
	$saida = '';

	for ( $i = 0; $i < strlen( $args ); $i++ ) {
		$c = $args[ $i ];

		if ( '(' === $c || '[' === $c ) {
			$nivel++;
		}

		if ( ')' === $c || ']' === $c ) {
			$nivel--;
		}

		if ( ',' === $c && 0 === $nivel ) {
			break;
		}

		$saida .= $c;
	}

	return trim( $saida );
}

/**
 * Converte uma expressão de caminho em caminho pontilhado, com `*` no dinâmico.
 *
 * Anda caractere a caractere e respeita as aspas: o ponto DENTRO de um literal
 * (`'consentimento.ttl_dias'`) faz parte do caminho, e o ponto FORA dele é o
 * operador de concatenação. Tratar os dois igual apagava todo caminho com mais
 * de um segmento — e o cruzamento passava a acusar como órfã a chave que o
 * código lê na linha de cima.
 *
 * A borda NÃO é aparada aqui: um sufixo legítimo começa por ponto
 * (`.*.id`), e apará-lo colaria o índice no nome da chave-pai. Quem monta o
 * caminho final apara.
 *
 * @param string $expr Expressão.
 * @return string
 */
function f3b_expressao_para_caminho( string $expr ): string {
	$expr = trim( $expr );
	$tam  = strlen( $expr );
	$i    = 0;
	$saida = '';

	while ( $i < $tam ) {
		$c = $expr[ $i ];

		if ( ' ' === $c || "\t" === $c || "\n" === $c || "\r" === $c || '.' === $c ) {
			$i++;
			continue;
		}

		if ( "'" === $c || '"' === $c ) {
			$aspas = $c;
			$i++;
			$buf = '';

			while ( $i < $tam ) {
				if ( '\\' === $expr[ $i ] && $i + 1 < $tam ) {
					$buf .= $expr[ $i + 1 ];
					$i   += 2;
					continue;
				}

				if ( $expr[ $i ] === $aspas ) {
					$i++;
					break;
				}

				$buf .= $expr[ $i ];
				$i++;
			}

			$saida .= $buf;
			continue;
		}

		/* Variável, chamada ou constante: índice que só existe em execução. */
		$saida .= '*';
		$nivel  = 0;

		while ( $i < $tam ) {
			$c2 = $expr[ $i ];

			if ( '(' === $c2 || '[' === $c2 ) {
				$nivel++;
			}

			if ( ')' === $c2 || ']' === $c2 ) {
				$nivel--;
			}

			if ( 0 === $nivel && '.' === $c2 ) {
				break;
			}

			$i++;
		}
	}

	return (string) preg_replace( '/\.{2,}/', '.', $saida );
}

/**
 * Normaliza um caminho montado, apando as bordas.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function f3b_caminho_normalizado( string $caminho ): string {
	return trim( (string) preg_replace( '/\.{2,}/', '.', $caminho ), '.' );
}

/**
 * Toda chave declarada em `config/site.json` tem alguma linha que a lê.
 *
 * Cruzamento GERAL, nunca por seção: a cobertura é bidirecional — chave-pai
 * lida cobre os filhos, e caminho lido mais fundo que a chave também a cobre.
 * A própria `consumidores_declarados` entra na varredura como qualquer outra.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_chave_sem_consumidor( string $raiz ): array {
	$arquivo = $raiz . '/config/site.json';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente na raiz varrida' ),
		);
	}

	$json = json_decode( (string) file_get_contents( $arquivo ), true );

	if ( ! is_array( $json ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json não analisa' ),
		);
	}

	$declaradas = array();
	f3b_achatar( $json, '', $declaradas );
	$declaradas = array_keys( $declaradas );

	$lidas   = f3b_caminhos_lidos( $raiz );
	$achados = array();

	foreach ( $declaradas as $chave ) {
		if ( str_starts_with( $chave, '$schema' ) ) {
			$chave_busca = $chave;
		} else {
			$chave_busca = $chave;
		}

		if ( in_array( $chave_busca, $lidas, true ) ) {
			continue;
		}

		$coberta = false;

		foreach ( $lidas as $lida ) {
			if ( str_starts_with( $chave_busca, $lida . '.' ) || str_starts_with( $lida, $chave_busca . '.' ) ) {
				$coberta = true;
				break;
			}
		}

		if ( ! $coberta ) {
			$achados[] = $chave_busca;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $declaradas ),
		'lidos'   => count( $lidas ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.gate_de_fase_do_metadado
 * ---------------------------------------------------------------------- */

/**
 * A lista de gates de FASE sai do METADADO, e não existe uma segunda fonte.
 *
 * O defeito medido na 1.0.17: havia DUAS fontes para o mesmo fato — uma lista
 * literal em `gates_de_fase()`, com UM nome, e o metadado `gate` por checagem,
 * com DOIS emissores. Duas fontes divergem, e a divergência saiu impressa dentro
 * de UMA linha do log, unidade `entrega`: "Nenhuma pendência de fase em aberto"
 * ao lado de "Pendência(s) de FASE dentro desta unidade — 1 …
 * orcamento.medicao_de_pagina (BLOCKED)".
 *
 * Três achados, e cada um fecha um caminho de volta:
 *
 * 1. **Nome de checagem literal dentro de `gates_de_fase()`**: a lista paralela
 *    voltou, e o próximo emissor de `gate=fase` que ninguém acrescentar a ela
 *    reabre a divergência.
 * 2. **O mesmo nome nos dois gates**: um nome que é entregável do gate de
 *    aplicação E emite `gate=fase` decide e não decide a autodesativação ao
 *    mesmo tempo.
 * 3. **Emissor de `gate=fase` sem nome literal**: o nome entra na lista derivada
 *    valendo o que a variável tiver, e o operador não consegue achá-lo na fonte.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_gate_de_fase_do_metadado( string $raiz ): array {
	$forma_de_nome = '/^[a-z][a-z0-9_]*\.[a-z0-9_.-]+$/';
	$emissoras     = array( 'emitir', 'avaliar', 'condicional', 'emitir_unidade' );

	$achados     = array();
	$medidas     = 0;
	$de_fase     = array();
	$corpo_fase  = '';
	$corpo_gate  = '';

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( 'gates_de_fase' === $funcao['nome'] ) {
				$corpo_fase = $funcao['corpo'];
			}

			if ( 'entregaveis_do_gate_de_aplicacao' === $funcao['nome'] ) {
				$corpo_gate = $funcao['corpo'];
			}
		}

		$posicao = 0;

		while ( true ) {
			$onde = strpos( $src, "'gate'", $posicao );

			if ( false === $onde ) {
				break;
			}

			$posicao = $onde + 1;

			if ( 1 !== preg_match( '/^\'gate\'\s*=>\s*\'fase\'/', substr( $src, $onde, 40 ) ) ) {
				continue;
			}

			++$medidas;

			$inicio = max( 0, $onde - 4000 );
			$antes  = substr( $src, $inicio, $onde - $inicio );
			$nome   = '';

			foreach ( $emissoras as $emissora ) {
				$abre = strrpos( $antes, $emissora . '(' );

				if ( false === $abre ) {
					continue;
				}

				if ( preg_match_all( '/\'([a-z][a-z0-9_]*\.[a-z0-9_.-]+)\'/', substr( $antes, $abre ), $ms ) ) {
					$nome = (string) $ms[1][0];
				}

				break;
			}

			if ( '' === $nome ) {
				$achados[] = $rel . ': emissor com gate=fase sem NOME LITERAL de checagem no argumento — a lista de gates de fase sai do metadado, '
					. 'e um emissor cujo nome vem de variável entra nela valendo o que a variável tiver, sem que o operador consiga achá-lo na fonte';
				continue;
			}

			$de_fase[ $nome ] = $rel;
		}
	}

	if ( '' === $corpo_fase ) {
		return array(
			'ok'      => false,
			'achados' => array( 'nenhuma função gates_de_fase() foi encontrada fora de suite/: sem a âncora não há como saber se a lista é derivada ou literal' ),
			'medidas' => max( 1, $medidas ),
		);
	}

	foreach ( array( 'gates_de_fase()' => $corpo_fase ) as $funcao => $corpo ) {
		if ( ! preg_match_all( '/\'([^\']+)\'/', $corpo, $ms ) ) {
			continue;
		}

		foreach ( $ms[1] as $literal ) {
			if ( 1 === preg_match( $forma_de_nome, $literal ) ) {
				$achados[] = $funcao . ' traz o nome de checagem literal "' . $literal . '": a lista paralela voltou. '
					. 'Duas fontes para o mesmo fato divergem, e a divergência da 1.0.17 saiu impressa dentro de uma linha só do log — '
					. '"Nenhuma pendência de fase em aberto" ao lado de "Pendência(s) de FASE dentro desta unidade — 1". A lista sai do metadado gate=fase';
			}
		}
	}

	if ( '' !== $corpo_gate && preg_match_all( '/\'([^\']+)\'/', $corpo_gate, $ms ) ) {
		foreach ( $ms[1] as $literal ) {
			if ( isset( $de_fase[ $literal ] ) ) {
				$achados[] = '"' . $literal . '" é entregável do gate de APLICAÇÃO e emite gate=fase em ' . $de_fase[ $literal ]
					. ': o mesmo nome decide e não decide a autodesativação, e o gate que ganhar depende de qual lista for consultada primeiro';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => max( 1, $medidas ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.option_gravada_sem_leitor
 * ---------------------------------------------------------------------- */

/**
 * Toda option do NOSSO namespace que o pacote GRAVA é lida por alguém.
 *
 * O IRMÃO DE `estatica.detector_chave_sem_consumidor`, e o motivo de existir
 * está no que aquele detector mede: ele prova que a chave do config é LIDA por
 * alguma linha — e "ser lida" não é "mudar alguma coisa". Foi por essa distinção
 * que `cadencia_relatorio.apos_n_ajustes` passou por ele com nota cheia até a
 * 1.0.17: a chave era lida, o valor ia para a option `f3base_cadencia`, e
 * NENHUMA linha do pacote lia aquela option. O relatório imprimia "gatilho
 * alternativo: após N ajustes" sobre um contador que não existia. Um detector
 * que mede a coisa errada é pior que detector ausente, porque produz confiança.
 *
 * Este fecha a outra metade do caminho: gravar não é configurar, e option
 * gravada que ninguém relê é escrita sem consequência. Os dois juntos cobrem o
 * trajeto inteiro — a chave é lida, e o que a leitura produz é lido de volta.
 *
 * ESCOPO: só options do prefixo técnico DECLARADO em `site.prefixo_tecnico`.
 * Option do núcleo (`blog_public`, `site_icon`, `permalink_structure`) é lida
 * pelo WordPress, não por nós, e acusá-la seria falso positivo com cara de
 * rigor. O prefixo sai da configuração e não de literal, para que a regra
 * continue valendo no pacote renomeado.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_option_sem_leitor( string $raiz ): array {
	$config = json_decode( (string) @file_get_contents( $raiz . '/config/site.json' ), true );

	if ( ! is_array( $config ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou ilegível na raiz varrida: sem site.prefixo_tecnico não há namespace de option a delimitar, e varrer tudo acusaria option do núcleo' ),
			'medidas' => 0,
		);
	}

	$prefixo = (string) ( $config['site']['prefixo_tecnico'] ?? '' );

	if ( '' === $prefixo ) {
		return array(
			'ok'      => false,
			'achados' => array( 'site.prefixo_tecnico vazio: o namespace das nossas options sai daí, e sem ele a regra não tem escopo' ),
			'medidas' => 0,
		);
	}

	$fontes    = array();
	$constantes = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src            = f3b_codigo_php( $raiz . '/' . $rel );
		$fontes[ $rel ] = $src;

		if ( preg_match_all( '/const\s+([A-Z][A-Z0-9_]*)\s*=\s*\'([^\']+)\'/', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$constantes[ $m[1] ] = $m[2];
			}
		}
	}

	$alvo = '(?:([\'"])([A-Za-z_][A-Za-z0-9_]*)\1|(?:self|static|parent|[A-Za-z_][A-Za-z0-9_]*)::([A-Z][A-Z0-9_]*))';

	$resolver = static function ( array $m ) use ( $constantes ): string {
		if ( isset( $m[2] ) && '' !== $m[2] ) {
			return $m[2];
		}

		return $constantes[ $m[3] ?? '' ] ?? '';
	};

	$escritas = array();
	$leituras = array();

	foreach ( $fontes as $rel => $src ) {
		if ( preg_match_all( '/(?:Gravador::(?:gravar|gravar_chaves|persistir_infra|criar_atomico|trocar_atomico)|update_option|add_option|update_site_option)\s*\(\s*' . $alvo . '/s', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$nome = $resolver( $m );

				if ( str_starts_with( $nome, $prefixo . '_' ) ) {
					$escritas[ $nome ][ $rel ] = true;
				}
			}
		}

		if ( preg_match_all( '/(?:get_option|get_site_option|delete_option|Options::(?:obter|ler|gravar|salvar)|obter_option)\s*\(\s*' . $alvo . '/s', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$nome = $resolver( $m );

				if ( '' !== $nome ) {
					$leituras[ $nome ] = true;
				}
			}
		}
	}

	$achados = array();

	foreach ( $escritas as $nome => $onde ) {
		if ( isset( $leituras[ $nome ] ) ) {
			continue;
		}

		$achados[] = 'a option "' . $nome . '" é GRAVADA em ' . implode( ', ', array_keys( $onde ) )
			. ' e NENHUMA linha do pacote a lê de volta: gravar não é configurar, e valor que ninguém relê é escrita sem consequência. '
			. 'Foi assim que apos_n_ajustes passou pelo detector de chave sem consumidor — a chave era lida, o valor ia para uma option, '
			. 'e o relatório prometia um gatilho sobre um contador que não existia. Ou alguém lê esta option, ou ela sai do pacote';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $escritas ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.plano_dependencias
 * ---------------------------------------------------------------------- */

/**
 * O grafo de dependências do plano se sustenta.
 *
 * A regra que não pode ser afrouxada: **unidade que declara dependência de uma
 * que não existe é defeito de configuração**. Sem detector, uma aresta apontando
 * para um grupo inexistente simplesmente não se forma — a dependência some em
 * silêncio, a unidade dependente passa a rodar quando não deveria, e ninguém
 * fica sabendo. O modo de falha é o mesmo do preset inexistente que resolve para
 * vazio: nada quebra, e a promessa deixa de valer.
 *
 * Roda a MESMA função que o runtime usa — `F3Base_Imp_Plano::conferir()` — em
 * SUBPROCESSO, porque o piso executa esta checagem duas vezes (fixture negativa
 * e positiva) e duas declarações da mesma classe no mesmo processo seriam erro
 * fatal. Reimplementar a regra aqui provaria que a cópia funciona, não que o
 * grafo está de pé.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_plano_dependencias( string $raiz ): array {
	$arquivo = $raiz . '/includes/class-f3base-imp-plano.php';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'includes/class-f3base-imp-plano.php ausente na raiz varrida: sem a tabela declarada não existe grafo a conferir' ),
			'medidas' => 1,
		);
	}

	$codigo = 'define("ABSPATH","/"); require ' . var_export( $arquivo, true ) . '; '
		. 'echo json_encode(F3Base_Imp_Plano::conferir(), JSON_UNESCAPED_UNICODE);';

	$saida  = array();
	$estado = 0;
	exec( 'php -r ' . escapeshellarg( $codigo ) . ' 2>&1', $saida, $estado );

	$bruto = implode( '', $saida );
	$json  = json_decode( $bruto, true );

	if ( 0 !== $estado || ! is_array( $json ) || ! isset( $json['achados'], $json['medidas'] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'a tabela não pôde ser lida em subprocesso (código ' . $estado . '): ' . substr( $bruto, 0, 300 ) ),
			'medidas' => 1,
		);
	}

	return array(
		'ok'      => array() === $json['achados'],
		'achados' => array_map( 'strval', (array) $json['achados'] ),
		'medidas' => (int) $json['medidas'],
	);
}

/* -------------------------------------------------------------------------
 * estatica.detector_placeholder
 * ---------------------------------------------------------------------- */

/**
 * Regiões que não são prosa publicada: código, atributo de bloco e mail-tag.
 *
 * @param string $texto Texto.
 * @return array<int,array{0:int,1:int}> Intervalos a ignorar.
 */
function f3b_regioes_isentas( string $texto ): array {
	$isentas = array();
	$padroes = array(
		'/<!--.*?-->/s',
		'#<code\b.*?</code>#is',
		'#<pre\b.*?</pre>#is',
		'/`[^`]*`/',
		'/\[contact-form-7\b.*?\]/is',
		'#<form\b.*?</form>#is',
		'#class="[^"]*f3base-formulario[^"]*".*?</div>#is',
	);

	foreach ( $padroes as $re ) {
		if ( preg_match_all( $re, $texto, $ms, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $ms[0] as $m ) {
				$isentas[] = array( (int) $m[1], (int) $m[1] + strlen( $m[0] ) );
			}
		}
	}

	return $isentas;
}

/**
 * A posição cai numa região isenta?
 *
 * @param int                             $pos     Posição.
 * @param array<int,array{0:int,1:int}>   $isentas Intervalos.
 * @return bool
 */
function f3b_isento( int $pos, array $isentas ): bool {
	foreach ( $isentas as $faixa ) {
		if ( $pos >= $faixa[0] && $pos < $faixa[1] ) {
			return true;
		}
	}

	return false;
}

/**
 * Nenhum placeholder no CONTEÚDO PUBLICADO.
 *
 * Escopo: `content/`, `fontes/tema/patterns`, `fontes/tema/templates`, `fontes/tema/parts` — o que
 * chega ao visitante. As formas são as do contrato: `{{X}}`, `[[X]]`, `[texto]`,
 * `«texto»`, TODO, TBD, XXX, LOREM e EXEMPLO.
 *
 * O colchete tem regra de exceção declarada, e é a parte que o piso positivo
 * cobre: link de markdown (`[texto](url)`), imagem de markdown, colchete dentro
 * de código (`<code>`, `<pre>`, crase) ou de atributo de bloco, e mail-tag de
 * formulário não são placeholder — são sintaxe legítima.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_placeholder( string $raiz ): array {
	$formas = array(
		'chaves_duplas'    => '/\{\{[^}\n]{1,80}\}\}/',
		'colchetes_duplos' => '/\[\[[^\]\n]{1,80}\]\]/',
		'aspas_angulares'  => '/«[^»\n]{1,80}»/u',
		'todo'             => '/(?<![A-Za-z])TODO(?![A-Za-z])/',
		'tbd'              => '/(?<![A-Za-z])TBD(?![A-Za-z])/',
		'xxx'              => '/(?<![A-Za-z])XXX(?![A-Za-z])/',
		'lorem'            => '/(?<![A-Za-z])LOREM(?![A-Za-z])/i',
		'exemplo'          => '/(?<![A-Za-z])EXEMPLO(?![A-Za-z])/',
	);

	$escopos = array( 'content/', 'fontes/tema/patterns/', 'fontes/tema/templates/', 'fontes/tema/parts/' );
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'html', 'php' ), f3b_excluidos() ) as $rel ) {
		$dentro = false;

		foreach ( $escopos as $escopo ) {
			if ( str_starts_with( $rel, $escopo ) || str_contains( '/' . $rel, '/' . $escopo ) ) {
				$dentro = true;
				break;
			}
		}

		if ( ! $dentro ) {
			continue;
		}

		$medidas++;
		$texto   = (string) file_get_contents( $raiz . '/' . $rel );
		$isentas = f3b_regioes_isentas( $texto );

		foreach ( $formas as $rotulo => $re ) {
			if ( ! preg_match_all( $re, $texto, $ms, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $ms[0] as $m ) {
				if ( f3b_isento( (int) $m[1], $isentas ) ) {
					continue;
				}

				$achados[] = $rel . ': ' . $rotulo . ' ' . trim( substr( $m[0], 0, 40 ) );
			}
		}

		/* `[texto]`: colchete simples, com as exceções declaradas. */
		if ( preg_match_all( '/\[([^\]\[\n]{1,60})\]/', $texto, $ms, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				$pos     = (int) $m[0][1];
				$inteiro = $m[0][0];
				$dentro2 = $m[1][0];
				$fim     = $pos + strlen( $inteiro );

				if ( f3b_isento( $pos, $isentas ) ) {
					continue;
				}

				if ( $pos > 0 && '!' === $texto[ $pos - 1 ] ) {
					continue;
				}

				if ( isset( $texto[ $fim ] ) && '(' === $texto[ $fim ] ) {
					continue;
				}

				if ( preg_match( '/^\s*[\d\'"$]/', $dentro2 ) ) {
					continue;
				}

				$achados[] = $rel . ': colchetes ' . trim( substr( $inteiro, 0, 40 ) );
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.simbolos_resolvem
 * ---------------------------------------------------------------------- */

/**
 * Todo método e constante `F3Base_*::` chamados existem na classe.
 *
 * Sem WordPress não dá para executar os caminhos; o que dá para provar sem
 * executar é que nenhuma chamada aponta para um símbolo que não existe — o erro
 * fatal que só aparece no ramo raro, em produção, no meio da aplicação.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_simbolos_resolvem( string $raiz ): array {
	$metodos    = array();
	$constantes = array();
	$fontes     = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src            = f3b_codigo_php( $raiz . '/' . $rel );
		$fontes[ $rel ] = $src;

		if ( ! preg_match_all( '/(?:final\s+|abstract\s+)?class\s+(F3Base_\w+)/', $src, $cs ) ) {
			continue;
		}

		foreach ( $cs[1] as $classe ) {
			preg_match_all( '/function\s+(\w+)\s*\(/', $src, $fs );
			$metodos[ $classe ] = array_merge( $metodos[ $classe ] ?? array(), $fs[1] );

			preg_match_all( '/const\s+([A-Z][A-Z0-9_]*)/', $src, $ks );
			$constantes[ $classe ] = array_merge( $constantes[ $classe ] ?? array(), $ks[1] );
		}
	}

	$achados = array();

	foreach ( $fontes as $rel => $src ) {
		if ( preg_match_all( '/(F3Base_\w+)::(\w+)\s*\(/', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				if ( ! isset( $metodos[ $m[1] ] ) ) {
					continue;
				}

				if ( ! in_array( $m[2], $metodos[ $m[1] ], true ) ) {
					$achados[] = $rel . ': ' . $m[1] . '::' . $m[2] . '() não existe';
				}
			}
		}

		if ( preg_match_all( '/(F3Base_\w+)::([A-Z][A-Z0-9_]*)(?!\s*\()/', $src, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $m ) {
				if ( ! isset( $constantes[ $m[1] ] ) ) {
					continue;
				}

				if ( ! in_array( $m[2], $constantes[ $m[1] ], true ) ) {
					$achados[] = $rel . ': constante ' . $m[1] . '::' . $m[2] . ' não existe';
				}
			}
		}
	}

	return array(
		'ok'      => array() === array_unique( $achados ),
		'achados' => array_values( array_unique( $achados ) ),
		'medidas' => count( $fontes ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.estados_fechados
 * ---------------------------------------------------------------------- */

/**
 * Todo estado emitido pelo pacote pertence à lista fechada.
 *
 * A lista vem de `F3Base_Suite::ESTADOS` — a MESMA que `estado()` valida, e não
 * uma segunda cópia que possa divergir dela.
 *
 * @param string $raiz Raiz.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_estados_fechados( string $raiz ): array {
	$achados = array();
	$alvos   = f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() );

	foreach ( $alvos as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		$padroes = array(
			"/'estado'\s*=>\s*'([^']+)'/",
			"/(?<![A-Za-z0-9_])saida\(\s*'([^']+)'/",
			"/(?<![A-Za-z0-9_])estado\(\s*'([^']+)'/",
		);

		foreach ( $padroes as $re ) {
			if ( ! preg_match_all( $re, $src, $ms ) ) {
				continue;
			}

			foreach ( $ms[1] as $valor ) {
				if ( ! in_array( $valor, F3Base_Suite::ESTADOS, true ) ) {
					$achados[] = $rel . ": '" . $valor . "'";
				}
			}
		}
	}

	return array(
		'ok'      => array() === array_unique( $achados ),
		'achados' => array_values( array_unique( $achados ) ),
		'medidas' => count( $alvos ),
	);
}

/* -------------------------------------------------------------------------
 * config.slug_declarado
 * ---------------------------------------------------------------------- */

/**
 * Toda entrada de `paginas` e `posts` declara slug, e nenhum se repete.
 *
 * PISO DOS DOIS LADOS, porque a armadilha tem duas caras e uma só delas
 * reprovando deixaria a outra viva:
 *
 * - **Slug vazio.** Sem `post_name` declarado, o núcleo deriva do título,
 *   encontra o que já ocupa aquele slug — para tipo hierárquico
 *   `wp_unique_post_slug()` consulta `post_type IN ('page','attachment')` —,
 *   desambigua em silêncio para `<slug>-2` e a leitura de volta da etapa de
 *   conteúdo fecha FALHA. Foi exatamente o que aconteceu: `attachment #10
 *   post_name=metodo-f3` (o logo, importado antes) e `page #11
 *   post_name=metodo-f3-2` (a home, com `slug: ""`).
 * - **Slug repetido entre entradas declaradas.** Duas entradas pedindo o mesmo
 *   `post_name` produzem a mesma desambiguação, com a diferença de que aqui o
 *   defeito está na configuração e é legível antes de qualquer execução.
 *
 * A varredura é da configuração, não do banco: é o que se pode provar em build.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_slug_declarado( string $raiz ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou não analisa na raiz varrida: sem configuração não há slug declarado a conferir' ),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 0;
	$vistos  = array();

	foreach ( array( 'paginas', 'posts' ) as $lista ) {
		foreach ( (array) ( $config[ $lista ] ?? array() ) as $indice => $entrada ) {
			if ( ! is_array( $entrada ) ) {
				continue;
			}

			$medidas++;

			/* A identidade que a mensagem usa: `ref` nas páginas, `slug` nos posts. */
			$nome = isset( $entrada['ref'] ) ? (string) $entrada['ref'] : (string) ( $entrada['titulo'] ?? '' );
			$onde = $lista . '[' . (string) $indice . ']' . ( '' !== $nome ? ' (' . $nome . ')' : '' );
			$slug = isset( $entrada['slug'] ) ? (string) $entrada['slug'] : '';

			if ( '' === trim( $slug ) ) {
				$achados[] = $onde . ': slug vazio — slug vazio delega ao núcleo a decisão que a leitura de volta depois cobra: '
					. 'ele deriva do título, encontra quem já ocupa (para tipo hierárquico wp_unique_post_slug() '
					. 'confere post_type IN (\'page\',\'attachment\')), desambigua para <slug>-2 em silêncio e a etapa de conteúdo fecha FALHA';
				continue;
			}

			if ( isset( $vistos[ $slug ] ) ) {
				$achados[] = $onde . ' e ' . $vistos[ $slug ] . ': declaram o MESMO slug "' . $slug
					. '" — duas entradas pedindo o mesmo post_name produzem a mesma desambiguação silenciosa, '
					. 'com a diferença de que este defeito é legível na configuração antes de qualquer execução';
				continue;
			}

			$vistos[ $slug ] = $onde;
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.gate_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * Nomes de estado de gate declarados pela função âncora `gates_do_canal()`.
 *
 * Os nomes NÃO são escritos aqui: eles saem da função do próprio pacote que os
 * declara. Uma lista literal na suíte seria uma terceira fonte para o mesmo
 * fato — precisamente o que este detector existe para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_gates_declarados( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src   = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = f3b_corpo_de_funcao( $src, 'gates_do_canal' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * Nomes de veredito que a função âncora `vereditos_da_suite()` declara.
 *
 * Como em `f3b_gates_declarados()`, os nomes saem do PRÓPRIO PACOTE: uma lista
 * literal escrita aqui seria a segunda fonte para o mesmo fato, que é
 * exatamente o que este detector existe para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_vereditos_da_suite( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src   = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = f3b_corpo_de_funcao( $src, 'vereditos_da_suite' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * Corpo de uma função pelo nome, com chaves balanceadas.
 *
 * @param string $src  Código sem comentário.
 * @param string $nome Nome da função.
 * @return string|null Corpo entre as chaves, ou null quando a função não existe.
 */
function f3b_corpo_de_funcao( string $src, string $nome ): ?string {
	if ( 1 !== preg_match( '/function\s+' . preg_quote( $nome, '/' ) . '\s*\(/', $src, $m, PREG_OFFSET_CAPTURE ) ) {
		return null;
	}

	$abre = strpos( $src, '{', (int) $m[0][1] );

	if ( false === $abre ) {
		return null;
	}

	$nivel = 0;
	$tam   = strlen( $src );

	for ( $i = $abre; $i < $tam; $i++ ) {
		if ( '{' === $src[ $i ] ) {
			$nivel++;
		}

		if ( '}' === $src[ $i ] ) {
			$nivel--;

			if ( 0 === $nivel ) {
				return substr( $src, $abre + 1, $i - $abre - 1 );
			}
		}
	}

	return null;
}

/**
 * Todas as funções de um arquivo, com nome e corpo.
 *
 * @param string $src Código sem comentário.
 * @return array<int,array{nome:string,corpo:string,linha:int}>
 */
function f3b_funcoes_do_arquivo( string $src ): array {
	$saida = array();

	if ( ! preg_match_all( '/function\s+(\w+)\s*\(/', $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
		return $saida;
	}

	foreach ( $ms as $m ) {
		$corpo = f3b_corpo_de_funcao( substr( $src, (int) $m[0][1] ), $m[1][0] );

		if ( null === $corpo ) {
			continue;
		}

		$saida[] = array(
			'nome'  => (string) $m[1][0],
			'corpo' => $corpo,
			'linha' => substr_count( substr( $src, 0, (int) $m[0][1] ), "\n" ) + 1,
		);
	}

	return $saida;
}

/**
 * O registro da rodada limpa é produzido por UM lugar só — o comando único.
 *
 * Corolário da regra de fonte única, aplicado a um ARTEFATO em vez de a um
 * veredito: `suite/rodada.json` é a evidência importada que o host aceita
 * como prova da rodada integral. Se ele puder ser escrito de dois lugares — ou
 * de nenhum, ou seja, à mão — a evidência deixa de ser evidência: passa a ser
 * uma afirmação que qualquer um coloca no pacote.
 *
 * A regra é inerte quando o nome não aparece no pacote varrido: uma árvore que
 * não conhece o registro não tem o que provar sobre ele.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,string> Achados.
 */
function f3b_produtores_do_registro_da_rodada( string $raiz ): array {
	/*
	 * O nome do registro é montado por pedaços de propósito: escrito inteiro,
	 * ESTA função conteria a marca que ela procura ao lado de uma primitiva de
	 * escrita e o detector se acusaria de ser o segundo produtor — o detector
	 * que grita por causa de si é tão inútil quanto o que nunca grita.
	 */
	$marca    = 'rodada' . '.json';
	$escritas = array( 'file_put_contents(', 'fwrite(', 'fputs(', 'fopen(' );

	$produtores = array();
	$mencionado = false;

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! str_contains( $src, $marca ) ) {
			continue;
		}

		$mencionado = true;

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( ! str_contains( $funcao['corpo'], $marca ) ) {
				continue;
			}

			foreach ( $escritas as $primitiva ) {
				if ( str_contains( $funcao['corpo'], $primitiva ) ) {
					$produtores[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()';
					break;
				}
			}
		}
	}

	if ( ! $mencionado ) {
		return array();
	}

	$produtores = array_values( array_unique( $produtores ) );

	if ( array() === $produtores ) {
		return array(
			'o registro da rodada limpa (' . $marca . ') é MENCIONADO no pacote e não tem produtor: '
				. 'nenhuma função o escreve. Registro que ninguém grava só pode chegar ali à mão, '
				. 'e registro de rodada gravado à mão é uma afirmação de limpeza sem medição por trás',
		);
	}

	if ( count( $produtores ) > 1 ) {
		return array(
			'o registro da rodada limpa (' . $marca . ') é gravado em ' . count( $produtores ) . ' lugares: '
				. implode( ' E ', $produtores )
				. ' — só o COMANDO ÚNICO pode produzi-lo; um segundo produtor é a porta pela qual '
				. 'o registro passa a existir sem a rodada que ele afirma ter havido',
		);
	}

	if ( ! str_starts_with( $produtores[0], 'suite/lib/' ) ) {
		return array(
			'o único produtor do registro da rodada limpa está fora de suite/lib/: ' . $produtores[0]
				. ' — quem grava o registro é o comando único, e mais ninguém',
		);
	}

	return array();
}

/**
 * Veredito da SUÍTE derivado no runtime — ou sumido da suíte.
 *
 * Os dois sentidos reprovam, e é preciso que reprovem:
 *
 * - **Derivado aqui também**: uma função do implantador contém o literal do nome
 *   E produz um estado fechado. É a duplicação medida na 1.0.7, em que a mesma
 *   pergunta recebia duas respostas produzidas por caminhos diferentes.
 * - **Sumido de lá**: o nome não aparece em lugar nenhum de `suite/`. Tirar o
 *   veredito do runtime e não o ter na suíte não é fonte única — é fonte
 *   nenhuma, e a pergunta deixa de ser respondida sem que ninguém perceba.
 *
 * A regra é inerte quando a árvore varrida não declara a âncora: uma árvore que
 * não diz quais vereditos são da suíte não tem o que provar sobre eles.
 *
 * @param string                                        $raiz       Raiz a varrer.
 * @param array{nomes:array<int,string>,ancora:string}  $da_suite   Âncora `vereditos_da_suite()`.
 * @param array<string,array<int,string>>               $derivacoes Derivações achadas no implantador, por nome.
 * @return array<int,string> Achados.
 */
function f3b_vereditos_fora_do_lugar( string $raiz, array $da_suite, array $derivacoes ): array {
	if ( array() === $da_suite['nomes'] ) {
		return array();
	}

	$achados = array();

	foreach ( $da_suite['nomes'] as $veredito ) {
		$lugares = array_values( array_unique( $derivacoes[ $veredito ] ?? array() ) );

		if ( array() !== $lugares ) {
			$achados[] = 'o veredito "' . $veredito . '", declarado em ' . $da_suite['ancora']
				. ' como sendo da SUÍTE, é derivado no implantador: ' . implode( ' E ', $lugares )
				. ' — duas implementações da mesma pergunta, medindo coisas diferentes, é a duplicação de fonte '
				. 'de verdade voltando por outra porta; o runtime pode RELATAR o que mediu, com nome próprio e '
				. 'sem produzir estado fechado para este nome';
		}

		$mencionado = false;

		foreach ( f3b_arquivos( $raiz . '/suite', array( 'php', 'mjs', 'js', 'tsv', 'sh' ) ) as $rel ) {
			if ( str_contains( (string) file_get_contents( $raiz . '/suite/' . $rel ), $veredito ) ) {
				$mencionado = true;
				break;
			}
		}

		if ( ! $mencionado ) {
			$achados[] = 'o veredito "' . $veredito . '", declarado em ' . $da_suite['ancora']
				. ' como sendo da SUÍTE, não aparece em lugar nenhum de suite/: tirar a derivação do runtime e '
				. 'não ter a checagem na suíte não é fonte única, é fonte nenhuma — a pergunta deixa de ser '
				. 'respondida e ninguém percebe';
		}
	}

	return $achados;
}

/**
 * Nenhum estado de gate da autodesativação é DERIVADO em mais de um lugar.
 *
 * O corolário da correção que acabou com o relatório contradizendo a si mesmo:
 * a linha 14 dizia "as 12 rotas estão registradas E há servidor MCP ativo
 * expondo-as" (OK) e a linha 41 do MESMO relatório dizia "o canal MCP não
 * fechou em OK; o canal não está EXPOSTO" (FALHA). Não era o site oscilando:
 * eram duas implementações do mesmo veredito, cada uma medindo por um caminho.
 *
 * A regra que este detector executa, e o que cada palavra significa:
 *
 * - **Estado de gate** é um nome declarado pela função âncora `gates_do_canal()`
 *   — os nomes que a decisão de autodesativação consulta. Eles saem do pacote,
 *   nunca de uma lista escrita aqui.
 * - **Derivação** é uma função que contém o literal daquele nome E produz um
 *   estado fechado. Quem apenas LÊ o veredito recebe o nome por parâmetro e por
 *   isso não aparece: a construção da leitura é o que a mantém fora da conta.
 * - **No máximo uma** derivação por nome. Duas são acusadas NOMEANDO as duas,
 *   com arquivo e função de cada uma.
 * - **E o REGISTRO DA RODADA LIMPA tem um produtor só**, que é o comando único:
 *   evidência importada que qualquer arquivo do pacote pudesse gravar deixaria
 *   de ser evidência. É a linha que `f3b_produtores_do_registro_da_rodada()`
 *   acrescenta.
 * - **E NENHUM VEREDITO É DERIVADO NOS DOIS LUGARES.** Linha nova na 1.0.8, e
 *   ela vem de um defeito medido: `config.toda_chave_tem_consumidor` reprovou no
 *   host nomeando vinte chaves que TÊM consumidor — a suíte, o site-core, um
 *   caminho de execução que aquele lote não percorreu. O detector estático
 *   `estatica.detector_chave_sem_consumidor` cruza toda chave contra TODO o
 *   código do pacote e fecha OK; a versão de runtime cruzava contra o que o
 *   implantador leu NAQUELA execução, que é outra pergunta, e respondia como se
 *   fosse a mesma. A regra: veredito declarado em `vereditos_da_suite()` é da
 *   SUÍTE, e o implantador não pode derivar estado fechado para aquele nome —
 *   nem pode deixá-lo desaparecer da suíte, que seria a outra metade do erro.
 *
 * Escopo: o código do implantador. `suite/` fica de fora da regra de derivação,
 * por desenho — a suíte NOMEIA checagens que não pode medir (é o que
 * `bloqueadas.php` faz), e isso é declaração de pendência, nunca derivação de
 * veredito. A regra do produtor, ao contrário, varre o pacote INTEIRO: é
 * justamente dentro de `suite/lib/` que o produtor legítimo mora.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_gate_fonte_unica( string $raiz ): array {
	$ancora = f3b_gates_declarados( $raiz );

	if ( array() === $ancora['nomes'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função gates_do_canal() foi encontrada fora de suite/: sem a âncora que declara quais estados '
					. 'decidem a autodesativação, não há como saber o que precisa ter fonte única — e um gate sem âncora '
					. 'é exatamente o terreno em que a segunda derivação passa despercebida',
			),
			'medidas' => 1,
		);
	}

	$estados = array(
		'F3Base_Imp_Relatorio::OK',
		'F3Base_Imp_Relatorio::FALHA',
		'F3Base_Imp_Relatorio::BLOCKED',
		'F3Base_Imp_Relatorio::WARN',
		'F3Base_Imp_Relatorio::NA',
		'F3Base_Imp_Relatorio::WAIVED',
	);

	$literais = array_map( static fn( string $e ): string => "'" . $e . "'", F3Base_Suite::ESTADOS );

	/*
	 * Derivar também acontece por delegação: `avaliar()` e `condicional()`
	 * decidem entre dois estados fechados sem que a palavra OK ou FALHA apareça
	 * na função que as chama. Sem estas marcas, a segunda derivação escaparia
	 * exatamente por ser bem escrita.
	 */
	$emissoras = array(
		'F3Base_Imp_Relatorio::avaliar(',
		'F3Base_Imp_Relatorio::condicional(',
		'F3Base_Imp_Relatorio::emitir(',
		'F3Base_Imp_Relatorio::emitir_unidade(',
	);

	$da_suite   = f3b_vereditos_da_suite( $raiz );
	$procurados = array_values( array_unique( array_merge( $ancora['nomes'], $da_suite['nomes'] ) ) );
	$derivacoes = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			$produz = false;

			foreach ( array_merge( $estados, $literais, $emissoras ) as $marca ) {
				if ( str_contains( $funcao['corpo'], $marca ) ) {
					$produz = true;
					break;
				}
			}

			if ( ! $produz ) {
				continue;
			}

			foreach ( $procurados as $gate ) {
				if ( ! str_contains( $funcao['corpo'], "'" . $gate . "'" ) ) {
					continue;
				}

				$derivacoes[ $gate ]   = $derivacoes[ $gate ] ?? array();
				$derivacoes[ $gate ][] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()';
			}
		}
	}

	$achados = array_merge(
		array(),
		f3b_produtores_do_registro_da_rodada( $raiz ),
		f3b_vereditos_fora_do_lugar( $raiz, $da_suite, $derivacoes )
	);

	foreach ( $ancora['nomes'] as $gate ) {
		$lugares = array_values( array_unique( $derivacoes[ $gate ] ?? array() ) );

		if ( count( $lugares ) > 1 ) {
			$achados[] = 'o estado de gate "' . $gate . '" é derivado em ' . count( $lugares ) . ' lugares: '
				. implode( ' E ', $lugares )
				. ' — duas implementações do mesmo veredito produzem duas respostas para a mesma pergunta no mesmo relatório; '
				. 'quem precisar do veredito depois precisa LER o que a unidade gravou, recebendo o nome por parâmetro';
			continue;
		}

		if ( array() === $lugares ) {
			$achados[] = 'o estado de gate "' . $gate . '" declarado em ' . $ancora['ancora']
				. ' não é derivado em lugar nenhum: gate sem quem o meça fecha sempre pelo caminho da ausência, '
				. 'e ninguém percebe que a medição não existe';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $procurados ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.contagem_com_nomes
 * ---------------------------------------------------------------------- */

/**
 * Fontes de CONTAGEM por estado — quem lê um número de estado do relatório.
 *
 * São chamadas de acessor (`::contagem(`, `::checagens_em_falha(` …), nunca as
 * definições: a definição devolve a propriedade, o acessor é o call-site. E as
 * chaves que a resposta do lote carrega para a tela, que são o mesmo número
 * atravessando a rede.
 *
 * @return array{php:array<int,string>,js:array<int,string>}
 */
function f3b_fontes_de_contagem(): array {
	/*
	 * As marcas de PHP são montadas por pedaços de propósito: escritas inteiras,
	 * esta função conteria as próprias marcas e o detector reprovaria a si
	 * mesmo — o detector que grita por causa de si é tão inútil quanto o que
	 * nunca grita. As de JS não precisam: elas são nomes de chave, e a lista de
	 * nomes logo abaixo já é o que a regra exige na mesma saída.
	 */
	$acessores = array(
		'contagem(',
		'contagem_unidades(',
		'checagens_em_falha(',
		'checagens_em_blocked(',
		'unidades_em_falha(',
		'unidades_em_blocked(',
		'falhas(',
	);

	return array(
		'php' => array_map( static fn( string $acessor ): string => ':' . ':' . $acessor, $acessores ),
		'js'  => array(
			'renderizadas[',
			'renderizadas.',
			'checagens_falha',
			'checagens_blocked',
			'unidades_falha',
			'unidades_blocked',
		),
	);
}

/**
 * Fontes de NOMES por estado — quem devolve a lista que a contagem exige.
 *
 * @return array<int,string>
 */
function f3b_fontes_de_nomes(): array {
	return array(
		'::nomes_por_estado(',
		'::resumo_por_estado(',
		'::nomes_em(',
		'f3b_resumo_por_estado(',
		'nomesPorEstado',
		'nomesRenderizados',
		'checagens_nomes',
		'unidades_nomes',
	);
}

/**
 * Literal que imprime um ESTADO ao lado de um NÚMERO.
 *
 * `%d` e `%1$d` são contagem por construção. `%s` fica de fora: ele carrega
 * tanto número quanto lista de nomes, e acusar por ele transformaria o
 * detector em ruído — o que a regra cobra é que a lista exista, não que o
 * marcador seja de um tipo.
 *
 * @param string $literal Conteúdo do literal.
 * @return bool
 */
function f3b_literal_conta_estado( string $literal ): bool {
	$estados = implode( '|', array_map( static fn( string $e ): string => preg_quote( $e, '/' ), F3Base_Suite::ESTADOS ) );

	$antes  = '/%[0-9]*\$?d\s*(?:[a-zçãáéíóúâêô]+\s+){0,2}(' . $estados . ')(?![A-Za-z0-9_])/u';
	$depois = '/(?<![A-Za-z0-9_])(' . $estados . ')\s*[:=]?\s*%[0-9]*\$?d/u';

	return 1 === preg_match( $antes, $literal ) || 1 === preg_match( $depois, $literal );
}

/**
 * Unidades de saída de um arquivo: cada função nomeada, mais o RESTO do arquivo.
 *
 * O resto existe porque os dois runners da suíte imprimem o resumo em escopo de
 * arquivo, fora de qualquer função — e um detector que só olhasse funções
 * deixaria justamente o rodapé da rodada de fora.
 *
 * @param string $src Código já sem comentário.
 * @return array<int,array{nome:string,corpo:string,linha:int}>
 */
function f3b_unidades_de_saida( string $src ): array {
	$funcoes = f3b_funcoes_do_arquivo( $src );
	$resto   = $src;

	foreach ( $funcoes as $funcao ) {
		$pos = strpos( $resto, $funcao['corpo'] );

		if ( false !== $pos && '' !== $funcao['corpo'] ) {
			$resto = substr_replace( $resto, "\n", $pos, strlen( $funcao['corpo'] ) );
		}
	}

	$funcoes[] = array(
		'nome'  => '(escopo de arquivo)',
		'corpo' => $resto,
		'linha' => 1,
	);

	return $funcoes;
}

/**
 * Nenhuma contagem de estado sai sem a LISTA DE NOMES na mesma saída.
 *
 * O defeito medido, e ele é de instrumento: o cabeçalho do log dizia
 * "checagens do relatório: 5 FALHA e 6 BLOCKED · unidades do plano: 1 FALHA e 2
 * BLOCKED" e as linhas renderizadas mostravam UMA unidade em FALHA. As outras
 * rodavam DENTRO de unidades que fecharam OK e não tinham linha nenhuma. O
 * operador ficava com um número e nenhum nome — nada que ele pudesse abrir,
 * procurar ou corrigir. Contagem sem nome não responde à pergunta que ele faz
 * em seguida, que é sempre "quais?".
 *
 * A regra, executável: toda unidade de saída (função nomeada, ou o escopo de
 * arquivo) que LEIA uma contagem por estado — ou que imprima um literal com um
 * estado ao lado de um número — precisa referenciar, no mesmo corpo, uma fonte
 * de NOMES por estado. Estado OK continua podendo sair resumido: o que a regra
 * proíbe é estado ruim invisível.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_contagem_com_nomes( string $raiz ): array {
	$fontes  = f3b_fontes_de_contagem();
	$nomes   = f3b_fontes_de_nomes();
	$achados = array();
	$medidas = 0;

	foreach ( f3b_arquivos( $raiz, array( 'php', 'js', 'mjs' ), f3b_excluidos() ) as $rel ) {
		$extensao = strtolower( (string) pathinfo( $rel, PATHINFO_EXTENSION ) );
		$caminho  = $raiz . '/' . $rel;
		$src      = 'php' === $extensao ? f3b_codigo_php( $caminho ) : f3b_codigo_js( $caminho );
		$contam   = 'php' === $extensao ? $fontes['php'] : $fontes['js'];

		foreach ( f3b_unidades_de_saida( $src ) as $unidade ) {
			$corpo = $unidade['corpo'];

			if ( '' === trim( $corpo ) ) {
				continue;
			}

			++$medidas;

			$motivo = '';

			foreach ( $contam as $marca ) {
				if ( str_contains( $corpo, $marca ) ) {
					$motivo = 'lê a contagem por estado em "' . $marca . '"';
					break;
				}
			}

			if ( '' === $motivo && preg_match_all( '/([\'"])((?:\\\\.|(?!\1).)*)\1/s', $corpo, $ms ) ) {
				foreach ( $ms[2] as $literal ) {
					if ( f3b_literal_conta_estado( $literal ) ) {
						$motivo = 'imprime um estado ao lado de um número em "' . trim( mb_substr( $literal, 0, 60 ) ) . '…"';
						break;
					}
				}
			}

			if ( '' === $motivo ) {
				continue;
			}

			$nomeia = false;

			foreach ( $nomes as $marca ) {
				if ( str_contains( $corpo, $marca ) ) {
					$nomeia = true;
					break;
				}
			}

			if ( $nomeia ) {
				continue;
			}

			$achados[] = $rel . ':' . $unidade['linha'] . ' ' . $unidade['nome']
				. ' ' . $motivo . ' e NÃO produz a lista de nomes correspondente na mesma saída: '
				. 'contagem de estado sem nome responde "quantos?" e a pergunta do operador é "quais?". '
				. 'Use uma das fontes de nomes declaradas (' . implode( ', ', $nomes ) . ')';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Fonte JavaScript sem comentário, com as linhas preservadas.
 *
 * A varredura mede o que EXECUTA, aqui pela mesma razão que em PHP: a prosa que
 * explica a armadilha cita a armadilha, e reprovar o arquivo correto por causa
 * do comentário que o explica é o detector gritando por causa de si mesmo.
 *
 * @param string $caminho Caminho absoluto.
 * @return string
 */
function f3b_codigo_js( string $caminho ): string {
	$src   = (string) file_get_contents( $caminho );
	$saida = '';
	$tam   = strlen( $src );
	$i     = 0;

	while ( $i < $tam ) {
		$par = substr( $src, $i, 2 );

		if ( '/*' === $par ) {
			$fim    = strpos( $src, '*/', $i + 2 );
			$fim    = false === $fim ? $tam : $fim + 2;
			$saida .= str_repeat( "\n", substr_count( substr( $src, $i, $fim - $i ), "\n" ) );
			$i      = $fim;
			continue;
		}

		if ( '//' === $par ) {
			$fim = strpos( $src, "\n", $i );
			$i   = false === $fim ? $tam : $fim;
			continue;
		}

		if ( '\'' === $src[ $i ] || '"' === $src[ $i ] ) {
			$aspas  = $src[ $i ];
			$saida .= $aspas;
			++$i;

			while ( $i < $tam && $src[ $i ] !== $aspas ) {
				if ( '\\' === $src[ $i ] && $i + 1 < $tam ) {
					$saida .= substr( $src, $i, 2 );
					$i     += 2;
					continue;
				}

				$saida .= $src[ $i ];
				++$i;
			}

			if ( $i < $tam ) {
				$saida .= $aspas;
				++$i;
			}

			continue;
		}

		$saida .= $src[ $i ];
		++$i;
	}

	return $saida;
}

/* -------------------------------------------------------------------------
 * estatica.unidade_reflete_internas
 * ---------------------------------------------------------------------- */

/**
 * Estados fechados como o código do implantador os escreve, normalizados.
 *
 * `self::NA` e `F3Base_Imp_Relatorio::NA` valem pelo estado `N/A`; o literal
 * entre aspas vale por si. A tabela mora aqui porque é tradução de GRAFIA, não
 * declaração de ordem — a ordem sai do pacote varrido, e é isso que este
 * detector confere.
 *
 * @return array<string,string> Sufixo da constante => estado fechado.
 */
function f3b_grafias_de_estado(): array {
	return array(
		'OK'      => 'OK',
		'FALHA'   => 'FALHA',
		'BLOCKED' => 'BLOCKED',
		'NA'      => 'N/A',
		'WAIVED'  => 'WAIVED',
		'WARN'    => 'WARN',
	);
}

/**
 * ONDE o pacote declara a ordem de severidade, e qual ordem ele declara.
 *
 * Uma DECLARAÇÃO DE ORDEM é um bloco em que ao menos quatro dos seis estados
 * fechados recebem um inteiro, e em que esses inteiros não são todos iguais. A
 * segunda condição é o que separa a ordem do CONTADOR: `array( OK => 0, FALHA
 * => 0, … )` mapeia os seis estados a um inteiro e não ordena coisa alguma.
 *
 * A ordem sai do PACOTE VARRIDO, nunca de uma lista escrita aqui — pelo mesmo
 * motivo que os nomes de gate saem da função âncora: uma segunda declaração na
 * suíte seria a segunda fonte para o fato que este detector existe para manter
 * único.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{lugares:array<int,string>,ordem:array<string,int>}
 */
function f3b_declaracoes_de_severidade( string $raiz ): array {
	$grafias = f3b_grafias_de_estado();

	/*
	 * A expressão é montada por `sprintf()`, e não por concatenação: um literal
	 * PHP com `=>` colado a um ponto de concatenação é acusado por
	 * `estatica.detector_codigo_em_string`, que lê `=>` como arrow function.
	 * Reescrever o outro detector para abrir exceção a este seria enfraquecer a
	 * regra por conveniência de quem a viola.
	 */
	$re = sprintf(
		'/(?:self|F3Base_Imp_Relatorio)::(%1$s)\s*%2$s\s*(\d+)|\'(%3$s)\'\s*%2$s\s*(\d+)/',
		implode( '|', array_keys( $grafias ) ),
		preg_quote( '=>', '/' ),
		implode( '|', array_map( static fn( string $e ): string => preg_quote( $e, '/' ), array_values( $grafias ) ) )
	);

	$lugares = array();
	$ordem   = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( $re, $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			continue;
		}

		$grupo    = array();
		$primeira = 0;
		$anterior = -10;

		/* Fecha o grupo corrente e o registra quando ele for uma ordem. */
		$fechar = static function () use ( &$grupo, &$primeira, &$lugares, &$ordem, $rel ): void {
			if ( count( $grupo ) < 4 || count( array_unique( array_values( $grupo ) ) ) < 2 ) {
				$grupo = array();
				return;
			}

			$lugares[] = $rel . ':' . $primeira;

			if ( array() === $ordem ) {
				$ordem = $grupo;
			}

			$grupo = array();
		};

		foreach ( $ms as $m ) {
			$pos   = (int) $m[0][1];
			$linha = substr_count( substr( $src, 0, $pos ), "\n" ) + 1;

			if ( $linha - $anterior > 3 ) {
				$fechar();
				$primeira = $linha;
			}

			$anterior = $linha;

			$estado = '' !== (string) $m[1][0] ? $grafias[ (string) $m[1][0] ] : (string) ( $m[3][0] ?? '' );
			$peso   = '' !== (string) $m[1][0] ? (int) $m[2][0] : (int) ( $m[4][0] ?? 0 );

			if ( '' !== $estado ) {
				$grupo[ $estado ] = $peso;
			}
		}

		$fechar();
	}

	return array(
		'lugares' => $lugares,
		'ordem'   => $ordem,
	);
}

/**
 * Funções do pacote que APLICAM o helper único de severidade.
 *
 * Existe porque a aplicação é de DOIS SALTOS por desenho: `processar()` chama
 * `veredito_da_unidade()`, e é esta que compara. Exigir a marca literal dentro
 * de quem emite a linha da unidade obrigaria a promoção a morar no orquestrador
 * inteiro em vez de numa função que o piso consegue exercitar.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<string,bool> Nome da função => ela consulta o gate que decide?
 */
function f3b_promotoras_de_severidade( string $raiz ): array {
	$funcoes = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		foreach ( f3b_funcoes_do_arquivo( f3b_codigo_php( $raiz . '/' . $rel ) ) as $funcao ) {
			$funcoes[ $funcao['nome'] ] = ( $funcoes[ $funcao['nome'] ] ?? '' ) . $funcao['corpo'];
		}
	}

	/*
	 * CIÊNCIA DO GATE É TRANSITIVA, como a aplicação do helper: a função que
	 * compara pode delegar o teste de gate a uma função de uma linha — e é o que
	 * o pacote faz, porque a regra tem um caso de borda (gate vazio) que uma
	 * comparação repetida em três pontos erra. Exigir a marca literal dentro de
	 * quem compara obrigaria a regra a morar inline, que é o contrário do que a
	 * própria borda ensinou.
	 */
	$cientes = array();

	foreach ( $funcoes as $nome_da_funcao => $corpo ) {
		if ( str_contains( $corpo, 'GATE_QUE_DECIDE' ) ) {
			$cientes[ $nome_da_funcao ] = true;
		}
	}

	$nomes = array();

	foreach ( $funcoes as $nome_da_funcao => $corpo ) {
		if ( ! str_contains( $corpo, 'estado_mais_severo(' ) ) {
			continue;
		}

		$ciente = isset( $cientes[ $nome_da_funcao ] );

		foreach ( array_keys( $cientes ) as $delegada ) {
			$ciente = $ciente || str_contains( $corpo, $delegada . '(' );
		}

		$nomes[ $nome_da_funcao ] = $ciente;
	}

	return $nomes;
}

/**
 * Listas de linhas de relatório dentro de uma estrutura já analisada.
 *
 * Uma lista de linhas é uma lista cujos itens todos têm `estado` e `nome`, e em
 * que ao menos um está marcado como `unidade`. É a forma exata do acumulador do
 * relatório, e é o registro que o operador baixa da tela.
 *
 * @param array<mixed> $valor Estrutura analisada.
 * @return array<int,array<int,array<string,mixed>>>
 */
function f3b_listas_de_linhas( array $valor ): array {
	$saida       = array();
	$e_lista     = array() !== $valor;
	$tem_unidade = false;

	foreach ( $valor as $item ) {
		if ( ! is_array( $item ) || ! isset( $item['estado'] ) || ! isset( $item['nome'] ) ) {
			$e_lista = false;
			break;
		}

		$tem_unidade = $tem_unidade || ! empty( $item['unidade'] );
	}

	if ( $e_lista && $tem_unidade ) {
		$saida[] = array_values( $valor );
	}

	foreach ( $valor as $filho ) {
		if ( is_array( $filho ) ) {
			$saida = array_merge( $saida, f3b_listas_de_linhas( $filho ) );
		}
	}

	return $saida;
}

/**
 * Unidades que fecharam em estado MENOS severo do que uma checagem SUA E DO
 * GATE QUE DECIDE.
 *
 * A varredura reproduz a ordem real de emissão: as checagens saem primeiro, a
 * linha da unidade sai depois e fecha o bloco. Cada achado NOMEIA AS DUAS — a
 * unidade e a checagem —, porque "há incoerência no relatório" não é coisa que
 * o operador possa abrir.
 *
 * A DISTINÇÃO DE GATE, e por que ela não é uma exceção conveniente: checagem
 * cuja evidência este host não produz — navegador, campo, suíte externa — é
 * relatada e não decide, exatamente como no gate da autodesativação. Sem isso a
 * unidade `entrega`, que emite `orcamento.medicao_de_pagina` em BLOCKED por
 * natureza, fecharia BLOCKED em toda instalação, para sempre, por desenho.
 *
 * O gate que decide sai do PACOTE VARRIDO, não de uma constante escrita aqui, e
 * gate AUSENTE conta como gate que decide: a omissão não pode ser o caminho
 * barato para escapar da promoção.
 *
 * @param array<int,array<string,mixed>> $linhas  Linhas do registro, na ordem.
 * @param array<string,int>              $ordem   Ordem de severidade do pacote.
 * @param string                         $arquivo Arquivo do registro, para o achado.
 * @param string                         $decide  Gate cuja checagem decide o veredito.
 * @return array<int,string> Achados.
 */
function f3b_unidades_menos_severas( array $linhas, array $ordem, string $arquivo, string $decide ): array {
	$achados = array();
	$bloco   = array();

	foreach ( $linhas as $linha ) {
		$estado = (string) ( $linha['estado'] ?? '' );
		$nome   = (string) ( $linha['nome'] ?? '' );
		/* Gate ausente OU VAZIO conta como o gate que decide: a omissão não absolve. */
		$gate   = '' !== (string) ( $linha['gate'] ?? '' ) ? (string) $linha['gate'] : $decide;

		if ( empty( $linha['unidade'] ) ) {
			$bloco[] = array( $nome, $estado, $gate );
			continue;
		}

		$peso_da_unidade = $ordem[ $estado ] ?? -1;

		foreach ( $bloco as $interna ) {
			if ( $decide !== $interna[2] ) {
				continue;
			}

			$peso_da_interna = $ordem[ $interna[1] ] ?? -1;

			if ( $peso_da_interna > $peso_da_unidade ) {
				$achados[] = $arquivo . ': a unidade "' . $nome . '" fechou ' . $estado
					. ' contendo a checagem "' . $interna[0] . '" em ' . $interna[1]
					. ', do gate ' . $decide . ' — quem lê o resumo por unidade vê verde onde há vermelho';
			}
		}

		$bloco = array();
	}

	return $achados;
}

/**
 * O GATE QUE DECIDE o veredito da unidade, declarado pelo pacote varrido.
 *
 * Como a ordem de severidade e como os nomes de gate do canal: o valor sai da
 * âncora do próprio pacote. Uma constante escrita na suíte seria a segunda
 * declaração do mesmo fato — e um pacote que mudasse a sua passaria a ser
 * medido pela régua errada, calada.
 *
 * @param string $raiz Raiz a varrer.
 * @return string Gate declarado, ou vazio quando o pacote não declara nenhum.
 */
function f3b_gate_que_decide( string $raiz ): string {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( preg_match( '/const\s+GATE_QUE_DECIDE\s*=\s*\'([a-z_]+)\'/', $src, $m ) ) {
			return (string) $m[1];
		}
	}

	return '';
}

/**
 * NENHUMA UNIDADE FECHA EM ESTADO MENOS SEVERO DO QUE O QUE ELA MEDIU.
 *
 * O defeito medido na 1.0.8, com as duas linhas verbatim: a linha 48 do
 * relatório era `OK entrega — "todos os entregáveis do gate de aplicação
 * fecharam sem BLOCKED"` e a linha 49, DENTRO dela, era
 * `FALHA ↳ mcp.canal_unico`. Quem lê o resumo por unidade vê verde onde há
 * vermelho, e foi essa mesma discrepância que escondeu as FALHAs até a 1.0.7.
 *
 * Três regras, e cada uma fecha uma porta diferente:
 *
 * 1. **Quem emite a linha de uma unidade aplica a promoção.** Toda função que
 *    chama `emitir_unidade()` precisa passar por `estado_mais_severo()`, direta
 *    ou pela função que o aplica. Sem isso a regra vira convenção, e convenção
 *    é o que a próxima etapa esquece.
 * 2. **A ordem de severidade é declarada em UM lugar.** Duas declarações
 *    divergem, e a divergência sai como um relatório que se contradiz — foi
 *    exatamente assim que a ordem viveu em `F3Base_Imp_Plugins` enquanto o
 *    orquestrador não tinha nenhuma.
 * 3. **A promoção é POR GATE, e o gate que decide é declarado.** Sem a âncora
 *    `GATE_QUE_DECIDE` e sem uma promotora que a consulte, a promoção é cega: a
 *    unidade `entrega`, que emite `orcamento.medicao_de_pagina` em BLOCKED por
 *    natureza, fecharia BLOCKED em toda instalação, para sempre, por desenho —
 *    a mesma armadilha que a 1.0.7 desfez no gate da autodesativação.
 * 4. **Nenhum registro de relatório do pacote contém unidade menos severa que
 *    uma checagem sua DO GATE QUE DECIDE.** É a regra medida sobre DADOS, e é
 *    ela que acusa nomeando as duas linhas. Fica inerte quando o pacote não
 *    carrega registro nenhum — o log de execução mora em option, no host —, e é
 *    no piso que ela prova saber acusar, dos dois lados: acusa a interna de
 *    aplicação e cala sobre a de fase, para que a distinção de gate não vire a
 *    porta de escape que absolve qualquer coisa marcada como fase.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_unidade_reflete_internas( string $raiz ): array {
	$achados    = array();
	$declaracao = f3b_declaracoes_de_severidade( $raiz );
	$promotoras = f3b_promotoras_de_severidade( $raiz );
	$decide     = f3b_gate_que_decide( $raiz );
	$medidas    = 0;

	if ( array() === $declaracao['lugares'] ) {
		$achados[] = 'nenhuma declaração de ordem de severidade foi encontrada fora de suite/: sem a ordem, '
			. '"estado mais severo" não quer dizer nada e a promoção do veredito da unidade não pode ser conferida';
	}

	if ( '' === $decide ) {
		$achados[] = 'nenhuma âncora GATE_QUE_DECIDE foi encontrada fora de suite/: sem declarar QUAL gate decide o '
			. 'veredito da unidade, a promoção é cega — ou engole a evidência de fase que o host não produz e trava a '
			. 'unidade em BLOCKED para sempre, ou não promove nada';
	}

	if ( count( $declaracao['lugares'] ) > 1 ) {
		$achados[] = 'a ordem de severidade é declarada em ' . count( $declaracao['lugares'] ) . ' lugares: '
			. implode( ' E ', $declaracao['lugares'] )
			. ' — duas ordens divergem, e a divergência sai como um relatório que se contradiz; a ordem mora em um lugar só';
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), array_merge( f3b_excluidos(), array( 'suite/' ) ) ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( ! str_contains( $funcao['corpo'], 'emitir_unidade(' ) ) {
				continue;
			}

			++$medidas;


			$aplica         = false;
			$ciente_do_gate = str_contains( $funcao['corpo'], 'GATE_QUE_DECIDE' );

			foreach ( $promotoras as $promotora => $olha_o_gate ) {
				if ( str_contains( $funcao['corpo'], $promotora . '(' ) ) {
					$aplica         = true;
					$ciente_do_gate = $ciente_do_gate || $olha_o_gate;
				}
			}

			if ( ! $aplica ) {
				$achados[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome']
					. '() emite a linha de uma unidade sem passar o estado por estado_mais_severo(), nem direta '
					. 'nem por quem o aplica: a unidade pode fechar em estado menos severo do que a checagem que '
					. 'ela mesma emitiu, que é o OK por cima de uma FALHA';
				continue;
			}

			if ( '' !== $decide && ! $ciente_do_gate ) {
				$achados[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome']
					. '() promove o veredito da unidade sem olhar o GATE da checagem: promoção cega engole a '
					. 'evidência que este host não produz — a medição de página, de navegador, é BLOCKED por '
					. 'natureza — e trava a unidade em BLOCKED em toda instalação, para sempre, por desenho';
			}
		}
	}

	if ( array() !== $declaracao['ordem'] && '' !== $decide ) {
		foreach ( f3b_arquivos( $raiz, array( 'json' ), f3b_excluidos() ) as $rel ) {
			$json = json_decode( (string) file_get_contents( $raiz . '/' . $rel ), true );

			if ( ! is_array( $json ) ) {
				continue;
			}

			foreach ( f3b_listas_de_linhas( $json ) as $linhas ) {
				++$medidas;
				$achados = array_merge( $achados, f3b_unidades_menos_severas( $linhas, $declaracao['ordem'], $rel, $decide ) );
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.option_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * Prefixos que ficam FORA da varredura de produtores de option.
 *
 * O escopo é o código do IMPLANTADOR — a raiz e `includes/`. `fontes/` traz o
 * catálogo de options do `site-core`, que DECLARA a forma e o padrão de cada
 * uma (`'f3base_redirects' => array( 'padrao' => …, 'sanitiza' => … )`) e não
 * produz valor desejado de implantação nenhum; contá-lo como produtor faria o
 * detector acusar a declaração do dono da option. `suite/` e `content/` não
 * gravam options.
 *
 * @return array<int,string>
 */
function f3b_fora_do_escopo_de_option(): array {
	return array_merge( f3b_excluidos(), array( 'fontes/', 'suite/', 'content/' ) );
}

/**
 * Nomes de option GERENCIADA, lidos da âncora `options_gerenciadas()`.
 *
 * Como em `f3b_gates_declarados()`, a lista sai do PRÓPRIO PACOTE: escrevê-la
 * na suíte seria a segunda fonte para o mesmo fato — precisamente o que este
 * detector existe para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{nomes:array<int,string>,ancora:string}
 */
function f3b_options_gerenciadas_declaradas( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), 'options_gerenciadas' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([A-Za-z_][A-Za-z0-9_]*)'/", $corpo, $ms );

		return array(
			'nomes'  => array_values( array_unique( $ms[1] ) ),
			'ancora' => $rel,
		);
	}

	return array(
		'nomes'  => array(),
		'ancora' => '',
	);
}

/**
 * O mapa option => função de união, lido da âncora `uniao_declarada()`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{mapa:array<string,string>,ancora:string}
 */
function f3b_uniao_declarada( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), 'uniao_declarada' );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'\s*=>\s*'([^']+)'/", $corpo, $ms, PREG_SET_ORDER );

		$mapa = array();

		foreach ( $ms as $m ) {
			$mapa[ $m[1] ] = $m[2];
		}

		return array(
			'mapa'   => $mapa,
			'ancora' => $rel,
		);
	}

	return array(
		'mapa'   => array(),
		'ancora' => '',
	);
}

/**
 * A expressão de VALOR que começa em `$pos`, até a vírgula ou o fecho do nível.
 *
 * Lê com parênteses, colchetes e chaves balanceados, para que
 * `array( 'a' => b( 1, 2 ) )` não seja cortado na vírgula de dentro.
 *
 * @param string $src Código.
 * @param int    $pos Posição do primeiro caractere da expressão.
 * @return string
 */
function f3b_expressao_de_valor( string $src, int $pos ): string {
	$tam   = strlen( $src );
	$nivel = 0;
	$buf   = '';

	for ( $i = $pos; $i < $tam; $i++ ) {
		$c = $src[ $i ];

		if ( '(' === $c || '[' === $c || '{' === $c ) {
			$nivel++;
		}

		if ( ')' === $c || ']' === $c || '}' === $c ) {
			if ( 0 === $nivel ) {
				break;
			}

			$nivel--;
		}

		if ( 0 === $nivel && ( ',' === $c || ';' === $c ) ) {
			break;
		}

		$buf .= $c;
	}

	return trim( preg_replace( '/\s+/', ' ', $buf ) ?? '' );
}

/**
 * O nome da função que envolve uma posição do código.
 *
 * @param string $src Código.
 * @param int    $pos Posição.
 * @return string
 */
function f3b_funcao_envolvente( string $src, int $pos ): string {
	if ( ! preg_match_all( '/function\s+(\w+)\s*\(/', substr( $src, 0, $pos ), $ms, PREG_SET_ORDER ) ) {
		return '(escopo de arquivo)';
	}

	$ultimo = end( $ms );

	return (string) $ultimo[1];
}

/**
 * Constantes de classe que valem uma cadeia literal, no escopo do implantador.
 *
 * Existe porque o nome da option NEM SEMPRE aparece como literal no ponto da
 * gravação: `F3Base_Imp_Navegacao::OPTION` é o nome de uma option gerenciada
 * escrito de outro jeito, e um detector que só enxergasse aspas contaria um
 * produtor onde há dois — que é o buraco por onde este defeito entrou.
 *
 * A resolução é POR CLASSE, nunca por nome solto de constante: duas classes
 * deste pacote declaram `const OPTION`, com valores diferentes, e um mapa
 * global as confundiria — ou, o que é pior, descartaria as duas e voltaria a
 * não enxergar a forma que importa.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{por_arquivo:array<string,array<string,string>>,qualificadas:array<string,string>}
 */
function f3b_constantes_de_classe( string $raiz ): array {
	$por_arquivo  = array();
	$qualificadas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( ! preg_match_all( "/const\s+([A-Z][A-Z0-9_]*)\s*=\s*'([^']*)'/", $src, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		$classe                = preg_match( '/\bclass\s+(\w+)/', $src, $mc ) ? (string) $mc[1] : '';
		$por_arquivo[ $rel ]   = array();

		foreach ( $ms as $m ) {
			$por_arquivo[ $rel ][ $m[1] ] = $m[2];

			if ( '' !== $classe ) {
				$qualificadas[ $classe . '::' . $m[1] ] = $m[2];
			}
		}
	}

	return array(
		'por_arquivo'  => $por_arquivo,
		'qualificadas' => $qualificadas,
	);
}

/**
 * Pontos do código que PRODUZEM o valor desejado de uma option.
 *
 * Duas formas, e as duas precisam contar — foi justamente a diferença entre
 * elas que escondeu o defeito medido: a etapa de permalinks passava o valor
 * DIRETO ao gravador, e a etapa de options do `site-core` o passava dentro de
 * um mapa `option => valor` que um laço grava depois. Procurar só a chamada
 * direta enxergaria um produtor onde havia dois.
 *
 * Menção não é produção: `get_option( 'nome' )`, `in_array( 'nome', … )` e a
 * lista de nomes da âncora não ligam o nome a um valor desejado, e não entram.
 *
 * @param string            $raiz  Raiz a varrer.
 * @param array<int,string> $nomes Options gerenciadas.
 * @return array<string,array<int,array{onde:string,expr:string}>>
 */
function f3b_produtores_de_option( string $raiz, array $nomes ): array {
	$produtores = array();
	/*
	 * ÂNCORAS não são produtores. Elas DECLARAM, em pares `chave => valor`, o
	 * que o pacote afirma sobre si — e o nome de uma option dentro de uma delas
	 * é declaração, não gravação. Sem esta lista, a âncora que nomeia o produtor
	 * de cada seleção de llms.txt seria contada como um segundo ponto produzindo
	 * o valor de `f3base_llms`, e o detector acusaria a própria declaração.
	 */
	$ancoras    = array( 'uniao_declarada', 'options_gerenciadas', 'produtor_de_item_llms' );
	$constantes = f3b_constantes_de_classe( $raiz );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src     = f3b_codigo_php( $raiz . '/' . $rel );
		$achados = array();

		foreach ( $nomes as $nome ) {
			$literal = preg_quote( $nome, '/' );

			/*
			 * As duas expressões são montadas por `sprintf()`, e não por
			 * concatenação: a seta do elemento de array é uma das marcas de
			 * JavaScript de `f3b_linguagem_em_texto()`, e um literal com ela
			 * colado por `.` faria `estatica.detector_codigo_em_string`
			 * reprovar ESTE detector. É a mesma saída que `$re_inline` já usa
			 * lá — o detector que grita por causa de si é tão inútil quanto o
			 * que nunca grita.
			 */
			foreach (
				array(
					sprintf( '/F3Base_Imp_Gravador::gravar(?:_chaves)?\(\s*\'%s\'\s*,\s*/', $literal ),
					sprintf( '/\'%s\'\s*=>\s*/', $literal ),
				) as $re
			) {
				if ( ! preg_match_all( $re, $src, $ms, PREG_OFFSET_CAPTURE ) ) {
					continue;
				}

				foreach ( $ms[0] as $m ) {
					$achados[] = array(
						'nome' => $nome,
						'pos'  => (int) $m[1],
						'fim'  => (int) $m[1] + strlen( (string) $m[0] ),
					);
				}
			}
		}

		/* A MESMA option escrita pelo nome de uma constante de classe. */
		foreach (
			array(
				'/F3Base_Imp_Gravador::gravar(?:_chaves)?\(\s*(self|static|[A-Za-z_][A-Za-z0-9_]*)::([A-Z][A-Z0-9_]*)\s*,\s*/',
				'/(self|static|[A-Za-z_][A-Za-z0-9_]*)::([A-Z][A-Z0-9_]*)\s*=>\s*/',
			) as $re
		) {
			if ( ! preg_match_all( $re, $src, $ms, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $ms as $m ) {
				$escopo    = (string) $m[1][0];
				$resolvida = in_array( $escopo, array( 'self', 'static' ), true )
					? (string) ( $constantes['por_arquivo'][ $rel ][ $m[2][0] ] ?? '' )
					: (string) ( $constantes['qualificadas'][ $escopo . '::' . $m[2][0] ] ?? '' );

				if ( ! in_array( $resolvida, $nomes, true ) ) {
					continue;
				}

				$achados[] = array(
					'nome' => $resolvida,
					'pos'  => (int) $m[0][1],
					'fim'  => (int) $m[0][1] + strlen( (string) $m[0][0] ),
				);
			}
		}

		foreach ( $achados as $achado ) {
			$funcao = f3b_funcao_envolvente( $src, $achado['pos'] );

			if ( in_array( $funcao, $ancoras, true ) ) {
				continue;
			}

			$produtores[ $achado['nome'] ][] = array(
				'onde' => $rel . ':' . ( substr_count( substr( $src, 0, $achado['pos'] ), "\n" ) + 1 ) . ' ' . $funcao . '()',
				'expr' => f3b_expressao_de_valor( $src, $achado['fim'] ),
			);
		}
	}

	return $produtores;
}

/**
 * Nenhuma option gerenciada com dois produtores de valor desejado fora da união.
 *
 * O DEFEITO MEDIDO NO BANCO DEPOIS DA 1.0.11. `f3base_redirects` ficou em
 * `a:0:{}` e o log da mesma execução afirmava "permalinks aplicada para
 * /%postname%/, com 2 URL(s) antiga(s) respondendo por redirecionamento
 * declarado". As duas coisas eram verdadeiras: a etapa de permalinks computou
 * os pares, gravou e leu de volta; mais adiante, a etapa `site_core.options`
 * gravou a MESMA option a partir de `redirects: []` do arquivo de configuração,
 * gravou e leu de volta. Duas fontes de valor desejado, duas mensagens
 * verdadeiras, um artefato que contradiz a primeira — e as URLs antigas dos
 * dois posts respondendo 404 em vez de 301.
 *
 * A regra: option gerenciada pode ter quantas FONTES o projeto precisar, e um
 * ponto só produzindo o valor desejado. Havendo dois, os dois precisam passar
 * pela função de UNIÃO declarada em `uniao_declarada()` — e, quando passam,
 * este detector fica em silêncio, porque aí não existem duas respostas: existe
 * uma resposta com várias parcelas.
 *
 * É a terceira vez neste ciclo que duas fontes para o mesmo fato produzem
 * relatório contraditório — `estatica.gate_fonte_unica` cobre o veredito e o
 * artefato da rodada; esta cobre a OPTION. A prosa não segurou nas duas
 * anteriores.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_option_fonte_unica( string $raiz ): array {
	$gerenciadas = f3b_options_gerenciadas_declaradas( $raiz );
	$uniao       = f3b_uniao_declarada( $raiz );

	if ( array() === $gerenciadas['nomes'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função options_gerenciadas() foi encontrada no código do implantador: sem a âncora que declara '
					. 'QUAIS options são gerenciadas por este pacote, não há como saber sobre o que a regra de fonte '
					. 'única vale — e uma regra sem escopo é uma regra que nunca acusa nada',
			),
			'medidas' => 1,
		);
	}

	$produtores = f3b_produtores_de_option( $raiz, $gerenciadas['nomes'] );
	$achados    = array();

	foreach ( $gerenciadas['nomes'] as $nome ) {
		$lugares = $produtores[ $nome ] ?? array();
		$funcao  = (string) ( $uniao['mapa'][ $nome ] ?? '' );

		if ( count( $lugares ) < 2 ) {
			continue;
		}

		$fora = array();

		foreach ( $lugares as $lugar ) {
			if ( '' === $funcao || ! str_contains( $lugar['expr'], $funcao . '(' ) ) {
				$fora[] = $lugar['onde'] . ' produz «' . $lugar['expr'] . '»';
			}
		}

		if ( array() === $fora ) {
			continue;
		}

		$achados[] = 'a option gerenciada "' . $nome . '" tem ' . count( $lugares ) . ' ponto(s) do código produzindo o '
			. 'valor desejado, e ' . count( $fora ) . ' dele(s) NÃO passa(m) pela função de união declarada'
			. ( '' === $funcao ? ' (nenhuma união está declarada para esta option em uniao_declarada())' : ' ' . $funcao . '()' )
			. ': ' . implode( ' E ', array_map( static fn( array $l ): string => $l['onde'] . ' produz «' . $l['expr'] . '»', $lugares ) )
			. ' — a segunda a rodar apaga o que a primeira gravou, as duas leem de volta, as duas conferem, e o relatório '
			. 'sai com duas mensagens verdadeiras e contraditórias sobre o mesmo artefato';
	}

	/*
	 * União declarada para option que não existe, ou apontando para função que
	 * ninguém definiu: a declaração passaria a absolver sozinha, e o detector
	 * ficaria em silêncio por não ter o que medir.
	 */
	foreach ( $uniao['mapa'] as $nome => $funcao ) {
		if ( ! in_array( $nome, $gerenciadas['nomes'], true ) ) {
			$achados[] = 'uniao_declarada() declara união para "' . $nome . '", que não consta das options gerenciadas '
				. 'declaradas em ' . $gerenciadas['ancora'] . ': declaração sem alvo absolve sem medir';
			continue;
		}

		$definida = false;

		foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
			if ( null !== f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $funcao ) ) {
				$definida = true;
				break;
			}
		}

		if ( ! $definida ) {
			$achados[] = 'uniao_declarada() aponta "' . $nome . '" para ' . $funcao . '(), que não está definida em '
				. 'lugar nenhum do código do implantador: a união declarada e ausente é pior que a união inexistente, '
				. 'porque ela faz o detector calar';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $gerenciadas['nomes'] ),
	);
}

/* -------------------------------------------------------------------------
 * estatica.pagina_status_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * Mapa `chave => valor` declarado por uma função-ÂNCORA do pacote.
 *
 * Mesma construção de `f3b_uniao_declarada()`, generalizada: a suíte LÊ do
 * próprio pacote o que ele declara sobre si, em vez de manter uma cópia. Cópia
 * é a segunda fonte para o mesmo fato, que é o defeito que estas regras
 * existem para impedir.
 *
 * @param string $raiz Raiz a varrer.
 * @param string $nome Nome da função-âncora.
 * @return array{mapa:array<string,string>,ancora:string}
 */
function f3b_ancora_mapa( string $raiz, string $nome ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $nome );

		if ( null === $corpo ) {
			continue;
		}

		preg_match_all( "/'([^']+)'\s*=>\s*'([^']*)'/", $corpo, $ms, PREG_SET_ORDER );

		$mapa = array();

		foreach ( $ms as $m ) {
			$mapa[ $m[1] ] = $m[2];
		}

		return array(
			'mapa'   => $mapa,
			'ancora' => $rel,
		);
	}

	return array(
		'mapa'   => array(),
		'ancora' => '',
	);
}

/**
 * A função existe em algum arquivo do implantador?
 *
 * @param string $raiz Raiz a varrer.
 * @param string $nome Nome da função.
 * @return bool
 */
function f3b_funcao_existe( string $raiz, string $nome ): bool {
	if ( '' === $nome ) {
		return false;
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		if ( null !== f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $nome ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Funções que LEEM um caminho de configuração, atribuídas por função.
 *
 * O caminho é normalizado do jeito que `estatica.detector_chave_sem_consumidor`
 * já normaliza — índice dinâmico vira `*` —, para que `'paginas.' . $indice .
 * '.status'` e `'paginas.0.status'` sejam o mesmo caminho.
 *
 * @param string $raiz Raiz a varrer.
 * @param string $alvo Caminho normalizado procurado.
 * @return array<int,array{onde:string,nome:string,corpo:string}>
 */
function f3b_leitores_de_caminho( string $raiz, string $alvo ): array {
	$leitores = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			foreach ( f3b_chamadas_regex( $funcao['corpo'], F3B_RE_CONFIG ) as $args ) {
				$caminho = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args ) ) );

				if ( $caminho !== $alvo ) {
					continue;
				}

				$leitores[] = array(
					'onde'  => $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()',
					'nome'  => $funcao['nome'],
					'corpo' => $funcao['corpo'],
				);
				continue 2;
			}
		}
	}

	return $leitores;
}

/**
 * Funções que produzem o `post_status` DESEJADO de uma página gerenciada.
 *
 * A discriminação é dupla e as duas metades importam:
 *
 * - **`'post_type' => 'page'` literal** no corpo, que é o que separa página de
 *   `wp_navigation` e dos outros tipos — o menu é post e o status dele nunca
 *   foi decisão editorial deste pacote.
 * - **`post_status` com valor que NÃO é `array(`**, que é o que separa valor
 *   DESEJADO de filtro de consulta: toda busca deste pacote passa uma lista de
 *   status, e contar uma consulta como decisão de publicação faria o detector
 *   acusar `get_posts()`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array<int,array{onde:string,nome:string,corpo:string,expr:string}>
 */
function f3b_produtores_de_status_de_pagina( string $raiz ): array {
	$produtores = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( ! preg_match( "/'post_type'\s*=>\s*'page'/", $funcao['corpo'] ) ) {
				continue;
			}

			if ( ! preg_match_all( "/'post_status'\s*=>\s*/", $funcao['corpo'], $ms, PREG_OFFSET_CAPTURE ) ) {
				continue;
			}

			foreach ( $ms[0] as $m ) {
				$expr = f3b_expressao_de_valor( $funcao['corpo'], (int) $m[1] + strlen( (string) $m[0] ) );

				if ( str_starts_with( $expr, 'array(' ) || str_starts_with( $expr, '[' ) ) {
					continue;
				}

				$produtores[] = array(
					'onde'  => $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '()',
					'nome'  => $funcao['nome'],
					'corpo' => $funcao['corpo'],
					'expr'  => $expr,
				);
			}
		}
	}

	return $produtores;
}

/**
 * O status efetivo de página sai de um PRODUTOR SÓ.
 *
 * O DEFEITO MEDIDO NA 1.0.12. A página da política de privacidade nasceu em
 * `draft` porque a configuração declarava `draft`, e a decisão de não publicá-la
 * — tomada pelo pacote, por um motivo real que ninguém tinha ratificado — não
 * aparecia em lugar nenhum do relatório. A correção não foi publicar assim
 * mesmo: foi inverter o ônus como na indexação da 1.0.12. A intenção declarada
 * é produção, e uma GUARDA MEDIDA segura a publicação nomeando a si mesma, as
 * chaves vazias e a saída.
 *
 * Isso só se sustenta com fonte única. Enquanto o status vier de dois lugares —
 * um lendo o declarado, outro escrevendo um literal —, o segundo a rodar
 * contradiz o primeiro, e o relatório sai com duas afirmações verdadeiras sobre
 * o que está publicado. É a mesma família de `estatica.option_fonte_unica`.
 *
 * Três cláusulas, e as três reprovam:
 *
 * 1. **Âncora presente e com alvo.** `produtor_de_status_de_pagina()` precisa
 *    existir e nomear uma função que existe: declaração sem alvo absolve sem
 *    medir, que é pior do que nenhuma declaração.
 * 2. **Um leitor só do caminho declarado, e ele passa pelo produtor.** Duas
 *    funções lendo `paginas.*.status` são duas decisões esperando para divergir.
 * 3. **Todo `post_status` desejado de página chama o produtor.** É a cláusula
 *    que pega o literal `'publish'` escrito direto num `wp_insert_post()`.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_pagina_status_fonte_unica( string $raiz ): array {
	$ancora  = f3b_ancora_mapa( $raiz, 'produtor_de_status_de_pagina' );
	$funcao  = (string) ( $ancora['mapa']['funcao'] ?? '' );
	$caminho = (string) ( $ancora['mapa']['caminho'] ?? '' );

	if ( '' === $ancora['ancora'] || '' === $funcao || '' === $caminho ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função produtor_de_status_de_pagina() declarando "funcao" e "caminho" foi encontrada no '
					. 'código do implantador: sem a âncora que diz QUEM produz o status efetivo de uma página e QUAL '
					. 'caminho da configuração só ele pode ler, não há sobre o que a regra de fonte única valha — e '
					. 'regra sem escopo é regra que nunca acusa nada',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 1;

	if ( ! f3b_funcao_existe( $raiz, $funcao ) ) {
		$achados[] = 'produtor_de_status_de_pagina(), em ' . $ancora['ancora'] . ', aponta o produtor para ' . $funcao
			. '(), que não está definida em lugar nenhum do código do implantador: produtor declarado e ausente é pior '
			. 'que produtor inexistente, porque ele faz o detector calar';
	}

	$leitores = f3b_leitores_de_caminho( $raiz, $caminho );
	$medidas += count( $leitores );

	foreach ( $leitores as $leitor ) {
		if ( $leitor['nome'] === $funcao || str_contains( $leitor['corpo'], $funcao . '(' ) ) {
			continue;
		}

		$achados[] = $leitor['onde'] . ' lê "' . $caminho . '" e NÃO passa por ' . $funcao . '(): quem lê a intenção '
			. 'declarada sem consultar o produtor está decidindo o status de uma página por conta própria, e a decisão '
			. 'que o produtor tomar no mesmo relatório vai contradizê-la';
	}

	if ( count( $leitores ) > 1 ) {
		$achados[] = '"' . $caminho . '" é lido em ' . count( $leitores ) . ' funções: '
			. implode( ' E ', array_map( static fn( array $l ): string => $l['onde'], $leitores ) )
			. ' — a intenção declarada tem um leitor só, que é o produtor; um segundo leitor é a segunda resposta '
			. 'para a mesma pergunta esperando para divergir';
	}

	if ( array() === $leitores ) {
		$achados[] = '"' . $caminho . '", declarado em ' . $ancora['ancora'] . ' como o caminho da intenção de status, '
			. 'não é lido por função nenhuma do implantador: caminho que ninguém lê é a configuração prometendo o que '
			. 'o código não faz, e o produtor passa a decidir sobre um valor que não existe';
	}

	$produtores = f3b_produtores_de_status_de_pagina( $raiz );
	$medidas   += count( $produtores );

	foreach ( $produtores as $produtor ) {
		if ( $produtor['nome'] === $funcao || str_contains( $produtor['corpo'], $funcao . '(' ) ) {
			continue;
		}

		$achados[] = $produtor['onde'] . ' produz o post_status de uma página com «' . $produtor['expr'] . '» sem passar '
			. 'por ' . $funcao . '(): é o segundo lugar decidindo o que este pacote publica, e é por ele que uma página '
			. 'volta a nascer fora do ar sem que uma linha do relatório diga por quê';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}


/* -------------------------------------------------------------------------
 * estatica.llms_so_pagina_publicada
 * ---------------------------------------------------------------------- */

/**
 * Corpo de uma função do implantador, pelo nome, com o arquivo onde ela mora.
 *
 * @param string $raiz Raiz a varrer.
 * @param string $nome Nome da função.
 * @return array{corpo:string,onde:string}|null
 */
function f3b_funcao_do_implantador( string $raiz, string $nome ): ?array {
	if ( '' === $nome ) {
		return null;
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$corpo = f3b_corpo_de_funcao( f3b_codigo_php( $raiz . '/' . $rel ), $nome );

		if ( null !== $corpo ) {
			return array(
				'corpo' => $corpo,
				'onde'  => $rel,
			);
		}
	}

	return null;
}

/**
 * Toda seleção de `llms.txt` só nasce de página PUBLICADA — nos DOIS produtores.
 *
 * O DEFEITO MEDIDO NA 1.0.12 e o que sobrou dele na 1.0.13.
 *
 * Na 1.0.12, o item da política era montado de `localizar_gerenciado()` sem
 * conferir o status: com a página em rascunho, `get_permalink()` devolvia o
 * endereço de um rascunho — que só responde a quem está logado e com permissão
 * — e o `llms.txt`, que é público, anunciava aquele endereço como a política do
 * site.
 *
 * A 1.0.13 fechou UM produtor, `f3base_llms`, e deixou o outro passar:
 * `wpseo_llmstxt` continuava recebendo `privacy_policy => <id da página>` sem
 * gate nenhum. O detector prometia, pelo nome, mais do que media — e detector
 * cujo nome promete mais do que ele mede é pior que detector nenhum, porque
 * compra silêncio.
 *
 * O critério NÃO é o que o consumidor de terceiro faz com o identificador de um
 * rascunho. É se este pacote deve entregá-lo a um slot que alimenta arquivo
 * publicado. Não deve, faça o consumidor o que fizer: a escrita está errada na
 * origem.
 *
 * Quatro cláusulas, e as quatro reprovam:
 *
 * 1. **Âncora presente**, declarando o `gate` e ao menos um par
 *    `option => produtor`.
 * 2. **O gate existe e mede o ARTEFATO** — `get_post_status()` contra `publish`.
 *    Gate que não olha o status centraliza a montagem e deixa o defeito onde
 *    estava.
 * 3. **Cada produtor declarado existe e passa pelo gate.**
 * 4. **Quem monta o valor de cada option chama o produtor daquela option, e não
 *    resolve página por fora** — nem `localizar_gerenciado()`, nem
 *    `get_permalink()`, que são os dois caminhos paralelos que devolvem
 *    identificador e endereço sem passar pela conferência de status.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_llms_so_pagina_publicada( string $raiz ): array {
	$ancora  = f3b_ancora_mapa( $raiz, 'produtor_de_item_llms' );
	$gate    = (string) ( $ancora['mapa']['gate'] ?? '' );
	$por_opt = $ancora['mapa'];
	unset( $por_opt['gate'] );

	if ( '' === $ancora['ancora'] || '' === $gate || array() === $por_opt ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função produtor_de_item_llms() declarando "gate" e ao menos um par option => produtor foi '
					. 'encontrada no código do implantador: sem a âncora que diz QUEM mede o status e QUEM monta a '
					. 'seleção de cada option, não há sobre o que a regra valha — e uma âncora que declarasse um '
					. 'produtor só voltaria a prometer, pelo nome, mais do que mede',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 1;

	$corpo_gate = f3b_funcao_do_implantador( $raiz, $gate );

	if ( null === $corpo_gate ) {
		$achados[] = 'produtor_de_item_llms(), em ' . $ancora['ancora'] . ', declara o gate ' . $gate . '(), que não '
			. 'está definido em lugar nenhum do implantador: gate declarado e ausente absolve sem medir';
	} else {
		$medidas++;

		if ( ! str_contains( $corpo_gate['corpo'], 'get_post_status(' ) || ! str_contains( $corpo_gate['corpo'], "'publish'" ) ) {
			$achados[] = $corpo_gate['onde'] . ' ' . $gate . '() é o gate declarado e NÃO confere o status do artefato '
				. '(get_post_status() contra publish): gate que não olha o status centraliza a montagem e deixa o '
				. 'defeito onde estava — o rascunho continua indo para um arquivo público';
		}
	}

	foreach ( $por_opt as $option => $produtor ) {
		$medidas++;
		$corpo_produtor = f3b_funcao_do_implantador( $raiz, $produtor );

		if ( null === $corpo_produtor ) {
			$achados[] = 'produtor_de_item_llms() declara ' . $produtor . '() como produtor de "' . $option . '", e essa '
				. 'função não está definida em lugar nenhum do implantador: produtor declarado e ausente absolve sem medir';
			continue;
		}

		if ( '' !== $gate && ! str_contains( $corpo_produtor['corpo'], $gate . '(' ) ) {
			$achados[] = $corpo_produtor['onde'] . ' ' . $produtor . '(), produtor de "' . $option . '", não passa pelo '
				. 'gate ' . $gate . '(): produtor que resolve a página por conta própria é o segundo lugar decidindo o '
				. 'que vai para um arquivo público';
		}
	}

	$paralelos = array( 'localizar_gerenciado(', 'get_permalink(' );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $montador ) {
			if ( 'produtor_de_item_llms' === $montador['nome'] || $montador['nome'] === $gate ) {
				continue;
			}

			foreach ( $por_opt as $option => $produtor ) {
				if ( $montador['nome'] === $produtor ) {
					continue;
				}

				/*
				 * As duas formas de PRODUZIR o valor de uma option: o nome dentro
				 * do mapa que um laço grava depois, e o nome entregue direto ao
				 * gravador. Procurar só a primeira enxergaria um produtor onde
				 * há dois — foi assim que o lado do plugin de SEO passou livre.
				 * Montadas por sprintf() porque a seta colada por concatenação
				 * faria `estatica.detector_codigo_em_string` reprovar ESTE
				 * detector.
				 */
				$formas = array(
					sprintf( "/'%s'\s*=>\s*/", preg_quote( (string) $option, '/' ) ),
					sprintf( "/gravar(?:_chaves)?\(\s*'%s'\s*,/", preg_quote( (string) $option, '/' ) ),
				);

				$monta = false;

				foreach ( $formas as $re ) {
					if ( preg_match( $re, $montador['corpo'] ) ) {
						$monta = true;
						break;
					}
				}

				if ( ! $monta ) {
					continue;
				}

				$medidas++;
				$onde = $rel . ':' . $montador['linha'] . ' ' . $montador['nome'] . '()';

				if ( ! str_contains( $montador['corpo'], $produtor . '(' ) ) {
					$achados[] = $onde . ' monta o valor de "' . $option . '" sem chamar ' . $produtor . '(): a seleção '
						. 'volta a ser montada por fora do único ponto que confere se a página está publicada';
				}

				foreach ( $paralelos as $paralelo ) {
					if ( str_contains( $montador['corpo'], $paralelo ) ) {
						$achados[] = $onde . ' resolve página com ' . $paralelo . ') dentro do montador de "' . $option
							. '": é o caminho paralelo que devolve identificador ou endereço sem passar pela '
							. 'conferência de status, e foi exatamente por ele que o rascunho chegou a um arquivo público';
					}
				}
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.politica_privacidade_fonte_unica
 * ---------------------------------------------------------------------- */

/**
 * A identidade da política de privacidade tem UM produtor, e ele não depende
 * de chave que não a nomeia.
 *
 * O DEFEITO CORRIGIDO NA 1.0.14. A 1.0.13 acertou em matar o literal
 * `'privacidade' === $ref` espalhado pelas etapas — lista fechada no código
 * decidindo o que a configuração declara — e errou o destino: pendurou a
 * identidade em `seo.llms_selecao.politica_privacidade`, uma chave que nomeia
 * uma seleção de llms.txt.
 *
 * A consequência é medível e é séria. Desligar `bots_ia.llms_txt` e limpar a
 * seleção é operação legítima — o nome da chave convida a ela — e fazia o
 * pacote parar de gravar `wp_page_for_privacy_policy` E derrubava
 * `privacidade.controlador_identificado` em "condição de aplicabilidade falsa".
 * Uma chave de SEO silenciava uma checagem exigida pelo art. 9º da LGPD, sem
 * nada acusar: o pior modo de falha possível, porque o relatório fica verde.
 *
 * O fato passa a morar onde ele se chama pelo próprio nome — `papel` na entrada
 * de `paginas` que descreve a página —, e a regra que impede a recorrência não
 * é o nome da chave: é a CLÁUSULA 3, que proíbe o produtor de ler qualquer
 * caminho fora da raiz declarada.
 *
 * Cinco cláusulas, e as cinco reprovam:
 *
 * 1. **Âncora presente e com alvo**: `produtor_da_politica_de_privacidade()`
 *    declara `funcao`, `papel`, `caminho` e `raiz`, e a função existe.
 * 2. **Um leitor só do caminho do papel**, e ele é o produtor.
 * 3. **O produtor não lê caminho fora da raiz declarada.** É a cláusula que
 *    encoda o defeito: identidade legal pendurada em seção alheia.
 * 4. **O valor do papel não aparece em função nenhuma além do produtor e da
 *    âncora** — senão volta a existir um segundo lugar respondendo QUAL página
 *    é a política.
 * 5. **Ninguém lê o caminho aposentado** `seo.llms_selecao.politica_privacidade`:
 *    a seleção do llms.txt REFERENCIA o produtor, nunca possui o fato.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_politica_privacidade_fonte_unica( string $raiz ): array {
	$ancora  = f3b_ancora_mapa( $raiz, 'produtor_da_politica_de_privacidade' );
	$funcao  = (string) ( $ancora['mapa']['funcao'] ?? '' );
	$papel   = (string) ( $ancora['mapa']['papel'] ?? '' );
	$caminho = (string) ( $ancora['mapa']['caminho'] ?? '' );
	$raiz_ok = (string) ( $ancora['mapa']['raiz'] ?? '' );

	if ( '' === $ancora['ancora'] || '' === $funcao || '' === $papel || '' === $caminho || '' === $raiz_ok ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função produtor_da_politica_de_privacidade() declarando "funcao", "papel", "caminho" e "raiz" '
					. 'foi encontrada no código do implantador: sem a âncora que diz QUEM responde qual página é a '
					. 'política e QUAL raiz de configuração ele tem permissão de ler, a identidade legal volta a poder '
					. 'ser pendurada em qualquer chave, e o relatório continua verde',
			),
			'medidas' => 1,
		);
	}

	$achados = array();
	$medidas = 1;

	$produtor = f3b_funcao_do_implantador( $raiz, $funcao );

	if ( null === $produtor ) {
		$achados[] = 'produtor_da_politica_de_privacidade(), em ' . $ancora['ancora'] . ', aponta para ' . $funcao
			. '(), que não está definida em lugar nenhum do implantador: produtor declarado e ausente absolve sem medir';
	} else {
		$medidas++;

		/* CLÁUSULA 3: o produtor só pode ler a raiz declarada. */
		foreach ( f3b_chamadas_regex( $produtor['corpo'], F3B_RE_CONFIG ) as $args ) {
			$lido = f3b_caminho_normalizado( f3b_expressao_para_caminho( f3b_primeiro_argumento( $args ) ) );

			if ( '' === $lido || str_starts_with( $lido, '*' ) ) {
				continue;
			}

			if ( $lido === $raiz_ok || str_starts_with( $lido, $raiz_ok . '.' ) ) {
				continue;
			}

			$achados[] = $produtor['onde'] . ' ' . $funcao . '() lê "' . $lido . '", fora da raiz declarada "' . $raiz_ok
				. '": a identidade da política é fato do SITE, exigido pelo art. 9º da LGPD, e pendurá-la em outra seção '
				. 'faz uma chave alheia poder silenciar a checagem legal — desligar aquela seção derruba esta medição '
				. 'sem nada acusar';
		}
	}

	/* CLÁUSULA 2: um leitor só do caminho do papel, e ele é o produtor. */
	$leitores = f3b_leitores_de_caminho( $raiz, $caminho );
	$medidas += count( $leitores );

	foreach ( $leitores as $leitor ) {
		if ( $leitor['nome'] === $funcao ) {
			continue;
		}

		$achados[] = $leitor['onde'] . ' lê "' . $caminho . '" e não é o produtor declarado ' . $funcao . '(): duas '
			. 'funções respondendo QUAL página é a política são duas respostas esperando para divergir';
	}

	if ( array() === $leitores ) {
		$achados[] = '"' . $caminho . '", declarado em ' . $ancora['ancora'] . ' como o caminho do papel, não é lido por '
			. 'função nenhuma do implantador: papel que ninguém lê é a configuração prometendo o que o código não faz';
	}

	/* CLÁUSULA 4: o valor do papel não aparece fora do produtor e da âncora. */
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( f3b_funcoes_do_arquivo( $src ) as $f ) {
			if ( $f['nome'] === $funcao || 'produtor_da_politica_de_privacidade' === $f['nome'] ) {
				continue;
			}

			if ( ! str_contains( $f['corpo'], "'" . $papel . "'" ) ) {
				continue;
			}

			$medidas++;
			$achados[] = $rel . ':' . $f['linha'] . ' ' . $f['nome'] . '() traz o literal "' . $papel . '" fora do '
				. 'produtor: é o segundo lugar respondendo qual página é a política, e é por ele que o literal de '
				. 'referência lógica no código volta a decidir o que a configuração declara';
		}
	}

	/* CLÁUSULA 5: o caminho aposentado não tem leitor. */
	$aposentado = 'seo.llms_selecao.politica_privacidade';
	$antigos    = f3b_leitores_de_caminho( $raiz, $aposentado );
	$medidas++;

	foreach ( $antigos as $antigo ) {
		$achados[] = $antigo['onde'] . ' lê "' . $aposentado . '": esse caminho foi APOSENTADO na 1.0.14 porque '
			. 'pendurava a identidade da política numa chave que nomeia uma seleção de llms.txt. A seleção referencia '
			. 'o produtor; ela não possui o fato';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.warn_tem_ramo_adverso
 * ---------------------------------------------------------------------- */

/**
 * Funções pelas quais um estado chega ao relatório do RUNTIME.
 *
 * ÂNCORA declarada num lugar só, como as outras da suíte. O detector abaixo só
 * olha para o literal `WARN` que é ARGUMENTO de uma destas — ou valor de uma
 * chave `'estado'` de array de veredito. Com isso a lista fechada de estados, o
 * mapa de severidade e a constante `const WARN = 'WARN'` ficam fora por
 * construção, sem precisar de exceção por arquivo: eles não emitem nada.
 *
 * @return array<int,string>
 */
function f3b_emissoras_de_estado(): array {
	return array( 'emitir', 'emitir_unidade', 'saida', 'estado', 'estado_mais_severo' );
}

/**
 * Escopo do detector: o RUNTIME do pacote.
 *
 * `includes/` é o implantador; `fontes/` é o tema e o site-core. É esse código
 * que escreve o relatório que o operador lê. A suíte fica fora porque o WARN
 * dela nasce da tabela de ORIGENS (`terceiro` → WARN) em `estado_por_origem()`,
 * que é maquinaria de classificação e não checagem, e porque a sonda funcional
 * PRECISA emitir estados fabricados para exercitar o próprio relatório.
 *
 * @return array<int,string>
 */
function f3b_escopo_de_runtime(): array {
	return array( 'includes/', 'fontes/' );
}

/**
 * Nome da função da chamada que ENVOLVE a posição dada.
 *
 * Sobe pelos parênteses não fechados e devolve o identificador imediatamente
 * anterior ao `(` que abriu a chamada. Vazio quando a posição não está dentro
 * de chamada nenhuma.
 *
 * @param array<int,array{0:int,1:string,2:int}|string> $tokens Tokens.
 * @param int                                           $n      Índice do token.
 * @return string
 */
function f3b_chamada_envolvente( array $tokens, int $n ): string {
	$nivel = 0;

	for ( $i = $n - 1; $i >= 0; $i-- ) {
		$bruto = is_array( $tokens[ $i ] ) ? $tokens[ $i ][1] : $tokens[ $i ];

		if ( ')' === $bruto ) {
			$nivel++;
			continue;
		}

		if ( '(' !== $bruto ) {
			continue;
		}

		if ( $nivel > 0 ) {
			$nivel--;
			continue;
		}

		/* Achou o `(` da chamada que envolve: o nome é o identificador antes. */
		for ( $j = $i - 1; $j >= 0; $j-- ) {
			if ( is_array( $tokens[ $j ] ) && T_WHITESPACE === $tokens[ $j ][0] ) {
				continue;
			}

			return is_array( $tokens[ $j ] ) ? (string) $tokens[ $j ][1] : (string) $tokens[ $j ];
		}

		return '';
	}

	return '';
}

/**
 * Vizinho significativo antes da posição, pulando espaço em branco.
 *
 * @param array<int,array{0:int,1:string,2:int}|string> $tokens Tokens.
 * @param int                                           $n      Índice.
 * @param int                                           $salto  Quantos vizinhos voltar (1 = o imediatamente anterior).
 * @return string
 */
function f3b_vizinho_anterior( array $tokens, int $n, int $salto = 1 ): string {
	$vistos = 0;

	for ( $i = $n - 1; $i >= 0; $i-- ) {
		if ( is_array( $tokens[ $i ] ) && T_WHITESPACE === $tokens[ $i ][0] ) {
			continue;
		}

		$vistos++;

		if ( $vistos >= $salto ) {
			return is_array( $tokens[ $i ] ) ? (string) $tokens[ $i ][1] : (string) $tokens[ $i ];
		}
	}

	return '';
}

/**
 * Todo WARN do runtime mora num ramo que MEDIU alguma coisa.
 *
 * A regra, e o defeito que a produziu. Na execução real da 1.0.14 nove
 * checagens fecharam WARN sem achado adverso nenhum, e cada uma promoveu a
 * unidade dela: `config.schema_declarado` avisando que "a configuração declara
 * o schema e validou contra ele"; `plugins.politica_versao` avisando que a
 * política declarada foi aplicada; `tema.declaracoes` avisando que a lista
 * vazia é estado válido; `preflight.limites` dizendo de si mesma "fato de
 * ambiente, relatado sem decidir gate" e promovendo a unidade assim mesmo.
 * Quatro unidades amarelas numa execução em que nada estava errado — a mesma
 * família da checagem que acusava o próprio pacote e das 24 FALHA por ausência
 * de terceiro. Relatório que grita treina o leitor a ignorar o grito.
 *
 * A correção NÃO é um sétimo estado: os seis são regra do contrato. É a
 * checagem DERIVAR o estado da medição — validou, aplicou, declarou, mediu
 * dentro do esperado fecha OK com o detalhe no texto; mediu algo ADVERSO que
 * não bloqueia fecha WARN nomeando o que está adverso e a consequência.
 *
 * O detector cobra o piso disso, e o piso é sintático porque é o que dá para
 * medir sem executar: **nenhum WARN pode ser retorno incondicional ou único de
 * uma checagem**. Um WARN passa quando está dentro de `if`, `elseif`, `else`,
 * `foreach`, `for`, `while`, `switch`, `match` ou de um ternário — ramo cuja
 * condição mediu alguma coisa — ou quando a função já saiu por uma CLÁUSULA DE
 * GUARDA antes dele: um `return`, `throw` ou `exit` dentro de um ramo, mais
 * acima na mesma função. A guarda é o que torna o WARN nem incondicional (a
 * guarda pode impedi-lo) nem único (a guarda é outra saída). WARN no corpo raso
 * de uma função sem nenhuma das duas coisas é acusado com arquivo, linha e nome
 * da função.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_warn_tem_ramo_adverso( string $raiz ): array {
	$emissoras = f3b_emissoras_de_estado();
	$escopo    = f3b_escopo_de_runtime();
	$achados   = array();
	$medidas   = 0;

	$abre_controle = array( T_IF, T_ELSEIF, T_ELSE, T_FOREACH, T_FOR, T_WHILE, T_DO, T_SWITCH, T_MATCH );

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_excluidos() ) as $rel ) {
		$dentro = false;

		foreach ( $escopo as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$dentro = true;
				break;
			}
		}

		if ( ! $dentro ) {
			continue;
		}

		$medidas++;

		$tokens = token_get_all( f3b_codigo_php( $raiz . '/' . $rel ) );
		$total  = count( $tokens );

		/*
		 * Pilha de chaves: cada quadro sabe por que foi aberto — `funcao`,
		 * `controle` ou `outro` — e o quadro de função guarda se já houve
		 * cláusula de guarda (saída dentro de ramo) antes da posição atual.
		 */
		$pilha    = array();
		$pendente = '';
		$funcao   = '';
		$ternario = false;

		for ( $n = 0; $n < $total; $n++ ) {
			$token = $tokens[ $n ];

			if ( is_array( $token ) ) {
				if ( T_FUNCTION === $token[0] ) {
					$pendente = 'funcao';
					$funcao   = f3b_nome_da_funcao( $tokens, $n );
					continue;
				}

				if ( in_array( $token[0], $abre_controle, true ) ) {
					$pendente = 'controle';
					continue;
				}

				if ( T_WHITESPACE === $token[0] ) {
					continue;
				}
			}

			$bruto = is_array( $token ) ? $token[1] : $token;

			if ( '{' === $bruto ) {
				$pilha[]  = array(
					'tipo'   => '' !== $pendente ? $pendente : 'outro',
					'guarda' => false,
				);
				$pendente = '';
				continue;
			}

			if ( '}' === $bruto ) {
				array_pop( $pilha );
				continue;
			}

			/* `?` nu é ternário: `??` é T_COALESCE e `?->` é T_NULLSAFE_OBJECT_OPERATOR. */
			if ( '?' === $bruto ) {
				$ternario = true;
				continue;
			}

			if ( ';' === $bruto ) {
				$ternario = false;
				continue;
			}

			/* Quadro de função mais interno, e se estamos dentro de um ramo dele. */
			$nivel_funcao = -1;

			for ( $k = count( $pilha ) - 1; $k >= 0; $k-- ) {
				if ( 'funcao' === $pilha[ $k ]['tipo'] ) {
					$nivel_funcao = $k;
					break;
				}
			}

			$em_ramo = false;

			for ( $k = $nivel_funcao + 1; $k < count( $pilha ); $k++ ) {
				if ( 'controle' === $pilha[ $k ]['tipo'] ) {
					$em_ramo = true;
					break;
				}
			}

			/*
			 * CLÁUSULA DE GUARDA: saída dentro de um ramo. Quem sai ali pode
			 * impedir que o resto da função rode, e é isso que faz o que vem
			 * depois deixar de ser incondicional.
			 */
			if ( is_array( $token ) && in_array( $token[0], array( T_RETURN, T_THROW, T_EXIT ), true ) && $em_ramo && $nivel_funcao >= 0 ) {
				$pilha[ $nivel_funcao ]['guarda'] = true;
				continue;
			}

			$e_warn = ( is_array( $token ) && T_STRING === $token[0] && 'WARN' === $token[1] && '::' === f3b_vizinho_anterior( $tokens, $n ) )
				|| ( is_array( $token ) && T_CONSTANT_ENCAPSED_STRING === $token[0] && in_array( trim( $token[1], "'\"" ), array( 'WARN' ), true ) );

			if ( ! $e_warn ) {
				continue;
			}

			/* Posição de EMISSÃO: argumento de emissora, ou valor de `'estado' =>`. */
			$chamada  = f3b_chamada_envolvente( $tokens, $n );
			$por_seta = '=>' === f3b_vizinho_anterior( $tokens, $n ) && in_array( trim( f3b_vizinho_anterior( $tokens, $n, 2 ), "'\"" ), array( 'estado' ), true );

			if ( ! in_array( $chamada, $emissoras, true ) && ! $por_seta ) {
				continue;
			}

			if ( $em_ramo || $ternario ) {
				continue;
			}

			if ( $nivel_funcao >= 0 && $pilha[ $nivel_funcao ]['guarda'] ) {
				continue;
			}

			/*
			 * A linha vai como `%s` de propósito: `%d` colado a um nome de
			 * estado é exatamente o padrão que `estatica.contagem_com_nomes`
			 * acusa, e um detector novo não pode nascer disparando outro.
			 */
			$achados[] = sprintf(
				'%s:%s — o estado adverso é retorno incondicional de %s(), fora de qualquer ramo e sem cláusula de guarda antes dele. '
					. 'Todo aviso mora num ramo cuja condição mediu alguma coisa: medição sem achado adverso fecha OK com o detalhe no texto, '
					. 'e aviso que sai sempre treina o operador a ignorar aviso.',
				$rel,
				(string) ( is_array( $token ) ? (int) $token[2] : 0 ),
				'' !== $funcao ? $funcao : '(escopo de arquivo)'
			);
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Nome da função declarada no token `T_FUNCTION` da posição.
 *
 * @param array<int,array{0:int,1:string,2:int}|string> $tokens Tokens.
 * @param int                                           $n      Índice do T_FUNCTION.
 * @return string
 */
function f3b_nome_da_funcao( array $tokens, int $n ): string {
	$total = count( $tokens );

	for ( $i = $n + 1; $i < $total; $i++ ) {
		if ( is_array( $tokens[ $i ] ) && T_WHITESPACE === $tokens[ $i ][0] ) {
			continue;
		}

		if ( is_array( $tokens[ $i ] ) && T_STRING === $tokens[ $i ][0] ) {
			return (string) $tokens[ $i ][1];
		}

		return '';
	}

	return '';
}

/* -------------------------------------------------------------------------
 * plugins.serie_de_backup_normalizada
 * ---------------------------------------------------------------------- */

/**
 * Nomes de cópia preservada medidos, e a série que cada um pertence.
 *
 * TABELA ÚNICA: o runner e o piso leem esta mesma lista, e o que muda entre
 * eles é só a implementação que a atende. Os nomes são montados a partir das
 * constantes do pacote — nunca escritos por extenso, porque um literal com a
 * marca sem o ponto na frente é exatamente o que `pacote.backup_sempre_oculto`
 * proíbe, e com razão.
 *
 * O segundo caso é o NOME MEDIDO NO SITE REAL depois da 1.0.14: backup de um
 * diretório que já era backup.
 *
 * @param string $prefixo Prefixo de construção (`PREFIXO_BACKUP`).
 * @param string $marca   Marca de reconhecimento (`MARCA_ANTERIOR`).
 * @param string $slug    Slug do artefato.
 * @return array<int,array{rotulo:string,nome:string,slug:string,quando:int}>
 */
function f3b_series_de_backup_medidas( string $prefixo, string $marca, string $slug ): array {
	return array(
		array(
			'rotulo' => 'cópia simples',
			'nome'   => $prefixo . $slug . '-1788152131',
			'slug'   => $slug,
			'quando' => 1788152131,
		),
		array(
			'rotulo' => 'cópia de cópia, o nome medido no site',
			'nome'   => $prefixo . $slug . $marca . '1788152131-1788156801',
			'slug'   => $slug,
			'quando' => 1788156801,
		),
		array(
			'rotulo' => 'aninhamento duplo',
			'nome'   => $prefixo . $prefixo . $slug . $marca . '1788152131-1788156801-1788160000',
			'slug'   => $slug,
			'quando' => 1788160000,
		),
		array(
			'rotulo' => 'plugin de terceiro',
			'nome'   => $prefixo . 'wordpress-seo-1788100000',
			'slug'   => 'wordpress-seo',
			'quando' => 1788100000,
		),
	);
}

/**
 * A chave da série colapsa a marca de backup embutida.
 *
 * O DEFEITO MEDIDO, com o nome literal que estava em `wp-content/plugins/`:
 * `.f3base-anterior-f3base-site-core-f3base-anterior-1788152131-1788156801` —
 * backup de um diretório que já era backup. Cortando o slug no último traço, a
 * chave virava `f3base-site-core-f3base-anterior-1788152131`: série PRÓPRIA,
 * com uma cópia só, que nunca alcança o teto de 2 e portanto nunca poda. O log
 * fechou com sete cópias preservadas e a frase "nada acima do teto" — cada
 * palavra verdadeira e a conclusão errada.
 *
 * Roda a MESMA função do runtime — `F3Base_Imp_Plugins::serie_do_nome()` — em
 * SUBPROCESSO, pela mesma razão de `estatica.plano_dependencias`: o piso a
 * executa duas vezes, contra a fixture com o corte ingênuo e contra a correta, e
 * duas declarações da mesma classe no mesmo processo seriam erro fatal.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_serie_de_backup( string $raiz, string $suite ): array {
	$arquivo = $raiz . '/includes/class-f3base-imp-plugins.php';
	$sonda   = $suite . '/lib/sonda-serie.php';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'includes/class-f3base-imp-plugins.php ausente na raiz varrida: sem ele não existe função de série a exercitar' ),
			'medidas' => 1,
		);
	}

	$marcas = f3b_linhas_da_sonda( $sonda, $arquivo, array() );

	if ( 1 !== count( $marcas ) || 2 > count( $marcas[0] ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'as marcas de cópia preservada não puderam ser lidas em subprocesso: ' . f3b_amostra( array_map( 'implode', $marcas ), 2 ) ),
			'medidas' => 1,
		);
	}

	$casos = f3b_series_de_backup_medidas( $marcas[0][0], $marcas[0][1], 'f3base-site-core' );
	$fora  = array( 'f3base-site-core', 'wordpress-seo', $marcas[0][0], $marcas[0][0] . 'semcarimbo' );

	$nomes = array_merge( array_map( static fn( array $c ): string => $c['nome'], $casos ), $fora );
	$lidas = array();

	foreach ( f3b_linhas_da_sonda( $sonda, $arquivo, $nomes ) as $linha ) {
		$lidas[ (string) ( $linha[0] ?? '' ) ] = array(
			'slug'   => (string) ( $linha[1] ?? '' ),
			'quando' => (int) ( $linha[2] ?? 0 ),
		);
	}

	if ( count( $lidas ) !== count( array_unique( $nomes ) ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'a sonda da série devolveu ' . count( $lidas ) . ' linha(s) para ' . count( array_unique( $nomes ) ) . ' nome(s) medido(s)' ),
			'medidas' => 1,
		);
	}

	$achados   = array();
	$agrupadas = array();

	foreach ( $casos as $caso ) {
		$slug   = (string) ( $lidas[ $caso['nome'] ]['slug'] ?? '' );
		$quando = (int) ( $lidas[ $caso['nome'] ]['quando'] ?? 0 );

		if ( $slug !== $caso['slug'] ) {
			$achados[] = $caso['rotulo'] . ': ' . $caso['nome'] . ' caiu na série "' . ( '' !== $slug ? $slug : '(nenhuma)' )
				. '" e a série do artefato real é "' . $caso['slug'] . '" — série fantasma nunca alcança o teto declarado e portanto nunca poda';
		}

		if ( $quando !== $caso['quando'] ) {
			$achados[] = $caso['rotulo'] . ': o carimbo lido foi ' . $quando
				. ' e o carimbo EXTERNO, que é quando esta cópia foi criada, é ' . $caso['quando'];
		}

		if ( '' !== $slug ) {
			$agrupadas[ $slug ] = ( $agrupadas[ $slug ] ?? 0 ) + 1;
		}
	}

	if ( 2 !== count( $agrupadas ) ) {
		$achados[] = 'as ' . count( $casos ) . ' cópias medidas produziram ' . count( $agrupadas )
			. ' série(s) e precisam produzir 2: o artefato do pacote, com três cópias, e o plugin de terceiro, com uma';
	}

	if ( 3 !== ( $agrupadas['f3base-site-core'] ?? 0 ) ) {
		$achados[] = 'a série do artefato do pacote ficou com ' . (string) ( $agrupadas['f3base-site-core'] ?? 0 )
			. ' cópia(s) e precisa ficar com 3 — é essa contagem que o teto de plugins.backups_preservados compara';
	}

	foreach ( $fora as $nome ) {
		if ( '' !== (string) ( $lidas[ $nome ]['slug'] ?? '' ) ) {
			$achados[] = 'piso do falso positivo: "' . $nome . '" não é cópia preservada deste pacote e virou série assim mesmo';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => count( $casos ) + count( $fora ),
	);
}

/**
 * Roda a sonda de série e devolve as linhas do TSV já separadas.
 *
 * @param string            $sonda   Caminho da sonda.
 * @param string            $arquivo Classe a carregar.
 * @param array<int,string> $nomes   Nomes a medir; vazio pede as marcas.
 * @return array<int,array<int,string>>
 */
function f3b_linhas_da_sonda( string $sonda, string $arquivo, array $nomes ): array {
	$comando = 'php ' . escapeshellarg( $sonda ) . ' ' . escapeshellarg( $arquivo );

	foreach ( $nomes as $nome ) {
		$comando .= ' ' . escapeshellarg( (string) $nome );
	}

	$saida  = array();
	$estado = 0;
	exec( $comando . ' 2>&1', $saida, $estado );

	if ( 0 !== $estado ) {
		return array();
	}

	$linhas = array();

	foreach ( $saida as $linha ) {
		if ( '' === trim( (string) $linha ) ) {
			continue;
		}

		$linhas[] = explode( "\t", (string) $linha );
	}

	return $linhas;
}

/* -------------------------------------------------------------------------
 * estatica.sem_residuo_de_prefixo
 * ---------------------------------------------------------------------- */

/**
 * Uma tabela declarada de `ferramentas/`, sem comentário nem linha vazia.
 *
 * As tabelas são a FONTE ÚNICA: a ferramenta de renomeação as lê para saber o
 * que procurar e o que pular, e este detector as lê para saber o que não pode
 * sobrar e onde é permitido sobrar. Duas leituras do MESMO arquivo; uma exceção
 * que existisse só de um lado seria uma exceção que não protege nada.
 *
 * @param string $caminho Caminho absoluto do TSV.
 * @return array<int,array<int,string>>
 */
function f3b_tabela_de_ferramenta( string $caminho ): array {
	if ( ! is_file( $caminho ) ) {
		return array();
	}

	$linhas = array();

	foreach ( explode( "\n", (string) file_get_contents( $caminho ) ) as $linha ) {
		$linha = rtrim( $linha, "\r" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$linhas[] = explode( "\t", $linha );
	}

	return $linhas;
}

/**
 * Nenhuma grafia do prefixo do TEMPLATE sobrevive num pacote já renomeado.
 *
 * A regra que faz a renomeação valer alguma coisa. Uma ferramenta que reescreve
 * "quase tudo" produz um pacote meio num prefixo e meio noutro: o tema instala,
 * a option grava, e três semanas depois uma classe que ninguém tocou continua
 * chamando `F3Base_Imp_Config` num site que se chama outra coisa. O detector
 * varre as três grafias declaradas em `ferramentas/prefixo-do-template.tsv` —
 * técnica, abreviada e de exibição —, no CAMINHO e no CONTEÚDO de todo arquivo,
 * e só perdoa o que estiver em `ferramentas/excecoes-de-prefixo.tsv`, arquivo a
 * arquivo, com o motivo escrito ao lado.
 *
 * Binário fica de fora por MEDIÇÃO, não por lista: arquivo com byte nulo nos
 * primeiros 8 KB não é texto, e procurar prefixo dentro de PNG é procurar
 * coincidência.
 *
 * CONDIÇÃO DE APLICABILIDADE, declarada: enquanto `site.prefixo_tecnico` for o
 * prefixo do próprio template, o pacote É o template — procurar resíduo do
 * próprio prefixo não mede nada, e a checagem fecha N/A dizendo isso. Ela roda
 * de verdade no pacote renomeado, e o piso de fixture a exercita dos dois lados
 * aqui, em toda rodada.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int,estado:string,motivo:string}
 */
function f3b_ck_sem_residuo_de_prefixo( string $raiz ): array {
	$origem = array();

	foreach ( f3b_tabela_de_ferramenta( $raiz . '/ferramentas/prefixo-do-template.tsv' ) as $linha ) {
		$papel = trim( $linha[0] ?? '' );
		$valor = trim( $linha[1] ?? '' );

		if ( '' !== $papel && '' !== $valor ) {
			$origem[ $papel ] = $valor;
		}
	}

	if ( array() === $origem ) {
		return array(
			'ok'      => false,
			'achados' => array( 'ferramentas/prefixo-do-template.tsv ausente ou vazio: sem o registro da origem não há o que procurar, e uma renomeação sem detector é uma renomeação que ninguém confere' ),
			'medidas' => 0,
			'estado'  => 'FALHA',
			'motivo'  => 'ferramentas/prefixo-do-template.tsv ausente ou vazio.',
		);
	}

	$excecoes = array();

	foreach ( f3b_tabela_de_ferramenta( $raiz . '/ferramentas/excecoes-de-prefixo.tsv' ) as $linha ) {
		$caminho = trim( $linha[0] ?? '' );
		$motivo  = trim( $linha[1] ?? '' );

		if ( '' !== $caminho ) {
			$excecoes[ $caminho ] = $motivo;
		}
	}

	$config  = f3b_config( $raiz ) ?? array();
	$atual   = trim( (string) ( $config['site']['prefixo_tecnico'] ?? '' ) );
	$tecnico = (string) ( $origem['tecnico'] ?? '' );

	if ( $atual === $tecnico ) {
		return array(
			'ok'      => true,
			'achados' => array(),
			'medidas' => 1,
			'estado'  => 'N/A',
			'motivo'  => 'condição declarada: site.prefixo_tecnico ainda é o prefixo do template ("' . $tecnico . '"), ou seja, este pacote É o template e não um site derivado dele. '
				. 'Procurar resíduo do próprio prefixo não mede nada. A regra roda de verdade sobre o pacote renomeado, e o piso de fixture prova, em toda rodada, '
				. 'que ela acusa o resíduo plantado e cala sobre a árvore limpa.',
		);
	}

	$agulhas = array_values( array_unique( array_filter( array_map( 'strval', $origem ) ) ) );
	$achados = array();
	$medidas = 0;
	$isentos = 0;

	foreach ( f3b_arquivos( $raiz, array(), array( 'dist/' ) ) as $rel ) {
		$coberto = false;

		foreach ( array_keys( $excecoes ) as $caminho ) {
			if ( str_ends_with( $caminho, '/' ) ? str_starts_with( $rel, $caminho ) : $rel === $caminho ) {
				$coberto = true;
				break;
			}
		}

		if ( $coberto ) {
			$isentos++;
			continue;
		}

		$medidas++;

		foreach ( $agulhas as $agulha ) {
			if ( str_contains( $rel, $agulha ) ) {
				$achados[] = $rel . ': o CAMINHO ainda carrega "' . $agulha . '", que é o prefixo do template — dois sites da operação com o mesmo nome de arquivo é o que a troca de prefixo existe para impedir';
			}
		}

		$bruto = (string) file_get_contents( $raiz . '/' . $rel );

		if ( str_contains( substr( $bruto, 0, 8192 ), "\0" ) ) {
			continue;
		}

		foreach ( $agulhas as $agulha ) {
			$quantas = substr_count( $bruto, $agulha );

			if ( $quantas < 1 ) {
				continue;
			}

			$achados[] = $rel . ': ' . $quantas . ' ocorrência(s) de "' . $agulha . '" no conteúdo, e o arquivo não consta de ferramentas/excecoes-de-prefixo.tsv — '
				. 'resíduo do prefixo do template dentro de um pacote que se chama "' . $atual . '"';
		}
	}

	if ( array() === $achados ) {
		return array(
			'ok'      => true,
			'achados' => array(),
			'medidas' => $medidas,
			'estado'  => 'OK',
			'motivo'  => sprintf(
				'nenhuma das %d grafias do prefixo do template (%s) sobrou em %d arquivo(s) medido(s), nem no caminho nem no conteúdo. %d arquivo(s) preservado(s) por exceção declarada em ferramentas/excecoes-de-prefixo.tsv: %s.',
				count( $agulhas ),
				implode( ', ', $agulhas ),
				$medidas,
				$isentos,
				array() === $excecoes ? 'nenhuma' : implode( '; ', array_keys( $excecoes ) )
			),
		);
	}

	return array(
		'ok'      => false,
		'achados' => $achados,
		'medidas' => $medidas,
		'estado'  => 'FALHA',
		'motivo'  => sprintf(
			'%d resíduo(s) do prefixo do template fora da lista de exceções declarada: %s',
			count( $achados ),
			f3b_amostra( $achados, 5 )
		),
	);
}

/* -------------------------------------------------------------------------
 * estatica.troca_invalida_cache
 * ---------------------------------------------------------------------- */

/**
 * A INVALIDAÇÃO DE CACHE PERTENCE A QUEM TROCOU O DIRETÓRIO.
 *
 * O DEFEITO MEDIDO, e ele custou uma instalação limpa inteira na 1.0.15.
 * `Theme_Upgrader::install()` chama `wp_clean_themes_cache()` e
 * `Plugin_Upgrader::install()` chama `wp_clean_plugins_cache()`. A troca
 * controlada de diretório do pacote não passa pelo upgrader e não chamava nem
 * um nem outro — `wp_clean_themes_cache` não aparecia UMA VEZ no pacote. Num
 * WordPress recém-criado a etapa consulta o estado antes da troca, o núcleo
 * memoriza o NEGATIVO na mesma requisição, a troca acontece, e a leitura de
 * volta relê o cache: a unidade fechava FALHA dizendo "não apareceu no disco"
 * sobre um diretório que estava lá, enquanto outra unidade da MESMA rodada
 * enumerava o artefato entre os instalados.
 *
 * Por que a regra é "de quem trocou" e não "de quem chamou": há TRÊS chamadores
 * da troca — tema, site-core e embarcado —, e chamador que esquece é o defeito
 * voltando. A regra, executável:
 *
 * 1. a âncora do pacote declara trocador, invalidador, leitura de volta e as
 *    duas funções de limpeza do núcleo;
 * 2. o corpo do trocador chama o invalidador;
 * 3. o corpo do invalidador chama as DUAS limpezas declaradas;
 * 4. toda função que chama o trocador também chama a leitura de volta
 *    declarada — reler o estado por fora dela é reintroduzir a mensagem que
 *    confunde disco com cache.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_troca_invalida_cache( string $raiz ): array {
	$ancora = f3b_ancora_mapa( $raiz, 'troca_de_diretorio_declarada' );
	$mapa   = $ancora['mapa'];

	if ( array() === $mapa ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função troca_de_diretorio_declarada() foi encontrada no código: sem a âncora que nomeia '
					. 'quem troca o diretório, quem invalida o cache e quem relê o artefato, esta regra não tem o que medir — '
					. 'e foi a ausência dela que deixou a troca de diretório atravessar quinze releases sem derrubar cache nenhum',
			),
			'medidas' => 1,
		);
	}

	$trocador    = (string) ( $mapa['trocador'] ?? '' );
	$invalidador = (string) ( $mapa['invalidador'] ?? '' );
	$leitura     = (string) ( $mapa['leitura'] ?? '' );
	$limpezas    = array_values( array_filter( array( (string) ( $mapa['tema'] ?? '' ), (string) ( $mapa['plugin'] ?? '' ) ) ) );

	$achados = array();
	$medidas = 0;

	foreach ( array( 'trocador' => $trocador, 'invalidador' => $invalidador, 'leitura' => $leitura ) as $papel => $nome ) {
		++$medidas;

		if ( '' === $nome ) {
			$achados[] = 'a âncora em ' . $ancora['ancora'] . ' não declara o papel "' . $papel . '"';
			continue;
		}

		if ( ! f3b_funcao_existe( $raiz, $nome ) ) {
			$achados[] = 'a âncora em ' . $ancora['ancora'] . ' declara ' . $papel . ' = ' . $nome . '() e essa função não existe no pacote: declaração que absolve sem medir é pior que nenhuma';
		}
	}

	++$medidas;

	if ( array() === $limpezas ) {
		$achados[] = 'a âncora em ' . $ancora['ancora'] . ' não declara as funções de limpeza do núcleo (tema e plugin)';
	}

	/* 2 e 3: o trocador chama o invalidador, e o invalidador chama as limpezas. */
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		$corpo_trocador = '' === $trocador ? null : f3b_corpo_de_funcao( $src, $trocador );

		if ( null !== $corpo_trocador ) {
			++$medidas;

			if ( ! str_contains( $corpo_trocador, $invalidador . '(' ) ) {
				$achados[] = $rel . ': ' . $trocador . '() troca o diretório e NÃO chama ' . $invalidador
					. '(): o cache do núcleo continua respondendo pelo estado anterior, e a leitura de volta de uma '
					. 'instalação limpa relê o negativo que a consulta prévia memorizou';
			}
		}

		$corpo_invalidador = '' === $invalidador ? null : f3b_corpo_de_funcao( $src, $invalidador );

		if ( null !== $corpo_invalidador ) {
			foreach ( $limpezas as $limpeza ) {
				++$medidas;

				if ( ! str_contains( $corpo_invalidador, $limpeza . '(' ) ) {
					$achados[] = $rel . ': ' . $invalidador . '() não chama ' . $limpeza
						. '(), que é a limpeza que o upgrader do núcleo faz para este tipo de artefato';
				}
			}
		}

		/* 4: quem chama o trocador passa pela leitura de volta declarada. */
		foreach ( f3b_funcoes_do_arquivo( $src ) as $funcao ) {
			if ( $funcao['nome'] === $trocador || '' === $trocador ) {
				continue;
			}

			if ( ! str_contains( $funcao['corpo'], $trocador . '(' ) ) {
				continue;
			}

			++$medidas;

			if ( ! str_contains( $funcao['corpo'], $leitura . '(' ) ) {
				$achados[] = $rel . ':' . $funcao['linha'] . ' ' . $funcao['nome'] . '() chama ' . $trocador
					. '() e NÃO passa por ' . $leitura . '(): a leitura de volta por fora dela volta a dizer '
					. '"não apareceu no disco" sobre diretório que está no disco, que é o relatório que mandou o operador procurar no lugar errado';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.artefato_do_pacote_e_lido
 * ---------------------------------------------------------------------- */

/**
 * Prefixos de zip embutido, lidos da constante do PRÓPRIO pacote.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{prefixos:array<int,string>,ancora:string}
 */
function f3b_prefixos_de_zip( string $raiz ): array {
	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		if ( 1 !== preg_match( '/const\s+PREFIXOS_DE_ZIP\s*=\s*array\(([^)]*)\)/', $src, $m ) ) {
			continue;
		}

		preg_match_all( "/'([^']*)'/", $m[1], $ms );

		return array(
			'prefixos' => array_values( array_unique( $ms[1] ) ),
			'ancora'   => $rel,
		);
	}

	return array(
		'prefixos' => array(),
		'ancora'   => '',
	);
}

/**
 * ARTEFATO QUE VIAJA NO PACOTE E NINGUÉM LÊ É DEFEITO.
 *
 * O DEFEITO MEDIDO, da 1.0.14 à 1.0.15: o empacotamento montava `f3base.zip`
 * (27.607 bytes) e `f3base-site-core.zip` (76.414 bytes) e os copiava para a
 * RAIZ do bundle. Nenhum caminho de instalação os abria — a resolução de zip
 * embutido só procura sob os prefixos declarados, e a instalação de tema e
 * site-core lê `fontes/`. Eram 104.021 bytes dentro do hash do pacote servindo
 * de PROVA FALSA DE ENTREGA: um relatório podia dizer "o tema viaja no pacote"
 * apontando para um artefato que a instalação nunca abriria.
 *
 * Duas medições:
 *
 * 1. todo `.zip` que viaja no pacote está sob um dos prefixos que a constante
 *    do pacote declara — fora deles, ninguém o lê;
 * 2. quem INSTALA e quem PROVA o entregável passam pelo MESMO resolvedor, e
 *    nenhum dos dois monta caminho de artefato por conta própria. Foi a segunda
 *    lista, escrita à mão em `F3Base_Imp_Entrega`, que fez o entregável provar
 *    um artefato enquanto a instalação usava outro.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_artefato_do_pacote_e_lido( string $raiz ): array {
	$zip    = f3b_prefixos_de_zip( $raiz );
	$ancora = f3b_ancora_mapa( $raiz, 'artefato_fonte_unica_declarada' );

	$achados = array();
	$medidas = 0;

	++$medidas;

	if ( array() === $zip['prefixos'] ) {
		$achados[] = 'nenhuma constante PREFIXOS_DE_ZIP foi encontrada no código: sem a lista declarada de onde um zip '
			. 'embutido pode estar, não há como dizer se um artefato do pacote é lido por alguém';
	}

	/* 1: todo zip do pacote sob um prefixo declarado. */
	foreach ( f3b_arquivos( $raiz, array( 'zip' ), f3b_excluidos() ) as $rel ) {
		++$medidas;

		$sob_prefixo = false;

		foreach ( $zip['prefixos'] as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) && ! str_contains( substr( $rel, strlen( $prefixo ) ), '/' ) ) {
				$sob_prefixo = true;
				break;
			}
		}

		if ( ! $sob_prefixo ) {
			$achados[] = $rel . ': artefato instalável viaja no pacote e NENHUM caminho de instalação o lê — a resolução '
				. 'de zip embutido só procura em ' . implode( ', ', $zip['prefixos'] ) . ' (declarado em ' . $zip['ancora'] . '). '
				. 'Peso morto que ainda por cima serve de prova falsa de entrega: ou ele é ligado ao caminho que instala, ou para de viajar';
		}
	}

	/* 2: quem instala e quem prova passam pelo mesmo resolvedor. */
	++$medidas;

	if ( array() === $ancora['mapa'] ) {
		$achados[] = 'nenhuma função artefato_fonte_unica_declarada() foi encontrada no código: sem a âncora que nomeia '
			. 'o resolvedor, quem instala e quem prova, a fonte única não é verificável';

		return array(
			'ok'      => array() === $achados,
			'achados' => $achados,
			'medidas' => $medidas,
		);
	}

	$resolvedor = (string) ( $ancora['mapa']['resolvedor'] ?? '' );
	$obrigadas  = array();

	foreach ( array( 'instala', 'prova' ) as $papel ) {
		foreach ( explode( ',', (string) ( $ancora['mapa'][ $papel ] ?? '' ) ) as $nome ) {
			$nome = trim( $nome );

			if ( '' !== $nome ) {
				$obrigadas[ $nome ] = $papel;
			}
		}
	}

	++$medidas;

	if ( '' === $resolvedor || ! f3b_funcao_existe( $raiz, $resolvedor ) ) {
		$achados[] = 'a âncora em ' . $ancora['ancora'] . ' declara resolvedor = ' . $resolvedor . '() e essa função não existe no pacote';
	}

	$vistas = array();

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src = f3b_codigo_php( $raiz . '/' . $rel );

		foreach ( $obrigadas as $nome => $papel ) {
			$corpo = f3b_corpo_de_funcao( $src, $nome );

			if ( null === $corpo ) {
				continue;
			}

			$vistas[ $nome ] = true;
			++$medidas;

			if ( '' !== $resolvedor && ! str_contains( $corpo, $resolvedor . '(' ) ) {
				$achados[] = $rel . ': ' . $nome . '() (' . $papel . ') não passa por ' . $resolvedor
					. '(): quem instala e quem prova o entregável precisam ler o MESMO artefato, ou o relatório prova um e a instalação usa outro';
			}

			if ( 1 === preg_match( "/'[^']*\\.zip'/", $corpo ) || 1 === preg_match( "/'fontes\\/[^']*'/", $corpo ) ) {
				$achados[] = $rel . ': ' . $nome . '() (' . $papel . ') monta caminho de artefato por conta própria — '
					. 'a segunda lista é o defeito, e é ela que produz entregável provado num caminho e instalação feita em outro';
			}
		}
	}

	foreach ( $obrigadas as $nome => $papel ) {
		++$medidas;

		if ( ! isset( $vistas[ $nome ] ) ) {
			$achados[] = 'a âncora em ' . $ancora['ancora'] . ' declara ' . $papel . ' = ' . $nome . '() e essa função não existe no pacote';
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/* -------------------------------------------------------------------------
 * estatica.resposta_de_lote_nomeada
 * ---------------------------------------------------------------------- */

/**
 * TODA RESPOSTA DE LOTE É NOMEADA E FECHA NUM ESTADO.
 *
 * O DEFEITO MEDIDO na 1.0.15: a rejeição de lock voltava como
 * `{ok:false, estado:BLOCKED, motivo:"…"}` — sem `rotulo` e sem `aplicacao`. Na
 * tela, 163 linhas anônimas: o rodapé dizia "linhas desta tela: 163 BLOCKED" e,
 * na lista por nome do MESMO escopo, "BLOCKED: nenhum"; e `estado da aplicação:`
 * saía vazio, que não é estado fechado.
 *
 * A regra: toda resposta que a tela renderiza traz as chaves que a âncora do
 * pacote declara, e o emissor só recebe carga do produtor declarado ou do
 * produtor de reserva — que é o único lugar onde uma resposta "não rodou" é
 * montada.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_resposta_de_lote_nomeada( string $raiz ): array {
	$ancora = f3b_ancora_mapa( $raiz, 'resposta_declarada' );

	if ( array() === $ancora['mapa'] ) {
		return array(
			'ok'      => false,
			'achados' => array(
				'nenhuma função resposta_declarada() foi encontrada no código: sem a âncora que nomeia o emissor, o '
					. 'produtor e as chaves obrigatórias, não há como cobrar que a linha da tela tenha nome e estado fechado',
			),
			'medidas' => 1,
		);
	}

	$emissor  = (string) ( $ancora['mapa']['emissor'] ?? '' );
	$produtor = (string) ( $ancora['mapa']['produtor'] ?? '' );
	$reserva  = (string) ( $ancora['mapa']['reserva'] ?? '' );
	$exigidas = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $ancora['mapa']['exigidas'] ?? '' ) ) ) ) );

	$achados = array();
	$medidas = 0;

	++$medidas;

	if ( array() === $exigidas ) {
		$achados[] = 'a âncora em ' . $ancora['ancora'] . ' não declara nenhuma chave obrigatória na resposta do lote';
	}

	foreach ( f3b_arquivos( $raiz, array( 'php' ), f3b_fora_do_escopo_de_option() ) as $rel ) {
		$src   = f3b_codigo_php( $raiz . '/' . $rel );
		$corpo = '' === $produtor ? null : f3b_corpo_de_funcao( $src, $produtor );

		if ( null !== $corpo ) {
			foreach ( f3b_retornos_de_array( $corpo ) as $retorno ) {
				++$medidas;

				if ( ! str_contains( $retorno, "'estado'" ) ) {
					continue;
				}

				foreach ( $exigidas as $chave ) {
					if ( ! str_contains( $retorno, "'" . $chave . "'" ) ) {
						$achados[] = $rel . ': ' . $produtor . '() devolve uma resposta com estado e SEM a chave "' . $chave
							. '" — linha sem rótulo sai anônima da tela e a contagem por estado fica sem a lista de nomes; '
							. 'resposta sem estado da aplicação fecha o rodapé em branco, e vazio não é estado fechado. '
							. 'Resposta que não rodou se monta em ' . $reserva . '()';
					}
				}
			}
		}

		/* O emissor só recebe carga do produtor declarado ou do de reserva. */
		if ( '' === $emissor || ! str_contains( $src, $emissor . '(' ) ) {
			continue;
		}

		if ( null === f3b_corpo_de_funcao( $src, $emissor ) ) {
			continue;
		}

		foreach ( f3b_chamadas_de( $src, $emissor ) as $chamada ) {
			++$medidas;

			if ( str_contains( $chamada, $produtor . '(' ) || str_contains( $chamada, $reserva . '(' ) ) {
				continue;
			}

			$achados[] = $rel . ': ' . $emissor . '() recebe uma carga montada fora de ' . $produtor . '() e de '
				. $reserva . '(): resposta montada à mão volta a sair sem nome e sem estado da aplicação — '
				. 'trecho: ' . trim( preg_replace( '/\s+/', ' ', mb_substr( $chamada, 0, 90 ) ) ?? '' );
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}

/**
 * Blocos `return array( … );` de um corpo de função, com parênteses balanceados.
 *
 * @param string $corpo Corpo já sem comentário.
 * @return array<int,string>
 */
function f3b_retornos_de_array( string $corpo ): array {
	$saida = array();
	$pos   = 0;

	while ( true ) {
		$inicio = strpos( $corpo, 'return array(', $pos );

		if ( false === $inicio ) {
			return $saida;
		}

		$abre = strpos( $corpo, '(', $inicio );

		if ( false === $abre ) {
			return $saida;
		}

		$saida[] = f3b_bloco_balanceado( $corpo, $abre );
		$pos     = $abre + 1;
	}
}

/**
 * Chamadas de uma função pelo nome, com os argumentos balanceados.
 *
 * @param string $src  Código já sem comentário.
 * @param string $nome Nome da função.
 * @return array<int,string>
 */
function f3b_chamadas_de( string $src, string $nome ): array {
	$saida = array();
	$pos   = 0;
	$alvo  = '::' . $nome . '(';

	while ( true ) {
		$inicio = strpos( $src, $alvo, $pos );

		if ( false === $inicio ) {
			return $saida;
		}

		$abre    = $inicio + strlen( $alvo ) - 1;
		$saida[] = f3b_bloco_balanceado( $src, $abre );
		$pos     = $abre + 1;
	}
}

/**
 * O trecho entre um `(` e o `)` que o fecha.
 *
 * @param string $src Código.
 * @param int    $pos Posição do parêntese de abertura.
 * @return string
 */
function f3b_bloco_balanceado( string $src, int $pos ): string {
	$nivel = 0;
	$tam   = strlen( $src );

	for ( $i = $pos; $i < $tam; $i++ ) {
		if ( '(' === $src[ $i ] ) {
			++$nivel;
		}

		if ( ')' === $src[ $i ] ) {
			--$nivel;

			if ( 0 === $nivel ) {
				return substr( $src, $pos, $i - $pos + 1 );
			}
		}
	}

	return substr( $src, $pos );
}

/* -------------------------------------------------------------------------
 * estatica.identidade_do_implantador
 * ---------------------------------------------------------------------- */

/**
 * A IDENTIDADE da release é a mesma nos três lugares que a carregam.
 *
 * O defeito que produziu este detector foi medido na 1.0.17, e ele é do mesmo
 * tipo que o carimbo velho em documento entregável — só que pior, porque o
 * `MANIFESTO.md` afirmava, em linha própria, que "`release.identidade` e o
 * cabeçalho do implantador são a mesma coisa" e NENHUMA checagem media isso. A
 * afirmação era verdadeira por hábito: alguém lembrava de bumpar o cabeçalho a
 * cada release. Na 1.0.17 o `config/site.json` foi para `1.0.17` e o cabeçalho
 * ficou em `1.0.16`, com a constante de bootstrap ainda em `1.0.15` — três
 * respostas para "qual release é esta?", e o relatório do site imprimiria a do
 * cabeçalho, que é a que o WordPress mostra na lista de plugins.
 *
 * Os três lugares, e por que cada um existe:
 *
 * - `release.identidade` e `release.implantador` em `config/site.json` — o que
 *   o pacote DECLARA ser.
 * - `Version:` no cabeçalho de `implantador-base.php` — o que o WordPress LÊ, e
 *   a fonte de verdade em execução (`f3base_imp_versao()` a prefere).
 * - `F3BASE_IMP_VERSAO_DECLARADA` — o fallback de bootstrap, usado antes de
 *   `get_plugin_data()` existir. Divergir dele é o caso medido em 3.0.4: a
 *   constante fica para trás e o número que aparece antes do admin carregar não
 *   é o da release.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_identidade_do_implantador( string $raiz ): array {
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou inválido na raiz varrida: sem release.identidade não há identidade a conferir' ),
			'medidas' => 0,
		);
	}

	$arquivo = $raiz . '/implantador-base.php';

	if ( ! is_file( $arquivo ) ) {
		return array(
			'ok'      => false,
			'achados' => array( 'implantador-base.php ausente na raiz varrida: o cabeçalho que o WordPress lê não existe' ),
			'medidas' => 0,
		);
	}

	$fonte      = (string) file_get_contents( $arquivo );
	$declarada  = (string) ( $config['release']['identidade'] ?? '' );
	$implantada = (string) ( $config['release']['implantador'] ?? '' );
	$achados    = array();
	$medidas    = 0;

	++$medidas;

	if ( '' === $declarada ) {
		$achados[] = 'config/site.json não declara release.identidade';
	}

	++$medidas;

	if ( '' !== $declarada && $implantada !== $declarada ) {
		$achados[] = 'release.implantador ("' . $implantada . '") diverge de release.identidade ("' . $declarada
			. '"): nesta base os dois são o mesmo número, e duas respostas para a mesma pergunta é o defeito que a identidade única existe para impedir';
	}

	++$medidas;

	if ( 1 !== preg_match( '/^\s*\*\s*Version:\s*(\S+)\s*$/mi', $fonte, $cabecalho ) ) {
		$achados[] = 'implantador-base.php sem cabeçalho Version: — é ele que o WordPress mostra na lista de plugins e o que f3base_imp_versao() prefere';
	} elseif ( '' !== $declarada && $cabecalho[1] !== $declarada ) {
		$achados[] = 'o cabeçalho Version: de implantador-base.php é "' . $cabecalho[1] . '" e release.identidade é "' . $declarada
			. '": o número que o WordPress mostra não é o da release que o pacote declara ser';
	}

	++$medidas;

	if ( 1 !== preg_match( "/define\(\s*'F3BASE_IMP_VERSAO_DECLARADA'\s*,\s*'([^']+)'\s*\)/", $fonte, $constante ) ) {
		$achados[] = 'implantador-base.php não define F3BASE_IMP_VERSAO_DECLARADA: sem o fallback de bootstrap, a versão fica indefinida antes de get_plugin_data() existir';
	} elseif ( '' !== $declarada && $constante[1] !== $declarada ) {
		$achados[] = 'F3BASE_IMP_VERSAO_DECLARADA é "' . $constante[1] . '" e release.identidade é "' . $declarada
			. '": o fallback de bootstrap ficou para trás, e é ele que responde antes do admin carregar';
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}
