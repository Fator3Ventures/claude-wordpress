<?php
/**
 * Contraste — recalculado, nunca copiado de documento.
 *
 * A razão de cada par é computada da paleta do `theme.json` pela fórmula de
 * luminância relativa da WCAG. `fontes/tema/CONTRASTE.md` é documentação: se ele e o
 * `theme.json` discordarem, quem vale é o `theme.json`, e é ele que esta
 * checagem lê.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Componente sRGB linearizado.
 *
 * @param float $c Componente 0..255.
 * @return float
 */
function f3b_srgb( float $c ): float {
	$c = $c / 255.0;

	return $c <= 0.03928 ? $c / 12.92 : pow( ( $c + 0.055 ) / 1.055, 2.4 );
}

/**
 * Luminância relativa de um hexadecimal.
 *
 * @param string $hex Cor.
 * @return float|null
 */
function f3b_luminancia( string $hex ): ?float {
	$hex = ltrim( trim( $hex ), '#' );

	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}

	if ( 8 === strlen( $hex ) ) {
		$hex = substr( $hex, 0, 6 );
	}

	if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
		return null;
	}

	return 0.2126 * f3b_srgb( (float) hexdec( substr( $hex, 0, 2 ) ) )
		+ 0.7152 * f3b_srgb( (float) hexdec( substr( $hex, 2, 2 ) ) )
		+ 0.0722 * f3b_srgb( (float) hexdec( substr( $hex, 4, 2 ) ) );
}

/**
 * Razão de contraste entre duas cores.
 *
 * @param string $a Cor.
 * @param string $b Cor.
 * @return float|null
 */
function f3b_razao( string $a, string $b ): ?float {
	$la = f3b_luminancia( $a );
	$lb = f3b_luminancia( $b );

	if ( null === $la || null === $lb ) {
		return null;
	}

	$alto  = max( $la, $lb );
	$baixo = min( $la, $lb );

	return ( $alto + 0.05 ) / ( $baixo + 0.05 );
}

/**
 * Slug de preset em uma referência, ou string vazia.
 *
 * @param mixed $valor Valor.
 * @return string
 */
function f3b_slug_de_cor( $valor ): string {
	if ( ! is_string( $valor ) ) {
		return '';
	}

	if ( preg_match( '/^var:preset\|color\|([A-Za-z0-9_-]+)$/', trim( $valor ), $m ) ) {
		return $m[1];
	}

	if ( preg_match( '/var\(\s*--wp--preset--color--([A-Za-z0-9_-]+)\s*\)/', $valor, $m ) ) {
		return $m[1];
	}

	return '';
}

/**
 * Pares texto/fundo EM USO, derivados do `theme.json`, do markup e do CSS.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{pares:array<int,array<string,mixed>>,paleta:array<string,string>,erros:array<int,string>}
 */
function f3b_pares_em_uso( string $raiz, string $suite ): array {
	$json = f3b_theme_json( $raiz );

	if ( null === $json ) {
		return array(
			'pares'  => array(),
			'paleta' => array(),
			'erros'  => array( 'fontes/tema/theme.json ausente ou inválido na raiz varrida' ),
		);
	}

	$paleta = array();

	foreach ( (array) ( $json['settings']['color']['palette'] ?? array() ) as $cor ) {
		if ( is_array( $cor ) && isset( $cor['slug'], $cor['color'] ) ) {
			$paleta[ (string) $cor['slug'] ] = (string) $cor['color'];
		}
	}

	$pares = array();
	$erros = array();

	$adicionar = static function ( string $frente, string $fundo, float $piso, string $onde ) use ( &$pares, $paleta, &$erros ): void {
		if ( '' === $frente || '' === $fundo || $frente === $fundo ) {
			return;
		}

		if ( ! isset( $paleta[ $frente ] ) || ! isset( $paleta[ $fundo ] ) ) {
			$erros[] = $onde . ': par ' . $frente . '/' . $fundo . ' usa slug fora da paleta';
			return;
		}

		$pares[] = array(
			'frente' => $frente,
			'fundo'  => $fundo,
			'piso'   => $piso,
			'onde'   => $onde,
		);
	};

	$fundo_raiz = f3b_slug_de_cor( $json['styles']['color']['background'] ?? '' );
	$texto_raiz = f3b_slug_de_cor( $json['styles']['color']['text'] ?? '' );

	$adicionar( $texto_raiz, $fundo_raiz, 4.5, 'theme.json styles.color' );

	/*
	 * Blocos cujo `color.text` NÃO é texto: ele pinta um objeto gráfico. O piso
	 * deles é o de componente não textual (3:1, critério 1.4.11), e medi-los
	 * com o piso de texto reprovaria uma cor que a WCAG aprova. A lista é curta
	 * e declarada — nunca inferida do nome do bloco.
	 */
	$graficos = array(
		'core/separator' => 'a linha do separador é objeto gráfico, não texto',
		'core/spacer'    => 'o espaçador não tem texto',
	);

	/*
	 * `$fundo_externo` é o que está ATRÁS do elemento. Texto e borda medem
	 * contra o fundo do próprio elemento; o ANEL DE FOCO mede contra o fundo
	 * externo, porque `outline` é desenhado FORA da caixa. Medir o anel contra
	 * o fundo do botão comparava `primaria` com `primaria-forte` e reprovava um
	 * foco que na tela aparece sobre a página, não sobre o botão.
	 */
	$anda_elemento = static function ( array $no, string $caminho, string $fundo_externo, float $piso_texto = 4.5 ) use ( &$anda_elemento, $adicionar, $texto_raiz ): void {
		$proprio = f3b_slug_de_cor( $no['color']['background'] ?? '' );
		$fundo   = '' !== $proprio ? $proprio : $fundo_externo;
		$texto   = f3b_slug_de_cor( $no['color']['text'] ?? '' );

		$adicionar( $texto, $fundo, $piso_texto, $caminho . ( 4.5 === $piso_texto ? '' : ' (não-texto)' ) );

		/*
		 * Fundo declarado SEM cor de texto: o texto continua existindo, e ele é
		 * o herdado da raiz. Medir só os pares em que as duas pontas estão
		 * escritas no mesmo nó deixaria de fora justamente o cartão e o painel
		 * — onde o fundo muda e a cor do texto não.
		 */
		if ( '' !== $proprio && '' === $texto && 4.5 === $piso_texto ) {
			$adicionar( $texto_raiz, $proprio, 4.5, $caminho . ' (texto herdado da raiz sobre o fundo declarado)' );
		}

		$borda = f3b_slug_de_cor( $no['border']['color'] ?? '' );
		$adicionar( $borda, $fundo, 3.0, $caminho . '.border (não-texto)' );

		foreach ( array( 'left', 'right', 'top', 'bottom' ) as $lado ) {
			$adicionar( f3b_slug_de_cor( $no['border'][ $lado ]['color'] ?? '' ), $fundo, 3.0, $caminho . '.border.' . $lado . ' (não-texto)' );
		}

		$anel = f3b_slug_de_cor( $no['outline']['color'] ?? '' );
		$adicionar( $anel, $fundo_externo, 3.0, $caminho . '.outline (não-texto, medido contra o fundo externo)' );

		foreach ( $no as $chave => $filho ) {
			if ( ! is_array( $filho ) ) {
				continue;
			}

			if ( 'elements' === $chave ) {
				foreach ( $filho as $el => $sub ) {
					if ( is_array( $sub ) ) {
						$anda_elemento( $sub, $caminho . '.elements.' . $el, $fundo );
					}
				}

				continue;
			}

			if ( str_starts_with( (string) $chave, ':' ) ) {
				$anda_elemento( $filho, $caminho . $chave, $fundo_externo, $piso_texto );
			}
		}
	};

	foreach ( (array) ( $json['styles']['elements'] ?? array() ) as $el => $no ) {
		if ( is_array( $no ) ) {
			$anda_elemento( $no, 'theme.json styles.elements.' . $el, $fundo_raiz );
		}
	}

	foreach ( (array) ( $json['styles']['blocks'] ?? array() ) as $bloco => $no ) {
		if ( ! is_array( $no ) ) {
			continue;
		}

		$piso = isset( $graficos[ $bloco ] ) ? 3.0 : 4.5;

		$anda_elemento( $no, 'theme.json styles.blocks.' . $bloco, $fundo_raiz, $piso );
	}

	$elementos_raiz = array();

	foreach ( array( 'link', 'heading' ) as $papel ) {
		$cor = f3b_slug_de_cor( $json['styles']['elements'][ $papel ]['color']['text'] ?? '' );

		if ( '' !== $cor ) {
			$elementos_raiz[ $papel ] = $cor;
		}
	}

	/*
	 * Markup publicado, percorrido como ÁRVORE.
	 *
	 * A pilha é o que faz a diferença: o parágrafo `suave` do pattern de cartões
	 * não declara fundo nenhum — ele herda o `superficie` do grupo três níveis
	 * acima. Medir cada bloco isolado deixaria de fora exatamente os pares que a
	 * composição cria, que são os que aparecem na tela.
	 */
	foreach ( f3b_markup_publicado( $raiz, $suite ) as $rotulo => $markup ) {
		$re = '/<!--\s*(\/?)wp:([a-z0-9\/-]+)\s*(\{.*?\})?\s*(\/?)-->/s';

		if ( ! preg_match_all( $re, $markup, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		$pilha_fundo = array( $fundo_raiz );
		$pilha_texto = array( $texto_raiz );

		/*
		 * Cor de LINK e de TÍTULO viajam com o contexto: elas valem em toda
		 * parte até que um ancestral as substitua. Quando um bloco abre um
		 * fundo novo sem trocá-las, o par que aparece na tela é a cor herdada
		 * sobre o fundo novo — é assim que `primaria` acaba sobre `superficie`
		 * sem que ninguém tenha escrito esse par em lugar nenhum.
		 */
		$pilha_elem = array( $elementos_raiz );

		foreach ( $ms as $m ) {
			$fechando = '' !== $m[1];
			$nome     = $m[2];
			$sozinho  = '' !== ( $m[4] ?? '' );
			$bloco    = str_contains( $nome, '/' ) ? $nome : 'core/' . $nome;

			if ( $fechando ) {
				if ( count( $pilha_fundo ) > 1 ) {
					array_pop( $pilha_fundo );
					array_pop( $pilha_texto );
				}

				continue;
			}

			$attrs = isset( $m[3] ) && '' !== $m[3] ? json_decode( $m[3], true ) : array();

			if ( ! is_array( $attrs ) ) {
				$attrs = array();
			}

			$fundo_pai = (string) end( $pilha_fundo );
			$texto_pai = (string) end( $pilha_texto );

			/*
			 * `core/cover` não usa `backgroundColor`: o fundo dele é o
			 * `overlayColor`. Ler só a chave usual media o texto do herói
			 * contra o fundo da página — um par que não existe na tela, e que
			 * reprovaria uma faixa escura perfeitamente legível.
			 */
			$proprio = is_string( $attrs['backgroundColor'] ?? null ) ? $attrs['backgroundColor'] : '';

			if ( '' === $proprio && is_string( $attrs['overlayColor'] ?? null ) && 0 !== (int) ( $attrs['dimRatio'] ?? 100 ) ) {
				$proprio = $attrs['overlayColor'];
			}

			if ( '' === $proprio ) {
				$proprio = f3b_slug_de_cor( $attrs['style']['color']['background'] ?? '' );
			}
			$texto   = is_string( $attrs['textColor'] ?? null ) ? $attrs['textColor'] : f3b_slug_de_cor( $attrs['style']['color']['text'] ?? '' );

			$fundo    = '' !== $proprio ? $proprio : $fundo_pai;
			$efetivo  = '' !== $texto ? $texto : $texto_pai;

			$elem_atual = (array) end( $pilha_elem );
			$sobrepoe   = $attrs['style']['elements'] ?? array();

			if ( is_array( $sobrepoe ) ) {
				foreach ( array( 'link', 'heading' ) as $papel ) {
					$cor = f3b_slug_de_cor( $sobrepoe[ $papel ]['color']['text'] ?? '' );

					if ( '' !== $cor ) {
						$elem_atual[ $papel ] = $cor;
					}
				}
			}

			if ( '' !== $proprio && ! isset( $graficos[ $bloco ] ) ) {
				foreach ( $elem_atual as $papel => $cor ) {
					$adicionar( (string) $cor, $fundo, 4.5, $rotulo . ' wp:' . $nome . ' (' . $papel . ' herdado sobre o fundo declarado)' );
				}
			}

			if ( isset( $graficos[ $bloco ] ) ) {
				$adicionar( '' !== $proprio ? $proprio : $texto, $fundo_pai, 3.0, $rotulo . ' wp:' . $nome . ' (' . $graficos[ $bloco ] . ')' );
			} else {
				$adicionar( $efetivo, $fundo, 4.5, $rotulo . ' wp:' . $nome );
			}

			/* O painel do menu compacto tem paleta própria, independente da pilha. */
			$overlay_fundo = is_string( $attrs['overlayBackgroundColor'] ?? null ) ? $attrs['overlayBackgroundColor'] : '';
			$overlay_texto = is_string( $attrs['overlayTextColor'] ?? null ) ? $attrs['overlayTextColor'] : '';
			$adicionar( $overlay_texto, $overlay_fundo, 4.5, $rotulo . ' wp:' . $nome . ' (painel do menu compacto)' );

			$elementos = $attrs['style']['elements'] ?? array();

			if ( is_array( $elementos ) ) {
				foreach ( $elementos as $el => $no ) {
					if ( is_array( $no ) ) {
						$anda_elemento( $no, $rotulo . ' wp:' . $nome . ' elements.' . $el, $fundo );
					}
				}
			}

			if ( ! $sozinho ) {
				$pilha_fundo[] = $fundo;
				$pilha_texto[] = $efetivo;
				$pilha_elem[]  = $elem_atual;
			}
		}
	}

	/* CSS do tema: par declarado no MESMO bloco de regra. */
	foreach ( f3b_arquivos_tema( $raiz, array( 'css' ) ) as $rel ) {
		$css = (string) file_get_contents( $raiz . '/' . $rel );

		if ( ! preg_match_all( '/([^{}]+)\{([^{}]*)\}/s', $css, $ms, PREG_SET_ORDER ) ) {
			continue;
		}

		foreach ( $ms as $m ) {
			$seletor = trim( preg_replace( '/\s+/', ' ', $m[1] ) ?? '' );
			$corpo   = $m[2];

			$fundo = '';
			$texto = '';
			$outro = array();

			if ( preg_match( '/(?<![a-z-])background-color\s*:\s*([^;]+);/i', $corpo, $c ) ) {
				$fundo = f3b_slug_de_cor( $c[1] );
			}

			if ( preg_match( '/(?<![a-z-])color\s*:\s*([^;]+);/i', $corpo, $c ) ) {
				$texto = f3b_slug_de_cor( $c[1] );
			}

			if ( preg_match_all( '/(?<![a-z-])(border[a-z-]*|outline)\s*:\s*([^;]+);/i', $corpo, $c, PREG_SET_ORDER ) ) {
				foreach ( $c as $decl ) {
					$slug = f3b_slug_de_cor( $decl[2] );

					if ( '' !== $slug ) {
						$outro[] = $slug;
					}
				}
			}

			if ( '' === $fundo ) {
				continue;
			}

			$adicionar( $texto, $fundo, 4.5, $rel . ' { ' . $seletor . ' }' );

			foreach ( $outro as $slug ) {
				$adicionar( $slug, $fundo, 3.0, $rel . ' { ' . $seletor . ' } (não-texto)' );
			}
		}
	}

	/* Deduplicação: o mesmo par medido em dois lugares é um par só. */
	$vistos = array();
	$unicos = array();

	foreach ( $pares as $par ) {
		$chave = $par['frente'] . '|' . $par['fundo'] . '|' . $par['piso'];

		if ( isset( $vistos[ $chave ] ) ) {
			continue;
		}

		$vistos[ $chave ] = true;
		$unicos[]         = $par;
	}

	return array(
		'pares'  => $unicos,
		'paleta' => $paleta,
		'erros'  => $erros,
	);
}

/**
 * Todo par texto/fundo em uso alcança o piso AA.
 *
 * Piso conservador e declarado: 4,5:1 para todo par de texto, sem invocar a
 * exceção de texto grande (3:1), e 3:1 para borda, separador e anel de foco —
 * contraste de componente não textual. Medir texto grande com o piso de texto
 * normal nunca aprova o que deveria reprovar; o contrário, sim.
 *
 * @param string $raiz  Raiz.
 * @param string $suite Diretório da suíte.
 * @return array{ok:bool,achados:array<int,string>,total:int}
 */
function f3b_ck_contraste( string $raiz, string $suite ): array {
	$dados   = f3b_pares_em_uso( $raiz, $suite );
	$achados = $dados['erros'];
	$paleta  = $dados['paleta'];

	if ( array() === $dados['pares'] && array() === $achados ) {
		$achados[] = 'nenhum par texto/fundo encontrado — não há o que medir';
	}

	foreach ( $dados['pares'] as $par ) {
		$razao = f3b_razao( $paleta[ $par['frente'] ], $paleta[ $par['fundo'] ] );

		if ( null === $razao ) {
			$achados[] = $par['onde'] . ': cor não analisável em ' . $par['frente'] . '/' . $par['fundo'];
			continue;
		}

		if ( $razao + 0.005 < $par['piso'] ) {
			$achados[] = sprintf(
				'%s: %s sobre %s = %.2f:1 (piso %.1f:1)',
				$par['onde'],
				$par['frente'],
				$par['fundo'],
				$razao,
				$par['piso']
			);
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'total'   => count( $dados['pares'] ),
	);
}
