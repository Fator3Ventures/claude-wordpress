#!/usr/bin/env bash
#
# COMANDO ÚNICO do implantador-base.
#
#   bash suite/verificar.sh <caminho-do-pacote>   empacota e verifica
#   bash suite/verificar.sh piso [caminho]        roda só o piso dos detectores
#
# Três regras que este arquivo existe para não deixar ninguém contornar:
#
#   1. Rodar vazio REPROVA. Sem argumento não há artefato, e uma rodada sem
#      artefato que terminasse em 0 seria a pior aprovação possível.
#   2. Empacotar é a PRIMEIRA etapa, sempre. Arquivo fora do inventário aborta
#      com o nome, antes de qualquer checagem.
#   3. O código de saída vem da contagem que a função de emissão acumulou.
#      Nenhuma etapa deste script "corrige" o resultado do PHP.
#   4. SELAR é a ÚLTIMA etapa, e só dela sai `suite/rodada.json`. O
#      registro carrega o hash do pacote que ESTA rodada mediu, o resumo por
#      estado com os nomes, a contagem de detectores do piso e o carimbo de
#      tempo, e é injetado no bundle já montado. Ele não pode ser escrito à mão:
#      `estatica.gate_fonte_unica` confere que o produtor é um só, e é este.
#      Rodada com FALHA não sela — e apaga o registro anterior.

set -u

SUITE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACOTE_PADRAO="$(dirname "$SUITE")"

uso() {
	cat >&2 <<'TEXTO'
uso:
  bash suite/verificar.sh <caminho-do-pacote>   empacota e verifica o pacote
  bash suite/verificar.sh piso [caminho]        roda o piso dos detectores

Sem argumento não há artefato para empacotar nem para verificar, e uma rodada
sem artefato não pode terminar em sucesso. Informe o caminho do pacote.
TEXTO
}

if [ "$#" -lt 1 ]; then
	echo "FALHA   suite.invocacao                             — comando único chamado sem argumento: não há artefato a verificar.  [evidência: analise-estatica/build]" >&2
	uso
	exit 2
fi

# Pré-condições de ambiente: ausência é BLOCKED com o recurso nomeado.
faltou=0

for recurso in php node zip unzip; do
	if ! command -v "$recurso" >/dev/null 2>&1; then
		echo "BLOCKED suite.ambiente                               — pré-condição ausente. Recurso ausente: $recurso.  [evidência: pendencia-externa/build]" >&2
		faltou=1
	fi
done

if [ "$faltou" -ne 0 ]; then
	exit 2
fi

if [ "$1" = "piso" ]; then
	PACOTE="${2:-$PACOTE_PADRAO}"
	exec php "$SUITE/lib/piso.php" "$PACOTE"
fi

PACOTE="$1"

if [ ! -d "$PACOTE" ]; then
	echo "BLOCKED pacote.artefato                             — o artefato a verificar não existe no caminho informado: $PACOTE.  [evidência: pendencia-externa/build]" >&2
	uso
	exit 2
fi

exec php "$SUITE/lib/executar.php" "$PACOTE"
