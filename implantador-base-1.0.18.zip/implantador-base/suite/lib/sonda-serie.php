<?php
/**
 * Sonda da série de cópias preservadas, em subprocesso.
 *
 * Não reimplementa nada: carrega o `class-f3base-imp-plugins.php` da raiz que
 * lhe foi apontada e chama `F3Base_Imp_Plugins::serie_do_nome()` — a MESMA
 * função que a poda usa no site. Subprocesso porque o piso executa a checagem
 * duas vezes, contra a fixture com o corte ingênuo e contra a correta, e duas
 * declarações da mesma classe no mesmo processo seriam erro fatal.
 *
 * Saída em TSV, uma linha por nome. Sem argumentos de nome, imprime as duas
 * marcas declaradas pela classe — é delas que a tabela de casos é montada, para
 * que nenhum nome de cópia preservada precise ser escrito por extenso.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$arquivo = (string) ( $argv[1] ?? '' );

if ( '' === $arquivo || ! is_file( $arquivo ) ) {
	fwrite( STDERR, "uso: sonda-serie.php <class-f3base-imp-plugins.php> [nome...]\n" );
	exit( 2 );
}

define( 'ABSPATH', '/' );

require $arquivo;

$nomes = array_slice( $argv, 2 );

if ( array() === $nomes ) {
	echo F3Base_Imp_Plugins::PREFIXO_BACKUP, "\t", F3Base_Imp_Plugins::MARCA_ANTERIOR, "\n";
	exit( 0 );
}

foreach ( $nomes as $nome ) {
	$serie = F3Base_Imp_Plugins::serie_do_nome( (string) $nome );

	echo (string) $nome, "\t", (string) ( $serie['slug'] ?? '' ), "\t", (string) (int) ( $serie['quando'] ?? 0 ), "\n";
}

exit( 0 );
