<?php
/**
 * Sonda do gravador: equivalência de leitura de volta e impressão de procedência.
 *
 * A camada de options faz round-trip de tipo — inteiro volta como string,
 * booleano volta como `"1"` ou `""`. Uma comparação estrita marcaria TODA option
 * como divergente; uma comparação frouxa (`==`) deixaria de ver a diferença que
 * importa. Esta sonda exercita os dois lados: o teto (o round-trip real é
 * reconhecido) e o piso (o que precisa continuar reprovando, reprova).
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( $argv[1] ?? '', '/' );

if ( '' === $raiz || ! is_file( $raiz . '/includes/class-f3base-imp-gravador.php' ) ) {
	echo json_encode( array( 'gravador.leitura_de_volta_equivalente' => array( 'achados' => array( 'includes/class-f3base-imp-gravador.php ausente na raiz varrida' ), 'medidas' => 0 ) ) );
	exit( 0 );
}

define( 'ABSPATH', '/tmp/f3base-sem-wordpress/' );

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

require $raiz . '/includes/class-f3base-imp-gravador.php';

$G       = 'F3Base_Imp_Gravador';
$achados = array();
$medidas = 0;

$casos = array(
	array( true, $G::equivalente( '1', 1 ), 'teto: inteiro 1 gravado volta do banco como "1"' ),
	array( true, $G::equivalente( '1', true ), 'teto: booleano true volta como "1"' ),
	array( true, $G::equivalente( '', false ), 'teto: booleano false volta como ""' ),
	array( true, $G::equivalente( '0', 0 ), 'teto: inteiro 0 volta como "0"' ),
	array( true, $G::equivalente( 'texto', 'texto' ), 'teto: string idêntica' ),
	array( true, $G::equivalente( array( 'b' => 2, 'a' => 1 ), array( 'a' => 1, 'b' => 2 ) ), 'teto: array tolerante à ordem de chaves' ),
	array( false, $G::equivalente( '0', false ), 'piso: "0" não é "" — a confusão clássica' ),
	array( false, $G::equivalente( '', 0 ), 'piso: "" não é 0' ),
	array( false, $G::equivalente( '1', 2 ), 'piso: valor diferente reprova' ),
	array( false, $G::equivalente( '1', '10' ), 'piso: prefixo não é igualdade' ),
	array( false, $G::equivalente( array( 1 ), 1 ), 'piso: array não equivale a escalar' ),
	array( false, $G::equivalente( array( 'a' => 1 ), array( 'a' => 2 ) ), 'piso: array com valor diferente reprova' ),
	array( false, $G::equivalente( array( 'a' => 1 ), array( 'a' => '1' ) ), 'piso: dentro do array o tipo importa' ),
	array( false, $G::equivalente( array( 'a' => 1 ), array( 'a' => 1, 'b' => 2 ) ), 'piso: chave a mais reprova' ),
	array( true, $G::mesma_representacao( 1, '1' ), 'representação: 1 e "1" têm a mesma' ),
	array( false, $G::mesma_representacao( 0, false ), 'representação: 0 e false não têm' ),
	array( false, $G::mesma_representacao( array( 1 ), array( '1' ) ), 'representação: arrays nunca passam por aqui' ),
	array( true, $G::impressao( 1 ) === $G::impressao( '1' ), 'procedência: o hash casa depois do round-trip' ),
	array( false, $G::impressao( 0 ) === $G::impressao( false ), 'procedência (piso): 0 e false continuam com hashes diferentes' ),
	array( false, $G::impressao( array( 'a' => 1 ) ) === $G::impressao( array( 'a' => 2 ) ), 'procedência (piso): valor diferente muda o hash' ),
	array( true, $G::impressao( array( 'b' => 2, 'a' => 1 ) ) === $G::impressao( array( 'a' => 1, 'b' => 2 ) ), 'procedência: hash estável com ordem diferente' ),
);

foreach ( $casos as $caso ) {
	$medidas++;

	if ( $caso[0] !== $caso[1] ) {
		$achados[] = $caso[2];
	}
}

echo json_encode(
	array(
		'gravador.leitura_de_volta_equivalente' => array(
			'achados' => $achados,
			'medidas' => $medidas,
		),
	),
	JSON_UNESCAPED_UNICODE
);
