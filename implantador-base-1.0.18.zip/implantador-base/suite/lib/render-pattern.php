<?php
/**
 * Renderiza um arquivo de pattern do tema FORA do WordPress, em subprocesso.
 *
 * Um pattern é PHP que imprime markup de bloco. Conferir o balanceamento só no
 * arquivo cru mede o texto antes das chamadas de i18n — e o defeito que importa
 * (comentário `wp:` quebrado, JSON de atributo inválido) aparece na SAÍDA. Aqui
 * as funções de escape e tradução do núcleo viram eco puro: o que sai é o
 * markup que o WordPress emitiria com a string original.
 *
 * Subprocesso, e não `include` no processo da suíte: erro fatal dentro de um
 * pattern derruba só este processo, e a sonda transforma isso em achado com o
 * nome do arquivo em vez de morrer junto.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

if ( ! function_exists( 'esc_html_e' ) ) {
	/**
	 * Eco da string traduzida.
	 *
	 * @param string $texto   Texto.
	 * @param string $dominio Text domain.
	 * @return void
	 */
	function esc_html_e( string $texto, string $dominio = '' ): void {
		echo htmlspecialchars( $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
	}
}

if ( ! function_exists( 'esc_attr_e' ) ) {
	/**
	 * Eco da string traduzida em contexto de atributo.
	 *
	 * @param string $texto   Texto.
	 * @param string $dominio Text domain.
	 * @return void
	 */
	function esc_attr_e( string $texto, string $dominio = '' ): void {
		echo htmlspecialchars( $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
	}
}

if ( ! function_exists( 'esc_html__' ) ) {
	/**
	 * String traduzida e escapada.
	 *
	 * @param string $texto   Texto.
	 * @param string $dominio Text domain.
	 * @return string
	 */
	function esc_html__( string $texto, string $dominio = '' ): string {
		return htmlspecialchars( $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
	}
}

if ( ! function_exists( 'esc_attr__' ) ) {
	/**
	 * String traduzida e escapada para atributo.
	 *
	 * @param string $texto   Texto.
	 * @param string $dominio Text domain.
	 * @return string
	 */
	function esc_attr__( string $texto, string $dominio = '' ): string {
		return htmlspecialchars( $texto, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
	}
}

if ( ! function_exists( '__' ) ) {
	/**
	 * String traduzida.
	 *
	 * @param string $texto   Texto.
	 * @param string $dominio Text domain.
	 * @return string
	 */
	function __( string $texto, string $dominio = '' ): string {
		return $texto;
	}
}

if ( ! function_exists( '_e' ) ) {
	/**
	 * Eco da string traduzida, sem escape.
	 *
	 * @param string $texto   Texto.
	 * @param string $dominio Text domain.
	 * @return void
	 */
	function _e( string $texto, string $dominio = '' ): void {
		echo $texto; // phpcs:ignore WordPress.Security.EscapeOutput -- eco de bancada.
	}
}

if ( ! function_exists( 'esc_url' ) ) {
	/**
	 * URL escapada.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	function esc_url( string $url ): string {
		return $url;
	}
}

$arquivo = $argv[1] ?? '';

if ( '' === $arquivo || ! is_file( $arquivo ) ) {
	fwrite( STDERR, 'pattern inexistente' );
	exit( 2 );
}

require $arquivo;
