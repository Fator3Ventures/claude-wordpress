<?php
/**
 * Sonda do HASH DO PACOTE — subprocesso que chama a ÚNICA implementação dele.
 *
 * O comando único precisa gravar, dentro do pacote, o hash do pacote que a
 * rodada mediu. Esse hash tem uma dona: `F3Base_Imp_Entrega::hash_do_pacote()`,
 * que é a função que o HOST executa quando confere a amarração. Reimplementar a
 * fórmula aqui criaria duas somas para o mesmo fato, e no dia em que uma delas
 * mudasse a de cá continuaria dizendo que estava tudo certo — que é exatamente
 * a doença que o pacote inteiro existe para não ter.
 *
 * Por isso esta sonda não calcula nada: ela define `F3BASE_IMP_DIR` apontando
 * para a árvore a medir, carrega a classe do implantador e imprime o que ela
 * devolve. Subprocesso por desenho — carregar a classe define `ABSPATH`, e isso
 * não pode vazar para o processo que imprime os estados.
 *
 * uso: php suite/lib/sonda-hash.php <arvore-a-medir> [<arvore-com-as-classes>]
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$alvo  = rtrim( (string) ( $argv[1] ?? '' ), '/' );
$fonte = rtrim( (string) ( $argv[2] ?? $alvo ), '/' );

if ( '' === $alvo || ! is_dir( $alvo ) ) {
	fwrite( STDERR, "sonda-hash: árvore a medir inexistente\n" );
	exit( 2 );
}

$classe = $fonte . '/includes/class-f3base-imp-entrega.php';

if ( ! is_file( $classe ) ) {
	fwrite( STDERR, "sonda-hash: pré-condição ausente. Recurso ausente: " . $classe . "\n" );
	exit( 2 );
}

define( 'ABSPATH', '/tmp/f3base-sem-wordpress/' );
define( 'F3BASE_IMP_DIR', $alvo . '/' );

require $classe;

echo F3Base_Imp_Entrega::hash_do_pacote();
