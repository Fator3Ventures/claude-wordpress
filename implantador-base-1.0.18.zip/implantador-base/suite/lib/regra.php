<?php
/**
 * Regra compartilhada da suíte — arquivo ÚNICO, importado por toda sonda.
 *
 * Mora aqui, e só aqui:
 *
 * - `estado()`: a única função que imprime uma linha de resultado, e que
 *   INCREMENTA O CONTADOR DENTRO DELA MESMA. Contador por fora já produziu o
 *   defeito medido: a linha saía FALHA, o `exit` saía 0, e a rodada passava.
 * - A lista FECHADA de estados, de classes de evidência e de fases. Estado fora
 *   da lista não é impresso: é erro de programação da própria suíte e aborta.
 * - A classificação de erro por ORIGEM: site → FALHA, terceiro → WARN,
 *   ambiente → BLOCKED com o recurso nomeado. Nenhuma sonda reimplementa isso.
 * - Os utilitários de varredura que toda sonda usa (lista de arquivos, código
 *   PHP sem comentário, caminho relativo).
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

final class F3Base_Suite {

	/** Estados fechados do contrato. Nenhum outro. */
	public const ESTADOS = array( 'OK', 'FALHA', 'BLOCKED', 'N/A', 'WAIVED', 'WARN' );

	/**
	 * Classes de evidência do contrato.
	 *
	 * `importada` entrou nesta release com um significado que nenhuma das outras
	 * tinha: o fato foi MEDIDO POR OUTRA RODADA, em outra máquina, e este host
	 * apenas confere a amarração — o caso da rodada limpa, cujo registro viaja
	 * dentro do pacote com o hash que ela mediu. Chamar isso de `medida` seria o
	 * instrumento afirmando ter feito o que não fez.
	 */
	public const CLASSES = array( 'medida', 'teste-funcional', 'analise-estatica', 'leitura-de-volta', 'doc-externa', 'inferencia', 'pendencia-externa', 'importada' );

	/** Fases do contrato. */
	public const FASES = array( 'build', 'local', 'producao', 'campo' );

	/**
	 * Origens possíveis de um erro e o estado que cada uma produz.
	 *
	 * Esta tabela é a regra de classificação inteira. Ela não é repetida em
	 * nenhuma sonda: quem precisa classificar chama `estado_por_origem()`.
	 */
	public const ORIGENS = array(
		'site'     => 'FALHA',
		'terceiro' => 'WARN',
		'ambiente' => 'BLOCKED',
	);

	/** @var array<string,int> Contagem por estado. Escrita SÓ dentro de estado(). */
	private static array $contagem = array();

	/** @var array<int,array<string,string>> Linhas emitidas, na ordem. */
	private static array $linhas = array();

	/** @var array<int,string> Nomes de checagem já emitidos (para o cruzamento do manifesto). */
	private static array $emitidas = array();

	/**
	 * Zera o acumulador. Usado pelo runner antes de uma rodada.
	 *
	 * @return void
	 */
	public static function zerar(): void {
		self::$contagem = array();
		self::$linhas   = array();
		self::$emitidas = array();
	}

	/**
	 * Incremento do contador. PRIVADO e chamado só por estado().
	 *
	 * @param string $estado Estado emitido.
	 * @return void
	 */
	private static function contar( string $estado ): void {
		self::$contagem[ $estado ] = ( self::$contagem[ $estado ] ?? 0 ) + 1;
	}

	/**
	 * Contagem por estado, na ordem da lista fechada.
	 *
	 * @return array<string,int>
	 */
	public static function contagem(): array {
		$saida = array();

		foreach ( self::ESTADOS as $estado ) {
			$saida[ $estado ] = self::$contagem[ $estado ] ?? 0;
		}

		return $saida;
	}

	/**
	 * Número de FALHAS. É o que decide o código de saída do comando único.
	 *
	 * @return int
	 */
	public static function falhas(): int {
		return self::$contagem['FALHA'] ?? 0;
	}

	/**
	 * Nomes de checagem efetivamente emitidos nesta rodada.
	 *
	 * O cruzamento do manifesto e o mapa de armadilhas leem DAQUI — nunca de
	 * uma lista escrita à mão, e nunca de `check(true)`.
	 *
	 * @return array<int,string>
	 */
	public static function emitidas(): array {
		return array_values( array_unique( self::$emitidas ) );
	}

	/**
	 * Linhas emitidas, com estado e nome.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function linhas(): array {
		return self::$linhas;
	}

	/**
	 * NOMES por estado — o par obrigatório de toda contagem por estado.
	 *
	 * Contagem sem nome não responde à pergunta do operador. O resumo da rodada
	 * imprimia `BLOCKED 22` e nenhum nome; quem precisasse saber QUAIS tinha de
	 * reler as 73 linhas acima e contar à mão.
	 *
	 * @return array<string,array<int,string>>
	 */
	public static function nomes_por_estado(): array {
		$saida = array();

		foreach ( self::ESTADOS as $estado ) {
			$saida[ $estado ] = array();
		}

		foreach ( self::$linhas as $linha ) {
			$estado = (string) ( $linha['estado'] ?? '' );
			$nome   = (string) ( $linha['nome'] ?? '' );

			if ( ! isset( $saida[ $estado ] ) || '' === $nome || in_array( $nome, $saida[ $estado ], true ) ) {
				continue;
			}

			$saida[ $estado ][] = $nome;
		}

		return $saida;
	}

	/**
	 * Registra a linha. Chamado SÓ por estado().
	 *
	 * @param string $estado Estado.
	 * @param string $nome   Nome da checagem.
	 * @return void
	 */
	private static function registrar( string $estado, string $nome ): void {
		self::$linhas[]  = array(
			'estado' => $estado,
			'nome'   => $nome,
		);
		self::$emitidas[] = $nome;
	}

	/**
	 * Ponte para o registro. SÓ `estado()` pode chamar, e isso é conferido.
	 *
	 * A regra do contrato é que o contador more dentro da função que imprime o
	 * estado. Documentar isso não basta: qualquer sonda poderia incrementar por
	 * fora e a contagem deixaria de descrever o que saiu na tela. A guarda
	 * abaixo torna a regra executável — chamada de outro lugar aborta a rodada.
	 *
	 * @param string $estado Estado.
	 * @param string $nome   Nome.
	 * @return void
	 */
	public static function anotar( string $estado, string $nome ): void {
		$pilha    = debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS, 2 );
		$chamador = $pilha[1]['function'] ?? '';

		if ( 'estado' !== $chamador ) {
			fwrite( STDERR, sprintf( "ERRO DE SUÍTE: contagem chamada de '%s' — o contador só pode ser tocado por estado().\n", $chamador ) );
			exit( 3 );
		}

		self::contar( $estado );
		self::registrar( $estado, $nome );
	}
}

/**
 * ÚNICA função que imprime resultado — e que conta.
 *
 * Formato: `ESTADO  nome.checagem  — mensagem  [evidência: classe/fase]`
 *
 * @param string $estado    Um dos estados fechados.
 * @param string $nome      Nome da checagem (`familia.checagem`).
 * @param string $mensagem  O que foi observado, nos dois ramos.
 * @param string $classe    Classe de evidência.
 * @param string $fase      Fase.
 * @return void
 */
function estado( string $estado, string $nome, string $mensagem, string $classe, string $fase ): void {
	if ( ! in_array( $estado, F3Base_Suite::ESTADOS, true ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: estado '%s' fora da lista fechada em '%s'.\n", $estado, $nome ) );
		exit( 3 );
	}

	if ( ! in_array( $classe, F3Base_Suite::CLASSES, true ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: classe de evidência '%s' fora da lista em '%s'.\n", $classe, $nome ) );
		exit( 3 );
	}

	if ( ! in_array( $fase, F3Base_Suite::FASES, true ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: fase '%s' fora da lista em '%s'.\n", $fase, $nome ) );
		exit( 3 );
	}

	/* O CONTADOR MORA AQUI DENTRO. Nunca por fora, nunca no chamador. */
	F3Base_Suite::anotar( $estado, $nome );

	printf(
		"%-7s %-44s — %s  [evidência: %s/%s]\n",
		$estado,
		$nome,
		$mensagem,
		$classe,
		$fase
	);
}

/**
 * Emissão classificada por ORIGEM do erro.
 *
 * A regra inteira mora nesta função: site → FALHA, terceiro → WARN,
 * ambiente → BLOCKED com o recurso nomeado. Quando `$ok` é verdadeiro o estado
 * é sempre OK, qualquer que seja a origem.
 *
 * @param bool   $ok       Resultado observado.
 * @param string $origem   `site`, `terceiro` ou `ambiente`.
 * @param string $nome     Nome da checagem.
 * @param string $msg_ok   Mensagem do ramo aprovado.
 * @param string $msg_erro Mensagem do ramo reprovado.
 * @param string $classe   Classe de evidência.
 * @param string $fase     Fase.
 * @param string $recurso  Recurso ausente, obrigatório quando a origem é `ambiente`.
 * @return void
 */
function estado_por_origem( bool $ok, string $origem, string $nome, string $msg_ok, string $msg_erro, string $classe, string $fase, string $recurso = '' ): void {
	if ( ! isset( F3Base_Suite::ORIGENS[ $origem ] ) ) {
		fwrite( STDERR, sprintf( "ERRO DE SUÍTE: origem '%s' desconhecida em '%s'.\n", $origem, $nome ) );
		exit( 3 );
	}

	if ( $ok ) {
		estado( 'OK', $nome, $msg_ok, $classe, $fase );
		return;
	}

	$destino = F3Base_Suite::ORIGENS[ $origem ];

	if ( 'ambiente' === $origem ) {
		if ( '' === $recurso ) {
			fwrite( STDERR, sprintf( "ERRO DE SUÍTE: origem 'ambiente' sem recurso nomeado em '%s'.\n", $nome ) );
			exit( 3 );
		}

		$msg_erro = $msg_erro . ' Recurso ausente: ' . $recurso . '.';
	}

	estado( $destino, $nome, $msg_erro, $classe, $fase );
}

/* -------------------------------------------------------------------------
 * Utilitários de varredura. Compartilhados para que nenhuma sonda invente a
 * própria noção de "o pacote inteiro".
 * ---------------------------------------------------------------------- */

/**
 * Diretórios que NENHUMA varredura de pacote alcança, com o motivo.
 *
 * - `suite/fixtures/`: por construção contém os defeitos plantados. Varrer as
 *   fixtures junto com o pacote faria toda checagem reprovar por causa do
 *   próprio piso — o detector gritando por causa de si mesmo.
 * - `dist/`: saída do empacotamento, gerada por esta suíte e declarada como
 *   tal no inventário; não pertence ao pacote que o operador faz upload.
 *
 * @return array<int,string>
 */
function f3b_excluidos(): array {
	return array( 'suite/fixtures/', 'dist/' );
}

/**
 * Lista recursiva de arquivos de uma raiz, em ordem de caminho relativo.
 *
 * @param string             $raiz       Raiz absoluta.
 * @param array<int,string>  $extensoes  Extensões (sem ponto). Vazio = todas.
 * @param array<int,string>  $excluir    Prefixos relativos a pular.
 * @return array<int,string> Caminhos relativos.
 */
function f3b_arquivos( string $raiz, array $extensoes = array(), array $excluir = array() ): array {
	$raiz = rtrim( $raiz, '/' );

	if ( ! is_dir( $raiz ) ) {
		return array();
	}

	$saida = array();
	$iter  = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);

	foreach ( $iter as $item ) {
		if ( ! $item->isFile() ) {
			continue;
		}

		$rel  = ltrim( substr( $item->getPathname(), strlen( $raiz ) ), '/' );
		$pula = false;

		foreach ( $excluir as $prefixo ) {
			if ( str_starts_with( $rel, $prefixo ) ) {
				$pula = true;
				break;
			}
		}

		if ( $pula ) {
			continue;
		}

		if ( array() !== $extensoes && ! in_array( strtolower( (string) pathinfo( $rel, PATHINFO_EXTENSION ) ), $extensoes, true ) ) {
			continue;
		}

		$saida[] = $rel;
	}

	sort( $saida );

	return $saida;
}

/**
 * Fonte PHP sem comentários, com as linhas preservadas.
 *
 * A varredura mede o que EXECUTA. Sem isto, a menção a uma armadilha dentro do
 * comentário que a explica reprova o arquivo correto — e é justamente o que o
 * pacote faz: `class-f3base-imp-journal.php` cita `update_option` na prosa que
 * explica por que ele mora em um arquivo só.
 *
 * @param string $caminho Caminho absoluto.
 * @return string Código sem comentário.
 */
function f3b_codigo_php( string $caminho ): string {
	$src   = (string) file_get_contents( $caminho );
	$saida = '';

	foreach ( token_get_all( $src ) as $token ) {
		if ( is_array( $token ) && in_array( $token[0], array( T_COMMENT, T_DOC_COMMENT ), true ) ) {
			$saida .= str_repeat( "\n", substr_count( $token[1], "\n" ) );
			continue;
		}

		$saida .= is_array( $token ) ? $token[1] : $token;
	}

	return $saida;
}

/**
 * Argumentos de cada chamada de uma função, com parênteses balanceados.
 *
 * @param string $src    Código.
 * @param string $funcao Nome da função.
 * @return array<int,string>
 */
function f3b_chamadas( string $src, string $funcao ): array {
	$saida = array();
	$pos   = 0;
	$tam   = strlen( $src );

	while ( false !== ( $pos = strpos( $src, $funcao . '(', $pos ) ) ) {
		if ( $pos > 0 && preg_match( '/[A-Za-z0-9_$]/', $src[ $pos - 1 ] ) ) {
			$pos += strlen( $funcao ) + 1;
			continue;
		}

		$i     = $pos + strlen( $funcao ) + 1;
		$nivel = 1;
		$buf   = '';

		while ( $i < $tam && $nivel > 0 ) {
			$c = $src[ $i ];

			if ( '(' === $c ) {
				$nivel++;
			}

			if ( ')' === $c ) {
				$nivel--;

				if ( 0 === $nivel ) {
					break;
				}
			}

			$buf .= $c;
			$i++;
		}

		$saida[] = $buf;
		$pos     = $i;
	}

	return $saida;
}

/**
 * Argumentos de cada chamada cujo cabeçalho casa com uma expressão regular.
 *
 * Existe separado de `f3b_chamadas()` porque a busca por substring precisa
 * rejeitar `xversion_compare(` e ao mesmo tempo ACEITAR
 * `F3Base_Imp_Config::obter(` — onde o caractere anterior ao trecho procurado é
 * o `_` do nome da classe. Uma guarda só não resolve os dois casos; a expressão
 * regular resolve, porque ela descreve o cabeçalho inteiro da chamada.
 *
 * @param string $src Código.
 * @param string $re  Expressão regular cujo casamento TERMINA no parêntese de abertura.
 * @return array<int,string>
 */
function f3b_chamadas_regex( string $src, string $re ): array {
	$saida = array();

	if ( ! preg_match_all( $re, $src, $ms, PREG_OFFSET_CAPTURE ) ) {
		return $saida;
	}

	$tam = strlen( $src );

	foreach ( $ms[0] as $m ) {
		$i     = (int) $m[1] + strlen( $m[0] );
		$nivel = 1;
		$buf   = '';

		while ( $i < $tam && $nivel > 0 ) {
			$c = $src[ $i ];

			if ( '(' === $c ) {
				$nivel++;
			}

			if ( ')' === $c ) {
				$nivel--;

				if ( 0 === $nivel ) {
					break;
				}
			}

			$buf .= $c;
			$i++;
		}

		$saida[] = $buf;
	}

	return $saida;
}

/**
 * Achata um array em caminhos pontilhados, com `*` no índice numérico.
 *
 * @param mixed              $valor    Valor.
 * @param string             $prefixo  Prefixo do caminho.
 * @param array<string,bool> $acumula  Acumulador por referência.
 * @return void
 */
function f3b_achatar( $valor, string $prefixo, array &$acumula ): void {
	if ( '' !== $prefixo ) {
		$acumula[ $prefixo ] = true;
	}

	if ( ! is_array( $valor ) ) {
		return;
	}

	foreach ( $valor as $chave => $filho ) {
		$seg = is_int( $chave ) ? '*' : (string) $chave;
		f3b_achatar( $filho, '' === $prefixo ? $seg : $prefixo . '.' . $seg, $acumula );
	}
}

/**
 * Lê um TSV declarado da suíte, ignorando comentário e linha vazia.
 *
 * @param string $caminho Caminho absoluto.
 * @return array<int,array<int,string>>
 */
function f3b_tsv( string $caminho ): array {
	if ( ! is_file( $caminho ) ) {
		return array();
	}

	$saida = array();

	foreach ( preg_split( '/\R/', (string) file_get_contents( $caminho ) ) ?: array() as $linha ) {
		$linha = rtrim( $linha, "\r\n" );

		if ( '' === trim( $linha ) || str_starts_with( ltrim( $linha ), '#' ) ) {
			continue;
		}

		$saida[] = explode( "\t", $linha );
	}

	return $saida;
}

/**
 * Recorta uma lista de achados para caber na linha, sem esconder o total.
 *
 * @param array<int,string> $achados Achados.
 * @param int               $limite  Quantos mostrar.
 * @return string
 */
function f3b_amostra( array $achados, int $limite = 6 ): string {
	$total = count( $achados );
	$corte = array_slice( $achados, 0, $limite );
	$texto = implode( '; ', $corte );

	if ( $total > $limite ) {
		$texto .= sprintf( '; (+%d)', $total - $limite );
	}

	return $texto;
}

/**
 * `config/site.json` da raiz varrida, analisado.
 *
 * @param string $raiz Raiz.
 * @return array<string,mixed>|null
 */
function f3b_config( string $raiz ): ?array {
	$arquivo = $raiz . '/config/site.json';

	if ( ! is_file( $arquivo ) ) {
		return null;
	}

	$json = json_decode( (string) file_get_contents( $arquivo ), true );

	return is_array( $json ) ? $json : null;
}

/**
 * Resumo por estado com CONTAGEM E NOMES na mesma saída.
 *
 * Formatador ÚNICO da suíte: qualquer runner que imprima quantos fecharam em
 * cada estado passa por aqui, e por aqui a lista de nomes vem junto. Estado OK
 * sai resumido — o que não pode existir é estado ruim invisível.
 *
 * @param array<string,int>               $contagem Contagem por estado.
 * @param array<string,array<int,string>> $nomes    Nomes por estado.
 * @return array<int,string> Uma linha por estado, pronta para impressão.
 */
function f3b_resumo_por_estado( array $contagem, array $nomes ): array {
	$saida = array();

	foreach ( F3Base_Suite::ESTADOS as $estado ) {
		$quantas = (int) ( $contagem[ $estado ] ?? 0 );
		$lista   = isset( $nomes[ $estado ] ) && is_array( $nomes[ $estado ] ) ? $nomes[ $estado ] : array();

		if ( 'OK' === $estado ) {
			$saida[] = sprintf( '   %-8s %-4d (não nomeadas: estado OK sai resumido, por desenho)', $estado, $quantas );
			continue;
		}

		$saida[] = sprintf(
			'   %-8s %-4d %s',
			$estado,
			$quantas,
			array() === $lista ? 'nenhum' : implode( ', ', $lista )
		);
	}

	return $saida;
}
