<?php
/**
 * Sonda funcional: exercita as funções PURAS do pacote, sem WordPress.
 *
 * Subprocesso por desenho — carregar as classes do implantador define ABSPATH e
 * um punhado de funções do núcleo, e isso não pode vazar para o processo que
 * imprime os estados. Devolve JSON; quem imprime e conta é `estado()`.
 *
 * Cada bloco tem TETO (o caso correto continua em silêncio) e PISO (o mutante
 * precisa reprovar) na mesma sonda: uma validação que só foi exercitada com o
 * arquivo certo não provou saber reprovar nada.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( $argv[1] ?? '', '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

define( 'ABSPATH', '/tmp/f3base-sem-wordpress/' );
define( 'F3BASE_IMP_DIR', $raiz . '/' );
define( 'F3BASE_IMP_ARQUIVO', $raiz . '/implantador-base.php' );
define( 'F3BASE_IMP_TEXT_DOMAIN', 'f3base' );

/**
 * Caminho relativo do arquivo principal, como o núcleo o produz.
 *
 * Mesma forma do original — `<pasta>/<arquivo>.php` —, para que o slug que o
 * preflight extrai daqui seja o mesmo que ele extrai no site.
 *
 * @param string $arquivo Caminho absoluto do arquivo principal.
 * @return string
 */
function plugin_basename( string $arquivo ): string {
	return basename( dirname( $arquivo ) ) . '/' . basename( $arquivo );
}

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor  Valor.
 * @param int   $flags  Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * Escape de saída do núcleo.
 *
 * A MESMA função que a interpolação usa para gravar e que a leitura de volta
 * usa para conferir: fossem duas, a checagem poderia aprovar um conteúdo em que
 * o valor gravado e o valor procurado só coincidem por acaso.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_html( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES );
}

/**
 * Desserialização tolerante do núcleo.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function maybe_unserialize( $valor ) {
	if ( is_string( $valor ) ) {
		$dados = @unserialize( trim( $valor ) );

		if ( false !== $dados || 'b:0;' === trim( $valor ) ) {
			return $dados;
		}
	}

	return $valor;
}

/**
 * Caminho dentro do pacote, com a mesma guarda de travessia do implantador.
 *
 * @param string $relativo Caminho relativo.
 * @return string
 */
function f3base_imp_caminho( string $relativo ): string {
	$base = rtrim( F3BASE_IMP_DIR, '/' ) . '/';

	if ( '' === $relativo || str_contains( $relativo, '../' ) ) {
		return '';
	}

	$candidato = $base . ltrim( $relativo, '/' );
	$real      = realpath( $candidato );

	if ( false === $real ) {
		return $candidato;
	}

	return str_starts_with( $real, $base ) ? $real : '';
}

require $raiz . '/includes/class-f3base-imp-config.php';
require $raiz . '/includes/class-f3base-imp-conteudo.php';
require $raiz . '/includes/class-f3base-imp-relatorio.php';
require $raiz . '/includes/class-f3base-imp-lotes.php';
require $raiz . '/includes/class-f3base-imp-entrega.php';
require $raiz . '/includes/class-f3base-imp-preflight.php';
require $raiz . '/includes/class-f3base-imp-plugins.php';

$resultado = array();

/**
 * Acumula um achado.
 *
 * @param string $checagem Nome.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]             = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Registra uma medida (aprovando ou não).
 *
 * @param string $checagem Nome.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Contém, sem depender de caixa.
 *
 * O texto do relatório grifa em MAIÚSCULA o que precisa saltar aos olhos, e
 * uma sonda presa à caixa reprovaria a ênfase em vez do conteúdo.
 *
 * @param string $palheiro Texto medido.
 * @param string $agulha   Trecho exigido ou proibido.
 * @return bool
 */
function contem( string $palheiro, string $agulha ): bool {
	return '' !== $agulha && false !== stripos( $palheiro, $agulha );
}

/* ---------- config.schema_valida: teto e piso ---------- */

$nome = 'config.schema_valida';
medir( $nome );

if ( ! F3Base_Imp_Config::carregar() ) {
	anotar( $nome, 'teto: site.json não valida contra o schema — ' . implode( ' | ', F3Base_Imp_Config::erros() ) );
}

medir( $nome );

if ( false !== F3Base_Imp_Config::obter( 'cabecalhos.hsts', true ) ) {
	anotar( $nome, 'teto: cabecalhos.hsts não foi lido do lugar certo' );
}

medir( $nome );

if ( true !== F3Base_Imp_Config::obter( 'ambiente.hsts', true ) ) {
	anotar( $nome, 'teto: chave ausente não devolveu o padrão explícito' );
}

medir( $nome );

if ( false !== F3Base_Imp_Config::existe( 'ambiente.hsts' ) ) {
	anotar( $nome, 'teto: existe() não distingue ausente de declarado' );
}

$original = json_decode( (string) file_get_contents( $raiz . '/config/site.json' ), true );

$mutantes = array(
	'tipo errado'         => static function ( array $c ): array {
		$c['consentimento']['ttl_dias'] = '180';
		return $c;
	},
	'chave não declarada' => static function ( array $c ): array {
		$c['ambiente']['hsts'] = true;
		return $c;
	},
	'obrigatória ausente' => static function ( array $c ): array {
		unset( $c['seo']['organizacao']['nome'] );
		return $c;
	},
	'enum inválido'       => static function ( array $c ): array {
		$c['ambiente']['tipo'] = 'homologacao';
		return $c;
	},
	/*
	 * As duas chaves nascidas na 1.0.12 entram no piso do validador junto com
	 * as outras: chave nova sem mutante é chave cujo schema nunca provou
	 * reprovar nada.
	 */
	'enum de indexação'   => static function ( array $c ): array {
		$c['ambiente']['indexar'] = 'as-vezes';
		return $c;
	},
	'lista de prévia'     => static function ( array $c ): array {
		$c['ambiente']['dominios_de_previa'] = 'dreamhosters.com';
		return $c;
	},
	'padrão de texto'     => static function ( array $c ): array {
		$c['contato']['whatsapp_e164'] = '+55 11 90000-0000';
		return $c;
	},
	'regime misturado'    => static function ( array $c ): array {
		$c['formularios'][0]['pagina_confirmacao'] = array( 'slug' => 'obrigado', 'pai_ref' => null );
		return $c;
	},
	'mínimo numérico'     => static function ( array $c ): array {
		$c['retencao']['leads_meses'] = 0;
		return $c;
	},
	/*
	 * As chaves nascidas na 1.0.17 entram no piso do validador pela mesma razão
	 * que as da 1.0.12: chave nova sem mutante é chave cujo schema nunca provou
	 * reprovar nada. São TRÊS mutantes — o enum novo de permalinks, o enum da
	 * decisão sobre o conteúdo de exemplo, e a ausência dessa chave, que é
	 * obrigatória.
	 */
	'enum de permalinks'  => static function ( array $c ): array {
		$c['ambiente']['permalinks_decisao'] = 'aplicar-sempre-e-torcer';
		return $c;
	},
	'enum de exemplo'     => static function ( array $c ): array {
		$c['conteudo']['exemplo_do_wordpress'] = 'apagar-de-vez';
		return $c;
	},
	'exemplo ausente'     => static function ( array $c ): array {
		unset( $c['conteudo']['exemplo_do_wordpress'] );
		return $c;
	},
	/*
	 * A chave nascida na 1.0.18 entra no piso do validador pela mesma razão que
	 * as anteriores: chave nova sem mutante é chave cujo schema nunca provou
	 * reprovar nada. São DOIS mutantes, porque a chave tem duas regras que
	 * importam — o alfabeto do nome do cabeçalho e o mínimo dos saltos, que não
	 * pode ser zero (zero leria a ponta que o próprio cliente escreveu).
	 */
	'cabeçalho de origem' => static function ( array $c ): array {
		$c['cabecalhos']['origem_confiavel']['cabecalho'] = 'X Forwarded For; drop table';
		return $c;
	},
	'saltos de proxy'     => static function ( array $c ): array {
		$c['cabecalhos']['origem_confiavel']['saltos'] = 0;
		return $c;
	},
	/*
	 * O digesto declarável da 1.0.18 entra no piso do validador com DOIS
	 * mutantes, porque a chave tem duas regras que importam: a FORMA do valor
	 * (64 hexadecimais minúsculos, e não "o que couber numa string") e o RAMO
	 * em que ela é aceita — declarar sha256 numa entrada de origem
	 * `wordpress.org` seria prometer conferência sobre artefato que este
	 * pacote não escolhe, e aquele ramo continua com additionalProperties
	 * fechado.
	 */
	'digesto malformado'  => static function ( array $c ): array {
		foreach ( $c['plugins']['instalaveis'] as $i => $entrada ) {
			if ( 'url' === ( $entrada['origem'] ?? '' ) ) {
				$c['plugins']['instalaveis'][ $i ]['sha256'] = 'SHA256:naosouumdigesto';
			}
		}

		return $c;
	},
	'digesto no ramo errado' => static function ( array $c ): array {
		foreach ( $c['plugins']['instalaveis'] as $i => $entrada ) {
			if ( 'wordpress.org' === ( $entrada['origem'] ?? '' ) ) {
				$c['plugins']['instalaveis'][ $i ]['sha256'] = str_repeat( 'a', 64 );
			}
		}

		return $c;
	},
);

foreach ( $mutantes as $rotulo => $mutar ) {
	medir( $nome );

	if ( array() === F3Base_Imp_Config::validar( $mutar( $original ) ) ) {
		anotar( $nome, 'piso: mutante "' . $rotulo . '" passou sem erro — validador cego' );
	}
}

medir( $nome );

if ( array() !== F3Base_Imp_Config::validar( $original ) ) {
	anotar( $nome, 'piso: o arquivo correto deixou de ficar em silêncio' );
}

/* ---------- conteudo.merge_tres_vias ---------- */

$nome = 'conteudo.merge_tres_vias';
$b    = hash( 'sha256', 'base' );
$h    = hash( 'sha256', 'humano' );
$n    = hash( 'sha256', 'novo' );

$tabela = array(
	array( $b, $b, $b, 'gerenciado', 'atualizar_base', 'igual/igual/igual não grava' ),
	array( $b, $b, $n, 'gerenciado', 'gravar', 'base/base/novo é atualização segura' ),
	array( $b, $h, $b, 'gerenciado', 'preservar', 'base/edição humana/base preserva a edição' ),
	array( $b, $h, $n, 'conflito', 'conflito', 'base/edição humana/novo sem política é conflito' ),
	array( $b, $h, $n, 'gerenciado', 'gravar', 'a mesma linha com política de campo gerenciado grava' ),
	array( $b, $h, $n, 'preservar', 'preservar', 'a mesma linha com política de campo preservado preserva' ),
	array( $h, $n, $n, 'conflito', 'atualizar_base', 'igual ao desejado não grava e atualiza a base' ),
	array( null, $h, $n, 'conflito', 'conflito', 'sem base e divergente é conflito' ),
	array( null, $h, $n, 'preservar', 'preservar', 'sem base com política preservar (a página adotada)' ),
	array( null, $h, $n, 'gerenciado', 'gravar', 'sem base com política gerenciado (primeira execução)' ),
);

foreach ( $tabela as $linha ) {
	medir( $nome );
	$decisao = F3Base_Imp_Conteudo::merge_campo( $linha[0], $linha[1], $linha[2], $linha[3] );

	if ( $decisao['acao'] !== $linha[4] ) {
		anotar( $nome, $linha[5] . ': esperado ' . $linha[4] . ', obtido ' . $decisao['acao'] );
	}
}

/* ---------- conteudo.nao_promocao_status ---------- */

$nome = 'conteudo.nao_promocao_status';
medir( $nome );

if ( ! ( F3Base_Imp_Conteudo::rank_status( 'publish' ) > F3Base_Imp_Conteudo::rank_status( 'draft' ) ) ) {
	anotar( $nome, 'publish não é mais público que draft — a regra de não promoção depende disso' );
}

/* ---------- relatorio.waiver_casa ---------- */

$nome  = 'relatorio.waiver_casa';
$casos = array(
	array( 'orcamento.pagina:home', 'orcamento.pagina:', true, 'prefixo terminado em dois-pontos casa' ),
	array( 'orcamento.pagina', 'orcamento.pagina', true, 'igualdade casa' ),
	array( 'orcamento.pagina:', 'orcamento.pagina:', true, 'igualdade exata do prefixo casa' ),
	array( 'orcamento.paginaX', 'orcamento.pagina', false, 'prefixo sem dois-pontos não casa' ),
	array( 'qualquer.coisa', '', false, 'padrão vazio não casa' ),
	array( 'qualquer.coisa', '*', false, 'asterisco não casa' ),
	array( 'qualquer.coisa', ':', false, 'só dois-pontos não casa' ),
	array( 'qualquer.coisa', '.', false, 'ponto não casa' ),
	array( 'orcamento.pagina:home', 'orcamento.', false, 'prefixo com ponto final não casa' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	if ( F3Base_Imp_Relatorio::waiver_casa( $caso[0], $caso[1] ) !== $caso[2] ) {
		anotar( $nome, $caso[3] . ': resultado invertido' );
	}
}

/* ---------- relatorio.sanitiza_dump ---------- */

$nome    = 'relatorio.sanitiza_dump';
$payload = array(
	'user_email'  => 'pessoa@exemplo.test',
	'sha256'      => 'abc123',
	'serializado' => serialize( array( 'token' => 'segredo-real', 'contagem' => 3 ) ),
	'aninhado'    => array( 'senha' => 'nao-deve-sair', 'ok' => 'pode-sair' ),
	'solto'       => 'outra@pessoa.test',
);

$texto = (string) wp_json_encode( F3Base_Imp_Relatorio::sanitizar( $payload ) );

$assercoes = array(
	array( ! str_contains( $texto, 'pessoa@exemplo.test' ), 'e-mail em chave proibida não foi redigido' ),
	array( ! str_contains( $texto, 'outra@pessoa.test' ), 'e-mail solto não foi redigido pelo valor' ),
	array( ! str_contains( $texto, 'segredo-real' ), 'token dentro de array serializado não foi alcançado' ),
	array( ! str_contains( $texto, 'nao-deve-sair' ), 'senha aninhada não foi redigida' ),
	array( str_contains( $texto, 'abc123' ), 'hash técnico de estado foi removido sem motivo' ),
	array( str_contains( $texto, 'pode-sair' ), 'valor legítimo foi removido' ),
	array( str_contains( $texto, '__redigido' ), 'a redação não preservou a estrutura' ),
	array( str_contains( $texto, '"contagem":3' ), 'a estrutura do serializado foi corrompida' ),
);

foreach ( $assercoes as $a ) {
	medir( $nome );

	if ( ! $a[0] ) {
		anotar( $nome, $a[1] );
	}
}

/* ---------- formulario.veredito_destino: teto e piso ---------- */

/*
 * O defeito medido: `contato.whatsapp_e164` nasce VAZIA no template, por
 * desenho, e a etapa fechava FALHA — pré-condição ausente tratada como defeito
 * do pacote. Os dois ramos precisam existir e ficar provados aqui: chave vazia
 * é BLOCKED nomeando a chave a preencher, e chave preenchida com valor que o
 * regime não aceita continua FALHA. Um ramo só é a metade que mente.
 */

$nome  = 'formulario.veredito_destino';
$casos = array(
	array( 'whatsapp', 'contato.whatsapp_e164', '', 'BLOCKED', 'contato.whatsapp_e164', 'chave declarada e vazia é BLOCKED' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '   ', 'BLOCKED', 'contato.whatsapp_e164', 'só espaço continua sendo vazio' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '5511900000000', 'OK', '', 'E.164 só com dígitos é aceito' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '+55 11 90000-0000', 'FALHA', 'PREENCHIDA', 'preenchido com pontuação é FALHA, não BLOCKED' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '551', 'FALHA', 'PREENCHIDA', 'curto demais para E.164 é FALHA' ),
	array( 'whatsapp', 'contato.whatsapp_e164', '5511900000000000000', 'FALHA', 'PREENCHIDA', 'longo demais para E.164 é FALHA' ),
	array( 'cf7-email', 'contato.email_leads', '', 'BLOCKED', 'contato.email_leads', 'a mesma regra vale para o outro regime' ),
	array( 'cf7-email', 'contato.email_leads', 'leads@exemplo.test', 'OK', '', 'e-mail válido é aceito' ),
	array( 'cf7-email', 'contato.email_leads', 'leads-arroba-exemplo', 'FALHA', 'PREENCHIDA', 'e-mail preenchido e inválido é FALHA' ),
	array( 'whatsapp', '', '5511900000000', 'FALHA', 'destino', 'entrada sem chave de destino é defeito da entrada, não pré-condição' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Lotes::veredito_destino( $caso[0], $caso[1], $caso[2] );

	if ( $veredito['estado'] !== $caso[3] ) {
		anotar( $nome, $caso[5] . ': esperado ' . $caso[3] . ', obtido ' . $veredito['estado'] );
		continue;
	}

	medir( $nome );

	if ( '' !== $caso[4] && ! str_contains( $veredito['motivo'], $caso[4] ) ) {
		anotar( $nome, $caso[5] . ': o motivo do ramo ' . $caso[3] . ' não menciona "' . $caso[4] . '"' );
	}

	medir( $nome );

	if ( '' === trim( $veredito['resumo'] ) ) {
		anotar( $nome, $caso[5] . ': ramo ' . $caso[3] . ' sem resumo para a linha da unidade' );
	}
}



/* ---------- privacidade.controlador_identificado: teto e piso dos três ramos ---------- */

/*
 * O defeito medido na 1.0.12, dito por inteiro: a página da política de
 * privacidade nascia `status: "draft"` na configuração, e a decisão de não
 * publicá-la — tomada pelo pacote, por um motivo real que ninguém tinha
 * ratificado — não aparecia em linha nenhuma do relatório. Junto com ela, o
 * `seo.indexar` da mesma página tinha ido para `true` e o texto continuava
 * afirmando o rascunho: configuração e conteúdo se contradiziam.
 *
 * A correção é a mesma inversão da indexação: a intenção declarada é produção,
 * e uma GUARDA MEDIDA segura, nomeando a si mesma, as chaves vazias e a saída.
 * Os três ramos precisam existir e ficar provados aqui, porque cada um deles é
 * uma classificação diferente e nenhuma é intercambiável:
 *
 * - chave vazia é PRÉ-CONDIÇÃO ausente, e pré-condição ausente é BLOCKED;
 * - chave cheia com o valor no conteúdo servido é OK, medido por LEITURA DE
 *   VOLTA — configuração preenchida não é o mesmo que texto identificado;
 * - chave cheia com o valor AUSENTE do conteúdo é FALHA, porque aí a guarda
 *   liberou a publicação e a política está no ar sem dizer quem trata os dados.
 */

$nome = 'privacidade.controlador_identificado';
$C    = 'F3Base_Imp_Conteudo';

/**
 * Valores do controlador, na forma de caminho => valor que o pacote usa.
 *
 * @param array<string,string> $mudanca O que este caso muda.
 * @return array<string,string>
 */
function f3b_controlador( array $mudanca = array() ): array {
	return $mudanca + array(
		'contato.controlador.razao_social' => 'Fator 3 Ventures Ltda.',
		'contato.controlador.documento'    => '00.000.000/0001-00',
		'contato.controlador.endereco'     => 'Rua da Medicao, 42, Sao Paulo, SP',
		'contato.controlador.encarregado'  => '',
	);
}

$completo = f3b_controlador();
$servido  = 'Fator 3 Ventures Ltda. — 00.000.000/0001-00 — Rua da Medicao, 42, Sao Paulo, SP';

$casos_controlador = array(
	array(
		'rotulo'   => 'as tres chaves vazias fecham BLOCKED, nomeando as tres e a saida',
		'medido'   => f3b_controlador(
			array(
				'contato.controlador.razao_social' => '',
				'contato.controlador.documento'    => '',
				'contato.controlador.endereco'     => '',
			)
		),
		'conteudo' => 'texto sem qualificacao nenhuma',
		'estado'   => 'BLOCKED',
		'exige'    => array( 'contato.controlador.razao_social', 'contato.controlador.documento', 'contato.controlador.endereco', 'publica sozinha na execução seguinte' ),
		'proibe'   => array( 'furou em silêncio' ),
	),
	array(
		'rotulo'   => 'uma chave vazia fecha BLOCKED nomeando SO ela: contagem sem nome nao responde nada',
		'medido'   => f3b_controlador( array( 'contato.controlador.endereco' => '   ' ) ),
		'conteudo' => $servido,
		'estado'   => 'BLOCKED',
		'exige'    => array( 'contato.controlador.endereco', '1 chave(s)' ),
		'proibe'   => array( 'contato.controlador.razao_social' ),
	),
	array(
		'rotulo'   => 'chaves completas e qualificacao presente no conteudo servido fecham OK',
		'medido'   => $completo,
		'conteudo' => $servido,
		'estado'   => 'OK',
		'exige'    => array( 'conteúdo SERVIDO', 'art. 9' ),
		'proibe'   => array( 'pré-condição ausente', 'furou em silêncio' ),
	),
	array(
		'rotulo'   => 'chaves completas e um valor AUSENTE do conteudo fecham FALHA, nomeando qual',
		'medido'   => $completo,
		'conteudo' => 'Fator 3 Ventures Ltda. — Rua da Medicao, 42, Sao Paulo, SP',
		'estado'   => 'FALHA',
		'exige'    => array( 'contato.controlador.documento', 'furou em silêncio' ),
		'proibe'   => array( 'pré-condição ausente' ),
	),
	array(
		'rotulo'   => 'marcador nao resolvido sobrevivendo no conteudo servido fecha FALHA',
		'medido'   => $completo,
		'conteudo' => $servido . ' e o encarregado é %f3base:contato.controlador.encarregado_errado%',
		'estado'   => 'FALHA',
		'exige'    => array( 'marcador de interpolação não resolvido' ),
		'proibe'   => array( 'pré-condição ausente' ),
	),
);

foreach ( $casos_controlador as $caso ) {
	medir( $nome );

	$veredito = $C::veredito_do_controlador( $caso['medido'], $caso['conteudo'] );

	if ( $veredito['estado'] !== $caso['estado'] ) {
		anotar( $nome, $caso['rotulo'] . ': esperado ' . $caso['estado'] . ', obtido ' . $veredito['estado'] );
		continue;
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo do ramo ' . $caso['estado'] . ' não traz "' . $trecho . '"' );
		}
	}

	foreach ( $caso['proibe'] as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo do ramo ' . $caso['estado'] . ' trouxe "' . $trecho . '", que é texto de outro ramo' );
		}
	}

	medir( $nome );

	if ( '' === trim( $veredito['resumo'] ) ) {
		anotar( $nome, $caso['rotulo'] . ': ramo ' . $caso['estado'] . ' sem resumo para a linha da unidade' );
	}
}

/* O PRODUTOR ÚNICO do status efetivo: quem ele segura, quem ele não toca. */

$vazio_no_endereco = f3b_controlador( array( 'contato.controlador.endereco' => '' ) );

$casos_status = array(
	array(
		'rotulo' => 'pagina que nao e a politica publica mesmo com o controlador vazio',
		'args'   => array( 'contato', 'publish', 'privacidade', $vazio_no_endereco ),
		'status' => 'publish',
		'exige'  => array( 'Nenhuma guarda de status se aplica' ),
	),
	array(
		'rotulo' => 'a politica com uma chave vazia fica em draft, nomeando a chave e a saida',
		'args'   => array( 'privacidade', 'publish', 'privacidade', $vazio_no_endereco ),
		'status' => 'draft',
		'exige'  => array( 'contato.controlador.endereco', 'guarda MEDIDA', 'publica sozinha na execução seguinte', 'art. 9' ),
	),
	array(
		'rotulo' => 'a politica com as tres chaves cheias publica, e a guarda diz que MEDIU e nao segurou',
		'args'   => array( 'privacidade', 'publish', 'privacidade', $completo ),
		'status' => 'publish',
		'exige'  => array( 'foi MEDIDA e não segurou' ),
	),
	array(
		'rotulo' => 'o produtor nunca PROMOVE: draft declarado continua draft com tudo preenchido',
		'args'   => array( 'privacidade', 'draft', 'privacidade', $completo ),
		'status' => 'draft',
		'exige'  => array( 'que é o declarado na configuração' ),
	),
	array(
		'rotulo' => 'projeto que nao declara pagina de politica nao tem guarda aplicavel',
		'args'   => array( 'privacidade', 'publish', '', $vazio_no_endereco ),
		'status' => 'publish',
		'exige'  => array( 'Nenhuma guarda de status se aplica' ),
	),
);

foreach ( $casos_status as $caso ) {
	medir( $nome );

	$veredito = $C::veredito_de_status_de_pagina( $caso['args'][0], $caso['args'][1], $caso['args'][2], $caso['args'][3] );

	if ( $veredito['status'] !== $caso['status'] ) {
		anotar( $nome, $caso['rotulo'] . ': esperado status "' . $caso['status'] . '", obtido "' . $veredito['status'] . '"' );
		continue;
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo não traz "' . $trecho . '"' );
		}
	}
}

/* ---------- A IDENTIDADE da política: onde ela mora, e o que NÃO pode derrubá-la ---------- */

/*
 * O defeito da 1.0.13, dito por inteiro: a identidade da página de política era
 * lida de `seo.llms_selecao.politica_privacidade`. Matar o literal
 * `'privacidade' === $ref` estava certo; o destino estava errado. Quem
 * desligasse `bots_ia.llms_txt` e limpasse a seleção — operação legítima, que o
 * nome da chave convida a fazer — parava de gravar `wp_page_for_privacy_policy`
 * E derrubava esta checagem em "condição de aplicabilidade falsa". Uma chave de
 * SEO silenciava uma checagem exigida pelo art. 9º da LGPD, com o relatório
 * verde.
 *
 * O piso abaixo é o que o dono exigiu: com o llms.txt DESLIGADO e a seleção
 * VAZIA, a política continua identificada, `wp_page_for_privacy_policy`
 * continua sendo gravada e a checagem do controlador continua falando.
 */

$paginas_do_projeto = array(
	array( 'ref' => 'home', 'papel' => '' ),
	array( 'ref' => 'contato', 'papel' => '' ),
	array( 'ref' => 'privacidade', 'papel' => 'politica-privacidade' ),
);

$casos_identidade = array(
	array( 'rotulo' => 'o papel declarado na entrada da página resolve a identidade', 'entradas' => $paginas_do_projeto, 'ref' => 'privacidade' ),
	array( 'rotulo' => 'nenhuma entrada com papel: projeto sem política declarada', 'entradas' => array( array( 'ref' => 'home', 'papel' => '' ) ), 'ref' => '' ),
	array( 'rotulo' => 'papel declarado com ref vazia não inventa referência', 'entradas' => array( array( 'ref' => '', 'papel' => 'politica-privacidade' ) ), 'ref' => '' ),
	array( 'rotulo' => 'entrada que não é array não derruba a resolução', 'entradas' => array( 'lixo', array( 'ref' => 'p', 'papel' => 'politica-privacidade' ) ), 'ref' => 'p' ),
	array( 'rotulo' => 'papel de outro valor não casa', 'entradas' => array( array( 'ref' => 'x', 'papel' => 'outro-papel' ) ), 'ref' => '' ),
);

foreach ( $casos_identidade as $caso ) {
	medir( $nome );

	$obtido = $C::ref_da_politica_em( $caso['entradas'] );

	if ( $obtido !== $caso['ref'] ) {
		anotar( $nome, $caso['rotulo'] . ': esperado "' . $caso['ref'] . '", obtido "' . $obtido . '"' );
	}
}

/*
 * O PISO DO DONO. As entradas de página de um projeto que desligou o llms.txt
 * são EXATAMENTE as mesmas — o papel não mora lá —, e é isso que a resolução
 * prova. A proibição estática que sustenta a prova está em
 * `estatica.politica_privacidade_fonte_unica`, cláusula 3: o produtor não pode
 * ler caminho fora de `paginas.*`.
 */

$ref_com_llms_desligado = $C::ref_da_politica_em( $paginas_do_projeto );

medir( $nome );

if ( 'privacidade' !== $ref_com_llms_desligado ) {
	anotar( $nome, 'llms.txt desligado e seleção vazia: a identidade da política deixou de resolver — foi exatamente esse o defeito da 1.0.13' );
}

medir( $nome );

if ( ! $C::grava_pagina_de_privacidade( $ref_com_llms_desligado, 'privacidade', 12 ) ) {
	anotar( $nome, 'llms.txt desligado e seleção vazia: wp_page_for_privacy_policy deixaria de ser gravada' );
}

medir( $nome );

if ( $C::grava_pagina_de_privacidade( $ref_com_llms_desligado, 'contato', 12 ) ) {
	anotar( $nome, 'wp_page_for_privacy_policy seria gravada apontando para uma página que não é a política' );
}

medir( $nome );

if ( $C::grava_pagina_de_privacidade( $ref_com_llms_desligado, 'privacidade', 0 ) ) {
	anotar( $nome, 'wp_page_for_privacy_policy seria gravada com ID zero: option apontando para objeto que não existe' );
}

medir( $nome );

if ( $C::grava_pagina_de_privacidade( '', 'privacidade', 12 ) ) {
	anotar( $nome, 'sem política declarada, wp_page_for_privacy_policy seria gravada assim mesmo' );
}

/* Os QUATRO ramos da checagem, com a mesma identidade resolvida sem llms.txt. */

$ramos_da_checagem = array(
	array(
		'rotulo' => 'llms.txt desligado e seleção vazia: a checagem CONTINUA falando, e fala OK',
		'args'   => array( $ref_com_llms_desligado, 12, $completo, $servido ),
		'estado' => 'OK',
		'proibe' => array( 'condição de aplicabilidade falsa' ),
	),
	array(
		'rotulo' => 'chave vazia com a página aplicada continua BLOCKED de pré-condição',
		'args'   => array( $ref_com_llms_desligado, 12, $vazio_no_endereco, $servido ),
		'estado' => 'BLOCKED',
		'exige'  => array( 'contato.controlador.endereco' ),
	),
	array(
		'rotulo' => 'página ainda não aplicada é BLOCKED nomeando a pendência, nunca FALHA',
		'args'   => array( $ref_com_llms_desligado, 0, $completo, '' ),
		'estado' => 'BLOCKED',
		'exige'  => array( 'ainda não existe no banco' ),
	),
	array(
		'rotulo' => 'projeto sem política declarada fecha N/A dizendo que o llms.txt não a silencia',
		'args'   => array( '', 0, $completo, '' ),
		'estado' => 'N/A',
		'exige'  => array( 'papel = "politica-privacidade"', 'bots_ia.llms_txt' ),
	),
);

foreach ( $ramos_da_checagem as $caso ) {
	medir( $nome );

	$veredito = $C::veredito_da_checagem_do_controlador( $caso['args'][0], $caso['args'][1], $caso['args'][2], $caso['args'][3] );

	if ( $veredito['estado'] !== $caso['estado'] ) {
		anotar( $nome, $caso['rotulo'] . ': esperado ' . $caso['estado'] . ', obtido ' . $veredito['estado'] );
		continue;
	}

	foreach ( ( $caso['exige'] ?? array() ) as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo não traz "' . $trecho . '"' );
		}
	}

	foreach ( ( $caso['proibe'] ?? array() ) as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo trouxe "' . $trecho . '", que é texto de outro ramo' );
		}
	}

	medir( $nome );

	if ( '' === trim( $veredito['evidencia'] ) || '' === trim( $veredito['fase'] ) ) {
		anotar( $nome, $caso['rotulo'] . ': ramo sem classe de evidência ou sem fase declarada' );
	}
}

/* E a configuração REAL: o papel está declarado, e o caminho aposentado sumiu. */

medir( $nome );

if ( 'privacidade' !== $C::ref_da_politica_de_privacidade() ) {
	anotar( $nome, 'a configuração deste pacote não declara papel = "politica-privacidade" em nenhuma entrada de paginas: a identidade da política ficou sem produtor' );
}

medir( $nome );

$config_bruta = (array) json_decode( (string) file_get_contents( $raiz . '/config/site.json' ), true );

if ( array_key_exists( 'politica_privacidade', (array) ( $config_bruta['seo']['llms_selecao'] ?? array() ) ) ) {
	anotar( $nome, 'seo.llms_selecao ainda declara "politica_privacidade": a seleção do llms.txt voltou a POSSUIR o fato em vez de referenciar o produtor' );
}

/* A INTERPOLAÇÃO no arquivo REAL da política: o teto que prova o caminho todo. */

$ref_politica = $C::ref_da_politica_de_privacidade();
$arquivo_pol  = $raiz . '/content/pages/' . $ref_politica . '.html';

medir( $nome );

if ( '' === $ref_politica || ! is_file( $arquivo_pol ) ) {
	anotar( $nome, 'a configuração declara a política em "' . $ref_politica . '" e não há content/pages/' . $ref_politica . '.html para interpolar' );
} else {
	$bruto = (string) file_get_contents( $arquivo_pol );

	medir( $nome );

	if ( ! contem( $bruto, '%f3base:contato.controlador.razao_social%' ) ) {
		anotar( $nome, 'o arquivo da política não carrega o marcador da razão social: sem marcador a interpolação não tem onde escrever, e a página publicaria sem identificar o controlador' );
	}

	$com_encarregado = f3b_controlador( array( 'contato.controlador.encarregado' => 'Maria da Medicao' ) );
	$interpolado     = $C::interpolar_com( $bruto, $com_encarregado );

	foreach ( $com_encarregado as $caminho => $valor ) {
		medir( $nome );

		if ( '' !== $valor && ! contem( $interpolado, esc_html( $valor ) ) ) {
			anotar( $nome, 'interpolação: o valor de ' . $caminho . ' não chegou ao conteúdo produzido' );
		}
	}

	medir( $nome );

	if ( contem( $interpolado, $C::MARCA_ABRE ) ) {
		anotar( $nome, 'interpolação: sobrou marcador não resolvido no conteúdo produzido com todos os valores preenchidos' );
	}

	medir( $nome );

	if ( contem( $interpolado, 'Nenhum encarregado é nomeado' ) ) {
		anotar( $nome, 'bloco condicional: com encarregado preenchido, a redação que diz que não há encarregado continuou no conteúdo — as duas afirmações contraditórias na mesma página' );
	}

	$sem_encarregado = $C::interpolar_com( $bruto, f3b_controlador() );

	medir( $nome );

	if ( ! contem( $sem_encarregado, 'Nenhum encarregado é nomeado' ) ) {
		anotar( $nome, 'bloco condicional: com encarregado vazio, a redação que explica quem recebe os pedidos sumiu do conteúdo' );
	}

	medir( $nome );

	if ( contem( $sem_encarregado, 'art. 41 da LGPD, é ' ) ) {
		anotar( $nome, 'bloco condicional: com encarregado vazio, a redação nominal continuou no conteúdo e o pacote estaria inventando um encarregado' );
	}

	medir( $nome );

	if ( contem( $sem_encarregado, $C::MARCA_ABRE ) ) {
		anotar( $nome, 'interpolação: sobrou marcador não resolvido no conteúdo produzido com o encarregado vazio' );
	}

	/* Ponta a ponta: o arquivo do pacote, interpolado, satisfaz a leitura de volta. */
	medir( $nome );

	$ponta_a_ponta = $C::veredito_do_controlador( $completo, $C::interpolar_com( $bruto, $completo ) );

	if ( 'OK' !== $ponta_a_ponta['estado'] ) {
		anotar( $nome, 'ponta a ponta: o arquivo real da política, interpolado com os três valores, não satisfaz a leitura de volta — ' . $ponta_a_ponta['estado'] . ': ' . $ponta_a_ponta['motivo'] );
	}
}

/* ---------- relatorio.nomeia_o_que_nao_fecha_ok: o defeito 1, medido ---------- */

/*
 * O defeito, dito por inteiro: o cabeçalho do log de 1.0.6 dizia "checagens do
 * relatório: 5 FALHA e 6 BLOCKED" e as linhas renderizadas mostravam UMA
 * unidade em FALHA. As outras rodavam DENTRO de unidades que fecharam OK — em
 * `etapa_preflight`, por exemplo, o veredito de cada checagem interna é
 * descartado e a unidade devolve OK a menos que a medição inteira esteja
 * bloqueada. O operador ficava com um número e nenhum nome.
 *
 * O que esta sonda prova: uma FALHA emitida DENTRO de uma unidade que fecha OK
 * sai NOMEADA — no recorte que a resposta do lote carrega para a tela, na
 * lista por estado e no resumo com contagem. E que o estado OK continua
 * resumido, que é a outra metade da regra.
 */

$nome = 'relatorio.nomeia_o_que_nao_fecha_ok';

F3Base_Imp_Relatorio::zerar();

$marca_da_unidade = F3Base_Imp_Relatorio::marcar();

F3Base_Imp_Relatorio::emitir( 'OK', 'preflight.disco', 'espaço suficiente.', array( 'evidencia' => 'medida', 'fase' => 'local' ) );
F3Base_Imp_Relatorio::emitir( 'FALHA', 'preflight.saida_https', 'a saída HTTPS não respondeu.', array( 'evidencia' => 'teste-funcional', 'fase' => 'local' ) );
F3Base_Imp_Relatorio::emitir( 'WARN', 'preflight.limites', 'memory_limit apertado.', array( 'evidencia' => 'medida', 'fase' => 'local' ) );

$internas = F3Base_Imp_Relatorio::desde( $marca_da_unidade );

/* A unidade fecha OK — e é justamente esse o caso que escondia as outras. */
F3Base_Imp_Relatorio::emitir_unidade( 'OK', 'preflight', 'preflight completo.', array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' ) );

medir( $nome );

if ( 3 !== count( $internas ) ) {
	anotar( $nome, 'teto: o recorte da unidade devolveu ' . count( $internas ) . ' checagem(ns) internas, e não as 3 emitidas' );
}

$nomeadas = array();

foreach ( $internas as $interna ) {
	if ( 'OK' !== $interna['estado'] ) {
		$nomeadas[] = (string) $interna['nome'];
	}
}

medir( $nome );

if ( array( 'preflight.saida_https', 'preflight.limites' ) !== $nomeadas ) {
	anotar( $nome, 'teto: o que não fechou OK dentro da unidade precisa sair nomeado e saiu: ' . implode( ', ', $nomeadas ) );
}

$nomes_checagens = F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' );
$nomes_unidades  = F3Base_Imp_Relatorio::nomes_por_estado( 'unidades' );

medir( $nome );

if ( array( 'preflight.saida_https' ) !== $nomes_checagens['FALHA'] ) {
	anotar( $nome, 'piso: a lista de FALHA do escopo checagens não nomeia a checagem interna: ' . implode( ', ', $nomes_checagens['FALHA'] ) );
}

medir( $nome );

if ( array( 'preflight.limites' ) !== $nomes_checagens['WARN'] ) {
	anotar( $nome, 'piso: a lista de WARN do escopo checagens não nomeia a checagem interna' );
}

medir( $nome );

if ( array( 'preflight' ) !== $nomes_unidades['OK'] || array() !== $nomes_unidades['FALHA'] ) {
	anotar( $nome, 'piso: os dois escopos se misturaram — a unidade fechou OK e o escopo de unidades precisa dizer só isso' );
}

$resumo = F3Base_Imp_Relatorio::resumo_por_estado( F3Base_Imp_Relatorio::contagem(), $nomes_checagens );

medir( $nome );

if ( ! str_contains( $resumo, 'preflight.saida_https' ) || ! str_contains( $resumo, 'preflight.limites' ) ) {
	anotar( $nome, 'piso: o resumo por estado conta e NÃO nomeia — é o defeito de volta' );
}

medir( $nome );

if ( str_contains( $resumo, 'preflight.disco' ) ) {
	anotar( $nome, 'teto: checagem OK saiu nomeada no resumo; a regra é que OK fica resumido' );
}

medir( $nome );

if ( ! str_contains( $resumo, 'OK: 2' ) ) {
	anotar( $nome, 'teto: o resumo perdeu a contagem de OK — a lista de nomes não substitui o número, ela acompanha' );
}

F3Base_Imp_Relatorio::zerar();

/* ---------- entrega.rodada_limpa_confere: teto e piso dos DOIS lados ---------- */

/*
 * A rodada limpa é fato da SUÍTE EXTERNA e não roda no host. Antes desta
 * release ela era tratada como entregável em BLOCKED, e como o host nunca pode
 * produzi-la, ela proibia a autodesativação PARA SEMPRE, em toda instalação,
 * por desenho. A separação é a correção; o que esta sonda prova é que o novo
 * caminho de fechamento existe de verdade, nos dois ramos:
 *
 * - registro com o hash CERTO precisa fechar OK, com classe `importada` e fase
 *   `build` — jamais "medida", jamais fase "producao";
 * - registro com hash DIVERGENTE precisa ser acusado NOMEANDO os dois hashes;
 * - registro AUSENTE precisa ser acusado, e nenhum dos dois pode segurar a
 *   autodesativação.
 */

$nome = 'entrega.rodada_limpa_confere';

$hash_certo    = str_repeat( 'a', 64 );
$hash_alheio   = str_repeat( 'b', 64 );

/*
 * O REGISTRO DECLARA O VEREDITO desde a 1.0.18, e o leitor o LÊ além do hash.
 * Sem esse campo, o conteúdo abaixo é o da 1.0.17: hash batendo e nada mais,
 * que era o pacote se aprovando pelo arquivo que ele mesmo escreveu.
 */
$registro_limpo = array(
	'veredito'           => 'sem-falha-e-sem-pendencia',
	'falhas'             => 0,
	'pendencias_de_fase' => array(),
);

$registro_com_pendencia = array(
	'veredito'           => 'sem-falha-com-pendencia-de-fase',
	'falhas'             => 0,
	'pendencias_de_fase' => array( 'mcp.canal_configurado', 'orcamento.pagina' ),
);

/* Ramo 1: registro presente e casado. */
medir( $nome );
$veredito = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_certo, $hash_certo, $registro_limpo );

if ( 'OK' !== $veredito['estado'] ) {
	anotar( $nome, 'teto: hash igual não fechou OK, e sim ' . $veredito['estado'] );
}

medir( $nome );

if ( 'importada' !== $veredito['evidencia'] ) {
	anotar( $nome, 'teto: o ramo OK precisa sair com classe de evidência "importada" e saiu com "' . $veredito['evidencia'] . '"' );
}

medir( $nome );

if ( 'build' !== $veredito['fase'] ) {
	anotar( $nome, 'teto: o ramo OK precisa sair na fase "build" e saiu na fase "' . $veredito['fase'] . '"' );
}

medir( $nome );

if ( ! str_contains( $veredito['motivo'], $hash_certo ) ) {
	anotar( $nome, 'teto: o ramo OK não nomeia o hash conferido' );
}

/* Ramo 2: registro presente e divergente — o piso. */
medir( $nome );
$divergente = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_alheio, $hash_certo, $registro_limpo );

if ( 'BLOCKED' !== $divergente['estado'] ) {
	anotar( $nome, 'piso: hash divergente não foi acusado; fechou ' . $divergente['estado'] );
}

medir( $nome );

if ( ! str_contains( $divergente['motivo'], $hash_alheio ) || ! str_contains( $divergente['motivo'], $hash_certo ) ) {
	anotar( $nome, 'piso: o BLOCKED de hash divergente precisa nomear o esperado E o encontrado' );
}

medir( $nome );

if ( 'medida' === $divergente['evidencia'] || 'producao' === $divergente['fase'] ) {
	anotar( $nome, 'piso: evidência importada não pode sair como "medida" nem na fase "producao"' );
}

/* Ramo 3: registro sem o campo de hash. */
medir( $nome );
$sem_campo = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, '', $hash_certo, $registro_limpo );

if ( 'BLOCKED' !== $sem_campo['estado'] ) {
	anotar( $nome, 'piso: registro sem hash_pacote não foi acusado; fechou ' . $sem_campo['estado'] );
}

/* Ramo 4: registro ausente. */
medir( $nome );
$ausente = F3Base_Imp_Entrega::veredito_da_rodada_limpa( false, '', $hash_certo, array() );

if ( 'BLOCKED' !== $ausente['estado'] ) {
	anotar( $nome, 'piso: registro ausente não foi acusado; fechou ' . $ausente['estado'] );
}

medir( $nome );

if ( ! str_contains( $ausente['motivo'], F3Base_Imp_Entrega::REGISTRO_RODADA ) ) {
	anotar( $nome, 'piso: o BLOCKED de registro ausente não nomeia o caminho que falta' );
}

/*
 * Ramo 5 — O PISO DA 1.0.18: hash batendo NÃO basta. O registro que não declara
 * veredito é o registro da 1.0.17, e aprová-lo pelo hash era o pacote se
 * aprovando pelo arquivo que ele mesmo escreveu.
 */
medir( $nome );
$sem_veredito = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_certo, $hash_certo, array( 'hash_pacote' => $hash_certo ) );

if ( 'BLOCKED' !== $sem_veredito['estado'] ) {
	anotar( $nome, 'piso: registro com hash certo e SEM veredito declarado fechou ' . $sem_veredito['estado'] . ' — hash igual prova que a rodada mediu este pacote, e não diz o que ela achou' );
}

medir( $nome );

if ( ! contem( $sem_veredito['motivo'], 'NÃO declara veredito' ) ) {
	anotar( $nome, 'piso: a recusa do registro sem veredito não diz o que falta nele' );
}

/* Ramo 6: registro que declara FALHA não amarra entrega nenhuma. */
medir( $nome );
$com_falha = F3Base_Imp_Entrega::veredito_da_rodada_limpa(
	true,
	$hash_certo,
	$hash_certo,
	array( 'veredito' => 'com-falha', 'falhas' => 3, 'pendencias_de_fase' => array() )
);

if ( 'BLOCKED' !== $com_falha['estado'] ) {
	anotar( $nome, 'piso: registro declarando 3 FALHA fechou ' . $com_falha['estado'] );
}

medir( $nome );

if ( ! str_contains( $com_falha['motivo'], '3 checagem' ) ) {
	anotar( $nome, 'piso: a recusa do registro com FALHA não nomeia quantas' );
}

/*
 * Ramo 7 — o que a 1.0.17 escondia no NOME do arquivo: hash batendo, zero
 * FALHA e pendências dentro fecha OK, e as pendências saem NOMEADAS. O host não
 * pode afirmar mais do que a rodada mediu.
 */
$com_pendencia = F3Base_Imp_Entrega::veredito_da_rodada_limpa( true, $hash_certo, $hash_certo, $registro_com_pendencia );

medir( $nome );

if ( 'OK' !== $com_pendencia['estado'] ) {
	anotar( $nome, 'teto: rodada sem FALHA e com pendência de fase declarada fechou ' . $com_pendencia['estado'] . ' — pendência de fase não é FALHA' );
}

foreach ( array( 'mcp.canal_configurado', 'orcamento.pagina', 'NOMEADA', 'rodada limpa' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $com_pendencia['motivo'], $trecho ) ) {
		anotar( $nome, 'teto: o OK com pendências não traz "' . $trecho . '" — contar sem nomear é o que o nome do arquivo antigo escondia' );
	}
}

/* ---------- entrega.gates_separados: o gate de fase NÃO decide a autodesativação ---------- */

$nome = 'entrega.gates_separados';

$do_gate = F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao();

/*
 * A LISTA DO GATE DE FASE SAI DO METADADO desde a 1.0.18, e é por isso que este
 * bloco EMITE antes de perguntar: até a 1.0.17 havia uma lista literal com UM
 * nome do lado de cá e o metadado `gate` com DOIS emissores do lado de lá, e o
 * log imprimia as duas fontes dentro da mesma linha, discordando. Emitir aqui é
 * o que prova a derivação: o nome entra na lista porque a linha o declarou, não
 * porque alguém o escreveu numa segunda lista.
 */
F3Base_Imp_Relatorio::zerar();

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::BLOCKED,
	'entrega.rodada_limpa',
	'linha de fase da bancada',
	array( 'evidencia' => 'pendencia-externa', 'fase' => 'build', 'gate' => 'fase' )
);

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::BLOCKED,
	'orcamento.medicao_de_pagina',
	'segunda linha de fase da bancada',
	array( 'evidencia' => 'pendencia-externa', 'fase' => 'campo', 'gate' => 'fase' )
);

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::OK,
	'entrega.tema',
	'linha de aplicação da bancada',
	array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local', 'gate' => 'aplicacao' )
);

F3Base_Imp_Relatorio::emitir(
	F3Base_Imp_Relatorio::OK,
	'bancada.sem_gate_declarado',
	'linha sem gate declarado da bancada',
	array( 'evidencia' => 'analise-estatica', 'fase' => 'build' )
);

$de_fase = F3Base_Imp_Entrega::gates_de_fase();

medir( $nome );

if ( 8 !== count( $do_gate ) ) {
	anotar( $nome, 'teto: o gate de aplicação precisa listar os OITO entregáveis e lista ' . count( $do_gate ) );
}

medir( $nome );

if ( in_array( 'entrega.rodada_limpa', $do_gate, true ) ) {
	anotar( $nome, 'piso: entrega.rodada_limpa continua dentro do gate de aplicação — o gate volta a ser insatisfazível no host' );
}

medir( $nome );

if ( ! in_array( 'entrega.rodada_limpa', $de_fase, true ) ) {
	anotar( $nome, 'piso: entrega.rodada_limpa saiu do gate de aplicação e não entrou no gate de fase — evidência externa não pode simplesmente sumir' );
}

/* TETO da derivação: o SEGUNDO emissor de gate=fase entra sem que ninguém o declare. */
medir( $nome );

if ( ! in_array( 'orcamento.medicao_de_pagina', $de_fase, true ) ) {
	anotar( $nome, 'teto: o segundo emissor de gate=fase não entrou na lista derivada — era exatamente ele que a lista literal da 1.0.17 não continha, e a divergência saía impressa dentro de uma linha só do log' );
}

/* PISO da derivação: gate de aplicação e gate ausente NÃO entram na lista de fase. */
foreach ( array( 'entrega.tema', 'bancada.sem_gate_declarado' ) as $fora ) {
	medir( $nome );

	if ( in_array( $fora, $de_fase, true ) ) {
		anotar( $nome, 'piso: ' . $fora . ' entrou na lista de gates de fase sem ter declarado gate=fase — gate ausente conta como aplicação, e a ausência não pode ser o caminho barato para escapar do gate' );
	}
}

/* A nota de fase NOMEIA o escopo que resume: foi a falta disso que fez as duas frases parecerem contraditórias. */
$nota = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, array() )['motivo'];

medir( $nome );

if ( ! contem( $nota, 'derivados do metadado' ) ) {
	anotar( $nome, 'teto: a nota de fase não declara de onde a lista sai — sem o escopo nomeado, "nenhuma pendência de fase em aberto" e "pendência de FASE dentro desta unidade" continuam parecendo contradição na mesma linha' );
}

/* Mapa de uma execução em que TUDO fecha, menos a evidência importada. */
$mapa_bom = array( 'entrega.rodada_limpa' => 'BLOCKED' );

foreach ( $do_gate as $entregavel ) {
	$mapa_bom[ $entregavel ] = 'OK';
}

foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
	$mapa_bom[ $gate ] = 'OK';
}

medir( $nome );
$decisao = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_bom );

if ( true !== $decisao['pode'] ) {
	anotar( $nome, 'teto: com SUCESSO_APLICACAO, entregáveis e canal em OK, a rodada limpa em BLOCKED continuou proibindo a autodesativação — o gate segue insatisfazível' );
}

medir( $nome );

if ( ! str_contains( $decisao['motivo'], 'entrega.rodada_limpa' ) ) {
	anotar( $nome, 'teto: a pendência de fase precisa aparecer NOMEADA no motivo, e não aparece — ignorar a evidência externa é a outra metade do erro' );
}

/* PISO do caminho de falha: com entregável ausente, o implantador permanece ativo. */
medir( $nome );
$mapa_ruim = $mapa_bom;
$mapa_ruim[ $do_gate[0] ] = 'BLOCKED';
$decisao_ruim = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_ruim );

if ( false !== $decisao_ruim['pode'] ) {
	anotar( $nome, 'piso: entregável do gate de aplicação em BLOCKED deixou de impedir a autodesativação' );
}

medir( $nome );

if ( ! str_contains( $decisao_ruim['motivo'], $do_gate[0] ) ) {
	anotar( $nome, 'piso: o motivo da recusa não nomeia o entregável em BLOCKED' );
}

/* PISO do caminho de falha: sem SUCESSO_APLICACAO, o implantador permanece ativo. */
medir( $nome );
$decisao_falha = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::FALHA_PARCIAL, $mapa_bom );

if ( false !== $decisao_falha['pode'] ) {
	anotar( $nome, 'piso: FALHA_PARCIAL deixou de impedir a autodesativação' );
}

/* PISO do caminho de falha: canal em aberto mantém o implantador ativo. */
medir( $nome );
$mapa_canal = $mapa_bom;
$mapa_canal['mcp.canal_exposto'] = 'BLOCKED';
$decisao_canal = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_canal );

if ( false !== $decisao_canal['pode'] ) {
	anotar( $nome, 'piso: canal não exposto deixou de impedir a autodesativação' );
}

medir( $nome );

if ( ! str_contains( $decisao_canal['motivo'], 'mcp.canal_exposto' ) ) {
	anotar( $nome, 'piso: a recusa por canal em aberto não nomeia o veredito que ficou fora de OK' );
}

/*
 * PISO do caminho de falha, continuação da 1.0.8: com A, B, C e D corrigidos, a
 * execução seguinte fecha sem FALHA e a autodesativação passa a acontecer. É
 * exatamente aí que o caminho de falha precisa continuar provado — senão a
 * correção que destrava o gate é a mesma que o desliga.
 */

/* FALHA de verdade no estado da aplicação: o implantador permanece ativo. */
medir( $nome );
$decisao_estado_falha = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::FALHA, $mapa_bom );

if ( false !== $decisao_estado_falha['pode'] ) {
	anotar( $nome, 'piso: o estado FALHA deixou de impedir a autodesativação' );
}

medir( $nome );

if ( ! str_contains( $decisao_estado_falha['motivo'], F3Base_Imp_Lotes::FALHA ) ) {
	anotar( $nome, 'piso: a recusa por estado FALHA não nomeia o estado observado' );
}

/* Canal CONFIGURADO em aberto: o outro veredito de canal também segura. */
medir( $nome );
$mapa_configurado = $mapa_bom;
$mapa_configurado['mcp.canal_configurado'] = 'BLOCKED';
$decisao_configurado = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_configurado );

if ( false !== $decisao_configurado['pode'] ) {
	anotar( $nome, 'piso: canal não configurado deixou de impedir a autodesativação' );
}

/* Cada entregável do gate, um a um: nenhum deles pode ter deixado de segurar. */
foreach ( $do_gate as $entregavel ) {
	medir( $nome );

	$mapa_um             = $mapa_bom;
	$mapa_um[ $entregavel ] = 'BLOCKED';
	$decisao_um          = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_um );

	if ( false !== $decisao_um['pode'] || ! str_contains( $decisao_um['motivo'], $entregavel ) ) {
		anotar( $nome, 'piso: o entregável ' . $entregavel . ' em BLOCKED não impediu a autodesativação, ou não foi nomeado na recusa' );
	}
}

/*
 * O ESTADO DA UNIDADE NÃO DECIDE O GATE, e desde a 1.0.9 isso precisa estar
 * provado: a unidade `entrega` passou a REFLETIR as checagens que emite, e uma
 * delas — `orcamento.medicao_de_pagina`, evidência de navegador que este host
 * não produz — é BLOCKED por declaração, em toda instalação. Se a linha da
 * unidade entrasse no gate, a autodesativação viraria impossível por desenho,
 * que é exatamente o defeito que a separação dos dois gates desfez.
 */
medir( $nome );
$mapa_com_unidade = $mapa_bom;
$mapa_com_unidade['entrega'] = 'BLOCKED';
$mapa_com_unidade['preflight'] = 'BLOCKED';
$decisao_com_unidade = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_com_unidade );

if ( true !== $decisao_com_unidade['pode'] ) {
	anotar( $nome, 'teto: a linha de uma UNIDADE em BLOCKED passou a proibir a autodesativação — o gate lê nomes de entregável declarados, e unidade não é entregável' );
}

/* TETO, de novo e por último: nada disso pode ter tornado o gate insatisfazível. */
medir( $nome );
$decisao_teto = F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_bom );

if ( true !== $decisao_teto['pode'] ) {
	anotar( $nome, 'teto: com tudo do gate em OK a autodesativação deixou de ser autorizada — um gate que não fecha nunca é tão inútil quanto um que fecha sempre' );
}

/* ---------- preflight.artefato_do_pacote_e_baseline: o defeito A, medido ---------- */

/*
 * O defeito, dito por inteiro: `preflight.baseline` reprovou em produção
 * nomeando "dreamhost-panel-login 1.0.0, f3base-site-core 1.0.0". O primeiro é
 * achado legítimo — plugin da hospedagem, ativo e não declarado. O segundo é o
 * plugin persistente que ESTE pacote instala e ativa: o instrumento reprovando
 * o próprio produto, e oferecendo como saída que o pacote se declarasse plugin
 * de terceiro.
 *
 * O que esta sonda prova, nos dois lados: com os artefatos do pacote ativos e
 * nada mais, a classificação não produz divergência nenhuma; com um plugin de
 * terceiro ativo e não declarado, ela produz a divergência NOMEADA. E que os
 * slugs saem da CONFIGURAÇÃO — trocar o slug declarado muda o que a baseline
 * reconhece como nosso, que é a propriedade que uma lista literal não teria.
 */

$nome = 'preflight.artefato_do_pacote_e_baseline';

$artefatos = F3Base_Imp_Preflight::artefatos_do_pacote();
$do_pacote = F3Base_Imp_Preflight::plugins_do_pacote( $artefatos );

$slug_site_core = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );
$slug_tema      = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );

medir( $nome );

if ( ! isset( $do_pacote[ $slug_site_core ] ) ) {
	anotar( $nome, 'teto: o site-core declarado em site.site_core_slug (' . $slug_site_core . ') não foi reconhecido como artefato do pacote' );
}

/*
 * O SLUG DO IMPLANTADOR É DERIVADO, nunca escrito por extenso. Com o literal
 * `implantador-base` aqui, a asserção media o NOME DO DIRETÓRIO em que a suíte
 * está rodando, e não o que o preflight resolve: bastava verificar uma cópia
 * do pacote a partir de outra pasta — que é exatamente o que a criação de um
 * site novo faz — para a checagem reprovar sem nenhum defeito no pacote. A
 * derivação é a MESMA de artefatos_do_pacote(): plugin_basename() do arquivo
 * principal em execução.
 */
$slug_implantador = dirname( plugin_basename( F3BASE_IMP_ARQUIVO ) );

medir( $nome );

if ( ! isset( $do_pacote[ $slug_implantador ] ) ) {
	anotar( $nome, 'teto: o próprio implantador (' . $slug_implantador . ') não foi reconhecido como artefato do pacote' );
}

medir( $nome );

$tem_tema = false;

foreach ( $artefatos as $artefato ) {
	if ( 'tema' === $artefato['tipo'] && $slug_tema === $artefato['slug'] ) {
		$tem_tema = true;
	}
}

if ( ! $tem_tema ) {
	anotar( $nome, 'teto: o tema declarado em site.tema_slug (' . $slug_tema . ') não consta dos artefatos do pacote' );
}

medir( $nome );

if ( isset( $do_pacote[ $slug_tema ] ) ) {
	anotar( $nome, 'piso: o slug do TEMA entrou na absolvição de PLUGINS — um plugin de terceiro com esse nome de diretório seria absolvido sem estar declarado' );
}

/* TETO: só o que é do pacote, ativo. A checagem precisa ficar em silêncio. */
$so_nosso = array(
	'f3base-site-core/f3base-site-core.php'                 => array( 'slug' => $slug_site_core, 'nome' => 'F3 Base Site Core', 'versao' => '1.0.0', 'ativo' => true ),
	$slug_implantador . '/' . basename( F3BASE_IMP_ARQUIVO ) => array( 'slug' => $slug_implantador, 'nome' => 'Implantador Base F3', 'versao' => '1.0.10', 'ativo' => true ),
);

medir( $nome );

$classificado = F3Base_Imp_Preflight::classificar_plugins( $so_nosso, $do_pacote, array(), array(), array() );
$divergentes  = array_values( array_filter( $classificado, static fn ( array $i ): bool => 'divergencia-a-classificar' === $i['classe'] && $i['ativo'] ) );

if ( array() !== $divergentes ) {
	anotar( $nome, 'piso do silêncio: com o site-core e o implantador ativos e nada mais, a baseline acusou ' . count( $divergentes ) . ' divergência(s) — o instrumento reprovando o próprio produto' );
}

medir( $nome );

if ( 'artefato-do-pacote' !== $classificado['f3base-site-core/f3base-site-core.php']['classe'] ) {
	anotar( $nome, 'piso do silêncio: o site-core saiu classificado como ' . $classificado['f3base-site-core/f3base-site-core.php']['classe'] );
}

/* PISO: plugin de terceiro, ativo e não declarado. Precisa ser acusado, nomeado. */
$com_terceiro = array_merge(
	$so_nosso,
	array(
		'dreamhost-panel-login/dreamhost-panel-login.php' => array( 'slug' => 'dreamhost-panel-login', 'nome' => 'DreamHost Panel Login', 'versao' => '1.0.0', 'ativo' => true ),
	)
);

medir( $nome );

$classificado = F3Base_Imp_Preflight::classificar_plugins( $com_terceiro, $do_pacote, array(), array(), array() );
$divergentes  = array_values( array_filter( $classificado, static fn ( array $i ): bool => 'divergencia-a-classificar' === $i['classe'] && $i['ativo'] ) );

if ( 1 !== count( $divergentes ) || 'dreamhost-panel-login' !== $divergentes[0]['slug'] ) {
	anotar( $nome, 'piso da acusação: plugin de terceiro ativo e não declarado não foi acusado nomeando — divergências: ' . count( $divergentes ) );
}

/* E declarado em plugins.operacionais, o mesmo plugin sai da acusação, com finalidade e responsável. */
$operacionais = array();

foreach ( F3Base_Imp_Config::lista( 'plugins.operacionais' ) as $indice => $entrada ) {
	unset( $entrada );

	$slug_operacional = (string) F3Base_Imp_Config::obter( 'plugins.operacionais.' . $indice . '.slug', '' );

	if ( '' !== $slug_operacional ) {
		$operacionais[ $slug_operacional ] = array(
			'finalidade'  => (string) F3Base_Imp_Config::obter( 'plugins.operacionais.' . $indice . '.finalidade', '' ),
			'responsavel' => (string) F3Base_Imp_Config::obter( 'plugins.operacionais.' . $indice . '.responsavel', '' ),
		);
	}
}

medir( $nome );

if ( ! isset( $operacionais['dreamhost-panel-login'] ) ) {
	anotar( $nome, 'teto: o achado legítimo da 1.0.7 não foi declarado em plugins.operacionais no site.json' );
}

medir( $nome );

$classificado = F3Base_Imp_Preflight::classificar_plugins( $com_terceiro, $do_pacote, array(), array(), $operacionais );

if ( 'externo-preservado' !== $classificado['dreamhost-panel-login/dreamhost-panel-login.php']['classe'] ) {
	anotar( $nome, 'teto: declarado em plugins.operacionais, o plugin da hospedagem continuou como divergência' );
}

medir( $nome );

if ( ! str_contains( $classificado['dreamhost-panel-login/dreamhost-panel-login.php']['justificativa'], 'DreamHost' ) ) {
	anotar( $nome, 'teto: a classificação do externo preservado não carrega a finalidade e o responsável declarados' );
}

/* PISO da fonte: o slug vem da configuração, não de lista literal no código. */
medir( $nome );

$outro_pacote = array( 'outro-site-core' => 'plugin persistente (site.site_core_slug)' );
$classificado = F3Base_Imp_Preflight::classificar_plugins( $so_nosso, $outro_pacote, array(), array(), array() );

if ( 'divergencia-a-classificar' !== $classificado['f3base-site-core/f3base-site-core.php']['classe'] ) {
	anotar( $nome, 'piso da fonte: com outro slug declarado, f3base-site-core continuou absolvido — sinal de lista literal decidindo no lugar da configuração' );
}

/* ---------- tema.override_por_conteudo: o defeito B, medido ---------- */

/*
 * O defeito: a checagem reprovou nomeando `wp_global_styles:wp-global-styles-f3base
 * (#24, 52 bytes)`. O WordPress cria esse post SOZINHO ao ativar um tema de
 * blocos, e 52 bytes é o stub vazio. Medindo EXISTÊNCIA, a checagem dispararia
 * em toda instalação de tema de blocos, para sempre.
 *
 * Os dois lados, provados aqui: `wp_global_styles` com `styles` preenchido é
 * acusado; o stub vazio fica em silêncio. E o post vazio e o idêntico ao arquivo
 * do tema também ficam — com motivo, porque some-los do relatório seria a outra
 * metade do erro.
 */

$nome = 'tema.override_por_conteudo';

$stub  = '{"version":3,"isGlobalStylesUserThemeJSON":true}';
$vazio = '{"version":3,"isGlobalStylesUserThemeJSON":true,"settings":{},"styles":{}}';
$real_ = '{"version":3,"isGlobalStylesUserThemeJSON":true,"styles":{"color":{"background":"#101010"}}}';

$casos = array(
	array( 'wp_global_styles', $stub, '', false, 'stub vazio', 'stub' ),
	array( 'wp_global_styles', $vazio, '', false, 'settings e styles presentes e VAZIOS', 'nenhuma chave tem conteúdo' ),
	array( 'wp_global_styles', $real_, '', true, 'styles preenchido', 'styles' ),
	array( 'wp_global_styles', '{"version":3,"settings":{"color":{"palette":[]}}}', '', true, 'settings preenchido', 'settings' ),
	array( 'wp_global_styles', '', '', false, 'post_content vazio', 'VAZIO' ),
	array( 'wp_global_styles', '   ', '', false, 'só espaço em branco', 'VAZIO' ),
	array( 'wp_global_styles', '{isso não é json', '', true, 'JSON que não decodifica', 'não decodifica' ),
	array( 'wp_template', '', '<!-- wp:group --><!-- /wp:group -->', false, 'template vazio no banco', 'VAZIO' ),
	array( 'wp_template', "<!-- wp:group --><!-- /wp:group -->\n", '<!-- wp:group --><!-- /wp:group -->', false, 'template idêntico ao arquivo do tema', 'IDÊNTICO' ),
	array( 'wp_template', '<!-- wp:paragraph --><p>outro</p><!-- /wp:paragraph -->', '<!-- wp:group --><!-- /wp:group -->', true, 'template diferente do arquivo do tema', 'DIFERE' ),
	array( 'wp_template_part', '<!-- wp:site-title /-->', '<!-- wp:site-title /-->', false, 'part idêntica ao arquivo do tema', 'IDÊNTICO' ),
	array( 'wp_template_part', '<!-- wp:site-title /-->', '', true, 'part sem arquivo do tema correspondente', 'não há arquivo do tema' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Preflight::veredito_de_override( $caso[0], $caso[1], $caso[2] );

	if ( $veredito['override'] !== $caso[3] ) {
		anotar( $nome, $caso[4] . ': esperado override=' . ( $caso[3] ? 'sim' : 'não' ) . ', obtido ' . ( $veredito['override'] ? 'sim' : 'não' ) );
		continue;
	}

	medir( $nome );

	if ( ! str_contains( $veredito['motivo'], $caso[5] ) ) {
		anotar( $nome, $caso[4] . ': o motivo não diz "' . $caso[5] . '" — ' . $veredito['motivo'] );
	}
}

/*
 * O TAMANHO NÃO DECIDE NADA, e é preciso que não decida: o log de produção
 * trazia "52 bytes" e o núcleo grava o stub em mais de uma grafia — compacta e
 * com espaços —, cada uma com um número diferente. Uma regra por tamanho
 * absolveria pelo motivo errado e reprovaria na próxima versão do WordPress.
 *
 * A prova: as duas grafias do stub ficam em silêncio, e uma personalização MAIS
 * CURTA que qualquer uma delas continua sendo acusada.
 */
$stub_do_nucleo = '{"isGlobalStylesUserThemeJSON":true, "version": 3 }';
$curto_e_real   = '{"styles":{"color":{"text":"#111"}}}';

medir( $nome );

if ( F3Base_Imp_Preflight::veredito_de_override( 'wp_global_styles', $stub_do_nucleo, '' )['override'] ) {
	anotar( $nome, 'a grafia do stub que o núcleo grava (com espaços, ' . strlen( $stub_do_nucleo ) . ' bytes) foi acusada' );
}

medir( $nome );

if ( ! F3Base_Imp_Preflight::veredito_de_override( 'wp_global_styles', $curto_e_real, '' )['override'] ) {
	anotar( $nome, 'personalização de ' . strlen( $curto_e_real ) . ' bytes, MENOR que o stub, não foi acusada: o tamanho voltou a decidir no lugar do conteúdo' );
}

medir( $nome );

if ( strlen( $curto_e_real ) >= strlen( $stub_do_nucleo ) ) {
	anotar( $nome, 'a amostra de personalização deixou de ser menor que o stub, e com isso a sonda parou de provar que o tamanho não decide' );
}

/* ---------- mcp.canal_unico_mede_plugins_ativos: o defeito A, medido ---------- */

/*
 * O DEFEITO DA 1.0.8, verbatim do log de produção:
 *
 *   FALHA entrega ↳ mcp.canal_unico — "as 9 rota(s) de arquivo que a unidade
 *   mediu não têm registrador único: Abilities files/list, Abilities
 *   files/read, … Dois diretórios de backup e DUAS chaves de desligamento — o
 *   operador fecha o canal em um e ele segue aberto pelo outro."
 *
 * Nove rotas, UMA fonte cada, nenhum segundo plugin nomeado: a evidência
 * impressa na própria linha desmente a frase. A causa é que a Abilities API não
 * devolve o plugin que registrou cada habilidade, e o código tratava "não
 * consegui atribuir" como "há mais de um".
 *
 * O que esta sonda prova, nos dois lados:
 *
 * - um complemento ativo → OK nomeando-o, e a FRASE DA CONSEQUÊNCIA não aparece
 *   (é este o piso que tranca o defeito: consequência sem achado é o
 *   diagnóstico afirmando causa que os dados contradizem);
 * - o declarado mais uma cópia com OUTRO slug e o MESMO `Plugin Name` → FALHA
 *   nomeando os dois diretórios e os dois arquivos principais, e aí sim com a
 *   frase da consequência ao lado dos nomes reais;
 * - nenhum complemento ativo → BLOCKED;
 * - censo indisponível (fonte incapaz de atribuir) → BLOCKED com a frase da
 *   Abilities API;
 * - unidade que não rodou → BLOCKED nomeando a option.
 *
 * E prova a medição por baixo do veredito: `complementos_de_canal()` conta
 * PLUGINS ATIVOS, ignora inativo e oculto, e enxerga a cópia pelo Plugin Name.
 */

$nome = 'mcp.canal_unico_mede_plugins_ativos';

$consequencia = 'chaves de desligamento';

$declarado = 'wp-mcp-ultimate-complemento-fator3';
$plugin_name = 'WP MCP Ultimate — Complemento Fator 3';

/*
 * Censo com o complemento declarado ativo, um plugin qualquer ativo, um
 * inativo com o MESMO Plugin Name (não conta: o WordPress não o carrega) e um
 * backup oculto (que `get_plugins()` nem lista, aqui representado como inativo).
 */
$censo_um = array(
	'wp-mcp-ultimate/wp-mcp-ultimate.php' => array( 'slug' => 'wp-mcp-ultimate', 'nome' => 'WP MCP Ultimate', 'ativo' => true ),
	$declarado . '/' . $declarado . '.php' => array( 'slug' => $declarado, 'nome' => $plugin_name, 'ativo' => true ),
	'flamingo/flamingo.php' => array( 'slug' => 'flamingo', 'nome' => 'Flamingo', 'ativo' => true ),
	'copia-inativa/copia-inativa.php' => array( 'slug' => 'copia-inativa', 'nome' => $plugin_name, 'ativo' => false ),
);

$censo_dois = $censo_um + array(
	'canal-mcp-copia/canal-mcp-copia.php' => array( 'slug' => 'canal-mcp-copia', 'nome' => $plugin_name, 'ativo' => true ),
);

$censo_nenhum = array(
	'wp-mcp-ultimate/wp-mcp-ultimate.php' => array( 'slug' => 'wp-mcp-ultimate', 'nome' => 'WP MCP Ultimate', 'ativo' => true ),
	'copia-inativa/copia-inativa.php' => array( 'slug' => 'copia-inativa', 'nome' => $plugin_name, 'ativo' => false ),
);

/* A MEDIÇÃO: um ativo, e o inativo com o mesmo nome fica de fora. */
medir( $nome );

$um = F3Base_Imp_Entrega::complementos_de_canal( $censo_um, $declarado, $plugin_name );

if ( 1 !== count( $um ) || $declarado !== $um[0]['slug'] ) {
	anotar( $nome, 'medição: com um complemento ativo e uma cópia INATIVA de mesmo Plugin Name, a contagem devolveu ' . count( $um ) . ' — diretório que o WordPress não carrega não é canal aberto' );
}

medir( $nome );

$dois = F3Base_Imp_Entrega::complementos_de_canal( $censo_dois, $declarado, $plugin_name );

if ( 2 !== count( $dois ) ) {
	anotar( $nome, 'medição: a cópia ATIVA com outro slug e o mesmo Plugin Name não foi contada — é assim que a segunda cópia aparece, e é ela que abre o segundo canal' );
}

medir( $nome );

if ( array() !== F3Base_Imp_Entrega::complementos_de_canal( $censo_nenhum, $declarado, $plugin_name ) ) {
	anotar( $nome, 'medição: sem complemento ativo, a contagem devolveu alguma coisa' );
}

/* PISO DA FONTE: o slug vem da CONFIGURAÇÃO, não de lista literal no código. */
medir( $nome );

if ( array() !== F3Base_Imp_Entrega::complementos_de_canal( $censo_um, 'outro-slug-declarado', '' ) ) {
	anotar( $nome, 'piso da fonte: com outro slug declarado e nenhum Plugin Name, o complemento continuou sendo reconhecido — sinal de lista literal decidindo no lugar da configuração' );
}

/* Os fatos, como a unidade `mcp` os grava. */
$fatos_um = array(
	'rotas_de_arquivo'    => array( 'files/list', 'files/read', 'files/write' ),
	'fontes_de_arquivo'   => array( 'Abilities files/list', 'Abilities files/read', 'Abilities files/write' ),
	'censo_de_plugins'    => true,
	'complementos_ativos' => $um,
	'nome_complemento'    => $plugin_name,
	'slug_complemento'    => $declarado,
);

$fatos_dois = array(
	'rotas_de_arquivo'    => array( 'files/list' ),
	'fontes_de_arquivo'   => array( 'Abilities files/list' ),
	'censo_de_plugins'    => true,
	'complementos_ativos' => $dois,
	'nome_complemento'    => $plugin_name,
	'slug_complemento'    => $declarado,
);

$fatos_nenhum = array(
	'rotas_de_arquivo'    => array(),
	'fontes_de_arquivo'   => array(),
	'censo_de_plugins'    => true,
	'complementos_ativos' => array(),
	'nome_complemento'    => '',
	'slug_complemento'    => $declarado,
);

$fatos_sem_censo = array(
	'rotas_de_arquivo'    => array( 'files/list', 'files/read' ),
	'fontes_de_arquivo'   => array( 'Abilities files/list', 'Abilities files/read' ),
	'censo_de_plugins'    => false,
	'complementos_ativos' => array(),
	'nome_complemento'    => '',
	'slug_complemento'    => $declarado,
);

$casos = array(
	array( false, array(), 'BLOCKED', F3Base_Imp_Entrega::OPTION_MEDICOES, 'unidade que não rodou é pré-condição ausente, e o BLOCKED nomeia a option' ),
	array( true, $fatos_sem_censo, 'BLOCKED', 'Abilities API não devolve o plugin', 'fonte incapaz de atribuir fecha BLOCKED com a frase da Abilities API' ),
	array( true, $fatos_nenhum, 'BLOCKED', 'canal-mcp-complemento', 'nenhum complemento ativo é BLOCKED nomeando o papel declarado' ),
	array( true, $fatos_um, 'OK', $declarado, 'um complemento ativo fecha OK nomeando-o' ),
	array( true, $fatos_dois, 'FALHA', 'canal-mcp-copia', 'dois complementos ativos é FALHA nomeando o segundo diretório' ),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Entrega::veredito_do_canal_unico( $caso[0], $caso[1] );

	if ( $veredito['estado'] !== $caso[2] ) {
		anotar( $nome, $caso[4] . ': esperado ' . $caso[2] . ', obtido ' . $veredito['estado'] );
		continue;
	}

	medir( $nome );

	if ( ! str_contains( $veredito['motivo'], $caso[3] ) ) {
		anotar( $nome, $caso[4] . ': o motivo do ramo ' . $caso[2] . ' não menciona "' . $caso[3] . '"' );
	}
}

/*
 * PISO DA CONSEQUÊNCIA DECORADA. É esta a linha que a 1.0.8 imprimiu sem ter
 * medido nada que a sustentasse, e é ela que a sonda tranca: com UM complemento
 * ativo, a frase sobre dois diretórios de backup e duas chaves de desligamento
 * NÃO pode aparecer.
 */
medir( $nome );

$veredito_um = F3Base_Imp_Entrega::veredito_do_canal_unico( true, $fatos_um );

if ( str_contains( $veredito_um['motivo'], $consequencia ) ) {
	anotar( $nome, 'piso: com um único complemento ativo, a mensagem trouxe a frase da consequência ("' . $consequencia . '") — consequência sem achado é o diagnóstico afirmando causa que os dados contradizem' );
}

medir( $nome );

if ( str_contains( $veredito_um['motivo'], 'não têm registrador único' ) ) {
	anotar( $nome, 'piso: o ramo de um só voltou a falar em "registrador único", que é a atribuição que nenhuma das fontes sabe fazer' );
}

/* TETO: no ramo de dois, a consequência é verdadeira e PRECISA sair. */
medir( $nome );

$veredito_dois = F3Base_Imp_Entrega::veredito_do_canal_unico( true, $fatos_dois );

if ( ! str_contains( $veredito_dois['motivo'], $consequencia ) ) {
	anotar( $nome, 'teto: com dois complementos ativos, a frase da consequência sumiu — ela é verdadeira aqui e é o que torna o achado acionável' );
}

/* E o achado precisa NOMEAR os dois diretórios E os dois arquivos principais. */
foreach ( array( $declarado, 'canal-mcp-copia', $declarado . '/' . $declarado . '.php', 'canal-mcp-copia/canal-mcp-copia.php' ) as $exigido ) {
	medir( $nome );

	if ( ! str_contains( $veredito_dois['motivo'], $exigido ) ) {
		anotar( $nome, 'teto: a FALHA de canal duplicado não nomeia "' . $exigido . '" — sem diretório e arquivo principal o operador não tem o que abrir' );
	}
}

/*
 * PISO DA IMPOSSIBILIDADE DE MEDIR: sem censo, o estado NUNCA pode ser FALHA.
 * Era exatamente isso que a 1.0.8 fazia — tratar "não consegui atribuir" como
 * "há mais de um".
 */
medir( $nome );

$veredito_sem_censo = F3Base_Imp_Entrega::veredito_do_canal_unico( true, $fatos_sem_censo );

if ( 'FALHA' === $veredito_sem_censo['estado'] ) {
	anotar( $nome, 'piso: sem censo de plugins o veredito voltou a ser FALHA — impossibilidade de medir é BLOCKED, nunca veredito' );
}

medir( $nome );

if ( str_contains( $veredito_sem_censo['motivo'], $consequencia ) ) {
	anotar( $nome, 'piso: o BLOCKED por fonte incapaz de atribuir trouxe a frase da consequência junto' );
}

/* ---------- lotes.unidade_reflete_internas: o defeito B, medido ---------- */

/*
 * O DEFEITO: na mesma execução de 1.0.8, a linha 48 era `OK entrega — "todos os
 * entregáveis do gate de aplicação fecharam sem BLOCKED"` e a linha 49, DENTRO
 * dela, era `FALHA ↳ mcp.canal_unico`. Uma unidade não pode fechar OK contendo
 * uma checagem em FALHA: quem lê o resumo por unidade vê verde onde há
 * vermelho, e foi essa mesma discrepância que escondeu as FALHAs até a 1.0.7.
 *
 * E OS DOIS DEFEITOS QUE A CORREÇÃO PODIA CRIAR, os dois trancados aqui:
 *
 * - promover por N/A. A 1.0.9 pôs N/A acima de OK e uma unidade que INSTALOU e
 *   ATIVOU um plugin passou a fechar N/A porque a supressão de onboarding não
 *   se aplicava — o relatório mentindo para baixo. Só FALHA, BLOCKED e WARN
 *   promovem.
 * - promover por evidência de FASE. `orcamento.medicao_de_pagina` é BLOCKED por
 *   natureza (medição de navegador), e uma promoção cega ao gate travaria
 *   `entrega` em BLOCKED em toda instalação, para sempre, por desenho.
 *
 * O caminho exercitado é o REAL de `processar()`: `checagens_da_unidade()`
 * recorta as internas a partir da marca e `veredito_da_unidade()` decide.
 * Nenhuma das duas é reimplementada aqui — sonda que reimplementa prova que a
 * cópia funciona.
 */

$nome = 'lotes.unidade_reflete_internas';

/**
 * Roda o caminho real: emite as internas, recorta pela marca e promove.
 *
 * @param string                          $estado_da_unidade Estado que a etapa devolveria.
 * @param array<int,array<string,string>> $emitir            Internas a emitir: estado, nome, gate.
 * @return array<string,mixed>
 */
function f3b_reflexo_real( string $estado_da_unidade, array $emitir ): array {
	F3Base_Imp_Relatorio::zerar();

	$marca = F3Base_Imp_Relatorio::marcar();

	foreach ( $emitir as $linha ) {
		F3Base_Imp_Relatorio::emitir(
			$linha['estado'],
			$linha['nome'],
			'linha da sonda.',
			array( 'evidencia' => 'medida', 'fase' => 'local', 'gate' => $linha['gate'] )
		);
	}

	$internas = F3Base_Imp_Lotes::checagens_da_unidade( $marca );
	$reflexo  = F3Base_Imp_Lotes::veredito_da_unidade( $estado_da_unidade, $internas['nomeadas'] );

	F3Base_Imp_Relatorio::zerar();

	return $reflexo + array( 'internas' => $internas );
}

$ok_aplicacao    = array( 'estado' => 'OK', 'nome' => 'entrega.readme', 'gate' => 'aplicacao' );
$na_aplicacao    = array( 'estado' => 'N/A', 'nome' => 'formulario.regime_cf7', 'gate' => 'aplicacao' );
$warn_aplicacao  = array( 'estado' => 'WARN', 'nome' => 'config.chaves_lidas_nesta_execucao', 'gate' => 'aplicacao' );
$blocked_aplic   = array( 'estado' => 'BLOCKED', 'nome' => 'entrega.suite', 'gate' => 'aplicacao' );
$falha_aplicacao = array( 'estado' => 'FALHA', 'nome' => 'mcp.canal_unico', 'gate' => 'aplicacao' );
$blocked_fase    = array( 'estado' => 'BLOCKED', 'nome' => 'orcamento.medicao_de_pagina', 'gate' => 'fase' );
$falha_fase      = array( 'estado' => 'FALHA', 'nome' => 'entrega.rodada_limpa', 'gate' => 'fase' );

/*
 * O PISO INTEIRO, em tabela: estado da unidade, internas emitidas, estado
 * esperado, e se a promoção deve ou não ter acontecido.
 */
$piso = array(
	array( 'OK', array( $ok_aplicacao ), 'OK', false, 'só OK dentro: nada promove' ),
	array( 'OK', array( $ok_aplicacao, $na_aplicacao ), 'OK', false, 'OK + N/A fecha OK — N/A é condição de aplicabilidade falsa, não "pior que OK"' ),
	array( 'OK', array( $ok_aplicacao, $warn_aplicacao ), 'WARN', true, 'OK + WARN fecha WARN' ),
	array( 'OK', array( $ok_aplicacao, $blocked_aplic ), 'BLOCKED', true, 'OK + BLOCKED de aplicação fecha BLOCKED' ),
	array( 'OK', array( $ok_aplicacao, $falha_aplicacao ), 'FALHA', true, 'OK + FALHA de aplicação fecha FALHA' ),
	array( 'OK', array( $ok_aplicacao, $blocked_fase ), 'OK', false, 'OK + BLOCKED de FASE fecha OK: evidência que o host não produz não decide' ),
	array( 'OK', array( $ok_aplicacao, $falha_fase ), 'OK', false, 'OK + FALHA de FASE fecha OK, pelo mesmo motivo' ),
	array( 'OK', array( $blocked_fase, $warn_aplicacao ), 'WARN', true, 'fase não promove e aplicação promove, na mesma unidade' ),
	array( 'WARN', array( $ok_aplicacao, $warn_aplicacao ), 'WARN', false, 'unidade que JÁ reflete não é promovida de novo' ),
	array( 'FALHA', array( $ok_aplicacao, $blocked_aplic ), 'FALHA', false, 'BLOCKED não rebaixa uma unidade que já está em FALHA' ),
	array( 'N/A', array( $ok_aplicacao ), 'N/A', false, 'unidade N/A com interna OK continua N/A: OK não promove nem rebaixa' ),
	array( 'BLOCKED', array( $falha_aplicacao ), 'FALHA', true, 'FALHA promove por cima de BLOCKED' ),
);

foreach ( $piso as $caso ) {
	medir( $nome );

	$reflexo = f3b_reflexo_real( $caso[0], $caso[1] );

	if ( $reflexo['estado'] !== $caso[2] ) {
		anotar( $nome, $caso[4] . ': esperado ' . $caso[2] . ', obtido ' . $reflexo['estado'] );
		continue;
	}

	medir( $nome );

	if ( $reflexo['promovida'] !== $caso[3] ) {
		anotar( $nome, $caso[4] . ': a marca de promoção saiu ' . var_export( $reflexo['promovida'], true ) . ' e devia ser ' . var_export( $caso[3], true ) );
	}
}

/* A promoção NOMEIA quem a causou — estado promovido sem nome é número sem nome. */
medir( $nome );

$reflexo = f3b_reflexo_real( 'OK', array( $ok_aplicacao, $blocked_fase, $falha_aplicacao ) );

if ( ! str_contains( $reflexo['nota'], 'mcp.canal_unico' ) || ! str_contains( $reflexo['nota'], 'OK' ) ) {
	anotar( $nome, 'a nota da promoção não nomeia a checagem que a causou, ou não diz de qual estado a unidade veio' );
}

medir( $nome );

if ( array( 'mcp.canal_unico' ) !== $reflexo['responsaveis'] ) {
	anotar( $nome, 'a lista de responsáveis pela promoção incluiu quem não promoveu: ' . implode( ', ', $reflexo['responsaveis'] ) );
}

/*
 * A PENDÊNCIA DE FASE SOME DO VEREDITO E NUNCA DO RELATÓRIO: ela precisa estar
 * NOMEADA no texto da unidade mesmo quando não promoveu nada.
 */
medir( $nome );

$so_fase = f3b_reflexo_real( 'OK', array( $ok_aplicacao, $blocked_fase ) );

if ( 'OK' !== $so_fase['estado'] || $so_fase['promovida'] ) {
	anotar( $nome, 'piso da fase: a evidência que este host não produz promoveu a unidade — é a unidade entrega travada em BLOCKED para sempre, por desenho' );
}

medir( $nome );

if ( ! str_contains( $so_fase['nota'], 'orcamento.medicao_de_pagina' ) || array( 'orcamento.medicao_de_pagina (BLOCKED)' ) !== $so_fase['pendencias_de_fase'] ) {
	anotar( $nome, 'piso da fase: a pendência saiu do veredito E do texto — some do veredito, nunca do relatório' );
}

/*
 * PISO DA PORTA DE ESCAPE: gate AUSENTE não pode absolver. Quem esquecer de
 * declarar o gate promove como aplicação, que é o lado seguro.
 */
medir( $nome );

$sem_gate = F3Base_Imp_Lotes::veredito_da_unidade( 'OK', array( array( 'estado' => 'FALHA', 'nome' => 'sem.gate', 'gate' => '' ) ) );

if ( 'FALHA' !== $sem_gate['estado'] ) {
	anotar( $nome, 'piso da porta de escape: interna SEM gate declarado deixou de promover — a omissão virou o caminho barato para escapar da promoção' );
}

/* A ordem inteira, e ela mora em um lugar só. */
$ordem = array(
	array( 'OK', 'FALHA', 'FALHA' ),
	array( 'OK', 'BLOCKED', 'BLOCKED' ),
	array( 'OK', 'WARN', 'WARN' ),
	array( 'OK', 'N/A', 'OK' ),
	array( 'OK', 'WAIVED', 'OK' ),
	array( 'N/A', 'OK', 'N/A' ),
	array( 'WAIVED', 'OK', 'WAIVED' ),
	array( 'BLOCKED', 'FALHA', 'FALHA' ),
	array( 'WARN', 'BLOCKED', 'BLOCKED' ),
	array( 'N/A', 'WARN', 'WARN' ),
	array( 'FALHA', 'BLOCKED', 'FALHA' ),
	array( 'BLOCKED', 'WARN', 'BLOCKED' ),
	array( 'ESTADO-INVENTADO', 'OK', 'FALHA' ),
	array( 'OK', 'ESTADO-INVENTADO', 'FALHA' ),
);

foreach ( $ordem as $par ) {
	medir( $nome );

	$obtido = F3Base_Imp_Relatorio::estado_mais_severo( $par[0], $par[1] );

	if ( $obtido !== $par[2] ) {
		anotar( $nome, 'ordem de severidade: ' . $par[0] . ' com ' . $par[1] . ' devia dar ' . $par[2] . ' e deu ' . $obtido );
	}
}

/* E os pesos: só FALHA, BLOCKED e WARN promovem; o resto empata em zero. */
$pesos = F3Base_Imp_Relatorio::ordem_de_severidade();

foreach ( array( 'OK' => 0, 'N/A' => 0, 'WAIVED' => 0 ) as $estado_neutro => $peso_esperado ) {
	medir( $nome );

	if ( ( $pesos[ $estado_neutro ] ?? -1 ) !== $peso_esperado ) {
		anotar( $nome, 'peso de ' . $estado_neutro . ': ' . var_export( $pesos[ $estado_neutro ] ?? null, true ) . ' — estado que não é reprovação, pré-condição ausente nem observação NÃO pode promover' );
	}
}

medir( $nome );

if ( ! ( ( $pesos['WARN'] ?? 0 ) < ( $pesos['BLOCKED'] ?? 0 ) && ( $pesos['BLOCKED'] ?? 0 ) < ( $pesos['FALHA'] ?? 0 ) ) ) {
	anotar( $nome, 'a ordem entre os três que promovem deixou de ser FALHA > BLOCKED > WARN' );
}

/*
 * PISO DO RECORTE: a promoção enxerga as internas pelo MESMO recorte que
 * `processar()` usa. Se `checagens_da_unidade()` parar de nomear o que não
 * fecha OK, a promoção fica cega e a unidade volta a fechar verde por cima de
 * vermelho — por isso o recorte é medido aqui, e não só a promoção.
 */
medir( $nome );

$recorte = f3b_reflexo_real( 'OK', array( $ok_aplicacao ) );

if ( array() !== $recorte['internas']['nomeadas'] || 1 !== $recorte['internas']['resumidas'] ) {
	anotar( $nome, 'piso do recorte: com só uma checagem OK dentro, o recorte devia nomear nenhuma e resumir uma, e devolveu ' . count( $recorte['internas']['nomeadas'] ) . ' nomeada(s) e ' . $recorte['internas']['resumidas'] . ' resumida(s)' );
}

medir( $nome );

$recorte = f3b_reflexo_real( 'OK', array( $ok_aplicacao, $blocked_fase ) );

if ( 1 !== count( $recorte['internas']['nomeadas'] )
	|| 'orcamento.medicao_de_pagina' !== $recorte['internas']['nomeadas'][0]['nome']
	|| 'fase' !== $recorte['internas']['nomeadas'][0]['gate'] ) {
	anotar( $nome, 'piso do recorte: a checagem que não fechou OK perdeu o nome ou o GATE no recorte que alimenta a promoção — sem o gate, a distinção não tem como existir' );
}

/* ---------- lotes.permalinks_decisao: os cinco ramos, teto e piso ---------- */

/*
 * O defeito medido na 1.0.10: o padrão `manter-existente` recusava aplicar a
 * estrutura declarada e devolvia ao operador o ajuste manual que este pacote
 * existe para eliminar. O motivo do bloqueio continuava válido onde nasceu —
 * trocar a estrutura quebra toda URL já publicada e indexada —, e as duas
 * coisas se conciliam MEDINDO: se todo publicado é gerenciado por este pacote,
 * não há URL de terceiro para quebrar.
 *
 * Os cinco ramos precisam existir e ficar provados aqui. Um ramo só é a metade
 * que mente, e um padrão que nunca aplica é a metade que devolve trabalho
 * manual.
 */

$nome = 'lotes.permalinks_decisao';

$L             = 'F3Base_Imp_Lotes';
$so_gerenciado = array(
	'em_risco'    => array(),
	'sem_caminho' => array(),
);
$com_terceiro  = array(
	'em_risco'    => array(
		array(
			'id'      => 2,
			'tipo'    => 'page',
			'slug'    => 'sample-page',
			'caminho' => '/blog/sample-page/',
		),
	),
	'sem_caminho' => array(),
);

/*
 * A instalação recém-criada, que é onde este pacote entra: "Sample Page" e
 * "Hello world!" seguem publicados e não gerenciados, e com permalinks simples
 * o endereço deles é `?p=N` — URL de QUERY, que continua resolvendo depois da
 * troca. Lista de risco vazia por um motivo DIFERENTE de "tudo é gerenciado", e
 * a mensagem não pode confundir os dois.
 */
$so_query = array(
	'em_risco'    => array(),
	'sem_caminho' => array(
		array(
			'id'      => 2,
			'tipo'    => 'page',
			'slug'    => 'sample-page',
			'caminho' => '',
		),
	),
);

$casos = array(
	array(
		'rotulo'    => 'aplicar-se-seguro com todo publicado gerenciado APLICA',
		'decisao'   => $L::PERMALINKS_SE_SEGURO,
		'observado' => '/blog/%postname%/',
		'medicao'   => $so_gerenciado,
		'acao'      => $L::ACAO_PERMALINK_APLICAR,
		'estado'    => 'OK',
		'exige'     => array( 'aplicar-se-seguro', 'nenhuma URL de terceiro está em risco', '/blog/%postname%/', '/%postname%/' ),
		'proibe'    => array( 'NÃO gerenciado(s) por este pacote tem URL de caminho em risco' ),
	),
	array(
		'rotulo'    => 'aplicar-se-seguro com UM publicado não gerenciado BLOQUEIA nomeando o objeto',
		'decisao'   => $L::PERMALINKS_SE_SEGURO,
		'observado' => '/blog/%postname%/',
		'medicao'   => $com_terceiro,
		'acao'      => $L::ACAO_PERMALINK_BLOQUEAR,
		'estado'    => 'BLOCKED',
		'exige'     => array( '#2', 'page', 'sample-page', '/blog/sample-page/', 'aplicar-declarada' ),
		'proibe'    => array( 'nenhuma URL de terceiro está em risco' ),
	),
	array(
		'rotulo'    => 'manter-existente BLOQUEIA mesmo com tudo gerenciado',
		'decisao'   => $L::PERMALINKS_MANTER,
		'observado' => '/blog/%postname%/',
		'medicao'   => $so_gerenciado,
		'acao'      => $L::ACAO_PERMALINK_BLOQUEAR,
		'estado'    => 'BLOCKED',
		'exige'     => array( 'manter-existente', 'nenhuma URL de terceiro está em risco', 'aplicar-se-seguro' ),
		'proibe'    => array(),
	),
	array(
		'rotulo'    => 'aplicar-declarada APLICA mesmo com terceiro publicado, registrando a decisão',
		'decisao'   => $L::PERMALINKS_DECLARADA,
		'observado' => '/blog/%postname%/',
		'medicao'   => $com_terceiro,
		'acao'      => $L::ACAO_PERMALINK_APLICAR,
		'estado'    => 'OK',
		'exige'     => array( 'aplicar-declarada', '#2', 'sample-page', 'risco fica REGISTRADO' ),
		'proibe'    => array( 'nenhuma URL de terceiro está em risco' ),
	),
	array(
		'rotulo'    => 'estrutura já igual à declarada: OK sem gravação, com aplicar-se-seguro',
		'decisao'   => $L::PERMALINKS_SE_SEGURO,
		'observado' => '/%postname%/',
		'medicao'   => $so_gerenciado,
		'acao'      => $L::ACAO_PERMALINK_NADA,
		'estado'    => 'OK',
		'exige'     => array( 'JÁ É a declarada', 'nada a gravar' ),
		'proibe'    => array( 'aplicar-se-seguro' ),
	),
	array(
		'rotulo'    => 'estrutura já igual à declarada: a igualdade vence a decisão manter-existente',
		'decisao'   => $L::PERMALINKS_MANTER,
		'observado' => '/%postname%/',
		'medicao'   => $so_gerenciado,
		'acao'      => $L::ACAO_PERMALINK_NADA,
		'estado'    => 'OK',
		'exige'     => array( 'JÁ É a declarada' ),
		'proibe'    => array( 'BLOCKED', 'manter-existente' ),
	),
	array(
		'rotulo'    => 'estrutura já igual à declarada: a igualdade vence a decisão aplicar-declarada, e nada é escrito',
		'decisao'   => $L::PERMALINKS_DECLARADA,
		'observado' => '/%postname%/',
		'medicao'   => $com_terceiro,
		'acao'      => $L::ACAO_PERMALINK_NADA,
		'estado'    => 'OK',
		'exige'     => array( 'nada a gravar' ),
		'proibe'    => array( 'aplicar-declarada' ),
	),
	array(
		'rotulo'    => 'aplicar-se-seguro APLICA na instalação recém-criada: publicado não gerenciado sem URL de caminho não quebra',
		'decisao'   => $L::PERMALINKS_SE_SEGURO,
		'observado' => '',
		'medicao'   => $so_query,
		'acao'      => $L::ACAO_PERMALINK_APLICAR,
		'estado'    => 'OK',
		'exige'     => array( '#2', 'sample-page', '?p=', 'Nenhuma URL de terceiro está em risco', 'vazia (permalinks simples' ),
		'proibe'    => array( 'TODO conteúdo publicado tem a meta de gestão' ),
	),
	array(
		'rotulo'    => 'valor não reconhecido não vira aplicação silenciosa nem recusa silenciosa',
		'decisao'   => 'aplicar-sempre-porque-sim',
		'observado' => '/blog/%postname%/',
		'medicao'   => $so_gerenciado,
		'acao'      => $L::ACAO_PERMALINK_BLOQUEAR,
		'estado'    => 'BLOCKED',
		'exige'     => array( 'aplicar-sempre-porque-sim', 'aplicar-se-seguro', 'aplicar-declarada', 'manter-existente' ),
		'proibe'    => array(),
	),
);

foreach ( $casos as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Lotes::decisao_de_permalinks( $caso['decisao'], $caso['observado'], '/%postname%/', $caso['medicao'] );

	if ( $veredito['acao'] !== $caso['acao'] ) {
		anotar( $nome, $caso['rotulo'] . ': ação esperada ' . $caso['acao'] . ', obtida ' . $veredito['acao'] );
		continue;
	}

	medir( $nome );

	if ( $veredito['estado'] !== $caso['estado'] ) {
		anotar( $nome, $caso['rotulo'] . ': estado esperado ' . $caso['estado'] . ', obtido ' . $veredito['estado'] );
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! str_contains( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo do ramo ' . $caso['acao'] . ' não menciona "' . $trecho . '"' );
		}
	}

	foreach ( $caso['proibe'] as $trecho ) {
		medir( $nome );

		if ( str_contains( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo do ramo ' . $caso['acao'] . ' trouxe "' . $trecho . '", que é texto de outro ramo' );
		}
	}

	medir( $nome );

	if ( '' === trim( $veredito['resumo'] ) ) {
		anotar( $nome, $caso['rotulo'] . ': ramo sem resumo para a linha da unidade' );
	}
}

/*
 * PISO DA CLASSIFICAÇÃO: nenhum publicado não gerenciado some. Ou está em
 * risco, ou está sem caminho a quebrar — e nos dois casos continua nomeado. Um
 * objeto que caísse de uma lista sem entrar na outra deixaria a mensagem
 * afirmar "nenhuma URL de terceiro em risco" sobre um banco que ela não mediu
 * por inteiro.
 */
$censo = array(
	array( 'id' => 1, 'tipo' => 'post', 'slug' => 'hello-world', 'titulo' => 'Hello world!' ),
	array( 'id' => 2, 'tipo' => 'page', 'slug' => 'sample-page', 'titulo' => 'Sample Page' ),
	array( 'id' => 3, 'tipo' => 'page', 'slug' => 'raiz', 'titulo' => 'Raiz' ),
);

$classificado = F3Base_Imp_Lotes::classificar_urls_de_terceiro(
	$censo,
	array(
		1 => '',
		2 => '/blog/sample-page/',
		3 => '/',
	)
);

medir( $nome );

if ( count( $classificado['em_risco'] ) + count( $classificado['sem_caminho'] ) !== count( $censo ) ) {
	anotar( $nome, 'piso da classificação: dos ' . count( $censo ) . ' publicados não gerenciados, a classificação devolveu '
		. ( count( $classificado['em_risco'] ) + count( $classificado['sem_caminho'] ) ) . ' — objeto que sai de uma lista sem entrar na outra some do relatório' );
}

medir( $nome );

if ( 1 !== count( $classificado['em_risco'] ) || 2 !== (int) $classificado['em_risco'][0]['id'] ) {
	anotar( $nome, 'piso da classificação: só o publicado com URL de CAMINHO entra em risco, e a lista veio com ' . count( $classificado['em_risco'] ) . ' item(ns)' );
}

medir( $nome );

if ( 2 !== count( $classificado['sem_caminho'] ) ) {
	anotar( $nome, 'piso da classificação: caminho vazio e caminho "/" são endereços de query e vão para sem_caminho — vieram ' . count( $classificado['sem_caminho'] ) . ' item(ns)' );
}

medir( $nome );

if ( ! contem( F3Base_Imp_Lotes::decisao_de_permalinks( $L::PERMALINKS_SE_SEGURO, '', '/%postname%/', $classificado )['motivo'], 'hello-world' ) ) {
	anotar( $nome, 'piso da classificação: o publicado não gerenciado sem URL de caminho saiu do relatório — some do risco, nunca da mensagem' );
}

/*
 * PISO DA APLICAÇÃO: o ramo que aplica GRAVA REDIRECT. A regra do par é pura e
 * é medida aqui — endereço que mudou vira 301, endereço que não mudou é
 * descartado (o módulo do site-core casa o par ANTES do 404, e um par idêntico
 * redirecionaria a página viva para si própria), e referência sem endereço novo
 * não inventa destino.
 */
$pares = F3Base_Imp_Lotes::pares_de_redirect(
	array(
		'/blog/metodo/'   => 'metodo',
		'/contato/'       => 'contato',
		'/blog/sumido/'   => 'sumido',
	),
	array(
		'metodo'  => '/metodo/',
		'contato' => '/contato/',
		'sumido'  => '',
	)
);

medir( $nome );

if ( 1 !== count( $pares ) ) {
	anotar( $nome, 'piso do redirect: dos três caminhos antigos só UM mudou de endereço, e a regra devolveu ' . count( $pares ) . ' par(es)' );
}

medir( $nome );

if ( 1 === count( $pares ) && ( '/blog/metodo/' !== $pares[0]['de'] || '/metodo/' !== $pares[0]['para'] || 301 !== $pares[0]['status'] ) ) {
	anotar( $nome, 'piso do redirect: o par gravado não é /blog/metodo/ → /metodo/ em 301, e sim ' . wp_json_encode( $pares[0] ) );
}

medir( $nome );

if ( array() !== F3Base_Imp_Lotes::pares_de_redirect( array( '/contato/' => 'contato' ), array( 'contato' => '/contato/' ) ) ) {
	anotar( $nome, 'piso do laço: caminho que não mudou virou par de redirect — o módulo casa o par antes do 404 e a página viva passaria a redirecionar para si própria' );
}


/*
 * O RAMO QUE COBRE, nascido na 1.0.17. Ele não é um quarto valor decorativo: é
 * o padrão do template, e a diferença dele para `aplicar-declarada` é
 * exatamente a chave `cobertura`, que decide se o 301 alcança o publicado que
 * este pacote NÃO gerencia. Sem piso na chave, o ramo novo poderia aplicar sem
 * cobrir — indistinguível de `aplicar-declarada` — e ninguém saberia.
 */
$casos_cobertura = array(
	array(
		'rotulo'    => 'aplicar-e-cobrir com terceiro publicado APLICA e COBRE, nomeando a URL coberta',
		'decisao'   => $L::PERMALINKS_COBRIR,
		'observado' => '/blog/%postname%/',
		'medicao'   => $com_terceiro,
		'acao'      => $L::ACAO_PERMALINK_APLICAR,
		'estado'    => 'OK',
		'cobertura' => true,
		'exige'     => array( 'aplicar-e-cobrir', '#2', 'sample-page', '/blog/sample-page/', 'aditivo', '301' ),
		'proibe'    => array( 'nada foi escrito', 'risco fica REGISTRADO' ),
	),
	array(
		'rotulo'    => 'aplicar-e-cobrir na instalação recém-criada: o endereço de query não ganha par, e a mensagem diz por quê',
		'decisao'   => $L::PERMALINKS_COBRIR,
		'observado' => '',
		'medicao'   => $so_query,
		'acao'      => $L::ACAO_PERMALINK_APLICAR,
		'estado'    => 'OK',
		'cobertura' => true,
		'exige'     => array( '#2', 'sample-page', '?p=', 'laço' ),
		'proibe'    => array( 'passa a responder 301' ),
	),
	array(
		'rotulo'    => 'aplicar-e-cobrir com todo publicado gerenciado APLICA e diz que não há terceiro a cobrir',
		'decisao'   => $L::PERMALINKS_COBRIR,
		'observado' => '/blog/%postname%/',
		'medicao'   => $so_gerenciado,
		'acao'      => $L::ACAO_PERMALINK_APLICAR,
		'estado'    => 'OK',
		'cobertura' => true,
		'exige'     => array( 'aplicar-e-cobrir', 'nenhum publicado não gerenciado tem URL de caminho a cobrir' ),
		'proibe'    => array( 'passa a responder 301' ),
	),
	array(
		'rotulo'    => 'estrutura já igual à declarada: a igualdade vence aplicar-e-cobrir e nada é coberto',
		'decisao'   => $L::PERMALINKS_COBRIR,
		'observado' => '/%postname%/',
		'medicao'   => $com_terceiro,
		'acao'      => $L::ACAO_PERMALINK_NADA,
		'estado'    => 'OK',
		'cobertura' => false,
		'exige'     => array( 'JÁ É a declarada', 'nada a gravar' ),
		'proibe'    => array( 'aplicar-e-cobrir' ),
	),
);

foreach ( $casos_cobertura as $caso ) {
	medir( $nome );

	$veredito = F3Base_Imp_Lotes::decisao_de_permalinks( $caso['decisao'], $caso['observado'], '/%postname%/', $caso['medicao'] );

	if ( $veredito['acao'] !== $caso['acao'] ) {
		anotar( $nome, $caso['rotulo'] . ': ação esperada ' . $caso['acao'] . ', obtida ' . $veredito['acao'] );
		continue;
	}

	medir( $nome );

	if ( $veredito['estado'] !== $caso['estado'] ) {
		anotar( $nome, $caso['rotulo'] . ': estado esperado ' . $caso['estado'] . ', obtido ' . $veredito['estado'] );
	}

	medir( $nome );

	if ( (bool) $veredito['cobertura'] !== $caso['cobertura'] ) {
		anotar( $nome, $caso['rotulo'] . ': cobertura esperada ' . ( $caso['cobertura'] ? 'true' : 'false' ) . ' e veio o contrário — é ela que decide se o 301 alcança o publicado não gerenciado' );
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'] . ' ' . $veredito['resumo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem do ramo não menciona "' . $trecho . '"' );
		}
	}

	foreach ( $caso['proibe'] as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o motivo trouxe "' . $trecho . '", que é texto de outro ramo' );
		}
	}
}

/*
 * PISO DA COBERTURA: os OUTROS ramos que aplicam NÃO cobrem. Se `cobertura`
 * viesse true em todos, a decisão declarada deixaria de ter efeito — e o
 * relatório continuaria dizendo a mesma coisa, porque a frase de cada ramo é
 * escrita à parte da chave que o lado impuro lê.
 */
foreach (
	array(
		$L::PERMALINKS_SE_SEGURO  => $so_gerenciado,
		$L::PERMALINKS_DECLARADA  => $com_terceiro,
	) as $decisao_sem_cobertura => $medicao_do_caso
) {
	medir( $nome );

	$veredito = F3Base_Imp_Lotes::decisao_de_permalinks( $decisao_sem_cobertura, '/blog/%postname%/', '/%postname%/', $medicao_do_caso );

	if ( $L::ACAO_PERMALINK_APLICAR === $veredito['acao'] && false !== (bool) $veredito['cobertura'] ) {
		anotar( $nome, 'piso da cobertura: "' . $decisao_sem_cobertura . '" aplicou COM cobertura — só aplicar-e-cobrir grava redirect para o publicado que este pacote não gerencia' );
	}
}

medir( $nome );

if ( ! in_array( $L::PERMALINKS_COBRIR, F3Base_Imp_Lotes::decisoes_de_permalinks(), true ) ) {
	anotar( $nome, 'piso da lista: aplicar-e-cobrir não consta das decisões aceitas, e o ramo que não consta da lista sai do texto que o valor não reconhecido imprime' );
}

/*
 * PISO DO PAR DE TERCEIRO: a referência de quem não é gerenciado é o ID
 * prefixado, e a MESMA regra do par vale para ela — caminho que muda vira 301,
 * caminho que não muda é descartado. `/sample-page/` sob `/%postname%/` é
 * exatamente o segundo caso, e ele não pode ganhar par nenhum.
 */
$pares_terceiro = F3Base_Imp_Lotes::pares_de_redirect(
	array(
		'/2026/08/31/hello-world/' => F3Base_Imp_Lotes::REF_POR_ID . '1',
		'/sample-page/'            => F3Base_Imp_Lotes::REF_POR_ID . '2',
	),
	array(
		F3Base_Imp_Lotes::REF_POR_ID . '1' => '/hello-world/',
		F3Base_Imp_Lotes::REF_POR_ID . '2' => '/sample-page/',
	)
);

medir( $nome );

if ( 1 !== count( $pares_terceiro ) ) {
	anotar( $nome, 'piso do par de terceiro: dos dois publicados não gerenciados só o post muda de caminho, e a regra devolveu ' . count( $pares_terceiro ) . ' par(es)' );
}

medir( $nome );

if ( 1 === count( $pares_terceiro ) && ( '/2026/08/31/hello-world/' !== $pares_terceiro[0]['de'] || '/hello-world/' !== $pares_terceiro[0]['para'] || 301 !== $pares_terceiro[0]['status'] ) ) {
	anotar( $nome, 'piso do par de terceiro: o par não é /2026/08/31/hello-world/ → /hello-world/ em 301, e sim ' . wp_json_encode( $pares_terceiro[0] ) );
}

medir( $nome );

foreach ( $pares_terceiro as $par_medido ) {
	if ( '/sample-page/' === $par_medido['de'] ) {
		anotar( $nome, 'piso do laço em terceiro: /sample-page/ não muda de endereço sob /%postname%/ e ganhou par — o módulo casa o par antes do 404 e a página viva passaria a redirecionar para si própria' );
	}
}

/*
 * PISO DA CONTAGEM POR ORIGEM com o par de terceiro: ele entra na união pelo
 * MESMO produtor e com origem própria, e a contagem por origem continua
 * batendo. Um par que entrasse por fora do produtor é o defeito da 1.0.11 com
 * outro nome.
 */
F3Base_Imp_Lotes::esquecer_redirects_computados();
F3Base_Imp_Lotes::registrar_redirects_computados( $pares_terceiro, 'wordpress.permalinks' );

$uniao_terceiro = F3Base_Imp_Lotes::uniao_de_redirects(
	array(),
	F3Base_Imp_Lotes::redirects_computados(),
	array()
);

medir( $nome );

if ( 1 !== (int) $uniao_terceiro['contagem'][ $L::REDIRECT_COMPUTADO ] || 1 !== count( $uniao_terceiro['pares'] ) ) {
	anotar( $nome, 'piso da contagem por origem: o par computado para o publicado não gerenciado não apareceu na união com origem computado — vieram '
		. (int) $uniao_terceiro['contagem'][ $L::REDIRECT_COMPUTADO ] . ' computado(s) e ' . count( $uniao_terceiro['pares'] ) . ' par(es)' );
}

medir( $nome );

if ( array() !== $uniao_terceiro['pares'] && 'computado:wordpress.permalinks' !== (string) $uniao_terceiro['pares'][0]['origem'] ) {
	anotar( $nome, 'piso da origem: o par do publicado não gerenciado entrou sem o carimbo da etapa que o computou — origem observada: ' . (string) $uniao_terceiro['pares'][0]['origem'] );
}

F3Base_Imp_Lotes::esquecer_redirects_computados();


/* ---------- conteudo.exemplo_do_wordpress: o discriminante, teto e piso ---------- */

/*
 * A orientação que criou esta regra: o implantador deve fazer todas as
 * modificações necessárias para a página funcionar, alterando conteúdo
 * preexistente se preciso. `Hello world!` e `Sample Page` não são conteúdo de
 * ninguém — são o que `wp_install_defaults()` insere em toda instalação —, e
 * deixá-los publicados põe `Sample Page` no sitemap, na seleção do `llms.txt` e
 * na busca.
 *
 * O que decide NÃO é o slug: slug igual não prova nada, e é a mesma regra que
 * governa a adoção de objeto. O objeto só é exemplo se AINDA FOR o que o
 * WordPress criou — título e conteúdo idênticos ao que o núcleo escreveria
 * agora E `post_modified_gmt` sem avançar em relação a `post_date_gmt`.
 *
 * O piso que importa é o NEGATIVO: objeto EDITADO não pode ir para a lixeira em
 * nenhuma circunstância. A edição é plantada em título, em conteúdo e nos dois,
 * e os três casos precisam sobreviver.
 */

$nome = 'conteudo.exemplo_do_wordpress';
$C    = 'F3Base_Imp_Conteudo';

$amostra_falsa = array(
	array(
		'papel'    => $C::EXEMPLO_PRIMEIRO_POST,
		'tipo'     => 'post',
		'slug'     => 'hello-world',
		'titulo'   => 'Hello world!',
		'conteudo' => "<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->",
	),
	array(
		'papel'    => $C::EXEMPLO_PAGINA_EXEMPLO,
		'tipo'     => 'page',
		'slug'     => 'sample-page',
		'titulo'   => 'Sample Page',
		'conteudo' => "<!-- wp:paragraph -->\n<p>This is an example page.</p>\n<!-- /wp:paragraph -->",
	),
);

$post_do_nucleo = $amostra_falsa[0];

/**
 * Objeto observado, INTOCADO, com o desvio que o caso quiser plantar.
 *
 * @param array<string,string> $esperado Entrada do catálogo.
 * @param array<string,mixed>  $desvio   O que o caso muda.
 * @return array<string,mixed>
 */
function f3b_observado_de_exemplo( array $esperado, array $desvio = array() ): array {
	return array_merge(
		array(
			'tipo'              => $esperado['tipo'],
			'slug'              => $esperado['slug'],
			'titulo'            => $esperado['titulo'],
			'conteudo'          => $esperado['conteudo'],
			'post_date_gmt'     => '2026-08-31 12:00:00',
			'post_modified_gmt' => '2026-08-31 12:00:00',
			'gerenciado'        => false,
			'em_uso'            => '',
		),
		$desvio
	);
}

$casos_exemplo = array(
	array(
		'rotulo'   => 'intocado desde a instalação vai para a LIXEIRA',
		'esperado' => $post_do_nucleo,
		'desvio'   => array(),
		'acao'     => $C::ACAO_EXEMPLO_LIXEIRA,
		'exige'    => array( 'intocado', 'post_modified_gmt', $C::EXEMPLO_PRIMEIRO_POST ),
	),
	array(
		'rotulo'   => 'TÍTULO editado: intocável',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'titulo' => 'Como esta operação constrói sites' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'título editado' ),
		'proibe'   => array( 'conteúdo editado' ),
	),
	array(
		'rotulo'   => 'CONTEÚDO editado: intocável',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'conteudo' => '<!-- wp:paragraph --><p>Texto de verdade, publicado por alguém.</p><!-- /wp:paragraph -->' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'conteúdo editado' ),
		'proibe'   => array( 'título editado' ),
	),
	array(
		'rotulo'   => 'título E conteúdo editados: intocável, e as DUAS divergências saem nomeadas',
		'esperado' => $post_do_nucleo,
		'desvio'   => array(
			'titulo'   => 'Como esta operação constrói sites',
			'conteudo' => '<!-- wp:paragraph --><p>Texto de verdade, publicado por alguém.</p><!-- /wp:paragraph -->',
		),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'título editado', 'conteúdo editado' ),
	),
	array(
		'rotulo'   => 'texto idêntico e post_modified_gmt avançado: intocável, porque alguém gravou',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'post_modified_gmt' => '2026-09-02 09:14:00' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'post_modified_gmt avançou' ),
		'proibe'   => array( 'título editado', 'conteúdo editado' ),
	),
	array(
		'rotulo'   => 'objeto gerenciado por este pacote: intocável antes de qualquer comparação',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'gerenciado' => true ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'gerenciado por este pacote' ),
	),
	array(
		'rotulo'   => 'objeto EM USO como página inicial: intocável mesmo intocado',
		'esperado' => $post_do_nucleo,
		'desvio'   => array( 'em_uso' => 'page_on_front' ),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'em uso', 'page_on_front' ),
		'proibe'   => array( 'intocado' ),
	),
	array(
		'rotulo'   => 'fora do catálogo do núcleo: intocável, e a mensagem diz que não é objeto de wp_install_defaults()',
		'esperado' => array(),
		'desvio'   => array(),
		'acao'     => $C::ACAO_EXEMPLO_MANTER,
		'exige'    => array( 'wp_install_defaults' ),
	),
);

foreach ( $casos_exemplo as $caso ) {
	medir( $nome );

	$base_do_caso = array() === $caso['esperado'] ? $post_do_nucleo : $caso['esperado'];
	$veredito     = F3Base_Imp_Conteudo::veredito_de_exemplo_do_wordpress(
		$caso['esperado'],
		f3b_observado_de_exemplo( $base_do_caso, $caso['desvio'] )
	);

	if ( $veredito['acao'] !== $caso['acao'] ) {
		anotar( $nome, $caso['rotulo'] . ': ação esperada ' . $caso['acao'] . ', obtida ' . $veredito['acao'] );
		continue;
	}

	medir( $nome );

	if ( '' === trim( $veredito['discriminante'] ) ) {
		anotar( $nome, $caso['rotulo'] . ': veredito sem DISCRIMINANTE — dizer que removeu ou preservou não basta, o relatório imprime o que decidiu' );
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['discriminante'] . ' ' . $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem não menciona "' . $trecho . '"' );
		}
	}

	foreach ( (array) ( $caso['proibe'] ?? array() ) as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['discriminante'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': o discriminante trouxe "' . $trecho . '", que é o de outro caso' );
		}
	}
}

/*
 * O PISO NEGATIVO, dito como afirmação própria e não como consequência dos
 * casos acima: objeto EDITADO não vai para a lixeira em NENHUMA circunstância.
 * A edição é plantada em título, em conteúdo e nos dois, e nenhum dos três pode
 * produzir a ação de remover.
 */
$edicoes_plantadas = array(
	'só no título'   => array( 'titulo' => 'Um título que alguém escreveu' ),
	'só no conteúdo' => array( 'conteudo' => '<!-- wp:paragraph --><p>Um texto que alguém escreveu.</p><!-- /wp:paragraph -->' ),
	'nos dois'       => array(
		'titulo'   => 'Um título que alguém escreveu',
		'conteudo' => '<!-- wp:paragraph --><p>Um texto que alguém escreveu.</p><!-- /wp:paragraph -->',
	),
);

foreach ( $amostra_falsa as $entrada_do_nucleo ) {
	foreach ( $edicoes_plantadas as $onde => $edicao ) {
		medir( $nome );

		$veredito = F3Base_Imp_Conteudo::veredito_de_exemplo_do_wordpress(
			$entrada_do_nucleo,
			f3b_observado_de_exemplo( $entrada_do_nucleo, $edicao )
		);

		if ( $C::ACAO_EXEMPLO_LIXEIRA === $veredito['acao'] ) {
			anotar( $nome, 'PISO NEGATIVO violado: ' . $entrada_do_nucleo['papel'] . ' com edição ' . $onde
				. ' foi mandado para a lixeira — objeto editado é conteúdo de verdade de alguém e é intocável' );
		}

		medir( $nome );

		if ( $C::ACAO_EXEMPLO_MANTER === $veredito['acao'] && ! contem( $veredito['discriminante'], 'editado' ) ) {
			anotar( $nome, 'piso do discriminante: ' . $entrada_do_nucleo['papel'] . ' com edição ' . $onde
				. ' foi preservado sem que o discriminante dissesse que houve edição — discriminante: ' . $veredito['discriminante'] );
		}
	}
}

/*
 * PISO DA HIPÓTESE: o slug INDEXA o catálogo, e só. Tipo errado não casa, slug
 * de fora não casa, e slug vazio nunca casa — sem isso, um objeto sem
 * `post_name` cairia na primeira entrada do catálogo e seria comparado com o
 * que não é.
 */
$hipoteses = array(
	array( 'post', 'hello-world', $C::EXEMPLO_PRIMEIRO_POST, 'o post do núcleo casa com a entrada dele' ),
	array( 'page', 'sample-page', $C::EXEMPLO_PAGINA_EXEMPLO, 'a página do núcleo casa com a entrada dela' ),
	array( 'page', 'hello-world', '', 'o slug do post numa página NÃO casa: o tipo faz parte da hipótese' ),
	array( 'post', 'sample-page', '', 'o slug da página num post NÃO casa' ),
	array( 'post', 'metodo-f3', '', 'slug de fora do catálogo não casa' ),
	array( 'post', '', '', 'slug vazio nunca casa' ),
);

foreach ( $hipoteses as $hipotese ) {
	medir( $nome );

	$entrada = F3Base_Imp_Conteudo::entrada_da_amostra( $amostra_falsa, $hipotese[0], $hipotese[1] );
	$papel   = (string) ( $entrada['papel'] ?? '' );

	if ( $papel !== $hipotese[2] ) {
		anotar( $nome, 'piso da hipótese: ' . $hipotese[3] . ' — papel esperado "' . $hipotese[2] . '", obtido "' . $papel . '"' );
	}
}

/*
 * A lista comparada contra os LITERAIS que o schema declara, e não contra as
 * próprias constantes: comparar a constante com ela mesma é tautologia, e o que
 * se quer provar é que o código e o enum do schema não divergiram.
 */
medir( $nome );

if ( array( 'lixeira', 'manter' ) !== F3Base_Imp_Conteudo::decisoes_de_exemplo() ) {
	anotar( $nome, 'piso da lista: as decisões aceitas de conteudo.exemplo_do_wordpress deixaram de ser lixeira e manter, e o schema declara essas duas' );
}

/* ---------- lotes.indexacao_consequencia: causa E consequência, nos dois ramos ---------- */

/*
 * O defeito medido na 1.0.9: `blog_public = 0` era a gravação CERTA quando as
 * condições não fechavam, e o log dizia que gravou — sem dizer que essa
 * gravação é o que faz o wp-admin estampar "Problema grave de SEO: Você está
 * bloqueando o acesso dos robôs". O operador ficava com um alarme vermelho no
 * painel e um relatório em OK, sem nada ligando os dois.
 *
 * O aviso do WordPress não é suprimido: ele está certo. O que se exige aqui é
 * que a mensagem nomeie a consequência E o caminho de saída — e que o ramo
 * indexável NÃO carregue nenhum dos dois, que seria o texto de um ramo impresso
 * no outro.
 *
 * Na 1.0.12 o CAMINHO DE SAÍDA mudou, e a exigência muda com ele: não se pede
 * mais para declarar `producao` e preencher `ambiente.dominios_autorizados`,
 * porque o padrão já é indexar e a lista deixou de ser condição. O que resta é
 * sumir a causa medida ou declarar `ambiente.indexar = "forcar"`. Exigir aqui
 * o texto antigo seria a suíte guardando a regra revogada.
 */

$nome = 'lotes.indexacao_consequencia';

$bloqueado = F3Base_Imp_Lotes::consequencia_de_indexacao( false, 'local', 'exemplo.test' );
$indexavel = F3Base_Imp_Lotes::consequencia_de_indexacao( true, 'producao', 'exemplo.test' );

foreach ( array( 'Problema grave de SEO', 'ambiente.tipo', 'producao', 'ambiente.indexar = "forcar"', 'ambiente.dominios_de_previa', 'exemplo.test', 'local' ) as $trecho ) {
	medir( $nome );

	if ( ! str_contains( $bloqueado, $trecho ) ) {
		anotar( $nome, 'ramo não indexável: a mensagem não menciona "' . $trecho . '" — causa sem consequência, ou consequência sem o caminho de saída' );
	}
}

medir( $nome );

if ( ! str_contains( $bloqueado, 'não é suprimido' ) ) {
	anotar( $nome, 'ramo não indexável: a mensagem não diz que o aviso do WordPress NÃO é suprimido — esconder alarme verdadeiro é pior que explicá-lo, e a mensagem é o lugar onde isso fica dito' );
}

medir( $nome );

if ( str_contains( $bloqueado, 'inclua o host' ) ) {
	anotar( $nome, 'ramo não indexável: a mensagem ainda manda preencher ambiente.dominios_autorizados para indexar — a lista deixou de ser condição de blog_public na 1.0.12, e o caminho de saída que exige configuração é justamente o que esta release inverteu' );
}

foreach ( array( 'Problema grave de SEO', 'ambiente.indexar = "forcar"' ) as $trecho ) {
	medir( $nome );

	if ( str_contains( $indexavel, $trecho ) ) {
		anotar( $nome, 'ramo indexável: trouxe "' . $trecho . '", que é texto do ramo bloqueado — o aviso não existe quando blog_public = 1' );
	}
}

medir( $nome );

if ( '' === trim( $indexavel ) ) {
	anotar( $nome, 'ramo indexável em silêncio: toda checagem emite nos DOIS ramos, e o ramo certo também precisa dizer o que o operador deve ver' );
}

/* ---------- lotes.indexacao_veredito: o ônus invertido, teto e piso ---------- */

/*
 * A DECISÃO DO DONO, na 1.0.12: "todas as configurações do implantador devem já
 * criar um site pronto para produção e para ser indexado. Se o usuário não
 * quiser, ele deverá mudar isso manualmente."
 *
 * Até a 1.0.11 era o contrário: `blog_public = 1` exigia TRÊS condições, e o
 * template nascia com `ambiente.tipo = local` e a lista de domínios vazia — o
 * padrão era não indexar, e chegar ao estado normal de um site exigia acertar
 * três chaves. O piso aqui é dos dois lados e cobre os dois riscos: o de o
 * padrão voltar a não indexar, e o de uma guarda passar a dar falso positivo
 * num site real.
 */

$nome = 'lotes.indexacao_veredito';
$L    = 'F3Base_Imp_Lotes';

/**
 * Medição de ambiente com os valores de um site de produção limpo.
 *
 * @param array<string,mixed> $mudanca O que este caso muda.
 * @return array<string,mixed>
 */
function f3b_ambiente_medido( array $mudanca = array() ): array {
	return $mudanca + array(
		'modo'        => 'medir',
		'tipo'        => 'producao',
		'esquema'     => 'https',
		'host'        => 'exemplo.com.br',
		'ambiente_wp' => 'production',
		'previa'      => array(),
		'autorizados' => array(),
	);
}

$casos_indexacao = array(
	array(
		'rotulo' => 'produção limpa com HTTPS indexa, sem configuração nenhuma',
		'medido' => f3b_ambiente_medido(),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'PADRÃO', 'nasce indexável', 'nenhuma guarda' ),
		'proibe' => array( 'guarda(s) MEDIDA(s)', 'ambiente.indexar = "forcar"' ),
	),
	array(
		'rotulo' => 'wp_get_environment_type() = staging segura, em WARN, nomeando',
		'medido' => f3b_ambiente_medido( array( 'ambiente_wp' => 'staging' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'wp_get_environment_type()', 'staging', 'declararam explicitamente', 'ambiente.indexar = "forcar"' ),
		'proibe' => array( 'PADRÃO: o site nasce indexável' ),
	),
	array(
		'rotulo' => 'home_url() em HTTP puro segura, em WARN, nomeando o esquema observado',
		'medido' => f3b_ambiente_medido( array( 'esquema' => 'http' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'esquema de home_url()', 'http', 'HTTP puro é defeito', 'ambiente.indexar = "forcar"' ),
		'proibe' => array( 'wp_get_environment_type()' ),
	),
	array(
		'rotulo' => 'ambiente.tipo diferente de producao segura, em WARN, nomeando o valor declarado',
		'medido' => f3b_ambiente_medido( array( 'tipo' => 'local' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'ambiente.tipo', 'local', 'ambiente.indexar = "forcar"' ),
		'proibe' => array( 'esquema de home_url()' ),
	),
	array(
		'rotulo' => 'host de pré-visualização declarado segura, em WARN, nomeando o sufixo que casou',
		'medido' => f3b_ambiente_medido(
			array(
				'host'   => 'projeto.dreamhosters.com',
				'previa' => array( 'dreamhosters.com' ),
			)
		),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'ambiente.dominios_de_previa', 'projeto.dreamhosters.com', 'dreamhosters.com' ),
		'proibe' => array( 'PADRÃO: o site nasce indexável' ),
	),
	array(
		'rotulo' => 'lista de prévia VAZIA não segura o mesmo host: a guarda não existe escondida no código',
		'medido' => f3b_ambiente_medido( array( 'host' => 'projeto.dreamhosters.com' ) ),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'PADRÃO' ),
		'proibe' => array( 'ambiente.dominios_de_previa (observado' ),
	),
	array(
		'rotulo' => 'indexar = forcar com guarda ativa indexa E registra o motivo por que a decisão existia',
		'medido' => f3b_ambiente_medido(
			array(
				'modo'        => 'forcar',
				'ambiente_wp' => 'staging',
			)
		),
		'valor'  => 1,
		'estado' => 'WARN',
		'exige'  => array( 'forcar', 'IGNORANDO', 'wp_get_environment_type()', 'staging', 'motivo por que a decisão existia' ),
		'proibe' => array( 'INERTE' ),
	),
	array(
		'rotulo' => 'indexar = forcar sem guarda alguma registra a decisão como INERTE, em vez de calar',
		'medido' => f3b_ambiente_medido( array( 'modo' => 'forcar' ) ),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'forcar', 'INERTE' ),
		'proibe' => array( 'IGNORANDO' ),
	),
	array(
		'rotulo' => 'indexar = nunca em produção limpa não indexa, e diz que é escolha, não medição',
		'medido' => f3b_ambiente_medido( array( 'modo' => 'nunca' ) ),
		'valor'  => 0,
		'estado' => 'WARN',
		'exige'  => array( 'nunca', 'escolha do projeto', 'nenhuma' ),
		'proibe' => array( 'PADRÃO: o site nasce indexável' ),
	),
	array(
		'rotulo' => 'modo não reconhecido cai para medir, e não vira decisão silenciosa',
		'medido' => f3b_ambiente_medido( array( 'modo' => 'talvez' ) ),
		'valor'  => 1,
		'estado' => 'OK',
		'exige'  => array( 'PADRÃO' ),
		'proibe' => array( 'talvez' ),
	),
);

foreach ( $casos_indexacao as $caso ) {
	$veredito = F3Base_Imp_Lotes::veredito_de_indexacao( $caso['medido'] );

	medir( $nome );

	if ( $caso['valor'] !== $veredito['valor'] ) {
		anotar( $nome, $caso['rotulo'] . ': blog_public esperado ' . $caso['valor'] . ', obtido ' . $veredito['valor'] );
	}

	medir( $nome );

	if ( $caso['estado'] !== $veredito['estado'] ) {
		anotar( $nome, $caso['rotulo'] . ': estado esperado ' . $caso['estado'] . ', obtido ' . $veredito['estado'] );
	}

	foreach ( $caso['exige'] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem não menciona "' . $trecho . '" — guarda sem o valor observado, ou decisão sem o motivo, não responde à pergunta seguinte do operador' );
		}
	}

	foreach ( $caso['proibe'] as $trecho ) {
		medir( $nome );

		if ( contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $caso['rotulo'] . ': a mensagem trouxe "' . $trecho . '", que é texto de outro ramo' );
		}
	}
}

/*
 * PISO DA GUARDA QUE NÃO PODE DAR FALSO POSITIVO. `wp_get_environment_type()`
 * devolve `production` por padrão no núcleo; qualquer outro valor fora dos três
 * declarados (uma hospedagem que invente um nome) NÃO pode segurar o site.
 */
foreach ( array( 'production', '', 'producao-cliente' ) as $ambiente_wp ) {
	medir( $nome );

	$v = F3Base_Imp_Lotes::veredito_de_indexacao( f3b_ambiente_medido( array( 'ambiente_wp' => $ambiente_wp ) ) );

	if ( 1 !== $v['valor'] ) {
		anotar( $nome, 'piso do falso positivo: wp_get_environment_type() = "' . $ambiente_wp . '" segurou a indexação, e só local/development/staging podem — o resto é site de produção com nome diferente' );
	}
}

/* PISO DO SUFIXO DE PRÉVIA: casamento por sufixo de DOMÍNIO, nunca por trecho. */
$casos_sufixo = array(
	array( 'projeto.wpengine.com', array( 'wpengine.com' ), 'wpengine.com', 'subdomínio casa' ),
	array( 'wpengine.com', array( 'wpengine.com' ), 'wpengine.com', 'o próprio domínio casa' ),
	array( 'projeto.wpengine.com', array( '*.wpengine.com' ), 'wpengine.com', 'sufixo declarado com asterisco casa' ),
	array( 'projeto.wpengine.com', array( '.wpengine.com' ), 'wpengine.com', 'sufixo declarado com ponto casa' ),
	array( 'meusite.wpengine.com.br', array( 'wpengine.com' ), '', 'outro domínio que só CONTÉM o sufixo não casa — é outro dono' ),
	array( 'naowpengine.com', array( 'wpengine.com' ), '', 'host que termina com o sufixo sem a fronteira do ponto não casa' ),
	array( 'projeto.wpengine.com', array(), '', 'lista vazia não casa com nada' ),
	array( '', array( 'wpengine.com' ), '', 'host vazio não casa' ),
);

foreach ( $casos_sufixo as $caso ) {
	medir( $nome );

	$obtido = F3Base_Imp_Lotes::sufixo_de_previa( $caso[0], $caso[1] );

	if ( $caso[2] !== $obtido ) {
		anotar( $nome, 'sufixo de prévia (' . $caso[3] . '): esperado "' . $caso[2] . '", obtido "' . $obtido . '"' );
	}
}

/*
 * CROSS-CHECK DOS DOMÍNIOS AUTORIZADOS. Ele NÃO decide a indexação — era a
 * terceira condição até a 1.0.11, e com a lista vazia no template isso
 * significava um site que não indexa por padrão.
 */
$fora_da_lista = F3Base_Imp_Lotes::veredito_de_indexacao(
	f3b_ambiente_medido(
		array(
			'host'        => 'preview.outro.com',
			'autorizados' => array( 'exemplo.com.br' ),
		)
	)
);

medir( $nome );

if ( 1 !== $fora_da_lista['valor'] ) {
	anotar( $nome, 'cross-check: host fora da lista declarada SEGUROU a indexação — a lista deixou de ser condição de blog_public nesta release, e voltar a segurar é voltar ao padrão que exigia configuração' );
}

medir( $nome );

if ( 'WARN' !== $fora_da_lista['cross_check']['estado'] ) {
	anotar( $nome, 'cross-check: host fora da lista declarada não saiu em WARN, e sim ' . $fora_da_lista['cross_check']['estado'] . ' — divergência entre o endereço declarado e o servido é diagnóstico, e some do relatório se ninguém a emitir' );
}

foreach ( array( 'preview.outro.com', 'exemplo.com.br', 'NÃO impede a indexação' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $fora_da_lista['cross_check']['motivo'], $trecho ) ) {
		anotar( $nome, 'cross-check: a mensagem não menciona "' . $trecho . '" — o host OBSERVADO e a lista DECLARADA saem juntos, ou o operador não sabe qual dos dois corrigir' );
	}
}

$lista_vazia = F3Base_Imp_Lotes::cross_check_de_dominios( 'exemplo.com.br', array() );

medir( $nome );

if ( 'N/A' !== $lista_vazia['estado'] ) {
	anotar( $nome, 'cross-check: lista VAZIA fechou ' . $lista_vazia['estado'] . ' em vez de N/A — lista vazia não é achado, e o padrão do template é vazia' );
}

$na_lista = F3Base_Imp_Lotes::cross_check_de_dominios( 'exemplo.com.br', array( 'exemplo.com.br', 'www.exemplo.com.br' ) );

medir( $nome );

if ( 'OK' !== $na_lista['estado'] ) {
	anotar( $nome, 'cross-check: host DENTRO da lista declarada fechou ' . $na_lista['estado'] . ' em vez de OK — toda checagem emite nos dois ramos, e o ramo certo também precisa sair' );
}

/* A consequência acompanha o valor gravado, nos dois ramos do veredito. */
$producao_limpa = F3Base_Imp_Lotes::veredito_de_indexacao( f3b_ambiente_medido() );
$com_guarda     = F3Base_Imp_Lotes::veredito_de_indexacao( f3b_ambiente_medido( array( 'ambiente_wp' => 'local' ) ) );

medir( $nome );

if ( contem( $producao_limpa['consequencia'], 'Problema grave de SEO' ) ) {
	anotar( $nome, 'o ramo indexável trouxe o texto do aviso do wp-admin, que só existe quando blog_public = 0' );
}

medir( $nome );

if ( ! contem( $com_guarda['consequencia'], 'Problema grave de SEO' ) ) {
	anotar( $nome, 'o ramo com guarda ativa não nomeia a consequência no wp-admin: o operador fica com um alarme vermelho no painel e um relatório que não o explica' );
}

/* ---------- lotes.redirects_uniao: a fonte composta, teto e piso ---------- */

/*
 * O DEFEITO MEDIDO NO BANCO DEPOIS DA 1.0.11: `f3base_redirects` em `a:0:{}`
 * com o log da mesma execução afirmando "permalinks aplicada para
 * /%postname%/, com 2 URL(s) antiga(s) respondendo por redirecionamento
 * declarado". A option tinha DUAS fontes de valor desejado: a etapa de
 * permalinks computava os pares e gravava; mais adiante, a etapa
 * `site_core.options` gravava a mesma option a partir de `redirects: []` e
 * apagava os dois. As duas gravações leram de volta e conferiram.
 *
 * O piso cobre os dois lados da união e a colisão.
 */

$nome = 'lotes.redirects_uniao';

$par_declarado = array(
	'de'     => '/antigo/',
	'para'   => '/novo/',
	'status' => 301,
);
$par_computado = array(
	'de'     => '/blog/metodo/',
	'para'   => '/metodo/',
	'status' => 301,
);

/* O caso exato do defeito: configuração VAZIA não pode apagar o computado. */
$uniao = F3Base_Imp_Lotes::uniao_de_redirects( array(), array( $par_computado ), array() );

medir( $nome );

if ( 1 !== count( $uniao['pares'] ) ) {
	anotar( $nome, 'o defeito medido: com redirects vazio na configuração, a união devolveu ' . count( $uniao['pares'] ) . ' par(es) — o par computado pela troca de permalinks foi apagado pela fonte que não sabia dele, e a URL antiga volta a responder 404' );
}

medir( $nome );

if ( 1 === count( $uniao['pares'] ) && 'computado' !== substr( (string) $uniao['pares'][0]['origem'], 0, 9 ) ) {
	anotar( $nome, 'o par computado foi preservado sem o carimbo de origem: sem ele a execução seguinte não sabe distinguir o que rederivar da configuração do que preservar' );
}

/* As três fontes juntas, e a ordem declarada. */
$tres = F3Base_Imp_Lotes::uniao_de_redirects(
	array( $par_declarado ),
	array( $par_computado ),
	array(
		array(
			'de'     => '/de-outra-execucao/',
			'para'   => '/atual/',
			'status' => 301,
			'origem' => 'computado:wordpress.permalinks',
		),
		array(
			'de'     => '/sem-carimbo/',
			'para'   => '/destino/',
			'status' => 301,
		),
	)
);

medir( $nome );

if ( 4 !== count( $tres['pares'] ) ) {
	anotar( $nome, 'as três fontes juntas deveriam dar 4 pares e deram ' . count( $tres['pares'] ) . ': declarado + computado agora + computado de execução anterior + o que já estava gravado sem carimbo' );
}

medir( $nome );

if ( 1 !== (int) $tres['contagem']['declarado'] || 1 !== (int) $tres['contagem']['computado'] || 2 !== (int) $tres['contagem']['preexistente'] ) {
	anotar( $nome, 'a contagem por fonte saiu ' . wp_json_encode( $tres['contagem'] ) . ': o relatório precisa dizer QUANTOS pares vieram de cada fonte, senão a composição do valor volta a ser inferida' );
}

/* IDEMPOTÊNCIA: a segunda execução não recomputa e não pode apagar. */
$segunda = F3Base_Imp_Lotes::uniao_de_redirects(
	array(),
	array(),
	array( $par_computado + array( 'origem' => 'computado:wordpress.permalinks' ) )
);

medir( $nome );

if ( 1 !== count( $segunda['pares'] ) ) {
	anotar( $nome, 'idempotência: a execução seguinte, que não recomputa nada, apagou o par computado pela anterior — a URL antiga continua circulando muito depois da troca' );
}

/* Par gravado com origem `declarado` NÃO é preservado: a fonte dele é o arquivo. */
$removido = F3Base_Imp_Lotes::uniao_de_redirects(
	array(),
	array(),
	array( $par_declarado + array( 'origem' => 'declarado' ) )
);

medir( $nome );

if ( array() !== $removido['pares'] ) {
	anotar( $nome, 'par removido da configuração sobreviveu na option: o que é declarado é rederivado do arquivo a cada execução, e preservá-lo faria a remoção não ter efeito nenhum' );
}

/* COLISÃO: declarado × computado na mesma origem é FALHA nomeando os dois. */
$colisao = F3Base_Imp_Lotes::uniao_de_redirects(
	array( array( 'de' => '/x/', 'para' => '/declarado/', 'status' => 301 ) ),
	array( array( 'de' => '/x/', 'para' => '/computado/', 'status' => 301 ) ),
	array()
);

medir( $nome );

if ( 1 !== count( $colisao['colisoes'] ) ) {
	anotar( $nome, 'colisão de origem entre um par declarado e um computado não foi acusada: sobrescrita silenciosa é exatamente o que esta release corrige' );
}

$veredito_colisao = F3Base_Imp_Lotes::veredito_da_uniao_de_redirects( $colisao );

medir( $nome );

if ( 'FALHA' !== $veredito_colisao['estado'] ) {
	anotar( $nome, 'colisão de origem fechou ' . $veredito_colisao['estado'] . ' em vez de FALHA' );
}

foreach ( array( '/x/', '/declarado/', '/computado/' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $veredito_colisao['motivo'], $trecho ) ) {
		anotar( $nome, 'a mensagem da colisão não nomeia "' . $trecho . '": os DOIS destinos saem nomeados, ou o operador não tem como decidir qual das duas afirmações vale' );
	}
}

medir( $nome );

if ( 1 !== count( $colisao['pares'] ) || '/declarado/' !== $colisao['pares'][0]['para'] ) {
	anotar( $nome, 'na colisão, o par gravado não foi o DECLARADO: a configuração é a afirmação explícita do operador, e o que muda é que a divergência sai nomeada em vez de silenciosa' );
}

$veredito_limpo = F3Base_Imp_Lotes::veredito_da_uniao_de_redirects( $tres );

medir( $nome );

if ( 'OK' !== $veredito_limpo['estado'] ) {
	anotar( $nome, 'a união sem colisão fechou ' . $veredito_limpo['estado'] . ' em vez de OK — toda checagem emite nos dois ramos' );
}

foreach ( array( 'fonte COMPOSTA', 'declarado', 'computado', 'preservado' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $veredito_limpo['motivo'], $trecho ) ) {
		anotar( $nome, 'a mensagem da união sem colisão não menciona "' . $trecho . '": a composição do valor precisa ser LIDA no relatório, não inferida de duas mensagens distantes' );
	}
}

/* Par sem destino não vira redirect para lugar nenhum. */
medir( $nome );

if ( array() !== F3Base_Imp_Lotes::uniao_de_redirects( array( array( 'de' => '/y/', 'para' => '' ) ), array(), array() )['pares'] ) {
	anotar( $nome, 'par sem destino entrou na união: redirect para cadeia vazia é 301 para lugar nenhum' );
}

/* O REGISTRO das etapas carimba a origem, e é esquecível entre execuções. */
F3Base_Imp_Lotes::esquecer_redirects_computados();
F3Base_Imp_Lotes::registrar_redirects_computados( array( $par_computado ), 'wordpress.permalinks' );

$registrados = F3Base_Imp_Lotes::redirects_computados();

medir( $nome );

if ( 1 !== count( $registrados ) || 'computado:wordpress.permalinks' !== (string) $registrados[0]['origem'] ) {
	anotar( $nome, 'o registro de par computado não carimbou a ETAPA na origem: sem o nome da etapa, o par preservado não diz quem o produziu' );
}

F3Base_Imp_Lotes::esquecer_redirects_computados();

medir( $nome );

if ( array() !== F3Base_Imp_Lotes::redirects_computados() ) {
	anotar( $nome, 'o registro de pares computados não é esquecível: o acúmulo de uma execução vazaria para a seguinte' );
}

/* ---------- lotes.encerramento_por_estado: o texto de cada ramo, no ramo certo ---------- */

/*
 * O defeito medido na 1.0.10: a execução fechou em SUCESSO_APLICACAO, com zero
 * FALHA, e a última frase do log foi "Em falha o implantador permanece ativo,
 * preserva o log e oferece retomada idempotente e rollback das mutações
 * reversíveis." — parágrafo do ramo de falha impresso no ramo de sucesso.
 *
 * O piso é dos dois lados: o texto de falha não pode aparecer em
 * SUCESSO_APLICACAO, e o de sucesso não pode aparecer em FALHA_PARCIAL.
 */

$nome = 'lotes.encerramento_por_estado';

$da_falha   = array( 'PERMANECE ATIVO', 'retomada idempotente', 'rollback' );
$do_sucesso = array( 'autodesativou', 'site-core', 'MCP' );

$sucesso_desativado = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::SUCESSO, true );
$sucesso_ativo      = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::SUCESSO, false );
$falha_parcial      = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::FALHA_PARCIAL, false );
$falha              = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::FALHA, false );

foreach ( array( 'SUCESSO_APLICACAO com autodesativação' => $sucesso_desativado, 'SUCESSO_APLICACAO sem autodesativação' => $sucesso_ativo ) as $rotulo => $texto ) {
	foreach ( $da_falha as $trecho ) {
		medir( $nome );

		if ( contem( $texto, $trecho ) ) {
			anotar( $nome, $rotulo . ': o texto do ramo de FALHA apareceu no ramo de sucesso — trouxe "' . $trecho . '"' );
		}
	}
}

foreach ( $do_sucesso as $trecho ) {
	medir( $nome );

	if ( ! contem( $sucesso_desativado, $trecho ) ) {
		anotar( $nome, 'SUCESSO_APLICACAO com autodesativação: o texto não menciona "' . $trecho . '" — o ramo de sucesso precisa dizer o que aconteceu e o que o operador usa a partir de agora' );
	}
}

foreach ( array( 'FALHA_PARCIAL' => $falha_parcial, 'FALHA' => $falha ) as $rotulo => $texto ) {
	foreach ( $da_falha as $trecho ) {
		medir( $nome );

		if ( ! contem( $texto, $trecho ) ) {
			anotar( $nome, $rotulo . ': o texto do ramo de falha não menciona "' . $trecho . '"' );
		}
	}

	foreach ( array( 'autodesativou', 'MCP' ) as $trecho ) {
		medir( $nome );

		if ( contem( $texto, $trecho ) ) {
			anotar( $nome, $rotulo . ': o texto do ramo de SUCESSO apareceu no ramo de falha — trouxe "' . $trecho . '"' );
		}
	}
}

medir( $nome );

if ( $sucesso_desativado === $sucesso_ativo ) {
	anotar( $nome, 'sucesso com e sem autodesativação devolveram o MESMO texto: o log precisa dizer se o implantador saiu de cena ou continua ativo' );
}


/* ---------- preflight.limites_veredito: o estado sai da MEDIÇÃO, nos dois lados ---------- */

/*
 * O defeito medido na 1.0.14: esta linha era WARN incondicional. Ela dizia de
 * si mesma "fato de ambiente, relatado sem decidir gate" e promovia a unidade
 * do preflight a amarelo numa execução em que nada estava errado.
 *
 * Teto: limites folgados fecham OK NOMEANDO os valores. Piso: cada limite
 * abaixo do piso declarado fecha WARN nomeando QUAL e o que ele custa — e
 * `max_execution_time = 0` é ausência de limite, nunca limite zero.
 */

$nome = 'preflight.limites_veredito';

$piso_declarado = array(
	'max_execution_time_s'   => 30,
	'memory_mb'              => 128,
	'upload_max_filesize_mb' => 8,
	'post_max_size_mb'       => 8,
);

$folgado = array(
	'max_execution_time'  => 120,
	'memory_limit'        => '512M',
	'memoria_bytes'       => 512 * 1048576,
	'upload_max_filesize' => '64M',
	'upload_bytes'        => 64 * 1048576,
	'post_max_size'       => '64M',
	'post_bytes'          => 64 * 1048576,
);

$veredito = F3Base_Imp_Lotes::veredito_de_limites( $folgado, $piso_declarado );

medir( $nome );

if ( 'OK' !== $veredito['estado'] ) {
	anotar( $nome, 'teto: limites folgados fecharam ' . $veredito['estado'] . ' — medição sem achado adverso precisa fechar OK, senão a linha vira ruído amarelo' );
}

foreach ( array( '120s', '512M', '64M' ) as $valor ) {
	medir( $nome );

	if ( ! contem( $veredito['motivo'], $valor ) ) {
		anotar( $nome, 'teto: o ramo OK não NOMEIA o valor medido "' . $valor . '" — o detalhe não pode sumir junto com o WARN' );
	}
}

medir( $nome );

if ( array() !== $veredito['abaixo'] ) {
	anotar( $nome, 'teto: limites folgados produziram achado — ' . implode( ' | ', $veredito['abaixo'] ) );
}

/* `max_execution_time = 0` é AUSÊNCIA de limite: não pode ser lido como zero. */
$sem_limite            = $folgado;
$sem_limite['max_execution_time'] = 0;
$veredito_sem_limite   = F3Base_Imp_Lotes::veredito_de_limites( $sem_limite, $piso_declarado );

medir( $nome );

if ( 'OK' !== $veredito_sem_limite['estado'] ) {
	anotar( $nome, 'piso do falso positivo: max_execution_time = 0 é ausência de limite e fechou ' . $veredito_sem_limite['estado'] );
}

medir( $nome );

if ( ! contem( $veredito_sem_limite['motivo'], 'sem limite' ) ) {
	anotar( $nome, 'piso do falso positivo: o texto não diz que max_execution_time = 0 é ausência de limite' );
}

/* Cada limite, um a um, abaixo do piso: WARN nomeando QUAL e o custo. */
$apertados = array(
	'max_execution_time' => array( 'campo' => 'max_execution_time', 'valor' => 10, 'agulha' => 'max_execution_time 10s', 'custo' => 'retomada refaz a etapa inteira' ),
	'memoria'            => array( 'campo' => 'memoria_bytes', 'valor' => 32 * 1048576, 'agulha' => 'memory_limit', 'custo' => 'morre sem relatório' ),
	'upload'             => array( 'campo' => 'upload_bytes', 'valor' => 2 * 1048576, 'agulha' => 'upload_max_filesize', 'custo' => 'recusado pelo próprio PHP' ),
	'post'               => array( 'campo' => 'post_bytes', 'valor' => 2 * 1048576, 'agulha' => 'post_max_size', 'custo' => 'não cabe' ),
);

foreach ( $apertados as $rotulo => $caso ) {
	$medido                  = $folgado;
	$medido[ $caso['campo'] ] = $caso['valor'];

	if ( 'memoria_bytes' === $caso['campo'] ) {
		$medido['memory_limit'] = '32M';
	}

	if ( 'upload_bytes' === $caso['campo'] ) {
		$medido['upload_max_filesize'] = '2M';
	}

	if ( 'post_bytes' === $caso['campo'] ) {
		$medido['post_max_size'] = '2M';
	}

	$apertado = F3Base_Imp_Lotes::veredito_de_limites( $medido, $piso_declarado );

	medir( $nome );

	if ( 'WARN' !== $apertado['estado'] ) {
		anotar( $nome, $rotulo . ': limite abaixo do piso declarado fechou ' . $apertado['estado'] . ' em vez de WARN' );
	}

	medir( $nome );

	if ( 1 !== count( $apertado['abaixo'] ) ) {
		anotar( $nome, $rotulo . ': ' . count( $apertado['abaixo'] ) . ' achado(s) onde só um limite ficou abaixo do piso' );
	}

	medir( $nome );

	if ( ! contem( $apertado['motivo'], $caso['agulha'] ) ) {
		anotar( $nome, $rotulo . ': o WARN não NOMEIA qual limite ficou abaixo do piso' );
	}

	medir( $nome );

	if ( ! contem( $apertado['motivo'], $caso['custo'] ) ) {
		anotar( $nome, $rotulo . ': o WARN não diz o que o limite abaixo do piso CUSTA' );
	}
}

/* ---------- conteudo.guarda_de_marca: a declaracao e o arquivo, nos dois lados ---------- */

/*
 * A saída barata que esta guarda fecha: desligar `conteudo.demonstrativo` para
 * calar o aviso e não trocar o conteúdo. Aí a configuração afirma que o texto é
 * do site e o arquivo continua sendo o do template — uma das duas está mentindo,
 * e a que vai ao ar é a errada.
 */

$nome = 'conteudo.guarda_de_marca';

$marca_do_template = F3Base_Imp_Conteudo::marca_demonstrativa( 'f3base' );

medir( $nome );

if ( 'f3base:conteudo-demonstrativo' !== $marca_do_template ) {
	anotar( $nome, 'a marca não é montada a partir do prefixo declarado: veio "' . $marca_do_template . '"' );
}

medir( $nome );

if ( '' !== F3Base_Imp_Conteudo::marca_demonstrativa( '' ) ) {
	anotar( $nome, 'sem prefixo declarado não existe marca a procurar, e a função devolveu uma' );
}

/*
 * A MARCA MUDA COM O PREFIXO, e é isto que impede a marca do template de
 * sobreviver dentro do site do cliente. O prefixo de teste aqui é literal e
 * deliberadamente diferente do declarado: é o outro site da operação.
 */
$outro_prefixo = 'siteb';

medir( $nome );

if ( $outro_prefixo . ':conteudo-demonstrativo' !== F3Base_Imp_Conteudo::marca_demonstrativa( $outro_prefixo ) ) {
	anotar( $nome, 'a marca não acompanha o prefixo do site: dois sites diferentes teriam a mesma marca' );
}

$com_marca = $marca_do_template . " -->\n<!-- wp:heading -->\n<h2>O que é o método</h2>\n";
$sem_marca = "<!-- wp:heading -->\n<h2>Serviços de fundação</h2>\n";

$casos_da_guarda = array(
	'desligado com a marca no arquivo' => array( $com_marca, false, 'f3base', true ),
	'desligado sem a marca'            => array( $sem_marca, false, 'f3base', false ),
	'ligado com a marca'               => array( $com_marca, true, 'f3base', false ),
	'ligado sem a marca'               => array( $sem_marca, true, 'f3base', false ),
	'sem prefixo declarado'            => array( $com_marca, false, '', false ),
	'prefixo trocado'                  => array( $com_marca, false, $outro_prefixo, false ),
);

foreach ( $casos_da_guarda as $rotulo => $caso ) {
	list( $texto, $declarado, $prefixo, $espera_recusa ) = $caso;

	$motivo = F3Base_Imp_Conteudo::guarda_de_marca_demonstrativa( $texto, $declarado, $prefixo, 'content/pages/home.html' );

	medir( $nome );

	if ( $espera_recusa && '' === $motivo ) {
		anotar( $nome, $rotulo . ': a guarda deixou publicar um arquivo que ainda é o do template com a configuração afirmando que não é' );
	}

	medir( $nome );

	if ( ! $espera_recusa && '' !== $motivo ) {
		anotar( $nome, $rotulo . ': a guarda recusou um caso legítimo — ' . $motivo );
	}
}

/* A recusa NOMEIA o arquivo, a marca e as duas saídas: recusa sem caminho de saída é beco. */
$recusa = F3Base_Imp_Conteudo::guarda_de_marca_demonstrativa( $com_marca, false, 'f3base', 'content/pages/home.html' );

foreach ( array( 'content/pages/home.html', 'f3base:conteudo-demonstrativo', 'Troque o conteúdo', 'conteudo.demonstrativo = true' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $recusa, $trecho ) ) {
		anotar( $nome, 'a recusa não traz "' . $trecho . '": ela precisa nomear o arquivo, a marca e as duas saídas' );
	}
}


/* ---------- relatorio.contagem_colada_no_estado: o número diz de quem ele é ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17, na linha do encerramento: `5 em FALHA: nenhum ·
 * BLOCKED: … · WARN: …`. Três coisas erradas de uma vez — o 5 era FALHA MAIS
 * BLOCKED somados, ele encostava no PRIMEIRO estado da string (e quem lê casa
 * número com a primeira palavra, então lia "5 em FALHA" ao lado de "FALHA:
 * nenhum"), e a mesma string ainda listava WARN, que não estava nos cinco.
 *
 * TETO: cada número sai colado ao estado que ele conta.
 * PISO: a forma antiga — soma de dois estados encostada no primeiro — não pode
 * voltar a aparecer.
 */
$nome = 'relatorio.contagem_colada_no_estado';

$contagem_medida = array( 'OK' => 40, 'FALHA' => 0, 'BLOCKED' => 5, 'N/A' => 2, 'WAIVED' => 0, 'WARN' => 1 );
$nomes_medidos   = array(
	'OK'      => array(),
	'FALHA'   => array(),
	'BLOCKED' => array( 'mcp.canal_configurado', 'orcamento.pagina', 'entrega.rodada_limpa', 'origem.rota_carimbada', 'desempenho.core_web_vitals' ),
	'N/A'     => array( 'handoff.pacote_de_entrega', 'formulario.regime_cf7' ),
	'WAIVED'  => array(),
	'WARN'    => array( 'conteudo.demonstrativo' ),
);

$resumo_medido = F3Base_Imp_Relatorio::resumo_por_estado( $contagem_medida, $nomes_medidos );

foreach ( array( 'FALHA: 0', 'BLOCKED: 5', 'WARN: 1' ) as $par ) {
	medir( $nome );

	if ( ! contem( $resumo_medido, $par ) ) {
		anotar( $nome, 'teto: o resumo não traz "' . $par . '" — cada número tem de sair colado ao estado que ele conta' );
	}
}

/* PISO: a soma de FALHA com BLOCKED encostada no primeiro estado não pode existir. */
medir( $nome );

if ( 1 === preg_match( '/\b5\s+em\s+FALHA\b/u', $resumo_medido ) ) {
	anotar( $nome, 'piso: a forma da 1.0.17 voltou — "5 em FALHA: nenhum" com o 5 sendo FALHA mais BLOCKED, encostado no estado errado' );
}

/* PISO: os nomes de WARN não podem viajar dentro do segmento de FALHA nem do de BLOCKED. */
medir( $nome );

$segmento_de_falha = (string) ( explode( '|', $resumo_medido )[1] ?? '' );

if ( contem( $segmento_de_falha, 'conteudo.demonstrativo' ) ) {
	anotar( $nome, 'piso: o nome de uma checagem em WARN apareceu dentro do segmento de FALHA — foi assim que a linha da 1.0.17 listou WARN dentro de uma contagem que não o continha' );
}

/* TETO: OK continua resumido, sem lista de nomes. */
medir( $nome );

if ( ! contem( $resumo_medido, 'OK: 40' ) ) {
	anotar( $nome, 'teto: o resumo deixou de trazer a contagem de OK colada ao estado' );
}

F3Base_Imp_Relatorio::zerar();

/* ---------- lotes.convergencia_terceiro_eixo: execução terminada ≠ estado convergido ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17: o gate consultava BLOCKED de entregável e de
 * canal, e NINGUÉM consultava o BLOCKED de pré-condição declarada.
 * `privacidade.controlador_identificado` e `formulario.contato-whatsapp`
 * fechavam BLOCKED e não entravam em lista nenhuma. O resultado era honesto nos
 * fatos e otimista no nome: SUCESSO_APLICACAO mais autodesativação, com a
 * política em rascunho e o CTA em degradado.
 *
 * TETO: sem pré-condição pendente, convergiu.
 * PISO: BLOCKED de pré-condição declarada torna a convergência PENDENTE e o
 * texto de encerramento diz o que falta e como sair; FALHA de pré-condição não
 * convergiu; e a AUTODESATIVAÇÃO continua amarrada ao gate de aplicação, não à
 * convergência — é a discordância registrada com a auditoria.
 */
$nome = 'lotes.convergencia_terceiro_eixo';

/**
 * Linha de relatório na forma que o veredito de convergência recebe.
 *
 * @param string $checagem   Nome.
 * @param string $estado     Estado fechado.
 * @param bool   $precondicao É pré-condição declarada.
 * @return array<string,mixed>
 */
$linha_de = static function ( string $checagem, string $estado, bool $precondicao ): array {
	return array(
		'nome'        => $checagem,
		'estado'      => $estado,
		'precondicao' => $precondicao,
	);
};

$casos_de_convergencia = array(
	'tudo preenchido' => array(
		array(
			$linha_de( 'privacidade.controlador_identificado', 'OK', true ),
			$linha_de( 'formulario.contato-whatsapp', 'OK', true ),
			$linha_de( 'orcamento.medicao_de_pagina', 'BLOCKED', false ),
		),
		F3Base_Imp_Lotes::CONVERGIU,
		array( 'CONVERGIU' ),
	),
	'controlador em branco' => array(
		array(
			$linha_de( 'privacidade.controlador_identificado', 'BLOCKED', true ),
			$linha_de( 'formulario.contato-whatsapp', 'BLOCKED', true ),
		),
		F3Base_Imp_Lotes::CONVERGENCIA_PENDENTE,
		array( 'PENDENTE', 'privacidade.controlador_identificado', 'formulario.contato-whatsapp', 'Como sair' ),
	),
	'controlador preenchido e errado' => array(
		array(
			$linha_de( 'privacidade.controlador_identificado', 'FALHA', true ),
			$linha_de( 'formulario.contato-whatsapp', 'BLOCKED', true ),
		),
		F3Base_Imp_Lotes::NAO_CONVERGIU,
		array( 'NÃO CONVERGIU', 'privacidade.controlador_identificado' ),
	),
	'BLOCKED que NÃO é pré-condição não move o eixo' => array(
		array(
			$linha_de( 'orcamento.medicao_de_pagina', 'BLOCKED', false ),
			$linha_de( 'entrega.rodada_limpa', 'BLOCKED', false ),
		),
		F3Base_Imp_Lotes::CONVERGIU,
		array( 'CONVERGIU' ),
	),
	'WARN de pré-condição não move o eixo' => array(
		array( $linha_de( 'formulario.contato-whatsapp', 'WARN', true ) ),
		F3Base_Imp_Lotes::CONVERGIU,
		array( 'CONVERGIU' ),
	),
);

foreach ( $casos_de_convergencia as $rotulo => $caso ) {
	$veredito = F3Base_Imp_Lotes::veredito_de_convergencia( $caso[0] );

	medir( $nome );

	if ( $caso[1] !== $veredito['estado'] ) {
		anotar( $nome, $rotulo . ': o eixo fechou ' . $veredito['estado'] . ' e o esperado era ' . $caso[1] );
	}

	foreach ( $caso[2] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $rotulo . ': a mensagem do eixo não traz "' . $trecho . '" — ' . $veredito['motivo'] );
		}
	}
}

/* O ENCERRAMENTO DIZ EM UMA FRASE o que falta e como sair. */
$pendente = F3Base_Imp_Lotes::veredito_de_convergencia(
	array( $linha_de( 'privacidade.controlador_identificado', 'BLOCKED', true ) )
);

$texto_pendente = F3Base_Imp_Lotes::texto_de_encerramento( F3Base_Imp_Lotes::SUCESSO, true, $pendente );

foreach ( array( 'CONVERGÊNCIA PENDENTE', 'privacidade.controlador_identificado', 'config/site.json', 'A autodesativação NÃO espera por isso' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $texto_pendente, $trecho ) ) {
		anotar( $nome, 'o encerramento com convergência pendente não traz "' . $trecho . '"' );
	}
}

/*
 * A DISCORDÂNCIA REGISTRADA, congelada em piso: a autodesativação continua
 * amarrada ao gate de APLICAÇÃO. Amarrá-la à convergência prenderia o pacote a
 * uma espera indefinida — um site cujo operador nunca preenche o controlador
 * ficaria com o implantador ativo para sempre, que é a forma de gate
 * insatisfazível que a 1.0.8 eliminou.
 */
$mapa_convergencia = array();

foreach ( F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao() as $entregavel ) {
	$mapa_convergencia[ $entregavel ] = 'OK';
}

foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
	$mapa_convergencia[ $gate ] = 'OK';
}

medir( $nome );

if ( true !== F3Base_Imp_Entrega::pode_autodesativar( F3Base_Imp_Lotes::SUCESSO, $mapa_convergencia )['pode'] ) {
	anotar( $nome, 'piso da discordância: com o gate de aplicação inteiro em OK, a autodesativação foi recusada — a convergência pendente NÃO pode segurar a ferramenta, ou o pacote fica preso a dado que só o operador tem' );
}

medir( $nome );

if ( ! contem( $texto_pendente, 'SE AUTODESATIVOU' ) ) {
	anotar( $nome, 'piso da discordância: o texto de encerramento com convergência pendente deixou de dizer que o implantador saiu de cena — o eixo relata, não decide' );
}

/* ---------- plugins.autoupdate_alcance_separado: flag e fonte não são o mesmo fato ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17: a etapa gravava `auto_update_plugins` e RELIA A
 * MESMA OPTION para conferir — a flag conferida contra si mesma — e o relatório
 * saía dizendo "atualização automática ligada" sobre nove plugins dos quais
 * CINCO não têm fonte que os alcance. `Update URI`, `update_uri` e
 * `site_transient_update_plugins` não aparecem uma vez no pacote inteiro.
 *
 * TETO: todo mundo com fonte alcançável medida fecha OK.
 * PISO: origem `url`, origem `bundle` e artefato do pacote NÃO podem ser
 * contados como alcançáveis; e alcance que só se decide por rede sai como
 * PENDÊNCIA NOMEADA, nunca como número inventado.
 */
$nome = 'plugins.autoupdate_alcance_separado';

/*
 * OS SLUGS SAEM DA CONFIGURAÇÃO E DO PACOTE, nunca de literal: escrito à mão,
 * este bloco reprovaria o pacote RENOMEADO — que é o único caso em que a regra
 * de prefixo é exercitada de verdade.
 */
$esperado_por_slug = array();

foreach ( F3Base_Imp_Config::lista( 'plugins.instalaveis' ) as $i => $entrada ) {
	unset( $entrada );

	$slug_declarado = (string) F3Base_Imp_Config::obter( 'plugins.instalaveis.' . $i . '.slug', '' );
	$origem_declarada = (string) F3Base_Imp_Config::obter( 'plugins.instalaveis.' . $i . '.origem', '' );

	$esperado_por_slug[ $slug_declarado ] = 'url' === $origem_declarada ? 'sem-fonte' : 'pendente';
}

foreach ( F3Base_Imp_Config::lista( 'plugins.operacionais' ) as $i => $entrada ) {
	unset( $entrada );

	$esperado_por_slug[ (string) F3Base_Imp_Config::obter( 'plugins.operacionais.' . $i . '.slug', '' ) ] = 'pendente';
}

foreach ( F3Base_Imp_Preflight::artefatos_do_pacote() as $artefato ) {
	$esperado_por_slug[ (string) $artefato['slug'] ] = 'sem-fonte';
}

$fontes_medidas = F3Base_Imp_Plugins::fontes_declaradas( array_keys( $esperado_por_slug ) );

$slug_do_servidor = F3Base_Imp_Entrega::slug_por_papel( 'canal-mcp-servidor' );

foreach ( $esperado_por_slug as $slug => $classe ) {
	medir( $nome );

	if ( $classe !== ( $fontes_medidas[ $slug ]['classe'] ?? '' ) ) {
		anotar( $nome, $slug . ': classificado como "' . ( $fontes_medidas[ $slug ]['classe'] ?? 'ausente' ) . '" e o esperado era "' . $classe . '"' );
	}
}

/*
 * O SERVIDOR do canal entra na mesma classe do complemento. `README.md` já
 * ressalvava o complemento e ESQUECIA o servidor, instalado pela MESMA URL — o
 * esquecimento é o achado, e o piso o congela.
 */
medir( $nome );

if ( 'sem-fonte' !== ( $fontes_medidas[ $slug_do_servidor ]['classe'] ?? '' ) ) {
	anotar( $nome, 'piso: o SERVIDOR do canal (' . $slug_do_servidor . ') foi contado como alcançável — ele desce da mesma URL que o complemento, e a ressalva do README esquecia justamente ele' );
}

/* PISO: com pendência de rede, o veredito é BLOCKED e as pendentes saem NOMEADAS. */
$alcance_pendente = F3Base_Imp_Plugins::veredito_de_alcance( $fontes_medidas );

medir( $nome );

if ( 'BLOCKED' !== $alcance_pendente['estado'] ) {
	anotar( $nome, 'piso: alcance que depende de consulta ao WordPress.org fechou ' . $alcance_pendente['estado'] . ' em vez de BLOCKED — decidir sem medir seria inventar número' );
}

foreach ( array( 'PENDÊNCIA NOMEADA', 'SEM FONTE ALCANÇÁVEL', $slug_do_servidor, 'FLAG e FONTE são fatos diferentes' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $alcance_pendente['motivo'], $trecho ) ) {
		anotar( $nome, 'piso: a mensagem do alcance não traz "' . $trecho . '"' );
	}
}

/* PISO: sem pendência e COM plugin sem fonte, o veredito é WARN com o achado adverso. */
$alcance_warn = F3Base_Imp_Plugins::veredito_de_alcance(
	array(
		'wp-mcp-ultimate' => array( 'classe' => 'sem-fonte', 'fonte' => 'origem url' ),
		'algum-plugin'    => array( 'classe' => 'alcanca', 'fonte' => 'wordpress.org respondeu' ),
	)
);

medir( $nome );

if ( 'WARN' !== $alcance_warn['estado'] ) {
	anotar( $nome, 'piso: plugin com a flag ligada e SEM fonte alcançável fechou ' . $alcance_warn['estado'] . ' em vez de WARN — a flag prometendo o que não entrega é achado adverso' );
}

/* TETO: todo mundo com fonte alcançável medida fecha OK. */
$alcance_ok = F3Base_Imp_Plugins::veredito_de_alcance(
	array( 'algum-plugin' => array( 'classe' => 'alcanca', 'fonte' => 'wordpress.org respondeu' ) )
);

medir( $nome );

if ( 'OK' !== $alcance_ok['estado'] ) {
	anotar( $nome, 'teto: todos com fonte alcançável medida fechou ' . $alcance_ok['estado'] );
}

/* PISO do escopo vazio: nada medido não aprova nada. */
medir( $nome );

if ( 'BLOCKED' !== F3Base_Imp_Plugins::veredito_de_alcance( array() )['estado'] ) {
	anotar( $nome, 'piso: escopo vazio aprovou o alcance — o que não foi medido não pode ser aprovado' );
}

/* ---------- mcp.autoteste_veredito: teto e piso do autoteste do canal ---------- */

/*
 * O DEFEITO MEDIDO: `README.md` afirmava que "files/selftest roda na entrega e
 * após toda mudança de PHP ou de hospedagem, com o resultado no relatório", e o
 * pacote inteiro não tinha uma chamada de execução — nem `wp_execute_ability`,
 * nem `rest_do_request`. A afirmação existia, o resultado não.
 *
 * TETO: rota presente que responde 2xx e sem item reprovado fecha OK.
 * PISO: rota AUSENTE fecha BLOCKED e nunca OK; rota que responde reprovando
 * fecha FALHA, que é o que reprova a entrega.
 */
$nome = 'mcp.autoteste_veredito';

/**
 * Monta a resposta de um despacho, na forma que o veredito recebe.
 *
 * @param int                 $codigo Código HTTP.
 * @param array<string,mixed> $corpo  Corpo devolvido.
 * @param bool                $executou Houve despacho.
 * @param string              $erro   Motivo quando não houve.
 * @return array{executou:bool,codigo:int,corpo:array<string,mixed>,erro:string,via:string}
 */
$despacho = static function ( int $codigo, array $corpo, bool $executou = true, string $erro = '' ): array {
	return array(
		'executou' => $executou,
		'codigo'   => $codigo,
		'corpo'    => $corpo,
		'erro'     => $erro,
		'via'      => 'servidor REST interno, rest_do_request( POST /mcp/files/selftest )',
	);
};

$casos_do_autoteste = array(
	'rota ausente' => array(
		false,
		$despacho( 0, array(), false ),
		'BLOCKED',
		array( 'NÃO está registrada', 'nunca OK' ),
	),
	'rota presente e aprovada' => array(
		true,
		$despacho( 200, array( 'ok' => true, 'php_lint' => true ) ),
		'OK',
		array( 'RODOU nesta execução', 'php_lint=true', 'recusa_credencial' ),
	),
	'rota presente e reprovada' => array(
		true,
		$despacho( 200, array( 'ok' => true, 'php_lint' => false ) ),
		'FALHA',
		array( 'REPROVOU', 'php_lint', 'PHP quebrado' ),
	),
	'rota presente com lista de falhas' => array(
		true,
		$despacho( 200, array( 'status' => 'ok', 'falhas' => array( 'lint' ) ) ),
		'FALHA',
		array( 'REPROVOU', 'falhas' ),
	),
	'rota presente com status de erro' => array(
		true,
		$despacho( 200, array( 'status' => 'error' ) ),
		'FALHA',
		array( 'REPROVOU', 'status=error' ),
	),
	'resposta 500' => array(
		true,
		$despacho( 500, array() ),
		'FALHA',
		array( 'código 500', 'o canal dizendo que não funciona' ),
	),
	'recusa por credencial' => array(
		true,
		$despacho( 403, array() ),
		'BLOCKED',
		array( 'RECUSOU o despacho interno', 'não carrega credencial' ),
	),
	'despacho que não aconteceu' => array(
		true,
		$despacho( 0, array(), false, 'nem a Abilities API nem rest_do_request() existem nesta instalação' ),
		'BLOCKED',
		array( 'não chegou a acontecer' ),
	),
);

foreach ( $casos_do_autoteste as $rotulo => $caso ) {
	$veredito = F3Base_Imp_Entrega::veredito_do_autoteste( $caso[0], $caso[1], 'wp-mcp-ultimate-complemento-fator3' );

	medir( $nome );

	if ( $caso[2] !== $veredito['estado'] ) {
		anotar( $nome, $rotulo . ': fechou ' . $veredito['estado'] . ' e o esperado era ' . $caso[2] );
	}

	foreach ( $caso[3] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $rotulo . ': a mensagem não traz "' . $trecho . '" — ' . $veredito['motivo'] );
		}
	}
}

/* O corpo sem campo legível NÃO pode virar afirmação sobre o que não foi lido. */
$sem_campo = F3Base_Imp_Entrega::ler_resultado_do_autoteste( array() );

medir( $nome );

if ( ! $sem_campo['aprovado'] ) {
	anotar( $nome, 'teto: corpo vazio com resposta 2xx foi tratado como reprovação, e a rota respondeu' );
}

medir( $nome );

if ( ! contem( $sem_campo['resumo'], 'sem campo legível' ) ) {
	anotar( $nome, 'teto: o corpo sem campo legível não é declarado como tal — adivinhar o vocabulário do complemento é afirmar o que não foi lido' );
}

/* ---------- plugins.digesto_do_artefato: os três ramos e o do salto ---------- */

/*
 * O DEFEITO MEDIDO NA 1.0.17, reproduzido aqui: os dois plugins do canal descem
 * de `https://github.com/.../raw/main/...zip` — ref MUTÁVEL — e `baixar_artefato()`
 * chamava `download_url()` puro. Nenhum hash conferido e nenhuma revalidação de
 * host depois do redirecionamento: o host era conferido na URL declarada e o
 * corpo vinha de onde a origem mandasse.
 *
 * TETO: declarado e batendo instala; ausente na primeira busca instala fixando.
 * PISO: declarado e divergindo NÃO instala; fixado e divergindo NÃO instala; e
 * um redirecionamento para host fora da lista declarada NÃO baixa.
 */
$nome = 'plugins.digesto_do_artefato';

$digesto_a = str_repeat( 'a', 64 );
$digesto_b = str_repeat( 'b', 64 );

$ramos = array(
	'declarado e batendo'   => array( $digesto_a, $digesto_a, '', true, false, array( 'DECLARADO', $digesto_a ) ),
	'declarado e divergindo' => array( $digesto_a, $digesto_b, '', false, false, array( 'DIVERGENTE', $digesto_a, $digesto_b, 'NADA foi instalado' ) ),
	'ausente e fixando'     => array( '', $digesto_a, '', true, true, array( 'FIXADO', 'NÃO PROTEGE', 'não é verificação de integridade' ) ),
	'fixado e batendo'      => array( '', $digesto_a, $digesto_a, true, false, array( 'FIXADO na primeira observação' ) ),
	'fixado e divergindo'   => array( '', $digesto_b, $digesto_a, false, false, array( 'DIVERGENTE do fixado', $digesto_a, $digesto_b, 'NADA foi instalado' ) ),
	'sem digesto medido'    => array( '', '', '', false, false, array( 'não pôde ser medido' ) ),
);

foreach ( $ramos as $rotulo => $caso ) {
	$veredito = F3Base_Imp_Plugins::veredito_do_digest( $caso[0], $caso[1], $caso[2] );

	medir( $nome );

	if ( $caso[3] !== $veredito['ok'] ) {
		anotar( $nome, $rotulo . ': o veredito devolveu ok=' . var_export( $veredito['ok'], true ) . ' e o esperado era ' . var_export( $caso[3], true ) );
	}

	medir( $nome );

	if ( $caso[4] !== $veredito['fixar'] ) {
		anotar( $nome, $rotulo . ': o veredito devolveu fixar=' . var_export( $veredito['fixar'], true ) . ' e o esperado era ' . var_export( $caso[4], true ) );
	}

	foreach ( $caso[5] as $trecho ) {
		medir( $nome );

		if ( ! contem( $veredito['motivo'], $trecho ) ) {
			anotar( $nome, $rotulo . ': a mensagem não traz "' . $trecho . '" — ' . $veredito['motivo'] );
		}
	}
}

/*
 * A FRONTEIRA DO CONTRATO, congelada em piso. A regra 20 manda instalar sempre a
 * última versão da fonte oficial, sem número de versão declarado e SEM CHECKSUM
 * DE TERCEIRO, e ela vale inteira para o WordPress.org: a URL de lá é
 * por VERSÃO, o artefato muda de propósito a cada atualização, e fixar o digesto
 * ali faria a PRÓXIMA VERSÃO LEGÍTIMA reprovar — o oposto da política. A origem
 * `url` declarada é o caso que a regra não cobre, porque o endereço é uma ref
 * mutável servindo conteúdo diferente sem que nada no site mude.
 */
foreach ( array( 'url' => true, 'wordpress.org' => false, 'fornecedor' => false, 'bundle' => false, '' => false ) as $origem_declarada => $aplica ) {
	medir( $nome );

	if ( $aplica !== F3Base_Imp_Plugins::digesto_se_aplica( (string) $origem_declarada ) ) {
		anotar(
			$nome,
			'origem "' . $origem_declarada . '": a conferência de digesto ' . ( $aplica ? 'deixou de se aplicar' : 'passou a se aplicar' )
				. ' — fixar o digesto de artefato do WordPress.org faz a próxima versão legítima reprovar, e é a regra 20 do contrato que essa fronteira executa'
		);
	}
}

/*
 * A MENSAGEM DO RAMO AUSENTE NÃO PODE MAQUIAR O LIMITE. TOFU que se apresenta
 * como verificação de integridade é pior que nenhuma, porque produz confiança:
 * a mensagem tem de dizer as duas metades, o que protege e o que não protege.
 */
$tofu = F3Base_Imp_Plugins::veredito_do_digest( '', $digesto_a, '' );

foreach ( array( 'O QUE ISSO PROTEGE', 'O QUE ISSO NÃO PROTEGE', 'esta busca' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $tofu['motivo'], $trecho ) ) {
		anotar( $nome, 'o ramo do digesto ausente não diz "' . $trecho . '": fixar na primeira observação sem declarar o limite produz a confiança que ele não sustenta' );
	}
}

/* ---------- plugins.host_revalidado_apos_salto: teto e piso ---------- */

$nome = 'plugins.host_revalidado_apos_salto';

/*
 * A lista de hosts vem da CONFIGURAÇÃO desta base, não de um literal escrito
 * aqui: o piso precisa provar que a recusa acontece contra a lista declarada.
 */
$autorizados = array_map( 'strval', F3Base_Imp_Config::lista( 'plugins.origens_url_autorizadas' ) );

$autorizador = static function ( string $endereco ) use ( $autorizados ): array {
	$host = strtolower( (string) parse_url( $endereco, PHP_URL_HOST ) );

	return array(
		'ok'     => in_array( $host, $autorizados, true ),
		'host'   => $host,
		'motivo' => in_array( $host, $autorizados, true )
			? ''
			: 'host não autorizado: ' . $host . ' não está em plugins.origens_url_autorizadas (' . implode( ', ', $autorizados ) . ').',
	);
};

/**
 * Buscador de mentira: uma tabela de endereço para resposta.
 *
 * @param array<string,array{codigo:int,location:string,erro:string}> $tabela Respostas.
 * @return callable
 */
$buscador = static function ( array $tabela ): callable {
	return static function ( string $endereco ) use ( $tabela ): array {
		return $tabela[ $endereco ] ?? array(
			'codigo'   => 200,
			'location' => '',
			'erro'     => '',
		);
	};
};

$declarada = (string) F3Base_Imp_Config::obter( 'plugins.instalaveis.2.url', '' );
$final_ok  = 'https://' . ( $autorizados[1] ?? 'raw.githubusercontent.com' ) . '/x/main/artefato.zip';
$final_mau = 'https://cdn.exemplo-nao-declarado.test/x/artefato.zip';

/* TETO: a cadeia inteira dentro da lista declarada resolve e devolve o endereço final. */
$boa = F3Base_Imp_Plugins::seguir_redirecionamentos(
	$declarada,
	$buscador( array( $declarada => array( 'codigo' => 302, 'location' => $final_ok, 'erro' => '' ) ) ),
	$autorizador,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( ! $boa['ok'] ) {
	anotar( $nome, 'teto: uma cadeia inteiramente dentro da lista declarada foi recusada — ' . $boa['motivo'] );
}

medir( $nome );

if ( $final_ok !== $boa['url'] ) {
	anotar( $nome, 'teto: o endereço final devolvido não é o do último salto (' . $boa['url'] . ')' );
}

/* PISO: o salto sai da lista declarada e NADA é baixado. */
$ma = F3Base_Imp_Plugins::seguir_redirecionamentos(
	$declarada,
	$buscador( array( $declarada => array( 'codigo' => 302, 'location' => $final_mau, 'erro' => '' ) ) ),
	$autorizador,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( $ma['ok'] ) {
	anotar( $nome, 'piso: o redirecionamento para host FORA de plugins.origens_url_autorizadas foi aceito — conferir o host só na URL declarada deixa a lista valendo para um endereço que ninguém baixa' );
}

foreach ( array( 'REDIRECIONAMENTO', 'não autorizado', 'Nada foi baixado', 'cdn.exemplo-nao-declarado.test' ) as $trecho ) {
	medir( $nome );

	if ( ! contem( $ma['motivo'], $trecho ) ) {
		anotar( $nome, 'piso: a recusa do salto não traz "' . $trecho . '" — ' . $ma['motivo'] );
	}
}

/* PISO: cadeia que não termina não pode virar perseguição sem fim. */
$laco = F3Base_Imp_Plugins::seguir_redirecionamentos(
	$declarada,
	static fn( string $endereco ): array => array( 'codigo' => 302, 'location' => $endereco . '/mais', 'erro' => '' ),
	$autorizador,
	F3Base_Imp_Plugins::SALTOS_MAXIMOS
);

medir( $nome );

if ( $laco['ok'] ) {
	anotar( $nome, 'piso: uma cadeia sem fim foi seguida até o fim — seguir indefinidamente deixa a origem decidir quantas vezes o site a persegue' );
}

medir( $nome );

if ( ! contem( $laco['motivo'], 'passou do teto' ) ) {
	anotar( $nome, 'piso: o abandono da cadeia não nomeia o teto de saltos — ' . $laco['motivo'] );
}

F3Base_Imp_Relatorio::zerar();

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
