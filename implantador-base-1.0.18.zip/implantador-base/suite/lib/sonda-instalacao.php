<?php
/**
 * Sonda da INSTALAÇÃO LIMPA: o piso que a 1.0.15 não tinha.
 *
 * POR QUE ESTA SONDA EXISTE. A 1.0.15 foi instalada num WordPress recém-criado
 * e reprovou com duas linhas que se contradiziam dentro da mesma rodada:
 *
 *     FALHA tema      o tema não apareceu no disco depois da instalação.
 *     FALHA site_core o site-core não apareceu no disco depois da instalação.
 *
 * e, três linhas abaixo, a unidade de auto-update enumerando
 * `f3base-site-core 1.0.0` entre os plugins instalados. O diretório estava no
 * disco; quem não o enxergava era a API do WordPress, porque a etapa havia
 * consultado o estado ANTES da troca — numa instalação limpa isso memoriza o
 * NEGATIVO na mesma requisição — e `trocar_diretorio()`, que não passa pelo
 * upgrader do núcleo, não derrubava o cache depois de mover o diretório.
 *
 * A LIÇÃO, e é ela que dita o desenho desta sonda: a checagem atravessou quinze
 * releases sem nunca ter sido exercitada no caminho que importa, porque toda
 * execução de produção anterior rodou em site que JÁ TINHA tema e site-core
 * instalados. Ali a consulta prévia memorizava o POSITIVO e a leitura de volta
 * passava por acidente. Piso que só exercita alvo existente é o piso que deixou
 * isto passar quinze vezes.
 *
 * ENTÃO A BANCADA REPRODUZ O CASO, não o contorna:
 *
 * 1. Um WordPress de mentira cujo cache MEMORIZA O NEGATIVO, como o de verdade:
 *    `wp_get_theme()` responde da varredura guardada, `get_plugins()` responde
 *    da lista guardada, e a lista só cai quando alguém chama
 *    `wp_clean_themes_cache()` / `wp_clean_plugins_cache()` — que é exatamente
 *    o que `Theme_Upgrader::install()` e `Plugin_Upgrader::install()` fazem e
 *    `trocar_diretorio()` não fazia.
 * 2. O diretório de destino COMEÇA INEXISTENTE, e a consulta prévia acontece
 *    antes da troca, na mesma "requisição".
 * 3. A troca é a função REAL do pacote — `aplicar_tema()` e
 *    `aplicar_site_core()`, com o tema e o site-core REAIS de `fontes/`.
 * 4. A invalidação é um INTERRUPTOR da bancada. Desligada, a leitura de volta
 *    tem de continuar cega: é assim que se prova que a bancada reproduz o
 *    defeito de verdade, em vez de aprovar por não ter cache nenhum. Ligada, a
 *    leitura de volta tem de enxergar o artefato.
 * 5. E a ORDEM é medida: a invalidação precisa acontecer ENTRE a consulta
 *    prévia e a leitura de volta. O registro de eventos da bancada guarda cada
 *    leitura e cada limpeza, e a asserção lê essa fita.
 *
 * Subprocesso por desenho, como as outras sondas: carregar as classes do
 * implantador define ABSPATH e um punhado de funções do núcleo, e isso não pode
 * vazar para o processo que imprime os estados.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'instalacao.limpa_le_de_volta' => array( 'achados' => array( 'raiz inexistente' ), 'medidas' => 0 ) ) );
	exit( 2 );
}

$sandbox = sys_get_temp_dir() . '/f3base-sonda-instalacao-' . getmypid();

/*
 * A RAIZ DO WORDPRESS fica FORA do sandbox que é zerado entre cenários: o
 * pacote faz `require_once ABSPATH . 'wp-admin/includes/file.php'`, e
 * `require_once` guarda o caminho já carregado — apagá-lo entre cenários
 * deixaria a segunda inclusão silenciosamente sem arquivo.
 */
$abspath = sys_get_temp_dir() . '/f3base-sonda-instalacao-' . getmypid() . '-wp/';

if ( ! is_dir( $abspath . 'wp-admin/includes' ) ) {
	mkdir( $abspath . 'wp-admin/includes', 0777, true );
}

foreach ( array( 'file.php', 'misc.php', 'plugin.php', 'class-wp-upgrader.php' ) as $stub_do_nucleo ) {
	file_put_contents( $abspath . 'wp-admin/includes/' . $stub_do_nucleo, "<?php
" );
}

define( 'ABSPATH', $abspath );
define( 'WP_PLUGIN_DIR', $sandbox . '/wp-content/plugins' );
define( 'F3BASE_IMP_DIR', $raiz . '/' );
define( 'F3BASE_IMP_ARQUIVO', $raiz . '/implantador-base.php' );
define( 'F3BASE_IMP_TEXT_DOMAIN', 'f3base' );

/**
 * ESTADO DA BANCADA: caches, interruptor de invalidação e fita de eventos.
 *
 * @var array<string,mixed>
 */
$GLOBALS['f3b_wp'] = array(
	'temas'       => null,
	'plugins'     => null,
	'invalidacao' => true,
	'stylesheet'  => 'twentytwentyfour',
	'options'     => array(),
	'ativos'      => array(),
	'fita'        => array(),
);

/**
 * Anota um evento na fita da bancada.
 *
 * @param string $evento Evento.
 * @return void
 */
function f3b_fita( string $evento ): void {
	$GLOBALS['f3b_wp']['fita'][] = $evento;
}

/* ---------------------------------------------------------------------- *
 * Núcleo de mentira: só o que as funções medidas de fato chamam.
 * ---------------------------------------------------------------------- */

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Escape de saída do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function esc_html( string $texto ): string {
	return htmlspecialchars( $texto, ENT_QUOTES );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * Desserialização tolerante do núcleo.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function maybe_unserialize( $valor ) {
	return $valor;
}

/**
 * Serialização do núcleo.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function maybe_serialize( $valor ) {
	return is_array( $valor ) || is_object( $valor ) ? serialize( $valor ) : $valor;
}

/**
 * Barra final.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function trailingslashit( string $caminho ): string {
	return rtrim( $caminho, '/\\' ) . '/';
}

/**
 * Chave sanitizada.
 *
 * @param string $chave Chave.
 * @return string
 */
function sanitize_key( string $chave ): string {
	return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $chave ) ) ?? '';
}

/**
 * Texto sanitizado.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_text_field( string $texto ): string {
	return trim( strip_tags( $texto ) );
}

/**
 * Inteiro absoluto.
 *
 * @param mixed $valor Valor.
 * @return int
 */
function absint( $valor ): int {
	return abs( (int) $valor );
}

/**
 * Data formatada no fuso do site.
 *
 * @param string   $formato Formato.
 * @param int|null $quando  Epoch.
 * @return string
 */
function wp_date( string $formato, ?int $quando = null ): string {
	return gmdate( $formato, null === $quando ? time() : $quando );
}

/**
 * Caminho dentro do pacote, com a mesma guarda de travessia do implantador.
 *
 * @param string $relativo Caminho relativo.
 * @return string
 */
function f3base_imp_caminho( string $relativo ): string {
	$base = rtrim( F3BASE_IMP_DIR, '/' ) . '/';

	if ( '' === $relativo || str_contains( $relativo, '../' ) ) {
		return '';
	}

	$candidato = $base . ltrim( $relativo, '/' );
	$real      = realpath( $candidato );

	if ( false === $real ) {
		return $candidato;
	}

	return str_starts_with( $real, $base ) ? $real : '';
}

/**
 * Caminho relativo do arquivo principal, como o núcleo o produz.
 *
 * @param string $arquivo Caminho absoluto.
 * @return string
 */
function plugin_basename( string $arquivo ): string {
	return basename( dirname( $arquivo ) ) . '/' . basename( $arquivo );
}

/* ---------- options ---------- */

/**
 * Lê uma option da bancada.
 *
 * @param string $nome    Nome.
 * @param mixed  $padrao  Padrão.
 * @return mixed
 */
function get_option( string $nome, $padrao = false ) {
	return array_key_exists( $nome, $GLOBALS['f3b_wp']['options'] ) ? $GLOBALS['f3b_wp']['options'][ $nome ] : $padrao;
}

/*
 * A BANCADA NÃO ESCREVE OPTION, e isso é decisão, não esquecimento. Um núcleo
 * de mentira que definisse `update_option()`, `add_option()` e
 * `delete_option()` poria três escritas diretas de option dentro do pacote, e
 * `estatica.detector_escrita_unica` — que varre o pacote INTEIRO, a suíte
 * inclusive — as acusaria com razão: a regra é do caminho único de escrita, e
 * não abre exceção para arquivo de teste. O journal e o gravador entram como
 * dublês declarados logo abaixo, e o que está sob medição aqui é a troca de
 * diretório, não a camada de options — essa já tem sonda própria.
 */

/**
 * Criação recursiva de diretório.
 *
 * @param string $caminho Caminho.
 * @return bool
 */
function wp_mkdir_p( string $caminho ): bool {
	return is_dir( $caminho ) || mkdir( $caminho, 0777, true );
}

/* ---------- TEMAS: a varredura que MEMORIZA O NEGATIVO ---------- */

/**
 * Raiz de temas da bancada.
 *
 * @return string
 */
function get_theme_root(): string {
	return dirname( WP_PLUGIN_DIR ) . '/themes';
}

/**
 * Um tema como o núcleo o devolve, com o mínimo que o pacote consulta.
 */
final class F3Base_Sonda_Tema {

	/**
	 * Existe no disco, segundo a VARREDURA GUARDADA.
	 *
	 * @var bool
	 */
	private bool $existe;

	/**
	 * Versão do cabeçalho.
	 *
	 * @var string
	 */
	private string $versao;

	/**
	 * Monta a partir do que a varredura guardada diz.
	 *
	 * @param bool   $existe Existe.
	 * @param string $versao Versão.
	 */
	public function __construct( bool $existe, string $versao ) {
		$this->existe = $existe;
		$this->versao = $versao;
	}

	/**
	 * O tema existe?
	 *
	 * @return bool
	 */
	public function exists(): bool {
		return $this->existe;
	}

	/**
	 * Erros do tema.
	 *
	 * @return false
	 */
	public function errors() {
		return false;
	}

	/**
	 * Cabeçalho.
	 *
	 * @param string $campo Campo.
	 * @return string
	 */
	public function get( string $campo ): string {
		return 'Version' === $campo ? $this->versao : '';
	}
}

/**
 * A VARREDURA DE DIRETÓRIOS DE TEMA, memorizada como no núcleo.
 *
 * `search_theme_directories()` guarda o resultado numa estática e só refaz a
 * varredura com `$force = true`, que é o que `wp_clean_themes_cache()` passa.
 * Numa instalação limpa a primeira chamada guarda uma lista SEM o nosso tema, e
 * é essa lista que a leitura de volta relê.
 *
 * @return array<string,string> Slug => versão.
 */
function f3b_varredura_de_temas(): array {
	if ( null !== $GLOBALS['f3b_wp']['temas'] ) {
		f3b_fita( 'leu:temas(cache)' );

		return $GLOBALS['f3b_wp']['temas'];
	}

	f3b_fita( 'leu:temas(disco)' );

	$achados = array();

	foreach ( glob( get_theme_root() . '/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
		$style = $dir . '/style.css';

		if ( ! is_file( $style ) ) {
			continue;
		}

		$versao = '';

		if ( 1 === preg_match( '/^[\s*#]*Version:\s*(.+)$/mi', (string) file_get_contents( $style ), $m ) ) {
			$versao = trim( $m[1] );
		}

		$achados[ basename( $dir ) ] = $versao;
	}

	$GLOBALS['f3b_wp']['temas'] = $achados;

	return $achados;
}

/**
 * `wp_get_theme()` da bancada: responde da varredura guardada.
 *
 * @param string $slug Slug.
 * @return F3Base_Sonda_Tema
 */
function wp_get_theme( string $slug = '' ): F3Base_Sonda_Tema {
	$temas = f3b_varredura_de_temas();

	return new F3Base_Sonda_Tema( isset( $temas[ $slug ] ), (string) ( $temas[ $slug ] ?? '' ) );
}

/**
 * Derruba a varredura guardada de temas — se a bancada permitir.
 *
 * O interruptor é o coração do piso: DESLIGADO, esta função não faz nada e a
 * leitura de volta continua cega, que é a 1.0.15 reproduzida.
 *
 * @param bool $lote Em lote.
 * @return void
 */
function wp_clean_themes_cache( bool $lote = true ): void {
	if ( ! $GLOBALS['f3b_wp']['invalidacao'] ) {
		f3b_fita( 'limpou:temas(inerte)' );

		return;
	}

	f3b_fita( 'limpou:temas' );

	$GLOBALS['f3b_wp']['temas'] = null;
}

/**
 * Tema ativo.
 *
 * @return string
 */
function get_stylesheet(): string {
	return (string) $GLOBALS['f3b_wp']['stylesheet'];
}

/**
 * Troca o tema ativo.
 *
 * @param string $slug Slug.
 * @return void
 */
function switch_theme( string $slug ): void {
	$GLOBALS['f3b_wp']['stylesheet'] = $slug;
}

/* ---------- PLUGINS: a lista que MEMORIZA O NEGATIVO ---------- */

/**
 * `get_plugins()` da bancada: responde da lista guardada.
 *
 * @return array<string,array<string,string>>
 */
function get_plugins(): array {
	if ( null !== $GLOBALS['f3b_wp']['plugins'] ) {
		f3b_fita( 'leu:plugins(cache)' );

		return $GLOBALS['f3b_wp']['plugins'];
	}

	f3b_fita( 'leu:plugins(disco)' );

	$achados = array();

	foreach ( glob( WP_PLUGIN_DIR . '/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
		foreach ( glob( $dir . '/*.php' ) ?: array() as $arquivo ) {
			$cabecalho = (string) file_get_contents( $arquivo );

			if ( 1 !== preg_match( '/^[\s*#]*Plugin Name:\s*(.+)$/mi', $cabecalho, $nome ) ) {
				continue;
			}

			$versao = '';

			if ( 1 === preg_match( '/^[\s*#]*Version:\s*(.+)$/mi', $cabecalho, $v ) ) {
				$versao = trim( $v[1] );
			}

			$achados[ basename( $dir ) . '/' . basename( $arquivo ) ] = array(
				'Name'    => trim( $nome[1] ),
				'Version' => $versao,
			);
		}
	}

	$GLOBALS['f3b_wp']['plugins'] = $achados;

	return $achados;
}

/**
 * Derruba a lista guardada de plugins — se a bancada permitir.
 *
 * @param bool $lote Em lote.
 * @return void
 */
function wp_clean_plugins_cache( bool $lote = true ): void {
	if ( ! $GLOBALS['f3b_wp']['invalidacao'] ) {
		f3b_fita( 'limpou:plugins(inerte)' );

		return;
	}

	f3b_fita( 'limpou:plugins' );

	$GLOBALS['f3b_wp']['plugins'] = null;
}

/**
 * O plugin está ativo?
 *
 * @param string $arquivo Arquivo principal relativo.
 * @return bool
 */
function is_plugin_active( string $arquivo ): bool {
	return in_array( $arquivo, $GLOBALS['f3b_wp']['ativos'], true );
}

/**
 * Ativa um plugin.
 *
 * @param string $arquivo Arquivo principal relativo.
 * @return null
 */
function activate_plugin( string $arquivo ) {
	$GLOBALS['f3b_wp']['ativos'][] = $arquivo;

	return null;
}

/* ---------- filesystem ---------- */

/**
 * Erro do núcleo.
 */
class WP_Error {

	/**
	 * Mensagem.
	 *
	 * @var string
	 */
	private string $mensagem;

	/**
	 * Monta.
	 *
	 * @param string $codigo   Código.
	 * @param string $mensagem Mensagem.
	 */
	public function __construct( string $codigo = '', string $mensagem = '' ) {
		$this->mensagem = $mensagem;
	}

	/**
	 * Mensagem.
	 *
	 * @return string
	 */
	public function get_error_message(): string {
		return $this->mensagem;
	}
}

/**
 * É erro?
 *
 * @param mixed $valor Valor.
 * @return bool
 */
function is_wp_error( $valor ): bool {
	return $valor instanceof WP_Error;
}

/**
 * Filesystem do núcleo, com o mínimo que a troca de diretório usa.
 */
class WP_Filesystem_Base {

	/**
	 * Cria diretório.
	 *
	 * @param string $caminho Caminho.
	 * @return bool
	 */
	public function mkdir( string $caminho ): bool {
		return is_dir( $caminho ) || mkdir( $caminho, 0777, true );
	}

	/**
	 * Move.
	 *
	 * @param string $origem     Origem.
	 * @param string $destino    Destino.
	 * @param bool   $sobrescrever Sobrescrever.
	 * @return bool
	 */
	public function move( string $origem, string $destino, bool $sobrescrever = false ): bool {
		if ( $sobrescrever && is_dir( $destino ) ) {
			$this->delete( $destino, true );
		}

		return rename( $origem, $destino );
	}

	/**
	 * Apaga.
	 *
	 * @param string $caminho    Caminho.
	 * @param bool   $recursivo  Recursivo.
	 * @return bool
	 */
	public function delete( string $caminho, bool $recursivo = false ): bool {
		if ( is_file( $caminho ) ) {
			return unlink( $caminho );
		}

		if ( ! is_dir( $caminho ) ) {
			return false;
		}

		foreach ( scandir( $caminho ) ?: array() as $item ) {
			if ( '.' === $item || '..' === $item ) {
				continue;
			}

			$this->delete( $caminho . '/' . $item, true );
		}

		return rmdir( $caminho );
	}
}

/**
 * Inicializa o filesystem global.
 *
 * @return bool
 */
function WP_Filesystem(): bool { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid -- nome do núcleo.
	global $wp_filesystem;

	if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
		$wp_filesystem = new WP_Filesystem_Base();
	}

	return true;
}

/**
 * Cópia recursiva do núcleo.
 *
 * @param string $origem  Origem.
 * @param string $destino Destino.
 * @return bool
 */
function copy_dir( string $origem, string $destino ): bool {
	if ( ! is_dir( $origem ) ) {
		return false;
	}

	if ( ! is_dir( $destino ) && ! mkdir( $destino, 0777, true ) ) {
		return false;
	}

	foreach ( scandir( $origem ) ?: array() as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}

		$de   = $origem . '/' . $item;
		$para = $destino . '/' . $item;

		if ( is_dir( $de ) ) {
			copy_dir( $de, $para );
			continue;
		}

		copy( $de, $para );
	}

	return true;
}

/**
 * DUBLÊ do gravador: só o que a troca de diretório chama.
 *
 * O gravador de verdade é ponto único de escrita de option e já tem sonda
 * própria (`sonda-gravador.php`). Carregá-lo aqui obrigaria a bancada a definir
 * `update_option()`, e escrita direta de option dentro do pacote é achado —
 * inclusive na suíte.
 */
final class F3Base_Imp_Gravador {

	/**
	 * Modo simulação.
	 *
	 * @var bool
	 */
	private static bool $simulacao = false;

	/**
	 * Liga ou desliga a simulação.
	 *
	 * @param bool $ligado Ligado.
	 * @return void
	 */
	public static function simulacao( bool $ligado ): void {
		self::$simulacao = $ligado;
	}

	/**
	 * Está em simulação?
	 *
	 * @return bool
	 */
	public static function em_simulacao(): bool {
		return self::$simulacao;
	}

	/**
	 * Diretório de trabalho da troca.
	 *
	 * @param string $sub Subdiretório.
	 * @return string
	 */
	public static function diretorio_trabalho( string $sub = '' ): string {
		$base = dirname( WP_PLUGIN_DIR ) . '/uploads/f3base-implantador/' . ( '' === $sub ? '' : $sub . '/' );

		wp_mkdir_p( $base );

		return $base;
	}
}

/**
 * DUBLÊ do journal: registra em memória, para a troca poder registrar a preimagem.
 */
final class F3Base_Imp_Journal {

	public const TIPO_OPTION  = 'option';
	public const TIPO_ARQUIVO = 'arquivo';

	/**
	 * Entradas registradas nesta sonda.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	private static array $entradas = array();

	/**
	 * Inicia a execução.
	 *
	 * @param string $execucao Execução.
	 * @return void
	 */
	public static function iniciar( string $execucao ): void {
		unset( $execucao );

		self::$entradas = array();
	}

	/**
	 * Carimba a etapa.
	 *
	 * @param string $etapa Etapa.
	 * @return void
	 */
	public static function etapa( string $etapa ): void {
		unset( $etapa );
	}

	/**
	 * Registra uma mutação.
	 *
	 * @param string              $tipo      Tipo.
	 * @param string              $alvo      Alvo.
	 * @param mixed               $preimagem Preimagem.
	 * @param mixed               $posimagem Pós-imagem.
	 * @param array<string,mixed> $inversa   Inversa.
	 * @param array<string,mixed> $extra     Extra.
	 * @return string
	 */
	public static function registrar( string $tipo, string $alvo, $preimagem, $posimagem, array $inversa, array $extra = array() ): string {
		unset( $preimagem, $posimagem, $inversa, $extra );

		self::$entradas[] = array(
			'tipo' => $tipo,
			'alvo' => $alvo,
		);

		return 'sonda-' . str_pad( (string) count( self::$entradas ), 4, '0', STR_PAD_LEFT );
	}

	/**
	 * Entradas registradas.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function entradas(): array {
		return self::$entradas;
	}
}

require $raiz . '/includes/class-f3base-imp-config.php';
require $raiz . '/includes/class-f3base-imp-relatorio.php';
require $raiz . '/includes/class-f3base-imp-preflight.php';
require $raiz . '/includes/class-f3base-imp-plugins.php';

$resultado = array();

/**
 * Acumula um achado.
 *
 * @param string $checagem Nome.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]              = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Registra uma medida.
 *
 * @param string $checagem Nome.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array( 'achados' => array(), 'medidas' => 0 );
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Afirma, medindo.
 *
 * @param string $checagem Nome.
 * @param bool   $condicao Condição observada.
 * @param string $falhou   Frase do ramo adverso.
 * @return void
 */
function afirmar( string $checagem, bool $condicao, string $falhou ): void {
	medir( $checagem );

	if ( ! $condicao ) {
		anotar( $checagem, $falhou );
	}
}

/**
 * Contém, sem depender de caixa.
 *
 * @param string $palheiro Texto medido.
 * @param string $agulha   Trecho.
 * @return bool
 */
function contem( string $palheiro, string $agulha ): bool {
	return '' !== $agulha && false !== stripos( $palheiro, $agulha );
}

/**
 * Apaga uma árvore inteira.
 *
 * @param string $dir Diretório.
 * @return void
 */
function f3b_apagar_arvore( string $dir ): void {
	if ( ! is_dir( $dir ) ) {
		return;
	}

	foreach ( scandir( $dir ) ?: array() as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}

		$caminho = $dir . '/' . $item;

		if ( is_dir( $caminho ) ) {
			f3b_apagar_arvore( $caminho );
			continue;
		}

		unlink( $caminho );
	}

	rmdir( $dir );
}

/**
 * INSTALAÇÃO RECÉM-CRIADA: sandbox zerado, caches zerados, nenhum artefato.
 *
 * @param string $sandbox     Raiz do sandbox.
 * @param bool   $invalidacao Interruptor da invalidação de cache.
 * @return void
 */
function f3b_instalacao_limpa( string $sandbox, bool $invalidacao ): void {
	f3b_apagar_arvore( $sandbox );

	foreach ( array( '/wp-content/plugins', '/wp-content/themes', '/wp-content/uploads' ) as $sub ) {
		mkdir( $sandbox . $sub, 0777, true );
	}

	$GLOBALS['f3b_wp']['temas']       = null;
	$GLOBALS['f3b_wp']['plugins']     = null;
	$GLOBALS['f3b_wp']['invalidacao'] = $invalidacao;
	$GLOBALS['f3b_wp']['stylesheet']  = 'twentytwentyfour';
	$GLOBALS['f3b_wp']['options']     = array();
	$GLOBALS['f3b_wp']['ativos']      = array();
	$GLOBALS['f3b_wp']['fita']        = array();
}

F3Base_Imp_Config::carregar();
F3Base_Imp_Gravador::simulacao( false );
F3Base_Imp_Journal::iniciar( 'sonda' );

$tema_slug  = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );
$core_slug  = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );
$dir_tema   = get_theme_root() . '/' . $tema_slug;
$dir_core   = WP_PLUGIN_DIR . '/' . $core_slug;

/* =======================================================================
 * instalacao.limpa_le_de_volta
 * ==================================================================== */

$nome = 'instalacao.limpa_le_de_volta';

/* ---------- TEMA, PISO: a 1.0.15 reproduzida (invalidação DESLIGADA) ---------- */

f3b_instalacao_limpa( $sandbox, false );

afirmar( $nome, '' !== $tema_slug, 'piso do tema: site.tema_slug vazio — não há alvo a instalar' );
afirmar( $nome, ! is_dir( $dir_tema ), 'piso do tema: o alvo já existia antes da troca; este piso EXIGE alvo inexistente, que é o caso que passou quinze releases sem ser exercitado' );

/* A CONSULTA PRÉVIA, na mesma "requisição": é ela que memoriza o negativo. */
afirmar( $nome, false === wp_get_theme( $tema_slug )->exists(), 'piso do tema: a consulta prévia devia dizer que o tema NÃO existe numa instalação limpa' );

$saida_tema_cego = F3Base_Imp_Plugins::aplicar_tema();

afirmar( $nome, is_dir( $dir_tema ), 'piso do tema: a troca de diretório não colocou o tema no disco — sem isso o resto do piso não mede nada' );
afirmar( $nome, is_file( $dir_tema . '/style.css' ), 'piso do tema: o diretório trocado não tem style.css' );
afirmar( $nome, false === wp_get_theme( $tema_slug )->exists(), 'piso do tema: sem invalidação, a API DEVERIA continuar cega — a bancada não está reproduzindo o cache negativo, e um teto medido sobre ela não provaria nada' );
afirmar( $nome, 'FALHA' === $saida_tema_cego['estado'], 'piso do tema: com a API cega a unidade tinha de fechar FALHA, e fechou ' . (string) $saida_tema_cego['estado'] );
afirmar( $nome, contem( (string) $saida_tema_cego['motivo'], 'DEFEITO DE CACHE' ), 'piso do tema: a mensagem não nomeia o defeito de cache — ' . (string) $saida_tema_cego['motivo'] );
afirmar( $nome, ! contem( (string) $saida_tema_cego['motivo'], 'não apareceu no disco' ), 'piso do tema: a mensagem diz "não apareceu no disco" sobre um diretório que ESTÁ no disco, que é o defeito de relatório da 1.0.15' );

/* ---------- TEMA, TETO: a mesma instalação limpa com a 1.0.16 ---------- */

f3b_instalacao_limpa( $sandbox, true );

afirmar( $nome, ! is_dir( $dir_tema ), 'teto do tema: o sandbox não zerou entre os cenários' );
afirmar( $nome, false === wp_get_theme( $tema_slug )->exists(), 'teto do tema: a consulta prévia devia memorizar o negativo, como na instalação limpa real' );

$saida_tema = F3Base_Imp_Plugins::aplicar_tema();

afirmar( $nome, true === wp_get_theme( $tema_slug )->exists(), 'teto do tema: a leitura de volta NÃO enxergou o tema depois da troca — a invalidação não aconteceu' );
afirmar( $nome, 'OK' === $saida_tema['estado'], 'teto do tema: instalação limpa devia fechar OK, e fechou ' . (string) $saida_tema['estado'] . ' — ' . (string) $saida_tema['motivo'] );
afirmar( $nome, ! contem( (string) $saida_tema['motivo'], 'não apareceu no disco' ), 'teto do tema: a mensagem de disco apareceu num caso que deu certo' );
afirmar( $nome, ! contem( (string) $saida_tema['motivo'], 'DEFEITO DE CACHE' ), 'teto do tema: a mensagem de cache apareceu num caso que deu certo' );
afirmar( $nome, get_stylesheet() === $tema_slug, 'teto do tema: o tema instalado não ficou ativo' );

/* A ORDEM: a limpeza precisa acontecer ENTRE a consulta prévia e a leitura de volta. */
$fita        = $GLOBALS['f3b_wp']['fita'];
$pos_limpeza = array_search( 'limpou:temas', $fita, true );
$pos_leitura = false === $pos_limpeza ? false : null;

if ( false !== $pos_limpeza ) {
	$pos_leitura = false;

	foreach ( $fita as $indice => $evento ) {
		if ( $indice > (int) $pos_limpeza && 'leu:temas(disco)' === $evento ) {
			$pos_leitura = $indice;
			break;
		}
	}
}

afirmar( $nome, false !== $pos_limpeza, 'teto do tema: nenhuma invalidação de cache de tema aconteceu na troca — fita: ' . implode( ' → ', $fita ) );
afirmar( $nome, false !== $pos_leitura && null !== $pos_leitura, 'teto do tema: nenhuma leitura de disco depois da invalidação — a leitura de volta respondeu do cache velho. Fita: ' . implode( ' → ', $fita ) );
afirmar( $nome, in_array( 'leu:temas(disco)', array_slice( $fita, 0, false === $pos_limpeza ? 0 : (int) $pos_limpeza ), true ), 'teto do tema: a consulta prévia não chegou a ler o disco antes da invalidação — o piso não reproduziu a ordem da instalação limpa' );

/* ---------- SITE-CORE, PISO: a 1.0.15 reproduzida ---------- */

f3b_instalacao_limpa( $sandbox, false );

afirmar( $nome, '' !== $core_slug, 'piso do site-core: site.site_core_slug vazio — não há alvo a instalar' );
afirmar( $nome, ! is_dir( $dir_core ), 'piso do site-core: o alvo já existia antes da troca; este piso EXIGE alvo inexistente' );
afirmar( $nome, '' === F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'piso do site-core: a consulta prévia devia dizer que o plugin NÃO está instalado numa instalação limpa' );

$saida_core_cego = F3Base_Imp_Plugins::aplicar_site_core();

afirmar( $nome, is_dir( $dir_core ), 'piso do site-core: a troca de diretório não colocou o plugin no disco' );
afirmar( $nome, array() !== ( glob( $dir_core . '/*.php' ) ?: array() ), 'piso do site-core: o diretório trocado não tem arquivo PHP principal' );
afirmar( $nome, '' === F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'piso do site-core: sem invalidação, get_plugins() DEVERIA continuar cego — a bancada não está reproduzindo o cache negativo' );
afirmar( $nome, 'FALHA' === $saida_core_cego['estado'], 'piso do site-core: com a API cega a unidade tinha de fechar FALHA, e fechou ' . (string) $saida_core_cego['estado'] );
afirmar( $nome, contem( (string) $saida_core_cego['motivo'], 'DEFEITO DE CACHE' ), 'piso do site-core: a mensagem não nomeia o defeito de cache — ' . (string) $saida_core_cego['motivo'] );
afirmar( $nome, ! contem( (string) $saida_core_cego['motivo'], 'não apareceu no disco' ), 'piso do site-core: a mensagem diz "não apareceu no disco" sobre um diretório que ESTÁ no disco' );

/* ---------- SITE-CORE, TETO: a mesma instalação limpa com a 1.0.16 ---------- */

f3b_instalacao_limpa( $sandbox, true );

afirmar( $nome, ! is_dir( $dir_core ), 'teto do site-core: o sandbox não zerou entre os cenários' );
afirmar( $nome, '' === F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'teto do site-core: a consulta prévia devia memorizar o negativo' );

$saida_core = F3Base_Imp_Plugins::aplicar_site_core();

afirmar( $nome, '' !== F3Base_Imp_Plugins::versao_instalada( $core_slug ), 'teto do site-core: a leitura de volta NÃO enxergou o plugin depois da troca — a invalidação não aconteceu' );
afirmar( $nome, 'OK' === $saida_core['estado'], 'teto do site-core: instalação limpa devia fechar OK, e fechou ' . (string) $saida_core['estado'] . ' — ' . (string) $saida_core['motivo'] );
afirmar( $nome, ! contem( (string) $saida_core['motivo'], 'não apareceu no disco' ), 'teto do site-core: a mensagem de disco apareceu num caso que deu certo' );
afirmar( $nome, ! contem( (string) $saida_core['motivo'], 'DEFEITO DE CACHE' ), 'teto do site-core: a mensagem de cache apareceu num caso que deu certo' );

$fita_core   = $GLOBALS['f3b_wp']['fita'];
$limpou_core = array_search( 'limpou:plugins', $fita_core, true );
$releu_core  = false;

if ( false !== $limpou_core ) {
	foreach ( $fita_core as $indice => $evento ) {
		if ( $indice > (int) $limpou_core && 'leu:plugins(disco)' === $evento ) {
			$releu_core = true;
			break;
		}
	}
}

afirmar( $nome, false !== $limpou_core, 'teto do site-core: nenhuma invalidação de cache de plugin aconteceu na troca — fita: ' . implode( ' → ', $fita_core ) );
afirmar( $nome, $releu_core, 'teto do site-core: nenhuma leitura de disco depois da invalidação — a leitura de volta respondeu do cache velho. Fita: ' . implode( ' → ', $fita_core ) );
afirmar( $nome, in_array( 'leu:plugins(disco)', array_slice( $fita_core, 0, false === $limpou_core ? 0 : (int) $limpou_core ), true ), 'teto do site-core: a consulta prévia não chegou a ler o disco antes da invalidação' );

/* =======================================================================
 * instalacao.disco_ou_cache — a tabela inteira do discriminante
 * ==================================================================== */

$nome = 'instalacao.disco_ou_cache';

f3b_instalacao_limpa( $sandbox, true );

$presente_tema = get_theme_root() . '/presente';
$incompleto    = get_theme_root() . '/incompleto';
$presente_plug = WP_PLUGIN_DIR . '/presente';
$incomplet_plug = WP_PLUGIN_DIR . '/incompleto';

mkdir( $presente_tema, 0777, true );
file_put_contents( $presente_tema . '/style.css', "/*\nTheme Name: Presente\nVersion: 1.0.0\n*/\n" );
mkdir( $incompleto, 0777, true );
mkdir( $presente_plug, 0777, true );
file_put_contents( $presente_plug . '/presente.php', "<?php\n/*\nPlugin Name: Presente\nVersion: 1.0.0\n*/\n" );
mkdir( $incomplet_plug, 0777, true );

$tabela = array(
	array( 'tema', 'ausente', get_theme_root() . '/nao-existe', false, 'ausente_no_disco', false, 'não apareceu no disco', 'DEFEITO DE CACHE' ),
	array( 'tema', 'presente', $incompleto, false, 'principal_ausente', false, 'arquivo principal', 'não apareceu no disco' ),
	array( 'tema', 'presente', $presente_tema, false, 'cache_desatualizado', false, 'DEFEITO DE CACHE', 'não apareceu no disco' ),
	array( 'tema', 'presente', $presente_tema, true, 'presente', true, 'leitura de volta', 'DEFEITO DE CACHE' ),
	array( 'tema', 'ausente', get_theme_root() . '/nao-existe', true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'não apareceu no disco' ),
	array( 'tema', 'presente', $incompleto, true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'arquivo principal' ),
	array( 'plugin', 'ausente', WP_PLUGIN_DIR . '/nao-existe', false, 'ausente_no_disco', false, 'não apareceu no disco', 'DEFEITO DE CACHE' ),
	array( 'plugin', 'presente', $incomplet_plug, false, 'principal_ausente', false, 'arquivo principal', 'não apareceu no disco' ),
	array( 'plugin', 'presente', $presente_plug, false, 'cache_desatualizado', false, 'DEFEITO DE CACHE', 'não apareceu no disco' ),
	array( 'plugin', 'presente', $presente_plug, true, 'presente', true, 'leitura de volta', 'DEFEITO DE CACHE' ),
	array( 'plugin', 'ausente', WP_PLUGIN_DIR . '/nao-existe', true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'não apareceu no disco' ),
	array( 'plugin', 'presente', $incomplet_plug, true, 'presente_fora_do_caminho', true, 'raiz diferente da medida', 'arquivo principal' ),
);

foreach ( $tabela as $linha ) {
	$veredito = F3Base_Imp_Plugins::leitura_de_volta_do_artefato( $linha[0], basename( $linha[2] ), $linha[2], $linha[3] );
	$onde     = $linha[0] . '/' . $linha[1] . '/api=' . ( $linha[3] ? 've' : 'cega' );

	afirmar( $nome, $veredito['diagnostico'] === $linha[4], $onde . ': diagnóstico esperado ' . $linha[4] . ', obtido ' . (string) $veredito['diagnostico'] );
	afirmar( $nome, $veredito['ok'] === $linha[5], $onde . ': ok esperado ' . ( $linha[5] ? 'true' : 'false' ) );
	afirmar( $nome, contem( (string) $veredito['motivo'], $linha[6] ), $onde . ': a mensagem não traz "' . $linha[6] . '" — ' . (string) $veredito['motivo'] );
	afirmar( $nome, ! contem( (string) $veredito['motivo'], $linha[7] ), $onde . ': a mensagem traz "' . $linha[7] . '", que pertence a outro diagnóstico — ' . (string) $veredito['motivo'] );
}

/* =======================================================================
 * instalacao.artefato_fonte_unica — quem instala e quem prova leem o mesmo
 * ==================================================================== */

$nome = 'instalacao.artefato_fonte_unica';

foreach ( array( 'tema' => $tema_slug, 'site_core' => $core_slug ) as $papel => $slug ) {
	$artefato = F3Base_Imp_Plugins::artefato_do_papel( $papel );

	afirmar( $nome, $artefato['slug'] === $slug, $papel . ': a fonte única devolveu slug "' . (string) $artefato['slug'] . '" e a configuração declara "' . $slug . '"' );
	afirmar( $nome, array() !== $artefato['candidatos'], $papel . ': a fonte única não declarou nenhum caminho candidato' );
	afirmar( $nome, '' !== $artefato['tipo'], $papel . ': nenhum dos caminhos declarados existe no pacote — ' . implode( ', ', $artefato['candidatos'] ) );
	afirmar( $nome, in_array( 'assets/plugins/' . $slug . ( 'tema' === $papel ? '-tema' : '' ) . '.zip', $artefato['candidatos'], true ), $papel . ': o slot de zip do operador saiu da lista de candidatos' );
	afirmar( $nome, str_starts_with( (string) $artefato['caminho'], rtrim( F3BASE_IMP_DIR, '/' ) ), $papel . ': o caminho resolvido está fora do pacote — ' . (string) $artefato['caminho'] );
}

/* Papel desconhecido não inventa artefato: piso do falso positivo. */
$desconhecido = F3Base_Imp_Plugins::artefato_do_papel( 'inventado' );
afirmar( $nome, '' === $desconhecido['tipo'] && array() === $desconhecido['candidatos'], 'papel não declarado devolveu artefato — a fonte única não pode inventar caminho' );

f3b_apagar_arvore( $sandbox );
f3b_apagar_arvore( rtrim( ABSPATH, '/' ) );

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
