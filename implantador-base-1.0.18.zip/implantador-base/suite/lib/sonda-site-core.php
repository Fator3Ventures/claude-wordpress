<?php
/**
 * Sonda do SITE-CORE: as classes REAIS do plugin persistente, exercitadas.
 *
 * Subprocesso por desenho, como as outras sondas: esta monta um WordPress de
 * mentira — `wpdb` com as linhas em memória, options, transientes, hooks e
 * agendamentos — e roda o `class-f3base-modulo-endpoint-leads.php` e o
 * `class-f3base-modulo-cadencia-relatorio.php` de verdade contra ele. Nada é
 * copiado para cá: o que a sonda mede é o arquivo que viaja no pacote.
 *
 * Cada bloco tem TETO e PISO. O piso NÃO é "um caso inválido reprovou": é o
 * DEFEITO MEDIDO reproduzido na bancada, e a afirmação de que a bancada
 * realmente o reproduz sai junto. Um piso que não consegue plantar o defeito
 * prova que a bancada é cega, não que o código está certo — foi a lição que a
 * 1.0.15 pagou na sonda de instalação.
 *
 * A honestidade do limite: a bancada de banco entende as instruções que este
 * módulo emite, e só elas. Ela não é um MySQL. O que ela mede é a SEMÂNTICA
 * declarada — quantas instruções o incremento gasta, quem decide o empate, o
 * que sobra na tabela depois da falha —, e é essa semântica que os defeitos da
 * 1.0.17 violavam.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$raiz = rtrim( (string) ( $argv[1] ?? '' ), '/' );

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	echo json_encode( array( 'erro' => 'raiz inexistente' ) );
	exit( 2 );
}

$GLOBALS['f3b_bench'] = array(
	'options'     => array(),
	'transientes' => array(),
	'congelados'  => null,
	'hooks'       => array(),
	'eventos'     => array(),
	'posts'       => 0,
	'ultimo_post' => array(),
	'insert_ok'   => true,
	'insert_id_cego' => false,
	'servidor'    => array( 'REMOTE_ADDR' => '203.0.113.7' ),
	'fita'        => array(),
);

/*
 * A raiz do WordPress de mentira fica fora do pacote: `criar_tabela()` faz
 * `require_once ABSPATH . 'wp-admin/includes/upgrade.php'`, e o arquivo precisa
 * existir. O stub é vazio — quem responde por `dbDelta()` é a bancada, logo
 * abaixo.
 */
$abspath = sys_get_temp_dir() . '/f3base-sonda-site-core-' . getmypid() . '-wp/';

if ( ! is_dir( $abspath . 'wp-admin/includes' ) ) {
	mkdir( $abspath . 'wp-admin/includes', 0777, true );
}

file_put_contents( $abspath . 'wp-admin/includes/upgrade.php', "<?php
" );

define( 'ABSPATH', $abspath );
define( 'MINUTE_IN_SECONDS', 60 );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'DAY_IN_SECONDS', 86400 );
define( 'MONTH_IN_SECONDS', 30 * 86400 );
define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
define( 'F3BASE_SITE_CORE_VERSAO', '1.0.1' );
define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
define( 'F3BASE_PREFIXO', 'f3base' );
define( 'ARRAY_A', 'ARRAY_A' );

/* ---------------------------------------------------------------------------
 * Núcleo de mentira: só o que estas classes chamam.
 * ------------------------------------------------------------------------ */

/**
 * Tradução: eco.
 *
 * @param string $texto   Texto.
 * @param string $dominio Domínio.
 * @return string
 */
function __( string $texto, string $dominio = '' ): string {
	return $texto;
}

/**
 * Codificação JSON do núcleo.
 *
 * @param mixed $valor Valor.
 * @param int   $flags Flags.
 * @return string|false
 */
function wp_json_encode( $valor, int $flags = 0 ) {
	return json_encode( $valor, $flags | JSON_UNESCAPED_UNICODE );
}

/**
 * Validação de e-mail do núcleo.
 *
 * @param mixed $valor Valor.
 * @return string|false
 */
function is_email( $valor ) {
	return is_string( $valor ) && false !== filter_var( $valor, FILTER_VALIDATE_EMAIL ) ? $valor : false;
}

/**
 * Sanitização de e-mail do núcleo: entrada inválida devolve string VAZIA.
 *
 * É esse retorno vazio, não conferido, que fazia o lead entrar sem endereço.
 *
 * @param string $email E-mail bruto.
 * @return string
 */
function sanitize_email( string $email ): string {
	$email = trim( $email );

	return false !== filter_var( $email, FILTER_VALIDATE_EMAIL ) ? $email : '';
}

/**
 * Sanitização de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_text_field( string $texto ): string {
	$texto = strip_tags( $texto );
	$texto = preg_replace( '/[\r\n\t]+/', ' ', $texto );

	return trim( is_string( $texto ) ? $texto : '' );
}

/**
 * Sanitização de área de texto do núcleo.
 *
 * @param string $texto Texto.
 * @return string
 */
function sanitize_textarea_field( string $texto ): string {
	return trim( strip_tags( $texto ) );
}

/**
 * Sanitização de chave do núcleo.
 *
 * @param string $chave Chave.
 * @return string
 */
function sanitize_key( string $chave ): string {
	$limpo = preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $chave ) );

	return is_string( $limpo ) ? $limpo : '';
}

/**
 * Escape de URL do núcleo.
 *
 * @param string $url URL.
 * @return string
 */
function esc_url_raw( string $url ): string {
	return trim( $url );
}

/**
 * Remoção das barras que o núcleo acrescenta.
 *
 * @param mixed $valor Valor.
 * @return mixed
 */
function wp_unslash( $valor ) {
	return is_string( $valor ) ? stripslashes( $valor ) : $valor;
}

/**
 * URL do site.
 *
 * @param string $caminho Caminho.
 * @return string
 */
function home_url( string $caminho = '' ): string {
	return 'https://exemplo.test' . $caminho;
}

/**
 * Parser de URL do núcleo.
 *
 * @param string $url        URL.
 * @param int    $componente Componente.
 * @return array<string,mixed>|string|int|null|false
 */
function wp_parse_url( string $url, int $componente = -1 ) {
	return -1 === $componente ? parse_url( $url ) : parse_url( $url, $componente );
}

/**
 * Sal do núcleo.
 *
 * @param string $esquema Esquema.
 * @return string
 */
function wp_salt( string $esquema = 'auth' ): string {
	return 'sal-de-bancada-' . $esquema;
}

/**
 * Aleatório do núcleo.
 *
 * @param int $minimo Mínimo.
 * @param int $maximo Máximo.
 * @return int
 */
function wp_rand( int $minimo = 0, int $maximo = 0 ): int {
	return random_int( $minimo, max( $minimo, $maximo ) );
}

/**
 * Data formatada do núcleo.
 *
 * @param string   $formato  Formato.
 * @param int|null $carimbo  Carimbo.
 * @return string
 */
function wp_date( string $formato, ?int $carimbo = null ): string {
	return gmdate( $formato, null === $carimbo ? time() : $carimbo );
}

/**
 * Diferença legível do núcleo.
 *
 * @param int $de  Início.
 * @param int $ate Fim.
 * @return string
 */
function human_time_diff( int $de, int $ate = 0 ): string {
	return (string) abs( $ate - $de ) . 's';
}

/**
 * Erro do núcleo.
 */
class WP_Error {

	/**
	 * Mensagem do erro.
	 *
	 * @var string
	 */
	public string $mensagem;

	/**
	 * Constrói o erro.
	 *
	 * @param string $codigo   Código.
	 * @param string $mensagem Mensagem.
	 */
	public function __construct( string $codigo = '', string $mensagem = '' ) {
		$this->mensagem = $codigo . ': ' . $mensagem;
	}
}

/**
 * Predicado de erro do núcleo.
 *
 * @param mixed $valor Valor.
 * @return bool
 */
function is_wp_error( $valor ): bool {
	return $valor instanceof WP_Error;
}

/* ---------------------------------------------------------------------------
 * Options, transientes e hooks
 * ------------------------------------------------------------------------ */

/**
 * Leitura de option.
 *
 * @param string $nome   Nome.
 * @param mixed  $padrao Padrão.
 * @return mixed
 */
function get_option( string $nome, $padrao = false ) {
	return array_key_exists( $nome, $GLOBALS['f3b_bench']['options'] ) ? $GLOBALS['f3b_bench']['options'][ $nome ] : $padrao;
}

/**
 * Escrita de option, com os hooks que o núcleo dispara.
 *
 * @param string $nome     Nome.
 * @param mixed  $valor    Valor.
 * @param bool   $autoload Autoload.
 * @return bool
 */
function update_option( string $nome, $valor, bool $autoload = true ): bool {
	$existia = array_key_exists( $nome, $GLOBALS['f3b_bench']['options'] );
	$antigo  = $existia ? $GLOBALS['f3b_bench']['options'][ $nome ] : null;

	$GLOBALS['f3b_bench']['options'][ $nome ] = $valor;

	if ( ! $existia ) {
		do_action( 'added_option', $nome, $valor );

		return true;
	}

	if ( $antigo !== $valor ) {
		do_action( 'updated_option', $nome, $antigo, $valor );
	}

	return true;
}

/**
 * Remoção de option.
 *
 * @param string $nome Nome.
 * @return bool
 */
function delete_option( string $nome ): bool {
	unset( $GLOBALS['f3b_bench']['options'][ $nome ] );
	do_action( 'deleted_option', $nome );

	return true;
}

/**
 * Leitura de transiente.
 *
 * Quando a bancada está com os transientes CONGELADOS, a leitura devolve o
 * retrato tirado antes das gravações: é assim que duas requisições concorrentes
 * enxergam o mesmo valor, que é o defeito do balde por ler-modificar-gravar.
 *
 * @param string $chave Chave.
 * @return mixed
 */
function get_transient( string $chave ) {
	$fonte = null === $GLOBALS['f3b_bench']['congelados']
		? $GLOBALS['f3b_bench']['transientes']
		: $GLOBALS['f3b_bench']['congelados'];

	return array_key_exists( $chave, $fonte ) ? $fonte[ $chave ] : false;
}

/**
 * Escrita de transiente.
 *
 * @param string $chave Chave.
 * @param mixed  $valor Valor.
 * @param int    $ttl   TTL.
 * @return bool
 */
function set_transient( string $chave, $valor, int $ttl = 0 ): bool {
	$GLOBALS['f3b_bench']['transientes'][ $chave ] = $valor;

	return true;
}

/**
 * Remoção de transiente.
 *
 * @param string $chave Chave.
 * @return bool
 */
function delete_transient( string $chave ): bool {
	unset( $GLOBALS['f3b_bench']['transientes'][ $chave ] );

	return true;
}

/**
 * Registra um filtro.
 *
 * @param string   $hook       Hook.
 * @param callable $callback   Callback.
 * @param int      $prioridade Prioridade.
 * @param int      $args       Argumentos.
 * @return bool
 */
function add_filter( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	$GLOBALS['f3b_bench']['hooks'][ $hook ][] = array(
		'callback' => $callback,
		'args'     => $args,
	);

	return true;
}

/**
 * Registra uma ação.
 *
 * @param string   $hook       Hook.
 * @param callable $callback   Callback.
 * @param int      $prioridade Prioridade.
 * @param int      $args       Argumentos.
 * @return bool
 */
function add_action( string $hook, $callback, int $prioridade = 10, int $args = 1 ): bool {
	return add_filter( $hook, $callback, $prioridade, $args );
}

/**
 * Aplica um filtro.
 *
 * @param string $hook  Hook.
 * @param mixed  $valor Valor.
 * @param mixed  ...$extras Extras.
 * @return mixed
 */
function apply_filters( string $hook, $valor, ...$extras ) {
	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		$argumentos = array_slice( array_merge( array( $valor ), $extras ), 0, max( 1, (int) $registro['args'] ) );
		$valor      = call_user_func_array( $registro['callback'], $argumentos );
	}

	return $valor;
}

/**
 * Dispara uma ação.
 *
 * @param string $hook  Hook.
 * @param mixed  ...$argumentos Argumentos.
 * @return void
 */
function do_action( string $hook, ...$argumentos ): void {
	foreach ( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() as $registro ) {
		call_user_func_array( $registro['callback'], array_slice( $argumentos, 0, max( 0, (int) $registro['args'] ) ) );
	}
}

/**
 * Há ouvinte registrado neste hook?
 *
 * @param string $hook Hook.
 * @return int Quantos ouvintes.
 */
function has_action( string $hook ): int {
	return count( $GLOBALS['f3b_bench']['hooks'][ $hook ] ?? array() );
}

/* ---------------------------------------------------------------------------
 * Agendamentos
 * ------------------------------------------------------------------------ */

/**
 * Recorrências do núcleo, ANTES de qualquer filtro.
 *
 * A lista é exatamente a do WordPress: `monthly` não existe, e `quinzenal`
 * tampouco. É esta ausência que fazia "mensal" cair em `daily` e "quinzenal"
 * cair em `weekly`, com o dobro da frequência, em silêncio.
 *
 * @return array<string,array{interval:int,display:string}>
 */
function f3b_recorrencias_do_nucleo(): array {
	return array(
		'hourly'     => array(
			'interval' => HOUR_IN_SECONDS,
			'display'  => 'Once Hourly',
		),
		'twicedaily' => array(
			'interval' => 12 * HOUR_IN_SECONDS,
			'display'  => 'Twice Daily',
		),
		'daily'      => array(
			'interval' => DAY_IN_SECONDS,
			'display'  => 'Once Daily',
		),
		'weekly'     => array(
			'interval' => 7 * DAY_IN_SECONDS,
			'display'  => 'Once Weekly',
		),
	);
}

/**
 * Recorrências disponíveis, já com os filtros aplicados.
 *
 * @return array<string,array{interval:int,display:string}>
 */
function wp_get_schedules(): array {
	return (array) apply_filters( 'cron_schedules', f3b_recorrencias_do_nucleo() );
}

/**
 * Próxima execução agendada de um hook.
 *
 * @param string $hook Hook.
 * @return int|false
 */
function wp_next_scheduled( string $hook ) {
	return isset( $GLOBALS['f3b_bench']['eventos'][ $hook ] )
		? (int) $GLOBALS['f3b_bench']['eventos'][ $hook ]['timestamp']
		: false;
}

/**
 * Evento agendado, com a recorrência.
 *
 * @param string $hook Hook.
 * @return object|false
 */
function wp_get_scheduled_event( string $hook ) {
	if ( ! isset( $GLOBALS['f3b_bench']['eventos'][ $hook ] ) ) {
		return false;
	}

	return (object) $GLOBALS['f3b_bench']['eventos'][ $hook ];
}

/**
 * Agenda um evento recorrente.
 *
 * O núcleo RECUSA recorrência que não exista na lista: é aí que o agendamento
 * sem quem registre `f3base_mensal` fracassa em vez de degradar em silêncio.
 *
 * @param int    $quando      Carimbo.
 * @param string $recorrencia Recorrência.
 * @param string $hook        Hook.
 * @return bool|WP_Error
 */
function wp_schedule_event( int $quando, string $recorrencia, string $hook ) {
	$agendas = wp_get_schedules();

	if ( ! isset( $agendas[ $recorrencia ] ) ) {
		return new WP_Error( 'invalid_schedule', 'recorrência inexistente: ' . $recorrencia );
	}

	$GLOBALS['f3b_bench']['eventos'][ $hook ] = array(
		'hook'      => $hook,
		'timestamp' => $quando,
		'schedule'  => $recorrencia,
		'interval'  => (int) $agendas[ $recorrencia ]['interval'],
		'args'      => array(),
	);

	return true;
}

/**
 * Desagenda um evento.
 *
 * @param int    $quando Carimbo.
 * @param string $hook   Hook.
 * @return bool
 */
function wp_unschedule_event( int $quando, string $hook ): bool {
	unset( $GLOBALS['f3b_bench']['eventos'][ $hook ] );

	return true;
}

/* ---------------------------------------------------------------------------
 * Conteúdo
 * ------------------------------------------------------------------------ */

/**
 * Registro de tipo de conteúdo: inerte na bancada.
 *
 * @param string              $tipo      Tipo.
 * @param array<string,mixed> $argumentos Argumentos.
 * @return void
 */
function register_post_type( string $tipo, array $argumentos = array() ): void {}

/**
 * Registro de rota REST: inerte na bancada.
 *
 * @param string              $espaco    Namespace.
 * @param string              $rota      Rota.
 * @param array<string,mixed> $argumentos Argumentos.
 * @return void
 */
function register_rest_route( string $espaco, string $rota, array $argumentos = array() ): void {}

/**
 * Inserção de conteúdo, com o interruptor de falha da bancada.
 *
 * @param array<string,mixed> $dados Dados.
 * @param bool                $erro  Devolver WP_Error.
 * @return int|WP_Error
 */
function wp_insert_post( array $dados, bool $erro = false ) {
	if ( ! $GLOBALS['f3b_bench']['insert_ok'] ) {
		return new WP_Error( 'db_insert_error', 'a bancada recusou a inserção, como o banco cheio recusaria' );
	}

	++$GLOBALS['f3b_bench']['posts'];

	$GLOBALS['f3b_bench']['ultimo_post'] = $dados;

	return $GLOBALS['f3b_bench']['posts'];
}

/**
 * Migração de tabela do núcleo: a bancada já cria a tabela completa.
 *
 * @param string $sql SQL.
 * @return array<int,string>
 */
function dbDelta( string $sql ): array { // phpcs:ignore WordPress.NamingConventions
	global $wpdb;

	$wpdb->criar_do_sql( $sql );

	return array();
}

/* ---------------------------------------------------------------------------
 * REST
 * ------------------------------------------------------------------------ */

/**
 * Requisição REST de bancada.
 */
class WP_REST_Request {

	/**
	 * Corpo como JSON.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $json;

	/**
	 * Corpo como formulário.
	 *
	 * @var array<string,mixed>|null
	 */
	private ?array $form;

	/**
	 * Constrói a requisição.
	 *
	 * @param array<string,mixed>|null $json Corpo JSON.
	 * @param array<string,mixed>|null $form Corpo urlencoded.
	 */
	public function __construct( ?array $json = null, ?array $form = null ) {
		$this->json = $json;
		$this->form = $form;
	}

	/**
	 * Corpo JSON.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_json_params() {
		return $this->json;
	}

	/**
	 * Corpo urlencoded.
	 *
	 * @return array<string,mixed>|null
	 */
	public function get_body_params() {
		return $this->form;
	}

	/**
	 * Parâmetro solto.
	 *
	 * @param string $nome Nome.
	 * @return mixed
	 */
	public function get_param( string $nome ) {
		return null;
	}

	/**
	 * Cabeçalho.
	 *
	 * @param string $nome Nome.
	 * @return string|null
	 */
	public function get_header( string $nome ) {
		return null;
	}
}

/**
 * Resposta REST de bancada.
 */
class WP_REST_Response {

	/**
	 * Corpo.
	 *
	 * @var array<string,mixed>
	 */
	public array $data;

	/**
	 * Status HTTP.
	 *
	 * @var int
	 */
	public int $status;

	/**
	 * Constrói a resposta.
	 *
	 * @param array<string,mixed> $data   Corpo.
	 * @param int                 $status Status.
	 */
	public function __construct( array $data = array(), int $status = 200 ) {
		$this->data   = $data;
		$this->status = $status;
	}
}

/* ---------------------------------------------------------------------------
 * wpdb de bancada
 * ------------------------------------------------------------------------ */

/**
 * Banco de bancada: linhas em memória, com a semântica das instruções emitidas.
 *
 * Ela entende as instruções que o módulo emite, e só elas. O que importa medir
 * aqui é QUEM decide: a chave primária recusa o segundo `INSERT`, o
 * `ON DUPLICATE KEY UPDATE` soma numa instrução só, e o `UPDATE` condicionado ao
 * carimbo lido faz a retomada da reserva morta acontecer uma vez só.
 */
class F3Base_Bench_Wpdb {

	/**
	 * Prefixo das tabelas.
	 *
	 * @var string
	 */
	public string $prefix = 'wp_';

	/**
	 * Último id gerado por LAST_INSERT_ID().
	 *
	 * @var int
	 */
	public int $insert_id = 0;

	/**
	 * Tabelas: nome => array{colunas:string[],linhas:array<string,array<string,mixed>>}.
	 *
	 * @var array<string,array<string,mixed>>
	 */
	public array $tabelas = array();

	/**
	 * Fita de instruções executadas.
	 *
	 * @var array<int,string>
	 */
	public array $fita = array();

	/**
	 * Cria a tabela a partir do CREATE TABLE do módulo.
	 *
	 * @param string $sql SQL.
	 * @return void
	 */
	public function criar_do_sql( string $sql ): void {
		if ( ! preg_match( '/CREATE TABLE ([A-Za-z0-9_]+) \((.*)\)\s*;?\s*$/s', trim( $sql ), $achado ) ) {
			return;
		}

		$nome    = $achado[1];
		$colunas = array();

		foreach ( explode( "\n", $achado[2] ) as $linha ) {
			$linha = trim( $linha );

			if ( '' === $linha || preg_match( '/^(PRIMARY KEY|KEY|UNIQUE)/i', $linha ) ) {
				continue;
			}

			if ( preg_match( '/^([a-z_]+)\s/i', $linha, $coluna ) ) {
				$colunas[] = $coluna[1];
			}
		}

		$anteriores = $this->tabelas[ $nome ]['linhas'] ?? array();

		$this->tabelas[ $nome ] = array(
			'colunas' => $colunas,
			'linhas'  => $anteriores,
		);
	}

	/**
	 * Interpola a instrução como o núcleo interpola.
	 *
	 * @param string $sql  SQL com marcadores.
	 * @param mixed  ...$argumentos Argumentos.
	 * @return string
	 */
	public function prepare( string $sql, ...$argumentos ): string {
		if ( 1 === count( $argumentos ) && is_array( $argumentos[0] ) ) {
			$argumentos = $argumentos[0];
		}

		$saida = '';
		$i     = 0;
		$n     = strlen( $sql );

		while ( $i < $n ) {
			$c = $sql[ $i ];

			if ( '%' === $c && $i + 1 < $n && in_array( $sql[ $i + 1 ], array( 's', 'd' ), true ) ) {
				$argumento = array_shift( $argumentos );

				$saida .= 's' === $sql[ $i + 1 ]
					? "'" . addslashes( (string) $argumento ) . "'"
					: (string) (int) $argumento;

				$i += 2;
				continue;
			}

			$saida .= $c;
			++$i;
		}

		return $saida;
	}

	/**
	 * Silenciamento de erro: a bancada nunca imprime.
	 *
	 * @param bool $silenciar Silenciar.
	 * @return bool
	 */
	public function suppress_errors( bool $silenciar = true ): bool {
		return false;
	}

	/**
	 * Escape de LIKE.
	 *
	 * @param string $texto Texto.
	 * @return string
	 */
	public function esc_like( string $texto ): string {
		return $texto;
	}

	/**
	 * Collate do núcleo.
	 *
	 * @return string
	 */
	public function get_charset_collate(): string {
		return '';
	}

	/**
	 * Valor único.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return string|null
	 */
	public function get_var( string $sql ) {
		$this->fita[] = $sql;

		if ( preg_match( "/SHOW TABLES LIKE '([^']+)'/", $sql, $achado ) ) {
			return isset( $this->tabelas[ $achado[1] ] ) ? $achado[1] : null;
		}

		if ( preg_match( "/SELECT contador FROM ([A-Za-z0-9_]+) WHERE chave = '([^']*)'/", $sql, $achado ) ) {
			$linha = $this->tabelas[ $achado[1] ]['linhas'][ $achado[2] ] ?? null;

			return null === $linha ? null : (string) $linha['contador'];
		}

		return null;
	}

	/**
	 * Coluna inteira.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return array<int,string>
	 */
	public function get_col( string $sql ): array {
		$this->fita[] = $sql;

		if ( preg_match( '/SHOW COLUMNS FROM ([A-Za-z0-9_]+)/', $sql, $achado ) ) {
			return $this->tabelas[ $achado[1] ]['colunas'] ?? array();
		}

		return array();
	}

	/**
	 * Uma linha.
	 *
	 * @param string $sql   SQL já interpolada.
	 * @param string $saida Formato.
	 * @return array<string,mixed>|null
	 */
	public function get_row( string $sql, string $saida = ARRAY_A ) {
		$this->fita[] = $sql;

		if ( ! preg_match( '/FROM ([A-Za-z0-9_]+)/', $sql, $tabela ) ) {
			return null;
		}

		if ( ! preg_match( "/WHERE chave = '([^']*)'/", $sql, $chave ) ) {
			return null;
		}

		return $this->tabelas[ $tabela[1] ]['linhas'][ $chave[1] ] ?? null;
	}

	/**
	 * Instrução de escrita.
	 *
	 * @param string $sql SQL já interpolada.
	 * @return int|false Linhas afetadas.
	 */
	public function query( string $sql ) {
		$this->fita[] = $sql;

		if ( str_starts_with( ltrim( $sql ), 'INSERT INTO' ) ) {
			return $this->inserir( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'UPDATE' ) ) {
			return $this->atualizar( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'DELETE' ) ) {
			return $this->apagar( $sql );
		}

		if ( str_starts_with( ltrim( $sql ), 'DROP' ) ) {
			return 0;
		}

		return false;
	}

	/**
	 * INSERT, com e sem ON DUPLICATE KEY UPDATE.
	 *
	 * @param string $sql SQL.
	 * @return int|false
	 */
	private function inserir( string $sql ) {
		if ( ! preg_match( '/INSERT INTO ([A-Za-z0-9_]+) \(([^)]*)\) VALUES \(([^)]*)\)/', $sql, $achado ) ) {
			return false;
		}

		$tabela = $achado[1];

		if ( ! isset( $this->tabelas[ $tabela ] ) ) {
			return false;
		}

		$colunas = array_map( 'trim', explode( ',', $achado[2] ) );
		$valores = $this->argumentos( $achado[3] );

		if ( count( $colunas ) !== count( $valores ) ) {
			return false;
		}

		$linha = array_combine( $colunas, $valores );
		$chave = (string) $linha['chave'];

		if ( ! isset( $this->tabelas[ $tabela ]['linhas'][ $chave ] ) ) {
			$this->tabelas[ $tabela ]['linhas'][ $chave ] = $linha;

			return 1;
		}

		if ( ! str_contains( $sql, 'ON DUPLICATE KEY UPDATE' ) ) {
			/* A CHAVE PRIMÁRIA DECIDE O EMPATE: o segundo INSERT não entra. */
			return false;
		}

		$atual = $this->tabelas[ $tabela ]['linhas'][ $chave ];

		if ( ! preg_match( '/contador = LAST_INSERT_ID\( IF\( expira_em < (\d+), 1, contador \+ 1 \) \)/', $sql, $conta ) ) {
			return false;
		}

		if ( ! preg_match( '/expira_em = IF\( expira_em < (\d+), (\d+), expira_em \)/', $sql, $prazo ) ) {
			return false;
		}

		$expirou = (int) $atual['expira_em'] < (int) $conta[1];

		$atual['contador']  = $expirou ? 1 : (int) $atual['contador'] + 1;
		$atual['expira_em'] = (int) $atual['expira_em'] < (int) $prazo[1] ? (int) $prazo[2] : (int) $atual['expira_em'];

		$this->tabelas[ $tabela ]['linhas'][ $chave ] = $atual;

		/* Driver que não devolve LAST_INSERT_ID(): o interruptor da bancada. */
		$this->insert_id = $GLOBALS['f3b_bench']['insert_id_cego'] ? 0 : (int) $atual['contador'];

		return 2;
	}

	/**
	 * UPDATE, nas duas formas que o módulo emite.
	 *
	 * @param string $sql SQL.
	 * @return int|false
	 */
	private function atualizar( string $sql ) {
		if ( ! preg_match( '/UPDATE ([A-Za-z0-9_]+) SET/', $sql, $achado ) ) {
			return false;
		}

		$tabela = $achado[1];

		if ( ! preg_match( "/WHERE chave = '([^']*)'/", $sql, $chave ) || ! isset( $this->tabelas[ $tabela ]['linhas'][ $chave[1] ] ) ) {
			return 0;
		}

		$linha = $this->tabelas[ $tabela ]['linhas'][ $chave[1] ];

		if ( preg_match( "/AND estado = '([^']*)'/", $sql, $estado ) && (string) $linha['estado'] !== $estado[1] ) {
			return 0;
		}

		if ( preg_match( '/AND criado_em = (\d+)/', $sql, $carimbo ) && (int) $linha['criado_em'] !== (int) $carimbo[1] ) {
			return 0;
		}

		if ( preg_match( "/SET record_id = '([^']*)', criado_em = (\d+), expira_em = (\d+)/", $sql, $set ) ) {
			$linha['record_id'] = $set[1];
			$linha['criado_em'] = (int) $set[2];
			$linha['expira_em'] = (int) $set[3];
		} elseif ( preg_match( "/SET estado = '([^']*)'/", $sql, $set ) ) {
			$linha['estado'] = $set[1];
		} else {
			return false;
		}

		$this->tabelas[ $tabela ]['linhas'][ $chave[1] ] = $linha;

		return 1;
	}

	/**
	 * DELETE, nas duas formas que o módulo emite.
	 *
	 * @param string $sql SQL.
	 * @return int
	 */
	private function apagar( string $sql ): int {
		if ( ! preg_match( '/DELETE FROM ([A-Za-z0-9_]+)/', $sql, $achado ) || ! isset( $this->tabelas[ $achado[1] ] ) ) {
			return 0;
		}

		$tabela = $achado[1];

		if ( preg_match( "/WHERE chave = '([^']*)' AND estado = '([^']*)'/", $sql, $par ) ) {
			$linha = $this->tabelas[ $tabela ]['linhas'][ $par[1] ] ?? null;

			if ( null === $linha || (string) $linha['estado'] !== $par[2] ) {
				return 0;
			}

			unset( $this->tabelas[ $tabela ]['linhas'][ $par[1] ] );

			return 1;
		}

		if ( ! preg_match( "/WHERE criado_em < (\d+) OR \( expira_em > 0 AND expira_em < (\d+) \) OR \( estado = '([^']*)' AND criado_em < (\d+) \)/", $sql, $poda ) ) {
			return 0;
		}

		$removidas = 0;

		foreach ( $this->tabelas[ $tabela ]['linhas'] as $chave => $linha ) {
			$velha     = (int) $linha['criado_em'] < (int) $poda[1];
			$expirada  = (int) $linha['expira_em'] > 0 && (int) $linha['expira_em'] < (int) $poda[2];
			$abandonada = (string) $linha['estado'] === $poda[3] && (int) $linha['criado_em'] < (int) $poda[4];

			if ( $velha || $expirada || $abandonada ) {
				unset( $this->tabelas[ $tabela ]['linhas'][ $chave ] );
				++$removidas;
			}
		}

		return $removidas;
	}

	/**
	 * Valores literais de um trecho de instrução, na ordem em que aparecem.
	 *
	 * @param string $trecho Trecho.
	 * @return array<int,mixed>
	 */
	private function argumentos( string $trecho ): array {
		preg_match_all( "/'((?:[^'\\\\]|\\\\.)*)'|(-?\d+)/", $trecho, $achados, PREG_SET_ORDER );

		$saida = array();

		foreach ( $achados as $achado ) {
			$saida[] = isset( $achado[2] ) && '' !== $achado[2] ? (int) $achado[2] : stripslashes( $achado[1] );
		}

		return $saida;
	}
}

$wpdb = new F3Base_Bench_Wpdb();

/* ---------------------------------------------------------------------------
 * As classes REAIS do pacote
 * ------------------------------------------------------------------------ */

$fonte = $raiz . '/fontes/site-core/includes/';

require $fonte . 'class-f3base-options.php';
require $fonte . 'class-f3base-atividade.php';
require $fonte . 'class-f3base-modulo.php';
require $fonte . 'class-f3base-modulo-endpoint-leads.php';
require $fonte . 'class-f3base-modulo-cadencia-relatorio.php';
require $fonte . 'class-f3base-registro.php';
require $fonte . 'class-f3base-plugin.php';

/* ---------------------------------------------------------------------------
 * Registro dos achados
 * ------------------------------------------------------------------------ */

$resultado = array();

/**
 * Registra um achado.
 *
 * @param string $checagem Checagem.
 * @param string $achado   Achado.
 * @return void
 */
function anotar( string $checagem, string $achado ): void {
	global $resultado;
	$resultado[ $checagem ]              = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['achados'][] = $achado;
}

/**
 * Conta uma unidade medida.
 *
 * @param string $checagem Checagem.
 * @return void
 */
function medir( string $checagem ): void {
	global $resultado;
	$resultado[ $checagem ]            = $resultado[ $checagem ] ?? array(
		'achados' => array(),
		'medidas' => 0,
	);
	$resultado[ $checagem ]['medidas'] = $resultado[ $checagem ]['medidas'] + 1;
}

/**
 * Afirma, contando a medida.
 *
 * @param string $checagem Checagem.
 * @param bool   $condicao Condição medida.
 * @param string $falha    Texto do achado quando a condição não vale.
 * @return void
 */
function afirmar( string $checagem, bool $condicao, string $falha ): void {
	medir( $checagem );

	if ( ! $condicao ) {
		anotar( $checagem, $falha );
	}
}

/**
 * Zera a bancada entre cenários.
 *
 * @return void
 */
function bancada_limpa(): void {
	global $wpdb;

	$GLOBALS['f3b_bench']['options']     = array();
	$GLOBALS['f3b_bench']['transientes'] = array();
	$GLOBALS['f3b_bench']['congelados']  = null;
	$GLOBALS['f3b_bench']['posts']       = 0;
	$GLOBALS['f3b_bench']['ultimo_post']  = array();
	$GLOBALS['f3b_bench']['insert_ok']   = true;
	$GLOBALS['f3b_bench']['insert_id_cego'] = false;
	$GLOBALS['f3b_bench']['servidor']    = array( 'REMOTE_ADDR' => '203.0.113.7' );

	$wpdb->tabelas   = array();
	$wpdb->fita      = array();
	$wpdb->insert_id = 0;

	requisicao_nova();
	F3Base_Modulo_Endpoint_Leads::criar_tabela();
}

/**
 * Simula uma REQUISIÇÃO NOVA, zerando os memos de requisição.
 *
 * Os memos existem para não repetir trabalho DENTRO de uma requisição — o
 * registro de módulos e a prontidão da tabela. Numa bancada que encadeia vários
 * cenários no mesmo processo eles atravessariam a fronteira que no site real não
 * existe, e o cenário seguinte mediria o estado do anterior.
 *
 * @return void
 */
function requisicao_nova(): void {
	foreach ( array( 'F3Base_Registro' => 'modulos', 'F3Base_Modulo_Endpoint_Leads' => 'tabela_pronta' ) as $classe => $propriedade ) {
		$reflexo = new ReflectionProperty( $classe, $propriedade );
		$reflexo->setAccessible( true );
		$reflexo->setValue( null, null );
	}
}

/**
 * Linhas da tabela de chaves com um tipo, e opcionalmente um estado.
 *
 * @param string $tipo   Tipo da linha.
 * @param string $estado Estado da reserva; vazio aceita qualquer um.
 * @return int
 */
function linhas_do_tipo( string $tipo, string $estado = '' ): int {
	global $wpdb;

	$tabela = F3Base_Modulo_Endpoint_Leads::nome_tabela();
	$conta  = 0;

	foreach ( $wpdb->tabelas[ $tabela ]['linhas'] ?? array() as $linha ) {
		if ( (string) $linha['tipo'] !== $tipo ) {
			continue;
		}

		if ( '' !== $estado && (string) $linha['estado'] !== $estado ) {
			continue;
		}

		++$conta;
	}

	return $conta;
}

/**
 * Payload mínimo aceito pelo endpoint.
 *
 * @param array<string,mixed> $extra Campos a acrescentar ou trocar.
 * @return array<string,mixed>
 */
function carga( array $extra = array() ): array {
	return array_merge(
		array(
			'token'          => F3Base_Modulo_Endpoint_Leads::emitir_token(),
			'correlation_id' => 'correlacao-de-bancada-1',
		),
		$extra
	);
}

/**
 * Exercita o endpoint com um corpo JSON.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Endpoint_Leads();

	return $modulo->receber( new WP_REST_Request( $corpo, null ) );
}

/**
 * Exercita o endpoint com um corpo de formulário — onde tudo chega string.
 *
 * @param array<string,mixed> $corpo Corpo.
 * @return WP_REST_Response
 */
function postar_form( array $corpo ): WP_REST_Response {
	$modulo = new F3Base_Modulo_Endpoint_Leads();

	return $modulo->receber( new WP_REST_Request( null, $corpo ) );
}

bancada_limpa();

/* ==========================================================================
 * leads.limite_por_caractere
 * ======================================================================= */

$nome = 'leads.limite_por_caractere';

$limites = F3Base_Modulo_Endpoint_Leads::limites_publicos();
$max     = (int) $limites['nome'];

/* PISO: a bancada reproduz o defeito? O texto acentuado no limite EXCEDE em bytes. */
$acentuado = str_repeat( 'ção', (int) floor( $max / 3 ) );
$acentuado .= str_repeat( 'á', $max - mb_strlen( $acentuado, 'UTF-8' ) );

afirmar(
	$nome,
	mb_strlen( $acentuado, 'UTF-8' ) === $max,
	'piso: a bancada não conseguiu montar um nome com exatamente ' . $max . ' caracteres acentuados, e sem ele o defeito não é reproduzido'
);

afirmar(
	$nome,
	strlen( $acentuado ) > $max,
	'piso: o texto acentuado no limite NÃO excede o limite em bytes — a bancada não está reproduzindo o defeito de unidade da 1.0.17, e o teto abaixo aprovaria por acaso'
);

/* TETO: o mesmo texto é aceito, porque a unidade agora é a que o cliente corta. */
$resposta = postar( carga( array( 'nome' => $acentuado ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: nome com ' . $max . ' caracteres acentuados foi recusado com status ' . $resposta->status . ' e código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — o navegador aprovou e o servidor recusou, que é o lead perdido em português'
);

/* PISO da regra: um caractere ACIMA do limite continua sendo recusado. */
bancada_limpa();
$resposta = postar( carga( array( 'nome' => $acentuado . 'ç' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_limite_excedido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso: um caractere acima do limite passou — a regra deixou de recusar, e "recusado, nunca truncado em silêncio" virou letra morta'
);

afirmar(
	$nome,
	'caracteres' === (string) ( $resposta->data['unidade'] ?? '' ),
	'a recusa não NOMEIA a unidade medida: o cliente precisa saber em que unidade o limite foi contado para cortar na mesma'
);

/* A unidade também vale dentro de atribuicao, que repetia a mesma medida. */
bancada_limpa();
$referrer = 'https://exemplo.test/' . str_repeat( 'é', 500 );
$resposta = postar( carga( array( 'atribuicao' => array( 'fonte' => str_repeat( 'ã', 120 ) ) ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto de atribuicao: 120 caracteres acentuados em atribuicao.fonte foram recusados com status ' . $resposta->status . ' — a segunda medida em bytes continuou de pé'
);

bancada_limpa();
$resposta = postar( carga( array( 'atribuicao' => array( 'fonte' => str_repeat( 'ã', 121 ) ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'atribuicao.fonte' === (string) ( $resposta->data['campo'] ?? '' ),
	'piso de atribuicao: 121 caracteres passaram, ou a recusa não nomeou a chave'
);

/* Um limite por campo, e ele é o do schema: `pagina` no limite chega inteira. */
bancada_limpa();

$caminho  = '/contato/?origem=' . str_repeat( 'ã', 100 );
$resposta = postar( carga( array( 'pagina' => 'https://exemplo.test' . $caminho ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto de pagina: uma URL interna com acentuação dentro do limite foi recusada com status ' . $resposta->status
);

$meta = $GLOBALS['f3b_bench']['ultimo_post']['meta_input'] ?? array();
$corpo_do_post = (string) ( $GLOBALS['f3b_bench']['ultimo_post']['post_content'] ?? '' );

afirmar(
	$nome,
	str_contains( $corpo_do_post, $caminho ),
	'a URL interna acentuada foi CORTADA na normalização: um segundo limite, em outra unidade, é uma segunda fonte para o mesmo fato'
);

/* ==========================================================================
 * leads.email_conclusivo
 * ======================================================================= */

$nome = 'leads.email_conclusivo';

/* PISO: a bancada reproduz o defeito? sanitize_email() devolve VAZIO, não erro. */
afirmar(
	$nome,
	'' === sanitize_email( 'joao arroba exemplo' ),
	'piso: a bancada não reproduz o retorno vazio de sanitize_email() para entrada inválida, e sem ele o teto aprovaria por acaso'
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => 'joao arroba exemplo' ) ) );

afirmar(
	$nome,
	400 === $resposta->status,
	'piso: e-mail inválido foi ACEITO com status ' . $resposta->status . ' — o lead entra sem endereço nenhum e a resposta diz que deu certo'
);

afirmar(
	$nome,
	'email' === (string) ( $resposta->data['campo'] ?? '' ),
	'a recusa do e-mail inválido não nomeia o campo'
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => 'pessoa@exemplo.test' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto: e-mail válido foi recusado com status ' . $resposta->status
);

bancada_limpa();
$resposta = postar( carga( array( 'email' => '' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'teto do falso positivo: e-mail VAZIO é campo opcional ausente, não e-mail inválido, e foi recusado com status ' . $resposta->status
);

/* ==========================================================================
 * leads.booleano_explicito
 * ======================================================================= */

$nome = 'leads.booleano_explicito';

/* PISO: a bancada reproduz o defeito? O molde da linguagem faz "false" valer true. */
afirmar(
	$nome,
	true === (bool) 'false',
	'piso: nesta versão de PHP (bool) "false" não é true, e o defeito medido não é reproduzível aqui'
);

afirmar(
	$nome,
	false === (bool) '0',
	'piso: a assimetria entre "0" e "false" não é reproduzível aqui'
);

$tabela_booleana = array(
	array( 'false', false, 'a string "false" precisa valer FALSO, e era ela que arquivava consentimento inexistente' ),
	array( '0', false, 'a string "0"' ),
	array( '', false, 'a string vazia' ),
	array( 'no', false, 'a string "no"' ),
	array( 'nao', false, 'a string "nao"' ),
	array( 'off', false, 'a string "off"' ),
	array( '1', true, 'a string "1"' ),
	array( 'true', true, 'a string "true"' ),
	array( 'sim', true, 'a string "sim"' ),
	array( 'on', true, 'a string "on"' ),
);

foreach ( $tabela_booleana as $caso ) {
	bancada_limpa();
	$resposta = postar_form( carga( array( 'consentimento' => $caso[0] ) ) );

	afirmar(
		$nome,
		201 === $resposta->status,
		'valor booleano "' . $caso[0] . '" foi recusado com status ' . $resposta->status
	);

	$gravado = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

	afirmar(
		$nome,
		array() !== $gravado,
		'valor booleano "' . $caso[0] . '" não chegou a gravar lead nenhum'
	);

	/*
	 * O VALOR QUE FOI ARQUIVADO, e não só o status da resposta: é o meta
	 * `_f3base_consentimento` que o Flamingo e o CPT guardam, e era ele que
	 * dizia "sim" para quem tinha mandado a string "false".
	 */
	$meta = $GLOBALS['f3b_bench']['ultimo_post']['meta_input'] ?? array();

	afirmar(
		$nome,
		( $caso[1] ? 'sim' : 'nao' ) === (string) ( $meta['_f3base_consentimento'] ?? '' ),
		'o valor "' . $caso[0] . '" foi ARQUIVADO como consentimento "' . (string) ( $meta['_f3base_consentimento'] ?? '' ) . '": ' . $caso[2]
	);
}

/* O valor lido é conferido no meta, que é o que o Flamingo arquiva como consentimento. */
foreach ( $tabela_booleana as $caso ) {
	medir( $nome );

	$lido = F3Base_Modulo_Endpoint_Leads::interpretar_booleano( $caso[0] );

	if ( $caso[1] !== $lido ) {
		anotar( $nome, $caso[2] . ' foi interpretada como ' . var_export( $lido, true ) . ' e devia ser ' . var_export( $caso[1], true ) );
	}
}

/* Estrutura no lugar de escalar: a guarda que o `continue` do booleano pulava. */
bancada_limpa();
$resposta = postar( carga( array( 'consentimento' => array() ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_tipo_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso da estrutura: {"consentimento":{}} devolveu status ' . $resposta->status . ' com código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — array vazio virando consentimento verdadeiro é o defeito que o ramo próprio do booleano escondia'
);

bancada_limpa();
$resposta = postar( carga( array( 'consentimento' => (object) array( 'a' => 1 ) ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_tipo_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso da estrutura: objeto em consentimento devolveu status ' . $resposta->status
);

/* O limite de 8 do schema deixou de ser letra morta. */
bancada_limpa();
$resposta = postar_form( carga( array( 'consentimento' => 'verdadeiro-demais' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_limite_excedido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso do limite: valor de 17 caracteres no campo booleano de max 8 devolveu status ' . $resposta->status . ' com código ' . (string) ( $resposta->data['codigo'] ?? '' ) . ' — o ramo próprio do booleano pulava a checagem de limite e o max era letra morta'
);

/* Vocabulário fechado: valor que ninguém sabe ler é recusado, nunca adivinhado. */
bancada_limpa();
$resposta = postar_form( carga( array( 'consentimento' => 'talvez' ) ) );

afirmar(
	$nome,
	400 === $resposta->status && 'f3base_valor_invalido' === (string) ( $resposta->data['codigo'] ?? '' ),
	'piso do vocabulário: "talvez" foi aceito com status ' . $resposta->status . ' — consentimento adivinhado é consentimento inventado'
);

/* ==========================================================================
 * leads.reserva_compensada
 * ======================================================================= */

$nome = 'leads.reserva_compensada';

bancada_limpa();

$tabela = F3Base_Modulo_Endpoint_Leads::nome_tabela();

/* PISO: a bancada reproduz a reserva? A primeira tentativa DEIXA a linha lá. */
$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	503 === $resposta->status,
	'a gravação recusada devolveu status ' . $resposta->status . ', e não 5xx — 201 Created com ok:false diz que o recurso existe'
);

afirmar(
	$nome,
	0 === linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP ),
	'piso: a reserva SOBREVIVEU à falha de gravação (' . linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP ) . ' linha(s) de deduplicação na tabela). É exatamente ela que, na 1.0.17, bloqueava por 30 dias o visitante que tentasse de novo'
);

/* TETO: a tentativa seguinte com o MESMO correlation_id é ACEITA. */
$GLOBALS['f3b_bench']['insert_ok'] = true;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	201 === $resposta->status && true === ( $resposta->data['registrado'] ?? false ),
	'teto: depois de uma falha de armazenamento, a segunda tentativa com o mesmo correlation_id devolveu status ' . $resposta->status . ' e registrado=' . var_export( $resposta->data['registrado'] ?? null, true ) . ' — ela precisa ser ACEITA'
);

/* PISO da deduplicação: com a gravação BEM-SUCEDIDA, o replay continua recusado. */
$resposta = postar( carga( array( 'correlation_id' => 'correlacao-que-falha' ) ) );

afirmar(
	$nome,
	200 === $resposta->status && true === ( $resposta->data['duplicado'] ?? false ),
	'piso da deduplicação: o replay de uma correlação JÁ GRAVADA passou — a compensação não pode ter apagado a reserva firme'
);

/* Exatamente uma reserva FIRME, e o balde do rate limit não se confunde com ela. */
$firmes = linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME );

afirmar(
	$nome,
	1 === $firmes,
	'a tabela ficou com ' . $firmes . ' reserva(s) firme(s) depois de uma gravação aceita; esperava exatamente uma'
);

afirmar(
	$nome,
	linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_LIMITE ) > 0 && 0 === linhas_do_tipo( F3Base_Modulo_Endpoint_Leads::TIPO_LIMITE, F3Base_Modulo_Endpoint_Leads::RESERVA_FIRME ),
	'a linha do balde do rate limit está gravada com estado de RESERVA: balde não é reserva, e misturá-los faz qualquer contagem por estado mentir'
);

/* Reserva PENDENTE abandonada é retomada, e uma vez só. */
bancada_limpa();

$chave = F3Base_Modulo_Endpoint_Leads::chave_de_dedup( 'correlacao-abandonada' );

$wpdb->tabelas[ $tabela ]['linhas'][ $chave ] = array(
	'chave'     => $chave,
	'tipo'      => F3Base_Modulo_Endpoint_Leads::TIPO_DEDUP,
	'estado'    => F3Base_Modulo_Endpoint_Leads::RESERVA_PENDENTE,
	'record_id' => 'registro-abandonado',
	'contador'  => 0,
	'expira_em' => time() + 100000,
	'criado_em' => time() - ( F3Base_Modulo_Endpoint_Leads::ttl_reserva_pendente() + 60 ),
);

$retomada = F3Base_Modulo_Endpoint_Leads::reservar( 'correlacao-abandonada', 'registro-novo' );

afirmar(
	$nome,
	true === $retomada['novo'] && 'registro-novo' === $retomada['record_id'],
	'a reserva pendente abandonada não foi retomada: uma requisição interrompida entre a reserva e a gravação bloquearia a correlação até o fim do TTL'
);

$segunda = F3Base_Modulo_Endpoint_Leads::reservar( 'correlacao-abandonada', 'registro-terceiro' );

afirmar(
	$nome,
	false === $segunda['novo'],
	'piso da retomada: a reserva recém-retomada foi retomada DE NOVO — o UPDATE precisa casar o carimbo lido para que dois pedidos concorrentes produzam uma retomada só'
);

/* A contingência por transiente tem a mesma compensação. */
bancada_limpa();
$wpdb->tabelas = array();

afirmar(
	$nome,
	! F3Base_Modulo_Endpoint_Leads::tabela_pronta(),
	'piso da contingência: sem tabela, tabela_pronta() continuou dizendo que está pronta'
);

$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	503 === $resposta->status,
	'contingência: a gravação recusada devolveu status ' . $resposta->status
);

$GLOBALS['f3b_bench']['insert_ok'] = true;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	201 === $resposta->status,
	'contingência: a segunda tentativa depois da falha devolveu status ' . $resposta->status . ' — o caminho de transiente tinha o MESMO defeito e precisa da mesma compensação'
);

$resposta = postar( carga( array( 'correlation_id' => 'correlacao-transiente' ) ) );

afirmar(
	$nome,
	200 === $resposta->status && true === ( $resposta->data['duplicado'] ?? false ),
	'contingência: o replay de correlação já gravada passou'
);

/* ==========================================================================
 * leads.atividade_so_com_persistencia
 * ======================================================================= */

$nome = 'leads.atividade_so_com_persistencia';

bancada_limpa();

$GLOBALS['f3b_bench']['insert_ok'] = false;
postar( carga( array( 'correlation_id' => 'correlacao-sem-persistencia' ) ) );

$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );
$falha  = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );

afirmar(
	$nome,
	array() === $aceito,
	'piso: a atividade "último registro aceito" foi carimbada mesmo sem persistência — a tela do site-core passa a apontar para onde nada foi escrito'
);

afirmar(
	$nome,
	array() !== $falha && '' !== (string) ( $falha['destino'] ?? '' ),
	'a recusa não deixou carimbo próprio: o ramo adverso não pode simplesmente sumir da tela'
);

afirmar(
	$nome,
	str_contains( (string) ( $falha['motivo'] ?? '' ), F3Base_Modulo_Endpoint_Leads::CPT ),
	'o carimbo da recusa não NOMEIA os destinos que recusaram'
);

/* TETO: com persistência, o carimbo sai e aponta para o destino real. */
$GLOBALS['f3b_bench']['insert_ok'] = true;
postar( carga( array( 'correlation_id' => 'correlacao-com-persistencia' ) ) );

$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

afirmar(
	$nome,
	F3Base_Modulo_Endpoint_Leads::CPT === (string) ( $aceito['destino'] ?? '' ),
	'teto: a gravação aceita não carimbou o destino real'
);

/* O estado do módulo reflete a recusa mais recente, em vez de calar. */
bancada_limpa();
$GLOBALS['f3b_bench']['insert_ok'] = false;
postar( carga( array( 'correlation_id' => 'correlacao-degradada' ) ) );

$estado = ( new F3Base_Modulo_Endpoint_Leads() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" com a última tentativa recusada: gravação que não aconteceu não pode sair verde na tela'
);

/* ==========================================================================
 * leads.status_da_gravacao
 * ======================================================================= */

$nome = 'leads.status_da_gravacao';

bancada_limpa();

$GLOBALS['f3b_bench']['insert_ok'] = false;
$resposta                          = postar( carga( array( 'correlation_id' => 'correlacao-do-status' ) ) );

/* PISO: 201 Created com ok:false diz que o recurso existe. Não pode voltar. */
afirmar(
	$nome,
	201 !== $resposta->status,
	'piso: nenhum destino aceitou o lead e a resposta saiu 201 Created — o cliente é informado de que o recurso foi criado quando nada foi escrito'
);

afirmar(
	$nome,
	$resposta->status >= 500 && $resposta->status < 600,
	'a gravação indisponível saiu com status ' . $resposta->status . ', e falha de armazenamento do servidor é 5xx'
);

afirmar(
	$nome,
	false === ( $resposta->data['ok'] ?? true ) && false === ( $resposta->data['registrado'] ?? true ),
	'a resposta da gravação recusada não diz ok=false e registrado=false'
);

afirmar(
	$nome,
	'' !== (string) ( $resposta->data['codigo'] ?? '' ),
	'a resposta da gravação recusada não traz código: erro sem código é erro que o cliente não sabe distinguir'
);

foreach ( array( 'reenviar', 'WhatsApp' ) as $instrucao ) {
	afirmar(
		$nome,
		str_contains( (string) ( $resposta->data['motivo'] ?? '' ), $instrucao ),
		'a resposta da gravação recusada não diz ao visitante o que fazer: falta "' . $instrucao . '" no motivo'
	);
}

/* TETO: a gravação aceita responde 201 com registrado verdadeiro. */
bancada_limpa();
$resposta = postar( carga( array( 'correlation_id' => 'correlacao-do-status-ok' ) ) );

afirmar(
	$nome,
	201 === $resposta->status && true === ( $resposta->data['registrado'] ?? false ),
	'teto: a gravação aceita saiu com status ' . $resposta->status . ' e registrado=' . var_export( $resposta->data['registrado'] ?? null, true )
);

afirmar(
	$nome,
	'' !== (string) ( $resposta->data['record_id'] ?? '' ),
	'a gravação aceita não devolveu o record_id nascido no servidor'
);

/* ==========================================================================
 * leads.rate_limit_atomico
 * ======================================================================= */

$nome = 'leads.rate_limit_atomico';

bancada_limpa();

$chave_limite = hash( 'sha256', 'limite-de-bancada' );

/*
 * PISO: a bancada reproduz o defeito? Com os transientes CONGELADOS — que é o
 * que duas requisições concorrentes enxergam —, o caminho de ler-modificar-
 * gravar precisa PERDER o incremento.
 */
$GLOBALS['f3b_bench']['congelados'] = $GLOBALS['f3b_bench']['transientes'];

$perdido_a = F3Base_Modulo_Endpoint_Leads::incrementar_por_transiente( $chave_limite, 600 );
$perdido_b = F3Base_Modulo_Endpoint_Leads::incrementar_por_transiente( $chave_limite, 600 );

afirmar(
	$nome,
	1 === $perdido_a && 1 === $perdido_b,
	'piso: sob leitura congelada o caminho de transiente devolveu ' . $perdido_a . ' e ' . $perdido_b . ' — a bancada não está reproduzindo a perda de incremento, e o teto abaixo aprovaria por acaso'
);

/* TETO: o incremento no banco não perde nada sob a MESMA leitura congelada. */
$atomico = array();

for ( $i = 0; $i < 5; $i++ ) {
	$atomico[] = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_limite, 600 );
}

$GLOBALS['f3b_bench']['congelados'] = null;

afirmar(
	$nome,
	array( 1, 2, 3, 4, 5 ) === $atomico,
	'teto: cinco incrementos concorrentes devolveram ' . implode( ',', $atomico ) . ' — quem soma tem de ser o banco, numa instrução só, senão N requisições leem o mesmo valor e o balde deixa de segurar'
);

/* Uma instrução por incremento: o balde não tem leitura separada da escrita. */
$instrucoes = 0;

foreach ( $wpdb->fita as $linha ) {
	if ( str_contains( $linha, 'ON DUPLICATE KEY UPDATE' ) ) {
		++$instrucoes;
	}
}

afirmar(
	$nome,
	5 === $instrucoes,
	'os cinco incrementos gastaram ' . $instrucoes . ' instrução(ões) de soma no banco: o incremento tem de ser UMA instrução, sem SELECT antes'
);

/*
 * PISO do driver cego: sem LAST_INSERT_ID() o incremento JÁ aconteceu, e devolver
 * 1 daria um balde que nunca fecha — limite que nunca fecha é pior que limite
 * nenhum, porque parece que existe.
 */
bancada_limpa();
$chave_cega = hash( 'sha256', 'limite-com-driver-cego' );

F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_cega, 600 );
$GLOBALS['f3b_bench']['insert_id_cego'] = true;

$cegos = array();

for ( $i = 0; $i < 3; $i++ ) {
	$cegos[] = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_cega, 600 );
}

$GLOBALS['f3b_bench']['insert_id_cego'] = false;

afirmar(
	$nome,
	array( 2, 3, 4 ) === $cegos,
	'piso do driver cego: sem LAST_INSERT_ID() a contagem devolveu ' . implode( ',', $cegos ) . ' — devolver 1 aqui é um balde que nunca fecha'
);

/* A janela expirada zera o balde, em vez de somar para sempre. */
bancada_limpa();
$chave_curta = hash( 'sha256', 'limite-de-janela-curta' );

F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_curta, 1 );
$linha_curta = $wpdb->tabelas[ $tabela ]['linhas'][ $chave_curta ];
$wpdb->tabelas[ $tabela ]['linhas'][ $chave_curta ]['expira_em'] = time() - 10;

$depois = F3Base_Modulo_Endpoint_Leads::incrementar_janela( $chave_curta, 600 );

afirmar(
	$nome,
	1 === $depois,
	'a janela vencida devolveu ' . $depois . ' em vez de reiniciar o balde em 1'
);

/* ==========================================================================
 * leads.origem_declarada
 * ======================================================================= */

$nome = 'leads.origem_declarada';

bancada_limpa();

/*
 * A cadeia que UM proxy confiável produz: ele acrescenta o IP de quem falou com
 * ele, e o visitante que não mandou nada deixa a lista com um elemento só.
 */
$servidor_com_proxy = array(
	'REMOTE_ADDR'          => '198.51.100.10',
	'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
);

/* PISO: sem declaração, o cabeçalho é IGNORADO. */
$origem = F3Base_Modulo_Endpoint_Leads::origem( $servidor_com_proxy );

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'piso: sem cabeçalho declarado a origem saiu ' . $origem['valor'] . ' por ' . $origem['fonte'] . ' — cabeçalho de proxy aceito sem declaração é o visitante escolhendo o balde em que conta'
);

/* TETO: declarado, o cabeçalho é lido descontando os saltos confiáveis. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$origem = F3Base_Modulo_Endpoint_Leads::origem( $servidor_com_proxy );

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'] && 'cabecalho-declarado' === $origem['fonte'],
	'teto: com o cabeçalho declarado a origem saiu ' . $origem['valor'] . ' por ' . $origem['fonte'] . ', e devia ser o IP do visitante'
);

/* PISO do spoofing: o visitante empurra um valor a mais e não escolhe o balde. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'balde-inventado, 203.0.113.99',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'],
	'piso do spoofing: o valor que o visitante empurrou na frente da cadeia virou a origem (' . $origem['valor'] . '), e com ela ele escolhe em que balde conta'
);

/* Dois proxies confiáveis: a declaração desconta os dois saltos, não um. */
F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 2,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99, 198.51.100.20',
	)
);

afirmar(
	$nome,
	'203.0.113.99' === $origem['valor'],
	'com dois saltos declarados a origem saiu ' . $origem['valor'] . ' em vez do IP do visitante'
);

/* Cadeia mais curta que a declaração não vira origem: ela volta a REMOTE_ADDR. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => '203.0.113.99',
	)
);

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'cadeia mais curta que os saltos declarados virou origem (' . $origem['valor'] . ') em vez de voltar para REMOTE_ADDR'
);

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

/* Cadeia mais curta que a declaração, ou valor que não é IP: volta a REMOTE_ADDR. */
$origem = F3Base_Modulo_Endpoint_Leads::origem(
	array(
		'REMOTE_ADDR'          => '198.51.100.10',
		'HTTP_X_FORWARDED_FOR' => 'nao-e-um-ip',
	)
);

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'] && 'remote_addr' === $origem['fonte'],
	'valor que não é IP no cabeçalho declarado virou origem (' . $origem['valor'] . ') em vez de voltar para REMOTE_ADDR'
);

$origem = F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10' ) );

afirmar(
	$nome,
	'198.51.100.10' === $origem['valor'],
	'cabeçalho declarado e AUSENTE na requisição não voltou para REMOTE_ADDR'
);

/* O nome do cabeçalho vira variável de servidor, com e sem o prefixo. */
foreach ( array( 'X-Forwarded-For' => 'HTTP_X_FORWARDED_FOR', 'CF-Connecting-IP' => 'HTTP_CF_CONNECTING_IP', 'HTTP_CF_CONNECTING_IP' => 'HTTP_CF_CONNECTING_IP', '' => '' ) as $declarado => $esperado ) {
	afirmar(
		$nome,
		$esperado === F3Base_Modulo_Endpoint_Leads::chave_de_servidor( $declarado ),
		'o cabeçalho declarado "' . $declarado . '" virou "' . F3Base_Modulo_Endpoint_Leads::chave_de_servidor( $declarado ) . '" em vez de "' . $esperado . '"'
	);
}

/* O balde muda com a origem: dois visitantes atrás do mesmo proxy não se somam. */
bancada_limpa();

F3Base_Options::gravar(
	'f3base_origem_confiavel',
	array(
		'cabecalho' => 'X-Forwarded-For',
		'saltos'    => 1,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$um    = hash( 'sha256', 'limite|' . F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10', 'HTTP_X_FORWARDED_FOR' => '203.0.113.1' ) )['valor'] . '|' . wp_salt( 'nonce' ) );
$outro = hash( 'sha256', 'limite|' . F3Base_Modulo_Endpoint_Leads::origem( array( 'REMOTE_ADDR' => '198.51.100.10', 'HTTP_X_FORWARDED_FOR' => '203.0.113.2' ) )['valor'] . '|' . wp_salt( 'nonce' ) );

afirmar(
	$nome,
	$um !== $outro,
	'dois visitantes distintos atrás do mesmo proxy caíram na MESMA chave de balde: é o balde único de 20 por 10 minutos para o proxy inteiro'
);

/* ==========================================================================
 * cadencia.ouvinte_registrado
 * ======================================================================= */

$nome = 'cadencia.ouvinte_registrado';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

/* PISO: o núcleo do WordPress não tem as recorrências que a configuração pede. */
$nucleo = f3b_recorrencias_do_nucleo();

afirmar(
	$nome,
	! isset( $nucleo['monthly'] ),
	'piso: a bancada inventou uma recorrência "monthly" no núcleo — sem a ausência dela, a degradação silenciosa não é reproduzível'
);

afirmar(
	$nome,
	! isset( $nucleo[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ] ) && ! isset( $nucleo[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ),
	'piso: as recorrências do módulo já existiam no núcleo da bancada'
);

/* PISO: sem ouvinte, o evento dispara e ninguém escuta — que é a 1.0.17. */
afirmar(
	$nome,
	0 === has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
	'piso: a bancada começou com ouvinte no hook da cadência, e não há como provar que é o registro que o cria'
);

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 3,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

/* TETO: o registro único enganchou o ouvinte. */
afirmar(
	$nome,
	has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ) > 0,
	'teto: depois do registro único NINGUÉM escuta ' . F3Base_Modulo_Cadencia_Relatorio::HOOK . ' — o evento dispara, o WP-Cron o reagenda, e nada acontece'
);

$agendas = wp_get_schedules();

afirmar(
	$nome,
	isset( $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ] ) && 30 * DAY_IN_SECONDS === (int) $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL ]['interval'],
	'teto: a recorrência mensal não foi registrada com trinta dias de intervalo, e "mensal" volta a cair em daily'
);

afirmar(
	$nome,
	isset( $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ] ) && 15 * DAY_IN_SECONDS === (int) $agendas[ F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL ]['interval'],
	'teto: a recorrência quinzenal não foi registrada com quinze dias, e "quinzenal" volta a cair em weekly, com o DOBRO da frequência'
);

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL === F3Base_Modulo_Cadencia_Relatorio::recorrencia_declarada(),
	'a periodicidade "mensal" da configuração não resolveu para a recorrência mensal registrada'
);

/* O agendamento acontece com a recorrência DECLARADA, não com a mais próxima. */
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL === F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada(),
	'o evento ficou agendado com "' . F3Base_Modulo_Cadencia_Relatorio::recorrencia_agendada() . '" e a configuração declara mensal'
);

/* O estado NOMEIA a divergência quando quem agendou não conhecia a recorrência. */
$GLOBALS['f3b_bench']['eventos'][ F3Base_Modulo_Cadencia_Relatorio::HOOK ]['schedule'] = 'daily';

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'] && str_contains( $estado['motivo'], 'daily' ),
	'a degradação de mensal para daily saiu como "' . $estado['estado'] . '" sem nomear a recorrência observada: era exatamente isso que acontecia em silêncio'
);

/* ==========================================================================
 * cadencia.execucao_registrada
 * ======================================================================= */

$nome = 'cadencia.execucao_registrada';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks']   = array();
$GLOBALS['f3b_bench']['eventos'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'quinzenal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

$modulo = new F3Base_Modulo_Cadencia_Relatorio();
$modulo->garantir_agendamento();

/*
 * DUAS execuções: a primeira CRIA as options de estado que ela mesma grava, e
 * comparar a contagem da primeira com a medição de agora compararia dois
 * momentos diferentes. Da segunda em diante o conjunto é estável, e é sobre ele
 * que a conferência do número tem sentido.
 */
$modulo->executar_por_cron();
$modulo->executar_por_cron();

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

foreach ( array( 'em', 'gatilho', 'resultado', 'duracao_ms', 'atraso_segundos', 'proxima', 'modulos', 'options' ) as $campo ) {
	afirmar(
		$nome,
		array_key_exists( $campo, $carimbo ),
		'a execução não registrou o campo "' . $campo . '": cadência que roda sem deixar última execução, próxima, duração, resultado e erro é cadência que ninguém sabe se rodou'
	);
}

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RESULTADO_OK === (string) ( $carimbo['resultado'] ?? '' ),
	'a execução limpa terminou em "' . (string) ( $carimbo['resultado'] ?? '' ) . '"'
);

afirmar(
	$nome,
	'' === (string) ( $carimbo['erro'] ?? 'x' ),
	'a execução limpa registrou erro: ' . (string) ( $carimbo['erro'] ?? '' )
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['modulos'] ?? '' ), 'cadencia-relatorio' ),
	'o relatório não NOMEIA os módulos que mediu: contagem por estado sem a lista de nomes responde "quantos" e a pergunta é "quais"'
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['options'] ?? '' ), 'divergentes' ),
	'o relatório não diz quais options divergiram na releitura'
);

/* Nenhum número inventado: a contagem de options relidas bate com a medição. */
$relidas = 0;

foreach ( F3Base_Options::nomes() as $option ) {
	if ( F3Base_Options::existe( $option ) ) {
		++$relidas;
	}
}

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['options'] ?? '' ), (string) $relidas . ' relida' ),
	'a contagem de options relidas no texto do relatório não bate com a medição de agora (' . $relidas . '): número em texto de relatório sai de medição, nunca de estimativa'
);

/* PISO do atraso: previsão no passado precisa virar atraso medido e degradação. */
$atrasado = time() - ( F3Base_Modulo_Cadencia_Relatorio::atraso_tolerado() + 3600 );

F3Base_Options::gravar(
	'f3base_cadencia_estado',
	array(
		'ajustes'  => 0,
		'previsto' => $atrasado,
	),
	F3Base_Options::ORIGEM_MANUAL
);

$modulo->executar_por_cron();
$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	(int) ( $carimbo['atraso_segundos'] ?? 0 ) > F3Base_Modulo_Cadencia_Relatorio::atraso_tolerado(),
	'piso do atraso: a execução atrasada registrou atraso de ' . (int) ( $carimbo['atraso_segundos'] ?? 0 ) . 's — evento atrasado que não é medido é evento que ninguém sabe que atrasou'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" com a última execução acima da tolerância de atraso'
);

/* PISO do erro: a medição que explode vira resultado erro NOMEADO, nunca sucesso. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

add_filter(
	'f3base_site_core_relatorio',
	static function ( $relatorio ) {
		throw new RuntimeException( 'a medição do relatório falhou na bancada' );
	}
);

( new F3Base_Modulo_Cadencia_Relatorio() )->executar_por_cron();

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::RESULTADO_ERRO === (string) ( $carimbo['resultado'] ?? '' ),
	'piso do erro: a medição que explodiu registrou resultado "' . (string) ( $carimbo['resultado'] ?? '' ) . '"'
);

afirmar(
	$nome,
	str_contains( (string) ( $carimbo['erro'] ?? '' ), 'a medição do relatório falhou na bancada' ),
	'piso do erro: o erro não foi registrado com a mensagem que o produziu'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	F3Base_Modulo::DEGRADADO === $estado['estado'],
	'o módulo fechou "' . $estado['estado'] . '" depois de uma execução que terminou em erro'
);

$GLOBALS['f3b_bench']['hooks'] = array();

/* ==========================================================================
 * cadencia.contador_de_ajustes
 * ======================================================================= */

$nome = 'cadencia.contador_de_ajustes';

bancada_limpa();
$GLOBALS['f3b_bench']['hooks']   = array();
$GLOBALS['f3b_bench']['eventos'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'nenhuma',
		'apos_n_ajustes' => 3,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();

afirmar(
	$nome,
	3 === F3Base_Modulo_Cadencia_Relatorio::apos_n_ajustes(),
	'piso: a chave apos_n_ajustes gravada pelo implantador não é LIDA por ninguém — era exatamente esse o defeito: o relatório prometia um gatilho sobre um contador inexistente'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o contador não começou em zero'
);

F3Base_Options::gravar( 'f3base_retencao_meses', 7, F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	1 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'teto: a escrita numa option gerenciada não foi contada como ajuste (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* PISO da reentrância: a própria atividade não pode contar como ajuste. */
F3Base_Atividade::registrar( F3Base_Atividade::ULTIMO_LEAD, array( 'record_id' => 'apenas-atividade' ) );

afirmar(
	$nome,
	1 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'piso da reentrância: o carimbo de atividade contou como ajuste (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ') — o site mudar porque rodou não é alguém ter ajustado alguma coisa, e contá-lo faz o gatilho disparar sozinho'
);

F3Base_Options::gravar( 'f3base_linkedin_partner_id', '123456', F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	2 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o segundo ajuste não foi contado (contador em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* TETO: ao alcançar o alvo, o gatilho DISPARA e zera o contador. */
F3Base_Options::gravar( 'f3base_retencao_meses', 9, F3Base_Options::ORIGEM_MANUAL );

$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

afirmar(
	$nome,
	F3Base_Modulo_Cadencia_Relatorio::GATILHO_AJUSTES === (string) ( $carimbo['gatilho'] ?? '' ),
	'teto: o terceiro ajuste NÃO disparou a execução (gatilho registrado: "' . (string) ( $carimbo['gatilho'] ?? 'nenhum' ) . '") — chave que não faz nada é pior que chave ausente, porque produz confiança'
);

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'o contador não foi zerado depois do disparo (ficou em ' . F3Base_Modulo_Cadencia_Relatorio::ajustes() . ')'
);

/* PISO do gatilho desligado: alvo zero não mantém contador nem promete nada. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'mensal',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => F3Base_Modulo_Cadencia_Relatorio::HOOK,
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

F3Base_Site_Core::registrar();
( new F3Base_Modulo_Cadencia_Relatorio() )->garantir_agendamento();
F3Base_Options::gravar( 'f3base_retencao_meses', 11, F3Base_Options::ORIGEM_MANUAL );

afirmar(
	$nome,
	0 === F3Base_Modulo_Cadencia_Relatorio::ajustes(),
	'piso do gatilho desligado: com apos_n_ajustes em zero o contador andou mesmo assim'
);

$estado = ( new F3Base_Modulo_Cadencia_Relatorio() )->estado();

afirmar(
	$nome,
	str_contains( $estado['motivo'], 'zero' ),
	'com o gatilho desligado o estado do módulo não diz que nada promete disparar por ele: "' . $estado['motivo'] . '"'
);

/* Sem periodicidade e sem gatilho, o módulo é INERTE e declara por quê. */
bancada_limpa();
$GLOBALS['f3b_bench']['hooks'] = array();

F3Base_Options::gravar(
	'f3base_cadencia',
	array(
		'periodicidade'  => 'nenhuma',
		'apos_n_ajustes' => 0,
		'mecanismo'      => '',
		'hook'           => '',
	),
	F3Base_Options::ORIGEM_IMPLANTADOR
);

$modulo = new F3Base_Modulo_Cadencia_Relatorio();

afirmar(
	$nome,
	F3Base_Modulo::INATIVO === $modulo->estado()['estado'] && ! $modulo->deve_registrar(),
	'sem periodicidade e sem gatilho o módulo continuou registrando hooks: módulo inativo é inerte de verdade'
);

requisicao_nova();
F3Base_Site_Core::registrar();

afirmar(
	$nome,
	0 === has_action( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
	'o módulo inativo enganchou o hook mesmo assim'
);

echo json_encode( $resultado, JSON_UNESCAPED_UNICODE );
