<?php
/**
 * Piso: a prova de que cada detector SABE REPROVAR.
 *
 * Regra dura deste arquivo: o piso roda a MESMA função que roda contra o
 * pacote. Nada é reimplementado aqui — o registro abaixo só troca a raiz. Uma
 * suíte cujo piso reimplementa a regra prova que a cópia funciona, não que o
 * detector funciona.
 *
 * Segunda regra dura: a detecção precisa sair com o NOME DA PRÓPRIA CHECAGEM.
 * Reprovar por exceção, por erro de análise ou por qualquer acidente genérico
 * não prova nada — por isso toda chamada é isolada e a exceção vira FALHA do
 * piso, nunca aprovação.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$suite = dirname( __DIR__ );
$raiz  = rtrim( (string) ( $argv[1] ?? '' ), '/' );

require $suite . '/lib/regra.php';
require $suite . '/lib/empacotar.php';

foreach ( array( 'estatica', 'tema', 'conteudo', 'a11y', 'copy', 'entrega', 'funcional', 'bloqueadas', 'meta' ) as $modulo ) {
	require $suite . '/checagens/' . $modulo . '.php';
}

require $suite . '/lib/documentos.php';

if ( '' === $raiz || ! is_dir( $raiz ) ) {
	fwrite( STDERR, "uso: piso.php <caminho-do-pacote>\n" );
	exit( 2 );
}

/**
 * Registro: nome da checagem => a MESMA função que o runner chama.
 *
 * @param string $suite Diretório da suíte.
 * @return array<string,callable(string):array{ok:bool,achados:array<int,string>}>
 */
function f3b_registro_piso( string $suite ): array {
	return array(
		'estatica.php_lint'                    => static fn( string $r ): array => f3b_ck_php_lint( $r ),
		'estatica.json_valido'                 => static fn( string $r ): array => f3b_ck_json_valido( $r ),
		'estatica.js_lint'                     => static fn( string $r ): array => f3b_ck_js_lint( $r, $suite ),
		'estatica.wp_comentarios_balanceados'  => static fn( string $r ): array => f3b_ck_wp_comentarios( $r, $suite ),
		'estatica.detector_escrita_unica'      => static fn( string $r ): array => f3b_ck_escrita_unica( $r ),
		'estatica.detector_version_compare'    => static fn( string $r ): array => f3b_ck_version_compare( $r ),
		'estatica.detector_condicao_literal'   => static fn( string $r ): array => f3b_ck_condicao_literal( $r ),
		'estatica.detector_codigo_em_string'   => static fn( string $r ): array => f3b_ck_codigo_em_string( $r ),
		'estatica.detector_chave_sem_consumidor' => static fn( string $r ): array => f3b_ck_chave_sem_consumidor( $r ),
		'estatica.option_gravada_sem_leitor'   => static fn( string $r ): array => f3b_ck_option_sem_leitor( $r ),
		'estatica.gate_de_fase_do_metadado'    => static fn( string $r ): array => f3b_ck_gate_de_fase_do_metadado( $r ),
		'doc.afirmacao_conferida'              => static fn( string $r ): array => f3b_ck_afirmacoes( $r ),
		'estatica.detector_placeholder'        => static fn( string $r ): array => f3b_ck_placeholder( $r ),
		'estatica.plano_dependencias'          => static fn( string $r ): array => f3b_ck_plano_dependencias( $r ),
		'estatica.simbolos_resolvem'           => static fn( string $r ): array => f3b_ck_simbolos_resolvem( $r ),
		'estatica.estados_fechados'            => static fn( string $r ): array => f3b_ck_estados_fechados( $r ),
		'estatica.gate_fonte_unica'            => static fn( string $r ): array => f3b_ck_gate_fonte_unica( $r ),
		'estatica.option_fonte_unica'          => static fn( string $r ): array => f3b_ck_option_fonte_unica( $r ),
		'estatica.pagina_status_fonte_unica'   => static fn( string $r ): array => f3b_ck_pagina_status_fonte_unica( $r ),
		'estatica.llms_so_pagina_publicada'    => static fn( string $r ): array => f3b_ck_llms_so_pagina_publicada( $r ),
		'estatica.politica_privacidade_fonte_unica' => static fn( string $r ): array => f3b_ck_politica_privacidade_fonte_unica( $r ),
		'estatica.carimbo_de_release_nos_documentos' => static fn( string $r ): array => f3b_ck_carimbo_de_release_nos_documentos( $r ),
		'estatica.identidade_do_implantador'   => static fn( string $r ): array => f3b_ck_identidade_do_implantador( $r ),
		'estatica.contagem_com_nomes'          => static fn( string $r ): array => f3b_ck_contagem_com_nomes( $r ),
		'estatica.unidade_reflete_internas'     => static fn( string $r ): array => f3b_ck_unidade_reflete_internas( $r ),
		'estatica.warn_tem_ramo_adverso'        => static fn( string $r ): array => f3b_ck_warn_tem_ramo_adverso( $r ),
		'estatica.troca_invalida_cache'         => static fn( string $r ): array => f3b_ck_troca_invalida_cache( $r ),
		'estatica.artefato_do_pacote_e_lido'    => static fn( string $r ): array => f3b_ck_artefato_do_pacote_e_lido( $r ),
		'estatica.resposta_de_lote_nomeada'     => static fn( string $r ): array => f3b_ck_resposta_de_lote_nomeada( $r ),
		'estatica.piso_em_sonda_declarado'      => static fn( string $r ): array => f3b_ck_piso_em_sonda_declarado( $r ),
		'plugins.serie_de_backup_normalizada'  => static fn( string $r ): array => f3b_ck_serie_de_backup( $r, $suite ),
		'estatica.sem_residuo_de_prefixo'       => static fn( string $r ): array => f3b_ck_sem_residuo_de_prefixo( $r ),
		'config.slug_declarado'                => static fn( string $r ): array => f3b_ck_slug_declarado( $r ),
		'tema.zero_com_unidade'                => static fn( string $r ): array => f3b_ck_zero_com_unidade( $r, $suite ),
		'tema.preset_ocioso'                   => static fn( string $r ): array => f3b_ck_preset_ocioso( $r, $suite ),
		'tema.preset_inexistente'              => static fn( string $r ): array => f3b_ck_preset_inexistente( $r, $suite ),
		'tema.sem_cor_literal'                 => static fn( string $r ): array => f3b_ck_sem_cor_literal( $r ),
		'tema.wp_html_declarado'               => static fn( string $r ): array => f3b_ck_wp_html_declarado( $r, $suite ),
		'tema.main_layout_default'             => static fn( string $r ): array => f3b_ck_main_layout_default( $r, $suite ),
		'tema.versao_assets'                   => static fn( string $r ): array => f3b_ck_versao_assets( $r ),
		'conteudo.sem_estilo_avulso'           => static fn( string $r ): array => f3b_ck_sem_estilo_avulso( $r, $suite ),
		'conteudo.headings'                    => static fn( string $r ): array => f3b_ck_headings( $r, $suite ),
		'conteudo.demonstrativo'               => static fn( string $r ): array => f3b_ck_conteudo_demonstrativo( $r ),
		'conteudo.marca_demonstrativa'         => static fn( string $r ): array => f3b_ck_marca_demonstrativa( $r ),
		'a11y.contraste'                       => static fn( string $r ): array => f3b_ck_contraste( $r, $suite ),
		'copy.contrato'                        => static fn( string $r ): array => f3b_ck_copy_contrato( $r ),
		'pacote.allow_list'                    => static fn( string $r ): array => f3b_ck_allow_list( $r, $r . '/suite' ),
		'pacote.build_fresco'                  => static fn( string $r ): array => f3b_ck_build_fresco( $r . '/artefato.zip', $r . '/fonte' ),
		'pacote.sem_cabecalho_de_plugin_aninhado' => static fn( string $r ): array => f3b_ck_cabecalho_aninhado( $r ),
		'pacote.backup_sempre_oculto'          => static fn( string $r ): array => f3b_ck_backup_sempre_oculto( $r ),
	);
}

$registro = f3b_registro_piso( $suite );
$fixtures = $suite . '/fixtures';

echo "== piso: cada detector contra a fixture que reproduz o defeito ==\n";

foreach ( $registro as $nome => $funcao ) {
	$negativa = $fixtures . '/' . $nome . '/negativa';
	$positiva = $fixtures . '/' . $nome . '/positiva';

	if ( ! is_dir( $negativa ) || ! is_dir( $positiva ) ) {
		estado(
			'BLOCKED',
			$nome,
			'piso ausente: falta ' . ( is_dir( $negativa ) ? 'fixtures/' . $nome . '/positiva' : 'fixtures/' . $nome . '/negativa' ) . '.',
			'pendencia-externa',
			'build'
		);
		continue;
	}

	/* Ramo negativo: a fixture reproduz o defeito e a checagem PRECISA acusar. */
	try {
		$r = $funcao( $negativa );

		if ( ! is_array( $r ) || ! array_key_exists( 'ok', $r ) ) {
			estado( 'FALHA', $nome, 'piso negativo: a checagem não devolveu veredito analisável.', 'teste-funcional', 'build' );
		} elseif ( $r['ok'] ) {
			estado( 'FALHA', $nome, 'piso negativo: o defeito plantado NÃO foi acusado — detector cego.', 'teste-funcional', 'build' );
		} else {
			estado(
				'OK',
				$nome,
				'piso negativo: acusou o defeito plantado — ' . f3b_amostra( $r['achados'], 2 ) . '.',
				'teste-funcional',
				'build'
			);
		}
	} catch ( Throwable $e ) {
		estado(
			'FALHA',
			$nome,
			'piso negativo: reprovou por exceção (' . get_class( $e ) . ': ' . $e->getMessage() . '), e exceção não prova detecção.',
			'teste-funcional',
			'build'
		);
	}

	/* Ramo positivo: a fixture preserva o correto e a checagem PRECISA calar. */
	try {
		$r = $funcao( $positiva );

		if ( ! is_array( $r ) || ! array_key_exists( 'ok', $r ) ) {
			estado( 'FALHA', $nome, 'piso positivo: a checagem não devolveu veredito analisável.', 'teste-funcional', 'build' );
		} elseif ( $r['ok'] ) {
			estado( 'OK', $nome, 'piso positivo: ficou em silêncio sobre o caso correto.', 'teste-funcional', 'build' );
		} else {
			estado(
				'FALHA',
				$nome,
				'piso positivo: acusou o caso correto — ' . f3b_amostra( $r['achados'], 3 ) . '.',
				'teste-funcional',
				'build'
			);
		}
	} catch ( Throwable $e ) {
		estado(
			'FALHA',
			$nome,
			'piso positivo: morreu por exceção (' . get_class( $e ) . ': ' . $e->getMessage() . ').',
			'teste-funcional',
			'build'
		);
	}
}

/* Fixture sem checagem no registro é piso solto: ninguém a executa. */
foreach ( glob( $fixtures . '/*', GLOB_ONLYDIR ) ?: array() as $dir ) {
	$nome = basename( $dir );

	if ( isset( $registro[ $nome ] ) ) {
		continue;
	}

	estado( 'FALHA', 'piso.fixture_orfa', 'fixtures/' . $nome . ' não corresponde a nenhuma checagem do registro do piso.', 'analise-estatica', 'build' );
}

echo "\n== resumo do piso ==\n";

/* CONTAGEM E NOMES SAEM JUNTOS, aqui pela mesma razão que no runner. */
$contagem   = F3Base_Suite::contagem();
$nomes_piso = F3Base_Suite::nomes_por_estado();

foreach ( f3b_resumo_por_estado( $contagem, $nomes_piso ) as $linha_do_resumo ) {
	echo $linha_do_resumo . "\n";
}

printf( "   %-8s %d\n", 'TOTAL', array_sum( $contagem ) );

$falhas = F3Base_Suite::falhas();

if ( $falhas > 0 ) {
	printf(
		"\npiso REPROVADO: %d ramo(s) em FALHA — %s.\n",
		$falhas,
		'FALHA: ' . ( array() === $nomes_piso['FALHA'] ? 'nenhum' : implode( ', ', $nomes_piso['FALHA'] ) )
	);
	exit( 1 );
}

printf( "\npiso aprovado: %d detector(es) provaram acusar o defeito e calar sobre o correto.\n", count( $registro ) );

exit( 0 );
