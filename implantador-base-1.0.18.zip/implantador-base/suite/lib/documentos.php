<?php
/**
 * Documentos entregáveis: as regiões GERADAS e o detector que as guarda.
 *
 * A REGRA, e o defeito que a produziu. README, MANIFESTO e MEMORIA-DECISOES são
 * ENTREGÁVEIS: o operador instala por eles e outros agentes constroem sites a
 * partir deles. Da 1.0.6 à 1.0.13 os três ficaram carimbados `1.0.6`, afirmando
 * `ambiente.dominios_autorizados` como gate de indexação (superado na 1.0.12) e
 * `permalinks_decisao: manter-existente` como padrão (superado na 1.0.11), e
 * imprimindo contagens que a rodada da vez contradizia. Sete releases passaram
 * por cima disso sem que nada acusasse.
 *
 * Trazer os números à mão só adia: eles envelhecem de novo na próxima release.
 * Então:
 *
 * 1. **Número em documento entregável é GERADO, não digitado.** Ele sai de
 *    LEITURA DE DISCO no empacotamento — a primeira etapa do comando único, e
 *    portanto antes de o bundle ser montado, para que o que viaja seja o
 *    documento atualizado.
 * 2. **O que não pode ser gerado no momento da escrita sai como PENDÊNCIA
 *    NOMEADA**, nunca como número velho. A contagem por estado da rodada é
 *    resultado da rodada: ela não existe quando os documentos são escritos, e o
 *    carimbo diz isso e aponta para `suite/rodada.json`, que é o artefato
 *    gerado que a carrega.
 * 3. **`estatica.carimbo_de_release_nos_documentos` compara o que está no disco
 *    com o que a medição de agora produz.** É ele que impede a recorrência —
 *    vale mais do que a correção pontual, porque a correção pontual é o que já
 *    foi feito sete vezes.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

/**
 * Abertura de uma região gerada.
 *
 * Montada por concatenação de propósito: escrita inteira, ESTA função conteria
 * o marcador que ela procura, e o arquivo do gerador viraria uma quarta cópia
 * do carimbo dentro do pacote.
 *
 * SEM PREFIXO, e isso mudou na 1.0.15 por uma razão medida. Este pacote virou
 * template de criação de sites, e a renomeação de prefixo NÃO reescreve
 * `MEMORIA-DECISOES.md`: aquele documento narra defeitos observados citando
 * diretórios e nomes reais, e trocar o prefixo neles inventaria um passado que
 * não aconteceu. Com o prefixo dentro do marcador, o documento não reescrito
 * ficaria com marcadores que o gerador renomeado não encontraria mais, e a
 * região gerada deixaria de ser regenerada em silêncio. O marcador delimita uma
 * região dentro dos documentos do próprio pacote e não disputa espaço de nome
 * com ninguém: não precisa de prefixo, e sem ele o documento é o mesmo nos dois
 * prefixos.
 *
 * @param string $regiao Nome da região.
 * @return string
 */
function f3b_marca_inicio( string $regiao ): string {
	return '<!-- gerado:' . 'inicio=' . $regiao . ' -->';
}

/**
 * Fecho de uma região gerada.
 *
 * @param string $regiao Nome da região.
 * @return string
 */
function f3b_marca_fim( string $regiao ): string {
	return '<!-- gerado:' . 'fim=' . $regiao . ' -->';
}

/**
 * Quais documentos são ENTREGÁVEIS e quais regiões cada um carrega.
 *
 * Fonte única do escopo: o gerador escreve por esta lista e o detector cobra
 * por ela. Documento entregável sem região gerada é documento que envelhece
 * calado — foi o que aconteceu sete vezes seguidas.
 *
 * @return array<string,array<int,string>>
 */
function f3b_regioes_dos_documentos(): array {
	return array(
		'README.md'           => array( 'carimbo', 'arvore' ),
		'MANIFESTO.md'        => array( 'carimbo', 'inventario', 'fixtures' ),
		'MEMORIA-DECISOES.md' => array( 'carimbo' ),
	);
}

/**
 * Os FATOS MEDIDOS que entram no carimbo, todos por leitura de disco.
 *
 * Nenhum deles é resultado de rodada: tudo aqui existe antes de qualquer
 * checagem, que é a condição para o carimbo poder ser escrito na primeira etapa
 * e viajar dentro do bundle.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte daquele pacote.
 * @return array<string,string> Rótulo => valor.
 */
function f3b_fatos_medidos( string $raiz, string $suite ): array {
	$config = f3b_config( $raiz ) ?? array();
	$rel    = (array) ( $config['release'] ?? array() );

	$inventario = f3b_inventario( $suite );

	$requisitos = 0;

	foreach ( f3b_tsv( $suite . '/manifesto.tsv' ) as $linha ) {
		if ( '' !== trim( $linha[0] ?? '' ) ) {
			$requisitos++;
		}
	}

	$mapeadas  = 0;
	$pendentes = 0;

	foreach ( f3b_tsv( $suite . '/armadilhas.tsv' ) as $linha ) {
		if ( '' === trim( $linha[0] ?? '' ) ) {
			continue;
		}

		$checagem = trim( $linha[1] ?? '' );

		if ( '' === $checagem || '—' === $checagem ) {
			$pendentes++;
			continue;
		}

		$mapeadas++;
	}

	$detectores = count( f3b_com_piso( $suite ) );

	return array(
		'Identidade da release'                    => '`' . (string) ( $rel['identidade'] ?? '' ) . '`',
		'Implantador · tema · site-core'           => '`' . (string) ( $rel['implantador'] ?? '' ) . '` · `' . (string) ( $rel['tema'] ?? '' ) . '` · `' . (string) ( $rel['site_core'] ?? '' ) . '`',
		'Bundle desta identidade'                  => '`implantador-base-' . (string) ( $rel['implantador'] ?? '' ) . '.zip`',
		'Origens de release suportadas'            => (string) count( (array) ( $rel['anterior_suportada'] ?? array() ) ) . ' além da instalação limpa',
		'Caminhos exatos no inventário'            => (string) count( $inventario['exatos'] ),
		'Prefixos declarados no inventário'        => (string) count( $inventario['prefixos'] ),
		'Arquivos no pacote (fora de `dist/`)'     => (string) count( f3b_fontes( $raiz ) ),
		'Requisitos em `suite/manifesto.tsv`'      => (string) $requisitos,
		'Armadilhas com checagem mapeada'          => (string) $mapeadas,
		'Armadilhas em pendência declarada'        => (string) $pendentes,
		'Detectores com piso em disco'             => (string) $detectores,
		'Ramos de piso (negativa + positiva)'      => (string) ( $detectores * 2 ),
		'Páginas · posts declarados'               => (string) count( (array) ( $config['paginas'] ?? array() ) ) . ' · ' . (string) count( (array) ( $config['posts'] ?? array() ) ),
		'Contagem por estado da última rodada'     => 'PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu.',
	);
}

/**
 * O título de cada documento entregável, com a identidade da release.
 *
 * @param string $doc        Nome do documento.
 * @param string $identidade Identidade da release.
 * @return string
 */
function f3b_titulo_do_documento( string $doc, string $identidade ): string {
	$titulos = array(
		'README.md'           => '# implantador-base %s — leia-me',
		'MANIFESTO.md'        => '# Manifesto da release — implantador-base %s',
		'MEMORIA-DECISOES.md' => '# Memória de decisões — implantador-base %s',
	);

	return sprintf( $titulos[ $doc ] ?? '# implantador-base %s', $identidade );
}

/**
 * A árvore de arquivos do pacote, gerada de disco.
 *
 * `suite/fixtures/<detector>/` sai COLAPSADO com a contagem: expandir cada
 * fixture encheria a árvore de arquivos plantados de propósito e afogaria o que
 * o operador precisa ver.
 *
 * @param string $raiz Raiz do pacote.
 * @return string
 */
function f3b_arvore_do_pacote( string $raiz ): string {
	$linhas   = array();
	$fixtures = array();

	foreach ( f3b_fontes( $raiz ) as $rel ) {
		if ( preg_match( '#^suite/fixtures/([^/]+)/#', $rel, $m ) ) {
			$fixtures[ $m[1] ] = ( $fixtures[ $m[1] ] ?? 0 ) + 1;
			continue;
		}

		$linhas[] = $rel;
	}

	foreach ( $fixtures as $nome => $quantos ) {
		$linhas[] = 'suite/fixtures/' . $nome . '/  (' . $quantos . ' arquivo(s) de piso)';
	}

	sort( $linhas );

	return "```\n" . 'implantador-base/' . "\n" . implode( "\n", array_map( static fn( string $l ): string => '  ' . $l, $linhas ) ) . "\n```";
}

/**
 * O conteúdo de uma região gerada.
 *
 * @param string $raiz   Raiz do pacote.
 * @param string $suite  Diretório da suíte.
 * @param string $doc    Documento.
 * @param string $regiao Região.
 * @return string
 */
function f3b_conteudo_da_regiao( string $raiz, string $suite, string $doc, string $regiao ): string {
	if ( 'carimbo' === $regiao ) {
		$fatos      = f3b_fatos_medidos( $raiz, $suite );
		$identidade = trim( (string) ( $fatos['Identidade da release'] ?? '' ), '`' );

		$linhas = array(
			f3b_titulo_do_documento( $doc, $identidade ),
			'',
			'> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por',
			'> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece',
			'> em silêncio: foi o que aconteceu da 1.0.6 à 1.0.13. O que não pode ser gerado no momento da escrita',
			'> sai aqui como pendência nomeada, nunca como número velho.',
			'',
			'| Fato medido | Valor |',
			'|---|---|',
		);

		foreach ( $fatos as $rotulo => $valor ) {
			$linhas[] = '| ' . $rotulo . ' | ' . $valor . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'arvore' === $regiao ) {
		return "### Árvore de arquivos\n\nGerada de disco na montagem desta release. A allow-list executável que decide o que\nentra no bundle é `suite/inventario.tsv`.\n\n" . f3b_arvore_do_pacote( $raiz );
	}

	if ( 'inventario' === $regiao ) {
		$linhas = array(
			'### Inventário: caminho para papel',
			'',
			'Gerado de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco',
			'fora dela **aborta o build com o nome**. Manter aqui uma cópia escrita à mão criaria duas fontes.',
			'',
			'| Caminho | Papel |',
			'|---|---|',
		);

		$inventario = f3b_inventario( $suite );

		foreach ( $inventario['exatos'] as $caminho => $papel ) {
			$linhas[] = '| `' . $caminho . '` | ' . $papel . ' |';
		}

		foreach ( $inventario['prefixos'] as $caminho => $papel ) {
			$linhas[] = '| `' . $caminho . '` (prefixo) | ' . $papel . ' |';
		}

		return implode( "\n", $linhas );
	}

	if ( 'fixtures' === $regiao ) {
		$linhas = array(
			'### Piso: um detector, duas árvores',
			'',
			'Gerado de disco. Cada linha é um detector com fixture NEGATIVA — que reproduz o defeito e precisa ser',
			'acusada — e POSITIVA — que preserva o caso correto e precisa ficar em silêncio.',
			'',
			'| Detector | Arquivos de piso |',
			'|---|---|',
		);

		foreach ( f3b_com_piso( $suite ) as $detector ) {
			$linhas[] = '| `' . $detector . '` | ' . count( f3b_arquivos( $suite . '/fixtures/' . $detector ) ) . ' |';
		}

		return implode( "\n", $linhas );
	}

	return '';
}

/**
 * Substitui uma região marcada, ou devolve null quando os marcadores faltam.
 *
 * @param string $texto    Texto do documento.
 * @param string $regiao   Nome da região.
 * @param string $conteudo Conteúdo novo.
 * @return string|null
 */
function f3b_trocar_regiao( string $texto, string $regiao, string $conteudo ): ?string {
	$abre  = f3b_marca_inicio( $regiao );
	$fecha = f3b_marca_fim( $regiao );

	$ini = strpos( $texto, $abre );
	$fim = strpos( $texto, $fecha );

	if ( false === $ini || false === $fim || $fim < $ini ) {
		return null;
	}

	return substr( $texto, 0, $ini ) . $abre . "\n" . $conteudo . "\n" . substr( $texto, $fim );
}

/**
 * O que está DENTRO de uma região marcada, ou null quando ela não existe.
 *
 * @param string $texto  Texto do documento.
 * @param string $regiao Nome da região.
 * @return string|null
 */
function f3b_regiao_atual( string $texto, string $regiao ): ?string {
	$abre  = f3b_marca_inicio( $regiao );
	$fecha = f3b_marca_fim( $regiao );

	$ini = strpos( $texto, $abre );
	$fim = strpos( $texto, $fecha );

	if ( false === $ini || false === $fim || $fim < $ini ) {
		return null;
	}

	return trim( substr( $texto, $ini + strlen( $abre ), $fim - $ini - strlen( $abre ) ), "\n" );
}

/**
 * Regenera as regiões dos documentos entregáveis. Roda no EMPACOTAMENTO.
 *
 * Só escreve quando o conteúdo muda: reescrever igual mexeria na data de
 * modificação a cada rodada e faria `pacote.build_fresco` reprovar um artefato
 * que está correto.
 *
 * @param string $raiz  Raiz do pacote.
 * @param string $suite Diretório da suíte.
 * @return array{achados:array<int,string>,escritos:array<int,string>}
 */
function f3b_gerar_documentos( string $raiz, string $suite ): array {
	$achados  = array();
	$escritos = array();

	foreach ( f3b_regioes_dos_documentos() as $doc => $regioes ) {
		$caminho = $raiz . '/' . $doc;

		if ( ! is_file( $caminho ) ) {
			$achados[] = 'documento entregável ausente: ' . $doc;
			continue;
		}

		$texto   = (string) file_get_contents( $caminho );
		$antes   = $texto;

		foreach ( $regioes as $regiao ) {
			$novo = f3b_trocar_regiao( $texto, $regiao, f3b_conteudo_da_regiao( $raiz, $suite, $doc, $regiao ) );

			if ( null === $novo ) {
				$achados[] = $doc . ': região gerada "' . $regiao . '" sem marcadores no arquivo — não há onde escrever, '
					. 'e um documento entregável sem região gerada é um documento que envelhece calado';
				continue;
			}

			$texto = $novo;
		}

		if ( $texto !== $antes ) {
			file_put_contents( $caminho, $texto );
			$escritos[] = $doc;
		}
	}

	return array(
		'achados'  => $achados,
		'escritos' => $escritos,
	);
}

/**
 * O carimbo dos documentos entregáveis bate com a medição de agora.
 *
 * Três cláusulas, e as três reprovam:
 *
 * 1. **O documento existe** e traz cada região declarada, com os dois
 *    marcadores. Marcador ausente é a porta pela qual o documento sai do
 *    alcance do gerador e volta a envelhecer calado.
 * 2. **A identidade dentro do carimbo é a de `release.identidade`.** Cláusula
 *    própria, e não só um caso da comparação abaixo, porque é a divergência
 *    mais provável e a mensagem precisa dizer isso na cara.
 * 3. **O conteúdo de cada região é IGUAL ao que a medição de agora produz.** É
 *    a cláusula que pega número velho — o defeito de sete releases seguidas.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>,medidas:int}
 */
function f3b_ck_carimbo_de_release_nos_documentos( string $raiz ): array {
	$suite  = $raiz . '/suite';
	$config = f3b_config( $raiz );

	if ( null === $config ) {
		return array(
			'ok'      => false,
			'achados' => array( 'config/site.json ausente ou inválido na raiz varrida: sem release.identidade não há carimbo a conferir' ),
			'medidas' => 1,
		);
	}

	$identidade = (string) ( $config['release']['identidade'] ?? '' );
	$achados    = array();
	$medidas    = 0;

	foreach ( f3b_regioes_dos_documentos() as $doc => $regioes ) {
		$caminho = $raiz . '/' . $doc;

		if ( ! is_file( $caminho ) ) {
			$achados[] = 'documento entregável ausente: ' . $doc . ' — o operador instala por ele e outro agente '
				. 'constrói a partir dele';
			continue;
		}

		$texto = (string) file_get_contents( $caminho );

		foreach ( $regioes as $regiao ) {
			$medidas++;
			$atual = f3b_regiao_atual( $texto, $regiao );

			if ( null === $atual ) {
				$achados[] = $doc . ': região gerada "' . $regiao . '" sem marcadores — documento entregável fora do '
					. 'alcance do gerador volta a carregar número digitado à mão, que envelhece em silêncio';
				continue;
			}

			$esperado = f3b_conteudo_da_regiao( $raiz, $suite, $doc, $regiao );

			if ( 'carimbo' === $regiao && '' !== $identidade && ! str_contains( $atual, $identidade ) ) {
				$achados[] = $doc . ': o carimbo não traz a identidade declarada em release.identidade (' . $identidade
					. '). Documento entregável carimbado com outra release descreve um pacote que não é este';
				continue;
			}

			if ( trim( $atual ) !== trim( $esperado ) ) {
				$achados[] = $doc . ': a região "' . $regiao . '" está DIVERGENTE da medição de agora — o documento '
					. 'afirma um número que a leitura de disco contradiz. Número em documento entregável é gerado no '
					. 'empacotamento, nunca digitado';
			}
		}
	}

	return array(
		'ok'      => array() === $achados,
		'achados' => $achados,
		'medidas' => $medidas,
	);
}
