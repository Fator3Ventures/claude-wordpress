<?php
/**
 * Fixture POSITIVA: a lista SAI do metadado, e não há segunda fonte.
 *
 * `gates_de_fase()` não contém nome de checagem nenhum: ela devolve o que as
 * linhas desta execução declararam. Os dois emissores nomeiam a própria
 * checagem com literal, e nenhum deles é entregável do gate de aplicação.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Entrega {

	public static function gates_de_fase(): array {
		return F3Base_Imp_Relatorio::nomes_com_gate( 'fase' );
	}

	public static function entregaveis_do_gate_de_aplicacao(): array {
		return array( 'entrega.tema', 'entrega.site_core' );
	}

	public static function conferir(): void {
		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'entrega.rodada_limpa',
			'o registro da rodada não viaja neste pacote.',
			array( 'evidencia' => 'pendencia-externa', 'fase' => 'build', 'gate' => 'fase' )
		);

		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'orcamento.medicao_de_pagina',
			'a medição é de navegador e não roda neste host.',
			array( 'evidencia' => 'pendencia-externa', 'fase' => 'campo', 'gate' => 'fase' )
		);
	}
}
