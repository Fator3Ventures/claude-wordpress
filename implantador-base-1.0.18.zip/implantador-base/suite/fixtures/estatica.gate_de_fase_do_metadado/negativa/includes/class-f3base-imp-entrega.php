<?php
/**
 * Fixture NEGATIVA: o estado de 1.0.17 inteiro.
 *
 * `gates_de_fase()` é uma LISTA LITERAL com UM nome, e o metadado `gate=fase`
 * marca DOIS emissores. As duas fontes divergem, e a divergência sai impressa
 * dentro de uma linha só do log. De quebra, `entrega.rodada_limpa` aparece
 * também na lista do gate de aplicação: o mesmo nome decidindo e não decidindo
 * a autodesativação.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Entrega {

	public static function gates_de_fase(): array {
		return array( 'entrega.rodada_limpa' );
	}

	public static function entregaveis_do_gate_de_aplicacao(): array {
		return array( 'entrega.tema', 'entrega.site_core', 'entrega.rodada_limpa' );
	}

	public static function conferir(): void {
		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'entrega.rodada_limpa',
			'o registro da rodada não viaja neste pacote.',
			array( 'evidencia' => 'pendencia-externa', 'fase' => 'build', 'gate' => 'fase' )
		);

		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'orcamento.medicao_de_pagina',
			'a medição é de navegador e não roda neste host.',
			array( 'evidencia' => 'pendencia-externa', 'fase' => 'campo', 'gate' => 'fase' )
		);
	}
}
