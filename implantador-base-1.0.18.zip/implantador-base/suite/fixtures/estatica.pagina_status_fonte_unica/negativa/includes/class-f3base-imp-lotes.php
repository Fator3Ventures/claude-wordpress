<?php
/**
 * Fixture NEGATIVA: a página de posts nasce com o literal escrito à mão.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Garante a página que hospeda o índice do blog.
	 *
	 * @return int
	 */
	public static function garantir_pagina_de_posts(): int {
		return (int) wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => 'Blog',
				'post_content' => '',
			)
		);
	}
}
