<?php
/**
 * Fixture NEGATIVA: o produtor existe e ninguém passa por ele.
 *
 * O defeito plantado é o da 1.0.12: a etapa de conteúdo lê a intenção
 * declarada e a escreve direto no objeto, sem consultar a guarda. O produtor
 * continua ali, e é isso que torna o defeito difícil de ver a olho nu — existe
 * um lugar certo, e o código simplesmente não passa por ele.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Conteúdo gerenciado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * A âncora do produtor único do status efetivo de página.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_de_status_de_pagina(): array {
		return array(
			'funcao'  => 'status_efetivo_de_pagina',
			'caminho' => 'paginas.*.status',
		);
	}

	/**
	 * O produtor único, que ninguém chama.
	 *
	 * @param string $ref       Referência lógica.
	 * @param string $declarado Status declarado.
	 * @return array<string,mixed>
	 */
	public static function status_efetivo_de_pagina( string $ref, string $declarado ): array {
		$faltando = array();

		if ( 'privacidade' === $ref && '' === (string) F3Base_Imp_Config::obter( 'contato.controlador.razao_social', '' ) ) {
			$faltando[] = 'contato.controlador.razao_social';
		}

		return array(
			'status'    => array() === $faltando ? $declarado : 'draft',
			'declarado' => $declarado,
			'faltando'  => $faltando,
		);
	}

	/**
	 * Aplica uma página declarada, decidindo o status por conta própria.
	 *
	 * @param int $indice Índice.
	 * @return array<string,mixed>
	 */
	public static function aplicar_pagina( int $indice ): array {
		return array(
			'post_title'  => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.titulo', '' ),
			'post_status' => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.status', 'draft' ),
		);
	}
}
