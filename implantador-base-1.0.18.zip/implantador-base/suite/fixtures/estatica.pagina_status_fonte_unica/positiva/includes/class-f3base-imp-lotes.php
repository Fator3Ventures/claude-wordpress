<?php
/**
 * Fixture POSITIVA: a página de posts também passa pelo produtor.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Garante a página que hospeda o índice do blog.
	 *
	 * @return int
	 */
	public static function garantir_pagina_de_posts(): int {
		$ref = 'blog';

		return (int) wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => F3Base_Imp_Conteudo::status_efetivo_de_pagina( $ref, 'publish' )['status'],
				'post_title'   => 'Blog',
				'post_content' => '',
			)
		);
	}
}
