<?php
/**
 * Fixture POSITIVA: o status efetivo de página sai de um produtor só.
 *
 * A âncora nomeia o produtor e o caminho da intenção; o único leitor do
 * caminho é quem chama o produtor; e o valor desejado que chega ao objeto é o
 * que o produtor devolveu.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Conteúdo gerenciado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * A âncora do produtor único do status efetivo de página.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_de_status_de_pagina(): array {
		return array(
			'funcao'  => 'status_efetivo_de_pagina',
			'caminho' => 'paginas.*.status',
		);
	}

	/**
	 * O produtor único.
	 *
	 * @param string $ref       Referência lógica.
	 * @param string $declarado Status declarado.
	 * @return array<string,mixed>
	 */
	public static function status_efetivo_de_pagina( string $ref, string $declarado ): array {
		$faltando = array();

		if ( 'privacidade' === $ref && '' === (string) F3Base_Imp_Config::obter( 'contato.controlador.razao_social', '' ) ) {
			$faltando[] = 'contato.controlador.razao_social';
		}

		return array(
			'status'    => array() === $faltando ? $declarado : 'draft',
			'declarado' => $declarado,
			'faltando'  => $faltando,
		);
	}

	/**
	 * Aplica uma página declarada.
	 *
	 * @param int $indice Índice.
	 * @return array<string,mixed>
	 */
	public static function aplicar_pagina( int $indice ): array {
		$ref    = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
		$status = self::status_efetivo_de_pagina( $ref, (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.status', 'draft' ) );

		return array(
			'post_title'  => (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.titulo', '' ),
			'post_status' => $status['status'],
		);
	}
}
