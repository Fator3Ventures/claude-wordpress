<?php
/**
 * Fixture POSITIVA: PHP válido. A checagem precisa ficar em silêncio.
 */
declare( strict_types = 1 );

function f3base_fixture_correta( int $a ): int {
	return $a + 1;
}
