<?php
/**
 * Fixture NEGATIVA: parêntese não fechado. `php -l` precisa reprovar, e o
 * comando único precisa sair com código diferente de zero por causa disso —
 * o defeito medido era imprimir FALHA e sair 0.
 */
function f3base_fixture_quebrada( $a {
	return $a;
}
