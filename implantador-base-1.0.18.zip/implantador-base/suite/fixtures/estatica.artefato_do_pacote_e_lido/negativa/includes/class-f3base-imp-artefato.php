<?php
/**
 * Fixture NEGATIVA de `estatica.artefato_do_pacote_e_lido`: a 1.0.15.
 *
 * Dois defeitos plantados:
 *
 * 1. `f3base.zip` viaja na RAIZ do pacote e nenhum caminho de instalação o abre
 *    — a resolução de zip embutido só procura sob os prefixos declarados;
 * 2. quem PROVA o entregável monta o caminho do artefato por conta própria, em
 *    vez de passar pelo resolvedor: o entregável prova um artefato e a
 *    instalação usa outro.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Resolução de artefatos.
 */
final class F3Base_Imp_Artefato {

	/**
	 * Prefixos onde um zip embutido pode estar.
	 */
	public const PREFIXOS_DE_ZIP = array( 'assets/plugins/', 'assets/' );

	/**
	 * Âncora da fonte única.
	 *
	 * @return array<string,string>
	 */
	public static function artefato_fonte_unica_declarada(): array {
		return array(
			'resolvedor' => 'artefato_do_papel',
			'instala'    => 'aplicar_tema,aplicar_site_core',
			'prova'      => 'conferir_tema,conferir_site_core',
		);
	}

	/**
	 * Resolve o artefato de um papel.
	 *
	 * @param string $papel Papel.
	 * @return array<string,mixed>
	 */
	public static function artefato_do_papel( string $papel ): array {
		return array(
			'papel'      => $papel,
			'tipo'       => 'diretorio',
			'caminho'    => '',
			'candidatos' => array(),
		);
	}

	/**
	 * Instala o tema.
	 *
	 * @return string
	 */
	public static function aplicar_tema(): string {
		$artefato = self::artefato_do_papel( 'tema' );

		return (string) $artefato['caminho'];
	}

	/**
	 * Instala o site-core.
	 *
	 * @return string
	 */
	public static function aplicar_site_core(): string {
		$artefato = self::artefato_do_papel( 'site_core' );

		return (string) $artefato['caminho'];
	}

	/**
	 * Prova o entregável do tema — com a lista própria, que é o defeito.
	 *
	 * @param string $slug Slug.
	 * @return bool
	 */
	public static function conferir_tema( string $slug ): bool {
		return is_readable( 'assets/' . $slug . '-tema.zip' ) || is_dir( 'fontes/tema' );
	}

	/**
	 * Prova o entregável do site-core.
	 *
	 * @return bool
	 */
	public static function conferir_site_core(): bool {
		$artefato = self::artefato_do_papel( 'site_core' );

		return '' !== (string) $artefato['tipo'];
	}
}
