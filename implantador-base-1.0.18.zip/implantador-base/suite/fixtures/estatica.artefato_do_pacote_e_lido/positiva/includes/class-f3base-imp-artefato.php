<?php
/**
 * Fixture POSITIVA de `estatica.artefato_do_pacote_e_lido`: o caso correto.
 *
 * O zip que viaja no pacote mora sob um prefixo declarado — é o slot do
 * operador, que a resolução de fato abre — e quem prova o entregável passa pelo
 * MESMO resolvedor que instala, sem montar caminho por conta própria.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Resolução de artefatos.
 */
final class F3Base_Imp_Artefato {

	/**
	 * Prefixos onde um zip embutido pode estar.
	 */
	public const PREFIXOS_DE_ZIP = array( 'assets/plugins/', 'assets/' );

	/**
	 * Âncora da fonte única.
	 *
	 * @return array<string,string>
	 */
	public static function artefato_fonte_unica_declarada(): array {
		return array(
			'resolvedor' => 'artefato_do_papel',
			'instala'    => 'aplicar_tema,aplicar_site_core',
			'prova'      => 'conferir_tema,conferir_site_core',
		);
	}

	/**
	 * Resolve o artefato de um papel.
	 *
	 * @param string $papel Papel.
	 * @return array<string,mixed>
	 */
	public static function artefato_do_papel( string $papel ): array {
		return array(
			'papel'      => $papel,
			'tipo'       => 'diretorio',
			'caminho'    => '',
			'candidatos' => array(),
		);
	}

	/**
	 * Instala o tema.
	 *
	 * @return string
	 */
	public static function aplicar_tema(): string {
		$artefato = self::artefato_do_papel( 'tema' );

		return (string) $artefato['caminho'];
	}

	/**
	 * Instala o site-core.
	 *
	 * @return string
	 */
	public static function aplicar_site_core(): string {
		$artefato = self::artefato_do_papel( 'site_core' );

		return (string) $artefato['caminho'];
	}

	/**
	 * Prova o entregável do tema pelo MESMO resolvedor que instala.
	 *
	 * @return bool
	 */
	public static function conferir_tema(): bool {
		$artefato = self::artefato_do_papel( 'tema' );

		return '' !== (string) $artefato['tipo'];
	}

	/**
	 * Prova o entregável do site-core pelo MESMO resolvedor que instala.
	 *
	 * @return bool
	 */
	public static function conferir_site_core(): bool {
		$artefato = self::artefato_do_papel( 'site_core' );

		return '' !== (string) $artefato['tipo'];
	}
}
