<?php
/**
 * Title: Fixture negativa executada
 * Slug: f3base/fixture-quebrada
 *
 * O arquivo cru parece íntegro; o defeito só aparece DEPOIS de executado,
 * porque o fechamento sai de dentro de uma condição que nunca é verdadeira.
 */

$f3base_fixture_fechar = false;

?>
<!-- wp:group -->
<div class="wp-block-group"><!-- wp:paragraph -->
<p><?php esc_html_e( 'O fechamento do grupo depende de uma condição falsa.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></div>
<?php if ( $f3base_fixture_fechar ) : ?>
<!-- /wp:group -->
<?php endif; ?>
