<?php
/**
 * Title: Fixture positiva executada
 * Slug: f3base/fixture-correta
 */

?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph -->
<p><?php esc_html_e( 'Balanceado depois de executado.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
