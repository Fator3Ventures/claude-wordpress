<?php
/**
 * Fixture POSITIVA: o literal está DENTRO de um ramo de if/else cujo ramo
 * irmão emite o outro veredito. Quem decide ali é o `if`; o literal só nomeia
 * de que lado aquele ramo está. Isso é idioma legítimo, e o detector precisa
 * ficar em silêncio sobre ele — senão a regra proíbe a forma correta.
 */
declare( strict_types = 1 );

function f3base_fixture_com_escopo( string $arquivo ): void {
	if ( is_file( $arquivo ) ) {
		afirmar( true, 'checagem.arquivo_presente', 'arquivo encontrado' );
	} else {
		afirmar( false, 'checagem.arquivo_presente', 'arquivo ausente' );
	}
}

function f3base_fixture_com_escopo_invertido( int $total ): void {
	if ( 0 === $total ) {
		check( false, 'checagem.tem_item', 'nenhum item' );
	} else {
		check( true, 'checagem.tem_item', 'itens encontrados' );
	}
}
