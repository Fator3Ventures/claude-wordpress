<?php
/**
 * Fixture NEGATIVA: veredito decidido no código-fonte, não observado.
 * Nenhuma destas três linhas mede coisa alguma; todas imprimem OK para sempre.
 */
declare( strict_types = 1 );

function f3base_fixture_decorativa(): void {
	check( true, 'checagem.decorativa', 'aprovada sem medir nada' );
	estado( 1, 'checagem.sempre_ok', 'contador de teto' );
	assert( 1, 'invariante que ninguem avalia' );
}
