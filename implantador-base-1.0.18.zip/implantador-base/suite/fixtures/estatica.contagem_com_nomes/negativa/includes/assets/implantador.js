/**
 * Fixture NEGATIVA: a tela conta as linhas renderizadas e não guarda os nomes.
 */
( function () {
	'use strict';

	const renderizadas = {};

	function registrar( estado ) {
		renderizadas[ String( estado ) ] = ( renderizadas[ String( estado ) ] || 0 ) + 1;
	}

	function rodape( carga ) {
		return 'checagens do relatório: ' + String( carga.checagens_falha || 0 ) +
			' FALHA, ' + String( carga.checagens_blocked || 0 ) + ' BLOCKED' +
			' · linhas desta tela: ' + String( renderizadas.FALHA || 0 ) + ' FALHA';
	}

	window.f3baseFixture = { registrar: registrar, rodape: rodape };
}() );
