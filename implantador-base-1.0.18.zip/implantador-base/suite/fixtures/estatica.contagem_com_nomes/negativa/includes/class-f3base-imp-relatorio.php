<?php
/**
 * Fixture NEGATIVA: o rodapé conta e NÃO nomeia.
 *
 * Reproduz o defeito medido: o cabeçalho dizia "5 FALHA e 6 BLOCKED" em
 * checagens e a tela mostrava UMA unidade em FALHA. As outras rodaram dentro de
 * unidades que fecharam OK e não tinham linha nenhuma — o operador ficou com um
 * número e nenhum nome para procurar.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Relatorio {

	public static function rodape(): string {
		return sprintf(
			'checagens do relatório: %1$d FALHA e %2$d BLOCKED',
			F3Base_Imp_Relatorio::checagens_em_falha(),
			F3Base_Imp_Relatorio::checagens_em_blocked()
		);
	}

	public static function encerramento(): string {
		$contagem = F3Base_Imp_Relatorio::contagem();
		$partes   = array();

		foreach ( $contagem as $estado => $quantas ) {
			$partes[] = $estado . ': ' . $quantas;
		}

		return implode( ' | ', $partes );
	}
}
