/**
 * Fixture POSITIVA: o contador e o nomeador moram na MESMA função.
 *
 * Separar um do outro é abrir a porta para o número existir sem a lista.
 */
( function () {
	'use strict';

	const renderizadas = {};
	const nomesRenderizados = {};

	function registrar( estado, checagem ) {
		const chave = String( estado );

		renderizadas[ chave ] = ( renderizadas[ chave ] || 0 ) + 1;

		if ( ! nomesRenderizados[ chave ] ) {
			nomesRenderizados[ chave ] = [];
		}

		nomesRenderizados[ chave ].push( String( checagem ) );
	}

	function nomesPorEstado( mapa ) {
		const fonte = mapa && typeof mapa === 'object' ? mapa : {};

		return [ 'FALHA', 'BLOCKED', 'WARN' ].map( function ( estado ) {
			const lista = Array.isArray( fonte[ estado ] ) ? fonte[ estado ] : [];

			return estado + ': ' + ( lista.length === 0 ? 'nenhum' : lista.join( ', ' ) );
		} ).join( ' | ' );
	}

	function rodape( carga ) {
		return 'checagens do relatório: ' + String( carga.checagens_falha || 0 ) +
			' FALHA, ' + String( carga.checagens_blocked || 0 ) + ' BLOCKED · ' +
			nomesPorEstado( carga.checagens_nomes ) +
			' · linhas desta tela: ' + String( renderizadas.FALHA || 0 ) +
			' FALHA · ' + nomesPorEstado( nomesRenderizados );
	}

	window.f3baseFixture = { registrar: registrar, rodape: rodape };
}() );
