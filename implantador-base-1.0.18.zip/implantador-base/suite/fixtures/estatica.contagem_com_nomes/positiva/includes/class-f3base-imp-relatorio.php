<?php
/**
 * Fixture POSITIVA: contagem e lista de nomes saem juntas, sempre.
 *
 * A pergunta do operador nunca é "quantos?", é "quais?". Estado OK continua
 * podendo sair resumido; o que não pode existir é estado ruim invisível.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Relatorio {

	public static function rodape(): string {
		$nomes = F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' );

		return sprintf(
			'checagens do relatório: %1$d FALHA (%2$s) e %3$d BLOCKED (%4$s)',
			F3Base_Imp_Relatorio::checagens_em_falha(),
			F3Base_Imp_Relatorio::nomes_em( 'FALHA', $nomes['FALHA'] ),
			F3Base_Imp_Relatorio::checagens_em_blocked(),
			F3Base_Imp_Relatorio::nomes_em( 'BLOCKED', $nomes['BLOCKED'] )
		);
	}

	public static function encerramento(): string {
		return F3Base_Imp_Relatorio::resumo_por_estado(
			F3Base_Imp_Relatorio::contagem(),
			F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' )
		);
	}
}
