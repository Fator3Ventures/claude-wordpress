<?php
/**
 * Sonda com TETO e PISO na mesma medição, para a checagem que ela declara.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

$achados = array();

if ( 2 !== 1 + 1 ) {
	$achados[] = 'teto: sonda.com_piso reprovou o caso correto';
}

if ( 3 === 1 + 1 ) {
	$achados[] = 'piso: sonda.com_piso deixou passar o caso errado';
}

echo json_encode( array( 'sonda.com_piso' => array( 'achados' => $achados ) ) );
