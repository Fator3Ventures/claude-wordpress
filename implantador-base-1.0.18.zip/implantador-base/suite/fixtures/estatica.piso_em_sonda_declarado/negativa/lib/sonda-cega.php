<?php
/**
 * Sonda que menciona a checagem e NÃO tem os dois ramos: piso nenhum.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

$achados = array();

if ( ! function_exists( 'sonda_cega' ) ) {
	$achados[] = 'sonda.cega: a função não existe';
}

echo json_encode( array( 'sonda.cega' => array( 'achados' => $achados ) ) );
