<?php
/**
 * Sonda que tem os dois ramos e NÃO mede a checagem declarada.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

$achados = array();

if ( 2 !== 1 + 1 ) {
	$achados[] = 'teto: a soma correta reprovou';
}

if ( 3 === 1 + 1 ) {
	$achados[] = 'piso: a soma errada passou';
}

echo json_encode( array( 'outra.coisa' => array( 'achados' => $achados ) ) );
