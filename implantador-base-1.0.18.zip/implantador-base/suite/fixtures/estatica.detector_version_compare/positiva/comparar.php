<?php
/**
 * Fixture POSITIVA: operador da lista fechada.
 */
declare( strict_types = 1 );

function f3base_fixture_boa( string $a, string $b ): bool {
	return ! version_compare( $a, $b, '<' );
}
