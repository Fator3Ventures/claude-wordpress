<?php
/**
 * Fixture NEGATIVA: operador fora da lista fechada, e chamada sem operador.
 * O primeiro explode em runtime no PHP 8; o segundo devolve int, nunca bool.
 */
declare( strict_types = 1 );

function f3base_fixture_ruim( string $a, string $b ): bool {
	if ( version_compare( $a, $b, '===' ) ) {
		return true;
	}

	return (bool) version_compare( $a, $b );
}
