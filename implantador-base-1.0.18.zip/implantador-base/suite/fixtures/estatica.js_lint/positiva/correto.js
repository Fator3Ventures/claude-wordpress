/* Fixture POSITIVA: JavaScript válido. A checagem precisa ficar em silêncio. */
( function () {
	'use strict';

	function somar( a, b ) {
		return a + b;
	}

	window.f3baseFixture = somar;
}() );
