/* Fixture NEGATIVA: chave não fechada. `node --check` precisa reprovar. */
( function () {
	const alvo = document.querySelector( '.f3base-alvo' );

	if ( alvo ) {
		alvo.textContent = 'sem fechar o bloco';
}() );
