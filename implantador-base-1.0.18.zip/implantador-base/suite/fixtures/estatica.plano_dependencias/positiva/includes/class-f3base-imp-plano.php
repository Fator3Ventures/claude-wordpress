<?php
/**
 * Tabela de dependências correta: todo alvo existe em grupos().
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Fixture. */
final class F3Base_Imp_Plano {

	/**
	 * Grupos declarados.
	 *
	 * @return string[]
	 */
	public static function grupos(): array {
		return array( 'preflight', 'conteudo', 'midia', 'entrega' );
	}

	/**
	 * Toda dependência aponta para grupo declarado.
	 *
	 * @return array<string,string[]>
	 */
	public static function dependencias(): array {
		return array(
			'conteudo' => array( 'midia' ),
			'entrega'  => array(),
		);
	}

	/**
	 * Confere a própria tabela.
	 *
	 * @return array{achados:string[],medidas:int}
	 */
	public static function conferir(): array {
		$grupos  = self::grupos();
		$achados = array();
		$medidas = 0;

		foreach ( self::dependencias() as $grupo => $alvos ) {
			$grupo = (string) $grupo;
			$medidas++;

			if ( ! in_array( $grupo, $grupos, true ) ) {
				$achados[] = 'grupo "' . $grupo . '" declara dependências e não consta de grupos()';
			}

			foreach ( (array) $alvos as $alvo ) {
				$alvo = (string) $alvo;
				$medidas++;

				if ( ! in_array( $alvo, $grupos, true ) ) {
					$achados[] = 'grupo "' . $grupo . '" depende de "' . $alvo . '", que não existe em grupos(): dependência para unidade inexistente é defeito de configuração, e nunca uma aresta que some';
					continue;
				}

				if ( $alvo === $grupo ) {
					$achados[] = 'grupo "' . $grupo . '" depende de si mesmo';
				}
			}
		}

		return array(
			'achados' => $achados,
			'medidas' => $medidas,
		);
	}
}
