<?php
/**
 * Fixture NEGATIVA: a leitura de série ANTERIOR à 1.0.15, com o corte ingênuo.
 *
 * O slug sai do último traço do resto e mais nada. É esta implementação que
 * produziu, no site real, a série `f3base-site-core-f3base-anterior-1788152131`
 * — uma cópia só, teto de 2 nunca alcançado, poda que nunca acontece, e o log
 * afirmando "nada acima do teto".
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Recorte da classe: só o que a leitura de série usa.
 */
final class F3Base_Imp_Plugins {

	/** Marca de reconhecimento de cópia preservada, sem o ponto. */
	public const MARCA_ANTERIOR = '-f3base-anterior-';

	/** Prefixo de construção de cópia preservada, com o ponto. */
	public const PREFIXO_BACKUP = '.f3base-anterior-';

	/**
	 * Slug e carimbo de um nome de cópia preservada, SEM normalização.
	 *
	 * @param string $nome Nome do diretório.
	 * @return array{slug:string,quando:int}|array{}
	 */
	public static function serie_do_nome( string $nome ): array {
		if ( ! str_starts_with( $nome, self::PREFIXO_BACKUP ) ) {
			return array();
		}

		$resto = substr( $nome, strlen( self::PREFIXO_BACKUP ) );
		$corte = strrpos( $resto, '-' );

		if ( false === $corte || 0 === $corte ) {
			return array();
		}

		return array(
			'slug'   => substr( $resto, 0, $corte ),
			'quando' => (int) substr( $resto, $corte + 1 ),
		);
	}
}
