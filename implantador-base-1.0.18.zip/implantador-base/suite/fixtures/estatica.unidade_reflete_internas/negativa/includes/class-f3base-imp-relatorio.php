<?php
/**
 * Fixture: a ordem de severidade, declarada UMA vez.
 *
 * Só FALHA, BLOCKED e WARN promovem; N/A, OK e WAIVED pesam zero e empatados,
 * e empate conserva o estado incumbente. Ela está aqui nos dois lados para que
 * a acusação do lado negativo seja sobre o que a fixture planta — a promoção
 * cega ao gate e a unidade que não reflete —, e não sobre a ausência da ordem.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Relatorio {

	public const OK      = 'OK';
	public const FALHA   = 'FALHA';
	public const BLOCKED = 'BLOCKED';
	public const NA      = 'N/A';
	public const WAIVED  = 'WAIVED';
	public const WARN    = 'WARN';

	public static function ordem_de_severidade(): array {
		return array(
			self::WAIVED  => 0,
			self::NA      => 0,
			self::OK      => 0,
			self::WARN    => 1,
			self::BLOCKED => 2,
			self::FALHA   => 3,
		);
	}

	public static function estado_mais_severo( string $a, string $b ): string {
		$ordem = self::ordem_de_severidade();

		$a = isset( $ordem[ $a ] ) ? $a : self::FALHA;
		$b = isset( $ordem[ $b ] ) ? $b : self::FALHA;

		return $ordem[ $b ] > $ordem[ $a ] ? $b : $a;
	}
}
