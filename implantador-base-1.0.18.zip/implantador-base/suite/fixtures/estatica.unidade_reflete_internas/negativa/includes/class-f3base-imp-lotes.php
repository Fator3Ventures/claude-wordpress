<?php
/**
 * Fixture NEGATIVA: os dois modos de a unidade mentir sobre o que mediu.
 *
 * `processar()` PROMOVE, mas cego ao gate: ele engole a evidência de fase que
 * este host não produz, e a unidade `entrega` fecharia BLOCKED em toda
 * instalação, para sempre, por desenho — a mesma armadilha que a 1.0.7 desfez
 * no gate da autodesativação.
 *
 * `processar_retomada()` não promove nada: emite o estado que a etapa devolveu,
 * cru. É o defeito medido na 1.0.8 — a linha 48 do relatório era `OK entrega —
 * "todos os entregáveis do gate de aplicação fecharam sem BLOCKED"` e a linha
 * 49, DENTRO dela, era `FALHA ↳ mcp.canal_unico`.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Lotes {

	/* A âncora existe — e nenhuma promoção a consulta, que é o defeito. */
	public const GATE_QUE_DECIDE = 'aplicacao';

	public static function processar( string $modo, int $indice ): array {
		$marca     = F3Base_Imp_Relatorio::marcar();
		$resultado = self::executar( $modo, $indice );
		$internas  = self::checagens_da_unidade( $marca );

		$resultado['estado'] = self::veredito_da_unidade( $resultado['estado'], $internas['nomeadas'] );

		F3Base_Imp_Relatorio::emitir_unidade(
			$resultado['estado'],
			$resultado['rotulo'],
			$resultado['motivo'],
			array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' )
		);

		return $resultado;
	}

	public static function processar_retomada( string $modo, int $indice ): array {
		$resultado = self::executar( $modo, $indice );

		F3Base_Imp_Relatorio::emitir_unidade(
			$resultado['estado'],
			$resultado['rotulo'],
			$resultado['motivo'],
			array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' )
		);

		return $resultado;
	}

	public static function veredito_da_unidade( string $estado_da_unidade, array $internas ): string {
		$estado = $estado_da_unidade;

		foreach ( $internas as $interna ) {
			$estado = F3Base_Imp_Relatorio::estado_mais_severo( $estado, (string) $interna['estado'] );
		}

		return $estado;
	}
}
