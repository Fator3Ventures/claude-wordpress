<?php
/**
 * Fixture POSITIVA: a promoção existe, e ela olha o GATE.
 *
 * Os dois emissores de linha de unidade passam pelo mesmo `veredito_da_unidade()`,
 * que decide pela checagem de gate `aplicacao` e trata a de fase como pendência
 * nomeada — fora do veredito, dentro do relatório.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Lotes {

	public const GATE_QUE_DECIDE = 'aplicacao';

	public static function processar( string $modo, int $indice ): array {
		$marca     = F3Base_Imp_Relatorio::marcar();
		$resultado = self::executar( $modo, $indice );
		$internas  = self::checagens_da_unidade( $marca );

		$reflexo             = self::veredito_da_unidade( $resultado['estado'], $internas['nomeadas'] );
		$resultado['estado'] = $reflexo['estado'];
		$resultado['motivo'] = $resultado['motivo'] . ' ' . $reflexo['nota'];

		F3Base_Imp_Relatorio::emitir_unidade(
			$resultado['estado'],
			$resultado['rotulo'],
			$resultado['motivo'],
			array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' )
		);

		return $resultado;
	}

	public static function processar_retomada( string $modo, int $indice ): array {
		$marca     = F3Base_Imp_Relatorio::marcar();
		$resultado = self::executar( $modo, $indice );
		$internas  = self::checagens_da_unidade( $marca );

		$reflexo             = self::veredito_da_unidade( $resultado['estado'], $internas['nomeadas'] );
		$resultado['estado'] = $reflexo['estado'];

		F3Base_Imp_Relatorio::emitir_unidade(
			$resultado['estado'],
			$resultado['rotulo'],
			$resultado['motivo'],
			array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' )
		);

		return $resultado;
	}

	public static function veredito_da_unidade( string $estado_da_unidade, array $internas ): array {
		$estado = $estado_da_unidade;
		$fase   = array();

		foreach ( $internas as $interna ) {
			if ( self::GATE_QUE_DECIDE !== (string) ( $interna['gate'] ?? self::GATE_QUE_DECIDE ) ) {
				$fase[] = (string) $interna['nome'] . ' (' . (string) $interna['estado'] . ')';
				continue;
			}

			$estado = F3Base_Imp_Relatorio::estado_mais_severo( $estado, (string) $interna['estado'] );
		}

		return array(
			'estado' => $estado,
			'nota'   => array() === $fase ? '' : 'Pendência(s) de FASE, fora do veredito: ' . implode( ', ', $fase ) . '.',
		);
	}
}
