<?php
/**
 * Troca de diretório correta.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/** Fixture. */
final class F3Base_Imp_Troca_Correta {

	/**
	 * Marca usada só para RECONHECER o nome antigo. Não constrói caminho.
	 */
	public const MARCA_ANTERIOR = '-f3base-anterior-';

	/**
	 * Constrói o caminho de backup com o ponto na frente.
	 *
	 * @param string $destino Diretório de destino.
	 * @return string
	 */
	public static function caminho_do_backup( string $destino ): string {
		$pai  = dirname( $destino );
		$slug = basename( $destino );

		return $pai . '/.f3base-anterior-' . $slug . '-' . time();
	}

	/**
	 * Reconhecimento do nome antigo: literal como ARGUMENTO, nunca concatenado.
	 *
	 * Está aqui para provar que o detector separa construir de reconhecer — a
	 * migração precisa reconhecer o nome sem ponto, e acusá-la seria proibir a
	 * própria correção.
	 *
	 * @param string $nome Nome do diretório.
	 * @return bool
	 */
	public static function e_backup_antigo( string $nome ): bool {
		return str_contains( $nome, self::MARCA_ANTERIOR ) || str_contains( $nome, '-f3base-anterior-' );
	}
}
