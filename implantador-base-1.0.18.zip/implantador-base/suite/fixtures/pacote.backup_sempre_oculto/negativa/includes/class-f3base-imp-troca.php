<?php
/**
 * Troca de diretório com o defeito plantado.
 *
 * O comentário abaixo cita `<destino>-f3base-anterior-<ts>` de propósito: a
 * varredura mede o que EXECUTA, e prosa que descreve a armadilha não pode
 * reprovar o arquivo. Quem reprova é a linha de código logo adiante.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/** Fixture. */
final class F3Base_Imp_Troca_Quebrada {

	/**
	 * O DEFEITO: monta o caminho de backup sem o ponto na frente.
	 *
	 * @param string $destino Diretório de destino.
	 * @return string
	 */
	public static function caminho_do_backup( string $destino ): string {
		return $destino . '-f3base-anterior-' . time();
	}
}
