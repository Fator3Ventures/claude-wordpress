<?php
/**
 * Fixture POSITIVA: o JavaScript mora em arquivo próprio e entra por
 * referência; o SQL vai inteiro para a consulta preparada, sem montagem por
 * pedaços. As duas formas são as sancionadas, e o detector precisa calar.
 */
declare( strict_types = 1 );

final class F3Base_Fixture_Tela_Correta {

	public static function tag( string $url ): string {
		return sprintf( '<script src="%s"></script>', $url );
	}

	public static function consulta( $wpdb, string $nome ) {
		return $wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", $nome );
	}
}
