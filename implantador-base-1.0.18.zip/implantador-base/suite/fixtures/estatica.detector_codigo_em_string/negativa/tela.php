<?php
/**
 * Fixture NEGATIVA: JavaScript em heredoc e SQL montado por concatenação.
 * JavaScript dentro de string não é lintado nem executado por teste algum.
 */
declare( strict_types = 1 );

final class F3Base_Fixture_Tela {

	public static function script(): string {
		return <<<'JS'
			document.addEventListener( 'click', function () {
				window.location.reload();
			} );
JS;
	}

	public static function consulta( string $tabela ): string {
		return 'SELECT option_id FROM ' . $tabela . ' WHERE option_name = %s';
	}
}
