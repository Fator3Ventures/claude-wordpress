<?php
/**
 * Fixture NEGATIVA: um segundo lugar respondendo qual página é a política.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Páginas especiais do núcleo, decidindo por conta própria.
	 *
	 * @return string
	 */
	public static function etapa_paginas_especiais(): string {
		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( 'politica-privacidade' === (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.papel', '' ) ) {
				return (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
			}
		}

		return '';
	}
}
