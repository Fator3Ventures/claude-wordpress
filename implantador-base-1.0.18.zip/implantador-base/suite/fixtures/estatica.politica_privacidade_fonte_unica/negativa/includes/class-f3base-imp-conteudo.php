<?php
/**
 * Fixture NEGATIVA: o estado da 1.0.13 — a identidade pendurada no llms.txt.
 *
 * O produtor existe, a âncora está no lugar, e ele lê a identidade de
 * `seo.llms_selecao.politica_privacidade`. Desligar o llms.txt e limpar a
 * seleção — operação legítima — faz o produtor devolver vazio, o pacote deixa
 * de gravar `wp_page_for_privacy_policy` e a checagem legal cai em "condição de
 * aplicabilidade falsa", com o relatório verde.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Conteúdo gerenciado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * A âncora do produtor único da identidade da política.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_da_politica_de_privacidade(): array {
		return array(
			'funcao'  => 'ref_da_politica_de_privacidade',
			'papel'   => 'politica-privacidade',
			'caminho' => 'paginas.*.papel',
			'raiz'    => 'paginas',
		);
	}

	/**
	 * O produtor, lendo o fato de uma chave que não o nomeia.
	 *
	 * @return string
	 */
	public static function ref_da_politica_de_privacidade(): string {
		return (string) F3Base_Imp_Config::obter( 'seo.llms_selecao.politica_privacidade', '' );
	}
}
