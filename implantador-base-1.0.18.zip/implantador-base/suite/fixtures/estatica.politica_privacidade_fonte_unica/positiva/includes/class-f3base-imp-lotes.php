<?php
/**
 * Fixture POSITIVA: quem precisa da política pergunta ao produtor.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Páginas especiais do núcleo.
	 *
	 * @return string
	 */
	public static function etapa_paginas_especiais(): string {
		return F3Base_Imp_Conteudo::ref_da_politica_de_privacidade();
	}

	/**
	 * Seleção do llms.txt: referencia o produtor, não possui o fato.
	 *
	 * @return string
	 */
	public static function etapa_options_site_core(): string {
		if ( ! (bool) F3Base_Imp_Config::obter( 'seo.llms_selecao.incluir_politica_privacidade', true ) ) {
			return '';
		}

		return F3Base_Imp_Conteudo::ref_da_politica_de_privacidade();
	}
}
