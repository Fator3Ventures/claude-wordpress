<?php
/**
 * Fixture POSITIVA: a identidade da política mora no papel da própria página.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Conteúdo gerenciado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * A âncora do produtor único da identidade da política.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_da_politica_de_privacidade(): array {
		return array(
			'funcao'  => 'ref_da_politica_de_privacidade',
			'papel'   => 'politica-privacidade',
			'caminho' => 'paginas.*.papel',
			'raiz'    => 'paginas',
		);
	}

	/**
	 * O produtor único: lê o papel declarado na entrada da página, e nada mais.
	 *
	 * @return string
	 */
	public static function ref_da_politica_de_privacidade(): string {
		$papel = (string) self::produtor_da_politica_de_privacidade()['papel'];

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( $papel === (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.papel', '' ) ) {
				return (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
			}
		}

		return '';
	}
}
