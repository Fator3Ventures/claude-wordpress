<?php
/**
 * Fixture POSITIVA de `estatica.troca_invalida_cache`: o caso correto.
 *
 * A invalidação mora dentro de quem trocou o diretório, derruba os dois caches
 * que o núcleo mantém, e quem chama o trocador relê o artefato pela leitura de
 * volta declarada — a que mede o disco AO LADO da API.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Instalação de artefatos.
 */
final class F3Base_Imp_Troca {

	/**
	 * Âncora da troca de diretório.
	 *
	 * @return array<string,string>
	 */
	public static function troca_de_diretorio_declarada(): array {
		return array(
			'trocador'    => 'trocar_diretorio',
			'invalidador' => 'invalidar_cache_do_artefato',
			'leitura'     => 'leitura_de_volta_do_artefato',
			'tema'        => 'wp_clean_themes_cache',
			'plugin'      => 'wp_clean_plugins_cache',
		);
	}

	/**
	 * Derruba o cache do artefato que acabou de trocar de lugar.
	 *
	 * @param string $tipo Tipo.
	 * @return void
	 */
	public static function invalidar_cache_do_artefato( string $tipo ): void {
		if ( 'tema' === $tipo ) {
			wp_clean_themes_cache( false );

			return;
		}

		wp_clean_plugins_cache( false );
	}

	/**
	 * Leitura de volta que mede disco e API.
	 *
	 * @param string $tipo    Tipo.
	 * @param string $slug    Slug.
	 * @param string $destino Destino.
	 * @param bool   $api_ve  A API enxerga.
	 * @return array{ok:bool,motivo:string}
	 */
	public static function leitura_de_volta_do_artefato( string $tipo, string $slug, string $destino, bool $api_ve ): array {
		unset( $tipo );

		if ( ! is_dir( $destino ) ) {
			return array(
				'ok'     => false,
				'motivo' => $slug . ' não apareceu no disco depois da instalação: ' . $destino,
			);
		}

		return array(
			'ok'     => $api_ve,
			'motivo' => $api_ve ? $slug . ' conferido por leitura de volta.' : 'DEFEITO DE CACHE em ' . $slug . '.',
		);
	}

	/**
	 * Troca controlada de diretório, invalidando o cache depois de mover.
	 *
	 * @param string $origem  Origem.
	 * @param string $destino Destino.
	 * @param string $tipo    Tipo.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function trocar_diretorio( string $origem, string $destino, string $tipo ): array {
		if ( ! rename( $origem, $destino ) ) {
			return array(
				'ok'     => false,
				'motivo' => 'falha ao mover o diretório novo para o destino.',
			);
		}

		self::invalidar_cache_do_artefato( $tipo );

		return array(
			'ok'     => true,
			'motivo' => '',
		);
	}

	/**
	 * Instala o tema e relê pelo produtor declarado.
	 *
	 * @param string $slug    Slug.
	 * @param string $origem  Origem.
	 * @param string $destino Destino.
	 * @return array{estado:string,motivo:string}
	 */
	public static function aplicar_tema( string $slug, string $origem, string $destino ): array {
		$instalou = self::trocar_diretorio( $origem, $destino, 'tema' );

		if ( ! $instalou['ok'] ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => $instalou['motivo'],
			);
		}

		$de_volta = self::leitura_de_volta_do_artefato( 'tema', $slug, $destino, wp_get_theme( $slug )->exists() );

		return array(
			'estado' => $de_volta['ok'] ? 'OK' : 'FALHA',
			'motivo' => $de_volta['motivo'],
		);
	}
}
