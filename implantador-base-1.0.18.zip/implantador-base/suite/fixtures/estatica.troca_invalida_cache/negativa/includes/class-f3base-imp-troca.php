<?php
/**
 * Fixture NEGATIVA de `estatica.troca_invalida_cache`: a 1.0.15 reproduzida.
 *
 * Três defeitos plantados, um por regra:
 *
 * 1. `trocar_diretorio()` move o diretório e NÃO chama o invalidador — o cache
 *    do núcleo continua respondendo pelo estado anterior;
 * 2. o invalidador só derruba o cache de plugin e esquece o de tema;
 * 3. `aplicar_tema()` chama o trocador e relê o estado por fora da leitura de
 *    volta declarada, voltando a dizer "não apareceu no disco" sobre um
 *    diretório que está no disco.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Instalação de artefatos.
 */
final class F3Base_Imp_Troca {

	/**
	 * Âncora da troca de diretório.
	 *
	 * @return array<string,string>
	 */
	public static function troca_de_diretorio_declarada(): array {
		return array(
			'trocador'    => 'trocar_diretorio',
			'invalidador' => 'invalidar_cache_do_artefato',
			'leitura'     => 'leitura_de_volta_do_artefato',
			'tema'        => 'wp_clean_themes_cache',
			'plugin'      => 'wp_clean_plugins_cache',
		);
	}

	/**
	 * Derruba o cache — e esquece o do tema.
	 *
	 * @param string $tipo Tipo.
	 * @return void
	 */
	public static function invalidar_cache_do_artefato( string $tipo ): void {
		unset( $tipo );

		wp_clean_plugins_cache( false );
	}

	/**
	 * Leitura de volta que mede disco e API.
	 *
	 * @param string $tipo    Tipo.
	 * @param string $slug    Slug.
	 * @param string $destino Destino.
	 * @param bool   $api_ve  A API enxerga.
	 * @return array{ok:bool,motivo:string}
	 */
	public static function leitura_de_volta_do_artefato( string $tipo, string $slug, string $destino, bool $api_ve ): array {
		unset( $tipo );

		return array(
			'ok'     => is_dir( $destino ) && $api_ve,
			'motivo' => $slug . ': ' . $destino,
		);
	}

	/**
	 * Troca controlada de diretório, SEM invalidar o cache depois.
	 *
	 * @param string $origem  Origem.
	 * @param string $destino Destino.
	 * @param string $tipo    Tipo.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function trocar_diretorio( string $origem, string $destino, string $tipo ): array {
		unset( $tipo );

		if ( ! rename( $origem, $destino ) ) {
			return array(
				'ok'     => false,
				'motivo' => 'falha ao mover o diretório novo para o destino.',
			);
		}

		return array(
			'ok'     => true,
			'motivo' => '',
		);
	}

	/**
	 * Instala o tema e relê o estado por fora da leitura de volta declarada.
	 *
	 * @param string $slug    Slug.
	 * @param string $origem  Origem.
	 * @param string $destino Destino.
	 * @return array{estado:string,motivo:string}
	 */
	public static function aplicar_tema( string $slug, string $origem, string $destino ): array {
		$instalou = self::trocar_diretorio( $origem, $destino, 'tema' );

		if ( ! $instalou['ok'] ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => $instalou['motivo'],
			);
		}

		if ( ! wp_get_theme( $slug )->exists() ) {
			return array(
				'estado' => 'FALHA',
				'motivo' => 'o tema não apareceu no disco depois da instalação.',
			);
		}

		return array(
			'estado' => 'OK',
			'motivo' => 'tema ' . $slug . ' instalado.',
		);
	}
}
