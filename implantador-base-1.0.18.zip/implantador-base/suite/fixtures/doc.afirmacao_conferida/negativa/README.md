# Fixture NEGATIVA

Três afirmações desta página são refutadas pela configuração e pelo código que
viajam neste mesmo pacote — e é exatamente esse o defeito medido na 1.0.17:

- Cadência: mecanismo vazio → o item fecha BLOCKED, não OK.
- Plugins: `plugins.operacionais` está vazio nesta base.
- Canal: `files/selftest` roda na entrega, com o resultado no relatório.
