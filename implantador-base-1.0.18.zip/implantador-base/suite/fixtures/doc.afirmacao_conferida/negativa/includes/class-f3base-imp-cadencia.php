<?php
/**
 * Fixture NEGATIVA: o código que refuta as três frases do README.
 *
 * A cadência monta WP-Cron SEMPRE e o veredito é OK quando o agendamento
 * existe — não há emissão de `cadencia.mecanismo_declarado` em lugar nenhum. E
 * o canal não despacha rota alguma: nem `rest_do_request`, nem
 * `wp_execute_ability`.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Cadencia {

	public static function agendar(): string {
		return F3Base_Imp_Relatorio::avaliar(
			false !== wp_next_scheduled( 'f3base_cadencia_relatorio' ),
			'cadencia.agendada',
			'cadência agendada.',
			'a cadência não ficou agendada.',
			array( 'evidencia' => 'leitura-de-volta', 'fase' => 'local' )
		);
	}
}
