# Fixture POSITIVA

Três afirmações desta página, e cada uma sustentada por um fato medido no mesmo
pacote:

- Cadência: mecanismo vazio → o item fecha BLOCKED, não OK.
- Plugins: `plugins.operacionais` traz uma entrada nesta base.
- Canal: `files/selftest` é despachado na entrega, com o resultado no relatório.
