<?php
/**
 * Fixture POSITIVA: o código que SUSTENTA as três frases do README.
 *
 * `cadencia.mecanismo_declarado` existe e fecha BLOCKED enquanto a chave estiver
 * vazia, e o autoteste do canal é despachado de verdade pelo servidor REST.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Cadencia {

	public static function agendar( string $declarado ): string {
		return F3Base_Imp_Relatorio::emitir(
			'' !== $declarado ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::BLOCKED,
			'cadencia.mecanismo_declarado',
			'' !== $declarado ? 'mecanismo declarado.' : 'pré-condição ausente: cadencia_relatorio.mecanismo está vazio.',
			array( 'evidencia' => 'pendencia-externa', 'fase' => 'producao' )
		);
	}

	public static function autoteste( string $namespace ) {
		return rest_do_request( new WP_REST_Request( 'POST', '/' . $namespace . '/files/selftest' ) );
	}
}
