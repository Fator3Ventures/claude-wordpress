<?php
/**
 * Fixture POSITIVA: o comentário CITA update_option para explicar a regra.
 * Comentário não executa, e o detector não pode gritar por causa da prosa que
 * o descreve — o detector que reprova o arquivo correto é inútil.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Journal {

	public static function registrar( string $nome ): string {
		return $nome;
	}
}
