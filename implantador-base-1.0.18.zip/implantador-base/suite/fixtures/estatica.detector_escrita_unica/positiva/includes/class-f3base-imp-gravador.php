<?php
/**
 * Fixture POSITIVA: o gravador declarado é o único que escreve. Ele PODE.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Gravador {

	public static function gravar( string $nome, $valor ): bool {
		return update_option( $nome, $valor, false );
	}
}
