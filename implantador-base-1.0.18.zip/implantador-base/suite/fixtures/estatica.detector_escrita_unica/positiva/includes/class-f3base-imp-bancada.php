<?php
/**
 * Fixture POSITIVA: uma bancada de sonda DECLARA a função do núcleo.
 *
 * Declarar não é escrever: a bancada roda fora do WordPress e precisa que o
 * código real do pacote tenha onde cair. Num WordPress de verdade esta
 * declaração nem existiria — redeclarar função do núcleo é erro fatal.
 */
declare( strict_types = 1 );

$GLOBALS['f3base_bancada_options'] = array();

/**
 * Escrita de option da bancada.
 *
 * @param string $nome     Nome.
 * @param mixed  $valor    Valor.
 * @param bool   $autoload Autoload.
 * @return bool
 */
function update_option( string $nome, $valor, bool $autoload = true ): bool {
	$GLOBALS['f3base_bancada_options'][ $nome ] = $valor;

	return true;
}

/**
 * Remoção de option da bancada.
 *
 * @param string $nome Nome.
 * @return bool
 */
function delete_option( string $nome ): bool {
	unset( $GLOBALS['f3base_bancada_options'][ $nome ] );

	return true;
}
