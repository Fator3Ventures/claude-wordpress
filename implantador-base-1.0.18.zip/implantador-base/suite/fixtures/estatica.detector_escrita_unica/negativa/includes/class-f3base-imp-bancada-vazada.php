<?php
/**
 * Fixture NEGATIVA: a definição da bancada com uma CHAMADA na mesma linha.
 *
 * A definição não conta; a chamada continua contando, mesmo colada nela.
 */
declare( strict_types = 1 );

/**
 * Escrita de option que vaza para o núcleo de verdade.
 *
 * @param string $nome  Nome.
 * @param mixed  $valor Valor.
 * @return bool
 */
function delete_site_option( string $nome ) { return update_site_option( $nome, null ); }
