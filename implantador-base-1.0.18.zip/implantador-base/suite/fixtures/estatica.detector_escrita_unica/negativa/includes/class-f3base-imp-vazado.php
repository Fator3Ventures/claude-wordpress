<?php
/**
 * Fixture NEGATIVA: escrita de option fora do gravador único.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Vazado {

	public static function aplicar(): void {
		update_option( 'f3base_qualquer', 1 );
		set_theme_mod( 'custom_logo', 7 );
	}
}
