<?php
/**
 * Fixture POSITIVA de `estatica.resposta_de_lote_nomeada`: o caso correto.
 *
 * Toda resposta que a tela renderiza traz `rotulo` e `aplicacao`, e o emissor só
 * recebe carga do produtor declarado ou do produtor de reserva — que é o único
 * lugar onde uma resposta "não rodou" se monta.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/**
 * Máquina de lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Âncora da resposta do lote.
	 *
	 * @return array<string,string>
	 */
	public static function resposta_declarada(): array {
		return array(
			'emissor'  => 'responder',
			'produtor' => 'processar',
			'reserva'  => 'nao_rodou',
			'exigidas' => 'rotulo,aplicacao',
		);
	}

	/**
	 * Resposta de um lote que não rodou.
	 *
	 * @param int    $indice Índice.
	 * @param string $rotulo Rótulo.
	 * @param string $motivo Motivo.
	 * @return array<string,mixed>
	 */
	private static function nao_rodou( int $indice, string $rotulo, string $motivo ): array {
		return array(
			'ok'        => false,
			'concluido' => true,
			'parou'     => true,
			'lote'      => $indice,
			'etapa'     => 'lote',
			'rotulo'    => $rotulo,
			'estado'    => 'BLOCKED',
			'motivo'    => $motivo,
			'aplicacao' => 'BLOCKED',
		);
	}

	/**
	 * Processa um lote.
	 *
	 * @param string $execucao Execução.
	 * @param int    $indice   Índice.
	 * @return array<string,mixed>
	 */
	public static function processar( string $execucao, int $indice ): array {
		$lock = self::adquirir_lock( $execucao );

		if ( ! $lock['ok'] ) {
			return self::nao_rodou( $indice, 'lote.lock_ocupado', $lock['motivo'] );
		}

		return array(
			'ok'        => true,
			'concluido' => false,
			'lote'      => $indice,
			'etapa'     => 'preflight',
			'rotulo'    => 'preflight',
			'estado'    => 'OK',
			'motivo'    => 'unidade executada.',
			'aplicacao' => 'EXECUTANDO',
		);
	}

	/**
	 * Adquire o lock.
	 *
	 * @param string $execucao Execução.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function adquirir_lock( string $execucao ): array {
		return array(
			'ok'     => '' !== $execucao,
			'motivo' => 'execução concorrente rejeitada.',
		);
	}

	/**
	 * Endpoint do lote.
	 *
	 * @return void
	 */
	public static function endpoint_lote(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			self::responder( self::nao_rodou( 0, 'lote.capacidade_ausente', 'capacidade manage_options ausente.' ) );
		}

		self::responder( self::processar( 'exec', 0 ) );
	}

	/**
	 * Responde JSON e encerra.
	 *
	 * @param array<string,mixed> $carga Carga.
	 * @return void
	 */
	private static function responder( array $carga ): void {
		echo wp_json_encode( $carga );

		exit;
	}
}
