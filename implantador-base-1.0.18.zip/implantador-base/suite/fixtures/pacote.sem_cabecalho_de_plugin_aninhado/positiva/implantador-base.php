<?php
/**
 * Plugin Name:       Implantador Base F3
 * Description:       Único cabeçalho de plugin ao alcance de get_plugins(): o da raiz.
 * Version:           0.0.0
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );
