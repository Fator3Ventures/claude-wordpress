<?php
/**
 * Plugin Name:       F3 Base Site Core
 * Description:       A MESMA fonte, agora a DOIS níveis da raiz. get_plugins() varre a
 *                    raiz e um nível só, então este cabeçalho está fora do alcance e a
 *                    checagem precisa ficar em silêncio sobre ele.
 * Version:           0.0.0
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );
