<?php
/**
 * Classe do implantador, a um nível da raiz e sem cabeçalho de plugin.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/** Exemplo. */
final class F3Base_Imp_Exemplo_Positiva {

	/**
	 * Nada.
	 *
	 * @return string
	 */
	public static function nada(): string {
		return '';
	}
}
