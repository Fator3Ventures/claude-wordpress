<?php
/**
 * Classe do implantador, a um nível da raiz e SEM cabeçalho de plugin.
 *
 * Está aqui para provar que a checagem não acusa todo .php de subdiretório:
 * o que ela mede é a presença de "Plugin Name:", não a profundidade sozinha.
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );

/** Exemplo. */
final class F3Base_Imp_Exemplo {

	/**
	 * Nada.
	 *
	 * @return string
	 */
	public static function nada(): string {
		return '';
	}
}
