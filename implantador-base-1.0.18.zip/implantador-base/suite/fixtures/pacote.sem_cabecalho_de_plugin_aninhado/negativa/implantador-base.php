<?php
/**
 * Plugin Name:       Implantador Base F3
 * Description:       Arquivo principal do pacote, na raiz. Este cabeçalho está certo.
 * Version:           0.0.0
 *
 * @package F3Base\Fixture
 */

declare( strict_types = 1 );
