<?php
/**
 * Fixture NEGATIVA: a frase aposentada voltou ao pacote, e a frase obrigatória
 * não está na página onde foi declarada.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Plugins_Fixture {

	const POLITICA = 'instala o numero de serie do fornecedor declarado no catalogo';
}
