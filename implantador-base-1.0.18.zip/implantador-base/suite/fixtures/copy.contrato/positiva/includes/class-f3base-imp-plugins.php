<?php
/**
 * Fixture POSITIVA: a frase obrigatória está na página declarada e a frase
 * aposentada não aparece em lugar nenhum — nem aqui, nem no conteúdo.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Plugins_Fixture {

	const POLITICA = 'instala sempre a ultima publicada pela fonte oficial';
}
