# Memória de decisões — implantador-base 1.0.6

Registro das decisões.
