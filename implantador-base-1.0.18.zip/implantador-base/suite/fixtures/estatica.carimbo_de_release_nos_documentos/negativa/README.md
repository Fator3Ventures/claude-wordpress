<!-- gerado:inicio=carimbo -->
# implantador-base 9.9.8 — leia-me

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio: foi o que aconteceu da 1.0.6 à 1.0.13. O que não pode ser gerado no momento da escrita
> sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `9.9.8` |
| Implantador · tema · site-core | `9.9.8` · `9.9.0` · `9.9.0` |
| Bundle desta identidade | `implantador-base-9.9.8.zip` |
| Origens de release suportadas | 1 além da instalação limpa |
| Caminhos exatos no inventário | 1 |
| Prefixos declarados no inventário | 0 |
| Arquivos no pacote (fora de `dist/`) | 7 |
| Requisitos em `suite/manifesto.tsv` | 1 |
| Armadilhas com checagem mapeada | 1 |
| Armadilhas em pendência declarada | 1 |
| Detectores com piso em disco | 0 |
| Ramos de piso (negativa + positiva) | 0 |
| Páginas · posts declarados | 1 · 0 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

Prosa do leia-me, que o gerador não toca.

<!-- gerado:inicio=arvore -->
### Árvore de arquivos

Gerada de disco na montagem desta release. A allow-list executável que decide o que
entra no bundle é `suite/inventario.tsv`.

```
implantador-base/
  MANIFESTO.md
  MEMORIA-DECISOES.md
  README.md
  config/site.json
  suite/armadilhas.tsv
  suite/inventario.tsv
  suite/manifesto.tsv
```
<!-- gerado:fim=arvore -->
