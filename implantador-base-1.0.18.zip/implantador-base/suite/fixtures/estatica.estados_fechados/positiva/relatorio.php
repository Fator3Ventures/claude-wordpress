<?php
/**
 * Fixture POSITIVA: só estados da lista fechada.
 */
declare( strict_types = 1 );

function f3base_fixture_estado_valido( bool $ok ): array {
	return array( 'estado' => $ok ? 'OK' : 'FALHA' );
}

function f3base_fixture_estado_bloqueado(): array {
	return array( 'estado' => 'BLOCKED' );
}
