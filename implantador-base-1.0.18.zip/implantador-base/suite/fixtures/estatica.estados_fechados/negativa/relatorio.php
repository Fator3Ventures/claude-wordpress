<?php
/**
 * Fixture NEGATIVA: estado inventado fora da lista fechada. Um estado novo é
 * indistinguível de um estado que ninguém sabe interpretar.
 */
declare( strict_types = 1 );

function f3base_fixture_estado_novo(): array {
	return array( 'estado' => 'QUASE_OK' );
}
