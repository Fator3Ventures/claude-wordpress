# leia-me da fixture positiva
