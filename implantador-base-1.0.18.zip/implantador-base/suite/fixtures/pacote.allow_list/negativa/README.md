# leia-me da fixture negativa
