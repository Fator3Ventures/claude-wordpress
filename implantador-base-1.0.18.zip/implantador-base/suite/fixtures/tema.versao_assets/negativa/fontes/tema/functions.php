<?php
/**
 * Fixture NEGATIVA: a versão do tema virou constante literal. Quando o
 * style.css subir para 1.0.1 esta constante fica para trás, o CSS novo sai
 * publicado com o parâmetro de versão antigo, e o cache serve o arquivo velho.
 */
declare( strict_types = 1 );

define( 'F3BASE_FIXTURE_VERSAO', '1.0.0' );

function f3base_fixture_assets(): void {
	wp_register_style( 'f3base', get_stylesheet_uri(), array(), F3BASE_FIXTURE_VERSAO );
}
