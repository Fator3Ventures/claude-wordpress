<?php
/**
 * Fixture POSITIVA: fonte única — o cabeçalho do style.css, lido por
 * wp_get_theme(). Nenhuma constante repete o número.
 */
declare( strict_types = 1 );

function f3base_fixture_versao(): string {
	return (string) wp_get_theme()->get( 'Version' );
}

function f3base_fixture_assets(): void {
	wp_register_style( 'f3base', get_stylesheet_uri(), array(), f3base_fixture_versao() );
}
