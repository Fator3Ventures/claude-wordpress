<?php
/**
 * Classe do implantador, já no prefixo do site.
 *
 * @package Acme\Implantador
 */

declare( strict_types = 1 );

/**
 * Configuração.
 */
final class Acme_Imp_Config {

	/** Prefixo técnico deste site. */
	public const PREFIXO = 'acme';
}
