<?php
/**
 * Classe do implantador, com resíduo do prefixo do template.
 *
 * @package Acme\Implantador
 */

declare( strict_types = 1 );

/**
 * Configuração.
 */
final class Acme_Imp_Config {

	/** Prefixo técnico deste site. */
	public const PREFIXO = 'acme';

	/** Option que ninguém renomeou. */
	public const OPTION_ESTADO = 'f3base_estado_aplicacao';
}
