# Memória de decisões

O log de uma execução real listou `f3base-site-core-f3base-anterior-1788152131`
entre os plugins com atualização automática ligada. A frase cita o diretório que
existiu, e ela continua verdadeira exatamente porque não foi reescrita.
