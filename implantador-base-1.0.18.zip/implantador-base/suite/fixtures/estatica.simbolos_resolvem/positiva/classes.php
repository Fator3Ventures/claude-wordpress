<?php
/**
 * Fixture POSITIVA: todo símbolo chamado existe.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Alvo {

	const EXISTE = 1;

	public static function presente(): int {
		return self::EXISTE;
	}
}

final class F3Base_Imp_Chamador {

	public static function chamar(): int {
		return F3Base_Imp_Alvo::presente() + F3Base_Imp_Alvo::EXISTE;
	}
}
