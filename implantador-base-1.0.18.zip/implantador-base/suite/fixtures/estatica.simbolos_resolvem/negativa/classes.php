<?php
/**
 * Fixture NEGATIVA: chamada para método e constante que não existem. O erro
 * fatal só apareceria no ramo raro, em produção, no meio da aplicação.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Alvo {

	const EXISTE = 1;

	public static function presente(): int {
		return self::EXISTE;
	}
}

final class F3Base_Imp_Chamador {

	public static function chamar(): int {
		F3Base_Imp_Alvo::metodo_que_nao_existe();

		return F3Base_Imp_Alvo::CONSTANTE_INEXISTENTE;
	}
}
