<?php
/**
 * Fixture NEGATIVA de `estatica.option_fonte_unica` — a âncora da união.
 *
 * A âncora EXISTE e está VAZIA, que é o estado da 1.0.11: ninguém declarou que
 * `f3base_redirects` tem fonte composta, e as duas etapas montam o valor
 * desejado por caminhos diferentes. Âncora presente e vazia não pode absolver.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Gravador reduzido ao que a âncora exige.
 */
final class F3Base_Imp_Gravador {

	/**
	 * Options de fonte composta — nenhuma declarada.
	 *
	 * @return array<string,string>
	 */
	public static function uniao_declarada(): array {
		return array();
	}

	/**
	 * Grava uma option.
	 *
	 * @param string $nome  Nome.
	 * @param mixed  $valor Valor.
	 * @return array<string,mixed>
	 */
	public static function gravar( string $nome, $valor ): array {
		unset( $nome, $valor );

		return array(
			'estado' => 'OK',
			'motivo' => 'gravada e conferida na leitura de volta.',
		);
	}
}
