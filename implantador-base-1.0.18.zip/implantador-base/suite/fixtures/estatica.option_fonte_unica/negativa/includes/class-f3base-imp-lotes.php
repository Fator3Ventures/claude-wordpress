<?php
/**
 * Fixture NEGATIVA de `estatica.option_fonte_unica` — o defeito MEDIDO.
 *
 * Duas etapas gravam `f3base_redirects` por caminhos diferentes, e é assim que
 * o pacote estava depois da 1.0.11:
 *
 * - `gravar_redirects_de_permalink()` computa os pares da troca de estrutura e
 *   grava `array_merge( $atuais, $novos )` — leitura de volta conferida, log
 *   afirmando "2 URL(s) antiga(s) respondendo por redirecionamento declarado";
 * - `etapa_options_site_core()` grava a MESMA option a partir de
 *   `redirects_declarados()`, que sai de `redirects: []` no arquivo de
 *   configuração — leitura de volta conferida também, e os dois pares apagados.
 *
 * As duas mensagens eram verdadeiras no instante em que foram escritas. O
 * artefato final (`a:0:{}`) contradizia a primeira, e as URLs antigas dos dois
 * posts respondiam 404 em vez de 301.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Lotes com duas fontes para a mesma option.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Grava os pares computados pela troca de estrutura de permalinks.
	 *
	 * @param array<int,array<string,mixed>> $novos Pares computados.
	 * @return array<string,mixed>
	 */
	private static function gravar_redirects_de_permalink( array $novos ): array {
		$atuais = get_option( 'f3base_redirects', array() );
		$atuais = is_array( $atuais ) ? $atuais : array();

		return F3Base_Imp_Gravador::gravar( 'f3base_redirects', array_merge( $atuais, $novos ) );
	}

	/**
	 * Grava as options do `site-core`.
	 *
	 * @return array<string,mixed>
	 */
	private static function etapa_options_site_core(): array {
		$valores = array(
			'f3base_contato'   => array( 'whatsapp_e164' => '' ),
			'f3base_redirects' => self::redirects_declarados(),
		);

		$ultimo = array();

		foreach ( $valores as $option => $valor ) {
			$ultimo = F3Base_Imp_Gravador::gravar( $option, $valor );
		}

		return $ultimo;
	}

	/**
	 * Redirects declarados no arquivo de configuração.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function redirects_declarados(): array {
		return array();
	}
}
