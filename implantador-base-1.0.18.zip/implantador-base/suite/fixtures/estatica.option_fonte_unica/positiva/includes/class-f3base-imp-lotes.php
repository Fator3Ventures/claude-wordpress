<?php
/**
 * Fixture POSITIVA de `estatica.option_fonte_unica` — a união declarada.
 *
 * As MESMAS duas etapas gravam `f3base_redirects`, e nenhuma delas monta o
 * valor desejado: as duas pedem a `valor_desejado_de_redirects()`, que une as
 * fontes — pares declarados na configuração, pares computados por etapas desta
 * execução e o que já estava gravado. Nenhum lado apaga o outro, e o detector
 * fica em silêncio: duas gravações do mesmo valor não são duas respostas.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Lotes com fonte composta e ordem declarada.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Grava os pares computados pela troca de estrutura de permalinks.
	 *
	 * @param array<int,array<string,mixed>> $novos Pares computados.
	 * @return array<string,mixed>
	 */
	private static function gravar_redirects_de_permalink( array $novos ): array {
		self::registrar_redirects_computados( $novos );

		return F3Base_Imp_Gravador::gravar( 'f3base_redirects', self::valor_desejado_de_redirects() );
	}

	/**
	 * Grava as options do `site-core`.
	 *
	 * @return array<string,mixed>
	 */
	private static function etapa_options_site_core(): array {
		$valores = array(
			'f3base_contato'   => array( 'whatsapp_e164' => '' ),
			'f3base_redirects' => self::valor_desejado_de_redirects(),
		);

		$ultimo = array();

		foreach ( $valores as $option => $valor ) {
			$ultimo = F3Base_Imp_Gravador::gravar( $option, $valor );
		}

		return $ultimo;
	}

	/**
	 * Pares computados por etapas desta execução.
	 *
	 * @var array<string,array<string,mixed>>
	 */
	private static array $computados = array();

	/**
	 * Registra pares computados por uma etapa.
	 *
	 * @param array<int,array<string,mixed>> $pares Pares.
	 * @return void
	 */
	private static function registrar_redirects_computados( array $pares ): void {
		foreach ( $pares as $par ) {
			self::$computados[ (string) ( $par['de'] ?? '' ) ] = $par;
		}
	}

	/**
	 * O valor desejado da option — ponto único que o produz.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function valor_desejado_de_redirects(): array {
		$gravados = get_option( 'f3base_redirects', array() );

		return self::uniao_de_redirects(
			self::redirects_declarados(),
			array_values( self::$computados ),
			is_array( $gravados ) ? $gravados : array()
		);
	}

	/**
	 * A união declarada das três fontes, por chave de origem.
	 *
	 * @param array<int,array<string,mixed>> $declarados Pares da configuração.
	 * @param array<int,array<string,mixed>> $computados Pares desta execução.
	 * @param array<int,array<string,mixed>> $gravados   Pares já gravados.
	 * @return array<int,array<string,mixed>>
	 */
	private static function uniao_de_redirects( array $declarados, array $computados, array $gravados ): array {
		$pares = array();

		foreach ( array_merge( $declarados, $computados, $gravados ) as $par ) {
			$de = (string) ( $par['de'] ?? '' );

			if ( '' === $de || isset( $pares[ $de ] ) ) {
				continue;
			}

			$pares[ $de ] = $par;
		}

		return array_values( $pares );
	}

	/**
	 * Redirects declarados no arquivo de configuração.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	private static function redirects_declarados(): array {
		return array();
	}
}
