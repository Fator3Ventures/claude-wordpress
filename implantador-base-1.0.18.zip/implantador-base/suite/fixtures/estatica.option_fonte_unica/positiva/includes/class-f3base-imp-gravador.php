<?php
/**
 * Fixture POSITIVA de `estatica.option_fonte_unica` — a âncora da união.
 *
 * A option de fonte composta está DECLARADA, e com o nome da função que produz
 * o valor desejado dela. É o que faz o detector calar sobre as duas gravações
 * da mesma option: elas não são duas respostas, são uma resposta com parcelas.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Gravador reduzido ao que a âncora exige.
 */
final class F3Base_Imp_Gravador {

	/**
	 * Options de fonte composta e a função que une as fontes de cada uma.
	 *
	 * @return array<string,string>
	 */
	public static function uniao_declarada(): array {
		return array(
			'f3base_redirects' => 'valor_desejado_de_redirects',
		);
	}

	/**
	 * Grava uma option.
	 *
	 * @param string $nome  Nome.
	 * @param mixed  $valor Valor.
	 * @return array<string,mixed>
	 */
	public static function gravar( string $nome, $valor ): array {
		unset( $nome, $valor );

		return array(
			'estado' => 'OK',
			'motivo' => 'gravada e conferida na leitura de volta.',
		);
	}
}
