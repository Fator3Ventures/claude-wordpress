<?php
/**
 * Fixture POSITIVA de `estatica.option_fonte_unica` — a âncora das options.
 *
 * Só o que a regra precisa para ter escopo: a lista declarada de options
 * gerenciadas. Sem ela o detector não sabe sobre o que a regra vale.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Relatório reduzido ao que a âncora exige.
 */
final class F3Base_Imp_Relatorio {

	/**
	 * Options gerenciadas do pacote.
	 *
	 * @return string[]
	 */
	public static function options_gerenciadas(): array {
		return array(
			'f3base_contato',
			'f3base_redirects',
		);
	}
}
