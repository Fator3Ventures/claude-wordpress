<?php
/**
 * Fixture POSITIVA: o mesmo relato, com o estado derivado da medição.
 *
 * Dois ramos: dentro do piso declarado fecha OK com os valores no texto; abaixo
 * do piso fecha WARN nomeando o que ficou abaixo e o que ele custa. A segunda
 * função mostra a outra forma legítima — cláusula de guarda antes do WARN.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Exemplo do caso correto.
 */
final class F3Base_Imp_Exemplo {

	/**
	 * Relata os limites do ambiente, derivando o estado da medição.
	 *
	 * @param array<string,int> $medido  Limites medidos.
	 * @param array<string,int> $minimos Piso declarado.
	 * @return void
	 */
	public static function relatar_limites( array $medido, array $minimos ): void {
		$tempo = (int) $medido['max_execution_time'];
		$piso  = (int) $minimos['max_execution_time_s'];

		if ( 0 !== $tempo && $tempo < $piso ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'preflight.limites',
				sprintf( 'max_execution_time %1$ds abaixo do piso declarado %2$ds: o servidor interrompe o lote no meio da gravação.', $tempo, $piso ),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'preflight.limites',
				sprintf( 'limites suficientes para a execução em lotes — max_execution_time %1$ds contra o piso de %2$ds.', $tempo, $piso ),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}
	}

	/**
	 * Conteúdo publicado que este pacote não gerencia — com cláusula de guarda.
	 *
	 * @param array<int,string> $nao_gerenciados Objetos medidos.
	 * @param int               $medidos         Quantidade lida.
	 * @return array{estado:string,motivo:string}
	 */
	public static function relatar_nao_gerenciado( array $nao_gerenciados, int $medidos ): array {
		if ( 0 === $medidos ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'motivo' => 'pré-condição ausente: nenhum conteúdo publicado foi lido, e escopo vazio não aprova.',
			);
		}

		if ( array() === $nao_gerenciados ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => 'todo conteúdo publicado tem meta de gestão deste pacote.',
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::WARN,
			'motivo' => 'conteúdo PUBLICADO e NÃO gerenciado por este pacote: ' . implode( '; ', $nao_gerenciados ) . '. Ele não foi tocado.',
		);
	}
}
