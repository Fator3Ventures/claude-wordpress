<?php
/**
 * Fixture NEGATIVA: WARN incondicional, sem ramo e sem guarda.
 *
 * É o defeito medido na 1.0.14 reproduzido em miniatura: a checagem mede,
 * escreve os valores medidos no texto e emite WARN sempre — mesmo quando nada
 * ficou fora do esperado. A unidade que a contém é promovida a amarelo por uma
 * linha que não tem achado nenhum.
 *
 * @package F3Base\Suite\Fixtures
 */

declare( strict_types = 1 );

/**
 * Exemplo do defeito.
 */
final class F3Base_Imp_Exemplo {

	/**
	 * Relata os limites do ambiente.
	 *
	 * @param array<string,int> $medido Limites medidos.
	 * @return void
	 */
	public static function relatar_limites( array $medido ): void {
		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::WARN,
			'preflight.limites',
			sprintf( 'limites observados — max_execution_time %ds. Fato de ambiente, relatado sem decidir gate.', (int) $medido['max_execution_time'] ),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);
	}
}
