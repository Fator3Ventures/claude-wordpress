<?php
/**
 * Fixture POSITIVA: o veredito da suíte MORA na suíte.
 *
 * A âncora `vereditos_da_suite()` declara que `estatica.detector_chave_sem_consumidor`
 * é pergunta da suíte externa. Aqui está quem a responde: o cruzamento contra
 * TODO o código do pacote, uma vez, num lugar só.
 */
declare( strict_types = 1 );

/**
 * Toda chave declarada tem alguma linha do pacote que a lê.
 *
 * @param string $raiz Raiz a varrer.
 * @return array{ok:bool,achados:array<int,string>}
 */
function f3b_ck_chave_sem_consumidor( string $raiz ): array {
	unset( $raiz );

	return array(
		'ok'      => true,
		'achados' => array(),
	);
}

emitir( f3b_ck_chave_sem_consumidor( __DIR__ ), 'estatica.detector_chave_sem_consumidor', 'toda chave tem consumidor.', 'analise-estatica', 'build' );
