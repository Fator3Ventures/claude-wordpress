<?php
/**
 * Fixture POSITIVA: o encerramento LÊ o registro e não recalcula nada.
 *
 * O nome de cada gate chega por parâmetro à função que lê — o corpo desta
 * classe não contém nenhum literal de nome de gate, e por isso ela não pode
 * virar a segunda derivação nem por descuido.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Lotes {

	public static function etapa_encerramento(): array {
		$estados = array();

		foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
			$estados[ $gate ] = F3Base_Imp_Entrega::veredito_registrado( $gate )['estado'];
		}

		return $estados;
	}
}
