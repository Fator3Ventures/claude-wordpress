<?php
/**
 * Fixture POSITIVA: um veredito, uma derivação, e leitura por parâmetro.
 *
 * `gates_do_canal()` só declara NOMES e não deriva estado nenhum.
 * `etapa_canal_mcp()` deriva `mcp.canal_configurado`; `derivar_canal_exposto()`
 * deriva `mcp.canal_exposto`. Quem precisa do veredito depois LÊ o registro da
 * execução, recebendo o nome por PARÂMETRO — e é essa construção que impede a
 * leitura de virar a segunda derivação.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Entrega {

	public static function gates_do_canal(): array {
		return array( 'mcp.canal_configurado', 'mcp.canal_exposto' );
	}

	public static function vereditos_da_suite(): array {
		return array( 'estatica.detector_chave_sem_consumidor' );
	}

	public static function etapa_canal_mcp(): array {
		$medicao  = self::medir_canal();
		$completo = 12 === count( $medicao['achadas'] );

		$estado = F3Base_Imp_Relatorio::avaliar(
			$completo,
			'mcp.canal_configurado',
			'as doze rotas respondem.',
			'canal incompleto.',
			array()
		);

		self::registrar_veredito( 'mcp.canal_configurado', $estado, 'medido uma vez.' );

		$exposto = self::derivar_canal_exposto( $medicao );

		self::registrar_veredito( $exposto['rotulo'], $exposto['estado'], $exposto['motivo'] );

		return $exposto;
	}

	public static function medir_canal(): array {
		return array(
			'achadas'        => array(),
			'servidor_ativo' => false,
		);
	}

	private static function derivar_canal_exposto( array $medicao ): array {
		return array(
			'estado' => $medicao['servidor_ativo'] ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::BLOCKED,
			'rotulo' => 'mcp.canal_exposto',
			'motivo' => 'registradas e expostas, ou não.',
		);
	}

	public static function registrar_veredito( string $nome, string $estado, string $motivo ): void {
		F3Base_Imp_Gravador::persistir_infra( 'f3base_vereditos', array( $nome => array( $estado, $motivo ) ) );
	}

	public static function veredito_registrado( string $nome ): array {
		$registro = get_option( 'f3base_vereditos', array() );

		if ( ! isset( $registro[ $nome ] ) ) {
			return array( 'estado' => F3Base_Imp_Relatorio::BLOCKED, 'motivo' => 'a unidade não rodou.' );
		}

		return array( 'estado' => (string) $registro[ $nome ][0], 'motivo' => (string) $registro[ $nome ][1] );
	}
}
