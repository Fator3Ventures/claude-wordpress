<?php
/**
 * Fixture POSITIVA: o registro da rodada tem UM produtor — o comando único.
 *
 * Evidência importada que qualquer arquivo do pacote pudesse gravar deixaria de
 * ser evidência: passaria a ser uma afirmação que qualquer um coloca no pacote.
 */
declare( strict_types = 1 );

/**
 * Grava o registro da rodada limpa dentro do pacote.
 *
 * @param string $raiz Raiz do pacote.
 * @param string $json Registro já codificado.
 * @return void
 */
function f3b_selar_rodada( string $raiz, string $json ): void {
	file_put_contents( $raiz . '/suite/rodada.json', $json );
}
