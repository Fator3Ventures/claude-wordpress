<?php
/**
 * Fixture NEGATIVA: um SEGUNDO produtor do registro da rodada limpa.
 *
 * O implantador gravando, no host, o registro que só a suíte externa pode
 * produzir: o pacote passa a poder afirmar "rodada limpa" sem que rodada
 * nenhuma tenha acontecido, e o gate da fase fecha OK sobre nada.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Relatorio {

	public static function carimbar_rodada( string $raiz, string $hash ): void {
		file_put_contents(
			$raiz . '/suite/rodada.json',
			(string) json_encode( array( 'hash_pacote' => $hash ) )
		);
	}
}
