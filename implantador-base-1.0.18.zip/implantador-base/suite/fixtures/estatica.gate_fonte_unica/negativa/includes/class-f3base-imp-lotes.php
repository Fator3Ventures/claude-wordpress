<?php
/**
 * Fixture NEGATIVA: o encerramento RECALCULA os mesmos vereditos de gate.
 *
 * Segunda implementação do mesmo fato, por outro caminho de medição — é ela que
 * faz a linha 41 contradizer a linha 14 do mesmo relatório.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Lotes {

	public static function etapa_encerramento(): array {
		$rotas = F3Base_Imp_Entrega::rotas_registradas();

		$estados = array();

		$estados['mcp.canal_configurado'] = 12 === count( $rotas )
			? F3Base_Imp_Relatorio::OK
			: F3Base_Imp_Relatorio::FALHA;

		$estados['mcp.canal_exposto'] = array() !== $rotas
			? F3Base_Imp_Relatorio::OK
			: F3Base_Imp_Relatorio::BLOCKED;

		return $estados;
	}
}

/**
 * Fixture NEGATIVA: o RUNTIME deriva um veredito que é da SUÍTE.
 *
 * `vereditos_da_suite()` declara `estatica.detector_chave_sem_consumidor` como
 * pergunta da suíte externa, que cruza toda chave contra TODO o código do
 * pacote. Esta classe responde a mesma pergunta contra outra coisa — o que o
 * implantador leu NESTA execução — e emite estado fechado com o nome do
 * veredito alheio. Duas implementações, duas respostas, uma pergunta.
 */
final class F3Base_Imp_Consumidores {

	public static function conferir(): void {
		$orfas = F3Base_Imp_Config::chaves_sem_consumidor();

		F3Base_Imp_Relatorio::avaliar(
			array() === $orfas,
			'estatica.detector_chave_sem_consumidor',
			'nenhuma chave sem consumidor.',
			'chaves sem consumidor: ' . implode( ', ', $orfas ),
			array()
		);
	}
}
