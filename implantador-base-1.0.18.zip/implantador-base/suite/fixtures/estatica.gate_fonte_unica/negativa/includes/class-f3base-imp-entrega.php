<?php
/**
 * Fixture NEGATIVA: o veredito de gate é derivado em DUAS classes.
 *
 * Reproduz o defeito medido em produção. Aqui a unidade `mcp` mede pelas
 * habilidades REGISTRADAS e emite OK; em `class-f3base-imp-lotes.php` o
 * encerramento recalcula o MESMO veredito por outro caminho e emite FALHA. O
 * relatório sai dizendo as duas coisas.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Entrega {

	public static function gates_do_canal(): array {
		return array( 'mcp.canal_configurado', 'mcp.canal_exposto' );
	}

	public static function vereditos_da_suite(): array {
		return array( 'estatica.detector_chave_sem_consumidor' );
	}

	public static function etapa_canal_mcp(): array {
		$registradas = self::habilidades_registradas();
		$completo    = 12 === count( $registradas );

		F3Base_Imp_Relatorio::avaliar(
			$completo,
			'mcp.canal_configurado',
			'as doze rotas respondem.',
			'canal incompleto.',
			array()
		);

		return array(
			'estado' => $completo ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::BLOCKED,
			'rotulo' => 'mcp.canal_exposto',
			'motivo' => 'registradas e expostas.',
		);
	}

	public static function habilidades_registradas(): array {
		return array();
	}
}
