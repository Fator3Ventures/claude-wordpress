<?php
/**
 * Plugin Name:       Implantador Base F3
 * Version:           1.0.16
 * Text Domain:       f3base
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'F3BASE_IMP_VERSAO_DECLARADA' ) ) {
	define( 'F3BASE_IMP_VERSAO_DECLARADA', '1.0.15' );
}
