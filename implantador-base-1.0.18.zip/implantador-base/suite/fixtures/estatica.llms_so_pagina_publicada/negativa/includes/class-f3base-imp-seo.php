<?php
/**
 * Fixture NEGATIVA: o estado da 1.0.13 — um produtor gateado, o outro livre.
 *
 * O item de `f3base_llms` passa pelo gate; a gravação de `wpseo_llmstxt`
 * resolve a página com `localizar_gerenciado()` e entrega o ID de um rascunho
 * a um slot chamado `privacy_policy` que alimenta arquivo publicado. E o
 * produtor declarado para essa option existe sem passar pelo gate, que é a
 * outra metade do defeito: a âncora promete um gate que ninguém executa.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Adaptador de SEO.
 */
final class F3Base_Imp_Seo {

	/**
	 * Produtor declarado que não pergunta o status.
	 *
	 * @param string $ref Referência lógica.
	 * @return int
	 */
	public static function id_llms_de_pagina( string $ref ): int {
		return F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );
	}

	/**
	 * Seleção gravada na option do plugin, montada por fora do produtor.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_llms(): array {
		$id = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', 'privacidade' );

		$chaves = array(
			'privacy_policy' => $id,
			'manual'         => true,
		);

		return F3Base_Imp_Gravador::gravar_chaves( 'wpseo_llmstxt', $chaves, array() );
	}
}
