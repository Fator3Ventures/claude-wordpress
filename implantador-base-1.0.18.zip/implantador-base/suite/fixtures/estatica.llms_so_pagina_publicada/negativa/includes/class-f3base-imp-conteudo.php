<?php
/**
 * Fixture POSITIVA: o gate único mede o artefato.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Conteúdo gerenciado.
 */
final class F3Base_Imp_Conteudo {

	/**
	 * O gate único: página publicada, medida no banco.
	 *
	 * @param string $ref Referência lógica.
	 * @return array<string,mixed>
	 */
	public static function id_de_pagina_publicada( string $ref ): array {
		$id = self::localizar_gerenciado( 'page', $ref );

		if ( $id <= 0 ) {
			return array( 'id' => 0, 'existe' => false, 'publicada' => false, 'observado' => '' );
		}

		$observado = (string) get_post_status( $id );
		$publicada = 'publish' === $observado;

		return array(
			'id'        => $publicada ? $id : 0,
			'existe'    => true,
			'publicada' => $publicada,
			'observado' => $observado,
		);
	}

	/**
	 * Localiza um objeto gerenciado.
	 *
	 * @param string $tipo Tipo.
	 * @param string $ref  Referência.
	 * @return int
	 */
	public static function localizar_gerenciado( string $tipo, string $ref ): int {
		unset( $tipo, $ref );

		return 0;
	}
}
