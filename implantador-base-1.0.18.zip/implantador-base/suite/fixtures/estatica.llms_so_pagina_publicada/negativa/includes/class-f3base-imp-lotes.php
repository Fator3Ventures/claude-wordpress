<?php
/**
 * Fixture POSITIVA: a âncora declara o gate e os DOIS produtores.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Lotes.
 */
final class F3Base_Imp_Lotes {

	/**
	 * A âncora dos produtores de seleção do llms.txt.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_de_item_llms(): array {
		return array(
			'gate'          => 'id_de_pagina_publicada',
			'f3base_llms'   => 'item_llms_de_pagina',
			'wpseo_llmstxt' => 'id_llms_de_pagina',
		);
	}

	/**
	 * Produtor do item do site-core.
	 *
	 * @param string $ref Referência lógica.
	 * @return array<string,string>
	 */
	public static function item_llms_de_pagina( string $ref ): array {
		$medido = F3Base_Imp_Conteudo::id_de_pagina_publicada( $ref );

		if ( $medido['id'] <= 0 ) {
			return array();
		}

		return array(
			'titulo' => (string) get_the_title( $medido['id'] ),
			'url'    => (string) get_permalink( $medido['id'] ),
		);
	}

	/**
	 * Options do site-core.
	 *
	 * @return array<string,mixed>
	 */
	public static function etapa_options_site_core(): array {
		return array(
			'f3base_llms' => array(
				'politica_privacidade' => self::item_llms_de_pagina( 'privacidade' ),
			),
		);
	}
}
