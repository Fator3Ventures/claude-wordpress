<?php
/**
 * Fixture POSITIVA: o segundo produtor também passa pelo gate.
 *
 * @package F3Base\Suite\Fixture
 */

declare( strict_types = 1 );

/**
 * Adaptador de SEO.
 */
final class F3Base_Imp_Seo {

	/**
	 * Produtor do ID para a seleção do plugin.
	 *
	 * @param string $ref Referência lógica.
	 * @return int
	 */
	public static function id_llms_de_pagina( string $ref ): int {
		return (int) F3Base_Imp_Conteudo::id_de_pagina_publicada( $ref )['id'];
	}

	/**
	 * Seleção gravada na option do plugin.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_llms(): array {
		$chaves = array(
			'privacy_policy' => self::id_llms_de_pagina( 'privacidade' ),
			'manual'         => true,
		);

		return F3Base_Imp_Gravador::gravar_chaves( 'wpseo_llmstxt', $chaves, array() );
	}
}
