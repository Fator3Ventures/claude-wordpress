<?php
/**
 * Fixture NEGATIVA: o defeito de 1.0.17, reproduzido inteiro.
 *
 * A etapa GRAVA `f3base_cadencia` com o número de ajustes lido da configuração,
 * e NENHUMA linha do pacote lê essa option de volta. A chave do config tinha
 * leitor — `estatica.detector_chave_sem_consumidor` aprovava —, e mesmo assim o
 * relatório prometia "gatilho alternativo: após N ajustes" sobre um contador
 * que não existia. `blog_public` fica aqui de propósito: option do núcleo é lida
 * pelo WordPress, e acusá-la seria falso positivo com cara de rigor.
 */
declare( strict_types = 1 );

final class F3Base_Imp_Cadencia {

	public const OPTION_CADENCIA = 'f3base_cadencia';

	public static function agendar(): void {
		F3Base_Imp_Gravador::gravar(
			self::OPTION_CADENCIA,
			array(
				'apos_n_ajustes' => (int) F3Base_Imp_Config::obter( 'cadencia_relatorio.apos_n_ajustes', 0 ),
			),
			array( 'autoload' => false )
		);

		F3Base_Imp_Gravador::gravar( 'f3base_release', '1.0.0' );
		update_option( 'blog_public', 1 );
	}

	public static function release(): string {
		return (string) get_option( 'f3base_release', '' );
	}
}
