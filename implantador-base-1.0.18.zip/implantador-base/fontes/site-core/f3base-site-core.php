<?php
/**
 * Plugin Name:       F3 Base Site Core
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Plugin persistente do Método F3: leads e endpoint endurecido, consentimento, tracking inerte por padrão, rota de origem, reserva de llms.txt, redirects de slug, honra de noindex, extensão de schema, retenção e eliminação com journal, guarda das options no canal MCP, cabeçalhos de resposta e o ouvinte da cadência do modo somente-relatório. Tudo declarado num registro único de módulos que alimenta hooks, tela e relatório.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            Fator 3 Ventures
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       f3base
 * Domain Path:       /languages
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Identidade e caminhos. Constantes definidas antes de qualquer require: as classes
 * do plugin as consomem no carregamento e o guard de PHP abaixo precisa da versão
 * para nomear o próprio motivo.
 */
if ( ! defined( 'F3BASE_SITE_CORE_VERSAO' ) ) {
	define( 'F3BASE_SITE_CORE_VERSAO', '1.0.1' );
}
if ( ! defined( 'F3BASE_SITE_CORE_PHP_MINIMO' ) ) {
	define( 'F3BASE_SITE_CORE_PHP_MINIMO', '8.1' );
}
if ( ! defined( 'F3BASE_PREFIXO' ) ) {
	define( 'F3BASE_PREFIXO', 'f3base' );
}
if ( ! defined( 'F3BASE_TEXT_DOMAIN' ) ) {
	define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
}
if ( ! defined( 'F3BASE_REST_NAMESPACE' ) ) {
	define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
}
if ( ! defined( 'F3BASE_SITE_CORE_ARQUIVO' ) ) {
	define( 'F3BASE_SITE_CORE_ARQUIVO', __FILE__ );
}
if ( ! defined( 'F3BASE_SITE_CORE_DIR' ) ) {
	define( 'F3BASE_SITE_CORE_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'F3BASE_SITE_CORE_URL' ) ) {
	define( 'F3BASE_SITE_CORE_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Guard de versão de PHP.
 *
 * `version_compare()` aqui usa `<`, operador da lista permitida pelo contrato
 * (`< lt <= le > gt >= ge == = eq != <> ne`).
 *
 * @return bool Verdadeiro quando o PHP em execução atende ao mínimo declarado.
 */
function f3base_site_core_php_suportado(): bool {
	return ! version_compare( PHP_VERSION, F3BASE_SITE_CORE_PHP_MINIMO, '<' );
}

if ( ! f3base_site_core_php_suportado() ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: versão mínima de PHP exigida, 2: versão de PHP em execução. */
						__( 'F3 Base Site Core exige PHP %1$s ou superior. Este servidor executa PHP %2$s: o plugin ficou inerte e nenhum hook foi registrado.', 'f3base' ),
						F3BASE_SITE_CORE_PHP_MINIMO,
						PHP_VERSION
					)
				)
			);
		}
	);

	return;
}

/**
 * Autoload simples: lista declarada de arquivos, um `require_once` por arquivo.
 *
 * Sem PSR-4 e sem `spl_autoload_register` de propósito — o pacote precisa ser
 * legível por quem abre a pasta, e a lista é a mesma que o empacotador confere.
 *
 * @return void
 */
function f3base_site_core_carregar(): void {
	$arquivos = array(
		'includes/class-f3base-options.php',
		'includes/class-f3base-atividade.php',
		'includes/class-f3base-modulo.php',
		'includes/class-f3base-modulo-leads-whatsapp.php',
		'includes/class-f3base-modulo-endpoint-leads.php',
		'includes/class-f3base-modulo-consentimento.php',
		'includes/class-f3base-modulo-tracking.php',
		'includes/class-f3base-modulo-rota-origem.php',
		'includes/class-f3base-modulo-llms-txt-reserva.php',
		'includes/class-f3base-modulo-redirects.php',
		'includes/class-f3base-modulo-noindex-honrado.php',
		'includes/class-f3base-modulo-schema-extensao.php',
		'includes/class-f3base-modulo-retencao-eliminacao.php',
		'includes/class-f3base-modulo-guarda-options-mcp.php',
		'includes/class-f3base-modulo-cabecalhos.php',
		'includes/class-f3base-modulo-cadencia-relatorio.php',
		'includes/class-f3base-registro.php',
		'includes/class-f3base-plugin.php',
		'admin/class-f3base-admin-tela.php',
	);

	foreach ( $arquivos as $relativo ) {
		require_once F3BASE_SITE_CORE_DIR . $relativo;
	}
}

f3base_site_core_carregar();

register_activation_hook( __FILE__, array( 'F3Base_Site_Core', 'ativar' ) );
register_deactivation_hook( __FILE__, array( 'F3Base_Site_Core', 'desativar' ) );

F3Base_Site_Core::iniciar();
