<?php
/**
 * Módulo consentimento.
 *
 * Padrão pré-aprovado: as tags carregam por padrão, o controle de revisão fica no
 * rodapé de TODA página, a negativa desliga e persiste pelo TTL da configuração e
 * o re-aceite religa. Consent Mode com `granted` na carga e `update` para `denied`
 * na negativa.
 *
 * A chave `aviso_primeira_visita` existe, tem consumidor (o aviso não bloqueante
 * do JavaScript) e nasce DESLIGADA — ligá-la é decisão declarada por projeto.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Política de consentimento e seu controle permanente.
 */
final class F3Base_Modulo_Consentimento extends F3Base_Modulo {

	/**
	 * Handle do script.
	 */
	public const HANDLE = 'f3base-consentimento';

	/**
	 * Cookie que persiste a decisão do titular.
	 */
	public const COOKIE = 'f3base_consentimento';

	/**
	 * Suporte que o tema declara quando ele próprio fornece o controle no rodapé.
	 */
	public const SUPORTE_TEMA = 'f3base-consentimento-rodape';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'consentimento';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Consentimento', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Aplica a política declarada — pré-aprovado por padrão —, publica o controle de revisão no rodapé de toda página, persiste a negativa pelo TTL configurado e religa no re-aceite. Emite Consent Mode com granted na carga e update para denied na negativa.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 1,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_footer',
				'metodo'     => 'render_controle',
				'prioridade' => 20,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_consentimento' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$tema = current_theme_supports( self::SUPORTE_TEMA );

		return array(
			array(
				'rotulo'   => __( 'Controle no rodapé', 'f3base' ),
				'presente' => true,
				'detalhe'  => $tema
					? __( 'fornecido pela part do tema, que declara suporte; o comportamento continua sendo do site-core.', 'f3base' )
					: __( 'fornecido pelo próprio site-core em wp_footer, porque o tema não declara suporte.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'JavaScript no navegador', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'sem JavaScript o controle não opera: perda declarada no relatório, como no fluxo de WhatsApp.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( F3Base_Options::ORIGEM_PADRAO === F3Base_Options::proveniencia( 'f3base_consentimento' ) ) {
			return $this->degradado(
				__( 'f3base_consentimento nunca foi gravada pelo implantador: o site opera sobre o padrão embutido do plugin, não sobre a política declarada do projeto.', 'f3base' )
			);
		}

		if ( empty( $config['controle_rodape'] ) ) {
			return $this->degradado(
				__( 'controle no rodapé desligado na configuração: o titular fica sem instrumento permanente de revisão.', 'f3base' )
			);
		}

		if ( 'pre-aprovado' === ( $config['padrao'] ?? 'pre-aprovado' ) ) {
			return $this->ativo(
				sprintf(
					/* translators: %d: prazo em dias. */
					__( 'política pré-aprovada com controle no rodapé; a negativa persiste por %d dias e o re-aceite religa.', 'f3base' ),
					(int) ( $config['ttl_dias'] ?? 180 )
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: prazo em dias. */
				__( 'política de negativa por padrão: as tags só carregam após o aceite, que persiste por %d dias.', 'f3base' ),
				(int) ( $config['ttl_dias'] ?? 180 )
			)
		);
	}

	/**
	 * Enfileira o script de consentimento no cabeçalho.
	 *
	 * Precisa ser bloqueante e vir antes de qualquer tag: o `default` do Consent
	 * Mode só vale se chegar antes do gtag.js.
	 *
	 * @return void
	 */
	public function enfileirar(): void {
		$config = $this->config();
		$padrao = (string) ( $config['padrao'] ?? 'pre-aprovado' );

		wp_enqueue_script(
			self::HANDLE,
			F3BASE_SITE_CORE_URL . 'assets/f3base-consentimento.js',
			array(),
			F3BASE_SITE_CORE_VERSAO,
			array(
				'in_footer' => false,
			)
		);

		wp_localize_script(
			self::HANDLE,
			'f3baseConsentimentoDados',
			array(
				'padrao'              => $padrao,
				'ttlDias'             => (int) ( $config['ttl_dias'] ?? 180 ),
				'controleRodape'      => ! empty( $config['controle_rodape'] ),
				'avisoPrimeiraVisita' => ! empty( $config['aviso_primeira_visita'] ),
				'cookie'              => self::COOKIE,
				'seletorControle'     => '[data-f3base-consentimento]',
				'categorias'          => array( 'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization' ),
				'textos'              => array(
					'titulo'       => __( 'Suas escolhas de medição', 'f3base' ),
					'explicacao'   => 'pre-aprovado' === $padrao
						? __( 'Este site carrega ferramentas de medição por padrão. Você pode desligá-las agora; a escolha fica guardada neste navegador.', 'f3base' )
						: __( 'Este site só carrega ferramentas de medição depois do seu aceite. Você pode mudar essa escolha quando quiser.', 'f3base' ),
					'aceitar'      => __( 'Permitir medição', 'f3base' ),
					'recusar'      => __( 'Desligar medição', 'f3base' ),
					'fechar'       => __( 'Fechar', 'f3base' ),
					'estadoAtivo'  => __( 'Medição ligada neste navegador.', 'f3base' ),
					'estadoNegado' => __( 'Medição desligada neste navegador.', 'f3base' ),
					'aviso'        => __( 'Este site usa medição por padrão. Ajuste no controle de privacidade do rodapé.', 'f3base' ),
					'avisoOk'      => __( 'Entendi', 'f3base' ),
					'politica'     => __( 'Política de Privacidade', 'f3base' ),
				),
				'politicaUrl'         => esc_url_raw( (string) get_privacy_policy_url() ),
			)
		);
	}

	/**
	 * Publica o controle de revisão no rodapé.
	 *
	 * Se o tema declara `f3base-consentimento-rodape`, ele já fornece o botão na
	 * part e nada é impresso aqui — o comportamento continua sendo deste módulo.
	 *
	 * @return void
	 */
	public function render_controle(): void {
		$config = $this->config();

		if ( empty( $config['controle_rodape'] ) ) {
			return;
		}

		if ( current_theme_supports( self::SUPORTE_TEMA ) ) {
			return;
		}

		printf(
			'<div class="f3base-consentimento-rodape"><button type="button" class="f3base-consentimento-abrir" data-f3base-consentimento="abrir" aria-haspopup="dialog">%s</button></div>',
			esc_html__( 'Privacidade e medição', 'f3base' )
		);
	}

	/**
	 * Decisão registrada no navegador do visitante, lida no servidor.
	 *
	 * @return string `granted`, `denied` ou `sem-decisao`.
	 */
	public static function decisao_do_visitante(): string {
		if ( ! isset( $_COOKIE[ self::COOKIE ] ) ) {
			return 'sem-decisao';
		}

		$valor = sanitize_key( wp_unslash( (string) $_COOKIE[ self::COOKIE ] ) );

		return in_array( $valor, array( 'granted', 'denied' ), true ) ? $valor : 'sem-decisao';
	}

	/**
	 * Há consentimento efetivo para carregar tags de terceiro?
	 *
	 * @return bool
	 */
	public static function permite_tags(): bool {
		$config = F3Base_Options::ler( 'f3base_consentimento' );
		$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';

		$decisao = self::decisao_do_visitante();

		if ( 'denied' === $decisao ) {
			return false;
		}

		if ( 'granted' === $decisao ) {
			return true;
		}

		return 'pre-aprovado' === $padrao;
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_consentimento' );

		return is_array( $config ) ? $config : array();
	}
}
