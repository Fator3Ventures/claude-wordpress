<?php
/**
 * Módulo cabecalhos.
 *
 * Emite os cabeçalhos de resposta da configuração — os de segurança que não
 * alteram o carregamento de recurso nenhum.
 *
 * COOP PRECISA ser `same-origin-allow-popups`: o fluxo de leads do WhatsApp abre
 * janela, e `same-origin` corta a relação com ela. O valor é travado na
 * sanitização do gravador, não apenas conferido aqui.
 *
 * HSTS fica desligado por padrão — é o único da lista com efeito persistente no
 * navegador, e a decisão é do cliente, com implantação escalonada.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cabeçalhos de resposta.
 */
final class F3Base_Modulo_Cabecalhos extends F3Base_Modulo {

	/**
	 * Valor exigido para o COOP.
	 */
	public const COOP_EXIGIDO = 'same-origin-allow-popups';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'cabecalhos';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Cabeçalhos de resposta', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Emite no front-end os cabeçalhos de segurança declarados na configuração. COOP fica travado em same-origin-allow-popups porque o fluxo de leads abre janela; HSTS sai apenas quando ligado por decisão e sobre HTTPS.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'send_headers',
				'metodo'     => 'emitir',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_cabecalhos' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'HTTPS na requisição', 'f3base' ),
				'presente' => is_ssl(),
				'detalhe'  => is_ssl()
					? __( 'HSTS pode ser emitido quando a decisão do cliente ligar a chave.', 'f3base' )
					: __( 'sem HTTPS, HSTS não é emitido em hipótese alguma.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( self::COOP_EXIGIDO !== (string) $config['coop'] ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: valor gravado, 2: valor exigido. */
					__( 'COOP gravado como %1$s: o fluxo de leads abre janela e exige %2$s.', 'f3base' ),
					(string) $config['coop'],
					self::COOP_EXIGIDO
				)
			);
		}

		if ( ! empty( $config['hsts'] ) && ! is_ssl() ) {
			return $this->degradado(
				__( 'HSTS ligado sem HTTPS nesta requisição: o cabeçalho não é emitido, e ligá-lo aqui não teria efeito seguro.', 'f3base' )
			);
		}

		if ( empty( $config['hsts'] ) ) {
			return $this->ativo(
				sprintf(
					/* translators: %s: valor do COOP. */
					__( 'emitindo a lista declarada com COOP %s; HSTS desligado por padrão, como decisão do cliente.', 'f3base' ),
					self::COOP_EXIGIDO
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: max-age do HSTS, em segundos. */
				__( 'emitindo a lista declarada, com HSTS em max-age de %d segundos na etapa escalonada vigente.', 'f3base' ),
				(int) $config['hsts_max_age']
			)
		);
	}

	/**
	 * Emite os cabeçalhos.
	 *
	 * @return void
	 */
	public function emitir(): void {
		if ( is_admin() || headers_sent() ) {
			return;
		}

		$config = $this->config();

		if ( ! empty( $config['x_content_type_options'] ) ) {
			header( 'X-Content-Type-Options: nosniff' );
		}

		$frame = (string) $config['x_frame_options'];
		if ( '' !== $frame ) {
			header( 'X-Frame-Options: ' . $frame );
		}

		$ancestrais = (string) $config['csp_frame_ancestors'];
		if ( '' !== $ancestrais ) {
			header( 'Content-Security-Policy: frame-ancestors ' . $ancestrais );
		}

		$referrer = (string) $config['referrer_policy'];
		if ( '' !== $referrer ) {
			header( 'Referrer-Policy: ' . $referrer );
		}

		header( 'Cross-Origin-Opener-Policy: ' . self::COOP_EXIGIDO );

		$permissoes = (string) $config['permissions_policy'];
		if ( '' !== $permissoes ) {
			header( 'Permissions-Policy: ' . $permissoes );
		}

		if ( ! empty( $config['hsts'] ) && is_ssl() ) {
			header( 'Strict-Transport-Security: max-age=' . (int) $config['hsts_max_age'] );
		}
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$declaracao = F3Base_Options::declaracao( 'f3base_cabecalhos' );
		$padrao     = null !== $declaracao && is_array( $declaracao['padrao'] ) ? $declaracao['padrao'] : array();
		$config     = F3Base_Options::ler( 'f3base_cabecalhos' );

		return array_merge( $padrao, is_array( $config ) ? $config : array() );
	}
}
