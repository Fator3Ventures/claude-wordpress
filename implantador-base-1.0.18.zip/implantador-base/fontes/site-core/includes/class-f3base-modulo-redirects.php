<?php
/**
 * Módulo redirects.
 *
 * O WordPress não tem: `wp_check_for_changed_slugs()` ignora tipos hierárquicos e
 * `wp_old_slug_redirect()` só olha a query var `name` com `post_type = post`. Aqui
 * o redirecionamento lê `_f3base_old_slug` e trata `pagename` E `name` — com
 * permalinks `/%postname%/`, uma URL de um nível chega como `name`.
 *
 * Também aplica os pares declarados em `f3base_redirects`.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Redirecionamento de slug antigo e pares declarados.
 */
final class F3Base_Modulo_Redirects extends F3Base_Modulo {

	/**
	 * Meta que guarda o slug antigo de um conteúdo gerenciado.
	 */
	public const META = '_f3base_old_slug';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'redirects';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Redirects de slug', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Redireciona slugs antigos de páginas e posts lendo _f3base_old_slug, tratando as query vars pagename e name, e aplica os pares declarados em f3base_redirects antes do 404.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_redirecionar',
				'prioridade' => 1,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_redirects' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'Permalinks com /%postname%/', 'f3base' ),
				'presente' => str_contains( (string) get_option( 'permalink_structure', '' ), '%postname%' ),
				'detalhe'  => __( 'com essa estrutura, uma URL de um nível chega como name e não como pagename — os dois são tratados.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::REDIRECTS_SERVIDOS, __( 'Redirects servidos', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$declarados = $this->declarados();

		return $this->ativo(
			sprintf(
				/* translators: %d: quantidade de pares declarados. */
				_n(
					'lendo %d par declarado e o slug antigo gravado em cada conteúdo gerenciado, por pagename e por name.',
					'lendo %d pares declarados e o slug antigo gravado em cada conteúdo gerenciado, por pagename e por name.',
					count( $declarados ),
					'f3base'
				),
				count( $declarados )
			)
		);
	}

	/**
	 * Aplica o redirecionamento quando houver destino.
	 *
	 * @return void
	 */
	public function talvez_redirecionar(): void {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		$declarado = $this->casar_declarado();
		if ( null !== $declarado ) {
			$this->executar( $declarado['para'], $declarado['status'], 'declarado' );
			return;
		}

		if ( ! is_404() ) {
			return;
		}

		$destino = $this->destino_por_slug_antigo();
		if ( '' !== $destino ) {
			$this->executar( $destino, 301, 'slug-antigo' );
		}
	}

	/**
	 * Casa o caminho atual com os pares declarados.
	 *
	 * @return array{para:string,status:int}|null
	 */
	private function casar_declarado(): ?array {
		$declarados = $this->declarados();
		if ( array() === $declarados ) {
			return null;
		}

		$atual = $this->caminho_atual();
		if ( '' === $atual ) {
			return null;
		}

		$normaliza = static fn ( string $caminho ): string => '/' . trim( strtok( $caminho, '?' ) ?: '', '/' );

		$atual_norm = $normaliza( $atual );

		foreach ( $declarados as $regra ) {
			if ( $normaliza( (string) $regra['de'] ) !== $atual_norm ) {
				continue;
			}

			return array(
				'para'   => home_url( (string) $regra['para'] ),
				'status' => (int) $regra['status'],
			);
		}

		return null;
	}

	/**
	 * Procura um conteúdo gerenciado pelo slug antigo pedido.
	 *
	 * @return string Permalink de destino, ou vazio.
	 */
	private function destino_por_slug_antigo(): string {
		$candidatos = array();

		foreach ( array( 'pagename', 'name' ) as $var ) {
			$valor = get_query_var( $var );
			$valor = is_string( $valor ) ? trim( $valor, '/' ) : '';

			if ( '' === $valor ) {
				continue;
			}

			$candidatos[] = $valor;

			if ( str_contains( $valor, '/' ) ) {
				$partes = explode( '/', $valor );
				$ultimo = (string) end( $partes );
				if ( '' !== $ultimo ) {
					$candidatos[] = $ultimo;
				}
			}
		}

		$candidatos = array_values( array_unique( array_filter( array_map( 'sanitize_title', $candidatos ) ) ) );

		if ( array() === $candidatos ) {
			return '';
		}

		$tipos = get_post_types( array( 'public' => true ), 'names' );
		$tipos = is_array( $tipos ) ? array_values( $tipos ) : array( 'post', 'page' );

		foreach ( $candidatos as $slug ) {
			$encontrados = get_posts(
				array(
					'post_type'              => $tipos,
					'post_status'            => array( 'publish', 'private' ),
					'numberposts'            => 1,
					'fields'                 => 'ids',
					'suppress_filters'       => false,
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
					'ignore_sticky_posts'    => true,
					'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						array(
							'key'     => self::META,
							'value'   => $slug,
							'compare' => '=',
						),
					),
				)
			);

			if ( ! is_array( $encontrados ) || array() === $encontrados ) {
				continue;
			}

			$permalink = get_permalink( (int) $encontrados[0] );

			if ( is_string( $permalink ) && '' !== $permalink ) {
				return $permalink;
			}
		}

		return '';
	}

	/**
	 * Executa o redirecionamento e carimba a atividade.
	 *
	 * @param string $destino Destino absoluto.
	 * @param int    $status  Código HTTP.
	 * @param string $origem  Mecanismo que decidiu.
	 * @return void
	 */
	private function executar( string $destino, int $status, string $origem ): void {
		if ( 410 === $status ) {
			F3Base_Atividade::registrar(
				F3Base_Atividade::REDIRECTS_SERVIDOS,
				array(
					'ultimo_de'  => $this->caminho_atual(),
					'mecanismo'  => $origem,
					'status'     => 410,
				)
			);
			F3Base_Atividade::incrementar( F3Base_Atividade::REDIRECTS_SERVIDOS, 'total' );

			status_header( 410 );
			nocache_headers();
			return;
		}

		$destino = wp_validate_redirect( $destino, '' );
		if ( '' === $destino ) {
			return;
		}

		F3Base_Atividade::registrar(
			F3Base_Atividade::REDIRECTS_SERVIDOS,
			array(
				'ultimo_de'   => $this->caminho_atual(),
				'ultimo_para' => $destino,
				'mecanismo'   => $origem,
				'status'      => $status,
			)
		);
		F3Base_Atividade::incrementar( F3Base_Atividade::REDIRECTS_SERVIDOS, 'total' );

		wp_safe_redirect( $destino, $status, 'f3base-site-core' );
		exit;
	}

	/**
	 * Caminho pedido nesta requisição.
	 *
	 * @return string
	 */
	private function caminho_atual(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $uri ) {
			return '';
		}

		$partes = wp_parse_url( $uri );

		return is_array( $partes ) && isset( $partes['path'] ) ? (string) $partes['path'] : '';
	}

	/**
	 * Pares declarados normalizados.
	 *
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	private function declarados(): array {
		$regras = F3Base_Options::ler( 'f3base_redirects' );

		return is_array( $regras ) ? $regras : array();
	}
}
