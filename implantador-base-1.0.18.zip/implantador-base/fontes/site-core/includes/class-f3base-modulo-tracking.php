<?php
/**
 * Módulo tracking.
 *
 * Slots de terceiro nascem inertes. A tag do LinkedIn só existe no HTML quando
 * `f3base_linkedin_partner_id` estiver preenchida E houver consentimento — e o
 * próprio carregador confere o consentimento de novo no navegador, porque página
 * em cache congela a decisão do primeiro visitante. Sem ID, nada sai: nunca um
 * placeholder.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tags de terceiro e eventos de medição.
 */
final class F3Base_Modulo_Tracking extends F3Base_Modulo {

	/**
	 * Handle do carregador do LinkedIn.
	 */
	public const HANDLE_LINKEDIN = 'f3base-linkedin';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'tracking';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Tracking', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Governa os slots de tag de terceiro e os eventos recomendados do GA4. O carregador do LinkedIn só entra no HTML com Partner ID preenchido e consentimento vigente; sem ID, nenhuma marcação é emitida.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 20,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_linkedin_partner_id', 'f3base_tracking' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$id = $this->partner_id();

		return array(
			array(
				'rotulo'   => __( 'Partner ID do LinkedIn', 'f3base' ),
				'presente' => '' !== $id,
				'detalhe'  => '' !== $id
					? __( 'slot preenchido: o carregador entra sob consentimento.', 'f3base' )
					: __( 'vazio por configuração: o slot permanece inerte e nada é emitido.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Módulo de consentimento', 'f3base' ),
				'presente' => class_exists( 'F3Base_Modulo_Consentimento' ),
				'detalhe'  => __( 'decide se a tag pode ser emitida nesta requisição e no navegador.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$id      = $this->partner_id();
		$eventos = $this->eventos_ga4();

		if ( '' === $id && ! $eventos ) {
			return $this->inativo(
				__( 'nenhum slot de terceiro preenchido e eventos do GA4 desligados: não há requisito de medição neste projeto.', 'f3base' )
			);
		}

		if ( '' === $id ) {
			return $this->ativo(
				__( 'slot do LinkedIn vazio por configuração — nenhuma tag de terceiro no HTML — e eventos do GA4 entregues pelo stub do Consent Mode.', 'f3base' )
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %s: Partner ID do LinkedIn. */
				__( 'carregador do LinkedIn %s emitido apenas com consentimento vigente, conferido no servidor e de novo no navegador.', 'f3base' ),
				$id
			)
		);
	}

	/**
	 * Enfileira o carregador do LinkedIn quando os dois portões abrem.
	 *
	 * @return void
	 */
	public function enfileirar(): void {
		$id = $this->partner_id();
		if ( '' === $id ) {
			return;
		}

		if ( ! F3Base_Modulo_Consentimento::permite_tags() ) {
			return;
		}

		wp_enqueue_script(
			self::HANDLE_LINKEDIN,
			F3BASE_SITE_CORE_URL . 'assets/f3base-linkedin.js',
			array( F3Base_Modulo_Consentimento::HANDLE ),
			F3BASE_SITE_CORE_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		wp_localize_script(
			self::HANDLE_LINKEDIN,
			'f3baseLinkedinDados',
			array(
				'partnerId' => $id,
				'origem'    => 'https://snap.licdn.com/li.lms-analytics/insight.min.js',
			)
		);
	}

	/**
	 * Partner ID configurado.
	 *
	 * @return string
	 */
	private function partner_id(): string {
		$id = F3Base_Options::ler( 'f3base_linkedin_partner_id' );

		return is_string( $id ) ? $id : '';
	}

	/**
	 * Os eventos recomendados do GA4 estão ligados?
	 *
	 * @return bool
	 */
	private function eventos_ga4(): bool {
		$tracking = F3Base_Options::ler( 'f3base_tracking' );

		return is_array( $tracking ) && ! empty( $tracking['eventos_ga4'] );
	}
}
