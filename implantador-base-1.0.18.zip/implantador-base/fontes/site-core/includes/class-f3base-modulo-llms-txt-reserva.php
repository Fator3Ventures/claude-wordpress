<?php
/**
 * Módulo llms-txt-reserva.
 *
 * Rota virtual `/llms.txt` servida APENAS quando não existe arquivo físico na
 * raiz — a mesma física do robots.txt: arquivo existente vence.
 *
 * Registrada em `template_redirect` com prioridade 0, antes de
 * `redirect_canonical`, que acrescentaria barra à rota virtual e devolveria 301
 * para `/llms.txt/`.
 *
 * Reserva ociosa com o principal funcionando é o desenho: com o arquivo físico
 * presente, o estado continua ativo e o motivo diz que a rota está em espera.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reserva do /llms.txt.
 */
final class F3Base_Modulo_Llms_Txt_Reserva extends F3Base_Modulo {

	/**
	 * Caminho público do recurso.
	 */
	public const CAMINHO = '/llms.txt';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'llms-txt-reserva';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Reserva do llms.txt', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Serve /llms.txt por rota virtual quando não há arquivo físico na raiz, com a seleção curada da configuração. Registrada em template_redirect prioridade 0 para não receber a barra final de redirect_canonical.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_servir',
				'prioridade' => 0,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$fisico = self::arquivo_fisico();

		return array(
			array(
				'rotulo'   => __( 'Arquivo físico llms.txt na raiz', 'f3base' ),
				'presente' => '' !== $fisico,
				'detalhe'  => '' !== $fisico
					? sprintf(
						/* translators: %s: caminho do arquivo. */
						__( 'presente em %s: é ele quem responde, e a rota fica de reserva.', 'f3base' ),
						$fisico
					)
					: __( 'ausente: quem responde no endereço público é esta rota.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LLMS, __( 'Última resposta pela rota reserva', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( empty( $config['ligado'] ) ) {
			return $this->inativo(
				__( 'recurso llms.txt desligado na configuração de bots de IA: nenhum hook, nenhuma rota e nenhuma superfície pública.', 'f3base' )
			);
		}

		$fisico = self::arquivo_fisico();

		if ( '' !== $fisico ) {
			return $this->ativo(
				__( 'arquivo físico presente na raiz: a rota reserva fica em espera, que é o desenho.', 'f3base' )
			);
		}

		$itens = $this->itens();

		if ( array() === $itens ) {
			return $this->degradado(
				__( 'sem arquivo físico e sem seleção curada em f3base_llms: a rota responderia só com o cabeçalho do site.', 'f3base' )
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: número de itens curados. */
				_n( 'respondendo no endereço público com %d item curado.', 'respondendo no endereço público com %d itens curados.', count( $itens ), 'f3base' ),
				count( $itens )
			)
		);
	}

	/**
	 * Serve a rota quando ela é a responsável pelo endereço.
	 *
	 * @return void
	 */
	public function talvez_servir(): void {
		if ( ! $this->requisicao_do_llms() ) {
			return;
		}

		if ( '' !== self::arquivo_fisico() ) {
			return;
		}

		$conteudo = $this->montar();

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMO_LLMS,
			array(
				'bytes'      => strlen( $conteudo ),
				'itens'      => count( $this->itens() ),
				'respondeu'  => 'rota-reserva',
			)
		);

		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: text/plain; charset=utf-8' );
			header( 'X-Robots-Tag: noindex' );
			header( 'X-F3Base-Mecanismo: rota-reserva' );
			nocache_headers();
		}

		echo $conteudo; // phpcs:ignore WordPress.Security.EscapingOutput -- text/plain montado a partir de valores já sanitizados.
		exit;
	}

	/**
	 * A requisição atual é do endereço público do llms.txt?
	 *
	 * @return bool
	 */
	private function requisicao_do_llms(): bool {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $uri ) {
			return false;
		}

		$partes  = wp_parse_url( $uri );
		$caminho = is_array( $partes ) && isset( $partes['path'] ) ? (string) $partes['path'] : '';
		$caminho = rtrim( $caminho, '/' );

		if ( '' === $caminho ) {
			return false;
		}

		$casa   = wp_parse_url( home_url( '/' ) );
		$prefixo = is_array( $casa ) && isset( $casa['path'] ) ? rtrim( (string) $casa['path'], '/' ) : '';

		return $caminho === $prefixo . self::CAMINHO || $caminho === self::CAMINHO;
	}

	/**
	 * Caminho do arquivo físico, quando existir.
	 *
	 * @return string Caminho absoluto, ou vazio.
	 */
	public static function arquivo_fisico(): string {
		$caminho = trailingslashit( ABSPATH ) . 'llms.txt';

		return file_exists( $caminho ) ? $caminho : '';
	}

	/**
	 * Monta o conteúdo servido.
	 *
	 * @return string
	 */
	private function montar(): string {
		$config = $this->config();

		$nome    = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$tagline = wp_specialchars_decode( (string) get_bloginfo( 'description' ), ENT_QUOTES );

		$linhas = array();
		$linhas[] = '# ' . $nome;
		$linhas[] = '';

		$introducao = isset( $config['introducao'] ) ? trim( (string) $config['introducao'] ) : '';
		if ( '' === $introducao ) {
			$introducao = $tagline;
		}
		if ( '' !== $introducao ) {
			$linhas[] = '> ' . $introducao;
			$linhas[] = '';
		}

		$livres = isset( $config['livres'] ) && is_array( $config['livres'] ) ? $config['livres'] : array();
		if ( array() !== $livres ) {
			$linhas[] = '## ' . __( 'Páginas', 'f3base' );
			foreach ( $livres as $item ) {
				$linha = $this->linha_item( $item );
				if ( '' !== $linha ) {
					$linhas[] = $linha;
				}
			}
			$linhas[] = '';
		}

		$politica = isset( $config['politica_privacidade'] ) && is_array( $config['politica_privacidade'] ) ? $config['politica_privacidade'] : array();
		$linha_politica = $this->linha_item( $politica );
		if ( '' !== $linha_politica ) {
			$linhas[] = '## ' . __( 'Política', 'f3base' );
			$linhas[] = $linha_politica;
			$linhas[] = '';
		}

		return implode( "\n", $linhas ) . "\n";
	}

	/**
	 * Monta uma linha de item.
	 *
	 * @param mixed $item Item curado.
	 * @return string
	 */
	private function linha_item( $item ): string {
		if ( ! is_array( $item ) || empty( $item['url'] ) ) {
			return '';
		}

		$titulo = isset( $item['titulo'] ) ? (string) $item['titulo'] : '';
		if ( '' === $titulo ) {
			$titulo = (string) $item['url'];
		}

		$linha = '- [' . $titulo . '](' . (string) $item['url'] . ')';

		$descricao = isset( $item['descricao'] ) ? trim( (string) $item['descricao'] ) : '';
		if ( '' !== $descricao ) {
			$linha .= ': ' . $descricao;
		}

		return $linha;
	}

	/**
	 * Itens curados declarados.
	 *
	 * @return array<int,array<string,string>>
	 */
	private function itens(): array {
		$config = $this->config();
		$itens  = isset( $config['livres'] ) && is_array( $config['livres'] ) ? $config['livres'] : array();

		if ( isset( $config['politica_privacidade'] ) && is_array( $config['politica_privacidade'] ) && ! empty( $config['politica_privacidade']['url'] ) ) {
			$itens[] = $config['politica_privacidade'];
		}

		return $itens;
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_llms' );

		return is_array( $config ) ? $config : array();
	}
}
