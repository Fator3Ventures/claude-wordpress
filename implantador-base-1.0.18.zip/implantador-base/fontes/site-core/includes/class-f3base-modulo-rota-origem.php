<?php
/**
 * Módulo rota-origem.
 *
 * A rota de leitura de volta pela ORIGEM: o servidor pede a própria URL pública e
 * devolve status, cabeçalhos e corpo, carimbados com a fase `origem`.
 *
 * Restrição fechada: só caminho do próprio `home_url()`. O host é validado, o
 * redirecionamento não é seguido e destino livre é recusado pelo nome — rota que
 * aceita qualquer URL é SSRF com outro nome.
 *
 * Honestidade do instrumento: o resultado é evidência de origem, nunca do que o
 * visitante recebe. Cache ou CDN na frente ficam fora desta medição, e a diferença
 * entre as duas leituras é o próprio diagnóstico.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Leitura de volta pela origem.
 */
final class F3Base_Modulo_Rota_Origem extends F3Base_Modulo {

	/**
	 * Rota, dentro do namespace do plugin.
	 */
	public const ROTA = '/origem';

	/**
	 * Ação do nonce aceito pela rota.
	 */
	public const NONCE = 'f3base_origem';

	/**
	 * Fase carimbada em todo resultado.
	 */
	public const FASE = 'origem';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'rota-origem';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Rota de origem', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Requisita um caminho do próprio site a partir do servidor e devolve status, cabeçalhos e corpo carimbados com a fase origem. Aceita apenas caminho do próprio home_url, valida o host e não segue redirecionamento para fora.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'Loopback HTTP para o próprio host', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'a requisição sai do servidor para o próprio home_url; ambiente que barre loopback devolve erro de transporte no corpo do resultado.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_ORIGEM, __( 'Última leitura pela origem', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		return $this->ativo(
			sprintf(
				/* translators: %s: host autorizado. */
				__( 'aceita apenas caminhos de %s, sem seguir redirecionamento, e carimba o resultado como evidência de origem.', 'f3base' ),
				$this->host_do_site()
			)
		);
	}

	/**
	 * Registra a rota REST.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'ler' ),
				'permission_callback' => array( $this, 'pode_ler' ),
				'args'                => array(
					'caminho' => array(
						'type'        => 'string',
						'required'    => true,
						'description' => __( 'Caminho do próprio site, começando por barra.', 'f3base' ),
					),
					'corpo'   => array(
						'type'        => 'boolean',
						'required'    => false,
						'default'     => true,
						'description' => __( 'Incluir o corpo da resposta.', 'f3base' ),
					),
				),
			)
		);
	}

	/**
	 * Capability da rota.
	 *
	 * @return bool
	 */
	public function pode_ler(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Executa a leitura pela origem.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function ler( WP_REST_Request $requisicao ): WP_REST_Response {
		$autorizacao = $this->conferir_nonce( $requisicao );
		if ( true !== $autorizacao ) {
			return new WP_REST_Response(
				array(
					'fase'   => self::FASE,
					'ok'     => false,
					'codigo' => 'f3base_nonce_invalido',
					'motivo' => $autorizacao,
				),
				403
			);
		}

		$alvo = self::resolver_alvo( (string) $requisicao->get_param( 'caminho' ) );

		if ( ! $alvo['ok'] ) {
			return new WP_REST_Response(
				array(
					'fase'   => self::FASE,
					'ok'     => false,
					'codigo' => 'f3base_destino_recusado',
					'motivo' => $alvo['motivo'],
				),
				400
			);
		}

		$resposta = wp_remote_get(
			$alvo['url'],
			array(
				'timeout'     => 15,
				'redirection' => 0,
				'sslverify'   => true,
				'user-agent'  => 'f3base-site-core/' . F3BASE_SITE_CORE_VERSAO . ' (origem)',
				'headers'     => array(
					'Cache-Control' => 'no-cache',
					'Pragma'        => 'no-cache',
				),
			)
		);

		if ( is_wp_error( $resposta ) ) {
			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_ORIGEM,
				array(
					'caminho' => $alvo['caminho'],
					'status'  => 0,
					'erro'    => $resposta->get_error_code(),
				)
			);

			return new WP_REST_Response(
				array(
					'fase'   => self::FASE,
					'ok'     => false,
					'codigo' => 'f3base_transporte',
					'url'    => $alvo['url'],
					'motivo' => $resposta->get_error_message(),
				),
				502
			);
		}

		$status     = (int) wp_remote_retrieve_response_code( $resposta );
		$cabecalhos = wp_remote_retrieve_headers( $resposta );
		$cabecalhos = is_object( $cabecalhos ) && method_exists( $cabecalhos, 'getAll' ) ? $cabecalhos->getAll() : (array) $cabecalhos;
		$corpo      = (string) wp_remote_retrieve_body( $resposta );
		$bytes      = strlen( $corpo );

		$limite    = (int) apply_filters( 'f3base_origem_limite_corpo', 1048576 );
		$limite    = max( 1024, $limite );
		$truncado  = $bytes > $limite;
		$devolver  = (bool) $requisicao->get_param( 'corpo' );
		$conteudo  = $truncado ? substr( $corpo, 0, $limite ) : $corpo;

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_ORIGEM,
			array(
				'caminho' => $alvo['caminho'],
				'status'  => $status,
				'bytes'   => $bytes,
			)
		);

		return new WP_REST_Response(
			array(
				'fase'            => self::FASE,
				'ok'              => true,
				'url'             => $alvo['url'],
				'caminho'         => $alvo['caminho'],
				'status'          => $status,
				'cabecalhos'      => array_map( 'strval', $cabecalhos ),
				'redirecionado_para' => isset( $cabecalhos['location'] ) ? (string) $cabecalhos['location'] : '',
				'bytes'           => $bytes,
				'sha256'          => hash( 'sha256', $corpo ),
				'corpo_truncado'  => $truncado,
				'corpo'           => $devolver ? $conteudo : '',
				'evidencia'       => 'medida',
				'ressalva'        => __( 'Leitura pela origem do servidor. Não é o que o visitante recebe: cache ou CDN na frente ficam fora desta medição.', 'f3base' ),
			),
			200
		);
	}

	/**
	 * Resolve o alvo dentro do próprio `home_url()`.
	 *
	 * @param string $entrada Caminho ou URL informada.
	 * @return array{ok:bool,url:string,caminho:string,motivo:string}
	 */
	public static function resolver_alvo( string $entrada ): array {
		$recusa = static function ( string $motivo ): array {
			return array(
				'ok'      => false,
				'url'     => '',
				'caminho' => '',
				'motivo'  => $motivo,
			);
		};

		$entrada = trim( $entrada );
		if ( '' === $entrada ) {
			return $recusa( __( 'Caminho vazio.', 'f3base' ) );
		}

		if ( strlen( $entrada ) > 2000 ) {
			return $recusa( __( 'Caminho acima do limite aceito.', 'f3base' ) );
		}

		if ( str_contains( $entrada, "\n" ) || str_contains( $entrada, "\r" ) || str_contains( $entrada, "\0" ) ) {
			return $recusa( __( 'Caminho com controle de linha: recusado.', 'f3base' ) );
		}

		$casa = wp_parse_url( home_url( '/' ) );
		if ( ! is_array( $casa ) || ! isset( $casa['host'] ) ) {
			return $recusa( __( 'home_url do site não pôde ser interpretada.', 'f3base' ) );
		}

		$meu_host   = strtolower( (string) $casa['host'] );
		$meu_scheme = isset( $casa['scheme'] ) ? strtolower( (string) $casa['scheme'] ) : 'https';
		$minha_port = isset( $casa['port'] ) ? (int) $casa['port'] : 0;
		$meu_path   = isset( $casa['path'] ) ? rtrim( (string) $casa['path'], '/' ) : '';

		if ( str_starts_with( $entrada, '//' ) ) {
			return $recusa( __( 'URL sem esquema (protocol-relative) aponta para host externo: recusada.', 'f3base' ) );
		}

		$caminho = $entrada;
		$consulta = '';

		if ( str_contains( $entrada, '://' ) ) {
			$partes = wp_parse_url( $entrada );

			if ( ! is_array( $partes ) || ! isset( $partes['host'] ) ) {
				return $recusa( __( 'URL absoluta ilegível.', 'f3base' ) );
			}

			if ( isset( $partes['user'] ) || isset( $partes['pass'] ) ) {
				return $recusa( __( 'URL com credencial embutida: recusada.', 'f3base' ) );
			}

			$scheme = isset( $partes['scheme'] ) ? strtolower( (string) $partes['scheme'] ) : '';
			if ( ! in_array( $scheme, array( 'http', 'https' ), true ) ) {
				return $recusa( __( 'Esquema fora de http/https: recusado.', 'f3base' ) );
			}

			if ( strtolower( (string) $partes['host'] ) !== $meu_host ) {
				return $recusa(
					sprintf(
						/* translators: 1: host pedido, 2: host do site. */
						__( 'Host %1$s não é o host do site (%2$s): destino recusado.', 'f3base' ),
						strtolower( (string) $partes['host'] ),
						$meu_host
					)
				);
			}

			$porta = isset( $partes['port'] ) ? (int) $partes['port'] : 0;
			if ( $porta !== $minha_port ) {
				return $recusa( __( 'Porta divergente da porta do site: destino recusado.', 'f3base' ) );
			}

			$caminho  = isset( $partes['path'] ) ? (string) $partes['path'] : '/';
			$consulta = isset( $partes['query'] ) ? (string) $partes['query'] : '';
		} else {
			$partes = wp_parse_url( $entrada );
			if ( ! is_array( $partes ) || isset( $partes['host'] ) ) {
				return $recusa( __( 'Caminho com host embutido: recusado.', 'f3base' ) );
			}

			$caminho  = isset( $partes['path'] ) ? (string) $partes['path'] : '/';
			$consulta = isset( $partes['query'] ) ? (string) $partes['query'] : '';
		}

		if ( str_contains( rawurldecode( $caminho ), '..' ) ) {
			return $recusa( __( 'Caminho com travessia de diretório: recusado.', 'f3base' ) );
		}

		$caminho = '/' . ltrim( $caminho, '/' );

		if ( '' !== $meu_path && ! str_starts_with( $caminho, $meu_path . '/' ) && $caminho !== $meu_path ) {
			$caminho = $meu_path . $caminho;
		}

		$url = $meu_scheme . '://' . $meu_host;
		if ( $minha_port > 0 ) {
			$url .= ':' . $minha_port;
		}
		$url .= $caminho;
		if ( '' !== $consulta ) {
			$url .= '?' . $consulta;
		}

		$conferencia = wp_parse_url( $url );
		if ( ! is_array( $conferencia ) || ! isset( $conferencia['host'] ) || strtolower( (string) $conferencia['host'] ) !== $meu_host ) {
			return $recusa( __( 'Conferência final do host falhou: destino recusado.', 'f3base' ) );
		}

		return array(
			'ok'      => true,
			'url'     => $url,
			'caminho' => $caminho . ( '' !== $consulta ? '?' . $consulta : '' ),
			'motivo'  => '',
		);
	}

	/**
	 * Confere o nonce, ou a credencial do canal quando a sessão não é por cookie.
	 *
	 * Requisição autenticada por cookie já chega aqui com o nonce do REST
	 * validado pelo core; a exigência explícita cobre o caminho do operador. A
	 * credencial do canal (Application Password) não tem nonce por natureza e é
	 * aceita como o próprio documento prevê.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return true|string Verdadeiro quando autorizada, ou o motivo da recusa.
	 */
	private function conferir_nonce( WP_REST_Request $requisicao ) {
		$nonce = (string) $requisicao->get_param( '_wpnonce' );

		if ( '' === $nonce ) {
			$cabecalho = $requisicao->get_header( 'x_wp_nonce' );
			$nonce     = is_string( $cabecalho ) ? $cabecalho : '';
		}

		if ( '' !== $nonce && ( wp_verify_nonce( $nonce, self::NONCE ) || wp_verify_nonce( $nonce, 'wp_rest' ) ) ) {
			return true;
		}

		$por_cookie = defined( 'LOGGED_IN_COOKIE' ) && isset( $_COOKIE[ LOGGED_IN_COOKIE ] );

		if ( ! $por_cookie ) {
			return true;
		}

		return __( 'Nonce ausente ou inválido para a rota de origem.', 'f3base' );
	}

	/**
	 * Host autorizado.
	 *
	 * @return string
	 */
	private function host_do_site(): string {
		$casa = wp_parse_url( home_url( '/' ) );

		return is_array( $casa ) && isset( $casa['host'] ) ? strtolower( (string) $casa['host'] ) : '';
	}
}
