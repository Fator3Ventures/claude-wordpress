<?php
/**
 * Módulo guarda-options-mcp.
 *
 * Estende por filtro a lista de options protegidas do servidor MCP com as options
 * gerenciadas do projeto. A lista vem do catálogo do gravador — não existe segunda
 * lista escrita à mão.
 *
 * Honestidade do desenho, repetida aqui porque é onde ela custa: a lista protegida
 * é trava contra acidente e disciplina de operação, NÃO fronteira de segurança —
 * as rotas de arquivo do canal alcançam o próprio código que a implementa. A
 * fronteira real é o usuário dedicado, a Application Password e as travas do canal.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Guarda das options gerenciadas no canal MCP.
 */
final class F3Base_Modulo_Guarda_Options_Mcp extends F3Base_Modulo {

	/**
	 * Pasta do plugin servidor do canal.
	 */
	public const PASTA_SERVIDOR = 'wp-mcp-ultimate';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'guarda-options-mcp';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Guarda das options no canal MCP', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Acrescenta as options gerenciadas do projeto à lista protegida do servidor MCP, pelos filtros que o servidor expõe. A lista sai do catálogo do gravador único, não de uma cópia paralela.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		$hooks = array();

		foreach ( self::filtros() as $nome ) {
			$hooks[] = array(
				'tipo'       => 'filter',
				'hook'       => $nome,
				'metodo'     => 'proteger',
				'prioridade' => 10,
				'args'       => 1,
			);
		}

		return $hooks;
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_mcp_files_audit' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$servidor = $this->plugin_ativo( self::PASTA_SERVIDOR );

		return array(
			array(
				'rotulo'   => __( 'Servidor MCP ativo', 'f3base' ),
				'presente' => $servidor,
				'detalhe'  => $servidor
					? __( 'presente: há lista protegida para estender.', 'f3base' )
					: __( 'ausente: nenhum filtro do servidor é aplicado e a guarda não tem onde agir.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Nome do filtro exposto pelo servidor', 'f3base' ),
				'presente' => $servidor,
				'detalhe'  => sprintf(
					/* translators: %s: lista de nomes de filtro. */
					__( 'pendência externa: a guarda se registra em %s; filtro que o servidor nunca aplica não protege nada, e o nome vigente é fato do fornecedor, não deste pacote.', 'f3base' ),
					implode( ', ', self::filtros() )
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		if ( ! $this->plugin_ativo( self::PASTA_SERVIDOR ) ) {
			return $this->degradado(
				__( 'servidor MCP ausente: sem canal, não há lista protegida para estender e as options gerenciadas ficam sem a trava contra acidente.', 'f3base' )
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: quantidade de options protegidas. */
				_n(
					'%d option gerenciada acrescentada à lista protegida do canal, lida do catálogo do gravador.',
					'%d options gerenciadas acrescentadas à lista protegida do canal, lidas do catálogo do gravador.',
					count( F3Base_Options::nomes() ),
					'f3base'
				),
				count( F3Base_Options::nomes() )
			)
		);
	}

	/**
	 * Acrescenta as options gerenciadas à lista protegida.
	 *
	 * @param mixed $lista Lista recebida do servidor.
	 * @return mixed Lista estendida, no formato em que chegou.
	 */
	public function proteger( $lista ) {
		$nossas = F3Base_Options::nomes();

		if ( is_array( $lista ) ) {
			// Lista associativa (option => motivo) é preservada como associativa.
			$associativa = array() !== $lista && array_keys( $lista ) !== range( 0, count( $lista ) - 1 );

			if ( $associativa ) {
				foreach ( $nossas as $nome ) {
					if ( ! array_key_exists( $nome, $lista ) ) {
						$lista[ $nome ] = __( 'Option gerenciada pelo F3 Base Site Core: edite pela tela do plugin.', 'f3base' );
					}
				}

				return $lista;
			}

			return array_values( array_unique( array_merge( array_map( 'strval', $lista ), $nossas ) ) );
		}

		if ( is_string( $lista ) ) {
			$atual = array_filter( array_map( 'trim', explode( ',', $lista ) ) );

			return implode( ',', array_unique( array_merge( $atual, $nossas ) ) );
		}

		return $nossas;
	}

	/**
	 * Nomes de filtro em que a guarda se registra.
	 *
	 * O nome vigente pertence ao fornecedor do servidor: por isso a lista é
	 * declarada e filtrável, e o estado do módulo diz que a efetividade depende
	 * de o servidor aplicar um destes nomes.
	 *
	 * @return string[]
	 */
	public static function filtros(): array {
		$filtros = array(
			'wp_mcp_ultimate_protected_options',
			'wp_mcp_ultimate_options_protegidas',
			'wp_mcp_protected_options',
			'mcp_protected_options',
		);

		/**
		 * Permite ao implantador declarar o nome do filtro vigente do servidor.
		 *
		 * @param string[] $filtros Nomes de filtro.
		 */
		$filtros = apply_filters( 'f3base_mcp_filtros_options_protegidas', $filtros );

		if ( ! is_array( $filtros ) ) {
			return array();
		}

		$limpos = array();

		foreach ( $filtros as $nome ) {
			$nome = trim( (string) $nome );
			if ( '' !== $nome ) {
				$limpos[] = $nome;
			}
		}

		return array_values( array_unique( $limpos ) );
	}
}
