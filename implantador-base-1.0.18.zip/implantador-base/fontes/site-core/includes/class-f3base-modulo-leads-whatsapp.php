<?php
/**
 * Módulo leads-whatsapp.
 *
 * Enfileira o JavaScript que monta a URL `wa.me` a partir de `f3base_contato`,
 * registra a interação e transporta a atribuição. O envio do registro é
 * `navigator.sendBeacon()` para o endpoint REST ANTES da navegação, fire and
 * forget: falha de registro nunca custa o lead nem atrasa a abertura da conversa.
 *
 * Sem o plugin ativo, o CTA degrada para link simples — o `href` do pattern do
 * tema continua respondendo; é este módulo que o promove a link profundo do
 * WhatsApp no servidor, para que o caminho sem JavaScript também funcione.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Comportamento do CTA de WhatsApp.
 */
final class F3Base_Modulo_Leads_Whatsapp extends F3Base_Modulo {

	/**
	 * Handle do script.
	 */
	public const HANDLE = 'f3base-leads';

	/**
	 * Atributo que marca um CTA de lead no HTML do tema.
	 */
	public const ATRIBUTO = 'data-f3base-lead';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'leads-whatsapp';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Leads por WhatsApp', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Monta a URL wa.me a partir do número de contato, registra a interação por sendBeacon antes da navegação e transporta a atribuição. Sem JavaScript, o link profundo continua respondendo com a mensagem padrão.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'render_block',
				'metodo'     => 'promover_cta',
				'prioridade' => 10,
				'args'       => 2,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_contato', 'f3base_atribuicao', 'f3base_tracking' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$numero    = $this->numero();
		$processor = class_exists( 'WP_HTML_Tag_Processor' );

		return array(
			array(
				'rotulo'   => __( 'Número de WhatsApp em f3base_contato', 'f3base' ),
				'presente' => '' !== $numero,
				'detalhe'  => '' !== $numero
					? __( 'destino do link profundo resolvido pela option.', 'f3base' )
					: __( 'sem número, não há link profundo a montar.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Endpoint de registro de leads', 'f3base' ),
				'presente' => class_exists( 'F3Base_Modulo_Endpoint_Leads' ),
				'detalhe'  => __( 'origem do token efêmero assinado que o beacon carrega.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'WP_HTML_Tag_Processor', 'f3base' ),
				'presente' => $processor,
				'detalhe'  => $processor
					? __( 'promoção do href acontece no servidor, sem regex sobre HTML.', 'f3base' )
					: __( 'ausente: o href do pattern não é promovido no servidor.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LEAD, __( 'Último lead registrado', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		if ( '' === $this->numero() ) {
			return $this->degradado(
				__( 'número de WhatsApp ausente em f3base_contato: o CTA permanece como link simples do tema, sem registro e sem evento.', 'f3base' )
			);
		}

		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $this->degradado(
				__( 'WP_HTML_Tag_Processor indisponível nesta versão do WordPress: o caminho sem JavaScript não recebe o link profundo.', 'f3base' )
			);
		}

		return $this->ativo(
			__( 'CTA promovido no servidor e registro enviado por beacon antes da navegação.', 'f3base' )
		);
	}

	/**
	 * Enfileira o script de leads e entrega a configuração como dado.
	 *
	 * @return void
	 */
	public function enfileirar(): void {
		$numero = $this->numero();
		if ( '' === $numero ) {
			return;
		}

		wp_enqueue_script(
			self::HANDLE,
			F3BASE_SITE_CORE_URL . 'assets/f3base-leads.js',
			array(),
			F3BASE_SITE_CORE_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		$atribuicao = F3Base_Options::ler( 'f3base_atribuicao' );
		$tracking   = F3Base_Options::ler( 'f3base_tracking' );

		wp_localize_script(
			self::HANDLE,
			'f3baseLeadsDados',
			array(
				'endpoint'   => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . '/lead' ) ),
				'token'      => F3Base_Modulo_Endpoint_Leads::emitir_token(),
				'numero'     => $numero,
				'mensagem'   => $this->mensagem_padrao(),
				'seletor'    => '[' . self::ATRIBUTO . ']',
				'atributo'   => self::ATRIBUTO,
				'atribuicao' => array(
					'modelo'  => is_array( $atribuicao ) ? (string) ( $atribuicao['modelo'] ?? 'first-touch' ) : 'first-touch',
					'ttlDias' => is_array( $atribuicao ) ? (int) ( $atribuicao['ttl_dias'] ?? 30 ) : 30,
					'chave'   => 'f3base_atribuicao',
				),
				'eventosGa4' => is_array( $tracking ) && ! empty( $tracking['eventos_ga4'] ),
				'limites'    => F3Base_Modulo_Endpoint_Leads::limites_publicos(),
			)
		);
	}

	/**
	 * Promove o CTA do tema a link profundo do WhatsApp, no servidor.
	 *
	 * O tema entrega um link simples; aqui ele ganha o `wa.me` com a mensagem
	 * padrão, para que o visitante sem JavaScript continue chegando à conversa.
	 *
	 * @param string              $html  HTML renderizado do bloco.
	 * @param array<string,mixed> $bloco Bloco analisado.
	 * @return string HTML possivelmente reescrito.
	 */
	public function promover_cta( string $html, array $bloco ): string {
		unset( $bloco );

		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $html;
		}

		if ( ! str_contains( $html, self::ATRIBUTO ) ) {
			return $html;
		}

		$numero = $this->numero();
		if ( '' === $numero ) {
			return $html;
		}

		$processor = new WP_HTML_Tag_Processor( $html );
		$mudou     = false;

		while ( $processor->next_tag( array( 'tag_name' => 'A' ) ) ) {
			if ( null === $processor->get_attribute( self::ATRIBUTO ) ) {
				continue;
			}

			$mensagem = $processor->get_attribute( 'data-f3base-mensagem' );
			$mensagem = is_string( $mensagem ) && '' !== $mensagem ? $mensagem : $this->mensagem_padrao();

			$processor->set_attribute( 'href', self::montar_url( $numero, $mensagem ) );
			$processor->set_attribute( 'rel', 'noopener' );
			$processor->set_attribute( 'data-f3base-numero', $numero );

			$mudou = true;
		}

		return $mudou ? $processor->get_updated_html() : $html;
	}

	/**
	 * Monta a URL `wa.me` com a mensagem.
	 *
	 * @param string $numero   Número em E.164 sem sinais.
	 * @param string $mensagem Mensagem inicial.
	 * @return string
	 */
	public static function montar_url( string $numero, string $mensagem ): string {
		$base = 'https://wa.me/' . rawurlencode( $numero );

		if ( '' === $mensagem ) {
			return $base;
		}

		return add_query_arg( 'text', rawurlencode( $mensagem ), $base );
	}

	/**
	 * Número de WhatsApp configurado.
	 *
	 * @return string
	 */
	private function numero(): string {
		$contato = F3Base_Options::ler( 'f3base_contato' );

		return is_array( $contato ) ? (string) ( $contato['whatsapp_e164'] ?? '' ) : '';
	}

	/**
	 * Mensagem padrão do CTA.
	 *
	 * @return string
	 */
	private function mensagem_padrao(): string {
		$contato  = F3Base_Options::ler( 'f3base_contato' );
		$mensagem = is_array( $contato ) ? trim( (string) ( $contato['mensagem_padrao'] ?? '' ) ) : '';

		if ( '' !== $mensagem ) {
			return $mensagem;
		}

		return sprintf(
			/* translators: %s: nome do site. */
			__( 'Olá! Vim pelo site %s e quero falar com a equipe.', 'f3base' ),
			wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES )
		);
	}
}
