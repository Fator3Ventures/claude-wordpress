<?php
/**
 * Gravador único de options do site-core.
 *
 * Regra dura do contrato: nenhuma chamada direta a `update_option`,
 * `update_site_option` ou `delete_option` fora desta classe. Todo módulo, a tela
 * de administração e o `uninstall.php` passam por aqui — o ponto único de escrita
 * é o que torna a leitura de volta e a procedência auditáveis.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Catálogo, sanitização, escrita com leitura de volta e procedência.
 */
final class F3Base_Options {

	/**
	 * Option onde o implantador registra a procedência de cada chave gravada.
	 */
	public const OPTION_PROVENIENCIA = 'f3base_proveniencia';

	/**
	 * Option onde o implantador declara quais chaves são operáveis pelo operador.
	 */
	public const OPTION_OPERAVEIS = 'f3base_operaveis';

	/**
	 * Procedências fechadas.
	 */
	public const ORIGEM_IMPLANTADOR = 'implantador';
	public const ORIGEM_MANUAL      = 'edicao-manual';
	public const ORIGEM_PADRAO      = 'padrao';

	/**
	 * Catálogo resolvido (memoizado por requisição).
	 *
	 * @var array<string,array<string,mixed>>|null
	 */
	private static ?array $catalogo = null;

	/**
	 * Catálogo das options gerenciadas pelo site-core.
	 *
	 * Cada entrada declara: rótulo, descrição, se é operável na tela, o tipo de
	 * campo do formulário, o padrão embutido e o sanitizador. O catálogo é a
	 * fonte única — a tela, a guarda do canal MCP e o relatório leem daqui.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function catalogo(): array {
		if ( null !== self::$catalogo ) {
			return self::$catalogo;
		}

		$catalogo = array(
			'f3base_contato'             => array(
				'rotulo'    => __( 'Contato de leads', 'f3base' ),
				'descricao' => __( 'Número de WhatsApp em E.164, e-mail de leads e mensagem padrão do CTA.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'grupo',
				'padrao'    => array(
					'whatsapp_e164'   => '',
					'email_leads'     => '',
					'mensagem_padrao' => '',
				),
				'subcampos' => array(
					'whatsapp_e164'   => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'WhatsApp (E.164)', 'f3base' ),
						'descricao' => __( 'Só dígitos, com código do país. Vazio mantém o CTA como link simples.', 'f3base' ),
					),
					'email_leads'     => array(
						'tipo'   => 'email',
						'rotulo' => __( 'E-mail de leads', 'f3base' ),
					),
					'mensagem_padrao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Mensagem padrão do CTA', 'f3base' ),
						'descricao' => __( 'Vazio usa a mensagem embutida com o nome do site.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_contato' ),
			),
			'f3base_consentimento'       => array(
				'rotulo'    => __( 'Consentimento', 'f3base' ),
				'descricao' => __( 'Padrão da política, controle no rodapé, aviso de primeira visita e TTL da decisão.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'grupo',
				'padrao'    => array(
					'padrao'                => 'pre-aprovado',
					'controle_rodape'       => true,
					'aviso_primeira_visita' => false,
					'ttl_dias'              => 180,
				),
				'subcampos' => array(
					'padrao'                => array(
						'tipo'   => 'enum',
						'rotulo' => __( 'Padrão da política', 'f3base' ),
						'opcoes' => array(
							'pre-aprovado' => __( 'pré-aprovado (tags carregam por padrão)', 'f3base' ),
							'negado'       => __( 'negado (tags só após o aceite)', 'f3base' ),
						),
					),
					'controle_rodape'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Controle de revisão no rodapé', 'f3base' ),
						'descricao' => __( 'Instrumento permanente do titular, presente em toda página.', 'f3base' ),
					),
					'aviso_primeira_visita' => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Aviso não bloqueante na primeira visita', 'f3base' ),
						'descricao' => __( 'Desligado por padrão. Ligar é decisão declarada por projeto.', 'f3base' ),
					),
					'ttl_dias'              => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'TTL da decisão (dias)', 'f3base' ),
						'descricao' => __( 'Prazo em que a negativa e o re-aceite persistem no navegador.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_consentimento' ),
			),
			'f3base_atribuicao'          => array(
				'rotulo'    => __( 'Atribuição', 'f3base' ),
				'descricao' => __( 'Modelo de atribuição transportado no clique de lead e prazo de persistência.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'grupo',
				'padrao'    => array(
					'modelo'   => 'first-touch',
					'ttl_dias' => 30,
				),
				'subcampos' => array(
					'modelo'   => array(
						'tipo'   => 'enum',
						'rotulo' => __( 'Modelo', 'f3base' ),
						'opcoes' => array(
							'first-touch' => __( 'first-touch', 'f3base' ),
							'last-touch'  => __( 'last-touch', 'f3base' ),
						),
					),
					'ttl_dias' => array(
						'tipo'   => 'inteiro',
						'rotulo' => __( 'TTL da atribuição (dias)', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_atribuicao' ),
			),
			'f3base_retencao_meses'      => array(
				'rotulo'    => __( 'Retenção de leads (meses)', 'f3base' ),
				'descricao' => __( 'Prazo operacional de guarda dos registros de lead antes da limpeza automática.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'inteiro',
				'padrao'    => 12,
				'sanitiza'  => array( __CLASS__, 'sanitiza_retencao_meses' ),
			),
			'f3base_linkedin_partner_id' => array(
				'rotulo'    => __( 'LinkedIn Partner ID', 'f3base' ),
				'descricao' => __( 'Vazio mantém o slot inerte: sem ID, nenhuma tag do LinkedIn existe no HTML.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'texto',
				'padrao'    => '',
				'sanitiza'  => array( __CLASS__, 'sanitiza_partner_id' ),
			),
			'f3base_tracking'            => array(
				'rotulo'    => __( 'Tracking', 'f3base' ),
				'descricao' => __( 'Chaves de comportamento de medição — hoje, o disparo dos eventos recomendados do GA4.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'grupo',
				'padrao'    => array(
					'eventos_ga4' => true,
				),
				'subcampos' => array(
					'eventos_ga4' => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Eventos recomendados do GA4', 'f3base' ),
						'descricao' => __( 'form_start e generate_lead disparados no acionamento, pelo stub do Consent Mode.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_tracking' ),
			),
			'f3base_llms'                => array(
				'rotulo'    => __( 'llms.txt', 'f3base' ),
				'descricao' => __( 'Liga o recurso e guarda a seleção curada servida pela rota reserva quando não há arquivo físico. A seleção em si é estrutural: vem da configuração, resolvida por referência lógica.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado'               => true,
					'introducao'           => '',
					'politica_privacidade' => array(),
					'livres'               => array(),
				),
				'subcampos' => array(
					'ligado'     => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Recurso llms.txt ligado', 'f3base' ),
						'descricao' => __( 'Desligado, o módulo de reserva fica inerte: sem hook e sem rota.', 'f3base' ),
					),
					'introducao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Introdução do arquivo', 'f3base' ),
						'descricao' => __( 'Vazio usa a descrição do site.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_llms' ),
			),
			'f3base_redirects'           => array(
				'rotulo'    => __( 'Redirects declarados', 'f3base' ),
				'descricao' => __( 'Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'sanitiza'  => array( __CLASS__, 'sanitiza_redirects' ),
			),
			'f3base_seo_entidade'        => array(
				'rotulo'    => __( 'Entidade de SEO', 'f3base' ),
				'descricao' => __( 'Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'nome'             => '',
					'same_as'          => array(),
					'area_servida'     => array(),
					'conhece_sobre'    => array(),
					'ponto_de_contato' => array(),
					'organizacao_mae'  => '',
					'servicos'         => array(),
					'faq_schema'       => false,
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_seo_entidade' ),
			),
			'f3base_cabecalhos'          => array(
				'rotulo'    => __( 'Cabeçalhos de resposta', 'f3base' ),
				'descricao' => __( 'Cabeçalhos de segurança emitidos no front-end. COOP fica travado em same-origin-allow-popups; HSTS desligado por padrão.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'x_content_type_options' => true,
					'x_frame_options'        => 'SAMEORIGIN',
					'csp_frame_ancestors'    => "'self'",
					'referrer_policy'        => 'strict-origin-when-cross-origin',
					'coop'                   => 'same-origin-allow-popups',
					'permissions_policy'     => 'geolocation=(), camera=(), microphone=()',
					'hsts'                   => false,
					'hsts_max_age'           => 300,
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_cabecalhos' ),
			),
			'f3base_copy_contrato'       => array(
				'rotulo'    => __( 'Contrato de copy', 'f3base' ),
				'descricao' => __( 'Frases canônicas que devem aparecer e que não podem voltar. Estrutural: gravada pelo implantador.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'devem_aparecer'   => array(),
					'nao_podem_voltar' => array(),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_copy_contrato' ),
			),
			'f3base_nav_id'              => array(
				'rotulo'    => __( 'ID da navegação', 'f3base' ),
				'descricao' => __( 'Post wp_navigation gerenciado. Estrutural: quebrar o vínculo derruba o menu do topo.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'inteiro',
				'padrao'    => 0,
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_post' ),
			),
			'f3base_mcp_files_audit'     => array(
				'rotulo'    => __( 'Auditoria de escritas do canal MCP', 'f3base' ),
				'descricao' => __( 'Registro mantido pelo complemento do canal. Estrutural: leitura apenas.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'sanitiza'  => array( __CLASS__, 'sanitiza_lista_generica' ),
			),
			'f3base_atividade'           => array(
				'rotulo'    => __( 'Última atividade relevante', 'f3base' ),
				'descricao' => __( 'Carimbos do que cada módulo fez por último. Estado de execução, não configuração.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_atividade' ),
			),
			'f3base_journal_eliminacao'  => array(
				'rotulo'    => __( 'Journal de eliminação', 'f3base' ),
				'descricao' => __( 'Identificador, contagem, carimbo, operador e regime de cada eliminação. Nunca o conteúdo eliminado.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_journal' ),
			),
			'f3base_origem_confiavel'    => array(
				'rotulo'    => __( 'Origem confiável do rate limit', 'f3base' ),
				'descricao' => __( 'Cabeçalho de proxy em que este site confia para descobrir o IP do visitante. Vazio por padrão, e vazio significa NUNCA confiar: atrás de CDN ou proxy reverso, REMOTE_ADDR é o mesmo para todo mundo e o balde vira um só; aceitar o cabeçalho sem declaração deixa o visitante escolher em que balde ele conta.', 'f3base' ),
				'operavel'  => true,
				'campo'     => 'grupo',
				'padrao'    => array(
					'cabecalho' => '',
					'saltos'    => 1,
				),
				'subcampos' => array(
					'cabecalho' => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Cabeçalho confiável', 'f3base' ),
						'descricao' => __( 'Exemplos: X-Forwarded-For, CF-Connecting-IP. Vazio conta por REMOTE_ADDR.', 'f3base' ),
					),
					'saltos'    => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Saltos de proxy confiáveis', 'f3base' ),
						'descricao' => __( 'Quantos proxies seus estão na frente do site. O valor é lido descontando esses saltos da direita da lista, que é a única parte que o proxy da frente escreveu.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_origem_confiavel' ),
			),
			'f3base_cadencia'            => array(
				'rotulo'    => __( 'Cadência do modo somente-relatório', 'f3base' ),
				'descricao' => __( 'Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'periodicidade'  => 'nenhuma',
					'apos_n_ajustes' => 0,
					'mecanismo'      => '',
					'hook'           => '',
				),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_cadencia' ),
			),
			'f3base_cadencia_estado'     => array(
				'rotulo'    => __( 'Estado da cadência', 'f3base' ),
				'descricao' => __( 'Contador de ajustes desde o último relatório e carimbo previsto da próxima execução. Estado de execução, não configuração.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ajustes'  => 0,
					'previsto' => 0,
				),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_cadencia_estado' ),
			),
			'f3base_endpoint_segredo'    => array(
				'rotulo'    => __( 'Segredo do token efêmero', 'f3base' ),
				'descricao' => __( 'Chave HMAC do token do endpoint de leads. Gerada na ativação; nunca exibida.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'segredo',
				'padrao'    => '',
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_segredo' ),
			),
		);

		/**
		 * Permite ao implantador ou ao complemento do canal declarar options
		 * gerenciadas adicionais sem editar o catálogo embutido.
		 *
		 * @param array<string,array<string,mixed>> $catalogo Catálogo declarado.
		 */
		$catalogo = apply_filters( 'f3base_options_catalogo', $catalogo );

		self::$catalogo = is_array( $catalogo ) ? $catalogo : array();

		return self::$catalogo;
	}

	/**
	 * Nomes das options gerenciadas.
	 *
	 * @return string[]
	 */
	public static function nomes(): array {
		return array_keys( self::catalogo() );
	}

	/**
	 * Declaração de uma option do catálogo.
	 *
	 * @param string $nome Nome da option.
	 * @return array<string,mixed>|null Declaração, ou null quando não gerenciada.
	 */
	public static function declaracao( string $nome ): ?array {
		$catalogo = self::catalogo();

		return isset( $catalogo[ $nome ] ) ? $catalogo[ $nome ] : null;
	}

	/**
	 * Uma option é operável pelo operador na tela?
	 *
	 * A declaração do catálogo é o teto; `f3base_operaveis`, quando presente,
	 * restringe — o implantador pode fechar o que não quer aberto, nunca abrir
	 * o que o catálogo declarou estrutural.
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function operavel( string $nome ): bool {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao || empty( $declaracao['operavel'] ) ) {
			return false;
		}

		$lista = get_option( self::OPTION_OPERAVEIS, null );
		if ( ! is_array( $lista ) || array() === $lista ) {
			return true;
		}

		return in_array( $nome, array_map( 'strval', $lista ), true );
	}

	/**
	 * Lê uma option gerenciada já normalizada pelo sanitizador declarado.
	 *
	 * Ler pelo sanitizador garante forma: chave ausente ou valor corrompido não
	 * vira notice no consumidor.
	 *
	 * @param string $nome Nome da option.
	 * @return mixed Valor normalizado.
	 */
	public static function ler( string $nome ) {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return null;
		}

		$bruto = get_option( $nome, null );
		if ( null === $bruto ) {
			return $declaracao['padrao'];
		}

		return self::sanitizar( $nome, $bruto );
	}

	/**
	 * A option existe no banco?
	 *
	 * @param string $nome Nome da option.
	 * @return bool
	 */
	public static function existe( string $nome ): bool {
		return null !== get_option( $nome, null );
	}

	/**
	 * Sanitiza um valor com o sanitizador declarado da option.
	 *
	 * @param string $nome  Nome da option.
	 * @param mixed  $valor Valor bruto.
	 * @return mixed Valor normalizado.
	 */
	public static function sanitizar( string $nome, $valor ) {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return null;
		}

		$sanitizador = isset( $declaracao['sanitiza'] ) ? $declaracao['sanitiza'] : null;
		if ( ! is_callable( $sanitizador ) ) {
			return $declaracao['padrao'];
		}

		return call_user_func( $sanitizador, $valor, $declaracao['padrao'] );
	}

	/**
	 * Grava uma option gerenciada e devolve a leitura de volta.
	 *
	 * @param string $nome   Nome da option.
	 * @param mixed  $valor  Valor bruto (será sanitizado).
	 * @param string $origem Procedência da escrita.
	 * @return array{ok:bool,lido:mixed,motivo:string} Resultado com leitura de volta.
	 */
	public static function gravar( string $nome, $valor, string $origem = self::ORIGEM_MANUAL ): array {
		$declaracao = self::declaracao( $nome );
		if ( null === $declaracao ) {
			return array(
				'ok'     => false,
				'lido'   => null,
				'motivo' => sprintf(
					/* translators: %s: nome da option. */
					__( 'Option %s não é gerenciada pelo site-core: escrita recusada.', 'f3base' ),
					$nome
				),
			);
		}

		$normalizado = self::sanitizar( $nome, $valor );
		$autoload    = array_key_exists( 'autoload', $declaracao ) ? (bool) $declaracao['autoload'] : true;

		self::escrever( $nome, $normalizado, $autoload );

		$lido = self::ler( $nome );

		$conferiu = self::equivalente( $normalizado, $lido );
		$motivo   = '';

		if ( ! $conferiu ) {
			$motivo = sprintf(
				/* translators: %s: nome da option. */
				__( 'Leitura de volta divergiu do valor gravado em %s.', 'f3base' ),
				$nome
			);
		} elseif ( ! self::equivalente( $valor, $lido ) && is_scalar( $valor ) ) {
			$motivo = sprintf(
				/* translators: %s: nome da option. */
				__( 'Valor normalizado pela sanitização de %s antes da gravação.', 'f3base' ),
				$nome
			);
		}

		if ( self::OPTION_PROVENIENCIA !== $nome ) {
			self::registrar_proveniencia( $nome, $origem );
		}

		return array(
			'ok'     => $conferiu,
			'lido'   => $lido,
			'motivo' => $motivo,
		);
	}

	/**
	 * Remove uma option gerenciada. Ponto único de `delete_option`.
	 *
	 * @param string $nome Nome da option.
	 * @return bool Verdadeiro quando a option deixou de existir.
	 */
	public static function remover( string $nome ): bool {
		if ( null === self::declaracao( $nome ) ) {
			return false;
		}

		delete_option( $nome );

		return ! self::existe( $nome );
	}

	/**
	 * Procedência conhecida de uma option gerenciada.
	 *
	 * @param string $nome Nome da option.
	 * @return string Uma das constantes de origem.
	 */
	public static function proveniencia( string $nome ): string {
		$registro = get_option( self::OPTION_PROVENIENCIA, array() );

		if ( is_array( $registro ) && isset( $registro[ $nome ] ) ) {
			$entrada = $registro[ $nome ];
			$origem  = is_array( $entrada ) && isset( $entrada['origem'] ) ? (string) $entrada['origem'] : (string) $entrada;

			if ( in_array( $origem, array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO ), true ) ) {
				return $origem;
			}
		}

		return self::existe( $nome ) ? self::ORIGEM_IMPLANTADOR : self::ORIGEM_PADRAO;
	}

	/**
	 * Carimbo da última escrita conhecida de uma option.
	 *
	 * @param string $nome Nome da option.
	 * @return int Timestamp UTC, ou 0 quando desconhecido.
	 */
	public static function carimbo( string $nome ): int {
		$registro = get_option( self::OPTION_PROVENIENCIA, array() );

		if ( is_array( $registro ) && isset( $registro[ $nome ] ) && is_array( $registro[ $nome ] ) && isset( $registro[ $nome ]['em'] ) ) {
			return (int) $registro[ $nome ]['em'];
		}

		return 0;
	}

	/**
	 * Rótulo humano de uma procedência.
	 *
	 * @param string $origem Constante de origem.
	 * @return string
	 */
	public static function rotulo_origem( string $origem ): string {
		switch ( $origem ) {
			case self::ORIGEM_IMPLANTADOR:
				return __( 'implantador', 'f3base' );
			case self::ORIGEM_MANUAL:
				return __( 'edição manual', 'f3base' );
			default:
				return __( 'padrão embutido (option ausente)', 'f3base' );
		}
	}

	/**
	 * Escrita física. ÚNICO ponto de `update_option` do plugin.
	 *
	 * @param string $nome     Nome da option.
	 * @param mixed  $valor    Valor já sanitizado.
	 * @param bool   $autoload Carregar automaticamente.
	 * @return void
	 */
	private static function escrever( string $nome, $valor, bool $autoload ): void {
		update_option( $nome, $valor, $autoload );
	}

	/**
	 * Registra a procedência de uma escrita.
	 *
	 * @param string $nome   Nome da option.
	 * @param string $origem Procedência.
	 * @return void
	 */
	private static function registrar_proveniencia( string $nome, string $origem ): void {
		$permitidas = array( self::ORIGEM_IMPLANTADOR, self::ORIGEM_MANUAL, self::ORIGEM_PADRAO );
		if ( ! in_array( $origem, $permitidas, true ) ) {
			$origem = self::ORIGEM_MANUAL;
		}

		$registro = get_option( self::OPTION_PROVENIENCIA, array() );
		if ( ! is_array( $registro ) ) {
			$registro = array();
		}

		$registro[ $nome ] = array(
			'origem' => $origem,
			'em'     => time(),
		);

		self::escrever( self::OPTION_PROVENIENCIA, $registro, true );
	}

	/**
	 * Comparação tolerante a ordem de chaves para a leitura de volta.
	 *
	 * Pública porque a cadência do modo somente-relatório relê as options
	 * gravadas para saber se alguma passou a divergir depois da entrega: fossem
	 * duas implementações de equivalência, a releitura poderia acusar
	 * divergência onde a gravação tinha conferido, e vice-versa.
	 *
	 * @param mixed $a Valor gravado.
	 * @param mixed $b Valor lido.
	 * @return bool
	 */
	public static function equivalente( $a, $b ): bool {
		if ( is_array( $a ) && is_array( $b ) ) {
			return wp_json_encode( self::ordenar( $a ) ) === wp_json_encode( self::ordenar( $b ) );
		}

		return $a === $b;
	}

	/**
	 * Ordena arrays associativos recursivamente para comparação estável.
	 *
	 * @param array<mixed> $valor Array de entrada.
	 * @return array<mixed>
	 */
	private static function ordenar( array $valor ): array {
		ksort( $valor );

		foreach ( $valor as $chave => $item ) {
			if ( is_array( $item ) ) {
				$valor[ $chave ] = self::ordenar( $item );
			}
		}

		return $valor;
	}

	/* ------------------------------------------------------------------ *
	 * Sanitizadores declarados
	 * ------------------------------------------------------------------ */

	/**
	 * Sanitiza `f3base_contato`.
	 *
	 * @param mixed                $valor  Valor bruto.
	 * @param array<string,string> $padrao Padrão declarado.
	 * @return array<string,string>
	 */
	public static function sanitiza_contato( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$e164 = isset( $valor['whatsapp_e164'] ) ? preg_replace( '/[^0-9]/', '', (string) $valor['whatsapp_e164'] ) : '';
		$e164 = is_string( $e164 ) ? substr( $e164, 0, 15 ) : '';

		if ( '' !== $e164 && strlen( $e164 ) < 8 ) {
			$e164 = '';
		}

		return array(
			'whatsapp_e164'   => $e164,
			'email_leads'     => isset( $valor['email_leads'] ) ? sanitize_email( (string) $valor['email_leads'] ) : $padrao['email_leads'],
			'mensagem_padrao' => isset( $valor['mensagem_padrao'] ) ? sanitize_textarea_field( (string) $valor['mensagem_padrao'] ) : $padrao['mensagem_padrao'],
		);
	}

	/**
	 * Sanitiza `f3base_consentimento`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_consentimento( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$politica = isset( $valor['padrao'] ) ? sanitize_key( (string) $valor['padrao'] ) : $padrao['padrao'];
		if ( ! in_array( $politica, array( 'pre-aprovado', 'negado' ), true ) ) {
			$politica = 'pre-aprovado';
		}

		$ttl = isset( $valor['ttl_dias'] ) ? (int) $valor['ttl_dias'] : (int) $padrao['ttl_dias'];
		$ttl = max( 1, min( 3650, $ttl ) );

		return array(
			'padrao'                => $politica,
			'controle_rodape'       => isset( $valor['controle_rodape'] ) ? (bool) $valor['controle_rodape'] : (bool) $padrao['controle_rodape'],
			'aviso_primeira_visita' => isset( $valor['aviso_primeira_visita'] ) ? (bool) $valor['aviso_primeira_visita'] : (bool) $padrao['aviso_primeira_visita'],
			'ttl_dias'              => $ttl,
		);
	}

	/**
	 * Sanitiza `f3base_atribuicao`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_atribuicao( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$modelo = isset( $valor['modelo'] ) ? sanitize_key( (string) $valor['modelo'] ) : (string) $padrao['modelo'];
		if ( ! in_array( $modelo, array( 'first-touch', 'last-touch' ), true ) ) {
			$modelo = 'first-touch';
		}

		$ttl = isset( $valor['ttl_dias'] ) ? (int) $valor['ttl_dias'] : (int) $padrao['ttl_dias'];

		return array(
			'modelo'   => $modelo,
			'ttl_dias' => max( 1, min( 3650, $ttl ) ),
		);
	}

	/**
	 * Sanitiza `f3base_retencao_meses`.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return int
	 */
	public static function sanitiza_retencao_meses( $valor, $padrao ): int {
		$meses = is_scalar( $valor ) ? (int) $valor : (int) $padrao;

		return max( 1, min( 600, $meses ) );
	}

	/**
	 * Sanitiza o Partner ID do LinkedIn.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_partner_id( $valor, $padrao ): string {
		unset( $padrao );

		$id = is_scalar( $valor ) ? preg_replace( '/[^0-9]/', '', (string) $valor ) : '';

		return is_string( $id ) ? substr( $id, 0, 20 ) : '';
	}

	/**
	 * Sanitiza `f3base_tracking`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_tracking( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return array(
			'eventos_ga4' => isset( $valor['eventos_ga4'] ) ? (bool) $valor['eventos_ga4'] : (bool) $padrao['eventos_ga4'],
		);
	}

	/**
	 * Sanitiza `f3base_llms`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_llms( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return array(
			'ligado'               => isset( $valor['ligado'] ) ? (bool) $valor['ligado'] : (bool) $padrao['ligado'],
			'introducao'           => isset( $valor['introducao'] ) ? sanitize_textarea_field( (string) $valor['introducao'] ) : '',
			'politica_privacidade' => isset( $valor['politica_privacidade'] ) ? self::sanitiza_item_llms( $valor['politica_privacidade'] ) : array(),
			'livres'               => isset( $valor['livres'] ) && is_array( $valor['livres'] )
				? array_values(
					array_filter(
						array_map( array( __CLASS__, 'sanitiza_item_llms' ), $valor['livres'] ),
						static fn ( array $item ): bool => '' !== $item['url']
					)
				)
				: array(),
		);
	}

	/**
	 * Sanitiza um item de listagem do llms.txt.
	 *
	 * @param mixed $item Item bruto.
	 * @return array{titulo:string,url:string,descricao:string}
	 */
	public static function sanitiza_item_llms( $item ): array {
		$item = is_array( $item ) ? $item : array();

		return array(
			'titulo'    => isset( $item['titulo'] ) ? sanitize_text_field( (string) $item['titulo'] ) : '',
			'url'       => isset( $item['url'] ) ? esc_url_raw( (string) $item['url'] ) : '',
			'descricao' => isset( $item['descricao'] ) ? sanitize_text_field( (string) $item['descricao'] ) : '',
		);
	}

	/**
	 * Sanitiza `f3base_redirects`.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	public static function sanitiza_redirects( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $regra ) {
			if ( ! is_array( $regra ) ) {
				continue;
			}

			$de   = isset( $regra['de'] ) ? self::sanitiza_caminho( (string) $regra['de'] ) : '';
			$para = isset( $regra['para'] ) ? self::sanitiza_caminho( (string) $regra['para'] ) : '';

			if ( '' === $de || '' === $para || $de === $para ) {
				continue;
			}

			$status = isset( $regra['status'] ) ? (int) $regra['status'] : 301;
			if ( ! in_array( $status, array( 301, 302, 307, 308, 410 ), true ) ) {
				$status = 301;
			}

			$saida[] = array(
				'de'     => $de,
				'para'   => $para,
				'status' => $status,
			);
		}

		return $saida;
	}

	/**
	 * Normaliza um caminho relativo do próprio site.
	 *
	 * @param string $caminho Caminho bruto.
	 * @return string Caminho começando por barra, ou vazio quando inválido.
	 */
	public static function sanitiza_caminho( string $caminho ): string {
		$caminho = trim( $caminho );
		if ( '' === $caminho ) {
			return '';
		}

		if ( str_contains( $caminho, '://' ) || str_starts_with( $caminho, '//' ) ) {
			return '';
		}

		if ( str_contains( $caminho, '..' ) ) {
			return '';
		}

		$partes = wp_parse_url( $caminho );
		if ( ! is_array( $partes ) || isset( $partes['host'] ) ) {
			return '';
		}

		$limpo = isset( $partes['path'] ) ? (string) $partes['path'] : '';
		if ( '' === $limpo ) {
			return '';
		}

		$limpo = '/' . ltrim( sanitize_text_field( rawurldecode( $limpo ) ), '/' );

		if ( isset( $partes['query'] ) && '' !== $partes['query'] ) {
			$limpo .= '?' . sanitize_text_field( (string) $partes['query'] );
		}

		return substr( $limpo, 0, 500 );
	}

	/**
	 * Sanitiza `f3base_seo_entidade`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_seo_entidade( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$texto_lista = static function ( $lista ): array {
			if ( ! is_array( $lista ) ) {
				return array();
			}

			return array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $lista ) ), static fn ( string $item ): bool => '' !== $item ) );
		};

		$urls = array();
		if ( isset( $valor['same_as'] ) && is_array( $valor['same_as'] ) ) {
			foreach ( $valor['same_as'] as $url ) {
				$limpa = esc_url_raw( (string) $url );
				if ( '' !== $limpa ) {
					$urls[] = $limpa;
				}
			}
		}

		$contato = array();
		if ( isset( $valor['ponto_de_contato'] ) && is_array( $valor['ponto_de_contato'] ) ) {
			foreach ( $valor['ponto_de_contato'] as $ponto ) {
				if ( ! is_array( $ponto ) ) {
					continue;
				}
				$contato[] = array(
					'tipo'     => isset( $ponto['tipo'] ) ? sanitize_text_field( (string) $ponto['tipo'] ) : 'customer support',
					'telefone' => isset( $ponto['telefone'] ) ? sanitize_text_field( (string) $ponto['telefone'] ) : '',
					'email'    => isset( $ponto['email'] ) ? sanitize_email( (string) $ponto['email'] ) : '',
					'idiomas'  => isset( $ponto['idiomas'] ) ? $texto_lista( $ponto['idiomas'] ) : array(),
				);
			}
		}

		$servicos = array();
		if ( isset( $valor['servicos'] ) && is_array( $valor['servicos'] ) ) {
			foreach ( $valor['servicos'] as $servico ) {
				if ( ! is_array( $servico ) ) {
					continue;
				}
				$nome = isset( $servico['nome'] ) ? sanitize_text_field( (string) $servico['nome'] ) : '';
				if ( '' === $nome ) {
					continue;
				}
				$servicos[] = array(
					'nome'         => $nome,
					'descricao'    => isset( $servico['descricao'] ) ? sanitize_text_field( (string) $servico['descricao'] ) : '',
					'url'          => isset( $servico['url'] ) ? esc_url_raw( (string) $servico['url'] ) : '',
					'tipo_servico' => isset( $servico['tipo_servico'] ) ? sanitize_text_field( (string) $servico['tipo_servico'] ) : '',
					'area_servida' => isset( $servico['area_servida'] ) ? $texto_lista( $servico['area_servida'] ) : array(),
				);
			}
		}

		return array(
			'nome'             => isset( $valor['nome'] ) ? sanitize_text_field( (string) $valor['nome'] ) : (string) $padrao['nome'],
			'same_as'          => $urls,
			'area_servida'     => isset( $valor['area_servida'] ) ? $texto_lista( $valor['area_servida'] ) : array(),
			'conhece_sobre'    => isset( $valor['conhece_sobre'] ) ? $texto_lista( $valor['conhece_sobre'] ) : array(),
			'ponto_de_contato' => $contato,
			'organizacao_mae'  => isset( $valor['organizacao_mae'] ) ? sanitize_text_field( (string) $valor['organizacao_mae'] ) : '',
			'servicos'         => $servicos,
			'faq_schema'       => isset( $valor['faq_schema'] ) ? (bool) $valor['faq_schema'] : (bool) $padrao['faq_schema'],
		);
	}

	/**
	 * Sanitiza `f3base_cabecalhos`.
	 *
	 * COOP é travado em `same-origin-allow-popups`: `same-origin` corta a janela
	 * aberta pelo fluxo de leads do WhatsApp, e o contrato cobra o valor.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_cabecalhos( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$frame = isset( $valor['x_frame_options'] ) ? strtoupper( sanitize_text_field( (string) $valor['x_frame_options'] ) ) : (string) $padrao['x_frame_options'];
		if ( ! in_array( $frame, array( 'SAMEORIGIN', 'DENY', '' ), true ) ) {
			$frame = 'SAMEORIGIN';
		}

		$referrer  = isset( $valor['referrer_policy'] ) ? sanitize_text_field( (string) $valor['referrer_policy'] ) : (string) $padrao['referrer_policy'];
		$aceitos   = array(
			'no-referrer',
			'no-referrer-when-downgrade',
			'origin',
			'origin-when-cross-origin',
			'same-origin',
			'strict-origin',
			'strict-origin-when-cross-origin',
			'unsafe-url',
			'',
		);
		$referrer  = in_array( $referrer, $aceitos, true ) ? $referrer : (string) $padrao['referrer_policy'];
		$max_age   = isset( $valor['hsts_max_age'] ) ? (int) $valor['hsts_max_age'] : (int) $padrao['hsts_max_age'];
		$max_age   = max( 0, min( 63072000, $max_age ) );
		$permissoes = isset( $valor['permissions_policy'] ) ? sanitize_text_field( (string) $valor['permissions_policy'] ) : (string) $padrao['permissions_policy'];

		return array(
			'x_content_type_options' => isset( $valor['x_content_type_options'] ) ? (bool) $valor['x_content_type_options'] : (bool) $padrao['x_content_type_options'],
			'x_frame_options'        => $frame,
			'csp_frame_ancestors'    => isset( $valor['csp_frame_ancestors'] ) ? sanitize_text_field( (string) $valor['csp_frame_ancestors'] ) : (string) $padrao['csp_frame_ancestors'],
			'referrer_policy'        => $referrer,
			'coop'                   => 'same-origin-allow-popups',
			'permissions_policy'     => $permissoes,
			'hsts'                   => isset( $valor['hsts'] ) ? (bool) $valor['hsts'] : (bool) $padrao['hsts'],
			'hsts_max_age'           => $max_age,
		);
	}

	/**
	 * Sanitiza `f3base_copy_contrato`.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_copy_contrato( $valor, array $padrao ): array {
		unset( $padrao );

		$valor = is_array( $valor ) ? $valor : array();

		$grupo = static function ( $lista ): array {
			if ( ! is_array( $lista ) ) {
				return array();
			}

			$saida = array();
			foreach ( $lista as $item ) {
				if ( ! is_array( $item ) ) {
					continue;
				}
				$id = isset( $item['id'] ) ? sanitize_key( (string) $item['id'] ) : '';
				if ( '' === $id ) {
					continue;
				}
				$grafias = array();
				if ( isset( $item['grafias'] ) && is_array( $item['grafias'] ) ) {
					foreach ( $item['grafias'] as $grafia ) {
						$limpa = sanitize_text_field( (string) $grafia );
						if ( '' !== $limpa ) {
							$grafias[] = $limpa;
						}
					}
				}
				$saida[] = array(
					'id'      => $id,
					'grafias' => $grafias,
					'onde'    => isset( $item['onde'] ) && is_array( $item['onde'] ) ? array_map( 'sanitize_key', array_map( 'strval', $item['onde'] ) ) : array(),
					'motivo'  => isset( $item['motivo'] ) ? sanitize_text_field( (string) $item['motivo'] ) : '',
				);
			}

			return $saida;
		};

		return array(
			'devem_aparecer'   => $grupo( $valor['devem_aparecer'] ?? array() ),
			'nao_podem_voltar' => $grupo( $valor['nao_podem_voltar'] ?? array() ),
		);
	}

	/**
	 * Sanitiza um ID de post.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return int
	 */
	public static function sanitiza_id_post( $valor, $padrao ): int {
		unset( $padrao );

		return is_scalar( $valor ) ? max( 0, (int) $valor ) : 0;
	}

	/**
	 * Sanitiza uma lista genérica gravada por outro artefato do pacote.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<mixed>
	 */
	public static function sanitiza_lista_generica( $valor, array $padrao ): array {
		unset( $padrao );

		return is_array( $valor ) ? $valor : array();
	}

	/**
	 * Sanitiza `f3base_atividade`.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<string,array<string,mixed>>
	 */
	public static function sanitiza_atividade( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $chave => $dados ) {
			$chave_limpa = sanitize_key( (string) $chave );
			if ( '' === $chave_limpa || ! is_array( $dados ) ) {
				continue;
			}

			$entrada = array();
			foreach ( $dados as $campo => $conteudo ) {
				$campo_limpo = sanitize_key( (string) $campo );
				if ( '' === $campo_limpo ) {
					continue;
				}
				if ( is_int( $conteudo ) || is_float( $conteudo ) ) {
					$entrada[ $campo_limpo ] = $conteudo + 0;
				} elseif ( is_bool( $conteudo ) ) {
					$entrada[ $campo_limpo ] = $conteudo;
				} else {
					$entrada[ $campo_limpo ] = sanitize_text_field( (string) $conteudo );
				}
			}

			$saida[ $chave_limpa ] = $entrada;
		}

		return $saida;
	}

	/**
	 * Sanitiza `f3base_origem_confiavel`.
	 *
	 * O nome do cabeçalho é reduzido ao alfabeto de um nome de cabeçalho HTTP e
	 * os saltos ficam entre 1 e 10: cabeçalho não é caminho nem expressão, e
	 * salto zero significaria ler a ponta que o próprio cliente escreveu.
	 *
	 * @param mixed        $valor  Valor bruto.
	 * @param array<mixed> $padrao Padrão declarado.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_origem_confiavel( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$cabecalho = isset( $valor['cabecalho'] ) ? trim( sanitize_text_field( (string) $valor['cabecalho'] ) ) : (string) $padrao['cabecalho'];
		$cabecalho = preg_replace( '/[^A-Za-z0-9_-]/', '', $cabecalho );
		$cabecalho = is_string( $cabecalho ) ? $cabecalho : '';

		$saltos = isset( $valor['saltos'] ) ? (int) $valor['saltos'] : (int) $padrao['saltos'];

		return array(
			'cabecalho' => $cabecalho,
			'saltos'    => max( 1, min( 10, $saltos ) ),
		);
	}

	/**
	 * Sanitiza a cadência declarada.
	 *
	 * @param mixed                $valor  Valor bruto.
	 * @param array<string,mixed>  $padrao Padrão embutido.
	 * @return array<string,mixed>
	 */
	public static function sanitiza_cadencia( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		$periodicidade = isset( $valor['periodicidade'] ) ? sanitize_key( (string) $valor['periodicidade'] ) : (string) $padrao['periodicidade'];

		if ( ! in_array( $periodicidade, array( 'nenhuma', 'semanal', 'quinzenal', 'mensal' ), true ) ) {
			$periodicidade = (string) $padrao['periodicidade'];
		}

		return array(
			'periodicidade'  => $periodicidade,
			'apos_n_ajustes' => max( 0, isset( $valor['apos_n_ajustes'] ) ? (int) $valor['apos_n_ajustes'] : (int) $padrao['apos_n_ajustes'] ),
			'mecanismo'      => isset( $valor['mecanismo'] ) ? sanitize_text_field( (string) $valor['mecanismo'] ) : (string) $padrao['mecanismo'],
			'hook'           => isset( $valor['hook'] ) ? sanitize_key( (string) $valor['hook'] ) : (string) $padrao['hook'],
		);
	}

	/**
	 * Sanitiza o estado de execução da cadência.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<string,int>
	 */
	public static function sanitiza_cadencia_estado( $valor, array $padrao ): array {
		$valor = is_array( $valor ) ? $valor : array();

		return array(
			'ajustes'  => max( 0, isset( $valor['ajustes'] ) ? (int) $valor['ajustes'] : (int) $padrao['ajustes'] ),
			'previsto' => max( 0, isset( $valor['previsto'] ) ? (int) $valor['previsto'] : (int) $padrao['previsto'] ),
		);
	}

	/**
	 * Sanitiza `f3base_journal_eliminacao`.
	 *
	 * O journal guarda identificador, contagem, carimbo, operador e regime.
	 * Nenhum campo de conteúdo é aceito: campo desconhecido é descartado.
	 *
	 * @param mixed               $valor  Valor bruto.
	 * @param array<string,mixed> $padrao Padrão embutido.
	 * @return array<int,array<string,mixed>>
	 */
	public static function sanitiza_journal( $valor, array $padrao ): array {
		unset( $padrao );

		if ( ! is_array( $valor ) ) {
			return array();
		}

		$saida = array();

		foreach ( $valor as $entrada ) {
			if ( ! is_array( $entrada ) ) {
				continue;
			}

			$regime = isset( $entrada['regime'] ) ? sanitize_key( (string) $entrada['regime'] ) : '';
			if ( ! in_array( $regime, array( 'operacional', 'titular' ), true ) ) {
				continue;
			}

			$saida[] = array(
				'regime'          => $regime,
				'identificador'   => isset( $entrada['identificador'] ) ? sanitize_text_field( (string) $entrada['identificador'] ) : '',
				'identificador_hash' => isset( $entrada['identificador_hash'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $entrada['identificador_hash'] ) ) : '',
				'contagem'        => isset( $entrada['contagem'] ) ? max( 0, (int) $entrada['contagem'] ) : 0,
				'em'              => isset( $entrada['em'] ) ? max( 0, (int) $entrada['em'] ) : 0,
				'operador'        => isset( $entrada['operador'] ) ? sanitize_text_field( (string) $entrada['operador'] ) : '',
				'reversivel_ate'  => isset( $entrada['reversivel_ate'] ) ? max( 0, (int) $entrada['reversivel_ate'] ) : 0,
			);
		}

		$limite = (int) apply_filters( 'f3base_journal_limite_entradas', 500 );
		$limite = max( 10, $limite );

		if ( count( $saida ) > $limite ) {
			$saida = array_slice( $saida, count( $saida ) - $limite );
		}

		return array_values( $saida );
	}

	/**
	 * Sanitiza um segredo hexadecimal.
	 *
	 * @param mixed $valor  Valor bruto.
	 * @param mixed $padrao Padrão declarado.
	 * @return string
	 */
	public static function sanitiza_segredo( $valor, $padrao ): string {
		unset( $padrao );

		if ( ! is_scalar( $valor ) ) {
			return '';
		}

		$limpo = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $valor ) );

		return is_string( $limpo ) ? substr( $limpo, 0, 128 ) : '';
	}
}
