<?php
/**
 * Módulo cadencia-relatorio: o OUVINTE do evento da cadência.
 *
 * O implantador agenda `f3base_cadencia_relatorio` e se autodesativa. Até a
 * 1.0.17 o nome do hook aparecia UMA vez no pacote inteiro — na variável que o
 * agendava — e nenhum `add_action` o escutava: o evento disparava, o WP-Cron o
 * reagendava, e nada acontecia. O ouvinte mora aqui, no componente persistente,
 * porque é o único que sobrevive à autodesativação de quem agendou.
 *
 * Três coisas que este módulo faz e que o agendamento sozinho não fazia:
 *
 * 1. **Registra as recorrências que o núcleo não tem.** `monthly` não existe no
 *    WordPress e `quinzenal` também não: agendar "mensal" caía em `daily` e
 *    "quinzenal" caía em `weekly` — o dobro da frequência —, as duas em
 *    silêncio. Aqui elas existem, com o intervalo declarado, e a aproximação de
 *    mês por 30 dias é dita em voz alta, porque o WP-Cron conta intervalo e não
 *    calendário.
 * 2. **Executa o modo somente-relatório e registra o que mediu**: última
 *    execução, próxima, duração, resultado, erro e atraso do evento.
 * 3. **Conta ajustes de verdade.** `cadencia_relatorio.apos_n_ajustes` era
 *    gravado numa option que ninguém lia, e o relatório imprimia "gatilho
 *    alternativo: após N ajustes" sobre um contador inexistente. O contador é
 *    este, ele conta escrita em option gerenciada, e ao alcançar o alvo ele
 *    DISPARA.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cadência do modo somente-relatório: agendamento, execução e contador.
 */
final class F3Base_Modulo_Cadencia_Relatorio extends F3Base_Modulo {

	/**
	 * Evento agendado pelo implantador e escutado por este módulo.
	 */
	public const HOOK = 'f3base_cadencia_relatorio';

	/**
	 * Recorrências que o núcleo do WordPress não tem.
	 */
	public const RECORRENCIA_QUINZENAL = 'f3base_quinzenal';
	public const RECORRENCIA_MENSAL    = 'f3base_mensal';

	/**
	 * Resultados fechados de uma execução.
	 */
	public const RESULTADO_OK   = 'ok';
	public const RESULTADO_ERRO = 'erro';

	/**
	 * Gatilhos fechados de uma execução.
	 */
	public const GATILHO_CRON     = 'wp-cron';
	public const GATILHO_ATRASO   = 'carregamento-atrasado';
	public const GATILHO_AJUSTES  = 'apos-n-ajustes';

	/**
	 * Guarda de reentrância do contador de ajustes.
	 *
	 * A execução da cadência grava options (atividade e estado), e sem esta
	 * guarda cada gravação contaria como ajuste e chamaria a execução de novo.
	 *
	 * @var bool
	 */
	private static bool $contando = false;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'cadencia-relatorio';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Cadência do modo somente-relatório', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Escuta o evento f3base_cadencia_relatorio que o implantador agenda, registra as recorrências quinzenal e mensal que o núcleo do WordPress não tem, executa a releitura das options gerenciadas e dos módulos, e registra última execução, próxima, duração, resultado, erro e atraso. Conta também os ajustes em option gerenciada e dispara a execução ao alcançar o número declarado.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'filter',
				'hook'       => 'cron_schedules',
				'metodo'     => 'registrar_recorrencias',
				'prioridade' => 10,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_agendamento',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => self::HOOK,
				'metodo'     => 'executar_por_cron',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'updated_option',
				'metodo'     => 'contar_ajuste',
				'prioridade' => 10,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'added_option',
				'metodo'     => 'contar_ajuste',
				'prioridade' => 10,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'deleted_option',
				'metodo'     => 'contar_ajuste',
				'prioridade' => 10,
				'args'       => 1,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_cadencia', 'f3base_cadencia_estado' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$declarada = self::recorrencia_declarada();
		$agendas   = wp_get_schedules();
		$agendado  = wp_next_scheduled( self::HOOK );
		$cron_off  = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;

		return array(
			array(
				'rotulo'   => __( 'Evento agendado', 'f3base' ),
				'presente' => false !== $agendado,
				'detalhe'  => false !== $agendado
					? sprintf(
						/* translators: %s: data e hora previstas. */
						__( 'próxima execução prevista para %s.', 'f3base' ),
						(string) wp_date( 'd/m/Y H:i', (int) $agendado )
					)
					: __( 'evento não agendado: o carregamento seguinte reagenda pela periodicidade declarada em f3base_cadencia.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Recorrência declarada disponível', 'f3base' ),
				'presente' => '' === $declarada || isset( $agendas[ $declarada ] ),
				'detalhe'  => '' === $declarada
					? __( 'periodicidade declarada como nenhuma: não há recorrência a exigir.', 'f3base' )
					: sprintf(
						/* translators: 1: nome da recorrência, 2: intervalo em dias. */
						__( 'recorrência %1$s registrada por este módulo, com intervalo de %2$d dia(s). O núcleo não traz monthly nem quinzenal: agendar sem quem as registre cai em daily e em weekly, em silêncio.', 'f3base' ),
						$declarada,
						(int) round( (int) ( $agendas[ $declarada ]['interval'] ?? 0 ) / DAY_IN_SECONDS )
					),
			),
			array(
				'rotulo'   => __( 'WP-Cron habilitado', 'f3base' ),
				'presente' => ! $cron_off,
				'detalhe'  => $cron_off
					? __( 'DISABLE_WP_CRON ligado: a cadência depende de cron real do sistema, conforme o README.', 'f3base' )
					: __( 'WP-Cron não garante horário; o atraso é medido e registrado a cada execução.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_CADENCIA, __( 'Última execução da cadência', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$declarada = self::recorrencia_declarada();
		$alvo      = self::apos_n_ajustes();

		if ( '' === $declarada && $alvo < 1 ) {
			return $this->inativo(
				__( 'a configuração declara periodicidade "nenhuma" e nenhum gatilho por ajustes: não há evento a escutar nem contador a manter, e o módulo não registra hook nenhum.', 'f3base' )
			);
		}

		$carimbo = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );

		if ( self::RESULTADO_ERRO === (string) ( $carimbo['resultado'] ?? '' ) ) {
			return $this->degradado(
				sprintf(
					/* translators: %s: erro registrado na última execução. */
					__( 'a última execução terminou em erro e o relatório não saiu: %s.', 'f3base' ),
					(string) ( $carimbo['erro'] ?? __( 'erro não registrado', 'f3base' ) )
				)
			);
		}

		if ( '' !== $declarada ) {
			$agendado = wp_next_scheduled( self::HOOK );

			if ( false === $agendado ) {
				return $this->degradado(
					__( 'evento sem agendamento: a releitura das options só volta a acontecer quando o carregamento seguinte reagendar a rotina.', 'f3base' )
				);
			}

			$observada = self::recorrencia_agendada();

			if ( '' !== $observada && $observada !== $declarada ) {
				return $this->degradado(
					sprintf(
						/* translators: 1: recorrência observada no agendamento, 2: recorrência declarada. */
						__( 'o evento está agendado com a recorrência %1$s e a configuração declara %2$s: quem agendou não conhecia a recorrência declarada e degradou para a mais próxima. Reexecute a etapa de cadência do implantador com este plugin já ativo.', 'f3base' ),
						$observada,
						$declarada
					)
				);
			}

			$atraso = isset( $carimbo['atraso_segundos'] ) ? (int) $carimbo['atraso_segundos'] : 0;
			$limite = self::atraso_tolerado();

			if ( $atraso > $limite ) {
				return $this->degradado(
					sprintf(
						/* translators: 1: atraso medido, 2: tolerância declarada. */
						__( 'a última execução saiu com %1$s de atraso sobre o horário previsto, acima da tolerância de %2$s.', 'f3base' ),
						human_time_diff( 0, $atraso ),
						human_time_diff( 0, $limite )
					)
				);
			}

			return $this->ativo(
				sprintf(
					/* translators: 1: recorrência declarada, 2: data e hora previstas, 3: gatilho por ajustes. */
					__( 'escutando %1$s com recorrência %2$s; próxima execução prevista para %3$s.', 'f3base' ),
					self::HOOK,
					$declarada,
					(string) wp_date( 'd/m/Y H:i', (int) $agendado )
				) . ' ' . self::frase_do_contador()
			);
		}

		return $this->ativo(
			__( 'periodicidade declarada como nenhuma: não há evento periódico.', 'f3base' ) . ' ' . self::frase_do_contador()
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		$this->garantir_agendamento();
	}

	/**
	 * {@inheritDoc}
	 */
	public function desinstalar(): void {
		$timestamp = wp_next_scheduled( self::HOOK );

		while ( false !== $timestamp ) {
			wp_unschedule_event( (int) $timestamp, self::HOOK );
			$timestamp = wp_next_scheduled( self::HOOK );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Recorrências que o núcleo não tem
	 * ------------------------------------------------------------------ */

	/**
	 * Acrescenta as recorrências quinzenal e mensal.
	 *
	 * O WP-Cron conta INTERVALO, não calendário: "mensal" aqui é trinta dias, e
	 * a aproximação sai escrita no nome legível em vez de virar surpresa em
	 * fevereiro.
	 *
	 * @param mixed $agendas Recorrências registradas.
	 * @return array<string,array{interval:int,display:string}>
	 */
	public function registrar_recorrencias( $agendas ): array {
		$agendas = is_array( $agendas ) ? $agendas : array();

		$agendas[ self::RECORRENCIA_QUINZENAL ] = array(
			'interval' => 15 * DAY_IN_SECONDS,
			'display'  => __( 'A cada quinze dias (F3 Base)', 'f3base' ),
		);

		$agendas[ self::RECORRENCIA_MENSAL ] = array(
			'interval' => 30 * DAY_IN_SECONDS,
			'display'  => __( 'A cada trinta dias (F3 Base, o "mensal" do WP-Cron)', 'f3base' ),
		);

		return $agendas;
	}

	/**
	 * Recorrência que a periodicidade declarada exige.
	 *
	 * @return string Vazio quando a periodicidade declarada é "nenhuma".
	 */
	public static function recorrencia_declarada(): string {
		$mapa = array(
			'semanal'   => 'weekly',
			'quinzenal' => self::RECORRENCIA_QUINZENAL,
			'mensal'    => self::RECORRENCIA_MENSAL,
		);

		$periodicidade = (string) ( self::cadencia()['periodicidade'] ?? 'nenhuma' );

		return $mapa[ $periodicidade ] ?? '';
	}

	/**
	 * Recorrência com que o evento está de fato agendado.
	 *
	 * @return string Vazio quando não há evento agendado.
	 */
	public static function recorrencia_agendada(): string {
		if ( ! function_exists( 'wp_get_scheduled_event' ) ) {
			return '';
		}

		$evento = wp_get_scheduled_event( self::HOOK );

		if ( ! is_object( $evento ) || ! isset( $evento->schedule ) ) {
			return '';
		}

		return (string) $evento->schedule;
	}

	/* ------------------------------------------------------------------ *
	 * Agendamento e recuperação
	 * ------------------------------------------------------------------ */

	/**
	 * Garante o agendamento e recupera a execução perdida.
	 *
	 * @return void
	 */
	public function garantir_agendamento(): void {
		$declarada = self::recorrencia_declarada();

		if ( '' === $declarada ) {
			return;
		}

		if ( false === wp_next_scheduled( self::HOOK ) ) {
			$quando = time() + HOUR_IN_SECONDS;

			wp_schedule_event( $quando, $declarada, self::HOOK );
			self::guardar_previsao( $quando );
		}

		$previsto = self::previsto();

		if ( $previsto <= 0 ) {
			return;
		}

		if ( time() <= $previsto + self::tolerancia_de_recuperacao() ) {
			return;
		}

		if ( false === set_transient( 'f3base_cadencia_recuperando', 1, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		$this->executar( self::GATILHO_ATRASO );
	}

	/**
	 * Callback do evento agendado.
	 *
	 * @return void
	 */
	public function executar_por_cron(): void {
		$this->executar( self::GATILHO_CRON );
	}

	/**
	 * Executa o modo somente-relatório e registra o que mediu.
	 *
	 * @param string $gatilho Quem disparou esta execução.
	 * @return void
	 */
	public function executar( string $gatilho = self::GATILHO_CRON ): void {
		$previsto = self::previsto();
		$atraso   = $previsto > 0 ? max( 0, time() - $previsto ) : 0;
		$comeco   = microtime( true );

		$resultado = self::RESULTADO_OK;
		$erro      = '';
		$medicao   = array(
			'modulos' => '',
			'options' => '',
		);

		try {
			$medicao = self::medir();
		} catch ( Throwable $falha ) {
			$resultado = self::RESULTADO_ERRO;
			$erro      = get_class( $falha ) . ': ' . $falha->getMessage();
		}

		$duracao = (int) round( ( microtime( true ) - $comeco ) * 1000 );
		$proxima = wp_next_scheduled( self::HOOK );

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_CADENCIA,
			array(
				'gatilho'         => $gatilho,
				'resultado'       => $resultado,
				'erro'            => $erro,
				'duracao_ms'      => $duracao,
				'atraso_segundos' => $atraso,
				'proxima'         => false !== $proxima
					? (string) wp_date( 'd/m/Y H:i', (int) $proxima )
					: __( 'sem agendamento', 'f3base' ),
				'modulos'         => $medicao['modulos'],
				'options'         => $medicao['options'],
			)
		);

		self::guardar_previsao( false !== $proxima ? (int) $proxima : 0 );
		self::guardar_ajustes( 0 );

		delete_transient( 'f3base_cadencia_recuperando' );
	}

	/**
	 * A medição do modo somente-relatório, em texto.
	 *
	 * Só número MEDIDO entra: o estado de cada módulo sai do registro único, e a
	 * releitura das options gerenciadas compara o que está gravado com o que a
	 * sanitização devolve — a mesma equivalência que o gravador usa. Contagem
	 * sai sempre acompanhada dos NOMES, porque a pergunta do operador é "quais?".
	 *
	 * @return array{modulos:string,options:string}
	 */
	public static function medir(): array {
		$relatorio = F3Base_Registro::relatorio();
		$linhas    = isset( $relatorio['modulos'] ) && is_array( $relatorio['modulos'] ) ? $relatorio['modulos'] : array();

		$por_estado = array();

		foreach ( $linhas as $linha ) {
			$estado = isset( $linha['estado'] ) ? (string) $linha['estado'] : F3Base_Modulo::INATIVO;
			$id     = isset( $linha['id'] ) ? (string) $linha['id'] : '';

			$por_estado[ $estado ][] = $id;
		}

		$partes = array();

		foreach ( $por_estado as $estado => $ids ) {
			sort( $ids );

			$partes[] = sprintf(
				/* translators: 1: estado do módulo, 2: quantos módulos, 3: ids dos módulos. */
				__( '%1$s (%2$d): %3$s', 'f3base' ),
				$estado,
				count( $ids ),
				implode( ' ', $ids )
			);
		}

		$conferidas   = 0;
		$divergentes  = array();
		$nao_gravadas = array();

		foreach ( F3Base_Options::nomes() as $nome ) {
			if ( ! F3Base_Options::existe( $nome ) ) {
				$nao_gravadas[] = $nome;
				continue;
			}

			++$conferidas;

			if ( ! F3Base_Options::equivalente( get_option( $nome ), F3Base_Options::ler( $nome ) ) ) {
				$divergentes[] = $nome;
			}
		}

		return array(
			'modulos' => array() === $partes ? __( 'nenhum módulo no registro', 'f3base' ) : implode( ' | ', $partes ),
			'options' => sprintf(
				/* translators: 1: quantas options foram relidas, 2: as que divergiram, 3: as que nunca foram gravadas. */
				__( '%1$d relida(s); divergentes: %2$s; nunca gravadas: %3$s', 'f3base' ),
				$conferidas,
				array() === $divergentes ? __( 'nenhuma', 'f3base' ) : implode( ' ', $divergentes ),
				array() === $nao_gravadas ? __( 'nenhuma', 'f3base' ) : implode( ' ', $nao_gravadas )
			),
		);
	}

	/* ------------------------------------------------------------------ *
	 * Contador de ajustes
	 * ------------------------------------------------------------------ */

	/**
	 * Conta uma escrita em option gerenciada e dispara ao alcançar o alvo.
	 *
	 * @param string $option Nome da option escrita.
	 * @return void
	 */
	public function contar_ajuste( $option = '' ): void {
		$nome = is_string( $option ) ? $option : '';

		if ( self::$contando ) {
			return;
		}

		if ( ! in_array( $nome, self::options_que_contam(), true ) ) {
			return;
		}

		$alvo = self::apos_n_ajustes();

		if ( $alvo < 1 ) {
			return;
		}

		self::$contando = true;

		try {
			$ajustes = self::ajustes() + 1;

			if ( $ajustes < $alvo ) {
				self::guardar_ajustes( $ajustes );

				return;
			}

			$this->executar( self::GATILHO_AJUSTES );
		} finally {
			self::$contando = false;
		}
	}

	/**
	 * Options cuja escrita é um AJUSTE — e as que são estado de execução.
	 *
	 * Carimbo de atividade, estado da cadência, procedência e journal mudam
	 * porque o site rodou, não porque alguém ajustou alguma coisa: contá-los
	 * faria o gatilho disparar sozinho, e o disparo gravaria de novo.
	 *
	 * @return string[]
	 */
	public static function options_que_contam(): array {
		$estado_de_execucao = array(
			F3Base_Atividade::OPTION,
			'f3base_cadencia_estado',
			'f3base_journal_eliminacao',
			F3Base_Options::OPTION_PROVENIENCIA,
		);

		return array_values( array_diff( F3Base_Options::nomes(), $estado_de_execucao ) );
	}

	/**
	 * Frase do contador, com os números que ele de fato tem.
	 *
	 * @return string
	 */
	private static function frase_do_contador(): string {
		$alvo = self::apos_n_ajustes();

		if ( $alvo < 1 ) {
			return __( 'O gatilho por número de ajustes está declarado como zero: nenhum contador é mantido, e nada promete disparar por ele.', 'f3base' );
		}

		return sprintf(
			/* translators: 1: ajustes contados desde a última execução, 2: alvo declarado. */
			__( 'Gatilho alternativo por ajustes: %1$d de %2$d escritas em option gerenciada desde a última execução, o que vier antes.', 'f3base' ),
			self::ajustes(),
			$alvo
		);
	}

	/* ------------------------------------------------------------------ *
	 * Leitura da declaração e do estado
	 * ------------------------------------------------------------------ */

	/**
	 * A cadência declarada, lida da option que o implantador grava.
	 *
	 * @return array<string,mixed>
	 */
	public static function cadencia(): array {
		$valor = F3Base_Options::ler( 'f3base_cadencia' );

		return is_array( $valor ) ? $valor : array();
	}

	/**
	 * Número de ajustes declarado como gatilho alternativo.
	 *
	 * @return int
	 */
	public static function apos_n_ajustes(): int {
		return max( 0, (int) ( self::cadencia()['apos_n_ajustes'] ?? 0 ) );
	}

	/**
	 * Estado de execução da cadência.
	 *
	 * @return array<string,int>
	 */
	private static function estado_da_cadencia(): array {
		$valor = F3Base_Options::ler( 'f3base_cadencia_estado' );

		return is_array( $valor ) ? $valor : array();
	}

	/**
	 * Ajustes contados desde a última execução.
	 *
	 * @return int
	 */
	public static function ajustes(): int {
		return max( 0, (int) ( self::estado_da_cadencia()['ajustes'] ?? 0 ) );
	}

	/**
	 * Timestamp previsto da próxima execução.
	 *
	 * @return int
	 */
	public static function previsto(): int {
		return max( 0, (int) ( self::estado_da_cadencia()['previsto'] ?? 0 ) );
	}

	/**
	 * Guarda a previsão da próxima execução, para medir o atraso seguinte.
	 *
	 * @param int $quando Timestamp previsto.
	 * @return void
	 */
	private static function guardar_previsao( int $quando ): void {
		$estado             = self::estado_da_cadencia();
		$estado['previsto'] = max( 0, $quando );

		F3Base_Options::gravar( 'f3base_cadencia_estado', $estado, F3Base_Options::ORIGEM_MANUAL );
	}

	/**
	 * Guarda o contador de ajustes.
	 *
	 * @param int $quantos Contagem a gravar.
	 * @return void
	 */
	private static function guardar_ajustes( int $quantos ): void {
		$estado            = self::estado_da_cadencia();
		$estado['ajustes'] = max( 0, $quantos );

		F3Base_Options::gravar( 'f3base_cadencia_estado', $estado, F3Base_Options::ORIGEM_MANUAL );
	}

	/**
	 * Atraso tolerado antes de o módulo se declarar degradado.
	 *
	 * @return int
	 */
	public static function atraso_tolerado(): int {
		$limite = (int) apply_filters( 'f3base_cadencia_atraso_tolerado', 2 * DAY_IN_SECONDS );

		return max( HOUR_IN_SECONDS, $limite );
	}

	/**
	 * Folga antes de o carregamento recuperar uma execução perdida.
	 *
	 * @return int
	 */
	public static function tolerancia_de_recuperacao(): int {
		$folga = (int) apply_filters( 'f3base_cadencia_tolerancia_recuperacao', 12 * HOUR_IN_SECONDS );

		return max( MINUTE_IN_SECONDS, $folga );
	}
}
