<?php
/**
 * Desinstalação do F3 Base Site Core.
 *
 * O que sai: estado de execução do próprio plugin, o segredo do endpoint, os
 * agendamentos, os transientes e a tabela de chaves do endpoint — estrutura que
 * só o plugin usa e que ele sabe recriar.
 *
 * O que FICA, por decisão declarada: os registros de lead (CPT de contingência e
 * caixa do Flamingo), o journal de eliminação e as options de configuração
 * gravadas pelo implantador. Desinstalar plugin não é pedido de eliminação de
 * dado pessoal, e apagar registro sem journal é perda sem registro. A remoção
 * desses dados tem rota própria, com capability, journal e regime declarado.
 *
 * Toda escrita passa pelo gravador único, inclusive aqui.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-f3base-options.php';

/**
 * Remove os agendamentos do plugin.
 *
 * @return void
 */
function f3base_uninstall_desagendar(): void {
	$eventos = array( 'f3base_retencao_limpeza', 'f3base_cadencia_relatorio' );

	foreach ( $eventos as $evento ) {
		$timestamp = wp_next_scheduled( $evento );

		while ( false !== $timestamp ) {
			wp_unschedule_event( (int) $timestamp, $evento );
			$timestamp = wp_next_scheduled( $evento );
		}
	}
}

/**
 * Remove a tabela de chaves do endpoint (deduplicação e rate limit).
 *
 * @return void
 */
function f3base_uninstall_tabela(): void {
	global $wpdb;

	$tabela = $wpdb->prefix . 'f3base_leads_dedup';

	$wpdb->query( "DROP TABLE IF EXISTS `{$tabela}`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL
}

/**
 * Remove os transientes do plugin.
 *
 * @return void
 */
function f3base_uninstall_transientes(): void {
	global $wpdb;

	$prefixos = array( '_transient_f3base_', '_transient_timeout_f3base_' );

	foreach ( $prefixos as $prefixo ) {
		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$wpdb->esc_like( $prefixo ) . '%'
			)
		);
	}
}

/**
 * Remove o estado de execução do próprio plugin.
 *
 * @return void
 */
function f3base_uninstall_estado(): void {
	$descartaveis = array(
		'f3base_atividade',
		'f3base_endpoint_segredo',
		'f3base_cadencia_estado',
	);

	foreach ( $descartaveis as $nome ) {
		F3Base_Options::remover( $nome );
	}
}

f3base_uninstall_desagendar();
f3base_uninstall_tabela();
f3base_uninstall_transientes();
f3base_uninstall_estado();
