/**
 * F3 Base Site Core — carregador do LinkedIn Insight Tag.
 *
 * Este arquivo só chega ao HTML quando as duas condições fecham no servidor:
 * `f3base_linkedin_partner_id` preenchida E consentimento vigente. Sem ID, nada
 * sai — nunca um placeholder.
 *
 * A conferência de consentimento é refeita aqui porque página em cache congela a
 * decisão do primeiro visitante: o servidor decide se o carregador entra, e o
 * navegador decide se ele carrega a tag.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseLinkedinDados;

	if (!dados || typeof dados !== 'object' || !dados.partnerId) {
		return;
	}

	function permitido() {
		if (window.f3baseConsentimento && typeof window.f3baseConsentimento.permiteTags === 'function') {
			return window.f3baseConsentimento.permiteTags();
		}

		return true;
	}

	function carregar() {
		if (!permitido()) {
			return;
		}

		window._linkedin_partner_id = String(dados.partnerId);
		window._linkedin_data_partner_ids = window._linkedin_data_partner_ids || [];

		if (window._linkedin_data_partner_ids.indexOf(window._linkedin_partner_id) === -1) {
			window._linkedin_data_partner_ids.push(window._linkedin_partner_id);
		}

		if (document.getElementById('f3base-linkedin-insight')) {
			return;
		}

		var tag = document.createElement('script');

		tag.id = 'f3base-linkedin-insight';
		tag.type = 'text/javascript';
		tag.async = true;
		tag.src = String(dados.origem);

		var primeiro = document.getElementsByTagName('script')[0];

		if (primeiro && primeiro.parentNode) {
			primeiro.parentNode.insertBefore(tag, primeiro);
		} else {
			document.head.appendChild(tag);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', carregar);
	} else {
		carregar();
	}
}(window, document));
