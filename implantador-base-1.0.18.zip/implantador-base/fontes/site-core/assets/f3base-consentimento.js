/**
 * F3 Base Site Core — consentimento.
 *
 * Política pré-aprovada por padrão: as tags carregam na chegada e o instrumento
 * do titular é o controle de revisão do rodapé, presente em toda página. A
 * negativa desliga e persiste pelo TTL declarado; o re-aceite religa.
 *
 * Consent Mode: `default` com `granted` na carga (política pré-aprovada) e
 * `update` para `denied` na negativa. O stub de `gtag()` fica definido em toda
 * página — consequência documentada: `typeof gtag === 'function'` passa a ser
 * verdadeiro sempre, e os eventos entram no dataLayer como comandos gtag.
 *
 * Sem JavaScript o controle não opera. A perda é declarada no relatório.
 *
 * Contrato de DOM: qualquer elemento com `data-f3base-consentimento` abre o
 * painel. O tema pode fornecer o botão na part do rodapé; sem ele, o site-core
 * imprime o próprio.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseConsentimentoDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CATEGORIAS = Array.isArray(dados.categorias) && dados.categorias.length
		? dados.categorias
		: ['analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization'];

	var COOKIE = String(dados.cookie || 'f3base_consentimento');
	var TTL_DIAS = parseInt(dados.ttlDias, 10) > 0 ? parseInt(dados.ttlDias, 10) : 180;
	var PRE_APROVADO = String(dados.padrao || 'pre-aprovado') === 'pre-aprovado';
	var TEXTOS = dados.textos && typeof dados.textos === 'object' ? dados.textos : {};

	var painel = null;
	var aviso = null;

	window.dataLayer = window.dataLayer || [];

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	function lerCookie(nome) {
		var partes = String(document.cookie || '').split(';');
		var i;
		var atual;

		for (i = 0; i < partes.length; i++) {
			atual = partes[i].replace(/^\s+/, '');
			if (atual.indexOf(nome + '=') === 0) {
				return decodeURIComponent(atual.substring(nome.length + 1));
			}
		}

		return '';
	}

	function gravarCookie(nome, valor, dias) {
		var seguro = window.location.protocol === 'https:' ? '; Secure' : '';
		document.cookie = nome + '=' + encodeURIComponent(valor) +
			'; Max-Age=' + (dias * 86400) +
			'; Path=/; SameSite=Lax' + seguro;
	}

	function decisaoGravada() {
		var valor = lerCookie(COOKIE);

		return (valor === 'granted' || valor === 'denied') ? valor : '';
	}

	function estadoAtual() {
		var decisao = decisaoGravada();

		if (decisao) {
			return decisao;
		}

		return PRE_APROVADO ? 'granted' : 'denied';
	}

	function mapa(estado) {
		var saida = {};
		var i;

		for (i = 0; i < CATEGORIAS.length; i++) {
			saida[CATEGORIAS[i]] = estado;
		}

		saida.functionality_storage = 'granted';
		saida.security_storage = 'granted';

		return saida;
	}

	function aplicarPadrao() {
		window.gtag('consent', 'default', mapa(estadoAtual()));
	}

	function atualizar(estado) {
		window.gtag('consent', 'update', mapa(estado));
		window.dataLayer.push({
			event: 'f3base_consentimento',
			f3base_consentimento_estado: estado
		});
	}

	function definir(estado) {
		var normalizado = estado === 'granted' ? 'granted' : 'denied';

		gravarCookie(COOKIE, normalizado, TTL_DIAS);
		atualizar(normalizado);
		sincronizarPainel();
		fecharAviso();

		return normalizado;
	}

	function botao(rotulo, aoClicar, classe) {
		var elemento = document.createElement('button');

		elemento.type = 'button';
		elemento.className = classe;
		elemento.textContent = rotulo;
		elemento.addEventListener('click', aoClicar);

		return elemento;
	}

	function construirPainel() {
		var caixa = document.createElement('div');
		var titulo = document.createElement('h2');
		var texto = document.createElement('p');
		var estado = document.createElement('p');
		var acoes = document.createElement('div');

		caixa.className = 'f3base-consentimento-painel';
		caixa.setAttribute('role', 'dialog');
		caixa.setAttribute('aria-modal', 'false');
		caixa.setAttribute('aria-label', String(TEXTOS.titulo || 'Consentimento'));
		caixa.hidden = true;

		titulo.className = 'f3base-consentimento-titulo';
		titulo.textContent = String(TEXTOS.titulo || '');

		texto.className = 'f3base-consentimento-texto';
		texto.textContent = String(TEXTOS.explicacao || '');

		estado.className = 'f3base-consentimento-estado';

		acoes.className = 'f3base-consentimento-acoes';
		acoes.appendChild(botao(String(TEXTOS.aceitar || 'Permitir'), function () {
			definir('granted');
		}, 'f3base-consentimento-aceitar'));
		acoes.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-recusar'));
		acoes.appendChild(botao(String(TEXTOS.fechar || 'Fechar'), function () {
			caixa.hidden = true;
		}, 'f3base-consentimento-fechar'));

		caixa.appendChild(titulo);
		caixa.appendChild(texto);
		caixa.appendChild(estado);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.className = 'f3base-consentimento-politica';
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || 'Política de Privacidade');
			caixa.appendChild(link);
		}

		caixa.appendChild(acoes);
		document.body.appendChild(caixa);

		painel = { caixa: caixa, estado: estado };

		sincronizarPainel();

		return painel;
	}

	function sincronizarPainel() {
		if (!painel) {
			return;
		}

		painel.estado.textContent = estadoAtual() === 'granted'
			? String(TEXTOS.estadoAtivo || '')
			: String(TEXTOS.estadoNegado || '');
	}

	function abrir() {
		if (!painel) {
			construirPainel();
		}

		sincronizarPainel();
		painel.caixa.hidden = false;
		painel.caixa.scrollIntoView({ block: 'nearest' });
	}

	function fecharAviso() {
		if (aviso && aviso.parentNode) {
			aviso.parentNode.removeChild(aviso);
			aviso = null;
		}
	}

	function mostrarAviso() {
		if (!dados.avisoPrimeiraVisita) {
			return;
		}

		if (decisaoGravada()) {
			return;
		}

		try {
			if (window.localStorage.getItem('f3base_aviso_visto') === '1') {
				return;
			}
			window.localStorage.setItem('f3base_aviso_visto', '1');
		} catch (erro) {
			// Armazenamento indisponível: o aviso aparece nesta visita e não persiste.
		}

		aviso = document.createElement('div');
		aviso.className = 'f3base-consentimento-aviso';
		aviso.setAttribute('role', 'status');

		var texto = document.createElement('span');
		texto.textContent = String(TEXTOS.aviso || '');
		aviso.appendChild(texto);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || '');
			aviso.appendChild(link);
		}

		aviso.appendChild(botao(String(TEXTOS.avisoOk || 'Ok'), fecharAviso, 'f3base-consentimento-aviso-ok'));
		aviso.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-aviso-recusar'));

		document.body.appendChild(aviso);
	}

	function ligarControles() {
		var seletor = String(dados.seletorControle || '[data-f3base-consentimento]');

		document.addEventListener('click', function (evento) {
			var alvo = evento.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(seletor)) {
					evento.preventDefault();
					abrir();
					return;
				}
				alvo = alvo.parentNode;
			}
		});
	}

	function iniciar() {
		if (dados.controleRodape) {
			ligarControles();
		}

		mostrarAviso();
	}

	aplicarPadrao();

	window.f3baseConsentimento = {
		estado: estadoAtual,
		definir: definir,
		abrir: abrir,
		permiteTags: function () {
			return estadoAtual() === 'granted';
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', iniciar);
	} else {
		iniciar();
	}
}(window, document));
