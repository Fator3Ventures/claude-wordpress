/**
 * F3 Base Site Core — leads por WhatsApp.
 *
 * Monta a URL `wa.me` a partir do número da configuração, registra a interação e
 * transporta a atribuição. O registro sai por `navigator.sendBeacon()` para o
 * endpoint REST ANTES da navegação, fire and forget: nunca bloqueia nem atrasa a
 * abertura da conversa, e falha de registro não custa o lead.
 *
 * Honestidade do desenho: o registro é melhor esforço — bloqueador derruba
 * beacon. A conversa no WhatsApp continua sendo a fonte da verdade do lead.
 *
 * Identificadores com nome honesto: o `correlation_id` nasce aqui, no navegador,
 * com fonte criptograficamente segura; o `record_id` nasce no servidor. O mesmo
 * `correlation_id` amarra registro, mensagem do `wa.me` e evento.
 *
 * Contrato de DOM (fornecido pelo pattern do tema):
 *   a[data-f3base-lead]              CTA. O valor é o id do formulário do fluxo.
 *   [data-f3base-form="<seletor>"]   seletor do formulário associado, opcional.
 *   [data-f3base-mensagem]           mensagem própria do CTA, opcional.
 *   [data-f3base-campo="nome"]       campo do formulário associado.
 *   [data-f3base-honeypot]           campo isca, que precisa chegar vazio.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseLeadsDados;

	if (!dados || typeof dados !== 'object' || !dados.numero) {
		return;
	}

	var CAMPOS = ['nome', 'email', 'telefone', 'mensagem'];
	var LIMITES = dados.limites && typeof dados.limites === 'object' ? dados.limites : {};
	var ATRIBUICAO = dados.atribuicao && typeof dados.atribuicao === 'object' ? dados.atribuicao : {};
	var CHAVE_ATRIBUICAO = String(ATRIBUICAO.chave || 'f3base_atribuicao');
	var TTL_ATRIBUICAO = parseInt(ATRIBUICAO.ttlDias, 10) > 0 ? parseInt(ATRIBUICAO.ttlDias, 10) : 30;
	var PRIMEIRO_TOQUE = String(ATRIBUICAO.modelo || 'first-touch') === 'first-touch';

	var registrados = {};
	var iniciados = {};

	function correlationId() {
		var bytes = new Uint8Array(8);
		var saida = '';
		var i;

		if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
			window.crypto.getRandomValues(bytes);
		} else {
			for (i = 0; i < bytes.length; i++) {
				bytes[i] = Math.floor(Math.random() * 256);
			}
		}

		for (i = 0; i < bytes.length; i++) {
			saida += ('0' + bytes[i].toString(16)).slice(-2);
		}

		return saida;
	}

	/**
	 * Comprimento em CARACTERES, e não em unidades UTF-16.
	 *
	 * `'coração'.length` é 7 e `Array.from('coração').length` também — mas um
	 * emoji conta 2 pela primeira medida e 1 pela segunda. A unidade tem de ser
	 * a MESMA dos dois lados: o servidor mede caracteres, publica o limite em
	 * caracteres por `limites_publicos()` e recusa por caractere.
	 */
	function caracteres(texto) {
		return Array.from(texto);
	}

	/**
	 * Corta pelo limite publicado, na unidade publicada.
	 *
	 * O corte por `slice()` fatia unidades UTF-16: um limite alcançado no meio
	 * de um par substituto devolveria metade de um caractere, e o servidor
	 * receberia texto que ninguém escreveu.
	 */
	function limitar(nome, valor) {
		var limite = parseInt(LIMITES[nome], 10);
		var texto = String(valor == null ? '' : valor);
		var letras;

		if (limite > 0) {
			letras = caracteres(texto);

			if (letras.length > limite) {
				return letras.slice(0, limite).join('');
			}
		}

		return texto;
	}

	/**
	 * Carimbo em segundos, como o servidor o guarda.
	 */
	function agora() {
		return String(Math.floor(Date.now() / 1000));
	}

	function lerAtribuicaoGuardada() {
		try {
			var cru = window.localStorage.getItem(CHAVE_ATRIBUICAO);

			if (!cru) {
				return null;
			}

			var guardado = JSON.parse(cru);

			if (!guardado || typeof guardado !== 'object') {
				return null;
			}

			if (parseInt(guardado.expira, 10) < Math.floor(Date.now() / 1000)) {
				window.localStorage.removeItem(CHAVE_ATRIBUICAO);
				return null;
			}

			return guardado.valor && typeof guardado.valor === 'object' ? guardado.valor : null;
		} catch (erro) {
			return null;
		}
	}

	function guardarAtribuicao(valor) {
		try {
			window.localStorage.setItem(CHAVE_ATRIBUICAO, JSON.stringify({
				expira: Math.floor(Date.now() / 1000) + (TTL_ATRIBUICAO * 86400),
				valor: valor
			}));
		} catch (erro) {
			// Armazenamento indisponível: a atribuição vale só para esta navegação.
		}
	}

	function atribuicaoDaUrl() {
		var busca = new URLSearchParams(window.location.search);
		var mapa = {
			fonte: 'utm_source',
			meio: 'utm_medium',
			campanha: 'utm_campaign',
			termo: 'utm_term',
			conteudo: 'utm_content'
		};
		var saida = {};
		var chave;
		var valor;

		for (chave in mapa) {
			if (Object.prototype.hasOwnProperty.call(mapa, chave)) {
				valor = busca.get(mapa[chave]);
				if (valor) {
					saida[chave] = String(valor);
				}
			}
		}

		if (document.referrer && document.referrer.indexOf(window.location.origin) !== 0) {
			saida.referrer = document.referrer;
		}

		return saida;
	}

	function atribuicao() {
		var guardada = lerAtribuicaoGuardada();
		var atual = atribuicaoDaUrl();
		var temAtual = Object.keys(atual).length > 0;
		var escolhida;

		if (PRIMEIRO_TOQUE) {
			escolhida = guardada || atual;
		} else {
			escolhida = temAtual ? atual : (guardada || {});
		}

		if (!escolhida.primeiro_toque_em) {
			escolhida.primeiro_toque_em = guardada && guardada.primeiro_toque_em
				? String(guardada.primeiro_toque_em)
				: agora();
		}

		escolhida.modelo = String(ATRIBUICAO.modelo || 'first-touch');

		if (!guardada || (!PRIMEIRO_TOQUE && temAtual)) {
			guardarAtribuicao(escolhida);
		}

		return escolhida;
	}

	function formularioDe(gatilho) {
		var seletor = gatilho.getAttribute('data-f3base-form');

		if (!seletor) {
			return null;
		}

		try {
			return document.querySelector(seletor);
		} catch (erro) {
			return null;
		}
	}

	function valorDoCampo(escopo, nome) {
		var elemento = escopo.querySelector('[data-f3base-campo="' + nome + '"]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="' + nome + '"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function honeypotDe(escopo) {
		var elemento = escopo.querySelector('[data-f3base-honeypot]');

		if (!elemento) {
			elemento = escopo.querySelector('[name="website"]');
		}

		return elemento && typeof elemento.value === 'string' ? elemento.value.trim() : '';
	}

	function coletar(gatilho) {
		var escopo = formularioDe(gatilho);
		var carga = {};
		var i;
		var nome;

		if (escopo) {
			for (i = 0; i < CAMPOS.length; i++) {
				nome = CAMPOS[i];
				carga[nome] = limitar(nome, valorDoCampo(escopo, nome));
			}
			carga.website = honeypotDe(escopo);
		}

		return carga;
	}

	function temContato(carga) {
		var i;

		for (i = 0; i < CAMPOS.length; i++) {
			if (carga[CAMPOS[i]]) {
				return true;
			}
		}

		return false;
	}

	function mensagemDe(gatilho, id) {
		var propria = gatilho.getAttribute('data-f3base-mensagem');
		var base = propria || String(dados.mensagem || '');

		return base ? base + ' [ref: ' + id + ']' : '[ref: ' + id + ']';
	}

	function urlWhatsapp(gatilho, id) {
		var numero = gatilho.getAttribute('data-f3base-numero') || String(dados.numero);
		var texto = encodeURIComponent(mensagemDe(gatilho, id));

		return 'https://wa.me/' + encodeURIComponent(numero) + '?text=' + texto;
	}

	function enviar(carga) {
		var corpo = JSON.stringify(carga);

		try {
			if (navigator && typeof navigator.sendBeacon === 'function') {
				navigator.sendBeacon(String(dados.endpoint), new Blob([corpo], { type: 'application/json' }));
				return;
			}

			if (typeof window.fetch === 'function') {
				window.fetch(String(dados.endpoint), {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: corpo,
					keepalive: true,
					credentials: 'omit'
				}).catch(function () {
					// Fire and forget: falha de registro nunca custa o lead.
				});
			}
		} catch (erro) {
			// Fire and forget: bloqueador derruba beacon, e a conversa segue.
		}
	}

	function evento(nome, parametros) {
		if (!dados.eventosGa4 || typeof window.gtag !== 'function') {
			return;
		}

		try {
			window.gtag('event', nome, parametros);
		} catch (erro) {
			// Medição nunca interrompe o fluxo do visitante.
		}
	}

	function marcarInicio(gatilho) {
		var id = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';

		if (iniciados[id]) {
			return;
		}

		iniciados[id] = true;
		evento('form_start', { form_id: id });
	}

	/**
	 * Correlação estável por CTA dentro de uma janela curta.
	 *
	 * Duplo clique reaproveita a mesma correlação — e o servidor a deduplica pela
	 * chave única. Passada a janela, um novo clique é uma nova interação.
	 */
	function correlacaoDo(gatilho) {
		var guardada = gatilho.getAttribute('data-f3base-correlation');
		var carimbo = parseInt(gatilho.getAttribute('data-f3base-correlation-em'), 10);
		var segundos = Math.floor(Date.now() / 1000);

		if (guardada && carimbo > 0 && (segundos - carimbo) <= 5) {
			return guardada;
		}

		var nova = correlationId();

		gatilho.setAttribute('data-f3base-correlation', nova);
		gatilho.setAttribute('data-f3base-correlation-em', String(segundos));

		return nova;
	}

	function aoClicar(gatilho) {
		var id = correlacaoDo(gatilho);
		var formulario = gatilho.getAttribute('data-f3base-lead') || 'contato-whatsapp';
		var carga = coletar(gatilho);
		var contato = temContato(carga);
		var destino = urlWhatsapp(gatilho, id);

		gatilho.setAttribute('href', destino);

		if (registrados[id]) {
			return;
		}

		registrados[id] = true;

		carga.token = String(dados.token || '');
		carga.correlation_id = id;
		carga.formulario = limitar('formulario', formulario);
		carga.pagina = limitar('pagina', window.location.pathname + window.location.search);
		carga.consentimento = !!(window.f3baseConsentimento && window.f3baseConsentimento.permiteTags());
		carga.atribuicao = atribuicao();

		if (typeof carga.website === 'undefined') {
			carga.website = '';
		}

		enviar(carga);

		if (contato) {
			evento('generate_lead', {
				form_id: formulario,
				correlation_id: id
			});
		} else {
			evento('select_content', {
				content_type: 'whatsapp_cta',
				item_id: formulario,
				correlation_id: id
			});
		}
	}

	function ligar() {
		var seletor = String(dados.seletor || '[data-f3base-lead]');

		document.addEventListener('click', function (ev) {
			var alvo = ev.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(seletor)) {
					aoClicar(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		}, true);

		document.addEventListener('input', function (ev) {
			var alvo = ev.target;

			if (!alvo || alvo.nodeType !== 1 || !alvo.closest) {
				return;
			}

			var formulario = alvo.closest('form');

			if (!formulario) {
				return;
			}

			var gatilhos = document.querySelectorAll(seletor);
			var i;

			for (i = 0; i < gatilhos.length; i++) {
				if (formularioDe(gatilhos[i]) === formulario) {
					marcarInicio(gatilhos[i]);
					return;
				}
			}
		}, true);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', ligar);
	} else {
		ligar();
	}
}(window, document));
