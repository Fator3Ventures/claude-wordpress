<?php
/**
 * F3 Base — funções do tema.
 *
 * O tema é apresentação. Funcionalidade persistente mora no site-core.
 * Tudo aqui existe por um destes motivos: declarar suporte, publicar o CSS com
 * a versão certa, ler do banco o que o implantador gravou, ou tirar do HTML
 * peso que o WordPress adiciona sozinho.
 *
 * @package f3base
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Versão do tema.
 *
 * FONTE ÚNICA: o cabeçalho do style.css, lido por wp_get_theme(). Nenhuma
 * constante com o número literal — o caso medido (3.0.4) foi exatamente esse:
 * o style.css subiu de versão, a constante ficou para trás, o enqueue publicou
 * o CSS novo com o ?ver= antigo e navegador e cache seguiram servindo o arquivo
 * velho. O fallback pelo mtime só age em cabeçalho corrompido, e ainda assim
 * muda quando o arquivo muda.
 *
 * @return string Versão para o parâmetro ?ver= do asset.
 */
function f3base_versao(): string {
	static $versao = null;

	if ( null === $versao ) {
		$declarada = (string) wp_get_theme()->get( 'Version' );

		if ( '' === $declarada ) {
			$arquivo   = get_theme_file_path( 'style.css' );
			$declarada = file_exists( $arquivo ) ? (string) filemtime( $arquivo ) : '';
		}

		$versao = $declarada;
	}

	return $versao;
}

/**
 * Suporte mínimo do tema.
 *
 * Tema de blocos já traz templates, estilos do editor e alinhamento largo pelo
 * theme.json — só entra aqui o que o theme.json não declara.
 *
 * @return void
 */
function f3base_suporte(): void {
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 48,
			'width'       => 180,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);

	/*
	 * Contrato com o site-core: a part do rodapé já fornece o botão do controle
	 * de consentimento. Sem esta declaração o site-core imprime o dele em
	 * wp_footer e a página passa a ter DOIS controles. O comportamento continua
	 * sendo do plugin — o tema fornece só a apresentação (princípio 4).
	 */
	add_theme_support( 'f3base-consentimento-rodape' );
}
add_action( 'after_setup_theme', 'f3base_suporte' );

/**
 * Traduções do tema.
 *
 * Em `init`, e não em `after_setup_theme`: desde o WordPress 6.7 carregar
 * domínio de tradução antes de `init` emite aviso de "doing it wrong", e o
 * contrato exige zero notice.
 *
 * @return void
 */
function f3base_traducoes(): void {
	load_theme_textdomain( 'f3base', get_template_directory() . '/languages' );
}
add_action( 'init', 'f3base_traducoes' );

/**
 * Registro dos assets do tema.
 *
 * ARMADILHA MEDIDA — registrar em `init`, nunca em `wp_enqueue_scripts`:
 * em tema de blocos o template-canvas resolve get_the_block_template_html() na
 * PRIMEIRA instrução do arquivo, então cada bloco e cada template part
 * renderizam ANTES de wp_head() — e portanto antes de wp_enqueue_scripts.
 * Asset registrado só naquele gancho não existe para quem renderiza
 * (did_action('wp_enqueue_scripts') = 0 dentro das parts), e o enqueue some sem
 * erro e sem nada no HTML. Registro aqui; a wp_enqueue_scripts fica só a
 * decisão condicional de enfileirar.
 *
 * @return void
 */
function f3base_registrar_assets(): void {
	wp_register_style( 'f3base', get_stylesheet_uri(), array(), f3base_versao() );
}
add_action( 'init', 'f3base_registrar_assets' );

/**
 * Decisão condicional de enfileirar.
 *
 * @return void
 */
function f3base_enfileirar_assets(): void {
	if ( is_feed() ) {
		return;
	}

	wp_enqueue_style( 'f3base' );
}
add_action( 'wp_enqueue_scripts', 'f3base_enfileirar_assets' );

/**
 * Categoria de padrões do tema.
 *
 * Os arquivos de patterns/ são registrados pelo próprio WordPress; só a
 * categoria precisa de declaração.
 *
 * @return void
 */
function f3base_categoria_padroes(): void {
	register_block_pattern_category(
		'f3base',
		array( 'label' => __( 'Método F3', 'f3base' ) )
	);
}
add_action( 'init', 'f3base_categoria_padroes' );

/**
 * Injeta o `ref` do menu no bloco Navigation, em tempo de render.
 *
 * O `ref` é o ID de um post `wp_navigation` — diferente em cada instalação.
 * Fixo no arquivo, quebra a instalação limpa; ausente, o WordPress cai no
 * fallback de lista de páginas. Por isso: o implantador cria a navegação de
 * forma idempotente e grava o ID na option `f3base_nav_id`; o tema LÊ a option
 * e injeta. O implantador escreve, o tema lê.
 *
 * O gancho é `render_block_data` — e não `render_block` — porque `render_block`
 * recebe o bloco JÁ RENDERIZADO: mudar um atributo ali não tem efeito nenhum.
 * `render_block_data` filtra o bloco analisado, antes do render.
 *
 * Duas guardas: bloco que já traz `ref` (override do editor de site) e bloco
 * com blocos internos próprios (a navegação secundária do rodapé, curada em
 * arquivo) passam intactos. ID que não aponta para um `wp_navigation`
 * publicado também passa intacto — o fallback do core é preferível a um menu
 * vazio.
 *
 * @param array $bloco Bloco analisado.
 * @return array Bloco, com `ref` quando aplicável.
 */
function f3base_navegacao_ref( $bloco ) {
	if ( ! is_array( $bloco ) || 'core/navigation' !== ( $bloco['blockName'] ?? '' ) ) {
		return $bloco;
	}

	if ( ! empty( $bloco['attrs']['ref'] ) || ! empty( $bloco['innerBlocks'] ) ) {
		return $bloco;
	}

	$id = (int) get_option( 'f3base_nav_id', 0 );

	if ( $id <= 0 ) {
		return $bloco;
	}

	$menu = get_post( $id );

	if ( ! $menu instanceof WP_Post || 'wp_navigation' !== $menu->post_type || 'publish' !== $menu->post_status ) {
		return $bloco;
	}

	$bloco['attrs']['ref'] = $id;

	return $bloco;
}
add_filter( 'render_block_data', 'f3base_navegacao_ref' );

/**
 * Resolve o link da política de privacidade pelo permalink real.
 *
 * O aviso aponta pelo permalink, nunca por slug fixo. E quando não há política
 * PUBLICADA, o link não sai no HTML: visitante anônimo não lê rascunho, e
 * apontar para uma página não publicada é aparência de conformidade.
 *
 * @param string $conteudo HTML já renderizado do bloco.
 * @param array  $bloco    Bloco analisado.
 * @return string HTML do bloco.
 */
function f3base_link_privacidade( $conteudo, $bloco ) {
	if ( 'core/paragraph' !== ( $bloco['blockName'] ?? '' ) ) {
		return $conteudo;
	}

	if ( ! is_string( $conteudo ) || false === strpos( $conteudo, 'f3base-link-privacidade' ) ) {
		return $conteudo;
	}

	$url = (string) get_privacy_policy_url();

	if ( '' === $url ) {
		return '';
	}

	$processador = new WP_HTML_Tag_Processor( $conteudo );

	while ( $processador->next_tag(
		array(
			'tag_name'   => 'A',
			'class_name' => 'f3base-link-privacidade',
		)
	) ) {
		$processador->set_attribute( 'href', esc_url( $url ) );
	}

	return $processador->get_updated_html();
}
add_filter( 'render_block', 'f3base_link_privacidade', 10, 2 );

/**
 * Marca o CTA de contato com o atributo que o site-core procura.
 *
 * O pattern entrega um link simples para a página de contato — que funciona
 * sozinho, sem plugin e sem JavaScript. O site-core, quando ativo e com número
 * gravado, promove esse mesmo link a `wa.me` no servidor; o seletor dele é o
 * atributo `data-f3base-lead` no <a>. O atributo não vive no arquivo do pattern
 * porque atributo estranho no markup do bloco `core/button` invalida o bloco no
 * editor — então quem o carimba é o tema, no render.
 *
 * Prioridade 5: plugins carregam antes do tema, e a promoção do href do
 * site-core roda em `render_block` na prioridade 10. Carimbar depois dela seria
 * carimbar tarde demais.
 *
 * @param string $conteudo HTML já renderizado do bloco.
 * @param array  $bloco    Bloco analisado.
 * @return string HTML do bloco.
 */
function f3base_marcar_cta_contato( $conteudo, $bloco ) {
	if ( 'core/button' !== ( $bloco['blockName'] ?? '' ) ) {
		return $conteudo;
	}

	if ( ! is_string( $conteudo ) || false === strpos( $conteudo, 'f3base-acao-contato' ) ) {
		return $conteudo;
	}

	$processador = new WP_HTML_Tag_Processor( $conteudo );
	$mudou       = false;

	while ( $processador->next_tag( array( 'tag_name' => 'A' ) ) ) {
		if ( null !== $processador->get_attribute( 'data-f3base-lead' ) ) {
			continue;
		}

		$processador->set_attribute( 'data-f3base-lead', 'cta' );
		$mudou = true;
	}

	return $mudou ? $processador->get_updated_html() : $conteudo;
}
add_filter( 'render_block', 'f3base_marcar_cta_contato', 5, 2 );

/**
 * Tira do HTML os scripts e estilos de emoji.
 *
 * Peso que o WordPress adiciona sozinho em toda página, sem consumidor neste
 * site. Cobre os ganchos antigos e o `wp_enqueue_emoji_styles` do 6.4+.
 *
 * @return void
 */
function f3base_sem_emoji(): void {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'admin_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'embed_head', 'print_emoji_detection_script' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'f3base_sem_emoji' );

/**
 * Remove o plugin de emoji do editor clássico.
 *
 * @param array $plugins Plugins do TinyMCE.
 * @return array Plugins sem `wpemoji`.
 */
function f3base_sem_emoji_tinymce( $plugins ) {
	return is_array( $plugins ) ? array_values( array_diff( $plugins, array( 'wpemoji' ) ) ) : $plugins;
}
add_filter( 'tiny_mce_plugins', 'f3base_sem_emoji_tinymce' );
