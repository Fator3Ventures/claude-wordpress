<?php
/**
 * Title: Chamada para contato por WhatsApp
 * Slug: f3base/cta-whatsapp
 * Categories: f3base, call-to-action
 * Description: Faixa de conversão com título, linha de apoio e o botão de contato que o site-core transforma em conversa de WhatsApp.
 * Keywords: contato, conversão, whatsapp
 * Viewport Width: 1280
 * Inserter: true
 *
 * @package f3base
 */

?>
<!-- wp:group {"align":"full","className":"f3base-faixa-escura","backgroundColor":"inverso","textColor":"superficie","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|md","padding":{"top":"var:preset|spacing|xl","bottom":"var:preset|spacing|xl"}},"elements":{"link":{"color":{"text":"var:preset|color|base"},":hover":{"color":{"text":"var:preset|color|superficie"}}},"heading":{"color":{"text":"var:preset|color|base"}},"button":{"color":{"background":"var:preset|color|base","text":"var:preset|color|inverso"},"border":{"color":"var:preset|color|base"},":hover":{"color":{"background":"var:preset|color|superficie","text":"var:preset|color|inverso"},"border":{"color":"var:preset|color|superficie"}}}}}} -->
<div class="wp-block-group alignfull f3base-faixa-escura has-superficie-color has-inverso-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--xl);padding-bottom:var(--wp--preset--spacing--xl)"><!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Fale com quem constrói', 'f3base' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medio"} -->
<p class="has-medio-font-size"><?php esc_html_e( 'Conte o que precisa e a conversa começa direto no WhatsApp, sem formulário longo e sem página intermediária.', 'f3base' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"var:preset|spacing|sm"}}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"f3base-acao-contato"} -->
<div class="wp-block-button f3base-acao-contato"><a class="wp-block-button__link wp-element-button" href="/contato/"><?php esc_html_e( 'Falar com a equipe', 'f3base' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph {"fontSize":"pequeno"} -->
<p class="has-pequeno-font-size"><?php esc_html_e( 'O acionamento registra a interação e a origem da visita antes de abrir a conversa. As preferências de privacidade ficam no controle do rodapé.', 'f3base' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->
