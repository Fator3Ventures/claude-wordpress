<?php
/**
 * Title: Abertura de página
 * Slug: f3base/hero
 * Categories: f3base, banner
 * Description: Faixa de abertura de largura total, com título de seção, linha de apoio e chamada para contato.
 * Keywords: abertura, destaque, chamada
 * Viewport Width: 1280
 * Inserter: true
 *
 * @package f3base
 */

?>
<!-- wp:group {"align":"full","className":"f3base-faixa-escura","backgroundColor":"inverso","textColor":"superficie","layout":{"type":"constrained"},"style":{"spacing":{"blockGap":"var:preset|spacing|md","padding":{"top":"var:preset|spacing|xxl","bottom":"var:preset|spacing|xxl"}},"elements":{"link":{"color":{"text":"var:preset|color|base"},":hover":{"color":{"text":"var:preset|color|superficie"}}},"heading":{"color":{"text":"var:preset|color|base"}},"button":{"color":{"background":"var:preset|color|base","text":"var:preset|color|inverso"},"border":{"color":"var:preset|color|base"},":hover":{"color":{"background":"var:preset|color|superficie","text":"var:preset|color|inverso"},"border":{"color":"var:preset|color|superficie"}}}}}} -->
<div class="wp-block-group alignfull f3base-faixa-escura has-superficie-color has-inverso-background-color has-text-color has-background has-link-color" style="padding-top:var(--wp--preset--spacing--xxl);padding-bottom:var(--wp--preset--spacing--xxl)"><!-- wp:heading {"level":2,"fontSize":"maior"} -->
<h2 class="wp-block-heading has-maior-font-size"><?php esc_html_e( 'Um método que sabe reprovar', 'f3base' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"medio"} -->
<p class="has-medio-font-size"><?php esc_html_e( 'A entrega roda por um comando único, do empacotamento à verificação. Cada regra do método virou detector com piso provado, e nenhuma etapa depende de alguém lembrar de executá-la: sem passo manual.', 'f3base' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","flexWrap":"wrap"},"style":{"spacing":{"blockGap":"var:preset|spacing|sm"}}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"f3base-acao-contato"} -->
<div class="wp-block-button f3base-acao-contato"><a class="wp-block-button__link wp-element-button" href="/contato/"><?php esc_html_e( 'Falar com a equipe', 'f3base' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group -->
