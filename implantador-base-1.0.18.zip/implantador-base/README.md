<!-- gerado:inicio=carimbo -->
# implantador-base 1.0.18 — leia-me

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio: foi o que aconteceu da 1.0.6 à 1.0.13. O que não pode ser gerado no momento da escrita
> sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `1.0.18` |
| Implantador · tema · site-core | `1.0.18` · `1.0.1` · `1.0.1` |
| Bundle desta identidade | `implantador-base-1.0.18.zip` |
| Origens de release suportadas | 18 além da instalação limpa |
| Caminhos exatos no inventário | 112 |
| Prefixos declarados no inventário | 3 |
| Arquivos no pacote (fora de `dist/`) | 306 |
| Requisitos em `suite/manifesto.tsv` | 176 |
| Armadilhas com checagem mapeada | 85 |
| Armadilhas em pendência declarada | 11 |
| Detectores com piso em disco | 50 |
| Ramos de piso (negativa + positiva) | 100 |
| Páginas · posts declarados | 6 · 2 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

Pacote-fábrica do Método F3: um plugin de implantação que aplica um estado desejado
declarado em um arquivo único, embarcando o tema de blocos `f3base` e o plugin
persistente `f3base-site-core`. O site que ele produz fala sobre o próprio método.

Este arquivo cobre o que o operador precisa para instalar, executar, reverter e
desligar. O porquê de cada decisão está em `MEMORIA-DECISOES.md`; a identidade e o
inventário da release estão em `MANIFESTO.md`.

O comando único é `bash suite/verificar.sh <caminho-do-pacote>`, com caminho ABSOLUTO;
`bash suite/verificar.sh piso` roda só o piso dos detectores. O locale é `pt_BR` e o fuso
`America/Sao_Paulo`. O prefixo técnico é `f3base` para handles, text domain e slugs, e
`f3base_` para options e metas.

## Árvore de arquivos

**As fontes do tema e do `site-core` moram em `fontes/`, e a profundidade é a correção
de um defeito medido, não organização.** `get_plugins()` varre a raiz do plugin e UM
nível de subdiretório; com o `site-core` em `site-core/f3base-site-core.php`, aquele
cabeçalho entrava na varredura e a tela de instalação oferecia o arquivo errado no link
"Ativar plugin". Em `fontes/` não existe `.php` direto, e os arquivos reais ficam fora
do alcance. Quem prova isso a cada rodada é `pacote.sem_cabecalho_de_plugin_aninhado`.

<!-- gerado:inicio=arvore -->
### Árvore de arquivos

Gerada de disco na montagem desta release. A allow-list executável que decide o que
entra no bundle é `suite/inventario.tsv`.

```
implantador-base/
  MANIFESTO.md
  MEMORIA-DECISOES.md
  README.md
  TEMPLATE.md
  assets/favicon.png
  assets/logo.png
  assets/logo.svg
  assets/plugins/LEIA-ME.txt
  assets/social.png
  config/site.json
  config/site.schema.json
  content/pages/arquitetura.html
  content/pages/contato.html
  content/pages/home.html
  content/pages/manutencao.html
  content/pages/privacidade.html
  content/pages/verificacao.html
  content/posts/o-artefato-decide-o-registro-e-diagnostico.html
  content/posts/por-que-checagem-que-nunca-falhou-nao-e-evidencia.html
  ferramentas/excecoes-de-prefixo.tsv
  ferramentas/prefixo-do-template.tsv
  ferramentas/prefixos-recusados.tsv
  ferramentas/renomear-prefixo.php
  ferramentas/renomear-prefixo.sh
  fontes/site-core/admin/assets/f3base-admin.css
  fontes/site-core/admin/class-f3base-admin-tela.php
  fontes/site-core/assets/f3base-consentimento.js
  fontes/site-core/assets/f3base-leads.js
  fontes/site-core/assets/f3base-linkedin.js
  fontes/site-core/f3base-site-core.php
  fontes/site-core/includes/class-f3base-atividade.php
  fontes/site-core/includes/class-f3base-modulo-cabecalhos.php
  fontes/site-core/includes/class-f3base-modulo-cadencia-relatorio.php
  fontes/site-core/includes/class-f3base-modulo-consentimento.php
  fontes/site-core/includes/class-f3base-modulo-endpoint-leads.php
  fontes/site-core/includes/class-f3base-modulo-guarda-options-mcp.php
  fontes/site-core/includes/class-f3base-modulo-leads-whatsapp.php
  fontes/site-core/includes/class-f3base-modulo-llms-txt-reserva.php
  fontes/site-core/includes/class-f3base-modulo-noindex-honrado.php
  fontes/site-core/includes/class-f3base-modulo-redirects.php
  fontes/site-core/includes/class-f3base-modulo-retencao-eliminacao.php
  fontes/site-core/includes/class-f3base-modulo-rota-origem.php
  fontes/site-core/includes/class-f3base-modulo-schema-extensao.php
  fontes/site-core/includes/class-f3base-modulo-tracking.php
  fontes/site-core/includes/class-f3base-modulo.php
  fontes/site-core/includes/class-f3base-options.php
  fontes/site-core/includes/class-f3base-plugin.php
  fontes/site-core/includes/class-f3base-registro.php
  fontes/site-core/uninstall.php
  fontes/tema/CONTRASTE.md
  fontes/tema/functions.php
  fontes/tema/parts/footer.html
  fontes/tema/parts/header.html
  fontes/tema/patterns/cta-whatsapp.php
  fontes/tema/patterns/faq.php
  fontes/tema/patterns/hero.php
  fontes/tema/patterns/secao-cartoes.php
  fontes/tema/patterns/secao-texto.php
  fontes/tema/style.css
  fontes/tema/templates/404.html
  fontes/tema/templates/archive.html
  fontes/tema/templates/front-page.html
  fontes/tema/templates/index.html
  fontes/tema/templates/page.html
  fontes/tema/templates/search.html
  fontes/tema/templates/single.html
  fontes/tema/theme.json
  implantador-base.php
  includes/assets/implantador.css
  includes/assets/implantador.js
  includes/class-f3base-imp-admin.php
  includes/class-f3base-imp-config.php
  includes/class-f3base-imp-conteudo.php
  includes/class-f3base-imp-entrega.php
  includes/class-f3base-imp-gravador.php
  includes/class-f3base-imp-journal.php
  includes/class-f3base-imp-lotes.php
  includes/class-f3base-imp-navegacao.php
  includes/class-f3base-imp-plano.php
  includes/class-f3base-imp-plugins.php
  includes/class-f3base-imp-preflight.php
  includes/class-f3base-imp-relatorio.php
  includes/class-f3base-imp-seo.php
  suite/afirmacoes.tsv
  suite/armadilhas.tsv
  suite/checagens/a11y.php
  suite/checagens/bloqueadas.php
  suite/checagens/conteudo.php
  suite/checagens/copy.php
  suite/checagens/entrega.php
  suite/checagens/estatica.php
  suite/checagens/funcional.php
  suite/checagens/js.mjs
  suite/checagens/meta.php
  suite/checagens/tema.php
  suite/fixtures/a11y.contraste/  (2 arquivo(s) de piso)
  suite/fixtures/config.slug_declarado/  (2 arquivo(s) de piso)
  suite/fixtures/conteudo.demonstrativo/  (4 arquivo(s) de piso)
  suite/fixtures/conteudo.headings/  (4 arquivo(s) de piso)
  suite/fixtures/conteudo.marca_demonstrativa/  (4 arquivo(s) de piso)
  suite/fixtures/conteudo.sem_estilo_avulso/  (2 arquivo(s) de piso)
  suite/fixtures/copy.contrato/  (6 arquivo(s) de piso)
  suite/fixtures/doc.afirmacao_conferida/  (8 arquivo(s) de piso)
  suite/fixtures/estatica.artefato_do_pacote_e_lido/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.carimbo_de_release_nos_documentos/  (14 arquivo(s) de piso)
  suite/fixtures/estatica.contagem_com_nomes/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.detector_chave_sem_consumidor/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.detector_codigo_em_string/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_condicao_literal/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_escrita_unica/  (5 arquivo(s) de piso)
  suite/fixtures/estatica.detector_placeholder/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.detector_version_compare/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.estados_fechados/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.gate_de_fase_do_metadado/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.gate_fonte_unica/  (9 arquivo(s) de piso)
  suite/fixtures/estatica.identidade_do_implantador/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.js_lint/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.json_valido/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.llms_so_pagina_publicada/  (6 arquivo(s) de piso)
  suite/fixtures/estatica.option_fonte_unica/  (6 arquivo(s) de piso)
  suite/fixtures/estatica.option_gravada_sem_leitor/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.pagina_status_fonte_unica/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.php_lint/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.piso_em_sonda_declarado/  (5 arquivo(s) de piso)
  suite/fixtures/estatica.plano_dependencias/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.politica_privacidade_fonte_unica/  (4 arquivo(s) de piso)
  suite/fixtures/estatica.resposta_de_lote_nomeada/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.sem_residuo_de_prefixo/  (10 arquivo(s) de piso)
  suite/fixtures/estatica.simbolos_resolvem/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.troca_invalida_cache/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.unidade_reflete_internas/  (6 arquivo(s) de piso)
  suite/fixtures/estatica.warn_tem_ramo_adverso/  (2 arquivo(s) de piso)
  suite/fixtures/estatica.wp_comentarios_balanceados/  (4 arquivo(s) de piso)
  suite/fixtures/pacote.allow_list/  (5 arquivo(s) de piso)
  suite/fixtures/pacote.backup_sempre_oculto/  (2 arquivo(s) de piso)
  suite/fixtures/pacote.build_fresco/  (4 arquivo(s) de piso)
  suite/fixtures/pacote.sem_cabecalho_de_plugin_aninhado/  (6 arquivo(s) de piso)
  suite/fixtures/plugins.serie_de_backup_normalizada/  (2 arquivo(s) de piso)
  suite/fixtures/tema.main_layout_default/  (2 arquivo(s) de piso)
  suite/fixtures/tema.preset_inexistente/  (2 arquivo(s) de piso)
  suite/fixtures/tema.preset_ocioso/  (2 arquivo(s) de piso)
  suite/fixtures/tema.sem_cor_literal/  (4 arquivo(s) de piso)
  suite/fixtures/tema.versao_assets/  (4 arquivo(s) de piso)
  suite/fixtures/tema.wp_html_declarado/  (6 arquivo(s) de piso)
  suite/fixtures/tema.zero_com_unidade/  (2 arquivo(s) de piso)
  suite/inventario.tsv
  suite/lib/documentos.php
  suite/lib/empacotar.php
  suite/lib/executar.php
  suite/lib/piso.php
  suite/lib/regra.php
  suite/lib/render-pattern.php
  suite/lib/sonda-funcional.php
  suite/lib/sonda-gravador.php
  suite/lib/sonda-hash.php
  suite/lib/sonda-instalacao.php
  suite/lib/sonda-serie.php
  suite/lib/sonda-site-core.php
  suite/manifesto.tsv
  suite/pisos-em-sonda.tsv
  suite/rodada.json
  suite/verificar.sh
```
<!-- gerado:fim=arvore -->

## Este pacote é um template de criação de sites

O site que ele instala fala sobre o próprio método, e isso é deliberado: o site
demonstrativo **fica**, marcado como substituível, porque é o exemplo funcionante de cada
padrão — o agente que cria um site novo copia dele em vez de inventar markup.

Para criar um site novo a partir daqui, o procedimento executável está em **`TEMPLATE.md`**,
e ele começa pela renomeação do prefixo:

```
cp -a implantador-base <pasta-do-site-novo>
bash <pasta-do-site-novo>/ferramentas/renomear-prefixo.sh <prefixo> <pasta-do-site-novo>
```

Cada site recebe o próprio prefixo técnico — diretório e slug do tema, slug do plugin
persistente, prefixo das options e das metas, text domain, handles, classes CSS e prefixo
das classes PHP —, e dois sites da operação nunca compartilham nome de tema nem de option.
A ferramenta é idempotente, recusa prefixo inválido antes de qualquer escrita, e o que
sobrevive do prefixo antigo está declarado arquivo a arquivo em
`ferramentas/excecoes-de-prefixo.tsv`, com o motivo ao lado. `estatica.sem_residuo_de_prefixo`
confere que nada sobrou fora dessa lista.

Enquanto o conteúdo demonstrativo continuar declarado em `conteudo.demonstrativo` e
`ambiente.tipo` for `producao`, a rodada fecha `conteudo.demonstrativo` em **WARN nomeando
as páginas que ainda são do template**. Não é defeito do pacote: é o aviso de que ele ainda
não virou o site de ninguém.

## Pré-requisitos

### Do site de destino

| Requisito | Valor | Onde está declarado |
|---|---|---|
| PHP | 8.1 ou superior | cabeçalho dos dois plugins e `ambiente.php_minimo` |
| WordPress | 6.7 ou superior | piso efetivo: o cabeçalho do tema pede 6.7, os plugins pedem 6.4, e vale o maior |
| Compatibilidade máxima declarada | série 7.0 | campo de compatibilidade máxima do cabeçalho do tema |
| Banco de dados | o que a versão de WordPress em uso exigir | não redeclarado aqui, para não criar uma segunda fonte |
| Saída de rede | HTTPS para o WordPress.org | conferida no preflight, antes de qualquer mutação |

Capacidades exigidas da conta que executa, conferidas no preflight: `manage_options`,
`install_plugins`, `activate_plugins`, `install_themes`, `switch_themes`,
`update_themes`, `update_plugins`, `edit_theme_options` e `upload_files`. Capacidade
crítica ausente termina em BLOCKED, sem mutação.

Também medido antes de mutar: método de escrita no sistema de arquivos, escrita nos
destinos, espaço em disco para o pacote temporário, limites de tempo, memória e
upload do PHP, baseline da instalação, colisões de slug e inventário de sobreposições
do editor de site.

### Da máquina que roda o comando único

Quatro executáveis precisam estar no `PATH`: `php`, `node`, `zip` e `unzip`. O comando
único confere os quatro antes de qualquer coisa e, na ausência de qualquer um, fecha
`suite.ambiente` em **BLOCKED nomeando o recurso que falta** e sai com código 2. Não é
FALHA: pré-condição ausente e defeito são coisas diferentes e pedem ações diferentes de
quem lê.

## Instalação

1. Obtenha o bundle da release no repositório de artefatos do projeto. O bundle é um
   arquivo único e nomeado — o nome exato desta release está no bloco gerado no topo
   deste documento, na linha "Bundle desta identidade" — e carrega tema, `site-core` e o
   complemento do canal dentro dele, sem chamada de rede externa para esses três durante
   o deploy.
2. Instale o implantador como plugin, pelo envio de arquivo em **Plugins → Adicionar
   novo → Enviar plugin**, e ative.
3. Não copie arquivo a arquivo sobre código ativo. A troca de diretório é controlada
   e acontece dentro da execução.

O implantador é canônico e consolidado: cada release substitui a anterior por
inteiro. Não existe plugin incremental de correção.

## Execução

```
bash suite/verificar.sh <caminho-do-pacote>   empacota e verifica
bash suite/verificar.sh piso                  roda o piso a partir da raiz do pacote
bash suite/verificar.sh piso <caminho>        roda o piso contra outro caminho
```

Três regras que o próprio script existe para não deixar ninguém contornar:

- **Rodar sem argumento reprova.** Sem caminho não há artefato, e uma rodada sem
  artefato que terminasse em zero seria a pior aprovação possível: ela emite
  `FALHA suite.invocacao` e sai com código 2.
- **Empacotar é a primeira etapa, sempre.** Arquivo fora de `suite/inventario.tsv`
  aborta o build com o nome, antes de qualquer checagem. Artefato de build mais velho
  que a fonte reprova em `pacote.build_fresco` — isso já fez edições "não surtirem
  efeito" por dois ciclos.
- **O código de saída vem da contagem que a função de emissão acumulou.** Nenhuma etapa
  do script corrige o resultado; o contador mora dentro da função que imprime o estado.

### O que a etapa de empacotamento produz

| Artefato | Papel |
|---|---|
| `dist/implantador-base-<identidade>.zip` | o bundle único que o operador envia ao site; a identidade é a do carimbo gerado no topo deste arquivo |
| `dist/lock.tsv` | `sha256` de cada caminho do pacote, uma linha por arquivo |

**Nenhum zip de tema ou de `site-core` é montado aqui, e isso é decisão.** Até a
1.0.15 o empacotamento produzia `<tema>.zip` e `<site-core>.zip` e os copiava para
a raiz do bundle, e **nenhum caminho de instalação os abria**: quem instala lê
`fontes/tema/` e `fontes/site-core/`, que já viajam no bundle, ou o zip que o
operador embute no slot `assets/plugins/<slug>.zip`. Eram bytes mortos dentro do
hash do pacote servindo de prova falsa de entrega. A razão inteira está no item 28
de `MEMORIA-DECISOES.md`, e quem cobra a regra é
`estatica.artefato_do_pacote_e_lido`: artefato instalável que viaja no pacote e não
é lido pelo caminho que instala é achado.

`dist/` é saída de build, declarada como prefixo no inventário e fora do pacote que o
operador envia.

### O que a etapa de verificação cobre

A rodada integral emite **73 checagens**. Elas nascem de **74 requisitos declarados** em
`suite/manifesto.tsv`, cada linha amarrando requisito, checagem, ambiente em que ela pode
ser medida e classe/fase da evidência — a diferença entre os dois números é requisito que
aponta para uma checagem já emitida por outro. O cruzamento é **bidirecional** e roda como
checagem, em `manifesto.bidirecional`: requisito aplicável cuja checagem a rodada não
emitiu é FALHA, e rótulo emitido sem requisito nem armadilha que o justifique também é
FALHA. O mapa de armadilhas — 40 entradas em `suite/armadilhas.tsv` — é calculado dos
rótulos efetivamente emitidos, nunca de uma condição literal; a última rodada fechou com
30 armadilhas mapeadas com piso e 10 pendências declaradas, cada uma nomeada.

As famílias são `estatica`, `entrega`, `tema`, `conteudo`, `pacote`, `formulario`,
`a11y`, `consentimento`, `mcp`, `menu`, `origem`, `plugins`, `relatorio`, `seguranca`,
`orcamento`, `desempenho`, `visual`, `handoff`, `idempotencia`, `homologacao`, `htaccess`,
`copy`, `config`, `lotes`, `privacidade`, `lgpd`, `js` e a própria meta-verificação da
suíte. **A quantidade por família não é digitada aqui** — ela muda a cada release e o
lugar onde ela está certa é a saída da rodada.

**Resultado da última rodada integral sobre este pacote:** código de saída 0, sem FALHA. A
contagem por estado sai na própria rodada e é gravada em `suite/rodada.json` pelo
selo, com o hash do pacote medido; repeti-la aqui à mão foi o defeito que sete releases
carregaram. Os N/A são condicionais não instanciadas com a condição escrita na linha; os
BLOCKED pedem WordPress rodando, navegador ou tráfego real. **Eles não são todos
iguais para a autodesativação, e dizer que "continuam impedindo" era errado:** só
BLOCKED de ENTREGÁVEL do gate de aplicação e de veredito de canal a impedem; BLOCKED de
FASE — evidência que este host não produz — sai nomeado e não segura a ferramenta, e
BLOCKED de PRÉ-CONDIÇÃO DECLARADA deixa a **convergência** pendente sem segurá-la
também. Os três eixos estão descritos em "Execução terminada não é estado convergido".

### O piso, e por que ele é um subcomando próprio

`bash suite/verificar.sh piso` roda **a mesma função** de cada detector contra duas
árvores: a negativa, que reproduz o defeito e precisa ser acusada, e a positiva, que
precisa passar em silêncio. Resultado desta base: **zero falhas** — cada detector provou
acusar o defeito plantado e calar sobre o caso correto. A quantidade de detectores com
piso em disco está no bloco gerado no topo deste documento, e o número de ramos executados
sai na saída do próprio subcomando; nenhum dos dois é digitado aqui.

O piso é o que separa uma checagem correta de uma checagem cega: enquanto o único
resultado observado for aprovação, as duas produzem a mesma saída.

### Máquina de estados da aplicação

`PRONTO → EXECUTANDO → SUCESSO_APLICACAO | FALHA_PARCIAL | FALHA | REVERTIDO`.

Antes da primeira execução real em produção roda o **modo somente-relatório** — não
existe camada de ensaio hospedada, e a produção é o primeiro host externo que o pacote
encontra. A aplicação avança em **lotes**: a tela orquestradora renderiza inline na
resposta do `admin-post.php` e avança por requisições autenticadas sucessivas, uma
unidade idempotente por lote. Uma única requisição síncrona estoura tempo e memória em
hospedagem compartilhada.

Proteções da execução, para o operador saber o que esperar:

- **Lock com heartbeat e renovação atômica.** Execução concorrente é rejeitada.
  Expiração sozinha não impede duas execuções quando uma etapa longa passa do prazo.
- **Checkpoint gravado depois da leitura de volta**, com identificador da execução, da
  release, hash da configuração, etapa, estado e token de disputa. A retomada só
  acontece com a mesma release e o mesmo hash de configuração.
- **Journal antes de mutar**, com pré-imagem, pós-imagem e a operação inversa
  declarativa. Ações irreversíveis são declaradas e excluídas da promessa de reversão.
- **O carimbo de versão aplicada avança apenas em `SUCESSO_APLICACAO`.** Execução que
  aborta no preflight, falha ou é revertida não grava a versão.
- **Autodesativação apenas em `SUCESSO_APLICACAO` e sem nenhum dos oito entregáveis em
  BLOCKED.** Canal MCP incompleto também impede: sem canal, o implantador é a única
  ferramenta de correção que resta. Em falha ele permanece ativo, preserva o log e
  oferece retomada idempotente e reversão das mutações reversíveis.

### Execução terminada não é estado convergido

O encerramento tem **três eixos**, e até a 1.0.17 tinha dois. O terceiro nasceu de um
defeito medido: o gate consultava BLOCKED de entregável e BLOCKED de canal, e **ninguém**
consultava o BLOCKED de PRÉ-CONDIÇÃO DECLARADA. `privacidade.controlador_identificado` e
`formulario.contato-whatsapp` fechavam BLOCKED, apareciam no relatório e não entravam em
lista nenhuma. O resultado era honesto nos fatos e otimista no nome: `SUCESSO_APLICACAO`
mais autodesativação, com a política de privacidade em rascunho e o CTA de WhatsApp em
degradado.

| Eixo | Pergunta que ele responde | Quem o move |
|---|---|---|
| `estado_final` | O implantador aplicou o que sabia aplicar? | qualquer checagem em FALHA |
| `convergencia` | O site está completo? | pré-condição declarada em BLOCKED (pendente) ou em FALHA (não convergiu) |
| `autodesativacao` | O ciclo do implantador terminou? | o gate de aplicação: os oito entregáveis e os dois vereditos de canal |

O eixo novo sai na linha `entrega.convergencia` e na frase final do encerramento, que
diz **o que falta e como sair** — preencher a chave nomeada em `config/site.json` e
executar de novo, sem passo manual no wp-admin.

**A autodesativação continua amarrada ao gate de aplicação, e não à convergência.** É
aqui que esta base discorda da auditoria, e a discordância fica escrita: a
autodesativação é sobre o CICLO DO IMPLANTADOR ter terminado, não sobre o site estar
completo. Manter a ferramenta no ar por dado que só o operador tem — razão social,
documento, endereço, número de WhatsApp, nome do mecanismo de cadência da hospedagem —
prenderia o pacote a uma espera indefinida: um site cujo operador nunca preenche o
controlador ficaria com o implantador ativo para sempre, que é exatamente a forma de
gate insatisfazível que a 1.0.8 eliminou para a rodada limpa. O que o eixo muda é o NOME
do resultado e a frase de encerramento, não quem sai de cena.

## Remoção

- **Implantador.** Autodesativado não é descartável: o pacote versionado continua sendo
  a referência executável do estado gerenciado. Remover o plugin do servidor é escolha
  operacional, com o pacote preservado no projeto. Remover o implantador **não** remove
  nada do que ele aplicou.
- **`site-core`.** Desativar interrompe o comportamento; excluir dispara
  `uninstall.php`, que declara o destino de cada conjunto de dados. Sai o que só o
  plugin usa e sabe recriar: estado de execução, segredo do endpoint, agendamentos,
  transientes e a tabela de deduplicação. O que é dado de titular segue o regime de
  retenção e eliminação, não a desinstalação.
- **Tema.** Trocar o tema não desliga leads, medição, redirects nem retenção — é para
  isso que eles moram no `site-core`. O controle de consentimento do rodapé continua
  existindo: o `site-core` mantém markup de reserva idêntico ao do tema e o imprime
  quando o tema não declara o suporte correspondente.

## Plugins

Política declarada: `politica_versao` é `ultima-da-fonte-oficial` e `autoupdate` é
`todos`. Nenhuma versão é fixada no arquivo de configuração e nenhum checksum de
terceiro entra no lock — o gate é a leitura de volta de cada option gravada.

**Precedência de origem, na ordem em que o instalador tenta:** `assets/plugins/<slug>.zip`
(slot embutido, sem rede) → URL declarada na entrada, com o host conferido contra
`plugins.origens_url_autorizadas` → WordPress.org. Pôr o zip no slot dispensa a rede sem
mudar uma linha de configuração; `assets/plugins/LEIA-ME.txt` descreve o slot e o
diretório entra no inventário como prefixo declarado. `plugins.embarcados` está **vazio**:
nada viaja hoje dentro do bundle como plugin, e o complemento do canal, que já viajou
assim, passou a ser instalado por URL declarada — o zip do slot é o caminho offline dele,
não o padrão.

| Slug | Papel | Origem | Justificativa |
|---|---|---|---|
| `wordpress-seo` | seo | wordpress.org | Responde por Organization, WebSite, WebPage, BreadcrumbList e Article, pelas metas por conteúdo e pelo sitemap. O `site-core` só **estende** o que falta (`Service` e propriedades de entidade), pelos filtros do próprio plugin, sem duplicar nó existente — funcionalidade que o plugin do catálogo cobriria e fosse reimplementada no `site-core` exigiria justificativa escrita. |
| `flamingo` | caixa-de-leads | wordpress.org | Guarda os envios no próprio site. Sem ele, a prova do lead depende de e-mail entregue, que é o elo mais frágil da cadeia. Também é o motivo de a eliminação de lead ter rota própria com journal: eliminar registro por rota genérica de conteúdo já custou 37 registros, com cópia única fora do site. |
| `wp-mcp-ultimate` | canal-mcp-servidor | origem `url`, com `pasta_esperada` declarada | Servidor do canal MCP: rotas tipadas de conteúdo, options, mídia, plugins, usuários, menus e comentários — e **nenhuma** rota de arquivo ou de banco. Instalação obrigatória em todo projeto. |
| `wp-mcp-ultimate-complemento-fator3` | canal-mcp-complemento | origem `url`, com `pasta_esperada` declarada; o slot `assets/plugins/<slug>.zip` tem precedência quando presente | Artefato nosso, instalado como os outros e não embutido no bundle. Acrescenta as doze rotas de arquivo e de banco com as travas do canal: sintaxe de PHP conferida antes de gravar, hash esperado na escrita, backup com restauração e escrita de banco em duas fases com pré-visualização obrigatória. Sem ele, quatro linhas da matriz de alocação não têm via de execução pelo agente. |
| `google-site-kit` | protegido | instalação do cliente | Declarado em `plugins.protegidos`. O deploy **não** o reconfigura: o contrato esperado é verificado e a configuração de medição segue como dependência externa, com responsável nomeado. Se ele emitir requisição, cookie ou tag incompatível com a política de consentimento declarada, o gate de produção fecha BLOCKED. |

### Cadeia de suprimentos: o que o digesto protege e o que ele não protege

Os dois plugins do canal descem de `https://github.com/…/raw/main/….zip` — **ref
mutável**: `main` de hoje não é `main` de amanhã, e o artefato que chega por esse caminho
é o que expõe as rotas `files/*` e `db/*`. Até a 1.0.17 o host era conferido **antes** do
download e `download_url()` seguia o redirecionamento sozinho, sem hash nenhum conferido.
Duas correções, e cada uma vale o que ela vale, nem mais:

1. **O host é revalidado DEPOIS de cada redirecionamento.** Os saltos são seguidos um a
   um, com `redirection => 0`, e o host de cada endereço é conferido contra
   `plugins.origens_url_autorizadas` antes do próximo. O corpo só desce do endereço
   final, que é o único que teve o host conferido. Conferir só a URL declarada deixava a
   lista fechada valendo para um endereço que ninguém baixava. Cadeia que não termina é
   abandonada no teto de saltos, com a cadeia percorrida nomeada.
2. **`sha256` passa a ser DECLARÁVEL na entrada de origem `url`.** O schema o aceita — no
   ramo `origem: "url"` ele era rejeitado por `additionalProperties: false`, e declarar
   um digesto era literalmente impossível.

Os três ramos, e a diferença entre eles é o ponto inteiro:

| Situação | O que acontece | O que isso garante |
|---|---|---|
| `sha256` declarado e batendo | instala | o artefato é o que a configuração nomeia, **inclusive na primeira busca** |
| `sha256` declarado e divergindo | **FALHA** nomeando os dois valores; **nada é instalado** | — |
| `sha256` ausente | o digesto é **medido e fixado** na primeira observação, e a execução seguinte com digesto diferente do fixado é FALHA | defende contra a origem MUDAR embaixo das execuções seguintes; **não** defende a primeira busca |

**A conferência vale só para a origem `url` declarada, e isso é fronteira de contrato.**
Para `origem: "wordpress.org"` ela **não** roda: a URL de lá é por VERSÃO, o artefato muda
de propósito a cada atualização, e fixar o digesto ali faria a próxima versão legítima
reprovar — o oposto de "sempre a última versão da fonte oficial". O schema executa a mesma
fronteira: `sha256` só existe no ramo `url`.

**O limite do terceiro ramo está escrito na própria mensagem do relatório, e não é
maquiado.** Fixar na primeira observação não é verificação de integridade: se o artefato
já veio trocado, é o trocado que ficou fixado. TOFU que se apresenta como verificação é
pior do que nenhuma, porque produz confiança. O ramo existe porque o usuário exige que o
template funcione como produção sem configuração extra, e exigir digesto declarado
quebraria a primeira execução de todo projeto novo — quem quiser a garantia na primeira
busca declara `sha256` na entrada, e aí o teto é o declarado.

`plugins.operacionais` traz **uma** entrada nesta base: `dreamhost-panel-login`, o
atalho de login do painel que a própria hospedagem instala e ativa no provisionamento,
com `responsavel` declarado. Até a 1.0.17 este parágrafo dizia que a lista estava vazia
enquanto a entrada viajava no `config/site.json` do mesmo zip — afirmação de documento
refutada pela configuração ao lado, e é o tipo de achado que `doc.afirmacao_conferida`
passou a acusar. Plugin operacional do cliente entra nessa lista e é classificado no
relatório como externo preservado, nunca removido.

### Versão observada é fato de entrega, não requisito

O relatório de cada execução registra a **versão observada** de cada plugin e do núcleo
no momento em que a execução aconteceu. Esse número é fato de diagnóstico: ele descreve
o que estava instalado, não o que precisa estar. Nenhuma execução aprova ou reprova por
comparação desse número, e nenhum item deste pacote exige uma versão específica de
plugin de terceiro.

Regra que produz o valor, já que ele só existe em tempo de execução: o adaptador lê a
versão instalada no momento da aplicação, grava-a no relatório junto do resultado da
leitura de volta das options daquele plugin, e o leia-me de cada projeto **deriva** do
lock a frase "validado até a versão que o lock registra", nunca "instalado tal versão".

**Estado nesta base: BLOCKED.** O comando único roda contra a árvore do pacote, não
contra um WordPress instalado, então nenhuma versão de plugin de terceiro foi observada.
Declarar um número aqui seria inventá-lo.

### Caminho de reversão de um plugin

A fonte é a mesma da instalação: o WordPress.org mantém as versões anteriores de cada
plugin publicadas e baixáveis. Reverter é instalar de lá a última versão em que a
leitura de volta conferiu — a que o relatório da execução anterior registra pelo nome.
Nunca o ZIP do repositório de artefatos, que serve ao laboratório e ao ambiente
offline, não à produção.

Três limites, e eles vêm juntos, sob pena de a reversão virar o segundo incidente:

1. **O WordPress reverte sozinho só a falha grosseira.** A atualização automática
   desfaz a atualização que produz erro fatal na verificação. Quebra sutil —
   comportamento mudado, chave de option descartada, CSS deslocado — passa por essa
   rede e só aparece na cadência ou no cliente.
2. **Reverter código não reverte dados.** Versão nova que migrou schema ou reescreveu
   options deixa o banco à frente do código, e o downgrade pode encontrar estado que
   não sabe ler. Antes de reverter, o estado gravado por aquele plugin entra no journal;
   se a migração for de mão única, a reversão é da instalação inteira pelo backup, não
   do plugin isolado — e isso se decide com o mecanismo na mão, não durante o incidente.
3. **Reversão é temporária e datada.** Ela congela o site numa versão com a
   vulnerabilidade que a política existe para fechar. Entra no relatório com data,
   motivo e a versão de destino, e o item só fecha quando o upstream corrige e o site
   volta à última. Reversão sem data de volta é a exceção que a política recusou,
   entrando pela porta dos fundos.

Nota de fato, para não prometer o que não existe — e a 1.0.18 corrigiu a metade que
faltava. O complemento do canal **não** vem do WordPress.org, e **o servidor do canal
tampouco**: os dois descem da MESMA URL declarada, e a ressalva anterior nomeava só o
complemento. O caminho dos dois é release nossa, por upload com sobrescrita e
reativação — o instalador desativa ao sobrescrever, e o canal não se autoedita por
desenho.

**Flag ligada e fonte alcançável são fatos diferentes, e agora saem em duas linhas.**
`plugins.autoupdate_conforme_politica` mede o que sempre mediu: a flag está no banco,
lida de volta plugin a plugin. Ela não mede alcance. A política é categórica e continua
como está — **Atualização automática ligada para TODO plugin instalado** —, e a flag a
executa; não porque haja fonte para todos. `plugins.autoupdate_alcance` mede a segunda pergunta e separa
três classes, cada uma nomeada: **sem fonte alcançável** (os dois plugins do canal, por
origem `url`; os artefatos do próprio pacote — tema, `site-core` e o implantador),
**pendente** (origem `wordpress.org` declarada e o plugin operacional da hospedagem — se
o WordPress.org responde por um slug é medição por REDE, e esta linha não a faz, então
sai como pendência nomeada em vez de número inventado) e **alcançável medida**. Enquanto
houver pendência de rede, a linha fecha BLOCKED; sem pendência e com plugin sem fonte,
WARN. `Update URI`, `update_uri` e `site_transient_update_plugins` não aparecem no
pacote, e é por isso que a classe "sem fonte" é o que é.

## Cadência do modo somente-relatório: como pausar e como retomar

A configuração declara `cadencia_relatorio`: periodicidade **mensal**, ou **a cada 10
ajustes**, o que vier primeiro. Cadência sem agendamento é lembrete, e por isso o
agendamento é item de entrega: quem entrega cria o gatilho e nomeia o mecanismo usado —
agendador do host, cron real do servidor ou tarefa do lado do agente.

**Quem escuta o evento é o `site-core`, não o implantador.** Até a 1.0.17 o nome do hook
`f3base_cadencia_relatorio` aparecia UMA vez no pacote inteiro — na variável que o
agendava — e nenhum `add_action` o escutava: o evento disparava, o WP-Cron o reagendava, e
nada acontecia. O ouvinte mora no plugin persistente porque ele é o componente que
sobrevive à autodesativação de quem agendou. O módulo **Cadência do modo somente-relatório**
faz três coisas que o agendamento sozinho não fazia:

1. **Registra as recorrências que o núcleo não tem.** `monthly` não existe no WordPress e
   `quinzenal` também não. Agendar "mensal" caía em `daily` e "quinzenal" caía em `weekly`
   — o dobro da frequência —, as duas em silêncio. O módulo registra `f3base_mensal`
   (trinta dias) e `f3base_quinzenal` (quinze dias); o WP-Cron conta intervalo e não
   calendário, e a aproximação de mês por trinta dias está dita no nome legível.
2. **Executa e registra o que mediu**: última execução, próxima, duração, resultado, erro
   e o atraso do evento sobre o horário previsto. Evento atrasado acima da tolerância
   deixa o módulo DEGRADADO na tela, com o atraso medido.
3. **Conta os ajustes.** `cadencia_relatorio.apos_n_ajustes` é lido de `f3base_cadencia`,
   e cada escrita em option gerenciada conta como um ajuste — carimbo de atividade e
   estado de execução não contam, porque o site mudar porque rodou não é alguém ter
   ajustado alguma coisa. Ao alcançar o número declarado, a execução DISPARA e o contador
   zera. Com o número declarado em zero, nada é contado e o módulo diz na tela que nada
   promete disparar por ali.

Se a recorrência com que o evento está agendado divergir da declarada, o módulo fecha
DEGRADADO **nomeando as duas** — em vez de aceitar a degradação em silêncio.

**O agendamento sai com a recorrência DECLARADA, e a degradação é nomeada.** A etapa
`cadencia` do implantador mapeia `quinzenal` para `f3base_quinzenal` e `mensal` para
`f3base_mensal` — as recorrências que o módulo do `site-core` registra —, e não mais
para `weekly` e `monthly`. Até a 1.0.17 ela mandava `quinzenal` para `weekly`, o DOBRO da
frequência, e `mensal` para `monthly`, que não existe no núcleo e caía para `daily`: as
duas em silêncio. Se a recorrência declarada não existir no agendador no momento do
agendamento — o caso típico é o `site-core` não estar ativo naquela requisição —, o
evento é agendado assim mesmo, para o site não ficar sem cadência, e `cadencia.agendada`
fecha **WARN** dizendo a recorrência declarada, a usada, o que a diferença custa em
frequência e como sair.

`cadencia_relatorio.mecanismo` está **vazio** nesta base, de propósito: o mecanismo
depende da hospedagem e é preenchido pelo projeto que instancia a base. Enquanto
estiver vazio, o item correspondente da entrega fecha BLOCKED, não OK. Esse item tem
nome desde a 1.0.18 e é `cadencia.mecanismo_declarado` — antes dela a frase existia em
dois documentos e nenhuma linha do relatório correspondia a ela: o único item era
`cadencia.agendada`, que mede o WP-Cron e fecha OK porque o agendamento existe mesmo. As
duas afirmações eram verdadeiras sobre coisas diferentes, e a saída foi dar à segunda
pergunta uma linha própria. Ele é **pré-condição declarada**: enquanto estiver em
BLOCKED, a convergência do estado fica pendente — e não segura a autodesativação.

**Pausar.** Desabilite o gatilho no mecanismo nomeado no relatório de entrega — é lá que
está escrito qual dos três é o seu. A pausa entra no relatório com data, motivo e **data
de retomada**; pausa sem data de retomada é a mesma exceção pela porta dos fundos que a
reversão sem data de volta. Enquanto a cadência estiver pausada, a releitura das options
escritas em plugin de terceiro não acontece — e, com atualização automática ligada, esse
é o único lugar onde ela aconteceria depois da entrega.

**Retomar.** Reabilite o gatilho no mesmo mecanismo e **execute o modo somente-relatório
uma vez, imediatamente**, sem esperar a próxima janela. A execução imediata é o que fecha
a lacuna: ela produz o diff de três vias acumulado no período pausado, classificando cada
divergência como incorporada à próxima versão, mantida como conteúdo externo, ou
corrigida. A data da última execução volta ao relatório, e é ela — não a existência do
gatilho — que sustenta qualquer afirmação sobre o estado atual do site.

## Kill switch do canal MCP

O canal é execução remota de código atrás de uma credencial. O desligamento é caminho de
operador e precisa funcionar sem depender do agente.

1. **Interruptor na tela do complemento**, no wp-admin, em Ferramentas. É o caminho de
   primeira mão e não exige acesso a arquivo.
2. **Filtro equivalente no código**, para desligar por `mu-plugin` ou por
   `wp-config.php` quando o wp-admin estiver indisponível.
3. **Revogar a Application Password do usuário dedicado.** Este passo não é opcional:
   desligar as rotas sem revogar a credencial deixa metade da porta aberta, e a
   credencial é o perímetro real.

Duas conferências que precisam acompanhar o desligamento:

- **Canal único.** O complemento é distribuído com identificadores fixos — pasta,
  namespace, diretório de backups e chave de liga-desliga — e nunca prefixado por
  projeto. Uma build prefixada instalada ao lado de uma genérica são, para o WordPress,
  dois plugins, com dois diretórios de backup e **duas** chaves de desligamento: o
  operador desliga o canal e ele continua aberto pelo outro, com a tela dizendo que está
  fechado. A checagem `mcp.canal_unico` acusa mais de um plugin registrando as rotas de
  arquivo, nomeando os dois.
- **Autoteste do canal.** `files/selftest` **é despachado na entrega**, e o resultado
  estruturado vai para o relatório na linha `mcp.autoteste`. Até a 1.0.17 esta frase
  dizia que ele "roda na entrega … com o resultado no relatório" e o pacote inteiro não
  tinha uma única chamada de execução — nem `wp_execute_ability`, nem `rest_do_request`:
  a afirmação existia, o resultado não. Hoje o despacho tenta a Abilities API primeiro e
  o servidor REST interno em seguida, e a via que respondeu sai nomeada. **Autoteste que
  devolve falha REPROVA a entrega**, e **ausência da rota fecha BLOCKED, nunca OK** — não
  medir e medir-e-passar são fatos diferentes. O item que mais importa é a detecção de
  PHP quebrado: se ela estiver inerte, gravar PHP passa a ser perigoso, e é isso que a
  linha diz quando reprova.

  **O que essa linha não prova, e sai declarado:** as duas vias despacham DENTRO do
  processo, com o usuário da requisição já autenticado como administrador, e nenhuma
  passa pela autenticação HTTP. A recusa a uma credencial NÃO autorizada não é
  mensurável daqui, e por isso ela é uma linha própria — `mcp.autoteste_recusa_credencial`
  — em **BLOCKED de fase**, nomeando o que falta: uma requisição HTTP de fora, com uma
  credencial sem a capacidade exigida, e o 401 ou 403 observado na ponta. Forjar um
  usuário sem capacidade e despachar internamente mediria o `permission_callback`, não a
  credencial: seria uma prova fraca com nome de prova negativa.

Consequência do desligamento, declarada antes e não depois: sem canal não há fase de
manutenção por agente. Toda mudança estrutural volta a depender de acesso humano ao
servidor, e o implantador deixa de poder se autodesativar em uma execução futura.

## Mídia embarcada e a justificativa de formato

`assets/` carrega quatro binários e um slot. Os quatro binários são gerados a partir da
paleta declarada no `theme.json` — `inverso`, `primaria` e `base`. Nenhuma cor nova foi
introduzida, e o detector `tema.sem_cor_literal` cobre o SVG inline junto com o resto.

| Arquivo | Papel na configuração | Formato e medida |
|---|---|---|
| `assets/logo.png` | `custom_logo` | PNG 512 × 512, 15 546 bytes, fundo transparente |
| `assets/logo.svg` | `marca_inline` | SVG sem cor literal, 656 bytes: o desenho usa `currentColor` e herda a cor do contexto, com `title` e `aria-label` próprios |
| `assets/favicon.png` | `site_icon` | PNG 512 × 512, 2 790 bytes |
| `assets/social.png` | `og_default_image` | PNG 1200 × 630, 3 272 bytes |

`assets/plugins/` é um slot, não mídia: o `LEIA-ME.txt` diz o que ele é e o diretório
entra no inventário como prefixo declarado, para receber `<slug>.zip` de plugin quando o
projeto quiser instalar sem chamada de rede.

**Por que PNG e não WebP ou AVIF.** O método pede WebP ou AVIF salvo justificativa
escrita no relatório, e aqui a justificativa é de compatibilidade do consumidor, não de
peso. Os papéis em jogo são consumidos por software que não é o navegador do visitante:
o `site_icon` do WordPress gera e serve os tamanhos derivados do ícone, e a imagem padrão
de Open Graph é lida por rastreadores de redes sociais e aplicativos de mensagem. O
suporte a WebP nesses consumidores é inconsistente, e o modo de falha é o pior possível —
ícone ou prévia que simplesmente não aparece, sem erro em lugar nenhum. PNG é o formato
que eles consomem de forma confiável.

**Por que o logo virou PNG, com o vetor preservado.** `custom_logo` exige anexo na
biblioteca de mídia, e o WordPress recusa SVG por padrão — recusa correta, porque SVG é
vetor de XSS, e habilitar o MIME no site seria decisão de segurança que este pacote não
toma. O bitmap assume o papel de anexo; o vetor continua no pacote sob o papel declarado
`marca_inline`, servido pelo tema dentro do próprio markup e nunca enviado para a
biblioteca. As duas decisões, com custo e caminho de reversão, estão em
`MEMORIA-DECISOES.md`, decisão 11.

## Suposições e desvios

Cada item abaixo é um estado declarado deste pacote, com a consequência escrita. Nenhum
deles é omissão.

### Estado da última rodada integral

1. **A rodada integral fecha sem FALHA.** `bash suite/verificar.sh <caminho absoluto>`
   sobre este pacote sai com código 0. **A contagem por estado desta rodada não é digitada
   aqui**: ela é resultado da rodada, e quem a carrega é `suite/rodada.json`, gravado
   pelo selo com o hash do pacote que aquela rodada mediu — foi assim que a contagem escrita
   à mão neste lugar envelheceu calada durante sete releases. O que é estável e vale
   escrever: as checagens em BLOCKED são todas da mesma natureza — pedem WordPress rodando,
   navegador ou tráfego real —, cada linha nomeia a pré-condição que falta, elas continuam
   impedindo a autodesativação, que é o comportamento correto, e não são defeito do pacote.
   A única linha em WARN é `conteudo.demonstrativo`, e ela é o aviso de que este pacote
   ainda é o template: some no passo em que o conteúdo do site novo entra.

### Desvios do documento do método

1.1. **O layout de arquivos do contrato ganhou `ferramentas/` e `TEMPLATE.md`.** O contrato
   descreve a árvore da 1.0.0, e a allow-list EXECUTÁVEL do empacotamento é
   `suite/inventario.tsv` — é ela que aborta o build com o nome do arquivo fora da lista.
   Os cinco arquivos de `ferramentas/` e o `TEMPLATE.md` entraram no inventário com papel
   declarado, como `fontes/` e `dist/` entraram antes deles. O desvio está aqui declarado,
   não omitido: nenhum deles é código que roda no site, e nenhum viaja para dentro do
   WordPress a não ser como parte do bundle.


2. **Fontes de sistema em vez de webfont auto-hospedada.** O `theme.json` declara duas
   pilhas nativas e nenhum `fontFace`, porque `tema.fontes` está vazia e não há binário
   de fonte no pacote. A regra de fonte auto-hospedada continua valendo e o caminho de
   retorno está em `MEMORIA-DECISOES.md`, decisão 8. Custo: o site não tem tipografia
   de marca.
3. **PNG em vez de WebP ou AVIF** para ícone do site, imagem social e logo, pela
   justificativa de compatibilidade da seção de mídia. Decisão 11.
4. **Duas exceções de `wp:html` no tema**, declaradas em `tema.wp_html_excecoes` com
   motivo: o link de pular para o conteúdo e o botão do controle de consentimento.
   Navegação nunca. O conteúdo editorial não tem nenhuma.
5. **Nenhum `core/image` no conteúdo editorial.** Os quatro itens de `midia` servem a
   `custom_logo`, `marca_inline`, `site_icon` e imagem padrão de Open Graph — papéis de
   configuração, não blocos de conteúdo. Imagem dentro de conteúdo exige o identificador
   do anexo injetado no bloco em tempo de deploy, e esse identificador muda por
   instalação: ele não pode viver no arquivo. Os blocos `core/cover` do conteúdo usam
   apenas sobreposição de cor de preset, sem imagem de fundo.

### Chaves de configuração e o que cada uma implica

6. `ambiente.url_canonica` e `ambiente.dominios_autorizados` vazios **não seguram nada**.
   A lista de domínios deixou de ser condição de `blog_public` na 1.0.12 e virou
   CROSS-CHECK: preenchida, um host fora dela sai em WARN nomeando o host observado e a
   lista declarada, e a indexação acontece assim mesmo; vazia, não é achado. O site nasce
   INDEXÁVEL e o implantador só segura a indexação quando MEDE uma guarda — ambiente do
   núcleo declarado como não-produção, `home_url()` em HTTP puro, `ambiente.tipo`
   diferente de `producao`, ou host casando com sufixo de `ambiente.dominios_de_previa`.
   Guarda que dispara fecha WARN nomeando a si mesma, o valor observado e como forçar.
7. `ambiente.permalinks_decisao` é `aplicar-e-cobrir`, o padrão desde a 1.0.17: ele
   **aplica** a estrutura declarada **e cobre** com 301 o caminho antigo de todo
   conteúdo publicado que muda de endereço — gerenciado por este pacote ou não. O par
   entra na união declarada de `f3base_redirects` com origem própria, pelo mesmo
   produtor único das outras fontes, e o par cujo caminho **não** muda continua sendo
   descartado, porque redirecionar um endereço para ele mesmo é laço: `/sample-page/`
   sob `/%postname%/` é exatamente esse caso. O relatório **nomeia** cada URL coberta,
   uma a uma, em vez de contá-las.

   Os outros três valores continuam declaráveis e com o comportamento de sempre.
   `aplicar-se-seguro` MEDE antes de decidir e recusa a troca diante de publicado NÃO
   gerenciado com URL de caminho, fechando **BLOCKED sem escrita** e nomeando cada
   objeto em risco com id, tipo, slug e caminho; `aplicar-declarada` aplica sempre,
   **sem** cobrir a URL de terceiro, e registra o risco assumido; `manter-existente`
   nunca aplica.

   O que mudou de fundo na 1.0.17 foi a reserva por trás do padrão antigo — "este
   pacote não escreve redirect para conteúdo alheio". Ela é boa para escrita
   **destrutiva** e estava sendo aplicada por analogia a uma escrita que não destrói
   nada: o redirect é **aditivo e reversível** — não altera o objeto, não apaga nada e
   some quando a option some. O preço da recusa era entregar o site com a estrutura de
   permalink que ninguém escolheu, por causa de duas páginas que o próprio WordPress
   cria.
8. `conteudo.exemplo_do_wordpress` é `lixeira`, ligado por padrão, porque a regra deste
   pacote é **nascer pronto para produção**. `Hello world!` e `Sample Page` não são
   conteúdo de ninguém: são o que `wp_install_defaults()` insere em toda instalação, e
   deixá-los publicados num site entregue põe `Sample Page` no sitemap, na seleção do
   `llms.txt` e na busca.

   O que decide **não é o slug** — slug igual não prova nada, e é a mesma regra que
   governa a adoção de objeto. O objeto só é conteúdo de exemplo se **ainda for o que o
   WordPress criou**, e isso são duas provas conjuntas: **identidade** contra o que
   `wp_install_defaults()` produz (título e conteúdo idênticos ao que o núcleo
   escreveria agora — o esperado sai das mesmas chamadas de tradução que o instalador
   usa, no locale da instalação) e **ninguém editou** (`post_modified_gmt` igual a
   `post_date_gmt`, que é como o instalador os grava). Objeto gerenciado por este pacote
   e objeto em uso como `page_on_front`, `page_for_posts` ou `wp_page_for_privacy_policy`
   também ficam.

   O que casa vai para a **lixeira**, nunca para exclusão definitiva: é reversível com um
   clique em Restaurar, entra no journal com a operação inversa, e o relatório **nomeia**
   o objeto e imprime **o discriminante que decidiu** — dizer que removeu não basta.
   Quem reescreveu o `Hello world!` para publicar um texto de verdade deixou de ter
   conteúdo de exemplo, e esse objeto é **intocável**: fica publicado, sai relatado em
   `conteudo.nao_gerenciado_publicado` e é coberto pelo 301 se o caminho dele mudar.
   Declarar `manter` desliga a etapa inteira.

   A etapa roda **antes** da troca de estrutura de permalinks, e a ordem é decisão: o
   que sai daqui deixa de ser publicado e não ganha um 301 para um endereço que passaria
   a 404.
9. `contato.whatsapp_e164` vazio: o `site-core` não promove o `href` do CTA e o botão
   continua apontando para a página de contato. Nenhum número falso aparece no HTML. O
   veredito é BLOCKED nomeando a chave, nunca FALHA — a chave nasce vazia por desenho.
10. `contato.email_leads` vazio, coerente com o regime de e-mail declarado inativo.
11. `contato.controlador` com `razao_social`, `documento` ou `endereco` vazios: a página
    da política de privacidade fica em `draft` por uma **guarda medida**, nunca por
    decisão calada do pacote. A intenção declarada dela é `publish`, como a de toda
    página daqui; o produtor único de status a rebaixa enquanto faltar qualquer um dos
    três, `privacidade.controlador_identificado` fecha BLOCKED **nomeando quais faltam**,
    e a página não entra no `llms.txt` nem no link de privacidade do rodapé. Preencha os
    três e execute de novo: ela publica sozinha na execução seguinte, sem passo manual —
    não há botão a apertar nem status a mudar à mão. O texto da página identifica o
    controlador com esses valores, e política publicada sem dizer quem é o controlador é
    notificação deficiente na face do art. 9º da LGPD; razão social, documento e endereço
    são dado que só o operador tem, e o pacote não os inventa.
12. `contato.controlador.encarregado` vazio é estado normal e **não** segura a
    publicação: o texto da política passa a dizer que o canal de contato do site recebe
    os pedidos do titular, em vez de nomear alguém que este pacote não conhece.
    Preenchido, a redação nominal do art. 41 entra no lugar dela. As duas redações moram
    no arquivo de conteúdo, em blocos que se excluem pela condição declarada no atributo.
13. `paginas[*].papel` declara o PAPEL ESTRUTURAL de uma página, e hoje há um valor:
    `politica-privacidade`. É dele — e só dele — que sai a resposta a "qual página é a
    política": é ela que o núcleo grava em `wp_page_for_privacy_policy` e é ela que
    `privacidade.controlador_identificado` mede. Até a 1.0.13 essa identidade era lida de
    `seo.llms_selecao.politica_privacidade`, e o efeito era este: desligar `bots_ia.llms_txt`
    e limpar a seleção — operação legítima, que o nome da chave convida a fazer — parava
    de gravar a option do núcleo E derrubava a checagem legal em "condição de
    aplicabilidade falsa", com o relatório verde. `seo.llms_selecao.incluir_politica_privacidade`
    é hoje um booleano de INCLUSÃO: ligado, a política entra na seleção do `llms.txt`;
    desligado, sai da seleção e nada mais muda.
14. `tracking.linkedin_partner_id` vazio: nenhuma tag do LinkedIn é emitida. O slot
    nasce inerte por desenho, e ausência de ID nunca vira placeholder.
15. `cadencia_relatorio.mecanismo` vazio: ver a seção da cadência acima. O item de
    entrega é `cadencia.mecanismo_declarado`, e ele fecha **BLOCKED** enquanto a chave
    estiver vazia — a linha existe desde a 1.0.18, e até ela a frase estava em dois
    documentos sem item nenhum que correspondesse. É **pré-condição declarada**: deixa a
    convergência do estado pendente e **não** segura a autodesativação. O OUVINTE do
    evento, esse, existe e é do `site-core`: o que continua vazio é o NOME do mecanismo
    externo, não o gatilho.
15a. `cabecalhos.origem_confiavel.cabecalho` vazio: o rate limit do endpoint de leads
    conta por `REMOTE_ADDR`. Atrás de CDN ou proxy reverso, `REMOTE_ADDR` é o mesmo para
    todo mundo e os 20 registros por janela passam a valer para o proxy inteiro — preço
    declarado, e a saída é preencher o nome do cabeçalho e os saltos confiáveis. Aceitar
    cabeçalho de proxy sem declaração seria pior: seria o visitante escolhendo em que
    balde ele conta.
16. `plugins.configuracao_servidor_mcp` vazio: os nomes das chaves de configuração do
    servidor MCP são fato do fornecedor, e este pacote não os inventa. Enquanto o mapa
    estiver vazio, a unidade do canal reporta que não há configuração declarada a aplicar
    — e continua conferindo as rotas.
17. `plugins.supressao_onboarding` traz hoje **uma** entrada, para `wordpress-seo`. O
    mapa é declarado, não deduzido: quem descobre a chave de option que suprime o
    assistente de um plugin é o operador, e é ele quem a declara. O mapa grava
    `option.chave = false`, e **entrada que não seja uma option grava lixo** na
    instalação do cliente.

    Por isso `wp-mcp-ultimate` **não** tem entrada aqui, e a ausência é resultado de
    medição, não de esquecimento. O assistente dele é registrado em `admin_init` e
    sequestra a primeira requisição administrativa depois da ativação — é o que aparece
    em `lote.sequestro_por_terceiro` a cada execução. A 1.0.17 leu o artefato da origem
    declarada e mediu o mecanismo: ele **não é uma option**. Está em
    `includes/Plugin.php`, linha 87, `if ( ! get_transient( 'wp_mcp_ultimate_activated' ) )`,
    e o transiente é posto em `wp-mcp-ultimate.php`, linha 38, dentro do
    `register_activation_hook`, com TTL de 30 segundos — e apagado por
    `delete_transient()` na linha 90 do mesmo `Plugin.php`, na primeira requisição que o
    encontra. Não há `apply_filters` nesse caminho. Um transiente com TTL de trinta
    segundos, consumido e apagado no primeiro uso, não se desarma por chave de
    configuração; declarar uma entrada aqui gravaria uma option que ninguém lê. O
    sequestro continua acontecendo uma vez, o cliente repete a unidade e segue — é
    observação, nunca bloqueio.
18. `plugins.backups_preservados` é 2: por slug, as cópias preservadas acima desse teto
    saem do disco na unidade de poda, **nomeadas**, da mais antiga para a mais nova. O
    teto vem da configuração e nunca de número escrito no código.
19. `plugins.origens_url_autorizadas` traz `github.com` e `raw.githubusercontent.com`.
    Host fora dessa lista fechada não é baixado: origem `url` com host livre seria
    execução remota de código com outro nome.
20. `release.anterior_suportada` é uma lista FECHADA de origens aceitas além da
    instalação limpa, cada uma com a própria `determinacao`: `medida-no-site` quando a
    release foi observada rodando num site, `entregue-nao-confirmada` quando ela foi
    produzida e nunca chegou a um. A distinção é sobre o SITE, não sobre o repositório:
    release entregue não é release aplicada. Quantas entradas existem hoje está no
    carimbo gerado no topo deste arquivo — aqui não se digita contagem. Origem fora da
    lista termina em BLOCKED, sem mutação.
21. `seo.organizacao.same_as` vazio, `seo.robots_extra` vazio, `redirects` vazio,
    `plugins.embarcados` vazio e `tema.fragmentos_sincronizados` vazio: lista vazia é
    estado válido e declarado, não seção esquecida. Fragmento sincronizado vazio é o
    padrão do método. `plugins.operacionais` **não** está nesta lista, e a correção é da
    1.0.18: ele tem uma entrada (`dreamhost-panel-login`), e afirmar aqui que estava
    vazio era o documento contradizendo o `config/site.json` que viaja no mesmo zip.

### O que foi medido e o que não foi

22. **Medido nesta base:** o piso dos detectores — cada um provando acusar o defeito
    plantado e calar sobre o correto, nos dois ramos. E o contraste, recalculado pela
    checagem `a11y` a partir da paleta do `theme.json`, pela fórmula de luminância
    relativa da WCAG, sobre os pares de texto e fundo EM USO, todos acima do piso AA.
    As contagens dos dois não são digitadas aqui: a de detectores com piso está no
    carimbo gerado no topo, e a de pares de contraste sai na linha `a11y.contraste` da
    rodada, junto com o número que ela mediu.
23. **Não medido: orçamento de página.** `orcamento_pagina` declara 100 kB de CSS, 50 kB
    de JavaScript próprio, 1024 kB de peso total, 30 requisições e 1500 nós de DOM. São
    limites declarados; o consumo real é medido na entrega, num site servindo páginas, e
    `orcamento.pagina` fecha BLOCKED dizendo exatamente isso.
24. **Não medido: Core Web Vitals.** São medidos em campo, sobre tráfego real;
    `desempenho.core_web_vitals` fecha BLOCKED com a pré-condição nomeada.
25. **Não medido: versões observadas de núcleo, PHP e plugins de terceiro**, pelo motivo
    da seção de plugins — o comando único roda contra a árvore do pacote, não contra uma
    instalação. `plugins.autoupdate_conforme_politica` e
    `plugins.adaptador_leitura_de_volta` fecham BLOCKED com evidência `leitura-de-volta`.
26. **Conferência do preset no navegador não executada.** As razões de contraste são
    calculadas da paleta; a checagem que lê o valor computado da custom property no
    navegador exige ambiente com navegador e fecha BLOCKED com a pré-condição nomeada.

### Suposições sobre o ambiente do operador

27. O operador tem acesso ao wp-admin com as capacidades listadas em pré-requisitos, e a
    instalação permite envio de plugin por arquivo.
28. A hospedagem permite saída HTTPS para o WordPress.org e para os hosts de
    `plugins.origens_url_autorizadas`. Sem ela, a instalação fecha BLOCKED e os caminhos
    de contingência declarados são o slot `assets/plugins/<slug>.zip` e a instalação
    manual pelo wp-admin.
29. O agendador do WordPress é o mecanismo padrão da rotina de retenção. Ele não garante
    horário: a rotina mede o próprio atraso e se recupera no carregamento seguinte.
    Obrigação temporal relevante pede agendador real do servidor, e essa troca é decisão
    de projeto.

## O que quatro execuções em produção ensinaram

Leia esta seção antes de mexer no pacote. Cada linha é um defeito que custou uma
execução real, no formato **sintoma → causa medida → correção**. Nenhum deles foi
deduzido: todos apareceram em site de produção, e a última execução foi medida pelo
próprio canal MCP.

### Primeira execução — a 1.0.0 parou no lote do canal MCP

1. **Sintoma:** o canal MCP fechou BLOCKED e a execução parou ali. → **Causa medida:**
   `wp-mcp-ultimate` e o complemento não existem no WordPress.org, e a única origem
   prevista era ela. → **Correção:** origem `url` na entrada do plugin, com o host
   conferido contra a lista fechada `plugins.origens_url_autorizadas`, e precedência
   `assets/plugins/<slug>.zip` → URL declarada → WordPress.org.
2. **Sintoma:** plugin instalado e ativação falhando. → **Causa medida:** zip de
   código-fonte de repositório extrai como `<repo>-main`, e ativar pelo slug procurava
   em outro diretório. → **Correção:** a pasta criada é lida do resultado do instalador
   e reconciliada com a `pasta_esperada` declarada, antes da ativação.
3. **Sintoma:** um lote inteiro voltou como página do wp-admin em vez de resposta.
   → **Causa medida:** o assistente de boas-vindas do plugin de SEO registra o
   redirecionamento em `admin_init`, que roda antes do nosso handler; a supressão estava
   numa etapa adiante e chegava tarde. → **Correção:** a supressão passou para a
   ativação, por mapa declarado em `plugins.supressao_onboarding`, e o cliente distingue
   sequestro por terceiro de erro fatal e de falha de rede — repetindo a unidade uma vez
   em vez de perdê-la.
4. **Sintoma:** a mesma linha BLOCKED impressa cinco vezes no relatório. → **Causa
   medida:** unidade bloqueada era reexecutada a cada passagem do orquestrador.
   → **Correção:** BLOCKED é registrado uma vez e a unidade não roda de novo; a
   interrupção nomeia as etapas que ficaram sem executar.

### Segunda execução — instalou e ativou pelo canal, e mostrou cinco defeitos

5. **Sintoma:** "The plugin does not have a valid header.", reproduzindo sempre no fluxo
   *upload → ativar pela tela de instalação*, e nunca pela lista de plugins. → **Causa
   medida:** `get_plugins( '/implantador-base' )` varre a raiz do plugin **e um nível de
   subdiretório**, e o pacote tinha dois arquivos com `Plugin Name:` nesse alcance —
   `implantador-base.php` e `site-core/f3base-site-core.php`. A varredura ordena por
   **Name**, "F3 Base Site Core" vem antes, `Plugin_Upgrader::plugin_info()` devolve o
   primeiro, e era esse caminho de dois níveis que o link "Ativar plugin" carregava;
   `validate_plugin()` só enxerga um nível a partir de `wp-content/plugins/` e devolve
   exatamente aquela mensagem. → **Correção:** as fontes saíram do alcance da varredura
   para `fontes/tema/` e `fontes/site-core/`, e o detector
   `pacote.sem_cabecalho_de_plugin_aninhado` reprova qualquer pacote que volte a ter
   cabeçalho de plugin a um nível da raiz, ou que não tenha exatamente um na raiz.
6. **Sintoma:** o logo não entrava na biblioteca de mídia e `custom_logo` ficava sem
   anexo. → **Causa medida:** o WordPress recusa SVG por padrão, e a recusa está certa —
   SVG é vetor de XSS, e habilitar o MIME seria decisão de segurança que este pacote não
   toma. → **Correção:** `assets/logo.png` assume o papel `custom_logo`;
   `assets/logo.svg` continua no pacote com o papel declarado `marca_inline`, servido
   pelo tema no próprio markup e nunca enviado para a biblioteca.
7. **Sintoma:** `contato.whatsapp_e164` vazia saía FALHA e o relatório parecia acusar
   defeito do pacote. → **Causa medida:** a chave nasce vazia **por desenho** — é
   pré-condição que o projeto preenche. → **Correção:** chave declarada e vazia fecha
   **BLOCKED** nomeando a chave a preencher; chave preenchida com valor que o regime não
   aceita continua **FALHA**. Os dois ramos são exercitados em
   `formulario.veredito_destino`.
8. **Sintoma:** `f3base-site-core-f3base-anterior-1788152131` listado entre os plugins
   com atualização automática. → **Causa medida:** a troca controlada deixava a versão
   anterior em `wp-content/plugins/<nome>-f3base-anterior-<ts>`, e o WordPress a
   enxergava como plugin. → **Correção:** o backup passou a ter ponto na frente
   (`.f3base-anterior-<slug>-<ts>`), porque `get_plugins()` pula tudo que começa com
   ponto; a etapa de atualização automática ignora diretório com ponto na frente
   explicitamente e diz no relatório quantos ignorou.
9. **Sintoma:** sequestro de requisição de novo, agora vindo do servidor MCP; a
   repetição da unidade funcionou e a execução seguiu. → **Causa medida:** o mecanismo
   de repetição está certo, mas a ida e volta se repete a cada execução enquanto o
   assistente daquele plugin não for suprimido. → **Correção:** quando a repetição tem
   sucesso, o relatório registra WARN nomeando o plugin e dizendo que uma entrada em
   `plugins.supressao_onboarding` evitaria a ida e volta. É observação, não gate: a
   chave de option do plugin não é inventada aqui.

### Terceira execução — a dependência grossa demais

10. **Sintoma:** a tela do complemento dizia "Servidor MCP não detectado" e não havia
    nenhuma evidência do nosso lado; `mcp.canal_configurado`, a única linha que
    responderia, não rodou. → **Causa medida:** o orquestrador abortava, depois de um
    BLOCKED, **tudo que vinha depois** — dependência por POSIÇÃO. `formularios` fechou
    BLOCKED (destino do WhatsApp vazio, correto e esperado) e derrubou `cadencia`,
    `entrega` e `encerramento`, nenhuma das quais depende do destino de um formulário.
    → **Correção:** o grafo de dependências passou a ser declarado por unidade em
    `F3Base_Imp_Plano`, e `mcp`, `entrega` e `encerramento` declaram lista vazia de
    propósito: unidade que diagnostica não pode ser suspensa pelo que ela diagnostica.
    `estatica.plano_dependencias` reprova dependência para grupo inexistente, autoloop e
    ciclo.
11. **Sintoma:** dois "F3 Base Site Core 1.0.0" na lista de plugins, com a mesma
    descrição, um com "Desativar" e outro com "Ativar | Excluir" — lido pelo usuário
    como uma substituição que não aconteceu. → **Causa medida:** a correção do ponto
    vale para o backup novo; o diretório criado **antes** dela continuava visível.
    → **Correção:** unidade de migração que oculta os órfãos anteriores, com quatro
    regras — propriedade provada por `Plugin Name:` que bata com um artefato deste
    pacote, diretório ativo nunca renomeado (sai WARN), nunca apaga, e idempotente por
    construção, emitindo nos dois ramos.
12. **Sintoma:** três cartões lado a lado com fundos de alturas diferentes e a régua
    inferior irregular. → **Causa medida:** `.wp-block-columns` é flex e a coluna já
    estica; o que não estica é o Group do cartão dentro dela, que é bloco de fluxo e
    fica alto o quanto o texto pedir. O alinhamento vertical do bloco Columns move o
    conteúdo, não faz o filho crescer. → **Correção:** `height: 100%` escopado em
    `.wp-block-column > .f3base-cartao`, no `style.css` do tema, com o motivo escrito ao
    lado — e inerte no móvel, onde o núcleo empilha em uma coluna.

### Quarta execução — o site medido pelo canal, e as quatro correções da 1.0.6

13. **Sintoma:** o mesmo relatório dizendo, na linha 14, que as 12 rotas estão
    registradas e há servidor MCP ativo expondo-as (OK), e na linha 41 que o canal não
    está exposto (FALHA). → **Causa medida:** não era o site oscilando, eram **duas
    implementações do mesmo veredito** — a unidade `mcp` media pelas habilidades
    registradas (Abilities API mais rota REST) e o encerramento recalculava por conta
    própria a partir da checagem antiga, que só enxerga rota REST. → **Correção:** uma
    fonte de verdade por veredito de gate: a unidade `mcp` é o único ponto que deriva os
    dois vereditos de canal, grava-os no registro da execução, e a entrega e o
    encerramento **leem** em vez de recalcular. Sem registro, o estado é BLOCKED dizendo
    que a unidade não rodou — nunca um veredito inventado no lugar. `mcp.canal_exposto`
    é rótulo próprio, porque **rota registrada** e **rota exposta por MCP** são fatos
    diferentes, e o estado do meio precisa sair com o nome dele. O detector
    `estatica.gate_fonte_unica` impede o segundo derivador.
14. **Sintoma:** a home publicada com o slug errado. → **Causa medida:** sem `post_name`
    declarado o núcleo deriva o slug do título, e o quarto argumento de
    `media_handle_sideload()` faltava — três itens de mídia com o mesmo `alt` produziam
    `metodo-f3`, `metodo-f3-2` e `metodo-f3-3`, e um deles tirava o slug da home;
    `wp_unique_post_slug()` consulta `post_type IN ('page','attachment')` para tipo
    hierárquico e desambigua em silêncio. → **Correção:** slug declarado obrigatório em
    toda entrada de `paginas` e `posts` (a home passou a `inicio`), conferido por
    `config.slug_declarado` com piso dos dois lados; anexo gerenciado recebe slug
    determinístico derivado da referência lógica, o slug anterior é liberado antes do
    sideload e fica gravado em `_f3base_old_slug` para o `site-core` redirecionar.
15. **Sintoma:** o rodapé imprimia `FALHA: 7`, o encerramento imprimia `(5 FALHA, 9
    BLOCKED)` e a tela mostrava 2 linhas com FALHA. → **Causa medida:** três números
    para a mesma palavra, medidos em escopos diferentes e nenhum deles declarado.
    → **Correção:** contadores por escopo nomeado — checagens e unidades contam
    separado, cada bloco nomeia o escopo que resume, e nenhum estado aparece contado
    duas vezes sob a mesma palavra.
16. **Sintoma:** crescimento sem teto no disco — as cópias preservadas de cada troca de
    diretório se acumulando execução após execução. → **Causa medida:** a troca preserva
    a versão anterior por desenho e nada removia as antigas. → **Correção:** unidade de
    poda declarada, com o teto por slug vindo de `plugins.backups_preservados` (hoje 2)
    e nunca de número escrito no código; o que sai do disco sai **nomeado**, da mais
    antiga para a mais nova, e a operação entra no journal.
17. **Sintoma:** o segundo crescimento sem teto — a troca de diretório sendo executada
    em toda execução, mesmo sem nada para trocar. → **Causa medida:** origem por URL não
    anuncia versão, então todo plugin de origem `url` caía no ramo "versão não
    anunciada" e a troca era refeita. → **Correção:** a versão é lida do cabeçalho
    **dentro** do artefato já baixado, e a troca é **pulada** quando o artefato é
    idêntico ao instalado.
18. **Sintoma:** o site entregue com `Sample Page` e `Hello world!` ainda publicados, e
    ninguém dizendo nada. → **Causa medida:** o pacote não os gerencia — não têm
    `_f3base_managed_id`, não constam de `paginas` nem de `posts` — e por isso eram
    simplesmente ignorados. → **Correção, em duas etapas.** A 1.0.10 pôs um WARN
    nomeando o conteúdo publicado que veio da instalação limpa, sem tocar em nada. A
    1.0.17 abriu uma porta estreita: `conteudo.exemplo_do_wordpress` manda para a
    **lixeira** o que **ainda é** o que `wp_install_defaults()` criou, e o critério é
    DISCRIMINANTE, jamais slug — título e conteúdo idênticos ao que o núcleo escreveria
    agora, e `post_modified_gmt` sem avançar em relação a `post_date_gmt`. Quem
    reescreveu o `Hello world!` para publicar um texto de verdade deixou de ter
    conteúdo de exemplo, e esse objeto é **intocável**. O relatório nomeia cada objeto e
    imprime o discriminante que decidiu. O que a etapa não tocar continua saindo em
    WARN, nunca FALHA: o site não está defeituoso, está com uma decisão em aberto.

### O padrão que se repete nas quatro

Onze dos dezoito defeitos acima têm a mesma forma: **o pacote acreditou em algo que não
mediu**. Origem que existia só no WordPress.org, pasta deduzida do slug, veredito
recalculado em dois lugares, slug derivado do título, versão presumida do artefato. Em
todos, a correção foi a mesma na estrutura — ler o fato de onde ele mora, uma vez, e
gravar o que se leu. É a regra do artefato sobre o registro, cobrada em produção.
