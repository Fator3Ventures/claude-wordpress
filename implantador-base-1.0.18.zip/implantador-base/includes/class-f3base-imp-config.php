<?php
/**
 * Leitura e validação do arquivo único de configuração.
 *
 * Duas regras duras moram aqui:
 *
 * 1. **Leitura por caminho absoluto com padrão explícito.** Não existe helper que
 *    prefixe uma seção e devolva `true` para chave ausente. A armadilha medida foi
 *    exatamente essa: o relatório acusou o HSTS como "ligado na configuração" com
 *    ele desligado no arquivo, porque a leitura procurava a chave dentro de outra
 *    seção e o padrão permissivo respondeu por ela. `obter()` exige o caminho
 *    inteiro e o padrão, sempre — não há valor default no parâmetro.
 * 2. **Toda chave lida fica registrada.** `obter()` anota o caminho normalizado
 *    (índices numéricos viram `*`), e `chaves_declaradas()` achata o arquivo. O
 *    cruzamento das duas listas é o detector GERAL de chave sem consumidor — sem
 *    recorte por seção, porque cruzamento por prefixo de uma seção cega o resto.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Configuração validada por schema.
 */
final class F3Base_Imp_Config {

	/**
	 * Caminho relativo do arquivo de configuração.
	 */
	public const ARQUIVO = 'config/site.json';

	/**
	 * Caminho relativo do schema.
	 */
	public const SCHEMA = 'config/site.schema.json';

	/**
	 * Configuração decodificada.
	 *
	 * @var array<string,mixed>|null
	 */
	private static ?array $dados = null;

	/**
	 * Erros de carga e de validação, na ordem em que apareceram.
	 *
	 * @var string[]
	 */
	private static array $erros = array();

	/**
	 * Caminhos normalizados efetivamente lidos nesta execução.
	 *
	 * @var array<string,int>
	 */
	private static array $lidas = array();

	/**
	 * Conteúdo bruto do arquivo, para o hash de configuração.
	 *
	 * @var string
	 */
	private static string $bruto = '';

	/**
	 * Carrega e valida a configuração. Idempotente por requisição.
	 *
	 * @return bool Verdadeiro quando o arquivo carregou E validou.
	 */
	public static function carregar(): bool {
		if ( null !== self::$dados ) {
			return array() === self::$erros;
		}

		self::$dados = array();
		self::$erros = array();

		$caminho = f3base_imp_caminho( self::ARQUIVO );

		if ( '' === $caminho || ! is_readable( $caminho ) ) {
			self::$erros[] = sprintf(
				/* translators: %s: caminho relativo do arquivo de configuração. */
				__( 'Arquivo de configuração ausente ou ilegível: %s', 'f3base' ),
				self::ARQUIVO
			);

			return false;
		}

		$bruto = file_get_contents( $caminho ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote, sem rede.

		if ( ! is_string( $bruto ) ) {
			self::$erros[] = sprintf(
				/* translators: %s: caminho relativo do arquivo de configuração. */
				__( 'Falha ao ler o arquivo de configuração: %s', 'f3base' ),
				self::ARQUIVO
			);

			return false;
		}

		self::$bruto = $bruto;

		$decodificado = json_decode( $bruto, true );

		if ( ! is_array( $decodificado ) ) {
			self::$erros[] = sprintf(
				/* translators: 1: caminho do arquivo, 2: mensagem do decodificador. */
				__( 'JSON inválido em %1$s: %2$s', 'f3base' ),
				self::ARQUIVO,
				json_last_error_msg()
			);

			return false;
		}

		self::$dados = $decodificado;

		foreach ( self::validar( $decodificado ) as $erro ) {
			self::$erros[] = $erro;
		}

		return array() === self::$erros;
	}

	/**
	 * Erros de carga e validação.
	 *
	 * @return string[]
	 */
	public static function erros(): array {
		self::carregar();

		return self::$erros;
	}

	/**
	 * Hash da configuração — identidade usada pelo checkpoint e pela retomada.
	 *
	 * @return string
	 */
	public static function hash(): string {
		self::carregar();

		return hash( 'sha256', self::$bruto );
	}

	/**
	 * Lê um valor pelo CAMINHO ABSOLUTO, com padrão explícito.
	 *
	 * @param string $caminho Caminho absoluto separado por ponto, ex.: `cabecalhos.hsts`.
	 * @param mixed  $padrao  Valor devolvido quando o caminho não existe. Obrigatório.
	 * @return mixed
	 */
	public static function obter( string $caminho, $padrao ) {
		self::carregar();
		self::anotar( $caminho );

		$atual = self::$dados;

		foreach ( self::segmentos( $caminho ) as $segmento ) {
			if ( ! is_array( $atual ) || ! array_key_exists( $segmento, $atual ) ) {
				return $padrao;
			}

			$atual = $atual[ $segmento ];
		}

		return $atual;
	}

	/**
	 * O caminho existe no arquivo?
	 *
	 * Perguntar pela existência é diferente de ler com padrão: quem precisa
	 * distinguir "ausente" de "declarado com o valor do padrão" usa isto.
	 *
	 * @param string $caminho Caminho absoluto.
	 * @return bool
	 */
	public static function existe( string $caminho ): bool {
		self::carregar();
		self::anotar( $caminho );

		$atual = self::$dados;

		foreach ( self::segmentos( $caminho ) as $segmento ) {
			if ( ! is_array( $atual ) || ! array_key_exists( $segmento, $atual ) ) {
				return false;
			}

			$atual = $atual[ $segmento ];
		}

		return true;
	}

	/**
	 * Lista declarada em um caminho, sempre como array de índices inteiros.
	 *
	 * @param string $caminho Caminho absoluto de uma lista.
	 * @return array<int,mixed>
	 */
	public static function lista( string $caminho ): array {
		$valor = self::obter( $caminho, array() );

		return is_array( $valor ) ? array_values( $valor ) : array();
	}

	/**
	 * Todas as chaves declaradas no arquivo, na forma normalizada.
	 *
	 * @return string[] Caminhos com `*` no lugar de índice numérico, ordenados.
	 */
	public static function chaves_declaradas(): array {
		self::carregar();

		$saida = array();
		self::achatar( self::$dados, '', $saida );

		$chaves = array_keys( $saida );
		sort( $chaves );

		return $chaves;
	}

	/**
	 * Caminhos efetivamente lidos nesta execução.
	 *
	 * @return string[] Ordenados.
	 */
	public static function chaves_lidas(): array {
		$chaves = array_keys( self::$lidas );
		sort( $chaves );

		return $chaves;
	}

	/**
	 * Acumula caminhos lidos em requisições anteriores.
	 *
	 * A execução avança em lotes, e cada lote é uma requisição PHP nova: sem
	 * acumular, o cruzamento de consumidores mediria só o último lote e acusaria
	 * como órfã toda chave lida nos anteriores — um detector que reprova o
	 * pacote correto é tão inútil quanto o que aprova o errado.
	 *
	 * @param string[] $caminhos Caminhos já lidos.
	 * @return void
	 */
	public static function acumular( array $caminhos ): void {
		foreach ( $caminhos as $caminho ) {
			$caminho = (string) $caminho;

			if ( '' === $caminho ) {
				continue;
			}

			self::$lidas[ $caminho ] = ( self::$lidas[ $caminho ] ?? 0 ) + 1;
		}
	}

	/**
	 * Chaves declaradas que nenhuma linha de código leu nesta execução.
	 *
	 * Detector geral, sem recorte por seção — inclusive `consumidores_declarados`,
	 * que é uma chave como as outras e por isso entra na varredura.
	 *
	 * @return string[]
	 */
	public static function chaves_sem_consumidor(): array {
		$declaradas = self::chaves_declaradas();
		$lidas      = self::$lidas;
		$orfas      = array();

		foreach ( $declaradas as $chave ) {
			if ( isset( $lidas[ $chave ] ) ) {
				continue;
			}

			/*
			 * Duas formas de cobertura, e nenhuma delas cega o detector:
			 *
			 * - Ler o PAI cobre o filho: quem lê `navegacao.itens` consome cada
			 *   `navegacao.itens.*.rotulo` que iterar.
			 * - Ler um FILHO cobre o contêiner: `ambiente` é um nó de estrutura,
			 *   e quem lê `ambiente.tipo` provou que a seção tem consumidor.
			 *   Sem esta linha, toda seção do arquivo apareceria como órfã e o
			 *   detector reprovaria o pacote correto — que treina o leitor a
			 *   ignorar a lista exatamente como o falso OK treina a ignorar o
			 *   verde. Cada FOLHA continua conferida por si, então o contêiner
			 *   coberto não esconde nenhuma chave sem leitor.
			 */
			$coberta = false;

			foreach ( $lidas as $lida => $quantas ) {
				unset( $quantas );

				if ( str_starts_with( $chave, $lida . '.' ) || str_starts_with( $lida, $chave . '.' ) ) {
					$coberta = true;
					break;
				}
			}

			if ( ! $coberta ) {
				$orfas[] = $chave;
			}
		}

		return $orfas;
	}

	/**
	 * Segmentos de um caminho absoluto.
	 *
	 * @param string $caminho Caminho separado por ponto.
	 * @return array<int,string|int>
	 */
	private static function segmentos( string $caminho ): array {
		$partes = array();

		foreach ( explode( '.', $caminho ) as $parte ) {
			if ( '' === $parte ) {
				continue;
			}

			$partes[] = ctype_digit( $parte ) ? (int) $parte : $parte;
		}

		return $partes;
	}

	/**
	 * Anota o caminho lido na forma normalizada.
	 *
	 * @param string $caminho Caminho absoluto.
	 * @return void
	 */
	private static function anotar( string $caminho ): void {
		$normalizado = array();

		foreach ( self::segmentos( $caminho ) as $segmento ) {
			$normalizado[] = is_int( $segmento ) ? '*' : $segmento;
		}

		$chave = implode( '.', $normalizado );

		if ( '' === $chave ) {
			return;
		}

		self::$lidas[ $chave ] = ( self::$lidas[ $chave ] ?? 0 ) + 1;
	}

	/**
	 * Achata a configuração em caminhos normalizados.
	 *
	 * @param mixed              $valor    Nó atual.
	 * @param string             $prefixo  Caminho acumulado.
	 * @param array<string,bool> $acumula  Saída por referência.
	 * @return void
	 */
	private static function achatar( $valor, string $prefixo, array &$acumula ): void {
		if ( '' !== $prefixo ) {
			$acumula[ $prefixo ] = true;
		}

		if ( ! is_array( $valor ) ) {
			return;
		}

		foreach ( $valor as $chave => $filho ) {
			$segmento = is_int( $chave ) ? '*' : (string) $chave;
			$caminho  = '' === $prefixo ? $segmento : $prefixo . '.' . $segmento;

			self::achatar( $filho, $caminho, $acumula );
		}
	}

	/* ------------------------------------------------------------------ *
	 * Validador de schema (subconjunto do JSON Schema 2020-12 usado aqui)
	 * ------------------------------------------------------------------ */

	/**
	 * Valida os dados contra o schema do pacote.
	 *
	 * @param array<string,mixed> $dados Configuração decodificada.
	 * @return string[] Erros; vazio quando válido.
	 */
	public static function validar( array $dados ): array {
		$caminho = f3base_imp_caminho( self::SCHEMA );

		if ( '' === $caminho || ! is_readable( $caminho ) ) {
			return array(
				sprintf(
					/* translators: %s: caminho relativo do schema. */
					__( 'Schema ausente ou ilegível: %s', 'f3base' ),
					self::SCHEMA
				),
			);
		}

		$bruto = file_get_contents( $caminho ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote, sem rede.

		if ( ! is_string( $bruto ) ) {
			return array(
				sprintf(
					/* translators: %s: caminho relativo do schema. */
					__( 'Falha ao ler o schema: %s', 'f3base' ),
					self::SCHEMA
				),
			);
		}

		$schema = json_decode( $bruto, true );

		if ( ! is_array( $schema ) ) {
			return array(
				sprintf(
					/* translators: 1: caminho do schema, 2: mensagem do decodificador. */
					__( 'JSON inválido no schema %1$s: %2$s', 'f3base' ),
					self::SCHEMA,
					json_last_error_msg()
				),
			);
		}

		$erros = array();
		self::conferir( $dados, $schema, '', $erros );

		return $erros;
	}

	/**
	 * Confere um nó contra um sub-schema.
	 *
	 * @param mixed               $valor  Valor observado.
	 * @param array<string,mixed> $schema Sub-schema.
	 * @param string              $onde   Caminho para a mensagem.
	 * @param string[]            $erros  Saída por referência.
	 * @return void
	 */
	private static function conferir( $valor, array $schema, string $onde, array &$erros ): void {
		$rotulo = '' === $onde ? '(raiz)' : $onde;

		if ( isset( $schema['const'] ) || array_key_exists( 'const', $schema ) ) {
			if ( $valor !== $schema['const'] ) {
				$erros[] = sprintf(
					/* translators: 1: caminho, 2: valor esperado. */
					__( '%1$s: valor deve ser exatamente %2$s.', 'f3base' ),
					$rotulo,
					self::descrever( $schema['const'] )
				);
			}
		}

		if ( isset( $schema['enum'] ) && is_array( $schema['enum'] ) ) {
			$encontrou = false;

			foreach ( $schema['enum'] as $aceito ) {
				if ( $valor === $aceito ) {
					$encontrou = true;
					break;
				}
			}

			if ( ! $encontrou ) {
				$erros[] = sprintf(
					/* translators: 1: caminho, 2: lista de valores aceitos. */
					__( '%1$s: valor fora da lista declarada (%2$s).', 'f3base' ),
					$rotulo,
					implode( ', ', array_map( array( __CLASS__, 'descrever' ), $schema['enum'] ) )
				);
			}
		}

		if ( isset( $schema['type'] ) ) {
			$tipos = is_array( $schema['type'] ) ? $schema['type'] : array( $schema['type'] );
			$ok    = false;

			foreach ( $tipos as $tipo ) {
				if ( self::tipo_confere( $valor, (string) $tipo ) ) {
					$ok = true;
					break;
				}
			}

			if ( ! $ok ) {
				$erros[] = sprintf(
					/* translators: 1: caminho, 2: tipos aceitos, 3: tipo observado. */
					__( '%1$s: tipo esperado %2$s, observado %3$s.', 'f3base' ),
					$rotulo,
					implode( '|', array_map( 'strval', $tipos ) ),
					self::tipo_de( $valor )
				);

				return;
			}
		}

		if ( isset( $schema['oneOf'] ) && is_array( $schema['oneOf'] ) ) {
			$validos = 0;
			$parcial = array();

			foreach ( $schema['oneOf'] as $indice => $alternativa ) {
				if ( ! is_array( $alternativa ) ) {
					continue;
				}

				$locais = array();
				self::conferir( $valor, $alternativa, $onde, $locais );

				if ( array() === $locais ) {
					++$validos;
				} else {
					$parcial[] = sprintf( '#%d: %s', (int) $indice, implode( ' ', $locais ) );
				}
			}

			if ( 1 !== $validos ) {
				$erros[] = sprintf(
					/* translators: 1: caminho, 2: quantidade de alternativas válidas, 3: detalhes. */
					__( '%1$s: precisa casar com exatamente uma alternativa declarada; casou com %2$d. %3$s', 'f3base' ),
					$rotulo,
					$validos,
					implode( ' | ', $parcial )
				);
			}
		}

		foreach ( array( 'allOf', 'anyOf' ) as $combinador ) {
			if ( ! isset( $schema[ $combinador ] ) || ! is_array( $schema[ $combinador ] ) ) {
				continue;
			}

			$validos = 0;

			foreach ( $schema[ $combinador ] as $alternativa ) {
				if ( ! is_array( $alternativa ) ) {
					continue;
				}

				$locais = array();
				self::conferir( $valor, $alternativa, $onde, $locais );

				if ( array() === $locais ) {
					++$validos;
				} elseif ( 'allOf' === $combinador ) {
					foreach ( $locais as $erro ) {
						$erros[] = $erro;
					}
				}
			}

			if ( 'anyOf' === $combinador && 0 === $validos ) {
				$erros[] = sprintf(
					/* translators: %s: caminho. */
					__( '%s: nenhuma das alternativas declaradas casou.', 'f3base' ),
					$rotulo
				);
			}
		}

		if ( is_string( $valor ) ) {
			self::conferir_texto( $valor, $schema, $rotulo, $erros );
		}

		if ( is_int( $valor ) || is_float( $valor ) ) {
			self::conferir_numero( $valor, $schema, $rotulo, $erros );
		}

		if ( is_array( $valor ) && self::e_lista( $valor ) ) {
			self::conferir_lista( $valor, $schema, $onde, $rotulo, $erros );
		}

		if ( is_array( $valor ) && ! self::e_lista( $valor ) ) {
			self::conferir_objeto( $valor, $schema, $onde, $rotulo, $erros );
		}
	}

	/**
	 * Restrições de string.
	 *
	 * @param string              $valor  Valor.
	 * @param array<string,mixed> $schema Sub-schema.
	 * @param string              $rotulo Caminho legível.
	 * @param string[]            $erros  Saída por referência.
	 * @return void
	 */
	private static function conferir_texto( string $valor, array $schema, string $rotulo, array &$erros ): void {
		if ( isset( $schema['minLength'] ) && strlen( $valor ) < (int) $schema['minLength'] ) {
			$erros[] = sprintf(
				/* translators: 1: caminho, 2: comprimento mínimo. */
				__( '%1$s: texto mais curto que o mínimo de %2$d caractere(s).', 'f3base' ),
				$rotulo,
				(int) $schema['minLength']
			);
		}

		if ( isset( $schema['maxLength'] ) && strlen( $valor ) > (int) $schema['maxLength'] ) {
			$erros[] = sprintf(
				/* translators: 1: caminho, 2: comprimento máximo. */
				__( '%1$s: texto mais longo que o máximo de %2$d caractere(s).', 'f3base' ),
				$rotulo,
				(int) $schema['maxLength']
			);
		}

		if ( isset( $schema['pattern'] ) && is_string( $schema['pattern'] ) ) {
			/*
			 * Delimitador `#`, com o `#` literal escapado. Delimitador de chaves
			 * quebra em todo padrão que use quantificador `{n,m}` — o PCRE conta
			 * as chaves como par de delimitadores e reclama de "ending matching
			 * delimiter", e o efeito é o instrumento acusando o arquivo correto.
			 * O `D` fecha o `$` no fim real do texto, não antes de uma quebra.
			 */
			$expressao = '#' . str_replace( '#', '\\#', $schema['pattern'] ) . '#D';
			$casou     = preg_match( $expressao, $valor );

			if ( false === $casou ) {
				/* Erro do PADRÃO, não do valor: o instrumento não julga o que não conseguiu ler. */
				$erros[] = sprintf(
					/* translators: 1: caminho, 2: expressão declarada. */
					__( '%1$s: o padrão declarado no schema não compila (%2$s) — defeito do schema, não do valor observado.', 'f3base' ),
					$rotulo,
					$schema['pattern']
				);
			} elseif ( 1 !== $casou ) {
				$erros[] = sprintf(
					/* translators: 1: caminho, 2: expressão declarada. */
					__( '%1$s: texto não casa com o padrão declarado (%2$s).', 'f3base' ),
					$rotulo,
					$schema['pattern']
				);
			}
		}
	}

	/**
	 * Restrições numéricas.
	 *
	 * @param int|float           $valor  Valor.
	 * @param array<string,mixed> $schema Sub-schema.
	 * @param string              $rotulo Caminho legível.
	 * @param string[]            $erros  Saída por referência.
	 * @return void
	 */
	private static function conferir_numero( $valor, array $schema, string $rotulo, array &$erros ): void {
		if ( isset( $schema['minimum'] ) && $valor < $schema['minimum'] ) {
			$erros[] = sprintf(
				/* translators: 1: caminho, 2: mínimo declarado. */
				__( '%1$s: valor abaixo do mínimo declarado (%2$s).', 'f3base' ),
				$rotulo,
				(string) $schema['minimum']
			);
		}

		if ( isset( $schema['maximum'] ) && $valor > $schema['maximum'] ) {
			$erros[] = sprintf(
				/* translators: 1: caminho, 2: máximo declarado. */
				__( '%1$s: valor acima do máximo declarado (%2$s).', 'f3base' ),
				$rotulo,
				(string) $schema['maximum']
			);
		}
	}

	/**
	 * Restrições de lista.
	 *
	 * @param array<int,mixed>    $valor  Lista.
	 * @param array<string,mixed> $schema Sub-schema.
	 * @param string              $onde   Caminho cru.
	 * @param string              $rotulo Caminho legível.
	 * @param string[]            $erros  Saída por referência.
	 * @return void
	 */
	private static function conferir_lista( array $valor, array $schema, string $onde, string $rotulo, array &$erros ): void {
		if ( isset( $schema['minItems'] ) && count( $valor ) < (int) $schema['minItems'] ) {
			$erros[] = sprintf(
				/* translators: 1: caminho, 2: quantidade mínima. */
				__( '%1$s: lista com menos de %2$d item(ns).', 'f3base' ),
				$rotulo,
				(int) $schema['minItems']
			);
		}

		if ( ! isset( $schema['items'] ) || ! is_array( $schema['items'] ) ) {
			return;
		}

		foreach ( $valor as $indice => $item ) {
			$filho = '' === $onde ? (string) $indice : $onde . '.' . $indice;
			self::conferir( $item, $schema['items'], $filho, $erros );
		}
	}

	/**
	 * Restrições de objeto.
	 *
	 * @param array<string,mixed> $valor  Objeto.
	 * @param array<string,mixed> $schema Sub-schema.
	 * @param string              $onde   Caminho cru.
	 * @param string              $rotulo Caminho legível.
	 * @param string[]            $erros  Saída por referência.
	 * @return void
	 */
	private static function conferir_objeto( array $valor, array $schema, string $onde, string $rotulo, array &$erros ): void {
		$propriedades = isset( $schema['properties'] ) && is_array( $schema['properties'] ) ? $schema['properties'] : array();

		if ( isset( $schema['required'] ) && is_array( $schema['required'] ) ) {
			foreach ( $schema['required'] as $obrigatoria ) {
				if ( ! array_key_exists( (string) $obrigatoria, $valor ) ) {
					$erros[] = sprintf(
						/* translators: 1: caminho, 2: nome da chave. */
						__( '%1$s: chave obrigatória ausente: %2$s.', 'f3base' ),
						$rotulo,
						(string) $obrigatoria
					);
				}
			}
		}

		if ( isset( $schema['additionalProperties'] ) && false === $schema['additionalProperties'] ) {
			foreach ( array_keys( $valor ) as $chave ) {
				if ( ! array_key_exists( (string) $chave, $propriedades ) ) {
					$erros[] = sprintf(
						/* translators: 1: caminho, 2: nome da chave. */
						__( '%1$s: chave não declarada no schema: %2$s.', 'f3base' ),
						$rotulo,
						(string) $chave
					);
				}
			}
		}

		/*
		 * Mapa de chave aberta: o NOME da chave é dado da configuração (um slug
		 * de plugin, por exemplo) e não cabe na lista de `properties`. Sem estes
		 * dois ramos o schema aceitaria qualquer coisa dentro de um mapa aberto —
		 * validação que não sabe reprovar o valor é validação decorativa.
		 */
		if ( isset( $schema['propertyNames'] ) && is_array( $schema['propertyNames'] ) ) {
			foreach ( array_keys( $valor ) as $chave ) {
				$locais = array();
				self::conferir( (string) $chave, $schema['propertyNames'], $rotulo . ' (nome de chave)', $locais );

				foreach ( $locais as $local ) {
					$erros[] = $local;
				}
			}
		}

		if ( isset( $schema['additionalProperties'] ) && is_array( $schema['additionalProperties'] ) ) {
			foreach ( $valor as $chave => $filho_valor ) {
				if ( array_key_exists( (string) $chave, $propriedades ) ) {
					continue;
				}

				$filho = '' === $onde ? (string) $chave : $onde . '.' . $chave;
				self::conferir( $filho_valor, $schema['additionalProperties'], $filho, $erros );
			}
		}

		foreach ( $propriedades as $chave => $sub ) {
			if ( ! is_array( $sub ) || ! array_key_exists( (string) $chave, $valor ) ) {
				continue;
			}

			$filho = '' === $onde ? (string) $chave : $onde . '.' . $chave;
			self::conferir( $valor[ $chave ], $sub, $filho, $erros );
		}
	}

	/**
	 * O array é uma lista de índices sequenciais?
	 *
	 * @param array<mixed> $valor Array.
	 * @return bool
	 */
	private static function e_lista( array $valor ): bool {
		return array() === $valor || array_keys( $valor ) === range( 0, count( $valor ) - 1 );
	}

	/**
	 * O valor confere com o tipo do schema?
	 *
	 * @param mixed  $valor Valor observado.
	 * @param string $tipo  Nome do tipo no schema.
	 * @return bool
	 */
	private static function tipo_confere( $valor, string $tipo ): bool {
		switch ( $tipo ) {
			case 'object':
				/*
				 * AMBIGUIDADE REAL, e ela é do formato, não do validador: depois
				 * de `json_decode( $texto, true )`, `{}` e `[]` são o MESMO valor
				 * PHP — `array()`. Um validador que afirmasse distinguir os dois
				 * estaria afirmando uma distinção que o dado já não carrega. Por
				 * isso o array VAZIO satisfaz `object`, e a conferência de forma
				 * volta a morder assim que existe um elemento: aí as chaves dizem
				 * se é mapa ou lista. Foi o mapa `plugins.configuracao_servidor_mcp`,
				 * que nasce vazio por desenho, que expôs isto.
				 */
				return is_array( $valor ) && ( array() === $valor || ! self::e_lista( $valor ) );
			case 'array':
				return is_array( $valor ) && self::e_lista( $valor );
			case 'string':
				return is_string( $valor );
			case 'integer':
				return is_int( $valor );
			case 'number':
				return is_int( $valor ) || is_float( $valor );
			case 'boolean':
				return is_bool( $valor );
			case 'null':
				return null === $valor;
			default:
				return false;
		}
	}

	/**
	 * Nome legível do tipo observado.
	 *
	 * @param mixed $valor Valor.
	 * @return string
	 */
	private static function tipo_de( $valor ): string {
		if ( null === $valor ) {
			return 'null';
		}

		if ( is_bool( $valor ) ) {
			return 'boolean';
		}

		if ( is_int( $valor ) ) {
			return 'integer';
		}

		if ( is_float( $valor ) ) {
			return 'number';
		}

		if ( is_string( $valor ) ) {
			return 'string';
		}

		if ( is_array( $valor ) ) {
			return self::e_lista( $valor ) ? 'array' : 'object';
		}

		return 'desconhecido';
	}

	/**
	 * Representação curta de um valor para mensagem de erro.
	 *
	 * @param mixed $valor Valor.
	 * @return string
	 */
	public static function descrever( $valor ): string {
		if ( is_bool( $valor ) ) {
			return $valor ? 'true' : 'false';
		}

		if ( null === $valor ) {
			return 'null';
		}

		if ( is_scalar( $valor ) ) {
			return (string) $valor;
		}

		$json = wp_json_encode( $valor );

		return is_string( $json ) ? $json : '';
	}
}
