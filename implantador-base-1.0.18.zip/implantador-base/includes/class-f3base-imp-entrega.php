<?php
/**
 * Checagens de entrega e o gate da autodesativação.
 *
 * Cada um dos oito entregáveis tem checagem nomeada com estado fechado, mais
 * `entrega.rodada_limpa`, que amarra a entrega à última rodada integral da suíte
 * sobre o HASH EXATO do pacote. Entregável ausente é **BLOCKED com o nome do
 * arquivo que falta** — nunca ausência silenciosa —, e BLOCKED em entregável
 * IMPEDE a autodesativação: a ferramenta de correção não sai do ar antes de a
 * entrega existir. (Medido: um pacote sem suíte, sem README e sem memória fechou
 * o relatório com `FALHA: 0` e se autodesativou dizendo OK.)
 *
 * DOIS GATES, E ELES NÃO SÃO O MESMO. O gate de APLICAÇÃO decide a
 * autodesativação e só olha o que é mensurável NO HOST: os oito entregáveis
 * presentes no pacote, os vereditos de canal e o estado `SUCESSO_APLICACAO`. O
 * gate de ENTREGA POR FASE reúne a evidência IMPORTADA da suíte externa — hoje,
 * `entrega.rodada_limpa` — e ele não decide autodesativação nenhuma: fica
 * BLOCKED com a fase declarada, aparece no relatório como pendência de fase e
 * não segura a ferramenta.
 *
 * Os dois estavam FUNDIDOS, e a fusão era insatisfazível: `entrega.rodada_limpa`
 * é fato da suíte externa, que não roda no host, então ela fechava BLOCKED
 * SEMPRE e proibia a autodesativação PARA SEMPRE, em qualquer instalação, por
 * desenho. Evidência externa ausente trava o gate da fase declarada — não segura
 * o implantador ativo para sempre, nem se ignora.
 *
 * `mcp.canal_configurado` tem o mesmo efeito de gate: sem canal completo, a
 * manutenção pós-entrega não tem via de execução e o implantador é a única
 * ferramenta de correção que sobra. E a checagem confere as ROTAS PELO NOME, não
 * a presença dos plugins — a versão anterior conferia "plugin ativo + endpoint
 * autenticado + options bloqueadas", e os três fecham OK num site sem nenhuma
 * rota de arquivo.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Entregáveis e canal.
 */
final class F3Base_Imp_Entrega {

	/**
	 * Registro da EXECUÇÃO com os vereditos que as unidades gravaram.
	 *
	 * Uma fonte de verdade por fato. O caso medido: a linha 14 de um relatório
	 * dizia "as 12 rotas estão registradas E há servidor MCP ativo expondo-as:
	 * wp-mcp-ultimate" (OK) e a linha 41 do MESMO relatório dizia "o canal MCP
	 * não fechou em OK; o canal não está EXPOSTO por um servidor MCP ativo"
	 * (FALHA). Não era o site oscilando: eram DUAS implementações do mesmo
	 * veredito — a unidade `mcp` media pelas habilidades REGISTRADAS (Abilities
	 * API mais rota REST) e o encerramento recalculava por conta própria a
	 * partir da checagem antiga, que só enxerga rota REST.
	 *
	 * Daqui em diante o encerramento e a entrega LEEM o que a unidade gravou.
	 * Sem registro, o estado é BLOCKED dizendo que a unidade não rodou — nunca
	 * um veredito inventado no lugar.
	 */
	public const OPTION_VEREDITOS = 'f3base_vereditos';

	/**
	 * Registro da EXECUÇÃO com os FATOS que cada unidade mediu.
	 *
	 * Irmão do registro de vereditos, e pela mesma razão. O caso medido na
	 * 1.0.7: a linha 19 do relatório dizia "as 12 rotas de arquivo e banco estão
	 * registradas E há servidor MCP ativo expondo-as" e a linha 51 do MESMO
	 * relatório dizia "`mcp.canal_unico` — condição de aplicabilidade falsa:
	 * nenhuma rota de arquivo registrada". O predicado de aplicabilidade media o
	 * oposto do que a unidade tinha acabado de medir, no mesmo minuto, porque
	 * media por conta própria e só por rota REST.
	 *
	 * Quem precisa dos FATOS depois os LÊ daqui, como quem precisa do veredito
	 * lê de `OPTION_VEREDITOS`. Sem registro, BLOCKED dizendo que a unidade não
	 * rodou — nunca uma segunda medição no lugar.
	 */
	public const OPTION_MEDICOES = 'f3base_medicoes';

	/**
	 * Nome da unidade do plano que mede o canal — a única que o mede.
	 */
	public const UNIDADE_MCP = 'mcp';

	/**
	 * VEREDITOS QUE SÃO DA SUÍTE, E SÓ DELA.
	 *
	 * Lista de NOMES, e nada além disso — esta função não deriva estado nenhum.
	 * Ela declara a fronteira que a 1.0.8 fechou: perguntas cuja resposta é
	 * medida pela suíte externa, contra o pacote inteiro, e que o runtime NÃO
	 * pode responder por um segundo caminho.
	 *
	 * O caso medido: `config.toda_chave_tem_consumidor` reprovou no host
	 * nomeando vinte chaves que TÊM consumidor — a suíte, o site-core, outro
	 * caminho de execução. Duas implementações da mesma pergunta, medindo coisas
	 * diferentes, é a duplicação de fonte de verdade que a 1.0.7 eliminou para
	 * os gates reaparecendo por outra porta. O runtime passou a emitir
	 * `config.chaves_lidas_nesta_execucao`, WARN informativo, que é o que ele de
	 * fato mede.
	 *
	 * `estatica.gate_fonte_unica` executa esta declaração: nenhuma função do
	 * implantador pode derivar um estado fechado para um nome desta lista.
	 *
	 * @return string[]
	 */
	public static function vereditos_da_suite(): array {
		return array( 'estatica.detector_chave_sem_consumidor' );
	}

	/**
	 * Nomes dos vereditos de canal que decidem o gate da autodesativação.
	 *
	 * Lista de NOMES, e nada além disso: esta função não deriva estado nenhum.
	 * É dela que `pode_autodesativar()` tira o que consultar, é dela que a
	 * entrega tira o que ler do registro, e é dela que o detector
	 * `estatica.gate_fonte_unica` tira os nomes cuja derivação precisa morar em
	 * um lugar só.
	 *
	 * @return string[]
	 */
	public static function gates_do_canal(): array {
		return array( 'mcp.canal_configurado', 'mcp.canal_exposto' );
	}

	/**
	 * GATE DE APLICAÇÃO: os entregáveis que decidem a autodesativação.
	 *
	 * Lista de NOMES, e nada além disso. Todos são mensuráveis no host: ou o
	 * arquivo está no pacote e o objeto está no site, ou não está. Quem não
	 * aparece aqui NÃO decide se o implantador sai do ar — e é essa fronteira
	 * que impede uma evidência que o host não pode produzir de proibir a
	 * autodesativação para sempre.
	 *
	 * @return string[]
	 */
	public static function entregaveis_do_gate_de_aplicacao(): array {
		return array_merge(
			array( 'entrega.tema', 'entrega.site_core', 'entrega.conteudo', 'entrega.blog' ),
			array_keys( self::artefatos() )
		);
	}

	/**
	 * GATE DE ENTREGA POR FASE: evidência que ESTE host não produz.
	 *
	 * Lista de NOMES, e ela NÃO é escrita aqui: sai do metadado `gate` das
	 * linhas emitidas nesta execução. Até a 1.0.17 este corpo era uma lista
	 * literal com UM nome — `entrega.rodada_limpa` — enquanto o metadado `gate`
	 * marcava DOIS emissores. Duas fontes para o mesmo fato divergem, e a
	 * divergência saiu impressa dentro de UMA linha do log da 1.0.17: "Nenhuma
	 * pendência de fase em aberto" logo ao lado de "Pendência(s) de FASE dentro
	 * desta unidade — 1 … orcamento.medicao_de_pagina (BLOCKED)".
	 *
	 * Nenhum destes nomes decide autodesativação: ausente, cada um fica BLOCKED
	 * com a fase declarada e sai no relatório como pendência de fase. Não some,
	 * não vira FALHA e não segura a ferramenta de correção no ar.
	 *
	 * @return string[]
	 */
	public static function gates_de_fase(): array {
		return F3Base_Imp_Relatorio::nomes_com_gate( 'fase' );
	}

	/**
	 * Grava no registro da execução o veredito que uma unidade acabou de medir.
	 *
	 * @param string $nome   Nome da checagem.
	 * @param string $estado Estado fechado decidido pela unidade.
	 * @param string $motivo Mensagem que a unidade emitiu.
	 * @return void
	 */
	public static function registrar_veredito( string $nome, string $estado, string $motivo ): void {
		$registro = get_option( self::OPTION_VEREDITOS, array() );
		$registro = is_array( $registro ) ? $registro : array();

		$registro[ $nome ] = array(
			'estado' => $estado,
			'motivo' => $motivo,
			'em'     => time(),
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_VEREDITOS, $registro );
	}

	/**
	 * LÊ o veredito gravado por uma unidade. Não recalcula nada.
	 *
	 * O nome chega por PARÂMETRO de propósito: é isso que impede esta função de
	 * virar a segunda derivação daquilo que ela só deveria ler.
	 *
	 * @param string $nome Nome da checagem.
	 * @return array{estado:string,motivo:string,registrado:bool}
	 */
	public static function veredito_registrado( string $nome ): array {
		$registro = get_option( self::OPTION_VEREDITOS, array() );
		$registro = is_array( $registro ) ? $registro : array();

		if ( ! isset( $registro[ $nome ] ) || ! is_array( $registro[ $nome ] ) ) {
			return array(
				'estado'     => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'     => sprintf(
					/* translators: 1: nome da checagem, 2: nome da option do registro. */
					__( 'pré-condição ausente: a unidade que mede %1$s não rodou nesta execução e não há veredito em %2$s para ler. Uma fonte de verdade por fato — sem o registro, o estado é BLOCKED, e não um veredito recalculado aqui.', 'f3base' ),
					$nome,
					self::OPTION_VEREDITOS
				),
				'registrado' => false,
			);
		}

		return array(
			'estado'     => (string) ( $registro[ $nome ]['estado'] ?? F3Base_Imp_Relatorio::BLOCKED ),
			'motivo'     => (string) ( $registro[ $nome ]['motivo'] ?? '' ),
			'registrado' => true,
		);
	}

	/**
	 * Grava no registro da execução os FATOS que uma unidade acabou de medir.
	 *
	 * @param string             $unidade Nome da unidade que mediu.
	 * @param array<string,mixed> $fatos  Fatos observados, sem veredito nenhum.
	 * @return void
	 */
	public static function registrar_medicao( string $unidade, array $fatos ): void {
		$registro = get_option( self::OPTION_MEDICOES, array() );
		$registro = is_array( $registro ) ? $registro : array();

		$registro[ $unidade ] = array(
			'fatos' => $fatos,
			'em'    => time(),
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_MEDICOES, $registro );
	}

	/**
	 * LÊ os fatos que uma unidade gravou. Não mede nada.
	 *
	 * O nome da unidade chega por PARÂMETRO pela mesma razão que o do veredito:
	 * é a construção da leitura que impede esta função de virar a segunda
	 * medição daquilo que ela só deveria ler.
	 *
	 * @param string $unidade Nome da unidade.
	 * @return array{fatos:array<string,mixed>,registrado:bool}
	 */
	public static function medicao_registrada( string $unidade ): array {
		$registro = get_option( self::OPTION_MEDICOES, array() );
		$registro = is_array( $registro ) ? $registro : array();

		if ( ! isset( $registro[ $unidade ] ) || ! is_array( $registro[ $unidade ] ) ) {
			return array(
				'fatos'      => array(),
				'registrado' => false,
			);
		}

		$fatos = $registro[ $unidade ]['fatos'] ?? array();

		return array(
			'fatos'      => is_array( $fatos ) ? $fatos : array(),
			'registrado' => true,
		);
	}

	/**
	 * As doze rotas de arquivo e banco que o complemento acrescenta.
	 *
	 * Estas são o PROTOCOLO do canal — não são o que a configuração declara (a
	 * configuração declara os slugs dos dois plugins). Por isso vivem aqui, e a
	 * conferência é pelo NOME de cada uma, com a que faltar saindo nomeada.
	 *
	 * @return string[]
	 */
	public static function rotas_do_complemento(): array {
		return array(
			'files/list',
			'files/read',
			'files/write',
			'files/patch',
			'files/delete',
			'files/backups',
			'files/restore',
			'files/fetch',
			'files/selftest',
			'db/schema',
			'db/query',
			'db/execute',
		);
	}

	/**
	 * Arquivos que provam cada entregável, por nome.
	 *
	 * @return array<string,array{rotulo:string,caminhos:string[]}>
	 */
	public static function artefatos(): array {
		return array(
			'entrega.readme'      => array(
				'rotulo'   => __( 'README com árvore de arquivos, instalação, execução e remoção', 'f3base' ),
				'caminhos' => array( 'README.md' ),
			),
			'entrega.memoria'     => array(
				'rotulo'   => __( 'Memória de decisões', 'f3base' ),
				'caminhos' => array( 'MEMORIA-DECISOES.md' ),
			),
			'entrega.suite'       => array(
				'rotulo'   => __( 'Suíte de verificação com comando único', 'f3base' ),
				'caminhos' => array( 'suite/verificar.sh' ),
			),
			'entrega.implantador' => array(
				'rotulo'   => __( 'Implantador consolidado', 'f3base' ),
				'caminhos' => array( 'implantador-base.php', 'config/site.json', 'config/site.schema.json', 'includes/class-f3base-imp-lotes.php' ),
			),
		);
	}

	/**
	 * Executa todas as checagens de entrega, emitindo nos dois ramos.
	 *
	 * @return array<string,string> Estado por checagem.
	 */
	public static function conferir(): array {
		$estados = array();

		$estados['entrega.tema']       = self::conferir_tema();
		$estados['entrega.site_core']  = self::conferir_site_core();
		$estados['entrega.conteudo']   = self::conferir_conteudo();
		$estados['entrega.blog']       = self::conferir_blog();

		foreach ( self::artefatos() as $nome => $artefato ) {
			$estados[ $nome ] = self::conferir_arquivos( $nome, $artefato['rotulo'], $artefato['caminhos'] );
		}

		/*
		 * A rodada limpa entra pelo GATE DE FASE: ela é medida, nomeada e
		 * impressa como qualquer outra, e simplesmente não participa da decisão
		 * de autodesativação — que é o que `pode_autodesativar()` executa lendo
		 * `entregaveis_do_gate_de_aplicacao()`.
		 */
		$estados['entrega.rodada_limpa'] = self::conferir_rodada_limpa();
		$estados['mcp.canal_unico']      = self::conferir_canal_unico();

		/*
		 * OS VEREDITOS DE CANAL SÃO LIDOS, NUNCA RECALCULADOS AQUI. Quem mede é
		 * a unidade `mcp`, uma vez, e é ela que grava no registro da execução.
		 * A entrega e o encerramento leem o mesmo registro — foi a segunda
		 * derivação, feita aqui, que produziu o relatório que se contradizia
		 * entre a linha 14 e a linha 41.
		 */
		foreach ( self::gates_do_canal() as $gate ) {
			$estados[ $gate ] = self::ler_gate_do_canal( $gate );
		}

		return $estados;
	}

	/**
	 * Lê um veredito de gate do registro da execução e emite quando ele falta.
	 *
	 * Dois ramos, e os dois vivos: registrado, o estado volta como a unidade o
	 * decidiu e NENHUMA linha nova sai (a unidade já emitiu a dela, e uma
	 * segunda linha com o mesmo nome seria a duplicidade voltando pela porta do
	 * relatório); não registrado, sai UMA linha BLOCKED dizendo que a unidade
	 * não rodou.
	 *
	 * O nome vem por parâmetro: esta função lê, e por construção não pode
	 * derivar.
	 *
	 * @param string $gate Nome do veredito de gate.
	 * @return string Estado lido.
	 */
	private static function ler_gate_do_canal( string $gate ): string {
		$veredito = self::veredito_registrado( $gate );

		if ( $veredito['registrado'] ) {
			return $veredito['estado'];
		}

		return F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			$gate,
			$veredito['motivo'],
			array(
				'evidencia' => 'pendencia-externa',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * O tema viaja no pacote e está instalado e ativo?
	 *
	 * @return string
	 */
	private static function conferir_tema(): string {
		/*
		 * FONTE ÚNICA. O entregável é provado pelo MESMO artefato que a
		 * instalação lê: até a 1.0.15 esta função tinha a própria lista de
		 * caminhos, que não conhecia o slot `assets/plugins/` que o instalador
		 * lê — o entregável provava um artefato e a instalação usava outro.
		 */
		$artefato = F3Base_Imp_Plugins::artefato_do_papel( 'tema' );
		$slug     = $artefato['slug'];

		if ( '' === $artefato['tipo'] ) {
			return F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'entrega.tema',
				sprintf(
					/* translators: %s: caminhos esperados. */
					__( 'entregável ausente no pacote: nenhum dos caminhos que a instalação lê existe — %s.', 'f3base' ),
					implode( ', ', $artefato['candidatos'] )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'gate'      => 'aplicacao',
				)
			);
		}

		$tema  = wp_get_theme( $slug );
		$ativo = $tema->exists() && get_stylesheet() === $slug;

		return F3Base_Imp_Relatorio::avaliar(
			$ativo,
			'entrega.tema',
			sprintf(
				/* translators: 1: slug do tema, 2: versão observada. */
				__( 'tema %1$s presente no pacote, instalado e ativo na versão %2$s.', 'f3base' ),
				$slug,
				(string) $tema->get( 'Version' )
			),
			sprintf(
				/* translators: 1: slug desejado, 2: slug ativo. */
				__( 'o tema %1$s viaja no pacote mas não é o ativo: no ar está %2$s.', 'f3base' ),
				$slug,
				get_stylesheet()
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * O `site-core` viaja no pacote e está instalado e ativo?
	 *
	 * @return string
	 */
	private static function conferir_site_core(): string {
		/* FONTE ÚNICA, pela mesma razão de `conferir_tema()`. */
		$artefato = F3Base_Imp_Plugins::artefato_do_papel( 'site_core' );
		$slug     = $artefato['slug'];

		if ( '' === $artefato['tipo'] ) {
			return F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'entrega.site_core',
				sprintf(
					/* translators: %s: caminhos esperados. */
					__( 'entregável ausente no pacote: nenhum dos caminhos que a instalação lê existe — %s.', 'f3base' ),
					implode( ', ', $artefato['candidatos'] )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'gate'      => 'aplicacao',
				)
			);
		}

		$arquivo = F3Base_Imp_Plugins::arquivo_principal( $slug );
		$ativo   = '' !== $arquivo && is_plugin_active( $arquivo );

		return F3Base_Imp_Relatorio::avaliar(
			$ativo,
			'entrega.site_core',
			sprintf(
				/* translators: 1: slug, 2: versão observada. */
				__( 'plugin persistente %1$s presente no pacote, instalado e ativo na versão %2$s. Trocar o tema não derruba leads, redirects, schema, tracking nem as contingências.', 'f3base' ),
				$slug,
				F3Base_Imp_Plugins::versao_instalada( $slug )
			),
			sprintf(
				/* translators: %s: slug. */
				__( 'o plugin persistente %s viaja no pacote mas não está ativo no site.', 'f3base' ),
				$slug
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * Todo conteúdo declarado tem arquivo e objeto gerenciado?
	 *
	 * @return string
	 */
	private static function conferir_conteudo(): string {
		$faltam_arquivos = array();
		$faltam_objetos  = array();
		$presentes       = array();

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$ref     = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
			$arquivo = f3base_imp_caminho( 'content/pages/' . $ref . '.html' );

			if ( '' === $arquivo || ! is_readable( $arquivo ) ) {
				$faltam_arquivos[] = 'content/pages/' . $ref . '.html';
				continue;
			}

			if ( F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref ) <= 0 ) {
				$faltam_objetos[] = $ref;
				continue;
			}

			$presentes[] = $ref;
		}

		if ( array() !== $faltam_arquivos ) {
			return F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'entrega.conteudo',
				sprintf(
					/* translators: %s: nomes dos arquivos ausentes. */
					__( 'conteúdo editorial ausente no pacote: %s. O entregável é o arquivo, não a promessa dele.', 'f3base' ),
					implode( ', ', $faltam_arquivos )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'gate'      => 'aplicacao',
				)
			);
		}

		return F3Base_Imp_Relatorio::avaliar(
			array() === $faltam_objetos,
			'entrega.conteudo',
			sprintf(
				/* translators: %s: referências publicadas. */
				__( 'páginas gerenciadas presentes e localizadas pela meta de gestão: %s.', 'f3base' ),
				implode( ', ', $presentes )
			),
			sprintf(
				/* translators: %s: referências sem objeto. */
				__( 'páginas declaradas sem objeto gerenciado no site: %s.', 'f3base' ),
				implode( ', ', $faltam_objetos )
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * O blog está funcional, com item de menu e posts?
	 *
	 * @return string
	 */
	private static function conferir_blog(): string {
		$declarados = F3Base_Imp_Config::lista( 'posts' );

		$tem_item_menu = false;

		foreach ( F3Base_Imp_Config::lista( 'navegacao.itens' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( 'posts-page' === (string) F3Base_Imp_Config::obter( 'navegacao.itens.' . $indice . '.tipo', '' ) ) {
				$tem_item_menu = true;
				break;
			}
		}

		if ( array() === $declarados && ! $tem_item_menu ) {
			return F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'entrega.blog',
				__( 'condição de aplicabilidade falsa: a configuração não declara posts nem item de menu para a página de posts — blog fora do escopo declarado.', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'gate'      => 'aplicacao',
				)
			);
		}

		$faltam = array();
		$nomes  = array();

		foreach ( $declarados as $indice => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' );
			$id   = F3Base_Imp_Conteudo::localizar_gerenciado( 'post', $slug );

			if ( $id <= 0 ) {
				$faltam[] = $slug;
			} else {
				$nomes[] = $slug . ' (#' . $id . ')';
			}
		}

		$pagina_posts = (int) get_option( 'page_for_posts', 0 );
		$completo     = array() === $faltam && ( ! $tem_item_menu || $pagina_posts > 0 );

		return F3Base_Imp_Relatorio::avaliar(
			$completo,
			'entrega.blog',
			sprintf(
				/* translators: 1: posts nomeados, 2: ID da página de posts. */
				__( 'blog funcional: posts gerenciados %1$s e página de posts #%2$d definida.', 'f3base' ),
				implode( ', ', $nomes ),
				$pagina_posts
			),
			sprintf(
				/* translators: 1: posts ausentes, 2: ID da página de posts. */
				__( 'blog incompleto: posts sem objeto gerenciado (%1$s) e página de posts #%2$d.', 'f3base' ),
				array() === $faltam ? __( 'nenhum', 'f3base' ) : implode( ', ', $faltam ),
				$pagina_posts
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * Entregável de arquivo: presente com o nome, ou BLOCKED com o nome que falta.
	 *
	 * @param string   $nome     Nome da checagem.
	 * @param string   $rotulo   Rótulo humano.
	 * @param string[] $caminhos Caminhos relativos exigidos.
	 * @return string
	 */
	private static function conferir_arquivos( string $nome, string $rotulo, array $caminhos ): string {
		$ausentes  = array();
		$presentes = array();

		foreach ( $caminhos as $relativo ) {
			$absoluto = f3base_imp_caminho( $relativo );

			if ( '' === $absoluto || ! is_readable( $absoluto ) ) {
				$ausentes[] = $relativo;
				continue;
			}

			$presentes[] = sprintf( '%s (%s bytes)', $relativo, number_format_i18n( (float) filesize( $absoluto ) ) );
		}

		if ( array() !== $ausentes ) {
			return F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				$nome,
				sprintf(
					/* translators: 1: rótulo do entregável, 2: arquivos ausentes. */
					__( '%1$s: entregável ausente no pacote — falta %2$s. Entregável ausente é defeito do pacote e impede a autodesativação.', 'f3base' ),
					$rotulo,
					implode( ', ', $ausentes )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'gate'      => 'aplicacao',
				)
			);
		}

		return F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::OK,
			$nome,
			sprintf(
				/* translators: 1: rótulo, 2: arquivos presentes com tamanho. */
				__( '%1$s presente: %2$s.', 'f3base' ),
				$rotulo,
				implode( '; ', $presentes )
			),
			array(
				'evidencia' => 'analise-estatica',
				'fase'      => 'build',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * Nome do registro que o COMANDO ÚNICO grava dentro do pacote.
	 *
	 * Ponto único do caminho: quem lê usa esta constante, e o detector de fonte
	 * única confere que quem ESCREVE é um lugar só — o comando único. Registro
	 * de rodada gravado à mão é uma afirmação sem medição por trás.
	 */
	public const REGISTRO_RODADA = 'suite/rodada.json';

	/**
	 * VEREDITO PURO da rodada limpa: função sem WordPress, com piso dos dois lados.
	 *
	 * A regra que ela executa, e é a regra do documento: checagem que o
	 * implantador NÃO executa no host entra como EVIDÊNCIA IMPORTADA da suíte
	 * externa. Registro presente cujo hash bate com o do pacote instalado fecha
	 * **OK com classe `importada` e fase `build`** — jamais `medida`, jamais fase
	 * `producao`: quem mediu foi outra rodada, em outra máquina, e o que este
	 * host faz é conferir a amarração. Registro ausente ou com hash divergente
	 * fecha BLOCKED NOMEANDO o hash esperado e o encontrado.
	 *
	 * A 1.0.18 acrescentou a SEGUNDA metade da conferência, e ela é o achado:
	 * até a 1.0.17 esta função comparava SÓ O HASH. O registro se chamava
	 * "rodada limpa", trazia 22 BLOCKED dentro, e bastava o hash bater para
	 * `entrega.rodada_limpa` fechar OK no host — o pacote se aprovando pelo
	 * arquivo que ele mesmo escreveu, com a palavra "limpa" fazendo o resto do
	 * trabalho. Agora o registro DECLARA o veredito e esta função o LÊ: sem
	 * veredito legível, ou com FALHA declarada, o estado é BLOCKED; com
	 * pendências de fase declaradas, fecha OK NOMEANDO-as, porque o host não
	 * pode afirmar mais do que a rodada mediu.
	 *
	 * @param bool                $existe    O registro existe e é legível?
	 * @param string              $declarado Hash declarado dentro do registro.
	 * @param string              $observado Hash do pacote instalado, calculado aqui.
	 * @param array<string,mixed> $registro  Conteúdo lido do registro.
	 * @return array{estado:string,motivo:string,evidencia:string,fase:string}
	 */
	public static function veredito_da_rodada_limpa( bool $existe, string $declarado, string $observado, array $registro = array() ): array {
		if ( ! $existe ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: caminho do registro, 2: hash observado do pacote instalado. */
					__( 'pendência de FASE, não de aplicação: o registro %1$s não viaja neste pacote. Ele é produzido pelo comando único da suíte externa e é a única evidência aceita da rodada integral; o hash do pacote instalado é %2$s e não há registro com que compará-lo. Isto NÃO impede a autodesativação — evidência externa ausente trava o gate da fase declarada, não a ferramenta.', 'f3base' ),
					self::REGISTRO_RODADA,
					'' !== $observado ? $observado : __( '(indisponível)', 'f3base' )
				),
				'evidencia' => 'pendencia-externa',
				'fase'      => 'build',
			);
		}

		if ( '' === $declarado || $declarado !== $observado ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: hash esperado (o do pacote instalado), 2: hash encontrado no registro, 3: caminho do registro. */
					__( 'pendência de FASE: a rodada registrada não é a deste pacote. Hash esperado (pacote instalado): %1$s. Hash encontrado em %3$s: %2$s. Rodada de um hash não vale para outro, e o registro não pode ser corrigido à mão — só o comando único o produz.', 'f3base' ),
					'' !== $observado ? $observado : __( '(indisponível)', 'f3base' ),
					'' !== $declarado ? $declarado : __( '(ausente no registro)', 'f3base' ),
					self::REGISTRO_RODADA
				),
				'evidencia' => 'pendencia-externa',
				'fase'      => 'build',
			);
		}

		/*
		 * O HASH BATE. Falta a outra metade: O QUE a rodada declarou ter medido.
		 */
		$veredito   = isset( $registro['veredito'] ) ? (string) $registro['veredito'] : '';
		$falhas     = isset( $registro['falhas'] ) ? (int) $registro['falhas'] : -1;
		$pendencias = isset( $registro['pendencias_de_fase'] ) && is_array( $registro['pendencias_de_fase'] )
			? array_map( 'strval', $registro['pendencias_de_fase'] )
			: array();

		if ( '' === $veredito || $falhas < 0 ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: caminho do registro, 2: hash conferido. */
					__( 'pendência de FASE: o hash bate (%2$s), e o registro %1$s NÃO declara veredito nem contagem de FALHA. Hash igual prova que a rodada mediu ESTE pacote, e não diz o que ela achou; conferir só o hash foi o defeito da 1.0.17 — o pacote se aprovava pelo arquivo que ele mesmo escreveu. Registro sem veredito legível é registro de uma versão anterior do selo: reexecute o comando único.', 'f3base' ),
					self::REGISTRO_RODADA,
					$observado
				),
				'evidencia' => 'pendencia-externa',
				'fase'      => 'build',
			);
		}

		if ( $falhas > 0 ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: quantidade de FALHA declarada, 2: caminho do registro, 3: veredito declarado. */
					__( 'pendência de FASE: o registro %2$s declara %1$d checagem(ns) em FALHA (veredito "%3$s"). Uma rodada com FALHA não amarra entrega nenhuma, e o selo nem deveria tê-la gravado — reexecute o comando único e corrija o que ele nomear.', 'f3base' ),
					$falhas,
					self::REGISTRO_RODADA,
					$veredito
				),
				'evidencia' => 'pendencia-externa',
				'fase'      => 'build',
			);
		}

		return array(
			'estado'    => F3Base_Imp_Relatorio::OK,
			'motivo'    => sprintf(
				/* translators: 1: hash conferido, 2: caminho do registro, 3: veredito declarado, 4: pendências de fase nomeadas. */
				__( 'a rodada integral registrada em %2$s mediu exatamente este pacote: o hash declarado no registro e o hash do pacote instalado são o mesmo (%1$s). VEREDITO DECLARADO NO REGISTRO: "%3$s" — zero FALHA. %4$s Evidência IMPORTADA da suíte externa, fase build — este host conferiu a amarração E leu o veredito; ele não mediu a rodada.', 'f3base' ),
				$observado,
				self::REGISTRO_RODADA,
				$veredito,
				array() === $pendencias
					? __( 'Nenhuma pendência de fase declarada naquela rodada.', 'f3base' )
					: sprintf(
						/* translators: 1: quantidade de pendências, 2: os nomes. */
						__( 'Pendência(s) de fase NOMEADA(S) naquela rodada — %1$d: %2$s. Elas não somem por o hash bater, e é por isso que o registro deixou de se chamar "rodada limpa": um arquivo com esse nome e pendências dentro afirma mais do que mediu.', 'f3base' ),
						count( $pendencias ),
						implode( ', ', $pendencias )
					)
			),
			'evidencia' => 'importada',
			'fase'      => 'build',
		);
	}

	/**
	 * A entrega referencia uma rodada integral da suíte sobre ESTE hash?
	 *
	 * Lê o registro que o comando único gravou dentro do pacote e confere contra
	 * o hash do pacote instalado. O gate é `fase`: esta linha NUNCA decide a
	 * autodesativação.
	 *
	 * @return string
	 */
	private static function conferir_rodada_limpa(): string {
		$arquivo   = f3base_imp_caminho( self::REGISTRO_RODADA );
		$existe    = '' !== $arquivo && is_readable( $arquivo );
		$declarado = '';
		$rodada    = array();

		if ( $existe ) {
			$bruto     = (string) file_get_contents( $arquivo ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo do próprio pacote.
			$lido      = json_decode( $bruto, true );
			$rodada    = is_array( $lido ) ? $lido : array();
			$declarado = isset( $rodada['hash_pacote'] ) ? (string) $rodada['hash_pacote'] : '';
		}

		$veredito = self::veredito_da_rodada_limpa( $existe, $declarado, self::hash_do_pacote(), $rodada );

		return F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'entrega.rodada_limpa',
			$veredito['motivo'],
			array(
				'evidencia' => $veredito['evidencia'],
				'fase'      => $veredito['fase'],
				'gate'      => 'fase',
			)
		);
	}

	/**
	 * Um canal por site: mais de um PLUGIN DE CANAL ativo é defeito.
	 *
	 * A pergunta mudou de forma na 1.0.9, e o nome dela é a diferença: não é
	 * "quantos registram `files/*`" — essa não tem resposta, porque nenhuma das
	 * fontes de rota atribui plugin — é **"quantos plugins de canal estão
	 * ativos"**, que tem resposta e que é a pergunta que o operador faz.
	 *
	 * O que continua daqui da 1.0.8, e continua certo: a medição é LIDA do
	 * registro que a unidade `mcp` gravou, nunca refeita por um segundo caminho.
	 * Foi a segunda medição que pôs a linha 19 do relatório de 1.0.7 em
	 * contradição com a linha 51 no mesmo minuto.
	 *
	 * @return string
	 */
	private static function conferir_canal_unico(): string {
		$medicao  = self::medicao_registrada( self::UNIDADE_MCP );
		$veredito = self::veredito_do_canal_unico( $medicao['registrado'], $medicao['fatos'] );

		return F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'mcp.canal_unico',
			$veredito['motivo'],
			array(
				'evidencia' => $veredito['evidencia'],
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * Veredito PURO do canal único, a partir do que a unidade `mcp` registrou.
	 *
	 * O DEFEITO DA 1.0.8, dito por inteiro. A linha do log era:
	 *
	 *   *"as 9 rota(s) de arquivo que a unidade mediu não têm registrador
	 *   único: Abilities files/list, Abilities files/read, … Dois diretórios de
	 *   backup e DUAS chaves de desligamento — o operador fecha o canal em um e
	 *   ele segue aberto pelo outro."*
	 *
	 * Os dados que a própria linha imprime desmentem a frase: nove rotas, UMA
	 * fonte cada, e nenhum segundo plugin nomeado. A lista de "registradores"
	 * eram as rotas repetidas com o nome da fonte na frente, porque **a
	 * Abilities API não devolve qual plugin registrou cada habilidade**. O
	 * código tratava "não consegui atribuir" como "há mais de um", e a
	 * consequência — dois diretórios, duas chaves — era decorada, não medida.
	 *
	 * A correção, em três camadas, e cada uma é um ramo desta função:
	 *
	 * 1. **Impossibilidade de medir é BLOCKED, nunca FALHA.** Sem o censo de
	 *    plugins, a única fonte que resta é a que não atribui origem, e o estado
	 *    diz exatamente isso, nomeando a Abilities API.
	 * 2. **Mede-se o que responde à pergunta real** — quantos PLUGINS DE CANAL
	 *    estão ativos: nenhum é BLOCKED, um é OK nomeando-o, dois ou mais é
	 *    FALHA nomeando os diretórios e os arquivos principais, que é o que
	 *    torna o achado acionável.
	 * 3. **A frase da consequência só existe quando o achado existe.** Ela é
	 *    verdadeira com dois plugins, e só ali é impressa, ao lado dos nomes
	 *    reais. Enquanto o achado for hipotético, imprimi-la é o diagnóstico
	 *    afirmando causa que os dados contradizem.
	 *
	 * Sem nome de checagem aqui dentro, de propósito: quem emite é
	 * `conferir_canal_unico()`, e esta função não pode virar a segunda menção
	 * derivante do mesmo nome.
	 *
	 * @param bool                $registrado A unidade `mcp` gravou medição nesta execução?
	 * @param array<string,mixed> $fatos      Fatos gravados pela unidade.
	 * @return array{estado:string,motivo:string,evidencia:string}
	 */
	public static function veredito_do_canal_unico( bool $registrado, array $fatos ): array {
		if ( ! $registrado ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: nome da unidade que mede o canal, 2: option do registro de medições. */
					__( 'pré-condição ausente: a unidade %1$s não rodou nesta execução e não há medição em %2$s para ler. Quantos plugins de canal estão ativos é fato daquela unidade; medi-lo aqui por um segundo caminho foi exatamente o que pôs a aplicabilidade em contradição com o relatório.', 'f3base' ),
					self::UNIDADE_MCP,
					self::OPTION_MEDICOES
				),
				'evidencia' => 'pendencia-externa',
			);
		}

		$fontes = array_map( 'strval', (array) ( $fatos['fontes_de_arquivo'] ?? array() ) );
		$rotas  = array_map( 'strval', (array) ( $fatos['rotas_de_arquivo'] ?? array() ) );

		/*
		 * CAMADA 1. Sem censo de plugins não há como atribuir origem a coisa
		 * alguma, e a fonte que sobra — a Abilities API — não devolve o plugin
		 * que registrou cada habilidade. Isso é pré-condição ausente, e o
		 * contrato é explícito: BLOCKED, nunca FALHA, nunca veredito por
		 * impossibilidade de medir.
		 */
		if ( ! (bool) ( $fatos['censo_de_plugins'] ?? false ) ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: quantidade de rotas de arquivo observadas, 2: fontes observadas, sem atribuição de plugin. */
					__( 'pré-condição ausente: esta execução não conseguiu ler a lista de plugins instalados, e sem ela não há como contar plugins de canal. A única fonte que resta NÃO atribui origem: a Abilities API não devolve o plugin que registrou cada habilidade, e o namespace REST é escolhido por quem registra, não por quem instala. Rotas de arquivo observadas: %1$d; fontes observadas, sem atribuição de plugin: %2$s. Não consegui atribuir NÃO é há mais de um — por isso esta linha é BLOCKED e não FALHA.', 'f3base' ),
					count( $rotas ),
					array() === $fontes ? __( 'nenhuma', 'f3base' ) : implode( ', ', $fontes )
				),
				'evidencia' => 'pendencia-externa',
			);
		}

		$complementos     = self::complementos_normalizados( $fatos );
		$slug_complemento = (string) ( $fatos['slug_complemento'] ?? '' );

		/*
		 * CAMADA 2, primeiro ramo: nenhum plugin de canal ativo. Não há canal
		 * cuja unicidade medir, e a pergunta fica sem sujeito — pré-condição
		 * ausente de novo, e de novo BLOCKED.
		 */
		if ( array() === $complementos ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: slug declarado com o papel do complemento, 2: Plugin Name do complemento declarado. */
					__( 'pré-condição ausente: nenhum plugin ATIVO responde pelo papel canal-mcp-complemento (%1$s) nem carrega o cabeçalho Plugin Name do complemento declarado (%2$s). Sem complemento ativo não existe canal cuja unicidade medir — diretório inativo ou oculto não é canal aberto, e o WordPress nem o carrega.', 'f3base' ),
					'' !== $slug_complemento ? $slug_complemento : __( 'papel ausente na configuração', 'f3base' ),
					'' !== (string) ( $fatos['nome_complemento'] ?? '' ) ? (string) $fatos['nome_complemento'] : __( 'não legível: o complemento declarado não está instalado', 'f3base' )
				),
				'evidencia' => 'medida',
			);
		}

		if ( 1 === count( $complementos ) ) {
			$unico = $complementos[0];

			/*
			 * RAMO DE UM SÓ. A frase sobre dois diretórios de backup e duas
			 * chaves de desligamento NÃO aparece aqui, e a ausência dela é a
			 * correção: consequência de achado que não existe é o diagnóstico
			 * afirmando causa que os dados contradizem.
			 */
			return array(
				'estado'    => F3Base_Imp_Relatorio::OK,
				'motivo'    => sprintf(
					/* translators: 1: Plugin Name, 2: diretório, 3: arquivo principal, 4: como foi reconhecido, 5: quantidade de rotas de arquivo observadas. */
					__( 'um único plugin de canal ATIVO neste site: %1$s (diretório %2$s, arquivo principal %3$s), reconhecido pelo %4$s. Nenhum outro plugin ativo carrega esse papel nem esse Plugin Name — a pergunta é quantos plugins de canal estão ativos, e a resposta medida é um. Rotas de arquivo respondendo: %5$d.', 'f3base' ),
					'' !== $unico['nome'] ? $unico['nome'] : $unico['slug'],
					self::diretorio_nomeado( $unico['diretorio'] ),
					$unico['arquivo'],
					$unico['por'],
					count( $rotas )
				),
				'evidencia' => 'medida',
			);
		}

		$nomeados = array();

		foreach ( $complementos as $complemento ) {
			$nomeados[] = sprintf(
				/* translators: 1: Plugin Name, 2: diretório, 3: arquivo principal, 4: como foi reconhecido. */
				__( '%1$s — diretório %2$s, arquivo principal %3$s (reconhecido pelo %4$s)', 'f3base' ),
				'' !== $complemento['nome'] ? $complemento['nome'] : $complemento['slug'],
				self::diretorio_nomeado( $complemento['diretorio'] ),
				$complemento['arquivo'],
				$complemento['por']
			);
		}

		/*
		 * CAMADA 3. AQUI, e só aqui, a consequência é verdadeira: há dois
		 * plugins de canal ativos, os dois estão nomeados ao lado dela, e o
		 * operador tem o que abrir.
		 */
		return array(
			'estado'    => F3Base_Imp_Relatorio::FALHA,
			'motivo'    => sprintf(
				/* translators: 1: quantidade de plugins de canal ativos, 2: os plugins, com diretório e arquivo principal. */
				__( '%1$d plugins de canal ATIVOS ao mesmo tempo neste site: %2$s. Dois diretórios de backup e DUAS chaves de desligamento — o operador fecha o canal em um e ele segue aberto pelo outro. Desative o que não for o complemento declarado e remova o diretório dele.', 'f3base' ),
				count( $complementos ),
				implode( ' · ', $nomeados )
			),
			'evidencia' => 'medida',
		);
	}

	/**
	 * Complementos ativos gravados pela unidade, normalizados para a mensagem.
	 *
	 * Existe para que a derivação acima não repita cinco `(string)` por campo em
	 * cada ramo — e para que um registro com forma inesperada não vire aviso do
	 * PHP no meio de uma linha de relatório.
	 *
	 * @param array<string,mixed> $fatos Fatos gravados pela unidade.
	 * @return array<int,array{arquivo:string,diretorio:string,slug:string,nome:string,por:string}>
	 */
	private static function complementos_normalizados( array $fatos ): array {
		$saida = array();

		foreach ( (array) ( $fatos['complementos_ativos'] ?? array() ) as $bruto ) {
			if ( ! is_array( $bruto ) ) {
				continue;
			}

			$saida[] = array(
				'arquivo'   => (string) ( $bruto['arquivo'] ?? '' ),
				'diretorio' => (string) ( $bruto['diretorio'] ?? '' ),
				'slug'      => (string) ( $bruto['slug'] ?? '' ),
				'nome'      => (string) ( $bruto['nome'] ?? '' ),
				'por'       => (string) ( $bruto['por'] ?? '' ),
			);
		}

		return $saida;
	}

	/**
	 * Diretório do plugin, ou a declaração de que ele não tem um.
	 *
	 * @param string $diretorio Diretório observado, possivelmente vazio.
	 * @return string
	 */
	private static function diretorio_nomeado( string $diretorio ): string {
		return '' !== $diretorio
			? $diretorio
			: __( '(sem diretório próprio: arquivo solto na raiz de wp-content/plugins)', 'f3base' );
	}

	/**
	 * Slug do plugin declarado com um papel do canal MCP.
	 *
	 * O nome do servidor e o do complemento saem da CONFIGURAÇÃO, pelo papel
	 * declarado. Nenhuma lista literal no código decide qual plugin é o servidor
	 * do canal — e nomear o plugin errado numa mensagem de BLOCKED é mandar o
	 * operador procurar no lugar errado.
	 *
	 * @param string $papel Papel declarado (`canal-mcp-servidor`, `canal-mcp-complemento`).
	 * @return string Slug, ou vazio quando a configuração não declara aquele papel.
	 */
	public static function slug_por_papel( string $papel ): string {
		foreach ( array( 'plugins.instalaveis', 'plugins.embarcados' ) as $lista ) {
			foreach ( F3Base_Imp_Config::lista( $lista ) as $indice => $entrada ) {
				unset( $entrada );

				if ( $papel === (string) F3Base_Imp_Config::obter( $lista . '.' . $indice . '.papel', '' ) ) {
					return (string) F3Base_Imp_Config::obter( $lista . '.' . $indice . '.slug', '' );
				}
			}
		}

		return '';
	}

	/**
	 * Habilidades/rotas REGISTRADAS, com a fonte de verdade que achou cada uma.
	 *
	 * Duas fontes, e elas respondem perguntas diferentes — misturá-las numa
	 * contagem só é a linha única por fonte de verdade que o método proíbe:
	 *
	 * - **Abilities API**: a habilidade está registrada no site. Registrada NÃO
	 *   quer dizer alcançável por MCP.
	 * - **Rota REST**: o namespace responde no servidor REST.
	 *
	 * Cada rota volta com a(s) fonte(s) que a encontrou, para que a mensagem
	 * possa dizer o que foi observado em vez de afirmar mais do que mediu.
	 *
	 * @return array<string,array<int,string>> Rota curta => fontes que a acharam.
	 */
	public static function habilidades_registradas(): array {
		$saida = array();

		foreach ( self::rotas_registradas() as $rota => $namespace ) {
			$saida[ (string) $rota ]   = $saida[ (string) $rota ] ?? array();
			$saida[ (string) $rota ][] = sprintf(
				/* translators: %s: namespace REST que registra a rota. */
				__( 'rota REST em %s', 'f3base' ),
				(string) $namespace
			);
		}

		/*
		 * A Abilities API pode não existir nesta instalação, e isso NÃO é erro:
		 * é uma fonte a menos, declarada como tal na mensagem. Inventar um
		 * fallback que finge tê-la lido seria pior do que não lê-la.
		 */
		if ( ! function_exists( 'wp_get_abilities' ) ) {
			return $saida;
		}

		foreach ( (array) wp_get_abilities() as $chave => $habilidade ) {
			$nome = is_object( $habilidade ) && method_exists( $habilidade, 'get_name' )
				? (string) $habilidade->get_name()
				: (string) $chave;

			foreach ( self::rotas_do_complemento() as $rota ) {
				if ( $nome === $rota || str_ends_with( $nome, '/' . $rota ) || str_ends_with( str_replace( '-', '/', $nome ), '/' . $rota ) ) {
					$saida[ $rota ]   = $saida[ $rota ] ?? array();
					$saida[ $rota ][] = sprintf(
						/* translators: %s: nome completo da habilidade registrada. */
						__( 'habilidade %s na Abilities API', 'f3base' ),
						$nome
					);
				}
			}
		}

		return $saida;
	}

	/**
	 * MEDIÇÃO ÚNICA do canal. Fatos observados, e nenhum veredito.
	 *
	 * Separada da derivação de propósito: enquanto medir e decidir moravam
	 * juntos, cada lugar que precisava do veredito acabava medindo de novo — e
	 * duas medições do mesmo fato, feitas por caminhos diferentes (Abilities API
	 * mais rota REST de um lado, só rota REST do outro), foi exatamente o que
	 * pôs OK na linha 14 e FALHA na linha 41 do mesmo relatório.
	 *
	 * @return array{esperadas:array<int,string>,achadas:array<int,string>,faltam:array<int,string>,rotas_de_arquivo:array<int,string>,fontes_de_arquivo:array<int,string>,censo_de_plugins:bool,complementos_ativos:array<int,array<string,string>>,nome_complemento:string,slug_servidor:string,slug_complemento:string,arquivo_servidor:string,servidor_ativo:bool}
	 */
	public static function medir_canal(): array {
		$esperadas   = self::rotas_do_complemento();
		$registradas = self::habilidades_registradas();

		$achadas = array();
		$faltam  = array();

		foreach ( $esperadas as $rota ) {
			if ( isset( $registradas[ $rota ] ) ) {
				$achadas[] = $rota . ' (' . implode( ', ', array_unique( $registradas[ $rota ] ) ) . ')';
				continue;
			}

			$faltam[] = $rota;
		}

		$slug_servidor    = self::slug_por_papel( 'canal-mcp-servidor' );
		$arquivo_servidor = '' === $slug_servidor ? '' : F3Base_Imp_Plugins::arquivo_principal( $slug_servidor );

		$rotas_de_arquivo = array();

		foreach ( $esperadas as $rota ) {
			if ( str_starts_with( $rota, 'files/' ) && isset( $registradas[ $rota ] ) ) {
				$rotas_de_arquivo[] = $rota;
			}
		}

		/*
		 * O CENSO DE PLUGINS ATIVOS é o que responde à pergunta de
		 * `mcp.canal_unico`, e por isso ele é medido AQUI, junto com o resto do
		 * canal, e viaja nos fatos. A pergunta não é "quem registrou cada
		 * habilidade" — essa não tem resposta, e é a fonte do defeito da 1.0.8.
		 */
		$slug_complemento = self::slug_por_papel( 'canal-mcp-complemento' );
		$censo            = self::censo_de_plugins();
		$nome_complemento = self::nome_do_plugin( $censo['instalados'], $slug_complemento );

		return array(
			'esperadas'         => $esperadas,
			'achadas'           => $achadas,
			'faltam'            => $faltam,
			'rotas_de_arquivo'  => $rotas_de_arquivo,
			'fontes_de_arquivo' => self::fontes_das_rotas_de_arquivo(),
			'censo_de_plugins'  => $censo['disponivel'],
			'complementos_ativos' => self::complementos_de_canal( $censo['instalados'], $slug_complemento, $nome_complemento ),
			'nome_complemento'  => $nome_complemento,
			'slug_servidor'     => $slug_servidor,
			'slug_complemento'  => $slug_complemento,
			'arquivo_servidor'  => $arquivo_servidor,
			'servidor_ativo'    => '' !== $arquivo_servidor && is_plugin_active( $arquivo_servidor ),
		);
	}

	/**
	 * As FONTES que responderam por `files/*` — e elas NÃO atribuem plugin.
	 *
	 * O NOME DESTA FUNÇÃO É A CORREÇÃO. Ela se chamava
	 * `registradores_de_arquivo()` e devolvia uma lista de "registradores"; o
	 * relatório de 1.0.8 imprimiu, com essa lista, a frase *"as 9 rota(s) de
	 * arquivo que a unidade mediu não têm registrador único: Abilities
	 * files/list, Abilities files/read, …"*. Leia os dados que a própria linha
	 * imprime: nove rotas, UMA fonte cada, e nenhum segundo plugin nomeado. O
	 * que a lista continha não eram registradores — eram as ROTAS repetidas com
	 * o nome da fonte na frente.
	 *
	 * A causa: **a Abilities API não expõe qual plugin registrou cada
	 * habilidade.** `wp_get_abilities()` devolve as habilidades, não a origem
	 * delas; o prefixo do nome é convenção do fornecedor, não procedência. O
	 * namespace REST tem o mesmo limite: quem escolhe o namespace é quem
	 * registra, dois plugins podem registrar no mesmo e um plugin pode registrar
	 * vários. Nenhuma das duas fontes atribui plugin — e atribuir por elas era
	 * o instrumento afirmando no diagnóstico o que não mediu.
	 *
	 * O que sobra, e que é verdadeiro, é isto: as fontes que ACHARAM cada rota.
	 * Serve para o operador saber por onde a rota respondeu. Não serve, e não é
	 * usado, para contar plugins — quem responde a essa pergunta é
	 * `complementos_de_canal()`, que conta PLUGINS ATIVOS.
	 *
	 * @return array<int,string> Fontes observadas, sem repetição.
	 */
	public static function fontes_das_rotas_de_arquivo(): array {
		$fontes = array();

		foreach ( self::rotas_registradas() as $rota => $namespace ) {
			if ( str_starts_with( (string) $rota, 'files/' ) ) {
				$fontes[ 'REST ' . (string) $namespace ] = true;
			}
		}

		if ( ! function_exists( 'wp_get_abilities' ) ) {
			return array_keys( $fontes );
		}

		foreach ( (array) wp_get_abilities() as $chave => $habilidade ) {
			$nome = is_object( $habilidade ) && method_exists( $habilidade, 'get_name' )
				? (string) $habilidade->get_name()
				: (string) $chave;

			foreach ( self::rotas_do_complemento() as $rota ) {
				if ( ! str_starts_with( $rota, 'files/' ) ) {
					continue;
				}

				$normalizado = str_replace( '-', '/', $nome );

				if ( $nome === $rota || str_ends_with( $nome, '/' . $rota ) || str_ends_with( $normalizado, '/' . $rota ) ) {
					$fontes[ 'Abilities ' . $nome ] = true;
				}
			}
		}

		return array_keys( $fontes );
	}

	/**
	 * CENSO dos plugins instalados, com nome de cabeçalho e estado de ativação.
	 *
	 * Fonte única do censo: `F3Base_Imp_Plugins::inventario()`, a mesma lista
	 * que o preflight e o relatório usam. `disponivel` é o que separa "medi e
	 * não achei nenhum" de "não consegui medir" — e é essa distinção que
	 * sustenta a regra do contrato: pré-condição ausente é BLOCKED, nunca FALHA.
	 *
	 * @return array{disponivel:bool,instalados:array<string,array{slug:string,nome:string,ativo:bool}>}
	 */
	public static function censo_de_plugins(): array {
		if ( ! function_exists( 'get_plugins' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( ! function_exists( 'get_plugins' ) ) {
			return array(
				'disponivel' => false,
				'instalados' => array(),
			);
		}

		$instalados = array();

		foreach ( F3Base_Imp_Plugins::inventario() as $item ) {
			$instalados[ (string) $item['arquivo'] ] = array(
				'slug'  => (string) $item['slug'],
				'nome'  => (string) $item['nome'],
				'ativo' => (bool) $item['ativo'],
			);
		}

		return array(
			'disponivel' => true,
			'instalados' => $instalados,
		);
	}

	/**
	 * `Plugin Name` do plugin instalado sob um slug, ou vazio.
	 *
	 * Existe porque a segunda cópia de um plugin costuma chegar com OUTRO slug
	 * de diretório e o MESMO cabeçalho `Plugin Name` — é assim que ela aparece
	 * na lista do WordPress, e é por esse nome que ela é reconhecível.
	 *
	 * @param array<string,array{slug:string,nome:string,ativo:bool}> $instalados Censo.
	 * @param string                                                  $slug       Slug procurado.
	 * @return string
	 */
	public static function nome_do_plugin( array $instalados, string $slug ): string {
		if ( '' === $slug ) {
			return '';
		}

		foreach ( $instalados as $dados ) {
			if ( is_array( $dados ) && $slug === (string) ( $dados['slug'] ?? '' ) ) {
				return (string) ( $dados['nome'] ?? '' );
			}
		}

		return '';
	}

	/**
	 * PLUGINS DE CANAL ATIVOS — a medição que responde à pergunta real.
	 *
	 * A pergunta de `mcp.canal_unico` nunca foi "quem registrou cada
	 * habilidade": é **"há mais de um plugin de canal ativo neste site?"**, e
	 * essa tem resposta, medida em duas passadas sobre o censo:
	 *
	 * 1. o plugin ATIVO cujo slug é o do papel `canal-mcp-complemento`
	 *    declarado na configuração;
	 * 2. qualquer plugin ATIVO cujo cabeçalho `Plugin Name` seja igual ao do
	 *    complemento declarado — que é exatamente a forma como uma SEGUNDA
	 *    CÓPIA com outro slug de diretório aparece.
	 *
	 * Inativo não entra: um diretório que o WordPress não carrega não abre canal
	 * nenhum. Foi por não medir isso que a 1.0.8 contou sete backups
	 * `.f3base-anterior-*` — ocultos, que `get_plugins()` nem lista — como se
	 * fossem canal aberto.
	 *
	 * Função PURA: o censo chega por parâmetro, e é isso que permite ao piso
	 * exercitar os três ramos sem WordPress.
	 *
	 * @param array<string,array{slug:string,nome:string,ativo:bool}> $instalados      Censo de plugins.
	 * @param string                                                  $slug_declarado  Slug do papel canal-mcp-complemento.
	 * @param string                                                  $nome_declarado  `Plugin Name` do complemento declarado.
	 * @return array<int,array{arquivo:string,diretorio:string,slug:string,nome:string,por:string}>
	 */
	public static function complementos_de_canal( array $instalados, string $slug_declarado, string $nome_declarado ): array {
		$achados = array();

		foreach ( $instalados as $arquivo => $dados ) {
			$arquivo = (string) $arquivo;
			$dados   = is_array( $dados ) ? $dados : array();

			if ( ! (bool) ( $dados['ativo'] ?? false ) ) {
				continue;
			}

			$slug = (string) ( $dados['slug'] ?? '' );
			$nome = (string) ( $dados['nome'] ?? '' );

			$por_papel = '' !== $slug_declarado && $slug === $slug_declarado;
			$por_nome  = '' !== $nome_declarado && $nome === $nome_declarado;

			if ( ! $por_papel && ! $por_nome ) {
				continue;
			}

			$achados[ $arquivo ] = array(
				'arquivo'   => $arquivo,
				'diretorio' => str_contains( $arquivo, '/' ) ? substr( $arquivo, 0, (int) strpos( $arquivo, '/' ) ) : '',
				'slug'      => $slug,
				'nome'      => $nome,
				'por'       => $por_papel
					? __( 'slug do papel canal-mcp-complemento declarado na configuração', 'f3base' )
					: __( 'mesmo cabeçalho Plugin Name do complemento declarado', 'f3base' ),
			);
		}

		ksort( $achados );

		return array_values( $achados );
	}

	/**
	 * UNIDADE `mcp`: mede uma vez, deriva os DOIS vereditos e grava os dois.
	 *
	 * Esta unidade existe por causa do que o operador viu na terceira execução:
	 * a tela do complemento dizendo "Servidor MCP não detectado" e nenhuma
	 * evidência do nosso lado, porque a única linha que responderia — a
	 * conferência do canal — tinha sido derrubada por uma cadeia de dependência
	 * grossa demais. Agora ela é unidade própria, sem dependência declarada, e
	 * roda sempre.
	 *
	 * A distinção que a mensagem preserva em todos os ramos: **rota registrada**
	 * e **rota exposta por MCP** são fatos diferentes. O estado que o operador
	 * está vendo é justamente o do meio — registradas e não expostas —, e ele
	 * precisa sair com esse nome, não como "canal incompleto".
	 *
	 * Este é o ÚNICO ponto do pacote que deriva os dois vereditos de canal.
	 * Quem precisar deles depois — a entrega, o encerramento — lê o registro da
	 * execução. `estatica.gate_fonte_unica` é o detector que impede o segundo.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	public static function etapa_canal_mcp(): array {
		$configurou = self::configurar_servidor_mcp();
		$medicao    = self::medir_canal();

		/*
		 * A MEDIÇÃO É GRAVADA ANTES DE QUALQUER DERIVAÇÃO. Quem precisar dos
		 * fatos depois — `mcp.canal_unico`, no gate de entrega — lê daqui em vez
		 * de medir de novo por outro caminho, que foi como o predicado de
		 * aplicabilidade passou a contradizer esta mesma unidade no mesmo
		 * relatório.
		 */
		self::registrar_medicao( self::UNIDADE_MCP, $medicao );

		$completo = array() === $medicao['faltam'] && array() !== $medicao['achadas'];

		$motivo_configurado = $completo
			? sprintf(
				/* translators: 1: quantidade esperada, 2: rotas encontradas com a fonte. */
				__( 'as %1$d rotas de arquivo e banco do complemento respondem, conferidas pelo NOME: %2$s.', 'f3base' ),
				count( $medicao['esperadas'] ),
				implode( '; ', $medicao['achadas'] )
			)
			: sprintf(
				/* translators: 1: rotas ausentes, 2: rotas encontradas, 3: slug do complemento. */
				__( 'canal incompleto — rotas ausentes: %1$s. Encontradas: %2$s. Quem as registra é o complemento %3$s; sem ele, quatro linhas da matriz de alocação não têm via de execução pelo agente, e o implantador é a única ferramenta de correção que resta.', 'f3base' ),
				array() === $medicao['faltam'] ? __( 'nenhuma nomeada', 'f3base' ) : implode( ', ', $medicao['faltam'] ),
				array() === $medicao['achadas'] ? __( 'nenhuma', 'f3base' ) : implode( '; ', $medicao['achadas'] ),
				'' !== $medicao['slug_complemento'] ? $medicao['slug_complemento'] : __( '(papel canal-mcp-complemento ausente na configuração)', 'f3base' )
			);

		$estado_configurado = F3Base_Imp_Relatorio::avaliar(
			$completo,
			'mcp.canal_configurado',
			$motivo_configurado,
			$motivo_configurado,
			array(
				'evidencia' => 'teste-funcional',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);

		self::registrar_veredito( 'mcp.canal_configurado', $estado_configurado, $motivo_configurado );

		/*
		 * O nome do veredito de exposição vem de QUEM O DERIVA, no `rotulo` que
		 * ele devolve — repeti-lo aqui faria deste ponto uma segunda menção
		 * derivante do mesmo nome, que é a forma embrionária do defeito que esta
		 * release fechou.
		 */
		$exposto = self::derivar_canal_exposto( $medicao, $configurou );

		self::registrar_veredito( $exposto['rotulo'], $exposto['estado'], $exposto['motivo'] );

		self::executar_autoteste( $medicao );
		self::declarar_recusa_de_credencial( $medicao );

		return $exposto;
	}

	/**
	 * Nome curto da rota de AUTOTESTE dentro do protocolo do canal.
	 *
	 * Ponto único: a rota é procurada, executada e nomeada a partir daqui. O
	 * README afirmava desde a 1.0.6 que ela "roda na entrega e após toda mudança
	 * de PHP ou de hospedagem, com o resultado no relatório", e até a 1.0.17 o
	 * pacote inteiro não tinha uma única chamada de execução de habilidade ou de
	 * rota: nem `wp_execute_ability`, nem `rest_do_request`. A afirmação existia,
	 * o resultado não.
	 */
	public const ROTA_AUTOTESTE = 'files/selftest';

	/**
	 * EXECUTA a rota de autoteste do canal e leva o resultado ao relatório.
	 *
	 * @param array<string,mixed> $medicao Fatos observados por `medir_canal()`.
	 * @return string Estado emitido.
	 */
	private static function executar_autoteste( array $medicao ): string {
		$namespace = (string) ( self::rotas_registradas()[ self::ROTA_AUTOTESTE ] ?? '' );
		$execucao  = '' === $namespace
			? array(
				'executou' => false,
				'codigo'   => 0,
				'corpo'    => array(),
				'erro'     => '',
				'via'      => '',
			)
			: self::despachar_autoteste( $namespace );

		$veredito = self::veredito_do_autoteste(
			'' !== $namespace,
			$execucao,
			'' !== (string) $medicao['slug_complemento'] ? (string) $medicao['slug_complemento'] : __( 'declarado com o papel canal-mcp-complemento (papel ausente na configuração)', 'f3base' )
		);

		self::registrar_veredito( 'mcp.autoteste', $veredito['estado'], $veredito['motivo'] );

		return F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'mcp.autoteste',
			$veredito['motivo'],
			array(
				'evidencia' => $veredito['evidencia'],
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);
	}

	/**
	 * DESPACHA a rota, pelas duas vias possíveis, e devolve o que ela respondeu.
	 *
	 * Duas vias, tentadas nesta ordem, e a que responder sai NOMEADA: a Abilities
	 * API quando o site a tiver (`wp_execute_ability`), e o servidor REST interno
	 * (`rest_do_request`) sempre. Não são a mesma coisa e o relatório não pode
	 * fingir que são: a primeira executa a habilidade registrada, a segunda
	 * despacha a rota. Nenhuma das duas passa por autenticação HTTP — este
	 * despacho roda como o usuário da requisição, que é o administrador, e é por
	 * isso que a prova de RECUSA é uma linha separada e BLOCKED.
	 *
	 * @param string $namespace Namespace REST em que a rota respondeu.
	 * @return array{executou:bool,codigo:int,corpo:array<string,mixed>,erro:string,via:string}
	 */
	private static function despachar_autoteste( string $namespace ): array {
		if ( function_exists( 'wp_execute_ability' ) ) {
			foreach ( (array) wp_get_abilities() as $chave => $habilidade ) {
				$nome = is_object( $habilidade ) && method_exists( $habilidade, 'get_name' )
					? (string) $habilidade->get_name()
					: (string) $chave;

				if ( $nome !== self::ROTA_AUTOTESTE
					&& ! str_ends_with( $nome, '/' . self::ROTA_AUTOTESTE )
					&& ! str_ends_with( str_replace( '-', '/', $nome ), '/' . self::ROTA_AUTOTESTE ) ) {
					continue;
				}

				$resultado = wp_execute_ability( $nome, array() );

				if ( is_wp_error( $resultado ) ) {
					return array(
						'executou' => true,
						'codigo'   => 0,
						'corpo'    => array(),
						'erro'     => $resultado->get_error_code() . ': ' . $resultado->get_error_message(),
						'via'      => sprintf(
							/* translators: %s: nome completo da habilidade. */
							__( 'Abilities API, habilidade %s', 'f3base' ),
							$nome
						),
					);
				}

				return array(
					'executou' => true,
					'codigo'   => 200,
					'corpo'    => is_array( $resultado ) ? $resultado : array( 'resultado' => $resultado ),
					'erro'     => '',
					'via'      => sprintf(
						/* translators: %s: nome completo da habilidade. */
						__( 'Abilities API, habilidade %s', 'f3base' ),
						$nome
					),
				);
			}
		}

		if ( ! function_exists( 'rest_do_request' ) ) {
			return array(
				'executou' => false,
				'codigo'   => 0,
				'corpo'    => array(),
				'erro'     => __( 'nem a Abilities API nem rest_do_request() existem nesta instalação: não há via de execução para a rota.', 'f3base' ),
				'via'      => '',
			);
		}

		$caminho = '/' . trim( $namespace, '/' ) . '/' . self::ROTA_AUTOTESTE;
		$via     = sprintf(
			/* translators: %s: caminho REST despachado. */
			__( 'servidor REST interno, rest_do_request( POST %s )', 'f3base' ),
			$caminho
		);

		$resposta = rest_do_request( new WP_REST_Request( 'POST', $caminho ) );

		if ( ! $resposta instanceof WP_REST_Response ) {
			return array(
				'executou' => false,
				'codigo'   => 0,
				'corpo'    => array(),
				'erro'     => __( 'o servidor REST não devolveu uma resposta analisável para o despacho da rota.', 'f3base' ),
				'via'      => $via,
			);
		}

		$dados = $resposta->get_data();

		return array(
			'executou' => true,
			'codigo'   => (int) $resposta->get_status(),
			'corpo'    => is_array( $dados ) ? $dados : array( 'resultado' => $dados ),
			'erro'     => '',
			'via'      => $via,
		);
	}

	/**
	 * VEREDITO PURO do autoteste: função sem WordPress, com piso nos ramos.
	 *
	 * Os pisos que esta função existe para sustentar, e são os dois que o
	 * roteiro da 1.0.18 exigiu por escrito:
	 *
	 * - **Autoteste que devolve falha REPROVA a entrega.** Rota que respondeu
	 *   dizendo que o canal está quebrado fecha FALHA, e o item mais importante
	 *   dela é a detecção de PHP quebrado: com ela inerte, gravar PHP pelo canal
	 *   passa a ser perigoso, e o relatório precisa dizer isso.
	 * - **Ausência da rota fecha BLOCKED, nunca OK.** Não medir e medir-e-passar
	 *   são fatos diferentes; foi exatamente a confusão entre os dois que
	 *   sustentou por doze releases a frase do README sobre um autoteste que
	 *   nunca rodou.
	 *
	 * Recusa do despacho por credencial (401/403) é BLOCKED, não FALHA: aí a
	 * rota existe e não respondeu porque a via interna não carrega credencial —
	 * pré-condição ausente, e não defeito medido.
	 *
	 * @param bool                                                                  $rota_presente A rota está registrada.
	 * @param array{executou:bool,codigo:int,corpo:array<string,mixed>,erro:string,via:string} $execucao      O que o despacho devolveu.
	 * @param string                                                                $complemento   Slug do complemento, para nomear o responsável.
	 * @return array{estado:string,motivo:string,evidencia:string}
	 */
	public static function veredito_do_autoteste( bool $rota_presente, array $execucao, string $complemento ): array {
		if ( ! $rota_presente ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: nome da rota, 2: slug do complemento. */
					__( 'pré-condição ausente: a rota %1$s NÃO está registrada neste site, então não há autoteste a executar e não há resultado a relatar. Quem a registra é o complemento %2$s. Ausência da rota fecha BLOCKED e nunca OK: não medir e medir-e-passar são fatos diferentes, e foi a confusão entre os dois que sustentou por doze releases a frase do README sobre um autoteste que nunca rodou.', 'f3base' ),
					self::ROTA_AUTOTESTE,
					$complemento
				),
				'evidencia' => 'pendencia-externa',
			);
		}

		if ( ! (bool) $execucao['executou'] ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: nome da rota, 2: motivo, 3: via tentada. */
					__( 'pré-condição ausente: a rota %1$s está registrada e o despacho não chegou a acontecer — %2$s Via tentada: %3$s.', 'f3base' ),
					self::ROTA_AUTOTESTE,
					'' !== (string) $execucao['erro'] ? (string) $execucao['erro'] : __( 'sem motivo devolvido pela via.', 'f3base' ),
					'' !== (string) $execucao['via'] ? (string) $execucao['via'] : __( 'nenhuma', 'f3base' )
				),
				'evidencia' => 'pendencia-externa',
			);
		}

		$codigo = (int) $execucao['codigo'];

		if ( 401 === $codigo || 403 === $codigo ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => sprintf(
					/* translators: 1: nome da rota, 2: código HTTP, 3: via usada. */
					__( 'pré-condição ausente: a rota %1$s existe e RECUSOU o despacho interno com código %2$d. A via usada (%3$s) não carrega credencial, e recusa por credencial é pré-condição ausente — não é o autoteste dizendo que o canal está quebrado. Para exercitá-la, execute a rota por HTTP com a Application Password do usuário dedicado.', 'f3base' ),
					self::ROTA_AUTOTESTE,
					$codigo,
					(string) $execucao['via']
				),
				'evidencia' => 'pendencia-externa',
			);
		}

		$leitura = self::ler_resultado_do_autoteste( is_array( $execucao['corpo'] ) ? $execucao['corpo'] : array() );

		if ( $codigo < 200 || $codigo >= 300 ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::FALHA,
				'motivo'    => sprintf(
					/* translators: 1: nome da rota, 2: código HTTP, 3: via usada, 4: itens lidos da resposta. */
					__( 'a rota %1$s respondeu com código %2$d. Via: %3$s. %4$s O autoteste é o que separa "o canal está aberto" de "o canal funciona", e uma resposta que não é 2xx é o canal dizendo que não funciona.', 'f3base' ),
					self::ROTA_AUTOTESTE,
					$codigo,
					(string) $execucao['via'],
					$leitura['resumo']
				),
				'evidencia' => 'teste-funcional',
			);
		}

		if ( ! $leitura['aprovado'] ) {
			return array(
				'estado'    => F3Base_Imp_Relatorio::FALHA,
				'motivo'    => sprintf(
					/* translators: 1: nome da rota, 2: itens reprovados, 3: via usada. */
					__( 'o autoteste do canal REPROVOU: %2$s (rota %1$s, via %3$s). Isto reprova a entrega. O item que mais importa é a detecção de PHP quebrado: com ela inerte, gravar PHP pelo canal passa a ser perigoso, porque o canal aceitaria o arquivo que derruba o site.', 'f3base' ),
					self::ROTA_AUTOTESTE,
					$leitura['resumo'],
					(string) $execucao['via']
				),
				'evidencia' => 'teste-funcional',
			);
		}

		return array(
			'estado'    => F3Base_Imp_Relatorio::OK,
			'motivo'    => sprintf(
				/* translators: 1: nome da rota, 2: via usada, 3: itens lidos da resposta. */
				__( 'o autoteste do canal RODOU nesta execução e passou — rota %1$s, via %2$s. %3$s O que esta linha NÃO afirma: ela roda como o administrador desta requisição e não exercita autenticação nenhuma; a prova de recusa para credencial não autorizada é mcp.autoteste_recusa_credencial, e ela fecha BLOCKED por fase.', 'f3base' ),
				self::ROTA_AUTOTESTE,
				(string) $execucao['via'],
				$leitura['resumo']
			),
			'evidencia' => 'teste-funcional',
		);
	}

	/**
	 * LÊ o resultado estruturado do autoteste, sem inventar vocabulário.
	 *
	 * O protocolo do complemento não é deste pacote, e adivinhar o nome do campo
	 * seria o instrumento afirmando o que não leu. A regra é conservadora e está
	 * escrita: qualquer chave booleana falsa, qualquer `status`/`resultado` com
	 * valor de reprovação, ou uma lista `falhas`/`errors` não vazia REPROVA; um
	 * corpo que não traga nenhum desses sinais é relatado como corpo sem veredito
	 * legível — e isso é aprovação da resposta HTTP, dito com essas palavras.
	 *
	 * @param array<string,mixed> $corpo Corpo devolvido pela rota.
	 * @return array{aprovado:bool,resumo:string}
	 */
	public static function ler_resultado_do_autoteste( array $corpo ): array {
		$reprovados = array();
		$lidos      = array();
		$reprovacao = array( 'fail', 'failed', 'failure', 'error', 'erro', 'ko', 'nok', 'reprovado', 'falha', 'broken' );

		foreach ( $corpo as $chave => $valor ) {
			$chave = (string) $chave;

			if ( is_bool( $valor ) ) {
				$lidos[] = $chave . '=' . ( $valor ? 'true' : 'false' );

				if ( ! $valor ) {
					$reprovados[] = $chave;
				}

				continue;
			}

			if ( is_string( $valor ) ) {
				$lidos[] = $chave . '=' . $valor;

				if ( in_array( strtolower( trim( $valor ) ), $reprovacao, true ) ) {
					$reprovados[] = $chave . '=' . $valor;
				}

				continue;
			}

			if ( is_array( $valor ) && in_array( $chave, array( 'falhas', 'errors', 'erros', 'failures' ), true ) ) {
				$lidos[] = $chave . '=' . count( $valor ) . ' item(ns)';

				if ( array() !== $valor ) {
					$reprovados[] = $chave . ' com ' . count( $valor ) . ' item(ns)';
				}

				continue;
			}

			if ( is_scalar( $valor ) ) {
				$lidos[] = $chave . '=' . (string) $valor;
			}
		}

		if ( array() !== $reprovados ) {
			return array(
				'aprovado' => false,
				'resumo'   => sprintf(
					/* translators: 1: itens reprovados, 2: tudo o que foi lido do corpo. */
					__( 'item(ns) do autoteste em reprovação: %1$s. Corpo lido: %2$s.', 'f3base' ),
					implode( ', ', $reprovados ),
					array() === $lidos ? __( 'nenhum campo legível', 'f3base' ) : implode( ' · ', $lidos )
				),
			);
		}

		if ( array() === $lidos ) {
			return array(
				'aprovado' => true,
				'resumo'   => __( 'A resposta veio sem campo legível: o que esta linha mede é que a rota respondeu 2xx, e nada além disso — o vocabulário do corpo é do complemento, e adivinhá-lo seria afirmar o que não foi lido.', 'f3base' ),
			);
		}

		return array(
			'aprovado' => true,
			'resumo'   => sprintf(
				/* translators: %s: campos lidos do corpo, com o valor de cada um. */
				__( 'Resultado estruturado lido da resposta: %s.', 'f3base' ),
				implode( ' · ', $lidos )
			),
		);
	}

	/**
	 * A prova de RECUSA para credencial não autorizada: BLOCKED de fase.
	 *
	 * Avaliado, e a resposta é não: **não é mensurável de dentro do WordPress
	 * rodando como administrador.** Tanto `wp_execute_ability()` quanto
	 * `rest_do_request()` despacham dentro do processo, com o usuário da
	 * requisição já autenticado; nenhum dos dois passa pela autenticação HTTP,
	 * que é justamente o que uma credencial não autorizada exercitaria. Forjar
	 * um usuário sem capacidade e despachar de novo mediria o
	 * `permission_callback` — e chamar isso de "prova de recusa de credencial"
	 * seria inventar uma prova fraca e batizá-la de negativa, que é pior do que
	 * declarar a pendência.
	 *
	 * Então ela sai como BLOCKED de FASE, nomeando o que falta.
	 *
	 * @param array<string,mixed> $medicao Fatos observados por `medir_canal()`.
	 * @return string Estado emitido.
	 */
	private static function declarar_recusa_de_credencial( array $medicao ): string {
		return F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'mcp.autoteste_recusa_credencial',
			sprintf(
				/* translators: 1: nome da rota, 2: slug do servidor do canal. */
				__( 'pendência de FASE, nomeada: a recusa de %1$s a uma credencial NÃO autorizada não é mensurável deste lado. As duas vias de execução que este host tem — wp_execute_ability() e rest_do_request() — despacham DENTRO do processo, com o usuário da requisição já autenticado como administrador, e nenhuma delas passa pela autenticação HTTP que uma credencial não autorizada exercitaria. Falta: uma requisição HTTP de fora, ao servidor %2$s, com uma credencial que NÃO tenha a capacidade exigida, e a resposta 401 ou 403 observada na ponta. Forjar um usuário sem capacidade e despachar internamente mediria o permission_callback, não a credencial — seria uma prova fraca com nome de prova negativa, e é por isso que esta linha é BLOCKED em vez de OK.', 'f3base' ),
				self::ROTA_AUTOTESTE,
				'' !== (string) $medicao['slug_servidor'] ? (string) $medicao['slug_servidor'] : __( 'declarado com o papel canal-mcp-servidor (papel ausente na configuração)', 'f3base' )
			),
			array(
				'evidencia' => 'pendencia-externa',
				'fase'      => 'producao',
				'gate'      => 'fase',
			)
		);
	}

	/**
	 * Deriva o veredito de EXPOSIÇÃO a partir da medição única.
	 *
	 * @param array<string,mixed> $medicao    Fatos observados por `medir_canal()`.
	 * @param string              $configurou Frase da configuração declarada, já resolvida.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function derivar_canal_exposto( array $medicao, string $configurou ): array {
		$rotulo    = 'mcp.canal_exposto';
		$esperadas = (array) $medicao['esperadas'];
		$achadas   = (array) $medicao['achadas'];
		$faltam    = (array) $medicao['faltam'];

		/* Nenhuma das doze registrada: o complemento é quem as registra. */
		if ( 0 === count( $achadas ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => $rotulo,
				'motivo' => sprintf(
					/* translators: 1: quantidade esperada, 2: slug do complemento, 3: resultado da configuração declarada. */
					__( 'nenhuma das %1$d rotas de arquivo e banco está REGISTRADA neste site: nem como habilidade da Abilities API, nem como rota REST. Quem as registra é o complemento %2$s — sem ele não há o que expor, e a pergunta sobre o servidor MCP nem chega a se colocar. %3$s', 'f3base' ),
					count( $esperadas ),
					'' !== (string) $medicao['slug_complemento'] ? (string) $medicao['slug_complemento'] : __( 'declarado com o papel canal-mcp-complemento (papel ausente na configuração)', 'f3base' ),
					$configurou
				),
			);
		}

		if ( array() !== $faltam ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => $rotulo,
				'motivo' => sprintf(
					/* translators: 1: rotas ausentes, 2: rotas achadas com a fonte, 3: slug do complemento, 4: resultado da configuração. */
					__( 'registro INCOMPLETO: faltam %1$s. Registradas: %2$s. O complemento %3$s registra as doze; com parte delas o canal não fecha, e registrada continua sendo coisa diferente de exposta por MCP. %4$s', 'f3base' ),
					implode( ', ', $faltam ),
					implode( '; ', $achadas ),
					'' !== (string) $medicao['slug_complemento'] ? (string) $medicao['slug_complemento'] : __( '(papel canal-mcp-complemento ausente na configuração)', 'f3base' ),
					$configurou
				),
			);
		}

		/* O estado que o operador está vendo agora: registradas e não expostas. */
		if ( ! (bool) $medicao['servidor_ativo'] ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => $rotulo,
				'motivo' => sprintf(
					/* translators: 1: quantidade registrada, 2: slug do servidor esperado, 3: situação do plugin servidor, 4: resultado da configuração. */
					__( 'Servidor MCP não detectado. As %1$d rotas estão REGISTRADAS neste site, e nenhum servidor MCP as EXPÕE: rota registrada na Abilities API e rota exposta por MCP são fatos diferentes, e é o segundo que falta. O servidor esperado é o plugin %2$s, declarado com o papel canal-mcp-servidor — %3$s. Enquanto ele não estiver ativo e expondo, o agente não alcança nenhuma das doze. %4$s', 'f3base' ),
					count( $achadas ),
					'' !== (string) $medicao['slug_servidor'] ? (string) $medicao['slug_servidor'] : __( 'não declarado na configuração', 'f3base' ),
					'' === (string) $medicao['slug_servidor']
						? __( 'a configuração não declara nenhum plugin com esse papel', 'f3base' )
						: ( '' === (string) $medicao['arquivo_servidor']
							? __( 'ele não está instalado neste site', 'f3base' )
							: __( 'ele está instalado e NÃO está ativo', 'f3base' ) ),
					$configurou
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'rotulo' => $rotulo,
			'motivo' => sprintf(
				/* translators: 1: quantidade registrada, 2: slug do servidor ativo, 3: rotas com a fonte, 4: resultado da configuração. */
				__( 'as %1$d rotas de arquivo e banco estão registradas E há servidor MCP ativo expondo-as: %2$s. Registradas, com a fonte que achou cada uma: %3$s. %4$s', 'f3base' ),
				count( $achadas ),
				(string) $medicao['slug_servidor'],
				implode( '; ', $achadas ),
				$configurou
			),
		);
	}

	/**
	 * Configuração declarada do servidor MCP, gravada pelo gravador único.
	 *
	 * O mapa é `plugins.configuracao_servidor_mcp`: option → chave → valor. Ele
	 * nasce VAZIO e mapa vazio não grava nada — e isso não é erro, é o estado
	 * normal de um pacote que não conhece as chaves do fornecedor. Os nomes de
	 * chave NÃO são inventados aqui: quem os conhece é a documentação do
	 * servidor, e é o projeto que os declara quando precisar.
	 *
	 * @return string Frase para a mensagem da unidade, sempre presente.
	 */
	private static function configurar_servidor_mcp(): string {
		$mapa = F3Base_Imp_Config::obter( 'plugins.configuracao_servidor_mcp', array() );
		$mapa = is_array( $mapa ) ? $mapa : array();

		if ( array() === $mapa ) {
			return __( 'Configuração declarada do servidor: plugins.configuracao_servidor_mcp está vazio, então nada foi gravado — mapa vazio é o padrão do pacote e não é erro; os nomes de chave vêm do fornecedor do servidor.', 'f3base' );
		}

		$partes = array();

		foreach ( $mapa as $option => $chaves ) {
			$option = (string) $option;
			$chaves = is_array( $chaves ) ? $chaves : array();

			if ( array() === $chaves ) {
				$partes[] = sprintf(
					/* translators: %s: nome da option declarada sem chaves. */
					__( '%s declarada sem chave alguma: nada a gravar', 'f3base' ),
					$option
				);
				continue;
			}

			$resultado    = F3Base_Imp_Gravador::gravar_chaves( $option, $chaves );
			$descartadas  = ( isset( $resultado['descartadas'] ) && is_array( $resultado['descartadas'] ) ) ? $resultado['descartadas'] : array();

			$partes[] = sprintf(
				/* translators: 1: option, 2: quantidade de chaves, 3: chaves descartadas na leitura de volta. */
				__( '%1$s: %2$d chave(s) gravadas e relidas; descartadas pelo destino: %3$s', 'f3base' ),
				$option,
				count( $chaves ),
				array() === $descartadas ? __( 'nenhuma', 'f3base' ) : implode( ', ', $descartadas )
			);
		}

		return sprintf(
			/* translators: %s: resultado por option. */
			__( 'Configuração declarada do servidor, gravada pelo gravador único com leitura de volta — %s.', 'f3base' ),
			implode( ' | ', $partes )
		);
	}

	/**
	 * Rotas de arquivo e banco registradas, mapeadas para o namespace.
	 *
	 * A descoberta é do próprio servidor REST: `rest_get_server()` instancia e
	 * dispara `rest_api_init`, então as rotas existem mesmo fora de uma
	 * requisição REST.
	 *
	 * @return array<string,string> Rota curta => namespace.
	 */
	public static function rotas_registradas(): array {
		if ( ! function_exists( 'rest_get_server' ) ) {
			return array();
		}

		$servidor = rest_get_server();

		if ( ! $servidor instanceof WP_REST_Server ) {
			return array();
		}

		$saida = array();

		foreach ( array_keys( $servidor->get_routes() ) as $rota ) {
			$rota = (string) $rota;

			if ( 1 !== preg_match( '#^/([^/]+(?:/[^/]+)*?)/((?:files|db)/[a-z_]+)$#', $rota, $casamento ) ) {
				continue;
			}

			$saida[ $casamento[2] ] = $casamento[1];
		}

		return $saida;
	}

	/**
	 * Hash do pacote: caminhos relativos e hashes de conteúdo, ordenados.
	 *
	 * @return string
	 */
	public static function hash_do_pacote(): string {
		$raiz = rtrim( str_replace( '\\', '/', F3BASE_IMP_DIR ), '/' ) . '/';

		if ( ! is_dir( $raiz ) ) {
			return '';
		}

		$itens    = array();
		$iterador = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ) );

		foreach ( $iterador as $arquivo ) {
			if ( ! $arquivo instanceof SplFileInfo || ! $arquivo->isFile() ) {
				continue;
			}

			$absoluto = str_replace( '\\', '/', (string) $arquivo->getPathname() );
			$relativo = substr( $absoluto, strlen( $raiz ) );

			if ( self::REGISTRO_RODADA === $relativo ) {
				/*
				 * O PROBLEMA CIRCULAR, resolvido por construção: o registro da
				 * rodada mora DENTRO do pacote cujo hash ele declara. Ele fica
				 * FORA da soma — dos dois lados, aqui e no comando único que o
				 * grava — e por isso escrevê-lo não muda o número que ele
				 * carrega. Sem esta linha, todo registro nasceria divergente.
				 */
				continue;
			}

			$itens[] = $relativo . ':' . (string) hash_file( 'sha256', $absoluto );
		}

		sort( $itens );

		return hash( 'sha256', implode( "\n", $itens ) );
	}

	/**
	 * A autodesativação está autorizada?
	 *
	 * Três condições, todas mensuráveis NO HOST: `SUCESSO_APLICACAO`, nenhum dos
	 * entregáveis de `entregaveis_do_gate_de_aplicacao()` em BLOCKED, e os
	 * vereditos de `gates_do_canal()` — o canal COMPLETO e o canal EXPOSTO — em
	 * OK. O canal entrou depois do caso medido em que as doze rotas estavam
	 * registradas, o canal fechava OK, e nenhum servidor MCP as expunha.
	 *
	 * O QUE NÃO DECIDE MAIS: `gates_de_fase()`. A versão anterior varria o mapa
	 * pelo PREFIXO `entrega.` e assim `entrega.rodada_limpa` — fato da suíte
	 * externa, que não roda no host — proibia a autodesativação em toda
	 * instalação, para sempre, por desenho. Ela continua sendo medida, nomeada e
	 * impressa; ela só não segura mais a ferramenta de correção no ar. Varrer por
	 * prefixo era a fusão: a lista de nomes é a separação.
	 *
	 * Esta função CONSULTA vereditos; ela não deriva nenhum. Os nomes vêm das
	 * funções âncora e os estados vêm do mapa que o chamador leu do registro da
	 * execução — foi o `mcp.canal_configurado` recalculado aqui do lado que
	 * produziu o relatório contradizendo a si mesmo.
	 *
	 * @param string               $estado_aplicacao Estado da máquina.
	 * @param array<string,string> $entregaveis      Estados por checagem de entrega e de canal.
	 * @return array{pode:bool,motivo:string}
	 */
	public static function pode_autodesativar( string $estado_aplicacao, array $entregaveis ): array {
		$sucesso = F3Base_Imp_Lotes::SUCESSO === $estado_aplicacao;

		$bloqueados = array();

		foreach ( self::entregaveis_do_gate_de_aplicacao() as $entregavel ) {
			$estado_do_entregavel = isset( $entregaveis[ $entregavel ] ) ? (string) $entregaveis[ $entregavel ] : '';

			if ( F3Base_Imp_Relatorio::BLOCKED === $estado_do_entregavel ) {
				$bloqueados[] = $entregavel;
			}
		}

		/*
		 * Pendência de FASE: nomeada no motivo, nunca somada ao gate. Ignorar
		 * seria a outra metade do erro — a evidência externa continua visível.
		 */
		$pendencias_de_fase = array();

		foreach ( self::gates_de_fase() as $gate_de_fase ) {
			$estado_da_fase = isset( $entregaveis[ $gate_de_fase ] ) ? (string) $entregaveis[ $gate_de_fase ] : '';

			if ( F3Base_Imp_Relatorio::OK !== $estado_da_fase ) {
				$pendencias_de_fase[] = $gate_de_fase . ' (' . ( '' !== $estado_da_fase ? $estado_da_fase : __( 'sem estado lido', 'f3base' ) ) . ')';
			}
		}

		$abertos = array();

		foreach ( self::gates_do_canal() as $gate ) {
			$estado = isset( $entregaveis[ $gate ] ) ? (string) $entregaveis[ $gate ] : '';

			if ( F3Base_Imp_Relatorio::OK !== $estado ) {
				$abertos[] = sprintf(
					/* translators: 1: nome do veredito de canal, 2: estado lido do registro da execução. */
					__( '%1$s fechou %2$s no registro desta execução', 'f3base' ),
					$gate,
					'' !== $estado ? $estado : __( 'sem estado lido', 'f3base' )
				);
			}
		}

		$pode = $sucesso && array() === $bloqueados && array() === $abertos;

		/*
		 * O ESCOPO SAI JUNTO COM O VEREDITO, e é a segunda metade da correção da
		 * 1.0.18. Deriva-la do metadado resolve a DIVERGÊNCIA entre as duas
		 * fontes; sem nomear o escopo, as duas frases continuariam parecendo
		 * contraditórias mesmo concordando — a linha da 1.0.17 dizia "Nenhuma
		 * pendência de fase em aberto" (escopo: os gates de fase da execução) ao
		 * lado de "Pendência(s) de FASE dentro desta unidade — 1" (escopo: as
		 * internas daquela unidade), e quem lê não tinha como saber que os dois
		 * números contavam coisas diferentes.
		 */
		$gates_de_fase = self::gates_de_fase();

		$nota_de_fase = array() === $pendencias_de_fase
			? sprintf(
				/* translators: 1: quantidade de gates de fase da execução, 2: os nomes. */
				__( 'Nenhum GATE DE FASE em aberto — escopo: os %1$d gate(s) de fase desta execução, derivados do metadado gate=fase e não de lista escrita à mão (%2$s). Este escopo não é o das pendências de fase DENTRO de cada unidade, que saem nomeadas na linha da própria unidade.', 'f3base' ),
				count( $gates_de_fase ),
				array() === $gates_de_fase ? __( 'nenhum emissor declarou gate=fase nesta execução', 'f3base' ) : implode( ', ', $gates_de_fase )
			)
			: sprintf(
				/* translators: 1: pendências de fase, com o estado de cada uma, 2: quantidade de gates de fase da execução. */
				__( 'GATE(S) DE FASE em aberto, declarado(s) e NÃO somado(s) a este gate: %1$s — evidência que este host não produz trava o gate da fase, não a ferramenta. Escopo: os %2$d gate(s) de fase desta execução, derivados do metadado gate=fase; não é o escopo das pendências de fase dentro de cada unidade.', 'f3base' ),
				implode( '; ', $pendencias_de_fase ),
				count( $gates_de_fase )
			);

		if ( $pode ) {
			return array(
				'pode'   => true,
				'motivo' => sprintf(
					/* translators: 1: entregáveis do gate de aplicação, pelo nome, 2: vereditos de canal consultados, pelo nome, 3: nota sobre as pendências de fase. */
					__( 'as três condições do GATE DE APLICAÇÃO fecham, e todas são mensuráveis no host: SUCESSO_APLICACAO; nenhum dos entregáveis %1$s em BLOCKED; e os vereditos de canal %2$s em OK, lidos do registro da execução e não recalculados aqui. %3$s', 'f3base' ),
					implode( ', ', self::entregaveis_do_gate_de_aplicacao() ),
					implode( ', ', self::gates_do_canal() ),
					$nota_de_fase
				),
			);
		}

		$partes = array();

		if ( ! $sucesso ) {
			$partes[] = sprintf(
				/* translators: %s: estado observado. */
				__( 'o estado da aplicação é %s, não SUCESSO_APLICACAO', 'f3base' ),
				$estado_aplicacao
			);
		}

		if ( array() !== $bloqueados ) {
			$partes[] = sprintf(
				/* translators: %s: entregáveis do gate de aplicação em BLOCKED, pelo nome. */
				__( 'entregáveis do gate de aplicação em BLOCKED: %s', 'f3base' ),
				F3Base_Imp_Relatorio::nomes_em( F3Base_Imp_Relatorio::BLOCKED, $bloqueados )
			);
		}

		if ( array() !== $abertos ) {
			$partes[] = sprintf(
				/* translators: %s: vereditos de canal em aberto, com o estado lido. */
				__( 'vereditos de canal fora de OK, lidos do registro da execução e não recalculados: %s — rota registrada e rota exposta são fatos diferentes, e sair do ar com qualquer um deles em aberto deixaria o site sem ferramenta de correção e sem canal', 'f3base' ),
				implode( '; ', $abertos )
			);
		}

		return array(
			'pode'   => false,
			'motivo' => sprintf(
				/* translators: 1: motivos acumulados, 2: nota sobre as pendências de fase. */
				__( 'o implantador permanece ativo porque %1$s. A ferramenta de correção não sai do ar antes de a entrega existir. %2$s', 'f3base' ),
				implode( '; ', $partes ),
				$nota_de_fase
			),
		);
	}
}
