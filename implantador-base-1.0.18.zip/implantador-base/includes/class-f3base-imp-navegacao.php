<?php
/**
 * Navegação como entidade, não como markup.
 *
 * Em tema de blocos não existe "localização de menu" de tema clássico. Com
 * manutenção pós-entrega por agente, quem edita o menu é o agente, e o padrão é
 * o bloco Navigation apontando para um post `wp_navigation`: o menu vira um
 * objeto único no banco, editável por rota tipada, e duas páginas divergirem de
 * menu deixa de ser fisicamente possível porque só existe uma cópia.
 *
 * O `ref` é um ID de post, diferente em cada instalação: fixo no arquivo do
 * tema, quebra a instalação limpa; ausente, o WordPress cai no fallback de lista
 * de páginas. Por isso o implantador ESCREVE o ID em `f3base_nav_id` e o tema
 * LÊ — e a leitura de volta confere as duas pontas.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Criação idempotente do post de navegação.
 */
final class F3Base_Imp_Navegacao {

	/**
	 * Option lida pelo tema.
	 */
	public const OPTION = 'f3base_nav_id';

	/**
	 * Tipo de post da navegação.
	 */
	public const TIPO = 'wp_navigation';

	/**
	 * Aplica a navegação declarada.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar(): array {
		$rotulo = 'navegacao.wp_navigation';
		$modo   = (string) F3Base_Imp_Config::obter( 'navegacao.modo', 'wp_navigation' );

		if ( 'wp_navigation' !== $modo ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: %s: modo declarado. */
					__( 'condição de aplicabilidade falsa: a configuração declara o modo %s, reservado a projeto sem manutenção pós-entrega. Nenhum post de navegação é criado, e o menu vive curado na template part.', 'f3base' ),
					$modo
				)
			);
		}

		$slug = (string) F3Base_Imp_Config::obter( 'navegacao.slug', '' );

		if ( '' === $slug ) {
			return self::saida( 'BLOCKED', $rotulo, __( 'slug estável da navegação não declarado na configuração.', 'f3base' ) );
		}

		$itens = self::montar_itens();

		if ( array() !== $itens['pendentes'] ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: %s: referências não resolvidas. */
					__( 'itens de menu com referência lógica não resolvida: %s. Menu com item quebrado não vai ao ar.', 'f3base' ),
					implode( ', ', $itens['pendentes'] )
				)
			);
		}

		if ( '' === $itens['markup'] ) {
			return self::saida( 'BLOCKED', $rotulo, __( 'nenhum item de navegação declarado: não existe menu para criar.', 'f3base' ) );
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida(
				'N/A',
				$rotulo,
				sprintf(
					/* translators: 1: slug, 2: quantidade de itens. */
					__( 'modo simulação: garantiria o post wp_navigation %1$s com %2$d item(ns) e gravaria o ID na option lida pelo tema.', 'f3base' ),
					$slug,
					$itens['total']
				)
			);
		}

		$id = F3Base_Imp_Conteudo::localizar_gerenciado( self::TIPO, $slug );

		if ( $id <= 0 ) {
			$id = self::localizar_por_slug( $slug );
		}

		if ( $id > 0 ) {
			$post = get_post( $id );

			if ( $post instanceof WP_Post && (string) $post->post_content !== $itens['markup'] ) {
				F3Base_Imp_Journal::registrar(
					F3Base_Imp_Journal::TIPO_NAVEGACAO,
					$rotulo,
					array( 'post_content' => $post->post_content ),
					array( 'post_content' => $itens['markup'] ),
					array(
						'acao'   => 'post.restaurar',
						'id'     => $id,
						'campos' => array( 'post_content' => $post->post_content ),
					)
				);

				$atualizado = wp_update_post(
					wp_slash(
						array(
							'ID'           => $id,
							'post_content' => $itens['markup'],
							'post_title'   => (string) F3Base_Imp_Config::obter( 'site.nome', '' ),
							'post_status'  => 'publish',
						)
					),
					true
				);

				if ( is_wp_error( $atualizado ) ) {
					return self::saida( 'FALHA', $rotulo, $atualizado->get_error_message(), $id );
				}
			}
		} else {
			$id = wp_insert_post(
				wp_slash(
					array(
						'post_type'    => self::TIPO,
						'post_status'  => 'publish',
						'post_name'    => $slug,
						'post_title'   => (string) F3Base_Imp_Config::obter( 'site.nome', '' ),
						'post_content' => $itens['markup'],
						'meta_input'   => array(
							F3Base_Imp_Conteudo::META_ID     => F3Base_Imp_Conteudo::identidade( self::TIPO, $slug ),
							F3Base_Imp_Conteudo::META_VERSAO => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
						),
					)
				),
				true
			);

			if ( is_wp_error( $id ) ) {
				return self::saida( 'FALHA', $rotulo, $id->get_error_message() );
			}

			$id = (int) $id;

			F3Base_Imp_Journal::registrar(
				F3Base_Imp_Journal::TIPO_NAVEGACAO,
				$rotulo,
				null,
				array( 'id' => $id ),
				array(
					'acao' => 'post.excluir',
					'id'   => $id,
				)
			);
		}

		F3Base_Imp_Gravador::gravar_meta( 'post', $id, F3Base_Imp_Conteudo::META_ID, F3Base_Imp_Conteudo::identidade( self::TIPO, $slug ) );

		$gravacao = F3Base_Imp_Gravador::gravar( self::OPTION, $id );

		$lido = (int) get_option( self::OPTION, 0 );
		$post = get_post( $lido );

		$vinculo_ok = $lido === $id
			&& $post instanceof WP_Post
			&& self::TIPO === $post->post_type
			&& 'publish' === $post->post_status;

		return self::saida(
			$vinculo_ok ? 'OK' : 'FALHA',
			$rotulo,
			$vinculo_ok
				? sprintf(
					/* translators: 1: ID da navegação, 2: quantidade de itens, 3: slug. */
					__( 'post wp_navigation #%1$d com %2$d item(ns), slug estável %3$s, ID gravado na option lida pelo tema e conferido na leitura de volta nas duas pontas.', 'f3base' ),
					$id,
					$itens['total'],
					$slug
				)
				: sprintf(
					/* translators: 1: ID gravado, 2: ID lido, 3: mensagem do gravador. */
					__( 'o vínculo não fechou: gravado #%1$d, lido #%2$d. %3$s Sem vínculo válido o tema cai no fallback de lista de páginas — que é preferível a um menu vazio, e por isso o tema não força o ref.', 'f3base' ),
					$id,
					$lido,
					$gravacao['motivo']
				),
			$id
		);
	}

	/**
	 * Monta o markup dos itens declarados.
	 *
	 * @return array{markup:string,total:int,pendentes:string[]}
	 */
	private static function montar_itens(): array {
		$blocos    = array();
		$pendentes = array();

		foreach ( F3Base_Imp_Config::lista( 'navegacao.itens' ) as $indice => $entrada ) {
			unset( $entrada );

			$base   = 'navegacao.itens.' . $indice;
			$rotulo = (string) F3Base_Imp_Config::obter( $base . '.rotulo', '' );
			$ref    = F3Base_Imp_Config::obter( $base . '.pagina_ref', null );
			$tipo   = F3Base_Imp_Config::obter( $base . '.tipo', null );

			if ( '' === $rotulo ) {
				$pendentes[] = sprintf(
					/* translators: %d: posição do item. */
					__( 'item #%d sem rótulo', 'f3base' ),
					(int) $indice
				);
				continue;
			}

			$id = 0;

			if ( is_string( $ref ) && '' !== $ref ) {
				$id = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

				if ( $id <= 0 ) {
					$pendentes[] = $ref;
					continue;
				}
			} elseif ( 'posts-page' === $tipo ) {
				$id = (int) get_option( 'page_for_posts', 0 );

				if ( $id <= 0 ) {
					$pendentes[] = __( 'página de posts ainda não definida', 'f3base' );
					continue;
				}
			} elseif ( 'home' === $tipo ) {
				$id = (int) get_option( 'page_on_front', 0 );

				if ( $id <= 0 ) {
					$pendentes[] = __( 'página inicial ainda não definida', 'f3base' );
					continue;
				}
			} else {
				$pendentes[] = $rotulo;
				continue;
			}

			$atributos = array(
				'label' => $rotulo,
				'type'  => 'page',
				'id'    => $id,
				'url'   => (string) get_permalink( $id ),
				'kind'  => 'post-type',
			);

			$json     = wp_json_encode( $atributos );
			$blocos[] = '<!-- wp:navigation-link ' . ( is_string( $json ) ? $json : '{}' ) . ' /-->';
		}

		return array(
			'markup'    => implode( "\n", $blocos ),
			'total'     => count( $blocos ),
			'pendentes' => $pendentes,
		);
	}

	/**
	 * Navegação existente pelo slug estável.
	 *
	 * `post_type` explícito: `wp_navigation` é registrado com `public => false`
	 * e `'any'` não o enxerga.
	 *
	 * @param string $slug Slug.
	 * @return int ID, ou 0.
	 */
	private static function localizar_por_slug( string $slug ): int {
		$encontrados = get_posts(
			array(
				'post_type'        => self::TIPO,
				'name'             => $slug,
				'post_status'      => array( 'publish', 'draft' ),
				'numberposts'      => 1,
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => false,
			)
		);

		return ( is_array( $encontrados ) && array() !== $encontrados ) ? (int) $encontrados[0] : 0;
	}

	/**
	 * Monta o resultado.
	 *
	 * @param string $estado Estado fechado.
	 * @param string $rotulo Nome da checagem.
	 * @param string $motivo Mensagem.
	 * @param int    $id     ID envolvido.
	 * @return array<string,mixed>
	 */
	private static function saida( string $estado, string $rotulo, string $motivo, int $id = 0 ): array {
		return array(
			'estado' => $estado,
			'rotulo' => $rotulo,
			'motivo' => $motivo,
			'id'     => $id,
		);
	}
}
