<?php
/**
 * Orquestrador em lotes.
 *
 * Uma única requisição síncrona estoura timeout e memória em hospedagem
 * compartilhada num site maior. Por isso: `admin-post.php` inicia e renderiza a
 * tela orquestradora, e a tela avança por requisições autenticadas sucessivas,
 * **uma unidade idempotente por lote**.
 *
 * Mecânica que este arquivo garante:
 *
 * - **Checkpoint gravado DEPOIS da leitura de volta**, com identificador da
 *   execução, identificador da release, hash da configuração, etapa, estado e
 *   fencing token. Retomada só com a MESMA release e o MESMO hash de
 *   configuração.
 * - **Lock com heartbeat e renovação atômica.** Expiração sozinha não impede
 *   duas execuções quando uma etapa longa passa do TTL: a renovação é
 *   condicional ao valor observado, e o fencing token invalida a execução
 *   velha que acordar depois.
 * - **O endpoint responde JSON bufferizando**, com `register_shutdown_function`
 *   ARMADO ANTES do trabalho: saída inesperada vai para o log, nunca para o
 *   corpo, e o erro fatal ainda responde JSON com tipo, mensagem, arquivo,
 *   linha e limites do PHP. Como a página de erro do WordPress já foi enviada
 *   quando o shutdown roda, a resposta real é "HTML + JSON" — e o cliente
 *   procura o objeto JSON no FIM do corpo.
 * - **Sentinela de INÍCIO e `Content-Type` cedo.** A requisição administrativa
 *   seguinte a uma ativação de plugin de terceiro pode nunca chegar aqui: o
 *   plugin registra o assistente dele em `admin_init`, que roda ANTES do
 *   `admin_post_*`, e o cliente recebe uma página inteira do wp-admin com HTTP
 *   200. Com um marcador nosso no começo do corpo, o cliente distingue
 *   sequestro (sem sentinela, com marcador de wp-admin) de fatal no meio do
 *   lote (com sentinela, sem JSON) e de resposta de rede (nem um nem outro).
 * - **BLOCKED não se repete.** Unidade que devolve BLOCKED é registrada UMA vez
 *   por execução, não é reexecutada e interrompe a cadeia dependente, com as
 *   etapas que ficaram sem executar nomeadas na mesma linha. Artefato ausente
 *   não aparece em nova tentativa, e a mesma linha cinco vezes esconde as
 *   outras quatro que o operador precisava ler.
 * - **O JavaScript mora em `includes/assets/implantador.js`.** Código
 *   executável não mora dentro de string: heredoc não é lintado nem executado
 *   por teste algum.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Máquina de estados, lock, checkpoint e execução por unidade.
 */
final class F3Base_Imp_Lotes {

	/**
	 * Estados da aplicação.
	 */
	public const PRONTO        = 'PRONTO';
	public const EXECUTANDO    = 'EXECUTANDO';
	public const SUCESSO       = 'SUCESSO_APLICACAO';
	public const FALHA_PARCIAL = 'FALHA_PARCIAL';
	public const FALHA         = 'FALHA';

	/**
	 * TERCEIRO EIXO: a CONVERGÊNCIA do estado, ao lado do estado da aplicação.
	 *
	 * O defeito medido na 1.0.17: o gate consultava BLOCKED de entregável e
	 * BLOCKED de canal, e ninguém consultava o BLOCKED de PRÉ-CONDIÇÃO
	 * DECLARADA. `privacidade.controlador_identificado` e
	 * `formulario.contato-whatsapp` fechavam BLOCKED, entravam no relatório e
	 * não entravam em lista nenhuma. O resultado saía honesto nos fatos e
	 * otimista no nome: SUCESSO_APLICACAO mais autodesativação, com a política
	 * em rascunho e o CTA em degradado.
	 *
	 * Execução terminada e estado convergido são perguntas diferentes, e agora
	 * elas têm nomes diferentes. `SUCESSO_APLICACAO` continua respondendo "o
	 * implantador aplicou o que sabia aplicar"; a convergência responde "o site
	 * está completo".
	 *
	 * E A AUTODESATIVAÇÃO CONTINUA AMARRADA AO GATE DE APLICAÇÃO, não à
	 * convergência — é aqui que esta base discorda da auditoria, e a
	 * discordância fica registrada. A autodesativação é sobre o CICLO DO
	 * IMPLANTADOR ter terminado, não sobre o site estar completo. Manter a
	 * ferramenta no ar por dado que só o operador tem — razão social, documento,
	 * endereço, número de WhatsApp, nome do mecanismo de cadência da hospedagem
	 * — prenderia o pacote a uma espera indefinida: um site cujo operador nunca
	 * preenche o controlador ficaria com o implantador ativo para sempre, que é
	 * exatamente a forma de gate insatisfazível que a 1.0.8 eliminou para a
	 * rodada limpa. O que a convergência muda é o NOME do resultado e a frase de
	 * encerramento, não quem sai de cena.
	 */
	public const CONVERGIU     = 'CONVERGIU';
	public const CONVERGENCIA_PENDENTE = 'CONVERGENCIA_PENDENTE';
	public const NAO_CONVERGIU = 'NAO_CONVERGIU';
	public const REVERTIDO     = 'REVERTIDO';

	/**
	 * Decisões declaráveis em `ambiente.permalinks_decisao`.
	 *
	 * `aplicar-e-cobrir` é o PADRÃO desde a 1.0.17: aplica a estrutura declarada
	 * e COBRE com 301 o caminho de todo publicado que muda de endereço,
	 * gerenciado ou não. `aplicar-se-seguro` mede antes de decidir e recusa
	 * diante de publicado não gerenciado com URL de caminho; `aplicar-declarada`
	 * aplica assumindo o risco e sem cobrir terceiro; `manter-existente` nunca
	 * aplica. Os quatro são símbolos porque o schema declara os quatro, e
	 * comparação por cadeia solta repetida em dois pontos é o que faz o código e
	 * o schema divergirem em silêncio.
	 */
	public const PERMALINKS_COBRIR    = 'aplicar-e-cobrir';
	public const PERMALINKS_SE_SEGURO = 'aplicar-se-seguro';
	public const PERMALINKS_DECLARADA = 'aplicar-declarada';
	public const PERMALINKS_MANTER    = 'manter-existente';

	/**
	 * Prefixo da referência lógica de objeto sem `ref` declarada.
	 *
	 * O par de redirect é chaveado por REFERÊNCIA LÓGICA — a `ref` da página ou
	 * o slug do post declarado —, e conteúdo que este pacote não gerencia não
	 * tem nenhuma das duas. A identidade dele no banco é o ID, e é ela que vira
	 * referência aqui, com prefixo para nunca colidir com uma `ref` declarada.
	 */
	public const REF_POR_ID = '#';

	/**
	 * Ações que a regra de permalinks produz — o que FAZER, não o veredito.
	 */
	public const ACAO_PERMALINK_NADA     = 'nada';
	public const ACAO_PERMALINK_APLICAR  = 'aplicar';
	public const ACAO_PERMALINK_BLOQUEAR = 'bloquear';

	/**
	 * Decisões declaráveis em `ambiente.indexar`.
	 *
	 * `medir` é o PADRÃO: o site nasce indexável e só deixa de ser quando uma
	 * guarda MEDIDA dispara. `forcar` grava 1 ignorando as guardas e registra a
	 * decisão com o motivo por que ela existia. `nunca` grava 0 sempre.
	 */
	public const INDEXAR_MEDIR  = 'medir';
	public const INDEXAR_FORCAR = 'forcar';
	public const INDEXAR_NUNCA  = 'nunca';

	/**
	 * Nomes das GUARDAS da indexação — as únicas que seguram `blog_public`.
	 *
	 * Cada uma foi escolhida por não poder dar falso positivo em site de
	 * produção real, e o nome de cada uma é o da coisa MEDIDA, para que a
	 * mensagem diga o valor observado ao lado do nome.
	 */
	public const GUARDA_AMBIENTE_WP = 'wp_get_environment_type()';
	public const GUARDA_ESQUEMA     = 'esquema de home_url()';
	public const GUARDA_TIPO        = 'ambiente.tipo';
	public const GUARDA_PREVIA      = 'ambiente.dominios_de_previa';

	/**
	 * Ambientes que o núcleo do WordPress considera NÃO produção.
	 *
	 * O padrão de `wp_get_environment_type()` é `production`: um destes três só
	 * aparece quando a hospedagem, o `wp-config.php` ou uma variável de ambiente
	 * DECLARARAM que aquele ambiente não é produção. Site de produção de verdade
	 * nunca cai aqui — e é exatamente por isso que esta é uma guarda, enquanto a
	 * lista de domínios autorizados deixou de ser.
	 */
	public const AMBIENTES_NAO_PRODUCAO = array( 'local', 'development', 'staging' );

	/**
	 * Origens de um par de `f3base_redirects` — a fonte COMPOSTA da option.
	 *
	 * `declarado` sai de `redirects` no arquivo de configuração e é rederivado a
	 * cada execução: tirar da configuração tira da option. `computado` sai de
	 * uma ETAPA da execução — a troca de estrutura de permalinks é a que existe
	 * hoje — e é PRESERVADO nas execuções seguintes, porque a URL antiga que ele
	 * redireciona continua circulando muito depois de a troca ter acontecido.
	 * `preexistente` é o par que já estava gravado sem carimbo de origem: não foi
	 * este pacote que o escreveu, e apagá-lo em silêncio seria o mesmo defeito
	 * com outro nome.
	 */
	public const REDIRECT_DECLARADO    = 'declarado';
	public const REDIRECT_COMPUTADO    = 'computado';
	public const REDIRECT_PREEXISTENTE = 'preexistente';

	/**
	 * Modos de execução.
	 */
	public const MODO_SIMULACAO = 'simulacao';
	public const MODO_EXECUCAO  = 'execucao';
	public const MODO_RELATORIO = 'relatorio';

	/**
	 * Options de estado.
	 */
	public const OPTION_CHECKPOINT   = 'f3base_checkpoint';
	public const OPTION_ESTADO       = 'f3base_estado_aplicacao';
	public const OPTION_LOCK         = 'f3base_lock';
	public const OPTION_RELEASE      = 'f3base_release';
	public const OPTION_CONSUMIDORES = 'f3base_consumidores';
	public const OPTION_BLOQUEIOS    = 'f3base_bloqueios';

	/**
	 * Ação do nonce dos lotes.
	 */
	public const NONCE = 'f3base_imp_lote';

	/**
	 * Sentinela que precede o JSON no fim do corpo.
	 */
	public const SENTINELA = '<<<F3BASE-JSON>>>';

	/**
	 * Sentinela impressa no INÍCIO do corpo, antes de qualquer trabalho.
	 *
	 * É o discriminante do cliente: corpo sem ela e com marcador de wp-admin é
	 * requisição sequestrada por terceiro (o nosso handler nunca rodou); corpo
	 * com ela e sem JSON no fim é erro fatal no meio do lote; sem uma nem outra
	 * é resposta de rede ou de proxy.
	 */
	public const SENTINELA_INICIO = '<<<F3BASE-INICIO>>>';

	/**
	 * TTL do lock, em segundos.
	 */
	public const LOCK_TTL = 90;

	/**
	 * Pares de redirect COMPUTADOS pelas etapas DESTA execução.
	 *
	 * Chave de origem (`de`) => par. Existe porque a etapa que computa o par não
	 * é a mesma que grava a option pela última vez, e o valor desejado de
	 * `f3base_redirects` é a UNIÃO das fontes, não o que a última etapa a tocar
	 * por acaso souber.
	 *
	 * @var array<string,array{de:string,para:string,status:int,origem:string}>
	 */
	private static array $redirects_computados = array();

	/**
	 * Estados fechados da máquina.
	 *
	 * @return string[]
	 */
	public static function estados(): array {
		return array( self::PRONTO, self::EXECUTANDO, self::SUCESSO, self::FALHA_PARCIAL, self::FALHA, self::REVERTIDO );
	}

	/**
	 * Modos declarados.
	 *
	 * @return string[]
	 */
	public static function modos(): array {
		return array( self::MODO_SIMULACAO, self::MODO_EXECUCAO, self::MODO_RELATORIO );
	}

	/**
	 * Plano de unidades da execução, na ordem em que rodam.
	 *
	 * Cada unidade é idempotente e roda sozinha num lote. A ordem garante o que
	 * a etapa seguinte pressupõe: mídia antes de conteúdo (o ID do anexo entra
	 * no bloco), páginas antes das páginas especiais e da navegação (os itens
	 * são resolvidos por referência lógica), tudo antes do SEO e da entrega.
	 *
	 * @return array<int,array{etapa:string,acao:string,indice:int,rotulo:string}>
	 */
	public static function unidades(): array {
		$plano = array();

		$plano[] = self::unidade( 'preflight', 'preflight', 0, __( 'Preflight: capacidades, filesystem, disco, rede, limites, baseline, colisões e overrides', 'f3base' ) );

		/*
		 * MIGRAÇÃO, e a POSIÇÃO é parte da correção: logo depois do preflight e
		 * ANTES de qualquer etapa que leia a lista de plugins instalados. O órfão
		 * criado antes da correção do ponto ainda é lido como plugin pelo núcleo;
		 * ocultá-lo aqui faz a etapa de atualização automática já sair com a lista
		 * limpa, em vez de nomear um diretório de backup ao lado do plugin de
		 * verdade.
		 */
		$plano[] = self::unidade( 'plugins', 'orfaos_anteriores', 0, __( 'Migração: órfãos de backup anteriores à correção do ponto, ocultados com propriedade provada', 'f3base' ), 'migracao' );

		$plano[] = self::unidade( 'tema', 'tema', 0, __( 'Tema do pacote: troca controlada de diretório e ativação depois de validado', 'f3base' ) );
		$plano[] = self::unidade( 'site_core', 'site_core', 0, __( 'Plugin persistente do pacote', 'f3base' ) );

		foreach ( F3Base_Imp_Config::lista( 'plugins.instalaveis' ) as $indice => $entrada ) {
			unset( $entrada );

			$slug = (string) F3Base_Imp_Config::obter( 'plugins.instalaveis.' . $indice . '.slug', '' );

			/*
			 * O plugin de SEO produz um grupo PRÓPRIO. Sem isso, as etapas de SEO
			 * dependeriam de "todos os plugins instaláveis" e um BLOCKED na
			 * instalação do servidor MCP suspenderia o SEO — que é a mesma
			 * grossura de cadeia que esta release existe para desfazer.
			 */
			$plano[] = self::unidade(
				'plugins',
				'plugin_instalavel',
				(int) $indice,
				sprintf(
					/* translators: %s: slug do plugin. */
					__( 'Plugin da fonte oficial, última versão: %s', 'f3base' ),
					$slug
				),
				F3Base_Imp_Seo::SLUG === $slug ? 'plugin_seo' : 'plugins',
				$slug
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'plugins.embarcados' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'plugins',
				'plugin_embarcado',
				(int) $indice,
				sprintf(
					/* translators: %s: slug do plugin embarcado. */
					__( 'Plugin embarcado no bundle: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.slug', '' )
				),
				'plugins',
				(string) F3Base_Imp_Config::obter( 'plugins.embarcados.' . $indice . '.slug', '' )
			);
		}

		/*
		 * PODA DECLARADA das cópias preservadas, depois de todas as instalações
		 * e antes da etapa que lista plugins: o teto vem de
		 * `plugins.backups_preservados` e o que sai do disco sai NOMEADO.
		 */
		$plano[] = self::unidade( 'plugins', 'backups_podados', 0, __( 'Poda declarada das cópias preservadas: acima do teto por slug, as mais antigas saem nomeadas', 'f3base' ), 'plugins_poda' );

		$plano[] = self::unidade( 'plugins', 'autoupdate', 0, __( 'Atualização automática ligada para TODO plugin instalado, conferida pela lista', 'f3base' ), 'plugins_autoupdate' );
		$plano[] = self::unidade( 'plugins', 'onboarding', 0, __( 'Redirecionamento de onboarding suprimido para todo slug declarado no mapa, reescrito de forma idempotente', 'f3base' ), 'plugins_onboarding' );

		/*
		 * DIAGNÓSTICO DO CANAL, cedo e SEM DEPENDÊNCIA declarada. Cedo porque o
		 * operador precisa saber do canal antes de ler trinta linhas de conteúdo;
		 * sem dependência porque foi exatamente esta linha que sumiu quando o
		 * canal era a dúvida. Unidade que diagnostica não pode ser suspensa pelo
		 * que ela diagnostica.
		 */
		$plano[] = self::unidade( 'mcp', 'mcp', 0, __( 'Canal MCP: habilidades registradas conferidas pelo nome, servidor que as expõe e configuração declarada do servidor', 'f3base' ), 'mcp' );

		/*
		 * O RESÍDUO DA INSTALAÇÃO SAI ANTES DOS PERMALINKS, e a ordem é decisão.
		 * O que vai para a lixeira deixa de ser publicado, some da medição de
		 * URLs de terceiro e não ganha 301 para um endereço que passaria a 404;
		 * o que FICA — o objeto que ocupa o slug de exemplo e deixou de ser
		 * exemplo — continua publicado e é COBERTO pelo redirect da troca de
		 * estrutura. Invertida a ordem, o pacote gravaria redirect para o que
		 * ele mesmo está prestes a remover.
		 */
		$plano[] = self::unidade( 'conteudo', 'exemplo_do_wordpress', 0, __( 'Conteúdo de exemplo INTOCADO do WordPress para a lixeira, decidido por discriminante e nunca por slug', 'f3base' ), 'exemplo_do_wordpress' );

		$plano[] = self::unidade( 'wordpress', 'opcoes_wp', 0, __( 'Nome, descrição, idioma, fuso e permalinks', 'f3base' ) );
		$plano[] = self::unidade( 'wordpress', 'indexacao', 0, __( 'Indexação: blog_public = 1 por padrão, salvo guarda medida', 'f3base' ) );

		foreach ( F3Base_Imp_Config::lista( 'midia' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'midia',
				'midia',
				(int) $indice,
				sprintf(
					/* translators: %s: referência lógica da mídia. */
					__( 'Mídia por sideload local: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.ref', '' )
				),
				'midia',
				(string) F3Base_Imp_Config::obter( 'midia.' . $indice . '.ref', '' )
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'categorias' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'taxonomias',
				'categoria',
				(int) $indice,
				sprintf(
					/* translators: %s: slug da categoria. */
					__( 'Categoria: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.slug', '' )
				),
				'taxonomias',
				(string) F3Base_Imp_Config::obter( 'categorias.' . $indice . '.slug', '' )
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'conteudo',
				'pagina',
				(int) $indice,
				sprintf(
					/* translators: %s: referência lógica da página. */
					__( 'Página gerenciada: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' )
				),
				'conteudo',
				(string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' )
			);
		}

		foreach ( F3Base_Imp_Config::lista( 'posts' ) as $indice => $entrada ) {
			unset( $entrada );

			$plano[] = self::unidade(
				'conteudo',
				'post',
				(int) $indice,
				sprintf(
					/* translators: %s: slug do post. */
					__( 'Post gerenciado: %s', 'f3base' ),
					(string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' )
				),
				'conteudo',
				(string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' )
			);
		}

		/*
		 * INVENTÁRIO DO QUE NÃO É NOSSO, depois de todo conteúdo gerenciado. Sai
		 * WARN e nunca FALHA: `Sample Page` e `Hello world!` publicados não são
		 * defeito do site, são decisão em aberto do projeto — e não relatá-los
		 * era o implantador entregando um site com página de exemplo publicada
		 * sem dizer nada.
		 */
		$plano[] = self::unidade( 'conteudo', 'conteudo_nao_gerenciado', 0, __( 'Conteúdo publicado NÃO gerenciado, herdado da instalação limpa: relatado, nunca apagado', 'f3base' ), 'conteudo_nao_gerenciado' );

		$plano[] = self::unidade( 'wordpress', 'paginas_especiais', 0, __( 'Página inicial, página de posts e política de privacidade', 'f3base' ), 'paginas_especiais' );
		$plano[] = self::unidade( 'navegacao', 'navegacao', 0, __( 'Post wp_navigation idempotente e ID na option lida pelo tema', 'f3base' ), 'navegacao' );
		$plano[] = self::unidade( 'seo', 'seo_identidade', 0, __( 'Identidade da organização em wpseo_titles', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'seo', 'seo_social', 0, __( 'Open Graph, Twitter Cards e imagem social padrão', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'seo', 'seo_geral', 0, __( 'Sitemap, telemetria desligada e a lista do que nunca ligar', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'seo', 'seo_llms', 0, __( 'Seleção do llms.txt gravada e relida', 'f3base' ), 'seo_llms' );
		$plano[] = self::unidade( 'seo', 'seo_robots', 0, __( 'robots.txt como arquivo físico, com Sitemap por home_url()', 'f3base' ), 'seo' );
		$plano[] = self::unidade( 'site_core', 'options_site_core', 0, __( 'Options operáveis e estruturais do site-core', 'f3base' ), 'options_site_core' );
		$plano[] = self::unidade( 'formularios', 'formularios', 0, __( 'Regimes de formulário declarados e seus destinos', 'f3base' ), 'formularios' );
		$plano[] = self::unidade( 'cadencia', 'cadencia', 0, __( 'Cadência do modo somente-relatório agendada, com o mecanismo nomeado', 'f3base' ), 'cadencia' );

		/*
		 * ENTREGA SEMPRE EXECUTA. Ela declara lista vazia de dependências, e isso
		 * é decisão, não omissão: a entrega é o INVENTÁRIO do que ficou de pé, e
		 * um relatório de entrega que não roda quando alguma coisa falhou é
		 * exatamente o instrumento que some quando é mais necessário. BLOCKED na
		 * entrega é RESULTADO — nunca impedimento para rodá-la.
		 */
		$plano[] = self::unidade( 'entrega', 'entrega', 0, __( 'Entregáveis, canal MCP e consumidores da configuração', 'f3base' ), 'entrega' );
		$plano[] = self::unidade( 'encerramento', 'encerramento', 0, __( 'Estado final, carimbo de release e decisão de autodesativação', 'f3base' ), 'encerramento' );

		return F3Base_Imp_Plano::resolver( $plano );
	}

	/**
	 * Monta uma unidade do plano.
	 *
	 * @param string $etapa  Etapa.
	 * @param string $acao   Ação interna.
	 * @param int    $indice Índice na lista da configuração.
	 * @param string $rotulo Rótulo humano.
	 * @param string $grupo  Grupo declarado em F3Base_Imp_Plano; vazio usa a ação.
	 * @param string $chave  Chave de instância (slug, ref) que distingue unidades da mesma ação.
	 * @return array{etapa:string,acao:string,indice:int,rotulo:string,grupo:string,id:string,depende_de:string[]}
	 */
	private static function unidade( string $etapa, string $acao, int $indice, string $rotulo, string $grupo = '', string $chave = '' ): array {
		return array(
			'etapa'      => $etapa,
			'acao'       => $acao,
			'indice'     => $indice,
			'rotulo'     => $rotulo,
			'grupo'      => '' === $grupo ? $acao : $grupo,
			'id'         => F3Base_Imp_Plano::id( $acao, $chave ),
			'depende_de' => array(),
		);
	}

	/**
	 * Índice de lote que o cliente pediu, sanitizado.
	 *
	 * Existe para que as recusas anteriores ao processamento — capacidade e
	 * nonce — respondam com o MESMO índice que o cliente enviou. Recusa que
	 * responde índice inventado impede o cliente de casar a resposta com o que
	 * ele pediu, e foi assim que uma resposta que não avançou o plano passou por
	 * uma que avançou.
	 *
	 * @return int
	 */
	private static function indice_pedido(): int {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- leitura de diagnóstico; o nonce é conferido por quem chama.
		return isset( $_POST['lote'] ) ? absint( wp_unslash( (string) $_POST['lote'] ) ) : 0;
	}

	/**
	 * Endpoint JSON de um lote.
	 *
	 * @return void
	 */
	public static function endpoint_lote(): void {
		/*
		 * A rede de fatal é armada ANTES de qualquer trabalho: se o próximo
		 * `require` explodir, o cliente ainda recebe diagnóstico em vez de
		 * "Unexpected token '<'".
		 */
		register_shutdown_function( array( __CLASS__, 'rede_de_fatal' ) );

		ob_start();

		if ( ! current_user_can( 'manage_options' ) ) {
			self::responder(
				self::nao_rodou(
					self::indice_pedido(),
					'lote.capacidade_ausente',
					__( 'capacidade manage_options ausente: nenhuma mutação executada e nenhum lote rodou.', 'f3base' )
				),
				403
			);
		}

		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['_wpnonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, self::NONCE ) ) {
			self::responder(
				self::nao_rodou(
					self::indice_pedido(),
					'lote.nonce_invalido',
					__( 'nonce inválido ou expirado: recarregue a tela da ferramenta e recomece. Nenhum lote rodou.', 'f3base' )
				),
				403
			);
		}

		$modo     = isset( $_POST['modo'] ) ? sanitize_key( wp_unslash( (string) $_POST['modo'] ) ) : self::MODO_SIMULACAO;
		$modo     = in_array( $modo, self::modos(), true ) ? $modo : self::MODO_SIMULACAO;
		$execucao = isset( $_POST['execucao'] ) ? sanitize_key( wp_unslash( (string) $_POST['execucao'] ) ) : '';
		$indice   = isset( $_POST['lote'] ) ? absint( wp_unslash( (string) $_POST['lote'] ) ) : 0;

		self::abrir_corpo();

		self::responder( self::processar( $modo, $execucao, $indice ) );
	}

	/**
	 * Marca o corpo como NOSSO antes de qualquer trabalho.
	 *
	 * O `Content-Type: application/json` e a sentinela de início saem AGORA, e
	 * não no fim: a requisição administrativa seguinte a uma ativação de plugin
	 * de terceiro pode nunca chegar até aqui — o plugin registra o assistente
	 * dele em `admin_init`, que roda ANTES do `admin_post_*`, e o cliente recebe
	 * uma página inteira do wp-admin com HTTP 200. Sem um marcador nosso no
	 * INÍCIO do corpo, essa resposta é indistinguível de um erro fatal no meio do
	 * lote, e o cliente não tem como decidir entre repetir a unidade e desistir
	 * dela.
	 *
	 * Sai depois da capacidade e do nonce de propósito: essas duas respondem com
	 * o código HTTP delas, e imprimir antes tiraria o 403 do fio.
	 *
	 * @return void
	 */
	private static function abrir_corpo(): void {
		$ruido = '';

		while ( ob_get_level() > 0 ) {
			$ruido .= (string) ob_get_clean();
		}

		if ( '' !== trim( $ruido ) ) {
			error_log( '[f3base-implantador] saída inesperada antes do lote: ' . substr( $ruido, 0, 2000 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- ruído vai ao log, nunca ao corpo.
		}

		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: application/json; charset=utf-8' );
			nocache_headers();
		}

		echo self::SENTINELA_INICIO . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- constante do próprio pacote, sem entrada de usuário.

		flush();

		ob_start();
	}

	/**
	 * ÂNCORA da resposta do lote: quem emite, quem produz e o que toda uma traz.
	 *
	 * A tela do operador é montada a partir DESTA resposta: linha sem `rotulo`
	 * sai anônima e a contagem por estado fica sem a lista de nomes; resposta
	 * sem `aplicacao` fecha o rodapé em branco, e vazio não é estado fechado.
	 * Quem cobra é `estatica.resposta_de_lote_nomeada`.
	 *
	 * @return array<string,string>
	 */
	public static function resposta_declarada(): array {
		return array(
			'emissor'  => 'responder',
			'produtor' => 'processar',
			'reserva'  => 'nao_rodou',
			'exigidas' => 'rotulo,aplicacao',
		);
	}

	/**
	 * Resposta de um lote que NÃO RODOU — e por isso ENCERRA a tela.
	 *
	 * O DEFEITO QUE ESTA FUNÇÃO FECHA, medido na 1.0.15: a rejeição de lock
	 * voltava como `{ok:false, estado:BLOCKED, motivo:"…"}` — sem nome de
	 * checagem, sem etapa, sem `concluido` e sem estado da aplicação. O cliente
	 * aplicava a ela a regra "BLOCKED não para mais a execução inteira", que é
	 * correta para UNIDADE que mediu pré-condição ausente e é errada aqui: o
	 * lote não rodou, nada foi medido, e não há o que continuar. O resultado foi
	 * um laço de 163 requisições, um `Etapa 94 de 40` na tela e um rodapé com
	 * `estado da aplicação:` vazio.
	 *
	 * A resposta daqui carrega os quatro fatos que faltavam:
	 *
	 * - `rotulo`: toda linha renderizada tem NOME, ou a contagem por estado sai
	 *   sem a lista correspondente — foi o que produziu "163 BLOCKED" ao lado de
	 *   "BLOCKED: nenhum";
	 * - `parou`: o plano NÃO avançou, e o cliente não pode pedir o próximo;
	 * - `concluido`: a tela fecha aqui;
	 * - `aplicacao`: estado FECHADO, nunca vazio. Execução que não chegou a
	 *   adquirir o lock fecha BLOCKED, que é o estado de pré-condição ausente.
	 *
	 * @param int                 $indice Índice pedido pelo cliente.
	 * @param string              $rotulo Nome da checagem.
	 * @param string              $motivo Mensagem, já montada.
	 * @param array<string,mixed> $extra  Fatos estruturados da causa.
	 * @return array<string,mixed>
	 */
	private static function nao_rodou( int $indice, string $rotulo, string $motivo, array $extra = array() ): array {
		return array_merge(
			array(
				'ok'        => false,
				'concluido' => true,
				'parou'     => true,
				'lote'      => $indice,
				'etapa'     => 'lote',
				'rotulo'    => $rotulo,
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'motivo'    => $motivo,
				'aplicacao' => F3Base_Imp_Relatorio::BLOCKED,
			),
			$extra
		);
	}

	/**
	 * Processa um lote.
	 *
	 * @param string $modo     Modo declarado.
	 * @param string $execucao Identificador da execução.
	 * @param int    $indice   Índice da unidade.
	 * @return array<string,mixed>
	 */
	public static function processar( string $modo, string $execucao, int $indice ): array {
		if ( ! F3Base_Imp_Config::carregar() ) {
			return self::nao_rodou(
				$indice,
				'lote.configuracao_invalida',
				sprintf(
					/* translators: %s: erros de validação. */
					__( 'a configuração não validou contra o schema e o lote NÃO rodou: %s', 'f3base' ),
					implode( ' | ', F3Base_Imp_Config::erros() )
				)
			);
		}

		if ( '' === $execucao ) {
			return self::nao_rodou(
				$indice,
				'lote.execucao_ausente',
				__( 'identificador de execução ausente: o lote não sabe a que execução pertence e NÃO rodou.', 'f3base' )
			);
		}

		$lock = self::adquirir_lock( $execucao );

		if ( ! $lock['ok'] ) {
			return self::nao_rodou(
				$indice,
				'lote.lock_ocupado',
				$lock['motivo'],
				array(
					'lock' => array(
						'dono'          => (string) $lock['dono'],
						'idade'         => (int) $lock['idade'],
						'ttl'           => (int) $lock['ttl'],
						'abandonado_em' => (int) $lock['abandonado_em'],
						'abandonado_as' => 0 === (int) $lock['abandonado_em'] ? '' : wp_date( 'Y-m-d H:i:s', (int) $lock['abandonado_em'] ),
					),
				)
			);
		}

		$retomada = self::conferir_retomada( $execucao, $indice );

		if ( ! $retomada['ok'] ) {
			return self::nao_rodou( $indice, 'lote.retomada_recusada', $retomada['motivo'] );
		}

		$plano = self::unidades();
		$total = count( $plano );

		if ( $indice < 0 || $indice >= $total ) {
			/*
			 * ÍNDICE FORA DO PLANO. Antes desta release a resposta saía sem nome
			 * e sem estado da aplicação, e o cliente a renderizava como linha
			 * anônima — a mesma doença da rejeição de lock. Sai nomeada, com o
			 * índice pedido e o total, porque índice fora do plano é sempre
			 * defeito de quem pediu, e o número que ele pediu é o diagnóstico.
			 */
			return array(
				'ok'        => true,
				'concluido' => true,
				'parou'     => true,
				'lote'      => $indice,
				'total'     => $total,
				'etapa'     => 'lote',
				'rotulo'    => 'lote.plano_concluido',
				'estado'    => F3Base_Imp_Relatorio::OK,
				'aplicacao' => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
				'motivo'    => sprintf(
					/* translators: 1: índice pedido, 2: total de unidades. */
					__( 'plano concluído: não há mais unidades. Índice pedido: %1$d; o plano tem %2$d.', 'f3base' ),
					$indice,
					$total
				),
			);
		}

		F3Base_Imp_Gravador::simulacao( self::MODO_EXECUCAO !== $modo );
		F3Base_Imp_Journal::iniciar( $execucao );
		F3Base_Imp_Relatorio::carregar();

		if ( 0 === $indice ) {
			F3Base_Imp_Relatorio::zerar();
			F3Base_Imp_Gravador::remover_infra( self::OPTION_CONSUMIDORES );
			F3Base_Imp_Gravador::remover_infra( self::OPTION_BLOQUEIOS );

			/*
			 * O registro de vereditos morre com a execução anterior. Veredito
			 * velho decidindo gate novo seria a mesma doença de outra forma: uma
			 * fonte de verdade, sim, mas desta execução.
			 */
			F3Base_Imp_Gravador::remover_infra( F3Base_Imp_Entrega::OPTION_VEREDITOS );

			/*
			 * O registro de MEDIÇÕES morre junto, e pela mesma razão: fato velho
			 * respondendo por predicado de aplicabilidade novo diria "há rotas"
			 * num site em que já não há.
			 */
			F3Base_Imp_Gravador::remover_infra( F3Base_Imp_Entrega::OPTION_MEDICOES );
			self::definir_estado( self::MODO_EXECUCAO === $modo ? self::EXECUTANDO : self::PRONTO );
		} else {
			$acumuladas = get_option( self::OPTION_CONSUMIDORES, array() );
			F3Base_Imp_Config::acumular( is_array( $acumuladas ) ? $acumuladas : array() );
		}

		$unidade = $plano[ $indice ];

		/*
		 * Unidade já registrada em BLOCKED nesta execução NÃO roda de novo, e não
		 * emite uma segunda linha: artefato ausente não aparece em nova tentativa,
		 * e a mesma linha repetida cinco vezes esconde as outras quatro que o
		 * operador precisava ler. A linha sai UMA vez, com a cadeia dependente
		 * nomeada; a saída é corrigir a pré-condição e começar uma execução nova.
		 */
		$repetida = self::bloqueio_registrado( $execucao, $indice );

		if ( array() !== $repetida ) {
			return array(
				'ok'          => false,
				'concluido'   => false,
				'lote'        => $indice,
				'total'       => $total,
				'etapa'       => $unidade['etapa'],
				'rotulo'      => $unidade['rotulo'],
				'estado'      => F3Base_Imp_Relatorio::BLOCKED,
				'repetida'    => true,
				'motivo'      => sprintf(
					/* translators: 1: data do registro, 2: motivo registrado. */
					__( 'unidade já registrada em BLOCKED nesta execução (em %1$s) e NÃO reexecutada — a linha do log sai uma vez só. Motivo registrado: %2$s', 'f3base' ),
					wp_date( 'Y-m-d H:i', (int) $repetida['em'] ),
					(string) $repetida['motivo']
				),
				'dependentes' => $repetida['dependentes'],
				'aplicacao'   => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
				'ativado'     => F3Base_Imp_Plugins::ultimo_ativado(),
			) + self::contadores_por_escopo();
		}

		/*
		 * SUSPENSÃO POR DEPENDÊNCIA DECLARADA. Não é "veio depois de alguém que
		 * falhou": é "declara depender, direta ou indiretamente, de uma unidade
		 * que fechou BLOCKED ou FALHA nesta execução". Quem não declara continua
		 * executando, e a linha nomeia QUAL unidade suspendeu esta — porque
		 * "ficou sem executar" não responde à pergunta que o operador faz em
		 * seguida.
		 */
		$suspensas = F3Base_Imp_Plano::suspensas( $plano, self::interrompidas( $execucao ) );
		$id        = (string) $unidade['id'];

		if ( isset( $suspensas[ $id ] ) ) {
			$causa  = $suspensas[ $id ];
			$motivo = sprintf(
				/* translators: 1: id da dependência direta, 2: id da unidade que originou, 3: estado observado, 4: motivo registrado. */
				__( 'unidade SUSPENSA e não executada: ela declara depender de %1$s, e a origem da suspensão é %2$s, que fechou %3$s nesta execução. Motivo registrado ali: %4$s A dependência é declarada em F3Base_Imp_Plano, não é a posição no plano — as unidades independentes desta continuaram executando.', 'f3base' ),
				(string) $causa['por'],
				(string) $causa['raiz'],
				(string) $causa['estado'],
				self::motivo_da_interrompida( $execucao, (string) $causa['raiz'] )
			);

			F3Base_Imp_Relatorio::emitir_unidade(
				F3Base_Imp_Relatorio::BLOCKED,
				$unidade['rotulo'],
				$motivo,
				array(
					'evidencia' => 'pendencia-externa',
					'fase'      => self::MODO_EXECUCAO === $modo ? 'local' : 'build',
					'gate'      => 'aplicacao',
				)
			);

			F3Base_Imp_Relatorio::persistir(
				array(
					'execucao' => $execucao,
					'modo'     => $modo,
				)
			);

			return array(
				'ok'          => true,
				'concluido'   => $indice + 1 >= $total,
				'lote'        => $indice,
				'total'       => $total,
				'etapa'       => $unidade['etapa'],
				'rotulo'      => $unidade['rotulo'],
				'estado'      => F3Base_Imp_Relatorio::BLOCKED,
				'suspensa'    => true,
				'motivo'      => $motivo,
				'aplicacao'   => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
				'dependentes' => array(),
				'ativado'     => F3Base_Imp_Plugins::ultimo_ativado(),
			) + self::contadores_por_escopo();
		}

		F3Base_Imp_Journal::etapa( $unidade['etapa'] );

		/*
		 * MARCA ANTES DE EXECUTAR. O que a unidade emitir daqui até a linha dela
		 * é o conjunto de checagens que rodaram DENTRO dela — e é ele que a
		 * resposta carrega, para que nenhum estado ruim fique invisível atrás de
		 * uma unidade que fechou OK.
		 */
		$marca = F3Base_Imp_Relatorio::marcar();

		$resultado   = self::executar( $unidade, $modo );
		$internas    = self::checagens_da_unidade( $marca );
		$dependentes = array();

		/*
		 * O VEREDITO DA UNIDADE REFLETE AS CHECAGENS QUE ELA EMITIU, e isso
		 * acontece AQUI — uma vez, para todas as unidades — em vez de em cada
		 * `etapa_*` à mão. Aplicado antes do bloco de dependentes de propósito:
		 * a promoção é o estado da unidade, e é ele que decide suspensão,
		 * registro de bloqueio e a linha que sai na tela.
		 */
		$reflexo             = self::veredito_da_unidade( $resultado['estado'], $internas['nomeadas'] );
		$resultado['estado'] = $reflexo['estado'];

		/*
		 * A nota sai quando há promoção E quando há pendência de fase: a
		 * segunda não muda o veredito, e é justamente por isso que ela precisa
		 * aparecer NOMEADA no texto — o que não decide também não pode sumir.
		 */
		if ( '' !== $reflexo['nota'] ) {
			$resultado['motivo'] .= ' ' . $reflexo['nota'];
		}

		if ( in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::BLOCKED, F3Base_Imp_Relatorio::FALHA ), true ) ) {
			$dependentes          = self::etapas_sem_execucao( $id, $resultado['estado'] );
			$resultado['motivo'] .= ' ' . self::texto_dependentes( $dependentes );

			self::registrar_bloqueio( $execucao, $indice, $id, $resultado['estado'], $resultado['motivo'], $dependentes );
		}

		/*
		 * A linha da UNIDADE sai por `emitir_unidade()`: ela imprime no escopo
		 * das checagens, como qualquer outra, e conta também no escopo das
		 * UNIDADES. Dois escopos, dois contadores, cada um com nome próprio.
		 */
		F3Base_Imp_Relatorio::emitir_unidade(
			$resultado['estado'],
			$resultado['rotulo'],
			$resultado['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => self::MODO_EXECUCAO === $modo ? 'local' : 'build',
				'gate'      => 'aplicacao',
			)
		);

		foreach ( F3Base_Imp_Conteudo::avisos() as $aviso ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'idempotencia.registro_vs_artefato',
				$aviso,
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}

		F3Base_Imp_Relatorio::persistir(
			array(
				'execucao' => $execucao,
				'modo'     => $modo,
			)
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_CONSUMIDORES, F3Base_Imp_Config::chaves_lidas() );

		/*
		 * O checkpoint é gravado DEPOIS da leitura de volta da unidade — nunca
		 * antes: checkpoint que corre à frente do artefato faz a retomada pular
		 * trabalho que não aconteceu.
		 */
		$gravou_checkpoint = self::gravar_checkpoint( $execucao, $modo, $unidade['etapa'], $indice, $resultado['estado'] );

		return array(
			'ok'          => in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::OK, F3Base_Imp_Relatorio::NA, F3Base_Imp_Relatorio::WAIVED, F3Base_Imp_Relatorio::WARN ), true ),
			'concluido'   => $indice + 1 >= $total,
			'lote'        => $indice,
			'total'       => $total,
			'etapa'       => $unidade['etapa'],
			'rotulo'      => $unidade['rotulo'],
			'estado'      => $resultado['estado'],
			'motivo'      => $resultado['motivo'],
			'checkpoint'  => $gravou_checkpoint,
			'aplicacao'   => (string) get_option( self::OPTION_ESTADO, self::PRONTO ),
			'dependentes' => $dependentes,
			'ativado'     => F3Base_Imp_Plugins::ultimo_ativado(),
			'checagens'   => $internas['nomeadas'],
			'checagens_resumidas' => $internas['resumidas'],
		) + self::contadores_por_escopo();
	}

	/**
	 * Checagens que rodaram DENTRO de uma unidade, prontas para a tela.
	 *
	 * A regra, e ela é a correção desta release: **toda checagem em FALHA,
	 * BLOCKED, WARN, WAIVED ou N/A é NOMEADA no relatório, mesmo quando a
	 * unidade que a contém fecha OK.** Só o estado OK sai resumido — o que não
	 * pode existir é estado ruim invisível.
	 *
	 * PÚBLICA de propósito: é a MESMA função que a sonda funcional chama para
	 * exercitar a promoção de estado no caminho real de `processar()`. Sonda que
	 * reimplementa o recorte prova que a cópia funciona, não que o recorte
	 * funciona.
	 *
	 * @param int $marca Ponto do acumulador anterior à execução da unidade.
	 * @return array{nomeadas:array<int,array<string,string>>,resumidas:int}
	 */
	public static function checagens_da_unidade( int $marca ): array {
		$nomeadas  = array();
		$resumidas = 0;

		foreach ( F3Base_Imp_Relatorio::desde( $marca ) as $linha ) {
			$estado = (string) ( $linha['estado'] ?? '' );

			if ( F3Base_Imp_Relatorio::OK === $estado ) {
				++$resumidas;
				continue;
			}

			$nomeadas[] = array(
				'estado'    => $estado,
				'nome'      => (string) ( $linha['nome'] ?? '' ),
				'mensagem'  => (string) ( $linha['mensagem'] ?? '' ),
				'evidencia' => (string) ( $linha['evidencia'] ?? '' ),
				'fase'      => (string) ( $linha['fase'] ?? '' ),
				'gate'      => (string) ( $linha['gate'] ?? '' ),
			);
		}

		return array(
			'nomeadas'  => $nomeadas,
			'resumidas' => $resumidas,
		);
	}

	/**
	 * GATE cuja checagem DECIDE o veredito da unidade.
	 *
	 * Um só, e declarado aqui: `aplicacao`. É a mesma separação que a 1.0.7
	 * estabeleceu para a autodesativação — gate de aplicação DECIDE, gate de
	 * fase INFORMA —, aplicada agora ao veredito da unidade.
	 *
	 * A regra do que é fase, e ela é estreita de propósito: **só entra em `fase`
	 * o que depende de evidência que o host NÃO PRODUZ** — navegador, campo,
	 * suíte externa. Tudo que é mensurável aqui é `aplicacao`, e isso inclui os
	 * oito entregáveis, os vereditos de canal e a decisão de autodesativação.
	 * Marcar como fase uma checagem que o host mede seria construir a porta de
	 * escape que absolve qualquer coisa, e é ela que `estatica.unidade_reflete_internas`
	 * existe para manter fechada.
	 */
	public const GATE_QUE_DECIDE = 'aplicacao';

	/**
	 * O VEREDITO DA UNIDADE: o mais severo entre o dela e as internas de gate
	 * `aplicacao`.
	 *
	 * O DEFEITO CORRIGIDO AQUI, medido em produção na 1.0.8: a linha 48 do
	 * relatório era `OK entrega — "todos os entregáveis do gate de aplicação
	 * fecharam sem BLOCKED"` e a linha 49, DENTRO dela, era
	 * `FALHA ↳ mcp.canal_unico`. Uma unidade não pode fechar OK contendo uma
	 * checagem em FALHA: quem lê o resumo por unidade vê verde onde há vermelho,
	 * e foi essa mesma discrepância que escondeu as FALHAs até a 1.0.7.
	 *
	 * A PROMOÇÃO É POR GATE, e sem isso a correção criava um defeito novo: a
	 * unidade `entrega` emite `orcamento.medicao_de_pagina` como BLOCKED em TODA
	 * execução — é medição de navegador, que este host não faz — e uma promoção
	 * cega faria `entrega` fechar BLOCKED para sempre, em qualquer instalação,
	 * por desenho. É a mesma armadilha que a 1.0.7 desfez no gate da
	 * autodesativação, reaparecendo no veredito da unidade.
	 *
	 * Então: decide quem é de `aplicacao`. O que é de fase **não some** — sai
	 * na sua própria linha, entra nas listas por estado e no resumo, e é
	 * NOMEADO no texto da unidade como pendência de fase. Some do veredito,
	 * nunca do relatório.
	 *
	 * Gate ausente conta como `aplicacao`, e isso é decisão: a ausência não pode
	 * ser o caminho barato para escapar da promoção.
	 *
	 * A ordem de severidade NÃO é declarada aqui — ela é
	 * `F3Base_Imp_Relatorio::ordem_de_severidade()`, uma só no pacote, e é o
	 * `estado_mais_severo()` daquela classe que compara. Duas ordens divergem, e
	 * a divergência sai como relatório que se contradiz.
	 *
	 * Só o que NÃO fechou OK chega aqui, e isso basta: OK não promove ninguém.
	 *
	 * @param string                          $estado_da_unidade Estado que a etapa devolveu.
	 * @param array<int,array<string,string>> $internas          Checagens da unidade que não fecharam OK.
	 * @return array{estado:string,promovida:bool,nota:string,responsaveis:array<int,string>,pendencias_de_fase:array<int,string>}
	 */
	/**
	 * Esta checagem interna DECIDE o veredito da unidade?
	 *
	 * Uma função, e não uma comparação repetida em três pontos: a regra tem um
	 * caso de borda que uma comparação distraída erra, e errou — **gate AUSENTE
	 * OU VAZIO conta como o gate que decide**. `?? ` só cobre a chave que falta;
	 * a chave presente e vazia passava direto e era lida como fase, o que fazia
	 * de "esquecer de declarar o gate" o caminho barato para escapar da
	 * promoção. Quem esquece promove como aplicação, que é o lado seguro.
	 *
	 * @param array<string,string> $interna Linha do recorte da unidade.
	 * @return bool
	 */
	private static function decide_o_veredito( array $interna ): bool {
		$gate = (string) ( $interna['gate'] ?? '' );

		return '' === $gate || self::GATE_QUE_DECIDE === $gate;
	}

	public static function veredito_da_unidade( string $estado_da_unidade, array $internas ): array {
		$estado             = $estado_da_unidade;
		$pendencias_de_fase = array();

		foreach ( $internas as $interna ) {
			$estado_interno = (string) ( $interna['estado'] ?? '' );

			if ( '' === $estado_interno ) {
				continue;
			}

			if ( ! self::decide_o_veredito( $interna ) ) {
				$pendencias_de_fase[] = (string) ( $interna['nome'] ?? '' ) . ' (' . $estado_interno . ')';
				continue;
			}

			$estado = F3Base_Imp_Relatorio::estado_mais_severo( $estado, $estado_interno );
		}

		$responsaveis = array();

		if ( $estado !== $estado_da_unidade ) {
			foreach ( $internas as $interna ) {
				if ( $estado === (string) ( $interna['estado'] ?? '' ) && self::decide_o_veredito( $interna ) ) {
					$responsaveis[] = (string) ( $interna['nome'] ?? '' );
				}
			}
		}

		$partes = array();

		if ( array() !== $responsaveis ) {
			$partes[] = sprintf(
				/* translators: 1: estado que a etapa devolveu, 2: estado promovido, 3: checagens responsáveis, pelo nome. */
				__( 'Veredito da unidade PROMOVIDO de %1$s para %2$s: a unidade emitiu checagem(ns) de gate de aplicação em %2$s e nenhuma unidade fecha em estado menos severo do que aquilo que ela mesma mediu — %3$s. Ler a linha da unidade e a das checagens e encontrar cores diferentes foi o que escondeu as FALHAs até a 1.0.7.', 'f3base' ),
				$estado_da_unidade,
				$estado,
				implode( ', ', $responsaveis )
			);
		}

		if ( array() !== $pendencias_de_fase ) {
			$partes[] = sprintf(
				/* translators: 1: quantidade de pendências de fase, 2: as pendências, pelo nome e com o estado. */
				__( 'Pendência(s) de FASE dentro desta unidade — %1$d, nomeada(s) e FORA do veredito dela: %2$s. Evidência que este host não produz (navegador, campo, suíte externa) é relatada e não decide: some do veredito, nunca do relatório.', 'f3base' ),
				count( $pendencias_de_fase ),
				implode( ', ', $pendencias_de_fase )
			);
		}

		return array(
			'estado'             => $estado,
			'promovida'          => $estado !== $estado_da_unidade,
			'nota'               => implode( ' ', $partes ),
			'responsaveis'       => $responsaveis,
			'pendencias_de_fase' => $pendencias_de_fase,
		);
	}

	/**
	 * Contadores da resposta do lote, um por escopo e cada um NOMEADO.
	 *
	 * A resposta antiga trazia `falhas` e `bloqueados` sem escopo declarado, e o
	 * cliente imprimia esses números ao lado de uma tabela que conta outra
	 * coisa. Aqui cada chave diz o que conta, e nenhuma palavra nomeia duas
	 * contagens diferentes. O terceiro escopo — as linhas renderizadas na tela —
	 * é do cliente, e é lá que ele é contado.
	 *
	 * CONTAGEM E NOMES VIAJAM JUNTOS. A resposta que levava só os números
	 * produziu o cabeçalho "5 FALHA e 6 BLOCKED" ao lado de uma tela com UMA
	 * unidade em FALHA: as outras rodavam DENTRO de unidades que fecharam OK, e
	 * o operador tinha o número e nenhum nome para procurar.
	 *
	 * @return array<string,mixed>
	 */
	private static function contadores_por_escopo(): array {
		return array(
			'escopos'            => F3Base_Imp_Relatorio::escopos(),
			'checagens_falha'    => F3Base_Imp_Relatorio::checagens_em_falha(),
			'checagens_blocked'  => F3Base_Imp_Relatorio::checagens_em_blocked(),
			'unidades_falha'     => F3Base_Imp_Relatorio::unidades_em_falha(),
			'unidades_blocked'   => F3Base_Imp_Relatorio::unidades_em_blocked(),
			'checagens_nomes'    => F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' ),
			'unidades_nomes'     => F3Base_Imp_Relatorio::nomes_por_estado( 'unidades' ),
		);
	}

	/**
	 * Unidades que ESTA unidade suspende — o fecho transitivo dela, e só ele.
	 *
	 * Era aqui que morava o defeito medido: a função devolvia TUDO que vinha
	 * depois na lista, e um BLOCKED em `formularios` derrubava `cadencia`,
	 * `entrega` e `encerramento`, que não leem nada de formulário. Agora a
	 * pergunta é "quem declarou depender desta unidade, direta ou
	 * indiretamente" — dependência declarada, nunca posição.
	 *
	 * @param string $id     Id da unidade que interrompeu.
	 * @param string $estado Estado observado (BLOCKED ou FALHA).
	 * @return array<int,string> Ids suspensos, com o rótulo humano.
	 */
	private static function etapas_sem_execucao( string $id, string $estado ): array {
		$plano     = self::unidades();
		$suspensas = F3Base_Imp_Plano::suspensas( $plano, array( $id => $estado ) );
		$pendentes = array();

		foreach ( $plano as $posicao => $unidade ) {
			$alvo = (string) $unidade['id'];

			if ( ! isset( $suspensas[ $alvo ] ) ) {
				continue;
			}

			$pendentes[] = sprintf(
				'#%1$d %2$s (depende de %3$s)',
				(int) $posicao + 1,
				$alvo,
				(string) $suspensas[ $alvo ]['por']
			);
		}

		return $pendentes;
	}

	/**
	 * Texto do fecho suspenso por esta unidade.
	 *
	 * Diz também o que NÃO foi suspenso, porque é essa metade que o operador
	 * precisa para não achar que a execução parou: as unidades independentes
	 * continuam, e a entrega roda de qualquer jeito.
	 *
	 * @param array<int,string> $dependentes Ids suspensos.
	 * @return string
	 */
	private static function texto_dependentes( array $dependentes ): string {
		if ( array() === $dependentes ) {
			return __( 'Nenhuma unidade declara depender desta: o fecho de suspensão é vazio e a execução segue em TODAS as demais, inclusive a entrega e o encerramento.', 'f3base' );
		}

		return sprintf(
			/* translators: 1: quantidade de unidades, 2: lista nomeada com a dependência de cada uma. */
			__( 'Suspensas por dependência declarada — %1$d unidade(s), e só elas: %2$s. As unidades independentes continuam executando, e a entrega roda de qualquer jeito.', 'f3base' ),
			count( $dependentes ),
			implode( ', ', $dependentes )
		);
	}

	/**
	 * Unidades interrompidas nesta execução: id => estado observado.
	 *
	 * @param string $execucao Identificador da execução.
	 * @return array<string,string>
	 */
	private static function interrompidas( string $execucao ): array {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		if ( ! is_array( $atual ) || ! isset( $atual['execucao'], $atual['unidades'] ) || ! is_array( $atual['unidades'] ) ) {
			return array();
		}

		if ( (string) $atual['execucao'] !== $execucao ) {
			return array();
		}

		$saida = array();

		foreach ( $atual['unidades'] as $registro ) {
			if ( ! is_array( $registro ) ) {
				continue;
			}

			$id = isset( $registro['id'] ) ? (string) $registro['id'] : '';

			if ( '' !== $id ) {
				$saida[ $id ] = isset( $registro['estado'] ) ? (string) $registro['estado'] : F3Base_Imp_Relatorio::BLOCKED;
			}
		}

		return $saida;
	}

	/**
	 * Motivo registrado de uma unidade interrompida.
	 *
	 * @param string $execucao Execução.
	 * @param string $id       Id da unidade.
	 * @return string
	 */
	private static function motivo_da_interrompida( string $execucao, string $id ): string {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		if ( ! is_array( $atual ) || ! isset( $atual['unidades'] ) || ! is_array( $atual['unidades'] ) ) {
			return '';
		}

		foreach ( $atual['unidades'] as $registro ) {
			if ( is_array( $registro ) && $id === (string) ( $registro['id'] ?? '' ) ) {
				return (string) ( $registro['motivo'] ?? '' );
			}
		}

		return '';
	}

	/**
	 * Registra que esta unidade fechou em BLOCKED nesta execução.
	 *
	 * @param string            $execucao    Identificador da execução.
	 * @param int               $indice      Índice da unidade.
	 * @param string            $id          Id declarado da unidade.
	 * @param string            $estado      Estado observado (BLOCKED ou FALHA).
	 * @param string            $motivo      Motivo já montado.
	 * @param array<int,string> $dependentes Unidades do fecho suspenso.
	 * @return void
	 */
	private static function registrar_bloqueio( string $execucao, int $indice, string $id, string $estado, string $motivo, array $dependentes ): void {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		$mesmo = is_array( $atual )
			&& isset( $atual['execucao'], $atual['unidades'] )
			&& (string) $atual['execucao'] === $execucao
			&& is_array( $atual['unidades'] );

		$registro = $mesmo
			? $atual
			: array(
				'execucao' => $execucao,
				'unidades' => array(),
			);

		$registro['unidades'][ (string) $indice ] = array(
			'id'          => $id,
			'estado'      => $estado,
			'motivo'      => $motivo,
			'dependentes' => $dependentes,
			'em'          => time(),
		);

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_BLOQUEIOS, $registro );
	}

	/**
	 * Bloqueio já registrado para esta unidade nesta execução.
	 *
	 * @param string $execucao Identificador da execução.
	 * @param int    $indice   Índice da unidade.
	 * @return array<string,mixed> Registro, ou array vazio quando não há.
	 */
	private static function bloqueio_registrado( string $execucao, int $indice ): array {
		$atual = get_option( self::OPTION_BLOQUEIOS, array() );

		if ( ! is_array( $atual ) || ! isset( $atual['execucao'], $atual['unidades'] ) || ! is_array( $atual['unidades'] ) ) {
			return array();
		}

		if ( (string) $atual['execucao'] !== $execucao || ! isset( $atual['unidades'][ (string) $indice ] ) ) {
			return array();
		}

		$registro = $atual['unidades'][ (string) $indice ];

		if ( ! is_array( $registro ) ) {
			return array();
		}

		return array(
			'motivo'      => isset( $registro['motivo'] ) ? (string) $registro['motivo'] : '',
			'dependentes' => ( isset( $registro['dependentes'] ) && is_array( $registro['dependentes'] ) ) ? $registro['dependentes'] : array(),
			'em'          => isset( $registro['em'] ) ? (int) $registro['em'] : 0,
		);
	}

	/**
	 * Executa uma unidade.
	 *
	 * @param array{etapa:string,acao:string,indice:int,rotulo:string} $unidade Unidade.
	 * @param string                                                   $modo    Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function executar( array $unidade, string $modo ): array {
		switch ( $unidade['acao'] ) {
			case 'preflight':
				return self::etapa_preflight( $modo );

			case 'tema':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_tema() );

			case 'site_core':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_site_core() );

			case 'plugin_instalavel':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_instalavel( $unidade['indice'] ) );

			case 'plugin_embarcado':
				return self::normalizar( F3Base_Imp_Plugins::aplicar_embarcado( $unidade['indice'] ) );

			case 'backups_podados':
				return self::normalizar( F3Base_Imp_Plugins::podar_backups() );

			case 'autoupdate':
				return self::normalizar( F3Base_Imp_Plugins::ligar_autoupdate() );

			case 'onboarding':
				return self::normalizar( F3Base_Imp_Plugins::suprimir_onboarding() );

			case 'opcoes_wp':
				return self::etapa_opcoes_wp();

			case 'indexacao':
				return self::etapa_indexacao();

			case 'midia':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_midia( $unidade['indice'] ) );

			case 'categoria':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_categoria( $unidade['indice'] ) );

			case 'pagina':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_pagina( $unidade['indice'] ) );

			case 'post':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_post( $unidade['indice'] ) );

			case 'conteudo_nao_gerenciado':
				return self::normalizar( F3Base_Imp_Conteudo::relatar_nao_gerenciado() );

			case 'exemplo_do_wordpress':
				return self::normalizar( F3Base_Imp_Conteudo::aplicar_exemplo_do_wordpress() );

			case 'paginas_especiais':
				return self::etapa_paginas_especiais();

			case 'navegacao':
				return self::normalizar( F3Base_Imp_Navegacao::aplicar() );

			case 'seo_identidade':
				return self::com_plugin_de_seo( 'seo.identidade', array( 'F3Base_Imp_Seo', 'aplicar_identidade' ) );

			case 'seo_social':
				return self::com_plugin_de_seo( 'seo.social', array( 'F3Base_Imp_Seo', 'aplicar_social' ) );

			case 'seo_geral':
				return self::com_plugin_de_seo( 'seo.geral', array( 'F3Base_Imp_Seo', 'aplicar_geral' ) );

			case 'seo_llms':
				return self::com_plugin_de_seo( 'seo.llms_selecao', array( 'F3Base_Imp_Seo', 'aplicar_llms' ) );

			case 'seo_robots':
				return self::normalizar( F3Base_Imp_Seo::aplicar_robots_txt() );

			case 'orfaos_anteriores':
				return self::normalizar( F3Base_Imp_Plugins::migrar_orfaos_anteriores() );

			case 'mcp':
				return F3Base_Imp_Entrega::etapa_canal_mcp();

			case 'options_site_core':
				return self::etapa_options_site_core();

			case 'formularios':
				return self::etapa_formularios();

			case 'cadencia':
				return self::etapa_cadencia();

			case 'entrega':
				return self::etapa_entrega( $modo );

			case 'encerramento':
				return self::etapa_encerramento( $modo );

			default:
				return array(
					'estado' => F3Base_Imp_Relatorio::FALHA,
					'rotulo' => 'lote.acao_desconhecida',
					'motivo' => sprintf(
						/* translators: %s: nome da ação. */
						__( 'ação de lote desconhecida: %s. Defeito do orquestrador, não do site.', 'f3base' ),
						$unidade['acao']
					),
				);
		}
	}

	/* ------------------------------------------------------------------ *
	 * Etapas
	 * ------------------------------------------------------------------ */

	/**
	 * Preflight: mede tudo e decide se pode haver mutação.
	 *
	 * @param string $modo Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_preflight( string $modo ): array {
		$medido = F3Base_Imp_Preflight::executar();

		foreach ( $medido['capacidades'] as $cap => $dados ) {
			F3Base_Imp_Relatorio::condicional(
				$dados['critica'],
				sprintf(
					/* translators: 1: capacidade, 2: motivo declarado, 3: presença observada. */
					__( 'a capacidade %1$s não é crítica nesta instalação — %2$s (observada no usuário em operação: %3$s).', 'f3base' ),
					$cap,
					$dados['motivo'],
					$dados['tem'] ? __( 'presente', 'f3base' ) : __( 'ausente', 'f3base' )
				),
				$dados['tem'],
				'preflight.capacidade:' . $cap,
				sprintf(
					/* translators: %s: capacidade. */
					__( 'capacidade %s presente no usuário em operação.', 'f3base' ),
					$cap
				),
				sprintf(
					/* translators: 1: capacidade, 2: motivo da criticidade. */
					__( 'capacidade crítica ausente: %1$s. %2$s Nenhuma mutação é executada.', 'f3base' ),
					$cap,
					$dados['motivo']
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}

		F3Base_Imp_Relatorio::avaliar(
			$medido['filesystem']['direto'],
			'preflight.filesystem_direto',
			sprintf(
				/* translators: %s: método observado. */
				__( 'método de filesystem: %s.', 'f3base' ),
				$medido['filesystem']['metodo']
			),
			sprintf(
				/* translators: %s: método observado. */
				__( 'o método de filesystem é %s, não direto: instalar tema e plugins exigiria credencial do operador a cada passo.', 'f3base' ),
				$medido['filesystem']['metodo']
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		foreach ( $medido['destinos'] as $nome => $destino ) {
			F3Base_Imp_Relatorio::avaliar(
				$destino['gravavel'],
				'preflight.destino:' . $nome,
				sprintf(
					/* translators: 1: nome do destino, 2: caminho. */
					__( 'destino gravável: %1$s em %2$s.', 'f3base' ),
					$nome,
					$destino['caminho']
				),
				sprintf(
					/* translators: 1: nome do destino, 2: caminho. */
					__( 'destino NÃO gravável: %1$s em %2$s.', 'f3base' ),
					$nome,
					$destino['caminho']
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}

		F3Base_Imp_Relatorio::avaliar(
			$medido['disco']['suficiente'],
			'preflight.disco',
			sprintf(
				/* translators: 1: bytes livres, 2: bytes necessários. */
				__( 'espaço livre %1$s bytes contra %2$s bytes necessários (pacote temporário, instalação e preimagem).', 'f3base' ),
				number_format_i18n( (float) $medido['disco']['livre'] ),
				number_format_i18n( (float) $medido['disco']['necessario'] )
			),
			sprintf(
				/* translators: 1: bytes livres, 2: bytes necessários. */
				__( 'espaço insuficiente: %1$s bytes livres contra %2$s necessários.', 'f3base' ),
				number_format_i18n( (float) $medido['disco']['livre'] ),
				number_format_i18n( (float) $medido['disco']['necessario'] )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		F3Base_Imp_Relatorio::avaliar(
			$medido['rede']['alcancavel'],
			'preflight.saida_https',
			sprintf(
				/* translators: 1: alvo, 2: detalhe. */
				__( 'saída HTTPS para a fonte oficial alcançável: %1$s (%2$s).', 'f3base' ),
				$medido['rede']['alvo'],
				$medido['rede']['detalhe']
			),
			sprintf(
				/* translators: 1: alvo, 2: detalhe. */
				__( 'saída HTTPS indisponível para %1$s: %2$s. A instalação manual pelo wp-admin é o caminho de contingência declarado.', 'f3base' ),
				$medido['rede']['alvo'],
				$medido['rede']['detalhe']
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		$php_minimo = (string) F3Base_Imp_Config::obter( 'ambiente.php_minimo', '8.1' );

		F3Base_Imp_Relatorio::avaliar(
			! version_compare( PHP_VERSION, $php_minimo, '<' ),
			'preflight.php_minimo',
			sprintf(
				/* translators: 1: versão em execução, 2: mínimo declarado. */
				__( 'PHP %1$s atende ao mínimo declarado %2$s.', 'f3base' ),
				PHP_VERSION,
				$php_minimo
			),
			sprintf(
				/* translators: 1: versão em execução, 2: mínimo declarado. */
				__( 'PHP %1$s abaixo do mínimo declarado %2$s.', 'f3base' ),
				PHP_VERSION,
				$php_minimo
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		/*
		 * O ESTADO SAI DA MEDIÇÃO, e é aqui que a lição da 1.0.14 está escrita
		 * em código: esta linha era WARN incondicional. Ela dizia de si mesma
		 * "fato de ambiente, relatado sem decidir gate" e ainda assim promovia a
		 * unidade do preflight a amarelo, numa execução em que nada estava
		 * errado. WARN que sai sempre treina o operador a ignorar WARN — a mesma
		 * família do "24 FALHA por ausência de terceiro" e da checagem que
		 * acusava o próprio pacote.
		 *
		 * Agora: limites suficientes para a execução em lotes fecham OK NOMEANDO
		 * os valores medidos; limite abaixo do piso declarado em
		 * `ambiente.limites_minimos` fecha WARN nomeando QUAL ficou abaixo e o
		 * que ele custa. O detalhe não sumiu do relatório — mudou de estado.
		 */
		$limites = self::veredito_de_limites(
			(array) $medido['limites'],
			array(
				'max_execution_time_s'   => (int) F3Base_Imp_Config::obter( 'ambiente.limites_minimos.max_execution_time_s', 0 ),
				'memory_mb'              => (int) F3Base_Imp_Config::obter( 'ambiente.limites_minimos.memory_mb', 0 ),
				'upload_max_filesize_mb' => (int) F3Base_Imp_Config::obter( 'ambiente.limites_minimos.upload_max_filesize_mb', 0 ),
				'post_max_size_mb'       => (int) F3Base_Imp_Config::obter( 'ambiente.limites_minimos.post_max_size_mb', 0 ),
			)
		);

		F3Base_Imp_Relatorio::emitir(
			$limites['estado'],
			'preflight.limites',
			$limites['motivo'],
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		$divergencias = $medido['baseline']['divergencias'];

		/*
		 * OS ARTEFATOS DO PACOTE SÃO BASELINE POR DEFINIÇÃO, e a mensagem do
		 * ramo OK os NOMEIA com a chave da configuração que os resolveu: a 1.0.7
		 * acusou `f3base-site-core` — o plugin que este pacote instala e ativa —
		 * como divergência a classificar, e a saída que a própria mensagem
		 * oferecia teria feito o pacote se declarar plugin de terceiro.
		 */
		$artefatos = array_map(
			static fn ( array $item ): string => $item['slug'] . ' [' . $item['tipo'] . ', de ' . $item['origem'] . ']',
			(array) $medido['baseline']['artefatos']
		);

		F3Base_Imp_Relatorio::avaliar(
			array() === $divergencias,
			'preflight.baseline',
			sprintf(
				/* translators: 1: versão do WordPress, 2: tema ativo, 3: quantidade de plugins, 4: artefatos do pacote com a origem de cada um, 5: se o tema ativo é o do pacote. */
				__( 'baseline: WordPress %1$s, tema ativo %2$s (%5$s), %3$d plugin(s) no disco, todos com classe declarada — artefato-do-pacote, gerenciado, protegido ou externo-preservado. Artefatos deste pacote, baseline por definição e resolvidos dos slugs declarados, nunca de lista literal no código: %4$s.', 'f3base' ),
				(string) $medido['baseline']['wordpress'],
				(string) $medido['baseline']['tema_ativo'],
				count( $medido['baseline']['plugins'] ),
				array() === $artefatos ? __( 'nenhum declarado', 'f3base' ) : implode( '; ', $artefatos ),
				$medido['baseline']['tema_e_do_pacote']
					? __( 'o tema ativo é o declarado em site.tema_slug', 'f3base' )
					: __( 'o tema ativo NÃO é o declarado em site.tema_slug', 'f3base' )
			),
			sprintf(
				/* translators: 1: nomes dos plugins sem classe, 2: artefatos do pacote, que não entram nesta lista. */
				__( 'plugins ativos fora da baseline E fora das listas declaradas — divergência a classificar antes de aplicar, não ruído: %1$s. A saída é declará-los em plugins.operacionais (slug, finalidade, responsável) ou em plugins.protegidos. Os artefatos deste pacote não entram nesta lista, por definição: %2$s.', 'f3base' ),
				implode( ', ', array_map( static fn ( array $item ): string => $item['slug'] . ' ' . $item['versao'], $divergencias ) ),
				array() === $artefatos ? __( 'nenhum declarado', 'f3base' ) : implode( '; ', $artefatos )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		F3Base_Imp_Relatorio::avaliar(
			array() === $medido['colisoes']['conflitos'],
			'preflight.colisao_de_slug',
			sprintf(
				/* translators: 1: quantidade de refs livres, 2: adoções autorizadas. */
				__( 'nenhuma colisão sem propriedade: %1$d referência(s) livre(s) ou já gerenciada(s); adoções autorizadas e provadas pela instalação: %2$s.', 'f3base' ),
				count( $medido['colisoes']['livres'] ),
				array() === $medido['colisoes']['adocoes']
					? __( 'nenhuma', 'f3base' )
					: implode( ', ', array_map( static fn ( array $item ): string => $item['ref'] . ' (#' . $item['id'] . ')', $medido['colisoes']['adocoes'] ) )
			),
			sprintf(
				/* translators: %s: conflitos nomeados. */
				__( 'CONFLICT sem escrita — slug igual não prova propriedade: %s', 'f3base' ),
				implode( ' | ', array_map( static fn ( array $item ): string => $item['ref'] . ' → #' . $item['id'] . ' "' . $item['titulo'] . '": ' . $item['motivo'], $medido['colisoes']['conflitos'] ) )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		/*
		 * OVERRIDE É PERGUNTA DE CONTEÚDO, NÃO DE EXISTÊNCIA. O WordPress cria
		 * o post `wp_global_styles` sozinho ao ativar um tema de blocos, e a
		 * versão anterior, medindo existência, reprovaria TODA instalação de
		 * tema de blocos, para sempre — a FALHA que sai sempre é a que ensina o
		 * operador a ignorar FALHA.
		 *
		 * A outra metade do erro seria sumir com o stub do relatório: ele
		 * aparece NOMEADO na linha de aprovação, como post inspecionado e
		 * inofensivo, com o motivo que o absolveu.
		 */
		$overrides    = $medido['overrides'];
		$personalizam = array_values( array_filter( $overrides, static fn ( array $item ): bool => (bool) $item['override'] ) );
		$inofensivos  = array_values( array_filter( $overrides, static fn ( array $item ): bool => ! (bool) $item['override'] ) );

		$descrever = static fn ( array $item ): string => $item['tipo'] . ':' . $item['slug'] . ' (#' . $item['id'] . ', ' . $item['bytes'] . ' bytes, ' . $item['data'] . ')';

		F3Base_Imp_Relatorio::avaliar(
			array() === $personalizam,
			'tema.sem_override_de_editor',
			sprintf(
				/* translators: 1: quantidade de posts inspecionados, 2: posts inspecionados e absolvidos, com o motivo de cada um. */
				__( 'nenhuma personalização do editor de site: %1$d post(s) de wp_template, wp_template_part e wp_global_styles inspecionado(s) POR CONTEÚDO, e o arquivo do tema continua sendo o que o visitante recebe. Inspecionado(s) e sem personalização: %2$s.', 'f3base' ),
				count( $overrides ),
				array() === $inofensivos
					? __( 'nenhum post desses tipos existe neste site', 'f3base' )
					: implode( ' | ', array_map( static fn ( array $item ): string => $descrever( $item ) . ' — ' . $item['motivo'], $inofensivos ) )
			),
			sprintf(
				/* translators: 1: overrides com personalização, com o motivo de cada um, 2: posts inspecionados e absolvidos. */
				__( 'overrides do editor de site com personalização de fato — o BANCO VENCE O ARQUIVO, e atualizar o tema não muda o que o visitante recebe enquanto eles existirem: %1$s. A política é exportar, decidir (incorporar ao arquivo ou reverter) e remover; nunca conviver. Inspecionados e sem personalização, que não entram nesta acusação: %2$s.', 'f3base' ),
				implode( ' | ', array_map( static fn ( array $item ): string => $descrever( $item ) . ' — ' . $item['motivo'], $personalizam ) ),
				array() === $inofensivos ? __( 'nenhum', 'f3base' ) : implode( ' | ', array_map( $descrever, $inofensivos ) )
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		F3Base_Imp_Relatorio::avaliar(
			$medido['origem']['suportada'],
			'preflight.contrato_de_caminho',
			sprintf(
				/* translators: %s: motivo declarado. */
				__( 'origem de release suportada: %s', 'f3base' ),
				$medido['origem']['motivo']
			),
			$medido['origem']['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		/*
		 * "Declara o schema e validou contra ele" É O RAMO BOM, e sair em WARN
		 * fazia a linha dizer o contrário do que media. O estado agora vem da
		 * medição: schema declarado e sem erro de validação fecha OK com o
		 * detalhe no texto; schema não declarado, ou erro de validação
		 * registrado, fecha WARN nomeando o que está adverso.
		 */
		$schema_declarado = (string) F3Base_Imp_Config::obter( '$schema', '' );
		$erros_do_schema  = F3Base_Imp_Config::erros();

		if ( '' !== $schema_declarado && array() === $erros_do_schema ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'config.schema_declarado',
				sprintf(
					/* translators: 1: schema declarado no arquivo, 2: hash da configuração. */
					__( 'a configuração declara o schema %1$s e validou contra ele, sem erro registrado; hash da configuração: %2$s.', 'f3base' ),
					$schema_declarado,
					substr( F3Base_Imp_Config::hash(), 0, 16 )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'config.schema_declarado',
				sprintf(
					/* translators: 1: o que está adverso, 2: hash da configuração. */
					__( 'a configuração NÃO está amarrada a um schema válido: %1$s. Sem essa amarração, chave escrita errada entra em silêncio e só aparece como comportamento estranho no site. Hash da configuração: %2$s.', 'f3base' ),
					'' === $schema_declarado
						? __( 'a chave $schema está ausente ou vazia', 'f3base' )
						: sprintf(
							/* translators: 1: quantidade de erros, 2: erros nomeados. */
							__( '%1$d erro(s) de validação registrados contra %2$s', 'f3base' ),
							count( $erros_do_schema ),
							$schema_declarado
						) . ': ' . implode( ' | ', $erros_do_schema ),
					substr( F3Base_Imp_Config::hash(), 0, 16 )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		}

		if ( $medido['bloqueado'] ) {
			if ( self::MODO_EXECUCAO === $modo ) {
				self::definir_estado( self::FALHA );
			}

			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => 'preflight',
				'motivo' => sprintf(
					/* translators: 1: capacidades ausentes, 2: quantidade de conflitos. */
					__( 'preflight BLOCKED, sem mutação: capacidades/pré-condições ausentes (%1$s) e %2$d colisão(ões) de slug sem propriedade.', 'f3base' ),
					array() === $medido['criticas_ausentes'] ? __( 'nenhuma', 'f3base' ) : implode( ', ', $medido['criticas_ausentes'] ),
					count( $medido['colisoes']['conflitos'] )
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'rotulo' => 'preflight',
			'motivo' => __( 'preflight completo: capacidades, filesystem, destinos, disco, rede, limites, baseline, colisões, overrides e contrato de caminho medidos, e nenhum impedimento crítico.', 'f3base' ),
		);
	}

	/**
	 * O veredito dos limites do PHP: OK quando bastam, WARN quando um não basta.
	 *
	 * FUNÇÃO PURA — recebe o que foi medido e o piso declarado, e devolve estado
	 * e texto. Nenhuma leitura de ambiente aqui dentro: é o que permite exercitar
	 * os DOIS ramos na sonda, que é o piso desta regra.
	 *
	 * `max_execution_time = 0` é AUSÊNCIA de limite, nunca limite zero — tratar
	 * o zero como "abaixo do piso" faria a checagem acusar exatamente o ambiente
	 * mais folgado que existe.
	 *
	 * @param array<string,mixed> $medido  Saída de F3Base_Imp_Preflight::medir_limites().
	 * @param array<string,int>   $minimos Piso declarado em ambiente.limites_minimos.
	 * @return array{estado:string,motivo:string,abaixo:array<int,string>}
	 */
	public static function veredito_de_limites( array $medido, array $minimos ): array {
		$tempo   = (int) ( $medido['max_execution_time'] ?? 0 );
		$memoria = (int) ( $medido['memoria_bytes'] ?? 0 );
		$upload  = (int) ( $medido['upload_bytes'] ?? 0 );
		$post    = (int) ( $medido['post_bytes'] ?? 0 );

		$piso_tempo   = (int) ( $minimos['max_execution_time_s'] ?? 0 );
		$piso_memoria = (int) ( $minimos['memory_mb'] ?? 0 ) * 1048576;
		$piso_upload  = (int) ( $minimos['upload_max_filesize_mb'] ?? 0 ) * 1048576;
		$piso_post    = (int) ( $minimos['post_max_size_mb'] ?? 0 ) * 1048576;

		$abaixo = array();

		if ( 0 !== $tempo && $tempo < $piso_tempo ) {
			$abaixo[] = sprintf(
				/* translators: 1: tempo observado, 2: piso declarado. */
				__( 'max_execution_time %1$ds contra o piso declarado de %2$ds — o servidor interrompe o lote no meio da gravação, e a retomada refaz a etapa inteira', 'f3base' ),
				$tempo,
				$piso_tempo
			);
		}

		if ( $memoria < $piso_memoria ) {
			$abaixo[] = sprintf(
				/* translators: 1: memória observada, 2: piso declarado em MB. */
				__( 'memory_limit %1$s contra o piso declarado de %2$d MB — a montagem de um lote morre sem relatório, que é a pior falha possível: nenhuma linha sai', 'f3base' ),
				(string) ( $medido['memory_limit'] ?? '' ),
				(int) ( $minimos['memory_mb'] ?? 0 )
			);
		}

		if ( $upload < $piso_upload ) {
			$abaixo[] = sprintf(
				/* translators: 1: limite observado, 2: piso declarado em MB. */
				__( 'upload_max_filesize %1$s contra o piso declarado de %2$d MB — o zip de um plugin ou o envio de mídia é recusado pelo próprio PHP, antes de qualquer código deste pacote', 'f3base' ),
				(string) ( $medido['upload_max_filesize'] ?? '' ),
				(int) ( $minimos['upload_max_filesize_mb'] ?? 0 )
			);
		}

		if ( $post < $piso_post ) {
			$abaixo[] = sprintf(
				/* translators: 1: limite observado, 2: piso declarado em MB. */
				__( 'post_max_size %1$s contra o piso declarado de %2$d MB — o corpo inteiro da requisição não cabe, e o envio falha mesmo com upload_max_filesize suficiente', 'f3base' ),
				(string) ( $medido['post_max_size'] ?? '' ),
				(int) ( $minimos['post_max_size_mb'] ?? 0 )
			);
		}

		$observados = sprintf(
			/* translators: 1: tempo, 2: memória, 3: upload, 4: post. */
			__( 'max_execution_time %1$s, memory_limit %2$s, upload_max_filesize %3$s, post_max_size %4$s', 'f3base' ),
			0 === $tempo ? __( 'sem limite', 'f3base' ) : $tempo . 's',
			(string) ( $medido['memory_limit'] ?? '' ),
			(string) ( $medido['upload_max_filesize'] ?? '' ),
			(string) ( $medido['post_max_size'] ?? '' )
		);

		if ( array() === $abaixo ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: 1: limites observados, 2: piso declarado. */
					__( 'limites suficientes para a execução em lotes — %1$s. Piso declarado em ambiente.limites_minimos: %2$s. Nenhum limite ficou abaixo dele, e é por isso que esta linha é OK: medição sem achado adverso não é aviso.', 'f3base' ),
					$observados,
					sprintf(
						/* translators: 1: tempo, 2: memória, 3: upload, 4: post. */
						__( '%1$ds, %2$d MB, %3$d MB, %4$d MB', 'f3base' ),
						$piso_tempo,
						(int) ( $minimos['memory_mb'] ?? 0 ),
						(int) ( $minimos['upload_max_filesize_mb'] ?? 0 ),
						(int) ( $minimos['post_max_size_mb'] ?? 0 )
					)
				),
				'abaixo' => array(),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::WARN,
			'motivo' => sprintf(
				/* translators: 1: quantidade abaixo do piso, 2: cada um nomeado com o custo, 3: limites observados. */
				__( '%1$d limite(s) ABAIXO do piso declarado em ambiente.limites_minimos, com o que cada um custa: %2$s. Observados: %3$s. Não bloqueia a execução — a execução em lotes existe justamente para caber em ambiente apertado —, e é aviso porque a folga que a retomada supõe deixou de existir.', 'f3base' ),
				count( $abaixo ),
				implode( '; ', $abaixo ),
				$observados
			),
			'abaixo' => $abaixo,
		);
	}

	/**
	 * Nome, descrição, idioma, fuso e permalinks.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_opcoes_wp(): array {
		$partes = array();
		$falhou = false;

		foreach (
			array(
				'blogname'        => (string) F3Base_Imp_Config::obter( 'site.nome', '' ),
				'blogdescription' => (string) F3Base_Imp_Config::obter( 'site.tagline', '' ),
				'timezone_string' => (string) F3Base_Imp_Config::obter( 'ambiente.fuso', '' ),
			) as $option => $valor
		) {
			$resultado = F3Base_Imp_Gravador::gravar( $option, $valor );
			$partes[]  = $option . ': ' . $resultado['motivo'];
			$falhou    = $falhou || in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::FALHA, F3Base_Imp_Relatorio::BLOCKED ), true );
		}

		$locale     = (string) F3Base_Imp_Config::obter( 'ambiente.locale', 'en_US' );
		$disponivel = in_array( $locale, array_merge( array( 'en_US' ), get_available_languages() ), true );

		if ( ! $disponivel && ! F3Base_Imp_Gravador::em_simulacao() ) {
			if ( ! function_exists( 'wp_download_language_pack' ) ) {
				require_once ABSPATH . 'wp-admin/includes/translation-install.php';
			}

			$baixado    = wp_download_language_pack( $locale );
			$disponivel = false !== $baixado && in_array( $locale, array_merge( array( 'en_US' ), get_available_languages() ), true );
		}

		if ( $disponivel ) {
			$resultado = F3Base_Imp_Gravador::gravar( 'WPLANG', 'en_US' === $locale ? '' : $locale );
			$partes[]  = 'WPLANG: ' . $resultado['motivo'];
		} else {
			/*
			 * `WPLANG` sem os arquivos de tradução NÃO gera erro: o WordPress cai
			 * para o inglês, e o sintoma é discreto ("12 de July de 2026").
			 * Gravar assim mesmo produziria um site que mente sobre o idioma.
			 */
			$partes[] = sprintf(
				/* translators: %s: locale declarado. */
				__( 'WPLANG NÃO gravado: o pacote de tradução de %s não está disponível e WPLANG sem arquivos cai para o inglês em silêncio.', 'f3base' ),
				$locale
			);
			$falhou   = true;
		}

		$desejado  = '/%postname%/';
		$observado = (string) get_option( 'permalink_structure', '' );
		$decisao   = self::aplicar_decisao_de_permalinks( $observado, $desejado );

		$partes[] = $decisao['resumo'];
		$falhou   = $falhou || F3Base_Imp_Relatorio::FALHA === $decisao['estado'];

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : ( F3Base_Imp_Gravador::em_simulacao() ? F3Base_Imp_Relatorio::NA : F3Base_Imp_Relatorio::OK ),
			'rotulo' => 'wordpress.opcoes',
			'motivo' => implode( ' | ', $partes ),
		);
	}

	/**
	 * A DECISÃO declarada sobre permalinks, MEDIDA antes de aplicada.
	 *
	 * Até a 1.0.10 o padrão era `manter-existente`: divergiu, BLOCKED, sem
	 * escrita. O motivo do bloqueio continua válido onde nasceu — trocar a
	 * estrutura quebra TODA URL já publicada e indexada —, mas o padrão estava
	 * errado para o que este pacote É. O implantador-base é ferramenta de
	 * CONFIGURAÇÃO INICIAL, e um padrão que se recusa a aplicar a estrutura
	 * declarada devolve ao operador exatamente o ajuste manual que o pacote
	 * existe para eliminar: a promessa é "sem passo manual".
	 *
	 * A 1.0.11 conciliou as duas coisas MEDINDO, em vez de escolher um padrão
	 * fixo — a mesma regra de `blog_public`. A 1.0.17 foi além, e o padrão
	 * passou a ser `aplicar-e-cobrir`: medir e RECUSAR devolvia ao operador uma
	 * lista de opções para escolher à mão, e o que a medição encontrava era, na
	 * instalação típica, as duas páginas que o próprio WordPress cria. Aplicar
	 * COBRINDO resolve as duas obrigações de uma vez, porque o redirect é
	 * aditivo: a estrutura declarada entra e nenhuma URL publicada passa a 404.
	 *
	 * @param string $observado Estrutura observada.
	 * @param string $desejado  Estrutura declarada.
	 * @return array{estado:string,resumo:string}
	 */
	private static function aplicar_decisao_de_permalinks( string $observado, string $desejado ): array {
		/*
		 * O PADRÃO DO TEMPLATE é `aplicar-e-cobrir` e mora no arquivo de
		 * configuração, onde o schema o exige. O padrão DESTA LEITURA é o valor
		 * CONSERVADOR, e a diferença é deliberada: chave ausente é configuração
		 * quebrada, e configuração quebrada não pode autorizar a escrita mais
		 * larga que o pacote sabe fazer.
		 */
		$decisao = (string) F3Base_Imp_Config::obter( 'ambiente.permalinks_decisao', self::PERMALINKS_SE_SEGURO );

		/*
		 * A medição só faz sentido quando há troca. Estrutura já igual não põe
		 * URL nenhuma em risco, e varrer o banco para descobrir isso seria
		 * consulta sem pergunta.
		 */
		$medicao  = $observado === $desejado ? array( 'em_risco' => array(), 'sem_caminho' => array() ) : self::medir_urls_de_terceiro();
		$veredito = self::decisao_de_permalinks( $decisao, $observado, $desejado, $medicao );

		if ( self::ACAO_PERMALINK_APLICAR !== $veredito['acao'] ) {
			F3Base_Imp_Relatorio::emitir(
				$veredito['estado'],
				'wordpress.permalinks',
				$veredito['motivo'],
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);

			return array(
				'estado' => $veredito['estado'],
				'resumo' => $veredito['resumo'],
			);
		}

		/*
		 * As URLs são medidas ANTES da troca: depois dela `get_permalink()` já
		 * devolve o endereço novo, e o antigo — o que continua circulando —
		 * deixa de existir para quem quisesse redirecioná-lo.
		 *
		 * A COBERTURA sai do veredito, e o conjunto coberto é o MESMO que a
		 * medição já classificou como em risco: são exatamente os publicados não
		 * gerenciados com URL de caminho, os objetos por causa dos quais o
		 * padrão antigo recusava a troca. Reaproveitar a medição em vez de
		 * varrer o banco de novo é o que impede que duas varreduras com o mesmo
		 * propósito discordem sobre o mesmo banco.
		 */
		$antigas = self::urls_dos_gerenciados();

		if ( (bool) ( $veredito['cobertura'] ?? false ) ) {
			foreach ( (array) ( $medicao['em_risco'] ?? array() ) as $item ) {
				$caminho = (string) ( $item['caminho'] ?? '' );

				if ( '' === $caminho || isset( $antigas[ $caminho ] ) ) {
					continue;
				}

				$antigas[ $caminho ] = self::REF_POR_ID . (int) ( $item['id'] ?? 0 );
			}
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'wordpress.permalinks',
				sprintf(
					/* translators: 1: motivo da decisão, 2: caminhos publicados que seriam cobertos, nomeados. */
					__( 'modo simulação: nenhuma escrita. %1$s Trocaria a estrutura e gravaria o redirecionamento dos caminhos publicados hoje: %2$s.', 'f3base' ),
					$veredito['motivo'],
					array() === $antigas ? __( 'nenhum', 'f3base' ) : implode( ', ', array_keys( $antigas ) )
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'resumo' => sprintf(
					/* translators: %s: decisão declarada. */
					__( 'permalinks: modo simulação, decisão declarada "%s".', 'f3base' ),
					$decisao
				),
			);
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_OPTION,
			'permalink_structure',
			$observado,
			$desejado,
			array(
				'acao'  => 'option.restaurar',
				'nome'  => 'permalink_structure',
				'valor' => $observado,
			)
		);

		$gravou = F3Base_Imp_Gravador::gravar( 'permalink_structure', $desejado );

		/*
		 * As regras de reescrita são regravadas ANTES de recalcular os
		 * endereços novos: `get_permalink()` compõe pela estrutura, e servir a
		 * estrutura nova com as regras velhas é 404 em toda URL bonita.
		 */
		flush_rewrite_rules( false );

		$redirects = self::gravar_redirects_de_permalink( $antigas );
		$relido    = (string) get_option( 'permalink_structure', '' );
		$conferiu  = $relido === $desejado;

		$mensagem = sprintf(
			/* translators: 1: motivo da decisão, 2: motivo do gravador, 3: resultado dos redirects. */
			__( '%1$s %2$s As regras de reescrita foram regravadas. %3$s', 'f3base' ),
			$veredito['motivo'],
			$gravou['motivo'],
			$redirects['motivo']
		);

		F3Base_Imp_Relatorio::avaliar(
			$conferiu,
			'wordpress.permalinks',
			sprintf(
				/* translators: 1: mensagem da decisão, 2: valor relido. */
				__( '%1$s A leitura de volta de permalink_structure trouxe %2$s.', 'f3base' ),
				$mensagem,
				'' !== $relido ? $relido : __( 'vazio', 'f3base' )
			),
			sprintf(
				/* translators: 1: mensagem da decisão, 2: valor relido, 3: estrutura desejada. */
				__( '%1$s A leitura de volta de permalink_structure trouxe %2$s, e não %3$s: a escrita não pegou, e a estrutura servida não é a declarada.', 'f3base' ),
				$mensagem,
				'' !== $relido ? $relido : __( 'vazio', 'f3base' ),
				$desejado
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		return array(
			'estado' => $conferiu ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'resumo' => sprintf(
				/* translators: 1: decisão declarada, 2: estrutura desejada, 3: URLs antigas nomeadas. */
				__( 'permalinks: decisão "%1$s" aplicada para %2$s, e estas URLs antigas passam a responder por redirecionamento declarado: %3$s.', 'f3base' ),
				$decisao,
				$desejado,
				$redirects['nomeados']
			),
		);
	}

	/**
	 * A REGRA da decisão de permalinks, pura: mede-se fora, decide-se aqui.
	 *
	 * Separada do lado que escreve porque é ela que tem piso dos dois lados na
	 * sonda funcional — cada ramo com o mutante dele. O lado impuro (banco,
	 * `flush_rewrite_rules()`, journal) fica em
	 * `aplicar_decisao_de_permalinks()`.
	 *
	 * `cobertura` sai daqui junto com a ação, e não é o mesmo que aplicar: o
	 * ramo `aplicar-e-cobrir` aplica E grava o 301 do caminho antigo de todo
	 * publicado que muda de endereço, gerenciado ou não; os outros dois ramos
	 * que aplicam cobrem só o que o pacote gerencia. Quem escreve lê esta chave
	 * em vez de reconhecer a decisão de novo — a mesma decisão reconhecida em
	 * dois lugares é o terreno em que os dois lados divergem.
	 *
	 * @param string $decisao   Decisão declarada em `ambiente.permalinks_decisao`.
	 * @param string $observado Estrutura observada na instalação.
	 * @param string $desejado  Estrutura declarada pelo pacote.
	 * @param array{em_risco:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho:array<int,array{id:int,tipo:string,slug:string,caminho:string}>} $medicao Medição das URLs de terceiro.
	 * @return array{acao:string,estado:string,motivo:string,resumo:string,cobertura:bool}
	 */
	public static function decisao_de_permalinks( string $decisao, string $observado, string $desejado, array $medicao ): array {
		$em_risco          = (array) ( $medicao['em_risco'] ?? array() );
		$observado_legivel = '' !== $observado ? $observado : __( 'vazia (permalinks simples, endereço por ?p=)', 'f3base' );
		$risco             = self::frase_do_risco( $medicao );

		if ( $observado === $desejado ) {
			return array(
				'acao'      => self::ACAO_PERMALINK_NADA,
				'estado'    => F3Base_Imp_Relatorio::OK,
				'cobertura' => false,
				'motivo'    => sprintf(
					/* translators: %s: estrutura declarada. */
					__( 'a estrutura observada JÁ É a declarada (%s): nada a gravar, nenhuma URL publicada muda e nenhum redirecionamento é necessário. Gravar o que já está gravado seria mutação sem diferença, e é por isso que este ramo não escreve.', 'f3base' ),
					$desejado
				),
				'resumo'    => sprintf(
					/* translators: %s: estrutura declarada. */
					__( 'permalinks já em %s, sem gravação.', 'f3base' ),
					$desejado
				),
			);
		}

		if ( self::PERMALINKS_MANTER === $decisao ) {
			return array(
				'acao'      => self::ACAO_PERMALINK_BLOQUEAR,
				'estado'    => F3Base_Imp_Relatorio::BLOCKED,
				'cobertura' => false,
				'motivo'    => sprintf(
					/* translators: 1: estrutura observada, 2: estrutura declarada, 3: frase do risco medido. */
					__( 'a instalação usa a estrutura %1$s, diferente da declarada %2$s, e a decisão declarada em ambiente.permalinks_decisao é "manter-existente": NÃO aplicar é o que essa decisão pede, e nada foi escrito. %3$s Para que a configuração inicial faça o ajuste, declare "aplicar-e-cobrir" (aplica e grava 301 do caminho antigo de todo publicado que muda de endereço, gerenciado ou não), "aplicar-se-seguro" (aplica só quando nenhum publicado não gerenciado tem URL de caminho) ou "aplicar-declarada" (aplica assumindo o risco das URLs de terceiro, sem cobri-las).', 'f3base' ),
					$observado_legivel,
					$desejado,
					$risco
				),
				'resumo'    => __( 'permalinks: BLOCKED (decisão declarada "manter-existente").', 'f3base' ),
			);
		}

		/*
		 * O RAMO QUE COBRE, e a reserva que ele aposenta. Até a 1.0.16 o padrão
		 * `aplicar-se-seguro` recusava a troca diante de publicado não
		 * gerenciado com URL de caminho, com a justificativa de que este pacote
		 * não gravaria redirecionamento para conteúdo alheio. A reserva
		 * era boa para escrita DESTRUTIVA e foi aplicada por analogia a uma
		 * escrita que não destrói nada: o par de redirect é ADITIVO — não altera
		 * o objeto, não apaga nada e some quando a option some. Recusar
		 * escrevê-lo deixava o site com a estrutura de permalinks que ninguém
		 * escolheu, que é dano maior do que a reserva evitava.
		 */
		if ( self::PERMALINKS_COBRIR === $decisao ) {
			return array(
				'acao'      => self::ACAO_PERMALINK_APLICAR,
				'estado'    => F3Base_Imp_Relatorio::OK,
				'cobertura' => true,
				'motivo'    => sprintf(
					/* translators: 1: estrutura observada, 2: estrutura declarada, 3: frase do risco medido, 4: frase da cobertura. */
					__( 'decisão declarada "aplicar-e-cobrir": aplica a estrutura declarada E COBRE com 301 o caminho antigo de todo publicado que muda de endereço, gerenciado ou não. %3$s %4$s A estrutura passa de %1$s para %2$s, e o redirecionamento é ADITIVO — não altera o objeto de ninguém, não apaga nada e some junto com a option: por isso ele pode ser gravado para conteúdo que este pacote não gerencia, e a recusa que existia aqui deixava o site com a estrutura que ninguém escolheu.', 'f3base' ),
					$observado_legivel,
					$desejado,
					$risco,
					self::frase_da_cobertura( $medicao )
				),
				'resumo'    => sprintf(
					/* translators: %s: objetos não gerenciados que a cobertura alcança, nomeados. */
					__( 'permalinks: aplicada (aplicar-e-cobrir), cobrindo o publicado não gerenciado: %s.', 'f3base' ),
					self::frase_da_cobertura( $medicao )
				),
			);
		}

		if ( self::PERMALINKS_SE_SEGURO === $decisao ) {
			if ( array() !== $em_risco ) {
				return array(
					'acao'      => self::ACAO_PERMALINK_BLOQUEAR,
					'estado'    => F3Base_Imp_Relatorio::BLOCKED,
					'cobertura' => false,
					'motivo'    => sprintf(
						/* translators: 1: estrutura observada, 2: estrutura declarada, 3: frase do risco medido. */
						__( 'decisão declarada "aplicar-se-seguro": MEDE antes de decidir, e a medição diz que NÃO é seguro. %3$s Trocar a estrutura de %1$s para %2$s quebraria essas URLs, e este valor não cobre conteúdo que o pacote não gerencia: nada foi escrito. Para aplicar COBRINDO essas URLs com 301, declare "aplicar-e-cobrir", que é o padrão do template; para aplicar assumindo o risco sem cobrir, "aplicar-declarada"; para manter a estrutura atual como escolha, "manter-existente"; ou traga esses objetos para a gestão (declare-os em paginas/posts) ou despublique-os e execute de novo.', 'f3base' ),
						$observado_legivel,
						$desejado,
						$risco
					),
					'resumo'    => sprintf(
						/* translators: %s: objetos em risco, nomeados. */
						__( 'permalinks: BLOCKED (aplicar-se-seguro) por publicado(s) não gerenciado(s) com URL em risco: %s.', 'f3base' ),
						self::nomear_publicados( $em_risco )
					),
				);
			}

			return array(
				'acao'      => self::ACAO_PERMALINK_APLICAR,
				'estado'    => F3Base_Imp_Relatorio::OK,
				'cobertura' => false,
				'motivo'    => sprintf(
					/* translators: 1: estrutura observada, 2: estrutura declarada, 3: frase do risco medido. */
					__( 'decisão declarada "aplicar-se-seguro": MEDE antes de decidir, e a medição diz que É seguro. %3$s Sem URL de terceiro para quebrar, aplicar a estrutura declarada é o que a configuração inicial deve fazer, e não deixar como passo manual: a estrutura passa de %1$s para %2$s.', 'f3base' ),
					$observado_legivel,
					$desejado,
					$risco
				),
				'resumo'    => __( 'permalinks: aplicada (aplicar-se-seguro, nenhuma URL de terceiro em risco).', 'f3base' ),
			);
		}

		if ( self::PERMALINKS_DECLARADA === $decisao ) {
			return array(
				'acao'      => self::ACAO_PERMALINK_APLICAR,
				'estado'    => F3Base_Imp_Relatorio::OK,
				'cobertura' => false,
				'motivo'    => sprintf(
					/* translators: 1: estrutura observada, 2: estrutura declarada, 3: frase do risco medido. */
					__( 'decisão declarada "aplicar-declarada": aplica SEMPRE, inclusive com conteúdo de terceiro publicado, e SEM cobrir a URL dele — o risco fica REGISTRADO aqui em vez de descoberto depois. %3$s A estrutura passa de %1$s para %2$s por decisão do projeto, não por medição. Para que essas URLs passem a responder 301 em vez de 404, declare "aplicar-e-cobrir".', 'f3base' ),
					$observado_legivel,
					$desejado,
					$risco
				),
				'resumo'    => sprintf(
					/* translators: %s: objetos não gerenciados sobre os quais o risco foi assumido, nomeados. */
					__( 'permalinks: aplicada (aplicar-declarada), risco assumido e NÃO coberto sobre: %s.', 'f3base' ),
					array() === $em_risco
						? __( 'nenhum publicado não gerenciado com URL de caminho', 'f3base' )
						: self::nomear_publicados( $em_risco )
				),
			);
		}

		return array(
			'acao'      => self::ACAO_PERMALINK_BLOQUEAR,
			'estado'    => F3Base_Imp_Relatorio::BLOCKED,
			'cobertura' => false,
			'motivo'    => sprintf(
				/* translators: 1: decisão declarada, 2: decisões aceitas. */
				__( 'pré-condição ausente: ambiente.permalinks_decisao declara "%1$s", que não é nenhuma das decisões aceitas (%2$s). Nada foi escrito — valor não reconhecido não pode virar aplicação silenciosa nem recusa silenciosa. Corrija a chave para uma das declaradas e execute de novo.', 'f3base' ),
				$decisao,
				implode( ', ', self::decisoes_de_permalinks() )
			),
			'resumo'    => sprintf(
				/* translators: %s: decisão declarada. */
				__( 'permalinks: BLOCKED (decisão declarada "%s" não reconhecida).', 'f3base' ),
				$decisao
			),
		);
	}

	/**
	 * As decisões de permalinks aceitas, na ordem em que o schema as declara.
	 *
	 * @return array<int,string>
	 */
	public static function decisoes_de_permalinks(): array {
		return array( self::PERMALINKS_COBRIR, self::PERMALINKS_SE_SEGURO, self::PERMALINKS_DECLARADA, self::PERMALINKS_MANTER );
	}

	/**
	 * A frase da COBERTURA medida: o que o 301 vai alcançar, NOMEADO.
	 *
	 * Contagem responde "quantas?" e a pergunta do operador é "quais?" — as
	 * URLs cobertas saem nomeadas, uma a uma, e a lista vazia sai dita em vez de
	 * sumir. Note o que NÃO entra: o publicado não gerenciado SEM URL de
	 * caminho (endereço por `?p=N`) não muda de endereço e por isso não pode
	 * ganhar par nenhum — redirecionar um endereço para ele mesmo é laço, e é a
	 * mesma regra que `pares_de_redirect()` aplica depois sobre o caminho
	 * recalculado.
	 *
	 * @param array{em_risco?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>} $medicao Medição das URLs de terceiro.
	 * @return string
	 */
	private static function frase_da_cobertura( array $medicao ): string {
		$em_risco    = (array) ( $medicao['em_risco'] ?? array() );
		$sem_caminho = (array) ( $medicao['sem_caminho'] ?? array() );

		if ( array() === $em_risco ) {
			return array() === $sem_caminho
				? __( 'Cobertura: nenhum publicado não gerenciado tem URL de caminho a cobrir, e o 301 alcança apenas o conteúdo gerenciado que mudar de endereço.', 'f3base' )
				: sprintf(
					/* translators: %s: objetos nomeados. */
					__( 'Cobertura: nenhum publicado não gerenciado tem URL de caminho a cobrir — %s tem endereço de query (?p=N), que continua resolvendo depois da troca e não pode ganhar par, porque redirecionar um endereço para ele mesmo é laço.', 'f3base' ),
					self::nomear_publicados( $sem_caminho )
				);
		}

		return sprintf(
			/* translators: 1: objetos cobertos, nomeados; 2: complemento sobre os que não têm caminho. */
			__( 'Cobertura: o caminho publicado de %1$s passa a responder 301 para o endereço novo, pelo par gravado em f3base_redirects com origem própria.%2$s', 'f3base' ),
			self::nomear_publicados( $em_risco ),
			array() === $sem_caminho
				? ''
				: ' ' . sprintf(
					/* translators: %s: objetos nomeados. */
					__( 'Fora da cobertura, por medição e não por omissão: %s tem endereço de query (?p=N), não muda de caminho e por isso não ganha par.', 'f3base' ),
					self::nomear_publicados( $sem_caminho )
				)
		);
	}

	/**
	 * A frase do risco MEDIDO — e a lista vazia tem DUAS causas, não uma.
	 *
	 * Nenhum ramo fica em silêncio: "não há URL de terceiro em risco" é
	 * resultado de medição tanto quanto a lista de objetos, e é essa frase que
	 * sustenta o ramo que aplica. Mas a lista vazia significa duas coisas
	 * diferentes, e dizer só a primeira seria afirmar o que não se mediu:
	 *
	 * - **Nada não gerenciado publicado.** Aí sim "todo publicado é gerenciado
	 *   por este pacote" é afirmação medida.
	 * - **Não gerenciado publicado, porém sem URL de caminho.** Com permalinks
	 *   simples o endereço publicado é `?p=N`, uma URL de QUERY que continua
	 *   resolvendo depois da troca. Não há caminho a quebrar — e é isso que
	 *   torna seguro aplicar na instalação recém-criada, que é justamente o
	 *   caso em que este pacote entra. Os objetos são nomeados assim mesmo.
	 *
	 * @param array{em_risco?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho?:array<int,array{id:int,tipo:string,slug:string,caminho:string}>} $medicao Medição das URLs de terceiro.
	 * @return string
	 */
	private static function frase_do_risco( array $medicao ): string {
		$em_risco    = (array) ( $medicao['em_risco'] ?? array() );
		$sem_caminho = (array) ( $medicao['sem_caminho'] ?? array() );

		if ( array() !== $em_risco ) {
			$frase = sprintf(
				/* translators: 1: quantidade, 2: objetos nomeados. */
				__( 'Medição: %1$d conteúdo(s) PUBLICADO(S) e NÃO gerenciado(s) por este pacote tem URL de caminho em risco — %2$s.', 'f3base' ),
				count( $em_risco ),
				self::nomear_publicados( $em_risco )
			);

			/*
			 * O que foi medido e NÃO corre risco também sai nomeado: um objeto
			 * que some da mensagem some do relatório, e o operador que decide
			 * entre as três decisões precisa da medição inteira, não do
			 * recorte que sustenta o veredito.
			 */
			if ( array() !== $sem_caminho ) {
				$frase .= ' ' . sprintf(
					/* translators: 1: quantidade, 2: objetos nomeados. */
					__( 'Outro(s) %1$d publicado(s) não gerenciado(s) NÃO têm URL de caminho e a troca não os quebra — %2$s.', 'f3base' ),
					count( $sem_caminho ),
					self::nomear_publicados( $sem_caminho )
				);
			}

			return $frase;
		}

		if ( array() !== $sem_caminho ) {
			return sprintf(
				/* translators: 1: quantidade, 2: objetos nomeados. */
				__( 'Medição: existe(m) %1$d conteúdo(s) publicado(s) e NÃO gerenciado(s) por este pacote — %2$s —, e NENHUM deles tem URL de caminho: com a estrutura observada o endereço publicado é de query (?p=N), que continua resolvendo depois da troca. Nenhuma URL de terceiro está em risco.', 'f3base' ),
				count( $sem_caminho ),
				self::nomear_publicados( $sem_caminho )
			);
		}

		return __( 'Medição: TODO conteúdo publicado tem a meta de gestão deste pacote (a mesma medição de conteudo.nao_gerenciado_publicado), então nenhuma URL de terceiro está em risco.', 'f3base' );
	}

	/**
	 * Nomeia objetos medidos: id, tipo, slug e o caminho publicado.
	 *
	 * @param array<int,array{id:int,tipo:string,slug:string,caminho:string}> $itens Objetos medidos.
	 * @return string
	 */
	private static function nomear_publicados( array $itens ): string {
		$nomes = array();

		foreach ( $itens as $item ) {
			$nomes[] = sprintf(
				/* translators: 1: ID, 2: post_type, 3: slug, 4: caminho publicado. */
				__( '#%1$d %2$s (slug %3$s) publicado em %4$s', 'f3base' ),
				(int) $item['id'],
				(string) $item['tipo'],
				(string) $item['slug'],
				'' !== (string) $item['caminho'] ? (string) $item['caminho'] : '?p=' . (int) $item['id']
			);
		}

		return implode( '; ', $nomes );
	}

	/**
	 * Mede as URLs de TERCEIRO: quais quebrariam com a troca e quais não.
	 *
	 * O censo é o de `F3Base_Imp_Conteudo`, o mesmo de
	 * `conteudo.nao_gerenciado_publicado` — duas varreduras com o mesmo
	 * propósito é o terreno em que os dois vereditos divergem sobre o mesmo
	 * banco. Aqui entra uma separação a mais, e ela é medição, não
	 * conveniência: com permalinks simples o endereço publicado é `?p=N`, uma
	 * URL de QUERY que continua resolvendo depois da troca. Sem caminho, não há
	 * caminho a quebrar — e o objeto sai da lista de risco SEM sair do
	 * relatório: as duas listas voltam, e a mensagem nomeia as duas.
	 *
	 * @return array{em_risco:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho:array<int,array{id:int,tipo:string,slug:string,caminho:string}>}
	 */
	private static function medir_urls_de_terceiro(): array {
		$nao_gerenciados = F3Base_Imp_Conteudo::censo_de_publicados()['nao_gerenciados'];
		$caminhos        = array();

		foreach ( $nao_gerenciados as $item ) {
			$caminhos[ (int) $item['id'] ] = (string) wp_parse_url( (string) get_permalink( (int) $item['id'] ), PHP_URL_PATH );
		}

		return self::classificar_urls_de_terceiro( $nao_gerenciados, $caminhos );
	}

	/**
	 * A CLASSIFICAÇÃO das URLs de terceiro, pura: em risco ou sem caminho.
	 *
	 * Separada da leitura do banco porque é aqui que um objeto pode sumir em
	 * silêncio — cair de uma lista sem entrar na outra —, e sumir em silêncio é
	 * exatamente o que a mensagem de risco não pode fazer. NENHUM publicado não
	 * gerenciado sai da classificação: ou está em risco, ou está sem caminho a
	 * quebrar, e nos dois casos ele é nomeado.
	 *
	 * @param array<int,array{id:int,tipo:string,slug:string,titulo:string}> $nao_gerenciados Censo dos publicados não gerenciados.
	 * @param array<int,string>                                             $caminhos        ID => caminho publicado agora.
	 * @return array{em_risco:array<int,array{id:int,tipo:string,slug:string,caminho:string}>,sem_caminho:array<int,array{id:int,tipo:string,slug:string,caminho:string}>}
	 */
	public static function classificar_urls_de_terceiro( array $nao_gerenciados, array $caminhos ): array {
		$em_risco    = array();
		$sem_caminho = array();

		foreach ( $nao_gerenciados as $item ) {
			$caminho = (string) ( $caminhos[ (int) $item['id'] ] ?? '' );
			$medido  = array(
				'id'      => (int) $item['id'],
				'tipo'    => (string) $item['tipo'],
				'slug'    => (string) $item['slug'],
				'caminho' => $caminho,
			);

			if ( '' === $caminho || '/' === $caminho ) {
				$sem_caminho[] = $medido;
				continue;
			}

			$em_risco[] = $medido;
		}

		return array(
			'em_risco'    => $em_risco,
			'sem_caminho' => $sem_caminho,
		);
	}

	/**
	 * Caminhos publicados dos objetos gerenciados, ANTES de mexer na estrutura.
	 *
	 * Medido antes da troca de propósito: depois dela `get_permalink()` já
	 * devolve o endereço novo, e o antigo — o que continua circulando — deixa de
	 * existir para quem quisesse redirecioná-lo.
	 *
	 * @return array<string,string> Caminho antigo => referência lógica.
	 */
	private static function urls_dos_gerenciados(): array {
		$antigas = array();

		foreach ( array( 'paginas' => 'page', 'posts' => 'post' ) as $lista => $tipo ) {
			foreach ( F3Base_Imp_Config::lista( $lista ) as $indice => $entrada ) {
				unset( $entrada );

				$ref = 'paginas' === $lista
					? (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' )
					: (string) F3Base_Imp_Config::obter( 'posts.' . $indice . '.slug', '' );

				$id = F3Base_Imp_Conteudo::localizar_gerenciado( $tipo, $ref );

				if ( $id <= 0 ) {
					continue;
				}

				$url     = (string) get_permalink( $id );
				$caminho = (string) wp_parse_url( $url, PHP_URL_PATH );

				if ( '' !== $caminho && '/' !== $caminho ) {
					$antigas[ $caminho ] = $ref;
				}
			}
		}

		return $antigas;
	}

	/**
	 * A REGRA dos pares de redirect, pura: caminho antigo → caminho novo.
	 *
	 * Separada do lado que escreve pelo mesmo motivo da decisão: é aqui que
	 * mora a única regra que pode errar em silêncio, e ela tem piso na sonda
	 * funcional. Duas coisas são descartadas, e as duas por medição:
	 *
	 * - **Caminho que não mudou.** Redirecionar um endereço para ele mesmo é
	 *   laço, e o módulo do site-core casa o par ANTES do 404 — um par idêntico
	 *   redirecionaria a página viva para si própria, em loop.
	 * - **Referência sem endereço novo.** Objeto que a execução não conseguiu
	 *   localizar não tem para onde apontar, e inventar destino é pior que não
	 *   redirecionar.
	 *
	 * @param array<string,string> $antigas Caminho antigo => referência lógica.
	 * @param array<string,string> $agora   Referência lógica => caminho novo.
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	public static function pares_de_redirect( array $antigas, array $agora ): array {
		$pares = array();

		foreach ( $antigas as $caminho => $ref ) {
			$novo = (string) ( $agora[ $ref ] ?? '' );

			if ( '' === $novo || $novo === $caminho ) {
				continue;
			}

			$pares[] = array(
				'de'     => (string) $caminho,
				'para'   => $novo,
				'status' => 301,
			);
		}

		return $pares;
	}

	/**
	 * Registra, em `f3base_redirects`, o par caminho-antigo → caminho-novo.
	 *
	 * A option é a mesma que o módulo de redirects do site-core já lê, e o
	 * mecanismo é NOMEADO na mensagem porque é ele que faz o endereço antigo
	 * continuar respondendo: o par declarado é casado em `template_redirect`
	 * com prioridade 1, ANTES do 404, e sai 301 para o endereço novo. O outro
	 * mecanismo do mesmo módulo — `_f3base_old_slug`, que trata `pagename` e
	 * `name` — é o de mudança de SLUG, e não cobre troca de ESTRUTURA: o
	 * caminho velho `/blog/x/` não é slug nenhum.
	 *
	 * Pares cujo caminho não mudou são descartados: redirecionar de um endereço
	 * para ele mesmo é laço.
	 *
	 * O CONJUNTO que chega aqui depende da decisão declarada, e não desta
	 * função: sob `aplicar-e-cobrir` ele traz também os publicados que este
	 * pacote não gerencia, chaveados pelo ID. A função não distingue os dois —
	 * um par de redirect é aditivo em qualquer caso, e a decisão de cobrir ou
	 * não já foi tomada e registrada por quem sabe medir.
	 *
	 * O DEFEITO MEDIDO NO BANCO DEPOIS DA 1.0.11, e a razão de esta função ter
	 * deixado de montar o valor da option: ela gravava `array_merge( $atuais,
	 * $novos )` e o log dizia, com razão, "2 URL(s) antiga(s) respondendo por
	 * redirecionamento declarado"; mais adiante, a etapa `site_core.options`
	 * gravava a MESMA option a partir de `redirects: []` do arquivo de
	 * configuração e apagava os dois pares. As duas gravações leram de volta e
	 * conferiram — as duas mensagens eram verdadeiras no instante em que foram
	 * escritas —, e o artefato final (`a:0:{}`) contradizia a primeira: as URLs
	 * antigas respondiam 404, não 301. Duas fontes para o mesmo fato.
	 *
	 * Agora esta função REGISTRA o que computou e grava a UNIÃO DECLARADA, que
	 * é a mesma que a etapa de options do site-core grava. Nenhum lado apaga o
	 * outro, e o detector `estatica.option_fonte_unica` impede que um segundo
	 * ponto do código volte a produzir o valor desejado por fora.
	 *
	 * @param array<string,string> $antigas Caminho antigo => referência lógica.
	 * @return array{motivo:string,nomeados:string}
	 */
	private static function gravar_redirects_de_permalink( array $antigas ): array {
		$agora = array();

		foreach ( $antigas as $ref ) {
			$agora[ $ref ] = self::caminho_atual_da_referencia( (string) $ref );
		}

		$novos = self::pares_de_redirect( $antigas, $agora );

		self::registrar_redirects_computados( $novos, 'wordpress.permalinks' );

		$resultado = F3Base_Imp_Gravador::gravar( 'f3base_redirects', self::valor_desejado_de_redirects(), array( 'autoload' => true ) );
		$nomeados  = implode( ', ', array_map( static fn( array $r ): string => $r['de'] . ' → ' . $r['para'], $novos ) );

		if ( array() === $novos ) {
			return array(
				'nomeados' => __( 'nenhuma, porque nenhum caminho publicado mudou', 'f3base' ),
				'motivo'   => sprintf(
					/* translators: 1: caminhos medidos antes da troca, nomeados; 2: motivo do gravador. */
					__( 'Nenhum dos caminhos publicados medidos antes da troca (%1$s) mudou de endereço: nenhum redirecionamento foi computado nesta etapa, e redirecionar um endereço para ele mesmo seria laço. A option foi gravada com a UNIÃO DECLARADA assim mesmo, que é o que preserva os pares declarados na configuração e os computados por execuções anteriores. %2$s', 'f3base' ),
					array() === $antigas ? __( 'nenhum', 'f3base' ) : implode( ', ', array_keys( $antigas ) ),
					$resultado['motivo']
				),
			);
		}

		return array(
			'nomeados' => $nomeados,
			'motivo'   => sprintf(
				/* translators: 1: pares computados, nomeados um a um; 2: motivo do gravador. */
				__( 'Estas URLs publicadas mudaram de endereço e o endereço ANTIGO de cada uma passa a responder pelo mecanismo de redirect DECLARADO do site-core — o par gravado em f3base_redirects é casado em template_redirect com prioridade 1, antes do 404, e sai 301 para o novo: %1$s. Cada par sai NOMEADO em vez de contado, porque a pergunta do operador é qual URL passou a responder, não quantas. O valor gravado é a UNIÃO DECLARADA (pares da configuração + computados desta execução + computados preservados), e não só estes pares: gravar só estes foi o que permitiu, na 1.0.11, que a etapa seguinte os apagasse. %2$s', 'f3base' ),
				$nomeados,
				$resultado['motivo']
			),
		);
	}

	/**
	 * Caminho publicado AGORA de uma referência lógica, nas duas formas dela.
	 *
	 * A referência de conteúdo gerenciado é a `ref` declarada, e ela é resolvida
	 * pela localização por meta de gestão — nunca por slug, que é a mesma regra
	 * que governa a adoção de objeto. A referência de conteúdo que este pacote
	 * NÃO gerencia é o ID prefixado: ele não tem `ref` para resolver, e o ID é a
	 * única identidade que o objeto tem no banco.
	 *
	 * Devolve vazio quando não há endereço novo, e é `pares_de_redirect()` que
	 * descarta o par: inventar destino é pior do que não redirecionar.
	 *
	 * @param string $ref Referência lógica.
	 * @return string Caminho publicado agora, ou vazio.
	 */
	private static function caminho_atual_da_referencia( string $ref ): string {
		if ( str_starts_with( $ref, self::REF_POR_ID ) ) {
			$id = (int) substr( $ref, strlen( self::REF_POR_ID ) );

			return $id > 0 ? (string) wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH ) : '';
		}

		$id = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );
		$id = $id > 0 ? $id : F3Base_Imp_Conteudo::localizar_gerenciado( 'post', $ref );

		return $id > 0 ? (string) wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH ) : '';
	}

	/**
	 * Registra pares computados por uma ETAPA desta execução.
	 *
	 * Acumulador de fonte, não de valor: quem grava continua sendo o gravador
	 * único, e o valor desejado continua saindo de um lugar só —
	 * `valor_desejado_de_redirects()`.
	 *
	 * @param array<int,array{de:string,para:string,status:int}> $pares Pares computados.
	 * @param string                                             $etapa Etapa que os computou, para o carimbo de origem.
	 * @return void
	 */
	public static function registrar_redirects_computados( array $pares, string $etapa ): void {
		foreach ( $pares as $par ) {
			$de = isset( $par['de'] ) ? (string) $par['de'] : '';

			if ( '' === $de ) {
				continue;
			}

			self::$redirects_computados[ $de ] = array(
				'de'     => $de,
				'para'   => isset( $par['para'] ) ? (string) $par['para'] : '',
				'status' => isset( $par['status'] ) ? (int) $par['status'] : 301,
				'origem' => self::REDIRECT_COMPUTADO . ':' . $etapa,
			);
		}
	}

	/**
	 * Pares computados por etapas DESTA execução.
	 *
	 * @return array<int,array{de:string,para:string,status:int,origem:string}>
	 */
	public static function redirects_computados(): array {
		return array_values( self::$redirects_computados );
	}

	/**
	 * Esquece os pares computados desta execução.
	 *
	 * Existe para o exercício da regra fora de uma execução real: sem isto, dois
	 * casos seguidos na mesma sonda mediriam o acúmulo do caso anterior.
	 *
	 * @return void
	 */
	public static function esquecer_redirects_computados(): void {
		self::$redirects_computados = array();
	}

	/**
	 * Redirects DECLARADOS no arquivo de configuração, normalizados.
	 *
	 * Uma das fontes de `f3base_redirects` — nunca a option inteira.
	 *
	 * @return array<int,array{de:string,para:string,status:int,origem:string}>
	 */
	private static function redirects_declarados(): array {
		$saida = array();

		foreach ( F3Base_Imp_Config::lista( 'redirects' ) as $indice => $entrada ) {
			unset( $entrada );

			$de   = (string) F3Base_Imp_Config::obter( 'redirects.' . $indice . '.de', '' );
			$para = (string) F3Base_Imp_Config::obter( 'redirects.' . $indice . '.para', '' );

			if ( '' === $de || '' === $para ) {
				continue;
			}

			$saida[] = array(
				'de'     => $de,
				'para'   => $para,
				'status' => (int) F3Base_Imp_Config::obter( 'redirects.' . $indice . '.status', 301 ),
				'origem' => self::REDIRECT_DECLARADO,
			);
		}

		return $saida;
	}

	/**
	 * A UNIÃO DECLARADA de `f3base_redirects`. FUNÇÃO PURA.
	 *
	 * Três fontes e uma ORDEM declarada, unidas por chave de origem (`de`):
	 *
	 * 1. **Declarados** — `redirects` no arquivo de configuração. Rederivados a
	 *    cada execução: tirar da configuração tira da option.
	 * 2. **Computados nesta execução** — o que as etapas mediram agora.
	 * 3. **Preservados** — o que já estava gravado e NÃO tem origem
	 *    `declarado`: pares computados por execuções anteriores (a URL antiga
	 *    que eles redirecionam continua circulando) e pares sem carimbo, que
	 *    este pacote não escreveu e não vai apagar em silêncio.
	 *
	 * Nenhum lado apaga o outro. O par computado AGORA vence o preservado com a
	 * mesma origem porque é a mesma medição, refeita — não é colisão. Colisão
	 * de origem entre um par DECLARADO e um COMPUTADO é outra coisa: são duas
	 * afirmações diferentes sobre o mesmo endereço, e isso é FALHA nomeando as
	 * duas, nunca sobrescrita silenciosa. O declarado prevalece no valor
	 * gravado — a configuração é a afirmação explícita do operador — e a
	 * colisão sai nomeada com os dois destinos, para que ele decida.
	 *
	 * @param array<int,array<string,mixed>> $declarados Pares da configuração.
	 * @param array<int,array<string,mixed>> $computados Pares computados nesta execução.
	 * @param array<int,array<string,mixed>> $gravados   Pares já gravados na option.
	 * @return array{pares:array<int,array{de:string,para:string,status:int,origem:string}>,colisoes:array<int,array{de:string,declarado:string,computado:string}>,contagem:array<string,int>}
	 */
	public static function uniao_de_redirects( array $declarados, array $computados, array $gravados ): array {
		$normalizar = static function ( $par, string $origem_padrao ): array {
			$par = is_array( $par ) ? $par : array();
			$de  = isset( $par['de'] ) ? (string) $par['de'] : '';

			return array(
				'de'     => $de,
				'para'   => isset( $par['para'] ) ? (string) $par['para'] : '',
				'status' => isset( $par['status'] ) ? (int) $par['status'] : 301,
				'origem' => isset( $par['origem'] ) && '' !== (string) $par['origem'] ? (string) $par['origem'] : $origem_padrao,
			);
		};

		$pares    = array();
		$colisoes = array();
		$contagem = array(
			self::REDIRECT_DECLARADO    => 0,
			self::REDIRECT_COMPUTADO    => 0,
			self::REDIRECT_PREEXISTENTE => 0,
		);

		foreach ( $declarados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_DECLARADO );

			if ( '' === $par['de'] || '' === $par['para'] ) {
				continue;
			}

			$par['origem']       = self::REDIRECT_DECLARADO;
			$pares[ $par['de'] ] = $par;

			$contagem[ self::REDIRECT_DECLARADO ]++;
		}

		foreach ( $computados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_COMPUTADO );

			if ( '' === $par['de'] || '' === $par['para'] ) {
				continue;
			}

			if ( isset( $pares[ $par['de'] ] ) && self::REDIRECT_DECLARADO === $pares[ $par['de'] ]['origem'] ) {
				$colisoes[] = array(
					'de'        => $par['de'],
					'declarado' => $pares[ $par['de'] ]['para'],
					'computado' => $par['para'],
				);
				continue;
			}

			$pares[ $par['de'] ] = $par;
			$contagem[ self::REDIRECT_COMPUTADO ]++;
		}

		foreach ( $gravados as $bruto ) {
			$par = $normalizar( $bruto, self::REDIRECT_PREEXISTENTE );

			if ( '' === $par['de'] || '' === $par['para'] ) {
				continue;
			}

			/*
			 * Par gravado com origem `declarado` NÃO é preservado: a fonte dele
			 * é o arquivo de configuração, e o laço acima já o rederivou de lá.
			 * Preservá-lo faria um par removido da configuração viver para
			 * sempre na option, que é o defeito espelhado do que esta release
			 * corrige.
			 */
			if ( self::REDIRECT_DECLARADO === $par['origem'] ) {
				continue;
			}

			if ( isset( $pares[ $par['de'] ] ) ) {
				if ( self::REDIRECT_DECLARADO === $pares[ $par['de'] ]['origem'] ) {
					$colisoes[] = array(
						'de'        => $par['de'],
						'declarado' => $pares[ $par['de'] ]['para'],
						'computado' => $par['para'],
					);
				}

				continue;
			}

			if ( ! str_starts_with( $par['origem'], self::REDIRECT_COMPUTADO ) ) {
				$par['origem'] = self::REDIRECT_PREEXISTENTE;
			}

			$pares[ $par['de'] ] = $par;
			$contagem[ self::REDIRECT_PREEXISTENTE ]++;
		}

		return array(
			'pares'    => array_values( $pares ),
			'colisoes' => $colisoes,
			'contagem' => $contagem,
		);
	}

	/**
	 * O valor desejado de `f3base_redirects` — PONTO ÚNICO que o produz.
	 *
	 * Toda gravação da option passa por aqui, e é isso que
	 * `estatica.option_fonte_unica` confere: enquanto houve duas funções
	 * montando o valor por caminhos diferentes, a segunda a rodar apagava o
	 * trabalho da primeira e o relatório saía com duas afirmações verdadeiras e
	 * contraditórias sobre o mesmo artefato.
	 *
	 * @return array<int,array{de:string,para:string,status:int,origem:string}>
	 */
	public static function valor_desejado_de_redirects(): array {
		return self::uniao_de_redirects_medida()['pares'];
	}

	/**
	 * A união, com as três fontes LIDAS: configuração, execução e artefato.
	 *
	 * @return array{pares:array<int,array<string,mixed>>,colisoes:array<int,array<string,string>>,contagem:array<string,int>}
	 */
	public static function uniao_de_redirects_medida(): array {
		$gravados = get_option( 'f3base_redirects', array() );

		return self::uniao_de_redirects(
			self::redirects_declarados(),
			self::redirects_computados(),
			is_array( $gravados ) ? $gravados : array()
		);
	}

	/**
	 * O texto da união, nos dois ramos. FUNÇÃO PURA.
	 *
	 * @param array{pares:array<int,array<string,mixed>>,colisoes:array<int,array<string,string>>,contagem:array<string,int>} $uniao União medida.
	 * @return array{estado:string,motivo:string}
	 */
	public static function veredito_da_uniao_de_redirects( array $uniao ): array {
		$contagem = (array) ( $uniao['contagem'] ?? array() );
		$colisoes = (array) ( $uniao['colisoes'] ?? array() );

		$resumo = sprintf(
			/* translators: 1: declarados, 2: computados, 3: preservados, 4: total. */
			__( 'fonte COMPOSTA e ordem declarada: %1$d par(es) declarado(s) na configuração + %2$d computado(s) por etapas desta execução + %3$d preservado(s) do que já estava gravado = %4$d par(es) unidos por chave de origem.', 'f3base' ),
			(int) ( $contagem[ self::REDIRECT_DECLARADO ] ?? 0 ),
			(int) ( $contagem[ self::REDIRECT_COMPUTADO ] ?? 0 ),
			(int) ( $contagem[ self::REDIRECT_PREEXISTENTE ] ?? 0 ),
			count( (array) ( $uniao['pares'] ?? array() ) )
		);

		if ( array() === $colisoes ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: %s: resumo da união. */
					__( 'f3base_redirects tem %s Nenhuma colisão de origem: nenhum lado apagou o outro, e o valor gravado é o mesmo em toda etapa que toca a option.', 'f3base' ),
					$resumo
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::FALHA,
			'motivo' => sprintf(
				/* translators: 1: quantidade de colisões, 2: colisões nomeadas, 3: resumo da união. */
				__( 'COLISÃO DE ORIGEM em f3base_redirects: %1$d endereço(s) de origem têm um par DECLARADO na configuração e um par COMPUTADO por esta execução apontando para destinos diferentes — %2$s. Nenhuma sobrescrita silenciosa: o par declarado prevaleceu no valor gravado, e a divergência sai nomeada para que o operador decida qual das duas afirmações vale. %3$s', 'f3base' ),
				count( $colisoes ),
				implode(
					'; ',
					array_map(
						static fn( array $c ): string => sprintf(
							/* translators: 1: origem, 2: destino declarado, 3: destino computado. */
							__( '%1$s → declarado %2$s, computado %3$s', 'f3base' ),
							(string) ( $c['de'] ?? '' ),
							(string) ( $c['declarado'] ?? '' ),
							(string) ( $c['computado'] ?? '' )
						),
						$colisoes
					)
				),
				$resumo
			),
		);
	}

	/**
	 * Indexação: `blog_public`, com o ÔNUS INVERTIDO.
	 *
	 * Até a 1.0.11 esta unidade gravava `blog_public = 1` só quando TRÊS
	 * condições fechavam — `ambiente.tipo = producao`, HTTPS e o host dentro de
	 * `ambiente.dominios_autorizados` — e o template nascia com `tipo = local` e
	 * a lista vazia. O padrão, portanto, era NÃO INDEXAR, e era preciso
	 * configurar três coisas para obter o resultado normal de um site.
	 *
	 * A decisão do dono inverteu isso: o implantador existe para entregar um
	 * site pronto para produção e para ser indexado, e o padrão precisa JÁ SER
	 * esse resultado. Quem não quiser, muda a chave à mão.
	 *
	 * Então o site NASCE INDEXÁVEL e a unidade só segura a indexação quando
	 * MEDE um motivo. As guardas que sobraram são as que não podem dar falso
	 * positivo num site real, e a lista de domínios autorizados saiu do gate:
	 * ela continua existindo, como CROSS-CHECK, e uma lista vazia não é achado.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_indexacao(): array {
		$veredito = self::indexacao_medida();
		$esperado = $veredito['valor'];

		$resultado = F3Base_Imp_Gravador::gravar( 'blog_public', $esperado );
		$conferiu  = (int) get_option( 'blog_public', 0 ) === $esperado || F3Base_Imp_Gravador::em_simulacao();

		/*
		 * TRÊS RAMOS, UMA EMISSÃO. Guarda que dispara é decisão MEDIDA e
		 * correta — WARN, nunca FALHA nem BLOCKED. O que é FALHA é a leitura de
		 * volta divergir do que se pediu: aí a escrita não pegou, e isso é
		 * defeito, não decisão.
		 */
		F3Base_Imp_Relatorio::emitir(
			$conferiu ? $veredito['estado'] : F3Base_Imp_Relatorio::FALHA,
			'wordpress.blog_public',
			$conferiu
				? sprintf(
					/* translators: 1: valor gravado, 2: motivo do veredito, 3: consequência no wp-admin. */
					__( 'blog_public = %1$d. %2$s %3$s', 'f3base' ),
					$esperado,
					$veredito['motivo'],
					$veredito['consequencia']
				)
				: sprintf(
					/* translators: 1: valor esperado, 2: valor observado, 3: motivo do veredito, 4: consequência no wp-admin. */
					__( 'blog_public deveria ser %1$d e a leitura de volta trouxe %2$d: a escrita não pegou, e isto é defeito, não decisão. %3$s %4$s', 'f3base' ),
					$esperado,
					(int) get_option( 'blog_public', 0 ),
					$veredito['motivo'],
					$veredito['consequencia']
				),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		/*
		 * O CROSS-CHECK SAI EM LINHA PRÓPRIA, e não dentro do veredito: ele não
		 * decide a indexação, e misturá-lo com quem decide foi o que fez a
		 * lista de domínios virar gate na 1.0.11.
		 */
		F3Base_Imp_Relatorio::emitir(
			$veredito['cross_check']['estado'],
			'ambiente.dominios_autorizados',
			$veredito['cross_check']['motivo'],
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		return array(
			'estado' => F3Base_Imp_Relatorio::estado_mais_severo( $resultado['estado'], $veredito['estado'] ),
			'rotulo' => 'wordpress.indexacao',
			'motivo' => sprintf(
				/* translators: 1: motivo do veredito, 2: consequência no wp-admin, 3: mensagem do gravador. */
				__( '%1$s %2$s %3$s', 'f3base' ),
				$veredito['motivo'],
				$veredito['consequencia'],
				$resultado['motivo']
			),
		);
	}

	/**
	 * MEDE o ambiente e devolve o veredito da indexação.
	 *
	 * O lado impuro: lê a configuração, `home_url()` e
	 * `wp_get_environment_type()`. A REGRA fica em `veredito_de_indexacao()`,
	 * que é pura e por isso tem piso dos dois lados na sonda funcional.
	 *
	 * @return array<string,mixed>
	 */
	public static function indexacao_medida(): array {
		$home = (string) home_url();

		return self::veredito_de_indexacao(
			array(
				'modo'        => (string) F3Base_Imp_Config::obter( 'ambiente.indexar', self::INDEXAR_MEDIR ),
				'tipo'        => (string) F3Base_Imp_Config::obter( 'ambiente.tipo', 'producao' ),
				'esquema'     => (string) wp_parse_url( $home, PHP_URL_SCHEME ),
				'host'        => (string) wp_parse_url( $home, PHP_URL_HOST ),
				'ambiente_wp' => function_exists( 'wp_get_environment_type' ) ? (string) wp_get_environment_type() : '',
				'previa'      => array_map( 'strval', F3Base_Imp_Config::lista( 'ambiente.dominios_de_previa' ) ),
				'autorizados' => array_map( 'strval', F3Base_Imp_Config::lista( 'ambiente.dominios_autorizados' ) ),
			)
		);
	}

	/**
	 * A REGRA da indexação, PURA: mede-se fora, decide-se aqui.
	 *
	 * O padrão é indexar. As três guardas de `medir` existem porque cada uma,
	 * sozinha, é impossível de disparar num site de produção legítimo:
	 *
	 * 1. `wp_get_environment_type()` em `local`, `development` ou `staging`. O
	 *    padrão do núcleo é `production`; um destes três só aparece quando
	 *    alguém — hospedagem, `wp-config.php`, variável de ambiente — DECLAROU
	 *    que aquele ambiente não é produção.
	 * 2. `home_url()` fora de HTTPS. Site indexável em HTTP puro é defeito, não
	 *    escolha.
	 * 3. `ambiente.tipo` declarado diferente de `producao`. A chave continua
	 *    respeitada quando o projeto a muda de propósito.
	 *
	 * E a quarta, que só existe quando o dono a declara: host casando com um
	 * sufixo de `ambiente.dominios_de_previa`. Ela nasce VAZIA e não pode
	 * nascer preenchida — a lista de sufixos de pré-visualização de cada
	 * hospedagem é fato do mundo, muda sem release nossa, e embutida no código
	 * seria uma guarda invisível decidindo sobre o site de alguém.
	 *
	 * @param array<string,mixed> $medido O que foi medido no ambiente.
	 * @return array{valor:int,estado:string,modo:string,guardas:array<int,array{nome:string,observado:string}>,cross_check:array{estado:string,motivo:string},motivo:string,consequencia:string,detalhe:string}
	 */
	public static function veredito_de_indexacao( array $medido ): array {
		$modo        = (string) ( $medido['modo'] ?? self::INDEXAR_MEDIR );
		$tipo        = (string) ( $medido['tipo'] ?? '' );
		$esquema     = strtolower( (string) ( $medido['esquema'] ?? '' ) );
		$host        = strtolower( (string) ( $medido['host'] ?? '' ) );
		$ambiente_wp = strtolower( (string) ( $medido['ambiente_wp'] ?? '' ) );
		$previa      = array_map( 'strval', (array) ( $medido['previa'] ?? array() ) );
		$autorizados = array_map( 'strval', (array) ( $medido['autorizados'] ?? array() ) );

		$modo    = in_array( $modo, array( self::INDEXAR_MEDIR, self::INDEXAR_FORCAR, self::INDEXAR_NUNCA ), true ) ? $modo : self::INDEXAR_MEDIR;
		$guardas = array();

		if ( in_array( $ambiente_wp, self::AMBIENTES_NAO_PRODUCAO, true ) ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_AMBIENTE_WP,
				'observado' => $ambiente_wp,
				'porque'    => __( 'o padrão do núcleo é "production": este valor só aparece quando a hospedagem, o wp-config.php ou uma variável de ambiente declararam explicitamente que este ambiente NÃO é produção', 'f3base' ),
			);
		}

		if ( 'https' !== $esquema ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_ESQUEMA,
				'observado' => '' !== $esquema ? $esquema : __( '(sem esquema)', 'f3base' ),
				'porque'    => __( 'site indexável servido em HTTP puro é defeito, não escolha: o endereço indexado é o que o buscador guarda', 'f3base' ),
			);
		}

		if ( 'producao' !== $tipo ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_TIPO,
				'observado' => '' !== $tipo ? $tipo : __( '(vazio)', 'f3base' ),
				'porque'    => __( 'a chave nasce "producao" e continua respeitada quando o projeto a muda de propósito: mudá-la é dizer que este não é o site de produção', 'f3base' ),
			);
		}

		$sufixo = self::sufixo_de_previa( $host, $previa );

		if ( '' !== $sufixo ) {
			$guardas[] = array(
				'nome'      => self::GUARDA_PREVIA,
				'observado' => $host . ' casa com o sufixo declarado ' . $sufixo,
				'porque'    => __( 'endereço de pré-visualização da hospedagem deixa de existir quando o domínio real aponta para o site, e o que foi indexado por ele fica órfão', 'f3base' ),
			);
		}

		$nomeadas = array_map(
			static fn( array $g ): string => sprintf(
				/* translators: 1: nome da guarda, 2: valor observado, 3: por que a guarda existe. */
				__( '%1$s (observado: %2$s — %3$s)', 'f3base' ),
				$g['nome'],
				$g['observado'],
				$g['porque']
			),
			$guardas
		);

		$como_forcar = __( 'Para indexar assim mesmo, sem tocar em nada do ambiente: declare ambiente.indexar = "forcar" — a decisão fica registrada no relatório junto com a guarda que ela ignorou.', 'f3base' );

		if ( self::INDEXAR_NUNCA === $modo ) {
			$veredito = array(
				'valor'  => 0,
				'estado' => F3Base_Imp_Relatorio::WARN,
				'motivo' => sprintf(
					/* translators: %s: guardas ativas, ou a frase de nenhuma. */
					__( 'DECISÃO DECLARADA em ambiente.indexar = "nunca": blog_public = 0 sempre, independentemente do que foi medido. Não é defeito e não é medição — é escolha do projeto, e sai em WARN porque um site não indexável é o oposto do estado normal deste pacote e o operador precisa ver por quê. Guarda(s) que estariam ativas de qualquer modo: %s. Para voltar ao padrão, declare ambiente.indexar = "medir".', 'f3base' ),
					array() === $nomeadas ? __( 'nenhuma', 'f3base' ) : implode( '; ', $nomeadas )
				),
			);
		} elseif ( self::INDEXAR_FORCAR === $modo ) {
			$veredito = array(
				'valor'  => 1,
				'estado' => array() === $guardas ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::WARN,
				'motivo' => array() === $guardas
					? __( 'DECISÃO DECLARADA em ambiente.indexar = "forcar": blog_public = 1. A decisão foi INERTE nesta execução — nenhuma guarda estava ativa, e o padrão "medir" teria gravado o mesmo 1. Registrada assim mesmo: decisão que ignora medição precisa aparecer no relatório mesmo quando não havia o que ignorar, senão ninguém percebe que ela continua ligada.', 'f3base' )
					: sprintf(
						/* translators: %s: guardas ignoradas, nomeadas com o valor observado. */
						__( 'DECISÃO DECLARADA em ambiente.indexar = "forcar": blog_public = 1 IGNORANDO a(s) guarda(s) que estavam ativas — e é este o motivo por que a decisão existia: %s. O site fica indexável apesar da medição acima; a medição não foi suprimida, só não decidiu. Para devolver a decisão à medição, declare ambiente.indexar = "medir".', 'f3base' ),
						implode( '; ', $nomeadas )
					),
			);
		} elseif ( array() === $guardas ) {
			$veredito = array(
				'valor'  => 1,
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => __( 'PADRÃO: o site nasce indexável e nenhuma guarda mediu motivo para segurá-lo — blog_public = 1 sem que nada precisasse ser configurado. As guardas medidas foram: wp_get_environment_type() fora de local/development/staging, home_url() em https, ambiente.tipo = "producao" e nenhum sufixo de ambiente.dominios_de_previa casando com o host.', 'f3base' ),
			);
		} else {
			$veredito = array(
				'valor'  => 0,
				'estado' => F3Base_Imp_Relatorio::WARN,
				'motivo' => sprintf(
					/* translators: 1: quantidade de guardas, 2: guardas nomeadas com o observado, 3: como forçar. */
					__( 'blog_public = 0 por %1$d guarda(s) MEDIDA(s), e isto é decisão correta, não defeito: %2$s. O padrão continua sendo indexar — nenhuma configuração é exigida para isso —, e o que segurou aqui foi medição, não ausência de configuração. %3$s', 'f3base' ),
					count( $guardas ),
					implode( '; ', $nomeadas ),
					$como_forcar
				),
			);
		}

		return $veredito + array(
			'modo'         => $modo,
			'guardas'      => $guardas,
			'cross_check'  => self::cross_check_de_dominios( $host, $autorizados ),
			'consequencia' => self::consequencia_de_indexacao( 1 === $veredito['valor'], $tipo, $host ),
			'detalhe'      => sprintf(
				/* translators: 1: modo declarado, 2: ambiente do núcleo, 3: esquema, 4: host, 5: quantidade de guardas ativas. */
				__( 'medido: ambiente.indexar = %1$s; wp_get_environment_type() = %2$s; esquema de home_url() = %3$s; host = %4$s; guardas ativas = %5$d.', 'f3base' ),
				$modo,
				'' !== $ambiente_wp ? $ambiente_wp : '—',
				'' !== $esquema ? $esquema : '—',
				'' !== $host ? $host : '—',
				count( $guardas )
			),
		);
	}

	/**
	 * O sufixo de pré-visualização que casa com o host, ou vazio. FUNÇÃO PURA.
	 *
	 * Casa o host inteiro (`exemplo.wpengine.com` contra `wpengine.com`) e o
	 * host igual ao sufixo. Aceita o sufixo declarado com `*.` ou com ponto na
	 * frente, porque é assim que essas listas costumam ser escritas — e um
	 * casamento por `str_contains()` pegaria `wpengine.com.br`, que é outro
	 * domínio e outro dono.
	 *
	 * @param string            $host    Host medido, minúsculo.
	 * @param array<int,string> $sufixos Sufixos declarados.
	 * @return string Sufixo normalizado que casou, ou vazio.
	 */
	public static function sufixo_de_previa( string $host, array $sufixos ): string {
		$host = strtolower( trim( $host ) );

		if ( '' === $host ) {
			return '';
		}

		foreach ( $sufixos as $sufixo ) {
			$limpo = strtolower( ltrim( trim( (string) $sufixo ), '*.' ) );

			if ( '' === $limpo ) {
				continue;
			}

			if ( $host === $limpo || str_ends_with( $host, '.' . $limpo ) ) {
				return $limpo;
			}
		}

		return '';
	}

	/**
	 * O CROSS-CHECK dos domínios autorizados. FUNÇÃO PURA.
	 *
	 * Era a terceira condição de `blog_public` até a 1.0.11, e com a lista
	 * vazia no template isso significava um site que não indexa por padrão. Não
	 * decide mais nada: preenchida, host fora dela sai em WARN nomeando o host
	 * OBSERVADO e a lista DECLARADA — divergência entre o endereço que se
	 * esperava servir e o que se está servindo é diagnóstico útil. Vazia, N/A
	 * com a condição declarada: lista vazia NÃO é achado.
	 *
	 * @param string            $host        Host medido.
	 * @param array<int,string> $autorizados Lista declarada.
	 * @return array{estado:string,motivo:string}
	 */
	public static function cross_check_de_dominios( string $host, array $autorizados ): array {
		$declarados = array_values( array_filter( array_map( static fn( $d ): string => strtolower( trim( (string) $d ) ), $autorizados ) ) );
		$host       = strtolower( trim( $host ) );

		if ( array() === $declarados ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'motivo' => __( 'condição de aplicabilidade falsa: ambiente.dominios_autorizados está vazia, que é o padrão do template. Lista vazia NÃO é achado e NÃO segura a indexação — ela deixou de ser condição de blog_public nesta release e virou cross-check: quem a preenche ganha o aviso de estar servindo de um host diferente do declarado, quem não preenche não perde nada.', 'f3base' ),
			);
		}

		if ( in_array( $host, $declarados, true ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: 1: host observado, 2: lista declarada. */
					__( 'cross-check: o host observado em home_url() (%1$s) consta da lista declarada em ambiente.dominios_autorizados (%2$s).', 'f3base' ),
					$host,
					implode( ', ', $declarados )
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::WARN,
			'motivo' => sprintf(
				/* translators: 1: host observado, 2: lista declarada. */
				__( 'cross-check: o host observado em home_url() é %1$s e NÃO consta da lista declarada em ambiente.dominios_autorizados (%2$s). Isto NÃO impede a indexação — a lista deixou de ser condição de blog_public nesta release —, e é diagnóstico: ou o site está sendo servido de um endereço que ninguém declarou, ou a lista ficou para trás. Nada aqui substitui home_url() na composição de URLs.', 'f3base' ),
				'' !== $host ? $host : '—',
				implode( ', ', $declarados )
			),
		);
	}

	/**
	 * A CONSEQUÊNCIA de `blog_public`, dita junto com a causa.
	 *
	 * O caso medido na 1.0.9: com as condições fechando falso, a unidade gravou
	 * `blog_public = 0` — o certo naquele momento — e o log disse que gravou. O
	 * que ele NÃO disse é que essa gravação faz o WordPress estampar no wp-admin
	 * "Problema grave de SEO: Você está bloqueando o acesso dos robôs". O
	 * operador ficou com um alarme vermelho no painel e um relatório que fechava
	 * OK, sem nada ligando os dois.
	 *
	 * O aviso do WordPress está CERTO e não é suprimido: esconder alarme
	 * verdadeiro é pior que explicá-lo. O que faltava era o relatório nomear a
	 * consequência e o caminho de saída. Na 1.0.12 esse caminho MUDOU, e a
	 * mensagem muda com ele: não se pede mais para declarar `producao` nem para
	 * preencher a lista de domínios — o padrão já é indexar, e o que resta é
	 * corrigir a guarda que disparou ou declarar `ambiente.indexar = "forcar"`.
	 *
	 * Pura por desenho: recebe o que foi medido e devolve texto, para ter piso
	 * dos dois lados na sonda funcional.
	 *
	 * @param bool   $indexavel O valor gravado foi 1.
	 * @param string $tipo      Ambiente declarado em `ambiente.tipo`.
	 * @param string $host      Host de `home_url()`.
	 * @return string
	 */
	public static function consequencia_de_indexacao( bool $indexavel, string $tipo, string $host ): string {
		if ( $indexavel ) {
			return __( 'Consequência: com blog_public = 1 o site é indexável e o wp-admin NÃO exibe o aviso de SEO sobre bloqueio de robôs — se ele aparecer, a causa está fora deste pacote.', 'f3base' );
		}

		return sprintf(
			/* translators: 1: ambiente declarado, 2: host de home_url(). */
			__( 'Consequência ESPERADA, e é ela que o operador está vendo: com blog_public = 0 o WordPress exibe no wp-admin o aviso "Problema grave de SEO: Você está bloqueando o acesso dos robôs". Esse aviso está CERTO e não é suprimido por este pacote — esconder alarme verdadeiro é pior que explicá-lo —, e ele permanece enquanto a guarda nomeada acima continuar valendo. O caminho de saída NÃO é mais configurar três chaves para chegar ao normal: o padrão desta release já é indexar. Ou some a causa medida (o ambiente declarado do WordPress, o https de home_url(), ambiente.tipo = "producao" — está "%1$s" —, ou o host %2$s deixar de casar com ambiente.dominios_de_previa), ou se declara ambiente.indexar = "forcar", que grava 1 e deixa a decisão registrada.', 'f3base' ),
			'' !== $tipo ? $tipo : '—',
			'' !== $host ? $host : '—'
		);
	}

	/**
	 * O CONTROLADOR está identificado no conteúdo SERVIDO da política?
	 *
	 * A leitura de volta é do artefato — `post_content` do objeto no banco —, e
	 * não do arquivo do pacote nem da configuração: a pergunta é o que o
	 * visitante lê, e uma checagem que confere o arquivo de entrada responderia
	 * outra pergunta com a mesma cara.
	 *
	 * @param string $ref_politica Referência lógica declarada da política.
	 * @param int    $id           ID da página aplicada, ou 0.
	 * @return void
	 */
	private static function emitir_controlador_identificado( string $ref_politica, int $id ): void {
		$veredito = F3Base_Imp_Conteudo::veredito_da_checagem_do_controlador(
			$ref_politica,
			$id,
			F3Base_Imp_Conteudo::controlador_medido(),
			$id > 0 ? (string) get_post_field( 'post_content', $id ) : ''
		);

		F3Base_Imp_Relatorio::emitir(
			$veredito['estado'],
			'privacidade.controlador_identificado',
			$veredito['motivo'],
			array(
				'evidencia'   => $veredito['evidencia'],
				'fase'        => $veredito['fase'],
				/*
				 * PRÉ-CONDIÇÃO DECLARADA: razão social, documento e endereço são
				 * dado que só o operador tem. O gate desta linha NÃO muda — ela
				 * continua promovendo a unidade como sempre promoveu; o metadado
				 * só a faz entrar no terceiro eixo, que até a 1.0.17 não existia
				 * e deixava o resultado sair otimista no nome com a política em
				 * rascunho.
				 */
				'precondicao' => true,
			)
		);
	}

	/**
	 * Página inicial, página de posts e política de privacidade.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_paginas_especiais(): array {
		$partes = array();
		$falhou = false;

		$home = 0;
		$blog = 0;

		/*
		 * QUAL página é a política sai da CONFIGURAÇÃO, de um lugar só. O
		 * literal `'privacidade'` espalhado por duas etapas era lista fechada
		 * decidindo o que a configuração declara.
		 */
		$ref_politica = F3Base_Imp_Conteudo::ref_da_politica_de_privacidade();
		$id_politica  = 0;

		foreach ( F3Base_Imp_Config::lista( 'paginas' ) as $indice => $entrada ) {
			unset( $entrada );

			$ref      = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.ref', '' );
			$template = (string) F3Base_Imp_Config::obter( 'paginas.' . $indice . '.template', '' );
			$id       = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

			if ( 'front-page' === $template && $id > 0 ) {
				$home = $id;
			}

			if ( F3Base_Imp_Conteudo::grava_pagina_de_privacidade( $ref_politica, $ref, $id ) ) {
				$id_politica = $id;
				$resultado   = F3Base_Imp_Gravador::gravar( 'wp_page_for_privacy_policy', $id );
				$partes[]    = 'wp_page_for_privacy_policy: ' . $resultado['motivo'];
				$falhou      = $falhou || F3Base_Imp_Relatorio::FALHA === $resultado['estado'];
			}
		}

		self::emitir_controlador_identificado( $ref_politica, $id_politica );

		if ( $home > 0 ) {
			$resultado = F3Base_Imp_Gravador::gravar( 'show_on_front', 'page' );
			$partes[]  = 'show_on_front: ' . $resultado['motivo'];
			$resultado = F3Base_Imp_Gravador::gravar( 'page_on_front', $home );
			$partes[]  = 'page_on_front: ' . $resultado['motivo'];
			$falhou    = $falhou || F3Base_Imp_Relatorio::FALHA === $resultado['estado'];
		} else {
			$partes[] = __( 'nenhuma página com template front-page gerenciada: página inicial não alterada.', 'f3base' );
		}

		$quer_blog = false;

		foreach ( F3Base_Imp_Config::lista( 'navegacao.itens' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( 'posts-page' === (string) F3Base_Imp_Config::obter( 'navegacao.itens.' . $indice . '.tipo', '' ) ) {
				$quer_blog = true;
				break;
			}
		}

		if ( $quer_blog ) {
			$blog = self::garantir_pagina_de_posts();

			if ( $blog > 0 ) {
				$resultado = F3Base_Imp_Gravador::gravar( 'page_for_posts', $blog );
				$partes[]  = 'page_for_posts: ' . $resultado['motivo'];
				$falhou    = $falhou || F3Base_Imp_Relatorio::FALHA === $resultado['estado'];
			} else {
				$partes[] = __( 'página de posts não pôde ser garantida.', 'f3base' );
				$falhou   = ! F3Base_Imp_Gravador::em_simulacao();
			}
		} else {
			$partes[] = __( 'nenhum item de menu do tipo posts-page declarado: página de posts fora do escopo.', 'f3base' );
		}

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : ( F3Base_Imp_Gravador::em_simulacao() ? F3Base_Imp_Relatorio::NA : F3Base_Imp_Relatorio::OK ),
			'rotulo' => 'wordpress.paginas_especiais',
			'motivo' => implode( ' | ', $partes ),
		);
	}

	/**
	 * Garante a página que hospeda o índice do blog.
	 *
	 * @return int ID, ou 0.
	 */
	private static function garantir_pagina_de_posts(): int {
		$ref = 'blog';
		$id  = F3Base_Imp_Conteudo::localizar_gerenciado( 'page', $ref );

		if ( $id > 0 ) {
			return $id;
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return 0;
		}

		$rotulo = __( 'Blog', 'f3base' );

		foreach ( F3Base_Imp_Config::lista( 'navegacao.itens' ) as $indice => $entrada ) {
			unset( $entrada );

			if ( 'posts-page' === (string) F3Base_Imp_Config::obter( 'navegacao.itens.' . $indice . '.tipo', '' ) ) {
				$rotulo = (string) F3Base_Imp_Config::obter( 'navegacao.itens.' . $indice . '.rotulo', $rotulo );
				break;
			}
		}

		/*
		 * A página de posts é uma PÁGINA GERENCIADA como qualquer outra, e o
		 * status dela sai do mesmo produtor: um literal aqui seria o segundo
		 * lugar decidindo o que este pacote publica.
		 */
		$criado = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => 'page',
					'post_status'  => F3Base_Imp_Conteudo::status_efetivo_de_pagina( $ref, 'publish' )['status'],
					'post_title'   => $rotulo,
					'post_name'    => sanitize_title( $rotulo ),
					'post_content' => '',
					'meta_input'   => array(
						F3Base_Imp_Conteudo::META_ID     => F3Base_Imp_Conteudo::identidade( 'page', $ref ),
						F3Base_Imp_Conteudo::META_VERSAO => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
					),
				)
			),
			true
		);

		if ( is_wp_error( $criado ) ) {
			return 0;
		}

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_POST,
			'page:blog',
			null,
			array( 'id' => (int) $criado ),
			array(
				'acao' => 'post.excluir',
				'id'   => (int) $criado,
			)
		);

		return (int) $criado;
	}

	/**
	 * A ÂNCORA dos produtores de seleção de `llms.txt`, e do gate que os serve.
	 *
	 * Lida por `estatica.llms_so_pagina_publicada`, do PRÓPRIO PACOTE, pela
	 * mesma razão de `uniao_declarada()`.
	 *
	 * - `gate`: a função que responde "esta página está publicada?" medindo o
	 *   artefato. Uma só, para os dois consumidores.
	 * - as demais entradas são `option => função produtora`. **São DUAS**, e a
	 *   segunda é a correção da 1.0.14: a 1.0.13 gateou `f3base_llms` e deixou
	 *   `wpseo_llmstxt` gravar o ID da política sem gate nenhum. O detector
	 *   prometia mais do que media enquanto olhava um produtor só.
	 *
	 * @return array<string,string>
	 */
	public static function produtor_de_item_llms(): array {
		return array(
			'gate'          => 'id_de_pagina_publicada',
			'f3base_llms'   => 'item_llms_de_pagina',
			'wpseo_llmstxt' => 'id_llms_de_pagina',
		);
	}

	/**
	 * O item de uma página no `llms.txt` do site-core — PONTO ÚNICO.
	 *
	 * O DEFEITO MEDIDO NA 1.0.12. O item da política de privacidade era montado
	 * de `localizar_gerenciado()` sem CONFERIR O STATUS: com a página em
	 * rascunho, `get_permalink()` devolvia um endereço que só responde a quem
	 * está logado e com permissão, e o `llms.txt` — que é público — publicava o
	 * permalink de um rascunho como se fosse a política vigente do site.
	 *
	 * @param string $ref Referência lógica da página.
	 * @return array<string,string> Item, ou vazio quando não há página publicada.
	 */
	public static function item_llms_de_pagina( string $ref ): array {
		$medido = F3Base_Imp_Conteudo::id_de_pagina_publicada( $ref );

		if ( $medido['id'] <= 0 ) {
			return array();
		}

		return array(
			'titulo'    => (string) get_the_title( $medido['id'] ),
			'url'       => (string) get_permalink( $medido['id'] ),
			'descricao' => (string) get_post_field( 'post_excerpt', $medido['id'] ),
		);
	}

	/**
	 * Options do `site-core`, todas pelo gravador único.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_options_site_core(): array {
		$paginas_llms = array();

		foreach ( F3Base_Imp_Config::lista( 'seo.llms_selecao.livres' ) as $ref ) {
			$item = self::item_llms_de_pagina( (string) $ref );

			if ( array() !== $item ) {
				$paginas_llms[] = $item;
			}
		}

		/*
		 * A SELEÇÃO REFERENCIA O PRODUTOR. A chave decide se a política ENTRA na
		 * seleção; QUAL página é a política sai do produtor único, que lê o
		 * papel declarado na entrada da página. Desligar esta chave tira a
		 * política do llms.txt e não toca em mais nada.
		 */
		$privacidade = (bool) F3Base_Imp_Config::obter( 'seo.llms_selecao.incluir_politica_privacidade', true )
			? self::item_llms_de_pagina( F3Base_Imp_Conteudo::ref_da_politica_de_privacidade() )
			: array();

		$valores = array(
			'f3base_contato'             => array(
				'whatsapp_e164'   => (string) F3Base_Imp_Config::obter( 'contato.whatsapp_e164', '' ),
				'email_leads'     => (string) F3Base_Imp_Config::obter( 'contato.email_leads', '' ),
				'mensagem_padrao' => '',
			),
			'f3base_consentimento'       => array(
				'padrao'                => (string) F3Base_Imp_Config::obter( 'consentimento.padrao', 'pre-aprovado' ),
				'controle_rodape'       => (bool) F3Base_Imp_Config::obter( 'consentimento.controle_rodape', true ),
				'aviso_primeira_visita' => (bool) F3Base_Imp_Config::obter( 'consentimento.aviso_primeira_visita', false ),
				'ttl_dias'              => (int) F3Base_Imp_Config::obter( 'consentimento.ttl_dias', 180 ),
			),
			'f3base_atribuicao'          => array(
				'modelo'   => (string) F3Base_Imp_Config::obter( 'atribuicao.modelo', 'first-touch' ),
				'ttl_dias' => (int) F3Base_Imp_Config::obter( 'atribuicao.ttl_dias', 30 ),
			),
			'f3base_retencao_meses'      => (int) F3Base_Imp_Config::obter( 'retencao.leads_meses', 12 ),
			'f3base_linkedin_partner_id' => (string) F3Base_Imp_Config::obter( 'tracking.linkedin_partner_id', '' ),
			'f3base_tracking'            => array(
				'eventos_ga4' => (bool) F3Base_Imp_Config::obter( 'tracking.eventos_ga4', true ),
			),
			'f3base_llms'                => array(
				'ligado'               => (bool) F3Base_Imp_Config::obter( 'bots_ia.llms_txt', false ),
				'introducao'           => '',
				'politica_privacidade' => $privacidade,
				'livres'               => $paginas_llms,
			),
			'f3base_redirects'           => self::valor_desejado_de_redirects(),
			'f3base_seo_entidade'        => array(
				'nome'             => (string) F3Base_Imp_Config::obter( 'seo.organizacao.nome', '' ),
				'same_as'          => array_map( 'strval', F3Base_Imp_Config::lista( 'seo.organizacao.same_as' ) ),
				'area_servida'     => array(),
				'conhece_sobre'    => array(),
				'ponto_de_contato' => array(),
				'organizacao_mae'  => '',
				'servicos'         => array(),
				'faq_schema'       => false,
			),
			'f3base_cabecalhos'          => array(
				'x_content_type_options' => (bool) F3Base_Imp_Config::obter( 'cabecalhos.x_content_type_options', true ),
				'x_frame_options'        => (string) F3Base_Imp_Config::obter( 'cabecalhos.x_frame_options', 'SAMEORIGIN' ),
				'csp_frame_ancestors'    => (string) F3Base_Imp_Config::obter( 'cabecalhos.csp_frame_ancestors', "'self'" ),
				'referrer_policy'        => (string) F3Base_Imp_Config::obter( 'cabecalhos.referrer_policy', 'strict-origin-when-cross-origin' ),
				'coop'                   => (string) F3Base_Imp_Config::obter( 'cabecalhos.coop', 'same-origin-allow-popups' ),
				'permissions_policy'     => (string) F3Base_Imp_Config::obter( 'cabecalhos.permissions_policy', '' ),
				'hsts'                   => (bool) F3Base_Imp_Config::obter( 'cabecalhos.hsts', false ),
				'hsts_max_age'           => (int) F3Base_Imp_Config::obter( 'cabecalhos.hsts_max_age', 300 ),
			),
			/*
			 * A ORIGEM CONFIÁVEL É DECLARADA, NUNCA INFERIDA. Vazia por padrão:
			 * enquanto ninguém declarar o cabeçalho, o rate limit do endpoint de
			 * leads conta por REMOTE_ADDR — atrás de CDN isso junta todo mundo
			 * num balde só, e é um preço declarado; aceitar cabeçalho de proxy
			 * sem declaração seria deixar o visitante escolher o próprio balde.
			 */
			'f3base_origem_confiavel'    => array(
				'cabecalho' => (string) F3Base_Imp_Config::obter( 'cabecalhos.origem_confiavel.cabecalho', '' ),
				'saltos'    => (int) F3Base_Imp_Config::obter( 'cabecalhos.origem_confiavel.saltos', 1 ),
			),
			'f3base_copy_contrato'       => array(
				'devem_aparecer'   => self::copy_grupo( 'copy_contrato.devem_aparecer' ),
				'nao_podem_voltar' => self::copy_grupo( 'copy_contrato.nao_podem_voltar' ),
			),
		);

		$partes = array();
		$falhou = false;

		foreach ( $valores as $option => $valor ) {
			$resultado = F3Base_Imp_Gravador::gravar( $option, $valor, array( 'plugin' => (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' ) ) );
			$partes[]  = $option . ': ' . $resultado['motivo'];
			$falhou    = $falhou || in_array( $resultado['estado'], array( F3Base_Imp_Relatorio::FALHA, F3Base_Imp_Relatorio::BLOCKED ), true );
		}

		/*
		 * A UNIÃO DE `f3base_redirects` SAI EM LINHA PRÓPRIA. Foi esta option
		 * que, na 1.0.11, teve duas fontes de valor desejado e um relatório com
		 * duas afirmações verdadeiras e contraditórias sobre o mesmo artefato:
		 * a etapa de permalinks gravou dois pares e disse a verdade, e esta
		 * etapa gravou `redirects: []` por cima e também disse a verdade. A
		 * linha existe para que a composição do valor seja LIDA, e não inferida
		 * de duas mensagens em pontos distantes do log.
		 */
		$uniao   = self::veredito_da_uniao_de_redirects( self::uniao_de_redirects_medida() );
		$falhou  = $falhou || F3Base_Imp_Relatorio::FALHA === $uniao['estado'];

		F3Base_Imp_Relatorio::emitir(
			$uniao['estado'],
			'redirects.fonte_composta',
			$uniao['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		$operaveis = array(
			'f3base_contato',
			'f3base_consentimento',
			'f3base_atribuicao',
			'f3base_retencao_meses',
			'f3base_linkedin_partner_id',
			'f3base_tracking',
			'f3base_llms',
			/*
			 * A origem confiável do rate limit é operável porque a resposta
			 * certa depende da hospedagem, e ela muda sem release: quem põe uma
			 * CDN na frente do site precisa poder declarar o cabeçalho ali, sem
			 * esperar por nós. Vazia continua sendo o padrão seguro.
			 */
			'f3base_origem_confiavel',
		);

		$resultado = F3Base_Imp_Gravador::gravar( 'f3base_operaveis', $operaveis );
		$partes[]  = 'f3base_operaveis: ' . $resultado['motivo'];

		$espelho = get_option( 'f3base_copy_contrato', array() );
		$fonte   = (string) F3Base_Imp_Config::obter( 'copy_contrato.fonte', 'config' );

		F3Base_Imp_Relatorio::avaliar(
			is_array( $espelho ) && ! empty( $espelho['devem_aparecer'] ) && 'config' === $fonte,
			'copy.contrato_espelhado',
			sprintf(
				/* translators: 1: quantidade de frases que devem aparecer, 2: quantidade que não podem voltar, 3: fonte declarada. */
				__( 'o contrato de copy existe DENTRO da instância: %1$d frase(s) que devem aparecer e %2$d que não podem voltar, espelhadas em option gerenciada a partir da fonte declarada "%3$s".', 'f3base' ),
				count( self::copy_grupo( 'copy_contrato.devem_aparecer' ) ),
				count( self::copy_grupo( 'copy_contrato.nao_podem_voltar' ) ),
				$fonte
			),
			__( 'o espelho do contrato de copy não existe ou está vazio na instância: o agente de manutenção ajusta aqui, e sem o espelho a checagem de copy não tem contra o que comparar.', 'f3base' ),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		/*
		 * BASE LEGAL DECLARADA É O RAMO BOM. A frase "o texto da política é
		 * técnico e precisa de revisão jurídica" vale para os dois ramos e não
		 * é achado: ela continua no texto, e o estado passa a medir o que dá
		 * para medir daqui — se as duas declarações que a política precisa
		 * existem na configuração.
		 */
		$base_legal = trim( (string) F3Base_Imp_Config::obter( 'retencao.base_legal', '' ) );
		$meses      = (int) F3Base_Imp_Config::obter( 'retencao.leads_meses', 0 );
		$faltando   = array();

		if ( '' === $base_legal ) {
			$faltando[] = __( 'retencao.base_legal está vazia, e a política vai ao ar sem dizer sob qual hipótese do art. 7º os leads são tratados', 'f3base' );
		}

		if ( $meses <= 0 ) {
			$faltando[] = __( 'retencao.leads_meses é zero ou negativo, e sem prazo declarado a eliminação programada do site-core não tem contra o que contar', 'f3base' );
		}

		if ( array() === $faltando ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'lgpd.base_legal_declarada',
				sprintf(
					/* translators: 1: base legal, 2: prazo de retenção em meses. */
					__( 'base legal declarada para os leads: %1$s; retenção operacional de %2$d meses, que é o prazo que a eliminação programada usa. O texto da política é técnico e continua pedindo revisão jurídica — isso vale para qualquer valor destas chaves e por isso não decide este estado.', 'f3base' ),
					$base_legal,
					$meses
				),
				array(
					'evidencia' => 'doc-externa',
					'fase'      => 'local',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'lgpd.base_legal_declarada',
				sprintf(
					/* translators: %s: o que falta declarar, nomeado. */
					__( 'a política de privacidade vai ao ar com declaração incompleta: %s. Não bloqueia a aplicação — a guarda que segura a publicação da política é a do controlador —, e é aviso porque o texto publicado afirma menos do que a LGPD exige que ele afirme.', 'f3base' ),
					implode( '; ', $faltando )
				),
				array(
					'evidencia' => 'doc-externa',
					'fase'      => 'local',
				)
			);
		}

		return array(
			'estado' => $falhou ? F3Base_Imp_Relatorio::FALHA : ( F3Base_Imp_Gravador::em_simulacao() ? F3Base_Imp_Relatorio::NA : F3Base_Imp_Relatorio::OK ),
			'rotulo' => 'site_core.options',
			'motivo' => implode( ' | ', $partes ),
		);
	}

	/**
	 * Grupo do contrato de copy, lido por caminho absoluto.
	 *
	 * @param string $caminho Caminho da lista.
	 * @return array<int,array<string,mixed>>
	 */
	private static function copy_grupo( string $caminho ): array {
		$saida = array();

		foreach ( F3Base_Imp_Config::lista( $caminho ) as $indice => $entrada ) {
			unset( $entrada );

			$id = (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.id', '' );

			if ( '' === $id ) {
				continue;
			}

			$saida[] = array(
				'id'      => $id,
				'grafias' => array_map( 'strval', F3Base_Imp_Config::lista( $caminho . '.' . $indice . '.grafias' ) ),
				'onde'    => array_map( 'strval', F3Base_Imp_Config::lista( $caminho . '.' . $indice . '.onde' ) ),
				'motivo'  => (string) F3Base_Imp_Config::obter( $caminho . '.' . $indice . '.motivo', '' ),
			);
		}

		return $saida;
	}

	/**
	 * Veredito do destino privado de um regime de formulário. FUNÇÃO PURA.
	 *
	 * Três saídas, e elas não são intercambiáveis — foi exatamente a confusão
	 * entre as duas primeiras que produziu o defeito medido:
	 *
	 * - **Chave declarada e VAZIA: BLOCKED.** `contato.whatsapp_e164` nasce vazia
	 *   no template por desenho — é pré-condição que o projeto preenche, não
	 *   defeito do pacote. Pré-condição ausente é BLOCKED com o motivo, NUNCA
	 *   FALHA; a mensagem nomeia a chave exata de `config/site.json` a preencher.
	 * - **Chave preenchida e com formato errado: FALHA.** Aí o dado existe e está
	 *   errado, e isso é defeito de configuração — o lead iria para um destino
	 *   que não recebe.
	 * - **Entrada sem `destino` declarado: FALHA.** O regime está ativo e não diz
	 *   para onde mandar; a entrada é que está quebrada.
	 *
	 * O formato conferido vem do regime, que o schema declara. Regime cujo
	 * conjunto fechado não declara formato para o destino sai OK DIZENDO que só a
	 * presença foi medida — silêncio ali seria a checagem afirmando mais do que
	 * mediu.
	 *
	 * @param string $regime  Regime declarado na entrada.
	 * @param string $caminho Caminho da chave de destino em `config/site.json`.
	 * @param string $valor   Valor lido daquela chave.
	 * @return array{estado:string,motivo:string,resumo:string}
	 */
	public static function veredito_destino( string $regime, string $caminho, string $valor ): array {
		if ( '' === trim( $caminho ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'motivo' => sprintf(
					/* translators: %s: regime declarado. */
					__( 'o regime %s está ativo e a entrada não declara a chave "destino": não existe caminho de configuração para onde o lead deva ir, e isso é defeito da própria entrada, não pré-condição de projeto.', 'f3base' ),
					$regime
				),
				'resumo' => __( 'entrada sem destino declarado', 'f3base' ),
			);
		}

		if ( '' === trim( $valor ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'motivo' => sprintf(
					/* translators: 1: caminho da chave de destino, 2: regime declarado. */
					__( 'pré-condição ausente: a chave %1$s de config/site.json está vazia. Ela nasce vazia no template por desenho — é dado do projeto, não defeito do pacote. Preencha %1$s e execute de novo; até lá o CTA do regime %2$s continua no comportamento degradado declarado, sem envio silencioso.', 'f3base' ),
					$caminho,
					$regime
				),
				'resumo' => sprintf(
					/* translators: %s: caminho da chave de destino. */
					__( 'destino a preencher em %s (BLOCKED)', 'f3base' ),
					$caminho
				),
			);
		}

		$formatos = array(
			'whatsapp'  => array(
				'regex'  => '/^[0-9]{8,15}$/',
				'exige'  => __( 'somente dígitos, com código de país, de 8 a 15 dígitos (E.164 sem "+", sem espaço e sem pontuação)', 'f3base' ),
			),
			'cf7-email' => array(
				'regex'  => '',
				'exige'  => __( 'um endereço de e-mail que o núcleo aceite', 'f3base' ),
			),
		);

		if ( ! isset( $formatos[ $regime ] ) ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::OK,
				'motivo' => sprintf(
					/* translators: 1: caminho da chave de destino, 2: regime declarado. */
					__( 'a chave %1$s está preenchida. O conjunto fechado do regime %2$s não declara formato para o destino, então SÓ A PRESENÇA foi medida — o formato não foi conferido, e dizer isso é parte do resultado.', 'f3base' ),
					$caminho,
					$regime
				),
				'resumo' => __( 'destino presente (formato não declarado pelo regime)', 'f3base' ),
			);
		}

		$valido = 'cf7-email' === $regime
			? ( false !== is_email( $valor ) )
			: ( 1 === preg_match( (string) $formatos[ $regime ]['regex'], $valor ) );

		if ( ! $valido ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::FALHA,
				'motivo' => sprintf(
					/* translators: 1: caminho da chave de destino, 2: regime, 3: formato exigido. */
					__( 'a chave %1$s está PREENCHIDA e o valor não serve para o regime %2$s, que exige %3$s. Destino preenchido e inválido é defeito de configuração, não pré-condição ausente: o lead sairia para um destino que não recebe.', 'f3base' ),
					$caminho,
					$regime,
					(string) $formatos[ $regime ]['exige']
				),
				'resumo' => sprintf(
					/* translators: %s: caminho da chave de destino. */
					__( 'destino inválido em %s (FALHA)', 'f3base' ),
					$caminho
				),
			);
		}

		return array(
			'estado' => F3Base_Imp_Relatorio::OK,
			'motivo' => sprintf(
				/* translators: 1: caminho da chave de destino, 2: regime, 3: formato exigido. */
				__( 'a chave %1$s está preenchida e o valor casa com o que o regime %2$s exige: %3$s.', 'f3base' ),
				$caminho,
				$regime,
				(string) $formatos[ $regime ]['exige']
			),
			'resumo' => __( 'destino configurado e no formato do regime', 'f3base' ),
		);
	}

	/**
	 * Regimes de formulário declarados.
	 *
	 * Cada regime declara o conjunto fechado de variáveis que usa; a validação
	 * do conjunto é do schema. Aqui o implantador prova que o DESTINO privado
	 * está configurado, e emite nos dois ramos por regime.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_formularios(): array {
		$partes   = array();
		$falhou   = false;
		$bloqueou = false;

		foreach ( F3Base_Imp_Config::lista( 'formularios' ) as $indice => $entrada ) {
			unset( $entrada );

			/*
			 * O conjunto fechado do regime é lido INTEIRO, ativo ou não: chave
			 * declarada que nenhuma linha lê é decoração, e o detector geral de
			 * consumidores não abre exceção para o regime que está dormindo.
			 */
			$base         = 'formularios.' . $indice;
			$id           = (string) F3Base_Imp_Config::obter( $base . '.id', '' );
			$regime       = (string) F3Base_Imp_Config::obter( $base . '.regime', '' );
			$ativo        = (bool) F3Base_Imp_Config::obter( $base . '.ativo', false );
			$destino      = (string) F3Base_Imp_Config::obter( $base . '.destino', '' );
			$criterio     = (string) F3Base_Imp_Config::obter( $base . '.criterio_lead', '' );
			$degradado    = (string) F3Base_Imp_Config::obter( $base . '.degradado', '' );
			$escopo       = (string) F3Base_Imp_Config::obter( $base . '.escopo', '' );
			$obrigatorios = array_map( 'strval', F3Base_Imp_Config::lista( $base . '.obrigatorios' ) );
			$confirmacao  = F3Base_Imp_Config::obter( $base . '.pagina_confirmacao', null );
			$inativo      = (string) F3Base_Imp_Config::obter( $base . '.motivo_inativo', '' );

			$pagina_ref = (string) F3Base_Imp_Config::obter(
				'whatsapp' === $regime ? $base . '.pagina_canonica_ref' : $base . '.pagina_ref',
				''
			);

			$anexo = F3Base_Imp_Config::obter( $base . '.anexo', false );

			if ( is_array( $anexo ) ) {
				$anexo = array(
					'tipos'     => array_map( 'strval', F3Base_Imp_Config::lista( $base . '.anexo.tipos' ) ),
					'limite_mb' => (float) F3Base_Imp_Config::obter( $base . '.anexo.limite_mb', 0 ),
					'validacao' => (string) F3Base_Imp_Config::obter( $base . '.anexo.validacao', 'nenhuma' ),
				);
			}

			if ( is_array( $confirmacao ) ) {
				$confirmacao = array(
					'slug'    => (string) F3Base_Imp_Config::obter( $base . '.pagina_confirmacao.slug', '' ),
					'pai_ref' => F3Base_Imp_Config::obter( $base . '.pagina_confirmacao.pai_ref', null ),
				);
			}

			if ( ! $ativo ) {
				F3Base_Imp_Relatorio::emitir(
					F3Base_Imp_Relatorio::NA,
					'formulario.' . $id,
					sprintf(
						/* translators: 1: regime, 2: motivo declarado, 3: escopo, 4: destino, 5: critério, 6: degradado. */
						__( 'condição de aplicabilidade falsa: o regime %1$s está declarado e inativo — %2$s. Conjunto declarado do regime, lido e preservado: escopo %3$s, destino %4$s, critério de lead %5$s, degradado "%6$s".', 'f3base' ),
						$regime,
						'' !== $inativo ? $inativo : __( 'sem motivo declarado', 'f3base' ),
						$escopo,
						$destino,
						$criterio,
						$degradado
					),
					array(
						'evidencia' => 'analise-estatica',
						'fase'      => 'build',
					)
				);

				$partes[] = $id . ': ' . __( 'inativo (N/A)', 'f3base' );
				continue;
			}

			$valor_destino = (string) F3Base_Imp_Config::obter( $destino, '' );
			$veredito      = self::veredito_destino( $regime, $destino, $valor_destino );

			$contexto = sprintf(
				/* translators: 1: regime, 2: escopo, 3: página canônica, 4: critério de lead, 5: obrigatórios, 6: anexo, 7: confirmação, 8: degradado. */
				__( 'regime %1$s ativo, escopo %2$s, página %3$s; critério de lead: %4$s; obrigatórios: %5$s; anexo: %6$s; página de confirmação: %7$s; comportamento degradado: %8$s.', 'f3base' ),
				$regime,
				$escopo,
				'' !== $pagina_ref ? $pagina_ref : __( 'não declarada', 'f3base' ),
				$criterio,
				array() === $obrigatorios ? __( 'nenhum', 'f3base' ) : implode( ', ', $obrigatorios ),
				false === $anexo ? __( 'não', 'f3base' ) : wp_json_encode( $anexo ),
				null === $confirmacao ? __( 'nenhuma (o regime não a tem)', 'f3base' ) : wp_json_encode( $confirmacao ),
				$degradado
			);

			F3Base_Imp_Relatorio::emitir(
				$veredito['estado'],
				'formulario.' . $id,
				$contexto . ' ' . $veredito['motivo'],
				array(
					'evidencia'   => F3Base_Imp_Relatorio::BLOCKED === $veredito['estado'] ? 'pendencia-externa' : 'analise-estatica',
					'fase'        => 'build',
					/*
					 * PRÉ-CONDIÇÃO DECLARADA: o destino do formulário — número de
					 * WhatsApp, e-mail de leads — é dado do operador. BLOCKED aqui
					 * deixa a convergência PENDENTE, e o CTA em degradado deixa de
					 * ser um detalhe que só aparece lendo a linha 30 do log.
					 */
					'precondicao' => true,
				)
			);

			/*
			 * Só FALHA reprova a unidade. BLOCKED continua impedindo a
			 * autodesativação pelo gate de entregável, e é assim que a
			 * pré-condição ausente aparece sem virar defeito do pacote.
			 */
			$falhou   = $falhou || F3Base_Imp_Relatorio::FALHA === $veredito['estado'];
			$bloqueou = $bloqueou || F3Base_Imp_Relatorio::BLOCKED === $veredito['estado'];
			$partes[] = $id . ': ' . $veredito['resumo'];
		}

		if ( $falhou ) {
			$estado_unidade = F3Base_Imp_Relatorio::FALHA;
		} elseif ( $bloqueou ) {
			$estado_unidade = F3Base_Imp_Relatorio::BLOCKED;
		} else {
			$estado_unidade = F3Base_Imp_Relatorio::OK;
		}

		return array(
			'estado' => $estado_unidade,
			'rotulo' => 'formularios.regimes',
			'motivo' => array() === $partes ? __( 'nenhum formulário declarado.', 'f3base' ) : implode( ' | ', $partes ),
		);
	}

	/**
	 * Agenda a cadência do modo somente-relatório.
	 *
	 * Cadência sem agendamento é lembrete. O agendamento é item de ENTREGA
	 * justamente porque ninguém o cria depois — e o mecanismo usado sai nomeado.
	 *
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_cadencia(): array {
		$periodicidade = (string) F3Base_Imp_Config::obter( 'cadencia_relatorio.periodicidade', 'nenhuma' );
		$apos          = (int) F3Base_Imp_Config::obter( 'cadencia_relatorio.apos_n_ajustes', 0 );
		$declarado     = (string) F3Base_Imp_Config::obter( 'cadencia_relatorio.mecanismo', '' );
		$hook          = 'f3base_cadencia_relatorio';

		if ( 'nenhuma' === $periodicidade ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.agendada',
				__( 'condição de aplicabilidade falsa: a configuração declara periodicidade "nenhuma".', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			/* Checagem condicional fecha N/A com a condição declarada, nunca some. */
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.mecanismo_declarado',
				__( 'condição de aplicabilidade falsa: a configuração declara periodicidade "nenhuma", e sem cadência não há mecanismo externo a nomear.', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'rotulo' => 'cadencia',
				'motivo' => __( 'periodicidade declarada como nenhuma: nada agendado.', 'f3base' ),
			);
		}

		/*
		 * AS RECORRÊNCIAS DECLARADAS SÃO AS DO `site-core`, e não as do núcleo.
		 * Até a 1.0.17 este mapa levava `quinzenal` para `weekly` — o DOBRO da
		 * frequência — e `mensal` para `monthly`, que não existe no WordPress e
		 * caía para `daily` logo abaixo, três linhas adiante, em silêncio. As
		 * duas degradações aconteciam sem nada no relatório.
		 *
		 * Quem registra `f3base_quinzenal` (quinze dias) e `f3base_mensal`
		 * (trinta) é o módulo `cadencia-relatorio` do `site-core`, que é o
		 * componente que sobrevive à autodesativação de quem agenda. O nome sai
		 * da CONSTANTE daquele módulo quando ele está carregado, e do PREFIXO
		 * TÉCNICO declarado quando não está — nunca de um literal preso a um
		 * prefixo que a renomeação de projeto trocaria.
		 */
		$prefixo   = (string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' );
		$quinzenal = class_exists( 'F3Base_Modulo_Cadencia_Relatorio' )
			? (string) F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_QUINZENAL
			: $prefixo . '_quinzenal';
		$mensal    = class_exists( 'F3Base_Modulo_Cadencia_Relatorio' )
			? (string) F3Base_Modulo_Cadencia_Relatorio::RECORRENCIA_MENSAL
			: $prefixo . '_mensal';

		$recorrencias = array(
			'semanal'   => 'weekly',
			'quinzenal' => $quinzenal,
			'mensal'    => $mensal,
		);

		$declarada   = $recorrencias[ $periodicidade ] ?? 'weekly';
		$recorrencia = $declarada;
		$agendadas   = wp_get_schedules();

		/*
		 * DEGRADAÇÃO NOMEADA. A queda para `daily` continua existindo — sem ela
		 * o site ficaria sem cadência nenhuma —, mas ela deixa de ser calada: a
		 * mensagem diz a recorrência DECLARADA, a USADA, o que a diferença custa
		 * em frequência e por que aconteceu. `quinzenal` caindo em `weekly`
		 * dobra a frequência, e dobrar frequência sem registro é o instrumento
		 * mudando o combinado por conta própria.
		 */
		$degradacao = '';

		if ( ! isset( $agendadas[ $recorrencia ] ) ) {
			$recorrencia = 'daily';

			/*
			 * O INTERVALO DA RECORRÊNCIA USADA É LIDO DO AGENDADOR, não digitado:
			 * escrever "de 1 dia" aqui seria afirmar sobre a tabela do núcleo sem
			 * consultá-la, e é o tipo de número que envelhece calado.
			 */
			$intervalo  = isset( $agendadas[ $recorrencia ]['interval'] ) ? (int) $agendadas[ $recorrencia ]['interval'] : 0;
			$degradacao = sprintf(
				/* translators: 1: periodicidade declarada, 2: recorrência declarada, 3: recorrência usada, 4: intervalo da usada, lido do agendador. */
				__( 'DEGRADAÇÃO NOMEADA: a periodicidade declarada é "%1$s", que pede a recorrência %2$s, e essa recorrência NÃO existia no agendador no momento deste agendamento. O evento foi agendado com %3$s, cujo intervalo lido do agendador é %4$s — frequência diferente da combinada, e maior. Quem registra %2$s é o módulo cadencia-relatorio do site-core; a causa provável é ele não estar ativo nesta requisição. Reexecute com o site-core ativo e o agendamento sai com a recorrência declarada.', 'f3base' ),
				$periodicidade,
				$declarada,
				$recorrencia,
				$intervalo > 0
					? sprintf(
						/* translators: %d: intervalo em segundos. */
						__( '%d segundo(s)', 'f3base' ),
						$intervalo
					)
					: __( 'não informado pelo agendador', 'f3base' )
			);
		}

		$mecanismo = sprintf(
			/* translators: 1: recorrência do WP-Cron, 2: nome do hook, 3: recorrência declarada. */
			__( 'WP-Cron, recorrência %1$s (declarada: %3$s), hook %2$s', 'f3base' ),
			$recorrencia,
			$hook,
			$declarada
		);

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.agendada',
				sprintf(
					/* translators: 1: mecanismo, 2: degradação nomeada, quando houver. */
					__( 'modo simulação: agendaria a cadência por %1$s. %2$s', 'f3base' ),
					$mecanismo,
					'' !== $degradacao ? $degradacao : ''
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			/* Checagem condicional fecha N/A com a condição declarada, nunca some. */
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'cadencia.mecanismo_declarado',
				sprintf(
					/* translators: %s: caminho da chave. */
					__( 'condição de aplicabilidade falsa: modo simulação, nada é gravado e o valor de %s não é conferido nesta execução.', 'f3base' ),
					'cadencia_relatorio.mecanismo'
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'rotulo' => 'cadencia',
				'motivo' => $mecanismo,
			);
		}

		$proxima = wp_next_scheduled( $hook );

		if ( false === $proxima ) {
			$quando   = time() + DAY_IN_SECONDS;
			$agendado = wp_schedule_event( $quando, $recorrencia, $hook );

			if ( false !== $agendado && ! is_wp_error( $agendado ) ) {
				F3Base_Imp_Journal::registrar(
					F3Base_Imp_Journal::TIPO_CRON,
					$hook,
					null,
					array( 'recorrencia' => $recorrencia ),
					array(
						'acao' => 'cron.desagendar',
						'hook' => $hook,
						'args' => array(),
					)
				);
			}

			$proxima = wp_next_scheduled( $hook );
		}

		$resultado = F3Base_Imp_Gravador::gravar(
			'f3base_cadencia',
			array(
				'periodicidade'  => $periodicidade,
				'apos_n_ajustes' => $apos,
				'mecanismo'      => '' !== $declarado ? $declarado : $mecanismo,
				'hook'           => $hook,
			),
			array( 'autoload' => false )
		);

		/*
		 * O GATILHO POR AJUSTES DEIXA DE SER PROMESSA SEM DONO. A linha antiga
		 * imprimia "gatilho alternativo: após N ajustes" sem dizer quem mantém o
		 * contador — e até a 1.0.17 ninguém mantinha: `apos_n_ajustes` era
		 * gravado numa option que nenhuma linha do pacote lia. Quem conta, hoje,
		 * é o módulo cadencia-relatorio do site-core, e é ele que dispara; este
		 * implantador só GRAVA o número, e se autodesativa depois.
		 */
		$gatilho = $apos > 0
			? sprintf(
				/* translators: 1: número de ajustes, 2: nome da option lida pelo site-core. */
				__( 'gatilho alternativo: após %1$d ajustes, o que vier antes. Quem conta os ajustes e dispara NÃO é este implantador — que se autodesativa — e sim o módulo cadencia-relatorio do site-core, que lê o número de %2$s e conta cada escrita em option gerenciada; as escritas da própria execução da cadência não contam.', 'f3base' ),
				$apos,
				'f3base_cadencia'
			)
			: __( 'gatilho alternativo por ajustes: DESLIGADO — cadencia_relatorio.apos_n_ajustes está em zero, e o site-core não conta nem dispara nada por essa via. A única via de disparo é a recorrência acima.', 'f3base' );

		/*
		 * O ESTADO SAI DA MEDIÇÃO, e são três fatos distintos: não agendou (o
		 * evento não existe — FALHA), agendou com recorrência DIFERENTE da
		 * declarada (a cadência existe e não é a combinada — WARN, com o achado
		 * adverso medido e nomeado), e agendou com a declarada (OK).
		 */
		$agendou   = false !== $proxima;
		$degradou  = '' !== $degradacao;
		$mensagens = array(
			F3Base_Imp_Relatorio::OK    => sprintf(
				/* translators: 1: mecanismo, 2: data da próxima execução, 3: gatilho por ajustes. */
				__( 'cadência do modo somente-relatório agendada com a recorrência DECLARADA — mecanismo: %1$s; próxima execução: %2$s; %3$s O README diz como pausar e como retomar.', 'f3base' ),
				'' !== $declarado ? $declarado : $mecanismo,
				$agendou ? (string) wp_date( 'Y-m-d H:i', (int) $proxima ) : '',
				$gatilho
			),
			F3Base_Imp_Relatorio::WARN  => sprintf(
				/* translators: 1: degradação nomeada, 2: data da próxima execução, 3: gatilho por ajustes. */
				__( 'a cadência FICOU agendada, e NÃO com a recorrência declarada. %1$s Próxima execução: %2$s. %3$s', 'f3base' ),
				$degradacao,
				$agendou ? (string) wp_date( 'Y-m-d H:i', (int) $proxima ) : '',
				$gatilho
			),
			F3Base_Imp_Relatorio::FALHA => sprintf(
				/* translators: %s: mecanismo tentado. */
				__( 'a cadência NÃO ficou agendada por %s: sem agendamento, a leitura de volta dos adaptadores não acontece em lugar nenhum e o plugin muda embaixo do site sem nada conferir.', 'f3base' ),
				$mecanismo
			),
		);

		$estado_medido = F3Base_Imp_Relatorio::FALHA;

		if ( $agendou ) {
			$estado_medido = $degradou ? F3Base_Imp_Relatorio::WARN : F3Base_Imp_Relatorio::OK;
		}

		$estado_da_agenda = F3Base_Imp_Relatorio::emitir(
			$estado_medido,
			'cadencia.agendada',
			$mensagens[ $estado_medido ],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		/*
		 * O NOME DO MECANISMO EXTERNO É PRÉ-CONDIÇÃO DECLARADA, e ganha linha
		 * própria na 1.0.18. README.md e MANIFESTO.md afirmavam desde a 1.0.6
		 * que "mecanismo vazio → o item fecha BLOCKED, não OK", e o item que
		 * existia era `cadencia.agendada`, que mede o WP-Cron e fecha OK porque
		 * o agendamento existe mesmo. As duas afirmações eram verdadeiras sobre
		 * coisas diferentes, e nenhuma linha do relatório correspondia à do
		 * documento. Agora corresponde: o agendamento é uma pergunta,
		 * `cadencia_relatorio.mecanismo` é outra, e é esta que fecha BLOCKED
		 * enquanto o projeto não declarar qual é o mecanismo da hospedagem.
		 */
		F3Base_Imp_Relatorio::emitir(
			'' !== $declarado ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::BLOCKED,
			'cadencia.mecanismo_declarado',
			'' !== $declarado
				? sprintf(
					/* translators: 1: mecanismo declarado, 2: mecanismo montado pelo WP-Cron. */
					__( 'o mecanismo externo da cadência está DECLARADO: %1$s. É ele que sai no relatório de entrega como o gatilho a desabilitar na pausa e a reabilitar na retomada. O agendamento medido neste host continua sendo %2$s.', 'f3base' ),
					$declarado,
					$mecanismo
				)
				: sprintf(
					/* translators: 1: caminho da chave, 2: mecanismo montado pelo WP-Cron. */
					__( 'pré-condição ausente: %1$s está vazio. O nome do mecanismo depende da hospedagem — agendador do host, cron real do servidor ou tarefa do lado do agente — e é declaração do PROJETO que instancia esta base, não fato que este pacote possa medir. Sem ele, o relatório de entrega não tem o que nomear para quem for pausar ou retomar a cadência. O que EXISTE e está medido é o agendamento por %2$s; declarar o mecanismo é dizer qual gatilho externo o operador desabilita. Preencha a chave e execute de novo.', 'f3base' ),
					'cadencia_relatorio.mecanismo',
					$mecanismo
				),
			array(
				'evidencia'   => '' !== $declarado ? 'analise-estatica' : 'pendencia-externa',
				'fase'        => 'producao',
				'precondicao' => true,
			)
		);

		return array(
			'estado' => false !== $proxima ? $estado_da_agenda : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => 'cadencia',
			'motivo' => $mecanismo . ' — ' . $resultado['motivo']
				. ( '' !== $degradacao ? ' ' . $degradacao : '' ),
		);
	}

	/**
	 * Entregáveis, canal MCP, consumidores e o que só a suíte mede.
	 *
	 * @param string $modo Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_entrega( string $modo ): array {
		$estados = F3Base_Imp_Entrega::conferir();

		self::conferir_consumidores();
		self::conferir_wp_html_do_tema();
		self::conferir_versoes_declaradas();
		self::declarar_evidencia_importada();

		/*
		 * DOIS GATES, DUAS LISTAS. O que decide a autodesativação são os
		 * entregáveis do gate de APLICAÇÃO; a evidência importada da suíte
		 * externa entra pelo gate de FASE, sai nomeada e não proíbe nada. A
		 * varredura antiga era por prefixo `entrega.` e engolia as duas.
		 */
		$bloqueados = array();

		foreach ( F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao() as $entregavel ) {
			if ( F3Base_Imp_Relatorio::BLOCKED === ( $estados[ $entregavel ] ?? '' ) ) {
				$bloqueados[] = $entregavel;
			}
		}

		$pendencias_de_fase = array();

		foreach ( F3Base_Imp_Entrega::gates_de_fase() as $gate_de_fase ) {
			if ( F3Base_Imp_Relatorio::OK !== ( $estados[ $gate_de_fase ] ?? '' ) ) {
				$pendencias_de_fase[] = $gate_de_fase;
			}
		}

		$nota_de_fase = array() === $pendencias_de_fase
			? __( 'Nenhuma pendência de fase em aberto.', 'f3base' )
			: sprintf(
				/* translators: %s: pendências de fase, pelo nome. */
				__( 'Pendência(s) de FASE, nomeada(s) e fora do gate da autodesativação: %s.', 'f3base' ),
				implode( ', ', $pendencias_de_fase )
			);

		unset( $modo );

		return array(
			'estado' => array() === $bloqueados ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::BLOCKED,
			'rotulo' => 'entrega',
			'motivo' => array() === $bloqueados
				? sprintf(
					/* translators: %s: nota sobre as pendências de fase. */
					__( 'todos os entregáveis do gate de aplicação fecharam sem BLOCKED e o canal foi conferido pelas rotas. %s', 'f3base' ),
					$nota_de_fase
				)
				: sprintf(
					/* translators: 1: entregáveis do gate de aplicação em BLOCKED, pelo nome, 2: nota sobre as pendências de fase. */
					__( 'entregáveis do gate de aplicação em %1$s. Enquanto houver um, a autodesativação fica proibida. %2$s', 'f3base' ),
					F3Base_Imp_Relatorio::nomes_em( F3Base_Imp_Relatorio::BLOCKED, $bloqueados ),
					$nota_de_fase
				),
		);
	}

	/**
	 * DIAGNÓSTICO: quais chaves ESTA execução leu. Nunca um veredito.
	 *
	 * O defeito medido na 1.0.7: uma checagem chamada
	 * `config.toda_chave_tem_consumidor` reprovou nomeando vinte chaves —
	 * `ambiente.url_canonica`, `orcamento_pagina.*`, `release.*`, `tema.fontes`
	 * e o resto — que TÊM consumidor. Quem as lê é a suíte, o site-core ou um
	 * caminho de execução que aquele lote não percorreu.
	 *
	 * Eram DUAS implementações com o mesmo nome medindo perguntas diferentes: o
	 * detector estático cruza toda chave contra TODO o código do pacote (e fecha
	 * OK); esta contagem cruza contra o que o implantador leu NESTA EXECUÇÃO. A
	 * duplicação de fonte de verdade que a 1.0.7 eliminou para os gates,
	 * reaparecendo aqui.
	 *
	 * A DECISÃO, dita por inteiro: **o veredito de "chave sem consumidor" é da
	 * suíte, e só dela** — `estatica.detector_chave_sem_consumidor`, com piso
	 * dos dois lados. Esta linha continua existindo porque a informação é útil,
	 * mas passa a se chamar pelo que mede e JAMAIS vira FALHA.
	 * `estatica.gate_fonte_unica` é o detector que impede a derivação de voltar
	 * para cá.
	 *
	 * O QUE MUDOU NA 1.0.15: ela também deixou de sair em WARN sempre. A
	 * contagem de chaves lidas não é achado — o texto sempre disse isso —, e o
	 * estado agora mede a única coisa adversa que dá para medir daqui: se o
	 * pacote afirma, em `consumidores_declarados`, que toda chave tem
	 * consumidor. Afirma: OK. Não afirma: WARN, nomeando a garantia que o
	 * relatório perde.
	 *
	 * @return void
	 */
	private static function conferir_consumidores(): void {
		$declarou    = (bool) F3Base_Imp_Config::obter( 'consumidores_declarados', false );
		$declaradas  = F3Base_Imp_Config::chaves_declaradas();
		$lidas       = F3Base_Imp_Config::chaves_lidas();
		$nao_lidas   = F3Base_Imp_Config::chaves_sem_consumidor();
		$dono        = implode( ', ', F3Base_Imp_Entrega::vereditos_da_suite() );

		$nota = $declarou
			? sprintf(
				/* translators: %s: nome da checagem da suíte que detém o veredito. */
				__( 'A configuração declara consumidores_declarados = true, e o veredito sobre chave sem consumidor é de %s, na suíte, que cruza contra TODO o código do pacote e tem piso dos dois lados.', 'f3base' ),
				$dono
			)
			: sprintf(
				/* translators: %s: nome da checagem da suíte que detém o veredito. */
				__( 'A configuração declara consumidores_declarados = false: o pacote não afirma que toda chave tem consumidor, e o cruzamento exigível continua sendo o de %s, na suíte.', 'f3base' ),
				$dono
			);

		/*
		 * A CONTAGEM NÃO É ACHADO. Chave não lida NESTE caminho de execução não
		 * é defeito — a própria mensagem diz isso —, e sair em WARN por causa
		 * dela era a linha se contradizendo. O que É medível e adverso aqui é
		 * outra coisa: se o pacote AFIRMA que toda chave tem consumidor. Com
		 * `consumidores_declarados = true` a afirmação existe e o cruzamento
		 * exigível é o da suíte, com piso — OK. Com `false` o pacote se recusa a
		 * afirmar, e o relatório perde uma garantia que ele costuma ter — WARN,
		 * nomeando o que se perde.
		 */
		if ( $declarou ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'config.chaves_lidas_nesta_execucao',
				sprintf(
					/* translators: 1: quantidade lida, 2: quantidade declarada, 3: chaves não lidas neste caminho, 4: nota sobre quem detém o veredito. */
					__( 'esta execução leu %1$d dos %2$d caminhos declarados na configuração. Chave NÃO lida aqui não é defeito: chave lida só pela suíte, só pelo site-core ou só em outro caminho de execução continua tendo consumidor — por isso esta contagem é detalhe de OK, e não aviso. Não lidas nesta execução: %3$s. %4$s', 'f3base' ),
					count( $lidas ),
					count( $declaradas ),
					array() === $nao_lidas ? __( 'nenhuma', 'f3base' ) : implode( ', ', $nao_lidas ),
					$nota
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'config.chaves_lidas_nesta_execucao',
				sprintf(
					/* translators: 1: quantidade lida, 2: quantidade declarada, 3: chaves não lidas neste caminho, 4: nota sobre quem detém o veredito. */
					__( 'a configuração declara consumidores_declarados = false: este pacote NÃO afirma que toda chave declarada tem consumidor, e quem lê o relatório perde essa garantia — chave órfã pode existir sem que nada aqui a acuse. Esta execução leu %1$d dos %2$d caminhos declarados; não lidas nesta execução: %3$s. %4$s', 'f3base' ),
					count( $lidas ),
					count( $declaradas ),
					array() === $nao_lidas ? __( 'nenhuma', 'f3base' ) : implode( ', ', $nao_lidas ),
					$nota
				),
				array(
					'evidencia' => 'medida',
					'fase'      => 'local',
				)
			);
		}
	}

	/**
	 * Todo bloco `wp:html` do tema instalado consta da lista declarada?
	 *
	 * @return void
	 */
	private static function conferir_wp_html_do_tema(): void {
		$declarados = array();

		foreach ( F3Base_Imp_Config::lista( 'tema.wp_html_excecoes' ) as $indice => $entrada ) {
			unset( $entrada );

			$arquivo = (string) F3Base_Imp_Config::obter( 'tema.wp_html_excecoes.' . $indice . '.arquivo', '' );
			$motivo  = (string) F3Base_Imp_Config::obter( 'tema.wp_html_excecoes.' . $indice . '.motivo', '' );

			if ( '' !== $arquivo && '' !== $motivo ) {
				$declarados[] = $arquivo;
			}
		}

		$raiz = get_stylesheet_directory();

		if ( ! is_dir( $raiz ) ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::BLOCKED,
				'tema.wp_html_declarado',
				__( 'pré-condição ausente: o diretório do tema ativo não está legível para a varredura.', 'f3base' ),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'local',
				)
			);

			return;
		}

		$fora     = array();
		$achados  = array();
		$iterador = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $raiz, FilesystemIterator::SKIP_DOTS ) );

		foreach ( $iterador as $arquivo ) {
			if ( ! $arquivo instanceof SplFileInfo || ! $arquivo->isFile() || 'html' !== strtolower( (string) $arquivo->getExtension() ) ) {
				continue;
			}

			$conteudo = (string) file_get_contents( (string) $arquivo->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- varredura estática local.

			if ( ! str_contains( $conteudo, 'wp:html' ) ) {
				continue;
			}

			$relativo  = ltrim( str_replace( array( '\\', $raiz ), array( '/', '' ), (string) $arquivo->getPathname() ), '/' );
			$achados[] = $relativo;

			if ( ! in_array( $relativo, $declarados, true ) ) {
				$fora[] = $relativo;
			}
		}

		F3Base_Imp_Relatorio::avaliar(
			array() === $fora,
			'tema.wp_html_declarado',
			sprintf(
				/* translators: 1: arquivos com wp:html, 2: arquivos declarados. */
				__( 'todo bloco wp:html do tema consta da lista declarada com motivo. Encontrados em: %1$s; declarados: %2$s.', 'f3base' ),
				array() === $achados ? __( 'nenhum arquivo', 'f3base' ) : implode( ', ', $achados ),
				array() === $declarados ? __( 'nenhum', 'f3base' ) : implode( ', ', $declarados )
			),
			sprintf(
				/* translators: %s: arquivos fora da lista. */
				__( 'bloco wp:html fora da lista de exceções declarada: %s. A lista existe para que cada exceção tenha motivo escrito; navegação nunca entra nela.', 'f3base' ),
				implode( ', ', $fora )
			),
			array(
				'evidencia' => 'analise-estatica',
				'fase'      => 'local',
			)
		);
	}

	/**
	 * Versões declaradas contra as observadas — diagnóstico, nunca gate.
	 *
	 * @return void
	 */
	private static function conferir_versoes_declaradas(): void {
		$tema_slug = (string) F3Base_Imp_Config::obter( 'site.tema_slug', '' );
		$core_slug = (string) F3Base_Imp_Config::obter( 'site.site_core_slug', '' );

		$pares = array(
			'release.versao_tema'        => array(
				'declarada' => (string) F3Base_Imp_Config::obter( 'release.tema', '' ),
				'observada' => (string) wp_get_theme( $tema_slug )->get( 'Version' ),
			),
			'release.versao_site_core'   => array(
				'declarada' => (string) F3Base_Imp_Config::obter( 'release.site_core', '' ),
				'observada' => F3Base_Imp_Plugins::versao_instalada( $core_slug ),
			),
			'release.versao_implantador' => array(
				'declarada' => (string) F3Base_Imp_Config::obter( 'release.implantador', '' ),
				'observada' => f3base_imp_versao(),
			),
		);

		foreach ( $pares as $nome => $par ) {
			F3Base_Imp_Relatorio::condicional(
				'' !== $par['observada'],
				sprintf(
					/* translators: %s: nome da checagem. */
					__( 'o artefato de %s ainda não está instalado, então não há versão observada para comparar.', 'f3base' ),
					$nome
				),
				$par['declarada'] === $par['observada'],
				$nome,
				sprintf(
					/* translators: 1: versão declarada, 2: versão observada. */
					__( 'versão declarada %1$s confere com a observada %2$s.', 'f3base' ),
					$par['declarada'],
					$par['observada']
				),
				sprintf(
					/* translators: 1: versão declarada, 2: versão observada. */
					__( 'a configuração declara %1$s e o artefato instalado responde %2$s — o cabeçalho do arquivo é a fonte única, e é ele que o ?ver= publica.', 'f3base' ),
					$par['declarada'],
					$par['observada']
				),
				array(
					'evidencia' => 'leitura-de-volta',
					'fase'      => 'local',
				)
			);
		}

		$canonica = (string) F3Base_Imp_Config::obter( 'ambiente.url_canonica', '' );

		F3Base_Imp_Relatorio::condicional(
			'' !== $canonica,
			__( 'a configuração não declara URL canônica: nada a cruzar com home_url().', 'f3base' ),
			untrailingslashit( $canonica ) === untrailingslashit( home_url() ),
			'ambiente.url_canonica',
			sprintf(
				/* translators: %s: URL. */
				__( 'a URL canônica declarada confere com home_url(): %s.', 'f3base' ),
				home_url()
			),
			sprintf(
				/* translators: 1: URL declarada, 2: home_url observado. */
				__( 'a URL canônica declarada (%1$s) diverge de home_url() (%2$s). O cross-check é diagnóstico: nada aqui substitui home_url() na composição de URLs.', 'f3base' ),
				$canonica,
				home_url()
			),
			array(
				'evidencia' => 'medida',
				'fase'      => 'local',
			)
		);

		$prefixo = (string) F3Base_Imp_Config::obter( 'site.prefixo_tecnico', '' );
		$dominio = (string) F3Base_Imp_Config::obter( 'site.text_domain', '' );

		F3Base_Imp_Relatorio::avaliar(
			'' !== $prefixo && $dominio === F3BASE_IMP_TEXT_DOMAIN,
			'site.prefixo_tecnico',
			sprintf(
				/* translators: 1: prefixo técnico, 2: text domain. */
				__( 'prefixo técnico %1$s e text domain %2$s conferem com os do implantador em execução.', 'f3base' ),
				$prefixo,
				$dominio
			),
			sprintf(
				/* translators: 1: text domain declarado, 2: text domain em uso. */
				__( 'o text domain declarado (%1$s) diverge do usado pelo implantador (%2$s): strings traduzidas com dois domínios não aparecem juntas em lugar nenhum.', 'f3base' ),
				$dominio,
				F3BASE_IMP_TEXT_DOMAIN
			),
			array(
				'evidencia' => 'analise-estatica',
				'fase'      => 'build',
			)
		);

		/*
		 * "Política aplicada: ultima-da-fonte-oficial" É O RAMO BOM. O que pode
		 * estar adverso é a política NÃO estar declarada: sem ela, o instalador
		 * não tem critério e o gate de leitura de volta não tem contra o que
		 * comparar.
		 */
		$politica_versao    = trim( (string) F3Base_Imp_Config::obter( 'plugins.politica_versao', '' ) );
		$politica_autoupdate = trim( (string) F3Base_Imp_Config::obter( 'plugins.autoupdate', '' ) );
		$protegidos_nomeados = implode( ', ', array_map( 'strval', F3Base_Imp_Config::lista( 'plugins.protegidos' ) ) );
		$sem_politica        = array();

		if ( '' === $politica_versao ) {
			$sem_politica[] = __( 'plugins.politica_versao', 'f3base' );
		}

		if ( '' === $politica_autoupdate ) {
			$sem_politica[] = __( 'plugins.autoupdate', 'f3base' );
		}

		if ( array() === $sem_politica ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'plugins.politica_versao',
				sprintf(
					/* translators: 1: política de versão, 2: política de autoupdate, 3: plugins protegidos. */
					__( 'política aplicada: %1$s; atualização automática: %2$s; plugins protegidos, não desativados nem reconfigurados: %3$s. As duas políticas estão declaradas, e é isso que dá critério ao instalador e ao gate de leitura de volta.', 'f3base' ),
					$politica_versao,
					$politica_autoupdate,
					'' !== $protegidos_nomeados ? $protegidos_nomeados : __( 'nenhum', 'f3base' )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'plugins.politica_versao',
				sprintf(
					/* translators: 1: chaves de política vazias, 2: plugins protegidos. */
					__( 'política de plugin NÃO declarada em %1$s: sem ela o instalador fica sem critério de versão ou de atualização automática, e o gate de leitura de volta não tem contra o que comparar. Plugins protegidos, não desativados nem reconfigurados: %2$s.', 'f3base' ),
					implode( ' e ', $sem_politica ),
					'' !== $protegidos_nomeados ? $protegidos_nomeados : __( 'nenhum', 'f3base' )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		}

		/*
		 * "Fontes auto-hospedadas: 0; fragmentos sincronizados: 0 (lista vazia é
		 * estado válido)" era a linha se contradizendo em voz alta: declarava o
		 * estado válido e saía em WARN por isso. Contar não é achado.
		 *
		 * O que É adverso, e agora decide o estado: declaração que aponta para
		 * arquivo que não existe. Fonte auto-hospedada declarada cujo arquivo
		 * não está no pacote não é servida — a página cai na fonte de sistema e
		 * ninguém percebe até alguém comparar duas telas.
		 */
		$fontes      = F3Base_Imp_Config::lista( 'tema.fontes' );
		$fragmentos  = F3Base_Imp_Config::lista( 'tema.fragmentos_sincronizados' );
		$sem_arquivo = array();

		foreach ( $fontes as $indice => $entrada ) {
			unset( $entrada );

			$familia = (string) F3Base_Imp_Config::obter( 'tema.fontes.' . $indice . '.familia', '' );
			$arquivo = (string) F3Base_Imp_Config::obter( 'tema.fontes.' . $indice . '.arquivo', '' );

			if ( '' === $arquivo || '' !== f3base_imp_caminho( $arquivo ) && is_file( f3base_imp_caminho( $arquivo ) ) ) {
				continue;
			}

			$sem_arquivo[] = sprintf(
				/* translators: 1: família declarada, 2: arquivo declarado. */
				__( '%1$s aponta para %2$s, que não existe no pacote', 'f3base' ),
				'' !== $familia ? $familia : __( '(família não declarada)', 'f3base' ),
				$arquivo
			);
		}

		if ( array() === $sem_arquivo ) {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::OK,
				'tema.declaracoes',
				sprintf(
					/* translators: 1: fontes declaradas, 2: fragmentos sincronizados. */
					__( 'fontes auto-hospedadas declaradas: %1$d, todas com arquivo presente no pacote; fragmentos sincronizados declarados: %2$d. Lista vazia é estado válido — fora dela, tudo expandido no conteúdo — e por isso a contagem é detalhe de OK, não aviso.', 'f3base' ),
					count( $fontes ),
					count( $fragmentos )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		} else {
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::WARN,
				'tema.declaracoes',
				sprintf(
					/* translators: 1: quantidade sem arquivo, 2: cada uma nomeada, 3: fragmentos sincronizados. */
					__( '%1$d fonte(s) auto-hospedada(s) declarada(s) SEM o arquivo correspondente no pacote: %2$s. A página cai na fonte de sistema sem que nada quebre, e a diferença só aparece comparando duas telas. Fragmentos sincronizados declarados: %3$d.', 'f3base' ),
					count( $sem_arquivo ),
					implode( '; ', $sem_arquivo ),
					count( $fragmentos )
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
				)
			);
		}
	}

	/**
	 * Declara como BLOCKED o que este implantador não executa no host.
	 *
	 * Checagem de navegador, axe e inspeção visual entra como evidência
	 * importada da suíte externa; ausente, é BLOCKED — nunca "medido".
	 *
	 * @return void
	 */
	private static function declarar_evidencia_importada(): void {
		F3Base_Imp_Relatorio::emitir(
			F3Base_Imp_Relatorio::BLOCKED,
			'orcamento.medicao_de_pagina',
			sprintf(
				/* translators: 1: CSS, 2: JS próprio, 3: peso total, 4: requisições, 5: nós de DOM. */
				__( 'orçamento declarado — CSS %1$s KB, JS próprio %2$s KB, peso total %3$s KB, %4$d requisições, %5$d nós de DOM. A medição é de navegador e não roda neste host: evidência importada da suíte externa, ausente nesta execução.', 'f3base' ),
				number_format_i18n( (float) F3Base_Imp_Config::obter( 'orcamento_pagina.css_kb', 0 ) ),
				number_format_i18n( (float) F3Base_Imp_Config::obter( 'orcamento_pagina.js_proprio_kb', 0 ) ),
				number_format_i18n( (float) F3Base_Imp_Config::obter( 'orcamento_pagina.peso_total_kb', 0 ) ),
				(int) F3Base_Imp_Config::obter( 'orcamento_pagina.requisicoes', 0 ),
				(int) F3Base_Imp_Config::obter( 'orcamento_pagina.dom_nos', 0 )
			),
			array(
				'evidencia' => 'pendencia-externa',
				'fase'      => 'campo',
				'gate'      => 'fase',
			)
		);
	}

	/**
	 * Encerramento: estado final, carimbo de release e autodesativação.
	 *
	 * @param string $modo Modo.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function etapa_encerramento( string $modo ): array {
		/*
		 * CADA NÚMERO DIZ O QUE CONTA, e nenhuma comparação cruza escopos. A
		 * versão anterior comparava `falhas` (linhas do relatório) com
		 * `count( unidades() )` (unidades do plano) para decidir FALHA_PARCIAL:
		 * dois escopos, um `<`, e um estado de máquina decidido por uma
		 * comparação sem sentido. O gate continua sendo o das CHECAGENS — é
		 * qualquer linha em FALHA que impede o sucesso —, e a contagem de
		 * unidades entra no texto como o segundo escopo, nomeado.
		 */
		$checagens_falha = F3Base_Imp_Relatorio::checagens_em_falha();
		$escopos         = F3Base_Imp_Relatorio::escopos();

		/*
		 * CONTAGEM E NOMES SAEM JUNTOS. Esta linha imprimia "5 FALHA e 6
		 * BLOCKED" e mais nada; a tela mostrava UMA unidade em FALHA e o
		 * operador não tinha como saber quais eram as outras — elas rodaram
		 * dentro de unidades que fecharam OK. Agora o próprio log as nomeia.
		 */
		$nomes_de_checagens = F3Base_Imp_Relatorio::nomes_por_estado( 'checagens' );
		$nomes_de_unidades  = F3Base_Imp_Relatorio::nomes_por_estado( 'unidades' );

		/*
		 * CADA NÚMERO COLADO NO ESTADO QUE ELE CONTA. A linha da 1.0.17 imprimia
		 * "5 em FALHA: nenhum · BLOCKED: … · WARN: …": o 5 era FALHA MAIS
		 * BLOCKED, encostava no primeiro estado da string — e quem lê casa
		 * número com a primeira palavra — e a mesma string ainda listava WARN,
		 * que não estava nos cinco. O cliente já formatava certo na linha 2 do
		 * mesmo log, por `resumo_por_estado()`, com `ESTADO: N — nomes` por
		 * estado; é essa forma que passa a valer aqui, pelo mesmo formatador.
		 */
		$contagem_de_checagens = F3Base_Imp_Relatorio::contagem();
		$contagem_de_unidades  = F3Base_Imp_Relatorio::contagem_unidades();

		$diagnostico = sprintf(
			/* translators: 1: escopo das checagens, 2: contagem com nomes por estado das checagens, 3: escopo das unidades, 4: contagem com nomes por estado das unidades. */
			__( 'Contagens por escopo, medidas ANTES de esta unidade emitir a própria linha, cada número colado no estado que ele conta e cada estado com a LISTA DE NOMES — %1$s: %2$s; %3$s: %4$s. A contagem final de cada escopo, com os nomes, sai no rodapé do log.', 'f3base' ),
			(string) ( $escopos['checagens'] ?? '' ),
			F3Base_Imp_Relatorio::resumo_por_estado( $contagem_de_checagens, $nomes_de_checagens ),
			(string) ( $escopos['unidades'] ?? '' ),
			F3Base_Imp_Relatorio::resumo_por_estado( $contagem_de_unidades, $nomes_de_unidades )
		);

		if ( self::MODO_EXECUCAO !== $modo ) {
			/* Checagem condicional fecha N/A com a condição declarada, nunca some. */
			F3Base_Imp_Relatorio::emitir(
				F3Base_Imp_Relatorio::NA,
				'entrega.convergencia',
				sprintf(
					/* translators: %s: modo. */
					__( 'condição de aplicabilidade falsa: modo %s. O terceiro eixo soma as pré-condições declaradas que fecharam estado numa APLICAÇÃO, e neste modo nada foi aplicado.', 'f3base' ),
					$modo
				),
				array(
					'evidencia' => 'analise-estatica',
					'fase'      => 'build',
					'gate'      => 'fase',
				)
			);

			self::liberar_lock();

			return array(
				'estado' => F3Base_Imp_Relatorio::NA,
				'rotulo' => 'encerramento',
				'motivo' => sprintf(
					/* translators: 1: modo, 2: diagnóstico por escopo. */
					__( 'modo %1$s: nada foi gravado e a versão da release NÃO é carimbada. %2$s', 'f3base' ),
					$modo,
					$diagnostico
				),
			);
		}

		$estado = self::SUCESSO;

		if ( $checagens_falha > 0 ) {
			$estado = self::FALHA_PARCIAL;
		}

		if ( $checagens_falha > 0 && 0 === F3Base_Imp_Relatorio::contagem()[ F3Base_Imp_Relatorio::OK ] ) {
			$estado = self::FALHA;
		}

		self::definir_estado( $estado );

		/*
		 * O carimbo de versão aplicada avança APENAS em SUCESSO_APLICACAO. Um
		 * BLOCKED que não tocou em nada não mudou o site, e gravar a versão ali
		 * faria o contrato de caminho validar como homologada uma rota nunca
		 * exercitada.
		 */
		if ( self::SUCESSO === $estado ) {
			F3Base_Imp_Gravador::gravar( self::OPTION_RELEASE, (string) F3Base_Imp_Config::obter( 'release.identidade', '' ) );
		}

		/*
		 * O mapa é montado por NOME declarado, não por prefixo: são os dois
		 * gates — aplicação e fase — que precisam chegar separados a quem
		 * decide. Ler por prefixo `entrega.` era o que fundia os dois.
		 */
		$entregaveis = array();
		$do_gate     = array_merge(
			F3Base_Imp_Entrega::entregaveis_do_gate_de_aplicacao(),
			F3Base_Imp_Entrega::gates_de_fase()
		);

		foreach ( F3Base_Imp_Relatorio::linhas() as $linha ) {
			$nome = (string) $linha['nome'];

			if ( in_array( $nome, $do_gate, true ) ) {
				$entregaveis[ $nome ] = (string) $linha['estado'];
			}
		}

		/*
		 * OS VEREDITOS DE CANAL SÃO LIDOS DO REGISTRO DA EXECUÇÃO, gravado pela
		 * unidade que os mediu. Este bloco não recalcula nenhum: era a segunda
		 * implementação do mesmo veredito, aqui, que fazia o encerramento
		 * contradizer a linha que a unidade `mcp` já tinha emitido no mesmo
		 * relatório.
		 */
		foreach ( F3Base_Imp_Entrega::gates_do_canal() as $gate ) {
			$entregaveis[ $gate ] = F3Base_Imp_Entrega::veredito_registrado( $gate )['estado'];
		}

		$decisao = F3Base_Imp_Entrega::pode_autodesativar( $estado, $entregaveis );

		F3Base_Imp_Relatorio::avaliar(
			$decisao['pode'],
			'entrega.autodesativacao',
			$decisao['motivo'],
			$decisao['motivo'],
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
				'gate'      => 'aplicacao',
			)
		);

		/*
		 * O TERCEIRO EIXO SAI COMO LINHA PRÓPRIA, e com gate de FASE: ele não
		 * decide a autodesativação, e é essa a discordância registrada com a
		 * auditoria. Dar a ele gate de aplicação promoveria a unidade de
		 * encerramento a BLOCKED e voltaria a fundir as duas perguntas — "o
		 * implantador terminou" e "o site está completo" — que esta release
		 * separou. Ele é medido, nomeado e impresso como qualquer outra linha.
		 */
		$convergencia = self::veredito_de_convergencia( F3Base_Imp_Relatorio::linhas() );

		F3Base_Imp_Relatorio::emitir(
			self::CONVERGIU === $convergencia['estado']
				? F3Base_Imp_Relatorio::OK
				: ( self::NAO_CONVERGIU === $convergencia['estado'] ? F3Base_Imp_Relatorio::FALHA : F3Base_Imp_Relatorio::BLOCKED ),
			'entrega.convergencia',
			$convergencia['motivo'],
			array(
				'evidencia' => self::CONVERGIU === $convergencia['estado'] ? 'leitura-de-volta' : 'pendencia-externa',
				'fase'      => 'producao',
				'gate'      => 'fase',
			)
		);

		F3Base_Imp_Relatorio::persistir(
			array(
				'estado_final'    => $estado,
				'convergencia'    => $convergencia['estado'],
				'autodesativacao' => $decisao['pode'],
			)
		);

		self::liberar_lock();

		if ( $decisao['pode'] ) {
			deactivate_plugins( array( plugin_basename( F3BASE_IMP_ARQUIVO ) ), true );
		}

		return array(
			'estado' => self::SUCESSO === $estado ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => 'encerramento',
			'motivo' => sprintf(
				/* translators: 1: estado da máquina, 2: eixo da convergência, 3: diagnóstico por escopo, 4: decisão de autodesativação, 5: texto do estado. */
				__( 'estado da aplicação: %1$s. %2$s %3$s %4$s %5$s', 'f3base' ),
				$estado,
				$convergencia['motivo'],
				$diagnostico,
				$decisao['motivo'],
				self::texto_de_encerramento( $estado, (bool) $decisao['pode'], $convergencia )
			),
		);
	}

	/**
	 * VEREDITO PURO do terceiro eixo, com piso: a convergência do estado.
	 *
	 * Recebe as LINHAS da execução e olha só o metadado `precondicao`. A regra:
	 *
	 * - Pré-condição declarada em FALHA → **não convergiu**: o dado foi
	 *   preenchido e o estado medido continua errado.
	 * - Pré-condição declarada em BLOCKED → **pendente**: falta o dado, e ele é
	 *   do operador.
	 * - Nenhuma das duas → **convergiu**.
	 *
	 * WARN de pré-condição não move o eixo: WARN não é ausência de dado.
	 *
	 * @param array<int,array<string,mixed>> $linhas Linhas emitidas nesta execução.
	 * @return array{estado:string,pendentes:array<int,string>,divergentes:array<int,string>,motivo:string}
	 */
	public static function veredito_de_convergencia( array $linhas ): array {
		$pendentes   = array();
		$divergentes = array();

		foreach ( $linhas as $linha ) {
			if ( true !== ( $linha['precondicao'] ?? false ) ) {
				continue;
			}

			$nome   = (string) ( $linha['nome'] ?? '' );
			$estado = (string) ( $linha['estado'] ?? '' );

			if ( '' === $nome ) {
				continue;
			}

			if ( F3Base_Imp_Relatorio::FALHA === $estado && ! in_array( $nome, $divergentes, true ) ) {
				$divergentes[] = $nome;
				continue;
			}

			if ( F3Base_Imp_Relatorio::BLOCKED === $estado && ! in_array( $nome, $pendentes, true ) ) {
				$pendentes[] = $nome;
			}
		}

		if ( array() !== $divergentes ) {
			return array(
				'estado'      => self::NAO_CONVERGIU,
				'pendentes'   => $pendentes,
				'divergentes' => $divergentes,
				'motivo'      => sprintf(
					/* translators: 1: pré-condições em FALHA, pelo nome, 2: pré-condições em BLOCKED, pelo nome. */
					__( 'convergência: NÃO CONVERGIU. Pré-condição declarada em FALHA: %1$s — o dado foi preenchido e o estado medido continua errado, e a linha de cada uma diz o que ela mediu. Ainda pendentes por falta de dado: %2$s. Como sair: corrija o que a linha nomeia e execute de novo; a execução seguinte reavalia sem repetir o que já foi aplicado.', 'f3base' ),
					implode( ', ', $divergentes ),
					array() === $pendentes ? __( 'nenhuma', 'f3base' ) : implode( ', ', $pendentes )
				),
			);
		}

		if ( array() !== $pendentes ) {
			return array(
				'estado'      => self::CONVERGENCIA_PENDENTE,
				'pendentes'   => $pendentes,
				'divergentes' => array(),
				'motivo'      => sprintf(
					/* translators: %s: pré-condições em BLOCKED, pelo nome. */
					__( 'convergência: PENDENTE. Falta dado que só o operador tem, e a execução terminou sem ele: %s. Como sair: preencha o que a linha de cada uma nomeia em config/site.json e execute de novo — nada disso exige passo manual no wp-admin, e a execução seguinte publica o que estiver esperando. A aplicação terminou; o estado não convergiu, e são duas perguntas diferentes.', 'f3base' ),
					implode( ', ', $pendentes )
				),
			);
		}

		return array(
			'estado'      => self::CONVERGIU,
			'pendentes'   => array(),
			'divergentes' => array(),
			'motivo'      => __( 'convergência: CONVERGIU. Nenhuma pré-condição declarada ficou em BLOCKED nem em FALHA nesta execução: todo dado que só o operador tem está preenchido e o estado medido bate com ele.', 'f3base' ),
		);
	}

	/**
	 * O parágrafo final do encerramento, CONDICIONAL AO ESTADO.
	 *
	 * O defeito medido na 1.0.10: a execução fechou em SUCESSO_APLICACAO, com
	 * zero FALHA, e a última frase do log foi "Em falha o implantador permanece
	 * ativo, preserva o log e oferece retomada idempotente e rollback das
	 * mutações reversíveis." — o parágrafo do ramo de FALHA impresso no ramo de
	 * SUCESSO. Ele não estava errado sobre o produto; estava errado sobre o que
	 * tinha acabado de acontecer, que é a única coisa que a linha de
	 * encerramento tem para dizer.
	 *
	 * No sucesso o texto diz o que DE FATO aconteceu — inclusive se o
	 * implantador se autodesativou — e para onde o operador vai a partir de
	 * agora: a tela do site-core e o canal MCP. Na falha, o texto da falha.
	 *
	 * @param string                                                                                    $estado        Estado da máquina.
	 * @param bool                                                                                      $autodesativou A autodesativação foi executada.
	 * @param array{estado:string,pendentes:array<int,string>,divergentes:array<int,string>,motivo:string} $convergencia  Veredito do terceiro eixo.
	 * @return string
	 */
	public static function texto_de_encerramento( string $estado, bool $autodesativou, array $convergencia = array() ): string {
		/*
		 * A FRASE DA CONVERGÊNCIA VEM JUNTO, e diz o que falta e como sair. Sem
		 * ela, o encerramento de uma execução com a política em rascunho e o CTA
		 * em degradado terminava dizendo só "a aplicação terminou" — verdadeiro
		 * sobre o implantador e mudo sobre o site.
		 */
		$estado_da_convergencia = (string) ( $convergencia['estado'] ?? self::CONVERGIU );
		$pendentes              = (array) ( $convergencia['pendentes'] ?? array() );
		$divergentes            = (array) ( $convergencia['divergentes'] ?? array() );

		if ( self::CONVERGENCIA_PENDENTE === $estado_da_convergencia ) {
			$frase = sprintf(
				/* translators: %s: pré-condições pendentes, pelo nome. */
				__( ' CONVERGÊNCIA PENDENTE: o site ainda não está completo porque falta dado que só o operador tem — %s. Preencha em config/site.json o que a linha de cada uma nomeia e execute de novo; nada disso pede passo manual no wp-admin. A autodesativação NÃO espera por isso, e é decisão: ela é sobre o ciclo do implantador ter terminado, não sobre o site estar completo, e segurar a ferramenta por dado que só o operador tem seria prender o pacote a uma espera indefinida.', 'f3base' ),
				implode( ', ', $pendentes )
			);
		} elseif ( self::NAO_CONVERGIU === $estado_da_convergencia ) {
			$frase = sprintf(
				/* translators: %s: pré-condições em FALHA, pelo nome. */
				__( ' O ESTADO NÃO CONVERGIU: pré-condição declarada em FALHA — %s. O dado está preenchido e o que foi medido continua errado; a linha de cada uma diz o que ela mediu e onde. Corrija e execute de novo.', 'f3base' ),
				implode( ', ', $divergentes )
			);
		} else {
			$frase = __( ' CONVERGÊNCIA: o estado convergiu — nenhuma pré-condição declarada ficou pendente nem divergente nesta execução.', 'f3base' );
		}

		if ( self::SUCESSO !== $estado ) {
			return __( 'O implantador PERMANECE ATIVO: preserva o log, oferece retomada idempotente a partir do checkpoint e rollback das mutações reversíveis pelo journal. Corrija o que está nomeado acima e execute de novo — a retomada não repete o que já foi aplicado.', 'f3base' ) . $frase;
		}

		if ( $autodesativou ) {
			return __( 'A aplicação terminou e o implantador SE AUTODESATIVOU: ele não roda mais, e reativá-lo pela tela de plugins é o que o traz de volta se houver o que reaplicar. O log desta execução fica preservado. Daqui em diante a operação do site é pela tela do site-core (estado dos módulos, options operáveis e atividade) e pelo canal MCP, que é por onde a manutenção acontece sem passo manual no wp-admin.', 'f3base' ) . $frase;
		}

		return __( 'A aplicação terminou em sucesso e o implantador CONTINUA ATIVO — a autodesativação foi recusada pelo motivo nomeado acima, e não por falha da aplicação. O log fica preservado. A operação do site já é pela tela do site-core e pelo canal MCP; resolva o que segurou a autodesativação e execute de novo para que o implantador saia de cena.', 'f3base' ) . $frase;
	}

	/* ------------------------------------------------------------------ *
	 * Lock, checkpoint e estado
	 * ------------------------------------------------------------------ */

	/**
	 * Instante em que um lock passa a ser considerado ABANDONADO.
	 *
	 * A tomada automática acontece quando `agora - heartbeat > TTL`; o primeiro
	 * segundo em que isso é verdade é `heartbeat + TTL + 1`. O número existe
	 * porque o operador precisa saber QUANTO ESPERAR — dizer só "TTL 90s" o
	 * deixa contando de cabeça a partir de um heartbeat que ele não viu.
	 *
	 * @param int $heartbeat Epoch do último heartbeat.
	 * @return int Epoch a partir do qual o lock é assumível.
	 */
	public static function lock_abandonado_em( int $heartbeat ): int {
		return $heartbeat + self::LOCK_TTL + 1;
	}

	/**
	 * Adquire ou renova o lock com heartbeat e fencing token.
	 *
	 * A rejeição devolve os FATOS, não só a frase: dono, idade do heartbeat, TTL
	 * e o instante em que o lock passa a ser assumível. Quem os imprime é a
	 * resposta do lote e o cliente, cada um uma vez — a 1.0.15 mandava só a
	 * frase, o cliente tratava a rejeição como se fosse resultado de unidade e
	 * repetia a MESMA linha 163 vezes até o TTL vencer.
	 *
	 * @param string $execucao Identificador da execução.
	 * @return array{ok:bool,motivo:string,fencing:int,dono:string,heartbeat:int,idade:int,ttl:int,abandonado_em:int}
	 */
	public static function adquirir_lock( string $execucao ): array {
		$agora = time();
		$atual = get_option( self::OPTION_LOCK, null );

		$adquirido = array(
			'ok'            => true,
			'motivo'        => '',
			'fencing'       => 0,
			'dono'          => $execucao,
			'heartbeat'     => $agora,
			'idade'         => 0,
			'ttl'           => self::LOCK_TTL,
			'abandonado_em' => self::lock_abandonado_em( $agora ),
		);

		if ( ! is_array( $atual ) ) {
			$novo = array(
				'execucao'  => $execucao,
				'fencing'   => 1,
				'heartbeat' => $agora,
			);

			if ( F3Base_Imp_Gravador::criar_atomico( self::OPTION_LOCK, $novo ) ) {
				return array_merge( $adquirido, array( 'fencing' => 1 ) );
			}

			$atual = get_option( self::OPTION_LOCK, null );
		}

		if ( ! is_array( $atual ) ) {
			return array(
				'ok'            => false,
				'motivo'        => __( 'não foi possível ler nem criar o lock da execução.', 'f3base' ),
				'fencing'       => 0,
				'dono'          => '',
				'heartbeat'     => 0,
				'idade'         => 0,
				'ttl'           => self::LOCK_TTL,
				'abandonado_em' => 0,
			);
		}

		$dono      = isset( $atual['execucao'] ) ? (string) $atual['execucao'] : '';
		$fencing   = isset( $atual['fencing'] ) ? (int) $atual['fencing'] : 0;
		$heartbeat = isset( $atual['heartbeat'] ) ? (int) $atual['heartbeat'] : 0;

		if ( $dono === $execucao ) {
			$renovado = $atual;
			$renovado['heartbeat'] = $agora;

			/* Renovação ATÔMICA: condicional ao valor observado, não ao tempo. */
			F3Base_Imp_Gravador::trocar_atomico( self::OPTION_LOCK, $atual, $renovado );

			return array_merge( $adquirido, array( 'fencing' => $fencing ) );
		}

		if ( $agora - $heartbeat > self::LOCK_TTL ) {
			$tomado = array(
				'execucao'  => $execucao,
				'fencing'   => $fencing + 1,
				'heartbeat' => $agora,
			);

			if ( F3Base_Imp_Gravador::trocar_atomico( self::OPTION_LOCK, $atual, $tomado ) ) {
				return array_merge( $adquirido, array( 'fencing' => $fencing + 1 ) );
			}
		}

		return array(
			'ok'            => false,
			'motivo'        => sprintf(
				/* translators: 1: execução dona do lock, 2: segundos desde o último heartbeat, 3: TTL, 4: horário em que o lock passa a ser assumível. */
				__( 'execução concorrente rejeitada: o lock pertence a %1$s, com heartbeat há %2$d segundos (TTL %3$ds). Este lote NÃO rodou e nada foi medido. O lock passa a ser considerado abandonado às %4$s: a partir daí basta executar de novo, e a tomada é automática — não há passo manual. Duas execuções simultâneas gravariam por cima uma da outra.', 'f3base' ),
				$dono,
				$agora - $heartbeat,
				self::LOCK_TTL,
				wp_date( 'Y-m-d H:i:s', self::lock_abandonado_em( $heartbeat ) )
			),
			'fencing'       => $fencing,
			'dono'          => $dono,
			'heartbeat'     => $heartbeat,
			'idade'         => $agora - $heartbeat,
			'ttl'           => self::LOCK_TTL,
			'abandonado_em' => self::lock_abandonado_em( $heartbeat ),
		);
	}

	/**
	 * Libera o lock desta execução.
	 *
	 * @return void
	 */
	public static function liberar_lock(): void {
		F3Base_Imp_Gravador::remover_infra( self::OPTION_LOCK );
	}

	/**
	 * Confere se a retomada é legítima.
	 *
	 * @param string $execucao Execução.
	 * @param int    $indice   Índice pedido.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function conferir_retomada( string $execucao, int $indice ): array {
		$checkpoint = get_option( self::OPTION_CHECKPOINT, null );

		if ( ! is_array( $checkpoint ) || 0 === $indice ) {
			return array(
				'ok'     => true,
				'motivo' => '',
			);
		}

		$release_atual = (string) F3Base_Imp_Config::obter( 'release.identidade', '' );
		$hash_atual    = F3Base_Imp_Config::hash();

		$release_ck = isset( $checkpoint['release'] ) ? (string) $checkpoint['release'] : '';
		$hash_ck    = isset( $checkpoint['config_hash'] ) ? (string) $checkpoint['config_hash'] : '';

		if ( $release_ck !== $release_atual || $hash_ck !== $hash_atual ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: 1: release do checkpoint, 2: release atual, 3: hash do checkpoint, 4: hash atual. */
					__( 'retomada recusada: o checkpoint é da release %1$s com config %3$s e esta execução é da release %2$s com config %4$s. Retomada só com a mesma release e o mesmo hash de configuração — divergiu, é rollback ou abandono explícito.', 'f3base' ),
					$release_ck,
					$release_atual,
					substr( $hash_ck, 0, 12 ),
					substr( $hash_atual, 0, 12 )
				),
			);
		}

		$execucao_ck = isset( $checkpoint['execucao'] ) ? (string) $checkpoint['execucao'] : '';
		$fencing_ck  = isset( $checkpoint['fencing'] ) ? (int) $checkpoint['fencing'] : 0;
		$lock        = get_option( self::OPTION_LOCK, array() );
		$fencing_ok  = is_array( $lock ) && isset( $lock['fencing'] ) ? (int) $lock['fencing'] : 0;

		if ( $execucao_ck === $execucao && $fencing_ck > $fencing_ok ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: 1: fencing do checkpoint, 2: fencing do lock. */
					__( 'fencing token vencido: o checkpoint traz %1$d e o lock vigente traz %2$d. Esta execução acordou depois de outra ter assumido, e escrever agora seria gravar por cima do trabalho novo.', 'f3base' ),
					$fencing_ck,
					$fencing_ok
				),
			);
		}

		return array(
			'ok'     => true,
			'motivo' => '',
		);
	}

	/**
	 * Grava o checkpoint DEPOIS da leitura de volta da unidade.
	 *
	 * @param string $execucao Execução.
	 * @param string $modo     Modo.
	 * @param string $etapa    Etapa.
	 * @param int    $indice   Índice da unidade concluída.
	 * @param string $estado   Estado da unidade.
	 * @return bool
	 */
	private static function gravar_checkpoint( string $execucao, string $modo, string $etapa, int $indice, string $estado ): bool {
		$lock    = get_option( self::OPTION_LOCK, array() );
		$fencing = is_array( $lock ) && isset( $lock['fencing'] ) ? (int) $lock['fencing'] : 0;

		F3Base_Imp_Gravador::persistir_infra(
			self::OPTION_CHECKPOINT,
			array(
				'execucao'    => $execucao,
				'release'     => (string) F3Base_Imp_Config::obter( 'release.identidade', '' ),
				'config_hash' => F3Base_Imp_Config::hash(),
				'modo'        => $modo,
				'etapa'       => $etapa,
				'unidade'     => $indice,
				'estado'      => $estado,
				'fencing'     => $fencing,
				'em'          => time(),
			)
		);

		$lido = get_option( self::OPTION_CHECKPOINT, array() );

		return is_array( $lido ) && isset( $lido['unidade'] ) && (int) $lido['unidade'] === $indice;
	}

	/**
	 * Define o estado da máquina de aplicação.
	 *
	 * @param string $estado Estado.
	 * @return void
	 */
	public static function definir_estado( string $estado ): void {
		if ( ! in_array( $estado, self::estados(), true ) ) {
			return;
		}

		F3Base_Imp_Gravador::persistir_infra( self::OPTION_ESTADO, $estado );
	}

	/**
	 * Reverte as mutações reversíveis desta execução.
	 *
	 * @return array<string,mixed>
	 */
	public static function reverter(): array {
		$resultado = F3Base_Imp_Journal::reverter();

		self::definir_estado( self::REVERTIDO );

		F3Base_Imp_Relatorio::emitir(
			array() === $resultado['falhas'] ? F3Base_Imp_Relatorio::OK : F3Base_Imp_Relatorio::FALHA,
			'rollback.journal',
			sprintf(
				/* translators: 1: quantidade revertida, 2: falhas, 3: irreversíveis declarados. */
				__( '%1$d mutação(ões) revertidas pelo journal. Falhas de reversão: %2$s. Fora da promessa de rollback, por declaração: %3$s.', 'f3base' ),
				(int) $resultado['revertidas'],
				array() === $resultado['falhas'] ? __( 'nenhuma', 'f3base' ) : implode( ' | ', $resultado['falhas'] ),
				array() === $resultado['irreversiveis'] ? __( 'nenhuma', 'f3base' ) : implode( ' | ', $resultado['irreversiveis'] )
			),
			array(
				'evidencia' => 'leitura-de-volta',
				'fase'      => 'local',
			)
		);

		F3Base_Imp_Relatorio::persistir();

		return $resultado;
	}

	/* ------------------------------------------------------------------ *
	 * Resposta do endpoint
	 * ------------------------------------------------------------------ */

	/**
	 * Normaliza o retorno de uma classe de aplicação.
	 *
	 * @param array<string,mixed> $resultado Resultado.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function normalizar( array $resultado ): array {
		return array(
			'estado' => isset( $resultado['estado'] ) ? (string) $resultado['estado'] : F3Base_Imp_Relatorio::FALHA,
			'rotulo' => isset( $resultado['rotulo'] ) ? (string) $resultado['rotulo'] : 'lote',
			'motivo' => isset( $resultado['motivo'] ) ? (string) $resultado['motivo'] : '',
		);
	}

	/**
	 * Executa uma etapa de SEO com o gate estrutural do plugin.
	 *
	 * Pré-condição ausente é BLOCKED, nunca FALHA: relatório que grita FALHA por
	 * ausência de terceiro treina o leitor a ignorar FALHA.
	 *
	 * @param string   $rotulo   Nome da checagem.
	 * @param callable $callback Etapa.
	 * @return array{estado:string,rotulo:string,motivo:string}
	 */
	private static function com_plugin_de_seo( string $rotulo, callable $callback ): array {
		if ( ! F3Base_Imp_Seo::plugin_ativo() ) {
			return array(
				'estado' => F3Base_Imp_Relatorio::BLOCKED,
				'rotulo' => $rotulo,
				'motivo' => sprintf(
					/* translators: %s: slug do plugin. */
					__( 'pré-condição ausente: o plugin %s não está ativo, e as options que esta etapa grava são dele. BLOCKED, nunca FALHA.', 'f3base' ),
					F3Base_Imp_Seo::SLUG
				),
			);
		}

		return self::normalizar( (array) call_user_func( $callback ) );
	}

	/**
	 * Rede de fatal: responde JSON no fim do corpo mesmo depois do erro do core.
	 *
	 * @return void
	 */
	public static function rede_de_fatal(): void {
		$erro = error_get_last();

		if ( null === $erro || ! in_array( (int) $erro['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ), true ) ) {
			return;
		}

		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		$carga = array(
			'ok'     => false,
			'estado' => F3Base_Imp_Relatorio::FALHA,
			'fatal'  => array(
				'tipo'     => (int) $erro['type'],
				'mensagem' => (string) $erro['message'],
				'arquivo'  => (string) $erro['file'],
				'linha'    => (int) $erro['line'],
			),
			'limites' => array(
				'memory_limit'       => (string) ini_get( 'memory_limit' ),
				'max_execution_time' => (string) ini_get( 'max_execution_time' ),
				'memoria_pico'       => memory_get_peak_usage( true ),
			),
			'motivo' => __( 'erro fatal durante o lote. O log da execução foi preservado e a retomada continua do último checkpoint válido.', 'f3base' ),
		);

		$json = wp_json_encode( $carga );

		echo "\n" . self::SENTINELA . "\n" . ( is_string( $json ) ? $json : '{}' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON serializado, com Content-Type próprio.
	}

	/**
	 * Responde JSON e encerra.
	 *
	 * `wp_send_json()` NÃO limpa o buffer: qualquer saída inesperada iria junto
	 * no corpo. Aqui o buffer é capturado, mandado ao log e descartado — e o
	 * JSON sai no FIM, precedido da sentinela.
	 *
	 * @param array<string,mixed> $carga  Carga.
	 * @param int                 $codigo Código HTTP.
	 * @return void
	 */
	private static function responder( array $carga, int $codigo = 200 ): void {
		$ruido = '';

		while ( ob_get_level() > 0 ) {
			$ruido .= (string) ob_get_clean();
		}

		if ( '' !== trim( $ruido ) ) {
			$carga['ruido_bytes'] = strlen( $ruido );
			error_log( '[f3base-implantador] saída inesperada no lote: ' . substr( $ruido, 0, 2000 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- ruído vai ao log, nunca ao corpo.
		}

		if ( ! headers_sent() ) {
			status_header( $codigo );
			header( 'Content-Type: application/json; charset=utf-8' );
			nocache_headers();
		}

		$json = wp_json_encode( $carga );

		echo self::SENTINELA . "\n" . ( is_string( $json ) ? $json : '{}' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON serializado, com Content-Type próprio.

		exit;
	}
}
