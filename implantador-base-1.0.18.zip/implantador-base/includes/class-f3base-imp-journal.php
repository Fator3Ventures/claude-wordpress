<?php
/**
 * Journal de mutações com preimagem, pós-imagem e operação inversa.
 *
 * Cada mutação gerenciada entra aqui ANTES de acontecer, com o estado anterior
 * (preimagem), o estado pretendido (pós-imagem) e o descritor da operação que a
 * desfaz. O descritor é declarativo — nunca um closure —, porque a reversão pode
 * acontecer em outra requisição, depois de um fatal, lida do banco.
 *
 * Rollback que restaura duas de dez mutações não é rollback: é relatório
 * otimista. Por isso o journal cobre as dez famílias que este implantador
 * escreve — posts, metas, termos, relações, navegação, overrides FSE, cron,
 * options, arquivos e referências de mídia — e por isso o gravador único
 * escreve DENTRO dele, inclusive as options de terceiro.
 *
 * Ação irreversível não vira promessa: é declarada com o motivo e fica FORA da
 * promessa de rollback, listada no relatório com esse nome.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Journal das mutações da execução.
 */
final class F3Base_Imp_Journal {

	/**
	 * Option onde o journal persiste.
	 */
	public const OPTION = 'f3base_journal';

	/**
	 * Famílias de mutação cobertas.
	 */
	public const TIPO_POST         = 'post';
	public const TIPO_META         = 'meta';
	public const TIPO_TERMO        = 'termo';
	public const TIPO_RELACAO      = 'relacao';
	public const TIPO_NAVEGACAO    = 'navegacao';
	public const TIPO_OVERRIDE_FSE = 'override_fse';
	public const TIPO_CRON         = 'cron';
	public const TIPO_OPTION       = 'option';
	public const TIPO_ARQUIVO      = 'arquivo';
	public const TIPO_MIDIA_REF    = 'midia_ref';

	/**
	 * Entradas carregadas (memoizadas por requisição).
	 *
	 * @var array<int,array<string,mixed>>|null
	 */
	private static ?array $entradas = null;

	/**
	 * Identificador da execução corrente.
	 *
	 * @var string
	 */
	private static string $execucao = '';

	/**
	 * Etapa corrente, carimbada em cada entrada.
	 *
	 * @var string
	 */
	private static string $etapa = '';

	/**
	 * Famílias declaradas do journal.
	 *
	 * @return string[]
	 */
	public static function tipos(): array {
		return array(
			self::TIPO_POST,
			self::TIPO_META,
			self::TIPO_TERMO,
			self::TIPO_RELACAO,
			self::TIPO_NAVEGACAO,
			self::TIPO_OVERRIDE_FSE,
			self::TIPO_CRON,
			self::TIPO_OPTION,
			self::TIPO_ARQUIVO,
			self::TIPO_MIDIA_REF,
		);
	}

	/**
	 * Abre o journal para uma execução.
	 *
	 * Execução nova zera as entradas: o journal responde por UMA aplicação, e
	 * misturar duas execuções produziria uma reversão que atravessa o checkpoint.
	 *
	 * @param string $execucao Identificador da execução.
	 * @return void
	 */
	public static function iniciar( string $execucao ): void {
		self::$execucao = sanitize_key( $execucao );
		self::carregar();

		$anterior = self::$entradas[0]['execucao'] ?? '';

		if ( '' !== $anterior && $anterior !== self::$execucao ) {
			self::$entradas = array();
			self::persistir();
		}
	}

	/**
	 * Carimba a etapa corrente.
	 *
	 * @param string $etapa Identificador da etapa.
	 * @return void
	 */
	public static function etapa( string $etapa ): void {
		self::$etapa = sanitize_key( $etapa );
	}

	/**
	 * Registra uma mutação.
	 *
	 * @param string              $tipo      Família da mutação.
	 * @param string              $alvo      Identificação legível do alvo.
	 * @param mixed               $preimagem Estado anterior.
	 * @param mixed               $posimagem Estado pretendido.
	 * @param array<string,mixed> $inversa   Descritor declarativo da operação inversa.
	 * @param array<string,mixed> $extra     Campos adicionais (reversivel, motivo, plugin).
	 * @return string Identificador da entrada.
	 */
	public static function registrar( string $tipo, string $alvo, $preimagem, $posimagem, array $inversa, array $extra = array() ): string {
		self::carregar();

		$reversivel = array_key_exists( 'reversivel', $extra ) ? (bool) $extra['reversivel'] : ( array() !== $inversa );
		$id         = self::$execucao . '-' . str_pad( (string) ( count( self::$entradas ) + 1 ), 4, '0', STR_PAD_LEFT );

		$entrada = array(
			'id'         => $id,
			'execucao'   => self::$execucao,
			'etapa'      => self::$etapa,
			'tipo'       => in_array( $tipo, self::tipos(), true ) ? $tipo : self::TIPO_OPTION,
			'alvo'       => sanitize_text_field( $alvo ),
			'preimagem'  => $preimagem,
			'posimagem'  => $posimagem,
			'inversa'    => $reversivel ? $inversa : array(),
			'reversivel' => $reversivel,
			'motivo'     => isset( $extra['motivo'] ) ? sanitize_text_field( (string) $extra['motivo'] ) : '',
			'plugin'     => isset( $extra['plugin'] ) ? sanitize_key( (string) $extra['plugin'] ) : '',
			'em'         => time(),
			'revertida'  => false,
		);

		self::$entradas[] = $entrada;
		self::persistir();

		return $id;
	}

	/**
	 * Todas as entradas do journal.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function entradas(): array {
		self::carregar();

		return self::$entradas;
	}

	/**
	 * Entradas declaradas irreversíveis, com o motivo.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function irreversiveis(): array {
		self::carregar();

		return array_values(
			array_filter(
				self::$entradas,
				static fn ( array $entrada ): bool => empty( $entrada['reversivel'] )
			)
		);
	}

	/**
	 * Contagem por família, para o relatório.
	 *
	 * @return array<string,int>
	 */
	public static function resumo(): array {
		self::carregar();

		$resumo = array();

		foreach ( self::tipos() as $tipo ) {
			$resumo[ $tipo ] = 0;
		}

		foreach ( self::$entradas as $entrada ) {
			$tipo = (string) $entrada['tipo'];

			if ( isset( $resumo[ $tipo ] ) ) {
				++$resumo[ $tipo ];
			}
		}

		return $resumo;
	}

	/**
	 * Reverte uma entrada específica pelo identificador.
	 *
	 * @param string $id Identificador da entrada.
	 * @return array{ok:bool,motivo:string}
	 */
	public static function reverter_entrada( string $id ): array {
		self::carregar();

		foreach ( self::$entradas as $indice => $entrada ) {
			if ( (string) $entrada['id'] !== $id ) {
				continue;
			}

			$resultado = self::aplicar_inversa( $entrada );

			if ( $resultado['ok'] ) {
				self::$entradas[ $indice ]['revertida'] = true;
				self::persistir();
			}

			return $resultado;
		}

		return array(
			'ok'     => false,
			'motivo' => sprintf(
				/* translators: %s: identificador da entrada. */
				__( 'Entrada de journal inexistente: %s', 'f3base' ),
				$id
			),
		);
	}

	/**
	 * Reverte todas as mutações reversíveis, na ordem inversa.
	 *
	 * @return array{revertidas:int,falhas:string[],irreversiveis:string[]}
	 */
	public static function reverter(): array {
		self::carregar();

		$revertidas    = 0;
		$falhas        = array();
		$irreversiveis = array();

		for ( $indice = count( self::$entradas ) - 1; $indice >= 0; $indice-- ) {
			$entrada = self::$entradas[ $indice ];

			if ( ! empty( $entrada['revertida'] ) ) {
				continue;
			}

			if ( empty( $entrada['reversivel'] ) ) {
				$irreversiveis[] = sprintf(
					/* translators: 1: alvo da mutação, 2: motivo declarado. */
					__( '%1$s — %2$s', 'f3base' ),
					(string) $entrada['alvo'],
					'' !== (string) $entrada['motivo'] ? (string) $entrada['motivo'] : __( 'ação declarada irreversível', 'f3base' )
				);
				continue;
			}

			$resultado = self::aplicar_inversa( $entrada );

			if ( $resultado['ok'] ) {
				self::$entradas[ $indice ]['revertida'] = true;
				++$revertidas;
			} else {
				$falhas[] = sprintf(
					/* translators: 1: alvo da mutação, 2: motivo da falha. */
					__( '%1$s — %2$s', 'f3base' ),
					(string) $entrada['alvo'],
					$resultado['motivo']
				);
			}
		}

		self::persistir();

		return array(
			'revertidas'    => $revertidas,
			'falhas'        => $falhas,
			'irreversiveis' => $irreversiveis,
		);
	}

	/**
	 * Executa o descritor da operação inversa.
	 *
	 * Lista fechada de AÇÕES do próprio journal — não de valores que a
	 * configuração declara. Ação desconhecida devolve falha nomeada em vez de
	 * silêncio, que é o modo de falha caro de um rollback.
	 *
	 * @param array<string,mixed> $entrada Entrada do journal.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function aplicar_inversa( array $entrada ): array {
		$inversa = isset( $entrada['inversa'] ) && is_array( $entrada['inversa'] ) ? $entrada['inversa'] : array();
		$acao    = isset( $inversa['acao'] ) ? (string) $inversa['acao'] : '';

		if ( '' === $acao ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'entrada sem descritor de operação inversa.', 'f3base' ),
			);
		}

		$nome = isset( $inversa['nome'] ) ? (string) $inversa['nome'] : '';

		switch ( $acao ) {
			case 'option.restaurar':
				if ( '' === $nome ) {
					return array(
						'ok'     => false,
						'motivo' => __( 'descritor de option sem nome.', 'f3base' ),
					);
				}

				$valor = $inversa['valor'] ?? null;

				F3Base_Imp_Gravador::persistir_infra( $nome, $valor );

				return self::conferido( $nome, get_option( $nome, null ), $valor );

			case 'option.remover':
				if ( '' === $nome ) {
					return array(
						'ok'     => false,
						'motivo' => __( 'descritor de option sem nome.', 'f3base' ),
					);
				}

				F3Base_Imp_Gravador::remover_infra( $nome );

				return self::conferido( $nome, get_option( $nome, null ), null );

			case 'meta.restaurar':
				return self::restaurar_meta( $inversa, false );

			case 'meta.remover':
				return self::restaurar_meta( $inversa, true );

			case 'post.restaurar':
				return self::restaurar_post( $inversa );

			case 'post.excluir':
				$id = isset( $inversa['id'] ) ? (int) $inversa['id'] : 0;
				if ( $id <= 0 ) {
					return array(
						'ok'     => false,
						'motivo' => __( 'identificador de post ausente no descritor.', 'f3base' ),
					);
				}
				wp_delete_post( $id, true );
				return array(
					'ok'     => null === get_post( $id ),
					'motivo' => null === get_post( $id ) ? '' : __( 'o post continua existindo após a exclusão.', 'f3base' ),
				);

			case 'termo.restaurar':
				return self::restaurar_termo( $inversa );

			case 'termo.excluir':
				$id         = isset( $inversa['id'] ) ? (int) $inversa['id'] : 0;
				$taxonomia  = isset( $inversa['taxonomia'] ) ? (string) $inversa['taxonomia'] : '';
				$eliminado  = ( $id > 0 && '' !== $taxonomia ) ? wp_delete_term( $id, $taxonomia ) : false;
				$sobreviveu = ( true === $eliminado );
				return array(
					'ok'     => $sobreviveu,
					'motivo' => $sobreviveu ? '' : __( 'falha ao excluir o termo criado.', 'f3base' ),
				);

			case 'relacao.restaurar':
				$objeto    = isset( $inversa['objeto_id'] ) ? (int) $inversa['objeto_id'] : 0;
				$taxonomia = isset( $inversa['taxonomia'] ) ? (string) $inversa['taxonomia'] : '';
				$termos    = isset( $inversa['termos'] ) && is_array( $inversa['termos'] ) ? array_map( 'intval', $inversa['termos'] ) : array();
				if ( $objeto <= 0 || '' === $taxonomia ) {
					return array(
						'ok'     => false,
						'motivo' => __( 'descritor de relação incompleto.', 'f3base' ),
					);
				}
				$aplicado = wp_set_object_terms( $objeto, $termos, $taxonomia, false );
				return array(
					'ok'     => ! is_wp_error( $aplicado ),
					'motivo' => is_wp_error( $aplicado ) ? $aplicado->get_error_message() : '',
				);

			case 'cron.desagendar':
				return self::cron_desagendar( $inversa );

			case 'cron.restaurar':
				return self::cron_restaurar( $inversa );

			case 'arquivo.restaurar':
				return self::restaurar_arquivo( $inversa );

			case 'diretorio.renomear':
				return self::renomear_diretorio( $inversa );

			case 'arquivo.remover':
				$caminho = isset( $inversa['caminho'] ) ? (string) $inversa['caminho'] : '';
				if ( '' === $caminho || ! file_exists( $caminho ) ) {
					return array(
						'ok'     => true,
						'motivo' => '',
					);
				}
				wp_delete_file( $caminho );
				return array(
					'ok'     => ! file_exists( $caminho ),
					'motivo' => file_exists( $caminho ) ? __( 'o arquivo continua no disco após a remoção.', 'f3base' ) : '',
				);

			default:
				return array(
					'ok'     => false,
					'motivo' => sprintf(
						/* translators: %s: nome da ação inversa. */
						__( 'operação inversa desconhecida: %s', 'f3base' ),
						$acao
					),
				);
		}
	}

	/**
	 * Restaura ou remove uma meta.
	 *
	 * @param array<string,mixed> $inversa Descritor.
	 * @param bool                $remover Remover em vez de restaurar.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function restaurar_meta( array $inversa, bool $remover ): array {
		$objeto = isset( $inversa['objeto_id'] ) ? (int) $inversa['objeto_id'] : 0;
		$chave  = isset( $inversa['chave'] ) ? (string) $inversa['chave'] : '';
		$tipo   = isset( $inversa['objeto_tipo'] ) ? (string) $inversa['objeto_tipo'] : 'post';

		if ( $objeto <= 0 || '' === $chave ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'descritor de meta incompleto.', 'f3base' ),
			);
		}

		if ( 'term' === $tipo ) {
			if ( $remover ) {
				delete_term_meta( $objeto, $chave );
			} else {
				update_term_meta( $objeto, $chave, $inversa['valor'] );
			}

			$lido = get_term_meta( $objeto, $chave, true );
		} else {
			if ( $remover ) {
				delete_post_meta( $objeto, $chave );
			} else {
				update_post_meta( $objeto, $chave, $inversa['valor'] );
			}

			$lido = get_post_meta( $objeto, $chave, true );
		}

		$esperado = $remover ? '' : ( $inversa['valor'] ?? '' );

		return self::conferido( $chave, $lido, $esperado );
	}

	/**
	 * Restaura os campos de um post pela preimagem.
	 *
	 * @param array<string,mixed> $inversa Descritor.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function restaurar_post( array $inversa ): array {
		$id     = isset( $inversa['id'] ) ? (int) $inversa['id'] : 0;
		$campos = isset( $inversa['campos'] ) && is_array( $inversa['campos'] ) ? $inversa['campos'] : array();

		if ( $id <= 0 || array() === $campos ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'descritor de post incompleto.', 'f3base' ),
			);
		}

		$campos['ID'] = $id;

		$resultado = wp_update_post( wp_slash( $campos ), true );

		return array(
			'ok'     => ! is_wp_error( $resultado ),
			'motivo' => is_wp_error( $resultado ) ? $resultado->get_error_message() : '',
		);
	}

	/**
	 * Restaura os campos de um termo pela preimagem.
	 *
	 * @param array<string,mixed> $inversa Descritor.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function restaurar_termo( array $inversa ): array {
		$id        = isset( $inversa['id'] ) ? (int) $inversa['id'] : 0;
		$taxonomia = isset( $inversa['taxonomia'] ) ? (string) $inversa['taxonomia'] : '';
		$campos    = isset( $inversa['campos'] ) && is_array( $inversa['campos'] ) ? $inversa['campos'] : array();

		if ( $id <= 0 || '' === $taxonomia ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'descritor de termo incompleto.', 'f3base' ),
			);
		}

		$resultado = wp_update_term( $id, $taxonomia, $campos );

		return array(
			'ok'     => ! is_wp_error( $resultado ),
			'motivo' => is_wp_error( $resultado ) ? $resultado->get_error_message() : '',
		);
	}

	/**
	 * Desagenda um evento criado pela implantação.
	 *
	 * @param array<string,mixed> $inversa Descritor.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function cron_desagendar( array $inversa ): array {
		$hook = isset( $inversa['hook'] ) ? (string) $inversa['hook'] : '';
		$args = isset( $inversa['args'] ) && is_array( $inversa['args'] ) ? $inversa['args'] : array();

		if ( '' === $hook ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'descritor de cron sem hook.', 'f3base' ),
			);
		}

		wp_clear_scheduled_hook( $hook, $args );

		$restou = wp_next_scheduled( $hook, $args );

		return array(
			'ok'     => false === $restou,
			'motivo' => false === $restou ? '' : __( 'o evento continua agendado após o desagendamento.', 'f3base' ),
		);
	}

	/**
	 * Reagenda um evento que existia antes da implantação.
	 *
	 * @param array<string,mixed> $inversa Descritor.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function cron_restaurar( array $inversa ): array {
		$hook        = isset( $inversa['hook'] ) ? (string) $inversa['hook'] : '';
		$args        = isset( $inversa['args'] ) && is_array( $inversa['args'] ) ? $inversa['args'] : array();
		$quando      = isset( $inversa['timestamp'] ) ? (int) $inversa['timestamp'] : 0;
		$recorrencia = isset( $inversa['recorrencia'] ) ? (string) $inversa['recorrencia'] : '';

		if ( '' === $hook || $quando <= 0 ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'descritor de cron incompleto.', 'f3base' ),
			);
		}

		wp_clear_scheduled_hook( $hook, $args );

		$agendado = '' !== $recorrencia
			? wp_schedule_event( $quando, $recorrencia, $hook, $args )
			: wp_schedule_single_event( $quando, $hook, $args );

		return array(
			'ok'     => false !== $agendado && ! is_wp_error( $agendado ),
			'motivo' => is_wp_error( $agendado ) ? $agendado->get_error_message() : '',
		);
	}

	/**
	 * Desfaz a renomeação de um diretório, movendo-o de volta.
	 *
	 * Existe porque renomear diretório NÃO é o mesmo caso que `arquivo.restaurar`:
	 * ali a reversão regrava um arquivo a partir de uma cópia de conteúdo; aqui
	 * nenhum byte foi copiado, o diretório inteiro apenas mudou de nome, e a
	 * inversa é a renomeação simétrica. Reaproveitar o descritor de arquivo
	 * deixaria a entrada com `reversivel => true` e uma inversa que não sabe
	 * executar — que é o modo de falha caro de um rollback.
	 *
	 * Recusa sobrescrever: se o destino já existe, a reversão para e diz por quê,
	 * em vez de apagar o que estiver lá.
	 *
	 * @param array<string,mixed> $inversa Descritor com `de` e `para`.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function renomear_diretorio( array $inversa ): array {
		$de   = isset( $inversa['de'] ) ? (string) $inversa['de'] : '';
		$para = isset( $inversa['para'] ) ? (string) $inversa['para'] : '';

		if ( '' === $de || '' === $para ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'descritor de renomeação de diretório sem origem ou sem destino.', 'f3base' ),
			);
		}

		if ( ! is_dir( $de ) ) {
			return array(
				'ok'     => is_dir( $para ),
				'motivo' => is_dir( $para )
					? ''
					: sprintf(
						/* translators: 1: caminho de origem, 2: caminho de destino. */
						__( 'nem %1$s nem %2$s existem no disco: não há diretório para renomear de volta.', 'f3base' ),
						$de,
						$para
					),
			);
		}

		if ( is_dir( $para ) ) {
			return array(
				'ok'     => false,
				'motivo' => sprintf(
					/* translators: %s: caminho de destino. */
					__( 'a reversão pararia sobre %s, que já existe: sobrescrever seria apagar código sem preimagem. Nada foi tocado.', 'f3base' ),
					$para
				),
			);
		}

		global $wp_filesystem;

		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			WP_Filesystem();
		}

		if ( ! $wp_filesystem instanceof WP_Filesystem_Base ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'filesystem do WordPress indisponível: nenhuma renomeação de diretório é segura sem ele.', 'f3base' ),
			);
		}

		$moveu = $wp_filesystem->move( $de, $para, false );

		return array(
			'ok'     => $moveu && is_dir( $para ),
			'motivo' => ( $moveu && is_dir( $para ) )
				? ''
				: sprintf(
					/* translators: 1: caminho de origem, 2: caminho de destino. */
					__( 'falha ao renomear %1$s de volta para %2$s.', 'f3base' ),
					$de,
					$para
				),
		);
	}

	/**
	 * Restaura um arquivo a partir da cópia de preimagem.
	 *
	 * @param array<string,mixed> $inversa Descritor.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function restaurar_arquivo( array $inversa ): array {
		$caminho = isset( $inversa['caminho'] ) ? (string) $inversa['caminho'] : '';
		$backup  = isset( $inversa['backup'] ) ? (string) $inversa['backup'] : '';

		if ( '' === $caminho || '' === $backup || ! is_readable( $backup ) ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'cópia de preimagem do arquivo ausente: restauração impossível.', 'f3base' ),
			);
		}

		$conteudo = file_get_contents( $backup ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- cópia local criada pelo próprio journal.

		if ( ! is_string( $conteudo ) ) {
			return array(
				'ok'     => false,
				'motivo' => __( 'falha ao ler a cópia de preimagem do arquivo.', 'f3base' ),
			);
		}

		$gravou = F3Base_Imp_Gravador::escrever_arquivo_infra( $caminho, $conteudo );

		return array(
			'ok'     => $gravou,
			'motivo' => $gravou ? '' : __( 'falha ao regravar o arquivo com a preimagem.', 'f3base' ),
		);
	}

	/**
	 * Compara leitura de volta com o esperado.
	 *
	 * @param string $alvo     Nome do alvo, para a mensagem.
	 * @param mixed  $lido     Valor lido de volta.
	 * @param mixed  $esperado Valor esperado.
	 * @return array{ok:bool,motivo:string}
	 */
	private static function conferido( string $alvo, $lido, $esperado ): array {
		$ok = wp_json_encode( $lido ) === wp_json_encode( $esperado );

		return array(
			'ok'     => $ok,
			'motivo' => $ok ? '' : sprintf(
				/* translators: %s: nome do alvo. */
				__( 'leitura de volta divergiu ao reverter %s.', 'f3base' ),
				$alvo
			),
		);
	}

	/**
	 * Carrega as entradas do banco.
	 *
	 * @return void
	 */
	private static function carregar(): void {
		if ( null !== self::$entradas ) {
			return;
		}

		$bruto = get_option( self::OPTION, array() );

		self::$entradas = is_array( $bruto ) ? array_values( $bruto ) : array();
	}

	/**
	 * Persiste as entradas.
	 *
	 * Passa pelo caminho de infraestrutura do gravador: o journal não se
	 * journaliza, e `update_option` continua existindo em um único arquivo.
	 *
	 * @return void
	 */
	private static function persistir(): void {
		F3Base_Imp_Gravador::persistir_infra( self::OPTION, self::$entradas );
	}
}
