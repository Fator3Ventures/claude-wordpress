<?php
/**
 * Adaptador do plugin de SEO.
 *
 * Fatos do fornecedor que este adaptador respeita, cada um por ter custado uma
 * medição:
 *
 * - A identidade da organização (`company_*`, `website_name`) vive em
 *   **`wpseo_titles`**, não em `wpseo`. Chave na option errada é descartada em
 *   silêncio, e o relatório diria "gravado" com o site sem identidade.
 * - `WPSEO_Taxonomy_Meta::set_value()` chamado uma chave por vez ZERA as
 *   anteriores. Aqui só existe `set_values()`, com o conjunto inteiro.
 * - `wpseo_llmstxt` é validada na gravação: o que o plugin não reconhece é
 *   descartado em silêncio. Por isso a option é gravada E RELIDA — e o arquivo
 *   publicado é uma segunda leitura de volta, de outra fonte de verdade.
 * - O SEO por conteúdo é gravado **mesmo sem o plugin ativo**: as chaves são
 *   dele, mas quem lê primeiro pode ser o site (o `site-core` honra o noindex).
 * - A lista do que NUNCA ligar é conferida como LISTA, chave a chave. Fixar a
 *   contagem esconde a chave que mudou de nome.
 *
 * Nenhum número de versão decide nada aqui: a versão observada vai nomeada ao
 * relatório e o gate é a leitura de volta.
 *
 * @package F3Base\Implantador
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Configuração de SEO gravada pelo implantador.
 */
final class F3Base_Imp_Seo {

	/**
	 * Slug do plugin de SEO adaptado.
	 */
	public const SLUG = 'wordpress-seo';

	/**
	 * Options do plugin em que este adaptador escreve.
	 *
	 * @return string[]
	 */
	public static function options(): array {
		return array( 'wpseo', 'wpseo_titles', 'wpseo_social', 'wpseo_llmstxt' );
	}

	/**
	 * Chaves que NUNCA se ligam, com a origem do valor esperado.
	 *
	 * As quatro primeiras são proibições incondicionais. As três de bots derivam
	 * da variável de política — nunca de um absoluto: política diferente muda a
	 * checagem, não o padrão.
	 *
	 * @return array<string,array{esperado:bool,motivo:string}>
	 */
	public static function nunca_ligar(): array {
		$restringe = 'restringir' === (string) F3Base_Imp_Config::obter( 'bots_ia.politica', 'liberar' );

		return array(
			'clean_permalinks'              => array(
				'esperado' => false,
				'motivo'   => __( 'redireciona URLs com parâmetros não registrados: apaga as UTMs das campanhas.', 'f3base' ),
			),
			'clean_campaign_tracking_urls'  => array(
				'esperado' => false,
				'motivo'   => __( 'remove utm_* por redirecionamento.', 'f3base' ),
			),
			'deny_adsbot_crawling'          => array(
				'esperado' => false,
				'motivo'   => __( 'o Google reprova o anúncio por não conseguir avaliar a página de destino.', 'f3base' ),
			),
			'deny_wp_json_crawling'         => array(
				'esperado' => false,
				'motivo'   => __( 'sem ganho real; a REST API é usada pelo editor de blocos.', 'f3base' ),
			),
			'deny_gptbot_crawling'          => array(
				'esperado' => $restringe,
				'motivo'   => __( 'valor derivado da política declarada de bots de IA.', 'f3base' ),
			),
			'deny_google_extended_crawling' => array(
				'esperado' => $restringe,
				'motivo'   => __( 'valor derivado da política declarada de bots de IA.', 'f3base' ),
			),
			'deny_ccbot_crawling'           => array(
				'esperado' => $restringe,
				'motivo'   => __( 'valor derivado da política declarada de bots de IA.', 'f3base' ),
			),
		);
	}

	/**
	 * O plugin de SEO está ativo?
	 *
	 * Gate ESTRUTURAL, provado pela saída e não pela presença de uma constante:
	 * uma fixture de onze linhas define a constante sem produzir uma linha de
	 * HTML.
	 *
	 * @return bool
	 */
	public static function plugin_ativo(): bool {
		$arquivo = F3Base_Imp_Plugins::arquivo_principal( self::SLUG );

		return '' !== $arquivo && is_plugin_active( $arquivo );
	}

	/**
	 * Identidade da organização e aparência na busca — em `wpseo_titles`.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_identidade(): array {
		$rotulo = 'seo.identidade';
		$nome   = (string) F3Base_Imp_Config::obter( 'seo.organizacao.nome', '' );
		$logo   = (string) F3Base_Imp_Config::obter( 'seo.organizacao.logo_ref', '' );
		$anexo  = '' !== $logo ? F3Base_Imp_Conteudo::localizar_gerenciado( 'attachment', 'midia:' . $logo ) : 0;

		$chaves = array(
			'company_or_person'       => 'company',
			'company_name'            => $nome,
			'website_name'            => (string) F3Base_Imp_Config::obter( 'site.nome', '' ),
			'disable-author'          => true,
			'disable-date'            => true,
			'disable-post_format'     => true,
			'disable-attachment'      => true,
			'breadcrumbs-enable'      => true,
			'noindex-tax-post_tag'    => true,
		);

		if ( $anexo > 0 ) {
			$chaves['company_logo']    = (string) wp_get_attachment_url( $anexo );
			$chaves['company_logo_id'] = $anexo;
		}

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo_titles', $chaves, array( 'plugin' => self::SLUG ) );

		return self::saida(
			$resultado['estado'],
			$rotulo,
			sprintf(
				/* translators: 1: chaves gravadas, 2: mensagem do gravador, 3: versão observada do plugin. */
				__( 'identidade gravada em wpseo_titles (nunca em wpseo) — chaves: %1$s. %2$s Versão observada do plugin: %3$s.', 'f3base' ),
				implode( ', ', array_keys( $chaves ) ),
				$resultado['motivo'],
				self::versao_observada()
			)
		);
	}

	/**
	 * Open Graph, Twitter Cards e imagem social padrão.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_social(): array {
		$ref   = (string) F3Base_Imp_Config::obter( 'seo.imagem_social_ref', '' );
		$anexo = '' !== $ref ? F3Base_Imp_Conteudo::localizar_gerenciado( 'attachment', 'midia:' . $ref ) : 0;

		$chaves = array(
			'opengraph' => true,
			'twitter'   => true,
		);

		if ( $anexo > 0 ) {
			$chaves['og_default_image']    = (string) wp_get_attachment_url( $anexo );
			$chaves['og_default_image_id'] = $anexo;
		}

		$perfis = array();

		foreach ( F3Base_Imp_Config::lista( 'seo.organizacao.same_as' ) as $url ) {
			$limpa = esc_url_raw( (string) $url );

			if ( '' !== $limpa ) {
				$perfis[] = $limpa;
			}
		}

		$chaves['other_social_urls'] = $perfis;

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo_social', $chaves, array( 'plugin' => self::SLUG ) );

		return self::saida(
			$resultado['estado'],
			'seo.social',
			sprintf(
				/* translators: 1: mensagem do gravador, 2: quantidade de perfis declarados. */
				__( 'Open Graph e Twitter Cards ligados; sameAs com %2$d URL(s) declarada(s) — só URL verificada entra, e vazio é estado válido. %1$s', 'f3base' ),
				$resultado['motivo'],
				count( $perfis )
			)
		);
	}

	/**
	 * Chaves gerais: sitemap, limpeza, telemetria desligada e integração.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_geral(): array {
		$chaves = array(
			'tracking'           => false,
			'enable_xml_sitemap' => true,
			'enable_index_now'   => false,
			'enable_llms_txt'    => (bool) F3Base_Imp_Config::obter( 'bots_ia.llms_txt', false ),
		);

		$site_kit = F3Base_Imp_Plugins::arquivo_principal( 'google-site-kit' );

		if ( '' !== $site_kit && is_plugin_active( $site_kit ) ) {
			$chaves['google_site_kit_feature_enabled'] = true;
		}

		foreach ( self::nunca_ligar() as $chave => $regra ) {
			$chaves[ $chave ] = $regra['esperado'];
		}

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo', $chaves, array( 'plugin' => self::SLUG ) );

		return self::saida(
			$resultado['estado'],
			'seo.geral',
			sprintf(
				/* translators: 1: mensagem do gravador, 2: estado da integração com o Site Kit. */
				__( 'telemetria desligada, sitemap do plugin ligado e a lista do que nunca ligar aplicada chave a chave. Integração com o Site Kit: %2$s. %1$s', 'f3base' ),
				$resultado['motivo'],
				isset( $chaves['google_site_kit_feature_enabled'] )
					? __( 'ligada (os dois plugins ativos)', 'f3base' )
					: __( 'não aplicável (Site Kit ausente ou inativo)', 'f3base' )
			)
		);
	}

	/**
	 * Confere a lista do que NUNCA ligar, chave a chave e pelo nome.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function conferir_nunca_ligar(): array {
		$saida = array();

		foreach ( self::nunca_ligar() as $chave => $regra ) {
			$onde = self::localizar_chave( $chave );

			if ( '' === $onde ) {
				$saida[] = self::saida(
					'N/A',
					'seo.nunca_ligar:' . $chave,
					sprintf(
						/* translators: 1: nome da chave, 2: versão observada do plugin. */
						__( 'condição de aplicabilidade falsa: a chave %1$s não existe em nenhuma option deste plugin na versão observada %2$s.', 'f3base' ),
						$chave,
						self::versao_observada()
					)
				);
				continue;
			}

			$valores = get_option( $onde, array() );
			$valores = is_array( $valores ) ? $valores : array();
			$atual   = ! empty( $valores[ $chave ] );

			$saida[] = self::saida(
				$atual === (bool) $regra['esperado'] ? 'OK' : 'FALHA',
				'seo.nunca_ligar:' . $chave,
				sprintf(
					/* translators: 1: option onde a chave vive, 2: valor esperado, 3: valor observado, 4: motivo declarado. */
					__( 'em %1$s — esperado %2$s, observado %3$s. %4$s', 'f3base' ),
					$onde,
					$regra['esperado'] ? 'true' : 'false',
					$atual ? 'true' : 'false',
					$regra['motivo']
				)
			);
		}

		return $saida;
	}

	/**
	 * O ID de página para a seleção do `llms.txt` do plugin — PONTO ÚNICO.
	 *
	 * O DEFEITO CORRIGIDO NA 1.0.14. A 1.0.13 gateou o item de `f3base_llms` pelo
	 * artefato e deixou ESTA gravação entregar `privacy_policy => <id>` sem gate
	 * nenhum: o mesmo defeito, no segundo produtor do mesmo fato.
	 *
	 * O teste NÃO é o que o plugin de terceiro faz com o ID de uma página não
	 * publicada — isso este pacote não mediu e não precisa medir. O teste é se
	 * ESTE pacote deve entregar o identificador de um rascunho a um slot chamado
	 * `privacy_policy` que alimenta um arquivo publicado. Não deve, faça o
	 * consumidor o que fizer: a escrita está errada na origem, e é na origem que
	 * ela se corrige. Zero é a forma declarada de "não há política selecionada".
	 *
	 * @param string $ref Referência lógica da página.
	 * @return int ID da página publicada, ou 0.
	 */
	public static function id_llms_de_pagina( string $ref ): int {
		return (int) F3Base_Imp_Conteudo::id_de_pagina_publicada( $ref )['id'];
	}

	/**
	 * Seleção manual do `llms.txt`, gravada E relida.
	 *
	 * As referências são LÓGICAS: a seleção é resolvida para os IDs desta
	 * instalação em tempo de deploy, nunca escrita como ID fixo.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_llms(): array {
		$rotulo = 'seo.llms_selecao';

		if ( ! (bool) F3Base_Imp_Config::obter( 'bots_ia.llms_txt', false ) ) {
			return self::saida(
				'N/A',
				$rotulo,
				__( 'condição de aplicabilidade falsa: a política declarada mantém o recurso llms.txt desligado, e não se configura seleção de um recurso que não existe.', 'f3base' )
			);
		}

		$id_privacidade = (bool) F3Base_Imp_Config::obter( 'seo.llms_selecao.incluir_politica_privacidade', true )
			? self::id_llms_de_pagina( F3Base_Imp_Conteudo::ref_da_politica_de_privacidade() )
			: 0;

		$livres      = array();
		$nao_achados = array();
		$fora        = array();

		foreach ( F3Base_Imp_Config::lista( 'seo.llms_selecao.livres' ) as $ref ) {
			$ref    = (string) $ref;
			$medido = F3Base_Imp_Conteudo::id_de_pagina_publicada( $ref );

			if ( ! $medido['existe'] ) {
				$nao_achados[] = $ref;
				continue;
			}

			if ( $medido['id'] > 0 ) {
				$livres[] = $medido['id'];
				continue;
			}

			$fora[] = $ref . ' (' . $medido['observado'] . ')';
		}

		if ( array() !== $nao_achados ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				sprintf(
					/* translators: %s: referências lógicas não resolvidas. */
					__( 'referências lógicas da seleção não resolvem para páginas gerenciadas: %s. Sem página, não há ID para gravar — e ID fixo escrito à mão é o defeito que a referência lógica existe para evitar.', 'f3base' ),
					implode( ', ', $nao_achados )
				)
			);
		}

		/*
		 * Os NOMES das chaves internas desta option são fato do fornecedor, não
		 * deste pacote. Quando a option já existe, preservamos a forma dela e
		 * preenchemos o que reconhecemos; quando não existe, gravamos a forma
		 * declarada e deixamos a LEITURA DE VOLTA decidir — que é o único gate
		 * possível quando o plugin muda embaixo do site sem release nossa.
		 */
		$chaves = array(
			'privacy_policy' => $id_privacidade,
			'manual'         => true,
			'pages'          => $livres,
		);

		$resultado = F3Base_Imp_Gravador::gravar_chaves( 'wpseo_llmstxt', $chaves, array( 'plugin' => self::SLUG ) );

		$descartadas = isset( $resultado['descartadas'] ) && is_array( $resultado['descartadas'] ) ? $resultado['descartadas'] : array();

		return self::saida(
			$resultado['estado'],
			$rotulo,
			array() === $descartadas
				? sprintf(
					/* translators: 1: quantidade de páginas livres, 2: estado do slot da política, 3: páginas fora por não estarem publicadas, 4: versão observada. */
					__( 'seleção gravada em wpseo_llmstxt e RELIDA: %1$d página(s) livre(s) e o slot da política de privacidade %2$s. Fora da seleção por NÃO estarem publicadas, nomeadas em vez de contadas: %3$s. Versão observada do plugin: %4$s. A segunda leitura de volta é o arquivo publicado, e ela é de outra fonte de verdade.', 'f3base' ),
					count( $livres ),
					$id_privacidade > 0
						? __( 'preenchido com a página publicada', 'f3base' )
						: __( 'ZERADO — a política não está publicada, ou a seleção não a inclui; entregar o ID de um rascunho a um slot que alimenta arquivo público é o defeito que esta release fechou', 'f3base' ),
					array() === $fora ? __( 'nenhuma', 'f3base' ) : implode( ', ', $fora ),
					self::versao_observada()
				)
				: sprintf(
					/* translators: 1: chaves descartadas, 2: versão observada. */
					__( 'o plugin descartou em silêncio as chaves %1$s ao gravar wpseo_llmstxt (versão observada: %2$s); a escrita foi revertida pelo journal.', 'f3base' ),
					implode( ', ', $descartadas ),
					self::versao_observada()
				)
		);
	}

	/**
	 * Grava o SEO de um conteúdo — mesmo sem o plugin ativo.
	 *
	 * @param int                 $id      ID do post.
	 * @param array<string,mixed> $valores Valores declarados.
	 * @return array<string,mixed>
	 */
	public static function gravar_por_conteudo( int $id, array $valores ): array {
		$rotulo = 'seo.conteudo:' . $id;

		if ( $id <= 0 ) {
			return self::saida( 'BLOCKED', 'seo.conteudo', __( 'identificador de conteúdo ausente.', 'f3base' ) );
		}

		$indexar = ! empty( $valores['indexar'] );

		$metas = array(
			'_yoast_wpseo_title'    => (string) ( $valores['titulo'] ?? '' ),
			'_yoast_wpseo_metadesc' => (string) ( $valores['descricao'] ?? '' ),
		);

		$metas['_yoast_wpseo_meta-robots-noindex'] = $indexar ? '' : '1';
		$metas['_yoast_wpseo_is_cornerstone']      = ! empty( $valores['cornerstone'] ) ? '1' : '';

		$frase = (string) ( $valores['frase_chave'] ?? '' );

		if ( '' !== $frase ) {
			$metas['_yoast_wpseo_focuskw'] = $frase;
		}

		$falhas = array();

		foreach ( $metas as $chave => $valor ) {
			$resultado = '' === $valor && in_array( $chave, array( '_yoast_wpseo_meta-robots-noindex', '_yoast_wpseo_is_cornerstone' ), true )
				? F3Base_Imp_Gravador::remover_meta( 'post', $id, $chave, array( 'plugin' => self::SLUG ) )
				: F3Base_Imp_Gravador::gravar_meta( 'post', $id, $chave, $valor, array( 'plugin' => self::SLUG ) );

			if ( ! in_array( $resultado['estado'], array( 'OK', 'N/A' ), true ) ) {
				$falhas[] = $chave;
			}
		}

		$comprimento_titulo    = mb_strlen( (string) ( $valores['titulo'] ?? '' ) );
		$comprimento_descricao = mb_strlen( (string) ( $valores['descricao'] ?? '' ) );

		$aviso = '';

		if ( $comprimento_titulo > 60 || $comprimento_descricao > 158 ) {
			$aviso = sprintf(
				/* translators: 1: comprimento do título, 2: comprimento da descrição. */
				__( ' Truncamento provável: título com %1$d caracteres (orçamento editorial 60) e descrição com %2$d (orçamento 158) — medida, nunca reescrita automática.', 'f3base' ),
				$comprimento_titulo,
				$comprimento_descricao
			);
		}

		if ( array() !== $falhas ) {
			return self::saida(
				'FALHA',
				$rotulo,
				sprintf(
					/* translators: %s: chaves que falharam. */
					__( 'leitura de volta divergiu nas metas: %s.', 'f3base' ),
					implode( ', ', $falhas )
				)
			);
		}

		return self::saida(
			'OK',
			$rotulo,
			sprintf(
				/* translators: 1: estado de indexação, 2: estado da frase-chave, 3: aviso de truncamento. */
				__( 'SEO por conteúdo gravado e conferido (as chaves são do plugin, mas quem lê primeiro pode ser o site). Indexação: %1$s. Frase-chave: %2$s.%3$s', 'f3base' ),
				$indexar ? __( 'indexável', 'f3base' ) : __( 'noindex, follow', 'f3base' ),
				'' !== $frase
					? $frase
					: ( $indexar
						? __( 'ausente — ausência é válida, não se fabrica frase para indicador verde', 'f3base' )
						: __( 'isenta: conteúdo noindex não disputa busca', 'f3base' ) ),
				$aviso
			)
		);
	}

	/**
	 * Grava as metas de SEO de um termo com o CONJUNTO INTEIRO.
	 *
	 * `set_value()` uma chave por vez zera as anteriores. Só existe `set_values()`.
	 *
	 * @param int                  $termo     ID do termo.
	 * @param string               $taxonomia Taxonomia.
	 * @param array<string,string> $valores   Conjunto inteiro.
	 * @return array<string,mixed>
	 */
	public static function aplicar_termo( int $termo, string $taxonomia, array $valores ): array {
		$rotulo = 'seo.termo:' . $taxonomia . '#' . $termo;

		if ( ! class_exists( 'WPSEO_Taxonomy_Meta' ) ) {
			return self::saida(
				'BLOCKED',
				$rotulo,
				__( 'pré-condição ausente: a classe de metas de taxonomia do plugin de SEO não está carregada. Nenhuma chave gravada uma a uma como contorno — esse é o caminho que zera as anteriores.', 'f3base' )
			);
		}

		if ( F3Base_Imp_Gravador::em_simulacao() ) {
			return self::saida( 'N/A', $rotulo, __( 'modo simulação: gravaria o conjunto inteiro das metas do termo.', 'f3base' ) );
		}

		$antes = WPSEO_Taxonomy_Meta::get_term_meta( $termo, $taxonomia );
		$antes = is_array( $antes ) ? $antes : array();

		F3Base_Imp_Journal::registrar(
			F3Base_Imp_Journal::TIPO_TERMO,
			$rotulo,
			$antes,
			$valores,
			array(
				'acao'      => 'termo.restaurar',
				'id'        => $termo,
				'taxonomia' => $taxonomia,
				'campos'    => array(),
			),
			array(
				'reversivel' => false,
				'motivo'     => __( 'as metas de taxonomia do plugin de SEO vivem numa option agregada do próprio plugin: a reversão fina fica fora da promessa automática.', 'f3base' ),
			)
		);

		WPSEO_Taxonomy_Meta::set_values( $termo, $taxonomia, $valores );

		$lido    = WPSEO_Taxonomy_Meta::get_term_meta( $termo, $taxonomia );
		$lido    = is_array( $lido ) ? $lido : array();
		$faltam  = array();

		foreach ( $valores as $chave => $valor ) {
			if ( ! isset( $lido[ $chave ] ) || (string) $lido[ $chave ] !== (string) $valor ) {
				$faltam[] = (string) $chave;
			}
		}

		return self::saida(
			array() === $faltam ? 'OK' : 'FALHA',
			$rotulo,
			array() === $faltam
				? __( 'conjunto inteiro gravado por set_values() e conferido na leitura de volta.', 'f3base' )
				: sprintf(
					/* translators: %s: chaves divergentes. */
					__( 'leitura de volta das metas do termo divergiu em: %s.', 'f3base' ),
					implode( ', ', $faltam )
				)
		);
	}

	/**
	 * Grava o `robots.txt` como ARQUIVO FÍSICO.
	 *
	 * Arquivo físico anula diretiva virtual — e em hospedagem que responde
	 * `robots.txt` no nível do servidor, a ausência do arquivo devolve o
	 * controle ao template do host, não ao WordPress. Consequência dupla: tudo
	 * precisa estar no arquivo, e o arquivo precisa existir sempre.
	 *
	 * A mutação acontece SÓ dentro da raiz autorizada (`ABSPATH`). Candidato em
	 * diretório pai é conflito externo relatado, nunca mutado: em hospedagem
	 * compartilhada o pai pode pertencer a outro site.
	 *
	 * @return array<string,mixed>
	 */
	public static function aplicar_robots_txt(): array {
		$rotulo  = 'seo.robots_txt';
		$destino = trailingslashit( ABSPATH ) . 'robots.txt';

		$linhas = array(
			'# ' . __( 'Arquivo gerenciado pelo implantador do Método F3.', 'f3base' ),
			'# ' . self::comentario_de_politica(),
			'User-agent: *',
			'Disallow: /*?s=',
			'Disallow: /*&s=',
		);

		foreach ( F3Base_Imp_Config::lista( 'seo.robots_extra' ) as $extra ) {
			$linha = trim( (string) $extra );

			if ( '' !== $linha ) {
				$linhas[] = $linha;
			}
		}

		$linhas[] = '';
		$linhas[] = 'Sitemap: ' . trailingslashit( home_url() ) . 'sitemap_index.xml';
		$linhas[] = '';

		$conteudo = implode( "\n", $linhas );

		$externos = self::candidatos_externos();

		$resultado = F3Base_Imp_Gravador::gravar_arquivo( $destino, $conteudo );

		$nota = array() !== $externos
			? sprintf(
				/* translators: %s: caminhos encontrados fora da raiz autorizada. */
				__( ' Conflito externo relatado, não mutado: há robots.txt fora da raiz autorizada em %s — em hospedagem compartilhada o diretório pai pode pertencer a outro site.', 'f3base' ),
				implode( ', ', $externos )
			)
			: '';

		return self::saida(
			$resultado['estado'],
			$rotulo,
			sprintf(
				/* translators: 1: caminho do arquivo, 2: mensagem do gravador, 3: nota sobre candidatos externos. */
				__( 'arquivo físico em %1$s com o conteúdo-base e a linha Sitemap resolvida por home_url(). %2$s%3$s A leitura pela URL pública é evidência de outra classe e fica com a suíte.', 'f3base' ),
				$destino,
				$resultado['motivo'],
				$nota
			)
		);
	}

	/**
	 * Versão observada do plugin de SEO — diagnóstico, nunca gate.
	 *
	 * @return string
	 */
	public static function versao_observada(): string {
		$versao = F3Base_Imp_Plugins::versao_instalada( self::SLUG );

		return '' !== $versao ? $versao : __( 'não instalado', 'f3base' );
	}

	/* ------------------------------------------------------------------ *
	 * Internos
	 * ------------------------------------------------------------------ */

	/**
	 * Em qual option do plugin a chave existe hoje.
	 *
	 * Procurar em vez de fixar o par chave→option é o que sobrevive à
	 * reorganização de options entre versões, que já aconteceu neste plugin.
	 *
	 * @param string $chave Nome da chave.
	 * @return string Nome da option, ou vazio quando a chave não existe.
	 */
	private static function localizar_chave( string $chave ): string {
		foreach ( self::options() as $option ) {
			$valores = get_option( $option, null );

			if ( is_array( $valores ) && array_key_exists( $chave, $valores ) ) {
				return $option;
			}
		}

		return '';
	}

	/**
	 * Comentário que declara a política de bots no próprio arquivo.
	 *
	 * Com a política em "liberar", o arquivo NÃO tem grupo nomeado: ausência de
	 * grupo já significa permitido, e grupo nomeado que repete o curinga só cria
	 * chance de perder paridade. A intenção vive em comentário.
	 *
	 * @return string
	 */
	private static function comentario_de_politica(): string {
		$politica = (string) F3Base_Imp_Config::obter( 'bots_ia.politica', 'liberar' );

		return 'liberar' === $politica
			? __( 'Política de bots de IA: liberar. Sem grupo nomeado — grupo só existe para restringir.', 'f3base' )
			: __( 'Política de bots de IA: restringir. Os grupos nomeados repetem as regras do curinga.', 'f3base' );
	}

	/**
	 * Candidatos de `robots.txt` fora da raiz autorizada.
	 *
	 * @return string[]
	 */
	private static function candidatos_externos(): array {
		$raiz       = realpath( ABSPATH );
		$candidatos = array();

		$possiveis = array();

		if ( isset( $_SERVER['DOCUMENT_ROOT'] ) ) {
			$possiveis[] = trailingslashit( sanitize_text_field( wp_unslash( (string) $_SERVER['DOCUMENT_ROOT'] ) ) ) . 'robots.txt';
		}

		$possiveis[] = trailingslashit( dirname( untrailingslashit( ABSPATH ) ) ) . 'robots.txt';

		foreach ( $possiveis as $caminho ) {
			$real = realpath( $caminho );

			if ( false === $real || ! is_file( $real ) ) {
				continue;
			}

			if ( false !== $raiz && str_starts_with( $real, trailingslashit( $raiz ) ) ) {
				continue;
			}

			$candidatos[] = $real;
		}

		return array_values( array_unique( $candidatos ) );
	}

	/**
	 * Monta o resultado de uma unidade.
	 *
	 * @param string $estado Estado fechado.
	 * @param string $rotulo Nome da checagem.
	 * @param string $motivo Mensagem.
	 * @return array<string,mixed>
	 */
	private static function saida( string $estado, string $rotulo, string $motivo ): array {
		return array(
			'estado' => $estado,
			'rotulo' => $rotulo,
			'motivo' => $motivo,
			'id'     => 0,
		);
	}
}
