#!/usr/bin/env bash
#
# Renomeação de prefixo — a primeira etapa de TEMPLATE.md.
#
#   bash ferramentas/renomear-prefixo.sh <prefixo-novo> [caminho-do-pacote]
#
# POR QUE BASH CHAMANDO PHP, e não um só dos dois. É a mesma forma de
# `suite/verificar.sh`, e pela mesma razão: o contrato de invocação — argumento
# obrigatório, pré-condição de ambiente nomeada, código de saída — mora no shell,
# onde o operador o executa; a reescrita mora em PHP, que é a linguagem do
# pacote e já é pré-requisito declarado da suíte. Uma ferramenta só em bash faria
# reescrita de código com expressão regular de sed, que é como se introduz o
# defeito silencioso; uma ferramenta só em PHP perderia a recusa antes de
# qualquer leitura de arquivo.
#
# Rodar sem argumento RECUSA. Renomear para um prefixo que ninguém escolheu é
# pior do que não renomear.

set -u

FERRAMENTAS="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACOTE_PADRAO="$(dirname "$FERRAMENTAS")"

uso() {
	cat >&2 <<'TEXTO'
uso:
  bash ferramentas/renomear-prefixo.sh <prefixo-novo> [caminho-do-pacote]

O prefixo novo é o nome técnico deste site: diretório do tema, slug do plugin
persistente, prefixo das options e das metas, text domain, handles de asset,
classes CSS e prefixo das classes PHP. Ele obedece [a-z][a-z0-9-] e não pode ser
o prefixo do template nem colidir com o espaço de nome do WordPress — a lista de
recusas está em ferramentas/prefixos-recusados.tsv, com o motivo de cada uma.

Rodar duas vezes com o mesmo prefixo não muda nada na segunda: a busca é sempre
pelo prefixo de ORIGEM, declarado em ferramentas/prefixo-do-template.tsv.
TEXTO
}

if [ "$#" -lt 1 ]; then
	echo "RECUSADO: renomear-prefixo chamado sem prefixo novo." >&2
	uso
	exit 2
fi

if ! command -v php >/dev/null 2>&1; then
	echo "BLOCKED: pré-condição ausente. Recurso ausente: php." >&2
	exit 2
fi

PREFIXO="$1"
PACOTE="${2:-$PACOTE_PADRAO}"

if [ ! -d "$PACOTE" ]; then
	echo "BLOCKED: o pacote a renomear não existe no caminho informado: $PACOTE." >&2
	uso
	exit 2
fi

exec php "$FERRAMENTAS/renomear-prefixo.php" "$PACOTE" "$PREFIXO"
