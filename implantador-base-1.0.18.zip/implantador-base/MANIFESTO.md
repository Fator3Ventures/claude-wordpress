<!-- gerado:inicio=carimbo -->
# Manifesto da release — implantador-base 1.0.18

> Este bloco é **gerado** na primeira etapa do comando único, por leitura de disco, e conferido por
> `estatica.carimbo_de_release_nos_documentos`. Número digitado à mão em documento entregável envelhece
> em silêncio: foi o que aconteceu da 1.0.6 à 1.0.13. O que não pode ser gerado no momento da escrita
> sai aqui como pendência nomeada, nunca como número velho.

| Fato medido | Valor |
|---|---|
| Identidade da release | `1.0.18` |
| Implantador · tema · site-core | `1.0.18` · `1.0.1` · `1.0.1` |
| Bundle desta identidade | `implantador-base-1.0.18.zip` |
| Origens de release suportadas | 18 além da instalação limpa |
| Caminhos exatos no inventário | 112 |
| Prefixos declarados no inventário | 3 |
| Arquivos no pacote (fora de `dist/`) | 306 |
| Requisitos em `suite/manifesto.tsv` | 176 |
| Armadilhas com checagem mapeada | 85 |
| Armadilhas em pendência declarada | 11 |
| Detectores com piso em disco | 50 |
| Ramos de piso (negativa + positiva) | 100 |
| Páginas · posts declarados | 6 · 2 |
| Contagem por estado da última rodada | PENDÊNCIA NOMEADA: é resultado da rodada e não existe quando este bloco é escrito. Ela mora em `suite/rodada.json`, gerado pelo selo, com o hash do pacote que a rodada mediu. |
<!-- gerado:fim=carimbo -->

## Identidade única

A release tem **uma** identidade, e ela é compartilhada por tudo que viaja junto:
implantador, tema, `site-core`, configuração, conteúdo, memória de decisões e suíte. Os
três componentes têm numeração PRÓPRIA e podem divergir — o tema sobe quando o tema muda,
e o número que carimba o parâmetro de versão do CSS publicado é o do tema, lido do
cabeçalho, nunca a identidade da release. Os valores desta release estão no carimbo
gerado acima; nenhum deles é digitado aqui, porque número digitado envelhece calado.

`release.anterior_suportada` é uma lista FECHADA de origens aceitas além da instalação
limpa, cada uma com a própria `determinacao`: `medida-no-site` quando a release foi
observada rodando num site, `entregue-nao-confirmada` quando ela foi produzida e nunca
chegou a um. A distinção é sobre o SITE e não sobre o repositório. Origem fora da lista
termina em BLOCKED, sem mutação, e cada entrada custa uma homologação: é por isso que ela
é fechada.

A identidade existe por um motivo operacional único: sem ela, outro agente recebe o
implantador de uma versão com o dump de outra. Tudo que o pacote produz — checkpoint,
proveniência, carimbo de versão aplicada, relatório — referencia essa identidade, e a
retomada de uma execução interrompida só acontece com a **mesma** identidade e o
**mesmo** hash de configuração.

Duas regras que dependem dela e que valem a pena repetir aqui:

- **O carimbo de versão aplicada avança apenas em `SUCESSO_APLICACAO`.** Execução que
  aborta no preflight, termina em falha ou é revertida não grava a versão. O carimbo é
  afirmação sobre o site, e um estado bloqueado que não tocou em nada não mudou o site.
- **Número de versão escrito em prosa não é contrato.** O contrato é o cabeçalho que o
  código lê. Nenhuma constante de PHP repete o número literal: ela deriva do cabeçalho,
  porque o caso medido foi exatamente esse — o `style.css` subiu de versão, a constante
  ficou para trás, o CSS novo saiu publicado com o parâmetro de versão antigo, e
  navegador e cache seguiram servindo o arquivo velho.

<!-- gerado:inicio=inventario -->
### Inventário: caminho para papel

Gerado de `suite/inventario.tsv`, que é a allow-list executável do empacotamento: arquivo em disco
fora dela **aborta o build com o nome**. Manter aqui uma cópia escrita à mão criaria duas fontes.

| Caminho | Papel |
|---|---|
| `MANIFESTO.md` | Manifesto da release: identidade única, inventário de caminho para papel, e a fronteira entre checksum de artefato nosso e fato observado de terceiro. |
| `MEMORIA-DECISOES.md` | Registro das decisões desta base, cada uma com o que foi decidido, por quê, o que custa e como reverter. |
| `README.md` | Leia-me do operador: árvore, pré-requisitos, instalação, execução, remoção, plugins, reversão de plugin, cadência, desligamento do canal e desvios. |
| `TEMPLATE.md` | Procedimento de troca de projeto: a ordem executável para criar um site novo a partir deste template, o que muda por site com o caminho exato de cada arquivo e chave, e o que nunca se toca. |
| `config/site.json` | Arquivo ÚNICO de configuração: fonte do estado desejado gerenciado. |
| `config/site.schema.json` | Schema de validação do arquivo de configuração; toda chave declarada aqui existe no site.json e tem consumidor provado. |
| `content/pages/arquitetura.html` | Conteúdo editorial da página de arquitetura (ref arquitetura): matriz de alocação, lockdown do theme.json, menu como objeto e onde mora o conteúdo. |
| `content/pages/contato.html` | Conteúdo editorial da página de contato (ref contato): CTA de WhatsApp no contrato de DOM do site-core e o que acontece no clique. |
| `content/pages/home.html` | Conteúdo editorial da página inicial (ref home): o que é o método, as três peças e a ordem do comando único. |
| `content/pages/manutencao.html` | Conteúdo editorial da página de manutenção (ref manutencao): canal MCP em dois plugins, risco aceito, protocolo do ajuste e cadência. |
| `content/pages/privacidade.html` | Conteúdo editorial da política de privacidade (ref privacidade), declarada para produção: qualificação do controlador interpolada da configuração, as duas redações do encarregado em blocos que se excluem, finalidades, base legal, retenção, fornecedores e direitos. |
| `content/pages/verificacao.html` | Conteúdo editorial da página de verificação (ref verificacao): teto e piso, estados fechados, classe de evidência e fase, e o instrumento que mente. |
| `content/posts/o-artefato-decide-o-registro-e-diagnostico.html` | Conteúdo editorial de post: o artefato decide, o registro é diagnóstico, e a ordem gravar, reler e só então registrar. |
| `content/posts/por-que-checagem-que-nunca-falhou-nao-e-evidencia.html` | Conteúdo editorial de post: por que o piso separa uma checagem correta de uma checagem cega. |
| `implantador-base.php` | Bootstrap do implantador: cabeçalho de plugin, constantes de identidade e caminho, autoload e registro dos hooks. |
| `includes/assets/implantador.css` | Estilo da tela orquestradora e da tela de resultado, em arquivo próprio: a resposta do admin-post.php é um documento que não herda o chrome do wp-admin. |
| `includes/assets/implantador.js` | Cliente da tela orquestradora, em arquivo próprio e nunca em heredoc: lê a resposta como texto e acha o JSON no fim de um corpo HTML+JSON. |
| `includes/class-f3base-imp-admin.php` | Superfície de administração: tela orquestradora e resultado renderizados INLINE na resposta do admin-post.php, nunca por redirect — a página do menu deixa de existir no instante do sucesso. |
| `includes/class-f3base-imp-config.php` | Leitura e validação do arquivo único de configuração. |
| `includes/class-f3base-imp-conteudo.php` | Conteúdo gerenciado: páginas, posts, categorias e mídia. |
| `includes/class-f3base-imp-entrega.php` | Checagens dos oito entregáveis e gate da autodesativação: entregável em BLOCKED impede o implantador de sair do ar. |
| `includes/class-f3base-imp-gravador.php` | Ponto único de escrita. |
| `includes/class-f3base-imp-journal.php` | Journal de mutações com preimagem, pós-imagem e operação inversa. |
| `includes/class-f3base-imp-lotes.php` | Orquestrador em lotes: checkpoint depois da leitura de volta, lock com heartbeat e fencing token, e resposta JSON bufferizada com shutdown armado antes do trabalho. |
| `includes/class-f3base-imp-navegacao.php` | Navegação como entidade, não como markup. |
| `includes/class-f3base-imp-plano.php` | Grafo de dependências do plano: grupos declarados, tabela de dependências reais, resolução para ids concretos e fecho transitivo da suspensão. Função pura, sem WordPress. |
| `includes/class-f3base-imp-plugins.php` | Instalação de tema, `site-core` e plugins. |
| `includes/class-f3base-imp-preflight.php` | Preflight: tudo que se mede ANTES de qualquer mutação. |
| `includes/class-f3base-imp-relatorio.php` | Relatório em estados fechados. |
| `includes/class-f3base-imp-seo.php` | Adaptador do plugin de SEO. |
| `fontes/site-core/admin/assets/f3base-admin.css` | Estilo da tela de administração. Só apresentação. |
| `fontes/site-core/admin/class-f3base-admin-tela.php` | Tela do wp-admin, renderizada a partir do registro único de módulos — nunca de lista escrita à mão. |
| `fontes/site-core/assets/f3base-consentimento.js` | Comportamento do consentimento pré-aprovado e do controle de revisão do rodapé. |
| `fontes/site-core/assets/f3base-leads.js` | Comportamento do CTA de leads: monta a URL do WhatsApp, registra a interação por sendBeacon e transporta a atribuição. É onde o contrato de DOM está documentado. |
| `fontes/site-core/assets/f3base-linkedin.js` | Carregador da tag do LinkedIn, só emitido quando há identificador preenchido e consentimento vigente. |
| `fontes/site-core/f3base-site-core.php` | Bootstrap do plugin persistente: cabeçalho, constantes, guarda de versão de PHP e carregamento do registro único. |
| `fontes/site-core/includes/class-f3base-atividade.php` | Última atividade relevante por módulo, exibida na tela. |
| `fontes/site-core/includes/class-f3base-modulo-cabecalhos.php` | Módulo: emite os cabeçalhos de resposta declarados na configuração. |
| `fontes/site-core/includes/class-f3base-modulo-cadencia-relatorio.php` | Módulo: OUVINTE do evento f3base_cadencia_relatorio, registro das recorrências quinzenal e mensal que o núcleo não tem, execução do modo somente-relatório com última execução, próxima, duração, resultado, erro e atraso, e o contador de ajustes que dispara. |
| `fontes/site-core/includes/class-f3base-modulo-consentimento.php` | Módulo: política de consentimento e o controle permanente do rodapé. |
| `fontes/site-core/includes/class-f3base-modulo-endpoint-leads.php` | Módulo: rota REST pública e endurecida que recebe o registro de lead. |
| `fontes/site-core/includes/class-f3base-modulo-guarda-options-mcp.php` | Módulo: estende a lista de options protegidas do servidor MCP a partir do catálogo do gravador. |
| `fontes/site-core/includes/class-f3base-modulo-leads-whatsapp.php` | Módulo: promove o CTA a link profundo do WhatsApp no servidor e enfileira o script de leads. |
| `fontes/site-core/includes/class-f3base-modulo-llms-txt-reserva.php` | Módulo: rota virtual de llms.txt, servida só quando não existe arquivo físico na raiz. |
| `fontes/site-core/includes/class-f3base-modulo-noindex-honrado.php` | Módulo: honra o noindex gravado nas chaves do plugin de SEO mesmo sem o plugin ativo. |
| `fontes/site-core/includes/class-f3base-modulo-redirects.php` | Módulo: redirecionamento de slug antigo, cobrindo o que o núcleo não cobre. |
| `fontes/site-core/includes/class-f3base-modulo-retencao-eliminacao.php` | Módulo: limpeza por prazo, exportador e eliminador do núcleo, e journal de eliminação. |
| `fontes/site-core/includes/class-f3base-modulo-rota-origem.php` | Módulo: rota de leitura de volta pela origem, restrita a caminhos do próprio home_url(). |
| `fontes/site-core/includes/class-f3base-modulo-schema-extensao.php` | Módulo: estende o schema do plugin de SEO sem duplicar nó existente. |
| `fontes/site-core/includes/class-f3base-modulo-tracking.php` | Módulo: slots de tag de terceiro, inertes até haver identificador e consentimento. |
| `fontes/site-core/includes/class-f3base-modulo.php` | Contrato de um módulo: identidade, dependências, options que o controlam, hooks e estado com motivo. |
| `fontes/site-core/includes/class-f3base-options.php` | Gravador ÚNICO de options do site-core, com catálogo, sanitização e procedência. |
| `fontes/site-core/includes/class-f3base-plugin.php` | Orquestrador: registra os hooks lendo o registro único. |
| `fontes/site-core/includes/class-f3base-registro.php` | Registro ÚNICO de módulos: alimenta hooks, tela e relatório. |
| `fontes/site-core/uninstall.php` | Desinstalação: declara o destino de cada conjunto de dados, passando pelo gravador único. |
| `suite/checagens/a11y.php` | Contraste recalculado da paleta do theme.json pela fórmula de luminância relativa da WCAG, sobre os pares em uso. |
| `suite/checagens/bloqueadas.php` | Tabela das checagens que este ambiente não pode medir (BLOCKED com a pré-condição que falta) e das condicionais não instanciadas (N/A com a condição declarada). |
| `suite/checagens/conteudo.php` | Checagens do conteúdo publicado: só referência a preset, e hierarquia de headings. |
| `suite/checagens/copy.php` | Contrato de copy: frases obrigatórias nas páginas declaradas e frases aposentadas em lugar nenhum do pacote. |
| `suite/checagens/entrega.php` | Os oito entregáveis, derivados da configuração: ausência fecha BLOCKED com o nome do arquivo que falta. |
| `suite/checagens/estatica.php` | Checagens estáticas: lint de PHP, JSON e JS, balanceamento de blocos, e os detectores de escrita única, version_compare, condição literal, código em string, chave sem consumidor e placeholder. |
| `suite/checagens/funcional.php` | Ponte para as sondas funcionais em subprocesso e para a sonda de JavaScript. |
| `suite/checagens/js.mjs` | Sonda de JavaScript sob o Node de verdade: `node --check` do pacote e o extrator de resposta do cliente, com teto e piso. |
| `suite/checagens/meta.php` | Cruzamentos da própria suíte: manifesto bidirecional e mapa de armadilhas, ambos calculados dos rótulos efetivamente emitidos. |
| `suite/checagens/tema.php` | Checagens do tema: zero com unidade, preset ocioso, preset inexistente, cor literal, wp:html declarado, layout do main e versão dos assets. |
| `suite/afirmacoes.tsv` | Elo DECLARADO entre uma frase de documento entregavel e o fato medido que a sustenta: documento, frase exata, regra e esperado. Sem ele nenhum detector conferia afirmacao de COMPORTAMENTO, e foi por essa fresta que passaram cinco dos vinte e dois achados da 1.0.17. |
| `suite/armadilhas.tsv` | Mapa de armadilha para checagem. Armadilha sem checagem é pendência declarada; mapeamento sem piso fecha BLOCKED. |
| `suite/inventario.tsv` | Inventário de caminho para papel: a allow-list de CAMINHOS do empacotamento. Arquivo fora dela aborta o build com o nome. |
| `suite/pisos-em-sonda.tsv` | Declaração das checagens cujo PISO mora dentro da própria sonda, e não numa fixture em disco: o caso negativo delas é um mutante do próprio pacote. A declaração não absolve — estatica.piso_em_sonda_declarado confere que a sonda existe, menciona a checagem e traz os dois ramos. |
| `suite/manifesto.tsv` | Manifesto de verificação: requisito para checagem, ambiente e classe de evidência. Base do cruzamento bidirecional. |
| `suite/lib/documentos.php` | Regiões GERADAS dos documentos entregáveis (README, MANIFESTO, MEMORIA-DECISOES) e o detector que as guarda: número em documento entregável sai de leitura de disco no empacotamento, nunca digitado, e o que não pode ser gerado sai como pendência nomeada. |
| `suite/lib/empacotar.php` | Empacotamento: allow-list de caminhos, montagem dos zips embutidos e do bundle, lock de sha256 e a checagem de artefato mais novo que a fonte. |
| `suite/lib/executar.php` | Runner do comando único: empacota, roda todas as checagens, imprime o resumo por estado e devolve código de saída diferente de zero quando há FALHA. |
| `suite/lib/piso.php` | Runner do piso: roda a MESMA função de cada checagem contra a fixture negativa (precisa acusar) e a positiva (precisa calar). |
| `suite/lib/sonda-hash.php` | Sonda do hash do pacote em subprocesso: não calcula nada, chama F3Base_Imp_Entrega::hash_do_pacote() — a MESMA função que o host executa ao conferir a amarração da rodada limpa. |
| `suite/lib/sonda-serie.php` | Sonda da série de cópias preservadas em subprocesso: carrega a classe de plugins da raiz apontada e chama a MESMA serie_do_nome() que a poda usa no site, para que o piso possa exercitá-la contra o corte ingênuo e contra o corrigido. |
| `suite/lib/regra.php` | Regra compartilhada, arquivo ÚNICO: `estado()` com o contador dentro, as listas fechadas de estado, classe e fase, a classificação de erro por origem e os utilitários de varredura. |
| `suite/lib/render-pattern.php` | Renderizador de pattern fora do WordPress, em subprocesso: o defeito de comentário `wp:` aparece na saída, não no arquivo cru. |
| `suite/lib/sonda-funcional.php` | Sonda funcional em subprocesso: validação do config com os mutantes, tabela do merge de três vias, casamento de waiver e sanitização de dump. |
| `suite/lib/sonda-gravador.php` | Sonda do gravador em subprocesso: equivalência de leitura de volta e impressão de procedência, com teto e piso. |
| `suite/lib/sonda-instalacao.php` | Sonda da INSTALAÇÃO LIMPA em subprocesso: monta um WordPress de mentira cujo cache memoriza o negativo, com o alvo inexistente e a consulta prévia na mesma requisição, e roda o aplicar_tema() e o aplicar_site_core() REAIS contra ele — com a invalidação desligada a leitura de volta tem de continuar cega, e com ela ligada tem de enxergar o artefato. |
| `suite/lib/sonda-site-core.php` | Sonda do SITE-CORE em subprocesso: monta um WordPress de mentira com wpdb, options e transientes e roda as funções REAIS do endpoint de leads e da cadência contra ele — cada regra com teto e com o mutante que reproduz o defeito medido. |
| `suite/verificar.sh` | COMANDO ÚNICO: empacota, verifica e resume. Sem argumento reprova; artefato ausente fecha BLOCKED nomeado; subcomando `piso` roda as fixtures. |
| `suite/rodada.json` | Registro DA rodada, gravado SÓ pelo comando único (etapa do selo): veredito declarado, contagem de FALHA, pendências de fase NOMEADAS, hash do pacote que a rodada mediu, resumo por estado com os nomes, contagem de detectores do piso e carimbo de tempo. É a evidência IMPORTADA que o host confere contra o hash do pacote instalado E cujo veredito ele LÊ; ele fica fora da soma que declara, e é isso que o deixa morar dentro do pacote que descreve. Ele se chamava rodada-limpa.json até a 1.0.17, trazia 22 BLOCKED dentro e o host o aprovava só pelo hash. |
| `fontes/tema/CONTRASTE.md` | Prova calculada do sistema de cor e de fonte: razões de contraste, alvo mínimo e o contrato de nomes entre tema e site-core. |
| `fontes/tema/functions.php` | Funções do tema: suportes declarados, publicação do CSS com a versão certa, injeção do ref da navegação, carimbo do CTA de contato e remoção de peso do núcleo. |
| `fontes/tema/parts/footer.html` | Parte de template do rodapé: navegação secundária, link da política e o controle de consentimento. Uma das duas exceções de wp:html declaradas. |
| `fontes/tema/parts/header.html` | Parte de template do cabeçalho: link de pular, logo, título, navegação e CTA. Uma das duas exceções de wp:html declaradas. |
| `fontes/tema/patterns/cta-whatsapp.php` | Pattern da faixa de conversão com o botão que o site-core promove a conversa de WhatsApp. |
| `fontes/tema/patterns/faq.php` | Pattern de perguntas frequentes em blocos de detalhes nativos. |
| `fontes/tema/patterns/hero.php` | Pattern de abertura de página, em faixa escura de largura total. |
| `fontes/tema/patterns/secao-cartoes.php` | Pattern de seção com três cartões lado a lado. |
| `fontes/tema/patterns/secao-texto.php` | Pattern de texto corrido com título, parágrafos e lista. |
| `fontes/tema/style.css` | Cabeçalho do tema (fonte única da versão) e as regras que o theme.json não expressa, cada uma com o motivo declarado. |
| `fontes/tema/templates/404.html` | Template de página não encontrada. |
| `fontes/tema/templates/archive.html` | Template de arquivo de termo e de data. |
| `fontes/tema/templates/front-page.html` | Template da página inicial, com a faixa de abertura e o conteúdo da página. |
| `fontes/tema/templates/index.html` | Template base do índice de posts. |
| `fontes/tema/templates/page.html` | Template de página: título em H1, e o conteúdo começando em H2. |
| `fontes/tema/templates/search.html` | Template de resultados de busca. |
| `fontes/tema/templates/single.html` | Template de post: título, data, categorias, conteúdo e navegação entre posts. |
| `fontes/tema/theme.json` | Coração do tema: paleta, escala tipográfica, escala de espaçamento, larguras, estilos por bloco e o lockdown de valores avulsos. |
| `ferramentas/renomear-prefixo.sh` | COMANDO da renomeação de prefixo: contrato de invocação, recusa sem argumento e pré-condição de ambiente nomeada; delega a reescrita ao PHP do pacote. |
| `ferramentas/renomear-prefixo.php` | Motor da renomeação: recusa o prefixo inválido antes de qualquer escrita, reescreve conteúdo e caminho pelas grafias declaradas, pula as exceções declaradas e remove a saída de build do prefixo antigo. |
| `ferramentas/prefixo-do-template.tsv` | Registro do prefixo de ORIGEM nas três grafias — técnica, abreviada e de exibição. Nunca reescrito: é dele que vêm a idempotência da ferramenta e o alvo do detector de resíduo. |
| `ferramentas/prefixos-recusados.tsv` | Prefixos que a renomeação recusa, com a regra (igual ou começa-com) e o motivo de cada um; declarados em arquivo para que acrescentar um não seja editar código. |
| `ferramentas/excecoes-de-prefixo.tsv` | Onde o prefixo do template pode sobreviver depois da renomeação, arquivo a arquivo com o motivo; lida pela ferramenta e pelo detector, para que a exceção não exista só de um lado. |
| `assets/logo.png` | midia embarcada: marca do site 512x512 com fundo transparente, nas cores inverso/primaria/base do theme.json; papel custom_logo, porque custom_logo exige anexo na biblioteca e a biblioteca recusa SVG por padrao |
| `assets/logo.svg` | midia embarcada: a MESMA marca em vetor, sem cor literal (currentColor), papel marca_inline: servida pelo tema no proprio markup e nunca enviada para a biblioteca de midia |
| `assets/favicon.png` | midia embarcada: icone do site 512x512, papel site_icon |
| `assets/social.png` | midia embarcada: imagem social padrao 1200x630, papel og_default_image |
| `assets/plugins/LEIA-ME.txt` | instrucao do slot de zips embutidos |
| `suite/fixtures/` (prefixo) | Fixtures do piso: uma árvore negativa que reproduz o defeito e uma positiva que preserva o correto, por detector. Fora do escopo das varreduras de pacote, por construção. |
| `dist/` (prefixo) | Saída do empacotamento, gerada pelo comando único: zips embutidos, bundle e lock. Não pertence ao pacote que o operador faz upload. |
| `assets/plugins/` (prefixo) | slot declarado: zip de plugin que o operador embute para dispensar rede no deploy; a resolucao de origem prefere este caminho a URL declarada |
<!-- gerado:fim=inventario -->

### `dist/`

Saída do empacotamento, gerada pelo comando único: o bundle da identidade desta release
e `dist/lock.tsv`. **Não pertence ao pacote que o operador faz upload** e não viaja dentro
dele. Desde a 1.0.16 não há zip de tema nem de `site-core` aqui: eles eram montados,
copiados para a raiz do bundle e não eram lidos por caminho de instalação nenhum — o item
28 de `MEMORIA-DECISOES.md` traz a medição e a razão da remoção. Tamanho e sha256 de cada peça moram em `dist/lock.tsv`,
que a primeira etapa do comando único grava e a etapa do selo regrava — copiar aqueles
números para cá criaria a segunda fonte que este manifesto inteiro existe para impedir.

<!-- gerado:inicio=fixtures -->
### Piso: um detector, duas árvores

Gerado de disco. Cada linha é um detector com fixture NEGATIVA — que reproduz o defeito e precisa ser
acusada — e POSITIVA — que preserva o caso correto e precisa ficar em silêncio.

| Detector | Arquivos de piso |
|---|---|
| `a11y.contraste` | 2 |
| `config.slug_declarado` | 2 |
| `conteudo.demonstrativo` | 4 |
| `conteudo.headings` | 4 |
| `conteudo.marca_demonstrativa` | 4 |
| `conteudo.sem_estilo_avulso` | 2 |
| `copy.contrato` | 6 |
| `doc.afirmacao_conferida` | 8 |
| `estatica.artefato_do_pacote_e_lido` | 4 |
| `estatica.carimbo_de_release_nos_documentos` | 14 |
| `estatica.contagem_com_nomes` | 4 |
| `estatica.detector_chave_sem_consumidor` | 4 |
| `estatica.detector_codigo_em_string` | 2 |
| `estatica.detector_condicao_literal` | 2 |
| `estatica.detector_escrita_unica` | 5 |
| `estatica.detector_placeholder` | 2 |
| `estatica.detector_version_compare` | 2 |
| `estatica.estados_fechados` | 2 |
| `estatica.gate_de_fase_do_metadado` | 2 |
| `estatica.gate_fonte_unica` | 9 |
| `estatica.identidade_do_implantador` | 4 |
| `estatica.js_lint` | 2 |
| `estatica.json_valido` | 2 |
| `estatica.llms_so_pagina_publicada` | 6 |
| `estatica.option_fonte_unica` | 6 |
| `estatica.option_gravada_sem_leitor` | 4 |
| `estatica.pagina_status_fonte_unica` | 4 |
| `estatica.php_lint` | 2 |
| `estatica.piso_em_sonda_declarado` | 5 |
| `estatica.plano_dependencias` | 2 |
| `estatica.politica_privacidade_fonte_unica` | 4 |
| `estatica.resposta_de_lote_nomeada` | 2 |
| `estatica.sem_residuo_de_prefixo` | 10 |
| `estatica.simbolos_resolvem` | 2 |
| `estatica.troca_invalida_cache` | 2 |
| `estatica.unidade_reflete_internas` | 6 |
| `estatica.warn_tem_ramo_adverso` | 2 |
| `estatica.wp_comentarios_balanceados` | 4 |
| `pacote.allow_list` | 5 |
| `pacote.backup_sempre_oculto` | 2 |
| `pacote.build_fresco` | 4 |
| `pacote.sem_cabecalho_de_plugin_aninhado` | 6 |
| `plugins.serie_de_backup_normalizada` | 2 |
| `tema.main_layout_default` | 2 |
| `tema.preset_inexistente` | 2 |
| `tema.preset_ocioso` | 2 |
| `tema.sem_cor_literal` | 4 |
| `tema.versao_assets` | 4 |
| `tema.wp_html_declarado` | 6 |
| `tema.zero_com_unidade` | 2 |
<!-- gerado:fim=fixtures -->

## Este pacote é um template, e o que isso muda no manifesto

A partir desta release o pacote é o **template de criação de sites** da operação: cada site
nasce de uma cópia dele, renomeada por `ferramentas/renomear-prefixo.sh` para o próprio
prefixo técnico. A identidade única acima continua sendo a da RELEASE do template; o site
derivado herda a release e troca o prefixo, e é `estatica.sem_residuo_de_prefixo` que
garante que a troca foi inteira — nenhuma grafia do prefixo de origem sobrevive fora da
lista declarada em `ferramentas/excecoes-de-prefixo.tsv`.

Uma exceção dessa lista merece estar aqui, porque é uma decisão sobre a verdade dos
documentos e não sobre código: **`MEMORIA-DECISOES.md` não é reescrito**. Ele narra defeitos
medidos citando diretórios que existiram em sites reais, e trocar o prefixo neles inventaria
um passado que não aconteceu. Ele viaja com o pacote como história herdada, atribuída a quem
a produziu. O procedimento completo está em `TEMPLATE.md`.

## Hash e checksum: o que é nosso e o que é fato observado

A fronteira é simples e não admite meio-termo: **artefato nosso tem checksum; artefato
de terceiro tem fato observado.** Confundir os dois produz um manifesto que parece
rigoroso e não prova nada.

### Artefatos nossos — entram no lock, com versão e checksum

São os que viajam dentro do bundle e cujo conteúdo nós controlamos:

| Artefato | O que o lock registra |
|---|---|
| Implantador (`implantador-base.php`, `includes/`, `config/`, `content/`, `assets/`, `suite/`) | `sha256` de cada caminho |
| Tema `f3base` (`fontes/tema/`) | `sha256` de cada caminho — é o diretório que a instalação lê |
| `f3base-site-core` (`fontes/site-core/`) | `sha256` de cada caminho, pela mesma razão |
| Os três `.md` da raiz | `sha256` de cada um, calculado depois de o arquivo estar fechado |

**O autoteste do canal é despachado de verdade.** `files/selftest` deixou de ser uma
frase de documento: a unidade `mcp` o DESPACHA — pela Abilities API quando ela existe, e
pelo servidor REST interno sempre — e leva o resultado estruturado para a linha
`mcp.autoteste`. Autoteste que devolve falha REPROVA a entrega; ausência da rota fecha
BLOCKED, nunca OK. A recusa a credencial não autorizada NÃO é mensurável de dentro do
WordPress rodando como administrador, e por isso sai como BLOCKED de fase em
`mcp.autoteste_recusa_credencial`, nomeando o que falta.

**A política de versão declarada é `ultima-da-fonte-oficial`**, e o que a sustenta é a
leitura de volta, nunca um número congelado. O que a 1.0.18 acrescentou é a fronteira que
faltava do outro lado: **flag de atualização automática ligada não é fonte que alcance**,
e as duas saem em linhas separadas — `plugins.autoupdate_conforme_politica` para a flag,
`plugins.autoupdate_alcance` para a fonte, com as classes nomeadas e a pendência de rede
declarada como pendência em vez de virar número inventado.

**O complemento do canal MCP saiu desta lista, e a razão importa.** Ele continua sendo
artefato nosso, mas deixou de viajar dentro do bundle: `plugins.embarcados` está vazio e
o complemento é instalado por origem `url` declarada, como o servidor. O lock cobre **o
que viaja no pacote**, e o que não viaja não tem caminho para hashear. O que substitui o
checksum nele é o mesmo mecanismo dos plugins de terceiro — a conferência das doze rotas
pelo nome, na unidade `mcp`. Se um dia ele voltar ao slot `assets/plugins/<slug>.zip`,
volta ao lock pelo caminho do slot, sem regra nova: a regra sempre foi "o que viaja é
hasheado".

**Regra que produz o valor.** O empacotador percorre a allow-list de caminhos em ordem,
calcula `sha256` de cada arquivo e escreve `caminho` e digest em `dist/lock.tsv`, uma
linha por arquivo, com o cabeçalho de colunas comentado. Zip embutido, quando existe,
entra pelo nome com que viaja dentro do bundle e não pelo caminho de saída em `dist/`;
nesta release não existe nenhum, e o laço simplesmente não roda. O próprio `dist/` fica
**fora** do lock: ele é saída de build, não pacote.

O manifesto não pode conter o seu próprio digest — ele é hasheado pelo lock e mudaria a
cada tentativa. Quem o cobre é a linha `MANIFESTO.md` do lock, calculada depois de este
arquivo estar fechado, e o digest do bundle, calculado depois do lock.

**Estado nesta base.** O empacotador existe, roda e produziu lock. Última saída de
build desta montagem:

| Artefato | `sha256` de contrato |
|---|---|
| `dist/implantador-base-<identidade>.zip` | tamanho e digest não podem constar aqui: o bundle **contém este arquivo**, e escrevê-los mudaria os dois no mesmo ato |
| `dist/lock.tsv` | idem: o lock traz a linha de `MANIFESTO.md`, calculada depois de este arquivo estar fechado |

O `dist/lock.tsv` desta montagem traz uma linha por caminho do pacote, mais uma por zip
embutido — nesta release, nenhum. **O número não é escrito aqui**, e essa é a regra que a
1.0.13 pagou para aprender: contagem digitada à mão em documento entregável está correta no
dia em que foi escrita e é contradita pela rodada seguinte. A contagem de arquivos do
pacote sai no carimbo gerado no topo deste arquivo, e o lock em si é o registro
autoritativo — ele é gerado a cada rodada e o próprio `dist/` fica fora dele, porque é
saída de build, não pacote.

**Por que a coluna de digest é um ponteiro e não um número.** A ressalva é do
instrumento: **os digests dos
zips não se repetem entre duas montagens.** `zip` grava a data de modificação de cada
entrada, e os arquivos que o empacotador copia para o diretório de montagem recebem data
nova a cada rodada; conteúdo idêntico produz digest diferente. Um número escrito aqui
estaria errado na rodada seguinte, e um manifesto que envelhece sozinho é pior do que um
que aponta. **O contrato é o `dist/lock.tsv` que sai da rodada que fecha a release**, e o
que ele prova é a correspondência entre caminho e conteúdo naquela rodada — não a
igualdade byte a byte de dois zips montados em momentos diferentes. Dizer isso é mais
barato do que deixar um operador comparar dois digests legítimos e concluir que o pacote
foi adulterado.

Recalcular um digest à mão não substitui isso: `sha256sum` de um arquivo desta árvore
devolve um número correto e sem valor de contrato, porque contrato é o que o comando
único reproduz. Evidência que o comando único não reproduz é BLOCKED — é a mesma regra
que já reprovou três requisitos de idempotência sustentados por um script que não viajava
no pacote.

### Artefatos de terceiro — não entram no lock, entram como fato observado

WordPress núcleo, PHP e os plugins instaláveis da fonte oficial ficam **fora** do lock.
Eles são instalados sempre na última versão publicada pela fonte oficial, e o manifesto
registra a versão **observada** na execução, como fato de diagnóstico e nunca como
critério de aprovação.

| Componente | O que o manifesto registra | O que decide |
|---|---|---|
| WordPress núcleo | versão observada na execução | nada: é diagnóstico |
| PHP | versão observada na execução | o piso `8.1` do preflight, que é requisito e não observação |
| `wordpress-seo` | versão observada e resultado da leitura de volta de cada option gravada | a leitura de volta |
| `flamingo` | versão observada e resultado da leitura de volta | a leitura de volta |
| `wp-mcp-ultimate` | versão observada e o resultado da conferência de rotas por nome | a presença das rotas exigidas |

Nenhum checksum de terceiro entra no lock. A fronteira de confiança nesses artefatos é
a entrega da própria fonte oficial por HTTPS, e o que substitui o checksum como prova de
que a instalação serve é a leitura de volta: o pacote grava dentro do journal, relê a
chave gravada, e reverte a escrita e fecha BLOCKED quando o plugin descartou ou
transformou o valor.

**Estado nesta base: BLOCKED.** O comando único roda contra a árvore do pacote, não
contra um WordPress instalado. Nenhuma versão de terceiro foi observada, e declarar um
número aqui seria inventá-lo.

## Valores que só existem em tempo de execução

Para cada um deles, a regra que o produz — nunca um número.

| Valor | Regra que o produz | Onde ele aparece |
|---|---|---|
| `sha256` de cada artefato nosso | `sha256` de cada caminho da allow-list, em ordem, no empacotamento | `dist/lock.tsv` |
| Digest do bundle | calculado sobre o arquivo único nomeado, depois de o lock estar fechado | repositório de artefatos |
| Hash da configuração | digest do `config/site.json` no início da execução; a retomada exige o mesmo valor | checkpoint e proveniência |
| Versão do implantador | cabeçalho `Version:` lido por `get_plugin_data()`; a constante de bootstrap é fallback, e o relatório imprime as duas quando divergem | relatório |
| Versão do tema | cabeçalho do `style.css` lido por `wp_get_theme()`; é a mesma que vai ao parâmetro de versão do CSS publicado | relatório e HTML publicado |
| Versão observada de plugin de terceiro | leitura da versão instalada no momento da aplicação, gravada junto do resultado da leitura de volta daquele plugin | relatório |
| Frase de validação do leia-me de projeto | **derivada** do lock: "validado até a versão que o lock registra", nunca "instalado tal versão" | leia-me de cada projeto |
| Identificador da execução e token de disputa | gerados no início da execução, gravados no checkpoint depois da leitura de volta | checkpoint |
| Identificador de anexo de mídia | atribuído pela instalação no sideload e injetado no bloco em tempo de deploy; muda por instalação e não pode viver no arquivo | conteúdo publicado |
| `f3base_nav_id` | identificador do post de navegação criado na aplicação, lido de volta e guardado em option | banco da instância |
| Data da última execução do modo somente-relatório | carimbo da execução mais recente da cadência, gravado pelo módulo `cadencia-relatorio` do `site-core` junto de gatilho, resultado, erro, duração e atraso medido sobre o horário previsto | relatório e tela do site-core |
| Ajustes contados desde a última execução da cadência | escritas em option GERENCIADA desde o último relatório, com carimbo de atividade, estado da cadência, procedência e journal fora da conta — eles mudam porque o site rodou, não porque alguém ajustou | tela do site-core |
| Peso de página, número de requisições e nós de DOM | medidos na entrega contra o orçamento declarado em `orcamento_pagina` | relatório |
| Razões de contraste | fórmula de luminância relativa da WCAG aplicada à paleta do `theme.json`, recalculada pela checagem `a11y` sobre os pares em uso | relatório e `fontes/tema/CONTRASTE.md` |

## Estado do manifesto nesta release

**Nenhuma linha desta tabela carrega contagem digitada.** Contagem por estado é resultado
da rodada, e a rodada acontece DEPOIS de este arquivo ser escrito: quem a carrega é
`suite/rodada.json`, gerado pelo selo com o hash do pacote que aquela rodada mediu.
Os números de disco — caminhos, requisitos, armadilhas, detectores com piso — estão no
carimbo gerado no topo. O que sobra aqui é o que a tabela sempre deveria ter sido: o
ESTADO de cada item e o motivo dele.

| Item | Estado | Motivo |
|---|---|---|
| Identidade única declarada e compartilhada | OK | `estatica.identidade_do_implantador` mede os TRÊS lugares que carregam o número — `release.identidade` e `release.implantador` na configuração, o cabeçalho `Version:` de `implantador-base.php` e o fallback `F3BASE_IMP_VERSAO_DECLARADA` —, e `estatica.carimbo_de_release_nos_documentos` reprova se um documento entregável carimbar outra. Até a 1.0.17 esta linha AFIRMAVA a igualdade e nada a media: a configuração foi para `1.0.17` com o cabeçalho em `1.0.16` e a constante em `1.0.15`, e nenhuma rodada acusou |
| Inventário de caminho para papel | OK | gerado de `suite/inventario.tsv`, a allow-list executável, e conferido contra o disco por `pacote.allow_list` |
| Comando único existe e roda | OK | `bash suite/verificar.sh <caminho absoluto>` fecha com código 0, e o resumo por estado daquela rodada é o que vai para `suite/rodada.json` |
| Piso dos detectores | OK | `bash suite/verificar.sh piso` roda dois ramos por detector — a fixture negativa precisa ser acusada, a positiva precisa ficar em silêncio —, e a contagem de detectores com piso está no carimbo |
| Mapa de armadilhas | OK | `armadilhas.mapeadas` calcula dos rótulos EFETIVAMENTE emitidos; mapeamento para checagem sem piso fecha BLOCKED, não OK |
| Empacotador produz lock com `sha256` por caminho | OK | `dist/lock.tsv`, gravado na primeira etapa e regravado pelo selo |
| Nenhum cabeçalho de plugin ao alcance de `get_plugins()` fora do arquivo principal | OK | `pacote.sem_cabecalho_de_plugin_aninhado`: um único `Plugin Name:` na raiz e nenhum a um nível, com as fontes em `fontes/` |
| Cobertura da allow-list sobre o disco | OK | nenhum arquivo em disco fora de `suite/inventario.tsv`, e nenhum caminho declarado sem arquivo |
| Lock e bundle correspondentes à árvore de hoje | OK | `pacote.build_fresco`: o bundle desta montagem é mais novo que toda fonte do pacote |
| Documentos entregáveis carimbados com a release que descrevem | OK | `estatica.carimbo_de_release_nos_documentos`: as regiões geradas de README, MANIFESTO e MEMORIA-DECISOES são comparadas com a medição de agora, e divergência é achado |
| Grafo de dependências do plano fecha | OK | `estatica.plano_dependencias`: nenhum grupo alvo inexistente, nenhum autoloop, nenhum ciclo |
| Uma fonte de verdade por veredito de gate, por option, por status de página e pela identidade da política | OK | `estatica.gate_fonte_unica`, `estatica.option_fonte_unica`, `estatica.pagina_status_fonte_unica` e `estatica.politica_privacidade_fonte_unica` |
| Slug declarado em todo conteúdo gerenciado | OK | `config.slug_declarado`: toda entrada de `paginas` e `posts` declara slug não vazio, e nenhum se repete |
| Cobertura das URLs antigas na troca de estrutura de permalinks | OK | `lotes.permalinks_decisao`: o padrão `aplicar-e-cobrir` grava 301 do caminho antigo de TODO publicado que muda de endereço, gerenciado ou não; o par sai pelo produtor único de `f3base_redirects` com origem própria, o caminho que não muda é descartado porque seria laço, e o relatório NOMEIA cada URL coberta em vez de contá-las |
| Conteúdo de exemplo do WordPress decidido por discriminante | OK | `conteudo.exemplo_do_wordpress`: só vai para a lixeira o objeto que AINDA É o que `wp_install_defaults()` criou — identidade contra o catálogo do núcleo mais `post_modified_gmt` sem avançar em relação a `post_date_gmt`. O piso que importa é o NEGATIVO: a edição é plantada em título, em conteúdo e nos dois, nos dois objetos do catálogo, e nenhum dos casos produz remoção |
| Nenhum WARN do runtime sem achado adverso | OK | `estatica.warn_tem_ramo_adverso`: todo WARN de `includes/` e `fontes/` mora num ramo que mediu alguma coisa, ou depois de uma cláusula de guarda que pode impedi-lo |
| Série de cópia preservada colapsa o backup de backup | OK | `plugins.serie_de_backup_normalizada`: a MESMA função do runtime, em subprocesso, sobre o nome literal medido no site e o aninhamento duplo |
| Renomeação de prefixo sem resíduo fora das exceções declaradas | N/A neste pacote | `estatica.sem_residuo_de_prefixo`: enquanto `site.prefixo_tecnico` for o prefixo do template, procurar resíduo do próprio prefixo não mede nada. A regra roda de verdade no pacote renomeado, e o piso de fixture prova, em toda rodada, que ela acusa o resíduo plantado e cala sobre a árvore limpa |
| Conteúdo demonstrativo declarado e coerente com o disco | WARN por desenho neste pacote | `conteudo.demonstrativo` fecha WARN porque `conteudo.demonstrativo = true` e `ambiente.tipo = "producao"`: as páginas ainda são as do template, e é isso que o aviso diz. `conteudo.marca_demonstrativa` fecha OK — declaração e disco concordam arquivo a arquivo |
| Referências de mídia com arquivo correspondente | OK | os arquivos declarados em `midia` existem em `assets/`; `logo.png` leva o papel `custom_logo` e `logo.svg` o papel `marca_inline`, que não passa pela biblioteca |
| Complemento do canal no lock | N/A | condição declarada: ele deixou de viajar no bundle (`plugins.embarcados` vazio) e é instalado por origem `url`. O lock cobre o que viaja; a conferência dele é a das doze rotas pelo nome |
| Versões observadas de núcleo, PHP e plugins de terceiro | BLOCKED | o comando único roda contra a árvore do pacote, não contra uma instalação. Regra que produziria o valor: o adaptador lê a versão instalada no momento da aplicação e a grava no relatório junto do resultado da leitura de volta |
| Canal MCP configurado e exposto | BLOCKED | as doze rotas se conferem pelo nome num WordPress com servidor e complemento ativos |
| Autoteste do canal despachado, com o resultado no relatório | BLOCKED | `mcp.autoteste`: despachar `files/selftest` exige um servidor REST vivo, e a árvore do pacote não é um. O veredito tem teto e piso em `mcp.autoteste_veredito` — autoteste que devolve falha REPROVA a entrega, e ausência da rota fecha BLOCKED, nunca OK |
| Recusa do autoteste a credencial não autorizada | BLOCKED de fase | `mcp.autoteste_recusa_credencial`: não é mensurável de dentro do WordPress rodando como administrador, e a linha nomeia o que falta. Prova fraca com nome de prova negativa foi recusada explicitamente |
| Digesto do artefato baixado por URL | OK | `plugins.digesto_do_artefato`: os três ramos separados, com o limite do ramo TOFU escrito na própria mensagem — fixar na primeira observação defende contra a origem mudar embaixo das execuções seguintes e NÃO defende a primeira busca |
| Host da origem revalidado depois do redirecionamento | OK | `plugins.host_revalidado_apos_salto`: os saltos são seguidos um a um com `redirection = 0`, o host é conferido em cada um, e o corpo desce só do endereço final |
| Alcance da atualização automática, separado da flag | BLOCKED | `plugins.autoupdate_alcance` pede consulta ao WordPress.org por slug, que é rede. A classificação tem teto e piso em `plugins.autoupdate_alcance_separado`: origem `url`, origem `bundle` e artefato do pacote são SEM FONTE, e o resto é pendência nomeada |
| Afirmação de documento conferida contra comportamento medido | OK | `doc.afirmacao_conferida`: o elo mora em `suite/afirmacoes.tsv`, e as três afirmações que a 1.0.17 carregava refutadas pela configuração do mesmo zip estão corrigidas e amarradas |
| Option gravada que ninguém lê de volta | OK | `estatica.option_gravada_sem_leitor`: o irmão de `estatica.detector_chave_sem_consumidor`, que mede "a chave é lida" e não "a leitura muda alguma coisa" — e por isso aprovou `apos_n_ajustes` até a 1.0.17 |
| Rodada limpa amarrada ao hash do pacote aplicado | BLOCKED | `entrega.rodada_limpa` exige uma execução da aplicação em WordPress, com o hash do pacote no checkpoint |
| Identificação do controlador na política publicada | BLOCKED | `privacidade.controlador_identificado` mede o conteúdo SERVIDO; `contato.controlador` nasce vazio e a guarda medida mantém a página fora do ar até ele ser preenchido |
| Mecanismo da cadência do modo somente-relatório | BLOCKED | `cadencia.mecanismo_declarado` fecha BLOCKED enquanto a chave estiver vazia, e ela está: `cadencia_relatorio.mecanismo` depende da hospedagem e é declaração do projeto. A linha existe desde a 1.0.18 — antes dela a frase "mecanismo vazio → o item fecha BLOCKED, não OK" estava em dois documentos e nenhum item do relatório correspondia a ela, porque o único era `cadencia.agendada`, que mede o WP-Cron e fecha OK. O OUVINTE do evento não está em aberto: é o módulo `cadencia-relatorio` do `site-core`, e `cadencia.ouvinte_registrado` mede que o hook tem ouvinte e que as recorrências quinzenal e mensal existem |
| Convergência do estado (terceiro eixo) | BLOCKED nesta base | `entrega.convergencia` fecha pendente porque `contato.controlador`, `contato.whatsapp_e164` e `cadencia_relatorio.mecanismo` nascem vazios: são dado do OPERADOR. Pendência de convergência NÃO segura a autodesativação, e a discordância com a auditoria está escrita — a autodesativação é sobre o ciclo do implantador ter terminado, não sobre o site estar completo |
| Orçamento de página e Core Web Vitals | BLOCKED | medição pede site servindo páginas e tráfego real; a regra que produziria cada número está na tabela da seção anterior |

Os BLOCKED continuam BLOCKED pelo mesmo motivo de sempre: pedem uma instalação servindo
páginas, e a árvore do pacote não é uma. Nenhum deles é defeito. Um manifesto que os
fechasse em OK seria o defeito que este pacote inteiro existe para impedir: um registro
afirmando sobre um artefato que ninguém leu de volta. E a distinção que a 1.0.11 firmou
continua valendo: BLOCKED de FASE declarada não impede a autodesativação — quem a decide
é o gate de APLICAÇÃO, que lê nomes de entregável, nunca a linha de uma unidade.
