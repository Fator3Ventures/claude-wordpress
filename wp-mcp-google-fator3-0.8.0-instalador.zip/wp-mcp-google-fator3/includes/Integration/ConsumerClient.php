<?php
/**
 * Public client bound by object identity to a registered consumer.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class ConsumerClient {
	public function query( array $input ): array {
		return ServiceApi::query( $this, $input );
	}
	public function effective_status(): array {
		return ServiceApi::effective_status( $this );
	}
	public function status(): array {
		return ServiceApi::client_status( $this );
	}
}
