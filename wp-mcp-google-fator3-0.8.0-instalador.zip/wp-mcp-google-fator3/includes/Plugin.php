<?php
/**
 * Ligações do plugin com o WordPress.
 *
 * Nada aqui faz trabalho: só decide quando as outras classes entram em cena. O
 * registro das habilidades acontece em `wp_abilities_api_init`, que dispara
 * tanto no WordPress 6.9+ nativo quanto no polyfill que o servidor MCP carrega.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	public static function init(): void {
		Options::init();
		Integration\ServiceApi::init();
		Automation\CronHistory::init();
		Channel::init();

		add_action( 'wp_abilities_api_categories_init', array( self::class, 'register_category' ) );
		add_action( 'wp_abilities_api_init', array( self::class, 'register_abilities' ) );

		Admin::init();
		Admin\OperationsScreen::init();
		SetupAdmin::init();
		Storage\Migration::init();
		Automation\Jobs::init();
		Cli::init();
		Updater::init();
		McpBridge::init();
		Auth\OAuthFlow::init();
	}

	/**
	 * A categoria precisa existir antes das habilidades; se outro plugin já
	 * registrou 'google', a dele vale — duas categorias com o mesmo slug seriam
	 * a segunda sobrescrevendo a primeira sem aviso.
	 */
	public static function register_category(): void {
		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		if ( function_exists( 'wp_has_ability_category' ) && wp_has_ability_category( 'google' ) ) {
			return;
		}

		wp_register_ability_category(
			'google',
			array(
				'label'       => __( 'Google', 'wp-mcp-google-fator3' ),
				'description' => __( 'Leitura e escrita de Analytics, Ads, Search Console, Site Verification, Sheets, Drive e Tag Manager.', 'wp-mcp-google-fator3' ),
			)
		);
	}

	/** Register the complete packaged catalog; missing runtime modules are build errors. */
	public static function register_abilities(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		Analytics\Abilities::register();

		Ads\Abilities::register();

		Unified\Abilities::register();
		Generic\Abilities::register();
		TagManager\Abilities::register();
		Confirmation::register();
		Policy::register();
		Template::register();
		Updater::register();
		McpBridge::register();
		Storage\AuditReader::register();
		Storage\Migration::register();
		Analytics\AdminWrite::register();
		Analytics\Profile::register();
		Analytics\MeasurementProtocol::register();
		Ads\Mutate::register();
		Ads\WriteAbilities::register();
		SearchConsole\Abilities::register();
		SiteVerification\Abilities::register();
		Unified\Blend::register();
		Sheets\Export::register();
		Setup::register();
		Configuration::register();
		Catalog::register();
		Automation\Reports::register();
		Automation\Jobs::register();
		Automation\Executor::register();
		Automation\Alerts::register();
		SearchConsole\Workflow::register();
		SearchConsole\SiteWorkflow::register();
		Integration\ServiceApi::register();
		Recovery::register();
	}

	/** Detect the compatible Fator3 SDK's observed server; do not initialize it. */
	public static function mcp_server_detected(): bool {
		return ( self::mcp_status()['server_registered'] ?? null ) === true;
	}
	public static function mcp_status(): array {
		return McpServer::status();
	}


	/**
	 * A Abilities API existe nesta instalação?
	 *
	 * Vem do núcleo no WordPress 6.9+, ou de um polyfill carregado por um plugin
	 * de servidor MCP. Sem ela, `wp_abilities_api_init` nunca dispara e este
	 * plugin não registra rota nenhuma.
	 */
	public static function abilities_api_available(): bool {
		return function_exists( 'wp_register_ability' );
	}
}
