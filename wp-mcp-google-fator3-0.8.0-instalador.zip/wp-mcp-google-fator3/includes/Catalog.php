<?php
/**
 * Live ability catalog and local settings share the production rules.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Catalog {

	/** Same registry universe for listing and counting; no availability checks. */
	public static function registered(): array {
		if ( ! function_exists( 'wp_get_abilities' ) ) {
			return array(); }
		return array_filter( (array) wp_get_abilities(), static fn( $ability )=>'google' === $ability->get_category() );
	}
	public static function counts(): array {
		$counts = array(
			'ga'               => 0,
			'ads'              => 0,
			'google'           => 0,
			'gsc'              => 0,
			'siteverification' => 0,
			'gtm'              => 0,
		);
		foreach ( self::registered() as $ability ) {
			$prefix            = explode( '/', $ability->get_name(), 2 )[0];
			$counts[ $prefix ] = ( $counts[ $prefix ] ?? 0 ) + 1;
		}
		$counts['total'] = array_sum( $counts );
		return $counts;
	}
	public static function read( array $input ): array {
		$items  = array();
		$prefix = (string) ( $input['prefix'] ?? '' );
		$mode   = $input['mode'] ?? '';
		foreach ( self::registered() as $ability ) {
			$name = $ability->get_name();
			$meta = $ability->get_meta();
			if ( ( $prefix && ! str_starts_with( $name, $prefix ) ) || ( $mode && ( $meta['fator3']['mode'] ?? '' ) !== $mode ) ) {
				continue;
			}
			$row       = array(
				'name'        => $name,
				'label'       => $ability->get_label(),
				'description' => $ability->get_description(),
				'metadata'    => $meta,
				'available'   => true,
				'local_read'  => Ability::local_read( $name ),
			);
			$connector = $meta['fator3']['connector'] ?? 'any';
			$gate      = Gate::check( $connector );
			$profile   = Operation::profile( $connector, $meta['fator3']['remote_effect'] ?? $meta['fator3']['mode'] ?? 'read' );
			$reason    = $gate['error_code'] ?? ( null !== $profile ? $profile->get_error_code() : null );
			$policy    = Policy::current();
			if ( null === $reason && 'any' !== $connector && 'restricted' === ( $policy['mode'] ?? 'identity' ) && empty( $policy['services'][ $connector ]['resources'] ) ) {
				$reason = 'f3_google_policy_no_resources';
			}
			$row['available']                = null === $reason;
			$row['unavailable_reason']       = $reason;
			$row['availability_scope']       = 'local_configuration_only';
			$row['resource_access_verified'] = false;
			if ( ! empty( $input['include_schemas'] ) ) {
				$row['input_schema']  = $ability->get_input_schema();
				$row['output_schema'] = $ability->get_output_schema();
			}
			$items[ $name ] = $row;
		}
		ksort( $items );
		$offset = max( 0, (int) ( $input['offset'] ?? 0 ) );
		$limit  = max( 1, min( 100, (int) ( $input['limit'] ?? 30 ) ) );
		$slice  = array_values( array_slice( $items, $offset, $limit ) );
		return Response::ok(
			array(
				'catalog_version' => '2.0.0',
				'plugin_version'  => F3_MCP_GOOGLE_VERSION,
				'abilities'       => $slice,
				'total'           => count( $items ),
				'next_offset'     => $offset + count( $slice ) < count( $items ) ? $offset + count( $slice ) : null,
				'authorization'   => 'Channel, actor, connection, service, credential and resource policy are revalidated at execution.',
			)
		);
	}
	public static function configure( array $input ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Gerenciar opções locais exige manage_options.' ) );
		}
		$values = array();
		foreach ( array(
			'audit_local_reads'  => Options::AUDIT_LOCAL_READS,
			'purge_on_uninstall' => 'f3_mcp_google_purge_on_uninstall',
		) as $key => $name ) {
			if ( array_key_exists( $key, $input ) ) {
				if ( ! is_bool( $input[ $key ] ) ) {
					return Response::fail( new \WP_Error( 'f3_google_local_input', 'Opções devem ser booleanas.' ) );
				}
				$values[ $name ] = $input[ $key ];
			}
		}
		foreach ( array(
			'job_detail_days'  => Options::JOB_DETAIL_DAYS,
			'job_summary_days' => Options::JOB_SUMMARY_DAYS,
		) as $key => $name ) {
			if ( isset( $input[ $key ] ) ) {
				$value = $input[ $key ];
				$rule  = Options::LIMITS[ $name ];
				if ( ! is_int( $value ) || $value < $rule['minimum'] || $value > $rule['maximum'] ) {
					return Response::fail( new \WP_Error( 'f3_google_retention_input', 'Retenção fora dos limites.' ) );
				}
				$values[ $name ] = $value;
			}
		}
		return Settings::save( $values, array(), array(), $input['expected_revision'] ?? null );
	}
	public static function register(): void {
		Ability::register(
			'google/ability-catalog',
			'any',
			array(
				'label'        => 'Google: catálogo de habilidades',
				'description'  => 'Catálogo paginado do registro desta versão, com efeitos e schemas opcionais. Consulta local.',
				'input_schema' => array(
					'properties' => array(
						'prefix'          => array( 'type' => 'string' ),
						'mode'            => array(
							'type' => 'string',
							'enum' => array( 'read', 'write' ),
						),
						'include_schemas' => array(
							'type'    => 'boolean',
							'default' => false,
						),
						'offset'          => array(
							'type'    => 'integer',
							'minimum' => 0,
						),
						'limit'           => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
				'callback'     => array( self::class, 'read' ),
			)
		);
		Ability::register(
			'google/configure-local',
			'any',
			array(
				'label'        => 'Google: opções locais de manutenção',
				'description'  => 'Auditar leituras locais e excluir dados públicos na desinstalação são optativos. Credenciais são sempre removidas na desinstalação.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'expected_revision' ),
					'properties' => array(
						'expected_revision'  => array( 'type' => 'string' ),
						'audit_local_reads'  => array( 'type' => 'boolean' ),
						'purge_on_uninstall' => array( 'type' => 'boolean' ),
						'job_detail_days'    => Options::LIMITS[ Options::JOB_DETAIL_DAYS ],
						'job_summary_days'   => Options::LIMITS[ Options::JOB_SUMMARY_DAYS ],
					),
				),
				'callback'     => array( self::class, 'configure' ),
			)
		);
	}
}
