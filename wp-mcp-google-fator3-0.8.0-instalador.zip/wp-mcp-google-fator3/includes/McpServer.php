<?php
/**
 * Local, non-initializing adapter for the public Fator3 server SDK.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class McpServer {
	private const SDK = '\\Fator3\\McpFiles\\ServerContract';
	public static function accepts( $identity ): bool {
		return is_array( $identity )
			&& ( $identity['contract'] ?? null ) === 'server-integration/1.0.0'
			&& ( $identity['provider'] ?? null ) === 'wp-mcp-fator3'
			&& ( $identity['server_id'] ?? null ) === 'wp-mcp-ultimate-server';
	}
	public static function status(): array {
		$base    = array(
			'contract_compatible'          => false,
			'server_registered'            => null,
			'external_connectivity_tested' => false,
			'reason'                       => 'server_sdk_unavailable',
		);
		$state   = 'sdk_unavailable';
		$codes   = array( 'server_sdk_unavailable' );
		$version = null;
		$sdk     = self::SDK;
		if ( class_exists( $sdk ) ) {
			$state = 'sdk_incompatible';
			$codes = array( 'server_sdk_incompatible' );
			if ( is_callable( array( $sdk, 'capabilities' ) ) && is_callable( array( $sdk, 'status' ) ) ) {
				try {
					$caps = $sdk::capabilities();
					if ( is_array( $caps ) && is_string( $caps['version'] ?? null ) && preg_match( '/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/D', $caps['version'] ) ) {
						$version = $caps['version'];
					}
					if ( ! is_array( $caps ) ) {
						$state = 'error';
						$codes = array( 'server_sdk_capabilities_invalid' );
					} elseif ( self::accepts( $caps ) ) {
						$raw = $sdk::status();
						if ( ! self::valid_status( $raw ) ) {
							$state = 'error';
							$codes = array( 'server_sdk_status_invalid' );
						} else {
							$base                        = array_intersect_key( $raw, array_flip( array( 'contract', 'provider', 'server_id', 'route', 'aliases', 'core_loaded', 'server_enabled', 'registry_checked', 'server_registered', 'tools_ready', 'endpoints', 'external_connectivity_tested', 'channel_enabled' ) ) );
							$base['contract_compatible'] = true;
							$base['errors']              = array_values( array_filter( $raw['errors'] ?? array(), static fn( $v )=>is_string( $v ) && (bool) preg_match( '/^[a-z][a-z0-9_]{0,99}$/D', $v ) ) );
							$codes                       = $base['errors'];
							if ( ( $raw['channel_enabled'] ?? null ) === false || ( $raw['server_enabled'] ?? null ) === false ) {
								$state   = 'disabled';
								$codes[] = 'server_disabled';
							} elseif ( array_diff( $codes, array( 'mcp_server_missing', 'mcp_route_missing', 'mcp_route_conflict', 'mcp_tools_missing', 'mcp_core_missing' ) ) ) {
								$state = 'error';
							} elseif ( ( $raw['registry_checked'] ?? null ) !== true ) {
								$state   = 'not_observed';
								$codes[] = 'server_registry_not_observed';
							} elseif ( $codes || ( $raw['server_registered'] ?? null ) !== true || ( $raw['tools_ready'] ?? null ) !== true ) {
								$state   = 'not_ready';
								$codes[] = 'server_registration_incomplete';
							} else {
								$state = 'registered';
							}
						}
					}
				} catch ( \Throwable $e ) {
					$state = 'error';
					$codes = array( 'server_sdk_read_failed' );
				}
			}
		}
		if ( ! $base['contract_compatible'] ) {
			$base['reason'] = $codes[0];
		}
		$base['diagnostic'] = array(
			'state'            => $state,
			'reason_codes'     => array_values( array_unique( $codes ) ),
			'observed_version' => $version,
			'scope'            => 'local_registration',
		);
		return $base;
	}
	private static function valid_status( $raw ): bool {
		if ( ! self::accepts( $raw ) ) {
			return false;
		}
		foreach ( array( 'server_registered', 'registry_checked', 'tools_ready', 'external_connectivity_tested' ) as $key ) {
			if ( ! array_key_exists( $key, $raw ) || ( ! is_bool( $raw[ $key ] ) && null !== $raw[ $key ] ) ) {
				return false;
			}
		}
		foreach ( array( 'core_loaded', 'channel_enabled', 'server_enabled' ) as $key ) {
			if ( isset( $raw[ $key ] ) && ! is_bool( $raw[ $key ] ) ) {
				return false;
			}
		}
		if ( isset( $raw['errors'] ) ) {
			if ( ! is_array( $raw['errors'] ) ) {
				return false; }
			foreach ( $raw['errors'] as $error ) {
				if ( ! is_string( $error ) || ! preg_match( '/^[a-z][a-z0-9_]{0,99}$/D', $error ) ) {
					return false; }
			}
		}
		return true;
	}
	public static function diagnostic_schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'state'            => array(
					'type' => 'string',
					'enum' => array( 'sdk_unavailable', 'sdk_incompatible', 'disabled', 'not_observed', 'not_ready', 'registered', 'error' ),
				),
				'reason_codes'     => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'observed_version' => array( 'type' => array( 'string', 'null' ) ),
				'scope'            => array(
					'type' => 'string',
					'enum' => array( 'local_registration' ),
				),
			),
		);
	}
	public static function message( array $status ): string {
		$messages = array(
			'sdk_unavailable'  => 'SDK MCP compatível ausente. Confira a instalação e ativação do Fator3 MCP.',
			'sdk_incompatible' => 'SDK MCP incompatível. Confira o contrato e os métodos públicos do canal.',
			'disabled'         => 'Canal ou servidor MCP desativado. Confira os controles no Fator3 MCP.',
			'not_observed'     => 'Registro MCP ainda não observado. Faça uma chamada pelo cliente para conferir a conexão.',
			'not_ready'        => 'Registro MCP observado e incompleto. Confira os motivos no diagnóstico local.',
			'registered'       => 'Registro MCP local confirmado. Ferramentas básicas disponíveis; bridges e acesso externo exigem verificação pelo cliente.',
			'error'            => 'Falha na leitura do SDK MCP. Confira os códigos do diagnóstico local.',
		);
		return $messages[ $status['diagnostic']['state'] ?? 'error' ] ?? $messages['error'];
	}
}
