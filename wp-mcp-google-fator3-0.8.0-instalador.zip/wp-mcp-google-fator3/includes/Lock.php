<?php
/**
 * Bounded leases acquired with the database's unique option_name constraint.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Lock {

	public static function acquire( string $resource_id, int $ttl = 180 ): ?array {
		return self::acquire_result( $resource_id, $ttl )['lock'];
	}
	public static function acquire_result( string $resource_id, int $ttl = 180 ): array {
		$key    = 'f3_mcp_google_lock_' . hash( 'sha256', $resource_id );
		$lease  = array(
			'owner'   => bin2hex( random_bytes( 16 ) ),
			'expires' => time() + $ttl,
		);
		$insert = Options::insert_exclusive_result( $key, $lease );
		if ( $insert['success'] ) {
			return array(
				'success'   => true,
				'lock'      => array(
					'key'   => $key,
					'lease' => $lease,
				),
				'code'      => null,
				'retryable' => false,
			); }
		$fail = static fn( $code, $cause, $retryable )=>array(
			'success'    => false,
			'lock'       => null,
			'code'       => $code,
			'cause_code' => $cause,
			'retryable'  => $retryable,
		);
		if ( ! $insert['occupied'] ) {
			return $fail( 'f3_google_lock_storage', $insert['error_code'], false ); }
		$prior = Options::stored( $key );
		if ( ! $prior['success'] ) {
			return $fail( 'f3_google_lock_read', 'f3_google_option_read', false ); }
		if ( ! $prior['exists'] ) {
			return $fail( 'f3_google_lock_busy', 'f3_google_lock_changed', true ); }
		if ( ! is_array( $prior['value'] ) || ! is_int( $prior['value']['expires'] ?? null ) || ! is_string( $prior['value']['owner'] ?? null ) ) {
			return $fail( 'f3_google_lock_read', 'f3_google_lock_invalid', false );
		}
		if ( $prior['value']['expires'] < time() ) {
			if ( ! self::delete_if( $key, $prior['value'] ) ) {
				global $wpdb;
				return $fail( ! empty( $wpdb->last_error ) ? 'f3_google_lock_storage' : 'f3_google_lock_busy', ! empty( $wpdb->last_error ) ? 'f3_google_option_delete' : 'f3_google_lock_changed', empty( $wpdb->last_error ) );
			}
			$insert = Options::insert_exclusive_result( $key, $lease );
			if ( $insert['success'] ) {
				return array(
					'success'   => true,
					'lock'      => array(
						'key'   => $key,
						'lease' => $lease,
					),
					'code'      => null,
					'retryable' => false,
				); }
			if ( ! $insert['occupied'] ) {
				return $fail( 'f3_google_lock_storage', $insert['error_code'], false ); }
		}
		return $fail( 'f3_google_lock_busy', 'f3_google_option_exists', true );
	}
	public static function owned( array $lock ): bool {
		$current = Options::stored( $lock['key'] );
		return $current['success'] && $current['exists'] && $current['value'] === $lock['lease'] && $lock['lease']['expires'] >= time();
	}

	public static function release( array $lock ): void {
		self::delete_if( $lock['key'], $lock['lease'] );
	}
	private static function delete_if( string $key, array $lease ): bool {
		global $wpdb;
		if ( isset( $wpdb ) && is_callable( array( $wpdb, 'get_row' ) ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- Fresh SQL is required for CAS, leases and lifecycle; identifiers are fixed/allowlisted, and variable values use prepare().
			$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $key, maybe_serialize( $lease ) ) );
			if ( function_exists( 'wp_cache_delete' ) ) {
				wp_cache_delete( $key, 'options' );
			}
			return 1 === $deleted;
		}
		if ( get_option( $key ) !== $lease ) {
			return false;
		}
		return delete_option( $key );
	}
}
