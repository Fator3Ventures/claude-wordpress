<?php
/**
 * Fence new work and let admitted operations finish before storage copy.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Storage;

use Fator3\McpGoogle\{
	Ability, Lock, Options, Response
};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class Admission {
	private static ?array $lease = null;
	public static function blocked(): array {
		return Response::fail(
			new \WP_Error( 'f3_google_storage_migrating', 'Armazenamento em migração. Repita após a janela indicada.' ),
			array(
				'retryable'         => true,
				'retry_after_ms'    => 15000,
				'operation_outcome' => 'not_applied',
				'storage_phase'     => Migration::state()['phase'] ?? 'legacy',
			)
		);
	}
	public static function run( string $name, callable $callback ) {
		// A bridge only resolves and authorizes its final target. That target owns
		// admission and recovery checks; otherwise even status/resume is fenced.
		if ( in_array( $name, array( 'google/mcp-read', 'google/mcp-write' ), true ) ) {
			return $callback();
		}
		if ( Ability::local_read( $name ) || in_array( $name, array( 'google/migrate-storage', 'google/recovery', 'google/complete-transition', 'google/executar-vencidos' ), true ) ) {
			return $callback();
		}
		if ( null !== self::$lease ) {
			return self::can_write() ? $callback() : self::blocked();
		}
		$admission = Lock::acquire( 'storage-admission', 30 );
		if ( null === $admission ) {
			return self::blocked();
		}
		try {
			if ( Migration::paused() ) {
				return self::blocked();
			}
			self::$lease = Lock::acquire( 'storage-call:' . bin2hex( random_bytes( 16 ) ), 3600 );
			if ( null === self::$lease ) {
				return self::blocked();
			}
		} finally {
			Lock::release( $admission );
		}
		try {
			return \Fator3\McpGoogle\Recovery::run( $callback );
		} finally {
			Lock::release( self::$lease );
			self::$lease = null;
		}
	}
	public static function can_write(): bool {
		if ( null === self::$lease || ( self::$lease['lease']['expires'] ?? 0 ) <= time() ) {
			return false;
		}
		$stored = Options::stored( self::$lease['key'] );
		return $stored['success'] && $stored['value'] === self::$lease['lease'] && in_array( Migration::state()['phase'] ?? 'legacy', array( 'legacy', 'drain', 'indexed' ), true );
	}
	public static function dispatch_guard(): ?\WP_Error {
		if ( ( Migration::paused() && ! self::can_write() ) || ( null !== self::$lease && ! self::can_write() ) ) {
			return new \WP_Error(
				'f3_google_storage_migrating',
				'Despacho suspenso durante a migração.',
				array(
					'retryable'         => true,
					'retry_after_ms'    => 15000,
					'operation_outcome' => 'not_applied',
				)
			);
		}
		return null;
	}
}
