<?php
/**
 * Durable pass records, independent origin projections and explicit observability failures.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Automation;

use Fator3\McpGoogle\{Connections, Lock, Options, Records};
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class CronHistory {
	private static ?array $invocation = null;
	public static function origin(): string {
		return defined( 'WP_CLI' ) && WP_CLI ? 'cli' : ( ( function_exists( 'wp_doing_cron' ) ? wp_doing_cron() : ( defined( 'DOING_CRON' ) && DOING_CRON ) ) ? 'http_cron' : 'manual' );
	}
	public static function init(): void {
		if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_CLI' ) && method_exists( 'WP_CLI', 'add_hook' ) ) {
			\WP_CLI::add_hook(
				'before_invoke:cron event run',
				static function ( $args ) {
					self::$invocation = self::begin( array_keys( Connections::registry() ), 'wp cron event run', true );
					return $args;
				}
			);
			\WP_CLI::add_hook(
				'after_invoke:cron event run',
				static function ( $args ) {
					if ( self::$invocation ) {
						self::finish( self::$invocation, array(), 'observed' );
						self::$invocation = null; }
					return $args;
				}
			);
		}
	}
	public static function begin( array $connections, string $entry = 'executor', bool $observation = false ): array {
		$frame                = self::$invocation ?? array(
			'run_id' => Records::id(),
			'at'     => time(),
			'origem' => self::origin(),
			'entry'  => $entry,
		);
		$frame['connections'] = $connections;
		$frame['observation'] = $observation;
		$frame['errors']      = array();
		$frame['previous']    = array();
		foreach ( $connections as $cid ) {
			$row   = array(
				'at'                  => $frame['at'],
				'started_at'          => $frame['at'],
				'run_id'              => $frame['run_id'],
				'origem'              => $frame['origem'],
				'entry'               => $frame['entry'],
				'scope'               => $observation ? 'wp_cli_invocation' : 'executor',
				'connection_id'       => $cid,
				'connection_examined' => false,
				'success'             => null,
				'items'               => 0,
				'jobs'                => 0,
				'schedules'           => 0,
				'alerts'              => 0,
				'state'               => 'running',
				'finished_at'         => null,
				'reason_code'         => $observation ? 'google_executor_not_observed' : 'executor_entered',
				'reason_evidence'     => $observation ? 'callback_not_observed' : 'callback_entered',
			);
			$saved = self::save( $row, 'begin' );
			if ( ! empty( $saved['previous'] ) && ( $saved['previous']['scope'] ?? '' ) === 'executor' ) {
				$frame['previous'][ $cid ] = $saved['previous'];
			}
			if ( ! $saved['success'] ) {
				$frame['errors'][ $cid ] = self::record_failure( $row, $saved ); }
		}
		return $frame;
	}
	public static function finish( array $frame, array $results, string $reason = 'completed' ): array {
		$errors = $frame['errors'];
		$passes = array();
		foreach ( $frame['connections'] as $cid ) {
			// Initial recording failure blocks dispatch. Never invent a completed pass.
			if ( isset( $frame['errors'][ $cid ] ) ) {
				continue; }
			$stored  = Options::stored( self::event_key( $cid, $frame['run_id'] ) );
			$context = array(
				'connection_id' => $cid,
				'run_id'        => $frame['run_id'],
				'origem'        => $frame['origem'],
			);
			if ( ! $stored['success'] || ! self::valid_row( $stored['value'] ?? null ) ) {
				$errors[ $cid ] = self::record_failure( $context, self::error( 'f3_google_cron_read', 'finish', 'event', 'f3_google_option_read', false ) );
				continue;
			}
			$row = $stored['value'];
			if ( ! empty( $frame['observation'] ) && 'executor' === $row['scope'] ) {
				$passes[ $cid ] = $row;
				continue;
			}
			$r        = $results[ $cid ] ?? array();
			$previous = $frame['previous'][ $cid ] ?? array();
			if ( $previous ) {
				foreach ( array( 'items', 'jobs', 'schedules', 'alerts' ) as $field ) {
					$r[ $field ] = (int) ( $r[ $field ] ?? 0 ) + (int) ( $previous[ $field ] ?? 0 ); }
				$r['connection_examined'] = ! empty( $r['connection_examined'] ) || ! empty( $previous['connection_examined'] );
				if ( ( $previous['success'] ?? null ) === false ) {
					$r['success'] = false;
					$r['state']   = 'failed'; }
			}
			$row = array_replace(
				$row,
				$r,
				array(
					'finished_at' => time(),
					'state'       => $r['state'] ?? $reason,
				)
			);
			if ( ! empty( $frame['observation'] ) ) {
				// The WP-CLI hook does not expose the final event selection. Do not infer absence.
				$row['reason_code']     = 'google_executor_not_observed';
				$row['reason_evidence'] = 'callback_not_observed';
			} elseif ( empty( $row['connection_examined'] ) ) {
				$row['reason_code']     = $r['reason_code'] ?? 'connection_not_examined';
				$row['reason_evidence'] = 'executor_result';
			} else {
				$row['reason_code']     = $r['reason_code'] ?? ( $row['items'] ? 'work_executed' : 'connection_examined_no_items' );
				$row['reason_evidence'] = 'executor_result';
			}
			$saved = self::save( $row, 'finish' );
			if ( ! $saved['success'] ) {
				$errors[ $cid ] = self::record_failure( $row, $saved ); }
			// This is the work outcome; persisted separately in observability fields.
			$row['history_persisted'] = $saved['success'];
			$passes[ $cid ]           = $row;
		}
		return array(
			'passes'              => $passes,
			'observability_error' => $errors ? $errors : null,
		);
	}
	private static function event_key( string $cid, string $id ): string {
		return 'f3_mcp_google_cron_pass_' . $cid . '_' . $id; }
	private static function valid_row( $row, bool $projection = false ): bool {
		$valid = is_array( $row ) && is_string( $row['run_id'] ?? null ) && is_int( $row['at'] ?? null )
			&& in_array( $row['origem'] ?? null, array( 'cli', 'http_cron', 'manual' ), true )
			&& ( ( $projection && ! isset( $row['scope'] ) ) || in_array( $row['scope'] ?? null, array( 'executor', 'wp_cli_invocation' ), true ) );
		if ( ! $valid ) {
			return false;
		}
		foreach ( array( 'items', 'jobs', 'schedules', 'alerts' ) as $key ) {
			if ( array_key_exists( $key, $row ) && ( ! is_int( $row[ $key ] ) || $row[ $key ] < 0 ) ) {
				return false;
			}
		}
		return ( ! isset( $row['success'] ) || is_bool( $row['success'] ) )
			&& ( ! isset( $row['connection_examined'] ) || is_bool( $row['connection_examined'] ) );
	}
	private static function valid_projection( $state ): bool {
		if ( ! is_array( $state ) ) {
			return false;
		}
		foreach ( array( 'last_pass', 'ultima_cli', 'ultima_http', 'ultima_manual' ) as $key ) {
			// Older projections may lack scope; retain that uncertainty verbatim.
			if ( isset( $state[ $key ] ) && ! self::valid_row( $state[ $key ], true ) ) {
				return false;
			}
		}
		foreach ( array( 'last_success', 'observed_since' ) as $key ) {
			if ( isset( $state[ $key ] ) && ! is_int( $state[ $key ] ) ) {
				return false;
			}
		}
		return true;
	}
	private static function error( string $code, string $phase, string $resource_kind, string $cause, bool $retryable ): array {
		return array(
			'success'    => false,
			'code'       => $code,
			'phase'      => $phase,
			'resource'   => $resource_kind,
			'cause_code' => $cause,
			'retryable'  => $retryable,
			'storage'    => 'wordpress_options',
			'at'         => time(),
		);
	}
	private static function record_failure( array $row, array $result ): array {
		$error                          = array_intersect_key( $result, array_flip( array( 'code', 'phase', 'resource', 'cause_code', 'retryable', 'storage', 'at', 'attempts', 'event_persisted' ) ) );
		$error                         += array(
			'at'            => time(),
			'origem'        => $row['origem'],
			'run_id'        => $row['run_id'],
			'connection_id' => $row['connection_id'],
		);
		$key                            = 'f3_mcp_google_cron_incident_' . $row['connection_id'] . '_' . Records::id();
		$saved                          = Options::set( $key, $error );
		$error['diagnostic_persisted']  = $saved['success'];
		$error['diagnostic_error_code'] = $saved['success'] ? null : ( $saved['error_code'] ?? 'f3_google_option_persistence' );
		// Compatibility projection. Independent incident remains authoritative under concurrency.
		$projected                                = Options::set( 'f3_mcp_google_cron_error_' . $row['connection_id'], $error );
		$error['diagnostic_projection_persisted'] = $projected['success'];
		return $error;
	}
	private static function acquire( string $cid ): array {
		for ( $attempt = 1; $attempt <= 3; ++$attempt ) {
			$r             = Lock::acquire_result( 'cron-history:' . $cid, 30 );
			$r['attempts'] = $attempt;
			if ( $r['success'] || ! $r['retryable'] || 3 === $attempt ) {
				return $r; }
			usleep( 10000 * $attempt );
		}
		return $r;
	}
	/** Called under a short connection lock. Event precedes all projection reads/writes. */
	private static function save( array $row, string $phase ): array {
		$cid      = $row['connection_id'];
		$acquired = self::acquire( $cid );
		if ( ! $acquired['success'] ) {
			return self::error( $acquired['code'], $phase, 'lock', $acquired['cause_code'], $acquired['retryable'] ) + array(
				'attempts'        => $acquired['attempts'],
				'event_persisted' => false,
			);
		}
		try {
			$event = self::event_key( $cid, $row['run_id'] );
			$old   = Options::stored( $event );
			if ( ! $old['success'] || ( $old['exists'] && ! self::valid_row( $old['value'] ) ) ) {
				return self::error( 'f3_google_cron_read', $phase, 'event', 'f3_google_option_read', false );
			}
			// An observer never replaces a child executor. Repeated close is idempotent.
			if ( 'wp_cli_invocation' === $row['scope'] && 'executor' === ( $old['value']['scope'] ?? '' ) ) {
				$row = $old['value'];
			} elseif ( 'begin' === $phase && 'executor' === ( $old['value']['scope'] ?? '' ) ) {
				$row = array_replace( $row, array_intersect_key( $old['value'], array_flip( array( 'items', 'jobs', 'schedules', 'alerts', 'connection_examined', 'success' ) ) ) );
			}
			if ( ! Lock::owned( $acquired['lock'] ) ) {
				return self::error( 'f3_google_lock_lost', $phase, 'lock', 'f3_google_lock_changed', true ); }
			$saved = self::write_retry( $event, $row );
			if ( ! $saved['success'] ) {
				return self::error( 'f3_google_cron_event', $phase, 'event', $saved['error_code'], false ) + array( 'event_persisted' => false );
			}
			$key    = 'f3_mcp_google_cron_history_' . $cid;
			$stored = Options::stored( $key );
			if ( ! $stored['success'] || ( $stored['exists'] && ! self::valid_projection( $stored['value'] ) ) ) {
				return self::error( 'f3_google_cron_read', $phase, 'projection', 'f3_google_option_read', false ) + array( 'event_persisted' => true );
			}
			$state = $stored['value'] ?? array(
				'observed_since'  => $row['at'],
				'window_complete' => false,
			);
			$state = self::project( $state, $row );
			if ( ! Lock::owned( $acquired['lock'] ) ) {
				return self::error( 'f3_google_lock_lost', $phase, 'lock', 'f3_google_lock_changed', true ) + array( 'event_persisted' => true ); }
			$saved = self::write_retry( $key, $state );
			if ( ! $saved['success'] ) {
				return self::error( 'f3_google_cron_projection', $phase, 'projection', $saved['error_code'], false ) + array( 'event_persisted' => true );
			}
			return array(
				'success'         => true,
				'event_persisted' => true,
				'previous'        => $old['value'],
				'attempts'        => $acquired['attempts'],
			);
		} finally {
			Lock::release( $acquired['lock'] ); }
	}
	private static function write_retry( string $key, array $value ): array {
		// Repeats only idempotent history storage, never a job or an HTTP request.
		for ( $attempt = 0; $attempt < 3; ++$attempt ) {
			$saved = Options::set( $key, $value );
			if ( $saved['success'] ) {
				break; }
			if ( $attempt < 2 ) {
				usleep( 10000 ); }
		}
		return $saved;
	}
	private static function project( array $state, array $row ): array {
		$field = array(
			'cli'       => 'ultima_cli',
			'http_cron' => 'ultima_http',
			'manual'    => 'ultima_manual',
		)[ $row['origem'] ];
		foreach ( array_merge( array( $field ), 'executor' === $row['scope'] ? array( 'last_pass' ) : array() ) as $f ) {
			$prior = $state[ $f ] ?? null;
			if ( ! $prior || array( $row['at'], $row['run_id'] ) >= array( $prior['at'], $prior['run_id'] ) ) {
				$state[ $f ] = $row; }
		}
		if ( ( $row['success'] ?? null ) === true && $row['at'] > ( $state['last_success'] ?? 0 ) ) {
			$state['last_success'] = $row['at']; }
		return $state;
	}
	/** Explicit maintenance, also used by cleanup; no dispatch and no invented event. */
	public static function reconcile( string $cid ): array {
		$lock = self::acquire( $cid );
		if ( ! $lock['success'] ) {
			return self::error( $lock['code'], 'reconcile', 'lock', $lock['cause_code'], $lock['retryable'] ); }
		try {
			$read = Options::stored( 'f3_mcp_google_cron_history_' . $cid );
			if ( ! $read['success'] || ( $read['exists'] && ! self::valid_projection( $read['value'] ) ) ) {
				return self::error( 'f3_google_cron_read', 'reconcile', 'projection', 'f3_google_option_read', false ); }
			$state = $read['value'] ?? array(
				'observed_since'  => time(),
				'window_complete' => false,
			);
			$names = self::names( $cid, 10001, true );
			if ( is_wp_error( $names ) || count( $names ) > 10000 ) {
				return self::error( 'f3_google_cron_read', 'reconcile', 'event', 'f3_google_cron_window_incomplete', false ); }
			foreach ( $names as $name ) {
				$r = Options::stored( $name );
				if ( ! $r['success'] || ! self::valid_row( $r['value'] ) ) {
					return self::error( 'f3_google_cron_read', 'reconcile', 'event', 'f3_google_option_read', false ); }
				$state = self::project( $state, $r['value'] );
			}
			if ( ! Lock::owned( $lock['lock'] ) ) {
				return self::error( 'f3_google_lock_lost', 'reconcile', 'lock', 'f3_google_lock_changed', true ); }
			$error = Options::stored( 'f3_mcp_google_cron_error_' . $cid );
			if ( $error['success'] && is_string( $error['value']['run_id'] ?? null ) ) {
				$state['reconciled_through_run'] = $error['value']['run_id']; }
			$saved = self::write_retry( 'f3_mcp_google_cron_history_' . $cid, $state );
			return $saved['success'] ? array(
				'success' => true,
				'events'  => count( $names ),
			) : self::error( 'f3_google_cron_projection', 'reconcile', 'projection', $saved['error_code'], false );
		} finally {
			Lock::release( $lock['lock'] ); }
	}
	public static function summary( string $cid, ?int $now = null ): array {
		$now        = $now ?? time();
		$base       = array(
			'last_pass'                       => null,
			'ultima_cli'                      => null,
			'ultima_http'                     => null,
			'ultima_manual'                   => null,
			'last_success'                    => null,
			'cron_servidor_ativo'             => false,
			'executor'                        => 'wp-cron',
			'agendamento_verificado'          => false,
			'passagens_24h'                   => array(
				'cli'       => 0,
				'http_cron' => 0,
				'manual'    => 0,
			),
			'observed_since'                  => null,
			'window_complete'                 => false,
			'observability_error'             => null,
			'last_observability_error'        => null,
			'projection_reconciled_in_memory' => false,
		);
		$s          = Options::stored( 'f3_mcp_google_cron_history_' . $cid );
		$read_error = ! $s['success'] || ( $s['exists'] && ! self::valid_projection( $s['value'] ) );
		if ( ! $read_error ) {
			$base = array_replace( $base, array_intersect_key( $s['value'] ?? array(), array_flip( array( 'last_pass', 'ultima_cli', 'ultima_http', 'ultima_manual', 'last_success', 'observed_since' ) ) ) ); }
		$complete = ! $read_error;
		$names    = self::names( $cid, 10001, true );
		if ( is_wp_error( $names ) ) {
			$complete = false; } else {
			$complete = $complete && count( $names ) <= 10000;
			foreach ( array_slice( $names, 0, 10000 ) as $name ) {
				$r = Options::stored( $name );
				if ( ! $r['success'] || ! self::valid_row( $r['value'] ) ) {
					$read_error = true;
					$complete   = false;
					continue; }
				$row    = $r['value'];
				$before = $base;
				$base   = self::project( $base, $row );
				if ( $base !== $before ) {
					$base['projection_reconciled_in_memory'] = true; }
				if ( $row['at'] > $now - 86400 && $row['at'] <= $now ) {
					++$base['passagens_24h'][ $row['origem'] ]; }
			}
			}
			$incident_names = self::names( $cid, 1, true, 'incident' );
			$error          = is_wp_error( $incident_names ) ? array( 'success' => false ) : Options::stored( $incident_names[0] ?? 'f3_mcp_google_cron_error_' . $cid );
			if ( ! $error['success'] ) {
				$read_error = true; } elseif ( is_array( $error['value'] ?? null ) ) {
						$base['last_observability_error'] = $error['value'];
				if ( ( $error['value']['at'] ?? 0 ) > $now - 86400 ) {
					$base['observability_error'] = $error['value']; }
				}
				if ( $read_error || is_wp_error( $names ) ) {
					$base['observability_error'] = self::error( 'f3_google_cron_read', 'summary', 'history', 'f3_google_option_read', false );
				}
				foreach ( array( 'last_pass', 'ultima_cli', 'ultima_http', 'ultima_manual' ) as $f ) {
					if ( is_array( $base[ $f ] ) && ( $base[ $f ]['state'] ?? '' ) === 'running' && $base[ $f ]['at'] < $now - 120 ) {
						$base[ $f ]['state']           = 'interrupted';
						$base[ $f ]['success']         = null;
						$base[ $f ]['reason_code']     = 'completion_not_recorded';
						$base[ $f ]['reason_evidence'] = 'history_only';
					}
				}
				$at                          = $base['ultima_cli']['at'] ?? null;
				$base['cron_servidor_ativo'] = ! $read_error && ! is_wp_error( $names ) && is_int( $at ) && $at <= $now && $at >= $now - 7200;
				$base['executor']            = $base['cron_servidor_ativo'] ? 'server-cron' : 'wp-cron';
				$base['legacy_last_pass']    = get_option( 'f3_mcp_google_executor_last_' . $cid, null );
				$base['window_complete']     = $complete && ! $base['observability_error'] && is_int( $base['observed_since'] ) && $base['observed_since'] <= $now - 86400;
				return $base;
	}
	public static function schema(): array {
		$pass  = array(
			'type'       => array( 'object', 'null' ),
			'properties' => array(
				'at'                  => array( 'type' => 'integer' ),
				'started_at'          => array( 'type' => 'integer' ),
				'finished_at'         => array( 'type' => array( 'integer', 'null' ) ),
				'run_id'              => array( 'type' => 'string' ),
				'origem'              => array(
					'type' => 'string',
					'enum' => array( 'cli', 'http_cron', 'manual' ),
				),
				'scope'               => array(
					'type' => 'string',
					'enum' => array( 'executor', 'wp_cli_invocation' ),
				),
				'connection_id'       => array( 'type' => 'string' ),
				'connection_examined' => array( 'type' => 'boolean' ),
				'success'             => array( 'type' => array( 'boolean', 'null' ) ),
				'items'               => array( 'type' => 'integer' ),
				'state'               => array( 'type' => 'string' ),
				'reason_code'         => array( 'type' => 'string' ),
				'reason_evidence'     => array( 'type' => 'string' ),
			),
		);
		$error = array(
			'type'       => array( 'object', 'string', 'null' ),
			'properties' => array(
				'code'                  => array( 'type' => 'string' ),
				'at'                    => array( 'type' => 'integer' ),
				'origem'                => array( 'type' => 'string' ),
				'run_id'                => array( 'type' => 'string' ),
				'connection_id'         => array( 'type' => 'string' ),
				'phase'                 => array( 'type' => 'string' ),
				'cause_code'            => array( 'type' => 'string' ),
				'storage'               => array( 'type' => 'string' ),
				'resource'              => array( 'type' => 'string' ),
				'retryable'             => array( 'type' => 'boolean' ),
				'event_persisted'       => array( 'type' => 'boolean' ),
				'diagnostic_persisted'  => array( 'type' => 'boolean' ),
				'diagnostic_error_code' => array( 'type' => array( 'string', 'null' ) ),
			),
		);
		return array(
			'type'       => 'object',
			'properties' => array(
				'last_pass'                       => $pass,
				'ultima_cli'                      => $pass,
				'ultima_http'                     => $pass,
				'ultima_manual'                   => $pass,
				'cron_servidor_ativo'             => array( 'type' => 'boolean' ),
				'executor'                        => array(
					'type' => 'string',
					'enum' => array( 'server-cron', 'wp-cron' ),
				),
				'agendamento_verificado'          => array( 'type' => 'boolean' ),
				'window_complete'                 => array( 'type' => 'boolean' ),
				'observability_error'             => $error,
				'last_observability_error'        => $error,
				'projection_reconciled_in_memory' => array( 'type' => 'boolean' ),
			),
		);
	}
	private static function names( string $cid, int $limit, bool $newest, string $kind = 'pass' ) {
		global $wpdb;
		try {
			$prefix = 'f3_mcp_google_cron_' . $kind . '_' . $cid . '_';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- Fresh bounded history read; names/limit use placeholders, ordering is a boolean choice of fixed SQL literals.
			$rows = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s ORDER BY option_name " . ( $newest ? 'DESC' : 'ASC' ) . ' LIMIT %d', $wpdb->esc_like( $prefix ) . '%', $limit ) );
			return $wpdb->last_error || ! is_array( $rows ) ? new \WP_Error( 'f3_google_cron_read', 'Histórico ilegível.' ) : $rows;
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'f3_google_cron_read', 'Histórico ilegível.' ); }
	}
	public static function cleanup(): void {
		foreach ( array_keys( Connections::registry() ) as $cid ) {
			$error      = Options::stored( 'f3_mcp_google_cron_error_' . $cid );
			$projection = Options::stored( 'f3_mcp_google_cron_history_' . $cid );
			if ( $error['success'] && ! empty( $error['value']['event_persisted'] ) && strcmp( $error['value']['run_id'] ?? '', $projection['value']['reconciled_through_run'] ?? '' ) > 0 ) {
				self::reconcile( $cid ); }
			foreach ( array( 'pass', 'incident' ) as $kind ) {
				$names = self::names( $cid, 100, false, $kind );
				if ( is_wp_error( $names ) ) {
					continue; }
				foreach ( $names as $name ) {
					$row = Options::stored( $name );
					// Eight days cover the seven-day operational window with a collection margin.
					if ( $row['success'] && is_array( $row['value'] ) && ( $row['value']['at'] ?? PHP_INT_MAX ) < time() - 8 * 86400 ) {
						Options::delete( $name ); }
				}
			}
		}
	}
}
