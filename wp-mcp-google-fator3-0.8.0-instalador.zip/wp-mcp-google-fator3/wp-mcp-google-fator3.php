<?php
/**
 * Plugin Name:       Fator3 MCP Google
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Google Analytics 4, Google Ads, Search Console, Tag Manager, Site Verification, Sheets e Drive em leitura e escrita pela Abilities API e pelo Fator3 MCP, com conta técnica, limite de uso e auditoria. Configuração em Ferramentas → Fator3 MCP Google.
 * Update URI:        https://fator3.com.br/plugins/wp-mcp-google-fator3
 * Version:           0.8.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            Fator3
 * Author URI:        https://www.fator3.com.br
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-mcp-google-fator3
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Duas cópias ativas ao mesmo tempo seriam erro fatal — as classes têm o mesmo
 * nome. Acontece quando a pasta do plugin muda e o WordPress trata a nova como
 * instalação separada. A segunda cópia a carregar sai de campo com um aviso em
 * vez de derrubar o site.
 */
if ( defined( 'F3_MCP_GOOGLE_VERSION' ) || class_exists( __NAMESPACE__ . '\\Options', false ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			printf(
				'<div class="notice notice-error"><p><strong>Fator3 MCP Google:</strong> %s</p></div>',
				esc_html__( 'outra cópia deste plugin já está ativa. Desative e apague a duplicada; enquanto isso, esta não carrega.', 'wp-mcp-google-fator3' )
			);
		}
	);

	return;
}

define( 'F3_MCP_GOOGLE_VERSION', '0.8.0' );
define( 'F3_MCP_GOOGLE_FILE', __FILE__ );
define( 'F3_MCP_GOOGLE_DIR', plugin_dir_path( __FILE__ ) );

require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/Candidate.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Options.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Uninstall.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Crypto.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Connections.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Records.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Storage/Repository.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Storage/Migration.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Storage/DateFilter.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Storage/AuditReader.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Lock.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Audit.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Response.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Settings.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/Configuration.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Gate.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Operation.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Confirmation.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Telemetry.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Policy.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Template.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Updater.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/McpServer.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/McpBridge.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Channel.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Storage/Admission.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ability.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/CredentialsInterface.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/Credentials.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/ServiceAccount.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/OAuthUser.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Auth/OAuthFlow.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Execution.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Context.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/FrozenInput.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SearchConsole/Quota.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Http/GoogleClient.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Http/PublicPage.php';

/**
 * Os três módulos de habilidades, na ordem de dependência.
 *
 * `require_once` direto, e não um `file_exists` condicional: durante o
 * desenvolvimento em fases fazia sentido tolerar um arquivo ausente, mas agora
 * todos existem — e uma carga silenciosamente parcial (um arquivo apagado por
 * um upload incompleto, por exemplo) apareceria só lá na frente, como "rota
 * não encontrada", em vez de falhar aqui dizendo qual arquivo falta.
 */
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/PropertyId.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/AdminApi.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/CatalogReader.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/Profile.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/DataApi.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/Abilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/CustomerId.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/Gaql.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/AdsApi.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/Resources.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/Abilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/DateRange.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/Catalog.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/Filters.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/Accounts.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/Query.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/Abilities.php';

require_once F3_MCP_GOOGLE_DIR . 'includes/Generic/Discovery.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Generic/ExecuteAction.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Generic/Abilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/AdminWrite.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Analytics/MeasurementProtocol.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/Mutate.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/WriteAbilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Ads/Conversions.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SearchConsole/Api.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SearchConsole/Abilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SearchConsole/Workflow.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SearchConsole/SiteWorkflow.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SiteVerification/Abilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Unified/Blend.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Sheets/Export.php';

require_once F3_MCP_GOOGLE_DIR . 'includes/Admin/Fields.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Admin/Resources.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Admin/Screen.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Admin/OperationsScreen.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Admin.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SelfTest.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Preflight.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/CoreBinding.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Setup.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Configuration.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Catalog.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SetupAdmin.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Reports.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Results.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Worker.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Operations.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Executor.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Alerts.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Cli.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Jobs.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/Approval.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/TagManager/Api.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/TagManager/Abilities.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/TagManager/Publish.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/TagManager/Diagnostic.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Recovery.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Automation/CronHistory.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/SearchConsole/AnalyticsBudget.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Integration/Context.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Integration/ConsumerClient.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Integration/Transition.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Integration/ServiceApi.php';
require_once F3_MCP_GOOGLE_DIR . 'includes/Plugin.php';

Plugin::init();

/**
 * Ativar já é o ato humano explícito: o canal nasce aberto, com Analytics ligado
 * e Ads aguardando seleção explícita. Sem credencial nada funciona mesmo, então abrir por
 * padrão não expõe nada — só evita uma volta a mais na configuração.
 */
register_activation_hook(
	__FILE__,
	static function (): void {
		add_option( Options::ENABLED, true, '', true );
		add_option( Options::GA_ENABLED, true, '', true );
		add_option( Options::ADS_ENABLED, false, '', true );
		add_option( Options::AUTH_MODE, 'service_account', '', true );
		add_option( Options::ADS_API_VERSION, Options::ADS_VERSION_DEFAULT, '', true );
		add_option( Options::MAX_ROWS, Options::LIMITS[ Options::MAX_ROWS ]['default'], '', true );
		add_option( Options::HTTP_TIMEOUT, Options::LIMITS[ Options::HTTP_TIMEOUT ]['default'], '', true );
	}
);

/**
 * Desativar já tira as habilidades do registro; a credencial fica para quem
 * reativar. Desinstalar apaga segredos; a limpeza adicional é optativa.
 */
register_deactivation_hook(
	__FILE__,
	static function ( bool $network_wide = false ): void {
		Uninstall::on_deactivation( $network_wide );
	}
);

/**
 * Protege as opções deste plugin contra a habilidade options/update.
 *
 * A lista padrão do WP MCP Ultimate cobre uns poucos nomes fixos e libera o
 * resto. Sem isto, um agente poderia reabrir o canal depois de você fechá-lo,
 * trocar a versão da API ou apagar o log de auditoria com um options/update.
 * Os segredos já são invisíveis à leitura (ver Options::init), mas gravar é
 * outra operação.
 */
add_filter(
	'wp_mcp_ultimate_protected_options',
	static function ( $protected_options ) {
		if ( ! is_array( $protected_options ) ) {
			$protected_options = array();
		}

		return array_values( array_unique( array_merge( $protected_options, Options::all_names() ) ) );
	}
);

/**
 * Avisos no admin — apenas pré-requisito ausente.
 *
 * Sem a Abilities API o plugin ativa, a tela diz "ABERTO" e nada funciona:
 * é falha silenciosa, e isso precisa gritar.
 */
add_action(
	'admin_notices',
	static function (): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! Plugin::abilities_api_available() ) {
			printf(
				'<div class="notice notice-error"><p><strong>Fator3 MCP Google:</strong> %s</p></div>',
				esc_html__( 'a Abilities API do WordPress não está disponível, então NENHUMA rota foi registrada e o plugin não faz nada. Ela vem no WordPress 6.9 ou superior; em versões anteriores, é preciso um plugin de servidor MCP que traga o polyfill.', 'wp-mcp-google-fator3' )
			);

			return;
		}
	}
);

/**
 * Atalho "Configurar" na linha do plugin.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	static function ( $links ) {
		if ( ! is_array( $links ) ) {
			$links = array();
		}

		array_unshift(
			$links,
			'<a href="' . esc_url( admin_url( 'tools.php?page=' . Admin::SLUG ) ) . '">'
				. esc_html__( 'Configurações', 'wp-mcp-google-fator3' ) . '</a>'
		);

		return $links;
	}
);
