# Fator3 Site Core 1.89.1

Versão 1.89.1. Catálogo ampliado com Infinix SMART 8 Pro e Multilaser M7 Wi-Fi. Consulte docs/RELEASE-1.89.1.md.

Instalação nova ou atualização da 1.89.0. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
