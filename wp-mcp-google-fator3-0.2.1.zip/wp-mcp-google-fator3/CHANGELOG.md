# Histórico

## 0.2.1 — 2026-09-09

- Corrige HTTP 411 em `gsc/submit-sitemap`: o cliente HTTP envia `Content-Length: 0` em PUT com corpo vazio.
- Aplica a correção também a `gsc/add-site` e a métodos PUT sem corpo executados por `google/execute-action`.
- Preserva corpos JSON, formulários e uploads com conteúdo; mantém o contrato sem corpo da Search Console.
- Inclui testes de regressão e reprodução HTTP local com o transporte Requests/Fsockopen do WordPress.

## 0.2.0 — 2026-09-08

- Preserva as 21 habilidades e configurações da 0.1.0; acrescenta 93 habilidades.
- Adiciona Search Console, Site Verification, GA Admin em escrita, Ads em escrita, Measurement Protocol, blend e exportação para Sheets/Drive.
- Expõe catálogo e executor baseados em nove documentos oficiais, com 521 métodos no conjunto validado.
- Acrescenta anotações de escrita, auditoria before/after redigida, validateOnly Ads, erros acionáveis e diagnóstico de APIs/escopos.
- Resolve contas por nome e wildcard; inclui conversões customizadas Ads, catálogos completos e isolamento de caches por credencial/delegação.
- Corrige colisão de IDs numéricos em fanout, paginação incompleta/cíclica, repetição indevida de gravações e codificação de objetos JSON vazios.
- Conserva integração com as três metatools e URL do servidor WP MCP Fator3.

## 0.1.0 — base recebida

21 habilidades de leitura Analytics/Ads/camada unificada, service account e OAuth de usuário, cifra, configuração administrativa, portão geral e auditoria de metadados.
