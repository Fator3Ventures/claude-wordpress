# WP MCP Google Fator3 0.2.1

Plugin complementar ao **WP MCP Fator3**. Integra Google Analytics 4, Google Ads, Search Console, Site Verification, Sheets e Drive pela Abilities API do WordPress, em leitura e escrita.

A versão registra **114 habilidades: 39 de leitura e 75 de escrita**, preservando as 21 da 0.1.0. A execução genérica alcança os **521 métodos** presentes nos nove documentos oficiais de descoberta usados na validação desta entrega. Esse número acompanha a evolução dos documentos, das versões e da opção de versão do Ads.

## Correção 0.2.1

Corrige HTTP 411 (`Length Required`) no envio de sitemap. O cliente HTTP envia `Content-Length: 0` em PUT sem corpo, atendendo também `gsc/add-site` e `google/execute-action`. Corpos JSON e uploads com conteúdo são preservados. As credenciais, opções e habilidades permanecem compatíveis com 0.2.0.

## Instalação e atualização

1. Mantenha o WP MCP Fator3 ativo.
2. Em **Plugins → Adicionar plugin → Enviar plugin**, envie `wp-mcp-google-fator3-0.2.1.zip`. Se uma versão anterior estiver instalada, escolha substituir a versão atual. A pasta e o arquivo principal continuam `wp-mcp-google-fator3/wp-mcp-google-fator3.php`.
3. Configure ou confira a credencial em **Ferramentas → MCP Google**. A atualização conserva opções, credenciais cifradas, capacidade exigida e estado dos interruptores existentes.
4. Pelo conector atual, execute `google/status`, descubra as habilidades e faça uma consulta de leitura aos serviços utilizados.

Não desinstale a versão Google antes de atualizar: o desinstalador apaga suas credenciais. A atualização por substituição do ZIP preserva os dados. O ZIP `src` é o pacote de desenvolvimento; use o ZIP sem `src` no WordPress.

## URL e ferramentas do conector

Este complemento usa o servidor do Fator3, sem criar outro endpoint MCP. Na configuração padrão do Fator3 0.9.0, a conexão continua:

```text
https://SEU-DOMINIO/wp-json/mcp/wp-mcp-ultimate
```

Se seu servidor usa uma URL personalizada, mantenha essa URL. As três metatools — Discover Abilities, Get Ability Info e Execute Ability — continuam sendo a entrada para todas as habilidades Google. Atualize a descoberta do cliente se ele guardar o catálogo em cache.

O callback de autenticação Google é separado e também foi preservado:

```text
https://SEU-DOMINIO/wp-json/wp-mcp-google-fator3/v1/oauth/callback
```

## Requisitos

- WordPress 6.4+ com Abilities API: nativa em 6.9+, ou fornecida pelo servidor MCP nas versões anteriores.
- PHP 8.0+, JSON, OpenSSL para service accounts; libsodium ou OpenSSL/AES-GCM para cifra local.
- APIs habilitadas no projeto Google Cloud e acesso da credencial às contas, propriedades e arquivos necessários.
- Google Ads exige developer token e, quando aplicável, login customer ID da administradora.

A base 0.2.0 foi validada com PHP 8.3.6 e WordPress 6.9.4 e 6.8.3, incluindo compatibilidade estática com PHP 8.0. Na correção 0.2.1, foram executados 763 testes PHPUnit (8.380 asserções), sintaxe dos 45 PHP de produção e teste HTTP local com Requests/Fsockopen 2.0.11 em PHP 8.3.6. Não houve nova integração completa com WordPress/MariaDB nem chamada às contas Google reais nesta correção.

## Autenticação, escopos e permissões

Uma credencial ativa por site; mantidos os modos service account e OAuth de usuário da 0.1.0. Delegação Workspace continua opcional. No OAuth, reconecte a conta para autorizar os novos escopos; emitir um novo access token com um refresh token antigo não amplia o consentimento.

| Serviço | Escopos usuais | Acesso necessário |
|---|---|---|
| Analytics | `analytics.readonly`, `analytics.edit`, `analytics.manage.users` | Leitor para relatórios; Editor para alterações; Administrador para usuários |
| Ads | `adwords` | Papel suficiente na conta/MCC e developer token aprovado para o ambiente |
| Search Console | `webmasters` | Acesso à propriedade exata; proprietário para operações que o exigem |
| Site Verification | `siteverification` | Provar controle do site ou domínio pelo método escolhido |
| Sheets | `spreadsheets` | Edição da planilha compartilhada com a credencial |
| Drive | `drive.file` | Acesso ao arquivo/pasta e papel necessário para compartilhamento |

O executor genérico seleciona escopo aceito pelo método oficial; alguns métodos exigem escopos diferentes dos usuais. Métodos disponíveis no catálogo não concedem papéis, não habilitam APIs nem contornam requisitos do Google.

`google/status` separa escopos solicitados, escopos registrados na última autorização OAuth e habilitação observada de APIs. Em service accounts, `scopes_granted` é `null`: não há consentimento OAuth de usuário a declarar. Uma API sem chamada observada aparece com `enabled: null`; emissão de token não comprova acesso ao recurso.

## Habilidades

| Família | Quantidade | Conteúdo |
|---|---:|---|
| `ga/*` | 45 | Relatórios, tempo real, funis, atribuição; propriedades, contas, streams, eventos-chave, dimensões/métricas, retenção, sinais, anotações, públicos, vínculos, usuários e Measurement Protocol |
| `ads/*` | 46 | GAQL e catálogo; campanhas, orçamentos, grupos, anúncios, critérios, conversões, Customer Match, assets, PMax, experimentos, rótulos, públicos, usuários, faturamento e mutate genérico |
| `gsc/*` | 9 | Sites, Search Analytics, sitemaps e inspeção de URL |
| `siteverification/*` | 4 | Token, verificação, proprietários e listagem |
| `google/*` | 10 | Status, autoteste, contas, campos, consultas, blend, exportação, catálogo genérico, execução e auditoria |

Consulte `get-ability-info` para o contrato de cada habilidade. O pacote-fonte contém `CATALOGO-HABILIDADES.md`, o manifesto completo de schemas e exemplos exercitados nos testes.

As rotas GA de escrita recebem `body` com campos oficiais, seletores de recurso e `update_mask` quando aplicável. As rotas Ads recebem `resource`, `resources` ou `resource_names`, conforme a operação, com campos oficiais camelCase. IDs de recurso seguem o formato da API. Obtenha o schema antes de montar uma gravação.

### Consulta unificada

```json
{"connector":"ga4","accounts":["Nome único da propriedade"],"metrics":["sessions","activeUsers"],"dimensions":["date"],"date_range":"last_30_days"}
```

Aceita `ga4`, `google-ads` e `search-console`; aliases `ga`, `ads` e `gsc`. `accounts:["*"]` expande o catálogo acessível. Nomes ambíguos retornam candidatos. Listagem incompleta ou com erro impede resolver nomes e wildcard como se fosse completa; IDs explícitos continuam utilizáveis.

As rotas nomeadas resolvem `property_id`, `customer_id` ou `site_url` por nome. `*` nesses seletores executa a operação em cada alvo e devolve os resultados individuais. Um wildcard de escrita pode alterar várias contas: a confirmação do agente deve abranger os alvos concretos. Seletores de subrecursos continuam usando IDs/nomes oficiais.

Para Ads, `google/list-fields` com `account_id` acrescenta `conversions:<nome>` e `conversions_value:<nome>`. Consultas com essas métricas separam totais comuns das conversões segmentadas, evitando duplicar cliques e custo.

### Descoberta e execução genérica

```json
{"api":"analytics-admin-v1alpha","task":"audience","limit":10}
```

Envie a entrada acima a `google/list-actions`. Use o `id`, os parâmetros e o schema retornados em `google/execute-action`:

```json
{"api":"analytics-admin-v1alpha","method":"analyticsadmin.properties.get","path_params":{"name":"properties/123456"}}
```

O método ilustrado lê uma propriedade; a ferramenta genérica é anotada como escrita porque também executa mutações. Sua URL é sempre derivada do documento oficial. O catálogo tem cache de 24 horas, busca textual sobre documentação majoritariamente em inglês e paginação. Métodos inexistentes, parâmetros desconhecidos, caminhos fora do documento e substituição de credencial via query são recusados.

APIs: `analytics-admin-v1alpha`, `analytics-admin-v1beta`, `analytics-data-v1beta`, `analytics-data-v1alpha`, `google-ads`, `search-console`, `site-verification`, `sheets`, `drive`. Upload multipart inline aceita até 20 MiB nos métodos que o documentam; downloads não JSON retornam conteúdo em base64 e seu tipo.

### Blend e Sheets

`google/blend` recebe de 2 a 10 `queries`, opcionalmente envolvidas por `{query:{...},prefix:"..."}`, e `on:["date"]`, com `campaign` ou `page` quando necessário. Faz junção externa completa, prefixa colunas, preserva períodos comparados, mantém células ausentes como `null` e informa linhas sem par. Chaves duplicadas são recusadas para evitar multiplicação de métricas.

```json
{"query":{"connector":"google-ads","accounts":["1234567890"],"metrics":["clicks","cost"],"dimensions":["date"],"date_range":"last_30_days"},"spreadsheet_id":"ID_DA_PLANILHA","tab_name":"Ads","mode":"replace"}
```

Envie a `google/export-to-sheet`. Aceita uma query, um blend ou várias consultas; `replace` substitui valores da aba e `append` exige cabeçalho correspondente. Células são literais, sem inferir fórmulas. Até 20 abas, 500.000 células e 8 MiB de payload por exportação. Escrita das abas em um batch atômico; compartilhamento posterior pode falhar separadamente, com ID e alterações confirmadas devolvidos.

**Service accounts não possuem quota no Meu Drive.** Para criar planilha, use `shared_drive_folder_id` de um Drive compartilhado, OAuth de usuário ou delegação configurada. Alternativamente, informe uma planilha existente compartilhada. Uma pasta comum compartilhada do Meu Drive não é um Drive compartilhado. [Limites oficiais do Drive](https://developers.google.com/workspace/drive/api/guides/handle-errors).

## Escrita, dry run e auditoria

Gravações são imediatas, sem interruptor separado de escrita, confirmação em duas fases ou reversão. O portão geral e a capacidade `manage_options` permanecem. A skill do agente deve obter confirmação para a gravação concreta antes de executá-la; autorização já concedida não deve ser pedida novamente para a mesma operação.

Em Ads, `dry_run:true` usa `validateOnly` real. Métodos sem suporte recusam o pedido antes de gravar: inclui billing setups, acesso/convites de usuários, Sheets e Drive. Validar Customer Match sem criar um job exige job existente. Measurement Protocol `debug:true` valida payload e não coleta eventos, nem comprova validade do api_secret. HTTP 2xx na coleta confirma transporte, não processamento dos eventos.

Escritas não são repetidas automaticamente após erro de rede/5xx. `partial_failure` pode indicar alterações aplicadas; inspecione os resultados antes de repetir. Operações assíncronas retornam referências para acompanhamento, sem prometer conclusão imediata.

`google/audit` filtra o log circular de 100 entradas. Toda escrita registra modo, resultado, dry_run e `before`/`after` limitados a 4 KiB cada, com segredos e identificadores de Customer Match redigidos. Estados impossíveis de recuperar são marcados como indisponíveis. A auditoria não é backup e não oferece reversão.

## Limites relevantes do Google e do escopo

- Customer Match via Ads continua sujeito à elegibilidade da integração. Desde abril de 2026, muitas novas integrações devem usar Data Manager API, que não integra este plugin. [Documentação oficial](https://developers.google.com/google-ads/api/docs/remarketing/audience-segments/customer-match/manage).
- Verificação de domínio exige publicação de token no DNS; o plugin fornece o token. Publicação de arquivos/META/DNS cabe às ferramentas do site.
- Search Console não oferece solicitação genérica de indexação. Sua consulta tem limites e dados parciais próprios; filtros de métricas e ordenação locais são explicitamente limitados à página obtida.
- Provisionamento de conta Analytics devolve ticket e link de termos para aceitação humana. Segredos MP são redigidos em `get-settings`; podem ser obtidos na API conforme suas permissões, sem persistência pelo plugin.
- Tag GA4, Consent Mode, ponte de eventos do site, agendamentos e Looker Studio permanecem fora deste complemento, conforme o plano.

## Desenvolvimento e evidência

O pacote-fonte inclui os testes, nove documentos oficiais com SHA256, exemplos, runners WordPress e relatório executado. Rode PHPUnit com `--bootstrap tests/bootstrap.php tests`; use `phpcs.xml.dist` para WPCS e PHPCompatibilityWP. As instruções de reprodução completas acompanham o relatório.

Os testes locais usam HTTP Google simulado. Não houve acesso às credenciais ou ao WordPress de produção, nem ensaio vivo em contas Google nesta entrega.
