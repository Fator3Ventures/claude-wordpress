# Fator3 MCP 0.46.0

Em Ferramentas → Fator3 MCP, use Operação, Configurar e Suporte. Acompanhe operações longas de banco pelo identificador devolvido e confira os eventos em Atividade. Consulte as notas desta versão na Ajuda.

Instale `wp-mcp-fator3-0.46.0-instalador.zip` em WordPress 7.1.4 ou superior com PHP 8.3 ou superior. Esta versão admite atualização direta da 0.45.0. Confira a versão em `system/health`. Em **Ajuda → Notas desta versão**, leia as mudanças e os procedimentos de verificação. Os mesmos documentos estão disponíveis por `system/guide`.

As senhas de aplicação continuam com o alcance nativo do WordPress. O perfil da conexão controla as chamadas MCP. A descoberta aceita paginação explícita com `per_page` e `cursor` e mantém o comportamento da 0.43.0 quando o limite é omitido.

As suítes desta versão ficam em `tools/release0460/` e os resultados em `evidencias/0460/`.

## Reproduzir a entrega

Use Python 3 para gerar a documentação e os pacotes. Execute na raiz do fonte, em ordem:

```sh
python3 tools/sync_docs.py
python3 tools/build_packages.py --out dist
python3 tools/pack_source.py --out dist/wp-mcp-fator3-0.46.0-fonte.zip
```

O inventário em `tools/runtime-manifest.json` determina o conteúdo do instalador. As oito entradas da rodada, com tamanho e SHA-256, estão em `docs/ENTRADAS-TESTE.json`. Os contratos efetivos dos provedores e das habilidades próprias estão em `docs/CONTRATOS-INSTALADOS.json`.

Os testes em `tools/release0460` usam dois WordPress descartáveis com banco próprio. Crie o marcador vazio `f3-disposable-lab.marker` na raiz de cada WordPress, exporte `F3_WP_ROOT` com o caminho para seu `wp-load.php` e `F3_EVIDENCE` com uma pasta de saída. Instale o MCP do zero no primeiro. No segundo, ative a 0.45.0, configure o canal, instale os acompanhantes de referência e atualize para a 0.46.0. As chamadas de teste usam o usuário administrador de laboratório com ID 1.

- `F3_TIER=clean php tools/release0460/scenarios.php` ou `F3_TIER=update` cobre a escrita e as restaurações por linha e por tabela.
- `php tools/release0460/logs.php` cobre as entradas sintéticas. `F3_QA_REPLAY=evidencias/0460/ctooffice-extrato-sanitizado.txt php tools/release0460/replay.php` reprocessa o recorte histórico.
- Para testar HTTP por mais de 120 segundos, disponibilize o servidor de laboratório com senhas de aplicação habilitadas. Use o endereço desse servidor como `LAB_HOME`, copie `slow.php` para os MU-plugins **do laboratório marcado** e execute `php tools/release0460/slow-check.php`. A prévia, a confirmação e a consulta de status trafegam pelo endpoint MCP. A prova equivalente realizada no Site-Teste tem recibos em `evidencias/0460/site-teste.json`.
- Para reproduzir as telas, execute `php tools/release0460/seed-ui.php` no laboratório integrado, configure `LAB_HOME`, `F3_QA_USER`, `F3_QA_PASSWORD`, `F3_CHROME` e `F3_EVIDENCE`, e rode `python3 tools/release0460/browser.py` com Playwright e Chromium. Use credenciais descartáveis.
