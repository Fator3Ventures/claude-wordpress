# Fator3 MCP 0.46.0

Em Ferramentas → Fator3 MCP, use Operação, Configurar e Suporte. Acompanhe operações longas de banco pelo identificador devolvido e confira os eventos em Atividade. Consulte as notas desta versão na Ajuda.

Instale `wp-mcp-fator3-0.46.0-instalador.zip` em WordPress 7.1.4 ou superior com PHP 8.3 ou superior. Esta versão admite atualização direta da 0.45.0. Confira a versão em `system/health`. Em **Ajuda → Notas desta versão**, leia as mudanças e os procedimentos de verificação. Os mesmos documentos estão disponíveis por `system/guide`.

As senhas de aplicação continuam com o alcance nativo do WordPress. O perfil da conexão controla as chamadas MCP. A descoberta aceita paginação explícita com `per_page` e `cursor` e mantém o comportamento da 0.43.0 quando o limite é omitido.
