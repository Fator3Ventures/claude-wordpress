<?php
/** Authenticated identity and per-connection restrictions, independent of MCP sessions. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class ConnectionContext {
	private static ?array $identity = null;
	public static function init(): void {
		add_action('application_password_did_authenticate', static function($user,$item): void {
			self::$identity = ['user_id'=>(int)$user->ID,'connection_id'=>'app:'.$item['uuid'],'transport'=>'wordpress-application-password'];
		}, 10, 2);
	}
    /** Transport identity established in this request (application password, OAuth or internal job), or null. */
    public static function transport_identity(): ?array {
        return self::$identity;
    }
    /** Native WP authentication is independent of an optional/revoked MCP user policy. */
    public static function native_identity(): bool {
        $user=get_current_user_id();
        return $user>0 && (self::$identity===null || self::$identity['user_id']!==$user);
    }
	/** Called only after BearerAuth has validated the token and WP user. */
	public static function oauth(array $payload): void {
		self::$identity = ['user_id'=>(int)$payload['user_id'],'connection_id'=>'grant:'.$payload['grant_id'],'grant_id'=>$payload['grant_id']??'','client_id'=>$payload['client_id']??'','transport'=>'oauth','profile'=>$payload['profile']??null];
	}
    public static function credential_active(string $id, int $user): bool {
        if (str_starts_with($id, 'app:')) {
            return class_exists('WP_Application_Passwords')
                && is_array(\WP_Application_Passwords::get_user_application_password($user, substr($id, 4)));
        }
        if (str_starts_with($id, 'grant:')) {
            $grant = Persistence::get('oauth-grants', substr($id, 6));
            return $grant && self::grant_active($grant, $grant['_storage']['status'], $user, time());
        }
        return true;
    }

    private static function grant_active(array $grant, string $status, int $owner, int $now): bool {
        return $status === 'active' && (int)($grant['user_id'] ?? 0) === $owner
            && (empty($grant['expires']) || $grant['expires'] > $now);
    }

    /** Read-only page projection. Execution continues to resolve its own current credential. */
    public static function page_access(array $rows, int $now): array {
        $access = [];
        $grants = [];
        $applications = [];
        foreach ($rows as $row) {
            $id = $row['connection_id'];
            $owner = (int)$row['user_id'];
            $access[$id] = false;
            if ($row['status'] !== 'active' || ($row['profile'] ?? 'unconfigured') === 'unconfigured'
                || (!empty($row['expires']) && $row['expires'] <= $now)) {
                continue;
            }
            if (str_starts_with($id, 'grant:')) {
                $grants[Persistence::hash('oauth-grants', substr($id, 6))] = [$id, $owner];
            } elseif (str_starts_with($id, 'app:')) {
                $applications[$owner][substr($id, 4)] = $id;
            } else {
                $access[$id] = true;
            }
        }
        if ($grants) {
            global $wpdb;
            $table = Persistence::table('oauth-grants');
            $slots = implode(',', array_fill(0, count($grants), '%s'));
            $sql = $wpdb->prepare("SELECT record_key,status,payload FROM {$table} WHERE bucket='oauth-grants' AND record_key IN ($slots)", array_keys($grants));
            foreach (Persistence::rows($sql) as $record) {
                [$id, $owner] = $grants[$record['record_key']];
                $grant = json_decode($record['payload'], true, 512, JSON_THROW_ON_ERROR);
                $access[$id] = self::grant_active($grant, $record['status'], $owner, $now);
            }
        }
        if ($applications && class_exists('WP_Application_Passwords')) {
            foreach ($applications as $owner => $ids) {
                foreach (\WP_Application_Passwords::get_user_application_passwords($owner) as $application) {
                    if (isset($ids[$application['uuid']])) {
                        $access[$ids[$application['uuid']]] = true;
                    }
                }
            }
        }
        return $access;
    }
    /**
     * 0.29.0: evaluate a read-only batch (discovery listing) against one resolved
     * context instead of re-reading credential and policy for every ability.
     * Scoped to the callback; never used for executions or writes.
     */
    private static ?array $snapshot = null;
    public static function with_snapshot(callable $callback) {
        $previous=self::$snapshot;
        self::$snapshot=['user'=>get_current_user_id(),'identity'=>self::$identity,'context'=>null,'resolved'=>false];
        try { return $callback(); } finally { self::$snapshot=$previous; }
    }
    public static function get(): ?array {
		$user=get_current_user_id(); if (!$user) return null;
        if (self::$snapshot!==null && self::$snapshot['user']===$user && self::$snapshot['identity']===self::$identity) {
            if (!self::$snapshot['resolved']) { self::$snapshot['resolved']=true; $snapshot=self::$snapshot; self::$snapshot=null; try { $snapshot['context']=self::get(); } finally { self::$snapshot=$snapshot; } }
            return self::$snapshot['context'];
        }
		$identity=self::$identity;
		if (!$identity || $identity['user_id']!==$user) $identity=['user_id'=>$user,'connection_id'=>'integration:user:'.$user,'transport'=>'wordpress-identity'];
		if(!self::credential_active($identity['connection_id'],$user))return null;
        $row=self::policy($identity['connection_id']);
		if (!$row) {
            // Only an active, explicitly consented OAuth grant can materialize a policy.
            $grant = !empty($identity['grant_id']) ? Persistence::get('oauth-grants', $identity['grant_id']) : null;
            $profile = $grant['profile'] ?? 'unconfigured';
            if (!in_array($profile, ['read','content','maintenance','custom'], true)) $profile = 'unconfigured';
            if($profile==='unconfigured')return $identity+['profile'=>'unconfigured','status'=>'no_access','policy_version'=>0,'expires'=>0];
			$row=array_replace($identity,['profile'=>$profile,'status'=>'active','policy_version'=>1,'time'=>time(),'expires'=>0,'allow_backup_export'=>false]);
			if ($grant) $row['label']=self::oauth_label($grant);
            Persistence::put('connections',$identity['connection_id'],$row,true);
			$row=self::policy($identity['connection_id']);
		}
		if (($row['_storage']['status']??'')!=='active' || (int)$row['user_id']!==$user || !empty($row['expires']) && (int)$row['expires']<=time()) return null;
		if (!empty($identity['grant_id'])) {
			$grant=Persistence::get('oauth-grants',$identity['grant_id']);
			if (!$grant || ($grant['_storage']['status']??'')!=='active') return null;
		}
		if(($row['last_seen']??0)<time()-60)Persistence::touch_connection($identity['connection_id']);
        return array_replace($row,['transport'=>$identity['transport']]);
	}
	/** Read local authorization metadata only. Legacy grants can omit both name and time. */
    public static function oauth_label(array $grant): string {
        $id=$grant['client_id']??'';
        $client=is_string($id) && $id!=='' ? Persistence::get('oauth-clients',$id) : null;
        $name=trim((string)($client['client_name']??'')) ?: 'Cliente OAuth';
        $time=(int)($grant['time']??$grant['_storage']['created_at']??0);
        return mb_substr($name,0,94).($time>0?' · '.wp_date('d/m/Y H:i:s T',$time):'');
    }
    /** Read persisted policy without changing explicit restrictions or revocations. */
    public static function policy(string $id): ?array {
        $row=Persistence::get('connections',$id);
        return $row;
    }
    /** Used only by an authenticated internal worker with a persisted identity. */
    public static function resume(string $id,int $user): ?array {
        $previous=self::$identity;wp_set_current_user($user);self::$identity=['user_id'=>$user,'connection_id'=>$id,'transport'=>'internal-job'];return $previous;
    }
    public static function restore_identity(?array $identity,int $user): void {self::$identity=$identity;wp_set_current_user($user);}
    public static function maintenance(): bool {return (self::get()['profile']??'')==='maintenance';}
    public static function key(): string { return (string)(self::get()['connection_id']??'unauthorized'); }
}

final class AuthorizationPolicy {
	public static function executor(\WP_Ability $ability): bool {
		$meta=$ability->get_meta(); $schema=$ability->get_input_schema();
		return !empty($meta['fator3']['executes_ability']) || in_array($ability->get_name(), ['wp-mcp-ultimate/execute-ability','wp-mcp-ultimate/execute-readonly-ability','mcp-adapter/execute-ability'],true) || isset($schema['properties']['ability_name']) && (isset($schema['properties']['parameters']) || isset($schema['properties']['input']));
	}
	public static function readonly(\WP_Ability $ability): bool {
		$meta=$ability->get_meta();
		return !self::executor($ability) && Providers::known((string)($meta['fator3']['provider']??'')) && !empty($meta['annotations']['readonly']);
	}
	public static function check(string $name, array $input=[], bool $read=false, bool $discovery=false) {
        if ((MutationAudit::allows_panel_reader($name)||MutationServiceAudit::allows_panel_reader($name))) return true;
        // 0.29.0: a browser administrator on a domain screen is not an MCP connection.
        // The domain permission callback already ran; nothing is persisted here.
        if (!$discovery && NativeAdminCall::allows($name)) return true;
		$context=ConnectionContext::get();
		if (!$context) return new \WP_Error('connection_context_required','Identidade autenticada e perfil configurado são necessários para esta habilidade.');
		$profile=$context['profile']??'unconfigured';
		$ability=wp_get_ability($name);
        $root = $ability && self::executor($ability) && RootToolContext::allows($ability);
        if($ability && self::executor($ability) && !$root)return new \WP_Error('ability_executor_forbidden','Um executor não pode ser alvo de outro executor.');
        if($ability){$target=RootToolContext::check_target($ability);if(is_wp_error($target))return $target;}
        if($root)$read = !empty($ability->get_meta()['annotations']['readonly']);
        if(in_array($profile,['read','content'],true) && $read && $ability && !$root && !self::readonly($ability))$read=false;
        $allow=false;
		if ($profile==='maintenance') $allow=true;
		elseif ($profile==='read') $allow=$read && !preg_match('~^(files|db|users|backups|audit)/~',$name);
		elseif ($profile==='content') $allow=($read && !preg_match('~^(files|db|users|backups|audit)/~',$name)) || (bool)preg_match('~^(content|media|comments|menus|widgets)/~',$name);
		elseif ($profile==='custom') $allow=in_array($name,(array)($context['abilities']??[]),true);
		if (!$allow) return new \WP_Error('profile_denied','A habilidade não está autorizada no perfil desta conexão.');
		if ($profile!=='maintenance' && str_starts_with($name,'backups/export') && empty($context['allow_backup_export'])) return new \WP_Error('backup_export_denied','Exportar valores originais exige permissão explícita de recuperação.');
		if (!$discovery) {
            if(str_starts_with($name,'backups/export')&&isset($input['backup_id'])){
                $backup=Backups::metadata($input['backup_id'],false);if(is_wp_error($backup))return $backup;
                if(($backup['kind']??'')==='file'){$scope=self::check('files/read',['path'=>$backup['path']],true);if(is_wp_error($scope))return $scope;}
                elseif(($backup['connection_id']??'')!==$context['connection_id']&&$profile!=='maintenance'&&empty($context['allow_foreign_backup_export']))return new \WP_Error('backup_scope_denied','Backup fora da conexão; migração/recuperação de outro acervo exige autorização adicional.');
            }
			if ($profile!=='maintenance' && !empty($context['post_types']) && str_starts_with($name,'content/')) {
				$type=!empty($input['id'])?get_post_type((int)$input['id']):($input['post_type']??(str_contains($name,'page')?'page':'post'));
				if (!in_array($type,(array)$context['post_types'],true)) return new \WP_Error('profile_post_type_denied','Tipo de conteúdo fora do perfil.');
			}
			if (str_starts_with($name,'files/') && $profile!=='maintenance') {
				$roots=$context['roots']??[];
				if (!$roots) return new \WP_Error('profile_path_required','Configure raízes de arquivos explícitas para esta conexão.');
				$paths=[]; foreach(['path','source','destination'] as $key) if(isset($input[$key])) $paths[]=$input[$key];
				if ($name==='files/restore' && isset($input['backup_id'])) { $backup=Backups::metadata($input['backup_id'],false); if(is_wp_error($backup)) return $backup; $paths[]=$backup['path']??''; }
				foreach($paths as $requested) {
					$path=Locks::path((string)$requested); if(is_wp_error($path)) return $path; $inside=false;
					foreach($roots as $root) { $root=realpath($root); if($root && ($path===wp_normalize_path($root)||str_starts_with($path,rtrim(wp_normalize_path($root),'/').'/'))) $inside=true; }
					if(!$inside) return new \WP_Error('profile_path_denied','Caminho fora das raízes autorizadas.');
				}
			}
			if ($name==='db/execute' && $profile!=='maintenance' && empty($context['database_write'])) return new \WP_Error('profile_database_write_denied','Escrita SQL exige permissão administrativa explícita.');
		}
		return true;
	}

}

final class Providers {
	private static array $providers=[];
	public static function register(string $id,string $version,array $prefixes): void { self::$providers[$id]=['id'=>$id,'version'=>$version,'prefixes'=>$prefixes]; }
	public static function all(): array {return array_values(self::$providers);}
	public static function known(string $id): bool { return isset(self::$providers[$id]); }
	public static function metadata(string $name): array {
		foreach(self::$providers as $provider) foreach($provider['prefixes'] as $prefix) if(str_starts_with($name,$prefix)) return ['provider'=>$provider['id'],'version'=>$provider['version'],'result_contract'=>2];
        if(str_starts_with($name,'f3base/')&&defined('F3BASE_PLUGIN_VERSAO'))return ['provider'=>'base-site-core-fator3','version'=>F3BASE_PLUGIN_VERSAO,'version_source'=>'loaded_plugin_constant'];
		return ['provider'=>'unknown','version'=>null,'version_reason'=>'Provedor sem registro explícito.'];
	}
}
