<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$url=Admin::url('connections');
?>
<div class="f3-page-intro"><h2>Clientes</h2><p>Veja quem tem um perfil neste site e quando cada cliente acessou o MCP.</p>
<div class="f3-actions"><a class="button button-primary" href="<?php echo esc_url(add_query_arg('mode','associate',$url)); ?>">Associar identidade existente</a>
<a class="button" href="<?php echo esc_url(add_query_arg('mode','create',$url)); ?>">Emitir senha de aplicação</a></div></div>
<section class="f3-card" aria-label="Clientes cadastrados">
<h3>Identidades cadastradas</h3>
<form class="f3-search" method="get"><input type="hidden" name="page" value="wp-mcp-fator3"><input type="hidden" name="group" value="configurar"><input type="hidden" name="tab" value="connections">
<label for="f3-client-search">Nome, conta ou identificador</label><div class="f3-actions"><input type="search" name="q" id="f3-client-search" value="<?php echo esc_attr($search); ?>"><button class="button">Buscar</button></div></form>
<?php if (!$rows): ?><h3>Nenhum cliente nesta página</h3><p>Associe uma identidade WordPress ou autorize o primeiro cliente pelo fluxo OAuth.</p>
<?php else: ?>
<div class="f3-table-scroll" tabindex="0" role="region" aria-label="Conexões e perfis">
<table class="widefat striped f3-connections-table"><thead><tr><th scope="col">Cliente</th><th scope="col">Conta WordPress</th><th scope="col">Perfil e validade</th><th scope="col">Último acesso</th><th scope="col">Ação</th></tr></thead><tbody>
<?php foreach ($rows as $row):
    $id=$row['connection_id'];
    $expired=!empty($row['expires']) && $row['expires']<=time();
    $state=$row['status']??'active';
    $user=get_userdata((int)$row['user_id']);
?>
<tr><td><strong><?php echo esc_html(OperationsAdmin::client_name($row)); ?></strong><br><code><?php echo esc_html($id); ?></code>
<?php if (!empty($row['client_id'])): ?><small><?php echo esc_html($row['client_id']); ?></small><?php endif; ?></td>
<td data-label="Conta WordPress"><?php echo esc_html($user?$user->display_name:'Usuário removido'); ?><small>#<?php echo (int)$row['user_id']; ?></small></td>
<td data-label="Perfil e validade"><?php echo esc_html(Admin::profile($row['profile']??'')); ?><small><?php
    if ($state==='revoked')echo 'Revogada';
    elseif ($expired || $state==='expired')echo 'Expirada';
    elseif ($state!=='active')echo 'Inativa';
    elseif (!empty($row['expires']))echo 'Até '.Admin::time_html($row['expires']);
    else echo 'Sem prazo definido';
?></small></td>
<td data-label="Último acesso"><?php echo empty($row['last_seen'])?'Ainda não observado':Admin::time_html($row['last_seen']); ?><small><?php echo esc_html($session_counts===null?'Contagem indisponível':sprintf('Sessões ativas: %d',$session_counts[$id]??0)); ?></small></td>
<td><?php if ($user && current_user_can('edit_user',$user->ID)): ?><a aria-label="<?php echo esc_attr('Abrir cliente '.(($row['label']??'')?:$id)); ?>" href="<?php echo esc_url(add_query_arg('connection',$id,$url)); ?>"><?php echo $state==='revoked'?'Consultar':'Editar'; ?></a><?php endif; ?></td></tr>
<?php endforeach; ?></tbody></table></div>
<?php endif; ?>
<?php Admin::pager($url,['q'=>$search,'before_id'=>$before],$page,20,$total); ?>
</section>
