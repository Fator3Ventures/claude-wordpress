<?php
/** Durable OAuth state with atomic validation, consumption and issuance. */
declare(strict_types=1);
namespace WpMcpUltimate\OAuth;
use Fator3\McpFiles\Persistence;
use Fator3\McpFiles\Locks;
use Fator3\McpFiles\ConnectionEndpoints;

final class TokenStore {
    private const CODE_TTL = 120;
    private const ACCESS_TTL = 3600;
    private const REFRESH_TTL = 2592000;
    public static function generate_token(): string { return bin2hex(random_bytes(32)); }
    public static function access_token_ttl(): int { return self::ACCESS_TTL; }
    public static function get_client(string $id, bool $resolve_metadata = true): ?array {
        $result=self::resolve_client($id,$resolve_metadata);return is_wp_error($result)?null:$result;
    }
    public static function resolve_client(string $id,bool $resolve_metadata=true) {
        try { $row=Persistence::get('oauth-clients',$id); }
        catch (\Throwable $e) { return ClientDiagnostics::failure('client_persistence_failed',$id); }
        if ($row && (($row['_storage']['status']??'')!=='active' || !empty($row['expires']) && $row['expires']<=time() && empty($row['authorized_at']) || !empty($row['issuer']) && $row['issuer']!==untrailingslashit(home_url()))) return ClientDiagnostics::failure('client_unavailable',$id);
        if ($resolve_metadata && str_starts_with($id,'https://'))return ClientMetadata::resolve_result($id,$row);
        return $row ?: ClientDiagnostics::failure('client_unavailable',$id);
    }
    public static function save_client(string $id, array $client) {
        return Locks::run(['oauth-clients'=>LOCK_EX], static function () use ($id,$client) {
            $all = Persistence::listing('oauth-clients', [], 101);
            if (count($all)>=100 && !self::get_client($id,false)) return new \WP_Error('client_capacity_reached', 'Client registration capacity reached; existing clients were preserved.');
            $old=Persistence::get('oauth-clients',$id);
            if(!empty($old['authorized_at'])){$client['authorized_at']=$old['authorized_at'];$client['expires']=0;}
            Persistence::put('oauth-clients',$id,$client+['client_id'=>$id,'time'=>time(),'expires'=>time()+DAY_IN_SECONDS]);
            return true;
        });
    }
    private static function store(string $kind, string $token, array $value, int $ttl): void {
        $bucket = $kind === 'code' ? 'oauth-codes' : 'oauth-tokens';
        $value['issuer']=untrailingslashit(home_url()); $value['kind']=$kind; $value['expires']=time()+$ttl; $value['status']='active'; $value['time']=time();
        if (!Persistence::put($bucket, hash('sha256',$token), $value, true)) throw new \RuntimeException('Token collision.');
    }
    private static function get(string $kind, string $token, bool $lock = false): ?array {
        if (!preg_match('/^[a-f0-9]{64}$/D',$token)) return null;
        $bucket=$kind==='code' ? 'oauth-codes' : 'oauth-tokens'; $key=hash('sha256',$token);
        $row=Persistence::get($bucket,$key,$lock);
        if ($row) return $row;
        return null;
    }
    private static function active(?array $row): bool {
        if (!$row || !empty($row['issuer']) && $row['issuer']!==untrailingslashit(home_url()) || ($row['_storage']['status'] ?? '')!=='active' || (int)($row['expires']??0)<=time()) return false;
        if (($row['kind']??'') !== 'code' && empty($row['grant_id'])) return false;
        if (!empty($row['grant_id'])) {
            $grant=Persistence::get('oauth-grants',$row['grant_id']);
            if (!$grant || ($grant['_storage']['status']??'')!=='active') return false;
        }
        return true;
    }
    public static function store_code(string $code,array $payload): void {
        Persistence::transaction(static function()use($code,$payload){
            $id=$payload['client_id'];$client=Persistence::get('oauth-clients',$id,true);
            if(!$client||($client['_storage']['status']??'')!=='active'||(!empty($client['expires'])&&$client['expires']<=time()&&empty($client['authorized_at'])))throw new \RuntimeException('Client unavailable during consent.');
            $client['authorized_at']=$client['authorized_at']??time();$client['expires']=0;
            Persistence::put('oauth-clients',$id,$client);self::store('code',$code,$payload,self::CODE_TTL);
        });
    }
    public static function store_access_token(string $token,array $payload): void { self::store('at',$token,$payload,self::ACCESS_TTL); }
    public static function store_refresh_token(string $token,array $payload): void { self::store('rt',$token,$payload,self::REFRESH_TTL); }
    public static function get_access_token(string $token): ?array {
        $row=self::get('at',$token);
        return self::active($row) && ($row['kind']??'')==='at' ? $row : null;
    }
    public static function exchange(array $params) {
        $auth_error=ClientAuthentication::request_error($params);if($auth_error)return $auth_error;
        $kind=($params['grant_type']??'')==='authorization_code'?'code':'rt';
        $token=(string)($params[$kind==='code'?'code':'refresh_token']??'');
        $client=(string)($params['client_id']??'');
        if (!$client || !$token) return new \WP_Error('invalid_request','client_id and grant token are required.');
        try {
            $result=Persistence::transaction(static function () use ($kind,$token,$client,$params) {
                $row=self::get($kind,$token,true);
                if ($row && $kind==='rt' && ($row['_storage']['status']??'')==='consumed' && ($row['client_id']??'')===$client && !empty($row['grant_id'])) {
                    $grant=Persistence::get('oauth-grants',$row['grant_id'],true);
                    if ($grant) { $grant['status']='revoked'; Persistence::put('oauth-grants',$row['grant_id'],$grant); }
                    // Commit the revocation instead of rolling back an error return.
                    return ['reuse_detected'=>true];
                }
                if (!self::active($row) || ($row['kind']??'')!==$kind || ($row['client_id']??'')!==$client || !self::get_client($client,false)) return new \WP_Error('invalid_grant','Grant invalid, expired, revoked or consumed.');
                $registered=self::get_client($client,false);
                if (($registered['token_endpoint_auth_method']??'none')!=='none')return new \WP_Error('invalid_client','Unsupported client authentication method.');
                if (isset($row['site_id']) && (int)$row['site_id']!==get_current_blog_id()) return new \WP_Error('invalid_grant','Grant belongs to another site.');
                if ($kind==='code') {
                    $verifier=(string)($params['code_verifier']??'');
                    $challenge=rtrim(strtr(base64_encode(hash('sha256',$verifier,true)),'+/','-_'),'=');
                    if (!preg_match('/^[A-Za-z0-9._~-]{43,128}$/D',$verifier) || !hash_equals((string)($row['code_challenge']??''),$challenge) || ($row['redirect_uri']??'')!==($params['redirect_uri']??'')) return new \WP_Error('invalid_grant','PKCE or redirect_uri mismatch.');
                }
                $bound=ConnectionEndpoints::resource($row['resource']??null,ConnectionEndpoints::url(ConnectionEndpoints::LEGACY));
                $resource=ConnectionEndpoints::resource($params['resource']??null,is_string($bound)?$bound:'');
                if (is_wp_error($bound)||is_wp_error($resource)) return new \WP_Error('invalid_target','Resource must identify this MCP service.');
                $bucket=$kind==='code'?'oauth-codes':'oauth-tokens';
                if (!Persistence::consume($bucket,hash('sha256',$token))) return new \WP_Error('invalid_grant','Grant already consumed.');
                $grant_id=$row['grant_id']??bin2hex(random_bytes(16));
                $grant=Persistence::get('oauth-grants',$grant_id,true);
                if (!$grant) {
                    $profile=$row['profile']??'read';
                    if ($kind!=='code' || !in_array($profile,['read','content','maintenance','custom'],true)) return new \WP_Error('invalid_grant','Explicit current consent required.');
                    $grant=['grant_id'=>$grant_id,'user_id'=>(int)$row['user_id'],'client_id'=>$client,'profile'=>$profile,'status'=>'active','issuer'=>untrailingslashit(home_url()),'time'=>time()];
                    Persistence::put('oauth-grants',$grant_id,$grant,true);
                    $identity='grant:'.$grant_id;
                    $policy=['connection_id'=>$identity,'user_id'=>$grant['user_id'],'grant_id'=>$grant_id,'client_id'=>$client,
                        'transport'=>'oauth','profile'=>$profile,'status'=>'active','policy_version'=>1,
                        'time'=>$grant['time'],'expires'=>0,'allow_backup_export'=>false,
                        'label'=>\Fator3\McpFiles\ConnectionContext::oauth_label($grant)];
                    if (!Persistence::put('connections',$identity,$policy,true)) throw new \RuntimeException('Could not register the new grant identity.');

                }
                if (($grant['status']??'')!=='active') return new \WP_Error('invalid_grant','Grant revoked.');
                $payload=['client_id'=>$client,'user_id'=>(int)$row['user_id'],'scope'=>$row['scope']??'mcp','resource'=>$resource,'site_id'=>get_current_blog_id(),'grant_id'=>$grant_id,'profile'=>$grant['profile']];
                $access=self::generate_token(); $refresh=self::generate_token();
                self::store_access_token($access,$payload); self::store_refresh_token($refresh,$payload);
                return ['access_token'=>$access,'token_type'=>'Bearer','expires_in'=>self::ACCESS_TTL,'refresh_token'=>$refresh,'scope'=>$payload['scope']];
            });
            return is_array($result) && !empty($result['reuse_detected']) ? new \WP_Error('invalid_grant','Refresh reuse detected; grant revoked.') : $result;
        } catch (\Throwable $error) { return new \WP_Error('temporarily_unavailable','Token issuance could not be confirmed. Reauthorize if the grant was consumed.'); }
    }
}
