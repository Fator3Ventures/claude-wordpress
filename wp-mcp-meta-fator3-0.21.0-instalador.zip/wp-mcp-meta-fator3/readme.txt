=== Fator3 MCP Meta ===
Requires at least: 7.1.4
Requires PHP: 8.3
Stable tag: 0.21.0
License: GPL-2.0-or-later

Configure em Ferramentas > Fator3 MCP Meta. Consulte docs/README.md e docs/CONTRACTS.md.
