# Instalação e migração — Meta 0.21.0

Requisitos: WordPress 7.1.4 ou superior, PHP 8.3 ou superior de 64 bits, criptografia autenticada e banco com InnoDB/travas nomeadas. Para instalação limpa, use o instalador com raiz wp-mcp-meta-fator3/ e ative **Fator3 MCP Meta**. O painel e a ajuda funcionam sem acompanhantes; transporte remoto requer MCP. Ativar não configura conta nem dispara publicação.

**Atualização direta: 0.20.0 → 0.21.0.** Faça backup consistente do banco e das chaves/salts. Substitua o plugin pelo instalador no mesmo basename, sem desinstalar. A versão nova não altera tabelas, não migra em massa nem regrava conexões, grants, retenção ou filas por causa desta mudança. Não é necessário alterar o Core ou os outros plugins para usar o painel.

Em requisição nova, confira versão, conexão, ativos, retenção e agendas existentes. Abra Diagnóstico e confira a saúde. Em Ajuda, leia o guia do painel e verifique a versão. Pelo MCP, use meta/health e meta/documentation com document=index. Um site sem credencial não comprova acesso à Meta.

**Recuperação:** se houver falha, preserve banco, salts, revisões e recibos. Pause o fluxo afetado, registre o estado e aplique uma nova versão corretiva a partir desse ponto. Não há downgrade. Reconciliar efeitos externos antes de repetir operações incertas. Desativar suspende hooks; desinstalar preserva os registros cifrados, conforme uninstall.php.
