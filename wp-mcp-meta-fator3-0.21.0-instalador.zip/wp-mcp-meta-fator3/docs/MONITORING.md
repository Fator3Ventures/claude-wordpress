# Atividades de anúncios e qualidade de datasets — 0.21.0

`ads_activity` usa o canal `ads` e a conta de anúncios em `account_id`. `dataset_quality` usa o canal `dataset`, o ID do dataset em `account_id` e a conta autorizada em `ads_account_id`. Ambos exigem datas explícitas de dias completos no fuso da conta e token conferido com `ads_read`. O dataset e a conta devem estar selecionados na conexão; a coleta também confere o vínculo entre eles na Meta.

Em Ativos, autorize primeiro a conta de anúncios. Depois selecione essa conta para descobrir datasets e salve a seleção. Em Coletas, escolha o relatório e crie uma agenda de 1440 minutos. A coleta usa o cron existente; não há ativação automática nem alteração de anúncios. A revisita e `create-backfill` reaproveitam os controles e a continuidade dos jobs. A retenção cifrada destes dois relatórios e das páginas de resultados é sem prazo, mesmo se a conexão tiver política finita.

## Dados e limites

Atividades: GET `/act_{conta}/activities`, incluindo filhos, intervalo diário e cursor Graph. Preserva horário, objeto, tipo de alteração, autor, aplicativo e `extra_data`; `old_value`/`new_value` ficam nulos quando ausentes. Não há ID de atividade garantido: a chave local deriva de conta, instante, objeto, tipo, autor, aplicativo e detalhe canônico. Revisitas não multiplicam eventos indistinguíveis; o limite é declarado em cada linha. O horizonte remoto é o que o fornecedor devolver, sem promessa de recuperação integral.

Contagens: GET `/{dataset}/stats`, agregação horária `event`, uma consulta WEB_ONLY e outra SERVER_ONLY por dia. A origem documenta event_source para aggregation=event. Somam-se buckets horários distintos; paginação completa, todas as horas do dia e presença explícita de cada evento em cada hora são necessárias para cobertura por evento. Horas/eventos ausentes, buckets duplicados, fora da janela, contagens negativas ou overflow nunca confirmam zero. Dias de 23 e 25 horas são tratados pelo fuso da conta. Não somar essas fontes como eventos únicos. Total ausente fica nulo. A documentação pública descreve sete dias de recuperação; fora desse intervalo, dados retornados são preservados sem declarar cobertura completa. Erros parciais ficam no resultado e na agenda. Cada aresta é limitada a 10 páginas e 3000 registros, e vínculos/conjuntos a 5 páginas, dentro do orçamento HTTP existente. Limite atingido produz cobertura incompleta, nunca truncamento silencioso nem zero.

EMQ: GET `/dataset_quality?dataset_id=...`, projeção `web{event_name,event_match_quality}`. Registra `emq_snapshot` separado, com data e `emq_observed_at` atuais; mantém observações sucessivas sem prazo. Não existe reconstrução de EMQ de dias anteriores. A coleta do dia completo mais recente também captura a nota atual. Backfill de dias anteriores só busca contagens. A API pode exigir `ads_read` com `ads_management` ou `business_management`, ou autorização específica de qualidade/opt-in do dataset; confirme na conta. As permissões adicionais não habilitam escritas pelo plugin.

Conjuntos: GET `/act_{conta}/adsets`, status efetivo ACTIVE, conta e pixel conferidos. Eventos padrão são mapeados explicitamente. Conversões personalizadas que não identificam um evento padrão não geram inferência de zero. O estado ativo é observado agora e não afirma que o conjunto esteve ativo durante todo o dia passado.

## Health e leitura local pelo Core

`meta/health` acrescenta `datasets` e o aviso `dataset_optimized_event_zero` para a última coleta diária de uma agenda autorizada: dois zeros explícitos, cobertura de ambas as fontes, dia completo mais recente e evento padrão usado por conjunto ativo. Não alerta a partir de vazio/erro/parcial sem cobertura, plano revogado ou observação antiga. A leitura é local. O Core 1.61.1 implementa a leitura e o job de notificação do pedido 341, com concessão e autorização separadas. Ele exige também emissão local no pixel/evento/dia exatos ou gasto positivo autorizado; ausência de prova impede o aviso. Consulte CORE-MONITORING.md para configurar e conferir a integração.

Contrato adicional: `meta-ads-monitoring/1.0.0`, classe `Fator3\Meta\MonitoringReader`, hook `f3_meta_register_monitoring_consumers`. Registro: `register_consumer(id, version, contract, configurationCallback, label)` retorna cliente com `status` e `query`. Callback retorna `ready:true`, `connection_id`, `account_id` da conta de anúncios, `revision` monotônica, `reports` (ads_activity/dataset_quality) e `dataset_ids`. Concessão explícita exige igualdade com a seleção do callback. Operações administrativas: `monitoring-consumers`, `get-monitoring-grant`, `save-monitoring-grant`.

Exemplo de leitura: `client.query(['connection_id'=>'conexao','account_id'=>'123','report'=>'dataset_quality','dataset_id'=>'456','date_from'=>'2026-10-27','date_to'=>'2026-10-28','limit'=>50])`. Para notas de EMQ observadas hoje, consulte também a data de hoje no histórico local. Nenhum token é disponibilizado ao consumidor. Cursores vinculam consumidor, concessão, seleção, revisões e geração do histórico. Revogação invalida leitura/continuação. O contrato antigo `meta-ads-reader/1.0.0` permanece exclusivo de performance e inalterado.

## Fontes primárias conferidas em 29/10/2026

- https://developers.facebook.com/documentation/ads-commerce/conversions-api/dataset-quality-api
- https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ads-pixel/stats
- https://developers.facebook.com/documentation/ads-commerce/marketing-api/reference/ad-activity
- https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adaccount.py
- https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adspixelstatsresult.py

As páginas descrevem APIs mais recentes; as conexões preservam sua versão configurada (padrão v24.0). Disponibilidade por versão/ativo/permissão depende de validação remota. Fixtures não homologam essas permissões.

## Pedido 27 — coleta parcial e diagnóstico na 0.19.0

O vínculo usa `/act_{conta}/adspixels`, a mesma direção da descoberta de datasets. Continua obrigatório antes de ler contagens/EMQ. Falhas de stats browser, stats server, conjuntos ativos ou EMQ são diagnosticadas separadamente; dados úteis das demais partes permanecem. Falha de uma entrada EMQ não descarta as outras. Permissão, validação, resposta inválida, limite remoto, transporte e orçamento local podem terminar como parcial quando há dados úteis. Autorizações locais, revisões concorrentes e persistência continuam impedindo a coleta. Não há repetição automática das partes faltantes do dia: use nova coleta/backfill após resolver a causa; o cron mantém as próximas execuções previstas.

`health.datasets.diagnostics[]` mostra erros atuais de jobs vinculados a agendas autorizadas, mesmo sem linhas: schedule_id, state, last_error, errors e action. Código 100 permanece causa não determinada; não prova falta de permissão. Leia COLLECTION-DIAGNOSTICS.md para campos sanitizados. Contagens incompletas permanecem consultáveis com count_coverage=false; EMQ atual permanece separado. Retenção sem prazo e contratos SDK não mudam.

Revisão técnica em 01/11/2026: SDK oficial adspixel.py e metadados do conector Meta oficial (aggregation=event para event_source) orientaram a consulta. As páginas developers.facebook.com acima retornaram HTTP429 nesta revisão. A correção de consulta foi testada com fixtures; o aceite com o token dos dois sites do Pedido27 permanece necessário e não foi substituído por um token diferente do conector oficial.
