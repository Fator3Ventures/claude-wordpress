# Guia do painel — Meta 0.21.0

Abra **Ferramentas → Fator3 MCP Meta** com uma conta administradora. Cada aba tem seu próprio endereço e funciona com Voltar/Avançar. Para uma instalação nova, siga **Conexão → Ativos → Relatórios**.

## 1. Cadastrar ou editar uma conexão

Escolha **Editar conexão** na lista para alterar uma conexão existente. Confira o nome e a revisão exibidos. **Nova conexão** abre outro cadastro. A troca de destino limpa token e validade digitados no formulário de renovação, a prévia e a seleção transitória de usuários. Não há envio nesse passo.

| Grupo | O que fazer | Como conferir |
|---|---|---|
| Identificação e aplicativo | Dê um nome reconhecível. Copie App ID e App Secret do mesmo aplicativo da Meta. | A lista deve permitir distinguir conexões de empresas diferentes. |
| Acesso à Meta | Informe o token do usuário do sistema. Preencha validade em UTC somente se houver vencimento. O painel traz o caminho para obter o token. | Ao fornecer credencial nova, o servidor verifica aplicativo, identidade, escopos e ativos antes de persistir. |
| Retenção dos resultados | Mantenha **Sem expiração automática** para retenção máxima. Para um prazo explícito, escolha **Prazo em dias** e informe de 1 a 3650. | A edição ilimitada não envia um prazo oculto. Ads e outros acervos com política própria estão descritos em RETENTION.md. |
| Usuários WordPress associados | Busque pelo nome e marque os usuários pertinentes. | A seleção não concede permissão de administrador. |

Salve e confira a lista. Token e chave salvos não reaparecem no formulário. Um campo em branco conserva o valor existente. Para eliminar um deles, expanda **Remover credenciais salvas**, marque o item e salve. Para renovar, edite a conexão correta e abra **Renovar token preservando agendas**; confira o nome do destino antes de enviar. Se a identidade mudar, leia a prévia e as agendas afetadas antes da confirmação. Em conflito de revisão, releia a conexão antes de repetir.

## 2. Selecionar ativos e conferir dados

Em **Ativos**, selecione a conexão, carregue os ativos disponíveis por canal, marque os desejados e clique em **Salvar ativos selecionados**. Descobrir um ativo não o autoriza. Uma falha de leitura de nomes não deve apagar a seleção salva. Para datasets, escolha uma conta de anúncios autorizada.

Em **Relatórios**, escolha conexão, canal, conta e relatório. Informe período/campos quando exigidos e selecione **Consultar página**. Uma consulta não cria uma agenda. Resultado parcial conserva os dados disponíveis; ausência de uma fonte não é zero. Para diagnósticos do fornecedor, leia COLLECTION-DIAGNOSTICS.md.

## 3. Trocar de conta, filtro ou aba durante uma leitura

Em **Relatórios**, **Histórico**, **Conversas** e **Arquivo de Stories**, os resultados e o botão de próxima página pertencem à consulta que você enviou. O aviso ao concluir identifica a conexão e o ativo. Ao mudar o recorte ou sair da aba, a tela limpa os resultados e descarta o cursor. Consulte novamente para ver a nova seleção. Uma resposta que chegar depois da troca não substitui a tela atual, mesmo que você volte à conta inicial.

Em **Histórico**, comece a exportação CSV/JSON com a conta e o período desejados e permaneça na seleção até o download. Se mudar o recorte ou sair da aba, o painel deixa de avançar ou baixar aquela exportação. Etapas já recebidas pelo servidor e dados armazenados são preservados. Para baixar outro recorte, inicie a exportação na seleção correspondente.

Em **Conversas**, selecione a conta Instagram e clique em **Carregar configuração e permissões** antes de editar. Trocar de conta ou sair dessa aba limpa a página, o token de webhook digitado e as escolhas não salvas do formulário. Alterar somente as datas da consulta não descarta a configuração daquela conta. Para voltar a editar após a troca, carregue a configuração novamente.

Em **Coletas**, **Ver primeira página** mostra os dados no cartão da coleta escolhida, sem misturá-los com os filtros da aba Relatórios.

## 4. Demais tarefas

| Aba | Quando usar | Efeito |
|---|---|---|
| Coletas | Processar páginas ou criar uma agenda | Salva jobs e agendas. O horário UTC indica elegibilidade; a execução depende do cron. |
| Histórico | Consultar dados já persistidos ou exportar CSV/JSON | Consulta o acervo autorizado. Exportar e avançar migração são ações explícitas. |
| Consumidores de anúncios | Autorizar leitura local para um consumidor | Exige concessão específica por consumidor, conta e relatório. |
| Conversas | Configurar página, webhook e leitura de metadados | Recepção e criação de contatos são opções distintas. A criação exige consumidor Core compatível e autorização explícita. |
| Arquivo de Stories | Ver metadados e miniaturas já coletados | Consultar o arquivo não cria uma agenda. A agenda horária é uma ação separada. |
| Diagnóstico | Observar a saúde local ou investigar uma conta | Abrir lê a saúde, sem reparo nem consulta à Meta. **Verificar e recuperar agendamento** pode recompor o cron. **Validar conta selecionada** consulta a Meta. |
| Ajuda | Ler documentação desta instalação | Selecione o documento e leia até “leitura completa”. Trocar o documento limpa o texto anterior. Não requer token nem consulta externa. |

Alterar retenção, credenciais, concessões ou agendamento requer revisão da configuração. Em caso de persistência incerta, consulte conexão, agenda e auditoria antes de repetir. Nenhuma opção do painel publica anúncios ou ativa contatos automaticamente.
