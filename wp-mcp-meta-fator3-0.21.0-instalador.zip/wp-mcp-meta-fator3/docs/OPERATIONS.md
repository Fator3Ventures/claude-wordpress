# Operações Meta — 0.13.0

## Relatórios e catálogo

Instagram: profile, media, stories, account_insights, media_insights, audience, stories_insights. Facebook: page_profile, page_insights, page_posts, post_insights, page_videos, video_insights, page_audience, page_ratings. Consulte list-fields com report e api_version. O catálogo é fechado, versionado e expõe disponibilidade condicional, período, tipo, breakdown, timeframe e horizonte histórico desconhecido. Métricas candidatas não são certificadas para todos os ativos: a API precisa aceitá-las. Demografia legada do Facebook pode estar indisponível; a resposta não a inventa.

account_insights/page_insights aceitam granularity=day ou interval. O comportamento interval preserva a coleta antiga por métrica. day consulta cada dia com limites UTC explícitos e agrupa métricas compatíveis. Cada linha contém data, entidade, métrica, valor ou indisponibilidade. Follows/unfollows usa grupo separado; follower_count e online_followers são condicionais/time_series. Valores únicos não são somados para fabricar total, totais de intervalo não são divididos entre dias e valores acumulados de mídia não são distribuídos retroativamente.

No contexto v24.0 observado no pedido 3, engaged_audience_demographics aceita somente this_month/this_week; last_30_days é recusado localmente com unsupported_timeframe antes de HTTP. A restrição não é generalizada a outra métrica/versão sem prova.

Uma seleção de 14 dias × 10 métricas produz 140 linhas em duas páginas de até 100 quando a origem responde dentro do orçamento. Latência, erros de grupo e quota podem exigir continuações adicionais; nenhum limite autoriza truncar linhas silenciosamente. Parâmetros since/until usam dias UTC; timezone preserva que o calendário da origem pode diferir. Não se certifica alinhamento de um fuso proprietário não documentado.

media_insights requer media_id ou iterate_media=true. stories_insights inventaria Stories ativas e lê métricas de cada objeto. Capturas guardam published_at e observed_at separados. Não há arquivo de imagem/vídeo, scraping, tentativa de recuperar Stories já desaparecidas ou garantia de captura de todas as Stories entre execuções. Recomenda-se agenda de 60 minutos para Stories. post_insights/video_insights requerem entity_id e pertencem ao canal facebook.

## Coletas, agendas e backfill

create-job admite uma seleção fechada e uma chave idempotente. run-job avança uma página; job-status/control-job/job-results permitem acompanhar, pausar, cancelar, retomar e ler. O cron usa os mesmos métodos. A página durável precede o checkpoint, permitindo retomada após interrupção. Limite de 10000 páginas; ao atingi-lo com continuação a coleta termina parcial, nunca completa.

create-backfill requer date_from e fixa date_to (padrão ontem UTC), máximo 3660 dias. A origem não comprova um horizonte universal. Métricas de conta usam day; mídia usa iterate_media para observar o acumulado disponível agora. O plano pode cobrir dois anos, mas a API pode limitar o que entrega: o aceite externo de dois anos exige evidência diária e permanece pendente até execução autorizada. Erros/supressão ficam como lacunas, não zeros.

Agendas mantêm a preferência enabled quando a execução fica bloqueada e registram last_code; nova tentativa ocorre após cinco minutos. Troca validada de token conserva agendas. Cursores remotos de inventário são reiniciados após troca validada, com deduplicação no histórico; exportação bruta do job pode conter observações repetidas da retomada. Cursores de partições diárias conservam a posição local. Alteração de autorização exige salvar novamente a agenda com sua revisão atual.

## Histórico e exportação

O histórico cifrado é independente da retenção do registro do job. Chave lógica considera principal, conexão, canal, conta, relatório, entidade, métrica, dia, temporalidade, API, timeframe e breakdown. Observações sobrepostas atualizam a mesma chave; first_seen/last_seen preservam a procedência. Snapshots guardam o último valor observado em cada dia, não todas as observações intradiárias.

history-query requer conexão/canal/conta, aceita relatório, período, limit e cursor. O cursor fixa seleção, principal, autorização e geração do conjunto. Mudanças do histórico invalidam a continuação com history_changed; reinicie para não misturar visões. Leitura local dispensa token válido, mas exige autorização atual e ativo habilitado.

history-export cria exportação CSV/JSON paginada. Execute history-export-step até state=complete; baixe history-export-read por part e offset_bytes. Concatene partes decodificadas em ordem, sem separador; cada parte tem SHA-256. Sem expiração automática, limite de 64 MiB por exportação, nenhuma URL pública. CSV mantém row_json/coverage_json para não perder estruturas e neutraliza fórmulas. Exportação de job continua disponível via export/export-read, até 8 MiB de páginas/12 MiB finais.

**Qual seleção permite baixar?** Para `dataset_quality`, tanto o dataset (`account_id`) quanto a conta de anúncios vinculada (`ads_account_id`) precisam continuar selecionados na mesma conexão. Isso vale para consultar o histórico, ler as páginas locais de um job, preparar/repetir/avançar uma exportação e baixar cada trecho CSV/JSON. Remover um dos dois ativos bloqueia novas leituras, inclusive de arquivos já completos (`asset_access_denied`). Os bytes cifrados continuam armazenados. Com ambos novamente selecionados e o principal original ainda autorizado, uma exportação completa pode ser lida outra vez; um cursor de uma consulta em andamento pode exigir reinício se o histórico ou a revisão da seleção mudou. Os outros canais não exigem conta Ads adicional.

**Como retomar após falha de escrita?** Guarde o `export_id`. Se uma parte não conseguir confirmar sua gravação (`persistence_unconfirmed` ou `storage_unavailable`), não descarte o recibo nem use nova chave por padrão. Após restabelecer o banco, repita `history-export-step` com o mesmo ID: se a parte já foi persistida, o Meta recupera seu checkpoint e continua da página seguinte; se não foi, tenta a página que ainda falta. Só inicie o download com `state=complete`. Se o estado for `failed` por alteração da visão histórica (`history_changed`), inicie nova exportação com nova chave para usar uma visão consistente. Uma falha terminal já registrada anteriormente não é reescrita pela atualização.

## Histórico — Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.


## Pedido 15 — contrato de credenciais 0.9.0

`save-connection`/`rotate-token`: a candidata é validada na Meta antes de escrever. Entradas existentes são preservadas, mas valores novos inválidos agora são recusados. `save-connection`, `rotate-token` e `switch-identity` anunciam efeito remoto de leitura e efeito local de escrita; todas exigem manage_options. Identificadores anteriores não são renomeados.

Nova `meta/switch-identity`: `{connection_id, expected_revision, token, dry_run, label?, client_id?, client_secret?, expires_at?, confirmation?}`. Simulação obrigatória com dry_run=true devolve `persisted=false`, identity, schedules, connection_revision, confirmation e confirmation_expires_in=600. Execução com dry_run=false exige a confirmation da mesma candidata/revisão. O comprovante é cifrado/autenticado e específico do site, nunca contém o token em claro. Simulação faz HTTP de leitura e a auditoria usual; não grava conexão/agenda.

Gravações de conexão retornam `persisted`, connection pública, schedules_rebased (quantidade) e schedules_requiring_review (IDs). `token_identity` inclui os nomes confirmados, validade, scopes/extra_scopes e instante da conferência; nenhum segredo é retornado. Códigos estáveis: invalid_token_format, invalid_app_id, invalid_app_secret, app_proof_required, credential_app_mismatch, credential_identity_mismatch, credential_scopes_reduced, token_rejected, token_expired, asset_access_denied, validation_limit, confirmation_mismatch, invalid_cursor/cursor_expired, revision_conflict, storage_unavailable e persistence_unconfirmed. Mensagens são em português e não reproduzem corpo bruto da Meta.

`retryable` não prova ausência de efeitos. Em persistence_unconfirmed, releia conexão, agendas e auditoria antes de repetir. A confirmação consumida na troca deixa a revisão antiga inválida. Não reenvie segredos em logs/relatórios. Formatos e exemplos completos são os schemas instalados.


## Histórico — Versão 0.10.0 — Pedidos MCP Meta 16 e 17

A prévia de troca de identidade aparece junto do formulário que a pediu; a origem Renovar token abre o bloco automaticamente. A prévia recebe foco e anúncio acessível. A recusa de identidade fica junto de Salvar conexão e aponta o botão de troca. `meta/switch-identity` aceita `label` opcional (até 120 caracteres): o nome é incluído na prévia (`connection_label`), vinculado à confirmação e salvo junto da credencial e das agendas na mesma revisão/transação. Sem label, preserva o nome salvo. Editar a candidata invalida a prévia; resposta assíncrona obsoleta não a reabre.

Stories indisponíveis têm códigos próprios; revogação da conexão exige confirmação independente. Agendas e auditoria guardam código Graph, subcódigo, HTTP e instante. O aviso passa a uma tentativa por incidente e mostra a causa medida. Consulte `COLLECTION-DIAGNOSTICS.md` para códigos, efeitos, recuperação, persistência e limites. Na série 0.10, os 35 IDs de operações foram preservados e label foi acrescentado a switch-identity. Na série 0.11, somam-se seis operações, totalizando 41.


## Complemento 0.11.0 — pedidos 18/19

Consulte INSTAGRAM-MESSAGING.md para as operações administrativas de conversas, configuração, escopos, webhook e contrato local instagram-first-message/1.0.0. Core 1.56.0 registra o consumidor de ingestão; contatos exigem opt-in explícito nos dois pacotes. A eliminação coordenada é descrita em MESSAGE-PRIVACY.md; Core1.57.1 já integra esse SDK. Consulte STORY-ARCHIVE.md para novos campos/breakdowns, limites do arquivo privado, agenda horária e diagnóstico de supressão. Os 35 IDs anteriores são preservados e há seis operações aditivas (41).


## Meta Ads na 0.13.0

Pedido20 inclui leitura Ads: seleção explícita/ads_read, dias completos no fuso da conta, acervo cifrado sempre sem prazo, agendas e CSV/JSON. Canal ads, relatório ads_insights, nível selecionável. Consumidores locais exigem registro e concessão explícita, desligada por padrão. Leia META-ADS.md e META-ADS-READER.md. Nenhuma escrita em anúncios, alteração do LinkedIn ou ingestão comercial implícita. Pedido21 distingue coleta parcial de falha em COLLECTION-DIAGNOSTICS.md.

## Pedido 25 — orçamento local na 0.17.0

`budget_exhausted` indica limite de chamadas/tempo da execução PHP. Não existe quota diária local por conexão ou agenda. Leia EXECUTION-BUDGET.md para consumo, prazo, próxima execução estimada, prioridade de agendas, quota remota separada e incidente após 24 horas. `meta/health` e `meta/list-schedules` expõem esses dados sem chamar a Meta nem enviar e-mail.

## Diagnóstico histórico — 0.18.0

Pedido 26: last_error_at/last_error_superseded/last_error_state em list-schedules e health.schedules distinguem erro corrente de histórico. Leia COLLECTION-DIAGNOSTICS.md; não classifique uma agenda usando apenas last_error nem confunda dados parciais úteis com conclusão. Leitura não regrava dados ou dispara notificações.
