# Fator3 MCP Meta 0.21.0

Plugin independente. Configure em Ferramentas > Fator3 MCP Meta. Entradas humanas (painel, REST, abilities/MCP, arquivos e tarefas iniciadas por usuário) exigem `manage_options`. A lista legada `users` não concede acesso a pessoas sem essa capacidade. O transporte MCP é opcional; o plugin não chama Google, Core ou outro provedor para executar relatórios.

## Comece aqui

1. Leia ADMINISTRATION.md para cadastrar a conexão, selecionar ativos e fazer a primeira consulta.
2. Consulte CONFIGURATION.md para credenciais, permissões e validade. RETENTION.md explica quais dados ficam sem expiração.
3. Abra Diagnóstico para observar a saúde sem reparo nem chamada externa. Recuperação do cron e validação na Meta são ações explícitas.
4. Para configurar consumidores, use os guias de anúncios, monitoramento e conversas. Acesso depende de concessão própria.
5. Na Ajuda do painel ou em meta/documentation, consulte o índice e leia o documento da versão instalada.

## Instalação

WordPress ≥ 7.1.4, PHP ≥ 8.3 de 64 bits, InnoDB/bloqueios nomeados e criptografia autenticada. Acesso externo às APIs requer HTTPS, token válido, escopos e ativos; coletas agendadas exigem cron. Instalação limpa ou troca direta da 0.20.0. Há 47 operações; nenhum schema público mudou nesta rodada. Para entender por que uma exportação pode deixar de ser legível após remover um ativo, consulte OPERATIONS.md. Para repetir uma consulta depois de mudar a seleção, consulte ADMINISTRATION.md.

## Documentos por tarefa

- EXECUTION-BUDGET.md — limite local de execução e recuperação de orçamento.
- MONITORING.md — atividades e qualidade de datasets.
- COLLECTION-DIAGNOSTICS.md — cobertura parcial, erros de fornecedor e interpretação.
- CORE-MONITORING.md — configuração e concessão no Site Core, operação, alertas e aceite.

- META-ADS.md — seleção, coleta, atribuição, acervo, limites e aceite remoto.
- META-ADS-READER.md — registro, concessão e contrato local do consumidor.
- MESSAGE-PRIVACY.md — autorização, eliminação, recibos, concorrência e recuperação.
- messaging-privacy-schema.json — schema gerado do SDK local de eliminação.

- RETENTION.md — retenção máxima, atualização e limites de segurança.
- INSTAGRAM-MESSAGING.md — conversas, autorização, webhooks e SDK do Core.
- STORY-ARCHIVE.md — métricas, agenda horária e arquivo privado de Stories.
- ADMINISTRATION.md — abas, seletores e fluxos de administração.
- AGENTS.md — operação por agentes e limites de autorização.
- CONFIGURATION.md — tokens, seleção e acesso.
- OPERATIONS.md — consultas, processamento e exportações.
- CONTRACTS.md — contratos, REST/MCP, schemas e erros.
- SDK-PHP.md — SDK local e responsabilidade de consumidores.
- SECURITY.md — isolamento, dados e autorização.
- MIGRATION.md — atualização, preservação de dados e correção por nova versão.
- PAGE-VIEWS.md — campo de visualizações do perfil e limites de validação.
- PAGE-DIAGNOSTICS.md — diagnóstico de permissões e insights por Página.
- TROUBLESHOOTING.md — diagnóstico, limites e falhas.
- CHANGELOG.md — alterações da versão.
- WORKER.md — fila, recuperação, diagnóstico somente leitura (`meta/health`) e alertas.
- abilities-pt-br.json — rótulos e descrições das 47 habilidades, gerados do registro.
- input-schemas.json e output-schema.json — contratos gerados pelo build.

Todos estes arquivos integram o instalador e o conteúdo retornado por `meta/documentation`. Consulte `{"document":"index"}`. Para ler um documento use `document`, `offset` (bytes) e `limit_bytes` (256–65536). Continue por `next_offset`, repetindo `expected_revision` igual a `revision`. Concatene `content` sem separadores; confira o SHA-256 integral indicado. O cursor documental não faz HTTP, não migra armazenamento, não grava auditoria nem lê caminhos arbitrários. A resposta identifica slug, versão, origem local, tamanho e hash. O painel usa a mesma operação.

