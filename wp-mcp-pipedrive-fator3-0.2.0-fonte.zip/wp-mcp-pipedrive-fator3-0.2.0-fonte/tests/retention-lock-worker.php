<?php
$root=$argv[1]??'';
if(!str_contains($root,'f3-pipedrive-qa-0200-'))exit(2);
define('ABSPATH',rtrim($root,'/').'/');require ABSPATH.'wp-load.php';
if(!str_starts_with($wpdb->prefix,'f3pipqa_'))exit(3);
$name='f3pip_ret_'.substr(hash('sha256',DB_NAME.'|'.$wpdb->options),0,48);
if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 1)',$name))!=='1')exit(4);
fwrite(STDOUT,"LOCKED\n");fflush(STDOUT);fgets(STDIN);
$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$name));
