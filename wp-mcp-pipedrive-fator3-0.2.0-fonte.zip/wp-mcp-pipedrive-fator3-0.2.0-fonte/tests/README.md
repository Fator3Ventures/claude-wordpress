# Testes — 0.2.0

Executar exclusivamente em WordPress descartável com prefixo próprio. As baterias alteram usuários, options e dados sintéticos e não devem ser chamadas no banco compartilhado. Não integram o instalador.

## Disposição e execução

`lab-controller.php` registra a ability temporária administrativa `qa-pipedrive020/run`, com `acao` e `cenario` (`current` ou `upgrade`) enumerados. Código PHP instalado é confiável; esse controlador é instrumento de laboratório, não executor para usuários. Ele prepara dois diretórios privados `/tmp/f3-pipedrive-qa-0200-d848899a8f83-{cenario}`, com marcador exclusivo, e prefixes `f3pipqa_0200c_`/`f3pipqa_0200u_`. Antes de reproduzir, conferir ausência desses recursos e autorização de uso. Nunca adaptar o filtro de limpeza para tabelas de negócio.

O bundle temporário esperado em `wp-content/f3-pipedrive-qa-0200.zip` contém `runner.php` (cópia de `lab-runner.php`), `installer.zip` (0.2.0), `base.zip` (0.1.0, hash no relatório), e os testes PHP em `tests/`, exceto lab-controller/lab-runner. Não incluir wp-config ou banco. Esse bundle de QA não faz parte da entrega. O controlador referencia os arquivos WordPress e acompanhantes existentes só para leitura; usa wp-content, salts, usuários e SQL isolados, e bloqueia HTTP/e-mail desde o bootstrap. Configuração privada com modo 0600 fica fora do webroot e é excluída ao final.

Sequência, uma chamada por ação e em processo PHP novo:

1. `cenario=current`: setup → install → native → retention → integrate → integrated → core.
2. `cenario=upgrade`: setup → install-base → seed-upgrade → upgrade → verify-upgrade → upgrade-restart.
3. `cleanup` para cada cenário. Conferir zero tabelas restantes e diretório ausente; excluir bundle/controlador temporários com backup e hash esperado; verificar desaparecimento da ability e inventário/saúde do hospedeiro.

`install` e `upgrade` usam Plugin_Upgrader; overwrite nativo é seguido por processo novo antes de conferir código e dados. A suite native exige banco recém-preparado; repeti-la sobre os mesmos usuários/registros invalida suas premissas. O teste de atualização usa três operações e duas linhas de diário com 400 dias, incluindo dados cifrados, compara byte a byte antes de qualquer limpeza e verifica escolha finita em novo processo/reativação.

A suíte native tem 76 verificações; retention 33; integrated 25; core-retention 8; verify-upgrade 9; upgrade-restart 2. Total final: 153, sem somar setup, lint ou tentativas preliminares. Core original 1.56.0, MCP 0.33.0, Google 0.19.0, Meta 0.12.0 e LinkedIn 0.10.1. A integração Core usa suas classes reais e credencial/respostas HTTP sintéticas; não acessa fornecedor real. A suíte MCP executa o executor/política originais em WordPress; não é uma sessão HTTP MCP própria da 0.2.0 no site compartilhado.

Concorrência: `race-worker.php` disputa uma prévia em dois processos; `retention-lock-worker.php` mantém a trava em outra conexão MySQL enquanto configuração e limpeza são recusadas. Não remover marcadores, guardas ou isolamento para fazer o teste passar.

## Painel e limites

O painel é executado com funções administrativas nativas: POST com nonce válido altera a política, nonce inválido recusa, revisão é preservada e o formulário renderiza campos atuais. O HTML foi capturado somente para inspeção interna; não é artefato da entrega. Uma tentativa de renderização visual local não pôde iniciar Chromium, ausente no ambiente. Não há alegação de inspeção visual completa em navegador.

Os primeiros ensaios identificaram faltas no harness herdado: includes administrativos (template/file), marcador do worker e repetição de uma suite que exige estado limpo. Foram corrigidos no harness, sem afrouxar gates do produto; a rodada final passou. O executor local também ficou temporariamente indisponível e voltou com os arquivos preservados. Não contar essas tentativas como testes aprovados.

O Site-Teste compartilhado permaneceu com 0.1.0: a revisão automática rejeitou a instalação 0.2.0 por exigir autorização explícita da implantação. Nenhum código do produto foi escrito diretamente para contornar a rejeição. Fontes/evidências não contêm banco, wp-config, valores de credenciais reais ou estado de sessão.
