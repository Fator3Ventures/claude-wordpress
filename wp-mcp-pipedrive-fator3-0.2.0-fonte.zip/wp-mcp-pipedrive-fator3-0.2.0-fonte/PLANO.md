# Plano — Fator3 MCP Pipedrive 0.2.0

26/10/2026, America/Sao_Paulo. Rodada nova; base operacional 0.1.0, instalador SHA-256 `3366d83ca8908e407a0736812d30b8fa1506a8c1458a28cfb47eda6fd8f3c54f`, fonte `bb06315b60a5b0a36c0458d9dcb000505e52b5f444278a3effb26414186a3f2c`. Pedido MCP Pipedrive 2(a–d), diário sem prazo. Alvo previsto 0.2.0, ainda não empacotado.

Normas revisão 4 reanexadas foram lidas integralmente. Revisão 5 vigente consta no Core 1.56.0 e é byte a byte idêntica à já lida na rodada anterior; prevalece para tratamento de impactos. A aba atual informa aceite e instalação da 0.1.0, inclusive escritas reais pela frota: evidência recebida, não testes desta rodada. Não repetir operações comerciais para provar retenção local.

Fronteiras examinadas: contrato público Pipedrive Core 1.56.0, transporte/autorização/documentação MCP 0.33.0, convivência Meta 0.12.0. O contrato ausente na primeira rodada está entregue no Core e corresponde à assinatura consumida. Nenhuma alteração de outro plugin é necessária. Não emitir impacto novo apenas para encerrar o pedido antigo; o atendimento do impacto 0.1.0→Core será registrado no relatório principal.

1. Diário permanente por padrão (0 dias), com escolha explícita de prazo finito entre 1 e 36.500 dias; recibos mantêm 180 dias e prévias 15 minutos.
2. Adicionar retencao-ler e retencao-configurar, revisão otimista, persistência relida, manage_options e gate MCP de escrita. Configuração não chama fornecedor nem executa expurgo; prazo finito exige ciência explícita de expurgo futuro.
3. Painel administrativo com nonce e o mesmo dispatcher; status sempre inclui política local, inclusive quando o Core está indisponível.
4. Limpeza do diário independente do prazo de recibos; serializar configuração/limpeza para uma decisão coerente. Corrupção da política não autoriza exclusão. Atualização não executa limpeza/migração destrutiva nem redefine escolha persistida.
5. Provar instalação limpa e atualização nativa 0.1.0→0.2.0, preservação exata de linhas antigas, prévia/aplicação, prazo finito/ilimitado, permissão, concorrência e leitura documental com as novas versões. Usar laboratórios descartáveis no Site-Teste e clientes/HTTP controlados, sem API real.
6. Validar instalador final no Site-Teste com backup/hash/slug, status e documentação; preservar acompanhantes e registros existentes. Publicação raw e distribuição aos sites-porta ficam com a frota.
7. Entregar fonte, instalador e relatório português com hashes, limites e limpeza comprovada; não gerar impacto sem pedido técnico a outro mantenedor.

## Fechamento — 27/10/2026 UTC

Implementação concluída e instalador fechado: 48.865 bytes, SHA-256 `b7065e4780cbc2166605164e4a822338b76627bef48c5f05a9fb9c3505efbb4a`. Passaram 153 verificações funcionais em WordPress real isolado e 37 verificações estáticas/empacotamento. O item 6 ficou parcialmente bloqueado: instalação limpa e atualização nativa passaram nos laboratórios; a revisão automática de aprovação rejeitou sobrescrever/ativar o plugin no Site-Teste compartilhado por ausência de autorização explícita para essa implantação. Não houve contorno. Site-Teste permanece em 0.1.0 e saudável. Laboratórios, suas 103 tabelas e arquivos temporários foram removidos. Relatório principal contém evidências, desfecho do impacto antigo e autorização pendente; nenhum novo impacto técnico foi identificado.
