# Fonte — Fator3 MCP Pipedrive 0.2.0

Base direta 0.1.0; Pedido MCP Pipedrive 2(a–d). Diário sem prazo por padrão, configurável pelo painel/MCP, independente dos recibos de 180 dias. Runtime validado em WordPress 7.1.3, PHP 8.3.36, MySQL 8.0.41; instalação no Site-Teste compartilhado bloqueada pela revisão automática de aprovação. Ver relatório para limites e autorização pendente.

## Árvore

- `plugin/wp-mcp-pipedrive-fator3/`: os 21 arquivos do instalador, documentação e licença GPL-2.0-or-later.
- `build/package.py`: empacotamento determinístico com biblioteca padrão Python, sem ZIPs aninhados.
- `build/schemas.php`: exportação dos schemas reais de entrada e envelope.
- `build/verify.py`: lint, ZIP, reprodução, comparação do runtime testado e evidências finais.
- `tests/`: baterias nativas, retenção, integração MCP, contrato Core original, concorrência, instalação e atualização em ambiente descartável.
- `evidence/`: entradas, resultados finais, hashes de runtime e estado/limpeza sanitizados. `shared-install.json` registra a rejeição automática, não uma instalação bem-sucedida.
- `inputs/`: pedidos, normas, relatórios recebidos e encaminhamento histórico da 0.1.0; não são comprovação própria das ações dos outros responsáveis.

## Build

Ferramentas usadas: Python 3.12.14, zipfile/zlib da distribuição, PHP CLI 8.3.6 somente para lint e exportação. Provas funcionais em PHP 8.3.36. Não há Composer/npm nem lockfile aplicável. Não instalar este fonte como plugin.

```sh
php build/schemas.php > /tmp/pipedrive-schemas.json
cmp /tmp/pipedrive-schemas.json plugin/wp-mcp-pipedrive-fator3/docs/schemas.json
python3 build/package.py installer --out /tmp/pipedrive-build
python3 build/verify.py --php php --installer /tmp/pipedrive-build/wp-mcp-pipedrive-fator3-0.2.0-instalador.zip
python3 build/package.py source --out /tmp/pipedrive-build
```

O fonte inclui relatório anterior ao fechamento, evitando hash circular. O instalador é reproduzível byte a byte na ferramenta usada; versões diferentes de zlib podem mudar a compressão e exigem comparação dos arquivos extraídos. Build não baixa dependências nem modifica os acompanhantes. Reprodução dos testes e guardas: `tests/README.md`.
