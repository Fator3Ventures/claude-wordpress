# Fonte do Fator3 Site Core 1.84.0

Árvore instalável em work/plugin/base-site-core-fator3. Notas e guias estão em docs/ nessa árvore. A base 1.83.0 está em history/1.83.0-runtime. Veja PLANO-1.84.0.md e RELATORIO-PRE-FECHAMENTO.md. Evidência da rodada em evidence/1840; arquivos de rodadas anteriores permanecem identificados.

Reconstrução: build/assets-1840.py (Terser fixado no build/node), tests/verificar-entrega.py, build/reproduzir-instalador.py e build/conferir-instalador.py. Para testar em WordPress descartável, execute tests/run-1840.py com F3BASE_PHASE=fresh ou upgrade. O banco e o diretório de laboratório precisam ser exclusivos.
