# Validação — Core 1.22.0

Data: 06/10/2026. WordPress local 7.1.2, PHP 8.3.6 de 64 bits, MariaDB 10.11.14. Dados sintéticos. Rede externa e wp_mail bloqueados; adapters simulados interceptam apenas os destinos de teste. Nenhuma implantação ou teste nos sites da frota.

## Evidência executada nesta release

- Instalação nova e atualização usando o fonte real 1.21.0, em bancos separados; estrutura confirmada, origem correta, país BR persistido, preferências/atividades desligadas e listas vazias preservadas, procedência e repetição idempotente.
- Suíte PHP final: 18 processos concluídos com exit 0; intervalo correspondente de log sem novo Fatal/Uncaught. Inclui injeções intencionais de falha de banco, sem confundi-las com concorrência.
- Procedência: complemento, reparo com evidência, simulação, idempotência, revisão obsoleta, país ausente/vazio/escolhido, falha parcial de auditoria e retomada; caminhos aninhados/valores explícitos.
- Candidato CRM: recusa 401/403, 429, timeout, resposta malformada, verificação válida, simulação sem opções gravadas, conflito durante consulta, exclusão e segredo intocado ao salvar GTM.
- Salvamento das áreas intocadas e só GTM; zero/integer inválido, submissão truncada, contexto consumido e alteração concorrente.
- Contexto de formulário: limite de dez, expiração sem JS, renovação administrativa, teto absoluto, revisão original mantida e nenhum segredo no contexto. JavaScript executado em jsdom 26.1.0 para renovação/erro e editor de mapas; não é teste visual.
- Três abas renderizadas com tokens endpoint-leads/comportamento presentes; seis seções de medição, lista antiga de seis e-mails e ajuda efetiva de Integrações. HTMLs da rodada estão nas evidências de render.
- CLI real via WP-CLI, processo cron com DOING_CRON e chamada administrativa concorrentes: efeito único, uma identidade de ocorrência e três origens no diário. Falhas de checkpoint/reagendamento/consumo têm causa saneada e retomam a mesma ocorrência.
- Recuperação em processos novos: guarda ausente/inválida/pausada e trava ocupada; documentação administrativa disponível, anônimo recusado e negócio inerte; recriação continuamente pausada seguida de preparar.
- CRM simulado: núcleo entregue, ausência de duplicação, nota, identidade, atividade v2 com participants e fuso, recusa complementar/retomada só da atividade, diagnóstico, e-mail alternativo explícito/idempotente e seleção de pessoa incerta sem novo POST. Campos numéricos/data/monetário, título Unicode, limites e omissão opcional testados.
- Avisos: separação do resumo, destinatários, cron sem usuário, falha/timeout, repetição por episódio. Jornada, leitura por capability e autorização negativa; tabela com colunas alinhadas e URLs saneadas.
- GSC: quatro estados opcionais do SDK, inválido/exceção/fallback e anúncio sem método, lacunas; requisições repetidas sem PSL após prova persistida e invalidação por host.
- Redirects: revisão/permissão/retirada seletiva; HTTP local devolveu 404 na URL retirada e 301 na outra URL histórica.
- Sintaxe: 159 PHP e 27 JavaScript sem erro; JSONs lidos; nove pares de assets minificados conferidos com Terser fixado. Schemas gerados de 51 opções e 96 abilities.

- Adendo 135: formulário Clarity, cadastro de ID/token juntos, cifra/máscara, vazio/remoção, configuração obsoleta, autorização/nonce, trava, coleta e relatório, reenvio idempotente, 401/429/timeout/JSON inválido e teto conjunto de dez consultas. Nenhuma credencial real ou chamada Clarity externa.

A prova do instalador fechado e seus hashes ficam no relatório de entrega e na suíte de fontes, para evitar autorreferência dentro do ZIP. Evidências antigas da 1.21 são históricas, não prova desta release.

## Limitações explícitas

Chrome Headless Shell falhou ao iniciar neste ambiente com SIGSEGV. Playwright não concluiu a inspeção visual desktop/celular. A validação disponível é renderização PHP/HTML, DOM/JavaScript e testes de serviços; não substitui avaliação visual/teclado em navegador real.

Pipedrive/Google/Clarity/SMTP foram simulados. Não houve envio de e-mail real, criação de objetos em conta Pipedrive, renderização da nota no CRM, consulta GSC real ou prova de commit remoto. Matriz conjunta com pacotes MCP/Google reais, teste no Site-Teste/frota, servidores Apache/Nginx/proxy/cache e observação por sete dias pertencem à homologação posterior. Nenhum teste antigo de outra versão foi promovido a aceite atual.

A prevenção do defeito 134 foi validada. Recuperar autoria perdida em cada site depende de fotografia/histórico verificável; a migração não afirma que recuperou os 14 sites. Ausência de histórico permanece diagnosticada.

Não foram exercitadas todas as combinações de interrupção abrupta em cada POST externo nem falhas reais de filesystem/hospedagem. Checkpoints, retomadas, recusa e incerteza são testados localmente nos cenários descritos; não oferecem garantia distribuída de exatamente uma criação entre vários sites.
