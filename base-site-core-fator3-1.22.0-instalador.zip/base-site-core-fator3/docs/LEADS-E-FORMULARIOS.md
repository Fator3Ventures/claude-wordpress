> Versão vigente: Core 1.22.0. Consulte RELEASE-1.22.md e os guias 1.22 para mudanças e precedência; exemplos antigos de instalação não autorizam bases anteriores à 1.21.0.

# Leads, formulários e arquivos — 1.19.0

## Repositório e contexto

O destino dos cliques e envios nativos é a tabela `{prefixo}f3base_leads`. Flamingo não é dependência da captura atual. A base suportada já contém `sessao`, `post_id`, `resposta`, `resposta_em` e `resposta_erro`. A 1.14 acrescenta a classe de tráfego sem apagar linhas anteriores.

| Campo | Origem e significado |
|---|---|
| `record_id` | Identificador próprio do registro, gerado no servidor. |
| `correlacao` | Identificador da ação. O clique transporta `correlation_id`, normalizado para a coluna. Aliases conflitantes são recusados. |
| `sessao` | 32 caracteres hexadecimais, obtidos de `f3baseTracking.sessao()`, sob consentimento de medição. É o mesmo identificador empregado pelo tracking no repositório de eventos. |
| `post_id` | ID da página pública resolvido no servidor pela URL, nunca por um ID livre fornecido no clique. Nulo se não resolvido. |
| `dados.contexto.ip` | Endereço da requisição segundo o resolvedor de origem confiável. Cabeçalhos encaminhados só valem com proxy declarado. |
| `dados.contexto.user_agent` | User agent recebido pelo servidor, sanitizado e limitado. |
| `dados.contexto.sessao_motivo` | Informa sessão recebida, tracking sem sessão ou medição não permitida. |
| `dados.snapshot` | Nome do site, URL e título da página no momento da captura. |

Sessão não é identidade pessoal nem chave deduzida por IP/horário. Sem tracking, sem JS ou sem autorização, a coluna pode ser nula. Dados nunca capturados não são reconstruídos por suposição. O CSV e a leitura privada expõem o contexto novo mediante permissão; o JSON do registro mantém o snapshot completo.

## Métodos

| Ação | Método |
|---|---|
| Clique para `wa.me`, `api.whatsapp.com`, `web.whatsapp.com` ou `whatsapp://send` | `whatsapp_cta` |
| Clique de contato para destino interno/externo não WhatsApp, telefone ou e-mail | `contato_cta` |
| Envio nativo de registro | `formulario` |
| Envio nativo que abre WhatsApp | `whatsapp_formulario` |
| Envio de conteúdo fechado | `conteudo` |
| Acervo sem origem comprovada | `legado_desconhecido` |

A captura de CTAs marcados funciona também em páginas sem formulário e sem `whatsapp_e164`. O script continua adiado (`defer`), e somente o botão flutuante exige número e ativação. Os destinos permanecem sob controle do conteúdo/tema.

Nome e e-mail não classificam o método. Domínios parecidos ou URLs com credenciais não são reconhecidos como WhatsApp. Abrir um diálogo não é envio; a conversão nativa ocorre após aceite. `generate_lead.method` acompanha a ação. A disponibilidade de um evento em GA4 exige verificação do destino real.

## Acervo e análise

A atualização preserva o acervo já pertencente ao Core. Não importa nem normaliza novamente CF7/Flamingo. A origem histórica preservada continua legível; registros sem método comprovado aparecem separados, sem inferir dados ausentes.

O contexto novo inclui `dados.navegacao` (carregamento), `dados.dispositivo` (faixa de tela), atribuição da sessão e `dados.campos_relatorio` (snapshot das opções fechadas). O detalhe do contato permite abrir a jornada observada. Consulte RELATORIOS.md para os cruzamentos e limitações.

Mudanças de atendimento geram histórico com estado anterior/novo, horário, revisão e operador. O relatório mede tempo até a marcação manual de respondido, sem afirmar o horário real da primeira resposta. Falha ao guardar o histórico desfaz a alteração de estado na transação.

## Anexos

Sem `max_bytes`, ou com `max_bytes:0`, não existe teto de tamanho do plugin por arquivo. `extensoes:[]` ou ausente não limita extensão. Um valor positivo continua sendo respeitado; a atualização não remove restrições deliberadamente salvas.

Continuam valendo os limites do PHP (`upload_max_filesize`, `post_max_size`, `max_file_uploads`), espaço e tempo de execução, além de servidor/proxy. O diagnóstico lê os valores do PHP, informa se o limite alcança a requisição completa e declara o limite do proxy como desconhecido. Não apresenta um teto inferido como se fosse medido. A quantidade padrão continua sendo até cinco arquivos por campo.

Arquivos ficam fora das raízes públicas conhecidas, recebem nome opaco e permissão restrita e são baixados pelo fluxo autorizado. Não há fallback em uploads públicos. Extensão livre não concede execução no servidor. Conteúdo fechado continua usando concessões com validade/quota, revogadas quando o registro é eliminado.

## Resposta ao visitante

A opção `resposta_visitante.ativa` é falsa por padrão. Um envio novo aceito pode reservar uma resposta independentemente do aviso interno. Suspeitos, duplicados, cliques e registros importados não disparam essa resposta.

Estados: `desligada`, `pendente`, `enviando`, `processada`, `falhou`, `incerta`, `expirada`, `desconfigurada`. `processada` significa que `wp_mail` aceitou o envio; não comprova recebimento na caixa postal. Há limite de 3 respostas por destinatário/hora e 30 por site/hora, com janela de 24 horas. O cron existente trata pendências; uma reserva abandonada por mais de cinco minutos vira `incerta`, sem reenvio automático.

A ability `f3base/leads-resposta-reenviar` exige simulação e revisão. Estado incerto exige `aceitar_possivel_duplicacao:true`; estado processado não é reenviado por ela. Falha de envio não elimina nem invalida o lead. A interface de contatos mostra o estado da resposta; o detalhe do registro contém os campos de acompanhamento.

## Caixa de entrada e editor

Contatos oferece filtros por método, formulário, estado, período, origem/anúncio e segmento de testes; detalhe e retorno preservam o recorte. A jornada mostra somente dados observados anteriores ao contato. CSV exporta o conjunto filtrado em arquivo privado temporário e só inicia a resposta depois de terminar a leitura; fórmulas são neutralizadas. Limites explícitos evitam download parcial anunciado como completo.

Formulários abre uma lista com estado, usos e ações. Editar abre uma definição por vez. Novo e Duplicar começam inativos, com resposta ao visitante desligada; IDs salvos ficam estáveis. Campos são recolhíveis e controles variam por tipo. O editor JSON avançado fica separado, com o mesmo schema e revisão. Conflito mantém o rascunho. Remoção de definição usada é recusada; inativação conserva contatos anteriores. Referências dinâmicas do tema podem exigir conferência adicional.

A rapidez do preenchimento (`tempo_curto`) é apenas informativa. Não bloqueia nem classifica spam sozinha. Honeypot, token, validação, quotas e idempotência permanecem. Essas medidas reduzem abuso sem prometer ausência de spam. Reenvio após falha mantém a mesma instância; sucesso permite iniciar outro envio explicitamente.

Marcação de teste acompanha o contato e a fila. Não envia resposta ao visitante nem aviso comercial quando suprimido; destino de teste só é usado se configurado. Aprovar um suspeito não emite conversão retroativa automaticamente. A superfície do CTA é separada do seu identificador e método, preservando a série de form_id existente.


## Consentimento e conversões na 1.16.0

Cliques e formulários usam a mesma normalização de atribuição. Sem medição permitida, o Core remove sessão, navegação e toques persistentes e conserva somente a origem recebida para a navegação corrente. Recusa de publicidade remove `fbc`/`fbp`, sem impedir o registro funcional do contato. Payload do navegador não amplia a permissão confirmada no servidor.

A CAPI parte do lead persistido e preserva marca de teste, correlação, horário, origem e snapshot de consentimento. Supressão de testes é o padrão. Test Events exige configuração explícita e consentimento; não autoriza envio comercial. Repetição usa o mesmo identificador e fila durável. Não há reenvio automático do histórico. Pipedrive é opcional e já está disponível; consulte PIPEDRIVE.md. O transporte PageView/Lead Meta da 1.19 está em META-TRANSPORTE-1.19.md.


## Integrações e papéis na 1.16

Contatos centraliza registros, formulários, conteúdo privado e integrações. Cada campo pode declarar papel empresa, cargo ou serviço; serviço deve vir de opções fechadas ou valor fixo configurado, não de inferência por rótulo. A captura preserva o snapshot dos papéis/rótulos para futura interpretação. O checkbox Pipedrive é subordinado à ativação global. Consulte PIPEDRIVE.md para mapeamento e dados de jornada.

O assunto de aviso/resposta é composto por uma rotina comum que evita repetir o nome do site. Prévia do editor usa a mesma composição. Testes continuam suprimindo e-mails externos por padrão. A resposta opcional ao visitante permanece desligada até habilitação explícita do formulário.

CTAs são classificados pelo destino: WhatsApp válido, página interna, mailto ou tel. Link interno /contato/ nunca vira WhatsApp pela ausência de nome/e-mail. Link sem destino, âncora isolada, esquema indevido ou host semelhante malicioso é recusado. Marcação por número de WhatsApp é opcional e exige correspondência exata. Inventário autenticado ctas-inventariar (grafia da ability: `f3base/ctas-inventariar`) inspeciona lotes de conteúdo salvo com limites e cobertura, sem renderizar o site ao abrir ajuda.


## Confirmação e arquivos na 1.19

Confirmação por URL após aceite, mensagens fechadas e assunto com `{nome}` usam configuração por formulário. Não se dispara nova conversão pela página de obrigado. Para download/WhatsApp há referência privada temporária de continuação. Cadastro/importação/substituição por agentes e concessões que seguem o PDF novo estão em ARQUIVOS-PRIVADOS-1.19.md; campos e permissões constam de dados/abilities-*.json. A ausência de max_bytes continua sem teto do plugin.
