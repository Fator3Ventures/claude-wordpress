# Fator3 Site Core 1.22.0

Instale `base-site-core-fator3-1.22.0-instalador.zip` em WordPress novo ou atualize a partir da **1.21.0**. Não há caminho de downgrade ou migração de versões anteriores. O ZIP de fontes é para desenvolvimento.

A 1.22.0 corrige procedência de configurações complementadas, recuperação e diário do executor; melhora contatos, jornada, avisos, formulários de configuração e integração Pipedrive. A atividade opcional do CRM tem estado separado da entrega principal. País ausente/vazio passa a Brasil (+55), preservando outro país explicitamente configurado.

Leia [DOCUMENTACAO.md](DOCUMENTACAO.md), [RELEASE-1.22.md](RELEASE-1.22.md) e [VALIDACAO.md](VALIDACAO.md). A documentação acompanha o plugin em `docs/` e pode ser lida pela ability administrativa `f3base/documentacao-ler`, inclusive em recuperação. Nenhum plugin MCP/Google, tema ou implantador foi alterado.

Contrato de configuração **5.2.0**, schema de leads **6** (sem nova coluna nesta release), política MCP **1**, SDK Google `search-console-reader/1.0.0`. São versões independentes.

## Adendo 135 — revisão 2 da entrega

Token Clarity disponível em Site Core → Configurações → Medição e anúncios → Clarity. O dono cadastra o segredo diretamente, salva e usa **Testar token e coletar agora**; agentes não precisam receber a credencial. Teste preserva uma consulta no relatório, compartilhando as cotas existentes. Leia CLARITY-1.22.md. O pacote 1.22.0 revisado substitui o anterior desta entrega; novo WordPress ou atualização da 1.21.0 continuam os caminhos de instalação.
