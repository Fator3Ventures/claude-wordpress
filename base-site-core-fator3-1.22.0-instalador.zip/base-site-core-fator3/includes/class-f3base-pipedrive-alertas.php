<?php
/** Episódios de alerta por entrega e causa; confirmação de transporte é distinta de recebimento. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Alertas {
    public static function intencao(array $journal,string $estado,string $codigo): array {
        foreach($journal['avisos']??array() as $a){if(($a['codigo']??'')===$codigo&&empty($a['encerrado_em'])){return $journal;}}
        $seq=(int)($journal['aviso_sequencia']??0)+1;$journal['aviso_sequencia']=$seq;$journal['avisos'][(string)$seq]=array('id'=>wp_generate_uuid4(),'estado'=>'pendente','transicao'=>$estado,'codigo'=>$codigo,'em'=>time(),'tentativas'=>0,'proxima'=>time());return $journal;
    }
    public static function resolver(array $journal): array {foreach($journal['avisos']??array() as $k=>$a){if(empty($a['encerrado_em'])){$journal['avisos'][$k]['encerrado_em']=time();if(in_array($a['estado'],array('pendente','falhou'),true)){$journal['avisos'][$k]['estado']='resolvido';}}}return $journal;}
    public static function registrar(array $job): void {F3Base_Fila::agendar('f3base_pipedrive_alertas',time()+10);}
    public static function orientacao(string $code): string {
        if(preg_match('/credencial|permissao|conta/',$code)){return 'Confira a credencial e a conta em Integrações; depois verifique a integração.';}
        if(preg_match('/pessoa|identificador/',$code)){return 'Confira a identidade da pessoa no CRM. Para criação incerta, use a reconciliação por ID; não repita a criação.';}
        if(preg_match('/autoria|lead.*ambigu|negocio.*ambigu/',$code)){return 'Confira os leads próprios elegíveis e escolha uma referência na reconciliação administrativa.';}
        if(str_contains($code,'atividade')){return 'O núcleo do contato pode estar entregue. Confira o estado complementar e repare somente a atividade.';}
        if(preg_match('/campo|mapa|rotulo|alternativa/',$code)){return 'Atualize o catálogo e confira o campo ou alternativa indicado antes de reagendar.';}
        if(preg_match('/timeout|incerto|checkpoint/',$code)){return 'Releia as referências remotas antes de tentar novamente: a operação pode já ter ocorrido.';}
        return 'Consulte a etapa e o código no diário desta entrega antes de decidir o reenvio.';
    }
    public static function processar(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT chave,record_id,journal FROM %i WHERE (JSON_SEARCH(journal,'one','pendente',NULL,'$.avisos.*.estado') IS NOT NULL OR JSON_SEARCH(journal,'one','enviando',NULL,'$.avisos.*.estado') IS NOT NULL OR JSON_SEARCH(journal,'one','falhou',NULL,'$.avisos.*.estado') IS NOT NULL) ORDER BY atualizado_em,chave LIMIT 100",F3Base_Pipedrive_Fila::tabela()),ARRAY_A);$count=0;$next=null;
        foreach($rows as $r){$raw=$r['journal'];$j=json_decode($raw,true)?:array();$lead=F3Base_Leads_Repositorio::obter($r['record_id']);
            foreach($j['avisos']??array() as $k=>$a){
                if(!$lead||$lead['eliminacao_pendente']||$lead['lixeira']){$j['avisos'][$k]['estado']='cancelado';}
                elseif($a['estado']==='enviando'&&($a['reserva_em']??0)<time()-300){$j['avisos'][$k]['estado']='incerto';}
                else {
                    if(!empty($a['encerrado_em'])||!in_array($a['estado'],array('pendente','falhou'),true)||(int)($a['tentativas']??0)>=3){continue;}
                    if(($a['proxima']??0)>time()){$next=$next===null?$a['proxima']:min($next,$a['proxima']);continue;}
                    $test=$lead['classe_trafego']==='teste';$to=F3Base_Leads_Notificacoes::destinatarios($test?F3Base_Testes::config()['email_destinatarios']:($lead['dados']['destinatarios']??F3Base_Options::ler('f3base_contato')['email_leads']??array()));$suppressed=$test&&F3Base_Testes::politica('email','teste')==='suprimir';
                    $form=F3Base_Formularios::obter($lead['formulario']);$text='Site: '.home_url()."\nContato: ".($lead['nome']?:$lead['record_id'])."\nFormulário: ".($lead['dados']['formulario_titulo']??$form['titulo']??$lead['formulario'])."\nEstado: ".F3Base_Relatorios::rotulo($a['transicao'])."\nMotivo: ".str_replace('_',' ',$a['codigo'])."\n".self::orientacao($a['codigo'])."\n".admin_url('admin.php?page=f3base-integracoes&integracao=entregas')."\n".admin_url('admin.php?page=f3base-leads&record_id='.$lead['record_id']);
                    $j['avisos'][$k]['estado']=$suppressed?'suprimido_teste':($to?'enviando':'sem_destinatarios');$j['avisos'][$k]['reserva_em']=time();$j['avisos'][$k]['tentativas']=(int)($a['tentativas']??0)+1;$reserved=wp_json_encode($j);
                    if(1!==$wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('journal'=>$reserved),array('chave'=>$r['chave'],'journal'=>$raw))){break;}$raw=$reserved;
                    if($suppressed||!$to){continue;}
                    try{$state=wp_mail($to,($test?'[TESTE] ':'').'Pipedrive — entrega requer atenção — '.get_bloginfo('name'),$text,array('Content-Type: text/plain; charset=UTF-8'))?'processado':'falhou';}catch(Throwable $e){$state='incerto';}
                    $j['avisos'][$k]['estado']=$state;$j['avisos'][$k]['resultado_em']=time();$j['avisos'][$k]['recebimento']='nao_comprovado';
                    if($state==='falhou'&&$j['avisos'][$k]['tentativas']<3){$at=time()+300*2**($j['avisos'][$k]['tentativas']-1);$j['avisos'][$k]['proxima']=$at;$next=$next===null?$at:min($next,$at);}$count++;
                }
                $updated=wp_json_encode($j);if($raw!==$updated&&1!==$wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('journal'=>$updated),array('chave'=>$r['chave'],'journal'=>$raw))){break;}$raw=$updated;
                if($count>=10){self::registrar(array());return array('ok'=>true,'avisos'=>$count);}
            }
        }
        if($next!==null){F3Base_Fila::agendar('f3base_pipedrive_alertas',$next);}elseif(count($rows)>=100){self::registrar(array());}return array('ok'=>!$wpdb->last_error,'avisos'=>$count);
    }
    public static function conta(): void {
        $cfg=F3Base_Options::ler('f3base_pipedrive');if(empty($cfg['ativo'])||F3Base_Integracoes::pipedrive_verificado()){F3Base_Options::atualizar_estado('f3base_pipedrive_alerta_conta',static function($s){if($s&&($s['estado']??'')!=='resolvido'){$s['resolvido_em']=time();$s['estado']='resolvido';}return $s;});return;}
        global $wpdb;$lead=$wpdb->get_row($wpdb->prepare("SELECT l.record_id,l.classe_trafego FROM %i l LEFT JOIN %i q ON q.record_id=l.record_id WHERE l.lixeira=0 AND l.eliminacao_pendente=0 AND l.captura='aceito' AND JSON_UNQUOTE(JSON_EXTRACT(l.entrega,'$.pipedrive.solicitado'))='true' AND (q.chave IS NULL OR q.estado IN ('pendente','suspenso') AND q.codigo IN ('credencial_recusada','permissao_recusada','credencial_indisponivel','integracao_nao_verificada')) ORDER BY (l.classe_trafego='teste'),l.id LIMIT 1",F3Base_Leads_Repositorio::tabela(),F3Base_Pipedrive_Fila::tabela()),ARRAY_A);if(!$lead){return;}
        $rev=F3Base_Options::revisao('f3base_pipedrive').F3Base_Options::revisao('f3base_pipedrive_token');$pass=F3Base_Execucoes::atual()['run_id']??wp_generate_uuid4();$saved=F3Base_Options::atualizar_estado('f3base_pipedrive_alerta_conta',static function($s)use($lead,$rev,$pass){if(($s['revisao']??'')!==$rev||($s['estado']??'')==='resolvido'){$s=array('revisao'=>$rev,'estado'=>'observando','primeira_observacao'=>time(),'passagens'=>0,'record_id'=>$lead['record_id'],'teste'=>$lead['classe_trafego']==='teste');}if(($s['estado']??'')==='enviando'&&($s['reserva_em']??0)<time()-300){$s['estado']='incerto';$s['resultado_em']=time();$s['recebimento']='nao_comprovado';}if(($s['passagem']??'')!==$pass){$s['passagem']=$pass;$s['passagens']++;}return $s;});
        if(empty($saved['persisted'])){return;}$s=get_option('f3base_pipedrive_alerta_conta',array());$changed=max(F3Base_Options::carimbo('f3base_pipedrive'),F3Base_Options::carimbo('f3base_pipedrive_token'),(int)($s['primeira_observacao']??0));
        if(!in_array($s['estado']??'',array('observando','falhou'),true)||($s['tentativas']??0)>=3||($s['proxima']??0)>time()||($s['passagens']??0)<2||$changed>time()-300){return;}
        $test=$s['teste'];$to=F3Base_Leads_Notificacoes::destinatarios($test?F3Base_Testes::config()['email_destinatarios']:(F3Base_Options::ler('f3base_contato')['email_leads']??array()));$state=$test&&F3Base_Testes::politica('email','teste')==='suprimir'?'suprimido_teste':($to?'enviando':'sem_destinatarios');
        $claim=F3Base_Options::atualizar_estado('f3base_pipedrive_alerta_conta',static fn($x)=>($x['revisao']??'')===$rev&&in_array($x['estado']??'',array('observando','falhou'),true)?array_merge($x,array('estado'=>$state,'tentativas'=>(int)($x['tentativas']??0)+1,'reserva_em'=>time())):null);if(empty($claim['persisted'])||$state!=='enviando'){return;}
        try{$state=wp_mail($to,($test?'[TESTE] ':'').'Pipedrive — verificação pendente — '.get_bloginfo('name'),"Há contatos aguardando a verificação desta conta há mais de uma passagem. Confira Integrações.\n".admin_url('admin.php?page=f3base-integracoes'),array('Content-Type: text/plain; charset=UTF-8'))?'processado':'falhou';}catch(Throwable $e){$state='incerto';}
        F3Base_Options::atualizar_estado('f3base_pipedrive_alerta_conta',static fn($x)=>($x['revisao']??'')===$rev?array_merge($x,array('estado'=>$state,'resultado_em'=>time(),'recebimento'=>'nao_comprovado','proxima'=>time()+300*2**min(2,(int)($x['tentativas']??1)))):null);
    }
}
