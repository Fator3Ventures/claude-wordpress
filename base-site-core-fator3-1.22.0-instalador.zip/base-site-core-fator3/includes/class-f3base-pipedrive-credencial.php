<?php
/** Consulta limitada da credencial candidata; não grava estado nem orçamento local. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Credencial {
    private static array $cache=array();private static array $ultima=array();public static function ultima(): array {return self::$ultima;}public static function limpar_resultado(): void {self::$ultima=array();}
    public static function verificar(string $token,string $dominio): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao','motivo'=>'Verificar a credencial exige administração.');}
        if($token===''){return array('ok'=>true,'remota'=>false);}
        if(!preg_match('/^[a-z0-9][a-z0-9-]{0,62}\.pipedrive\.com$/D',$dominio)){return array('ok'=>false,'codigo'=>'dominio_ausente_ou_invalido','motivo'=>'Defina um domínio Pipedrive válido antes de verificar a credencial.');}
        $key=hash('sha256',$token.'|'.$dominio.'|'.F3Base_Options::revisao('f3base_pipedrive_token'));
        if(isset(self::$cache[$key])){return self::$ultima=self::$cache[$key];}
        $before=F3Base_Options::revisao('f3base_pipedrive').'|'.F3Base_Options::revisao('f3base_pipedrive_token');$r=wp_remote_get('https://'.$dominio.'/api/v1/users/me',array('timeout'=>8,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>65536,'headers'=>array('x-api-token'=>$token,'Accept'=>'application/json')));
        $http=is_wp_error($r)?0:(int)wp_remote_retrieve_response_code($r);$data=is_wp_error($r)?null:json_decode(wp_remote_retrieve_body($r),true);
        $ok=$http>=200&&$http<300&&!empty($data['success'])&&!empty($data['data']['id'])&&!empty($data['data']['company_id']);
        $result=array('ok'=>$ok,'remota'=>true,'http'=>$http,'codigo'=>$ok?'credencial_confirmada':(in_array($http,array(401,403),true)?'credencial_recusada':'credencial_nao_verificada'),'motivo'=>$ok?'Acesso à conta confirmado; confira ativação e mapeamentos.':(in_array($http,array(401,403),true)?'Credencial recusada pelo Pipedrive.':'Não verificado — não foi possível confirmar a credencial. Tente novamente; a credencial anterior foi preservada.'));
        if($ok){$s=get_option('f3base_pipedrive_estado',array());$company=(string)$data['data']['company_id'];if(($s['dominio']??'')===$dominio&&!empty($s['conta_id'])&&(string)$s['conta_id']!==$company){$result['ok']=false;$result['codigo']='conta_divergente';$result['motivo']='A credencial identifica outra conta; reconcilie os vínculos antes da troca.';}}
        $after=F3Base_Options::revisao('f3base_pipedrive').'|'.F3Base_Options::revisao('f3base_pipedrive_token');if(!hash_equals($before,$after)){$result=array('ok'=>false,'remota'=>true,'codigo'=>'conflito','motivo'=>'A configuração mudou durante a verificação. Leia novamente antes de trocar a credencial.');}return self::$ultima=self::$cache[$key]=$result;
    }
}
