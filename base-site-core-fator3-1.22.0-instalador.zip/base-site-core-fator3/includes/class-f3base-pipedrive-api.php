<?php
/** Adaptador API versionado, sem fallback para endpoints v1 descontinuados. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Api {
    private static float $inicio=0;
    private static array $prova=array();
    private static array $config=array();
    private static string $token='';
    public static function iniciar_lote(): array {
        self::$inicio=microtime(true);$c=F3Base_Options::fotografia('f3base_pipedrive');$s=F3Base_Options::fotografia_bruta('f3base_pipedrive_token');
        self::$config=$c['valor'];self::$token=$s['erro']?'':F3Base_Segredos::abrir('f3base_pipedrive_token',is_string($s['valor'])?$s['valor']:'');
        self::$prova=array('revisao'=>$c['erro']?'':$c['revisao'],'credencial_revisao'=>$s['erro']?'':$s['revisao']);return self::$prova;
    }
    public static function configuracao_lote(): array {return self::$config;}
    public static function lote_atual(): bool {return F3Base_Integracoes::revisoes_atuais(self::$prova,'f3base_pipedrive','f3base_pipedrive_token');}
    public static function permitido(string $method,string $path): bool {
        $routes=array('GET'=>array('v1/users/me','v1/users','v1/leadLabels','v1/activityTypes','v1/leads','v1/notes','v2/persons/search','v2/organizations/search','v2/leads/search','v2/deals','v2/activities','v2/dealFields','v1/personFields'), 'POST'=>array('v2/persons','v2/organizations','v2/activities','v1/leads','v1/notes'));
        return ($method==='PATCH'&&preg_match('#^v2/persons/[1-9][0-9]*$#D',$path))||(in_array($method,array('GET','DELETE'),true)&&preg_match('#^v1/leads/[a-f0-9-]{36}$#D',$path))||in_array($path,$routes[$method]??array(),true)||(in_array($method,array('GET','DELETE'),true)&&preg_match('#^(?:v1/notes|v2/activities|v2/persons)/[1-9][0-9]*$#D',$path))||($method==='GET'&&preg_match('#^v2/(?:persons|organizations)/[1-9][0-9]*$#D',$path));
    }
    public static function pedir(string $method,string $path,array $data=array()): array {
        if(!self::$inicio){self::iniciar_lote();}
        if(!self::lote_atual()){return array('ok'=>false,'codigo'=>'configuracao_ou_credencial_alterada','pausa'=>true);}
        if(in_array($method,array('POST','PATCH','DELETE'),true)&&(empty(self::$config['ativo'])||!F3Base_Integracoes::pipedrive_verificado())){return array('ok'=>false,'codigo'=>'integracao_nao_verificada','pausa'=>true);}
        $cfg=self::$config;$host=$cfg['dominio']??'';
        if(!self::permitido($method,$path)||!preg_match('/^[a-z0-9][a-z0-9-]{0,62}\.pipedrive\.com$/D',$host)){return array('ok'=>false,'codigo'=>'rota_ou_dominio_recusado','permanente'=>true);}
        $token=self::$token;if($token===''){return array('ok'=>false,'codigo'=>'credencial_indisponivel','pausa'=>true);}
        if(self::$inicio&&microtime(true)-self::$inicio>18){return array('ok'=>false,'codigo'=>'orcamento_execucao','pausa'=>true,'retry_after'=>30);}
        $cost=str_contains($path,'search')?20:($method==='GET'?20:10);$budget=max(1,(int)($cfg['orcamento_local_diario']??3000));
        $state=get_option('f3base_pipedrive_estado',array());$until=(int)($state['pausa_ate']??0);if($until>time()){return array('ok'=>false,'codigo'=>'aguarda_limite','pausa'=>true,'retry_after'=>$until-time());}
        // Local share of a company-wide budget: never represent this as the company's remaining tokens.
        $day=gmdate('Y-m-d');$reserve=F3Base_Options::atualizar_estado('f3base_pipedrive_orcamento',static function($v)use($day,$cost,$budget){if(($v['dia']??'')!==$day){$v=array('dia'=>$day,'usados'=>0);}if($v['usados']+$cost>$budget){return null;}$v['usados']+=$cost;return $v;});
        if(empty($reserve['persisted'])){return array('ok'=>false,'codigo'=>'orcamento_local_esgotado','pausa'=>true,'retry_after'=>max(300,strtotime('tomorrow UTC')-time()+300));}
        // Conservative per-site fixed windows, below Lite and Search burst ceilings.
        if(!F3Base_Leads_Repositorio::quota(hash('sha256','pipedrive|'.$host.'|'.floor(time()/2)),str_contains($path,'search')?5:10,time()+4)){return array('ok'=>false,'codigo'=>'janela_requisicoes','pausa'=>true,'retry_after'=>3);}
        $url='https://'.$host.'/api/'.$path;if($method==='GET'&&$data){$url.='?'.http_build_query($data,'','&',PHP_QUERY_RFC3986);}
        $args=array('method'=>$method,'timeout'=>min(8,self::$inicio?max(1,(int)(20-(microtime(true)-self::$inicio))):8),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1048576,'headers'=>array('x-api-token'=>$token,'Accept'=>'application/json','Content-Type'=>'application/json'));
        if(in_array($method,array('POST','PATCH','DELETE'),true)){$args['body']=wp_json_encode($data);}
        $r=wp_remote_request($url,$args);unset($token,$args);
        if(is_wp_error($r)){return array('ok'=>false,'codigo'=>'transporte_sem_confirmacao','incerto'=>in_array($method,array('POST','PATCH','DELETE'),true),'temporario'=>true);}
        $http=wp_remote_retrieve_response_code($r);$json=json_decode(wp_remote_retrieve_body($r),true,512,JSON_BIGINT_AS_STRING);$retry=(string)wp_remote_retrieve_header($r,'retry-after');$after=ctype_digit($retry)?(int)$retry:max(0,(int)strtotime($retry)-time());
        $left=wp_remote_retrieve_header($r,'x-ratelimit-remaining');$reset=wp_remote_retrieve_header($r,'x-ratelimit-reset');
        if($http===429||($left!==''&&(int)$left===0)){$pause=max(3,$after,is_numeric($reset)?min(86400,(int)$reset>time()?(int)$reset-time():(int)$reset):0);F3Base_Options::atualizar_estado('f3base_pipedrive_estado',static function($v)use($pause){$v['pausa_ate']=time()+$pause;return $v;});}
        if($http>=200&&$http<300&&!empty($json['success'])){if($method==='POST'&&empty($json['data']['id'])){return array('ok'=>false,'codigo'=>'resposta_sem_identificador','incerto'=>true); }return array('ok'=>true,'http'=>$http,'data'=>$json['data']??array(),'additional_data'=>$json['additional_data']??array());}
        if(in_array($http,array(401,403),true)){F3Base_Options::atualizar_estado('f3base_pipedrive_estado',static function($v){if(!self::lote_atual()){return null;}$v['estado']='pendente';$v['codigo']='credencial_ou_permissao_recusada';return $v;});}
        $safe=array('metodo'=>$method,'rota'=>$path,'campo'=>null,'codigo_provedor'=>null,'correlacao'=>null);foreach(array('error_code'=>'codigo_provedor','field'=>'campo') as $k=>$dest){$v=$json[$k]??null;if(is_scalar($v)&&preg_match('/^[A-Za-z0-9_.:-]{1,80}$/D',(string)$v)){$safe[$dest]=(string)$v;}}$corr=wp_remote_retrieve_header($r,'x-correlation-id');if(is_string($corr)&&preg_match('/^[A-Za-z0-9-]{1,80}$/D',$corr)){$safe['correlacao']=$corr;}
        return $safe+array('ok'=>false,'http'=>$http,'codigo'=>in_array($http,array(404,410),true)?'api_ou_referencia_alterada':($http===401?'credencial_recusada':($http===403?'permissao_recusada':($http===429?'limite_api':'resposta_recusada'))),'pausa'=>in_array($http,array(401,403,404,410,429),true),'retry_after'=>max(3,$after),'temporario'=>$http>=500||$http===429,'incerto'=>in_array($method,array('POST','PATCH','DELETE'),true)&&$http>=500,'permanente'=>$http>=400&&$http<500&&!in_array($http,array(429),true));
    }
    /** Paginação completa até orçamento declarado; nunca toma decisão com lista parcial. */
    public static function listar(string $path,array $q=array()): array {
        $rows=array();$seen=array();for($n=0;$n<20;++$n){$r=self::pedir('GET',$path,$q+array('limit'=>100));if(empty($r['ok'])){return $r;}$data=$r['data'];$part=isset($data['items'])?$data['items']:$data;
            if(!is_array($part)){return array('ok'=>false,'codigo'=>'contrato_lista_invalido','pausa'=>true);}$rows=array_merge($rows,$part);$a=$r['additional_data'];$cursor=$a['next_cursor']??null;$pagination=$a['pagination']??array();
            if($cursor){if(isset($seen[$cursor])){break;}$seen[$cursor]=true;$q['cursor']=$cursor;}
            elseif(!empty($pagination['more_items_in_collection'])){$q['start']=$pagination['next_start']??(($q['start']??0)+100);}
            else{return array('ok'=>true,'data'=>$rows);}
        }return array('ok'=>false,'codigo'=>'paginacao_excede_orcamento','pausa'=>true);
    }
    public static function linkedin(string $v): string {
        $v=trim($v);if($v===''){return '';}if(!preg_match('~^[a-z][a-z0-9+.-]*://~i',$v)){$v='https://'.$v;}$p=wp_parse_url($v);if(!is_array($p)||isset($p['user'])||isset($p['pass'])||isset($p['port'])||!in_array(strtolower($p['scheme']??''),array('http','https'),true)||!preg_match('/^(?:www\.|m\.|[a-z]{2}\.)?linkedin\.com$/D',strtolower($p['host']??''))||!preg_match('~^/in/([\p{L}\p{N}%_-]+)/?$~iu',$p['path']??'',$m)){return '';}$slug=rawurldecode($m[1]);if(!preg_match('/^[\p{L}\p{N}_-]+$/uD',$slug)){return '';}return 'https://www.linkedin.com/in/'.rawurlencode(mb_strtolower($slug));
    }
    public static function telefone(string $v,?string $pais=null): string {
        $v=preg_replace('/[ ().-]/','',trim($v));if(preg_match('/^\+[1-9][0-9]{6,14}$/D',$v)){return $v;}
        $pais=$pais??(self::$config['pais_telefone']??F3Base_Options::ler('f3base_pipedrive')['pais_telefone']??'BR');
        if($pais==='BR'&&preg_match('/^[1-9][0-9]{9,10}$/D',$v)){return '+55'.$v;}
        if($pais==='PT'&&preg_match('/^[2-9][0-9]{8}$/D',$v)){return '+351'.$v;}
        if(in_array($pais,array('US','CA'),true)&&preg_match('/^[2-9][0-9]{9}$/D',$v)){return '+1'.$v;}
        return '';
    }
    public static function identificadores(array $lead): array {
        $email=strtolower(trim($lead['email']??''));return array('email'=>is_email($email)?$email:'','phone'=>self::telefone((string)($lead['dados']['telefone']??'')),'linkedin'=>self::linkedin((string)($lead['dados']['linkedin']??'')));
    }
    private static function possui(array $p,string $role,string $value,string $key=''): bool {
        if($role==='linkedin'){return self::linkedin((string)($p['custom_fields'][$key]??$p[$key]??''))===$value;}
        foreach($p[$role==='email'?'emails':'phones']??array() as $v){$x=is_array($v)?($v['value']??''):$v;$x=$role==='email'?strtolower(trim($x)):self::telefone((string)$x);if($x===$value){return true;}}return false;
    }
    /** Confirma a referência relida sem depender da indexação da pesquisa. */
    public static function identidade_confirmada(array $p,array $lead,bool $criada=false): bool {
        $norm=self::identificadores($lead);$key=self::$config['mapa_pessoa']['linkedin']??'';$matches=0;$total=0;
        foreach($norm as $role=>$value){if($value===''||($role==='linkedin'&&$key==='')){continue;}$total++;if(self::possui($p,$role,$value,$key)){$matches++;}}
        if($total){return $criada?$matches===$total:$matches>0;}
        return $criada&&mb_strtolower(trim((string)($p['name']??'')))===mb_strtolower(trim((string)($lead['nome']??'')))&&trim((string)($lead['nome']??''))!=='';
    }
    public static function buscar_pessoa(array $lead): array {
        $ids=array();$norm=self::identificadores($lead);$key=self::$config['mapa_pessoa']['linkedin']??'';
        foreach($norm as $role=>$term){if($term===''||($role==='linkedin'&&$key==='')){continue;}$search=$role==='phone'?substr(preg_replace('/\D/','',$term),-8):($role==='linkedin'?rawurldecode(basename($term)):$term);$r=self::listar('v2/persons/search',array('term'=>$search,'fields'=>$role==='linkedin'?'custom_fields':$role,'exact_match'=>$role==='email'?'true':'false'));if(empty($r['ok'])){return $r;}
            foreach($r['data'] as $item){$item=$item['item']??$item;$id=(int)($item['id']??0);if(!$id){continue;}$one=self::pedir('GET','v2/persons/'.$id);if(empty($one['ok'])){return $one;}if(self::possui($one['data'],$role,$term,$key)){$ids[$id]=$one['data'];}}
        }
        if(count($ids)>1){return array('ok'=>false,'codigo'=>'identificadores_em_pessoas_distintas','revisao'=>true);}return array('ok'=>true,'pessoa'=>$ids?reset($ids):null,'identificadores'=>$norm);
    }
    /** Completa ausências. Releitura evita substituir valores observados; API não oferece CAS distribuído. */
    public static function enriquecer(int $id,array $lead): array {
        $r=self::pedir('GET','v2/persons/'.$id);if(empty($r['ok'])){return $r;}$before=$r['data'];$patch=array();$norm=self::identificadores($lead);$key=self::$config['mapa_pessoa']['linkedin']??'';
        foreach(array('email'=>'emails','phone'=>'phones') as $role=>$field){$values=$before[$field]??array();$filled=array_filter($values,static fn($x)=>trim((string)(is_array($x)?($x['value']??''):$x))!=='');if(!$filled&&$norm[$role]!==''){$patch[$field]=array_merge($values,array(array('value'=>$norm[$role],'primary'=>true,'label'=>'work')));}}
        if($key!==''&&$norm['linkedin']!==''&&empty($before['custom_fields'][$key])&&empty($before[$key])){$patch['custom_fields']=array($key=>$norm['linkedin']);}if(!$patch){return array('ok'=>true,'codigo'=>'identificadores_preservados');}
        $again=self::pedir('GET','v2/persons/'.$id);if(empty($again['ok'])){return $again;}foreach(array('emails','phones','custom_fields','label_ids') as $field){if(($again['data'][$field]??null)!==($before[$field]??null)){return array('ok'=>false,'codigo'=>'pessoa_alterada_concorrentemente','revisao'=>true);}}
        $write=self::pedir('PATCH','v2/persons/'.$id,$patch);if(empty($write['ok'])){return $write;}$read=self::pedir('GET','v2/persons/'.$id);if(empty($read['ok'])){return $read;}foreach($norm as $role=>$v){$field=$role==='email'?'emails':($role==='phone'?'phones':'custom_fields');if(isset($patch[$field])&&$v!==''&&!self::possui($read['data'],$role,$v,$key)){return array('ok'=>false,'codigo'=>'enriquecimento_nao_confirmado','revisao'=>true);}}return array('ok'=>true);
    }
}
