<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Local execution diagnostics; no quota reset, grant, HTTP or notification on read. */
final class ExecutionBudget {
    public static function policy(): array {
        return ['kind'=>'local_execution','scope'=>'php_phase','request_limit'=>40,'window_seconds'=>25,'worker_window_seconds'=>22,'daily_quota'=>false,'replenishment'=>'next_execution','queue_priority'=>'active_schedule_latest_jobs_before_backfill'];
    }
    public static function since(array $v): ?int {
        $at=(int)($v['budget_blocked_since']??0);
        if(!$at&&($v['last_code']??null)==='budget_exhausted')$at=(int)($v['last_error']['observed_at']??0);
        return $at>0?$at:null;
    }
    public static function failure(array &$v,Fault $e): void {
        if($e->reason==='budget_exhausted'){$v['budget_blocked_since']=self::since($v)??time();$v['last_budget']=$e->details['execution_budget']??Http::snapshot();}
        else $v['budget_blocked_since']=null;
    }
    public static function progress(array &$v): void {$v['budget_blocked_since']=null;}
    public static function view(array $v): array {
        $next=!empty($v['enabled'])?max(time(),(int)$v['next_at']):null;
        if($next!==null&&!empty($v['last_job'])){try{$j=Store::get('job',$v['last_job']);if($j&&in_array($j['value']['status'],['queued','retry'],true))$next=min($next,max(time(),(int)$j['value']['next_at']));}catch(Fault $e){if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;}}
        $cron=wp_next_scheduled(Config::KEY.'_worker');if($next!==null&&$cron)$next=max($next,(int)$cron);
        $q=Store::get('quota',$v['query']['connection_id']);$until=(int)($q['value']['until']??0);$until=$until>time()?$until:null;
        return ['local'=>self::policy()+['last_observation'=>$v['last_budget']??null,'blocked_since'=>self::since($v),'next_replenishment_at'=>$next,'replenishment_estimated'=>true,'requires_worker_execution'=>true],
            'remote'=>['kind'=>'provider_quota','scope'=>'connection','connection_id'=>$v['query']['connection_id'],'blocked_until'=>$until,'provider_limit'=>null,'provider_consumption'=>null]];
    }
}
