# Diagnóstico — 0.13.0

`status` informa versão, banco, criptografia e execução do cron. `selftest` realiza verificações locais; não valida credenciais externas. `validate-connection` lê identidade do ativo, sem prometer todas as métricas. Consulte auditoria paginada para códigos sanitizados.

- not_authorized: para recusa local, confirme manage_options ou a concessão vigente do consumidor SDK; com `auth_scope=connection`, a conexão também recusou a validação remota e exige renovar a credencial ou restaurar permissões. Consulte `COLLECTION-DIAGNOSTICS.md` para o diagnóstico medido.
- revision_conflict: releia a configuração; uma revisão não é intercambiável com outra.
- token_expired/token_rejected: renove e valide a credencial; resultados históricos locais não dependem de token válido.
- rate_limited: aguarde retry_after; o agendador aplica adiamento.
- upstream_validation: confirme versão, campo, produto e aprovação do aplicativo.
- operation_uncertain: consulte e reconcilie o diário; não gere outra chave para contornar o bloqueio.
- history_changed: a visão paginada mudou; reinicie consulta/exportação com nova chave.
- response_limit: reduza campos ou limit. Não considere uma resposta truncada completa.
- cipher_unreadable: confira salts e restauração; não tente regravar sobre dado ilegível.
- storage_unavailable/persistence_unconfirmed: verifique banco, espaço e bloqueios; preserve o backup.

Cron depende de visitas se não houver agendador do servidor. Execução alternativa: `wp f3-meta run` / `wp f3-linkedin run`. Cada passo tem orçamento; grandes coletas exigem múltiplas execuções. O usuário que criou uma agenda precisa continuar autorizado.

Para Page Insights, consulte PAGE-DIAGNOSTICS.md. O número de seguidores e a leitura de page_profile não comprovam permissão read_insights nem disponibilidade histórica. `empty_or_suppressed` sem erro Graph não autoriza afirmar falta de permissão. Consulte provider_code/provider_subcode em errors ou last_error para recusas documentadas.

## Histórico — Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.

## Códigos novos da 0.7.0

- `maintenance_missing`: a manutenção horária sumiu do cron. É recriada na próxima requisição do site; se persistir, confira o cron do servidor e travas do banco.
- `queue_record_unreadable` (com `count`): há coletas cifradas que a chave atual do site não abre. Não são executadas nem apagadas; confira AUTH_KEY/AUTH_SALT do wp-config contra o backup. Os demais registros seguem normalmente.


## Correção 0.7.1 — registros ilegíveis

Jobs cujo ciphertext ou JSON interno não pode ser lido são isolados com `queue_state=unreadable`, sem reescrever payload, revisão, timestamps ou retenção. O worker trata também jobs já indexados; eles deixam de ocupar repetidamente as 20 posições executáveis. Migração e retenção usam a mesma trava e conferência de revisão/payload; registros legíveis, alterados concorrentemente ou com falha transitória de banco não recebem essa marca.

Se a agenda aponta para um job ilegível, `meta/health` e `meta/status` retornam diagnóstico degradado com `schedule_job_unreadable` e nome da agenda. Health continua sem reparo operacional e status mantém a recuperação explícita do evento. O aviso de ilegibilidade permanece no diagnóstico, fora dos avisos por e-mail. `queue_record_unreadable` informa a contagem já isolada.

A restauração dos salts ou a reparação de dados exige avaliação do administrador. Registros isolados não voltam automaticamente à fila e não são apagados pela retenção; não há reautorização ou exportação automática de conteúdo ilegível.


## Histórico — Versão 0.10.0 — Pedidos MCP Meta 16 e 17

A prévia de troca de identidade aparece junto do formulário que a pediu; a origem Renovar token abre o bloco automaticamente. A prévia recebe foco e anúncio acessível. A recusa de identidade fica junto de Salvar conexão e aponta o botão de troca. `meta/switch-identity` aceita `label` opcional (até 120 caracteres): o nome é incluído na prévia (`connection_label`), vinculado à confirmação e salvo junto da credencial e das agendas na mesma revisão/transação. Sem label, preserva o nome salvo. Editar a candidata invalida a prévia; resposta assíncrona obsoleta não a reabre.

Stories indisponíveis têm códigos próprios; revogação da conexão exige confirmação independente. Agendas e auditoria guardam código Graph, subcódigo, HTTP e instante. O aviso passa a uma tentativa por incidente e mostra a causa medida. Consulte `COLLECTION-DIAGNOSTICS.md` para códigos, efeitos, recuperação, persistência e limites. Na série 0.10, os 35 IDs de operações foram preservados e label foi acrescentado a switch-identity. Na série 0.11, somam-se seis operações, totalizando 41.


## Complemento 0.11.0 — pedidos 18/19

Consulte INSTAGRAM-MESSAGING.md para as operações administrativas de conversas, configuração, escopos, webhook e contrato local instagram-first-message/1.0.0. Core 1.56.0 registra o consumidor de ingestão; contatos exigem opt-in explícito nos dois pacotes. A eliminação coordenada é descrita em MESSAGE-PRIVACY.md; Core1.57.1 já integra esse SDK. Consulte STORY-ARCHIVE.md para novos campos/breakdowns, limites do arquivo privado, agenda horária e diagnóstico de supressão. Os 35 IDs anteriores são preservados e há seis operações aditivas (41).


## Pedido21 — coletas parciais na 0.13.0

Campos vazios/suprimidos, null e recusas específicas são diagnosticados individualmente; dados úteis dos pares permanecem. Zero é valor válido. Recusa de permissão por métrica só é localizada depois de conferir a conexão em /me; revogação global, quota ou transporte continuam interrompendo/retentando conforme seus códigos.

coverage acrescenta successful_rows acumulado, page_successful_rows e unavailable_metrics. Jobs acrescentam successful_rows, unavailable_metrics e outcome. Mantém status=partial terminal por compatibilidade quando há lacunas; outcome=failed distingue término sem nenhuma linha útil. Não houve sucesso só por gravar linhas com value=null. Agendas acrescentam last_run_status, last_successful_rows, unavailable_metrics e last_partial_at. last_success_at avança após persistência de linhas úteis (inclusive parcial); last_partial_at registra término parcial com dados. Falha global não se transforma em parcial. Health conta partial_schedules e failed_schedules separadamente entre agendas ativas; issue schedule_partial não dispara novo e-mail.

O workaround A-METASEG-2710 pode ser recomposto pelo operador da frota depois da implantação e conferência do recorte real; o pacote não altera agendas de produção automaticamente.

## Pedido 22 — tokens sem prefixo fixo

Na 0.15.0, save-connection, rotate-token e switch-identity retornam avisos estruturados em `avisos` (campo, codigo, motivo), tanto em sucesso quanto em erro. Token curto, aparência de App Secret, espaços internos e padrões incomuns de App ID/App Secret geram avisos, não recusa local. Espaços ASCII externos são aparados com aviso. Só vazio indispensável, mais de 16384 bytes e caracteres de controle impedem a conferência local. Campo de segredo vazio preserva o valor salvo; limpeza é explícita. A Meta confere app/identidade/escopos/ativos antes de gravar. CAS, geração monotônica, confirmação de troca e preservação após recusa permanecem.

## Monitoramento no Core 1.61.1

O consumidor de atividades e qualidade já está registrado no Core 1.61.1. Leia CORE-MONITORING.md antes de configurar, conceder leitura ou habilitar avisos. A configuração do consumidor e a concessão no Meta são separadas; mudança da configuração exige nova conferência da concessão. Atualizar os pacotes não autoriza ativos ou notificações.

## Pedido 25 — orçamento local na 0.17.0

`budget_exhausted` indica limite de chamadas/tempo da execução PHP. Não existe quota diária local por conexão ou agenda. Leia EXECUTION-BUDGET.md para consumo, prazo, próxima execução estimada, prioridade de agendas, quota remota separada e incidente após 24 horas. `meta/health` e `meta/list-schedules` expõem esses dados sem chamar a Meta nem enviar e-mail.
