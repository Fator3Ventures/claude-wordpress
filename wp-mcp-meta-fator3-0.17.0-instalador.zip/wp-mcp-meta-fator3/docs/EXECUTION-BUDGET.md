# Orçamento de execução — Meta 0.17.0 — Pedido 25

`budget_exhausted` é um limite local de segurança por fase da execução PHP, compartilhado por chamadas dentro dessa fase. Não é quota diária por conexão, conta ou agenda. Não é orçamento financeiro de anúncio. Não se repõe à meia-noite. Quotas da Meta são independentes e aparecem como `rate_limited`.

## Limites, consumo e reposição

| Fase | Chamadas HTTP máximas | Janela |
| --- | ---: | --- |
| Operação pública | 40 | 25 segundos |
| Despacho das agendas | 40, compartilhadas entre agendas do passe | 25 segundos, limitada pelo prazo do worker |
| Página de uma coleta | 40, renovadas antes da página | 25 segundos, limitada pelo prazo do worker |
| Passe do worker | até 20 jobs, agendas prioritárias primeiro | 22 segundos; não inicia job depois de 19 segundos |

As chamadas contam quando chegam ao transporte HTTP, inclusive respostas com erro; uma recusa local por quota remota não consome chamada. Há margem de dois segundos antes do prazo para chamadas normais e três para miniaturas. O timeout HTTP é limitado pelo tempo restante. Diagnósticos de tempo são observações, não um cronômetro atual nem garantia de execução no segundo estimado. Operações internas isoladas sem alocação explícita continuam com a proteção padrão de 15 chamadas/25 segundos.

A 0.16.0 podia despachar agendas Ads/dataset com estado estático de uma fase anterior, já esgotado ou vencido, antes de consultar o fuso da conta. A 0.17.0 aloca orçamento novo antes desse despacho. Cada página também recebe alocação própria, respeitando o prazo do passe. Pausar backfills não renova um orçamento PHP herdado. Não há limpeza de contador diário ou opção de zerar quota via banco.

`meta/health.data.execution_budget_policy` descreve a política e `budgets[]` traz o estado por agenda habilitada. `meta/list-schedules.data[].budget` inclui também agendas desabilitadas. `local.last_observation` contém `scope`, `request_limit`, `requests_used`, `requests_remaining`, `started_at`, `deadline_at`, `seconds_remaining`, `observed_at` e `exhausted_by` (`requests`, `time`, `not_initialized` ou null). O diagnóstico também fica em `last_error.execution_budget` quando há falha local. Valores ausentes em registros legados são null; não se inventa consumo histórico.

`local.blocked_since` é a primeira falha local persistente observada. Em registro legado, usa-se `last_error.observed_at` quando o último código ainda é budget_exhausted; a data exata original pode ser anterior. Sucesso de despacho preserva esse relógio até progresso da coleta. Página persistida com sucesso ou erro de outra natureza encerra esse bloqueio específico. Alterar a seleção de uma agenda reinicia seus diagnósticos; salvar a mesma seleção os preserva.

`local.next_replenishment_at` é o próximo instante elegível estimado, combinando agenda/job recuperável e evento do worker; não há renovação automática sem execução. `replenishment_estimated=true` e `requires_worker_execution=true` tornam essa limitação explícita. Em agenda desabilitada o valor é null. `remote.blocked_until` mostra o bloqueio Retry-After por conexão; `provider_limit` e `provider_consumption` são null porque o plugin não mede um saldo completo da plataforma. Renovar orçamento local nunca apaga a quota remota.

## Prioridade e recuperação

As últimas coletas vinculadas a agendas habilitadas entram antes dos retroativos, mesmo quando há mais de 20 backfills antigos. Só entram jobs `queued`/`retry` já elegíveis. O espaço e tempo restantes continuam disponíveis aos retroativos. A seleção é limitada a 100 agendas e 20 jobs por passe, preservando locks, checkpoint, autorização, idempotência, fila indexada e retenção. Jobs pausados, cancelados ou completos não são retomados automaticamente. Em carga contínua de agendas, o progresso retroativo depende da capacidade restante; não há promessa de prazo de conclusão.

Falhas locais de orçamento aguardam cinco minutos e permanecem recuperáveis mesmo após seis tentativas. Outros erros mantêm suas regras anteriores. O histórico e os resultados já persistidos são reaproveitados. Agendas também aguardam cinco minutos após falha no despacho.

## Incidente após 24 horas

Bloqueio local de agenda habilitada estritamente superior a 86.400 segundos aparece como `schedule_budget_exhausted` em `meta/health.data.issues`. Inclui conexão, agenda, duração, último erro, orçamento e ação recomendada. O mecanismo operacional existente tenta enviar uma mensagem ao `admin_email`, com recibo persistente antes do envio e deduplicação enquanto o incidente está ativo. `wp_mail` aceito não prova entrega na caixa de entrada. Health e list-schedules são leituras: não coletam dados, não enviam e-mail e não renovam orçamento. O worker executa a avaliação e a tentativa de notificação. Recuperação resolve o incidente; recorrência posterior pode gerar nova tentativa.

## Verificação operacional

1. Instale a versão e confira health, worker e orçamento das agendas.
2. Preserve pausas deliberadas. Para retomar um backfill, use o controle de coleta com revisão atual.
3. Com três agendas diárias habilitadas e backfills elegíveis, confira `last_job`, `last_success_at` e a seleção de ontem no fuso da conta.
4. Consulte o histórico diário e a leitura autorizada do Core. A versão não cria linhas artificiais para datas ainda não coletadas.
5. Havendo `rate_limited`, aguarde a janela remota. Havendo `budget_exhausted` persistente, examine o último consumo, prazo e funcionamento do worker.

A entrega foi preparada para testes sintéticos isolados. Instalação e aceite em contas reais da frota devem ser registrados separadamente, com a data de ontem efetivamente disponível; resultados de laboratório não provam coleta real da Meta.
