# Meta Ads somente leitura — 0.13.0

Pedido MCP Meta 20 inclui expressamente este domínio, anteriormente fora do escopo. Não há criação, edição, publicação, pausa ou gasto de anúncios. Pixel/CAPI, Lead Ads comercial, associação de contatos/parceiros e gestão remota de campanhas continuam fora deste leitor.

## Configuração e consulta

Em Conexão, conferir token com ads_read; em Ativos, descobrir e selecionar explicitamente contas de anúncios. IDs são strings numéricas sem prefixo act_; o leitor aplica o prefixo somente no GET Graph. Descoberta não concede acesso. Token deve estar validado na geração atual. Sem ativo há asset_access_denied; sem escopo comprovado, ads_read_required. Não expor credenciais em saída, histórico ou SDK.

meta/query e create-job aceitam channel=ads, report=ads_insights, connection_id, account_id, date_from/date_to (obrigatórias, até ontem no fuso IANA da conta), ads_level=account|campaign|adset|ad (padrão campaign) e limit=1–100. Omitir fields ou enviar []; a coleta preserva o conjunto completo disponível. Não aceita filtros orgânicos/breakdowns/intervalo. Calendário diário com time_increment=1; cada página consulta um dia. No nível ad há no máximo 10 linhas/página para reservar as chamadas de criativos. Cursor firmado preserva consulta, identidade, autorização, geração de credencial e limites.

Campos: spend, account_currency, impressions, reach, frequency, clicks, inline_link_clicks; account/campaign/adset/ad IDs e nomes conforme o nível; actions, cost_per_action_type, results e cost_per_result tipados; creative_id/name quando nível ad e disponíveis; leads_native/website. IDs e valores monetários/contagens conservam strings; não usar float para somar moeda no consumidor. Datas e fuso originais são preservados. Alcance/frequência não devem ser somados entre entidades/dias. Criativo e nomes são os observados na coleta, não versões históricas reconstruídas. Níveis acima de ad não possuem um único criativo.

Atribuição explícita e fixa: use_unified_attribution_setting=true, action_report_time=mixed. Results/cost_per_result conservam objetos tipados do fornecedor, sem escolher um resultado principal artificialmente. Se esses campos forem recusados, a página básica é lida e os opcionais são isolados, com correspondência de entidades/continuação antes de anexar dados. Campo ausente fica null e diagnosticado, sem apagar spend/impressions/clicks já disponíveis. Dados de outros escopos são recusados. Leads nativos selecionam actions.onsite_conversion.lead_grouped; leads de site, actions.offsite_conversion.fb_pixel_lead. O agregado lead é preservado separadamente em actions, nunca somado aos subtipos sobrepostos. Ausência permanece desconhecida, não zero.

## Acervo, backfill, revisita e exportação

create-backfill usa início explícito, término congelado e jobs retomáveis (padrão 5000 páginas; máximo 10000). A consulta avança do dia mais recente ao mais antigo, preservando o que já foi coletado se um dia antigo for recusado. O plugin não inventa horizonte universal: a disponibilidade depende do ativo, métrica e versão. Recusa é registrada com códigos medidos; não prova por si só que se atingiu um limite histórico. Um período vazio não comprova cobertura integral. Dividir grandes cargas em intervalos e conferir cobertura, errors, plan_complete e last_code; retomar depois de tratar a causa. Nenhum total acumulado vira série diária artificial.

Agendas usam por padrão 1440 minutos e revisitam 7 dias completos; lookback_days aceita 1–30. O período de cada execução é calculado no fuso da conta (inclusive mudanças de horário local); next_at é Unix UTC. Crie uma agenda por conta/nível desejado. Revisões tardias além do lookback precisam de novo backfill explícito.

Histórico cifrado e sem prazo para Ads. Identidade de linha inclui conexão/conta/nível/entidade/dia/atribuição/moeda/fuso; uma revisita substitui a observação corrente dessa identidade, sem somar investimento duas vezes. Cada resultado original permanece no diário conforme a política de resultados; o acervo Ads não expira. last_available_fields conserva o último valor não nulo de cada campo com sua data, separadamente da observação atual: não tratar esse valor antigo como confirmado na consulta atual. Última observação integral bem-sucedida permanece separada. Dia sem linhas não cria zeros nem elimina silenciosamente linhas previamente observadas; comparar last_seen e cobertura antes de concluir ausência atual.

history-query/export aceitam ads_level (padrão campaign), datas e canal ads. Exporte CSV ou JSON pelas operações history-export, history-export-step/read; arquivos privados em partes, sem URL pública. Exportação por job continua disponível, com allow_partial explícito quando necessário. Cursores, autorização, limites por resposta e proteção de fórmula CSV permanecem.

## Aceite externo

Fixtures validam armazenamento/contratos; não homologam a Meta. Conferir com Ads Manager os mesmos 30 dias completos, nível campanha, fuso, moeda, atribuição e instante nas contas 1803436740776667 (korvena.com.br) e 2098846280719695 (ctooffice.com.br), conforme Pedido20. Comparar spend, impressions e clicks por campaign_id, paginar tudo e registrar diferenças, sem somar alcance. Essa comparação exige implantação autorizada na frota e credenciais/ativos do operador; não é substituída por Site-Teste sem adaccount.

Referências primárias consultadas em 28/10/2026: SDK oficial Meta, https://github.com/facebook/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adsinsights.py e ad.py; parâmetros do Insights em https://www.postman.com/meta/facebook-marketing-api/request/5wdl62t/attributionsetting. As páginas developers.facebook.com limitaram a leitura automatizada (429); não se afirma validação real de todos os campos na v24.0. O catálogo marca candidatos sujeitos à validação remota.

## Pedido 25 — orçamento local na 0.17.0

`budget_exhausted` indica limite de chamadas/tempo da execução PHP. Não existe quota diária local por conexão ou agenda. Leia EXECUTION-BUDGET.md para consumo, prazo, próxima execução estimada, prioridade de agendas, quota remota separada e incidente após 24 horas. `meta/health` e `meta/list-schedules` expõem esses dados sem chamar a Meta nem enviar e-mail.
