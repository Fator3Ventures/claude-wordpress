# Fator3 Site Core 1.87.3

Versão 1.87.3. Aplicabilidade, histórico de e-mail, memória dos relatórios e recorrência das filas. Consulte docs/RELEASE-1.87.3.md.

Instalação nova ou atualização da 1.86.0, da 1.87.0, da 1.87.1 ou da 1.87.2. WordPress ≥ 7.1.4 e PHP ≥ 8.3. Contrato 8.41.0.

Índice de operação em docs/DOCUMENTACAO.md.
