# Fonte — Fator3 MCP LinkedIn 0.8.1

Revisão independente da 0.8.0, comparada com a 0.7.0. Patch expressamente solicitado pelo dono para os achados R1–R4. Atualização direta validada de 0.8.0 e de 0.7.0. Este fonte não é instalável; instale somente `wp-mcp-linkedin-fator3-0.8.1-instalador.zip`.

## Estrutura e autoria das evidências

- `plugin/wp-mcp-linkedin-fator3/`: 58 arquivos idênticos ao instalador testado, incluindo 28 PHP e 24 documentos.
- `build/common/` e `build/linkedin/`: código canônico. Query/Queue foram corrigidos neste build; não são mais declarados idênticos aos do Meta. A versão está em `build/build.py`.
- `build/docs/linkedin/`: documentação instalada e notas do patch. Schemas gerados pelo build permanecem iguais à 0.8.0.
- `tests/native/review081.php`: sete verificações dos quatro achados e seus limites (trava, payload e resultado filho). `suite.php` inclui regressões anteriores e preservação na atualização. `seed.php` arma a agenda sintética na base 0.8.0 como faz a API pública; o ensaio não exige reparo de cron num bootstrap já estabilizado.
- `evidence/review081/`: provas próprias desta rodada; `base080-clean6` contém a reprodução de quatro achados na 0.8.0 exata, antes de acrescentar três casos de proteção. `cert081-*` contém apenas o instalador final 0.8.1. O mínimo tem 132 verificações aprovadas e duas não aplicáveis por ausência da Abilities API no WP 6.4.
- `history/received-0.8.0/`: evidências e relatório recebidos; não são execução própria da revisão. Demais arquivos de history/planning anteriores conservam sua origem histórica.
- `tools/lab.py`: laboratório WordPress com MySQL descartável configurado por manifesto. `tools/lab-review081.example.json` é exemplo portátil; ajustar caminhos, PHP e hashes ao ambiente, mantendo os hashes dos pacotes de entrada. O runner confere os hashes antes de extrair.
- `tools/site-qa-081.php`: auxiliar sintético usado e removido do Site-Teste. Recusa configuração LinkedIn pré-existente, bloqueia rede e limpa apenas recursos próprios. Nunca faz parte do instalador.
- `impacts/`: dois impactos recebidos atualizados e alerta técnico ao Meta. `inputs/0.8.1/`: originais recebidos e normas aplicáveis.

## Reprodução

```sh
F3_SOCIAL_PHP=/usr/bin/php python3 build/build.py
F3_LAB_DB_PASSWORD=... python3 tools/lab.py --manifest tools/lab-review081.example.json --workdir /tmp/li081-clean --order linkedin-only
F3_LAB_DB_PASSWORD=... python3 tools/lab.py --manifest tools/lab-review081.example.json --workdir /tmp/li081-integrated --order linkedin-integrated
F3_LAB_DB_PASSWORD=... python3 tools/lab.py --manifest tools/lab-review081.example.json --workdir /tmp/li081-upgrade --order linkedin-integrated --origin upgrade
```

O manifesto de atualização aponta para a 0.8.0. Para o salto da 0.7.0, alterar somente baseline_linkedin.path/sha256 para os valores aceitos no relatório. Para o mínimo, usar --wordpress wordpress_minimum --php php81 --tests suite.php. A prova do PHP 8.1 nesta revisão usou pacotes cujos bytes conferem com `tools/php81-lock.json`; a verificação GPG do índice documentada pela sessão anterior não foi repetida.

Ambiente próprio: WordPress 7.1.3 e 6.4, PHP 8.3.6 e 8.1.2, MySQL 8.0.46; Site-Teste WP 7.1.3/PHP 8.3.36. Chamadas ao LinkedIn e e-mail interceptados. Acompanhantes próprios: Core 1.48.0, MCP 0.28.0, Google 0.17.0 e Meta 0.6.0. Versões posteriores citadas no relatório recebido não foram reexecutadas.

## Fechamento

`tools/package-source.py` confere o runtime contra o instalador, recusa ZIPs aninhados e sobrescrita. Relatório interno é anterior ao fechamento; tamanho/hash do próprio fonte ficam no relatório externo. O instalador final é determinístico e seu hash foi verificado em todos os cenários certificados e na atualização remota.
