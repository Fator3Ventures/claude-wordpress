<?php
declare(strict_types=1);
defined('ABSPATH') || exit;

/** Public local-PHP boundary. Neither function grants send authority or exposes secrets. */
function f3_linkedin_service_audit_descriptor(): array {
    return \Fator3\LinkedIn\ServiceAudit::descriptor();
}
function f3_linkedin_introspect_service_grant(array $identity): array {
    return \Fator3\LinkedIn\ServiceAudit::introspect($identity);
}
