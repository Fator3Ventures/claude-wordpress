<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class CentralAudit {
    public static function boot(): void {
        add_action('f3_mcp_register_mutation_audit', static function($contract): void {
            $api='\\Fator3\\McpFiles\\MutationAudit';
            if($contract==='mutation-audit/1.0.0'&&is_callable([$api,'register']))
                $api::register(['contract'=>$contract,'provider'=>Config::SLUG,'reader'=>'linkedin/get-write-operation','event_contract'=>'linkedin-mutation/1.0.0']);
        });
    }
    public static function status(): string {
        $api='\\Fator3\\McpFiles\\MutationAudit';
        if(!is_callable([$api,'status']))return 'unavailable';
        try {$s=$api::status();foreach($s['providers']??[] as $p)if(($p['provider']??'')===Config::SLUG&&($p['contract']??'')==='mutation-audit/1.0.0'&&($p['reader']??'')==='linkedin/get-write-operation')return 'registered';}
        catch(\Throwable $e){return 'unavailable';}
        return 'not_registered';
    }
}
