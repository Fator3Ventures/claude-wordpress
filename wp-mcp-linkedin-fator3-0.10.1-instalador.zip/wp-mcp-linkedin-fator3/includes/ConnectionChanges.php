<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Candidate validation and the atomic boundary for connections and their schedules. */
final class ConnectionChanges {
    public const READ_SCOPES=['r_ads','r_ads_reporting','r_organization_admin','r_organization_social'];
    public const WRITE_SCOPES=['rw_ads','w_organization_social','rw_organization_admin','rw_conversions'];
    public static function formats(array $c,array $before,array $input): void {
        $changed=static fn($k)=>($c[$k]??'')!==($before[$k]??'');
        // Empty password fields retain saved values. Validate the effective tuple, including cross-field mistakes.
        if($changed('token')&&$c['token']!==''){
            if(strlen($c['token'])<100||in_array($c['token'],array_filter([$c['client_id'],$c['client_secret'],$before['client_id']??'',$before['client_secret']??'']),true))
                throw new Fault('invalid_access_token','Isto parece a Chave secreta do aplicativo (Primary Client Secret) ou o Client ID, não um token. Copie o Access Token no Token Generator.');
        }
        if($changed('client_id')&&$c['client_id']!==''){
            if(ctype_digit($c['client_id']))throw new Fault('invalid_client_id','Isto é o número do aplicativo no endereço, não o Client ID. Copie o Client ID em Auth → Application credentials.');
            if(!preg_match('/^[a-zA-Z0-9]+$/D',$c['client_id']))throw new Fault('invalid_client_id','O Client ID aceita somente letras e números, sem espaços.');
        }
        if($changed('client_secret')&&$c['client_secret']!==''&&(strlen($c['client_secret'])>=100||in_array($c['client_secret'],[$c['token'],$c['client_id']],true)))throw new Fault('invalid_client_secret','Isto parece um Access Token, não a Primary Client Secret.');
        if($changed('application_id')&&$c['application_id']!==''&&!ctype_digit($c['application_id']))throw new Fault('invalid_application_id','O número do aplicativo (App ID no endereço) aceita somente dígitos.');
        if(!empty($c['refresh_token'])&&$c['refresh_token']===$c['token'])throw new Fault('invalid_refresh_token','O Refresh Token deve ser diferente do Access Token.');
        foreach(['token','client_secret','refresh_token','client_id'] as $k)if(isset($input[$k])&&preg_match('/[\s\x00-\x20]/u',$input[$k]))throw new Fault('invalid_input','Credenciais não podem conter espaços.');
    }
    public static function verify(array $c): array {
        // The provider, not a manually entered expiration, decides whether the candidate is active.
        $candidate=$c;$candidate['enabled']=true;$candidate['expires_at']=0;
        $proof=Credentials::requireScopes($candidate,self::READ_SCOPES);
        if(($proof['client_id']??'')!==$c['client_id']||($proof['expires_at']??0)<=time())throw new Fault('verification_incomplete','O LinkedIn não confirmou o Client ID e a validade deste token. O token salvo continua em uso.');
        $proof['member']=Credentials::member($candidate,$proof['scopes']);
        $proof['write_scopes']=array_values(array_intersect(self::WRITE_SCOPES,$proof['scopes']));
        return $proof;
    }
    public static function sameIdentity(array $before,array $c,array $proof): bool {
        if($before['client_id']!==$c['client_id'])return false;
        if($before['token']===$c['token'])return true;
        $a=$before['identity']['member']['subject']??null;$b=$proof['member']['subject']??null;
        return is_string($a)&&$a!==''&&is_string($b)&&hash_equals($a,$b);
    }
    public static function rows(string $bucket,string $id): array {
        $out=[];$after='';do{$rows=Store::scan($bucket,$after,100);foreach($rows as $r){$after=$r['key'];$v=$r['value'];if(($v['connection_id']??$v['query']['connection_id']??'')===$id)$out[]=$r;}}while(count($rows)===100);return $out;
    }
    private static function fingerprint(array $i,array $before,array $rows,?array $proof): string {
        unset($i['dry_run'],$i['confirmation'],$i['reconfirm_leads'],$i['reconfirm_conversions']);
        $revisions=[];foreach($rows as $bucket=>$list)foreach($list as $r)$revisions[$bucket.':'.$r['key']]=$r['revision'];
        return hash_hmac('sha256',Util::json([$i,Credentials::binding($before),$revisions,Access::principal(),$proof['client_id']??null,$proof['member']['subject']??null,$proof['scopes']??null]),wp_salt('auth'));
    }
    public static function save(array $i,array $c,array $before,?array $old): array {
        $principal=Access::principal();self::formats($c,$before,$i);$expected=(int)$i['expected_revision'];$proof=null;
        if(!empty($i['use_pending_authorization']))$c['refresh_binding_verified']=!empty($i['refresh_binding_verified']);
        elseif(($before['refresh_token']??'')!==($c['refresh_token']??''))$c['refresh_binding_verified']=false;
        $changed=Credentials::binding($before)!==Credentials::binding($c);
        if($changed&&$c['token']!=='')$proof=self::verify($c);
        elseif($changed&&$c['enabled'])throw new Fault('application_required','Informe Access Token, Client ID e Primary Client Secret para ativar a conexão. Para preparar OAuth sem token, salve a conexão pausada.');
        $identityChange=$old&&!empty($before['token'])&&$proof&&!self::sameIdentity($before,$c,$proof);
        $rows=['schedule'=>self::rows('schedule',$c['id']),'grant'=>self::rows('grant',$c['id']),'conversion_grant'=>self::rows('conversion_grant',$c['id'])];
        $fingerprint=self::fingerprint($i,$before,$rows,$proof);
        $summary=['schedules'=>array_map(static fn($r)=>['id'=>$r['key'],'label'=>$r['value']['label'],'revision'=>$r['revision'],'enabled'=>$r['value']['enabled']],$rows['schedule']),
            'lead_grants'=>array_map(static fn($r)=>['consumer_id'=>$r['value']['consumer_id'],'enabled'=>$r['value']['enabled'],'revision'=>$r['revision']],$rows['grant']),
            'conversion_grants'=>array_map(static fn($r)=>['account_id'=>$r['value']['account_id']??null,'conversion_id'=>$r['value']['conversion_id']??null,'enabled'=>$r['value']['enabled'],'revision'=>$r['revision']],$rows['conversion_grant'])];
        if(!empty($i['dry_run']))return ['persisted'=>false,'identity_change_required'=>(bool)$identityChange,'identity'=>$proof?self::publicProof($proof,$c):($c['identity']??null),'affected'=>$summary,'confirmation'=>Util::cursor(['fingerprint'=>$fingerprint,'expires'=>time()+600]),'expires_at'=>time()+600];
        if(!empty($i['confirmation'])){$preview=Util::uncursor($i['confirmation']);if(!hash_equals($fingerprint,(string)($preview['fingerprint']??'')))throw new Fault('revision_conflict','A candidata, a identidade, as agendas ou as concessões mudaram. Simule novamente.');}
        if($identityChange){
            $name=$proof['member']['name']??('Client ID '.$c['client_id']);
            if(empty($i['confirmation']))throw new Fault('identity_change_required','O token novo é de outra identidade ('.$name.'). Para trocar, use \'Trocar identidade e regravar agendas\': o token é conferido, a seleção de ativos, formulários e concessões é mantida e as agendas são regravadas na nova revisão.',['member_verified'=>!empty($proof['member']['subject']),'simulation_required'=>true]);
            // Identity changes never also silently widen or replace the selected resources.
            foreach(['assets','forms','users','api_version','enabled'] as $k)if(($before[$k]??null)!==($c[$k]??null))throw new Fault('identity_selection_changed','Troque primeiro a identidade mantendo a seleção salva. Altere a seleção em outro salvamento.');
            if(array_filter($rows['grant'],static fn($r)=>!empty($r['value']['enabled']))&&empty($i['reconfirm_leads']))throw new Fault('grant_confirmation_required','Reconfirme as concessões do Lead Sync nesta tela.');
            foreach($rows['conversion_grant'] as &$r)if(!empty($r['value']['enabled'])){
                if(empty($i['reconfirm_conversions']))throw new Fault('grant_confirmation_required','Reconfirme a concessão da Conversions API nesta tela.');
                $r['verified_rule']=Conversions::verifyCandidate(array_replace($c,['revision'=>$expected,'expires_at'=>$proof['expires_at']]),$r['value']);
            }unset($r);
            if(array_filter($rows['grant'],static fn($r)=>!empty($r['value']['enabled']))&&!in_array('r_marketing_leadgen_automation',$proof['scopes'],true))throw new Fault('scope_missing','Para reconfirmar Lead Sync, o token precisa de r_marketing_leadgen_automation.');
        }
        $authChanged=(bool)$identityChange;
        foreach(['enabled','assets','forms','users','api_version','application_id'] as $k)if(($before[$k]??null)!==($c[$k]??null))$authChanged=true;
        $c['authorization_revision']=($before['authorization_revision']??1)+($old&&$authChanged?1:0);
        if($proof){$c['expires_at']=$proof['expires_at'];$c['identity']=self::publicProof($proof,$c);}
        elseif($changed){$c['identity']=null;$authChanged=true;$c['authorization_revision']=($before['authorization_revision']??1)+1;}
        elseif(isset($before['identity'])){$c['identity']=$before['identity'];if($c['identity']){$c['identity']['application_name']=self::appName($c);$c['expires_at']=$c['identity']['expires_at'];}}
        $eligible=array_filter($rows['schedule'],static fn($r)=>in_array($r['value']['query']['account_id'],$c['assets'][$r['value']['query']['channel']]??[],true)&&(($r['value']['connection_revision']??0)===$expected||$identityChange));
        $history=$before['connection_history']??[];
        $history[]=['at'=>time(),'by'=>get_current_user_id(),'from_revision'=>$expected,'to_revision'=>$expected+1,'identity_change'=>(bool)$identityChange,'authorization_revision'=>$c['authorization_revision'],'credential_generation'=>$c['credential_generation'],'schedules'=>array_column($eligible,'key')];
        $c['connection_history']=array_slice($history,-20);unset($c['authorization_pending']);
        Access::checkPrincipal($principal);Access::admin();
        return self::transaction(static function()use($i,$c,$before,$old,$expected,$proof,$rows,$identityChange,$authChanged){
            $saved=Store::put('connection',$c['id'],$c,$expected);
            // Each CAS belongs to the same transaction. Do not resurrect schedules paused by an operator.
            $rebased=[];foreach($rows['schedule'] as $r){$v=$r['value'];if(!in_array($v['query']['account_id'],$c['assets'][$v['query']['channel']]??[],true))continue;
                if(($v['connection_revision']??0)!==$expected&&!$identityChange)continue;
                $v['connection_revision']=$saved['revision'];$v['authorization_revision']=$c['authorization_revision'];$v['credential_generation']=$c['credential_generation'];
                if(($v['last_code']??null)==='revision_conflict')$v['last_code']=null;
                Store::put('schedule',$r['key'],$v,$r['revision'],$r['expires_at']);$rebased[]=$r['key'];
            }
            // Only current grants follow a benign edit. Explicit identity confirmation can rebind an active grant.
            foreach(['grant'=>'credential_revision','conversion_grant'=>'connection_revision'] as $bucket=>$field)foreach($rows[$bucket] as $r){$v=$r['value'];
                if(empty($v['enabled'])||($authChanged&&!$identityChange)||(!$identityChange&&($v[$field]??0)!==$expected))continue;
                if($bucket==='conversion_grant'&&!$identityChange){$v['service_revision']=$v['service_revision']??$r['revision'];$v['service_connection_revision']=$v['service_connection_revision']??$v[$field];}
                $v[$field]=$saved['revision'];
                if($identityChange){$v['updated_at']=time();if($bucket==='grant')$v['configured_by']=get_current_user_id();else{unset($v['service_revision'],$v['service_connection_revision']);$v['principal']=Access::principal();$v['rule']=$r['verified_rule'];}}
                Store::put($bucket,$r['key'],$v,$r['revision'],$r['expires_at']);
            }
            // The effective material is now the base record. An old overlay must not restore a manually changed refresh token.
            $overlay=Store::get('credential',$c['id']);if($overlay)Store::remove('credential',$c['id'],$overlay['revision']);
            if($proof)self::storeProof($c,$proof);
            if(!empty($i['use_pending_authorization'])){$pending=Store::get('credential_candidate',$c['id']);if($pending)Store::remove('credential_candidate',$c['id'],$pending['revision']);}
            return ['persisted'=>true,'connection'=>Connections::public($c+['revision'=>$saved['revision']]),'schedules_rebased'=>$rebased,'identity_changed'=>(bool)$identityChange];
        });
    }
    private static function appName(array $c): string {$parts=explode('·',$c['label'],2);return trim($parts[1]??'')?:'Nome não informado';}
    public static function publicProof(array $proof,array $c): array {return $proof+['application_name'=>self::appName($c),'application_name_source'=>'administrator_label'];}
    public static function storeProof(array $c,array $proof): void {
        $r=Store::get('token_proof',$c['id']);$binding=Credentials::binding($c);
        // A scopes-only check must not discard an already verified subject for this exact credential.
        if(!array_key_exists('member',$proof)&&$r&&hash_equals($binding,$r['value']['binding']))$proof['member']=$r['value']['member']??null;
        Store::put('token_proof',$c['id'],$proof+['binding'=>$binding],$r['revision']??0);
    }
    public static function transaction(callable $fn) {
        global $wpdb;if($wpdb->query('START TRANSACTION')===false)throw new Fault('storage_unavailable','Não foi possível iniciar o salvamento atômico.');
        try{$out=$fn();if($wpdb->query('COMMIT')===false)throw new Fault('persistence_unconfirmed','O banco não confirmou o salvamento. Releia a conexão antes de tentar novamente.');return $out;}
        catch(\Throwable $e){$wpdb->query('ROLLBACK');throw $e;}
    }
}
