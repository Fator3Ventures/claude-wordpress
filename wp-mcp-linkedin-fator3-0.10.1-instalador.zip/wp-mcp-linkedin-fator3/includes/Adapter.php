<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Adapter {
    public static function base(array $c): string {return 'https://api.linkedin.com/rest/';}
    private static function value($v): string {
        if(is_array($v)){if(array_is_list($v))return 'List('.implode(',',array_map([self::class,'value'],$v)).')';$a=[];foreach($v as $k=>$x)$a[]=rawurlencode((string)$k).':'.self::value($x);return '('.implode(',',$a).')';}
        return rawurlencode(is_bool($v)?($v?'true':'false'):(string)$v);
    }
    public static function encode(array $q): string {$a=[];foreach($q as $k=>$v)$a[]=rawurlencode((string)$k).'='.($k==='fields'?(string)$v:self::value($v));return implode('&',$a);}
    public static function allowed(string $p,string $m): bool {
        if(self::managementAllowed($p,$m))return true;
        if($m==='GET'&&preg_match('~^conversions(?:/[0-9]+)?$~D',$p))return true;
        if($m==='POST'&&$p==='conversionEvents')return true;
        if($m==='POST')return $p==='leadNotifications';if($m==='DELETE')return (bool)preg_match('~^leadNotifications/[0-9]+$~D',$p);
        return $m==='GET'&&(bool)preg_match('~^(?:adAccountUsers|organizationAcls|organizations/[0-9]+|adAccounts(?:/[0-9]+(?:/(?:adCampaignGroups|adCampaigns|creatives))?)?|posts|organizationPageStatistics|organizationalEntityShareStatistics|organizationalEntityFollowerStatistics|networkSizes/urn%3Ali%3Aorganization%3A[0-9]+|adAnalytics|leadForms(?:/[0-9]+)?|leadFormResponses(?:/[A-Za-z0-9_-]+)?|leadNotifications(?:/[0-9]+)?)$~D',$p);
    }
    private static function managementAllowed(string $p,string $m): bool {
        $ad='adAccounts/[0-9]+/(?:adCampaignGroups(?:/[0-9]+)?|adCampaigns(?:/[0-9]+)?|creatives(?:/urn%3Ali%3AsponsoredCreative%3A[0-9]+)?)';
        $post='posts(?:/urn%3Ali%3A(?:share|ugcPost)%3A[0-9]+)?';
        $media='(?:images/urn%3Ali%3Aimage%3A|videos/urn%3Ali%3Avideo%3A)[A-Za-z0-9_-]+';
        $comment='socialActions/urn%3Ali%3A(?:share|ugcPost)%3A[0-9]+/comments(?:/[0-9]+)?';
        if($m==='GET')return (bool)preg_match('~^(?:'.$ad.'|'.$post.'|'.$media.'|'.$comment.'|adTargetingEntities|adSegments)$~D',$p);
        if($m==='POST')return (bool)preg_match('~^(?:'.$ad.'|'.$post.'|'.$comment.'|images|videos)$~D',$p);
        return $m==='DELETE'&&(bool)preg_match('~^(?:adAccounts/[0-9]+/(?:adCampaignGroups/[0-9]+|adCampaigns/[0-9]+|creatives/urn%3Ali%3AsponsoredCreative%3A[0-9]+)|posts/urn%3Ali%3A(?:share|ugcPost)%3A[0-9]+)$~D',$p);
    }
    public static function reports(): array {return ['organization','posts','page_statistics','share_statistics','follower_statistics','follower_total','audience','ad_accounts','campaign_groups','campaigns','creatives','ad_analytics'];}
    public static function fields(string $report): array {
        $fields=match($report){
            'ad_analytics'=>['impressions','clicks','landingPageClicks','costInLocalCurrency','externalWebsiteConversions','conversionValueInLocalCurrency','oneClickLeads','oneClickLeadFormOpens','reactions','comments','shares','follows','totalEngagements','videoViews','videoStarts','videoCompletions','videoFirstQuartileCompletions','videoMidpointCompletions','videoThirdQuartileCompletions','approximateMemberReach','ctr','cpc','cpm','roas'],
            'organization'=>['id','localizedName','vanityName','localizedDescription','logoV2','website'],
            'posts'=>['id','author','commentary','publishedAt','createdAt','lastModifiedAt','content','visibility','lifecycleState'],
            'page_statistics'=>['organization','timeRange','totalPageStatistics','mobilePageStatistics','desktopPageStatistics'],
            'share_statistics'=>['organizationalEntity','timeRange','totalShareStatistics','share','ugcPost'],
            'follower_statistics','audience'=>['organizationalEntity','timeRange','followerGains','followerCountsByGeoCountry','followerCountsByGeo','followerCountsByIndustry','followerCountsByFunction','followerCountsBySeniority','followerCountsByStaffCountRange','followerCountsByAssociationType'],
            'follower_total'=>['firstDegreeSize'],
            'ad_accounts'=>['id','name','currency','status','reference','type'],
            'campaign_groups'=>['id','name','account','status','runSchedule','totalBudget'],
            'campaigns'=>['id','name','account','campaignGroup','status','type','objectiveType','costType','runSchedule'],
            'creatives'=>['id','campaign','account','content','intendedStatus','isServing'],
            default=>throw new Fault('unsupported','Relatório não suportado.')};
        $out=[];foreach($fields as $f)$out[]=['name'=>$f,'source_field'=>in_array($f,['ctr','cpc','cpm','roas'],true)?null:$f,'unit'=>match($f){'ctr'=>'percent','cpc','cpm','costInLocalCurrency','conversionValueInLocalCurrency'=>'account_currency','roas'=>'ratio',default=>'provider_defined'},'formula'=>match($f){'ctr'=>'clicks / impressions * 100','cpc'=>'costInLocalCurrency / clicks','cpm'=>'costInLocalCurrency / impressions * 1000','roas'=>'conversionValueInLocalCurrency / costInLocalCurrency',default=>null},'aggregation'=>in_array($f,['ctr','cpc','cpm','roas','approximateMemberReach'],true)?'native_or_recalculate':'preserve_source','availability'=>'requires_remote_validation'];return $out;
    }
    public static function accounts(array $c,array $i): array {
        $channel=$i['channel'];$offset=(int)($i['offset']??0);
        $p=$channel==='pages'?'organizationAcls':'adAccountUsers';$q=['q'=>$channel==='pages'?'roleAssignee':'authenticatedUser','start'=>$offset,'count'=>10];
        $r=Http::request($c,$p,$q)['body'];$rows=self::elements($r);$out=[];
        foreach($rows as $x){$urn=$x[$channel==='pages'?'organization':'account']??'';$pattern=$channel==='pages'?'/^urn:li:organization:([0-9]+)$/D':'/^urn:li:sponsoredAccount:([0-9]+)$/D';if(preg_match($pattern,$urn,$m))$out[]=['id'=>$m[1],'urn'=>$urn,'role'=>$x['role']??null,'state'=>$x['state']??null];}
        foreach($out as &$item){try{$detail=Http::request($c,($channel==='pages'?'organizations/':'adAccounts/').$item['id'])['body'];if((string)($detail['id']??'')!==$item['id'])throw new Fault('upstream_invalid','Identidade divergente.');$name=$detail[$channel==='pages'?'localizedName':'name']??null;$item['name']=is_string($name)?mb_substr(sanitize_text_field($name),0,180):null;$item['name_status']=$item['name']?'available':'unavailable';}catch(Fault $e){$item['name']=null;$item['name_status']='unavailable';$item['name_reason']=$e->reason;}}unset($item);
        return ['rows'=>$out,'continuation'=>self::more($r,$offset,count($rows),10)?$offset+count($rows):null,'limitation'=>'A listagem prova os papéis retornados; não comprova todos os escopos de analytics ou Lead Sync.'];
    }
    public static function validate(array $c,string $channel,string $account): array {
        $r=Http::request($c,($channel==='pages'?'organizations/':'adAccounts/').$account)['body'];
        if((string)($r['id']??'')!==$account)throw new Fault('asset_access_denied','Identidade do recurso divergente.');
        return ['account_id'=>$account,'metadata_read'=>true,'analytics_read'=>false,'lead_responses_read'=>false,'app_approval_verified'=>false,'checked_at'=>gmdate('c')];
    }
    public static function elements(array $r): array {if(!is_array($r['elements']??null))throw new Fault('upstream_invalid','Lista de elementos inválida.');return $r['elements'];}
    public static function more(array $r,int $start,int $count,int $pageSize): bool {
        $p=$r['paging']??null;if(!is_array($p))throw new Fault('upstream_invalid','Paginação ausente.');
        if(isset($p['start'])&&(int)$p['start']!==$start)throw new Fault('upstream_invalid','Posição de paginação divergente.');
        $more=isset($p['total'])?$start+$count<(int)$p['total']:$count===$pageSize;
        if($more&&$count===0)throw new Fault('upstream_invalid','Paginação sem progresso.');return $more;
    }
    public static function page(array $c,array $i,array $s): array {
        $report=$i['report'];$account=Util::numeric($i['account_id']);$channel=$i['channel'];
        if(($channel==='ads')!==in_array($report,['ad_accounts','campaign_groups','campaigns','creatives','ad_analytics'],true)||$channel==='leads')throw new Fault('unsupported','Relatório não pertence ao canal.');
        $fields=$i['fields']??[];$allowed=array_column(self::fields($report),'name');if(array_diff($fields,$allowed))throw new Fault('unsupported_field','Campo fora do catálogo.');
        $out=['rows'=>[],'next'=>null,'warnings'=>[],'errors'=>[],'origin_complete'=>null,'timezone'=>'UTC','currency'=>null,'temporal'=>'snapshot','fields'=>$fields?:$allowed];
        if($report==='ad_analytics')return self::analytics($c,$i,$s,$out);
        $org='urn:li:organization:'.$account;$offset=(int)($s['offset']??0);$limit=$i['limit']??50;$q=[];$paged=false;$nativeCursor=false;
        switch($report){
            case 'organization':$path='organizations/'.$account;break;
            case 'ad_accounts':$path='adAccounts/'.$account;break;
            case 'follower_total':$path='networkSizes/'.rawurlencode($org);$q=['edgeType'=>'COMPANY_FOLLOWED_BY_MEMBER'];break;
            case 'posts':$path='posts';$q=['q'=>'author','author'=>$org,'sortBy'=>'LAST_MODIFIED','start'=>$offset,'count'=>$limit];$paged=true;break;
            case 'page_statistics':$path='organizationPageStatistics';$q=['q'=>'organization','organization'=>$org];break;
            case 'share_statistics':$path='organizationalEntityShareStatistics';$q=['q'=>'organizationalEntity','organizationalEntity'=>$org];break;
            case 'follower_statistics':case 'audience':$path='organizationalEntityFollowerStatistics';$q=['q'=>'organizationalEntity','organizationalEntity'=>$org];break;
            default:
                $path='adAccounts/'.$account.'/'.match($report){'campaign_groups'=>'adCampaignGroups','campaigns'=>'adCampaigns',default=>'creatives'};
                $q=['q'=>$report==='creatives'?'criteria':'search','pageSize'=>$limit,'sortOrder'=>'ASCENDING'];
                if($report!=='creatives')$q['search']=['status'=>['values'=>['ACTIVE','ARCHIVED','CANCELED','DRAFT','PAUSED','PENDING_DELETION','REMOVED']]];
                if($report==='campaigns')$q['search']['status']['values'][]='COMPLETED';
                if(isset($s['page_token']))$q['pageToken']=$s['page_token'];$nativeCursor=true;
        }
        if(in_array($report,['page_statistics','share_statistics','follower_statistics'],true)){
            $d=Util::dates($i);$q['timeIntervals']=['timeGranularityType'=>'DAY','timeRange'=>['start'=>$d['date_from_ts']*1000,'end'=>($d['date_to_ts']+86400)*1000]];$out['temporal']='interval';
        }
        $r=Http::request($c,$path,$q)['body'];
        if(in_array($report,['organization','ad_accounts','follower_total'],true))$rows=[$r];else $rows=self::elements($r);
        if($nativeCursor){if(!array_key_exists('metadata',$r)||!is_array($r['metadata']))throw new Fault('upstream_invalid','Metadados de paginação ausentes.');$token=$r['metadata']['nextPageToken']??null;if($token!==null&&$token!==''){if(!is_string($token)||$token===($s['page_token']??null))throw new Fault('upstream_invalid','Cursor remoto não avançou.');$out['next']=['page_token'=>$token];}foreach($rows as $row)if(($row['account']??'')!=='urn:li:sponsoredAccount:'.$account)throw new Fault('asset_access_denied','Entidade de outra conta.');}
        if($paged&&self::more($r,$offset,count($rows),$limit))$out['next']=['offset'=>$offset+count($rows)];
        if($report==='posts'&&isset($i['date_from'],$i['date_to'])){$d=Util::dates($i);$rows=array_values(array_filter($rows,static fn($v)=>isset($v['publishedAt'])&&(int)$v['publishedAt']>=$d['date_from_ts']*1000&&(int)$v['publishedAt']<($d['date_to_ts']+86400)*1000));$out['warnings'][]='Filtro local por publishedAt; paginação da origem não é encerrada antecipadamente.';}
        if($fields)$rows=array_map(static fn($r)=>array_intersect_key($r,array_flip($fields)),$rows);
        $out['rows']=$rows;if($report==='audience')$out['warnings'][]='Demografia agregada sujeita a supressão e limitações da origem.';return $out;
    }
    private static function analytics(array $c,array $i,array $s,array $out): array {
        $d=Util::dates($i);$fields=$i['fields']??[];if(!$fields)$fields=['impressions','clicks','costInLocalCurrency'];
        $needed=[];foreach($fields as $f){$deps=match($f){'ctr'=>['clicks','impressions'],'cpc'=>['costInLocalCurrency','clicks'],'cpm'=>['costInLocalCurrency','impressions'],'roas'=>['conversionValueInLocalCurrency','costInLocalCurrency'],default=>[$f]};$needed=array_merge($needed,$deps);} $needed=array_values(array_unique($needed));
        $grain=$i['granularity']??'DAILY';$pivot=$i['pivot']??'ACCOUNT';$start=$s['date_from']??$d['date_from'];$end=$s['date_to']??($grain==='DAILY'?gmdate('Y-m-d',min(strtotime($start)+6*86400,$d['date_to_ts'])):$d['date_to']);
        $parts=static fn($x)=>['year'=>(int)substr($x,0,4),'month'=>(int)substr($x,5,2),'day'=>(int)substr($x,8,2)];
        $q=['q'=>'analytics','pivot'=>$pivot,'timeGranularity'=>$grain,'dateRange'=>['start'=>$parts($start),'end'=>$parts($end)],'accounts'=>['urn:li:sponsoredAccount:'.$i['account_id']]];
        if(!empty($i['campaign_ids']))$q['campaigns']=array_map(static fn($x)=>'urn:li:sponsoredCampaign:'.Util::numeric($x),$i['campaign_ids']);
        $rows=[];$expectedKeys=null;
        foreach(array_chunk($needed,18) as $group){$q['fields']=implode(',',array_merge($group,['dateRange','pivotValues']));$r=Http::request($c,'adAnalytics',$q)['body'];$page=self::elements($r);
            if(count($page)>=15000)throw new Fault('source_row_limit','A origem atingiu 15.000 elementos; restrinja período ou campanhas.',['complete'=>false]);
            $keys=[];foreach($page as $v){if(!isset($v['dateRange'],$v['pivotValues']))throw new Fault('upstream_invalid','Chave analítica incompleta.');$key=hash('sha256',Util::json([$v['dateRange'],$v['pivotValues']]));if(isset($keys[$key]))throw new Fault('upstream_invalid','Chave analítica duplicada.');$keys[$key]=true;$rows[$key]=array_replace($rows[$key]??[],$v);}
            ksort($keys);if($expectedKeys!==null&&$keys!==$expectedKeys)throw new Fault('upstream_changed','Partições de campos divergiram; repita a consulta.');$expectedKeys=$keys;
        }
        ksort($rows);$digest=hash('sha256',Util::json($rows));if(isset($s['digest'])&&!hash_equals($s['digest'],$digest))throw new Fault('upstream_changed','Dados remotos mudaram entre páginas locais. Reinicie o recorte.');
        $account=Http::request($c,'adAccounts/'.$i['account_id'])['body'];$out['currency']=$account['currency']??null;
        $offset=(int)($s['offset']??0);$limit=$i['limit']??50;$slice=array_slice(array_values($rows),$offset,$limit);
        foreach($slice as &$r){foreach($fields as $f){if(in_array($f,['ctr','cpc','cpm','roas'],true)){$num=match($f){'ctr'=>$r['clicks']??null,'roas'=>$r['conversionValueInLocalCurrency']??null,default=>$r['costInLocalCurrency']??null};$den=match($f){'cpc'=>$r['clicks']??null,'roas'=>$r['costInLocalCurrency']??null,default=>$r['impressions']??null};$r[$f]=is_numeric($num)&&is_numeric($den)&&(float)$den!==0.0?(float)$num/(float)$den*($f==='ctr'?100:($f==='cpm'?1000:1)):null;}}$r=array_intersect_key($r,array_flip(array_merge($fields,['dateRange','pivotValues'])));}unset($r);
        $out['rows']=$slice;$out['fields']=$fields;$out['temporal']='interval';$out['warnings'][]='Paginação local sobre recorte reconsultado e conferido por hash; adAnalytics não oferece cursor nativo.';
        if(str_starts_with($pivot,'MEMBER_'))$out['warnings'][]='Demografia aproximada/suprimida; soma de recortes não garante total de pessoas.';
        if(!$rows)$out['warnings'][]='Vazio pode representar ausência de atividade ou acesso insuficiente; não foi convertido em zero.';
        if($offset+count($slice)<count($rows))$out['next']=['date_from'=>$start,'date_to'=>$end,'offset'=>$offset+count($slice),'digest'=>$digest];
        elseif($end<$d['date_to'])$out['next']=['date_from'=>gmdate('Y-m-d',strtotime($end)+86400)];
        return $out;
    }
}
