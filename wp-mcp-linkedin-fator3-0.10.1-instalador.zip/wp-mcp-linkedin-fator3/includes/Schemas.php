<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Schemas {
    public static function obj(array $p=[],array $r=[]): array {return ['type'=>'object','properties'=>$p,'required'=>$r,'additionalProperties'=>false];}
    private static function str(int $max=128,string $pattern=''): array {$x=['type'=>'string','maxLength'=>$max];if($pattern)$x['pattern']=$pattern;return $x;}
    private static function arr(array $items,int $max=100): array {return ['type'=>'array','items'=>$items,'maxItems'=>$max,'uniqueItems'=>true];}
    public static function all(): array {
        $id=self::str(64,'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$');$num=self::str(40,'^[0-9]+$');$hash=self::str(64,'^[a-f0-9]{64}$');$cursor=self::str(50000);$bool=['type'=>'boolean'];$rev=['type'=>'integer','minimum'=>0];$offset=['type'=>'integer','minimum'=>0,'maximum'=>100000];$channel=['type'=>'string','enum'=>Config::CHANNELS];$conn=['connection_id'=>$id];$asset=$conn+['channel'=>$channel,'account_id'=>$num];
        $forms=['type'=>'object','maxProperties'=>100,'additionalProperties'=>self::arr($num)];
        $query=self::obj($asset+['report'=>['type'=>'string','enum'=>Adapter::reports()],'fields'=>self::arr(self::str(80),30),'date_from'=>self::str(10,'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'),'date_to'=>self::str(10,'^[0-9]{4}-[0-9]{2}-[0-9]{2}$'),'limit'=>['type'=>'integer','minimum'=>1,'maximum'=>100],'cursor'=>$cursor]+(Config::KEY==='f3_meta'?['media_id'=>$num,'entity_id'=>self::str(81,'^[0-9]+(_[0-9]+)?$'),'granularity'=>['type'=>'string','enum'=>['day','interval']],'iterate_media'=>$bool,'timeframe'=>['type'=>'string','enum'=>['this_month','this_week','last_14_days','last_30_days','last_90_days','prev_month','prev_week']],'breakdown'=>['type'=>'string','enum'=>['country','city','age','gender']]]:['granularity'=>['type'=>'string','enum'=>['DAILY','ALL']],'pivot'=>['type'=>'string','enum'=>['ACCOUNT','CAMPAIGN_GROUP','CAMPAIGN','CREATIVE','MEMBER_COMPANY','MEMBER_INDUSTRY','MEMBER_SENIORITY','MEMBER_JOB_TITLE','MEMBER_JOB_FUNCTION','MEMBER_COUNTRY_V2','MEMBER_REGION_V2','MEMBER_COMPANY_SIZE']],'campaign_ids'=>self::arr($num,100)]),['connection_id','channel','account_id','report']);
        $a=[];foreach(['capabilities','status','selftest','configuration-schema','contracts','list-connections','list-schedules','list-grants'] as $k)$a[$k]=self::obj();
        $a['admin-options']=self::obj(['kind'=>['type'=>'string','enum'=>['users','assets','selected','objects','forms','journal']],'connection_id'=>$id,'channel'=>$channel,'account_id'=>$num,'report'=>['type'=>'string','enum'=>Adapter::reports()],'cursor'=>$cursor,'offset'=>$offset,'search'=>self::str(100),'ids'=>self::arr(['type'=>'integer','minimum'=>1])],['kind']);
        $a['documentation']=self::obj(['document'=>self::str(100),'offset'=>['type'=>'integer','minimum'=>0,'maximum'=>16777216],'limit_bytes'=>['type'=>'integer','minimum'=>256,'maximum'=>65536],'expected_revision'=>$hash]);
        $a['list-connections']=self::obj(['offset'=>$offset]);$a['get-connection']=self::obj($conn,['connection_id']);
        $a['save-connection']=self::obj($conn+['expected_revision'=>$rev,'label'=>self::str(120),'token'=>self::str(16384),'client_secret'=>self::str(16384),'clear_token'=>$bool,'clear_client_secret'=>$bool,'client_id'=>self::str(160),'application_id'=>self::str(160),'enabled'=>$bool,'expires_at'=>['type'=>'integer','minimum'=>0],'users'=>self::arr(['type'=>'integer','minimum'=>1]),'assets'=>self::obj(array_fill_keys(Config::CHANNELS,self::arr($num))),'forms'=>$forms,'api_version'=>self::str(10),'retention_days'=>['type'=>'integer','minimum'=>1,'maximum'=>3650],'retention_mode'=>['type'=>'string','enum'=>['finite','unlimited']]],['connection_id','expected_revision']);
        $a['validate-connection']=self::obj($asset,['connection_id','channel','account_id']);
        $a['list-accounts']=self::obj($conn+['channel'=>$channel,'cursor'=>$cursor],['connection_id','channel']);
        $a['list-fields']=self::obj(['report'=>['type'=>'string','enum'=>Adapter::reports()],'api_version'=>self::str(10),'connection_id'=>$id,'channel'=>$channel],['report']);$a['query']=$query;
        $a['create-job']=self::obj(['query'=>$query,'idempotency_key'=>$id,'max_pages'=>['type'=>'integer','minimum'=>1,'maximum'=>10000]],['query','idempotency_key']);
        $a['audit']=self::obj(['offset'=>$offset,'since'=>['type'=>'integer','minimum'=>0]]);
        $a['list-jobs']=self::obj(['offset'=>$offset]);
        foreach(['job-status','run-job'] as $k)$a[$k]=self::obj(['job_id'=>$hash],['job_id']);
        $a['control-job']=self::obj(['job_id'=>$hash,'expected_revision'=>$rev,'action'=>['type'=>'string','enum'=>['pause','resume','cancel']]],['job_id','expected_revision','action']);
        $a['job-results']=self::obj(['job_id'=>$hash,'page'=>['type'=>'integer','minimum'=>0,'maximum'=>9999]],['job_id']);
        $a['save-schedule']=self::obj(['schedule_id'=>$id,'label'=>self::str(120),'next_at'=>['type'=>'integer','minimum'=>0],'expected_revision'=>$rev,'query'=>$query,'enabled'=>$bool,'interval_minutes'=>['type'=>'integer','minimum'=>60,'maximum'=>43200],'lookback_days'=>['type'=>'integer','minimum'=>1,'maximum'=>30]],['schedule_id','expected_revision','query','enabled','interval_minutes']);
        $a['export']=self::obj(['job_id'=>$hash,'format'=>['type'=>'string','enum'=>['csv','json']],'allow_partial'=>$bool,'idempotency_key'=>$id],['job_id','format','idempotency_key']);
        $a['export-read']=self::obj(['export_id'=>$hash,'offset_bytes'=>['type'=>'integer','minimum'=>0,'maximum'=>12582912],'byte_limit'=>['type'=>'integer','minimum'=>1,'maximum'=>196608]],['export_id']);
        if(Config::KEY==='f3_meta'){
            unset($a['list-grants']);
            $a['rotate-token']=self::obj($conn+['expected_revision'=>$rev,'token'=>self::str(16384),'expires_at'=>['type'=>'integer','minimum'=>0]],['connection_id','expected_revision','token']);
            $a['history-status']=self::obj();$a['history-migrate']=self::obj();
            $a['history-query']=self::obj($asset+['report'=>['type'=>'string','enum'=>Adapter::reports()],'date_from'=>self::str(10),'date_to'=>self::str(10),'limit'=>['type'=>'integer','minimum'=>1,'maximum'=>100],'cursor'=>$cursor],['connection_id','channel','account_id']);
            $a['create-backfill']=self::obj(['query'=>$query,'idempotency_key'=>$id,'max_pages'=>['type'=>'integer','minimum'=>1,'maximum'=>10000]],['query','idempotency_key']);
            $a['history-export']=self::obj(['query'=>$a['history-query'],'format'=>['type'=>'string','enum'=>['csv','json']],'idempotency_key'=>$id],['query','format','idempotency_key']);
            $a['history-export-step']=self::obj(['export_id'=>$hash],['export_id']);
            $a['history-export-read']=self::obj(['export_id'=>$hash,'part'=>['type'=>'integer','minimum'=>0,'maximum'=>10000],'offset_bytes'=>['type'=>'integer','minimum'=>0,'maximum'=>1000000],'byte_limit'=>['type'=>'integer','minimum'=>1,'maximum'=>196608]],['export_id']);
            return $a;
        }
        unset($a['save-connection']['properties']['retention_mode']);$a['save-connection']['properties']+=['use_pending_authorization'=>$bool,'dry_run'=>$bool,'confirmation'=>$cursor,'reconfirm_leads'=>$bool,'reconfirm_conversions'=>$bool,'refresh_token'=>self::str(16384),'clear_refresh_token'=>$bool,'refresh_expires_at'=>['type'=>'integer','minimum'=>0]];
        $a['list-grants']=self::obj(['offset'=>$offset]);$a['get-grant']=self::obj($conn+['consumer_id'=>$id],['connection_id','consumer_id']);
        $a['save-grant']=self::obj($conn+['consumer_id'=>$id,'expected_revision'=>$rev,'enabled'=>$bool,'permissions'=>self::arr(['type'=>'string','enum'=>['metadata','responses','verify','subscriptions']],4),'forms'=>$forms,'callback_url'=>self::str(2048)],['connection_id','consumer_id','expected_revision','enabled','permissions','forms']);
        $lead=$conn+['account_id'=>$num,'credential_revision'=>$rev,'grant_revision'=>$rev];$required=['connection_id','account_id'];
        foreach(['effective-status','check-access'] as $k)$a['lead-'.$k]=self::obj($lead,$required);
        $a['lead-list-forms']=self::obj($lead+['cursor'=>$cursor],$required);
        $a['lead-discover-forms']=self::obj($lead+['offset'=>$offset],$required);
        $a['lead-get-form']=self::obj($lead+['form_id'=>$num],array_merge($required,['form_id']));
        $a['lead-read-responses']=self::obj($lead+['form_id'=>$num,'form_version'=>$num,'from_ms'=>self::str(13,'^[0-9]{13}$'),'to_ms'=>self::str(13,'^[0-9]{13}$'),'test_only'=>$bool,'cursor'=>$cursor],array_merge($required,['form_id','form_version','from_ms','to_ms']));
        $a['lead-get-response']=self::obj($lead+['form_id'=>$num,'response_id'=>self::str(150,'^[A-Za-z0-9_-]+$')],array_merge($required,['form_id','response_id']));
        $a['lead-verify-challenge']=self::obj($lead+['challenge_code'=>self::str(4096),'application_id'=>self::str(160)],array_merge($required,['challenge_code']));
        $a['lead-verify-notification']=self::obj($lead+['raw_body'=>self::str(262144),'signature'=>self::str(64,'^[a-f0-9]{64}$')],array_merge($required,['raw_body','signature']));
        $a['lead-list-subscriptions']=self::obj($lead+['offset'=>$offset],$required);
        $a['lead-create-subscription']=self::obj($lead+['form_id'=>$num,'form_version'=>$num,'callback_url'=>self::str(2048),'idempotency_key'=>$id],array_merge($required,['form_id','form_version','callback_url','idempotency_key']));
        $a['lead-delete-subscription']=self::obj($lead+['ownership_key'=>$hash],array_merge($required,['ownership_key']));
        $a['lead-get-subscription-operation']=self::obj($lead+['ownership_key'=>$hash],array_merge($required,['ownership_key']));
        $a['lead-reconcile-subscription']=self::obj($lead+['ownership_key'=>$hash,'expected_operation_revision'=>$rev,'authorize_current_context'=>$bool],array_merge($required,['ownership_key','expected_operation_revision']));
        return $a+ManagementSchemas::all()+ConversionSchemas::all();
    }
    public static function validate(string $name,array $input): void {
        $schema=self::all()[$name]??null;if(!$schema)throw new Fault('unsupported','Operação desconhecida.');
        $r=rest_validate_value_from_schema($input,$schema,$name);if(is_wp_error($r))throw new Fault('invalid_input','Entrada não corresponde ao schema.',['schema'=>$name,'validation_code'=>$r->get_error_code()]);
        if($name==='history-query'){if(isset($input['date_from'])!==isset($input['date_to']))throw new Fault('invalid_input','Informe as duas datas.');if(isset($input['date_from']))Util::dates($input,3660);}
        if($name==='query'){
            if(isset($input['date_from'])!==isset($input['date_to']))throw new Fault('invalid_input','Informe as duas datas.');
            if(isset($input['date_from']))Util::dates($input,Config::KEY==='f3_meta'?(($input['granularity']??'interval')==='day'||!in_array($input['report'],['account_insights','page_insights'],true)?3660:30):366);
            if(in_array($input['report'],['account_insights','page_insights','page_statistics','share_statistics','follower_statistics','ad_analytics'],true)&&!isset($input['date_from']))throw new Fault('invalid_input','Este relatório exige período explícito.');
            if($input['report']==='media_insights'&&!isset($input['media_id'])&&empty($input['iterate_media']))throw new Fault('invalid_input','Informe media_id.');
            if(Config::KEY==='f3_meta'&&in_array($input['report'],['post_insights','video_insights'],true)&&empty($input['entity_id']))throw new Fault('invalid_input','Informe entity_id.');
            if(Config::KEY==='f3_meta'&&Catalog::channel($input['report'])!==$input['channel'])throw new Fault('invalid_input','Relatório de outro canal.');
            if(array_diff($input['fields']??[],array_column(Adapter::fields($input['report']),'name')))throw new Fault('unsupported_field','Campo fora do catálogo.');
        }
    }
}
