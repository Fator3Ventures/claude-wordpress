# Fator3 MCP LinkedIn 0.10.0 — pedido 13

Base 0.9.0. Validação de formatos e introspecção da candidata antes de salvar ou renovar; prova salva e nomes com origem explícita; simulação e troca guiada; reconfirmação de concessões na tela; gravação atômica de conexão/agendas/vínculos e histórico limitado. OAuth retorna candidata temporária conferida. Nova classe ConnectionChanges.

Permanecem 81 operações e schema SQL 2. save-connection recebe campos aditivos dry_run, confirmation, reconfirm_leads, reconfirm_conversions e use_pending_authorization; seu efeito remoto é leitura. Não muda contrato do Core/MCP nem instala tabelas em outros plugins. Os esquemas das outras oitenta operações permanecem iguais, exceto a enumeração opcional openid/profile em oauth-start. Quatro escopos de leitura passam a ser obrigatórios na validação de credenciais novas.

Convivência considerada: Core 1.50.0, MCP 0.29.1, Meta 0.8.0 e Google 0.19.0. Atualizar somente o instalador do LinkedIn sobre 0.9.0. Não desinstalar nem apagar registros. Consulte CREDENTIALS.md para fluxos/limites e o relatório externo para a matriz efetivamente executada.

A API não fornece nome do aplicativo por introspecção. Nome exibido é declarado; membro só é identificado quando userinfo autorizado o permite. Sem essa prova, a substituição manual exige troca guiada. Testes simulados não homologam credenciais reais nem aprovação de produtos do LinkedIn.
