# Notas — 0.8.0

Base direta 0.7.0. Melhorias por ordem do dono de 22/10/2026 (rodada conjunta dos pacotes Fator3). Nenhum identificador público alterado; 80 operações preservadas e uma nova.

- M1 — Worker de coletas com fila indexada (schema 2), passagem sob trava, rearme em `finally`, recuperação na manutenção e no bootstrap, registro ilegível isolado e diagnóstico somente leitura em `linkedin/status`. Ver WORKER.md.
- M2 — O hook `f3_linkedin_register_consumers` passa de `plugins_loaded` (20) para `init` (1): continua antes do WP-Cron (`init` 10), da REST e do painel, e deixa de forçar o carregamento de traduções do Site Core antes de `init` (aviso `_load_textdomain_just_in_time` do domínio f3base em toda requisição com o Core 1.47/1.48).
- M3 — Manutenção horária ausente é recriada na requisição seguinte.
- M4 — Nova `linkedin/diagnose-conversions`: lista local de requisitos do envio de conversões pelo servidor (concessão, conexão, revisão, conta, regra com fonte Conversions API, regra ativa, escopos, dono da concessão, regra de servidor do Site Core quando informada, validade do token, prova de escopos e registro central), com ação para cada falta. Sem HTTP. Como toda operação despachada (exceto `documentation` e `get-service-write-operation`), grava uma linha no registro de auditoria local (`linkedin/audit`, retenção de 30 dias) e mantém `f3_linkedin_audit_health`; não altera concessão, conexão, credenciais, fila nem agendas.
- M5 — `linkedin/audit` em ordem do mais recente, com `since` opcional; `list-connections` com uma leitura por página; retenção exclui registro ilegível da seleção; `f3_linkedin_schema` e a marca `f3_linkedin_queue_settled` em autoload, sem consulta SQL própria no carregamento de cada requisição.
- Leitura documental: `linkedin/documentation` recusava `offset` acima de 100000, e o `input-schemas.json` instalado tem cerca de 117 KB; com páginas de 16 KB o fim do documento ficava inacessível pela operação. Teto elevado a 16 MiB.
- M6 — Testes alinhados às versões reais dos acompanhantes (Core 1.48.0 com regra de servidor separada, MCP 0.28.0 com consumidor central real), matriz mínima WordPress 6.4/PHP 8.1.2 executada.

Limites: a homologação no LinkedIn real (conversão entregue e contada, regra API e `rw_conversions` na conta de CTO Office) segue com o dono e a frota. Ver o relatório da entrega para a matriz executada.
