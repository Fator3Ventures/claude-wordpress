> Histórico da 0.7.0. Consulte RELEASE-0.8.0.md para a entrega corrente.

# Notas e aceite — 0.7.0

Base direta 0.6.0. Escopo: Pedidos MCP LinkedIn 8(d), coordenação com Pedidos MCP 65 e proposta recebida do MCP 0.27.0, revisão 2. Mantidas as 79 abilities anteriores; acrescentada linkedin/get-service-write-operation.

Parte de domínio do contrato mutation-service-audit/1.0.0: descritor e introspector PHP locais, leitor administrativo com concessão/revisão vigentes, emissão de serviço desde sendBound, referência opaca persistida antes do POST e conferência de recibo central por digest. Usuário zero ou incidental não altera o principal. Replay não reemite nem reenvia; revogação bloqueia detalhe e preserva histórico. Auditoria humana continua separada. Leitor e introspector não consultam fornecedor nem gravam estado.

O MCP 0.27.0 não implementa o consumidor: service_principal_unsupported permanece correto nessa combinação. O handshake e o recibo foram concretizados como proposta ao responsável MCP, sem alterar seu pacote. Consumidor simulado comprova comportamento do domínio, não aceite central real. Leia SERVICE-AUDIT.md e o relatório externo para a matriz efetivamente executada.

Pedidos 9, 10, 11 e 8(a,b,c,e) foram retirados pelo responsável pela lista atual após a 0.6.0. A aba recebida informa seguidores reais de 14 na CTO Office e 9831 na fator3, aceitos em 22/10/2026; essa é evidência recebida, não nova consulta desta rodada. Permanecem com dono/frota os aceites reais 20/92 e a decisão 116 sobre regra Insight Tag/API. Não houve envio real de conversão ou mudança na fila Core. Mínimos WordPress 6.4/PHP 8.1.2 continuam herdados e sem nova prova desta rodada.
