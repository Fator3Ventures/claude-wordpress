> Histórico congelado da versão 0.5.0; a pendência MCP mencionada abaixo foi atendida pelo MCP 0.26.1 e pelo descritor da 0.6.0.

# Notas e aceite — 0.5.0

Base direta: 0.4.1. Pedidos MCP LinkedIn 5, 6 e 7. Identidade, prefixos, contratos de relatórios e Lead Reader preservados. Acrescenta 31 operações (total 73), rótulos/descrições em português, gestão com prévia e confirmação, diário cifrado e renovação opcional.

Pedido 5 implementado em todas as abilities. Pedido 6 implementado no pacote com limite de edição de posts ao texto e inicialização de mídia sem transferência/finalização. Antes/depois no Registro central é pendência do responsável MCP; antes/depois local está disponível. Pedido 7 implementado; refresh depende de emissão pelo aplicativo e de cron operacional.

A matriz e as evidências desta rodada constam no relatório externo e no ZIP fonte. Testes simulados em WordPress real não comprovam aceitação do payload por uma conta real do LinkedIn. Homologação de gastos/publicações, OAuth e primeira renovação real exige credenciais/aprovação e ordem do dono. Nenhuma produção é alterada automaticamente pela instalação.

Aceite futuro sob ordem específica: conta 558431216 em ctooffice, grupo/campanha DRAFT, releitura, renomeação e exclusão com diário; Página fator3 40774077, criação/exclusão de publicação na data combinada; primeira renovação automática real registrada. Não executar como consequência de consultar esta ajuda.
