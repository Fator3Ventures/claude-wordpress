# Notas — 0.8.1

Patch solicitado na revisão independente de 23/10/2026, base 0.8.0. Quatro defeitos foram reproduzidos na base; correções preservam 81 abilities, schemas de entrada, SDKs, identidade, payload e os contratos humano/de serviço.

- R1: coletas já indexadas ilegíveis ocupavam as primeiras 20 posições e impediam progresso. O worker isola apenas a projeção técnica sob a trava da coleta, preservando payload/revisão/datas/retenção.
- R2: última coleta de agenda ilegível derrubava status. Agora retorna diagnóstico degradado com schedule_job_unreadable, sem reparo.
- R3: prova local conhecida expirada era ignorada na prontidão. Capabilities e diagnose-conversions respeitam expiração/atividade da prova vigente; a consulta não renova nem chama o fornecedor.
- R4: agenda desabilitada automaticamente por autorização desaparecia do diagnóstico. O aviso permanece visível, sem reativação.

Sem schema novo: atualização 0.8.0→0.8.1 conserva schema 2; salto 0.7.0 aplica a migração aditiva existente. MCP 0.28.0 já implementa mutation-service-audit/1.0.0; a pendência técnica da 0.7.0 está superada para o conjunto validado. Core 1.48.0 conserva IDs separados para Insight Tag e regra API. Conversão real entregue e contada continua dependente de autorização, ativo e homologação do dono. Consulte o relatório da revisão para resultados próprios, evidências recebidas e matriz executada.
