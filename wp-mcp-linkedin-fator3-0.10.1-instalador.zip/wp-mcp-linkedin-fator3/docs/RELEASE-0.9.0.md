# Fator3 MCP LinkedIn 0.9.0

Base aceita: 0.8.1. Pedido atendido: **12**, corrida no isolamento de coletas ilegíveis na migração e na retenção.

O isolamento passa a reler o job sob bloqueio individual e a atualizar somente a mesma revisão e o mesmo ciphertext. A comparação binária impede que a collation textual trate cifras diferentes como iguais. Worker, migração e retenção compartilham esse caminho. Um registro reparado por outra gravação não é marcado como ilegível por uma leitura antiga. Erros SQL continuam explícitos e bloqueios ocupados adiam a migração/retenção sem alterar a projeção.

A alteração preserva dados cifrados, revisão, datas e expiração. Mantém schema 2, 81 operações, SDK Lead Reader, SDK de conversões e auditoria central. Atualização direta: 0.8.1 → 0.9.0. Não exige mudança nos acompanhantes Core 1.49.1, MCP 0.29.1, Google 0.18.1 e Meta 0.7.1. O critério conservador do MCP para repetição exige prova explícita de ausência de efeito; esta release não adiciona essa prova sem fundamento.

Não reativa jobs já isolados nem reenvia conversões. Homologação comercial do LinkedIn continua dependente de credenciais e produtos autorizados. Testes de concorrência usam MySQL real, conexões independentes e fixtures sintéticas; não comprovam chamadas comerciais.
