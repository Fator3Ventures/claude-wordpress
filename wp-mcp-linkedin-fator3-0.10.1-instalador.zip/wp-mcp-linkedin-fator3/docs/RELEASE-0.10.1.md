# Fator3 MCP LinkedIn 0.10.1

Patch da 0.10.0, identificado na revisão final após a aplicação inicial no Site-Teste. Refresh Token manual não é aceito como prova de continuidade de membro. Renovação sem comprovação de mesma identidade guarda candidata temporária e exige confirmação guiada, preservando a credencial ativa. Troca manual do refresh remove a prova de vínculo; par aceito de resposta OAuth/refresh permite a continuidade subsequente. Veja CREDENTIALS.md.

Mantém as 81 operações, schema SQL 2 e os campos aditivos da 0.10.0. Não requer mudança no Core, MCP, Meta ou Google. Base direta de desenvolvimento 0.9.0; a entrega corrente passa a ser 0.10.1.
