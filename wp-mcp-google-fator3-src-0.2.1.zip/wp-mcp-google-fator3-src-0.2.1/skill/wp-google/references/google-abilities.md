# Rotas Google e equivalências — 0.2.0

| Vocabulário Porter | WP MCP Google Fator3 |
|---|---|
| list_connectors / whoami | google/status |
| list_accounts | google/list-accounts |
| list_fields | google/list-fields |
| query_data | google/query |
| list_actions / execute_action | google/list-actions / google/execute-action |
| create_blend | google/blend |
| exportação para planilha | google/export-to-sheet |

`google/query` devolve colunas descritas por objetos `id/label/type/kind` e linhas posicionais. Aceita conector ga4/google-ads/search-console, accounts, metrics, dimensions, date_range, compare_date_range, filtros e ordenação. Exemplos de período: last_30_days, previous_period para comparação, ou {from,to}. Nomes de conta precisam ser únicos; * é expansão explícita.

Para rotas nomeadas de GA4 em escrita, usar body com campos oficiais, property_id e seletores específicos de subrecurso; atualização aceita update_mask. Para Ads, usar resource/resources/resource_names, no formato oficial camelCase; obter o schema exato. Para Search Console, site_url precisa corresponder à propriedade URL-prefix ou sc-domain registrada.

## Exemplo de descoberta genérica

1. Executar google/list-actions com {"api":"analytics-admin-v1alpha","task":"audience","limit":10}.
2. Ler id, parâmetros e request_schema da ação escolhida. Percorrer next_offset quando necessário.
3. Confirmar a gravação concreta com o usuário se houver efeito de escrita.
4. Executar google/execute-action com api, method, path_params, query e body.

As versões disponíveis são analytics-admin-v1alpha/v1beta, analytics-data-v1beta/v1alpha, google-ads (versão configurada), search-console, site-verification, sheets e drive. O catálogo validado nesta versão possui 521 métodos. Não reutilizar nomes de métodos de outra versão sem conferir.

## Blends e exportações

Blends aceitam queries:[{query:{...},prefix:"ga4"},{query:{...},prefix:"ads"}], on:["date"] com campaign/page opcionais. As consultas também podem ser objetos diretos. Junções recusam duplicatas ambíguas; não contornar removendo avisos ou inventando totais.

Exportar passando query/blend/queries e spreadsheet_id; para criação, title e destino compatível. Service account simples exige shared_drive_folder_id de um Drive compartilhado, ou planilha existente compartilhada. share_with lista e-mails, share_role define reader/commenter/writer. A operação escreve valores literais. append em aba existente exige cabeçalho compatível.

## Auditoria e limites

Consultar google/audit por action/target/status/mode/from/to. before/after podem estar limitados ou indisponíveis. Ads partial_failure pode ter aplicado parte das operações; verificar resultados antes de repetir. Customer Match/offlineUserDataJobs é assíncrono e novas integrações podem precisar de Data Manager API. Inspeção de URL não solicita indexação.


Os campos abaixo são apenas os obrigatórios na raiz do schema. Regras condicionais, corpo e nomes de recurso devem ser consultados em Get Ability Info ou no manifesto JSON.

## google/*

| Habilidade | Modo | Obrigatórios na raiz |
|---|---|---|
| `google/audit` | leitura | Ver regras da operação |
| `google/blend` | leitura | `queries` |
| `google/execute-action` | escrita | `api`, `method` |
| `google/export-to-sheet` | escrita | Ver regras da operação |
| `google/list-accounts` | leitura | Ver regras da operação |
| `google/list-actions` | leitura | Ver regras da operação |
| `google/list-fields` | leitura | `connector` |
| `google/query` | leitura | `connector`, `metrics`, `date_range` |
| `google/selftest` | leitura | Ver regras da operação |
| `google/status` | leitura | Ver regras da operação |

## ga/*

| Habilidade | Modo | Obrigatórios na raiz |
|---|---|---|
| `ga/add-user` | escrita | `body` |
| `ga/archive-audience` | escrita | Ver regras da operação |
| `ga/archive-custom-dimension` | escrita | Ver regras da operação |
| `ga/archive-custom-metric` | escrita | Ver regras da operação |
| `ga/check-compatibility` | leitura | `dimensions`, `metrics` |
| `ga/create-annotation` | escrita | `body` |
| `ga/create-audience` | escrita | `body` |
| `ga/create-custom-dimension` | escrita | `body` |
| `ga/create-custom-metric` | escrita | `body` |
| `ga/create-google-ads-link` | escrita | `body` |
| `ga/create-key-event` | escrita | `body` |
| `ga/create-mp-secret` | escrita | `body` |
| `ga/create-property` | escrita | `body` |
| `ga/create-web-stream` | escrita | `body` |
| `ga/delete-account` | escrita | Ver regras da operação |
| `ga/delete-annotation` | escrita | Ver regras da operação |
| `ga/delete-google-ads-link` | escrita | Ver regras da operação |
| `ga/delete-key-event` | escrita | Ver regras da operação |
| `ga/delete-mp-secret` | escrita | Ver regras da operação |
| `ga/delete-property` | escrita | Ver regras da operação |
| `ga/delete-web-stream` | escrita | Ver regras da operação |
| `ga/get-account-summaries` | leitura | Ver regras da operação |
| `ga/get-metadata` | leitura | Ver regras da operação |
| `ga/get-property-details` | leitura | Ver regras da operação |
| `ga/get-settings` | leitura | Ver regras da operação |
| `ga/list-google-ads-links` | leitura | Ver regras da operação |
| `ga/list-property-annotations` | leitura | Ver regras da operação |
| `ga/list-users` | leitura | Ver regras da operação |
| `ga/provision-account` | escrita | `body` |
| `ga/remove-user` | escrita | Ver regras da operação |
| `ga/run-conversions-report` | leitura | `date_ranges`, `dimensions`, `metrics`, `conversion_spec` |
| `ga/run-funnel-report` | leitura | `funnel_steps` |
| `ga/run-realtime-report` | leitura | `dimensions`, `metrics` |
| `ga/run-report` | leitura | `date_ranges`, `dimensions`, `metrics` |
| `ga/send-event` | escrita | `measurement_id`, `api_secret`, `client_id`, `events` |
| `ga/update-annotation` | escrita | `body` |
| `ga/update-attribution` | escrita | `body` |
| `ga/update-audience` | escrita | `body` |
| `ga/update-data-retention` | escrita | `body` |
| `ga/update-enhanced-measurement` | escrita | `body` |
| `ga/update-google-signals` | escrita | `body` |
| `ga/update-key-event` | escrita | `body` |
| `ga/update-property` | escrita | `body` |
| `ga/update-user` | escrita | `body` |
| `ga/update-web-stream` | escrita | `body` |

## ads/*

| Habilidade | Modo | Obrigatórios na raiz |
|---|---|---|
| `ads/add-audience-to-campaign` | escrita | `customer_id`, `resource` |
| `ads/add-keywords` | escrita | `customer_id`, `resources` |
| `ads/add-label` | escrita | `customer_id`, `resource` |
| `ads/add-negative-keywords` | escrita | `customer_id`, `resources` |
| `ads/apply-label` | escrita | `customer_id`, `resource` |
| `ads/create-ad-group` | escrita | `customer_id`, `resource` |
| `ads/create-asset` | escrita | `customer_id`, `resource` |
| `ads/create-asset-group` | escrita | `customer_id`, `resource` |
| `ads/create-billing-setup` | escrita | `customer_id`, `resource` |
| `ads/create-budget` | escrita | `customer_id`, `resource` |
| `ads/create-campaign` | escrita | `customer_id`, `resource` |
| `ads/create-conversion-action` | escrita | `customer_id`, `resource` |
| `ads/create-experiment` | escrita | `customer_id`, `resource` |
| `ads/create-responsive-search-ad` | escrita | `customer_id`, `resource` |
| `ads/create-user-list` | escrita | `customer_id`, `resource` |
| `ads/get-campaign` | leitura | `customer_id`, `resource_name` |
| `ads/get-customer` | leitura | `customer_id` |
| `ads/get-resource-metadata` | leitura | `resource_name` |
| `ads/invite-user` | escrita | `customer_id`, `resource` |
| `ads/link-asset` | escrita | `customer_id`, `resource` |
| `ads/list-accessible-customers` | leitura | Ver regras da operação |
| `ads/list-assets` | leitura | `customer_id` |
| `ads/list-audiences` | leitura | `customer_id` |
| `ads/list-conversion-actions` | leitura | `customer_id` |
| `ads/list-customer-clients` | leitura | `manager_customer_id` |
| `ads/list-experiments` | leitura | `customer_id` |
| `ads/list-resources` | leitura | Ver regras da operação |
| `ads/list-users` | leitura | `customer_id` |
| `ads/mutate` | escrita | `customer_id`, `operations` |
| `ads/remove-ad` | escrita | `customer_id`, `resource_name` |
| `ads/remove-ad-group` | escrita | `customer_id`, `resource_name` |
| `ads/remove-campaign` | escrita | `customer_id`, `resource_name` |
| `ads/remove-keywords` | escrita | `customer_id`, `resource_names` |
| `ads/remove-negative-keywords` | escrita | `customer_id`, `resource_names` |
| `ads/remove-user` | escrita | `customer_id`, `resource_name` |
| `ads/schedule-experiment` | escrita | `customer_id`, `resource_name` |
| `ads/search` | leitura | `customer_id` |
| `ads/update-ad-group` | escrita | `customer_id`, `resource` |
| `ads/update-ad-status` | escrita | `customer_id`, `resource` |
| `ads/update-budget` | escrita | `customer_id`, `resource` |
| `ads/update-campaign` | escrita | `customer_id`, `resource` |
| `ads/update-conversion-action` | escrita | `customer_id`, `resource` |
| `ads/update-keyword` | escrita | `customer_id`, `resource` |
| `ads/update-user-access` | escrita | `customer_id`, `resource` |
| `ads/upload-click-conversions` | escrita | `customer_id`, `conversions` |
| `ads/upload-customer-match` | escrita | `customer_id`, `users` |

## gsc/*

| Habilidade | Modo | Obrigatórios na raiz |
|---|---|---|
| `gsc/add-site` | escrita | `site_url` |
| `gsc/delete-site` | escrita | `site_url` |
| `gsc/delete-sitemap` | escrita | `site_url`, `sitemap_url` |
| `gsc/get-site` | leitura | `site_url` |
| `gsc/inspect-url` | leitura | `site_url`, `inspection_url` |
| `gsc/list-sitemaps` | leitura | `site_url` |
| `gsc/list-sites` | leitura | Ver regras da operação |
| `gsc/query` | leitura | `site_url` |
| `gsc/submit-sitemap` | escrita | `site_url`, `sitemap_url` |

## siteverification/*

| Habilidade | Modo | Obrigatórios na raiz |
|---|---|---|
| `siteverification/get-token` | leitura | `site`, `verification_method` |
| `siteverification/list` | leitura | Ver regras da operação |
| `siteverification/update-owners` | escrita | `id`, `owners` |
| `siteverification/verify` | escrita | `site`, `verification_method` |

