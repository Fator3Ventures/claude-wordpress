---
name: wp-google
description: Consultar e administrar Google Analytics, Ads, Search Console, verificação de sites e exportações Sheets/Drive pelo plugin WP MCP Google Fator3 instalado no WordPress. Usar quando a tarefa envolve os serviços Google conectados por esse plugin.
metadata:
  version: "0.2.0"
  plugin: "WP MCP Google Fator3 0.2.0"
---

# WP MCP Google Fator3

Usar as habilidades Google pelo servidor MCP do WordPress. O plugin 0.2.0 registra 114 habilidades, incluindo leitura e escrita. O catálogo efetivo e os schemas do servidor são a autoridade quando diferirem deste guia.

## Acesso e descoberta

Usar as metatools Discover Abilities, Get Ability Info e Execute Ability do conector Fator3/Ultimate disponível. Os nomes podem aparecer normalizados com hífens. Execute Ability recebe `ability_name` e `parameters` como objeto, inclusive `{}`.

Manter a URL do servidor existente; na configuração padrão Fator3 é `/wp-json/mcp/wp-mcp-ultimate`. Não criar outro conector para este complemento. Ler `google/status` ao diagnosticar configuração, identidade, escopos e APIs. Verificar tanto o envelope MCP quanto o `success` interno da habilidade, os erros e os avisos.

Usar Get Ability Info quando os parâmetros não forem conhecidos, especialmente em gravações. Consultar o catálogo de famílias e exemplos em [references/google-abilities.md](references/google-abilities.md). Usar Discover Abilities para confirmar o que está instalado ou atualizar um catálogo desatualizado.

## Consultas

1. Resolver a conta com `google/list-accounts`. IDs explícitos são preferíveis depois de identificar o alvo; nomes precisam ser únicos. Não escolher entre candidatos ambíguos.
2. Consultar `google/list-fields` quando precisar descobrir métricas/dimensões; para conversões customizadas Ads, informar `account_id`.
3. Executar `google/query` com conector, contas, métricas e período. Usar `google/blend` para combinar fontes e `google/export-to-sheet` para exportar.

Ler `warnings`, `truncated`, períodos e moeda antes de reportar números. Ausência de linhas não significa zero quando a consulta falha. Não somar médias, CTR ou ROAS; evitar junções com granularidades diferentes. Células sem par em blend são `null`, não zero. Explicar diferenças de atribuição entre Ads e GA4 quando relevantes.

## Gravações e confirmação

Antes de uma escrita, apresentar e obter confirmação da operação concreta: conta/propriedade/arquivo, campos, valores e alvos afetados. Para wildcard, listar os alvos resolvidos antes da confirmação. Autorização explícita já dada para essa mesma operação satisfaz a confirmação; não pedir novamente sem mudança material.

Depois de autorizado, executar diretamente. O plugin não tem etapa de confirmação, interruptor separado de escrita nem reversão. Não usar esta regra para impedir leituras ou testes locais. `google/execute-action` é anotada como escrita mesmo quando o método escolhido é GET: julgar também o efeito do método específico.

Usar `dry_run:true` em Ads quando a validação ajudar e o método suportar `validateOnly`. Não apresentar dry run como alteração aplicada. Métodos sem suporte recusam dry run. No Measurement Protocol, `debug:true` valida payload sem coletar eventos e sem comprovar o api_secret; coleta HTTP 2xx não comprova processamento.

Após falha de rede, resultado parcial ou operação assíncrona, verificar o estado/referência retornados antes de repetir. Relatar alterações confirmadas e pendências separadamente. A auditoria `google/audit` ajuda a diagnosticar; snapshots podem ser limitados/indisponíveis e não são backup.

## Métodos sem rota nomeada

Chamar `google/list-actions` com `api`, `task` e paginação; a busca usa descrições oficiais majoritariamente em inglês. Obter id completo, verbo, parâmetros e `request_schema`. Chamar `google/execute-action` com esses dados em `api`, `method`, `path_params`, `query`, `body`. Não inventar IDs ou URLs, nem inserir access tokens na query para trocar a identidade configurada.

Nenhum método listado concede papéis ou habilita APIs. Corrigir a ação indicada no erro: API desabilitada, escopo ausente, aprovação de developer token ou acesso ao recurso. Não contornar o portão/capacidade pelo servidor de arquivos ou options do WordPress.

## Composição com o site

Usar as ferramentas de arquivos/conteúdo do Fator3 para publicar token META/arquivo somente após autorização para essa alteração. Verificação de domínio exige DNS; não afirmar que emitir token verifica o domínio.

Tag GA4, consentimento, ponte de eventos, onboarding completo e agendamentos ficam nas ferramentas responsáveis por esses trabalhos. Este complemento apenas expõe APIs. Manter fora daqui tarefas sem relação com os serviços Google solicitados.

Para planilhas novas, service accounts simples precisam de Drive compartilhado; também é possível editar planilha existente compartilhada ou criar via OAuth/delegação. Não prometer arquivos próprios no Meu Drive da service account. Customer Match em novas integrações pode exigir Data Manager API, fora deste catálogo.
