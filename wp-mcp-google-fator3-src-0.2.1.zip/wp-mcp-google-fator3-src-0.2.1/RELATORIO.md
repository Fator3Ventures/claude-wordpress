# WP MCP Google Fator3 0.2.1 — correção HTTP 411

Data: 2026-09-09. Base: pacote 0.2.0 com `googlecloudscript.txt` incorporado.

## Problema confirmado

`gsc/submit-sitemap` usa PUT sem corpo, conforme o contrato oficial da Search Console. O cliente `includes/Http/GoogleClient.php` não definia o corpo nem `Content-Length` quando recebia `body=null`. O transporte Requests/Fsockopen 2.0.11 não acrescenta automaticamente esse cabeçalho ao PUT vazio. A mesma condição ocorre em `gsc/add-site` e nos métodos correspondentes de `google/execute-action`.

Referência: https://developers.google.com/webmaster-tools/v1/sitemaps/submit — o método exige corpo ausente/vazio.

## Correção

Após a serialização do corpo, o cliente define `body=''` e `Content-Length: 0` para PUT com corpo ausente, string vazia ou formulário vazio. O JSON `{}` continua sendo um corpo de dois bytes e não recebe comprimento zero. Payloads JSON, binários, texto `0`, formulários preenchidos e outros métodos HTTP são preservados. Não há alteração de credenciais, endpoints MCP, scopes, habilidades ou opções. A pasta e o arquivo principal do plugin permanecem iguais.

## Validação executada nesta versão

- Regressão antes da correção: 14 casos executados, 5 falhas relacionadas ao PUT vazio.
- Reprodução HTTP antes da correção: as três entradas (`gsc/submit-sitemap`, `gsc/add-site`, `google/execute-action`) receberam 411 no servidor local; `Content-Length` ausente e zero bytes no corpo.
- Reprodução HTTP depois: as três entradas receberam 204 e indicaram sucesso; cabeçalho `Content-Length: 0`, zero bytes de corpo, sem `Content-Type` artificial.
- Suíte completa: **763 testes, 8.380 asserções, zero falhas** — PHP 8.3.6 / PHPUnit 9.6.17.
- Sintaxe PHP: **45 arquivos de produção aprovados**.

O teste HTTP usa uma conexão TCP real para localhost e o transporte Requests/Fsockopen 2.0.11 distribuído com WordPress. As funções WordPress são simuladas pelo bootstrap da suíte e o endpoint local emula a exigência de tamanho e as respostas Google. Não foram usados tokens reais. Não houve envio de sitemap às contas Google do usuário nem nova instalação em servidor WordPress remoto. A validação em produção após atualizar permanece necessária.

Os testes preexistentes enfileiravam respostas de sucesso e verificavam métodos/snapshots sem exigir o cabeçalho. Foram acrescentadas asserções nas rotas GSC e 13 casos específicos para transporte e preservação de payloads.

## Reprodução

Suíte padrão: `composer install` e `composer test` dentro de `wp-mcp-google-fator3/`.

Teste HTTP local, a partir da raiz deste pacote (substitua os caminhos pelos do seu ambiente):

```sh
python3 integration/empty-put-wire.py \
  --php /caminho/para/php \
  --plugin /caminho/para/wp-mcp-google-fator3 \
  --requests /caminho/para/wordpress/wp-includes/Requests
```

Para reproduzir a falha, aponte `--plugin` para o código 0.2.0 e acrescente `--expect-411`.

## Artefatos

- ZIP instalável `wp-mcp-google-fator3-0.2.1.zip`: substitui a versão anterior pelo painel WordPress. Atualize sem desinstalar para preservar as credenciais.
- ZIP fonte `wp-mcp-google-fator3-src-0.2.1.zip`: fontes, testes, fixtures, integração local, evidências e histórico Git atualizado.
- `googlecloudscript.txt`: preservado byte a byte como referência; não executado.
- `evidence/0.2.1/`: resultados desta correção. Os arquivos diretamente em `evidence/`, `RELATORIO-0.2.0.md` e `PROVENANCE-0.2.0.json` documentam a versão anterior; suas verificações WordPress/PHPCS/mutação não foram repetidas nem atribuídas à 0.2.1.
