# WP MCP Google Fator3 0.2.1 — código-fonte

Este arquivo ZIP é o pacote de desenvolvimento. Para instalar pelo painel WordPress, use o ZIP separado `wp-mcp-google-fator3-0.2.1.zip`.

- `wp-mcp-google-fator3/`: plugin, documentação operacional, testes e fixtures.
- `skill/wp-google/`: guia de uso atualizado para o agente, com catálogo de referência; não é instalado automaticamente no cliente.
- `CATALOGO-HABILIDADES.md` e `abilities-manifest.json`: 114 habilidades registradas, com schemas no manifesto.
- `RELATORIO.md`: correção e validação da 0.2.1; `RELATORIO-0.2.0.md` preserva o relatório anterior.
- `PLANO-RECEBIDO.md`: plano original recebido.
- `evidence/0.2.1/`: resultados atuais da suíte e do teste HTTP local. Os arquivos diretamente em `evidence/` são evidências históricas da 0.2.0.
- `integration/`: instruções e scripts para reproduzir os testes em WordPress descartável.
- `PROVENANCE.json`: origem, hashes e contagens atuais; `PROVENANCE-0.2.0.json` preserva a proveniência anterior.
- `source-history.bundle`: histórico Git do plugin e da skill, com as tags `v0.1.0`, `v0.2.0` e `v0.2.1`.

Para inspecionar o histórico:

```sh
git clone source-history.bundle revisao
git -C revisao diff v0.2.0 v0.2.1
```

Para executar a suíte de desenvolvimento:

```sh
cd wp-mcp-google-fator3
composer install
composer test
composer lint
```

As requisições Google dos testes são simuladas. A validação com credenciais e destinos Google reais permanece pendente. A atualização da 0.1.0 preserva o basename e as opções; substitua os arquivos sem desinstalar o plugin Google e mantenha o WP MCP Fator3 ativo.

## Referência para configuração do Google Cloud

[googlecloudscript.txt](googlecloudscript.txt) é o script fornecido pelo usuário para execução manual no Google Cloud Shell. Contém comandos para criar ou reutilizar um projeto, habilitar as sete APIs utilizadas pelo plugin e gerar uma service account com chave JSON por site. O arquivo foi incluído integralmente na entrega 0.2.0 e permanece preservado, sem alterações e sem execução na entrega 0.2.1.

Ao adaptar a referência, revise `SITES`, `SEGUNDO_DONO` e `PROJETO`, inclusive o projeto fixo informado na listagem da etapa 4. Cada execução solicita novas chaves para os sites listados. O script configura contas de serviço; as credenciais OAuth de usuário e o developer token do Google Ads não são criados por ele.
