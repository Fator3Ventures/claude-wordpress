# WP MCP Google Fator3 0.2.0 — relatório de entrega

Data: 08/09/2026. Base: ZIP 0.1.0 e plano 0.2.0 enviados pelo usuário. A versão é um complemento independente instalado ao lado do **WP MCP Fator3 0.9.0**.

## Resultado

Entregue plugin instalável, código-fonte, skill wp-google atualizada, catálogo das habilidades e evidências reproduzíveis. Registro real: **114 habilidades — 39 de leitura e 75 de escrita**. São 93 novas habilidades, com preservação das 21 anteriores.

| Família | Na 0.1.0 | Na 0.2.0 | Acréscimo |
|---|---:|---:|---:|
| Analytics ga/* | 10 | 45 | 35 |
| Ads ads/* | 6 | 46 | 40 |
| Unificada google/* | 5 | 10 | 5 |
| Search Console gsc/* | 0 | 9 | 9 |
| Site Verification | 0 | 4 | 4 |
| Total | 21 | 114 | 93 |

Além das habilidades nomeadas, o executor genérico usa nove documentos oficiais de descoberta, totalizando **521 métodos** na fotografia validada. Os 521 templates foram montados em testes a partir desses documentos; isso não significa 521 operações executadas contra contas reais.

## Implementação do plano

| Área | Implementação |
|---|---|
| Núcleo | mode read/write, anotações MCP, mesmo portão geral/capacidade; novos hosts e escopos; auditoria estruturada; diagnóstico observado de APIs |
| Descoberta | list-actions paginado, busca textual e schemas oficiais; cache de 24 h; todas as nove versões previstas |
| Execução genérica | URL/verbo/parâmetros derivados do documento, validação de corpo, credencial configurada, uploads multipart e downloads binários |
| Search Console / verificação | Todas as rotas nomeadas do plano; consultas e integração com contas/campos/blend; tokens, verificação e proprietários |
| Analytics | Todas as rotas Admin novas do plano, leitura de settings/usuários e envio/validação MP |
| Google Ads | Todas as rotas nomeadas, mutate genérico, validateOnly quando suportado, conversões, Customer Match, PMax/experimentos e usuários/faturamento |
| Contas e métricas | Nomes únicos, candidatos em ambiguidade, wildcard explícito, hierarquias Ads completas, métricas customizadas sem duplicar totais comuns |
| Blend | Junção externa por date/campaign/page, normalização, períodos, prefixos e avisos; duplicatas ambíguas recusadas |
| Sheets/Drive | Planilha existente ou criação em destino permitido, abas, replace/append, compartilhamento e resultados parciais explícitos |
| Skill | Catálogo, genéricas, equivalências Porter, confirmação de escrita pelo agente e composição com ferramentas do site |

O plugin não exige aprovação em duas fases, não tem interruptor separado de escrita e não implementa reversão. A confirmação de uma gravação concreta fica no agente. Auditoria registra estados recuperáveis; indisponibilidade ou amostragem é identificada, sem inventar snapshots.

## Correções na base e na integração

- Cache de contas passa a considerar credencial, OAuth, delegação e administradora. Tokens de service account são isolados por usuário delegado; tokens OAuth consideram a credencial mesmo sem e-mail.
- Nomes numéricos de IDs Ads são mantidos como strings; IDs com hífens/prefixos são deduplicados, evitando execução duplicada ou interrupção de fanout depois de gravar.
- Hierarquias Ads deixam de ser cortadas pelo limite de 25 detalhes ou pelo limite de linhas de relatório. Falhas e catálogos incompletos não são apresentados como seleção completa de wildcard.
- Paginação detecta ciclos e teto excedido, retornando erro em vez de totais incompletos silenciosos.
- Escritas não são repetidas automaticamente após erros de transporte/5xx. Falhas parciais preservam resultados já confirmados.
- Objetos vazios são codificados como objeto JSON segundo o schema; listas vazias permanecem listas, inclusive em campos aninhados como manualCpc.
- Parâmetros repeated e booleanos seguem o formato HTTP Google. Erros redigem inclusive tokens ecoados em chamadas públicas de descoberta.
- A interface deixou de anunciar somente leitura; status não confunde token emitido com API habilitada ou recurso autorizado.

## Correções factuais no plano

**Sheets e service accounts:** service accounts não possuem quota de armazenamento do Meu Drive. A criação exige Drive compartilhado ou OAuth/delegação; também é possível editar planilha existente compartilhada. Uma pasta compartilhada do Meu Drive não equivale a Drive compartilhado. [Documentação Google Drive](https://developers.google.com/workspace/drive/api/guides/handle-errors).

**Escopos:** analytics.edit não cobre sozinho relatórios e administração de usuários. A implementação inclui analytics.readonly e analytics.manage.users e usa os escopos aceitos por método na descoberta. Não foi inventado um escopo analytics.provision: o provisionamento atual usa analytics.edit. [Referência Analytics Admin](https://developers.google.com/analytics/devguides/config/admin/v1/rest).

**Measurement Protocol:** debug valida payload sem coletar eventos e não confirma api_secret; resposta 2xx na coleta não prova processamento. Segredos MP não são persistidos pelo plugin, mas a API permite leitura conforme permissões — não é correto afirmar que o Google sempre os entrega somente uma vez. [Validação MP](https://developers.google.com/analytics/devguides/collection/protocol/ga4/validating-events), [referência MP](https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference).

**Customer Match:** implementado o fluxo Ads solicitado, sujeito à elegibilidade. Desde abril de 2026, novas integrações frequentemente devem usar Data Manager API, fora do plano e deste catálogo. [Documentação Google Ads](https://developers.google.com/google-ads/api/docs/remarketing/audience-segments/customer-match/manage).

**Contagens:** o plano dizia três rotas de verificação, mas listava quatro; também subcontava outras famílias. A contagem desta entrega vem do registro WordPress.

## Evidência executada

| Verificação | Resultado |
|---|---|
| PHPUnit 9.6.29 | 750 testes, 8336 assertions; 0 falhas, 0 erros |
| WordPress 6.9.4 / Abilities API nativa | 1.162 verificações aprovadas |
| WordPress 6.8.3 / polyfill Fator3 | 1.162 verificações aprovadas |
| Transporte MCP REST interno | 5 verificações em cada WordPress: initialize, sessão, três metatools, descoberta das 114 habilidades e execução GA |
| Total integração WordPress | 2334 verificações, 0 falhas |
| PHPCS / WPCS 3.4.1 / PHPCompatibilityWP 2.1.8 | 45 arquivos PHP de produção; 0 erros, 0 avisos |
| Mutação: host removido | Detectada pela suíte |
| Mutação: before removido da auditoria | Detectada pela suíte |
| Mutação: normalização da junção quebrada | Detectada pela suíte |
| Mutação: caminho genérico fora do documento aceito | Detectada pela suíte |
| Restauração das mutações | Confirmada por bytes e SHA256 |
| Migração 0.1→0.2 | Mesmo basename; configurações e cifras preservadas byte a byte em ambos WordPress |

As contagens representam verificações/testes executados, não uma medida de cobertura de linhas. Os 45 PHP entregues correspondem aos hashes testados no WordPress. Há exemplos de sucesso e erro, recusas por capacidade, snapshots, dry run, consultas multiconector, conversões, fanout e validação de schemas.

**Limite da validação:** WordPress e MariaDB eram reais, locais; HTTP das APIs Google foi simulado por fixtures determinísticas. O transporte MCP foi exercitado por despacho REST interno, sem tráfego externo passando pelo proxy/hospedagem. Não foram fornecidas credenciais/destinos reais de Google Ads, GA4, Search Console ou Sheets. Portanto, **o ensaio vivo exigido no plano permanece pendente**; não houve criação/remoção de propriedades, campanhas ou arquivos nas contas do usuário.

O ambiente real deverá confirmar habilitação de APIs, papéis, developer token, escopos OAuth, regras específicas de conta e comportamento da hospedagem. A implementação e os pacotes estão prontos para essa homologação; esta entrega não é uma implantação em produção.

## Compatibilidade, instalação e conexão

Atualizar usando `wp-mcp-google-fator3-0.2.0.zip` pelo envio de plugin do WordPress, mantendo o WP MCP Fator3 ativo. Se a 0.1 estiver instalada, substituir o plugin existente; não desinstalá-lo antes, porque o desinstalador remove credenciais.

Pasta/arquivo mantidos: `wp-mcp-google-fator3/wp-mcp-google-fator3.php`. Chaves de opções e cifragem preservadas. Não há Composer ou SDK para instalar em produção.

URL MCP padrão preservada: `https://SEU-DOMINIO/wp-json/mcp/wp-mcp-ultimate`. O complemento não cria outro servidor. Uma configuração personalizada do Fator3 continua válida. Callback OAuth preservado: `/wp-json/wp-mcp-google-fator3/v1/oauth/callback`.

O conector continua com as três metatools; 114 habilidades Google são descobertas/executadas por elas. Não é necessário expor as 114 como ferramentas separadas. A skill atualizada acompanha o pacote-fonte; ela não é instalada automaticamente no cliente do usuário.

## Limites operacionais declarados

- Listas explícitas de contas em consultas herdadas mantêm o limite de 25 contas com aviso; wildcard expande catálogo completo ou recusa a listagem parcial.
- Blend: 2–10 consultas; duplicatas precisam ser resolvidas na granularidade. Exportação: 20 abas, 500.000 células, 8 MiB de payload; append exige cabeçalho idêntico. Conteúdo é escrito como valor literal.
- Upload genérico inline: 20 MiB. Operações maiores exigem outro fluxo compatível com a API, não upload inline por esta habilidade.
- Auditoria: 100 entradas; before/after até 4 KiB cada. Amostras e ausência de GET são declaradas; não há backup/reversão.
- Search Console tem seus próprios limites de linhas e disponibilidade; filtros de métricas/ordenação locais referem-se à página obtida. O plugin não oferece solicitação genérica de indexação nem altera DNS.
- APIs sem validateOnly não simulam gravação como sucesso. Provisionamento GA exige aceite humano de termos. Customer Match e outras operações assíncronas exigem acompanhamento pela API.
- Tag GA4, consentimento, ponte de eventos, agendamentos e Looker Studio permanecem fora do complemento, como no plano.

## Pacotes e reprodução

- `wp-mcp-google-fator3-0.2.0.zip`: instalável, somente plugin e documentação operacional.
- `wp-mcp-google-fator3-src-0.2.0.zip`: plugin completo, testes/fixtures, plano original, skill, catálogo, manifesto de schemas, evidências e runners de integração.
- `wp-mcp-google-fator3-0.2.0-relatorio.md`: este relatório.

No pacote-fonte: `composer install` no diretório do plugin para as dependências de desenvolvimento; `composer test` e `composer lint`. A versão executada de PHPUnit foi 9.6.29. Reprodução de WordPress em `integration/INTEGRACAO-WORDPRESS.md`. O runner de mutações altera os quatro arquivos um por vez, testa e restaura; usar em checkout de desenvolvimento.

SHA256 do ZIP instalável: `c2907eb3822e71057a892c7a2c7a561d58f85bd1349c85382586327b8f988cea`.

Fontes recebidas:

| Arquivo | SHA256 |
|---|---|
| wp-mcp-google-fator3-src-0.1.0.zip | `e0e646f5d9e1e985988b6e40f5a78e4c9e3d86bbccfe1b18972db577fc544204` |
| plano-wp-mcp-google-0.2.0.md | `a3ba7985f6643451bc6d85fbaf97b54231ddd654e9f7a51499f9cf1ea1ce29d9` |

Os documentos oficiais e suas revisões/fontes/hash constam em `tests/fixtures/discovery/sources.json`. As cifras usadas no laboratório eram sintéticas; nenhum segredo de produção integra os arquivos entregues.
