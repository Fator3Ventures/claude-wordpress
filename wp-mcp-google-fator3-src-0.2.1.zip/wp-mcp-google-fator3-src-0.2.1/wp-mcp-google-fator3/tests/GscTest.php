<?php
/** Regressões Search Console/Site Verification com descoberta oficial e HTTP simulado. */
declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\SearchConsole\Abilities as GscAbilities;
use Fator3\McpGoogle\SearchConsole\Api;
use Fator3\McpGoogle\SiteVerification\Abilities as VerificationAbilities;
use PHPUnit\Framework\TestCase;

require_once dirname( __DIR__ ) . '/includes/Generic/Discovery.php';
require_once dirname( __DIR__ ) . '/includes/Generic/ExecuteAction.php';
require_once dirname( __DIR__ ) . '/includes/Unified/Accounts.php';
require_once dirname( __DIR__ ) . '/includes/SearchConsole/Api.php';
require_once dirname( __DIR__ ) . '/includes/SearchConsole/Abilities.php';
require_once dirname( __DIR__ ) . '/includes/SiteVerification/Abilities.php';

final class GscTest extends TestCase {
	private const SITE = 'https://example.test/';
	private const SITE_PATH = 'webmasters/v3/sites/https%3A%2F%2Fexample.test%2F';

	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps'] = true;
		$GLOBALS['f3_test_user'] = 1;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, false );
		Options::set( Options::ADS_ENABLED, false );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'gsc-test.apps.googleusercontent.com' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'gsc-client-secret-for-tests' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'gsc-refresh-token-for-tests' );
		Options::set( Options::OAUTH_SCOPES, array( 'https://www.googleapis.com/auth/webmasters', 'https://www.googleapis.com/auth/siteverification' ) );
		foreach ( array( 'search-console' => 'searchconsole-v1', 'site-verification' => 'siteverification-v1' ) as $api => $file ) {
			$document = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/' . $file . '.json' ), true );
			set_transient( Discovery::cache_key( $api ), $document, 86400 );
		}
		for ( $i = 0; $i < 3; ++$i ) {
			FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'fake-gsc-access-token', 'expires_in' => 3600 ) );
		}
		GscAbilities::register();
		VerificationAbilities::register();
	}

	private function execute( string $name, array $input = array() ): array {
		$ability = wp_get_ability( $name );
		$this->assertNotNull( $ability );
		return $ability->execute( $input );
	}

	private function ok( array $result ): void {
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
	}

	private function api_requests(): array {
		return array_values( array_filter( FakeHttp::$requests, static function ( array $request ): bool { return false === strpos( $request['url'], 'oauth2.googleapis.com/token' ); } ) );
	}

	private function body(): array {
		$request = FakeHttp::last();
		return json_decode( (string) ( $request['body'] ?? '' ), true ) ?? array();
	}

	private function dates(): array {
		return array( 'from' => '2026-08-01', 'to' => '2026-08-07' );
	}

	public function test_all_thirteen_routes_have_correct_annotations_and_permissions(): void {
		$read = array( 'gsc/list-sites', 'gsc/get-site', 'gsc/query', 'gsc/list-sitemaps', 'gsc/inspect-url', 'siteverification/get-token', 'siteverification/list' );
		$write = array( 'gsc/submit-sitemap', 'gsc/delete-sitemap', 'gsc/add-site', 'gsc/delete-site', 'siteverification/verify', 'siteverification/update-owners' );
		foreach ( array_merge( $read, $write ) as $name ) {
			$ability = wp_get_ability( $name );
			$this->assertNotNull( $ability );
			$readonly = in_array( $name, $read, true );
			$this->assertSame( $readonly, $ability->get_meta()['annotations']['readonly'] );
			$this->assertSame( ! $readonly, $ability->get_meta()['annotations']['destructive'] );
			$this->assertTrue( $ability->check_permissions() );
			$GLOBALS['f3_test_caps'] = false;
			$this->assertFalse( $ability->check_permissions() );
			$result = $this->execute( $name );
			$this->assertFalse( $result['success'] );
			$GLOBALS['f3_test_caps'] = true;
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_global_switch_still_blocks_new_services(): void {
		Options::set( Options::ENABLED, false );
		foreach ( array( 'gsc/list-sites', 'siteverification/list' ) as $name ) {
			$this->assertFalse( wp_get_ability( $name )->check_permissions() );
			$this->assertFalse( $this->execute( $name )['success'] );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_list_sites_and_get_site_preserve_exact_identifiers(): void {
		FakeHttp::push( 'webmasters/v3/sites', 200, array( 'siteEntry' => array( array( 'siteUrl' => self::SITE, 'permissionLevel' => 'SITE_OWNER' ), array( 'siteUrl' => 'sc-domain:example.test', 'permissionLevel' => 'SITE_FULL_USER' ) ) ) );
		$list = $this->execute( 'gsc/list-sites' );
		$this->ok( $list );
		$this->assertSame( 2, $list['count'] );
		$this->assertSame( 'search-console', $list['sites'][0]['connector'] );
		$this->assertSame( 'sc-domain:example.test', $list['sites'][1]['account_id'] );
		FakeHttp::push( self::SITE_PATH, 200, array( 'siteUrl' => self::SITE, 'permissionLevel' => 'SITE_OWNER' ) );
		$result = $this->execute( 'gsc/get-site', array( 'site_url' => self::SITE ) );
		$this->ok( $result );
		$this->assertSame( 'SITE_OWNER', $result['data']['permissionLevel'] );
		$this->assertSame( 'https://searchconsole.googleapis.com/' . self::SITE_PATH, FakeHttp::last()['url'] );
	}

	public function test_query_body_uses_real_discovery_enums_and_offset_and_keeps_metrics(): void {
		FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'keys' => array( '2026-08-01', 'MOBILE' ), 'clicks' => 3, 'impressions' => 10, 'ctr' => 0.3, 'position' => 2.75 ) ), 'metadata' => array( 'first_incomplete_date' => '2026-08-01' ), 'responseAggregationType' => 'AUTO' ) );
		$result = $this->execute( 'gsc/query', array( 'site_url' => self::SITE, 'date_range' => $this->dates(), 'dimensions' => array( 'date', 'device' ), 'type' => 'googleNews', 'data_state' => 'all', 'aggregation_type' => 'auto', 'row_limit' => 1, 'start_row' => 99, 'filters' => array( array( 'field' => 'country', 'operator' => 'eq', 'value' => 'BRA' ) ) ) );
		$this->ok( $result );
		$this->assertSame( array( '2026-08-01', 'MOBILE', 3, 10, 0.3, 2.75 ), $result['rows'][0] );
		$this->assertTrue( $result['truncated'] );
		$this->assertSame( 100, $result['next_start_row'] );
		$this->assertSame( '2026-08-01', $result['metadata']['first_incomplete_date'] );
		$body = $this->body();
		$this->assertSame( array( 'DATE', 'DEVICE' ), $body['dimensions'] );
		$this->assertSame( 99, $body['startRow'] );
		$this->assertSame( 'GOOGLE_NEWS', $body['type'] );
		$this->assertSame( 'ALL', $body['dataState'] );
		$this->assertSame( array( 'dimension' => 'COUNTRY', 'operator' => 'EQUALS', 'expression' => 'BRA' ), $body['dimensionFilterGroups'][0]['filters'][0] );
	}

	public function test_query_body_rejects_invalid_dates_limits_offsets_and_incompatible_aggregation_without_http(): void {
		foreach ( array( array( 'row_limit' => 25001 ), array( 'row_limit' => 0 ), array( 'row_limit' => true ), array( 'row_limit' => 1.2 ), array( 'start_row' => -1 ), array( 'dimensions' => array( 'unknown' ) ), array( 'dimensions' => array( 'hour' ) ), array( 'dimensions' => array( 'page' ), 'aggregation_type' => 'byProperty' ), array( 'date_range' => array( 'from' => '2026-02-31', 'to' => '2026-03-03' ) ) ) as $invalid ) {
			$result = Api::body( $invalid + array( 'date_range' => $this->dates() ) );
			$this->assertTrue( is_wp_error( $result ), (string) wp_json_encode( $invalid ) );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_native_filters_normalize_camel_case_and_reject_or(): void {
		$result = Api::body( array( 'date_range' => $this->dates(), 'dimension_filter_groups' => array( array( 'group_type' => 'and', 'filters' => array( array( 'dimension' => 'search_appearance', 'operator' => 'notContains', 'expression' => 'RICH' ) ) ) ) ) );
		$this->assertFalse( is_wp_error( $result ) );
		$this->assertSame( 'SEARCH_APPEARANCE', $result['dimensionFilterGroups'][0]['filters'][0]['dimension'] );
		$this->assertSame( 'NOT_CONTAINS', $result['dimensionFilterGroups'][0]['filters'][0]['operator'] );
		$invalid = Api::body( array( 'date_range' => $this->dates(), 'dimension_filter_groups' => array( array( 'groupType' => 'or', 'filters' => array() ) ) ) );
		$this->assertTrue( is_wp_error( $invalid ) );
	}

	public function test_hour_dimension_requires_hourly_all(): void {
		$body = Api::body( array( 'date_range' => $this->dates(), 'dimensions' => array( 'hour' ), 'data_state' => 'hourly_all' ) );
		$this->assertFalse( is_wp_error( $body ) );
		$this->assertSame( 'HOURLY_ALL', $body['dataState'] );
	}

	public function test_list_sitemaps_and_inspect_url_call_correct_methods(): void {
		FakeHttp::push( '/sitemaps', 200, array( 'sitemap' => array( array( 'path' => self::SITE . 'sitemap.xml' ) ) ) );
		$result = $this->execute( 'gsc/list-sitemaps', array( 'site_url' => self::SITE, 'sitemap_index' => self::SITE . 'index.xml' ) );
		$this->ok( $result );
		$this->assertStringContainsString( 'sitemapIndex=https%3A%2F%2Fexample.test%2Findex.xml', FakeHttp::last()['url'] );
		FakeHttp::push( '/urlInspection/index:inspect', 200, array( 'inspectionResult' => array( 'indexStatusResult' => array( 'verdict' => 'PASS' ) ) ) );
		$result = $this->execute( 'gsc/inspect-url', array( 'site_url' => self::SITE, 'inspection_url' => self::SITE . 'article', 'language_code' => 'pt-BR' ) );
		$this->ok( $result );
		$this->assertSame( 'POST', FakeHttp::last()['method'] );
		$this->assertSame( array( 'siteUrl' => self::SITE, 'inspectionUrl' => self::SITE . 'article', 'languageCode' => 'pt-BR' ), $this->body() );
	}

	public function test_all_four_gsc_writes_take_real_before_after_snapshots(): void {
		foreach ( array( 'submit-sitemap' => 'PUT', 'delete-sitemap' => 'DELETE', 'add-site' => 'PUT', 'delete-site' => 'DELETE' ) as $name => $verb ) {
			FakeHttp::$requests = array();
			$input = array( 'site_url' => self::SITE );
			$sitemap = false !== strpos( $name, 'sitemap' );
			$path = self::SITE_PATH;
			if ( $sitemap ) {
				$input['sitemap_url'] = self::SITE . 'sitemap.xml';
				$path .= '/sitemaps/https%3A%2F%2Fexample.test%2Fsitemap.xml';
			}
			FakeHttp::push( $path, 200, array( 'marker' => 'before-' . $name ) );
			FakeHttp::push( $path, 204, '' );
			FakeHttp::push( $path, 'DELETE' === $verb ? 404 : 200, 'DELETE' === $verb ? array( 'error' => array( 'code' => 404, 'message' => 'not found', 'status' => 'NOT_FOUND' ) ) : array( 'marker' => 'after-' . $name ) );
			$result = $this->execute( 'gsc/' . $name, $input );
			$this->ok( $result );
			$requests = $this->api_requests();
			$this->assertCount( 3, $requests );
			$this->assertSame( array( 'GET', $verb, 'GET' ), array_column( $requests, 'method' ) );
			if ( 'PUT' === $verb ) {
				$this->assertSame( '0', $requests[1]['headers']['Content-Length'] ?? null );
				$this->assertSame( '', $requests[1]['body'] );
				$this->assertArrayNotHasKey( 'Content-Type', $requests[1]['headers'] );
			}
			$audit = Audit::recent( 1 )[0];
			$this->assertSame( 'before-' . $name, $audit['extra']['before']['resource']['marker'] );
			$this->assertSame( 'DELETE' !== $verb, $audit['extra']['after']['exists'] );
			$this->assertSame( 'ok', $audit['extra']['status'] );
		}
	}

	public function test_gsc_write_error_is_not_retried_and_is_audited(): void {
		FakeHttp::push( self::SITE_PATH, 200, array( 'siteUrl' => self::SITE ) );
		FakeHttp::push( self::SITE_PATH, 503, array( 'error' => array( 'message' => 'Service temporarily unavailable', 'status' => 'UNAVAILABLE' ) ) );
		$result = $this->execute( 'gsc/delete-site', array( 'site_url' => self::SITE ) );
		$this->assertFalse( $result['success'] );
		$this->assertCount( 2, $this->api_requests() );
		$extra = Audit::recent( 1 )[0]['extra'];
		$this->assertTrue( $extra['before']['available'] );
		$this->assertFalse( $extra['after']['available'] );
		$this->assertSame( 'erro', $extra['status'] );
	}

	public function test_dry_run_refused_for_every_write_without_http_and_audited(): void {
		foreach ( array( 'gsc/submit-sitemap', 'gsc/delete-sitemap', 'gsc/add-site', 'gsc/delete-site', 'siteverification/verify', 'siteverification/update-owners' ) as $name ) {
			$input = array( 'dry_run' => true );
			if ( 0 === strpos( $name, 'gsc/' ) ) {
				$input['site_url'] = self::SITE;
			}
			$result = $this->execute( $name, $input );
			$this->assertFalse( $result['success'] );
			$this->assertSame( 'f3_google_dry_run_unsupported', $result['error_code'] );
			$this->assertTrue( Audit::recent( 1 )[0]['extra']['dry_run'] );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_siteverification_get_token_uses_official_host_path_and_returns_token(): void {
		FakeHttp::push( '/siteVerification/v1/token', 200, array( 'method' => 'META', 'token' => '<meta name="google-site-verification" content="verification-test-token">' ) );
		$result = $this->execute( 'siteverification/get-token', array( 'site' => array( 'type' => 'SITE', 'identifier' => self::SITE ), 'verification_method' => 'META' ) );
		$this->ok( $result );
		$this->assertStringContainsString( 'verification-test-token', $result['token'] );
		$this->assertSame( 'https://www.googleapis.com/siteVerification/v1/token', FakeHttp::last()['url'] );
		$this->assertSame( 'META', $this->body()['verificationMethod'] );
		$this->assertArrayNotHasKey( 'before', Audit::recent( 1 )[0]['extra'] );
		$this->assertStringNotContainsString( 'verification-test-token', (string) wp_json_encode( Audit::recent() ) );
	}

	public function test_siteverification_dns_alias_and_method_type_validation(): void {
		FakeHttp::push( '/siteVerification/v1/token', 200, array( 'method' => 'DNS_TXT', 'token' => 'google-site-verification=test' ) );
		$result = $this->execute( 'siteverification/get-token', array( 'site' => array( 'type' => 'INET_DOMAIN', 'identifier' => 'example.test' ), 'verification_method' => 'DNS' ) );
		$this->ok( $result );
		$this->assertSame( 'DNS_TXT', $this->body()['verificationMethod'] );
		$before = FakeHttp::count();
		$result = $this->execute( 'siteverification/get-token', array( 'site' => array( 'type' => 'INET_DOMAIN', 'identifier' => 'example.test' ), 'verification_method' => 'META' ) );
		$this->assertFalse( $result['success'] );
		$this->assertSame( $before, FakeHttp::count() );
	}

	public function test_siteverification_list_and_verify_capture_resource_state(): void {
		FakeHttp::push( '/siteVerification/v1/webResource', 200, array( 'items' => array() ) );
		$this->ok( $this->execute( 'siteverification/list' ) );
		FakeHttp::push( '/siteVerification/v1/webResource', 200, array( 'items' => array() ) );
		FakeHttp::push( '/siteVerification/v1/webResource', 200, array( 'id' => 'verified-example', 'site' => array( 'type' => 'SITE', 'identifier' => self::SITE ), 'owners' => array( 'owner@example.test' ) ) );
		$result = $this->execute( 'siteverification/verify', array( 'site' => array( 'type' => 'SITE', 'identifier' => self::SITE ), 'verification_method' => 'FILE' ) );
		$this->ok( $result );
		$this->assertStringContainsString( 'verificationMethod=FILE', FakeHttp::last()['url'] );
		$this->assertSame( 'POST', FakeHttp::last()['method'] );
		$extra = Audit::recent( 1 )[0]['extra'];
		$this->assertFalse( $extra['before']['exists'] );
		$this->assertSame( 'verified-example', $extra['after']['resource']['id'] );
	}

	public function test_siteverification_update_owners_preserves_site_and_audits_previous_owners(): void {
		$site = array( 'type' => 'SITE', 'identifier' => self::SITE );
		FakeHttp::push( '/siteVerification/v1/webResource/verified%2Fexample', 200, array( 'id' => 'verified/example', 'site' => $site, 'owners' => array( 'old@example.test' ) ) );
		FakeHttp::push( '/siteVerification/v1/webResource/verified%2Fexample', 200, array( 'id' => 'verified/example', 'site' => $site, 'owners' => array( 'old@example.test', 'new@example.test' ) ) );
		$result = $this->execute( 'siteverification/update-owners', array( 'id' => 'verified/example', 'owners' => array( 'old@example.test', 'new@example.test' ) ) );
		$this->ok( $result );
		$this->assertSame( 'PUT', FakeHttp::last()['method'] );
		$this->assertSame( $site, $this->body()['site'] );
		$this->assertSame( array( 'old@example.test' ), Audit::recent( 1 )[0]['extra']['before']['resource']['owners'] );
	}

	public function test_unified_comparison_and_multiple_accounts_keep_ctr_and_position_separate(): void {
		$native = array( 'rows' => array( array( 'keys' => array( '2026-08-01' ), 'clicks' => 2, 'impressions' => 20, 'ctr' => 0.1, 'position' => 8.25 ) ) );
		for ( $i = 0; $i < 4; ++$i ) {
			FakeHttp::push( '/searchAnalytics/query', 200, $native );
		}
		$result = Api::unified( array( 'accounts' => array( self::SITE, 'sc-domain:example.test' ), 'date_range' => $this->dates(), 'compare_date_range' => 'previous_period', 'dimensions' => array( 'date' ), 'metrics' => array( 'clicks', 'ctr', 'position' ) ) );
		$this->ok( $result );
		$this->assertSame( 4, $result['row_count'] );
		$this->assertSame( array( 'date_range_name', 'account_id', 'account_name', 'date', 'clicks', 'ctr', 'position' ), array_column( $result['columns'], 'id' ) );
		$this->assertSame( array( 'current', self::SITE, self::SITE, '2026-08-01', 2, 0.1, 8.25 ), $result['rows'][0] );
		$this->assertSame( 'previous', $result['rows'][1][0] );
		$this->assertSame( '2026-07-25', $result['compare_date_range']['from'] );
		$this->assertSame( 'America/Los_Angeles', $result['data_timezone'] );
		$this->assertCount( 2, $result['accounts'] );
	}

	public function test_unified_filters_and_ordering_are_honest_about_page_scope(): void {
		FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'keys' => array( 'b' ), 'clicks' => 1, 'impressions' => 10, 'ctr' => 0.1, 'position' => 5 ), array( 'keys' => array( 'c' ), 'clicks' => 3, 'impressions' => 10, 'ctr' => 0.3, 'position' => 7 ), array( 'keys' => array( 'a' ), 'clicks' => 2, 'impressions' => 10, 'ctr' => 0.2, 'position' => 9 ) ) ) );
		$result = Api::unified( array( 'accounts' => array( self::SITE ), 'date_range' => $this->dates(), 'dimensions' => array( 'query' ), 'metrics' => array( 'clicks' ), 'filters' => array( array( 'field' => 'clicks', 'operator' => 'gt', 'value' => 1 ), array( 'field' => 'page', 'operator' => 'begins_with', 'value' => 'https://example.test/a+b' ) ), 'order_by' => array( 'field' => 'query', 'direction' => 'asc' ) ) );
		$this->ok( $result );
		$this->assertSame( array( array( 'a', 2 ), array( 'c', 3 ) ), $result['rows'] );
		$this->assertStringContainsString( 'somente à página', implode( ' ', $result['warnings'] ) );
		$this->assertSame( '^https\://example\.test/a\+b', $this->body()['dimensionFilterGroups'][0]['filters'][0]['expression'] );
		$this->assertCount( 1, $this->body()['dimensionFilterGroups'][0]['filters'] );
	}

	public function test_empty_is_success_but_upstream_failure_is_not_zero(): void {
		$input = array( 'accounts' => array( self::SITE ), 'date_range' => $this->dates(), 'metrics' => array( 'clicks' ) );
		FakeHttp::push( '/searchAnalytics/query', 200, array() );
		$empty = Api::unified( $input );
		$this->ok( $empty );
		$this->assertSame( 0, $empty['row_count'] );
		FakeHttp::push( '/searchAnalytics/query', 403, array( 'error' => array( 'code' => 403, 'message' => 'User does not have sufficient permission for site', 'errors' => array( array( 'reason' => 'insufficientPermissions' ) ) ) ) );
		$failed = Api::unified( $input );
		$this->assertFalse( $failed['success'] );
		$this->assertSame( 'f3_google_query_failed', $failed['error_code'] );
		$this->assertNotEmpty( $failed['warnings'] );
	}

	public function test_unified_wildcard_enumerates_all_accessible_properties(): void {
		FakeHttp::push( 'webmasters/v3/sites', 200, array( 'siteEntry' => array( array( 'siteUrl' => self::SITE ), array( 'siteUrl' => 'sc-domain:example.test' ) ) ) );
		FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'clicks' => 2, 'impressions' => 10, 'ctr' => 0.2, 'position' => 3 ) ) ) );
		FakeHttp::push( '/searchAnalytics/query', 200, array( 'rows' => array( array( 'clicks' => 4, 'impressions' => 10, 'ctr' => 0.4, 'position' => 7 ) ) ) );
		$result = Api::unified( array( 'accounts' => array( '*' ), 'date_range' => 'last_7_days', 'metrics' => array( 'clicks', 'ctr' ) ) );
		$this->ok( $result );
		$this->assertCount( 2, $result['accounts'] );
		$this->assertCount( 2, $result['rows'] );
		$this->assertSame( 0.2, $result['rows'][0][3] );
		$this->assertSame( 0.4, $result['rows'][1][3] );
	}

	public function test_traversal_and_external_destination_do_not_escape_fixed_api_host(): void {
		$result = $this->execute( 'gsc/get-site', array( 'site_url' => 'https://example.test/%252e%252e/secrets' ) );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 0, FakeHttp::count() );
		foreach ( array( 'file:///etc/passwd', 'https://user:password@example.test/', 'sc-domain:example.test/path' ) as $site ) {
			$this->assertTrue( is_wp_error( Api::site( $site ) ) );
		}
	}
}
