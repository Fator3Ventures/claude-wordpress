<?php
/**
 * Validador de JSON Schema mínimo, com o comportamento do WordPress 6.9+.
 *
 * Existe porque o polyfill da Abilities API carregado nos testes (o mesmo que o
 * WP MCP Ultimate traz para o WordPress 6.4–6.8) **não valida nada**: ele chama
 * o `execute_callback` com a entrada como veio e devolve a saída como veio. O
 * núcleo do WordPress 6.9, onde este plugin vai rodar de verdade, faz o
 * contrário — passa a entrada por `rest_validate_value_from_schema()` ANTES de
 * executar e a saída pelo mesmo validador DEPOIS, transformando uma saída que
 * não bate com o `output_schema` num `WP_Error` que o agente recebe no lugar do
 * relatório.
 *
 * Ou seja: sem este arquivo, a suíte inteira roda num ambiente mais permissivo
 * do que o de produção, e um esquema errado só apareceria no site do cliente.
 *
 * Não é uma implementação completa de JSON Schema — é a reprodução das regras
 * que o núcleo aplica nos casos que este plugin usa, com as três armadilhas que
 * importam:
 *
 *  1. `rest_is_integer()` aceita string numérica ("100" É um integer válido),
 *     mas NÃO converte — o callback continua recebendo a string.
 *  2. `oneOf` exige casar com EXATAMENTE um ramo. Como "123456" é string E
 *     integer para o núcleo, um `oneOf: [string, integer]` recusa toda string
 *     numérica com "matches 2 schemas".
 *  3. `''` conta como objeto e como array válidos (o núcleo os converte em
 *     vazio), o que cria a mesma ambiguidade de `oneOf` com `[string, object]`.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

final class JsonSchema {

	/** Tipos que o núcleo aceita em `type`. */
	public const TYPES = array( 'array', 'object', 'string', 'number', 'integer', 'boolean', 'null' );

	/**
	 * @param mixed  $value  Valor a validar.
	 * @param array  $schema Esquema.
	 * @param string $param  Nome do parâmetro, para a mensagem.
	 * @return true|string `true` quando válido; a razão da recusa quando não.
	 */
	public static function validate( $value, array $schema, string $param = 'valor' ) {
		if ( isset( $schema['anyOf'] ) && is_array( $schema['anyOf'] ) ) {
			$matched = self::count_matches( $value, $schema['anyOf'], $param );

			if ( 0 === $matched ) {
				return $param . ' não casa com nenhum esquema de anyOf';
			}
		}

		if ( isset( $schema['oneOf'] ) && is_array( $schema['oneOf'] ) ) {
			$matched = self::count_matches( $value, $schema['oneOf'], $param );

			if ( 0 === $matched ) {
				return $param . ' não casa com nenhum esquema de oneOf';
			}

			if ( $matched > 1 ) {
				return $param . ' casa com ' . $matched . ' esquemas de oneOf; precisa casar com exatamente um';
			}
		}

		if ( ! isset( $schema['type'] ) ) {
			// O núcleo dispara `_doing_it_wrong` e segue em frente; para os
			// testes, um esquema sem `type` só é aceitável quando anyOf/oneOf
			// resolveu o tipo.
			return isset( $schema['anyOf'] ) || isset( $schema['oneOf'] )
				? true
				: $param . ' não declara "type" (o WordPress 6.9 dispara _doing_it_wrong)';
		}

		$type = $schema['type'];

		if ( is_array( $type ) ) {
			$best = self::best_type( $value, $type );

			if ( '' === $best ) {
				return $param . ' não é do tipo ' . implode( ',', $type );
			}

			$type = $best;
		}

		if ( ! in_array( $type, self::TYPES, true ) ) {
			return $param . ': tipo desconhecido "' . (string) $type . '"';
		}

		if ( ! self::is_type( $value, (string) $type ) ) {
			return $param . ' não é do tipo ' . (string) $type;
		}

		if ( isset( $schema['enum'] ) && is_array( $schema['enum'] ) && ! self::in_enum( $value, $schema['enum'] ) ) {
			return $param . ' não é um dos valores de enum (' . implode( ', ', array_map( 'strval', $schema['enum'] ) ) . ')';
		}

		if ( 'object' === $type ) {
			return self::validate_object( $value, $schema, $param );
		}

		if ( 'array' === $type ) {
			return self::validate_array( $value, $schema, $param );
		}

		return true;
	}

	/**
	 * @param mixed  $value    Valor.
	 * @param array  $branches Ramos de anyOf/oneOf.
	 * @param string $param    Nome do parâmetro.
	 */
	private static function count_matches( $value, array $branches, string $param ): int {
		$matched = 0;

		foreach ( $branches as $branch ) {
			if ( is_array( $branch ) && true === self::validate( $value, $branch, $param ) ) {
				++$matched;
			}
		}

		return $matched;
	}

	/**
	 * Cópia da regra de `rest_get_best_type_for_value()`.
	 *
	 * @param mixed    $value Valor.
	 * @param string[] $types Tipos declarados, na ordem em que aparecem.
	 */
	private static function best_type( $value, array $types ): string {
		// Array e objeto aceitam string vazia, mas a melhor resposta para ''
		// continua sendo string quando ela está na lista.
		if ( '' === $value && in_array( 'string', $types, true ) ) {
			return 'string';
		}

		foreach ( $types as $type ) {
			if ( is_string( $type ) && self::is_type( $value, $type ) ) {
				return $type;
			}
		}

		return '';
	}

	/**
	 * @param mixed  $value Valor.
	 * @param string $type  Tipo do JSON Schema.
	 */
	private static function is_type( $value, string $type ): bool {
		switch ( $type ) {
			case 'null':
				return null === $value;

			case 'number':
				return is_numeric( $value );

			case 'integer':
				// rest_is_integer(): string numérica inteira também passa.
				return is_numeric( $value ) && round( (float) $value ) === (float) $value;

			case 'boolean':
				// rest_is_boolean(): aceita as formas que uma query string produz.
				if ( is_bool( $value ) ) {
					return true;
				}

				if ( is_int( $value ) ) {
					return in_array( $value, array( 0, 1 ), true );
				}

				return is_string( $value )
					&& in_array( strtolower( $value ), array( '0', '1', 'true', 'false' ), true );

			case 'string':
				return is_string( $value );

			case 'array':
				// rest_is_array(): array de índices numéricos, ou um escalar
				// (que o núcleo trata como lista separada por vírgulas).
				if ( is_scalar( $value ) ) {
					return true;
				}

				if ( ! is_array( $value ) ) {
					return false;
				}

				return array() === $value || array_keys( $value ) === range( 0, count( $value ) - 1 );

			case 'object':
				// rest_is_object(): '' vira objeto vazio; qualquer array serve.
				return '' === $value || is_array( $value ) || $value instanceof \stdClass;
		}

		return false;
	}

	/**
	 * @param mixed $value Valor.
	 * @param array $enum  Valores aceitos.
	 */
	private static function in_enum( $value, array $enum ): bool {
		foreach ( $enum as $candidate ) {
			if ( $candidate === $value ) {
				return true;
			}

			if ( is_scalar( $candidate ) && is_scalar( $value ) && (string) $candidate === (string) $value ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param mixed  $value  Valor.
	 * @param array  $schema Esquema do objeto.
	 * @param string $param  Nome do parâmetro.
	 * @return true|string
	 */
	private static function validate_object( $value, array $schema, string $param ) {
		if ( '' === $value ) {
			$value = array();
		}

		if ( $value instanceof \stdClass ) {
			$value = (array) $value;
		}

		if ( ! is_array( $value ) ) {
			return $param . ' não é um objeto';
		}

		$properties = isset( $schema['properties'] ) && is_array( $schema['properties'] )
			? $schema['properties']
			: array();

		foreach ( (array) ( $schema['required'] ?? array() ) as $required ) {
			if ( ! array_key_exists( (string) $required, $value ) ) {
				return $param . ': falta a propriedade obrigatória "' . (string) $required . '"';
			}
		}

		foreach ( $value as $key => $item ) {
			$key = (string) $key;

			if ( isset( $properties[ $key ] ) && is_array( $properties[ $key ] ) ) {
				$result = self::validate( $item, $properties[ $key ], $param . '.' . $key );

				if ( true !== $result ) {
					return $result;
				}

				continue;
			}

			if ( array_key_exists( 'additionalProperties', $schema ) && false === $schema['additionalProperties'] ) {
				return $param . ': "' . $key . '" não é uma propriedade declarada (additionalProperties=false)';
			}
		}

		return true;
	}

	/**
	 * @param mixed  $value  Valor.
	 * @param array  $schema Esquema da lista.
	 * @param string $param  Nome do parâmetro.
	 * @return true|string
	 */
	private static function validate_array( $value, array $schema, string $param ) {
		if ( is_scalar( $value ) ) {
			// Como o núcleo: escalar vira lista separada por vírgulas.
			$value = '' === $value ? array() : array_map( 'trim', explode( ',', (string) $value ) );
		}

		if ( ! is_array( $value ) ) {
			return $param . ' não é uma lista';
		}

		if ( ! isset( $schema['items'] ) || ! is_array( $schema['items'] ) ) {
			return true;
		}

		foreach ( $value as $index => $item ) {
			$result = self::validate( $item, $schema['items'], $param . '[' . (string) $index . ']' );

			if ( true !== $result ) {
				return $result;
			}
		}

		return true;
	}
}
