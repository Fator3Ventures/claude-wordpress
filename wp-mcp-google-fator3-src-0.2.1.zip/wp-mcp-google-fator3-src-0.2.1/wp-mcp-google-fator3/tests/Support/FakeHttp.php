<?php
/**
 * Respostas HTTP enlatadas.
 *
 * Intercepta em `pre_http_request`, o mesmo ponto que o WordPress usa, então o
 * caminho exercitado é o de produção inteiro — inclusive a montagem de
 * cabeçalhos e do corpo. O que ficou registrado em `$requests` é o que o
 * plugin realmente teria mandado para a Google.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

final class FakeHttp {

	/** @var array<int,array{match:string,response:array}> Fila de respostas. */
	public static array $queue = array();

	/** @var array<int,array{url:string,method:string,body:mixed,headers:array}> */
	public static array $requests = array();

	public static function install(): void {
		add_filter( 'pre_http_request', array( self::class, 'handle' ), 10, 3 );
	}

	public static function reset(): void {
		self::$queue    = array();
		self::$requests = array();
	}

	/**
	 * Enfileira uma resposta para a primeira URL que contiver $match.
	 *
	 * @param string $match   Trecho da URL ('*' casa com qualquer uma).
	 * @param int    $code    Código HTTP.
	 * @param mixed  $body    Array (vira JSON) ou string crua.
	 * @param array  $headers Cabeçalhos de resposta.
	 */
	public static function push( string $match, int $code, $body, array $headers = array() ): void {
		self::$queue[] = array(
			'match'    => $match,
			'response' => array(
				'response' => array(
					'code'    => $code,
					'message' => '',
				),
				'body'     => is_string( $body ) ? $body : (string) wp_json_encode( $body ),
				'headers'  => $headers,
			),
		);
	}

	/**
	 * @param mixed  $preempt Valor atual do curto-circuito.
	 * @param array  $args    Argumentos da requisição.
	 * @param string $url     URL chamada.
	 * @return array
	 */
	public static function handle( $preempt, $args = array(), $url = '' ) {
		self::$requests[] = array(
			'url'     => (string) $url,
			'method'  => (string) ( $args['method'] ?? 'GET' ),
			'body'    => $args['body'] ?? null,
			'headers' => (array) ( $args['headers'] ?? array() ),
		);

		foreach ( self::$queue as $index => $item ) {
			if ( '*' === $item['match'] || false !== strpos( (string) $url, $item['match'] ) ) {
				unset( self::$queue[ $index ] );

				return $item['response'];
			}
		}

		// Uma chamada sem resposta enfileirada é erro de teste, não sucesso
		// silencioso: 599 estoura em qualquer asserção de caminho feliz.
		return array(
			'response' => array(
				'code'    => 599,
				'message' => 'sem resposta enfileirada',
			),
			'body'     => (string) wp_json_encode(
				array(
					'error' => array(
						'code'    => 599,
						'message' => 'Nenhuma resposta enfileirada para ' . $url,
						'status'  => 'TEST_NO_CANNED_RESPONSE',
					),
				)
			),
			'headers'  => array(),
		);
	}

	public static function count(): int {
		return count( self::$requests );
	}

	/**
	 * @return array|null
	 */
	public static function last(): ?array {
		$last = end( self::$requests );

		return false === $last ? null : $last;
	}
}
