<?php
/**
 * WordPress mínimo em memória, para rodar o plugin sem WordPress.
 *
 * Não é um mock do WordPress: é o subconjunto exato de funções que este plugin
 * usa, com o mesmo contrato observável (curto-circuito de `pre_option_*`,
 * `pre_http_request` interceptando toda requisição, transients que expiram).
 * Se um arquivo do plugin passar a usar uma função nova, o stub dela entra
 * aqui — é assim que se sabe que a superfície de dependência cresceu.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

define( 'ABSPATH', dirname( __DIR__ ) . '/' );
define( 'WPINC', 'wp-includes' );
define( 'WP_CONTENT_DIR', dirname( __DIR__ ) . '/wp-content' );

$GLOBALS['f3_test_options']    = array();
$GLOBALS['f3_test_transients'] = array();
$GLOBALS['f3_test_hooks']      = array();
$GLOBALS['f3_test_caps']       = true;
$GLOBALS['f3_test_user_caps']  = array();
$GLOBALS['f3_test_user']       = 1;
$GLOBALS['f3_test_redirects']  = array();

/**
 * Redirecionamento no lugar de sair do processo.
 */
class F3_Test_Redirect extends \RuntimeException {

	public string $location;

	public function __construct( string $location ) {
		$this->location = $location;
		parent::__construct( 'redirect: ' . $location );
	}
}

/**
 * wp_die() no lugar de matar o processo.
 */
class F3_Test_Die extends \RuntimeException {
}

// -----------------------------------------------------------------------------
// WP_Error
// -----------------------------------------------------------------------------

class WP_Error {

	protected $errors = array();

	protected $error_data = array();

	public function __construct( $code = '', $message = '', $data = '' ) {
		if ( '' === $code ) {
			return;
		}

		$this->add( $code, $message, $data );
	}

	public function add( $code, $message = '', $data = '' ) {
		$this->errors[ $code ][] = $message;

		if ( '' !== $data && null !== $data ) {
			$this->error_data[ $code ] = $data;
		}
	}

	public function get_error_codes() {
		return array_keys( $this->errors );
	}

	public function get_error_code() {
		$codes = $this->get_error_codes();

		return $codes ? $codes[0] : '';
	}

	public function get_error_messages( $code = '' ) {
		if ( '' === $code ) {
			$all = array();
			foreach ( $this->errors as $messages ) {
				$all = array_merge( $all, $messages );
			}

			return $all;
		}

		return $this->errors[ $code ] ?? array();
	}

	public function get_error_message( $code = '' ) {
		if ( '' === $code ) {
			$code = $this->get_error_code();
		}

		$messages = $this->get_error_messages( $code );

		return $messages ? (string) $messages[0] : '';
	}

	public function get_error_data( $code = '' ) {
		if ( '' === $code ) {
			$code = $this->get_error_code();
		}

		return $this->error_data[ $code ] ?? null;
	}

	public function has_errors() {
		return ! empty( $this->errors );
	}
}

function is_wp_error( $thing ) {
	return $thing instanceof WP_Error;
}

// -----------------------------------------------------------------------------
// Hooks
// -----------------------------------------------------------------------------

function add_filter( $hook, $callback, $priority = 10, $accepted_args = 1 ) {
	$GLOBALS['f3_test_hooks'][ $hook ][ (int) $priority ][] = array(
		'cb'   => $callback,
		'args' => (int) $accepted_args,
	);

	return true;
}

function add_action( $hook, $callback, $priority = 10, $accepted_args = 1 ) {
	return add_filter( $hook, $callback, $priority, $accepted_args );
}

function remove_filter( $hook, $callback, $priority = 10 ) {
	$priority = (int) $priority;

	if ( ! isset( $GLOBALS['f3_test_hooks'][ $hook ][ $priority ] ) ) {
		return false;
	}

	foreach ( $GLOBALS['f3_test_hooks'][ $hook ][ $priority ] as $index => $entry ) {
		if ( $entry['cb'] === $callback ) {
			unset( $GLOBALS['f3_test_hooks'][ $hook ][ $priority ][ $index ] );

			return true;
		}
	}

	return false;
}

function remove_action( $hook, $callback, $priority = 10 ) {
	return remove_filter( $hook, $callback, $priority );
}

function has_filter( $hook, $callback = false ) {
	if ( empty( $GLOBALS['f3_test_hooks'][ $hook ] ) ) {
		return false;
	}

	foreach ( $GLOBALS['f3_test_hooks'][ $hook ] as $entries ) {
		if ( ! empty( $entries ) ) {
			return true;
		}
	}

	return false;
}

function has_action( $hook, $callback = false ) {
	return has_filter( $hook, $callback );
}

function apply_filters( $hook, $value = null, ...$rest ) {
	if ( empty( $GLOBALS['f3_test_hooks'][ $hook ] ) ) {
		return $value;
	}

	$by_priority = $GLOBALS['f3_test_hooks'][ $hook ];
	ksort( $by_priority );

	foreach ( $by_priority as $entries ) {
		foreach ( $entries as $entry ) {
			$args  = array_merge( array( $value ), $rest );
			$args  = array_slice( $args, 0, max( 1, $entry['args'] ) );
			$value = call_user_func_array( $entry['cb'], $args );
		}
	}

	return $value;
}

function do_action( $hook, ...$args ) {
	if ( empty( $GLOBALS['f3_test_hooks'][ $hook ] ) ) {
		return;
	}

	$by_priority = $GLOBALS['f3_test_hooks'][ $hook ];
	ksort( $by_priority );

	foreach ( $by_priority as $entries ) {
		foreach ( $entries as $entry ) {
			call_user_func_array( $entry['cb'], array_slice( $args, 0, $entry['args'] ) );
		}
	}
}

function __return_true() {
	return true;
}

function __return_false() {
	return false;
}

// -----------------------------------------------------------------------------
// Opções e transients
// -----------------------------------------------------------------------------

function get_option( $option, $default_value = false ) {
	// Mesmo contrato do WordPress: qualquer valor diferente de false
	// curto-circuita a leitura. É disto que depende a trava dos segredos.
	$pre = apply_filters( 'pre_option_' . $option, false, $option, $default_value );

	if ( false !== $pre ) {
		return $pre;
	}

	return array_key_exists( $option, $GLOBALS['f3_test_options'] )
		? $GLOBALS['f3_test_options'][ $option ]
		: $default_value;
}

function update_option( $option, $value, $autoload = null ) {
	$GLOBALS['f3_test_options'][ $option ] = $value;

	return true;
}

function add_option( $option, $value = '', $deprecated = '', $autoload = 'yes' ) {
	if ( array_key_exists( $option, $GLOBALS['f3_test_options'] ) ) {
		return false;
	}

	$GLOBALS['f3_test_options'][ $option ] = $value;

	return true;
}

function delete_option( $option ) {
	if ( ! array_key_exists( $option, $GLOBALS['f3_test_options'] ) ) {
		return false;
	}

	unset( $GLOBALS['f3_test_options'][ $option ] );

	return true;
}

function get_transient( $key ) {
	if ( ! isset( $GLOBALS['f3_test_transients'][ $key ] ) ) {
		return false;
	}

	$entry = $GLOBALS['f3_test_transients'][ $key ];

	if ( 0 !== $entry['expires'] && $entry['expires'] < time() ) {
		unset( $GLOBALS['f3_test_transients'][ $key ] );

		return false;
	}

	return $entry['value'];
}

function set_transient( $key, $value, $expiration = 0 ) {
	$GLOBALS['f3_test_transients'][ $key ] = array(
		'value'   => $value,
		'expires' => $expiration > 0 ? time() + (int) $expiration : 0,
	);

	return true;
}

function delete_transient( $key ) {
	unset( $GLOBALS['f3_test_transients'][ $key ] );

	return true;
}

// -----------------------------------------------------------------------------
// Usuário, salts, ambiente
// -----------------------------------------------------------------------------

function wp_salt( $scheme = 'auth' ) {
	return 'f3-test-salt-' . $scheme;
}

function current_user_can( $capability, ...$args ) {
	$caps = $GLOBALS['f3_test_caps'];

	if ( is_bool( $caps ) ) {
		return $caps;
	}

	return ! empty( $caps[ $capability ] );
}

/**
 * Capacidade de um usuário específico (não do atual).
 *
 * Usado pelo callback do OAuth para conferir que quem iniciou o fluxo ainda é
 * administrador. `$GLOBALS['f3_test_user_caps']` mapeia id => bool; quando um id
 * não está no mapa, vale a mesma resposta de `current_user_can()`.
 */
function user_can( $user, $capability, ...$args ) {
	$id = is_object( $user ) ? (int) ( $user->ID ?? 0 ) : (int) $user;

	if ( $id <= 0 ) {
		return false;
	}

	$map = $GLOBALS['f3_test_user_caps'] ?? array();
	if ( is_array( $map ) && array_key_exists( $id, $map ) ) {
		return (bool) $map[ $id ];
	}

	return current_user_can( $capability );
}

function is_user_logged_in() {
	return (int) $GLOBALS['f3_test_user'] > 0;
}

function get_current_user_id() {
	return (int) $GLOBALS['f3_test_user'];
}

function get_userdata( $user_id ) {
	if ( (int) $user_id <= 0 ) {
		return false;
	}

	return (object) array(
		'ID'         => (int) $user_id,
		'user_login' => 'usuario' . (int) $user_id,
	);
}

function get_bloginfo( $show = '' ) {
	if ( 'version' === $show ) {
		return '6.9';
	}

	return 'Site de teste';
}

function wp_timezone() {
	return new \DateTimeZone( 'America/Sao_Paulo' );
}

function current_time( $type = 'mysql', $gmt = 0 ) {
	if ( 'timestamp' === $type || 'U' === $type ) {
		return time();
	}

	$now = new \DateTimeImmutable( 'now', $gmt ? new \DateTimeZone( 'UTC' ) : wp_timezone() );

	return $now->format( 'mysql' === $type ? 'Y-m-d H:i:s' : $type );
}

function home_url( $path = '' ) {
	return 'https://exemplo.test' . $path;
}

function admin_url( $path = '' ) {
	return 'https://exemplo.test/wp-admin/' . ltrim( (string) $path, '/' );
}

function rest_url( $path = '' ) {
	return 'https://exemplo.test/wp-json/' . ltrim( (string) $path, '/' );
}

function plugin_dir_path( $file ) {
	return rtrim( dirname( (string) $file ), '/\\' ) . '/';
}

function plugin_basename( $file ) {
	return basename( dirname( (string) $file ) ) . '/' . basename( (string) $file );
}

function trailingslashit( $string ) {
	return rtrim( (string) $string, '/\\' ) . '/';
}

function wp_normalize_path( $path ) {
	return str_replace( '\\', '/', (string) $path );
}

function size_format( $bytes, $decimals = 0 ) {
	return number_format( (float) $bytes / 1024, (int) $decimals ) . ' KB';
}

function number_format_i18n( $number, $decimals = 0 ) {
	return number_format( (float) $number, (int) $decimals );
}

function wp_rand( $min = 0, $max = 0 ) {
	return $max > $min ? random_int( (int) $min, (int) $max ) : random_int( 0, PHP_INT_MAX );
}

function wp_generate_password( $length = 12, $special_chars = true, $extra_special_chars = false ) {
	$chars    = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$password = '';

	for ( $i = 0; $i < (int) $length; $i++ ) {
		$password .= $chars[ random_int( 0, strlen( $chars ) - 1 ) ];
	}

	return $password;
}

function absint( $value ) {
	return abs( (int) $value );
}

function is_email( $email ) {
	return (bool) filter_var( (string) $email, FILTER_VALIDATE_EMAIL );
}

/**
 * `uninstall.php` pergunta antes de apagar transients de rede também em
 * `sitemeta`. Controlável por teste; `false` por padrão, como a maioria dos
 * sites.
 */
function is_multisite() {
	return ! empty( $GLOBALS['f3_test_multisite'] );
}

// -----------------------------------------------------------------------------
// Saneamento e escape
// -----------------------------------------------------------------------------

function wp_unslash( $value ) {
	if ( is_array( $value ) ) {
		return array_map( 'wp_unslash', $value );
	}

	return is_string( $value ) ? stripslashes( $value ) : $value;
}

function sanitize_text_field( $str ) {
	$str = (string) $str;
	$str = strip_tags( $str );
	$str = preg_replace( '/[\r\n\t ]+/', ' ', $str );

	return trim( (string) $str );
}

function sanitize_textarea_field( $str ) {
	return trim( strip_tags( (string) $str ) );
}

function sanitize_key( $key ) {
	return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $key ) );
}

function sanitize_email( $email ) {
	return trim( (string) $email );
}

function esc_html( $text ) {
	return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' );
}

function esc_attr( $text ) {
	return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' );
}

function esc_url( $url ) {
	return (string) $url;
}

function esc_url_raw( $url ) {
	return (string) $url;
}

function esc_textarea( $text ) {
	return htmlspecialchars( (string) $text, ENT_QUOTES, 'UTF-8' );
}

function __( $text, $domain = '' ) {
	return (string) $text;
}

function _x( $text, $context = '', $domain = '' ) {
	return (string) $text;
}

function _n( $single, $plural, $number, $domain = '' ) {
	return 1 === (int) $number ? (string) $single : (string) $plural;
}

function esc_html__( $text, $domain = '' ) {
	return esc_html( $text );
}

function esc_attr__( $text, $domain = '' ) {
	return esc_attr( $text );
}

function _e( $text, $domain = '' ) {
	echo (string) $text;
}

function esc_html_e( $text, $domain = '' ) {
	echo esc_html( $text );
}

function wp_json_encode( $data, $options = 0, $depth = 512 ) {
	return json_encode( $data, (int) $options | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE, (int) $depth );
}

function wp_parse_url( $url, $component = -1 ) {
	return parse_url( (string) $url, (int) $component );
}

/**
 * Mesmo comportamento do WordPress: os valores NÃO são urlencodados aqui.
 */
function add_query_arg( ...$args ) {
	if ( is_array( $args[0] ) ) {
		$params = $args[0];
		$url    = (string) ( $args[1] ?? '' );
	} else {
		$params = array( (string) $args[0] => $args[1] ?? '' );
		$url    = (string) ( $args[2] ?? '' );
	}

	$pairs = array();
	foreach ( $params as $key => $value ) {
		$pairs[] = $key . '=' . $value;
	}

	$glue = false === strpos( $url, '?' ) ? '?' : '&';

	return $url . $glue . implode( '&', $pairs );
}

function wp_http_validate_url( $url ) {
	$parts = parse_url( (string) $url );

	if ( ! is_array( $parts ) || empty( $parts['host'] ) || empty( $parts['scheme'] ) ) {
		return false;
	}

	return in_array( strtolower( $parts['scheme'] ), array( 'http', 'https' ), true ) ? (string) $url : false;
}

// -----------------------------------------------------------------------------
// Admin
// -----------------------------------------------------------------------------

function wp_safe_redirect( $location, $status = 302 ) {
	$GLOBALS['f3_test_redirects'][] = (string) $location;

	throw new F3_Test_Redirect( (string) $location );
}

function wp_redirect( $location, $status = 302 ) {
	$GLOBALS['f3_test_redirects'][] = (string) $location;

	throw new F3_Test_Redirect( (string) $location );
}

function wp_die( $message = '', $title = '', $args = array() ) {
	throw new F3_Test_Die( is_string( $message ) ? $message : 'wp_die' );
}

function check_admin_referer( $action = -1, $query_arg = '_wpnonce' ) {
	return true;
}

function wp_nonce_field( $action = -1, $name = '_wpnonce', $referer = true, $display = true ) {
	$field = '<input type="hidden" name="' . esc_attr( $name ) . '" value="nonce">';

	if ( $display ) {
		echo $field;
	}

	return $field;
}

function submit_button( $text = '', $type = 'primary', $name = 'submit', $wrap = true, $other = null ) {
	echo '<button type="submit" name="' . esc_attr( (string) $name ) . '">' . esc_html( (string) $text ) . '</button>';
}

function selected( $selected, $current = true, $display = true ) {
	$result = (string) $selected === (string) $current ? ' selected="selected"' : '';

	if ( $display ) {
		echo $result;
	}

	return $result;
}

function checked( $checked, $current = true, $display = true ) {
	$result = (string) $checked === (string) $current ? ' checked="checked"' : '';

	if ( $display ) {
		echo $result;
	}

	return $result;
}

function add_management_page( $page_title, $menu_title, $capability, $menu_slug, $callback = '', $position = null ) {
	return $menu_slug;
}

function register_activation_hook( $file, $callback ) {
}

function register_deactivation_hook( $file, $callback ) {
}

function register_rest_route( $namespace, $route, $args = array(), $override = false ) {
	return true;
}

/**
 * WP_REST_Request reduzido ao que o callback do OAuth usa.
 */
class WP_REST_Request {

	private array $params;

	public function __construct( array $params = array() ) {
		$this->params = $params;
	}

	public function get_param( $key ) {
		return $this->params[ $key ] ?? null;
	}

	public function set_param( $key, $value ) {
		$this->params[ $key ] = $value;
	}

	public function get_params() {
		return $this->params;
	}
}

/**
 * `$wpdb` reduzido ao que `uninstall.php` usa: `prepare()`, `esc_like()` e
 * `query()`. Grava cada SQL montado em `$queries` para o teste de
 * desinstalação afirmar que a faxina de transients foi de fato emitida — não
 * há como enumerar transients por prefixo pela API do WordPress, então
 * `uninstall.php` cai para SQL direto e é isso que este stub precisa deixar
 * observável.
 */
class F3_Test_Wpdb {

	public string $options = 'wp_options';

	public string $sitemeta = 'wp_sitemeta';

	/** @var array<int,string> SQL final de cada `query()`, na ordem em que foram chamadas. */
	public array $queries = array();

	/**
	 * Substitui `%s`/%d` na ordem em que aparecem. Simplificado: sem as
	 * regras de escaping do wpdb real, suficiente para o teste conferir a
	 * cláusula LIKE montada.
	 *
	 * @param string $query Consulta com placeholders.
	 * @param mixed  ...$args Valores, ou um único array com todos eles.
	 */
	public function prepare( $query, ...$args ) {
		if ( 1 === count( $args ) && is_array( $args[0] ) ) {
			$args = $args[0];
		}

		$i = 0;

		return (string) preg_replace_callback(
			'/%[sd]/',
			static function ( $match ) use ( &$i, $args ) {
				$value = $args[ $i ] ?? '';
				++$i;

				return '%d' === $match[0] ? (string) (int) $value : "'" . addslashes( (string) $value ) . "'";
			},
			(string) $query
		);
	}

	public function esc_like( $text ) {
		return addcslashes( (string) $text, '_%\\' );
	}

	public function query( $sql ) {
		$this->queries[] = (string) $sql;

		return 0;
	}
}

// -----------------------------------------------------------------------------
// HTTP
// -----------------------------------------------------------------------------

function wp_remote_request( $url, $args = array() ) {
	// Toda requisição passa pelo filtro; em teste nada sai para a rede.
	$pre = apply_filters( 'pre_http_request', false, $args, $url );

	if ( false !== $pre ) {
		return $pre;
	}

	return new WP_Error( 'http_request_failed', 'Rede desabilitada nos testes: ' . $url );
}

function wp_remote_get( $url, $args = array() ) {
	$args['method'] = 'GET';

	return wp_remote_request( $url, $args );
}

function wp_remote_post( $url, $args = array() ) {
	$args['method'] = 'POST';

	return wp_remote_request( $url, $args );
}

function wp_remote_retrieve_response_code( $response ) {
	if ( is_wp_error( $response ) || ! is_array( $response ) ) {
		return '';
	}

	return $response['response']['code'] ?? '';
}

function wp_remote_retrieve_body( $response ) {
	if ( is_wp_error( $response ) || ! is_array( $response ) ) {
		return '';
	}

	return (string) ( $response['body'] ?? '' );
}

function wp_remote_retrieve_headers( $response ) {
	if ( is_wp_error( $response ) || ! is_array( $response ) ) {
		return array();
	}

	return (array) ( $response['headers'] ?? array() );
}

function wp_remote_retrieve_header( $response, $header ) {
	$headers = wp_remote_retrieve_headers( $response );

	foreach ( $headers as $name => $value ) {
		if ( strtolower( (string) $name ) === strtolower( (string) $header ) ) {
			return $value;
		}
	}

	return '';
}

// -----------------------------------------------------------------------------
// Carga: polyfill da Abilities API, apoio de teste e o plugin inteiro
// -----------------------------------------------------------------------------

require_once __DIR__ . '/Support/AbilitiesApiPolyfill.php';
require_once __DIR__ . '/Support/FakeHttp.php';
require_once dirname( __DIR__ ) . '/wp-mcp-google-fator3.php';

\Fator3\McpGoogle\Tests\FakeHttp::install();

// Sem isto os testes de nova tentativa dormiriam três segundos cada.
add_filter( 'f3_mcp_google_retry_wait', '__return_false' );
