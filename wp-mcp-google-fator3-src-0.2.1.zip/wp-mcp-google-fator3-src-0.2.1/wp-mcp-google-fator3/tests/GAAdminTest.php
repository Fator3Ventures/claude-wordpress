<?php
/**
 * Contratos GA4 0.2.0 contra documentos reais de descoberta e HTTP simulado.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Analytics\AdminWrite;
use Fator3\McpGoogle\Analytics\MeasurementProtocol;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Options;
use PHPUnit\Framework\TestCase;

final class GAAdminTest extends TestCase {

	private static ?string $private_key = null;

	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps'] = true;
		$GLOBALS['f3_test_user'] = 1;
		FakeHttp::reset();
		if ( null === self::$private_key ) {
			$pair = openssl_pkey_new( array( 'private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA ) );
			$key = '';
			openssl_pkey_export( $pair, $key );
			self::$private_key = $key;
		}
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set_secret( Options::SA_JSON, (string) wp_json_encode( array(
			'type' => 'service_account', 'client_email' => 'ga-tests@example.iam.gserviceaccount.com',
			'private_key' => self::$private_key, 'token_uri' => 'https://oauth2.googleapis.com/token',
		) ) );
		foreach ( Credentials::scopes_for( 'ga' ) as $scope ) {
			Credentials::remember( Credentials::cache_key( array( $scope ) ), 'ga-test-cached-token', 3500 );
		}
		$fixture = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/analyticsadmin-v1alpha.json' ), true );
		$this->assertIsArray( $fixture );
		set_transient( Discovery::cache_key( 'analytics-admin-v1alpha' ), $fixture, 86400 );
		AdminWrite::register();
		MeasurementProtocol::register();
	}

	public static function actions(): array {
		$p = array( 'property_id' => '123' );
		$n = 'properties/123/';
		return array(
			'create-property' => array( 'create-property', array( 'body' => array( 'parent' => 'accounts/100', 'displayName' => 'Site', 'timeZone' => 'America/Sao_Paulo' ) ), 'POST', 'properties', null ),
			'update-property' => array( 'update-property', $p + array( 'body' => array( 'display_name' => 'Novo site' ) ), 'PATCH', 'properties/123', 'properties/123' ),
			'delete-property' => array( 'delete-property', $p, 'DELETE', 'properties/123', 'properties/123' ),
			'provision-account' => array( 'provision-account', array( 'body' => array( 'account' => array( 'displayName' => 'Empresa', 'regionCode' => 'BR' ), 'redirectUri' => 'https://example.com/return' ) ), 'POST', 'accounts:provisionAccountTicket', null ),
			'delete-account' => array( 'delete-account', array( 'account_id' => '100' ), 'DELETE', 'accounts/100', 'accounts/100' ),
			'create-web-stream' => array( 'create-web-stream', $p + array( 'body' => array( 'displayName' => 'Web', 'webStreamData' => array( 'defaultUri' => 'https://example.com' ) ) ), 'POST', $n . 'dataStreams', null ),
			'update-web-stream' => array( 'update-web-stream', $p + array( 'stream_id' => '456', 'body' => array( 'web_stream_data' => array( 'default_uri' => 'https://example.org' ) ) ), 'PATCH', $n . 'dataStreams/456', $n . 'dataStreams/456' ),
			'delete-web-stream' => array( 'delete-web-stream', $p + array( 'stream_id' => '456' ), 'DELETE', $n . 'dataStreams/456', $n . 'dataStreams/456' ),
			'update-enhanced-measurement' => array( 'update-enhanced-measurement', $p + array( 'stream_id' => '456', 'body' => array( 'scrollsEnabled' => false ) ), 'PATCH', $n . 'dataStreams/456/enhancedMeasurementSettings', $n . 'dataStreams/456/enhancedMeasurementSettings' ),
			'create-key-event' => array( 'create-key-event', $p + array( 'body' => array( 'eventName' => 'generate_lead', 'countingMethod' => 'ONCE_PER_EVENT' ) ), 'POST', $n . 'keyEvents', null ),
			'update-key-event' => array( 'update-key-event', $p + array( 'resource_id' => '7', 'body' => array( 'countingMethod' => 'ONCE_PER_SESSION' ) ), 'PATCH', $n . 'keyEvents/7', $n . 'keyEvents/7' ),
			'delete-key-event' => array( 'delete-key-event', $p + array( 'resource_id' => '7' ), 'DELETE', $n . 'keyEvents/7', $n . 'keyEvents/7' ),
			'create-custom-dimension' => array( 'create-custom-dimension', $p + array( 'body' => array( 'parameterName' => 'lead_type', 'displayName' => 'Lead type', 'scope' => 'EVENT' ) ), 'POST', $n . 'customDimensions', null ),
			'archive-custom-dimension' => array( 'archive-custom-dimension', $p + array( 'resource_id' => '7' ), 'POST', $n . 'customDimensions/7:archive', $n . 'customDimensions/7' ),
			'create-custom-metric' => array( 'create-custom-metric', $p + array( 'body' => array( 'parameterName' => 'lead_score', 'displayName' => 'Lead score', 'scope' => 'EVENT', 'measurementUnit' => 'STANDARD' ) ), 'POST', $n . 'customMetrics', null ),
			'archive-custom-metric' => array( 'archive-custom-metric', $p + array( 'resource_id' => '7' ), 'POST', $n . 'customMetrics/7:archive', $n . 'customMetrics/7' ),
			'update-data-retention' => array( 'update-data-retention', $p + array( 'body' => array( 'eventDataRetention' => 'FOURTEEN_MONTHS' ) ), 'PATCH', $n . 'dataRetentionSettings', $n . 'dataRetentionSettings' ),
			'update-attribution' => array( 'update-attribution', $p + array( 'body' => array( 'reportingAttributionModel' => 'PAID_AND_ORGANIC_CHANNELS_DATA_DRIVEN' ) ), 'PATCH', $n . 'attributionSettings', $n . 'attributionSettings' ),
			'update-google-signals' => array( 'update-google-signals', $p + array( 'body' => array( 'state' => 'GOOGLE_SIGNALS_ENABLED' ) ), 'PATCH', $n . 'googleSignalsSettings', $n . 'googleSignalsSettings' ),
			'create-annotation' => array( 'create-annotation', $p + array( 'body' => array( 'title' => 'Lançamento', 'color' => 'BLUE', 'annotationDate' => array( 'year' => 2026, 'month' => 9, 'day' => 8 ) ) ), 'POST', $n . 'reportingDataAnnotations', null ),
			'update-annotation' => array( 'update-annotation', $p + array( 'resource_id' => '7', 'body' => array( 'title' => 'Lançamento adiado' ) ), 'PATCH', $n . 'reportingDataAnnotations/7', $n . 'reportingDataAnnotations/7' ),
			'delete-annotation' => array( 'delete-annotation', $p + array( 'resource_id' => '7' ), 'DELETE', $n . 'reportingDataAnnotations/7', $n . 'reportingDataAnnotations/7' ),
			'create-audience' => array( 'create-audience', $p + array( 'body' => array( 'displayName' => 'Leads', 'description' => 'Leads', 'membershipDurationDays' => 30, 'filterClauses' => self::audience_filter() ) ), 'POST', $n . 'audiences', null ),
			'update-audience' => array( 'update-audience', $p + array( 'resource_id' => '7', 'body' => array( 'displayName' => 'Leads qualificados' ) ), 'PATCH', $n . 'audiences/7', $n . 'audiences/7' ),
			'archive-audience' => array( 'archive-audience', $p + array( 'resource_id' => '7' ), 'POST', $n . 'audiences/7:archive', $n . 'audiences/7' ),
			'create-mp-secret' => array( 'create-mp-secret', $p + array( 'stream_id' => '456', 'body' => array( 'displayName' => 'Servidor' ) ), 'POST', $n . 'dataStreams/456/measurementProtocolSecrets', null ),
			'delete-mp-secret' => array( 'delete-mp-secret', $p + array( 'stream_id' => '456', 'resource_id' => '7' ), 'DELETE', $n . 'dataStreams/456/measurementProtocolSecrets/7', $n . 'dataStreams/456/measurementProtocolSecrets/7' ),
			'create-google-ads-link' => array( 'create-google-ads-link', $p + array( 'body' => array( 'customerId' => '1234567890', 'adsPersonalizationEnabled' => true ) ), 'POST', $n . 'googleAdsLinks', null ),
			'delete-google-ads-link' => array( 'delete-google-ads-link', $p + array( 'resource_id' => '7' ), 'DELETE', $n . 'googleAdsLinks/7', $n . 'googleAdsLinks' ),
			'add-user' => array( 'add-user', array( 'parent' => 'accounts/100', 'body' => array( 'user' => 'person@example.com', 'roles' => array( 'predefinedRoles/editor' ) ) ), 'POST', 'accounts/100/accessBindings', null ),
			'update-user' => array( 'update-user', $p + array( 'resource_id' => '7', 'body' => array( 'roles' => array( 'predefinedRoles/viewer' ) ) ), 'PATCH', $n . 'accessBindings/7', $n . 'accessBindings/7' ),
			'remove-user' => array( 'remove-user', array( 'name' => 'accounts/100/accessBindings/7' ), 'DELETE', 'accounts/100/accessBindings/7', 'accounts/100/accessBindings/7' ),
		);
	}

	private static function audience_filter(): array {
		return array( array(
			'clauseType' => 'INCLUDE',
			'simpleFilter' => array(
				'scope' => 'AUDIENCE_FILTER_SCOPE_ACROSS_ALL_SESSIONS',
				'filterExpression' => array( 'andGroup' => array( 'filterExpressions' => array(
					array( 'orGroup' => array( 'filterExpressions' => array( array( 'eventFilter' => array( 'eventName' => 'generate_lead' ) ) ) ) ),
				) ) ),
			),
		) );
	}

	private function enqueue_before( string $route, ?string $before ): void {
		if ( null === $before ) {
			return;
		}
		$resource = 'delete-google-ads-link' === $route ? array( 'googleAdsLinks' => array( array( 'name' => 'properties/123/googleAdsLinks/7', 'customerId' => '1234567890' ) ) ) : array( 'name' => $before, 'displayName' => 'Estado anterior real' );
		FakeHttp::push( '/v1alpha/' . $before, 200, $resource );
	}

	/** @dataProvider actions */
	public function test_named_action_uses_real_method_path_and_audits( string $route, array $input, string $verb, string $path, ?string $before ): void {
		$this->enqueue_before( $route, $before );
		$raw = 'provision-account' === $route ? array( 'accountTicketId' => 'ticket-123' ) : array( 'name' => $path, 'displayName' => 'Estado posterior real' );
		if ( 'DELETE' === $verb || false !== strpos( $path, ':archive' ) ) {
			$raw = array();
		}
		FakeHttp::push( '/v1alpha/' . $path, 200, $raw );
		$ability = wp_get_ability( 'ga/' . $route );
		$this->assertNotNull( $ability );
		$result = $ability->execute( $input );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$request = FakeHttp::last();
		$this->assertSame( $verb, $request['method'] );
		$this->assertSame( '/v1alpha/' . $path, parse_url( $request['url'], PHP_URL_PATH ) );
		$this->assertSame( 'Bearer ga-test-cached-token', $request['headers']['Authorization'] );
		if ( 'PATCH' === $verb && 'update-user' !== $route ) {
			parse_str( (string) parse_url( $request['url'], PHP_URL_QUERY ), $query );
			$this->assertNotEmpty( $query['updateMask'] );
		}
		if ( 'update-user' === $route ) {
			$this->assertStringNotContainsString( 'updateMask', $request['url'] );
		}
		$audit = Audit::recent( 1 )[0]['extra'];
		$this->assertArrayHasKey( 'before', $audit );
		$this->assertArrayHasKey( 'after', $audit );
		if ( null !== $before ) {
			$this->assertArrayHasKey( 'name', $audit['before'] );
		} else {
			$this->assertFalse( $audit['before']['exists'] );
		}
		if ( 'provision-account' === $route ) {
			$this->assertFalse( $result['account_created'] );
			$this->assertSame( 'https://analytics.google.com/analytics/web/?provisioningSignup=false#/termsofservice/ticket-123', $result['terms_url'] );
		}
	}

	/** @dataProvider actions */
	public function test_each_action_propagates_failure_without_repeating_a_write( string $route, array $input, string $verb, string $path, ?string $before ): void {
		$this->enqueue_before( $route, $before );
		FakeHttp::push( '/v1alpha/' . $path, 503, array( 'error' => array( 'code' => 503, 'status' => 'UNAVAILABLE', 'message' => 'Try later' ) ) );
		$result = wp_get_ability( 'ga/' . $route )->execute( $input );
		$this->assertFalse( $result['success'], (string) wp_json_encode( $result ) );
		$writes = array_filter( FakeHttp::$requests, static fn( $request ) => 'GET' !== $request['method'] );
		$this->assertCount( 1, $writes, 'Não repetir mutações automaticamente.' );
		$audit = Audit::recent( 1 )[0]['extra'];
		$this->assertArrayHasKey( 'before', $audit );
		$this->assertArrayHasKey( 'after', $audit );
		$this->assertFalse( $audit['after']['available'] );
	}

	public function test_all_admin_writes_refuse_dry_run_without_http(): void {
		foreach ( self::actions() as $case ) {
			$result = wp_get_ability( 'ga/' . $case[0] )->execute( array( 'dry_run' => true ) + $case[1] );
			$this->assertFalse( $result['success'], $case[0] );
			$this->assertSame( 'f3_google_dry_run_unsupported', $result['error_code'] );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_all_ga_new_abilities_enforce_permissions(): void {
		$GLOBALS['f3_test_caps'] = false;
		foreach ( self::actions() as $case ) {
			$this->assertFalse( wp_get_ability( 'ga/' . $case[0] )->check_permissions( $case[1] ) );
			$this->assertFalse( wp_get_ability( 'ga/' . $case[0] )->execute( $case[1] )['success'] );
		}
		foreach ( array( 'ga/list-users', 'ga/get-settings', 'ga/send-event' ) as $route ) {
			$this->assertFalse( wp_get_ability( $route )->check_permissions( array() ) );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_update_mask_is_nested_and_explicit_clear_is_preserved(): void {
		FakeHttp::push( '/v1alpha/properties/123/dataStreams/456', 200, array( 'name' => 'properties/123/dataStreams/456' ) );
		FakeHttp::push( '/v1alpha/properties/123/dataStreams/456', 200, array( 'name' => 'properties/123/dataStreams/456' ) );
		$result = wp_get_ability( 'ga/update-web-stream' )->execute( array( 'property_id' => '123', 'stream_id' => '456', 'body' => array( 'web_stream_data' => array( 'default_uri' => 'https://example.org' ) ) ) );
		$this->assertTrue( $result['success'] );
		$this->assertStringContainsString( 'updateMask=webStreamData.defaultUri', FakeHttp::last()['url'] );
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123' ) );
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123' ) );
		$result = wp_get_ability( 'ga/update-property' )->execute( array( 'property_id' => '123', 'body' => array(), 'update_mask' => 'currency_code' ) );
		$this->assertTrue( $result['success'] );
		$this->assertStringContainsString( 'updateMask=currencyCode', FakeHttp::last()['url'] );
	}

	public function test_conflicting_target_cannot_mutate_a_different_property(): void {
		$result = wp_get_ability( 'ga/delete-key-event' )->execute( array( 'property_id' => '123', 'name' => 'properties/999/keyEvents/7' ) );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_ga_target_mismatch', $result['error_code'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_mp_secret_is_returned_on_creation_but_not_persisted(): void {
		FakeHttp::push( '/v1alpha/properties/123/dataStreams/456/measurementProtocolSecrets', 200, array( 'name' => 'properties/123/dataStreams/456/measurementProtocolSecrets/7', 'secretValue' => 'mp-secret-generated-for-agent' ) );
		$result = wp_get_ability( 'ga/create-mp-secret' )->execute( array( 'property_id' => '123', 'stream_id' => '456', 'body' => array( 'displayName' => 'Servidor' ) ) );
		$this->assertTrue( $result['success'] );
		$this->assertSame( 'mp-secret-generated-for-agent', $result['data']['secretValue'] );
		$this->assertStringNotContainsString( 'mp-secret-generated-for-agent', (string) wp_json_encode( $GLOBALS['f3_test_options'] ) );
	}

	public function test_list_users_paginates_account_and_preserves_next_token_when_capped(): void {
		FakeHttp::push( '/v1alpha/accounts/100/accessBindings', 200, array( 'accessBindings' => array( array( 'name' => 'accounts/100/accessBindings/1', 'user' => 'a@example.com' ) ), 'nextPageToken' => 'page2' ) );
		FakeHttp::push( '/v1alpha/accounts/100/accessBindings', 200, array( 'accessBindings' => array( array( 'name' => 'accounts/100/accessBindings/2', 'user' => 'b@example.com' ) ) ) );
		$result = wp_get_ability( 'ga/list-users' )->execute( array( 'parent' => 'accounts/100' ) );
		$this->assertTrue( $result['success'] );
		$this->assertSame( 2, $result['count'] );
		$this->assertFalse( $result['truncated'] );
		$this->assertStringContainsString( 'pageToken=page2', FakeHttp::last()['url'] );
		FakeHttp::push( '/v1alpha/properties/123/accessBindings', 200, array( 'accessBindings' => array(), 'nextPageToken' => 'continue' ) );
		$result = wp_get_ability( 'ga/list-users' )->execute( array( 'property_id' => '123', 'max_pages' => 1 ) );
		$this->assertTrue( $result['truncated'] );
		$this->assertSame( 'continue', $result['next_page_token'] );
	}

	public function test_settings_aggregates_actual_methods_redacts_secrets_and_reports_partial_errors(): void {
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123', 'account' => 'accounts/100' ) );
		foreach ( array( 'dataRetentionSettings', 'attributionSettings', 'googleSignalsSettings' ) as $resource ) {
			FakeHttp::push( '/v1alpha/properties/123/' . $resource, 200, array( 'name' => 'properties/123/' . $resource ) );
		}
		FakeHttp::push( '/v1alpha/accounts/100', 200, array( 'name' => 'accounts/100' ) );
		FakeHttp::push( '/v1alpha/accounts/100/dataSharingSettings', 200, array( 'name' => 'accounts/100/dataSharingSettings' ) );
		FakeHttp::push( '/v1alpha/properties/123/dataStreams', 200, array( 'dataStreams' => array( array( 'name' => 'properties/123/dataStreams/456', 'type' => 'WEB_DATA_STREAM' ) ) ) );
		foreach ( array( 'keyEvents', 'customDimensions', 'customMetrics', 'reportingDataAnnotations', 'audiences', 'googleAdsLinks' ) as $resource ) {
			FakeHttp::push( '/v1alpha/properties/123/' . $resource, 200, array( $resource => array() ) );
		}
		FakeHttp::push( '/v1alpha/properties/123/accessBindings', 403, array( 'error' => array( 'status' => 'PERMISSION_DENIED', 'message' => 'User lacks permissions' ) ) );
		FakeHttp::push( '/v1alpha/accounts/100/accessBindings', 200, array( 'accessBindings' => array() ) );
		FakeHttp::push( '/v1alpha/properties/123/dataStreams/456/enhancedMeasurementSettings', 200, array( 'scrollsEnabled' => true ) );
		FakeHttp::push( '/v1alpha/properties/123/dataStreams/456/measurementProtocolSecrets', 200, array( 'measurementProtocolSecrets' => array( array( 'name' => 'secret-resource', 'displayName' => 'Servidor', 'secretValue' => 'never-return-this-secret' ) ) ) );
		$result = wp_get_ability( 'ga/get-settings' )->execute( array( 'property_id' => '123' ) );
		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$this->assertFalse( $result['complete'] );
		$this->assertArrayHasKey( 'users', $result['errors'] );
		$this->assertStringNotContainsString( 'never-return-this-secret', (string) wp_json_encode( $result ) );
		$this->assertStringContainsString( 'Servidor', (string) wp_json_encode( $result['settings']['stream_settings'] ) );
		$this->assertSame( array(), FakeHttp::$queue );
	}

	private static function mp_input(): array {
		return array( 'measurement_id' => 'G-ABCDEFGHIJ', 'api_secret' => 'private-mp-secret', 'client_id' => '123.456', 'events' => array( array( 'name' => 'generate_lead', 'params' => array( 'session_id' => 123, 'engagement_time_msec' => 100 ) ) ) );
	}

	public function test_mp_debug_is_real_validation_without_oauth_or_collection(): void {
		FakeHttp::push( '/debug/mp/collect', 200, array( 'validationMessages' => array() ) );
		$result = wp_get_ability( 'ga/send-event' )->execute( array( 'debug' => true ) + self::mp_input() );
		$this->assertTrue( $result['success'] );
		$this->assertTrue( $result['validated'] );
		$this->assertFalse( $result['events_collected'] );
		$this->assertFalse( $result['credential_validated'] );
		$request = FakeHttp::last();
		$this->assertArrayNotHasKey( 'Authorization', $request['headers'] );
		$body = json_decode( $request['body'], true );
		$this->assertSame( 'ENFORCE_RECOMMENDATIONS', $body['validation_behavior'] );
		$this->assertSame( 100, $body['events'][0]['params']['engagement_time_msec'] );
		$this->assertStringNotContainsString( 'private-mp-secret', (string) wp_json_encode( Audit::recent() ) );
	}

	public function test_mp_validation_errors_fail_even_when_http_is_200(): void {
		FakeHttp::push( '/debug/mp/collect', 200, array( 'validationMessages' => array( array( 'validationCode' => 'NAME_INVALID', 'fieldPath' => 'events[0].name', 'description' => 'Name is reserved' ) ) ) );
		$result = wp_get_ability( 'ga/send-event' )->execute( array( 'dry_run' => true ) + self::mp_input() );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_mp_validation', $result['error_code'] );
		$this->assertSame( 'NAME_INVALID', $result['validation_messages'][0]['validationCode'] );
	}

	public function test_mp_204_confirms_transport_only_and_does_not_retry_or_leak_input_secret(): void {
		FakeHttp::push( '/mp/collect', 204, '' );
		$result = wp_get_ability( 'ga/send-event' )->execute( self::mp_input() );
		$this->assertTrue( $result['success'] );
		$this->assertNull( $result['processed'] );
		$this->assertTrue( $result['accepted_by_transport'] );
		$body = json_decode( FakeHttp::last()['body'], true );
		$this->assertArrayNotHasKey( 'validation_behavior', $body );
		FakeHttp::reset();
		FakeHttp::push( '/mp/collect', 503, array( 'error' => array( 'message' => 'Bad private-mp-secret' ) ) );
		$result = wp_get_ability( 'ga/send-event' )->execute( self::mp_input() );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 1, FakeHttp::count() );
		$this->assertStringNotContainsString( 'private-mp-secret', (string) wp_json_encode( $result ) );
		$this->assertStringNotContainsString( 'private-mp-secret', (string) wp_json_encode( Audit::recent() ) );
	}

	public function test_mp_transport_exception_cannot_expose_per_call_secret(): void {
		$throw = static function ( $pre, $args, $url ) {
			throw new \RuntimeException( 'Falha em ' . $url );
		};
		add_filter( 'pre_http_request', $throw, 1, 3 );
		try {
			$result = wp_get_ability( 'ga/send-event' )->execute( self::mp_input() );
			$this->assertFalse( $result['success'] );
			$this->assertSame( 'f3_google_mp_transport', $result['error_code'] );
			$this->assertStringNotContainsString( 'private-mp-secret', (string) wp_json_encode( $result ) );
			$this->assertStringNotContainsString( 'private-mp-secret', (string) wp_json_encode( Audit::recent() ) );
		} finally {
			remove_filter( 'pre_http_request', $throw, 1 );
		}
	}

	public function test_mp_refuses_invalid_event_count_and_unexpected_debug_response(): void {
		$result = wp_get_ability( 'ga/send-event' )->execute( array( 'events' => array_fill( 0, 26, array( 'name' => 'test' ) ) ) + self::mp_input() );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 0, FakeHttp::count() );
		FakeHttp::push( '/debug/mp/collect', 200, array() );
		$result = wp_get_ability( 'ga/send-event' )->execute( array( 'debug' => true ) + self::mp_input() );
		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_mp_validation_response', $result['error_code'] );
	}
}
