<?php
/**
 * Descoberta oficial, validação REST e execução genérica com HTTP interceptado.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Generic\Abilities;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Options;
use PHPUnit\Framework\TestCase;

final class GenericTest extends TestCase {

	private const FIXTURES = array(
		'analytics-admin-v1alpha' => 'analyticsadmin-v1alpha',
		'analytics-admin-v1beta'  => 'analyticsadmin-v1beta',
		'analytics-data-v1beta'   => 'analyticsdata-v1beta',
		'analytics-data-v1alpha'  => 'analyticsdata-v1alpha',
		'google-ads'              => 'googleads-v25',
		'search-console'          => 'searchconsole-v1',
		'site-verification'       => 'siteverification-v1',
		'sheets'                  => 'sheets-v4',
		'drive'                   => 'drive-v3',
	);

	private static array $documents = array();

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'generic.apps.googleusercontent.com' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'generic-client-secret-123' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'generic-refresh-token-123' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'generic-developer-token-123' );
		foreach ( self::FIXTURES as $api => $file ) {
			if ( ! isset( self::$documents[ $api ] ) ) {
				self::$documents[ $api ] = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/' . $file . '.json' ), true, 512, JSON_THROW_ON_ERROR );
			}
			set_transient( Discovery::cache_key( $api ), self::$documents[ $api ], Discovery::CACHE_TTL );
		}
	}

	private function token(): void {
		FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'generic-access-token-123', 'expires_in' => 3600 ) );
	}

	private function api_requests(): array {
		return array_values( array_filter( FakeHttp::$requests, static fn( array $row ): bool => false === strpos( $row['url'], 'oauth2.googleapis.com' ) && false === strpos( $row['url'], '$discovery' ) ) );
	}

	public function test_real_fixtures_have_provenance_and_all_521_methods(): void {
		$sources = json_decode( (string) file_get_contents( __DIR__ . '/fixtures/discovery/sources.json' ), true, 512, JSON_THROW_ON_ERROR );
		foreach ( $sources as $source ) {
			$this->assertSame( $source['sha256'], hash_file( 'sha256', __DIR__ . '/fixtures/discovery/' . $source['api'] . '.json' ) );
		}
		$expected = array( 166, 55, 11, 16, 174, 11, 7, 17, 64 );
		$total = 0;
		foreach ( Discovery::apis() as $i => $api ) {
			$document = Discovery::document( $api );
			$this->assertIsArray( $document, $api );
			$count = count( Discovery::methods( $document ) );
			$this->assertSame( $expected[ $i ], $count, $api );
			$total += $count;
		}
		$this->assertSame( 521, $total );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_every_real_method_has_an_executable_discovery_template(): void {
		$count = 0;
		foreach ( Discovery::apis() as $api ) {
			$document = Discovery::document( $api );
			foreach ( Discovery::methods( $document ) as $method ) {
				$path  = array();
				$query = array();
				foreach ( $method['parameters'] ?? array() as $name => $parameter ) {
					if ( 'path' !== ( $parameter['location'] ?? '' ) && empty( $parameter['required'] ) ) {
						continue;
					}
					$value = isset( $parameter['pattern'] ) ? str_replace( array( '[^/]+', '^', '$' ), array( '123', '', '' ), $parameter['pattern'] ) : '123';
					if ( isset( $parameter['enum'] ) ) {
						$value = $parameter['enum'][0];
					}
					if ( 'integer' === ( $parameter['type'] ?? '' ) ) {
						$value = 1;
					}
					if ( 'path' === $parameter['location'] ) {
						$path[ $name ] = $value;
					} else {
						$query[ $name ] = $value;
					}
				}
				$result = ExecuteAction::prepare( $api, $method, $document, $path, $query, null );
				$this->assertIsArray( $result, $api . ':' . $method['id'] . ( is_wp_error( $result ) ? ' ' . $result->get_error_message() : '' ) );
				$this->assertSame( $method['httpMethod'], $result['method'] );
				$this->assertStringStartsWith( Discovery::config( $api )['root'], $result['url'] );
				$this->assertStringNotContainsString( '{', $result['url'] );
				++$count;
			}
		}
		$this->assertSame( 521, $count );
	}

	public function test_catalog_pages_cover_every_method_without_duplicates(): void {
		$ids    = array();
		$offset = 0;
		do {
			$result = Discovery::catalog( array( 'limit' => 100, 'offset' => $offset, 'include_schemas' => false ) );
			$this->assertTrue( $result['success'] );
			$this->assertTrue( $result['complete'] );
			$this->assertSame( 521, $result['total'] );
			foreach ( $result['actions'] as $action ) {
				$ids[] = $action['api'] . ':' . $action['id'];
			}
			$offset = $result['next_offset'];
		} while ( null !== $offset );
		$this->assertCount( 521, $ids );
		$this->assertCount( 521, array_unique( $ids ) );
	}

	public function test_catalog_search_returns_real_body_and_referenced_schemas(): void {
		$result = Discovery::catalog( array( 'api' => 'analytics-admin', 'task' => 'create audience', 'limit' => 100 ) );
		$this->assertTrue( $result['success'] );
		$this->assertContains( 'analyticsadmin.properties.audiences.create', array_column( $result['actions'], 'id' ) );
		$schemas = (array) $result['schemas'];
		$this->assertArrayHasKey( 'GoogleAnalyticsAdminV1alphaAudience', $schemas['analytics-admin-v1alpha'] );
		$all_text = json_encode( $result );
		$this->assertStringContainsString( 'eventName', $all_text );
		$this->assertStringContainsString( 'http_method', $all_text );
	}

	public function test_live_catalog_fetch_uses_fixed_unauthenticated_url_and_24h_cache(): void {
		$api = 'site-verification';
		delete_transient( Discovery::cache_key( $api ) );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, '' );
		FakeHttp::push( 'discovery/v1/apis/siteVerification/v1/rest', 200, self::$documents[ $api ] );
		$this->assertIsArray( Discovery::document( $api ) );
		$this->assertIsArray( Discovery::document( 'siteverification' ) );
		$this->assertSame( 1, FakeHttp::count() );
		$this->assertSame( Discovery::config( $api )['url'], FakeHttp::last()['url'] );
		$this->assertArrayNotHasKey( 'Authorization', FakeHttp::last()['headers'] );
		$this->assertSame( 86400, Discovery::CACHE_TTL );
	}

	public function test_poisoned_document_origin_and_unknown_api_are_refused(): void {
		$bad = self::$documents['analytics-admin-v1alpha'];
		$bad['rootUrl'] = 'https://www.googleapis.com/';
		set_transient( Discovery::cache_key( 'analytics-admin-v1alpha' ), $bad, 86400 );
		$result = Discovery::document( 'analytics-admin' );
		$this->assertInstanceOf( \WP_Error::class, $result );
		$this->assertSame( 'f3_google_discovery_document', $result->get_error_code() );
		$this->assertInstanceOf( \WP_Error::class, Discovery::document( 'https://evil.example/discovery' ) );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_unknown_method_and_forged_template_are_refused_before_http(): void {
		$this->assertInstanceOf( \WP_Error::class, ExecuteAction::call( 'drive', 'drive.files.dropDatabase' ) );
		$method = Discovery::method( 'drive', 'drive.files.get' );
		$method['path'] = 'permissions/{fileId}';
		$result = ExecuteAction::prepare( 'drive', $method, self::$documents['drive'], array( 'fileId' => '123' ), array(), null );
		$this->assertSame( 'f3_google_action_method', $result->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public static function traversal_inputs(): array {
		return array_map( static fn( string $value ): array => array( $value ), array(
			'properties/../accounts/12', 'properties/..', 'properties/%2e%2e',
			'properties/%252e%252e', 'properties/%252e%252e%252faccounts', 'properties/123/../../accounts',
			'properties/123%00', "properties/123\n", 'https://evil.example/properties/123',
			'//evil.example/properties/123', 'properties/123\\..\\accounts',
		) );
	}

	/** @dataProvider traversal_inputs */
	public function test_traversal_and_external_resource_paths_cannot_leave_template( string $value ): void {
		$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.get', array( 'name' => $value ), array(), null, array( 'mode' => 'read' ) );
		$this->assertInstanceOf( \WP_Error::class, $result, $value );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_site_urls_and_sheets_ranges_are_encoded_as_single_path_values(): void {
		$this->token();
		FakeHttp::push( '/webmasters/v3/sites/', 200, array( 'siteUrl' => 'https://example.test/' ) );
		$result = ExecuteAction::call( 'gsc', 'webmasters.sites.get', array( 'siteUrl' => 'https://example.test/?a=1#x' ), array(), null, array( 'mode' => 'read' ) );
		$this->assertIsArray( $result );
		$this->assertSame( 'https://searchconsole.googleapis.com/webmasters/v3/sites/https%3A%2F%2Fexample.test%2F%3Fa%3D1%23x', FakeHttp::last()['url'] );
		$method = Discovery::method( 'sheets', 'sheets.spreadsheets.values.update' );
		$result = ExecuteAction::prepare( 'sheets', $method, self::$documents['sheets'], array( 'spreadsheetId' => 'abc-123', 'range' => "'Campanha Brasil'!A1:C5" ), array( 'valueInputOption' => 'RAW' ), array( 'values' => array( array( 'hello', 42, true ) ) ) );
		$this->assertIsArray( $result );
		$this->assertStringEndsWith( '/values/%27Campanha%20Brasil%27%21A1%3AC5', $result['url'] );
	}

	public function test_unknown_path_query_wrong_types_and_nested_body_fields_are_refused(): void {
		$cases = array(
			array( array( 'name' => 'properties/123', 'url' => 'https://analyticsadmin.googleapis.com/v1alpha/accounts' ), array(), array( 'displayName' => 'x' ) ),
			array( array( 'name' => 'properties/123' ), array( 'arbitraryUrl' => 'https://www.googleapis.com/' ), array( 'displayName' => 'x' ) ),
			array( array( 'name' => 'properties/123' ), array( 'prettyPrint' => 'true' ), array( 'displayName' => 'x' ) ),
			array( array( 'name' => 'properties/123' ), array(), array( 'notAPropertyField' => 'x' ) ),
			array( array( 'name' => 'properties/123' ), array(), array( 'displayName' => array( 'not' => 'string' ) ) ),
		);
		foreach ( $cases as $case ) {
			$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.patch', $case[0], $case[1], $case[2] );
			$this->assertInstanceOf( \WP_Error::class, $result );
		}
		$result = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.batchUpdate', array( 'spreadsheetId' => 'abc' ), array(), array( 'requests' => array( array( 'addSheet' => array( 'properties' => array( 'madeUp' => true ) ) ) ) ) );
		$this->assertInstanceOf( \WP_Error::class, $result );
		$this->assertStringContainsString( 'madeUp', $result->get_error_message() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_required_query_and_enum_are_checked_from_discovery(): void {
		$result = ExecuteAction::call( 'siteverification', 'siteVerification.webResource.insert', array(), array(), array( 'site' => array( 'type' => 'SITE', 'identifier' => 'https://example.test/' ) ) );
		$this->assertSame( 'f3_google_action_required', $result->get_error_code() );
		$result = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.values.update', array( 'spreadsheetId' => 'abc', 'range' => 'A1' ), array( 'valueInputOption' => 'MADE_UP' ), array( 'values' => array( array( 1 ) ) ) );
		$this->assertSame( 'f3_google_action_enum', $result->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_repeated_query_parameters_and_booleans_match_wire_format(): void {
		$this->token();
		FakeHttp::push( '/v4/spreadsheets/abc', 200, array( 'spreadsheetId' => 'abc' ) );
		$result = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.get', array( 'spreadsheetId' => 'abc' ), array( 'ranges' => array( 'A1:C2', 'D1:F2' ), 'includeGridData' => false ), null, array( 'mode' => 'read' ) );
		$this->assertIsArray( $result );
		$this->assertSame( 'https://sheets.googleapis.com/v4/spreadsheets/abc?ranges=A1%3AC2&ranges=D1%3AF2&includeGridData=false', FakeHttp::last()['url'] );
	}

	public function test_admin_patch_matches_exact_verb_url_body_and_update_mask(): void {
		$this->token();
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123', 'displayName' => 'Novo nome' ) );
		$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.patch', array( 'name' => 'properties/123' ), array( 'updateMask' => 'display_name' ), array( 'displayName' => 'Novo nome' ) );
		$this->assertSame( 'Novo nome', $result['displayName'] );
		$request = FakeHttp::last();
		$this->assertSame( 'PATCH', $request['method'] );
		$this->assertSame( 'https://analyticsadmin.googleapis.com/v1alpha/properties/123?updateMask=display_name', $request['url'] );
		$this->assertSame( array( 'displayName' => 'Novo nome' ), json_decode( $request['body'], true ) );
		$this->assertSame( 'Bearer generic-access-token-123', $request['headers']['Authorization'] );
	}

	public function test_ads_mutate_validate_only_and_manager_header_come_from_real_contract(): void {
		$this->token();
		Options::set( Options::ADS_LOGIN_CUSTOMER_ID, '987-654-3210' );
		FakeHttp::push( '/v25/customers/1234567890/googleAds:mutate', 200, array() );
		$operation = array( 'campaignBudgetOperation' => array( 'create' => array( 'name' => 'Teste', 'amountMicros' => '2000000', 'deliveryMethod' => 'STANDARD' ) ) );
		$result = ExecuteAction::call( 'ads', 'googleads.customers.googleAds.mutate', array( 'customerId' => '1234567890' ), array(), array( 'mutateOperations' => array( $operation ), 'partialFailure' => true ), array( 'dry_run' => true, 'headers' => array( 'login-customer-id' => '111-222-3333', 'Authorization' => 'Bearer forged' ) ) );
		$this->assertIsArray( $result );
		$request = FakeHttp::last();
		$body = json_decode( $request['body'], true );
		$this->assertTrue( $body['validateOnly'] );
		$this->assertTrue( $body['partialFailure'] );
		$this->assertSame( $operation, $body['mutateOperations'][0] );
		$this->assertSame( '1112223333', $request['headers']['login-customer-id'] );
		$this->assertSame( 'generic-developer-token-123', $request['headers']['developer-token'] );
		$this->assertSame( 'Bearer generic-access-token-123', $request['headers']['Authorization'] );
	}

	public function test_dry_run_is_refused_if_api_does_not_offer_validation(): void {
		$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.create', array(), array(), array( 'displayName' => 'Teste', 'parent' => 'accounts/123', 'timeZone' => 'UTC' ), array( 'dry_run' => true ) );
		$this->assertSame( 'f3_google_dry_run_unsupported', $result->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_write_is_not_retried_after_service_error(): void {
		$this->token();
		FakeHttp::push( '/v1alpha/properties', 503, array( 'error' => array( 'message' => 'Temporary outage', 'status' => 'UNAVAILABLE' ) ) );
		$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.create', array(), array(), array( 'displayName' => 'Teste', 'parent' => 'accounts/123', 'timeZone' => 'UTC' ), array( 'retries' => 2 ) );
		$this->assertInstanceOf( \WP_Error::class, $result );
		$this->assertCount( 1, $this->api_requests() );
	}

	public function test_known_oauth_scopes_must_authorize_selected_method(): void {
		Options::set( Options::OAUTH_SCOPES, array( 'https://www.googleapis.com/auth/analytics.readonly' ) );
		$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.create', array(), array(), array( 'displayName' => 'Teste' ) );
		$this->assertSame( 'f3_google_missing_scope', $result->get_error_code() );
		$this->assertStringContainsString( 'analytics.edit', $result->get_error_message() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_generic_query_cannot_replace_the_configured_oauth_identity(): void {
		foreach ( array( 'access_token', 'oauth_token' ) as $key ) {
			$result = ExecuteAction::call( 'drive', 'drive.files.list', array(), array( $key => 'another-user-token' ), null, array( 'mode' => 'read' ) );
			$this->assertSame( 'f3_google_action_auth_override', $result->get_error_code() );
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_manage_users_scope_is_selected_for_access_bindings(): void {
		Options::set( Options::OAUTH_SCOPES, array( 'https://www.googleapis.com/auth/analytics.manage.users' ) );
		$this->token();
		FakeHttp::push( '/v1alpha/properties/123/accessBindings', 200, array( 'name' => 'properties/123/accessBindings/abc' ) );
		$result = ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.accessBindings.create', array( 'parent' => 'properties/123' ), array(), array( 'user' => 'user@example.test', 'roles' => array( 'predefinedRoles/viewer' ) ) );
		$this->assertIsArray( $result );
		$this->assertCount( 1, $this->api_requests() );
	}

	public function test_global_gate_and_capability_prevent_network(): void {
		Options::set( Options::ENABLED, false );
		$result = ExecuteAction::call( 'drive', 'drive.files.list' );
		$this->assertSame( 'f3_google_disabled', $result->get_error_code() );
		Options::set( Options::ENABLED, true );
		$GLOBALS['f3_test_caps'] = false;
		$result = ExecuteAction::call( 'drive', 'drive.files.list' );
		$this->assertSame( 'f3_google_forbidden', $result->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_site_verification_service_path_and_real_body(): void {
		$this->token();
		FakeHttp::push( '/siteVerification/v1/token', 200, array( 'token' => 'google-site-verification=test', 'method' => 'META' ) );
		$result = ExecuteAction::call( 'siteverification', 'siteVerification.webResource.getToken', array(), array(), array( 'site' => array( 'identifier' => 'https://example.test/', 'type' => 'SITE' ), 'verificationMethod' => 'META' ), array( 'mode' => 'read' ) );
		$this->assertIsArray( $result );
		$this->assertSame( 'https://www.googleapis.com/siteVerification/v1/token', FakeHttp::last()['url'] );
		$this->assertSame( 'POST', FakeHttp::last()['method'] );
	}

	public function test_google_execute_action_audits_observed_state_not_request_parameters(): void {
		$this->token();
		$this->token();
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123', 'displayName' => 'Nome anterior' ) );
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123', 'displayName' => 'Nome novo' ) );
		Abilities::register();
		$ability = wp_get_ability( 'google/execute-action' );
		$this->assertNotNull( $ability );
		$result = $ability->execute( array( 'api' => 'ga-admin', 'method' => 'analyticsadmin.properties.patch', 'path_params' => array( 'name' => 'properties/123' ), 'query' => array( 'updateMask' => 'display_name' ), 'body' => array( 'displayName' => 'Nome novo' ) ) );
		$this->assertTrue( $result['success'] );
		$entry = Audit::recent( 1 )[0];
		$this->assertSame( 'Nome anterior', $entry['extra']['before']['data']['displayName'] );
		$this->assertSame( 'Nome novo', $entry['extra']['after']['data']['displayName'] );
		$this->assertFalse( $entry['extra']['dry_run'] );
		$this->assertSame( 'write', $entry['extra']['mode'] );
	}

	public function test_generic_audit_is_honest_when_resource_has_no_get_method(): void {
		$this->token();
		FakeHttp::push( '/v25/customers/1234567890/googleAds:mutate', 200, array() );
		Audit::begin();
		$result = ExecuteAction::run( array( 'api' => 'ads', 'method' => 'googleads.customers.googleAds.mutate', 'path_params' => array( 'customerId' => '1234567890' ), 'body' => array( 'mutateOperations' => array() ), 'dry_run' => true ) );
		$context = Audit::finish();
		$this->assertTrue( $result['success'] );
		$this->assertFalse( $context['before']['available'] );
		$this->assertStringContainsString( 'GET', $context['before']['reason'] );
		$this->assertStringContainsString( 'validateOnly', $context['after']['reason'] );
	}

	public function test_internal_call_preserves_named_module_audit_snapshots(): void {
		$this->token();
		FakeHttp::push( '/v1alpha/properties/123', 200, array( 'name' => 'properties/123', 'displayName' => 'Novo' ) );
		Audit::begin();
		Audit::before( array( 'displayName' => 'Estado do módulo' ) );
		ExecuteAction::call( 'ga-admin', 'analyticsadmin.properties.patch', array( 'name' => 'properties/123' ), array( 'updateMask' => 'display_name' ), array( 'displayName' => 'Novo' ) );
		$context = Audit::finish();
		$this->assertSame( 'Estado do módulo', $context['before']['displayName'] );
		$this->assertCount( 1, $this->api_requests() );
	}

	public function test_generic_partial_failure_keeps_applied_results_and_reports_failure(): void {
		$this->token();
		FakeHttp::push( '/v25/customers/1234567890/googleAds:mutate', 200, array(
			'partialFailureError' => array( 'code' => 3, 'message' => 'One operation failed' ),
			'mutateOperationResponses' => array( array( 'campaignResult' => array( 'resourceName' => 'customers/1234567890/campaigns/10' ) ), array() ),
		) );
		$result = ExecuteAction::run( array( 'api' => 'ads', 'method' => 'googleads.customers.googleAds.mutate', 'path_params' => array( 'customerId' => '1234567890' ), 'body' => array( 'mutateOperations' => array(), 'partialFailure' => true ) ) );
		$this->assertFalse( $result['success'] );
		$this->assertTrue( $result['partial_failure'] );
		$this->assertSame( 'f3_google_partial_failure', $result['error_code'] );
		$this->assertSame( 'customers/1234567890/campaigns/10', $result['data']['mutateOperationResponses'][0]['campaignResult']['resourceName'] );
		$this->assertCount( 1, $this->api_requests() );
	}

	public function test_audit_filters_and_redaction_do_not_expose_tokens(): void {
		Audit::log( 'google/execute-action', 'properties/123', array( 'mode' => 'write', 'status' => 'ok', 'before' => array( 'api_secret' => 'do-not-persist' ), 'after' => array( 'name' => 'properties/123' ) ) );
		Audit::log( 'google/query', 'properties/456', array( 'mode' => 'read', 'status' => 'error' ) );
		$result = Abilities::audit( array( 'mode' => 'write', 'target' => 'properties/123', 'user' => 1, 'from' => gmdate( 'Y-m-d' ), 'to' => gmdate( 'Y-m-d' ) ) );
		$this->assertTrue( $result['success'] );
		$this->assertSame( 1, $result['count'] );
		$this->assertSame( '[redigido]', $result['entries'][0]['extra']['before']['api_secret'] );
		$this->assertStringNotContainsString( 'do-not-persist', json_encode( $result ) );
		$this->assertFalse( Abilities::audit( array( 'from' => 'not-a-date' ) )['success'] );
	}

	public function test_drive_inline_upload_uses_documented_multipart_endpoint(): void {
		$this->token();
		FakeHttp::push( '/upload/drive/v3/files?uploadType=multipart', 200, array( 'id' => 'created-file-id' ) );
		$result = ExecuteAction::call( 'drive', 'drive.files.create', array(), array(), array( 'name' => 'dados.csv', 'parents' => array( 'shared-folder' ) ), array( 'media' => array( 'content_base64' => base64_encode( "name,count\nA,1\n" ), 'mime_type' => 'text/csv' ) ) );
		$this->assertSame( 'created-file-id', $result['id'] );
		$request = FakeHttp::last();
		$this->assertSame( 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', $request['url'] );
		$this->assertStringStartsWith( 'multipart/related; boundary=f3_google_', $request['headers']['Content-Type'] );
		$this->assertStringContainsString( '"name":"dados.csv"', $request['body'] );
		$this->assertStringContainsString( "name,count\nA,1\n", $request['body'] );
	}

	public function test_discovery_restores_nested_empty_objects_and_arrays_after_wordpress_json_decode(): void {
		$this->token();
		FakeHttp::push( '/v4/spreadsheets/abc:batchUpdate', 200, array( 'replies' => array( array( 'addSheet' => array( 'properties' => array( 'sheetId' => 1 ) ) ) ) ) );
		$result = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.batchUpdate', array( 'spreadsheetId' => 'abc' ), array(), array( 'requests' => array( array( 'addSheet' => array() ) ) ) );
		$this->assertIsArray( $result );
		$this->assertSame( '{"requests":[{"addSheet":{}}]}', FakeHttp::last()['body'] );
	}

	public function test_ads_manual_cpc_object_and_repeated_operations_keep_distinct_json_types(): void {
		$this->token();
		FakeHttp::push( '/v25/customers/1234567890/campaigns:mutate', 200, array( 'results' => array() ) );
		$result = ExecuteAction::call( 'ads', 'googleads.customers.campaigns.mutate', array( 'customerId' => '1234567890' ), array(), array( 'operations' => array( array( 'create' => array( 'name' => 'CPC', 'manualCpc' => array() ) ) ) ) );
		$this->assertIsArray( $result );
		$this->assertStringContainsString( '"manualCpc":{}', FakeHttp::last()['body'] );
		$this->assertStringContainsString( '"operations":[', FakeHttp::last()['body'] );
		FakeHttp::push( '/v25/customers/1234567890/googleAds:mutate', 200, array() );
		ExecuteAction::call( 'ads', 'googleads.customers.googleAds.mutate', array( 'customerId' => '1234567890' ), array(), array( 'mutateOperations' => array() ), array( 'dry_run' => true ) );
		$this->assertSame( '{"mutateOperations":[],"validateOnly":true}', FakeHttp::last()['body'] );
	}

	public function test_drive_export_preserves_non_json_download_bytes(): void {
		$this->token();
		FakeHttp::push( '/drive/v3/files/abc/export?mimeType=text%2Fcsv', 200, "name,count\nA,1\n", array( 'content-type' => 'text/csv' ) );
		$result = ExecuteAction::call( 'drive', 'drive.files.export', array( 'fileId' => 'abc' ), array( 'mimeType' => 'text/csv' ), null, array( 'mode' => 'read' ) );
		$this->assertIsArray( $result );
		$this->assertSame( 'text/csv', $result['content_type'] );
		$this->assertSame( base64_encode( "name,count\nA,1\n" ), $result['content_base64'] );
	}

	public function test_media_invalid_encoding_header_injection_and_unsupported_methods_fail(): void {
		foreach ( array(
			array( 'content_base64' => 'not base64 !!!', 'mime_type' => 'text/plain' ),
			array( 'content_base64' => base64_encode( 'ok' ), 'mime_type' => "text/plain\r\nX-Evil: yes" ),
		) as $media ) {
			$result = ExecuteAction::call( 'drive', 'drive.files.create', array(), array(), array( 'name' => 'bad' ), array( 'media' => $media ) );
			$this->assertSame( 'f3_google_media_input', $result->get_error_code() );
		}
		$result = ExecuteAction::call( 'sheets', 'sheets.spreadsheets.create', array(), array(), array(), array( 'media' => array( 'content_base64' => base64_encode( 'ok' ), 'mime_type' => 'text/plain' ) ) );
		$this->assertSame( 'f3_google_media_unsupported', $result->get_error_code() );
		$this->assertSame( 0, FakeHttp::count() );
	}
}
