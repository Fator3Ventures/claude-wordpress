<?php
/**
 * Testes do módulo Analytics (fase 2a): PropertyId, normalize_keys, to_table,
 * as 10 habilidades `ga/*` e o portão que já é testado no núcleo.
 *
 * O que se procura aqui é o que quebraria em silêncio numa chamada real: um
 * filtro em snake_case que a REST API rejeitaria por causa da caixa da chave,
 * um `limit` maior que o teto vazando cru para a Google, uma métrica de
 * moeda virando string em vez de número, uma paginação que para na primeira
 * página, ou um erro 403 que chega ao agente sem `reason`.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Analytics\Abilities as AnalyticsAbilities;
use Fator3\McpGoogle\Analytics\DataApi;
use Fator3\McpGoogle\Analytics\PropertyId;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use PHPUnit\Framework\TestCase;

final class AnalyticsTest extends TestCase {

	private const SA_EMAIL = 'robo@projeto-teste.iam.gserviceaccount.com';

	/** @var array{private:string,public:string}|null Par de chaves gerado uma vez. */
	private static ?array $keys = null;

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;

		FakeHttp::reset();

		// `wp_abilities_api_init` só dispara em `init`, que os testes não
		// simulam (o núcleo também não depende disso — ver CoreTest). Chamar
		// direto é idempotente: cada chamada só substitui a entrada no
		// registro em memória do polyfill.
		AnalyticsAbilities::register();
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);

			$private = '';
			openssl_pkey_export( $pair, $private );
			$details = openssl_pkey_get_details( $pair );

			self::$keys = array(
				'private' => $private,
				'public'  => (string) $details['key'],
			);
		}

		return self::$keys;
	}

	private static function sa_key_array(): array {
		return array(
			'type'         => 'service_account',
			'project_id'   => 'projeto-teste',
			'private_key'  => self::keys()['private'],
			'client_email' => self::SA_EMAIL,
			'token_uri'    => 'https://oauth2.googleapis.com/token',
		);
	}

	/**
	 * Liga o canal com o conector GA configurado; Ads fica desligado de
	 * propósito, para os testes de portão do GA não dependerem dele.
	 */
	private function enable_ga( string $default_property = '' ): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, false );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set_secret( Options::SA_JSON, (string) wp_json_encode( self::sa_key_array() ) );

		if ( '' !== $default_property ) {
			Options::set( Options::GA_DEFAULT_PROPERTY, $default_property );
		}
	}

	/**
	 * Enfileira a troca de JWT por access token — toda chamada autenticada
	 * passa por aqui antes de chegar à Admin/Data API.
	 */
	private function push_token(): void {
		FakeHttp::push(
			'oauth2.googleapis.com/token',
			200,
			array(
				'access_token' => 'tok-ga-teste',
				'expires_in'   => 3600,
				'token_type'   => 'Bearer',
			)
		);
	}

	private function execute( string $name, array $input = array() ): array {
		$ability = wp_get_ability( $name );
		$this->assertNotNull( $ability, $name );

		return $ability->execute( $input );
	}

	private function last_body(): array {
		$body = FakeHttp::last()['body'] ?? '';

		return is_string( $body ) ? (array) json_decode( $body, true ) : array();
	}

	// =========================================================================
	// PropertyId
	// =========================================================================

	public function test_property_id_aceita_int_string_prefixo_e_espacos(): void {
		$this->assertSame( 'properties/123', PropertyId::normalize( 123 ) );
		$this->assertSame( 'properties/123', PropertyId::normalize( '123' ) );
		$this->assertSame( 'properties/123', PropertyId::normalize( 'properties/123' ) );
		$this->assertSame( 'properties/123', PropertyId::normalize( '  123  ' ) );
		$this->assertSame( 'properties/123', PropertyId::normalize( '  properties/123  ' ) );
		$this->assertSame( '123', PropertyId::number( 'properties/123' ) );
	}

	public function test_property_id_recusa_valor_invalido(): void {
		foreach ( array( 'abc', 'properties/abc', '12a' ) as $invalid ) {
			$result = PropertyId::normalize( $invalid );
			$this->assertTrue( is_wp_error( $result ), (string) wp_json_encode( $invalid ) );
			$this->assertSame( 'f3_google_bad_property_id', $result->get_error_code() );
		}

		// Um valor não-escalar (não veio de JSON válido) é tratado como
		// ausente, não como formato inválido — cai na mesma mensagem de
		// "informe property_id".
		$this->assertSame( 'f3_google_property_required', PropertyId::normalize( array( 1, 2 ) )->get_error_code() );
	}

	public function test_property_id_sem_valor_e_sem_padrao_e_erro(): void {
		$result = PropertyId::normalize( '' );

		$this->assertTrue( is_wp_error( $result ) );
		$this->assertSame( 'f3_google_property_required', $result->get_error_code() );

		$this->assertTrue( is_wp_error( PropertyId::normalize( null ) ) );
	}

	public function test_property_id_usa_a_propriedade_padrao_da_option(): void {
		Options::set( Options::GA_DEFAULT_PROPERTY, '999' );

		$this->assertSame( 'properties/999', PropertyId::normalize( '' ) );
		$this->assertSame( 'properties/999', PropertyId::normalize( null ) );
		$this->assertSame( '999', PropertyId::number( null ) );

		// Um property_id explícito sempre vale mais que a padrão.
		$this->assertSame( 'properties/1', PropertyId::normalize( '1' ) );
	}

	// =========================================================================
	// DataApi::normalize_keys
	// =========================================================================

	public function test_normalize_keys_converte_chaves_recursivamente_sem_tocar_valores(): void {
		$input = array(
			'and_group' => array(
				'expressions' => array(
					array(
						'filter' => array(
							'field_name'    => 'eventName',
							'string_filter' => array(
								'match_type' => 'BEGINS_WITH',
								'value'      => 'add_to_cart',
							),
						),
					),
					array( 'int64_value' => '10' ),
				),
			),
		);

		$out = DataApi::normalize_keys( $input );

		$this->assertArrayHasKey( 'andGroup', $out );
		$this->assertArrayNotHasKey( 'and_group', $out );

		$first = $out['andGroup']['expressions'][0]['filter'];
		$this->assertSame( 'eventName', $first['fieldName'] );
		// Valores nunca mudam de caixa nem de conteúdo — nem o enum em
		// maiúsculas, nem o texto do usuário com underscore.
		$this->assertSame( 'BEGINS_WITH', $first['stringFilter']['matchType'] );
		$this->assertSame( 'add_to_cart', $first['stringFilter']['value'] );

		$this->assertSame( '10', $out['andGroup']['expressions'][1]['int64Value'] );
	}

	public function test_normalize_keys_deixa_chave_ja_camel_intacta(): void {
		$this->assertSame(
			array( 'fieldName' => 'x', 'matchType' => 'EXACT' ),
			DataApi::normalize_keys( array( 'fieldName' => 'x', 'matchType' => 'EXACT' ) )
		);
	}

	public function test_normalize_keys_preserva_listas_numericas(): void {
		$out = DataApi::normalize_keys( array( 'values' => array( 'a', 'b', 'c' ) ) );

		$this->assertSame( array( 'a', 'b', 'c' ), $out['values'] );
	}

	// =========================================================================
	// DataApi::to_table
	// =========================================================================

	public function test_to_table_com_um_date_range_converte_tipos_e_traz_totais(): void {
		$response = array(
			'dimensionHeaders' => array( array( 'name' => 'eventName' ) ),
			'metricHeaders'    => array(
				array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ),
				array( 'name' => 'purchaseRevenue', 'type' => 'TYPE_CURRENCY' ),
			),
			'rows'             => array(
				array(
					'dimensionValues' => array( array( 'value' => 'purchase' ) ),
					'metricValues'    => array( array( 'value' => '10' ), array( 'value' => '9.5' ) ),
				),
			),
			'totals'           => array(
				array(
					'dimensionValues' => array( array( 'value' => 'RESERVED_TOTAL' ) ),
					'metricValues'    => array( array( 'value' => '10' ), array( 'value' => '9.5' ) ),
				),
			),
			'rowCount'         => 5,
		);

		$table = DataApi::to_table( $response );

		$this->assertSame( array( 'eventName', 'eventCount', 'purchaseRevenue' ), $table['columns'] );
		$this->assertSame( array( 'purchase', 10, 9.5 ), $table['rows'][0] );
		$this->assertIsInt( $table['rows'][0][1] );
		$this->assertIsFloat( $table['rows'][0][2] );
		$this->assertSame( 1, $table['row_count'] );
		$this->assertSame( 5, $table['row_count_total'] );
		$this->assertTrue( $table['truncated'] );
		$this->assertSame( array( 'RESERVED_TOTAL', 10, 9.5 ), $table['totals'][0] );
	}

	public function test_to_table_com_dois_date_ranges_mantem_a_dimensao_que_a_google_ja_devolve(): void {
		$response = array(
			'dimensionHeaders' => array( array( 'name' => 'dateRange' ), array( 'name' => 'eventName' ) ),
			'metricHeaders'    => array( array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ) ),
			'rows'             => array(
				array(
					'dimensionValues' => array( array( 'value' => 'date_range_0' ), array( 'value' => 'purchase' ) ),
					'metricValues'    => array( array( 'value' => '3' ) ),
				),
				array(
					'dimensionValues' => array( array( 'value' => 'date_range_1' ), array( 'value' => 'purchase' ) ),
					'metricValues'    => array( array( 'value' => '7' ) ),
				),
			),
			'rowCount'         => 2,
		);

		$table = DataApi::to_table( $response );

		$this->assertSame( array( 'dateRange', 'eventName', 'eventCount' ), $table['columns'] );
		$this->assertSame( array( 'date_range_0', 'purchase', 3 ), $table['rows'][0] );
		$this->assertSame( array( 'date_range_1', 'purchase', 7 ), $table['rows'][1] );
		$this->assertFalse( $table['truncated'] );
	}

	public function test_to_table_traz_property_quota_e_metadata_quando_existem(): void {
		$response = array(
			'dimensionHeaders' => array(),
			'metricHeaders'    => array(),
			'rows'             => array(),
			'propertyQuota'    => array( 'tokensPerDay' => array( 'consumed' => 1, 'remaining' => 99 ) ),
			'metadata'         => array( 'currencyCode' => 'BRL', 'timeZone' => 'America/Sao_Paulo' ),
		);

		$table = DataApi::to_table( $response );

		$this->assertSame( 99, $table['property_quota']['tokensPerDay']['remaining'] );
		$this->assertSame( 'BRL', $table['metadata']['currencyCode'] );
	}

	// =========================================================================
	// ga/run-report
	// =========================================================================

	public function test_run_report_monta_o_corpo_certo_a_partir_de_entrada_snake_case(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'analyticsdata.googleapis.com/v1beta/properties/123:runReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'eventName' ) ),
				'metricHeaders'    => array( array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(),
				'rowCount'         => 0,
			)
		);

		$result = $this->execute(
			'ga/run-report',
			array(
				'property_id'       => '123',
				'date_ranges'       => array( array( 'start_date' => '7daysAgo', 'end_date' => 'yesterday' ) ),
				'dimensions'        => array( 'eventName' ),
				'metrics'           => array( 'eventCount' ),
				'dimension_filter'  => array(
					'and_group' => array(
						'expressions' => array(
							array(
								'filter' => array(
									'field_name'    => 'eventName',
									'string_filter' => array( 'match_type' => 'EXACT', 'value' => 'purchase' ),
								),
							),
						),
					),
				),
			)
		);

		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );

		$request = FakeHttp::last();
		$this->assertSame( GoogleClient::HOST_GA_DATA . '/v1beta/properties/123:runReport', $request['url'] );
		$this->assertSame( 'application/json', $request['headers']['Content-Type'] );
		$this->assertSame( 'Bearer tok-ga-teste', $request['headers']['Authorization'] );

		$body = $this->last_body();
		$this->assertArrayNotHasKey( 'property', $body, 'a propriedade vai na URL, não no corpo' );
		$this->assertSame( array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ), $body['dateRanges'] );
		$this->assertSame( array( array( 'name' => 'eventName' ) ), $body['dimensions'] );
		$this->assertSame( array( array( 'name' => 'eventCount' ) ), $body['metrics'] );
		$this->assertSame(
			'eventName',
			$body['dimensionFilter']['andGroup']['expressions'][0]['filter']['fieldName']
		);
		$this->assertSame(
			'EXACT',
			$body['dimensionFilter']['andGroup']['expressions'][0]['filter']['stringFilter']['matchType']
		);
		$this->assertSame( Options::max_rows(), $body['limit'] );
	}

	public function test_run_report_aceita_dimensoes_como_objetos_e_order_bys_em_camel(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'eventName' ) ),
				'metricHeaders'    => array( array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(),
				'rowCount'         => 0,
			)
		);

		$result = $this->execute(
			'ga/run-report',
			array(
				'property_id' => '1',
				'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'  => array( array( 'name' => 'eventName' ) ),
				'metrics'     => array( 'eventCount' ),
				'order_bys'   => array( array( 'metric' => array( 'metricName' => 'eventCount' ), 'desc' => true ) ),
			)
		);

		$this->assertTrue( $result['success'] );

		$body = $this->last_body();
		$this->assertSame( array( array( 'name' => 'eventName' ) ), $body['dimensions'] );
		$this->assertTrue( $body['orderBys'][0]['desc'] );
		$this->assertSame( 'eventCount', $body['orderBys'][0]['metric']['metricName'] );
	}

	public function test_run_report_format_raw_devolve_a_resposta_da_google_intacta(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'eventName' ) ),
				'metricHeaders'    => array( array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(),
				'rowCount'         => 0,
			)
		);

		$result = $this->execute(
			'ga/run-report',
			array(
				'property_id' => '1',
				'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'  => array( 'eventName' ),
				'metrics'     => array( 'eventCount' ),
				'format'      => 'raw',
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertArrayHasKey( 'raw', $result );
		$this->assertSame( 'eventName', $result['raw']['dimensionHeaders'][0]['name'] );
		$this->assertArrayNotHasKey( 'columns', $result );
	}

	public function test_limit_acima_do_teto_e_cortado_e_marcado_truncated(): void {
		$this->enable_ga();
		Options::set( Options::MAX_ROWS, 10 );
		$this->push_token();

		FakeHttp::push(
			'runReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'eventName' ) ),
				'metricHeaders'    => array( array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(),
				'rowCount'         => 0,
			)
		);

		$result = $this->execute(
			'ga/run-report',
			array(
				'property_id' => '1',
				'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'  => array( 'eventName' ),
				'metrics'     => array( 'eventCount' ),
				'limit'       => 5000,
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( 10, $this->last_body()['limit'] );
		$this->assertTrue( $result['truncated'] );
	}

	public function test_offset_e_repassado_e_entra_no_calculo_de_truncated(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'eventName' ) ),
				'metricHeaders'    => array( array( 'name' => 'eventCount', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(
					array(
						'dimensionValues' => array( array( 'value' => 'x' ) ),
						'metricValues'    => array( array( 'value' => '1' ) ),
					),
				),
				'rowCount'         => 11,
			)
		);

		$result = $this->execute(
			'ga/run-report',
			array(
				'property_id' => '1',
				'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'  => array( 'eventName' ),
				'metrics'     => array( 'eventCount' ),
				'offset'      => 10,
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( 10, $this->last_body()['offset'] );
		// rowCountTotal(11) === offset(10) + row_count(1): não sobrou nada.
		$this->assertFalse( $result['truncated'] );
	}

	// =========================================================================
	// ga/run-realtime-report
	// =========================================================================

	public function test_run_realtime_report_nao_manda_date_ranges(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runRealtimeReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'country' ) ),
				'metricHeaders'    => array( array( 'name' => 'activeUsers', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(
					array(
						'dimensionValues' => array( array( 'value' => 'Brazil' ) ),
						'metricValues'    => array( array( 'value' => '42' ) ),
					),
				),
				'rowCount'         => 1,
			)
		);

		$result = $this->execute(
			'ga/run-realtime-report',
			array(
				'property_id' => '1',
				'dimensions'  => array( 'country' ),
				'metrics'     => array( 'activeUsers' ),
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( 'Brazil', 42 ), $result['rows'][0] );

		$request = FakeHttp::last();
		$this->assertSame( GoogleClient::HOST_GA_DATA . '/v1beta/properties/1:runRealtimeReport', $request['url'] );

		$body = $this->last_body();
		$this->assertArrayNotHasKey( 'dateRanges', $body );
		$this->assertArrayNotHasKey( 'currencyCode', $body );
	}

	// =========================================================================
	// ga/run-funnel-report
	// =========================================================================

	public function test_funnel_report_passos_event_e_filter_expression_breakdown_e_next_action(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runFunnelReport',
			200,
			array( 'funnelVisualization' => array( 'sim' => true ) )
		);

		$result = $this->execute(
			'ga/run-funnel-report',
			array(
				'property_id'        => '1',
				'funnel_steps'       => array(
					array( 'name' => 'Visita', 'event' => 'first_visit' ),
					array(
						'name'              => 'Compra',
						'filter_expression' => array(
							'or_group' => array(
								'expressions' => array(
									array( 'funnel_event_filter' => array( 'event_name' => 'purchase' ) ),
								),
							),
						),
					),
				),
				'funnel_breakdown'   => array( 'breakdown_dimension' => 'deviceCategory' ),
				'funnel_next_action' => array( 'next_action_dimension' => 'eventName', 'limit' => 5 ),
			)
		);

		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$this->assertArrayHasKey( 'raw', $result, 'formato padrão do funil é raw' );

		$body = $this->last_body();
		$this->assertSame(
			'first_visit',
			$body['funnel']['steps'][0]['filterExpression']['funnelEventFilter']['eventName']
		);
		$this->assertSame(
			'purchase',
			$body['funnel']['steps'][1]['filterExpression']['orGroup']['expressions'][0]['funnelEventFilter']['eventName']
		);
		$this->assertSame( array( 'startDate' => '30daysAgo', 'endDate' => 'yesterday' ), $body['dateRanges'][0] );
		$this->assertSame( 'deviceCategory', $body['funnelBreakdown']['breakdownDimension']['name'] );
		$this->assertSame( 'eventName', $body['funnelNextAction']['nextActionDimension']['name'] );
		$this->assertSame( 5, $body['funnelNextAction']['limit'] );
	}

	public function test_funnel_report_format_table_converte_funnel_table(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runFunnelReport',
			200,
			array(
				'funnelTable' => array(
					'dimensionHeaders' => array( array( 'name' => 'funnelStepName' ) ),
					'metricHeaders'    => array( array( 'name' => 'activeUsers', 'type' => 'TYPE_INTEGER' ) ),
					'rows'             => array(
						array(
							'dimensionValues' => array( array( 'value' => 'Visita' ) ),
							'metricValues'    => array( array( 'value' => '100' ) ),
						),
					),
				),
				'funnelVisualization' => array( 'ignorado' => true ),
			)
		);

		$result = $this->execute(
			'ga/run-funnel-report',
			array(
				'property_id'  => '1',
				'funnel_steps' => array( array( 'name' => 'Visita', 'event' => 'first_visit' ) ),
				'format'       => 'table',
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertArrayNotHasKey( 'raw', $result );
		$this->assertSame( array( 'funnelStepName', 'activeUsers' ), $result['columns'] );
		$this->assertSame( array( 'Visita', 100 ), $result['rows'][0] );
	}

	public function test_funnel_report_sem_passo_e_recusado_antes_da_rede(): void {
		$this->enable_ga();

		$result = $this->execute(
			'ga/run-funnel-report',
			array( 'property_id' => '1', 'funnel_steps' => array() )
		);

		$this->assertFalse( $result['success'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	// =========================================================================
	// ga/run-conversions-report
	// =========================================================================

	public function test_run_conversions_report_inclui_conversion_spec_em_v1alpha(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'v1alpha/properties/1:runReport',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'source' ) ),
				'metricHeaders'    => array( array( 'name' => 'advertiserAdCost', 'type' => 'TYPE_CURRENCY' ) ),
				'rows'             => array(),
				'rowCount'         => 0,
			)
		);

		$result = $this->execute(
			'ga/run-conversions-report',
			array(
				'property_id'     => '1',
				'date_ranges'     => array( array( 'start_date' => '30daysAgo', 'end_date' => 'yesterday' ) ),
				'dimensions'      => array( 'source' ),
				'metrics'         => array( 'advertiserAdCost' ),
				'conversion_spec' => array( 'conversion_actions' => array(), 'attribution_model' => 'data_driven' ),
			)
		);

		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );

		$request = FakeHttp::last();
		$this->assertStringContainsString( '/v1alpha/properties/1:runReport', $request['url'] );

		$body = $this->last_body();
		$this->assertSame( array(), $body['conversionSpec']['conversionActions'] );
		$this->assertSame( 'DATA_DRIVEN', $body['conversionSpec']['attributionModel'] );
		$this->assertArrayNotHasKey( '__conversion_spec', $body );
	}

	public function test_run_conversions_report_com_acao_especifica_e_last_click(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'v1alpha/properties/1:runReport',
			200,
			array(
				'dimensionHeaders' => array(),
				'metricHeaders'    => array(),
				'rows'             => array(),
			)
		);

		$this->execute(
			'ga/run-conversions-report',
			array(
				'property_id'     => '1',
				'date_ranges'     => array( array( 'startDate' => '30daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'      => array( 'source' ),
				'metrics'         => array( 'allConversionsByConversionDate' ),
				'conversion_spec' => array(
					'conversionActions' => array( 'conversionActions/12345' ),
					'attributionModel'  => 'LAST_CLICK',
				),
			)
		);

		$body = $this->last_body();
		$this->assertSame( array( 'conversionActions/12345' ), $body['conversionSpec']['conversionActions'] );
		$this->assertSame( 'LAST_CLICK', $body['conversionSpec']['attributionModel'] );
	}

	// =========================================================================
	// ga/get-metadata
	// =========================================================================

	public function test_get_metadata_custom_only_padrao_filtra_o_catalogo_padrao(): void {
		$this->enable_ga( '123' );
		$this->push_token();

		FakeHttp::push(
			'properties/123/metadata',
			200,
			array(
				'dimensions' => array(
					array(
						'apiName'          => 'eventName',
						'uiName'           => 'Event name',
						'description'      => 'Nome do evento',
						'customDefinition' => false,
						'category'         => 'Event',
					),
					array(
						'apiName'          => 'customEvent:foo',
						'uiName'           => 'Foo',
						'description'      => 'Dimensão customizada',
						'customDefinition' => true,
						'category'         => 'Custom',
					),
				),
				'metrics'    => array(
					array(
						'apiName'          => 'eventCount',
						'uiName'           => 'Event count',
						'description'      => 'Contagem de eventos',
						'type'             => 'TYPE_INTEGER',
						'customDefinition' => false,
						'category'         => 'Event',
					),
				),
			)
		);

		$result = $this->execute( 'ga/get-metadata', array( 'property_id' => '123' ) );

		$this->assertTrue( $result['success'] );
		$this->assertCount( 1, $result['dimensions'] );
		$this->assertSame( 'customEvent:foo', $result['dimensions'][0]['api_name'] );
		$this->assertTrue( $result['dimensions'][0]['custom'] );
		$this->assertSame( 0, $result['counts']['metrics'], 'custom_only=true (padrão) não deixa passar a métrica padrão' );

		$this->assertStringContainsString( '/v1beta/properties/123/metadata', FakeHttp::last()['url'] );
	}

	public function test_get_metadata_custom_only_false_com_query(): void {
		$this->enable_ga( '123' );
		$this->push_token();

		FakeHttp::push(
			'properties/123/metadata',
			200,
			array(
				'dimensions' => array(
					array(
						'apiName'          => 'eventName',
						'uiName'           => 'Event name',
						'description'      => 'Nome do evento disparado',
						'customDefinition' => false,
						'category'         => 'Event',
					),
					array(
						'apiName'          => 'country',
						'uiName'           => 'Country',
						'description'      => 'País do usuário',
						'customDefinition' => false,
						'category'         => 'Geo',
					),
				),
				'metrics'    => array(),
			)
		);

		$result = $this->execute(
			'ga/get-metadata',
			array( 'property_id' => '123', 'custom_only' => false, 'query' => 'evento' )
		);

		$this->assertTrue( $result['success'] );
		$this->assertCount( 1, $result['dimensions'] );
		$this->assertSame( 'eventName', $result['dimensions'][0]['api_name'] );
	}

	public function test_get_metadata_sem_propriedade_e_sem_padrao_usa_catalogo_universal(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'properties/0/metadata',
			200,
			array(
				'dimensions' => array(
					array(
						'apiName'          => 'eventName',
						'uiName'           => 'Event name',
						'description'      => 'Nome do evento',
						'customDefinition' => false,
						'category'         => 'Event',
					),
				),
				'metrics'    => array(),
			)
		);

		// custom_only não é informado (usaria o padrão true), mas sem
		// propriedade não existe customização: precisa ser ignorado.
		$result = $this->execute( 'ga/get-metadata', array() );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 1, $result['counts']['dimensions'] );
		$this->assertSame( 'eventName', $result['dimensions'][0]['api_name'] );
		$this->assertStringContainsString( '/v1beta/properties/0/metadata', FakeHttp::last()['url'] );
	}

	// =========================================================================
	// ga/check-compatibility
	// =========================================================================

	public function test_check_compatibility_separa_compativel_de_incompativel(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'checkCompatibility',
			200,
			array(
				'dimensionCompatibilities' => array(
					array( 'dimensionMetadata' => array( 'apiName' => 'eventName' ), 'compatibility' => 'COMPATIBLE' ),
				),
				'metricCompatibilities'    => array(
					array( 'metricMetadata' => array( 'apiName' => 'sessions' ), 'compatibility' => 'INCOMPATIBLE' ),
				),
			)
		);

		$result = $this->execute(
			'ga/check-compatibility',
			array(
				'property_id' => '1',
				'dimensions'  => array( 'eventName' ),
				'metrics'     => array( 'sessions' ),
			)
		);

		$this->assertTrue( $result['success'] );
		$this->assertSame( array( 'eventName' ), $result['compatible_dimensions'] );
		$this->assertSame( array(), $result['compatible_metrics'] );
		$this->assertCount( 1, $result['incompatible'] );
		$this->assertSame( 'sessions', $result['incompatible'][0]['name'] );
		$this->assertSame( 'metric', $result['incompatible'][0]['type'] );
		$this->assertArrayNotHasKey( 'raw', $result );
	}

	// =========================================================================
	// ga/get-account-summaries
	// =========================================================================

	public function test_account_summaries_junta_as_paginas(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'accountSummaries',
			200,
			array(
				'accountSummaries' => array(
					array(
						'account'           => 'accounts/1',
						'displayName'       => 'Conta 1',
						'propertySummaries' => array(
							array(
								'property'     => 'properties/10',
								'displayName'  => 'Site A',
								'propertyType' => 'PROPERTY_TYPE_ORDINARY',
								'parent'       => 'accounts/1',
							),
						),
					),
				),
				'nextPageToken'    => 'pagina-2',
			)
		);
		FakeHttp::push(
			'accountSummaries',
			200,
			array(
				'accountSummaries' => array(
					array( 'account' => 'accounts/2', 'displayName' => 'Conta 2', 'propertySummaries' => array() ),
				),
			)
		);

		$result = $this->execute( 'ga/get-account-summaries' );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 2, $result['count_accounts'] );
		$this->assertSame( 1, $result['count_properties'] );
		$this->assertSame( 'accounts/2', $result['accounts'][1]['account'] );
		$this->assertSame( 'properties/10', $result['accounts'][0]['properties'][0]['property'] );
	}

	// =========================================================================
	// ga/get-property-details
	// =========================================================================

	public function test_get_property_details(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'analyticsadmin.googleapis.com/v1beta/properties/1',
			200,
			array( 'name' => 'properties/1', 'displayName' => 'Meu site', 'timeZone' => 'America/Sao_Paulo' )
		);

		$result = $this->execute( 'ga/get-property-details', array( 'property_id' => '1' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 'Meu site', $result['property']['displayName'] );
	}

	// =========================================================================
	// ga/list-google-ads-links
	// =========================================================================

	public function test_list_google_ads_links(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'googleAdsLinks',
			200,
			array(
				'googleAdsLinks' => array(
					array(
						'name'                      => 'properties/1/googleAdsLinks/2',
						'customerId'                => '1234567890',
						'adsPersonalizationEnabled' => true,
						'canManageClients'          => false,
						'creatorEmailAddress'       => 'dono@exemplo.com',
						'createTime'                => '2024-01-01T00:00:00Z',
					),
				),
			)
		);

		$result = $this->execute( 'ga/list-google-ads-links', array( 'property_id' => '1' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 1, $result['count'] );
		$this->assertSame( '1234567890', $result['links'][0]['customer_id'] );
		$this->assertTrue( $result['links'][0]['ads_personalization_enabled'] );
		$this->assertFalse( $result['links'][0]['can_manage_clients'] );
		$this->assertSame( 'dono@exemplo.com', $result['links'][0]['creator_email_address'] );
	}

	// =========================================================================
	// ga/list-property-annotations
	// =========================================================================

	public function test_list_property_annotations_usa_v1alpha(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'reportingDataAnnotations',
			200,
			array( 'reportingDataAnnotations' => array( array( 'title' => 'Lançamento da campanha X' ) ) )
		);

		$result = $this->execute( 'ga/list-property-annotations', array( 'property_id' => '1' ) );

		$this->assertTrue( $result['success'] );
		$this->assertSame( 1, $result['count'] );
		$this->assertSame( 'Lançamento da campanha X', $result['annotations'][0]['title'] );
		$this->assertStringContainsString( '/v1alpha/properties/1/reportingDataAnnotations', FakeHttp::last()['url'] );
	}

	// =========================================================================
	// Erros da API
	// =========================================================================

	public function test_erro_403_da_api_vira_success_false_com_error_code_e_reason(): void {
		$this->enable_ga();
		$this->push_token();

		FakeHttp::push(
			'runReport',
			403,
			array(
				'error' => array(
					'code'    => 403,
					'message' => 'User does not have sufficient permissions for this property.',
					'status'  => 'PERMISSION_DENIED',
				),
			)
		);

		$result = $this->execute(
			'ga/run-report',
			array(
				'property_id' => '1',
				'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'  => array( 'eventName' ),
				'metrics'     => array( 'eventCount' ),
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_http', $result['error_code'] );
		$this->assertSame( 403, $result['details']['status'] );
		$this->assertSame( 'PERMISSION_DENIED', $result['details']['reason'] );
	}

	// =========================================================================
	// Registro das 10 habilidades
	// =========================================================================

	public function test_as_dez_habilidades_estao_registradas_com_os_padroes_da_casa(): void {
		$names = array(
			'ga/get-account-summaries',
			'ga/get-property-details',
			'ga/list-google-ads-links',
			'ga/list-property-annotations',
			'ga/get-metadata',
			'ga/check-compatibility',
			'ga/run-report',
			'ga/run-realtime-report',
			'ga/run-funnel-report',
			'ga/run-conversions-report',
		);

		$all = wp_get_abilities();

		foreach ( $names as $name ) {
			$this->assertArrayHasKey( $name, $all, $name );

			$ability = $all[ $name ];
			$meta    = $ability->get_meta();

			$this->assertTrue( $meta['mcp']['public'], $name );
			$this->assertSame( 'tool', $meta['mcp']['type'], $name );
			$this->assertTrue( $meta['annotations']['readonly'], $name );
			$this->assertSame( 'google', $ability->get_category(), $name );

			$schema = $ability->get_input_schema();
			$this->assertSame( 'object', $schema['type'], $name );
			$this->assertFalse( $schema['additionalProperties'], $name );

			foreach ( (array) ( $schema['required'] ?? array() ) as $field ) {
				$this->assertArrayHasKey( $field, $schema['properties'], $name . ' -> ' . $field );
			}

			$this->assertLessThanOrEqual(
				400,
				strlen( $ability->get_description() ),
				$name . ' tem descrição com ' . strlen( $ability->get_description() ) . ' caracteres'
			);
			$this->assertNotSame( '', $ability->get_description(), $name );
		}
	}

	public function test_run_report_tem_os_required_certos(): void {
		$schema = wp_get_ability( 'ga/run-report' )->get_input_schema();
		sort( $schema['required'] );
		$this->assertSame( array( 'date_ranges', 'dimensions', 'metrics' ), $schema['required'] );
		$this->assertArrayNotHasKey( 'property_id', array_flip( $schema['required'] ) );
	}

	public function test_run_realtime_report_tem_os_required_certos(): void {
		$schema = wp_get_ability( 'ga/run-realtime-report' )->get_input_schema();
		sort( $schema['required'] );
		$this->assertSame( array( 'dimensions', 'metrics' ), $schema['required'] );
	}

	public function test_run_conversions_report_tem_os_required_certos(): void {
		$schema = wp_get_ability( 'ga/run-conversions-report' )->get_input_schema();
		sort( $schema['required'] );
		$this->assertSame( array( 'conversion_spec', 'date_ranges', 'dimensions', 'metrics' ), $schema['required'] );
	}

	public function test_run_funnel_report_tem_os_required_certos(): void {
		$schema = wp_get_ability( 'ga/run-funnel-report' )->get_input_schema();
		$this->assertSame( array( 'funnel_steps' ), $schema['required'] );
	}

	// =========================================================================
	// Portão (Gate) aplicado às habilidades de Analytics
	// =========================================================================

	public function test_recusa_quando_o_canal_esta_fechado(): void {
		$this->enable_ga();
		Options::set( Options::ENABLED, false );

		$result = $this->execute( 'ga/get-account-summaries' );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_disabled', $result['error_code'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_recusa_quando_o_conector_ga_esta_desligado(): void {
		$this->enable_ga();
		Options::set( Options::GA_ENABLED, false );

		$result = $this->execute( 'ga/get-account-summaries' );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_connector_off', $result['error_code'] );
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_recusa_sem_credencial_configurada(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );

		$result = $this->execute( 'ga/get-account-summaries' );

		$this->assertFalse( $result['success'] );
		$this->assertSame( 'f3_google_not_configured', $result['error_code'] );
	}
}
