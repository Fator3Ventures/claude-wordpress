<?php
/** Regressões encontradas na revisão independente da fase 4. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ads\AdsApi;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Auth\ServiceAccount;
use Fator3\McpGoogle\Auth\OAuthUser;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Unified\Accounts;
use Fator3\McpGoogle\Unified\Query;
use PHPUnit\Framework\TestCase;

final class ReviewCoreTest extends TestCase {
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps'] = true;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'review-local-client' );
		Options::set( Options::OAUTH_EMAIL, 'review@example.test' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'review-client-secret' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'review-refresh-token' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'review-developer-token' );
		Credentials::remember( Credentials::cache_key( Credentials::scopes_for( 'ads' ) ), 'review-access-token', 3500 );
	}

	private function accessible( array $ids ): void {
		FakeHttp::push( 'customers:listAccessibleCustomers', 200, array( 'resourceNames' => array_map( static fn( $id ) => 'customers/' . $id, $ids ) ) );
	}

	private function details( string $id, bool $manager = true ): void {
		FakeHttp::push( '/customers/' . $id . '/googleAds:search', 200, array(
			'fieldMask' => 'customer.id,customer.descriptive_name,customer.manager',
			'results' => array( array( 'customer' => array( 'id' => $id, 'descriptiveName' => 'Conta ' . $id, 'manager' => $manager ) ) ),
		) );
	}

	private function children( string $id, array $clients, string $token = '' ): void {
		FakeHttp::push( '/customers/' . $id . '/googleAds:search', 200, array(
			'fieldMask' => 'customer_client.id,customer_client.descriptive_name,customer_client.manager,customer_client.level',
			'results' => array_map( static fn( $client ) => array( 'customerClient' => $client ), $clients ),
			'nextPageToken' => $token,
		) );
	}

	public function test_wildcard_expands_every_root_all_levels_and_pages_beyond_report_limit(): void {
		Options::set( Options::MAX_ROWS, 1 );
		$this->accessible( array( '1111111111', '2222222222', '1111111111' ) );
		$this->details( '1111111111' );
		$children = array();
		for ( $i = 0; $i < 30; ++$i ) {
			$children[] = array( 'id' => (string) ( 3000000000 + $i ), 'descriptiveName' => 'Filho ' . $i, 'manager' => 0 === $i, 'level' => 0 === $i ? 1 : 2 );
		}
		$this->children( '1111111111', array_slice( $children, 0, 20 ), 'next-page' );
		$this->children( '1111111111', array_slice( $children, 20 ) );
		$this->details( '2222222222' );
		$this->children( '2222222222', array( array( 'id' => '4444444444', 'descriptiveName' => 'Cliente da segunda MCC', 'manager' => false, 'level' => 1 ) ) );
		$result = Accounts::resolve_many( 'ads', array( '*' ) );
		$this->assertIsArray( $result, is_wp_error( $result ) ? $result->get_error_message() : '' );
		$this->assertCount( 33, $result );
		$this->assertContains( '4444444444', $result );
		$this->assertContains( '3000000029', $result );
		$hierarchy_requests = array_filter( FakeHttp::$requests, static function ( $request ): bool {
			$body = is_string( $request['body'] ) ? json_decode( $request['body'], true ) : array();
			return false !== strpos( $body['query'] ?? '', 'FROM customer_client' );
		} );
		$this->assertCount( 3, $hierarchy_requests );
		foreach ( $hierarchy_requests as $request ) {
			$body = json_decode( $request['body'], true );
			$this->assertStringNotContainsString( 'level <=', $body['query'] );
			$this->assertStringNotContainsString( 'LIMIT', $body['query'] );
			$this->assertStringNotContainsString( 'hidden = FALSE', $body['query'] );
		}
		$this->assertSame( array( '4444444444' ), Accounts::resolve_many( 'ads', array( 'cliente da segunda mcc' ) ) );
		$this->assertSame( array(), FakeHttp::$queue );
	}

	public function test_manager_failure_refuses_wildcard_and_does_not_cache_partial_catalog(): void {
		$this->accessible( array( '1111111111' ) );
		$this->details( '1111111111' );
		FakeHttp::push( '/customers/1111111111/googleAds:search', 403, array( 'error' => array( 'status' => 'PERMISSION_DENIED', 'message' => 'No permission for hierarchy' ) ) );
		$result = Accounts::resolve_many( 'ads', array( '*' ) );
		$this->assertTrue( is_wp_error( $result ) );
		$this->assertSame( 'f3_google_account_catalog', $result->get_error_code() );
		$this->assertStringContainsString( '1111111111', $result->get_error_message() );
		$this->assertFalse( get_transient( Query::ACCOUNTS_CACHE . 'ads_mcc_' . Credentials::identity_key() ) );
	}

	public function test_detail_failure_is_not_silently_converted_to_an_unnamed_account(): void {
		$this->accessible( array( '1111111111' ) );
		FakeHttp::push( '/customers/1111111111/googleAds:search', 403, array( 'error' => array( 'status' => 'PERMISSION_DENIED', 'message' => 'No permission for customer' ) ) );
		$result = Query::accounts( array( 'connector' => 'ads', 'expand_managers' => true ) );
		$this->assertNotEmpty( $result['warnings'] );
		$this->assertSame( 0, $result['count'] );
		$this->assertFalse( get_transient( Query::ACCOUNTS_CACHE . 'ads_mcc_' . Credentials::identity_key() ) );
	}

	public function test_repeated_page_token_refuses_a_complete_catalog(): void {
		$this->accessible( array( '1111111111' ) );
		$this->details( '1111111111' );
		$this->children( '1111111111', array(), 'repeated' );
		$this->children( '1111111111', array(), 'repeated' );
		$result = Accounts::resolve_many( 'ads', array( '*' ) );
		$this->assertTrue( is_wp_error( $result ) );
		$this->assertStringContainsString( 'repetiu', $result->get_error_message() );
		$this->assertSame( 4, FakeHttp::count() );
	}

	public function test_explicit_customer_clients_preserves_original_row_limit_and_default_filters(): void {
		Options::set( Options::MAX_ROWS, 1 );
		$this->children( '1111111111', array( array( 'id' => '2222222222' ), array( 'id' => '3333333333' ) ) );
		$result = AdsApi::customer_clients( '1111111111' );
		$this->assertTrue( $result['truncated'] );
		$this->assertCount( 1, $result['rows'] );
		$query = json_decode( FakeHttp::last()['body'], true )['query'];
		$this->assertStringContainsString( 'customer_client.level <= 1', $query );
		$this->assertStringContainsString( 'customer_client.hidden = FALSE', $query );
		$this->assertStringContainsString( 'LIMIT 1', $query );
	}
	public function test_service_account_tokens_are_isolated_by_delegated_subject(): void {
		Options::set( Options::AUTH_MODE, 'service_account' );
		$pair = openssl_pkey_new( array( 'private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA ) );
		$private_key = '';
		openssl_pkey_export( $pair, $private_key );
		$key = array( 'type' => 'service_account', 'client_email' => 'review@example.iam.gserviceaccount.com', 'private_key' => $private_key, 'token_uri' => 'https://oauth2.googleapis.com/token' );
		$alice = new ServiceAccount( $key, 'alice@example.test' );
		$bob = new ServiceAccount( $key, 'bob@example.test' );
		FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'synthetic-token-alice', 'expires_in' => 3600 ) );
		FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'synthetic-token-bob', 'expires_in' => 3600 ) );
		$this->assertSame( 'synthetic-token-alice', $alice->get_access_token( array( Credentials::SCOPE_GA ) ) );
		$this->assertSame( 'synthetic-token-bob', $bob->get_access_token( array( Credentials::SCOPE_GA ) ) );
		$this->assertSame( 'synthetic-token-alice', $alice->get_access_token( array( Credentials::SCOPE_GA ) ) );
		$this->assertSame( 'synthetic-token-bob', $bob->get_access_token( array( Credentials::SCOPE_GA ) ) );
		$this->assertSame( 2, FakeHttp::count() );
	}

	public function test_oauth_tokens_without_email_do_not_cross_refresh_credentials(): void {
		$first = new OAuthUser( 'same-client-id', 'same-client-secret', 'first-refresh-credential' );
		$second = new OAuthUser( 'same-client-id', 'same-client-secret', 'second-refresh-credential' );
		$this->assertSame( $first->identity(), $second->identity(), 'A identidade exibida pode coincidir; a chave de cache não.' );
		FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'synthetic-oauth-first', 'expires_in' => 3600 ) );
		FakeHttp::push( 'oauth2.googleapis.com/token', 200, array( 'access_token' => 'synthetic-oauth-second', 'expires_in' => 3600 ) );
		$this->assertSame( 'synthetic-oauth-first', $first->get_access_token( array( Credentials::SCOPE_ADS ) ) );
		$this->assertSame( 'synthetic-oauth-second', $second->get_access_token( array( Credentials::SCOPE_ADS ) ) );
		$this->assertSame( 'synthetic-oauth-first', $first->get_access_token( array( Credentials::SCOPE_ADS ) ) );
		$this->assertSame( 2, FakeHttp::count() );
	}

	public function test_general_pagination_refuses_loops_and_page_ceiling_without_silent_partial_results(): void {
		$url = 'https://analyticsadmin.googleapis.com/v1alpha/accountSummaries';
		foreach ( array( 1, 2 ) as $page ) {
			FakeHttp::push( 'analyticsadmin.googleapis.com', 200, array( 'accountSummaries' => array( array( 'page' => $page ) ), 'nextPageToken' => 'same-token' ) );
		}
		$result = GoogleClient::get_all_pages( $url, array(), 'accountSummaries', array( 'auth' => false ) );
		$this->assertTrue( is_wp_error( $result ) );
		$this->assertSame( 'f3_google_pagination', $result->get_error_code() );
		$this->assertSame( 2, FakeHttp::count() );
		FakeHttp::reset();
		for ( $page = 0; $page < 100; ++$page ) {
			FakeHttp::push( 'analyticsadmin.googleapis.com', 200, array( 'accountSummaries' => array( array( 'page' => $page ) ), 'nextPageToken' => 'token-' . $page ) );
		}
		$result = GoogleClient::get_all_pages( $url, array(), 'accountSummaries', array( 'auth' => false ) );
		$this->assertTrue( is_wp_error( $result ) );
		$this->assertSame( 'f3_google_pagination_limit', $result->get_error_code() );
		$this->assertSame( 100, FakeHttp::count() );
		FakeHttp::reset();
		FakeHttp::push( 'analyticsadmin.googleapis.com', 200, array( 'accountSummaries' => array( array( 'page' => 1 ), array( 'page' => 2 ) ), 'nextPageToken' => 'more' ) );
		$result = GoogleClient::get_all_pages( $url, array(), 'accountSummaries', array( 'auth' => false ), 1 );
		$this->assertSame( array( array( 'page' => 1 ) ), $result );
		$this->assertSame( 1, FakeHttp::count() );
	}

}
