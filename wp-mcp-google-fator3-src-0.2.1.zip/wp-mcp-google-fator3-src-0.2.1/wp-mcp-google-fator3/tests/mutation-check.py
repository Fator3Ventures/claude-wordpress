#!/usr/bin/env python3
"""Quatro mutações reais, isoladas, com restauração obrigatória do código."""
import argparse, hashlib, json, pathlib, re, subprocess
parser=argparse.ArgumentParser()
parser.add_argument('--php',default='php');parser.add_argument('--phpunit',required=True)
parser.add_argument('--output',required=True)
args=parser.parse_args();root=pathlib.Path(__file__).resolve().parent.parent
command=[args.php,args.phpunit,'--bootstrap',str(root/'tests/bootstrap.php')]
def unbind_method(s):
 start=s.index("\t\tif ( ! isset( $methods[ $id ] ) ||")
 end=s.index("\t\t$parameters",start)
 return s[:start]+"\t\t// Mutante: aceita metadados fornecidos fora do catálogo.\n"+s[end:]
mutants=[
 ('host-search-console','includes/Http/GoogleClient.php',lambda s:s.replace('self::HOST_ADS, self::HOST_GSC,','self::HOST_ADS,',1),'UpdateCoreTest.php','test_http_write_is_not_retried_and_new_hosts_are_allowed'),
 ('audit-before','includes/Audit.php',lambda s:s.replace("\tpublic static function log( string $action, string $target = '-', array $extra = array() ): void {","\tpublic static function log( string $action, string $target = '-', array $extra = array() ): void {\n\t\tunset( $extra['before'] );",1),'UpdateCoreTest.php','test_write_audits_real_snapshots_bounded_and_redacted'),
 ('blend-date','includes/Unified/Blend.php',lambda s:s.replace("$value = substr( $value, 0, 4 ) . '-' . substr( $value, 4, 2 ) . '-' . substr( $value, 6, 2 );","$value = $value; // Mutante: não normaliza data GA4.",1),'BlendSheetsTest.php',None),
 ('discovery-path-binding','includes/Generic/ExecuteAction.php',unbind_method,'GenericTest.php','test_unknown_method_and_forged_template_are_refused_before_http'),
]
results=[]
for name,relative,mutate,test,filter_name in mutants:
 path=root/relative;original=path.read_bytes();text=original.decode();changed=mutate(text)
 assert changed!=text, name+' não alterou o código'
 baseline=subprocess.run(command+([ '--filter',filter_name] if filter_name else [])+[str(root/'tests'/test)],capture_output=True,text=True,timeout=45)
 if baseline.returncode:raise RuntimeError(name+' base não aprovada: '+baseline.stdout+baseline.stderr)
 try:
  path.write_text(changed)
  run=subprocess.run(command+([ '--filter',filter_name] if filter_name else [])+[str(root/'tests'/test)],capture_output=True,text=True,timeout=45)
  result={'mutation':name,'file':relative,'baseline_exit':baseline.returncode,'mutant_exit':run.returncode,'detected':run.returncode!=0,'test':test,'filter':filter_name,'output':run.stdout+run.stderr}
 finally:path.write_bytes(original)
 result['restored_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 result['restored']=path.read_bytes()==original
 results.append(result);print(name,'DETECTED' if result['detected'] else 'SURVIVED',flush=True)
payload={'mutations':results,'detected':sum(x['detected'] for x in results),'total':len(results),'all_restored':all(x['restored'] for x in results)}
pathlib.Path(args.output).write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
raise SystemExit(0 if payload['detected']==payload['total'] else 1)
