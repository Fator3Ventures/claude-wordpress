<?php
/**
 * Testes de integração de ponta a ponta (fase 3).
 *
 * Os outros arquivos de teste (CoreTest, AnalyticsTest, AdsTest, UnifiedTest)
 * verificam cada classe isoladamente, registrando habilidades direto ou
 * chamando o `execute_callback` por dentro. Este arquivo cobre o que só
 * aparece quando as peças rodam juntas, do jeito que o WP MCP Ultimate
 * realmente aciona o plugin:
 *
 *  a) o bootstrap de verdade (`wp-mcp-google-fator3.php`) disparado por
 *     `do_action( 'init' )`, com a categoria e as 21 habilidades saindo do
 *     registro da Abilities API — não de uma chamada direta a `X::register()`;
 *  b) o protocolo do Ultimate propriamente dito: `discover-abilities`,
 *     `get-ability-info` e `execute-ability` (com `parameters` como string
 *     JSON, como o Cowork manda), usando uma cópia literal dos quatro
 *     arquivos do Ultimate que fazem isso;
 *  c) uma varredura de vazamento de segredo pelas 21 rotas de uma vez, com
 *     credenciais reais configuradas e respostas HTTP adversárias (erro que
 *     ecoa o cabeçalho Authorization, como uma API mal comportada faria);
 *  d) `uninstall.php` de verdade, com `WP_UNINSTALL_PLUGIN` definido e um
 *     `$wpdb` de mentira;
 *  e) uma rede de segurança estática: nenhum arquivo usa sintaxe só de PHP
 *     8.1+, e todo arquivo de `includes/` tem `declare(strict_types=1)` e a
 *     guarda de `ABSPATH` — coisas que `php -l` sob PHP 8.4 não pega, porque
 *     8.4 entende 8.1+ perfeitamente.
 *
 * @package Fator3\McpGoogle\Tests
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Tests;

use Fator3\McpGoogle\Ads\Abilities as AdsAbilities;
use Fator3\McpGoogle\Analytics\Abilities as AnalyticsAbilities;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Unified\Abilities as UnifiedAbilities;
use Fator3\McpGoogle\Unified\Catalog;
use PHPUnit\Framework\TestCase;
use WpMcpUltimate\Server\Abilities\DiscoverAbilitiesAbility;
use WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility;
use WpMcpUltimate\Server\Abilities\GetAbilityInfoAbility;

// Cópia literal (mesmo namespace) dos quatro arquivos do WP MCP Ultimate que
// implementam o protocolo — ver README ao lado deles. Carregados aqui, e não
// em tests/bootstrap.php, porque só este arquivo os usa.
require_once __DIR__ . '/Support/Ultimate/McpAbilityHelperTrait.php';
require_once __DIR__ . '/Support/Ultimate/DiscoverAbilitiesAbility.php';
require_once __DIR__ . '/Support/Ultimate/GetAbilityInfoAbility.php';
require_once __DIR__ . '/Support/Ultimate/ExecuteAbilityAbility.php';

final class IntegrationTest extends TestCase {

	private const SA_EMAIL = 'robo-integracao@projeto-teste.iam.gserviceaccount.com';

	private const DEV_TOKEN = 'DEVTOKEN-SECRET-123';

	private const OAUTH_CLIENT_SECRET = 'client-secret-super-confidencial-999888';

	private const OAUTH_REFRESH_TOKEN = 'refresh-token-super-confidencial-777666';

	private const ACCESS_TOKEN = 'tok-integracao-vazamento-secreto-555444';

	/**
	 * As 21 habilidades que o plugin registra: 10 `ga/*`, 6 `ads/*`, 5
	 * `google/*`. Listadas aqui, literalmente, porque é exatamente isto que a
	 * fase 3 precisa fixar contra regressão — perder uma rota silenciosamente
	 * (por exemplo um arquivo que parou de ser incluído no bootstrap) não dá
	 * erro nenhum sozinho, só um `wp_get_ability()` que devolve null lá na
	 * frente, dentro de uma sessão MCP de um usuário de verdade.
	 *
	 * @var string[]
	 */
	private const EXPECTED_ABILITIES = array(
		'ga/get-account-summaries',
		'ga/get-property-details',
		'ga/list-google-ads-links',
		'ga/list-property-annotations',
		'ga/get-metadata',
		'ga/check-compatibility',
		'ga/run-report',
		'ga/run-realtime-report',
		'ga/run-conversions-report',
		'ga/run-funnel-report',
		'ads/list-accessible-customers',
		'ads/get-customer',
		'ads/search',
		'ads/get-resource-metadata',
		'ads/list-resources',
		'ads/list-customer-clients',
		'google/status',
		'google/selftest',
		'google/list-accounts',
		'google/list-fields',
		'google/query',
	);

	/** @var array{private:string,public:string}|null Par de chaves gerado uma vez. */
	private static ?array $keys = null;

	protected function setUp(): void {
		$GLOBALS['f3_test_options']    = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps']       = true;
		$GLOBALS['f3_test_user']       = 1;
		$GLOBALS['f3_test_redirects']  = array();
		$GLOBALS['f3_test_multisite']  = false;

		FakeHttp::reset();
		Catalog::flush();

		// O registro de habilidades (WP_Abilities_Registry, do polyfill) é um
		// singleton que sobrevive ao teste inteiro — inclusive às habilidades
		// de mentira que CoreTest registra ('ga/teste-padroes' etc.) para
		// testar o Ability::register() isoladamente. Começar cada teste deste
		// arquivo com o registro limpo, e então disparar o `init` de verdade,
		// é o que garante que "as 21 habilidades esperadas" signifique
		// exatamente 21 — nem a mais (lixo de outro arquivo), nem a menos.
		self::reset_ability_registry();
		do_action( 'init' );

		// As três meta-ferramentas do Ultimate por cima do que acabou de ser
		// registrado — é assim que um servidor MCP de verdade enxergaria isto.
		DiscoverAbilitiesAbility::register();
		GetAbilityInfoAbility::register();
		ExecuteAbilityAbility::register();
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	private static function reset_ability_registry(): void {
		foreach ( array_keys( wp_get_abilities() ) as $name ) {
			wp_unregister_ability( $name );
		}
	}

	private static function keys(): array {
		if ( null === self::$keys ) {
			$pair = openssl_pkey_new(
				array(
					'private_key_bits' => 2048,
					'private_key_type' => OPENSSL_KEYTYPE_RSA,
				)
			);

			$private = '';
			openssl_pkey_export( $pair, $private );
			$details = openssl_pkey_get_details( $pair );

			self::$keys = array(
				'private' => $private,
				'public'  => (string) $details['key'],
			);
		}

		return self::$keys;
	}

	/**
	 * Liga os dois conectores, com os quatro segredos configurados (inclusive
	 * os do modo OAuth, que fica inativo — o ponto é que NENHUM dos quatro
	 * pode vazar, esteja em uso ou não) e um access token já em cache, para os
	 * testes de rota não precisarem enfileirar a troca de token.
	 */
	private function enable_all_with_real_secrets(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set( Options::GA_DEFAULT_PROPERTY, '123456789' );
		Options::set( Options::ADS_LOGIN_CUSTOMER_ID, '1234567890' );

		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, self::DEV_TOKEN );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, self::OAUTH_CLIENT_SECRET );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, self::OAUTH_REFRESH_TOKEN );
		Options::set_secret(
			Options::SA_JSON,
			(string) wp_json_encode(
				array(
					'type'         => 'service_account',
					'project_id'   => 'projeto-integracao',
					'private_key'  => self::keys()['private'],
					'client_email' => self::SA_EMAIL,
					'token_uri'    => 'https://oauth2.googleapis.com/token',
				)
			)
		);

		foreach ( array( 'ga', 'ads', 'any' ) as $connector ) {
			Credentials::remember(
				Credentials::cache_key( Credentials::scopes_for( $connector ), self::SA_EMAIL ),
				self::ACCESS_TOKEN,
				3600
			);
		}
	}

	/**
	 * Todos os segredos configurados nesta classe, para os testes de
	 * vazamento afirmarem que nenhum aparece num texto.
	 *
	 * @return string[]
	 */
	private function all_secrets(): array {
		return array(
			self::keys()['private'],
			self::DEV_TOKEN,
			self::OAUTH_CLIENT_SECRET,
			self::OAUTH_REFRESH_TOKEN,
			self::ACCESS_TOKEN,
		);
	}

	private function assert_no_secret_in( string $haystack, string $context ): void {
		foreach ( $this->all_secrets() as $secret ) {
			$this->assertStringNotContainsString( $secret, $haystack, $context . ' vazou um segredo' );
		}

		// A chave privada é o segredo mais fácil de reconhecer mesmo se algum
		// dia deixar de ser gerada por este teste: o marcador PEM sozinho já
		// não pode aparecer em lugar nenhum.
		$this->assertStringNotContainsString( '-----BEGIN', $haystack, $context . ' vazou um marcador PEM' );
	}

	// =========================================================================
	// (a) Bootstrap real
	// =========================================================================

	public function test_categoria_google_e_registrada_pelo_init(): void {
		$this->assertTrue( wp_has_ability_category( 'google' ) );

		$category = wp_get_ability_category( 'google' );
		$this->assertNotNull( $category );
		$this->assertSame( 'google', $category->get_slug() );
		$this->assertNotSame( '', $category->get_label() );
	}

	public function test_exatamente_as_21_habilidades_esperadas_estao_registradas(): void {
		$this->assertCount( 21, self::EXPECTED_ABILITIES, 'a lista literal em si precisa ter 21 nomes' );

		$abilities = wp_get_abilities();

		$nossas = array_filter(
			array_keys( $abilities ),
			static function ( string $name ): bool {
				return 0 === strpos( $name, 'ga/' ) || 0 === strpos( $name, 'ads/' ) || 0 === strpos( $name, 'google/' );
			}
		);

		sort( $nossas );
		$esperadas = self::EXPECTED_ABILITIES;
		sort( $esperadas );

		$this->assertSame( array(), array_values( array_diff( $esperadas, $nossas ) ), 'a versão 0.2.0 preserva as 21 rotas da 0.1.0' );

		foreach ( self::EXPECTED_ABILITIES as $name ) {
			$this->assertNotNull( wp_get_ability( $name ), "habilidade ausente: $name" );
		}
	}

	/**
	 * @return array<string,array{0:string}>
	 */
	public static function provider_todas_as_habilidades(): array {
		$rows = array();
		foreach ( self::EXPECTED_ABILITIES as $name ) {
			$rows[ $name ] = array( $name );
		}

		return $rows;
	}

	/**
	 * @dataProvider provider_todas_as_habilidades
	 */
	public function test_cada_habilidade_segue_os_padroes_da_casa( string $name ): void {
		$ability = wp_get_ability( $name );
		$this->assertNotNull( $ability, $name );

		$meta = $ability->get_meta();
		$this->assertTrue( $meta['mcp']['public'] ?? false, "$name: meta.mcp.public" );
		$this->assertSame( 'tool', $meta['mcp']['type'] ?? null, "$name: meta.mcp.type" );
		$this->assertTrue( $meta['annotations']['readonly'] ?? false, "$name: meta.annotations.readonly" );
		$this->assertFalse( $meta['annotations']['destructive'] ?? true, "$name: meta.annotations.destructive" );

		// permission_callback existe e é chamável — testado indiretamente:
		// check_permissions() não deveria devolver null nem estourar.
		$this->assertIsBool( $ability->check_permissions( array() ), "$name: check_permissions() devolve bool" );

		$schema = $ability->get_input_schema();
		$this->assertSame( 'object', $schema['type'] ?? null, "$name: input_schema.type" );
		$this->assertFalse( $schema['additionalProperties'] ?? true, "$name: input_schema.additionalProperties" );

		$properties = array_keys( $schema['properties'] ?? array() );
		foreach ( (array) ( $schema['required'] ?? array() ) as $req ) {
			$this->assertContains( $req, $properties, "$name: required '$req' precisa estar em properties" );
		}

		$this->assertNotSame( '', trim( $ability->get_label() ), "$name: label não pode ser vazio" );
		$this->assertLessThanOrEqual( 400, strlen( $ability->get_description() ), "$name: description até 400 caracteres" );
		$this->assertNotSame( '', trim( $ability->get_description() ), "$name: description não pode ser vazia" );

		$output_schema = $ability->get_output_schema();
		$this->assertSame( 'object', $output_schema['type'] ?? null, "$name: output_schema.type" );
	}

	public function test_filtro_protected_options_devolve_todas_as_options_do_plugin(): void {
		$protected = apply_filters( 'wp_mcp_ultimate_protected_options', array() );

		$this->assertIsArray( $protected );

		$all = Options::all_names();
		sort( $all );
		$protected_sorted = $protected;
		sort( $protected_sorted );

		$this->assertSame( $all, $protected_sorted );

		// E precisa ser um acréscimo: um valor que já estivesse na lista de
		// outro plugin continua lá.
		$com_outro = apply_filters( 'wp_mcp_ultimate_protected_options', array( 'option_de_outro_plugin' ) );
		$this->assertContains( 'option_de_outro_plugin', $com_outro );
		foreach ( Options::all_names() as $name ) {
			$this->assertContains( $name, $com_outro );
		}
	}

	// =========================================================================
	// (b) Protocolo via o WP MCP Ultimate
	// =========================================================================

	public function test_discover_abilities_lista_as_21_rotas(): void {
		$result = wp_get_ability( 'wp-mcp-ultimate/discover-abilities' )->execute( array() );

		$this->assertArrayHasKey( 'abilities', $result );

		$by_name = array();
		foreach ( $result['abilities'] as $item ) {
			$this->assertArrayHasKey( 'name', $item );
			$this->assertArrayHasKey( 'label', $item );
			$this->assertArrayHasKey( 'description', $item );
			$by_name[ $item['name'] ] = $item;
		}

		foreach ( self::EXPECTED_ABILITIES as $name ) {
			$this->assertArrayHasKey( $name, $by_name, "discover-abilities não trouxe $name" );
			$this->assertNotSame( '', $by_name[ $name ]['label'] );
			$this->assertNotSame( '', $by_name[ $name ]['description'] );
		}
	}

	public function test_discover_abilities_recusa_usuario_sem_capacidade(): void {
		$GLOBALS['f3_test_caps'] = array();

		$ability   = wp_get_ability( 'wp-mcp-ultimate/discover-abilities' );
		$permitido = $ability->check_permissions( array() );

		// O `check_permission` do Ultimate devolve um WP_Error (não `false`)
		// quando falta capacidade — o polyfill repassa o valor cru do
		// permission_callback sem convertê-lo para bool.
		$this->assertTrue( is_wp_error( $permitido ) || false === $permitido );
	}

	public function test_get_ability_info_de_ga_run_report_devolve_o_input_schema(): void {
		$result = wp_get_ability( 'wp-mcp-ultimate/get-ability-info' )->execute(
			array( 'ability_name' => 'ga/run-report' )
		);

		$this->assertSame( 'ga/run-report', $result['name'] );
		$this->assertArrayHasKey( 'input_schema', $result );
		$this->assertSame( 'object', $result['input_schema']['type'] );

		$properties = array_keys( $result['input_schema']['properties'] );
		foreach ( array( 'date_ranges', 'dimensions', 'metrics', 'property_id' ) as $expected_param ) {
			$this->assertContains( $expected_param, $properties );
		}

		$this->assertSame( array( 'date_ranges', 'dimensions', 'metrics' ), $result['input_schema']['required'] );
	}

	public function test_get_ability_info_de_rota_inexistente_devolve_erro(): void {
		$result = wp_get_ability( 'wp-mcp-ultimate/get-ability-info' )->execute(
			array( 'ability_name' => 'ga/nao-existe' )
		);

		$this->assertArrayHasKey( 'error', $result );
	}

	/**
	 * O caminho que o Cowork usa de verdade: `parameters` chega como STRING
	 * JSON, não como array — `ExecuteAbilityAbility::normalize_parameters()`
	 * decodifica antes de checar permissão e antes de executar.
	 */
	public function test_execute_ability_com_parametros_como_string_json(): void {
		$this->enable_all_with_real_secrets();

		FakeHttp::push(
			'analyticsdata',
			200,
			array(
				'dimensionHeaders' => array( array( 'name' => 'date' ) ),
				'metricHeaders'    => array( array( 'name' => 'sessions', 'type' => 'TYPE_INTEGER' ) ),
				'rows'             => array(
					array(
						'dimensionValues' => array( array( 'value' => '20260901' ) ),
						'metricValues'    => array( array( 'value' => '10' ) ),
					),
				),
				'rowCount'         => 1,
			)
		);

		$parametros_json = (string) wp_json_encode(
			array(
				'connector'  => 'ga4',
				'accounts'   => array( '123456789' ),
				'metrics'    => array( 'sessions' ),
				'dimensions' => array( 'date' ),
				'date_range' => array( 'preset' => 'yesterday' ),
			)
		);

		$result = wp_get_ability( 'wp-mcp-ultimate/execute-ability' )->execute(
			array(
				'ability_name' => 'google/query',
				'parameters'   => $parametros_json,
			)
		);

		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$this->assertIsArray( $result['data'] );
		$this->assertTrue( $result['data']['success'] );
		$this->assertSame( 1, $result['data']['row_count'] );
		$this->assertSame( array( '2026-09-01', 10 ), $result['data']['rows'][0] );
	}

	/**
	 * `google/status` não pede nenhum parâmetro; `parameters: {}` (objeto
	 * vazio, ou array vazio depois do `json_decode`) precisa funcionar sem o
	 * núcleo exigir nada além disso.
	 */
	public function test_execute_ability_com_parametros_vazios_funciona(): void {
		$this->enable_all_with_real_secrets();

		$result = wp_get_ability( 'wp-mcp-ultimate/execute-ability' )->execute(
			array(
				'ability_name' => 'google/status',
				'parameters'   => array(),
			)
		);

		$this->assertTrue( $result['success'], (string) wp_json_encode( $result ) );
		$this->assertTrue( $result['data']['success'] );
	}

	public function test_execute_ability_com_canal_fechado_devolve_erro_de_permissao(): void {
		$this->enable_all_with_real_secrets();
		Options::set( Options::ENABLED, false );

		$result = wp_get_ability( 'wp-mcp-ultimate/execute-ability' )->execute(
			array(
				'ability_name' => 'ga/run-report',
				'parameters'   => '{}',
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertArrayHasKey( 'error', $result );
		$this->assertNotSame( '', $result['error'] );
	}

	/**
	 * O `check_permission` do Ultimate só exige `edit_posts` (ou o que o
	 * filtro `wp_mcp_ultimate_execute_ability_capability` disser); quem
	 * recusa um editor sem `manage_options` é o NOSSO portão
	 * (`Gate::permission()`, chamado por dentro de `$ability->check_permissions()`).
	 */
	public function test_usuario_com_edit_posts_mas_sem_manage_options_e_recusado_pelo_nosso_portao(): void {
		$this->enable_all_with_real_secrets();
		$GLOBALS['f3_test_caps'] = array(
			'edit_posts'     => true,
			'manage_options' => false,
		);

		// O Ultimate deixaria passar (edit_posts basta para ele); confirma
		// isso antes de provar que quem barra é o nosso lado.
		$permite_o_ultimate = current_user_can( 'edit_posts' );
		$this->assertTrue( $permite_o_ultimate );

		$ability = wp_get_ability( 'ga/run-report' );
		$this->assertFalse( $ability->check_permissions( array() ), 'Gate::permission exige manage_options' );

		$result = wp_get_ability( 'wp-mcp-ultimate/execute-ability' )->execute(
			array(
				'ability_name' => 'ga/run-report',
				'parameters'   => '{}',
			)
		);

		$this->assertFalse( $result['success'] );
		$this->assertArrayHasKey( 'error', $result );
	}

	/**
	 * Padrão da casa: o envelope EXTERNO (`execute-ability`) só diz que a
	 * chamada chegou e rodou; o resultado de negócio vai em `data`, com seu
	 * próprio `success`. Sem `property_id` e sem propriedade padrão
	 * configurada, `ga/run-report` SABE rodar (o portão libera — é erro de
	 * entrada, não de permissão) e devolve uma mensagem clara por dentro.
	 */
	public function test_execute_ability_sem_property_id_e_sem_padrao_falha_por_dentro_nao_por_fora(): void {
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'service_account' );
		Options::set_secret(
			Options::SA_JSON,
			(string) wp_json_encode(
				array(
					'type'         => 'service_account',
					'project_id'   => 'projeto-integracao',
					'private_key'  => self::keys()['private'],
					'client_email' => self::SA_EMAIL,
					'token_uri'    => 'https://oauth2.googleapis.com/token',
				)
			)
		);
		// Sem Options::GA_DEFAULT_PROPERTY — o ponto do teste.

		$result = wp_get_ability( 'wp-mcp-ultimate/execute-ability' )->execute(
			array(
				'ability_name' => 'ga/run-report',
				'parameters'   => (string) wp_json_encode(
					array(
						'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
						'dimensions'  => array( 'date' ),
						'metrics'     => array( 'sessions' ),
					)
				),
			)
		);

		$this->assertTrue( $result['success'], 'envelope externo: a chamada chegou e rodou' );
		$this->assertIsArray( $result['data'] );
		$this->assertFalse( $result['data']['success'], 'envelope interno: faltou property_id' );
		$this->assertNotSame( '', $result['data']['message'] );
		$this->assertStringContainsString( 'property_id', $result['data']['message'] );

		// E nenhuma requisição HTTP pode ter saído: faltou entrada antes de
		// chegar perto da rede.
		$this->assertSame( 0, FakeHttp::count() );
	}

	// =========================================================================
	// (c) Vazamento de segredo pelas 21 rotas
	// =========================================================================

	/**
	 * @return array<int,array>
	 */
	private function inputs_por_habilidade(): array {
		return array(
			'ga/get-account-summaries'      => array(),
			'ga/get-property-details'       => array(),
			'ga/list-google-ads-links'      => array(),
			'ga/list-property-annotations'  => array(),
			'ga/get-metadata'               => array(),
			'ga/check-compatibility'        => array(
				'dimensions' => array( 'date' ),
				'metrics'    => array( 'sessions' ),
			),
			'ga/run-report'                 => array(
				'date_ranges' => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'  => array( 'date' ),
				'metrics'     => array( 'sessions' ),
			),
			'ga/run-realtime-report'        => array(
				'dimensions' => array( 'country' ),
				'metrics'    => array( 'activeUsers' ),
			),
			'ga/run-conversions-report'     => array(
				'date_ranges'     => array( array( 'startDate' => '7daysAgo', 'endDate' => 'yesterday' ) ),
				'dimensions'      => array( 'campaignName' ),
				'metrics'         => array( 'advertiserAdCost' ),
				'conversion_spec' => array( 'conversion_actions' => array( 'purchase' ) ),
			),
			'ga/run-funnel-report'          => array(
				'funnel_steps' => array( array( 'name' => 'Início', 'event' => 'session_start' ) ),
			),
			'ads/list-accessible-customers' => array(),
			'ads/get-customer'              => array( 'customer_id' => '1234567890' ),
			'ads/search'                    => array(
				'customer_id' => '1234567890',
				'query'       => 'SELECT campaign.id, campaign.name FROM campaign',
			),
			'ads/get-resource-metadata'     => array( 'resource_name' => 'campaign' ),
			'ads/list-resources'            => array( 'query' => 'campaign' ),
			'ads/list-customer-clients'     => array( 'manager_customer_id' => '1234567890' ),
			'google/status'                 => array(),
			'google/selftest'               => array(),
			'google/list-accounts'          => array( 'connector' => 'all' ),
			'google/list-fields'            => array( 'connector' => 'ga4' ),
			'google/query'                  => array(
				'connector'  => 'ga4',
				'accounts'   => array( '123456789' ),
				'metrics'    => array( 'sessions' ),
				'dimensions' => array( 'date' ),
				'date_range' => array( 'preset' => 'yesterday' ),
			),
		);
	}

	/**
	 * Fila generosa de respostas: a maioria um "sucesso" vazio (todas as
	 * chaves de topo que qualquer uma das três APIs poderia esperar, cada uma
	 * com lista vazia — toda rota decodifica isso sem erro e sem linha
	 * nenhuma) e um terço delas um erro 400/403 cujo `error.message` ecoa o
	 * cabeçalho Authorization desta chamada — exatamente o jeito como uma API
	 * mal comportada (ou um proxy de depuração) devolveria a própria
	 * requisição. O ponto não é testar o resultado de negócio de cada rota
	 * (isso é papel de AnalyticsTest/AdsTest/UnifiedTest) — é rodar as 21 com
	 * uma mistura de sucesso e erro e provar que o access token não escapa
	 * por nenhum dos dois caminhos.
	 */
	private function abastecer_fila_generica( int $quantidade ): void {
		$sucesso = array(
			'accountSummaries' => array(),
			'googleAdsLinks'   => array(),
			'annotations'      => array(),
			'dimensionHeaders' => array(),
			'metricHeaders'    => array(),
			'rows'             => array(),
			'rowCount'         => 0,
			'dimensions'       => array(),
			'metrics'          => array(),
			'results'          => array(),
			'resourceNames'    => array(),
			'fields'           => array(),
		);

		$erro_adversario = array(
			'error' => array(
				'code'    => 403,
				'status'  => 'PERMISSION_DENIED',
				'message' => 'Blocked by edge proxy. Echo of request headers: Authorization: Bearer ' . self::ACCESS_TOKEN,
				'details' => array(
					array(
						'@type'  => 'type.googleapis.com/google.ads.googleads.v25.errors.GoogleAdsFailure',
						'errors' => array(
							array(
								'errorCode' => array( 'authorizationError' => 'AUTHENTICATION_ERROR' ),
								'message'   => 'debug echo Authorization=Bearer ' . self::ACCESS_TOKEN,
							),
						),
						'requestId' => 'req-adversario-teste',
					),
				),
			),
		);

		for ( $i = 0; $i < $quantidade; $i++ ) {
			if ( 0 === $i % 3 ) {
				FakeHttp::push( '*', 403, $erro_adversario );
			} else {
				FakeHttp::push( '*', 200, $sucesso );
			}
		}
	}

	public function test_nenhuma_das_21_rotas_vaza_segredo_mesmo_com_erro_adversario(): void {
		$this->enable_all_with_real_secrets();
		Audit::clear();

		$this->abastecer_fila_generica( 80 );

		$inputs    = $this->inputs_por_habilidade();
		$this->assertSame(
			self::EXPECTED_ABILITIES,
			array_keys( $inputs ),
			'a lista de entradas precisa cobrir exatamente as 21 rotas, na mesma ordem'
		);

		$todas_as_respostas = array();

		foreach ( $inputs as $name => $params ) {
			$ability = wp_get_ability( $name );
			$this->assertNotNull( $ability, $name );

			$result = $ability->execute( $params );
			$this->assertIsArray( $result, "$name: execute() precisa devolver array, nunca estourar" );
			$this->assertArrayHasKey( 'success', $result, $name );

			$todas_as_respostas[ $name ] = $result;

			// Falha aqui já aponta exatamente qual rota vazou o quê.
			$this->assert_no_secret_in( (string) wp_json_encode( $result ), "resposta de $name" );
		}

		// E de novo, tudo junto — cobre o caso de um segredo partido entre
		// duas chaves que só apareceria concatenado.
		$this->assert_no_secret_in( (string) wp_json_encode( $todas_as_respostas ), 'o conjunto das 21 respostas' );

		// O log de auditoria só guarda escalares curtos (ver Audit::clean_extra),
		// mas o teste confere o que de fato foi gravado, não a promessa.
		$auditoria = Audit::recent( 100 );
		$this->assertNotEmpty( $auditoria, 'as 21 chamadas deveriam ter deixado rastro no log' );
		$this->assert_no_secret_in( (string) wp_json_encode( $auditoria ), 'Audit::recent()' );
	}

	// =========================================================================
	// (d) uninstall.php
	// =========================================================================

	private function options_preenchidas_para_desinstalar(): void {
		foreach ( Options::all_names() as $name ) {
			// delete_option ignora quem não existe; popular todas garante que
			// o teste prova que TODAS somem, não só as que o resto do teste
			// já tivesse tocado.
			$GLOBALS['f3_test_options'][ $name ] = 'valor-' . $name;
		}
	}

	public function test_uninstall_apaga_todas_as_options_e_emite_a_query_de_transients(): void {
		if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
			define( 'WP_UNINSTALL_PLUGIN', true );
		}

		$this->options_preenchidas_para_desinstalar();
		$GLOBALS['f3_test_multisite'] = false;

		$wpdb = new \F3_Test_Wpdb();
		$GLOBALS['wpdb'] = $wpdb;

		require F3_MCP_GOOGLE_DIR . 'uninstall.php';

		foreach ( Options::all_names() as $name ) {
			$this->assertArrayNotHasKey( $name, $GLOBALS['f3_test_options'], "uninstall.php deveria ter apagado $name" );
		}

		$this->assertNotEmpty( $wpdb->queries, 'a faxina de transients precisa emitir ao menos uma query' );

		$sql = implode( "\n", $wpdb->queries );
		$this->assertStringContainsString( $wpdb->options, $sql );
		// esc_like() escapa "_" e "%"; prepare() escapa de novo (addslashes)
		// ao encaixar em "%s". Compara com as duas camadas, em vez de supor
		// uma sintaxe exata de escape.
		$this->assertStringContainsString( addslashes( $wpdb->esc_like( '_transient_f3_mcp_google_' ) ), $sql );
		$this->assertStringContainsString( addslashes( $wpdb->esc_like( '_transient_timeout_f3_mcp_google_' ) ), $sql );

		// Sem multisite, a tabela de sitemeta não precisa ser tocada.
		$this->assertStringNotContainsString( $wpdb->sitemeta, $sql );

		unset( $GLOBALS['wpdb'] );
	}

	public function test_uninstall_tambem_limpa_sitemeta_em_multisite(): void {
		if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
			define( 'WP_UNINSTALL_PLUGIN', true );
		}

		$this->options_preenchidas_para_desinstalar();
		$GLOBALS['f3_test_multisite'] = true;

		$wpdb = new \F3_Test_Wpdb();
		$GLOBALS['wpdb'] = $wpdb;

		require F3_MCP_GOOGLE_DIR . 'uninstall.php';

		$sql = implode( "\n", $wpdb->queries );
		$this->assertStringContainsString( $wpdb->sitemeta, $sql );
		$this->assertStringContainsString( addslashes( $wpdb->esc_like( '_site_transient_f3_mcp_google_' ) ), $sql );

		unset( $GLOBALS['wpdb'] );
		$GLOBALS['f3_test_multisite'] = false;
	}

	// =========================================================================
	// (e) Compatibilidade PHP 8.0
	// =========================================================================

	/**
	 * @return string[] Caminhos absolutos.
	 */
	private static function arquivos_de_includes(): array {
		$arquivos = array();
		$iterator = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( dirname( __DIR__ ) . '/includes', \FilesystemIterator::SKIP_DOTS ) );

		foreach ( $iterator as $file ) {
			if ( $file->isFile() && 'php' === strtolower( $file->getExtension() ) ) {
				$arquivos[] = $file->getPathname();
			}
		}

		sort( $arquivos );

		return $arquivos;
	}

	public function test_nenhum_arquivo_de_includes_usa_sintaxe_so_de_php_81_mais(): void {
		$arquivos   = self::arquivos_de_includes();
		$arquivos[] = F3_MCP_GOOGLE_FILE;

		$this->assertGreaterThanOrEqual( 29, count( $arquivos ) - 1, 'sanidade: includes/ deveria ter pelo menos as classes conhecidas' );

		foreach ( $arquivos as $caminho ) {
			$achados = self::sintaxe_php81_em( $caminho );
			$this->assertSame( array(), $achados, $caminho . ': ' . implode( '; ', $achados ) );
		}
	}

	/**
	 * Varre um arquivo com `token_get_all` procurando quatro assinaturas de
	 * sintaxe que só existem a partir do PHP 8.1: `enum`, `readonly`, `never`
	 * como tipo de retorno, callable de primeira classe `foo(...)` e `new` num
	 * inicializador (valor padrão de parâmetro). `php -l` sob o PHP 8.4 desta
	 * máquina não detecta nada disto — 8.4 entende 8.1+ nativamente — então
	 * esta é a única rede de segurança contra alguém introduzir sintaxe nova
	 * demais para o `Requires PHP: 8.0` do cabeçalho do plugin.
	 *
	 * @return string[] Descrição de cada achado; vazio quando o arquivo está limpo.
	 */
	private static function sintaxe_php81_em( string $caminho ): array {
		$code   = (string) file_get_contents( $caminho );
		$tokens = token_get_all( $code );

		// Só os tokens que carregam significado sintático; espaço e
		// comentário nunca decidem se algo é sintaxe nova ou não, e mantê-los
		// só obrigaria a pular espaço em cada checagem de vizinhança abaixo.
		$sig = array();
		foreach ( $tokens as $t ) {
			if ( is_array( $t ) ) {
				if ( in_array( $t[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true ) ) {
					continue;
				}
				$sig[] = array( 'id' => $t[0], 'text' => $t[1], 'line' => $t[2] );
			} else {
				$sig[] = array( 'id' => null, 'text' => $t, 'line' => 0 );
			}
		}

		$achados     = array();
		$paren_stack = array();

		$count = count( $sig );
		for ( $i = 0; $i < $count; $i++ ) {
			$tok = $sig[ $i ];

			// 1) enum ...  {  — token dedicado, só existe para uma declaração
			// de enum de verdade (não para a palavra "enum" dentro de string
			// ou comentário, que já ficaram de fora de $sig).
			if ( T_ENUM === $tok['id'] ) {
				$achados[] = 'enum (linha ' . $tok['line'] . ')';
			}

			// 2) readonly como modificador de propriedade/classe.
			if ( defined( 'T_READONLY' ) && T_READONLY === $tok['id'] ) {
				$achados[] = 'readonly (linha ' . $tok['line'] . ')';
			}

			// 3) ": never" como tipo de retorno — a vírgula/parêntese que
			// fecha a lista de parâmetros sempre vem logo antes do ':' do
			// tipo de retorno na gramática do PHP.
			if ( null === $tok['id'] && ')' === $tok['text']
				&& isset( $sig[ $i + 1 ], $sig[ $i + 2 ] )
				&& null === $sig[ $i + 1 ]['id'] && ':' === $sig[ $i + 1 ]['text']
				&& T_STRING === $sig[ $i + 2 ]['id'] && 'never' === strtolower( $sig[ $i + 2 ]['text'] )
			) {
				$achados[] = 'never como tipo de retorno (linha ' . $sig[ $i + 2 ]['line'] . ')';
			}

			// 4) callable de primeira classe: "(" "..." ")" sem variável
			// nenhuma no meio — variádico de verdade sempre tem "...$nome".
			if ( T_ELLIPSIS === $tok['id']
				&& isset( $sig[ $i - 1 ], $sig[ $i + 1 ] )
				&& null === $sig[ $i - 1 ]['id'] && '(' === $sig[ $i - 1 ]['text']
				&& null === $sig[ $i + 1 ]['id'] && ')' === $sig[ $i + 1 ]['text']
			) {
				$achados[] = 'callable de primeira classe (...)  (linha ' . $tok['line'] . ')';
			}

			// Empilha se este "(" abre a lista de parâmetros de uma função —
			// função nomeada, método ou closure ("function ("), ou arrow
			// function ("fn("). Uma chamada comum ("foo(", "self::bar(") não
			// empilha como declaração.
			if ( null === $tok['id'] && '(' === $tok['text'] ) {
				$anterior    = $sig[ $i - 1 ] ?? null;
				$eh_funcao   = null !== $anterior && ( T_FUNCTION === $anterior['id'] || T_FN === ( $anterior['id'] ?? null ) );
				$duplo_atras = $sig[ $i - 2 ] ?? null;
				$eh_metodo   = null !== $anterior && T_STRING === $anterior['id']
					&& null !== $duplo_atras && T_FUNCTION === $duplo_atras['id'];

				$paren_stack[] = $eh_funcao || $eh_metodo;
			} elseif ( null === $tok['id'] && ')' === $tok['text'] ) {
				array_pop( $paren_stack );
			}

			// 5) "new" logo depois de um "=" dentro de uma lista de
			// parâmetros de DECLARAÇÃO — valor padrão de parâmetro, que só
			// aceita uma expressão com `new` a partir do PHP 8.1. Uma
			// atribuição comum ("$x = new Y();", fora de toda lista de
			// parâmetros de declaração) continua de fora porque a pilha está
			// vazia ou o topo dela não é uma declaração.
			if ( T_NEW === $tok['id']
				&& isset( $sig[ $i - 1 ] )
				&& null === $sig[ $i - 1 ]['id'] && '=' === $sig[ $i - 1 ]['text']
				&& ! empty( $paren_stack ) && true === end( $paren_stack )
			) {
				$achados[] = 'new em valor padrão de parâmetro (linha ' . $tok['line'] . ')';
			}
		}

		return $achados;
	}

	public function test_todo_arquivo_de_includes_tem_strict_types_e_guarda_de_abspath(): void {
		$arquivos = self::arquivos_de_includes();
		$this->assertNotEmpty( $arquivos );

		foreach ( $arquivos as $caminho ) {
			$conteudo = (string) file_get_contents( $caminho );
			$relativo = str_replace( dirname( __DIR__ ) . '/', '', $caminho );

			$this->assertMatchesRegularExpression(
				'/declare\s*\(\s*strict_types\s*=\s*1\s*\)\s*;/',
				$conteudo,
				"$relativo: falta declare(strict_types=1)"
			);

			$this->assertStringContainsString(
				"defined( 'ABSPATH' )",
				$conteudo,
				"$relativo: falta a guarda de ABSPATH"
			);
		}
	}
}
