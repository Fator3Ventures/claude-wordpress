<?php
/** Regressões do núcleo 0.2.0 com fronteiras reais do plugin e HTTP simulado. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Tests;
use Fator3\McpGoogle\{Ability,Audit,Gate,Options,Plugin,Response};
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Unified\{Accounts,Query};
use PHPUnit\Framework\TestCase;

final class UpdateCoreTest extends TestCase {
	protected function setUp(): void {
		$GLOBALS['f3_test_options'] = array();
		$GLOBALS['f3_test_transients'] = array();
		$GLOBALS['f3_test_caps'] = true;
		FakeHttp::reset();
		Options::set( Options::ENABLED, true );
		Options::set( Options::GA_ENABLED, true );
		Options::set( Options::ADS_ENABLED, true );
		Options::set( Options::AUTH_MODE, 'oauth' );
		Options::set( Options::OAUTH_CLIENT_ID, 'local-client.apps.googleusercontent.com' );
		Options::set( Options::OAUTH_EMAIL, 'local@example.test' );
		Options::set_secret( Options::OAUTH_CLIENT_SECRET, 'local-client-secret-12345' );
		Options::set_secret( Options::OAUTH_REFRESH_TOKEN, 'local-refresh-token-12345' );
		Options::set_secret( Options::ADS_DEVELOPER_TOKEN, 'local-developer-token-12345' );
		foreach ( array( 'ga','ads','gsc','siteverification','sheets','drive','any' ) as $service ) {
			Credentials::remember( Credentials::cache_key( Credentials::scopes_for( $service ) ), 'local-access-token-12345', 3600 );
		}
		Plugin::register_abilities();
	}

	public function test_new_services_share_capability_and_kill_switch(): void {
		foreach ( array( 'ga','ads','gsc','siteverification','sheets','drive' ) as $service ) {
			$this->assertTrue( Gate::permission( $service ), $service );
			$this->assertNull( Gate::check( $service ), $service );
		}
		Options::set( Options::GA_ENABLED, false ); Options::set( Options::ADS_ENABLED, false );
		$this->assertTrue( Gate::permission( 'gsc' ) );
		$this->assertTrue( Gate::permission( 'any' ) );
		$GLOBALS['f3_test_caps'] = false;
		foreach ( wp_get_abilities() as $ability ) {
			if ( 'google' !== $ability->get_category() ) { continue; }
			$this->assertNotTrue( $ability->check_permissions( array() ), $ability->get_name() );
		}
		$GLOBALS['f3_test_caps'] = true; Options::set( Options::ENABLED, false );
		foreach ( wp_get_abilities() as $ability ) {
			if ( 'google' === $ability->get_category() ) { $this->assertNotTrue( $ability->check_permissions( array() ), $ability->get_name() ); }
		}
		$this->assertSame( 0, FakeHttp::count() );
	}

	public function test_write_audits_real_snapshots_bounded_and_redacted(): void {
		Ability::register( 'google/test-v02-write', 'any', array( 'mode' => 'write', 'callback' => static function (): array {
			Audit::before( array( 'displayName' => 'Antes', 'secretValue' => 'cannot-persist' ) );
			Audit::after( array( 'displayName' => 'Depois', 'private_key' => 'cannot-persist', 'large' => str_repeat( 'á', 10000 ) ) );
			return Response::ok();
		} ) );
		$a = wp_get_ability( 'google/test-v02-write' );
		$this->assertFalse( $a->get_meta()['annotations']['readonly'] );
		$this->assertTrue( $a->get_meta()['annotations']['destructive'] );
		$this->assertFalse( $a->get_meta()['annotations']['idempotent'] );
		$this->assertTrue( $a->execute( array() )['success'] );
		$entry = Audit::recent(1)[0]['extra'];
		$this->assertSame( 'Antes', $entry['before']['displayName'] );
		$this->assertTrue( $entry['after']['truncated'] );
		$this->assertLessThanOrEqual( 4096, strlen( wp_json_encode( $entry['after'] ) ) );
		$this->assertStringNotContainsString( 'cannot-persist', wp_json_encode( $entry ) );
		$this->assertFalse( $entry['dry_run'] );
		$this->assertSame( 'write', $entry['mode'] );
	}

	public function test_failed_write_also_has_before_and_after(): void {
		Ability::register( 'google/test-v02-throw', 'any', array( 'mode'=>'write', 'callback'=>static function () { throw new \RuntimeException( 'local-refresh-token-12345' ); } ) );
		$this->assertFalse( wp_get_ability('google/test-v02-throw')->execute(array())['success'] );
		$extra=Audit::recent(1)[0]['extra'];
		$this->assertArrayHasKey('before',$extra);$this->assertArrayHasKey('after',$extra);
		$this->assertFalse($extra['before']['available']);
		$this->assertStringNotContainsString('local-refresh-token-12345',wp_json_encode($extra));
	}

	public function test_http_write_is_not_retried_and_new_hosts_are_allowed(): void {
		foreach ( array( 'searchconsole.googleapis.com','www.googleapis.com','sheets.googleapis.com','www.google-analytics.com' ) as $host ) {
			FakeHttp::push( $host, 503, array( 'error'=>array('message'=>'temporarily unavailable') ) );
			$r=GoogleClient::request('POST','https://'.$host.'/test',array(),array('auth'=>false,'mode'=>'write','retries'=>2));
			$this->assertTrue(is_wp_error($r));$this->assertSame('f3_google_http',$r->get_error_code());
		}
		$this->assertSame(4,FakeHttp::count());
		$this->assertSame('{}',FakeHttp::last()['body']);
	}

	public function test_error_echo_is_scrubbed_even_on_public_discovery(): void {
		FakeHttp::push( 'www.googleapis.com',403,array('error'=>array('message'=>'debug local-access-token-12345')) );
		$r=GoogleClient::request('GET','https://www.googleapis.com/discovery/v1/test',null,array('auth'=>false));
		$this->assertStringNotContainsString('local-access-token-12345',wp_json_encode(Response::fail($r)));
	}

	public function test_google_repeated_query_booleans_and_binary_download(): void {
		FakeHttp::push('www.googleapis.com',200,'a,b\n1,2',array('content-type'=>'text/csv'));
		$r=GoogleClient::get('https://www.googleapis.com/drive/v3/files/x/export',array('fields'=>array('id','name'),'supportsAllDrives'=>true),array('auth'=>false));
		$this->assertStringContainsString('fields=id&fields=name&supportsAllDrives=true',FakeHttp::last()['url']);
		$this->assertSame('a,b\n1,2',base64_decode($r['content_base64']));
	}

	private function accounts_fixture( array $properties ): void {
		FakeHttp::push('analyticsadmin.googleapis.com',200,array('accountSummaries'=>array(array('displayName'=>'Conta','propertySummaries'=>$properties))));
	}

	public function test_account_names_are_unique_and_wildcard_is_complete(): void {
		$properties=array();for($i=1;$i<=30;$i++){$properties[]=array('property'=>'properties/'.$i,'displayName'=>$i<3?'Mesmo':'Site '.$i);}
		$this->accounts_fixture($properties);
		$r=Accounts::resolve_many('ga',array('Mesmo'));
		$this->assertSame('f3_google_account_ambiguous',$r->get_error_code());
		$this->assertCount(2,$r->get_error_data()['candidates']);
		$this->assertSame(array('properties/3'),Accounts::resolve_many('ga',array('site 3')));
		$this->assertCount(30,Accounts::resolve_many('ga',array('*')));
		for ( $i=1; $i<=30; $i++ ) { FakeHttp::push( 'properties/'.$i.':runReport', 200, array( 'metricHeaders'=>array(array('name'=>'sessions','type'=>'TYPE_INTEGER')), 'rows'=>array(array('metricValues'=>array(array('value'=>'1')))), 'rowCount'=>1 ) ); }
		$result=Query::run(array('connector'=>'ga4','accounts'=>array('*'),'metrics'=>array('sessions'),'date_range'=>'yesterday'));
		$this->assertTrue($result['success'], $result['message']);
		$this->assertCount(30,$result['accounts']);
		$this->assertSame(30,$result['row_count']);
	}

	public function test_switching_credentials_does_not_reuse_account_catalog(): void {
		$this->accounts_fixture(array(array('property'=>'properties/1','displayName'=>'Antiga')));
		$this->assertSame(array('properties/1'),Accounts::resolve_many('ga',array('Antiga')));
		Options::set(Options::OAUTH_EMAIL,'new@example.test');
		FakeHttp::push('oauth2.googleapis.com',200,array('access_token'=>'new-local-access-token','expires_in'=>3600));
		$this->accounts_fixture(array(array('property'=>'properties/2','displayName'=>'Nova')));
		$this->assertSame(array('properties/2'),Accounts::resolve_many('ga',array('Nova')));
		$this->assertSame('f3_google_account_not_found',Accounts::resolve_many('ga',array('Antiga'))->get_error_code());
	}

	public function test_status_does_not_infer_api_enablement_from_token(): void {
		$r=\Fator3\McpGoogle\Unified\Abilities::status(array('live'=>true));
		$this->assertTrue($r['token_ok']['ga']);
		$this->assertNull($r['api_status']['analytics-admin']['enabled']);
		$this->assertNotEmpty($r['scopes_requested']);
		FakeHttp::push('analyticsadmin.googleapis.com',403,array('error'=>array('status'=>'PERMISSION_DENIED','details'=>array(array('reason'=>'SERVICE_DISABLED')))));
		GoogleClient::get('https://analyticsadmin.googleapis.com/v1alpha/accountSummaries',array(),array('scopes'=>Credentials::scopes_for('ga')));
		$this->assertFalse(GoogleClient::api_status()['analytics-admin']['enabled']);
	}
	public function test_aliases_do_not_duplicate_accounts_and_numeric_fanout_finishes(): void {
		$this->assertSame( array('1234567890'), Accounts::resolve_many('ads',array('123-456-7890','customers/1234567890','1234567890')) );
		$this->assertSame( array('properties/123'), Accounts::resolve_many('ga',array('123','properties/123')) );
		set_transient(Query::ACCOUNTS_CACHE.'ads_mcc_'.Credentials::identity_key(),array(array('account_id'=>'1111111111','name'=>'One'),array('account_id'=>'2222222222','name'=>'Two')),600);
		$executed=array();
		Ability::register('ads/test-v02-fanout','ads',array('mode'=>'write','input_schema'=>array('properties'=>array('customer_id'=>array('type'=>'string'))),'callback'=>static function(array $input) use (&$executed):array {
			$executed[]=$input['customer_id']; Audit::before(array('exists'=>false)); Audit::after(array('resource'=>$input['customer_id'])); return Response::ok();
		}));
		$r=wp_get_ability('ads/test-v02-fanout')->execute(array('customer_id'=>'*'));
		$this->assertTrue($r['success'],$r['message']);$this->assertSame(array('1111111111','2222222222'),$executed);$this->assertCount(2,$r['results']);
		$entries=Audit::recent(3);$this->assertCount(3,$entries);$this->assertSame('write',$entries[1]['extra']['mode']);$this->assertSame('2222222222',$entries[1]['target']);
	}

}
