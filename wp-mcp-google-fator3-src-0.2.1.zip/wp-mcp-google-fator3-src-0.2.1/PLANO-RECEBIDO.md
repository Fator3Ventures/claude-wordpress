# WP MCP Google Fator3 0.2.0 — plano único: acesso total do agente aos serviços Google

Data: 07/09/2026. Tudo numa versão só. Só plano; nada implementado. Base:
0.1.0 instalada em `fator3-teste-mcp-1.dreamhosters.com`, GA4 verificado ao
vivo.

## 0. Escopo

O plugin é um servidor de habilidades MCP que dá ao agente acesso às APIs
da Google — Google Analytics 4 (Data e Admin), Google Ads, Search Console,
Site Verification, Sheets e Drive — em leitura e escrita, com a mesma
abrangência do Porter Metrics para essas fontes. Nada além disso.

- Conectada a credencial, toda ação que a API oferece está disponível: sem lista de exclusão, sem interruptor de escrita, sem confirmação em duas fases, sem reversão. Cada rota executa o que recebeu.
- Dois níveis de rota, como no Porter: nomeadas para as operações comuns e genéricas (`google/list-actions` + `google/execute-action`) que alcançam qualquer método das APIs. O que não tiver rota nomeada é alcançável pela genérica.
- Fica no plugin, por ser diagnóstico: auditoria com `before`/`after` em toda gravação; `dry_run: true` opcional no Ads (`validateOnly` da API); erros da Google traduzidos para a ação que falta. O kill switch geral e a capacidade `manage_options` vêm da 0.1.0 e não mudam.
- Uma credencial (service account) por site. Que papéis ela tem em cada serviço é responsabilidade de quem a cria e a atribui; o plugin usa o que ela puder.
- Confirmar com o usuário antes de gravar é regra da skill `wp-google`, não do plugin.

**Fora do plugin, e onde fica** (seção 2): tag GA4 e consentimento no site,
ponte de eventos, onboarding de site novo, consultas salvas e agendamentos,
relatórios hospedados, modelos de Looker Studio, padrão de eventos.

## 1. Inventário da 0.2.0

Contagem-alvo: 21 rotas existentes + as novas listadas abaixo. A contagem
final sai do `discover-abilities` na entrega, não deste documento.

### 1.1 Núcleo

| Mudança | Detalhe |
|---|---|
| `Ability::register( $name, $connector, $args )` ganha `mode` | `read` (padrão) ou `write`; `write` marca `meta.annotations.readonly=false, destructive=true` e grava `before`/`after` na auditoria. Portão igual ao da leitura |
| Escopos da service account | `analytics.edit`, `adwords`, `webmasters`, `siteverification`, `spreadsheets`, `drive.file` |
| Hosts permitidos | + `searchconsole.googleapis.com`, `www.googleapis.com`, `sheets.googleapis.com`, `www.google-analytics.com` |
| Auditoria | entradas de escrita com `before`/`after` (limitados em tamanho), `dry_run`, resultado; rota `google/audit` (leitura do log com filtros) |
| Resolução de conta | `accounts: ["*"]` e **nome** (casamento único contra `google/list-accounts`; ambíguo → recusa listando candidatos) em `google/query`, `google/blend` e nas rotas `ga/*`, `ads/*`, `gsc/*` |
| Catálogo Ads | conversões personalizadas por conta em `google/list-fields` com `account_id`: `conversions:<nome>` e `conversions_value:<nome>` (GAQL com `segments.conversion_action_name`) |
| Erros | tabela Google → ação: `DEVELOPER_TOKEN_NOT_APPROVED`, `PERMISSION_DENIED` por papel, escopo ausente, `USER_PERMISSION_DENIED`, `insufficientPermissions` |
| Tela | nada novo além do estado das APIs habilitadas e dos escopos concedidos no `google/status` |

### 1.2 Rotas genéricas (3) — cobertura total das APIs

| Rota | O que faz |
|---|---|
| `google/list-actions` (read) | catálogo de métodos a partir dos **documentos de descoberta** da Google (Analytics Admin v1alpha/v1beta, Analytics Data v1beta/v1alpha, Google Ads REST, Search Console, Site Verification, Sheets, Drive), cache de 24 h; busca por texto (`task`) e filtro por API; devolve id, verbo, caminho, parâmetros e esquema do corpo |
| `google/execute-action` (write) | executa um método pelo id do catálogo: `{ api, method, path_params, query, body }`; o plugin monta a URL a partir do documento de descoberta (nunca de string livre), autentica, envia e audita |
| `ads/mutate` (write) | `googleAds:mutate` com `operations[]` de qualquer serviço, `partial_failure`, `dry_run` |

### 1.3 Search Console (9) e Site Verification (3)

| Rota | Modo | API |
|---|---|---|
| `gsc/list-sites` · `gsc/get-site` | read | `sites.list` / `sites.get` |
| `gsc/query` | read | `searchAnalytics.query` (clicks, impressions, ctr, position; query, page, country, device, date, searchAppearance; `type`; filtros; `dataState`; `rowLimit` ≤ 25.000 + `startRow`) |
| `gsc/list-sitemaps` | read | `sitemaps.list` |
| `gsc/inspect-url` | read | `urlInspection.index.inspect` |
| `gsc/submit-sitemap` · `gsc/delete-sitemap` | write | `sitemaps.submit` / `delete` |
| `gsc/add-site` · `gsc/delete-site` | write | `sites.add` / `sites.delete` |
| `siteverification/get-token` | read | `webResource.getToken` — devolve o token META ou o nome do arquivo; colocar o token no site é tarefa de outra ferramenta (`files/*` do WP MCP Fator3, `content/*` do Ultimate) |
| `siteverification/verify` | write | `webResource.insert` — a credencial vira proprietária verificada |
| `siteverification/update-owners` · `siteverification/list` | write / read | `webResource.update` / `list` |

Conector `search-console` em `google/list-accounts`, `google/list-fields`,
`google/query`, `google/blend`.

### 1.4 GA4 — Admin API em escrita (27) e complementos (2)

| Rota | API (Admin) |
|---|---|
| `ga/create-property` · `ga/update-property` · `ga/delete-property` | `properties.*` |
| `ga/provision-account` · `ga/delete-account` | `accounts:provisionAccountTicket` (devolve a URL do termo que um humano aceita — é assim que a API funciona) / `accounts.delete` |
| `ga/create-web-stream` · `ga/update-web-stream` · `ga/delete-web-stream` | `dataStreams.*` (devolve `measurementId`) |
| `ga/update-enhanced-measurement` | `enhancedMeasurementSettings.patch` |
| `ga/create-key-event` · `ga/update-key-event` · `ga/delete-key-event` | `keyEvents.*` |
| `ga/create-custom-dimension` · `ga/archive-custom-dimension` · `ga/create-custom-metric` · `ga/archive-custom-metric` | `customDimensions.*` / `customMetrics.*` |
| `ga/update-data-retention` · `ga/update-attribution` · `ga/update-google-signals` | `dataRetentionSettings` / `attributionSettings` / `googleSignalsSettings` |
| `ga/create-annotation` · `ga/update-annotation` · `ga/delete-annotation` | `reportingDataAnnotations.*` (v1alpha) |
| `ga/create-audience` · `ga/update-audience` · `ga/archive-audience` | `audiences.*` (v1alpha) |
| `ga/create-mp-secret` · `ga/delete-mp-secret` | `measurementProtocolSecrets.*` (o valor do segredo é devolvido ao agente uma vez, na criação, como a API faz; o plugin não o guarda) |
| `ga/create-google-ads-link` · `ga/delete-google-ads-link` | `googleAdsLinks.*` |
| `ga/list-users` · `ga/add-user` · `ga/update-user` · `ga/remove-user` | `accessBindings.*` (conta e propriedade) |
| `ga/get-settings` (read) | tudo acima numa resposta |
| `ga/send-event` (write) | Measurement Protocol: envia eventos a uma propriedade (`measurement_id`, `api_secret`, `client_id`, `events[]`); `debug: true` usa o endpoint de validação. É acesso à API, sem nada instalado no site |

Vínculos com BigQuery, Firebase e Search Ads 360, grupos de canais, regras
de criação de evento, subpropriedades e propriedades de agregação: pela rota
genérica.

### 1.5 Google Ads — escrita nomeada (26) e leitura complementar (6)

| Rota | API `mutate` |
|---|---|
| `ads/create-campaign` · `ads/update-campaign` · `ads/remove-campaign` | `campaigns` |
| `ads/create-budget` · `ads/update-budget` | `campaignBudgets` |
| `ads/create-ad-group` · `ads/update-ad-group` · `ads/remove-ad-group` | `adGroups` |
| `ads/create-responsive-search-ad` · `ads/update-ad-status` · `ads/remove-ad` | `adGroupAds` |
| `ads/add-keywords` · `ads/update-keyword` · `ads/remove-keywords` | `adGroupCriteria` |
| `ads/add-negative-keywords` · `ads/remove-negative-keywords` | `adGroupCriteria` / `campaignCriteria` |
| `ads/create-conversion-action` · `ads/update-conversion-action` | `conversionActions` |
| `ads/upload-click-conversions` | `conversionUploads:uploadClickConversions` |
| `ads/upload-customer-match` | `offlineUserDataJobs` (hash SHA-256 que a API exige) |
| `ads/create-asset` · `ads/link-asset` | `assets`, `campaignAssets`, `adGroupAssets` |
| `ads/create-asset-group` (Performance Max) | `assetGroups`, `assetGroupAssets` |
| `ads/create-experiment` · `ads/schedule-experiment` | `experiments`, `experimentArms` |
| `ads/add-label` · `ads/apply-label` | `labels`, `campaignLabels`, `adGroupLabels` |
| `ads/add-audience-to-campaign` · `ads/create-user-list` | `campaignCriteria`, `userLists` |
| `ads/invite-user` · `ads/update-user-access` · `ads/remove-user` | `customerUserAccessInvitations`, `customerUserAccess` |
| `ads/create-billing-setup` | `billingSetups` |

Shopping e o restante: `ads/mutate`. Leitura complementar: `ads/get-campaign`,
`ads/list-conversion-actions`, `ads/list-assets`, `ads/list-audiences`,
`ads/list-users`, `ads/list-experiments`.

### 1.6 Camada unificada (2)

| Rota | O que faz |
|---|---|
| `google/blend` (read) | tabela única com colunas de GA4, Ads e Search Console, juntadas por `date` e, quando pedido, `campaign` (Ads ↔ `sessionCampaignName`) ou `page` (Search Console ↔ `pagePath`); presets, filtros e comparação do `google/query`; colunas prefixadas pelo conector; `warnings` para linhas sem par |
| `google/export-to-sheet` (write) | executa consulta ou blend e grava numa planilha Google pela Sheets API: cria na conta da service account e compartilha com os e-mails informados (Drive API), ou escreve numa planilha existente compartilhada com a service account; aba por consulta, substitui ou anexa |

### 1.7 Skill `wp-google` 0.2.0

Catálogo das rotas novas e das genéricas (como achar um método em
`google/list-actions` e chamar `google/execute-action`); regra de
confirmação no agente antes de qualquer `write`; tabela Porter → aqui com
`list_actions`/`execute_action`, `create_blend`, exportações; instruções de
como o agente compõe com outras ferramentas o que este plugin não faz
(seção 2).

## 2. Fora do plugin, e onde fica

| Item | Responsável |
|---|---|
| Tag GA4 no site, Consent Mode, banner de consentimento | Base Site Core Fator3 (padrão permissivo, `granted`) |
| Ponte de eventos do site para o GA4, padrão de eventos-chave e dimensões | Base Site Core Fator3; o GA4 recebe pelo gtag do site ou pelo Measurement Protocol, que este plugin apenas expõe (`ga/send-event`) |
| Onboarding de site novo (propriedade, fluxo, verificação, sitemap) | o agente ou o implantador, compondo as rotas deste plugin com `files/*` e `content/*` para colocar o token de verificação no site |
| Consultas salvas, blends salvos, exportação agendada | tarefas agendadas do Claude chamando `google/query`/`google/blend` + `google/export-to-sheet` |
| Relatórios hospedados que o usuário acompanha | a planilha exportada; ou página no WordPress criada pelo agente via `content/*` do Ultimate com os dados; Looker Studio não entra |
| Credenciais, papéis e permissões da service account | quem cria e atribui a service account |
| Conectores fora da Google | fora |

## 3. Limites da API (não do plugin)

| Item | Motivo |
|---|---|
| "Solicitar indexação" de URL | não existe na Search Console API; a Indexing API só aceita vagas e transmissões ao vivo |
| Mudança de endereço na Search Console | sem API |
| Verificação de propriedade de domínio (`sc-domain:`) | exige registro TXT no DNS; a API só emite o token |
| Restaurar propriedade GA4 da lixeira | sem API |
| Cancelar conta do Ads; alterar ou cancelar faturamento | sem API |
| Relatórios salvos dentro de GA4/Ads/Search Console | sem API |

Customer Match, experimentos, Performance Max e Shopping têm requisitos
próprios da Google; o plugin expõe as rotas e a Google aplica as regras dela.

## 4. Papéis para "todas as ações"

GA4: Administrador na conta e nas propriedades. Google Ads: Administrador na
conta ou na MCC; developer token Básico (Standard para volume). Search
Console: Proprietário (a verificação pela API já dá). Sheets/Drive: a
planilha nasce na conta da service account e é compartilhada, ou o usuário
compartilha a dele. O que a service account puder fazer, o agente pode.

## 5. Arquitetura

Módulos novos em `includes/`: `Generic/` (Discovery, ExecuteAction),
`SearchConsole/`, `SiteVerification/`, `Analytics/AdminWrite.php`,
`Analytics/MeasurementProtocol.php`, `Ads/Mutate.php`,
`Ads/WriteAbilities.php`, `Unified/Blend.php`, `Sheets/`. Núcleo: `Ability`
(modo), `Credentials` (escopos), `GoogleClient` (hosts, execução por
documento de descoberta), `Audit` (before/after), `Options` (options novas).
Contratos no `CONTRACTS.md` antes de qualquer subagente começar.

## 6. Testes e evidência

- Unitários com HTTP simulado por rota: sucesso, erro traduzido, papel insuficiente, `dry_run` presente/ausente no corpo, auditoria com `before`/`after`, resolução por nome e `*`, blend com e sem pares, exportação (corpo enviado ao Sheets/Drive).
- Rotas genéricas: catálogo montado a partir de documentos de descoberta reais gravados em `tests/fixtures`; `execute-action` monta URL, verbo e corpo exatamente como o documento manda; método inexistente e host fora da lista recusados.
- Validação de entrada/saída de todas as rotas contra o núcleo do WP 6.9 (o `JsonSchema` de teste da 0.1.0).
- Ensaio vivo antes da entrega, com limpeza ao fim: GA4 numa propriedade de teste criada e apagada pelo ensaio; Search Console e verificação num subdomínio de teste; Ads numa conta de teste (serve com o token no nível Conta de teste); Sheets numa planilha descartável.
- Verificação por mutação feita por mim na árvore real: remover um host da lista, apagar o `before` da auditoria, quebrar a junção do blend, deixar `execute-action` aceitar caminho fora do documento de descoberta — a suíte tem de acusar cada um.
- Todos os números do relatório de entrega saem da execução.

## 7. Execução

| Fase | Conteúdo | Agente |
|---|---|---|
| 1 | Núcleo (1.1) + rotas genéricas (1.2) + CONTRACTS.md | Opus |
| 2a | Search Console + Site Verification (1.3) | Sonnet |
| 2b | GA4 Admin em escrita + `get-settings` + Measurement Protocol (1.4) | Opus |
| 2c | Ads escrita e leitura complementar (1.5) + conversões personalizadas no catálogo | Opus |
| 2d | Blend + exportação para Sheets (1.6) | Sonnet |
| 3 | Testes de integração, schema de todas as rotas, phpcs | Sonnet |
| 4 | Revisão + README + skill 0.2.0 + pacote | Opus |
| 5 | Ensaio vivo + verificação por mutação | eu |

2a–2d em paralelo sobre o núcleo. Estimativa: 6 a 9 dias de trabalho de
agentes, mais o ensaio vivo, que depende do developer token e de um
subdomínio de teste para a Search Console.

## 8. Decisões pendentes

Nenhuma de produto. Pré-requisitos para o ensaio vivo: developer token do
Ads (qualquer nível) e um subdomínio de teste com WordPress para a Search
Console.
