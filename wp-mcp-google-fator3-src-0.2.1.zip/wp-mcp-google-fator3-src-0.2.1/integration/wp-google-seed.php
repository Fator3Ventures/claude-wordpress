<?php
/** Seed ORIGINAL 0.1.0 in disposable WordPress only. Called before replacement. */
if (PHP_SAPI !== 'cli' || empty($argv[1]) || empty($argv[2])) exit(2);
define('WP_DISABLE_FATAL_ERROR_HANDLER', true);
$_SERVER['HTTP_HOST']='127.0.0.1:8787'; $_SERVER['REQUEST_URI']='/';
require rtrim($argv[1], '/').'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
wp_set_current_user(1);
$plugin='wp-mcp-google-fator3/wp-mcp-google-fator3.php';
$result=activate_plugin($plugin);
if(is_wp_error($result))throw new RuntimeException($result->get_error_message());
use Fator3\McpGoogle\Options;
Options::set(Options::ENABLED,true);
Options::set(Options::GA_ENABLED,true);
Options::set(Options::ADS_ENABLED,true);
Options::set(Options::AUTH_MODE,'oauth');
Options::set(Options::OAUTH_CLIENT_ID,'integration-fixture.apps.googleusercontent.com');
Options::set(Options::OAUTH_EMAIL,'integration@example.invalid');
Options::set(Options::GA_DEFAULT_PROPERTY,'123456');
Options::set(Options::MAX_ROWS,321);
Options::set(Options::HTTP_TIMEOUT,17);
$fixtures=[Options::OAUTH_CLIENT_SECRET=>'fixture-client-secret-v010',Options::OAUTH_REFRESH_TOKEN=>'fixture-refresh-token-v010',Options::ADS_DEVELOPER_TOKEN=>'fixture-developer-token-v010'];
$record=['version'=>F3_MCP_GOOGLE_VERSION,'active_plugins'=>get_option('active_plugins'),'options'=>[],'secrets'=>[]];
foreach($fixtures as $name=>$value){Options::set_secret($name,$value);$stored=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$name));$record['secrets'][$name]=['plain_sha256'=>hash('sha256',$value),'stored_sha256'=>hash('sha256',$stored),'encrypted'=>$stored!==$value,'hidden'=>get_option($name)===''];}
foreach([Options::AUTH_MODE,Options::OAUTH_CLIENT_ID,Options::OAUTH_EMAIL,Options::GA_DEFAULT_PROPERTY,Options::MAX_ROWS,Options::HTTP_TIMEOUT] as $name)$record['options'][$name]=Options::get($name);
file_put_contents($argv[2],json_encode($record,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));
echo json_encode(['version'=>F3_MCP_GOOGLE_VERSION,'seeded'=>count($fixtures),'active_plugins'=>$record['active_plugins']]).PHP_EOL;
