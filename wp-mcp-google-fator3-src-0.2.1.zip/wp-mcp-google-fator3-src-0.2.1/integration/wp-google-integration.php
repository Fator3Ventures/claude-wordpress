<?php
/** Disposable REAL WordPress + installed MCP Fator3 integration; Google HTTP is simulated.
 * Usage: php wp-google-integration.php <wp-root> <output.json> <migration-before.json>
 */
if(PHP_SAPI!=='cli'||empty($argv[1])||empty($argv[2]))exit(2);
define('WP_DISABLE_FATAL_ERROR_HANDLER',true);
$_SERVER['HTTP_HOST']='127.0.0.1:8787';$_SERVER['REQUEST_URI']='/';
$checks=[];$warnings=[];$routes=[];$outcomes=[];$transport=[];
set_error_handler(static function($severity,$message,$file,$line)use(&$warnings){if(str_contains($file,'wp-mcp-google-fator3')||str_contains($message,'schema'))$warnings[]=['severity'=>$severity,'message'=>$message,'file'=>basename($file),'line'=>$line];return false;});
require rtrim($argv[1],'/').'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
require_once ABSPATH.'wp-admin/includes/user.php';
require_once __DIR__.'/wp-google-http-fixture.php';
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Unified\Catalog;
function check_google(string $test,bool $ok,$detail=''):void {global $checks;$checks[]=['test'=>$test,'ok'=>$ok,'detail'=>$detail];}
function summary_google($result):array {if(is_wp_error($result))return ['wp_error'=>$result->get_error_code(),'message'=>$result->get_error_message()];return is_array($result)?['success'=>$result['success']??null,'error_code'=>$result['error_code']??null,'message'=>$result['message']??null,'row_count'=>$result['row_count']??null]:['type'=>gettype($result)];}
function success_google($result):bool{return is_array($result)&&!empty($result['success']);}
function denied_google($result):bool{return is_wp_error($result)||(is_array($result)&&isset($result['success'])&&!$result['success']);}
function run_google(string $route,array $input=[]){return wp_get_ability($route)->execute($input);}
wp_set_current_user(1);
add_filter('pre_http_request','google_fixture_http',1,3);
$GLOBALS['google_fixture_calls']=[];$GLOBALS['google_fixture_unmodeled']=[];$GLOBALS['google_fixture_mode']='success';
try{
 check_google('upgrade:version',defined('F3_MCP_GOOGLE_VERSION')&&F3_MCP_GOOGLE_VERSION==='0.2.0',defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:'not loaded');
 $active=get_option('active_plugins');check_google('coexist:two_active_plugins',count($active)===2&&in_array('wp-mcp-fator3/wp-mcp-fator3.php',$active,true)&&in_array('wp-mcp-google-fator3/wp-mcp-google-fator3.php',$active,true),$active);
 if(!empty($argv[3])){
  $before=json_decode(file_get_contents($argv[3]),true);check_google('upgrade:from_original_v010',$before['version']==='0.1.0');
  foreach($before['options'] as $name=>$value)check_google('upgrade:option:'.$name,(string)Options::get($name)===(string)$value);
  foreach($before['secrets'] as $name=>$record){$stored=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name=%s",$name));check_google('upgrade:encrypted_bytes:'.$name,hash('sha256',$stored)===$record['stored_sha256']);check_google('upgrade:decrypt:'.$name,hash('sha256',Options::get_secret($name))===$record['plain_sha256']);check_google('upgrade:hidden:'.$name,get_option($name)==='');}
 }
 Options::set(Options::ENABLED,true);Options::set(Options::GA_ENABLED,true);Options::set(Options::ADS_ENABLED,true);Options::set(Options::AUTH_MODE,'oauth');
 Options::set(Options::OAUTH_SCOPES,Credentials::scopes_for('any'));Credentials::invalidate_cache();Catalog::flush();
 $fixtures=json_decode(file_get_contents(__DIR__.'/original-inputs.json'),true);
 foreach(['ga-admin-inputs','ads-write-inputs','gsc-inputs','blend-sheet-inputs'] as $name){$path=F3_MCP_GOOGLE_DIR.'tests/fixtures/'.$name.'.json';if(file_exists($path))$fixtures=array_merge($fixtures,json_decode(file_get_contents($path),true));}
 $query=['connector'=>'ga4','accounts'=>['123456'],'metrics'=>['sessions'],'dimensions'=>['date'],'date_range'=>['from'=>'2026-08-01','to'=>'2026-08-07']];
 $gscQuery=['connector'=>'search-console','accounts'=>['https://example.test/'],'metrics'=>['clicks'],'dimensions'=>['date'],'date_range'=>['from'=>'2026-08-01','to'=>'2026-08-07']];
 $extra=[['route'=>'google/list-actions','input'=>['api'=>'search-console','limit'=>100]],['route'=>'google/execute-action','input'=>['api'=>'analytics-admin','method'=>'analyticsadmin.properties.get','path_params'=>['name'=>'properties/123456']]],['route'=>'google/audit','input'=>['limit'=>10]],['route'=>'google/blend','input'=>['queries'=>[$query,$gscQuery],'on'=>['date']]],['route'=>'google/export-to-sheet','input'=>['query'=>$query,'spreadsheet_id'=>'fixture_sheet_123','tab_name'=>'Report','mode'=>'replace']]];
 $byRoute=[];foreach(array_merge($extra,$fixtures) as $fixture)$byRoute[$fixture['route']]=$fixture['input'];
 $all=wp_get_abilities();foreach($all as $name=>$ability)if($ability->get_category()==='google')$routes[$name]=$ability;
 check_google('registry:all_original_21',!array_diff(array_column(json_decode(file_get_contents(__DIR__.'/original-inputs.json'),true),'route'),array_keys($routes)));
 check_google('registry:each_route_has_fixture',!array_diff(array_keys($routes),array_keys($byRoute)),array_values(array_diff(array_keys($routes),array_keys($byRoute))));
 check_google('registry:all_fixture_routes_registered',!array_diff(array_keys($byRoute),array_keys($routes)),array_values(array_diff(array_keys($byRoute),array_keys($routes))));
 foreach($fixtures as $index=>$fixture){$ability=$routes[$fixture['route']]??null;if(!$ability)continue;$valid=rest_validate_value_from_schema($fixture['input'],$ability->get_input_schema(),$fixture['route']);check_google('input_variant:'.$fixture['route'].':'.$index,$valid===true,is_wp_error($valid)?$valid->get_error_message():'');}
 $countRead=0;$countWrite=0;
 foreach($routes as $name=>$ability){
  $meta=$ability->get_meta();$annotations=$meta['annotations'];$write=$annotations['readonly']===false;$write?++$countWrite:++$countRead;
  check_google('metadata:'.$name,($meta['mcp']['public']??false)===true&&($meta['mcp']['type']??'')==='tool'&&$annotations['destructive']===$write&&$annotations['idempotent']===!$write);
  $input=$byRoute[$name]??[];$schema=$ability->get_input_schema();$valid=rest_validate_value_from_schema($input,$schema,$name);
  check_google('input:'.$name,$valid===true,is_wp_error($valid)?$valid->get_error_message():'');
  $invalid=rest_validate_value_from_schema($input+['__intruder'=>'x'],$schema,$name);check_google('closed_input:'.$name,is_wp_error($invalid));
  $start=count($GLOBALS['google_fixture_calls']);$result=$ability->execute($input);$outcomes[$name]=summary_google($result);
  check_google('execute_success:'.$name,success_google($result),summary_google($result));
  if(is_array($result)){$validated=rest_validate_value_from_schema($result,$ability->get_output_schema(),$name.'.output');check_google('output:'.$name,$validated===true,is_wp_error($validated)?$validated->get_error_message():'');}else check_google('output:'.$name,false,summary_google($result));
  $transport[$name]=array_slice($GLOBALS['google_fixture_calls'],$start);
  if($write){$entries=Audit::recent(1);$entry=$entries[0]??[];$extraAudit=$entry['extra']??[];check_google('audit:'.$name,($entry['action']??'')===$name&&array_key_exists('before',$extraAudit)&&array_key_exists('after',$extraAudit)&&array_key_exists('dry_run',$extraAudit)&&isset($extraAudit['result']),['action'=>$entry['action']??null,'keys'=>array_keys($extraAudit)]);}
 }
 foreach(['ga4'=>$query,'search-console'=>$gscQuery,'google-ads'=>['connector'=>'google-ads','accounts'=>['1234567890'],'metrics'=>['clicks','cost'],'dimensions'=>['date'],'date_range'=>['from'=>'2026-08-01','to'=>'2026-08-07']]] as $connector=>$input){$result=run_google('google/query',$input);check_google('query:'.$connector,success_google($result)&&($result['row_count']??0)>0,summary_google($result));}
 $named=$query;$named['accounts']=['fixture site'];$r=run_google('google/query',$named);check_google('accounts:casefold_name',success_google($r),summary_google($r));$wild=$query;$wild['accounts']=['*'];$r=run_google('google/query',$wild);check_google('accounts:wildcard',success_google($r)&&count($r['accounts']??[])===3,summary_google($r));
 $numeric=['123456',123456,'properties/123456'];foreach($numeric as $id){$r=run_google('ga/get-property-details',['property_id'=>$id]);check_google('ids:'.gettype($id).':'.$id,success_google($r),summary_google($r));}
 $discovery=wp_get_ability('wp-mcp-ultimate/discover-abilities')->execute();$exposed=is_array($discovery)?array_column($discovery['abilities']??[],'name'):[];check_google('mcp:discover_all_google_routes',!array_diff(array_keys($routes),$exposed),is_wp_error($discovery)?summary_google($discovery):count($exposed));
 $wrapped=run_google('wp-mcp-ultimate/execute-ability',['ability_name'=>'ga/get-property-details','parameters'=>json_encode(['property_id'=>'123456'])]);check_google('mcp:execute_google_using_original_metatool',success_google($wrapped)&&!empty($wrapped['data']['success']),summary_google($wrapped));
 $restRoutes=rest_get_server()->get_routes();check_google('mcp:legacy_endpoint_registered',isset($restRoutes['/mcp/wp-mcp-ultimate']),array_values(array_filter(array_keys($restRoutes),static fn($x)=>str_contains($x,'mcp/'))));
 $protected=apply_filters('wp_mcp_ultimate_protected_options',[]);check_google('secrets:all_options_protected',!array_diff(Options::all_names(),$protected));
 $secretSerialized=json_encode(Audit::recent(0));check_google('secrets:audit_redacts_mp_secret',!str_contains($secretSerialized,'fixture-mp-secret-redact-me')&&!str_contains($secretSerialized,'fixture-access-token'));
 $dryInput=$byRoute['ads/create-campaign'];$dryInput['dry_run']=true;$r=run_google('ads/create-campaign',$dryInput);$log=Audit::recent(1);check_google('dry_run:ads_native_validate_only',success_google($r)&&!empty($log[0]['extra']['dry_run']),summary_google($r));
 $start=count($GLOBALS['google_fixture_calls']);$r=run_google('ga/create-property',$byRoute['ga/create-property']+['dry_run'=>true]);check_google('dry_run:unsupported_fails_before_transport',denied_google($r)&&$start===count($GLOBALS['google_fixture_calls']),summary_google($r));
 $genericBatch=['api'=>'google-ads','method'=>'googleads.customers.googleAds.mutate','path_params'=>['customerId'=>'1234567890'],'body'=>['mutateOperations'=>[['campaignOperation'=>['create'=>['name'=>'Object encoding fixture','status'=>'PAUSED','advertisingChannelType'=>'SEARCH','campaignBudget'=>'customers/1234567890/campaignBudgets/1','manualCpc'=>[]]]]]],'dry_run'=>true];$r=run_google('google/execute-action',$genericBatch);check_google('generic:batch_native_schema_execute',success_google($r),summary_google($r));
 $encodedObjects=array_values(array_filter($GLOBALS['google_fixture_calls'],static fn($call)=>$call['manual_cpc_object']!==null));check_google('json:empty_proto_objects_are_objects',count($encodedObjects)>=2&&!in_array(false,array_column($encodedObjects,'manual_cpc_object'),true),$encodedObjects);
 $illegal=['api'=>'analytics-admin','method'=>'analyticsadmin.properties.get','path_params'=>['name'=>'properties/123/../../accounts/100']];$start=count($GLOBALS['google_fixture_calls']);$r=run_google('google/execute-action',$illegal);check_google('generic:traversal_denied_before_http',denied_google($r)&&$start===count($GLOBALS['google_fixture_calls']),summary_google($r));
 $illegal=['api'=>'analytics-admin','method'=>'analyticsadmin.properties.get','path_params'=>['name'=>'properties/123456'],'query'=>['url'=>'https://example.invalid']];$start=count($GLOBALS['google_fixture_calls']);$r=run_google('google/execute-action',$illegal);check_google('generic:unknown_url_query_rejected_no_mutation',denied_google($r)&&!array_filter(array_slice($GLOBALS['google_fixture_calls'],$start),static fn($call)=>$call['method']!=='GET'&&$call['host']!=='oauth2.googleapis.com'),summary_google($r));
 $custom=['connector'=>'google-ads','accounts'=>['1234567890'],'metrics'=>['clicks','conversions:Purchase','conversions_value:Purchase'],'dimensions'=>['date'],'date_range'=>['from'=>'2026-08-01','to'=>'2026-08-07']];$r=run_google('google/query',$custom);check_google('query:custom_conversions_exact_values',success_google($r)&&($r['rows'][0]??[])===['2026-08-01',2,3.0,30.0],is_array($r)?['summary'=>summary_google($r),'rows'=>$r['rows']??null]:summary_google($r));
 $GLOBALS['google_fixture_mode']='denied';foreach(['ga/get-property-details','ga/update-property','ads/create-campaign','gsc/query','siteverification/get-token','google/export-to-sheet','google/execute-action'] as $name){$r=run_google($name,$byRoute[$name]);check_google('google_403:'.$name,denied_google($r),summary_google($r));if(is_array($r)){$valid=rest_validate_value_from_schema($r,$routes[$name]->get_output_schema(),'error_output');check_google('error_output:'.$name,$valid===true,is_wp_error($valid)?$valid->get_error_message():'');}}
 $GLOBALS['google_fixture_mode']='success';
 $editorLogin='google-integration-editor';$editor=get_user_by('login',$editorLogin);$editorId=$editor?$editor->ID:wp_insert_user(['user_login'=>$editorLogin,'user_pass'=>'Disposable-fixture-123!','user_email'=>'google-integration-editor@example.invalid','role'=>'editor']);if(is_wp_error($editorId))throw new RuntimeException($editorId->get_error_message());wp_set_current_user($editorId);check_google('permission:editor_fixture_has_edit_posts_not_manage_options',current_user_can('edit_posts')&&!current_user_can('manage_options'));$beforeEditor=count($GLOBALS['google_fixture_calls']);foreach($routes as $name=>$ability){$r=$ability->execute($byRoute[$name]??[]);check_google('permission:editor:'.$name,denied_google($r),summary_google($r));}wp_set_current_user(1);check_google('permission:editor_no_http',count($GLOBALS['google_fixture_calls'])===$beforeEditor);if(!$editor)wp_delete_user($editorId);
 $beforePermissions=count($GLOBALS['google_fixture_calls']);wp_set_current_user(0);foreach($routes as $name=>$ability){$r=$ability->execute($byRoute[$name]??[]);check_google('permission:anonymous:'.$name,denied_google($r),summary_google($r));}wp_set_current_user(1);check_google('permission:anonymous_no_http',count($GLOBALS['google_fixture_calls'])===$beforePermissions);
 Options::set(Options::ENABLED,false);$beforePermissions=count($GLOBALS['google_fixture_calls']);foreach($routes as $name=>$ability){$r=$ability->execute($byRoute[$name]??[]);check_google('permission:killswitch:'.$name,denied_google($r),summary_google($r));}Options::set(Options::ENABLED,true);check_google('permission:killswitch_no_http',count($GLOBALS['google_fixture_calls'])===$beforePermissions);
 check_google('http:no_unmodeled_calls',empty($GLOBALS['google_fixture_unmodeled']),$GLOBALS['google_fixture_unmodeled']);
 check_google('schemas:no_wp_warnings',empty($warnings),$warnings);
}catch(Throwable $e){check_google('uncaught_exception',false,['class'=>get_class($e),'message'=>$e->getMessage(),'file'=>$e->getFile(),'line'=>$e->getLine()]);}
$failed=array_values(array_filter($checks,static fn($x)=>!$x['ok']));
$report=['environment'=>'Real disposable WordPress, MariaDB, installed WP MCP Fator3; Google HTTP simulated with deterministic fixtures. No live Google credentials or API calls.','wordpress'=>get_bloginfo('version'),'php'=>PHP_VERSION,'google_plugin'=>defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null,'fator3_plugin'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'registered_google_routes'=>count($routes),'read_routes'=>$countRead??0,'write_routes'=>$countWrite??0,'passed'=>count($checks)-count($failed),'failed'=>count($failed),'checks'=>$checks,'outcomes'=>$outcomes,'transport_by_route'=>$transport,'warnings'=>$warnings];
file_put_contents($argv[2],json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));
echo json_encode(['wordpress'=>$report['wordpress'],'routes'=>count($routes),'passed'=>$report['passed'],'failed'=>count($failed),'failures'=>$failed],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
exit($failed?1:0);
