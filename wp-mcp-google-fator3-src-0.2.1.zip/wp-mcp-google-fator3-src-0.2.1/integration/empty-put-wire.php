<?php
/** Ponte de teste: plugin real, WordPress em memória e transporte Requests real para localhost. */
declare(strict_types=1);

$plugin = $argv[1];
$requests = $argv[2];
$target = $argv[3];
if (!preg_match('~^http://127\.0\.0\.1:\d+$~', $target)) {
    throw new RuntimeException('O servidor de teste deve ser local.');
}
require $plugin . '/tests/bootstrap.php';
require $requests . '/src/Autoload.php';
\WpOrg\Requests\Autoload::register();
foreach (array('Generic/Discovery', 'Generic/ExecuteAction', 'Generic/Abilities', 'SearchConsole/Api', 'SearchConsole/Abilities') as $file) {
    require_once $plugin . '/includes/' . $file . '.php';
}
remove_filter('pre_http_request', array(\Fator3\McpGoogle\Tests\FakeHttp::class, 'handle'), 10);
$wire = array();
add_filter('pre_http_request', static function ($pre, $args, $url) use ($target, &$wire) {
    $path = parse_url($url, PHP_URL_PATH);
    $query = parse_url($url, PHP_URL_QUERY);
    $response = \WpOrg\Requests\Requests::request(
        $target . $path . ($query ? '?' . $query : ''),
        $args['headers'],
        $args['body'] ?? '',
        $args['method'],
        array('transport' => new \WpOrg\Requests\Transport\Fsockopen(), 'protocol_version' => 1.1, 'timeout' => 5, 'follow_redirects' => false)
    );
    $wire[] = array('method' => $args['method'], 'path' => $path, 'status' => $response->status_code);
    return array('response' => array('code' => $response->status_code), 'body' => $response->body, 'headers' => $response->headers->getAll());
}, 10, 3);

use Fator3\McpGoogle\Options;
Options::set(Options::ENABLED, true);
Options::set(Options::AUTH_MODE, 'oauth');
Options::set(Options::OAUTH_CLIENT_ID, 'local-wire-test');
Options::set_secret(Options::OAUTH_CLIENT_SECRET, 'dummy-local-secret');
Options::set_secret(Options::OAUTH_REFRESH_TOKEN, 'dummy-local-refresh');
Options::set(Options::OAUTH_SCOPES, array('https://www.googleapis.com/auth/webmasters'));
set_transient(
    \Fator3\McpGoogle\Generic\Discovery::cache_key('search-console'),
    json_decode(file_get_contents($plugin . '/tests/fixtures/discovery/searchconsole-v1.json'), true),
    86400
);
\Fator3\McpGoogle\SearchConsole\Abilities::register();
\Fator3\McpGoogle\Generic\Abilities::register();
$site = 'https://example.test/';
$results = array();
foreach (array(
    array('gsc/submit-sitemap', array('site_url' => $site, 'sitemap_url' => $site . 'sitemap.xml')),
    array('gsc/add-site', array('site_url' => $site)),
    array('google/execute-action', array('api' => 'search-console', 'method' => 'webmasters.sitemaps.submit', 'path_params' => array('siteUrl' => $site, 'feedpath' => $site . 'sitemap.xml'))),
) as [$name, $input]) {
    $result = wp_get_ability($name)->execute($input);
    $results[] = array('ability' => $name, 'success' => $result['success'], 'error_code' => $result['error_code'] ?? null);
}
echo json_encode(array('php' => PHP_VERSION, 'requests' => \WpOrg\Requests\Requests::VERSION, 'results' => $results, 'wire' => $wire), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
