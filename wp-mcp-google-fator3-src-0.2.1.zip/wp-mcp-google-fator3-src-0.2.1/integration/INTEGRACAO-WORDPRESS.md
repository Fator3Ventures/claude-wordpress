# Integração executada em WordPress real

Este conjunto usa WordPress instalado e MariaDB real. As requisições às APIs Google são substituídas por respostas determinísticas no filtro `pre_http_request`. Nenhuma credencial Google real é necessária nem utilizada. Isso verifica integração, serialização, autorização e contratos do plugin; não comprova acesso a contas Google, aprovação do developer token Ads ou API habilitada no projeto do cliente.

Execute somente em instalações descartáveis. O seed grava credenciais fictícias e opções locais. A suíte abre/fecha temporariamente o canal Google, cria e remove um usuário Editor descartável e preenche o log de auditoria.

## Arquivos

- `wp-google-seed.php`: ativa a versão original 0.1.0 e registra hashes dos segredos cifrados e da configuração, para comparação após substituir os arquivos pela 0.2.0.
- `wp-google-integration.php`: executa todas as habilidades registradas, verifica schemas pelo validador REST nativo, resultados, anotações, auditoria, IDs, consultas, permissões e migração.
- `wp-google-http-fixture.php`: modelos HTTP dos serviços e documentos de descoberta reais. URL sem modelo retorna WP_Error, sem acesso externo.
- `wp-google-mcp-transport.php`: faz despacho REST interno no endpoint MCP existente, com initialize, sessão, tools/list, discovery e execução de habilidade Google.
- `wp-google-manifest.php`: exporta o registro real, incluindo nomes, descrição, schemas e anotações.
- `original-inputs.json`: 21 exemplos da versão original; exemplos novos são lidos de `tests/fixtures` do plugin instalado.

## Reprodução

Requer PHP 8.0+, WordPress instalado, usuário administrador ID 1, WP MCP Fator3 0.9.0 ativo e permissão para gravar resultados. Instale a 0.1.0 na mesma pasta que será atualizada, `wp-mcp-google-fator3`, antes do seed.

```sh
php wp-google-seed.php /caminho/wordpress migration-before.json
```

Substitua os arquivos da pasta do plugin pela versão 0.2.0 deste **pacote-fonte**, incluindo `tests/fixtures`, preservando banco e basename. O ZIP de instalação não inclui as fixtures necessárias ao laboratório. Em seguida:

```sh
php wp-google-integration.php /caminho/wordpress integration-results.json migration-before.json
php wp-google-mcp-transport.php /caminho/wordpress mcp-results.json
php wp-google-manifest.php /caminho/wordpress abilities-manifest.json
```

Os scripts devolvem exit code diferente de zero quando há falha. Use o mesmo processo de atualização em uma instalação WordPress 6.9 com Abilities API nativa e outra anterior com o polyfill do Fator3. Os testes de transporte usam `rest_do_request` e a sessão MCP real; não incluem ida e volta pela rede ao servidor WordPress.

## Escopo das verificações

- Registro completo e preservação dos nomes originais.
- Esquemas de entrada/saída e exemplos, validadores REST reais, entrada fechada.
- Execução com sucesso simulado de todas as rotas, sem interpretar erro operacional como sucesso.
- Três conectores de consulta, nomes de conta e wildcard, tipos de ID, conversões customizadas com valores exatos.
- Metadados coerentes de leitura/escrita, snapshots antes/depois, resultado e dry run na auditoria.
- Batch genérico, validateOnly, objetos proto vazios serializados como `{}`, recusa de traversal e parâmetro URL não declarado.
- Erros HTTP 403 simulados em serviços representativos e validação do schema de erro.
- Recusa de todas as rotas para anônimo, Editor sem `manage_options` e canal geral fechado, sem requisições Google nesses casos.
- Segredos da 0.1.0 preservados byte a byte cifrados, decifração e ocultação pela API de opções após atualizar.
- Endpoint `/wp-json/mcp/wp-mcp-ultimate`, três metatools, todas as habilidades Google descobertas e execução pelo metatool.

A contagem final e os desfechos ficam nos arquivos JSON gerados. O catálogo é derivado do registro real, evitando depender de totais declarados no plano.
