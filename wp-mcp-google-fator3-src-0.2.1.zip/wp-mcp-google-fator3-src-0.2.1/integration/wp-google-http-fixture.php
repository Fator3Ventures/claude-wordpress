<?php
/** Google transport double for REAL WordPress integration. No Google account is contacted. */
function google_fixture_response(array $payload, int $code=200): array {
 return ['headers'=>['content-type'=>'application/json'],'body'=>json_encode($payload,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE),'response'=>['code'=>$code,'message'=>$code===200?'OK':'Forbidden'],'cookies'=>[],'filename'=>null];
}
function google_fixture_http($pre, array $args, string $url) {
 $parts=parse_url($url);$host=$parts['host']??'';$path=$parts['path']??'';$method=$args['method']??'GET';$query=[];parse_str($parts['query']??'',$query);
 $body=is_string($args['body']??null)?json_decode($args['body'],true):(array)($args['body']??[]);if(!is_array($body))$body=[];
 $jsonBody=is_string($args['body']??null)?json_decode($args['body']):null;$manualCpc=$jsonBody->operations[0]->create->manualCpc??($jsonBody->mutateOperations[0]->campaignOperation->create->manualCpc??null);$GLOBALS['google_fixture_calls'][]=['host'=>$host,'path'=>$path,'method'=>$method,'validate_only'=>$body['validateOnly']??null,'manual_cpc_object'=>$manualCpc!==null?is_object($manualCpc):null];
 if($host==='oauth2.googleapis.com')return google_fixture_response(['access_token'=>'fixture-access-token','expires_in'=>3600,'token_type'=>'Bearer']);
 if(str_contains($path,'discovery')){
  $map=['analyticsadmin.googleapis.com'=>'analyticsadmin-'.($query['version']??'v1alpha').'.json','analyticsdata.googleapis.com'=>'analyticsdata-'.($query['version']??'v1beta').'.json','googleads.googleapis.com'=>'googleads-v25.json','searchconsole.googleapis.com'=>'searchconsole-v1.json','sheets.googleapis.com'=>'sheets-v4.json'];
  $file=$map[$host]??(str_contains($path,'siteVerification')?'siteverification-v1.json':(str_contains($path,'drive')?'drive-v3.json':null));
  if(!$file)return new WP_Error('integration_missing_discovery_fixture','Unmodeled discovery URL: '.$host.$path);
  $fixtureDir=defined('F3_MCP_GOOGLE_DIR')&&is_file(F3_MCP_GOOGLE_DIR.'tests/fixtures/discovery/'.$file)?F3_MCP_GOOGLE_DIR.'tests/fixtures/discovery/':__DIR__.'/discovery/';$raw=file_get_contents($fixtureDir.$file);$response=google_fixture_response([]);$response['body']=$raw;return $response;
 }
 if(($GLOBALS['google_fixture_mode']??'success')==='denied')return google_fixture_response(['error'=>['code'=>403,'status'=>'PERMISSION_DENIED','message'=>'Insufficient permissions for this resource.','errors'=>[['reason'=>'insufficientPermissions']]]],403);
 if($host==='analyticsadmin.googleapis.com'){
  if(str_ends_with($path,'/accountSummaries'))return google_fixture_response(['accountSummaries'=>[['name'=>'accountSummaries/100','account'=>'accounts/100','displayName'=>'Fixture account','propertySummaries'=>[['property'=>'properties/123456','displayName'=>'Fixture Site'],['property'=>'properties/123','displayName'=>'Fixture GA'],['property'=>'properties/987654','displayName'=>'Other Site']]]]]);
  $name=preg_replace('#^/v1(?:alpha|beta)/#','',$path);$name=preg_replace('/:[^\/]+$/','',$name);
  if(str_contains($path,':provisionAccountTicket'))return google_fixture_response(['accountTicketId'=>'fixture-ticket']);
  if(str_contains($path,'/accessBindings'))return google_fixture_response(['name'=>$name,'user'=>'person@example.com','roles'=>['predefinedRoles/viewer'],'accessBindings'=>[]]);
  if(str_contains($path,'/measurementProtocolSecrets'))return google_fixture_response(['name'=>$name.'/7','secretValue'=>'fixture-mp-secret-redact-me','displayName'=>'Server']);
  if($method==='DELETE')return google_fixture_response([]);
  return google_fixture_response(array_merge(['name'=>$name,'displayName'=>'Fixture Site','propertyType'=>'PROPERTY_TYPE_ORDINARY','timeZone'=>'America/Sao_Paulo','currencyCode'=>'BRL','googleAdsLinks'=>[],'reportingDataAnnotations'=>[],'dataStreams'=>[],'keyEvents'=>[],'customDimensions'=>[],'customMetrics'=>[],'audiences'=>[],'accountTicketId'=>'fixture-ticket'], $body));
 }
 if($host==='analyticsdata.googleapis.com'){
  if(str_ends_with($path,'/metadata')){
   $dims=['date','dateHour','country','deviceCategory','eventName','campaignName','sessionCampaignName','pagePath','pageLocation'];$metrics=['sessions','activeUsers','conversions','keyEvents','eventCount','advertiserAdCost','totalUsers'];
   return google_fixture_response(['dimensions'=>array_map(static fn($n)=>['apiName'=>$n,'uiName'=>$n,'description'=>'Fixture '.$n,'category'=>'Fixture'], $dims),'metrics'=>array_map(static fn($n)=>['apiName'=>$n,'uiName'=>$n,'description'=>'Fixture '.$n,'type'=>'TYPE_INTEGER','category'=>'Fixture'], $metrics)]);
  }
  if(str_contains($path,':checkCompatibility'))return google_fixture_response(['dimensionCompatibilities'=>[],'metricCompatibilities'=>[]]);
  $dimensionNames=array_map(static fn($x)=>is_array($x)?($x['name']??'date'):(string)$x,$body['dimensions']??[]);$metricNames=array_map(static fn($x)=>is_array($x)?($x['name']??'sessions'):(string)$x,$body['metrics']??[]);
  $dimensionValues=array_map(static fn($n)=>['value'=>match($n){'date'=>'20260801','pagePath'=>'/article','pageLocation'=>'https://example.test/article','country'=>'Brazil','deviceCategory'=>'desktop','eventName'=>'purchase',default=>'Fixture campaign'}],$dimensionNames);
  $result=['dimensionHeaders'=>array_map(static fn($n)=>['name'=>$n],$dimensionNames),'metricHeaders'=>array_map(static fn($n)=>['name'=>$n,'type'=>'TYPE_INTEGER'],$metricNames),'rows'=>[['dimensionValues'=>$dimensionValues,'metricValues'=>array_map(static fn($n)=>['value'=>'10'],$metricNames)]],'rowCount'=>1];
  if(str_contains($path,':runFunnelReport'))return google_fixture_response(['funnelTable'=>$result,'funnelVisualization'=>$result]);
  return google_fixture_response($result);
 }
 if($host==='googleads.googleapis.com'){
  if(str_ends_with($path,':listAccessibleCustomers'))return google_fixture_response(['resourceNames'=>['customers/1234567890']]);
  if(str_contains($path,'googleAdsFields:search'))return google_fixture_response(['results'=>[['name'=>'campaign.id','category'=>'ATTRIBUTE','dataType'=>'INT64','selectable'=>true,'filterable'=>true,'sortable'=>true],['name'=>'campaign.name','category'=>'ATTRIBUTE','dataType'=>'STRING','selectable'=>true,'filterable'=>true,'sortable'=>true]]]);
  if(str_contains($path,'googleAds:search')){
   $row=['customer'=>['id'=>'1234567890','resourceName'=>'customers/1234567890','descriptiveName'=>'Fixture Ads','currencyCode'=>'BRL','timeZone'=>'America/Sao_Paulo','manager'=>false,'testAccount'=>true],'customerClient'=>['id'=>'1234567890','clientCustomer'=>'customers/1234567890','descriptiveName'=>'Fixture Ads','manager'=>false,'hidden'=>false,'status'=>'ENABLED','level'=>0],'campaign'=>['id'=>'1','resourceName'=>'customers/1234567890/campaigns/1','name'=>'Fixture campaign','status'=>'PAUSED'],'metrics'=>['clicks'=>'2','impressions'=>'20','costMicros'=>'1000000','conversions'=>3.0,'conversionsValue'=>30.0,'allConversions'=>3.0,'allConversionsValue'=>30.0,'ctr'=>0.1,'averageCpc'=>'500000','costPerConversion'=>'333333'],'segments'=>['date'=>'2026-08-01','conversionActionName'=>'Purchase','conversionAction'=>'customers/1234567890/conversionActions/1'],'conversionAction'=>['id'=>'1','resourceName'=>'customers/1234567890/conversionActions/1','name'=>'Purchase','status'=>'ENABLED','type'=>'UPLOAD_CLICKS','category'=>'PURCHASE'],'asset'=>['id'=>'1','name'=>'Fixture asset','resourceName'=>'customers/1234567890/assets/1'],'userList'=>['id'=>'1','name'=>'Fixture audience','resourceName'=>'customers/1234567890/userLists/1'],'customerUserAccess'=>['userId'=>'1','accessRole'=>'READ_ONLY','emailAddress'=>'fixture@example.invalid'],'experiment'=>['resourceName'=>'customers/1234567890/experiments/1','name'=>'Fixture experiment','status'=>'SETUP']];
   $selected='';preg_match('/SELECT\s+(.+?)\s+FROM/is',(string)($body['query']??''),$selectedMatch);$selected=$selectedMatch[1]??'';$result=['results'=>[$row],'fieldMask'=>preg_replace('/\s+/','',$selected)];return google_fixture_response(str_contains($path,'searchStream')?[$result]:$result);
  }
  if(str_contains($path,':createOfflineUserDataJob'))return google_fixture_response(['resourceName'=>'customers/1234567890/offlineUserDataJobs/5']);
  if(str_contains($path,':run')||str_contains($path,':scheduleExperiment'))return google_fixture_response(['name'=>'customers/1234567890/operations/fixture-operation']);
  if(str_contains($path,':mutate')){
   preg_match('#/customers/([0-9]+)/([^/:]+):mutate#',$path,$match);$resource=($match[2]??'campaigns');if($resource==='googleAds')$resource='campaigns';
   $rn='customers/1234567890/'.$resource.'/1';return google_fixture_response(['results'=>[['resourceName'=>$rn]],'mutateOperationResponses'=>[['campaignResult'=>['resourceName'=>$rn]]],'resourceName'=>$rn]);
  }
  if(str_contains($path,':uploadClickConversions'))return google_fixture_response(['results'=>$body['conversions']??[]]);
  if(str_contains($path,':addOperations'))return google_fixture_response([]);
 }
 if($host==='searchconsole.googleapis.com'||($host==='www.googleapis.com'&&str_contains($path,'/webmasters/'))){
  if(str_contains($path,':inspect'))return google_fixture_response(['inspectionResult'=>['indexStatusResult'=>['verdict'=>'PASS','coverageState'=>'Submitted and indexed']]]);
  if(str_contains($path,'searchAnalytics/query')){
   $keys=array_map(static fn($d)=>match($d){'date'=>'2026-08-01','device'=>'DESKTOP','country'=>'bra','page'=>'https://example.test/article',default=>'fixture query'},$body['dimensions']??[]);
   return google_fixture_response(['rows'=>[['keys'=>$keys,'clicks'=>2,'impressions'=>20,'ctr'=>0.1,'position'=>3.5]],'responseAggregationType'=>'byPage']);
  }
  if(str_contains($path,'/sitemaps'))return google_fixture_response(['sitemap'=>[],'path'=>'https://example.test/sitemap.xml','lastSubmitted'=>'2026-09-01T00:00:00.000Z','isPending'=>false]);
  if(str_ends_with($path,'/sites'))return google_fixture_response(['siteEntry'=>[['siteUrl'=>'https://example.test/','permissionLevel'=>'siteOwner'],['siteUrl'=>'sc-domain:example.test','permissionLevel'=>'siteOwner']]]);
  return google_fixture_response(['siteUrl'=>'https://example.test/','permissionLevel'=>'siteOwner']);
 }
 if($host==='www.googleapis.com'&&str_contains($path,'/siteVerification/')){
  if(str_ends_with($path,'/token'))return google_fixture_response(['token'=>'google-site-verification=fixture-token','method'=>$body['verificationMethod']??'META']);
  return google_fixture_response(['id'=>'verified-example','site'=>['type'=>'SITE','identifier'=>'https://example.test/'],'owners'=>['owner@example.test'],'items'=>[]]);
 }
 if($host==='www.google-analytics.com')return google_fixture_response(['validationMessages'=>[]]);
 if($host==='sheets.googleapis.com'){
  if(str_contains($path,'/values/'))return google_fixture_response(['range'=>'Report!A1:B51','majorDimension'=>'ROWS','values'=>[['date','sessions'],['20260801',10]]]);
  if(str_contains($path,':batchUpdate'))return google_fixture_response(['spreadsheetId'=>'fixture_sheet_123','replies'=>[]]);
  return google_fixture_response(['spreadsheetId'=>'fixture_sheet_123','spreadsheetUrl'=>'https://docs.google.com/spreadsheets/d/fixture_sheet_123/edit','properties'=>['title'=>'Integration fixture'],'sheets'=>[['properties'=>['sheetId'=>0,'title'=>'Report','gridProperties'=>['rowCount'=>1000,'columnCount'=>26]]]]]);
 }
 if($host==='www.googleapis.com'&&str_contains($path,'/drive/')){
  if(str_contains($path,'/permissions'))return google_fixture_response(['id'=>'fixture_permission','type'=>'user','role'=>'reader','emailAddress'=>'fixture@example.invalid','permissions'=>[]]);
  if((str_contains($path,'fixture_shared_folder')||str_contains($path,'fixture-folder-id')))return google_fixture_response(['id'=>'fixture_shared_folder','mimeType'=>'application/vnd.google-apps.folder','driveId'=>'fixture_drive','capabilities'=>['canAddChildren'=>true]]);
  return google_fixture_response(['id'=>'fixture_sheet_123','name'=>'Integration fixture','mimeType'=>'application/vnd.google-apps.spreadsheet','files'=>[]]);
 }
 $GLOBALS['google_fixture_unmodeled'][]=$host.$path;
 return new WP_Error('integration_unmodeled_http','No HTTP fixture for '.$method.' '.$host.$path);
}
