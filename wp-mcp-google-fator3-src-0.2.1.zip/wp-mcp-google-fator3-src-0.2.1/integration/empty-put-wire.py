#!/usr/bin/env python3
"""Reproduz 411 em HTTP local usando o transporte Requests distribuído com WordPress."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import threading

parser = argparse.ArgumentParser()
parser.add_argument('--php', required=True)
parser.add_argument('--plugin', required=True)
parser.add_argument('--requests', required=True, help='Diretório wp-includes/Requests de uma instalação WordPress')
parser.add_argument('--expect-411', action='store_true')
args = parser.parse_args()
captured = []


class Endpoint(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, *unused):
        pass

    def handle_request(self):
        length = self.headers.get('Content-Length')
        body = self.rfile.read(int(length or '0'))
        captured.append({'method': self.command, 'path': self.path,
                         'content_length': length, 'body_bytes': len(body),
                         'content_type': self.headers.get('Content-Type')})
        if self.path == '/token':
            status, payload = 200, {'access_token': 'dummy-local-access', 'expires_in': 3600}
        elif self.command == 'PUT':
            if length is None:
                status, payload = 411, {'error': {'code': 411, 'message': 'Length Required'}}
            elif length != '0' or body:
                status, payload = 400, {'error': {'code': 400, 'message': 'Request body must be empty'}}
            else:
                status, payload = 204, None
        else:
            status, payload = 200, {}
        encoded = b'' if payload is None else json.dumps(payload).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    do_GET = handle_request
    do_POST = handle_request
    do_PUT = handle_request


server = ThreadingHTTPServer(('127.0.0.1', 0), Endpoint)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    completed = subprocess.run(
        [args.php, str(Path(__file__).with_suffix('.php')), args.plugin, args.requests,
         f'http://127.0.0.1:{server.server_port}'], capture_output=True, text=True, timeout=30)
    if completed.returncode:
        raise RuntimeError(completed.stderr + completed.stdout)
    report = json.loads(completed.stdout)
    puts = [r for r in captured if r['method'] == 'PUT']
    statuses = [r['status'] for r in report['wire'] if r['method'] == 'PUT']
    assert len(puts) == 3, captured
    assert statuses == [411 if args.expect_411 else 204] * 3, report
    assert all(r['success'] == (not args.expect_411) for r in report['results']), report
    assert all(r['body_bytes'] == 0 for r in puts), puts
    assert all(r['content_length'] == (None if args.expect_411 else '0') for r in puts), puts
    assert all(r['content_type'] is None for r in puts), puts
    report['captured_puts'] = puts
    report['expected_http_status'] = 411 if args.expect_411 else 204
    report['passed'] = True
    print(json.dumps(report, indent=2))
finally:
    server.shutdown()
    server.server_close()
