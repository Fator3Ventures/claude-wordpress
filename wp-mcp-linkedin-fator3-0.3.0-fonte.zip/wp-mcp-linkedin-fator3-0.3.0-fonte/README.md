# Desenvolvimento — wp-mcp-linkedin-fator3 0.3.0

GPL-2.0-or-later. Este fonte é autônomo para reconstruir seu próprio instalador. Código exato em plugin/wp-mcp-linkedin-fator3; templates em build/common e build/linkedin; nenhuma dependência de runtime do outro social. Leia o relatório desta pasta e os guias em plugin/wp-mcp-linkedin-fator3/docs/.

## Reconstruir o instalador

Requer Python 3.12+ e PHP CLI 8.1.2+; release reconstruída com Python 3.12.14, zlib 1.3.2 e PHP 8.3.6. O runner de laboratório usa extração segura de tar com filter=data; utilize Python com esse recurso (3.12+, ou distribuição com backport). Não instale este ZIP como plugin.

```bash
export F3_SOCIAL_PHP=/caminho/para/php
python3 build/build.py
```

Resultado em build/dist/wp-mcp-linkedin-fator3-0.3.0-instalador.zip. Metadados ZIP fixos; não editar arquivos gerados. SHA esperado: b6d20998379236baf46ac5ae0181646e8a15fb75bbb4f37a88a68be01d2d768a. evidence/build-reproduction.json registra a reconstrução a partir desta árvore. A biblioteca zlib/Python pode alterar compressão entre versões; a prova desta rodada é byte a byte no ambiente registrado.

## Dependências de laboratório

Os instaladores-base 0.2.0, acompanhantes, WordPress e runtimes não integram o ZIP fonte. Obtenha os pacotes de referência com o dono e valide pelos hashes dos manifestos. Binários de PHP/MySQL de desenvolvimento são pacotes públicos Ubuntu fixados em tools/runtime-dependencies.json e tools/php81-dependencies.json. Em Linux x86_64 com dpkg-deb/tar:

```bash
export F3_RUNTIME_DOWNLOAD_ROOT="$(pwd)/../social-030-deps"
python3 tools/fetch-runtime.py
python3 tools/fetch-php81.py
export LD_LIBRARY_PATH="$F3_RUNTIME_DOWNLOAD_ROOT/runtime/usr/lib/x86_64-linux-gnu"
export F3_SOCIAL_PHP="$F3_RUNTIME_DOWNLOAD_ROOT/runtime/usr/bin/php8.3"
python3 build/build.py
```

Use downloads oficiais https://wordpress.org/wordpress-7.1.2.tar.gz e https://wordpress.org/wordpress-6.4.tar.gz. Coloque-os em social-030-deps, junto aos instaladores canônicos referidos nos manifestos. Ajuste caminhos se necessário; preserve os hashes esperados. Não copie tokens, salts ou banco de produção. O runner verifica hashes de arquivo/árvore, recusa diretório de trabalho não vazio, usa banco e porta isolados e intercepta o HTTP de fornecedores. Não requer WP-CLI. Matrizes reais executadas nesta release estão em evidence/lab-*/.

## Executar os testes

Para somente este plugin (runner suporta --order linkedin-only), use tools/dependencies.example.json com runtime, WordPress e base deste plugin. Para reproduzir a matriz completa com ambos os sociais, copie também o instalador meta 0.3.0 fornecido separadamente para build/dist e use tools/trio-dependencies.example.json. O teste de atualização exige ambas as bases 0.2.0; a instalação limpa com trio exige os três acompanhantes pelos hashes declarados.

```bash
python3 tools/lab.py --manifest tools/trio-dependencies.example.json --workdir ../lab-030-clean-new --origin clean --order trio-first
python3 tools/lab.py --manifest tools/trio-dependencies.example.json --workdir ../lab-030-upgrade-new --origin upgrade --order social-first
python3 tools/lab.py --manifest tools/minimum-dependencies.example.json --workdir ../lab-030-min-new --origin clean --order meta-first
```

As 196 verificações reportadas referem-se à matriz conjunta acima, não a uma execução individual deste fonte. Script --ui e testes visuais herdados são auxiliares históricos; não foram usados para atestar esta rodada e exigem dependências de navegador próprias. Apenas fixtures sintéticas nos testes. O runner encerra MySQL e remove seu datadir temporário ao terminar. Mantenha evidências de novas execuções fora da árvore de release.

## Fechar novamente o fonte preparado

```bash
python3 tools/package-source.py --output-dir ../reconstrucao-fonte
```

O empacotador seleciona somente as pastas de desenvolvimento/entrega, ignora build/dist e caches, recusa ZIP aninhado e sobrescrita de fonte fechado. Não coloca a identidade do próprio arquivo dentro dele. A cópia interna do relatório é anterior ao fechamento; o relatório externo entregue é definitivo.
