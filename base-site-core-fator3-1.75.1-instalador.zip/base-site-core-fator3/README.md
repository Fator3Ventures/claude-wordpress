# Fator3 Site Core 1.75.1

Requer WordPress 7.1.4 e PHP 8.3. Atualização direta da 1.74.0. Contrato administrativo 8.36.0. Consulte docs/DOCUMENTACAO.md e docs/RELEASE-1.75.1.md.


