# Instalação, atualização e reversão — Meta 0.12.0

Base direta aceita: 0.11.1. Instalar o ZIP 0.12.0 sobre a pasta/basename existente wp-mcp-meta-fator3/wp-mcp-meta-fator3.php, sem desinstalar. Fazer backup de arquivos, banco e salts; conferir SHA-256 do relatório. Verificar versão em PHP novo, health/selftest, 41 operações e 23 documentos completos com hashes. O fonte não é instalável.

Não há nova tabela nem migração automática de dados de negócio. Mantidos schemas de registros 2 e histórico 1; política unlimited e marcador f3_meta_retention0110 permanecem. O novo SDK só grava após exclusão administrativa explícita. Buckets novos: message_suppression, message_erasure_receipt e message_privacy_scope; option f3_meta_message_privacy_key criada na primeira exclusão válida. Tudo sem expiração automática.

Core1.56.0 continua consumindo instagram-first-message/1.0.0; não chama o novo SDK de exclusão. O mantenedor Core deve usar instagram-message-erasure/1.0.0 depois de confirmar sua própria eliminação, fora de transação SQL ativa, e manter pendência enquanto não obtiver recibo. Leia MESSAGE-PRIVACY.md para sequência, schema e limites. Não modificar tabelas/options privadas como alternativa.

## Reversão e preservação de exclusões

Voltar à 0.11.1 remove a interpretação dos bloqueios novos: antes de qualquer downgrade, desligar recepção/contatos e a assinatura do webhook, cancelar processamento de mensagens e manter os bloqueios/chave/recibos. Não reativar ingestão em versão que ignore esses registros. Uma restauração de banco anterior à exclusão também exige reaplicar exclusões e bloqueios antes de habilitar ingestão.

Arquivos antigos não recuperam dados eliminados nem desfazem contatos externos. Preserve banco, salts e a chave de privacidade juntos; se a chave existir mas estiver ilegível, a versão atual interrompe recepção/processamento. Não remova a option para mascarar o erro. Não apagar bloqueios/recibos durante limpeza do diário. Desativação/desinstalação preserva dados e remove apenas eventos próprios. Outras funções e a retenção ilimitada permanecem independentes da integração comercial.
