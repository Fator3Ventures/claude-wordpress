# Preservação de dados — Meta 0.12.0

Orientação explícita do responsável em 26/10/2026: priorizar o valor dos dados e aumentar ao máximo a retenção. Esta política substitui o plano inicial de arquivo de 30 dias/1.000 Stories/64 MiB e diário de 10.000 candidatos.

- Novas conexões usam retenção ilimitada para resultados e histórico. Na primeira carga da série 0.11, conexões existentes passam a `retention_mode=unlimited` e os prazos dos registros históricos ainda presentes são estendidos a zero (sem expiração). Credenciais, escopos, geração de token, seleção de ativos e agendas permanecem preservados; a revisão da configuração aumenta quando muda a política. Uma escolha futura explícita de retenção finita de métricas continua disponível no painel.
- Resultados/coletas retidos, índice histórico, auditoria administrativa e de worker, exportações, metadados/recibos de conversas e Stories arquivados não são eliminados automaticamente por idade. Arquivo de Stories e diário de mensagens não têm teto total de quantidade/tamanho. Não há descarte do mais antigo para liberar espaço.
- A migração inicial amplia a retenção de registros ainda existentes, inclusive órfãos cifrados; não concede acesso, não reativa credencial e não recupera dados já apagados. Registros que a chave do site não consegue abrir precisam de recuperação antes de completar a migração de política; a manutenção não deve apagar dados nessa condição.
- Cursores, confirmações, prévias e demais autorizações temporárias mantêm seus prazos de segurança. Limites por chamada, tamanho de download/imagem, quantidade por página e memória de processamento também permanecem. Retenção ilimitada não significa chamadas ilimitadas nem mudança das restrições da Meta.
- O escopo de coleta não foi ampliado para texto de mensagens, anexos ou vídeo completo. As miniaturas reduzidas e os metadados já previstos são preservados. Cada remetente/conta/conexão mantém seu candidato/recibo de primeira mensagem; mensagens subsequentes não viram um arquivo integral de chat.
- Exclusão futura deve ser deliberada, administrativa e compatível com política de privacidade do responsável. Não há rotina de limpeza automática de contatos do Core; sua política e deduplicação permanecem com o Core. Mantenha backups do banco e das chaves WordPress fora do plugin.

A marca técnica `f3_meta_retention0110` registra conclusão; a migração pode retomar em nova carga se interrompida. A alteração de prazos é intencional e é coberta pelo teste de atualização direta da 0.10.1. Reverter arquivos para a 0.10.1 não restaura automaticamente prazos finitos anteriores. Exportações antigas ainda existentes permanecem legíveis sob autorização atual; recibos novos indicam expires_at=0.

## Eliminação explícita na 0.12.0

O SDK Messaging acrescenta privacyContract, privacyStatus, eraseLocalData e erasureReceipt, contrato instagram-message-erasure/1.0.0. A eliminação administrativa solicitada prevalece sobre retenção ilimitada; bloqueios pseudônimos e recibos permanecem. Nenhum processo automático apaga dados nem habilita contatos. Leia MESSAGE-PRIVACY.md para revisão, autorização atual, falhas parciais, cron e preservação de chaves.
