# Fator3 MCP Meta 0.12.0

Plugin independente. Configure em Ferramentas > Fator3 MCP Meta. Entradas humanas (painel, REST, abilities/MCP, arquivos e tarefas iniciadas por usuário) exigem `manage_options`. A lista legada `users` não concede acesso a pessoas sem essa capacidade. O transporte MCP é opcional; o plugin não chama Google, Core ou outro provedor para executar relatórios.

## Eliminação local na 0.12.0

SDK público instagram-message-erasure/1.0.0: revisão, idempotência, recibo, remoção de identificadores locais e bloqueio durável de reimportação, inclusive com token revogado ou conexão removida. Core1.56.0 deve integrar a chamada posterior à sua própria exclusão. Leia MESSAGE-PRIVACY.md e messaging-privacy-schema.json. O contrato de ingestão e as 41 abilities permanecem.

## Pedidos 18 e 19 na série 0.11

Conversas Instagram sem texto, diagnóstico de escopos/App Review, recepção assinada e SDK opcional de contatos (consumidor disponível no Core 1.56.0, com opt-in), novos insights e arquivo privado de Stories sem expiração automática. Leia INSTAGRAM-MESSAGING.md e STORY-ARCHIVE.md para limites e configuração.

## Preservação solicitada em 26/10/2026

Histórico, resultados, auditoria, exportações, metadados de conversas e arquivo de Stories priorizam retenção ilimitada. A atualização amplia os prazos dos dados ainda existentes; não altera expiração de tokens ou cursores. Leia RETENTION.md.

## Índice instalado

- MESSAGE-PRIVACY.md — autorização, eliminação, recibos, concorrência e recuperação.
- messaging-privacy-schema.json — schema gerado do SDK local de eliminação.

- RETENTION.md — retenção máxima, atualização e limites de segurança.
- INSTAGRAM-MESSAGING.md — conversas, autorização, webhooks e SDK do Core.
- STORY-ARCHIVE.md — métricas, agenda horária e arquivo privado limitado.
- ADMINISTRATION.md — abas, seletores e fluxos de administração.
- AGENTS.md — operação por agentes e limites de autorização.
- CONFIGURATION.md — tokens, seleção e acesso.
- OPERATIONS.md — consultas, processamento e exportações.
- CONTRACTS.md — contratos, REST/MCP, schemas e erros.
- SDK-PHP.md — SDK local e responsabilidade de consumidores.
- SECURITY.md — isolamento, dados e autorização.
- MIGRATION.md — atualização, retenção e rollback.
- PAGE-VIEWS.md — campo de visualizações do perfil e limites de validação.
- PAGE-DIAGNOSTICS.md — diagnóstico de permissões e insights por Página.
- TROUBLESHOOTING.md — diagnóstico, limites e falhas.
- CHANGELOG.md — alterações da versão.
- WORKER.md — fila, recuperação, diagnóstico somente leitura (`meta/health`) e alertas.
- abilities-pt-br.json — rótulos e descrições das 41 habilidades, gerados do registro.
- input-schemas.json e output-schema.json — contratos gerados pelo build.

Todos estes arquivos integram o instalador e o conteúdo retornado por `meta/documentation`. Consulte `{"document":"index"}`. Para ler um documento use `document`, `offset` (bytes) e `limit_bytes` (256–65536). Continue por `next_offset`, repetindo `expected_revision` igual a `revision`. Concatene `content` sem separadores; confira o SHA-256 integral indicado. O cursor documental não faz HTTP, não migra armazenamento, não grava auditoria nem lê caminhos arbitrários. A resposta identifica slug, versão, origem local, tamanho e hash. O painel usa a mesma operação.

## Histórico — Patch 0.11.1

A documentação corrente passa a refletir a retenção ilimitada já implementada na 0.11.0, o SDK opcional e o catálogo de 41 operações. Código funcional e schemas não mudam no patch. Base direta de referência: 0.10.1; a 0.11.0 não é pré-requisito.

## Instalação e dependências

WordPress 6.4+, PHP 8.1.2+ de 64 bits (mínimos exercitados na 0.7.0: WordPress 6.4 com PHP 8.1.2, sem Abilities API; e WordPress 7.1.3 com PHP 8.3.6), MySQL/MariaDB com InnoDB e bloqueios nomeados, criptografia sodium ou AES-256-GCM, HTTPS externo e WP-Cron ou cron real. Abilities exigem a API de abilities disponível; em WordPress sem ela o painel e REST continuam operando. Instale o ZIP instalador; o ZIP fonte é para desenvolvimento. Consulte o relatório da entrega para a matriz de versões efetivamente testadas.

Tokens nunca são retornados por APIs de configuração. Configuração local, teste com respostas simuladas e homologação externa são estados distintos. Acesso real depende de produtos, permissões, ativos e versões liberados pelo fornecedor.

## Habilidades em português — Pedido 12

Os rótulos e descrições são definidos pelo Meta e exibidos pelo MCP em Clientes conectados, no filtro Habilidade do Registro e na descoberta. Por exemplo: `meta/save-schedule` aparece como “Meta: salvar agenda de coleta”. Os identificadores técnicos permanecem iguais para preservar perfis e integrações. Leia `abilities-pt-br.json` pela operação documental para o mapeamento completo.

## Histórico — Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.

## Histórico — Novidades da 0.7.0

- `meta/health` (nova, leitura): o mesmo diagnóstico de `meta/status` sem rearmar o worker, sem e-mail e sem chamar a Meta. Grava apenas a linha de auditoria local, como toda operação despachada. O perfil de leitura do Fator3 MCP pode usá-la; `meta/status` continua exigindo escrita local porque recupera o worker.
- Recuperação: a manutenção horária `f3_meta_maintenance` é recriada na requisição seguinte se desaparecer do cron; o diagnóstico mostra `maintenance_missing` enquanto isso.
- Carregamento: nenhuma consulta SQL própria do pacote por requisição depois da primeira (marcas em autoload e migração confirmada); um registro de coleta que a chave atual do site não abre fica marcado `unreadable`, não bloqueia a migração dos demais e sai da seleção da retenção, e aparece como `queue_record_unreadable`.
- Registro (`meta/audit`): eventos do mais recente ao mais antigo, com filtro opcional `since` (Unix, segundos).
- 35 operações públicas: as 33 anteriores, com identificadores, rótulos e schemas preservados (exceto o campo opcional `since` em `meta/audit`), e `meta/health`.


## Histórico — Entrega 0.9.0

Base direta 0.8.0. Pedido 15 entregue: credenciais conferidas antes da escrita, campos orientados, identidade visível e agendas regravadas atomicamente. Leia CONFIGURATION.md para fluxo de troca e CONTRACTS.md para meta/switch-identity. São 35 operações administrativas. A disponibilidade de métricas reais depende do token, ativos e permissões homologados pelo operador.


## Histórico — Versão 0.10.0 — Pedidos MCP Meta 16 e 17

A prévia de troca de identidade aparece junto do formulário que a pediu; a origem Renovar token abre o bloco automaticamente. A prévia recebe foco e anúncio acessível. A recusa de identidade fica junto de Salvar conexão e aponta o botão de troca. `meta/switch-identity` aceita `label` opcional (até 120 caracteres): o nome é incluído na prévia (`connection_label`), vinculado à confirmação e salvo junto da credencial e das agendas na mesma revisão/transação. Sem label, preserva o nome salvo. Editar a candidata invalida a prévia; resposta assíncrona obsoleta não a reabre.

Stories indisponíveis têm códigos próprios; revogação da conexão exige confirmação independente. Agendas e auditoria guardam código Graph, subcódigo, HTTP e instante. O aviso passa a uma tentativa por incidente e mostra a causa medida. Consulte `COLLECTION-DIAGNOSTICS.md` para códigos, efeitos, recuperação, persistência e limites. Na série 0.10, os 35 IDs de operações foram preservados e label foi acrescentado a switch-identity. Na série 0.11, somam-se seis operações, totalizando 41.
