# Eliminação local de mensagens — Meta 0.12.0

Contrato PHP público aditivo `instagram-message-erasure/1.0.0`, pelo SDK `Fator3\Meta\Messaging`. Atende ao impacto Core1.56.0 → Meta, revisão1, Meta18(b)/Core309. O contrato de ingestão `instagram-first-message/1.0.0` permanece compatível. Não há ability ou endpoint de eliminação novo; o consumidor local deve aplicar sua própria política e proteção da entrada administrativa antes de chamar o SDK.

## Autorização e alvo

Exige `manage_options` atual. Se houver contexto MCP, verifica também a concessão corrente; revogação da concessão de transporte não equivale à revogação do token Meta. A eliminação não requer token Meta válido, recepção ativa, ativo ainda selecionado, conexão existente, consumidor registrado ou chamada Graph. Um administrador atual pode apagar o dado local mesmo depois de remover a conexão.

Alvo: `connection_id`, `account_id` e exatamente um de `sender_id` ou `event_id`. O event_id publicado na ingestão identifica o remetente escopado à conexão/conta; não é o message_id da Graph nem o record_id do contato. O diário contém um registro por esse escopo. A eliminação remove esse registro inteiro, incluindo sender_id, message_id, referências de origem, datas e record_id. Alvo em outra conta/conexão é recusado. Para alvo ainda ausente, registra bloqueio preventivo no escopo informado.

## Métodos e exemplo

`privacyContract()` fornece schema e metadados; `messaging-privacy-schema.json` é gerado desse mesmo contrato. `privacyStatus($target)` é leitura local e retorna estado, presença de identificadores, bloqueio de reimportação e `revision` opaca de 64 caracteres. Essa revisão não é a revisão inteira de deliveryReceipt. Erros são `Fator3\Meta\Fault`, com `reason` sem valores pessoais.

```php
$sdk = \Fator3\Meta\Messaging::class;
$contract = $sdk::privacyContract();
if ($contract['contract'] !== 'instagram-message-erasure/1.0.0') {
    throw new \RuntimeException('Contrato de eliminação incompatível');
}
$target = [
    'connection_id' => $connectionId,
    'account_id' => $accountId,
    'event_id' => $eventId, // ou sender_id, nunca ambos
];
$state = $sdk::privacyStatus($target);
// Guarde a chave da operação antes da chamada; não inclua dados do titular nela.
$request = $target + [
    'expected_revision' => $state['revision'],
    'idempotency_key' => $stableRequestId,
];
$receipt = $sdk::eraseLocalData($request);
$confirmed = $sdk::erasureReceipt($stableRequestId);
```

O Core deve capturar o alvo antes de remover seu payload privado, confirmar sua própria eliminação/transação, e então chamar o Meta. A chamada durante transação SQL ativa é recusada com `transaction_active`; não confirma nem desfaz a transação do Core. Um processo coordenador pode manter o alvo cifrado somente enquanto necessário à exclusão e apagá-lo após conferir o recibo. Core1.56.0 ainda não chama este contrato; sua indicação `pendente_sdk_exclusao_meta` permanece até o mantenedor integrar o fluxo.

## Concorrência, repetição e falhas

A mesma trava protege recepção, entrega e eliminação. Primeiro é gravado bloqueio durável, depois são removidas as continuações de cron da conta e o registro pessoal. Uma geração de privacidade impede o worker de agendar uma continuação calculada antes da exclusão. A rotina não inicia transação nem confirma transação alheia.

O mesmo pedido com a mesma chave retorna o mesmo recibo quando a conclusão continua válida. A chave não pode ser reutilizada para outro alvo (`idempotency_conflict`). Revisão obsoleta é `revision_conflict`. Interrupção após bloqueio pode deixar `erasure_incomplete`: o remetente já fica impedido de reimportação, mas não se declara exclusão concluída. Após corrigir a falha, repetir exatamente o pedido e sua chave permite retomar. Se um recibo anterior divergir do armazenamento atual, `erasure_state_changed` exige nova leitura/revisão e nova chave; não retorna sucesso de uma exclusão desfeita por restauração externa.

Recibo mínimo: contrato, receipt_id opaco, state=erased, local_identifiers_removed=true, reimportation_blocked=true, revisão de conclusão, completed_at Unix e external_copies_erased=false. Não contém conexão, conta, remetente, mensagem, event_id, record_id, texto ou origem. `erasureReceipt` consulta o recibo histórico; `privacyStatus` verifica o estado local corrente. Ausência de recibo não comprova ausência de efeitos: não reimporte para testar.

## Bloqueio durável, retenção e limites

Buckets `message_suppression`, `message_erasure_receipt` e `message_privacy_scope` usam a tabela cifrada existente, sem expiração. Chaves são HMAC com segredo aleatório próprio por site, cifrado na option `f3_meta_message_privacy_key`; não guardam os identificadores brutos nem o hash público antigo do evento. Permanecem apenas correlações técnicas necessárias ao bloqueio/repetição. São pseudônimos de proteção, não uma afirmação de anonimização absoluta.

A limpeza do diário `message_event` não remove bloqueios. Reinício, revogação do token e remoção/recriação da mesma conexão não liberam o remetente. Não existe desbloqueio automático nem prazo de expiração. Nova connection_id/conta é outro escopo: o pacote não tenta identificar a pessoa entre escopos distintos. Core deve preservar sua deduplicação própria.

Preserve segredo de privacidade, salts, bloqueios e recibos em backups/restaurações. Se a chave não abrir, ou estiver ausente enquanto houver bloqueios/recibos, a recepção/processamento falham de modo fechado com `privacy_key_unavailable`; não há recriação silenciosa. Remover manualmente a chave e os bloqueios ou restaurar backup anterior à exclusão compromete a garantia. A eliminação do banco ativo não apaga backups externos; o responsável deve aplicar os recibos/retenção de backups no processo de restauração.

A exclusão explícita prevalece sobre a retenção ilimitada solicitada. Não muda a retenção das demais funcionalidades. Não apaga Core, Pipedrive, mensagens na Meta, respostas/cópias já entregues ao cliente ou cursores que o cliente já recebeu. A leitura autorizada de conversas continua consultando a fonte remota; o bloqueio impede novo armazenamento no diário e entrega automática ao Core. Não se declara exclusão na Graph ou consentimento por ausência de dados locais.

Referência técnica: RELEASE SAVEPOINT não confirma nem desfaz trabalho da transação, conforme [MySQL](https://dev.mysql.com/doc/refman/8.0/en/savepoint.html). A detecção foi exercitada no MySQL8.0.41 do Site-Teste; não se declara teste nativo MariaDB nesta rodada.
