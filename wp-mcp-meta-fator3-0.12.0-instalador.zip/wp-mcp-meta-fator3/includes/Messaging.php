<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Facebook Login only. No send-message endpoint or arbitrary Graph proxy. */
final class Messaging {
    public const SCOPES=['instagram_basic','instagram_manage_messages','pages_manage_metadata'];
    public const CONTRACT='instagram-first-message/1.0.0';
    public const DAYS=0;
    public const MAX_EVENTS=0;
    private static $consumer=null;
    private static function key(array $c,string $account): string {return hash('sha256',$c['id'].'|'.$account);}
    public static function registerConsumer(string $id,string $contract,callable $handler): bool {
        if($id!=='site-core'||$contract!==self::CONTRACT||self::$consumer!==null)return false;self::$consumer=$handler;return true;
    }
    /** Additive local privacy SDK; ingestion CONTRACT remains unchanged. */
    public static function privacyContract(): array {Access::admin();return MessagePrivacy::contract();}
    public static function privacyStatus(array $target): array {return MessagePrivacy::status($target);}
    public static function eraseLocalData(array $request): array {return MessagePrivacy::erase($request);}
    public static function erasureReceipt(string $idempotencyKey): array {return MessagePrivacy::receipt($idempotencyKey);}
    public static function health(): array {
        Access::admin();$rows=[];$more=false;
        foreach(Connections::list(0,100) as $c)foreach($c['assets']['instagram']??[] as $account){if(count($rows)>=100){$more=true;break 2;}$s=self::status(['connection_id'=>$c['id'],'account_id'=>$account]);$rows[]=['connection_id'=>$c['id'],'account_id'=>$account,'enabled'=>$s['enabled'],'scope_status'=>$s['scope_status'],'missing_scopes'=>$s['missing_scopes'],'app_review'=>$s['app_review'],'consumer'=>$s['consumer']];}
        return ['accounts'=>$rows,'truncated'=>$more,'automatic_contacts_default'=>false];
    }
    private static function settings(array $c,string $account): array {
        $r=Store::get('messaging_config',self::key($c,$account));
        return $r?['revision'=>$r['revision']]+$r['value']:['revision'=>0,'connection_id'=>$c['id'],'account_id'=>$account,'enabled'=>false,'contacts_enabled'=>false,'page_id'=>'','app_review'=>'unknown','verify_token'=>'','activated_at'=>0,'authorization_revision'=>$c['authorization_revision'],'principal'=>null];
    }
    public static function status(array $i): array {
        Access::admin();$c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);Access::connection($c,'instagram',$account);$v=self::settings($c,$account);$proof=$c['token_identity']??[];
        $verified=($proof['validated_generation']??0)===$c['credential_generation']&&!empty($proof['app_verified'])&&is_array($proof['scopes']??null);
        $missing=$verified?array_values(array_diff(self::SCOPES,$proof['scopes'])):null;
        $out=['revision'=>$v['revision'],'enabled'=>$v['enabled'],'contacts_enabled'=>$v['contacts_enabled'],'page_id'=>$v['page_id'],'authorization_current'=>$v['authorization_revision']===$c['authorization_revision'],'required_scopes'=>self::SCOPES,'scope_status'=>$verified?($missing?'scope_missing':'scopes_observed'):'scope_unverified','missing_scopes'=>$missing,'scope_evidence'=>'Última validação do token da conexão; a leitura de conversas inspeciona o token da Página novamente.','app_review'=>['declared_by_operator'=>$v['app_review'],'verified'=>false,'message'=>'Acesso avançado e aprovação do aplicativo precisam ser conferidos no painel Meta pelo responsável. Escopos concedidos não provam App Review.'],'consumer'=>['id'=>'site-core','contract'=>self::CONTRACT,'available'=>self::$consumer!==null],'webhook_url'=>rest_url(Config::REST.'/messaging-webhook/'.$c['id'].'/'.$account),'verify_token_configured'=>$v['verify_token']!=='','retention_mode'=>'unlimited','retention_days'=>null,'maximum_events_site'=>null];
        return $out;
    }
    public static function save(array $i): array {
        Access::admin();$c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);Access::connection($c,'instagram',$account);$principal=Access::principal();$key=self::key($c,$account);
        return Store::lock('messaging:'.$key,static function()use($i,$c,$account,$principal,$key){
            $old=self::settings($c,$account);if($old['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','Configuração de mensagens alterada.');
            $v=$old;unset($v['revision']);foreach(['enabled','contacts_enabled','page_id','app_review'] as $field)if(array_key_exists($field,$i))$v[$field]=$i[$field];
            if(!empty($i['verify_token'])){if(strlen($i['verify_token'])<16||preg_match('/[\x00-\x20]/',$i['verify_token']))throw new Fault('invalid_input','Token de verificação deve ter de 16 a 128 caracteres, sem espaços.');$v['verify_token']=$i['verify_token'];}
            if($v['contacts_enabled']&&!$v['enabled'])throw new Fault('invalid_input','Ative a recepção antes de autorizar contatos.');
            if($v['contacts_enabled']&&self::$consumer===null)throw new Fault('consumer_unavailable','O Site Core ainda não registrou um consumidor compatível. Contatos permanecem desligados.',['contract'=>self::CONTRACT]);
            if($v['enabled']){if($v['verify_token']===''||$c['client_secret']==='')throw new Fault('webhook_configuration_required','Informe token de verificação e segredo do aplicativo.');self::page($c,$account,$v['page_id']);}
            Connections::revalidate($c);Access::checkPrincipal($principal);$v['principal']=$principal;$v['authorization_revision']=$c['authorization_revision'];
            if($v['enabled']&&(!$old['enabled']||$old['authorization_revision']!==$c['authorization_revision']))$v['activated_at']=time();
            if($v['contacts_enabled']&&(!$old['contacts_enabled']||$old['authorization_revision']!==$c['authorization_revision']))$v['contacts_activated_at']=time();
            $saved=Store::put('messaging_config',$key,$v,$old['revision']);return ['revision'=>$saved['revision'],'enabled'=>$v['enabled'],'contacts_enabled'=>$v['contacts_enabled']];
        });
    }
    private static function page(array $c,string $account,string $page): array {
        Util::numeric($page);Access::asset($c,'facebook',$page);
        $r=Http::inspect($c,$page,['fields'=>'id,access_token,instagram_business_account'])['body'];
        if((string)($r['id']??'')!==$page||(string)($r['instagram_business_account']['id']??'')!==$account)throw new Fault('asset_access_denied','A Página selecionada não está vinculada à conta Instagram selecionada.');
        if(!is_string($r['access_token']??null)||strlen($r['access_token'])>16384||$r['access_token']===''||preg_match('/[\x00-\x20]/',$r['access_token']))throw new Fault('page_token_unavailable','Token da Página indisponível.');
        $p=$c;$p['token']=$r['access_token'];return $p;
    }
    private static function permissions(array $c,array $page,string $id): void {
        $auth=$c;if($c['client_id']!==''&&$c['client_secret']!==''){$auth['token']=$c['client_id'].'|'.$c['client_secret'];$auth['expires_at']=0;}
        $d=Http::inspect($auth,'debug_token',['input_token'=>$page['token']])['body']['data']??null;
        if(!is_array($d)||($d['is_valid']??null)!==true)throw new Fault('scope_unverified','Não foi possível confirmar a validade e os escopos do token da Página.');
        if(isset($d['profile_id'])&&(string)$d['profile_id']!==$id||isset($d['type'])&&$d['type']!=='PAGE'||$c['client_id']!==''&&(string)($d['app_id']??'')!==$c['client_id'])throw new Fault('credential_identity_mismatch','A inspeção do token retornou outra Página ou aplicativo.');
        if(!is_array($d['scopes']??null)||count($d['scopes'])>200||!is_array($d['granular_scopes']??[]))throw new Fault('scope_unverified','Escopos não confirmados.');
        $missing=array_values(array_diff(self::SCOPES,$d['scopes']));
        foreach($d['granular_scopes']??[] as $g){if(!is_array($g)||!in_array($g['scope']??'',self::SCOPES,true)||!array_key_exists('target_ids',$g))continue;if(!is_array($g['target_ids']))throw new Fault('scope_unverified','Alvos de escopo não confirmados.');$targets=array_map('strval',$g['target_ids']);if(!in_array($id,$targets,true)&&!in_array($page['_messaging_account']??'',$targets,true))$missing[]=$g['scope'];}
        if($missing)throw new Fault('scope_missing','Faltam permissões de mensagens para esta Página/conta. Gere um token com os escopos necessários após a aprovação do aplicativo.',['missing_scopes'=>array_values(array_unique($missing)),'required_scopes'=>self::SCOPES,'app_review_verified'=>false]);
    }
    private static function after(array $body): ?string {
        if(empty($body['paging']['next']))return null;$a=$body['paging']['cursors']['after']??null;if(!is_string($a)||$a===''||strlen($a)>4096)throw new Fault('coverage_incomplete','Paginação sem continuação segura.');return $a;
    }
    private static function opaque($id): string {if(!is_string($id)||!preg_match('/^[A-Za-z0-9_:=-]{1,512}$/D',$id))throw new Fault('upstream_invalid','Identificador de conversa inválido.');return $id;}
    public static function conversations(array $i,?array $principal=null): array {
        $c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);$principal=$principal??Access::principal();Access::worker($principal,$c,'instagram',$account);
        $v=self::settings($c,$account);$pageId=$i['page_id']??$v['page_id'];if($pageId==='')throw new Fault('page_selection_required','Selecione uma Página autorizada vinculada ao Instagram.');
        // An already validated missing scope is readable without an unnecessary provider request.
        $identity=$c['token_identity']??[];if(($identity['validated_generation']??0)===$c['credential_generation']&&!empty($identity['app_verified'])&&is_array($identity['scopes']??null)){$missing=array_values(array_diff(self::SCOPES,$identity['scopes']));if($missing)throw new Fault('scope_missing','O token validado não possui os escopos de mensagens.',['missing_scopes'=>$missing,'required_scopes'=>self::SCOPES,'app_review_verified'=>false]);}
        $base=$i;unset($base['cursor']);$binding=hash('sha256',Util::json([$base,$principal,$c['authorization_revision'],$c['credential_generation'],$pageId]));$state=[];
        if(isset($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação de outra consulta ou credencial.');$state=$cur['state'];}
        $page=self::page($c,$account,$pageId);$page['_messaging_account']=$account;self::permissions($c,$page,$pageId);$dates=isset($i['date_from'])?Util::dates($i,3660):null;
        $rows=[];$daily=[];$scanned=0;$limit=$i['limit']??5;$requests=0;
        while(count($rows)<$limit&&Http::remaining(1)&&$requests<10){
            if(!isset($state['items'])){$q=['platform'=>'instagram','fields'=>'id,updated_time','limit'=>5];if(isset($state['after']))$q['after']=$state['after'];$b=Http::inspect($page,$pageId.'/conversations',$q)['body'];$requests++;if(!is_array($b['data']??null)||count($b['data'])>100)throw new Fault('upstream_invalid','Lista de conversas inválida.');$state=['items'=>array_map(static fn($x)=>['id'=>self::opaque($x['id']??null)],$b['data']),'index'=>0,'after'=>self::after($b)];}
            if($state['index']>=count($state['items'])){if($state['after']!==null){$state=['after'=>$state['after']];continue;}$state=[];break;}
            $id=$state['items'][$state['index']]['id'];$q=['fields'=>'id,created_time,from,to,reply_to','limit'=>100];if(isset($state['message_after']))$q['after']=$state['message_after'];
            if(!Http::remaining(1)||$requests>=10)break;$b=Http::inspect($page,rawurlencode($id).'/messages',$q)['body'];$requests++;if(!is_array($b['data']??null)||count($b['data'])>100)throw new Fault('upstream_invalid','Lista de mensagens inválida.');
            foreach($b['data'] as $m){$stamp=is_string($m['created_time']??null)?strtotime($m['created_time']):false;if($stamp===false||!is_string($m['id']??null)||strlen($m['id'])>1024)throw new Fault('upstream_invalid','Metadados de mensagem incompletos.');$from=(string)($m['from']['id']??'');if(!ctype_digit($from))throw new Fault('upstream_invalid','Remetente da mensagem não confirmado.');
                if(!isset($state['first'])||$stamp<$state['first']['timestamp'])$state['first']=['message_id'=>$m['id'],'timestamp'=>$stamp,'sender_id'=>$from,'origin'=>self::origin(['message'=>['reply_to'=>$m['reply_to']??[]]])];
            }
            $after=self::after($b);if($after!==null){$state['message_after']=$after;continue;}
            $scanned++;$first=$state['first']??null;
            if($first&&(!$dates||$first['timestamp']>=$dates['date_from_ts']&&$first['timestamp']<$dates['date_to_ts']+86400)){
                $event=Store::get('message_event',self::eventKey($c,$account,$first['sender_id']));
                if($event&&($event['expires_at']===0||$event['expires_at']>time())&&$event['value']['authorization_revision']===$c['authorization_revision']&&$event['value']['message_id']===$first['message_id'])$first['origin']=$event['value']['origin'];
                $day=gmdate('Y-m-d',$first['timestamp']);$rows[]=['conversation_id'=>$id,'first_available_message_id'=>$first['message_id'],'first_available_message_at'=>gmdate('c',$first['timestamp']),'date'=>$day,'sender_id'=>$first['sender_id'],'inbound'=>$first['sender_id']!==$account,'origin'=>$first['origin'],'coverage'=>'oldest_available_message; lifetime_first_unverified'];$daily[$day]=($daily[$day]??0)+1;
            }
            $state['index']++;unset($state['first'],$state['message_after']);
        }
        Connections::revalidate($c);Access::checkPrincipal($principal);
        return ['rows'=>$rows,'started_per_day_in_page'=>$daily,'conversations_scanned'=>$scanned,'next_cursor'=>$state?Util::cursor(['binding'=>$binding,'state'=>$state,'expires'=>time()+3600]):null,'coverage'=>['first_message'=>'oldest_available_not_guaranteed_lifetime_first','inactive_requests_older_than_days_may_be_absent'=>30,'counts'=>'Somar páginas completas da mesma consulta; não equivale a total histórico da caixa de entrada.','timezone'=>'UTC','origin'=>'Referência verificada quando disponível; ausência é desconhecida, não espontânea.'],'app_review_verified'=>false];
    }
    public static function origin(array $event): array {
        $story=$event['message']['reply_to']['story']['id']??null;if(is_scalar($story)&&ctype_digit((string)$story))return ['type'=>'story_reply','story_id'=>(string)$story,'evidence'=>'message.reply_to.story.id'];
        $r=$event['referral']??$event['message']['referral']??null;if(!is_array($r))return ['type'=>'unknown','evidence'=>'no_supported_reference'];
        $out=['type'=>'referral','evidence'=>'webhook.referral'];foreach(['ref','source','type','ad_id'] as $key)if(is_scalar($r[$key]??null))$out[$key==='type'?'referral_type':$key]=mb_substr(preg_replace('/[\x00-\x1f\x7f]/u','',(string)$r[$key])??'',0,512);
        if(($out['source']??'')==='ADS'&&ctype_digit($out['ad_id']??''))$out['type']='ad';
        if(($out['source']??'')==='SHORTLINK'&&isset($out['ref']))$out['type']='ig_me';
        return $out;
    }
    private static function eventKey(array $c,string $account,string $sender): string {return hash('sha256',$c['id'].'|'.$account.'|'.$sender);}
    private static function authorized(array $c,string $account,array $v): void {
        if(!$v['enabled']||$v['authorization_revision']!==$c['authorization_revision']||!is_array($v['principal']))throw new Fault('not_authorized','Recepção de mensagens desativada ou autorização alterada.');Access::worker($v['principal'],$c,'instagram',$account);Access::asset($c,'facebook',$v['page_id']);Connections::revalidate($c);
    }
    public static function receive(string $connection,string $account,string $raw,string $signature): array {
        if(strlen($raw)>262144||!preg_match('/^sha256=[a-f0-9]{64}$/D',$signature))throw new Fault('invalid_webhook','Notificação inválida.');$c=Connections::get($connection);Util::numeric($account);$v=self::settings($c,$account);self::authorized($c,$account,$v);
        if($c['client_secret']===''||!hash_equals('sha256='.hash_hmac('sha256',$raw,$c['client_secret']),$signature))throw new Fault('invalid_signature','Assinatura inválida.');
        $body=json_decode($raw,true,32,JSON_BIGINT_AS_STRING);unset($raw);if(!is_array($body)||($body['object']??'')!=='instagram'||!is_array($body['entry']??null)||count($body['entry'])>100)throw new Fault('invalid_webhook','Envelope de notificação inválido.');$saved=0;
        foreach($body['entry'] as $entry){if((string)($entry['id']??'')!==$account||!is_array($entry['messaging']??null))continue;foreach($entry['messaging'] as $e){
            if(!is_array($e)||!is_array($e['message']??null)||!empty($e['message']['is_echo'])||!empty($e['message']['is_deleted'])||!empty($e['message']['is_unsupported'])||isset($e['message']['edit'])||(string)($e['recipient']['id']??'')!==$account)continue;
            $sender=(string)($e['sender']['id']??'');$mid=$e['message']['mid']??null;$ms=$e['timestamp']??null;
            if(!ctype_digit($sender)||strlen($sender)>40||$sender===$account||!is_string($mid)||$mid===''||strlen($mid)>1024||!is_numeric($ms))continue;$stamp=(int)floor((float)$ms/1000);if($stamp<$v['activated_at']||$stamp>time()+300)continue;
            $key=self::eventKey($c,$account,$sender);$origin=self::origin($e);
            Store::lock('message-events',static function()use($c,$account,$v,$sender,$mid,$stamp,$key,$origin,&$saved){
                self::authorized($c,$account,$v);$current=self::settings($c,$account);if($current['revision']!==$v['revision'])throw new Fault('revision_conflict','Recepção alterada.');if(MessagePrivacy::blocked($c['id'],$account,$key))return;$old=Store::get('message_event',$key);
                if($old&&($old['expires_at']===0||$old['expires_at']>time())&&$old['value']['authorization_revision']===$c['authorization_revision']&&$old['value']['timestamp']<=$stamp)return;
                if($old&&in_array($old['value']['delivery']??'', ['reserved','persisted','uncertain','evidence_changed','suppressed'],true)){if($stamp<$old['value']['timestamp']){$x=$old['value'];$x['delivery']='evidence_changed';Store::put('message_event',$key,$x,$old['revision'],$old['expires_at']);}return;}

                $event=['event_id'=>$key,'idempotency_key'=>$key,'connection_id'=>$c['id'],'account_id'=>$account,'sender_id'=>$sender,'message_id'=>$mid,'timestamp'=>$stamp,'first_available_message_at'=>gmdate('c',$stamp),'observed_at'=>gmdate('c'),'origin'=>$origin,'authorization_revision'=>$c['authorization_revision'],'delivery'=>'pending','coverage'=>'first_observed_only'];
                Store::put('message_event',$key,$event,$old['revision']??0,0);$saved++;
            });
        }}
        if($saved&&$v['contacts_enabled']&&self::$consumer!==null&&!wp_next_scheduled(Config::KEY.'_messages',[$connection,$account]))wp_schedule_single_event(time()+5,Config::KEY.'_messages',[$connection,$account]);
        return ['accepted'=>true,'stored'=>$saved];
    }
    public static function process(array $i): array {
        $c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);$v=self::settings($c,$account);self::authorized($c,$account,$v);
        if(!$v['contacts_enabled'])throw new Fault('contacts_disabled','Criação de contatos desativada.');if(self::$consumer===null)throw new Fault('consumer_unavailable','Consumidor do Site Core indisponível.');
        $privacyEpoch=MessagePrivacy::epoch($c['id'],$account);$query=['connection_id'=>$c['id'],'account_id'=>$account,'limit'=>5];if(isset($i['cursor']))$query['cursor']=$i['cursor'];$data=self::conversations($query,$v['principal']);$deliveries=[];
        foreach($data['rows'] as $row){if(!$row['inbound'])continue;$key=self::eventKey($c,$account,$row['sender_id']);$deliveries[]=Store::lock('message-events',static function()use($c,$account,$v,$row,$key){
            self::authorized($c,$account,$v);if(self::settings($c,$account)['revision']!==$v['revision'])throw new Fault('revision_conflict','Autorização de contatos alterada.');if(MessagePrivacy::blocked($c['id'],$account,$key))return ['state'=>'suppressed'];$r=Store::get('message_event',$key);if(!$r||($r['expires_at']>0&&$r['expires_at']<=time()))return ['state'=>'no_event'];$e=$r['value'];if($e['authorization_revision']!==$c['authorization_revision']||$e['delivery']!=='pending')return ['state'=>$e['delivery']];
            if($e['message_id']!==$row['first_available_message_id']||$e['timestamp']<($v['contacts_activated_at']??PHP_INT_MAX))return ['state'=>'not_a_new_available_conversation'];
            $e['coverage']='oldest_available_matches_signed_webhook; lifetime_first_unverified';$e['delivery']='reserved';$r=Store::put('message_event',$key,$e,$r['revision'],$r['expires_at']);
            $payload=array_intersect_key($e,array_flip(['event_id','idempotency_key','connection_id','account_id','sender_id','message_id','first_available_message_at','observed_at','origin','coverage']));$payload['contract']=self::CONTRACT;
            try{$receipt=(self::$consumer)($payload);$ok=is_array($receipt)&&($receipt['persisted']??false)===true&&($receipt['idempotency_key']??null)===$key&&is_scalar($receipt['record_id']??null)&&(string)$receipt['record_id']!=='';if(!$ok)throw new \RuntimeException('unconfirmed');$e['delivery']='persisted';$e['record_id']=mb_substr((string)$receipt['record_id'],0,128);}catch(\Throwable $error){$e['delivery']='uncertain';}
            Store::put('message_event',$key,$e,$r['revision'],$r['expires_at']);return ['event_id'=>$key,'state'=>$e['delivery']];
        });}
        return ['deliveries'=>$deliveries,'next_cursor'=>$data['next_cursor'],'coverage'=>$data['coverage'],'privacy_revision'=>$privacyEpoch];
    }
    public static function tick(string $connection,string $account,?string $cursor=null): void {
        Http::budget(20,25);$i=['connection_id'=>$connection,'account_id'=>$account];if($cursor)$i['cursor']=$cursor;
        $r=Result::run(static fn()=>self::process($i));Audit::record('process-messages',$i,$r,'site-core','message_worker');if(!empty($r['data']['next_cursor']))Store::lock('message-events',static function()use($connection,$account,$r){if(MessagePrivacy::epoch($connection,$account)===($r['data']['privacy_revision']??null))wp_schedule_single_event(time()+60,Config::KEY.'_messages',[$connection,$account,$r['data']['next_cursor']]);});
    }
    /** Manual reconciliation by an administrator, after the Core checks its durable receipt/tombstone. Never retries a callback. */
    public static function deliveryReceipt(string $connection,string $account,string $event): array {
        Access::admin();$c=Connections::get($connection);Access::connection($c,'instagram',$account);$r=Store::get('message_event',$event);
        if(!$r||($r['expires_at']>0&&$r['expires_at']<=time())||$r['value']['connection_id']!==$connection||$r['value']['account_id']!==$account||$r['value']['authorization_revision']!==$c['authorization_revision'])throw new Fault('not_found','Recibo não disponível neste contexto.');
        return ['event_id'=>$event,'revision'=>$r['revision'],'state'=>$r['value']['delivery'],'record_id'=>$r['value']['record_id']??null,'expires_at'=>$r['expires_at']];
    }
    public static function reconcileReceipt(string $connection,string $account,string $event,int $expected,array $receipt): array {
        Access::admin();if(self::$consumer===null)throw new Fault('consumer_unavailable','Consumidor indisponível.');$c=Connections::get($connection);Access::connection($c,'instagram',$account);$v=self::settings($c,$account);self::authorized($c,$account,$v);
        return Store::lock('message-events',static function()use($c,$account,$event,$expected,$receipt){$r=Store::get('message_event',$event);if(!$r||$r['revision']!==$expected)throw new Fault('revision_conflict','Recibo alterado ou ausente.');$e=$r['value'];if($e['connection_id']!==$c['id']||$e['account_id']!==$account||$e['authorization_revision']!==$c['authorization_revision'])throw new Fault('not_authorized','Recibo de outro contexto.');if(!in_array($e['delivery'],['reserved','uncertain','evidence_changed'],true)||($receipt['idempotency_key']??null)!==$event)throw new Fault('invalid_input','Recibo não corresponde à operação incerta.');
            if(($receipt['suppressed']??false)===true)$e['delivery']='suppressed';elseif(($receipt['persisted']??false)===true&&is_scalar($receipt['record_id']??null)&&(string)$receipt['record_id']!==''){$e['delivery']='persisted';$e['record_id']=mb_substr((string)$receipt['record_id'],0,128);}else throw new Fault('invalid_input','Informe persistência comprovada ou bloqueio definitivo pelo Core.');Connections::revalidate($c);$saved=Store::put('message_event',$event,$e,$r['revision'],$r['expires_at']);return ['state'=>$e['delivery'],'revision'=>$saved['revision']];});
    }
    public static function routes(): void {
        register_rest_route(Config::REST,'/messaging-webhook/(?P<connection>[A-Za-z0-9][A-Za-z0-9_.-]{0,63})/(?P<account>[0-9]{1,40})',['methods'=>'GET,POST','permission_callback'=>'__return_true','callback'=>static function($r){
            try {if($r->get_method()==='GET'){$c=Connections::get($r['connection']);$v=self::settings($c,$r['account']);self::authorized($c,$r['account'],$v);$p=$r->get_query_params();$token=$p['hub_verify_token']??$p['hub.verify_token']??null;$mode=$p['hub_mode']??$p['hub.mode']??null;$challenge=$p['hub_challenge']??$p['hub.challenge']??null;if($mode!=='subscribe'||!is_string($token)||$v['verify_token']===''||!hash_equals($v['verify_token'],$token)||!is_string($challenge)||!preg_match('/^[0-9]{1,100}$/D',$challenge))throw new Fault('invalid_webhook','Verificação recusada.');$response=new \WP_REST_Response($challenge,200);$response->header('Content-Type','text/plain');}
            else{$value=self::receive($r['connection'],$r['account'],$r->get_body(),$r->get_header('x-hub-signature-256'));$response=new \WP_REST_Response($value,200);}}
            catch(\Throwable $e){$response=new \WP_REST_Response(['accepted'=>false],$e instanceof Fault&&in_array($e->reason,['storage_unavailable','busy','message_capacity'],true)?503:403);}
            $response->header('Cache-Control','private, no-store');return $response;
        }]);
        // REST normally JSON-encodes scalars. Meta requires the exact numeric challenge body.
        add_filter('rest_pre_serve_request',static function($served,$result,$request){if($request->get_method()==='GET'&&str_starts_with($request->get_route(),'/'.Config::REST.'/messaging-webhook/')&&$result->get_status()===200&&is_string($result->get_data())){echo $result->get_data();return true;}return $served;},10,3);
    }
}
