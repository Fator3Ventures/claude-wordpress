<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Local erasure boundary. Public consumers use the wrappers on Messaging. */
final class MessagePrivacy {
    public const CONTRACT='instagram-message-erasure/1.0.0';
    private const KEY_OPTION='f3_meta_message_privacy_key';

    public static function contract(): array {
        $target=['type'=>'object','additionalProperties'=>false,'required'=>['connection_id','account_id'],
            'properties'=>['connection_id'=>['type'=>'string','pattern'=>'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$'],
                'account_id'=>['type'=>'string','pattern'=>'^[0-9]{1,40}$'],
                'sender_id'=>['type'=>'string','pattern'=>'^[0-9]{1,40}$'],
                'event_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{64}$']],
            'oneOf'=>[['required'=>['sender_id']],['required'=>['event_id']]]];
        $write=$target;$write['required']=array_merge($write['required'],['expected_revision','idempotency_key']);
        $write['properties']['expected_revision']=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $write['properties']['idempotency_key']=['type'=>'string','pattern'=>'^[A-Za-z0-9_.:-]{16,128}$'];
        return ['contract'=>self::CONTRACT,'sdk'=>Messaging::class,
            'methods'=>['privacyContract'=>['input'=>null,'effect'=>'none'],
                'privacyStatus'=>['input'=>$target,'effect'=>'read_local'],
                'eraseLocalData'=>['input'=>$write,'effect'=>'erase_local_and_suppress'],
                'erasureReceipt'=>['input'=>$write['properties']['idempotency_key'],'effect'=>'read_local']],
            'authorization'=>'current_manage_options_and_current_transport_grant_when_present',
            'revision'=>'opaque_sha256_from_privacyStatus; not_deliveryReceipt_revision',
            'scope'=>'one_sender_per_connection_and_account; event_id_is_the_scoped_sender_key',
            'remote_calls'=>false,'requires_connection_or_token'=>false,
            'receipt_fields'=>['contract','receipt_id','state','local_identifiers_removed','reimportation_blocked','revision','completed_at','external_copies_erased'],
            'limitations'=>['Does not erase Core, Graph, backups or already returned responses/cursors.',
                'Core must invoke this SDK and retain its own durable tombstone.',
                'Keep the privacy key, salts, suppression and receipt records during restore/cleanup.']];
    }
    private static function authorize(bool $write=false): array {
        $p=Access::principal();$sdk='\\Fator3\\McpFiles\\ConnectionContext';
        if(is_callable([$sdk,'transport_identity'])){
            $identity=$sdk::transport_identity();
            if(is_array($identity)&&preg_match('/^(grant:|app:)/',$identity['connection_id']??'')&&(!$p['channel']||($identity['user_id']??0)!==$p['user_id']))throw new Fault('not_authorized','Concessão de transporte indisponível ou revogada.');
        }
        Access::checkPrincipal($p);
        if($write&&$p['channel']&&!in_array($p['channel']['profile']??'',['maintenance','custom'],true))throw new Fault('not_authorized','O perfil de transporte não permite eliminação local.');
        return $p;
    }
    private static function target(array $i,bool $write=false): array {
        Util::guardKeys($i,$write?['connection_id','account_id','sender_id','event_id','expected_revision','idempotency_key']:['connection_id','account_id','sender_id','event_id']);
        if(!is_string($i['connection_id']??null))throw new Fault('invalid_input','Informe a conexão do registro local.');
        $c=Util::id($i['connection_id']);$a=Util::numeric($i['account_id']??null);
        if(array_key_exists('sender_id',$i)===array_key_exists('event_id',$i))throw new Fault('invalid_input','Informe exatamente um sender_id ou event_id.');
        if(array_key_exists('sender_id',$i)){$s=Util::numeric($i['sender_id']);if($s===$a)throw new Fault('invalid_input','Informe o remetente externo.');$event=hash('sha256',$c.'|'.$a.'|'.$s);}
        else {$event=$i['event_id'];if(!is_string($event)||!preg_match('/^[a-f0-9]{64}$/D',$event))throw new Fault('invalid_input','event_id inválido.');}
        return [$c,$a,$event];
    }
    private static function request(string $id): void {
        if(!preg_match('/^[A-Za-z0-9_.:-]{16,128}$/D',$id))throw new Fault('invalid_input','Use chave de idempotência de 16–128 caracteres, sem dados pessoais.');
    }
    /** The random HMAC key is encrypted, independent of provider credentials. Lost salts fail closed. */
    private static function material(bool $create=false): ?string {
        $raw=get_option(self::KEY_OPTION,false);
        if($raw===false){
            global $wpdb;$retained=$wpdb->get_var($wpdb->prepare('SELECT 1 FROM %i WHERE bucket IN (%s,%s,%s) LIMIT 1',Store::table(),'message_suppression','message_erasure_receipt','message_privacy_scope'));
            if($wpdb->last_error)throw new Fault('storage_unavailable','Não foi possível verificar os bloqueios de privacidade.');
            if($retained!==null)throw new Fault('privacy_key_unavailable','Chave de privacidade ausente para bloqueios existentes. Restaure a chave; não reinicie a identidade.');
        }
        if($raw===false&&$create){$sealed=Crypto::seal(base64_encode(random_bytes(32)),'message-privacy-key');add_option(self::KEY_OPTION,$sealed,'',true);$raw=get_option(self::KEY_OPTION,false);}
        if($raw===false){if($create)throw new Fault('persistence_unconfirmed','Chave de privacidade não confirmada.');return null;}
        try {$key=is_string($raw)?base64_decode(Crypto::open($raw,'message-privacy-key'),true):false;}
        catch(\Throwable $e){throw new Fault('privacy_key_unavailable','Restaure a chave de privacidade e os salts antes de receber mensagens ou administrar exclusões.');}
        if(!is_string($key)||strlen($key)!==32)throw new Fault('privacy_key_unavailable','Chave de privacidade inválida. Recepção interrompida.');
        return $key;
    }
    private static function digest(string $key,string $purpose,array $parts): string {
        return hash_hmac('sha256',Util::json([Config::SLUG,get_current_blog_id(),$purpose,$parts]),$key);
    }
    private static function row(array $target): ?array {
        [$c,$a,$event]=$target;$r=Store::get('message_event',$event);
        if($r&&(($r['value']['connection_id']??null)!==$c||($r['value']['account_id']??null)!==$a))throw new Fault('not_authorized','Registro de outro contexto local.');
        return $r;
    }
    private static function snapshot(array $target,?array $row,?array $block): array {
        return ['contract'=>self::CONTRACT,'revision'=>hash_hmac('sha256',Util::json([$target,$row,$block]),wp_salt('auth')),
            'state'=>$block?($row?'erasure_incomplete':(($block['value']['state']??'')==='erased'?'erased':'erasure_incomplete')):($row?'retained':'absent'),
            'local_identifiers_present'=>$row!==null,'reimportation_blocked'=>$block!==null];
    }
    public static function status(array $i): array {
        $p=self::authorize();$t=self::target($i);$key=self::material();
        return Store::lock('message-events',static function()use($p,$t,$key){Access::checkPrincipal($p);$row=self::row($t);$block=$key===null?null:Store::get('message_suppression',self::digest($key,'subject',$t));return self::snapshot($t,$row,$block);});
    }
    public static function blocked(string $connection,string $account,string $event): bool {
        $key=self::material();return $key!==null&&Store::get('message_suppression',self::digest($key,'subject',[$connection,$account,$event]))!==null;
    }
    public static function epoch(string $connection,string $account): int {
        $key=self::material();if($key===null)return 0;$r=Store::get('message_privacy_scope',self::digest($key,'scope',[$connection,$account]));return $r['revision']??0;
    }
    private static function clearContinuations(string $connection,string $account): void {
        foreach(_get_cron_array()?:[] as $when=>$hooks)foreach($hooks[Config::KEY.'_messages']??[] as $event){
            $args=$event['args']??[];
            if(($args[0]??null)===$connection&&($args[1]??null)===$account&&isset($args[2])){
                $ok=wp_unschedule_event((int)$when,Config::KEY.'_messages',$args,true);
                if(is_wp_error($ok)||$ok===false)throw new Fault('erasure_incomplete','Não foi possível remover a continuação local. Repita a mesma requisição após corrigir o cron.');
            }
        }
        foreach(_get_cron_array()?:[] as $hooks)foreach($hooks[Config::KEY.'_messages']??[] as $event){$args=$event['args']??[];
            if(($args[0]??null)===$connection&&($args[1]??null)===$account&&isset($args[2]))throw new Fault('erasure_incomplete','Continuação local ainda presente.');}
    }
    /** A savepoint exists only in a transaction. RELEASE never commits or rolls back user work. */
    private static function requireAutocommit(): void {
        global $wpdb;$name='f3_privacy_'.bin2hex(random_bytes(12));$previous=$wpdb->suppress_errors(true);
        try {
            if($wpdb->query('SAVEPOINT '.$name)===false)throw new Fault('storage_unavailable','Não foi possível verificar a fronteira de persistência.');
            $released=$wpdb->query('RELEASE SAVEPOINT '.$name);
            if($released!==false)throw new Fault('transaction_active','Confirme a transação do consumidor antes de chamar a eliminação local.');
            $errno=$wpdb->dbh instanceof \mysqli?mysqli_errno($wpdb->dbh):0;
            if($errno!==1305)throw new Fault('storage_unavailable','Fronteira de persistência não confirmada.');
        }finally{$wpdb->suppress_errors($previous);}
    }
    public static function erase(array $i): array {
        $p=self::authorize(true);$t=self::target($i,true);
        if(!is_string($i['expected_revision']??null)||!preg_match('/^[a-f0-9]{64}$/D',$i['expected_revision'])||!is_string($i['idempotency_key']??null))throw new Fault('invalid_input','Informe revisão atual e chave de idempotência.');
        self::request($i['idempotency_key']);
        return Store::lock('message-events',static function()use($i,$p,$t){
            Access::checkPrincipal($p);
            self::requireAutocommit();
            $row=self::row($t);$key=self::material();$block=null;$prior=null;
            if($key!==null){$subject=self::digest($key,'subject',$t);$request=self::digest($key,'request',[$i['idempotency_key']]);$block=Store::get('message_suppression',$subject);$prior=Store::get('message_erasure_receipt',$request);}
            if($prior){
                if(!hash_equals($prior['value']['subject'],$subject))throw new Fault('idempotency_conflict','Chave de idempotência já usada em outro alvo.');
                if($row||!$block||($block['value']['state']??'')!=='erased')throw new Fault('erasure_state_changed','Estado local diverge do recibo. Releia o estado e use nova requisição revisada.');
                return $prior['value']['receipt'];
            }
            $resume=$block&&($block['value']['request']??null)===$request&&($block['value']['base_revision']??null)===$i['expected_revision'];
            if(!$resume&&!hash_equals(self::snapshot($t,$row,$block)['revision'],$i['expected_revision']))throw new Fault('revision_conflict','Estado local alterado. Releia privacyStatus.');
            $key=$key??self::material(true);$subject=self::digest($key,'subject',$t);$request=self::digest($key,'request',[$i['idempotency_key']]);
            // Write-ahead suppression survives partial failure. No transaction can commit the caller's transaction.
            $state=['contract'=>self::CONTRACT,'state'=>'erasing','request'=>$request,'base_revision'=>$i['expected_revision']];
            $block=Store::put('message_suppression',$subject,$state,$block['revision']??0,0);
            $scope=self::digest($key,'scope',array_slice($t,0,2));$epoch=Store::get('message_privacy_scope',$scope);
            Store::put('message_privacy_scope',$scope,['contract'=>self::CONTRACT],$epoch['revision']??0,0);
            self::clearContinuations($t[0],$t[1]);Access::checkPrincipal($p);
            if($row)Store::remove('message_event',$t[2],$row['revision']);
            if(self::row($t)!==null)throw new Fault('erasure_incomplete','Registro local ainda presente.');
            $state['state']='erased';$block=Store::put('message_suppression',$subject,$state,$block['revision'],0);
            $receipt=['contract'=>self::CONTRACT,'receipt_id'=>$request,'state'=>'erased','local_identifiers_removed'=>true,
                'reimportation_blocked'=>true,'revision'=>self::snapshot($t,null,$block)['revision'],'completed_at'=>time(),'external_copies_erased'=>false];
            $saved=Store::put('message_erasure_receipt',$request,['subject'=>$subject,'receipt'=>$receipt],0,0);
            return $saved['value']['receipt'];
        });
    }
    public static function receipt(string $id): array {
        self::authorize();self::request($id);$key=self::material();$r=$key===null?null:Store::get('message_erasure_receipt',self::digest($key,'request',[$id]));
        if(!$r)throw new Fault('not_found','Recibo de exclusão ainda não confirmado.');return $r['value']['receipt'];
    }
}
