<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Private bounded archive. Thumbnails never enter uploads, attachments or public URLs. */
final class StoryArchive {
    public const DAYS=0;
    public const MAX_RECORDS=0;
    public const MAX_STORAGE_BYTES=0;
    public const MAX_THUMBNAIL_BYTES=32768;
    private static function prefix(array $c,string $account): string {return hash('sha256',$c['id'].'|'.$account).':';}
    private static function key(array $c,string $account,string $story): string {return self::prefix($c,$account).Util::numeric($story);}
    public static function policy(): array {return ['retention_mode'=>'unlimited','retention_days'=>null,'maximum_records_site'=>null,'maximum_encrypted_storage_bytes_site'=>null,'maximum_thumbnail_bytes'=>self::MAX_THUMBNAIL_BYTES,'thumbnail_dimensions'=>256,'media_download_limit_bytes'=>1048576,'private_encrypted'=>true,'full_media_stored'=>false,'oldest_evicted_when_full'=>false];}
    public static function capture(array $c,string $account,array $media,array $principal): array {
        try {
            Access::worker($principal,$c,'instagram',$account);Connections::revalidate($c);
            $id=Util::numeric((string)($media['id']??''));$key=self::key($c,$account,$id);$old=Store::get('story_archive',$key);
            if($old&&($old['expires_at']===0||$old['expires_at']>time())&&($old['value']['thumbnail']!==null||($old['value']['thumbnail_attempted_at']??0)>time()-300||$old['value']['authorization_revision']!==$c['authorization_revision']))return ['story_id'=>$id,'state'=>'already_archived','expires_at'=>$old['expires_at']];
            $stamp=strtotime((string)($media['timestamp']??''));
            if($stamp===false||$stamp>time()+300)return ['story_id'=>$id,'state'=>'publication_time_unavailable_or_outside_retention'];
            $permalink=self::publicLink($media['permalink']??null);
            $v=['connection_id'=>$c['id'],'account_id'=>$account,'story_id'=>$id,'authorization_revision'=>$c['authorization_revision'],'published_at'=>gmdate('c',$stamp),'published_ts'=>$stamp,'captured_at'=>gmdate('c'),'media_type'=>in_array($media['media_type']??'', ['IMAGE','VIDEO'],true)?$media['media_type']:null,'permalink'=>$permalink,'caption'=>isset($media['caption'])?mb_substr(sanitize_textarea_field((string)$media['caption']),0,2200):null,'thumbnail'=>null,'thumbnail_status'=>'not_provided','thumbnail_attempted_at'=>time()];
            $url=$media['thumbnail_url']??(($media['media_type']??'')==='IMAGE'?($media['media_url']??null):null);
            if(is_string($url)&&$url!==''){
                try{$v['thumbnail']=self::thumbnail($c,$url);$v['thumbnail_status']='available';}
                catch(Fault $e){$v['thumbnail_status']=$e->reason;}
            }
            return Store::lock('story-archive',static function()use($c,$account,$id,$key,$v,$principal,$stamp){
                Access::worker($principal,$c,'instagram',$account);Connections::revalidate($c);$old=Store::get('story_archive',$key);
                if($old&&($old['expires_at']===0||$old['expires_at']>time())&&($old['value']['thumbnail']!==null||($old['value']['thumbnail_attempted_at']??0)>time()-300||$old['value']['authorization_revision']!==$c['authorization_revision']))return ['story_id'=>$id,'state'=>'already_archived','expires_at'=>$old['expires_at']];
                if($old)$v=array_replace($old['value'],['thumbnail'=>$v['thumbnail'],'thumbnail_status'=>$v['thumbnail_status'],'thumbnail_attempted_at'=>$v['thumbnail_attempted_at']]);
                
                $saved=Store::put('story_archive',$key,$v,$old['revision']??0,0);
                return ['story_id'=>$id,'state'=>'archived','thumbnail_status'=>$v['thumbnail_status'],'expires_at'=>$saved['expires_at']];
            });
        }catch(Fault $e){return ['story_id'=>isset($media['id'])&&is_scalar($media['id'])?(string)$media['id']:null,'state'=>'archive_failed','code'=>$e->reason];}
    }
    private static function publicLink($value): ?string {
        if(!is_string($value)||strlen($value)>2048)return null;$p=wp_parse_url($value);
        if(!$p||($p['scheme']??'')!=='https'||!in_array(strtolower($p['host']??''),['instagram.com','www.instagram.com'],true)||isset($p['user'])||isset($p['pass'])||isset($p['port']))return null;
        return 'https://'.strtolower($p['host']).($p['path']??'/');
    }
    private static function thumbnail(array $c,string $url): array {
        $body=Http::thumbnail($c,$url);$info=@getimagesizefromstring($body);
        if(!$info||!in_array($info['mime']??'', ['image/jpeg','image/png','image/webp'],true)||$info[0]<1||$info[1]<1||$info[0]>4096||$info[1]>4096||$info[0]*$info[1]>12000000)throw new Fault('thumbnail_invalid','Miniatura fora dos tipos ou dimensões permitidos.');
        if(!function_exists('wp_tempnam'))require_once ABSPATH.'wp-admin/includes/file.php';
        $tmp=wp_tempnam('f3-meta-story-image');if(!$tmp)throw new Fault('thumbnail_storage_unavailable','Arquivo temporário indisponível.');@chmod($tmp,0600);$dest=$tmp.'.jpg';
        try {
            if(file_put_contents($tmp,$body)!==strlen($body))throw new Fault('thumbnail_storage_unavailable','Falha no arquivo temporário.');unset($body);
            $editor=wp_get_image_editor($tmp);if(is_wp_error($editor))throw new Fault('thumbnail_editor_unavailable','Editor de imagem indisponível.');
            if($info[0]>256||$info[1]>256){$resized=$editor->resize(256,256,false);if(is_wp_error($resized))throw new Fault('thumbnail_resize_failed','Não foi possível reduzir a imagem.');}$editor->set_quality(60);
            $saved=$editor->save($dest,'image/jpeg');if(is_wp_error($saved)||($saved['path']??'')!==$dest||!is_file($dest))throw new Fault('thumbnail_resize_failed','Imagem reduzida não confirmada.');
            @chmod($dest,0600);$bytes=file_get_contents($dest);if($bytes===false||strlen($bytes)>self::MAX_THUMBNAIL_BYTES)throw new Fault('thumbnail_too_large','Miniatura reduzida excedeu 32 KiB.');
            return ['mime_type'=>'image/jpeg','bytes'=>strlen($bytes),'width'=>$saved['width'],'height'=>$saved['height'],'sha256'=>hash('sha256',$bytes),'content_base64'=>base64_encode($bytes)];
        }finally{if(is_file($tmp))unlink($tmp);if(is_file($dest))unlink($dest);}
    }
    public static function read(array $i,bool $thumbnail=false): array {
        Access::admin();$c=Connections::get($i['connection_id']);$account=Util::numeric($i['account_id']);Access::connection($c,'instagram',$account);$principal=Access::principal();
        if($thumbnail){
            $r=Store::get('story_archive',self::key($c,$account,$i['story_id']));
            if(!$r||($r['expires_at']>0&&$r['expires_at']<=time())||$r['value']['authorization_revision']!==$c['authorization_revision'])throw new Fault('archive_unavailable','Story ausente, expirado ou de autorização anterior.');
            Connections::revalidate($c);Access::checkPrincipal($principal);return ['story_id'=>$i['story_id'],'status'=>$r['value']['thumbnail_status'],'thumbnail'=>$r['value']['thumbnail'],'expires_at'=>$r['expires_at']];
        }
        $base=$i;unset($base['cursor']);$binding=hash('sha256',Util::json([$base,$principal,$c['authorization_revision']]));$after='';
        if(isset($i['cursor'])){$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação de outro arquivo ou autorização.');$after=$cur['after'];}
        $dates=isset($i['date_from'])?Util::dates($i,3660):null;$limit=$i['limit']??25;$prefix=self::prefix($c,$account);global $wpdb;
        $keys=$wpdb->get_col($wpdb->prepare('SELECT record_key FROM %i WHERE bucket=%s AND record_key LIKE %s AND record_key>%s AND (expires_at=0 OR expires_at>%d) ORDER BY record_key LIMIT %d',Store::table(),'story_archive',$wpdb->esc_like($prefix).'%',$after,time(),$limit+1));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha na leitura do arquivo.');$more=count($keys)>$limit;$keys=array_slice($keys,0,$limit);$rows=[];
        foreach($keys as $key){$r=Store::get('story_archive',$key);if(!$r)continue;$v=$r['value'];if($v['authorization_revision']!==$c['authorization_revision'])continue;if($dates&&($v['published_ts']<$dates['date_from_ts']||$v['published_ts']>=$dates['date_to_ts']+86400))continue;$v['thumbnail_available']=$v['thumbnail']!==null;unset($v['thumbnail'],$v['authorization_revision'],$v['published_ts']);$rows[]=$v+['expires_at'=>$r['expires_at']];}
        Connections::revalidate($c);Access::checkPrincipal($principal);
        return ['rows'=>$rows,'policy'=>self::policy(),'next_cursor'=>$more?Util::cursor(['binding'=>$binding,'after'=>end($keys),'expires'=>time()+3600]):null,'coverage'=>'Stories observados por coletas, preservados sem expiração automática nem descarte por quantidade. Não reconstrói mídia anterior à instalação.'];
    }
}
