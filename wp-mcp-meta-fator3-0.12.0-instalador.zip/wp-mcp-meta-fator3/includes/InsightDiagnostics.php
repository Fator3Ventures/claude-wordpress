<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Provider rules are matched narrowly; raw Graph messages are never retained. */
final class InsightDiagnostics {
    public static function providerRule(array $error): ?string {
        if(($error['code']??null)!==10)return null;
        $message=trim((string)($error['message']??''));
        if(preg_match('/^(?:\(#10\)\s*)?Not enough viewers for the media to show insights\.?$/iD',$message))return 'story_viewers_below_five';
        return null;
    }
    public static function describe(string $metric,string $availability,array $details=[]): array {
        $rule=$details['provider_rule']??null;
        if($rule==='story_viewers_below_five')return ['classification'=>'provider_suppression','rule'=>$rule,'rule_confirmed'=>true,'message'=>'A Meta suprimiu esta métrica de Story por ter menos de 5 visualizações elegíveis. O valor não é zero e essa resposta não comprova perda de autorização.','action'=>'Aguardar novas visualizações e coletar enquanto o Story estiver disponível.'];
        if($availability==='story_expired')return ['classification'=>'provider_data_unavailable','rule_confirmed'=>false,'message'=>'A Meta recusou a métrica de um Story publicado há pelo menos 24 horas. O arquivo local não recupera métricas que a API já não fornece.','action'=>'Consultar os snapshots coletados antes da expiração.'];
        if(in_array($availability,['empty_or_suppressed','value_unavailable','story_insights_unavailable'],true)){
            $message='A Meta não devolveu valor para esta métrica. Ausência, supressão e indisponibilidade não equivalem a zero; a causa específica não foi confirmada.';
            if(in_array($metric,['follower_count','online_followers','follower_demographics','engaged_audience_demographics','reached_audience_demographics'],true))$message.=' Algumas métricas de público exigem pelo menos 100 seguidores ou amostra elegível; o total efetivo da conta não foi medido por esta resposta.';
            if($metric==='follows_and_unfollows')$message.=' Não é correto atribuir automaticamente esta ausência ao limite de 100 seguidores. Confira período, follow_type e disponibilidade do fornecedor.';
            return ['classification'=>'provider_data_unavailable','rule_confirmed'=>false,'message'=>$message,'action'=>'Preservar null e a cobertura parcial; não tratar como falha de autenticação sem outra evidência.'];
        }
        if($availability==='unsupported_for_asset_or_version')return ['classification'=>'metric_not_available','rule_confirmed'=>false,'message'=>'A Meta recusou a métrica para este ativo ou versão. Use o post ou álbum principal; filhos de carrossel não têm insights próprios.','action'=>'Conferir tipo de mídia e catálogo; preservar as outras métricas disponíveis.'];
        return ['classification'=>'provider_error','rule_confirmed'=>false,'message'=>'O fornecedor recusou a leitura; código e HTTP medidos estão preservados. Erro 10 genérico não identifica sozinho uma regra de audiência.','action'=>'Consultar diagnóstico da conexão e permissões antes de concluir a causa.'];
    }
    public static function breakdown(string $report,string $metric,array $input=[]): ?string {
        if(in_array($report,['media_insights','stories_insights'],true))return match($metric){'profile_activity'=>'action_type','navigation'=>'story_navigation_action_type',default=>null};
        if($report==='account_insights')return $metric==='follows_and_unfollows'?'follow_type':(in_array($metric,['reach','views'],true)&&($input['breakdown']??'')==='media_product_type'?'media_product_type':null);
        return null;
    }
}
