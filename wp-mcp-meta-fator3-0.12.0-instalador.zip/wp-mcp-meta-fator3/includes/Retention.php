<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
/** Explicit 0.11.0 policy requested by the owner: preserve historical data, not transient capabilities. */
final class Retention {
    public static function upgrade(): array {
        if((int)Util::boot(Config::KEY.'_retention0110',0)===1)return ['complete'=>true];
        return Store::lock('retention-0110',static function(){
            if((int)get_option(Config::KEY.'_retention0110',0)===1)return ['complete'=>true];$changed=0;
            foreach(Store::list('connection',0,100) as $row)Store::lock('connection:'.$row['key'],static function()use($row,&$changed){
                $r=Store::get('connection',$row['key']);if(!$r)return;$c=Connections::defaults($r['value']);
                if($c['retention_mode']!=='unlimited'){$c['retention_mode']='unlimited';Store::put('connection',$row['key'],$c,$r['revision'],$r['expires_at']);$changed++;}
                History::policyChanged($c);
            });
            global $wpdb;
            foreach(['job','result','audit','export','history_export','history_export_part','story_archive','message_event'] as $bucket){$ok=$wpdb->query($wpdb->prepare('UPDATE %i SET expires_at=0 WHERE bucket=%s AND expires_at<>0',Store::table(),$bucket));if($ok===false)throw new Fault('storage_unavailable','Não foi possível preservar os prazos dos dados históricos.');}
            // Includes retained orphan history: preservation grants no access to an unavailable connection.
            if($wpdb->query($wpdb->prepare('UPDATE %i SET expires_at=0 WHERE expires_at<>0',History::table()))===false)throw new Fault('storage_unavailable','Retenção histórica não confirmada.');
            update_option(Config::KEY.'_retention0110',1,true);if((int)get_option(Config::KEY.'_retention0110',0)!==1)throw new Fault('persistence_unconfirmed','Política de retenção não confirmada.');
            return ['complete'=>true,'connections_changed'=>$changed,'historical_retention'=>'unlimited'];
        });
    }
}
