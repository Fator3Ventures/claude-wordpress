<?php
/**
 * Plugin Name: Fator3 MCP LinkedIn
 * Plugin URI: https://github.com/Fator3Ventures/claude-wordpress
 * Description: LinkedIn: relatórios de Pages e Ads e SDK local de Lead Sync.
 * Version: 0.2.0
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Author: Fator3
 * Author URI: https://www.fator3.com.br
 * License: GPL-2.0-or-later
 * Text Domain: wp-mcp-linkedin-fator3
 * Update URI: https://fator3.com.br/plugins/wp-mcp-linkedin-fator3
 */
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
if(class_exists(__NAMESPACE__.'\\Config',false))return;
require_once __DIR__.'/includes/Config.php';
require_once __DIR__.'/includes/Support.php';
require_once __DIR__.'/includes/Connections.php';
require_once __DIR__.'/includes/Http.php';
require_once __DIR__.'/includes/Adapter.php';
require_once __DIR__.'/includes/Schemas.php';
require_once __DIR__.'/includes/Query.php';
require_once __DIR__.'/includes/Export.php';
require_once __DIR__.'/includes/Documentation.php';
require_once __DIR__.'/includes/LeadReader.php';
require_once __DIR__.'/includes/Api.php';
require_once __DIR__.'/includes/Admin.php';
register_activation_hook(__FILE__,static function($network=false){if($network)wp_die('Ative a integração individualmente em cada site.');if(PHP_INT_SIZE<8)wp_die('PHP de 64 bits necessário.');if(!Crypto::available())wp_die('Criptografia autenticada necessária.');Store::install();if(!wp_next_scheduled(Config::KEY.'_maintenance'))wp_schedule_event(time()+3600,'hourly',Config::KEY.'_maintenance');if(Schedules::active())Jobs::scheduleTick();});
register_deactivation_hook(__FILE__,static function(){wp_clear_scheduled_hook(Config::KEY.'_worker');wp_clear_scheduled_hook(Config::KEY.'_maintenance');});
add_action('plugins_loaded',static function(){if((int)get_option(Config::KEY.'_schema',0)!==1){try{Store::install();}catch(\Throwable $e){add_action('admin_notices',static function(){if(current_user_can('manage_options'))echo '<div class="notice notice-error"><p>Fator3 MCP LinkedIn: armazenamento indisponível. Reative o plugin após verificar o banco.</p></div>';});}}},10);

add_action('f3_mcp_register_providers',static function($version=1){if($version===1&&class_exists('\\Fator3\\McpFiles\\ExtensionContract'))\Fator3\McpFiles\ExtensionContract::register(Config::SLUG,Config::VERSION,[Config::PREFIX.'/']);});
add_action('wp_abilities_api_categories_init',static function(){if(function_exists('wp_register_ability_category'))wp_register_ability_category(Config::PREFIX,['label'=>Config::NAME,'description'=>'Integração social independente Fator3.']);});
add_action('wp_abilities_api_init',[Api::class,'abilities'],20);
add_action('rest_api_init',[Api::class,'routes']);
add_action('admin_menu',[Admin::class,'menu']);
add_action('admin_enqueue_scripts',[Admin::class,'assets']);
add_action(Config::KEY.'_maintenance',static function(){Result::run(static fn()=>['removed'=>Store::prune()]);});
add_action(Config::KEY.'_worker',static function(){try{Jobs::tick();}catch(\Throwable $e){update_option(Config::KEY.'_last_worker',['at'=>time(),'state'=>'failed'],false);}});
add_action('plugins_loaded',static function(){do_action('f3_linkedin_register_consumers',PublicApi::class);},20);

if(defined('WP_CLI')&&WP_CLI){
 \WP_CLI::add_command('f3-linkedin run',static function(){Jobs::tick();\WP_CLI::line(Util::json(get_option(Config::KEY.'_last_worker',[])));});
 \WP_CLI::add_command('f3-linkedin selftest',static function(){$r=Result::run(static fn()=>SelfTest::run());\WP_CLI::line(Util::json($r));if(!$r['success'])\WP_CLI::halt(1);});
}
