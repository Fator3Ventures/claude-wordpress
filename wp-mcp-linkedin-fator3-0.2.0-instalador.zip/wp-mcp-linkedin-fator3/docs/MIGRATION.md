# Migração e rollback — LinkedIn 0.2.0

Preserva slug, arquivo principal, namespace, REST, prefixo, tabela f3_linkedin_records e grants/credenciais da 0.1.0. Novos buckets guardam índice de intenção e checkpoint de migração; nenhum dado de outro plugin é modificado. A indexação percorre registros antigos em lotes de 50 antes de autorizar novos POSTs. migration_pending pede repetir a operação sem emitir mutação remota.

Assinaturas criando/sem ID da 0.1 continuam bloqueadas após atualização. Não se presume autoria de equivalente remoto, e ausência em GET não resolve POST incerto. Consultas/reconciliações usam contrato público 1.1. Uma mudança de contexto não aceita grant antigo implicitamente. Preserve conexão e grant antigos enquanto a transição estiver pendente.

Backup inclui banco, salts, instalador anterior e estado de ativação. Rollback deve restaurar código e banco do mesmo ponto, após pausar consumidores; a 0.1.0 não conhece o bloqueio global novo e pode reenviar intenções sob nova chave. Não use downgrade como mecanismo para liberar incerteza. Desinstalar a 0.2 conserva dados; uninstall da 0.1 remove dados e não deve ser executado para atualizar/voltar versão.
