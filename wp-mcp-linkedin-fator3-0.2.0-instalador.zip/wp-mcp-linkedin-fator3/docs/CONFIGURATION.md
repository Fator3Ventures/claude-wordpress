# Configuração LinkedIn — 0.2.0

Cadastre token e versão mensal da API (padrão 202609), selecione Pages, contas de Ads e contas de Lead Sync separadamente. IDs são strings. Lead Sync aceita somente SPONSORED e requer formulários explicitamente selecionados por conta. `r_ads`/`rw_ads` não implicam acesso a respostas: Lead Sync precisa do produto e permissão específicos do LinkedIn.

Tokens e client_secret são cifrados. Secret é usado para challenge/notificação; token para consultas e assinaturas. Configure client_id/application_id para rastreabilidade da transição; valores configurados não comprovam remotamente a titularidade do aplicativo. Token vazio mantém o atual. Toda mudança da conexão incrementa a revisão e exige reconfirmar concessões.

Registrar consumidor não autoriza acesso. Administrador concede permissões metadata, responses, verify e/ou subscriptions, formulários selecionados e callback HTTPS do próprio site. Formulários vazios não concedem acesso. Releia get-connection/get-grant; list-grants é paginada e retorna next_offset. O SDK concedido funciona com usuário zero e não exige sessão humana.

A versão não muda o seletor de provedor do Core. Preserve credencial e concessão antigas até concluir drenagem do diário de assinaturas. Não substitua aliases ou remova registros como tentativa de resolver timeout.
