# Fator3 Site Core 1.78.0

O diretório work/plugin/base-site-core-fator3 contém o runtime. history/1.77.0-runtime contém a base oficial para migração direta. A documentação instalada inclui instruções para agentes, contratos e notas da versão. A cópia do relatório na raiz antecede o fechamento do fonte. A proposta experimental para o Implantador está em impactos e fica fora do instalador do Core.

## Reprodução

Execute a partir desta raiz, preservando o nome base-site-core-fator3-1.78.0-fonte.

```bash
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.78.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.78.0-fonte.zip
```

Os arquivos públicos JS/CSS vêm da base 1.77.0 com bytes idênticos. O script histórico build/assets-1770.py e o lockfile em build/node permitem conferir os artefatos JS.

## Testes

Use PHP 8.3 com mysqli/mysqlnd, mbstring, DOM, XML, curl, iconv, fileinfo e tokenizer, Python 3, WordPress 7.1.4 oficial e MySQL descartável com administrador root local. Para reproduzir as duas fases, mantenha o servidor MySQL em 127.0.0.1, informe sua porta em F3BASE_LAB_PORT e use bancos core_1780_fresh e core_1780_upgrade ainda inexistentes.

```bash
F3BASE_PHASE=fresh python3 tests/run-1780.py --wordpress-archive /caminho/wordpress-7.1.4.zip --lab /tmp/core178-fresh --php /caminho/php
F3BASE_PHASE=upgrade python3 tests/run-1780.py --wordpress-archive /caminho/wordpress-7.1.4.zip --lab /tmp/core178-upgrade --php /caminho/php
```

tests/INTEGRACAO-1780.md detalha as provas com Apache e fornecedores locais. Consulte evidence/1780. As evidências de outras versões são históricas.
