"""Compare the UI release to the official input installer, without executing a plugin."""
import re, sys, json, hashlib, zipfile
from pathlib import Path
def inspect(path):
    with zipfile.ZipFile(path) as z:
        records={f.filename.partition('/')[2]:z.read(f) for f in z.infolist() if not f.is_dir()}
    return records
def sha(v):return hashlib.sha256(v).hexdigest()
base,new=map(inspect,map(Path,sys.argv[1:3]))
slug='wp-mcp-linkedin-fator3'
assert re.search(rb'\bVersion: 0\.26\.0\b',base[slug+'.php'])
assert re.search(rb'\bVersion: 0\.27\.0\b',new[slug+'.php'])
expected='15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b'
assert sha(new['assets/f3-ui.css'])==expected
same=sorted(k for k in base.keys()&new.keys() if base[k]==new[k])
changed=sorted(k for k in base.keys()&new.keys() if base[k]!=new[k])
added=sorted(new.keys()-base.keys());removed=sorted(base.keys()-new.keys())
for key in ['docs/input-schemas.json','docs/output-schema.json','docs/lead-campaign-schema.json','uninstall.php','includes/Api.php','includes/History.php','includes/Connections.php','includes/Query.php','includes/Worker.php','includes/Conversions.php','includes/ServiceAudit.php']:
    assert key in same, key
assert base[slug+'.php'].replace(b'Version: 0.26.0',b'Version: 0.27.0')==new[slug+'.php']
assert base['includes/Config.php'].replace(b"VERSION='0.26.0'",b"VERSION='0.27.0'")==new['includes/Config.php']
allowed={slug+'.php','readme.txt','manifest.sha256.json','includes/Config.php','includes/Admin.php','includes/AdminManagement.php','includes/FieldHelp.php','includes/Data/Documentation.php','includes/Data/DocumentationIndex.php'}
assert not [k for k in changed+added+removed if k not in allowed and not k.startswith(('assets/','docs/'))], 'unexpected change, expand only after manual review'
print(json.dumps({'scope':'runtime diff and immutability of domain, schemas and bootstrap','baseline':'0.26.0','target':'0.27.0','baseline_sha256':sha(Path(sys.argv[1]).read_bytes()),'candidate_sha256':sha(Path(sys.argv[2]).read_bytes()),'f3_ui_css_sha256':expected,'same':same,'added':added,'removed':removed,'changed':changed},ensure_ascii=False,indent=2))
