"""Build a review PDF from the 36 real browser images; source images remain unchanged."""
import io, sys, os
from pathlib import Path
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
TABS={'Configurar':{'connections':'Conexões','assets':'Ativos','leads':'Formulários','conversions':'Conversões de aquisição','stages':'Etapas comerciais'},'Dados':{'reports':'Relatórios','jobs':'Coletas','history':'Histórico','management':'Anúncios e publicações'},'Suporte':{'diagnostics':'Diagnóstico','retention':'Retenção','help':'Ajuda'}}
widths=[360,768,1440]
folder,pdf=map(Path,sys.argv[1:3])
fonts=Path(os.getenv('F3_PDF_FONTS','/usr/share/fonts/truetype/dejavu'))
for name,file in [('body','DejaVuSans.ttf'),('heavy','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,str(fonts/file)))
out=canvas.Canvas(str(pdf),pageCompression=1,invariant=1);out.setTitle('Fator3 MCP LinkedIn 0.27.0 | Caderno visual');out.setAuthor('Fator3')
blue='#173e85';ink='#192c42';muted='#526478';light='#dee6ee'
def line(x,y,z,u,stroke=light):
    out.setStrokeColor(HexColor(stroke));out.line(x,y,z,u)
def t(x,y,s,size=11,face='body',color=ink):
    out.setFont(face,size);out.setFillColor(HexColor(color));out.drawString(x,y,s)
def find(tab,width):
    p=folder/f'{width}-{tab}.webp'
    if p.is_file():return p
    import re
    matches=[p for p in folder.rglob('*') if p.suffix in ('.webp','.png') and re.search(fr'(?:^|[-_.]){tab}(?:[-_.]|$)',p.name) and str(width) in p.name]
    assert len(matches)==1,(tab,width,matches)
    return matches[0]
out.setPageSize(A4);W,H=A4;out.bookmarkPage('index');out.addOutlineEntry('Índice', 'index')
t(42,H-54,'FATOR3  /  PAINEL WORDPRESS',10,'heavy',blue)
t(42,H-102,'Fator3 MCP LinkedIn',30,'heavy');t(42,H-136,'Caderno visual da versão 0.27.0',17)
t(42,H-173,'Doze subabas do painel em três larguras. Clique em uma largura para abrir',10)
t(42,H-189,'a captura. Use “Índice” ou os marcadores do PDF para voltar.',10)
y=H-226
for group,tabs in TABS.items():
    t(42,y,group,15,'heavy',blue);y-=25
    for tab,label in tabs.items():
        t(52,y,label,11)
        for j,w in enumerate(widths):
            X=304+j*80;t(X,y,f'{w} px',10,'heavy',blue);out.linkRect('',f'{tab}-{w}',(X,y-5,X+59,y+14),relative=0,thickness=0)
        y-=23
    line(42,y+8,W-44,y+8);y-=18
t(42,64,'Evidência de laboratório · WordPress com dados sintéticos e aviso de outro plugin.',9,'body',muted)
t(42,48,'As capturas originais e a conferência por subaba acompanham o código-fonte.',9,'body',muted)
out.showPage()
i=0
for group,tabs in TABS.items():
    for tab,label in tabs.items():
        for width in widths:
            i+=1;p=find(tab,width);img=Image.open(p).convert('RGB');iw,ih=img.size;assert iw==width,(p,iw,width)
            maxh=960 if width==1440 else 850;view=img.crop((0,0,iw,min(ih,maxh)))
            scale=0.8 if width==1440 else 0.9;pad=26;W=max(405,iw*scale+2*pad);H=view.height*scale+115
            out.setPageSize((W,H));key=f'{tab}-{width}';out.bookmarkPage(key);out.addOutlineEntry(f'{group} / {label}' if width==360 else f'{width} px',key,level=1 if width==360 else 2)
            t(pad,H-23,f'FATOR3   /   LINKEDIN 0.27.0   /   {group.upper()}',9,'heavy',blue)
            t(pad,H-51,label,17,'heavy');t(W-pad-54,H-23,'Índice',10,'heavy',blue);out.linkRect('','index',(W-pad-63,H-31,W-pad,H-8),relative=0,thickness=0)
            line(pad,H-65,W-pad,H-65)
            x=(W-iw*scale)/2;out.drawImage(ImageReader(view),x,38,width=iw*scale,height=view.height*scale,mask='auto')
            t(pad,15,f'{width} px    /    '+ ('Início da página' if ih>maxh else 'Captura da tela'),9,'body',muted);t(W-pad-46,15,f'{i:02} / 36',9,'heavy',blue)
            out.showPage()
out.save()
