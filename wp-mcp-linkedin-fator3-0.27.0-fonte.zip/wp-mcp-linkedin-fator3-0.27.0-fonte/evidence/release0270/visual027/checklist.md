# Conferência visual · Fator3 MCP LinkedIn 0.27.0

WordPress 7.1.4; Chromium 156.0.8078.79; 12 subabas e 3 larguras. As imagens mostram a página completa, com aviso real de outro plugin de laboratório.

| Subaba | 360 px | 768 px | 1440 px | 1. Folha e ordem | 2. Identidade | 3. Aviso alheio | 4. Navegação | 5. Esquema WP | 6. Selos | 7. Campos | 8. Tabelas | 9. Largura | 10. Toque | 11. Foco | 12. CSS local |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Conexões | [Captura](360-connections.webp) | [Captura](768-connections.webp) | [Captura](1440-connections.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Ativos | [Captura](360-assets.webp) | [Captura](768-assets.webp) | [Captura](1440-assets.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Formulários | [Captura](360-leads.webp) | [Captura](768-leads.webp) | [Captura](1440-leads.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Conversões de aquisição | [Captura](360-conversions.webp) | [Captura](768-conversions.webp) | [Captura](1440-conversions.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Etapas comerciais | [Captura](360-stages.webp) | [Captura](768-stages.webp) | [Captura](1440-stages.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Relatórios | [Captura](360-reports.webp) | [Captura](768-reports.webp) | [Captura](1440-reports.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Coletas | [Captura](360-jobs.webp) | [Captura](768-jobs.webp) | [Captura](1440-jobs.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Histórico | [Captura](360-history.webp) | [Captura](768-history.webp) | [Captura](1440-history.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Anúncios e publicações | [Captura](360-management.webp) | [Captura](768-management.webp) | [Captura](1440-management.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Diagnóstico | [Captura](360-diagnostics.webp) | [Captura](768-diagnostics.webp) | [Captura](1440-diagnostics.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Retenção | [Captura](360-retention.webp) | [Captura](768-retention.webp) | [Captura](1440-retention.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |
| Ajuda | [Captura](360-help.webp) | [Captura](768-help.webp) | [Captura](1440-help.webp) | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim | Sim |

O critério 10 se aplica a 360 e 768 px. Critério 6 admite o selo neutro sem classe semântica. Em abas sem tabela, campo ou resumo, a regra se aplica quando o componente existe. Medições, ocorrências, mudança de esquema e testes complementares em results.json.
