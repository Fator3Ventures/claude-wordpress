<?php
require __DIR__.'/fixtures017.php'; require __DIR__.'/upgrade027-snapshot.php';
use Fator3\LinkedIn as L;
$before=json_decode(file_get_contents(getenv('F3_LAB_ROOT').'/before027.json'),true,512,JSON_THROW_ON_ERROR);
$after=snapshot_ui_27();$s=array_column(L\Schedules::list(),null,'schedule_id');$j=L\Jobs::status($before['job_id']);
$report=['version'=>L\Config::VERSION,'checks'=>[
 'target'=>L\Config::VERSION==='0.27.0','encrypted_domain_rows_and_revisions'=>hash_equals($before['records_sha256'],$after['records_sha256']),
 'encrypted_site_history'=>hash_equals($before['history_sha256'],$after['history_sha256'])&&$after['history_rows']===2,
 'running_schedule'=>$s['running27']['enabled']&&$s['running27']['revision']===1,'manual_pause'=>!$s['paused27']['enabled']&&$s['paused27']['revision']===1,
 'queue_checkpoint'=>$j['status']==='paused'&&$j['pages']===3&&L\Store::get('job',$before['job_id'])['value']['cursor']==='preserve-this-checkpoint',
 'uncertain_mutation'=>L\Store::get('mutation',str_repeat('a',64))['value']['state']==='uncertain','retention_policy'=>L\Retention::get()['audit_days']===45
 ],'counts'=>$after['counts'],'history_rows'=>$after['history_rows']];
$report['failed']=array_keys(array_filter($report['checks'],static fn($v)=>!$v));
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/migration027.json',wp_json_encode($report,JSON_PRETTY_PRINT));echo wp_json_encode($report)."\n";exit($report['failed']?1:0);
