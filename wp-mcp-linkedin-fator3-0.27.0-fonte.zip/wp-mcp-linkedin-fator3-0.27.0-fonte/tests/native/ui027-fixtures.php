<?php
/** A visible notice from a separate lab plugin, never installed outside disposable browser tests. */
defined('ABSPATH') || exit;
add_action('admin_notices',static function(){
    $screen=get_current_screen();
    if(!$screen || $screen->id!=='tools_page_wp-mcp-linkedin-fator3')return;
    echo '<div class="notice notice-info" id="qa027-other-plugin"><p><strong>Aviso de outra extensão</strong> · Laboratório visual. <a class="button" href="#qa027-other-plugin">Conferir instruções de verificação desta extensão</a></p></div>';
});
