<?php
require __DIR__.'/fixtures017.php'; require __DIR__.'/upgrade027-snapshot.php';
use Fator3\LinkedIn as L;
assert17(L\Config::VERSION==='0.26.0','seed requires official 0.26.0');
setup17('preserve27','reader27');
$p=L\Access::principal();$q=['connection_id'=>'preserve27','channel'=>'pages','account_id'=>'111','report'=>'organization'];
foreach(['running27'=>true,'paused27'=>false] as $id=>$enabled){L\Schedules::save(['schedule_id'=>$id,'query'=>$q,'enabled'=>$enabled,'interval_minutes'=>1440,'expected_revision'=>0,'next_at'=>time()+7200]);}
$j=L\Jobs::create(['query'=>$q,'idempotency_key'=>'checkpoint27']);$jobId=$j['job_id'];
L\Jobs::control(['job_id'=>$jobId,'action'=>'pause','expected_revision'=>$j['revision']]);
$r=L\Store::get('job',$jobId);$v=$r['value'];$v['cursor']='preserve-this-checkpoint';$v['pages']=3;$v['rows']=18;L\Store::put('job',$jobId,$v,$r['revision']);
L\Store::put('mutation',str_repeat('a',64),['state'=>'uncertain','connection_id'=>'preserve27','operation'=>'create-campaign-group','principal'=>$p],0);
L\Retention::save(['expected_revision'=>0,'audit_mode'=>'finite','audit_days'=>45,'dry_run'=>false]);
$day=gmdate('Y-m-d',time()-DAY_IN_SECONDS*3);$dp=array_combine(['year','month','day'],array_map('intval',explode('-',$day)));
$ads=['connection_id'=>'preserve27','account_id'=>'222','channel'=>'ads','report'=>'ad_analytics'];
$selection=$ads+['date_from'=>$day,'date_to'=>$day,'granularity'=>'DAILY','fields'=>['impressions']];
$data=$ads+['selection'=>$selection,'rows'=>[['dateRange'=>['start'=>$dp,'end'=>$dp],'pivotValues'=>['urn:li:sponsoredAccount:222'],'impressions'=>27]],'currency'=>'BRL','fetched_at'=>gmdate('c'),'api_version'=>'202609','coverage'=>['complete'=>true,'errors'=>[]]];
assert17(L\History::ingest($data,$p,L\Connections::get('preserve27'),'retained27')['stored_metrics']===1);
$before=snapshot_ui_27();assert17($before['history_rows']===2&&!empty($before['counts']['connection'])&&!empty($before['counts']['grant']),'operated fixture');
file_put_contents(getenv('F3_LAB_ROOT').'/before027.json',wp_json_encode($before+['job_id'=>$jobId]));
