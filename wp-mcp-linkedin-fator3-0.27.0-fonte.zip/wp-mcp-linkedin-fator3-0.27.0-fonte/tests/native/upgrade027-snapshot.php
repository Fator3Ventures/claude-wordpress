<?php
/** Snapshot domain state only: stable ciphertext and record revisions; never output credentials or payloads. */
function snapshot_ui_27():array {
 global $wpdb;
 $table=\Fator3\LinkedIn\Store::table();
 $rows=$wpdb->get_results("SELECT bucket,record_key,revision,payload,expires_at,queue_state,queue_next FROM $table WHERE bucket IN ('connection','grant','token_proof','job','schedule','settings','credential','mutation','result','lead_scan') ORDER BY bucket,record_key", ARRAY_A);
 $history=$wpdb->get_results('SELECT * FROM '.\Fator3\LinkedIn\History::table().' ORDER BY row_key',ARRAY_A);
 return ['counts'=>array_count_values(array_column($rows,'bucket')),'records_sha256'=>hash('sha256',serialize($rows)),'history_rows'=>count($history),'history_sha256'=>hash('sha256',serialize($history))];
}
