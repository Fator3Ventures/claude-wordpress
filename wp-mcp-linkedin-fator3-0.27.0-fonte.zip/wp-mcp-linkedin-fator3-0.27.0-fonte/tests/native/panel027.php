<?php
/** Server-rendered navigation must work even when JavaScript never loads. No foreign HTTP or writes. */
require __DIR__.'/fixtures017.php';
use Fator3\LinkedIn as L;
$groups=['Configurar'=>['connections'=>'Conexões','assets'=>'Ativos','leads'=>'Formulários','conversions'=>'Conversões de aquisição','stages'=>'Etapas comerciais'],'Dados'=>['reports'=>'Relatórios','jobs'=>'Coletas','history'=>'Histórico','management'=>'Anúncios e publicações'],'Suporte'=>['diagnostics'=>'Diagnóstico','retention'=>'Retenção','help'=>'Ajuda']];
$checks=[];$rows=[];$http=count($GLOBALS['calls17']);
$has=static fn($c)=>"contains(concat(' ',normalize-space(@class),' '),' ".$c." ')";
$toLabels=static fn($nodes)=>array_map(static fn($n)=>trim($n->textContent),iterator_to_array($nodes));
foreach($groups as $group=>$tabs)foreach($tabs as $tab=>$title){
 $_GET['tab']=$tab;ob_start();L\Admin::screen();$html=ob_get_clean();
 $doc=new DOMDocument();libxml_use_internal_errors(true);$doc->loadHTML('<?xml encoding="UTF-8">'.$html);$x=new DOMXPath($doc);
 $q=static fn($s)=>$x->query($s);
 $panels=$q('//section['.$has('f3-section').' and not(@hidden)]');
 $top='//nav['.$has('f3-nav').']/div['.$has('f3-groups').']';$sub='//nav['.$has('f3-nav').']/div['.$has('f3-subtabs').' and not(@hidden)]';
 $current=$q($sub.'/a[@aria-current="page"]')->item(0);$href=$current?html_entity_decode($current->getAttribute('href')):'';
 $rows[$tab]=[
  'active_panel'=>$panels->length===1&&$panels->item(0)->getAttribute('id')==='f3-'.$tab,
  'groups'=>$toLabels($q($top.'/a'))===array_keys($groups)&&$toLabels($q($top.'/a[@aria-current]'))===[$group],
  'subtabs'=>$toLabels($q($sub.'/a'))===array_values($tabs)&&$current&&trim($current->textContent)===$title,
  'stable_url'=>parse_url($href,PHP_URL_PATH)==='/wp-admin/tools.php'&&str_contains($href,'page='.L\Config::SLUG)&&str_contains($href,'tab='.$tab),
  'heading'=>$q('//div['.$has('wrap').' and '.$has('f3-ui').']/header['.$has('f3-heading').']/h1[normalize-space()="Fator3 MCP LinkedIn"]')->length===1&&$q('//header['.$has('f3-heading').']/span['.$has('f3-version').']')->length===1&&$q('//header['.$has('f3-heading').']/following-sibling::*[1][self::hr and '.$has('wp-header-end').']')->length===1,
  'result_dismiss'=>$q('//*[@id="f3-message" and '.$has('f3-result').' and @hidden]/button[normalize-space()="Dispensar" and @type="button"]')->length===1
 ];
}
unset($_GET['tab']);$checks['default_connections']=L\Admin::currentTab()==='connections';
$_GET['tab']='bogus';$checks['unknown_safe_default']=L\Admin::currentTab()==='connections';unset($_GET['tab']);
try{
 $u=wp_create_user('reader27-no-admin','example-password-not-used','reader27@example.invalid');(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);
 $deny=static fn()=>static function(){throw new RuntimeException('expected_admin_denial');};add_filter('wp_die_handler',$deny);
 try{L\Admin::screen();$checks['subscriber_denied']=false;}catch(RuntimeException $e){$checks['subscriber_denied']=$e->getMessage()==='expected_admin_denial';}
 finally{remove_filter('wp_die_handler',$deny);}
 L\Admin::assets('tools_page_'.L\Config::SLUG);$checks['subscriber_assets_denied']=!wp_style_is(L\Config::KEY,'enqueued');
} finally{wp_set_current_user(1);}
L\Admin::assets('dashboard');$checks['no_assets_on_other_pages']=!wp_style_is(L\Config::KEY,'enqueued');
L\Admin::assets('tools_page_'.L\Config::SLUG);$wpStyles=wp_styles();$entry=$wpStyles->registered[L\Config::KEY]??null;$deps=$entry?->deps??[];
$common=array_filter($deps,static fn($handle)=>str_ends_with((string)($wpStyles->registered[$handle]->src??''),'/assets/f3-ui.css'));$checks['common_css_precedes_scoped_css']=wp_style_is(L\Config::KEY,'enqueued')&&count($common)===1;
$checks['no_provider_http']=count($GLOBALS['calls17'])===$http;
$failed=[];foreach($rows as $tab=>$r)foreach($r as $name=>$ok)if(!$ok)$failed[]=$tab.':'.$name;
foreach($checks as $name=>$ok)if(!$ok)$failed[]=$name;
$result=['tabs'=>count($rows),'per_tab'=>$rows,'checks'=>$checks,'total'=>array_sum(array_map('count',$rows))+count($checks),'failed'=>$failed];
file_put_contents(getenv('F3_LAB_ROOT').'/evidence/panel027.json',wp_json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo wp_json_encode(['total'=>$result['total'],'failed'=>$failed])."\n";exit($failed?1:0);
