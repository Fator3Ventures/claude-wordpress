<?php
declare(strict_types=1);
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';
$owner=json_decode((string)file_get_contents(getenv('F3_LAB_ROOT').'/.social-lab.json'),true);
if(!$owner || !$owner['id'] || !hash_equals($owner['id'],getenv('F3_LAB_ID')))throw new RuntimeException('Owned laboratory required');
$scheme=$argv[1]??'fresh';if(!in_array($scheme,['fresh','modern'],true))throw new RuntimeException('Unknown scheme');
update_user_option(1,'admin_color',$scheme,true);
if(get_user_option('admin_color',1)!==$scheme)throw new RuntimeException('Did not select WP color scheme');
