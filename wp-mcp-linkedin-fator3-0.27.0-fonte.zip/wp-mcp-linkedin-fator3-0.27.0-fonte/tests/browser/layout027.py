"""Twelve tabs in real wp-admin, at three viewports. Credentials and HTTP fixtures are disposable."""
from pathlib import Path
from urllib.parse import urlsplit
from io import BytesIO
import os,re,json,hashlib,subprocess,html
from PIL import Image
from playwright.sync_api import sync_playwright,expect
origin=os.environ['F3_UI_URL'];assert urlsplit(origin).hostname=='127.0.0.1'
root=Path(os.environ['F3_LAB_ROOT']);dest=root/'evidence'/'visual027';dest.mkdir(parents=True,exist_ok=True)
src=Path(__file__).resolve().parents[2];wanted='15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b'
plugin=root/'wordpress/wp-content/plugins/wp-mcp-linkedin-fator3'; sha=lambda b:hashlib.sha256(b).hexdigest()
wpurl=origin+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3';url=wpurl+'&tab='
groups={'Configurar':{'connections':'Conexões','assets':'Ativos','leads':'Formulários','conversions':'Conversões de aquisição','stages':'Etapas comerciais'},'Dados':{'reports':'Relatórios','jobs':'Coletas','history':'Histórico','management':'Anúncios e publicações'},'Suporte':{'diagnostics':'Diagnóstico','retention':'Retenção','help':'Ajuda'}}
tabs={t:(g,title) for g,ts in groups.items() for t,title in ts.items()}
obs=[];extras=[];runtime_errors=[];offsite_assets=set();images=[];additional_images=[]
css=(plugin/'assets/admin.css').read_text()
# Dimensions specific to a table, media queries, screen-reader rules or native hairlines are not components.
bespoke=re.sub(r'/\*.*?\*/','',css,flags=re.S)
own_errors=re.findall(r'(?:#[a-fA-F0-9]{3,8}(?=\s*(?:[;,}\)]|$))|(?:^|[;{])\s*(?:padding(?:-[\w-]+)?|margin(?:-[\w-]+)?|gap|row-gap|column-gap|border-radius)\s*:[^;}]*?(?:\d+px|\d*\.\d+rem))',bespoke)
def record(items,name,ok,detail=None):
 items.append(dict(check=name,passed=bool(ok),detail=detail))
def scheme(s):
 subprocess.run(json.loads(os.environ['F3_LAB_PHP'])+[str(src/'tests/native/ui027-colors.php'),s],check=True)
def screenshot(p,tab,width,name=None):
 fn=f'{width}-{name or tab}.webp';img=Image.open(BytesIO(p.screenshot(full_page=True,animations='disabled',caret='hide')));img.save(dest/fn,format='WEBP',method=3,lossless=True)
 (additional_images if name else images).append({'tab':tab,'width':width,'file':fn,'pixels':list(img.size),'sha256':sha((dest/fn).read_bytes())});return fn
def route(r):
 if urlsplit(r.request.url).netloc!=urlsplit(origin).netloc:
  if r.request.resource_type in ('font','stylesheet','script','image'):offsite_assets.add((r.request.resource_type,urlsplit(r.request.url).hostname))
  return r.abort()
 return r.continue_()
def login(c):
 c.request.get(origin+'/wp-login.php');r=c.request.post(origin+'/wp-login.php',form={'log':'social_admin','pwd':os.environ['F3_UI_PASSWORD'],'testcookie':'1','redirect_to':wpurl},max_redirects=0);assert r.status in (302,303)
def nav(p,tab):
 p.goto(url+tab,wait_until='domcontentloaded');expect(p.locator('#f3-'+tab)).to_be_visible()
 if tab=='connections':expect(p.locator('#f3-connection-list tbody tr')).to_have_count(20)
 p.locator('.f3-nav').wait_for(timeout=3500)
 if tab=='help':expect(p.locator('#f3-help-document option[value=\"PRIMEIROS-PASSOS.md\"]')).to_have_count(1)
 p.evaluate('document.fonts.ready');p.evaluate('window.scrollTo(0,0)')
def measure(p):
 return p.evaluate("""()=>{const root=document.querySelector('.wrap.f3-ui'),h=root?.querySelector(':scope>.f3-heading'),other=document.querySelector('#qa027-other-plugin'),nav=root?.querySelector('nav.f3-nav'),visible=e=>e.getClientRects().length>0&&getComputedStyle(e).visibility!=='hidden',sel=(s)=>[...(root?.querySelectorAll(s)||[])].filter(visible),text=e=>e?.textContent.trim(),names=s=>sel(s).map(text),height=e=>Math.round(e.getBoundingClientRect().height*10)/10,view=root?.querySelector('.f3-section:not([hidden])'),buttons=sel('button,.button,.f3-field input:not([type=checkbox],[type=radio]),.f3-field select,.f3-field textarea'),short=buttons.filter(e=>height(e)<39.9).map(e=>[e.id||e.name||e.tagName,(e.innerText||'').slice(0,34),height(e)]),fields=sel('input,select,textarea').filter(e=> !['hidden','submit','button'].includes(e.type)&&!e.closest('.notice')),unlabel=fields.filter(e=>!e.id||!e.labels?.length||![...e.labels].some(l=>l.htmlFor===e.id)).map(e=>[e.id,e.name,e.type]),badTable=sel('table').filter(e=>!e.closest('.f3-table-scroll')).map(e=>e.id||e.className),ga=nav?.querySelector('.f3-groups [aria-current]'),sa=nav?.querySelector('.f3-subtabs [aria-current]'),accent=getComputedStyle(root||document.body).getPropertyValue('--wp-admin-theme-color').trim(),parseColor=document.createElement('span');parseColor.style.color=accent||'#2271b1';root?.appendChild(parseColor);const ac=getComputedStyle(parseColor).color;parseColor.remove();const hrefLinks=sel('.f3-nav a'),noticeRect=other?.getBoundingClientRect(),hr=h?.nextElementSibling;return{root:!!root,header:h&&[text(h.querySelector(':scope>h1')),text(h.querySelector(':scope>p')),text(h.querySelector(':scope>.f3-version')),!!h.querySelector(':scope>div')],notice:!!other&&!!hr?.matches('hr.wp-header-end')&&!h.contains(other)&&!!(hr.compareDocumentPosition(other)&Node.DOCUMENT_POSITION_FOLLOWING)&&visible(other)&&noticeRect.left>=-1&&noticeRect.right<=innerWidth+1,navName:nav?.getAttribute('aria-label'),groups:names('.f3-groups a'),tabs:names('.f3-subtabs a'),active:[text(ga),text(sa)],navHeights:hrefLinks.map(height),navLinks:hrefLinks.every(a=>a.tagName==='A'&&a.getAttribute('href')&&a.href.startsWith(location.origin+'/')),navs:sel('nav').length,theme:accent,colors:[ga?getComputedStyle(ga).backgroundColor:'',sa?getComputedStyle(sa).borderBottomColor:'',ac],state:sel('.f3-pill').map(e=>[text(e),e.className]),legacy:root?.querySelectorAll('.f3-status-pill,.f3-badge,.f3-tabs,.f3-subnav,.f3-config-panel,.f3-sensitive,.f3-form-footer').length,formTable:root?.querySelectorAll('table.form-table').length,unlabel,tables:sel('table').length,badTable,short,fieldCount:fields.length,buttons:buttons.length,body:document.documentElement.scrollWidth,width:innerWidth,activeId:view?.id,loaded:[...document.styleSheets].map(x=>x.href||'').filter(x=>x.includes('wp-mcp-linkedin-fator3/assets/')).map(x=>new URL(x).pathname.split('/').pop()),renderedCount:sel('.f3-section').length,navTarget:nav?.querySelector('.f3-subtabs [aria-current]')?.href,details:sel('summary').length};}""")
def focus(p):
 # Place the focus *before* a representative of each type; Tab must move focus and produce the computed 2px indicator.
 out={}
 for label,qs in [('nav','.f3-nav a'),('button','button:not(:disabled)'),('field','input:not([type=hidden]):not(:disabled),select:not(:disabled),textarea:not(:disabled)'),('summary','summary')]:
  loc=p.locator('.f3-ui').locator(qs);e=next((x for x in loc.all() if x.is_visible()),None)
  if e is None:out[label]=None;continue
  e=e.element_handle() # retain the actual node while adding a temporary focus starting point
  e.evaluate("""e=>{let a=document.createElement('button');a.id='qa27-tab-probe';a.style.cssText='position:fixed;top:0;left:0;width:1px;height:1px;opacity:0';const anchor=e.tagName==='SUMMARY'&&e.parentElement.tagName==='DETAILS'?e.parentElement:e;anchor.parentNode.insertBefore(a,anchor);a.focus()}""");p.keyboard.press('Tab')
  out[label]=e.evaluate("""e=>{const s=getComputedStyle(e),v={focused:document.activeElement===e,visible:e.matches(':focus-visible'),style:s.outlineStyle,px:s.outlineWidth};document.querySelector('#qa27-tab-probe')?.remove();return v}""")
 return out
def run():
 colors={};periodic_path=dest/'partial.json'
 with sync_playwright() as w:
  b=w.chromium.launch(executable_path=os.environ['F3_CHROME_HEADLESS_SHELL'],chromium_sandbox=os.environ.get('F3_LAB_CHROME_NO_SANDBOX')!='1',args=['--disable-dev-shm-usage'])
  try:
   browser=b.version
   for width in [360,768,1440]:
    ctx=b.new_context(viewport={'width':width,'height':850 if width<782 else 960},locale='pt-BR',device_scale_factor=1,service_workers='block',reduced_motion='reduce')
    ctx.route('**/*',route);login(ctx);p=ctx.new_page();p.set_default_timeout(8500);p.on('pageerror',lambda exc:runtime_errors.append(str(exc)[:260]))
    for tab,(group,title) in tabs.items():
     ob={'tab':tab,'width':width,'checks':[]};ck=ob['checks'];obs.append(ob)
     try:
      nav(p,tab)
      p.wait_for_function("document.querySelector('.f3-ui')?.contains(document.querySelector('#qa027-other-plugin'))",timeout=4000)
      m=measure(p);ob['data']=m
      positioning=p.locator('.f3-ui').evaluate("root=>[...root.querySelectorAll('input,select,textarea')].filter(e=>e.getClientRects().length&&e.type!=='checkbox'&&e.type!=='radio'&&e.type!=='hidden'&&e.labels?.length).filter(e=>{const l=[...e.labels].find(l=>l.htmlFor===e.id&&l.getClientRects().length);return l && l.getBoundingClientRect().bottom>e.getBoundingClientRect().top+1}).map(e=>e.id)");m['mispositionedLabels']=positioning
      record(ck,1,sha((plugin/'assets/f3-ui.css').read_bytes())==wanted and m['loaded'][:2]==['f3-ui.css','admin.css'],m['loaded'])
      record(ck,2,m['root'] and m['header'] and m['header'][0]=='Fator3 MCP LinkedIn' and bool(m['header'][1]) and '0.27.0' in m['header'][2] and not m['header'][3],m['header'])
      record(ck,3,m['notice'],m['notice']);record(ck,4,m['navName'] and m['groups']==list(groups) and m['tabs']==list(groups[group].values()) and m['active']==[group,title] and m['navs']==1 and m['activeId']=='f3-'+tab and m['navLinks'],[m['groups'],m['tabs'],m['active']])
      colors[width,tab]=m['colors']
      record(ck,5,len(set(m['colors']))==1,m['colors'])
      record(ck,6,m['legacy']==0 and all(label and set(cl.split())<=set(['f3-pill','is-ok','is-warn','is-error','is-info']) for label,cl in m['state']),[m['legacy'],m['state'][:3]])
      record(ck,7,not m['formTable'] and not m['unlabel'] and not positioning,[m['unlabel'],positioning]);record(ck,8,not m['badTable'],m['badTable'])
      record(ck,9,m['body']==width==m['width'],[m['body'],width]);record(ck,10,width>=782 or (all(h>=44 for h in m['navHeights']) and not m['short']),m['short'] if width<782 else 'não se aplica no desktop')
      ob['image']=screenshot(p,tab,width);f=focus(p);record(ck,11,all(v is None or (v['focused'] and v['visible'] and v['style']=='solid' and v['px']=='2px') for v in f.values()),f)
      record(ck,12,not own_errors,own_errors)
      if tab=='connections':
       p.locator('#f3-connections-more').click();expect(p.locator('#f3-connection-count.f3-list-total')).to_contain_text('21–40');p.locator('#f3-connection-search').fill('z018-55');expect(p.locator('#f3-connection-list tbody tr')).to_have_count(1);p.locator('#f3-connection-list button').click();expect(p.locator('#f3-connection [name=connection_id]')).to_have_value('z018-55');record(extras,str(width)+' busca, paginação e editar',True)
       form=p.locator('#f3-connection');expect(form).to_be_visible();details=form.locator('details.f3-collapsible.f3-danger');summary=details.locator('summary');expect(summary).to_be_visible();summary.focus();p.keyboard.press('Enter');expect(details).to_have_attribute('open','')
       risk=details.locator('input[type=checkbox]').first;expect(risk).not_to_be_checked();expect(form.locator('.f3-savebar')).to_be_visible()
       record(extras,str(width)+' confirmação de remoção em bloco recolhível; barra de salvar sticky',form.locator('.f3-savebar').evaluate("e=>getComputedStyle(e).position==='sticky'"))
       name=form.locator('input[name=label]');name.fill('Equipe visual sintética');expect(form.locator('#f3-dirty')).to_contain_text('salvas')
       record(extras,str(width)+' rótulos e foco no editor real',name.evaluate("e=>!!e.labels.length&&e.labels[0].htmlFor===e.id"))
       if width in [360,1440]:
        p.evaluate('window.scrollTo(0,0)');screenshot(p,tab,width,'editor')
      if tab=='diagnostics' and width==1440:
       p.locator('#f3-selftest').click();result=p.locator('#f3-message');expect(result).to_be_visible();expect(result).to_have_attribute('role','status');expect(p.locator('#f3-diagnostic-result')).to_contain_text('Autoteste');d=result.get_by_role('button',name='Dispensar');d.focus();p.keyboard.press('Enter');expect(result).not_to_be_visible()
       record(extras,'Autoteste local: resultado no painel, anúncio e Dispensar por teclado',True)
      if tab=='retention' and width==1440:
       form=p.locator('#f3-retention-form');mode=form.locator('[name=audit_mode]');mode.select_option('finite');days=form.locator('[name=audit_days]');days.fill('31')
       form.get_by_role('button',name='Simular alteração').click();save=form.locator('#f3-retention-save');expect(save).to_be_enabled();save.click()
       result=p.locator('#f3-message');expect(result).to_have_attribute('role','status');expect(result).to_contain_text('Política salva');expect(p.locator('#f3-retention-result')).to_contain_text('Política salva');d=result.get_by_role('button',name='Dispensar');d.focus();p.keyboard.press('Enter');expect(result).not_to_be_visible();nav(p,tab);expect(mode).to_have_value('finite');expect(days).to_have_value('31')
       record(extras,'Retenção: simular, confirmar, dispensar por teclado e reler o prazo persistido',True)
      if tab=='help':
       p.locator('#f3-help-read').click();expect(p.locator('#f3-help-content h2').first).to_be_visible();result=p.locator('#f3-message');expect(result).to_have_attribute('role','status');d=result.get_by_role('button',name='Dispensar');expect(d).to_be_visible();d.focus();p.keyboard.press('Enter');expect(result).not_to_be_visible();record(extras,str(width)+' leitura de ajuda e dispensar resultado com teclado',True)
     except Exception as exc:
      ob['exception']=str(exc)[:580];record(ck,'execução',False,ob['exception'])
     periodic_path.write_text(json.dumps(obs,ensure_ascii=False,indent=1))
     print(str(width)+'/'+tab+': '+str([v['check'] for v in ck if not v['passed']]),flush=True)
    if width==1440:
     try:
      nav(p,'help')
      # Force a single local documentation refusal: assert the plugin exposes a dismissible error and restores keyboard focus.
      def deny_help(r):
       from urllib.parse import parse_qs
       u=urlsplit(r.request.url);path=parse_qs(u.query).get('rest_route',[u.path])[0]
       if '/f3-linkedin/v1/documentation' in path:
        r.fulfill(status=403,json={'success':False,'code':'not_authorized','message':'Acesso recusado. Verifique a autorização e tente novamente.'})
       else:r.fallback()
      p.route('**/*',deny_help);p.locator('#f3-help-read').click();msg=p.locator('#f3-message');expect(msg).to_have_attribute('role','alert');expect(msg).to_have_class(re.compile(r'\bis-error\b'));btn=msg.get_by_role('button',name='Dispensar');screenshot(p,'help',width,'erro-e-dispensar');btn.focus();p.keyboard.press('Enter');expect(msg).not_to_be_visible();p.unroute('**/*',deny_help);record(extras,'Erro controlado de leitura: alerta, ação Dispensar e fechamento por teclado',True)
     except Exception as exc:record(extras,'Erro controlado de leitura',False,str(exc)[:400])
     try:
      scheme('modern')
      for tab in tabs:
       nav(p,tab);m=measure(p);fresh=colors.get((width,tab),[None,None,None]);ok=m['colors'][0]!=fresh[0] and len(set(m['colors']))==1
       record(extras,'Esquema moderno: '+tab,ok,[fresh[0],m['colors'][0]])
       for ob in obs:
        if ob['tab']==tab:
         for ck in ob['checks']:
          if ck['check']==5:ck['passed']=ck['passed'] and ok;ck['modern']=m['colors'][0]
     except Exception as exc:record(extras,'esquema alternativo do WordPress',False,str(exc)[:400])
     finally:scheme('fresh')
    ctx.close()
   ctx=b.new_context(java_script_enabled=False,viewport={'width':768,'height':900},locale='pt-BR',service_workers='block');ctx.route('**/*',route);login(ctx);p=ctx.new_page();p.set_default_timeout(4000)
   try:
    p.goto(wpurl,wait_until='networkidle');a=p.locator('.f3-subtabs').get_by_role('link',name='Ativos',exact=True);a.scroll_into_view_if_needed()
    box=a.bounding_box();xy=[box['x']+box['width']/2,box['y']+box['height']/2];hit=a.evaluate('(e,xy)=>e.contains(document.elementFromPoint(...xy))',xy);href=a.get_attribute('href')
    p.mouse.click(*xy);p.wait_for_url(href,timeout=6500);expect(p.locator('#f3-assets')).to_be_visible()
    record(extras,'Clique físico de ponteiro sem JS em subaba inativa',hit,{'origem':'connections','destino':'assets','hitTest':hit,'metodo':'coordenadas centrais do link, sem force'})
   except Exception as exc:record(extras,'Clique físico sem JS',False,str(exc)[:1000])
   for group,ts in groups.items():
    try:
     p.goto(wpurl);a=p.locator('.f3-groups').get_by_role('link',name=group,exact=True);href=a.get_attribute('href');a.focus();p.keyboard.press('Enter');p.wait_for_url(href)
     for tab,title in ts.items():
      a=p.locator('.f3-subtabs').get_by_role('link',name=title,exact=True);href=a.get_attribute('href');a.focus();p.keyboard.press('Enter');p.wait_for_url(href);expect(p.locator('#f3-'+tab)).to_be_visible();record(extras,'Navegação sem JavaScript: '+tab,True)
    except Exception as exc:record(extras,'Navegação sem JavaScript: '+group,False,str(exc)[:400])
   ctx.close()
  finally:b.close()
 record(extras,'Sem erro JavaScript na página',not runtime_errors,runtime_errors);record(extras,'Sem fontes, ícones ou scripts externos',not {a for a in offsite_assets if a[0] in ('script','font','stylesheet')},list(offsite_assets))
 checks=[x for o in obs for x in o['checks']]+extras
 result={'browser':browser,'wordpress':(root/'wordpress/wp-includes/version.php').read_text().split("$wp_version = '")[1].split("'")[0],'canonical_css_sha256':wanted,'native_scheme':'fresh → modern; atualização do perfil do usuário sintético entre as consultas','fixture':'aviso independente via admin_notices; somente dados sintéticos; HTTP externo bloqueado','screens':obs,'extras':extras,'images':images,'supplementary_images':additional_images,'total':len(checks),'failed':sum(not x['passed'] for x in checks)}
 (dest/'results.json').write_text(json.dumps(result,ensure_ascii=False,indent=1)+'\n')
 checklist=['Folha e ordem','Identidade','Aviso alheio','Navegação','Esquema WP','Selos','Campos','Tabelas','Largura','Toque','Foco','CSS local'];lines=['# Conferência visual · Fator3 MCP LinkedIn 0.27.0','',f'WordPress {result["wordpress"]}; Chromium {browser}; 12 subabas e 3 larguras. As imagens mostram a página completa, com aviso real de outro plugin de laboratório.', '', '| Subaba | 360 px | 768 px | 1440 px | '+ ' | '.join(f'{i+1}. {c}' for i,c in enumerate(checklist))+' |','|'+ '---|'*16]
 for t,(g,title) in tabs.items():
  rows=[o for o in obs if o['tab']==t]
  lines+=['| '+title+' | '+' | '.join('[Captura]('+o['image']+')' if o.get('image') else 'Sem captura' for o in rows)+' | '+' | '.join('Sim' if len(rows)==3 and all(any(k['check']==i and k['passed'] for k in o['checks']) for o in rows) else 'Ver evidência' for i in range(1,13))+' |']
 lines+=['','O critério 10 se aplica a 360 e 768 px. Critério 6 admite o selo neutro sem classe semântica. Em abas sem tabela, campo ou resumo, a regra se aplica quando o componente existe. Medições, ocorrências, mudança de esquema e testes complementares em results.json.']
 (dest/'checklist.md').write_text('\n'.join(lines)+'\n')
 periodic_path.unlink(missing_ok=True)
 print(json.dumps({'images':len(images),'total':len(checks),'failed':result['failed']},ensure_ascii=False));return result['failed']==0 and len(images)==36
if __name__=='__main__':raise SystemExit(0 if run() else 1)
