# Prova visual do painel LinkedIn 0.27.0

O executor `../native/webui027.php` só funciona em uma instalação descartável criada por `tools/lab.py`. Ele confere a identidade do laboratório, instala temporariamente uma extensão de aviso e fixtures de HTTP sintéticas e inicia o próprio wp-admin em endereço de loopback. Todas as requisições do navegador a endereços externos são bloqueadas. Não fornece credenciais a sites remotos.

Requisitos adicionais: Python 3 com Playwright e Pillow, Chromium Headless Shell executável, e os requisitos de `tools/lab.py`. Defina `F3_CHROME_HEADLESS_SHELL` com a instalação local do navegador e passe `--tests webui027.php --order linkedin-integrated --origin clean` ao executor. Em um ambiente descartável que não oferece o sandbox de Chromium, o executor respeita `F3_LAB_CHROME_NO_SANDBOX=1` para esse navegador de teste.

O laboratório grava `evidence/visual027/results.json` (por largura, subaba e item da seção 7 do Guia Visual), `checklist.md` e capturas de página inteira, em WebP sem perdas. O viewport é de 360 × 850, 768 × 850 ou 1440 × 960; a largura da imagem confirma o viewport e a altura inclui toda a página. Só as imagens principais contam nas 36. As adicionais mostram o editor e o aviso de erro. A falta da folha oficial, uma diferença de toque, foco, posição de rótulo ou largura, ou uma interação malsucedida faz o teste terminar com erro.

Para o esquema de cores, o teste altera a preferência do administrador sintético pelo WordPress, carrega as 12 subabas novamente e mede a cor calculada do grupo e da subaba. Depois restaura a preferência da fixture. A navegação sem JavaScript é testada em um segundo contexto com teclado e ponteiro. As contagens referem-se a verificações da UI, não a homologação de APIs do LinkedIn.
