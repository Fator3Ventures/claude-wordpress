# Plano da release — Fator3 MCP LinkedIn 0.27.0

20/11/2026 · implementação · base 0.26.0. Regras centrais: instrucoes-agentes-plugins-fator3.md e padrao-desenvolvimento-plugins-fator3.md, revisão 5 de 02/11/2026. A aba LinkedIn e a regra comum preservam a identidade pública; o guia de 20/11 substitui a referência visual anterior. A especificação “Fator3 MCP LinkedIn — ajustes de tela” tem 15 itens numerados dentro do documento, sem novo número de pedido geral.

## Escopo e decisões

- Preservar Ferramentas → Fator3 MCP LinkedIn, o endereço de cada uma das 12 subabas, `manage_options`, as 100 operações e os controles atuais de simulação e confirmação. Redistribuir os destinos em Configurar (5), Dados (4) e Suporte (3). Não criar terceiro nível.
- Adotar a cópia local de `assets/f3-ui.css` versão visual 1.0.0: 11.886 bytes e SHA-256 `15ef0d932b1be12a541b8408b061ee276a4db9d6650476f92b5e2f41eefc0c2b`, idêntica ao bloco da Folha comum. Sem servir recursos a partir de outro plugin ou de CDN. Carregar somente na página do LinkedIn e antes da folha específica.
- Aplicar os componentes previstos a estados, avisos de resultado, blocos avançados, ações sensíveis, formulários, barra de salvar e listas. Preservar pesquisa, paginação, acionamento por teclado, contexto da conexão e distinção entre ação local e efeito no fornecedor.
- Não há alteração de schema ou migração de dados própria desta versão. O caminho é instalação limpa ou atualização direta do instalador 0.26.0 (SHA-256 `607a7b432bcf974047cc648506087690ba46998aaf0dc931662f9ecadf2e02bd`). A distribuição nova ainda não estava fechada na fase de planejamento; o relatório de entrega identifica seus bytes efetivos.

## Fronteiras e impactos avaliados no planejamento

O guia é comum à frota; cada pacote embarca a sua própria cópia. O LinkedIn não registra estilos em páginas do Meta, Google, Pipedrive, Implantador, Site Core ou do canal MCP. O escopo não altera autenticação, API pública, Lead Sync, assinaturas, conversões, envelopes, transporte ou atribuição de propriedade dos dados. A frota pode comparar os hashes dos seis pacotes independentemente de ordem de instalação.

Referências recebidas: instalador do Site Core 1.100.1, SHA-256 `15b5f18858d5e56e5cdbc96bdef83fcc60629279cc6c8e7e17d14571a9fe2f11`; instalador do MCP 0.54.0, SHA-256 `175b01ba1eeacc6655e739b70b694c2127c7df7e5858b180c773da8630392202`. O relatório do Core declara convivência com o LinkedIn 0.26.0. O relatório do MCP trata da apresentação de uma configuração técnica do Core. Nenhum exige modificação no LinkedIn para cumprir seu contrato. O encaminhamento sobre e-mail da versão LinkedIn 0.26.0 permanece histórico da rodada anterior; esta atualização não muda seu contrato nem atesta aceite na caixa postal.

**Conclusão preliminar:** nenhuma alteração de contrato, código ou configuração solicitada a outro mantenedor. Não emitir impacto individual de simples padronização visual. Se o teste identificar consequência real em outro pacote, registrar diagnóstico e destinatário antes do fechamento.

## Critérios de entrega

1. Conferir raiz e header, ordem/escopo das folhas, SHA do CSS literal, número, ordem e destinos dos links; testar acesso pelos endereços antigos com e sem JavaScript.
2. Preencher os 12 critérios da seção 7 do guia por subaba; obter capturas de cada subaba a 360, 768 e 1440 px com aviso ativo de outro plugin. Conferir rolagem, tamanho dos alvos, foco, estados e cor ao trocar de esquema. Usar registros sintéticos e capturas sem segredos.
3. Conferir preservação dos dados e permissões da base; repetir as operações relevantes sem chamadas comerciais. Descobrir/paginar a documentação pelo MCP. Validar instalação e saúde no ambiente autorizado separadamente das provas em instalação local.
4. Registrar evidências efetivas e limites no relatório. Somente os testes concluídos podem ser classificados como validados.
