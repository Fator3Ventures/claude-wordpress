# Fator3 MCP LinkedIn — ajustes de tela

O Fator3 MCP LinkedIn 0.26.0 usa a mesma raiz do Meta (`f3-social`), mas tem outra navegação (seis pílulas em vez de três grupos), cor de destaque fixa (`#2271b1`), selos de estado em outras cores e itens de navegação de 30 px em tela estreita. Slug, capacidade, rotas e options não mudam.

## Navegação

Hoje são seis seções em pílulas: Conexões · Concessões · Dados · Anúncios e publicações · Manutenção · Ajuda. Passa aos mesmos grupos do Meta:

| grupo | subabas |
| --- | --- |
| Configurar | Conexões · Ativos · Formulários · Conversões de aquisição · Etapas comerciais |
| Dados | Relatórios · Coletas · Histórico · Anúncios e publicações |
| Suporte | Diagnóstico · Retenção · Ajuda |

A tela abre em Configurar › Conexões. Os endereços de hoje continuam abrindo a mesma tela.

## Ajustes

| # | onde | hoje | muda para |
| --- | --- | --- | --- |
| 1 | carga da folha (`includes/Admin.php` linha 90) | só `assets/admin.css` | `assets/f3-ui.css` antes da folha própria |
| 2 | raiz `div.wrap.f3-social` | sem variáveis; `#2271b1` sete vezes e `#135e96` quatro vezes na folha | acrescentar `f3-ui`; variáveis `--f3-*` |
| 3 | cabeçalho `header.f3-heading` (linha 121) | h1 e descrição dentro de `div`; selo `span.f3-badge` de raio 20 px; sem `hr.wp-header-end` | sem `div`; `span.f3-version`; `hr.wp-header-end` depois do cabeçalho |
| 4 | primeiro nível `nav.f3-tabs` (linha 30) | seis pílulas de 13 px e 33 px de altura, 30 px abaixo de 782 px; ativa `#2271b1` | `div.f3-groups` dentro de `nav.f3-nav`, com três grupos |
| 5 | segundo nível `nav.f3-subnav` (linha 35) | traço de 2 px, texto `#135e96`, 13 px | `div.f3-subtabs` |
| 6 | selos `.f3-status-pill` e `[role=status][data-tone]` | `#e8f4eb` / `#14532d`, `#fff4d6` / `#704500`, `#fcecea` / `#842521`, `#eaf2fa` / `#164a70`; raio 1 rem; 13 px, peso 600 | `f3-pill` com `is-ok`, `is-warn`, `is-error` ou `is-info`; 12 px |
| 7 | aviso de resultado `#f3-message` | preso ao canto superior direito da janela (`position:fixed`), com `pointer-events:none` e altura máxima de 18vh | `f3-result`, sob a barra do wp-admin, com botão Dispensar |
| 8 | blocos `.f3-config-panel` (raio 6 px, 14×16 px) e `.f3-sensitive` (barra de 3 px `#b32d2e`) | nomes e medidas próprios | `details.f3-collapsible` e `f3-danger` |
| 9 | rodapé de formulário `.f3-form-footer` | barra presa ao pé | `f3-savebar` |
| 10 | campos: `label` direto em `.f3-grid`, com peso 500 | rótulo e campo no mesmo `label` | `f3-field` em `f3-grid`; rótulo com peso 600 |
| 11 | listas: `.f3-list-tools` e `.f3-pager` | busca, total e paginação já existem | manter; o total passa a `f3-list-total` |
| 12 | tabela `.f3-connection-table` em `.f3-scroll` | larguras por coluna e largura mínima de 42 rem, ou 37 rem abaixo de 782 px | `f3-table-scroll`; as larguras por coluna ficam na folha própria |
| 13 | caixas de marcar | 1,1 rem, ou 1,35 rem abaixo de 782 px | o tamanho nativo do WordPress |
| 14 | botões da lista de conexões abaixo de 782 px (`#f3-connection-list .button`) | `min-height:30px` e `padding:4px` | 40 px, pela folha comum |
| 15 | foco | contorno `#2271b1` ou `#135e96` | o da folha comum |

## Já está conforme

- Largura de 1320 px e h1 nativo.
- Cartão `f3-section` com raio 8 px e 24 px de espaço interno.
- Listas com busca, total e paginação; links com endereço e `aria-current`.
- A 360 px a página não rola na horizontal.

## Aceite

A conferência da seção 7 do guia preenchida por subaba, com as capturas a 360, 768 e 1440 px; a navegação com os mesmos três grupos do Meta.
