# Fator3 MCP LinkedIn 0.27.0 — código, testes e evidências

Esta versão atualiza diretamente a 0.26.0. O painel fica em **Ferramentas → Fator3 MCP LinkedIn**. A nova navegação reúne as doze subabas em **Configurar**, **Dados** e **Suporte**. A árvore editável de PHP está em `build/common` e `build/linkedin`, a interface em `build/assets` e os manuais em `build/docs/linkedin`. A cópia `plugin/wp-mcp-linkedin-fator3` corresponde ao instalador.

## Reproduzir o pacote

Em PHP de 64 bits ≥ 8.3, com Python 3:

```sh
F3_SOCIAL_PHP=/caminho/php python3 build/build.py
python3 tools/verify-installer027.py build/dist/wp-mcp-linkedin-fator3-0.27.0-instalador.zip plugin/wp-mcp-linkedin-fator3
python3 tools/review-runtime027.py /dependencias/wp-mcp-linkedin-fator3-0.26.0-instalador.zip build/dist/wp-mcp-linkedin-fator3-0.27.0-instalador.zip
```

O primeiro passo gera o catálogo das operações e a ajuda paginada. O segundo verifica a árvore publicada e cada entrada do manifesto. O terceiro compara as duas versões, a folha canônica, o bootstrap e os schemas de domínio. Os binários de WordPress, PHP, banco, navegador e plugins acompanhantes não são redistribuídos.

## Homologação

Use WordPress ≥ 7.1.4 e banco MySQL/MariaDB descartável. Consulte o relatório da versão para os cenários, caminhos de reexecução e limites. Os pedidos, o guia e a folha comum originais estão em `inputs/0.27.0`. Resultados da rodada: `evidence/release0270`. Não execute as fixtures contra uma instalação de produção.

Para reproduzir a prova de navegador, consulte [PROVA-VISUAL-027.md](tests/browser/PROVA-VISUAL-027.md). O arquivo [lab-release0270.example.json](tools/lab-release0270.example.json) identifica as dependências usadas na rodada. Para gerar o caderno a partir das capturas, execute `python3 tools/visual-book027.py evidence/release0270/visual027 caderno.pdf` com Pillow, ReportLab e as fontes DejaVu Sans instalados.

O instalador contém somente runtime e documentação. O pacote de fonte é fechado com `tools/package-source.py --output-dir /caminho/externo`. A cópia interna do relatório antecede o cálculo do tamanho e SHA-256 do próprio fonte.
