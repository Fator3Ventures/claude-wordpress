<?php
/** Diagnostics for MCP's marker only. Reads never run callbacks or repair history. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class CronMarker {
    private static array $intent=[];
    public const HOOK='f3_mcp_cron_observed';
    public static function init(): void {
        add_action('init',[self::class,'ensure']);add_action(self::HOOK,[self::class,'observed']);
        add_filter('pre_reschedule_event',static function($pre,$event){if($event->hook===self::HOOK)self::$intent['reschedule']=(array)$event;return $pre;},PHP_INT_MAX,2);
        add_filter('pre_unschedule_event',static function($pre,$ts,$hook,$args){if($hook===self::HOOK)self::$intent['unschedule']=['timestamp'=>(int)$ts,'args'=>$args];return $pre;},PHP_INT_MAX,4);
        foreach(['reschedule','unschedule'] as $operation)add_action('cron_'.$operation.'_event_error',static function($error,$hook,$event)use($operation){if($hook===self::HOOK)self::incident($operation,$event,$error);},10,3);
    }
    private static function persisted() {
        global $wpdb;$wpdb->last_error='';$raw=$wpdb->get_var("SELECT option_value FROM `$wpdb->options` WHERE option_name='cron'");if($wpdb->last_error)return null;
        if($raw===null)return [];$cron=maybe_unserialize($raw);return is_array($cron)?$cron:null;
    }
    private static function matching(?array $cron): ?array {
        if($cron===null)return null;$rows=[];foreach($cron as $ts=>$hooks)if(is_array($hooks)&&isset($hooks[self::HOOK]))foreach($hooks[self::HOOK] as $e)$rows[]=['timestamp'=>(int)$ts,'schedule'=>$e['schedule']??false,'interval'=>(int)($e['interval']??0),'args'=>$e['args']??[]];return $rows;
    }
    private static function current(): array {
        $db=self::matching(self::persisted());wp_cache_delete('cron','options');wp_cache_delete('alloptions','options');$effective=self::matching(_get_cron_array()?:[]);
        return ['persisted'=>$db,'effective'=>$effective,'consistent'=>$db!==null&&$db===$effective];
    }
    private static function record(array $r): void {
        try{$s=StateStore::get('cron-marker','scheduling')??[];$s['last_operation']=$r;StateStore::put('cron-marker','scheduling',$s);}catch(\Throwable $e){error_log('Fator3 MCP cron marker diagnostic persistence failed');}
    }
    public static function ensure(): void {try{self::schedule();}catch(\Throwable $e){error_log('Fator3 MCP marker scheduling observation unavailable');}}
    private static function schedule(): void {
        Locks::run(['cron-marker:'.get_current_blog_id()=>LOCK_EX],static function(){
            $read=self::current();if(!$read['consistent']){self::record(['operation'=>'schedule','status'=>'unconfirmed','reason'=>'cron_readback_unavailable','time'=>time()]);return Result::ok();}
            foreach($read['persisted'] as $row)if($row['args']===[]&&$row['schedule']==='hourly'&&$row['interval']===3600)return Result::ok();
            if($read['persisted']){self::record(['operation'=>'schedule','status'=>'unconfirmed','reason'=>'unexpected_marker_shape','time'=>time()]);return Result::ok();}
            $ts=time()+300;$native=wp_schedule_event($ts,'hourly',self::HOOK,[],true);$after=self::current();$wanted=['timestamp'=>$ts,'schedule'=>'hourly','interval'=>3600,'args'=>[]];$verified=$after['consistent']&&in_array($wanted,$after['persisted'],true);
            $r=['operation'=>'schedule','status'=>$verified?'confirmed':(is_wp_error($native)?'failed':'unconfirmed'),'timestamp'=>$ts,'args_sha256'=>hash('sha256',serialize([])),'interval'=>3600,'schedule'=>'hourly','origin'=>'mcp_init','time'=>time(),'native_return'=>is_wp_error($native)?$native->get_error_code():$native];
            self::record($r);if(is_wp_error($native)&&!$verified)self::incident('schedule',(object)['timestamp'=>$ts,'schedule'=>'hourly','interval'=>3600,'args'=>[]],$native);return Result::ok();
        });
    }
    public static function incident(string $operation,$event,$error): void {try{self::save_incident($operation,$event,$error);}catch(\Throwable $e){error_log('Fator3 MCP marker incident persistence unavailable');}}
    private static function save_incident(string $operation,$event,$error): void {
        Locks::run(['cron-marker-history:'.get_current_blog_id()=>LOCK_EX],static function()use($operation,$event,$error){
            $s=StateStore::get('cron-marker','scheduling')??[];$s['incidents']=$s['incidents']??[];
            $e=array_merge((array)$event,self::$intent[$operation]??[]);$r=['id'=>bin2hex(random_bytes(12)),'operation'=>$operation,'timestamp'=>(int)($e['timestamp']??0),'schedule'=>$e['schedule']??false,'interval'=>(int)($e['interval']??0),'args_sha256'=>hash('sha256',serialize($e['args']??[])),'args_empty'=>($e['args']??[])===[],'time'=>time(),'status'=>'unconfirmed','error_code'=>is_wp_error($error)?$error->get_error_code():'unknown','origin'=>'native_wp_cron'];
            $read=self::current();$proved=false;
            if($read['consistent']&&$r['timestamp']>0){
                if($operation==='unschedule'){$proved=true;foreach($read['persisted'] as $row)if($row['timestamp']===$r['timestamp']&&hash('sha256',serialize($row['args']))===$r['args_sha256'])$proved=false;}
                elseif($operation==='reschedule'&&$r['interval']>0){foreach($read['persisted'] as $row)if($row['timestamp']>$r['timestamp']&&($row['timestamp']-$r['timestamp'])%$r['interval']===0&&$row['schedule']===$r['schedule']&&$row['interval']===$r['interval']&&hash('sha256',serialize($row['args']))===$r['args_sha256'])$proved=true;}
            }
            if($proved){$r['status']='confirmed';$r['resolved_at']=time();$r['resolved_by']='persisted_postcondition';}

            if(count($s['incidents'])>=100)$s['untracked_errors']=(int)($s['untracked_errors']??0)+1;else $s['incidents'][]=$r;
            StateStore::put('cron-marker','scheduling',$s);return Result::ok();
        });
    }
    public static function observed(): void {
        $stamp=time();$native=update_option('f3_mcp_last_cron_observed',$stamp,false);global $wpdb;$actual=$wpdb->get_var("SELECT option_value FROM `$wpdb->options` WHERE option_name='f3_mcp_last_cron_observed'");
        self::record(['operation'=>'callback_marker','status'=>!$wpdb->last_error&&(string)$actual===(string)$stamp?'confirmed':'unconfirmed','callback_executed'=>true,'marker_persisted'=>!$wpdb->last_error&&(string)$actual===(string)$stamp,'time'=>$stamp,'native_return'=>$native]);
    }
    public static function status(): array {
        try{$s=StateStore::get('cron-marker','scheduling')??[];$r=self::current();return ['contract'=>'mcp-cron-marker/1','scope'=>'site_marker_only','hook'=>self::HOOK,'status'=>$r['consistent']&&$r['persisted']?'confirmed':($s['last_operation']['status']??'unobserved'),'readback'=>$r,'last_operation'=>$s['last_operation']??null,'incidents'=>$s['incidents']??[],'untracked_errors'=>$s['untracked_errors']??0,'history_complete'=>empty($s['untracked_errors']),'callbacks_replayed'=>false];}catch(\Throwable $e){return ['contract'=>'mcp-cron-marker/1','scope'=>'site_marker_only','status'=>'unconfirmed','history_complete'=>false];}
    }
    public static function deactivate(): void {
        Locks::run(['cron-marker:'.get_current_blog_id()=>LOCK_EX],static function(){
            $native=wp_clear_scheduled_hook(self::HOOK,[],true);$r=self::current();self::record(['operation'=>'clear','status'=>$r['consistent']&&!$r['persisted']?'confirmed':(is_wp_error($native)?'failed':'unconfirmed'),'time'=>time(),'native_return'=>is_wp_error($native)?$native->get_error_code():$native]);return Result::ok();
        });
    }
}
