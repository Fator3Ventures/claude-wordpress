<?php
/** Scoped Yoast adapter: preserve identity, bounded typed repair. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class SeoIndexables {
    public static function rows(int $id,bool $lock=false,string $type='post'): array {
        global $wpdb;
        return Persistence::rows($wpdb->prepare("SELECT * FROM `{$wpdb->prefix}yoast_indexable` WHERE object_id=%d AND object_type=%s ORDER BY id LIMIT 1001".($lock?' FOR UPDATE':''),$id,$type));
    }
    public static function services() {
        try {
            $c=\YoastSEO()->classes;$b=$c->get('Yoast\\WP\\SEO\\Builders\\Indexable_Builder');$r=$c->get('Yoast\\WP\\SEO\\Repositories\\Indexable_Repository');
            if(!is_callable([$b,'build_for_id_and_type'])||!is_callable([$r,'query'])||(new \ReflectionMethod($b,'build_for_id_and_type'))->getNumberOfParameters()<3)throw new \RuntimeException();
            return [$b,$r];
        } catch(\Throwable $e){return new \WP_Error('seo_provider_incompatible','Contrato de indexação compatível indisponível; nada foi alterado.');}
    }
    public static function rebuild(int $id,?int $expected=null,string $type='post'): bool {
        $services=self::services();if(is_wp_error($services))return false;
        try {
            [$b,$r]=$services;$rows=self::rows($id,false,$type);if(count($rows)>1)return false;
            $old=$rows?(int)$rows[0]['id']:null;if($expected!==null&&$expected!==$old)return false;
            // query() avoids the repository's automatic upgrade/build side effect.
            $model=$old?$r->query()->where('id',$old)->find_one():false;
            if($old&&!$model)return false;
            $built=$b->build_for_id_and_type($id,$type,$model);$after=self::rows($id,false,$type);
            return $built&&count($after)===1&&(!$old||(int)$after[0]['id']===$old)&&(int)$built->id===(int)$after[0]['id'];
        }catch(\Throwable $e){return false;}
    }
    public static function preflight(int $id,string $type='post') {
        $s=self::services();if(is_wp_error($s))return $s;
        try{[$b,$r]=$s;$rows=self::rows($id,false,$type);if(count($rows)>1)return new \WP_Error('seo_indexable_duplicates','Duplicatas existentes requerem reparação explícita.');$model=$rows?$r->query()->where('id',(int)$rows[0]['id'])->find_one():$r->query()->create(['object_id'=>$id,'object_type'=>$type]);
            $helper=\YoastSEO()->classes->get('Yoast\\WP\\SEO\\Helpers\\Indexable_Helper');if(!is_callable([$helper,'should_index_indexable'])||!$helper->should_index_indexable($model))return new \WP_Error('seo_indexing_disabled','Persistência de indexação desabilitada pelo provedor; nada foi alterado.');return true;
        }catch(\Throwable $e){return new \WP_Error('seo_provider_incompatible','Não foi possível verificar a indexação do provedor.');}
    }
    public static function permission(array $i): bool {
        return ConnectionTools::permission()&&ContentTools::permission($i)&&(current_user_can('wpseo_manage_options')||current_user_can('wpseo_edit_advanced_metadata'));
    }
    public static function register(): void {
        Registry::add('content/deduplicate-seo-indexables','Prévia e confirmação de reparo Yoast para um post/página. Preserva menor ID e recusa dependências não modeladas. Backup privado limitado a 1000 linhas e 4 MiB; não reindexa o site.', ['id'=>Registry::integer(1),'confirm_token'=>Registry::string()],['id'],[self::class,'repair'],[self::class,'permission'],false);
    }
    private static function snapshot(int $id,bool $lock=false) {
        global $wpdb;
        if(!self::permission(['id'=>$id]))return new \WP_Error('permission_denied','Exige Manutenção, administração e edição SEO.');
        if(!in_array(get_post_type($id),['post','page'],true))return new \WP_Error('seo_object_unsupported','A reparação atende posts e páginas.');
        if(!defined('WPSEO_VERSION'))return new \WP_Error('seo_provider_unavailable','Yoast indisponível.');
        $tables=['indexable'=>$wpdb->prefix.'yoast_indexable','hierarchy'=>$wpdb->prefix.'yoast_indexable_hierarchy','links'=>$wpdb->prefix.'yoast_seo_links'];$schemas=[];
        foreach($tables as $key=>$t){
            $engine=Persistence::rows($wpdb->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=%s',$t));
            if(($engine[0]['ENGINE']??'')!=='InnoDB')return new \WP_Error('seo_schema_unsupported','Reparo requer as três tabelas Yoast InnoDB.');
            $schemas[$key]=Persistence::rows("SHOW FULL COLUMNS FROM `$t`");
            $foreign=Persistence::rows($wpdb->prepare('SELECT TABLE_NAME,COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE REFERENCED_TABLE_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME=%s',$t));
            if($foreign)return new \WP_Error('seo_dependencies_unsupported','Há chaves estrangeiras externas; reparo específico necessário.');
        }
        $allowed=json_decode('{"indexable":["id","permalink","permalink_hash","object_id","object_type","object_sub_type","author_id","post_parent","title","description","breadcrumb_title","post_status","is_public","is_protected","has_public_posts","number_of_pages","canonical","primary_focus_keyword","primary_focus_keyword_score","readability_score","is_cornerstone","is_robots_noindex","is_robots_nofollow","is_robots_noarchive","is_robots_noimageindex","is_robots_nosnippet","twitter_title","twitter_image","twitter_description","twitter_image_id","twitter_image_source","open_graph_title","open_graph_description","open_graph_image","open_graph_image_id","open_graph_image_source","open_graph_image_meta","link_count","incoming_link_count","prominent_words_version","created_at","updated_at","blog_id","language","region","schema_page_type","schema_article_type","has_ancestors","estimated_reading_time_minutes","version","object_last_modified","object_published_at","inclusive_language_score","seo_title_score","meta_description_score"],"hierarchy":["indexable_id","ancestor_id","depth","blog_id"],"links":["id","url","post_id","target_post_id","type","indexable_id","target_indexable_id","height","width","size","language","region"]}',true);
        foreach($schemas as $key=>$schema){$actual=array_column($schema,'Field');sort($actual);$known=$allowed[$key];sort($known);if($actual!==$known)return new \WP_Error('seo_schema_unsupported','Colunas Yoast fora do schema verificado.');}
        $cols=array_column($schemas['hierarchy'],'Field');sort($cols);if($cols!==['ancestor_id','blog_id','depth','indexable_id'])return new \WP_Error('seo_schema_unsupported','Schema da hierarquia desconhecido.');
        $linkcols=array_column($schemas['links'],'Field');foreach(['indexable_id','target_indexable_id'] as $k)if(!in_array($k,$linkcols,true))return new \WP_Error('seo_schema_unsupported','Referência de links desconhecida.');
        $rows=self::rows($id,$lock);$ids=array_map('intval',array_column($rows,'id'));$hierarchy=[];$links=[];
        if($ids){$list=implode(',',$ids);$suffix=$lock?' FOR UPDATE':'';
            $hierarchy=Persistence::rows("SELECT * FROM `{$tables['hierarchy']}` WHERE indexable_id IN ($list) OR ancestor_id IN ($list) ORDER BY indexable_id,ancestor_id,depth LIMIT 1001".$suffix);
            $links=Persistence::rows("SELECT * FROM `{$tables['links']}` WHERE indexable_id IN ($list) OR target_indexable_id IN ($list) ORDER BY id LIMIT 1001".$suffix);
        }
        $remove=array_slice($ids,1);$postmeta=Persistence::rows($wpdb->prepare("SELECT * FROM `$wpdb->postmeta` WHERE post_id=%d ORDER BY meta_id LIMIT 1001".($lock?' FOR UPDATE':''),$id));
        foreach($hierarchy as $h)if(in_array((int)$h['ancestor_id'],$ids,true)||!in_array((int)$h['indexable_id'],$ids,true)||(int)$h['ancestor_id']!==0)return new \WP_Error('seo_dependencies_unsupported','Hierarquia externa requer reparação específica.');
        foreach($links as $l)if(in_array((int)$l['indexable_id'],$remove,true)||in_array((int)$l['target_indexable_id'],$remove,true))return new \WP_Error('seo_dependencies_unsupported','Duplicata possui links; nada foi alterado.');
        $s=['contract'=>'yoast-deduplicate/1','id'=>$id,'site_id'=>get_current_blog_id(),'yoast_version'=>WPSEO_VERSION,'schemas'=>$schemas,'rows'=>$rows,'hierarchy'=>$hierarchy,'links'=>$links,'postmeta'=>$postmeta,'keep_id'=>$ids[0]??null,'remove_ids'=>$remove];
        if(count($rows)+count($hierarchy)+count($links)+count($postmeta)>1000||strlen(serialize($s))>4194304)return new \WP_Error('seo_preimage_limit','Pré-imagem excede 1000 linhas ou 4 MiB.');return $s;
    }
    private static function summary(array $s): array {return ['id'=>$s['id'],'keep_id'=>$s['keep_id'],'remove_ids'=>$s['remove_ids'],'relationships'=>count($s['hierarchy']),'preimage_sha256'=>hash('sha256',serialize($s))];}
    public static function repair(array $i): array {
        return Locks::run(['post:'.get_current_blog_id().':'.(int)$i['id']=>LOCK_EX],static function()use($i){
            $s=self::snapshot((int)$i['id']);if(is_wp_error($s))return Result::error($s);
            if(!$s['remove_ids']&&empty($i['confirm_token']))return Result::ok(['changed'=>false,'persisted'=>true,'keep_id'=>$s['keep_id']]);
            return Phase::run('content/deduplicate-seo-indexables',$i,static function()use($i){$s=self::snapshot((int)$i['id']);return is_wp_error($s)?$s:self::summary($s);},static function($before)use($i){
                global $wpdb;$s=self::snapshot((int)$i['id']);if(is_wp_error($s))return Result::error($s);if(self::summary($s)!==$before)return Result::fail('preimage_conflict','Seleção mudou.');
                $backup=Backups::create_snapshot('content/deduplicate-seo-indexables',$s);if(is_wp_error($backup))return Result::error($backup);
                try{$result=Persistence::transaction(static function()use($i,$before,$s,$wpdb){
                    $fresh=self::snapshot((int)$i['id'],true);if(is_wp_error($fresh))return $fresh;if(self::summary($fresh)!==$before)return new \WP_Error('preimage_conflict','Seleção mudou sob lock.');
                    $list=implode(',',array_map('intval',$s['remove_ids']));
                    Persistence::query("DELETE FROM `{$wpdb->prefix}yoast_indexable_hierarchy` WHERE indexable_id IN ($list)");
                    Persistence::query("DELETE FROM `{$wpdb->prefix}yoast_indexable` WHERE id IN ($list)");
                    $after=self::rows((int)$i['id'],true);if(count($after)!==1||$after[0]!==$s['rows'][0])throw new \RuntimeException('readback');
                    return true;
                });if(is_wp_error($result))return Result::error($result)+['backup_id'=>$backup];
                $after=self::snapshot((int)$i['id']);if(is_wp_error($after)||count($after['rows'])!==1||$after['rows'][0]!==$s['rows'][0]||$after['postmeta']!==$s['postmeta'])return Result::fail('seo_repair_unconfirmed','Releitura após commit divergente.',['backup_id'=>$backup,'applied'=>null]);
                clean_post_cache((int)$i['id']);return Result::ok(['id'=>(int)$i['id'],'changed'=>true,'persisted'=>true,'keep_id'=>$s['keep_id'],'removed_ids'=>$s['remove_ids'],'backup_id'=>$backup,'readback'=>['count'=>1,'removed_absent'=>true,'hierarchy_removed'=>true]]);
                }catch(\Throwable $e){return Result::fail('seo_repair_failed','Reparo não confirmado; consulte a pré-imagem.',['backup_id'=>$backup,'applied'=>null]);}
            });
        });
    }
}
