# Impacto — Core 1.63.0 → Fator3 MCP

30/10/2026 · revisão 1 · **validacao-coordenada** · aberto. Emissor base-site-core-fator3, base 1.62.0, alvo 1.63.0. Destinatário wp-mcp-fator3, versão examinada 0.37.0; próxima versão a definir pelo responsável. Identificado na homologação do pedido 354, após o planejamento inicial sem impacto conhecido. Nenhum arquivo do MCP foi alterado.

## Fato e consequência

`MutationServiceAudit::init()` no MCP 0.37.0 registra `initialize()` em `wp_loaded`, prioridade 30, inclusive no login e na página pública. `initialize()` chama `wp_get_abilities()` antes de registrar a auditoria de serviço. Isso inicializa o catálogo global de habilidades e faz o Core carregar os produtores dos schemas administrativos nessas superfícies.

A pilha nativa capturada em `tests/mcp-bootstrap-trace-1630.php` confirma `MutationServiceAudit::initialize → wp_get_abilities → WP_Abilities_Registry`, no login. Sem esse acompanhante no laboratório, o bootstrap mínimo do Core inclui 7 arquivos; no Site-Teste com o conjunto ativo, a sondagem administrativa do login inclui 172. São ambientes diferentes: a contagem demonstra carga observada, e não uma estimativa isolada do custo do MCP.

No Site-Teste, `system/probe`, cache bypass comprovado, três amostras e menor geração: com Core/Pipedrive, página 870,749 ms e login 484,936 ms; sem os dois, página 408,140 ms e login 337,358 ms. Diferenças 462,609 e 147,578 ms: **pedido 354 não aceito**. Não atribuímos toda essa diferença ao MCP; há trabalho adicional do Core na página, inclusive verificações de estrutura e descoberta de llms. As medições próprias da página registram cerca de 200–216 ms em callbacks instrumentados; o restante não é uma medida isolada de um pacote.

## Ação e proposta

Responsável MCP: avaliar inicialização sob demanda da descoberta/validação do catálogo de auditoria em REST/MCP/admin/cron ou no primeiro uso efetivo. Separar registro leve dos descritores da consulta pesada de habilidades, se necessário. Preservar a captura de recibos de serviço, permissões e autorização atual do leitor, inclusive quando o primeiro evento de serviço vier de um job. Não retirar o hook sem prova de que a auditoria continuará cobrindo esses fluxos.

Responsável Core: continuar a redução do custo de montagem pública, preservando a resposta imediata das capturas e os contratos publicados. A versão 1.63.0 não fornece nem presume a alteração do MCP. O Core mantém a inicialização completa quando o catálogo é solicitado para não devolver habilidades incompletas.

## Aceite coordenado

1. Login/página pública não inicializam o catálogo administrativo apenas por carregamento dos plugins.
2. Catálogo completo e schemas atuais continuam disponíveis por MCP/REST administrativo.
3. Auditoria de escrita de serviço continua registrando, consultando e negando acesso revogado; sem escrita comercial real nesta prova.
4. Repetir os mínimos de três amostras com/sem Core+Pipedrive, com os demais pacotes preservados; diferença até 100 ms em ambas as rotas.

Evidências: evidence/1630/mcp-bootstrap-trace.json, site-profile-login.json, site-profile-page.json, site-probe-on.json e site-probe-off.json. Instalador Core examinado: 2986868 bytes, SHA-256 `afd99c56edc9445f7498e010d3123d8497fd0dd335b3cc283b5156c7de855c5b`. Não há alteração de contrato solicitada nem encerramento de trabalho de outro responsável.
