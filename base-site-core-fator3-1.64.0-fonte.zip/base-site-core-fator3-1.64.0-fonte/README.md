# Fator3 Site Core 1.64.0 — fonte

Base canônica 1.63.0. Runtime em work/plugin/base-site-core-fator3; plano em PLANO-1.64.0.md. Instruções vigentes em docs/AGENTES-1.64.0.md e docs/RELEASE-1.64.0.md dentro do runtime. Contrato 8.29.0.

Instalador separado. O fonte não contém dependências instaladas, laboratório, banco, segredos ou ZIPs aninhados. Companheiros fornecidos separadamente, versões/hashes em inputs/1640/packages.json. PHP local via build/php, F3BASE_RUNTIME aponta para runtime externo. Testes nativos requerem MySQL descartável; nunca usar banco de produção. Evidências atuais em evidence/1640, histórico preservado por versão.
