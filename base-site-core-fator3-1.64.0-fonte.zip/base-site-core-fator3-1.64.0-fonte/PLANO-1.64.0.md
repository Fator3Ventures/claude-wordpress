# Plano — Fator3 Site Core 1.64.0

31/10/2026 UTC · revisão 2 · entrega com pendências. Base publicada: 1.63.0, contrato 8.28.0. Versão implementada: 1.64.0, contrato administrativo aditivo 8.29.0. Instalador final: 3020630 bytes, SHA-256 e8c34d1cfbd347f6947e4e208fed92c11579c735f843d6c2e002c4fe29ce6588. Base conferida: 2986868 bytes, SHA-256 afd99c56edc9445f7498e010d3123d8497fd0dd335b3cc283b5156c7de855c5b. Instruções e padrão comuns revisão 4.

## Escopo e ordem

1. 357: spam por sinal, padrão falso, captura e complemento, cancelamento de saídas, revisão e contagem próprias; restauração administrativa preservada.
2. 358: persistência configurável do alerta robots (120 minutos, 15–1440), atenção e recuperação únicas e diagnóstico.
3. 359: política simulável dos e-mails nativos, sucesso desativado e falhas/recuperação preservadas.
4. 354/360: mapa e assinatura compactos do llms, invalidação imediata de conteúdo restrito; versão de estrutura, reparo agendado; zelador/rotinas no cron CLI com reserva após uma hora; perfil público com carregamento sob demanda; memorização da barreira/cache; medição completa, consultas, classes e OPcache.

Captura, consentimento, cabeçalhos e redirecionamentos mantêm efeito imediato. Rotinas podem aguardar a passagem de 15 minutos; llms, schema e configuração pública até uma hora. A configuração devolverá efeito_ate.

## Fronteiras

MCP 0.38.0 recebido resolve o carregamento antecipado do catálogo relatado no impacto da 1.63.0; comprovar novamente a convivência. Preservar SDKs Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0 e Pipedrive 0.5.0. A declaração opcional f3base_cron_rotina não altera jobs de outros plugins sem adesão. Nenhum encaminhamento individual necessário identificado nesta etapa; avaliar consequência concreta antes da implementação dependente. Não modificar acompanhantes nem enviar mensagens/push/frota.

## Validação

WordPress nativo descartável: instalação limpa e atualização direta da 1.63.0, configuração/dados preservados, permissões, documentação e regressões afetadas. Fixtures de spam, e-mail, robots, cron/contingência, reparo de estrutura e 48 itens llms. HTTP e correio comerciais bloqueados. Site-Teste autorizado: registrar estado, instalar pacote exato, validar fluxos em ambiente técnico isolado, ler documentação por MCP, medir página/login (três amostras) e limpar apenas recursos próprios.

## Limites

A homologação em korvena.com.br/fator3.com.br, redução diária de HTTP cron, próxima atualização automática real e configuração dos 12 sites pertencem à frota. Medidas locais e relatório recebido não substituem essas provas. Não declarar aceitos limites de latência sem evidência. Artefatos finais: instalador, fonte com build/testes/evidência sanitizada, relatório; impactos somente se tecnicamente necessários.

## Fechamento

Pedidos 357–359 implementados e validados em WordPress. Pedido 360 implementado, com 2316 verificações na fixture nativa do Site-Teste e provas locais complementares. Ciclos do ZIP final em WP 7.1.2 e 7.1.4/PHP 8.3.6; convivência dos cinco acompanhantes em WP 7.1.4/PHP 8.3.36. Site-Teste atualizado e recursos temporários removidos.

Pedido 354 permanece parcial: diferença comparativa de 130,460 ms na página e 22,146 ms no login; limite de 100 ms só atendido no login. Tempo próprio final de 85,888–98,097 ms na página, 60 classes, 3 consultas, descoberta abaixo de 0,05 ms; janela não instrumentada acima de 20 ms. Homologação da frota e entrega real de lead/e-mail continuam pendentes, conforme relatório. Nenhuma alteração em acompanhantes, push ou distribuição à frota. Sem impacto individual necessário nas interfaces examinadas.
