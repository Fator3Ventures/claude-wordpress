<?php
require __DIR__.'/bootstrap.php';global $wpdb;
$mode=getenv('F3BASE_STRUCTURE_MODE')?:'fail';$table=F3Base_Vitais::tabela();
$sample=['detalhe'=>'LCP','soma'=>125.0,'amostra'=>['id'=>'qa360structure','dispositivo'=>'desktop','sequencia'=>1]];
if($mode==='fail'){
 F3Base_Esquema::executar(static function(){F3Base_Vitais::instalar();(new F3Base_Modulo_Acessos_Servidor())->garantir_estrutura();});
 $seen=[];$watch=static function($sql)use(&$seen){$seen[]=$sql;return $sql;};add_filter('query',$watch);
 foreach(['F3Base_Vitais'=>'pronta','F3Base_Leads_Repositorio'=>'pronto','F3Base_Capi_Fila'=>'pronta','F3Base_Modulo_Endpoint_Leads'=>'tabela_pronta','F3Base_Modulo_Acessos_Servidor'=>'tabela_pronta','F3Base_Atualizacao'=>'pronta'] as $class=>$method){check($class::$method(),'360_cached_'.$class);}
 F3Base_Vitais::instalar();F3Base_Capi_Fila::instalar();remove_filter('query',$watch);
 check(!array_filter($seen,static fn($q)=>preg_match('/^\s*(SHOW|ALTER|CREATE|UPDATE|DESCRIBE)/i',$q)),'360_readiness_without_ddl_or_update');
 $wpdb->query("ALTER TABLE {$table} DROP COLUMN atribuicao");$previous=$wpdb->suppress_errors(true);
 check(!F3Base_Vitais::gravar(gmdate('Y-m-d'),'/qa360-structure/',$sample,'teste'),'360_first_write_rejected');
 F3Base_Esquema::observar();$wpdb->suppress_errors($previous);F3Base_Esquema::registrar_falhas();
 check(isset(get_option('f3base_esquema_reparos')[$table]),'360_repair_pending');check(wp_next_scheduled('f3base_esquema_reparar')!==false,'360_repair_scheduled');check(!F3Base_Vitais::pronta(),'360_readiness_invalidated');
 evidence('request-360-structure-fail');
}else{
 $r=F3Base_Esquema::reparar();check($r['ok']&&in_array($table,$r['reparadas'],true),'360_scheduled_repair_completed');
 check(F3Base_Vitais::gravar(gmdate('Y-m-d'),'/qa360-structure/',$sample,'teste'),'360_write_after_repair');
 $wpdb->delete($table,['caminho'=>'/qa360-structure/']);evidence('request-360-structure-repaired');
}
