<?php
require __DIR__.'/bootstrap.php';
switch_theme('f3-fixture');
// Reset only this disposable fixture's generated file when changing isolated DBs.

$cfg=F3Base_Options::ler('f3base_llms');$cfg['ligado']=true;$cfg['markdown']=true;$cfg['full']=true;$cfg['modo']='automatica';raw('f3base_llms',$cfg);
$ids=get_posts(['post_type'=>'page','post_status'=>'any','numberposts'=>100,'fields'=>'ids','meta_key'=>'qa360']);
if(count($ids)!==48){foreach($ids as $id)wp_delete_post($id,true);$ids=[];for($i=0;$i<48;$i++){$ids[]=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'QA 360 item '.$i,'post_name'=>'qa360-'.$i,'post_content'=>'<h2>Conteúdo de teste '.$i.'</h2><p>Texto público sintético para testar a seleção e o mapa Markdown. Nenhum contato ou credencial.</p>','meta_input'=>['qa360'=>1]]);}}
update_option('show_on_front','page');update_option('page_on_front',$ids[0]);update_option('blog_public',1);
// Actual front-end collection, consent and tags are registered, but external HTTP is blocked.
raw('f3base_comportamento',array_replace(F3Base_Options::ler('f3base_comportamento'),['ligado'=>true]));raw('f3base_meta_pixel_id','1234567890');
update_option('permalink_structure','/%postname%/');flush_rewrite_rules(false);
F3Base_Perfil_Publico::atualizar(false);
$physical=F3Base_Llms_Arquivo::caminho();if(str_starts_with(realpath(dirname($physical)),realpath(getenv('F3BASE_LAB_DIR')))&&is_file($physical)){unlink($physical);}
for($n=0;$n<15;$n++){$result=F3Base_Llms_Cobertura::executar(10,$n===0);if(empty($result['restantes']))break;}
if(empty($result['ok'])){echo wp_json_encode(array_intersect_key($result,array_flip(['codigo','restantes','parcial'])))."\n";}check(!empty($result['ok']),'360_generation_completed');$map=get_option('f3base_llms_mapa');check(!empty($map['serve'])&&count($map['itens'])>=48,'360_map_48_items');
$last=end($ids);$url=$map['itens'][$last];wp_update_post(['ID'=>$last,'post_status'=>'private']);$map=get_option('f3base_llms_mapa');check(!isset($map['itens'][$last]),'360_private_removed_immediately');$g=get_option(F3Base_Llms_Cobertura::PUBLICADA);$item=current(array_filter($g['itens'],static fn($i)=>($i['id']??0)===$last));check(empty(F3Base_Llms_Cobertura::item($item)['completo']),'360_private_representation_denied');wp_update_post(['ID'=>$last,'post_status'=>'publish']);F3Base_Llms_Cobertura::executar(10,true);
$info=['ids'=>$ids,'map'=>get_option('f3base_llms_mapa'),'result'=>$result];file_put_contents(getenv('F3BASE_ROOT').'/evidence/1640/fixture360.json',wp_json_encode($info,JSON_PRETTY_PRINT));evidence('fixture-360');
