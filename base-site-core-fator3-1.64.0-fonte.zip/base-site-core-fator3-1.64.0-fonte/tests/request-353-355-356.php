<?php
require __DIR__.'/bootstrap.php';wp_get_abilities();
$preserve=[];foreach([F3Base_Email_Site_Config::OPTION,F3Base_Email_Site_Config::STATE,'f3base_avisos_tecnicos','f3base_meta_correspondencia','f3base_robots',F3Base_Robots_Arquivo::OPTION,'f3base_meta_pixel_id'] as $n){$preserve[$n]=get_option($n,null);}
try{
// All mail/HTTP calls are intercepted; no provider or customer messages.
$sent=[];$accept=true;$mail=static function($pre,$attrs)use(&$sent,&$accept){$sent[]=$attrs['subject'];return $accept;};add_filter('pre_wp_mail',$mail,99999,2);
$cfg=F3Base_Email_Site_Config::padroes();$cfg['ativo']=true;$cfg['homologacao']=false;raw(F3Base_Email_Site_Config::OPTION,$cfg);
raw('f3base_avisos_tecnicos',['email'=>'fixture1630@example.test','atraso_minutos'=>60]);
check(F3Base_Options::ler('f3base_avisos_tecnicos')['imap_falhas_consecutivas']===3,'353_old_configuration_defaults');
$reset=static function($age=0){raw(F3Base_Email_Site_Config::STATE,['ativado_em'=>time()-$age,'ultima_leitura_completa'=>time()-$age]);};
$fail=static function(){F3Base_Email_Site::resultado_leitura('imap_resposta_incompleta',false,false);F3Base_Email_Alerta::observar();};
$ok=static function(){F3Base_Email_Site::resultado_leitura('',true,true);F3Base_Email_Alerta::observar();};
$reset();$fail();$ok();check(count($sent)===0,'353_transient_no_open_or_recovery');$s=F3Base_Email_Site::saude();check(count($s['ocorrencias'])===2&&$s['ocorrencias'][0]['codigo']==='imap_resposta_incompleta','353_history_error_and_recovery');
$reset();$fail();$fail();check(count($sent)===0,'353_two_passes_silent');$fail();$fail();check(count($sent)===1,'353_third_opens_once');F3Base_Email_Site::resultado_leitura('',false,true);F3Base_Email_Alerta::observar();check(count($sent)===1,'353_partial_same_second_does_not_recover');$ok();$ok();check(count($sent)===2,'353_one_recovery_after_accepted_open');
$sent=[];$reset(1201);$fail();check(count($sent)===1,'353_twenty_minutes_alternative');$ok();check(count($sent)===2,'353_elapsed_recovery');
$sent=[];$accept=false;$reset();$fail();$fail();$fail();$ok();check(count($sent)===1,'353_failed_open_has_no_recovery_mail');$accept=true;
for($i=0;$i<25;$i++){F3Base_Email_Site::resultado_leitura('imap_resposta_incompleta',false,false);}check(count(F3Base_Email_Site::saude()['ocorrencias'])===20,'353_bounded_history');
raw('f3base_avisos_tecnicos',['imap_falhas_consecutivas'=>2,'imap_sem_leitura_minutos'=>10]);$sent=[];$reset();$fail();check(!$sent,'353_custom_first_silent');$fail();check(count($sent)===1,'353_custom_second_opens');
remove_filter('pre_wp_mail',$mail,99999);
// Both configuration additions use the native dry-run path and expected revision.
foreach(['f3base_meta_correspondencia'=>false,'f3base_avisos_tecnicos'=>['imap_falhas_consecutivas'=>4,'imap_sem_leitura_minutos'=>25]] as $n=>$v){$rev=F3Base_Options::revisao($n);$dry=wp_get_ability('f3base/config-core-escrever')->execute(['nome'=>$n,'valor'=>$v,'revisao_esperada'=>$rev]);check(!is_wp_error($dry)&&empty($dry['persisted'])&&$rev===F3Base_Options::revisao($n),'configuration_simulation_'.$n);}
// Manual matching: browser accept only, classified, ad consent, no editor/test/automation.
wp_set_current_user(0);$_SERVER['HTTP_USER_AGENT']='Mozilla/5.0';
$lead=['captura'=>'aceito','classe_trafego'=>'nao_marcado','metodo'=>'formulario','email'=>'  SYNTHETIC1630@Example.Test ','dados'=>['telefone'=>'+55 (11) 99999-1630','consentimento_snapshot'=>['medicao'=>true,'publicidade'=>true,'politica_versao'=>'legado:pre-aprovado']]];
$hash=F3Base_Meta_Correspondencia::dados($lead);check(($hash['em']??'')===hash('sha256','synthetic1630@example.test'),'356_email_normalization');check(($hash['ph']??'')===hash('sha256','5511999991630'),'356_phone_country_hash');
foreach(['teste','editor'] as $kind){$v=$lead;$v['classe_trafego']=$kind;check(F3Base_Meta_Correspondencia::dados($v)===[],'356_exclusion_'.$kind);}
$v=$lead;$v['dados']['sinais_navegador']=['webdriver'=>true];check(F3Base_Meta_Correspondencia::dados($v)===[],'356_no_robot');
$v=$lead;$v['dados']['consentimento_snapshot']['publicidade']=false;check(F3Base_Meta_Correspondencia::dados($v)===[],'356_no_ad_consent');
$v=$lead;$v['dados']['classificacao_contexto']='pendente';check(F3Base_Meta_Correspondencia::dados($v)===[],'356_no_pending');
$v=$lead;$v['email']='invalid';$v['dados']['telefone']='abc';check(F3Base_Meta_Correspondencia::dados($v)===[],'356_no_valid_identity');
raw('f3base_meta_correspondencia',false);check(F3Base_Meta_Correspondencia::dados($lead)===[],'356_site_switch_off');raw('f3base_meta_correspondencia',true);
wp_set_current_user(1);check(F3Base_Meta_Correspondencia::dados($lead)===[],'356_server_editor_excluded');
// Reservation response never exposes matching before classification, including accepted forms.
wp_set_current_user(0);$lead+=['record_id'=>str_repeat('a',32),'criado_em'=>gmdate('Y-m-d H:i:s'),'sessao'=>'','correlacao'=>'fixture-1630-event'];
$pending=$lead;$pending['dados']['classificacao_contexto']='pendente';$reserved=F3Base_Aquisicoes::reservar($pending);
check(empty($reserved['elegivel'])&&isset($reserved['finalizacao'])&&!isset($reserved['meta_correspondencia']),'356_accepted_pending_defers_conversion_and_hashes');
$lead['dados']['classificacao_contexto']='permitida';$reserved=F3Base_Aquisicoes::reservar($lead);
check(!empty($reserved['elegivel'])&&($reserved['event_id']??'')==='fixture-1630-event'&&($reserved['meta_correspondencia']??[])===$hash,'356_accepted_classified_response_hashes_same_event');
wp_set_current_user(1);
// Read-only diagnostic and permission gate.
$before=get_option('active_plugins');$r=F3Base_Desempenho::ler();check($r['ok']&&count($r['modulos'])>0&&get_option('active_plugins')===$before,'354_readonly_profile');wp_set_current_user(0);check(!F3Base_Desempenho::ler()['ok'],'354_anonymous_denied');wp_set_current_user(1);
// Native deactivate/reactivate schedules the first pass even with an existing long schedule.
$robots=F3Base_Options::ler('f3base_robots');$robots['ligado']=true;raw('f3base_robots',$robots);F3Base_Robots_Arquivo::suspender();$st=F3Base_Options::ler(F3Base_Robots_Arquivo::OPTION);check(!empty($st['suspenso'])&&!empty($st['suspenso_em']),'355_suspension_timestamp');
wp_clear_scheduled_hook(F3Base_Robots_Entrega::EVENTO);wp_schedule_single_event(time()+3600,F3Base_Robots_Entrega::EVENTO);F3Base_Site_Core::ativar();check(wp_next_scheduled(F3Base_Robots_Entrega::EVENTO)<=time()+2,'355_activation_advances_verification');
$http=static function($pre,$args,$url){if(!str_contains($url,'robots')){return $pre;}parse_str((string)wp_parse_url($url,PHP_URL_QUERY),$q);$body="User-agent: *\nDisallow:\n";$headers=['content-type'=>'text/plain'];if(isset($q['f3base_robots_sonda'])){$headers['x-f3base-robots-sonda']=$q['f3base_robots_sonda'];}else{if(is_file(ABSPATH.'robots.txt')){$body=file_get_contents(ABSPATH.'robots.txt');}}return ['response'=>['code'=>200],'headers'=>$headers,'body'=>$body];};add_filter('pre_http_request',$http,99999,3);
$r=F3Base_Robots_Entrega::verificar();check(!empty($r['ok']),'355_first_pass_verifies');$st=F3Base_Options::ler(F3Base_Robots_Arquivo::OPTION);check(empty($st['suspenso'])&&!empty($st['retomado_em'])&&($st['retomada_versao']??'')===F3BASE_PLUGIN_VERSAO,'355_resume_version_timestamp');check(!empty($st['retomada_confirmada_em']),'355_confirmation_timestamp');
remove_filter('pre_http_request',$http,99999);check(isset(F3Base_Saude::resumo()['robots_retomada']),'355_health_resume_marks');
evidence('request-353-355-356');
// Export the actual WordPress configuration for DOM execution.
wp_set_current_user(0);raw('f3base_meta_pixel_id','1234567890');$tracking=F3Base_Modulo_Tracking::dados_de_medicao();$tracking['meta']=['pixelId'=>'1234567890','modo'=>'ambos','autoConfig'=>false,'origem'=>'https://connect.facebook.net/en_US/fbevents.js'];
file_put_contents(getenv('F3BASE_ROOT').'/evidence/tracking-1630.json',wp_json_encode($tracking));

}finally{foreach($preserve as $n=>$v){if($v===null){delete_option($n);}else{raw($n,$v);}}}
