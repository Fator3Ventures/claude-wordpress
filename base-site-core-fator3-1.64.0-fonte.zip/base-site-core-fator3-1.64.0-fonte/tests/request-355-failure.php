<?php
require __DIR__.'/bootstrap.php';
$names=['f3base_robots',F3Base_Robots_Arquivo::OPTION,'f3base_avisos_tecnicos'];$before=[];foreach($names as $n){$before[$n]=get_option($n,null);}
$sent=0;$mail=static function($pre)use(&$sent){++$sent;return true;};$http=static fn()=>new WP_Error('fixture_failure');
try{
 raw('f3base_avisos_tecnicos',['email'=>'fixture@example.test']);$cfg=F3Base_Options::ler('f3base_robots');$cfg['ligado']=true;raw('f3base_robots',$cfg);
 add_filter('pre_wp_mail',$mail,99999);add_filter('pre_http_request',$http,99999);
 F3Base_Robots_Arquivo::suspender();$a=F3Base_Robots_Entrega::verificar();$b=F3Base_Robots_Entrega::verificar();
 check(empty($a['ok'])&&empty($b['ok']),'355_http_failure_remains_unverified');
 check($sent===1,'355_failure_one_technical_notice');
 $state=F3Base_Options::ler(F3Base_Robots_Arquivo::OPTION);check(($state['aviso_retomada']['estado']??'')==='tentado','355_notice_attempt_recorded');
 $cfg['ligado']=false;raw('f3base_robots',$cfg);F3Base_Robots_Arquivo::suspender();F3Base_Robots_Entrega::verificar();
 check(!empty(F3Base_Options::ler(F3Base_Robots_Arquivo::OPTION)['suspenso']),'355_disabled_generator_not_resumed');
 evidence('request-355-failure');
}finally{remove_filter('pre_wp_mail',$mail,99999);remove_filter('pre_http_request',$http,99999);foreach($before as $n=>$v){if($v===null){delete_option($n);}else{raw($n,$v);}}}
