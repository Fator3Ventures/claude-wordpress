import os,subprocess,json
from pathlib import Path
r=Path(__file__).resolve().parents[1]
results={}
for context in ['pagina','login','contexto']:
 x=subprocess.run([str(r/'build/php'),str(r/'tests/profile-1630.php')],env=dict(os.environ,F3BASE_PROFILE_CONTEXT=context),capture_output=True,text=True,check=True)
 results[context]=json.loads(x.stdout)
print(json.dumps({k:{'ms':v['total_proprio_ms'],'files':v['includes_core']} for k,v in results.items()}))
(r/'evidence/1630/profiles.json').write_text(json.dumps(results,indent=2))
