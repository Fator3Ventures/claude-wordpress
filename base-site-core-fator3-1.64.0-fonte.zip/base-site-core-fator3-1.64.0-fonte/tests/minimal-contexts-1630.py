import os, subprocess
from pathlib import Path
r=Path(__file__).resolve().parents[1]
for context in ['login','contexto']:
 subprocess.run([str(r/'build/php'),str(r/'tests/minimal-context-1630.php')],env=dict(os.environ,F3BASE_PROFILE_CONTEXT=context),check=True)
