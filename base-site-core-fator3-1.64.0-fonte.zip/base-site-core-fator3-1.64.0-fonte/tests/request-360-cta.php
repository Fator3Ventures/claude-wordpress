<?php
require __DIR__.'/bootstrap.php';
$before=get_option('f3base_contato');
$cases=[
 '<p>Texto sem links</p>',
 '<a href="/">Página normal</a>',
 '<div class="f3base-acao-contato"><a href="https://wa.me/5511999990000">Contato</a></div>',
 '<header><div class="f3base-acao-contato"><a href="/contato">Contato</a></div></header>',
 '<nav><a class="custom-cta" href="mailto:qa@example.test">Contato</a></nav>',
 '<a class="f3base-acao-cont&#97;to" href="/contato">Codificado</a>',
 '<A CLASS="f3base-acao-contato" HREF="/contato">Maiúsculas</A>',
 '<div class="f3base-superficie-flutuante"><a data-f3base-lead="contato" href="/contato">Ação</a></div>',
 '<button data-f3base-destino="/contato" class="f3base-acao-contato">Enviar</button>',
 '<a data-f3base-lead="contato" href="javascript:alert(1)">Inválido</a>',
 '<a href="https://wa.me/5511999990000">WhatsApp configurado</a>',
 '<a href="https://w&#97;.me/5511999990000">WhatsApp codificado</a>',
 '<a href="https://api.whatsapp.com/send?phone=5511999990000&amp;text=Ola">WhatsApp API</a>',
 '<div class="custom-cta"><span><a href="/contato">Aninhado</a></span></div>',
 '<p>f3base-acao-contato</p><a href="/normal">Não é uma classe</a>',
 '<div><a data-f3base-lead="contato" data-f3base-superficie="menu" data-f3base-superficie-inferida="1" href="/contato">Menu</a></div>'
];
try{
 foreach([false,true] as $enabled){raw('f3base_contato',array_replace(F3Base_Options::ler('f3base_contato'),['classes_cta'=>['custom-cta'],'carimbar_whatsapp_por_destino'=>$enabled,'whatsapp_e164'=>'5511999990000']));foreach($cases as $i=>$html){foreach(['conteudo','cabecalho'] as $surface){$legacy=QA_Cta_Legacy::carimbar_cta($html,$surface);$actual=F3Base_Servicos::carimbar_cta($html,$surface);check($legacy===$actual,'360_cta_parity_'.(int)$enabled.'_'.$i.'_'.$surface);}}}
 evidence('request-360-cta');
}finally{if($before===false)delete_option('f3base_contato');else raw('f3base_contato',$before);}
final class QA_Cta_Legacy {
    public static function carimbar_cta( string $html, string $superficie_padrao='conteudo' ): string {
        if ( ! class_exists( 'WP_HTML_Processor' ) ) { return $html; }
        $classes = array_merge( array( 'f3base-acao-contato' ), (array) ( F3Base_Options::ler( 'f3base_contato' )['classes_cta'] ?? array() ) );
        $p = WP_HTML_Processor::create_fragment( $html );
        if ( ! $p ) { return $html; }
        $contextos = array();
        while ( $p->next_tag( array( 'tag_closers'=>'visit' ) ) ) {
            if ( $p->is_tag_closer() ) { continue; }
            $depth = $p->get_current_depth();
            foreach ( array_keys( $contextos ) as $d ) { if ( $d >= $depth ) { unset( $contextos[$d] ); } }
            if ( $p->is_tag_closer() ) { continue; }
            $contexto = $contextos ? end( $contextos ) : array( 'cta'=>false, 'superficie'=>$superficie_padrao );
            foreach ( $classes as $cl ) { if ( $p->has_class( $cl ) ) { $contexto['cta'] = true; } }
            $inferida=$p->get_attribute('data-f3base-superficie-inferida')==='1';$superficie = $inferida?null:$p->get_attribute( 'data-f3base-superficie' );
            if(!in_array($superficie,array('conteudo','menu','flutuante','cabecalho','barra_fixa'),true)){foreach(array('conteudo','menu','flutuante','cabecalho','barra_fixa') as $nome){if($p->has_class('f3base-superficie-'.$nome)){$superficie=$nome;break;}}}
            if(is_string($superficie)&&in_array($superficie,array('conteudo','menu','flutuante','cabecalho','barra_fixa'),true)){$contexto['declarada']=true;}

            if ( is_string( $superficie ) && in_array( $superficie, array( 'conteudo','menu','flutuante','cabecalho','barra_fixa' ), true ) ) { $contexto['superficie']=$superficie; }
            elseif(empty($contexto['declarada'])&&'HEADER'===$p->get_tag()){$contexto['superficie']='cabecalho';}
            elseif ( empty($contexto['declarada']) && ( 'NAV' === $p->get_tag() || $p->has_class( 'menu-item' ) || $p->has_class('wp-block-navigation-link') || $p->has_class('wp-block-navigation-submenu') ) ) { $contexto['superficie']='menu'; }
            $contextos[$depth] = $contexto;
            if ( ! in_array( $p->get_tag(), array( 'A','BUTTON' ), true ) ) { continue; }
            $destino = $p->get_attribute( 'data-f3base-destino' );
            if ( null === $destino ) { $destino = $p->get_attribute( 'href' ); }
            if(!is_string($destino)){continue;}$acao=F3Base_Leads_Contexto::destino($destino);
            if(!$acao['valido']){$p->remove_attribute('data-f3base-lead');continue;}
            if($p->get_attribute('data-f3base-lead')===null&&($contexto['cta']||F3Base_Leads_Contexto::whatsapp_configurado($destino))){$p->set_attribute('data-f3base-lead',$acao['tipo']==='whatsapp'?'whatsapp':'contato');}
            if ( $p->get_attribute( 'data-f3base-lead' ) !== null && ($p->get_attribute( 'data-f3base-superficie' ) === null || $inferida) ) { $old=$p->get_attribute('data-f3base-superficie');if(empty($contexto['declarada'])&&$contexto['superficie']==='conteudo'&&in_array($old,array('menu','cabecalho','barra_fixa','flutuante','elementor'),true)){$contexto['superficie']=$old;}$p->set_attribute( 'data-f3base-superficie', $contexto['superficie'] );$p->set_attribute('data-f3base-superficie-inferida','1'); }
        }
        return $p->get_updated_html();
    }

}
