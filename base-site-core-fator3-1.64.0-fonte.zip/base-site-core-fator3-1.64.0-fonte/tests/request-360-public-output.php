<?php
require __DIR__.'/bootstrap.php';
$cases=[[],['z'=>1,'a'=>['y'=>[3,1,2],'b'=>null]],['campos'=>[['tipo'=>'tel','nome'=>'telefone'],['nome'=>'nome','tipo'=>'text']],'ligado'=>true]];
foreach($cases as $i=>$value){$legacy=hash('sha256',(string)wp_json_encode(F3Base_Auditoria::ordenar($value)));check(F3Base_Formularios::revisao($value)===$legacy&&F3Base_Leads_Repositorio::hash($value)===$legacy,'360_form_hash_legacy_'.$i);}
$html=F3Base_Formularios::iscas_html();foreach(['website','comentario','segmento_atuacao','ctodesenvolvimentofator3'] as $name)check(str_contains($html,'name="'.$name.'"'),'360_honeypot_preserved_'.$name);
check(F3Base_Formularios::telefone_livre(['papel'=>'telefone','formato_livre'=>true])&&!F3Base_Formularios::telefone_livre(['papel'=>'contato','formato_livre'=>true]),'360_phone_format_rule');
F3Base_Perfil_Publico::atualizar(false);$before=F3Base_Cache_Pagina::contexto();$state=F3Base_Cache_Pagina::estado();$catalog=0;add_action('f3base_perfil_catalogo',static function()use(&$catalog){$catalog++;});
$property=new ReflectionProperty(F3Base_Perfil_Publico::class,'ativo');$property->setValue(null,true);
try{check(F3Base_Cache_Pagina::contexto()===$before&&F3Base_Cache_Pagina::estado()===$state,'360_public_cache_marker_same');check($catalog===0,'360_public_cache_without_catalog');}finally{F3Base_Perfil_Publico::completo();}
evidence('request-360-public-output');
