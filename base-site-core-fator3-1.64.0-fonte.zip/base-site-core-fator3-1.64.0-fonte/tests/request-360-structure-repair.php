<?php putenv('F3BASE_STRUCTURE_MODE=repair');require __DIR__.'/request-360-structure.php';
