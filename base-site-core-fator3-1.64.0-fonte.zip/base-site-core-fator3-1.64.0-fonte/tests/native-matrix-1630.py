"""Run the exact installer on the two locally supplied WP runtimes, sequentially."""
import os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parents[1]
for tag,lab in [('713',r/'lab'),('712',r/'lab-minimum')]:
 env=dict(os.environ,F3BASE_LAB_DIR=str(lab),F3BASE_SITE=str(lab/'wordpress/wp-load.php'),F3BASE_LAB_DB='core_1630_final_'+tag+'_'+str(int(time.time())),F3BASE_EVIDENCE_DIR='evidence/1630'+('/minimum' if tag=='712' else ''))
 subprocess.run([sys.executable,str(r/'tests/native-cycles.py')],env=env,check=True)
