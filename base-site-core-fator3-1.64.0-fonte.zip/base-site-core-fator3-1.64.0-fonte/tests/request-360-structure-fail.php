<?php putenv('F3BASE_STRUCTURE_MODE=fail');require __DIR__.'/request-360-structure.php';
