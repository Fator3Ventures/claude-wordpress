<?php
require __DIR__.'/bootstrap.php';
foreach(F3Base_Registro::instanciar() as $m){check($m->deve_registrar()===($m->estado()['estado']!==F3Base_Modulo::INATIVO),'354_registration_matches_health_'.$m->id());}
$before=[];foreach(['f3base_comportamento','f3base_robots','f3base_llms','f3base_acessos'] as $n){$before[$n]=get_option($n,null);$v=F3Base_Options::ler($n);$v['ligado']=false;raw($n,$v);}
try{foreach(F3Base_Registro::classes() as $class){$m=new $class();check($m->deve_registrar()===($m->estado()['estado']!==F3Base_Modulo::INATIVO),'354_disabled_matches_health_'.$m->id());}}finally{foreach($before as $n=>$v){if($v===null){delete_option($n);}else{raw($n,$v);}}}
evidence('eligibility-1630');
