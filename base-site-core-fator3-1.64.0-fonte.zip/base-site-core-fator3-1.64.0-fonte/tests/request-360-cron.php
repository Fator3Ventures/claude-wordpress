<?php
require __DIR__.'/bootstrap.php';
$old=get_option(F3Base_Zelador::ESTADO);$cron=get_option('cron');
try{
 update_option(F3Base_Zelador::ESTADO,['ultima_cli'=>time(),'run_id'=>'qa360'],true);
 $at=time()-1;$jobs=[$at=>[]];foreach(['f3base_llms_converter_lote','wp_update_plugins','f3base_avisos_processar','f3base_pipedrive_processar','other_plugin_tick','f3base_operacao_retomar','f3base_operacao_urgente'] as $hook){$jobs[$at][$hook]=['event'=>['schedule'=>false,'args'=>[]]];}
 $r=F3Base_Zelador::filtrar($jobs);check(!isset($r[$at]['f3base_llms_converter_lote'])&&!isset($r[$at]['wp_update_plugins']),'360_routine_core_and_wp_removed');check(isset($r[$at]['f3base_avisos_processar'],$r[$at]['f3base_pipedrive_processar'],$r[$at]['other_plugin_tick']),'360_urgent_and_other_kept');
 check(!isset($r[$at]['f3base_operacao_retomar'])&&isset($r[$at]['f3base_operacao_urgente']),'360_separate_dispatchers');
 $optin=static fn($hooks)=>array_merge($hooks,['other_plugin_tick']);add_filter('f3base_cron_rotina',$optin);$r=F3Base_Zelador::filtrar($jobs);check(!isset($r[$at]['other_plugin_tick']),'360_other_requires_optin');remove_filter('f3base_cron_rotina',$optin);
 update_option(F3Base_Zelador::ESTADO,['ultima_cli'=>time()-3601,'iniciado_em'=>time()-7200],true);check(F3Base_Zelador::filtrar($jobs)===$jobs,'360_failover_after_hour');
 // Full maintenance is authorized here, with provider traffic blocked by the lab.
 wp_clear_scheduled_hook('f3base_servidor_reverificar');F3Base_Zelador::executar(true);$state=get_option(F3Base_Zelador::ESTADO);check(!empty($state['reserva_aviso']),'360_failover_attention_reserved');F3Base_Zelador::executar(true);check(get_option(F3Base_Zelador::ESTADO)['reserva_aviso']===$state['reserva_aviso'],'360_attention_once');
 check(wp_next_scheduled(F3Base_Servidor::EVENTO)!==false,'360_deleted_schedule_recovered');
 update_option(F3Base_Zelador::ESTADO,['ultima_cli'=>time(),'run_id'=>'qa360-next'],true);check(!isset(F3Base_Zelador::filtrar($jobs)[$at]['f3base_llms_converter_lote']),'360_next_cli_restores_filter');
 evidence('request-360-cron');
}finally{update_option(F3Base_Zelador::ESTADO,$old,true);update_option('cron',$cron,true);}
