<?php
$mode=getenv('F3BASE_PROFILE_CONTEXT');
if($mode==='login'){$GLOBALS['pagenow']='wp-login.php';$_SERVER['PHP_SELF']='/wp-login.php';$_SERVER['SCRIPT_NAME']='/wp-login.php';}
else{$_SERVER['REQUEST_URI']='/wp-json/f3base/v1/contexto-publico';}
require __DIR__.'/bootstrap.php';
check(F3Base_Desempenho::resumo()['includes_core']<25,'minimal_bootstrap');
check(apply_filters('auth_cookie_expiration',7200,1,false)===7200,'ordinary_session_preserved');
check(apply_filters('auth_cookie_expiration',7200,1,true)===365*DAY_IN_SECONDS,'remembered_admin_session');
if($mode!=='login'){
    wp_set_current_user(0);$r=rest_do_request(new WP_REST_Request('GET','/f3base/v1/contexto-publico'));
    check($r->get_status()===200&&!$r->get_data()['excluida'],'public_context_dispatch');
    check(str_contains($r->get_headers()['Cache-Control']??'','no-store'),'public_context_not_cached');
    wp_set_current_user(1);$r=rest_do_request(new WP_REST_Request('GET','/f3base/v1/contexto-publico'));
    check($r->get_status()===200&&$r->get_data()['excluida'],'editor_context_dispatch');
}
wp_get_abilities();
check(wp_get_ability('f3base/config-core-contrato-v1')!==null,'full_ability_registration_after_lazy_context');
check(wp_get_ability('f3base/desempenho-ler')!==null,'profile_ability_after_lazy_context');
evidence('minimal-'.$mode.'-1630');
