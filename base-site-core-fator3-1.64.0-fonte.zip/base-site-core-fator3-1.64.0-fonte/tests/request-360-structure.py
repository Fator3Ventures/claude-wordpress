import os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
for mode in ['fail','repair']:
 subprocess.run([str(root/'build/php'),str(root/'tests/request-360-structure.php')],env=dict(os.environ,F3BASE_STRUCTURE_MODE=mode),check=True)
