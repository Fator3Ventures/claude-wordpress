<?php
require __DIR__.'/bootstrap.php';require_once ABSPATH.'wp-admin/includes/plugin.php';
foreach(['wp-mcp-fator3/wp-mcp-fator3.php','wp-mcp-google-fator3/wp-mcp-google-fator3.php','wp-mcp-meta-fator3/wp-mcp-meta-fator3.php','wp-mcp-linkedin-fator3/wp-mcp-linkedin-fator3.php'] as $name){$r=activate_plugin($name);if(is_wp_error($r)){throw new RuntimeException($name.': '.$r->get_error_message());}}
echo "Companions active; no provider HTTP or mail.\n";
