<?php
// Read-only call-stack observation in the disposable laboratory. No provider calls.
$_SERVER['HTTP_HOST']='127.0.0.1:8134';$_SERVER['PHP_SELF']='/wp-login.php';$_SERVER['SCRIPT_NAME']='/wp-login.php';$GLOBALS['pagenow']='wp-login.php';
require_once dirname(getenv('F3BASE_SITE')).'/wp-includes/plugin.php';
$trace=[];
add_action('wp_abilities_api_categories_init',static function()use(&$trace){foreach(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,20) as $f){$trace[]=($f['class']??'').($f['type']??'').($f['function']??'');}},-100);
require __DIR__.'/bootstrap.php';
check(in_array('Fator3\\McpFiles\\MutationServiceAudit::initialize',$trace,true),'mcp_wp_loaded_initializes_ability_catalog_on_login');
check(in_array('wp_get_abilities',$trace,true),'native_ability_registry_requested');
file_put_contents(getenv('F3BASE_ROOT').'/evidence/1630/mcp-bootstrap-trace.json',wp_json_encode(['trace'=>$trace,'profile'=>F3Base_Desempenho::resumo()],JSON_PRETTY_PRINT));
evidence('mcp-bootstrap-trace-1630');
