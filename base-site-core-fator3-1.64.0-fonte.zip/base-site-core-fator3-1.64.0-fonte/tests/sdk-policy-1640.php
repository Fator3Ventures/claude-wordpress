<?php
require __DIR__.'/bootstrap.php';
// Explicit synthetic connection policy in the disposable test database only.
\Fator3\McpFiles\Persistence::put('connections','integration:user:1',['user_id'=>1,'connection_id'=>'integration:user:1','profile'=>'maintenance','status'=>'active','policy_version'=>1,'time'=>time(),'expires'=>0],true);
echo "Local synthetic maintenance profile for native ability regression tests.\n";
