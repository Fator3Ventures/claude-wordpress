<?php
require __DIR__.'/bootstrap.php';
$recoveryBefore=F3Base_Recuperacao::ler()['entrada_requisicao'];$calls=0;$sql=[];$watch=static function($q)use(&$sql){$sql[]=$q;return $q;};$key='schema:qa360:'.wp_generate_uuid4();
$generate=static function()use(&$calls){$calls++;return ['@type'=>'Service','name'=>'QA 360'];};add_filter('query',$watch);
$a=F3Base_Modulo_Cache_Publico::lembrar($key,$generate);$b=F3Base_Modulo_Cache_Publico::lembrar($key,$generate);wp_cache_flush_runtime();$c=F3Base_Modulo_Cache_Publico::lembrar($key,$generate);remove_filter('query',$watch);
check($calls===1&&$a===$b&&$b===$c,'360_schema_cache_reused_across_runtime_cache_reset');check(!array_filter($sql,static fn($q)=>preg_match('/^\s*(SHOW|UPDATE|INSERT|ALTER|CREATE)/i',$q)),'360_schema_cache_no_structure_or_write');check((F3Base_Recuperacao::ler()['entrada_requisicao']??'')===$recoveryBefore,'360_schema_does_not_enter_recovery');
$queries=[];add_filter('query',$watch);$before=F3Base_Modulo_Cache_Publico::geracao();$after=F3Base_Modulo_Cache_Publico::geracao();remove_filter('query',$watch);check($before===$after,'360_generation_request_memo');
evidence('request-360-cache');
