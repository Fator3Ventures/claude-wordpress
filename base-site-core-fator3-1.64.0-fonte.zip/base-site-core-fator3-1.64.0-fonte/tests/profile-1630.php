<?php
$_SERVER['HTTP_HOST']='127.0.0.1:8134';$_SERVER['REQUEST_URI']='/';$_SERVER['REQUEST_TIME_FLOAT']=microtime(true);
if(getenv('F3BASE_PROFILE_CONTEXT')==='login'){$GLOBALS['pagenow']='wp-login.php';$_SERVER['PHP_SELF']='/wp-login.php';$_SERVER['SCRIPT_NAME']='/wp-login.php';}elseif(getenv('F3BASE_PROFILE_CONTEXT')==='contexto'){$_SERVER['REQUEST_URI']='/wp-json/f3base/v1/contexto-publico';}
require getenv('F3BASE_SITE');
$r=F3Base_Desempenho::resumo();echo wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";
