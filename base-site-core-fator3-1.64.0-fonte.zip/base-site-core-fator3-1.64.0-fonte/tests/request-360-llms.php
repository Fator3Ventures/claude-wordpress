<?php
require __DIR__.'/bootstrap.php';
$ids=get_posts(['post_type'=>'page','post_status'=>'publish','numberposts'=>48,'fields'=>'ids','meta_key'=>'qa360']);check(count($ids)===48,'360_llms_fixture_48');$id=end($ids);$original=get_post($id);$oldMeta=get_post_meta($id,'_yoast_wpseo_meta-robots-noindex',true);
function qa360_generate(){for($n=0;$n<15;$n++){$r=F3Base_Llms_Cobertura::executar(10,$n===0);if(empty($r['restantes']))return $r;}return $r;}
function qa360_item($id){$g=get_option(F3Base_Llms_Cobertura::PUBLICADA);return current(array_filter($g['itens']??[],static fn($i)=>(int)($i['id']??0)===$id))?:[];}
qa360_generate();check(isset(get_option('f3base_llms_mapa')['itens'][$id]),'360_selected_has_discovery');
try{
 foreach(['password','noindex','trash'] as $kind){
  $item=qa360_item($id);
  if($kind==='password')wp_update_post(['ID'=>$id,'post_password'=>'synthetic-restriction']);
  elseif($kind==='noindex')update_post_meta($id,'_yoast_wpseo_meta-robots-noindex','1');
  else wp_trash_post($id);
  check(!isset(get_option('f3base_llms_mapa')['itens'][$id]),'360_'.$kind.'_immediate_map');check(empty(F3Base_Llms_Cobertura::item($item)['completo']),'360_'.$kind.'_immediate_representation');
  wp_update_post(['ID'=>$id,'post_password'=>'','post_status'=>'publish']);delete_post_meta($id,'_yoast_wpseo_meta-robots-noindex');qa360_generate();
 }
 $new=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'QA new selected item','post_content'=>'<h2>Novo conteúdo público</h2><p>Fixture sintética.</p>']);$start=time();check(!isset(get_option('f3base_llms_mapa')['itens'][$new]),'360_new_not_prematurely_advertised');
 $signature=get_option('f3base_llms_assinatura');check(!empty($signature['pendente'])||!empty(wp_next_scheduled(F3Base_Llms_Cobertura::EVENTO)),'360_new_pending_generation');qa360_generate();
 check(isset(get_option('f3base_llms_mapa')['itens'][$new])&&time()-$start<3600,'360_new_completed_before_one_hour');
 $GLOBALS['wp_query']=new WP_Query(['page_id'=>$id]);$m=new F3Base_Modulo_Llms_Markdown();ob_start();$m->descoberta();$head=ob_get_clean();check(str_contains($head,'text/markdown')&&str_contains($head,esc_url(get_option('f3base_llms_mapa')['itens'][$id])),'360_alternate_link_parity');
 wp_update_post(['ID'=>$id,'post_status'=>'private']);ob_start();$m->descoberta();$head=ob_get_clean();check(!str_contains($head,'text/markdown'),'360_no_link_outside_selection');
 evidence('request-360-llms');
}finally{
 wp_update_post(['ID'=>$id,'post_status'=>$original->post_status,'post_password'=>$original->post_password]);if($oldMeta==='')delete_post_meta($id,'_yoast_wpseo_meta-robots-noindex');else update_post_meta($id,'_yoast_wpseo_meta-robots-noindex',$oldMeta);if(!empty($new))wp_delete_post($new,true);qa360_generate();wp_reset_query();
}
