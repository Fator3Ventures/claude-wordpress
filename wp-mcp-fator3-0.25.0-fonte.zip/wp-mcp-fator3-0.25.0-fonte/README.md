# Fator3 MCP 0.25.0

A versão 0.25.0 implementa o pedido MCP 62: administração por assunto, seletores pesquisáveis, filtros de data/resultado e canal de atualização exclusivo do MCP. Consulte docs/ADMINISTRACAO.md e docs/RELEASE-0250.md.

Servidor MCP independente para WordPress. Instalação limpa ou atualização direta da 0.23.0. Requer WordPress 7.1.2 e PHP 8.3.6.

Esta versão corrige o Pedido MCP 61: cache_bypass_verified booleano é preservado nas sondas de instalação e na projeção pública. A documentação instalada está disponível em system/guide, com lista, paginação por bytes e revisão/hash.

- Runtime: fontes/wp-mcp-fator3/. Identidade wp-mcp-fator3/wp-mcp-fator3.php.
- Operação e contratos: docs/OPERACAO.md e docs/RELEASE-0240.md.
- Build: python tools/sync_docs.py; python tools/build_packages.py.
- Testes e limitações: tools/release0240/README.md e relatório externo.
- Evidências próprias: evidencias/0240/. Diretórios anteriores são históricos.

Contratos server-integration/1.0.0, executor-registration/1.0.0 e package-distribution/1.0.0 mantidos. Nenhuma publicação automática de fonte, feed ou instalador. Tokens reais e bancos privados não integram o pacote.
