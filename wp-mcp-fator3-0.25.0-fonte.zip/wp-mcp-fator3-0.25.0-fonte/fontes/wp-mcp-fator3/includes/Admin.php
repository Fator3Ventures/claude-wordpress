<?php
/** Unified settings UI. Operational status is supplied by ConnectionStatus. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Admin {
    private const SLUG = 'wp-mcp-fator3';
    public static function init(): void {
        add_action('admin_menu', [self::class, 'menu']);
        add_action('admin_enqueue_scripts', [self::class, 'assets']);
        add_action('admin_post_f3_mcp_save', [self::class, 'handle_save']);
        add_action('admin_post_f3_mcp_file_limit', [self::class, 'handle_file_limit']);
        add_action('admin_post_f3_mcp_sql_retention', [self::class, 'handle_retention']);
        add_action('admin_post_f3_mcp_files_toggle', [self::class, 'handle_toggle']);
        add_action('admin_post_f3_mcp_db_toggle', [self::class, 'handle_db_toggle']);
    }
    public static function menu(): void { add_management_page('Fator3 MCP', 'Fator3 MCP', 'manage_options', self::SLUG, [self::class, 'render']); }
    public static function url(string $tab = 'connection'): string { return add_query_arg(['page' => self::SLUG, 'tab' => $tab], admin_url('tools.php')); }
    public static function forced_by_filter(): bool { return (bool)has_filter('f3_mcp_files_enabled'); }
    public static function hard_block(): bool { return (defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS); }
    public static function assets(string $hook): void {
        if (!in_array($hook, ['tools_page_wp-mcp-fator3','tools_page_wp-mcp-ultimate'], true)) return;
        $base = plugin_dir_url(F3_MCP_FILES_DIR . 'wp-mcp-fator3.php') . 'core/assets/';
        wp_enqueue_style('f3-mcp-admin', $base . 'css/admin.css', [], F3_MCP_FILES_VERSION);
        wp_enqueue_script('f3-mcp-admin', $base . 'js/admin.js', [], F3_MCP_FILES_VERSION, true);
        wp_localize_script('f3-mcp-admin', 'f3McpAdmin', ['ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('wp-mcp-ultimate'), 'endpoint' => ConnectionEndpoints::url()]);
    }
    public static function save(string $section, bool $enable): array {
        if (!current_user_can('manage_options')) return Result::fail('permission_denied', 'Permissão insuficiente.');
        if (!in_array($section, ['channel','database'], true)) return Result::fail('invalid_section', 'Seção inválida.');
        if ('channel' === $section && $enable && self::hard_block()) return Result::fail('channel_blocked', 'O canal está bloqueado pelo wp-config.php.');
        $option = 'channel' === $section ? PathGuard::OPTION_ENABLED : Database::OPTION_WRITES;
        $result = Locks::run(['option:' . get_current_blog_id() . ':' . $option => LOCK_EX], static fn() => VerifiedOptions::update($option, ['value' => $enable ? '1' : '0']));
        $effective = 'channel' === $section ? PathGuard::is_enabled() : (PathGuard::is_enabled() && Database::writes_enabled());
        $result['effective'] = $effective;
        $result['overridden'] = $effective !== $enable;
        $result['message'] = empty($result['success']) ? 'Não foi possível salvar a configuração. Confira o estado atual e tente novamente.' : ($result['overridden'] ? 'Preferência salva. O estado efetivo depende das restrições indicadas nesta seção.' : (!empty($result['changed']) ? 'Configurações salvas.' : 'Nenhuma alteração necessária.'));
        Audit::record('admin/settings', ['name' => $section], $result, 0);
        return $result;
    }
    private static function submit(string $nonce, ?string $section = null): void {
        if (!current_user_can('manage_options')) wp_die('Permissão insuficiente.', '', ['response' => 403]);
        check_admin_referer($nonce);
        $section = $section ?? (isset($_POST['section']) && is_string($_POST['section']) ? sanitize_key(wp_unslash($_POST['section'])) : '');
        $enable = isset($_POST['enable']) && '1' === $_POST['enable'];
        $result = self::save($section, $enable);
        $key = wp_generate_uuid4();
        set_transient('f3_mcp_notice_' . get_current_user_id() . '_' . $key, ['success' => $result['success'], 'message' => $result['message']], 60);
        wp_safe_redirect(add_query_arg('notice', $key, self::url('files')));
        exit;
    }
    public static function handle_retention(): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_sql_retention');$policy=[];
        foreach(['older_than_days','max_count','min_keep'] as $k){$raw=$_POST[$k]??null;$policy[$k]=is_string($raw)&&ctype_digit($raw)?(int)$raw:-1;}
        $revision=is_string($_POST['revision']??null)?wp_unslash($_POST['revision']):'';
        $result=Locks::run(['channel-settings'=>LOCK_EX],static function()use($policy,$revision){
            if(!SqlArtifacts::valid_policy($policy))return Result::fail('artifact_policy_invalid','Use idade de 1 a 3650 dias, quantidade de 1 a 10000 e mínimo entre zero e a quantidade.');
            if(!hash_equals(hash('sha256',serialize(SqlArtifacts::policy())),$revision))return Result::fail('settings_conflict','A política mudou. Recarregue a página antes de salvar.');
            return VerifiedOptions::update('f3_mcp_sql_retention',['value'=>$policy]);
        });
        Audit::record('admin/sql-retention',[],$result,0);$key=wp_generate_uuid4();
        set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$key,['success'=>!empty($result['success']),'message'=>!empty($result['success'])?'Política salva. A exclusão continua exigindo prévia e confirmação.':($result['message']??'Não foi possível salvar.')],60);
        wp_safe_redirect(add_query_arg('notice',$key,self::url('files')));exit;
    }
    public static function handle_save(): void { self::submit('f3_mcp_settings'); }
    public static function handle_toggle(): void { self::submit('f3_mcp_files_toggle', 'channel'); }
    public static function handle_db_toggle(): void { self::submit('f3_mcp_db_toggle', 'database'); }
    public static function badge(bool $ok, string $yes, string $no): void { echo '<span class="f3-badge ' . ($ok ? 'is-ok' : 'is-muted') . '">' . esc_html($ok ? $yes : $no) . '</span>'; }

    /** UI formatting only: stored protocol identifiers remain unchanged. */
    public static function nonce(string $action): void {
        static $number=0;++$number;
        echo str_replace('id="_wpnonce"','id="f3-nonce-'.esc_attr($action).'-'.$number.'"',wp_nonce_field($action,'_wpnonce',false,false));
    }
    public static function states(): array { return ['pending'=>'Pendente','running'=>'Em andamento','paused'=>'Pausado','complete'=>'Concluído','failed'=>'Falhou','cancelled'=>'Cancelado','compensated'=>'Revertido por compensação','compensation_incomplete'=>'Compensação incompleta']; }
    public static function state(string $state): string { return self::states()[$state] ?? 'Estado não reconhecido'; }
    public static function profile(string $profile): string { return ['read'=>'Leitura','content'=>'Conteúdo','maintenance'=>'Manutenção','custom'=>'Personalizado'][$profile] ?? 'Sem acesso'; }
    public static function date($value): string { $time=is_numeric($value)?(int)$value:strtotime((string)$value);return $time?gmdate('d/m/Y H:i:s',$time).' UTC':'Não informado'; }
    public static function help(string $id,string $text): void { echo '<p class="description" id="'.esc_attr($id).'">'.esc_html($text).'</p>'; }
    public static function ability_label(string $id): string {
        $ability=wp_get_ability($id);if(!$ability)return 'Habilidade indisponível';
        $labels=[
            'menus/add-item'=>'Adicionar item de menu',
            'menus/assign-location'=>'Definir localização do menu',
            'menus/get-items'=>'Consultar itens do menu',
            'menus/update-item'=>'Atualizar item de menu',
            'menus/delete-item'=>'Excluir item de menu',
            'menus/list'=>'Listar menus',
            'menus/create'=>'Criar menu',
            'menus/delete'=>'Excluir menu',
            'files/archive'=>'Compactar arquivos',
            'files/copy'=>'Copiar arquivo',
            'files/upload-cancel'=>'Cancelar envio de arquivo',
            'files/upload-create'=>'Iniciar envio de arquivo',
            'files/upload-status'=>'Consultar envio de arquivo',
            'files/upload-finalize'=>'Concluir envio de arquivo',
            'files/upload-part'=>'Enviar parte de arquivo',
            'files/extract'=>'Extrair arquivos',
            'files/mkdir'=>'Criar diretório',
            'files/move'=>'Mover arquivo',
            'files/search'=>'Pesquisar arquivos',
            'files/rollback-tree'=>'Restaurar árvore de arquivos',
            'files/stat'=>'Consultar informações do arquivo',
            'files/delete'=>'Excluir arquivo ou diretório vazio',
            'files/fetch'=>'Baixar arquivo de endereço remoto',
            'files/write'=>'Gravar arquivo',
            'files/read'=>'Ler arquivo',
            'files/backups'=>'Listar backups de arquivos',
            'files/list'=>'Listar arquivos',
            'files/patch'=>'Aplicar alterações em arquivo',
            'files/restore'=>'Restaurar backup de arquivo',
            'files/selftest'=>'Testar canal de arquivos',
            'plugins/activate'=>'Ativar plugin',
            'plugins/deactivate'=>'Desativar plugin',
            'plugins/install'=>'Instalar plugin',
            'plugins/delete'=>'Excluir plugin',
            'plugins/list'=>'Listar plugins',
            'plugins/update'=>'Atualizar plugin',
            'plugins/upload'=>'Enviar pacote de plugin',
            'plugins/upload-base64'=>'Enviar plugin por arquivo ou Base64',
            'plugins/operation-status'=>'Consultar operação de plugin',
            'plugins/reconcile'=>'Reconciliar operação de plugin',
            'plugins/rollback'=>'Restaurar versão do plugin',
            'plugins/cleanup-orphaned-uninstall'=>'Limpar registro órfão de desinstalação',
            'content/create-post'=>'Criar publicação',
            'content/update-post'=>'Atualizar publicação',
            'content/get-post'=>'Consultar publicação',
            'content/delete-post'=>'Excluir publicação',
            'content/list-posts'=>'Listar publicações',
            'content/patch-post'=>'Aplicar alterações em publicação',
            'content/create-page'=>'Criar página',
            'content/update-page'=>'Atualizar página',
            'content/get-page'=>'Consultar página',
            'content/delete-page'=>'Excluir página',
            'content/list-pages'=>'Listar páginas',
            'content/patch-page'=>'Aplicar alterações em página',
            'content/list-media'=>'Listar mídias',
            'content/list-users'=>'Listar usuários',
            'content/create-category'=>'Criar categoria',
            'content/list-categories'=>'Listar categorias',
            'content/create-tag'=>'Criar etiqueta',
            'content/list-tags'=>'Listar etiquetas',
            'content/get-revision'=>'Consultar revisão',
            'content/list-revisions'=>'Listar revisões',
            'content/restore-revision'=>'Restaurar revisão',
            'content/get-meta'=>'Consultar metadados',
            'content/update-meta'=>'Atualizar metadados',
            'content/delete-meta'=>'Excluir metadados',
            'content/get-seo'=>'Consultar SEO',
            'content/update-seo'=>'Atualizar SEO',
            'content/update-term'=>'Atualizar termo',
            'content/delete-term'=>'Excluir termo',
            'content/blocks'=>'Consultar blocos',
            'content/edit-block'=>'Editar bloco',
            'content/diff'=>'Comparar conteúdo',
            'content/upsert'=>'Criar ou atualizar conteúdo',
            'content/untrash'=>'Restaurar conteúdo da lixeira',
            'content/search'=>'Pesquisar conteúdo',
            'content/deduplicate-seo-indexables'=>'Remover índices SEO duplicados',
            'content/delete-orphan-seo-indexable'=>'Excluir índice SEO órfão',
            'comments/list'=>'Listar comentários',
            'comments/get'=>'Consultar comentário',
            'comments/create'=>'Criar comentário',
            'comments/delete'=>'Excluir comentário',
            'comments/update-status'=>'Atualizar estado do comentário',
            'comments/reply'=>'Responder comentário',
            'users/list'=>'Listar usuários com detalhes',
            'users/get'=>'Consultar usuário',
            'users/create'=>'Criar usuário',
            'users/update'=>'Atualizar usuário',
            'users/delete'=>'Excluir usuário',
            'media/get'=>'Consultar mídia',
            'media/update'=>'Atualizar mídia',
            'media/delete'=>'Excluir mídia',
            'media/upload'=>'Enviar mídia',
            'media/regenerate'=>'Regenerar tamanhos de mídia',
            'media/set-site-icon'=>'Definir ícone do site',
            'options/get'=>'Consultar opção',
            'options/list'=>'Listar opções',
            'options/update'=>'Atualizar opção',
            'options/delete'=>'Excluir opção',
            'connections/list'=>'Listar conexões',
            'connections/update'=>'Atualizar conexão',
            'connections/revoke'=>'Revogar conexão',
            'audit/list'=>'Listar registro de auditoria',
            'audit/prune'=>'Limpar registro de auditoria',
            'backups/list'=>'Listar cópias de segurança',
            'backups/export'=>'Exportar cópia de segurança',
            'backups/export-part'=>'Exportar parte de cópia de segurança',
            'backups/prune'=>'Limpar cópias de segurança',
            'db/query'=>'Consultar banco de dados',
            'db/schema'=>'Consultar estrutura do banco',
            'db/execute'=>'Alterar banco com prévia e confirmação',
            'db/batch'=>'Executar lote no banco',
            'db/query-export'=>'Exportar consulta',
            'db/query-page'=>'Consultar página de resultados',
            'db/export'=>'Exportar banco',
            'db/export-cancel'=>'Cancelar exportação do banco',
            'db/export-part'=>'Exportar parte do banco',
            'db/search-replace'=>'Pesquisar e substituir no banco',
            'db/recovery-status'=>'Consultar recuperação do banco',
            'db/restore'=>'Restaurar banco',
            'operations/apply'=>'Aplicar plano',
            'operations/assert'=>'Verificar condição do plano',
            'operations/cancel'=>'Cancelar plano',
            'operations/status'=>'Consultar estado do plano',
            'operations/list'=>'Listar planos',
            'operations/plan'=>'Planejar operação',
            'operations/preview'=>'Visualizar prévia do plano',
            'cron/list'=>'Listar tarefas agendadas',
            'cron/run'=>'Executar tarefa agendada',
            'cron/schedule'=>'Agendar tarefa',
            'cron/unschedule'=>'Remover agendamento',
            'system/capabilities'=>'Consultar capacidades',
            'system/settings'=>'Consultar configurações',
            'system/settings-update'=>'Atualizar configurações',
            'system/guide'=>'Consultar documentação',
            'system/probe'=>'Verificar resposta HTTP',
            'system/health'=>'Consultar saúde do servidor',
            'system/maintenance'=>'Executar manutenção',
            'system/cache-flush'=>'Limpar cache',
            'system/debug-log'=>'Ler registro de depuração',
            'system/toggle-debug'=>'Configurar modo de depuração',
            'system/get-transient'=>'Consultar dado temporário',
            'system/delete-transient'=>'Excluir dado temporário',
            'site/set-address'=>'Definir endereço do site',
            'site/set-admin-email'=>'Definir e-mail administrativo',
            'site/set-language'=>'Definir idioma do site',
            'roles/list'=>'Listar funções',
            'roles/update'=>'Atualizar função',
            'roles/delete'=>'Excluir função',
            'roles/restore'=>'Restaurar função',
            'rewrite/flush'=>'Regerar regras de endereço',
            'widgets/get-sidebar'=>'Consultar widgets da área',
            'widgets/list-available'=>'Listar widgets disponíveis',
            'widgets/list-sidebars'=>'Listar áreas de widgets',
            'core/get-environment-info'=>'Consultar ambiente WordPress',
            'core/get-site-info'=>'Consultar informações do site',
            'core/get-user-info'=>'Consultar informações do usuário',
            'wp-mcp-ultimate/get-ability-info'=>'Consultar habilidade',
            'wp-mcp-ultimate/discover-abilities'=>'Descobrir habilidades',
            'wp-mcp-ultimate/execute-ability'=>'Executar habilidade',
            'wp-mcp-ultimate/execute-readonly-ability'=>'Executar habilidade somente de leitura',
            'themes/activate'=>'Ativar tema',
            'themes/update'=>'Atualizar tema',
            'themes/upload'=>'Enviar tema',
            'themes/delete'=>'Excluir tema',
            'themes/install'=>'Instalar tema',
            'themes/list'=>'Listar temas',
            'themes/rollback'=>'Restaurar versão do tema',
            'themes/validate'=>'Validar tema',
        ];
        return $labels[$id]??$ability->get_label();
    }

    public static function choices(string $name,array $choices,array $selected,string $label,string $help): void {
        $id='f3-choice-'.$name;
        echo '<fieldset class="f3-choices" data-choices><legend>'.esc_html($label).'</legend><label for="'.esc_attr($id).'">Pesquisar '.esc_html(strtolower($label)).'</label><input type="search" id="'.esc_attr($id).'" data-choice-search autocomplete="off" aria-controls="'.esc_attr($id.'-list').'"><p class="description" id="'.esc_attr($id.'-help').'">'.esc_html($help).'</p><p data-choice-count role="status" aria-live="polite"></p><div class="f3-choice-list" id="'.esc_attr($id.'-list').'">';
        foreach($choices as $key=>$title)echo '<label data-choice><input type="checkbox" name="'.esc_attr($name).'[]" value="'.esc_attr($key).'" '.checked(in_array($key,$selected,true),true,false).' aria-describedby="'.esc_attr($id.'-help').'"> <span>'.esc_html($title).'<small><code>'.esc_html($key).'</code></small></span></label>';
        echo '</div></fieldset>';
    }
    public static function file_limit(int $limit,string $revision): array {
        if(!current_user_can('manage_options'))return Result::fail('permission_denied','Permissão insuficiente.');
        return Locks::run(['channel-settings'=>LOCK_EX],static function()use($limit,$revision){
            if($limit<1048576||$limit>1073741824)return Result::fail('file_limit_invalid','Use um limite entre 1 MiB e 1 GiB.');
            if(!hash_equals(hash('sha256',serialize(get_option('f3_mcp_file_bytes',16777216))),$revision))return Result::fail('settings_conflict','O limite mudou. Recarregue a página.');
            return VerifiedOptions::update('f3_mcp_file_bytes',['value'=>$limit]);
        });
    }
    public static function handle_file_limit(): void {
        if(!current_user_can('manage_options'))wp_die('Permissão insuficiente.','',['response'=>403]);
        check_admin_referer('f3_mcp_file_limit');$raw=$_POST['file_bytes']??null;
        $r=self::file_limit(is_string($raw)&&ctype_digit($raw)?(int)$raw:0,is_string($_POST['revision']??null)?wp_unslash($_POST['revision']):'');
        Audit::record('admin/file-limit',[],$r,0);$key=wp_generate_uuid4();set_transient('f3_mcp_notice_'.get_current_user_id().'_'.$key,['success'=>!empty($r['success']),'message'=>!empty($r['success'])?'Limite salvo.':($r['message']??'Não foi possível salvar.')],60);
        wp_safe_redirect(add_query_arg('notice',$key,self::url('files')));exit;
    }

    public static function render(): void {
        if (!current_user_can('manage_options')) return;
        $tab = isset($_GET['tab']) && is_string($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'connection';
        if (!in_array($tab, ['connection','connections','files','diagnostics','help','updates','operations','history'], true)) $tab = 'connection';
        $status = ConnectionStatus::snapshot();
        echo '<div class="wrap f3-mcp-admin"><header class="f3-header"><div><h1>Fator3 MCP</h1><p>Conecte seus assistentes e gerencie o acesso ao WordPress.</p></div><span class="f3-version">' . esc_html(F3_MCP_FILES_VERSION) . '</span></header>';
        echo '<nav class="f3-nav" aria-label="Configurações do MCP">';
        foreach (['connection'=>'Conexão do servidor','connections'=>'Clientes conectados','files'=>'Arquivos e banco','operations'=>'Operações','history'=>'Registro','diagnostics'=>'Diagnóstico','updates'=>'Atualizações','help'=>'Ajuda'] as $key => $label) echo '<a ' . ($tab === $key ? 'aria-current="page"' : '') . ' href="' . esc_url(self::url($key)) . '">' . esc_html($label) . '</a>';
        echo '</nav>';
        if (isset($_GET['notice']) && is_string($_GET['notice']) && preg_match('/^[a-f0-9-]{36}$/D', $_GET['notice'])) {
            $key = 'f3_mcp_notice_' . get_current_user_id() . '_' . $_GET['notice']; $notice = get_transient($key); delete_transient($key);
            if (is_array($notice)) echo '<div class="notice ' . ($notice['success'] ? 'notice-success' : 'notice-error') . ' inline"><p>' . esc_html($notice['message']) . '</p></div>';
        }
        echo '<div id="f3-feedback" class="f3-feedback" role="status" aria-live="polite" hidden></div>';
        include F3_MCP_FILES_DIR . 'includes/views/' . $tab . '.php';
        echo '</div>';
    }
    public static function test_controls(array $status): void {
        $previous = ConnectionStatus::previous();
        $observed = $status['observed_connections'] ?? [];
        echo '<p>Registro local: ' . esc_html(empty($status['errors']) ? 'confirmado' : 'requer atenção') . '. OAuth: ' . esc_html(count(array_filter($observed, static fn($r) => $r['authentication'] === 'oauth')) ? 'requisição autenticada observada' : 'ainda não observado') . '.</p>';
        if ($observed) {
            echo '<details><summary>Conexões autenticadas observadas</summary><ul>';
            foreach ($observed as $row) echo '<li>' . esc_html($row['connection_id'] . ' · ' . $row['route'] . ' · ' . ($row['protocol_version'] ?? 'versão não informada') . ' · ' . gmdate('c', $row['observed_at'])) . '</li>';
            echo '</ul><p>Confirma requisições reais; não identifica a origem de rede através de proxies. Credenciais temporárias do autoteste são excluídas.</p></details>';
        } else echo '<p>Nenhuma requisição de conector foi observada desde esta atualização.</p>';
        echo '<label for="f3-test-route">Endereço para testar</label><div class="f3-actions"><select id="f3-test-route">';
        foreach ($status['endpoints'] as $entry) echo '<option value="' . esc_attr($entry['route']) . '">' . esc_html($entry['role'] === 'legacy' ? 'Compatibilidade — wp-mcp-ultimate' : ($entry['role'] === 'primary' ? 'URL principal' : 'Alias Fator3')) . '</option>';
        echo '</select><button type="button" class="button" id="f3-test">Testar comunicação HTTP</button></div><p class="description">O teste parte deste servidor, com uma senha temporária. Verifica autenticação e os três metatools; o acesso do seu conector e o fluxo OAuth precisam ser verificados no próprio cliente.</p>';
        echo '<p id="f3-test-result" role="status" aria-live="polite">' . esc_html($previous ? $previous['message'] . ' Último teste: ' . $previous['tested_at'] . ' — ' . $previous['route'] : 'Comunicação HTTP ainda não verificada.') . '</p>';
    }
    public static function form(string $section, bool $stored, bool $disabled = false): void {
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" class="f3-settings-form">';
        Admin::nonce('f3_mcp_settings');
        echo '<input type="hidden" name="action" value="f3_mcp_save"><input type="hidden" name="section" value="' . esc_attr($section) . '"><input type="hidden" name="enable" value="0">';
        echo '<label><input type="checkbox" name="enable" value="1" aria-describedby="f3-help-' . esc_attr($section) . '" ' . checked($stored, true, false) . disabled($disabled, true, false) . '> ' . esc_html($section === 'channel' ? 'Habilitar canal de arquivos e banco' : 'Permitir escrita SQL com prévia e confirmação') . '</label><p id="f3-help-' . esc_attr($section) . '" class="description">' . esc_html($section === 'channel' ? 'Autoriza o canal geral. Cada cliente continua limitado pelo perfil e pelas permissões do usuário.' : 'Autoriza alterações no banco somente após prévia e confirmação da operação.') . '</p><p><button class="button button-primary" ' . disabled($disabled, true, false) . '>Salvar</button></p></form>';
    }
}
