# OAuth/CIMD — contrato vigente

O servidor anuncia e implementa somente `token_endpoint_auth_methods_supported:["none"]`. A fonte comum é `ClientAuthentication::supported`. Clientes públicos continuam usando authorization_code com PKCE S256 e refresh rotativo.

Quando o documento CIMD tem lista plural válida, o método selecionado pertence à interseção com o suporte do servidor. O documento ChatGPT capturado em 15/10/2026 contém singular `private_key_jwt` e plural `["none","private_key_jwt"]`: o método efetivo é `none`.

A lista plural deve ser um array JSON não vazio, com strings de método não vazias, sem espaços, até 32 itens. Objeto com chaves numéricas não é array. Null, string, objeto, lista vazia ou item inválido é recusado sem fallback. O singular, quando presente, também precisa ser string válida. Sem plural, singular `none` é aceito; outros métodos são recusados. **Sem os dois campos, a política local CIMD assume cliente público `none`.** Isso é uma decisão explícita desta implementação, não suporte a autenticação confidencial.

O endpoint de token recusa `client_secret`, `client_assertion`, `client_assertion_type` e cabeçalho de autenticação de cliente, incluindo Basic. Não busca JWKS e não implementa private_key_jwt. O método persistido é verificado na troca/renovação, sem busca de metadados dentro da transação SQL.

Mantêm-se HTTPS público sem credenciais/query/fragmento/dot-segments, proteção SSRF, ausência de redirects na busca, JSON até 64 KiB, identidade exata, redirect URI, issuer, recurso/site, consentimento, perfil, PKCE e uso único. Cache padrão de 300 s, teto de 3600 s; no-cache/no-store exigem revalidação. No-store persiste apenas o vínculo operacional, sem nome/redirects do documento. Falha ao revalidar não usa documento vencido.

## Diagnóstico restrito

Falhas distinguem `client_unavailable`, `metadata_fetch_failed`, `metadata_invalid`, `metadata_unsafe`, `metadata_method_unsupported` e `client_persistence_failed`. A página de autorização e `X-F3-OAuth-Diagnostic` apresentam um identificador opaco de 24 caracteres hexadecimais. O registro privado fica em `f3-mcp-private/oauth-diagnostics`, com guarda PHP, arquivos 0600 e os últimos 128 registros. Cada registro contém ID, categoria, instante, site e HMAC da identidade do cliente. Não recebe tokens, códigos, segredos, state, challenge, corpo do documento ou URL completa da autorização. O arquivo ring.php é uma fila limitada; eventos antigos são substituídos sob lock. Falha do logger não autoriza o cliente nem copia dados para log público; o ID continua na resposta, mas pode não ter registro persistido.

## Atualização e validação

As evidências CIMD a seguir são históricas da rodada 0.22.0. A versão 0.25.0 mantém o contrato e verifica preservação de tokens na atualização, sem declarar nova homologação integral de cliente ChatGPT.

Não há limpeza geral de clientes ou cache na atualização, alteração de grants, extensão de prazos ou reemissão de tokens. Clientes DCR e conexões válidas permanecem. Não é necessária nova autorização para conexões válidas por causa desta release. Uma conexão que nunca concluiu CIMD precisa iniciar novamente a autorização após instalar a candidata; revogações continuam exigindo consentimento novo.

Os testes automatizados usam documento capturado e transporte externo controlado, com HTTP local nativo para autorização/consentimento/token/MCP. Na bancada, DNS externo não estava disponível para PHP; a fixture HTTP troca apenas client_id por uma URL HTTPS de IP público literal, mantendo os campos de negociação e redirect do documento capturado. Essa execução não é uma conexão real ChatGPT.

O protocolo 2025-11-25 foi testado com initialize, sessão, tools/list e tools/call; o protocolo 2026-07-28 foi testado no modo stateless, no qual initialize não existe. B22, conexão real pela interface ChatGPT em endpoint de homologação, permanece pendente e impede declarar homologação integral CIMD.

Referência oficial consultada: https://developers.openai.com/plugins/build/auth, seção Client registration e negociação plural CIMD. Fixture capturada: https://chatgpt.com/oauth/client.json, em 15/10/2026.
