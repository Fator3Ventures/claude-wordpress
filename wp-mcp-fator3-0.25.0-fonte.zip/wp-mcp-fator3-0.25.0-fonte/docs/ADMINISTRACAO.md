# Administração do Fator3 MCP 0.25.0

## Navegação

Abra Ferramentas → Fator3 MCP. As abas mantêm endereços próprios e nomes por assunto. Conexão do servidor informa o endereço e os meios de autenticação. Clientes conectados reúne identidades e perfis. Arquivos e banco controla o canal, escrita SQL, limites e retenção. Operações acompanha planos. Registro consulta auditoria e manutenção. Diagnóstico verifica comunicação. Atualizações configura apenas o MCP. Ajuda reúne os documentos instalados.

## Clientes e permissões

Escolha o usuário pelo nome e a identidade existente pela lista. Para localizar uma conta fora dos primeiros 100 resultados, use Pesquisar outro usuário. A edição mantém o usuário da identidade. Nome do cliente é um rótulo administrativo, não uma credencial.

Leitura permite consultas; Conteúdo permite escrita de conteúdo; Manutenção acompanha as permissões do usuário e do processo PHP. Personalizado usa as habilidades marcadas. O catálogo apresenta nomes e identificadores; pesquisar não desmarca opções ocultas. Habilidades e tipos temporariamente ausentes continuam visíveis como indisponíveis quando já fazem parte do perfil. Não é possível adicionar identificadores inexistentes. Nenhuma seleção de tipos significa todos os tipos permitidos ao usuário.

Diretórios devem ser caminhos absolutos existentes. Exceções de metadados usam chaves exatas. As quatro permissões adicionais possuem ajuda individual: exportação de backups próprios, exportação de backups de outras conexões, escrita SQL e executor de leitura. O canal geral e as permissões WordPress continuam valendo.

A expiração é escolhida em UTC e conserva os segundos ao editar. Vazio remove o prazo adicional do perfil. O limite por arquivo do perfil Manutenção aceita 1 MiB a 1 GiB; vazio volta a herdar o canal. Salvamentos concorrentes de perfis já existentes exigem recarregar a página.

## Arquivos e banco

O canal geral pode ser habilitado ou fechado. A escrita SQL possui controle separado e continua exigindo prévia e confirmação. Constantes, filtros e permissões do servidor podem restringir o estado efetivo; a tela informa essas restrições, mas não edita código de configuração PHP. O limite padrão por arquivo é editável em bytes, entre 1 MiB e 1 GiB. Perfis de Manutenção podem definir limite próprio.

Retenção SQL aceita idade de 1 a 3650 dias, quantidade de 1 a 10000 e mínimo entre zero e a quantidade máxima. Salvar a política não exclui backups. A aplicação da limpeza continua exigindo simulação e confirmação. Consulte SQL-RETENTION e SQL-GUARD nesta Ajuda ou pelo MCP.

## Registro e operações

O Registro usa seletores nativos de data e hora em UTC, com precisão de segundos. Intervalos invertidos ou datas inválidas são recusados. Resultado permite Todos, Concluído ou Falhou. Os filtros permanecem na paginação. Links ISO existentes são aceitos para compatibilidade; não é necessário digitar ISO.

Operações oferece estados Pendente, Em andamento, Pausado, Concluído, Falhou, Cancelado, Revertido por compensação e Compensação incompleta. Cancelamento impede próximos passos, mas não desfaz uma etapa que terminou. Os detalhes técnicos são somente leitura e não expõem parâmetros privados de planos.

## Atualizações

Informe o endereço HTTPS da fonte publicada do Fator3 MCP. Vazio desabilita apenas este canal. Domínios adicionais autorizam downloads fora do domínio da fonte. O endereço exige HTTPS, sem credenciais, fragmentos ou portas alternativas; redirecionamentos permanecem recusados pelo protocolo.

Esta tela salva somente a entrada wp-mcp-fator3 e preserva as configurações dos demais pacotes. Uma revisão impede sobrescrever alterações concorrentes. Nenhum pacote é instalado ao salvar. O contrato package-distribution v1 e os consumidores existentes continuam funcionando. Nenhum endereço de distribuição é inventado ou habilitado automaticamente.

## Documentação e limites

Ajuda permite escolher um documento e continuar a leitura por trechos. system/guide oferece os mesmos textos com hash e paginação UTF-8. JSON apresentado em exemplos de configuração ou detalhes técnicos é somente leitura; campos operacionais não exigem edição de JSON. Nomes técnicos, identificadores públicos, produtos e protocolos são preservados.
