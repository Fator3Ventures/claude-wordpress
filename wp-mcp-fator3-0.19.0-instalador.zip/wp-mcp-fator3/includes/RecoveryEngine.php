<?php
/** Small recovery runtime copied outside the replaceable plugin tree. No autoload dependency. */
declare(strict_types=1);
namespace Fator3\RecoveryV1;

final class Engine {
    public const HEADER = "<?php exit; ?>\n";
    private static array $last_sweep = ['status' => 'not_run', 'attempted' => 0, 'recovered' => 0, 'unresolved' => 0];
    /** Request-local diagnostics; never expose a journal, path, token or exception. */
    public static function sweep_status(): array { return self::$last_sweep; }
    private static function key(): string {
        if (!defined('AUTH_KEY') || !defined('SECURE_AUTH_KEY')) throw new \RuntimeException('Recovery signing keys unavailable.');
        return hash('sha256', AUTH_KEY . '|' . SECURE_AUTH_KEY . '|f3-recovery-v1', true);
    }
    public static function write(string $file, array $data): void {
        $json=json_encode($data,JSON_THROW_ON_ERROR|JSON_UNESCAPED_SLASHES);
        self::atomic($file,self::HEADER.json_encode(['data'=>$json,'mac'=>hash_hmac('sha256',$json,self::key())],JSON_THROW_ON_ERROR),0600);
        if(str_ends_with($file,'.journal.php')&&!empty($data['id'])){
            $active=dirname($file).'/active';if(!is_dir($active)&&!mkdir($active,0700)&&!is_dir($active))throw new \RuntimeException('Recovery index unavailable.');
            $pointer=$active.'/'.$data['id'].'.php';
            if(in_array($data['status']??'',['armed','applied','restoring','recovery_required','verification_pending'],true)||(($data['status']??'')==='rolled_back'&&($data['cache_invalidation_until']??0)>time()))self::write($pointer,['id'=>$data['id']]);
            elseif(is_file($pointer))unlink($pointer);
        }

    }
    /** Independent worker and parent serialize field-level journal changes. */
    private static function patch(string $file,array $patch): array {
        $h=fopen($file.'.state-lock','c+b');if(!$h)throw new \RuntimeException('Journal lock unavailable.');
        try{if(!flock($h,LOCK_EX))throw new \RuntimeException('Journal lock unavailable.');$s=self::read($file);if(!$s)throw new \RuntimeException('Recovery journal unavailable.');$s=array_replace($s,$patch);self::write($file,$s);return $s;}
        finally{flock($h,LOCK_UN);fclose($h);}
    }
    public static function read(string $file): ?array {
        if(!is_file($file)||is_link($file)||filesize($file)>1048576)return null;
        $raw=file_get_contents($file);
        if(!str_starts_with($raw,self::HEADER))return null;
        $envelope=json_decode(substr($raw,strlen(self::HEADER)),true);
        if(!is_array($envelope)||!is_string($envelope['data']??null)||!is_string($envelope['mac']??null)||!hash_equals(hash_hmac('sha256',$envelope['data'],self::key()),$envelope['mac']))return null;
        $data=json_decode($envelope['data'],true);return is_array($data)?$data:null;
    }
    public static function atomic(string $file,string $bytes,int $mode=0644): void {
        $temp=dirname($file).'/.f3-'.bin2hex(random_bytes(12)).'.tmp';$h=@fopen($temp,'xb');
        if(!$h)throw new \RuntimeException('Cannot create recovery temporary.');
        try {
            if(!@chmod($temp,$mode))throw new \RuntimeException('Recovery permissions failed.');$offset=0;$len=strlen($bytes);
            while($offset<$len){$n=@fwrite($h,substr($bytes,$offset,65536));if(!$n)throw new \RuntimeException('Incomplete recovery write.');$offset+=$n;}
            if(!@fflush($h))throw new \RuntimeException('Recovery flush failed.');
            if(function_exists('fsync')&&!@fsync($h))throw new \RuntimeException('Recovery fsync failed.');
        } catch(\Throwable $e){@unlink($temp);throw $e;} finally {fclose($h);}
        if(!@rename($temp,$file)){@unlink($temp);throw new \RuntimeException('Recovery rename failed.');}
        if(function_exists('opcache_invalidate'))@opcache_invalidate($file,true);
    }
    /** A bounded inventory refuses links, special files and incomplete reads. */
    public static function manifest(string $path): ?array {
        clearstatcache(true,$path);if(is_link($path))throw new \RuntimeException('Symbolic links are not recoverable.');
        if(!file_exists($path))return null;
        if(is_file($path))return ['kind'=>'file','files'=>[''=>self::entry($path)]];
        if(!is_dir($path))throw new \RuntimeException('Unsupported filesystem object.');
        $entries=[];$bytes=0;
        $it=new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path,\FilesystemIterator::SKIP_DOTS),\RecursiveIteratorIterator::SELF_FIRST);
        foreach($it as $file) {
            if($file->isLink())throw new \RuntimeException('Symbolic link in package.');
            $relative=substr($file->getPathname(),strlen($path)+1);
            if($file->isDir())$entries[$relative]=['directory'=>true,'mode'=>$file->getPerms()&0777];
            elseif($file->isFile()){$entries[$relative]=self::entry($file->getPathname());$bytes+=$entries[$relative]['bytes'];}
            else throw new \RuntimeException('Special file in package.');
            if(count($entries)>20000||$bytes>268435456)throw new \RuntimeException('Recovery inventory budget exceeded.');
        }
        ksort($entries,SORT_STRING);return ['kind'=>'tree','mode'=>fileperms($path)&0777,'files'=>$entries];
    }
    private static function entry(string $file): array {
        $hash=hash_file('sha256',$file);if(!$hash)throw new \RuntimeException('Cannot hash recovery file.');
        return ['sha256'=>$hash,'bytes'=>filesize($file),'mode'=>fileperms($file)&0777];
    }
    public static function digest(?array $manifest): ?string {return $manifest===null?null:hash('sha256',json_encode($manifest,JSON_THROW_ON_ERROR));}
    public static function copy(string $source,string $destination): void {
        $manifest=self::manifest($source);if(!$manifest)throw new \RuntimeException('Recovery source missing.');
        if(file_exists($destination)||is_link($destination))throw new \RuntimeException('Recovery destination exists.');
        if($manifest['kind']==='file') {
            if(!copy($source,$destination))throw new \RuntimeException('Recovery copy failed.');chmod($destination,$manifest['files']['']['mode']);
        } else {
            if(!mkdir($destination,$manifest['mode'],true))throw new \RuntimeException('Recovery directory failed.');
            foreach($manifest['files'] as $name=>$entry) {
                $out=$destination.'/'.$name;
                if(!empty($entry['directory'])){if(!is_dir($out)&&!mkdir($out,$entry['mode'],true))throw new \RuntimeException('Recovery directory failed.');}
                else {if(!is_dir(dirname($out)))mkdir(dirname($out),0755,true);if(!copy($source.'/'.$name,$out))throw new \RuntimeException('Recovery copy failed.');chmod($out,$entry['mode']);}
            }
        }
        if(self::digest($manifest)!==self::digest(self::manifest($destination)))throw new \RuntimeException('Recovery copy verification failed.');
    }
    public static function remove(string $path): void {
        if(is_link($path))throw new \RuntimeException('Refusing linked deletion.');
        if(is_dir($path)){foreach(new \FilesystemIterator($path,\FilesystemIterator::SKIP_DOTS) as $item)self::remove($item->getPathname());if(!rmdir($path))throw new \RuntimeException('Directory removal failed.');}
        elseif(is_file($path)&&!unlink($path))throw new \RuntimeException('File removal failed.');
    }
    /** Prepare on the destination filesystem; a partial copy is never the active package. */
    public static function prepare_install(string $journal,string $source): void {
        $state=self::read($journal);if(!$state||$state['status']!=='armed'||(empty($state['plugin'])&&empty($state['tree_operation'])))throw new \RuntimeException('Install journal invalid.');
        $target=$state['target'];$next=dirname($target).'/.f3-install-'.$state['id'];$previous=dirname($target).'/.f3-previous-'.$state['id'];
        if(file_exists($next)||file_exists($previous)||is_link($next)||is_link($previous))throw new \RuntimeException('Install staging exists.');
        if(self::digest(self::manifest($source))!==$state['after_sha256'])throw new \RuntimeException('Staged package changed.');
        $state['install_next']=$next;$state['install_previous']=$previous;$state['install_phase']='preparing';self::write($journal,$state);
        self::copy($source,$next);
        if(self::digest(self::manifest($next))!==$state['after_sha256'])throw new \RuntimeException('Install staging verification failed.');
        $state['install_phase']='prepared';self::write($journal,$state);
    }
    public static function commit_install(string $journal): void {
        $state=self::read($journal);if(!$state||($state['install_phase']??'')!=='prepared')throw new \RuntimeException('Install not prepared.');
        $previous_manifest=self::manifest($state['target']);
        if(self::digest($previous_manifest)!==$state['before_sha256']||self::digest(self::manifest($state['install_next']))!==$state['after_sha256'])throw new \RuntimeException('Install precondition changed.');
        $state['install_phase']='switching';self::write($journal,$state);
        if(file_exists($state['target'])&&!rename($state['target'],$state['install_previous']))throw new \RuntimeException('Cannot retain previous package.');
        if(!rename($state['install_next'],$state['target']))throw new \RuntimeException('Cannot install complete package.');
        self::invalidate($state['target'],$previous_manifest);$state['install_phase']='installed';self::write($journal,$state);
    }
    public static function finish_install(string $journal): void {
        $state=self::read($journal);if(!$state||!in_array($state['status'],['complete','rolled_back','unchanged'],true))return;
        foreach(['install_next'=>'after_sha256','install_previous'=>'before_sha256'] as $field=>$hash){
            if(empty($state[$field])||!file_exists($state[$field]))continue;
            if(self::digest(self::manifest($state[$field]))===$state[$hash])self::remove($state[$field]);
        }
    }
    private static function invalidate(string $target,?array $previous_manifest=null): void {
        if(!function_exists('opcache_invalidate'))return;
        // The new tree alone omits removed scripts, which OPcache can still execute.
        $paths=[];
        foreach([$previous_manifest,self::manifest($target)] as $manifest)
            foreach($manifest['files']??[] as $file=>$info)if(empty($info['directory']))$paths[$manifest['kind']==='file'?$target:$target.'/'.$file]=true;
        // CLI and FPM have separate caches; the serving sentinel also clears removed scripts.
        $cached=function_exists('opcache_get_status')?@opcache_get_status(true):false;
        foreach(($cached['scripts']??[]) as $path=>$entry)if($path===$target||str_starts_with($path,rtrim($target,'/').'/'))$paths[$path]=true;
        foreach($paths as $path=>$_)@opcache_invalidate($path,true);
    }
    /** Restore only this package's activation bit, preserving unrelated plugins. */
    private static function activation(array $state): void {
        if(isset($state['theme_before'])){foreach($state['theme_before'] as $key=>$value)update_option($key,$value);if(function_exists('wp_clean_themes_cache'))wp_clean_themes_cache();}
        if(!isset($state['plugin'],$state['active_before']))return;
        if(!function_exists('get_option')||!function_exists('update_option'))throw new \RuntimeException('WordPress option API unavailable.');
        $plugin=$state['plugin'];
        wp_cache_delete('alloptions','options');wp_cache_delete('active_plugins','options');
        $list=(array)get_option('active_plugins',[]);$next=array_values(array_diff($list,[$plugin]));
        if($state['active_before'])$next[]=$plugin;sort($next);
        if($next!==$list)update_option('active_plugins',$next);
        wp_cache_delete('alloptions','options');wp_cache_delete('active_plugins','options');
        if(in_array($plugin,(array)get_option('active_plugins',[]),true)!==$state['active_before'])throw new \RuntimeException('Activation state was not restored.');
    }
    private static function terminal(string $journal,array &$state,string $status,string $reason): array {
        $state['status']=$status;$state['recovery_reason']=$reason;self::write($journal,$state);
        return ['status'=>$status,'reason'=>$reason];
    }
    public static function restore(string $journal,bool $locks_held=false): array {
        $state=self::read($journal);if(!$state)return ['status'=>'recovery_required','reason'=>'journal_invalid'];
        if(!in_array($state['status'],['armed','applied','recovery_required','restoring','verification_pending'],true))return ['status'=>$state['status']];
        if(($state['verification_policy']??'')==='conservative-1'&&($state['install_phase']??'')==='installed'&&empty($state['rollback_authorized']))return ['status'=>'verification_pending','reason'=>'explicit_reconciliation_required'];
        $handles=[];
        try {
            if(($state['verification_policy']??'')==='conservative-1'){$activation=fopen($journal.'.activation-lock','c+b');if(!$activation||!flock($activation,LOCK_EX|LOCK_NB)){if($activation)fclose($activation);return ['status'=>'verification_pending','reason'=>'activation_running'];}$handles[]=$activation;}
            if(!$locks_held)foreach($state['locks'] as $file=>$mode){$h=fopen($file,'c+b');if(!$h||!flock($h,$mode|LOCK_NB)){if($h)fclose($h);return ['status'=>'busy'];}$handles[]=$h;}
            $target=$state['target'];$before=$state['before_sha256'];$after=$state['after_sha256']??null;
            $prepared=dirname($target).'/.f3-restore-'.$state['id'];$quarantine=dirname($target).'/.f3-displaced-'.$state['id'];
            $actual_manifest=self::manifest($target);$displaced_manifest=self::manifest($quarantine);
            $actual=self::digest($actual_manifest);$displaced=self::digest($displaced_manifest);
            if($actual===null&&$before!==null&&($state['install_phase']??'')==='switching'){
                $previous=$state['install_previous']??'';
                if(!$previous||self::digest(self::manifest($previous))!==$before)return self::terminal($journal,$state,'rollback_conflict','install_previous_changed');
                if(!rename($previous,$target))throw new \RuntimeException('Cannot restore interrupted install.');
                self::invalidate($target);$actual=self::digest(self::manifest($target));
            }

            if($displaced!==null&&$displaced!==$after)return self::terminal($journal,$state,'rollback_conflict','quarantine_changed');
            if($actual===$before){
                self::invalidate($target,$displaced_manifest);
                self::activation($state);$state['status']='rolled_back';$state['restored_at']=time();$state['cache_invalidation_until']=time()+60;self::write($journal,$state);
                if($displaced!==null)self::remove($quarantine);
                if(file_exists($prepared)&&self::digest(self::manifest($prepared))===$before)self::remove($prepared);
                self::finish_install($journal);return ['status'=>'rolled_back','already_restored'=>true];
            }
            // A persisted restoring phase plus verified quarantine proves our interrupted rename.
            $interrupted=$state['status']==='restoring'&&$actual===null&&$displaced===$after&&$displaced!==null;
            if($actual!==$after&&!$interrupted)return self::terminal($journal,$state,'rollback_conflict','postimage_changed');
            if($before!==null&&self::digest(self::manifest($state['preimage']))!==$before)return self::terminal($journal,$state,'recovery_required','preimage_invalid');
            $state['status']='restoring';self::write($journal,$state);
            if($before!==null){
                if(file_exists($prepared)){
                    if(self::digest(self::manifest($prepared))!==$before){
                        // An incomplete private copy is replaceable; it is never installed as the target.
                        self::remove($prepared);self::copy($state['preimage'],$prepared);
                    }
                }else self::copy($state['preimage'],$prepared);
            }elseif(file_exists($prepared))return self::terminal($journal,$state,'rollback_conflict','unexpected_prepared_object');
            if($actual!==self::digest(self::manifest($target)))return self::terminal($journal,$state,'rollback_conflict','postimage_changed');
            if(file_exists($target)){
                if($displaced!==null)return self::terminal($journal,$state,'rollback_conflict','duplicate_postimage');
                if(!rename($target,$quarantine))throw new \RuntimeException('Cannot displace postimage.');
            }
            if($before!==null&&!rename($prepared,$target))throw new \RuntimeException('Cannot restore preimage.');
            if(self::digest(self::manifest($target))!==$before)throw new \RuntimeException('Restored hash mismatch.');
            self::invalidate($target,$actual_manifest??$displaced_manifest);
            self::activation($state);$state['status']='rolled_back';$state['restored_at']=time();$state['cache_invalidation_until']=time()+60;self::write($journal,$state);
            if(file_exists($quarantine))self::remove($quarantine);
            self::finish_install($journal);return ['status'=>'rolled_back'];
        } catch(\Throwable $e){
            // Keep a resumable phase for temporary filesystem/option failures. Never discard preimages.
            return ['status'=>'recovery_required','reason'=>'filesystem_or_activation_recovery_failed'];
        } finally {foreach(array_reverse($handles) as $h){flock($h,LOCK_UN);fclose($h);}}
    }
    /** Dedicated activation route remains available while the MCP plugin is inactive. */
    public static function register_worker(string $directory): void {
        add_action('rest_api_init',static function()use($directory){
            register_rest_route('f3-mcp-recovery/v1','/activate',[
                'methods'=>'POST',
                'permission_callback'=>static function($request)use($directory){return self::worker_authorized($request,$directory);},
                'callback'=>static function($request)use($directory){return self::activate_worker($request,$directory);},
            ]);
        });
    }
    private static function worker_authorized($request,string $directory) {
        $id=(string)$request->get_header('x-f3-operation');$token=(string)$request->get_header('x-f3-activation');
        if(!preg_match('/^[a-f0-9]{32}$/D',$id)||!preg_match('/^[a-f0-9]{64}$/D',$token))return new \WP_Error('activation_forbidden','Credencial interna inválida.',['status'=>403]);
        $state=self::read($directory.'/'.$id.'.journal.php');
        if(!$state||!in_array($state['status'],['applied','verification_pending'],true)||($state['activation_status']??'')!=='pending'||($state['activation_expires']??0)<time()||!hash_equals($state['activation_token']??'',hash('sha256',$token)))return new \WP_Error('activation_forbidden','Credencial interna expirada/consumida.',['status'=>403]);
        return true;
    }
    private static function connection_valid(array $state): bool {
        global $wpdb;$connection=$state['connection_id'];$user=(int)$state['user_id'];
        $key=hash('sha256',get_current_blog_id().'|connections|'.$connection);
        $row=$wpdb->get_row($wpdb->prepare('SELECT status,payload FROM '.$wpdb->prefix.'f3_mcp_state WHERE record_key=%s',$key),ARRAY_A);
        if(!$row||$wpdb->last_error||$row['status']!=='active')return false;$policy=json_decode($row['payload'],true);
        if(!$policy||(int)$policy['user_id']!==$user||($policy['policy_version']??0)!==$state['activation_policy_version']||(!empty($policy['expires'])&&$policy['expires']<=time())||!user_can($user,'activate_plugins'))return false;
        if(str_starts_with($connection,'app:')&&!\WP_Application_Passwords::get_user_application_password($user,substr($connection,4)))return false;
        if(str_starts_with($connection,'grant:')){
            $key=hash('sha256',get_current_blog_id().'|oauth-grants|'.substr($connection,6));
            $grant=$wpdb->get_row($wpdb->prepare('SELECT status,user_id,expires_at FROM '.$wpdb->prefix.'f3_mcp_grants WHERE record_key=%s',$key),ARRAY_A);
            if(!$grant||$wpdb->last_error||$grant['status']!=='active'||(int)$grant['user_id']!==$user||((int)$grant['expires_at']>0&&(int)$grant['expires_at']<=time()))return false;
        }
        return true;
    }
    private static function activate_worker($request,string $directory): array {
        $id=(string)$request->get_header('x-f3-operation');$journal=$directory.'/'.$id.'.journal.php';$h=fopen($journal.'.activation-lock','c+b');
        if(!$h||!flock($h,LOCK_EX|LOCK_NB)){if($h)fclose($h);return ['success'=>false,'error_code'=>'activation_busy'];}
        try{
            if(self::worker_authorized($request,$directory)!==true)return ['success'=>false,'error_code'=>'activation_forbidden'];
            $state=self::read($journal);
            if(!self::connection_valid($state))return ['success'=>false,'error_code'=>'activation_permission_changed'];
            if(empty($state['plugin'])||self::digest(self::manifest($state['target']))!==$state['after_sha256'])return ['success'=>false,'error_code'=>'package_hash_conflict'];
            $state=self::patch($journal,['activation_status'=>'running']);wp_set_current_user((int)$state['user_id']);
            require_once ABSPATH.'wp-admin/includes/plugin.php';
            self::invalidate($state['target']);
            $result=activate_plugin($state['plugin'],'',false,true);
            $ok=!is_wp_error($result)&&is_plugin_active($state['plugin']);if(!empty($state['expected_runtime_version'])){$state['executed_runtime_version']=defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null;$ok=$ok&&$state['executed_runtime_version']===$state['expected_runtime_version'];}$patch=['activation_status'=>'complete','activation_success'=>$ok];if(isset($state['executed_runtime_version']))$patch['executed_runtime_version']=$state['executed_runtime_version'];self::patch($journal,$patch);
            return ['success'=>$ok,'active'=>is_plugin_active($state['plugin']),'fresh_php_request'=>true,'independent_worker'=>true];
        }finally{flock($h,LOCK_UN);fclose($h);}
    }
    /** Runs before normal plugins. It never reverts an operation holding its lease. */
    public static function sweep(string $directory): void {
        self::$last_sweep = ['status' => 'checked', 'attempted' => 0, 'recovered' => 0, 'unresolved' => 0];
        try {
            self::sweep_pending($directory);
        } catch (\Throwable $error) {
            // A full/unwritable acervo must not make otherwise healthy requests fatal.
            // Leave signed journals/preimages intact; the next request can retry.
            self::$last_sweep['status'] = 'degraded';
            self::$last_sweep['reason'] = 'recovery_storage_unavailable';
        }
    }
    private static function sweep_pending(string $directory): void {
        $active=$directory.'/active';
        if(!is_dir($active)&&!@mkdir($active,0700)&&!is_dir($active))throw new \RuntimeException('Recovery index unavailable.');
        // Import earlier journals incrementally once, without completed entries starving recovery.
        $cursor_file=$directory.'/recovery-index-migration.php';$cursor=self::read($cursor_file)??['after'=>'','complete'=>false];
        if(!$cursor['complete']){
            $files=glob($directory.'/*.journal.php')?:[];sort($files,SORT_STRING);$seen=0;$more=false;
            foreach($files as $file){if(basename($file)<=$cursor['after'])continue;if($seen++>=100){$more=true;break;}
                $state=self::read($file);if($state&&in_array($state['status']??'',['armed','applied','restoring','recovery_required','verification_pending'],true))self::write($active.'/'.$state['id'].'.php',['id'=>$state['id']]);$cursor['after']=basename($file);
            }
            $cursor['complete']=!$more;self::write($cursor_file,$cursor);
        }
        $cursor_path=$directory.'/recovery-sweep-cursor.php';
        $after=(self::read($cursor_path)['after']??'');$names=glob($active.'/*.php')?:[];sort($names,SORT_STRING);
        $later=array_values(array_filter($names,static fn($path)=>basename($path)>$after));
        $earlier=array_values(array_filter($names,static fn($path)=>basename($path)<=$after));
        foreach(array_slice(array_merge($later,$earlier),0,50) as $pointer_path){
            $pointer=new \SplFileInfo($pointer_path);self::write($cursor_path,['after'=>$pointer->getFilename()]);
            if($pointer->isLink()||!$pointer->isFile())continue;
            $entry=self::read($pointer->getPathname());if(!$entry||!preg_match('/^[a-f0-9]{32}$/D',$entry['id']??''))continue;
            $file=$directory.'/'.$entry['id'].'.journal.php';$state=self::read($file);
            if(!$state)continue;
            if($state['status']==='rolled_back'&&($state['cache_invalidation_until']??0)>time()){self::invalidate($state['target']);continue;}
            if(!in_array($state['status'],['armed','applied','restoring','recovery_required','verification_pending'],true)){unlink($pointer->getPathname());continue;}
            // Invalidate in the serving PHP pool before normal plugins load. CLI invalidation cannot clear another pool.
            if(($state['install_phase']??'')==='installed'||$state['status']==='applied')self::invalidate($state['target'],is_dir($state['preimage'])||is_file($state['preimage'])?self::manifest($state['preimage']):null);
            if($state['status']==='verification_pending'&&empty($state['rollback_authorized'])){self::$last_sweep['unresolved']++;self::$last_sweep['status']='degraded';self::$last_sweep['reason']='package_verification_pending';continue;}
            if(($state['lease_until']??PHP_INT_MAX)>time())continue;
            $h=@fopen($file.'.lease','c+b');if(!$h)continue;
            try {
                if(flock($h,LOCK_EX|LOCK_NB)) {
                    self::$last_sweep['attempted']++;
                    if(($state['verification_policy']??'')==='conservative-1'&&($state['install_phase']??'')==='installed'&&empty($state['rollback_authorized'])){self::patch($file,['status'=>'verification_pending','verification_reason'=>'executor_interrupted']);$result=['status'=>'verification_pending'];}
                    else $result=self::restore($file);
                    if(($result['status']??'')==='rolled_back')self::$last_sweep['recovered']++;
                    elseif(($result['status']??'')!=='busy') {
                        self::$last_sweep['unresolved']++;
                        self::$last_sweep['status']='degraded';
                        self::$last_sweep['reason']='recovery_requires_attention';
                    }
                    flock($h,LOCK_UN);
                }
            } finally {fclose($h);}
        }
    }
}
