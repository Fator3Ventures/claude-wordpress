<?php
/** Staged package replacement. Activation always happens in a fresh PHP request. */
declare(strict_types=1);
namespace Fator3\McpFiles;
use Fator3\RecoveryV1\Engine;

final class PackageService {
    public static function delete(array $input,callable $native): array {
        if($error=self::filesystem())return $error;$plugin=$input['plugin'];$key=ConnectionContext::key().'|'.$plugin;
        $pending=StateStore::get('package-delete-cleanup',$key);
        if($pending&&$pending['status']==='pending'){
            wp_clean_plugins_cache(false);$all=get_plugins();
            if(isset($all[$plugin])||file_exists(WP_PLUGIN_DIR.'/'.$plugin))return Result::fail('plugin_reinstalled_conflict','Plugin reapareceu; limpeza anterior não será aplicada.',['conflict'=>true]);
            return self::cleanup_auto_update($plugin,$pending,$key);
        }
        $all=get_plugins();if(!isset($all[$plugin]))return Result::fail('plugin_not_found','Plugin não encontrado.');
        if(is_plugin_active($plugin))return Result::fail('plugin_active','Desative o plugin antes de excluir.');
        $target=dirname($plugin)==='.'?WP_PLUGIN_DIR.'/'.$plugin:WP_PLUGIN_DIR.'/'.dirname($plugin);
        foreach($all as $entry=>$data)if($entry!==$plugin&&dirname($plugin)!=='.'&&str_starts_with($entry,dirname($plugin).'/'))return Result::fail('package_multiple_entrypoints','O diretório contém outros entrypoints; exclusão exige pacote inequívoco.');
        $op=Recovery::begin($target,null,['lock_root'=>WP_PLUGIN_DIR,'plugin'=>$plugin,'old_version'=>$all[$plugin]['Version'],'active_before'=>false]);
        $before=in_array($plugin,(array)get_site_option('auto_update_plugins',[]),true);
        try{
            $r=Result::normalize($native($input));wp_clean_plugins_cache(false);$actual=get_plugins();
            if(empty($r['success'])||isset($actual[$plugin])||file_exists($target)){
                Recovery::close($op,Engine::digest(Engine::manifest($target))===$op['state']['before_sha256']?'unchanged':'recovery_required');
                return Result::fail('plugin_delete_failed','Remoção física não confirmada; não limpar auto-update.',['backup_id'=>$op['state']['backup_id'],'exists'=>file_exists($target),'active'=>is_plugin_active($plugin),'applied'=>null]);
            }
            Recovery::close($op,'complete');$pending=['status'=>'pending','plugin'=>$plugin,'backup_id'=>$op['state']['backup_id'],'auto_update_before'=>$before,'connection_id'=>ConnectionContext::key(),'time'=>time()];StateStore::put('package-delete-cleanup',$key,$pending);
            return self::cleanup_auto_update($plugin,$pending,$key);
        }finally{Recovery::release($op);}
    }
    private static function cleanup_auto_update(string $plugin,array $pending,string $key): array {
        return Locks::run(['option:'.get_current_blog_id().':auto_update_plugins'=>LOCK_EX],static function()use($plugin,$pending,$key){
            wp_cache_delete('alloptions','options');wp_cache_delete('auto_update_plugins','options');$before=(array)get_site_option('auto_update_plugins',[]);$next=array_values(array_diff($before,[$plugin]));
            if($next!==$before)update_site_option('auto_update_plugins',$next);
            wp_cache_delete('alloptions','options');wp_cache_delete('auto_update_plugins','options');$after=(array)get_site_option('auto_update_plugins',[]);
            $data=['plugin'=>$plugin,'exists'=>false,'active'=>false,'changed'=>true,'files_removed'=>true,'auto_update_before'=>$pending['auto_update_before'],'auto_update_after'=>in_array($plugin,$after,true),'auto_update_changed'=>$pending['auto_update_before']&&!in_array($plugin,$after,true),'backup_id'=>$pending['backup_id']];
            if(in_array($plugin,$after,true)){
                return Result::fail('auto_update_cleanup_pending','Arquivos removidos; limpeza de auto-update não persistiu. Reutilize a confirmação.',$data+['auto_update_cleanup_pending'=>true,'pending'=>true,'applied'=>true]);
            }
            $pending['status']='complete';StateStore::put('package-delete-cleanup',$key,$pending);return Result::ok($data+['auto_update_cleanup_pending'=>false,'applied'=>true]);
        });
    }
    public static function register(): void {
        Registry::add('plugins/operation-status','Lê diário de troca da própria conexão, estado observado, ativação e última verificação. Não executa sondas ou nova instalação.',['operation_id'=>Registry::string()],['operation_id'],[self::class,'operation_status'],'update_plugins');
        Registry::add('plugins/reconcile','Reconcilia troca pendente por releitura e sonda; não repete instalação nem migração. Timeout permanece pendente; 5xx permite rollback.',['operation_id'=>Registry::string(),'probe_timeout_seconds'=>Registry::integer(1,30)],['operation_id'],[self::class,'reconcile'],'update_plugins',false);
        Registry::add('plugins/rollback','Restaura pré-imagem de pacote sob lock e hash da pós-imagem, incluindo estado de ativação observado. Não desfaz migrações de banco/hooks. Exige backup de pacote e permissão atual.',['backup_id'=>Registry::string()],['backup_id'],[self::class,'rollback'],'update_plugins',false);
    }
    public static function schema(array $args,string $name): array {
        if(in_array($name,['plugins/update','plugins/upload','plugins/upload-base64','plugins/reconcile','plugins/operation-status'],true)){
            $args['output_schema']['properties']=($args['output_schema']['properties']??[])+[
                'package_operation_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$'],
                'pending'=>['type'=>'boolean'],'files_applied'=>['type'=>'boolean'],'database_effects_reversible'=>['type'=>'boolean'],
                'recovery_status'=>['type'=>'string'],'verification_state'=>['type'=>'string'],'verification_reason'=>['type'=>['string','null']],
                'verification_evidence'=>['type'=>['object','null']],'file_state'=>['type'=>'string','enum'=>['candidate','preimage','diverged']],
            ];
            $args['output_schema']['properties']['applied']=['type'=>['boolean','null']];
        }
        if($name==='plugins/update'){$args['input_schema']['properties']['probe_timeout_seconds']=Registry::integer(1,30);return $args;}
        if(!in_array($name,['plugins/upload','plugins/upload-base64'],true))return $args;
        $args['input_schema']['properties']+=['probe_timeout_seconds'=>Registry::integer(1,30),'expected_sha256'=>['type'=>'string','pattern'=>'^[a-fA-F0-9]{64}$'],'expected_slug'=>['type'=>'string','pattern'=>'^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$']];
        $args['description']='Instala ZIP validado em staging. activate e overwrite são false quando omitidos. Substituição exige pré-imagem, preserva estado ativo anterior, reativa em PHP novo e verifica home/REST anônimos. expected_sha256 valida ZIP; expected_slug valida raiz. probe_timeout_seconds: 1–30 s (padrão 15) para ativação e sonda posterior; timeout deixa verification_pending, sem rollback automático. Consulte plugins/operation-status e plugins/reconcile. Retorna versões, backup e estados efetivos. Manutenção pode atualizar o próprio canal com executor de recuperação.';
        $args['execute_callback']=[self::class,'upload'];return $args;
    }
    private static function filesystem(): ?array {
        require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/plugin.php';require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';require_once F3_MCP_FILES_DIR.'includes/AtomicPluginUpgrader.php';require_once F3_MCP_FILES_DIR.'includes/ZipPackage.php';
        if(is_multisite())return Result::fail('package_topology_unsupported','Este fluxo foi homologado para single-site.');
        if(defined('DISALLOW_FILE_MODS')&&DISALLOW_FILE_MODS)return Result::fail('file_modifications_disabled','Alterações de pacotes desabilitadas.');
        if(get_filesystem_method()!=='direct'||!WP_Filesystem())return Result::fail('filesystem_direct_required','Recuperação exige acesso direto ao filesystem.');
        return null;
    }
    public static function upload(array $input): array {
        if($error=self::filesystem())return $error;
        if(count(array_intersect(array_keys($input),['url','content_base64','zip_path']))!==1)return Result::fail('package_source_invalid','Forneça exatamente uma origem do ZIP.');
        $dir=StateStore::directory('package-staging').'/'.bin2hex(random_bytes(16));if(!mkdir($dir,0700))return Result::fail('package_stage_failed','Não foi possível criar staging.');
        try {
            $zip=$dir.'/package.zip';
            if(isset($input['url'])){$r=Http::fetch($input['url'],16777216);if(is_wp_error($r))return Result::error($r);$bytes=$r['body'];}
            elseif(isset($input['content_base64'])){if(strlen($input['content_base64'])>22369624)return Result::fail('package_size_limit','ZIP supera 16 MiB.');$bytes=base64_decode($input['content_base64'],true);if($bytes===false)return Result::fail('base64_invalid','Base64 inválido.');}
            else {
                $policy=AuthorizationPolicy::check('files/read',['path'=>$input['zip_path']],true);if(is_wp_error($policy))return Result::error($policy);
                $path=PathGuard::resolve($input['zip_path'],false);if(is_wp_error($path))return Result::error($path);
                if(!is_file($path)||filesize($path)>16777216)return Result::fail('package_source_invalid','ZIP local ausente ou acima do limite.');$bytes=file_get_contents($path);
            }
            if(!is_string($bytes)||strlen($bytes)>16777216)return Result::fail('package_size_limit','ZIP supera 16 MiB.');
            if(isset($input['expected_sha256'])&&!hash_equals(strtolower($input['expected_sha256']),hash('sha256',$bytes)))return Result::fail('package_hash_conflict','Digest do ZIP difere do esperado.',['conflict'=>true]);
            Engine::atomic($zip,$bytes,0600);unset($bytes);
            $stage=self::stage($zip,$dir,$input['expected_slug']??null,ConnectionContext::maintenance());if(is_wp_error($stage))return Result::error($stage);
            if(dirname($stage['plugin'])===basename(rtrim(F3_MCP_FILES_DIR,'/'))){$preload=SelfUpdate::preload();if(is_wp_error($preload))return Result::error($preload);Recovery::install_sentinel();}
            return self::replace($stage,$input,null);
        } finally {Engine::remove($dir);}
    }
    private static function stage(string $zip,string $directory,?string $expected,bool $allow_self=false) {
        $out=$directory.'/expanded';if(!mkdir($out,0700))return new \WP_Error('package_stage_failed','Staging indisponível.');
        try {$list=ZipPackage::extract($zip,$out);}catch(\Throwable $error){return new \WP_Error('package_zip_invalid','ZIP inválido: integridade, tipo, caminho ou limite de expansão não aprovado.');}
        if(!$list||count($list)>20000)return new \WP_Error('package_zip_invalid','ZIP inválido ou com entradas demais.');
        $root=null;$expanded=0;$seen=[];
        foreach($list as $entry){
            $name=(string)$entry['filename'];
            if(str_contains($name,'\\')||preg_match('~(^/|(^|/)\.\.?(/|$)|[\x00-\x1f:])~',$name)||strlen($name)>1024)return new \WP_Error('package_path_invalid','Caminho inseguro no ZIP.');
            $parts=explode('/',rtrim($name,'/'));$first=$parts[0];
            if(!preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$/D',$first)||count($parts)<2&&empty($entry['folder']))return new \WP_Error('package_root_invalid','ZIP deve ter uma única pasta raiz de plugin.');
            if($root!==null&&$root!==$first)return new \WP_Error('package_multiple_roots','ZIP contém mais de uma raiz.');$root=$first;
            if(isset($seen[$name]))return new \WP_Error('package_duplicate_entry','Entrada duplicada no ZIP.');$seen[$name]=true;
            $expanded+=(int)$entry['size'];if($expanded>134217728)return new \WP_Error('package_expansion_limit','Expansão supera 128 MiB.');
        }
        if($expected!==null&&$expected!==$root)return new \WP_Error('package_slug_conflict','Raiz do ZIP difere de expected_slug.',['conflict'=>true]);
        if(!$allow_self&&$root===basename(rtrim(F3_MCP_FILES_DIR,'/')))return new \WP_Error('self_update_requires_recovery','Upload não pode substituir o próprio servidor. Use o canal de atualização homologado.');
        
        $tree=$out.'/'.$root;Engine::manifest($tree);$plugins=[];
        foreach(glob($tree.'/*.php')?:[] as $file){$data=get_plugin_data($file,false,false);if(!empty($data['Name']))$plugins[basename($file)]=$data;}
        if(count($plugins)!==1)return new \WP_Error('package_entrypoint_ambiguous','Pacote precisa de um entrypoint de plugin inequívoco na raiz.');
        $entry=array_key_first($plugins);$data=$plugins[$entry];
        if(!is_wp_version_compatible($data['RequiresWP']??'')||!is_php_version_compatible($data['RequiresPHP']??''))return new \WP_Error('package_requirements','Requisitos WordPress/PHP não atendidos.');
        return ['root'=>$root,'plugin'=>$root.'/'.$entry,'path'=>$tree,'zip'=>$zip,'data'=>$data,'zip_sha256'=>hash_file('sha256',$zip)];
    }
    public static function update(array $input): array {
        if($error=self::filesystem())return $error;$plugin=$input['plugin'];$plugins=get_plugins();
        if(!isset($plugins[$plugin]))return Result::fail('plugin_not_found','Plugin não encontrado.');
        $self=dirname($plugin)===basename(rtrim(F3_MCP_FILES_DIR,'/'));
        if($self){$preload=SelfUpdate::preload();if(is_wp_error($preload))return Result::error($preload);Recovery::install_sentinel();}
        $active=is_plugin_active($plugin);wp_update_plugins();$offers=get_site_transient('update_plugins');$offer=$offers->response[$plugin]??null;
        if(!$offer)return Result::ok(self::versions($plugin,$plugins[$plugin]['Version'],$plugins[$plugin]['Version'],$active,$active,false));
        if(empty($offer->package))return Result::fail('plugin_update_unavailable','Oferta sem URL de pacote.');
        $dir=StateStore::directory('package-staging').'/'.bin2hex(random_bytes(16));mkdir($dir,0700);
        try {
            $zip=$dir.'/package.zip';
            if(in_array($plugin,UpdateChannel::PACKAGES,true)){$download=UpdateChannel::download(false,$offer->package,null,['plugin'=>$plugin]);if(is_wp_error($download))return Result::error($download);try{if(!copy($download,$zip))return Result::fail('package_stage_failed','Falha de staging.');}finally{unlink($download);}}
            else{$response=Http::fetch($offer->package,16777216);if(is_wp_error($response))return Result::error($response);Engine::atomic($zip,$response['body'],0600);}
            if(!empty($offer->f3_sha256)&&!hash_equals(strtolower($offer->f3_sha256),hash_file('sha256',$zip)))return Result::fail('package_hash_conflict','ZIP não corresponde ao digest da oferta.',['conflict'=>true]);
            $stage=self::stage($zip,$dir,dirname($plugin),$self);if(is_wp_error($stage))return Result::error($stage);
            if($stage['plugin']!==$plugin||$stage['data']['Version']!==$offer->new_version)return Result::fail('package_identity_conflict','Entrypoint/versão diverge da oferta.',['conflict'=>true]);
            return self::replace($stage,$input+['overwrite'=>true,'activate'=>$active],$plugin);
        } finally {Engine::remove($dir);}
    }
    private static function versions(string $plugin,?string $old,?string $new,bool $before,bool $after,bool $changed): array {
        return ['plugin'=>$plugin,'old_version'=>$old,'version'=>$new,'versao_anterior'=>$old,'versao'=>$new,'changed'=>$changed,'mudou'=>$changed,'active_before'=>$before,'active_after'=>$after,'active'=>$after,'activated'=>$after];
    }
    private static function replace(array $stage,array $input,?string $updating): array {
        $timeout=(int)($input['probe_timeout_seconds']??15);if($timeout<1||$timeout>30)return Result::fail('probe_limits','probe_timeout_seconds aceita 1 a 30.');
        $plugin=$stage['plugin'];$target=WP_PLUGIN_DIR.'/'.$stage['root'];$all=get_plugins();$exists=is_dir($target);$old=$all[$plugin]['Version']??null;$active=isset($all[$plugin])&&is_plugin_active($plugin);
        if(($pending=self::pending_for($plugin))!==null)return Result::fail('package_verification_pending','Existe troca pendente deste pacote; consulte e reconcilie a operação.',['package_operation_id'=>$pending,'applied'=>null,'pending'=>true,'retryable'=>false]);
        if($exists&&empty($input['overwrite']))return Result::fail('package_exists','overwrite:true é necessário para substituir.');
        if($exists&&!isset($all[$plugin]))return Result::fail('package_identity_conflict','Pasta existente não corresponde ao entrypoint do pacote.');
        if($exists&&!current_user_can('update_plugins'))return Result::fail('permission_denied','Substituição exige update_plugins.');
        $desired_active=$active||!empty($input['activate']);if($desired_active&&!current_user_can('activate_plugins'))return Result::fail('permission_denied','Ativação exige activate_plugins.');
        $baseline=Probe::run(['contexto_teste'=>true]);if(!Recovery::verified($baseline))return Result::fail('package_baseline_failed','Sonda inicial inconclusiva ou reprovada; pacote não alterado.',['applied'=>false,'probe_before'=>$baseline]);
        $expected=Engine::digest(Engine::manifest($stage['path']));
        if($exists&&Engine::digest(Engine::manifest($target))===$expected&&$desired_active===$active)return Result::ok(self::versions($plugin,$old,$old,$active,$active,false)+['probe_before'=>$baseline]);
        $op=Recovery::begin($target,$expected,['lock_root'=>WP_PLUGIN_DIR,'plugin'=>$plugin,'active_before'=>$active,'old_version'=>$old,'desired_active'=>$desired_active,'expected_version'=>$stage['data']['Version'],'verification_policy'=>'conservative-1','probe_timeout_seconds'=>$timeout,'expected_runtime_version'=>dirname($plugin)===basename(rtrim(F3_MCP_FILES_DIR,'/'))?$stage['data']['Version']:null]);
        $data=['operation_id'=>$op['state']['id'],'package_operation_id'=>$op['state']['id'],'backup_id'=>$op['state']['backup_id'],'zip_sha256'=>$stage['zip_sha256'],'probe_before'=>$baseline,'database_effects_reversible'=>false];
        try {
            if($updating!==null){
                $download=static function($reply,$url)use($stage){return $stage['zip'];};add_filter('upgrader_pre_download',$download,1,2);
                ob_start();try {$upgrader=new AtomicPluginUpgrader($stage,$op['file']);$result=$upgrader->upgrade($plugin);}finally{ob_end_clean();remove_filter('upgrader_pre_download',$download,1);}
                if(is_wp_error($result)||!$result) return self::recover($op,$data+['upgrader_error_code'=>is_wp_error($result)?$result->get_error_code():'upgrade_failed'],'package_update_failed',$plugin,$old,$active);
            }else{
                if($active)deactivate_plugins($plugin,true);
                $upgrader=new AtomicPluginUpgrader($stage,$op['file']);
                ob_start();try {$result=$upgrader->install($stage['zip'],['overwrite_package'=>$exists]);}finally{ob_end_clean();}
                if(is_wp_error($result)||!$result)return self::recover($op,$data,'package_install_failed',$plugin,$old,$active);
            }
            wp_clean_plugins_cache(false);$actual=Engine::digest(Engine::manifest($target));
            if($actual!==$expected)return self::recover($op,$data,'package_postimage_mismatch',$plugin,$old,$active);
            Recovery::close($op,'applied');
            if($desired_active){$activation=self::activate_fresh($plugin,$expected,$op['state']['id'],$timeout);$data['activation']=$activation;if(empty($activation['success']))return !empty($activation['definitive_failure'])?self::recover($op,$data,'package_activation_failed',$plugin,$old,$active):self::pending($op,$data,'activation_inconclusive');}
            $data['cache_invalidation']=self::invalidate_cache();
            $probe=Probe::package($timeout);$data['probe_after']=$probe;
            if(!Recovery::verified($probe))return self::definitive($probe)?self::recover($op,$data,'package_verification_failed',$plugin,$old,$active):self::pending($op,$data,'probe_inconclusive');
            wp_clean_plugins_cache(false);$all=get_plugins();$now=is_plugin_active($plugin);
            if($now!==$desired_active||($all[$plugin]['Version']??null)!==$stage['data']['Version'])return self::pending($op,$data,'package_state_mismatch');
            $s=Engine::read($op['file']);$s['verification_evidence']=$data;$s['verification_reason']='verified';$s['verification_observed_at']=time();Engine::write($op['file'],$s);Recovery::close($op,'complete');return Result::ok(self::versions($plugin,$old,$all[$plugin]['Version'],$active,$now,true)+$data+['applied'=>true,'recovery_status'=>'applied']);
        }catch(\Throwable $e){$state=Engine::read($op['file']);if(($state['install_phase']??'')==='installed'&&empty($state['rollback_authorized']))return self::pending($op,$data,'verification_exception');return self::recover($op,$data,'package_exception',$plugin,$old,$active);}
        finally {Recovery::release($op);}
    }
    private static function definitive(array $probe): bool {
        foreach($probe['samples']??[] as $row)if((int)($row['status_code']??0)>=500)return true;
        return false;
    }
    /** Merge observations without overwriting a concurrently completed activation worker. */
    private static function journal_patch(string $file,array $patch): array {
        $h=fopen($file.'.state-lock','c+b');if(!$h)throw new \RuntimeException('Journal lock unavailable.');
        try{if(!flock($h,LOCK_EX))throw new \RuntimeException('Journal lock unavailable.');$s=Engine::read($file);if(!$s)throw new \RuntimeException('Recovery journal unavailable.');$s=array_replace($s,$patch);Engine::write($file,$s);return $s;}
        finally{flock($h,LOCK_UN);fclose($h);}
    }
    /** A timeout is not proof of a failed migration. Preserve the candidate and its preimage. */
    private static function pending(array &$op,array $data,string $reason): array {
        $state=self::journal_patch($op['file'],['verification_reason'=>$reason,'verification_observed_at'=>time(),'verification_evidence'=>$data,'status'=>'verification_pending','finished_at'=>time()]);$op['state']=$state;
        wp_clean_plugins_cache(false);$all=get_plugins();wp_cache_delete('active_plugins','options');wp_cache_delete('alloptions','options');
        return Result::fail('package_verification_pending','Arquivos preservados; consulte plugins/operation-status e execute plugins/reconcile antes de repetir upload.',self::versions($state['plugin'],$state['old_version'],$all[$state['plugin']]['Version']??null,$state['active_before'],is_plugin_active($state['plugin']),true)+$data+[
            'operation_id'=>$state['id'],'package_operation_id'=>$state['id'],'backup_id'=>$state['backup_id'],'applied'=>null,'files_applied'=>true,'pending'=>true,'retryable'=>false,'verification_state'=>'inconclusive','verification_reason'=>$reason,'recovery_status'=>'verification_pending','database_effects_reversible'=>false,
        ]);
    }
    private static function pending_for(string $plugin): ?string {
        foreach(glob(Recovery::directory().'/active/*.php')?:[] as $pointer){
            $id=Engine::read($pointer)['id']??'';if(!preg_match('/^[a-f0-9]{32}$/D',$id))continue;
            $s=Engine::read(Recovery::directory().'/'.$id.'.journal.php');
            if($s&&($s['plugin']??'')===$plugin&&($s['verification_policy']??'')==='conservative-1'&&!in_array($s['status'],['complete','rolled_back','unchanged'],true))return $id;
        }
        return null;
    }
    private static function operation(string $id) {
        if(!preg_match('/^[a-f0-9]{32}$/D',$id))return new \WP_Error('package_operation_not_found','Identidade de operação inválida.');
        $s=Engine::read(Recovery::directory().'/'.$id.'.journal.php');
        if(!$s||empty($s['plugin'])||$s['connection_id']!==ConnectionContext::key())return new \WP_Error('package_operation_not_found','Operação não pertence à conexão.');
        return $s;
    }
    public static function operation_status(array $i): array {
        $s=self::operation((string)$i['operation_id']);if(is_wp_error($s))return Result::error($s);
        require_once ABSPATH.'wp-admin/includes/plugin.php';wp_clean_plugins_cache(false);$all=get_plugins();
        $digest=Engine::digest(Engine::manifest($s['target']));
        return Result::ok(['package_operation_id'=>$s['id'],'status'=>$s['status'],'plugin'=>$s['plugin'],'version'=>$all[$s['plugin']]['Version']??null,'active'=>is_plugin_active($s['plugin']),'backup_id'=>$s['backup_id'],'file_state'=>$digest===$s['after_sha256']?'candidate':($digest===$s['before_sha256']?'preimage':'diverged'),'expected_version'=>$s['expected_version']??null,'desired_active'=>$s['desired_active']??null,'probe_timeout_seconds'=>$s['probe_timeout_seconds']??null,'rollback_authorized'=>!empty($s['rollback_authorized']),'activation_status'=>$s['activation_status']??'not_requested','verification_reason'=>$s['verification_reason']??null,'verification_observed_at'=>$s['verification_observed_at']??null,'verification_evidence'=>$s['verification_evidence']??null,'database_effects_reversible'=>false,'read_only'=>true]);
    }
    public static function reconcile(array $i): array {
        if($error=self::filesystem())return $error;$state=self::operation((string)$i['operation_id']);if(is_wp_error($state))return Result::error($state);
        if(($state['verification_policy']??'')!=='conservative-1')return Result::fail('package_reconciliation_unsupported','Use a recuperação do contrato original para esta operação.');
        if(in_array($state['status'],['complete','rolled_back','unchanged'],true))return self::operation_status($i)+['replayed'=>true];
        if(!in_array($state['status'],['verification_pending','applied'],true))return Result::fail('package_operation_busy','Troca ainda em andamento ou recuperação estrutural pendente.');
        $timeout=(int)($i['probe_timeout_seconds']??$state['probe_timeout_seconds']??15);if($timeout<1||$timeout>30)return Result::fail('probe_limits','probe_timeout_seconds aceita 1 a 30.');
        if(!empty($state['desired_active'])&&!current_user_can('activate_plugins'))return Result::fail('permission_denied','Reconciliação de ativação exige activate_plugins.');
        $file=Recovery::directory().'/'.$state['id'].'.journal.php';$lease=fopen($file.'.lease','c+b');
        if(!$lease||!flock($lease,LOCK_EX|LOCK_NB)){if($lease)fclose($lease);return Result::fail('package_operation_busy','Executor original ainda possui a operação.');}
        $state=Engine::read($file);$op=['state'=>$state,'file'=>$file,'lease'=>$lease];$data=$state['verification_evidence']??[];
        try{
            if(Engine::digest(Engine::manifest($state['target']))!==$state['after_sha256'])return Result::fail('package_postimage_conflict','Pacote mudou; não sondar/reativar/restaurar por este recibo.',['conflict'=>true,'applied'=>null]);
            if(!empty($state['rollback_authorized']))return self::recover($op,$data,'package_rollback_requested',$state['plugin'],$state['old_version'],$state['active_before']);
            if(!empty($state['desired_active'])){
                if(!isset($state['activation_status'])||(($state['activation_status']??'')==='pending'&&($state['activation_expires']??0)<time())){
                    // The old worker can no longer claim this token and never entered its effect.
                    $data['activation']=self::activate_fresh($state['plugin'],$state['after_sha256'],$state['id'],$timeout);$state=Engine::read($file);
                    if(empty($data['activation']['success'])&&!empty($data['activation']['definitive_failure']))return self::recover($op,$data,'package_activation_failed',$state['plugin'],$state['old_version'],$state['active_before']);
                }
                if(($state['activation_status']??'')!=='complete')return self::pending($op,$data,'activation_inconclusive');
                if(empty($state['activation_success']))return self::recover($op,$data,'package_activation_failed',$state['plugin'],$state['old_version'],$state['active_before']);
            }
            $probe=Probe::package($timeout);$data['probe_after']=$probe;
            if(!Recovery::verified($probe))return self::definitive($probe)?self::recover($op,$data,'package_verification_failed',$state['plugin'],$state['old_version'],$state['active_before']):self::pending($op,$data,'probe_inconclusive');
            wp_clean_plugins_cache(false);wp_cache_delete('active_plugins','options');wp_cache_delete('alloptions','options');$all=get_plugins();
            if(($all[$state['plugin']]['Version']??null)!==$state['expected_version']||is_plugin_active($state['plugin'])!==$state['desired_active'])return self::pending($op,$data,'package_state_mismatch');
            $op['state']=Engine::read($file);$op['state']['verification_evidence']=$data;$op['state']['verification_reason']='verified';$op['state']['verification_observed_at']=time();Engine::write($file,$op['state']);Recovery::close($op,'complete');
            return Result::ok(self::versions($state['plugin'],$state['old_version'],$state['expected_version'],$state['active_before'],$state['desired_active'],true)+$data+['applied'=>true,'pending'=>false,'package_operation_id'=>$state['id'],'backup_id'=>$state['backup_id'],'recovery_status'=>'applied','reconciled'=>true,'database_effects_reversible'=>false]);
        }finally{Recovery::release($op);}
    }
    private static function recover(array &$op,array $data,string $code,string $plugin,?string $old,bool $active): array {
        self::journal_patch($op['file'],['rollback_authorized'=>true]);
        $data+=['database_effects_reversible'=>false,'package_operation_id'=>$op['state']['id']];
        $restore=Engine::restore($op['file'],true);wp_clean_plugins_cache(false);$current=get_plugins();
        if($restore['status']==='rolled_back'){
            $list=(array)get_option('active_plugins',[]);$list=array_values(array_diff($list,[$plugin]));if($active)$list[]=$plugin;sort($list);update_option('active_plugins',$list);
            $data['cache_invalidation']=self::invalidate_cache();
            $data['probe_recovery']=Probe::run(['contexto_teste'=>true]);
        }
        return Result::fail($restore['status']==='rolled_back'?$code:$restore['status'],'Atualização não concluída; consulte recuperação e estado final.',self::versions($plugin,$old,$current[$plugin]['Version']??null,$active,is_plugin_active($plugin),$restore['status']!=='rolled_back')+$data+['applied'=>$restore['status']==='rolled_back'?false:null,'attempted_change'=>true,'recovery'=>$restore,'recovery_status'=>$restore['status']]);
    }
    /** Provider API invocation is separate from proof of public cache freshness. */
    private static function invalidate_cache(): array {
        if(!is_callable(['F3Base_Cache_Pagina','limpar']))return ['status'=>'unavailable','provider'=>'base-site-core-fator3','public_cache_verified'=>false];
        try {
            $result=\F3Base_Cache_Pagina::limpar(false,'mcp_package_change');
            return ['status'=>!empty($result['ok'])?'requested':'failed','provider'=>'base-site-core-fator3','provider_code'=>$result['codigo']??null,'public_cache_verified'=>false];
        } catch(\Throwable $error) {return ['status'=>'failed','provider'=>'base-site-core-fator3','public_cache_verified'=>false];}
    }
    public static function activate_fresh(string $plugin,string $digest,string $operation,int $timeout=15): array {
        $journal=Recovery::directory().'/'.$operation.'.journal.php';$state=Engine::read($journal);$context=ConnectionContext::get();
        if(!$state||!$context||$state['plugin']!==$plugin||$state['after_sha256']!==$digest)return Result::fail('activation_invalid','Diário não corresponde ao pacote.');
        $token=bin2hex(random_bytes(32));self::journal_patch($journal,['activation_token'=>hash('sha256',$token),'activation_expires'=>time()+max(30,$timeout+15),'activation_status'=>'pending','activation_policy_version'=>$context['policy_version']??0]);
        $url=rest_url('f3-mcp-recovery/v1/activate');if(wp_parse_url($url,PHP_URL_HOST)!==wp_parse_url(home_url(),PHP_URL_HOST))return Result::fail('activation_origin_invalid','REST e home divergem de origem.');
        $r=wp_remote_post($url,['timeout'=>$timeout,'redirection'=>0,'cookies'=>[],'sslverify'=>true,'headers'=>['Content-Type'=>'application/json','X-F3-Activation'=>$token,'X-F3-Operation'=>$operation],'body'=>'{}','limit_response_size'=>65536]);
        $state=Engine::read($journal);wp_cache_delete('active_plugins','options');wp_cache_delete('alloptions','options');
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200||($state['activation_status']??'')!=='complete'||empty($state['activation_success'])||!is_plugin_active($plugin))return Result::fail('activation_unconfirmed','Ativação no executor independente não foi confirmada.',['active'=>is_plugin_active($plugin),'status_code'=>is_wp_error($r)?null:wp_remote_retrieve_response_code($r),'error_code_transport'=>is_wp_error($r)?$r->get_error_code():null,'definitive_failure'=>(!is_wp_error($r)&&wp_remote_retrieve_response_code($r)>=500)||(($state['activation_status']??'')==='complete'&&empty($state['activation_success']))]);
        return Result::ok(['active'=>true,'fresh_php_request'=>true,'independent_worker'=>true]);
    }
    public static function rollback(array $input): array {
        if($error=self::filesystem())return $error;$backup=Backups::metadata($input['backup_id']);if(is_wp_error($backup))return Result::error($backup);
        $id=$backup['snapshot']['journal_id']??'';if(!preg_match('/^[a-f0-9]{32}$/D',$id))return Result::fail('backup_type_mismatch','Backup não é pré-imagem recuperável de pacote.');
        $file=Recovery::directory().'/'.$id.'.journal.php';$state=Engine::read($file);
        if($state&&dirname($state['plugin']??'')===basename(rtrim(F3_MCP_FILES_DIR,'/'))){$preload=SelfUpdate::preload();if(is_wp_error($preload))return Result::error($preload);}if(!$state||empty($state['plugin'])||$state['connection_id']!==ConnectionContext::key())return Result::fail('backup_access_denied','Pré-imagem não pertence a esta conexão/pacote.');
        if($state['status']==='rolled_back')return Result::ok(['changed'=>false,'recovery_status'=>'rolled_back']);
        if(!in_array($state['status'],['complete','verification_pending'],true))return Result::fail('recovery_required','Operação original não terminou; reconcilie o diário.');
        if(Engine::digest(Engine::manifest($state['target']))!==$state['after_sha256'])return Result::fail('rollback_conflict','Pacote mudou depois da operação.',['conflict'=>true]);
        $state['status']='applied';Engine::write($file,$state);$op=['state'=>$state,'file'=>$file];
        $result=self::recover($op,[],'rollback_requested',$state['plugin'],$state['old_version'],$state['active_before']);
        if(($result['recovery_status']??'')==='rolled_back'&&Recovery::verified($result['probe_recovery']??[])){unset($result['error_code']);$result['success']=true;$result['changed']=true;$result['mudou']=true;$result['message']='Pacote restaurado e sonda aprovada.';}
        return $result;
    }
}
