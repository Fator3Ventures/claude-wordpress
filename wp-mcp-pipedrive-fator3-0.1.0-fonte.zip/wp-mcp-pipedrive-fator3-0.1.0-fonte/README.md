# Fonte — Fator3 MCP Pipedrive 0.1.0

Primeira versão; estado da entrega: **com-pendencias**. O runtime foi instalado pelo ZIP e testado em WordPress 7.1.3, PHP 8.3.36, MySQL 8.0.41. O contrato `pipedrive-api-client/1.0.0` ainda precisa ser implementado e confirmado pelo mantenedor do Site Core. Core 1.50.0 não o fornece. Nenhum teste usou uma conta real do Pipedrive.

## Conteúdo

* `plugin/wp-mcp-pipedrive-fator3/`: runtime completo, GPL-2.0-or-later, nove documentos e schemas; exatamente os arquivos do instalador testado.
* `build/package.py`: empacotamento determinístico com biblioteca padrão Python, sem dependências externas.
* `build/schemas.php`: exporta o schema real de `Api.php`; não exige WordPress instalado.
* `build/verify.py`: lint PHP, confronto do instalador e dos vinte hashes da instalação testada, documentação, separação de QA e reprodução do build.
* `tests/`: bateria nativa, integração MCP, concorrência em dois processos e executores do laboratório descartável.
* `evidence/`: entradas identificadas, instalação, testes, identidade do runtime e limpeza sanitizadas.
* `inputs/`: pedidos, relatórios-base e normas vigentes recebidos; não são comprovação própria dos testes de outros responsáveis.
* `PLANO.md`, relatório interno e impacto para o Core: planejamento, resultados e pedido de contrato.

## Reprodução do build

Ferramentas usadas: Python 3.12.14, `zipfile`/zlib da distribuição; PHP CLI 8.3.6 somente para lint e exportação local. As provas funcionais usaram PHP 8.3.36. Não há Composer, npm, dependências baixadas durante build ou lockfile aplicável.

Na raiz deste fonte, com `php` disponível no PATH:

```sh
php build/schemas.php > /tmp/pipedrive-schemas.json
cmp /tmp/pipedrive-schemas.json plugin/wp-mcp-pipedrive-fator3/docs/schemas.json
python3 build/package.py installer --out /tmp/pipedrive-build
python3 build/verify.py --php php --installer /tmp/pipedrive-build/wp-mcp-pipedrive-fator3-0.1.0-instalador.zip
python3 build/package.py source --out /tmp/pipedrive-build
```

O instalador tem uma única raiz sem versão. O fonte tem uma única raiz com versão e não inclui ZIPs. A reprodução binária foi conferida com a ferramenta acima; outras versões de zlib podem gerar bytes ZIP diferentes, devendo-se comparar também os arquivos extraídos. Para reproduzir o fonte, mantenha todos os arquivos, inclusive esta cópia do relatório anterior ao fechamento. Não tente inserir o hash do ZIP dentro dele.

Só o instalador é enviado ao WordPress. Documentação operacional: `plugin/wp-mcp-pipedrive-fator3/docs/README.md`. Testes: `tests/README.md`. Publicação e escolha do site-porta pertencem à frota; o fonte permanece com o dono conforme decisão 89 ainda pendente.
