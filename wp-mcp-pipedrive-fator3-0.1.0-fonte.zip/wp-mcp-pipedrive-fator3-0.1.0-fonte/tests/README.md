# Testes da versão 0.1.0

Executar exclusivamente em WordPress descartável, com banco/prefixo isolado e sem credenciais de fornecedores. As baterias alteram suas próprias tabelas, usuários, opções e políticas MCP do laboratório. Nunca carregá-las em produção. O instalador não contém estes arquivos.

## Ambiente e sequência usados

WordPress 7.1.3, PHP 8.3.36, MySQL 8.0.41/InnoDB; site único. Arquivos nativos do WordPress e dos cinco acompanhantes foram reutilizados somente para leitura. O laboratório teve `wp-content`, usuários, salts e prefixo próprios. HTTP externo e e-mail foram bloqueados desde o bootstrap por MU plugin; cron foi desabilitado. Configuração privada permaneceu fora do webroot, permissão 0600, e foi removida na limpeza.

`lab-controller.php` é a cópia exata do controlador temporário usado: registra somente `qa-pipedrive/run`, com ações enumeradas, `manage_options` e política MCP de escrita. O controlador só deve ser disponibilizado no Site-Teste com a autorização operacional correspondente e deve ser removido ao final. A configuração dinâmica do banco não integra este fonte. Ele cria `/tmp/f3-pipedrive-qa-d848899a8f83`, com marcador de propriedade, e o prefixo exclusivo `f3pipqa_d848_`; recusa diretório preexistente sem marcador. A limpeza não segue links e só seleciona esse prefixo. Antes de uma nova execução, garantir que esse namespace está livre e reservado ao teste; não adaptar os filtros para alcançar tabelas de negócio.

O bundle privado usado pelo controlador continha `runner.php` (cópia de `lab-runner.php`), `installer.zip` (os bytes finais indicados no relatório) e `tests/native.php`, `tests/integrated.php`, `tests/race-worker.php`. Ele não é um artefato de distribuição. Não colocar configuração, credencial ou banco nesse bundle. Os acompanhantes necessários ao teste integrado são os slugs/versões do relatório, presentes no WordPress hospedeiro.

Sequência pelo executor MCP existente, com objeto de entrada `{"acao":"<ação>"}`:

1. `setup`: prepara o ambiente privado e bloqueios de saída.
2. `install`: processo PHP novo; `Plugin_Upgrader` instala o instalador ZIP, ativa e relê o schema.
3. `run`: processo novo; 74 verificações nativas com cliente Core simulado.
4. `integrate`: ativa Core 1.50.0, MCP 0.29.1, Google 0.19.0, Meta 0.9.0 e LinkedIn 0.10.1 somente no laboratório.
5. `integrated`: processo novo; 24 verificações do executor e política MCP originais, incluindo leitura integral dos nove documentos em 18 páginas e hashes de todos os arquivos instalados.
6. `cleanup`: remove somente o ambiente marcado; conferir retorno e ausência do diretório/tabelas. Remover bundle e controlador temporários com hash esperado; conferir que a ability temporária desapareceu e que o inventário do site hospedeiro não mudou.

Para execução exclusivamente local, reproduzir essa mesma disposição em diretório privado e preparar um WordPress descartável cujo prefixo comece com `f3pipqa_`, usando credenciais de um banco de testes e o mesmo bloqueio de saída. Executar `php runner.php install`, `run`, `integrate` e `integrated`. `race-worker.php` é iniciado pela suíte nativa em dois processos independentes; requer `proc_open` e acesso ao mesmo MySQL. Não omitir o marcador `F3_PIPEDRIVE_DISPOSABLE` nem as guardas de prefixo.

## Limites da prova

`native.php` simula o cliente do **contrato proposto**, seus códigos, saldo e orçamento. Não comprova reserva, autorização, barreira de recuperação, token, transporte HTTP ou efeito no fornecedor implementados pelo Core futuro. `integrated.php` utiliza os plugins originais efetivamente carregados, mas sua invocação do executor é PHP dentro do WordPress; não é uma sessão HTTP MCP independente para o provider Pipedrive. As evidências distinguem ambas as coisas.

A reinstalação comprovada pela bateria reexecuta a instalação do schema e preserva recibos. Não houve atualização nativa a partir de uma versão Pipedrive anterior, porque não existe base publicada recebida. O painel foi renderizado e conferido no PHP, sem validação visual em navegador.

Tentativas preliminares corrigiram configuração do bootstrap do laboratório, uma variável do harness reutilizada e um teste que atribuía ao normalizador genérico a redação que pertence ao provider. Esses resultados não foram somados aos testes aprovados; os JSONs da rodada final são a evidência da entrega. Nenhum bug dessas tentativas exigiu alteração dos plugins acompanhantes.
