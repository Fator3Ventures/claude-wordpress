<?php
// Only usable from the private disposable laboratory created by the QA controller.
$mode=$argv[1]??'run';
if (!in_array($mode,['install','run','integrate','integrated'],true)) { exit(2); }
define('F3_PIPEDRIVE_DISPOSABLE',true);
if ($mode==='install') { define('WP_INSTALLING',true); }
define('ABSPATH',__DIR__.'/wordpress/');
require ABSPATH.'wp-load.php';
add_filter('pre_http_request',static fn()=>new WP_Error('qa_network_blocked','External HTTP disabled in laboratory'),PHP_INT_MIN);
add_filter('pre_wp_mail',static fn()=>true,PHP_INT_MIN);
require_once ABSPATH.'wp-admin/includes/plugin.php';
$result=[];
try {
 if ($mode==='install') {
  require_once ABSPATH.'wp-admin/includes/upgrade.php';
  if (!is_blog_installed()) { wp_install('Pipedrive disposable QA','qa_admin','qa@example.test',true,'',wp_generate_password(40)); }
  wp_set_current_user(1);
  if (!file_exists(WP_PLUGIN_DIR.'/wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php')) {
   if (!defined('FS_METHOD'))define('FS_METHOD','direct');
   require_once ABSPATH.'wp-admin/includes/class-wp-upgrader.php';
   $up=new Plugin_Upgrader(new Automatic_Upgrader_Skin());$installed=$up->install(__DIR__.'/installer.zip');
   if ($installed!==true)throw new RuntimeException('Native ZIP installation failed');
  }
  $r=activate_plugin('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php');
  if (is_wp_error($r)) { throw new RuntimeException('Activation failed: '.$r->get_error_code()); }
  $result=['installed'=>true,'wp'=>$wp_version,'php'=>PHP_VERSION,'plugin_active'=>is_plugin_active('wp-mcp-pipedrive-fator3/wp-mcp-pipedrive-fator3.php'),'storage'=>get_option('f3_pipedrive_schema')];
 } elseif ($mode==='run') {
  $result=require __DIR__.'/tests/native.php';
 } elseif ($mode==='integrate') {
  wp_set_current_user(1);
  $r=activate_plugin('wp-mcp-fator3/wp-mcp-fator3.php');
  foreach(['base-site-core-fator3','wp-mcp-google-fator3','wp-mcp-meta-fator3','wp-mcp-linkedin-fator3'] as $slug){$other=activate_plugin($slug.'/'.$slug.'.php');if(is_wp_error($other))throw new RuntimeException('Companion activation: '.$slug.' '.$other->get_error_code());}
  $result=['mcp_active'=>!is_wp_error($r),'error'=>is_wp_error($r)?$r->get_error_code():null,'companions_active'=>true];
 } elseif ($mode==='integrated') {
  $result=require __DIR__.'/tests/integrated.php';
 }
} catch (Throwable $e) { $result=['exception'=>get_class($e),'message'=>$e->getMessage(),'line'=>$e->getLine(),'file'=>basename($e->getFile()),'checks_so_far'=>$checks??[]]; }
echo "F3_QA_RESULT=".json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
