<?php
/** Execute in a disposable WordPress only. Provider HTTP is entirely simulated. */
declare(strict_types=1);
use Fator3\Pipedrive\{Api,CoreClient,Documentation,Policy,Store,Support,Fault};
if (!defined('F3_PIPEDRIVE_DISPOSABLE') || F3_PIPEDRIVE_DISPOSABLE !== true) { throw new RuntimeException('Disposable test marker required'); }
require_once ABSPATH.'wp-admin/includes/plugin.php';
$checks=[];
$assert=static function(string $name,bool $ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>$ok];};
$call=static fn($op,$input=[])=>Api::dispatch($op,$input);
wp_set_current_user(1);
$assert('core_ausente_status_sem_fatal',$call('status')['code']==='core_indisponivel');
$assert('seis_schemas',count(Api::schemas())===6);
$assert('sem_cron_pipedrive',!str_contains(json_encode(_get_cron_array()),'pipedrive'));
$http=0;$block=static function($pre)use(&$http){++$http;return new WP_Error('qa_http','HTTP blocked in fixture');};add_filter('pre_http_request',$block,1);
$d=$call('documentacao-ler');$assert('documentacao_independente',$d['success']&&$http===0);
$assert('traversal_recusado',$call('documentacao-ler',['documento'=>'../../wp-config.php'])['code']==='documento_invalido');
$assert('schema_fechado',$call('status',['unknown'=>true])['code']==='entrada_invalida');

final class FixtureClient {
    public int $calls=0;public int $writes=0;public bool $allowed=true;public string $revision='r1';public string $guard='';
    public bool $timeout=false;public bool $huge=false;public bool $errorBody=false;public bool $reenter=false;public ?array $reentrant=null;
    public int $budget=3000;public int $spent=0;public int $balance=15000;public array $lastBody=[];
    public array $records=[];public array $fields=[];public array $labels=[];public array $paths=[];public bool $pageFields=false;
    public function capabilities(){return ['contract'=>'pipedrive-api-client/1.0.0'];}
    public function status(){
        if (!$this->allowed) { return ['success'=>false,'code'=>'operacao_nao_autorizada']; }
        if ($this->guard) { return ['success'=>false,'code'=>$this->guard]; }
        return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'revisao'=>$this->revision,
            'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>1,'usuario_id'=>2],
            'orcamento'=>['teto'=>$this->budget,'consumido'=>$this->spent,'reservado'=>0],'saldo_conta'=>['restante'=>$this->balance,'lido_em'=>'2026-10-23T20:00:00Z']]];
    }
    public function request($m,$p,$q,$b,$c){
        $cost=$m==='GET'?20:10;
        if ($this->balance<3000) { return ['success'=>false,'code'=>'saldo_conta_baixo','remote_dispatched'=>false]; }
        if ($this->spent+$cost>$this->budget) { return ['success'=>false,'code'=>'orcamento_esgotado','remote_dispatched'=>false]; }
        ++$this->calls;$this->paths[]=$p;$this->spent+=$cost;$this->balance-=$cost;
        if ($m!=='GET') {
            ++$this->writes;$this->lastBody=$b;
            if ($this->reenter) { $this->reenter=false;$this->reentrant=Api::dispatch('api-aplicar',['previa_id'=>$c['previa_id']]); }
            if ($this->timeout) { throw new RuntimeException('Sensitive upstream api_token=secret-canary-fixture'); }
            if ($this->errorBody) { return ['success'=>false,'remote_dispatched'=>true,'data'=>['http_status'=>400,'body'=>['error'=>'api_token=secret-canary-fixture'],'saldo_conta'=>null]]; }
            if ($p==='/v1/leadLabels'&&$m==='POST') { $id='00000000-0000-4000-8000-000000000099';$this->labels[$id]=['id'=>$id]+$b;$data=$this->labels[$id]; }
            elseif ($m==='DELETE') { unset($this->records[$p]);$data=['id'=>basename($p)]; }
            else { $this->records[$p]=array_merge($this->records[$p]??['id'=>basename($p)],$b);$data=$this->records[$p]; }
        } else {
            if (str_ends_with($p,'Fields')) {
                $data=array_values($this->fields);
                if ($this->pageFields && ($q['start']??0)===0) { return $this->response([],['pagination'=>['more_items_in_collection'=>true,'next_start'=>500]]); }
            } elseif ($p==='/v1/leadLabels') { $data=array_values($this->labels); }
            elseif (isset($this->records[$p])) { $data=$this->records[$p]; }
            elseif (in_array($p,['/v1/leads','/v1/leads/archived','/v1/notes','/v1/filters','/v1/activityTypes','/api/v2/pipelines','/api/v2/stages'],true)) { $data=[]; }
            else { $data=['id'=>basename($p),'name'=>'Fixture only']; }
        }
        if ($this->huge) { $data=['content'=>str_repeat('X',524289)]; }
        return $this->response($data);
    }
    private function response($data,$additional=[]){return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$data,'additional_data'=>$additional], 'saldo_conta'=>['restante'=>$this->balance,'lido_em'=>'2026-10-23T20:00:00Z']]];}
}
$client=new FixtureClient();
$registry=new class($client){ public array $args=[];public function __construct(public $client){}public function register_consumer($p,$v,$c,$config){$this->args=[$p,$v,$c,$config()];return $this->client;} };
CoreClient::register($registry,'wrong/1.0.0');$assert('contrato_divergente_recusado',$call('status')['code']==='core_indisponivel');
CoreClient::register($registry,'pipedrive-api-client/1.0.0');
$assert('registro_provider_exato',$registry->args[0]==='wp-mcp-pipedrive-fator3');
$client->allowed=false;$assert('A1_autorizacao_negada',$call('status')['code']==='operacao_nao_autorizada'&&$client->calls===0);
$client->allowed=true;$assert('A2_status_local',$call('status')['success']&&$client->calls===0);
$assert('A3_campos_consulta',$call('api-ler',['caminho'=>'/v1/dealFields'])['success']);
$before=$client->calls;
foreach (['/v1/mailbox/mailThreads','https://api.pipedrive.com/v1/leads','/v1/leads?ids=1,2','/v1/persons/1/merge','/v1/leads/../users','/v1/leads%2F123'] as $p) {
    $assert('A4_path_'.count($checks),$call('api-ler',['caminho'=>$p])['code']==='caminho_fora_da_lista');
}
$assert('A4_zero_chamadas',$client->calls===$before);
$assert('A10_ids_query',$call('api-ler',['caminho'=>'/v1/leads','query'=>['ids'=>'1,2']])['code']==='caminho_fora_da_lista');
$assert('A10_ids_delete',$call('api-previa',['metodo'=>'DELETE','caminho'=>'/api/v2/persons/1?ids=1,2'])['code']==='caminho_fora_da_lista');
$assert('chave_nao_permitida',$call('api-previa',['metodo'=>'PATCH','caminho'=>'/v1/leads/00000000-0000-4000-8000-000000000001','corpo'=>['unknown'=>'x']])['code']==='caminho_fora_da_lista');
$lead='/v1/leads/00000000-0000-4000-8000-000000000001';$custom=str_repeat('a',40);
$client->records[$lead]=['id'=>basename($lead),'title'=>'Pessoa sintética QA','email'=>'synthetic@example.test',$custom=>100];
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>[$custom=>152,'title'=>'Valor privado de fixture']]);
$assert('A5_previa_estado_e_novo',$prev['success']&&$prev['data']['estado_atual'][$custom]===100&&$prev['data']['corpo_a_enviar'][$custom]===152);
$id=$prev['data']['previa_id']??str_repeat('0',32);$originalPreviewId=$id;$r=$call('api-aplicar',['previa_id'=>$id]);
$assert('A5_aplicado',$r['success']&&$client->records[$lead][$custom]===152);
$calls=$client->calls;$log=$call('registro-ler');$replay=$call('api-aplicar',['previa_id'=>$id]);
$assert('A6_recibo_identico',$replay===$r&&$client->calls===$calls);
$assert('A6_linha_unica',count($log['data']['itens'])===1);
$raw=$GLOBALS['wpdb']->get_var('SELECT metadata FROM '.Store::table('journal').' LIMIT 1');
$assert('A5_auditoria_sem_pii',!str_contains($raw,'Valor privado')&&!str_contains($raw,'synthetic@example.test')&&!str_contains($raw,'152'));
$stored=$GLOBALS['wpdb']->get_var('SELECT result FROM '.Store::table('ops')." WHERE previa_id='$id'");
$assert('recibo_cifrado',!str_contains($stored,'Valor privado')&&$stored!=='');
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'Expire']]);$eid=$prev['data']['previa_id'];
$GLOBALS['wpdb']->update(Store::table('ops'),['expires'=>time()-1],['previa_id'=>$eid]);
$assert('A7_expirada',$call('api-aplicar',['previa_id'=>$eid])['code']==='previa_expirada');
$prev=$call('api-previa',['metodo'=>'POST','caminho'=>'/v1/leadLabels','corpo'=>['name'=>'Teste pipedrive-operacao (apagar)','color'=>'blue']]);
$sid=$prev['data']['previa_id'];$writes=$client->writes;
$assert('A8_sem_frase',$call('api-aplicar',['previa_id'=>$sid])['code']==='confirmacao_ausente'&&$client->writes===$writes);
$assert('A8_frase_errada',$call('api-aplicar',['previa_id'=>$sid,'confirmacao'=>'Confirmo'])['code']==='confirmacao_ausente');
$assert('A8_frase_correta',$call('api-aplicar',['previa_id'=>$sid,'confirmacao'=>$prev['data']['confirmacao_exigida']])['success']);
$client->fields=[['id'=>10,'field_type'=>'enum','name'=>'Campo QA','options'=>[['id'=>1,'label'=>'Um'],['id'=>2,'label'=>'Dois']]]];
$b=['options'=>[['id'=>1,'label'=>'Um']]];$writes=$client->writes;
$bad=$call('api-previa',['metodo'=>'PUT','caminho'=>'/v1/dealFields/10','corpo'=>$b]);
$assert('A9_opcao_omitida',$bad['code']==='opcao_seria_apagada'&&$bad['data']->opcoes[0]['id']===2&&$client->writes===$writes);
$b['remover_opcoes']=[2];$prev=$call('api-previa',['metodo'=>'PUT','caminho'=>'/v1/dealFields/10','corpo'=>$b]);
$assert('remocao_explicita_na_previa',$prev['success']&&$prev['data']['opcoes_a_remover'][0]['id']===2&&!isset($prev['data']['corpo_a_enviar']['remover_opcoes']));
$ok=$call('api-aplicar',['previa_id'=>$prev['data']['previa_id'],'confirmacao'=>$prev['data']['confirmacao_exigida']]);
$assert('remover_opcoes_nao_enviado',$ok['success']&&!isset($client->lastBody['remover_opcoes']));
$b['remover_opcoes']=[1];$assert('remocao_divergente',$call('api-previa',['metodo'=>'PUT','caminho'=>'/v1/dealFields/10','corpo'=>$b])['code']==='opcao_seria_apagada');
$client->pageFields=true;$prev=$call('api-previa',['metodo'=>'PUT','caminho'=>'/v1/dealFields/10','corpo'=>['name'=>'Novo']]);
$assert('catalogo_paginado',$prev['success']&&$prev['data']['custo_estimado']['previa_gets']===2);$client->pageFields=false;
$before=$client->calls;$label=array_key_first($client->labels);$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>'/v1/leadLabels/'.$label,'corpo'=>['name'=>'Renomeada']]);
$assert('etiqueta_via_colecao',$prev['success']&&end($client->paths)==='/v1/leadLabels');
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'Novo estado']]);$cid=$prev['data']['previa_id'];$client->records[$lead]['title']='Mudou depois';$writes=$client->writes;
$assert('estado_alterado_recusado',$call('api-aplicar',['previa_id'=>$cid])['code']==='estado_alterado'&&$client->writes===$writes);
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'Conta errada']]);$cid=$prev['data']['previa_id'];$client->revision='r2';
$assert('revisao_alterada_recusada',$call('api-aplicar',['previa_id'=>$cid])['code']==='contexto_alterado');$client->revision='r1';
$uid=wp_create_user('qa_other_admin',wp_generate_password(),'other@example.test');$u=new WP_User($uid);$u->set_role('administrator');wp_set_current_user($uid);
$assert('outro_admin_recusado',$call('api-aplicar',['previa_id'=>$cid])['code']==='previa_de_outro_usuario');wp_set_current_user(1);
$client->budget=40;$client->spent=0;$r1=$call('api-ler',['caminho'=>'/v1/dealFields']);$r2=$call('api-ler',['caminho'=>'/v1/dealFields']);$r3=$call('api-ler',['caminho'=>'/v1/dealFields']);
$assert('A11_fixture_orcamento',$r1['success']&&$r2['success']&&$r3['code']==='orcamento_esgotado');$client->budget=10000;$client->spent=0;
$client->balance=2999;$assert('A12_fixture_saldo',$call('api-ler',['caminho'=>'/v1/dealFields'])['code']==='saldo_conta_baixo');$client->balance=15000;
$client->guard='core_em_recuperacao';$calls=$client->calls;$assert('A13_fixture_recuperacao',$call('api-ler',['caminho'=>'/v1/dealFields'])['code']==='core_em_recuperacao'&&$client->calls===$calls);$client->guard='';
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'Timeout']]);$tid=$prev['data']['previa_id'];$client->timeout=true;$writes=$client->writes;
$r=$call('api-aplicar',['previa_id'=>$tid]);$again=$call('api-aplicar',['previa_id'=>$tid]);
$assert('timeout_sem_retry',$r['code']==='resultado_incerto'&&$again===$r&&$client->writes===$writes+1);
$assert('A15_excecao_sem_segredo',!str_contains(json_encode($r),'secret-canary'));$client->timeout=false;
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'Concorrente']]);$client->reenter=true;
$r=$call('api-aplicar',['previa_id'=>$prev['data']['previa_id']]);$assert('reentrada_bloqueada',$r['success']&&($client->reentrant['code']??'')==='resultado_incerto');
$client->errorBody=true;$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'HTTP erro']]);$r=$call('api-aplicar',['previa_id'=>$prev['data']['previa_id']]);
$assert('A15_corpo_erro_omitido',$r['code']==='fornecedor_recusou'&&!str_contains(json_encode($r),'secret-canary'));$client->errorBody=false;
$client->huge=true;$assert('limite_resposta',$call('api-ler',['caminho'=>'/v1/leads'])['code']==='resposta_excedeu_limite');$client->huge=false;
$calls=$client->calls;
foreach (Documentation::DOCUMENTS as $id=>$file) {
    $text='';$offset=0;$hash=null;
    do {$args=['documento'=>$id,'offset'=>$offset,'limite_bytes'=>512];if ($hash) {$args['sha256_esperado']=$hash;}$doc=$call('documentacao-ler',$args);
        if (!$doc['success']) {break;} $text.=$doc['data']['conteudo'];$offset=$doc['data']['proximo_offset'];$hash=$doc['data']['sha256'];
    } while ($offset!==null);
    $assert('doc_integral_'.$id,$doc['success']&&$text===file_get_contents(Fator3\Pipedrive\ROOT.'/docs/'.$file)&&hash('sha256',$text)===$hash);
}
$assert('docs_zero_http',$client->calls===$calls&&$http===0);
$assert('doc_revisao_divergente',$call('documentacao-ler',['documento'=>'uso','offset'=>1,'sha256_esperado'=>str_repeat('0',64)])['code']==='documento_alterado');
$assert('doc_revisao_obrigatoria',$call('documentacao-ler',['documento'=>'uso','offset'=>1])['code']==='revisao_exigida');
$p=Api::dispatch('registro-ler',['limite'=>1]);$q=Api::dispatch('registro-ler',['limite'=>1,'antes_id'=>$p['data']['proximo_antes_id']]);
$assert('auditoria_paginada',$p['data']['itens'][0]['id']>$q['data']['itens'][0]['id']);
$subscriber=wp_create_user('qa_subscriber',wp_generate_password(),'subscriber@example.test');wp_set_current_user($subscriber);
foreach (array_keys(Api::schemas()) as $op) {$assert('permissao_'.$op,$call($op)['code']==='nao_autorizado');}
do_action('rest_api_init');$req=new WP_REST_Request('GET','/f3-pipedrive/v1/status');$rest=rest_do_request($req);$assert('rest_sem_admin',$rest->get_status()===403);
wp_set_current_user(1);$req=new WP_REST_Request('GET','/f3-pipedrive/v1/status');$rest=rest_do_request($req);$assert('rest_admin',$rest->get_status()===200&&$rest->get_data()['success']);
ob_start();Fator3\Pipedrive\Admin::page();$html=ob_get_clean();$assert('painel_renderizado',str_contains($html,'Fator3 MCP Pipedrive')&&str_contains($html,'Documentação instalada'));
// CAS verified using two independent PHP/MySQL connections.
$raceid=bin2hex(random_bytes(16));Store::create($raceid,CoreClient::binding(CoreClient::status()),['race'=>true]);
$workers=[];$workerResults=[];
foreach ([1,2] as $n) {
 $pipes=[];$process=proc_open(escapeshellarg(PHP_BINARY).' '.escapeshellarg(__DIR__.'/race-worker.php').' '.escapeshellarg(rtrim(ABSPATH,'/')).' '.escapeshellarg($raceid),[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes);
 fclose($pipes[0]);$workers[]=[$process,$pipes];
}
foreach ($workers as [$process,$pipes]) {$out=stream_get_contents($pipes[1]);$err=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($process);$workerResults[]=['out'=>trim($out),'exit'=>$exit,'stderr_bytes'=>strlen($err)];}
$assert('concorrencia_dois_processos',count(array_filter($workerResults,static fn($x)=>$x['out']==='claimed'&&$x['exit']===0))===1&&count(array_filter($workerResults,static fn($x)=>$x['out']==='not_claimed'&&$x['exit']===0))===1);
// Transaction failure before dispatch leaves a retryable, untouched preview.
$prev=$call('api-previa',['metodo'=>'PATCH','caminho'=>$lead,'corpo'=>['title'=>'Persistência']]);$fid=$prev['data']['previa_id'];$w=$client->writes;
$inject=static function($sql){if(str_starts_with($sql,'INSERT INTO `'.Store::table('journal').'`'))return 'INSERT INTO f3_qa_table_does_not_exist (x) VALUES (1)';return $sql;};
$oldSuppress=$GLOBALS['wpdb']->suppress_errors(true);add_filter('query',$inject);$fr=$call('api-aplicar',['previa_id'=>$fid]);remove_filter('query',$inject);$GLOBALS['wpdb']->suppress_errors($oldSuppress);
$assert('auditoria_falha_sem_http',$fr['code']==='persistencia_falhou'&&$client->writes===$w&&Store::get($fid)['state']==='ready');
$assert('reinstalacao_preserva_recibo',(function()use($originalPreviewId){$before=Store::get($originalPreviewId);Store::install();return Store::get($originalPreviewId)===$before;})());
$assert('sem_http_real',$http===0);
remove_filter('pre_http_request',$block,1);
return ['runtime'=>['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'mysql'=>$GLOBALS['wpdb']->db_version()],
    'checks'=>$checks,'passed'=>count(array_filter($checks,static fn($x)=>$x['passed'])),'failed'=>count(array_filter($checks,static fn($x)=>!$x['passed'])),
    'provider'=>'fixture do contrato proposto, sem homologação Core/fornecedor','http_real'=>0,'fixture_requests'=>$client->calls,'fixture_writes'=>$client->writes];
