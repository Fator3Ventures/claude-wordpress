<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

final class Store {
    public static function table(string $kind): string { global $wpdb; return $wpdb->prefix . 'f3_pipedrive_' . ($kind==='journal'?'journal':'operations'); }
    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset=$wpdb->get_charset_collate();$ops=self::table('ops');$log=self::table('journal');
        dbDelta("CREATE TABLE $ops (
            previa_id char(32) NOT NULL,
            actor_id bigint(20) unsigned NOT NULL,
            binding char(64) NOT NULL,
            state varchar(16) NOT NULL,
            created bigint(20) unsigned NOT NULL,
            expires bigint(20) unsigned NOT NULL,
            retain_until bigint(20) unsigned NOT NULL,
            payload longtext NOT NULL,
            result longtext NOT NULL,
            PRIMARY KEY  (previa_id),
            KEY retain_until (retain_until)
        ) ENGINE=InnoDB $charset;");
        dbDelta("CREATE TABLE $log (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            previa_id char(32) NOT NULL,
            created bigint(20) unsigned NOT NULL,
            metadata longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY previa_id (previa_id),
            KEY created (created)
        ) ENGINE=InnoDB $charset;");
        self::ready();
        update_option('f3_pipedrive_schema',1,false);
    }
    public static function ready(): void {
        global $wpdb;
        foreach (['ops','journal'] as $kind) {
            $t=self::table($kind);
            $row=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS WHERE Name = %s',$t),ARRAY_A);
            if (!$row || strcasecmp((string)$row['Engine'],'InnoDB')!==0) {
                throw new Fault('armazenamento_indisponivel','Reative o plugin após conferir tabelas InnoDB e permissões de banco.');
            }
        }
    }
    public static function cleanup(): void {
        global $wpdb;$t=self::table('ops');$log=self::table('journal');$now=time();
        $results=[];
        $results[]=$wpdb->query($wpdb->prepare("UPDATE $t SET payload='', state='expired' WHERE state='ready' AND expires<=%d",$now));
        $results[]=$wpdb->query($wpdb->prepare("UPDATE $t SET payload='' WHERE state='running' AND expires<=%d",$now));
        $results[]=$wpdb->query($wpdb->prepare("DELETE FROM $t WHERE retain_until<%d AND state<>'running'",$now));
        // Keep unresolved attempts identifiable even beyond ordinary retention.
        $results[]=$wpdb->query($wpdb->prepare("DELETE j FROM $log j LEFT JOIN $t o ON o.previa_id=j.previa_id WHERE j.created<%d AND (o.state IS NULL OR o.state<>'running')",$now-180*DAY_IN_SECONDS));
        if (in_array(false,$results,true)) { throw new Fault('armazenamento_indisponivel','Não foi possível aplicar a retenção; nenhuma nova chamada será feita.'); }
    }
    public static function create(string $id, string $binding, array $payload): void {
        global $wpdb;$now=time();
        $ok=$wpdb->insert(self::table('ops'),['previa_id'=>$id,'actor_id'=>get_current_user_id(),'binding'=>$binding,'state'=>'ready','created'=>$now,'expires'=>$now+900,'retain_until'=>$now+180*DAY_IN_SECONDS,'payload'=>Support::seal($payload),'result'=>'']);
        if ($ok!==1) { throw new Fault('persistencia_falhou','A prévia não foi persistida; nenhuma escrita externa foi feita.'); }
        $row=self::get($id);
        if (Support::open($row['payload'])!==$payload) { throw new Fault('persistencia_falhou','A releitura da prévia não confirmou o conteúdo.'); }
    }
    public static function get(string $id): array {
        global $wpdb;$t=self::table('ops');
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE previa_id=%s",$id),ARRAY_A);
        if ($wpdb->last_error!=='') { throw new Fault('armazenamento_indisponivel','Falha de leitura do armazenamento.'); }
        if (!$row) { throw new Fault('previa_inexistente','Prévia inexistente ou fora da retenção.'); }
        if ((int)$row['actor_id']!==get_current_user_id()) { throw new Fault('previa_de_outro_usuario','A prévia pertence a outro administrador.'); }
        return $row;
    }
    public static function claim(string $id, array $metadata): bool {
        global $wpdb;$t=self::table('ops');
        if ($wpdb->query('START TRANSACTION')===false) { throw new Fault('persistencia_falhou','Não foi possível iniciar o registro da operação.'); }
        try {
            $updated=$wpdb->query($wpdb->prepare("UPDATE $t SET state='running' WHERE previa_id=%s AND state='ready' AND expires>%d",$id,time()));
            if ($updated!==1) { $wpdb->query('ROLLBACK');return false; }
            $ok=$wpdb->insert(self::table('journal'),['previa_id'=>$id,'created'=>time(),'metadata'=>Support::json($metadata)]);
            if ($ok!==1) { throw new Fault('persistencia_falhou','A auditoria não foi persistida.'); }
            if ($wpdb->query('COMMIT')===false) { throw new Fault('persistencia_incerta','Confirmação do registro local incerta; escrita não despachada.'); }
            $row=self::get($id);
            if ($row['state']!=='running') { throw new Fault('persistencia_incerta','A releitura não confirmou a aquisição da operação.'); }
            return true;
        } catch (\Throwable $e) { $wpdb->query('ROLLBACK');throw $e; }
    }
    public static function finish(string $id, array $result, array $metadata): void {
        global $wpdb;$ops=self::table('ops');$log=self::table('journal');
        $sealed=Support::seal($result);
        if ($wpdb->query('START TRANSACTION')===false) { throw new Fault('resultado_incerto','Falha ao registrar o resultado. Não repita a escrita.'); }
        try {
            $changed=$wpdb->query($wpdb->prepare("UPDATE $ops SET state='done',result=%s,payload='' WHERE previa_id=%s AND state='running'",$sealed,$id));
            if ($changed!==1) { throw new Fault('resultado_incerto','O resultado externo não foi confirmado no recibo.'); }
            if ($wpdb->update($log,['metadata'=>Support::json($metadata)],['previa_id'=>$id])===false) { throw new Fault('resultado_incerto','Não foi possível concluir a auditoria.'); }
            if ($wpdb->query('COMMIT')===false) { throw new Fault('resultado_incerto','Confirmação do resultado incerta. Não repita a escrita.'); }
            $row=self::get($id);
            if ($row['state']!=='done' || Support::open($row['result'])!==$result) { throw new Fault('resultado_incerto','Releitura do resultado divergente.'); }
        } catch (\Throwable $e) { $wpdb->query('ROLLBACK');throw $e; }
    }
    public static function journal(array $input): array {
        global $wpdb;$t=self::table('journal');
        $limit=$input['limite']??50;$before=$input['antes_id']??PHP_INT_MAX;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,created,metadata FROM $t WHERE id<%d ORDER BY id DESC LIMIT %d",$before,$limit+1),ARRAY_A);
        if ($wpdb->last_error!=='') { throw new Fault('armazenamento_indisponivel','Falha ao ler o registro.'); }
        $more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$items=[];
        foreach ($rows as $row) {
            $meta=json_decode($row['metadata'],true);
            if (!is_array($meta)) { throw new Fault('registro_ilegivel','Metadados de auditoria ilegíveis.'); }
            $items[]=['id'=>(int)$row['id'],'instante_utc'=>gmdate('Y-m-d\TH:i:s\Z',(int)$row['created'])]+$meta;
        }
        return ['itens'=>$items,'proximo_antes_id'=>$more?(int)end($rows)['id']:null,'retencao_dias'=>180,'limpeza'=>'sob demanda nas operações de escrita; tentativas incertas são preservadas'];
    }
}
