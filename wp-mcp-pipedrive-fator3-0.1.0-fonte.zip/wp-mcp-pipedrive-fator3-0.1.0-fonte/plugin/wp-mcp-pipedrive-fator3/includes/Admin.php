<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;
final class Admin {
    public static function menu(): void {
        add_management_page('Fator3 MCP Pipedrive','Fator3 MCP Pipedrive','manage_options',SLUG,[self::class,'page']);
    }
    public static function page(): void {
        if (!current_user_can('manage_options')) { wp_die('Acesso administrativo necessário.'); }
        echo '<div class="wrap"><h1>Fator3 MCP Pipedrive</h1><p>Versão '.esc_html(VERSION).'. Configure a autorização no Fator3 Site Core do site-porta. Este plugin não recebe token.</p>';
        $status=Operations::status();
        echo '<h2>Contrato, conta e orçamento</h2><p>'.esc_html($status['message']).'</p><pre style="white-space:pre-wrap;overflow-wrap:anywhere">'.esc_html(Support::json($status['data'])).'</pre>';
        echo '<h2>Registro de escritas</h2>';
        $before=isset($_GET['antes_id'])?(int)$_GET['antes_id']:PHP_INT_MAX;
        $r=Api::dispatch('registro-ler',['limite'=>20,'antes_id'=>max(1,$before)]);
        if ($r['success']) {
            echo '<table class="widefat striped"><thead><tr><th>UTC</th><th>Método e caminho</th><th>Classe</th><th>Estado</th><th>Prévia</th><th>Chaves alteradas</th><th>Saldo</th></tr></thead><tbody>';
            foreach ($r['data']['itens'] as $item) {
                echo '<tr>';foreach ([$item['instante_utc'],$item['metodo'].' '.$item['caminho'],$item['classe'],$item['status'],$item['previa_id'],implode(', ',$item['chaves_alteradas']),$item['saldo_depois']['restante']??'—'] as $value) { echo '<td>'.esc_html((string)$value).'</td>'; }echo '</tr>';
            }
            echo '</tbody></table>';
            if ($r['data']['proximo_antes_id']!==null) { echo '<p><a href="'.esc_url(add_query_arg(['page'=>SLUG,'antes_id'=>$r['data']['proximo_antes_id']],admin_url('tools.php'))).'">Registros anteriores</a></p>'; }
        } else { echo '<p>'.esc_html($r['message']).'</p>'; }
        echo '<h2>Documentação instalada</h2><p>';
        foreach (Documentation::DOCUMENTS as $id=>$filename) { echo '<a style="margin-right:12px" href="'.esc_url(add_query_arg(['page'=>SLUG,'documento'=>$id],admin_url('tools.php'))).'">'.esc_html($id).'</a>'; }
        echo '</p>';
        $id=isset($_GET['documento'])&&is_string($_GET['documento'])?sanitize_key($_GET['documento']):'index';
        try {
            $offset=0;$hash=null;$content='';
            do {
                $args=['documento'=>$id,'offset'=>$offset,'limite_bytes'=>24000];if ($hash) { $args['sha256_esperado']=$hash; }
                $d=Documentation::read($args);$content.=$d['conteudo'];$offset=$d['proximo_offset'];$hash=$d['sha256'];
            } while ($offset!==null);
            echo '<pre style="white-space:pre-wrap;overflow-wrap:anywhere;background:white;padding:16px">'.esc_html($content).'</pre>';
        } catch (Fault $e) { echo '<p>'.esc_html($e->getMessage()).'</p>'; }
        echo '</div>';
    }
}
