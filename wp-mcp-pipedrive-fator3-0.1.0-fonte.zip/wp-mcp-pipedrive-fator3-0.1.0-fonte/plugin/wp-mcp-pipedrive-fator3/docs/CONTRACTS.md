# Contratos — 0.1.0

## Core: proposta de concretização de pipedrive-api-client/1.0.0

A especificação funcional exige o contrato, mas Core 1.50.0 ainda não o publica. A assinatura abaixo é implementada no consumidor e na fixture, e foi encaminhada ao mantenedor Core. Compatibilidade com uma futura implementação não está homologada; não há fallback para options privadas.

Hook: `f3base_register_pipedrive_consumers($registry, 'pipedrive-api-client/1.0.0')`, depois do carregamento dos plugins. O Pipedrive chama `$registry->register_consumer('wp-mcp-pipedrive-fator3','0.1.0','pipedrive-api-client/1.0.0',$configuration)`. Callback configuration retorna `{ready:true,revision:'0.1.0',provider:'wp-mcp-pipedrive-fator3'}`. Registro não é autorização. Retorno: objeto ou WP_Error.

Cliente deve expor capabilities(), status(), request(metodo,caminho,query,corpo,contexto). capabilities retorna `{contract:'pipedrive-api-client/1.0.0'}`. Nenhuma chamada de capabilities/status envolve HTTP.

Status:
```json
{"success":true,"code":"ok","message":"Estado local.","data":{"contract":"pipedrive-api-client/1.0.0","autorizado":true,"conta":{"dominio":"exemplo.pipedrive.com","conta_id":1,"usuario_id":2},"revisao":"revisao-nao-secreta","orcamento":{"teto":3000,"consumido":0,"reservado":0},"saldo_conta":{"restante":15000,"lido_em":"2026-10-23T20:00:00Z"}}}
```

revisao muda em troca de conta/credencial/autorização. Saldo pode ser null se nunca lido. Não usar chave que inclua token no nome para metadados públicos: o MCP redige chaves sensíveis.

request recebe contexto com provider, consumer=operacao, contract, actor_id, revisao_esperada e previa_id nas mutações. O Core deve verificar revisão/autorização e reservar orçamento imediatamente antes de despachar. Resposta:
```json
{"success":true,"code":"ok","message":"Consulta concluída.","remote_dispatched":true,"data":{"http_status":200,"body":{"success":true,"data":[]},"saldo_conta":{"restante":14980,"lido_em":"2026-10-23T20:01:00Z"}}}
```

Falha anterior ao despacho usa success=false e remote_dispatched=false explícito. WP_Error pode conter esse booleano em error_data; sem ele a tentativa de escrita é incerta. Exceções e mensagens do cliente nunca são copiadas ao usuário. Códigos admitidos: saldo_conta_baixo, operacao_nao_autorizada, core_em_recuperacao, orcamento_esgotado, pipedrive_orcamento_esgotado, pausa_remota, rate_limit, credencial_invalida, revisao_conflitante, contexto_alterado e core_indisponivel. Desconhecidos viram core_recusou sem a mensagem privada.

## Transporte e autorização

Provider `wp-mcp-pipedrive-fator3`, prefixo `pipedrive/`, policy_contract=1 via f3_mcp_register_providers/ExtensionContract. Abilities API nativa registra seis operações. Sem MCP, REST e painel continuam disponíveis; MCP é necessário só para o transporte remoto.

api-previa é escrita local/GET remoto; api-aplicar escrita local/remota. api-ler consulta remota com efeito de orçamento no Core. status, registro e documentação são observacionais. Todos exigem manage_options também no dispatcher, além da política MCP. Idempotency_key acrescentada pelo MCP é independente do previa_id; usar o previa_id da operação de domínio e não contornar recibos incertos com outra chave.

Schemas de entrada e envelope gerados em schemas.json. Caminhos, parâmetros e corpos têm validação de domínio em Policy.php. Limites: corpo 65.536 bytes, resposta 524.288 bytes, documentos 24.000 bytes/página, auditoria 100 itens/página, catálogo atual 20 páginas de 500 itens. Query vazia e corpo vazio representam objetos JSON vazios.

## Evidência técnica do fornecedor

Consultadas em 23/10/2026: documentação oficial de Leads, LeadLabels, DealFields, Notes e filtros. Leads/etiquetas usam UUID; etiquetas são lidas pela coleção. A API também documenta campos v2, mas o pedido condiciona sua adoção à prova na conta. Mantida a allowlist v1 solicitada.

- https://developers.pipedrive.com/docs/api/v1/Leads
- https://developers.pipedrive.com/docs/api/v1/LeadLabels
- https://developers.pipedrive.com/docs/api/v1/DealFields
- https://developers.pipedrive.com/docs/api/v1/Notes
- https://developers.pipedrive.com/docs/api/v1/Filters
- https://pipedrive.readme.io/docs/working-with-labels
