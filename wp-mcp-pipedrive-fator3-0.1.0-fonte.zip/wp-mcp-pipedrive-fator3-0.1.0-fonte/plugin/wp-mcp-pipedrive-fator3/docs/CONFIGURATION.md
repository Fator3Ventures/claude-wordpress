# Configuração — 0.1.0

Requisitos declarados: WordPress 7.1.3, PHP 8.3.36, 64 bits, OpenSSL AES-256-GCM, mbstring e banco MySQL/MariaDB com InnoDB. Consulte o relatório para as versões realmente executadas. Site único; multisite não é suportado nesta versão.

1. A frota recebe e valida os hashes do instalador e instala o Core que ofereça o contrato confirmado. Core 1.50.0 ainda é insuficiente.
2. Escolher um único site-porta e instalar `wp-mcp-pipedrive-fator3-0.1.0-instalador.zip`. O ZIP fonte não é instalável. A ativação cria apenas duas tabelas próprias e a versão do schema; não liga a operação comercial.
3. A credencial permanece no Core (`f3base_pipedrive_token`), usando sua tela e verificação. Nenhum token entra no chat nem neste plugin.
4. Pelo contrato de configuração Core, configurar `f3base_pipedrive_operacao.ativo=true` e incluir somente `wp-mcp-pipedrive-fator3` em consumidores nesse site. Consultar o schema efetivo de `f3base/config-core-escrever`; esta versão não grava options alheias nem inventa payload do Core futuro.
5. Conferir `pipedrive/status`: contrato 1.0.0, autorização, domínio/conta/usuário esperados, revisão, teto/consumido/reservado e saldo com instante. O pedido prevê conta 14725895; a seleção real pertence ao Core, não é hardcoded no plugin.
6. Autorizar explicitamente as rotas na conexão MCP. Registro do provider não concede perfil. Leitura não autoriza api-previa/api-aplicar. Toda operação exige também manage_options.

O orçamento operacao padrão de 3.000/dia UTC, reserva atômica GET=20/escrita=10, piso de saldo oficial 3.000, pausa remota e recuperação são responsabilidade do Core C2–C6. O plugin sempre consulta o cliente; não cria cota paralela. A prévia e a revalidação consomem GETs. Revogar autorização no Core suspende novas operações e leitura de recibos vinculados à conta pela aplicação; documentação e registro técnico local seguem administrativos.

Sem contrato: core_indisponivel. Sem concessão: operacao_nao_autorizada. A interface mostra o diagnóstico, sem pedir token ou fazer reparo automático. Não é necessário instalar Google, Meta ou LinkedIn para usar as funções próprias.
