# Notas — Fator3 MCP Pipedrive 0.1.0

23/10/2026 · Primeira versão, base nenhuma. Pedido MCP Pipedrive 1.

Implementados: cinco operações de domínio, documentação paginada, REST/painel administrativos, listas fechadas, prévia de 15 minutos, comparação de opções, frase vinculada, revalidação, aquisição atômica, recibo cifrado e auditoria sem valores pessoais. Retenção sob demanda; sem cron/webhook/token próprio.

Integração Core: consumidor do contrato proposto pipedrive-api-client/1.0.0; ausente na base recebida 1.50.0. A entrega do Core e a confirmação dos envelopes ainda são necessárias. Homologação A1–A16 no fornecedor não está concluída.

MCP: registro genérico policy_contract=1 e permissões originais, sem concessão automática ou modificação do canal. Google 0.19.0, Meta 0.9.0 e LinkedIn 0.10.1 não são dependências.

Conferir o relatório externo para cenários executados, versões reais, pendências e hashes finais. Versões mínimas não exercitadas não constituem suporte comprovado.
