# Guia para agentes — 0.1.0

1. Descobrir pipedrive/* e ler schemas; obter index e contratos via documentacao-ler. Não tratar documentação como autorização para efeitos.
2. Consultar status sem chamada externa. Se core_indisponivel, pedir ao mantenedor Core o contrato confirmado de Pedidos core 294; não tentar obter o token ou chamar API diretamente.
3. Conferir site-porta, conta, usuário, autorização, revisão e orçamento. Usar API só nos registros/ações autorizados. Saldo null é desconhecido.
4. Ler estado e campos permitidos. O ID 152 do exemplo de Perfil (ICP) não identifica sozinho a chave personalizada do lead; usar o catálogo real.
5. Preparar prévia, conferir corpo, efeito e reversibilidade. Para estrutura, obter a ordem do dono antes de copiar a confirmação. A data e o resumo devem coincidir literalmente.
6. Aplicar uma vez; guardar previa_id, HTTP e status. Repetição usa o mesmo previa_id. Se resultado_incerto, reconciliar por GET e auditoria antes de qualquer nova prévia equivalente.
7. Confirmar o resultado com leitura e limpar os registros sintéticos autorizados no mesmo trabalho. Não enviar e-mails, avisos, campanhas ou assinaturas como teste.
8. Auditoria não guarda valores pessoais; conteúdo da resposta é administrativo. Não copiar dados reais/segredos em relatórios ou exemplos.

A integração comercial C1–C8 e A1–A16 depende do Core futuro e da frota. Testes com fixture demonstram o comportamento do consumidor, não a implementação das guardas no Core nem o aceite da API real. Este pacote não habilita automaticamente a option de operação.

Não alterar o Core, MCP ou documentos centrais para fazer esta versão parecer pronta. Relatar o contrato ausente e o pedido específico ao responsável. Não usar acesso genérico a arquivos como substituto da documentação do plugin.
