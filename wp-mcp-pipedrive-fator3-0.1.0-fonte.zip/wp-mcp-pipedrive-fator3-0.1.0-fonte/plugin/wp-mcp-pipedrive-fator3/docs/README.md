# Fator3 MCP Pipedrive 0.1.0

Operações administrativas na conta Pipedrive pelo token que permanece no Site Core. Este pacote não armazena token, não faz HTTP próprio e não interfere nas filas de entrega de leads.

## Prontidão

O Core 1.50.0 fornecido não publica o cliente exigido. A implementação depende da confirmação e disponibilização de `pipedrive-api-client/1.0.0`, solicitado em Pedidos core 294. O adaptador desta versão segue a proposta detalhada em CONTRATOS; homologação integrada com Core 1.51.0 está pendente. Sem o contrato, `status` devolve `core_indisponivel`; ajuda e auditoria local permanecem utilizáveis.

## Índice e leitura

| ID | Arquivo | Assunto |
|---|---|---|
| index | README.md | Visão geral |
| especificacao | SPECIFICATION.md | Listas e comportamento |
| configuracao | CONFIGURATION.md | Pré-requisitos e autorização |
| uso | USAGE.md | Fluxo e exemplos |
| contratos | CONTRACTS.md | Interface proposta ao Core e erros |
| agentes | AGENT-GUIDE.md | Orientação de operação |
| operacao | OPERATIONS.md | Armazenamento e recuperação |
| release | CHANGELOG.md | Escopo 0.1.0 |
| schemas | schemas.json | Schemas gerados do runtime |

Descobrir `pipedrive/documentacao-ler`. Chamar `{}` para este índice, ou `{"documento":"uso"}`. Continuações usam `offset=proximo_offset` e `sha256_esperado` da página anterior. Encerrar quando `fim=true`. Páginas de 256 a 24.000 bytes, padrão 16.000, com corte UTF-8. O SHA-256 representa o documento completo. Não juntar revisões diferentes. IDs são fechados; caminhos arbitrários e symlinks externos são recusados. Todos os acessos exigem manage_options.

A documentação é estática: sua leitura não consulta o Core nem fornecedor, não verifica token e não cria tabelas, cron ou configurações. Painel: Ferramentas → Fator3 MCP Pipedrive.
