# Operação e recuperação — 0.1.0

Sem cron, fila, webhook ou HTTP próprio. Desativação e desinstalação não chamam a API e preservam as tabelas.

## Armazenamento

`{prefix}f3_pipedrive_operations`: chave aleatória de 32 hexadecimais, administrador, digest de site/conta/revisão, estado ready/running/done/expired, prazos, payload e result cifrados AES-256-GCM. A prévia guarda corpo a enviar e hash do estado atual, sem persistir a cópia integral do estado lido. Payload removido ao concluir; pendentes expirados são esvaziados na próxima operação de manutenção sob demanda. Recibos cifrados duram 180 dias para reprodução idêntica. Os salts WordPress são necessários para decifrar.

`{prefix}f3_pipedrive_journal`: ID sequencial, previa_id único, instante UTC e metadados. Caminho com IDs, classe, status, chaves e saldo; nomes/opções de estrutura permitidos. Nenhum conteúdo de nota ou valor de campo pessoal é gravado no diário. O recibo privado cifrado é separado da auditoria; ele pode conter a resposta privada do fornecedor, necessária à repetição exata.

Retenção padrão 180 dias, sob demanda em prévia/aplicação, sem agendamento. Sem novas escritas, não há limpeza automática. Tentativas running são preservadas para reconciliação mesmo após 180 dias; seu payload expirado é apagado na limpeza. A leitura documental/status/registro não aciona limpeza nem reparo.

## Uma tentativa por prévia

UPDATE condicional ready→running e INSERT único na auditoria são confirmados em transação InnoDB antes do despacho. Duas execuções não podem adquirir a mesma prévia. Depois da chamada, recibo e auditoria são concluídos em outra transação. Falha de confirmação mantém a operação conservadoramente incerta. Nunca resetar running para ready para tentar novamente.

Falha entre a aquisição e o HTTP também fica incerta: a segurança contra duplicação tem prioridade. Reconciliar no fornecedor e registrar decisão administrativa fora do plugin antes de nova operação. Não há ferramenta de desbloqueio automático ou replay forçado.

## Instalação e reversão

Primeira versão: não existe base anterior para ensaio de atualização. Reinstalar o mesmo código preserva tabelas e recibos; não equivale a teste de atualização de versão anterior. A ativação usa dbDelta e exige InnoDB. Sem tabela, operações devolvem erro e não tentam reparar durante leituras.

Antes de trocar arquivos, preservar banco e salts. Restaurar arquivos não restaura valores apagados, opções, conta, quota nem chamadas externas. Desinstalar preserva os registros; remoção de tabelas exige decisão administrativa separada. Não executar DROP em tabelas de outros plugins nem apagar o banco compartilhado.

Core 1.50.0 permanece sem operação integrada; instalar o pacote não concede autorização. Ativação comercial ocorre após Core compatível confirmado, seleção do site-porta e homologação pela frota.
