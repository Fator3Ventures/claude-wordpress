# Plano — Fator3 MCP Pipedrive 0.1.0

23/10/2026 · Implementação · Base: nenhuma. Pedido MCP Pipedrive 1 e Pedido core 294, C1–C8, A1–A16.

Normas lidas integralmente: instruções e padrão revisão 4 nas fontes avulsas; revisão 5, de 23/10/2026, encontrada nos inputs/0.9.0 do fonte Meta. A revisão 5 é a vigente e será aplicada. Documentos centrais preservados.

O Core recebido/observado é 1.50.0; não fornece pipedrive-api-client/1.0.0. Implementar somente o pacote Pipedrive, com adaptador do contrato proposto e degradação segura. Não ler options privadas, nem duplicar token/HTTP do Core. A ativação comercial depende da implementação e confirmação do contrato pelo mantenedor Core.

1. Listas fechadas e validação de corpos; prévias com GET do estado e validade de 15 minutos.
2. Recibo durável com aquisição atômica antes de qualquer mutação; vincular usuário, site e conta/revisão do Core. Falha incerta nunca repete escrita.
3. Comparar opções atuais e exigir lista exata para exclusões; confirmação de estrutura vinculada ao resumo. Revalidar estado antes de aplicar para detectar mudanças concorrentes.
4. Histórico de metadados com retenção padrão 180 dias; dados privados de prévia/recibo cifrados separadamente. Sem cron, webhook ou fila.
5. Cinco operações de domínio e uma operação documental adicional exigida pela norma; painel local e REST administrativo.
6. MCP 0.29.1: usar registro genérico e política vigente, sem concessão automática. Validar com seu código original em laboratório isolado.
7. Instalação limpa WordPress descartável e testes com cliente contratual simulado, distinguindo-os de Core futuro e fornecedor real.
8. Fechar instalador, relatório interno sem hash circular, fonte, relatório externo com SHA-256 e checklist.

Impacto emitido antes da implementação: `wp-mcp-pipedrive-fator3-0.1.0-impacto-base-site-core-fator3.md`. Não há mudança necessária identificada nos contratos Meta, LinkedIn e Google. O MCP será objeto de encaminhamento apenas se a prova demonstrar necessidade de alteração.

A precedência do pedido específico de 23/10 sobre a instrução histórica de 06/10 permite os testes comerciais nomeados no Site-Teste; eles permanecem com a frota após o Core 1.51.0. Nenhuma operação na conta real é necessária para implementar a parte independente nesta rodada.
