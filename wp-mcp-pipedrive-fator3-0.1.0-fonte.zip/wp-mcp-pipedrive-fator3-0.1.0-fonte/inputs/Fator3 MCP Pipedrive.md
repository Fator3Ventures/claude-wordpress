# Pedidos — Fator3 MCP Pipedrive

**Aba do documento de pedidos aos pacotes Fator3.** Lista o que está pendente no pacote **wp-mcp-pipedrive-fator3** (rotas `pipedrive/*`). Em outros documentos, cite como "Pedidos MCP Pipedrive N". Serve também de documento para o responsável pelo pacote. Base: nenhuma (pacote novo, versão-alvo 0.1.0). A regra do dono de 08/10/2026 e o modo de manter a lista estão na aba Site Core e valem para esta aba.

**Situação em 23/10/2026: aberto o 1.** O pacote ainda não existe; depende do contrato pedido em Pedidos core 294 (Site Core 1.51.0).

**Numeração.** Item novo recebe o próximo número (hoje, 2) e vai no fim; item retirado deixa o número vago.

## wp-mcp-pipedrive-fator3

**1. Primeira versão do pacote, 0.1.0 (23/10/2026).** Ordem do dono, 23/10/2026 às 20h03: "Vamos seguir o caminho de criar um plugin separado para o Pipedrive. Faça as modificações necessárias e elabore o documento inicial para realizar o pedido para o desenvolvimento do novo plugin, assim como as mudanças necessárias no Core." O escopo vale como está no documento "Pedido — Fator3 MCP Pipedrive e contrato no Site Core" (Claude Docs 362af569-e445-4947-961d-967f6695cff4), seções "Pacote novo: Fator3 MCP Pipedrive 0.1.0", "Fora da primeira versão", "Critérios de aceite" e "Entrega e passos seguintes"; onde este item e o documento divergirem, vale o documento.

**Situação:** o agente não usa token colado no chat e o conector Pipedrive não grava campo personalizado de lead, não exclui e não mexe em estrutura; essas ações seguem pela tela (lido em 23/10/2026 no Site Core 1.50.0 do Site-Teste e na Referência para agentes rev 84 das Regras de operação do Pipedrive).

**Pedido:** slug `wp-mcp-pipedrive-fator3`, ID de coordenação `pipedrive`, prefixo `pipedrive/`, sem token próprio, chamando a API só pelo cliente `pipedrive-api-client/1.0.0` do Core (Pedidos core 294). Rotas: `pipedrive/status`, `pipedrive/api-ler`, `pipedrive/api-previa`, `pipedrive/api-aplicar` e `pipedrive/registro-ler`. Listas fechadas de leitura e de escrita, classes `registro` e `estrutura`, frase de confirmação para estrutura, recusa de opção que seria apagada, registro sem valor de campo pessoal, sem cron nem webhook, `manage_options` em todas as rotas, mensagens em português. Impacto individual para `base-site-core-fator3` e, se o canal não expuser rotas de provider novo sem mudança, para `wp-mcp-fator3`.

**Aceite (Site-Teste, Core 1.51.0 com o pacote 0.1.0):** A1 a A16 da seção "Critérios de aceite" do documento, com os registros de teste "Teste pipedrive-operacao (apagar)" excluídos no mesmo trabalho.

## Decidido não fazer

Nada registrado.
