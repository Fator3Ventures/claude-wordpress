'use strict';
/* 0.32.0 layout: self-contained copy of admin-browser.cjs (used by 031, unchanged) plus layout checks. */
const { chromium } = require('playwright');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const rootUrl = new URL(input.url);
assert.equal(rootUrl.hostname, '127.0.0.1');
const checks = [];
const check = (name, pass) => { assert.ok(pass, name); checks.push(name); };
const browserErrors = [];
const pageUrl = (section, more = {}) => {
  const url = new URL('/wp-admin/tools.php', input.url);
  url.search = new URLSearchParams({ page: 'wp-mcp-google-fator3', connection_id: 'browserqa', section, ...more }).toString();
  return url.href;
};

async function contextFor(browser, cookies, options = {}) {
  // Use the supported reduced-motion preference so rapid test navigation does not
  // interrupt WordPress core's cross-document view transitions.
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, reducedMotion: 'reduce', ...options });
  await ctx.route('**/*', route => {
    const url = new URL(route.request().url());
    return url.origin === rootUrl.origin || url.protocol === 'data:' ? route.continue() : route.abort();
  });
  await ctx.addCookies(Object.entries(cookies).map(([name,value]) => ({ name, value, url: input.url })));
  const page = await ctx.newPage();
  page.on('pageerror', e => browserErrors.push(e.message));
  page.setDefaultTimeout(60000);
  return { ctx, page };
}

async function run(checkDiagnostics, checkLayout) {
  const browser = await chromium.launch({ executablePath: process.env.F3_CHROMIUM || '/usr/bin/chromium', headless:true, args:['--no-sandbox','--disable-dev-shm-usage'] });
  try {
    const { ctx, page } = await contextFor(browser, input.cookies);
    const root = page.locator('.f3-google');
    if (checkLayout) { await checkLayout({ page, root, check, input, pageUrl, browser, contextFor }); }
    await page.goto(pageUrl('connection'));
    check('WordPress tools screen renders selected connection', await root.locator('#f3-connection').inputValue() === 'browserqa');
    check('Local script and scoped stylesheet loaded', await root.evaluate(el => el.classList.contains('f3-js') && getComputedStyle(el.querySelector('.f3-subnav')).display==='flex'));
    check('Only identity setup shown by default', await root.getByRole('heading',{name:'Autenticação',exact:true}).isVisible() && await root.locator('[name="services_present"]').count()===0);
    await root.locator('.f3-subnav').getByRole('link',{name:'Serviços e recursos',exact:true}).click();
    await page.locator('.f3-google.f3-js').waitFor();
    check('Services tab keeps connection', new URL(page.url()).searchParams.get('connection_id')==='browserqa');
    check('Services tab avoids authentication form', await root.locator('[name="sa_json"]').count()===0);
    check('Level field exposes its help to assistive technology', await root.locator('#f3-ads-level').getAttribute('aria-describedby')==='f3-ads-level-help');
    const ads=root.locator('#f3-service-ads'), binding=root.locator('[name="ads_customer_id"]');
    await ads.selectOption('');
    check('Service disabled hides and disables its binding', await binding.isDisabled() && await binding.isHidden());
    await ads.selectOption('read');
    check('Re-enabling restores saved selection', await binding.isEnabled() && await binding.inputValue()==='1234567890');
    // Intentional navigation after changing a selection.
    page.on('dialog', dialog=>dialog.accept());
    await root.getByRole('link',{name:'Verificar acessos em Diagnóstico'}).click();
    await root.getByRole('heading',{name:'Verificar a conexão',exact:true}).waitFor();
    check('Diagnostic deep link opens the diagnostic panel', await root.getByRole('heading',{name:'Verificar a conexão',exact:true}).isVisible());
    check('Diagnostic deep link preserves context',new URL(page.url()).searchParams.get('connection_id')==='browserqa');
    if (checkDiagnostics) { await checkDiagnostics({ page, root, check, input }); }
    await page.goto(pageUrl('connection'));
    await root.locator('details').filter({has:page.locator('summary',{hasText:'Nome da conexão'})}).locator('summary').first().click();
    await root.locator('[name="connection_label"]').fill('Nome editado no navegador');
    await root.getByRole('button',{name:'Salvar nome',exact:true}).click();
    await page.waitForURL(/f3_status=/);
    check('Real POST returns to same identity panel and connection', new URL(page.url()).searchParams.get('connection_panel')==='identity'&&new URL(page.url()).searchParams.get('connection_id')==='browserqa');
    check('Rename persisted after reload',(await root.locator('#f3-connection option:checked').innerText()).includes('Nome editado no navegador'));
    await page.goto(pageUrl('archive'));
    const origin = root.getByRole('checkbox',{name:'Consultar o criativo desta conta no Google Ads'}).first();
    check('Creative reader grant is separately labelled and off by default',await origin.isVisible() && !(await origin.isChecked()));
    for (const width of [390,1440]) {
      await page.setViewportSize({width,height:900});
      const region=origin.locator('xpath=ancestor::fieldset');
      await region.scrollIntoViewIfNeeded();
      check('Creative grant and explanation fit '+width,await region.evaluate(el=>el.getBoundingClientRect().right<=innerWidth && el.scrollWidth<=el.clientWidth+1));
      await region.locator('xpath=ancestor::section').screenshot({path:input.scratch+'/evidence/leitor-origem-'+width+'.png'});
    }
    check('Archive opens existing account with correct saved windows', await root.locator('#archive_backfill').inputValue()==='45'&&await root.locator('#archive_revisit').inputValue()==='3');
    check('Archive selected datasets are exact', await root.locator('form:has(#archive_backfill) input[name="archive_datasets[]"]:checked').count()===1);
    check('Account ID is read-only while editing',await root.locator('form:has(#archive_backfill) [name="archive_account"]').getAttribute('readonly')!==null);
    await root.locator('#f3-archive-account').selectOption('new');
    await root.getByRole('button',{name:'Abrir conta'}).click();
    check('New collection starts paused',!(await root.locator('form:has(#archive_backfill) input[name="archive_enabled"]').isChecked()));
    await page.goto(pageUrl('conversions'));
    check('Independent GA4 and Ads lookup buttons available',await root.getByRole('button',{name:'Consultar propriedades e fluxos'}).isVisible()&&await root.getByRole('button',{name:'Consultar contas e ações'}).isVisible());
    check('GA4 and Ads use labelled fieldsets',await root.locator('.f3-destinations fieldset > legend').count()===2);
    // Structured profiles have reversible row edits and unique labels.
    const group=root.locator('[data-profile-rows]').first();
    for (const node of await group.locator('xpath=ancestor::details').all()) { await node.evaluate(el=>el.open=true); }
    const count=await group.locator(':scope > .f3-profile-row').count();
    await group.locator(':scope > [data-add-profile-row]').click();
    check('Add GA4 profile row sets focus and distinct names',await group.locator(':scope > .f3-profile-row').count()===count+1 && await group.locator(':scope > .f3-profile-row').last().evaluate(el=>el.contains(document.activeElement)));
    const duplicate=await group.evaluate(el=>{const names=[...el.querySelectorAll('input,select')].map(f=>f.name);return new Set(names).size!==names.length;});
    check('Dynamic GA4 profile row names are unique',!duplicate);
    await group.locator(':scope > .f3-profile-row').last().locator(':scope > [data-remove-row]').click();
    check('Remove GA4 profile row restores original count',await group.locator(':scope > .f3-profile-row').count()===count);
    await page.goto(pageUrl('connection',{connection_panel:'services'}));
    await page.screenshot({path:input.scratch+'/desktop-private.png'});
    await page.setViewportSize({width:390,height:844});
    for (const [section,extra] of [['overview',{}],['connection',{connection_panel:'services'}],['connection',{connection_panel:'permissions'}],['conversions',{}],['archive',{}],['gsc',{}],['gtm',{}],['incidents',{}],['advanced',{}],['diagnostics',{}],['operations',{}],['help',{}]]) {
      await page.goto(pageUrl(section,extra));
      const overflow=await root.evaluate(el=>{const bound=el.getBoundingClientRect();return {inner:el.scrollWidth,width:el.clientWidth,right:bound.right,viewport:innerWidth};});
      const name=section+(extra.connection_panel?'/'+extra.connection_panel:'');
      check('Mobile content fits viewport on '+name, overflow.inner <= overflow.width + 2 && overflow.right <= overflow.viewport + 2);
      check('Mobile document has no horizontal scroll on '+name, await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
      const tabs=await root.locator('nav.f3-tabs').evaluate(nav=>{const links=[...nav.querySelectorAll('a')];const cur=nav.querySelector('[aria-current="page"]');const n=nav.getBoundingClientRect(),c=cur.getBoundingClientRect();return {rows:new Set(links.map(a=>Math.round(a.getBoundingClientRect().top))).size,visible:c.left>=n.left-1&&c.right<=n.right+1,scrolls:getComputedStyle(nav).overflowX};});
      check('Mobile primary tabs stay on one row and show the current tab on '+name, tabs.rows===1 && tabs.visible && tabs.scrolls==='auto');
      if (section === 'diagnostics' && checkDiagnostics) {
        await page.screenshot({path:input.scratch+'/diagnostics-mobile.png'});
      }
    }
    await page.goto(pageUrl('archive'));
    await page.screenshot({path:input.scratch+'/mobile-private.png'});
    await ctx.close();

    const nojs=await contextFor(browser,input.cookies,{javaScriptEnabled:false});
    await nojs.page.goto(pageUrl('services'));
    const form=nojs.page.locator('form:has([name="services_present"])');
    await form.locator('#f3-service-ads').selectOption('');
    await form.locator('#f3-service-ga').selectOption('read');
    await form.locator('#f3-service-sheets').selectOption('read');
    await form.locator('[name="ga_property_id"]').fill('12345678');
    await form.locator('[name="spreadsheet_id"]').fill('https://docs.google.com/spreadsheets/d/sheet_033/edit');
    await form.getByRole('button',{name:'Revisar alterações'}).click();
    await nojs.page.waitForURL(url => url.pathname.endsWith('/admin-post.php'));
    check('No-JS service preview uses normal WordPress POST',new URL(nojs.page.url()).pathname.endsWith('/admin-post.php') && await nojs.page.locator('[name="connection_id"]').inputValue()==='browserqa');
    const confirm=nojs.page.locator('form:has([name="configuration_intent"])');
    check('No-JS review offers confirmation bound to this intent',await confirm.count()===1);
    const agree=confirm.locator('[name="confirm_service_reduction"]');
    if (await agree.getAttribute('type')==='checkbox') await agree.check();
    await confirm.locator('button[type="submit"],button').last().click();
    await nojs.page.waitForURL(url => url.searchParams.get('connection_panel') === 'services');
    check('No-JS form returns to the same service panel after applying',new URL(nojs.page.url()).searchParams.get('connection_panel')==='services');
    check('No-JS reduction persisted in the selected connection',await nojs.page.locator('#f3-service-ads').inputValue()==='');
    check('GA property enabled and saved without JavaScript in the same submission',
      await nojs.page.locator('input[name="ga_property_id"]').inputValue() === '12345678');
    check('Sheet URL enabled and normalized without JavaScript in the same submission',
      await nojs.page.locator('input[name="spreadsheet_id"]').inputValue() === 'sheet_033');
    for (const width of [1440,390]) {
      await nojs.page.setViewportSize({width, height: width === 390 ? 844 : 900});
      await nojs.page.locator('.f3-service-review').scrollIntoViewIfNeeded();
      await nojs.page.screenshot({path: input.scratch + '/servicos-033-' + width + '.png'});
    }
    await nojs.ctx.close();
    const limited=await contextFor(browser,input.subscriber);
    const denied=await limited.page.goto(pageUrl('connection'));
    check('Subscriber is denied the administrative page',denied.status()===403 && await limited.page.locator('.f3-google').count()===0);
    await limited.ctx.close();
    if (browserErrors.length) { throw Error('Page errors: '+JSON.stringify(browserErrors)); }
    check('No JavaScript page errors',true);
    console.log(JSON.stringify({checks,browser:browser.version(),viewports:['1440x900','390x844']}));
  } finally { await browser.close(); }
}


async function checkPlanner({page,root,check,input}) {
  const url=new URL(page.url());url.searchParams.set('section','connection');url.searchParams.set('connection_panel','services');url.searchParams.delete('advanced_panel');
  await page.goto(url.href);
  const card=root.getByRole('region',{name:'Acesso ao Google Ads',exact:true});
  const help=card.getByRole('complementary',{name:'Conferir o Planejador pelo MCP'});
  check('Ads configuration has named region and diagnostic group',await card.isVisible()&&await help.isVisible());
  check('MCP diagnosis is positioned after the save form',await help.evaluate(el=>el.previousElementSibling.tagName==='FORM'));
  check('Level description distinguishes declaration from Google verification',await card.locator('#f3-ads-level-help').innerText().then(t=>t.includes('Test exige conta de teste')&&t.includes('Explorer e Não informado')&&t.includes('salvar não comprova acesso')));
  check('Planner help explains five routes and disabled connector diagnosis',await help.innerText().then(t=>t.includes('cinco operações')&&t.includes('Ads desligado')&&t.includes('PLANEJADOR.md')));
  const selector=card.locator('#f3-ads-level');await selector.focus();
  check('Level selector accepts keyboard focus',await selector.evaluate(el=>el===document.activeElement));
  for(const width of [1440,390]){
    await page.setViewportSize({width,height:width===390?844:900});
    check('Ads description fits viewport '+width,await card.evaluate(el=>el.scrollWidth<=el.clientWidth+2&&el.getBoundingClientRect().right<=innerWidth+2));
    check('Planner help follows fields vertically '+width,await help.evaluate(el=>el.getBoundingClientRect().top>=el.previousElementSibling.getBoundingClientRect().bottom));
    await card.screenshot({path:input.scratch+'/planner-'+width+'.png'});
  }
  await page.setViewportSize({width:1440,height:900});
}
async function checkLayout({page,root,check,input,pageUrl}) {
  // Default section without parameter: Visão geral, read-only.
  const bare=new URL('/wp-admin/tools.php?page=wp-mcp-google-fator3&connection_id=browserqa',input.url);
  await page.goto(bare.href);
  check('Bare URL opens Visão geral',await root.getByRole('heading',{name:'Próximos passos',exact:true}).isVisible()&&await root.locator('nav.f3-tabs [aria-current="page"]').innerText()==='Visão geral');
  check('Overview is read-only (only the connection selector form)',await root.locator('main form').count()===0);
  check('Exactly one h1 named Fator3 MCP Google',await page.locator('h1').count()===1&&(await page.locator('h1').innerText()).trim()==='Fator3 MCP Google');
  const strip=root.getByRole('region',{name:'Estado da conexão'});
  check('Status strip shows four labelled indicators with text states',await strip.locator('li').count()===4&&(await strip.locator('.f3-badge').allInnerTexts()).every(t=>t.trim()!==''));
  const marker=await strip.locator('.f3-badge').first().evaluate(el=>getComputedStyle(el,'::before').content);
  check('State badge carries a shape marker besides color',marker!=='none'&&marker!=='normal');
  const step=root.locator('#f3-next-steps li.f3-check a').first();
  const href=await step.getAttribute('href');await step.click();await page.waitForLoadState('load');
  check('Next step link opens the panel where it is resolved',new URL(page.url()).searchParams.get('section')===new URL(href,input.url).searchParams.get('section')&&new URL(page.url()).searchParams.get('connection_id')==='browserqa');
  // Help: documents only here, authenticated download.
  await page.goto(pageUrl('help'));
  const docs=root.locator('a[href*="action=f3_mcp_google_documentation"]');
  check('Help lists the version documents',await docs.count()>=20);
  const readme=await root.locator('a[href*="document=README.md"]').getAttribute('href');
  const download=await page.request.get(new URL(readme,input.url).href);
  check('Help download is authenticated and served as attachment',download.status()===200&&(download.headers()['content-disposition']||'').includes('README.md'));
  const forged=await page.request.get(new URL(readme.replace(/_wpnonce=[^&]+/,'_wpnonce=invalid'),input.url).href);
  check('Download with an invalid nonce is refused',forged.status()!==200||!(forged.headers()['content-disposition']||'').includes('README.md'));
  await page.goto(pageUrl('connection',{connection_panel:'services'}));
  check('Other sections keep only a link to Help',await docs.count()===0&&await root.locator('.f3-footer a[href*="section=help"]').count()===1);
  // Wide layout: side navigation for panels.
  const side=await root.locator('.f3-subnav').evaluate(nav=>({dir:getComputedStyle(nav).flexDirection,left:nav.getBoundingClientRect().right<=document.querySelector('.f3-panel').getBoundingClientRect().left}));
  check('Panels use a side navigation on wide screens',side.dir==='column'&&side.left);
  // Narrow: Permissions fits, and long buttons wrap.
  await page.setViewportSize({width:390,height:844});
  await page.goto(pageUrl('connection',{connection_panel:'permissions'}));
  const fit=await page.evaluate(()=>{const b=[...document.querySelectorAll('.f3-google button, .f3-google select')].filter(e=>e.getBoundingClientRect().width>0);return {doc:document.documentElement.scrollWidth,vw:innerWidth,out:b.filter(e=>e.getBoundingClientRect().right>innerWidth+1).map(e=>e.textContent.trim().slice(0,40))};});
  check('Mobile Permissions panel has no control beyond the viewport',fit.doc<=fit.vw&&fit.out.length===0);
  const sel=await root.locator('#f3-connection').evaluate(el=>el.getBoundingClientRect().right<=innerWidth);
  check('Connection selector stays within the viewport on mobile',sel);
  const sub=await root.locator('.f3-subnav').evaluate(nav=>({rows:new Set([...nav.querySelectorAll('a')].map(a=>Math.round(a.getBoundingClientRect().top))).size,ox:getComputedStyle(nav).overflowX}));
  check('Mobile panel navigation is a horizontal strip',sub.rows===1&&sub.ox==='auto');
  await page.goto(pageUrl('help'));
  const active=await root.locator('nav.f3-tabs').evaluate(nav=>{const c=nav.querySelector('[aria-current="page"]').getBoundingClientRect(),n=nav.getBoundingClientRect();return c.left>=n.left-1&&c.right<=n.right+1;});
  check('Script scrolls the last active tab into view on mobile',active);
  const targets=await page.evaluate(()=>[...document.querySelectorAll('.f3-google .f3-tabs a, .f3-google .button')].filter(e=>e.getBoundingClientRect().height>0).map(e=>e.getBoundingClientRect().height));
  check('Touch targets of tabs and buttons are at least 40 px on mobile',targets.length>0&&Math.min(...targets)>=40);
  await page.setViewportSize({width:1440,height:900});
}
run(checkPlanner,checkLayout).catch(error=>{console.error(error.stack);process.exitCode=1;});
