<?php
use Fator3\McpGoogle\Ads\OriginAd;
use Fator3\McpGoogle\Integration\AdsServiceApi;
use PHPUnit\Framework\TestCase;

final class OriginAd034Test extends TestCase {
    /** @dataProvider locators */
    public function test_contract_locator_is_closed(array $input,bool $valid): void {
        $base=['contract'=>OriginAd::CONTRACT,'connection_id'=>'default','account_id'=>'1234567890','consumer_revision'=>'r1'];
        self::assertSame($valid,OriginAd::valid($input+$base));
    }
    public static function locators(): array {
        return [
            [['gclid'=>'Ab-c','date'=>'2024-02-29'],true],[['ad_id'=>'1'],true],[['ad_id'=>'001'],false],
            [['ad_id'=>'2 OR 1=1'],false],[['gclid'=>'ABC','date'=>'2026-02-29'],false],
            [['gclid'=>'a','date'=>'2026-11-10','ad_id'=>'1'],false],[['ad_id'=>'1','date'=>'2026-11-10'],false],
            [['ad_id'=>'1','account_id'=>true],false],[['ad_id'=>123],false],[['ad_id'=>'1','query'=>'SELECT'],false],
            [['gclid'=>str_repeat('a',1025),'date'=>'2026-11-10'],false],[['ad_id'=>'1','contract'=>'1'],false],
        ];
    }
    public function test_legacy_reader_has_distinct_remote_extension(): void {
        $caps=AdsServiceApi::capabilities();
        self::assertFalse($caps['remote_calls']);self::assertTrue($caps['extensions']['origin_ad']['remote_calls']);
        self::assertSame(OriginAd::output_schema(),$caps['extensions']['origin_ad']['output_schema']);
    }
}
