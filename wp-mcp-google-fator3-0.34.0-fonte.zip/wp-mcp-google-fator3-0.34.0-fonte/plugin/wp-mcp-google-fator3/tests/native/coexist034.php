<?php
require __DIR__.'/common.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
$all=get_plugins();
foreach (['core'=>'base-site-core-fator3','mcp'=>'wp-mcp-fator3','meta'=>'wp-mcp-meta-fator3','linkedin'=>'wp-mcp-linkedin-fator3','pipedrive'=>'wp-mcp-pipedrive-fator3','candidate'=>'wp-mcp-google-fator3'] as $name=>$slug) {
    $path=$slug.'/'.$slug.'.php';
    verifyLab($slug.' active at declared version '.expectedLab($name),is_plugin_active($path) && $all[$path]['Version']===expectedLab($name));
}
$client=Fator3\McpGoogle\Integration\AdsServiceApi::capabilities();
verifyLab('Google extension and Core archive contract coexist',$client['extensions']['origin_ad']['contract']==='google-ads-origin/1.0.0' && F3Base_Google_Acervo::status()['registrado']);
finishLab('coexist034');
