<?php
require __DIR__.'/common.php';
get_role('administrator')->add_cap('f3base_ler_leads');wp_set_current_user(0);wp_set_current_user(1);
global $wpdb;$opt=F3Base_Google_Acervo::OPTION;
$wpdb->replace($wpdb->options,['option_name'=>$opt,'option_value'=>maybe_serialize(['ativo'=>true,'conexao'=>'default','conta_id'=>'1234567890','revisao'=>1]),'autoload'=>'no']);
wp_cache_delete($opt,'options');wp_cache_delete('alloptions','options');wp_cache_delete('notoptions','options');
verifyLab('Old producer and experimental Core ready',F3_MCP_GOOGLE_VERSION==='0.33.0' && F3Base_Google_Acervo::configuracao()['ready'] && F3Base_Google_Acervo::status()['registrado']);
$r=wp_get_ability('f3base/google-ads-anuncio-origem')->execute(['ad_id'=>'1']);
verifyLab('Missing extension is handled without fallback',empty($r['ok']) && $r['codigo']==='sdk_ausente');
finishLab('absent034');
