# Fator3 MCP Google · 0.34.0

Índice da documentação instalada. Este documento identifica o plugin, publica o mapa dos documentos e explica como lê-los pelo MCP.

## Identidade

| Campo | Valor |
|---|---|
| Nome | Fator3 MCP Google |
| Slug | `wp-mcp-google-fator3` |
| Versão instalada | 0.34.0 |
| Requisitos | WordPress 7.1.4 ou superior; PHP 8.3 ou superior |
| Tela | **Ferramentas → Fator3 MCP Google** (exige `manage_options`) |
| Transporte para agentes | Plugin acompanhante Fator3 MCP; as operações do Google são habilidades da Abilities API do WordPress |

O plugin conecta o WordPress a Google Analytics 4, Google Ads, Search Console, Tag Manager, Site Verification, Sheets e Drive. Cada conexão reúne uma identidade Google, os serviços escolhidos, os recursos padrão e a política de acesso. O objetivo, as fronteiras com os outros plugins e os limites estão em `ESPECIFICACAO.md`.

## Mapa dos documentos

Cada documento lógico exigido aponta para um ou mais documentos instalados. Os identificadores da coluna da direita são os valores aceitos em `document` por `google/documentation`.

<!-- mapa-documentos -->
| Documento lógico | Documento(s) instalado(s) |
|---|---|
| Índice | `README.md` |
| Especificação | `ESPECIFICACAO.md` |
| Configuração | `GUIA-0.34.0.md`, `CORE-ACERVOS.md`, `configuration-definitions.json`, `profile-schema.json` |
| Uso | `RECEITAS.md`, `ANALYTICS.md`, `PLANEJADOR.md`, `ACERVO-ADS-GSC.md`, `CONVERSOES.md` |
| Contratos | `CONTRACTS.md`, `CONTRATOS-PUBLICOS.md`, `SDK-PHP.md`, `CONVERSION-DELIVERY-CORE-140.md`, `ability-catalog.json`, `stage-conversion-payload.json`, `core-conversions-capabilities.json`, `core-conversions-snapshot-input.json`, `core-conversions-snapshot.json` |
| Guia para agentes | `AGENT-GUIDE.md` |
| Operação | `MIGRACAO.md`, `ACOMPANHAMENTO-CRON.md`, `AVISOS-RENOVACAO.md`, `VALIDACAO.md` |
| Notas da versão | `CHANGELOG.md` |
<!-- /mapa-documentos -->

| Documento | Conteúdo |
|---|---|
| `GUIA-0.34.0.md` | Configuração e operação pelo painel: identidade, OAuth, serviços, permissões, Ads, conversões, acervo, diagnóstico e tarefas |
| `CORE-ACERVOS.md` | Configuração conjunta com o Fator3 Site Core dos leitores do acervo Ads e das consultas do Search Console |
| `configuration-definitions.json` | Definição de cada opção de configuração: tipo, padrão, escopo, dependências e operação que a altera |
| `profile-schema.json` | Estrutura do perfil GA4 aceito por `ga/aplicar-perfil` |
| `RECEITAS.md` | Sequências completas por tarefa, com chamadas, parâmetros e conferências |
| `ANALYTICS.md` | Coleta completa, calendário e exportação para planilha |
| `PLANEJADOR.md` | Planejador de palavras-chave do Google Ads, histórico local e junção com o Search Console |
| `ACERVO-ADS-GSC.md` | Acervo diário do Google Ads, SDK local de leitura e leitor de consultas do Search Console |
| `CONVERSOES.md` | Leitura do contexto de conversões do Site Core e diagnóstico GTM |
| `CONTRACTS.md` | Contratos de execução, envelope, confirmação, fila, cron, armazenamento, manutenção e configuração |
| `CONTRATOS-PUBLICOS.md` | Interfaces públicas trocadas com o Site Core e o Fator3 MCP |
| `SDK-PHP.md` | Leitores PHP do Search Console e do GA4 para outros plugins |
| `CONVERSION-DELIVERY-CORE-140.md` | Entrega de conversões pelo servidor (GA4 e Google Ads Data Manager) |
| `ability-catalog.json` | Catálogo gerado de todas as habilidades, com schemas de entrada e saída |
| `stage-conversion-payload.json` | Schema do payload de conversão por etapa comercial |
| `core-conversions-capabilities.json`, `core-conversions-snapshot-input.json`, `core-conversions-snapshot.json` | Cópias dos schemas do SDK de finalidades de conversão do Site Core |
| `AGENT-GUIDE.md` | Roteiro do agente: descobrir, ler, diagnosticar, configurar ou consultar, verificar e retomar |
| `MIGRACAO.md` | Instalação, atualização, desativação, desinstalação, recuperação e correção por nova versão |
| `ACOMPANHAMENTO-CRON.md` | Executor, histórico de passagens, agenda, manutenção e diagnóstico do cron |
| `AVISOS-RENOVACAO.md` | Política de e-mail das renovações automáticas de conversões |
| `VALIDACAO.md` | Verificação da instalação e limites da validação desta versão |
| `CHANGELOG.md` | Notas da 0.34.0 e histórico de versões anteriores, identificado como histórico |

## Primeira configuração

1. Instale o ZIP em **Plugins → Adicionar plugin → Enviar plugin** e ative. A ativação abre o canal Google, liga o Analytics, deixa o Google Ads desligado e não pede credencial nem agenda coleta.
2. Abra **Ferramentas → Fator3 MCP Google**. Confira a conexão selecionada no topo (`default` em uma instalação nova).
3. Em **Conexão → Identidade**, prepare a conta de serviço (JSON da chave) ou o OAuth (aplicativo Web, consentimento e ativação). Ative o método que será usado.
4. Em **Conexão → Serviços e recursos**, escolha os serviços, o nível de cada um (leitura ou escrita) e os recursos padrão. Revise o efeito antes de salvar.
5. Em **Conexão → Permissões**, restrinja contas, propriedades e operações ao escopo pretendido.
6. Em **Avançado → Diagnóstico**, clique em **Testar acessos agora**. O resultado mostra, por serviço e recurso, o que foi confirmado no Google.
7. Para operar por agente, mantenha o canal aberto e confira a conexão do agente no plugin Fator3 MCP (perfil e habilidades permitidas).

Os detalhes de cada passo estão em `GUIA-0.34.0.md`. O que exige credencial, nível de acesso do Google Ads ou contrato de outro plugin está em `ESPECIFICACAO.md`.

## Como ler a documentação pelo MCP

A habilidade `google/documentation` é local: não chama o Google, não usa credencial e exige `manage_options`. Pelo Fator3 MCP, chame a ferramenta `wp-mcp-ultimate-execute-ability` com `ability_name:"google/documentation"` e `parameters`, ou a ferramenta `google-mcp-read` com `ability:"google/documentation"` e `parameters`. `google-mcp-read` e `google-mcp-write` são os nomes, na lista de ferramentas do MCP, das habilidades `google/mcp-read` e `google/mcp-write`; os parâmetros de cada ferramenta estão em `AGENT-GUIDE.md`.

1. Índice: `google/documentation` com `{}`. A resposta traz `slug`, `plugin_version`, `documents[]` (`document`, `description`, `bytes`, `revision`), `max_limit_bytes` e as instruções de paginação.
2. Primeira página: `{"document":"AGENT-GUIDE.md","offset":0,"limit_bytes":16384,"expected_revision":"<revision do índice>"}`. `limit_bytes` aceita de 256 a 65536.
3. Continuação: repita com `offset` igual ao `next_offset` recebido e o mesmo `expected_revision`, até `next_offset: null`. A partir de `offset` maior que zero, `expected_revision` é obrigatório.
4. Conferência: `revision` (igual a `sha256`) é o SHA-256 do documento inteiro; `total_bytes` é o tamanho em bytes. A concatenação das páginas tem exatamente esses bytes.

Exemplo de página (valores ilustrativos; conteúdo encurtado):

```json
{"success":true,"message":"","slug":"wp-mcp-google-fator3","plugin_version":"0.34.0","origin":"local","encoding":"UTF-8","document":"AGENT-GUIDE.md","revision":"<sha256>","sha256":"<sha256>","total_bytes":20480,"offset":0,"returned_bytes":16384,"content":"# Guia para agentes…","has_more":true,"next_offset":16384}
```

| Código | Causa | Próxima ação |
|---|---|---|
| `f3_google_document_missing` | `document` fora do índice instalado, inclusive caminhos | Leia o índice e use um ID exato |
| `f3_google_document_revision` | `expected_revision` ausente na continuação ou diferente da revisão instalada | Releia o índice e recomece o documento |
| `f3_google_document_range` | `offset` ou `limit_bytes` fora da faixa, ou `offset` no meio de um caractere UTF-8 | Use `next_offset` exatamente como recebido |
| `f3_google_document_integrity` | Índice ou arquivo instalado diverge do pacote | Confira a versão e reinstale o pacote íntegro da mesma versão |
| `f3_google_forbidden` | Usuário sem `manage_options` | Use um administrador |

O painel oferece os mesmos documentos para download, pela mesma lista permitida.
