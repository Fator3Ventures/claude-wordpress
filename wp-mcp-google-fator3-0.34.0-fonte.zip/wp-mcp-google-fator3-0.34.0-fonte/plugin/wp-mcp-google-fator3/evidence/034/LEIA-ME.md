# Reproduzir a 0.34.0

A partir da raiz do plugin, execute os comandos abaixo. O instalador usa a lista explícita de runtime. Os JSON de insumos nesta pasta registram versões e hashes. Para o laboratório, adapte os caminhos a arquivos locais e envolva o mapa no objeto `{"schema_version":1,"inputs":{…}}`. Os caminhos para os instaladores dos acompanhantes devem ser absolutos. Use uma pasta de trabalho vazia por execução.

```sh
php build/export-contracts.php --check
python3 build/check-docs.py
python3 build/build.py candidate --output /tmp/wp-mcp-google-fator3-0.34.0-instalador.zip
php -d memory_limit=512M /caminho/phpunit-9.6.37.phar --configuration phpunit.xml --do-not-cache-result
F3_LAB_WP_EXPECTED=7.1.4 python3 tools/lab.py --manifest /insumos/manifest.json --workdir /tmp/g034-core --origin clean --order mcp-first tests/native/companions028.php tests/native/coexist034.php tests/native/patch-core034.php tests/native/origin034.php
F3_LAB_WP_EXPECTED=7.1.4 python3 tools/lab.py --manifest /insumos/manifest.json --workdir /tmp/g034-up --origin upgrade --order google-first tests/native/upgrade034.php
```

O ensaio de integração usa por padrão material sintético. A repetição privada com dados do fornecedor usa a variável opcional `F3_ORIGIN_FIXTURE` e as mesmas consultas de produção. O identificador de clique e as respostas brutas do CTO Office foram excluídos da entrega. A evidência pública registra a correspondência do anúncio e os tipos de mídia. A cópia experimental do Core é modificada apenas pelo teste `patch-core034`. Para o caso ausente, use um manifesto com o instalador 0.33.0 como candidato e rode a sequência `patch-core034.php absent034.php` com Core 1.80.0 em instalação limpa.

O navegador precisa de Node, Playwright e `F3_CHROMIUM` apontando para o Chromium headless shell. A faixa utiliza `companions028.php browser032.php`. As pastas por execução incluem os checks aprovados, a revisão exata do instalador e o ambiente. A pasta `current` usa Meta 0.24.0, observado no Site-Teste após a instalação do Google. Os ensaios iniciais usaram Meta 0.23.0. As duas passagens de migração verificaram os arquivos instalados do Google, MCP e Core por SHA-256.

O conjunto de fechamento passou a incluir Meta 0.24.1 e LinkedIn 0.21.0. Veja `closing-inputs.json`, `fechamento`, `fechamento-up`, `fechamento-ui` e `fechamento-doc`. A prova pós-implantação inicial e a observação posterior das versões aparecem em arquivos distintos.
