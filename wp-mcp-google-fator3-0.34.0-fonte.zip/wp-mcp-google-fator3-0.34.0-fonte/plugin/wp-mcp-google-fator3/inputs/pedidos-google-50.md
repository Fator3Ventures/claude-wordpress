# Pedidos — Fator3 MCP Google (wp-mcp-google-fator3)

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-google-fator3**. Cite como "Pedidos MCP Google N". Próximo número: 51; número retirado fica vago.

## wp-mcp-google-fator3 — pendentes

**50. Leitura do anúncio de origem para o Site Core (Pedidos core 390).** Pedido do dono de 11/11/2026 às 01:36 (texto no core 390). No Google Ads o sufixo de URL não se pede à agência (dono, 19/10/2026), então o contato do site chega só com gclid; o acervo do pacote já coleta click\_view com conta, campanha, grupo e anúncio (Conector, Ref. §3.6, 0.23.0 e 0.24.0). Pedido: um contrato de leitura para o Site Core que, dado gclid e data do clique (ou o ID do anúncio do formulário de lead do Google), devolva o anúncio do clique: tipo; nome e ID da campanha e do grupo; títulos, descrições, caminhos e URL final; nas campanhas Demand Gen e Performance Max, as imagens e o vídeo do YouTube dos recursos usados, com endereço baixável e miniatura; e o link para a campanha e o grupo no Google Ads. Quando o click\_view do dia ainda não foi coletado, a resposta diz "pendente" e a hora prevista da coleta. Aceite: em ctooffice.com.br, um gclid real de 10/11/2026 da campanha "\[Demand Gen\] CTO Office — BR" devolve o anúncio com a imagem, só leitura.
