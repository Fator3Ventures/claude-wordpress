# Instalação, atualização, desinstalação e recuperação · 0.34.0

Procedimentos de ciclo de vida da release instalada. Uma versão instalada não é revertida: correção é feita por uma nova versão.

## Requisitos

WordPress 7.1.4 ou superior e PHP 8.3 ou superior. Tela, leitura de dados de conta e escrita de configuração exigem `manage_options`.

## Instalação limpa

1. Confira o SHA-256 do instalador contra o publicado para a versão.
2. **Plugins → Adicionar plugin → Enviar plugin**, envie o ZIP e ative.
3. A ativação cria as opções iniciais quando ausentes (canal aberto, Analytics ligado, Google Ads desligado, autenticação `service_account`, versão padrão da Ads API, limites de linhas e de tempo), prepara as tabelas `{prefix}f3_google_records` e `{prefix}f3_google_cron` e agenda o executor e a manutenção. Não pede credencial, não concede acesso e não coleta dados.
4. Em nova requisição: `google/status {"compact":true}` e `google/documentation {}` devem informar `plugin_version` 0.34.0.
5. Configure pelo `GUIA-0.34.0.md`.

## Atualização direta 0.33.0 → 0.34.0

1. Antes: anote `google/status {"compact":true}` (versão, conexão, identidade, serviços) e faça backup do banco, dos arquivos de `wp-content/f3-google-state/` e das salts do `wp-config.php`, que protegem credenciais e acervo cifrados.
2. Envie o ZIP da 0.34.0 em **Plugins → Adicionar plugin → Enviar plugin** e confirme a substituição da versão instalada. Não desinstale antes.
3. Em nova requisição: `google/status {"compact":true}` com `plugin_version` 0.34.0; `google/readiness-status {}`; `google/documentation {}` com `ESPECIFICACAO.md` e `GUIA-0.34.0.md` no índice.
4. Reabra formulários que estavam abertos no navegador antes da troca.

A atualização não altera tabelas, não migra dados e preserva configurações, credenciais, candidatas OAuth, acervos, jobs, agendas, recibos e revisões.

A permissão para buscar o criativo começa desligada. Para habilitá-la, abra Acervo Ads, selecione a conta e autorize o leitor no campo Anúncio de origem do contato.

### Serviços e recursos na 0.33.0

O painel aceita IDs conhecidos de propriedade e planilha e oferece sugestões quando há uma consulta disponível. O resultado da busca informa se ela terminou, se a lista é parcial ou se houve falha. Reabra o painel se sua configuração mudou em outra aba.

### Mudanças introduzidas na 0.32.0


| Mudança | Efeito | O que fazer |
|---|---|---|
| Campos de saída renomeados | Nomes que o transporte MCP mascarava foram trocados, sem aliases (tabela abaixo) | Clientes que liam os nomes antigos passam a ler os novos. Parâmetros de entrada, inclusive `page_token`, não mudaram; dados gravados continuam legíveis |
| Falhas de agenda `duplicate_event` | Recusas `duplicate_event` com evento equivalente deixam de virar erro ativo; um erro antigo desse tipo é resolvido na passagem da manutenção que encontrar ocorrência pendente do mesmo gancho e argumentos (`resolved_by:"duplicate_event_equivalent"`); sem essa ocorrência, continua ativo | Depois da troca, aguarde ou execute `google/maintenance {}` e confira `scheduling_active_errors` no compacto. Até essa passagem, `health` pode continuar `degraded` |
| Status compacto com saúde | `google/status {"compact":true}` passa a trazer `health`, `work_health`, `scheduling_active_errors` e `incidents_open` | Use o compacto para acompanhamento; a resposta completa continua igual, salvo os renomes |
| Tela de configuração | Cabeçalho com seletor de conexão; faixa de estado com Canal MCP, Identidade, Serviços ativos e Prontidão local; abas em uma linha (Visão geral, Conexão, Conversões, Acervo Ads, Search Console, GTM, Incidentes, Avançado, Ajuda); painéis de Conexão e Avançado em menu lateral em tela larga; seções novas Visão geral e Ajuda. A lista de documentos saiu do rodapé de cada aba e ficou só em Ajuda. Mesmas ações, nomes de campo, nonces e permissões | Nenhuma ação; recarregue formulários abertos antes da troca. Links antigos com `connection_panel` ou `advanced_panel` sem `section` abrem a seção correspondente |
| Desinstalação | Todo segredo de `Options::secret_names()` é removido, inclusive `mp_secret`, que na 0.31.0 permanecia sem purge | Nenhuma ação |
| Documentação instalada | Índice com mapa de documentos, `ESPECIFICACAO.md` novo, guia identificado pela versão instalada | Leia o índice novamente; revisões dos documentos mudaram |

Campos de saída renomeados na 0.32.0:

<!-- campos-renomeados -->
| Habilidade | Nome antigo | Nome atual |
|---|---|---|
| `google/executar-vencidos` | `pass` | `run` |
| `google/executar-vencidos` | `maintenance.reused_pass` | `maintenance.reused_run` |
| `google/status` | `cron.last_pass` (também em `connections[].cron`) | `cron.last_run` |
| `google/status` com `live:true` | `token_ok` | `auth_probe` |
| `google/maintenance`, `google/storage-status`, `google/status`, `google/executar-vencidos` | `progress.<família>.examined_in_pass` | `progress.<família>.examined_in_run` |
| `google/readiness-status` (check `executor`, `detail`) | `last_pass_at` | `last_run_at` |
| `google/readiness-status` (check `executor`, `detail`) | `last_pass_age` | `last_run_age_seconds` |
| `google/ability-catalog` | `authorization` | `execution_checks` |
| `google/configuration-schema` | `authorization` | `access_requirements` |
| `google/configuration-schema` | `options.*.secret` | `options.*.confidential` |
| `google/configuration-schema` | `runtime_prerequisites.credentials` | `runtime_prerequisites.authentication` |
| `google/selftest` | `data_manager.credential` | `data_manager.identity_requirement` |
| `google/selftest` | `data_manager.developer_token` | `data_manager.developer_access` |
| `google/export-template` | `secrets_included` | `confidential_included` |
| `google/status` | `telemetry.counters.token_requests` | `telemetry.counters.auth_requests` |
| `google/status` | `quota_observations.observations[].observations.tokensPerDay` | `quota_observations.observations[].observations.quota_units_per_day` |
| `google/status` | `quota_observations.observations[].observations.tokensPerHour` | `quota_observations.observations[].observations.quota_units_per_hour` |
| `google/status` | `quota_observations.observations[].observations.tokensPerProjectPerHour` | `quota_observations.observations[].observations.quota_units_per_project_per_hour` |
| `google/status` | `quota_observations.observations[].observations.concurrentRequests` | `quota_observations.observations[].observations.concurrent_requests` |
| `google/status` | `quota_observations.observations[].observations.serverErrorsPerProjectPerHour` | `quota_observations.observations[].observations.server_errors_per_project_per_hour` |
| `google/status` | `quota_observations.observations[].observations.potentiallyThresholdedRequestsPerHour` | `quota_observations.observations[].observations.potentially_thresholded_requests_per_hour` |
| `ga/send-event` com `debug:true` | `credential_validated` | `access_validated` |
| `ga/send-event` com `debug:false` | `secret_persisted` | `confidential_persisted` |
| `ga/create-mp-secret` | `secret_persisted` | `confidential_persisted` |
| `google/plan-template` | `credentials_promoted` | `confidential_promoted` |
| `google/cleanup-jobs` com `dry_run:true` | `max_records_per_pass` | `max_records_per_run` |
| `ads/search`, `ads/get-campaign`, `ads/list-conversion-actions`, `ads/list-assets`, `ads/list-audiences`, `ads/list-users`, `ads/list-experiments` | `next_page_token` | `next_page` |
| `ga/list-users` | `next_page_token` (texto vazio sem próxima página) | `next_page` (`null` sem próxima página) |
| `ga/get-settings` | `truncated_sections.<seção>.next_page_token` | `truncated_sections.<seção>.next_page` |
| `siteverification/get-token` | `token` (repetido em `data.token`) | `verification_value` (`data` sai sem `token`) |
<!-- /campos-renomeados -->

Nas observações de cota, cada chave nova traz `google_field` com o nome original do Google (`tokensPerDay` etc.). O contador de telemetria lê as horas gravadas antes da troca com o nome novo. Nas listagens do Ads e do GA Admin, o parâmetro de entrada continua `page_token`: envie nele o valor de `next_page`. Aditivo: `google/execute-read` acrescenta `next_page` quando a resposta do Google traz `nextPageToken` no nível superior de `data` (mesmo valor; `data` não muda; para a página seguinte, envie-o em `query.pageToken`).

## Desativação

Desativar retira as habilidades do registro e:

- remove os eventos `f3_mcp_google_jobs_tick` e `f3_mcp_google_maintenance`, sem executar trabalho;
- apaga os tokens de acesso em cache e os transients `f3_mcp_google_*`;
- apaga os arquivos de cache de `wp-content/f3-google-cache/`.

Credenciais, configuração, tabelas e acervos ficam. Em multisite, a desativação de rede repete isso em cada site. Reativar agenda o executor e a manutenção novamente.

## Desinstalação

Desinstalar (excluir o plugin desativado) executa `uninstall.php` em cada site. O comportamento depende da opção `purge_on_uninstall` (**Avançado → Modelos e manutenção** ou `google/configure-local`), padrão desligada.

| Item | Sem `purge_on_uninstall` | Com `purge_on_uninstall` |
|---|---|---|
| Eventos cron, tokens em cache, transients | Removidos | Removidos |
| Todo segredo declarado pelo plugin (chave da conta de serviço, segredo e token OAuth, developer token, segredo do Measurement Protocol `mp_secret`, candidatas) e também assunto, e-mail e escopos OAuth, índice de tokens e travas | Removidos (em todas as conexões) | Removidos |
| Demais opções `f3_mcp_google_*` (configuração, conexões, política, concessões, destinos de conversão, Client ID OAuth) | Permanecem; canal fechado (`enabled:false`), `auth_ready:false`, alertas e e-mail desligados | Removidas |
| Tabela `{prefix}f3_google_records` | Permanece; jobs e agendas pausados (`blocked_reason: plugin_uninstalled_requires_reauthorization`, escritas em andamento ficam `unknown`); confirmações e candidatas removidas | Excluída |
| Tabela `{prefix}f3_google_cron` | Permanece | Excluída |
| Diretórios `wp-content/f3-google-state/` e `wp-content/f3-google-cache/` | Permanecem (os arquivos de cache já foram apagados na desativação) | Permanecem |
| Transients de rede (multisite) | Removidos | Removidos |

A lista de segredos removidos é a de `Options::secret_names()`, sempre, com ou sem purge. Na 0.31.0, o `mp_secret` sobrevivia à desinstalação sem purge; na 0.32.0 ele é removido.

Limite conhecido desta versão: os diretórios `wp-content/f3-google-state/` e `wp-content/f3-google-cache/` permanecem depois da desinstalação, com ou sem purge. O administrador os remove manualmente, depois de excluir o plugin, se não for reinstalar. Uma reinstalação sem purge encontra o canal fechado e exige nova credencial e nova autorização dos jobs e agendas pausados.

## Recuperação de dados e retomada

Para restaurar banco ou arquivos sem perder controle sobre efeitos remotos:

1. `google/recovery {"action":"prepare"}`: pausa o despacho e aguarda drenagem. Acompanhe `google/recovery-status` até `ready_for_restore:true`.
2. Restaure banco e arquivos. Não copie uma sentinela antiga de `wp-content/f3-google-state/` sobre a pausa atual; todos os processos PHP e CLI precisam ler o mesmo volume.
3. Reconcilie o que estava incerto: jobs `unknown` por `google/get-job` e `google/reconcile-job`; conversões pelos recibos; publicações GTM por `gtm/get-publication`.
4. `google/recovery {"action":"resume","expected_generation":<geração atual>,"acknowledge_reconciled":true}`. A nova geração invalida caches de token e contextos restaurados.

A preparação não desfaz operações remotas já realizadas. Uma falha de página do planejador ou da coleta conserva o último checkpoint confirmado; releia o recibo antes de retomar. Conversões com resultado incerto exigem reconciliação por recibo antes de qualquer nova tentativa.

## Correção por nova versão

Se surgir regressão depois de instalar: pause o fluxo afetado (desligue o serviço ou a agenda), preserve registros e recibos e instale uma versão posterior com a correção. Não restaure arquivos de uma versão anterior. Os dados de recuperação e os recibos de efeitos externos precisam acompanhar a correção.
