# Guia de configuração e operação · 0.34.0

Configuração e operação pelo painel **Ferramentas → Fator3 MCP Google**, que exige `manage_options`. Os equivalentes por habilidade estão em `RECEITAS.md`; o roteiro do agente em `AGENT-GUIDE.md`.

## Navegação da tela

### Cabeçalho

Título **Fator3 MCP Google**, a versão instalada e o formulário **Conexão**: a lista mostra cada conexão como `rótulo (id)` e o botão **Abrir conexão** recarrega a tela com a conexão escolhida, mantendo a aba e o painel abertos. Todos os formulários abaixo usam a conexão selecionada. Em **Avançado → Limites e auditoria**, a linha abaixo do cabeçalho avisa que limites e auditoria abrangem todas as conexões do site.

### Faixa de estado

Logo abaixo do cabeçalho, em todas as abas, a faixa **Estado da conexão** tem quatro indicadores. Cada um traz o nome, um selo com o estado em texto e um marcador de forma (a cor não é o único sinal), uma linha de detalhe e um link para onde o estado é resolvido.

| Indicador | Estados do selo | Detalhe | Link |
|---|---|---|---|
| Canal MCP | Habilitado, Bloqueado | Se as chamadas Google estão permitidas no site; acrescenta "Controlado também por filtro." quando o filtro `f3_mcp_google_enabled` está ativo | **Controle do site** (Avançado → Limites e auditoria) |
| Identidade | Ativa, Ativação pendente, Falha de leitura, Ausente | Método (Conta de serviço ou Conta Google · OAuth) e situação da credencial ativa e da candidata | **Identidade** (Conexão → Identidade) |
| Serviços ativos | `N serviço`/`N serviços`, Nenhum | Nomes dos serviços ligados na conexão | **Serviços e recursos** |
| Prontidão local | Em Visão geral e Conversões: Pronta, Requer atenção, Bloqueada ou Indisponível. Nas demais abas: Na Visão geral | Em Visão geral e Conversões, o número de pendências das verificações locais. Nas demais abas a prontidão não é calculada e o detalhe aponta para a Visão geral | **Próximos passos** (Visão geral e Conversões) ou **Consultar prontidão** (demais abas), ambos para a lista de Próximos passos |

A prontidão local é a mesma leitura de `google/readiness-status`, sem chamada ao Google; ela só é calculada nas abas que a exibem por inteiro. Em tela estreita, os quatro indicadores ficam em duas colunas e a linha de detalhe sai da tela, mas continua disponível para leitores de tela; o selo e o link continuam visíveis.

### Abas e menu lateral

- **Abas principais**, em uma única linha: Visão geral, Conexão, Conversões, Acervo Ads, Search Console, GTM, Incidentes, Avançado e Ajuda. A aba aberta fica sublinhada. Quando as abas não cabem na largura (celular), a linha rola na horizontal; as abas não quebram em várias linhas.
- **Painéis de Conexão**: Identidade, Serviços e recursos, Permissões. **Painéis de Avançado**: Limites e auditoria, Diagnóstico, Tarefas e agendas, Modelos e manutenção, Credenciais avançadas, Contrato de configuração.
- Em tela larga (área do plugin com 1000 px ou mais), os painéis ficam num menu lateral à esquerda, que acompanha a rolagem da página. Em tela mais estreita, o mesmo menu vira uma linha acima do painel, com rolagem horizontal.
- Links gravados antes da 0.32.0 com `connection_panel` ou `advanced_panel` e sem `section` abrem a seção correspondente.
- Em todas as abas, exceto Ajuda, o rodapé tem um único link: **Documentação desta versão e leitura pelo MCP**, que abre a aba Ajuda. A lista de documentos não se repete nas outras abas.

### Visão geral

A aba inicial. Três cartões, todos com dados locais, sem chamada ao Google:

1. **Próximos passos**: selo com o estado geral (Pronta, Requer atenção ou Bloqueada) e um item por verificação de `google/readiness-status`, ordenados por gravidade (Bloqueado, Requer atenção, Não configurado, Em ordem). Cada item tem título, selo, o texto da próxima ação quando não está em ordem e um link **Abrir …** para o lugar que resolve:

   | Item | Link |
   |---|---|
   | Credencial da conexão | Conexão → Identidade (Avançado → Limites e auditoria quando o canal está bloqueado) |
   | Armazenamento local | Avançado → Diagnóstico |
   | Recuperação após restauração | Avançado → Tarefas e agendas |
   | Executor de tarefas e agenda | Avançado → Tarefas e agendas |
   | Entrega de conversões ao Google Analytics | Conversões |
   | Entrega de conversões ao Google Ads | Conversões |
   | Incidentes | Incidentes |
   | Contexto do Site Core | Conversões |

2. **Serviços desta conexão**: tabela com Serviço, Nível (Leitura, Leitura e escrita, Administração) e Recurso padrão (ou "Não selecionado"/"Sem recurso padrão"), e o link **Abrir Serviços e recursos**. Em tela estreita, cada linha vira um bloco com os três rótulos.
3. **Operação**: Executor e agenda (Em funcionamento, Nenhuma passagem registrada, Sem passagem há mais de uma hora ou Agenda do executor não confirmada), Próxima ocorrência agendada, Última manutenção (estado e horário) e Incidentes (Nenhum aberto ou o número de abertos), com os links **Tarefas e agendas**, **Manutenção** e **Incidentes**.

### Ajuda

Dois cartões:

1. **Documentos da versão** com os documentos instalados em seis grupos. Cada item mostra a descrição como link de download (exige sessão de administrador), o identificador e o tipo (Markdown ou JSON).

   | Grupo | Documentos |
   |---|---|
   | Comece por aqui | `README.md`, `ESPECIFICACAO.md`, `GUIA-0.34.0.md`, `CHANGELOG.md` |
   | Uso dos serviços | `ANALYTICS.md`, `PLANEJADOR.md`, `ACERVO-ADS-GSC.md`, `CONVERSOES.md` |
   | Operação e manutenção | `ACOMPANHAMENTO-CRON.md`, `AVISOS-RENOVACAO.md`, `VALIDACAO.md`, `MIGRACAO.md` |
   | Agentes e MCP | `AGENT-GUIDE.md`, `RECEITAS.md`, `CONTRACTS.md`, `ability-catalog.json` |
   | Integração entre plugins | `CONTRATOS-PUBLICOS.md`, `SDK-PHP.md`, `CORE-ACERVOS.md`, `CONVERSION-DELIVERY-CORE-140.md`, `core-conversions-capabilities.json`, `core-conversions-snapshot-input.json`, `core-conversions-snapshot.json` |
   | Schemas de configuração | `configuration-definitions.json`, `profile-schema.json`, `stage-conversion-payload.json` |

2. **Leitura pelo MCP**: os quatro passos de `google/documentation` (índice com `{}`, primeira página com `document` e `limit_bytes`, continuação por `next_offset` com `expected_revision`, recomeço pelo índice se a revisão mudar). O mesmo roteiro está em "Ler o manual pelo MCP", no fim deste guia.

## O que fazer em cada painel

| Onde | Cartões e ações | Como conferir |
|---|---|---|
| Cabeçalho | **Conexão** e **Abrir conexão** | O nome da conexão no seletor e o indicador Identidade |
| Visão geral | Próximos passos, Serviços desta conexão, Operação; somente leitura | Siga o link **Abrir …** de cada pendência |
| Conexão → Identidade | Cartão **Autenticação** com as abas de método **Conta de serviço · padrão** e **Conta Google · OAuth** (selo **Em uso** no método ativo); cartão **Conta de serviço salva**; **Nome da conexão** (**Salvar nome**) e **Adicionar conexão** (**Criar conexão**), recolhidos | Indicador Identidade e as etapas da conta de serviço |
| Conexão → Serviços e recursos | **Serviços e recursos** (**Salvar serviços e recursos**, **Revisar alterações**); **Acesso ao Google Ads** quando Ads está na seleção (**Salvar acesso ao Google Ads**); **Consultar recursos acessíveis** (**Consultar recursos**, **Consultar próxima página**); link **Verificar acessos em Diagnóstico** | Revise a prévia de **Revisar alterações**; reduções pedem confirmação |
| Conexão → Permissões | **Permissões por recurso** (**Consultar recursos disponíveis para definir a política**, **Conferir impacto antes de salvar**) | Confira a prévia antes de aplicar a política |
| Conversões | **Prontidão operacional**, **Entrega de conversões**, **Destinos** (**Consultar propriedades e fluxos**, **Consultar contas e ações**, **Salvar destinos e autorização**), **Verificar acesso** (**Verificar destino**), **Avisos da renovação**, **Ações comerciais por etapa**, **Perfis GA4** (**Comparar sem alterar o Google**, **Salvar definição local**) | **Verificar destino** depois de salvar |
| Acervo Ads | **Acervo Google Ads** com a lista **Conta para editar** (contas da conexão e a opção **Nova conta**) e **Abrir conta**; **Coleta diária** (**Salvar coleta**); **Leitores do acervo** (**Salvar permissão do leitor**); **Planejador de palavras-chave** | Confira os valores carregados da conta antes de salvar |
| Search Console | **Propriedade e sitemap** (**Consultar recursos da conta**, **Salvar seleção**); **Verificar Search Console** (**Verificar acesso e configuração**); **Leitura de consultas, páginas e dias** (**Salvar permissão de consultas**) | Resultado de **Verificar acesso e configuração** |
| GTM | **Conta e contêiner** (**Consultar recursos da conta**, **Salvar seleção**) | A seleção não publica tags |
| Incidentes | **Incidentes** (tabela Ocorrência, Estado, O que fazer, Última atualização) e **Alertas operacionais** (**Salvar preferências de alerta**) | `google/status {"compact":true}` → `incidents_open` |
| Avançado → Limites e auditoria | **Controle do site** (**Bloquear chamadas Google** ou **Permitir chamadas Google**), **Limites do site** (**Salvar**), **Auditoria** (**Limpar auditoria**, recolhido), **Informações técnicas** | Indicador Canal MCP; efeito em `google/configuration-schema` |
| Avançado → Diagnóstico | **Verificar a conexão** (**Testar acessos agora**), **Resultado da última verificação**, **Capacidades do servidor** | Seção "Executar e interpretar o diagnóstico" abaixo |
| Avançado → Tarefas e agendas | **Integração com plugins** (**Salvar autorização**), **Execução das tarefas**, **Restauração e recuperação** (**Conferir drenagem**), **Tarefas e agendas** (consulta, aprovação, passagens, cancelamento, reconciliação, **Criar agenda de leitura**, **Executar tarefas e agendas vencidas**), **Histórico e incidentes** | Histórico de execução da tarefa; admissão não comprova execução |
| Avançado → Modelos e manutenção | **Modelos de configuração** (**Gerar modelo sem segredos**, **Ver diferenças antes de aplicar**), **Manutenção do armazenamento** (**Avançar um lote de manutenção**), **Distribuição e manutenção** (**Salvar origem**; **Salvar manutenção**, com auditoria de leituras locais e limpeza na desinstalação) | `google/storage-status` depois da manutenção |
| Avançado → Credenciais avançadas | O mesmo painel da conta de serviço, com o campo de texto **Chave JSON da conta de serviço (Service account key)** dentro de **Ajustar delegação da conta de serviço** e os detalhes técnicos em JSON | Indicador Identidade |
| Avançado → Contrato de configuração | Seletor **Opção** e **Consultar**: mostra a definição de uma opção | Catálogo completo em `configuration-definitions.json` (aba Ajuda) |
| Ajuda | Documentos para download e leitura pelo MCP | Revisão de cada documento em `google/documentation {}` |

## Conexão e identidade

Uma conexão reúne identidade, serviços, recursos padrão e política. A instalação começa com a conexão `default`; outras conexões são criadas em **Conexão → Identidade** (abaixo da autenticação) e podem ser renomeadas. Escolha o método:

- **Conta de serviço**: envie o JSON da chave. O assunto (delegação de domínio) é opcional. A chave é validada antes de substituir a ativa; rotação de chave da mesma conta mantém a identidade.
- **OAuth**: aplicativo Web do Google Cloud, consentimento da conta Google e ativação (seção seguinte).

Uma credencial nova fica como candidata até ser validada e ativada; falha mantém a ativa. Credenciais são cifradas e nunca são exibidas depois de salvas.

### Etapas da conta de serviço

Na aba de método **Conta de serviço · padrão**, o cartão **Autenticação** começa por uma sequência de cinco etapas. Cada etapa mostra nome, estado em texto e uma dica. Uma etapa só aparece como concluída quando o dado local comprova; a primeira etapa pendente aparece como **Etapa atual**.

| Etapa | Concluída quando | Estados possíveis |
|---|---|---|
| Importar chave | Há chave salva ou candidata pronta | Concluída, Etapa atual, Pendente |
| Ativar a Conta de serviço | O método em uso na conexão é a conta de serviço, com credencial legível | Concluída, Etapa atual, Pendente |
| Conceder acesso no Google | Não comprovável localmente | Conferir no Google |
| Selecionar serviços e recursos | Há ao menos um serviço ligado | Concluída, Etapa atual, Pendente |
| Testar acessos | O último teste de **Avançado → Diagnóstico**, feito com a conta de serviço ativa e a configuração atual, foi aprovado | Concluída, Etapa atual, Pendente, Reprovada |

Abaixo das etapas: o estado da chave; **Como criar o projeto e a chave no Google Cloud** (recolhido, com **Baixar script de referência**); o envio do arquivo da chave (**Salvar** ou **Salvar e usar Conta de serviço**); **Ajustar delegação da conta de serviço** (assunto); **Usar Conta de serviço** quando há candidata pronta da mesma identidade, ou **Simular troca de identidade** e **Trocar identidade** quando a candidata é outra conta; **Conceder acesso aos serviços**, com o link de cada serviço ligado; **Selecionar serviços e recursos**; e **Remover credenciais Conta de serviço** (recolhido).

## Conectar e trocar um aplicativo OAuth

Em **Conexão → Identidade → Conta Google · OAuth**, siga as três etapas:

1. **Configurar aplicativo Web.** Cadastre a URL de retorno exibida no cliente Web do Google Cloud. Importe o JSON desse cliente ou abra os campos manuais. A importação confere o tipo e o callback; o consentimento confirma o acesso ao aplicativo. Para manter o mesmo Client ID, deixe o segredo vazio. Um novo Client ID exige seu próprio Client secret. Alterar o aplicativo prepara uma candidata e solicita novo consentimento.
2. **Autorizar conta Google.** Escolha os serviços antes de abrir o consentimento. O botão só fica disponível depois de salvar o par Client ID e Client secret. Confira a conta selecionada no Google. O retorno prepara a candidata e mantém a autorização em uso até a etapa seguinte.
3. **Conferir e ativar autorização.** Compare os cartões da autorização salva e da candidata. Clique em **Usar OAuth** para verificar autenticação e acesso aos recursos vinculados, inclusive o contêiner GTM. Falha de acesso mantém a autorização salva. Sem recursos vinculados, só a autenticação é comprovada; vincule e teste os recursos depois.

| Ação | Resultado local | Próximo passo |
|---|---|---|
| Salvar o mesmo aplicativo com segredo vazio | Preserva o segredo e o consentimento preparado | Autorize novamente apenas quando necessário |
| Trocar Client ID ou segredo | Prepara o aplicativo e limpa o consentimento da candidata | Autorizar a conta e ativar |
| Desconectar esta conexão | Remove autorizações salva e candidata, conservando os aplicativos | Obter novo consentimento antes de ativar |
| Revisar revogação no Google | Prepara a revogação da autorização salva; exige a confirmação apresentada | Conferir o alcance no usuário e projeto antes de executar |
| Remover credenciais | Exclui aplicativos e autorizações OAuth desta conexão | Configurar novamente desde a etapa 1 |

A revogação do Google pode afetar outros clientes do mesmo usuário e projeto. Uma candidata de outro projeto é removida apenas deste WordPress. Para retirar também o consentimento desse outro projeto, use as permissões da conta Google. Referência: [OAuth para aplicativos Web](https://developers.google.com/identity/protocols/oauth2/web-server#tokenrevoke).

Se aparecer **A configuração mudou**, recarregue a tela e confira a conexão. Um consentimento iniciado antes da desconexão não pode restaurar a autorização. Se uma gravação local falhar, confira o erro e a configuração persistida antes de repetir. A revogação remota, quando já concluída, não pode ser desfeita pelo WordPress.

## Serviços, recursos e permissões

Em **Conexão → Serviços e recursos**, ligue cada serviço com o nível necessário (leitura, escrita e, em GA4 e GTM, administração) e escolha os recursos padrão (propriedade GA4, cliente Ads, site do Search Console, contêiner GTM). **Revisar alterações** mostra antes e depois; reduções de acesso pedem confirmação. Recursos padrão não concedem autorização.

Para preparar o GA4, digite o ID numérico da propriedade. Para o Sheets, informe o ID da planilha ou cole a URL do arquivo. Se já conhece esses valores, pode preencher os campos ao habilitar o serviço, inclusive com JavaScript desativado. O painel ignora valores de um serviço que continua desligado.

Para escolher pelo nome, salve o nível do serviço e use **Consultar recursos**. Volte ao campo de propriedade ou planilha para abrir as sugestões. Uma consulta parcial exibe os resultados daquela página. Em Sheets, **Consultar próxima página** apresenta a página seguinte. A escolha só é gravada ao salvar. Se a consulta falhar, confira a identidade e as permissões do recurso. Se a configuração mudar durante a consulta, reabra a tela e consulte novamente.

Em **Conexão → Permissões**, a política define o alcance: `identity` usa todo o acesso da identidade; `restricted` permite só os recursos listados. Conexões novas começam restritas. Revise a prévia antes de aplicar; recurso fora da política é recusado com `f3_google_policy_denied`.

## Google Ads

A conta anunciante (`ads_customer_id`) identifica o cliente consultado. A gerenciadora (`ads_login_customer_id`) identifica por onde a credencial acessa esse cliente. O nível do planejador vem da declaração feita a partir do Google Cloud Console. O resumo na aba **Acervo Ads** mostra o nível e as operações observadas neste WordPress. O manual `PLANEJADOR.md` contém as chamadas completas, em português.

## Conversões

Consulte propriedades e fluxos GA4 ou contas e ações Ads pelos botões do respectivo destino. Uma consulta completa atualiza por 15 minutos as opções daquela identidade, conta ou propriedade. Se a consulta falhar ou vier incompleta, o painel mantém a última lista completa enquanto seu cache for válido. Um destino salvo continua visível para revisão. Para gravar um novo segredo, preencha-o imediatamente antes de clicar em **Salvar destinos e autorização**.

Uma verificação usa a conexão exibida no formulário. Se o contexto mudou ou o painel indicar conflito de revisão, recarregue a tela, confira os valores atuais e aplique novamente a intenção. Consulte `AVISOS-RENOVACAO.md` para o prazo de atenção e a recuperação dos avisos.

## Acervo diário

Use **Conta para editar → Abrir conta** antes de alterar uma coleta existente. A tela carrega os conjuntos de dados, janelas e autorizações salvos para aquela conta. **Nova conta** começa com coleta desligada. A autorização para armazenar dados e a permissão de um plugin para lê-los são decisões separadas. Ao pausar a coleta, o histórico permanece disponível segundo a política da conexão.

## Diagnóstico local e verificação remota

`google/status` com `{"compact":true}` resume a configuração e a saúde local (`health`, `work_health`, `scheduling_active_errors`, `incidents_open`) sem consultar o Google. `google/readiness-status` detalha credencial, armazenamento, executor e destinos. Use `google/ability-catalog` para ver se a operação está disponível na conexão. Em caso de Explorer, a leitura histórica já arquivada e as chamadas ao fornecedor têm condições diferentes. Para conferir os dados da conta ou validar uma permissão efetiva, execute a operação de leitura autorizada.

### Executar e interpretar o diagnóstico

1. Em **Conexão → Serviços e recursos**, escolha **Verificar acessos em Diagnóstico**. Confira a conexão e o método de autenticação. Abrir a página apenas lê o último resultado.
2. Clique em **Testar acessos agora** para verificar a configuração exibida. Se outra aba tiver alterado essa configuração, recarregue o painel, confira a identidade e os recursos e inicie um novo teste.
3. Leia primeiro **Acesso aos serviços Google**. Cada linha descreve o recurso e o próximo passo. Abra **Verificações locais do plugin** para investigar o WordPress, o servidor MCP ou a criptografia. Uma leitura aprovada confirma só aquele acesso e naquele instante.
4. O resultado fica disponível por até uma hora para quem executou o teste. Um resultado marcado como anterior descreve a configuração da ocasião. Para confirmar os acessos atuais, execute novamente.

### Trabalhar com duas abas e exportar uma auditoria

Em **Avançado → Tarefas e agendas**, abra cada resultado na mesma aba que gerou a prévia. Você pode, por exemplo, gerar um CSV em uma aba e um JSON em outra. Cada link abre o seu resultado por até dez minutos, vinculado ao administrador e à conexão. Durante esse prazo, repetir o download devolve os mesmos bytes.

Para aplicar uma limpeza, confira a prévia de limpeza e confirme nela. A confirmação é de uso único. Se ela expirar, gere uma nova prévia e revise os itens. Para editar uma agenda sem parâmetros, use o objeto JSON vazio `{}`. Para conferir se a tarefa realmente foi processada, consulte o histórico de execução.

## Tarefas, agendas e manutenção

**Avançado → Tarefas e agendas** lista tarefas e agendas da conexão, com estado e histórico de execução. Admissão de tarefa não comprova execução: confira o histórico. **Avançado → Modelos e manutenção** exporta e aplica modelos de configuração (sem credenciais) e executa a manutenção do armazenamento. Sem tráfego no site, o WP-Cron não dispara; configure no servidor `wp mcp-google run-due --user=<administrador>` (`ACOMPANHAMENTO-CRON.md`).

## Ler o manual pelo MCP

Peça o índice com `google/documentation` e parâmetros `{}`. Escolha o identificador exato e envie `document`, `limit_bytes` e `expected_revision`. Continue em `next_offset` até receber `null`. A revisão é o SHA-256 de todos os bytes do documento. Em caso de divergência de revisão, leia novamente o índice. Se o plugin informar falha de integridade do documento instalado, confira o pacote e a versão antes de continuar.

Para a lista de documentos e o papel de cada um, leia `README.md`.

## Permitir que um leitor consulte o anúncio de origem

Em **Acervo Ads**, escolha a conta e abra **Leitores do acervo**. No bloco do Site Core, marque **Cliques e GCLID**, **Permitir leitura local** e **Consultar o criativo desta conta no Google Ads**. Salve no botão desse leitor. A consulta consome cota de leitura do Google ao procurar o criativo. Para retirar apenas esse acesso, desmarque a última opção e salve.
