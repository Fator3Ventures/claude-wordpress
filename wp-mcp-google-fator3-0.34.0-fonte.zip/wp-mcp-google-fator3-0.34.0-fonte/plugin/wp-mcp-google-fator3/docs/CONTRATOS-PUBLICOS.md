# Contratos públicos entre plugins

Interfaces que o Google consome do Fator3 Site Core e do Fator3 MCP, e as que publica para eles. Nenhuma tem trava por número de versão de plugin.

Cada consumidor decide por capacidade e contrato, sem trava de instalação por versão. Ausência, esquema inválido e conflito tornam indisponível a operação dependente; os demais serviços continuam administráveis. Não há importação de opções privadas nem reparo automático de outro plugin.

| Dono | Interface | Uso Google |
|---|---|---|
| Core | `F3Base_Medicao_Contexto`, `site-measurement-context/1.0.0` | Contexto dos seis slots e catálogo de eventos |
| MCP | `Fator3\McpFiles\PackageDistribution`, `package-distribution/1.0.0` | Seleção, manifesto e guarda da origem |
| MCP | `Fator3\McpFiles\ExecutorRegistry`, `executor-registration/1.0.0` | Declaração explícita das bridges Google |
| Google | `search-console-reader/1.0.0` e `1.1.0`, `ga4-reader/1.0.0`, `google-ads-reader/1.0.0` | Leitores para consumidores com concessão explícita (`SDK-PHP.md`, `ACERVO-ADS-GSC.md`) |
| Google | `site-conversion-delivery/1.0.0`, `1.1.0`, `1.2.0`; `site-conversion-reconcile/1.0.0`; `site-stage-conversion-reconcile/1.0.0` | Entrega e reconciliação de conversões (`CONVERSION-DELIVERY-CORE-140.md`) |
| Core | `F3Base_Conversoes_Contexto`, `site-conversion-purposes/1.0.0` | Finalidades de conversão lidas por `google/conversion-context` (`CONVERSOES.md`) |
| Core | `F3Base_Conversoes_Contexto`, `site-conversion-purposes/1.1.0` | Transporte por destino (`selected` e `effective`: `navegador`, `servidor` ou `ambos`) em `core_transport` de `google/conversion-delivery-status`; erro `invalid_output` no envelope |

Os schemas do contexto de medição são cópias integrais dos quatro schemas publicados pelo Site Core, empacotadas no plugin em PHP protegido. Validação inclui envelope, tipos, slots, revisão, eventos e campos permitidos. Dados de formulário fora desse catálogo são recusados. Não há dependência de arquivos Core no filesystem em runtime.

O adaptador consulta `capabilities()` e `snapshot()`; o catálogo usa `events()` com `expected_revision`, 100 itens por página e até 20 páginas. Revisa o snapshot ao concluir. Revisão incompatível, repetição, ausência de progresso ou orçamento excedido não produzem catálogo completo. O catálogo descreve eventos; não prova emissão/recebimento nem cria tags/conversões.

`google/configure` resolve o Measurement ID efetivo somente quando solicitado. IDs explícitos continuam disponíveis sem Core. A leitura é repetida após descoberta e antes de persistir o vínculo. Configurado, efetivo, proveniência, escopo e revisão são distintos; fotografia administrativa não certifica o ID servido a cada visitante. A confirmação otimista não trava escritores Core nem promete atomicidade entre plugins. GTM inclui `meta_server` separado de `meta`, conforme o contexto público.

Distribuição consulta o SDK e o recibo público `f3_mcp_distribution_selection`. Canal MCP selecionado mantém precedência sobre a origem própria. Se o produtor ficar inativo, o recibo mantém a intenção MCP e bloqueia fallback. Sem prova de seleção, a origem é desconhecida; salvar explicitamente uma origem própria cria consentimento local. O Google não lê `f3_mcp_update_channels`, chama `UpdateChannel` nem remove filtros alheios. A consulta da seleção não usa rede; o manifesto é uma operação separada. Guardas revalidam seleção/revisão antes do download/instalação. ZIP manual continua independente desse canal.

As bridges declaram provedor, modo e seis prefixos próprios no hook `f3_mcp_register_executors`. A autorização da bridge não concede o alvo. Leitura não executa escrita simulada, e nenhuma bridge Google aceita executor aninhado ou alvo Core/Meta/LinkedIn. Na ausência da capacidade nova permanece o percurso público de servidor nas combinações que o oferecem; uma declaração recusada não é contornada por fallback.

Site Core, MCP, Google, Meta, LinkedIn e Pipedrive são donos independentes. Google não guarda tokens nem executa coletores sociais. Meta Ads, LinkedIn e Pipedrive pertencem aos respectivos plugins Fator3 MCP. Escritor Sheets de dados sociais e SDK de leads Ads não existem nesta release.

## Contexto de medição: contato e material

O SDK site-measurement-context/1.0.0 mantém seis slots e enumeração fechada. O slot google_ads.conversion_label refere-se a contato; não representa material. O Site Core emite `download_material` pelos seus emissores, mas não o anuncia neste SDK; a configuração de material pertence ao contrato administrativo do Site Core.

Uma receita de material deve usar explicitamente download_material e identificadores próprios por finalidade. Não convertê-lo em generate_lead, nem reaproveitar o label de contato. Consultas GA4 por eventName podem usar download_material explicitamente; o catálogo incompleto não significa ausência do evento no fornecedor. A criação de evento-chave, ação Ads ou publicação GTM é decisão explícita do dono, com os gates existentes. O Google não infere nem cria essas ações ao ler contexto.

`google/conversion-context` lê separadamente o contrato opcional `site-conversion-purposes/1.0.0`; entrada, erros e limites em [CONVERSOES.md](CONVERSOES.md).

## Anúncio de origem no Google Ads

A extensão opcional `google-ads-origin/1.0.0` é descoberta em `capabilities().extensions.origin_ad`. O consumidor autorizado usa `origin_ad` com o identificador do anúncio ou com GCLID e data da conta. Consulte CORE-ACERVOS.md para autorização, campos, exemplos e limites de atribuição.
