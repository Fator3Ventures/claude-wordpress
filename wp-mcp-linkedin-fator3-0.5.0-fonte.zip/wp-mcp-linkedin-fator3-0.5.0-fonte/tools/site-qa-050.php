<?php
/** Temporary acceptance harness. Never shipped inside the installable plugin. */
declare(strict_types=1);
defined('ABSPATH')||exit;
function f3_linkedin_050_acceptance(): array {
    if(!current_user_can('manage_options'))return ['success'=>false,'code'=>'not_authorized'];
    if(!class_exists('Fator3\\LinkedIn\\Config')||\Fator3\LinkedIn\Config::VERSION!=='0.5.0')return ['success'=>false,'code'=>'wrong_version'];
    if(\Fator3\LinkedIn\Store::list('connection',0,1))return ['success'=>false,'code'=>'requires_empty_linkedin_test_configuration'];
    $prefix='qa050-'.bin2hex(random_bytes(6));$checks=[];$previews=[];$mode='normal';$writes=0;$mails=0;$blocked=0;
    $response=static fn($body,$status=200)=>['headers'=>[],'body'=>wp_json_encode($body),'response'=>['code'=>$status,'message'=>'Isolated fixture'],'cookies'=>[]];
    $http=static function($pre,$args,$url)use(&$mode,&$writes,&$blocked,$response){
        $path=parse_url($url,PHP_URL_PATH);$method=$args['method']??'GET';
        if(str_ends_with($path,'/introspectToken'))return $response(['active'=>true,'client_id'=>'qa-app','scope'=>$mode==='deny'?'r_ads':'rw_ads,r_ads','expires_at'=>time()+7200]);
        if(str_ends_with($path,'/accessToken'))return $response(['access_token'=>'synthetic-qa-renewed','expires_in'=>5184000,'refresh_token'=>'synthetic-qa-refresh','refresh_token_expires_in'=>15552000]);
        if($method==='GET'&&$path==='/rest/adAccounts/222')return $response(['id'=>'222','currency'=>'BRL','name'=>'Conta sintética isolada']);
        if($method!=='GET'&&str_starts_with((string)$path,'/rest/'))$writes++;
        $blocked++;return new WP_Error('qa_network_blocked','No actual network permitted during this acceptance callback.');
    };
    $mail=static function($pre,$args)use(&$mails){$mails++;return true;};
    $call=static function($op,$input=[]){$r=\Fator3\LinkedIn\Api::dispatch($op,$input);if(!$r['success'])throw new RuntimeException('Unexpected code: '.$r['code']);return $r['data'];};
    $assert=static function($condition,$name)use(&$checks){if(!$condition)throw new RuntimeException($name);$checks[]=['name'=>$name,'passed'=>true];};
    add_filter('pre_http_request',$http,-10000,3);add_filter('pre_wp_mail',$mail,-10000,2);
    $failure=null;
    try {
        $call('save-connection',['connection_id'=>$prefix,'expected_revision'=>0,'label'=>'Aceite sintético 0.5.0','token'=>'synthetic-qa-token','refresh_token'=>'synthetic-qa-refresh','client_id'=>'qa-app','client_secret'=>'synthetic-qa-secret','expires_at'=>time()+86400,'assets'=>['ads'=>['222']]]);
        $rev=$call('get-ad-account',['connection_id'=>$prefix,'account_id'=>'222'])['revision'];
        $i=['connection_id'=>$prefix,'account_id'=>'222','expected_revision'=>$rev,'request_key'=>$prefix,'fields'=>['name'=>'Grupo somente em prévia']];
        $p=$call('create-campaign-group',$i);$previews[]=hash('sha256',$p['confirm_token']);
        $assert($p['dry_run']&&$p['proposed']['status']==='DRAFT'&&$writes===0,'Prévia em rascunho sem envio');
        $mode='deny';$r=\Fator3\LinkedIn\Api::dispatch('create-campaign-group',$i);$assert(!$r['success']&&$r['code']==='scope_missing'&&$writes===0,'Recusa de escopo antes de escrita');$mode='normal';
        $c=\Fator3\LinkedIn\Connections::get($prefix);\Fator3\LinkedIn\Credentials::tick();$new=\Fator3\LinkedIn\Connections::get($prefix);
        $assert($new['token']==='synthetic-qa-renewed'&&$new['revision']===$c['revision'],'Renovação automática simulada preserva revisão');
        $status=$call('status')['access_lifecycle'];$assert($status['connections'][0]['last_result']==='refreshed','Resultado de renovação no status');
        $call('save-connection',['connection_id'=>$prefix.'-manual','expected_revision'=>0,'label'=>'Aviso sintético','token'=>'synthetic-manual','expires_at'=>time()+13*86400]);
        \Fator3\LinkedIn\Credentials::tick();\Fator3\LinkedIn\Credentials::tick();$assert($mails===1,'Aviso de 14 dias interceptado e deduplicado');
        $c=\Fator3\LinkedIn\Connections::get($prefix.'-manual');$call('save-connection',['connection_id'=>$c['id'],'expected_revision'=>$c['revision'],'expires_at'=>time()+2*86400]);\Fator3\LinkedIn\Credentials::tick();$assert($mails===2,'Aviso de 3 dias interceptado');
        $assert($writes===0&&$blocked===0,'Nenhuma escrita remota ou envio de email real');
    }catch(Throwable $e){$failure=$e->getMessage();}
    finally {
        remove_filter('pre_http_request',$http,-10000);remove_filter('pre_wp_mail',$mail,-10000);
        foreach([$prefix,$prefix.'-manual'] as $id)foreach(['credential','credential_health','token_proof','connection'] as $bucket){$r=\Fator3\LinkedIn\Store::get($bucket,$id);if($r)\Fator3\LinkedIn\Store::remove($bucket,$id,$r['revision']);}
        foreach($previews as $key){$r=\Fator3\LinkedIn\Store::get('write_preview',$key);if($r)\Fator3\LinkedIn\Store::remove('write_preview',$key,$r['revision']);}
    }
    return ['success'=>$failure===null,'version'=>'0.5.0','wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'failure'=>$failure,'real_provider_calls'=>0,'real_emails'=>0,'configuration_remaining'=>count(\Fator3\LinkedIn\Store::list('connection',0,100)),'audit_retained'=>true];
}
add_action('wp_abilities_api_init',static function(){wp_register_ability('linkedin-qa/run-050',['label'=>'LinkedIn: executar aceite simulado isolado','description'=>'Executa prévia, recusa de escopo, renovação e avisos com rede e e-mail interceptados; exige configuração LinkedIn vazia e remove apenas os registros sintéticos criados.','category'=>'linkedin','input_schema'=>['type'=>'object','properties'=>[],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>static function(){try{return f3_linkedin_050_acceptance();}catch(Throwable $e){return ['success'=>false,'qa_exception'=>get_class($e),'qa_line'=>$e->getLine(),'qa_message'=>$e instanceof \Fator3\LinkedIn\Fault?$e->reason:'qa_failure'];}},'meta'=>['mcp'=>['public'=>true],'annotations'=>['readonly'=>false,'destructive'=>false,'idempotent'=>false]]]);},40);
