"""Fetch the exact PHP 8.1.2 development packages used by this release."""
from pathlib import Path
import os,json,hashlib,urllib.request,subprocess
here=Path(__file__).resolve().parent
root=Path(os.environ['F3_RUNTIME_DOWNLOAD_ROOT']).resolve()
project=here.parent
if root==project or project in root.parents:raise SystemExit('Dependency destination must be outside the source project')
(root/'php81').mkdir(parents=True,exist_ok=True);(root/'debs81').mkdir(exist_ok=True)
for item in json.loads((here/'php81-dependencies.json').read_text()):
    path=root/'debs81'/item['url'].rsplit('/',1)[1]
    if not path.exists():path.write_bytes(urllib.request.urlopen(item['url'],timeout=90).read())
    if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:raise SystemExit('Hash mismatch: '+item['package'])
    subprocess.run(['dpkg-deb','-x',str(path),str(root/'php81')],check=True)
print('Pinned PHP 8.1.2 dependencies verified.')
