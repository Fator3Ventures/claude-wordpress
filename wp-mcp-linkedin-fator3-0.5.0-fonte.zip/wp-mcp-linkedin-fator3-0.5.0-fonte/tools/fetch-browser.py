import urllib.request,json,zipfile,hashlib,shutil,os
from pathlib import Path
r=Path(__file__).resolve().parents[1]/'dependencies';meta=json.load(urllib.request.urlopen('https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json',timeout=20))['channels']['Stable'];url=next(x['url'] for x in meta['downloads']['chrome'] if x['platform']=='linux64')
p=Path('/tmp/f3-social-chrome-020.zip')
with urllib.request.urlopen(url,timeout=40) as src,p.open('wb') as dst:shutil.copyfileobj(src,dst)
print(json.dumps({'download_bytes':p.stat().st_size}),flush=True)
with zipfile.ZipFile(p) as z:z.extractall(r/'chrome')
for n in ['chrome','chrome_crashpad_handler','chrome_sandbox']:
 f=r/'chrome/chrome-linux64'/n
 if f.exists():f.chmod(0o755)
(r/'browser-manifest.json').write_text(json.dumps({'version':meta['version'],'url':url,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2));print(json.dumps({'ready':True,'version':meta['version']}))
