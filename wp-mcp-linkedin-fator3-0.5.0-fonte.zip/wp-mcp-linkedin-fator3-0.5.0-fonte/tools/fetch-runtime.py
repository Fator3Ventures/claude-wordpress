"""Fetch only the pinned public development dependencies into an explicit external directory."""
from pathlib import Path
import os,json,hashlib,urllib.request,subprocess
here=Path(__file__).resolve().parent
root=Path(os.environ['F3_RUNTIME_DOWNLOAD_ROOT']).resolve()
project=here.parent
if root==project or project in root.parents:raise SystemExit('Dependency destination must be outside the source project')
(root/'runtime').mkdir(parents=True,exist_ok=True);(root/'debs').mkdir(exist_ok=True)
for item in json.loads((here/'runtime-dependencies.json').read_text()):
 path=root/'debs'/item['url'].rsplit('/',1)[1]
 if not path.exists():path.write_bytes(urllib.request.urlopen(item['url'],timeout=90).read())
 if hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:raise SystemExit('Hash mismatch: '+item['name'])
 raw=subprocess.check_output(['dpkg-deb','--fsys-tarfile',str(path)])
 subprocess.run(['tar','--no-same-owner','-xf','-','-C',str(root/'runtime')],input=raw,check=True)
print('Pinned PHP/MySQL/HTTP dependencies verified. Supply WordPress and WP-CLI explicitly.')
