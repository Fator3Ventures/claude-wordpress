# Fonte — Fator3 MCP LinkedIn 0.5.0

Fonte exclusivo de wp-mcp-linkedin-fator3, base 0.4.1, pedidos 5/6/7. O fonte não é instalável. Instale o ZIP instalador entregue separadamente. Este diretório contém runtime em plugin/, templates e documentação em build/, testes nativos/DOM, evidências sanitizadas, normas/manifestos dos anexos em inputs/ e histórico do planejamento em planning/.

## Reprodução

Python 3 e PHP 8.1.2+ de 64 bits. Runtime desta rodada: PHP 8.3.6, MySQL 8.0.46, WordPress 7.1.2. Execute `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. O resultado determinístico em build/dist deve ter SHA-256 dcef9a7b236bdb84055baa4aa6db73ba2fcd3bdd9a7cea30905c2e771a563199. Nenhum ZIP está aninhado no fonte. O runtime em plugin/ é idêntico ao instalador.

Use tools/dependencies.example.json ou integrated-dependencies.example.json; troque apenas os caminhos pelos arquivos/diretórios correspondentes e valide os hashes. Diretórios usam SHA-256 da sequência ordenada de caminho UTF-8, byte zero e SHA-256 binário de cada arquivo. Dependências ficam fora do projeto. tools/fetch-runtime.py e fetch-php81.py são auxiliares recebidos da base; mínimos de runtime não foram reexecutados na 0.5.0, portanto não são prova desta rodada.

`python3 tools/lab.py --manifest /caminho/manifest.json --workdir /caminho/novo --order linkedin-only` testa instalação limpa. Acrescente `--origin upgrade` para a base imutável 0.4.1. Para coexistência use `--order linkedin-integrated` e os instaladores recebidos Core 1.46.1, MCP 0.25.0, Google 0.17.0 e Meta 0.4.1. Nunca reconstrua ou renumere os acompanhantes. Os modos legados multi-provider não fazem parte desta entrega.

Os laboratórios criam banco/processos descartáveis próprios, sem alterar site compartilhado. Toda saída HTTP e e-mail é interceptada. O runner encerra somente seus processos. `F3_JSDOM=/caminho/node_modules/jsdom` com `--ui` executa HTML/JS servidos pelo WordPress e REST administrativa real. `--ui-only` separa esse teste dos fixtures PHP. As 12 verificações DOM não substituem revisão visual em navegador.

`tools/site-qa-050.php` é um auxiliar temporário de aceite, não componente do instalador. Só pode ser usado em Site-Teste autorizado com configuração LinkedIn vazia. Exige administrador, intercepta HTTP/e-mail durante a execução e limpa apenas conexões/prévias sintéticas. Foi removido do Site-Teste após sete verificações aprovadas. Logs sintéticos de auditoria foram conservados.

## Evidências e limites

61 testes limpos, 63 de atualização e 89 integrados, além de 12 DOM; contagens são execuções, não casos únicos. Site-Teste: WordPress 7.1.3/PHP 8.3.36; troca 0.4.1→0.5.0 aplicada, cron de manutenção restabelecido por desativação/ativação normal, sete cenários simulados e oito autotestes aprovados. Catálogo com 73 abilities, 42 IDs anteriores preservados, 16 documentos completos verificados por hash via MCP.

Não houve operação real no LinkedIn. Aceite de produção, mínimos PHP 8.1.2/WordPress 6.4 e prova visual manual da nova tela ficam explícitos no relatório. Antes/depois no Registro central depende de alteração do MCP; o diário deste plugin já os conserva. A fonte não afirma que essas pendências estão resolvidas.

Para fechar o fonte, prepare pasta wp-mcp-linkedin-fator3-0.5.0-fonte e execute tools/package-source.py com --output-dir fora dela. O relatório interno é anterior ao fechamento e não contém o hash circular do próprio fonte. Hash/bytes finais estão no relatório externo.
