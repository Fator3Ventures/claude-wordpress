# Instruções comuns aos agentes — plugins Fator3

Revisão 4 — 16/10/2026. Usar no início de cada tarefa, acompanhado de `padrao-desenvolvimento-plugins-fator3.md`, da regra comum/aba do pacote, da última entrega e dos impactos recebidos. Aplicável a Core, MCP, Google, Meta, LinkedIn e Implantador.

**Alteração desta revisão:** impactos somente quando tecnicamente relevantes para outro plugin, desde o planejamento; eliminada a emissão fixa por destinatário ou apenas para informar versão.

## Contexto da tarefa

- Plugin responsável: `<nome, slug e basename existentes>`.
- Versão-base: `<última versão de referência ou base explicitamente indicada>`.
- Versão-alvo: `<X.Y.Z>`.
- Escopo e IDs: `<pedido da rodada e numeração existente>`.
- Contratos/impactos recebidos: `<documentos, revisões e versões>`.
- Exceções explícitas: `<somente as determinadas pelo usuário>`.

Determine esses valores pelas evidências disponíveis. Não invente versões, hashes, testes, credenciais ou autorizações. Resolva escolhas rotineiras no escopo sem confirmação desnecessária. O slug do Implantador não consta no anexo: confirme sua identidade existente antes de gerar arquivos ou encaminhamentos destinados a ele.

## Instruções de execução

1. **Identidade.** Preserve slug, pasta, basename, provider, namespaces, Text Domain, Update URI, prefixos e ferramentas públicas. Nome exibido começa por `Fator3`. Cada pacote tem fonte, instalador e relatório próprios.
2. **Cabeçalho e tela.** Siga a tabela do padrão: URI do repositório Fator3Ventures/claude-wordpress, autor Fator3, Author URI `https://www.fator3.com.br`, licença GPL-2.0-or-later, descrição específica e mínimos comprovados. Título da tela usa o nome exibido no menu existente. Não renomeie identidades publicadas por estética.
3. **Versão.** Incremente minor por padrão: `X.Y.Z → X.(Y+1).0`. Major/patch só quando solicitados. Sem sufixos públicos de homologação/build. Não altere silenciosamente contratos. Versão publicada não é renomeada; instalador final alterado exige nova versão, salvo revisão de candidato expressamente autorizada.
4. **Compatibilidade.** Garanta WordPress novo e atualização direta da versão imediatamente anterior de referência, com dados/configuração preservados. Base ou salto indicado pelo usuário prevalece. Não acrescente suporte histórico por conta própria. Registre versões de acompanhantes testadas e ordem de troca quando contratos exigirem.
5. **Autonomia.** Mantenha funções próprias sem dependência artificial de acompanhantes. Verifique contratos na operação integrada; MCP é necessário para o transporte remoto, não para tornar a ajuda local utilizável. Não remova acoplamentos legados fora do escopo.
6. **Autorização.** Tela, leitura de dados de conta conectada e escrita de configuração exigem `manage_options` ou capacidade própria exclusiva de administrador, validada no servidor, inclusive MCP/REST. `read` não basta. Documentação estática tem gate explícito e não expõe configuração efetiva nem dados privados.
7. **Documentação instalada.** Inclua especificação, configuração, uso, contratos/schemas, guia para agentes, operação/recuperação e notas da versão no instalador. Forneça índice e leitura MCP completa/paginada, versão/hash, allowlist de documentos e exemplos atuais. Ler ajuda não chama fornecedor nem muda estado.
8. **Provas.** Execute testes pertinentes, instalação limpa, atualização da base, funções próprias, fronteiras afetadas, autorização e leitura documental pelo MCP. Separe lint, fixtures, WordPress real e fornecedor real. Declare provas não feitas, motivo e responsável; mínimos de runtime não testados não são suporte comprovado.
9. **Ambiente real.** Use `https://fator3-teste-mcp-1.dreamhosters.com/` via **WP MCP fator3-teste** no escopo autorizado. Registre antes/depois e coordene uma alteração de instalação por vez. Preserve recursos alheios; não apague o banco compartilhado para simular WordPress limpo. Teste local descartável serve para instalação limpa.
10. **Efeitos externos.** Use ativos/destinos autorizados. Testes não autorizam gastos Ads, avisos a clientes, publicação ou assinaturas reais. Preparar encaminhamento não autoriza enviá-lo.
11. **Entrega por rodada.** Entregue os três artefatos principais: `<slug>-<versao>-fonte.zip`, `-instalador.zip` e `-relatorio.md`. Acrescente um `-impacto-<slug-destino>.md` somente por outro pacote com impacto técnico relevante, conforme o item 14 e a seção 6 do padrão completo. A quantidade de impactos pode ser zero. Manifesto/checksums são complementares. Fonte no singular; relatório em português/Markdown. Nenhum ZIP contém outro ZIP da entrega.
12. **Empacotamento.** Instalador tem raiz `<slug>/` e o arquivo principal publicado; apenas ele é instalável. Fonte tem raiz `<slug>-<versao>-fonte/`, código, build, testes, evidências sanitizadas e cópia do relatório. Não inclua segredos, cookies, banco de laboratório ou logs pessoais. Feche o instalador primeiro; a cópia do relatório dentro do fonte é identificada como anterior ao fechamento, e o hash final do fonte fica no relatório externo, evitando circularidade.
13. **Relatório.** Use `Entrega — <nome exibido> <versao>` e a ordem: bases aceitas; convivência/encaminhamentos; mudanças por pedido/evidência; instalação/prontidão; banco/reversão; pendências; credenciais sem valores secretos; nomes finais, bytes e SHA-256 de instalador e fonte. Inclua documentação MCP e estado final do teste. Um relatório conjunto não substitui os próprios.
14. **Impactos desde o planejamento.** Avalie as fronteiras pertinentes e gere relatórios somente para consequências técnicas relevantes sobre outro plugin: desenvolvimento, bugs/regressões, contratos, configuração, dados, permissões, dependências, conflitos ou validação coordenada. Não gere arquivos para simples aviso de versão, informação irrelevante ou “sem ação/sem impacto”. Emita os encaminhamentos já no planejamento da próxima versão, antes de implementar a parte afetada, para alinhar contratos e resolver conflitos antecipadamente. Inclua proposta, consequência, decisão/ação ou orientação técnica, responsável, ticket quando existente, aceite e validação prevista; use `acao-necessaria`, `decisao-necessaria`, `validacao-coordenada`, `alerta-tecnico` ou `bloqueio`. Identifique emissor/destinatário, versão-base/alvo, etapa, revisão e situação. No planejamento, marque a versão-alvo como prevista e o instalador como ainda não gerado; não exija hash futuro. Atualize o mesmo documento na implementação e na entrega, com contrato real, evidências, hash do instalador quando existir, pendências e decisões. Registre o encerramento de impactos resolvidos/cancelados sem apagar o histórico. Plano/relatório referencia apenas os encaminhamentos pertinentes; sem impacto identificado, basta conclusão breve e escopo avaliado. Lacunas ficam como `nao-avaliado` nas pendências e só exigem encaminhamento individual se houver risco técnico concreto a coordenar. Não declare concluído trabalho de outro responsável.
15. **Frota.** Entregue os artefatos ao dono. A frota publica instalador/relatório na raiz raw do repositório público e confere SHA-256 antes de `plugins/upload`, usando `expected_sha256` e `expected_slug`. Na troca seguinte remove a versão anterior de `main`, preservando histórico. Fonte fica com o dono até decisão 89; esta regra não é autorização de push/envio nesta tarefa.
16. **Rodada sem código.** Disponibilize ZIPs da base como artefatos inalterados e revise o relatório e os impactos pertinentes. No planejamento, não aguarde instalador-alvo para gerar o impacto necessário. Não fabrique software nem renumere plugin por revisão documental. Se a base não estiver disponível, registre a pendência de entrega.
17. **Governança.** Apenas “Site Geral | Todos” mantém a regra comum/abas com guarda de revisão. Encaminhe desvios com os números existentes; o revisor confere instalador/relatório e fecha o item. Não altere regra central, documento externo ou pacote alheio sem atribuição.

## Fronteiras a preservar

- Core: medição, consentimento, contatos, atribuição e pipeline comercial; Pixel/CAPI e Meta Lead Ads existentes permanecem nele.
- Google: APIs/credenciais e capacidades GA4/GSC/Sheets existentes; Google Ads exige configuração/homologação comprovadas.
- MCP: transporte, autenticação, descoberta e administração WordPress.
- Meta: Instagram Insights; Meta Ads/anúncios Instagram seguem no MCP oficial da Meta.
- LinkedIn: Pages/Ads e cliente Lead Sync. Cliente Core e cliente LinkedIn convivem com seleção explícita por integração e um ativo por fluxo; preservar progresso/deduplicação, sem troca automática.
- Implantador: implantação/configuração e contratos existentes, sem absorver APIs sociais ou regras comerciais.
- Tokens sociais manuais continuam como padrão. BigQuery, migração Porter e nova exportação social para Sheets permanecem fora do escopo.

## Encerramento esperado

Entregue links de todos os artefatos, estado da implementação, testes/limites, pendências e ações por responsável. Distinga prova própria de relatório recebido. Versão/hash entregue deve corresponder à evidência.
