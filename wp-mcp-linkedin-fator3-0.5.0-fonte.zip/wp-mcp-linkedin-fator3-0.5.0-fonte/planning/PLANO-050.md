# Plano — Fator3 MCP LinkedIn 0.5.0
Revisão 1 · 22/10/2026 · America/Sao_Paulo · implementação.
Normas lidas integralmente: instrucoes-agentes-plugins-fator3.md r4 e padrao-desenvolvimento-plugins-fator3.md r4 (16/10/2026).
Base direta: 0.4.1, instalador SHA-256 a1f2bd2393c7f1b1780f106f4a7c3ac46776a8a7cc7071f1e269daad7ec34c43. Alvo previsto: 0.5.0; instalador ainda não gerado.

Pedidos MCP LinkedIn 5, 6 e 7. Preservar 42 identificadores e leituras existentes. Adicionar rótulos/descrições em português, operações tipadas de anúncios/publicações, prévia, revisão remota, idempotência persistente, diário de efeitos incertos, seleção de ativos e comprovação de escopos por introspecção. Toda criação Ads força DRAFT; ativação separada. Interface sem editor JSON. OAuth opcional mantém token manual como padrão; refresh cifrado e avisos de expiração. Auto-renovação deve preservar revisão de autorização, concessões, cursores e diário.

Fronteiras examinadas: Core 1.46.1 (SDK consumidor), MCP 0.25.0 (registro/decoração/auditoria), Google 0.17.0 (incidentes e renovação), Meta 0.4.1 (isolamento). Nenhum pacote acompanhante será modificado. Implantador não fornecido, não avaliado.

Impacto aberto desde o planejamento: wp-mcp-linkedin-fator3-0.5.0-impacto-wp-mcp-fator3.md. O MCP recebido só grava resumo e operation_id; não há API pública de eventos com antes/depois. Não usar classe privada ou modificar o transporte. Fornecer diário próprio e evento documentado; aceitar que visualização integral no Registro central depende do responsável MCP.

Provas previstas: PHP lint, WordPress descartável limpo e atualização direta, autorização, HTTP simulado, falhas/concorrência/repetição, escopos e proprietários, OAuth/state, renovação e avisos interceptados, documentação paginada, DOM e site de teste se canal de instalação disponível. Nenhum gasto, publicação, comentário, assinatura ou email real de teste. Aceites de produção expressamente dependem de ordem do dono.

## Fechamento da implementação — revisão 2, 22/10/2026

Alvo entregue 0.5.0, instalador dcef9a7b236bdb84055baa4aa6db73ba2fcd3bdd9a7cea30905c2e771a563199, 155689 bytes. Execuções finais: 61 limpas, 63 atualização direta, 89 integradas e 12 DOM, todas aprovadas. Site-Teste atualizado e ativo, sete cenários sintéticos aprovados, auxiliar removido, zero conexões remanescentes, cron restabelecido pelo ciclo normal de ativação. Catálogo 73 e documentação 16 arquivos conferidos via MCP. Antes/depois central segue no impacto MCP R3; fornecedor real, mínimos e revisão visual manual são pendências documentadas. O planejamento inicial foi preservado.
