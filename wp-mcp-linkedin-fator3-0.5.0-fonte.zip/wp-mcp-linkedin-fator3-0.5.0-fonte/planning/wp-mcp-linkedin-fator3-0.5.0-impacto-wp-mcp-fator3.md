# Impacto de wp-mcp-linkedin-fator3 0.5.0 em wp-mcp-fator3
Revisão 1 · 22/10/2026 · Etapa: planejamento · Situação: aberto.
Base: LinkedIn 0.4.1 (SHA-256 a1f2bd2393c7f1b1780f106f4a7c3ac46776a8a7cc7071f1e269daad7ec34c43). Alvo previsto 0.5.0, instalador ainda não gerado.
Destinatário examinado: MCP 0.25.0, SHA-256 7f32527a88514f2f319e02308f491b96b3112b783f1b38791da85aab071ea961.
Natureza: contrato de auditoria e interface. Classificação: acao-necessaria.

## Mudança e consequência
Pedidos MCP LinkedIn 6(c) exige antes/depois no Registro central. Audit::record do MCP recebido conserva apenas resumo, identidade de operação e resultado; não há contrato público para anexar o par de estados. Usar classes internas ou escrever tabelas privadas violaria a independência.

## Proposta e ação do responsável MCP
LinkedIn manterá diário cifrado consultável em linkedin/get-write-operation, operation_id estável retornado no envelope e evento próprio f3_linkedin_mutation_recorded com recibo sanitizado e referência ao diário. Solicita-se contrato público versionado para receber ou consultar snapshots antes/depois, validar provider/permissão e renderizar no Registro, também para ações feitas pelo painel. Não incluir tokens, URLs assinadas de upload, texto de comentários ou conteúdo pessoal no log central. O responsável MCP deve confirmar contrato ou alternativa.

## Compatibilidade e aceite
Novas abilities seguem policy_contract=1. As existentes conservam nome/schema. Rótulos em português não alteram permissões. Até confirmação, LinkedIn pode registrar histórico próprio e MCP pode auditar chamadas remotas; o requisito de exibir antes/depois no Registro permanece pendente. Sem bloqueio das leituras próprias.
Aceite: escrita simulada via MCP e painel; linha central correlacionada ao operation_id, antes/depois disponíveis apenas ao administrador, sem segredo, repetição sem segundo efeito.

## Evolução
R1: lacuna constatada no código do MCP 0.25.0 antes da implementação. Ação do destinatário não foi executada nem presumida; documento preparado, não enviado.

## Revisão 2 — implementação, 22/10/2026

Contrato implementado pelo LinkedIn: evento f3_linkedin_mutation_recorded, linkedin-mutation/1.0.0, campos provider, operation_id, operation, state, before_sha256, after_sha256 e reader. O evento não inclui snapshots nem credenciais; o leitor exige administrador, principal proprietário e ativo ainda selecionado. Diário cifrado em bucket mutation. Não há chamada a persistência privada do MCP. A consulta ao diário pode continuar com token expirado; reconciliar exige acesso remoto válido.

As novas escritas usam request_key para idempotência de domínio. O MCP 0.25.0 acrescenta idempotency_key de transporte: omitir esse campo nas duas fases ou usar chaves diferentes por fase evita conflito entre dry_run e aplicação. confirm_token é hash aleatório de 64 hexadecimais, compatível com a exceção explícita de SafeOutput. Status público fica em access_lifecycle; endereço OAuth em consent_url. Não foram enfraquecidas as regras de segredo do transporte. UploadToken de vídeo pode continuar redigido pelo MCP; o painel/REST autorizado fornece a inicialização.

## Revisão 3 — entrega, 22/10/2026

Etapa atual: entrega. Situação: aberto, acao-necessaria, responsável pelo wp-mcp-fator3. Emissor: responsável pelo wp-mcp-linkedin-fator3. Versão-base 0.4.1, alvo entregue 0.5.0. Ticket existente: Pedidos MCP LinkedIn 6(c), sem inventar numeração do destinatário.

Instalador entregue: wp-mcp-linkedin-fator3-0.5.0-instalador.zip, 155689 bytes, SHA-256 dcef9a7b236bdb84055baa4aa6db73ba2fcd3bdd9a7cea30905c2e771a563199. Os 42 IDs anteriores permanecem; save-connection recebeu apenas três propriedades aditivas. Catálogo final tem 73 abilities.

Provas: 89 verificações integradas com Core 1.46.1/MCP 0.25.0/Google 0.17.0/Meta 0.4.1, incluindo execução real do wrapper MCP com prévia/aplicação simuladas e preservação do confirm_token. Site-Teste com MCP 0.25.0: 73 rótulos em português descobertos, 16 documentos completos lidos por MCP e hashes conferidos, sete cenários simulados aprovados. O painel foi exercitado por DOM+REST real. Essas provas não afirmam que o Registro central exibe antes/depois.

Decisão solicitada ao destinatário: definir contrato público versionado de referência/consulta dos snapshots, autorização do leitor e correlação do operation_id de domínio no Registro. Preservar mascaramento de segredos e o filtro de perfil; contemplar ações feitas pelo painel, não apenas chamadas MCP. Conteúdo pessoal não deve ser copiado indiscriminadamente ao log central; a exibição autorizada pode consultar o diário sob o mesmo gate do produtor. Aceite permanece o da R1, com teste também para usuário sem manage_options e principal distinto.

Documento preparado para o dono; não foi enviado a terceiros. Nenhum arquivo do MCP foi alterado. R1/R2 permanecem acima como histórico; tarefa do destinatário não foi declarada concluída. Não há bloqueio das leituras ou do diário próprio do LinkedIn; pedido 6(c) permanece parcialmente atendido até validação coordenada.
