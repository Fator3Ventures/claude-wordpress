<?php
// Uninstallation preserves encrypted business records for an explicit administrator-led cleanup.
if(!defined('WP_UNINSTALL_PLUGIN'))exit;
wp_clear_scheduled_hook('f3_linkedin_worker');wp_clear_scheduled_hook('f3_linkedin_maintenance');
