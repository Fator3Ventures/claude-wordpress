# Guia para agentes — 0.5.0

Leia `documentation` com document=index e continue cada documento por next_offset e expected_revision. Confira SHA-256. O catálogo não comprova disponibilidade remota. Entradas humanas exigem administrador; `users` não amplia esse direito. Não obtenha credenciais pelo navegador nem escreva arquivos para expô-las.

Antes de gravar, releia a configuração e use a revisão. Descubra nomes por `admin-options` e mantenha seleção explícita. Nunca interprete uma lista descoberta como autorização. Preservar campos não enviados é a forma de atualizar apenas a seção desejada. Confirme o retorno persistido e a revisão. Não repita mutações incertas.

Meta orgânico e Pixel/CAPI não são incorporados neste pacote. LinkedIn mantém Lead Reader 1.0/1.1; o consumidor Core detém ingestão e deduplicação comercial. `admin-options` é auxílio administrativo e não substitui o cliente SDK nem conclui demandas de outro pacote.

Distinguir testes de fixtures, WordPress real e fornecedor real. As credenciais do dono e aprovação do produto são necessárias para homologação externa. Não publicar, gastar Ads, enviar notificações reais ou criar assinaturas comerciais como teste sem autorização específica.

## Regras das novas escritas

Nunca omita a prévia nem derive expected_revision de dados antigos. Use request_key de domínio; omita a chave opcional idempotency_key do MCP entre fases ou diferencie as chaves de transporte. Registre data.operation_id. Uma criação Ads DRAFT não autoriza ativar. Publicação/comentário são efeitos imediatos. Verifique seleção, escopos introspectados e consentimento do dono para testes reais. Leia MANAGEMENT.md e CREDENTIALS.md por inteiro antes de operar.

Não conclua o pedido 6(c): antes/depois no Registro central permanece dependência MCP. Não declare refresh real aprovado por ter passado fixture. Não enfraqueça redatores do transporte para obter uploadToken; use interface autorizada prevista.
