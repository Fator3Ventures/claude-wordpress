# Atualização 0.4.1 → 0.5.0

Instale o ZIP instalador sobre a pasta wp-mcp-linkedin-fator3. Mantenha o basename publicado. Não instale o ZIP fonte. Faça backup de arquivos, banco e salts. Não altere os demais plugins para instalar esta versão. Recomendação operacional: conferir status e documentação após troca; inspecionar cron de manutenção antes de configurar renovação.

A tabela cifrada existente é reutilizada, sem nova tabela nem ALTER destrutivo. Novos buckets: credential, credential_health, token_proof, oauth_state, write_preview, mutation e mutation_guard. State e prévia expiram; diário de mutações/índice de intenção não são podados automaticamente. Conexões antigas sem refresh continuam manuais; ativos, concessões, agendas e diário de assinaturas não são migrados ou apagados. Identidade/configuração e leitura do SDK permanecem compatíveis.

Renovação automática conserva a revisão de autorização e grava token efetivo no bucket credential. Nova autorização e alteração manual exigem reconfirmar concessões, sem descartar os registros. O Core mantém sua seleção explícita e ingestão; não há mudança automática de provedor.

Rollback: desative escritores/cron, capture diário e backup integral, restaure arquivos e estado do mesmo ponto se apropriado. A 0.4.1 ignora a sobreposição credential e pode utilizar token-base antigo. Planeje token válido ou reautorização antes de retomar, sem copiar segredo para logs. Restaurar banco não desfaz publicação, gasto ou mudança de estado já confirmados no LinkedIn; consulte o diário e recupere cada efeito com autorização. Desinstalação conserva dados para limpeza explícita, não reverte efeitos remotos.
