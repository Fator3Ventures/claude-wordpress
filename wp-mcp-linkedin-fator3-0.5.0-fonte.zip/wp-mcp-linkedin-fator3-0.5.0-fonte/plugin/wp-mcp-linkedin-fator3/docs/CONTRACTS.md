# Contratos públicos — 0.5.0

Namespace REST preservado: `/wp-json/f3-linkedin/v1/{operation}`, POST JSON autenticado. Cookie administrativo exige nonce REST; credenciais MCP também passam pela política do transporte. Abilities preservam prefixo `linkedin/`. Consulte `contracts` e `input-schemas.json`; todos os objetos de entrada são fechados e parâmetros desconhecidos são recusados. IDs remotos são strings, não números de ponto flutuante.

Envelope: `success`, `code`, `provider`, `version` e `data` em sucesso. Falha: `error_code`, `message`, `conflict`, `retryable`, `details`, `data=null`. Um sucesso local não implica homologação externa. `not_authorized` é HTTP 403 em REST; os demais códigos de domínio usam envelope estruturado.

Relatórios mantêm contrato social-reporting/1.0.0; Meta estende para social-reporting/1.1.0 com linhas diárias e disponibilidade. Nenhum campo anterior é removido. Preserve seleção e next_cursor até esgotar. `coverage.complete` exige fim do plano e nenhuma indisponibilidade registrada; `all_rows_guaranteed` pode ser null. Inventário completo da resposta não comprova todo o histórico remoto.

Revisões são obrigatórias para configuração, agendas, concessões e controle de tarefas. Chaves idempotentes locais têm no máximo 64 caracteres; o transporte pode ter limites próprios. Não reutilize uma chave para outra intenção. Listagens administrativas usam `offset` e `next_offset`; get-connection/get-grant permitem releitura de uma configuração precisa. A falta de uma página não autoriza inferir que os outros registros não existem.

Erros estáveis incluem invalid_input, not_authorized, asset_access_denied, revision_conflict, credential_revalidation_required, rate_limited, upstream_error, operation_uncertain, history_changed, response_limit, storage_unavailable e persistence_unconfirmed. Não trate resultado incerto como autorização para reenviar uma mutação.

## Administração aditiva da 0.4.0

`linkedin/admin-options` exige administrador em painel, REST e MCP. `kind=users` lista nomes locais (50 por página, `offset/next_offset`, busca por nome/login ou até 100 IDs selecionados). Não retorna e-mail nem credencial. Os demais tipos exigem conexão e canal: `assets` usa descoberta com cursor assinado; `selected` resolve nomes de até 10 ativos já permitidos por página; `objects` projeta nome/ID de mídias, publicações, vídeos (Meta) ou campanhas (LinkedIn); `forms` e `journal` são exclusivos do LinkedIn. Formulários exigem conta selecionada e proprietário remoto idêntico. Diário mostra somente operações administrativas locais comprovadas pelo SDK; não adota recibos de consumidores.

Listas de nomes não alteram seleção. Falha de obtenção de nome deixa `name=null`, `name_status=unavailable` e motivo; resposta bem-sucedida de metadados não homologa relatórios. `connection_revision` identifica a revisão lida; alterações concorrentes invalidam a resposta. Os esquemas instalados enumeram todas as entradas. O limite por requisição continua Meta 40 / LinkedIn 15 e 25 segundos; descoberta LinkedIn pede 10 contas para comportar leitura de nomes.

`save-schedule` aceita `label` (até 120 caracteres) e `next_at` (Unix UTC) opcionais. Sem `next_at`, preserva o valor anterior; agenda nova usa agora + 60 segundos. Mantém último job e código. A interface não altera a consulta ao editar agenda: para consulta diferente, crie outra agenda. Contratos públicos de relatórios e Lead Reader não mudaram.

## Contratos aditivos 0.5.0

Gestão usa linkedin-management/1.0.0 e schemas exatos de input-schemas.json. Leia MANAGEMENT.md para request_key/confirm_token, revisões e fases. O limite de 15 chamadas citado para leituras permanece; novas mutações dispõem de 30 chamadas REST, 25 segundos. Credenciais usam access_lifecycle no status; consent_url é o endereço público da autorização. Esses nomes não removem filtros de segredo do transporte.

O evento linkedin-mutation/1.0.0 é uma oferta de integração do produtor, não um contrato já implementado pelo MCP central. O diário não se apresenta como Registro central. Não há alteração do SDK Lead Reader 1.0/1.1.
