<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Static, build-generated content. Reading help never touches provider/storage. */
final class Documentation {
    public const MAX_BYTES=65536;
    public static function read(array $i): array {
        Access::admin();
        $docs=require Config::DIR.'includes/Data/Documentation.php';
        $id=$i['document']??'README.md';
        $identity=['slug'=>Config::SLUG,'plugin_version'=>Config::VERSION,'origin'=>'local','encoding'=>'UTF-8'];
        $index=[];
        foreach($docs as $name=>$content)$index[]=['document'=>$name,'bytes'=>strlen($content),'sha256'=>hash('sha256',$content)];
        if($id==='index')return $identity+['documents'=>$index,'max_limit_bytes'=>self::MAX_BYTES,'read'=>['ability'=>Config::PREFIX.'/documentation','parameters'=>['document'=>'README.md','offset'=>0,'limit_bytes'=>16384]],'continuation'=>'Use next_offset e expected_revision; concatene content sem separadores e confira SHA-256 integral.'];
        if(!isset($docs[$id]))throw new Fault('not_found','Documento fora do índice instalado.');
        $content=$docs[$id];$hash=hash('sha256',$content);$at=$i['offset']??0;$limit=$i['limit_bytes']??16384;
        if(!is_int($at)||$at<0||$at>strlen($content)||!is_int($limit)||$limit<256||$limit>self::MAX_BYTES)throw new Fault('invalid_input','Faixa documental inválida.');
        if(($at>0&&!isset($i['expected_revision']))||(isset($i['expected_revision'])&&!hash_equals($hash,$i['expected_revision'])))throw new Fault('revision_conflict','Documento alterado; reinicie pelo índice.');
        if($at<strlen($content)&&(ord($content[$at])&0xc0)===0x80)throw new Fault('invalid_input','Offset deve iniciar caractere UTF-8.');
        $end=min(strlen($content),$at+$limit);
        while($end<strlen($content)&&(ord($content[$end])&0xc0)===0x80)$end--;
        return $identity+['document'=>$id,'content'=>substr($content,$at,$end-$at),'sha256'=>$hash,'revision'=>$hash,'total_bytes'=>strlen($content),'offset'=>$at,'returned_bytes'=>$end-$at,'next_offset'=>$end<strlen($content)?$end:null,'has_more'=>$end<strlen($content),'documents'=>$id==='README.md'?$index:[]];
    }
}
