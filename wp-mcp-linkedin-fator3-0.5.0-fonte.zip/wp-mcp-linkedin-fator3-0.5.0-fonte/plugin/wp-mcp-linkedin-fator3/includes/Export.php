<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Export {
    public static function create(array $i): array {
        $r=Store::get('job',$i['job_id']);if(!$r)throw new Fault('not_found','Coleta não encontrada.');$v=$r['value'];Access::owned($v['principal']);
        if($v['status']!=='complete'&&empty($i['allow_partial']))throw new Fault('incomplete_collection','Exportação exige coleta completa ou allow_partial explícito.');
        if($v['pages']===0)throw new Fault('result_unavailable','A coleta ainda não possui páginas.');
        $pages=[];$bytes=0;for($n=0;$n<$v['pages'];$n++){$page=Jobs::results(['job_id'=>$i['job_id'],'page'=>$n]);$pages[]=$page['data'];$bytes+=strlen(Util::json($page['data']));if($bytes>8000000)throw new Fault('export_limit','Exportação limitada a 8 MiB de dados; divida a coleta.');}
        $id=hash('sha256',Util::json([$v['principal'],$i['idempotency_key']]));$intent=hash('sha256',Util::json([$i['job_id'],$r['revision'],$i['format'],!empty($i['allow_partial'])]));
        return Store::lock('export:'.$id,static function()use($i,$id,$intent,$pages,$v){
            $old=Store::get('export',$id);if($old){if($old['value']['intent']!==$intent)throw new Fault('idempotency_conflict','Chave utilizada para outra exportação.');return self::receipt($id,$old['value']);}
            $out=['contract'=>'social-reporting/1.0.0','provider'=>Config::SLUG,'job_id'=>$i['job_id'],'job_status'=>$v['status'],'complete'=>$v['status']==='complete','generated_at'=>gmdate('c'),'pages'=>$pages];
            if($i['format']==='json')$content=Util::json($out);
            else{$h=fopen('php://temp','w+');$columns=[];foreach($pages as $p)foreach($p['rows'] as $row)foreach(array_keys($row) as $key)$columns[$key]=true;$columns=array_keys($columns);
                fputcsv($h,array_merge(['provider','job_id','page','complete','report','account_id','fetched_at','timezone','currency','coverage_json'],array_map(static fn($k)=>'row.'.$k,$columns)),',','"','');
                foreach($pages as $n=>$p){$rows=$p['rows']?:[null];foreach($rows as $row){$vals=[Config::SLUG,$i['job_id'],(string)$n,$v['status']==='complete'?'true':'false',$p['report'],$p['account_id'],$p['fetched_at'],$p['timezone'],(string)$p['currency'],Util::json($p['coverage'])];foreach($columns as $col){$val=$row!==null&&array_key_exists($col,$row)?$row[$col]:'';$vals[]=is_array($val)||is_object($val)||$val===null||is_bool($val)?Util::json($val):(string)$val;}fputcsv($h,array_map([self::class,'safeCell'],$vals),',','"','');}}
                rewind($h);$content=stream_get_contents($h);fclose($h);}
            if(strlen($content)>12000000)throw new Fault('export_limit','Arquivo excede 12 MiB.');
            $value=['intent'=>$intent,'principal'=>$v['principal'],'query'=>$v['query'],'connection_revision'=>$v['connection_revision'],'format'=>$i['format'],'filename'=>Config::SLUG.'-'.substr($id,0,12).'.'.$i['format'],'content'=>$content,'sha256'=>hash('sha256',$content),'bytes'=>strlen($content),'expires_at'=>time()+86400];Store::put('export',$id,$value,0,$value['expires_at']);return self::receipt($id,$value);
        });
    }
    public static function safeCell($s): string {$s=(string)$s;return preg_match('/^[\s]*[=+@\-]/u',$s)?"'".$s:$s;}
    private static function receipt(string $id,array $v): array {return ['export_id'=>$id,'filename'=>$v['filename'],'sha256'=>$v['sha256'],'bytes'=>$v['bytes'],'expires_at'=>$v['expires_at'],'download'=>'Use export-read autenticado ou o botão Baixar no painel. Nenhuma URL pública é gerada.'];}
    public static function value(string $id): array {
        $r=Store::get('export',$id);if(!$r||$r['expires_at']<time())throw new Fault('export_unavailable','Arquivo ausente ou expirado.');$v=$r['value'];Access::owned($v['principal']);$c=Connections::get($v['query']['connection_id']);Access::worker($v['principal'],$c,$v['query']['channel'],$v['query']['account_id'],false);if(Config::KEY!=='f3_meta'&&$v['connection_revision']!==$c['revision'])throw new Fault('revision_conflict','Conexão alterada após a exportação.');return $v;
    }
    public static function read(array $i): array {
        $v=self::value($i['export_id']);$offset=$i['offset_bytes']??0;$limit=$i['byte_limit']??196608;if($offset>$v['bytes'])throw new Fault('invalid_input','Offset excede o arquivo.');$s=substr($v['content'],$offset,$limit);
        return self::receipt($i['export_id'],$v)+['offset_bytes'=>$offset,'content_base64'=>base64_encode($s),'returned_bytes'=>strlen($s),'next_offset'=>$offset+strlen($s)<$v['bytes']?$offset+strlen($s):null];
    }
}
