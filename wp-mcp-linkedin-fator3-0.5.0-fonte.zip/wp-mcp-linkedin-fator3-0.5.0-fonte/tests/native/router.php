<?php
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);$file=getenv('F3_LAB_ROOT').'/wordpress'.$path;if(is_file($file))return false;require getenv('F3_LAB_ROOT').'/wordpress/index.php';
