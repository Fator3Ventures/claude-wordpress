<?php
/** Public local measurement SDK. No network, repair, scheduling or visitor data. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

final class F3Base_Medicao_Contexto {
    public const CONTRATO='site-measurement-context/1.0.0';
    public const PRODUTOR='base-site-core-fator3';
    private const CAMPOS=array(
        'ga4'=>array('measurement_id'=>array('f3base_ga4_measurement_id','')),
        'gtm'=>array('container_id'=>array('f3base_gtm_container_id','')),
        'google_ads'=>array('conversion_id'=>array('f3base_google_ads','conversion_id'),'conversion_label'=>array('f3base_google_ads','conversion_label')),
        'meta'=>array('pixel_id'=>array('f3base_meta_pixel_id',''),'server_pixel_id'=>array('f3base_meta_capi_pixel_id','')),
        'linkedin'=>array('partner_id'=>array('f3base_linkedin_partner_id',''),'conversion_id'=>array('f3base_linkedin_conversion_id','')),
        'clarity'=>array('project_id'=>array('f3base_clarity_project_id','')),
    );
    private const POLITICAS=array('f3base_conversoes_transporte','f3base_consentimento','f3base_google_carregamento','f3base_carregamento_destinos','f3base_testes','f3base_eventos_destinos','f3base_comportamento','f3base_meta_transporte','f3base_meta_homologacao','f3base_meta_auto_config','f3base_meta_janela','f3base_gtm_evidencia');
    private static function resposta(string $code,?array $data=null): array {
        $r=array('ok'=>$code==='ok','code'=>$code,'contract'=>self::CONTRATO,'provider'=>self::PRODUTOR,'data'=>$data);
        if ($code!=='ok') { $r['message']=array('unreadable'=>'Não foi possível ler o contexto de medição.','revision_conflict'=>'A configuração ou o catálogo mudou; repita a leitura.','invalid_input'=>'Confira os parâmetros de paginação.','unsupported'=>'Contrato ou schema de medição indisponível.','not_authorized'=>'Sem permissão para consultar medição.')[$code]??'Contexto indisponível.'; }
        return $r;
    }
    public static function capabilities(): array {
        return self::resposta('ok',array('methods'=>array('capabilities','snapshot','events'),'capabilities'=>array('measurement.context.read','measurement.events.read'),'schema_revision'=>'1','max_page_size'=>200,
            'schemas'=>array('capabilities'=>'docs/schemas/measurement-capabilities.json','snapshot'=>'docs/schemas/measurement-snapshot.json','events_input'=>'docs/schemas/measurement-events-input.json','events'=>'docs/schemas/measurement-events.json')));
    }
    public static function schema(string $name): array {
        if (!in_array($name,array('capabilities','snapshot','events','events-input','ability-snapshot','ability-events'),true)) { return array(); }
        $path=F3BASE_PLUGIN_DIR.'docs/schemas/measurement-'.$name.'.json';
        $s=is_readable($path)?json_decode((string)file_get_contents($path),true):null;
        return is_array($s)?$s:array();
    }
    /** Compare actual filter boundaries, rather than attributing every normalization to a filter. */
    private static function efetivo(string $name): array {
        $traces=array();$hooks=array('pre_option_'.$name,'pre_option','default_option_'.$name,'option_'.$name);$callbacks=array();
        foreach ($hooks as $hook) {
            $before=static function($v,...$args)use(&$traces,$hook,$name){
                if ($hook!=='pre_option'||($args[0]??null)===$name) { $traces[$hook]['before']=$v; } return $v;
            };
            $after=static function($v,...$args)use(&$traces,$hook,$name){
                if ($hook!=='pre_option'||($args[0]??null)===$name) { $traces[$hook]['after']=$v; } return $v;
            };
            add_filter($hook,$before,PHP_INT_MIN,3);add_filter($hook,$after,PHP_INT_MAX,3);$callbacks[$hook]=array($before,$after);
        }
        try { $value=F3Base_Options::ler($name); }
        finally { foreach ($callbacks as $hook=>$c) { remove_filter($hook,$c[0],PHP_INT_MIN);remove_filter($hook,$c[1],PHP_INT_MAX); } }
        $changed=false;
        foreach ($traces as $hook=>$trace) {
            if (!array_key_exists('before',$trace)||!array_key_exists('after',$trace)||$trace['before']===$trace['after']) { continue; }
            $after=$trace['after'];
            if (str_starts_with($hook,'pre_option') && $after===false) { continue; }
            if (F3Base_Options::equivalente(F3Base_Options::sanitizar($name,$after),$value)) { $changed=true; }
        }
        return array('value'=>$value,'filtered'=>$changed);
    }
    private static function ler_opcoes(): array {
        $names=self::POLITICAS;
        foreach (self::CAMPOS as $fields) { foreach ($fields as $definition) { $names[]=$definition[0]; } }
        // Read only revisions of secret storage: never decrypt or project its value.
        $names[]=F3Base_Options::OPTION_PROVENIENCIA;$names[]='f3base_meta_capi_token';$names=array_values(array_unique($names));
        $raw=array();$effective=array();$filtered=array();$revisions=array();
        foreach ($names as $name) {
            $f=F3Base_Options::fotografia_bruta($name);
            if ($f['erro']) { throw new RuntimeException('unreadable'); }
            $revisions[$name]=$f['revisao'];
            if ($name==='f3base_meta_capi_token') { continue; }
            $raw[$name]=$f;
            if ($name===F3Base_Options::OPTION_PROVENIENCIA) { continue; }
            $observed=self::efetivo($name);$effective[$name]=$observed['value'];$filtered[$name]=$observed['filtered'];
        }
        return array('raw'=>$raw,'effective'=>$effective,'filtered'=>$filtered,'revisions'=>$revisions);
    }
    private static function campo($value,string $key): ?string {
        if ($key!=='') { $value=is_array($value)?($value[$key]??'') : null; }
        return is_string($value)?$value:null;
    }
    private static function seguro(?string $value,string $slot,string $field): ?string {
        if ($value===null||strlen($value)>F3Base_Options::TAMANHOS['tag_id']) { return null; }
        if ($value==='') { return ''; }
        // Use the same sanitization and public format rules as the actual emitter.
        if ($field==='conversion_label') { return F3Base_Options::sanitiza_id_de_tag($value,'')===$value?$value:null; }
        [$name,$key]=self::CAMPOS[$slot][$field];
        $name=$field==='server_pixel_id'?'f3base_meta_pixel_id':($key===''?$name:$name.'.'.$key);
        $pattern=F3Base_Modulo_Tracking::formas()[$name]['regex']??null;
        return is_string($pattern)&&preg_match($pattern,$value)===1?$value:null;
    }
    private static function procedencia(string $name,array $all): array {
        $f=$all['raw'][$name];$records=$all['raw'][F3Base_Options::OPTION_PROVENIENCIA]['valor'];$entry=is_array($records)?($records[$name]??null):null;
        $known=is_array($entry)&&in_array($entry['origem']??'',F3Base_Options::origens(),true);
        $confirmed=$known&&is_string($entry['revisao']??null)&&hash_equals($f['revisao'],$entry['revisao']);
        $expected=$f['existe']?F3Base_Options::sanitizar($name,$f['valor']):(F3Base_Options::declaracao($name)['padrao']??null);
        $different=!F3Base_Options::equivalente($expected,$all['effective'][$name]);$filtered=$different&&$all['filtered'][$name];
        return array('recorded_origin'=>$known?$entry['origem']:null,'channel'=>$known&&in_array($entry['canal']??null,array('php','ability','admin','cli','mcp'),true)?$entry['canal']:null,
            'recorded_at'=>$known&&!empty($entry['em'])&&is_numeric($entry['em'])?gmdate('c',(int)$entry['em']):null,
            'record_status'=>$confirmed?'confirmed':($entry!==null?'unconfirmed':($f['existe']?'unknown':'default')),
            'effective_source'=>$filtered?'filtered':($different?'unknown':($f['existe']?'configured':'default')),'changed_by_filter'=>$filtered?true:($different?null:false));
    }
    private static function politica(array $v): array {
        $c=$v['f3base_consentimento'];$g=$v['f3base_google_carregamento'];$d=$v['f3base_carregamento_destinos'];$t=$v['f3base_testes'];$m=$v['f3base_comportamento'];
        $dest=array();foreach(array('meta','linkedin','clarity') as $name) { $dest[$name]=array('mode'=>$d[$name]??'herdar','deadline_seconds'=>$d[$name.'_teto_segundos']??5); }
        $tests=array();foreach(array('ga4','gtm','google_ads','meta','linkedin','clarity') as $name) { $tests[$name]=$t['destinos'][$name]??'suprimir'; }
        $selections=array();foreach(array('ga4','data_layer') as $target) { foreach(array('f3base_saida','f3base_rolagem_salto','f3base_clique_interno','f3base_clique_inerte') as $event) { $key=$target.'_'.$event;$selections[$key]=$v['f3base_eventos_destinos'][$key]??true; } }
        return array('consent_mode'=>$c['modo']??'legado','measurement_default'=>$c['padrao']??'negado','advertising_default'=>$c['publicidade_politica']??'exigir_decisao','gtm_category_separation_verified'=>(bool)($c['gtm_separacao_verificada']??false),
            'google_loading'=>array('mode'=>$g['modo']??'imediato','deadline_seconds'=>$g['teto_segundos']??5),'destination_loading'=>array('enabled'=>(bool)($d['ativo']??false),'destinations'=>$dest),
            'test_policy'=>array('enabled'=>(bool)($t['habilitado']??false),'exclude_reports'=>(bool)($t['excluir_relatorios']??true),'destinations'=>$tests),
            'audience_exclusions'=>array('404','editor'),'local_collection'=>(bool)($m['ligado']??false),'event_selection'=>$selections);
    }
    private static function fotografia(): array {
        $all=self::ler_opcoes();$v=$all['effective'];$slots=array();$warnings=array();$policy=self::politica($v);
        $tracking=F3Base_Registro::modulo('tracking')!==null;$consent=F3Base_Registro::modulo('consentimento')!==null;
        $meta=F3Base_Meta_Transporte::efetivo();$ids=F3Base_Modulo_Tracking::ids();
        foreach (self::CAMPOS as $slot=>$fields) {
            $configured=array();$effective=array();$provenances=array();$persisted=false;$invalid=false;
            foreach ($fields as $field=>[$name,$key]) {
                $f=$all['raw'][$name];$persisted=$persisted||$f['existe'];
                $normalized=$f['existe']?F3Base_Options::sanitizar($name,$f['valor']):null;
                $configured[$field]=$f['existe']?self::seguro(self::campo($normalized,$key),$slot,$field):null;
                $value=self::campo($v[$name],$key);
                $idKey=$key===''?$name:$name.'.'.$key;
                if (array_key_exists($idKey,$ids)&&$value!==$ids[$idKey]) { throw new RuntimeException('revision_conflict'); }
                $effective[$field]=self::seguro($value,$slot,$field);$invalid=$invalid||$effective[$field]===null;
                $provenances[]=self::procedencia($name,$all);
            }
            if ($slot==='meta'&&$effective['server_pixel_id']==='') { $effective['server_pixel_id']=$effective['pixel_id']; }
            $provenance=$provenances[0];
            foreach ($provenances as $p) { $comparable=$p;$baseline=$provenance;if($slot==='linkedin'&&$p['record_status']==='confirmed'&&$provenance['record_status']==='confirmed'){unset($comparable['recorded_at'],$baseline['recorded_at']);if($comparable===$baseline&&$p['recorded_at']!==$provenance['recorded_at']){$provenance['recorded_at']=null;}} if ($comparable!==$baseline) { $provenance=array('recorded_origin'=>null,'channel'=>null,'recorded_at'=>null,'record_status'=>'unknown','effective_source'=>'unknown','changed_by_filter'=>null);$warnings[]=array('code'=>'mixed_provenance_'.$slot,'message'=>'O destino reúne campos com procedências diferentes.');break; } }
            $required=array('ga4'=>array('measurement_id'),'gtm'=>array('container_id'),'google_ads'=>array('conversion_id','conversion_label'),'meta'=>array($meta['modo']==='servidor'?'server_pixel_id':'pixel_id'),'linkedin'=>array('partner_id'),'clarity'=>array('project_id'))[$slot];
            $empty=false;foreach($required as $key) { $empty=$empty||$effective[$key]===''; }
            $state=!$tracking||!$consent?'disabled':($invalid?'invalid':($empty?'empty':'configured'));
            $routes=$state==='configured'?array($slot==='gtm'?'gtm_container':'core_browser'):array();$reasons=array();
            if ($slot==='meta' && $state==='configured') { if ($meta['modo']==='servidor') { $routes=array('core_server'); } elseif($meta['modo']==='ambos') { $routes[]='core_server'; } }
            if ($state!=='configured') { $reasons[]=$state==='disabled'?'module_unavailable':($state==='empty'?'required_id_empty':'invalid_public_id'); }
            if ($slot==='linkedin'&&$effective['conversion_id']==='') { $reasons[]='conversion_id_empty'; }
            if ($slot==='meta'&&in_array('core_server',$routes,true)) { $reasons[]='server_credentials_not_verified'; }
            $transport=$slot==='meta'?$meta['modo']:null;$ready=$state==='configured';
            if($slot==='linkedin'){$transport=$v['f3base_conversoes_transporte']['linkedin']??'ambos';if($transport==='ambos'&&($effective['partner_id']!==''||$effective['conversion_id']!=='')){$cap=F3Base_Conversoes_Transporte::capacidade('linkedin');if($state==='configured'){$routes[]='core_server';}$ready=$ready&&$cap['ready'];if(!$cap['ready']){$reasons[]='server_credentials_not_verified';$warnings[]=array('code'=>'linkedin_server_'.$cap['reason'],'message'=>'LinkedIn: envio pelo servidor bloqueado — '.str_replace('_',' ',$cap['reason']).'.');}}}
            $slots[$slot]=array('state'=>$state,'configured'=>array('persisted'=>$persisted,'fields'=>$persisted?$configured:null),'effective'=>array('fields'=>$effective),'provenance'=>$provenance,
                'emission'=>array('routes'=>$routes,'transport'=>$transport,'configuration_ready'=>$ready,'reasons'=>$reasons));
        }
        $catalog=self::catalogo();
        if ($slots['gtm']['state']==='configured' && array_filter(array('ga4','google_ads','meta','linkedin','clarity'),static fn($x)=>$slots[$x]['state']==='configured')) { $warnings[]=array('code'=>'possible_concurrent_emitters','message'=>'GTM e slots diretos estão configurados; confira as tags do contêiner. Não é prova de dupla entrega.'); }
        $data=array('events_revision'=>$catalog['revision'],'scope'=>'site_request','emission_mode'=>(!$tracking||!$consent)?'nenhum':F3Base_Modulo_Tracking::caminho(),'runtime_verified'=>false,'remote_access_verified'=>false,'policy'=>$policy,'slots'=>$slots,'warnings'=>$warnings);
        return array('data'=>$data,'guard'=>$all['revisions']);
    }
    public static function snapshot(): array {
        try {
            $a=self::fotografia();$b=self::fotografia();
            if (!F3Base_Options::equivalente($a,$b)) { return self::resposta('revision_conflict'); }
            $data=$b['data'];$data['revision']=hash('sha256',(string)wp_json_encode(F3Base_Auditoria::ordenar($data)));$data['observed_at']=gmdate('c');
            $response=self::resposta('ok',$data);
            $schema=self::schema('snapshot');if(!$schema){return self::resposta('unsupported');}$valid=rest_validate_value_from_schema($response,$schema,'measurement');
            return is_wp_error($valid)?self::resposta('unreadable'):$response;
        } catch (Throwable $e) { return self::resposta($e instanceof RuntimeException&&$e->getMessage()==='revision_conflict'?'revision_conflict':'unreadable'); }
    }
    private static function catalogo(): array {
        $path=F3BASE_PLUGIN_DIR.'dados/medicao-eventos.json';$text=is_readable($path)?file_get_contents($path):false;
        $data=is_string($text)?json_decode($text,true):null;
        if (!is_array($data)||($data['contract']??'')!==self::CONTRATO||!is_array($data['items']??null)) { throw new RuntimeException('unreadable'); }
        return array('revision'=>hash('sha256',(string)$text),'items'=>$data['items']);
    }
    public static function events(array $input=array()): array {
        try {
            if (array_diff(array_keys($input),array('limit','offset','expected_revision')) || (array_key_exists('limit',$input)&&(!is_int($input['limit'])||$input['limit']<1||$input['limit']>200)) || (array_key_exists('offset',$input)&&(!is_int($input['offset'])||$input['offset']<0)) || (array_key_exists('expected_revision',$input)&&(!is_string($input['expected_revision'])||$input['expected_revision']===''||strlen($input['expected_revision'])>128))) { return self::resposta('invalid_input'); }
            $offset=$input['offset']??0;$limit=$input['limit']??100;
            if ($offset>0&&!isset($input['expected_revision'])) { return self::resposta('invalid_input'); }
            $catalog=self::catalogo();$total=count($catalog['items']);
            if (isset($input['expected_revision'])&&!hash_equals($catalog['revision'],$input['expected_revision'])) { return self::resposta('revision_conflict'); }
            if ($offset>$total) { return self::resposta('invalid_input'); }
            $items=array_slice($catalog['items'],$offset,$limit);foreach($items as &$item){if($item['parameters']===array()){$item['parameters']=new stdClass();}}unset($item);$next=$offset+count($items);$complete=$next===$total;
            $result=self::resposta('ok',array('revision'=>$catalog['revision'],'total'=>$total,'items'=>$items,'next_offset'=>$complete?null:$next,'complete'=>$complete));
            $schema=self::schema('events');if(!$schema){return self::resposta('unsupported');}$valid=rest_validate_value_from_schema($result,$schema,'events');
            return is_wp_error($valid)?self::resposta('unreadable'):$result;
        } catch (Throwable $e) { return self::resposta('unreadable'); }
    }
    public static function registrar(): void {
        if (!function_exists('wp_register_ability')) { return; }
        foreach (array('medicao-contexto-ler'=>'snapshot','medicao-eventos-ler'=>'events') as $name=>$method) {
            F3Base_Servicos::registrar_ability('f3base/'.$name,array('label'=>$method==='snapshot'?'Contexto público de medição':'Catálogo público de eventos','description'=>'Leitura local, sem rede, credenciais, contatos ou alterações. Contrato '.self::CONTRATO,'category'=>F3BASE_PREFIXO,
                'input_schema'=>$method==='events'?self::schema('events-input'):array('type'=>'object','additionalProperties'=>false),
                'output_schema'=>self::schema('ability-'.$method),'execute_callback'=>static function($input=array())use($method){if(!current_user_can('manage_options')){return self::resposta('not_authorized');}return $method==='events'?self::events($input):self::snapshot();},
                'permission_callback'=>static fn()=>current_user_can('manage_options'),'meta'=>array('show_in_rest'=>true,'mcp'=>array('public'=>true,'type'=>'tool'),'annotations'=>array('readonly'=>true,'destructive'=>false,'idempotent'=>true))));
        }
    }
}
