# Impacto de Core 1.40.0 em MCP Google

Revisão 2 · 20/10/2026 · Etapa: implementação/entrega · Situação: código entregue; incorporação pendente. Classificação: ação necessária de incorporação. Base Google examinada 0.13.0; alvo do mantenedor 0.14.0.

## Decisão e implementação

O plano Google 0.14 substitui a proposta anterior de Data Manager obrigatório: preservado site-conversion-delivery/1.0.0, sem estados assíncronos. A dependência foi implementada nesta frente, sem aguardar retorno: ConversionDelivery, segredo MP, tela/abilities administrativas, grant de background, verificação de destino e upload unitário GA4/Ads. O contrato de leitura Core 1.1 é negociado; 1.0 continua válido. Não há mudança em Google 29.

## Repasse

Aplicar wp-mcp-google-fator3-dependencia-core-1.40.0.zip à base 0.13 ou incorporar suas mudanças à árvore 0.14 em andamento. Contém patch, arquivos completos alterados, documentação compilada e testes. Não é instalador nem release Google publicada. Não exige resposta para concluir o código Core; o mantenedor recebe a implementação para incorporar, testar e publicar com o próprio trabalho.

## Compatibilidade e evidência

Core 1.40 no modo navegador funciona com Google 0.13. Servidor exige patch incorporado e ready=true. O adaptador respeita o existente. Quinze testes PHP de contrato/falhas e cinco verificações de bootstrap integrado em WordPress passaram. Sem chamada Google real. GA4 entregue = recepção HTTP. Ads parcial/incerto não confirma sucesso. Prontidão exige prova renovada após 24h; destino alterado não reaproveita fila. A elegibilidade Ads usa recibo real declarado pelo administrador mais leitura da ação; request_id não é validado por endpoint de recibos.

## Pendências

Incorporação no Google 0.14, configuração real, APIs e homologação analítica. Não implementar Data Manager sem evidência da necessidade. Este repasse resolve a dependência de desenvolvimento; não declara incorporação/publicação do mantenedor nem homologação em produção.
