# Fator3 Site Core 1.40.0 — fonte

Código em work/plugin/base-site-core-fator3/. Instruções em build/README.md. Consulte o relatório: entrega com pendências de homologação e navegador disponível; servidor e C0 dependem de configuração e homologação. Este ZIP não é instalável no WordPress.
