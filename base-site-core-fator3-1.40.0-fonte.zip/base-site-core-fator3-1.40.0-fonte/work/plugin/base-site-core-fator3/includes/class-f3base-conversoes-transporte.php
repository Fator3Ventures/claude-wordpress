<?php
/** Ownership is captured with the accepted record, never inferred from cached HTML. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Conversoes_Transporte {
    public static function catalogo(array $c): array {
        $props=$sub=array();foreach(array('ga4'=>'GA4','google_ads'=>'Google Ads') as $key=>$label){$props[$key]=array('type'=>'string','enum'=>array('navegador','servidor'));$sub[$key]=array('tipo'=>'enum','opcoes'=>array('navegador'=>'Navegador','servidor'=>'Servidor'),'rotulo'=>$label,'descricao'=>'navegador ou servidor. Servidor exige adaptador pronto.','impacto'=>'Aplica-se somente a novos contatos; não transfere entregas anteriores.');}
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>$props,'required'=>array_keys($props));
        $c['f3base_conversoes_transporte']=array('rotulo'=>'Transporte das conversões de contato','descricao'=>'Escolha independente por destino. Padrão navegador em instalação e atualização.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','autoload'=>false,'padrao'=>array('ga4'=>'navegador','google_ads'=>'navegador'),'subcampos'=>$sub,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>array(__CLASS__,'validar'));
        return $c;
    }
    public static function capacidade(string $target): array {
        try{$a=F3Base_Conversoes_Servidor::adaptador($target);$v=$a?$a->capabilities():array();}catch(Throwable $e){$v=array();}
        $ok=is_array($v)&&($v['contract']??'')===F3Base_Conversoes_Servidor::CONTRATO&&($v['ready']??false)===true&&is_string($v['destination_ref']??null)&&$v['destination_ref']!==''&&strlen($v['destination_ref'])<=191;
        return array('ready'=>$ok,'destination_ref'=>$ok?$v['destination_ref']:'','reason'=>$ok?'ok':'adaptador_indisponivel');
    }
    public static function validar($v): string {
        if(!is_array($v)||count($v)!==2){return 'Informe ga4 e google_ads.';}
        foreach(array('ga4','google_ads') as $t){if(!in_array($v[$t]??'',array('navegador','servidor'),true)){return 'Use navegador ou servidor.';}if($v[$t]==='servidor'&&!self::capacidade($t)['ready']){return 'Servidor indisponível para '.$t.': configure e valide o adaptador Google.';}}return '';
    }
    public static function capturar(): array {
        $v=F3Base_Options::ler('f3base_conversoes_transporte');$out=array();foreach(array('ga4','google_ads') as $t){$out[$t]=($v[$t]??'')==='servidor'?'servidor':'navegador';}
        return array('destinos'=>$out,'revisao'=>hash('sha256',(string)wp_json_encode($out)));
    }
    public static function registro(array $lead): array {
        $d=$lead['dados']??array();$stored=$d['conversoes_transporte']['destinos']??array();$out=array();
        foreach(array('ga4','google_ads') as $t){$out[$t]=in_array($stored[$t]??'',array('navegador','servidor'),true)?$stored[$t]:((int)($d['conversoes_servidor_versao']??0)===1?'servidor':'desconhecido');}
        return $out;
    }
    public static function estado(): array {
        $v=self::capturar();$out=array();foreach($v['destinos'] as $t=>$mode){$cap=$mode==='servidor'?self::capacidade($t):array('ready'=>true,'reason'=>'ok');$out[$t]=array('selected'=>$mode,'effective'=>$mode,'ready'=>$cap['ready'],'reason'=>$cap['reason']);}return $out;
    }
}
