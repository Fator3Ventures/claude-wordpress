# Ajuda das opções — Core 1.40.0

Gerada do catálogo executável e da ajuda efetiva. Não contém valores configurados no site.

## f3base_contato

```json
{
    "rotulo": "Contato, avisos e WhatsApp",
    "descricao": "Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.",
    "campo": "grupo",
    "subcampos": {
        "flutuante": {
            "tipo": "booleano",
            "rotulo": "Ativar WhatsApp flutuante",
            "descricao": "Ícone fixo no canto inferior direito em todas as páginas públicas.",
            "impacto": "Ativado com um número válido, publica um link de WhatsApp independente do menu e do layout. Desativado, o plugin não publica esse ícone. Os botões do tema são definidos pelo próprio layout.",
            "exemplo": "Marque para manter o contato disponível durante a rolagem no computador e no celular.",
            "ajuda": {
                "funcionamento": "Ativado com um número válido, publica um link de WhatsApp independente do menu e do layout. Desativado, o plugin não publica esse ícone. Os botões do tema são definidos pelo próprio layout.",
                "escolha": "Ative para oferecer acesso direto ao WhatsApp em páginas elegíveis.",
                "vantagens": "Mantém o atendimento acessível durante a navegação.",
                "limitacoes": "Clique direto é intenção; não informa nome/e-mail e não cria pessoa no CRM.",
                "exemplo": "Ativado com número completo; o visitante abre o aplicativo de WhatsApp.",
                "vazio": "Desmarcado oculta o botão; preserva número e mensagem."
            }
        },
        "whatsapp_e164": {
            "tipo": "texto",
            "rotulo": "Número de WhatsApp",
            "descricao": "Código do país, DDD e número, somente dígitos.",
            "impacto": "Define o destino do WhatsApp flutuante quando ele estiver ativado. Preencher o número não insere nem altera botões no menu ou no conteúdo. O clique instrumentado respeita o consentimento e os canais configurados.",
            "exemplo": "Ilustrativo: 5511900000000 — o 55 do país, o 11 do DDD e o número, sem espaço, traço ou parêntese.",
            "ajuda": {
                "funcionamento": "Define o destino do WhatsApp flutuante quando ele estiver ativado. Preencher o número não insere nem altera botões no menu ou no conteúdo. O clique instrumentado respeita o consentimento e os canais configurados.",
                "escolha": "Informe país, DDD e telefone do atendimento.",
                "vantagens": "Todos os botões que herdam o contato usam o mesmo destino.",
                "limitacoes": "Número incorreto pode encaminhar a outra pessoa. Não comprova conta WhatsApp ativa.",
                "exemplo": "5511900000000",
                "vazio": "Vazio deixa o destino sem configuração; não cria número automaticamente."
            }
        },
        "mensagem_padrao": {
            "tipo": "textarea",
            "rotulo": "Mensagem que abre a conversa",
            "descricao": "Texto já escrito na conversa quando o visitante chega ao WhatsApp.",
            "impacto": "Preenchida, é este texto que aparece escrito na conversa antes de o visitante digitar qualquer coisa — é onde se diz de qual página ele veio. Vazia, abre o destino sem texto inicial.",
            "exemplo": "Ilustrativo: \"Olá! Vim pelo site e gostaria de falar com a equipe.\"",
            "ajuda": {
                "funcionamento": "Texto inicial geral do WhatsApp. O botão flutuante usa a frase “Olá! Vim pelo site [nome] e quero falar com a equipe.” quando vazio. Formulários respeitam a mensagem específica e, sem ambas, não acrescentam introdução própria.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Olá! Gostaria de conversar sobre nossos serviços.",
                "vazio": "Vazio usa a frase de fallback no flutuante; formulários não inventam essa frase. URL de CTA preserva seu texto quando aplicável.",
                "padrao": "vazio"
            }
        },
        "email_leads": {
            "tipo": "emails",
            "rotulo": "Quem recebe os avisos internos (até cinco)",
            "descricao": "E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.",
            "impacto": "E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.",
            "ajuda": {
                "funcionamento": "Recebe os avisos internos. Na primeira configuração, copia o e-mail da administração do WordPress. Formulário com lista própria usa sua lista; o resumo horário usa a lista geral.",
                "escolha": "Use uma caixa acompanhada pela equipe comercial. A ação Usar e-mail da administração preenche o campo para revisão, sem salvar.",
                "vantagens": "Começa com um endereço existente e centraliza formulários sem lista própria.",
                "limitacoes": "Uma caixa técnica pode não ser acompanhada pelo atendimento. Alterar o e-mail do WordPress depois não atualiza este campo. Endereço válido não comprova entrega.",
                "exemplo": "contato@example.com e comercial@example.com, um por linha; até cinco destinatários.",
                "vazio": "Nenhum destinatário geral; formulários com lista própria continuam usando essa lista."
            },
            "estrutura": {
                "itens": []
            }
        },
        "avisar_por_clique": {
            "tipo": "booleano",
            "rotulo": "Enviar aviso interno de clique",
            "descricao": "Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.",
            "impacto": "Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.",
            "ajuda": {
                "funcionamento": "Envia aviso interno quando um CTA de contato é registrado. O clique representa intenção de contato.",
                "escolha": "Ative se a equipe precisa acompanhar cliques; desative se o volume de intenção atrapalha o atendimento de envios.",
                "vantagens": "Dá visibilidade a contatos iniciados fora do formulário.",
                "limitacoes": "Clique não comprova conversa, pessoa identificada ou venda. Há limite de avisos individuais e resumo horário.",
                "exemplo": "Um clique em WhatsApp pode gerar aviso; o registro permanece quando o aviso está desligado.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "avisar_por_formulario": {
            "tipo": "booleano",
            "rotulo": "Enviar aviso interno de formulário recebido",
            "descricao": "Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.",
            "impacto": "Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.",
            "ajuda": {
                "funcionamento": "Notifica a equipe sobre envios aceitos. Suspeitos e testes suprimidos permanecem no registro, sem aviso comercial.",
                "escolha": "Mantenha ativo quando o e-mail participa do atendimento.",
                "vantagens": "Facilita responder a uma solicitação com dados fornecidos pelo visitante.",
                "limitacoes": "Não substitui a consulta da fila de contatos. A resposta automática ao visitante tem controle separado.",
                "exemplo": "Formulário sem destinatários próprios usa a lista geral; lista própria vazia não herda.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "classes_cta": {
            "tipo": "linhas",
            "rotulo": "Classes adicionais de botões de contato",
            "descricao": "Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.",
            "impacto": "Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.",
            "ajuda": {
                "funcionamento": "Reconhece links dentro de contêineres com as classes informadas. Não muda destinos nem identifica campos de formulário.",
                "escolha": "Use quando os blocos existentes já têm uma classe estável de contato.",
                "vantagens": "Instrumenta blocos existentes sem recriar os links.",
                "limitacoes": "Classes genéricas podem marcar links que não são contatos. Para botões sem href, declare data-f3base-destino.",
                "exemplo": "acao-comercial, sem ponto inicial. Preserve data-f3base-lead existente para manter a série histórica.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            },
            "estrutura": {
                "itens": []
            }
        },
        "historico_sem_decisao": {
            "tipo": "enum",
            "rotulo": "Histórico com referência de consentimento perdida",
            "descricao": "Aplica-se quando a referência registrada não é localizada. Preserva negativas e revogações conhecidas.",
            "impacto": "Permitir usa os dados históricos disponíveis e indica a evidência ausente; negar restringe apresentação e reenvio sem apagar dados.",
            "exemplo": "Uma referência removida por retenção não impede o atendimento no modo permitir. A mudança não reenvia contatos automaticamente.",
            "opcoes": {
                "permitir": "Exibir e permitir reenvio do histórico",
                "negar": "Restringir o histórico"
            },
            "ajuda": {
                "funcionamento": "permitir conserva apresentação/reenvio do histórico com referência positiva perdida; negar restringe os dados. Negativa explícita conhecida continua prevalecendo.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "negar reduz o snapshot quando a decisão não pode ser recuperada.",
                "vazio": "Ausente usa permitir; a alternativa de restrição no schema é negar.",
                "padrao": "permitir"
            }
        },
        "carimbar_whatsapp_por_destino": {
            "tipo": "booleano",
            "rotulo": "Reconhecer links para este WhatsApp",
            "descricao": "Marca automaticamente links HTTPS para o número configurado, sem alterar o destino.",
            "impacto": "Ative para incluir links sem classe de CTA. Links wa.me/message continuam exigindo marca explícita.",
            "exemplo": "https://wa.me/5511900000000 deve corresponder exatamente ao número completo do site.",
            "ajuda": {
                "funcionamento": "Ative para incluir links sem classe de CTA. Links wa.me/message continuam exigindo marca explícita.",
                "escolha": "Ative quando links sem classe apontarem exatamente ao número configurado.",
                "vantagens": "Instrumenta links existentes sem recriá-los.",
                "limitacoes": "Links encurtados wa.me/message não revelam o número e exigem marca explícita.",
                "exemplo": "https://wa.me/5511900000000 corresponde ao número do site.",
                "vazio": "Desmarcado mantém somente marcações explícitas e componentes do Core."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.",
        "escolha": "Ajuste este campo conforme a operação de Contato, avisos e WhatsApp neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Configure os e-mails da equipe e ative o aviso de formulário; mantenha o aviso de clique desligado se apenas envios completos exigirem atendimento.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "whatsapp_e164": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "whatsapp_e164",
                "escolha": "Informe país, DDD e telefone do atendimento.",
                "vantagens": "Todos os botões que herdam o contato usam o mesmo destino.",
                "limitacoes": "Número incorreto pode encaminhar a outra pessoa. Não comprova conta WhatsApp ativa.",
                "exemplo": "5511900000000",
                "vazio": "Vazio deixa o destino sem configuração; não cria número automaticamente."
            }
        },
        "historico_sem_decisao": {
            "tipo": "string",
            "padrao": "permitir",
            "ajuda": {
                "funcionamento": "permitir conserva apresentação/reenvio do histórico com referência positiva perdida; negar restringe os dados. Negativa explícita conhecida continua prevalecendo.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "negar reduz o snapshot quando a decisão não pode ser recuperada.",
                "vazio": "Ausente usa permitir; a alternativa de restrição no schema é negar.",
                "padrao": "permitir"
            }
        }
    }
}
```

## f3base_ga4_measurement_id

```json
{
    "rotulo": "Google Analytics 4 — ID da métrica",
    "descricao": "Identificador do fluxo de dados da propriedade do Google Analytics.",
    "campo": "texto",
    "impacto": "Preenchido, o site passa a carregar o Google Analytics e a enviar para lá as páginas vistas, os contatos e o comportamento que ele já mede: profundidade de rolagem, seções alcançadas, cliques que saem do site, sinais de dificuldade, erros de página e tempo de carregamento. Vazio, nada disso chega ao Google Analytics — o site continua guardando o resumo próprio, e a análise completa, com público, origem de tráfego e comparação de períodos, deixa de existir.",
    "exemplo": "Ilustrativo, na forma que o próprio Google usa na documentação: G-XXXXXXXXXX. O valor real aparece no fluxo de dados da propriedade.",
    "ajuda": {
        "funcionamento": "Preenchido, o site passa a carregar o Google Analytics e a enviar para lá as páginas vistas, os contatos e o comportamento que ele já mede: profundidade de rolagem, seções alcançadas, cliques que saem do site, sinais de dificuldade, erros de página e tempo de carregamento. Vazio, nada disso chega ao Google Analytics — o site continua guardando o resumo próprio, e a análise completa, com público, origem de tráfego e comparação de períodos, deixa de existir.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Envia eventos elegíveis à propriedade selecionada.",
        "limitacoes": "GTM ou tema podem enviar à mesma propriedade; evite duplicidade.",
        "exemplo": "G-EXEMPLO123",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    },
    "estrutura": []
}
```

## f3base_gtm_container_id

```json
{
    "rotulo": "Google Tag Manager — ID do contêiner",
    "descricao": "Identificador do contêiner do Gerenciador de Tags.",
    "campo": "texto",
    "impacto": "Preenchido, publica o contêiner e objetos de evento, além das tags diretas configuradas. Confira tags repetidas no contêiner: podem duplicar eventos. Vazio não carrega GTM nem cria seus objetos; os slots diretos permanecem independentes.",
    "exemplo": "Ilustrativo, na forma que o próprio Google usa na documentação: GTM-XXXXXXX. O valor real aparece no painel do contêiner.",
    "ajuda": {
        "funcionamento": "Adiciona o GTM aos slots diretos configurados. Não suprime GA4, Google Ads, Meta, LinkedIn ou Clarity.",
        "escolha": "Configure somente se o contêiner for necessário; confira tags e gatilhos para evitar eventos repetidos.",
        "vantagens": "Permite gestão de tags pelo contêiner autorizado.",
        "limitacoes": "O Core não controla tags independentes dentro do GTM; confira consentimento e duplicidade.",
        "exemplo": "GTM-EXEMPLO",
        "vazio": "Vazio não injeta GTM nem objetos de evento do Core para o contêiner; preserva as tags diretas."
    },
    "estrutura": []
}
```

## f3base_google_ads

```json
{
    "rotulo": "Google Ads — conversão",
    "descricao": "A conta e a ação de conversão que recebem o clique no botão de contato.",
    "campo": "grupo",
    "subcampos": {
        "conversion_id": {
            "tipo": "texto",
            "rotulo": "ID de conversão",
            "descricao": "O identificador da conta de Google Ads que recebe a conversão.",
            "impacto": "Preenchido junto com o rótulo, o clique no botão de contato passa a ser registrado como conversão na conta do Google Ads, e as campanhas passam a otimizar por ele em vez de otimizar por cliques. Faltando este campo, nenhuma conversão é enviada ao Google Ads e o investimento continua sendo decidido sem saber quem procurou contato.",
            "exemplo": "Ilustrativo, na forma que o próprio Google usa na documentação: AW-000000000. O valor real aparece na ação de conversão da conta.",
            "ajuda": {
                "funcionamento": "O identificador da conta de Google Ads que recebe a conversão.",
                "escolha": "Informe o AW- da conta de destino.",
                "vantagens": "Direciona conversões à conta correta.",
                "limitacoes": "Não identifica um anúncio individual; isso vem dos IDs/UTMs da visita.",
                "exemplo": "AW-123456789",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conversion_label": {
            "tipo": "texto",
            "rotulo": "Rótulo da conversão",
            "descricao": "A segunda metade do endereço da conversão: qual ação da conta recebe o clique.",
            "impacto": "É ele que diz QUAL ação de conversão recebe o clique. Preenchido junto com o ID, a conversão chega à ação certa. Vazio, nada é enviado: um envio sem rótulo chegaria à conta sem dizer a que ação pertence, e o relatório de campanha não teria onde somá-lo.",
            "exemplo": "Ilustrativo: rotulo-da-acao-de-conversao. O valor real é gerado pelo Google junto com a ação e aparece ao lado do ID de conversão.",
            "ajuda": {
                "funcionamento": "A segunda metade do endereço da conversão: qual ação da conta recebe o clique.",
                "escolha": "Copie o rótulo da ação de conversão escolhida na mesma conta.",
                "vantagens": "Separa a ação Contato de outras conversões da conta.",
                "limitacoes": "Rótulo incorreto pode impedir a recepção mesmo com AW- válido.",
                "exemplo": "Use o rótulo real da ação; vazio não cria uma ação automaticamente.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conteudo_conversion_label": {
            "tipo": "texto",
            "rotulo": "Rótulo da conversão de material",
            "descricao": "Ação exclusiva para material, na mesma conta AW.",
            "impacto": "Vazio ou com destino de material desligado, não envia conversão de material ao Google Ads. O rótulo de contato nunca serve de substituto.",
            "exemplo": "Rótulo da ação Material na sua conta.",
            "ajuda": {
                "funcionamento": "Vazio ou com destino de material desligado, não envia conversão de material ao Google Ads. O rótulo de contato nunca serve de substituto.",
                "escolha": "Copie o identificador/token da propriedade e conta corretas; confirme o serviço no diagnóstico antes de medir conversões.",
                "vantagens": "Centraliza a identificação e evita editar o tema a cada alteração de conta.",
                "limitacoes": "Identificador válido não comprova entrega. Evite a mesma tag simultaneamente no Core, tema e GTM. Token deve ficar restrito à administração.",
                "exemplo": "Rótulo da ação Material na sua conta.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "A conta e a ação de conversão que recebem o clique no botão de contato.",
        "escolha": "Copie o identificador/token da propriedade e conta corretas; confirme o serviço no diagnóstico antes de medir conversões.",
        "vantagens": "Centraliza a identificação e evita editar o tema a cada alteração de conta.",
        "limitacoes": "Identificador válido não comprova entrega. Evite a mesma tag simultaneamente no Core, tema e GTM. Token deve ficar restrito à administração.",
        "exemplo": "Use a conta do site e faça um envio marcado como teste; confira recebimento no serviço autorizado.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "conversion_id": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "O identificador da conta de Google Ads que recebe a conversão.",
                "escolha": "Informe o AW- da conta de destino.",
                "vantagens": "Direciona conversões à conta correta.",
                "limitacoes": "Não identifica um anúncio individual; isso vem dos IDs/UTMs da visita.",
                "exemplo": "AW-123456789",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conversion_label": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "A segunda metade do endereço da conversão: qual ação da conta recebe o clique.",
                "escolha": "Copie o rótulo da ação de conversão escolhida na mesma conta.",
                "vantagens": "Separa a ação Contato de outras conversões da conta.",
                "limitacoes": "Rótulo incorreto pode impedir a recepção mesmo com AW- válido.",
                "exemplo": "Use o rótulo real da ação; vazio não cria uma ação automaticamente.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conteudo_conversion_label": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "conteudo_conversion_label",
                "escolha": "Copie o identificador/token da propriedade e conta corretas; confirme o serviço no diagnóstico antes de medir conversões.",
                "vantagens": "Centraliza a identificação e evita editar o tema a cada alteração de conta.",
                "limitacoes": "Identificador válido não comprova entrega. Evite a mesma tag simultaneamente no Core, tema e GTM. Token deve ficar restrito à administração.",
                "exemplo": "Use a conta do site e faça um envio marcado como teste; confira recebimento no serviço autorizado.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_meta_pixel_id

```json
{
    "rotulo": "Meta — Pixel",
    "descricao": "Identificador do Pixel usado por campanhas de Facebook e Instagram.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica o Pixel da Meta e envia a ele as páginas vistas e o contato — é o que permite às campanhas de Facebook e Instagram saber o que aconteceu depois do clique no anúncio. Vazio, nenhum código da Meta existe na página e essas campanhas otimizam sem resultado de volta.",
    "exemplo": "Ilustrativo: 000000000000000 — somente dígitos. O valor real aparece no Gerenciador de Eventos da Meta.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica o Pixel da Meta e envia a ele as páginas vistas e o contato — é o que permite às campanhas de Facebook e Instagram saber o que aconteceu depois do clique no anúncio. Vazio, nenhum código da Meta existe na página e essas campanhas otimizam sem resultado de volta.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Identifica o pixel de destino para eventos e CAPI configurados.",
        "limitacoes": "ID público não é token nem prova recebimento; CAPI exige credencial separada.",
        "exemplo": "123456789012345",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    },
    "estrutura": []
}
```

## f3base_meta_capi_token

```json
{
    "rotulo": "Meta — token do envio de servidor",
    "descricao": "Credencial do conjunto de dados do Pixel, usada para enviar o contato do servidor.",
    "campo": "segredo",
    "impacto": "Preenchido, o contato passa a ser enviado também do servidor para a Meta, com o mesmo identificador de evento que o navegador manda — é essa identidade que faz os dois caminhos contarem uma conversão só, e é ela que recupera as conversões que o navegador perde por bloqueio ou por falha de rede. Vazio, existe apenas o envio pelo navegador, e o que ele perder está perdido.",
    "exemplo": "Este campo não tem exemplo de valor, porque um valor de exemplo aqui seria uma credencial. O token é gerado no Gerenciador de Eventos da Meta, nas configurações do conjunto de dados do Pixel. Ele é o único campo desta tela que nunca viaja no arquivo de configuração do pacote: é gravado só aqui, ou pelo canal de manutenção.",
    "ajuda": {
        "funcionamento": "Preenchido, o contato passa a ser enviado também do servidor para a Meta, com o mesmo identificador de evento que o navegador manda — é essa identidade que faz os dois caminhos contarem uma conversão só, e é ela que recupera as conversões que o navegador perde por bloqueio ou por falha de rede. Vazio, existe apenas o envio pelo navegador, e o que ele perder está perdido.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    },
    "estrutura": []
}
```

## f3base_linkedin_partner_id

```json
{
    "rotulo": "LinkedIn — identificador de parceiro",
    "descricao": "Identificador da conta de anúncios do LinkedIn.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica a etiqueta do LinkedIn e passa a registrar as páginas vistas por quem chega de campanhas de lá. Vazio, nenhum código do LinkedIn existe na página e as campanhas do canal ficam sem retorno de audiência.",
    "exemplo": "Ilustrativo: 0000000 — somente dígitos. O valor real aparece no Campaign Manager do LinkedIn.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica a etiqueta do LinkedIn e passa a registrar as páginas vistas por quem chega de campanhas de lá. Vazio, nenhum código do LinkedIn existe na página e as campanhas do canal ficam sem retorno de audiência.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Identifica a conta do Insight Tag.",
        "limitacoes": "Não é a ID de conversão nem autorização à Lead Sync API.",
        "exemplo": "123456",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    },
    "estrutura": []
}
```

## f3base_linkedin_conversion_id

```json
{
    "rotulo": "LinkedIn — conversão",
    "descricao": "Identificador da conversão do LinkedIn emitida após o aceite do envio pelo Core, em formulários de contato, conforme consentimento e regra de contagem. Materiais usam o ID próprio de conversão de material. O clique isolado no botão não comprova envio aceito.",
    "campo": "texto",
    "impacto": "Com o parceiro configurado e o consentimento aplicável, um envio aceito pelo Core pode emitir a conversão, em formulários de contato. Materiais usam um ID próprio. Preencher o ID não comprova recebimento nem otimização no LinkedIn. Vazio, nenhuma conversão específica é emitida.",
    "exemplo": "Ilustrativo: 00000000 — somente dígitos. O valor real é gerado ao criar a conversão no Campaign Manager do LinkedIn.",
    "ajuda": {
        "funcionamento": "Com o parceiro configurado e o consentimento aplicável, um envio aceito pelo Core pode emitir a conversão, em formulários de contato. Materiais usam um ID próprio. Preencher o ID não comprova recebimento nem otimização no LinkedIn. Vazio, nenhuma conversão específica é emitida.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Associa conversão à regra cadastrada no LinkedIn.",
        "limitacoes": "Regra e conta precisam corresponder; não importa contatos nativos.",
        "exemplo": "654321",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    },
    "estrutura": []
}
```

## f3base_atribuicao

```json
{
    "rotulo": "Origem do contato",
    "descricao": "Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.",
    "campo": "grupo",
    "subcampos": {
        "modelo": {
            "tipo": "enum",
            "rotulo": "Campanha que leva o crédito",
            "descricao": "A primeira que trouxe o visitante, ou a última antes do contato.",
            "impacto": "Escolher a primeira visita credita quem descobriu o cliente, e favorece campanhas de topo; escolher a última credita quem estava lá no momento do contato, e favorece campanhas de retomada. O relatório de cada canal muda com esta escolha, e comparar dois períodos com escolhas diferentes compara coisas diferentes.",
            "exemplo": "Ilustrativo: a primeira visita, que é o padrão deste site.",
            "opcoes": {
                "first-touch": "a primeira visita — a campanha que descobriu o cliente",
                "last-touch": "a última visita — a campanha que fechou o contato"
            },
            "ajuda": {
                "funcionamento": "Escolher a primeira visita credita quem descobriu o cliente, e favorece campanhas de topo; escolher a última credita quem estava lá no momento do contato, e favorece campanhas de retomada. O relatório de cada canal muda com esta escolha, e comparar dois períodos com escolhas diferentes compara coisas diferentes.",
                "escolha": "Sessão acompanha a navegação; primeiro toque valoriza descoberta; último toque valoriza a origem mais recente observada.",
                "vantagens": "Permite uma comparação consistente entre campanhas.",
                "limitacoes": "Mudar modelo não reescreve histórico e não prova causalidade.",
                "exemplo": "Primeiro toque: descoberta via Instagram, conversão posterior por navegação direta.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "ttl_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias a origem é lembrada",
            "descricao": "Prazo em que a origem do visitante continua guardada no navegador dele.",
            "impacto": "É a janela em que o visitante pode sumir e voltar sem perder a origem. Um prazo curto credita como direto quem voltou depois dele; um prazo longo mantém a campanha antiga levando o crédito muito depois de ela ter deixado de influenciar a decisão.",
            "exemplo": "Ilustrativo: 30, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "É a janela em que o visitante pode sumir e voltar sem perder a origem. Um prazo curto credita como direto quem voltou depois dele; um prazo longo mantém a campanha antiga levando o crédito muito depois de ela ter deixado de influenciar a decisão.",
                "escolha": "Escolha quantos dias conservar uma origem no navegador com consentimento.",
                "vantagens": "Reconhece retornos dentro da janela configurada.",
                "limitacoes": "Não é retenção do banco; bloqueio/limpeza de cookies ou outro dispositivo quebra o vínculo.",
                "exemplo": "30 dias de atribuição.",
                "vazio": "Zero é recusado quando abaixo do mínimo do schema; não significa retenção ilimitada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.",
        "escolha": "Use primeiro toque para analisar a descoberta e último toque para a campanha mais recente observada.",
        "vantagens": "Conserva a origem durante navegação interna, dentro da janela e do consentimento.",
        "limitacoes": "A janela de atribuição não é a retenção do banco. Cookie bloqueado, outra origem/dispositivo e ausência de consentimento reduzem o vínculo.",
        "exemplo": "Uma campanha de Instagram pode continuar identificada no formulário de uma página interna; não identifica a pessoa em outro dispositivo.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "ttl_dias": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ttl_dias",
                "escolha": "Escolha quantos dias conservar uma origem no navegador com consentimento.",
                "vantagens": "Reconhece retornos dentro da janela configurada.",
                "limitacoes": "Não é retenção do banco; bloqueio/limpeza de cookies ou outro dispositivo quebra o vínculo.",
                "exemplo": "30 dias de atribuição.",
                "vazio": "Zero é recusado quando abaixo do mínimo do schema; não significa retenção ilimitada."
            }
        }
    }
}
```

## f3base_verificacao_google

```json
{
    "rotulo": "Verificação de domínio — Google",
    "descricao": "Código que comprova ao Google que este domínio é seu.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica no cabeçalho a etiqueta que comprova a posse do domínio, e a propriedade do Search Console pode ser verificada — é o que destrava o relatório de busca e o envio de sitemap. Vazio, nenhuma etiqueta é publicada; a verificação por DNS continua sendo uma alternativa que dispensa este campo.",
    "exemplo": "Ilustrativo: valor-de-verificacao-do-console. O valor real é fornecido pelo Search Console ao escolher a verificação por etiqueta HTML.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica no cabeçalho a etiqueta que comprova a posse do domínio, e a propriedade do Search Console pode ser verificada — é o que destrava o relatório de busca e o envio de sitemap. Vazio, nenhuma etiqueta é publicada; a verificação por DNS continua sendo uma alternativa que dispensa este campo.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Publica a verificação HTML administrada pelo Core.",
        "limitacoes": "Não cria propriedade nem concede acesso ao Search Console.",
        "exemplo": "token-fornecido-pelo-search-console",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    },
    "estrutura": []
}
```

## f3base_verificacao_meta

```json
{
    "rotulo": "Verificação de domínio — Meta",
    "descricao": "Código que comprova à Meta que este domínio é seu.",
    "campo": "texto",
    "impacto": "Preenchido, o site publica a etiqueta que reivindica o domínio no Gerenciador de Negócios — é o que permite controlar quem pode anunciar com links deste site e configurar eventos de página. Vazio, nenhuma etiqueta é publicada e o domínio permanece sem dono declarado para a Meta.",
    "exemplo": "Ilustrativo: valor-de-verificacao-do-dominio. O valor real é fornecido pelo Gerenciador de Negócios ao reivindicar o domínio.",
    "ajuda": {
        "funcionamento": "Preenchido, o site publica a etiqueta que reivindica o domínio no Gerenciador de Negócios — é o que permite controlar quem pode anunciar com links deste site e configurar eventos de página. Vazio, nenhuma etiqueta é publicada e o domínio permanece sem dono declarado para a Meta.",
        "escolha": "Copie o identificador da conta/site corretos no serviço correspondente.",
        "vantagens": "Publica a marca de verificação do domínio.",
        "limitacoes": "Não comprova permissões de leads, pixel ou páginas.",
        "exemplo": "token-fornecido-pelo-business-manager",
        "vazio": "Vazio desconfigura esta integração direta; não remove tags instaladas pelo tema ou GTM."
    },
    "estrutura": []
}
```

## f3base_consentimento

```json
{
    "rotulo": "Consentimento",
    "descricao": "O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.",
    "campo": "grupo",
    "subcampos": {
        "padrao": {
            "tipo": "enum",
            "rotulo": "O que vale antes de o visitante decidir",
            "descricao": "A posição do site na primeira visita, antes de qualquer clique do visitante.",
            "impacto": "Em pré-aprovado, a medição começa na primeira visita e quem recusa interrompe a partir do clique: os números cobrem quase todo mundo. Em negado, nada é carregado até o aceite, e os números passam a cobrir só quem aceitou — a diferença aparece como queda de tráfego no relatório, sem que o tráfego tenha caído. A escolha é jurídica antes de ser técnica. O QUE A RECUSA TARDIA NÃO DESFAZ: ela vale do clique em diante e não apaga o que já foi enviado. Google Analytics e Google Ads recebem a recusa como atualização de consentimento e passam a operar sem armazenamento no dispositivo; o que já chegou ao Google permanece com ele. Pixel da Meta e Insight Tag do LinkedIn não têm mecanismo equivalente: se o script deles já carregou nesta página, recusar não o descarrega — ele fica ali até a navegação seguinte. O que este site garante a partir da recusa é que nenhum evento novo é enviado a eles, e que na página seguinte eles não voltam a ser carregados. Em negado nada disso chega a carregar, e é por isso que nesse modo o script de consentimento é servido bloqueando o carregamento da página: ali a ordem é a garantia, e ela custa os 5.085 bytes comprimidos desse script no caminho crítico da página.",
            "exemplo": "Ilustrativo: pré-aprovado, que é a posição deste site.",
            "opcoes": {
                "pre-aprovado": "pré-aprovado — a medição começa e o visitante pode recusar",
                "negado": "negado — nada é medido até o visitante aceitar"
            },
            "ajuda": {
                "funcionamento": "Em pré-aprovado, a medição começa na primeira visita e quem recusa interrompe a partir do clique: os números cobrem quase todo mundo. Em negado, nada é carregado até o aceite, e os números passam a cobrir só quem aceitou — a diferença aparece como queda de tráfego no relatório, sem que o tráfego tenha caído. A escolha é jurídica antes de ser técnica. O QUE A RECUSA TARDIA NÃO DESFAZ: ela vale do clique em diante e não apaga o que já foi enviado. Google Analytics e Google Ads recebem a recusa como atualização de consentimento e passam a operar sem armazenamento no dispositivo; o que já chegou ao Google permanece com ele. Pixel da Meta e Insight Tag do LinkedIn não têm mecanismo equivalente: se o script deles já carregou nesta página, recusar não o descarrega — ele fica ali até a navegação seguinte. O que este site garante a partir da recusa é que nenhum evento novo é enviado a eles, e que na página seguinte eles não voltam a ser carregados. Em negado nada disso chega a carregar, e é por isso que nesse modo o script de consentimento é servido bloqueando o carregamento da página: ali a ordem é a garantia, e ela custa os 5.085 bytes comprimidos desse script no caminho crítico da página.",
                "escolha": "Pré-aprovado ou exigir aceite afetam o estado inicial conforme a política vigente do site.",
                "vantagens": "Define comportamento antes da primeira decisão.",
                "limitacoes": "Alterar valor não é aprovação jurídica nem autoriza ampliar a coleta automaticamente.",
                "exemplo": "Exigir aceite aguarda a ação do visitante.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "controle_rodape": {
            "tipo": "booleano",
            "rotulo": "Link de revisão no rodapé",
            "descricao": "Instrumento permanente para o visitante rever a decisão dele.",
            "impacto": "Ligado, toda página ganha no rodapé um link que reabre a decisão — é o caminho pelo qual quem aceitou pode recusar depois, e a demonstração de que a escolha é reversível. Desligado, o visitante que mudar de ideia não tem por onde: a decisão dele fica presa até o prazo abaixo vencer.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Ligado, toda página ganha no rodapé um link que reabre a decisão — é o caminho pelo qual quem aceitou pode recusar depois, e a demonstração de que a escolha é reversível. Desligado, o visitante que mudar de ideia não tem por onde: a decisão dele fica presa até o prazo abaixo vencer.",
                "escolha": "Mantenha acesso persistente às preferências para consulta e revogação.",
                "vantagens": "O visitante pode mudar a escolha após fechar o painel.",
                "limitacoes": "Se desligar, o tema deve oferecer outro controle acessível.",
                "exemplo": "Preferências de privacidade no rodapé.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "aviso_primeira_visita": {
            "tipo": "booleano",
            "rotulo": "Aviso na primeira visita",
            "descricao": "Faixa não bloqueante exibida a quem chega pela primeira vez.",
            "impacto": "Ligado, quem chega pela primeira vez vê uma faixa na base da página avisando que o site mede a navegação; ela não bloqueia a leitura, não espera resposta e oferece o controle do rodapé. O link da política de privacidade aparece quando houver uma página pública válida. Desligado — que é como o site é entregue —, o único ponto de decisão visível é o link do rodapé, que está em toda página publicada. Este campo NÃO decide o que é medido: a medição segue a política de consentimento acima, e o registro por visitante nasce onde ela permite medir, com ou sem a faixa.",
            "exemplo": "Ilustrativo: desligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Ligado, quem chega pela primeira vez vê uma faixa na base da página avisando que o site mede a navegação; ela não bloqueia a leitura, não espera resposta e oferece o controle do rodapé. O link da política de privacidade aparece quando houver uma página pública válida. Desligado — que é como o site é entregue —, o único ponto de decisão visível é o link do rodapé, que está em toda página publicada. Este campo NÃO decide o que é medido: a medição segue a política de consentimento acima, e o registro por visitante nasce onde ela permite medir, com ou sem a faixa.",
                "escolha": "Ative se a política exige mostrar a explicação na entrada.",
                "vantagens": "Torna a escolha mais visível.",
                "limitacoes": "A abertura ocupa a tela; mantenha ações claras em dispositivos pequenos.",
                "exemplo": "Painel abre na primeira visita elegível.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "ttl_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias a decisão vale",
            "descricao": "Prazo em que a recusa e o novo aceite continuam guardados no navegador.",
            "impacto": "É o prazo em que a recusa continua sendo respeitada sem perguntar de novo. Vencido, o visitante volta à posição padrão do site e é medido outra vez até recusar de novo. Prazo curto pergunta demais; prazo longo mantém a decisão por mais tempo do que ela costuma ser lembrada.",
            "exemplo": "Ilustrativo: 180, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "É o prazo em que a recusa continua sendo respeitada sem perguntar de novo. Vencido, o visitante volta à posição padrão do site e é medido outra vez até recusar de novo. Prazo curto pergunta demais; prazo longo mantém a decisão por mais tempo do que ela costuma ser lembrada.",
                "escolha": "Defina por quanto tempo lembrar a escolha de consentimento.",
                "vantagens": "Evita repetir a pergunta a cada página.",
                "limitacoes": "Outra versão de política pode exigir nova decisão; o prazo não substitui revogação.",
                "exemplo": "180 dias de escolha lembrada.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "modo": {
            "tipo": "enum",
            "rotulo": "Modo de consentimento",
            "descricao": "Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.",
            "impacto": "Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.",
            "exemplo": "Granular mediante mudança explícita.",
            "opcoes": {
                "legado": "Legado",
                "granular": "Por categoria"
            },
            "ajuda": {
                "funcionamento": "Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.",
                "escolha": "Legado preserva a política única; por categorias separa medição e publicidade.",
                "vantagens": "Expõe escolhas distintas ao visitante.",
                "limitacoes": "Tags fora do Core precisam respeitar as mesmas categorias.",
                "exemplo": "Recusar publicidade mantém formulário funcional.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "politica_versao": {
            "tipo": "texto",
            "rotulo": "Versão da política",
            "descricao": "Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.",
            "impacto": "Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.",
            "exemplo": "1",
            "ajuda": {
                "funcionamento": "Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.",
                "escolha": "Troque a versão ao mudar materialmente as finalidades e o texto aprovado.",
                "vantagens": "Permite distinguir decisões de políticas diferentes.",
                "limitacoes": "Trocar a cada atualização causaria novas solicitações desnecessárias.",
                "exemplo": "2026-09",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            },
            "estrutura": []
        },
        "publicidade_politica": {
            "tipo": "enum",
            "rotulo": "Política de publicidade",
            "descricao": "Pré-autorizar permite tags e retorno de conversões quando não há negativa explícita. Exigir decisão restringe a publicidade até uma decisão comprovada. Medição e histórico de navegação continuam independentes. A política não representa consentimento individual e não reenvia conversões antigas.",
            "impacto": "Pré-autorizar permite tags e retorno de conversões quando não há negativa explícita. Exigir decisão restringe a publicidade até uma decisão comprovada. Medição e histórico de navegação continuam independentes. A política não representa consentimento individual e não reenvia conversões antigas.",
            "exemplo": "Pré-autorizada nesta instalação; qualquer negativa prevalece.",
            "opcoes": {
                "pre_autorizada": "Pré-autorizada pela política do site",
                "exigir_decisao": "Exigir decisão individual"
            },
            "ajuda": {
                "funcionamento": "Pré-autorizar permite tags e retorno de conversões quando não há negativa explícita. Exigir decisão restringe a publicidade até uma decisão comprovada. Medição e histórico de navegação continuam independentes. A política não representa consentimento individual e não reenvia conversões antigas.",
                "escolha": "Escolha o regime conforme a política aprovada do site e teste aceitar, recusar e revogar cada categoria.",
                "vantagens": "Mantém a decisão do visitante separada da captura funcional do formulário.",
                "limitacoes": "Revogar interrompe novos envios controlados pelo Core. Tags instaladas pelo tema ou pelo GTM exigem configuração correspondente.",
                "exemplo": "Pré-autorizada nesta instalação; qualquer negativa prevalece.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": []
        },
        "gtm_separacao_verificada": {
            "tipo": "booleano",
            "rotulo": "Contêiner GTM respeita as categorias",
            "descricao": "Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.",
            "impacto": "Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.",
            "exemplo": "Desmarcado até verificar o contêiner.",
            "ajuda": {
                "funcionamento": "Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.",
                "escolha": "Marque apenas depois de testar a separação de tags por categoria no GTM.",
                "vantagens": "Registra uma pré-condição operacional para o contêiner.",
                "limitacoes": "É declaração do operador; não inspeciona automaticamente todas as tags do GTM.",
                "exemplo": "Teste recusa de publicidade antes de marcar.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "painel": {
            "tipo": "enum",
            "rotulo": "Apresentação do painel de consentimento",
            "descricao": "Padrão oferece estilos completos. Tema herda o desenho do site: exige CSS, contraste, foco e navegação por teclado adequados.",
            "impacto": "O modo tema não muda consentimento nem categorias.",
            "exemplo": "Use tema apenas com estilos conferidos em celular e teclado.",
            "opcoes": {
                "padrao": "Padrão do plugin",
                "tema": "Estilo fornecido pelo tema"
            },
            "ajuda": {
                "funcionamento": "O modo tema não muda consentimento nem categorias.",
                "escolha": "Escolha o regime conforme a política aprovada do site e teste aceitar, recusar e revogar cada categoria.",
                "vantagens": "Mantém a decisão do visitante separada da captura funcional do formulário.",
                "limitacoes": "Revogar interrompe novos envios controlados pelo Core. Tags instaladas pelo tema ou pelo GTM exigem configuração correspondente.",
                "exemplo": "Use tema apenas com estilos conferidos em celular e teclado.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.",
        "escolha": "Escolha o regime conforme a política aprovada do site e teste aceitar, recusar e revogar cada categoria.",
        "vantagens": "Mantém a decisão do visitante separada da captura funcional do formulário.",
        "limitacoes": "Revogar interrompe novos envios controlados pelo Core. Tags instaladas pelo tema ou pelo GTM exigem configuração correspondente.",
        "exemplo": "Em modo por categorias, recusar publicidade impede Pixel/Ads mesmo quando medição estiver permitida.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "ttl_dias": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ttl_dias",
                "escolha": "Defina por quanto tempo lembrar a escolha de consentimento.",
                "vantagens": "Evita repetir a pergunta a cada página.",
                "limitacoes": "Outra versão de política pode exigir nova decisão; o prazo não substitui revogação.",
                "exemplo": "180 dias de escolha lembrada.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "painel": {
            "tipo": "string",
            "padrao": "padrao",
            "ajuda": {
                "funcionamento": "painel",
                "escolha": "Escolha o regime conforme a política aprovada do site e teste aceitar, recusar e revogar cada categoria.",
                "vantagens": "Mantém a decisão do visitante separada da captura funcional do formulário.",
                "limitacoes": "Revogar interrompe novos envios controlados pelo Core. Tags instaladas pelo tema ou pelo GTM exigem configuração correspondente.",
                "exemplo": "Em modo por categorias, recusar publicidade impede Pixel/Ads mesmo quando medição estiver permitida.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_retencao_meses

```json
{
    "rotulo": "Guarda dos contatos recebidos (meses)",
    "descricao": "Por quanto tempo os registros de contato ficam no site antes da limpeza automática.",
    "campo": "inteiro",
    "impacto": "É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira e depois é eliminado, com o número de registros anotado. Um prazo longo mantém disponível o histórico comercial e mantém dado pessoal guardado por mais tempo do que a finalidade justifica; um prazo curto faz o contrário. O prazo declarado aqui governa a limpeza mesmo quando o site não tem uma página de política de privacidade. ZERO NÃO É ACEITO e não vira nada: a gravação é RECUSADA e o prazo anterior continua valendo — o mínimo é um mês.",
    "exemplo": "Ilustrativo: 12, o prazo que este site usa por padrão.",
    "ajuda": {
        "funcionamento": "É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira e depois é eliminado, com o número de registros anotado. Um prazo longo mantém disponível o histórico comercial e mantém dado pessoal guardado por mais tempo do que a finalidade justifica; um prazo curto faz o contrário. O prazo declarado aqui governa a limpeza mesmo quando o site não tem uma página de política de privacidade. ZERO NÃO É ACEITO e não vira nada: a gravação é RECUSADA e o prazo anterior continua valendo — o mínimo é um mês.",
        "escolha": "Defina por quanto tempo a operação precisa manter contatos, considerando também as retenções próprias de eventos e logs.",
        "vantagens": "Limita crescimento e acúmulo de dados pessoais antigos.",
        "limitacoes": "Dados eliminados pelo processo de retenção deixam de participar das análises; exportações externas têm sua própria gestão.",
        "exemplo": "Ilustrativo: 12, o prazo que este site usa por padrão.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_acessos

```json
{
    "rotulo": "Acessos do servidor",
    "descricao": "Contagem dos logs fechados em Medição → Acessos.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Somar acessos do servidor",
            "descricao": "Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.",
            "impacto": "Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.",
            "exemplo": "Ligado.",
            "ajuda": {
                "funcionamento": "Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.",
                "escolha": "Ative para somar os logs deste site.",
                "vantagens": "Inclui robôs e respostas que não executam JavaScript.",
                "limitacoes": "Exige arquivo legível pelo PHP e executor periódico.",
                "exemplo": "Desligar preserva os agregados anteriores.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "padrao_do_log": {
            "tipo": "texto",
            "rotulo": "Padrão dos arquivos de log",
            "descricao": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
            "impacto": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
            "exemplo": "~/logs/exemplo.com.br/https/access.log.*",
            "ajuda": {
                "funcionamento": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
                "escolha": "Use o diretório exclusivo deste domínio, com arquivos datados.",
                "vantagens": "Permite retomada e substituição idempotente da contribuição por arquivo.",
                "limitacoes": "Diretório de vários domínios mistura tráfego; o Core o recusa quando detectável.",
                "exemplo": "/caminho/deste-site/access.log.*",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "caminhos_excluidos": {
            "tipo": "lista",
            "rotulo": "Prefixos excluídos do detalhe",
            "descricao": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
            "impacto": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
            "exemplo": "/wp-admin/, /wp-json/mcp/",
            "ajuda": {
                "funcionamento": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
                "escolha": "Exclua prefixos privados ou estritamente técnicos.",
                "vantagens": "Reduz exposição de caminhos que contenham identificadores pessoais.",
                "limitacoes": "As contagens excluídas não têm detalhe por URL; reclassificação exige logs disponíveis.",
                "exemplo": "/wp-admin/; lista vazia é preservada.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "retencao_horaria_dias": {
            "tipo": "inteiro",
            "rotulo": "Retenção horária de agentes em dias",
            "descricao": "Mantém contagens por hora UTC de 1 a 90 dias, dentro da retenção diária. Padrão de 30 dias. Não guarda IP nem User-Agent bruto.",
            "impacto": "Permite comparar horários de busca; aumenta o agregado armazenado.",
            "exemplo": "30 dias",
            "ajuda": {
                "funcionamento": "Permite comparar horários de busca; aumenta o agregado armazenado.",
                "escolha": "Use 30 dias como janela inicial para comparar horários de agentes.",
                "vantagens": "Permite observar concentração de requisições por hora UTC.",
                "limitacoes": "Agregado não guarda caminho ou método nessa granularidade; máximo de 90 dias.",
                "exemplo": "30 dias de horas e 25 meses de resumo diário.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "retencao_meses": {
            "tipo": "inteiro",
            "rotulo": "Retenção do agregado em meses",
            "descricao": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
            "impacto": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
            "exemplo": "25 meses.",
            "ajuda": {
                "funcionamento": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
                "escolha": "Escolha o horizonte de comparações do agregado diário.",
                "vantagens": "Reduz crescimento do banco mantendo histórico útil.",
                "limitacoes": "Prazo menor elimina agregados antigos; não altera a retenção do host.",
                "exemplo": "6 mantém aproximadamente seis meses de agregados.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "padroes_hospedagem": {
            "tipo": "lista",
            "rotulo": "Marcadores de agentes da hospedagem",
            "descricao": "Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.",
            "impacto": "Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.",
            "exemplo": "Use somente marcadores confirmados nos logs.",
            "ajuda": {
                "funcionamento": "Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.",
                "escolha": "Informe marcas literais conhecidas do User-Agent da hospedagem.",
                "vantagens": "Separa sondas da hospedagem dos buscadores.",
                "limitacoes": "Marca declarada não autentica o operador; não use texto genérico como bot.",
                "exemplo": "Um marcador documentado pelo provedor, por linha.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            },
            "estrutura": {
                "itens": []
            }
        }
    },
    "ajuda": {
        "funcionamento": "Contagem dos logs fechados em Medição → Acessos.",
        "escolha": "Informe somente logs deste site que o PHP pode ler e exclusões deliberadas de caminhos técnicos.",
        "vantagens": "Permite analisar respostas HTTP, robôs e 404 mesmo sem executar JavaScript.",
        "limitacoes": "Requisições não equivalem a sessões. O log comum não contém o cookie de teste; exclusões e regras de classificação mudam a comparação histórica.",
        "exemplo": "Uma lista de exclusões vazia conserva todos os caminhos elegíveis; a atualização não a substitui.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "padrao_do_log": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.",
                "escolha": "Use o diretório exclusivo deste domínio, com arquivos datados.",
                "vantagens": "Permite retomada e substituição idempotente da contribuição por arquivo.",
                "limitacoes": "Diretório de vários domínios mistura tráfego; o Core o recusa quando detectável.",
                "exemplo": "/caminho/deste-site/access.log.*",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "caminhos_excluidos": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.",
                "escolha": "Exclua prefixos privados ou estritamente técnicos.",
                "vantagens": "Reduz exposição de caminhos que contenham identificadores pessoais.",
                "limitacoes": "As contagens excluídas não têm detalhe por URL; reclassificação exige logs disponíveis.",
                "exemplo": "/wp-admin/; lista vazia é preservada.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "retencao_meses": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.",
                "escolha": "Escolha o horizonte de comparações do agregado diário.",
                "vantagens": "Reduz crescimento do banco mantendo histórico útil.",
                "limitacoes": "Prazo menor elimina agregados antigos; não altera a retenção do host.",
                "exemplo": "6 mantém aproximadamente seis meses de agregados.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "retencao_horaria_dias": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "retencao_horaria_dias",
                "escolha": "Use 30 dias como janela inicial para comparar horários de agentes.",
                "vantagens": "Permite observar concentração de requisições por hora UTC.",
                "limitacoes": "Agregado não guarda caminho ou método nessa granularidade; máximo de 90 dias.",
                "exemplo": "30 dias de horas e 25 meses de resumo diário.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    }
}
```

## f3base_sessao

```json
{
    "rotulo": "Sessão de login",
    "descricao": "Prazo dos novos logins pelo formulário nativo. O diagnóstico informa o valor efetivo.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Manter login ao fechar o navegador",
            "descricao": "Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.",
            "impacto": "Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.",
            "exemplo": "Ligado.",
            "ajuda": {
                "funcionamento": "Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.",
                "escolha": "Ative quando a equipe deve continuar autenticada ao reabrir o navegador.",
                "vantagens": "Evita autenticações repetidas de usuários autorizados.",
                "limitacoes": "Maior persistência exige cuidado em computadores compartilhados; não revoga sessões existentes.",
                "exemplo": "Desligar afeta novos logins, não a sessão analítica do visitante.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "dias": {
            "tipo": "inteiro",
            "rotulo": "Duração das novas sessões em dias",
            "descricao": "Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.",
            "impacto": "Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.",
            "exemplo": "90 dias.",
            "ajuda": {
                "funcionamento": "Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.",
                "escolha": "Escolha o prazo de autenticação WordPress conforme o uso e o risco.",
                "vantagens": "Evita exigir login frequente da equipe.",
                "limitacoes": "Prazo longo expõe sessões em computadores compartilhados; não trata sessão analítica.",
                "exemplo": "14 dias de login.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "modo": {
            "tipo": "enum",
            "rotulo": "Política das sessões",
            "descricao": "Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.",
            "impacto": "Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.",
            "exemplo": "Por perfil após revisar as regras.",
            "opcoes": {
                "legado": "Legado",
                "por-perfil": "Por papel ou capacidade"
            },
            "ajuda": {
                "funcionamento": "Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.",
                "escolha": "Escolha prazo único ou regras por perfil/capacidade.",
                "vantagens": "Por perfil permite um prazo menor para funções sensíveis.",
                "limitacoes": "Regras sobrepostas usam a mais restritiva; a opção não muda senhas ou permissões.",
                "exemplo": "Uma regra de administradores pode usar prazo menor que a dos editores.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "regras": {
            "tipo": "json",
            "rotulo": "Regras de duração por perfil",
            "descricao": "Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.",
            "impacto": "Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.",
            "exemplo": "[{\"papel\":\"editor\",\"capacidade\":\"\",\"dias\":14,\"nucleo\":false}]",
            "ajuda": {
                "funcionamento": "Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.",
                "escolha": "Use papel/capacidade e duração para grupos que realmente precisam de exceção.",
                "vantagens": "A regra mais restritiva prevalece quando há sobreposição.",
                "limitacoes": "Altera novas sessões; não amplia permissões de usuário.",
                "exemplo": "Administradores com prazo menor que editores.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            },
            "estrutura": {
                "itens": {
                    "papel": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "papel",
                            "escolha": "Escolha a duração de autenticação adequada a cada papel/capacidade e considere computadores compartilhados.",
                            "vantagens": "Permite manter sessões de editores sem aplicar o mesmo prazo a todos os usuários.",
                            "limitacoes": "Esta opção trata login WordPress, não o identificador de sessão analítica dos visitantes. Prazo longo aumenta exposição em equipamentos perdidos.",
                            "exemplo": "Uma regra de administrador pode conservar o prazo do núcleo enquanto assinantes usam prazo próprio.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "capacidade": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "capacidade",
                            "escolha": "Escolha a duração de autenticação adequada a cada papel/capacidade e considere computadores compartilhados.",
                            "vantagens": "Permite manter sessões de editores sem aplicar o mesmo prazo a todos os usuários.",
                            "limitacoes": "Esta opção trata login WordPress, não o identificador de sessão analítica dos visitantes. Prazo longo aumenta exposição em equipamentos perdidos.",
                            "exemplo": "Uma regra de administrador pode conservar o prazo do núcleo enquanto assinantes usam prazo próprio.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "dias": {
                        "tipo": "integer",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "dias",
                            "escolha": "Escolha a duração de autenticação adequada a cada papel/capacidade e considere computadores compartilhados.",
                            "vantagens": "Permite manter sessões de editores sem aplicar o mesmo prazo a todos os usuários.",
                            "limitacoes": "Esta opção trata login WordPress, não o identificador de sessão analítica dos visitantes. Prazo longo aumenta exposição em equipamentos perdidos.",
                            "exemplo": "Uma regra de administrador pode conservar o prazo do núcleo enquanto assinantes usam prazo próprio.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "nucleo": {
                        "tipo": "boolean",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nucleo",
                            "escolha": "Escolha a duração de autenticação adequada a cada papel/capacidade e considere computadores compartilhados.",
                            "vantagens": "Permite manter sessões de editores sem aplicar o mesmo prazo a todos os usuários.",
                            "limitacoes": "Esta opção trata login WordPress, não o identificador de sessão analítica dos visitantes. Prazo longo aumenta exposição em equipamentos perdidos.",
                            "exemplo": "Uma regra de administrador pode conservar o prazo do núcleo enquanto assinantes usam prazo próprio.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    }
                }
            }
        }
    },
    "ajuda": {
        "funcionamento": "Prazo dos novos logins pelo formulário nativo. O diagnóstico informa o valor efetivo.",
        "escolha": "Escolha a duração de autenticação adequada a cada papel/capacidade e considere computadores compartilhados.",
        "vantagens": "Permite manter sessões de editores sem aplicar o mesmo prazo a todos os usuários.",
        "limitacoes": "Esta opção trata login WordPress, não o identificador de sessão analítica dos visitantes. Prazo longo aumenta exposição em equipamentos perdidos.",
        "exemplo": "Uma regra de administrador pode conservar o prazo do núcleo enquanto assinantes usam prazo próprio.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "dias": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "dias",
                "escolha": "Escolha o prazo de autenticação WordPress conforme o uso e o risco.",
                "vantagens": "Evita exigir login frequente da equipe.",
                "limitacoes": "Prazo longo expõe sessões em computadores compartilhados; não trata sessão analítica.",
                "exemplo": "14 dias de login.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    }
}
```

## f3base_comportamento

```json
{
    "rotulo": "Resumo de comportamento no próprio site",
    "descricao": "O resumo que o site guarda por conta própria sobre como as páginas são usadas.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Guardar o resumo no site",
            "descricao": "O resumo é somado por dia e por página, sem identificar visitante.",
            "impacto": "Ligado, ao sair de cada página o navegador envia uma vez os totais daquela visita — marcos de rolagem, seções vistas, cliques para fora, sinais de dificuldade, erros e tempo de carregamento — e o site os soma na linha do dia. É o que faz o quadro desta tela ter números sem depender de conta nenhuma de fornecedor. Desligado, nada é enviado nem guardado, e o quadro fica permanentemente vazio; o envio ao Google Analytics, quando configurado, não muda.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "O resumo é somado por dia e por página, sem identificar visitante.",
                "escolha": "Ative para observar interações consentidas no próprio site.",
                "vantagens": "Relaciona páginas e ações a sessões e formulários.",
                "limitacoes": "Bloqueios, recusa e saída abrupta reduzem cobertura; contagem não equivale a pessoas.",
                "exemplo": "Desativar interrompe novas coletas, preservando a retenção já definida.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "retencao_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias o resumo é guardado",
            "descricao": "Prazo depois do qual as linhas antigas do resumo são apagadas pela limpeza automática.",
            "impacto": "A limpeza que já roda no site apaga as linhas mais antigas que este prazo. Um prazo maior permite comparar períodos distantes e faz a tabela crescer; um prazo menor mantém a tabela pequena e impede a comparação com o mesmo mês do ano passado. Este quadro não é arquivo histórico: quem precisa de série longa a tem no Google Analytics.",
            "exemplo": "Ilustrativo: 90, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "Prazo de conservação dos resumos de comportamento.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "365 conserva um ano de dados elegíveis; reduzir afeta a próxima retenção.",
                "vazio": "Ausente usa 365; valor explícito válido é preservado.",
                "padrao": "365"
            }
        },
        "retencao_eventos_dias": {
            "tipo": "inteiro",
            "rotulo": "Por quantos dias o registro detalhado é guardado",
            "descricao": "Prazo do registro que guarda visitante, sessão e horário de cada acontecimento — mais curto que o do resumo, e nunca maior.",
            "impacto": "O site guarda duas coisas diferentes. O RESUMO soma por dia e por página e não identifica ninguém; o REGISTRO DETALHADO guarda, para cada acontecimento, um apelido sorteado do navegador do visitante, o identificador da visita e o horário com precisão de milésimo — é ele que responde quanto tempo a pessoa levou para descer a página e se ela voltou e leu de novo. Por guardar isso, ele é dado pessoal, ainda que o apelido não diga quem a pessoa é: o padrão é 365 dias e nunca pode passar o prazo do resumo; ampliar aumenta o histórico e o volume de dados pessoais conservados, reduzir limita a análise e apaga o que vencer. Vencido o prazo, as linhas detalhadas são apagadas pela mesma limpeza automática e o resumo continua, porque ele não identifica ninguém.",
            "exemplo": "Ilustrativo: 30, o prazo que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "Prazo de conservação dos eventos detalhados de comportamento. Reduzir limita a reconstrução de jornadas.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "365 conserva um ano de dados elegíveis; reduzir afeta a próxima retenção.",
                "vazio": "Ausente usa 365; valor explícito válido é preservado.",
                "padrao": "365"
            }
        },
        "dias_no_painel": {
            "tipo": "inteiro",
            "rotulo": "Período mostrado no quadro",
            "descricao": "Quantos dias o quadro desta tela soma ao exibir os números.",
            "impacto": "Muda apenas o que esta tela mostra, nunca o que é guardado. Um período curto revela o efeito de uma mudança recente; um período longo dilui o dia atípico e mostra a tendência. O número aparece ao lado de cada total, para que ninguém leia o quadro sem saber de quantos dias ele fala. O TETO DELE É O PRAZO DO RESUMO, o campo duas linhas acima — e os quadros que vêm do REGISTRO DETALHADO cobrem o prazo DELE, que é o campo logo acima e é sempre menor ou igual: pedir aqui mais dias do que o registro guarda continua valendo para a série do agregado, e a tela Medição avisa quando os dois períodos divergem.",
            "exemplo": "Ilustrativo: 28, o período que este site usa por padrão.",
            "ajuda": {
                "funcionamento": "Muda apenas o que esta tela mostra, nunca o que é guardado. Um período curto revela o efeito de uma mudança recente; um período longo dilui o dia atípico e mostra a tendência. O número aparece ao lado de cada total, para que ninguém leia o quadro sem saber de quantos dias ele fala. O TETO DELE É O PRAZO DO RESUMO, o campo duas linhas acima — e os quadros que vêm do REGISTRO DETALHADO cobrem o prazo DELE, que é o campo logo acima e é sempre menor ou igual: pedir aqui mais dias do que o registro guarda continua valendo para a série do agregado, e a tela Medição avisa quando os dois períodos divergem.",
                "escolha": "Escolha a janela inicial usada no painel de comportamento.",
                "vantagens": "Foca a leitura no período operacional relevante.",
                "limitacoes": "Não muda retenção nem coleta; período sem dados permanece indisponível.",
                "exemplo": "Últimos 30 dias.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "tempo_ativo": {
            "tipo": "booleano",
            "rotulo": "Estimar tempo ativo por bloco",
            "descricao": "Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.",
            "impacto": "Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.",
            "exemplo": "Ligado em instalações novas; a escolha já gravada é preservada.",
            "ajuda": {
                "funcionamento": "Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.",
                "escolha": "Ative para medir intervalos de atividade observada com consentimento.",
                "vantagens": "Acrescenta contexto às páginas e jornadas.",
                "limitacoes": "Tempo ativo estimado não comprova leitura ou atenção.",
                "exemplo": "Uma aba oculta deixa de acumular tempo ativo.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "O resumo que o site guarda por conta própria sobre como as páginas são usadas.",
        "escolha": "Ajuste coleta e retenções ao período que precisa analisar, conferindo o tamanho do banco e a cobertura.",
        "vantagens": "Permite relacionar seções, formulários, erros e métricas a sessões observadas no próprio site.",
        "limitacoes": "Tempo ativo é estimado. Retenção detalhada menor que o período consultado reduz a jornada; contagens não são pessoas identificadas.",
        "exemplo": "O padrão conserva eventos e resumos por 365 dias; reduzir a retenção pode deixar períodos antigos sem a jornada detalhada.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "retencao_dias": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Prazo de conservação dos resumos de comportamento.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "365 conserva um ano de dados elegíveis; reduzir afeta a próxima retenção.",
                "vazio": "Ausente usa 365; valor explícito válido é preservado.",
                "padrao": "365"
            }
        },
        "retencao_eventos_dias": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Prazo de conservação dos eventos detalhados de comportamento. Reduzir limita a reconstrução de jornadas.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "365 conserva um ano de dados elegíveis; reduzir afeta a próxima retenção.",
                "vazio": "Ausente usa 365; valor explícito válido é preservado.",
                "padrao": "365"
            }
        },
        "dias_no_painel": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "dias_no_painel",
                "escolha": "Escolha a janela inicial usada no painel de comportamento.",
                "vantagens": "Foca a leitura no período operacional relevante.",
                "limitacoes": "Não muda retenção nem coleta; período sem dados permanece indisponível.",
                "exemplo": "Últimos 30 dias.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    }
}
```

## f3base_origem_confiavel

```json
{
    "rotulo": "Como o site descobre o endereço do visitante",
    "descricao": "Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.",
    "campo": "grupo",
    "subcampos": {
        "cabecalho": {
            "tipo": "texto",
            "rotulo": "Cabeçalho em que este site confia",
            "descricao": "Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.",
            "impacto": "Preenchido, o limite de envios por visitante passa a contar cada visitante separadamente mesmo atrás de CDN. Vazio — que é o padrão e é a posição segura —, o site conta pelo endereço da conexão: atrás de CDN esse endereço é o mesmo para todo mundo, e um único visitante intenso pode esgotar o limite do site inteiro. Preencher com o nome errado é pior que deixar vazio: o visitante passaria a escolher em que balde ele conta.",
            "exemplo": "Ilustrativo: X-Forwarded-For, ou CF-Connecting-IP em sites atrás da Cloudflare. Só preencha o cabeçalho que a sua hospedagem confirmar.",
            "ajuda": {
                "funcionamento": "Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.",
                "escolha": "Selecione apenas o cabeçalho documentado pelo proxy que está diante deste site.",
                "vantagens": "Permite aplicar cotas ao endereço recebido pelo proxy confiável.",
                "limitacoes": "Confiar em cabeçalho enviado diretamente pelo visitante permite falsificação.",
                "exemplo": "Vazio mantém REMOTE_ADDR.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "saltos": {
            "tipo": "inteiro",
            "rotulo": "Em que posição da lista está o endereço do visitante",
            "descricao": "Usado apenas quando o cabeçalho acima está preenchido.",
            "impacto": "É a POSIÇÃO contada do fim da lista do cabeçalho: 1 é o último elemento, que é o único escrito pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.",
            "exemplo": "Ilustrativo: 1, quando há uma única CDN na frente do site.",
            "ajuda": {
                "funcionamento": "É a POSIÇÃO contada do fim da lista do cabeçalho: 1 é o último elemento, que é o único escrito pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.",
                "escolha": "Informe a quantidade de proxies confirmados entre visitante e WordPress.",
                "vantagens": "Seleciona a posição correta no cabeçalho de origem.",
                "limitacoes": "Número errado permite atribuir IP do proxy ou valor falsificado.",
                "exemplo": "Um proxy documentado: um salto.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "redes_confiaveis": {
            "tipo": "lista",
            "rotulo": "De quais endereços os seus proxies falam com o site",
            "descricao": "Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.",
            "impacto": "Preenchidas, só o pedido que chega de uma dessas faixas tem o cabeçalho acima lido; os outros voltam a contar pelo endereço da conexão. VAZIAS — que é como o site é entregue —, o cabeçalho acima é lido de QUALQUER conexão, e a tela emite um aviso apontando este campo: cabeçalho é texto que qualquer cliente manda, e quem alcança o servidor por fora da CDN escolhe em que balde do limite ele conta e qual endereço o site envia aos fornecedores de anúncio. É esta lista que fecha essa porta, e ela só é fechada por quem declara as faixas.",
            "exemplo": "Ilustrativo: 198.51.100.0/24 numa linha e 203.0.113.7 na outra. Só declare faixa que a sua hospedagem confirmar.",
            "ajuda": {
                "funcionamento": "Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.",
                "escolha": "Cadastre somente redes verificadas da CDN/proxy.",
                "vantagens": "Restringe quem pode fornecer o cabeçalho de origem.",
                "limitacoes": "Faixas amplas aceitam origens não controladas; manter a lista requer operação.",
                "exemplo": "192.0.2.0/24 ilustra CIDR; não é uma rede real do seu proxy.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.",
        "escolha": "Preencha somente quando a hospedagem documentar o proxy, o cabeçalho e suas redes confiáveis.",
        "vantagens": "Recupera o endereço de origem para cotas e diagnóstico quando existe um proxy comprovado.",
        "limitacoes": "Confiar em cabeçalho enviado pelo visitante permite falsificar a origem. Não use esta opção para excluir testes por IP e horário.",
        "exemplo": "Sem proxy confirmado, deixe cabeçalho e redes vazios e utilize REMOTE_ADDR.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "saltos": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "saltos",
                "escolha": "Informe a quantidade de proxies confirmados entre visitante e WordPress.",
                "vantagens": "Seleciona a posição correta no cabeçalho de origem.",
                "limitacoes": "Número errado permite atribuir IP do proxy ou valor falsificado.",
                "exemplo": "Um proxy documentado: um salto.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "redes_confiaveis": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.",
                "escolha": "Cadastre somente redes verificadas da CDN/proxy.",
                "vantagens": "Restringe quem pode fornecer o cabeçalho de origem.",
                "limitacoes": "Faixas amplas aceitam origens não controladas; manter a lista requer operação.",
                "exemplo": "192.0.2.0/24 ilustra CIDR; não é uma rede real do seu proxy.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        }
    }
}
```

## f3base_robots

```json
{
    "rotulo": "Robots.txt do plugin",
    "descricao": "Alterna entre o gerador do plugin e o arquivo físico original, com backup e restauração.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Utilizar o robots.txt do plugin",
            "descricao": "Ligado, guarda o original e verifica a entrega pública. Se a hospedagem interceptar a rota virtual, mantém um arquivo físico gerenciado e atualizado automaticamente.",
            "impacto": "Publica as regras do WordPress e dos plugins, com o sitemap disponível. O WP-Cron confirma a resposta HTTP e atualiza o arquivo gerenciado a cada hora e após mudanças reconhecidas de configuração. Desligado, retira somente o arquivo que ainda corresponde ao conteúdo gerado e restaura o original. Edições externas são preservadas. Sem original anterior, não cria um ao desligar. O diagnóstico informa falhas, conflitos e verificações pendentes.",
            "exemplo": "Ilustrativo: ligado, com o sitemap do núcleo ou do plugin de SEO.",
            "ajuda": {
                "funcionamento": "Ligado, guarda o original e verifica a entrega pública. Se a hospedagem interceptar a rota virtual, mantém um arquivo físico gerenciado e atualizado automaticamente.",
                "escolha": "Ative quando o Core for responsável pela política robots deste site.",
                "vantagens": "Mantém a política e uma reserva recuperável do original.",
                "limitacoes": "Não restringe acesso privado e não obriga bots a obedecer.",
                "exemplo": "A reserva reconhecida fica na pasta privada do Core.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Alterna entre o gerador do plugin e o arquivo físico original, com backup e restauração.",
        "escolha": "Mantenha um único responsável pelo robots.txt e confira a resposta pública após reconciliar.",
        "vantagens": "Centraliza regras do site e respeita arquivo de propriedade externa.",
        "limitacoes": "robots.txt não protege informação privada nem obriga um robô a cumprir a instrução. Proteger documentos exige regra de acesso do servidor.",
        "exemplo": "Uma documentação bloqueada por Require all denied continua protegida mesmo se o robô ignorar robots.txt.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_llms

```json
{
    "rotulo": "Arquivo llms.txt para leitores automáticos",
    "descricao": "Índice curto que apresenta o site a assistentes e agentes que o leem.",
    "campo": "grupo",
    "subcampos": {
        "ligado": {
            "tipo": "booleano",
            "rotulo": "Publicar o llms.txt",
            "descricao": "Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.",
            "impacto": "Ligado, o endereço /llms.txt passa a responder com um índice curto das páginas escolhidas — oferece contexto e links aos assistentes que consultam esse arquivo, sem garantir uso ou citação. Desligado, o endereço deixa de responder e a leitura automática volta a depender de rastreamento comum. Um arquivo físico na raiz do site sempre tem precedência sobre esta chave.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.",
                "escolha": "Ative para publicar o índice dos conteúdos públicos elegíveis.",
                "vantagens": "Oferece um ponto de descoberta em texto.",
                "limitacoes": "Não garante leitura nem citação por IA; depende da publicação da geração.",
                "exemplo": "Confira /llms.txt e o diagnóstico de entrega.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "introducao": {
            "tipo": "textarea",
            "rotulo": "Primeira frase do arquivo",
            "descricao": "Uma linha dizendo do que este site trata.",
            "impacto": "Preenchida, é a primeira frase que um leitor automático encontra, e ela resume o contexto do site. Vazia, o site usa a apresentação abaixo e, se ela também estiver vazia, a descrição cadastrada nas configurações gerais do WordPress — que serve, mas foi escrita para outra finalidade.",
            "exemplo": "Ilustrativo: \"Consultoria de operações para indústrias de médio porte, com atendimento em todo o país.\"",
            "ajuda": {
                "funcionamento": "Uma linha dizendo do que este site trata.",
                "escolha": "Escreva uma frase factual curta sobre o site.",
                "vantagens": "Dá contexto imediato ao leitor do índice.",
                "limitacoes": "Texto promocional impreciso também será publicado.",
                "exemplo": "Consultoria de tecnologia para empresas em crescimento.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "apresentacao": {
            "tipo": "textarea",
            "rotulo": "Apresentação do negócio",
            "descricao": "Um parágrafo dizendo o que o site é, para quem e com que oferta.",
            "impacto": "Descreve o site antes da lista de links quando o campo acima está vazio. Com a primeira frase preenchida, é ELA que sai, e este parágrafo fica de reserva; com os dois vazios, o arquivo usa a descrição cadastrada no WordPress. O texto oferece contexto ao leitor, sem garantir citações ou presença em respostas de assistentes.",
            "exemplo": "Ilustrativo: \"Somos uma consultoria de operações industriais para fábricas de 50 a 500 funcionários. Fazemos diagnóstico de linha, redesenho de processo e acompanhamento de indicadores, com contrato mensal e equipe em campo.\"",
            "ajuda": {
                "funcionamento": "Um parágrafo dizendo o que o site é, para quem e com que oferta.",
                "escolha": "Resuma público, oferta e finalidade do negócio.",
                "vantagens": "Ajuda a interpretar os links do índice.",
                "limitacoes": "Não substitui conteúdo das páginas nem comprova serviços não publicados.",
                "exemplo": "A empresa presta consultoria e mantém artigos públicos de tecnologia.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "modo": {
            "tipo": "enum",
            "rotulo": "Como a lista é formada",
            "descricao": "A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois.",
            "impacto": "Listando apenas o escolhido na entrega, o arquivo é previsível e toda página criada depois fica de fora para sempre. Listando apenas o publicado, ele acompanha o site e perde a ordem que alguém escolheu. Com os dois — que é como este site é entregue —, a curadoria vem primeiro e o resto entra em seguida: o arquivo continua vivo quando o site cresce, sem perder a ordem escolhida.",
            "exemplo": "Ilustrativo: os dois eixos juntos, com a lista escolhida na entrega à frente do que for publicado depois.",
            "opcoes": {
                "curada": "apenas a lista escolhida na entrega",
                "automatica": "apenas o conteúdo publicado dos tipos abaixo",
                "curada-mais-automatica": "os dois: a lista escolhida primeiro, o publicado em seguida"
            },
            "ajuda": {
                "funcionamento": "A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois.",
                "escolha": "Escolha curadoria fixa ou inclusão dos conteúdos publicados elegíveis.",
                "vantagens": "Curadoria oferece controle; enumeração acompanha novas publicações.",
                "limitacoes": "Enumeração amplia volume; curadoria precisa manutenção manual.",
                "exemplo": "Um site editorial pode enumerar artigos; uma página institucional pode usar curadoria.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "tipos": {
            "tipo": "multiescolha",
            "rotulo": "Tipos de conteúdo enumerados",
            "descricao": "Selecione os tipos públicos disponíveis neste site. Usado nos modos que enumeram o conteúdo publicado.",
            "impacto": "Os tipos marcados participam da lista automática do llms.txt e do llms-full.txt. Conteúdos privados, com senha ou noindex continuam excluídos. Desmarcar todos esvazia a seleção automática; os itens de curadoria continuam seguindo o modo escolhido.",
            "exemplo": "Ilustrativo: as páginas e os artigos do blog, que é como este site é entregue.",
            "opcoes": {
                "attachment": "Media (attachment)",
                "page": "Pages (page)",
                "post": "Posts (post)"
            },
            "ajuda": {
                "funcionamento": "Selecione os tipos públicos disponíveis neste site. Usado nos modos que enumeram o conteúdo publicado.",
                "escolha": "Selecione os tipos públicos com conteúdo editorial relevante.",
                "vantagens": "Permite incluir artigos e páginas sem conteúdo técnico repetitivo.",
                "limitacoes": "Só atua em modos que enumeram; não torna posts privados públicos.",
                "exemplo": "page e post; anexos continuam sujeitos à elegibilidade.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "markdown": {
            "tipo": "booleano",
            "rotulo": "Publicar páginas em Markdown",
            "descricao": "Disponibiliza versões de leitura das páginas públicas selecionadas e as anuncia no HTML.",
            "impacto": "Ligado, os links locais do índice apontam para alternativas Markdown. Conteúdo privado, com senha ou noindex fica fora. Desligado, os links apontam para o HTML. A conversão inclui o conteúdo editorial salvo; blocos dinâmicos e shortcodes não são executados.",
            "exemplo": "Ilustrativo: uma página de serviços ganha a alternativa /servicos/index.md.",
            "ajuda": {
                "funcionamento": "Ligado, os links locais do índice apontam para alternativas Markdown. Conteúdo privado, com senha ou noindex fica fora. Desligado, os links apontam para o HTML. A conversão inclui o conteúdo editorial salvo; blocos dinâmicos e shortcodes não são executados.",
                "escolha": "Ative para disponibilizar a representação Markdown individual.",
                "vantagens": "Facilita consumo do conteúdo público por agentes.",
                "limitacoes": "Não torna conteúdo privado público; geração acima do orçamento responde 503 temporário.",
                "exemplo": "/pagina.md quando a rota e a página forem elegíveis.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "full": {
            "tipo": "booleano",
            "rotulo": "Publicar também o texto integral",
            "descricao": "Serve /llms-full.txt com o conteúdo completo de cada item listado, em Markdown e sem resumo.",
            "impacto": "Ligado, o endereço /llms-full.txt passa a responder com o texto integral das mesmas páginas — reúne o corpo completo em um único arquivo, preservando títulos, listas, links e código. Usa a mesma seleção pública do índice e não corta textos pelo limite de palavras dos resumos. É uma segunda cópia do site em texto puro, com o custo de banda e de superfície que isso traz. Ligado é o padrão. Quando desligado, o endereço não responde: nenhum hook é registrado e a rota não existe.",
            "exemplo": "Ilustrativo: ligado, publica /llms-full.txt. Desligue quando não desejar reunir o conteúdo integral em um só arquivo.",
            "ajuda": {
                "funcionamento": "Ligado, o endereço /llms-full.txt passa a responder com o texto integral das mesmas páginas — reúne o corpo completo em um único arquivo, preservando títulos, listas, links e código. Usa a mesma seleção pública do índice e não corta textos pelo limite de palavras dos resumos. É uma segunda cópia do site em texto puro, com o custo de banda e de superfície que isso traz. Ligado é o padrão. Quando desligado, o endereço não responde: nenhum hook é registrado e a rota não existe.",
                "escolha": "Ative para publicar o índice integral dos conteúdos públicos elegíveis.",
                "vantagens": "Fornece texto completo usando o mesmo conversor do Markdown individual.",
                "limitacoes": "Pode aumentar tamanho e custo de geração; arquivos privados e noindex continuam excluídos.",
                "exemplo": "Novo site usa ativado; escolha false já gravada permanece false.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "indexavel": {
            "tipo": "booleano",
            "rotulo": "Deixar o arquivo ser indexado",
            "descricao": "Controla o cabeçalho X-Robots-Tag na resposta do arquivo.",
            "impacto": "Ligado, não solicita exclusão dos índices. Desligado, envia X-Robots-Tag: noindex para indexadores que respeitam a diretiva. Isso não bloqueia leitura, não é controle de treinamento de IA e não protege conteúdo. Alternativas Markdown usam noindex e apontam a página HTML canônica. As respostas usam cache interno com invalidação e exigem revalidação HTTP.",
            "exemplo": "Ilustrativo: ligado, que é como este site é entregue.",
            "ajuda": {
                "funcionamento": "Ligado, não solicita exclusão dos índices. Desligado, envia X-Robots-Tag: noindex para indexadores que respeitam a diretiva. Isso não bloqueia leitura, não é controle de treinamento de IA e não protege conteúdo. Alternativas Markdown usam noindex e apontam a página HTML canônica. As respostas usam cache interno com invalidação e exigem revalidação HTTP.",
                "escolha": "Escolha se as representações textuais podem ser indexadas.",
                "vantagens": "Permite controlar a descoberta das cópias textuais.",
                "limitacoes": "Não remove a página HTML dos buscadores nem garante indexação.",
                "exemplo": "Desligado mantém a representação com diretivas de não indexação.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "entrega": {
            "tipo": "enum",
            "rotulo": "Entrega do índice",
            "descricao": "Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados.",
            "impacto": "Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados.",
            "exemplo": "Arquivo gerado é o padrão.",
            "opcoes": {
                "dinamica": "Dinâmica",
                "arquivo_gerado": "Arquivo gerado"
            },
            "ajuda": {
                "funcionamento": "arquivo_gerado publica o índice para o servidor entregar; dinamica produz a resposta pelo WordPress.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Arquivo gerado reduz execução PHP por leitura e exige tarefas de atualização funcionando.",
                "vazio": "Ausente usa arquivo_gerado; valor explícito é preservado. Vazio é inválido.",
                "padrao": "arquivo_gerado"
            }
        },
        "atualizacao_intervalo_segundos": {
            "tipo": "inteiro",
            "rotulo": "Intervalo de atualização",
            "descricao": "Atualização periódica. Sem visitas é necessário cron real.",
            "impacto": "Atualização periódica. Sem visitas é necessário cron real.",
            "exemplo": "Atualizar a cada hora.",
            "ajuda": {
                "funcionamento": "Atualização periódica. Sem visitas é necessário cron real.",
                "escolha": "Escolha a frequência de preparação do índice conforme o ritmo editorial.",
                "vantagens": "Evita reconstruir todo o índice em cada leitura.",
                "limitacoes": "Depende de executor; cron atrasado pode atrasar conteúdo atualizado.",
                "exemplo": "3600 segundos para atualização horária.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            },
            "estrutura": []
        },
        "atualizar_por_visita": {
            "tipo": "booleano",
            "rotulo": "Verificar atualização nas visitas",
            "descricao": "Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.",
            "impacto": "Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.",
            "exemplo": "Ativado.",
            "ajuda": {
                "funcionamento": "Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.",
                "escolha": "Use como apoio em sites com tráfego; mantenha executor externo para horários previsíveis.",
                "vantagens": "Ajuda a disparar a preparação quando há visitas.",
                "limitacoes": "Não garante cadência em site sem acessos.",
                "exemplo": "Cron a cada cinco minutos continua sendo o executor da operação.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        },
        "blocos_interface": {
            "tipo": "blocos",
            "rotulo": "Blocos de interface excluídos da conversão",
            "descricao": "Selecione os blocos de interface que serão omitidos na conversão Markdown. Valores já salvos são preservados quando o bloco está indisponível.",
            "ajuda": {
                "funcionamento": "Exclui da conversão em Markdown os tipos de bloco selecionados. Não remove o bloco da página visual.",
                "escolha": "Marque elementos de navegação e interface repetitivos; mantenha os blocos que contêm conteúdo editorial relevante.",
                "vantagens": "Reduz repetição e deixa o documento convertido mais legível.",
                "limitacoes": "Excluir um contêiner pode excluir também seu conteúdo. Confira a prévia da conversão após mudar a lista.",
                "exemplo": "Exclua um bloco de navegação recorrente; não exclua grupos usados para textos dos serviços.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            },
            "estrutura": {
                "itens": []
            }
        },
        "cabecalhos_servidor": {
            "tipo": "booleano",
            "rotulo": "Gerenciar cabeçalhos do arquivo",
            "descricao": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
            "impacto": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
            "exemplo": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
            "ajuda": {
                "funcionamento": "A preferência exige Aplicar em Operação. A instalação não altera o arquivo do servidor.",
                "escolha": "Aplique as regras gerenciadas somente quando o servidor e as permissões forem compatíveis.",
                "vantagens": "Permite entregar arquivos gerados com os cabeçalhos previstos.",
                "limitacoes": "Preferência salva não comprova regra aplicada nem resposta HTTP do cache.",
                "exemplo": "Conferir Operação → publicação e cabeçalhos após aplicar.",
                "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Índice curto que apresenta o site a assistentes e agentes que o leem.",
        "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
        "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
        "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
        "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "politica_privacidade": {
            "tipo": [
                "object",
                "array"
            ],
            "padrao": null,
            "ajuda": {
                "funcionamento": "Referência opcional à política de privacidade no índice llms; não cria a página nem altera consentimento.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "{\"titulo\":\"Privacidade\",\"url\":\"https://exemplo.com/privacidade/\"}",
                "vazio": "Vazio omite a referência, inclusive a descoberta automática dessa página.",
                "padrao": "[]"
            },
            "estrutura": {
                "id": {
                    "tipo": "integer",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "id",
                        "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                        "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                        "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                        "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "url": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "url",
                        "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                        "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                        "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                        "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "titulo": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "titulo",
                        "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                        "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                        "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                        "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "descricao": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "descricao",
                        "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                        "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                        "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                        "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            }
        },
        "livres": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Referências curadas adicionais no índice llms. Cada item informa título, URL e descrição; passam pela seleção e deduplicação do índice.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "[{\"titulo\":\"Sobre\",\"url\":\"https://exemplo.com/sobre/\",\"descricao\":\"Nossa equipe\"}]",
                "vazio": "Lista vazia não acrescenta referências livres e é preservada.",
                "padrao": "[]"
            },
            "estrutura": {
                "itens": {
                    "id": {
                        "tipo": "integer",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "id",
                            "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                            "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                            "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                            "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "url": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "url",
                            "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                            "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                            "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                            "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "titulo": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "titulo",
                            "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                            "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                            "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                            "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "descricao": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "descricao",
                            "escolha": "Escolha quais conteúdos públicos podem ser convertidos e revise a prévia após alterar curadoria ou tipos.",
                            "vantagens": "Disponibiliza representações de texto sem executar o tema em cada leitura do arquivo gerado.",
                            "limitacoes": "Não garante uso ou citação por buscadores. Atualização depende do executor; conteúdo privado, com senha ou noindex permanece excluído.",
                            "exemplo": "Edite uma página: a geração anterior continua disponível enquanto a nova é preparada; retirar a visibilidade prevalece imediatamente.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    }
                }
            }
        }
    }
}
```

## f3base_redirects

```json
{
    "rotulo": "Redirects declarados",
    "descricao": "Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.",
        "escolha": "Cadastre pares exatos e simule antes de aplicar. Query é preservada por padrão; o destino vence colisões de parâmetros.",
        "vantagens": "Mantém links antigos e a origem publicitária durante mudança de endereço.",
        "limitacoes": "Preservar query envia seus parâmetros também ao destino externo. Status permanente pode ficar em caches; evite encadeamentos e laços.",
        "exemplo": "/contato/ para /#contato preserva UTMs e confere a âncora no HTML servido.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "itens": {
            "preservar_query": {
                "tipo": "boolean",
                "padrao": true,
                "ajuda": {
                    "funcionamento": "preservar_query",
                    "escolha": "Cadastre pares exatos e simule antes de aplicar. Query é preservada por padrão; o destino vence colisões de parâmetros.",
                    "vantagens": "Mantém links antigos e a origem publicitária durante mudança de endereço.",
                    "limitacoes": "Preservar query envia seus parâmetros também ao destino externo. Status permanente pode ficar em caches; evite encadeamentos e laços.",
                    "exemplo": "/contato/ para /#contato preserva UTMs e confere a âncora no HTML servido.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "de": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "de",
                    "escolha": "Cadastre pares exatos e simule antes de aplicar. Query é preservada por padrão; o destino vence colisões de parâmetros.",
                    "vantagens": "Mantém links antigos e a origem publicitária durante mudança de endereço.",
                    "limitacoes": "Preservar query envia seus parâmetros também ao destino externo. Status permanente pode ficar em caches; evite encadeamentos e laços.",
                    "exemplo": "/contato/ para /#contato preserva UTMs e confere a âncora no HTML servido.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "para": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "para",
                    "escolha": "Cadastre pares exatos e simule antes de aplicar. Query é preservada por padrão; o destino vence colisões de parâmetros.",
                    "vantagens": "Mantém links antigos e a origem publicitária durante mudança de endereço.",
                    "limitacoes": "Preservar query envia seus parâmetros também ao destino externo. Status permanente pode ficar em caches; evite encadeamentos e laços.",
                    "exemplo": "/contato/ para /#contato preserva UTMs e confere a âncora no HTML servido.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "status": {
                "tipo": "integer",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "status",
                    "escolha": "Cadastre pares exatos e simule antes de aplicar. Query é preservada por padrão; o destino vence colisões de parâmetros.",
                    "vantagens": "Mantém links antigos e a origem publicitária durante mudança de endereço.",
                    "limitacoes": "Preservar query envia seus parâmetros também ao destino externo. Status permanente pode ficar em caches; evite encadeamentos e laços.",
                    "exemplo": "/contato/ para /#contato preserva UTMs e confere a âncora no HTML servido.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            }
        }
    }
}
```

## f3base_google_carregamento

```json
{
    "rotulo": "Carregamento das tags Google",
    "descricao": "Controla a inserção de gtag.js direto; não se aplica ao GTM.",
    "campo": "grupo",
    "subcampos": {
        "modo": {
            "tipo": "enum",
            "rotulo": "Momento do carregamento",
            "descricao": "Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.",
            "impacto": "Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.",
            "exemplo": "Imediato para preservar a medição.",
            "opcoes": {
                "imediato": "Imediato",
                "apos_interacao": "Após interação ou prazo",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.",
                "escolha": "Escolha Imediato ou Após interação conforme a política de medição.",
                "vantagens": "Adiar reduz disputa de recursos na abertura.",
                "limitacoes": "Visitas curtas podem terminar antes da tag; o GTM mantém política própria.",
                "exemplo": "Após interação antecipa no primeiro gesto e respeita o teto.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo após load, em segundos",
            "descricao": "Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.",
            "impacto": "Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.",
            "exemplo": "Aguardar até cinco segundos.",
            "ajuda": {
                "funcionamento": "Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.",
                "escolha": "Defina a espera máxima contada depois do load.",
                "vantagens": "Garante liberação mesmo sem gesto em visitas longas.",
                "limitacoes": "Aumentar a espera pode reduzir cobertura de visitas breves.",
                "exemplo": "5 significa até cinco segundos; consentimento continua obrigatório.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": []
        }
    },
    "ajuda": {
        "funcionamento": "Controla a inserção de gtag.js direto; não se aplica ao GTM.",
        "escolha": "Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load e uma oportunidade livre, com prazo máximo próprio.",
        "vantagens": "Adiar reduz competição com os recursos da abertura; o teto atende páginas em que não há interação.",
        "limitacoes": "Visitas muito curtas podem terminar antes da liberação. O modo não controla tags que não foram instaladas pelo Core.",
        "exemplo": "Após interação, teto de 5 segundos: o primeiro toque libera antes do prazo; recusa de publicidade continua prevalecendo.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_seo_entidade

```json
{
    "rotulo": "Entidade de SEO",
    "descricao": "Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.",
    "campo": "grupo",
    "subcampos": {
        "nome": {
            "tipo": "texto",
            "rotulo": "Nome",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Nome público da organização, igual ao divulgado no site.",
                "vantagens": "Consolida a identidade institucional.",
                "limitacoes": "Não substitui razão social ou validação de marca.",
                "exemplo": "Empresa Exemplo",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "same_as": {
            "tipo": "json",
            "rotulo": "Same as",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Informe os perfis oficiais da mesma organização.",
                "vantagens": "Conecta identificadores institucionais existentes.",
                "limitacoes": "Uma resposta HTTP 200 não comprova identidade; não use perfil de parceiro.",
                "exemplo": "https://www.linkedin.com/company/empresa-exemplo/",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "area_servida": {
            "tipo": "json",
            "rotulo": "Area servida",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Liste regiões nas quais o serviço é realmente prestado.",
                "vantagens": "Explicita o alcance geográfico.",
                "limitacoes": "Não invente filial, endereço ou cobertura sem comprovação.",
                "exemplo": "Brasil; São Paulo",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "conhece_sobre": {
            "tipo": "json",
            "rotulo": "Conhece sobre",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Liste assuntos que a organização aborda no conteúdo publicado.",
                "vantagens": "Descreve especialidades sem alterar o texto editorial.",
                "limitacoes": "Não é uma lista de palavras-chave para aumentar artificialmente relevância.",
                "exemplo": "Planejamento financeiro",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "ponto_de_contato": {
            "tipo": "json",
            "rotulo": "Ponto de contato",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Declare o canal institucional e sua finalidade de atendimento.",
                "vantagens": "Distingue suporte, comercial e outros contatos oficiais.",
                "limitacoes": "Não cria formulário nem altera destinatários dos avisos.",
                "exemplo": "Atendimento comercial; +55 11 90000-0000",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "organizacao_mae": {
            "tipo": "json",
            "rotulo": "Organizacao mae",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Preencha apenas se existir relação societária/organizacional publicada.",
                "vantagens": "Representa hierarquia legítima.",
                "limitacoes": "Não equivale a parceiro comercial; relações circulares são recusadas.",
                "exemplo": "Nome e URL pública da holding",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "nome": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "nome",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "url": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "url",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "id": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "id",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            }
        },
        "servicos": {
            "tipo": "json",
            "rotulo": "Servicos",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Declare serviços com página pública correspondente e ofertas verificáveis.",
                "vantagens": "Relaciona catálogo, conteúdo e preços publicados.",
                "limitacoes": "Oferta exige prova de conteúdo e ausência de emissor concorrente; configuração não garante emissão.",
                "exemplo": "Consultoria, página 123; R$ 239/mês quando publicado",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "itens": {
                    "nome": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nome",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "descricao": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "descricao",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "url": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "url",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "tipo_servico": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "tipo_servico",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "area_servida": {
                        "tipo": "array",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "area_servida",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": []
                        }
                    },
                    "ofertas": {
                        "tipo": "array",
                        "padrao": [],
                        "ajuda": {
                            "funcionamento": "ofertas",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": {
                                "id": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "id",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "nome": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "nome",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "pagina": {
                                    "tipo": "integer",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "pagina",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "descricao": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "descricao",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "modalidade": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "modalidade",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "preco": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "preco",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "moeda": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "moeda",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "periodo": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "periodo",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        "faq_schema": {
            "tipo": "booleano",
            "rotulo": "Faq schema",
            "descricao": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "impacto": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
            "exemplo": "Valor confirmado pelo responsável do site.",
            "ajuda": {
                "funcionamento": "Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.",
                "escolha": "Ative somente para perguntas e respostas visíveis no conteúdo elegível.",
                "vantagens": "Representa FAQ publicado no mesmo documento.",
                "limitacoes": "Não garante resultado destacado; conteúdo oculto não vira FAQ válido.",
                "exemplo": "Pergunta: Como funciona? Resposta visível na página.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "razao_social": {
            "tipo": "texto",
            "rotulo": "Razão social",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Use o nome jurídico exato quando adequado à identificação pública.",
                "vantagens": "Distingue marca e entidade legal.",
                "limitacoes": "Não valida cadastro fiscal automaticamente.",
                "exemplo": "Empresa Exemplo Ltda.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "cnpj": {
            "tipo": "texto",
            "rotulo": "CNPJ",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Informe somente CNPJ válido da organização declarada.",
                "vantagens": "Ajuda a distinguir organizações com nomes semelhantes.",
                "limitacoes": "Validação matemática não comprova situação cadastral.",
                "exemplo": "Use o CNPJ público da própria empresa; não um número de demonstração no site real.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "descricao": {
            "tipo": "texto",
            "rotulo": "Descrição",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Resuma a atividade institucional em linguagem objetiva.",
                "vantagens": "Dá contexto ao nome da organização.",
                "limitacoes": "Não muda automaticamente a descrição de cada página no Yoast.",
                "exemplo": "Consultoria para empresas de serviços.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "email": {
            "tipo": "texto",
            "rotulo": "E-mail",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Use endereço institucional público para o grafo da organização.",
                "vantagens": "Explicita o canal público.",
                "limitacoes": "Não é a lista privada de destinatários de leads.",
                "exemplo": "contato@example.org",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "telefone": {
            "tipo": "texto",
            "rotulo": "Telefone E.164",
            "descricao": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "impacto": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
            "exemplo": "Preencher somente dados confirmados.",
            "ajuda": {
                "funcionamento": "Complementa somente propriedades ausentes na organização emitida pelo Yoast.",
                "escolha": "Use telefone público da organização com código de país.",
                "vantagens": "Padroniza o contato no grafo.",
                "limitacoes": "Não habilita WhatsApp nem modifica a captura de cliques.",
                "exemplo": "+55 11 90000-0000",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "endereco": {
            "tipo": "json",
            "rotulo": "Endereço",
            "descricao": "Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.",
            "impacto": "Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.",
            "exemplo": "{\"cidade\":\"São Paulo\",\"uf\":\"SP\",\"pais\":\"BR\"}",
            "ajuda": {
                "funcionamento": "Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.",
                "escolha": "Preencha endereço real e publicado, respeitando a política do site.",
                "vantagens": "Permite identificar uma localização institucional.",
                "limitacoes": "Não transforme área de atendimento em endereço fictício.",
                "exemplo": "Cidade e estado reais da organização",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "logradouro": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "logradouro",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "cidade": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "cidade",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "uf": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "uf",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "cep": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "cep",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "pais": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "pais",
                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            }
        },
        "organizacoes_filhas": {
            "tipo": "json",
            "rotulo": "Organizações filhas",
            "descricao": "Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.",
            "impacto": "Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.",
            "exemplo": "[]",
            "ajuda": {
                "funcionamento": "Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.",
                "escolha": "Informe organizações vinculadas com relação publicada.",
                "vantagens": "Permite representar o grupo sem duplicar identidades.",
                "limitacoes": "Lista não cria sites nem comprova vínculo societário.",
                "exemplo": "Uma subsidiária com nome e URL próprios",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "itens": {
                    "nome": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nome",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "url": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "url",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "id": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "id",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    }
                }
            }
        },
        "autoria": {
            "tipo": "enum",
            "rotulo": "Autoria padrão",
            "descricao": "Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.",
            "impacto": "Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.",
            "exemplo": "Usuário preserva a autoria atual.",
            "opcoes": {
                "usuario": "Usuário",
                "organizacao": "Institucional"
            },
            "ajuda": {
                "funcionamento": "Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.",
                "escolha": "Institucional apresenta a organização; Usuário conserva autoria pessoal legítima.",
                "vantagens": "Separa responsabilidade editorial da conta usada para editar.",
                "limitacoes": "post_author não é alterado; login técnico não deve servir como nome público.",
                "exemplo": "Institucional para páginas corporativas; pessoa publicada para artigo assinado.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            }
        },
        "pessoas": {
            "tipo": "json",
            "rotulo": "Pessoas por página",
            "ajuda": {
                "funcionamento": "Pessoas por página",
                "escolha": "Declare pessoas publicamente apresentadas e páginas que comprovam a relação.",
                "vantagens": "Preserva autores e membros legítimos da equipe no grafo.",
                "limitacoes": "Não publica automaticamente contas WordPress nem inventa emprego ou formação.",
                "exemplo": "Pessoa com página de equipe e perfil profissional oficial.",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "itens": {
                    "id": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "id",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "nome": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nome",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "cargo": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "cargo",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "descricao": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "descricao",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "same_as": {
                        "tipo": "array",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "same_as",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": []
                        }
                    },
                    "paginas": {
                        "tipo": "array",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "paginas",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": []
                        }
                    }
                }
            }
        }
    },
    "ajuda": {
        "funcionamento": "Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.",
        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "ponto_de_contato": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ponto_de_contato",
                "escolha": "Declare o canal institucional e sua finalidade de atendimento.",
                "vantagens": "Distingue suporte, comercial e outros contatos oficiais.",
                "limitacoes": "Não cria formulário nem altera destinatários dos avisos.",
                "exemplo": "Atendimento comercial; +55 11 90000-0000",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "itens": {
                    "tipo": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "tipo",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "telefone": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "telefone",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "email": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "email",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "idiomas": {
                        "tipo": "array",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "idiomas",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": []
                        }
                    }
                }
            }
        },
        "servicos": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "servicos",
                "escolha": "Declare serviços com página pública correspondente e ofertas verificáveis.",
                "vantagens": "Relaciona catálogo, conteúdo e preços publicados.",
                "limitacoes": "Oferta exige prova de conteúdo e ausência de emissor concorrente; configuração não garante emissão.",
                "exemplo": "Consultoria, página 123; R$ 239/mês quando publicado",
                "vazio": "Vazio omite a declaração específica; não apaga conteúdo do tema ou de outro emissor."
            },
            "estrutura": {
                "itens": {
                    "nome": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nome",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "descricao": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "descricao",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "url": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "url",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "tipo_servico": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "tipo_servico",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "area_servida": {
                        "tipo": "array",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "area_servida",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": []
                        }
                    },
                    "ofertas": {
                        "tipo": "array",
                        "padrao": [],
                        "ajuda": {
                            "funcionamento": "ofertas",
                            "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                            "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                            "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                            "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        },
                        "estrutura": {
                            "itens": {
                                "id": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "id",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "nome": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "nome",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "pagina": {
                                    "tipo": "integer",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "pagina",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "descricao": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "descricao",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "modalidade": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "modalidade",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "preco": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "preco",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "moeda": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "moeda",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                },
                                "periodo": {
                                    "tipo": "string",
                                    "padrao": null,
                                    "ajuda": {
                                        "funcionamento": "periodo",
                                        "escolha": "Preencha fatos publicados e verificáveis da organização; use pessoas e ofertas somente quando declaradas no conteúdo.",
                                        "vantagens": "Acrescenta relações ao grafo existente, preservando a identidade da página e referências legítimas.",
                                        "limitacoes": "Schema não garante resultado destacado. sameAs retornando 200 não comprova identidade; emprego, preço e periodicidade não podem ser inferidos.",
                                        "exemplo": "FAQ usa pergunta e resposta visíveis; preço mensal publicado pode usar período MON na oferta do serviço.",
                                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
```

## f3base_cabecalhos

```json
{
    "rotulo": "Cabeçalhos de resposta",
    "descricao": "Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.",
        "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
        "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
        "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
        "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "x_frame_options": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "x_frame_options",
                "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
                "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
                "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
                "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "coop": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "coop",
                "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
                "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
                "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
                "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "referrer_policy": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "referrer_policy",
                "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
                "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
                "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
                "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "permissions_policy": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "permissions_policy",
                "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
                "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
                "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
                "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "csp_frame_ancestors": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "csp_frame_ancestors",
                "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
                "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
                "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
                "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "hsts_max_age": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "hsts_max_age",
                "escolha": "Selecione valores compatíveis com embeds, autenticação, publicidade e protocolos realmente usados pelo site.",
                "vantagens": "Define respostas de segurança no escopo administrado pelo plugin.",
                "limitacoes": "Cache/CDN pode responder sem executar PHP. HSTS exige HTTPS estável e tem efeito persistente no navegador.",
                "exemplo": "Após mudar uma política, teste a home em HIT/MISS e as integrações afetadas; opção gravada não é prova HTTP.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_cadencia

```json
{
    "rotulo": "Cadência do modo somente-relatório",
    "descricao": "Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.",
        "escolha": "Periodicidade e quantidade de ajustes são gatilhos independentes. Nenhuma e zero deixam ambos desligados.",
        "vantagens": "Cria uma fotografia local de módulos, configurações e conteúdo demonstrativo para revisão da equipe.",
        "limitacoes": "Não envia relatório por e-mail, não mantém histórico completo e não corrige automaticamente divergências. Cron pode atrasar em sites sem tráfego.",
        "exemplo": "A última execução, seu resultado e próxima agenda aparecem em Operação e saude-ler → cadencia.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "periodicidade": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "periodicidade",
                "escolha": "Periodicidade e quantidade de ajustes são gatilhos independentes. Nenhuma e zero deixam ambos desligados.",
                "vantagens": "Cria uma fotografia local de módulos, configurações e conteúdo demonstrativo para revisão da equipe.",
                "limitacoes": "Não envia relatório por e-mail, não mantém histórico completo e não corrige automaticamente divergências. Cron pode atrasar em sites sem tráfego.",
                "exemplo": "A última execução, seu resultado e próxima agenda aparecem em Operação e saude-ler → cadencia.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "apos_n_ajustes": {
            "tipo": "",
            "padrao": null,
            "ajuda": {
                "funcionamento": "apos_n_ajustes",
                "escolha": "Periodicidade e quantidade de ajustes são gatilhos independentes. Nenhuma e zero deixam ambos desligados.",
                "vantagens": "Cria uma fotografia local de módulos, configurações e conteúdo demonstrativo para revisão da equipe.",
                "limitacoes": "Não envia relatório por e-mail, não mantém histórico completo e não corrige automaticamente divergências. Cron pode atrasar em sites sem tráfego.",
                "exemplo": "A última execução, seu resultado e próxima agenda aparecem em Operação e saude-ler → cadencia.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_operaveis

```json
{
    "rotulo": "Política de opções operáveis",
    "descricao": "Restrição explícita do site; gestão somente pelo serviço de política.",
    "campo": "json",
    "ajuda": {
        "funcionamento": "Política local de quais opções podem ser geridas pelo canal: todas permite todas as opções catalogadas como operáveis; lista restringe aos nomes escolhidos. É metaconfiguração, não opção operável por si mesma.",
        "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
        "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
        "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
        "exemplo": "{\"schema\":1,\"modo\":\"lista\",\"lista\":[\"f3base_gsc\"]}",
        "vazio": "No modo lista, [] autoriza zero opções; não é substituída pelo padrão.",
        "padrao": "{\"schema\":1,\"modo\":\"todas\",\"lista\":[]}"
    }
}
```

## f3base_politica_canal

```json
{
    "rotulo": "Gestão de política pelo canal",
    "descricao": "Gestão autenticada da política pelo canal, habilitada por padrão; alterações exigem manage_options e revisão.",
    "campo": "booleano",
    "ajuda": {
        "funcionamento": "Permite que o canal administre a política de configuração neste site. A concessão MCP e a capacidade do usuário continuam obrigatórias.",
        "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
        "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
        "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
        "exemplo": "Desative na Operação se a política só puder ser alterada pelo dono no wp-admin.",
        "vazio": "Ausente usa true; false mantém a gestão de política na interface local.",
        "padrao": "true"
    }
}
```

## f3base_formularios

```json
{
    "rotulo": "Formulários próprios",
    "descricao": "Definições revisionadas. Editor em Contatos → Formulários.",
    "campo": "json",
    "ajuda": {
        "funcionamento": "Definições revisionadas. Editor em Contatos → Formulários.",
        "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
        "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
        "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
        "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "itens": {
            "id": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "id",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "titulo": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "titulo",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "exigir_um_de": {
                "tipo": "array",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "exigir_um_de",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                },
                "estrutura": {
                    "itens": []
                }
            },
            "mensagem_exigir_um_de": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "mensagem_exigir_um_de",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "etapa2_apresentacao": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "inline mantém a segunda etapa no formulário; dialogo a apresenta em janela nativa quando o adaptador permite.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "dialogo conserva foco e retorna ao formulário ao fechar.",
                    "vazio": "Ausente usa inline; vazio é inválido.",
                    "padrao": "inline"
                }
            },
            "mostrar_pular": {
                "tipo": "boolean",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "Exibe a ação Pular e continuar na etapa complementar; o contato inicial já está salvo.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "false para evitar o convite de pulo na interface.",
                    "vazio": "Ausente mostra; false esconde o botão. Não torna a etapa inicial dependente do complemento.",
                    "padrao": "true"
                }
            },
            "whatsapp_nova_aba": {
                "tipo": "boolean",
                "padrao": true,
                "ajuda": {
                    "funcionamento": "whatsapp_nova_aba",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "whatsapp_campos": {
                "tipo": "array",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "whatsapp_campos",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                },
                "estrutura": {
                    "itens": []
                }
            },
            "pipedrive_sem_nome": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "herdar usa a política geral; recusar mantém contato sem nome para revisão; enviar permite nome alternativo com identificador válido.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "enviar com telefone válido usa o modelo de nome alternativo.",
                    "vazio": "Ausente herda; vazio é inválido.",
                    "padrao": "herdar"
                }
            },
            "pipedrive": {
                "tipo": "boolean",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "pipedrive",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "mensagem_whatsapp": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "mensagem_whatsapp",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "whatsapp_automatico": {
                "tipo": "boolean",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "Abre a conversa somente depois do aceite do envio; com duas etapas, aguarda a conclusão ou o pulo da segunda.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "true abre WhatsApp após confirmação.",
                    "vazio": "Ausente ou false mostra o botão para continuar; não abre sozinho.",
                    "padrao": "false"
                }
            },
            "servico_fixo": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "servico_fixo",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "resposta_visitante": {
                "tipo": "object",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "resposta_visitante",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                },
                "estrutura": {
                    "ativa": {
                        "tipo": "boolean",
                        "padrao": false,
                        "ajuda": {
                            "funcionamento": "ativa",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "campo_email": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "campo_email",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "assunto": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "assunto",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "corpo": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "corpo",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "remetente": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "remetente",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "nome_remetente": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nome_remetente",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    }
                }
            },
            "regime": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "registro salva o contato; whatsapp salva e oferece continuação da conversa; conteudo concede acesso ao arquivo privado.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "conteudo exige e-mail obrigatório e ativo privado.",
                    "vazio": "Ausente usa registro; string vazia é recusada.",
                    "padrao": "registro"
                }
            },
            "ativo": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "Identificador do arquivo privado entregue no regime conteudo. Não é um switch de habilitação.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "ID textual de 32 hexadecimais devolvido pelo cadastro de arquivo.",
                    "vazio": "Ausente é permitido em registro/whatsapp; conteudo exige ativo existente.",
                    "padrao": "ausente"
                }
            },
            "validade_dias": {
                "tipo": "integer",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "Prazo de cada concessão de acesso ao conteúdo protegido, contado desde a emissão.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "7 mantém o link válido por sete dias.",
                    "vazio": "Ausente usa 7; zero e vazio são inválidos.",
                    "padrao": "7"
                }
            },
            "quota": {
                "tipo": "integer",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "Máximo de utilizações da concessão de conteúdo protegido; não é limite de envios do formulário.",
                    "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                    "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                    "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                    "exemplo": "5 permite até cinco utilizações válidas do link.",
                    "vazio": "Ausente usa 5; zero e vazio são inválidos.",
                    "padrao": "5"
                }
            },
            "mensagens": {
                "tipo": "object",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "mensagens",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                },
                "estrutura": {
                    "baixar_conteudo": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "baixar_conteudo",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "complemento_nao_confirmado": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "complemento_nao_confirmado",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "complemento": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "complemento",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "complemento_pulado": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "complemento_pulado",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "concluir": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "concluir",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "pular": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "pular",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "enviando": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "enviando",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "sucesso": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "sucesso",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "validacao": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "validacao",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "arquivo_limite": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "arquivo_limite",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "token_indisponivel": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "token_indisponivel",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "conexao": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "conexao",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "nao_confirmado": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "nao_confirmado",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "falha": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "falha",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "novo_envio": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "novo_envio",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    },
                    "continuar_whatsapp": {
                        "tipo": "string",
                        "padrao": null,
                        "ajuda": {
                            "funcionamento": "continuar_whatsapp",
                            "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                            "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                            "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                            "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                            "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                        }
                    }
                }
            },
            "confirmacao_url": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "confirmacao_url",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "confirmacao": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "confirmacao",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "assunto": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "assunto",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "destinatarios": {
                "tipo": "array",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "destinatarios",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                },
                "estrutura": {
                    "itens": []
                }
            },
            "whatsapp": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "whatsapp",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "botao": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "botao",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "ligado": {
                "tipo": "boolean",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "ligado",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "campos": {
                "tipo": "array",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "campos",
                    "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                    "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                    "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                    "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                },
                "estrutura": {
                    "itens": {
                        "nome": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "nome",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "tipo": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "tipo",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "rotulo": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "rotulo",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "etapa": {
                            "tipo": "integer",
                            "padrao": 1,
                            "ajuda": {
                                "funcionamento": "etapa",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "obrigatorio": {
                            "tipo": "boolean",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "obrigatorio",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "ajuda": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "ajuda",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "opcoes": {
                            "tipo": "array",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "opcoes",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            },
                            "estrutura": {
                                "itens": []
                            }
                        },
                        "padrao": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "padrao",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "placeholder": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "placeholder",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "autocomplete": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "autocomplete",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "largura": {
                            "tipo": "integer",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "largura",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "papel": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "papel",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "html": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "html",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "limites_exibicao": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "automatico mostra os limites calculados do plugin/PHP; oculto esconde o texto; personalizado usa limites_texto. A validação do arquivo permanece igual.",
                                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                                "exemplo": "personalizado: informe uma frase coerente com os limites reais.",
                                "vazio": "Ausente usa automatico; personalizado vazio não mostra texto de limite.",
                                "padrao": "automatico"
                            }
                        },
                        "limites_texto": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "limites_texto",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "max_bytes": {
                            "tipo": "integer",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "max_bytes",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "extensoes": {
                            "tipo": "array",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "extensoes",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            },
                            "estrutura": {
                                "itens": []
                            }
                        },
                        "max_arquivos": {
                            "tipo": "integer",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "max_arquivos",
                                "escolha": "Edite um formulário por vez em Contatos → Formulários; use JSON avançado somente com o contrato validado.",
                                "vantagens": "Preserva os demais formulários e recusa alterações concorrentes por revisão.",
                                "limitacoes": "Prévia não cria lead. Teste real usa a marca de teste e as regras de destinatários daquele formulário.",
                                "exemplo": "Destinatário ausente herda o site; lista própria vazia significa nenhum destinatário.",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        }
                    }
                }
            }
        }
    }
}
```

## f3base_testes

```json
{
    "rotulo": "Testes de agentes e operadores",
    "descricao": "Testes de agentes e operadores",
    "campo": "grupo",
    "subcampos": {
        "habilitado": {
            "tipo": "booleano",
            "rotulo": "Identificar tráfego de teste",
            "descricao": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
            "impacto": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
            "exemplo": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
            "ajuda": {
                "funcionamento": "Cookie ou cabeçalho simples identificam novos registros. Não autenticam o agente.",
                "escolha": "Ative para separar visitas e envios de homologação. Agentes devem visitar /f3base-teste/ em cada navegador/origem ou enviar X-F3Base-Teste: 1.",
                "vantagens": "Permite manter os registros de teste consultáveis e excluí-los dos totais comerciais.",
                "limitacoes": "A marca é uma declaração, não autenticação. Cookies não atravessam subdomínios ou outro cliente HTTP. Não altera consentimento.",
                "exemplo": "Visite a página de ativação, confira a confirmação e faça o teste. A marca dura 365 dias; reativar renova o prazo. Use Sair do modo de teste ao terminar.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "excluir_relatorios": {
            "tipo": "booleano",
            "rotulo": "Excluir testes dos relatórios por padrão",
            "descricao": "Os registros continuam disponíveis em Somente testes e Todos.",
            "impacto": "Os registros continuam disponíveis em Somente testes e Todos.",
            "exemplo": "Os registros continuam disponíveis em Somente testes e Todos.",
            "ajuda": {
                "funcionamento": "Os registros continuam disponíveis em Somente testes e Todos.",
                "escolha": "Mantenha marcado para os totais comerciais.",
                "vantagens": "Evita inflar campanhas e conversões com homologação.",
                "limitacoes": "Depende de o agente marcar o cliente; não identifica testes de outro navegador.",
                "exemplo": "Consulte Somente testes para validar a operação.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_ids": {
            "tipo": "linhas",
            "rotulo": "IDs GA4 autorizados para homologação",
            "descricao": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
            "impacto": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
            "exemplo": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
            "ajuda": {
                "funcionamento": "Use propriedade exclusiva ou filtro de desenvolvedor já verificado; informe um ID G- por linha.",
                "escolha": "Autorize somente propriedades de homologação verificadas.",
                "vantagens": "Permite conferir transporte sem misturar o destino comercial.",
                "limitacoes": "ID válido não comprova filtros de desenvolvedor; valide na conta.",
                "exemplo": "G-XXXXXXXXXX de uma propriedade própria de testes.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "gtm_homologado": {
            "tipo": "booleano",
            "rotulo": "Contêiner GTM verificado para testes",
            "descricao": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
            "impacto": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
            "exemplo": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
            "ajuda": {
                "funcionamento": "Só permita após provar que o contêiner suprime tags comerciais e separa destinos.",
                "escolha": "Marque somente após verificar as tags internas do contêiner.",
                "vantagens": "Permite executar um contêiner preparado para homologação.",
                "limitacoes": "O Core não inspeciona nem controla todas as tags criadas dentro do GTM.",
                "exemplo": "Deixe desligado se o contêiner ainda envia para produção.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "capi_test_event_code": {
            "tipo": "texto",
            "rotulo": "Código Meta Test Events",
            "descricao": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
            "impacto": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
            "exemplo": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
            "ajuda": {
                "funcionamento": "Código do ambiente de teste da Meta. Não habilita o pixel no navegador.",
                "escolha": "Use o código obtido no Test Events da Meta.",
                "vantagens": "Distingue o ensaio do envio comercial no destino.",
                "limitacoes": "Pode expirar e não habilita o pixel do navegador por si só.",
                "exemplo": "Copie o código atual da ferramenta de testes.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "email_destinatarios": {
            "tipo": "emails",
            "rotulo": "Destinatários de homologação",
            "descricao": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
            "impacto": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
            "exemplo": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
            "ajuda": {
                "funcionamento": "Até cinco caixas autorizadas. Apenas avisos internos marcados; resposta ao visitante permanece suprimida.",
                "escolha": "Cadastre até cinco caixas autorizadas a receber os ensaios.",
                "vantagens": "Evita avisar a equipe comercial a cada teste.",
                "limitacoes": "Caixa válida não comprova entrega e não habilita resposta automática ao visitante.",
                "exemplo": "qa@example.com; lista vazia suprime o aviso de teste.",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        },
        "destinos": {
            "tipo": "grupo",
            "rotulo": "Envio de testes por destino",
            "subcampos": {
                "gtm": {
                    "tipo": "enum",
                    "rotulo": "GTM",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "ga4": {
                    "tipo": "enum",
                    "rotulo": "GA4",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "google_ads": {
                    "tipo": "enum",
                    "rotulo": "GOOGLE_ADS",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "meta": {
                    "tipo": "enum",
                    "rotulo": "META",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "linkedin": {
                    "tipo": "enum",
                    "rotulo": "LINKEDIN",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "clarity": {
                    "tipo": "enum",
                    "rotulo": "CLARITY",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir (sem destino de teste homologado)"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "capi": {
                    "tipo": "enum",
                    "rotulo": "CAPI",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "email": {
                    "tipo": "enum",
                    "rotulo": "EMAIL",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "slack": {
                    "tipo": "enum",
                    "rotulo": "SLACK",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "webhook": {
                    "tipo": "enum",
                    "rotulo": "WEBHOOK",
                    "descricao": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "impacto": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                    "opcoes": {
                        "suprimir": "Suprimir",
                        "marcar": "Marcar para homologação"
                    },
                    "ajuda": {
                        "funcionamento": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
                        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
                        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
                        "exemplo": "Suprimir impede o envio; marcar exige destino de homologação configurado. Pixel, Ads e LinkedIn permanecem suprimidos nos testes.",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            },
            "ajuda": {
                "funcionamento": "Envio de testes por destino",
                "escolha": "Defina Suprimir ou Marcar para cada serviço.",
                "vantagens": "Permite homologar um serviço mantendo os demais suprimidos.",
                "limitacoes": "Marcar exige suporte e configuração de testes no destino.",
                "exemplo": "Meta suprimida e GA4 marcado somente na propriedade autorizada.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Testes de agentes e operadores",
        "escolha": "Suprimir é o padrão por destino. Use Marcar somente nos destinos que aceitam o marcador e tenham configuração de homologação conferida.",
        "vantagens": "Mantém registros consultáveis em Somente testes e reduz contaminação dos relatórios comerciais.",
        "limitacoes": "O marcador é declarativo, não autenticação. Não abrange visitas de outro navegador ou tags fora do Core. Não aumenta permissões de acesso.",
        "exemplo": "Ative /f3base-teste/ no mesmo navegador antes do envio. O cookie dura 365 dias; visitas comuns não renovam o prazo. Use ?sair=1 para remover a marca; agentes HTTP usam X-F3Base-Teste: 1 na própria requisição.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_eventos_destinos

```json
{
    "rotulo": "Eventos de comportamento por destino",
    "descricao": "Eventos de comportamento por destino",
    "campo": "grupo",
    "subcampos": {
        "ga4_f3base_saida": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Saída: duração e profundidade",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_f3base_rolagem_salto": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Salto de rolagem",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_f3base_clique_interno": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Clique interno",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ga4_f3base_clique_inerte": {
            "tipo": "booleano",
            "rotulo": "GA4 direto — Clique sem ação observada",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_saida": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Saída: duração e profundidade",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_rolagem_salto": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Salto de rolagem",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_clique_interno": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Clique interno",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "data_layer_f3base_clique_inerte": {
            "tipo": "booleano",
            "rotulo": "dataLayer / GTM — Clique sem ação observada",
            "descricao": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "impacto": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
            "ajuda": {
                "funcionamento": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Controla este destino sem desligar a coleta local. dataLayer é independente do GA4 direto; confira também as tags e gatilhos do contêiner GTM.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Eventos de comportamento por destino",
        "escolha": "Ajuste este campo conforme a operação de Eventos de comportamento por destino neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_protecao

```json
{
    "rotulo": "Proteção pública",
    "descricao": "Proteção pública",
    "campo": "grupo",
    "subcampos": {
        "usuarios_rest_restritos": {
            "tipo": "booleano",
            "rotulo": "Restringir usuários na API pública",
            "descricao": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "impacto": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "exemplo": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "ajuda": {
                "funcionamento": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
                "escolha": "Ative para restringir enumeração pública e evitar autoria que revele o login.",
                "vantagens": "Protege REST público, oEmbed, feed e links de autoria elegíveis.",
                "limitacoes": "Não remove nomes escritos manualmente pelo tema; autores públicos legítimos permanecem.",
                "exemplo": "Se o slug de autor coincide com login, usa nome e URL públicos do site.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "xmlrpc_desativado": {
            "tipo": "booleano",
            "rotulo": "Desativar XML-RPC",
            "descricao": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "impacto": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "exemplo": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "ajuda": {
                "funcionamento": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
                "escolha": "Desative XML-RPC se nenhum publicador depende dele.",
                "vantagens": "Reduz uma superfície de publicação não utilizada.",
                "limitacoes": "Clientes que usam XML-RPC deixam de funcionar; REST autenticada é independente.",
                "exemplo": "Um publicador exclusivamente REST não precisa de XML-RPC.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "login_generico": {
            "tipo": "booleano",
            "rotulo": "Usar mensagem genérica no login",
            "descricao": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "impacto": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "exemplo": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
            "ajuda": {
                "funcionamento": "Proteção pública independente. Confira publicadores e integrações antes de alterar; autenticação administrativa é preservada.",
                "escolha": "Use mensagem genérica na falha de login.",
                "vantagens": "Reduz a confirmação pública de nomes de usuário.",
                "limitacoes": "Não limita tentativas nem substitui autenticação forte.",
                "exemplo": "Usuário inexistente e senha incorreta recebem mensagem equivalente.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Proteção pública",
        "escolha": "Mantenha ligado quando a integração correspondente não precisar de acesso; confira os publicadores do site antes de desligar XML-RPC.",
        "vantagens": "Reduz enumeração pública e superfícies que o site não utiliza, preservando permissões REST e MCP legítimas.",
        "limitacoes": "Uma integração que realmente publique por XML-RPC depende desse protocolo. Mensagem genérica não substitui senha forte nem limita tentativas.",
        "exemplo": "Um cliente que usa REST autenticada continua sujeito às capabilities do WordPress.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_servidor

```json
{
    "rotulo": "Diretórios do servidor",
    "descricao": "Diretórios do servidor",
    "campo": "grupo",
    "subcampos": {
        "bloquear_listagem": {
            "tipo": "booleano",
            "rotulo": "Proteger diretórios e templates do tema",
            "descricao": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
            "impacto": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
            "exemplo": "Instalação nova aplica regras próprias quando suportado. Impede listagem e leitura HTTP dos templates HTML. A prova HTTP confirma o resultado; escolhas existentes são preservadas.",
            "ajuda": {
                "funcionamento": "Solicita bloquear a listagem de diretórios. O efeito público depende da aplicação e prova das regras do servidor.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Confira na Operação se as regras foram aplicadas e verificadas; a preferência sozinha não é prova HTTP.",
                "vazio": "Ausente usa true; false explícito é preservado.",
                "padrao": "true"
            }
        }
    },
    "ajuda": {
        "funcionamento": "Diretórios do servidor",
        "escolha": "Ajuste este campo conforme a operação de Diretórios do servidor neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Habilite a preferência de cabeçalhos, consulte o plano em Operação e aplique com a revisão conferida; a preferência sozinha não escreve regras.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_carregamento_destinos

```json
{
    "rotulo": "Carregamento por destino",
    "descricao": "Carregamento por destino",
    "campo": "grupo",
    "subcampos": {
        "ativo": {
            "tipo": "booleano",
            "rotulo": "Política de carregamento por destino",
            "descricao": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
            "impacto": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
            "exemplo": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
            "ajuda": {
                "funcionamento": "Aplica interação e teto de espera; consentimento e marca de teste continuam obrigatórios.",
                "escolha": "Ative se Meta ou LinkedIn precisam de política própria de carregamento.",
                "vantagens": "Permite adiar cada SDK com o mesmo contrato de consentimento.",
                "limitacoes": "A configuração não controla SDK instalado diretamente pelo tema.",
                "exemplo": "Herdar acompanha a política Google; exceções têm prazo próprio.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "meta": {
            "tipo": "enum",
            "rotulo": "Meta",
            "descricao": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "impacto": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "exemplo": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "opcoes": {
                "herdar": "Herdar Google",
                "imediato": "Após consentimento",
                "apos_interacao": "Após interação",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Herdar usa modo e prazo Google. Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load, tempo livre ou prazo.",
                "escolha": "Escolha uma exceção apenas para este destino quando precisar de outra cadência.",
                "vantagens": "Permite reduzir competição com os recursos iniciais da página.",
                "limitacoes": "Visitas curtas podem terminar antes da carga; timers podem atrasar em abas suspensas. Consentimento continua obrigatório.",
                "exemplo": "Ocioso, prazo próprio de 3 segundos.",
                "vazio": "Campo ausente herda Google; a atualização preserva o valor configurado."
            }
        },
        "meta_teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo próprio de Meta (segundos)",
            "descricao": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "impacto": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "ajuda": {
                "funcionamento": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
                "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
                "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
                "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": []
        },
        "linkedin": {
            "tipo": "enum",
            "rotulo": "Linkedin",
            "descricao": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "impacto": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "exemplo": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "opcoes": {
                "herdar": "Herdar Google",
                "imediato": "Após consentimento",
                "apos_interacao": "Após interação",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Herdar usa modo e prazo Google. Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load, tempo livre ou prazo.",
                "escolha": "Escolha uma exceção apenas para este destino quando precisar de outra cadência.",
                "vantagens": "Permite reduzir competição com os recursos iniciais da página.",
                "limitacoes": "Visitas curtas podem terminar antes da carga; timers podem atrasar em abas suspensas. Consentimento continua obrigatório.",
                "exemplo": "Ocioso, prazo próprio de 3 segundos.",
                "vazio": "Campo ausente herda Google; a atualização preserva o valor configurado."
            }
        },
        "linkedin_teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo próprio de Linkedin (segundos)",
            "descricao": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "impacto": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "ajuda": {
                "funcionamento": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
                "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
                "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
                "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": []
        },
        "clarity": {
            "tipo": "enum",
            "rotulo": "Clarity",
            "descricao": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "impacto": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "exemplo": "Herdar acompanha modo e prazo Google. Ocioso aguarda load e uma oportunidade livre, com prazo garantido quando a aba está ativa; interação usa gesto ou prazo. Adiar reduz trabalho inicial e pode perder visitas curtas. Consentimento continua obrigatório.",
            "opcoes": {
                "herdar": "Herdar Google",
                "imediato": "Após consentimento",
                "apos_interacao": "Após interação",
                "ocioso": "Após load, em tempo ocioso ou prazo"
            },
            "ajuda": {
                "funcionamento": "Herdar usa modo e prazo Google. Imediato libera após consentimento; Após interação usa gesto ou prazo; Ocioso aguarda load, tempo livre ou prazo.",
                "escolha": "Escolha uma exceção apenas para este destino quando precisar de outra cadência.",
                "vantagens": "Permite reduzir competição com os recursos iniciais da página.",
                "limitacoes": "Visitas curtas podem terminar antes da carga; timers podem atrasar em abas suspensas. Consentimento continua obrigatório.",
                "exemplo": "Ocioso, prazo próprio de 3 segundos.",
                "vazio": "Campo ausente herda Google; a atualização preserva o valor configurado."
            }
        },
        "clarity_teto_segundos": {
            "tipo": "inteiro",
            "rotulo": "Prazo próprio de Clarity (segundos)",
            "descricao": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "impacto": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
            "ajuda": {
                "funcionamento": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
                "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
                "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
                "exemplo": "De 1 a 30 segundos após load. Só vale para uma exceção; Herdar usa o prazo Google.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": []
        }
    },
    "ajuda": {
        "funcionamento": "Carregamento por destino",
        "escolha": "Use Herdar para acompanhar a política Google existente; grave uma exceção apenas quando o destino precisar de outro prazo de liberação.",
        "vantagens": "Aplica a mesma regra de fila, interação e consentimento a Meta, LinkedIn e Clarity.",
        "limitacoes": "Uma exceção imediata pode aumentar trabalho na abertura. Alterar esta opção não modifica um contêiner GTM independente.",
        "exemplo": "Meta em Herdar acompanha Após interação; LinkedIn pode ter exceção Imediato se essa for a decisão do site.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_redirects_hosts

```json
{
    "rotulo": "Hosts HTTPS permitidos nos redirects",
    "descricao": "Lista vazia permite apenas destinos internos. Informe hosts exatos, sem caminhos ou curingas.",
    "campo": "linhas",
    "ajuda": {
        "funcionamento": "Lista vazia permite apenas destinos internos. Informe hosts exatos, sem caminhos ou curingas.",
        "escolha": "Declare apenas hostnames externos HTTPS autorizados, sem protocolo, caminho ou curinga.",
        "vantagens": "Permite destinos externos controlados e verificação de cada salto.",
        "limitacoes": "Subdomínio precisa de entrada própria. Lista vazia proíbe destinos externos; o plugin não adiciona hosts da frota automaticamente.",
        "exemplo": "example.com não autoriza sub.example.com nem example.com.outro.test.",
        "vazio": "Lista vazia é uma escolha explícita e é preservada."
    }
}
```

## f3base_classificacao_acessos

```json
{
    "rotulo": "Classificação de acessos",
    "descricao": "Classificação de acessos",
    "campo": "grupo",
    "subcampos": {
        "ativo": {
            "tipo": "booleano",
            "rotulo": "Classificação atual de acessos",
            "descricao": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
            "impacto": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
            "exemplo": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
            "ajuda": {
                "funcionamento": "Registra versão da regra, corrige slugs longos e separa evidência de automação.",
                "escolha": "Mantenha ativo para classificar assinaturas atuais e evidências de automação.",
                "vantagens": "Distingue robô conhecido, navegador provável e desconhecido.",
                "limitacoes": "User-Agent pode ser imitado; não prova identidade humana.",
                "exemplo": "OpenAI, Claude e Gemini recebem famílias próprias quando a assinatura é observada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "repeticao": {
            "tipo": "booleano",
            "rotulo": "Analisar repetição em janela de 24 horas",
            "descricao": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
            "impacto": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
            "exemplo": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
            "ajuda": {
                "funcionamento": "Guarda somente estado temporário pseudonimizado; periodicidade não comprova identidade.",
                "escolha": "Ative quando padrões temporais ajudarem a investigar automação.",
                "vantagens": "Acrescenta evidência de repetição em janela limitada.",
                "limitacoes": "Periodicidade também pode ter causa legítima; não bloqueia o visitante.",
                "exemplo": "Oito intervalos regulares podem sinalizar automação suspeita.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Classificação de acessos",
        "escolha": "Mantenha classificação e repetição ligadas para distinguir evidências; investigue os resultados antes de sugerir ações no conteúdo.",
        "vantagens": "Separa robôs reconhecidos, navegador provável e desconhecidos, sem promover todo UA desconhecido a humano.",
        "limitacoes": "Assinatura de navegador pode ser imitada. Periodicidade é indício, não prova de pessoa/robô; reprocessar exige logs ainda disponíveis.",
        "exemplo": "Scrapy entra como automação genérica. Um navegador com intervalos exatos recebe evidência separada de repetição.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_navegacao

```json
{
    "rotulo": "Navegação do site",
    "descricao": "Escolha quem administra a navegação e, se necessário, a referência publicada. O tema continua responsável por exibi-la.",
    "campo": "grupo",
    "subcampos": {
        "schema": {
            "tipo": "inteiro",
            "rotulo": "Versão do formato",
            "ajuda": {
                "funcionamento": "Versão do formato",
                "escolha": "Versão do contrato, fixada em 1. Não é uma preferência visual.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        },
        "tipo": {
            "tipo": "enum",
            "rotulo": "Origem da navegação",
            "opcoes": {
                "tema": "Administrada pelo tema",
                "menu_classico": "Menu clássico",
                "bloco": "Bloco de navegação"
            },
            "ajuda": {
                "funcionamento": "Origem da navegação",
                "escolha": "Use Tema quando não precisar entregar uma referência ao consumidor. Escolha Menu clássico ou Bloco conforme o conteúdo existente.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        },
        "id": {
            "tipo": "inteiro",
            "rotulo": "Referência selecionada",
            "ajuda": {
                "funcionamento": "Referência selecionada",
                "escolha": "Pesquise pelo nome e confira o ID e o tipo. IDs de termos e posts pertencem a espaços diferentes.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Escolha quem administra a navegação e, se necessário, a referência publicada. O tema continua responsável por exibi-la.",
        "escolha": "Tema usa a navegação já administrada pelo tema. Menu clássico seleciona um termo nav_menu; Bloco seleciona wp_navigation publicado.",
        "vantagens": "Aceita menu clássico sem criar bloco órfão.",
        "limitacoes": "A referência não altera templates, localizações nem prova uso no cabeçalho.",
        "exemplo": "Menu clássico — 92: Principal. Confirme a associação e a página renderizada.",
        "vazio": "Ausente herda o padrão declarado; um valor explícito permanece até uma edição confirmada."
    },
    "estrutura": {
        "schema": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "schema",
                "escolha": "Versão do contrato, fixada em 1. Não é uma preferência visual.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        },
        "tipo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "tipo",
                "escolha": "Use Tema quando não precisar entregar uma referência ao consumidor. Escolha Menu clássico ou Bloco conforme o conteúdo existente.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        },
        "id": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "id",
                "escolha": "Pesquise pelo nome e confira o ID e o tipo. IDs de termos e posts pertencem a espaços diferentes.",
                "vantagens": "Evita que um número válido de outro tipo seja aceito como navegação.",
                "limitacoes": "O tema é responsável pela renderização e pelos locais do menu.",
                "exemplo": "{\"schema\":1,\"tipo\":\"menu_classico\",\"id\":92}",
                "vazio": "Tema exige id=0; os demais tipos exigem referência existente."
            }
        }
    }
}
```

## f3base_pipedrive

```json
{
    "rotulo": "Pipedrive",
    "descricao": "Preferência deste site. Configure em F3 Base → Configurações → Conexões e entregas. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "sem_nome": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "sem_nome",
                "escolha": "Ajuste este campo conforme a operação de sem_nome neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "modelo_nome": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Modelo usado somente para contato sem nome quando o envio for autorizado. Variáveis: {empresa}, {email}, {telefone}, {formulario}. Não renomeia pessoa existente.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Contato {empresa} — {telefone}",
                "vazio": "Vazio usa empresa, e-mail ou telefone disponível.",
                "padrao": "{empresa}"
            }
        },
        "identidade_telefone": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Usa o telefone normalizado para procurar pessoa existente e detectar conflito com e-mail. Sem essa opção, o número permanece como dado de contato.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Número brasileiro com DDD é normalizado usando pais_telefone=BR; não há fusão automática.",
                "vazio": "Ausente herda true; false desativa a busca por telefone.",
                "padrao": "true"
            }
        },
        "linkedin_modo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Define onde guardar a URL do perfil profissional LinkedIn informada pela pessoa: nenhum conserva na nota; campo exige mapa_pessoa.linkedin; automatico exige único candidato textual no catálogo. Não consulta a rede social.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "campo e mapa_pessoa.linkedin com a chave de um campo textual de pessoa.",
                "vazio": "Ausente usa campo; sem campo escolhido a configuração precisa ser completada antes do uso.",
                "padrao": "campo"
            }
        },
        "orcamento_qualidade_diario": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "orcamento_qualidade_diario",
                "escolha": "Ajuste este campo conforme a operação de orcamento_qualidade_diario neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "orcamento_verificacao_diario": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Cota local de verificação de credencial e catálogo, separada da cota de entregas; não aumenta a cota global da conta.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "600 unidades por dia UTC; ao esgotar, aguarda o próximo período.",
                "vazio": "Ausente usa 600; vazio e zero são inválidos.",
                "padrao": "600"
            }
        },
        "pais_telefone": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "pais_telefone",
                "escolha": "Ajuste este campo conforme a operação de pais_telefone neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "modelo_titulo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "modelo_titulo",
                "escolha": "Ajuste este campo conforme a operação de modelo_titulo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "site_alternativa": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "site_alternativa",
                "escolha": "Ajuste este campo conforme a operação de site_alternativa neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "rotulo_pessoa": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "rotulo_pessoa",
                "escolha": "Ajuste este campo conforme a operação de rotulo_pessoa neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_pessoa": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "mapa_pessoa",
                "escolha": "Ajuste este campo conforme a operação de mapa_pessoa neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_respostas": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "mapa_respostas",
                "escolha": "Ajuste este campo conforme a operação de mapa_respostas neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "ativo": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Ative após preparar credencial, conta e mapeamentos. Desligar pausa a entrega; mantém os registros e a fila.",
                "escolha": "Ative após preparar credencial, conta e mapeamentos. Desligar pausa a entrega; mantém os registros e a fila.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "dominio": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Somente empresa.pipedrive.com, sem https ou caminho. Alterar a conta suspende entregas já vinculadas à anterior.",
                "escolha": "Somente empresa.pipedrive.com, sem https ou caminho. Alterar a conta suspende entregas já vinculadas à anterior.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "responsavel": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Escolha um usuário ativo da conta verificada. O plugin não troca o responsável de oportunidades existentes.",
                "escolha": "Escolha um usuário ativo da conta verificada. O plugin não troca o responsável de oportunidades existentes.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "rotulo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Etiqueta apenas novos leads; preserva as etiquetas de leads próprios reutilizados.",
                "escolha": "Etiqueta apenas novos leads; preserva as etiquetas de leads próprios reutilizados.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "unidade": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ID de alternativa do campo Unidade. Deve existir na conta; não é um texto livre nem ID de usuário.",
                "escolha": "ID de alternativa do campo Unidade. Deve existir na conta; não é um texto livre nem ID de usuário.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_campos": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Objeto com papéis unidade, canal, parceiro, ponto, servico, campanha, anuncio e cargo. Cada valor é a chave de 40 caracteres de um campo existente. Exemplo: {\"servico\":\"chave_do_campo\"}. Sem mapa, a informação permanece na nota.",
                "escolha": "Objeto com papéis unidade, canal, parceiro, ponto, servico, campanha, anuncio e cargo. Cada valor é a chave de 40 caracteres de um campo existente. Exemplo: {\"servico\":\"chave_do_campo\"}. Sem mapa, a informação permanece na nota.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_servicos": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Objeto: resposta estável ou formulario:resposta → ID de opção. Exemplo: {\"consultoria\":\"98\"}. Seleção múltipla envia todos os IDs conhecidos; valores desconhecidos ficam na nota.",
                "escolha": "Objeto: resposta estável ou formulario:resposta → ID de opção. Exemplo: {\"consultoria\":\"98\"}. Seleção múltipla envia todos os IDs conhecidos; valores desconhecidos ficam na nota.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_parceiros": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Chaves reservadas: sem_campanha (origem observada sem campanha), fora_do_padrao (campanha ou parceiro fora da convenção) e origem_nao_observada (informação indisponível). Exemplo: {\"sem_campanha\":\"1\",\"fora_do_padrao\":\"2\",\"origem_nao_observada\":\"3\"}. A ausência de informação não comprova tráfego orgânico.",
                "escolha": "Chaves reservadas: sem_campanha (origem observada sem campanha), fora_do_padrao (campanha ou parceiro fora da convenção) e origem_nao_observada (informação indisponível). Exemplo: {\"sem_campanha\":\"1\",\"fora_do_padrao\":\"2\",\"origem_nao_observada\":\"3\"}. A ausência de informação não comprova tráfego orgânico.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_canais": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Objeto: meta_ads, google_ads, linkedin_ads, openai_ads, nao_identificada → IDs da sua conta. Ausência de atribuição não comprova origem orgânica.",
                "escolha": "Objeto: meta_ads, google_ads, linkedin_ads, openai_ads, nao_identificada → IDs da sua conta. Ausência de atribuição não comprova origem orgânica.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_pontos": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Objeto: site, whatsapp_formulario, nativo → IDs. Cliques anônimos não criam pessoa fictícia no CRM.",
                "escolha": "Objeto: site, whatsapp_formulario, nativo → IDs. Cliques anônimos não criam pessoa fictícia no CRM.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "atividade": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Somente para lead novo e sem tarefa pendente equivalente. Pode aumentar o volume de tarefas; desligado não remove as existentes.",
                "escolha": "Somente para lead novo e sem tarefa pendente equivalente. Pode aumentar o volume de tarefas; desligado não remove as existentes.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "atividade_tipo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Tipo já cadastrado no CRM. A seleção será conferida com a conta.",
                "escolha": "Tipo já cadastrado no CRM. A seleção será conferida com a conta.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "homologacao": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Permite entregar contatos marcados como teste ao CRM. A marca continua visível e o registro é separado dos totais comerciais.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Ative em conta de homologação para validar o fluxo completo.",
                "vazio": "Ausente ou false impede o envio de teste ao CRM.",
                "padrao": "false"
            }
        },
        "orcamento_local_diario": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Cota conservadora deste site, compartilhada entre verificações e entregas. A conta tem um orçamento global próprio. Ao atingir o teto, a fila aguarda o próximo dia UTC.",
                "escolha": "Cota conservadora deste site, compartilhada entre verificações e entregas. A conta tem um orçamento global próprio. Ao atingir o teto, a fila aguarda o próximo dia UTC.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "retencao_entregas_dias": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Prazo do detalhe operacional; vínculos essenciais e pendências de eliminação permanecem para deduplicação e revisão. Não define a retenção comercial no Pipedrive.",
                "escolha": "Prazo do detalhe operacional; vínculos essenciais e pendências de eliminação permanecem para deduplicação e revisão. Não define a retenção comercial no Pipedrive.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "parceiros_plataforma": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "parceiros_plataforma",
                "escolha": "Ajuste este campo conforme a operação de parceiros_plataforma neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "campos_fixos": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "campos_fixos",
                "escolha": "Ajuste este campo conforme a operação de campos_fixos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "whatsapp_texto": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "whatsapp_texto",
                "escolha": "Ajuste este campo conforme a operação de whatsapp_texto neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "empresas_invalidas": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "empresas_invalidas",
                "escolha": "Ajuste este campo conforme a operação de empresas_invalidas neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "mapa_servicos_formularios": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "mapa_servicos_formularios",
                "escolha": "Ajuste este campo conforme a operação de mapa_servicos_formularios neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapa_servicos_campanhas": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "mapa_servicos_campanhas",
                "escolha": "Ajuste este campo conforme a operação de mapa_servicos_campanhas neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "atividade_canais": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "atividade_canais",
                "escolha": "Ajuste este campo conforme a operação de atividade_canais neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "whatsapp": {
                    "tipo": "object",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "whatsapp",
                        "escolha": "Ajuste este campo conforme a operação de whatsapp neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    },
                    "estrutura": {
                        "tipo": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "tipo",
                                "escolha": "Ajuste este campo conforme a operação de tipo neste site.",
                                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                                "exemplo": "",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "assunto": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "assunto",
                                "escolha": "Ajuste este campo conforme a operação de assunto neste site.",
                                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                                "exemplo": "",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        }
                    }
                },
                "email": {
                    "tipo": "object",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "email",
                        "escolha": "Ajuste este campo conforme a operação de email neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    },
                    "estrutura": {
                        "tipo": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "tipo",
                                "escolha": "Ajuste este campo conforme a operação de tipo neste site.",
                                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                                "exemplo": "",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "assunto": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "assunto",
                                "escolha": "Ajuste este campo conforme a operação de assunto neste site.",
                                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                                "exemplo": "",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        }
                    }
                },
                "task": {
                    "tipo": "object",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "task",
                        "escolha": "Ajuste este campo conforme a operação de task neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    },
                    "estrutura": {
                        "tipo": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "tipo",
                                "escolha": "Ajuste este campo conforme a operação de tipo neste site.",
                                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                                "exemplo": "",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        },
                        "assunto": {
                            "tipo": "string",
                            "padrao": null,
                            "ajuda": {
                                "funcionamento": "assunto",
                                "escolha": "Ajuste este campo conforme a operação de assunto neste site.",
                                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                                "exemplo": "",
                                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                            }
                        }
                    }
                }
            }
        },
        "atividade_janela": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "atividade_janela",
                "escolha": "Ajuste este campo conforme a operação de atividade_janela neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "fuso": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "fuso",
                        "escolha": "Ajuste este campo conforme a operação de fuso neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "dias": {
                    "tipo": "array",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "dias",
                        "escolha": "Ajuste este campo conforme a operação de dias neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    },
                    "estrutura": {
                        "itens": []
                    }
                },
                "inicio": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "inicio",
                        "escolha": "Ajuste este campo conforme a operação de inicio neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "fim": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "fim",
                        "escolha": "Ajuste este campo conforme a operação de fim neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "minutos": {
                    "tipo": "integer",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "minutos",
                        "escolha": "Ajuste este campo conforme a operação de minutos neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "retomada": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": "retomada",
                        "escolha": "Ajuste este campo conforme a operação de retomada neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            }
        }
    }
}
```

## f3base_anuncios_meta

```json
{
    "rotulo": "Meta — formulários nativos",
    "descricao": "Preferência deste site. Configure em F3 Base → Configurações → Conexões e entregas. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Importa contatos nativos Meta. O alerta operacional do item 182 acompanha ativo=true, sem switch separado: usa f3base_avisos.canal e as credenciais já configuradas; envia e-mail aos f3base_contato.email_leads como contingência. Não cria contato nem conversão.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Origem desligada não dispara acompanhamento de captação; destino externo incompleto pode cair no e-mail geral.",
        "padrao": "ativo=false; demais padrões no schema"
    },
    "estrutura": {
        "ativo": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Ative após preparar credencial, conta e mapeamentos. Desligar pausa a entrega; mantém os registros e a fila.",
                "escolha": "Ative após preparar credencial, conta e mapeamentos. Desligar pausa a entrega; mantém os registros e a fila.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "versao_api": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Versão fixada para chamadas à Meta. Trocar exige homologar permissões e payloads; não atualiza silenciosamente.",
                "escolha": "Versão fixada para chamadas à Meta. Trocar exige homologar permissões e payloads; não atualiza silenciosamente.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "paginas": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Uma ID por linha. A consulta descobre os formulários dessas páginas e confere acesso. Não autoriza páginas não relacionadas.",
                "escolha": "Uma ID por linha. A consulta descobre os formulários dessas páginas e confere acesso. Não autoriza páginas não relacionadas.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "formularios_modo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "formularios_modo",
                "escolha": "Ajuste este campo conforme a operação de formularios_modo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "formularios": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Uma ID por linha. Lista vazia não importa nada. Evite cadastrar o mesmo formulário em outro site.",
                "escolha": "Uma ID por linha. Lista vazia não importa nada. Evite cadastrar o mesmo formulário em outro site.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "conta_id": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Guarde o identificador da conta como texto, inclusive IDs grandes. A chave Google e os lotes autenticados devem corresponder a esta origem.",
                "escolha": "Guarde o identificador da conta como texto, inclusive IDs grandes. A chave Google e os lotes autenticados devem corresponder a esta origem.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapeamento": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Objeto com campos e campanhas. Exemplo: {\"campos\":{\"seu_email\":\"email\"},\"campanhas\":{\"123\":\"unidade_parceiro_objetivo_202609\"}}. Nomes ausentes não impedem a captura.",
                "escolha": "Objeto com campos e campanhas. Exemplo: {\"campos\":{\"seu_email\":\"email\"},\"campanhas\":{\"123\":\"unidade_parceiro_objetivo_202609\"}}. Nomes ausentes não impedem a captura.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "proprietario_confirmado": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Declara que este site é responsável por importar os formulários selecionados, após conferir os demais sites. Não coordena instalações automaticamente.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Confirme somente depois de revisar conta, páginas/formulários e os outros sites.",
                "vazio": "Ausente ou false impede ativação da importação.",
                "padrao": "false"
            }
        }
    }
}
```

## f3base_anuncios_google

```json
{
    "rotulo": "Google Ads — formulários nativos",
    "descricao": "Preferência deste site. Configure em F3 Base → Configurações → Conexões e entregas. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "ativo": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Ative após preparar credencial, conta e mapeamentos. Desligar pausa a entrega; mantém os registros e a fila.",
                "escolha": "Ative após preparar credencial, conta e mapeamentos. Desligar pausa a entrega; mantém os registros e a fila.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conta_id": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Guarde o identificador da conta como texto, inclusive IDs grandes. A chave Google e os lotes autenticados devem corresponder a esta origem.",
                "escolha": "Guarde o identificador da conta como texto, inclusive IDs grandes. A chave Google e os lotes autenticados devem corresponder a esta origem.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "formularios": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Uma ID por linha. Lista vazia não importa nada. Evite cadastrar o mesmo formulário em outro site.",
                "escolha": "Uma ID por linha. Lista vazia não importa nada. Evite cadastrar o mesmo formulário em outro site.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "campanhas": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Lista explícita para lead_source=CONVERSATIONAL_AGENT sem form_id. Uma ID por linha; lista vazia recusa esse caso. Formulários tradicionais continuam exigindo ID autorizada.",
                "escolha": "Lista explícita para lead_source=CONVERSATIONAL_AGENT sem form_id. Uma ID por linha; lista vazia recusa esse caso. Formulários tradicionais continuam exigindo ID autorizada.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "modo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Webhook recebe imediatamente quando a hospedagem permite. Reconciliação exige produtor externo/API, com execução ao menos diária. Ambos usam a mesma identidade do contato.",
                "escolha": "Webhook recebe imediatamente quando a hospedagem permite. Reconciliação exige produtor externo/API, com execução ao menos diária. Ambos usam a mesma identidade do contato.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "mapeamento": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Objeto com campos e campanhas. Exemplo: {\"campos\":{\"seu_email\":\"email\"},\"campanhas\":{\"123\":\"unidade_parceiro_objetivo_202609\"}}. Nomes ausentes não impedem a captura.",
                "escolha": "Objeto com campos e campanhas. Exemplo: {\"campos\":{\"seu_email\":\"email\"},\"campanhas\":{\"123\":\"unidade_parceiro_objetivo_202609\"}}. Nomes ausentes não impedem a captura.",
                "vantagens": "O registro local e a entrega têm estados independentes e podem ser conferidos em Contatos → Integrações → Entregas.",
                "limitacoes": "Conta, permissões, mapeamentos e executor devem ser verificados. Salvar a preferência não comprova aceitação remota.",
                "exemplo": "Prepare com a integração desligada e utilize dados sintéticos em uma conta de homologação.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "proprietario_confirmado": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Declara que este site é responsável por importar os formulários selecionados, após conferir os demais sites. Não coordena instalações automaticamente.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Confirme somente depois de revisar conta, páginas/formulários e os outros sites.",
                "vazio": "Ausente ou false impede ativação da importação.",
                "padrao": "false"
            }
        }
    }
}
```

## f3base_anuncios_linkedin

```json
{
    "rotulo": "LinkedIn — integrações de formulários",
    "descricao": "Preferência deste site. Configure em F3 Base → Configurações → Conexões e entregas. Ativação depende de conta e acesso confirmados.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Conecta novos registros elegíveis à origem ou destino configurado; não envia histórico anterior à ativação.",
        "escolha": "Configure conta, escopo, credencial e mapeamentos; habilite depois de conferir a política do site.",
        "vantagens": "Mantém os contatos organizados com identidade nativa e estado de entrega.",
        "limitacoes": "Disponibilidade externa e cadência podem atrasar os registros; consulte o diagnóstico e os limites da origem.",
        "exemplo": "Ativo=false prepara a configuração sem iniciar a captura ou entrega.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "integracoes": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "integracoes",
                "escolha": "Ajuste este campo conforme a operação de integracoes neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_c0_smtp_senha

```json
{
    "rotulo": "Credencial de c0 smtp senha",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Ajuste este campo conforme a operação de Credencial de c0 smtp senha neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_meta_crm_token

```json
{
    "rotulo": "Credencial de meta crm token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Token Meta exclusivo para retorno de qualidade comercial quando credencial=propria. Com credencial compartilhada usa o token CAPI. Segredo cifrado, nunca reapresentado.",
        "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
        "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
        "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
        "exemplo": "Cole o token na área de qualidade do wp-admin; confira dataset e acesso sem expor o valor ao agente.",
        "vazio": "Campo de senha deixado em branco na tela conserva o segredo. Use a ação explícita de remoção para apagá-lo.",
        "padrao": "ausente"
    },
    "estrutura": []
}
```

## f3base_pipedrive_webhook_segredo

```json
{
    "rotulo": "Credencial de pipedrive webhook segredo",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Segredo que autentica os recebimentos do webhook Pipedrive, distinto do token usado para enviar ao CRM.",
        "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
        "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
        "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
        "exemplo": "Configure a credencial correspondente no webhook e confira um recibo sem divulgar o valor.",
        "vazio": "Em branco na tela preserva o segredo; removê-lo impede autenticar novos recebimentos.",
        "padrao": "ausente"
    },
    "estrutura": []
}
```

## f3base_slack_bot_token

```json
{
    "rotulo": "Token do bot Slack",
    "descricao": "F3 Base → Configurações → Conexões e entregas → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de Token do bot Slack neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_avisos_webhook_url

```json
{
    "rotulo": "URL do receptor JSON",
    "descricao": "F3 Base → Configurações → Conexões e entregas → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de URL do receptor JSON neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_avisos_webhook_chave

```json
{
    "rotulo": "Chave HMAC do receptor JSON",
    "descricao": "F3 Base → Configurações → Conexões e entregas → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de Chave HMAC do receptor JSON neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_slack_webhook

```json
{
    "rotulo": "Webhook de entrada do Slack",
    "descricao": "F3 Base → Configurações → Conexões e entregas → Avisos. O dono cola o segredo; vazio mantém, apagar é explícito. Valor cifrado e nunca reapresentado.",
    "campo": "segredo",
    "impacto": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
    "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
    "ajuda": {
        "funcionamento": "Habilita o transporte escolhido para novas capturas. Alterar credencial não redireciona pendências; exige reenvio explícito.",
        "escolha": "Ajuste este campo conforme a operação de Webhook de entrada do Slack neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Consulte docs/AVISOS-WEBHOOK-1.26.md; nunca encaminhe a credencial ao agente.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_clarity_api_token

```json
{
    "rotulo": "Token de exportação do Clarity",
    "descricao": "Cole o token gerado em Settings → Data Export do projeto acima. É cifrado no servidor e nunca reapresentado. Salve primeiro; depois use Testar token e coletar agora.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Campo em Site Core → Configurações → Medição e anúncios → Clarity. Autoriza o servidor a consultar o histórico analítico do Clarity. É separado do ID público que instala a tag no navegador. O token é cifrado e não reaparece no formulário, relatório ou contrato.",
        "escolha": "No Clarity, abra o projeto deste site → Settings → Data Export → Generate new API token. Cole somente o token aqui, salve e use Testar token e coletar agora. Não envie a credencial ao agente.",
        "vantagens": "Permite cadastrar a credencial diretamente no wp-admin e preservar o acervo local, sem depender do canal para transportar segredos.",
        "limitacoes": "O teste consome uma das duas consultas manuais reservadas por dia, dentro de dez por projeto. Oito ficam para a coleta automática. Outros consumidores compartilham a cota do fornecedor. O vínculo ao projeto é local; a API não informa a identidade do projeto na resposta.",
        "exemplo": "Preencha o ID do projeto e seu token, salve e teste. A consulta das últimas 24 horas por URL aparece em Medição → Clarity. Trocar o ID exige cadastrar novamente o token do projeto correspondente.",
        "vazio": "Campo vazio mantém o token salvo; marque Apagar o valor gravado para removê-lo. Sem token vinculado não há coleta de exportação. A tag depende do ID e do consentimento, separadamente."
    },
    "estrutura": []
}
```

## f3base_pipedrive_token

```json
{
    "rotulo": "Credencial de pipedrive token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    },
    "estrutura": []
}
```

## f3base_anuncios_meta_token

```json
{
    "rotulo": "Credencial de anuncios meta token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    },
    "estrutura": []
}
```

## f3base_anuncios_google_chave

```json
{
    "rotulo": "Credencial de anuncios google chave",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    },
    "estrutura": []
}
```

## f3base_anuncios_linkedin_token

```json
{
    "rotulo": "Credencial de anuncios linkedin token",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Obtenha a credencial na conta autorizada e use somente o campo privado da integração.",
        "vantagens": "Permite autenticar o adaptador no servidor sem expor a credencial ao visitante.",
        "limitacoes": "Cifra depende dos salts; troca de salts exige recadastro. Banco cifrado não protege um servidor comprometido.",
        "exemplo": "Campo vazio no editor de integração mantém a credencial; Apagar remove. Nunca cole segredo em documentação.",
        "vazio": "Ausente fica desconfigurado; a API de opções recebe string vazia para apagar explicitamente."
    },
    "estrutura": []
}
```

## f3base_anuncios_linkedin_client_secret

```json
{
    "rotulo": "Credencial de anuncios linkedin client secret",
    "descricao": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
    "campo": "segredo",
    "ajuda": {
        "funcionamento": "Valor privado; vazio no formulário mantém o atual. Marque apagar para revogar localmente.",
        "escolha": "Ajuste este campo conforme a operação de Credencial de anuncios linkedin client secret neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_avisos

```json
{
    "rotulo": "Canal dos avisos internos",
    "descricao": "E-mail, Slack ou webhook JSON; e-mail pode acompanhar o destino externo; novas capturas guardam a escolha. Regras de clique e formulário são comuns. Contatos anteriores não são reenviados ao mudar o canal.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "E-mail, Slack ou webhook JSON; e-mail pode acompanhar o destino externo; novas capturas guardam a escolha. Regras de clique e formulário são comuns. Contatos anteriores não são reenviados ao mudar o canal.",
        "escolha": "Ajuste este campo conforme a operação de Canal dos avisos internos neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "canal": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "canal",
                "escolha": "Ajuste este campo conforme a operação de canal neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "slack_transporte": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "slack_transporte",
                "escolha": "Ajuste este campo conforme a operação de slack_transporte neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "slack_formato": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "slack_formato",
                "escolha": "Ajuste este campo conforme a operação de slack_formato neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "slack_canal_id": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "slack_canal_id",
                "escolha": "Ajuste este campo conforme a operação de slack_canal_id neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_qualidade

```json
{
    "rotulo": "Qualidade e retorno à Meta",
    "descricao": "Mapa exclusivo deste site: etapas locais, funis Pipedrive e eventos Meta. Nenhum mapa comercial é aplicado automaticamente.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "Mapa exclusivo deste site: etapas locais, funis Pipedrive e eventos Meta. Nenhum mapa comercial é aplicado automaticamente.",
        "escolha": "Ajuste este campo conforme a operação de Qualidade e retorno à Meta neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "credencial": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "credencial",
                "escolha": "Ajuste este campo conforme a operação de credencial neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "ativo": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ativo",
                "escolha": "Ajuste este campo conforme a operação de ativo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "meta_ativo": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "meta_ativo",
                "escolha": "Ajuste este campo conforme a operação de meta_ativo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "dataset": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "dataset",
                "escolha": "Ajuste este campo conforme a operação de dataset neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "versao_api": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "versao_api",
                "escolha": "Ajuste este campo conforme a operação de versao_api neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "precedencia": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "precedencia",
                "escolha": "Ajuste este campo conforme a operação de precedencia neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "etapas": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "etapas",
                "escolha": "Ajuste este campo conforme a operação de etapas neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "regras": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "regras",
                "escolha": "Ajuste este campo conforme a operação de regras neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "consentimentos_nativos": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Evidências declaradas para formulários nativos. Complementam a documentação da autorização; não anulam negativa conhecida. A política pré-autorizada não exige preencher todos os formulários.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Confira o schema e registre evidência real para a origem/formulário correspondente.",
                "vazio": "Vazio não inventa aceite individual. No modo exigir_decisao, ausência de prova continua restritiva.",
                "padrao": "[]"
            }
        },
        "campo_meta_id": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "Chave de campo textual do lead no Pipedrive que receberá o ID original do lead nativo Meta.",
                "escolha": "Escolha conforme o fluxo descrito; confira a prévia e o diagnóstico antes de ativar entregas.",
                "vantagens": "Torna a decisão explícita e consultável pela equipe e pelos agentes.",
                "limitacoes": "A preferência não comprova entrega externa nem desfaz ações anteriores.",
                "exemplo": "Chave de 40 caracteres de campo text, varchar ou varchar_auto da conta.",
                "vazio": "Vazio não grava o ID em campo estruturado; a referência permanece no contexto/nota.",
                "padrao": "vazio"
            }
        }
    }
}
```

## f3base_conversoes

```json
{
    "rotulo": "Contagem de conversões",
    "descricao": "Uma aquisição por continuidade do contato na sessão evita somar formulário e clique no WhatsApp. Todas as ações permanecem no histórico de comportamento.",
    "campo": "grupo",
    "subcampos": {
        "modo": {
            "tipo": "select",
            "rotulo": "Quando contar nova conversão",
            "opcoes": {
                "contato_sessao": "Uma por contato na sessão",
                "por_acao": "Cada ação elegível"
            },
            "ajuda": {
                "funcionamento": "Quando contar nova conversão",
                "escolha": "Escolha uma das alternativas exibidas. Cada alternativa muda o funcionamento descrito acima; uma opção gravada é preservada nas atualizações.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Uma por contato na sessão ou Cada ação elegível",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Uma aquisição por continuidade do contato na sessão evita somar formulário e clique no WhatsApp. Todas as ações permanecem no histórico de comportamento.",
        "escolha": "Ajuste este campo conforme a operação de Contagem de conversões neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "modo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "modo",
                "escolha": "Ajuste este campo conforme a operação de modo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_conversoes_conteudo

```json
{
    "rotulo": "Conversões de material",
    "descricao": "Escolha quais plataformas recebem o aceite de formulários do regime conteúdo. GA4: download_material; Meta: MaterialDownload. Google Ads e LinkedIn exigem a ação própria de material.",
    "campo": "grupo",
    "subcampos": {
        "ga4": {
            "tipo": "booleano",
            "rotulo": "GA4 — evento de material",
            "descricao": "Ativa somente a conversão de material neste destino, respeitando consentimento, modo de teste e identificadores próprios.",
            "impacto": "Desligado por padrão. Não reaproveita a conversão de contato.",
            "ajuda": {
                "funcionamento": "Desligado por padrão. Não reaproveita a conversão de contato.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "meta": {
            "tipo": "booleano",
            "rotulo": "Meta — evento de material",
            "descricao": "Ativa somente a conversão de material neste destino, respeitando consentimento, modo de teste e identificadores próprios.",
            "impacto": "Desligado por padrão. Não reaproveita a conversão de contato.",
            "ajuda": {
                "funcionamento": "Desligado por padrão. Não reaproveita a conversão de contato.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "google_ads": {
            "tipo": "booleano",
            "rotulo": "Google Ads — conversão de material",
            "descricao": "Ativa somente a conversão de material neste destino, respeitando consentimento, modo de teste e identificadores próprios.",
            "impacto": "Desligado por padrão. Não reaproveita a conversão de contato.",
            "ajuda": {
                "funcionamento": "Desligado por padrão. Não reaproveita a conversão de contato.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "linkedin": {
            "tipo": "booleano",
            "rotulo": "LinkedIn — conversão de material",
            "descricao": "Ativa somente a conversão de material neste destino, respeitando consentimento, modo de teste e identificadores próprios.",
            "impacto": "Desligado por padrão. Não reaproveita a conversão de contato.",
            "ajuda": {
                "funcionamento": "Desligado por padrão. Não reaproveita a conversão de contato.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Escolha quais plataformas recebem o aceite de formulários do regime conteúdo. GA4: download_material; Meta: MaterialDownload. Google Ads e LinkedIn exigem a ação própria de material.",
        "escolha": "Ajuste este campo conforme a operação de Conversões de material neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "ga4": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ga4",
                "escolha": "Ajuste este campo conforme a operação de ga4 neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "meta": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "meta",
                "escolha": "Ajuste este campo conforme a operação de meta neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "google_ads": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "google_ads",
                "escolha": "Ajuste este campo conforme a operação de google_ads neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "linkedin": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "linkedin",
                "escolha": "Ajuste este campo conforme a operação de linkedin neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_linkedin_conteudo_conversion_id

```json
{
    "rotulo": "LinkedIn — conversão de material",
    "descricao": "ID exclusivo da conversão de material.",
    "campo": "texto",
    "impacto": "Vazio ou com destino de material desligado, não envia conversão de material ao LinkedIn. O ID de contato nunca serve de substituto.",
    "exemplo": "Somente os dígitos da ação Material no Campaign Manager.",
    "ajuda": {
        "funcionamento": "Vazio ou com destino de material desligado, não envia conversão de material ao LinkedIn. O ID de contato nunca serve de substituto.",
        "escolha": "Ajuste este campo conforme a operação de LinkedIn — conversão de material neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Somente os dígitos da ação Material no Campaign Manager.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": []
}
```

## f3base_conversoes_transporte

```json
{
    "rotulo": "Transporte das conversões de contato",
    "descricao": "Escolha independente por destino. Padrão navegador em instalação e atualização.",
    "campo": "grupo",
    "subcampos": {
        "ga4": {
            "tipo": "enum",
            "rotulo": "GA4",
            "descricao": "navegador ou servidor. Servidor exige adaptador pronto.",
            "impacto": "Aplica-se somente a novos contatos; não transfere entregas anteriores.",
            "opcoes": {
                "navegador": "Navegador",
                "servidor": "Servidor"
            },
            "ajuda": {
                "funcionamento": "Aplica-se somente a novos contatos; não transfere entregas anteriores.",
                "escolha": "Escolha uma das alternativas exibidas. Cada alternativa muda o funcionamento descrito acima; uma opção gravada é preservada nas atualizações.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Navegador ou Servidor",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "google_ads": {
            "tipo": "enum",
            "rotulo": "Google Ads",
            "descricao": "navegador ou servidor. Servidor exige adaptador pronto.",
            "impacto": "Aplica-se somente a novos contatos; não transfere entregas anteriores.",
            "opcoes": {
                "navegador": "Navegador",
                "servidor": "Servidor"
            },
            "ajuda": {
                "funcionamento": "Aplica-se somente a novos contatos; não transfere entregas anteriores.",
                "escolha": "Escolha uma das alternativas exibidas. Cada alternativa muda o funcionamento descrito acima; uma opção gravada é preservada nas atualizações.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Navegador ou Servidor",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Escolha independente por destino. Padrão navegador em instalação e atualização.",
        "escolha": "Ajuste este campo conforme a operação de Transporte das conversões de contato neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "ga4": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ga4",
                "escolha": "Ajuste este campo conforme a operação de ga4 neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "google_ads": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "google_ads",
                "escolha": "Ajuste este campo conforme a operação de google_ads neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    }
}
```

## f3base_campanhas_nomes

```json
{
    "rotulo": "Nomes de campanhas por conta",
    "descricao": "Complementa o nome quando o link traz apenas o ID da campanha. Cada linha exige plataforma, conta, campanha e nome. IDs iguais de contas diferentes permanecem separados; nomes recebidos do link são preservados.",
    "campo": "campanhas",
    "exemplo": "[{\"plataforma\":\"meta_ads\",\"conta\":\"123\",\"campanha\":\"456\",\"nome\":\"Campanha de exemplo\"}]",
    "impacto": "Afeta capturas novas. Não renomeia mensagens já enviadas ou snapshots históricos. Evita inferir nomes por anúncio, e-mail ou data.",
    "ajuda": {
        "funcionamento": "Afeta capturas novas. Não renomeia mensagens já enviadas ou snapshots históricos. Evita inferir nomes por anúncio, e-mail ou data.",
        "escolha": "Ajuste este campo conforme a operação de Nomes de campanhas por conta neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "[{\"plataforma\":\"meta_ads\",\"conta\":\"123\",\"campanha\":\"456\",\"nome\":\"Campanha de exemplo\"}]",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "itens": {
            "plataforma": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "plataforma",
                    "escolha": "Ajuste este campo conforme a operação de plataforma neste site.",
                    "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                    "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                    "exemplo": "",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "conta": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "conta",
                    "escolha": "Ajuste este campo conforme a operação de conta neste site.",
                    "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                    "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                    "exemplo": "",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "campanha": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "campanha",
                    "escolha": "Ajuste este campo conforme a operação de campanha neste site.",
                    "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                    "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                    "exemplo": "",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            },
            "nome": {
                "tipo": "string",
                "padrao": null,
                "ajuda": {
                    "funcionamento": "nome",
                    "escolha": "Ajuste este campo conforme a operação de nome neste site.",
                    "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                    "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                    "exemplo": "",
                    "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                }
            }
        }
    }
}
```

## f3base_c0

```json
{
    "rotulo": "C0 — e-mail ao novo lead",
    "descricao": "SMTP DreamHost, caixa korvena@korvena.net.br. Cota conta destinatários e Cco; a soma das cotas dos sites e uso manual deve caber em 100/hora. Textos de serviço exigem aprovação prévia.",
    "campo": "grupo",
    "ajuda": {
        "funcionamento": "SMTP DreamHost, caixa korvena@korvena.net.br. Cota conta destinatários e Cco; a soma das cotas dos sites e uso manual deve caber em 100/hora. Textos de serviço exigem aprovação prévia.",
        "escolha": "Ajuste este campo conforme a operação de C0 — e-mail ao novo lead neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "homologacao_emails": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "homologacao_emails",
                "escolha": "Ajuste este campo conforme a operação de homologacao_emails neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        },
        "ativo": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "ativo",
                "escolha": "Ajuste este campo conforme a operação de ativo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "marca": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "marca",
                "escolha": "Ajuste este campo conforme a operação de marca neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "cota_destinatarios_hora": {
            "tipo": "integer",
            "padrao": null,
            "ajuda": {
                "funcionamento": "cota_destinatarios_hora",
                "escolha": "Ajuste este campo conforme a operação de cota_destinatarios_hora neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "alocacao_confirmada": {
            "tipo": "boolean",
            "padrao": null,
            "ajuda": {
                "funcionamento": "alocacao_confirmada",
                "escolha": "Ajuste este campo conforme a operação de alocacao_confirmada neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "textos_servicos": {
            "tipo": "object",
            "padrao": null,
            "ajuda": {
                "funcionamento": "textos_servicos",
                "escolha": "Ajuste este campo conforme a operação de textos_servicos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "89": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 89,
                        "escolha": "Ajuste este campo conforme a operação de 89 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "90": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 90,
                        "escolha": "Ajuste este campo conforme a operação de 90 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "91": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 91,
                        "escolha": "Ajuste este campo conforme a operação de 91 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "92": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 92,
                        "escolha": "Ajuste este campo conforme a operação de 92 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "93": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 93,
                        "escolha": "Ajuste este campo conforme a operação de 93 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "94": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 94,
                        "escolha": "Ajuste este campo conforme a operação de 94 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "95": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 95,
                        "escolha": "Ajuste este campo conforme a operação de 95 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "96": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 96,
                        "escolha": "Ajuste este campo conforme a operação de 96 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "148": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 148,
                        "escolha": "Ajuste este campo conforme a operação de 148 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                },
                "149": {
                    "tipo": "string",
                    "padrao": null,
                    "ajuda": {
                        "funcionamento": 149,
                        "escolha": "Ajuste este campo conforme a operação de 149 neste site.",
                        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                        "exemplo": "",
                        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
                    }
                }
            }
        }
    }
}
```

## f3base_medicao_editorial

```json
{
    "rotulo": "Conteúdo, audiência e IA",
    "descricao": "Retenção e qualidade dos relatórios editoriais.",
    "campo": "grupo",
    "subcampos": {
        "retencao_meses": {
            "tipo": "inteiro",
            "rotulo": "Meses de agregados editoriais",
            "descricao": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
            "impacto": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
            "exemplo": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
            "ajuda": {
                "funcionamento": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
                "escolha": "Ajuste este campo conforme a operação de Meses de agregados editoriais neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Padrão: 13 meses. Mantém contagens diárias anônimas; sessões individuais seguem a retenção bruta. Um prazo curto explícito é preservado.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "excluir_automacao": {
            "tipo": "booleano",
            "rotulo": "Excluir automação da audiência",
            "descricao": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
            "impacto": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
            "exemplo": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
            "ajuda": {
                "funcionamento": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Exclui sinais declarados e prováveis do resumo. Os registros continuam consultáveis; não identifica humanos nem bloqueia contatos.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "aplicar_anotacoes": {
            "tipo": "booleano",
            "rotulo": "Aplicar exclusões de períodos anotados",
            "descricao": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
            "impacto": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
            "exemplo": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
            "ajuda": {
                "funcionamento": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Padrão ligado. Períodos explicitamente marcados para exclusão ficam fora dos relatórios de audiência e conversão. Dias inteiros podem conter visitantes reais: anote somente testes conhecidos. Dados e contatos são preservados; desmarque o filtro para comparar.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "redes_oficiais": {
            "tipo": "booleano",
            "rotulo": "Conferir listas oficiais dos robôs",
            "descricao": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
            "impacto": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
            "exemplo": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
            "ajuda": {
                "funcionamento": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Atualiza listas públicas diariamente fora da leitura de logs. Compatibilidade de rede não comprova citação ou treinamento.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "ip_log_confiavel": {
            "tipo": "booleano",
            "rotulo": "Log contém o IP de origem confiável",
            "descricao": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
            "impacto": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
            "exemplo": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
            "ajuda": {
                "funcionamento": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ative apenas se o primeiro campo do log for o endereço real validado pelo servidor. Atrás de proxy sem essa garantia, a origem fica não verificável. O Core não persiste esse IP.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Retenção e qualidade dos relatórios editoriais.",
        "escolha": "Ajuste este campo conforme a operação de Conteúdo, audiência e IA neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_auto_config

```json
{
    "rotulo": "Configuração automática do Pixel Meta",
    "descricao": "Ligado preserva a configuração automática da Meta. Desligue para solicitar autoConfig=false antes do init; PageView e Lead explícitos continuam. Isso não remove o script nem garante melhoria de desempenho.",
    "impacto": "Desligar pode reduzir recursos automáticos do Pixel.",
    "exemplo": "Mantenha ligado, salvo decisão explícita de controlar os eventos automáticos.",
    "campo": "booleano",
    "ajuda": {
        "funcionamento": "Desligar pode reduzir recursos automáticos do Pixel.",
        "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
        "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
        "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
        "exemplo": "Mantenha ligado, salvo decisão explícita de controlar os eventos automáticos.",
        "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
    }
}
```

## f3base_clarity_project_id

```json
{
    "rotulo": "Projeto Microsoft Clarity",
    "descricao": "ID público do projeto; vazio mantém o Clarity inativo. Carrega somente com medição permitida e fora de testes. O script pode aumentar trabalho e tráfego; confira CSP e qualidade em uma amostra real. O token de exportação é separado.",
    "impacto": "Oferece mapas e gravações no fornecedor; não comprova identificação de pessoas.",
    "exemplo": "Copie somente o ID exibido pelo projeto Clarity.",
    "campo": "texto",
    "ajuda": {
        "funcionamento": "Oferece mapas e gravações no fornecedor; não comprova identificação de pessoas.",
        "escolha": "Ajuste este campo conforme a operação de Projeto Microsoft Clarity neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "Copie somente o ID exibido pelo projeto Clarity.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_confirmacao_hosts

```json
{
    "rotulo": "Hosts externos de confirmação autorizados",
    "descricao": "Um host por linha, sem esquema ou caminho. Só HTTPS; vazio permite somente este site. Páginas externas para conteúdo/WhatsApp devem exibir o link temporário recebido em f3base_continuar.",
    "campo": "linhas",
    "ajuda": {
        "funcionamento": "Um host por linha, sem esquema ou caminho. Só HTTPS; vazio permite somente este site. Páginas externas para conteúdo/WhatsApp devem exibir o link temporário recebido em f3base_continuar.",
        "escolha": "Informe somente os itens que se aplicam a este site. Confira os itens existentes antes de removê-los.",
        "vantagens": "A lista explícita permite revisar o conjunto aplicado sem editar arquivos do plugin.",
        "limitacoes": "Itens ausentes não são acrescentados por atualizações. Uma lista vazia pode suspender a função que depende dela.",
        "exemplo": "",
        "vazio": "Lista vazia é uma escolha explícita e é preservada."
    }
}
```

## f3base_clarity

```json
{
    "rotulo": "Histórico analítico do Clarity",
    "descricao": "Coletas móveis independentes de 24, 48 e 72 horas. Reduzir a retenção elimina consultas antigas na próxima limpeza. Zero preserva o acervo sem expiração automática. Não inclui gravações individuais.",
    "campo": "grupo",
    "subcampos": {
        "coleta_ativa": {
            "tipo": "booleano",
            "rotulo": "Coletar diariamente quando houver token vinculado",
            "descricao": "Sem projeto/token, nenhuma chamada. Oito recortes automáticos por dia. Duas consultas adicionais são compartilhadas entre testes manuais e retentativas; teto total de dez por projeto/dia.",
            "ajuda": {
                "funcionamento": "Sem projeto/token, nenhuma chamada. Oito recortes automáticos por dia. Duas consultas adicionais são compartilhadas entre testes manuais e retentativas; teto total de dez por projeto/dia.",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "retencao_meses": {
            "tipo": "inteiro",
            "rotulo": "Retenção do acervo em meses (0: preservar)",
            "descricao": "Política independente da retenção editorial. Reduzir apaga definitivamente consultas anteriores ao corte.",
            "ajuda": {
                "funcionamento": "Política independente da retenção editorial. Reduzir apaga definitivamente consultas anteriores ao corte.",
                "escolha": "Ajuste este campo conforme a operação de Retenção do acervo em meses (0: preservar) neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Coletas móveis independentes de 24, 48 e 72 horas. Reduzir a retenção elimina consultas antigas na próxima limpeza. Zero preserva o acervo sem expiração automática. Não inclui gravações individuais.",
        "escolha": "Ajuste este campo conforme a operação de Histórico analítico do Clarity neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_capi_pixel_id

```json
{
    "rotulo": "Pixel/dataset da Meta no servidor",
    "descricao": "Destino independente da tag direta. Vazio herda o Pixel direto; preencha quando o Pixel vier do GTM. Trocar destino invalida a homologação e não redireciona a fila antiga.",
    "campo": "texto",
    "ajuda": {
        "funcionamento": "Destino independente da tag direta. Vazio herda o Pixel direto; preencha quando o Pixel vier do GTM. Trocar destino invalida a homologação e não redireciona a fila antiga.",
        "escolha": "Ajuste este campo conforme a operação de Pixel/dataset da Meta no servidor neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_meta_transporte

```json
{
    "rotulo": "Transporte dos eventos Meta",
    "descricao": "Navegador usa o Pixel. Ambos acrescenta CAPI com mesmo event_id. Servidor exige homologação por site e desliga o Pixel direto. GA4 continua pela tag.",
    "campo": "grupo",
    "subcampos": {
        "modo": {
            "tipo": "enum",
            "rotulo": "Como enviar à Meta",
            "descricao": "A mudança para servidor exige equivalência, sete dias completos e provas externas por evento. Tag em GTM/tema exige conferência própria.",
            "opcoes": {
                "navegador": "Navegador",
                "ambos": "Pixel e servidor",
                "servidor": "Somente servidor homologado"
            },
            "ajuda": {
                "funcionamento": "A mudança para servidor exige equivalência, sete dias completos e provas externas por evento. Tag em GTM/tema exige conferência própria.",
                "escolha": "Escolha uma das alternativas exibidas. Cada alternativa muda o funcionamento descrito acima; uma opção gravada é preservada nas atualizações.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "Navegador ou Pixel e servidor ou Somente servidor homologado",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "eventos": {
            "tipo": "multiescolha",
            "rotulo": "Eventos com rota servidor",
            "descricao": "PageView e Lead usam esta seleção. MaterialDownload segue o interruptor Meta em Conversões de material, independentemente desta lista. A atualização não ativa destinos.",
            "opcoes": {
                "PageView": "Página vista (PageView)",
                "Lead": "Contato (Lead)"
            },
            "ajuda": {
                "funcionamento": "PageView e Lead usam esta seleção. MaterialDownload segue o interruptor Meta em Conversões de material, independentemente desta lista. A atualização não ativa destinos.",
                "escolha": "Informe somente os itens que se aplicam a este site. Confira os itens existentes antes de removê-los.",
                "vantagens": "A lista explícita permite revisar o conjunto aplicado sem editar arquivos do plugin.",
                "limitacoes": "Itens ausentes não são acrescentados por atualizações. Uma lista vazia pode suspender a função que depende dela.",
                "exemplo": "",
                "vazio": "Lista vazia é uma escolha explícita e é preservada."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Navegador usa o Pixel. Ambos acrescenta CAPI com mesmo event_id. Servidor exige homologação por site e desliga o Pixel direto. GA4 continua pela tag.",
        "escolha": "Ajuste este campo conforme a operação de Transporte dos eventos Meta neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    },
    "estrutura": {
        "modo": {
            "tipo": "string",
            "padrao": null,
            "ajuda": {
                "funcionamento": "modo",
                "escolha": "Ajuste este campo conforme a operação de modo neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "eventos": {
            "tipo": "array",
            "padrao": null,
            "ajuda": {
                "funcionamento": "eventos",
                "escolha": "Ajuste este campo conforme a operação de eventos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            },
            "estrutura": {
                "itens": []
            }
        }
    }
}
```

## f3base_meta_janela

```json
{
    "rotulo": "Janelas externas da Meta conferidas",
    "descricao": "Conferência operacional das regras oficiais, válida por 90 dias. Sem conferência, a fila mantém 1 hora. Nunca excede sete dias da ocorrência; ambos também respeita deduplicação, com margem de cinco minutos. Alterar não prolonga filas existentes.",
    "campo": "grupo",
    "subcampos": {
        "confirmada": {
            "tipo": "booleano",
            "rotulo": "Limites conferidos na documentação oficial",
            "ajuda": {
                "funcionamento": "Limites conferidos na documentação oficial",
                "escolha": "Ative quando quiser aplicar esta função no site. Desative quando a operação descrita não se aplicar.",
                "vantagens": "Permite controlar esta função sem apagar os demais dados e preferências.",
                "limitacoes": "Desligar não desfaz automaticamente os efeitos já produzidos. Considere as dependências descritas acima.",
                "exemplo": "Ativado aplica a função; desativado preserva a escolha desligada.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "aceitacao_segundos": {
            "tipo": "inteiro",
            "rotulo": "Idade máxima aceita, em segundos",
            "ajuda": {
                "funcionamento": "Idade máxima aceita, em segundos",
                "escolha": "Ajuste este campo conforme a operação de Idade máxima aceita, em segundos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "deduplicacao_segundos": {
            "tipo": "inteiro",
            "rotulo": "Janela de deduplicação, em segundos",
            "ajuda": {
                "funcionamento": "Janela de deduplicação, em segundos",
                "escolha": "Ajuste este campo conforme a operação de Janela de deduplicação, em segundos neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "conferida_em": {
            "tipo": "texto",
            "rotulo": "Data da conferência (AAAA-MM-DD)",
            "ajuda": {
                "funcionamento": "Data da conferência (AAAA-MM-DD)",
                "escolha": "Ajuste este campo conforme a operação de Data da conferência (AAAA-MM-DD) neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "fonte": {
            "tipo": "texto",
            "rotulo": "URL oficial conferida",
            "ajuda": {
                "funcionamento": "URL oficial conferida",
                "escolha": "Ajuste este campo conforme a operação de URL oficial conferida neste site.",
                "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
                "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
                "exemplo": "",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Conferência operacional das regras oficiais, válida por 90 dias. Sem conferência, a fila mantém 1 hora. Nunca excede sete dias da ocorrência; ambos também respeita deduplicação, com margem de cinco minutos. Alterar não prolonga filas existentes.",
        "escolha": "Ajuste este campo conforme a operação de Janelas externas da Meta conferidas neste site.",
        "vantagens": "A escolha fica centralizada no plugin e pode ser consultada pela equipe e pelos agentes.",
        "limitacoes": "A configuração salva não comprova o efeito público ou a entrega a um serviço externo; confira o diagnóstico da função.",
        "exemplo": "",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_gsc_property

```json
{
    "rotulo": "Propriedade do Google Search Console",
    "descricao": "Propriedade autorizada no MCP Google: sc-domain:exemplo.com ou prefixo HTTPS que abrange este site. O Core não recebe a credencial Google.",
    "impacto": "Permite medir impressões, cliques e posição orgânica. Não vincula buscas a pessoas, sessões ou citações de IA.",
    "exemplo": "sc-domain:exemplo.com abrange www.exemplo.com; https://exemplo.com/blog/ só abrange esse caminho.",
    "campo": "texto",
    "ajuda": {
        "funcionamento": "Permite medir impressões, cliques e posição orgânica. Não vincula buscas a pessoas, sessões ou citações de IA.",
        "escolha": "Prefira a propriedade de domínio que inclui este site; use prefixo URL quando a autorização cobre só uma seção.",
        "vantagens": "A propriedade de domínio conserva também URLs de outros hosts no acervo, sem atribuí-las ao site atual.",
        "limitacoes": "Exige autorização no MCP Google. Os dados são agregados; não identificam visitantes ou a busca de uma pessoa.",
        "exemplo": "sc-domain:exemplo.com abrange www.exemplo.com; https://exemplo.com/blog/ só abrange esse caminho.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```

## f3base_gsc

```json
{
    "rotulo": "Coleta orgânica do Search Console",
    "descricao": "Coleta diária de páginas web com dados finais. Últimos três dias disponíveis são revisitados. O histórico local não expira automaticamente. Exige o contrato search-console-reader/1.0.0, autorização e conexão efetiva resolvida.",
    "campo": "grupo",
    "subcampos": {
        "ativo": {
            "tipo": "booleano",
            "rotulo": "Coletar quando autorizado",
            "descricao": "Sem propriedade, SDK e concessão, não há consulta remota. Desligar preserva o acervo.",
            "ajuda": {
                "funcionamento": "Sem propriedade, SDK e concessão, não há consulta remota. Desligar preserva o acervo.",
                "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
                "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
                "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
                "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
                "vazio": "Desmarcado significa desligado. O padrão só vale quando a chave ainda não existe."
            }
        },
        "horario": {
            "tipo": "texto",
            "rotulo": "Horário local diário",
            "descricao": "Padrão 05:00 no fuso do WordPress. É previsão: depende de um disparo do cron.",
            "ajuda": {
                "funcionamento": "Padrão 05:00 no fuso do WordPress. É previsão: depende de um disparo do cron.",
                "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
                "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
                "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
                "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        },
        "inicio": {
            "tipo": "texto",
            "rotulo": "Início da série (AAAA-MM-DD)",
            "descricao": "Vazio começa nos últimos 30 dias finalizáveis. Um início anterior exige mais passagens para preencher as lacunas.",
            "ajuda": {
                "funcionamento": "Vazio começa nos últimos 30 dias finalizáveis. Um início anterior exige mais passagens para preencher as lacunas.",
                "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
                "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
                "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
                "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
                "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
            }
        }
    },
    "ajuda": {
        "funcionamento": "Coleta diária de páginas web com dados finais. Últimos três dias disponíveis são revisitados. O histórico local não expira automaticamente. Exige o contrato search-console-reader/1.0.0, autorização e conexão efetiva resolvida.",
        "escolha": "Ative depois de conferir a propriedade e a concessão. Escolha um horário com cron ativo; um início anterior amplia a recuperação histórica.",
        "vantagens": "Mantém histórico local por página e permite reprocessar dias sem somar fotografias repetidas.",
        "limitacoes": "Depende da cobertura, cotas e atraso do Google. Ampliar o período aumenta o número de passagens; ausência de linhas não comprova zero acessos.",
        "exemplo": "05:00 executa no fuso do WordPress. Início vazio recupera os últimos 30 dias finalizáveis, em lotes.",
        "vazio": "Campo ausente herda o padrão. Valor vazio explícito segue a regra deste campo e não é preenchido pela atualização."
    }
}
```
