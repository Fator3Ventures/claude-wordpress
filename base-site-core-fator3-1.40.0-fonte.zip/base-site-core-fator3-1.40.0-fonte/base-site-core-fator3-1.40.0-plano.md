> Revisão 2 — implementação em 20/10/2026. O plano Google 0.14 recebido substitui a seção 3 abaixo: utilizar contrato de entrega 1.0, GA4 com evidência HTTP e Ads legado somente com elegibilidade comprovada/declarada por recibo real. Data Manager/recibos 1.1 ficam condicionais, não implementados sem evidência. O contrato de leitura de configuração 1.1 permanece negociado. Esta revisão entrega código/patch, sem esperar resposta Google. O texto anterior segue como histórico; relatório e impactos r2 descrevem o resultado efetivo.

# Plano — Fator3 Site Core 1.40.0

Revisão 1 · 20/10/2026 · America/Sao_Paulo · Situação: planejamento, sem implementação nesta rodada.
Base: Core 1.39.0. Alvo: 1.40.0, ainda sem instalador. Entrada: Fator3 Site Core(8).md, Fator3 MCP Google(5).md, impacto Google 0.13.0 → Core r2 e pacotes Google 0.13.0.

## 1. Escopo e decisão de execução

| Pedido | Entrega planejada | Limite |
|---|---|---|
| Core 236 | Transporte de contato por destino GA4/Ads: navegador ou servidor, escolha persistida por registro, navegador como padrão. | Meta e materiais mantêm comportamento existente. |
| Core 237 | E-mail C0 após criação confirmada de lead novo, SMTP autenticado, Smart Bcc, texto por marca/serviço, atividade e tratamento de falha. | Sem envio a clientes durante desenvolvimento; ativação exige configuração. |
| MCP Google 28, dependência de 236 | Implementar nesta frente as mudanças necessárias no Google, incluindo adaptadores, credenciais, diagnóstico e contrato de entrega. | Google 29, sobre lacunas do cron, permanece com o responsável Google e não entra neste escopo. |

A instrução do dono nesta rodada autoriza implementar a dependência no pacote Google e repassá-la. Portanto, a implementação não aguardará resposta a um impacto para começar ou terminar o código dependente. As APIs e credenciais continuam no Google; fila, consentimento, propriedade do transporte e eventos continuam no Core. O repasse terá código, testes, contratos e resultado, em um único documento de impacto atualizado durante o ciclo.

Core 230–235 já foram entregues conforme a lista atual; seus aceites de frota não viram novas funcionalidades nesta release. A lista atual relata a instalação da 1.39 no Site-Teste após a entrega anterior; prevalece sobre o estado histórico do relatório 1.39. Isso é evidência recebida da frota, não nova inspeção remota nesta rodada.

## 2. Core 236 — transporte por destino

Proposta de option operável: `f3base_conversoes_transporte`, objeto fechado com `ga4` e `google_ads`, cada um `navegador|servidor`. Defaults de instalação e primeira migração: ambos navegador. Nome/schema finais serão publicados no catálogo e em `como-usar`; previsão de contrato administrativo aditivo 8.5.0, a confirmar no build.

1. Gravação via painel e `config-core-escrever` com permissão administrativa, revisão/CAS e validação anterior à persistência. Servidor exige adaptador do destino com contrato explicitamente suportado, `ready:true` e destino identificado. Recusa deve preservar a configuração anterior. `capabilities()` não executa rede; depende de provas/configuração locais válidas do Google.
2. Na aceitação do contato, persistir a escolha efetiva e a revisão por destino junto ao registro. A resposta do POST informa ao script quais destinos pertencem ao navegador. Não decidir apenas pelo HTML em cache: uma página aberta antes da troca precisa obedecer à decisão persistida no aceite.
3. Navegador reproduz o disparo de contato da 1.38 para aquele destino. Não cria linha no diário servidor. Servidor não dispara o evento de contato daquele destino no navegador. Não haverá fallback automático entre transportes em erro ou timeout.
4. Mudança de configuração vale para novos contatos. Repetição de submissão, atualização de página, recuperação e complemento preservam a escolha original. Restaurar navegador não reenvia registros antes destinados ao servidor.
5. Migração da 1.39: linhas existentes e contatos marcados `conversoes_servidor_versao=1` mantêm propriedade servidor, inclusive quando a linha faltou. Não eliminar diário nem converter incertos em pendentes. Históricos sem prova de transporte não entram em recuperação automática por uma simples mudança de option.
6. Falta ou perda posterior do adaptador pausa apenas os registros servidor daquele destino; não transfere eventos para o navegador. A finalidade material e Pixel/CAPI Meta são preservados.
7. Expor transporte selecionado/efetivo e motivo de indisponibilidade em `conversoes-contexto-ler` e `como-usar`. O SDK atual tem schema estrito: manter a resposta 1.0.0 válida e acrescentar leitura versionada/negociada 1.1.0 para transporte; atualizar consumidor Google no mesmo trabalho. Não inserir campos novos silenciosamente na resposta 1.0.0.

O modo navegador deve poder ser entregue e usado com Google 0.13.0, sem segredo MP ou developer token. A ausência dessas credenciais restringe a ativação servidor, não a disponibilidade da correção 236.

## 3. Dependência Google 28 — implementação e repasse

### Contrato de entrega

A objeção técnica do impacto Google é procedente: o contrato 1.0.0 do Core não representa processamento assíncrono com recibo. Planejar `site-conversion-delivery/1.1.0`, negociado explicitamente. Preservar o caminho 1.0.0 para respostas síncronas que cumpram exatamente sua semântica; um adaptador não deve anunciar 1.0.0 para devolver estados novos.

Proposta mínima: `capabilities()`, `send(payload)` e `status(receipt)`. A fila única continua no Core. Resultados novos distinguem `aceito_pendente` com recibo, confirmação terminal de processamento e `recebido_http` quando o fornecedor só comprova recepção HTTP. Manter `recusado` com prova de não entrega e `incerto` sem prova. Nomes e schemas ficam congelados em fixtures compartilhadas antes de integrar os dois lados.

Persistir recibo opaco, contrato, record_id, destino e identidade estável da conexão/conta, próxima consulta e resultado, com checkpoint e trilha auditável. `status()` consulta sem repetir `send()`. Troca de conta/ação/principal de credencial bloqueia reutilização do recibo; renovação do token da mesma identidade não deve ser confundida com troca de conta. Falha ao persistir recibo depois do envio é incerta, sem repetição automática. Expiração da consulta não é prova de não entrega. Reconciliação administrativa exige prova vinculada ao registro e nunca usa edição direta da tabela pelo Google.

### Adaptadores no Google

- **GA4:** segredo MP cifrado/mascarado, tela e ajuda próprias; validar vínculo measurement_id/propriedade/conexão e evento em `/debug/mp/collect` antes da primeira entrega. HTTP 2xx significa recebimento HTTP, não comprovação de processamento no GA4; registrar essa distinção e não repetir. Homologar sessão original em DebugView/Realtime. Nenhuma chamada na requisição do visitante.
- **Ads:** conta e ação de importação explícitas, valor/moeda configurados e consentimento preservado. Uma conversão por record_id, `order_id=record_id`. Selecionar um identificador de clique comprovado da aquisição; se houver vários sem procedência que determine um único, bloquear com motivo legível. Não escolher arbitrariamente nem multiplicar conversões.
- **Transporte Ads:** implementar Data Manager com recibo/consulta como caminho planejado. Não habilitar API legada por fallback. Elegibilidade, credenciais e permissões da conta precisam de verificação real; eventual restrição fica no `ready:false`, sem impedir implementação e testes com fixtures.
- **Granularidade:** iniciar com um registro e um destino por requisição, para associar diagnóstico ao registro. Resultado parcial/ambíguo sem prova individual não vira entrega confirmada. Consulta segue o prazo/backoff do fornecedor; timeout sem recibo continua incerto.
- **Prontidão:** `google/status` explica credencial ausente, destino não conferido, contrato incompatível, permissão ou validação pendente. Ler status/capabilities não renova token nem chama API.

A árvore Google 0.13.0 será trabalhada separadamente. Alvo técnico previsto 0.14.0, sujeito à conferência de entregas paralelas antes do fechamento; não sobrescrever release já publicada. Entregar alterações aplicáveis, testes e pacotes próprios se houver build Google. O mantenedor recebe a implementação para incorporação/manutenção. Sem aguardar retorno para implementar; sem afirmar que sua incorporação ou publicação já aconteceu.

## 4. Core 237 — C0 ao contato

### Configuração e conteúdo

Configuração própria de C0, desativada até a caixa e o destino serem conferidos. Separada de `resposta_visitante`, que permanece desligada onde assim configurado. SMTP autenticado DreamHost com TLS e verificação de certificado; senha fornecida pelo dono na tela, cifrada e mascarada, nunca em snapshot, HTML público, logs ou exemplos. Aplicar transporte só à mensagem C0, sem alterar o correio de outros módulos.

Remetente e Cco: `korvena@korvena.net.br`; nome de exibição: marca do site. Segundo Cco: `cc_email` obtido por GET do lead recém-criado, validado antes do envio. Se Smart Bcc não estiver disponível, manter pendente e avisar, sem registrar falso sucesso. HTML e alternativa texto, assunto, assinatura, telefone sem link/+55 e link direto `wa.me/5511936203481` seguem literalmente o item 237. Não inventar novas peças de copy.

Modelo por site com primeiro nome, origem, prazo calculado a partir da C1 e parágrafo de serviço. Preservar os textos de unidade Korvena e CTO Office fornecidos. Mapa dos serviços 89–96, 148 e 149 é preenchido somente com textos aprovados no projeto Pipedrive. Serviço vazio usa texto da unidade; serviço preenchido sem texto aprovado não deve ser tratado como vazio: sinalizar configuração incompleta e manter C0 pendente. Múltiplos serviços usam os respectivos parágrafos aprovados, sem repetição. Conferir a promessa de prazo no momento do envio se houve espera longa; não enviar promessa vencida como válida.

### Elegibilidade, fila e histórico

1. Criar intenção durável após comprovar a criação de lead novo pelo fluxo, com identidade site/conta/lead/C0 e snapshot da mensagem. Não depender de a requisição do formulário continuar aberta.
2. Excluir e-mail inválido, homologação, marca de teste e empresa `Teste … (apagar)`, além de lead existente/negócio aberto/reenvio. Recuperação não transforma esses casos em C0 novo. A configuração afeta entradas futuras, sem disparo retroativo em massa.
3. SMTP tem checkpoint antes do envio. Após aceitação SMTP, registrar hora e criar/concluir atividade `C0 E-mail`, tipo email. Se a atividade falhar, retomar apenas o registro da atividade, sem mandar outro e-mail.
4. Falha comprovada: atividade aberta com erro sanitizado e aviso Slack idempotente. Falha transitória/quota: espera na fila, sem descarte. Timeout após possível aceitação: estado incerto, reconciliação antes de qualquer reenvio. Resultado parcial entre destinatários deve ser registrado; não reenviar o corpo ao contato para corrigir somente um Cco.
5. Contabilizar destinatários efetivos únicos, incluindo Cco. Em situação usual são três por C0. O teto de 100 destinatários/hora é da caixa compartilhada, não 100 por site. Para esta entrega, prever cotas estáticas por site cuja soma, com reserva para uso manual, caiba no teto da caixa, além do tratamento da recusa remota. Não introduzir serviço central novo. Ativação precisa dessa alocação operacional; contadores locais isolados não provam respeito à cota global.

### Exceção de homologação necessária

O item 237(c) suprime testes e o aceite exige teste com caixa controlada. Proposta: autorização administrativa explícita de uma única intenção de homologação, destinatário em allowlist controlada pela Fator3, expiração e trilha. Isso não libera a fila inteira nem os leads de teste habituais. Manter prefixo de teste, validar recebimento/Smart Bcc/atividade e apagar somente recursos criados no ensaio. Caixa de destino, senha SMTP e texto aprovado são entradas operacionais; fixtures permitem implementar sem esperar por elas.

## 5. Compatibilidade e ordem

1. Fechar fixtures de contrato e snapshot de transporte; implementar 236, inclusive retorno navegador.
2. Implementar alterações Core/Google necessárias ao servidor na mesma frente, com APIs no Google e um único diário Core.
3. Implementar C0 de forma independente.
4. Testar instalação limpa, 1.39→1.40 e também 1.38→1.40, salto necessário porque os 11 sites continuam na 1.38 e não devem receber a 1.39 apenas como intermediária. Preservar configurações, filas, incertos e dados.
5. Homologar Core 1.40 + Google 0.13 no modo navegador. Depois, Google adaptado com Core 1.40 e destinos servidor explicitamente habilitados. Testar ordem mista: adaptador novo deve recusar contrato incompatível, sem efeitos.
6. Repasse dos pacotes/código ao responsável e ao dono. Publicação/distribuição da frota segue autorização própria.

Impactos consolidados: `base-site-core-fator3-1.40.0-impacto-wp-mcp-google-fator3.md` e `base-site-core-fator3-1.40.0-impacto-implantador-base.md`. O segundo existe pela mudança operável de configuração e implantação, não por aviso de versão. Sem alteração nova requerida em MCP/Meta/LinkedIn.

## 6. Critérios de aceite

| Área | Prova exigida |
|---|---|
| 236 navegador | Site-Teste e CTO Office: evento de teste no navegador e zero linha servidor para esse registro/destino. Combinações mistas GA4/Ads corretas. |
| 236 troca | Página antiga em cache, submissão repetida, troca concorrente, recuperação e contato pré-migração não geram transporte duplo. Servidor recusado sem ready/contrato exato. |
| Peso | Os mesmos scripts/requisições de carga; quatro scripts de contato somados em HTTP comprimido ≤21.517 bytes. |
| Servidor | Fixtures de recibo, consulta, falha/parcial, crash, timeout, troca de conta e revogação; nenhum reenvio de pendente/incerto/confirmado. |
| GA4/Ads real | Caixa/ativos autorizados; WebView Android e Instagram; uma ocorrência na sessão GA4 original e na ação Ads; consentimento negado sem envio; Meta deduplicada. |
| C0 | Novo lead elegível recebe mensagem/Smart Bcc, link direto e atividade; reenvio/lead existente/teste comum não recebem. Exceção controlada e limpeza comprovadas. |
| C0 falhas | Quota incluindo Cco, concorrência, destinatário parcial, SMTP incerto e falha de atividade/Slack não duplicam mensagem nem descartam intenção. |
| Segurança/docs | Permissões administrativas, segredo mascarado, leitura documental MCP completa/versionada sem efeitos, configuração com CAS e readback. |

Nenhum desses testes foi executado nesta rodada de planejamento. A conferência atual é documental e de código/hash dos pacotes-base.

## 7. Dependências de ativação

Dono: senha SMTP e caixa controlada; segredo MP; identidade/ação Ads e acesso API; textos por serviço aprovados; alocação de cota da caixa entre sites/usos manuais. Dono/Datta: meta Contatos e ações antigas. Essas entradas restringem ativação e homologação reais; não serão usadas para adiar a implementação própria ou a dependência Google.

## 8. Entregáveis e referências

Implementação: fonte, instalador e relatório Core 1.40.0; alterações Google com testes e documentação e, se empacotadas, fonte/instalador/relatório próprios. Atualizar os mesmos impactos com código, decisões, hashes e evidências. Não gerar ciclos de documentos pedindo autorização já concedida.

Bases imutáveis e hashes: ver `base-site-core-fator3-1.40.0-relatorio.md`. Os ZIPs 1.40.0 ainda não existem.

Fontes oficiais conferidas em 20/10/2026:
- [GA4: resposta HTTP e limites de confirmação](https://developers.google.com/analytics/devguides/collection/protocol/ga4/reference).
- [GA4: validação do evento](https://developers.google.com/analytics/devguides/collection/protocol/ga4/validating-events).
- [Data Manager: recibos e consulta de diagnóstico](https://developers.google.com/data-manager/api/devguides/diagnostics).
- [Data Manager: requestStatus.retrieve](https://developers.google.com/data-manager/api/reference/rest/v1/requestStatus/retrieve).
- [DreamHost: limites SMTP](https://help.dreamhost.com/hc/en-us/articles/215730437-SMTP-quota-limits).

Inferências técnicas do plano: necessidade de snapshot por contato e decisão na resposta POST para evitar corrida/cache; evolução negociada de contrato para recibos; cota coordenada por caixa; exceção de homologação restrita para compatibilizar 237(c) com seu aceite. Não são capacidades já entregues.
