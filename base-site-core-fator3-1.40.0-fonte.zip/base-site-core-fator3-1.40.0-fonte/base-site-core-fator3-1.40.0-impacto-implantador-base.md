# Impacto de Core 1.40.0 em implantador-base

Revisão 2 · 20/10/2026 · Etapa: entrega · Situação: validação operacional pendente. Contrato administrativo aditivo 8.5.0. Identidade implantador-base conforme aba recebida; runtime do Implantador não reexaminado.

`f3base_conversoes_transporte` foi implementada com ga4/google_ads=navegador|servidor e default navegador. Servidor exige adapter ready. A gravação vale para contatos novos; não transfere histórico. Consumir schema vivo, preservar CAS e readback. Google 0.13 não impede navegador.

C0 é desativado por padrão, com option f3base_c0 e segredo f3base_c0_smtp_senha. Não ativar em lote. Exige marca, senha, cota de destinatários alocada por site e textos aprovados por serviço. Contabilizar Cco. Não ativar resposta_visitante. Homologação é uma intenção administrativa por registro, caixa em allowlist e expiração de uma hora.

Instalação limpa e upgrades diretos 1.39→1.40 e 1.38→1.40 foram exercitados em WordPress local. Configurações/dados preservados. Site-Teste permanece Core 1.39/Google 0.13/MCP 0.24; só leitura remota nesta rodada. Instalar e homologar conforme o relatório, sem reset de filas ou conexão automática. Não foi executado teste integrado do Implantador.
