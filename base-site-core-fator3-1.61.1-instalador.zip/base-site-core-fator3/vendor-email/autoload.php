<?php
/** Isolated PSR-4 loader generated from the locked, PHP-Scoper-prefixed dependencies. */
declare(strict_types=1);
spl_autoload_register(static function(string $class): void {
    $prefix='F3BaseEmailVendor\\';if(!str_starts_with($class,$prefix)){return;}$name=substr($class,strlen($prefix));
    $map=array('ZBateson\\StreamDecorators\\'=>array('zbateson/stream-decorators/src'),'ZBateson\\MbWrapper\\'=>array('zbateson/mb-wrapper/src'),'ZBateson\\MailMimeParser\\'=>array('zbateson/mail-mime-parser/src'),'Psr\\Log\\'=>array('psr/log/src'),'Psr\\Http\\Message\\'=>array('psr/http-factory/src','psr/http-message/src'),'Psr\\Container\\'=>array('psr/container/src'),'Laravel\\SerializableClosure\\'=>array('laravel/serializable-closure/src'),'Invoker\\'=>array('php-di/invoker/src'),'GuzzleHttp\\Psr7\\'=>array('guzzlehttp/psr7/src'),'DI\\'=>array('php-di/php-di/src'));
    foreach($map as $ns=>$dirs){if(!str_starts_with($name,$ns)){continue;}foreach($dirs as $dir){$file=__DIR__.'/'.$dir.'/'.str_replace('\\','/',substr($name,strlen($ns))).'.php';if(is_file($file)){require $file;return;}}}
});
require_once __DIR__.'/php-di/php-di/src/functions.php';
