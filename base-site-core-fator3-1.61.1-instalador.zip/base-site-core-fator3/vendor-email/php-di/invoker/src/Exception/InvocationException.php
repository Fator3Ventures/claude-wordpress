<?php

declare (strict_types=1);
namespace F3BaseEmailVendor\Invoker\Exception;

/**
 * Impossible to invoke the callable.
 */
class InvocationException extends \Exception
{
}
