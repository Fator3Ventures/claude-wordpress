<?php

declare (strict_types=1);
namespace F3BaseEmailVendor\Invoker\Exception;

/**
 * Not enough parameters could be resolved to invoke the callable.
 */
class NotEnoughParametersException extends InvocationException
{
}
