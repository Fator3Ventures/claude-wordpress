<?php
/** Meta Ads: public local reader plus explicit campaign/partner attribution. Never calls Graph. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Ads {
    const OPTION='f3base_meta_ads';
    const CONTRACT='meta-ads-reader/1.0.0';
    const CONSUMER='base-site-core-fator3';
    private static $client=null;
    private static string $registro='sdk_ausente';

    public static function padroes(): array {return array('ativo'=>false,'conexao'=>'','conta_id'=>'','revisao'=>0,'revisao_acesso'=>0,'parceiro_padrao'=>array('parceiro_id'=>'','rotulo'=>''),'parceiros'=>array());}
    public static function props(): array {
        return array('revisao_acesso'=>array('type'=>'integer','minimum'=>0,'maximum'=>2147483647,'description'=>'Gerada pelo Core; preserve na escrita. Só muda com ativo, conexão ou conta.'),'parceiro_padrao'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('parceiro_id','rotulo'),'properties'=>array('parceiro_id'=>array('type'=>'string','pattern'=>'^([a-zA-Z0-9_-]{1,80})?$'),'rotulo'=>array('type'=>'string','maxLength'=>100))),'revisao'=>array('type'=>'integer','minimum'=>0,'maximum'=>2147483647),'ativo'=>array('type'=>'boolean'),'conexao'=>array('type'=>'string','pattern'=>'^([a-zA-Z0-9][a-zA-Z0-9_.-]{0,63})?$'),'conta_id'=>array('type'=>'string','pattern'=>'^([0-9]{1,40})?$'),'parceiros'=>array('type'=>'array','maxItems'=>1000,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('campanha_id','parceiro_id','rotulo'),'properties'=>array('campanha_id'=>array('type'=>'string','pattern'=>'^[0-9]{1,40}$'),'parceiro_id'=>array('type'=>'string','pattern'=>'^[a-zA-Z0-9_-]{1,80}$'),'rotulo'=>array('type'=>'string','minLength'=>1,'maxLength'=>100)))));
    }
    public static function opcoes(): array {return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function validar($v): string {
        $error=rest_validate_value_from_schema($v,array('type'=>'object','properties'=>self::props(),'additionalProperties'=>false));if(is_wp_error($error)){return $error->get_error_message();}
        $v=array_replace(self::padroes(),$v);if($v['ativo']&&($v['conexao']===''||$v['conta_id']===''||$v['revisao']<1)){return 'Informe conexão, conta Meta Ads e revisão positiva antes de habilitar a leitura.';}
        $p=$v['parceiro_padrao'];if(($p['parceiro_id']==='')!==($p['rotulo']==='')||sanitize_text_field($p['rotulo'])!==$p['rotulo']){return 'Parceiro padrão exige ID e rótulo simples, ou ambos vazios.';}
        $seen=array();foreach($v['parceiros'] as $m){if(isset($seen[$m['campanha_id']])){return 'Cada campanha pode ter somente um parceiro explícito na conta selecionada.';}$seen[$m['campanha_id']]=true;if(sanitize_text_field($m['rotulo'])!==$m['rotulo']){return 'O rótulo de parceiro deve ser texto simples.';}}return '';
    }
    /** The generation is stored atomically with the selection; restoring old values cannot revive a grant. */
    public static function validar_alteracao($v): string {
        $error=self::validar($v);if($error!==''){return $error;}$v=array_replace(self::padroes(),$v);$physical=F3Base_Options::fotografia_bruta(self::OPTION);if($physical['erro']){return 'Não foi possível conferir a revisão persistida da seleção.';}$old=array_replace(self::padroes(),(array)$physical['valor']);$next=$v;$previous=$old;unset($next['revisao'],$previous['revisao']);if(isset($v['revisao_acesso'])&&$v['revisao_acesso']!==$old['revisao_acesso']&&$v['revisao_acesso']!==0){return 'A geração de acesso é controlada pelo Core; preserve o valor lido.';}
        if($v['revisao']<$old['revisao']||($next!==$previous&&$v['revisao']<=$old['revisao'])){return 'Aumente revisao ao alterar esta seleção. Uma revisão anterior não pode restaurar concessões ou cursores antigos.';}return '';
    }
    private static function acesso(array $v): array {return array('ativo'=>$v['ativo'],'conexao'=>$v['conexao'],'conta_id'=>$v['conta_id']);}
    /** Called only by the central write path; read sanitizers never invent a generation. */
    public static function preparar_escrita(array $v): array {
        $old=self::opcoes();$v=array_replace(self::padroes(),$v);$v['revisao_acesso']=$old['revisao_acesso']+(self::acesso($old)!==self::acesso($v)?1:0);return $v;
    }
    public static function configuracao(): array {
        $c=self::opcoes();return array('connection_id'=>$c['conexao'],'account_id'=>$c['conta_id'],'revision'=>hash('sha256',wp_json_encode(array(self::acesso($c),$c['revisao_acesso']))),'ready'=>$c['ativo']&&$c['conexao']!==''&&$c['conta_id']!==''&&self::validar($c)==='');
    }
    public static function descobrir($sdk,string $contract): void {
        if($contract!==self::CONTRACT||self::$client){return;}
        if(!is_callable(array($sdk,'register_consumer'))){self::$registro='sdk_incompativel';return;}
        try{$client=$sdk::register_consumer(self::CONSUMER,F3BASE_PLUGIN_VERSAO,self::CONTRACT,array(__CLASS__,'configuracao'),'Fator3 Site Core — campanhas e contatos');if(!is_object($client)||!is_callable(array($client,'query'))||!is_callable(array($client,'status'))){self::$registro='sdk_incompativel';return;}self::$client=$client;self::$registro='registrado';}catch(Throwable $e){self::$registro='registro_indisponivel';}
    }
    public static function iniciar(): void {
        add_filter('f3base_options_catalogo',static function($c){$d=F3Base_Conversas::catalogo_grupo(self::OPTION,'Meta Ads — campanhas e parceiros',self::padroes(),self::props(),array(__CLASS__,'validar_alteracao'));$d['descricao']='Lê o acervo local do MCP Meta, com concessão explícita por conexão/conta. IDs de campanha identificam o parceiro; nomes são apenas rótulos. Não cria coleta nem concede acesso automaticamente.';$d['secao']='integracoes';$c[self::OPTION]=$d;return $c;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('meta-ads-status','Estado da concessão local Meta Ads e seleção do consumidor Core, sem Graph',array(__CLASS__,'status'));F3Base_Servicos::ability('meta-ads-relatorio-ler','Histórico diário por campanha e relação com contatos e parceiros; cursor consistente, moedas e cobertura preservadas',array(__CLASS__,'consultar'),self::schema(),array('de','ate'),true,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));});
    }
    public static function schema(): array {return array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>100,'default'=>50),'cursor'=>array('type'=>'string','maxLength'=>100000));}
    /** A local SDK may audit its read, but cannot turn this report into supplier HTTP. */
    private static function chamar(string $method,array $args): array {
        if(!self::$client){return array('success'=>false,'code'=>self::$registro);}$deny=static fn()=>new WP_Error('meta_ads_leitura_local','Esta operação consulta somente o acervo local.');add_filter('pre_http_request',$deny,PHP_INT_MAX,3);
        try{$r=self::$client->$method($args);return is_array($r)?$r:array('success'=>false,'code'=>'resposta_sdk_invalida');}catch(Throwable $e){return array('success'=>false,'code'=>'leitor_indisponivel');}finally{remove_filter('pre_http_request',$deny,PHP_INT_MAX);}
    }
    public static function status(array $e=array()): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}$c=self::configuracao();$r=$c['ready']?self::chamar('status',array_intersect_key($c,array_flip(array('connection_id','account_id')))):array('success'=>false,'code'=>'configuracao_pendente');
        return array('ok'=>true,'contrato'=>self::CONTRACT,'consumidor'=>self::CONSUMER,'sdk'=>self::$registro,'configuracao'=>$c,'pronto'=>!empty($r['success'])&&!empty($r['data']['ready']),'codigo'=>$r['code']??'resposta_sdk_invalida','concessao'=>$r['data']??null,'conceder_em'=>'Ferramentas → Fator3 MCP Meta → Consumidores de anúncios','http_fornecedor'=>false,'coleta'=>'Histórico mantido pelo Meta. Esta configuração não agenda coleta nem cria concessão.');
    }
    private static function erro(string $code): array {return array('ok'=>false,'codigo'=>$code,'linhas'=>array(),'proximo_cursor'=>null,'reiniciar_leitura'=>in_array($code,array('history_changed','revision_conflict','contatos_alterados','configuracao_alterada','cursor_expired'),true),'http_fornecedor'=>false);}
    private static function cursor(array $v): string {$body=base64_encode(wp_json_encode($v));return $body.'.'.hash_hmac('sha256',$body,wp_salt('auth'));}
    private static function abrir_cursor(string $cursor): ?array {
        if(strlen($cursor)>100000||substr_count($cursor,'.')!==1){return null;}[$body,$sig]=explode('.',$cursor,2);if(!hash_equals(hash_hmac('sha256',$body,wp_salt('auth')),$sig)){return null;}$json=base64_decode($body,true);$v=$json!==false?json_decode($json,true):null;return is_array($v)?$v:null;
    }
    /** One bounded snapshot; no contact data or identifiers are returned to the caller. */
    private static function contatos(string $from,string $to,string $account): array {
        global $wpdb;$start=(new DateTimeImmutable($from.' 00:00:00',new DateTimeZone('UTC')))->modify('-1 day');$end=(new DateTimeImmutable($to.' 00:00:00',new DateTimeZone('UTC')))->modify('+2 days');
        $rows=$wpdb->get_results($wpdb->prepare("SELECT record_id,criado_em,metodo,email,dados FROM %i WHERE criado_em>=%s AND criado_em<%s AND captura='aceito' AND classe_trafego='nao_marcado' AND lixeira=0 AND eliminacao_pendente=0 ORDER BY record_id LIMIT 10001",F3Base_Leads_Repositorio::tabela(),$start->format('Y-m-d H:i:s'),$end->format('Y-m-d H:i:s')),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'contatos_indisponiveis');}if(count($rows)>10000){return array('ok'=>false,'codigo'=>'reduza_periodo_contatos');}$out=array();
        foreach($rows as $r){$d=json_decode($r['dados'],true);if(!is_array($d)){return array('ok'=>false,'codigo'=>'contato_ilegivel');}if(!empty($d['audiencia_excluida'])||!empty($d['contexto_teste'])){continue;}$original=is_array($d['atribuicao']??null)?$d['atribuicao']:array();$accountValue=$original['conta_id']??$original['f3_ads_account_id']??'';$storedAccount=is_string($accountValue)?$accountValue:'';$a=F3Base_Atribuicao::normalizar($original);if($a['plataforma']!=='meta_ads'||$storedAccount!==$account||$a['campanha_id']===''){continue;}
            $ids=F3Base_Contato_Identidade::identificadores($r);$safe=array('record_id'=>$r['record_id'],'criado_em'=>$r['criado_em'],'metodo'=>$r['metodo'],'campanha_id'=>$a['campanha_id'],'identificadores'=>array());foreach($ids as $kind=>$v){if($v!==''){$safe['identificadores'][]=hash_hmac('sha256',$kind.'|'.$v,wp_salt('auth'));}}$out[]=$safe;
        }return array('ok'=>true,'revisao'=>hash('sha256',wp_json_encode($out)),'linhas'=>$out,'examinados'=>count($rows));
    }
    private static function contagem(array $contacts,string $campaign,string $day,string $timezone): array {
        $zone=new DateTimeZone($timezone);$ids=array();$parents=array();$by=array();$methods=array();$unknown=0;
        $find=static function($key)use(&$parents,&$find){return $parents[$key]===$key?$key:($parents[$key]=$find($parents[$key]));};
        foreach($contacts as $r){if($r['campanha_id']!==$campaign||(new DateTimeImmutable($r['criado_em'],new DateTimeZone('UTC')))->setTimezone($zone)->format('Y-m-d')!==$day){continue;}$id=$r['record_id'];$ids[]=$id;$parents[$id]=$id;$methods[$r['metodo']]=($methods[$r['metodo']]??0)+1;if(!$r['identificadores']){$unknown++;}foreach($r['identificadores'] as $hash){if(isset($by[$hash])){$parents[$find($id)]=$find($by[$hash]);}else{$by[$hash]=$id;}}}
        $roots=array();foreach($ids as $id){$roots[$find($id)]=true;}return array('registros_aceitos'=>count($ids),'pessoas_por_identificadores'=>count($roots),'sem_identificador'=>$unknown,'metodos'=>$methods,'data'=>'Dia da captura no fuso da conta; não é a janela de atribuição da Meta.');
    }
    private static function validar_linha(array $r,array $cfg,string $from,string $to): bool {
        $v=$r['row']??null;if(!is_array($v)||($r['connection_id']??'')!==$cfg['connection_id']||($r['account_id']??'')!==$cfg['account_id']||($r['channel']??'')!=='ads'||($r['report']??'')!=='ads_insights'||($v['ads_level']??'')!=='campaign'||($v['account_id']??'')!==$cfg['account_id']||!preg_match('/^[0-9]{1,40}$/D',(string)($v['campaign_id']??''))||($v['entity_id']??'')!==$v['campaign_id']){return false;}
        if(!preg_match('/^[a-f0-9]{64}$/D',(string)($r['row_id']??''))||!F3Base_Gsc::data_valida((string)($r['data_day']??''))||$r['data_day']<$from||$r['data_day']>$to||($v['date']??'')!==$r['data_day']||!preg_match('/^[A-Z]{3}$/D',(string)($r['currency']??''))||($v['account_currency']??'')!==$r['currency']){return false;}
        try{new DateTimeZone((string)($r['timezone']??''));}catch(Throwable $e){return false;}
        foreach(array('spend','impressions','clicks','reach','frequency','inline_link_clicks','leads_native','leads_website') as $field){if(!array_key_exists($field,$v)||($v[$field]!==null&&(!is_string($v[$field])||!preg_match('/^[0-9]+(?:\.[0-9]+)?$/D',$v[$field])))){return false;}}
        $a=$v['attribution']??array();return ($a['use_unified_attribution_setting']??null)===true&&($a['action_report_time']??'')==='mixed'&&is_array($r['coverage']??null)&&is_array($r['last_available_fields']??null);
    }
    public static function consultar(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return self::erro('sem_permissao');}
        $error=rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'required'=>array('de','ate'),'properties'=>self::schema()));if(is_wp_error($error)||!F3Base_Gsc::data_valida($e['de']??'')||!F3Base_Gsc::data_valida($e['ate']??'')||$e['de']>$e['ate']){return self::erro('periodo_invalido');}
        $days=(int)(new DateTimeImmutable($e['de']))->diff(new DateTimeImmutable($e['ate']))->format('%a');if($days>365){return self::erro('periodo_maximo_366_dias');}
        $mapa=self::opcoes();$mapa_rev=F3Base_Options::revisao(self::OPTION);$cfg=self::configuracao();if(!$cfg['ready']){return self::erro('configuracao_pendente');}if(!self::$client){return self::erro(self::$registro);}$limit=$e['limite']??50;
        $query=array('connection_id'=>$cfg['connection_id'],'account_id'=>$cfg['account_id'],'ads_level'=>'campaign','date_from'=>$e['de'],'date_to'=>$e['ate'],'limit'=>$limit);$binding=hash('sha256',wp_json_encode(array($query,$cfg['revision'],$mapa_rev)));$cur=null;
        if(!empty($e['cursor'])){$cur=self::abrir_cursor($e['cursor']);if(!$cur||!is_string($cur['meta']??null)||!is_int($cur['expira']??null)){return self::erro('cursor_invalido');}if($cur['expira']<time()){return self::erro('cursor_expired');}if(($cur['consulta']??'')!==$binding){return self::erro('configuracao_alterada');}$query['cursor']=$cur['meta'];}
        $auth=self::chamar('status',array_intersect_key($cfg,array_flip(array('connection_id','account_id'))));if(empty($auth['success'])){return self::erro((string)($auth['code']??'resposta_sdk_invalida'));}if(($auth['data']['contract']??'')!==self::CONTRACT||($auth['data']['ready']??false)!==true){return self::erro('resposta_sdk_invalida');}
        $contacts=self::contatos($e['de'],$e['ate'],$cfg['account_id']);if(!$contacts['ok']){return self::erro($contacts['codigo']);}if($cur&&($cur['contatos']??'')!==$contacts['revisao']){return self::erro('contatos_alterados');}
        $r=self::chamar('query',$query);if(empty($r['success'])){return self::erro((string)($r['code']??'resposta_sdk_invalida'));}$d=$r['data']??array();
        if(($d['contract']??'')!==self::CONTRACT||!is_array($d['rows']??null)||!array_is_list($d['rows'])||count($d['rows'])>$limit||!is_int($d['generation']??null)||!is_int($d['grant_revision']??null)||!array_key_exists('next_cursor',$d)||($d['next_cursor']!==null&&(!is_string($d['next_cursor'])||$d['next_cursor']===''||strlen($d['next_cursor'])>50000))){return self::erro('resposta_sdk_invalida');}
        if($cur&&(($cur['geracao']??null)!==$d['generation']||($cur['concessao']??null)!==$d['grant_revision'])){return self::erro('history_changed');}
        $partners=array_column($mapa['parceiros'],null,'campanha_id');$rows=array();$seen=array();foreach($d['rows'] as $row){if(!is_array($row)||!self::validar_linha($row,$cfg,$e['de'],$e['ate'])||isset($seen[$row['row_id']])){return self::erro('linha_meta_invalida');}$seen[$row['row_id']]=true;$campaign=$row['row']['campaign_id'];$explicit=isset($partners[$campaign]);$partner=$partners[$campaign]??($mapa['parceiro_padrao']['parceiro_id']!==''?$mapa['parceiro_padrao']:null);$row['relacao_core']=array('plataforma'=>'meta_ads','conta_id'=>$cfg['account_id'],'campanha_id'=>$campaign,'parceiro'=>$partner?array('id'=>$partner['parceiro_id'],'rotulo'=>$partner['rotulo'],'fonte'=>$explicit?'mapa_explicito_core':'mapa_conta_core'):null,'codigo_parceiro'=>$partner?'mapeado':'sem_mapa_explicito','contatos'=>self::contagem($contacts['linhas'],$campaign,$row['data_day'],$row['timezone']));$rows[]=$row;}
        // Recheck both ends after joining. No partial page survives a changed grant or contact set.
        if(self::configuracao()!==$cfg||F3Base_Options::revisao(self::OPTION)!==$mapa_rev){return self::erro('configuracao_alterada');}$after=self::contatos($e['de'],$e['ate'],$cfg['account_id']);if(!$after['ok']){return self::erro($after['codigo']);}if($after['revisao']!==$contacts['revisao']){return self::erro('contatos_alterados');}
        $status=self::chamar('status',array_intersect_key($cfg,array_flip(array('connection_id','account_id'))));if(empty($status['success'])){return self::erro((string)($status['code']??'resposta_sdk_invalida'));}if(($status['data']['grant_revision']??null)!==$d['grant_revision']){return self::erro('revision_conflict');}
        $next=$d['next_cursor']?self::cursor(array('meta'=>$d['next_cursor'],'consulta'=>$binding,'contatos'=>$contacts['revisao'],'geracao'=>$d['generation'],'concessao'=>$d['grant_revision'],'expira'=>time()+DAY_IN_SECONDS)):null;
        return array('ok'=>true,'fonte'=>'Meta Ads / acervo local','contrato'=>self::CONTRACT,'plataforma'=>'meta_ads','conta_id'=>$cfg['account_id'],'nivel'=>'campaign','periodo'=>array('de'=>$e['de'],'ate'=>$e['ate']),'linhas'=>$rows,'proximo_cursor'=>$next,'pagina_final'=>$next===null,'geracao'=>$d['generation'],'revisao_concessao'=>$d['grant_revision'],'revisao_configuracao'=>$cfg['revision'],'revisao_mapa'=>$mapa_rev,'revisao_contatos'=>$contacts['revisao'],'cobertura_contatos'=>array('examinados'=>$contacts['examinados'],'vinculados_por_ids'=>count($contacts['linhas']),'atribuidos_sem_identidade_de_conta_incluidos'=>false),'cobertura'=>$d['coverage']??null,'retencao'=>$d['retention']??null,'atribuicao'=>$d['attribution']??null,'http_fornecedor'=>false,'totais_agregados'=>false,'limites'=>array('Ausência permanece null; last_available_fields é observação anterior datada, não confirmação corrente.','As linhas são observações armazenadas; dia sem linha não prova zero nem cobertura integral.','Não somar alcance, frequência, tipos de resultado sobrepostos ou moedas/fusos diferentes.','Contatos são aceitos reais no dia da captura e vinculados por IDs estáveis; a contagem não comprova equivalência à janela de atribuição Meta.','Pessoas distintas usam e-mail/telefone exatos no recorte de cada linha, não identidade civil; não somar entre linhas.'));
    }
}
