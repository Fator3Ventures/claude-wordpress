<?php
/** Projeção fechada do catálogo fotografado no contato, sem respostas livres. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Demanda {
    public static function respostas(array $data,string $formulario): array {
        $native=!empty($data['origem_nativa']);$rev=$data['formulario_revisao']??'';
        if($native){$catalog=$data['catalogo_nativo']??array();$fields=$catalog['campos']??array();$rev=$catalog['revisao']??hash('sha256',wp_json_encode($fields));}
        else{$current=F3Base_Formularios::obter($formulario);$fields=$data['campos_relatorio']??($current&&F3Base_Formularios::revisao($current)===$rev?$current['campos']:array());}
        $out=array();$closed=0;$unknown=0;
        foreach($fields as $field){
            if(!is_array($field)||!empty($field['papel'])||!is_string($field['nome']??null)||(!$native&&!in_array($field['tipo']??'',array('select','radio','checkbox'),true))){continue;}
            $options=array();$labels=array();foreach($field['opcoes']??array() as $o){
                $value=is_string($o)?$o:($o['valor']??null);$label=is_string($o)?$o:($o['rotulo']??null);
                if(!is_string($value)||!is_string($label)||$value===''||$label===''){continue;}$options[$value]=$label;$labels[$label]=($labels[$label]??0)+1;
            }
            if(!$options){continue;}++$closed;$raw=$data['campos'][$field['nome']]??null;$seen=array();
            foreach(is_array($raw)?$raw:array($raw) as $value){
                if(!is_string($value)||$value===''){continue;}$id=array_key_exists($value,$options)?$value:(($labels[$value]??0)===1?array_search($value,$options,true):false);
                if($id===false){++$unknown;continue;}$id=(string)$id;if(isset($seen[$id])){continue;}$seen[$id]=true;
                $out[]=array('formulario'=>$formulario,'revisao'=>(string)$rev,'pergunta_id'=>$field['nome'],'campo'=>$field['rotulo']??$field['nome'],'opcao_id'=>$id,'resposta'=>$options[$id],'catalogo_fonte'=>$native?'catalogo_nativo':'formulario_site');
            }
        }
        return array('linhas'=>$out,'perguntas_fechadas'=>$closed,'respostas_fora_catalogo'=>$unknown);
    }
}
