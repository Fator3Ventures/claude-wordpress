<?php
/** Regras comerciais locais do pedido 226. Não chama fornecedores nem grava estado. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Pipedrive_Comercial {
    public static function padroes(): array {
        return array(
            'whatsapp_texto'=>'',
            'empresas_invalidas'=>array('não tem','nenhuma','autônomo','sim','não','x','-','particular','pessoa física','pf','mei','ainda não'),
            'mapa_servicos_formularios'=>array(), 'mapa_servicos_campanhas'=>array(),
            'atividade_canais'=>array('whatsapp'=>array('tipo'=>'whatsapp','assunto'=>'WhatsApp'),'email'=>array('tipo'=>'email','assunto'=>'E-mail – primeiro contato'),'task'=>array('tipo'=>'task','assunto'=>'Conferir contato')),
            'atividade_janela'=>array('fuso'=>'America/Sao_Paulo','dias'=>array(1,2,3,4,5),'inicio'=>'08:00','fim'=>'19:00','minutos'=>60,'retomada'=>'09:30'),
        );
    }
    public static function schemas(): array {
        $text=static fn($n)=>array('type'=>'string','maxLength'=>$n);
        $map=array('type'=>'object','maxProperties'=>500,'additionalProperties'=>array('type'=>'string','pattern'=>'^[1-9][0-9]*$','maxLength'=>20));
        $canal=array('type'=>'object','additionalProperties'=>false,'required'=>array('tipo','assunto'),'properties'=>array('tipo'=>array('type'=>'string','pattern'=>'^[a-z0-9_-]+$','maxLength'=>50),'assunto'=>array('type'=>'string','minLength'=>1,'maxLength'=>200)));
        $hour=array('type'=>'string','pattern'=>'^(?:[01][0-9]|2[0-3]):[0-5][0-9]$');
        return array('whatsapp_texto'=>$text(1000),'empresas_invalidas'=>array('type'=>'array','maxItems'=>200,'items'=>$text(200)),
            'mapa_servicos_formularios'=>$map,'mapa_servicos_campanhas'=>$map,
            'atividade_canais'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('whatsapp','email','task'),'properties'=>array_fill_keys(array('whatsapp','email','task'),$canal)),
            'atividade_janela'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('fuso','dias','inicio','fim','minutos','retomada'),'properties'=>array('fuso'=>$text(100),'dias'=>array('type'=>'array','minItems'=>1,'maxItems'=>7,'uniqueItems'=>true,'items'=>array('type'=>'integer','minimum'=>1,'maximum'=>7)),'inicio'=>$hour,'fim'=>$hour,'minutos'=>array('type'=>'integer','minimum'=>1,'maximum'=>660),'retomada'=>$hour)));
    }
    public static function validar(array $cfg): string {
        if(preg_match_all('/\{([^}]+)\}/',$cfg['whatsapp_texto']??'',$vars)&&array_diff($vars[1],array('nome','empresa','unidade'))){return 'whatsapp_texto: variável desconhecida.';}
        foreach(self::schemas() as $key=>$schema){if(array_key_exists($key,$cfg)){$r=rest_validate_value_from_schema($cfg[$key],$schema,$key);if(is_wp_error($r)){return $r->get_error_message();}}}
        if(isset($cfg['atividade_janela'])){$w=$cfg['atividade_janela'];if(!in_array($w['fuso'],DateTimeZone::listIdentifiers(),true)){return 'atividade_janela: fuso IANA inválido.';}
            $minutes=static fn($s)=>(int)substr($s,0,2)*60+(int)substr($s,3,2);
            if($w['inicio']>=$w['fim']||$w['retomada']<$w['inicio']||$w['retomada']>$w['fim']||$w['minutos']>$minutes($w['fim'])-$minutes($w['inicio'])){return 'atividade_janela: intervalo, prazo ou retomada incompatíveis.';}}
        foreach(array('mapa_servicos_formularios','mapa_servicos_campanhas') as $map){foreach($cfg[$map]??array() as $key=>$id){if(!preg_match('/^(?:meta|google|linkedin):[A-Za-z0-9_.:-]{1,200}$/D',(string)$key)){return $map.': use origem:ID (meta, google ou linkedin).';}}}
        return '';
    }
    private static function normalizar(string $v): string {return mb_strtolower(trim(preg_replace('/\s+/u',' ',remove_accents($v))));}
    public static function empresa(array $ctx,array $cfg): array {
        $value=trim((string)($ctx['empresa']??''));$normal=self::normalizar($value);$reason='';
        if($value===''){$reason='empresa_vazia';}
        elseif(mb_strlen(preg_replace('/[^\p{L}]/u','',$value))<3){$reason='empresa_menos_de_tres_letras';}
        elseif(is_email($value)||str_contains($value,'@')){$reason='empresa_email';}
        elseif(preg_match('~(?:https?://|www\.)|^(?:[\p{L}\d-]+\.)+[\p{L}]{2,}(?:[/?:#].*)?$~iu',$value)){$reason='empresa_url';}
        elseif(preg_match('/^[+()\d\s.\/-]+$/D',$value)){$reason='empresa_telefone';}
        elseif($normal===self::normalizar((string)($ctx['nome']??''))){$reason='empresa_igual_a_pessoa';}
        elseif(in_array($normal,array_map(array(__CLASS__,'normalizar'),$cfg['empresas_invalidas']??self::padroes()['empresas_invalidas']),true)){$reason='empresa_resposta_negativa';}
        return array('valida'=>$reason==='','nome'=>$reason===''?$value:'','motivo'=>$reason?:'empresa_valida');
    }
    public static function unidade(array $cfg): string {
        $key=$cfg['mapa_campos']['unidade']??'';$id=(string)($cfg['unidade']??'');
        $state=get_option('f3base_pipedrive_estado',array());if(($state['dominio']??'')!==($cfg['dominio']??'')){return '';}
        foreach($state['catalogos']['campos']??array() as $f){if(($f['field_code']??$f['key']??'')!==$key){continue;}foreach($f['options']??array() as $o){if((string)$o['id']===$id){return (string)($o['label']??$o['name']??'');}}}return '';
    }
    public static function respostas(array $lead): string {
        $d=$lead['dados']??array();$defs=array();foreach($d['campos_snapshot']??$d['catalogo_nativo']['campos']??array() as $f){$defs[$f['nome']]=$f;}$lines=array();
        $clean=static fn($v)=>trim(preg_replace('/[\r\n]+/u',' ',wp_strip_all_tags((string)$v)));
        foreach($d['campos']??array() as $key=>$value){$f=$defs[$key]??array();if(($f['tipo']??'')==='file'){continue;}$labels=array();foreach($f['opcoes']??array() as $o){if(is_array($o)){$labels[(string)($o['valor']??$o['value']??'')]=(string)($o['rotulo']??$o['label']??$o['valor']??'');}}
            $values=array();foreach(is_array($value)?$value:array($value) as $v){if(is_bool($v)){$values[]=$v?'Sim':'Não';}elseif(is_scalar($v)){$values[]=$clean($labels[(string)$v]??$v);}}
            $lines[]=$clean($f['rotulo']??($key.' (rótulo histórico indisponível)')).': '.implode('; ',$values);
        }return implode("\n",$lines);
    }
    public static function servico(array $ctx,array $cfg): array {
        $native=$ctx['origem_nativa']??array();$origin=(string)($native['origem']??'');$form=(string)($native['formulario_id']??'');$campaign=(string)($native['campanha_id']??$ctx['atribuicao']['campanha_id']??'');$ids=array();$source='resposta';
        foreach((array)($ctx['servicos']??array()) as $name){$v=$cfg['mapa_servicos'][($ctx['formulario_id']??'').':'.$name]??$cfg['mapa_servicos'][$name]??null;if($v!==null){$ids[]=(string)$v;}}
        if(!$ids&&$origin!==''&&$form!==''&&isset($cfg['mapa_servicos_formularios'][$origin.':'.$form])){$ids[]=(string)$cfg['mapa_servicos_formularios'][$origin.':'.$form];$source='formulario_nativo';}
        if(!$ids&&$campaign!==''){$mapKey=$origin.':'.$campaign;if($origin===''){$platform=$ctx['atribuicao']['plataforma']??'';$mapKey=(array('meta_ads'=>'meta','google_ads'=>'google','linkedin_ads'=>'linkedin')[$platform]??'').':'.$campaign;}if(isset($cfg['mapa_servicos_campanhas'][$mapKey])){$ids[]=(string)$cfg['mapa_servicos_campanhas'][$mapKey];$source='campanha';}}
        $missing=!$ids&&($origin!==''||$campaign!=='');
        return array('ids'=>array_values(array_unique($ids)),'origem'=>$ids?$source:'sem_mapa','formulario'=>$form?:($ctx['formulario_id']??''),'campanha'=>$campaign,'aviso'=>$missing?'serviço não mapeado — formulário: '.($form?:($ctx['formulario_id']??'não informado')).'; campanha: '.($campaign?:'não informada'):'');
    }
    public static function qualidade(array $ctx,array $cfg): array {
        $q=array();$org=self::empresa($ctx,$cfg);if(!$org['valida']&&($ctx['empresa']??'')!==''){$q[]=$org['motivo'];}
        $s=self::servico($ctx,$cfg);if($s['aviso']!==''){$q[]=$s['aviso'];}
        $n=$ctx['origem_nativa']??array();if($n){
            if(empty($ctx['atribuicao']['anuncio_id'])&&empty($ctx['atribuicao']['f3_ads_ad_name'])){$q[]=!empty($n['anuncio_id'])?'anuncio_omitido_por_politica':($n['anuncio_motivo']??'anuncio_ausente_sem_evidencia_historica');}
            if(empty($cfg['mapa_campos']['anuncio'])){$q[]='anuncio_sem_campo_mapeado';}
            if(empty($cfg['mapa_campos']['lead_nativo_id'])&&!(($n['origem']??'')==='meta'&&F3Base_Qualidade::config()['campo_meta_id']!=='')){$q[]='lead_nativo_id_sem_campo_mapeado';}
        }return $q;
    }
    public static function whatsapp(array $ctx,array $cfg): string {
        if(F3Base_Telefone::nao_normalizado($ctx)){return '';}
        $phone=F3Base_Pipedrive_Api::telefone((string)($ctx['telefone']??''),$cfg['pais_telefone']??'BR');
        // BR/PT fixed lines are not selected as mobile. Other E.164 numbers are syntactically eligible; reachability is not asserted.
        $mobile=in_array(F3Base_Telefone::classificacao((string)($ctx['telefone']??''),$cfg['pais_telefone']??'BR')['tipo'],array('celular','internacional'),true);
        if(!$mobile){return '';}
        $url='https://wa.me/'.substr($phone,1);
        $model=trim((string)($cfg['whatsapp_texto']??''));
        if($model!==''){$values=array();foreach(array('nome','empresa') as $key){$values['{'.$key.'}']=wp_strip_all_tags((string)($ctx[$key]??''));}$values['{unidade}']=self::unidade($cfg);$text=trim(strtr($model,$values));if($text!==''){while(strlen(rawurlencode($text))>1700){$text=mb_substr($text,0,mb_strlen($text)-1);}$url.='?text='.rawurlencode($text);}}
        return $url;
    }
    public static function whatsapp_pessoa(array $ctx,array $cfg): array {
        $key=$cfg['mapa_pessoa']['whatsapp_link']??'';$url=self::whatsapp($ctx,$cfg);
        if($key===''||$url===''){return array();}
        $state=get_option('f3base_pipedrive_estado',array());if(($state['dominio']??'')!==($cfg['dominio']??'')){return array();}
        foreach($state['catalogos']['pessoa_campos']??array() as $f){if(($f['key']??$f['field_code']??'')===$key&&in_array($f['field_type']??'',array('varchar','text','varchar_auto'),true)&&mb_strlen($url)<=(int)($f['max_length']??(($f['field_type']??'')==='text'?65535:255))){return array($key=>$url);}}return array();
    }
    public static function atividade(array $ctx,array $cfg,bool $reenvio=false): array {
        $defaults=self::padroes();$cfg=array_replace($defaults,$cfg);$w=$cfg['atividade_janela'];
        $whatsapp=self::whatsapp($ctx,$cfg);$mobile=$whatsapp!=='';
        $channel=$mobile?'whatsapp':(is_email((string)($ctx['email']??''))?'email':'task');$choice=$cfg['atividade_canais'][$channel];
        if($reenvio){$choice=array('tipo'=>'task','assunto'=>'Reenvio de formulário');$channel='reenvio';}
        $stamp=(int)strtotime((string)($ctx['capturado_em']??'').' UTC');if($stamp<=0){return array('ok'=>false,'codigo'=>'captura_sem_instante');}
        $tz=new DateTimeZone($w['fuso']);$in=(new DateTimeImmutable('@'.$stamp))->setTimezone($tz);$due=$in->modify('+'.$w['minutos'].' minutes');if($due->format('s')!=='00'){$due=$due->modify('+1 minute');$due=$due->setTime((int)$due->format('H'),(int)$due->format('i'),0);}
        $workday=static fn($d)=>in_array((int)$d->format('N'),$w['dias'],true);
        if(!$workday($in)||$in->format('H:i')<$w['inicio']||$due->format('Y-m-d')!==$in->format('Y-m-d')||$due->format('H:i:s')>$w['fim'].':00'){
            $day=$in;if($workday($day)&&$day->format('H:i')>=$w['inicio']){$day=$day->modify('+1 day');}
            for($i=0;$i<8&&!$workday($day);$i++){$day=$day->modify('+1 day');}
            [$h,$m]=array_map('intval',explode(':',$w['retomada']));$due=$day->setTime($h,$m,0);
        }
        $utc=$due->setTimezone(new DateTimeZone('UTC'));
        return array('ok'=>true,'telefone_classificacao'=>F3Base_Telefone::classificacao((string)($ctx['telefone']??''),$cfg['pais_telefone']??'BR'),'whatsapp_link'=>$whatsapp,'note'=>($mobile&&($channel==='whatsapp'||$reenvio)?'<p>WhatsApp: <a href="'.esc_url($whatsapp).'">'.esc_html($whatsapp).'</a></p>':''),'canal'=>$channel,'type'=>$choice['tipo'],'subject'=>$choice['assunto'],'due_date'=>$utc->format('Y-m-d'),'due_time'=>$utc->format('H:i'),'prazo_em'=>$due->getTimestamp(),'prazo_local'=>$due->format('Y-m-d H:i:s P'),'fuso'=>$w['fuso'],'habilitada'=>!empty($cfg['atividade'])||$reenvio);
    }
    public static function link(array $opp,array $cfg): string {
        $domain=$cfg['dominio']??'';if(!preg_match('/^[a-z0-9][a-z0-9-]{0,62}\.pipedrive\.com$/D',$domain)){return '';}
        $id=(string)($opp['id']??'');if(($opp['tipo']??'')==='lead'&&preg_match('/^[a-f0-9-]{36}$/D',$id)){return 'https://'.$domain.'/leads/inbox/'.$id;}
        if(($opp['tipo']??'')==='negocio'&&ctype_digit($id)&&(int)$id>0){return 'https://'.$domain.'/deal/'.$id;}return '';
    }
}
