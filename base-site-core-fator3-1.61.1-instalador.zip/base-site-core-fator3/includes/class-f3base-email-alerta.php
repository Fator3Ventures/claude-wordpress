<?php
/** One opening and recovery intent per mailbox incident, without message bodies. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Alerta {
    const HOOK='f3base_email_site_saude';
    public static function iniciar(): void {
        add_action('init',static function(){if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}},92);
        add_action(self::HOOK,static function(){try{self::observar();F3Base_Email_Site::continuacoes();}finally{F3Base_Fila::agendar(self::HOOK,time()+300);}});
    }
    public static function observar(): void {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-alerta')){return;}
        try{
            $health=F3Base_Email_Site::saude();if($health['estado']==='desligada'){return;}
            $state=get_option(F3Base_Email_Site_Config::STATE,array());$alarm=$state['alarme']??array();
            $code=(string)($health['codigo']??'');$error=$code!==''&&$code!=='sem_erro';
            $cfg=F3Base_Options::ler('f3base_avisos_tecnicos');$limit=max(60,(int)($cfg['atraso_minutos']??60))*MINUTE_IN_SECONDS;
            $complete=(int)($state['ultima_leitura_completa']??$state['ultimo_sucesso']??$state['ativado_em']??time());
            $bad=$error||time()-$complete>=$limit;
            if($bad&&!empty($alarm['aberto'])){return;}if(!$bad&&empty($alarm['aberto'])){return;}
            $closing=!$bad;
            if($closing&&empty($alarm['atencao_aceita'])){$alarm['aberto']=false;$alarm['encerrado_sem_aviso_em']=time();F3Base_Email_Site::estado(array('alarme'=>$alarm));return;}
            $title=$closing?'Captação de e-mail recuperada':'Captação de e-mail requer atenção';$type=$closing?'recuperacao':'abertura';
            $alarm=$closing?array_replace($alarm,array('aberto'=>false)):array('aberto'=>true,'incidente'=>wp_generate_uuid4(),'inicio'=>time(),'atencao_aceita'=>false);
            $alarm[$type]=array('estado'=>'reservado','em'=>time());F3Base_Email_Site::estado(array('alarme'=>$alarm));
            $test=!empty(F3Base_Email_Site::cfg()['homologacao']);
            $text=$title.' — '.get_bloginfo('name')."\nEstado: ".$health['estado']."\nCódigo: ".($error?$code:'leitura_completa_atrasada')."\n".F3Base_Configuracoes_Hub::url('conexoes','f3base_email_site');
            $result=F3Base_Alertas_Operacionais::enviar($title,$text,$test);
            if(!$closing){$alarm['atencao_aceita']=!empty($result['ok'])&&($result['estado']??'')!=='suprimido_teste';}
            $alarm[$type]=$result+array('em'=>time());F3Base_Email_Site::estado(array('alarme'=>$alarm));
        }finally{F3Base_Pipedrive_Fila::liberar_linha('email-alerta');}
    }
}
