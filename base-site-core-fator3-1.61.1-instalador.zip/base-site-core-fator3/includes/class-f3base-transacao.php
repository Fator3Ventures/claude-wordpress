<?php
/** Inspect the persistence boundary without committing or rolling back caller work. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Transacao {
    public static function autocommit(): bool {
        global $wpdb;$name='f3_core_'.bin2hex(random_bytes(12));$previous=$wpdb->suppress_errors(true);
        try {
            if((string)$wpdb->get_var('SELECT @@session.autocommit')!=='1'){return false;}
            if($wpdb->query('SAVEPOINT '.$name)===false){return false;}
            if($wpdb->query('RELEASE SAVEPOINT '.$name)!==false){return false;}
            $ok=$wpdb->dbh instanceof mysqli&&mysqli_errno($wpdb->dbh)===1305;
            if($ok){$wpdb->last_error='';}return $ok;
        } finally {$wpdb->suppress_errors($previous);}
    }
}
