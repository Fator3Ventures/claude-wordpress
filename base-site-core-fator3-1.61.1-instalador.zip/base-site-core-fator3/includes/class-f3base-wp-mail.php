<?php
/** WordPress mail through the site mailbox, with a durable quota outbox. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Wp_Mail {
    const HOOK='f3base_wp_mail_processar';
    const STATE='f3base_wp_mail_estado';
    private static bool $sending=false;

    public static function tabela(): string { global $wpdb; return $wpdb->prefix.'f3base_wp_mail'; }
    public static function instalar(): bool {
        global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta('CREATE TABLE '.self::tabela()." (
 id char(32) NOT NULL,
 estado varchar(24) NOT NULL,
 codigo varchar(96) NOT NULL,
 fase varchar(24) NOT NULL DEFAULT '',
 assinatura char(64) NOT NULL,
 payload longtext NOT NULL,
 destinatarios int unsigned NOT NULL,
 criado_em bigint unsigned NOT NULL,
 atualizado_em bigint unsigned NOT NULL,
 proxima bigint unsigned NOT NULL,
 PRIMARY KEY  (id),
 KEY agenda (estado,proxima)
) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');
        return !$wpdb->last_error;
    }
    public static function catalogo(array $c): array {
        $c[self::STATE]=array('rotulo'=>'Último resultado do e-mail WordPress','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade')); return $c;
    }
    public static function outro(): ?string {
        $active=array_merge((array)get_option('active_plugins',array()),array_keys((array)get_site_option('active_sitewide_plugins',array())));
        $known=array('wp-mail-smtp','wp-mail-smtp-pro','easy-wp-smtp','fluent-smtp','post-smtp','smtp-mailer','wp-smtp','wp-mail-bank','wp-offload-ses','mailgun','sendgrid-email-delivery-simplified','brevo');
        foreach($active as $file){if(in_array(explode('/',$file)[0],$known,true)){return $file;}}
        return null;
    }
    public static function avisos(): array {
        $other=self::outro();return self::cfg_ativa()&&$other?array('wp_mail_outro_smtp'=>array('nome'=>'f3base_email_site','ativo'=>true,'motivo'=>'O transporte WordPress foi cedido ao plugin SMTP ativo: '.$other.'.','acao'=>'Confira remetente, cota e diagnóstico nesse plugin. O Core não envia estas mensagens.','em'=>time())):array();
    }
    private static function cfg_ativa(): bool {return !empty(F3Base_Email_Site::cfg()['wp_mail_pela_caixa']);}
    private static function pronta(array $cfg): bool {
        return !empty($cfg['wp_mail_pela_caixa'])&&!empty($cfg['alocacao_confirmada'])&&is_email($cfg['endereco'])&&trim($cfg['nome_exibicao'])!==''&&$cfg['usuario']!==''&&F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET)!=='';
    }
    private static function enderecos($mail,$list,string $method): void {
        foreach((array)$list as $line){
            if(!is_string($line)||preg_match('/[\r\n\x00]/',$line)){throw new RuntimeException('destinatario_invalido');}
            $parsed=\PHPMailer\PHPMailer\PHPMailer::parseAddresses($line,false,'UTF-8');
            if(!$parsed){throw new RuntimeException('destinatario_invalido');}
            foreach($parsed as $address){if(!is_email($address['address'])){throw new RuntimeException('destinatario_invalido');}$mail->$method($address['address'],$address['name']);}
        }
    }
    /** Recheck after message hooks; snapshot local files with a bounded read before any SMTP effect. */
    private static function anexos($mail): void {
        $bytes=strlen($mail->Body)+strlen($mail->AltBody);if($bytes>8*MB_IN_BYTES){throw new RuntimeException('mensagem_limite');}
        $attachments=$mail->getAttachments();$mail->clearAttachments();
        foreach($attachments as $a){$remaining=8*MB_IN_BYTES-$bytes;
            if(!empty($a[5])){$data=$a[0];}
            else{$path=$a[0];if(!is_string($path)||!stream_is_local($path)||!is_file($path)||!is_readable($path)){throw new RuntimeException('anexo_indisponivel');}
                clearstatcache(true,$path);$size=filesize($path);if($size===false||$size>$remaining){throw new RuntimeException('mensagem_limite');}$data=file_get_contents($path,false,null,0,$remaining+1);if($data===false){throw new RuntimeException('anexo_indisponivel');}
            }
            $bytes+=strlen($data);if($bytes>8*MB_IN_BYTES){throw new RuntimeException('mensagem_limite');}
            $name=$a[2]!==''?$a[2]:$a[1];
            if($a[6]==='inline'){$mail->addStringEmbeddedImage($data,$a[7],$name,$a[3],$a[4],$a[6]);}
            else{$mail->addStringAttachment($data,$name,$a[3],$a[4],$a[6]);}
        }
    }
    /** Materialize attachments now; a later worker never reads caller-selected paths. */
    public static function mensagem(array $atts,array $cfg,string $id): array {
        require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
        $mail=new \PHPMailer\PHPMailer\PHPMailer(true);$mail->isSMTP();$mail->CharSet='UTF-8';
        $mail->setFrom($cfg['endereco'],$cfg['nome_exibicao']);$mail->Sender=$cfg['endereco'];
        $mail->MessageID='<f3base-'.$id.'@'.substr(strrchr($cfg['endereco'],'@'),1).'>';
        self::enderecos($mail,$atts['to']??array(),'addAddress');
        $headers=$atts['headers']??array();if(!is_array($headers)){$headers=preg_split('/\r?\n/',$headers);}
        $type='text/plain';$charset=(string)get_bloginfo('charset');
        foreach($headers as $header){
            if(trim($header)===''){continue;}
            if(preg_match('/[\r\n\x00]/',$header)||!str_contains($header,':')){throw new RuntimeException('cabecalho_invalido');}
            [$name,$value]=array_map('trim',explode(':',$header,2));$lower=strtolower($name);
            if(in_array($lower,array('from','sender','return-path','to','message-id','mime-version','content-transfer-encoding'),true)){continue;}
            if(isset(array('cc'=>1,'bcc'=>1,'reply-to'=>1)[$lower])){self::enderecos($mail,$value,array('cc'=>'addCC','bcc'=>'addBCC','reply-to'=>'addReplyTo')[$lower]);}
            elseif($lower==='content-type'){$parts=explode(';',$value);$type=trim($parts[0]);if(preg_match('/charset\s*=\s*["\']?([a-zA-Z0-9_-]+)/i',$value,$m)){$charset=$m[1];}if(str_starts_with(strtolower($type),'multipart/')){$type=$value;}}
            elseif(!$mail->addCustomHeader($name,$value)){throw new RuntimeException('cabecalho_invalido');}
        }
        $mail->ContentType=apply_filters('wp_mail_content_type',$type);$mail->CharSet=apply_filters('wp_mail_charset',$charset);
        $mail->Subject=(string)($atts['subject']??'');$mail->Body=(string)($atts['message']??'');$mail->AllowEmpty=true;
        $bytes=strlen($mail->Body);if($bytes>8*MB_IN_BYTES){throw new RuntimeException('mensagem_limite');}
        foreach(array('attachments','embeds') as $kind){
            $files=$atts[$kind]??array();if(!is_array($files)){$files=preg_split('/\r?\n/',$files);}
            foreach($files as $key=>$path){if($path===''){continue;}if(!is_string($path)||!is_file($path)||!is_readable($path)||!stream_is_local($path)){throw new RuntimeException('anexo_indisponivel');}$bytes+=(int)filesize($path);if($bytes>8*MB_IN_BYTES){throw new RuntimeException('mensagem_limite');}
                if($kind==='embeds'){$args=apply_filters('wp_mail_embed_args',array('path'=>$path,'cid'=>(string)$key,'name'=>basename($path),'encoding'=>'base64','type'=>'','disposition'=>'inline'));$mail->addEmbeddedImage($args['path'],$args['cid'],$args['name'],$args['encoding'],$args['type'],$args['disposition']);}
                else{$mail->addAttachment($path,is_string($key)?$key:'');}
            }
        }
        // Preserve message customization. Transport and aligned sender remain owned by the configured mailbox.
        do_action_ref_array('phpmailer_init',array(&$mail));
        if(!$mail instanceof \PHPMailer\PHPMailer\PHPMailer){throw new RuntimeException('mime_invalido');}
        $mail->isSMTP();$mail->setFrom($cfg['endereco'],$cfg['nome_exibicao']);$mail->Sender=$cfg['endereco'];
        $mail->MessageID='<f3base-'.$id.'@'.substr(strrchr($cfg['endereco'],'@'),1).'>';
        $custom=$mail->getCustomHeaders();$mail->clearCustomHeaders();foreach($custom as $header){if(!in_array(strtolower($header[0]),array('from','sender','return-path','to','cc','bcc','message-id','mime-version','content-transfer-encoding'),true)){$mail->addCustomHeader($header[0],$header[1]);}}
        foreach(array_keys($mail->getAllRecipientAddresses()) as $address){if(!is_email($address)){throw new RuntimeException('destinatario_invalido');}}
        self::anexos($mail);
        if(!$mail->preSend()){throw new RuntimeException('mime_invalido');}
        $mime=$mail->getSentMIMEMessage();$recipients=array_keys($mail->getAllRecipientAddresses());
        if(!$recipients||strlen($mime)>12*MB_IN_BYTES){throw new RuntimeException('mensagem_limite');}
        if(!empty($cfg['homologacao'])&&array_diff(array_map('strtolower',$recipients),array_map('strtolower',$cfg['homologacao_emails']))){throw new RuntimeException('destino_fora_homologacao');}
        return array('mime'=>$mime,'destinatarios'=>$recipients,'remetente'=>$cfg['endereco']);
    }
    private static function diagnostico(string $code,string $phase,?string $id=null): void {
        F3Base_Options::atualizar_estado(self::STATE,static fn($s)=>array('em'=>time(),'codigo'=>$code,'fase'=>$phase,'id'=>$id));
    }
    public static function interceptar($pre,array $atts) {
        $cfg=F3Base_Email_Site::cfg();if($pre!==null||empty($cfg['wp_mail_pela_caixa'])){return $pre;}
        if(self::outro()){return $pre;} // The active SMTP plugin owns wp_mail and its own quotas.
        if(self::$sending){return false;}self::$sending=true;
        try{
            if(!self::pronta($cfg)||!F3Base_Transacao::autocommit()){self::diagnostico('smtp_configuracao_ou_transacao_pendente','preparo');return false;}
            $id=bin2hex(random_bytes(16));$message=self::mensagem($atts,$cfg,$id);$cipher=F3Base_Contato_Comunicacao::cifrar($message);
            if(!$cipher){self::diagnostico('smtp_cifragem_falhou','preparo');return false;}
            global $wpdb;$row=array('id'=>$id,'estado'=>'pendente','codigo'=>'aguardando_cota','fase'=>'cota','assinatura'=>F3Base_SMTP_Prova::assinatura($cfg),'payload'=>$cipher,'destinatarios'=>count($message['destinatarios']),'criado_em'=>time(),'atualizado_em'=>time(),'proxima'=>time());
            if($wpdb->insert(self::tabela(),$row)!==1){self::diagnostico('smtp_fila_falhou','persistencia');return false;}
            $r=self::executar($id);if($r['estado']==='pendente'){F3Base_Fila::agendar(self::HOOK,time()+60);}
            $accepted=in_array($r['estado'],array('enviado','pendente'),true);
            // An observer failure cannot turn a persisted SMTP acceptance into a
            // false return and invite the caller to submit the same message again.
            try{if($r['estado']==='enviado'){do_action('wp_mail_succeeded',$atts);}elseif(!$accepted){do_action('wp_mail_failed',new WP_Error($r['codigo'],'Falha no SMTP autenticado; consulte o diagnóstico do Core.',array('id'=>$id)));}}
            catch(Throwable $e){self::diagnostico('wp_mail_hook_falhou','notificacao',$id);}
            return $accepted; // true also means durably accepted by the quota outbox, documented in help.
        }catch(Throwable $e){$code=preg_match('/^[a-z_]{1,80}$/D',$e->getMessage())?$e->getMessage():'smtp_preparo_falhou';self::diagnostico($code,'preparo');return false;}
        finally{self::$sending=false;}
    }
    public static function transmitir(array $message,array $cfg): array {
        require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
        $mail=new \PHPMailer\PHPMailer\PHPMailer(true);
        try{
            F3Base_SMTP_Prova::configurar($mail,$cfg,F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET));
            // Server-side integrations may supply an SMTP transport; never exposed through MCP/config.
            $client=apply_filters('f3base_wp_mail_smtp_cliente',$mail->getSMTPInstance(),$cfg);
            if(!$client instanceof \PHPMailer\PHPMailer\SMTP){throw new RuntimeException('smtp_cliente_invalido');}$mail->setSMTPInstance($client);
            if(!$mail->smtpConnect()){return array('estado'=>'falhou','codigo'=>F3Base_SMTP_Prova::codigo($mail),'fase'=>$client->fase??'conexao');}
            $r=F3Base_Email_Novo_Lead::envelope($client,$message['mime'],$message['destinatarios'],$message['remetente']);
            $r['fase']=str_contains($r['codigo'],'remetente')?'mail':(str_contains($r['codigo'],'destinatario')?'rcpt':'data');
            if($r['estado']==='pendente'){$r['estado']='falhou';}return $r;
        }catch(Throwable $e){return array('estado'=>'falhou','codigo'=>F3Base_SMTP_Prova::codigo($mail,$e),'fase'=>$mail->getSMTPInstance()->fase??'preparo');}
        finally{$mail->smtpClose();}
    }
    public static function executar(string $id): array {
        global $wpdb;$lock=F3Base_Trava::adquirir('wp-mail-'.$id,90);if(!$lock){return array('estado'=>'pendente','codigo'=>'ocupado');}
        try{
            $row=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',self::tabela(),$id),ARRAY_A);if(!$row){return array('estado'=>'falhou','codigo'=>'intencao_ausente');}
            if($row['estado']!=='pendente'){return array_intersect_key($row,array_flip(array('estado','codigo','fase')));}
            $cfg=F3Base_Email_Site::cfg();if(!self::pronta($cfg)||self::outro()){return array('estado'=>'pendente','codigo'=>'transporte_pausado');}
            if(!hash_equals($row['assinatura'],F3Base_SMTP_Prova::assinatura($cfg))){$r=array('estado'=>'falhou','codigo'=>'conta_ou_credencial_alterada','fase'=>'preparo');}
            else{
                $message=F3Base_Contato_Comunicacao::abrir($row['payload']);
                if(!$message){$r=array('estado'=>'falhou','codigo'=>'snapshot_ilegivel','fase'=>'preparo');}
                elseif(!empty($cfg['homologacao'])&&array_diff(array_map('strtolower',$message['destinatarios']),array_map('strtolower',$cfg['homologacao_emails']))){$r=array('estado'=>'falhou','codigo'=>'destino_fora_homologacao','fase'=>'preparo');}
                elseif(!F3Base_Email_Novo_Lead::reservar_cota((int)$row['destinatarios'],(int)$cfg['cota_destinatarios_hora'])){
                    $wpdb->update(self::tabela(),array('proxima'=>time()+300,'atualizado_em'=>time(),'codigo'=>'retido_pela_cota'),array('id'=>$id,'estado'=>'pendente'));self::diagnostico('retido_pela_cota','cota',$id);return array('estado'=>'pendente','codigo'=>'retido_pela_cota');
                }else{
                    if($wpdb->update(self::tabela(),array('estado'=>'enviando','codigo'=>'transporte_reservado','atualizado_em'=>time()),array('id'=>$id,'estado'=>'pendente'))!==1){return array('estado'=>'incerto','codigo'=>'reserva_nao_confirmada');}
                    $r=self::transmitir($message,$cfg);
                }
            }
            // A process interrupted after reservation is never sent a second time.
            $saved=$wpdb->update(self::tabela(),$r+array('payload'=>'','atualizado_em'=>time()),array('id'=>$id));
            if($saved===false){$r=array('estado'=>'incerto','codigo'=>'recibo_nao_persistido','fase'=>'persistencia');}
            self::diagnostico($r['codigo'],$r['fase'],$id);return $r;
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function processar(): array {
        global $wpdb;
        $wpdb->query($wpdb->prepare("UPDATE %i SET estado='incerto',codigo='executor_interrompido',payload='',fase='indeterminada' WHERE estado='enviando' AND atualizado_em<%d",self::tabela(),time()-120));
        $cfg=F3Base_Email_Site::cfg();if(!self::pronta($cfg)||self::outro()){return array('ok'=>true,'codigo'=>'transporte_pausado');}
        $ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM %i WHERE estado='pendente' AND proxima<=%d ORDER BY proxima LIMIT 2",self::tabela(),time()));$out=array();foreach($ids as $id){$out[]=array('id'=>$id)+self::executar($id);}
        return array('ok'=>true,'itens'=>$out);
    }
    public static function resumo(): array {
        global $wpdb;$cfg=F3Base_Email_Site::cfg();$counts=$wpdb->get_results('SELECT estado,COUNT(*) n FROM '.self::tabela().' GROUP BY estado',ARRAY_A)?:array();
        return array('ativo'=>(bool)($cfg['wp_mail_pela_caixa']??false),'cedido_a'=>self::outro(),'ultimo'=>get_option(self::STATE,array()),'fila'=>array_column($counts,'n','estado'),'detalhe'=>'f3base/email-wordpress-fila-ler','regra'=>'Cota compartilhada com respostas e e-mail automático; aceite local pode aguardar cota. Falha ou resultado incerto nunca usa PHP mail nem é reenviado automaticamente. Outro plugin SMTP ativo possui seu transporte.');
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;$page=max(1,(int)($e['pagina']??1));
        return array('ok'=>true,'resumo'=>self::resumo(),'linhas'=>$wpdb->get_results($wpdb->prepare('SELECT id,estado,codigo,fase,destinatarios,criado_em,atualizado_em,proxima FROM %i ORDER BY criado_em DESC,id LIMIT 50 OFFSET %d',self::tabela(),($page-1)*50),ARRAY_A),'pagina'=>$page);
    }
    public static function iniciar(): void {
        add_filter('pre_wp_mail',array(__CLASS__,'interceptar'),PHP_INT_MAX,2);
        add_action('init',static function(){if(F3Base_Email_Site::cfg()['wp_mail_pela_caixa']&&!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+60);}},96);
        add_action(self::HOOK,static function(){try{return self::processar();}finally{if(F3Base_Email_Site::cfg()['wp_mail_pela_caixa']){F3Base_Fila::agendar(self::HOOK,time()+300);}}});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-wordpress-fila-ler','Ler recibos SMTP e retenções por cota, sem assunto, corpo ou destinatários',array(__CLASS__,'ler'),array('pagina'=>array('type'=>'integer','minimum'=>1)),array(),true);});
    }
}
