<?php
/** Core consumer of LinkedIn CAPI. No credentials or provider HTTP live here. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Conversoes {
 public const CONTRATO='site-linkedin-conversion/1.0.0';
 public static function verificar_regra(): array {
  $cap=F3Base_Conversoes_Transporte::capacidade('linkedin');return array('status'=>$cap['ready']?'verified':'pending','scope'=>'configuracao_local','codigo'=>$cap['ready']?'regra_api_vinculada':'linkedin_server_'.$cap['reason'],'motivo'=>$cap['ready']?'Regra coincide com a concessão local do adaptador; não comprova entrega externa.':'Envio pelo servidor bloqueado: '.str_replace('_',' ',$cap['reason']).'.','checked_at'=>time());
 }
 public static function fotografia(): array {
  return array('server_conversion_id'=>(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id'),'conversion_id'=>(string)F3Base_Options::ler('f3base_linkedin_conversion_id'),'partner_id'=>(string)F3Base_Options::ler('f3base_linkedin_partner_id'),'submetido_em_ms'=>(int)floor(microtime(true)*1000));
 }
 public static function regra(array $lead): string {return (string)($lead['dados']['linkedin_conversao']['server_conversion_id']??'');}
 public static function montar(array $lead): array {
  $fail=static fn($c)=>array('ok'=>false,'codigo'=>$c);$s=$lead['dados']['linkedin_conversao']??array();$rule=self::regra($lead);
  if(!preg_match('/^[1-9][0-9]{0,29}$/D',$rule)){return $fail('regra_ausente');}
  $at=$s['submetido_em_ms']??0;if(!is_int($at)||$at<=0||$at>(int)floor(microtime(true)*1000)+1000){return $fail('instante_linkedin_ausente');}
  $acq=F3Base_Aquisicoes::reservar($lead);if(empty($acq['elegivel'])||empty($acq['event_id'])){return $fail($acq['codigo']??'conversao_inelegivel');}
  $d=$lead['dados'];$ids=array();$email=strtolower(trim((string)($lead['email']??'')));if(is_email($email)){$ids[]=array('idType'=>'SHA256_EMAIL','idValue'=>hash('sha256',$email));}
  $fat=$d['atribuicao']['li_fat_id']??'';if(is_string($fat)&&preg_match('/^[A-Za-z0-9._~-]{1,500}$/D',$fat)){$ids[]=array('idType'=>'LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID','idValue'=>$fat);}
  $name=preg_split('/\s+/u',trim((string)($lead['nome']??$d['nome']??'')),2);$info=array();
  if(count($name)===2&&$name[0]!==''&&$name[1]!==''){$info=array('firstName'=>mb_substr($name[0],0,100),'lastName'=>mb_substr($name[1],0,100));}
  foreach(array('empresa'=>'companyName','cargo'=>'title') as $key=>$field){if(is_string($d[$key]??null)&&trim($d[$key])!==''){$info[$field]=mb_substr(trim($d[$key]),0,100);}}
  $country=strtoupper(trim((string)($d['campos']['pais']??$d['campos']['country_code']??'')));if(preg_match('/^[A-Z]{2}$/D',$country)){$info['countryCode']=$country;}
  if(!$ids&&(!isset($info['firstName'],$info['lastName']))){return $fail('identidade_linkedin_ausente');}
  $user=array('userIds'=>$ids);if(isset($info['firstName'],$info['lastName'])){$user['userInfo']=$info;}
  $p=array('contract'=>self::CONTRATO,'record_id'=>$lead['record_id'],'event_id'=>$acq['event_id'],'eventId'=>$acq['event_id'],'conversion'=>'urn:lla:llaPartnerConversion:'.$rule,'conversionHappenedAt'=>$at,'user'=>$user);
  // Optional value is a server-side snapshot, never inferred from arbitrary visitor text.
  $value=$s['valor']??null;$currency=$s['moeda']??'';if(is_numeric($value)&&(float)$value>=0&&is_string($currency)&&preg_match('/^[A-Z]{3}$/D',$currency)){$p['conversionValue']=array('currencyCode'=>$currency,'amount'=>number_format((float)$value,2,'.',''));}
  return array('ok'=>true,'payload'=>$p);
 }
 public static function previa(array $e): array {
  if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
  $lead=F3Base_Leads_Repositorio::obter($e['record_id']);if(!$lead||!in_array($lead['metodo']??'',array('formulario','whatsapp_formulario'),true)||($lead['captura']??'')!=='aceito'||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])){return array('ok'=>false,'codigo'=>'registro_inelegivel');}
  $p=self::montar($lead);$eligible=F3Base_Conversoes_Servidor::preparar($lead,'linkedin');$cap=F3Base_Conversoes_Transporte::capacidade('linkedin');
  return array('ok'=>!empty($p['ok']),'simulacao'=>true,'envio_realizado'=>false,'codigo'=>$p['codigo']??'previa_sem_envio','payload'=>$p['payload']??null,'destinos'=>array('navegador'=>array('conversion_id'=>(string)($lead['dados']['linkedin_conversao']['conversion_id']??''),'event_id'=>(string)($p['payload']['event_id']??$lead['dados']['linkedin_conversao']['event_id']??'')),'servidor'=>array('conversion_id'=>self::regra($lead),'event_id'=>(string)($p['payload']['event_id']??$lead['dados']['linkedin_conversao']['event_id']??''))),'elegivel_envio'=>!empty($eligible['ok'])&&$cap['ready'],'motivo_envio'=>$eligible['codigo']??$cap['reason']);
 }
}
