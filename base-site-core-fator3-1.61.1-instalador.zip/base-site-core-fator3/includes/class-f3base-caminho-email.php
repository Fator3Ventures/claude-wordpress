<?php
/** Mail proof restricted to the configured mailbox, with signed ownership and UID-scoped erasure. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Caminho_Email {
    public static function disponibilidade(): array {
        $c=F3Base_Email_Site::cfg();$ok=!empty($c['envio_ativo'])&&!empty($c['alocacao_confirmada'])&&is_email($c['endereco'])&&in_array(strtolower($c['endereco']),array_map('strtolower',$c['homologacao_emails']),true)&&F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET)!==''&&empty(get_option(F3Base_Email_Site_Config::STATE,array())['reconciliacao_necessaria']);
        return array('estado'=>$ok?'previa':'bloqueado','codigo'=>$ok?'caixa_propria_homologada_uidplus_a_conferir':'caixa_propria_fora_homologacao_ou_desligada','configuracao'=>'f3base_email_site.envio_ativo / homologacao_emails','destino'=>'Somente endereco da caixa configurada; sem Cco, Smart Bcc ou destinatário do contato.');
    }
    private static function assinatura(string $mid): string {return hash_hmac('sha256',$mid.'|'.home_url('/'),wp_salt('secure_auth'));}
    /** The collector skips only authentic messages created by this installation. No contact or second notification. */
    public static function propria(string $raw,?string $mid=null): bool {
        $headers=explode("\r\n\r\n",$raw,2)[0];$headers=preg_replace('/\r\n[ \t]+/',' ',$headers);
        if(!preg_match('/^Message-ID:\s*(<f3c-[a-f0-9]{32}@[a-z0-9.-]+>)\s*$/mi',$headers,$m)||($mid!==null&&$m[1]!==$mid)){return false;}
        return preg_match('/^X-F3Base-Caminho:\s*([a-f0-9]{64})\s*$/mi',$headers,$p)===1&&hash_equals(self::assinatura($m[1]),$p[1]);
    }
    public static function executar(array &$r,string $id,string $phase,?array $lead,callable $persist): array {
        $cleanup=$phase==='limpeza_email';if(!F3Base_Caminho_Lead::permitido($id,$cleanup?'email_limpeza':'email')){return array('estado'=>'bloqueado','codigo'=>'contexto_email_invalido');}
        if(!F3Base_Pipedrive_Fila::travar_linha('email-site-worker')){return array('estado'=>'aguardando','codigo'=>'email_caixa_ocupada','continuar'=>true,'tentar_em'=>time()+60);}
        $client=null;
        try{
            $cfg=F3Base_Email_Site::cfg();$context=F3Base_Email_Site_Config::identidade($cfg);
            if($cleanup){
                $items=$r['recibo']['emails'][$id]??array();if(!$items){return array('estado'=>'confirmado','codigo'=>'nenhuma_mensagem_criada');}
                $client=F3Base_Email_Site::conectar();$box=$client->select('INBOX',false);$client->exigir_uidplus();
                foreach($items as $kind=>$item){
                    if($item['contexto']!==$context||$item['uidvalidity']!==$box['uidvalidity']){return array('estado'=>'bloqueado','codigo'=>'email_identidade_da_caixa_alterada');}
                    $uids=$client->buscar_message_id($item['message_id']);if(count($uids)>5){return array('estado'=>'bloqueado','codigo'=>'email_copias_excedidas');}
                    if(!$uids&&empty($item['exclusao_reservada'])){return array('estado'=>'aguardando','codigo'=>empty($item['recebido'])?'email_entrega_ainda_nao_observada':'email_nao_localizado_para_exclusao','continuar'=>true,'tentar_em'=>time()+60);}
                    foreach($uids as $uid){$m=$client->fetch($uid);if(!self::propria($m['raw']??'',$item['message_id'])){return array('estado'=>'bloqueado','codigo'=>'email_autoria_divergente');}}
                    if($uids){$r['recibo']['emails'][$id][$kind]['exclusao_reservada']=true;if(!$persist($r)){return array('estado'=>'bloqueado','codigo'=>'email_reserva_exclusao_falhou');}foreach($uids as $uid){$client->apagar_uid($uid);}}
                    if($client->buscar_message_id($item['message_id'])){return array('estado'=>'aguardando','codigo'=>'email_exclusao_nao_confirmada','continuar'=>true,'tentar_em'=>time()+60);}
                    $r['recibo']['emails'][$id][$kind]['estado']='apagada';$r['recibo']['emails'][$id][$kind]['ausencia_confirmada_em']=time();if(!$persist($r)){return array('estado'=>'incerto','codigo'=>'email_limpeza_sem_checkpoint');}
                }
                return array('estado'=>'confirmado','codigo'=>'emails_ausentes_por_message_id','mensagens'=>count($items),'caixa'=>'INBOX','expunge_geral'=>false);
            }
            $ready=self::disponibilidade();if($ready['estado']!=='previa'){return $ready;}
            if(!$lead){return array('estado'=>'bloqueado','codigo'=>'contato_indisponivel');}
            $client=F3Base_Email_Site::conectar();$box=$client->select('INBOX',false);$client->exigir_uidplus();
            $item=$r['recibo']['emails'][$id][$phase]??null;
            if(!$item){
                $auto=$phase==='email_automatico';$subject='[TESTE F3BASE] Aviso de contato';$text=F3Base_Contato_Apresentacao::texto(F3Base_Contato_Apresentacao::montar($lead,false));
                if($auto){$c=F3Base_Email_Envio::configuracao_automatica(F3Base_Options::ler('f3base_email_novo_lead'));if(empty($c['ativo'])){return array('estado'=>'bloqueado','codigo'=>'email_automatico_desligado');}$render=F3Base_Email_Novo_Lead::mensagem(F3Base_Pipedrive_Fila::contexto($lead),$c,array(),time());if(empty($render['ok'])){return array('estado'=>'bloqueado','codigo'=>$render['codigo']);}$subject='[TESTE F3BASE] '.$render['subject'];$text=$render['text'];}
                if(!F3Base_Email_Novo_Lead::reservar_cota(1,(int)$cfg['cota_destinatarios_hora'])){return array('estado'=>'bloqueado','codigo'=>'email_cota_hora_excedida');}
                $mid='<f3c-'.bin2hex(random_bytes(16)).'@'.strtolower(substr(strrchr($cfg['endereco'],'@'),1)).'>';
                $item=array('message_id'=>$mid,'contexto'=>$context,'uidvalidity'=>$box['uidvalidity'],'estado'=>'enviando','recebido'=>false,'em'=>time());$r['recibo']['emails'][$id][$phase]=$item;if(!$persist($r)){return array('estado'=>'bloqueado','codigo'=>'email_intencao_nao_persistida');}
                $message=array('message_id'=>$mid,'recebida_em'=>time(),'para'=>$cfg['endereco'],'cco'=>array(),'assunto'=>$subject,'texto'=>$text,'in_reply_to'=>'','references'=>array(),'caminho_prova'=>self::assinatura($mid));
                $sent=F3Base_Email_Envio::smtp($message,$cfg);$r['recibo']['emails'][$id][$phase]['estado']=$sent['estado'];$r['recibo']['emails'][$id][$phase]['smtp']=$sent['codigo'];if(!$persist($r)){return array('estado'=>'incerto','codigo'=>'email_aceite_sem_checkpoint');}
                return array('estado'=>$sent['estado']==='falhou'?'bloqueado':'aguardando','codigo'=>$sent['codigo'],'continuar'=>$sent['estado']!=='falhou','tentar_em'=>time()+60,'envio_real'=>true,'cco'=>false,'smart_bcc'=>false);
            }
            if($item['contexto']!==$context||$item['uidvalidity']!==$box['uidvalidity']){return array('estado'=>'bloqueado','codigo'=>'email_identidade_da_caixa_alterada');}
            $uids=$client->buscar_message_id($item['message_id']);if(!$uids){return array('estado'=>'aguardando','codigo'=>'email_entrega_ainda_nao_observada','continuar'=>true,'tentar_em'=>time()+60);}
            if(count($uids)>5){return array('estado'=>'bloqueado','codigo'=>'email_copias_excedidas');}
            foreach($uids as $uid){$m=$client->fetch($uid);if(!self::propria($m['raw']??'',$item['message_id'])){return array('estado'=>'bloqueado','codigo'=>'email_autoria_divergente');}}
            $r['recibo']['emails'][$id][$phase]['recebido']=true;$r['recibo']['emails'][$id][$phase]['uids']=$uids;
            return array('estado'=>'confirmado','codigo'=>'email_recebido_imap','envio_real'=>true,'mensagens'=>count($uids),'cco'=>false,'smart_bcc'=>false,'atividade_automatica_criada'=>false);
        }catch(Throwable $e){return array('estado'=>'bloqueado','codigo'=>F3Base_Email_Site::erro($e));}
        finally{if($client){$client->close();}F3Base_Pipedrive_Fila::liberar_linha('email-site-worker');}
    }
}
