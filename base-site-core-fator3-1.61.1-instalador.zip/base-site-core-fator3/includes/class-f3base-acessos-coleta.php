<?php
/** Importação reservada, com contribuições idempotentes por arquivo e calendário explícito. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Acessos_Coleta {
	public const TABELA = 'f3base_acessos_contribuicoes';
	public const VERSAO = 6;
	public static function instalar(): void {$e=F3Base_Options::ler('f3base_acessos_estado');self::estrutura($e);F3Base_Options::atualizar_estado('f3base_acessos_estado',static fn()=>$e);}
	private static function estrutura( array &$e ): void {
		global $wpdb;
		if ( (int) ( $e['estrutura'] ?? 0 ) === self::VERSAO ) {
			return; }
		if ( ! ( new F3Base_Modulo_Acessos_Servidor() )->garantir_estrutura() ) {
			throw new RuntimeException('acessos_estrutura_dos_acessos_indisponivel_dfbe2a'); }
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t       = $wpdb->prefix . self::TABELA;
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$t} (
 fonte char(64) NOT NULL,
 chave char(64) NOT NULL,
 regra char(64) NOT NULL,
 dia date NOT NULL,
 agente varchar(64) NOT NULL,
 classe_caminho varchar(16) NOT NULL,
 dimensao char(64) NOT NULL DEFAULT '',
post_id bigint unsigned NOT NULL DEFAULT 0,
tipo_conteudo varchar(32) NOT NULL DEFAULT '',
representacao varchar(20) NOT NULL DEFAULT 'nao_resolvida',
resolucao varchar(32) NOT NULL DEFAULT 'historico_sem_identidade',
rede_estado varchar(24) NOT NULL DEFAULT 'nao_verificada',
rede_lista char(64) NOT NULL DEFAULT '',
rede_data bigint unsigned NOT NULL DEFAULT 0,
rede_versao varchar(64) NOT NULL DEFAULT '',
assinatura_ua varchar(80) NOT NULL DEFAULT 'historico_desconhecido',
assinatura_regra varchar(24) NOT NULL DEFAULT '',
parametros_pagos smallint NOT NULL DEFAULT -1,
 caminho varchar(191) COLLATE utf8mb4_bin NOT NULL,
 status smallint unsigned NOT NULL,
 metodo varchar(5) NOT NULL,
 contagem bigint unsigned NOT NULL,
 primeiro_em datetime DEFAULT NULL,
 ultimo_em datetime DEFAULT NULL,
 instantes_validos bigint unsigned NOT NULL DEFAULT 0,
 PRIMARY KEY  (fonte,chave),
 KEY dia_regra (dia,regra)
 ) ENGINE=InnoDB {$charset};"
		);
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) !== $t ) {
			throw new RuntimeException('acessos_estrutura_de_contribuicoes_indisponivel_ddf1db'); }
		F3Base_Agentes::instalar();
        if((int)($e['estrutura']??0)<3){$e['legado']=$e['dias']??array();}
        $e['estrutura'] = self::VERSAO;
	}
    /** Gzip: CRC/ISIZE e fim do fluxo verificados pelo zlib; teto também no conteúdo expandido. */
    private static function abrir_fonte(array $arquivo,int $max): array {
        $in=@fopen($arquivo['nome'],'rb');$out=fopen('php://temp/maxmemory:2097152','w+b');
        if(!$in||!$out){if(is_resource($in)){fclose($in);}if(is_resource($out)){fclose($out);}throw new RuntimeException('acessos_fonte_sem_leitura');}
        $gzip=str_ends_with($arquivo['nome'],'.gz');$z=$gzip?inflate_init(ZLIB_ENCODING_GZIP):null;$sha=hash_init('sha256');$bytes=0;$entrada=0;$prazo=microtime(true)+F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA;
        try {
            while(!feof($in)){
                if(microtime(true)>$prazo){throw new RuntimeException('acessos_descompressao_excedeu_orcamento');}
                $raw=fread($in,16384);if($raw===false){throw new RuntimeException('acessos_leitura_falhou');}if($raw===''){break;}$entrada+=strlen($raw);
                $chunk=$gzip?@inflate_add($z,$raw,ZLIB_SYNC_FLUSH):$raw;
                if($chunk===false){throw new RuntimeException('acessos_gzip_integridade_invalida');}
                $bytes+=strlen($chunk);if($bytes>$max||$entrada>$max){throw new RuntimeException('acessos_conteudo_excede_96_mib');}
                hash_update($sha,$chunk);if(fwrite($out,$chunk)!==strlen($chunk)){throw new RuntimeException('acessos_buffer_falhou');}
            }
            if(!feof($in)||($gzip&&(inflate_get_status($z)!==ZLIB_STREAM_END||inflate_get_read_len($z)!==$entrada))){throw new RuntimeException('acessos_gzip_truncado_ou_membros_adicionais');}
            rewind($out);return array($out,array('sha256'=>hash_final($sha),'tamanho'=>$bytes,'tamanho_arquivo'=>$entrada,'comprimida'=>$gzip,'integridade'=>$gzip?'gzip_crc_isize':'leitura_completa'));
        }catch(Throwable $x){fclose($out);throw $x;}finally{fclose($in);}
    }
    /** Prova criada somente com fontes efetivamente lidas e disponíveis nesta inspeção. */
    private static function prova_dia(string $dia,array $e,string $regra): array {
        if(!self::fontes_do_dia_completas($dia,$e,$regra)){return array();}
        $fontes=array();$a=new DateTimeImmutable($dia,wp_timezone());$b=$a->modify('+1 day')->modify('-1 second');$rotacoes=array();
        foreach($e['fontes']??array() as $f){if(($f['regra']??'')!==$regra||empty($f['disponivel'])||!empty($f['erro'])){continue;}foreach($f['offsets']??array() as $offset){$zone=new DateTimeZone($offset);$rotacoes[$a->setTimezone($zone)->format('Y-m-d')]=true;$rotacoes[$b->setTimezone($zone)->format('Y-m-d')]=true;}}
        foreach($e['fontes']??array() as $id=>$f){if(!isset($rotacoes[$f['rotacao']??''])||($f['regra']??'')!==$regra||empty($f['disponivel'])||!empty($f['erro'])){continue;}if(empty($f['prova']['sha256'])||in_array($dia,$f['adiados']??array(),true)){return array();}$fontes[$id]=array('rotacao'=>$f['rotacao'],'linhas'=>(int)($f['linhas_lidas']??0),'offsets'=>$f['offsets']??array())+$f['prova'];}
        return $fontes?array('versao'=>1,'regra'=>$regra,'fuso'=>wp_timezone_string(),'processado_em'=>time(),'fontes'=>$fontes):array();
    }
    private static function prova_valida(array $s,array $e,string $regra): bool {
        $p=$s['prova_completude']??array();if(($e['regra_aliases'][$p['regra']??'']??($p['regra']??''))!==$regra||empty($p['fontes'])){return false;}
        foreach($p['fontes'] as $id=>$f){$atual=$e['fontes'][$id]??array();if(!empty($atual['prova']['sha256'])&&$atual['prova']['sha256']!==$f['sha256']){return false;}}
        return true;
    }
	/** Processar um arquivo é atômico; uma interrupção não apaga sua contribuição anterior. */
	public static function ler_arquivo( array $arquivo, array $excluidos, string $hoje ): array {
		$max = F3Base_Modulo_Acessos_Servidor::MAX_BYTES_ARQUIVO;
		if ( $arquivo['tamanho'] > $max ) {
			throw new RuntimeException('acessos_arquivo_excede_96_mib_coleta_externa_necess_b34b74'); }
		[$f,$prova]=self::abrir_fonte($arquivo,$max);
		$ag           = array();$horas=array();
		$caminhos     = array();
		$n            = 0;
		$ignoradas    = 0;
		$adiados      = array();
		$dias         = array();
		$offsets      = array();
		$datas_origem = array();
		$prazo        = microtime( true ) + F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA;
		try {
            F3Base_Modulo_Acessos_Servidor::preparar_caminhos();F3Base_Acessos_Repeticao::iniciar();
			while ( false !== ( $bruta = fgets( $f, 32769 ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- Laço de streaming encerra em EOF e verifica orçamento e leitura completa.
				if ( microtime( true ) > $prazo ) {
					throw new RuntimeException('acessos_orcamento_de_leitura_excedido_contribuicao_46585c'); }
				++$n;
				if ( ! str_ends_with( $bruta, "\n" ) ) {
					while ( ! feof( $f ) && false !== ( $resto = fgets( $f, 32769 ) ) && ! str_ends_with( $resto, "\n" ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- Laço de streaming encerra em EOF e verifica orçamento e leitura completa.
						if ( microtime( true ) > $prazo ) {
							throw new RuntimeException('acessos_linha_excede_orcamento_36b1e3'); }
					}
					++$ignoradas;
					continue;
				}
				$data = F3Base_Modulo_Acessos_Servidor::data_da_linha( $bruta );
				$r    = F3Base_Modulo_Acessos_Servidor::linha( $bruta, $excluidos );
				if ( ! $data || ! $r ) {
					++$ignoradas;
					continue; }
				$dia = $data->format( 'Y-m-d' );
				if ( preg_match( '~\[([^\]]+)\]~', $bruta, $tm ) ) {
					$original = DateTimeImmutable::createFromFormat( '!d/M/Y:H:i:s O', $tm[1] );
					if ( $original ) {
						$offsets[ $original->format( 'P' ) ]          = true;
						$datas_origem[ $original->format( 'Y-m-d' ) ] = true; }
				}
				if ( $dia >= $hoje ) {
					$adiados[ $dia ] = true;
					continue; }
				$r=F3Base_Acessos_Repeticao::observar($bruta,$r,$data->getTimestamp());
				$dias[ $dia ] = true;
				$r['dia']     = $dia;
                $stamp=$data->getTimestamp();$r['primeiro_em']=gmdate('Y-m-d H:i:s',$stamp);$r['ultimo_em']=$r['primeiro_em'];$r['instantes_validos']=1;
                
				$p            = $r['caminho'];
				$a            = $r['agente'];
				if ( '' !== $p ) {
					if ( ! isset( $caminhos[ $dia ][ $a ][ $p ] ) && count( $caminhos[ $dia ][ $a ] ?? array() ) >= F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA ) {
						$r['caminho']        = '';
						$r['classe_caminho'] = 'limite_caminhos';$r['post_id']=0;$r['tipo_conteudo']='outro';$r['representacao']='nao_resolvida';$r['resolucao']='limite_750_caminhos';$r['dimensao']=hash('sha256',wp_json_encode(array_intersect_key($r,array_flip(array_merge(F3Base_Agentes::DIMENSOES,array('parametros_pagos')))))); } else {
						$caminhos[ $dia ][ $a ][ $p ] = true; }
				}
				F3Base_Agentes::observar($horas,$r,$stamp);
                $k = hash( 'sha256', wp_json_encode( array( $r['dimensao'], $dia, $r['agente'], $r['classe_caminho'], $r['caminho'], $r['status'], $r['metodo'] ) ) );
				if ( isset( $ag[ $k ] ) ) {
					++$ag[ $k ]['contagem'];++$ag[$k]['instantes_validos'];$ag[$k]['primeiro_em']=min($ag[$k]['primeiro_em'],$r['primeiro_em']);$ag[$k]['ultimo_em']=max($ag[$k]['ultimo_em'],$r['ultimo_em']);
				} else {
					$ag[ $k ] = $r; }
				if ( count( $ag ) > F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS ) {
					throw new RuntimeException('acessos_teto_de_agregados_excedido_contribuicao_ant_15e0e2'); }
			}
			if ( ! feof( $f ) || $ignoradas > $n / 2 ) {
				throw new RuntimeException('acessos_leitura_interrompida_ou_formato_nao_reconhe_95be49'); }
		} finally {
			F3Base_Acessos_Repeticao::concluir();
			fclose( $f ); } // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		clearstatcache( true, $arquivo['nome'] );
		if ( @filesize( $arquivo['nome'] ) !== $arquivo['tamanho'] || @filemtime( $arquivo['nome'] ) !== $arquivo['mtime'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte.
			throw new RuntimeException('acessos_fonte_mudou_durante_a_coleta_contribuicao_a_18932b'); }
		return array(
			'prova'=>$prova,
            'linhas'       => $ag,'horas'=>$horas,
			'dias'         => array_keys( $dias ),
			'adiados'      => array_keys( $adiados ),
			'lidas'        => $n,
			'ignoradas'    => $ignoradas,
			'offsets'      => array_keys( $offsets ),
			'datas_origem' => array_keys( $datas_origem ),
		);
	}
	private static function guardar( string $fonte, string $regra, array $linhas, array $horas ): void {
		global $wpdb;
		$t = $wpdb->prefix . self::TABELA;
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			throw new RuntimeException('acessos_banco_recusou_transacao_d4a5ac'); }
		try {
			if ( false === $wpdb->delete( $t, array( 'fonte' => $fonte ) ) ) {
				throw new RuntimeException('acessos_banco_recusou_contribuicao_a06f3f'); }
            $campos=array('fonte','chave','regra','dia','agente','classe_caminho','caminho','status','metodo','contagem','primeiro_em','ultimo_em','instantes_validos','dimensao','post_id','tipo_conteudo','representacao','resolucao','rede_estado','rede_lista','rede_data','rede_versao','assinatura_ua','assinatura_regra','parametros_pagos');
            foreach(array_chunk($linhas,100,true) as $lote){$formas=array();$v=array();foreach($lote as $chave=>$r){$row=array('fonte'=>$fonte,'chave'=>$chave,'regra'=>$regra)+$r;foreach($campos as $col){$v[]=$row[$col];}$formas[]='('.implode(',',array_fill(0,count($campos),'%s')).')';}
                if(false===$wpdb->query($wpdb->prepare('INSERT INTO '.$t.' ('.implode(',',$campos).') VALUES '.implode(',',$formas),$v))){throw new RuntimeException('acessos_banco_recusou_lote_de_contribuicoes_3359d4');}}
            F3Base_Agentes::guardar($fonte,$regra,$horas);
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new RuntimeException('acessos_banco_nao_confirmou_contribuicao_8e3e5b'); }
		} catch ( Throwable $x ) {
			$wpdb->query( 'ROLLBACK' );
			throw $x; }
	}
	private static function publicar( array &$e, string $regra, string $corte, string $hoje ): void {
		global $wpdb;
		$t    = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$f    = $wpdb->prefix . self::TABELA;
		$dias = (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT dia FROM {$f} WHERE dia >= %s AND dia < %s AND regra = %s", $corte, $hoje, $regra ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
		foreach ( $e['fontes'] ?? array() as $s ) {
			if ( ( $s['regra'] ?? '' ) === $regra && empty( $s['erro'] ) && $s['rotacao'] >= $corte && $s['rotacao'] < $hoje ) {
				$dias[] = $s['rotacao']; }
		}
        F3Base_Acessos_Legado::reconciliar($e,$regra);
		foreach ( array_unique( $dias ) as $dia ) {
			$legado     = $e['legado'][ $dia ] ?? null;
			$incompleto = false;
			$fontes     = array();
			foreach ( (array) ( $legado['fontes'] ?? array() ) as $id ) {
				$anterior = $e['fontes'][ $id ] ?? array();
				if ( ( $anterior['regra'] ?? '' ) !== $regra || empty( $anterior['disponivel'] ) ) {
					$incompleto = true; }
			}
			foreach ( (array) ( $legado['arquivos'] ?? array() ) as $a ) {
				$estado = $e['fontes'][ hash( 'sha256', $a['nome'] ) ] ?? array();
				if ( ( $estado['regra'] ?? '' ) !== $regra || empty( $estado['disponivel'] ) || ! empty( $estado['erro'] ) ) {
					$incompleto = true; }
			}
			foreach ( $e['fontes'] ?? array() as $id => $s ) {
				if ( ! in_array( $dia, $s['dias'] ?? array(), true ) && $dia !== $s['rotacao'] ) {
					continue; }
				$fontes[] = $id;

				if ( ( $s['regra'] ?? '' ) !== $regra || ! empty( $s['erro'] ) || ( ! empty( $s['adiados'] ) && min( $s['adiados'] ) <= $dia ) ) {
					$incompleto = true; }
			}
			if ( $incompleto ) {
				continue; }
			$versoes = array();
			foreach ( $fontes as $id ) {
				$fonte          = $e['fontes'][ $id ];
				$versoes[ $id ] = array( $fonte['prova']['sha256'] ?? $fonte['assinatura'] ?? '', $fonte['regra'] ?? '', $fonte['dias'] ?? array(), $fonte['adiados'] ?? array() );
			} ksort( $versoes );
			$assinatura = hash( 'sha256', wp_json_encode( array( $regra, $dia, $versoes ) ) );
			if ( ( $e['dias'][ $dia ]['assinatura_contribuicoes'] ?? '' ) === $assinatura ) {
                if(empty($e['dias'][$dia]['prova_completude'])){$e['dias'][$dia]['prova_completude']=self::prova_dia($dia,$e,$regra);}
                continue; }
			if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
				throw new RuntimeException('acessos_banco_recusou_publicacao_95848a'); }
			try {
				if ( false === $wpdb->delete( $t, array( 'dia' => $dia ) ) ) {
					throw new RuntimeException('acessos_banco_recusou_atualizacao_do_dia_1fee31'); }
                F3Base_Agentes::publicar($dia,$regra);
				$sql = "INSERT INTO {$t} (dia,agente,classe_caminho,caminho,status,metodo,dimensao,post_id,tipo_conteudo,representacao,resolucao,rede_estado,rede_lista,rede_data,rede_versao,assinatura_ua,assinatura_regra,parametros_pagos,contagem,primeiro_em,ultimo_em,instantes_validos) SELECT dia,agente,classe_caminho,caminho,status,metodo,dimensao,post_id,tipo_conteudo,representacao,resolucao,rede_estado,rede_lista,rede_data,rede_versao,assinatura_ua,assinatura_regra,parametros_pagos,SUM(contagem),MIN(primeiro_em),MAX(ultimo_em),SUM(instantes_validos) FROM {$f} WHERE dia=%s AND regra=%s GROUP BY dia,agente,classe_caminho,caminho,status,metodo,dimensao,post_id,tipo_conteudo,representacao,resolucao,rede_estado,rede_lista,rede_data,rede_versao,assinatura_ua,assinatura_regra,parametros_pagos";
				if ( false === $wpdb->query( $wpdb->prepare( $sql, $dia, $regra ) ) || false === $wpdb->query( 'COMMIT' ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					throw new RuntimeException('acessos_banco_nao_confirmou_publicacao_do_dia_c16852'); }
			} catch ( Throwable $x ) {
				$wpdb->query( 'ROLLBACK' );
				throw $x; }
			$e['dias'][ $dia ] = array(
				'prova_completude'=>self::prova_valida($e['dias'][$dia]??array(),$e,$regra)?$e['dias'][$dia]['prova_completude']:self::prova_dia($dia,$e,$regra),
                'cobertura_publicacao'=>self::fontes_do_dia_completas($dia,$e,$regra)?'completa':'parcial',
                'config_hash'              => $regra,
				'regra'                    => $regra,
				'fuso'                     => wp_timezone_string(),
				'fontes'                   => $fontes,
				'assinatura_contribuicoes' => $assinatura,
				'inspecionado_em'          => time(),
			);
			unset( $e['legado'][ $dia ] );
		}
	}
	public static function executar(): array {
		global $wpdb;
		if ( empty( F3Base_Modulo_Acessos_Servidor::config()['ligado'] ) ) {
			return array( 'erro' => 'Coleta desligada.' ); }
		$lock = @fopen( get_temp_dir() . 'f3base-acessos-' . hash( 'sha256', ABSPATH . $wpdb->prefix ) . '.lock', 'c' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte. Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			} return array( 'em_curso' => true ); }
		$e              = F3Base_Options::ler( 'f3base_acessos_estado' );
		$e['tentativa'] = time();
		$e['erro']      = '';unset($e['erro_detalhes'],$e['proxima_tentativa']);
		$e['pendentes'] = 0;
		try {
			self::estrutura( $e );
			$c     = F3Base_Modulo_Acessos_Servidor::config();
			$regra = F3Base_Modulo_Acessos_Servidor::config_hash();
			$hoje  = wp_date( 'Y-m-d' );
            $old=F3Base_Modulo_Acessos_Servidor::config_hash(true);
            if(($e['config_hash']??'')===$old&&$old!==$regra){
                foreach(array($wpdb->prefix.self::TABELA,F3Base_Agentes::tabela(true)) as $table){if(false===$wpdb->query($wpdb->prepare('UPDATE %i SET regra=%s WHERE regra=%s',$table,$regra,$old))){throw new RuntimeException('acessos_migracao_regra_retencao_falhou');}}
                foreach(array('dias','fontes') as $grupo){foreach($e[$grupo]??array() as $key=>$v){if(($v['regra']??'')===$old){$e[$grupo][$key]['regra']=$regra;if(isset($v['config_hash'])){$e[$grupo][$key]['config_hash']=$regra;}}}}
                $e['regra_aliases'][$old]=$regra;$e['config_hash']=$regra;$e['migracao_regra_retencao_em']=time();
            }
			if ( isset( $e['config_hash'] ) && $e['config_hash'] !== $regra ) {
				foreach ( $e['dias'] ?? array() as $dia => $anterior ) {
					$e['legado'][ $dia ] = $anterior; }
			}
			$corte = F3Base_Modulo_Acessos_Servidor::corte( (int) $c['retencao_meses'] );
			foreach ( $e['fontes'] ?? array() as $id => $s ) {
				$e['fontes'][ $id ]['disponivel'] = false; }
			$arquivos                 = F3Base_Modulo_Acessos_Servidor::arquivos( $c['padrao_do_log'] );
			$e['inspecionado_em']     = time();
			$e['rotacoes_observadas'] = array_keys( $arquivos );
			$prazo                    = microtime( true ) + F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_LOTE;
			$falhas                   = array();
			foreach ( $arquivos as $rotacao => $grupo ) {
				if ( $rotacao < $corte ) {
					continue; }
				foreach ( $grupo as $arquivo ) {
					$id                 = hash( 'sha256', $arquivo['fonte_logica'] ?? preg_replace('/\.gz$/D','',$arquivo['nome']) );
					$ass                = hash( 'sha256', wp_json_encode( $arquivo ) );
					$s                  = $e['fontes'][ $id ] ?? array();
					$s['disponivel']    = true;
					$s['rotacao']       = $rotacao;
					$e['fontes'][ $id ] = $s;
					$adiado             = ! empty( $s['adiados'] ) && min( $s['adiados'] ) < $hoje;
					if ( ( $s['assinatura'] ?? '' ) === $ass && ( $s['regra'] ?? '' ) === $regra && ! $adiado && empty( $s['erro'] ) ) {
						continue; }
					if ( microtime( true ) >= $prazo ) {
						++$e['pendentes'];
						continue; }
					try {
						$lido = self::ler_arquivo( $arquivo, $c['caminhos_excluidos'], $hoje );
						self::guardar( $id, $regra, $lido['linhas'], $lido['horas'] );
						$e['fontes'][ $id ] = array(
							'rotacao'         => $rotacao,
                            'prova'=>$lido['prova'],'linhas_lidas'=>$lido['lidas'],
							'assinatura'      => $ass,
							'regra'           => $regra,
							'fuso'            => wp_timezone_string(),
							'dias'            => $lido['dias'],
							'offsets'         => $lido['offsets'],
							'datas_origem'    => $lido['datas_origem'],
							'adiados'         => $lido['adiados'],
							'disponivel'      => true,
							'inspecionado_em' => time(),
							'erro'            => '',
						);
						$e['ultima']        = array(
							'arquivo'   => basename( $arquivo['nome'] ),
							'linhas'    => $lido['lidas'],
							'ignoradas' => $lido['ignoradas'],
							'gravadas'  => count( $lido['linhas'] ),
						);
						$r                  = F3Base_Options::gravar( 'f3base_acessos_estado', $e );
						if ( array_key_exists( 'persisted', $r ) ? ! $r['persisted'] : empty( $r['ok'] ) ) {
							throw new RuntimeException('acessos_checkpoint_nao_persistido_arquivo_sera_reto_2e1783'); }
					} catch ( Throwable $x ) {
						$details=F3Base_Operacao::excecao($x,'acessos');$e['fontes'][$id]['erro_detalhes']=$details;$e['erro_detalhes']=$details;$e['fontes'][$id]['erro']=$details['codigo_interno']??'falha_acessos';
						$falhas[]                   = $details['codigo_interno']??'falha_acessos';++$e['pendentes']; }
				}
			}
			foreach ( $e['fontes'] ?? array() as $s ) {
				if ( empty( $s['disponivel'] ) && ! empty( $s['adiados'] ) ) {
					$falhas[] = 'Fonte indisponível antes da revisita; cobertura adiada não recuperável.'; }
			}
			// Publicação independente por dia. Uma fonte antiga perdida não bloqueia
            // contribuições novas sem sobreposição com o histórico preservado.
            self::publicar($e,$regra,$corte,$hoje);
			foreach ( array( F3Base_Modulo_Acessos_Servidor::TABELA, self::TABELA, 'f3base_acessos_legado' ) as $sufixo ) {
				$t = $wpdb->prefix . $sufixo;
				if ( false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE dia < %s", $corte ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					throw new RuntimeException('acessos_retencao_recusada_d4dc60'); }
			}
			foreach ( array( 'dias', 'legado', 'reconciliacao' ) as $campo ) {
				foreach ( $e[ $campo ] ?? array() as $d => $s ) {
					if ( $d < $corte ) {
						unset( $e[ $campo ][ $d ] ); }
				}
			}
			foreach ( $e['fontes'] ?? array() as $id => $s ) {
				if ( $s['rotacao'] < $corte ) {
					unset( $e['fontes'][ $id ] ); }
			}
			F3Base_Agentes::limpar();
            $e['config_hash']            = $regra;
			$e['dias_regras_anteriores'] = count( array_filter( $e['dias'] ?? array(), static fn( $d ) => ( $d['regra'] ?? '' ) !== $regra ) );
			$e['erro']                   = implode( ' | ', array_unique( array_slice( $falhas, 0, 5 ) ) );
			if ( ! $e['pendentes'] && ! $e['erro'] ) {
				$e['ultima_soma'] = time();
				F3Base_Atividade::registrar( 'ultima_soma_acessos', $e['ultima'] ?? array() ); }
			if ( $e['pendentes'] ) {
				F3Base_Modulo_Acessos_Servidor::solicitar(); }
		} catch ( Throwable $x ) {
			$e['erro_detalhes']=F3Base_Operacao::excecao($x,'acessos');$e['erro']=$e['erro_detalhes']['codigo_interno']??'falha_acessos'; } finally {
			if($e['erro']){$e['pendentes']=max(1,(int)$e['pendentes']);$at=wp_next_scheduled(F3Base_Modulo_Acessos_Servidor::CONTINUAR);if(!$at){wp_schedule_single_event(time()+300,F3Base_Modulo_Acessos_Servidor::CONTINUAR);}$e['proxima_tentativa']=wp_next_scheduled(F3Base_Modulo_Acessos_Servidor::CONTINUAR)?:null;}
            if(F3Base_Editorial::medida_catalogo()){$e['catalogo']=F3Base_Editorial::medida_catalogo();}
            $e['config_hash'] = F3Base_Modulo_Acessos_Servidor::config_hash();
			F3Base_Options::gravar( 'f3base_acessos_estado', $e );
			flock( $lock, LOCK_UN );
			fclose( $lock ); } // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			return $e;
	}
	private static function fontes_do_dia_completas( string $dia, array $e, string $regra ): bool {
        if(F3Base_Acessos_Legado::lacuna($dia,$e,$regra)){return false;}
		$offsets  = array();
		$rotacoes = array();
		foreach ( $e['fontes'] ?? array() as $f ) {
			if ( ( $f['regra'] ?? '' ) !== $regra || ! empty( $f['erro'] ) ) {
				continue; }
			if(empty($f['disponivel'])){continue;}
			foreach ( $f['offsets'] ?? array() as $offset ) {
				$offsets[ $offset ] = true; }
			$rotacoes[ $f['rotacao'] ] = true;
		}
		if ( ! $offsets ) {
			return false; }
		$a = new DateTimeImmutable( $dia, wp_timezone() );
		$b = $a->modify( '+1 day' )->modify( '-1 second' );
		foreach ( array_keys( $offsets ) as $offset ) {
			$zone = new DateTimeZone( $offset );
			$da   = $a->setTimezone( $zone )->format( 'Y-m-d' );
			$db   = $b->setTimezone( $zone )->format( 'Y-m-d' );
			for ( $d = new DateTimeImmutable( $da, $zone ); $d->format( 'Y-m-d' ) <= $db; $d = $d->modify( '+1 day' ) ) { // phpcs:ignore Generic.CodeAnalysis.ForLoopWithTestFunctionCall.NotAllowed -- Iteração de calendário/ascendentes limitada por janela ou profundidade explícita.
				if ( ! isset( $rotacoes[ $d->format( 'Y-m-d' ) ] ) ) {
					return false; }
			}
		}
		return true;
	}

	/** A ausência de fonte só é afirmada após descoberta bem-sucedida da janela. */
	public static function cobertura( string $inicio, string $fim ): array {
		$e     = F3Base_Options::ler( 'f3base_acessos_estado' );
		$r     = array();
		$regra = F3Base_Modulo_Acessos_Servidor::config_hash();
		$hoje  = wp_date( 'Y-m-d' );
		for ( $d = new DateTimeImmutable( $inicio, wp_timezone() ); $d->format( 'Y-m-d' ) <= $fim && count( $r ) < 790; $d = $d->modify( '+1 day' ) ) { // phpcs:ignore Generic.CodeAnalysis.ForLoopWithTestFunctionCall.NotAllowed,Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- Iteração de calendário/ascendentes limitada por janela ou profundidade explícita. Convergência/teto depende do tamanho atualizado nesta iteração; coleção limitada pelo orçamento.
			$dia    = $d->format( 'Y-m-d' );
			$s      = $e['dias'][ $dia ] ?? array();
			$estado = 'desconhecido';
			$motivo = 'Sem inspeção de fonte para esta data.';
			if ( $dia === $hoje ) {
				$estado = 'parcial';
				$motivo = 'Dia aberto; fotografia temporária do arquivo ativo.'; } elseif ( $s && ( $s['regra'] ?? '' ) !== $regra ) {
				$estado = 'legado';
				$motivo = 'Calendário ou classificação anterior; reconstrução completa não confirmada.'; } elseif ( $s ) {
					$completo = self::prova_valida($s,$e,$regra)||self::fontes_do_dia_completas( $dia, $e, $regra );
					$estado   = $completo ? 'completo' : 'parcial';
					$motivo   = $completo ? 'Fontes datadas necessárias ao calendário observado processadas; tráfego fora dos logs não é medido.' : 'Contribuições disponíveis processadas; falta fonte adjacente ou evidência do calendário de rotação.'; } elseif ( ! empty( $e['inspecionado_em'] ) ) {
					$estado = in_array( $dia, $e['rotacoes_observadas'] ?? array(), true ) ? 'pendente' : 'sem_fonte_observada';
					$motivo = 'pendente' === $estado ? 'Fonte observada ainda não publicada.' : 'Inspeção não encontrou log datado elegível com esta data de rotação; não comprova ausência de acessos.'; }
					foreach ( $e['fontes'] ?? array() as $f ) {
						if ( $f['rotacao'] !== $dia && ! in_array( $dia, $f['dias'] ?? array(), true ) && ! in_array( $dia, $f['adiados'] ?? array(), true ) ) {
							continue; }
						if ( ! empty( $f['erro'] ) || ( empty( $f['disponivel'] ) && in_array( $dia, $f['adiados'] ?? array(), true ) ) ) {
							$estado = 'falha';
							$motivo = $f['erro'] ?? 'Fonte perdida antes da revisita.';if(empty($f['disponivel'])){$estado='lacuna_irrecuperavel';$motivo='Arquivo necessário não está mais disponível; o histórico preservado não permite reconstruir as horas.';}
							break; }
						if ( in_array( $dia, $f['adiados'] ?? array(), true ) && $dia !== $hoje ) {
							$estado = 'pendente';
							$motivo = 'Contribuição adiada aguarda revisita.'; }
					}
                    if(isset($e['reconciliacao'][$dia])&&F3Base_Acessos_Legado::lacuna($dia,$e,$regra)){$estado='lacuna_irrecuperavel';$motivo='Parte das fontes anteriores não está disponível. Agregados antigos foram arquivados separadamente; contribuições atuais não representam o total do dia.';}
                    $prova=self::prova_valida($s,$e,$regra)?$s['prova_completude']:array();$codigo='fonte_ausente_desde_inicio';
                    if($prova){$estado='completo';$codigo='processado_completo';foreach($prova['fontes'] as $id=>$fonte){$atual=$e['fontes'][$id]??array();if(empty($atual['disponivel'])||(!empty($atual['prova']['comprimida'])&&empty($fonte['comprimida']))){$codigo='fonte_comprimida_ou_rotacionada_apos_processamento';break;}}$motivo='Completude comprovada no processamento; a disponibilidade atual dos arquivos não altera a prova.';}
                    elseif($estado==='completo'){$codigo='processado_completo_sem_prova_persistida';}elseif(in_array($estado,array('pendente','falha','legado'),true)){$codigo=$estado;}
					$r[] = array(
						'dia'             => $dia,
                        'codigo'=>$codigo,'prova_completude'=>$prova,
						'estado'          => $estado,
						'motivo'          => $motivo,
						'origem'          => $dia === $hoje ? 'arquivo_ativo' : 'logs_datados',
						'regra'           => (string) ( $s['regra'] ?? 'legado' ),
						'fuso'            => (string) ( $s['fuso'] ?? '' ),
						'inspecionado_em' => (int) ( $e['inspecionado_em'] ?? 0 ),
					);
		}
		return $r;
	}
}
