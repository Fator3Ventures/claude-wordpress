<?php
/** Alerta durável para cabeçalho que excede o teto técnico. Sem criação automática de contato. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Excedida {
    public static function metadados(array $msg,array $cfg): array {
        require_once dirname(__DIR__).'/vendor-email/autoload.php';$raw=(string)($msg['raw']??'');$end=strpos($raw,"\r\n\r\n");if($end===false){$pos=strrpos($raw,"\r\n");$raw=($pos===false?'':substr($raw,0,$pos))."\r\n\r\n";}
        $m=(new \F3BaseEmailVendor\ZBateson\MailMimeParser\MailMimeParser())->parse($raw,false);$from=$m->getHeader('From');$email=$from&&method_exists($from,'getEmail')?strtolower((string)$from->getEmail()):'';$subject=mb_substr(sanitize_text_field((string)$m->getHeaderValue('Subject','')),0,500);
        return array('classe'=>'suspeito','motivo'=>'cabecalho_excedido','cabecalho_excedido'=>true,'acima_limite'=>true,'bytes_mensagem'=>(int)$msg['bytes'],'remetente'=>is_email($email)?$email:'','email'=>is_email($email)?$email:'','assunto'=>$subject,'teste'=>!empty($cfg['homologacao'])||str_starts_with($subject,'[TESTE F3BASE]'),'alertas'=>array(),'autenticacao'=>array('aceito'=>false,'descartar'=>false,'motivo'=>'cabecalho_incompleto'));
    }
    public static function avisar(string $key): void {
        $lock=F3Base_Trava::adquirir('email-excedida:'.$key,60);if(!$lock){return;}
        try{$row=F3Base_Email_Site::row($key);if(!$row||$row['estado']!=='cabecalho_excedido'){return;}$p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$p){return;}$title='E-mail acima do limite requer revisão';$text='Remetente declarado: '.($p['remetente']?:'indisponível')."\nAssunto: ".$p['assunto']."\nTamanho: ".$p['bytes_mensagem']." bytes\nCabeçalho incompleto; autenticação não verificada. Mensagem preservada na pasta de importados.\nUID: ".$row['uid'].' / '.$row['uidvalidity'];
            foreach(array('email','slack') as $channel){if(isset($p['alertas'][$channel])){continue;}$p['alertas'][$channel]=array('estado'=>'incerto','codigo'=>'reservado_antes_envio','revisao_destino'=>F3Base_Options::revisao($channel==='email'?'f3base_avisos_tecnicos':'f3base_avisos'),'em'=>time());if(!F3Base_Email_Site::patch($key,array('payload'=>F3Base_Contato_Comunicacao::cifrar($p)))){return;}$fresh=F3Base_Email_Site::row($key);if(!$fresh||$fresh['estado']!=='cabecalho_excedido'||$fresh['payload']===''){return;}
                $result=$channel==='email'?F3Base_Alertas_Operacionais::enviar($title,$text,!empty($p['teste'])):self::slack($title,$text,!empty($p['teste']));$p['alertas'][$channel]=$result+array('em'=>time());global $wpdb;$wpdb->update(F3Base_Email_Site::tabela(),array('payload'=>F3Base_Contato_Comunicacao::cifrar($p),'atualizada_em'=>time()),array('chave'=>$key,'estado'=>'cabecalho_excedido','payload'=>$fresh['payload']));
            }
            global $wpdb;$wpdb->update(F3Base_Email_Site::tabela(),array('aviso_em'=>time()),array('chave'=>$key,'estado'=>'cabecalho_excedido'));
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function slack(string $title,string $text,bool $test): array {
        if($test&&F3Base_Testes::politica('slack','teste')==='suprimir'){return array('ok'=>true,'estado'=>'suprimido_teste');}$cfg=F3Base_Options::ler('f3base_avisos');$message=F3Base_Slack::simples(($test?'[TESTE F3BASE] ':'').$title,array('Revisão'=>array('Mensagem'=>$text)),F3Base_Configuracoes_Hub::url('conexoes','f3base_email_site'));
        if(($cfg['slack_transporte']??'webhook')==='app'){$token=F3Base_Segredos::abrir(F3Base_Slack::SEGREDO);$channel=$cfg['slack_canal_id']??'';if(!$token||!preg_match('/^[CG][A-Z0-9]{8,63}$/D',$channel)){return array('ok'=>false,'estado'=>'sem_destino');}$r=F3Base_Slack::api('chat.postMessage',$token,array('channel'=>$channel)+$message);return array('ok'=>!empty($r['ok']),'estado'=>!empty($r['ok'])?'confirmado':'incerto','codigo'=>!empty($r['ok'])?'slack_confirmou':'slack_nao_confirmou');}
        $url=F3Base_Segredos::abrir(F3Base_Avisos::SEGREDO);if(!F3Base_Avisos::url_valida($url)){return array('ok'=>false,'estado'=>'sem_destino');}$r=wp_safe_remote_post($url,array('timeout'=>8,'redirection'=>0,'headers'=>array('Content-Type'=>'application/json'),'body'=>wp_json_encode($message)));$ok=!is_wp_error($r)&&wp_remote_retrieve_response_code($r)===200&&trim(wp_remote_retrieve_body($r))==='ok';return array('ok'=>$ok,'estado'=>$ok?'confirmado':'incerto');
    }
}
