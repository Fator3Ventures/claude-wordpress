<?php
/** Local inventory and bounded deletion of registered messages, independent of lead lifetime. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Slack_Gestao {
    private static function filtros_gestao(): array {
        return array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'de'=>array('type'=>'integer','minimum'=>0,'description'=>'Instante UTC inclusivo (Unix).'),'ate'=>array('type'=>'integer','minimum'=>0,'description'=>'Instante UTC inclusivo (Unix).'),'teste'=>array('type'=>'boolean'),'estado'=>array('type'=>'string','maxLength'=>32),'tipo'=>array('type'=>'string','maxLength'=>32));
    }
    private static function onde_gestao(array $e): string {
        global $wpdb;$w=$wpdb->prepare("tipo IN ('parte','teste') AND site=%s",self::site());
        foreach(array('record_id','estado','tipo') as $k){if(isset($e[$k])){$col=$k==='tipo'?'aviso_tipo':$k;$w.=$wpdb->prepare(" AND {$col}=%s",$e[$k]);}}
        foreach(array('de'=>'>=','ate'=>'<=') as $k=>$op){if(isset($e[$k])){$w.=$wpdb->prepare(" AND criado_em {$op} %d",$e[$k]);}}
        if(isset($e['teste'])){$w.=$wpdb->prepare(' AND teste=%d',$e['teste']?1:0);}return $w;
    }
    private static function resumo_gestao(array $r): array {
        global $wpdb;$v=self::publico($r);$v['tipo']=$r['aviso_tipo'];$v['origem_registro']=$r['tipo'];$v['teste']=(bool)$r['teste'];
        $v['presenca_conhecida']=(int)$r['ausencia_em']>0?'ausente':($r['ts']!==''?'aceita_pela_api':'desconhecida');$v['presenca_verificada_em']=(int)$r['ausencia_em']?:null;
        $v['respostas_proprias']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE principal=%s AND site=%s AND tipo IN ('parte','teste')",self::tabela(),$r['id'],self::site()));return $v;
    }
    public static function listar_gestao(array $e=array()): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}global $wpdb;$w=self::onde_gestao($e);$limit=max(1,min(100,(int)($e['limite']??50)));$finger=hash('sha256',$w);
        if(!empty($e['cursor'])){$c=json_decode((string)base64_decode($e['cursor'],true),true);if(!is_array($c)||($c['filtro']??'')!==$finger||!is_int($c['em']??null)||!preg_match('/^[a-f0-9]{64}$/D',(string)($c['id']??''))){return self::erro('cursor_invalido');}$w.=$wpdb->prepare(' AND (criado_em>%d OR (criado_em=%d AND id>%s))',$c['em'],$c['em'],$c['id']);}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$w} ORDER BY criado_em,id LIMIT %d",self::tabela(),$limit+1),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);$last=end($rows);
        return array('ok'=>true,'linhas'=>array_map(array(__CLASS__,'resumo_gestao'),$rows),'proximo_cursor'=>$more?base64_encode(wp_json_encode(array('filtro'=>$finger,'em'=>(int)$last['criado_em'],'id'=>$last['id']))):null,'cobertura'=>'Inventário local; aceite da API não comprova presença atual nem leitura humana.');
    }
    private static function selecionar_gestao(array $e): array {
        global $wpdb;$limit=max(1,min(50,(int)($e['limite']??20)));$ids=$e['ids']??(!empty($e['id'])?array($e['id']):array());$filter=$e['filtro']??array();
        if($ids&&$filter){return self::erro('use_ids_ou_filtro');}if(!$ids&&!$filter){return self::erro('selecao_obrigatoria');}
        $w=self::onde_gestao($filter);if($ids){if(count($ids)>50||array_filter($ids,static fn($id)=>!is_string($id)||!preg_match('/^[a-f0-9]{64}$/D',$id))){return self::erro('ids_invalidos');}$marks=implode(',',array_fill(0,count($ids),'%s'));$w.=$wpdb->prepare(" AND id IN ({$marks})",...$ids);}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE {$w} ORDER BY criado_em,id LIMIT %d",self::tabela(),$limit+1),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}
        if($ids&&count($rows)<count(array_unique($ids))){return self::erro('alvo_nao_registrado');}
        $map=array_column($rows,null,'id');
        // Expand only known children of selected roots. Never discover/delete arbitrary thread members.
        foreach($rows as $row){if($row['principal']!==''){continue;}$children=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE principal=%s AND site=%s AND tipo IN ('parte','teste') LIMIT %d",self::tabela(),$row['id'],self::site(),$limit+1),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}foreach($children as $child){$map[$child['id']]=$child;}}
        if(count($map)>$limit){return self::erro('limite_excedido',array('limite'=>$limit,'orientacao'=>'Restrinja o filtro ou selecione primeiro as respostas; não houve exclusão.'));}
        ksort($map);$versions=array();foreach($map as $id=>$r){$versions[$id]=array_intersect_key($r,array_flip(array('revisao','estado','teste','canal','ts','principal','site','destino','team_id','bot_id','user_id')));}
        $rows=array_values($map);usort($rows,static fn($a,$b)=>(int)($b['principal']!=='')<=>(int)($a['principal']!==''));
        return array('ok'=>true,'linhas'=>$rows,'revisao'=>hash('sha256',wp_json_encode($versions)));
    }
    public static function apagar_gestao(array $e): array {return self::operacao('apagar_gestao',$e,static function(bool $sim)use($e){
        $s=self::selecionar_gestao($e);if(empty($s['ok'])){return $s;}$production=(bool)array_filter($s['linhas'],static fn($r)=>!(int)$r['teste']);
        if(!empty($e['somente_testes'])&&$production){return self::erro('mensagem_de_producao');}
        if($sim){return array('ok'=>true,'simular'=>true,'revisao'=>$s['revisao'],'alvos'=>array_map(array(__CLASS__,'resumo_gestao'),$s['linhas']),'exige_confirmar_nao_teste'=>$production,'regra'=>'Somente mensagens registradas com autoria comprovada; respostas próprias antes da principal. Respostas humanas não são alvos.');}
        if(trim((string)($e['motivo']??''))===''){return self::erro('motivo_obrigatorio');}
        if($production&&($e['confirmar_nao_teste']??false)!==true){return self::erro('confirmacao_nao_teste_obrigatoria');}
        if(!hash_equals($s['revisao'],(string)($e['revisao']??''))){return self::erro('selecao_alterada',array('revisao'=>$s['revisao']));}
        $results=array();foreach($s['linhas'] as $r){
            $base=array('id'=>$r['id'],'canal'=>$r['canal'],'ts'=>$r['ts']);$a=self::alvo($r['id']);
            if(empty($a['ok'])){$results[]=$base+array('ok'=>false,'resultado'=>'falhou','codigo'=>$a['codigo']);continue;}
            $remote=self::remota($r);$accepted=(int)$r['remocao_aceita_em'];
            if(empty($remote['ok'])){$results[]=$base+array('ok'=>false,'resultado'=>'falhou','codigo'=>$remote['codigo']);continue;}
            $code=$accepted?'apagada':'ausente_antes';
            if($remote['messages']){
                if(!self::propria($remote['messages'][0],$r)){$results[]=$base+array('ok'=>false,'resultado'=>'nao_propria','codigo'=>'autoria_divergente');continue;}
                $res=F3Base_Slack::api('chat.delete',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$r['canal'],'ts'=>$r['ts']));
                if(empty($res['ok'])){$results[]=$base+array('ok'=>false,'resultado'=>'falhou','codigo'=>$res['codigo'],'http'=>$res['http']??null);continue;}
                $accepted=time();$code='apagada';
                // Erase content immediately after the accepted deletion; retain only technical proof.
                if(!self::mudar($r,array('estado'=>'confirmacao_pendente','payload'=>'','remocao_aceita_em'=>$accepted,'ausencia_em'=>0))){$results[]=$base+array('ok'=>false,'resultado'=>'falhou','codigo'=>'resultado_incerto_nao_persistido');continue;}
                $remote=self::remota($r);if(empty($remote['ok'])||$remote['messages']){$results[]=$base+array('ok'=>false,'resultado'=>'falhou','codigo'=>'confirmacao_pendente','erro_slack'=>$remote['codigo']??null);continue;}
            }
            $ok=self::mudar($r,array('estado'=>'apagada','payload'=>'','ausencia_em'=>time(),'remocao_aceita_em'=>$accepted));
            $results[]=$base+array('ok'=>$ok,'resultado'=>$ok?$code:'falhou','codigo'=>$ok?$code:'resultado_incerto_nao_persistido','verificado_em'=>time());
            if($ok){global $wpdb;$wpdb->query($wpdb->prepare("UPDATE %i SET payload='',estado='suprimido',codigo='aviso_limpo',proxima=0 WHERE chave=%s",F3Base_Slack::tabela(),$r['id']));}
        }
        $ok=!array_filter($results,static fn($r)=>!$r['ok']);return array('ok'=>$ok,'codigo'=>$ok?'limpeza_concluida':'limpeza_parcial','resultados'=>$results,'parcial'=>!$ok);
    });}
    public static function apagar_testes(array $e): array {$e['somente_testes']=true;if(!empty($e['filtro'])){$e['filtro']['teste']=true;}return self::apagar_gestao($e);}
    public static function slack_eliminacao(string $record,bool $sim,bool $apagar): array {
        $e=array('filtro'=>array('record_id'=>$record),'limite'=>50,'simular'=>true);$preview=self::apagar_gestao($e);
        if(!$apagar){return array('solicitada'=>false,'resultado'=>'preservado','alvos'=>$preview['alvos']??array());}
        if($sim||empty($preview['ok'])){return $preview+array('solicitada'=>true);}
        $e+=array('revisao'=>$preview['revisao'],'chave_operacao'=>'eliminar:'.$record.':'.substr($preview['revisao'],0,24),'motivo'=>'Eliminação do contato solicitada pelo administrador.','confirmar_nao_teste'=>true);$e['simular']=false;return self::apagar_gestao($e)+array('solicitada'=>true);
    }
    public static function marcar_teste(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_gerir_leads')){return self::erro('sem_permissao');}
        global $wpdb;$id=(string)($e['record_id']??'');$r=F3Base_Leads_Repositorio::obter($id);if(!$r||$r['captura']==='eliminado'||!empty($r['eliminacao_pendente'])){return self::erro('contato_indisponivel');}
        if((int)$r['revisao']!==(int)($e['revisao_esperada']??0)){return self::erro('conflito');}
        if($e['simular']??true){return array('ok'=>true,'simulado'=>true,'record_id'=>$id,'revisao'=>(int)$r['revisao'],'classe_antes'=>$r['classe_trafego'],'classe_depois'=>'teste','avisos'=>self::listar_gestao(array('record_id'=>$id)));}
        if(trim((string)($e['motivo']??''))===''){return self::erro('motivo_obrigatorio');}
        $lock=F3Base_Trava::adquirir('slack-transporte',45);if(!$lock){return self::erro('slack_transporte_ocupado');}
        try{$wpdb->query('START TRANSACTION');$a=$wpdb->query($wpdb->prepare("UPDATE %i SET classe_trafego='teste',revisao=revisao+1,atualizado_em=%s WHERE record_id=%s AND revisao=%d",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s'),$id,$r['revisao']));$b=$wpdb->query($wpdb->prepare("UPDATE %i SET teste=1,atualizado_em=%d WHERE record_id=%s AND tipo IN ('parte','teste')",self::tabela(),time(),$id));$c=$wpdb->query($wpdb->prepare("UPDATE %i SET classe='teste' WHERE record_id=%s",F3Base_Avisos::tabela(),$id));if($a!==1||$b===false||$c===false){$wpdb->query('ROLLBACK');return self::erro('classificacao_nao_persistida');}if($wpdb->query('COMMIT')===false){return self::erro('classificacao_nao_confirmada');}return array('ok'=>true,'record_id'=>$id,'classe_trafego'=>'teste','revisao'=>(int)$r['revisao']+1,'avisos_marcados'=>$b);
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function registrar_gestao(): void {
        $id=array('type'=>'string','pattern'=>'^[a-f0-9]{64}$');$filter=array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros_gestao());$write=array('id'=>$id,'ids'=>array('type'=>'array','minItems'=>1,'maxItems'=>50,'uniqueItems'=>true,'items'=>$id),'filtro'=>$filter,'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>50),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'chave_operacao'=>array('type'=>'string','maxLength'=>128),'motivo'=>array('type'=>'string','maxLength'=>500),'confirmar_nao_teste'=>array('type'=>'boolean','default'=>false));
        F3Base_Servicos::ability('avisos-slack-listar','Inventário local paginado, sem conteúdo pessoal e sem consulta remota',array(__CLASS__,'listar_gestao'),self::filtros_gestao()+array('cursor'=>array('type'=>'string','maxLength'=>1024),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>100)));
        F3Base_Servicos::ability('avisos-slack-apagar','Simular e apagar mensagens próprias registradas, inclusive após eliminar o contato',array(__CLASS__,'apagar_gestao'),$write,array(),false);
        F3Base_Servicos::ability('avisos-slack-testes-apagar','Simular e apagar avisos de teste por ids ou filtro; inclui respostas próprias',array(__CLASS__,'apagar_testes'),$write,array(),false);
        F3Base_Servicos::ability('leads-marcar-teste','Reclassificar contato e seus avisos como teste, sem novo envio',array(__CLASS__,'marcar_teste'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'revisao_esperada'=>array('type'=>'integer','minimum'=>1),'simular'=>array('type'=>'boolean','default'=>true),'motivo'=>array('type'=>'string','maxLength'=>500)),array('record_id','revisao_esperada'),false,'f3base_gerir_leads');
    }
}
