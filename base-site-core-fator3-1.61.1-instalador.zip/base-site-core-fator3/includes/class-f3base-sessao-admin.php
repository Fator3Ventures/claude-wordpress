<?php
/** Remembered administrator logins use the site's explicit duration. WordPress owns tokens and revocation. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Sessao_Admin {
    const OPTION = 'f3base_sessao_admin_dias';
    public static function iniciar(): void {
        add_filter('auth_cookie_expiration', array(__CLASS__, 'expiracao'), 10000, 3);
    }
    public static function expiracao(int $seconds, int $user_id, bool $remember): int {
        if (!$remember || !user_can($user_id, 'manage_options')) { return $seconds; }
        return max(1, min(365, (int) F3Base_Options::ler(self::OPTION))) * DAY_IN_SECONDS;
    }
}
