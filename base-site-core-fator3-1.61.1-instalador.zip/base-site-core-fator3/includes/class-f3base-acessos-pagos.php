<?php
/** Presença, nunca valor, de identificadores de clique no request-target. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Acessos_Pagos {
    const PARAMETROS=array('gclid'=>1,'gbraid'=>2,'wbraid'=>4,'fbclid'=>8,'utm_source_platform'=>16);
    public static function mascara(string $target,string $method,string $class): int {
        if($method!=='GET'||$class!=='pagina'){return 0;}$query=wp_parse_url($target,PHP_URL_QUERY);if(!is_string($query)){return 0;}$mask=0;
        foreach(explode('&',$query) as $part){$key=urldecode(explode('=',$part,2)[0]);$mask|=self::PARAMETROS[$key]??0;}return $mask;
    }
    public static function ler(string $de,string $ate,string $prefix='',int $offset=0,bool $errors=false,string $classe=''): array {
        global $wpdb;$table=$wpdb->prefix.F3Base_Modulo_Acessos_Servidor::TABELA;$offset=max(0,$offset);
        $out=array('ok'=>true,'linhas'=>array(),'offset'=>$offset,'limite'=>100,'proximo_offset'=>null,'classificacao_revisao'=>F3Base_Modulo_Acessos_Servidor::config_hash(),'regra'=>'GET de página, presença por parâmetro, uma vez por requisição. Valores e query não são guardados. Sessões são observadas, sem equivalência a cliques cobrados.','sessoes_regra'=>'Sessões distintas pagas por caminho/dia, sem testes e automação declarada/provável. Repetidas nas classes de log do mesmo caminho/dia: não somar entre classes.','cobertura'=>F3Base_Acessos_Coleta::cobertura($de,$ate));
        if($classe!==''&&$classe!=='pagina'){$out['codigo']='recorte_sem_paginas';return $out;}
        $effective=F3Base_Agentes_Classificacao::expressao();$class="CASE WHEN ($effective) IN ('humano','navegador-provavel') THEN 'navegador_provavel' WHEN ($effective) IN ('automacao-suspeita','proprio','hospedagem','automacao-declarada') OR (agente='robo-generico' AND assinatura_ua NOT IN ('desconhecida','historico_desconhecido','')) THEN 'automacao' WHEN ($effective)='desconhecido' THEN 'desconhecida' ELSE 'robo_declarado' END";
        $where=$wpdb->prepare("dia BETWEEN %s AND %s AND metodo='GET' AND classe_caminho='pagina'",$de,$ate);if(!$errors){$where.=' AND status<400';}if($prefix!==''){$where.=$wpdb->prepare(' AND caminho LIKE %s',$wpdb->esc_like($prefix).'%');}
        $sums=array();foreach(self::PARAMETROS as $name=>$bit){$sums[]="SUM(CASE WHEN parametros_pagos>=0 THEN IF((parametros_pagos & $bit)>0,contagem,0) ELSE NULL END) $name";}
        $sql="SELECT dia,caminho,$class classe,SUM(contagem) requisicoes,SUM(IF(parametros_pagos<0,contagem,0)) sem_coleta_parametros,".implode(',',$sums)." FROM %i WHERE $where GROUP BY dia,caminho,classe ORDER BY dia,caminho,classe LIMIT 101 OFFSET %d";
        $rows=$wpdb->get_results($wpdb->prepare($sql,$table,$offset),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'presenca_parametros_leitura_falhou','linhas'=>null);}
        $out['proximo_offset']=count($rows)>100?$offset+100:null;$rows=array_slice($rows,0,100);$pairs=array();foreach($rows as $r){$key=$r['dia'].'|'.$r['caminho'];if(!isset($pairs[$key])){[$start,$end]=F3Base_Editorial::janela_dia($r['dia']);$pairs[$key]=$wpdb->prepare('SELECT %s dia,%s caminho,%d inicio,%d fim',$r['dia'],$r['caminho'],$start,$end);}}
        $observed=array();$failure=false;if($pairs){$analise=F3Base_Analise::tabela();$query='SELECT p.dia,p.caminho,COUNT(DISTINCT CONCAT(a.classe_trafego,\'|\',a.sessao)) sessoes FROM ('.implode(' UNION ALL ',array_values($pairs)).') p LEFT JOIN '.$wpdb->prepare('%i',$analise)." a ON a.caminho=p.caminho AND a.criado_em>=p.inicio AND a.criado_em<p.fim AND a.tipo='pagina' AND a.canal='pago' AND a.classe_trafego='nao_marcado' AND a.automacao NOT IN ('declarada','provavel') GROUP BY p.dia,p.caminho";$counts=$wpdb->get_results($query,ARRAY_A);$failure=(bool)$wpdb->last_error;foreach($counts??array() as $r){$observed[$r['dia'].'|'.$r['caminho']]=(int)$r['sessoes'];}}
        foreach($rows as &$r){foreach(array_merge(array('requisicoes','sem_coleta_parametros'),array_keys(self::PARAMETROS)) as $k){$r[$k]=$r[$k]===null?null:(int)$r[$k];}$r['sessoes_pagas_observadas']=$failure?null:($observed[$r['dia'].'|'.$r['caminho']]??0);$r['sessoes_codigo']=$failure?'leitura_falhou':'observadas';}unset($r);$out['linhas']=$rows;$out['medicao_habilitada']=F3Base_Modulo_Comportamento::ligado();return $out;
    }
}
