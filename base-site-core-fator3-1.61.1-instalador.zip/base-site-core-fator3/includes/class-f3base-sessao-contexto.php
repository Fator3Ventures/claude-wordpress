<?php
/** Contexto observado no pedido de medição; não depende da renderização da página. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Sessao_Contexto {
    const OPTION='f3base_contexto_sessao';
    const COLUNAS=array('contexto_cifrado','ip_hash','app','contexto_publico','contexto_em');
    public static function padrao(): array {return array('apps_modo'=>'somar','apps'=>array(),'redes'=>array(),'usar_nuvens_oficiais'=>true);}
    public static function schema(): array {
        $list=array('type'=>'array','maxItems'=>30,'uniqueItems'=>true,'items'=>array('type'=>'string','minLength'=>1,'maxLength'=>150));
        return array('type'=>'object','additionalProperties'=>false,'required'=>array('apps_modo','apps','redes','usar_nuvens_oficiais'),'properties'=>array(
            'apps_modo'=>array('type'=>'string','enum'=>array('somar','substituir')),
            'apps'=>array('type'=>'array','maxItems'=>100,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('id','pacotes','marcas'),'properties'=>array('id'=>array('type'=>'string','pattern'=>'^[a-z][a-z0-9_]{0,63}$'),'pacotes'=>$list,'marcas'=>$list))),
            'redes'=>array('type'=>'array','maxItems'=>2000,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('cidr','classe','fonte','versao'),'properties'=>array('cidr'=>array('type'=>'string','maxLength'=>50),'classe'=>array('type'=>'string','enum'=>array('movel','residencial','datacenter','desconhecida')),'fonte'=>array('type'=>'string','minLength'=>1,'maxLength'=>250),'versao'=>array('type'=>'string','minLength'=>1,'maxLength'=>100)))),
            'usar_nuvens_oficiais'=>array('type'=>'boolean')));
    }
    public static function recusar($v): string {
        if(is_wp_error(rest_validate_value_from_schema($v,self::schema()))){return 'Configuração de apps/redes fora do schema.';}
        $ids=array();$packages=array();foreach($v['apps'] as $a){if(isset($ids[$a['id']])||(!$a['pacotes']&&!$a['marcas'])){return 'Informe apps únicos com ao menos um pacote ou marca.';}$ids[$a['id']]=true;foreach($a['pacotes'] as $pkg){if(!preg_match('/^[a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z0-9_]+)+$/D',$pkg)||isset($packages[strtolower($pkg)])){return 'Pacote Android inválido ou repetido.';}$packages[strtolower($pkg)]=true;}}
        $seen=array();foreach($v['redes'] as $r){$a=explode('/',$r['cidr']);if(count($a)!==2||!ctype_digit($a[1])||!filter_var($a[0],FILTER_VALIDATE_IP)||(int)$a[1]>strlen(inet_pton($a[0]))*8||isset($seen[$r['cidr']])){return 'Faixa CIDR inválida ou repetida.';}$seen[$r['cidr']]=true;}return '';
    }
    public static function catalogo(array $c): array {
        $schema=self::schema();$c[self::OPTION]=array('rotulo'=>'Apps e classes de rede das sessões','descricao'=>'Catálogo revisável. Simule em contexto-sessao-simular; apps somam ou substituem o padrão. Redes locais são ordenadas e exigem fonte e versão. Sem faixa comprovada, a rede é desconhecida.','impacto'=>'Somente capturas novas. Não reclassifica automação nem atribui pessoa a IP. Nuvens usam somente listas oficiais já válidas no cache.','exemplo'=>'Use apps_modo somar para acrescentar marcas; declare CIDR, classe, fonte e versão da base de redes.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','padrao'=>self::padrao(),'autoload'=>false,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>array(__CLASS__,'recusar'));return $c;
    }
    public static function apps(array $cfg): array {
        $base=json_decode((string)file_get_contents(F3BASE_PLUGIN_DIR.'dados/apps-webview.json'),true);$out=array();
        foreach(($cfg['apps_modo']??'somar')==='substituir'?array():($base['apps']??array()) as $a){$out[$a['id']]=$a;}
        // Uma entrada do site com o mesmo id substitui integralmente aquela entrada do pacote.
        foreach($cfg['apps']??array() as $a){$out[$a['id']]=$a;}return array_values($out);
    }
    public static function classificar(string $ip,string $ua,string $requested,?array $cfg=null): array {
        $cfg=$cfg??F3Base_Options::ler(self::OPTION);$revision=hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($cfg)));
        $out=array('app'=>'','app_fonte'=>'nao_observada','app_conflito'=>false,'revisao_ia'=>hash('sha256',wp_json_encode(F3Base_Canais_Organicos::provedores())),'catalogo_apps_sha256'=>hash_file('sha256',F3BASE_PLUGIN_DIR.'dados/apps-webview.json'),'revisao'=>$revision,
            'rede'=>array('classe'=>'desconhecida','fonte'=>null,'versao'=>null,'motivo'=>'sem_faixa_correspondente'));
        $header=array();$markers=array();foreach(self::apps($cfg) as $a){if($requested!==''&&in_array(strtolower($requested),array_map('strtolower',$a['pacotes']),true)){$header[]=$a['id'];}foreach($a['marcas'] as $m){if(stripos($ua,$m)!==false){$markers[]=$a['id'];break;}}}
        $hits=array_values(array_unique(array_merge($header,$markers)));if(count($hits)===1){$out['app']=$hits[0];$out['app_fonte']=$header?'x_requested_with':'marca_user_agent';}elseif(count($hits)>1){$out['app_conflito']=true;$out['app_fonte']='sinais_conflitantes';}
        if(!filter_var($ip,FILTER_VALIDATE_IP)){$out['rede']['motivo']='ip_indisponivel';return $out;}
        foreach($cfg['redes']??array() as $r){if(F3Base_Redes_Robos::contem($ip,$r['cidr'])){$out['rede']=array('classe'=>$r['classe'],'fonte'=>$r['fonte'],'versao'=>$r['versao'],'motivo'=>'faixa_configurada','base_sha256'=>hash('sha256',wp_json_encode($cfg['redes'])));return $out;}}
        if(!empty($cfg['usar_nuvens_oficiais'])){$cloud=F3Base_Redes_Robos::nuvem($ip);if($cloud){$out['rede']=array('classe'=>'datacenter','fonte'=>F3Base_Redes_Robos::FONTES[$cloud['provedor']]??$cloud['provedor'],'versao'=>$cloud['lista_versao'],'base_sha256'=>$cloud['lista_sha256'],'base_em'=>$cloud['lista_em'],'motivo'=>'faixa_oficial_nuvem');}}
        return $out;
    }
    public static function capturar(?WP_REST_Request $req=null): array {
        $origin=F3Base_Modulo_Endpoint_Leads::origem();$ip=self::ip((string)($origin['valor']??''));
        $ua=mb_strcut(sanitize_text_field(wp_unslash($req?$req->get_header('user-agent'):(string)($_SERVER['HTTP_USER_AGENT']??''))),0,500,'UTF-8');
        if($ua===''&&$req){$ua=mb_strcut(sanitize_text_field(wp_unslash((string)($_SERVER['HTTP_USER_AGENT']??''))),0,500,'UTF-8');}
        $requested=trim((string)($req?$req->get_header('x-requested-with'):($_SERVER['HTTP_X_REQUESTED_WITH']??'')));if(strlen($requested)>150){$requested='';}
        return array('ip'=>$ip?:null,'ip_fonte'=>$origin['fonte']??'indisponivel','user_agent'=>$ua,'capturado_em'=>time(),'publico'=>self::classificar($ip,$ua,$requested));
    }
    public static function contato(array $d): array {
        global $wpdb;$capture=self::capturar()['publico']+array('contexto_fonte'=>'pedido_contato');$session=F3Base_Leads_Contexto::sessao($d['sessao']??null);$visitor=F3Base_Leads_Contexto::sessao($d['visitante']??null);if(!$session||!$visitor){return $capture;}
        $row=$wpdb->get_row($wpdb->prepare('SELECT contexto_publico,contexto_em FROM %i WHERE sessao=%s AND visitante=%s AND classe=%s AND conflito=0 AND contexto_em>0',F3Base_Sessoes::tabela(),$session,$visitor,!empty($d['contexto_teste'])?'teste':'nao_marcado'),ARRAY_A);
        if($row){$public=json_decode($row['contexto_publico'],true);if(is_array($public)){return $public+array('contexto_fonte'=>'pedido_medicao','contexto_em'=>(int)$row['contexto_em']);}}return $capture;
    }
    public static function ip(string $ip): string {return filter_var($ip,FILTER_VALIDATE_IP)?inet_ntop(inet_pton($ip)):'';}
    public static function indice(string $ip): string {$ip=self::ip($ip);return $ip!==''?hash_hmac('sha256','sessao-ip|'.$ip,wp_salt('auth')):'';}
    private static function chave(string $sessao,string $classe): string {return hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:sessao-contexto:1:'.$classe.':'.$sessao);}
    public static function colunas(array $row,?array $capture): array {
        $out=array('contexto_cifrado'=>null,'ip_hash'=>'','app'=>'','contexto_publico'=>null,'contexto_em'=>0);if($capture===null){return $out;}
        $n=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);$public=$capture['publico'];unset($capture['publico']);
        $out['contexto_cifrado']='f3sc:1:'.base64_encode($n.sodium_crypto_secretbox(wp_json_encode($capture),$n,self::chave($row['sessao'],$row['classe_trafego']??'nao_marcado')));
        $out['ip_hash']=self::indice((string)($capture['ip']??''));$out['app']=$public['app'];$out['contexto_publico']=wp_json_encode($public);$out['contexto_em']=$capture['capturado_em'];return $out;
    }
    public static function apresentar(array $row): array {
        $public=json_decode($row['contexto_publico']??'',true)?:array('app'=>'','app_fonte'=>'nao_observada','revisao'=>null,'rede'=>array('classe'=>'desconhecida','fonte'=>null,'versao'=>null,'motivo'=>'contexto_nao_capturado'));
        $out=$public+array('contexto_em'=>!empty($row['contexto_em'])?(int)$row['contexto_em']:null,'contexto_codigo'=>!empty($row['contexto_em'])?'observado':'historico_sem_captura');
        if(!current_user_can('f3base_ler_leads')){return $out+array('dados_pessoais'=>'sem_permissao');}
        if(!empty($row['conflito'])){return $out+array('dados_pessoais'=>'identidade_conflitante');}
        $out['visitante']=$row['visitante']??null;$out['ip']=null;$out['user_agent']=null;$out['ip_fonte']=null;
        $cipher=$row['contexto_cifrado']??'';if(!$cipher){return $out;}
        try{if(!str_starts_with($cipher,'f3sc:1:')){throw new RuntimeException();}$raw=base64_decode(substr($cipher,7),true);if($raw===false||strlen($raw)<40){throw new RuntimeException();}$plain=sodium_crypto_secretbox_open(substr($raw,24),substr($raw,0,24),self::chave($row['sessao'],$row['classe']));$value=$plain!==false?json_decode($plain,true):null;if(!is_array($value)){throw new RuntimeException();}foreach(array('ip','ip_fonte','user_agent') as $key){$out[$key]=$value[$key]??null;}}
        catch(Throwable $x){$out['contexto_codigo']='contexto_ilegivel';}return $out;
    }
    public static function filtro_sql(array $e): string {
        global $wpdb;$where='';if(!empty($e['ip'])){$where.=$wpdb->prepare(' AND ip_hash=%s',self::indice($e['ip']));}if(!empty($e['visitante'])){$where.=$wpdb->prepare(' AND visitante=%s',$e['visitante']);}if(!empty($e['app'])){$where.=$wpdb->prepare(' AND app=%s',$e['app']);}
        return $where?$wpdb->prepare(' AND (classe_trafego,sessao) IN (SELECT classe,sessao FROM %i WHERE conflito=0',F3Base_Sessoes::tabela()).$where.')':'';
    }
    /** Bounded batch: one query for the page, never one query per event. */
    public static function enriquecer(array $items): array {
        if(!$items){return $items;}global $wpdb;$parts=array();$args=array(F3Base_Sessoes::tabela());foreach($items as $s){$parts[]='(classe=%s AND sessao=%s)';$args[]=$s['classe_trafego'];$args[]=$s['sessao'];}
        $rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE '.implode(' OR ',$parts),...$args),ARRAY_A);$failed=(bool)$wpdb->last_error;$map=array();foreach($rows??array() as $r){$map[$r['classe'].'|'.$r['sessao']]=$r;}
        foreach($items as &$s){$r=$map[$s['classe_trafego'].'|'.$s['sessao']]??array('visitante'=>$s['visitante']??null);$s['google_ads']=F3Base_Google_Acervo::projecao($r['google_ads']??null,json_decode($r['origem']??'{}',true)?:[],(int)($r['inicio']??0));if(!empty($r['conflito']))$s['google_ads']=['codigo'=>'identidade_conflitante'];$s['contexto']=self::apresentar($r);if($failed){$s['contexto']['contexto_codigo']='leitura_falhou';}if(!current_user_can('f3base_ler_leads')||!empty($r['conflito'])){unset($s['visitante']);}$s['app']=$s['contexto']['app'];$s['rede']=$s['contexto']['rede'];}unset($s);return $items;
    }
    public static function simular(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}$cfg=$e['config']??F3Base_Options::ler(self::OPTION);$error=self::recusar($cfg);if($error){return array('ok'=>false,'codigo'=>'configuracao_invalida','motivo'=>$error);}if(!empty($e['ip'])&&self::ip($e['ip'])===''){return array('ok'=>false,'codigo'=>'ip_invalido');}
        return array('ok'=>true,'simulado'=>true,'persisted'=>false,'revisao_atual'=>F3Base_Options::revisao(self::OPTION),'resultado'=>self::classificar($e['ip']??'',$e['user_agent']??'',$e['x_requested_with']??'',$cfg));
    }
    public static function iniciar(): void {add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('contexto-sessao-simular','Simular app e classe de rede com catálogo candidato; sem HTTP ou gravação',array(__CLASS__,'simular'),array('ip'=>array('type'=>'string','maxLength'=>45),'user_agent'=>array('type'=>'string','maxLength'=>500),'x_requested_with'=>array('type'=>'string','maxLength'=>150),'config'=>self::schema()));});}
}
