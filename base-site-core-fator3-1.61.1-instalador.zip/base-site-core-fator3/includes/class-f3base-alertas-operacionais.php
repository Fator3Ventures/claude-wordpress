<?php
/** Canal exclusivo de alertas operacionais. A reserva/deduplicação pertence ao chamador. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Alertas_Operacionais {
    const POLITICA='avisos-tecnicos/1';
    public static function catalogo(array $c): array {
        $defaults=array('email'=>'','atraso_minutos'=>60);$props=array('email'=>array('type'=>'string','maxLength'=>254,'description'=>'Vazio usa admin_email. Destino técnico independente de avisos de contato.'),'atraso_minutos'=>array('type'=>'integer','minimum'=>60,'maximum'=>1440,'description'=>'Sem erro, aguarda este prazo desde a última leitura completa; padrão 60 minutos.'));
        $c['f3base_avisos_tecnicos']=F3Base_Conversas::catalogo_grupo('f3base_avisos_tecnicos','Avisos técnicos por e-mail',$defaults,$props,static function($v){return isset($v['email'])&&$v['email']!==''&&!is_email($v['email'])?'E-mail técnico inválido.':'';});$c['f3base_avisos_tecnicos']['descricao']='Destino próprio de avisos técnicos por e-mail; vazio usa admin_email. Erro real avisa imediatamente; atraso sem erro espera ao menos 60 minutos. Não usa o canal de contatos.';return $c;
    }
    public static function resumo(): array {$c=F3Base_Options::ler('f3base_avisos_tecnicos');return array('canal'=>'email','destinatario'=>self::destinatario(),'atraso_minutos'=>$c['atraso_minutos']??60,'primeiro_erro'=>'imediato','recuperacao'=>'somente_apos_atencao_aceita','origem'=>'f3base/config-core-ler: f3base_avisos_tecnicos');}
    public static function destinatario(): string {
        $c=F3Base_Options::ler('f3base_avisos_tecnicos');$v=!empty($c['email'])?$c['email']:get_option('admin_email','');return is_string($v)&&is_email($v)?$v:'';
    }
    public static function enviar(string $titulo,string $texto,bool $teste=false): array {
        $r=array('politica'=>self::POLITICA,'canal'=>'email','recebimento'=>'nao_comprovado','em'=>time());
        if($teste&&F3Base_Testes::politica('email','teste')==='suprimir'){return $r+array('estado'=>'suprimido_teste','ok'=>true);}
        $to=self::destinatario();if($to===''){return $r+array('estado'=>'sem_destinatarios','codigo'=>'admin_email_invalido','ok'=>false);}
        try{$ok=wp_mail($to,($teste?'[TESTE] ':'').$titulo,$texto,array('Content-Type: text/plain; charset=UTF-8'));
            return $r+array('ok'=>$ok,'estado'=>$ok?'processado':'falhou','codigo'=>$ok?'aceito_wp_mail':'envio_recusado');
        }catch(Throwable $e){return $r+array('ok'=>false,'estado'=>'incerto','codigo'=>'envio_sem_confirmacao');}
    }
}
