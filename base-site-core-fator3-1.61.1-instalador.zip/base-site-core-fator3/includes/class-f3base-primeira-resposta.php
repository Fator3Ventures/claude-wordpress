<?php
/** First observed team response. Conversation text is never persisted by this observer. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Primeira_Resposta {
    const HOOK='f3base_primeira_resposta_processar';const OPCAO='f3base_primeira_resposta';
    private static array $users=array();
    private static float $prazo=0;
    private static function restante_ms(): int {return min(F3Base_Execucoes::restante_ms(),self::$prazo?max(0,(int)((self::$prazo-microtime(true))*1000)):20000);}
    private static function pendente(array $state): array {return array_merge($state,array("codigo"=>"paginacao_pendente","orcamento_pendente"=>true,"em"=>time(),"completa"=>false));}
    public static function padroes(): array {return array('ativo'=>true,'janela_dias'=>90,'pipedrive_usuarios_humanos'=>array());}
    public static function config(): array {return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPCAO));}
    public static function catalogo(array $c): array {
        $props=array('ativo'=>array('type'=>'boolean'),'janela_dias'=>array('type'=>'integer','minimum'=>1,'maximum'=>365),'pipedrive_usuarios_humanos'=>array('type'=>'array','uniqueItems'=>true,'maxItems'=>100,'items'=>array('type'=>'integer','minimum'=>1)));
        $c[self::OPCAO]=F3Base_Conversas::catalogo_grupo(self::OPCAO,'Primeira resposta da equipe',self::padroes(),$props,static function($v){$s=get_option('f3base_pipedrive_estado',array());$active=array_column(array_filter($s['catalogos']['usuarios']??array(),static fn($u)=>!empty($u['active_flag'])),'id');foreach($v['pipedrive_usuarios_humanos']??array() as $id){if(!in_array($id,array_map('intval',$active),true)||(int)($s['usuario_id']??0)===$id){return 'Selecione usuários ativos da equipe, distintos do usuário de integração.';}}return '';});
        $c[self::OPCAO]['descricao']='Instante e fonte da primeira resposta observada, sem texto. Slack exige users:read e histórico da thread; Pipedrive exige usuários humanos explicitamente selecionados, diferentes da integração.';return $c;
    }
    public static function iniciar(): void {
        add_action(self::HOOK,static function(){try{return self::processar();}finally{if(self::config()['ativo']){F3Base_Fila::agendar(self::HOOK,time()+300);}}});
        add_action('init',static function(){if(self::config()['ativo']&&!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}},96);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('contato-primeira-resposta-atualizar','Consultar resposta da equipe; padrão simulado; guarda somente instante e fonte',array(__CLASS__,'atualizar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'simular'=>array('type'=>'boolean','default'=>true)),array('record_id'),false);});
    }
    private static function mudar(string $id,callable $fn): bool {
        global $wpdb;for($i=0;$i<3;$i++){$r=$wpdb->get_row($wpdb->prepare("SELECT dados FROM %i WHERE record_id=%s AND captura='aceito' AND lixeira=0 AND eliminacao_pendente=0",F3Base_Leads_Repositorio::tabela(),$id),ARRAY_A);if(!$r){return false;}$d=json_decode($r['dados'],true);if(!is_array($d)){return false;}$new=$fn($d);if($new===$d){return true;}$n=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($new)),array('record_id'=>$id,'dados'=>$r['dados'],'eliminacao_pendente'=>0,'lixeira'=>0,'captura'=>'aceito'));if($n===1){return true;}if($n===false){return false;}}return false;
    }
    public static function registrar(array $lead,int $at,string $source,bool $atividade=false): bool {
        $start=strtotime($lead['criado_em'].' UTC');if($at<$start||$at>time()+60||!in_array($source,array('slack','pipedrive_nota','pipedrive_atividade','pipedrive_email'),true)){return false;}
        return self::mudar($lead['record_id'],static function($d)use($at,$source,$atividade){$old=$d['primeira_resposta']['em']??PHP_INT_MAX;if($at<$old){$d['primeira_resposta']=array('em'=>$at,'fonte'=>str_starts_with($source,'pipedrive_')?'pipedrive':'slack','tipo'=>$source);}
            if($atividade&&$at<(int)($d['primeira_atividade_concluida_em']??PHP_INT_MAX)){$d['primeira_atividade_concluida_em']=$at;}return $d;});
    }
    public static function humano_slack(array $m,array $u,string $team,string $root): bool {
        return ($m['ts']??'')!==$root&&($m['thread_ts']??'')===$root&&empty($m['bot_id'])&&empty($m['app_id'])&&empty($m['subtype'])&&($u['id']??'')===($m['user']??'')&&($u['team_id']??'')===$team&&($u['is_bot']??null)===false&&($u['is_app_user']??null)===false&&($u['deleted']??null)===false&&($u['is_restricted']??null)===false&&($u['is_ultra_restricted']??null)===false;
    }
    public static function slack(array $lead,array $state): array {
        $page=F3Base_Slack_Manutencao::respostas_da_equipe($lead['record_id'],(string)($state['cursor']??''));if(empty($page['ok'])){return self::restante_ms()<1000?self::pendente($state):array_merge($state,array('codigo'=>$page['codigo']??'slack_indisponivel','em'=>time()));}
        $resume=(string)($state['apos_ts']??'');$last=$resume;$lookups=0;
        usort($page['messages'],static fn($a,$b)=>(float)$a['ts']<=>(float)$b['ts']);
        foreach($page['messages'] as $m){if($resume!==''&&(float)$m['ts']<=(float)$resume){continue;}if(empty($m['user'])||!empty($m['bot_id'])||($m['ts']??'')===$page['root_ts']){continue;}$key=$page['team_id'].'|'.$m['user'];if(!isset(self::$users[$key])){if($lookups>=2||self::restante_ms()<1000){return self::pendente(array_merge($state,array('cursor'=>$state['cursor']??'','apos_ts'=>$last)));}$lookups++;$user=F3Base_Slack::api('users.info',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('user'=>$m['user']));if(empty($user['ok'])){return self::restante_ms()<1000?self::pendente(array_merge($state,array('apos_ts'=>$last))):array_merge($state,array('codigo'=>$user['codigo'],'em'=>time()));}self::$users[$key]=$user['user'];}
            if(self::humano_slack($m,self::$users[$key],$page['team_id'],$page['root_ts'])){if(!self::registrar($lead,(int)(float)$m['ts'],'slack')){return array('codigo'=>'resposta_nao_persistida','cursor'=>$state['cursor']??'','apos_ts'=>$last,'em'=>time());}}$last=$m['ts'];
        }
        $next=(string)($page['cursor']??'');if(!empty($page['parcial'])&&($next===''||$next===($state['cursor']??''))){return array('codigo'=>'slack_cursor_incompleto','cursor'=>$state['cursor']??'','em'=>time());}
        return array('codigo'=>$next!==''?'paginacao_pendente':'consultada','cursor'=>$next,'em'=>time(),'completa'=>$next==='');
    }
    public static function humano_crm(int $id): bool {
        $s=get_option('f3base_pipedrive_estado',array());if($id<1||$id===(int)($s['usuario_id']??0)||!in_array($id,self::config()['pipedrive_usuarios_humanos'],true)){return false;}
        foreach($s['catalogos']['usuarios']??array() as $u){if((int)$u['id']===$id&&!empty($u['active_flag'])){return true;}}return false;
    }
    public static function interpretar_crm(array $row,string $kind,array $journal,int $automatic=0): ?array {
        if($kind==='email'){$row=$row['data']??$row;$id=(int)($row['user_id']??0);if(!in_array($row['sent_flag']??null,array(true,1,'1'),true)||!in_array($row['sent_from_pipedrive_flag']??null,array(true,1,'1'),true)||!empty($row['draft_flag'])||!empty($row['deleted_flag'])){return null;}$at=F3Base_Desfechos::instante($row['message_time']??null);}
        elseif($kind==='nota'){$id=(int)($row['user_id']??0);if((int)($row['id']??0)===(int)($journal['nota']??0)||str_contains((string)($row['content']??''),'f3base:')){return null;}$at=F3Base_Desfechos::instante($row['add_time']??null);}
        elseif($kind==='atividade'){$id=(int)($row['owner_id']??0);if(empty($row['done'])||(int)($row['id']??0)===$automatic||str_contains((string)($row['note']??''),'f3base:auto-email:')){return null;}$at=F3Base_Desfechos::instante($row['marked_as_done_time']??null);}
        else{return null;}
        return $at&&self::humano_crm($id)?array('em'=>$at,'fonte'=>'pipedrive_'.$kind):null;
    }
    private static function crm(array $lead,array $state): array {
        global $wpdb;$config=F3Base_Options::ler('f3base_pipedrive');if(empty($config['ativo'])||!F3Base_Integracoes::pipedrive_verificado()){return array('codigo'=>'crm_desligado_ou_nao_verificado','em'=>time());}if(!self::config()['pipedrive_usuarios_humanos']){return array('codigo'=>'usuarios_humanos_nao_configurados','em'=>time());}
        $s=get_option('f3base_pipedrive_estado',array());$account=($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??'');$job=$wpdb->get_row($wpdb->prepare("SELECT journal FROM %i WHERE record_id=%s AND conta=%s AND estado NOT IN ('cancelado','cancelando') ORDER BY atualizado_em DESC LIMIT 1",F3Base_Pipedrive_Fila::tabela(),$lead['record_id'],$account),ARRAY_A);$j=json_decode($job['journal']??'',true)?:array();$o=$j['oportunidade']??array();if(!empty($j['qualidade_negocio'])){$o=array('tipo'=>'deal','id'=>$j['qualidade_negocio']);}
        $entity=$o['tipo']??'';$id=(string)($o['id']??'');if(!in_array($entity,array('lead','deal'),true)||!$id){return array('codigo'=>'crm_sem_vinculo','em'=>time());}
        $ctx=hash('sha256',F3Base_Integracoes::identidade_pipedrive().'|'.$entity.'|'.$id.'|'.F3Base_Options::revisao(self::OPCAO));if(($state['contexto']??'')!==$ctx){$state=array('contexto'=>$ctx);}
        $types=$entity==='deal'?array('nota','atividade','email'):array('nota','atividade');$kind=$state['tipo']??'nota';if(!in_array($kind,$types,true)){$kind='nota';}$cursor=$state['cursor']??'';$query=array('limit'=>100);$path='';
        if($kind==='nota'){$path='v1/notes';$query+=array($entity.'_id'=>$id,'start'=>(int)$cursor,'sort'=>'add_time ASC');}
        elseif($kind==='atividade'){$path='v2/activities';$query+=array($entity.'_id'=>$id,'done'=>true,'sort_by'=>'id','sort_direction'=>'asc');if($cursor!==''){$query['cursor']=$cursor;}}
        else{$path='v1/deals/'.$id.'/mailMessages';$query+=array('start'=>(int)$cursor,'include_body'=>0);}
        if(self::restante_ms()<1000){return self::pendente($state);}$r=F3Base_Pipedrive_Api::pedir('GET',$path,$query);if(empty($r['ok'])){return self::restante_ms()<1000?self::pendente($state):array_merge($state,array('codigo'=>$r['codigo']??'crm_consulta_falhou','em'=>time()));}
        $rows=$r['data']['items']??$r['data'];if(!is_array($rows)||!array_is_list($rows)){return array_merge($state,array('codigo'=>'crm_resposta_incompleta','em'=>time()));}
        $automatic=(int)$wpdb->get_var($wpdb->prepare('SELECT atividade_id FROM %i WHERE record_id=%s AND atividade_id>0 ORDER BY enviado_em LIMIT 1',$wpdb->prefix.'f3base_email_novo_lead',$lead['record_id']));
        foreach($rows as $row){$e=self::interpretar_crm($row,$kind,$j,$automatic);if($e){if(!self::registrar($lead,$e['em'],$e['fonte'],$kind==='atividade')){return array_merge($state,array('codigo'=>'resposta_nao_persistida','em'=>time()));}}}
        $p=$r['additional_data']['pagination']??array();$next=$kind==='atividade'?($r['additional_data']['next_cursor']??''):(!empty($p['more_items_in_collection'])?($p['next_start']??null):'');
        if($next===null||($next!==''&&(string)$next===(string)$cursor)){return array_merge($state,array('codigo'=>'crm_cursor_incompleto','em'=>time()));}
        $complete=false;if($next===''){$i=array_search($kind,$types,true);$kind=$types[($i+1)%count($types)];$complete=$i===count($types)-1;}
        return array('contexto'=>$ctx,'tipo'=>$kind,'cursor'=>$next,'codigo'=>$complete?'consultada':'paginacao_pendente','em'=>time(),'completa'=>$complete,'email_cobertura'=>$entity==='deal'?'emails_enviados_pelo_pipedrive':'indisponivel_para_lead_sem_negocio');
    }
    private static function observar(array $lead): array {
        $s=$lead['dados']['resposta_observacao']??array();self::$prazo=microtime(true)+min(20000,F3Base_Execucoes::restante_ms())/1000;
        // A direct admin call has the same finite budget as a worker. Hooks live only for this observation.
        $args=static function($v){$v['timeout']=max(0.001,min((float)($v['timeout']??8),self::restante_ms()/1000));return $v;};
        $deny=static fn($pre)=>self::restante_ms()<1000?new WP_Error('f3base_orcamento_esgotado','Observação aguardando próxima passagem.'):$pre;
        add_filter('http_request_args',$args,PHP_INT_MAX);add_filter('pre_http_request',$deny,PHP_INT_MAX);
        try{
            // Resume the older source first so a large Slack thread cannot starve CRM observations.
            $order=((int)($s['slack']['em']??0)<=(int)($s['pipedrive']['em']??0))?array('slack','pipedrive'):array('pipedrive','slack');$observed=array();
            foreach($order as $source){$state=$s[$source]??array();$observed[$source]=self::restante_ms()<1000?self::pendente($state):($source==='slack'?self::slack($lead,$state):F3Base_Pipedrive_Api::com_consumidor('qualidade',static fn()=>self::crm($lead,$state)));}
            $pending=(bool)array_filter($observed,static fn($r)=>($r['codigo']??'')==='paginacao_pendente');
            $ok=self::mudar($lead['record_id'],static function($d)use($observed,$pending){$d['resposta_observacao']=$observed+array('em'=>time(),'proxima'=>time()+($pending?60:3600));return $d;});$fresh=F3Base_Leads_Repositorio::obter($lead['record_id']);
            return array('ok'=>$ok,'primeira_resposta'=>$fresh['dados']['primeira_resposta']??null,'primeira_atividade_concluida_em'=>$fresh['dados']['primeira_atividade_concluida_em']??null,'observacao'=>$fresh['dados']['resposta_observacao']??null);
        }finally{remove_filter('http_request_args',$args,PHP_INT_MAX);remove_filter('pre_http_request',$deny,PHP_INT_MAX);self::$prazo=0;}
    }
    public static function atualizar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$lead=F3Base_Leads_Repositorio::obter((string)($e['record_id']??''));if(!$lead||$lead['captura']!=='aceito'||$lead['lixeira']||$lead['eliminacao_pendente']){return array('ok'=>false,'codigo'=>'contato_indisponivel');}
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'primeira_resposta'=>$lead['dados']['primeira_resposta']??null,'efeito'=>'Leitura de thread, autor e registros vinculados no CRM; persiste somente instantes, fonte e estado da paginação.');}
        F3Base_Pipedrive_Api::iniciar_lote();return self::observar($lead);
    }
    public static function processar(): array {
        global $wpdb;if(!self::config()['ativo']){return array('ok'=>true,'codigo'=>'observacao_desligada');}$l=F3Base_Trava::adquirir('primeira-resposta-worker',120);if(!$l){return array('ok'=>false,'codigo'=>'observacao_ocupada');}
        try{$rows=$wpdb->get_col($wpdb->prepare("SELECT record_id FROM %i WHERE captura='aceito' AND lixeira=0 AND eliminacao_pendente=0 AND criado_em>=%s AND COALESCE(JSON_EXTRACT(dados,'$.resposta_observacao.proxima'),JSON_EXTRACT(dados,'$.resposta_observacao.em')+3600,0)<=%d ORDER BY COALESCE(JSON_EXTRACT(dados,'$.resposta_observacao.em'),0),id LIMIT 1",F3Base_Leads_Repositorio::tabela(),gmdate('Y-m-d H:i:s',time()-self::config()['janela_dias']*DAY_IN_SECONDS),time()));F3Base_Pipedrive_Api::iniciar_lote();$out=array();foreach($rows as $id){$lead=F3Base_Leads_Repositorio::obter($id);if($lead){$out[]=self::observar($lead);}}return array('ok'=>!array_filter($out,static fn($r)=>empty($r['ok'])),'consultados'=>count($out));}finally{F3Base_Trava::liberar($l);}
    }
    public static function relatorio(array $leads): array {
        $groups=array();foreach($leads as $l){$d=is_array($l['dados'])?$l['dados']:json_decode($l['dados'],true);$a=F3Base_Atribuicao::normalizar($d['atribuicao']??array());$dim=array('plataforma'=>$a['plataforma'],'conta_id'=>$a['conta_id'],'campanha_id'=>$a['campanha_id'],'campanha'=>$a['utm_campaign'])+F3Base_Desfechos::dimensoes_comerciais($l);$k=wp_json_encode($dim);$groups[$k]=$groups[$k]??$dim+array('registros'=>0,'amostras'=>array(),'primeiras_atividades_concluidas'=>0);$g=&$groups[$k];$g['registros']++;if(!empty($d['primeira_resposta']['em'])){$g['amostras'][]=max(0,$d['primeira_resposta']['em']-strtotime($l['criado_em'].' UTC'));}if(!empty($d['primeira_atividade_concluida_em'])){$g['primeiras_atividades_concluidas']++;}unset($g);}
        foreach($groups as &$g){$v=$g['amostras'];sort($v,SORT_NUMERIC);$n=count($v);$g['respostas_observadas']=$n;$g['sem_resposta_observada']=$g['registros']-$n;$g['mediana_segundos']=$n?($v[(int)floor(($n-1)/2)]+$v[(int)ceil(($n-1)/2)])/2:null;$g['p75_segundos']=$n?$v[(int)ceil($n*.75)-1]:null;unset($g['amostras']);}unset($g);return array('linhas'=>array_values($groups),'tempo'=>'Segundos corridos; p75 por posição mais próxima. Ausência de observação não comprova ausência de atendimento.','limite'=>'Slack: membro ativo do workspace, sem bots/convidados. CRM: usuários declarados, excluindo integração e artefatos automáticos conhecidos; a API não prova ação manual fora desses sinais.');
    }
}
