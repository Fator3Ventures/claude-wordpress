<?php
/** Server-owned definitions and validation. No CF7 dependency. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Formularios {
    public static function estilo(): void {
        if(!wp_style_is('f3base-formularios','registered')){
            wp_register_style('f3base-formularios',false,array(),F3BASE_PLUGIN_VERSAO);
            wp_add_inline_style('f3base-formularios',(string)file_get_contents(F3BASE_PLUGIN_DIR.'assets/f3base-formularios.css'));
        }
        wp_enqueue_style('f3base-formularios');
    }

	private static bool $estilo_impresso = false;
	const TIPOS                          = array( 'text', 'email', 'tel', 'textarea', 'select', 'radio', 'checkbox', 'url', 'file', 'static' );
    public const MENSAGENS=array('baixar_conteudo'=>'Baixar conteúdo','complemento_nao_confirmado'=>'Seu contato foi registrado, mas as informações adicionais ainda não foram confirmadas. Você pode continuar no WhatsApp ou tentar novamente.','complemento'=>'Informações adicionais registradas.','complemento_pulado'=>'Contato registrado. Você pode continuar.','concluir'=>'Concluir e continuar','pular'=>'Pular e continuar','enviando'=>'Enviando…','sucesso'=>'Obrigado. Seu contato foi registrado.','validacao'=>'Confira os campos destacados.','arquivo_limite'=>'O arquivo ou o envio excede o limite permitido.','token_indisponivel'=>'Não foi possível preparar o envio. Tente novamente.','conexao'=>'Falha de conexão. Tente novamente.','nao_confirmado'=>'O envio ainda não foi confirmado. Tente novamente.','falha'=>'Não foi possível receber o envio. Tente novamente.','novo_envio'=>'Novo envio','continuar_whatsapp'=>'Continuar no WhatsApp');
    /** A captura e o complemento resolvem o mesmo destino, conservando o CTA validado. */
    public static function conversa(array $f,array $lead,array $campos=array()): string {
        $dest=self::destino_whatsapp((string)($lead['dados']['cta_origem']['destino']??''));
        if($dest!==''){return $dest;}
        $cfg=F3Base_Options::ler('f3base_contato');
        return 'https://wa.me/'.(!empty($f['whatsapp'])?$f['whatsapp']:($cfg['whatsapp_e164']??'')).'?text='.rawurlencode(self::texto_whatsapp($f,$campos,$cfg));
    }
    public static function destino_whatsapp(string $url): string {
        if(F3Base_Leads_Contexto::destino($url)['tipo']!=='whatsapp'){return '';}$p=wp_parse_url($url);parse_str($p['query']??'',$q);$safe=array();if(($p['host']??'')==='api.whatsapp.com'){$safe['phone']=$q['phone'];}if(isset($q['text'])&&is_string($q['text'])){$safe['text']=mb_substr(sanitize_textarea_field($q['text']),0,2000);}return 'https://'.$p['host'].$p['path'].($safe?'?'.http_build_query($safe,'','&',PHP_QUERY_RFC3986):'');
    }
    public static function mensagens(array $f): array {
        $r=self::MENSAGENS;if(!empty($f['confirmacao'])){$r['sucesso']=$f['confirmacao'];}
        foreach($f['mensagens']??array() as $k=>$v){if(isset($r[$k])&&is_string($v)&&trim($v)!==''){$r[$k]=sanitize_text_field($v);}}return $r;
    }
    public static function schema_mensagens(): array {
        return array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array_keys(self::MENSAGENS),array('type'=>'string','maxLength'=>1000)));
    }
	public static function schema(): array {
		return array(
			'type'     => 'array',
			'maxItems' => 100,
			'items'    => array(
				'type'                 => 'object',
				'required'             => array( 'id', 'titulo', 'campos' ),
				'properties'           => array(
					'id'            => array(
						'type'    => 'string',
						'pattern' => '^[a-z][a-z0-9_-]{0,79}$',
					),
					'titulo'        => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
					'exigir_um_de'=>array('type'=>'array','maxItems'=>10,'uniqueItems'=>true,'items'=>array('type'=>'string')),
                    'mensagem_exigir_um_de'=>array('type'=>'string','maxLength'=>300),
                    'etapa2_apresentacao'=>array('type'=>'string','enum'=>array('inline','dialogo')),'mostrar_pular'=>array('type'=>'boolean'),
                    'whatsapp_nova_aba'=>array('type'=>'boolean','default'=>true),
                    'whatsapp_campos'=>array('type'=>'array','uniqueItems'=>true,'items'=>array('type'=>'string')),
                    'pipedrive_sem_nome'=>array('type'=>'string','enum'=>array('herdar','recusar','enviar')),'pipedrive'=>array('type'=>'boolean'),'mensagem_whatsapp'=>array('type'=>'string','maxLength'=>2000),'whatsapp_automatico'=>array('type'=>'boolean'),
                    'servico_fixo'=>array('type'=>'string','maxLength'=>200),
                    'resposta_visitante' => F3Base_Resposta_Visitante::schema(),
					'regime'        => array(
						'type' => 'string',
						'enum' => array( 'registro', 'whatsapp', 'conteudo' ),
					),
					'ativo'         => array(
						'type'    => 'string',
						'pattern' => '^[a-f0-9]{32}$',
					),
					'validade_dias' => array(
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 365,
					),
					'quota'         => array(
						'type'    => 'integer',
						'minimum' => 1,
						'maximum' => 1000,
					),
					'mensagens' => self::schema_mensagens(),
                    'confirmacao_url'=>array('type'=>'string','maxLength'=>2048),
                    'confirmacao'   => array(
						'type'      => 'string',
						'maxLength' => 10000,
					),
					'assunto'       => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
					'destinatarios' => array(
						'type'     => 'array',
						'maxItems' => 5,
						'items'    => array(
							'type'   => 'string',
							'format' => 'email',
						),
					),
					'whatsapp'      => array(
						'type'    => 'string',
						'pattern' => '^[0-9]{10,15}$',
					),
					'botao'         => array(
						'type'      => 'string',
						'maxLength' => 100,
					),
					'ligado'        => array( 'type' => 'boolean' ),
					'campos'        => array(
						'type'     => 'array',
						'minItems' => 1,
						'maxItems' => 100,
						'items'    => array(
							'type'                 => 'object',
							'required'             => array( 'nome', 'tipo', 'rotulo' ),
							'additionalProperties' => false,
							'properties'           => array(
								'nome'         => array(
									'type'    => 'string',
									'pattern' => '^[a-z][a-z0-9_-]{0,79}$',
								),
								'tipo'         => array(
									'type' => 'string',
									'enum' => self::TIPOS,
								),
								'rotulo'       => array(
									'type'      => 'string',
									'maxLength' => 200,
								),
								'etapa'=>array('type'=>'integer','enum'=>array(1,2),'default'=>1),
                                'obrigatorio'  => array( 'type' => 'boolean' ),
                                'formato_livre'=>array('type'=>'boolean','default'=>false,'description'=>'Somente papel telefone: aceita o valor digitado e registra a normalização sem impedir o envio por formato.'),
								'ajuda'        => array(
									'type'      => 'string',
									'maxLength' => 1000,
								),
								'opcoes'       => array(
									'type'     => 'array',
									'maxItems' => 100,
									'items'    => array(
										'type'      => 'string',
										'maxLength' => 500,
									),
								),
								'padrao'       => array(
									'type'      => 'string',
									'maxLength' => 1000,
								),
								'placeholder'  => array(
									'type'      => 'string',
									'maxLength' => 200,
								),
								'autocomplete' => array(
									'type'      => 'string',
									'maxLength' => 100,
								),
								'largura'      => array(
									'type' => 'integer',
									'enum' => array( 50, 100 ),
								),
								'papel'        => array(
									'type' => 'string',
									'enum' => array( 'nome', 'email', 'telefone', 'contato', 'mensagem', 'empresa', 'cargo', 'servico', 'linkedin', 'outro' ),
								),
								'html'         => array(
									'type'      => 'string',
									'maxLength' => 10000,
								),
								'limites_exibicao'=>array('type'=>'string','enum'=>array('automatico','oculto','personalizado')),'limites_texto'=>array('type'=>'string','maxLength'=>500),
                                'max_bytes'    => array(
									'type'    => 'integer',
									'minimum' => 0,
								),
								'extensoes'    => array(
									'type'  => 'array',
									'items' => array(
										'type'    => 'string',
										'pattern' => '^[a-z0-9]+$',
									),
								),
								'max_arquivos' => array(
									'type'    => 'integer',
									'minimum' => 1,
									'maximum' => 5,
								),
							),
						),
					),
				),
				'additionalProperties' => false,
			),
		);
	}
	public static function recusar( $v ): string {
		$r = rest_validate_value_from_schema( $v, self::schema(), 'formularios' );
		if ( is_wp_error( $r ) ) {
			return $r->get_error_message(); }
		$ids = array();
		foreach ( $v as $f ) {
            if(!empty($f['confirmacao_url'])&&!F3Base_Confirmacao::normalizar($f['confirmacao_url'])){return 'URL de confirmação inválida ou host externo não autorizado.';}
			if ( isset( $ids[ $f['id'] ] ) ) {
				return 'ID de formulário repetido.';
			} $ids[ $f['id'] ] = true;
			$nomes             = array();
			$papeis            = array();
			foreach ( $f['campos'] as $c ) {
				if ( isset( $nomes[ $c['nome'] ] ) ) {
					return 'Nome de campo repetido.';
				} $nomes[ $c['nome'] ] = true;
				if ( in_array( $c['tipo'], array( 'select', 'radio', 'checkbox' ), true ) && empty( $c['opcoes'] ) ) {
					return 'Campo de escolha precisa de opções.'; }
				if ( isset( $c['papel'] ) && 'outro' !== $c['papel'] ) {
					if ( isset( $papeis[ $c['papel'] ] ) ) {
						return 'Papel de campo repetido.';
					} $papeis[ $c['papel'] ] = $c['tipo']; }
				if(($c['papel']??'')==='contato'&&$c['tipo']!=='text'){return 'Papel contato exige tipo text: celular ou e-mail, sem validação de formato no envio.';}
				if('servico'===($c['papel']??'')&&!in_array($c['tipo'],array('select','radio','checkbox'),true)){return 'Papel serviço exige select, radio ou checkbox.';}
                if ( 'email' === ( $c['papel'] ?? '' ) && 'email' !== $c['tipo'] ) {
					return 'Papel email exige tipo email.'; }
			}
            $defs=array_column($f['campos'],null,'nome');
            foreach($f['campos'] as $campo){if(!empty($campo['formato_livre'])&&(($campo['papel']??'')!=='telefone'||($campo['tipo']??'')!=='tel')){return 'Formato livre só pode ser ligado em campo de telefone, do tipo tel.';}}
            foreach($f['exigir_um_de']??array() as $name){$c=$defs[$name]??null;if(!$c||(!in_array($c['tipo'],array('email','tel'),true)&&($c['papel']??'')!=='contato')||(int)($c['etapa']??1)!==1){return 'O grupo deve referenciar e-mail, telefone ou contato existentes na etapa 1.';}if(!empty($c['obrigatorio'])){return 'Os campos do grupo não devem ser individualmente obrigatórios.';}}
            foreach($f['whatsapp_campos']??array() as $name){if(!isset($defs[$name])||in_array($defs[$name]['tipo'],array('file','static'),true)){return 'Texto do WhatsApp aceita somente campos visíveis sem anexos.';}}
            foreach($f['campos'] as $c){if((int)($c['etapa']??1)===2&&in_array($c['papel']??'',array('nome','email','telefone','contato'),true)){return 'Identificação deve estar na etapa 1; a etapa 2 complementa o contato.';}}
            if(($f['regime']??'')==='conteudo'&&self::tem_complemento($f)){return 'Conteúdo privado usa uma etapa; a concessão depende do formulário completo.';}
			$erro_resposta = F3Base_Resposta_Visitante::validar( $f );
			if ( $erro_resposta ) { return $erro_resposta; }
			if ( 'conteudo' === ( $f['regime'] ?? 'registro' ) && ( empty( $f['ativo'] ) || ! isset( $papeis['email'] ) || ! array_filter( $f['campos'], static fn( $c )=>'email' === ( $c['papel'] ?? '' ) && ! empty( $c['obrigatorio'] ) ) ) ) {
				return 'Conteúdo exige ativo privado e campo email.'; }
			if ( 'whatsapp' === ( $f['regime'] ?? 'registro' ) && empty( $f['whatsapp'] ) && empty( F3Base_Options::ler( 'f3base_contato' )['whatsapp_e164'] ) ) {
				return 'Regime WhatsApp exige número de destino.'; }
			foreach ( array( 'assunto', 'titulo' ) as $k ) {
				if ( preg_match( '/[\r\n]/', $f[ $k ] ?? '' ) ) {
					return 'Título e assunto não aceitam quebras.'; }
			}
		}
		foreach ( (array) get_option( 'f3base_formularios', array() ) as $anterior ) {
			if ( ! isset( $ids[ $anterior['id'] ?? '' ] ) && self::referencias( (string) ( $anterior['id'] ?? '' ) ) ) {
				return 'Definição ainda referenciada: ' . $anterior['id'] . '. Retire a publicação explicitamente ou migre as referências antes de remover.'; }
		}
		return '';
	}
    public static function referencias(string $id): array {
        static $cache=null,$versao='';global $wpdb;$atual=wp_cache_get_last_changed('posts');
        if($cache===null||$versao!==$atual){
            $cache=array();$versao=$atual;
            $rows=$wpdb->get_results($wpdb->prepare("SELECT ID,post_title,post_type,post_content FROM {$wpdb->posts} WHERE post_type NOT IN ('revision','attachment') AND (post_content LIKE %s OR post_content LIKE %s) ORDER BY ID LIMIT 1001",'%f3base_formulario%','%f3base/formulario%'),ARRAY_A);
            foreach($rows as $row){$ids=array();$walk=static function($blocks)use(&$walk,&$ids){foreach($blocks as $block){if(($block['blockName']??'')==='f3base/formulario'&&is_string($block['attrs']['id']??null)){$ids[$block['attrs']['id']]=true;}$walk($block['innerBlocks']??array());}};$walk(parse_blocks($row['post_content']));
                if(preg_match_all('/'.get_shortcode_regex(array('f3base_formulario')).'/s',$row['post_content'],$matches,PREG_SET_ORDER)){foreach($matches as $m){if($m[1]==='['&&$m[6]===']'){continue;}$a=shortcode_parse_atts($m[3]);if(is_array($a)&&is_string($a['id']??null)){$ids[$a['id']]=true;}}}
                unset($row['post_content']);foreach($ids as $key=>$yes){$cache[$key][]=$row;}
            }
            if(count($rows)>1000||$wpdb->last_error){$cache['__incompleto']=true;}
        }
        $r=$cache[$id]??array();if(!empty($cache['__incompleto'])){$r[]=array('ID'=>0,'post_title'=>'Leitura de usos incompleta; revise as referências antes de remover.','post_type'=>'inconclusivo');}return $r;
    }

	public static function obter( string $id ): ?array {
		foreach ( (array) F3Base_Options::ler( 'f3base_formularios' ) as $f ) {
			if ( ( $f['id'] ?? '' ) === $id && ( $f['ligado'] ?? true ) ) {
				return $f;
			}
		} return null; }
	public static function revisao( array $f ): string {
		return F3Base_Leads_Repositorio::hash( $f ); }
	public static function iniciar(): void {
        add_action('wp_enqueue_scripts',static function(){if(F3Base_Options::ler('f3base_formularios')){self::estilo();}},0);
		add_action( 'init', array( __CLASS__, 'registrar' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'rotas' ) );
		add_action( 'admin_post_f3base_formulario', array( __CLASS__, 'post' ) );
		add_action( 'admin_post_nopriv_f3base_formulario', array( __CLASS__, 'post' ) );
		add_action( 'admin_post_f3base_confirmacao', array( __CLASS__, 'confirmacao' ) );
		add_action( 'admin_post_nopriv_f3base_confirmacao', array( __CLASS__, 'confirmacao' ) );
	}
    public static function texto_whatsapp(array $f,array $valores,array $cfg): string {
        $intro=trim((string)($f['mensagem_whatsapp']??''));if($intro===''){$intro=trim((string)($cfg['mensagem_padrao']??''));}
        $linhas=$intro!==''?array($intro):array();
        foreach($f['campos']??array() as $campo){if(!in_array($campo['nome'],$f['whatsapp_campos']??array(),true)){continue;}$v=$valores[$campo['nome']]??null;if(is_array($v)){$v=implode(', ',array_filter($v,static fn($x)=>is_scalar($x)&&trim((string)$x)!==''));}if(!is_scalar($v)||trim((string)$v)===''||($campo['tipo']??'')==='file'){continue;}$linhas[]=($campo['rotulo']??$campo['nome']).': '.trim((string)$v);}
        return implode("\n",$linhas);
    }
	public static function registrar(): void {
		add_shortcode( 'f3base_formulario', static fn( $a )=>self::renderizar( array( 'id' => (string) ( $a['id'] ?? '' ), 'secao'=>(string)($a['secao']??'') ) ) );
		register_block_type(
			'f3base/formulario',
			array(
				'api_version'     => 3,
				'attributes'      => array( 'id' => array( 'type' => 'string' ), 'secao'=>array('type'=>'string') ),
				'render_callback' => array( __CLASS__, 'renderizar' ),
			)
		);
	}
	public static function emitir( array $f, string $sid, int $pagina, bool $interacao = false ): string {
		$data = base64_encode( // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Encodes a typed cursor or HMAC payload, not executable code.
			wp_json_encode(
				array(
					'f'         => $f['id'],
					'r'         => self::revisao( $f ),
					'p'         => $pagina,
					't'         => $interacao ? time() : (int) floor( time() / HOUR_IN_SECONDS ) * HOUR_IN_SECONDS,
					'interacao' => $interacao,
				)
			)
		);
		return $data . '.' . hash_hmac( 'sha256', 'formulario|' . $data, wp_salt( 'nonce' ) );
	}
	public static function token( string $token, bool $vigente=true ): ?array {
		$partes = explode( '.', $token );
		if ( count( $partes ) !== 2 || ! hash_equals( hash_hmac( 'sha256', 'formulario|' . $partes[0], wp_salt( 'nonce' ) ), $partes[1] ) ) {
			return null; }
		$d = json_decode( (string) base64_decode( $partes[0], true ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decodes a typed pagination or signed form payload, never PHP or executable code.
		return is_array( $d ) && isset( $d['t'], $d['f'], $d['r'], $d['p'] ) && is_int( $d['t'] ) && $d['t'] <= time() && (!$vigente || $d['t'] >= time() - 2 * HOUR_IN_SECONDS) ? $d : null;
	}
    public static function tem_complemento(array $f): bool {return (bool)array_filter($f['campos']??array(),static fn($c)=>(int)($c['etapa']??1)===2);}
    public static function etapa(array $f,int $etapa): array {$f['campos']=array_values(array_filter($f['campos'],static fn($c)=>(int)($c['etapa']??1)===$etapa));if($etapa===2){unset($f['exigir_um_de']);}return $f;}
	/**
	 * Parâmetro textual de rota pública: lista ou objeto vira texto vazio (1.49.0).
	 * Antes, `formulario[]=…` produzia "Array to string conversion" no log a cada robô.
	 */
	public static function parametro_texto( WP_REST_Request $req, string $nome ): string {
		$v = $req->get_param( $nome );
		return is_scalar( $v ) ? (string) $v : '';
	}
	public static function rotas(): void {
        register_rest_route(F3BASE_REST_NAMESPACE,'/formularios/complementar',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>static function(WP_REST_Request $req){$r=F3Base_Formulario_Complementos::receber($req->get_body_params(),$req->get_file_params());return self::resposta($r,$r['http']??(!empty($r['ok'])?200:400));}));
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/formularios/token',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => static function ( WP_REST_Request $req ) {
					$f = self::obter( self::parametro_texto( $req, 'formulario' ) );
					$p = (int) $req->get_param( 'pagina' );
					if ( ! $f || ! self::limite( 'token', 60 ) ) {
						return self::resposta(
							array(
								'ok'     => false,
								'codigo' => 'token_indisponivel',
							),
							429
						); }
					$sid = self::parametro_texto( $req, 'submissao' );
					if ( ! preg_match( '/^[a-f0-9]{32}$/D', $sid ) ) {
						$sid = bin2hex( random_bytes( 16 ) ); }
					return self::resposta(
						array(
							'ok'        => true,
							'token'     => self::emitir( $f, $sid, $p, true ),
							'submissao' => $sid,
							'revisao'   => self::revisao( $f ),
						),
						200
					);
				},
			)
		);
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			'/formularios/enviar',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => static function ( WP_REST_Request $req ) {
					$r = self::receber( $req->get_body_params(), $req->get_file_params() );
					return self::resposta( $r, $r['http'] ?? ( $r['ok'] ? 201 : 400 ) );
				},
			)
		);
	}
	public static function resposta( array $r, int $status ): WP_REST_Response {
		$res = new WP_REST_Response( $r, $status );
		$res->header( 'Cache-Control', 'private, no-store, max-age=0' );
		$res->header( 'X-Robots-Tag', 'noindex, nofollow' );
		return $res; }
	public static function limite( string $tipo, int $max ): bool {
		$origem = F3Base_Modulo_Endpoint_Leads::origem();
		$hash   = hash_hmac( 'sha256', wp_json_encode( $origem ), wp_salt( 'auth' ) );
		$janela = (int) floor( time() / 600 );
		return F3Base_Leads_Repositorio::quota( 'form:' . $tipo . ':' . $hash . ':' . $janela, $max, ( $janela + 2 ) * 600 );
	}
	public static function renderizar( array $a ): string {
		$f = self::obter( (string) ( $a['id'] ?? '' ) );
		if ( ! $f ) {
			return current_user_can( 'manage_options' ) ? '<p>Formulário Core indisponível.</p>' : ''; }
		return self::renderizar_definicao( $f, (string)($a['secao']??'') );
	}
	public static function renderizar_definicao( array $f, string $secao='' ): string {
		// All HTML is shared: HMAC covers form, definition, page and a time window, never a visitor.
		F3Base_Atribuicao::enfileirar();
		wp_enqueue_script(
			'f3base-formularios',
			F3BASE_PLUGIN_URL . 'assets/f3base-formularios.min.js',
			array( 'f3base-contexto' ),
			F3BASE_PLUGIN_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		$style = '';
        self::estilo();
		// The existing channel owns consent, conversion destinations and deduplication.
		$leads = new F3Base_Modulo_Leads_Whatsapp();
		$leads->enfileirar( true );
		$sid  = '';
		$page = (int) get_queried_object_id();
		$uid  = wp_unique_id( 'f3f-' );
		$h    = $style . '<form data-analise-prova="'.esc_attr(F3Base_Analise::prova_formulario($f)).'" data-tentativas-valores="'.(!empty(F3Base_Options::ler(F3Base_Formulario_Tentativas::OPTION)['capturar_valores'])?'1':'0').'" data-ga4="'.esc_attr((string)F3Base_Options::ler('f3base_ga4_measurement_id')).'" data-etapa2-apresentacao="'.esc_attr($f['etapa2_apresentacao']??'inline').'" data-mostrar-pular="'.(($f['mostrar_pular']??true)?'1':'0').'" data-mensagens="'.esc_attr(wp_json_encode(self::mensagens($f))).'" data-post-max-bytes="'.(int)wp_convert_hr_to_bytes(ini_get('post_max_size')).'" data-max-file-uploads="'.(int)ini_get('max_file_uploads').'" data-regime="'.esc_attr($f['regime']??'registro').'" data-whatsapp-nova-aba="'.(($f['whatsapp_nova_aba']??true)?'1':'0').'" data-pais-telefone="'.esc_attr(F3Base_Options::ler('f3base_pipedrive')['pais_telefone']??'BR').'" data-exigir-um-de="'.esc_attr(wp_json_encode($f['exigir_um_de']??array())).'" data-grupo-mensagem="'.esc_attr($f['mensagem_exigir_um_de']??'Informe e-mail ou WhatsApp.').'" class="f3base-formulario'.(preg_match('/^[a-z][a-z0-9_-]{0,79}$/D',$secao)?' f3base-secao-'.esc_attr($secao):'').'" data-whatsapp-automatico="'.(!empty($f['whatsapp_automatico'])?'1':'0').'" data-f3base-formulario="' . esc_attr( $f['id'] ) . '" data-endpoint="' . esc_url( rest_url( F3BASE_REST_NAMESPACE . '/formularios/' ) ) . '" data-revisao="' . esc_attr(self::revisao($f)) . '" data-pagina="' . $page . '" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		foreach ( array(
			'action'     => 'f3base_formulario',
			'formulario' => $f['id'],
			'token'      => self::emitir( $f, $sid, $page ),
			'submissao'  => $sid,
		) as $k => $v ) {
			$h .= '<input type="hidden" name="' . $k . '" value="' . esc_attr( $v ) . '">'; }
		$h .= F3Base_Formulario_Antispam::html();
        if(!empty($f['exigir_um_de'])){$h.='<p id="'.esc_attr($uid).'-grupo" class="f3base-formulario-grupo">'.esc_html($f['mensagem_exigir_um_de']??'Informe e-mail ou WhatsApp.').'</p>';}
		foreach ( $f['campos'] as $c ) {
			$id   = $uid . '-' . $c['nome'];
			$name = 'campos[' . $c['nome'] . ']';
			$tipo = $c['tipo'];
			$h   .= '<div data-etapa="'.(int)($c['etapa']??1).'" class="f3base-campo f3base-campo-' . (int) ( $c['largura'] ?? 100 ) . '">';
			if ( 'static' === $tipo ) {
				$h .= wp_kses(
					$c['html'] ?? '',
					array(
						'p'      => array(),
						'strong' => array(),
						'a'      => array(
							'href' => true,
							'rel'  => true,
						),
					)
				) . '</div>';
				continue; }
			if(!in_array($tipo,array('radio','checkbox'),true)) $h    .= '<label for="' . esc_attr( $id ) . '">' . esc_html( $c['rotulo'] ) . ( ! empty( $c['obrigatorio'] ) ? ' *' : '' ) . '</label>';
			$attrs = ' id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . ( 'checkbox' === $tipo || 'file' === $tipo ? '[]' : '' ) . '"';
			if ( ! empty( $c['obrigatorio'] ) ) {
				$attrs .= ' required'; }
			if ( isset( $c['placeholder'] ) ) {
				$attrs .= ' placeholder="' . esc_attr( $c['placeholder'] ) . '"'; }
			if ( isset( $c['autocomplete'] ) ) {
				$attrs .= ' autocomplete="' . esc_attr( $c['autocomplete'] ) . '"'; }
			if ( isset( $c['ajuda'] ) ) {
				$attrs .= ' aria-describedby="' . esc_attr( $id ) . '-ajuda'.($tipo==='file'&&($c['limites_exibicao']??'automatico')!=='oculto'?' '.esc_attr($id).'-limites':'').'"'; }
			if($tipo==='file'&&!isset($c['ajuda'])&&($c['limites_exibicao']??'automatico')!=='oculto'){$attrs.=' aria-describedby="'.esc_attr($id).'-limites"';}
            if(($c['papel']??'')==='contato'){$attrs.=' data-papel-contato="1"';}
            if(F3Base_Telefone::livre($c)){$attrs.=' data-formato-livre="1"';}
            if(in_array($c['nome'],$f['exigir_um_de']??array(),true)){$attrs=preg_replace('/ aria-describedby="([^"]*)"/',' aria-describedby="$1 '.esc_attr($uid).'-grupo"',$attrs);if(!str_contains($attrs,'aria-describedby')){$attrs.=' aria-describedby="'.esc_attr($uid).'-grupo"';}}
            if ( 'textarea' === $tipo ) {
				$h .= '<textarea' . $attrs . '>' . esc_textarea( $c['padrao'] ?? '' ) . '</textarea>'; } elseif ( 'select' === $tipo ) {
				$h .= '<select' . $attrs . '><option value="">Selecione</option>';
				foreach ( $c['opcoes'] as $o ) {
					$h .= '<option value="' . esc_attr( $o ) . '"' . selected( $c['padrao'] ?? '', $o, false ) . '>' . esc_html( $o ) . '</option>';
				} $h .= '</select>'; } elseif ( in_array( $tipo, array( 'radio', 'checkbox' ), true ) ) {
								$h .= '<fieldset><legend>' . esc_html( $c['rotulo'] ) . '</legend>';
					foreach ( $c['opcoes'] as $i => $o ) {
						$h .= '<label><input type="' . $tipo . '" name="' . esc_attr( $name ) . ( 'checkbox' === $tipo ? '[]' : '' ) . '" value="' . esc_attr( $o ) . '"' . ( 'radio' === $tipo && ! empty( $c['obrigatorio'] ) ? ' required' : '' ) . '> ' . esc_html( $o ) . '</label>';
					} $h .= '</fieldset>';
				} elseif ( 'file' === $tipo ) {
					$lim=F3Base_Arquivos_Privados::politica($c);$php=(int)wp_convert_hr_to_bytes(ini_get('upload_max_filesize'));
                    $teto=$lim['teto_plugin_bytes']===null?$php:($php>0?min($php,$lim['teto_plugin_bytes']):$lim['teto_plugin_bytes']);
                    $h.='<input type="file"'.$attrs.' data-max-bytes="'.$teto.'" data-max-files="'.$lim['max_arquivos_campo'].'"'.($lim['max_arquivos_campo']>1?' multiple':'').'>';
                    $texto='Até '.$lim['max_arquivos_campo'].' arquivo(s). '.($teto>0?'Até '.size_format($teto).' por arquivo. ':'');$post=(int)wp_convert_hr_to_bytes(ini_get('post_max_size'));if($post>0){$texto.='O envio completo, incluindo outros arquivos e campos, deve caber em '.size_format($post).'.';}if(($c['limites_exibicao']??'')==='personalizado'){$texto=$c['limites_texto']??'';}
                    if($lim['extensoes_plugin']){$texto.=' Extensões permitidas no campo: '.implode(', ',$lim['extensoes_plugin']).'.';}
                    if(($c['limites_exibicao']??'automatico')!=='oculto'){$h.='<small id="'.esc_attr($id).'-limites">'.esc_html($texto).'</small>';} } else {
								$h .= '<input type="' . esc_attr( $tipo ) . '"' . $attrs . ' value="' . esc_attr( $c['padrao'] ?? '' ) . '">'; }
					if ( ! empty( $c['ajuda'] ) ) {
						$h .= '<small id="' . esc_attr( $id ) . '-ajuda">' . esc_html( $c['ajuda'] ) . '</small>';
					} $h .= '</div>';
		}
		return $h . '<button type="submit" class="wp-element-button">' . esc_html( $f['botao'] ?? 'Enviar' ) . '</button><div role="status" aria-live="polite" tabindex="-1" data-clarity-mask="true" class="f3base-formulario-resultado"></div></form>';
	}
	private static function erro( string $code, int $http = 400, array $extra = array() ): array {
		return array(
			'ok'        => false,
			'persisted' => false,
			'codigo'    => $code,
			'http'      => $http,
		) + $extra; }
    public static function validar_campos(array $f,$campos,array $files=array()): array {
		$campos = $campos ?? array();
		if ( ! is_array( $campos ) || array_diff( array_keys( $campos ), array_column( $f['campos'], 'nome' ) ) ) {
			return self::erro( 'campos_invalidos' ); }
		$nomes_arquivos = array_column( array_filter( $f['campos'], static fn( $c ) => 'file' === $c['tipo'] ), 'nome' );
		foreach ( (array) ( $files['campos'] ?? array() ) as $parte ) {
			if ( ! is_array( $parte ) || array_diff( array_keys( $parte ), $nomes_arquivos ) ) {
				return self::erro( 'arquivo_desconhecido' ); }
		}
		$limpos  = array();
		$papeis  = array();
		$anexos  = array();
		$uploads = array();
		foreach ( $f['campos'] as $c ) {
			$n    = $c['nome'];
			$tipo = $c['tipo'];
			$v    = $campos[ $n ] ?? ( 'checkbox' === $tipo ? array() : '' );
			if ( 'static' === $tipo ) {
				continue; }
			if ( 'file' === $tipo ) {
				$fs      = $files['campos'] ?? array();
				$errs    = $fs['error'][ $n ] ?? array();
				$errs    = is_array( $errs ) ? $errs : array( $errs );
				$validos = 0;
				foreach ( $errs as $i => $err ) {
					if ( UPLOAD_ERR_NO_FILE === $err ) {
						continue;
					} ++$validos;
					$file = array();
					foreach ( array( 'name', 'tmp_name', 'error', 'size', 'type' ) as $k ) {
						$file[ $k ] = $fs[ $k ][ $n ][ $i ] ?? null; }
					if ( UPLOAD_ERR_OK !== $err ) {
						return self::erro( 'upload_erro_' . $err );
					} $uploads[] = array( $file, $c );
				}
				if ( ( $c['obrigatorio'] ?? false ) && ! $validos ) {
					return self::erro( 'anexo_obrigatorio', 400, array( 'campo' => $n ) ); }
				if ( $validos > (int) ( $c['max_arquivos'] ?? 5 ) ) {
					return self::erro( 'quantidade_de_anexos' );
				} continue;
			}
			if ( 'checkbox' === $tipo ) {
				if ( ! is_array( $v ) || count( array_filter( $v, 'is_string' ) ) !== count( $v ) || array_diff( $v, $c['opcoes'] ) || count( $v ) !== count( array_unique( $v ) ) ) {
					return self::erro( 'escolha_invalida' ); }
				if ( ! empty( $c['obrigatorio'] ) && ! $v ) {
					return self::erro( 'campo_obrigatorio' );
				} $limpos[ $n ] = array_values( $v );if(!empty($c['papel'])){$papeis[$c['papel']]=$limpos[$n];}
				continue;
			}
			if ( ! is_string( $v ) || strlen( $v ) > 20000 ) {
				return self::erro( 'campo_invalido' );
			} $digitado=$v;$v = trim( $v );
			if ( ! empty( $c['obrigatorio'] ) && '' === $v ) {
				return self::erro( 'campo_obrigatorio', 400, array( 'campo' => $n ) ); }
			if($v!==''&&$tipo==='tel'&&!F3Base_Telefone::livre($c)){ $normal=F3Base_Pipedrive_Api::telefone($v);if($normal===''){return self::erro('campo_invalido',400,array('campo'=>$n));}$v=$normal;}
            if ( $v && ( ( 'email' === $tipo && ! is_email( $v ) ) || ( 'url' === $tipo && ! filter_var( $v, FILTER_VALIDATE_URL ) ) || ( in_array( $tipo, array( 'select', 'radio' ), true ) && ! in_array( $v, $c['opcoes'], true ) ) ) ) {
				return self::erro( 'campo_invalido', 400, array( 'campo' => $n ) ); }
			$limpos[ $n ] = (F3Base_Telefone::livre($c)||($c['papel']??'')==='contato')?wp_check_invalid_utf8($digitado):('textarea' === $tipo ? sanitize_textarea_field( $v ) : sanitize_text_field( $v ));
			if ( ! empty( $c['papel'] ) ) {
				$papeis[ $c['papel'] ] = $limpos[ $n ]; }
		}
        $group=$f['exigir_um_de']??array();if($group&&!array_filter($group,static fn($n)=>isset($limpos[$n])&&trim((string)$limpos[$n])!=='')){
            return self::erro('grupo_obrigatorio_nao_atendido',400,array('campos'=>$group,'mensagem'=>$f['mensagem_exigir_um_de']??'Informe e-mail ou WhatsApp.'));
        }
        if(trim((string)($papeis['contato']??''))!==''){$contact=F3Base_Telefone::contato((string)$papeis['contato']);$papeis['email']=$contact['email'];$papeis['telefone']=$contact['telefone'];}
        return array('ok'=>true,'limpos'=>$limpos,'papeis'=>$papeis,'uploads'=>$uploads);
    }
    public static function receber(array $e,array $files=array()): array {
        $r=self::receber_interno($e,$files);
        $f=self::obter(is_string($e['formulario']??null)?$e['formulario']:'');$m=self::mensagens($f??array());
        if(empty($r['ok'])&&!isset($r['mensagem'])){$codigo=(string)($r['codigo']??'');$chave=(str_contains($codigo,'campo')||$codigo==='escolha_invalida')?'validacao':(preg_match('/arquivo|anexo|limite_servidor|limite_do_formulario|upload_erro/',$codigo)?'arquivo_limite':(str_contains($codigo,'token')?'token_indisponivel':'falha'));$r['mensagem']=$m[$chave];}
        return $r;
    }
    private static function receber_interno( array $e, array $files = array() ): array {
        if(isset($e['contexto_teste'])&&in_array($e['contexto_teste'],array('0','1'),true)){$e['contexto_teste']=$e['contexto_teste']==='1';}
        $marca=F3Base_Testes::resolver($e);if(empty($marca['ok'])){return self::erro($marca['codigo']);}
$cota_excedida=!self::limite('envio',20);
		if ( array_diff( array_keys( $e ), array( 'ga4_session_source','ga4_session_started_at','ga4_observed_at','ga4_client_id','ga4_session_id','classificacao_contexto', 'action', 'formulario', 'token', 'submissao', 'campos', 'website', 'ctodesenvolvimentofator3','segmento_atuacao', 'comentario', 'atribuicao', 'sessao', 'navegacao', 'dispositivo', 'largura_janela', 'max_touch_points', 'retorno', 'visitas', 'visitas_minimo', 'visitas_desde', 'contexto_teste', 'audiencia_excluida', 'superficie', 'oferta', 'visitante', 'cta_origem' ) ) ) {
			return self::erro( 'campo_desconhecido' ); }
		if ( array_diff( array_keys( $files ), array( 'campos' ) ) ) {
			return self::erro( 'arquivo_desconhecido' ); }

		$token = is_string( $e['token'] ?? null ) ? self::token( $e['token'], false ) : null;
		$f     = self::obter( is_string( $e['formulario'] ?? null ) ? $e['formulario'] : '' );
        if(!$f){return self::erro('formulario_indisponivel',404);}
        $sinais=array();$token_valido=$token&&$token['f']===$f['id'];
        if(!$token_valido){$sinais[]='token_assinatura_invalida_ou_ausente';$token=array('f'=>$f['id'],'r'=>self::revisao($f),'p'=>0,'t'=>time(),'interacao'=>false);}
        elseif($token['t']<time()-2*HOUR_IN_SECONDS){$sinais[]='token_vencido';}
        if(!hash_equals(self::revisao($f),(string)$token['r'])){$sinais[]='token_revisao_anterior';}
        $tempo_confiavel=$token_valido&&!array_intersect($sinais,array('token_vencido','token_revisao_anterior'))&&!empty($token['interacao']);
        if($tempo_confiavel&&time()-$token['t']<3){$sinais[]='tempo_curto';}
        if($cota_excedida){$sinais[]='cota_excedida';}
		$sid = $e['submissao'] ?? '';
		if ( ! is_string( $sid ) || ( '' !== $sid && ! preg_match( '/^[a-f0-9]{32}$/D', $sid ) ) ) {
			return self::erro( 'submissao_invalida' );
		} $nojs = '' === $sid;
		if ( $nojs ) {
			$sid = bin2hex( random_bytes( 16 ) ); }
        $validacao=self::validar_campos($nojs?$f:self::etapa($f,1),$e['campos']??array(),$files);if(empty($validacao['ok'])){return $validacao;}
        $limpos=$validacao['limpos'];$papeis=$validacao['papeis'];$uploads=$validacao['uploads'];$anexos=array();
        $isca=F3Base_Formulario_Antispam::iscas($e,$limpos);if(empty($isca['ok'])){return self::erro($isca['codigo']);}
		$atrib     = array();
		$permitido = F3Base_Modulo_Consentimento::estado_permite_tags( F3Base_Modulo_Consentimento::estado_medido() );
		if ( isset( $e['atribuicao'] ) ) {
			$a = is_string( $e['atribuicao'] ) ? json_decode( $e['atribuicao'], true ) : $e['atribuicao'];
			if ( !F3Base_Atribuicao::validar($a) ) {
				return self::erro( 'atribuicao_invalida' );
            }
            // Sem armazenamento autorizado, só a origem declarada desta navegação.
            $atrib=F3Base_Atribuicao::normalizar($a);
        }
		$suspeito = $isca['suspeito']||!$token_valido||$cota_excedida;
        $oferta=null;if(isset($e['oferta'])&&F3Base_Modulo_Consentimento::permite_categoria('medicao')){$oferta=F3Base_Ofertas_Medicao::validar($e['oferta']);if(!$oferta){return self::erro('oferta_invalida');}}
        $atrib=F3Base_Atribuicao::normalizar($atrib);
		$record   = bin2hex( random_bytes( 16 ) );
		foreach ( $uploads as [$file, $campo] ) {
			$r = F3Base_Arquivos_Privados::receber( $file, 'anexo', $campo );
			if ( ! $r['ok'] ) {
				foreach ( $anexos as $a ) {
					F3Base_Arquivos_Privados::eliminar( $a['id'] );
				} return self::erro( $r['codigo'], 503 );
			} $a        = $r['arquivo'];
			$a['campo'] = $campo['nome'];
			$anexos[]   = $a;
		}
		$page   = get_post( (int) $token['p'] );
        $pagina=$page&&get_post_status($page)==='publish'?get_permalink($page):'';
        if($pagina===''&&!empty($_SERVER['HTTP_REFERER'])&&F3Base_Testes::origem_propria($_SERVER['HTTP_REFERER'])){$path=(string)wp_parse_url($_SERVER['HTTP_REFERER'],PHP_URL_PATH);$pagina=home_url($path?:'/');}
        if($pagina===''){$suspeito=true;$sinais[]='sem_pagina_origem';}
        foreach(array_keys($isca['iscas']['campos']) as $name){$sinais[]='isca_'.$name;}
        $politica_sinais=F3Base_Formulario_Antispam::avaliar($sinais);$suspeito=$politica_sinais['suspeito'];$motivos=$politica_sinais['sinais_suspeitos'];
		$cfg    = F3Base_Options::ler( 'f3base_contato' );
		$regime = $f['regime'] ?? 'registro';
		$metodo = array(
			'registro' => 'formulario',
			'whatsapp' => 'whatsapp_formulario',
			'conteudo' => 'conteudo',
		)[ $regime ];
		$origem = F3Base_Modulo_Endpoint_Leads::origem();
		$d      = array(
			'classificacao_contexto'=>$e['classificacao_contexto']??'nao_informada',
            'record_id'          => $record,
            'contexto_teste' => $marca['contexto_teste'],
            'audiencia_excluida' => ($e['audiencia_excluida']??'0')==='1',
            'superficie' => $e['superficie']??'conteudo',
			'correlacao'         => $sid,
			'formulario'         => $f['id'],
			'formulario_revisao' => $token['r'],
            'formulario_titulo' => $f['titulo'],
            'campos_snapshot'=>array_map(static fn($c)=>array_intersect_key($c,array_flip(array('nome','rotulo','tipo','papel','opcoes','formato_livre'))),$f['campos']),
            'campos_relatorio' => array_values(array_map(static fn($c)=>array_intersect_key($c,array_flip(array('nome','rotulo','tipo','opcoes'))),array_filter($f['campos'],static fn($c)=>in_array($c['tipo'],array('select','radio','checkbox'),true)&&(empty($c['papel'])||$c['papel']==='servico')))),
			'metodo'             => $metodo,
			'captura'            => $suspeito ? 'suspeito' : 'aceito',
            'sinais_politica'=>$politica_sinais,
			'campos'             => $limpos,
			'email'              => $papeis['email'] ?? '',
            'telefone' => $papeis['telefone'] ?? '',
            'linkedin' => $papeis['linkedin'] ?? '',
            'empresa'=>$papeis['empresa']??'', 'cargo'=>$papeis['cargo']??'',
            'servicos'=>isset($papeis['servico'])&&$papeis['servico']!==''?(array)$papeis['servico']:(!empty($f['servico_fixo'])?array($f['servico_fixo']):array()),
            'servico_origem'=>isset($papeis['servico'])&&$papeis['servico']!==''?'selecionado':(!empty($f['servico_fixo'])?'fixo':'ausente'),
			'nome'               => $papeis['nome'] ?? '',
			'pagina'             => $pagina,
			'snapshot'           => array(
				'site'          => get_bloginfo( 'name' ),
				'pagina_titulo' => $page ? $page->post_title : '',
				'usuario'       => get_current_user_id(),
			),
			'origem'             => $origem,
			'atribuicao'         => $atrib,
            'oferta' => $oferta,
            'navegacao' => $e['navegacao'] ?? null,
            'dispositivo' => $e['dispositivo'] ?? '',
            'visitante'=>$e['visitante']??'', 'visitas'=>$e['visitas']??'','visitas_minimo'=>$e['visitas_minimo']??'','visitas_desde'=>$e['visitas_desde']??'','retorno'=>$e['retorno']??'','largura_janela'=>$e['largura_janela']??null,'max_touch_points'=>$e['max_touch_points']??null,
			'suspeita_motivo'    => implode(',',$motivos),
            'iscas_privadas'=>$isca['iscas']['campos']?array($isca['iscas']):array(),
            'antispam_regra' => '3',
            'tempo_preenchimento_segundos' => $tempo_confiavel?max(0,time()-$token['t']):null,
            'tempo_preenchimento_confiavel'=>$tempo_confiavel,
            'sinais' => $sinais,
			'user_agent'         => substr( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ), 0, 500 ),
			'anexos'             => $anexos,
			'consentimento'      => F3Base_Modulo_Consentimento::estado_medido(),
			'consentimento_ref'  => F3Base_Modulo_Consentimento::referencia_confirmada(),
			'sessao'             => F3Base_Modulo_Consentimento::permite_categoria( 'medicao' ) && is_string( $e['sessao'] ?? null ) && preg_match( '/^[a-f0-9-]{16,64}$/D', $e['sessao'] ) ? $e['sessao'] : null,
			'notificar'          => ( $cfg['avisar_por_formulario'] ?? true ),
			'destinatarios'      => F3Base_Leads_Notificacoes::destinatarios( $f['destinatarios'] ?? $cfg['email_leads'] ?? array() ),
			'assunto'            => $f['assunto'] ?? $f['titulo'],
			'payload'            => array(
				'formulario' => $f['id'],
				'revisao'    => $token['r'],
				'campos'     => $limpos,
				'arquivos'   => array_map( static fn( $a )=>array_intersect_key( $a, array_flip( array( 'campo', 'nome', 'sha256', 'bytes' ) ) ), $anexos ),
			),
		);
        foreach($f['campos'] as $campo){if(($campo['papel']??'')==='telefone'&&trim((string)($limpos[$campo['nome']]??''))!==''){$marcaTelefone=F3Base_Telefone::diagnostico((string)($e['campos'][$campo['nome']]??''),F3Base_Options::ler('f3base_pipedrive')['pais_telefone']??'BR',F3Base_Telefone::livre($campo));$d['telefones_normalizacao'][$campo['nome']]=$marcaTelefone;$d['telefone_normalizacao']=$marcaTelefone;}}
        foreach($f['campos'] as $campo){if(($campo['papel']??'')==='contato'&&trim((string)($limpos[$campo['nome']]??''))!==''){$contact=F3Base_Telefone::contato((string)$limpos[$campo['nome']]);$d['contato_normalizacao']=$contact+array('campo'=>$campo['nome']);if($contact['tipo']==='telefone'){$d['telefone_normalizacao']=$contact['diagnostico'];$d['telefones_normalizacao'][$campo['nome']]=$contact['diagnostico'];}}}
        $d['conversoes_telefone']=array('classe'=>F3Base_Telefone::marca($d),'sem_identificador'=>F3Base_Telefone::sem_identificador($d),'politica_converter'=>F3Base_Options::ler(F3Base_Telefone::OPTION)!==false);
		if ( ! F3Base_Arquivos_Privados::vincular( $anexos, $record ) ) {
			foreach ( $anexos as $a ) {
				F3Base_Arquivos_Privados::eliminar( $a['id'] );
			} return self::erro( 'vinculo_de_anexo_falhou', 503 ); }
        if(self::tem_complemento($f)&&!$nojs){$d['complemento_permissao']=F3Base_Formulario_Complementos::permissao($record,$f);}
        if(isset($e['cta_origem'])){$cta=json_decode((string)$e['cta_origem'],true);if(is_array($cta)){$d['cta_origem']=array('texto'=>mb_substr(sanitize_text_field($cta['texto']??''),0,160),'destino'=>self::destino_whatsapp((string)($cta['destino']??'')),'superficie'=>$d['superficie']);}}
		if(F3Base_Modulo_Consentimento::permite_categoria('medicao')&&is_string($e['ga4_client_id']??null)&&is_string($e['ga4_session_id']??null)&&preg_match('/^[0-9]{1,20}\.[0-9]{1,20}$/D',$e['ga4_client_id'])&&preg_match('/^[1-9][0-9]{0,19}$/D',$e['ga4_session_id'])){$d['ga4']=array('client_id'=>$e['ga4_client_id'],'session_id'=>$e['ga4_session_id'],'measurement_id'=>(string)F3Base_Options::ler('f3base_ga4_measurement_id'));$d['ga4']=F3Base_Ga4_Sessao::capturar($e,$d['ga4']);}
        $d['resposta_visitante'] = $f['resposta_visitante'] ?? array( 'ativa' => false );
		$d = F3Base_Leads_Contexto::capturar( $d, F3Base_Modulo_Consentimento::permite_categoria( 'medicao' ) );
		$dedup = $nojs ? 'semjs|' . F3Base_Leads_Repositorio::hash( $d['payload'] ) . '|' . hash_hmac( 'sha256', wp_json_encode( $origem ), wp_salt( 'auth' ) ) . '|' . floor( time() / 300 ) : $sid;
		$r     = F3Base_Leads_Repositorio::guardar( $d, hash( 'sha256', 'form|' . $f['id'] . '|' . $dedup ) );
		if ( ! $r['ok'] || ! empty( $r['duplicado'] ) ) {
			foreach ( $anexos as $a ) {
				F3Base_Arquivos_Privados::eliminar( $a['id'] ); }
		}
		if ( ! $r['ok'] ) {
			return self::erro( $r['codigo'], 503 ); }
		$record   = $r['record_id'];
		$gravado  = F3Base_Leads_Repositorio::obter( $record );
		$suspeito = 'suspeito' === $gravado['captura'];
		$out      = array(
			'ok'             => true,
			'persisted'      => true,
			'duplicado'      => ! empty( $r['duplicado'] ),
			'aceito'         => ! $suspeito,
            'classe_trafego' => $gravado['classe_trafego'],
			'linkedin_conversion_id'=>F3Base_Linkedin_Conversoes::regra($gravado),'correlation_id' => $gravado['correlacao'],'transporte'=>F3Base_Conversoes_Transporte::registro($gravado),'conversao'=>F3Base_Aquisicoes::reservar($gravado),
			'method'         => $metodo,
			'mensagem'       => $suspeito ? 'Recebemos seu envio para análise.' : self::mensagens($f)['sucesso'],
		);
		if ( ! $suspeito && 'conteudo' === $regime ) {
			$g = F3Base_Conteudo_Privado::conceder( $record, $f, $gravado['email'] );
			if ( ! $g['ok'] ) {
				$out['conteudo_pendente'] = true;
				$out['mensagem']         .= ' O link de conteúdo está temporariamente indisponível.'; } else {
				$out['url'] = $g['url'];
				if ( $g['record_id'] !== $record ) {
					F3Base_Leads_Repositorio::eliminar( $record );
					$record           = $g['record_id'];
					$out['duplicado'] = true; }
				}
		}
		if ( ! $suspeito && 'whatsapp' === $regime ) {
            
			$out['url'] = self::conversa($f,$gravado,$limpos); }
		if ( ! $out['duplicado'] && ! $suspeito ) {
			$out['notificacao'] = F3Base_Leads_Notificacoes::agendar( $record );
			$out['resposta_visitante'] = F3Base_Resposta_Visitante::enviar( $record );
			F3Base_Modulo_Meta_Capi::agendar_registro( $record, $permitido && F3Base_Modulo_Consentimento::permite_categoria( 'publicidade' ) );
		}
        $out['record_id']=$record;
        if(!$suspeito&&!$nojs&&!empty($gravado['dados']['complemento_permissao'])){$out+=F3Base_Formulario_Complementos::continuacao($gravado);}
        if(!empty($out['etapa_pendente'])){return $out;}
        return F3Base_Confirmacao::preparar($out,$f);
	}
	public static function post(): void {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			status_header( 405 );
			exit; }
		if ( empty( $_POST ) && (int) ( $_SERVER['CONTENT_LENGTH'] ?? 0 ) > 0 ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Anonymous POST is authenticated and scoped by the HMAC token in receber(); files are verified as actual uploads there.
			wp_die( 'O envio excedeu o limite total do servidor.', 'Envio não recebido', array( 'response' => 413 ) ); }
		$r  = self::receber( wp_unslash( $_POST ), $_FILES ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Anonymous POST is authenticated and scoped by the HMAC token in receber(); files are verified as actual uploads there.
        if(!empty($r['redirecionar'])){nocache_headers();header('Referrer-Policy: no-referrer');wp_redirect($r['redirecionar'],303,'F3 Base confirmação validada');exit;}
		$id = bin2hex( random_bytes( 32 ) );
		set_transient( 'f3base_confirmacao_' . $id, $r, 600 );
		nocache_headers();
		wp_safe_redirect(
			add_query_arg(
				array(
					'action' => 'f3base_confirmacao',
					'ref'    => $id,
				),
				admin_url( 'admin-post.php' )
			),
			303
		);
		exit;
	}
	public static function confirmacao(): void {
		nocache_headers();
		header( 'Cache-Control: private, no-store' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		add_filter('wp_robots',static fn()=>array('noindex'=>true,'nofollow'=>true),PHP_INT_MAX);
		$id = (string) ( $_GET['ref'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only private confirmation uses a random 256-bit short-lived reference and no-cache headers.
		$r  = preg_match( '/^[a-f0-9]{64}$/D', $id ) ? get_transient( 'f3base_confirmacao_' . $id ) : false;
		if ( ! $r ) {
			wp_die( esc_html(F3Base_Textos_Contato::ler('confirmacao_expirada')), esc_html(F3Base_Textos_Contato::ler('confirmacao_titulo')), array( 'response' => 410 ) ); }
		$html = '<p>' . esc_html( $r['mensagem'] ?? ( 'Envio não recebido: ' . ( $r['codigo'] ?? 'erro' ) ) ) . '</p>';
		if ( ! empty( $r['url'] ) ) {
			$html .= '<p><a rel="noreferrer noopener" href="' . esc_url( $r['url'] ) . '">' . esc_html(F3Base_Textos_Contato::ler('confirmacao_continuar')) . '</a></p>'; }
		wp_die( $html, esc_html(F3Base_Textos_Contato::ler('confirmacao_titulo')), array( 'response' => 200 ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- HTML assembled above uses esc_html for messages and esc_url for links.
	}
}
