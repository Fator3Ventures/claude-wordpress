<?php
/** Leitor limitado da gramática IMAP e BODYSTRUCTURE (RFC 9051 §§6.4.5/7.5.2). */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Estrutura {
    private string $s;private int $i=0;private int $tokens=0;
    private function value(int $depth=0){
        if($depth>32||++$this->tokens>16000){throw new RuntimeException('imap_estrutura_excedida');}
        $n=strlen($this->s);while($this->i<$n&&ctype_space($this->s[$this->i])){++$this->i;}if($this->i>=$n){throw new RuntimeException('imap_estrutura_incompleta');}$c=$this->s[$this->i++];
        if($c==='('){$out=array();while(true){while($this->i<$n&&ctype_space($this->s[$this->i])){++$this->i;}if($this->i>=$n){throw new RuntimeException('imap_estrutura_incompleta');}if($this->s[$this->i]===')'){++$this->i;return $out;}$out[]=$this->value($depth+1);}}
        if($c==='"'){$out='';while($this->i<$n){$c=$this->s[$this->i++];if($c==='"'){return $out;}if($c==='\\'){if($this->i>=$n){break;}$c=$this->s[$this->i++];}$out.=$c;}throw new RuntimeException('imap_estrutura_incompleta');}
        if($c==='{'){if(!preg_match('/\G([0-9]+)\}\r\n/A',$this->s,$m,0,$this->i)){throw new RuntimeException('imap_literal_invalido');}$this->i+=strlen($m[0]);$length=(int)$m[1];if($length>F3Base_Email_Imap::MAX_MESSAGE||$this->i+$length>$n){throw new RuntimeException('imap_literal_incompleto');}$v=substr($this->s,$this->i,$length);$this->i+=$length;return $v;}
        --$this->i;if(preg_match('/\GBODY\[[^\]\r\n]{0,200}\](?:<[0-9]+>)?/Ai',$this->s,$m,0,$this->i)){$this->i+=strlen($m[0]);return $m[0];}if(!preg_match('/\G[^\s(){}"]+/A',$this->s,$m,0,$this->i)){throw new RuntimeException('imap_atom_invalido');}$this->i+=strlen($m[0]);return strtoupper($m[0])==='NIL'?null:$m[0];
    }
    public static function fetch(string $wire,int $uid): array {
        $p=new self();$p->s=$wire;$offset=0;$found=null;
        while(preg_match('/^\* [0-9]+ FETCH (\()/mi',$wire,$m,PREG_OFFSET_CAPTURE,$offset)){$p->i=$m[1][1];$list=$p->value();$offset=$p->i;if(count($list)%2){throw new RuntimeException('imap_fetch_invalido');}$a=array();for($i=0;$i<count($list);$i+=2){if(!is_string($list[$i])){throw new RuntimeException('imap_fetch_invalido');}$key=strtoupper($list[$i]);if(array_key_exists($key,$a)){throw new RuntimeException('imap_fetch_ambiguo');}$a[$key]=$list[$i+1];}if(($a['UID']??'')===(string)$uid){if($found!==null){throw new RuntimeException('imap_fetch_ambiguo');}$found=$a;}}
        if($found===null){throw new RuntimeException('imap_mensagem_ausente');}return $found;
    }
    private static function params($p): array {$out=array();if(is_array($p)){for($i=0;$i+1<count($p);$i+=2){if(is_string($p[$i])&&is_string($p[$i+1])){$out[strtolower($p[$i])]=$p[$i+1];}}}return $out;}
    private static function filename(array $params): string {
        $value=$params['filename']??$params['name']??'';foreach(array('filename','name') as $key){$encoded=$params[$key.'*']??'';if($encoded===''){for($i=0;$i<20&&isset($params[$key.'*'.$i.'*']);$i++){$encoded.=$params[$key.'*'.$i.'*'];}}if($encoded!==''){if(preg_match("/^([^']*)'[^']*'(.*)$/s",$encoded,$m)){$value=rawurldecode($m[2]);if($m[1]!==''&&in_array(strtoupper($m[1]),array_map('strtoupper',mb_list_encodings()),true)){$value=mb_convert_encoding($value,'UTF-8',$m[1]);}}else{$value=rawurldecode($encoded);}break;}}
        return mb_substr(sanitize_file_name(wp_check_invalid_utf8(mb_decode_mimeheader($value?:'anexo-sem-nome'))),0,180);
    }
    public static function partes(array $body): array {
        $out=array('texto'=>null,'anexos'=>array());$texts=array();$walk=function(array $b,string $path='',bool $attached=false,int $depth=0)use(&$walk,&$texts,&$out){
            if($depth>30||count($out['anexos'])>100||count($texts)>100){throw new RuntimeException('imap_estrutura_excedida');}
            if(is_array($b[0]??null)){$i=0;while(is_array($b[$i]??null)){$i++;}$disp=$b[$i+2]??null;$attached=$attached||(is_array($disp)&&strtolower((string)($disp[0]??''))==='attachment');for($k=0;$k<$i;$k++){$walk($b[$k],$path===''?(string)($k+1):$path.'.'.($k+1),$attached,$depth+1);}return;}
            $type=strtolower((string)($b[0]??''));$sub=strtolower((string)($b[1]??''));$params=self::params($b[2]??null);$disp=$b[$type==='text'?9:($type==='message'&&$sub==='rfc822'?11:8)]??null;$dp=is_array($disp)?self::params($disp[1]??null):array();$attachment=$attached||$type!=='text'||!in_array($sub,array('plain','html'),true)||strtolower((string)($disp[0]??''))==='attachment'||isset($params['name'],$dp['filename'])||isset($params['name'])||isset($dp['filename'])||isset($dp['filename*']);
            if(!is_scalar($b[6]??null)||!ctype_digit((string)$b[6])){throw new RuntimeException('imap_estrutura_invalida');}$size=(int)$b[6];$part=$path?:'1';
            if($attachment){$out['anexos'][]=array('nome'=>self::filename($dp+$params),'bytes_transferencia'=>$size,'tamanho_fonte'=>'BODYSTRUCTURE; octetos com codificação de transferência','parte'=>$part);}
            else{$texts[]=array('parte'=>$part,'tipo'=>$sub,'charset'=>$params['charset']??'UTF-8','encoding'=>strtolower((string)($b[5]??'7bit')),'bytes_transferencia'=>$size);}
        };$walk($body);foreach(array('plain','html') as $type){foreach($texts as $text){if($text['tipo']===$type){$out['texto']=$text;break 2;}}}return $out;
    }
    public static function texto(string $bytes,array $part,bool $truncated): string {
        $encoding=$part['encoding'];if($encoding==='base64'){$bytes=preg_replace('/\s+/','',$bytes);if($truncated){$bytes=substr($bytes,0,strlen($bytes)-strlen($bytes)%4);}$bytes=base64_decode($bytes,true);if($bytes===false){throw new RuntimeException('imap_texto_encoding_invalido');}}
        elseif($encoding==='quoted-printable'){if($truncated){$bytes=preg_replace('/=(?:[a-f0-9])?$/i','',$bytes);}$bytes=quoted_printable_decode($bytes);}elseif(!in_array($encoding,array('7bit','8bit','binary'),true)){throw new RuntimeException('imap_texto_encoding_invalido');}
        $charset=$part['charset'];if(in_array(strtoupper($charset),array_map('strtoupper',mb_list_encodings()),true)){$bytes=mb_convert_encoding($bytes,'UTF-8',$charset);}else{$bytes=wp_check_invalid_utf8($bytes,true);}
        if($part['tipo']==='html'){$bytes=preg_replace('~<(?:script|style)\b[^>]*>.*?</(?:script|style)>~is','',$bytes);$bytes=html_entity_decode(wp_strip_all_tags(preg_replace('~<br\s*/?>|</(?:p|div|li)>~i',"\n",$bytes)),ENT_QUOTES|ENT_HTML5,'UTF-8');}return $bytes;
    }
}
