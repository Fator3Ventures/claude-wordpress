<?php
/** Adaptadores de qualidade: recebimento autenticado, leitura do CRM e outbox Meta. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Qualidade_Remota {
    private static float $prazo=0;
    private static function conta(): string {$s=get_option('f3base_pipedrive_estado',array());return ($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??'');}
    private static function trabalho(string $id): ?array {
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE record_id=%s AND conta=%s AND estado NOT IN ('cancelado','cancelando') ORDER BY atualizado_em DESC LIMIT 1",F3Base_Pipedrive_Fila::tabela(),$id,self::conta()),ARRAY_A);if($r){$r['journal']=json_decode($r['journal'],true)?:array();}return $r;
    }
    private static function proprio(string $entity,string $id): ?array {
        global $wpdb;if(!in_array($entity,array('lead','deal'),true)||!preg_match('/^[a-z0-9-]{1,40}$/D',$id)){return null;}
        // JSON_EXTRACT is used only over this site's account. No matching by name/e-mail.
        $path=$entity==='lead'?'$.oportunidade.id':'$.qualidade_negocio';
        $r=$wpdb->get_row($wpdb->prepare("SELECT record_id,journal,chave FROM %i WHERE conta=%s AND estado NOT IN ('cancelado','cancelando') AND JSON_UNQUOTE(JSON_EXTRACT(journal,%s))=%s LIMIT 1",F3Base_Pipedrive_Fila::tabela(),self::conta(),$path,$id),ARRAY_A);
        return $r?:null;
    }
    public static function autenticar(WP_REST_Request $r) {
        if(!self::config()['ativo']){return new WP_Error('integracao_inativa','Integração indisponível.',array('status'=>403));}
        $secret=F3Base_Segredos::abrir('f3base_pipedrive_webhook_segredo');$header=(string)$r->get_header('authorization');
        $given=str_starts_with($header,'Basic ')?base64_decode(substr($header,6),true):false;
        if(!$secret||!is_string($given)||!hash_equals('f3base:'.$secret,$given)){return new WP_Error('credencial_invalida','Credencial inválida.',array('status'=>401));}
        return true;
    }
    public static function receber(WP_REST_Request $r): WP_REST_Response {
        $out=F3Base_Recuperacao::executar(static fn()=>self::receber_interno($r));return $out instanceof WP_REST_Response?$out:new WP_REST_Response(array('ok'=>false,'codigo'=>'core_em_recuperacao'),503);
    }
    private static function receber_interno(WP_REST_Request $r): WP_REST_Response {
        if(strlen($r->get_body())>131072){return new WP_REST_Response(array('ok'=>false,'codigo'=>'corpo_excede_limite'),413);}
        $v=json_decode($r->get_body(),true,32,JSON_BIGINT_AS_STRING);$meta=$v['meta']??array();$data=$v['data']??array();$account=(string)(get_option('f3base_pipedrive_estado',array())['conta_id']??'');
        if(!is_array($v)||!is_array($meta)||!is_array($data)||$account===''||(string)($meta['company_id']??'')!==$account){return new WP_REST_Response(array('ok'=>false,'codigo'=>'conta_ou_formato_invalido'),400);}
        $entity=(string)($meta['entity']??'');$id=(string)($meta['entity_id']??$data['id']??'');$job=self::proprio($entity,$id);
        if(!$job){return new WP_REST_Response(array('ok'=>true,'codigo'=>'fora_do_escopo'),200);}
        if(!F3Base_Leads_Repositorio::quota(hash('sha256','qualidade-webhook|'.$account.'|'.gmdate('YmdHi')),120,time()+120)){return new WP_REST_Response(array('ok'=>false,'codigo'=>'limite_local'),429);}
        $when=$meta['timestamp']??null;$at=is_numeric($when)?(int)$when:(is_string($when)?strtotime($when):false);if(!$at||$at>time()+60){return new WP_REST_Response(array('ok'=>false,'codigo'=>'horario_invalido'),400);}
        $safe=array('entity'=>$entity,'entity_id'=>$id,'at'=>$at,'action'=>sanitize_key($meta['action']??''),'data'=>array_intersect_key($data,array_flip(array('id','pipeline_id','stage_id','status','is_archived','update_time','lost_reason','value','currency','won_time','lost_time','close_time','add_time','custom_fields'))));
        $key=hash('sha256',$account.'|'.($meta['id']??wp_json_encode($safe)));global $wpdb;
        $exists=$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE chave=%s',self::tabela('recibos'),$key));
        if(!$exists&&$wpdb->insert(self::tabela('recibos'),array('chave'=>$key,'record_id'=>$job['record_id'],'conta'=>$account,'recebido_em'=>time(),'payload'=>F3Base_Capi_Fila::cifrar_payload($safe)))===false){return new WP_REST_Response(array('ok'=>false,'codigo'=>'recibo_nao_persistido'),503);}
        if($wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('qualidade_encerrada'=>0,'qualidade_terminal_contagem'=>0,'qualidade_terminal_em'=>0,'qualidade_proxima'=>time()),array('chave'=>$job['chave']))===false){return new WP_REST_Response(array('ok'=>false,'codigo'=>'retomada_nao_persistida'),503);}
        F3Base_Options::atualizar_estado('f3base_qualidade_estado',static function($s)use($account){$s['ultimo_webhook_recebido']=array('em'=>time(),'conta'=>$account,'codigo'=>'recibo_persistido');return $s;});
        F3Base_Fila::agendar(self::HOOK,time()+1);return new WP_REST_Response(array('ok'=>true,'codigo'=>$exists?'recibo_repetido':'recibo_persistido'),200);
    }
    public static function registrar_webhook(): array {return F3Base_Pipedrive_Api::com_consumidor('verificacao',static fn()=>self::registrar_webhook_interno());}
    private static function registrar_webhook_interno(): array {
        if(!F3Base_Integracoes::pipedrive_verificado()){return array('ok'=>false,'codigo'=>'conta_crm_nao_verificada');}
        if(!current_user_can('manage_options')||!is_ssl()||wp_parse_url(rest_url(),PHP_URL_SCHEME)!=='https'){return array('ok'=>false,'codigo'=>'administrador_e_https_necessarios');}
        $secret=F3Base_Segredos::abrir('f3base_pipedrive_webhook_segredo');if($secret===''){$secret=bin2hex(random_bytes(32));$r=F3Base_Options::gravar('f3base_pipedrive_webhook_segredo',$secret,F3Base_Options::ORIGEM_MANUAL,F3Base_Options::revisao('f3base_pipedrive_webhook_segredo'));if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'credencial_nao_persistida');}}
        F3Base_Pipedrive_Api::iniciar_lote();$list=F3Base_Pipedrive_Api::pedir('GET','v1/webhooks');if(empty($list['ok'])){return $list;}$url=rest_url(F3BASE_REST_NAMESPACE.'/pipedrive/qualidade');$ids=array();
        foreach(array('lead','deal') as $entity){$found=false;foreach($list['data'] as $hook){if(($hook['subscription_url']??'')===$url&&($hook['event_object']??'')===$entity&&($hook['version']??'')==='2.0'){$found=true;$ids[]=$hook['id'];break;}}if($found){continue;}$r=F3Base_Pipedrive_Api::pedir('POST','v1/webhooks',array('subscription_url'=>$url,'name'=>'F3Base '.wp_parse_url(home_url(),PHP_URL_HOST).' '.$entity,'event_action'=>'*','event_object'=>$entity,'version'=>'2.0','http_auth_user'=>'f3base','http_auth_password'=>$secret));if(empty($r['ok'])){return array('ok'=>false,'codigo'=>$r['codigo']??'webhook_sem_confirmacao','parcial'=>!empty($ids));}$ids[]=$r['data']['id'];}
        $s=F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($v)=>array_merge($v,array('webhooks'=>array('ids'=>$ids,'conta'=>self::conta(),'em'=>time()))));return array('ok'=>!empty($s['persisted']),'codigo'=>'webhooks_confirmados','ids'=>$ids);
    }
    private static function observar_crm(array $lead,string $entity,array $data,int $at,string $key,array $extra=array()): array {
        if(!F3Base_Desfechos::observar_contato($lead,$entity,$data,$at)){return array('ok'=>false,'codigo'=>'observacao_comercial_nao_persistida');}
        $finance=$entity==='deal'?F3Base_Desfechos::observar($lead,$data,$at,$key,(string)($extra['cobertura']??'pipedrive')):array('ok'=>true);if(empty($finance['ok'])){return $finance;}
        $state=$entity==='lead'?(!empty($data['is_archived'])?'lead_arquivado':'lead_criado'):(($data['status']??'')==='won'?'ganho':(($data['status']??'')==='lost'?'perdido':(!empty($data['stage_id'])?'stage:'.$data['stage_id']:'')));
        if($state===''){return array('ok'=>false,'codigo'=>'estado_crm_incompleto');}$account=(string)(get_option('f3base_pipedrive_estado',array())['conta_id']??'');$map=self::resolver($lead,$account,(string)($data['pipeline_id']??''),$state);
        if(empty($map['ok'])){return $map;}return self::registrar($lead,$map['regra']['etapa'],'pipedrive',$at,$key,$extra+array('conta'=>$account,'entidade'=>$entity,'id'=>(string)($data['id']??''),'estado'=>$state,'regra'=>$map['regra'],'desfecho'=>$entity==='deal'?F3Base_Desfechos::preparar($data):null));
    }
    private static function recibos(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' ORDER BY recebido_em LIMIT 30",self::tabela('recibos')),ARRAY_A);$n=0;
        foreach($rows as $row){if(microtime(true)>self::$prazo-2){break;}$data=F3Base_Capi_Fila::abrir_payload($row['payload']);$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||!$data||!self::trabalho($row['record_id'])){$r=array('ok'=>false,'codigo'=>'vinculo_ausente');}elseif($data['action']==='delete'){$r=array('ok'=>false,'codigo'=>'exclusao_nao_comprova_arquivamento');}else{
                $coverage='evento_webhook';
                if(($data['entity']==='deal'&&array_diff(array('value','currency','status'),array_keys($data['data'])))||!array_key_exists('custom_fields',$data['data'])){
                    $full=F3Base_Pipedrive_Api::pedir('GET',($data['entity']==='deal'?'v2/deals/':'v1/leads/').$data['entity_id']);
                    if(empty($full['ok'])||(string)($full['data']['id']??'')!==(string)$data['entity_id']){continue;}
                    $instant=F3Base_Desfechos::instante($full['data']['update_time']??null);if(!$instant){continue;}
                    $data['data']=$full['data'];$data['at']=$instant;$coverage='estado_atual_apos_webhook_parcial';
                }
                $r=self::observar_crm($lead,$data['entity'],$data['data'],(int)$data['at'],$row['chave'],array('cobertura'=>$coverage));
            }
            $done=!empty($r['ok'])||in_array($r['codigo']??'',array('vinculo_ausente','etapa_nao_mapeada','mapa_ambiguo','estado_crm_incompleto','exclusao_nao_comprova_arquivamento'),true);
            if($done){$wpdb->update(self::tabela('recibos'),array('estado'=>!empty($r['ok'])?'processado':'revisao','codigo'=>$r['codigo']??'','payload'=>''),array('chave'=>$row['chave']));}$n++;
        }return array('processados'=>$n);
    }
    public static function cadencia_crm(array $row,array $response,int $now): array {
        $ok=!empty($response['ok']);$fail=$ok?0:(int)($row['qualidade_falhas']??0)+1;$data=$response['data']??array();
        $hash=$ok?hash('sha256',wp_json_encode(array_intersect_key($data,array_flip(array('id','stage_id','pipeline_id','status','is_archived','value','currency','won_time','lost_time','close_time','custom_fields','is_deleted','value','currency','won_time','lost_time','close_time','custom_fields'))))):(string)($row['qualidade_hash']??'');
        $changed=($row['qualidade_hash']??'')!==$hash||empty($row['qualidade_alterada'])?$now:(int)$row['qualidade_alterada'];
        $terminal=!empty($data['is_archived'])||!empty($data['is_deleted'])||($data['status']??'')==='deleted';
        $ctx=(string)($response['contexto']??'');$same=$ctx!==''&&($row['qualidade_contexto']??'')===$ctx&&($row['qualidade_hash']??'')===$hash;
        $count=0;$last=0;
        if($ok&&$terminal&&$ctx!==''&&!empty($data['id'])){
            $count=$same?(int)($row['qualidade_terminal_contagem']??0):0;$last=$same?(int)($row['qualidade_terminal_em']??0):0;
            if(!$last||$now-$last>=DAY_IN_SECONDS){$count=min(3,$count+1);$last=$now;}
        }
        $closed=$count>=3?$now:0;
        $interval=$fail?min(DAY_IN_SECONDS,HOUR_IN_SECONDS*2**min(5,$fail-1)):($terminal?DAY_IN_SECONDS:($now-$changed>=DAY_IN_SECONDS?6*HOUR_IN_SECONDS:HOUR_IN_SECONDS));
        return array('qualidade_ultima'=>$now,'qualidade_confirmada'=>$ok?$now:(int)($row['qualidade_confirmada']??0),'qualidade_proxima'=>$now+$interval,'qualidade_alterada'=>$changed,'qualidade_falhas'=>min(65535,$fail),'qualidade_hash'=>$hash,'qualidade_encerrada'=>$closed,'qualidade_terminal_contagem'=>$count,'qualidade_terminal_em'=>$last,'qualidade_contexto'=>$ctx);
    }

    public static function cobertura_crm(): array {
        global $wpdb;$t=F3Base_Pipedrive_Fila::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))!==$t||$wpdb->get_var($wpdb->prepare('SHOW COLUMNS FROM %i LIKE %s',$t,'qualidade_proxima'))!=='qualidade_proxima'){return array('ok'=>false,'codigo'=>'estrutura_qualidade_pendente');}$rows=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) elegiveis,MIN(NULLIF(qualidade_confirmada,0)) mais_antiga_em,SUM(qualidade_confirmada=0 AND qualidade_encerrada=0) nunca_consultados,SUM(qualidade_encerrada>0) encerrados,SUM(qualidade_proxima<=%d AND qualidade_encerrada=0) vencidos,MIN(IF(qualidade_encerrada=0,qualidade_proxima,NULL)) proxima_em FROM %i WHERE conta=%s AND estado NOT IN ('cancelado','cancelando') AND JSON_EXTRACT(journal,'$.oportunidade.id') IS NOT NULL",time(),F3Base_Pipedrive_Fila::tabela(),self::conta()),ARRAY_A);
        $budget=F3Base_Pipedrive_Orcamento::resumo();$b=$budget['consumidores']['qualidade'];$active=max(0,(int)($rows['elegiveis']??0)-(int)($rows['encerrados']??0));
        return array('ok'=>!$wpdb->last_error,'contagens'=>$wpdb->last_error?null:$rows,'cobertura_estimada'=>array('registros_recorrentes'=>$active,'custo_minimo_por_registro'=>20,'custo_com_ponte'=>60,'limite_diario'=>$b['limite'],'saldo'=>$b['saldo_local'],'horas_minimas_rodada'=>$active*20/$b['limite']*24,'premissas'=>'Estimativa se todo o teto de qualidade estiver disponível; consultas auxiliares, erros e quota remota aumentam o atraso.','proximo_lote_em'=>max((int)($rows['proxima_em']??time()),$b['saldo_local']<20?$b['proxima_janela_em']:time(),$budget['pausa_remota_ate'])),'cadencia_segundos'=>array('ativo'=>3600,'sem_mudanca_24h'=>21600,'terminal'=>86400),'limite'=>'Fotografia atual; etapas intermediárias podem não ser observadas. Webhooks são independentes da consulta.');
    }
    private static function consultar_crm(string $record=''): array {
        return F3Base_Pipedrive_Api::com_consumidor('qualidade',static fn()=>self::consultar_crm_interno($record));
    }
    private static function consultar_crm_interno(string $record): array {
        global $wpdb;if(!F3Base_Integracoes::pipedrive_verificado()||empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])){return array('ok'=>true,'codigo'=>'crm_desligado_ou_nao_verificado');}
        $extra=$record!==''?$wpdb->prepare(' AND record_id=%s',$record):$wpdb->prepare(' AND qualidade_encerrada=0 AND qualidade_proxima<=%d',time());
        $budget=F3Base_Pipedrive_Orcamento::resumo()['consumidores']['qualidade'];if($budget['saldo_local']<20){return array('ok'=>true,'codigo'=>'orcamento_local_esgotado','processados'=>0,'cobertura'=>self::cobertura_crm());}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE conta=%s AND estado NOT IN ('cancelado','cancelando') AND JSON_EXTRACT(journal,'$.oportunidade.id') IS NOT NULL AND (lease='' OR lease_ate<=%d) {$extra} ORDER BY qualidade_confirmada,qualidade_ultima,chave LIMIT 10",F3Base_Pipedrive_Fila::tabela(),self::conta(),time()),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'agenda_qualidade_indisponivel');}$count=0;$errors=array();
        foreach($rows as $row){if(microtime(true)>self::$prazo-6){break;}if(!F3Base_Pipedrive_Fila::travar_linha($row['chave'])){continue;}
            try{
                $fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',F3Base_Pipedrive_Fila::tabela(),$row['chave']),ARRAY_A);
                if(!$fresh||in_array($fresh['estado'],array('cancelado','cancelando'),true)||($fresh['lease']!==''&&(int)$fresh['lease_ate']>time())||($record===''&&(int)$fresh['qualidade_proxima']>time())){continue;}$row=$fresh;$j=json_decode($row['journal'],true)?:array();$lead=F3Base_Leads_Repositorio::obter($row['record_id']);if(!$lead||!empty($lead['eliminacao_pendente'])||!empty($lead['lixeira'])||empty($j['oportunidade'])){continue;}
                $entity=!empty($j['qualidade_negocio'])?'deal':($j['oportunidade']['tipo']==='lead'?'lead':'deal');$id=(string)($j['qualidade_negocio']??$j['oportunidade']['id']);
                $r=F3Base_Pipedrive_Api::pedir('GET',($entity==='lead'?'v1/leads/':'v2/deals/').$id);
                $contexto=F3Base_Integracoes::identidade_pipedrive();
                // Only explicit absence/deletion can justify the note bridge. A rate limit,
                // network error or permission failure never triggers another search.
                $deleted=(!empty($r['ok'])&&!empty($r['data']['is_deleted']))||in_array($r['http']??0,array(404,410),true);
                if($entity==='lead'&&$deleted&&!empty($j['nota'])&&microtime(true)<self::$prazo-6){
                    $note=F3Base_Pipedrive_Api::pedir('GET','v1/notes/'.(int)$j['nota']);$n=$note['data']??array();
                    if(!empty($note['ok'])&&!empty($n['deal_id'])&&str_contains(wp_strip_all_tags($n['content']??''),'f3base:'.$row['chave'].':nota')){
                        $entity='deal';$id=(string)$n['deal_id'];$r=F3Base_Pipedrive_Api::pedir('GET','v2/deals/'.$id);
                        if(!empty($r['ok'])){$j['qualidade_negocio']=$id;$j['qualidade_vinculo']=array('nota'=>(int)$j['nota'],'em'=>time());}
                    }elseif(empty($note['ok'])){$r=$note;}
                }
                if(!empty($r['ok'])&&(string)($r['data']['id']??'')!==$id){$r=array('ok'=>false,'codigo'=>'identidade_crm_divergente');}
                if(!empty($r['ok'])){$data=$r['data'];$at=strtotime($data['update_time']??$data['add_time']??'')?:0;
                    if($at&&$at<=time()){$observed=self::observar_crm($lead,$entity,$data,$at,hash('sha256',self::conta().'|'.$row['record_id'].'|'.$entity.'|'.$id.'|'.$at.'|'.wp_json_encode(array_intersect_key($data,array_flip(array('stage_id','pipeline_id','status','is_archived','value','currency','won_time','lost_time','close_time','custom_fields'))))),array('cobertura'=>'estado_atual_intermediarias_nao_garantidas'));if(empty($observed['ok'])){$errors[]=$observed['codigo'];}}
                    else{$errors[]='horario_crm_ausente';}
                }else{$errors[]=$r['codigo']??'consulta_falhou';}
                $r['contexto']=$contexto;if($record!==''){$row['qualidade_terminal_contagem']=0;$row['qualidade_terminal_em']=0;}
                if(!F3Base_Pipedrive_Api::lote_atual()||F3Base_Integracoes::identidade_pipedrive()!==$contexto){$errors[]='contexto_alterado';break;}
                $patch=self::cadencia_crm($row,$r,time());$patch['journal']=wp_json_encode($j);
                // A consumer budget prevents all its remaining calls; leave due work due
                // so the next UTC budget resumes without an artificial per-entity penalty.
                if(($r['codigo']??'')==='orcamento_local_esgotado'){break;}
                if(false===$wpdb->update(F3Base_Pipedrive_Fila::tabela(),$patch,array('chave'=>$row['chave'],'journal'=>$row['journal']))){$errors[]='checkpoint_qualidade_falhou';break;}$count++;
                if(empty($r['ok'])&&!empty($r['pausa'])&&!in_array($r['http']??0,array(404,410),true)){break;}
            }finally{F3Base_Pipedrive_Fila::liberar_linha($row['chave']);}
        }
        return array('ok'=>!$errors,'processados'=>$count,'parcial'=>$count<count($rows)||count($rows)===10,'codigos'=>array_values(array_unique($errors)),'consumidor'=>'qualidade','cobertura'=>self::cobertura_crm());
    }
    private static function graph_qualidade(string $method,string $dataset,string $version,array $body=array(),int $timeout=8): array {
        if(!preg_match('/^[0-9]{1,40}$/D',$dataset)||!preg_match('/^v[0-9]{2}\.0$/D',$version)){return array('ok'=>false,'codigo'=>'dataset_ou_versao_invalido');}
        $token=F3Base_Segredos::abrir(self::credencial());if($token===''){return array('ok'=>false,'codigo'=>'credencial_ausente');}
        $url='https://graph.facebook.com/'.$version.'/'.$dataset.($method==='POST'?'/events':'?fields=id,name');$args=array('method'=>$method,'timeout'=>max(1,min(8,$timeout)),'redirection'=>0,'limit_response_size'=>131072,'headers'=>array('Authorization'=>'Bearer '.$token,'Content-Type'=>'application/json'));if($method==='POST'){$args['body']=wp_json_encode($body);}
        $r=wp_remote_request($url,$args);unset($token,$args);if(is_wp_error($r)){return array('ok'=>false,'codigo'=>'transporte_sem_confirmacao','incerto'=>$method==='POST','temporario'=>true);}
        $http=wp_remote_retrieve_response_code($r);$json=json_decode(wp_remote_retrieve_body($r),true,32,JSON_BIGINT_AS_STRING);$ok=$http>=200&&$http<300&&is_array($json)&&empty($json['error'])&&($method==='POST'?($json['events_received']??0)===1:(string)($json['id']??'')===$dataset);
        return array('ok'=>$ok,'http'=>$http,'codigo'=>$ok?($method==='POST'?'meta_aceitou':'leitura_confirmada'):'meta_recusou','incerto'=>$method==='POST'&&($http>=500||($http>=200&&$http<300&&!$ok)),'temporario'=>$http===429||$http>=500,'retry_after'=>max(60,min(86400,(int)wp_remote_retrieve_header($r,'retry-after'))),'code'=>(int)($json['error']['code']??0),'subcode'=>(int)($json['error']['error_subcode']??0),'type'=>sanitize_key($json['error']['type']??''));
    }
    public static function verificar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$cfg=self::config();if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'dataset'=>$cfg['dataset'],'efeito'=>'consulta_de_leitura_sem_conversao');}
        $rev=F3Base_Options::revisao(self::OPCAO);$r=self::graph_qualidade('GET',$cfg['dataset'],$cfg['versao_api']);$r['escrita']='nao_testada';$r['em']=time();$r['revisao']=$rev;$r['credencial_revisao']=F3Base_Options::revisao(self::credencial());
        F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($s)=>array_merge($s,array('meta_verificacao'=>$r)));return $r;
    }
    private static function enviar(): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('pendente','incerto','enviando') AND proxima<=%d ORDER BY proxima LIMIT 10",self::tabela('fila'),time()),ARRAY_A);$count=0;
        foreach($rows as $row){if(microtime(true)>self::$prazo-4){break;}$lock=F3Base_Trava::adquirir('qualidade-envio-'.$row['record_id'],30);if(!$lock){continue;}try{
            $fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela('fila'),$row['chave']),ARRAY_A);if(!$fresh||!in_array($fresh['estado'],array('pendente','incerto','enviando'),true)||(int)$fresh['proxima']>time()){continue;}$row=$fresh;$lead=F3Base_Leads_Repositorio::obter($row['record_id']);$stage=self::etapa($row['etapa']);$payload=F3Base_Capi_Fila::abrir_payload($row['payload']);
            $why='';if(!$lead||!$stage||!$payload){$why='contato_etapa_ou_payload_ausente';}elseif((int)$row['expira']<time()){$why='evento_expirado';}elseif($row['config_revisao']!==F3Base_Options::revisao(self::OPCAO)||$row['credencial_revisao']!==F3Base_Options::revisao(self::credencial())){$why='configuracao_alterada_revisar';}elseif(empty(($elig=self::elegibilidade($lead,$stage,(int)$payload['evento']['event_time']))['ok'])){$why=$elig['codigo'];}
            if($why){$wpdb->update(self::tabela('fila'),array('estado'=>'suspenso','codigo'=>$why,'atualizado_em'=>time()),array('chave'=>$row['chave']));continue;}
            if(in_array($row['estado'],array('enviando','incerto'),true)&&time()-(int)$payload['evento']['event_time']>172500){$wpdb->update(self::tabela('fila'),array('estado'=>'revisao','codigo'=>'incerto_fora_janela_deduplicacao'),array('chave'=>$row['chave']));continue;}
            $claimed=$wpdb->update(self::tabela('fila'),array('estado'=>'enviando','tentativas'=>(int)$row['tentativas']+1,'proxima'=>time()+60,'atualizado_em'=>time()),array('chave'=>$row['chave'],'estado'=>$row['estado']));if($claimed!==1){continue;}
            $r=self::graph_qualidade('POST',$row['dataset'],$payload['versao_api'],array('data'=>array($payload['evento'])),(int)(self::$prazo-microtime(true)-1));
            $state=!empty($r['ok'])?'entregue':(!empty($r['incerto'])?'incerto':(!empty($r['temporario'])?'pendente':'falhou'));if((int)$row['tentativas']>=9&&$state!=='entregue'){$state='revisao';}
            $wpdb->update(self::tabela('fila'),array('estado'=>$state,'codigo'=>$r['codigo'].'_'.(int)($r['code']??0).'_'.(int)($r['subcode']??0),'http'=>$r['http']??0,'proxima'=>time()+max((int)($r['retry_after']??60),min(21600,60*2**min(8,(int)$row['tentativas']))),'atualizado_em'=>time()),array('chave'=>$row['chave']));$count++;
        }finally{F3Base_Trava::liberar($lock);}}
        return array('tentativas'=>$count);
    }
    public static function atualizar(array $e=array()): array {
        $internal=!empty($e['interno']);if(!$internal&&!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}if(!$internal&&($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'ordem'=>array('captacao_meta','recibos_crm','consulta_crm','envio_meta'),'limite_segundos'=>20);}
        if(!self::config()['ativo']){return array('ok'=>true,'codigo'=>'qualidade_desligada');}$lock=F3Base_Trava::adquirir('qualidade-lote',30);if(!$lock){return array('ok'=>true,'codigo'=>'execucao_ocupada');}self::$prazo=microtime(true)+min(20,F3Base_Execucoes::restante_ms(1500)/1000);
        try{$out=array();if(!$internal){$record=!empty($e['record_id'])?F3Base_Leads_Repositorio::obter($e['record_id']):null;$native=$record['dados']['origem_nativa']??array();if(empty($e['record_id'])){$out['captacao_meta']=F3Base_Anuncios::consultar(min(self::$prazo-10,microtime(true)+8));}elseif(($native['origem']??'')==='meta'&&(string)($native['conta_id']??'')===(string)(F3Base_Options::ler('f3base_anuncios_meta')['conta_id']??'')){$out['captacao_meta']=F3Base_Anuncios::consultar(min(self::$prazo-10,microtime(true)+8),(string)$native['formulario_id']);}else{$out['captacao_meta']=array('ok'=>true,'codigo'=>'importacao_nao_aplicavel_ao_contato');}}F3Base_Pipedrive_Api::iniciar_lote();F3Base_Pipedrive_Api::limitar_prazo(self::$prazo-3);$out['recibos']=self::recibos();$out['crm']=self::consultar_crm((string)($e['record_id']??''));$out['meta']=self::enviar();$out['ok']=!empty($out['crm']['ok'])&&(!isset($out['captacao_meta'])||!empty($out['captacao_meta']['ok']));$out['parcial']=!empty($out['captacao_meta']['parcial'])||!empty($out['crm']['parcial'])||microtime(true)>self::$prazo-4;$out['codigo']=$out['parcial']?'lote_parcial':($out['ok']?'lote_concluido':'lote_com_pendencias');$out['em']=time();F3Base_Options::atualizar_estado('f3base_qualidade_estado',static fn($s)=>array_merge($s,array('ultima_passagem'=>$out)));return $out;}
        finally{F3Base_Pipedrive_Api::limitar_prazo(0);F3Base_Meta_Acesso::limitar_prazo(0);F3Base_Fila::agendar(self::HOOK,time()+300);F3Base_Trava::liberar($lock);}
    }
    public static function catalogos_remotos(): array {return F3Base_Qualidade_Catalogo::carregar(array('simular'=>false));}
}
