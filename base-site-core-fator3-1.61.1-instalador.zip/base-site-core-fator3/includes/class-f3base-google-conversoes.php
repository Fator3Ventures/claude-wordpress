<?php
/** Google 1.1 negotiation. Personal identifiers exist only in worker/preview memory. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Google_Conversoes {
    const CONTRACT='site-conversion-delivery/1.1.0';
    public static function selecionar(): array {
        $a=F3Base_Conversoes_Servidor::adaptador('google_ads');$cap=$a?$a->capabilities():array();$cap=is_array($cap)?$cap:array();
        if(($cap['contract']??'')===F3Base_Conversoes_Servidor::CONTRATO&&in_array(self::CONTRACT,$cap['supported_contracts']??array(),true)&&($cap['enhanced_leads']['supported']??false)===true){
            $new=F3Base_Conversoes_Servidor::adaptador('google_ads',self::CONTRACT);$v=$new?$new->capabilities():array();
            if(is_array($v)&&($v['contract']??'')===self::CONTRACT&&($v['destination_ref']??'')===($cap['destination_ref']??'')&&in_array(self::CONTRACT,$v['supported_contracts']??array(),true)){$a=$new;$cap=$v;}
        }
        return array('adapter'=>$a,'cap'=>$cap);
    }
    public static function suporta(array $cap): bool {
        $e=$cap['enhanced_leads']??array();return ($cap['contract']??'')===self::CONTRACT&&($e['supported']??false)===true&&in_array(self::CONTRACT,$cap['supported_contracts']??array(),true)&&!array_diff(array('email','telefone'),$e['user_data_fields']??array());
    }
    public static function pronta(array $cap): bool {
        $e=$cap['enhanced_leads']??array();
        return self::suporta($cap)&&($cap['ready']??false)===true&&($e['ready']??false)===true&&($e['accepted_customer_data_terms']??false)===true&&($e['enabled']??false)===true&&is_int($e['checked_at']??null)&&$e['checked_at']>0&&$e['checked_at']<=time()&&is_int($e['expires_at']??null)&&$e['expires_at']>time()&&preg_match('/^[0-9]{10}$/D',(string)($e['customer_id']??''))&&preg_match('~^customers/'.preg_quote((string)$e['customer_id'],'~').'/conversionActions/[0-9]+$~D',(string)($e['conversion_action']??''));
    }
    public static function dados(array $lead): array {
        $out=array();$email=strtolower(trim((string)($lead['email']??'')));
        if(is_email($email)){$out['email']=$email;}
        $d=$lead['dados']??array();if(!F3Base_Telefone::nao_normalizado($d)){$phone=F3Base_Pipedrive_Api::telefone((string)($d['telefone']??''),(string)($d['telefone_normalizacao']['pais']??'BR'));if(preg_match('/^\+[1-9][0-9]{7,14}$/D',$phone)){$out['telefone']=$phone;}}
        return $out;
    }
    /** Mirrors the provider's announced normalization only for the private preview. */
    public static function hashes(array $data): array {
        $out=array();if(isset($data['email'])){[$local,$domain]=explode('@',$data['email'],2);if(in_array($domain,array('gmail.com','googlemail.com'),true)){$local=str_replace('.','',$local);}$out[]=array('hashedEmail'=>hash('sha256',$local.'@'.$domain));}
        if(isset($data['telefone'])){$out[]=array('hashedPhoneNumber'=>hash('sha256',$data['telefone']));}return $out;
    }
    public static function montar(array $lead,array $cap): array {
        $a=$lead['dados']['atribuicao']??array();$ids=array();foreach(array('gclid','gbraid','wbraid') as $key){if(is_string($a[$key]??null)&&preg_match('/^[A-Za-z0-9._~-]{1,500}$/D',$a[$key])){$ids[$key]=$a[$key];}}
        if(count($ids)>1){return array('ok'=>false,'codigo'=>'identificador_clique_ambiguo');}
        if($ids){$click=(int)($a['ultimo_toque_em']??$a['primeiro_toque_em']??0);$time=strtotime($lead['criado_em'].' UTC');if($click<=0||$click>time()||$click>$time){return array('ok'=>false,'codigo'=>'instante_clique_invalido');}if(time()-$click>90*DAY_IN_SECONDS){return array('ok'=>false,'codigo'=>'clique_expirado');}}
        $data=self::pronta($cap)?self::dados($lead):array();
        if(!$ids&&!$data){return array('ok'=>false,'codigo'=>self::suporta($cap)?(self::pronta($cap)?'enhanced_leads_user_data_invalid':'enhanced_leads_not_ready'):'identificador_clique_ausente');}
        $p=array('click_ids'=>$ids,'order_id'=>$lead['record_id'],'ad_user_data'=>'GRANTED','value'=>0,'currency'=>'BRL');if($data){$p['user_data']=$data;}
        return array('ok'=>true,'payload'=>$p);
    }
    public static function previa(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $lead=F3Base_Leads_Repositorio::obter($e['record_id']);if(!$lead||($lead['captura']??'')!=='aceito'||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])){return array('ok'=>false,'codigo'=>'registro_inelegivel');}
        try{$selection=self::selecionar();$cap=$selection['cap'];}catch(Throwable $x){$cap=array();}
        $cons=F3Base_Contato_Apresentacao::consentimento_atual($lead['dados']);$allowed=!empty($cons['publicidade'])&&!empty($lead['dados']['consentimento_snapshot']['publicidade']);
        $data=$allowed&&self::suporta($cap)?self::dados($lead):array();$prep=F3Base_Conversoes_Servidor::preparar($lead,'google_ads',$cap);
        $payload=$prep['payload']??null;if(is_array($payload)){unset($payload['user_data']);if(isset($payload['click_ids'])){$payload['click_ids']=array_keys($payload['click_ids']);}}
        return array('ok'=>true,'simulacao'=>true,'envio_realizado'=>false,'contract'=>$cap['contract']??null,'elegivel_envio'=>!empty($prep['ok'])&&!empty($cap['ready']),'codigo'=>$prep['codigo']??($cap['reason']??'adaptador_indisponivel'),'enhanced_leads_pronta'=>self::pronta($cap),'motivo_google'=>F3Base_Conversoes_Servidor::codigo($cap['enhanced_leads']['reason']??null,'capacidade_ausente'),'userIdentifiers'=>self::hashes($data),'payload'=>$payload,'limite'=>'Hashes demonstrativos; Google normaliza novamente em memória. Testes, consentimento, prazo, destino e resultados incertos conservam seus bloqueios. Nenhuma fila é criada.');
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('google-conversao-previa','Prévia privada com hashes e motivos, inclusive para contato de teste; sem enfileirar ou enviar',array(__CLASS__,'previa'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));});
    }
}
