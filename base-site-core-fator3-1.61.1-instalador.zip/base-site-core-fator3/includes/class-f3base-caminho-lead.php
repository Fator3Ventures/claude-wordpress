<?php
/** On-demand lead path. Every side effect has a durable, private, one-use receipt. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Caminho_Lead {
    const HOOK='f3base_caminho_lead_processar';
    private static string $record='';
    private static string $fase='';
    private static ?array $atual=null;
    private static ?bool $schema=null;
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_caminho_lead';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta('CREATE TABLE '.self::tabela()." (\nid char(64) NOT NULL,\nintencao char(64) NOT NULL,\nrevisao char(64) NOT NULL,\nator bigint unsigned NOT NULL,\nestado varchar(32) NOT NULL,\nversao bigint unsigned NOT NULL DEFAULT 1,\npasso int unsigned NOT NULL DEFAULT 0,\nproxima bigint unsigned NOT NULL,\ncriado_em bigint unsigned NOT NULL,\natualizado_em bigint unsigned NOT NULL,\nentrada longtext NOT NULL,\nrecibo longtext NOT NULL,\nPRIMARY KEY  (id),\nKEY agenda (estado,proxima)\n) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');
        self::$schema=!$wpdb->last_error&&$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela();return self::$schema;
    }
    private static function pronta(): bool {if(self::$schema===null){global $wpdb;self::$schema=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela();}return self::$schema;}
    private static function row(string $id): ?array {if(!self::pronta()){return null;}global $wpdb;$r=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s',self::tabela(),$id),ARRAY_A);if(!$r){return null;}$r['recibo']=json_decode($r['recibo'],true)?:array();return $r;}
    public static function pertence(string $record): bool {
        if(!preg_match('/^[a-f0-9]{32}$/D',$record)||!self::pronta()){return false;}
        global $wpdb;return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM %i WHERE JSON_SEARCH(recibo,'one',%s,NULL,'$.registros[*].record_id') IS NOT NULL LIMIT 1",self::tabela(),$record));
    }
    /** Only the owned record in this worker may reach a transport. No global homologation toggle. */
    public static function permitido(string $record,string $destino): bool {
        if(!self::pertence($record)){return true;}
        if(self::$record!==$record){return false;}
        return ($destino==='email'&&in_array(self::$fase,array('aviso_email','email_automatico'),true))||($destino==='email_limpeza'&&self::$fase==='limpeza_email')||($destino==='pipedrive'&&in_array(self::$fase,array('captura','pipedrive'),true))||($destino==='slack'&&self::$fase==='aviso')||($destino==='eliminacao'&&self::$fase==='limpeza_pipedrive');
    }
    public static function homologacao(string $record): bool {return self::$record===$record&&self::pertence($record)&&self::site_crm()&&in_array(self::$fase,array('captura','pipedrive'),true);}
    public static function site_crm(): bool {return in_array(preg_replace('/^www\./','',strtolower((string)wp_parse_url(home_url('/'),PHP_URL_HOST))),array('ctooffice.com.br','korvena.com.br'),true);}
    private static function erro(string $code): array {return array('ok'=>false,'codigo'=>$code);}
    public static function schema_entrada(): array {return array('formulario'=>array('type'=>'string','maxLength'=>100),'campos'=>array('type'=>'object','maxProperties'=>50,'additionalProperties'=>array('oneOf'=>array(array('type'=>'string','maxLength'=>2000),array('type'=>'array','maxItems'=>30,'items'=>array('type'=>'string','maxLength'=>300))))),'nativo'=>array('type'=>'string','enum'=>array('','meta','linkedin'),'default'=>''),'atribuicao'=>array('type'=>'object','maxProperties'=>40,'additionalProperties'=>array('type'=>'string','maxLength'=>500)),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'chave_operacao'=>array('type'=>'string','pattern'=>'^[A-Za-z0-9._:-]{8,128}$'));}
    private static function entrada(array $e): array {
        $v=rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::schema_entrada(),'required'=>array('formulario')));if(is_wp_error($v)){return self::erro('entrada_invalida');}
        $f=F3Base_Formularios::obter($e['formulario']);if(!$f){return self::erro('formulario_indisponivel');}
        $q=array('formulario'=>$e['formulario'],'campos'=>$e['campos']??array(),'nativo'=>$e['nativo']??'','atribuicao'=>$e['atribuicao']??array());
        $campos=self::campos($f,$q,'previa');$valid=F3Base_Formularios::validar_campos($f,$campos);if(empty($valid['ok'])){return self::erro($valid['codigo']??'campos_invalidos')+array('campo'=>$valid['campo']??null);}
        return array('ok'=>true,'entrada'=>$q,'formulario'=>$f);
    }
    private static function campos(array $f,array $e,string $seed): array {
        $out=$e['campos'];foreach($f['campos'] as $c){$role=$c['papel']??'';if($role==='nome'){$out[$c['nome']]='[TESTE F3BASE] Caminho '.$seed;}elseif(in_array($role,array('email','contato'),true)){$out[$c['nome']]='f3-caminho-'.$seed.'@example.invalid';}elseif($role==='empresa'){$out[$c['nome']]='[TESTE F3BASE] Empresa '.$seed;}}
        return $out;
    }
    private static function revisao(array $q): string {
        $v=array(home_url('/'),$q,F3Base_Formularios::obter($q['formulario']),F3BASE_PLUGIN_VERSAO,F3Base_Integracoes::identidade_pipedrive());
        foreach(array('f3base_pipedrive','f3base_avisos','f3base_testes','f3base_email_novo_lead','f3base_email_site','f3base_email_site_senha','f3base_contato','f3base_slack_bot_token','f3base_avisos_webhook_url','f3base_avisos_webhook_chave') as $n){$v[$n]=F3Base_Options::revisao($n);}return hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($v)));
    }
    private static function plano(array $q): array {
        $c=F3Base_Options::ler('f3base_pipedrive');$a=F3Base_Options::ler('f3base_avisos');$s=F3Base_Conversoes_Contexto::snapshot();
        return array('captura'=>array('estado'=>'previa','codigo'=>'validacao_e_persistencia_do_formulario','formulario'=>$q['formulario'],'nativo'=>$q['nativo'],'navegador_comprovado'=>false),'aviso_email'=>F3Base_Caminho_Email::disponibilidade(),'aviso_slack'=>array('estado'=>in_array($a['canal']??'',array('slack','ambos'),true)&&($a['slack_transporte']??'')==='app'?'previa':'bloqueado','codigo'=>'exige_app_com_leitura_e_exclusao_autoral'),'aviso_webhook'=>array('estado'=>'bloqueado','codigo'=>'webhook_sem_contrato_de_limpeza'),'pipedrive'=>array('estado'=>!empty($c['ativo'])&&self::site_crm()?'previa':'bloqueado','codigo'=>empty($c['ativo'])?'integracao_desligada':(!self::site_crm()?'site_fora_da_homologacao_autorizada':'homologacao_por_registro'),'homologacao_original'=>(bool)($c['homologacao']??false),'opcao_global_alterada'=>false),'email_automatico'=>F3Base_Caminho_Email::disponibilidade(),'conversoes'=>array('estado'=>'somente_previa','envio_real'=>false,'contexto'=>$s),'limpeza'=>array('estado'=>'prevista','escopo'=>'Somente IDs registrados pelo teste e com autoria relida; objetos preexistentes são preservados.'));
    }
    public static function testar(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_gerir_leads')){return self::erro('sem_permissao');}
        $x=self::entrada($e);if(empty($x['ok'])){return $x;}$q=$x['entrada'];$rev=self::revisao($q);$intent=hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($q)));
        if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'revisao'=>$rev,'plano'=>self::plano($q),'efeitos'=>false);}
        if(!preg_match('/^[A-Za-z0-9._:-]{8,128}$/D',$e['chave_operacao']??'')){return self::erro('chave_operacao_obrigatoria');}
        if(!self::pronta()){return self::erro('estrutura_indisponivel');}$id=hash('sha256',home_url('/').'|caminho-lead|'.$e['chave_operacao']);
        $lock=F3Base_Trava::adquirir('caminho-'.$id,120);if(!$lock){return self::erro('teste_ocupado');}
        try{$old=self::row($id);if($old){return $old['intencao']===$intent&&hash_equals($old['revisao'],(string)($e['revisao']??''))?self::publico($old)+array('repetida'=>true):self::erro('chave_operacao_reutilizada');}
            global $wpdb;if((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE estado NOT IN ('concluido','com_pendencias')",self::tabela()))>0){return self::erro('outro_teste_em_curso');}
            if(!hash_equals($rev,(string)($e['revisao']??''))){return self::erro('revisao_alterada')+array('revisao'=>$rev);}
            $records=array(array('record_id'=>substr(hash('sha256',$id.'|site'),0,32),'origem'=>'site'));if($q['nativo']!==''){$records[]=array('record_id'=>substr(hash('sha256',$id.'|nativo'),0,32),'origem'=>$q['nativo']);}
            $r=array('id'=>$id,'intencao'=>$intent,'revisao'=>$rev,'ator'=>get_current_user_id(),'estado'=>'pendente','versao'=>1,'passo'=>0,'proxima'=>time(),'criado_em'=>time(),'atualizado_em'=>time(),'entrada'=>F3Base_Contato_Comunicacao::cifrar($q),'recibo'=>array('versao'=>2,'registros'=>$records,'saltos'=>array(),'limpeza'=>array(),'exclusoes'=>array(),'homologacao_original'=>(bool)(F3Base_Options::ler('f3base_pipedrive')['homologacao']??false),'opcao_global_alterada'=>false,'limites'=>array('Captura administrativa valida os campos e persiste pelo repositório real; não exercita navegador, desafio antispam ou APIs nativas.','E-mails usam somente a caixa própria explicitamente homologada, sem Cco/Smart Bcc, com UIDPLUS e prova de exclusão. Webhook permanece sem contrato de limpeza.')));
            global $wpdb;$row=$r;$row['recibo']=wp_json_encode($row['recibo']);if(!$r['entrada']||$wpdb->insert(self::tabela(),$row)!==1){return self::erro('recibo_nao_persistido');}
            self::agendar($id,time()+1);return self::publico($r);
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function publico(array $r): array {return array('ok'=>true,'id'=>$r['id'],'estado'=>$r['estado'],'passo'=>(int)$r['passo'],'criado_em'=>(int)$r['criado_em'],'atualizado_em'=>(int)$r['atualizado_em'],'proxima'=>(int)$r['proxima'],'recibo'=>$r['recibo'],'resultado_final'=>in_array($r['estado'],array('concluido','com_pendencias'),true),'revisao'=>$r['revisao']);}
    public static function ler(array $e): array {if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return self::erro('sem_permissao');}$r=self::row((string)($e['id']??''));return $r?self::publico($r):self::erro('teste_nao_encontrado');}
    public static function schema_limpeza(): array {return array('id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'chave_operacao'=>array('type'=>'string','pattern'=>'^[A-Za-z0-9._:-]{8,128}$'));}
    /** An administrator can resume only erasure after suspension, revocation or a terminal partial result. */
    public static function limpar(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_gerir_leads')){return self::erro('sem_permissao');}
        $v=rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::schema_limpeza(),'required'=>array('id')));if(is_wp_error($v)){return self::erro('entrada_invalida');}
        $lock=F3Base_Trava::adquirir('caminho-'.$e['id'],120);if(!$lock){return self::erro('teste_ocupado');}
        try{$r=self::row($e['id']);if(!$r){return self::erro('teste_nao_encontrado');}$rev=hash('sha256',wp_json_encode(array($r['id'],$r['versao'],home_url('/'),F3Base_Integracoes::identidade_pipedrive())));
            if(($e['simular']??true)!==false){return array('ok'=>true,'simulado'=>true,'id'=>$r['id'],'revisao'=>$rev,'efeitos'=>false,'registros'=>$r['recibo']['registros'],'codigo'=>'limpeza_somente_ids_conhecidos_sem_repetir_saltos_incertos');}
            if(!preg_match('/^[A-Za-z0-9._:-]{8,128}$/D',$e['chave_operacao']??'')){return self::erro('chave_operacao_obrigatoria');}$operation=hash('sha256',$e['chave_operacao']);$old=$r['recibo']['limpezas_solicitadas'][$operation]??null;if($old){return hash_equals($old['revisao'],(string)($e['revisao']??''))?self::publico($r)+array('repetida'=>true):self::erro('chave_operacao_reutilizada');}
            if(!hash_equals($rev,(string)($e['revisao']??''))){return self::erro('revisao_alterada')+array('revisao'=>$rev);}
            foreach(self::passos($r) as [$record,$phase]){$key=$record['record_id'];$kind=str_starts_with($phase,'limpeza_')?'limpeza':'saltos';$item=$r['recibo'][$kind][$key][$phase]??null;
                if($kind==='saltos'&&!$item){$r['recibo'][$kind][$key][$phase]=array('estado'=>'bloqueado','codigo'=>'interrompido_para_limpeza','em'=>time());}
                elseif(($item['estado']??'')==='iniciada'){$r['recibo'][$kind][$key][$phase]=array('estado'=>'incerto','codigo'=>'execucao_interrompida_nao_repetida','em'=>time());}
                elseif($kind==='limpeza'&&in_array($item['estado']??'',array('bloqueado','aguardando'),true)){$r['recibo']['limpezas_anteriores'][$operation][$key][$phase]=$item;unset($r['recibo'][$kind][$key][$phase]);}
            }
            $r['recibo']['limpezas_solicitadas'][$operation]=array('revisao'=>$rev,'ator'=>get_current_user_id(),'em'=>time());$r['ator']=get_current_user_id();$r['estado']='pendente';$r['passo']=count($r['recibo']['registros'])*(($r['recibo']['versao']??1)>=2?7:6);$r['proxima']=time()+1;
            if(!self::salvar($r)){return self::erro('reserva_nao_persistida');}wp_clear_scheduled_hook(self::HOOK,array($r['id']));self::agendar($r['id'],$r['proxima']);return self::publico($r);
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function salvar(array &$r): bool {global $wpdb;$before=(int)($r['versao']??1);$r['versao']=$before+1;$r['atualizado_em']=time();$v=array_intersect_key($r,array_flip(array('estado','passo','proxima','atualizado_em','entrada','versao','ator')));$v['recibo']=wp_json_encode($r['recibo']);$n=$wpdb->update(self::tabela(),$v,array('id'=>$r['id'],'versao'=>$before));return $n===1;}
    private static function agendar(string $id,int $at): void {if(!wp_next_scheduled(self::HOOK,array($id))){wp_schedule_single_event(max(time()+1,$at),self::HOOK,array($id));}}
    private static function passos(array $r): array {
        $steps=array();foreach($r['recibo']['registros'] as $entry){foreach((($r['recibo']['versao']??1)>=2?array('captura','aviso','aviso_email','pipedrive','conferencia_crm','email_automatico','conversoes'):array('captura','aviso','pipedrive','conferencia_crm','email_automatico','conversoes')) as $phase){$steps[]=array($entry,$phase);}}
        foreach(array('limpeza_email','limpeza_slack','limpeza_local','limpeza_pipedrive') as $phase){foreach($r['recibo']['registros'] as $entry){$steps[]=array($entry,$phase);}}return $steps;
    }
    /** Reserve each hop before acting. A lost process cannot repeat that hop. */
    public static function processar(string $id): array {
        $lock=F3Base_Trava::adquirir('caminho-'.$id,120);if(!$lock){return self::erro('teste_ocupado');}$previous=get_current_user_id();
        try{$r=self::row($id);if(!$r){return self::erro('teste_nao_encontrado');}if(in_array($r['estado'],array('concluido','com_pendencias'),true)){return self::publico($r);}
            if(!user_can((int)$r['ator'],'manage_options')||!user_can((int)$r['ator'],'f3base_gerir_leads')){$r['estado']='autorizacao_revogada';$r['proxima']=0;self::salvar($r);return self::publico($r);}
            wp_set_current_user((int)$r['ator']);$steps=self::passos($r);$entry=$steps[(int)$r['passo']]??null;
            if(!$entry){$bad=false;foreach(array('saltos','limpeza') as $kind){foreach($r['recibo'][$kind] as $items){foreach($items as $x){if(!in_array($x['estado'],array('confirmado','nao_aplicavel','previa'),true)){$bad=true;}}}}$r['estado']=$bad?'com_pendencias':'concluido';$r['proxima']=0;$r['entrada']='';self::salvar($r);return self::publico($r);}
            [$record,$phase]=$entry;$key=$record['record_id'];$kind=str_starts_with($phase,'limpeza_')?'limpeza':'saltos';$old=$r['recibo'][$kind][$key][$phase]??null;
            if($kind==='limpeza'&&$old&&!in_array($old['estado'],array('iniciada','aguardando'),true)){$r['passo']++;$r['proxima']=time()+1;$r['estado']='pendente';if(self::salvar($r)){self::agendar($id,$r['proxima']);}return self::publico($r);}
            if(($old['estado']??'')==='iniciada'){$r['recibo'][$kind][$key][$phase]=array('estado'=>'incerto','codigo'=>'execucao_interrompida_nao_repetida','em'=>time());$r['passo']++;$r['proxima']=time()+1;$r['estado']='pendente';if(self::salvar($r)){self::agendar($id,$r['proxima']);}return self::publico($r);}
            if((int)$r['proxima']>time()){self::agendar($id,(int)$r['proxima']);return self::publico($r);}
            $q=$kind==='limpeza'?array():F3Base_Contato_Comunicacao::abrir($r['entrada']);if($kind!=='limpeza'&&!$q){$result=array('estado'=>'bloqueado','codigo'=>'entrada_ilegivel');}
            elseif($kind==='saltos'&&$r['revisao']!==self::revisao($q)){$result=array('estado'=>'bloqueado','codigo'=>'configuracao_alterada');}
            else{
                $r['recibo'][$kind][$key][$phase]=array('estado'=>'iniciada','em'=>time());$r['estado']='executando';$r['proxima']=time()+125;if(!self::salvar($r)){return self::erro('reserva_nao_persistida');}self::agendar($id,$r['proxima']);
                self::$record=$key;self::$fase=$phase;self::$atual=&$r;
                try{$result=self::executar($r,$record,$phase,$q);}catch(Throwable $x){$result=array('estado'=>'incerto','codigo'=>'salto_interrompido_nao_repetir');}
            }
            $attempt=(int)($old['tentativas']??0)+1;$again=!empty($result['continuar'])&&$attempt<12;unset($result['continuar']);if(!$again&&($result['estado']??'')==='aguardando'){$result['estado']='bloqueado';$result['codigo']='tentativas_sem_conclusao';}$r['recibo'][$kind][$key][$phase]=$result+array('em'=>time(),'tentativas'=>$attempt);$r['estado']='pendente';if(!$again){$r['passo']++;}$r['proxima']=$again?max(time()+5,(int)($result['tentar_em']??0)):time()+($phase==='captura'?11:1);if(!self::salvar($r)){return self::erro('resultado_nao_persistido_incerto');}
            wp_clear_scheduled_hook(self::HOOK,array($id));self::agendar($id,$r['proxima']);return self::publico($r);
        }finally{self::$atual=null;self::$record='';self::$fase='';wp_set_current_user($previous);F3Base_Trava::liberar($lock);}
    }
    private static function executar(array &$r,array $record,string $phase,array $q): array {
        $id=$record['record_id'];$lead=F3Base_Leads_Repositorio::obter($id);
        if($phase==='captura'){
            if($lead){return array('estado'=>'incerto','codigo'=>'record_id_ja_existe_nao_sobrescrever');}
            $f=F3Base_Formularios::obter($q['formulario']);$fields=self::campos($f,$q,substr($id,0,12));$v=F3Base_Formularios::validar_campos($f,$fields);if(empty($v['ok'])){return array('estado'=>'bloqueado','codigo'=>$v['codigo']??'campos_invalidos');}
            $p=$v['papeis'];$native=$record['origem']!=='site';$attr=F3Base_Atribuicao::normalizar($q['atribuicao']);if($native){$attr['modelo']='informado';$attr['entrada']='';$attr['pagina']='';$attr['plataforma']=$record['origem']==='meta'?'meta_ads':'linkedin_ads';}
            $a=F3Base_Options::ler('f3base_avisos');$notify=in_array($a['canal']??'',array('slack','ambos'),true)&&($a['slack_transporte']??'')==='app';
            $d=array('record_id'=>$id,'caminho_teste_id'=>$r['id'],'contexto_teste'=>true,'classe_trafego'=>'teste','formulario'=>$f['id'],'formulario_revisao'=>hash('sha256',wp_json_encode($f)),'formulario_titulo'=>$f['titulo'],'campos_snapshot'=>$f['campos'],'campos'=>$v['limpos'],'nome'=>'[TESTE F3BASE] Caminho '.substr($id,0,12),'email'=>$p['email']??('f3-caminho-'.substr($id,0,12).'@example.invalid'),'telefone'=>$p['telefone']??'','empresa'=>$p['empresa']??'','cargo'=>$p['cargo']??'','servicos'=>(array)($p['servico']??$f['servico_fixo']??array()),'metodo'=>$native?'anuncio_'.$record['origem']:(array('registro'=>'formulario','whatsapp'=>'whatsapp_formulario','conteudo'=>'conteudo')[$f['regime']??'registro']),'captura'=>'aceito','atribuicao'=>$attr,'pagina'=>'','sessao'=>null,'consentimento_snapshot'=>array('publicidade'=>false,'medicao'=>false),'conversoes_bloqueadas'=>true,'notificar'=>$notify,'assunto'=>'[TESTE F3BASE] Caminho do lead','anexos'=>array(),'resposta_visitante'=>array('ativa'=>false));
            if($native){$d['origem_nativa']=array('origem'=>$record['origem'],'lead_id'=>'teste-caminho-'.substr($id,0,12),'formulario_id'=>'teste-caminho','campanha_id'=>$attr['campanha_id'],'simulado'=>true);}
            $saved=F3Base_Leads_Repositorio::guardar($d,hash('sha256',$r['id'].'|'.$id));$fresh=F3Base_Leads_Repositorio::obter($id);return array('estado'=>!empty($saved['persisted'])&&$fresh&&$fresh['classe_trafego']==='teste'?'confirmado':'incerto','codigo'=>$saved['codigo']??'contato_gravado','record_id'=>$id,'metodo'=>$fresh['metodo']??null,'sessao'=>$fresh['sessao']??null,'nativo_simulado'=>$native,'navegador_comprovado'=>false);
        }
        if(!str_starts_with($phase,'limpeza_')&&($r['recibo']['saltos'][$id]['captura']['estado']??'')!=='confirmado'){return array('estado'=>'bloqueado','codigo'=>'captura_nao_confirmada');}
        if($phase==='aviso'){
            $a=F3Base_Options::ler('f3base_avisos');$result=array('email'=>array('estado'=>'salto_proprio','codigo'=>'consulte_aviso_email'),'webhook'=>array('estado'=>'bloqueado','codigo'=>'webhook_sem_contrato_de_limpeza'));
            if(!$lead){return array('estado'=>'bloqueado','codigo'=>'contato_indisponivel')+$result;}
            if(!in_array($a['canal']??'',array('slack','ambos'),true)||($a['slack_transporte']??'')!=='app'){return array('estado'=>'bloqueado','codigo'=>'slack_app_nao_configurado')+$result;}
            if(F3Base_Testes::politica('slack','teste')==='suprimir'){return array('estado'=>'bloqueado','codigo'=>'suprimido_teste','configuracao'=>array('opcao'=>'f3base_testes','campo'=>'destinos.slack','valor'=>F3Base_Testes::config()['destinos']['slack'],'politica_efetiva'=>'suprimir'))+$result;}
            F3Base_Avisos::processar($id);$rows=F3Base_Avisos::consultar(array('record_id'=>$id))['linhas']??array();$state=$rows[0]['estado']??'';$parts=F3Base_Slack_Manutencao::listar(array('record_id'=>$id,'teste'=>true));
            $uncertain=$state==='incerto'||array_filter($rows[0]['partes']??array(),static fn($x)=>in_array($x['estado']??'',array('incerto','enviando'),true));$again=$state==='pendente'&&!$uncertain;return array('estado'=>$state==='entregue'?'confirmado':($uncertain?'incerto':($again?'aguardando':'bloqueado')),'continuar'=>$again,'tentar_em'=>(int)($rows[0]['proxima']??0),'codigo'=>$rows[0]['codigo']??'aviso_sem_recibo','mensagens'=>array_map(static fn($x)=>array_intersect_key($x,array_flip(array('id','canal','ts','estado'))),$parts['linhas']))+$result;
        }
        if($phase==='pipedrive'){
            if(empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])){return array('estado'=>'bloqueado','codigo'=>'integracao_desligada');}if(!self::site_crm()){return array('estado'=>'bloqueado','codigo'=>'site_fora_da_homologacao_autorizada');}if(!$lead){return array('estado'=>'bloqueado','codigo'=>'contato_indisponivel');}
            $job=self::crm_job($id);if($job&&in_array($job['estado'],array('incerto','enviando','revisao'),true)){return array('estado'=>$job['estado']!=='revisao'||!empty($job['etapa'])?'incerto':'bloqueado','codigo'=>$job['codigo']?:'crm_resultado_incerto_nao_repetir');}
            F3Base_Pipedrive_Fila::processar($id);$job=self::crm_job($id);$again=($job['estado']??'')==='pendente'&&empty($job['etapa']);return array('estado'=>($job['estado']??'')==='entregue'?'confirmado':((in_array($job['estado']??'',array('incerto','enviando'),true)||(($job['estado']??'')==='revisao'&&!empty($job['etapa'])))?'incerto':($again?'aguardando':'bloqueado')),'continuar'=>$again,'tentar_em'=>(int)($job['proxima']??0),'codigo'=>$job['codigo']??'crm_sem_intencao','chave'=>$job['chave']??null,'ids'=>$job['journal']['criados']??array(),'homologacao_restrita_ao_registro'=>true,'opcao_global_alterada'=>false);
        }
        if($phase==='conferencia_crm'){return self::conferir_crm($id,$lead);}
        if(in_array($phase,array('aviso_email','email_automatico','limpeza_email'),true)){return F3Base_Caminho_Email::executar($r,$id,$phase,$lead,static function(&$row){return self::salvar($row);});}
        if($phase==='conversoes'){
            $out=array();foreach(array('ga4','google_ads','linkedin') as $target){$x=$lead?F3Base_Conversoes_Servidor::preparar($lead,$target):array('codigo'=>'contato_indisponivel');$out[$target]=array('elegivel'=>!empty($x['ok']),'codigo'=>$x['codigo']??'preparado','envio_real'=>false);}$out['meta']=array('elegivel'=>false,'codigo'=>'caminho_teste_sem_envio','envio_real'=>false);
            return array('estado'=>'previa','codigo'=>'nenhuma_conversao_enviada','destinos'=>$out);
        }
        if($phase==='limpeza_slack'){
            $list=F3Base_Slack_Manutencao::listar(array('record_id'=>$id,'teste'=>true));if($list['proxima_pagina']){return array('estado'=>'bloqueado','codigo'=>'quantidade_mensagens_excede_limpeza_automatica');}$ids=array_column(array_filter($list['linhas'],static fn($x)=>!in_array($x['estado'],array('apagada','ausente'),true)),'id');if(!$ids){return array('estado'=>'confirmado','codigo'=>'sem_mensagem_restante');}if(count($ids)>20){return array('estado'=>'bloqueado','codigo'=>'quantidade_mensagens_excede_limpeza_automatica');}
            $p=F3Base_Slack_Manutencao::apagar(array('ids'=>$ids,'simular'=>true));if(empty($p['ok'])){return array('estado'=>'bloqueado','codigo'=>$p['codigo']??'slack_limpeza_indisponivel');}
            $x=F3Base_Slack_Manutencao::apagar(array('ids'=>$ids,'simular'=>false,'revisao'=>$p['revisao'],'chave_operacao'=>'caminho-'.$r['id'].'-'.$id));return array('estado'=>!empty($x['ok'])?'confirmado':(in_array($x['codigo']??'',array('core_em_recuperacao','slack_transporte_ocupado','auditoria_previa_falhou'),true)?'bloqueado':'incerto'),'codigo'=>$x['codigo']??'slack_limpeza_incerta','resultado'=>$x);
        }
        if($phase==='limpeza_local'){
            if(!$lead){return array('estado'=>'confirmado','codigo'=>'contato_ausente');}if(($lead['dados']['caminho_teste_id']??'')!==$r['id']||$lead['classe_trafego']!=='teste'){return array('estado'=>'bloqueado','codigo'=>'autoria_local_divergente');}
            $x=F3Base_Leads_Repositorio::eliminar($id,'teste');$fresh=F3Base_Leads_Repositorio::obter($id);return array('estado'=>!$fresh?'confirmado':'bloqueado','codigo'=>!$fresh?'contato_eliminado':'eliminacao_local_pendente');
        }
        if($phase==='limpeza_pipedrive'){
            $job=self::crm_job($id);if(!$job){return array('estado'=>'confirmado','codigo'=>'nenhum_objeto_crm_criado');}if(!self::site_crm()){return array('estado'=>'bloqueado','codigo'=>'site_fora_da_homologacao_autorizada');}
            F3Base_Pipedrive_Eliminacao::processar($id);$job=self::crm_job($id);$clean=$job['journal']['eliminacao_remota']??array();$again=($clean['estado']??'')==='pendente'&&($job['codigo']??'')==='eliminacao_remota_pendente';return array('estado'=>($clean['estado']??'')==='concluida'?'confirmado':($again?'aguardando':'bloqueado'),'continuar'=>$again,'tentar_em'=>time()+60,'codigo'=>$job['codigo']??'limpeza_crm_pendente','resultado'=>$clean);
        }
        return array('estado'=>'bloqueado','codigo'=>'passo_invalido');
    }
    private static function crm_job(string $id): ?array {global $wpdb;$r=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s ORDER BY atualizado_em DESC LIMIT 1',F3Base_Pipedrive_Fila::tabela(),$id),ARRAY_A);if($r){$r['journal']=json_decode($r['journal'],true)?:array();}return $r;}
    private static function conferir_crm(string $id,?array $lead): array {
        $job=self::crm_job($id);if(!$lead||!$job||($job['journal']['oportunidade']['tipo']??'')!=='lead'||empty($job['journal']['nucleo_confirmado_em'])){return array('estado'=>'bloqueado','codigo'=>'lead_crm_nao_confirmado');}
        if(!self::site_crm()){return array('estado'=>'bloqueado','codigo'=>'site_fora_da_homologacao_autorizada');}F3Base_Pipedrive_Api::iniciar_lote();$cfg=F3Base_Pipedrive_Api::configuracao_lote();$x=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$job['journal']['oportunidade']['id']);if(empty($x['ok'])){return array('estado'=>'bloqueado','codigo'=>$x['codigo']??'releitura_crm_falhou');}
        $wanted=F3Base_Pipedrive_Fila::campos(F3Base_Pipedrive_Fila::contexto($lead),$cfg);$fields=array();$ok=true;foreach(array('unidade','canal','parceiro','campanha','ponto') as $role){$field=$cfg['mapa_campos'][$role]??'';$expected=$field!==''?($wanted[$field]??null):null;$actual=$field!==''?($x['data']['custom_fields'][$field]??$x['data'][$field]??null):null;if(is_array($actual)){$actual=$actual['id']??$actual['value']??null;}$match=$expected!==null&&is_scalar($actual)&&(string)$actual===(string)$expected;$fields[$role]=array('estado'=>$match?'confirmado':'bloqueado','campo'=>$field,'codigo'=>$match?'relido_igual':($expected===null?'mapeamento_ausente':'valor_divergente'));$ok=$ok&&$match;}
        $activity=(int)($job['journal']['atividade']??$job['journal']['criados']['atividade']??0);$ar=$activity?F3Base_Pipedrive_Api::pedir('GET','v2/activities/'.$activity):array();$aok=!empty($ar['ok'])&&(string)($ar['data']['lead_id']??'')===(string)$job['journal']['oportunidade']['id'];return array('estado'=>$ok&&$aok?'confirmado':'bloqueado','codigo'=>$ok&&$aok?'campos_e_atividade_relidos':'conferencia_parcial','campos'=>$fields,'primeira_atividade'=>array('id'=>$activity?:null,'estado'=>$aok?'confirmado':'bloqueado'));
    }
    /** Durable DELETE intent, prior to the provider call; ambiguous deletion is never repeated. */
    public static function reservar_exclusao(string $record,string $method,string $path): bool {
        if(!self::pertence($record)){return true;}if(!self::permitido($record,'eliminacao')||self::$atual===null||$method!=='DELETE'){return false;}$key=hash('sha256',$path);if(isset(self::$atual['recibo']['exclusoes'][$record][$key])){return false;}self::$atual['recibo']['exclusoes'][$record][$key]=array('metodo'=>'DELETE','rota'=>$path,'em'=>time(),'estado'=>'solicitada');return self::salvar(self::$atual);
    }
    public static function filtro_fila(string $table,string $record=''): string {
        global $wpdb;if($record!==''){return $wpdb->prepare(' AND record_id=%s',$record);}if(!self::pronta()){return '';}if(!preg_match('/^[A-Za-z0-9_]+$/D',$table)){throw new InvalidArgumentException('tabela_invalida');}return $wpdb->prepare(" AND NOT EXISTS (SELECT 1 FROM %i caminho WHERE JSON_SEARCH(caminho.recibo,'one',`{$table}`.record_id,NULL,'$.registros[*].record_id') IS NOT NULL)",self::tabela());
    }
    public static function recuperar_agenda(): void {
        if(!self::pronta()){return;}global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT id,proxima FROM %i WHERE estado IN ('pendente','executando') ORDER BY proxima LIMIT 10",self::tabela()),ARRAY_A);foreach($rows?:array() as $r){self::agendar($r['id'],max(time()+1,(int)$r['proxima']));}
    }
    public static function iniciar(): void {
        add_action('init',array(__CLASS__,'recuperar_agenda'),96);
        add_action(self::HOOK,array(__CLASS__,'processar'),10,1);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('caminho-lead-testar','Teste sob demanda com prévia, revisão e recibo; nenhum envio de conversão e nenhuma repetição incerta',array(__CLASS__,'testar'),self::schema_entrada(),array('formulario'),false);F3Base_Servicos::ability('caminho-lead-limpar','Retoma somente limpeza autorizada de IDs conhecidos, com prévia e revisão; não repete efeitos incertos',array(__CLASS__,'limpar'),self::schema_limpeza(),array('id'),false);F3Base_Servicos::ability('caminho-lead-recibo-ler','Resultado dos saltos e limpezas do teste, sem campos pessoais',array(__CLASS__,'ler'),array('id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$')),array('id'));});
    }
}
