<?php
/** One durable observation per installation cycle, after executor confirmation. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pos_Atualizacao {
    const STATE='f3base_pos_atualizacao';const HOOK='f3base_pos_atualizacao_verificar';
    private static string $active='';
    public static function executando(string $step): bool {return self::$active===$step;}
    public static function catalogo(array $c): array {
        $c[self::STATE]=array('rotulo'=>'Provas após atualização','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;
    }
    private static function ciclo(): array {return (array)get_option(F3Base_Instalacao::OPTION,array());}
    public static function agendar(): void {
        $cycle=self::ciclo();if(($cycle['versao']??'')!==F3BASE_PLUGIN_VERSAO||empty($cycle['confirmada_no_executor_em'])||empty($cycle['ciclo'])){return;}
        $s=get_option(self::STATE,array());if(($s['ciclo']??'')!==$cycle['ciclo']||empty($s['concluida_em'])){F3Base_Fila::agendar(self::HOOK,max(time()+5,(int)($s['proxima']??0)));}
    }
    public static function executar(): array {
        $cycle=self::ciclo();if(($cycle['versao']??'')!==F3BASE_PLUGIN_VERSAO||empty($cycle['confirmada_no_executor_em'])||empty($cycle['ciclo'])){return array('ok'=>false,'codigo'=>'aguardando_confirmacao_executor');}
        $lock=F3Base_Trava::adquirir('pos-atualizacao',120);if(!$lock){return array('ok'=>false,'codigo'=>'prova_ocupada');}
        try{
            $s=get_option(self::STATE,array());if(($s['ciclo']??'')!==$cycle['ciclo']){$s=array('ciclo'=>$cycle['ciclo'],'versao'=>F3BASE_PLUGIN_VERSAO,'iniciada_em'=>time(),'etapas'=>array());}
            if(!empty($s['concluida_em'])){return array('ok'=>true,'codigo'=>'ciclo_ja_observado');}
            // Cache changes invalidate the navigation context: observe navigation after the purge.
            foreach(array('cabecalhos','navegacao','pipedrive') as $step){
                if(isset($s['etapas'][$step])){
                    if($s['etapas'][$step]['estado']==='reservado'){$s['etapas'][$step]=array('estado'=>'incerto','em'=>time(),'codigo'=>'executor_interrompido_sem_repeticao');self::salvar($s);}
                    continue;
                }
                if($step==='cabecalhos'){
                    $e=F3Base_Cache_Evidencia::ler();$after=max((int)($e['ultima_tentativa']['checked_at']??0),(int)($e['execucao']['iniciado_em']??0))+F3Base_Cache_Evidencia::INTERVALO;
                    if($after>time()){$s['proxima']=$after+1;self::salvar($s);F3Base_Fila::agendar(self::HOOK,$after+1);return array('ok'=>true,'codigo'=>'intervalo_minimo','proxima'=>$after+1);}
                }
                $s['etapas'][$step]=array('estado'=>'reservado','em'=>time(),'codigo'=>'prova_iniciada');unset($s['proxima']);
                if(!self::salvar($s)){return array('ok'=>false,'codigo'=>'reserva_nao_persistida');}
                self::$active=$step;
                try{
                    if($step==='navegacao'){$r=F3Base_Navegacao::verificar_apos_atualizacao();$ok=!empty($r['ok']);$code=$r['codigo']??$r['prova']['estado']??'navegacao_sem_prova';}
                    elseif($step==='cabecalhos'){$r=F3Base_Cache_Pagina::verificar_publico('pos_atualizacao',true);$v=F3Base_Options::verificar_configuracao('f3base_cabecalhos',F3Base_Options::ler('f3base_cabecalhos'));$ok=($v['status']??'')==='verified';$code=$ok?'cabecalhos_verificados':($v['codigo']??$r['codigo']??'cabecalhos_pendentes');}
                    elseif(empty(F3Base_Options::ler('f3base_pipedrive')['ativo'])){$ok=true;$code='pipedrive_desligado';}
                    else{$r=F3Base_Integracoes::verificar(true);$ok=!empty($r['ok'])&&F3Base_Integracoes::pipedrive_verificado()&&($r['status']??'')!=='aguardando';$code=$r['codigo']??'catalogo_sem_prova';}
                    $s['etapas'][$step]=array('estado'=>$ok?'verificado':'atencao','em'=>time(),'codigo'=>F3Base_Conversoes_Servidor::codigo($code,'verificacao_inconclusiva'));
                }catch(Throwable $e){$s['etapas'][$step]=array('estado'=>'atencao','em'=>time(),'codigo'=>'verificacao_interrompida');}
                finally{self::$active='';}
                if(count($s['etapas'])===3){$s['concluida_em']=time();}
                $saved=self::salvar($s);if(empty($s['concluida_em'])){F3Base_Fila::agendar(self::HOOK,time()+5);}
                return array('ok'=>$saved,'codigo'=>$saved?'prova_registrada':'recibo_nao_persistido','etapa'=>$step,'resultado'=>$s['etapas'][$step]);
            }
            $s['concluida_em']=time();self::salvar($s);return array('ok'=>true,'codigo'=>'ciclo_observado_com_recibos');
        }finally{self::$active='';F3Base_Trava::liberar($lock);}
    }
    private static function salvar(array $s): bool {
        $r=F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>(self::ciclo()['ciclo']??'')===$s['ciclo']?$s:null);return !empty($r['persisted']);
    }
    public static function resumo(): array {
        $s=get_option(self::STATE,array());$c=self::ciclo();if(($s['ciclo']??'')!==($c['ciclo']??'')||($c['versao']??'')!==F3BASE_PLUGIN_VERSAO){return array('estado'=>'aguardando_confirmacao','etapas'=>array());}
        return array('estado'=>empty($s['concluida_em'])?'em_andamento':'concluida','em'=>$s['concluida_em']??null,'etapas'=>$s['etapas']??array(),'proxima'=>$s['proxima']??null,'detalhe'=>'f3base/como-usar');
    }
    public static function avisos(): array {
        $out=array();foreach(self::resumo()['etapas'] as $step=>$r){if(in_array($r['estado'],array('atencao','incerto'),true)){$key='pos_atualizacao_'.$step;$out[$key]=array('nome'=>$key,'ativo'=>true,'motivo'=>$r['codigo'],'acao'=>'Consulte o recibo pós-atualização e a verificação deste módulo. A falha não impede o ciclo de instalação.','em'=>$r['em']);}}return $out;
    }
    public static function iniciar(): void {
        add_action('init',array(__CLASS__,'agendar'),99);add_action(self::HOOK,array(__CLASS__,'executar'));
    }
}
