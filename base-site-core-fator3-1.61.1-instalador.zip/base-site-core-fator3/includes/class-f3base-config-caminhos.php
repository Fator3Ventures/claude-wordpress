<?php
/** JSON Pointer operations. Full candidate validation remains owned by Core_Config_Mcp. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Config_Caminhos {
    public static function schema(): array {
        return array('type'=>'array','minItems'=>1,'maxItems'=>50,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('operacao','caminho'),'properties'=>array(
            'operacao'=>array('type'=>'string','enum'=>array('definir','remover','acrescentar','remover_de_lista')),
            'caminho'=>array('type'=>'string','minLength'=>1,'maxLength'=>500,'description'=>'JSON Pointer: /livres ou /0/campos/0/rotulo; ~1 representa / e ~0 representa ~.'),
            'valor'=>F3Base_Config_Contrato::schema_dado('Novo valor ou item completo.'),
            'chave'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('campo','valor'),'properties'=>array('campo'=>array('type'=>'string','minLength'=>1,'maxLength'=>100),'valor'=>array('type'=>array('string','integer'))))
        )));
    }
    private static function partes(string $p): array {
        if($p===''||$p[0]!=='/'||strlen($p)>500||preg_match('/~(?![01])/',$p)){throw new InvalidArgumentException('caminho_invalido');}
        $parts=array_map(static fn($s)=>str_replace(array('~1','~0'),array('/','~'),$s),explode('/',substr($p,1)));
        if(count($parts)>16){throw new InvalidArgumentException('caminho_profundo');}return $parts;
    }
    public static function trechos($v,array $paths): array {
        $r=array();foreach($paths as $p){$x=$v;$exists=true;foreach(self::partes($p) as $k){if(!is_array($x)||!array_key_exists($k,$x)){$exists=false;break;}$x=$x[$k];}$r[$p]=array('existe'=>$exists,'valor'=>$exists?$x:null);}return $r;
    }
    public static function aplicar($value,array $ops,array $schema=array()): array {
        if(count($ops)<1||count($ops)>50){return array('ok'=>false,'codigo'=>'operacoes_invalidas');}
        $paths=array();try{foreach($ops as $op){
            $parts=self::partes((string)($op['caminho']??''));$key=array_pop($parts);$ref=&$value;$node=$schema;
            foreach($parts as $part){if(!is_array($ref)||!array_key_exists($part,$ref)||!is_array($ref[$part])){throw new InvalidArgumentException('caminho_ausente');}$node=($node['type']??'')==='array'?($node['items']??array()):($node['properties'][$part]??(is_array($node['additionalProperties']??null)?$node['additionalProperties']:array()));$ref=&$ref[$part];}
            if(!is_array($ref)){throw new InvalidArgumentException('caminho_nao_composto');}$exists=array_key_exists($key,$ref);$action=$op['operacao']??'';
            if($action==='definir'){
                if(!array_key_exists('valor',$op)){throw new InvalidArgumentException('valor_obrigatorio');}
                if((($node['type']??'')==='array'||($ref!==array()&&array_is_list($ref)))&&(!$exists||!ctype_digit((string)$key))){throw new InvalidArgumentException('indice_lista_invalido');}$ref[$key]=$op['valor'];
            }elseif($action==='remover'){
                if(!$exists){throw new InvalidArgumentException('caminho_ausente');}$list=array_is_list($ref);unset($ref[$key]);if($list){$ref=array_values($ref);}
            }elseif(in_array($action,array('acrescentar','remover_de_lista'),true)){
                if(!$exists||!is_array($ref[$key])||!array_is_list($ref[$key])){throw new InvalidArgumentException('caminho_nao_lista');}
                if($action==='acrescentar'){if(!array_key_exists('valor',$op)){throw new InvalidArgumentException('valor_obrigatorio');}$ref[$key][]=$op['valor'];}
                else{$selector=$op['chave']??array();if(!isset($selector['campo'])||!array_key_exists('valor',$selector)){throw new InvalidArgumentException('chave_obrigatoria');}$matches=array_keys(array_filter($ref[$key],static fn($item)=>is_array($item)&&array_key_exists($selector['campo'],$item)&&$item[$selector['campo']]===$selector['valor']));if(count($matches)!==1){throw new InvalidArgumentException(count($matches)?'chave_ambigua':'chave_ausente');}array_splice($ref[$key],$matches[0],1);}
            }else{throw new InvalidArgumentException('operacao_invalida');}
            unset($ref);$paths[]=$op['caminho'];
        }}catch(InvalidArgumentException $e){return array('ok'=>false,'codigo'=>$e->getMessage());}
        return array('ok'=>true,'valor'=>$value,'caminhos'=>array_values(array_unique($paths)));
    }
    public static function hashes(string $name,$v): array {
        if(F3Base_Options::e_segredo($name)||!is_array($v)){return array();}$r=array();
        foreach($v as $k=>$x){$r[$k]=hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($x),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION));}return $r;
    }
    public static function projetar(string $name,array $entry,array $input): array {
        $r=array('revisao'=>$entry['revisao'],'origem'=>$entry['origem'],'existe_no_banco'=>$entry['existe_no_banco']);
        if(!empty($input['hash'])){$r['hash']=self::hashes($name,$entry['valor']);$r['hash_algoritmo']='sha256-json-canonico/1';}
        if(isset($input['caminhos'])){if(F3Base_Options::e_segredo($name)){return $r+array('codigo'=>'segredo_sem_projecao');}$r['caminhos']=self::trechos($entry['valor'],$input['caminhos']);}
        elseif(empty($input['hash'])){$r['valor']=$entry['valor'];}return $r;
    }
}
