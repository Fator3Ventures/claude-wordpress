<?php
/** e-mail automático ao novo lead: durable intent, one SMTP envelope, independent CRM acknowledgement. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Novo_Lead {
    const HOOK='f3base_email_novo_lead_processar';

    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_email_novo_lead';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta('CREATE TABLE '.self::tabela()." (
 chave char(64) NOT NULL,
 record_id char(32) NOT NULL,
 conta varchar(191) NOT NULL,
 lead_id char(36) NOT NULL,
 estado varchar(24) NOT NULL DEFAULT 'pendente',
 codigo varchar(80) NOT NULL DEFAULT '',
 payload longtext NOT NULL,
 proxima bigint unsigned NOT NULL,
 enviado_em bigint unsigned NOT NULL DEFAULT 0,
 historico longtext NULL,
 historico_proxima bigint unsigned NOT NULL DEFAULT 0,
 historico_final tinyint NOT NULL DEFAULT 0,
 atualizado_em bigint unsigned NOT NULL,
 atividade_id bigint unsigned NOT NULL DEFAULT 0,
 atividade_prova longtext NULL,
 atividade_estado varchar(24) NOT NULL DEFAULT '',
 slack_estado varchar(24) NOT NULL DEFAULT '',
 PRIMARY KEY  (chave),
 KEY agenda (estado,proxima),
 KEY registro (record_id)
) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function definicao(): array {
        $str=static fn($n)=>array('type'=>'string','maxLength'=>$n);
        $p=array('ativo'=>false,'marca'=>'','remetente'=>'','smtp_host'=>'','smtp_porta'=>587,'smtp_seguranca'=>'tls','smtp_usuario'=>'','nome_exibicao'=>'','assinatura'=>'','texto_unidade'=>'','contato'=>'','whatsapp_url'=>'','assunto_atividade'=>'E-mail – primeiro contato','cota_destinatarios_hora'=>0,'alocacao_confirmada'=>false,'textos_servicos'=>array(),'homologacao_emails'=>array());
        $p+=self::textos_padrao()+array('whatsapp_numero'=>'','whatsapp_texto'=>'');
        $props=array();foreach($p as $k=>$v){$props[$k]=is_bool($v)?array('type'=>'boolean'):(is_int($v)?array('type'=>'integer','minimum'=>0,'maximum'=>$k==='smtp_porta'?65535:100):$str(in_array($k,array('assinatura','texto_unidade'),true)?3000:300));}
        $props['smtp_seguranca']=array('type'=>'string','enum'=>array('tls','ssl'));
        $props['homologacao_emails']=array('type'=>'array','maxItems'=>5,'items'=>array('type'=>'string','format'=>'email'));
        $props['textos_servicos']=array('type'=>'object','additionalProperties'=>$str(3000));
        foreach(F3Base_Email_Novo_Lead_UI::ajuda() as $key=>$description){if(isset($props[$key])){$props[$key]['description']=$description;}}
        return array('titulo'=>'E-mail automático ao novo lead','padrao'=>$p,'props'=>$props);
    }
    public static function textos_padrao(): array {
        return array('assunto'=>'{marca} – Recebemos seu contato','saudacao'=>'Olá, {primeiro_nome}.','introducao'=>'Meu nome é {nome_exibicao}, da {marca}.','recebimento'=>'Recebemos seu contato {origem}.','origem_site'=>'pelo site','origem_meta'=>'pela Meta','origem_google'=>'pelo Google','origem_linkedin'=>'pelo LinkedIn','whatsapp_rotulo'=>'Conversar no WhatsApp','convite_resposta'=>'Você também pode responder a este e-mail.');
    }
    public static function substituir(string $text,array $ctx,array $cfg): string {
        $name=trim((string)($ctx['nome']??''));$origin=$ctx['origem_nativa']['origem']??'site';
        $vars=array('nome'=>$name,'primeiro_nome'=>explode(' ',$name)[0],'nome_exibicao'=>$cfg['nome_exibicao']??'','marca'=>$cfg['marca']??'','origem'=>$cfg['origem_'.(in_array($origin,array('meta','google','linkedin'),true)?$origin:'site')]??'');
        $map=array();foreach($vars as $key=>$value){$map['{'.$key.'}']=wp_strip_all_tags((string)$value);}$source=$map;$source['{origem}']=array('meta'=>'Meta','google'=>'Google','linkedin'=>'LinkedIn')[$origin]??'site';$map['{origem}']=strtr($map['{origem}'],$source);return strtr($text,$map);
    }
    public static function whatsapp_url(array $cfg,array $ctx=array()): string {
        // Existing URLs retain their exact meaning until explicitly replaced in the UI.
        if(!empty($cfg['whatsapp_url'])&&empty($cfg['whatsapp_numero'])){return $cfg['whatsapp_url'];}
        $number=$cfg['whatsapp_numero']??'';if($number===''){$number=F3Base_Options::ler('f3base_contato')['whatsapp_e164']??'';}$number=preg_replace('/\D/','',$number);
        if(!preg_match('/^[1-9][0-9]{7,14}$/D',$number)){return '';}$text=self::substituir($cfg['whatsapp_texto']??'',$ctx,$cfg);
        return 'https://wa.me/'.$number.($text!==''?'?text='.rawurlencode($text):'');
    }
    public static function pronta(array $v): bool {
        foreach(array('marca','smtp_host','smtp_usuario','nome_exibicao','assinatura','texto_unidade') as $k){if(trim((string)($v[$k]??''))===''){return false;}}
        return is_email($v['remetente']??'')&&(int)($v['smtp_porta']??0)>0&&in_array($v['smtp_seguranca']??'',array('tls','ssl'),true);
    }
    public static function servicos(): array {
        if(!F3Base_Integracoes::pipedrive_verificado()){return array();}
        $c=F3Base_Options::ler('f3base_pipedrive');$state=get_option('f3base_pipedrive_estado',array());
        foreach($state['catalogos']['campos']??array() as $field){if(($field['field_code']??$field['key']??'')===($c['mapa_campos']['servico']??'')){return $field['options']??array();}}
        return array();
    }
    public static function recusar($v): string {
        if(!is_array($v)){return 'Informe a configuração do e-mail automático ao novo lead.';}
        foreach($v as $k=>$value){if(is_string($value)&&!in_array($k,array('assinatura','texto_unidade'),true)&&preg_match('/[\r\n\x00]/',$value)){return 'Remova quebras de linha dos campos de identificação e conexão.';}}
        foreach($v['homologacao_emails']??array() as $email){if(!is_email($email)){return 'Homologação exige endereço válido de caixa controlada.';}}
        if(($v['whatsapp_url']??'')!==''&&!preg_match('~^https://(?:wa\.me/[0-9]{8,15}|api\.whatsapp\.com/send\?phone=[0-9]{8,15})(?:[?&]text=[^\s]*)?$~D',$v['whatsapp_url'])){return 'Informe um link HTTPS de WhatsApp válido.';}
        foreach(array_keys(self::textos_padrao()) as $key){if(preg_match_all('/\{([^}]+)\}/',(string)($v[$key]??''),$m)&&array_diff($m[1],array('nome','primeiro_nome','nome_exibicao','marca','origem'))){return 'Use somente as variáveis indicadas na prévia do conteúdo.';}}
        if(!empty($v['whatsapp_numero'])&&!preg_match('/^[1-9][0-9]{7,14}$/D',$v['whatsapp_numero'])){return 'Informe o WhatsApp com código do país e DDD, somente números.';}
        $old=F3Base_Options::ler('f3base_email_novo_lead');$ids=array_map('strval',array_column(self::servicos(),'id'));
        foreach($v['textos_servicos']??array() as $id=>$text){if(!ctype_digit((string)$id)||((string)($old['textos_servicos'][$id]??'')!==$text&&!in_array((string)$id,$ids,true))){return 'Atualize o catálogo da conta e escolha uma alternativa do campo Serviços.';}}
        $effective=F3Base_Email_Envio::configuracao_automatica($v);
        if(!empty($v['ativo'])&&(!self::pronta($effective)||empty($effective['alocacao_confirmada'])||($effective['cota_destinatarios_hora']??0)<3||F3Base_Email_Envio::senha_automatica()==='')){return 'Ativação exige remetente, conexão SMTP, identificação, assinatura, texto da unidade, senha e cota confirmada de pelo menos três destinatários por hora.';}
        return '';
    }
    public static function catalogo(array $c): array {
        $d=self::definicao();$schema=array('type'=>'object','additionalProperties'=>false,'properties'=>$d['props']);
        $c['f3base_email_novo_lead']=array('rotulo'=>$d['titulo'],'descricao'=>'Envia uma apresentação ao contato após confirmar um novo lead no CRM. Configure remetente, SMTP e conteúdo deste site. A cota inclui destinatário e cópias; resultados incertos não são reenviados automaticamente.','operavel'=>true,'secao'=>'conexoes','campo'=>'grupo','autoload'=>false,'padrao'=>$d['padrao'],'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>static fn($v,$p)=>is_array($v)?array_replace($p,$v):$p,'recusa'=>static fn($v)=>self::recusar(array_replace(F3Base_Options::ler('f3base_email_novo_lead'),(array)$v)));
        $c['f3base_email_novo_lead_cota']=array('rotulo'=>'Cota do e-mail automático','descricao'=>'Reservas de destinatários na última hora.','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));
        $c['f3base_email_migracao_142']=array('rotulo'=>'Migração do e-mail automático','descricao'=>'Estado interno da migração de configuração e diário.','operavel'=>false,'estado_execucao'=>true,'campo'=>'texto','autoload'=>false,'padrao'=>'','sanitiza'=>static fn($v)=>is_string($v)?$v:'');
        return $c;
    }
    public static function iniciar(): void {
        add_action(self::HOOK,array(__CLASS__,'processar'));
        add_action('init',static function(){if(!wp_next_scheduled(self::HOOK)){wp_schedule_event(time()+90,'hourly',self::HOOK);}},98);
        add_action('f3base_lead_eliminando',array(__CLASS__,'cancelar'));
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-novo-lead-homologar','Autoriza uma única intenção e-mail automático ao novo lead de teste por até uma hora; caixa deve constar na lista de caixas autorizadas deste site',array(__CLASS__,'homologar'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'confirmar'=>array('type'=>'boolean')),array('record_id','confirmar'),false);F3Base_Servicos::ability('email-novo-lead-ler','Estado privado do e-mail e-mail automático ao novo lead; sem corpo ou credenciais',array(__CLASS__,'ler'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));});
    }
    public static function intencao(): array {$c=F3Base_Options::ler('f3base_email_novo_lead');return array('solicitado'=>!empty($c['ativo']),'revisao'=>F3Base_Options::revisao('f3base_email_novo_lead'));}
    public static function elegivel(array $lead,array $job): bool {
        $o=$job['journal']['oportunidade']??array();$company=(string)($lead['dados']['empresa']??'');
        return !in_array($lead['metodo']??'',array('email','contato_externo'),true)&&!empty($lead['dados']['email_novo_lead_intencao']['solicitado'])&&($lead['captura']??'')==='aceito'&&empty($lead['lixeira'])&&empty($lead['eliminacao_pendente'])&&($lead['classe_trafego']??'')==='nao_marcado'&&empty($lead['dados']['contexto_teste'])&&!preg_match('/^Teste.*\(apagar\)/iu',$company)&&is_email($lead['email']??'')&&($o['tipo']??'')==='lead'&&!empty($o['nova'])&&empty($o['reenvio'])&&!empty($job['journal']['nucleo_confirmado_em']);
    }
    public static function enfileirar(array $lead,array $job,array $ctx,array $plan): bool {
        $company=$ctx['empresa']??'';if(is_array($company)){$company=$company['nome']??'';}if(!self::elegivel($lead,$job)||preg_match('/^Teste.*\(apagar\)/iu',(string)$company)){return true;}$ctx['email_novo_lead_service_ids']=F3Base_Pipedrive_Comercial::servico($ctx,F3Base_Options::ler('f3base_pipedrive'))['ids'];
        global $wpdb;$key=hash('sha256',get_current_blog_id().'|'.$job['conta'].'|'.$job['journal']['oportunidade']['id'].'|email_novo_lead');
        $payload=F3Base_Contato_Comunicacao::cifrar(array('ctx'=>$ctx,'plan'=>$plan,'config'=>F3Base_Options::ler('f3base_email_novo_lead'),'person_id'=>$job['journal']['pessoa']??0));
        $n=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (chave,record_id,conta,lead_id,payload,proxima,atualizado_em) VALUES (%s,%s,%s,%s,%s,%d,%d)',self::tabela(),$key,$lead['record_id'],$job['conta'],$job['journal']['oportunidade']['id'],$payload,time(),time()));
        if($n!==false){F3Base_Fila::agendar(self::HOOK,time()+30);}return $n!==false;
    }
    public static function mensagem(array $ctx,array $cfg,array $plan,int $now): array {
        if(!self::pronta($cfg)){return array('ok'=>false,'codigo'=>'configuracao_email_incompleta');}
        $brand=$cfg['marca'];$ids=$ctx['email_novo_lead_service_ids']??F3Base_Pipedrive_Comercial::servico($ctx,F3Base_Options::ler('f3base_pipedrive'))['ids'];$paragraphs=array();
        foreach(array_unique($ids) as $id){$text=trim((string)($cfg['textos_servicos'][(string)$id]??''));if($text===''){return array('ok'=>false,'codigo'=>'texto_servico_pendente');}$paragraphs[]=$text;}
        if(!$ids){$paragraphs[]=$cfg['texto_unidade'];}
        $first=explode(' ',trim($ctx['nome']??''))[0];if($first===''){return array('ok'=>false,'codigo'=>'nome_ausente');}
        $cfg+=self::textos_padrao();$parts=array();
        foreach(array('saudacao','introducao','recebimento') as $key){$parts[]=self::substituir($cfg[$key],$ctx,$cfg);}
        $parts[]=self::substituir(implode("\n\n",array_unique($paragraphs)),$ctx,$cfg);
        if(($cfg['contato']??'')!==''){$parts[]=self::substituir($cfg['contato'],$ctx,$cfg);}
        $url=self::whatsapp_url($cfg,$ctx);$label=self::substituir($cfg['whatsapp_rotulo'],$ctx,$cfg);
        if($url!==''){$parts[]=$label.': '.$url;}
        $parts[]=self::substituir($cfg['convite_resposta'],$ctx,$cfg);$parts[]=self::substituir($cfg['assinatura'],$ctx,$cfg);
        $parts=array_values(array_filter($parts,static fn($v)=>trim($v)!==''));
        $html=implode('',array_map(static fn($v)=>'<p>'.nl2br(esc_html($v)).'</p>',$parts));
        if($url!==''){$html=str_replace(esc_html($label.': '.$url),'<a href="'.esc_url($url).'">'.esc_html($label).'</a>',$html);}
        return array('ok'=>true,'subject'=>self::substituir($cfg['assunto'],$ctx,$cfg),'html'=>$html,'text'=>implode("\n\n",$parts),'brand'=>$brand);
    }
    /** Explicit administrative test: one controlled mailbox, no CRM writes or Bcc. */
    public static function testar_smtp(string $to=''): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $cfg=F3Base_Email_Envio::configuracao_automatica(F3Base_Options::ler('f3base_email_novo_lead'));
        if($to!==''&&!in_array(strtolower($to),array_map('strtolower',$cfg['homologacao_emails']??array()),true)){return array('ok'=>false,'codigo'=>'caixa_nao_autorizada');}
        $lock=F3Base_Trava::adquirir('email-novo-lead-teste',45);if(!$lock){return array('ok'=>false,'codigo'=>'teste_em_andamento');}
        $mail=null;try{
            require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/SMTP.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
            $mail=new \PHPMailer\PHPMailer\PHPMailer(true);$mail->isSMTP();$mail->Host=$cfg['smtp_host'];$mail->Port=(int)$cfg['smtp_porta'];$mail->SMTPSecure=$cfg['smtp_seguranca'];$mail->SMTPAuth=true;$mail->Username=$cfg['smtp_usuario'];$mail->Password=F3Base_Email_Envio::senha_automatica();$mail->Timeout=10;$mail->SMTPDebug=0;
            if(!$mail->smtpConnect()){return array('ok'=>false,'codigo'=>'autenticacao_recusada');}
            if($to===''){return array('ok'=>true,'codigo'=>'smtp_autenticado_sem_envio');}
            $m=self::mensagem(array('nome'=>'Contato de teste','email_novo_lead_service_ids'=>array()),$cfg,array(),time());if(empty($m['ok'])){return array('ok'=>false,'codigo'=>$m['codigo']);}
            if(empty($cfg['alocacao_confirmada'])||!self::reservar_cota(1,(int)$cfg['cota_destinatarios_hora'])){return array('ok'=>false,'codigo'=>'cota_nao_disponivel');}
            $mail->CharSet='UTF-8';$mail->setFrom($cfg['remetente'],$cfg['nome_exibicao']);$mail->addAddress($to);$mail->Subject='[TESTE] '.$m['subject'];$mail->isHTML(true);$mail->Body=$m['html'];$mail->AltBody=$m['text'];
            if(!$mail->preSend()){return array('ok'=>false,'codigo'=>'mensagem_invalida');}
            $r=self::envelope($mail->getSMTPInstance(),$mail->getSentMIMEMessage(),array($to),$cfg['remetente']);return array('ok'=>$r['estado']==='enviado')+$r;
        }catch(Throwable $e){return array('ok'=>false,'codigo'=>'smtp_teste_falhou');}finally{if($mail){$mail->smtpClose();}F3Base_Trava::liberar($lock);}
    }
    public static function reservar_cota(int $count,int $limit): bool {
        $ok=false;$r=F3Base_Options::atualizar_estado('f3base_email_novo_lead_cota',static function($s)use($count,$limit,&$ok){$rows=array_values(array_filter($s['reservas']??array(),static fn($x)=>$x['em']>time()-HOUR_IN_SECONDS));if(array_sum(array_column($rows,'n'))+$count>$limit){return null;}$rows[]=array('em'=>time(),'n'=>$count);$ok=true;return array('reservas'=>$rows);});return $ok&&!empty($r['persisted']);
    }
    /** All RCPTs must be accepted before DATA. No recipient receives a partial envelope. */
    public static function smtp(array $message,string $to,string $bcc): array {
        require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/SMTP.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';
        $cfg=F3Base_Email_Envio::configuracao_automatica(F3Base_Options::ler('f3base_email_novo_lead'));if(!self::pronta($cfg)){return array('estado'=>'pendente','codigo'=>'configuracao_email_incompleta');}$mail=new \PHPMailer\PHPMailer\PHPMailer(true);$phase='preparar';
        try{
            F3Base_SMTP_Prova::configurar($mail,$cfg,F3Base_Email_Envio::senha_automatica());$mail->CharSet='UTF-8';$mail->setFrom($cfg['remetente'],$cfg['nome_exibicao']);$mail->addAddress($to);foreach(F3Base_Email_Envio::copias($to,$bcc) as $address){if(strtolower($address)!==strtolower($to)){$mail->addBCC($address);}}$mail->MessageID=$message['message_id']??'';$mail->Subject=$message['subject'];$mail->isHTML(true);$mail->Body=$message['html'];$mail->AltBody=$message['text'];
            if(!$mail->preSend()||!$mail->smtpConnect()){return array('estado'=>'pendente','codigo'=>F3Base_SMTP_Prova::codigo($mail));}
            return self::envelope($mail->getSMTPInstance(),$mail->getSentMIMEMessage(),array_merge(array(strtolower($to)),F3Base_Email_Envio::copias($to,$bcc)),$cfg['remetente']);
        }catch(Throwable $e){return array('estado'=>$phase==='data'?'incerto':'pendente','codigo'=>F3Base_SMTP_Prova::codigo($mail,$e));}finally{$mail->smtpClose();}
    }
    public static function envelope(\PHPMailer\PHPMailer\SMTP $smtp,string $mime,array $recipients,string $sender): array {
        $phase='envelope';try{$smtp->Timelimit=15;
            if(!$smtp->mail($sender)){return array('estado'=>'pendente','codigo'=>'smtp_remetente_recusado');}
            foreach($recipients as $address){if(!$smtp->recipient($address)){$smtp->reset();return array('estado'=>'pendente','codigo'=>'smtp_destinatario_recusado');}}
            $phase='data';if(!$smtp->data($mime)){$code=(int)($smtp->getError()['smtp_code']??0);return array('estado'=>$code>=400&&$code<600?'pendente':'incerto','codigo'=>'smtp_data_sem_aceite');}
            return array('estado'=>'enviado','codigo'=>'smtp_aceito');
        }catch(Throwable $e){return array('estado'=>$phase==='data'?'incerto':'pendente','codigo'=>'smtp_'.$phase.'_falhou');}
    }
    /** Serialize erasure with SMTP/activity creation; retain only IDs and hashed creation evidence. */
    public static function cancelar(string $id): bool {
        $lock=F3Base_Trava::adquirir('email-novo-lead-worker',120);if(!$lock){return false;}
        try{global $wpdb;return $wpdb->update(self::tabela(),array('estado'=>'cancelado','codigo'=>'registro_eliminado','payload'=>'','historico'=>null,'historico_final'=>1,'historico_proxima'=>0),array('record_id'=>$id))!==false;}
        finally{F3Base_Trava::liberar($lock);}
    }
    private static function atualizar(array &$row,array $patch): bool {global $wpdb;$patch['atualizado_em']=time();$n=$wpdb->update(self::tabela(),$patch,array('chave'=>$row['chave'],'estado'=>$row['estado'],'atualizado_em'=>$row['atualizado_em']));if($n!==1){$fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$row['chave']),ARRAY_A);if(!$fresh||array_filter($patch,static fn($v,$k)=>(string)($fresh[$k]??'')!==(string)$v,ARRAY_FILTER_USE_BOTH)){return false;}}$row=array_replace($row,$patch);return true;}
    public static function ler(array $e): array {if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}global $wpdb;return array('ok'=>true,'linhas'=>$wpdb->get_results($wpdb->prepare('SELECT chave,record_id,estado,codigo,proxima,enviado_em,atividade_id,atividade_estado,slack_estado FROM %i WHERE record_id=%s',self::tabela(),$e['record_id']),ARRAY_A));}
    private static function reconciliar(): void {
        global $wpdb;$jobs=$wpdb->get_results($wpdb->prepare("SELECT q.* FROM %i q JOIN %i l ON l.record_id=q.record_id LEFT JOIN %i c ON c.record_id=l.record_id WHERE c.chave IS NULL AND JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.email_novo_lead_intencao.solicitado'))='true' AND JSON_EXTRACT(q.journal,'$.nucleo_confirmado_em') IS NOT NULL ORDER BY q.atualizado_em DESC LIMIT 20",F3Base_Pipedrive_Fila::tabela(),F3Base_Leads_Repositorio::tabela(),self::tabela()),ARRAY_A);
        foreach($jobs as $job){$job['journal']=json_decode($job['journal'],true)?:array();$lead=F3Base_Leads_Repositorio::obter($job['record_id']);if($lead&&self::elegivel($lead,$job)){self::enfileirar($lead,$job,F3Base_Pipedrive_Fila::contexto($lead),$job['journal']['atividade_plano']??array());}}
    }
    public static function homologar(array $e): array {
        if(F3Base_Caminho_Lead::pertence((string)($e['record_id']??''))){return array('ok'=>false,'codigo'=>'smart_bcc_sem_exclusao_individual_segura');}
        if(!current_user_can('manage_options')||($e['confirmar']??false)!==true){return array('ok'=>false,'codigo'=>'confirmacao_administrativa_necessaria');}
        global $wpdb;$lead=F3Base_Leads_Repositorio::obter($e['record_id']);$cfg=F3Base_Email_Envio::configuracao_automatica(F3Base_Options::ler('f3base_email_novo_lead'));
        if(!$lead||$lead['classe_trafego']!=='teste'||$lead['lixeira']||$lead['eliminacao_pendente']||!in_array($lead['email'],$cfg['homologacao_emails']??array(),true)){return array('ok'=>false,'codigo'=>'teste_ou_caixa_nao_autorizada');}
        $job=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s ORDER BY atualizado_em DESC LIMIT 1',F3Base_Pipedrive_Fila::tabela(),$lead['record_id']),ARRAY_A);$j=json_decode($job['journal']??'{}',true);$o=$j['oportunidade']??array();
        if(($o['tipo']??'')!=='lead'||empty($o['nova'])||!empty($o['reenvio'])||empty($j['nucleo_confirmado_em'])){return array('ok'=>false,'codigo'=>'novo_lead_nao_confirmado');}
        $ctx=F3Base_Pipedrive_Fila::contexto($lead);$plan=$j['atividade_plano']??array();$key=hash('sha256',get_current_blog_id().'|'.$job['conta'].'|'.$o['id'].'|email_novo_lead');
        $p=F3Base_Contato_Comunicacao::cifrar(array('ctx'=>$ctx,'plan'=>$plan,'config'=>$cfg,'person_id'=>$j['pessoa'],'homologacao'=>array('email'=>$lead['email'],'expires'=>time()+HOUR_IN_SECONDS,'by'=>get_current_user_id(),'authorized_at'=>time())));
        $n=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (chave,record_id,conta,lead_id,payload,proxima,atualizado_em) VALUES (%s,%s,%s,%s,%s,%d,%d)',self::tabela(),$key,$lead['record_id'],$job['conta'],$o['id'],$p,time(),time()));
        if($n===1){F3Base_Fila::agendar(self::HOOK,time()+10);}return array('ok'=>$n===1,'codigo'=>$n===1?'uma_intencao_autorizada':'intencao_ja_existe_ou_erro');
    }
    public static function processar(): array {
        if(get_option('f3base_email_migracao_142')!=='concluida'){return array('ok'=>false,'codigo'=>'migracao_pendente');}global $wpdb;$lock=F3Base_Trava::adquirir('email-novo-lead-worker',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}$count=0;
        try{
            $cfg=F3Base_Email_Envio::configuracao_automatica(F3Base_Options::ler('f3base_email_novo_lead'));if(empty($cfg['ativo'])||!self::pronta($cfg)){return array('ok'=>true,'codigo'=>'desligado');}
            F3Base_Pipedrive_Api::iniciar_lote();$crm=F3Base_Pipedrive_Api::configuracao_lote();$state=get_option('f3base_pipedrive_estado',array());$account=($state['dominio']??'').'|'.($state['conta_id']??'').'|'.($state['instalacao']??'');
            self::reconciliar();
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado IN ('pendente','enviado','incerto') AND proxima<=%d ORDER BY proxima LIMIT 3",self::tabela(),time()),ARRAY_A);
            foreach($rows as $row){
                $lead=F3Base_Leads_Repositorio::obter($row['record_id']);$p=F3Base_Contato_Comunicacao::abrir($row['payload']);$authorization=$p['homologacao']??array();$testAllowed=$lead&&($authorization['email']??'')===$lead['email']&&($authorization['expires']??0)>time()&&in_array($lead['email'],$cfg['homologacao_emails']??array(),true);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||($lead['classe_trafego']!=='nao_marcado'&&!$testAllowed&&!$row['enviado_em'])){self::atualizar($row,array('estado'=>'cancelado','codigo'=>'registro_inelegivel'));continue;}
                if($row['conta']!==$account||empty($crm['ativo'])||!F3Base_Integracoes::pipedrive_verificado()){self::atualizar($row,array('codigo'=>'conta_indisponivel','proxima'=>time()+3600));continue;}
                $p=F3Base_Contato_Comunicacao::abrir($row['payload']);if(!$p){self::atualizar($row,array('codigo'=>'snapshot_indisponivel','proxima'=>time()+3600));continue;}
                if($row['estado']==='pendente'){
                    $messageConfig=F3Base_Email_Envio::configuracao_automatica($p['config']);$messageConfig['textos_servicos']=($messageConfig['textos_servicos']??array())+($cfg['textos_servicos']??array());$message=$p['message']??self::mensagem($p['ctx'],$messageConfig,$p['plan'],time());if($testAllowed&&!empty($message['ok'])){$message['subject']='[TESTE] '.$message['subject'];}$remote=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$row['lead_id']);$bcc=$remote['data']['cc_email']??'';
                    $code=empty($message['ok'])?$message['codigo']:(empty($remote['ok'])?'smart_bcc_consulta_pendente':(!is_email($bcc)?'smart_bcc_ausente':((int)($remote['data']['person_id']??0)!==(int)$p['person_id']?'pessoa_divergente':'')));
                    if($code!==''){self::atualizar($row,array('codigo'=>$code,'proxima'=>time()+3600));self::complementar($row,$p,$lead,$crm);continue;}
                    if(F3Base_Email_Envio::senha_automatica()===''||empty($cfg['alocacao_confirmada'])||!self::reservar_cota(1+count(F3Base_Email_Envio::copias($lead['email'],$bcc)),(int)$cfg['cota_destinatarios_hora'])){self::atualizar($row,array('codigo'=>'smtp_credencial_ou_cota','proxima'=>time()+3600));continue;}
                    if($testAllowed&&array_diff(array_merge(array(strtolower($lead['email'])),F3Base_Email_Envio::copias($lead['email'],$bcc)),array_map('strtolower',$cfg['homologacao_emails']))){self::atualizar($row,array('codigo'=>'copias_fora_homologacao','proxima'=>time()+3600));continue;}
                    $message=F3Base_Email_Historico::preparar($message,$cfg,$lead['email']);$p['message']=$message;if(!self::atualizar($row,array('estado'=>'incerto','codigo'=>'smtp_iniciado','payload'=>F3Base_Contato_Comunicacao::cifrar($p)))){continue;}
                    $result=self::smtp($message,$lead['email'],$bcc);$patch=$result+array('proxima'=>time()+3600);if($result['estado']==='enviado'){$patch['enviado_em']=time();}if(!self::atualizar($row,$patch)){continue;}++$count;
                }
                self::complementar($row,$p,$lead,$crm);
            }
            return array('ok'=>true,'processados'=>$count);
        }finally{F3Base_Trava::liberar($lock);}
    }
    private static function complementar(array &$row,array $p,array $lead,array $crm): void {
        $sent=$row['estado']==='enviado';
        // IDs and uncertain operations remain local. A lost POST is never repeated.
        if($sent&&!$row['atividade_id']&&$row['atividade_estado']!=='incerta'){
            if(self::atualizar($row,array('atividade_estado'=>'incerta'))){
                $at=(int)$row['enviado_em'];$cfg=$p['config']??array();
                $data=array('subject'=>$cfg['assunto_atividade']??'E-mail – primeiro contato','type'=>'email','done'=>true,'due_date'=>gmdate('Y-m-d',$at),'due_time'=>gmdate('H:i',$at),'lead_id'=>$row['lead_id'],'owner_id'=>$crm['responsavel'],'participants'=>array(array('person_id'=>(int)$p['person_id'],'primary'=>true)),'note'=>'<p>'.esc_html(wp_date('d/m/Y H:i:s T',$at)).'</p>');
                $res=F3Base_Pipedrive_Api::pedir('POST','v2/activities',$data);
                if(!empty($res['ok'])&&!empty($res['data']['id'])){self::atualizar($row,array('atividade_id'=>(int)$res['data']['id'],'atividade_prova'=>wp_json_encode(F3Base_Pipedrive_Eliminacao::prova('atividade',$res['data'])),'atividade_estado'=>'concluida'));}elseif(empty($res['incerto'])){self::atualizar($row,array('atividade_estado'=>'pendente'));}
            }
        }
        if($sent&&$row['atividade_id']&&$row['atividade_estado']!=='concluida'){$res=F3Base_Pipedrive_Api::pedir('PATCH','v2/activities/'.$row['atividade_id'],array('done'=>true,'note'=>'<p>'.esc_html(wp_date('d/m/Y H:i:s T',(int)$row['enviado_em'])).'</p>'));if(!empty($res['ok'])){self::atualizar($row,array('atividade_estado'=>'concluida'));}}
        if(!$sent&&!in_array($row['slack_estado'],array('enfileirado','entregue','incerto'),true)){$result=F3Base_Slack::retorno_pipedrive($lead,'email-novo-lead-falha:'.$row['chave'],array('E-mail automático ao novo lead'=>array('Estado'=>$row['estado'],'Motivo'=>$row['codigo'])),'');self::atualizar($row,array('slack_estado'=>$result['estado']??'pendente'));}
        if($sent&&$row['atividade_estado']==='concluida'){self::atualizar($row,array('estado'=>'concluido'));}else{self::atualizar($row,array('proxima'=>time()+3600));}
    }
    public static function resumo(): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        global $wpdb;$cfg=F3Base_Email_Envio::configuracao_automatica(F3Base_Options::ler('f3base_email_novo_lead'));$quota=F3Base_Options::ler('f3base_email_novo_lead_cota');$rows=array_filter($quota['reservas']??array(),static fn($v)=>($v['em']??0)>time()-HOUR_IN_SECONDS);
        $error=(string)$wpdb->get_var('SELECT codigo FROM '.self::tabela()." WHERE codigo<>'' AND estado NOT IN ('enviado','concluido') ORDER BY atualizado_em DESC LIMIT 1");
        return array('ok'=>true,'ativo'=>!empty($cfg['ativo']),'configuracao_completa'=>self::pronta($cfg),'destinatarios_ultima_hora'=>array_sum(array_column($rows,'n')),'cota'=>$cfg['cota_destinatarios_hora'],'intencoes'=>$wpdb->get_results('SELECT estado,COUNT(*) AS quantidade FROM '.self::tabela().' GROUP BY estado',ARRAY_A),'ultimo_erro'=>preg_match('/^[a-z0-9_:-]{1,80}$/D',$error)?$error:'');
    }
}
