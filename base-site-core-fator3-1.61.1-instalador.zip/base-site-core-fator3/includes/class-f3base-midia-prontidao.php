<?php
/** Local paid-media checklist. It never verifies a provider or enables a destination. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Midia_Prontidao {
    public static function publica(string $name,array $input=array()): array {
        // Only documented local reads are admitted; a regression cannot dispatch provider HTTP here.
        if(!in_array($name,array('meta/health','meta/list-connections','linkedin/status','linkedin/diagnose-conversions','google/status'),true)){return array('ok'=>false,'codigo'=>'leitura_nao_permitida');}
        $ability=function_exists('wp_get_ability')?wp_get_ability($name):null;if(!$ability){return array('ok'=>false,'codigo'=>'pacote_ou_ability_ausente');}
        $deny=static fn()=>new WP_Error('f3base_leitura_local','Esta leitura não admite HTTP.');add_filter('pre_http_request',$deny,PHP_INT_MAX);
        try{$r=$ability->execute($input);if(is_wp_error($r)||!is_array($r)){return array('ok'=>false,'codigo'=>'contrato_leitura_recusado');}if(isset($r['success'])&&!$r['success']){return array('ok'=>false,'codigo'=>F3Base_Conversoes_Servidor::codigo($r['code']??null,'leitura_recusada'));}return array('ok'=>true,'dados'=>$r['data']??$r);}
        catch(Throwable $e){return array('ok'=>false,'codigo'=>'leitura_indisponivel');}finally{remove_filter('pre_http_request',$deny,PHP_INT_MAX);}
    }
    private static function linha(string $id,bool $ready,string $reason,string $action,$source,bool $blocking=true,array $details=array()): array {
        return array('id'=>$id,'estado'=>$ready?'pronto':($blocking?'bloqueado':'atencao'),'codigo'=>$ready?'configuracao_confirmada':$reason,'acao'=>$ready?null:$action,'fonte'=>(array)$source)+$details;
    }
    public static function ultimo(string $platform): ?array {
        global $wpdb;$r=$wpdb->get_row($wpdb->prepare("SELECT l.record_id,q.concluido_em FROM %i l JOIN %i q ON q.record_id=l.record_id WHERE l.captura='aceito' AND l.classe_trafego='nao_marcado' AND l.lixeira=0 AND l.eliminacao_pendente=0 AND q.estado='entregue' AND JSON_UNQUOTE(JSON_EXTRACT(l.dados,'$.atribuicao.plataforma'))=%s ORDER BY q.concluido_em DESC LIMIT 1",F3Base_Leads_Repositorio::tabela(),F3Base_Pipedrive_Fila::tabela(),$platform),ARRAY_A);return $r?array('record_id'=>$r['record_id'],'entregue_crm_em'=>(int)$r['concluido_em']):null;
    }
    public static function ler(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        // Capabilities callbacks share the same no-provider-HTTP boundary as abilities.
        $deny=static fn()=>new WP_Error('f3base_leitura_local','Esta leitura não admite HTTP.');add_filter('pre_http_request',$deny,PHP_INT_MAX);
        try{return self::ler_local($e);}finally{remove_filter('pre_http_request',$deny,PHP_INT_MAX);}
    }
    private static function ler_local(array $e): array {
        $snapshot=F3Base_Conversoes_Contexto::snapshot(array('contract'=>'site-conversion-purposes/1.1.0'));$readOk=!empty($snapshot['ok']);$purposes=$readOk?array_column($snapshot['data']['purposes']??array(),null,'purpose'):array();$transport=F3Base_Conversoes_Transporte::estado();
        $crm=F3Base_Options::ler('f3base_pipedrive');$verified=F3Base_Integracoes::pipedrive_verificado();$state=get_option('f3base_pipedrive_estado',array());$maps=F3Base_Integracoes::validar_mapeamento($crm,$state['catalogos']??array());
        $cons=F3Base_Options::ler('f3base_consentimento');$names=F3Base_Options::ler('f3base_campanhas_nomes');$out=array();
        foreach(array('meta'=>'meta_ads','google_ads'=>'google_ads','linkedin'=>'linkedin_ads') as $target=>$platform){
            $lines=array();$cap=array();if($target!=='meta'){try{if($target==='google_ads'){$cap=F3Base_Google_Conversoes::selecionar()['cap'];}else{$a=F3Base_Conversoes_Servidor::adaptador($target);$cap=$a?$a->capabilities():array();}}catch(Throwable $x){$cap=array();}}
            $contact=$purposes['contact']['destinations'][$target]??array();$material=$purposes['material']['destinations'][$target]??array();
            $mode=$target==='meta'?F3Base_Meta_Transporte::efetivo()['modo']:($contact['transport']['selected']??$transport[$target]['selected']??null);$browser=!empty($contact['enabled'])&&!empty($contact['configured']);$server=$target==='meta'?false:!empty($cap['ready']);
            if($target==='meta'){
                $proof=F3Base_Options::ler('f3base_meta_homologacao');$valid=!empty($proof['aprovada'])&&($proof['contexto']??'')===F3Base_Meta_Transporte::contexto();
                $server=F3Base_Modulo_Meta_Capi::pixel_id()!==''&&F3Base_Segredos::status('f3base_meta_capi_token')['presente'];
                $lines[]=self::linha('pixel_dataset',F3Base_Modulo_Meta_Capi::pixel_id()!=='','pixel_ausente','Configure o Pixel/dataset do site.',array('f3base_meta_pixel_id','f3base_meta_capi_pixel_id'),true,array('pixel_dataset'=>F3Base_Modulo_Meta_Capi::pixel_id()));
                if($mode!=='navegador'){$lines[]=self::linha('prova_servidor',$server&&$valid,'prova_meta_pendente','Confira a credencial e a homologação por evento.','f3base/meta-entregas-ler',true,array('prova_em'=>$proof['registrada_em']??$proof['em']??null));}
            }else{
                $lines[]=self::linha('adaptador_servidor',$server,F3Base_Conversoes_Servidor::codigo($cap['reason']??null,'adaptador_ausente'),'Configure, conceda e verifique o destino no pacote.',$target==='google_ads'?'google/conversion-delivery-status':'linkedin/conversion-capabilities',$mode!=='navegador',array('contrato'=>$cap['contract']??null,'prova_em'=>$cap['verified_at']??null,'prova_expira_em'=>$cap['verification_expires_at']??null));
                if($target==='linkedin'){$rule=(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id');$diag=self::publica('linkedin/diagnose-conversions',$rule!==''?array('conversion_id'=>$rule):array());$lines[]=self::linha('concessao_escopo_regra_api',$server,'concessao_escopo_ou_regra_pendente','Confira rw_conversions, r_ads, concessão e regra com fonte API.','linkedin/diagnose-conversions',$mode!=='navegador',array('verificacoes'=>$diag['dados']['checks']??array(),'regra_servidor'=>F3Base_Options::ler('f3base_linkedin_server_conversion_id'),'insight_tag'=>F3Base_Options::ler('f3base_linkedin_partner_id')));}
            }
            $contactReady=$mode==='servidor'?$server:($mode==='ambos'?$browser&&$server:$browser);
            if($readOk){
            $lines[]=self::linha('contato',$contactReady,'destino_contato_incompleto','Configure a conversão de contato e o transporte escolhido.','f3base/conversoes-contexto-ler',true,array('transporte'=>$mode,'identificadores'=>$contact['identifiers']??array(),'prova_navegador'=>'configuracao_local_sem_homologacao_de_execucao'));
            $lines[]=self::linha('material',!empty($material['enabled'])&&!empty($material['configured']),'destino_material_desligado_ou_incompleto','Se houver oferta de material, habilite a ação própria.','f3base/conversoes-contexto-ler',false,array('transporte'=>$target==='meta'?$mode:'navegador','identificadores'=>$material['identifiers']??array()));
            }else{foreach(array('contato','material') as $purpose){$lines[]=array('id'=>$purpose,'estado'=>'leitura_falhou','codigo'=>$snapshot['code']??'unreadable','acao'=>'Corrija a leitura do contexto antes de avaliar o destino.','fonte'=>array('f3base/conversoes-contexto-ler'),'contrato'=>$snapshot['contract']??null,'transporte'=>$mode,'identificadores'=>null);}}
            $point=isset($crm['mapa_pontos']['site'])&&isset($crm['mapa_campos']['ponto']);$partner=!empty($crm['parceiros_plataforma'][$platform]);$channel=!empty($crm['mapa_canais'][$platform]);$fields=!array_diff(array('unidade','canal','parceiro','ponto'),array_keys($crm['mapa_campos']??array()));
            $lines[]=self::linha('crm',!empty($crm['ativo'])&&$verified&&$maps===''&&$point&&!empty($crm['unidade'])&&$partner&&$channel&&$fields,'crm_ou_mapas_pendentes','Confirme integração, Unidade, Canal, Parceiro da plataforma e Ponto de conversão.',array('f3base_pipedrive','f3base/integracoes-ler'),true,array('verificado'=>$verified,'mapeamento_codigo'=>$maps,'unidade'=>$crm['unidade']??'','parceiro'=>$crm['parceiros_plataforma'][$platform]??null,'ponto_site'=>$crm['mapa_pontos']['site']??null,'ponto_nativo'=>$crm['mapa_pontos']['nativo']??null));
            $campaigns=array_values(array_filter($names,static fn($r)=>($r['plataforma']??'')===$platform));$lines[]=self::linha('campanhas_por_id',(bool)$campaigns,'mapa_campanhas_vazio','Preencha conta e campanha por ID.','f3base_campanhas_nomes',false,array('quantidade'=>count($campaigns)));
            if($target==='meta'){$native=F3Base_Options::ler('f3base_anuncios_meta');$lines[]=self::linha('formularios_nativos',!empty($native['ativo'])&&!empty($native['paginas'])&&(($native['forms_modo']??'selecionados')==='todos'||!empty($native['formularios'])),'captacao_nativa_desligada_ou_incompleta','Se houver campanha nativa, configure páginas, conta e formulários.','f3base_anuncios_meta',false,array('conta'=>$native['conta_id']??null,'paginas'=>$native['paginas']??array(),'formularios'=>$native['formularios']??array()));}
            if($target==='linkedin'){$n=F3Base_Linkedin::diagnostico();$lines[]=self::linha('formularios_nativos',F3Base_Linkedin_Integracoes::ativas(),'captacao_nativa_desligada','Se houver campanha nativa, habilite a integração e confira Lead Sync.','f3base_anuncios_linkedin',false,array('integracoes'=>$n));}
            $lines[]=self::linha('consentimento',true,'','',array('f3base_consentimento','f3base/consentimento-politica-ler'),false,array('politica'=>$cons,'regra'=>'Consentimento no aceite e atual é obrigatório por registro; esta leitura não concede publicidade.'));
            $states=array_column($lines,'estado');$overall=in_array('leitura_falhou',$states,true)?'leitura_falhou':(in_array('bloqueado',$states,true)?'bloqueado':(in_array('atencao',$states,true)?'atencao':'pronto'));$out[$target]=array('estado'=>$overall,'linhas'=>$lines,'ultimo_contato_pago_entregue'=>self::ultimo($platform),'detalhe_ultimo'=>'f3base/pipedrive-fila-ler');
        }
        return array('ok'=>true,'em'=>time(),'http_fornecedor'=>false,'plataformas'=>$out,'recebido_meta'=>F3Base_Meta_Monitoramento::qualidade($e),'limite'=>'Prontidão local por destino. Não certifica veiculação, entrega futura ou consentimento de todos os visitantes. Último contato pago entregue refere-se ao recibo do CRM.');
    }
    public static function iniciar(): void {add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('midia-prontidao-ler','Prontidão local por plataforma e destino, com fontes, motivos e ações; não chama fornecedores',array(__CLASS__,'ler'));});}
}
