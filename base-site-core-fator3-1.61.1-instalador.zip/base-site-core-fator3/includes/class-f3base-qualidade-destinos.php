<?php
/** Commercial stages have independent actions and receipts; never use the contact action implicitly. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Qualidade_Destinos {
    const OPTION='f3base_qualidade_destinos';
    const CONTRACT='site-conversion-delivery/1.2.0';
    const RECONCILE='site-stage-conversion-reconcile/1.0.0';
    const HOOK='f3base_qualidade_destinos_processar';
    public static function padroes(): array {return array('google_ads'=>array('ativo'=>false,'acoes'=>array()),'linkedin'=>array('ativo'=>false,'acoes'=>array()));}
    public static function config(): array {return array_replace_recursive(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function catalogo(array $c): array {
        $target=array('type'=>'object','additionalProperties'=>false,'properties'=>array('ativo'=>array('type'=>'boolean'),'acoes'=>array('type'=>'object','maxProperties'=>100,'additionalProperties'=>array('type'=>'string','maxLength'=>120))));
        $c[self::OPTION]=F3Base_Conversas::catalogo_grupo(self::OPTION,'Retorno comercial às plataformas',self::padroes(),array('google_ads'=>$target,'linkedin'=>$target),array(__CLASS__,'validar'));
        $c[self::OPTION]['descricao']='Uma ação própria por etapa e destino, desligada por padrão. Exige adaptador que anuncie crm_stage no contrato opcional 1.2. A capacidade efetiva do produtor determina a disponibilidade; a prévia explica bloqueios e nenhuma ação de contato é usada.';return $c;
    }
    public static function validar($v): string {
        if(!is_array($v)||array_diff(array_keys($v),array_keys(self::padroes()))){return 'Destinos inválidos.';}
        foreach($v as $target=>$cfg){$seen=array();foreach($cfg['acoes']??array() as $stage=>$action){
            if(!F3Base_Qualidade::etapa((string)$stage)){return 'Selecione etapas cadastradas neste site.';}
            $pattern=$target==='google_ads'?'~^customers/[0-9]{10}/conversionActions/[1-9][0-9]{0,29}$~D':'/^[1-9][0-9]{0,29}$/D';
            if(!is_string($action)||!preg_match($pattern,$action)||in_array($action,$seen,true)){return 'Cada etapa exige uma ação válida e exclusiva nesse destino.';}$seen[]=$action;
            if($target==='linkedin'&&$action===(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id')){return 'A ação comercial não pode reutilizar a ação de contato.';}
        }}return '';
    }
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_qualidade_destinos';}
    public static function instalar(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta('CREATE TABLE '.self::tabela()." (\nchave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\netapa varchar(60) NOT NULL,\ndestino varchar(16) NOT NULL,\nacao varchar(120) NOT NULL,\ndestino_ref varchar(191) NOT NULL,\nconfig_revisao char(64) NOT NULL,\nocorreu_em bigint unsigned NOT NULL,\nestado varchar(24) NOT NULL,\ncodigo varchar(80) NOT NULL,\nhttp smallint unsigned NOT NULL DEFAULT 0,\natualizado_em bigint unsigned NOT NULL,\nPRIMARY KEY  (chave),\nKEY contato (record_id),\nKEY agenda (estado,atualizado_em)\n) ENGINE=InnoDB ".$wpdb->get_charset_collate().';');return !$wpdb->last_error;
    }
    public static function adaptador(string $target,string $action,bool $reconcile=false): array {
        // Acquisition may change after the commercial mapping was validated and queued.
        if($target==='linkedin'&&$action!==''&&$action===(string)F3Base_Options::ler('f3base_linkedin_server_conversion_id')){return array('ok'=>false,'codigo'=>'acao_comercial_reutiliza_contato');}
        // A separate capability is mandatory. Providers that only support acquisition stay blocked.
        try{$legacy=F3Base_Conversoes_Servidor::adaptador($target);$base=$legacy?$legacy->capabilities():array();
            if(!in_array(self::CONTRACT,$base['supported_contracts']??array(),true)){return array('ok'=>false,'codigo'=>'adaptador_etapas_nao_suportado');}
            $a=apply_filters('f3base_conversoes_adaptador',null,$target,self::CONTRACT,array('consumer_id'=>'site-core-quality','purpose'=>'crm_stage','action'=>$action));
            if(!is_object($a)||!is_callable(array($a,'capabilities'))||!is_callable(array($a,'sendBound'))){return array('ok'=>false,'codigo'=>'adaptador_etapas_nao_suportado');}
            $cap=$a->capabilities();$entry=$cap['actions'][$action]??array();
            if(($cap['contract']??'')!==self::CONTRACT||!in_array('crm_stage',$cap['purposes']??array(),true)||($entry['action']??'')!==$action||($entry['purpose']??'')!=='crm_stage'){return array('ok'=>false,'codigo'=>'acao_comercial_nao_anunciada');}
            if($reconcile&&($target!=='google_ads'||($cap['async_reconciliation']??'')!==self::RECONCILE||!is_callable(array($a,'reconcileBound')))){return array('ok'=>false,'codigo'=>'reconciliacao_nao_suportada');}
            if($target==='google_ads'){
                // 1.2 must explicitly distinguish acquisition from commercial stages. Null means the provider confirms none is configured.
                if(!array_key_exists('acquisition_action',$cap)){return array('ok'=>false,'codigo'=>'acao_aquisicao_nao_comprovada');}$acquisition=$cap['acquisition_action'];
                if($acquisition!==null&&(!is_string($acquisition)||!preg_match('~^customers/[0-9]{10}/conversionActions/[1-9][0-9]{0,29}$~D',$acquisition))){return array('ok'=>false,'codigo'=>'acao_aquisicao_nao_comprovada');}
                if($acquisition===$action){return array('ok'=>false,'codigo'=>'acao_comercial_reutiliza_contato');}
                $legacyAction=$base['enhanced_leads']['conversion_action']??null;
                if($legacyAction!==null&&$legacyAction!==''&&$legacyAction!==$acquisition){return array('ok'=>false,'codigo'=>'acao_aquisicao_divergente');}
            }
            $ref=$entry['destination_ref']??'';
            $ready=!empty($cap['ready'])&&!empty($entry['ready']);
            $expiredProof=($cap['reason']??'')==='stage_verification_required'&&($entry['reason']??'')==='stage_verification_required';
            if((!$ready&&!($reconcile&&$expiredProof))||($reconcile&&(!in_array($cap['reason']??'',array('ok','stage_verification_required'),true)||!in_array($entry['reason']??'',array('ok','stage_verification_required'),true)))||!is_string($ref)||$ref===''||strlen($ref)>191){return array('ok'=>false,'codigo'=>F3Base_Conversoes_Servidor::codigo($entry['reason']??null,'acao_comercial_nao_pronta'));}
            return array('ok'=>true,'adapter'=>$a,'cap'=>$cap,'acao'=>$entry,'referencia'=>$ref);
        }catch(Throwable $e){return array('ok'=>false,'codigo'=>'adaptador_etapas_indisponivel');}
    }
    public static function preparar(array $lead,string $stage,string $target,int $at): array {
        $cfg=self::config()[$target]??array();$action=$cfg['acoes'][$stage]??'';
        $key=hash('sha256',get_current_blog_id().'|'.$lead['record_id'].'|'.$target.'|'.$stage);
        $p=array('contract'=>self::CONTRACT,'purpose'=>'crm_stage','record_id'=>$lead['record_id'],'stage_id'=>$stage,'action'=>$action,'event_id'=>'f3q-'.$key,'occurred_at'=>gmdate('c',$at));
        $why='';$selection=$action!==''?self::adaptador($target,$action):array('ok'=>false,'codigo'=>'acao_etapa_ausente');
        if(empty(F3Base_Qualidade::config()['ativo'])||empty($cfg['ativo'])){$why='destino_comercial_desligado';}
        elseif(!F3Base_Qualidade::etapa($stage)||$action===''){$why='acao_etapa_ausente';}
        elseif(($lead['captura']??'')!=='aceito'||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])){$why='registro_inelegivel';}
        elseif(($lead['classe_trafego']??'')!=='nao_marcado'||!empty($lead['dados']['contexto_teste'])||!empty($lead['dados']['homologacao'])){$why='trafego_suprimido';}
        elseif(!empty($lead['dados']['audiencia_excluida'])||($lead['metodo']??'')==='email'){$why='origem_nao_elegivel';}
        elseif($at<1||$at>time()||$at<time()-7*DAY_IN_SECONDS||$at<(int)strtotime($lead['criado_em'].' UTC')){$why='etapa_fora_da_janela';}
        $cons=F3Base_Contato_Apresentacao::consentimento_atual($lead['dados']);
        if($why===''&&(empty($cons['publicidade'])||empty($lead['dados']['consentimento_snapshot']['publicidade']))){$why='consentimento_nao_permite';}
        if($why===''&&empty($selection['ok'])){$why=$selection['codigo'];}
        if($why===''){
            if($target==='google_ads'){
                // 1.2 explicitly carries the 1.1 enhanced-lead capability for this action.
                $cap=$selection['cap'];$cap['contract']=F3Base_Google_Conversoes::CONTRACT;
                $cap['enhanced_leads']=$selection['acao']['enhanced_leads']??array();
                if(($cap['enhanced_leads']['conversion_action']??$action)!==$action){$why='acao_enhanced_divergente';}
                $g=F3Base_Google_Conversoes::montar($lead,$cap);if(empty($g['ok'])){$why=$g['codigo'];}else{$p+=$g['payload'];$p['order_id']=$p['event_id'];}
            }else{
                $email=F3Base_Google_Conversoes::dados($lead)['email']??'';$ids=array();if($email!==''){$ids[]=array('idType'=>'SHA256_EMAIL','idValue'=>hash('sha256',$email));}
                $fat=$lead['dados']['atribuicao']['li_fat_id']??'';if(is_string($fat)&&preg_match('/^[A-Za-z0-9._~-]{1,500}$/D',$fat)){$ids[]=array('idType'=>'LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID','idValue'=>$fat);}
                if(!$ids){$why='identidade_linkedin_ausente';}else{$p+=array('eventId'=>$p['event_id'],'conversion'=>'urn:lla:llaPartnerConversion:'.$action,'conversionHappenedAt'=>$at*1000,'user'=>array('userIds'=>$ids));}
            }
        }
        return array('ok'=>$why==='','codigo'=>$why?:'elegivel','payload'=>$p,'chave'=>$key,'referencia'=>$selection['referencia']??'','adapter'=>$selection['adapter']??null);
    }
    /** Called inside the commercial event transaction; no provider dispatch here. */
    public static function registrar(array $lead,string $stage,int $at): bool {
        global $wpdb;foreach(self::config() as $target=>$cfg){if(empty($cfg['ativo'])){continue;}$p=self::preparar($lead,$stage,$target,$at);$row=array('chave'=>$p['chave']??hash('sha256',get_current_blog_id().'|'.$lead['record_id'].'|'.$target.'|'.$stage),'record_id'=>$lead['record_id'],'etapa'=>$stage,'destino'=>$target,'acao'=>$cfg['acoes'][$stage]??'','destino_ref'=>$p['referencia']??'','config_revisao'=>F3Base_Options::revisao(self::OPTION),'ocorreu_em'=>$at,'estado'=>!empty($p['ok'])?'pendente':'bloqueado','codigo'=>$p['codigo'],'atualizado_em'=>time());
            if(!$wpdb->get_var($wpdb->prepare('SELECT chave FROM %i WHERE chave=%s',self::tabela(),$row['chave']))&&$wpdb->insert(self::tabela(),$row)!==1){return false;}
        }return true;
    }
    public static function previa(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $l=F3Base_Leads_Repositorio::obter((string)($e['record_id']??''));$stage=(string)($e['etapa']??'');if(!$l||!F3Base_Qualidade::etapa($stage)){return array('ok'=>false,'codigo'=>'contato_ou_etapa_ausente');}
        $out=array();foreach(array('google_ads','linkedin') as $t){$p=self::preparar($l,$stage,$t,(int)($e['ocorreu_em']??time()));$safe=$p['payload'];$safe['userIdentifiers']=F3Base_Google_Conversoes::hashes($safe['user_data']??array());unset($safe['user_data']);if(isset($safe['click_ids'])){$safe['click_ids']=array_keys($safe['click_ids']);}if(isset($safe['user'])){$safe['user']=array('tipos'=>array_column($safe['user']['userIds'],'idType'));}$out[$t]=array('elegivel'=>$p['ok'],'codigo'=>$p['codigo'],'payload'=>$safe,'destino_ref'=>$p['referencia']??'');}
        return array('ok'=>true,'simulado'=>true,'envio_realizado'=>false,'destinos'=>$out,'dependencia'=>'Requer produtor com crm_stage/1.2, ação e concessão explícitas. A confirmação assíncrona exige a extensão de reconciliação anunciada pelo produtor.');
    }
    public static function processar(): array {
        global $wpdb;$lock=F3Base_Trava::adquirir('qualidade-destinos',120);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}$n=0;
        try{$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='pendente' ORDER BY atualizado_em LIMIT 2",self::tabela()),ARRAY_A)?:array();foreach($rows as $r){if(F3Base_Execucoes::restante_ms()<20000){break;}$lead=F3Base_Leads_Repositorio::obter($r['record_id']);$p=$lead?self::preparar($lead,$r['etapa'],$r['destino'],(int)$r['ocorreu_em']):array('ok'=>false,'codigo'=>'registro_ausente');
                if(!empty($p['ok'])&&($r['config_revisao']!==F3Base_Options::revisao(self::OPTION)||$r['acao']!==($p['payload']['action']??'')||$r['destino_ref']===''||$r['destino_ref']!==($p['referencia']??''))){$p=array('ok'=>false,'codigo'=>'destino_ou_configuracao_alterado');}
                if(empty($p['ok'])){$wpdb->update(self::tabela(),array('estado'=>'bloqueado','codigo'=>$p['codigo'],'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'pendente'));continue;}
                if($wpdb->update(self::tabela(),array('estado'=>'incerto','codigo'=>'envio_iniciado','atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'pendente'))!==1){continue;}
                try{$result=$p['adapter']->sendBound($p['payload'],$r['destino_ref']);}catch(Throwable $e){$result=array();}$result=is_array($result)?$result:array();$state=$result['status']??'incerto';if(!in_array($state,array('entregue','recusado'),true)||($state==='recusado'&&empty($result['non_delivery_proven']))){$state='incerto';}
                $wpdb->update(self::tabela(),array('estado'=>$state,'codigo'=>F3Base_Conversoes_Servidor::codigo($result['code']??null,$state),'http'=>max(0,min(599,(int)($result['http']??0))),'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'incerto'));++$n;
            }$queries=self::reconciliar_incertos($lock);return array('ok'=>true,'processados'=>$n,'reconciliados'=>$queries);
        }finally{F3Base_Trava::liberar($lock);}
    }
    /** Query only: never reconstruct personal data or dispatch an uncertain event again. */
    private static function reconciliar_incertos(array &$lock): int {
        global $wpdb;$n=0;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE estado='incerto' AND destino='google_ads' AND atualizado_em<=%d ORDER BY atualizado_em LIMIT 2",self::tabela(),time()-1800),ARRAY_A)?:array();
        foreach($rows as $r){
            if(F3Base_Execucoes::restante_ms()<20000||!F3Base_Trava::renovar($lock,120)){break;}
            // Reserve the query interval before any provider access, including exceptions.
            $reserved=time();
            if($wpdb->update(self::tabela(),array('atualizado_em'=>$reserved),array('chave'=>$r['chave'],'estado'=>'incerto','atualizado_em'=>$r['atualizado_em']))!==1){continue;}
            $cfg=self::config()[$r['destino']]??array();$why='';
            if(empty(F3Base_Qualidade::config()['ativo'])||empty($cfg['ativo'])||!F3Base_Qualidade::etapa($r['etapa'])){$why='reconciliacao_destino_desligado';}
            elseif($r['config_revisao']!==F3Base_Options::revisao(self::OPTION)||($cfg['acoes'][$r['etapa']]??'')!==$r['acao']){$why='reconciliacao_configuracao_alterada';}
            $selection=$why===''?self::adaptador($r['destino'],$r['acao'],true):array();
            if($why===''&&(empty($selection['ok'])||$r['destino_ref']===''||$r['destino_ref']!==($selection['referencia']??''))){$why='reconciliacao_destino_nao_autorizado';}
            $result=array();
            // Capabilities are local provider code; recheck the Core mapping immediately before querying.
            if($why===''&&($r['config_revisao']!==F3Base_Options::revisao(self::OPTION)||empty(F3Base_Qualidade::config()['ativo'])||!F3Base_Qualidade::etapa($r['etapa']))){$why='reconciliacao_configuracao_alterada';}
            if($why===''){
                if(!F3Base_Trava::renovar($lock,120)){break;}
                $event='f3q-'.hash('sha256',get_current_blog_id().'|'.$r['record_id'].'|'.$r['destino'].'|'.$r['etapa']);
                try{$result=$selection['adapter']->reconcileBound($event,$r['destino_ref']);}catch(Throwable $e){$why='reconciliacao_indisponivel';}
                ++$n;
            }
            $result=is_array($result)?$result:array();$state=$result['status']??'incerto';
            if(!in_array($state,array('entregue','recusado'),true)||($state==='recusado'&&($result['non_delivery_proven']??false)!==true)){$state='incerto';}
            if($why===''&&($r['config_revisao']!==F3Base_Options::revisao(self::OPTION)||empty(F3Base_Qualidade::config()['ativo'])||!F3Base_Qualidade::etapa($r['etapa']))){$why='reconciliacao_configuracao_alterada';}
            if($why!==''){$state='incerto';}
            if(!F3Base_Trava::renovar($lock,120)){break;}
            $wpdb->update(self::tabela(),array('estado'=>$state,'codigo'=>$why?:F3Base_Conversoes_Servidor::codigo($result['code']??null,$state),'http'=>max(0,min(599,(int)($result['http']??0))),'atualizado_em'=>time()),array('chave'=>$r['chave'],'estado'=>'incerto','atualizado_em'=>$reserved));
        }
        return $n;
    }
    public static function ler(string $id): array {global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT etapa,destino,acao,destino_ref,estado,codigo,http,ocorreu_em,atualizado_em FROM %i WHERE record_id=%s ORDER BY ocorreu_em',self::tabela(),$id),ARRAY_A)?:array();}
    public static function eliminar(string $id): bool {global $wpdb;$l=F3Base_Trava::adquirir('qualidade-destinos',120);if(!$l){return false;}try{return $wpdb->delete(self::tabela(),array('record_id'=>$id))!==false;}finally{F3Base_Trava::liberar($l);}}
    public static function iniciar(): void {
        add_action(self::HOOK,static function(){try{return self::processar();}finally{F3Base_Fila::agendar(self::HOOK,time()+300);}});add_action('init',static function(){if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}},98);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('qualidade-conversoes-previa','Prévia comercial por etapa e destino; nenhuma ação de contato é reutilizada',array(__CLASS__,'previa'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'etapa'=>array('type'=>'string','maxLength'=>60),'ocorreu_em'=>array('type'=>'integer','minimum'=>1)),array('record_id','etapa'));});
    }
}
