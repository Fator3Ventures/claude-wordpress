<?php
/** Fotografia legível das alternativas enviadas, sem reconstruir rótulos históricos. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Recibo {
    public static function fotografar(array $data,array $ctx,array $cfg): array {
        $state=get_option('f3base_pipedrive_estado',array());$defs=array();foreach($state['catalogos']['campos']??array() as $f){$defs[$f['field_code']??$f['key']??'']=$f;}
        $source=F3Base_Pipedrive_Configuracao::aquisicao($ctx,$cfg)['fonte'];if(($ctx['metodo']??'')==='email'||!empty($ctx['contato_externo'])){$source='nome_legado';}
        $out=array('fotografado_em'=>time(),'config_revisao'=>F3Base_Options::revisao('f3base_pipedrive'),'catalogo_revisao'=>$state['revisao']??null,'alternativas'=>array());
        foreach(array('parceiro','unidade','canal','ponto') as $role){$key=$cfg['mapa_campos'][$role]??'';$f=$defs[$key]??array();$value=$data[$key]??null;$item=array('papel'=>$role,'campo_id'=>$key?:null,'opcoes'=>array(),'estado'=>$value===null?'vazio':'tipo_nao_selecao');
            if($value!==null&&in_array($f['field_type']??'',array('enum','set'),true)){$ids=explode(',',(string)$value);foreach($ids as $id){$label=null;foreach($f['options']??array() as $o){if((string)$o['id']===$id){$label=$o['label']??null;break;}}$item['opcoes'][]=array('id'=>$id,'rotulo'=>$label);}$item['estado']='intencao_enviada';}
            if($role==='parceiro'){$item['fonte']=$value===null?'vazio':(array('campanha_id'=>'mapa_campanhas_por_id','plataforma'=>'padrao_plataforma','nome_legado'=>'nome_legado')[$source]??$source);}$out['alternativas'][]=$item;
        }return $out;
    }
    public static function ler(string $id): array {
        if(!current_user_can('f3base_ler_leads')){return array('estado'=>'sem_permissao');}global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT chave,journal,estado,conta FROM %i WHERE record_id=%s ORDER BY capturado_em,chave LIMIT 101',F3Base_Pipedrive_Fila::tabela(),$id),ARRAY_A);if($wpdb->last_error){return array('estado'=>'leitura_falhou');}
        $out=array('estado'=>'observado','entregas'=>array(),'atividades'=>array(),'emails'=>array(),'mais_entregas'=>count($rows)>100);
        foreach(array_slice($rows,0,100) as $row){$j=json_decode($row['journal'],true)?:array();$receipt=$j['alternativas_recibo']??null;if($receipt){$receipt['estado']=!empty($j['campos_verificados'])?'confirmado_por_releitura':'aguardando_conferencia';$receipt['conferido_em']=$j['campos_verificados']??null;}$out['entregas'][]=array('referencia'=>$row['chave'],'estado'=>$row['estado'],'recibo'=>$receipt,'motivo'=>$receipt?null:'historico_sem_fotografia');
            foreach($j['atividades_recibo']??array() as $a){$out['atividades'][]=$a+array('referencia'=>$row['chave']);}
            if(empty($j['atividades_recibo'])&&!empty($j['criados']['atividade'])){$out['atividades'][]=array('id'=>$j['criados']['atividade'],'assunto'=>$j['atividade_plano']['subject']??null,'origem'=>'atividade_principal','prova'=>'journal_historico');}
        }
        $mails=$wpdb->get_results($wpdb->prepare('SELECT chave,estado,enviado_em,atividade_id,atividade_estado,payload,historico FROM %i WHERE record_id=%s ORDER BY atualizado_em,chave LIMIT 101',F3Base_Email_Novo_Lead::tabela(),$id),ARRAY_A);if($wpdb->last_error){$out['emails']=null;$out['emails_codigo']='leitura_falhou';return $out;}$out['mais_emails']=count($mails)>100;
        foreach(array_slice($mails,0,100) as $m){$p=F3Base_Contato_Comunicacao::abrir($m['payload'])??array();if($m['atividade_id']){$out['atividades'][]=array('id'=>(int)$m['atividade_id'],'assunto'=>$p['config']['assunto_atividade']??null,'origem'=>'email_automatico','estado'=>$m['atividade_estado'],'referencia'=>$m['chave']);}$out['emails'][]=array('referencia'=>$m['chave'],'envio_estado'=>$m['estado'],'smtp_aceito_em'=>(int)$m['enviado_em']?:null,'historico'=>F3Base_Email_Historico::projecao($m['historico']??null));
        }return $out;
    }
}
