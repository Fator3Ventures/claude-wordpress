# Exclusão Instagram — 1.57.1 / pedido 312

A rota existente f3base/leads-eliminar-registro mantém simulação padrão, record_id e revisao_esperada obrigatórios, autorização administrativa e f3base_gerir_leads. Ao aplicar, o alvo connection_id/account_id/event_id é copiado do payload cifrado para outbox também cifrado antes da remoção. event_id identifica o remetente no escopo Meta; não é o record_id nem message_id. A chave idempotente é aleatória sem dado pessoal.

A exclusão local do Core é em etapas autocommit, recuperáveis. Na 1.57.1, transação externa ou autocommit=0 são recusados ANTES de qualquer alteração local. O Core não confirma nem desfaz trabalho alheio. Depois de o chamador encerrar sua transação, releia a revisão e repita a rota.

O Core chama privacyContract, privacyStatus, eraseLocalData e erasureReceipt pelo contrato público instagram-message-erasure/1.0.0. Só depois de conferir recibo erased/local_identifiers_removed/reimportation_blocked limpa o alvo temporário e persiste recibo mínimo junto ao tombstone pelo record_id. Se o recibo do Core falhar após o Meta concluir, a chave durável permite buscar o mesmo resultado na retomada.

Leitura de contato eliminado e retorno de exclusão expõem copias_externas.meta_instagram_detalhes com estado, pendente, código e recibo. dados_eliminados trata o Core; ok=false/pendente=true quando falta confirmação do Meta. Nenhuma chamada Graph para eliminar o diário local. external_copies_erased=false permanece: mensagens na Meta, CRM, Slack e backups têm tratamento próprio.

SDK ausente, credencial MCP revogada, erro SQL, revisão concorrente ou recibo não confirmado deixam outbox. Retome a mesma exclusão como administrador; não há troca de identidade no cron. Falhas não impedem apagar os dados locais depois que o alvo foi preservado. Se nem o alvo cifrado pode ser gravado, a exclusão pausa antes de apagar o payload.

Tombstone antigo sem alvo mostra alvo_anterior_indisponivel: forneça ao operador a limitação; não adivinhe conta/conexão a partir da configuração atual. Histórico não é reconstruído. Repetir exclusão concluída devolve recibo já confirmado sem recriar contato.

Preserve f3base_instagram_exclusoes, tombstones Core e bloqueios/recibos Meta nos backups. Apagar bloqueios manualmente ou restaurar dados anteriores exige reconciliar exclusões antes de reativar ingestão. Alvo é removido após sucesso; recibo técnico permanece sem prazo. Reversão para 1.56.0 não reconhece a outbox nem retoma exclusão Meta: pause ingestão e prefira correção adiante.

Na 1.57.1, a coluna pedido LONGTEXT NULL conserva a requisição Meta cifrada antes da chamada. Falha parcial repete exatamente expected_revision e chave; revision_conflict não apaga a requisição se o status ainda indica supressão iniciada ou se o estado não puder ser comprovado. Conferem-se também o contrato do recibo e o estado final público. Alvo e pedido são removidos juntos após confirmação. Migração da 1.57.0 é aditiva; pedidos antigos começam NULL e são materializados na próxima retomada. Recibos já confirmados permanecem iguais.
