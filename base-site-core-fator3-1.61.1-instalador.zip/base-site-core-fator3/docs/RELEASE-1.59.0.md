# Fator3 Site Core 1.59.0

Base direta: **1.58.0 canônica**, preservada. Contrato administrativo **8.23.0**, sem mudança de schemas públicos. Slug e basename `base-site-core-fator3/base-site-core-fator3.php` preservados. Mínimos declarados: WordPress 7.1.2, PHP 8.3.6 de 64 bits, instalação única. Testes efetivamente executados, instalação observada e aceites externos constam do relatório da entrega.

Esta versão incorpora o retorno Google 0.22.0 ao Pedido Core 323 e considera o produtor LinkedIn 0.12.0. As capacidades comerciais 1.2.0 agora existem nesses produtores; sua disponibilidade concreta depende da seleção, concessão e referência da ação. Instalar não habilita destinos, cria concessões ou envia conversões reais. O escopo funcional dos Pedidos 314–329 e Meta 20(e) permanece descrito em RELEASE-1.58.0.md; as notas abaixo atualizam a fronteira comercial.

## Google: confirmação do mesmo evento

Google 0.22 anuncia `site-conversion-delivery/1.2.0` e a extensão `site-stage-conversion-reconcile/1.0.0`. A ingestão Data Manager devolve um recibo assíncrono: aceite inicial não significa entrega confirmada. Core 1.59 consulta esse recibo pelo método público `reconcileBound(event_id,destination_ref)` do mesmo adaptador selecionado para a ação.

O worker trata até dois recibos Google incertos por passagem, com intervalo local mínimo de 1800 segundos e reserva durável anterior à consulta. Reconstitui somente o identificador estável do evento; não remonta dados pessoais e não chama `sendBound` nesse caminho. A prova de envio expirada pode permitir consulta; revogação, referência divergente, ação alterada ou extensão ausente mantêm incerteza. `entregue` exige confirmação, e `recusado` exige `non_delivery_proven:true`. Não existe reingestão automática do evento incerto.

A incorporação conserva tabelas e options da base. A revisão da configuração é conferida antes e depois da consulta, e o commit usa a reserva atual. O backoff do produtor continua impondo seu próprio limite ao HTTP. O contador de consultas não é uma contagem de conversões confirmadas. Detalhes em RECONCILIACAO-COMERCIAL-1.59.md.

## LinkedIn e auditoria

LinkedIn 0.12 fornece `site-conversion-delivery/1.2.0`, com consumidor `site-core-quality`, finalidade `crm_stage`, concessão por ação e referência vinculada. Aquisição e etapa permanecem separadas. A capacidade anunciada pelo produtor decide a disponibilidade; não se consulta armazenamento privado de outro plugin nem se usa a ação de aquisição como alternativa.

LinkedIn 0.12 não anuncia a extensão de reconciliação Google. Seus recibos incertos conservam o comportamento sem reenvio. MCP 0.34 restringe a auditoria central comercial ao consumidor antigo; o LinkedIn pode confirmar entrega com `central_audit=service_record_unconfirmed`. Isso é limitação de auditoria central, não motivo para repetir o evento. O encaminhamento já emitido pelo mantenedor LinkedIn ao MCP é registrado no relatório principal; esta entrega não emite impacto de encerramento.

## Operação, compatibilidade e limites

Leia QUALIDADE-DESTINOS-1.58.md, atualizado para esta rodada, e RECONCILIACAO-COMERCIAL-1.59.md. Pacotes anteriores que não anunciam a capacidade continuam bloqueados para a função correspondente. Google aquisição 1.0/1.1, GA4, Meta Ads/Instagram e cliente Pipedrive mantêm seus contratos. Nenhuma nova ability administrativa Core foi criada para disparar envio ou consulta comercial diretamente; o executor e os leitores existentes conservam suas guardas.

O teste sob demanda do Pedido 322 continua parcial: aviso e e-mail automático Smart BCC, além de webhook genérico, bloqueiam antes do transporte quando não há exclusão individual segura comprovável. A instalação não supera essa dependência. Conversões reais, comparação Ads Manager/Campaign Manager, autenticação recebida de e-mail e aceites da frota continuam separados das fixtures.

Pipedrive 0.3 exige PHP 8.3.36 e não deve ser ativado no piso PHP 8.3.6 do Core. Os ambientes efetivamente exercitados estão no relatório; números de versão não substituem capacidades e permissões.

## Atualização e reversão

Caminho normal: 1.58.0 → 1.59.0, sem intermediária. O salto 1.57.1 → 1.59.0 corresponde ao Site-Teste ainda nessa base e exige prova própria; não deduzir seu aceite do ciclo 1.58.0. A 1.59 não introduz tabela, opção ou migração destrutiva. Preservar banco, salts/chaves, diretório privado, recibos e guarda operacional.

Voltar os arquivos para 1.58.0 preserva os recibos, mas interrompe a consulta automática de incertos comerciais Google. Não apagar recibos, trocar event_id nem voltar um incerto a pendente para tentar confirmar entrega. Antes de restore, pausar e drenar pelo fluxo Core e reconciliar efeitos externos. A instalação remota e a comprovação de sua conclusão pertencem ao relatório, não à presença deste guia.
