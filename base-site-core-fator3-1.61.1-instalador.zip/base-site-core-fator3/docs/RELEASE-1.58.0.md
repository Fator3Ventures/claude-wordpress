# Fator3 Site Core 1.58.0

Base direta: **1.57.1 canônica**. Contrato administrativo **8.23.0**, aditivo. Slug e basename `base-site-core-fator3/base-site-core-fator3.php` preservados. Mínimos declarados: WordPress 7.1.2, PHP 8.3.6 de 64 bits, instalação única. A prova efetivamente executada e seus limites constam do relatório externo, não deste guia comportamental.

Esta versão trata dos Pedidos core 314–329 e do consumidor solicitado pelo impacto Meta 0.13.0, revisão 2, Meta 20(e). Não cria canário diário nem marcos operacionais, excluídos pelo dono.

## Contatos e retorno comercial

| Pedido | Comportamento |
| --- | --- |
| 314 | Atribuição nativa `informado` aparece como “Informado pela plataforma”; entrada vazia não vira `/`. A nota de entrada inclui a fonte do nome da campanha. Fotografias de avisos anteriores não são reescritas. |
| 315 | Observações cifradas do negócio guardam valor, moeda e fechamento, inclusive mudança apenas de valor. O relatório deduplica negócios e separa moedas. Valor para Meta exige opção própria, desligada por padrão. |
| 317 | Abandono de formulário iniciado e não aceito informa nome técnico do último campo, etapa e quantidade preenchida, sem valores. A definição/revisão usada no navegador é conferida. |
| 318 | Uma primeira mensagem WhatsApp pode confirmar exatamente um contato do site pelo E.164 na janela configurada, sem novo registro, CRM ou conversão. Ausência ou ambiguidade mantém a captura separada com motivo. |
| 319 | Contato aceito registra o anterior por e-mail/telefone exatos no mesmo site, em 30 dias por padrão. Supressão de conversão é independente por destino e permanece desligada por padrão. |
| 320 | Primeiro instante observado de resposta da equipe no Slack/CRM, sem texto; mediana/p75 em segundos corridos e cobertura explícita. |
| 323 | Desfecho por contato inclui motivos fechados/ICP e observações comerciais. Ações Google/LinkedIn por etapa têm prévia e recibos próprios; os adaptadores atuais não implementam o contrato proposto para esse envio. |

Leia CONTATOS-COMERCIAL-1.58.md. O vínculo de identidade é uma correspondência de identificadores, não prova de identidade civil. Dados ausentes, falta de permissão e limites de leitura permanecem explícitos.

## Conversões e anúncios

Pedido 316: o Core negocia `site-conversion-delivery/1.1.0` com Google 0.21.0, conserva o destino vinculado e só entrega `user_data` quando a capacidade e a prontidão são anunciadas. Consentimento atual/capturado, prazos e supressões continuam obrigatórios. Sem clique, a conta e a ação precisam de prova vigente de conversões otimizadas de leads; a prévia mostra hashes, sem enviar ou criar fila. Instale o Google compatível antes de habilitar o recurso.

Pedido 323: `site-conversion-delivery/1.2.0` com propósito `crm_stage` é uma **proposta de contrato opcional do Core**, ainda não entregue por Google 0.21.0 ou LinkedIn 0.11.0. A configuração não transforma essa proposta em capacidade do fornecedor: `adaptador_etapas_nao_suportado` bloqueia o envio. Nunca reutilizar silenciosamente a ação de contato. Detalhes em CONVERSOES-1.58.md e nos impactos aos responsáveis.

Meta 20(e): consumidor de `meta-ads-reader/1.0.0` lê o acervo local concedido do Meta 0.13.0 por campanha, com moeda/fuso/atribuição/observação e vínculo explícito de parceiro. Não faz Graph, não recebe tokens e não duplica acervo. Revisitas substituem observações no produtor; cursores de outra geração são recusados. Consulte META-ADS-CORE-1.58.md. A comparação real de 30 dias com Ads Manager é aceite separado da frota.

## Operação

| Pedido | Interface e regra |
| --- | --- |
| 321 | `f3base/midia-prontidao-ler`: prontidão local Meta/Google Ads/LinkedIn com fonte, motivo e ação. Não consulta fornecedor nem altera configuração. |
| 322 | `f3base/caminho-lead-testar`: simulação padrão, revisão e chave de operação; execução sob demanda com recibo e limpeza autoral. CRM real limitado aos sites autorizados. Saltos sem limpeza individual comprovável ficam bloqueados antes do efeito. |
| 324 | `f3base/resumo-operacional-ler`: resumo local até 4 KiB, projeção `campos`, rotas de detalhe e omissões indicadas. `compacto` nas leituras operacionais selecionadas. Validade desconhecida não vira zero. |
| 325 | `f3base_marcas_vigiadas`: nomes, domínios e caminhos permitidos próprios de cada site; achados no HTML público e fotografia local de contagens. |
| 326 | Uma sequência por ciclo após confirmação no executor: cabeçalhos/cache, navegação e catálogo Pipedrive ativo. Resultados com instante/código; falha gera aviso sem bloquear a instalação. |
| 327 | `f3base_email_site.wp_mail_pela_caixa`, desligado por padrão: SMTP autenticado, cota compartilhada e fila cifrada; falha/incerteza não usa PHP mail. Cede a plugin SMTP reconhecido. |
| 328 | Operações por JSON Pointer, leitura por caminhos e hashes canônicos das subchaves; revisão e validação integral preservadas. |
| 329 | Avisos técnicos por e-mail próprio, padrão `admin_email`; erro real pode avisar imediatamente, atraso sem erro exige pelo menos 60 minutos, recuperação só após atenção aceita. |

Leia OPERACAO-1.58.md e CAMINHO-LEAD-1.58.md. Prontidão local não comprova entrega, leitura humana, autenticação DMARC ou acesso externo a partir de outro ponto de rede.

## Atualização e reversão

Atualização direta 1.57.1 → 1.58.0, sem intermediária. Tabelas/colunas novas são aditivas; defaults conservam escolhas anteriores. Preservar banco, salts/chaves de cifra, diretório privado e guarda operacional. Os contratos GA4/Instagram e a requisição cifrada de exclusão introduzida na base continuam presentes.

Não trocar arquivos para trás com entregas/testes em andamento. A base 1.57.1 não interpreta os novos diários e proteções; arquivos antigos não desfazem e-mails, CRM, mensagens ou exclusões. Pause e drene o executor pelo fluxo de recuperação antes de uma reversão deliberada, preservando recibos e objetos externos. Prefira correção adiante. O relatório final enumera testes, instalação observada e pendências por responsável.
