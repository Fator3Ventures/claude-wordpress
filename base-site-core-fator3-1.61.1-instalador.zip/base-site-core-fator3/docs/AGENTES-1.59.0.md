# Agentes — Core 1.59.0

Leia DOCUMENTACAO.md, RELEASE-1.59.0.md e RECONCILIACAO-COMERCIAL-1.59.md. Base canônica 1.58.0; contrato administrativo 8.23.0 preservado. O catálogo instalado em `docs/dados/abilities-*.json` define nomes, schemas e permissões. Leia o índice e todas as páginas de `f3base/documentacao-ler`, conferindo versão, hash e `proxima_linha` até o fim.

Comece por `f3base/resumo-operacional-ler` e use as rotas de detalhe para campos omitidos. A prontidão é uma leitura local, não autorização para conceder conta, enviar conversão ou produzir teste externo. Não renovar token nem reparar fila para tornar uma leitura aparentemente pronta.

No Pedido 323, descubra `supported_contracts`, negocie `site-conversion-delivery/1.2.0` com `consumer_id=site-core-quality`, `purpose=crm_stage` e ação exata, e preserve `destination_ref`. Google 0.22 e LinkedIn 0.12 implementam o produtor; versões anteriores permanecem utilizáveis nas funções que efetivamente anunciam. Configuração de etapa não concede acesso nem muda a ação de aquisição.

Um recibo Google inicialmente incerto pode ser consultado somente pela extensão anunciada `site-stage-conversion-reconcile/1.0.0`, no mesmo evento/ação/vínculo. O worker mantém mínimo local de 1800 segundos e até dois incertos por passagem; o produtor pode impor espera maior. Não chamar `sendBound` para sondar confirmação. Não alterar timestamp, estado, referência, revisão ou chave no banco para antecipar a consulta.

Prova de envio expirada não equivale a revogação: pode continuar permitida a consulta do evento já admitido. Concessão revogada, ação/configuração alterada, referência antiga ou ausência de extensão conservam o recibo incerto, com motivo. `reconciliados` indica chamadas de consulta, não entregas. A operação administrativa `google/reconcile-stage-conversion` altera somente o recibo do Google; não modifica diretamente a tabela Core.

LinkedIn 0.12 não recebe a extensão Google por inferência. `service_record_unconfirmed` no registro central MCP não autoriza reenvio de uma entrega confirmada nem a mudança do consumidor para aquisição. Preserve o diário local e acompanhe o impacto LinkedIn → MCP já existente no relatório; não criar outro impacto somente para confirmar atendimento.

Configuração continua por leitura de revisão, simulação e aplicação da mesma intenção. Permissões, consentimento atual/capturado, supressões, classe de teste e elegibilidade precedem novos envios. As instruções operacionais da 1.58 continuam vigentes onde a 1.59 não as atualiza. Teste 322 não é aceite integral enquanto houver saltos ou limpezas bloqueados/incertos.

A atualização autorizada no Site-Teste deve usar o instalador exato por `plugins/upload-base64`, quando disponível no schema corrente, com identidade, slug e chave idempotente. A rota aceita conteúdo Base64 ou caminho privado autorizado e evita estágio público. Preserve pré-imagem/recibo; verifique nova requisição, ciclo do executor, provas automáticas 326, home/REST e leitura integral da documentação. Não atribuir uma verificação manual à sequência automática. Instalação não habilita grants, contas ou conversões de teste.

Antes de restore, siga a recuperação Core. Preserve salts, diretório privado, tombstones e diários. Não reinicializar fila/cota nem repetir resultado incerto. Contas reais e implantação na frota permanecem sob seu responsável autorizado; não são inferidas dos testes locais ou da instalação no Site-Teste.
