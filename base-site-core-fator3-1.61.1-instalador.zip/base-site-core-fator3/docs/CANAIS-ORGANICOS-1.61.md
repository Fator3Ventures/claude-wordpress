# Regras orgânicas e catálogo IA — 1.61.0

As opções são revisionadas pelas rotas config-core. Padrões: regras vazias, catálogo IA do pacote somado a nenhuma extensão. A atualização não muda canais históricos nem cria opções no Pipedrive.

`f3base_canais_organicos` é lista ordenada. Cada item tem `id`, `condicoes` e `resultado` textual (até 80 caracteres). Condições disponíveis: `canal`, `utm_source`, `utm_medium`, `utm_source_platform`, `referrer`; valores em listas. Entre campos: E; dentro da lista: OU; primeira regra correspondente vence. Host de referência exato, sem wildcard. Resultados reservados de mídia paga são recusados. Exemplo:

```json
[{"id":"assistente","condicoes":{"canal":["ia"]},"resultado":"ia_organica"}]
```

`f3base_origens_ia`: `modo` somar/substituir e `provedores`, cada um com `id`, `nome`, `aliases_utm`, `dominios` (host e subdominios). Somar une marcas/hosts ao padrão; substituir permite catálogo próprio. A revisão é fotografada por captura. Marcas não autenticam origem nem comprovam citação.

`f3base/canais-organicos-simular` recebe parâmetros candidatos e/ou `contatos_30_dias=true`, com página. Até 100 contatos por página; `proxima_pagina` indica continuação. Requer administração e, para contatos, leitura de dados pessoais. Mostra resultado gravado e simulado, respeitando restrição de consentimento; não grava nem faz HTTP. `regras` e `catalogo_ia` opcionais permitem ensaio antes de salvar.

A prova paga do Core precede toda regra orgânica; `gclid` com ChatGPT permanece Google Ads. Sem regra, `nao_identificada`. O contato guarda `dados.canal_crm` com chave, ID da regra, revisão, revisão IA e fonte. O Pipedrive traduz a chave por `f3base_pipedrive.mapa_canais`; o ID deve ser uma opção válida do catálogo da conta. Nota informa assistente e regra. Revogação de medição remove a apresentação da origem, preservando política de consentimento anterior.

Para configurar: simular, salvar regras com CAS, criar/selecionar a alternativa autorizada no Pipedrive, atualizar mapa_canais com revisão e testar contato marcado no ambiente autorizado. Não alterar registros históricos automaticamente.
