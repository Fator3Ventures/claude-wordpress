# Operação e configuração — Core 1.58.0

Pedidos core 321 e 324–329. Este guia descreve o contrato; as provas de implantação, fornecedor e mínimos estão no relatório da entrega. Os schemas instalados são a referência exata dos argumentos.

## Prontidão e resumo local

`f3base/midia-prontidao-ler` não faz HTTP para fornecedores. Retorna Meta, Google Ads e LinkedIn, com linhas de estado `pronto`, `atencao` ou `bloqueado`, código, fonte e ação. Combina pixel/dataset, transporte/prova, contato/material, Insight Tag/regra, contratos de conversão, captação nativa, consentimento, mapa comercial/campanhas e último contato pago entregue. Um item não aplicável ou não configurado conserva seu motivo; a ausência de prova não vira prontidão.

A leitura pública de produtor é restrita a contratos locais: `meta/health`, `meta/list-connections`, `linkedin/status`, `linkedin/diagnose-conversions`, `google/status` e capabilities dos adaptadores. Auditoria local do produtor pode registrar a leitura; não há concessão, reparo, renovação de token ou envio comercial por esta consulta.

`f3base/resumo-operacional-ler` reúne os grupos `pacotes`, `atualizacao`, `recuperacao`, `cron_24h`, `avisos`, `perfil`, `caixa`, `filas`, `prontidao`, `credenciais` e `contatos`, cada um com rota de detalhe. O alvo é JSON UTF-8 de até 4096 bytes. Listas excedentes indicam omissão; não interpretar a página curta como inventário integral. `campos` projeta os grupos necessários. `f3base/credenciais-resumo-ler` detalha validades conhecidas, sem valores secretos; `null` significa validade não informada, não token eterno ou expirado. Contagens cron conservam indicação de cobertura da janela.

`compacto:true` em `f3base/saude-ler` usa a visão operacional breve. `f3base/pipedrive-fila-ler` e `f3base/executar-pendentes` também aceitam resposta compacta; na execução, simulação/revisão e guardas de mutação continuam valendo. Reduzir resposta não reduz autorização nem confirma o sucesso das operações detalhadas.

## Provas após a atualização

Depois de `confirmada_no_executor_em`, `f3base_pos_atualizacao_verificar` acompanha uma sequência por ciclo: cabeçalhos/cache, navegação e catálogo da conta Pipedrive quando ativo. A ordem evita que a purga invalide uma prova de navegação recém-feita. O intervalo mínimo de verificação é respeitado antes da reserva; limpeza de cache só ocorre quando pendente.

Cada etapa tem reserva durável anterior ao efeito, instante, estado e código. Interrupção depois da reserva produz `incerto` sem repetição automática. O resultado fica junto ao ciclo de atualização e aparece em `como-usar`/resumo. Falha gera aviso de configuração, mas não invalida etapas de instalação já concluídas. Catálogo desligado é explícito; conta sem autorização não é declarada verificada. Não executar os verificadores manualmente para depois atribuir essa prova à sequência automática.

## Marcas no conteúdo

`f3base_marcas_vigiadas` é uma lista, inicialmente vazia. Cada item contém `nome`, `variacoes`, `dominios` e `caminhos_permitidos`. Domínios não aceitam protocolo, porta ou curinga. Caminhos são locais e exatos, sem query/fragmento/curinga; não são copiados de outro site automaticamente. Configure somente outras marcas a vigiar. Exceção de uma marca em um caminho não autoriza as demais.

`f3base/conteudo-instrumentacao-ler` acrescenta menções e links por URL. Cada ocorrência indica marca, trecho até 80 caracteres, superfície (`corpo`, `cabecalho`, `rodape` ou `dados_estruturados`) e permissão do caminho. JSON-LD inclui referências como `sameAs`. O parser não executa JavaScript; conteúdo que só surge após execução não é comprovado. Limites de 200 ocorrências, 15 mil nós e inspeção limitada de JSON produzem cobertura parcial explícita.

Uma tarefa separada observa duas páginas publicadas por passagem e renova a fotografia diária. `como-usar` lê essa fotografia local sem GET. Revisão diferente, conteúdo removido, erro HTTP ou cobertura parcial não certificam ausência de menções. O estado de inspeção não altera conteúdo automaticamente.

## wp_mail pelo SMTP da caixa

`f3base_email_site.wp_mail_pela_caixa` é `false` por padrão. Para habilitar, configurar endereço, nome de exibição, usuário, senha, servidor/porta/TLS e prova vigente da caixa. O remetente usa a caixa autenticada. O transporte preserva destinatários To/Cc/Bcc, Reply-To, conteúdo e anexos suportados, materializados no MIME cifrado da fila. O recibo público não devolve assunto, corpo ou destinatários.

A cota de destinatários é compartilhada com os envios da caixa. Retenção por cota fica `pendente` e pode fazer `wp_mail` retornar aceite local antes da entrega. A fila reavalia o saldo; falha ou resultado incerto não é reenviado automaticamente. A credencial/identidade deve continuar compatível com a usada na reserva. Não há fallback para PHP mail quando o transporte Core está ativo.

O Core cede quando reconhece outro plugin SMTP ativo ou a chamada já foi interceptada; o aviso identifica essa condição. Isso não testa o transporte alheio. `f3base/email-wordpress-fila-ler` e o bloco `email_wordpress` de `como-usar` mostram estado, fase e código. A própria autenticação SMTP não prova DKIM/SPF/DMARC do destinatário: o aceite exige cabeçalhos recebidos e observação externa. E-mail automático ao novo lead e resposta explícita da caixa conservam seus fluxos próprios.

## Avisos técnicos

`f3base_avisos_tecnicos` contém `email` e `atraso_minutos`. E-mail vazio usa `admin_email`; prazo padrão 60, mínimo 60 e máximo 1440 minutos. Esse destino é independente de `f3base_avisos` e não envia ao Slack dos contatos.

Saúde da caixa: erro efetivo de autenticação/TLS/IMAP/pasta/movimentação pode avisar na primeira ocorrência. Atraso sem erro só avisa depois do prazo desde a última leitura completa. Recuperação só é anunciada se o aviso de atenção anterior foi aceito pelo transporte. Um `wp_mail` aceito localmente pode aguardar cota; recebimento externo não é presumido. Destino, prazo e política constam de `como-usar`.

## Operações por caminho e hash

`f3base/config-core-ler` aceita `nome`, `caminhos` e `hash`. Caminhos usam JSON Pointer: `/email`, `/0/campos/0/rotulo`; `~1` representa `/` e `~0`, `~`. A resposta distingue caminho ausente de valor `null`. `hash:true` devolve SHA-256 canônico de cada subchave de primeiro nível sem exigir seus valores. Mapas são ordenados canonicamente; a ordem das listas é significativa. Segredos não têm projeção nem hashes.

Em `f3base/config-core-escrever`, envie `operacoes` com `revisao_esperada`; `simular` continua padrão. As operações são aplicadas em ordem à fotografia da revisão, e o resultado inteiro passa pelo schema, normalização e validações do dono. O commit preserva a guarda de revisão.

| Operação | Parâmetros adicionais | Regra |
| --- | --- | --- |
| `definir` | `valor` | Substitui o caminho; índice de lista deve existir. |
| `remover` | — | Caminho deve existir; lista é reindexada. |
| `acrescentar` | `valor` | Acrescenta item completo à lista indicada. |
| `remover_de_lista` | `chave:{campo,valor}` | Exige exatamente um item com igualdade tipada; zero ou vários são recusados. |

Não combinar `operacoes` com `valor` ou `mesclar`. Segredos e a operação especializada de redirects conservam seus fluxos próprios. Até 50 operações, caminho até 500 caracteres e profundidade 16. Pai inexistente é recusado; não se criam objetos intermediários por adivinhação. Simulação mostra antes/depois somente dos caminhos tocados. A resposta de escrita evita repetir o valor completo. Conflito exige reler; não reaplicar com revisão presumida.

Exemplo somente de simulação, substituindo `REVISAO_LIDA` pela revisão real:

```json
{"nome":"f3base_avisos_tecnicos","revisao_esperada":"REVISAO_LIDA","simular":true,"operacoes":[{"operacao":"definir","caminho":"/atraso_minutos","valor":90}]}
```
