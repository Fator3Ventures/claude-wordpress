# Fator3 Site Core 1.57.1

Base direta: 1.57.0 canônica; contrato administrativo 8.22.1 (campos opcionais aditivos). Consolidação das duas implementações dos pedidos 312 e 313, solicitada pelo dono. WordPress >=7.1.2 e PHP >=8.3.6, 64 bits. Instalador 1.57.0 de referência: SHA-256 5a829a78b3a2265560a88a0dde969fd435fd502ea2072e21ae8f47aeabf13ca6.

## 312 — Instagram

Mantidos alvo cifrado, chave aleatória durável, outbox e recibo junto ao tombstone. O Core agora recusa transação externa ou autocommit=0 ANTES de iniciar qualquer eliminação local de Instagram. Nunca confirma nem desfaz transações alheias. Depois de o chamador encerrá-las, execute novamente a operação com a revisão atual.

A coluna aditiva pedido (LONGTEXT NULL) guarda a requisição cifrada, inclusive expected_revision, antes do SDK Meta. Uma falha parcial conserva exatamente essa requisição; revision_conflict só libera nova leitura se o status público comprovar ausência de supressão iniciada. Recibo, contrato e estado final são conferidos; alvo e pedido são apagados juntos após confirmação. A mesma chave permite recuperar sucesso no Meta após falha da gravação Core. Operações concorrentes de eliminação do mesmo contato têm trava local. Leitura de recibo mostra a disponibilidade real do contrato de exclusão.

## 313 — GA4

Preservados schema, sete recortes, fuso, filtros, cursor cifrado, publicação atômica, exportação base64 com hash e retenção sem expiração. Respostas exigem contrato, auditoria, revisão, headers, data, paginação e métricas numéricas válidas; cursor repetido, contagens divergentes e falha de cifragem impedem publicar a nova fotografia. Fotografias anteriores permanecem disponíveis.

Início vazio agora fixa inicio_efetivo no estado, na primeira coleta; inclui o dia mais antigo já conhecido ao atualizar. Não desloca silenciosamente a janela inicial. Pendências em andamento têm prioridade; histórico e datas recentes alternam. A retenção finita limita também a seleção, evitando recolher dias já expurgados. Dia manual fora dessa política retorna dia_fora_da_retencao.

Campos novos e opcionais de f3base_ga4_acervo: revisitar_dias=3 (1–90) e limite_pagina=1000 (1–1000). Defaults efetivos da 1.57.0 preservados. Horário usa o fuso configurado da propriedade; agenda diária recalculada por evento único acompanha mudanças de horário de verão. Não há ativação ou concessão automática. A barreira de recuperação cobre a coleta; restore invalida os cursores GA4 em andamento e inventaria esse efeito.

Consultas/exports aceitam pagina_qualidade para percorrer 10 registros de qualidade de cada fotografia; ga4-historico aceita coleta e limite. Sem esse campo, o formato completo anterior continua disponível dentro do orçamento. A navegação do painel carrega a revisão da fotografia. ga4-comparar aceita revisao_anterior, independente da revisão atual. relatorios-integrados-ler acrescenta ga4_propriedade, ga4_recorte, ga4_revisao e ga4_revisao_anterior, sem combinar métricas próprias com GA4.

## Convivência e operação

MCP 0.33.0, Google 0.20.0, Meta 0.12.0, LinkedIn 0.11.0 e Pipedrive 0.2.0. Contratos ga4-reader/1.0.0, instagram-message-erasure/1.0.0 e pipedrive-api-client/1.0.0 preservados. Nenhum pacote acompanhante alterado. Instalação continua com 17 etapas. A alteração de banco é somente pedido nullable na outbox; dados GA4, opções e tombstones canônicos são preservados. O candidato paralelo não publicado não é base de migração.

Use DOCUMENTACAO.md, ACERVO-GA4-1.57.md, INSTAGRAM-EXCLUSAO-1.57.md e os schemas instalados. Prova com SDK real e fornecedor simulado não homologa credenciais nem propriedade GA4 real. O relatório externo distingue os ambientes testados. Backup deve incluir banco, salts e guarda operacional. Reverter arquivos não desfaz exclusões Meta nem banco; prefira correção adiante. Não publique na frota como consequência da instalação de teste.
