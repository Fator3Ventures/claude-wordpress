# Agentes — Core 1.60.0

Leia DOCUMENTACAO.md e RELEASE-1.60.0.md. Normas 01/02 revisão 5; contrato 8.24.0. Use o catálogo instalado, leitura de revisão, simulação e aplicação da mesma intenção. Não invente abilities nem escreva armazenamento de acompanhantes. Leia integralmente os documentos via f3base/documentacao-ler, conferindo versão, hashes e paginação.

Pedidos 322 e 330–334 são desta rodada. Os pedidos 314–321 e 323–329 foram aceitos pela frota na base 1.59. Registre resultados de retornos no relatório principal. Encaminhamento de impacto só quando houver consequência técnica, segundo norma 02 revisão 5.

Meta: renovar concessão uma vez depois da atualização; editar parceiro não requer nova concessão. Preservar revisao_acesso lida. Aumentar revisao editorial ao mudar configuração. Mudança de acesso gera nova geração automaticamente e não restaura concessão antiga ao retornar.

Caminho do lead: prévia obrigatória, revisão e chave única; sem repetição de envio incerto. Caixa própria precisa de autorização em homologacao_emails, envio ativo, cota e UIDPLUS. Não autorize ou configure caixas automaticamente. Recibo aponta saltos e limpeza; resultado com_pendencias é honesto. CRM real apenas nos sites ctooffice/korvena .com.br autorizados, com prefixo de teste e eliminação. Site-Teste não é ambiente de CRM real. Não habilitar canário diário nem marcos operacionais rejeitados pelo dono.

Credenciais: formato é aviso. Não restaure regex como veto; não contorne rejeição do fornecedor. Preserve limite, controles, segurança dos endereços, CAS, cifra e confirmação de identidade. Clarity consome cota manual para validar candidata. Remoção explícita continua distinta de credencial em branco no formulário.

Diagnóstico de coleta: automação fica separada; ausência de visita não prova falha. Contagem de renovação exige lote aceito e prova vinculada. Configuração de marcas é específica de cada site. Exceção de dados estruturados não autoriza texto de corpo.
