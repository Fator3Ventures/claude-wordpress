# Agentes — Core 1.61.1

Contrato 8.26.0; base 1.61.0. Comece por DOCUMENTACAO.md, RELEASE-1.61.1.md e ACERVOS-E-EMAIL-1.61.1.md. Leia schemas completos em dados/configuracao-schema.json e dados/abilities-*.json através de `f3base/documentacao-ler` com paginação/hash. Configuração nova exige revisão e concessão explícitas do produtor; não ativar automaticamente no upgrade.

Novos consumidores encerram a pendência de implementação Core337/340/341/342 e343(c) indicada na nota1.61.0. Os aceites reais nas contas citadas continuam separados das provas sintéticas. Respeite fonte, cobertura, moeda, fuso, precisão e permissões. Consultas anônimas GSC e termo individual inexistente no click_view permanecem indisponíveis.

Para diagnóstico, leia os status locais primeiro. Nunca faça chamada de fornecedor para preencher uma página de relatório. Após revogação/revisão, reinicie o cursor e solicite nova concessão ao responsável. Use o executor normal de tarefas para retomadas autorizadas; não manipule tabelas ou opções privadas. CRM real somente ctooffice.com.br/korvena.com.br sob autorização do dono, nunca Site-Teste.
