# Contatos e retorno comercial — Core 1.58.0

Pedidos core 314, 315, 317–320 e 323. Schemas atuais em `dados/abilities-*.json` e `dados/configuracao-schema.json`; o relatório externo distingue implementação, testes locais e aceites reais.

## Apresentação da atribuição

O modelo `informado` usa “Informado pela plataforma”. Uma entrada vazia continua vazia e é omitida da apresentação, sem criar `/` ou uma sessão. A nota de entrada do Pipedrive inclui `nome_campanha_fonte` junto do nome quando disponível. A alteração afeta novas apresentações; fotografias cifradas já entregues não são reescritas nem contatos antigos reenviados automaticamente. A base 1.57.1 ainda omitia a fonte do nome da campanha na nota; esta versão corrige essa composição.

## Abandono de formulário

Formulário iniciado e ainda não aceito pode emitir `form_fechado` ao fechar o diálogo ou sair da página. São observados nome técnico do último campo com foco/alteração, etapa e quantidade preenchida. Nenhum valor digitado integra esses campos de telemetria. A definição de campos pertence à revisão exibida, incluindo página em cache; nome de campo arbitrário não passa pela validação. Eventos legados sem o novo detalhe permanecem distinguíveis.

A visão `formularios` de `f3base/relatorios-integrados-ler` mantém o funil por formulário/revisão e acrescenta abandono por campo/etapa. Aceite posterior não deve ser contado como abandono definitivo. Uma saída sem beacon recebido ou sem consentimento não é observação; zero eventos não prova que ninguém abandonou. Reabertura/abas e revisões diferentes não são mescladas como uma única sequência comprovada.

Detalhes de correlação, complemento, prova de definição e cobertura em FORMULARIOS-ABANDONO-1.58.md.

## Correspondência de contatos

`f3base_contato_identidade.janela_dias` vale 30 por padrão (1–365). No aceite, o Core procura registros anteriores aceitos, fora da lixeira/eliminação e na mesma classe de teste, com e-mail ou telefone normalizado exatos. O novo registro recebe `registro_anterior` com record_id, método, minutos e tipo de correspondência. A busca limitada declara cobertura incompleta quando excedida; não inventa resultado negativo. Não há comparação entre sites nem identificação probabilística.

`suprimir_conversoes` possui `ga4`, `google_ads`, `meta` e `linkedin`, todos `false` por padrão. Quando ligado para o destino, registro anterior na janela bloqueia a nova conversão; verificação incompleta também não é tratada como elegibilidade. O motivo aparece no recibo. A supressão não apaga o contato, não funde pessoas do CRM nem reclassifica envios históricos. Aviso e nota indicam “Já era contato há N min por método”.

A visão `identidade` mostra registros, pessoas distintas por identificadores e registros sem identificador. Trata-se de estimativa no recorte: e-mail/telefone compartilhado pode unir pessoas diferentes; registros sem identificador contam separadamente. Não é contagem de identidades civis certificadas.

## Conversa WhatsApp confirmada

`f3base_whatsapp_site.janela_horas` define a janela antes da primeira mensagem (padrão 24). Exatamente um contato do site com o mesmo E.164 permite vínculo e marca `conversa_confirmada`, com instante da primeira mensagem. Não cria outro contato, lead ou conversão. Contato só com e-mail não é candidato. Zero ou vários candidatos mantém o comportamento de registro da conversa, com motivo; busca incompleta é bloqueio explícito.

Decisão e persistência usam a mesma trava de captura, com transação para o vínculo e a marca. A exclusão conserva tombstone para impedir reimportação. Não inferir sessão web a partir da mensagem. A visão `identidade` inclui contagens de conversas confirmadas dos contatos WhatsApp por superfície/campanha.

## Primeira resposta observada

`f3base_primeira_resposta` contém `ativo`, `janela_dias` (padrão 90) e `pipedrive_usuarios_humanos`. No Slack, exige thread/autoria/workspace esperados, usuário ativo da equipe e ausência de bot/app/convidado; a leitura depende dos escopos de histórico e `users:read`. O texto da conversa não é persistido pelo observador.

No Pipedrive, selecione explicitamente usuários ativos da equipe, diferentes da integração. Nota automática, atividade/e-mail automático conhecidos, rascunho ou mensagem não enviada não valem como resposta humana. São sinais verificáveis da API, não prova universal de ação manual. E-mail de lead sem negócio vinculado pode não ter a mesma cobertura da API de negócios.

O menor instante válido após a captura é guardado com fonte/tipo; primeira atividade concluída fica separada. `f3base/contato-primeira-resposta-atualizar` simula por padrão; a aplicação consulta fontes vinculadas e persiste somente instantes/cobertura. Worker paginado e limitado respeita as esperas; ausência de observação não significa ausência de atendimento.

Visão `primeira_resposta`: contagens com/sem resposta, mediana e p75 em segundos corridos por canal/campanha/parceiro. p75 usa a posição mais próxima. Dimensões comerciais informam sua proveniência; um mapeamento atual não é apresentado como fotografia histórica do CRM.

## Valor, moeda e motivos

`f3base_desfechos` configura campos fechados de ICP, perda, arquivamento e desqualificação, além do mapa legado de motivos. Os campos precisam existir no catálogo da conta e ser enum/set. Guardam-se códigos/rótulos conhecidos; texto livre ou opção desconhecida não é exibido como motivo.

Cada observação de negócio inclui `value`, `currency`, estado e instante de fechamento informado. Alteração só de valor produz evento com anterior/atual. Webhook parcial pede releitura antes de registrar a observação completa; consulta periódica continua com sua cobertura própria. Valores usam decimal de seis casas; valor/moeda ausentes são explícitos, nunca zero inventado. `meta_enviar_valor` é desligado por padrão.

`f3base/contatos-qualidade-ler` combina etapa/histórico, desfecho, motivos/ICP, primeira atividade e criação do negócio. Visão `desfechos` agrega a observação mais recente de cada negócio, deduplicado por conta+ID no recorte, preservando vários negócios do mesmo contato e separando moedas. Visão `comercial` agrega etapas/rótulos por plataforma/campanha/anúncio. Contagem de contatos em etapa não é a mesma unidade de negócios ou gasto.

O estado de webhook informa prova local de assinatura e último evento, à parte da consulta periódica. Uma assinatura histórica não prova que a conta ainda entrega todos os eventos; comparar identidade/revisão e instante. Fluxo de consulta atual não garante etapas intermediárias nunca observadas.

## Envio comercial por etapa

`f3base_qualidade_destinos` mantém Google Ads e LinkedIn desligados por padrão; mapeia etapa local para ação própria do destino. A prévia `f3base/qualidade-conversoes-previa` não cria fila nem envia. Os pacotes atuais não implementam o contrato opcional 1.2.0 proposto; o bloqueio permanece até anúncio explícito. Leia CONVERSOES-1.58.md. A etapa escolhida para otimização de lances continua decisão do Growth Campanhas.
