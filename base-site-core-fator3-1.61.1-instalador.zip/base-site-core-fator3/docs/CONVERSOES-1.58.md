# Conversões de contato e de etapa — Core 1.58.0

Pedidos core 316 e 323. Conversão de contato e retorno comercial são propósitos distintos. Permissões, consentimento, destino histórico e recibos continuam obrigatórios. O Core não acessa tokens ou tabelas privadas dos adaptadores.

## Google: contrato entregue 1.1.0

O Google 0.21.0 anuncia `site-conversion-delivery/1.1.0` e preserva 1.0.0. O Core consulta primeiro as capacidades legadas e só negocia 1.1.0 quando anunciado. O novo objeto precisa devolver o mesmo `destination_ref`; uma troca de destino não é inferida nem aplicada.

A capacidade `enhanced_leads` precisa anunciar suporte e campos `email`/`telefone`. Envio com dados pessoais exige também prontidão, termos de dados aceitos, recurso habilitado, conta/ação coerentes e prova local `checked_at`/`expires_at` vigente. O Core passa e-mail/telefone normalizados somente nesse contrato; o pacote Google normaliza e aplica SHA-256 antes do transporte ao fornecedor. Não incluir valores brutos em recibos ou diagnósticos.

Com clique válido, o contrato anterior continua utilizável. Mais de um entre gclid/gbraid/wbraid é ambíguo. Sem clique, dados de usuário só são elegíveis com a prontidão de conversões otimizadas de leads; do contrário, motivos como `enhanced_leads_not_ready`, `enhanced_leads_user_data_invalid` ou `identificador_clique_ausente` permanecem no recibo. Não fabricar identificador ou horário de clique.

`f3base/google-conversao-previa` recebe `record_id`, exige administração e leitura de contatos, não enfileira nem faz envio. Mostra `userIdentifiers` em hash, tipos de clique, contrato e motivos. Um contato de teste pode ser inspecionado, mas continua inelegível para envio real. Hash demonstrativo não é aceitação do Google. A entrega vinculada usa o mesmo adaptador/capacidade que preparou o payload; a fila registra incerteza antes do HTTP e conserva a reconciliação do produtor.

## Etapas: proposta opcional 1.2.0

**Google 0.21.0 e LinkedIn 0.11.0 ainda não implementam esta capacidade.** A descrição abaixo é o contrato que o consumidor Core está preparado para negociar, encaminhado aos mantenedores; não é declaração de API entregue por esses plugins. Configuração ou prévia local não substitui anúncio de capacidades.

`f3base_qualidade_destinos`:

- `google_ads:{ativo:false,acoes:{}}` e `linkedin:{ativo:false,acoes:{}}` por padrão.
- Chave de `acoes`: ID de etapa existente no Core.
- Google: recurso `customers/<conta>/conversionActions/<acao>`; LinkedIn: ID numérico da regra.
- Cada etapa usa ação distinta no mesmo destino. A ação de contato não deve ser reutilizada como ação comercial.

O adaptador legado precisa anunciar `site-conversion-delivery/1.2.0` em `supported_contracts`. O filtro público `f3base_conversoes_adaptador` recebe o destino, esse contrato e contexto `consumer_id=site-core-quality`, `purpose=crm_stage`, `action=<acao>`. O adaptador negociado precisa ter `capabilities()` e `sendBound(payload,destination_ref)`.

A capacidade precisa trazer `contract`, `purposes` incluindo `crm_stage`, `ready` e `actions[action]` com `action`, `purpose=crm_stage`, `ready` e `destination_ref` não vazio. Para Google, `acquisition_action` é obrigatório: recurso da ação de contato ou `null` comprovado; ausência, formato inválido, divergência da capacidade legada ou reutilização da ação bloqueiam. A especificação detalhada e exemplos estão em QUALIDADE-DESTINOS-1.58.md. Para dados de usuário Google, a entrada da ação anuncia `enhanced_leads` nas mesmas condições verificáveis do 1.1.0. Ausência de capacidade retorna `adaptador_etapas_nao_suportado`; ação não anunciada ou não pronta tem motivo próprio. Não há fallback para a conversão de contato.

O payload identifica `contract`, `purpose`, `record_id`, `stage_id`, `action`, `event_id` e `occurred_at`. A identidade estável depende do site, contato, destino e etapa. Retornar à mesma etapa não cria outro envio por adivinhação. São conservados clique/identificadores elegíveis de cada plataforma; LinkedIn usa sua regra e tipos de identificador autorizados. O instante deve estar após a captura, não no futuro e dentro da janela de sete dias. Tráfego de teste, exclusão, origem inadequada e ausência/revogação de consentimento bloqueiam.

A observação local e a reserva de cada destino compõem a transação do evento. A fila guarda ação, referência do destino, revisão da configuração e recibo, sem payload pessoal persistido. Antes do envio, relê a elegibilidade e o binding; alteração de configuração/destino bloqueia. A reserva passa para `incerto` antes de HTTP. `entregue` exige confirmação; `recusado` exige prova de não entrega. Exceção ou resposta inconclusiva permanece incerta e não é repetida automaticamente.

`f3base/qualidade-conversoes-previa` recebe `record_id`, `etapa` e opcional `ocorreu_em`. Mostra os dois destinos, motivo e envelope privado redigido; não enfileira. `f3base/contatos-qualidade-ler` expõe `envios_comerciais` com recibos por destino. O crescimento de lista de estágios/recibos não autoriza mesclar dados pessoais com resumos públicos.

## Convivência e aceite

Google 1.1.0 deve estar instalado antes de usar 316. O restante do Core não depende de habilitar conversões otimizadas ou retorno comercial. A concessão LinkedIn com `rw_conversions` e regra API permanece responsabilidade do produtor/operador; escolher uma etapa para otimizar lance pertence ao Growth Campanhas.

Fixtures de capacidades e HTTP sintético comprovam comportamento do consumidor, não aceitação de uma conta real. O primeiro envio com userIdentifiers e a primeira etapa aceita por destino são aceites externos distintos. Respostas/encerramentos dos impactos constam do relatório principal; só mudança substantiva do contrato ou pedido gera revisão do impacto.
