# Core 1.61.1 — acervos e conferência individual de e-mail

29/10/2026. Base direta 1.61.0; contrato administrativo aditivo 8.26.0. Preserva os pedidos implementados na 1.61.0. Complementos de referência: Google 0.23.0, Meta 0.15.0, MCP 0.37.0, LinkedIn 0.13.0 e Pipedrive 0.4.0. O Core continua autônomo em suas funções próprias.

| Pedido | Entrega |
| --- | --- |
| 337 | Acervo Google concedido: igualdade exata de GCLID, gravação em sessão e contato, campanha/grupo/palavra-chave/correspondência/rede/dispositivo e proveniência. Campo indisponível permanece nulo. Leituras pessoais e revogação verificadas. |
| 340 | Sete datasets Google no SDK local; desempenho ao lado da Meta em campanhas, moeda/cobertura/revisão, contatos e parceiros por IDs. Leitura de alterações Google/Meta por conta, dia, entidade e campo; autoria restrita. |
| 341 | Contagens browser/servidor e snapshots EMQ datados no relatório Meta e prontidão. Aviso com intenção durável quando zero otimizado é comprovado e há emissão local exata ou gasto positivo. |
| 342 | Acervo independente consulta × página × dia; retomada, publicação atômica, revisitas e lacunas. Histórico e relatório editorial recebem seleção de escopo e filtros. |
| 343(c) | Message-ID individual congelado antes do SMTP; reconciliação paginada de pessoa e thread vinculada ao lead. Confirmação nunca usa contador agregado ou apenas assunto. |

Guia completo: ACERVOS-E-EMAIL-1.61.1.md. Configuração, schemas e inventário são gerados do código desta versão. A opção `f3base_google_ads_acervo` é nova: a opção existente `f3base_google_ads` continua pertencendo à conversão/tag e é preservada.

Instalação e atualização usam o ciclo nativo. Acrescenta três tabelas GSC e colunas opcionais de enriquecimento, pixel e conferência. Não reescreve históricos nem inventa dados anteriores. Não liga coleta ou concessões dos complementos. Conferência de mensagens novas usa a política fotografada; mensagens antigas sem Message-ID ficam não conferidas.

Provas locais e no Site-Teste estão no relatório externo. Aceites com contas e próximos leads reais de ctooffice.com.br/korvena.com.br pertencem à homologação de produção autorizada pelo dono; nenhum resultado sintético substitui essa conferência. Não executar CRM real no Site-Teste. Consultas anônimas GSC e dias Meta fora da cobertura não podem ser reconstruídos por esta versão.
