# Agentes — Core 1.57.1

Leia DOCUMENTACAO.md e RELEASE-1.57.1.md. Base direta canônica 1.57.0; contrato 8.22.1. Preserve os nomes públicos e a separação Google/Meta/Core. O candidato paralelo com o mesmo número não é instalador suportado.

Descubra f3base/documentacao-ler, consulte sem parâmetros e leia cada arquivo até proxima_linha:null, verificando SHA-256 e versão. A ajuda estática não faz chamada de fornecedor ou reparo. Configuração e dados privados exigem administrador; schema instalado é a referência.

Instagram: use leads-eliminar-registro com simular:false, record_id e revisao_esperada atuais. Transação externa é recusada antes da eliminação. Após falha parcial, retome a mesma operação; não apague pedido/alvo/chave ou invente recibo. dados_eliminados não prova exclusão Meta: confira pendente e copias_externas. Ausência de alvo legado continua explícita.

GA4: confira ga4-status antes de configurar. Credenciais e concessão ficam no Google; não os copie para Core. Coleta começa desativada. Uma chamada processa uma página; respeite proxima_tentativa e quota. Inicio vazio mantém âncora durável; dia explícito não ultrapassa retenção finita. Sem credenciais, use somente leitura local/simulação.

Continue consultas com pagina e revisao; em comparações, passe revisao_anterior separadamente. Para qualidade extensa use pagina_qualidade e percorra proxima_pagina_qualidade; o histórico também permite selecionar coleta. Não some usuários entre dias, recortes ou fontes. Exportação autenticada inclui bytes e SHA-256. Leitura da qualidade não altera a publicação.

Antes de restore, siga a recuperação Core; cursores em andamento são invalidados. Não resete estado/cota em um site real para contornar espera. Retenção 0 não expira; prazo positivo é escolha explícita e não recupera dados expurgados. Troca de arquivos não desfaz efeitos de eliminação. Consulte o relatório da rodada para provas e pendências reais.
