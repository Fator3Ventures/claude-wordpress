# Agentes — Core 1.58.0

Leia DOCUMENTACAO.md e RELEASE-1.58.0.md. Base direta canônica 1.57.1; contrato administrativo 8.23.0. A árvore `docs/dados/abilities-*.json` descreve os argumentos exatos. Descubra `f3base/documentacao-ler`, percorra o índice e todas as páginas até `proxima_linha:null`, conferindo hash e versão. Conteúdo estático não certifica fornecedor ou execução de cron.

Comece por `f3base/resumo-operacional-ler`. Use as rotas de detalhe indicadas para campos omitidos ou desconhecidos. `f3base/midia-prontidao-ler` combina provas locais; estado pronto não autoriza criar anúncios, conceder acesso ou enviar testes comerciais. Não usar `meta/status` como substituto de `meta/health` em leitura, pois algumas operações de estado podem agendar manutenção.

Configuração: ler revisão, simular e aplicar a mesma intenção. `operacoes` usa JSON Pointer e valida a option inteira; não combinar com `valor`, `mesclar`, segredos ou redirects. Hash por subchave é comparação canônica, não autorização de escrita. Depois de `persisted:true`, examine `effect`, `audit` e `verification` antes de nova gravação. Não gravar diretamente no banco para contornar recusa.

Google 316: negociar o contrato 1.1.0 e manter `destination_ref`; consentimento, conta/ação e prova vigente precedem identificadores pessoais. Prévia mostra hashes e motivos sem envio. Google/LinkedIn 323 continuam bloqueados enquanto não anunciarem a capacidade `crm_stage` proposta no 1.2.0; não adaptar por acesso privado nem trocar a ação de contato.

Meta 20(e): configure o consumidor Core e obtenha concessão explícita no Meta. Continue somente a mesma seleção/revisão; `history_changed` ou `revision_conflict` exige reiniciar o conjunto. Não somar níveis, moedas, alcance/frequência ou tipos de ações sobrepostos. Campo ausente e último valor anterior são fatos distintos. Leia META-ADS-CORE-1.58.md.

Teste 322 é sob demanda: simular, aplicar com revisão/chave, consultar recibo até terminar e conferir cada limpeza. Uma repetição da chave consulta a mesma intenção. Incerto não é permissão para repetir; preservar autoria e IDs. Pipedrive real apenas ctooffice.com.br e korvena.com.br, mediante a autorização aplicável. Sem contrato seguro de exclusão de e-mail/webhook, o salto bloqueia antes do envio. Não declarar aceite ponta a ponta quando houver bloqueios ou resíduos. Para reautorizar apenas limpeza, simule `f3base/caminho-lead-limpar` e aplique com revisão/chave; isso não retoma captura/envios nem repete efeitos incertos. Não criar canário diário.

Identidade 319 e vínculo 318 não substituem consentimento nem fundem registros. Supressão por destino é optativa. Busca incompleta não significa que não existe contato anterior. No relatório 320, ausência de observação não comprova ausência de atendimento; usuários humanos do CRM são declarados e não incluem a integração.

Após upload, observe a confirmação do executor e os recibos do 326 antes de disparar verificadores manualmente. O MCP 0.34 permite upload com chave idempotente/digest e sonda `served`; preservar pré-imagem. Sonda interna não prova todos os caches externos. Leituras não reparam filas.

SMTP 327: habilitar somente com caixa/credencial e prova SMTP vigentes. Limite de cota pode aceitar a mensagem localmente para envio posterior. Não reenviar manualmente estado incerto. Ceder a outro plugin SMTP é um estado explícito, não comprovação de DMARC. Avisos técnicos 329 usam destino próprio, sem o canal de avisos de contato.

Antes de restore siga recuperação Core. Preserve salts, diretório privado, tombstones e recibos. Não resete fila/quota para contornar espera. Atualização de produção, publicação e aceites de conta real dependem do responsável autorizado; não decorrem da instalação no Site-Teste.
