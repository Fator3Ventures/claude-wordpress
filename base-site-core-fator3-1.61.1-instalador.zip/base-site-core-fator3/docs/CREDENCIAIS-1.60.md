# Credenciais — 1.60

Regra do dono de 28/10/2026, pedido 334; prevalece sobre restrições de formato descritas em CREDENCIAIS-1.51.md e guias anteriores.

Prefixo, tamanho usual, alfabeto, espaços internos, aparência de URL/cabeçalho ou de outro segredo são avisos, com regra e motivo. Inclui Pipedrive diferente de 40 hex, Slack sem xoxb, Meta sem EAA/32 hex, LinkedIn fora do alfabeto usual, Clarity não JWT e chave HMAC de webhook fora de 32–256. Nenhum desses padrões decide a validade. SMTP e segredos sem verificação remota gravam valores seguros com aviso aplicável. Webhook URLs continuam validadas como URLs.

Candidatas Pipedrive, Slack, Meta e LinkedIn usam suas verificações existentes; Clarity chama exportação de um dia com a candidata, antes de gravar, usando trava e cota manual de exportação. Recusa, indisponibilidade ou cota esgotada preserva o salvo. Resposta 200 Clarity precisa de JSON válido em lista; não se publica esse resultado como coleta. O projeto na identidade Clarity é a seleção do operador, não confirmação de identidade devolvida pelo fornecedor. Duas tentativas manuais/retentativas compartilham o orçamento diário existente. Requisições idênticas na mesma execução reutilizam a verificação.

Recusa local: não texto, mais de 8192 bytes ou qualquer controle ASCII, inclusive na borda, antes de normalizar; valor composto só por espaços não vira remoção. Espaços ASCII nas extremidades são aparados com aviso. Não há bypass desses limites ao verificar segredo salvo. Mantém-se a remoção explícita por apagar no painel ou valor vazio no contrato de configuração; campo vazio sem apagar no formulário mantém o atual.

f3base/credenciais-verificar devolve avisos e resultado remoto, sem salvar candidata. f3base/config-core-escrever inclui avisos tanto na simulação quanto no resultado aplicado/recusado. Verificação prévia de formulário exibe regra/motivo junto ao campo. Avisos de credencial aceita são metadados vinculados à revisão e reaparecem junto do campo. Segredo nunca é retornado. Confirmação de troca de identidade, comparação de revisão e cifra continuam obrigatórias.
