# Core 1.61.0 — contexto de sessão, regras e recebimento de e-mails

29/10/2026. Contrato administrativo 8.25.0. Instalação limpa ou atualização direta da base canônica 1.60.0. Esta nota prevalece sobre limites anteriores nos pontos abaixo. Conjunto inicial examinado: MCP 0.37.0, Google 0.22.0, Meta 0.14.0, LinkedIn 0.13.0 e Pipedrive 0.4.0. Durante a homologação, Google 0.23.0 e Meta 0.15.0 chegaram ao Site-Teste; a convivência com eles foi reconferida. O Core não exige esses pacotes para suas funções próprias.

| Pedido | Comportamento desta versão |
| --- | --- |
| 335 | Conversões 1.1 aceitam `ambos`; erro conserva contrato solicitado, distingue `invalid_output` de `unreadable`. Prontidão informa `leitura_falhou`, nunca destino incompleto por erro de leitura. |
| 336 | IP, fonte e agente capturados no pedido de medição, cifrados uma vez por sessão. Visitante, IP e agente nas leituras administrativas autorizadas; filtros por IP e visitante. Histórico não é preenchido artificialmente. |
| 338 | Presença de cinco parâmetros pagos nos GET de página dos logs. Sem query ou valores. Contagem por dia/caminho/classe, ao lado de sessões pagas observadas. |
| 339 | App declarado por X-Requested-With/marca de UA; rede por faixa com fonte/versão. Catálogo revisável e simulação. Sem faixa confiável, `desconhecida`; não significa automação. |
| 343(a,b), parcial | Recibo congelado de alternativas enum/set e fonte do Parceiro; atividades principal e de e-mail. Texto livre permanece em hash. E-mail mostra SMTP e `nao_conferido` no histórico: conferência individual ainda pendente no Core. |
| 344 | Demanda lê opções valor/rótulo do catálogo nativo fotografado, inclusive CUSTOM; só respostas fechadas. Campos livres e respostas fora do catálogo não viram dimensões. |
| 345 | Mensagens acima de 2 MiB usam cabeçalho, estrutura e início do texto por FETCH parcial. Não baixam anexos. Cabeçalho excessivo gera recibo cifrado, alerta Slack/e-mail técnico e movimento; saúde conta mensagens grandes. |
| 346 | Regras orgânicas ordenadas, catálogo IA extensível, simulação e prova revisionada por contato. Identificadores pagos precedem regras; `mapa_canais` aceita chaves novas. |
| 347 | Metadados e revisão opaca em `itens`, com alias legado `credenciais`. Nenhum segredo nessa projeção; candidato não substitui salvo na mera verificação. |

## Sessões e logs

Veja SESSOES-1.61.md. Retenção segue a janela bruta configurada do Core, até 120 meses; não se adotou a proposta de 90 dias. `f3base_ler_leads` é exigida para dados pessoais e filtros por IP/visitante. Conflito de identidade impede projetar esses campos. A reconstrução do índice conserva o primeiro contexto capturado. Eliminação/esquecimento e retenção eliminam o contexto junto da sessão. Desinstalação conserva a política anterior de remoção da medição; backup requer banco e salts.

O parser de logs passa a revisão 8. Fontes ainda disponíveis são reprocessadas sem somar duas vezes. Linhas antigas sem presença coletada usam -1 internamente e valores nulos na leitura, com cobertura explícita. Os GET não equivalem a cliques faturados. As sessões pagas repetidas entre classes de um mesmo caminho/dia não são somáveis. Filtro padrão de acessos exclui status >=400; `incluir_erros` conserva sua semântica.

## E-mails grandes

Teto de mensagem completa preservado: 2.097.152 bytes. Cabeçalho até 256 KiB; amostra da parte textual até 64 KiB; texto persistido até 20.000 caracteres; estrutura limitada em profundidade/quantidade. Tamanhos de anexos são **octetos codificados de transferência de BODYSTRUCTURE**, não o tamanho binário decodificado. Nome e tamanho são preservados, conteúdo não.

Cabeçalhos completos conservam a classificação de destinatário, auto-resposta, lista, remetente e autenticação. Corpo parcial não produz falso resultado DKIM: aceita Authentication-Results do servidor explicitamente confiado ou SPF alinhado; prova insuficiente resulta suspeito para revisão. DMARC fail comprovado por servidor confiado conserva a política de descarte. Cabeçalho que não cabe não cria contato automaticamente. Alertas registram intenção antes do transporte e não repetem resultado incerto; configuração ausente/recusa ficam no recibo para revisão. A mensagem é movida somente depois de recibo durável. Mensagens descartadas em versões anteriores exigem reprocessamento administrativo por UID, sem importação retroativa automática.

## Dependências e pendências

337, 340, 341 e 342 não foram implementados nesta versão. Os contratos ausentes na base Google 0.22.0/Meta 0.14.0 passaram a existir no Google 0.23.0 (`google-ads-reader/1.0.0`, `search-console-reader/1.1.0`) e no Meta 0.15.0 (`meta-ads-monitoring/1.0.0`), recebidos durante a homologação. A pendência agora é a integração funcional no Core, não a publicação pelos produtores. Os impactos iniciais preservados no fonte são históricos. Não se acessam opções privadas nem se usa a cota administrativa como substituto. Recebimento Meta desconhecido não é zero.

343(c) permanece pendente: a versão não consulta automaticamente o Pipedrive para provar a presença de cada e-mail. `smtp_aceito_em` prova somente aceitação SMTP; `historico.estado=nao_conferido` e `conferido_em=null` são explícitos. Não infere confirmação pelo contador de mensagens nem assunto. Recibos históricos sem fotografia não ganham rótulos reconstruídos pela configuração atual.

Aceites comerciais na frota, teste real de caixa e inspeção visual são distintos das provas com fornecedores simulados. Pipedrive real só em ctooffice.com.br/korvena.com.br, conforme ordem do dono. Não executar CRM real no Site-Teste.

Correção de regressão 332: a leitura do instante no recibo de renovação usa apenas os dez dígitos de segundos. O nonce hexadecimal não é convertido como fração ou notação científica; o HMAC completo continua obrigatório.
