# Reconciliação comercial — Core 1.59.0

Pedido Core 323 e retorno Google 0.22.0, revisão 2. Este guia descreve a consulta de um evento comercial já admitido. O contrato administrativo Core permanece 8.23.0; não há nova tabela, option ou ability para essa consulta. O agendamento existente do worker comercial é reutilizado.

## Estados e identidade

| Situação | Conduta do Core |
| --- | --- |
| Pendente e elegível | Reserva o recibo como incerto antes de `sendBound`, preservando ação, configuração e referência. |
| Google aceitou ingestão | Mantém incerto até prova conclusiva do produtor. Um requestId não prova entrega. |
| Incerto Google com extensão e vínculo vigentes | Consulta `reconcileBound(event_id,destination_ref)`; não reenfileira nem envia outro evento. |
| Resultado `entregue` | Atualiza o mesmo recibo mediante confirmação do produtor para o evento/destino exatos. |
| Resultado `recusado` | Só é terminal com `non_delivery_proven` estritamente `true`. |
| Exceção, resposta inconclusiva ou recusa sem prova | Conserva incerto e motivo sanitizado. |
| LinkedIn incerto ou produtor sem extensão | Conserva o recibo; não tenta o método Google nem repete envio. |

O event_id conserva o formato `f3q-<SHA-256>` e a identidade já usada pelo Core, baseada em site, contato, destino e etapa. O worker não cria novo ID, não remonta e-mail/telefone/clique e não lê opções privadas do produtor. A ação e a referência vêm da reserva existente. O contrato Google define o envio comercial com valor fixo 0/BRL; reconciliação não atualiza o valor financeiro nem a escolha de otimização da campanha.

## Negociação e guardas

A seleção normal usa `site-conversion-delivery/1.2.0`, consumidor `site-core-quality`, finalidade `crm_stage` e ação exata. Para consultar, capabilities deve anunciar exatamente `async_reconciliation:"site-stage-conversion-reconcile/1.0.0"`, e o mesmo objeto deve oferecer `reconcileBound`. A presença de método sem anúncio, ou de anúncio sem método, não basta.

Qualidade comercial e destino precisam continuar ativos; a etapa deve existir. Configuração/revisão, mapa da etapa e referência têm de corresponder à reserva. A razão global e a razão da ação admitem somente `ok` ou `stage_verification_required` nessa consulta: uma prova de envio expirada pode ser consultada, mas revogação ou troca de identidade não recebe essa exceção. Com prontidão falsa, a exceção exige que ambos os motivos sejam `stage_verification_required`; motivos mistos não comprovam essa exceção. As demais proteções do contrato, incluindo separação da ação de aquisição, continuam vigentes.

A configuração Core é relida imediatamente antes e depois da consulta. A trava renovável serializa o worker e a reserva durável do horário usa comparação do estado e timestamp anteriores. O commit final exige o timestamp reservado. Mudança concorrente, perda de trava ou ausência de persistência comprovada não autoriza nova ingestão. O recibo do produtor pode ter avançado enquanto o Core permanece incerto; uma futura consulta autorizada é a forma de reconciliar essa diferença.

## Frequência e resultado operacional

Cada passagem seleciona até dois incertos Google cujo `atualizado_em` tenha pelo menos 1800 segundos. Esse campo continua sendo a data real da última atualização; não guarda prazo futuro. O intervalo é reservado antes de selecionar/consultar, inclusive quando a operação termina em bloqueio ou exceção. O worker exige orçamento de tempo e renova a trava antes do trabalho.

O Google aplica adicionalmente seu cooldown/backoff; o contrato recebido prevê esperas que podem chegar a 21600 segundos. Chamadas Core durante essa janela não obrigam nova consulta HTTP no produtor. A frequência do executor e a existência de trabalho elegível também afetam quando haverá consulta; 1800 segundos não são um SLA de confirmação.

O resultado `reconciliados` conta invocações de consulta ao adaptador, inclusive respostas ainda incertas. Não é número de confirmações nem recibo de atribuição no Google Ads. A leitura por contato em `f3base/contatos-qualidade-ler` expõe `envios_comerciais` com estado, código, ação, referência e instantes. Consultar esse relatório não dispara reconciliação.

## Diagnóstico e limites dos produtores

`google/stage-conversion-status` descreve capacidades locais; `google/configure-stage-conversion` concede/revoga; `google/verify-stage-conversion` valida conta/ação; `google/reconcile-stage-conversion` consulta o recibo do produtor. Essas operações são administradas pelo plugin Google e têm seus próprios schemas, permissões e efeitos. O comando de reconciliação Google não escreve a tabela Core.

LinkedIn 0.12 fornece o envio comercial por ação, mas não anuncia a extensão assíncrona Google. O recibo local e a entrega são distintos da auditoria central. Com MCP 0.34, `site-core-quality` pode produzir `central_audit=service_record_unconfirmed`; o mantenedor LinkedIn já encaminhou essa limitação ao MCP. Não substituir o consumidor por `site-core-conversions` e não reenviar eventos para preencher o Registro.

## Recuperação e aceite

Desativar a qualidade/destino interrompe as consultas elegíveis; restaurar somente as condições originais pode permitir consulta posterior. Revogar e reconceder pode gerar outra referência: não vincular silenciosamente um recibo antigo à nova concessão. Preserve banco, salts e diários antes de restore. Reverter arquivos para 1.58.0 interrompe a consulta automática, sem apagar os estados já confirmados.

Provas locais usam produtores originais e transportes sintéticos, com contagens identificadas no relatório da entrega. O aceite externo exige conta/ação autorizadas, evento real elegível, mesmo recibo passando de incerto a confirmado e zero novas ingestões. HTTP aceito ou fixture aprovada não comprova atribuição, otimização ou resultado de campanha.
