# Validação — Core 1.60.0

O relatório externo da entrega e evidence/1600 no fonte identificam cada execução, seu ambiente e a identidade do instalador. Artefatos históricos não contam como provas desta versão.

- Pedido 330: SDK original Meta 0.14, concessão por revisão de acesso, parceiro padrão e precedência da campanha; transporte Graph sintético.
- Pedidos 331–334: marcas no HTML, endpoint nativo de análise com token vencido, recibo de renovação, isolamento de robôs, host/cookie HTTP e conferência de candidatos com HTTP controlado.
- Pedido 322: worker completo de captura, CRM, Slack, aviso e automático, entrega IMAP e exclusão de UIDs autorais; transportes simulados e caixa alheia preservada. Não prova entregabilidade real.
- JavaScript fonte e minificado: renovação após 403 e manutenção das identidades de eventos; regressão dos formulários com HTML nativo e jsdom.
- Instalação limpa, atualização da base canônica 1.59.0, repetição de migração, desinstalação e reativação: Plugin_Upgrader e processos PHP separados, preservação das tabelas preenchidas.
- Documentação integral pela ability, schemas, hashes, índice e permissões; pacote exato verificado no Site-Teste.

O relatório final distingue testes concluídos de aceites reais ainda necessários. Contas Meta de korvena.com.br e caminho completo com Pipedrive de ctooffice.com.br pertencem aos aceites da frota; esta entrega não autoriza publicação nos demais sites. O webhook de aviso permanece bloqueado no teste 322 por não haver contrato de exclusão individual.
