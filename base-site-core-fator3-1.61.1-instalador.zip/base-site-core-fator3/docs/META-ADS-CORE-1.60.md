# Meta Ads — 1.60

Atualiza META-ADS-CORE-1.58.md para o pedido 330; contrato local meta-ads-reader/1.0.0, provedor Meta 0.14.0. Não há HTTP Graph na leitura Core.

f3base_meta_ads aceita parceiro_padrao = {parceiro_id, rotulo}, ambos preenchidos ou ambos vazios. A campanha em parceiros tem precedência. relacao_core.parceiro.fonte é mapa_explicito_core ou mapa_conta_core. Sem ambos continua sem_mapa_explicito, sem atribuição inferida por nome.

revisao continua monotônica para edições administrativas. revisao_acesso é controlada pelo Core: preservar o valor lido na escrita; omissão de clientes antigos é admitida e o Core recompõe a geração atual. Somente mudanças em ativo, conexao ou conta_id incrementam a geração, no mesmo CAS da opção. Isso impede reativação de concessão antiga ao voltar à seleção anterior. Alterações de mapa e padrão mantêm a revisão do consumidor; não concedem acesso novo.

A revisão é SHA-256 da seleção e geração, não do mapa. Na implantação desde 1.59 o formato muda: ler f3base/meta-ads-status, renovar concessão no Meta pela API pública com revisão esperada e confirmar pronto. Não fazer isso no instalador. Cursores de relatório incluem a revisão integral da opção e serão reiniciados após edição do mapa; revisao_mapa identifica essa fotografia. A releitura final impede misturar mapas durante a página. Cobertura, moedas, fusos, contatos e exclusões mantêm os limites da 1.58.
