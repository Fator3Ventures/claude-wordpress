# Acervos Google/Meta, GSC e e-mail — Core 1.61.1

## Autorização e configuração

Leitura de conta/configuração exige `manage_options`. GCLID, contatos e autoria de alterações também exigem `f3base_ler_leads`; sem esta capacidade, alterações preservam valores operacionais e retiram autoria, inclusive metadados históricos. Configurações são acessíveis em `f3base/config-core-ler`/`escrever` com revisão esperada e simulação. Leia o schema antes de escrever; aumente `revisao` ao alterar seleções. Concessão no complemento é sempre explícita. Não conceder por versão, ler opções privadas do produtor ou usar o token de administrador como fallback.

| Opção | Finalidade / padrão |
| --- | --- |
| `f3base_google_ads_acervo` | `ativo=false`, conexão/conta vazias, revisão 0, mapa campanha→parceiro e parceiro padrão vazio. Conta Google tem dez dígitos. |
| `f3base_meta_monitoramento` | Desligado; conexão, conta, relatórios `ads_activity`/`dataset_quality`, até 12 datasets explícitos; avisos desligados, canal Slack. Operador é registrado pelo Core ao salvar. |
| `f3base_gsc_consultas` | Coleta desligada, horário/início/revisão; usa propriedade e prova da configuração GSC existente. Concessão GSC1.1 é separada da 1.0. |
| `f3base_email_historico` | Ativo; janela 48 horas e intervalo 60 minutos, configuráveis (1–720 horas; 5–1440 minutos). Política fotografada por mensagem antes do SMTP. |

Google: `google-ads-reader/1.0.0` via hook `f3_mcp_google_register_ads_consumers`. Meta: `meta-ads-monitoring/1.0.0` via `f3_meta_register_monitoring_consumers`; o leitor de desempenho `meta-ads-reader/1.0.0` permanece independente. GSC: `search-console-reader/1.1.0`, capacidade `gsc.query-page-day.read`. A mudança de seleção/revisão invalida a concessão; restaurar valores anteriores não reautoriza. Valores de configuração vazios são preservados.

## Google Ads e contatos

`f3base/google-ads-acervo-status` diagnostica; `google-ads-acervo-ler` recebe `de`, `ate`, `dataset`, `limite`, `cursor` e, apenas em `clicks`, `gclid`. Datasets: clicks, customer, campaign, ad_group, ad, search_terms e changes. Uma página por dia, até 1000 linhas; a continuação avança páginas e dias. Período máximo 366 dias; sem HTTP de fornecedor na leitura. Recomeçar com cursor vazio após alteração de seleção, concessão, acervo ou conjunto de contatos. A revisão é diária; o Core não declara fotografia global simultânea de todo o período.

Custos permanecem `cost_micros` textuais, cliques/impressões e conversões na precisão fornecida; moeda, fuso, cobertura, extração e revisão são explícitos. Não somar revisões do mesmo recorte, moedas distintas ou métricas sobrepostas. Ausência de linha não é zero. O mapa de parceiro usa IDs de campanha e precedência explícita sobre o parceiro da conta. Contatos aceitos reais são associados à conta/campanha/grupo/anúncio por IDs, no dia da captura no fuso da conta; teto 10 mil contatos no recorte pede reduzir período. Não é equivalência à janela de atribuição do fornecedor. Termos agregados não identificam pessoas.

`relatorios-integrados-ler` com `visao=campanhas` acrescenta `google_ads`/`meta_ads`, com continuações independentes `google_ads_cursor` e `meta_ads_cursor`; `google_ads_dataset` seleciona o nível Google. O período é compartilhado; outros filtros do Core não são aplicados às linhas dos fornecedores (lista explícita `filtros_acervos`). A tela apresenta os acervos separadamente e conserva as medidas Core.

O job `google_cliques` processa até dez sessões e dez contatos por passagem de 12 segundos, uma página local por registro. A janela de busca é a data UTC de entrada/captura e os dias adjacentes para cobrir fusos; não afirma localizar GCLIDs reutilizados de visitas antigas fora dela. Grava checkpoint, origem/hash, conta/revisão, cobertura por dia e fonte. Só um clique exato permite `encontrado`; múltiplos viram `gclid_ambiguo`. Sem acervo, concessão ou linha, o motivo fica explícito. O SDK não fornece termo individual de busca: `search_term=null` permanece nulo. Hora agendada depende de WP-Cron; cron do servidor pode executar vencidos.

Sessões/editorial, `sessao-detalhar` e `leads-registros-ler` projetam `google_ads`. Origem editada, identidade conflitante, configuração alterada ou concessão revogada impede exibir observação antiga. A retenção segue sessão/contato; eliminação remove o enriquecimento. Não envia GCLID, pessoa ou contato ao produtor em uma leitura local.

## Alterações e qualidade Meta

`f3base/anuncios-alteracoes-ler`: plataforma `google_ads` ou `meta_ads`, `de`, `ate`, conta opcional (deve corresponder à seleção), `entidade`, `campo`, limite e cursor. Valores antigos/novos só aparecem quando fornecidos. Autor exige leitura de dados pessoais. Entidade Google é o resource name; Meta é object_id. Campo Google corresponde aos changed_fields; Meta aos detalhes estruturados/event_type. Páginas vazias após filtro podem ter continuação.

`f3base/meta-monitoramento-ler`: report, de/ate e dataset_id para qualidade. Mantém revisões, cobertura e snapshots anteriores datados. `meta-entregas-ler` e `midia-prontidao-ler` acrescentam `recebido_meta`; cada dataset contém contagens e EMQ observada separadamente. Browser e servidor podem conter o mesmo evento, portanto não se somam como recebidos únicos. EMQ atual não é nota histórica do dia das contagens. Continuar leitura pelo cursor indicado, inclusive quando o primeiro recorte não contém todas as linhas.

O alerta requer incidente recente do `meta/health`, concessão vigente, operador ainda autorizado, zero explícito browser/servidor com cobertura e conjunto otimizando o evento. Exige ainda emissão observada no pixel/evento/dia exatos ou gasto positivo autorizado. Erro/ausência não significa zero. Examina no máximo 31 páginas locais (3100 linhas) por prova; o limite deixa a prova desconhecida, sem inventar confirmação. Não atribui atividade a pixel legado ausente. A observação do navegador registra o pixel direto configurado; um destino CAPI diferente não substitui essa identidade. Pixel desconhecido em GTM permanece sem prova local por pixel.

`avisar=true` habilita o canal configurado, Slack do site ou e-mail técnico. Intenção durável é reservada antes do transporte e deduplicada por incidente; resultado incerto não é repetido automaticamente. Cron executa sob o operador salvo, restaurando identidade anterior. Os recibos ficam em `f3base_meta_monitoramento_estado`; revisar canal/incidente após falha, sem apagar recibos para forçar repetição. HTTP na leitura é proibido; envio ocorre somente no job autorizado.

## Search Console: consultas

No relatório editorial `visao=gsc`, selecionar `gsc_escopo=consultas`, propriedade, datas, `pagina_url` e `consulta` exatas. `post_id`/tipo podem limitar conteúdo local. Paginação de 200 linhas no máximo; até 90 dias por leitura conforme a janela do relatório. A coleta conserva o histórico sem expiração, em `f3base_gsc_consultas_coletas`, `linhas` e `lacunas`. Não soma este acervo aos totais por página.

`gsc-historico` e `gsc-lacunas-ler` aceitam `escopo=consultas`; os nomes `gsc-consultas-status`, `gsc-consultas-historico`, `gsc-consultas-lacunas-ler` e `gsc-consultas-coletar` também são públicos. Consulte o schema exato e use o executor normal. Coleta mantém cursor, concessão, revisão, limite, recibos e retomada. Página curta não fecha o dia; publicação só após conclusão explícita, em transação. Revisita incompleta preserva a publicação anterior. Revisita completa substitui o recorte publicado, sem duplicar métricas.

Dias são de Los Angeles; consultas anônimas excluídas pela API são indicadas em `consultas_anonimas` com valores nulos e motivo, nunca zero ou diferença inventada. `all_rows_guaranteed=false` permanece explícito. Cobertura/lacunas são próprias deste universo e não alteram GSC páginas/GA4.

## Conferência de e-mail no Pipedrive

Antes do SMTP, o Core congela Message-ID, remetente, destinatário e política no payload cifrado da mensagem. Aceite SMTP continua separado da prova no histórico. O job `email_historico` verifica até três mensagens por passagem, inclusive linhas cujo envio/atividade já terminou. A agenda verifica vencidos a cada cinco minutos; cada mensagem respeita seu intervalo. Respeita orçamento `qualidade`, conta/credencial verificada, recuperação, cancelamento e eliminação.

Usa apenas GET `/v1/persons/{id}/mailMessages` com `include_body=0`, páginas de 100, e GET `/v1/mailbox/mailThreads/{id}`. Compara `mua_message_id`, remetente, destinatário, linked_person_id e lead_id da thread, recusando rascunho/excluído. Não baixa corpos, não reenvia e não conclui pelo contador de mensagens. O Mailbox precisa estar visível ao token da conta. Referência de contrato: https://developers.pipedrive.com/docs/api/v1/Persons#getPersonMailMessages e https://developers.pipedrive.com/docs/api/v1/Mailbox#getMailThread .

| Estado | Significado |
| --- | --- |
| `confirmado` | Mensagem individual e vínculo à pessoa/lead comprovados; `conferido_em` informa o instante. |
| `nao_confirmado_no_prazo` | Busca completa autorizada depois do prazo não encontrou a mensagem. |
| `nao_conferido` | Ainda aguardando, legado sem Message-ID, resposta inválida, acesso recusado ou paginação incompleta no fim do prazo; motivo e tentativa disponíveis. |

`leads-registros-ler` inclui esse resultado em `crm.pipedrive.recibo.emails[].historico`. Prova persistida contém IDs técnicos/hash e datas; não o corpo nem endereços. Política congelada não é reescrita após envio. Mudança de conta não reconcilia mensagens da conta antiga. Eliminação cancela e limpa mensagem/prova. Erro no fim da janela continua desconhecido, nunca vira falso negativo. A prova descreve o instante conferido; uma exclusão posterior no CRM não retroage automaticamente nesse recibo.

## Instalação e reversão

Atualizar diretamente da 1.61.0; novos grupos desligados, exceto conferência de mensagens novas. Nada concede acesso automaticamente. Migração usa dbDelta e prontidão confere tabelas/colunas. Backup inclui banco, salts e guarda operacional. Para voltar à 1.61.0, pausar novos jobs e conferir efeitos externos; colunas/tabelas aditivas podem permanecer, mas a base não as interpreta. Repetir SMTP ou aviso incerto para reparar histórico é proibido. Desativação remove agendas Core; desinstalação conserva acervos/recibos comerciais segundo o inventário, enquanto a medição de sessões segue sua política anterior.
