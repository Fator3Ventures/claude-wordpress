# Retorno comercial por destino — vigente no Core 1.59.0

O nome do arquivo conserva a origem na 1.58. Esta revisão considera Google 0.22 e LinkedIn 0.12; a cópia anterior permanece no histórico do fonte.

Pedido Core 323. Google Ads e LinkedIn têm configuração própria em `f3base_qualidade_destinos`, desligada por padrão. Cada etapa local usa uma ação exclusiva em cada destino. Configurar uma ação não concede acesso à conta nem altera uma campanha. O destino Meta conserva seu contrato anterior e a opção independente de valor do Pedido 315.

## Situação dos acompanhantes

Google 0.22.0 entrega `site-conversion-delivery/1.2.0` para etapas, preservando aquisição 1.0/1.1. LinkedIn 0.12.0 entrega 1.2.0 e conserva aquisição 1.0. As ações comerciais exigem concessões próprias: instalação e número de versão não provam prontidão. O Core usa o anúncio efetivo da capacidade e a referência da ação; um produtor anterior ou incompleto continua bloqueado com `adaptador_etapas_nao_suportado`.

Google acrescenta `site-stage-conversion-reconcile/1.0.0` para confirmar assincronamente o mesmo evento. O Core 1.59 incorpora sua consulta no worker, conforme RECONCILIACAO-COMERCIAL-1.59.md. LinkedIn não anuncia essa extensão; incerteza nesse destino não recebe reenvio automático. Homologação de contas reais e auditoria central comercial permanecem separadas da implementação do contrato.

## Contrato opcional `site-conversion-delivery/1.2.0`

Descoberta pelo filtro público `f3base_conversoes_adaptador`. O adaptador de aquisição deve anunciar 1.2.0 em `supported_contracts`. A segunda seleção recebe destino `google_ads` ou `linkedin`, contrato 1.2.0 e contexto `{consumer_id:"site-core-quality",purpose:"crm_stage",action:"..."}`. O objeto retornado precisa oferecer `capabilities()` local e `sendBound(payload,destination_ref)`; capabilities não chama o fornecedor nem concede acesso.

Capabilities mínimas:

```json
{
  "contract": "site-conversion-delivery/1.2.0",
  "supported_contracts": ["site-conversion-delivery/1.2.0"],
  "purposes": ["crm_stage"],
  "ready": true,
  "acquisition_action": "customers/1234567890/conversionActions/111",
  "actions": {
    "customers/1234567890/conversionActions/222": {
      "action": "customers/1234567890/conversionActions/222",
      "purpose": "crm_stage",
      "ready": true,
      "destination_ref": "referencia-opaca-vinculada-pelo-produtor"
    }
  }
}
```

Os IDs são sintéticos. Google exige `acquisition_action` explicitamente: recurso completo da ação de contato, ou `null` quando o pacote comprova não haver ação de aquisição configurada. Omitir o campo, usar string vazia ou tipo inválido bloqueia com `acao_aquisicao_nao_comprovada`. Reutilizar a ação bloqueia com `acao_comercial_reutiliza_contato`. Quando a capacidade anterior anuncia `enhanced_leads.conversion_action`, a identidade precisa coincidir com `acquisition_action`; divergência bloqueia com `acao_aquisicao_divergente`. Não ler opções privadas do pacote para suprir ausência de contrato. LinkedIn exige ID numérico distinto da ação de contato configurada no Core.

Cada `actions[action]` precisa anunciar exatamente a ação solicitada, `purpose:"crm_stage"`, prontidão e referência própria. A referência deve vincular conta, ação, concessão, identidade e geração de autorização. `sendBound` deve revalidá-la antes do efeito; revogação ou troca de contexto impede envio, sem selecionar outra conta/ação. O Core conserva e confere essa referência e a revisão de sua própria configuração entre reserva e envio.

O payload comum contém `contract`, `purpose`, `record_id`, `stage_id`, `action`, `event_id` estável e `occurred_at` RFC3339 da etapa. Google acrescenta `click_ids`, `order_id` igual ao `event_id`, consentimento `ad_user_data`, valor 0/moeda BRL do contrato de aquisição e, se anunciado para aquela ação, `user_data`. `actions[action].enhanced_leads` deve seguir a prova 1.1.0, indicar a mesma ação comercial e anunciar prontidão vigente da conta/ação. Sem clique, exige conversão otimizada pronta e identidade normalizada disponível. O hashing e o transporte final continuam sob responsabilidade do Google.

LinkedIn acrescenta `eventId`, `conversion` como URN da ação, `conversionHappenedAt` em milissegundos e `user.userIds` com e-mail SHA-256 e/ou identificador publicitário capturado. Concessão, escopos e regra API pertencem ao produtor e devem fazer parte da prontidão/referência vinculada.

O retorno de `sendBound` usa `status:"entregue"|"recusado"|"incerto"`, `code` sanitizado e `http` opcional. `entregue` exige confirmação do fornecedor. `recusado` só é terminal comprovado com `non_delivery_proven:true`; ausência de prova, exceção ou resultado desconhecido torna o recibo `incerto`. O Core não repete automaticamente resultado incerto nem escolhe outra ação. No Google, o contrato de reconciliação anunciado permite consultar o mesmo evento e atualizar o recibo Core; não permite reenviar. Na reconciliação, a recusa só conclui o recibo com `non_delivery_proven` estritamente `true`. LinkedIn mantém a incerteza sem reenvio; seu retorno de auditoria central não muda essa regra.

## Operação e limites

A etapa precisa pertencer a contato aceito, ativo, real, com publicidade permitida na captura e atualmente. Testes, homologação, audiência excluída e entrada por e-mail não são enviados. O instante deve estar entre a captura e o presente, dentro de sete dias. A transação que registra o evento comercial também reserva o recibo por contato/etapa/destino; voltar à mesma etapa não gera outra conversão.

`f3base/qualidade-conversoes-previa` não cria fila nem envia: informa elegibilidade, motivo e forma do payload, removendo identificadores brutos e mostrando hashes/tipos. `f3base/contatos-qualidade-ler` acrescenta `envios_comerciais`, com estado e motivo por destino. Opções alteradas depois da reserva bloqueiam o trabalho pendente para evitar redirecionamento silencioso.

As tabelas e prévias locais não comprovam efeito no Google Ads ou LinkedIn. Os adaptadores compatíveis foram entregues pelos respectivos mantenedores; o aceite real continua dependendo de concessão, configuração e execução autorizada pelo operador. Com MCP 0.34, a auditoria central LinkedIn de `site-core-quality` pode permanecer `service_record_unconfirmed` mesmo quando o diário local confirma entrega. Esse limite já foi encaminhado pelo LinkedIn ao MCP e não autoriza repetir o evento.
