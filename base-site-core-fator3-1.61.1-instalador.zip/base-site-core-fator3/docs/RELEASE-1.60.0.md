# Core 1.60.0 — pedidos 322 e 330–334

Base direta imutável: 1.59.0. Contrato administrativo aditivo 8.24.0. Perfil piso-padrao-3.6 e ciclo de 17 etapas preservados. Normas 01 e 02 revisão 5 (23/10/2026). Compatibilidade considerada: MCP 0.36.0, Meta 0.14.0, Google 0.22.0, LinkedIn 0.12.0 e Pipedrive 0.3.0. Mínimos Core: WordPress 7.1.2, PHP 8.3.6 de 64 bits; Pipedrive 0.3 requer PHP 8.3.36. Identidade, opções, tabelas, dados e integrações anteriores permanecem.

A frota informou concluídos os pedidos 314–321 e 323–329 em 28/10/2026. A reconciliação comercial da 1.59, com Google 0.22 e LinkedIn 0.12, permanece. MCP 0.36 já incorpora a evolução de auditoria comercial; referências anteriores à limitação 0.34 são históricas. Não se alteram runtimes dos acompanhantes nesta entrega.

## Alterações

- 322: remove somente www inicial para a allowlist CRM ctooffice.com.br/korvena.com.br. Prova de aviso por e-mail e mensagem automática usa a caixa própria explicitamente incluída em homologacao_emails, SMTP real, recebimento IMAP e UID EXPUNGE limitado às mensagens assinadas do teste. Sem Cco/Smart Bcc. Supressão Slack aponta f3base_testes.destinos.slack e valor. Webhook genérico conserva bloqueio por falta de contrato de exclusão. Veja CAMINHO-LEAD-1.60.md.
- 330: parceiro_padrao por conta, usado só sem campanha explícita, com fonte mapa_conta_core. Hash do consumidor usa seleção e geração de acesso; parceiros não revogam acesso. Cursores continuam vinculados ao mapa completo. Troca/restauração de conta e desligamento/religamento exigem concessão nova. A primeira implantação requer reconcessão explícita pelo novo formato da revisão; nunca se migra autorização silenciosamente. Veja META-ADS-CORE-1.60.md.
- 331: superficies_permitidas opcional por marca: corpo, cabecalho, rodape, dados_estruturados. Caminho ou superfície basta; cada ocorrência informa motivo caminho, superficie ou sem_excecao. Permissão estruturada não libera menção visível.
- 332: conta token_invalido por dia e renovacao_aceita após lote persistido, com recibo HMAC de rejeição, vinculado ao primeiro evento/agente, duração de 15 minutos e consumo único. Contagens de robô declarado/automação provável são separadas, sem alterar ultima_operacional. Até 30 dias; no máximo 512 recibos de renovação simultâneos, sem armazenar token/IP. Contagens antigas sem separação são preservadas como legado e não promovidas a observação operacional.
- 333: /f3base-teste/ redireciona ao host/porta configurados em home_url antes de gravar cookie. Preserva somente a intenção sair, sem refletir Host ou endereço externo.
- 334: padrões de credenciais geram avisos com regra/motivo. Fornecedor confirma candidatas Pipedrive, Slack, Meta, LinkedIn e Clarity antes da troca; recusa mantém o salvo. Clarity usa a cota manual existente e informa que projeto é seleção administrativa. URLs mantêm suas regras. Texto até 8192 bytes sem controles; espaços de borda são aparados com aviso. String vazia permanece remoção explícita nos contratos existentes; somente espaços não remove segredo. Veja CREDENCIAIS-1.60.md.

## Atualização e limites

Sem nova tabela. revisao_acesso é campo aditivo gerado pelo Core e gravado no mesmo CAS da seleção Meta. Leituras não migram opções. Não editar a geração manualmente. Atualização/reinstalação preserva conteúdos, listas vazias, autoria, credenciais cifradas, diários e tombstones. Voltar à 1.59 pode mudar novamente o hash da concessão Meta: restaurar binários não autoriza acesso automaticamente.

Instalar não envia e-mails de teste, não habilita fornecedores e não cria concessões. Homologação real do CRM permanece exclusivamente nos dois sites autorizados. Fixtures não comprovam entrega por fornecedores reais. A evidência de testes, instalação Site-Teste e pendências de frota está no relatório externo; existência de documentação não é homologação.
