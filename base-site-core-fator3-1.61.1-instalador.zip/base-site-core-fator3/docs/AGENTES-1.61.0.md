# Operação por agentes — Core 1.61.0

Leia RELEASE-1.61.0.md, SESSOES-1.61.md e CANAIS-ORGANICOS-1.61.md. Base direta 1.60.0; contrato administrativo 8.25.0. MCP 0.37, LinkedIn 0.13 e Pipedrive 0.4 foram incorporados à matriz desta rodada; contratos preservados. Não rebaixar acompanhantes durante a instalação.

- Conversões: solicitar contrato 1.1.0 e distinguir unreadable/invalid_output. Prontidão com leitura_falhou não autoriza editar IDs.
- Credenciais: ler `itens`, obter `revisao` e enviar `revisao_esperada` na verificação. Não ler valor salvo, inventar revisão ou contornar a redação do canal. Alias legado permanece.
- Sessão: usar filtros IP/visitante apenas com f3base_ler_leads; desconhecido e contexto histórico ausente não são zero nem automação.
- E-mail grande: conferir record_id, marca acima_limite, autenticação, movimento e saúde. Incerto exige reconciliação; não repetir aviso/envio automaticamente. Não criar contato a partir de cabeçalho incompleto.
- CRM: `crm.pipedrive.recibo` consolida opções e atividades, com prova histórica. Estado de e-mail no histórico é nao_conferido nesta versão, e não foi consultado remotamente.
- Regras: simular candidatos, salvar com revisão e conferir nova captura; não regravar história ou transformar origem orgânica em paga.
- Google/Meta: 337/340/341/342 continuam pendentes de integração no Core. Os contratos já estão disponíveis no Google 0.23 e no Meta 0.15, que chegaram durante a homologação. Não acessar tabelas/opções privadas.

MCP 0.37 solicitou projeção neutra para metadados de credenciais. Proposta atendida pelo pedido 347; a prova e os limites estão no relatório desta versão, sem reemitir o impacto recebido como documento novo.

Correção de regressão 332: a leitura do instante no recibo de renovação usa apenas os dez dígitos de segundos. O nonce hexadecimal não é convertido como fração ou notação científica; o HMAC completo continua obrigatório.
