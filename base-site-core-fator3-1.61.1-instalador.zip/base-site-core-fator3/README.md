# Fator3 Site Core 1.61.0

Instalação limpa ou atualização direta da 1.60.0. Contrato administrativo 8.25.0. Leia docs/DOCUMENTACAO.md e docs/RELEASE-1.61.0.md. O instalador contém somente o Core; acompanhantes são fornecidos separadamente. Identidades, testes, pendências e hashes ficam no relatório externo.
