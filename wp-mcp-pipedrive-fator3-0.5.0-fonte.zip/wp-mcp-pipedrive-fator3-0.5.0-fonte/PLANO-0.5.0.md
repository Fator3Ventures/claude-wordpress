# Plano — Fator3 MCP Pipedrive 0.5.0

30/10/2026. Implementação de Pedidos MCP Pipedrive 10, base 0.4.0, instalador SHA-256 70100900ebd7b358e96c9778eaa359aeb454203f759136da380adcb853b383fe. Alvo previsto 0.5.0, ainda não gerado neste planejamento.

Preservar identidade, 19 operações, contrato pipedrive-api-client/1.0.0, permissões, opções, tabelas, recibos e idempotência. Sem token/HTTP/cron próprio. Atualização direta sem normalizar/regravar regras persistidas.

1. Corpo Activities v2: due_time HH:MM UTC; nota única, sem duplicar no replay. Provar create/update e falhas com fixture estrita; fornecedor real permanece distinto.
2. Auditoria: stage_change_time nulo usa add_time; item sem ambas datas não interrompe coleta, tem diagnóstico identificável. Regra opcional de nome de pessoa por tokens e vínculos organizacionais, com palavras de empresa configuráveis.
3. Nota: prefixo, formato fechado de data e autor configuráveis, fuso IANA; saída HTML escapada e marcador autenticado preservado.
4. Modelo aditivo: minutos úteis sem arredondar a período; feriados; variantes condicionais de texto e variáveis explícitas de campos; restrições cumulativas de canais; revisão/limite de espera sem entrega; encerramento no primeiro período útil seguinte; adoção opt-in de nota datada com autor e mapa de toques/etiqueta. Ausência/ambiguidade bloqueia o item, nunca inventa texto/estado.

Fronteiras examinadas: Core1.62.0 mantém cliente público e posse do transporte; MCP0.37.0 mantém autorização/decoração; Google0.24.0/Meta0.16.0 são atualizações documentais sem alteração pertinente; LinkedIn0.13.0 inventariado. Nenhuma adaptação necessária em outro pacote identificada; zero novos impactos. Normas atuais r4 lidas; diferença de r5 preservada da base limita impactos a consequências/pedidos e mantém respostas no relatório principal.

Provas previstas: lint, novas regressões adversariais, WordPress limpo, upgrade0.4→0.5 com regras e recibos preservados, mínimo WP7.1.3/PHP8.3.36, MCP e Core originais com fornecedor sintético, documentação integral, instalação própria com backup/hash no Site-Teste, limpeza somente de QA próprio. Não modificar acompanhantes compartilhados nem operar korvena nesta rodada. Aceite fornecedor definido no pedido pertence ao dono/frota.
