<?php
/** Two separate PHP workers compete for one durable preview, no supplier calls. */
$root=$argv[1]??'';$id=$argv[2]??'';
if (!is_file(dirname($root).'/marker') || trim(file_get_contents(dirname($root).'/marker'))!=='f3-pipedrive-disposable-0500-d848899a8f83'
    || !preg_match('/^[a-f0-9]{32}$/D',$id)) { exit(2); }
define('ABSPATH',$root.'/');require ABSPATH.'wp-load.php';wp_set_current_user(1);
usleep(200000);
$result=\Fator3\Pipedrive\Store::claim($id,['previa_id'=>$id,'metodo'=>'PATCH','caminho'=>'/v1/leads/00000000-0000-4000-8000-000000000001','classe'=>'registro','status'=>'em_execucao','chaves_alteradas'=>[],'saldo_depois'=>null]);
echo $result?'claimed':'not_claimed';
