<?php
final class ReleaseFixture {
 public array $data=[],$requests=[];public int $spent=0,$writes=0,$next=100;public string $fail='';public bool $pagination=true;public string $revision='fixture040';
 public function status(){return ['success'=>true,'data'=>['contract'=>'pipedrive-api-client/1.0.0','autorizado'=>true,'conta'=>['dominio'=>'fixture.pipedrive.com','conta_id'=>404,'usuario_id'=>1],'revisao'=>$this->revision,'orcamento'=>['teto'=>100000,'consumido'=>$this->spent,'reservado'=>0],'saldo_conta'=>null]];}
 public function request($m,$p,$q,$b,$ctx){$this->requests[]=[$m,$p,$q,$b,$ctx];$this->spent+=$m==='GET'?20:10;
  if($m!=='GET'&&isset($b['due_time'])&&!preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D',$b['due_time']))return ['success'=>false,'remote_dispatched'=>true,'data'=>['http_status'=>400,'body'=>['error'=>'Invalid due_time fixture']]];
  if($m!=='GET'){++$this->writes;if($this->fail==='timeout')throw new RuntimeException('private canary');if($this->fail==='edit'&&isset($b['title']))return ['success'=>false,'remote_dispatched'=>true,'data'=>['http_status'=>403,'body'=>['error'=>'PII_CANARY']]];}
  if($m==='GET'){
   if(isset($this->data[$p])&&!array_is_list($this->data[$p]))$d=$this->data[$p];
   else{$rows=$this->data[$p]??[];if(isset($q['lead_id']))$rows=array_values(array_filter($rows,fn($x)=>($x['lead_id']??'')===$q['lead_id']));$off=(int)($q['start']??$q['cursor']??0);$d=array_slice($rows,$off,2);$more=$off+2<count($rows);$a=str_starts_with($p,'/api/v2/')?['next_cursor'=>$more?(string)($off+2):null]:['pagination'=>['more_items_in_collection'=>$more,'next_start'=>$more?$off+2:null]];}
  }elseif($m==='POST'){$d=$b+['id'=>++$this->next];$this->data[$p][]=$d;$this->data[$p.'/'.$d['id']]=$d;}
  else{$d=array_replace($this->data[$p]??[],$b);if(($b['is_archived']??false)===true)$d['archive_time']=gmdate('Y-m-d\TH:i:s\Z');$this->data[$p]=$d; if(preg_match('~^(.+)/([0-9]+)$~',$p,$match)){foreach($this->data[$match[1]]??[] as $j=>$row)if((int)$row['id']===(int)$match[2])$this->data[$match[1]][$j]=$d;}}
  return ['success'=>true,'remote_dispatched'=>true,'data'=>['http_status'=>200,'body'=>['success'=>true,'data'=>$d,'additional_data'=>$this->pagination?($a??[]):[]],'saldo_conta'=>null]];
 }
}
