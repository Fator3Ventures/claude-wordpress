<?php
use Fator3\Pipedrive\{Api,Documentation};
if(!defined('F3_PIPEDRIVE_DISPOSABLE')||!str_starts_with($wpdb->prefix,'f3pipqa_0500'))throw new RuntimeException('Disposable only');
wp_set_current_user(1);$checks=[];$pages=0;
foreach(Documentation::DOCUMENTS as $id=>$file){$offset=0;$text='';$hash=null;do{$a=['documento'=>$id,'offset'=>$offset,'limite_bytes'=>2048];if($hash)$a['sha256_esperado']=$hash;$r=Api::dispatch('documentacao-ler',$a);if(!$r['success'])throw new RuntimeException('Read failed');$d=$r['data'];$text.=$d['conteudo'];$hash=$d['sha256'];$offset=$d['proximo_offset'];$pages++;}while($offset!==null);$checks[$id]=$text===file_get_contents(Fator3\Pipedrive\ROOT.'/docs/'.$file)&&hash('sha256',$text)===$hash;}
$checks['schema_version']=json_decode(file_get_contents(Fator3\Pipedrive\ROOT.'/docs/schemas.json'),true)['version']==='0.5.0';$checks['runtime_version']=Fator3\Pipedrive\VERSION==='0.5.0';
$manifest=[];$root=Fator3\Pipedrive\ROOT;foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $f)if($f->isFile())$manifest[substr($f->getPathname(),strlen($root)+1)]=hash_file('sha256',$f->getPathname());ksort($manifest);
return ['checks'=>$checks,'passed'=>count(array_filter($checks)),'failed'=>count(array_filter($checks,fn($x)=>!$x)),'pages'=>$pages,'runtime_sha256'=>$manifest,'supplier_http'=>0];
