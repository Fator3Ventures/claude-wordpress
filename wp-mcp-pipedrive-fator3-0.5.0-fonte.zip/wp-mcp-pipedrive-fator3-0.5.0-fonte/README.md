# Fonte — Fator3 MCP Pipedrive 0.5.0

Base direta0.4.0; Pedido10. Instalar somente o ZIP instalador, não este fonte.

`plugin/wp-mcp-pipedrive-fator3/`: runtime exato da entrega. `tests/`: testes nativos e controladores de laboratório descartável. `build/`: gerador de schemas, ZIP determinístico e verificador. `evidence/`: provas desta rodada. `inputs050/`: entradas atuais. `inputs/`, `evidence040/`, PLANO-0.4.0.md e relatório0.4.0 são históricos herdados; não contar seus testes nesta rodada.

Construção: PHP8.3.36 com OpenSSL/mbstring/MySQL no WordPress7.1.3+; Python3 com biblioteca padrão. Lint local usou PHP8.3.6, separado dos testes funcionais8.3.36. Não há dependências Composer/npm.

```sh
php build/schemas.php > plugin/wp-mcp-pipedrive-fator3/docs/schemas.json
python3 build/package.py installer --out /caminho/saida
python3 build/verify.py --php /caminho/php --installer /caminho/saida/wp-mcp-pipedrive-fator3-0.5.0-instalador.zip
python3 build/package.py source --out /caminho/saida
```

O verificador compara evidências remotas congeladas, integridade, sintaxe, schemas e reprodutibilidade; não substitui executar a bancada. Resultado desta rodada:67 gates, incluindo36 lints. Fonte contém cópia do relatório anterior ao fechamento; hash próprio somente no relatório externo.

Para bancada autorizada, empacotar runner.php a partir de tests/lab-runner.php, todos tests/*.php, installer.zip final e base.zip0.4.0 em ZIP temporário separado da entrega. Usar controlador tests/lab-controller.php somente no Site-Teste; roots/prefixos/marker exclusivos e bloqueio HTTP/e-mail impedem efeitos comerciais. Instalar controller MU com backup; upload do ZIP em wp-content/f3-pipedrive-qa-0500.zip. Para mínimo, backend PHP/JSON/HTML/TXT/CRT do WordPress7.1.3 original, sem wp-config/wp-content, em wp-content/f3-pipedrive-wp713-backend.zip. Contém apenas backend, sem prova visual de assets.

Ações current:setup→freeze→install→native→report→retention→release→requests050→integrate→integrated→core→core-report→core-workflows→diagnostics. Minimum:setup→install→native→report→retention→release→requests050→documents050. Upgrade:setup→install-base→seed-upgrade→upgrade→verify-upgrade→upgrade-restart. Cada execução é processo PHP independente. Repita cenários com prefixo limpo: fixtures usam chaves idempotentes fixas. Não executar esses testes no banco compartilhado.

Snapshot compartilhado tests/shared-controller.php lê apenas hashes/contagens/versão; não usar sua ação de fixture na produção. Cleanup de cada cenário confere marker e remove somente prefixo/diretório próprios. Depois excluir controladores e ZIPs temporários, preservando backups/auditoria MCP. Todos já removidos desta rodada; não reinstalar para consultar provas.

Fornecedores das suítes são sintéticos. Aceite do pedido10 em korvena.com.br é responsabilidade do dono/frota; não houve chamada comercial real, envio de WhatsApp, push GitHub ou modificação de acompanhantes.
