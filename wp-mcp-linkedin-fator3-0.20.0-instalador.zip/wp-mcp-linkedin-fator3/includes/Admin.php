<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class Admin {
    public static function menu(): void {add_management_page(Config::NAME,Config::NAME,'manage_options',Config::SLUG,[self::class,'screen']);}
    private const GROUPS = [
        'connections' => ['Conexões', ['connections'=>'Lista de conexões','assets'=>'Ativos']],
        'leads' => ['Concessões', ['leads'=>'Formulários','conversions'=>'Conversões de aquisição','stages'=>'Etapas comerciais']],
        'reports' => ['Dados', ['reports'=>'Relatórios','jobs'=>'Coletas','history'=>'Histórico']],
        'management' => ['Anúncios e publicações', ['management'=>'Anúncios e publicações']],
        'diagnostics' => ['Manutenção', ['diagnostics'=>'Diagnóstico','retention'=>'Retenção']],
        'help' => ['Ajuda', ['help'=>'Ajuda']],
    ];
    public static function tabs(): array {
        $tabs=[];
        foreach(self::GROUPS as [, $panels]) $tabs += $panels;
        return $tabs;
    }
    public static function currentTab(): string {
        $tab=sanitize_key((string)($_GET['tab']??'connections'));
        return isset(self::tabs()[$tab]) ? $tab : 'connections';
    }
    private static function link(string $id,string $label,string $group,bool $main,bool $current): void {
        $url=add_query_arg(['page'=>Config::SLUG,'tab'=>$id],admin_url('tools.php'));
        echo '<a href="'.esc_url($url).'" data-tab="'.esc_attr($id).'" data-group="'.esc_attr($group).'"'.($main?' data-main=""':'').($current?' aria-current="page"':'').'>'.esc_html($label).'</a>';
    }
    private static function navigation(): void {
        $tab=self::currentTab();
        echo '<nav class="f3-tabs" aria-label="Seções">';
        foreach(self::GROUPS as $key=>[$title,$panels]) self::link($key,$title,$key,true,isset($panels[$tab]));
        echo '</nav>';
        foreach(self::GROUPS as $key=>[$title,$panels]) {
            if(count($panels)<2) continue;
            echo '<nav class="f3-subnav" data-subnav="'.esc_attr($key).'" aria-label="'.esc_attr($title).'"'.(isset($panels[$tab])?'':' hidden').'>';
            foreach($panels as $id=>$label) self::link($id,$label,$key,false,$id===$tab);
            echo '</nav>';
        }
    }
    public static function users(array $i): array {
        Access::admin();$offset=$i['offset']??0;$args=['number'=>51,'offset'=>$offset,'orderby'=>'display_name','order'=>'ASC','fields'=>['ID','display_name','user_login']];
        if(!empty($i['search'])){$args['search']='*'.sanitize_text_field($i['search']).'*';$args['search_columns']=['display_name','user_login'];}
        if(!empty($i['ids'])){$args['include']=$i['ids'];$args['number']=100;$args['offset']=0;}
        $users=get_users($args);$more=empty($i['ids'])&&count($users)>50;$users=array_slice($users,0,empty($i['ids'])?50:100);
        return ['rows'=>array_map(static fn($u)=>['id'=>(int)$u->ID,'name'=>$u->display_name.' ('.$u->user_login.')','can_administer'=>user_can((int)$u->ID,'manage_options')],$users),'next_offset'=>$more?$offset+50:null,'selection_does_not_grant_capability'=>true];
    }
    public static function options(array $i): array {
        Access::admin();if($i['kind']==='users')return self::users($i);
        if(empty($i['connection_id'])||empty($i['channel']))throw new Fault('invalid_input','Escolha conexão e canal.');
        $c=Connections::get($i['connection_id']);Access::connection($c,$i['channel']);$principal=Access::principal();$out=[];
        if($i['kind']==='assets')return Query::accounts(array_intersect_key($i,array_flip(['connection_id','channel','cursor'])));
        if($i['kind']==='journal'){
            if(Config::KEY!=='f3_linkedin')throw new Fault('unsupported','Recurso do LinkedIn.');$at=$i['offset']??0;$records=Store::list('subscription',$at,50);$out=[];
            foreach($records as $r){$v=$r['value'];if(($v['consumer']??null)!==''||($v['connection_id']??'')!==$c['id'])continue;$owner=$v['wanted']['owner']['sponsoredAccount']??'';if(!preg_match('/^urn:li:sponsoredAccount:([0-9]+)$/D',$owner,$m)||!in_array($m[1],$c['assets']['leads'],true))continue;
                // Existing SDK remains the authority for ownership and active grant/form selection.
                $proof=PublicApi::lead_reader('')->get_subscription_operation(['connection_id'=>$c['id'],'account_id'=>$m[1],'ownership_key'=>$r['key']]);if(!$proof['success'])continue;
                $out[]=['id'=>$r['key'],'name'=>'Assinatura '.($v['remote_id']??'sem recibo remoto'),'account_id'=>$m[1],'state'=>$v['state'],'operation_revision'=>$r['revision']];
            }return ['rows'=>$out,'next_offset'=>count($records)===50?$at+50:null,'connection_revision'=>$c['revision']];
        }
        Connections::usable($c);
        if($i['kind']==='selected'){
            $at=$i['offset']??0;$ids=array_slice($c['assets'][$i['channel']],$at,10);
            foreach($ids as $id){try{$out[]=self::assetName($c,$i['channel'],$id);}catch(Fault $e){$out[]=['id'=>$id,'name'=>null,'name_status'=>'unavailable','reason'=>$e->reason];}}
            $result=['rows'=>$out,'next_offset'=>$at+count($ids)<count($c['assets'][$i['channel']])?$at+count($ids):null];
        }elseif($i['kind']==='objects'){
            $allowed=Config::KEY==='f3_meta'?['media','stories','page_posts','page_videos']:['campaigns'];$report=$i['report']??'';if(!in_array($report,$allowed,true))throw new Fault('unsupported','Lista de objetos não permitida.');
            if(empty($i['account_id']))throw new Fault('invalid_input','Escolha uma conta.');
            $q=['connection_id'=>$c['id'],'channel'=>$i['channel'],'account_id'=>$i['account_id'],'report'=>$report,'limit'=>25];if(isset($i['cursor']))$q['cursor']=$i['cursor'];
            $page=Query::execute($q);foreach($page['rows'] as $row){$id=(string)($row['id']??'');if($id==='')continue;$text=$row['name']??$row['caption']??$row['message']??$row['title']??'';$date=$row['timestamp']??$row['created_time']??'';
                $out[]=['id'=>$id,'name'=>self::title($text)?:($date?'Publicação de '.self::title($date):'Publicação sem título'),'date'=>self::title($date)];}
            $result=['rows'=>$out,'next_cursor'=>$page['next_cursor']];
        }elseif($i['kind']==='forms'){
            if(Config::KEY!=='f3_linkedin'||$i['channel']!=='leads'||empty($i['account_id']))throw new Fault('invalid_input','Escolha uma conta de formulários.');Access::connection($c,'leads',$i['account_id']);$at=$i['offset']??0;
            $r=Http::request($c,'leadForms',['q'=>'owner','owner'=>['sponsoredAccount'=>'urn:li:sponsoredAccount:'.$i['account_id']],'start'=>$at,'count'=>50])['body'];$rows=Adapter::elements($r);
            foreach($rows as $row){if(($row['owner']['sponsoredAccount']??'')!=='urn:li:sponsoredAccount:'.$i['account_id'])throw new Fault('upstream_invalid','Formulário de outra conta.');$id=(string)($row['id']??'');Util::numeric($id);$out[]=['id'=>$id,'name'=>self::title($row['name']??'')?:'Formulário sem nome','version'=>(string)($row['versionId']??'')];}
            $accountName=null;try{$accountName=self::assetName($c,'leads',$i['account_id'])['name'];}catch(Fault $e){}
            $result=['rows'=>$out,'account_name'=>$accountName,'next_offset'=>Adapter::more($r,$at,count($rows),50)?$at+count($rows):null];
        }else throw new Fault('unsupported','Lista não suportada.');
        Connections::revalidate($c);Access::checkPrincipal($principal);return $result+['connection_revision'=>$c['revision'],'selection_required'=>true];
    }
    private static function title($v): string {return is_scalar($v)?mb_substr(sanitize_text_field((string)$v),0,180):'';}
    private static function assetName(array $c,string $ch,string $id): array {
        Access::asset($c,$ch,$id);
        if(Config::KEY==='f3_meta'){$auth=Adapter::credential($c,$ch,$id);$r=Http::request($auth,$id,['fields'=>$ch==='facebook'?'id,name':'id,name,username'])['body'];$name=$r['name']??$r['username']??'';}
        else{$r=Http::request($c,($ch==='pages'?'organizations/':'adAccounts/').$id)['body'];$name=$r['localizedName']??$r['name']??'';}
        if((string)($r['id']??'')!==$id)throw new Fault('upstream_invalid','Identidade divergente.');return ['id'=>$id,'name'=>self::title($name)?:null,'name_status'=>$name!==''?'available':'unavailable'];
    }
    public static function assets(string $hook): void {
        if($hook!=='tools_page_'.Config::SLUG||!current_user_can('manage_options'))return;
        wp_enqueue_style(Config::KEY,plugins_url('assets/admin.css',Config::FILE),[],Config::VERSION);wp_enqueue_script(Config::KEY,plugins_url('assets/admin.js',Config::FILE),[],Config::VERSION,true);
        $error=null;$connections=[];try{$connections=Connections::list(0,100);}catch(\Throwable $e){$error='Não foi possível ler as conexões locais. Consulte Diagnóstico.';}
        if(Config::KEY==='f3_linkedin')wp_enqueue_script(Config::KEY.'_conversions',plugins_url('assets/conversions.js',Config::FILE),[Config::KEY],Config::VERSION,true);
        if(Config::KEY==='f3_linkedin')wp_enqueue_script(Config::KEY.'_stage_conversions',plugins_url('assets/stage-conversions.js',Config::FILE),[Config::KEY],Config::VERSION,true);
        if(Config::KEY==='f3_linkedin')wp_enqueue_script(Config::KEY.'_management',plugins_url('assets/management.js',Config::FILE),[Config::KEY],Config::VERSION,true);
        wp_localize_script(Config::KEY,'F3Social',['root'=>esc_url_raw(rest_url(Config::REST.'/')),'nonce'=>wp_create_nonce('wp_rest'),'channels'=>Config::CHANNELS,'reports'=>Adapter::reports(),'provider'=>Config::PREFIX,'apiVersion'=>Config::API_VERSION,'version'=>Config::VERSION,'tab'=>self::currentTab(),'bootstrap'=>['connections'=>$connections,'error'=>$error,'currentUser'=>get_current_user_id()]]);
    }
    private static function control(string $name,string $label,string $html,bool $check=false): void {
        $id=wp_unique_id('f3-field-');$helpKey=FieldHelp::forField($label);
        $attrs=' aria-labelledby="'.esc_attr($id.'-name').'"'.($helpKey?' aria-describedby="'.esc_attr($id.'-help').'"':'');
        $html=str_replace(' data-f3-control', $attrs, $html);
        $caption='<span id="'.esc_attr($id.'-name').'">'.esc_html($label).'</span>';
        echo '<div class="f3-field"><label'.($check?' class="f3-check"':'').'>'.($check?$html.$caption:$caption.$html);
        echo '</label>';
        if($helpKey) FieldHelp::disclosure($helpKey,$id.'-help');
        echo '</div>';
    }
    private static function input(string $name,string $label,string $type='text',string $extra=''): void {
        self::control($name,$label,'<input data-f3-control type="'.esc_attr($type).'" name="'.esc_attr($name).'" '.$extra.'>');
    }
    private static function select(string $name,string $label,array $options=[],string $extra=''): void {
        $html='<select data-f3-control name="'.esc_attr($name).'" '.$extra.'>';if(!$options)$html.='<option value="">Escolha uma opção</option>';
        foreach($options as $v=>$l)$html.='<option value="'.esc_attr((string)$v).'">'.esc_html($l).'</option>';
        self::control($name,$label,$html.'</select>');
    }
    private static function check(string $name,string $label,bool $checked=false): void {
        self::control($name,$label,'<input data-f3-control type="checkbox" name="'.esc_attr($name).'" '.checked($checked,true,false).'>',true);
    }
    private static function section(string $id): void {echo '<section id="f3-'.$id.'" class="f3-section" '.(self::currentTab()!==$id?'hidden':'').'>';}
    public static function screen(): void {
        if(!current_user_can('manage_options')){wp_die('Administração necessária.',403);return;}$meta=Config::KEY==='f3_meta';
        ?><div class="wrap f3-social"><header class="f3-heading"><div><h1><?php echo esc_html(Config::NAME);?></h1></div><span class="f3-badge">Versão <?php echo esc_html(Config::VERSION);?></span></header>
        <?php self::navigation();?>
        <div id="f3-message" role="status" aria-live="polite" aria-atomic="true"></div><noscript><p class="notice notice-warning">Ative o JavaScript para consultar e salvar pela tela. As abas continuam acessíveis por seus endereços.</p></noscript>
        <details id="f3-context" class="f3-card" hidden><summary>Seleção da consulta <span id="f3-context-summary"></span> · Alterar</summary><div class="f3-grid"><?php self::select('connection_id','Conexão',[],'form="f3-query" required');self::select('channel','Canal',[],'form="f3-query"');self::select('account_id','Conta autorizada',[],'form="f3-query" required');self::select('report','Relatório',[],'form="f3-query"');self::input('date_from','Data inicial','date','form="f3-query"');self::input('date_to','Data final','date','form="f3-query"');?></div><p id="f3-context-state" class="f3-state" role="status">Lendo configuração local…</p></details>
        <?php self::section('connections');if(!$meta&&self::currentTab()==='connections'&&isset($_GET['connection_id']))AdminManagement::credentialNotice();?><div id="f3-connection-directory"><h2>Conexões do LinkedIn</h2>
        <p>Escolha uma conexão para editar ou cadastre uma nova. Depois de salvar, abra <strong>Ativos</strong> para selecionar as contas e Páginas permitidas.</p>
        <div class="f3-actions"><label>Buscar conexão por nome ou identificador <input type="search" id="f3-connection-search" aria-controls="f3-connection-list"></label><button type="button" class="button" id="f3-new-connection">Nova conexão</button></div><div id="f3-connection-list" class="f3-scroll"></div><div class="f3-pager"><p id="f3-connection-count" role="status"></p><button type="button" class="button" id="f3-connections-prev" aria-controls="f3-connection-list" disabled>Anterior</button> <button type="button" class="button" id="f3-connections-more" aria-controls="f3-connection-list" disabled>Próxima</button></div></div>
        <div id="f3-connection-editor" hidden><button type="button" class="button-link" id="f3-back-connections">Voltar à lista</button><h2 id="f3-editor-heading">Editar conexão</h2>
        <p id="f3-connection-state" role="status"></p>
        <form id="f3-connection"><input type="hidden" name="connection_id"><input type="hidden" name="expected_revision" value="0">
        <fieldset><legend>1. Identificação</legend><div class="f3-grid"><?php self::input('label','Nome da conexão','text','required maxlength="120" placeholder="membro · aplicativo"');self::check('enabled','Conexão ativa');?></div></fieldset>
        <fieldset><legend>2. Aplicativo</legend><div class="f3-grid"><?php self::input('client_id','ID do aplicativo'); self::input('client_secret','Chave secreta do aplicativo','password','autocomplete="new-password"'); self::input('application_id','Identificação do aplicativo nas notificações');?></div><?php FieldHelp::callback();?></fieldset>
        <fieldset><legend>3. Acesso ao LinkedIn</legend><p>Para usar o token manual, informe o acesso abaixo. Para autorizar pelo LinkedIn, salve primeiro o aplicativo como conexão pausada. Campos secretos vazios conservam os valores salvos.</p><p class="description">Espaços nas pontas são aparados com aviso. A validade é conferida com o LinkedIn.</p><div class="f3-grid"><?php self::input('token','Token de acesso','password','autocomplete="new-password"'); self::input('expires','Validade informada do token (UTC)','datetime-local');?></div><p id="f3-local-expiry"></p><?php AdminManagement::credentials();?><div id="f3-saved-identity" aria-live="polite"></div></fieldset>
        <fieldset><legend>4. Ativos</legend><p>Depois de salvar, selecione as Páginas, as contas de anúncios e os formulários permitidos.</p><button type="button" class="button" id="f3-open-assets" disabled>Escolher ativos desta conexão</button></fieldset>
        <details class="f3-config-panel"><summary>Renovação e aviso de vencimento</summary><p>Preencha o token de renovação quando o aplicativo tiver essa permissão. Alterar o prazo de aviso exige simulação e confirmação.</p><div class="f3-grid"><?php self::input('refresh_token','Token de renovação (opcional)','password','autocomplete="new-password"');self::input('refresh_expires','Validade do token de renovação (UTC)','datetime-local');self::input('credential_notice_days','Antecedência do aviso (dias)','number','min="1" max="365" value="14"');?></div></details>
        <details class="f3-config-panel"><summary>Usuários WordPress associados</summary><p>Escolha pelo nome. O usuário também precisa de permissão administrativa no WordPress.</p><label>Buscar usuário por nome<input type="search" id="f3-user-search"></label> <button type="button" class="button" id="f3-user-find">Buscar</button><div id="f3-user-options" class="f3-choices" role="group" aria-label="Usuários"></div><p id="f3-users-state" role="status">Carregando usuários…</p><button type="button" class="button" id="f3-users-more" hidden>Carregar mais usuários</button></details>
        <details class="f3-config-panel"><summary>Guarda dos resultados de coleta</summary><p>O prazo abaixo vale para os resultados desta conexão. A auditoria tem uma política própria na aba Retenção.</p><div class="f3-grid"><?php self::select('retention_mode','Retenção dos resultados',['unlimited'=>'Sem expiração automática','finite'=>'Prazo em dias']);self::input('retention_days','Dias de guarda','number','min="1" max="3650" value="90"');?></div></details>
        <details class="f3-config-panel f3-sensitive"><summary>Remover credenciais salvas</summary><p>Marque somente os segredos que deseja apagar. A remoção será aplicada ao salvar e pode interromper o acesso da conexão.</p><div class="f3-checks"><?php self::check('clear_token','Remover token salvo');self::check('clear_client_secret','Remover chave secreta salva');self::check('clear_refresh_token','Remover token de renovação salvo');?></div></details>
        <p id="f3-pending-authorization" hidden><label><input type="checkbox" name="use_pending_authorization">Usar autorização candidata conferida (expira em dez minutos)</label></p>
        <fieldset id="f3-identity-change"><legend>Simular alterações e conferir concessões</legend><p>Confira quais agendas e concessões serão afetadas. Se a identidade mudar, confirme a simulação antes de salvar.</p><button class="button" type="button" id="f3-identity-preview">Simular alterações</button><div id="f3-identity-preview-result" aria-live="polite"></div><label hidden><input type="checkbox" name="reconfirm_leads">Reconfirmar as concessões ativas do Lead Sync neste salvamento</label><label hidden><input type="checkbox" name="reconfirm_conversions">Reconfirmar a concessão ativa da Conversions API neste salvamento</label><p><button class="button" type="button" id="f3-identity-confirm" disabled>Confirmar alterações</button></p></fieldset>
        <div class="f3-actions f3-form-footer"><button class="button button-primary">Salvar conexão</button><span id="f3-dirty" role="status"></span></div></form>
        <?php if($meta){?><details><summary>Renovar token preservando agendas</summary><p>Escolha a conexão em edição. A identidade e os ativos serão conferidos antes da substituição.</p><form id="f3-rotate"><div class="f3-grid"><?php self::input('token','Novo token de acesso','password','required autocomplete="new-password"');if(!$meta){self::input('refresh_token','Token de renovação (opcional)','password','autocomplete="new-password"');self::input('refresh_expires','Validade do token de renovação (UTC)','datetime-local');self::check('clear_refresh_token','Remover token de renovação salvo');}self::input('expires','Validade do novo token (UTC)','datetime-local');?></div><button class="button">Validar e substituir</button></form></details><?php }?></div></section>
        <?php self::section('assets');?><h2>Ativos autorizados</h2><p><strong>1. Escolha a conexão.</strong> Carregue as listas por canal, marque os ativos e salve. Se a origem recusar o acesso, as seleções existentes serão conservadas.</p><label>Conexão<select id="f3-assets-connection"><option value="">Escolha uma conexão salva</option></select></label><div id="f3-asset-options"></div><?php if(!$meta){?><h3>2. Formulários por conta</h3><p>Salve primeiro as contas de formulários. Depois carregue os formulários e marque os permitidos.</p><div id="f3-connection-forms"></div><?php }?><div class="f3-actions"><button class="button button-primary" id="f3-save-assets" type="button">Salvar seleção de ativos e formulários</button></div><div id="f3-assets-state" role="status"></div></section><?php self::section('conversions'); FieldHelp::conversions('acquisition'); echo '</section>'; self::section('stages'); FieldHelp::conversions('stages'); echo '</section>';?>
        <?php self::section('reports');?><h2>Relatório</h2><form id="f3-query"><div class="f3-grid"><?php self::input('limit','Linhas por página','number','min="1" max="100" value="50"');if($meta){self::select('granularity','Período dos valores',['day'=>'Diário','interval'=>'Intervalo']);self::select('media_id','Mídia',[],'data-object="media"');self::select('entity_id','Publicação ou vídeo',[],'data-object="facebook"');self::select('breakdown','Demografia',['country'=>'País','city'=>'Cidade','age'=>'Idade','gender'=>'Gênero']);self::select('timeframe','Janela de demografia',['last_30_days'=>'Últimos 30 dias','last_14_days'=>'Últimos 14 dias','last_90_days'=>'Últimos 90 dias','this_month'=>'Este mês','this_week'=>'Esta semana','prev_month'=>'Mês anterior','prev_week'=>'Semana anterior']);self::check('iterate_media','Capturar todas as mídias');}else{self::select('pivot','Agrupar anúncios por',['ACCOUNT'=>'Conta','CAMPAIGN_GROUP'=>'Grupo de campanhas','CAMPAIGN'=>'Campanha','CREATIVE'=>'Anúncio','CONVERSION'=>'Conversão','MEMBER_COUNTRY_V2'=>'País','MEMBER_REGION_V2'=>'Região','MEMBER_INDUSTRY'=>'Setor','MEMBER_COMPANY'=>'Empresa','MEMBER_SENIORITY'=>'Nível de experiência','MEMBER_JOB_TITLE'=>'Cargo','MEMBER_JOB_FUNCTION'=>'Função','MEMBER_COMPANY_SIZE'=>'Porte da empresa']);self::select('granularity','Período dos anúncios',['DAILY'=>'Diário','ALL'=>'Intervalo completo']);}?></div><p id="f3-object-state" role="status"></p><button type="button" class="button" id="f3-object-more" hidden>Carregar mais objetos</button><?php if(!$meta){?><details id="f3-campaign-filter"><summary>Filtrar por campanhas</summary><button type="button" class="button" id="f3-campaign-load">Carregar campanhas</button><div id="f3-campaign-options" class="f3-choices"></div><button type="button" class="button" id="f3-campaign-more" hidden>Carregar mais campanhas</button></details><?php }?><fieldset><legend>Campos do relatório</legend><p>Nenhum marcado usa os campos padrão.</p><div id="f3-fields" class="f3-choices"></div><p id="f3-fields-state" role="status"></p></fieldset><div class="f3-actions"><button class="button button-primary">Consultar página</button><button class="button" type="button" id="f3-next" hidden>Próxima página</button><button class="button" type="button" id="f3-collect">Coletar todas as páginas</button><button class="button" type="button" id="f3-backfill">Coletar histórico do período</button></div></form><div id="f3-coverage"></div><div id="f3-result" class="f3-scroll"></div></section>
        <?php self::section('jobs');?><h2>Coletas e agendas</h2><form id="f3-schedule"><input type="hidden" name="schedule_id"><input type="hidden" name="expected_revision" value="0"><div class="f3-grid"><?php self::input('label','Nome da agenda','text','required maxlength="120"');self::input('interval_minutes','Intervalo em minutos','number','min="60" max="43200" value="1440"');self::input('lookback_days','Últimos dias completos','number','min="1" max="30" value="7"');self::input('next_at','Próxima execução (UTC)','datetime-local');?></div><p class="description">A agenda usa a seleção acima. O horário indica quando o cron do site pode iniciar a coleta.</p><button class="button button-primary">Salvar agenda</button><button type="button" class="button" id="f3-new-schedule">Nova agenda</button></form><div id="f3-schedule-list"></div><h3>Coletas registradas</h3><button type="button" class="button" id="f3-refresh-jobs">Atualizar coletas</button><div id="f3-job-list"></div></section>
        <?php self::section('history');?><h2>Histórico local</h2><p>Usa a seleção e as datas acima. Lacunas da origem permanecem identificadas.</p><div class="f3-actions"><button class="button button-primary" id="f3-history-query">Consultar histórico</button><button class="button" id="f3-history-next" hidden>Próxima página</button><button class="button" id="f3-history-csv">Baixar CSV</button><button class="button" id="f3-history-json">Baixar JSON</button></div><div id="f3-history-status"></div><div id="f3-history-result" class="f3-scroll"></div><details><summary>Manutenção de histórico legado</summary><button class="button" id="f3-history-migrate">Avançar migração</button></details></section><?php if(!$meta){self::section('retention');?><h2>Guarda da auditoria local</h2><p>Por padrão, os eventos são guardados sem prazo. Um prazo em dias permite que a manutenção remova eventos antigos. O histórico diário permanece sem expiração, independentemente da retenção dos resultados de coleta.</p><form id="f3-retention-form"><input type="hidden" name="expected_revision" value="0"><div class="f3-grid"><?php self::select('audit_mode','Guardar auditoria',['unlimited'=>'Sem prazo','finite'=>'Prazo em dias']);self::input('audit_days','Dias de auditoria','number','min="1" max="36500" value="30"');?></div><p>Primeiro simule para ver quantos eventos ficam elegíveis. Depois confirme a política; a remoção ocorre na manutenção seguinte.</p><button class="button">Simular alteração</button><button type="button" class="button button-primary" id="f3-retention-save" disabled>Confirmar política</button></form><p id="f3-retention-result" role="status"></p></section><?php self::section('leads');?><h2>Concessões de formulários</h2><p>Escolha o consumidor e a conexão; depois marque os formulários e as permissões que ele deve usar. O Site Core recebe e deduplica os contatos. Salvar a concessão não cadastra um contato.</p><form id="f3-grant"><input type="hidden" name="expected_revision" value="0"><div class="f3-grid"><?php self::select('consumer_id','Consumidor',[],'required');self::select('connection_id','Conexão',[],'required');self::input('callback_url','Endereço de recebimento do consumidor','url','placeholder="https://seu-site/endpoint"');self::check('enabled','Concessão ativa',true);?></div><div id="f3-grant-forms" class="f3-choices"></div><fieldset><legend>Permissões do consumidor</legend><?php foreach(['metadata'=>'Ler metadados','responses'=>'Ler respostas de formulários','verify'=>'Verificar assinaturas','subscriptions'=>'Gerenciar assinaturas próprias','campaign_lookup'=>'Consultar nome da campanha vinculada ao lead (exige a conta selecionada em Ads)'] as $v=>$label)echo '<label class="f3-check"><input type="checkbox" name="permission" value="'.esc_attr($v).'"> '.esc_html($label).'</label>';?></fieldset><button class="button button-primary">Salvar concessão</button></form><div id="f3-grants"></div><h3>Diário de assinaturas administrativas</h3><p>Selecione uma operação local. Assinaturas de consumidores são reconciliadas pelo SDK do consumidor responsável.</p><form id="f3-subscription-journal"><div class="f3-grid"><?php self::select('connection_id','Conexão',[],'required');self::select('ownership_key','Operação de assinatura',[],'required');self::check('authorize_current_context','Autorizar vínculo à credencial atual do mesmo aplicativo');?></div><input type="hidden" name="account_id"><input type="hidden" name="expected_operation_revision"><button class="button">Consultar estado</button><button type="button" class="button" id="f3-journal-refresh">Atualizar operações</button><button type="button" class="button" id="f3-journal-more" hidden>Carregar mais operações</button><button type="button" class="button" id="f3-subscription-reconcile">Reconciliar recibo remoto</button></form><div id="f3-subscription-result"></div></section><?php }?>
        <?php if(!$meta)AdminManagement::screen();self::section('diagnostics');?><h2>Diagnóstico</h2><p>Consulte primeiro o estado do plugin. Use a validação externa quando precisar conferir um ativo específico.</p>
        <fieldset><legend>Estado local</legend><p>O estado mostra agendas, fila e avisos de credenciais. O autoteste confere o armazenamento, a criptografia e os contratos locais. Nenhum dos dois consulta o LinkedIn.</p>
        <div class="f3-actions"><button type="button" class="button" id="f3-status">Consultar estado local</button><button type="button" class="button" id="f3-selftest">Executar autoteste local</button></div><div id="f3-diagnostic-result" aria-live="polite"></div></fieldset>
        <fieldset><legend>Verificar acesso a um ativo</legend><p>Escolha um ativo já autorizado na conexão. O botão consulta os metadados no LinkedIn e registra a última prova local. Essa leitura não confirma acesso a relatórios, leads ou conversões.</p>
        <div class="f3-grid"><label>Conexão salva<select id="f3-diagnostic-connection"></select></label><label>Canal<select id="f3-diagnostic-channel"></select></label><label>Ativo autorizado<select id="f3-diagnostic-account"></select></label></div>
        <button class="button" type="button" id="f3-validate" disabled>Validar ativo no LinkedIn</button><p id="f3-diagnostic-selection" class="description"></p><div id="f3-diagnostic-remote" aria-live="polite"></div></fieldset><details><summary>Configuração avançada da versão da API</summary><p>Aplicada somente à conexão escolhida. Alterar a versão exige rever coletas e concessões.</p><form id="f3-api-version"><div class="f3-grid"><?php self::select('connection_id','Conexão',[],'required');self::input('api_version','Versão da API','text','required');?></div><button class="button">Simular versão da API</button> <button type="button" class="button button-primary" id="f3-api-version-confirm" disabled>Confirmar versão simulada</button><div id="f3-api-version-result" role="status"></div></form></details></section>
        <?php self::section('help');?><h2>Documentação instalada</h2><p>Comece por PRIMEIROS-PASSOS.md para configurar e verificar uma conexão. A ajuda funciona sem token do LinkedIn.</p><label>Documento<select id="f3-help-document"><option value="">Carregando índice…</option></select></label><button class="button" id="f3-help-read">Ler documento completo</button><p id="f3-help-description"></p><article id="f3-help-content" aria-label="Manual selecionado"></article><details><summary>Referência dos campos</summary><?php FieldHelp::table();?></details></section></div><?php
    }
}
