# Campos e telas — 0.20.0

Referências oficiais consultadas em 22/10/2026; não foi realizada conferência dentro da sessão autenticada do dono. A tabela também é renderizada na aba Ajuda e as instruções acompanham os campos em Conexão, Ativos e Concessões. Campos próprios do WordPress são identificados como locais.

| Campo no plugin | Nome no LinkedIn | Onde encontrar |
|---|---|---|
| Token de acesso | Access Token | Developers → Tools → OAuth Token Tools → Token Generator → aplicativo |
| ID do cliente | Client ID | Developers → aplicativo → Auth → Application credentials → Authentication keys |
| Chave secreta | Primary Client Secret | Mesmo local; use o botão de copiar ao lado do valor |
| Número do aplicativo | App ID no endereço | Número depois de /developers/apps/; não confundir com Client ID |
| Renovação | Refresh Token / refresh_token | Resposta OAuth de app aprovado para Programmatic Refresh Tokens |
| Validade do acesso | Access Token expiration / expires_in | Token Generator ou duração da resposta OAuth somada à emissão; informar UTC |
| Validade de renovação | refresh_token_expires_in | Duração em segundos na resposta OAuth somada à emissão, em UTC |
| Retorno OAuth | Authorized redirect URLs for your app | Developers → aplicativo → Auth → OAuth 2.0 settings; endereço do site pronto para copiar na aba Conexão |
| Página | Page ID / Organization ID | Página administrativa, número em /company/<ID>/; confirmar por descoberta |
| Conta Ads | Ad account ID | Campaign Manager, número após /campaignmanager/accounts/ |
| Formulário | Lead Gen Form ID | Campaign Manager → conta → Assets → Lead Gen Forms; seleção por nome descoberto |
| Regra | Conversion ID / Data source | Campaign Manager → conta → Measurement → Conversion tracking; número após /conversions/ e fonte Direct API |
| Notificações | Webhook URL | Fornecido pelo consumidor local Lead Sync; diferente do retorno OAuth |
| Nome, usuário, retenção, consumidor, ativo e permissões locais | Não se aplicam | Configuração local do WordPress; não concede produto/escopo no LinkedIn |

Leitura usa r_ads, r_ads_reporting, r_organization_admin, r_organization_social conforme a operação. Gestão acrescenta rw_ads e w_organization_social; Lead Sync exige r_marketing_leadgen_automation; CAPI exige rw_conversions e r_ads. Disponibilidade depende dos produtos aprovados. Introspecção usa Client ID + Primary Client Secret para verificar Access Token. OAuth 401 nessa etapa aponta o par do aplicativo; token inativo/expirado aponta Access Token. A resposta não revela nenhum valor secreto.

Links fixos: https://www.linkedin.com/developers/apps ; https://www.linkedin.com/developers/tools/oauth/token-generator ; https://www.linkedin.com/campaignmanager/ .
Referências: https://learn.microsoft.com/en-us/linkedin/shared/api-guide/best-practices/secure-applications ; https://learn.microsoft.com/en-us/linkedin/shared/authentication/programmatic-refresh-tokens ; https://learn.microsoft.com/en-us/linkedin/shared/authentication/token-introspection .

## Avisos junto das credenciais

Espaços externos são aparados com aviso, internos preservados e formatos incomuns apenas avisados; a conferência no LinkedIn decide. Controles e limites máximos continuam recusados. O aviso fica junto ao campo, inclusive em erro remoto e depois de salvar, sem reproduzir o valor. Consulte CREDENTIALS.md.

## Aviso de vencimento da credencial

Avisar sobre a credencial (dias): credential_notice_days, padrão 14, faixa 1–365, exige simular e confirmar alterações. Renovar agora inicia a primeira renovação; Usar autorização candidata e a confirmação concluem a mudança quando a identidade exigir.
