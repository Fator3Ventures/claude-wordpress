# Fator3 MCP LinkedIn 0.20.0 — índice da documentação

A release corrente é 0.20.0. Este índice diz o que o plugin faz, qual documento ler para cada tarefa e como ler a ajuda pelo MCP.

## O que o plugin faz

Conecta um site WordPress a LinkedIn Pages, LinkedIn Ads, Lead Sync (formulários de contato) e Conversions API. Guarda as credenciais cifradas, consulta relatórios, agenda coletas, mantém um histórico diário local, exporta CSV e JSON e executa alterações de anúncios e publicações em duas fases, com prévia. As mesmas operações atendem o painel, o REST do site e os agentes pelo Fator3 MCP.

O que fica fora dele:

- Contatos, deduplicação, consentimento e fila de conversões pertencem ao Fator3 Site Core. Este plugin entrega as respostas dos formulários e envia os eventos que o Core pede; não cadastra contato.
- O transporte MCP, sua autenticação e a descoberta de ferramentas pertencem ao Fator3 MCP. Sem ele, o painel e o REST continuam funcionando.
- Aprovação de produtos, escopos e papéis nas contas são decididos no LinkedIn. Nenhuma tela deste plugin concede acesso que o aplicativo não tem.

## Requisitos e acesso

WordPress 7.1.4 ou superior, PHP 8.3 ou superior em 64 bits, banco com InnoDB e travas nomeadas, criptografia autenticada e WP-Cron ou cron do sistema. Instalação por site; a ativação em rede é recusada. O painel fica em **Ferramentas → Fator3 MCP LinkedIn**. Painel, REST e MCP exigem administrador (`manage_options`).

## Qual documento ler

| Preciso… | Documento | O que ele contém |
|---|---|---|
| Configurar a primeira conexão e conferir o resultado | PRIMEIROS-PASSOS.md | Pré-requisitos no LinkedIn, sequência na tela e como verificar cada etapa. |
| Entender cada aba do painel | ADMINISTRATION.md | As seis seções e seus painéis, o que cada uma mostra e quais ações consultam o LinkedIn. |
| Saber o que significa cada campo | FIELD-HELP.md | Nome do campo na tela, nome no LinkedIn e onde encontrar o valor. |
| Conhecer campos, limites e padrões da configuração | CONFIGURATION.md | Conexão, ativos, concessões, retenção e versão da API, com faixas aceitas. |
| Autorizar, renovar ou trocar credenciais | CREDENTIALS.md | OAuth, introspecção, renovação, troca guiada de identidade e avisos. |
| Operar como agente | AGENTS.md | Sequência descobrir → ler → diagnosticar → configurar → verificar, com exemplos. |
| Encontrar a operação certa | ABILITIES.md | Catálogo das 99 operações por assunto, com tipo, efeito no LinkedIn e parâmetros obrigatórios. |
| Consultar relatórios e agendar coletas | OPERATIONS.md e WORKER.md | Rotina de consulta, coleta, exportação, cron e recuperação da fila. |
| Guardar e consultar o histórico diário | HISTORY.md | As três políticas de retenção, cobertura, retroação e exportação. |
| Alterar anúncio, publicação ou orçamento | MANAGEMENT.md | As duas fases, a prévia, o diário de intenções e a reconciliação. |
| Usar formulários de contato | LEAD-DISCOVERY.md, CAMPAIGN-METADATA.md e SDK-PHP.md | Seleção de formulários, nome da campanha do lead e SDK usado pelo Site Core. |
| Enviar conversões | CONVERSIONS.md e STAGE-CONVERSIONS.md | Concessão de aquisição, concessão por etapa comercial e envio. |
| Investigar uma recusa ou um código de erro | TROUBLESHOOTING.md | Códigos, significado e próxima ação. |
| Conhecer contratos e schemas | CONTRACTS.md, input-schemas.json, output-schema.json, lead-campaign-schema.json | Envelope de resposta, contratos publicados e schemas de entrada. |
| Entender proteção de dados e auditoria | SECURITY.md e SERVICE-AUDIT.md | Cifragem, autorização, auditoria local e auditoria de serviço. |
| Instalar ou atualizar | MIGRATION.md e RELEASE-0.20.0.md | Passos da troca e o que mudou nesta versão. |
| Ver o histórico de versões | CHANGELOG.md e RELEASE-*.md anteriores | Registros históricos. Não descrevem limites atuais. |

## Correspondência com os documentos lógicos do padrão Fator3

| Documento lógico | Onde está |
|---|---|
| Índice | README.md |
| Especificação | Seção «O que o plugin faz» deste índice, ADMINISTRATION.md e os manuais de domínio (MANAGEMENT.md, HISTORY.md, LEAD-DISCOVERY.md, CONVERSIONS.md, STAGE-CONVERSIONS.md, CAMPAIGN-METADATA.md) |
| Configuração | PRIMEIROS-PASSOS.md, CONFIGURATION.md, CREDENTIALS.md e FIELD-HELP.md |
| Uso | ABILITIES.md, OPERATIONS.md e os manuais de domínio |
| Contratos | CONTRACTS.md, SDK-PHP.md, SERVICE-AUDIT.md e os três arquivos JSON |
| Guia para agentes | AGENTS.md |
| Operação | OPERATIONS.md, WORKER.md, TROUBLESHOOTING.md, SECURITY.md e MIGRATION.md |
| Notas da versão | RELEASE-0.20.0.md e CHANGELOG.md |

## Ler a ajuda pelo painel

Abra a aba **Ajuda**, escolha o documento e use **Ler documento completo**. A leitura não depende do Fator3 MCP nem de token do LinkedIn. O texto aparece em Markdown sem formatação.

## Ler a ajuda pelo MCP

1. Chame `linkedin/documentation` com `{"document":"index"}`. A resposta lista cada documento com `document`, `bytes` e `sha256`.
2. Leia um documento com `{"document":"PRIMEIROS-PASSOS.md","offset":0,"limit_bytes":16384}`. `limit_bytes` aceita de 256 a 65536; o padrão é 16384.
3. Enquanto `next_offset` não for nulo, repita a chamada com `offset` igual a `next_offset` e `expected_revision` igual ao `revision` da primeira página. `offset` maior que zero sem `expected_revision` é recusado.
4. Concatene `content` sem separadores e confira o total de bytes e o SHA-256 contra o índice.

Respostas que indicam erro de uso:

| Código | Situação |
|---|---|
| `not_found` | O documento pedido não está no índice. Caminhos de arquivo não são aceitos. |
| `revision_conflict` | `expected_revision` ausente em continuação ou diferente do hash instalado. Recomece pelo índice. |
| `invalid_input` | Faixa inválida ou `offset` no meio de um caractere UTF-8. |
| `documentation_unavailable` | O conteúdo instalado difere do índice. Confira o pacote. |

A leitura usa somente a documentação instalada, não chama o LinkedIn, não altera dados e não grava auditoria.

Cada entrada do índice informa também `title`, `description` e `kind` (manual, schema ou history). O ID `document` continua sendo a chave para a leitura.
