> Versão corrente: **1.51.0**, contrato **8.16.0**. Pedidos 294 e 295: [RELEASE-1.51.0.md](RELEASE-1.51.0.md), [AGENTES-1.51.0.md](AGENTES-1.51.0.md), [PIPEDRIVE-OPERACAO.md](PIPEDRIVE-OPERACAO.md) e [CREDENCIAIS-1.51.md](CREDENCIAIS-1.51.md). Conteúdo anterior abaixo é histórico.

> Versão corrente: **1.50.0**, contrato **8.15.0**. Leia [RELEASE-1.50.0.md](RELEASE-1.50.0.md), [AGENTES-1.50.0.md](AGENTES-1.50.0.md) e [CREDENCIAIS-1.50.md](CREDENCIAIS-1.50.md). Conteúdo anterior abaixo é histórico.

# Versão atual: 1.49.1

Consulte [RELEASE-1.49.1.md](RELEASE-1.49.1.md) e [AGENTES-1.49.1.md](AGENTES-1.49.1.md). Base direta: [RELEASE-1.49.0.md](RELEASE-1.49.0.md).
