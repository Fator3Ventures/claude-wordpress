# Documentação instalada — Core 1.34.0

Leitura autorizada: f3base/documentacao-ler; arquivo/linha/limite até 200, SHA-256 e continuação até nulo. Exige manage_options. Índice atual prevalece sobre notas históricas. Nomes 1.33 de MEDICAO identificam a introdução do SDK mantido.

| Documento | Conteúdo |
|---|---|
| RELEASE-1.34.0.md | Escopo, instalação, banco, reversão e limites |
| AGENTES-1.34.0.md | Receitas, autorização e evidências |
| LINKEDIN-LEAD-SYNC.md | Coleção, clientes, concessões, transição, assinatura e recuperação |
| GSC-1.34.md | Apresentação, autorização e coleta |
| CORRECOES-OPERACIONAIS-1.34.md | Slack, CRM, alertas, memória e GTM |
| CONFIGURACAO.md / AJUDA-OPCOES.md | Configuração e ajuda gerada |
| CONTRACTS.md / dados/abilities-*.json | Contratos e schemas integrais |
| dados/configuracao-schema.json | Modelo administrativo 8.0.0 sem valores privados |
| MEDICAO-SDK-1.33.md / MEDICAO-EVENTOS-1.33.md | SDK público mantido, eventos e revisões |
| schemas/measurement-*.json / fixtures/measurement/*.json | Schemas fechados e exemplos completos |
| DICIONARIO-DADOS.md / dados/contrato.json | Tabelas, unidades, vínculos e retenção |
| ../dados/estado-inventario.json | Propriedade, backup e uninstall |
| OPERACAO-E-RECUPERACAO.md | Ciclo, pausa, backup e restore |
| VALIDACAO.md | Tipos de prova e limites |
| FORMULARIOS-1.29.md / COMUNICACAO-CONTATOS-1.27.md | Fluxos mantidos de captura e comunicação |
| ATRIBUICAO-1.32.md / HISTORICO-1.29.md / RELATORIOS.md | Atribuição, histórico e leitura |

RELEASE/AGENTES/IMPACTO de versões anteriores são históricos; não são procedimento de instalação atual. A leitura não ativa integração nem comprova acesso externo.

Especificações de origem instaladas: PLANO-1.34.0-REVISAO-4.md e ESPECIFICACAO-LINKEDIN-REVISAO-3.md. Seus aceites são requisitos, não resultados. Normas NORMA-01/NORMA-02 revisão 4 prevalecem sobre regras de entrega antigas do plano.
