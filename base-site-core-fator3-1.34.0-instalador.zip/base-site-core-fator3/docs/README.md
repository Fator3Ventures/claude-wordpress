# Documentação do pacote

Índice vigente: DOCUMENTACAO.md — Core 1.34.0. Instruções atuais: AGENTES-1.34.0.md e RELEASE-1.34.0.md.
