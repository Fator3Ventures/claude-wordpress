# Validação — Core 1.34.0

Provas próprias: lint PHP, WordPress nativo descartável, instalação nova e upgrade direto da 1.33.0; memória/Slack/alertas/GTM; migração; cliente LinkedIn Core e SDK real 0.2.0; transições; identidade Pipedrive; SDK de medição e consumidor Google 0.10.0. Transportes de fornecedores são simulados, sem efeitos externos. Os testes e evidências sanitizadas acompanham o fonte; relatório externo identifica o instalador exato e resultado final da matriz.

Não somar provas recebidas como executadas: inspeções do plano (21 estáticas revisão 1, seis observações MCP revisão 2, quatro observações LinkedIn revisão 3, 30 casos sociais e inventários revisão 4) pertencem às bases/relatórios recebidos. Reexecutar no candidato somente o que consta das evidências próprias.

Pendências externas: I03 LinkedIn com recursos autorizados, exclusão Slack, recebimento de e-mail, Pipedrive CTO Office/Korvena e janelas reais 24/48 horas. Não há homologação de fornecedor por fixture, stub, clique ou silêncio. Estado de cache/Yoast, navegador, Site-Teste e inventário do pacote final consta no relatório externo. Instalação e leitura de ajuda não dependem dessas homologações.
