# Instruções do plugin

Leia AGENTES-1.34.0.md e DOCUMENTACAO.md. Schemas e diagnóstico instalados descrevem o contrato atual. Normas comuns revisão 4. Histórico não é instrução operacional atual.
