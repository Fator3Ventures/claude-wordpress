# Fator3 Site Core 1.34.0

Plugin WordPress: base-site-core-fator3/base-site-core-fator3.php. Instalação nova ou atualização direta da 1.33.0. PHP 64 bits, instalação única. Contrato administrativo 8.0.0; SDK de medição site-measurement-context/1.0.0, schema 1, preservado.

Leia docs/DOCUMENTACAO.md, docs/RELEASE-1.34.0.md, docs/AGENTES-1.34.0.md e docs/LINKEDIN-LEAD-SYNC.md. Acompanhantes ensaiados localmente: MCP 0.23.0, Google 0.10.0, LinkedIn 0.2.0, Meta 0.2.0. Recursos opcionais validam seu contrato ao operar; Core não depende deles para instalar.

Fornecedor simulado não comprova efeito externo. O relatório de entrega registra hashes, matriz de aceite e pendências remotas.
