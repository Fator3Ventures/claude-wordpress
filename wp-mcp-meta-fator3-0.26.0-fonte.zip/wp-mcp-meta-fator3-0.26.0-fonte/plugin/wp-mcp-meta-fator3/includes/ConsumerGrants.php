<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Local SDK grants only. Job, export and interactive MCP identities are not converted. */
final class ConsumerGrants {
    public static function administrator(): array {
        $p=Access::principal();$sdk='\\Fator3\\McpFiles\\ConnectionContext';
        if(is_callable([$sdk,'transport_identity'])){
            $identity=$sdk::transport_identity();
            if(is_array($identity)&&preg_match('/^(grant:|app:)/',$identity['connection_id']??'')
                &&(!$p['channel']||($identity['user_id']??0)!==$p['user_id']))throw new Fault('not_authorized','Concessão de transporte revogada.');
        }
        Access::checkPrincipal($p);
        return $p;
    }
    /** Normalize both saved 0.25.0 grants and new records; never substitute the current user. */
    public static function owner(array $p): array {
        $id=$p['user_id']??null;
        if(!is_int($id)||$id<=0)throw new Fault('not_authorized','Responsável pela concessão indisponível.');
        return ['user_id'=>$id,'channel'=>null];
    }
    /** A local, read-only probe; do not run SDK reads, audit calls, notification or transport discovery. */
    public static function inspect(string $kind,callable $validate): array {
        $out=[];$after='';
        do{
            $rows=Store::scan($kind.'_grant',$after,100);
            foreach($rows as $row){
                $v=$row['value'];$after=$row['key'];$scope=array_intersect_key($v,array_flip(['consumer_id','connection_id','account_id']));
                $enabled=!empty($v['enabled']);$state=$enabled?'ready':'disabled';$reason=null;
                if($enabled)try{$validate($scope,$row);}catch(Fault $e){$state='blocked';$reason=$e->reason;}
                $out[]=$scope+['resource'=>$kind,'enabled'=>$enabled,'revision'=>$row['revision'],'state'=>$state,'reason'=>$reason,'repair_operation'=>'meta/save-'.$kind.'-grant'];
            }
        }while(count($rows)===100);
        return $out;
    }
    public static function withHealth(array $health): array {
        $grants=array_merge(AdsReader::grantHealth(),MonitoringReader::grantHealth());
        foreach($grants as $g)if($g['state']==='blocked'){
            $health['state']='degraded';
            $health['issues'][]=['code'=>'consumer_grant_blocked','consumer_id'=>$g['consumer_id'],'connection_id'=>$g['connection_id'],'account_id'=>$g['account_id'],'resource'=>$g['resource'],'last_code'=>$g['reason'],'action'=>$g['repair_operation']];
        }
        $health['consumer_grants']=$grants;
        return $health;
    }
}
