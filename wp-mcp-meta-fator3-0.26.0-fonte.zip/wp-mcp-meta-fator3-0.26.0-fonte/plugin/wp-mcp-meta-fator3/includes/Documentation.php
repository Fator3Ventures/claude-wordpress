<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** The compiled index identifies the installed files; only the selected document is read. */
final class Documentation {
    public const MAX_BYTES=65536;

    private static function content(string $id,array $entry): string {
        $root=realpath(Config::DIR);
        $file=$root===false?null:$root.'/docs/'.$id;
        if($file===null || realpath($file)!==$file || !is_file($file)){
            throw new Fault('documentation_unavailable','Documento instalado ausente ou fora da pasta permitida.');
        }
        // A replaced file cannot grow memory use without bound or disclose unverified bytes.
        $text=@file_get_contents($file,false,null,0,$entry['bytes']+1);
        if($text===false)throw new Fault('documentation_unavailable','Não foi possível ler o documento instalado.');
        if(strlen($text)!==$entry['bytes'] || !hash_equals($entry['sha256'],hash('sha256',$text))){
            throw new Fault('revision_conflict','Os bytes do documento não correspondem ao índice da versão instalada.');
        }
        return $text;
    }

    public static function read(array $i): array {
        Access::admin();
        $docs=require Config::DIR.'includes/Data/Documentation.php';
        $id=$i['document']??'README.md';
        $identity=['slug'=>Config::SLUG,'plugin_version'=>Config::VERSION,'origin'=>'local','encoding'=>'UTF-8'];
        $topics=require Config::DIR.'includes/Data/DocumentationTopics.php';
        if($id==='index')return $identity+['documents'=>array_values($docs),'topics'=>$topics,'max_limit_bytes'=>self::MAX_BYTES,'read'=>['ability'=>Config::PREFIX.'/documentation','parameters'=>['document'=>'README.md','offset'=>0,'limit_bytes'=>16384]],'continuation'=>'Use next_offset e expected_revision; concatene content sem separadores e confira SHA-256 integral.'];
        if(!is_string($id)||!isset($docs[$id]))throw new Fault('not_found','Documento fora do índice instalado.');
        $entry=$docs[$id];$bytes=$entry['bytes'];$hash=$entry['sha256'];
        $at=$i['offset']??0;$limit=$i['limit_bytes']??16384;
        if(!is_int($at)||$at<0||$at>$bytes||!is_int($limit)||$limit<256||$limit>self::MAX_BYTES)throw new Fault('invalid_input','Faixa documental inválida.');
        if($at>0&&!isset($i['expected_revision']))throw new Fault('invalid_input','Para continuar a leitura (offset maior que zero), informe expected_revision com o valor de revision da primeira página.',['field'=>'expected_revision','problem'=>'missing_required']);
        if(isset($i['expected_revision'])&&!hash_equals($hash,$i['expected_revision']))throw new Fault('revision_conflict','Documento alterado; reinicie pelo índice.');
        $content=self::content($id,$entry);
        if($at<$bytes&&(ord($content[$at])&0xc0)===0x80)throw new Fault('invalid_input','Offset deve iniciar caractere UTF-8.');
        $end=min($bytes,$at+$limit);
        while($end<$bytes&&(ord($content[$end])&0xc0)===0x80)$end--;
        return $identity+['document'=>$id,'title'=>$entry['title'],'content'=>substr($content,$at,$end-$at),'sha256'=>$hash,'revision'=>$hash,'total_bytes'=>$bytes,'offset'=>$at,'returned_bytes'=>$end-$at,'next_offset'=>$end<$bytes?$end:null,'has_more'=>$end<$bytes,'documents'=>$id==='README.md'?array_values($docs):[]];
    }
}
