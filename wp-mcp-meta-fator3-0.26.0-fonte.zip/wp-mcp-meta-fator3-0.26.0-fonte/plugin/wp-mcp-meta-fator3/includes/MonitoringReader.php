<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** In-process registered consumers; explicit grants never provide provider credentials. */
final class MonitoringReader {
    public const CONTRACT='meta-ads-monitoring/1.0.0';
    private static array $consumers=[];
    public static function contract(): array {return ['contract'=>self::CONTRACT,'registration_hook'=>'f3_meta_register_monitoring_consumers','sdk'=>self::class,'methods'=>['register_consumer','client.status','client.query'],'grant'=>'explicit_per_consumer_connection_account','source'=>'encrypted_local_history','remote_calls'=>false,'writes_ads'=>false,'retention'=>'unlimited','reports'=>Monitoring::REPORTS,'dataset_scope'=>'explicit_dataset_ids','identity'=>'activity_content_fingerprint; daily_counts_replace; emq_observations_append'];}
    public static function register_consumer(string $id,string $version,string $contract,callable $configuration,string $label=''): MonitoringReaderClient {
        Util::id($id);if(!preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/D',$version)||$contract!==self::CONTRACT)throw new Fault('contract_mismatch','Contrato de consumidor Meta Ads incompatível.');
        if(isset(self::$consumers[$id]))throw new Fault('consumer_conflict','Consumidor de anúncios já registrado.');
        $client=new MonitoringReaderClient();self::$consumers[$id]=['client'=>$client,'configuration'=>$configuration,'version'=>$version,'label'=>sanitize_text_field($label?:$id)];return $client;
    }
    private static function key(array $i): string {return hash('sha256',Util::json([$i['consumer_id'],$i['connection_id'],$i['account_id']]));}
    private static function configuration(string $id): array {
        if(!isset(self::$consumers[$id]))throw new Fault('consumer_unavailable','Consumidor de anúncios não registrado.');
        try{$v=(self::$consumers[$id]['configuration'])();}catch(\Throwable $e){throw new Fault('consumer_unavailable','Configuração do consumidor indisponível.');}
        if(!is_array($v)||($v['ready']??false)!==true||!is_string($v['connection_id']??null)||!is_string($v['account_id']??null)||!(is_int($v['revision']??null)||is_string($v['revision']??null)))throw new Fault('consumer_not_ready','Consumidor precisa informar conexão, conta e revisão prontas.');
        Util::id($v['connection_id']);Util::numeric($v['account_id']);if(strlen((string)$v['revision'])>128||(string)$v['revision']==='')throw new Fault('consumer_not_ready','Revisão inválida do consumidor.');
        if(!is_array($v['reports']??null)||!$v['reports']||array_diff($v['reports'],Monitoring::REPORTS)||!is_array($v['dataset_ids']??null)||count($v['dataset_ids'])>12)throw new Fault('consumer_not_ready','Informe relatórios e datasets explícitos.');
        foreach($v['dataset_ids'] as $dataset)Util::numeric($dataset);$v['reports']=array_values(array_unique($v['reports']));$v['dataset_ids']=array_values(array_unique($v['dataset_ids']));sort($v['reports']);sort($v['dataset_ids']);
        return array_intersect_key($v,array_flip(['connection_id','account_id','revision','ready','reports','dataset_ids']));
    }
    public static function consumers(): array {
        ConsumerGrants::administrator();$out=[];foreach(self::$consumers as $id=>$r){try{$cfg=self::configuration($id);$state='ready';}catch(Fault $e){$cfg=null;$state=$e->reason;}$out[]=['consumer_id'=>$id,'label'=>$r['label'],'version'=>$r['version'],'configuration'=>$cfg,'state'=>$state];}
        $grants=[];for($at=0;;$at+=100){$batch=Store::list('monitoring_grant',$at,100);foreach($batch as $r){$v=$r['value'];$grants[]=array_intersect_key($v,array_flip(['consumer_id','connection_id','account_id','enabled','reports','dataset_ids']))+['revision'=>$r['revision']];}if(count($batch)<100)break;}
        return ['contract'=>self::CONTRACT,'consumers'=>$out,'grants'=>$grants];
    }
    public static function grant(array $i): array {Schemas::validate('get-monitoring-grant',$i);ConsumerGrants::administrator();$r=Store::get('monitoring_grant',self::key($i));return $i+['revision'=>$r['revision']??0,'enabled'=>$r['value']['enabled']??false,'authorization_revision'=>$r['value']['authorization_revision']??null,'consumer_revision'=>$r['value']['configuration']['revision']??null,'reports'=>$r['value']['reports']??[],'dataset_ids'=>$r['value']['dataset_ids']??[]];}
    public static function save(array $i): array {
        Schemas::validate('save-monitoring-grant',$i);$p=ConsumerGrants::administrator();$key=self::key($i);
        return Store::lock('monitoring-grant:'.$key,static function()use($i,$p,$key){
            $old=Store::get('monitoring_grant',$key);if(($old['revision']??0)!==$i['expected_revision'])throw new Fault('revision_conflict','Concessão de anúncios alterada.');
            $v=['consumer_id'=>$i['consumer_id'],'connection_id'=>$i['connection_id'],'account_id'=>$i['account_id'],'enabled'=>$i['enabled'],'reports'=>$i['reports'],'dataset_ids'=>$i['dataset_ids'],'principal'=>ConsumerGrants::owner($p),'authorization_revision'=>null,'configuration'=>null];
            if($i['enabled']){$c=Connections::get($i['connection_id']);Access::worker($p,$c,'ads',$i['account_id'],false);$cfg=self::configuration($i['consumer_id']);if($cfg['connection_id']!==$c['id']||$cfg['account_id']!==$i['account_id'])throw new Fault('consumer_scope_mismatch','O consumidor selecionou outra conexão ou conta.');$reports=$i['reports'];$datasets=$i['dataset_ids'];sort($reports);sort($datasets);if($reports!==$cfg['reports']||$datasets!==$cfg['dataset_ids'])throw new Fault('consumer_scope_mismatch','Relatórios e datasets da concessão devem corresponder à seleção do consumidor.');foreach($datasets as $dataset)Access::asset($c,'dataset',$dataset);$v['configuration']=$cfg;$v['authorization_revision']=$c['authorization_revision'];}
            Access::checkPrincipal($p);$r=Store::put('monitoring_grant',$key,$v,$i['expected_revision'],0);
            return ['revision'=>$r['revision'],'enabled'=>$v['enabled'],'consumer_id'=>$i['consumer_id'],'connection_id'=>$i['connection_id'],'account_id'=>$i['account_id']];
        });
    }
    private static function authorized(string $id,array $i,?array $record=null): array {
        $cfg=self::configuration($id);if($i['connection_id']!==$cfg['connection_id']||$i['account_id']!==$cfg['account_id'])throw new Fault('consumer_scope_mismatch','Seleção fora da configuração do consumidor.');
        $r=$record??Store::get('monitoring_grant',self::key($i+['consumer_id'=>$id]));if(!$r||empty($r['value']['enabled']))throw new Fault('grant_revoked','Leitura do acervo não autorizada.');$v=$r['value'];
        if(!Util::same($cfg,$v['configuration']))throw new Fault('revision_conflict','Configuração do consumidor mudou; reautorize a concessão.');
        $c=Connections::get($i['connection_id']);if($c['authorization_revision']!==$v['authorization_revision'])throw new Fault('revision_conflict','Autorização da conexão mudou; reautorize o consumidor.');
        $r['value']['principal']=ConsumerGrants::owner($v['principal']??[]);Access::worker($r['value']['principal'],$c,'ads',$i['account_id'],false);foreach($cfg['dataset_ids'] as $dataset)Access::asset($c,'dataset',$dataset);return [$r,$cfg,$c];
    }
    public static function grantHealth(): array {
        return ConsumerGrants::inspect('monitoring',static fn(array $scope,array $row)=>self::authorized($scope['consumer_id'],$scope,$row));
    }
    public static function call(MonitoringReaderClient $client,string $op,array $i): array {
        $id=null;foreach(self::$consumers as $key=>$r)if($r['client']===$client){$id=$key;break;}
        $result=Result::run(static function()use($id,$op,$i){
            if($id===null)throw new Fault('not_authorized','Cliente não registrado.');
            Util::guardKeys($i,$op==='status'?['connection_id','account_id']:['connection_id','account_id','report','dataset_id','date_from','date_to','limit','cursor']);
            if(!is_string($i['connection_id']??null)||!is_string($i['account_id']??null))throw new Fault('invalid_input','Informe conexão e conta.');Util::id($i['connection_id']);Util::numeric($i['account_id']);
            $key=self::key($i+['consumer_id'=>$id]);
            return Store::lock('monitoring-grant:'.$key,static function()use($id,$op,$i){
                [$grant,$cfg,$c]=self::authorized($id,$i);
                if($op==='status')return self::contract()+['ready'=>true,'grant_revision'=>$grant['revision'],'connection_revision'=>$c['authorization_revision'],'consumer_revision'=>$cfg['revision'],'account_id'=>$i['account_id']];
                if(!in_array($i['report']??null,$cfg['reports'],true))throw new Fault('grant_revoked','Relatório não concedido.');
                $q=$i;unset($q['cursor'],$q['dataset_id']);$q['channel']='ads';
                if($i['report']==='dataset_quality'){if(!in_array($i['dataset_id']??null,$cfg['dataset_ids'],true))throw new Fault('asset_access_denied','Dataset não concedido.');$q['channel']='dataset';$q['account_id']=$i['dataset_id'];$q['ads_account_id']=$i['account_id'];}elseif(isset($i['dataset_id']))throw new Fault('invalid_input','Dataset só se aplica a dataset_quality');$binding=hash('sha256',Util::json([$id,$grant['revision'],$cfg,$c['authorization_revision'],$q]));
                if(!empty($i['cursor'])){if(!is_string($i['cursor'])||strlen($i['cursor'])>50000)throw new Fault('invalid_cursor','Cursor inválido.');$cur=Util::uncursor($i['cursor']);if(($cur['binding']??'')!==$binding)throw new Fault('revision_conflict','Continuação de outra concessão ou seleção.');$q['cursor']=$cur['history_cursor'];}
                $data=History::readAuthorized($q,$grant['value']['principal']);
                [$after,$again,$current]=self::authorized($id,$i);if($after['revision']!==$grant['revision']||!Util::same($cfg,$again)||$current['revision']!==$c['revision'])throw new Fault('revision_conflict','Autorização alterada durante a leitura.');
                if($data['next_cursor'])$data['next_cursor']=Util::cursor(['binding'=>$binding,'history_cursor'=>$data['next_cursor'],'expires'=>time()+86400]);
                $data['contract']=self::CONTRACT;$data['grant_revision']=$grant['revision'];return $data;
            });
        });
        Audit::record('monitoring-reader-'.$op,$i,$result,$id,'local_sdk');return $result;
    }
}
final class MonitoringReaderClient {
    public function status(array $i): array {return MonitoringReader::call($this,'status',$i);}
    public function query(array $i): array {return MonitoringReader::call($this,'query',$i);}
}
