<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Read-only daily monitoring; no graph URL supplied by a caller is followed. */
final class Monitoring {
    public const REPORTS=['ads_activity','dataset_quality'];
    public static function fields(string $report,string $version): array {
        $names=$report==='ads_activity'?['event_time','object_id','object_name','object_type','event_type','actor_id','actor_name','old_value','new_value','extra_data']:['record_kind','event_name','browser_count','server_count','count_coverage','emq','emq_observed_at','optimized_by','zero_confirmed'];
        return array_map(static fn($f)=>['name'=>$f,'source_field'=>$f,'catalog_revision'=>Catalog::REVISION,'api_version'=>$version,'availability'=>'requires_remote_validation','historical_horizon_days'=>null,'history_requires_explicit_start'=>true,'retention'=>'unlimited','aggregation'=>'preserve_source','temporal'=>$report==='ads_activity'?'event_time':'daily_counts_and_observed_emq'], $names);
    }
    public static function after(array $r): ?string {
        if(empty($r['paging']['next']))return null;$v=$r['paging']['cursors']['after']??null;
        if(!is_string($v)||$v===''||strlen($v)>8192)throw new Fault('coverage_incomplete','A origem retornou paginação sem cursor seguro.');return $v;
    }
    /** Finish a bounded edge before treating its coverage as usable; never truncate silently. */
    public static function edge(array $c,string $path,array $q,int $pages=10): array {
        $out=[];$seen=[];
        for($p=0;$p<$pages;$p++){
            $r=Http::request($c,$path,$q)['body'];if(!is_array($r['data']??null)||!array_is_list($r['data']))throw new Fault('upstream_invalid','Lista de monitoramento inválida.');
            $out=array_merge($out,$r['data']);if(count($out)>3000)throw new Fault('coverage_incomplete','A coleta excedeu o limite de 3000 registros por dia; nenhum zero foi inferido.');
            $next=self::after($r);if($next===null)return $out;if(isset($seen[$next]))throw new Fault('coverage_incomplete','A origem repetiu o cursor.');$seen[$next]=true;$q['after']=$next;
        }
        throw new Fault('coverage_incomplete','A coleta excedeu o limite de páginas deste dia; nenhum zero foi inferido.');
    }
    public static function day(array $c,array $i,array $s): array {
        Ads::scope($c);$account=$i['ads_account_id']??$i['account_id'];$meta=Ads::account($c,$account);Util::dates($i,3660);$tz=new \DateTimeZone($meta['timezone']);$day=$s['day']??$i['date_to'];
        if(!is_string($day)||$day<$i['date_from']||$day>$i['date_to'])throw new Fault('invalid_cursor','Dia fora da seleção.');$start=new \DateTimeImmutable($day.' 00:00:00',$tz);$end=$start->modify('+1 day');$today=new \DateTimeImmutable('today',$tz);
        if($i['date_to']>=$today->format('Y-m-d'))throw new Fault('invalid_input','Selecione dias completos no fuso da conta de anúncios.');
        return [$meta,$day,$start->getTimestamp(),$end->getTimestamp(),$today->modify('-1 day')->format('Y-m-d')];
    }
    public static function next(array $i,string $day,?string $after=null): ?array {return $after!==null?['day'=>$day,'after'=>$after]:($day>$i['date_from']?['day'=>gmdate('Y-m-d',strtotime($day.' UTC')-86400)]:null);}
    public static function activity(array $c,array $i,array $s): array {
        [$meta,$day,$start,$end]=self::day($c,$i,$s);$limit=$i['limit']??50;
        $q=['fields'=>'actor_id,actor_name,application_id,application_name,event_time,event_type,translated_event_type,object_id,object_name,object_type,extra_data','since'=>$start,'until'=>$end-1,'add_children'=>'true','limit'=>$limit];if(isset($s['after']))$q['after']=$s['after'];
        $r=Http::request($c,'act_'.$i['account_id'].'/activities',$q)['body'];if(!is_array($r['data']??null)||count($r['data'])>$limit)throw new Fault('upstream_invalid','Página de atividades inválida.');$rows=[];
        foreach($r['data'] as $raw){
            if(!is_array($raw)||!is_string($raw['event_time']??null)||!is_string($raw['event_type']??null)||($at=strtotime($raw['event_time']))===false||$at<$start||$at>=$end)throw new Fault('upstream_invalid','Atividade fora do período ou incompleta.');
            $object=Util::numeric((string)($raw['object_id']??''));$extra=$raw['extra_data']??null;if(is_string($extra)){if(strlen($extra)>65536)throw new Fault('response_limit','Detalhe de atividade excede o limite.');$parsed=json_decode($extra,true);if(json_last_error()===JSON_ERROR_NONE)$extra=$parsed;}elseif($extra!==null&&!is_array($extra))throw new Fault('upstream_invalid','Detalhe de atividade inválido.');
            // Meta exposes no activity ID. Stable content fingerprint preserves distinguishable events.
            $key=hash('sha256',Util::json([$i['account_id'],$raw['event_time'],$object,$raw['event_type'],$raw['actor_id']??null,$raw['application_id']??null,self::canonical($extra)]));
            $rows[]=array_intersect_key($raw,array_flip(['event_time','event_type','translated_event_type','actor_id','actor_name','application_id','application_name','object_name','object_type']))+['id'=>$key,'entity_id'=>$key,'object_id'=>$object,'account_id'=>$i['account_id'],'date'=>$day,'extra_data'=>$extra,'old_value'=>is_array($extra)?($extra['old_value']??null):null,'new_value'=>is_array($extra)?($extra['new_value']??null):null,'availability'=>'available','identity_semantics'=>'content_fingerprint; identical_indistinguishable_events_coalesce'];
        }
        return ['rows'=>$rows,'next'=>self::next($i,$day,self::after($r)),'fields'=>array_column(self::fields('ads_activity',$c['api_version']),'name'),'errors'=>[],'warnings'=>['O histórico remoto tem limite definido pela Meta; página vazia não comprova cobertura de toda a vida da conta.','Valores anterior/novo só existem quando fornecidos. Atividades indistinguíveis pelo conteúdo compartilham a mesma chave local.'],'origin_complete'=>false,'timezone'=>$meta['timezone'],'currency'=>$meta['currency'],'temporal'=>'daily'];
    }
    private static function canonical($v) {if(is_array($v)){if(!array_is_list($v))ksort($v);foreach($v as &$x)$x=self::canonical($x);}return $v;}
    public static function datasets(array $c,array $i): array {
        Ads::scope($c);$account=$i['ads_account_id']??'';Util::numeric($account);Access::asset($c,'ads',$account);$q=['fields'=>'id,name','limit'=>50];if(isset($i['after']))$q['after']=$i['after'];$r=Http::request($c,'act_'.$account.'/adspixels',$q)['body'];if(!is_array($r['data']??null))throw new Fault('upstream_invalid','Lista de datasets inválida.');$rows=[];foreach($r['data'] as $v)$rows[]=['id'=>Util::numeric((string)($v['id']??'')),'name'=>is_string($v['name']??null)?$v['name']:null];return ['rows'=>$rows,'continuation'=>self::after($r),'limitation'=>'Selecione explicitamente o dataset e mantenha a conta de anúncios autorizada.'];
    }
    public static function dataset(array $c,array $i,array $s): array {
        Access::asset($c,'dataset',$i['account_id']);[$meta,$day,$start,$end,$yesterday]=self::day($c,$i,$s);$observed=gmdate('c');$dataset=$i['account_id'];$account=$i['ads_account_id'];
        $linked=self::edge($c,'act_'.$account.'/adspixels',['fields'=>'id','limit'=>100],5);$found=false;foreach($linked as $v)if((string)($v['id']??'')===$dataset)$found=true;if(!$found)throw new Fault('asset_access_denied','O dataset não confirmou vínculo com a conta de anúncios selecionada.',ProviderDiagnostic::call($c,'act_'.$account.'/adspixels'));
        $errors=[];$counts=[];$coverage=[];$eventCoverage=[];
        foreach(['browser'=>'WEB_ONLY','server'=>'SERVER_ONLY'] as $source=>$filter){
            try{
                $raw=self::edge($c,$dataset.'/stats',['aggregation'=>'event','event_source'=>$filter,'start_time'=>$start,'end_time'=>$end,'limit'=>100]);
                [$counts[$source],$coverage[$source],$eventCoverage[$source]]=self::counts($raw,$start,$end);
                // The public stats endpoint documents seven days. Outside it, retain returned data without claiming completeness.
                if($start<time()-7*86400){$coverage[$source]=false;$eventCoverage[$source]=array_fill_keys(array_keys($counts[$source]),false);}
                if(!$coverage[$source])$errors[]=['field'=>$source.'_count','date'=>$day,'code'=>'coverage_unconfirmed','observed_at'=>time()];
            }catch(Fault $e){self::optionalFailure($e);$counts[$source]=[];$coverage[$source]=false;$eventCoverage[$source]=[];$errors[]=self::failure($e,$source.'_count',$day,$c,$dataset.'/stats',['aggregation'=>'event','event_source'=>$filter]);}
        }
        $active=[];$quality=[];$optimizationKnown=false;
        if($day===$yesterday){
            try{$active=self::optimization($c,$account,$dataset);$optimizationKnown=true;}catch(Fault $e){self::optionalFailure($e);$errors[]=self::failure($e,'optimized_by',$day,$c,'act_'.$account.'/adsets');}
            try{
                $quality=Http::request($c,'dataset_quality',['dataset_id'=>$dataset,'fields'=>'web{event_name,event_match_quality}'])['body']['web']??null;
                if(!is_array($quality)||!array_is_list($quality)||count($quality)>3000)throw new Fault('upstream_invalid','Qualidade do dataset incompleta.');
                if(!$quality)throw new Fault('value_unavailable','A origem não retornou observações EMQ.');
            }catch(Fault $e){self::optionalFailure($e);$quality=[];$errors[]=self::failure($e,'emq',$day,$c,'dataset_quality');}
        }
        $events=array_values(array_unique(array_merge(array_keys($counts['browser']),array_keys($counts['server']),array_keys($active))));sort($events);$rows=[];
        foreach($events as $event){$browser=$counts['browser'][$event]??null;$server=$counts['server'][$event]??null;$rowCoverage=['browser'=>$eventCoverage['browser'][$event]??false,'server'=>$eventCoverage['server'][$event]??false];$zero=$day===$yesterday&&$optimizationKnown&&!empty($active[$event])&&$rowCoverage['browser']&&$rowCoverage['server']&&$browser===0&&$server===0;
            $id=hash('sha256',Util::json(['event_counts',$dataset,$account,$event]));$rows[]=['id'=>$id,'entity_id'=>$id,'record_kind'=>'event_counts','dataset_id'=>$dataset,'ads_account_id'=>$account,'event_name'=>$event,'date'=>$day,'browser_count'=>$browser,'server_count'=>$server,'count_coverage'=>$rowCoverage,'optimized_by'=>$active[$event]??[],'optimization_observed_at'=>$optimizationKnown?$observed:null,'zero_confirmed'=>$zero,'emq'=>null,'emq_status'=>'separate_observed_snapshot','availability'=>$browser!==null||$server!==null?'available':'unknown','unavailable_fields'=>array_keys(array_filter(['browser_count'=>$browser===null,'server_count'=>$server===null]))];}
        foreach($quality as $entry){
            try{
                if(!is_array($entry))throw new Fault('upstream_invalid','Entrada de qualidade inválida.');
                $event=self::event($entry['event_name']??null);$emq=self::quality($entry['event_match_quality']??null);
                $id=hash('sha256',Util::json(['emq_snapshot',$dataset,$account,$event,$observed]));$rows[]=['id'=>$id,'entity_id'=>$id,'record_kind'=>'emq_snapshot','dataset_id'=>$dataset,'ads_account_id'=>$account,'event_name'=>$event,'date'=>(new \DateTimeImmutable('now',new \DateTimeZone($meta['timezone'])))->format('Y-m-d'),'emq'=>$emq,'emq_observed_at'=>$observed,'emq_status'=>$emq===null?'unavailable':'observed_current','browser_count'=>null,'server_count'=>null,'zero_confirmed'=>false,'availability'=>$emq===null?'unknown':'available'];
                if($emq===null)$errors[]=self::failure(new Fault('value_unavailable','EMQ indisponível.'),'emq',$day,$c,'dataset_quality');
            }catch(Fault $e){self::optionalFailure($e);$errors[]=self::failure($e,'emq',$day,$c,'dataset_quality');}
        }
        if(!$rows&&!$errors)$errors[]=['field'=>'event_counts','date'=>$day,'code'=>'empty_or_suppressed','observed_at'=>time()];
        return ['rows'=>$rows,'next'=>self::next($i,$day),'fields'=>array_column(self::fields('dataset_quality',$c['api_version']),'name'),'errors'=>$errors,'warnings'=>['Navegador e servidor podem conter o mesmo evento; não somar como eventos únicos. Cada contagem soma buckets horários distintos de aggregation=event; cobertura integral exige todas as horas do dia.','Ausência, erro ou janela incompleta não significam zero. Zero exige dois valores explícitos e cobertura confirmada.','EMQ é snapshot atual em registro separado, sem reconstrução para o dia das contagens. Conjuntos ativos também são observados na coleta.','Stats documenta sete dias; dados anteriores devolvidos pela origem não comprovam cobertura completa.'],'origin_complete'=>false,'timezone'=>$meta['timezone'],'currency'=>$meta['currency'],'temporal'=>'daily'];
    }
    private static function optionalFailure(Fault $e): void {if(!in_array($e->reason,['asset_access_denied','resource_not_found','upstream_validation','upstream_invalid','coverage_incomplete','upstream_error','response_limit','rate_limited','budget_exhausted','token_rejected','value_unavailable'],true))throw $e;}
    private static function event($v): string {if(!is_string($v)||$v===''||strlen($v)>256||preg_match('/[\x00-\x1f\x7f]/',$v))throw new Fault('upstream_invalid','Nome de evento inválido.');return $v;}
    private static function failure(Fault $e,string $field,string $day,array $c,string $path,array $q=[]): array {
        $d=CollectionState::diagnostic($e->reason,$e->details+ProviderDiagnostic::call($c,$path,$q));
        return ['field'=>$field,'date'=>$day]+$d;
    }
    private static function quality($emq): ?array {
        if($emq===null)return null;
        if(!is_array($emq)||!is_numeric($emq['composite_score']??null)||(float)$emq['composite_score']<0||(float)$emq['composite_score']>10)throw new Fault('upstream_invalid','EMQ fora do contrato do fornecedor.');
        $out=['composite_score'=>(float)$emq['composite_score'],'match_key_feedback'=>[]];
        if(isset($emq['match_key_feedback'])&&(!is_array($emq['match_key_feedback'])||!array_is_list($emq['match_key_feedback'])||count($emq['match_key_feedback'])>100))throw new Fault('upstream_invalid','Cobertura EMQ inválida.');
        foreach($emq['match_key_feedback']??[] as $v){
            if(!is_array($v)||!is_string($v['identifier']??null)||!preg_match('/^[a-z_]{1,64}$/D',$v['identifier'])||!is_numeric($v['coverage']['percentage']??null)||(float)$v['coverage']['percentage']<0||(float)$v['coverage']['percentage']>100)throw new Fault('upstream_invalid','Cobertura EMQ inválida.');
            $out['match_key_feedback'][]=['identifier'=>$v['identifier'],'coverage'=>['percentage'=>(float)$v['coverage']['percentage']]];
        }return $out;
    }
    private static function counts(array $raw,int $start,int $end): array {
        $out=[];$buckets=[];$eventBuckets=[];
        foreach($raw as $bucket){
            if(!is_array($bucket)||($bucket['aggregation']??'')!=='event'||!is_array($bucket['data']??null)||!array_is_list($bucket['data']))throw new Fault('upstream_invalid','Agregação horária de contagens inválida.');
            $at=$bucket['start_time']??$bucket['timestamp']??null;$at=is_int($at)||(is_string($at)&&ctype_digit($at))?(int)$at:(is_string($at)?strtotime($at):false);
            if($at===false||$at<$start||$at>=$end||($at-$start)%3600!==0)throw new Fault('coverage_incomplete','Bucket fora do dia ou da grade horária solicitada.');
            if(isset($buckets[$at]))throw new Fault('coverage_incomplete','A origem repetiu um bucket; não é seguro somar.');$buckets[$at]=true;$seen=[];
            foreach($bucket['data'] as $entry){
                if(!is_array($entry))throw new Fault('upstream_invalid','Contagem inválida.');$event=self::event($entry['value']??null);$count=$entry['count']??null;
                if(!is_int($count)||$count<0||$count>PHP_INT_MAX-($out[$event]??0))throw new Fault('upstream_invalid','Contagem inválida.');
                if(isset($seen[$event]))throw new Fault('coverage_incomplete','A origem repetiu um evento no mesmo bucket.');$seen[$event]=true;$out[$event]=($out[$event]??0)+$count;$eventBuckets[$event]=($eventBuckets[$event]??0)+1;
            }
        }
        // Missing buckets/events remain unknown; explicit zero is never fabricated.
        $confirmed=$end>$start&&($end-$start)%3600===0&&count($buckets)===intdiv($end-$start,3600);
        $perEvent=[];foreach($out as $event=>$count)$perEvent[$event]=$confirmed&&($eventBuckets[$event]??0)===count($buckets);return [$out,$confirmed&&!in_array(false,$perEvent,true),$perEvent];
    }
    private static function optimization(array $c,string $account,string $dataset): array {
        $map=['PURCHASE'=>'Purchase','LEAD'=>'Lead','COMPLETE_REGISTRATION'=>'CompleteRegistration','ADD_TO_CART'=>'AddToCart','INITIATED_CHECKOUT'=>'InitiateCheckout','VIEW_CONTENT'=>'ViewContent','SEARCH'=>'Search','ADD_PAYMENT_INFO'=>'AddPaymentInfo','ADD_TO_WISHLIST'=>'AddToWishlist','CONTACT'=>'Contact','SUBSCRIBE'=>'Subscribe','START_TRIAL'=>'StartTrial','SCHEDULE'=>'Schedule','SUBMIT_APPLICATION'=>'SubmitApplication','FIND_LOCATION'=>'FindLocation','CUSTOMIZE_PRODUCT'=>'CustomizeProduct','DONATE'=>'Donate'];$out=[];
        $rows=self::edge($c,'act_'.$account.'/adsets',['fields'=>'id,name,account_id,effective_status,promoted_object','effective_status'=>Util::json(['ACTIVE']),'limit'=>100],5);
        foreach($rows as $row){if((string)($row['account_id']??'')!==$account)throw new Fault('asset_access_denied','Conjunto de outra conta.');if(($row['effective_status']??'')!=='ACTIVE'||(string)($row['promoted_object']['pixel_id']??'')!==$dataset)continue;$object=$row['promoted_object'];$event=$map[$object['custom_event_type']??'']??null;if(!$event)continue;$out[$event][]=['adset_id'=>Util::numeric((string)($row['id']??'')),'name'=>is_string($row['name']??null)?$row['name']:null];}return $out;
    }
    /** Local-only health reads durable pages. Revoked or stale plans never raise a zero alert. */
    public static function health(): array {
        $issues=[];$observations=[];$diagnostics=[];$seen=[];
        foreach(Store::list('schedule',0,100) as $record){$v=$record['value'];if(empty($v['enabled'])||($v['query']['report']??'')!=='dataset_quality'||empty($v['last_job']))continue;
            try{$c=Connections::get($v['query']['connection_id']);Connections::checkPlan($v,$c);Access::worker($v['principal'],$c,'dataset',$v['query']['account_id'],false);Access::asset($c,'ads',$v['query']['ads_account_id']);$job=Store::get('job',$v['last_job']);if(!$job)continue;$diagnostic=CollectionState::samples($job['value']['errors']??[],$job['value']['last_error']??null);if($diagnostic)$diagnostics[]=['schedule_id'=>$record['key'],'state'=>$job['value']['outcome']??$job['value']['status'],'last_error'=>$diagnostic[0],'errors'=>$diagnostic,'action'=>ProviderDiagnostic::action($diagnostic[0])];if(!in_array($job['value']['status'],['complete','partial'],true))continue;
                $page=Store::get('result',$v['last_job'].':000000');if(!$page)continue;$data=$page['value']['data'];$yesterday=(new \DateTimeImmutable('yesterday',new \DateTimeZone($data['timezone'])))->format('Y-m-d');if(($data['selection']['date_to']??'')!==$yesterday||strtotime($data['fetched_at'])<time()-36*3600)continue;
                foreach($data['rows'] as $row){if(($row['record_kind']??'')!=='event_counts'||$row['date']!==$yesterday)continue;$observations[]=['connection_id'=>$c['id'],'dataset_id'=>$row['dataset_id'],'event_name'=>$row['event_name'],'date'=>$row['date'],'zero_confirmed'=>$row['zero_confirmed']];if(empty($row['zero_confirmed']))continue;$key=hash('sha256',Util::json([$c['id'],$row['dataset_id'],$row['ads_account_id'],$row['event_name'],$row['date']]));if(isset($seen[$key]))continue;$seen[$key]=true;$issues[]=['code'=>'dataset_optimized_event_zero','incident_key'=>$key,'connection_id'=>$c['id'],'dataset_id'=>$row['dataset_id'],'ads_account_id'=>$row['ads_account_id'],'event_name'=>$row['event_name'],'date'=>$row['date'],'observed_at'=>$data['fetched_at'],'action'=>'Confira o recebimento do evento usado por conjuntos ativos. A notificação ao canal do site pertence ao consumidor Core.'];}
            }catch(Fault $e){$observations[]=['schedule_id'=>$record['key'],'state'=>'unknown','code'=>$e->reason];}
        }return ['state'=>$issues||$diagnostics?'degraded':'ok','issues'=>$issues,'observations'=>$observations,'diagnostics'=>$diagnostics,'remote_calls'=>false,'notification_owner'=>'Core341'];
    }
}
