<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
final class Http {
    private static int $calls=0;
    private static float $until=0;
    private static int $limit=0;
    private static float $started=0;
    private static string $scope='operation';
    public static function budget(int $calls=15,int $seconds=25,string $scope='operation',?float $deadline=null): void {self::$limit=max(0,$calls);self::$calls=self::$limit;self::$started=microtime(true);self::$until=min(self::$started+max(0,$seconds),$deadline??PHP_FLOAT_MAX);self::$scope=$scope;}
    /** Independent SDK invocation; restore the caller's transport state even after errors. */
    public static function adOriginBudget(callable $read): array {
        $saved=[self::$calls,self::$until,self::$limit,self::$started,self::$scope];
        // A live enclosing operation owns its remaining requests and deadline.
        $nested=self::$until>microtime(true);
        self::budget($nested?min(8,self::$calls):8,25,'ad_origin',$nested?self::$until:null);
        try{return $read();}finally{$used=self::$limit-self::$calls;[self::$calls,self::$until,self::$limit,self::$started,self::$scope]=$saved;if($nested)self::$calls=max(0,self::$calls-$used);}
    }
    public static function snapshot(): array {
        $now=microtime(true);return ['kind'=>'local_execution','scope'=>self::$scope,'request_limit'=>self::$limit,'requests_used'=>self::$limit-self::$calls,'requests_remaining'=>max(0,self::$calls),'started_at'=>self::$started>0?(int)self::$started:null,'deadline_at'=>self::$until>0?(int)ceil(self::$until):null,'seconds_remaining'=>self::$until>0?max(0,round(self::$until-$now,3)):0,'observed_at'=>time(),'exhausted_by'=>self::$until===0?'not_initialized':(self::$calls<=0?'requests':($now>self::$until-2?'time':null)),'replenishment'=>'next_execution'];
    }
    public static function remaining(int $calls=1): bool {return self::$calls>=$calls&&microtime(true)<self::$until-3;}
    /** Only provider-returned CDN images; no token header, redirect, arbitrary host or public file. */
    public static function thumbnail(array $c,string $url): string {
        Connections::usable($c);Connections::revalidate($c);$p=wp_parse_url($url);$host=strtolower($p['host']??'');
        if(strlen($url)>4096||!$p||($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port'])||!preg_match('/(?:^|\.)(?:cdninstagram\.com|fbcdn\.net)$/D',$host))throw new Fault('thumbnail_url_denied','Origem da miniatura não permitida.');
        if(!self::remaining())throw new Fault('thumbnail_budget_exhausted','Orçamento de miniaturas atingido.',['execution_budget'=>self::snapshot()]);self::$calls--;
        $r=wp_safe_remote_get($url,['timeout'=>min(5,max(1,(int)(self::$until-microtime(true)))),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1048577,'headers'=>['Accept'=>'image/jpeg,image/png,image/webp']]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)throw new Fault('thumbnail_unavailable','A origem não entregou a miniatura.');
        $body=wp_remote_retrieve_body($r);if(strlen($body)>1048576)throw new Fault('thumbnail_too_large','Imagem de origem excedeu 1 MiB.');Connections::revalidate($c);return $body;
    }
    public static function diagnostic($data,int $http,array $context=[]): array {return ProviderDiagnostic::from($data,$http,$context);}
    /** Candidate inspection never persists quota or credentials. Only fixed GET endpoints are used. */
    public static function inspect(array $c,string $path,array $query=[]): array {return self::request($c,$path,$query,'GET',null,null,false);}
    public static function request(array $c,string $path,array $query=[],string $method='GET',?array $body=null,?callable $beforeDispatch=null,bool $persistQuota=true): array {
        try{return self::send($c,$path,$query,$method,$body,$beforeDispatch,$persistQuota);}
        catch(Fault $e){throw new Fault($e->reason,$e->getMessage(),$e->details+ProviderDiagnostic::call($c,$path,$query));}
    }
    private static function send(array $c,string $path,array $query,string $method,?array $body,?callable $beforeDispatch,bool $persistQuota): array {
        Connections::usable($c);Connections::revalidate($c);
        if(!Adapter::allowed($path,$method))throw new Fault('endpoint_forbidden','Endpoint não permitido.');
        if(self::$until===0)self::budget();
        if(self::$calls<=0||microtime(true)>self::$until-2)throw new Fault('budget_exhausted','Orçamento local desta execução atingido; renovado na próxima execução.',['execution_budget'=>self::snapshot()]);
        $quota=Store::get('quota',$c['id']);if(($quota['value']['until']??0)>time())throw new Fault('rate_limited','A conexão aguarda a janela de quota.',['retry_after'=>$quota['value']['until']-time()]);
        $url=Adapter::base($c).$path;if($query)$url.='?'.Adapter::encode($query);
        $headers=['Authorization'=>'Bearer '.$c['token'],'Accept'=>'application/json'];
        if(Config::KEY==='f3_linkedin')$headers+=['LinkedIn-Version'=>$c['api_version'],'X-Restli-Protocol-Version'=>'2.0.0'];
        if(Config::KEY==='f3_linkedin'&&isset($query['q']))$headers['X-RestLi-Method']='FINDER';
        if($body!==null)$headers['Content-Type']='application/json';
        $args=['method'=>$method,'headers'=>$headers,'timeout'=>min(8,max(1,(int)(self::$until-microtime(true)))),'redirection'=>0,'sslverify'=>true,'limit_response_size'=>1800000];
        if($body!==null)$args['body']=Util::json($body);
        // Guard runs after all local checks and immediately before the remote side effect.
        if($beforeDispatch)$beforeDispatch();
        self::$calls--;
        $r=wp_remote_request($url,$args);unset($args,$headers);
        if(is_wp_error($r))throw new Fault($method==='GET'?'upstream_error':'operation_uncertain','Não houve confirmação do fornecedor.');
        $http=wp_remote_retrieve_response_code($r);$raw=wp_remote_retrieve_body($r);
        if(strlen($raw)>=1800000)throw new Fault('response_limit','Resposta excedeu o orçamento de bytes.');
        $data=$raw===''?[]:json_decode($raw,true,96,JSON_BIGINT_AS_STRING);
        $provider=self::diagnostic($data,$http,[$c,$query]);$graphCode=$provider['provider_code']??0;$graphError=is_array($data)&&is_array($data['error']??null);
        if($http===429||(Config::KEY==='f3_meta'&&in_array($graphCode,[4,17,32,613],true))){$ra=(string)wp_remote_retrieve_header($r,'retry-after');$retry=ctype_digit($ra)?(int)$ra:max(60,(int)strtotime($ra)-time());$retry=max(60,min(86400,$retry));
            if($persistQuota)Store::lock('quota:'.$c['id'],static function()use($c,$retry){$q=Store::get('quota',$c['id']);Store::put('quota',$c['id'],['until'=>time()+$retry],$q['revision']??0);});
            throw new Fault('rate_limited','Limite remoto atingido.',['retry_after'=>$retry]+$provider);}
        if($http<200||$http>=300||$graphError){$code=$http===401?'token_rejected':($http===403?'asset_access_denied':($http===404?'resource_not_found':($http===400?'upstream_validation':'upstream_error')));
            if(Config::KEY==='f3_meta'&&in_array($graphCode,[190,102],true))$code='token_rejected';
            if(Config::KEY==='f3_meta'&&in_array($graphCode,[10,200],true))$code='asset_access_denied';
            if($method!=='GET'&&$http>=500)$code='operation_uncertain';
            if($http>=200&&$http<300&&$code==='upstream_error')$code='upstream_validation';
            throw new Fault($code,'O fornecedor recusou a operação.',$provider);}
        if(!is_array($data))throw new Fault($method==='GET'?'upstream_invalid':'operation_uncertain','Resposta inválida do fornecedor.');
        if($method==='GET')Connections::revalidate($c);
        // A successful write receipt must reach its durable journal even if access changed in flight.
        return ['body'=>$data,'status'=>$http,'id'=>(string)wp_remote_retrieve_header($r,'x-restli-id')];
    }
}
