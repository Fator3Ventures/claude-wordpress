<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
/** Resumable exports use encrypted chunks; no public file or all-history memory buffer. */
final class HistoryExport {
    public static function create(array $i): array {
        $p=Access::principal();$q=$i['query'];if(isset($q['cursor']))throw new Fault('invalid_input','Exportação começa sem cursor.');Schemas::validate('history-query',$q);
        $id=hash('sha256',Util::json([$p,$i['idempotency_key']]));$intent=hash('sha256',Util::json([$q,$i['format']]));
        return Store::lock('history-export:'.$id,static function()use($p,$q,$i,$id,$intent){Access::storedQuery($p,$q);$old=Store::get('history_export',$id);if($old){if($old['value']['intent']!==$intent)throw new Fault('idempotency_conflict','Chave de exportação reutilizada.');return self::receipt($id,$old['value']);}
            $v=['principal'=>$p,'query'=>$q,'format'=>$i['format'],'intent'=>$intent,'state'=>'queued','cursor'=>null,'parts'=>0,'bytes'=>0,'rows'=>0,'expires_at'=>0,'generation'=>null,'last_code'=>null];Store::put('history_export',$id,$v,0,$v['expires_at']);return self::receipt($id,$v);});
    }
    private static function receipt(string $id,array $v): array {return ['export_id'=>$id,'state'=>$v['state'],'parts'=>$v['parts'],'bytes'=>$v['bytes'],'rows'=>$v['rows'],'format'=>$v['format'],'expires_at'=>0,'last_code'=>$v['last_code'],'filename'=>Config::SLUG.'-history-'.substr($id,0,12).'.'.$v['format'],'assembly'=>'Concatenate decoded parts in ascending order after state=complete.'];}
    private static function get(string $id): array {$r=Store::get('history_export',$id);if(!$r||($r['expires_at']>0&&$r['expires_at']<time()))throw new Fault('export_unavailable','Exportação ausente ou expirada.');$r['value']['expires_at']=0;$v=$r['value'];Access::owned($v['principal']);return [$r,Access::storedQuery($v['principal'],$v['query'])];}
    public static function step(array $i): array {
        return Store::lock('history-export:'.$i['export_id'],static function()use($i){$id=$i['export_id'];[$r,$c]=self::get($id);$v=$r['value'];if($v['state']!=='queued')return self::receipt($id,$v);
            $partKey=$id.':'.str_pad((string)$v['parts'],6,'0',STR_PAD_LEFT);$existing=Store::get('history_export_part',$partKey);
            if($existing){$next=$existing['value']['checkpoint'];$next['expires_at']=0;Connections::revalidate($c);Access::checkPrincipal($v['principal']);Store::put('history_export',$id,$next,$r['revision'],$next['expires_at']);return self::receipt($id,$next);}
            try{$q=$v['query'];$q['limit']=min(100,$q['limit']??100);if($v['cursor'])$q['cursor']=$v['cursor'];$data=History::query($q);
                if($v['generation']!==null&&$v['generation']!==$data['generation'])throw new Fault('history_changed','O histórico mudou durante a exportação.');
                $rows=$data['rows'];$content='';$complete=$data['next_cursor']===null;
                if($v['format']==='json'){$content=$v['parts']===0?'{"contract":"meta-history/1.0.0","rows":[':'';foreach($rows as $n=>$row)$content.=($v['rows']+$n>0?',':'').Util::json($row);if($complete)$content.='],"coverage":'.Util::json($data['coverage']).',"generation":'.$data['generation'].'}';}
                else{$h=fopen('php://temp','w+');if($v['parts']===0)fputcsv($h,['row_id','channel','account_id','report','data_day','first_seen','last_seen','temporal','row_json','coverage_json'],',','"','');foreach($rows as $row)fputcsv($h,array_map([Export::class,'safeCell'],[$row['row_id'],$row['channel'],$row['account_id'],$row['report'],$row['data_day'],$row['first_seen'],$row['last_seen'],$row['temporal'],Util::json($row['row']),Util::json($row['coverage'])]),',','"','');rewind($h);$content=stream_get_contents($h);fclose($h);}
                if($v['bytes']+strlen($content)>67108864)throw new Fault('export_limit','Exportação excede 64 MiB; selecione períodos menores.');
                $v['parts']++;$v['bytes']+=strlen($content);$v['rows']+=count($rows);$v['cursor']=$data['next_cursor'];$v['generation']=$data['generation'];$v['state']=$complete?'complete':'queued';
            }catch(Fault $e){
                // A transient write or a revoked/changed scope cannot authorize a terminal receipt update.
                if(in_array($e->reason,['storage_unavailable','persistence_unconfirmed','busy','not_authorized','asset_access_denied','connection_paused','revision_conflict','not_configured'],true))throw $e;
                $v=$r['value'];$v['state']='failed';$v['last_code']=$e->reason;
                Store::put('history_export',$id,$v,$r['revision'],$v['expires_at']);return self::receipt($id,$v);
            }
            Connections::revalidate($c);Access::checkPrincipal($v['principal']);
            // The immutable part carries its checkpoint. If either write is uncertain, the
            // receipt stays queued or has advanced; retrying the same export reconciles it.
            Store::put('history_export_part',$partKey,['content'=>$content,'sha256'=>hash('sha256',$content),'checkpoint'=>$v],0,$v['expires_at']);
            Store::put('history_export',$id,$v,$r['revision'],$v['expires_at']);return self::receipt($id,$v);
        });
    }
    public static function read(array $i): array {
        [$r,$c]=self::get($i['export_id']);$v=$r['value'];if($v['state']!=='complete')throw new Fault('incomplete_collection','A exportação ainda não está completa.');$part=$i['part']??0;$row=Store::get('history_export_part',$i['export_id'].':'.str_pad((string)$part,6,'0',STR_PAD_LEFT));if(!$row)throw new Fault('result_unavailable','Parte ausente.');$content=$row['value']['content'];$at=$i['offset_bytes']??0;$limit=$i['byte_limit']??196608;if($at>strlen($content))throw new Fault('invalid_input','Offset inválido.');$chunk=substr($content,$at,$limit);
        Connections::revalidate($c);Access::checkPrincipal($v['principal']);
        return self::receipt($i['export_id'],$v)+['part'=>$part,'part_sha256'=>$row['value']['sha256'],'offset_bytes'=>$at,'content_base64'=>base64_encode($chunk),'next_offset'=>$at+strlen($chunk)<strlen($content)?$at+strlen($chunk):null,'next_part'=>$part+1<$v['parts']?$part+1:null];
    }
}
