<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Public diagnostics contain technical vocabulary, never arbitrary supplier prose. */
final class ProviderDiagnostic {
    private const WORDS='a an the this that these those and or with without for from to on in of by at is are was were be been being not no does do did can cannot could must may only please try again use using used requires require required permission permissions missing invalid parameter parameters param value values field fields nonexisting existing unknown unsupported request requests get post object objects node type method operation operations supported support access token tokens validating validation session expired expire expiration error errors occurred has have had been due loaded load exist exists read write api graph documentation endpoint path components invalidated revoked authorized authorization authentication insufficient unavailable temporarily service internal server failure failed timeout limit limits exceeded rate calls reached too many user application app business management account accounts ad ads pixel pixels dataset datasets event events source sources stats aggregation start end time date range window days day hours hour data quality match composite score coverage percentage identifier web server_only web_only event_total_counts event_source event_name start_time end_time event_match_quality composite_score match_key_feedback adspixel adsstatistics adaccount id account_id dataset_id adspixels adaccounts adsets promoted_object effective_status ads_read ads_management business_management web event_total_counts event cannot retrieve retrieving results retry later supplied provided valid format one allowed enum argument arguments parameter should int integer string array list maximum minimum between less greater than equal since until fields permissions permission denied unsupportedgetrequest o a de do da no na os as dos das para com sem e ou não acesso token permissão permissões parâmetro parâmetros campo campos inválido inválida operação indisponível expirado expirou erro redigido http oauthexception graphmethodexception facebookapiexception exception invalidparameterexception';

    public static function message($value,array $secrets=[]): array {
        if(!is_string($value)||$value==='')return [null,false];
        $original=$value;$value=html_entity_decode(strip_tags(wp_check_invalid_utf8($value,true)),ENT_QUOTES|ENT_HTML5,'UTF-8');
        foreach($secrets as $secret)if(is_string($secret)&&$secret!=='')$value=str_replace([$secret,rawurlencode($secret),urlencode($secret)],'[redigido]',$value);
        $value=preg_replace('~https?://[^\s<>]+|[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}|\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b~iu','[redigido]',$value)??'';
        // Every unrecognised word/identifier/number is removed, including names without quotes.
        $allowed=array_fill_keys(explode(' ',self::WORDS),true);
        $value=preg_replace_callback('/[\p{L}\p{N}_@.\-]+/u',static fn($m)=>isset($allowed[strtolower($m[0])])?$m[0]:'[redigido]',$value)??'';
        $value=preg_replace('/[^\p{L}\p{N}\s_.,:;()\[\]{}\/#=!?+\-]/u',' ',$value)??'';
        $value=preg_replace('/(?:\[redigido\][\s,]*){2,}/','[redigido] ',$value)??'';
        $value=trim(preg_replace('/\s+/u',' ',$value)??'');
        if(strlen($value)>512)$value=wp_check_invalid_utf8(substr($value,0,500),true).' [redigido]';
        return [$value!==''?$value:'[redigido]',$value!==$original];
    }
    private static function secrets(array $v): array {
        $out=[];foreach($v as $k=>$x){if(is_array($x))$out=array_merge($out,self::secrets($x));elseif(is_string($x)&&preg_match('/token|secret|password/i',(string)$k))$out[]=$x;}return $out;
    }
    public static function from($data,int $http,array $context=[]): array {
        $e=is_array($data)&&is_array($data['error']??null)?$data['error']:[];$secrets=self::secrets($context);
        [$message,$redacted]=self::message($e['message']??null,$secrets);[$userMessage,$userRedacted]=self::message($e['error_user_msg']??null,$secrets);
        $number=static fn($v)=>is_int($v)&&$v>=0?$v:null;
        $trace=$e['fbtrace_id']??null;if(!is_string($trace)||!preg_match('/^[A-Za-z0-9_\-]{1,128}$/D',$trace)||in_array($trace,$secrets,true))$trace=null;
        $type=$e['type']??null;if(!in_array($type,['OAuthException','GraphMethodException','FacebookApiException','InvalidParameterException','Exception'],true))$type=null;
        return ['http_status'=>$http,'provider_code'=>$number($e['code']??null),'provider_subcode'=>$number($e['error_subcode']??null),'provider_is_transient'=>is_bool($e['is_transient']??null)?$e['is_transient']:null,'provider_rule'=>InsightDiagnostics::providerRule($e),
            'provider_message'=>$message,'provider_error_user_msg'=>$userMessage,'provider_message_redacted'=>$redacted||$userRedacted,'provider_type'=>$type,'fbtrace_id'=>$trace];
    }
    public static function call(array $c,string $path,array $q=[]): array {
        $stage='other';$route='/{resource}';
        if(preg_match('~^act_[0-9]+/adspixels$~D',$path)){$stage='dataset_binding';$route='/act_{account_id}/adspixels';}
        elseif(preg_match('~^[0-9]+/adaccounts$~D',$path)){$stage='dataset_binding';$route='/{dataset_id}/adaccounts';}
        elseif(preg_match('~^[0-9]+/stats$~D',$path)){$stage=($q['event_source']??'')==='WEB_ONLY'?'stats_browser':((($q['event_source']??'')==='SERVER_ONLY')?'stats_server':'stats');$route='/{dataset_id}/stats';}
        elseif($path==='dataset_quality'){$stage='emq';$route='/dataset_quality';}
        elseif(preg_match('~^act_[0-9]+/adsets$~D',$path)){$stage='optimization';$route='/act_{account_id}/adsets';}
        elseif(preg_match('~^act_[0-9]+$~D',$path)){$stage='ad_account';$route='/act_{account_id}';}
        elseif($path==='me'){$stage='connection_validation';$route='/me';}
        $call='GET '.$route;
        if(in_array($q['event_source']??null,['WEB_ONLY','SERVER_ONLY'],true))$call.='; event_source='.$q['event_source'];
        if(in_array($q['aggregation']??null,['event','event_total_counts'],true))$call.='; aggregation='.$q['aggregation'];
        return ['provider_call'=>$call,'request_stage'=>$stage,'provider_api_version'=>preg_match('/^v[0-9]{1,2}\.[0-9]{1,2}$/D',$c['api_version']??'')?$c['api_version']:null];
    }
    /** Re-project already sanitised diagnostics before durable/public propagation. */
    public static function project(array $d): array {
        $out=[];foreach(['provider_message','provider_error_user_msg'] as $k)if(array_key_exists($k,$d))$out[$k]=self::message($d[$k])[0];
        if(is_bool($d['provider_message_redacted']??null))$out['provider_message_redacted']=$d['provider_message_redacted'];
        foreach(['provider_type'=>'/^(?:OAuthException|GraphMethodException|FacebookApiException|InvalidParameterException|Exception)$/D','fbtrace_id'=>'/^[A-Za-z0-9_\-]{1,128}$/D','request_stage'=>'/^(?:other|dataset_binding|stats_browser|stats_server|stats|emq|optimization|ad_account|connection_validation)$/D','provider_api_version'=>'/^v[0-9]{1,2}\.[0-9]{1,2}$/D'] as $k=>$pattern)if(is_string($d[$k]??null)&&preg_match($pattern,$d[$k]))$out[$k]=$d[$k];
        if(is_string($d['provider_call']??null)&&preg_match('~^GET /(?:\{resource\}|me|act_\{account_id\}(?:/(?:adspixels|adsets))?|\{dataset_id\}/(?:stats|adaccounts)|dataset_quality)(?:; event_source=(?:WEB_ONLY|SERVER_ONLY))?(?:; aggregation=(?:event|event_total_counts))?$~D',$d['provider_call']))$out['provider_call']=$d['provider_call'];
        return $out;
    }
    public static function action(array $d): string {
        if(in_array($d['provider_code']??null,[190,102],true))return 'A origem recusou o token nesta chamada. Valide a conexão e renove a credencial quando a validação confirmar a recusa.';
        if(in_array($d['provider_code']??null,[10,200],true)||($d['http_status']??null)===403)return 'A origem recusou acesso nesta chamada. Confira o acesso do usuário ao dataset (Usar conjunto de dados de eventos), sua atribuição ao negócio/conta e os escopos ads_read e ads_management ou business_management. Não altere a seleção automaticamente.';
        if(($d['request_stage']??'')==='dataset_binding')return 'Confirme que o dataset aparece em meta/list-accounts (channel=dataset) na conta selecionada, com a mesma credencial. A relação deve ser confirmada antes da coleta.';
        if(($d['provider_code']??null)===100)return 'O código 100 não identifica sozinho a causa. Confira provider_message, provider_call e a versão da API; verifique o parâmetro recusado e a atribuição do dataset usando a mesma credencial.';
        return 'Consulte a chamada e o diagnóstico medidos. Preserve a cobertura parcial e repita a coleta após resolver a causa; ausência de dados não equivale a zero.';
    }
}
