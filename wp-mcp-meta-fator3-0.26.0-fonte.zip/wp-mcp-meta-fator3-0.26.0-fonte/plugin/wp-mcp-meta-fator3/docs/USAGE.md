# Uso

Este documento traz as sequências completas de trabalho. Cada passo indica a operação `meta/…`, o que enviar e o que conferir na resposta. Os parâmetros completos de cada operação estão em REFERENCE.md e input-schemas.json. Respostas reais de sucesso, vazio, erro e resultado parcial estão em EXAMPLES.md.

No painel, as sequências 1 a 3 correspondem à faixa **Primeiros passos** da aba Conexão (ADMINISTRATION.md). Os valores abaixo (`conexao-exemplo`, `111`, `222`) são sintéticos.

## Antes de começar

- Use um usuário com `manage_options`. Pelo MCP, o perfil de transporte também precisa autorizar a operação; perfis de leitura não permitem operações de escrita.
- Toda resposta tem o envelope descrito em CONTRACTS.md. Confira `success` e `code` antes de usar `data`.
- Operações que gravam pedem `expected_revision` ou `idempotency_key`. Leia antes de gravar e guarde o recibo.

## Sequência 1 — Primeira conexão

1. **Conferir o ambiente.** `meta/health` com `{}`. Confira `storage_ready=true` e `crypto_ready=true`. Sem conexões, `state` costuma ser `ok`.
2. **Ver os campos.** `meta/configuration-schema` com `{}`. Confira o schema de `save-connection`.
3. **Gravar.** `meta/save-connection` com `connection_id`, `expected_revision=0`, `label`, `client_id`, `client_secret` e `token`. Confira `persisted=true`, a revisão nova e `connection.identity`. Leia os `avisos`, se houver.
4. **Reler.** `meta/get-connection` com `connection_id`. Confira nome, validade, escopos e que nenhum segredo aparece.

Se a gravação falhar, nada foi persistido; corrija a causa indicada em `code` (CONTRACTS.md) e repita com a mesma revisão. CONFIGURATION.md explica cada campo e a conferência na Meta.

## Sequência 2 — Seleção de ativos

1. **Descobrir.** `meta/list-accounts` com `connection_id` e `channel` (`instagram`, `facebook`, `ads` ou `dataset`). Para `dataset`, envie também `ads_account_id` de uma conta de anúncios já selecionada. Continue por `cursor` enquanto houver continuação.
2. **Escolher.** Monte as listas de IDs desejados por canal. A descoberta não autoriza nada.
3. **Gravar a seleção.** `meta/save-connection` com `connection_id`, a revisão atual e `assets` completo, por exemplo `{"instagram":["111"],"facebook":["222"]}`. Cada canal enviado substitui a lista salva daquele canal; canais omitidos preservam a seleção atual. Para retirar todos os ativos de um canal, envie a lista vazia.
4. **Validar.** `meta/validate-connection` com `connection_id`, `channel` e `account_id`, um ativo por chamada. Para Páginas, confira `proof.page_permissions` (PAGE-DIAGNOSTICS.md).

## Sequência 3 — Primeira consulta

1. **Ver os campos do relatório.** `meta/list-fields` com `report` (e, opcionalmente, `connection_id`, `channel`, `api_version`). Confira campos, períodos e disponibilidade condicional.
2. **Consultar uma página.** `meta/query` com `connection_id`, `channel`, `account_id`, `report` e, quando o relatório pedir, `date_from`, `date_to`, `fields` e `limit`. Exemplo: `{"connection_id":"conexao-exemplo","channel":"instagram","account_id":"111","report":"account_insights","granularity":"day","fields":["reach"],"date_from":"2026-01-01","date_to":"2026-01-07"}`.
3. **Conferir a resposta.** Leia `rows` e `coverage`. `coverage.complete=true` exige fim do plano sem indisponibilidade registrada. Valores ausentes ficam `null` com diagnóstico, nunca zero.
4. **Continuar.** Se houver `next_cursor`, repita a mesma seleção com `cursor`. Não altere a seleção no meio da continuação.

Uma consulta não grava histórico nem cria agenda. Para guardar os dados, use a sequência 4.

## Sequência 4 — Coleta e agenda

1. **Criar a coleta.** `meta/create-job` com `query` (a mesma seleção da consulta) e `idempotency_key`. Opcional: `max_pages` (1 a 10.000). Guarde o `job_id`. Repetir a mesma chave com a mesma seleção devolve a mesma coleta; com outra seleção, `idempotency_conflict`.
2. **Avançar.** `meta/run-job` com `job_id` executa uma página e grava o resultado. O cron também avança as coletas sozinho. Acompanhe com `meta/job-status`.
3. **Controlar.** `meta/control-job` com `job_id`, `expected_revision` e `action` (`pause`, `resume`, `cancel`). Resultados já gravados são preservados.
4. **Ler.** `meta/job-results` com `job_id` e `page`. Confira `successful_rows`, `unavailable_metrics` e `outcome` no estado da coleta.
5. **Agendar.** `meta/save-schedule` com `schedule_id`, `expected_revision` (`0` para criar), `query`, `enabled`, `interval_minutes` (60 a 43.200) e, opcionalmente, `label`, `next_at` (Unix UTC) e `lookback_days` (1 a 30). Sem `next_at`, a agenda nova começa em 60 segundos e a existente preserva o horário.
6. **Conferir.** `meta/list-schedules` mostra habilitação, próxima execução, último resultado e orçamento de cada agenda.

Uma coleta tem no máximo 10.000 páginas; se o limite for atingido com continuação pendente, ela termina parcial, nunca completa. Cada página é gravada antes de o checkpoint avançar, o que permite retomar depois de interrupção.

Agendas bloqueadas mantêm a habilitação, registram `last_code` e tentam de novo após cinco minutos. A renovação validada do token preserva as agendas. Depois de uma troca validada, cursores de inventário remoto recomeçam; o histórico deduplica, mas a exportação bruta da coleta pode conter observações repetidas da retomada. Mudança de autorização exige salvar a agenda de novo com a revisão atual.

Para cargas do passado, use `meta/create-backfill` com `query.date_from` obrigatório; `date_to` vai no máximo até ontem (no fuso da conta para Ads e datasets). A disponibilidade do passado depende da Meta: um período vazio não comprova cobertura integral. WORKER.md explica a execução pelo cron; COLLECTION-DIAGNOSTICS.md, o resultado parcial.

## Sequência 5 — Histórico e exportação

1. **Conferir o histórico.** `meta/history-status` com `{}`. Confira `rows` e `migration.complete`. Se houver resultados antigos ainda não migrados, `meta/history-migrate` avança um lote; a manutenção horária faz o mesmo.
2. **Consultar.** `meta/history-query` com `connection_id`, `channel`, `account_id` e, opcionalmente, `report`, `date_from`, `date_to`, `limit` e `cursor`. Para Ads, `ads_level`; para datasets, `ads_account_id`. A leitura não usa o token, mas exige autorização atual e ativo selecionado.
3. **Exportar.** `meta/history-export` com `query` (a mesma da consulta), `format` (`csv` ou `json`) e `idempotency_key`. Guarde o `export_id`.
4. **Processar.** Repita `meta/history-export-step` com `export_id` até `state=complete`.
5. **Baixar.** `meta/history-export-read` com `export_id`, `part` e `offset_bytes`. Concatene as partes decodificadas em ordem, sem separador, e confira o SHA-256 de cada parte.

O histórico é independente da retenção das coletas. Cada linha é identificada por principal, conexão, canal, conta, relatório, entidade, métrica, dia, temporalidade, versão da API, `timeframe` e detalhamento. Observações repetidas atualizam a mesma linha, com `first_seen` e `last_seen`; guarda-se o último valor observado de cada dia, não cada observação do dia.

A exportação do histórico tem até 64 MiB, não tem URL pública e não expira. O CSV mantém `row_json` e `coverage_json` para não perder estruturas e neutraliza fórmulas. A exportação de uma coleta vai até 8 MiB de dados.

Se o histórico mudar durante a leitura, a continuação recusa com `history_changed`: recomece sem cursor.

Se uma etapa da exportação não confirmar a gravação (`persistence_unconfirmed` ou `storage_unavailable`), guarde o `export_id` e não troque de chave. Depois de restabelecer o banco, repita `meta/history-export-step` com o mesmo ID: se a parte já foi gravada, a exportação continua da seguinte; se não, tenta a que falta. Se o estado ficar `failed` por `history_changed`, inicie nova exportação com nova chave. Só baixe com `state=complete`. A exportação de uma coleta específica usa `meta/export` e `meta/export-read`; resultado parcial exige `allow_partial=true`.

## Sequência 6 — Diagnóstico

1. **Observar.** `meta/health` com `{}`. Confira `state`, `issues[]` (com `code` e `action`), `queue`, `cron`, `schedules` e `budgets`. Não altera nada.
2. **Testar o local.** `meta/selftest` com `{}`. Confere armazenamento, cifra, cursores, lista de endpoints e schemas, sem chamar a Meta.
3. **Recuperar o agendamento.** Só se `issues` trouxer `worker_missing`: `meta/status` com `{}`. Confira `recovery.attempted` e `cron.next`.
4. **Investigar uma conta.** `meta/validate-connection` para o ativo, e `meta/job-status` ou `meta/list-schedules` para o último erro.
5. **Auditar.** `meta/audit` com `since` (Unix) e `offset`. A lista vem do mais recente para o mais antigo.

TROUBLESHOOTING.md associa sintomas a causas; WORKER.md descreve cada código de `issues`.

## Relatórios disponíveis

| Canal | Relatórios |
|---|---|
| `instagram` | `profile`, `media`, `stories`, `account_insights`, `media_insights`, `audience`, `stories_insights` |
| `facebook` | `page_profile`, `page_insights`, `page_posts`, `post_insights`, `page_videos`, `video_insights`, `page_audience`, `page_ratings` |
| `ads` | `ads_insights` (META-ADS.md), `ads_activity` (MONITORING.md) |
| `dataset` | `dataset_quality` (MONITORING.md) |

Regras de consulta:

- `account_insights` e `page_insights` aceitam `granularity=day` ou `interval`. Com `day`, cada dia é consultado com limites UTC explícitos e as métricas compatíveis são agrupadas. Valores únicos não são somados, totais de intervalo não são divididos entre dias e acumulados de mídia não são distribuídos para trás.
- `media_insights` exige `media_id` ou `iterate_media=true`. `post_insights` e `video_insights` exigem `entity_id` e pertencem ao canal `facebook`.
- `stories_insights` percorre os Stories ativos e lê as métricas de cada um (STORY-ARCHIVE.md).
- `timeframe` só vale para métricas demográficas compatíveis; combinações recusadas localmente retornam `unsupported_timeframe` antes de chamar a Meta. Exemplo observado na v24.0: `engaged_audience_demographics` aceita só `this_month` e `this_week`.
- Latência, erros de grupo e quota podem exigir continuações adicionais; nenhum limite trunca linhas silenciosamente.
- O catálogo é fechado: campo fora dele retorna `unsupported_field`. Métricas marcadas como dependentes de validação remota precisam ser aceitas pela Meta para o ativo.
- Datas usam o formato `AAAA-MM-DD`, em dias UTC para os relatórios orgânicos e no fuso da conta para Ads e datasets.
