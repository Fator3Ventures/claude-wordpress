# SDK de Meta Ads: histórico e anúncio de origem

O contrato `meta-ads-reader/1.0.0` permite que outro plugin do mesmo site leia o acervo local de Meta Ads, sem Graph API e sem token. O consumidor mantém sua própria seleção, regras comerciais, associação de campanhas a parceiros e contatos, e deduplicação. Ele não deve ler tabelas ou opções privadas do Meta nem chamar o MCP para ler o próprio site. Ter o leitor disponível não autoriza nenhum consumidor.

## Registro

Registre o consumidor no gancho abaixo e guarde o objeto devolvido. Esse objeto é o cliente registrado; um cliente fabricado de outra forma é recusado. Cada ID só pode ser registrado uma vez por processo.

```php
add_action('f3_meta_register_ads_consumers', static function ($sdk, $contract) {
    if ($contract !== 'meta-ads-reader/1.0.0') return;
    MeuConsumidor::$metaAds = $sdk::register_consumer(
        'meu-consumidor', '1.0.0', $contract,
        static fn() => MeuConsumidor::configuracaoMetaAds(),
        'Meu consumidor de anúncios'
    );
}, 10, 2);
```

O callback de configuração devolve `{connection_id, account_id, revision, ready:true}`; `revision` tem até 128 caracteres e só muda quando a configuração muda. O callback não deve fazer HTTP nem alterar estado. Enquanto a configuração estiver incompleta, devolva `ready=false`.

## Concessão

O administrador autoriza em **Ferramentas → Fator3 MCP Meta → Consumidores de anúncios**, ou pelas operações:

| Operação | Uso |
|---|---|
| `meta/ads-consumers` | Lista consumidores registrados e concessões |
| `meta/get-ads-grant` | Lê `revision` e `enabled` para `consumer_id`, `connection_id` e `account_id` |
| `meta/save-ads-grant` | Grava `enabled` com `expected_revision` (`0` ao criar) |

Para conceder também a consulta por ID, envie enabled=true e allow_ad_origin=true na mesma operação local. Para desligá-la mantendo o histórico, envie enabled=true e allow_ad_origin=false. enabled=false revoga tudo. Sem o campo adicional, uma concessão nova nunca habilita a consulta remota.

Não presuma a revisão: leia antes de gravar. É possível revogar mesmo depois que o consumidor ou a conexão foram removidos. Pelo MCP, gravar exige perfil de escrita. Uma recusa da política remota nunca vira sessão administrativa local.

## Leitura

- `$client->status(['connection_id'=>…, 'account_id'=>…])` informa `ready`, as versões da concessão, da autorização e da configuração, e o contrato.
- `$client->query([...])` aceita só `connection_id`, `account_id`, `ads_level` opcional, `date_from` e `date_to` juntas, `limit` (1 a 100, padrão 100) e `cursor`. Não aceita conexão ou conta diferente da configuração registrada.

A resposta usa o envelope do Meta (`success`, `code`, `provider`, `version`, `data`); falhas têm `data` nulo e código e mensagem sanitizados. Trate o envelope antes de usar as linhas.

`data` contém `contract`, `rows`, `next_cursor`, `generation`, `retention` e `grant_revision`. Cada linha traz `row_id`, `row`, `data_day`, `first_seen`, `last_seen`, `observations`, fuso, moeda, `selection` e `coverage`. Os campos de cada linha estão em META-ADS.md. O cursor inclui identidade do consumidor, revisões da concessão e da configuração, autorização da conexão e geração do acervo. `history_changed` ou `revision_conflict` exigem recomeçar a leitura, sem juntar conjuntos de gerações diferentes.

## Condições

- A origem administrativa da concessão precisa continuar existindo, com `manage_options`. A rotação da credencial MCP usada na configuração não encerra a concessão do consumidor.
- A conexão precisa estar ativa e a conta, selecionada. Mudança de identidade ou de ativos exige revisão da concessão.
- Token vencido não impede leitura local concedida.
- O cliente registrado e concedido pode operar no cron sem usuário na sessão; o SDK revalida origem, concessão e configuração antes e depois de ler.
- Revogar e reautorizar não revive cursores antigos.
- Leituras e falhas geram auditoria local, sem dados de anúncios nem credenciais.

## Erros

`consumer_unavailable`, `consumer_not_ready`, `contract_mismatch`, `consumer_conflict`, `consumer_scope_mismatch`, `grant_revoked`, `not_authorized`, `asset_access_denied`, `connection_paused`, `revision_conflict`, `history_changed`, `invalid_input`, `invalid_cursor`, `cursor_expired`, `storage_unavailable` e `response_limit`. Erro ou ausência nunca é zero. SDK-PHP.md resume o significado dos códigos de consumidor.

## Integração com o Site Core

Na integração observada, o Site Core registra-se como `base-site-core-fator3`, guarda sua seleção na própria configuração e exige revisão e concessão explícita no Meta. Instalar os dois plugins não concede acesso. Confira o consumidor presente no site com `meta/ads-consumers`; a configuração do lado do Core está na documentação do Core instalado.

## Anúncio de origem por ID

Para obter o anúncio ligado a um lead ou ao parâmetro de campanha, o consumidor registrado chama a extensão **meta-ad-origin/1.0.0**. Em **Configurar → Consumidores de anúncios**, autorize o histórico da conta, confira o nome do consumidor e selecione **Autorizar consulta por ID**. O titular do token deve ter acesso à conta e à mídia; o token deve estar válido e verificado com ads_read. A autorização do histórico não habilita a extensão por si só.

    $r = $client->ad_origin(['connection_id' => $conexao, 'account_id' => $conta, 'ad_id' => $anuncio]);
    if ($r['success']) { $origem = $r['data']; }

Os IDs são strings decimais; a conta não leva o prefixo act_. A consulta aceita exatamente as três chaves. Parte da conta concedida e confere a identidade do anúncio. Usa apenas GET; não cria campanhas, não lê o contato e não altera anúncios. O consumidor faz uma chamada PHP; a integração pode fazer leituras auxiliares de mídia e da publicação vinculada. As operações status e query continuam locais. Consulte a disponibilidade em meta/capabilities → local_sdk → extensions → ad_origin e o estado concedido em status → data → allow_ad_origin.

| Campo da resposta | Significado |
|---|---|
| account_id; ad, adset, campaign | Conta e pares id/name do anúncio, conjunto e campanha |
| creative.id, primary_text, title, description, button, destination | ID do criativo, texto principal, título, descrição, tipo de botão e destino |
| creative.media_type; image; video_id; thumbnail; playback | Formato, imagem, ID do vídeo, miniatura e endereço de reprodução. Os endereços ficam em url, dentro do respectivo objeto |
| creative.effective_object_story_id; instagram_permalink_url | Identidade da publicação e link do Instagram, quando disponíveis |
| creative.cards, variants e media_variants | Cartões na ordem original, alternativas de texto/destino e de mídia. Não inferir qual combinação uma pessoa viu |
| ads_manager_url; fetched_at; notices | Link direto no Gerenciador, instante UTC da leitura e limitações de obtenção |

Os campos diretos image_url, thumbnail_url e playback_url estão presentes no criativo, nos cartões e nas variantes; são null quando não há URL aplicável. Os objetos image, thumbnail e playback descrevem cada endereço e têm url, expires_at e expiry_source. O parâmetro oe de um endereço assinado fornece um indício de vencimento (cdn_oe_hint); sem esse valor, expires_at é null e expiry_source é unknown. O fornecedor pode invalidar o endereço antes. Consulte o anúncio novamente se o download falhar. Nenhum endereço é renovado em segundo plano. O Meta não arquiva cópia da mídia nessa consulta; o histórico existente mantém sua própria política. Campos ausentes são null e listas ausentes são vazias. Uma imagem de miniatura não confirma a disponibilidade do vídeo original.

A chamada limita leituras de vídeo a quatro e listas de variantes a 50 por tipo; notices indica cortes e falhas de enriquecimento. ad_origin_not_granted pede autorização pelo administrador; grant_revoked, revision_conflict ou consumer_scope_mismatch exigem revisar a configuração; resource_not_found indica que o anúncio não foi localizado nessa conta. token_rejected ou ads_read_required exigem revisão da credencial. Para rate_limited, respeite retry_after. Conserve o ID recebido mesmo quando a leitura falhar.

### Como interpretar uma leitura parcial no Core

No Core 1.81.1, abra a ficha do contato e use **Consultar anúncio na plataforma**. Confira a conta, o ID do anúncio, os textos disponíveis e a mídia exibida. Se a imagem identificada não vier com endereço utilizável, o SDK informa `image_url_unavailable`. Para vídeo com ID mas sem endereço de reprodução ou miniatura, informa `video_playback_unavailable` ou `video_thumbnail_unavailable`. O Core mostra a consulta como parcial e mantém os campos recebidos. Ausência de título ou descrição opcional não gera esse aviso.

O SDK descarta URLs com indício de vencimento já atingido e tenta resolver a imagem pelo hash na mesma conta. Sem vencimento conhecido, a URL pode ser aceita, mas só o download confirma a disponibilidade. Uma variante identificada como outro vídeo ou outra imagem não completa a mídia do criativo principal. Quando apropriado, o Core pode exibir a imagem como referência da variante. Fotos com legenda nativa usam essa legenda como texto quando a mensagem e o corpo estão ausentes.

Referência dos campos: https://github.com/meta/facebook-python-business-sdk/blob/main/facebook_business/adobjects/adcreative.py
