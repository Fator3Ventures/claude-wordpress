# Visualizações do perfil da Página

O relatório `page_insights` aceita a métrica `page_views_total`, inclusive em série diária. Exemplo sintético:

```json
{"connection_id":"conexao-exemplo","channel":"facebook","account_id":"222","report":"page_insights","date_from":"2026-01-05","date_to":"2026-01-11","granularity":"day","fields":["page_views_total"]}
```

No painel, escolha esses valores pelos seletores e datas da aba Relatórios.

## Como é consultada

A Graph API recebe `metric=page_views_total`, `period=day` e uma janela por dia. A versão da API da conexão acompanha a resposta.

- Zero devolvido pela Meta é conservado.
- Ausência ou recusa produzem valor `null` e cobertura incompleta, com diagnóstico sanitizado e código e subcódigo da Meta quando existem.
- Não há substituição por `page_media_view` nem equivalência com visualizações de mídia.

## Limites

O catálogo marca a métrica com `requires_remote_validation` e disponibilidade condicional. Ela precisa ser aceita pela Meta para o ativo e a credencial da consulta. Uma validação feita em outra Página não comprova disponibilidade em qualquer Página ou versão da API. Conexões novas precisam conferir identidade, permissões e a resposta efetiva (PAGE-DIAGNOSTICS.md).
