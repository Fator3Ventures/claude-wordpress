# Eliminação local de mensagens

O contrato PHP `instagram-message-erasure/1.0.0`, no SDK `Fator3\Meta\Messaging`, permite eliminar os dados locais de um remetente do Instagram e bloquear sua reimportação. Não há operação MCP nem endpoint para isso: o consumidor local (normalmente o Site Core) aplica sua política e protege a entrada administrativa antes de chamar o SDK. O schema gerado está em messaging-privacy-schema.json.

## Autorização e alvo

Exige `manage_options` atual. Com contexto MCP, confere também a concessão do transporte; revogar essa concessão não equivale a revogar o token da Meta. A eliminação não exige token válido, recepção ativa, ativo selecionado, conexão existente, consumidor registrado nem chamada à Meta. Um administrador pode apagar o dado local mesmo depois de remover a conexão.

O alvo é `connection_id`, `account_id` e exatamente um entre `sender_id` e `event_id`. O `event_id` publicado na ingestão identifica o remetente no escopo da conexão e da conta; não é o `message_id` da Meta nem o `record_id` do contato. O diário tem um registro por esse escopo, e a eliminação remove o registro inteiro, com `sender_id`, `message_id`, referências de origem, datas e `record_id`. Alvo de outra conta ou conexão é recusado. Para alvo ainda ausente, o plugin grava um bloqueio preventivo.

## Métodos

- `privacyContract()` devolve schema e metadados do contrato.
- `privacyStatus($target)` é leitura local: estado, presença de identificadores, bloqueio de reimportação e `revision` opaca de 64 caracteres (diferente da revisão inteira de `deliveryReceipt`).
- `eraseLocalData($request)` executa a eliminação.
- `erasureReceipt($idempotencyKey)` consulta o recibo histórico.

Erros são `Fator3\Meta\Fault`, com `reason` sem dados pessoais.

```php
$sdk = \Fator3\Meta\Messaging::class;
$contract = $sdk::privacyContract();
if ($contract['contract'] !== 'instagram-message-erasure/1.0.0') {
    throw new \RuntimeException('Contrato de eliminação incompatível');
}
$target = [
    'connection_id' => $connectionId,
    'account_id' => $accountId,
    'event_id' => $eventId, // ou sender_id, nunca os dois
];
$state = $sdk::privacyStatus($target);
// Guarde a chave antes da chamada; não inclua dados do titular nela.
$request = $target + [
    'expected_revision' => $state['revision'],
    'idempotency_key' => $stableRequestId,
];
$receipt = $sdk::eraseLocalData($request);
$confirmed = $sdk::erasureReceipt($stableRequestId);
```

O consumidor deve capturar o alvo antes de apagar seus próprios dados, confirmar sua própria transação e só então chamar o Meta. Chamar durante uma transação SQL ativa é recusado com `transaction_active`; o plugin não confirma nem desfaz a transação do consumidor. Um coordenador pode guardar o alvo cifrado só enquanto necessário e apagá-lo depois de conferir o recibo. Cópias externas não são eliminadas.

## Concorrência, repetição e falhas

A mesma trava protege recepção, entrega e eliminação. Primeiro é gravado o bloqueio durável; depois são removidas as continuações de cron da conta e o registro pessoal. Uma geração de privacidade impede o worker de agendar continuação calculada antes da eliminação. A rotina não abre nem confirma transações.

| Situação | Resultado |
|---|---|
| Mesmo pedido, mesma chave, conclusão ainda válida | Mesmo recibo |
| Mesma chave para outro alvo | `idempotency_conflict` |
| Revisão obsoleta | `revision_conflict` |
| Interrupção depois do bloqueio | `erasure_incomplete`: o remetente já está bloqueado, mas a exclusão não é declarada; corrija a causa e repita o mesmo pedido com a mesma chave |
| Recibo anterior diverge do estado atual | `erasure_state_changed`: releia o estado e faça novo pedido com nova chave |

O recibo contém contrato, `receipt_id` opaco, `state=erased`, `local_identifiers_removed=true`, `reimportation_blocked=true`, revisão de conclusão, `completed_at` (Unix) e `external_copies_erased=false`. Não contém conexão, conta, remetente, mensagem, `event_id`, `record_id`, texto ou origem. Ausência de recibo não prova ausência de efeito: não reimporte para testar.

## Bloqueio durável

Os registros `message_suppression`, `message_erasure_receipt` e `message_privacy_scope` ficam na tabela cifrada do plugin, sem prazo. As chaves são HMAC com um segredo aleatório do site, guardado cifrado na opção `f3_meta_message_privacy_key`; os identificadores brutos não são guardados. São pseudônimos de proteção, não anonimização absoluta.

Limpar o diário `message_event` não remove bloqueios. Reinício, revogação do token e remoção ou recriação da mesma conexão não liberam o remetente. Não há desbloqueio automático. Outro `connection_id` ou outra conta é outro escopo: o plugin não tenta identificar a pessoa entre escopos.

Preserve a chave de privacidade, os salts, os bloqueios e os recibos em backups e restaurações. Se a chave não abrir, ou faltar enquanto houver bloqueios, recepção e processamento falham fechados com `privacy_key_unavailable`, sem recriação silenciosa. Remover a chave ou os bloqueios, ou restaurar um backup anterior à eliminação, compromete a garantia. Eliminar do banco ativo não apaga backups externos.

## Alcance

A eliminação explícita prevalece sobre a retenção ilimitada e não muda a retenção das outras funções. Não apaga dados do Core, de CRMs, da Meta, cópias já entregues ou cursores já recebidos. A leitura autorizada de conversas continua consultando a Meta; o bloqueio impede novo armazenamento e nova entrega ao Core. A ausência de dados locais não prova exclusão na Meta nem consentimento.

A detecção de transação ativa depende de `RELEASE SAVEPOINT`, que não confirma nem desfaz trabalho da transação.
