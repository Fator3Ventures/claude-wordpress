# Diagnóstico das coletas

Este guia explica como ler o resultado de uma coleta: parcial ou falha, recusa da conexão ou do recurso, estado das agendas e diagnóstico sanitizado da Meta.

## Resultado parcial

Campos vazios, suprimidos, `null` e recusas específicas de uma métrica são diagnosticados um a um; os dados úteis das outras métricas permanecem. Zero é valor válido. Gravar linhas com `value=null` não conta como sucesso.

| Onde | Campos |
|---|---|
| `coverage` | `successful_rows` (acumulado), `page_successful_rows`, `unavailable_metrics`, `last_error`, `errors[]` (amostra de até 50) |
| Coleta (`meta/job-status`) | `successful_rows`, `unavailable_metrics`, `outcome`, `last_error` |
| Agenda (`meta/list-schedules`) | `last_run_status`, `last_successful_rows`, `unavailable_metrics`, `last_success_at`, `last_partial_at` |

`last_error` da coleta (também em `meta/list-jobs` e `meta/run-job`) é `null` ou o objeto sanitizado da última tentativa abortada; volta a `null` quando uma página é concluída com sucesso. Indisponibilidades por métrica continuam em `errors`.

Uma coleta com lacunas termina com `status=partial`. `outcome=failed` indica que terminou sem nenhuma linha útil. `last_success_at` avança quando linhas úteis são gravadas, inclusive num resultado parcial; `last_partial_at` registra o término parcial. Uma falha global (revogação, quota, transporte) não vira parcial: interrompe ou adia conforme o código. `meta/health` conta `partial_schedules` e `failed_schedules` separadamente; `schedule_partial` não gera e-mail.

## Stories indisponíveis

Uma falha de Story ou de métrica não prova que a conexão perdeu autorização.

- `story_expired`: a Meta recusou um Story publicado há pelo menos 24 horas.
- `story_insights_unavailable`: ausência, supressão ou recusa sem prova de expiração.

Os valores ficam `null`, nunca zero. Esses códigos não geram issue de autorização nem e-mail. Os demais itens e páginas continuam. Se o inventário de Stories for recusado, a coleta atual pausa, a agenda continua ativa e a próxima execução tenta de novo. STORY-ARCHIVE.md trata da supressão por poucos espectadores.

## Conexão recusada ou recurso recusado

Quando a Meta responde `token_rejected` ou `asset_access_denied`, o plugin confere a mesma credencial com um `GET /me?fields=id`:

- Se `/me` também recusar, a coleta termina `not_authorized` com `auth_scope=connection`. A falha é guardada vinculada a `authorization_revision` e `credential_generation`, e todas as agendas da conexão recebem o diagnóstico, inclusive as pausadas. `meta/health` mostra `connection_authorization_failed`.
- Se `/me` aceitar, a falha é do recurso: `asset_access_denied` fica restrito àquela consulta (`schedule_resource_access_failed`) e não bloqueia as outras agendas.
- Se a conferência for inconclusiva, nada é declarado revogado.

Os códigos da operação original e da conferência ficam separados. As recusas locais de administrador ou de concessão continuam como `not_authorized` sem `auth_scope=connection` e não se propagam a outras concessões. A coleta e o worker nunca trocam credenciais nem concedem acesso. Uma coleta da credencial antiga não diagnostica a credencial nova; uma credencial nova aceita torna o diagnóstico antigo obsoleto.

## Estado das agendas

`last_error` guarda a última ocorrência para consulta histórica e permanece depois de uma execução bem-sucedida. Para saber se o erro é atual, leia o conjunto `last_run_status`, `last_code`, `last_success_at`, `last_error_at`, `last_error_superseded` e `last_error_state`, presente em `meta/list-schedules` e em `meta/health` (`schedules[]`).

| Campo | Significado |
| --- | --- |
| `last_error_at` | Unix UTC da observação original; `null` quando ausente |
| `last_error_superseded` | `true` quando o estado comprova que o erro foi superado; `false` não prova, sozinho, erro atual |
| `last_error_state` | `none` (sem diagnóstico), `current` (falha ou parcial atual), `superseded` (erro histórico superado) ou `unknown` (dados insuficientes) |

`complete` com `last_code=null` marca o erro retido como superado, inclusive em agendas antigas e coletas vazias concluídas. Em outros estados sem erro atual, só um `last_success_at` estritamente posterior a `last_error_at` supera o erro. Falha atual, `partial` ou `last_code` preenchido nunca ficam superados por dados parciais úteis. Datas empatadas ou ausentes dão `unknown`; o plugin não corrige datas futuras.

Exemplo sintético de agenda recuperada:

```json
{"schedule_id":"agenda-exemplo","last_run_status":"complete","last_code":null,"last_success_at":1700003600,"last_error":{"code":"budget_exhausted","observed_at":1700000000},"last_error_at":1700000000,"last_error_superseded":true,"last_error_state":"superseded"}
```

Essa classificação é calculada na leitura: não regrava registros, não chama a Meta e não envia e-mail. Um `last_error` retido, sozinho, não gera alerta.

## Diagnóstico sanitizado da Meta

Os erros HTTP guardam, quando válidos: `http_status`, `provider_code`, `provider_subcode`, `provider_is_transient`, `retry_after`, `provider_message`, `provider_error_user_msg`, `provider_message_redacted`, `provider_type`, `fbtrace_id`, `provider_call`, `request_stage`, `provider_api_version` e `diagnostic_action`. Campos que a Meta não informou ficam `null` ou ausentes.

- `provider_call` identifica a rota como modelo, sem IDs, URL ou token.
- `request_stage` distingue `ad_account`, `dataset_binding`, `stats_browser`, `stats_server`, `optimization`, `emq` e `connection_validation`.
- `diagnostic_action` orienta a próxima conferência sem afirmar causa não medida.
- `provider_message_redacted=true` indica que a mensagem foi alterada pela sanitização (SECURITY.md).

Esses campos aparecem em `meta/job-status`, no `last_error` da agenda e na auditoria. Para `dataset_quality`, `last_errors` da agenda guarda até oito diagnósticos distintos da execução, e `meta/health` mostra a mesma projeção em `datasets.diagnostics`.

O código 100 com `request_stage=emq` identifica a chamada recusada, mas não prova falta de permissão. Para código 10 ou 200, ou HTTP 403, confira o acesso “Usar conjunto de dados de eventos”, a atribuição ao negócio e à conta, e `ads_read` com `ads_management` ou `business_management`, usando a mesma credencial. O sucesso de outro conector, com outro usuário ou token, não valida a credencial salva neste plugin.

## Auditoria das coletas

`meta/audit` registra `operation=collection-run` a cada avanço de coleta pelo worker e `schedule-dispatch` quando a agenda falha antes de criar a coleta. Cada evento traz conexão, agenda, coleta, ator de origem, `transport=collection_worker`, código, instante e `last_error` sanitizado. Se a auditoria falhar, `audit_health=failed`.

## Avisos e recuperação

`connection_authorization_failed` gera um aviso por incidente ao `admin_email`, com a causa medida, pedindo renovar o token ou restaurar as permissões do aplicativo. Não é preciso regravar cada agenda. Uma coleta nova bem-sucedida com a mesma geração de credencial resolve a falha da conexão. O worker registra a recuperação antes de avisar e não avisa incidente já resolvido. Um resultado antigo armazenado não conta como prova de recuperação. WORKER.md descreve a deduplicação dos avisos.

Os diagnósticos não comprovam a causa de incidentes passados; só os códigos medidos permitem concluir.
