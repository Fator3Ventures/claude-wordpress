# Guia do painel

Abra **Ferramentas → Fator3 MCP Meta** com uma conta administradora. O painel usa as mesmas operações da REST e do MCP; abaixo, cada ação indica a operação que chama. Cada aba tem endereço próprio (`?page=wp-mcp-meta-fator3&tab=…`) e funciona com Voltar e Avançar do navegador.

## Navegação

A navegação tem dois níveis. No primeiro, os grupos; no segundo, só as abas do grupo ativo.

| Grupo | Abas |
|---|---|
| Configurar | Conexão, Ativos, Consumidores de anúncios |
| Dados | Relatórios, Coletas, Histórico, Conversas, Arquivo de Stories |
| Suporte | Diagnóstico, Ajuda |

As dez abas continuam separadas e com os mesmos endereços. Algumas abas têm subvisões, mostradas uma por vez, para evitar telas longas.

**Mensagem de resultado.** O resultado de cada ação aparece num aviso fixo no topo da área visível, mesmo com a página rolada. Sucesso e erro têm aparência distinta, e o aviso pode ser dispensado. Ele some ao trocar de aba.

**Sessão expirada.** Se a sessão do painel vencer, o aviso diz: “A sessão do painel expirou. Recarregue a página e repita a ação; nada foi gravado por esta tentativa.” Recarregue e repita.

## Conexão

A aba tem duas subvisões: a lista e o editor.

### Lista

É a subvisão padrão quando já existe conexão.

- **Primeiros passos.** A faixa permanece visível até que uma mesma conexão ativa tenha token dentro da validade cadastrada e ativo selecionado. Um dataset exige também uma conta de anúncios. A conferência é local. Use Diagnóstico para verificar o acesso efetivo ao fornecedor. As três etapas são **Conexão**, **Ativos** e **Primeira consulta**. Cada etapa aparece como feita ou pendente e leva à aba correspondente.
- **Cartões de conexão.** Cada conexão mostra nome, selos (**Ativa** ou **Pausada**; **Token salvo** ou **Sem token**; **Identidade conferida** ou **Identidade não conferida**), validade do token e quantidade de ativos por canal.
- **Editar conexão** abre o editor com aquela conexão. **Escolher ativos** abre a aba Ativos com aquela conexão.
- **Nova conexão** abre o editor vazio.
- **Configuração avançada da versão da API**: escolha a conexão, informe a versão da Graph API e use **Salvar versão da API** (`meta/save-connection`). Trocar a versão exige rever coletas e concessões.

### Editor

Abre com **Nova conexão** ou **Editar conexão**, e também quando ainda não há nenhuma conexão. **Voltar à lista** pede confirmação se houver alterações, inclusive um token digitado para renovação. Confirmar descarta o rascunho e esvazia token e chave secreta no navegador. Cancelar conserva os campos. O título indica “Nova conexão” ou a conexão em edição.

| Bloco | Estado inicial | O que fazer |
|---|---|---|
| 1. Identificação e aplicativo | Aberto | Dê um nome reconhecível e informe App ID e App Secret do mesmo aplicativo. **Conexão ativa** fica aqui. |
| 2. Acesso à Meta | Aberto | Informe o token do usuário do sistema e, se houver, a validade em UTC. **Como obter o token e escolher permissões** mostra o caminho na Meta. |
| 3. Retenção dos resultados | Recolhido, com resumo do valor atual | **Sem expiração automática** ou **Prazo em dias** (1 a 3650). |
| 4. Usuários WordPress associados | Recolhido, com resumo do valor atual | Use **Buscar usuário por nome** e **Buscar**; marque os usuários. A associação não dá permissão de administrador. |
| Remover credenciais salvas | Recolhido | Marque o segredo a apagar e salve. |
| Renovar token preservando agendas | Recolhido | Informe o token novo e use **Conferir e renovar token** (`meta/rotate-token`). |

**Salvar conexão** grava com `meta/save-connection`; ao gravar credencial nova, o servidor confere aplicativo, identidade, escopos e ativos antes de persistir. Depois de salvar, a tela volta à lista. A barra de ações indica quando há alterações ainda não salvas. Token e chave salvos não reaparecem; campo em branco preserva o valor salvo. Em conflito de revisão, reabra a conexão antes de repetir.

A busca de usuários é independente do formulário: Enter no campo de busca executa a busca e não salva a conexão, e digitar nele não marca alterações.

Na renovação, confira o nome da conexão de destino. Trocar de conexão limpa o token e a validade digitados e a prévia.

**Troca de identidade.** Se a Meta indicar outra identidade, o painel oferece **Trocar identidade e regravar agendas**. A prévia aparece junto do formulário que a pediu, com identidade, aplicativo, validade, permissões e agendas afetadas. Leia a prévia antes de confirmar; editar a candidata a invalida. A operação é `meta/switch-identity` (CONFIGURATION.md).

## Ativos

1. Escolha a conexão. Para datasets, escolha também a conta de anúncios autorizada. Ao trocar a conta, a lista descarta descobertas anteriores que você não marcou e recomeça a paginação. Os datasets marcados continuam na seleção da conexão, inclusive os que aguardam gravação.
2. Escolha o canal no seletor; ele mostra quantos ativos estão selecionados em cada canal. A tela mostra um canal por vez.
3. Use **Carregar ativos disponíveis** (`meta/admin-options`) e marque os ativos. Trocar de canal não descarta as marcações.
4. Use **Salvar ativos selecionados** uma vez: grava todos os canais (`meta/save-connection`).

Descobrir um ativo não o autoriza. Uma falha ao ler nomes não apaga a seleção salva. Para datasets, autorize antes a conta de anúncios.

## Consumidores de anúncios

Mostra os consumidores locais registrados por outros plugins e suas concessões, por conexão e conta. **Atualizar consumidores e concessões** relê a lista. **Autorizar leitura desta conta** e **Revogar esta concessão** gravam a concessão com a revisão atual (`meta/save-ads-grant`). O bloco **Atividades e qualidade de datasets**, com **Atualizar consumidores de monitoramento**, faz o mesmo para monitoramento (`meta/save-monitoring-grant`). META-ADS-READER.md e CORE-MONITORING.md explicam as regras.

## Relatórios

Escolha conexão, canal, conta e relatório na **Seleção da consulta**; informe período e campos quando exigidos.

| Botão | Efeito |
|---|---|
| **Consultar página** | `meta/query`; não grava histórico nem cria agenda |
| **Próxima página** | Continua a mesma consulta |
| **Coletar todas as páginas** | `meta/create-job`: cria uma coleta persistente |
| **Coletar histórico do período** | `meta/create-backfill`: cria uma carga retroativa |

Resultado parcial conserva os dados disponíveis; ausência não é zero (COLLECTION-DIAGNOSTICS.md).

## Coletas

Duas subvisões:

- **Coletas**: lista as coletas. **Atualizar coletas** relê a lista; **Ver primeira página** mostra os dados no cartão da coleta, sem misturar com a aba Relatórios.
- **Agendas**: **Nova agenda** e **Salvar agenda** criam ou editam uma agenda a partir da consulta selecionada (`meta/save-schedule`). O horário é em UTC e indica quando a agenda fica elegível; a execução depende do cron. Editar uma agenda não muda a consulta: para outra consulta, crie outra agenda.

## Histórico

**Consultar histórico** lê o acervo autorizado (`meta/history-query`). **Baixar CSV** e **Baixar JSON** preparam, processam e baixam a exportação; permaneça na mesma seleção até o download. Em **Manutenção de histórico legado**, **Avançar migração** chama `meta/history-migrate`.

## Conversas

Duas subvisões:

- **Consulta** (padrão): escolha a conta Instagram e use **Consultar conversas** (`meta/conversations`), que lê só metadados.
- **Configuração da recepção**: use **Carregar configuração e permissões** antes de editar; escolha a Página, o token de verificação do webhook e as opções de recepção e de contatos; grave com **Salvar configuração** (`meta/save-messaging-settings`).

Trocar de conta ou sair da aba limpa o formulário não salvo e o token de verificação digitado. INSTAGRAM-MESSAGING.md descreve permissões e efeitos.

## Arquivo de Stories

**Consultar arquivo** lê os metadados e miniaturas já arquivados (`meta/story-archive`). **Criar agenda horária de Stories** cria uma agenda comum, que depois aparece em Coletas. STORY-ARCHIVE.md descreve limites e efeitos.

## Troca de seleção durante uma leitura

Em Relatórios, Histórico, Conversas e Arquivo de Stories, os resultados e o botão de próxima página pertencem à consulta enviada. Ao mudar o recorte ou sair da aba, a tela limpa os resultados e descarta a continuação. Uma resposta que chegar depois da troca não substitui a tela atual. No Histórico, sair da seleção interrompe o avanço e o download da exportação pelo painel; as etapas já gravadas no servidor são preservadas.

## Diagnóstico

O resultado de uma validação pertence à conexão, ao canal e ao ativo escolhidos. Alterar a seleção retira esse resultado; uma resposta atrasada não substitui a da seleção atual. Quando você inicia outra ação de diagnóstico, prevalece a mais recente.

Ao abrir, a aba lê a saúde local (`meta/health`) e mostra um resumo em cartões: estado geral, conexões, agendas ativas, parciais e com falha, e próxima manutenção. Os detalhes ficam recolhidos; cada campo tem rótulo em português, instantes aparecem em data e hora UTC e códigos conhecidos aparecem traduzidos.

As ações ficam separadas pelo efeito:

| Efeito | Ação | Operação |
|---|---|---|
| Somente leitura local | **Executar autoteste local** | `meta/selftest` |
| Altera estado local | **Verificar e recuperar agendamento** | `meta/status` |
| Consulta a Meta | **Validar conta selecionada** | `meta/validate-connection` |

A versão da API é configurada na aba Conexão. TROUBLESHOOTING.md e WORKER.md explicam os códigos exibidos.

## Ajuda

A aba lista os documentos instalados agrupados por tema, com título e resumo. Escolha um documento e use **Ler documento completo**: o texto aparece formatado (títulos, parágrafos, listas, tabelas, blocos de código) e o painel indica quando a leitura está completa. Trocar o documento limpa o texto anterior. A ajuda não exige token e não consulta a Meta.

## Regras gerais

- Alterar credenciais, retenção, concessões ou agendas usa a revisão da configuração. Em persistência incerta, reabra conexão, agenda e auditoria antes de repetir.
- Nenhuma opção do painel publica conteúdo, altera anúncios ou ativa contatos automaticamente.
