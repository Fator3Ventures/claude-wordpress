# Conversas do Instagram

O plugin lê metadados de conversas do Instagram profissional, recebe o webhook de mensagens e pode entregar a primeira mensagem disponível ao consumidor local do Site Core. Ele não envia mensagens e não guarda texto nem anexos. Exige Facebook Login, conta profissional e Página selecionada explicitamente.

## Configuração e aprovação

1. Salve e valide a conexão como administrador. Na aba Ativos, selecione a conta Instagram e a Página vinculada.
2. O responsável pelo aplicativo confere na Meta os produtos de mensagens, o App Review e o acesso avançado a `instagram_manage_messages`. Os escopos usados por este cliente são `instagram_basic`, `instagram_manage_messages` e `pages_manage_metadata`, além dos escopos de descoberta de Páginas e de relatórios. A Meta pode impor outros requisitos ao aplicativo.
3. Na aba Conversas, subvisão **Configuração da recepção**, use **Carregar configuração e permissões** e escolha a Página autorizada. O vínculo entre Página e Instagram é conferido antes de habilitar a recepção.
4. Defina o token de verificação do webhook (16 a 128 caracteres, sem espaços) e habilite a recepção. A chave do aplicativo já salva valida a assinatura HMAC SHA-256. Configure na Meta a URL exibida e os eventos de mensagens; o plugin não cria assinatura remota. Campo de verificação vazio mantém o valor salvo.
5. Confira `meta/messaging-status` e `meta/health`.

A declaração de acesso avançado (`app_review`) é feita pelo administrador; `app_review.verified` fica `false`, porque escopos não comprovam App Review. `scope_missing` lista os escopos ausentes; `scope_unverified` indica prova insuficiente. Sem aprovação e token válidos, a homologação externa fica pendente.

`meta/save-messaging-settings` usa `expected_revision` e seleção por conexão e conta. A configuração guarda a autorização de origem. Mudanças de autorização ou de seleção desligam a recepção até nova gravação explícita; uma renovação validada que conserva a autorização pode continuar. A conexão precisa estar ativa. Recepção e contatos começam desligados. Painel e operações exigem `manage_options`.

## Consulta

Exemplo sintético para `meta/conversations`:

```json
{"connection_id":"conexao-exemplo","account_id":"111","page_id":"222","date_from":"2026-01-01","date_to":"2026-01-26","limit":5}
```

`page_id` pode ser omitido se já estiver salvo. Datas opcionais vêm em par. A operação deriva o token só da Página autorizada, confere vínculo e escopos, consulta conversas com `platform=instagram` e mensagens com `id,created_time,from,to,reply_to`. Não pede texto nem anexos. Nunca segue `paging.next` como URL.

| Limite | Valor |
|---|---|
| Chamadas de paginação por execução | até 10 |
| Mensagens por página remota | até 100 |
| Conversas concluídas por página local | 1 a 10 |
| Validade da continuação | uma hora, vinculada a filtros, conta, principal, revisão de autorização e geração da credencial |

`first_available_message_at` é a mensagem mais antiga **disponível**, depois de esgotar as páginas daquela conversa; conversa incompleta não entra na contagem. `started_per_day_in_page` agrupa por dia UTC só as linhas da página: some todas as páginas da mesma consulta. A API pode omitir pedidos inativos há mais de 30 dias na pasta de solicitações. Não há garantia de histórico integral nem da primeira conversa de toda a vida; não apresente esses números como homologados antes do teste com credencial real.

**Origem comprovada:**

| Evidência | `origin` |
|---|---|
| `message.reply_to.story.id` | `story_reply` |
| Referral com `source=ADS` e `ad_id` | `ad` |
| Referral com `source=SHORTLINK` e `ref` | `ig_me` |
| Outro referral | `referral` |
| Sem evidência | `unknown` |

Ausência nunca vira “espontâneo”. Uma notificação `messaging_referral` de conversa existente não substitui a origem da primeira mensagem. `ref`, `source`, `type` e `ad_id` são preservados em projeção limitada, sem título do anúncio nem URL de mídia.

## Webhook e armazenamento

Rota própria: `GET|POST /wp-json/f3-meta/v1/messaging-webhook/<conexão>/<conta>`.

- `GET` valida o token de verificação e devolve o desafio numérico literalmente.
- `POST` exige `X-Hub-Signature-256` sobre o corpo bruto, no máximo 256 KiB, envelope do Instagram, conta e destinatário selecionados e autorização atual.
- Eco, mensagens de saída, eventos sem mensagem e eventos anteriores à habilitação são ignorados.
- Repetição por remetente, conta e conexão não duplica. Um evento anterior recebido fora de ordem ajusta o candidato enquanto ele não foi entregue; depois da entrega, exige reconciliação e não gera novo contato.

Só metadados mínimos são cifrados no diário `message_event`, sem texto, anexos, cookies ou segredos. O diário não expira e não tem teto de quantidade.

## Entrega ao Site Core

A entrega usa o contrato `instagram-first-message/1.0.0` do SDK `Fator3\Meta\Messaging`. A opção de contatos só pode ser habilitada com consumidor compatível registrado e exige autorização explícita nos dois plugins. Não use o registro manual de contato do Core como substituto automático deste fluxo.

O consumidor registra-se no gancho, antes de `plugins_loaded` com prioridade 20:

```php
add_action('f3_meta_register_messaging_consumers', static function (string $sdk): void {
    $sdk::registerConsumer('site-core', 'instagram-first-message/1.0.0',
        static function (array $event): array {
            // O consumidor revalida sua política, deduplica e persiste contato e recibo
            // na mesma unidade durável, e devolve SOMENTE o recibo real.
            return ConsumidorExemplo::ingest($event);
        }
    );
});
```

`ConsumidorExemplo` é um nome ilustrativo. Há um único consumidor por processo, sem registro automático se o Core não o fornecer.

O callback recebe `contract`, `event_id`, `idempotency_key`, `connection_id`, `account_id`, `sender_id`, `message_id`, `first_available_message_at`, `observed_at`, `origin` e `coverage`. O principal não vai no evento: o Meta o preserva e revalida antes de cada entrega. A chave é estável por conexão, conta e remetente. Nome, e-mail, telefone, UTM, sessão ou consentimento não são inferidos.

Antes de chamar o consumidor, o Meta compara o candidato assinado com a primeira mensagem disponível na API; só mensagens posteriores à autorização de contatos são elegíveis. `coverage` registra que isso **não comprova primeiro contato de toda a vida**. O consumidor precisa de deduplicação persistente pelo identificador escopado do Instagram, inclusive após reinstalação ou limpeza, e de bloqueio de reimportação para contatos eliminados.

**Recibo aceito:** `['persisted'=>true,'record_id'=><id real>,'idempotency_key'=><mesma chave>]`. A reserva é gravada antes do callback; exceção ou recibo ambíguo vira `uncertain`, sem repetição automática, e um reinício depois da reserva também não autoriza repetir.

`meta/process-messages` processa uma página; preserve `next_cursor`. Um evento elegível recebido agenda execução local, que continua as páginas pelo cron. Falha da Meta exige nova execução administrativa depois do diagnóstico. Sem cron, não há processamento.

**Reconciliação.** `Messaging::deliveryReceipt($connection,$account,$event)` devolve estado e revisão. Depois de conferir o recibo ou o bloqueio no Core, `Messaging::reconcileReceipt($connection,$account,$event,$expectedRevision,$receipt)` aceita persistência real com a mesma chave ou `suppressed=true`. Exige administrador, consumidor presente e autorização atual, e não repete o callback. Não existe botão que declare sucesso sem prova do Core.

## Erros próprios

| Código | Significado |
|---|---|
| `page_selection_required` | Falta Página autorizada vinculada ao Instagram |
| `page_token_unavailable` | Não foi possível derivar o token da Página |
| `scope_missing`, `scope_unverified` | Escopos ausentes ou não comprovados |
| `webhook_configuration_required` | Falta token de verificação ou chave do aplicativo |
| `invalid_signature`, `invalid_webhook` | Notificação com assinatura ou formato inválido |
| `contacts_disabled` | Criação de contatos desligada |
| `consumer_unavailable` | Consumidor do Core não registrado |
| `privacy_key_unavailable` | Chave de privacidade ausente ou inválida (MESSAGE-PRIVACY.md) |

A eliminação local de dados de mensagens está em MESSAGE-PRIVACY.md. Testes com fixtures exercitam o contrato; não substituem a validação com aplicativo aprovado na Meta.
