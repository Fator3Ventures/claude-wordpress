# Insights de Páginas — diagnóstico

Este guia orienta a investigação de insights de Páginas do Facebook: permissões do token da Página, interpretação de vazios e recusas, e comparação com outras fontes.

## Sequência

1. Leia este documento e CONTRACTS.md por `meta/documentation`. Não copie tokens entre sites.
2. Consulte `meta/list-connections` ou `meta/get-connection` e confirme que o ID da Página consta em `assets.facebook`. Descoberta não concede acesso.
3. Execute `meta/validate-connection` com `connection_id`, `channel=facebook` e o `account_id` da Página. Repita para cada Página: a operação trata um ativo por chamada.
4. Leia `proof.page_permissions`:
   - `status=verified` confirma a inspeção do token derivado da Página.
   - `read_insights_granted` e `pages_read_engagement_granted` indicam as concessões efetivas para essa Página. Escopo concedido só a outra Página resulta `false`.
   - `false` significa ausente quando `status=verified`; `null` significa não determinado.
   - `status=unknown` ou `invalid_credential` não comprova acesso. `diagnostic_error` traz a recusa sanitizada da inspeção.
   - `insights_read` continua `false`: a inspeção de escopos não consulta nem homologa métricas.
5. Consulte `page_insights` com uma métrica e um intervalo conhecido; depois amplie. Confira `errors` e `last_error`, não só `status` e `last_code`.

Exemplo sintético:

```json
{"connection_id":"conexao-exemplo","channel":"facebook","account_id":"222","report":"page_insights","fields":["page_follows"],"date_from":"2026-01-01","date_to":"2026-01-14","granularity":"day","limit":100}
```

Use `meta/query` para uma página de resultados, ou `meta/create-job` com `query` e `idempotency_key`. Numa coleta, avance com `meta/run-job` até o estado terminal, respeitando `retry` e `next_at`, e leia `meta/job-results`.

## Interpretação

| Situação | Evidência | Tratamento |
|---|---|---|
| Valor 0 | A Meta devolveu zero | Preservar como dado |
| Resposta 200 sem métrica ou valor | `empty_or_suppressed` ou `value_unavailable`, `cause=undetermined` | Não afirmar falta de permissão, de seguidores ou descontinuação sem outra prova |
| Grupo vazio | Consulta individual limitada para cada métrica ausente, com o mesmo `period=day`, `since` e `until` | Não repete indefinidamente |
| Recusa por métrica | `cause=provider_rejected`, `reason`, `provider_code`, `provider_subcode` | Ler o erro exato da Meta; o código `unsupported_for_asset_or_version` é preservado |
| Token ou ativo recusado | `token_rejected` ou `asset_access_denied` em `details`; coleta pausada com `last_error` | Corrigir credencial ou permissão e revalidar antes de retomar |
| Mais de um bucket diário | `multiple_source_buckets`, com `source_values` preservados | Não somar nem escolher; conferir `end_time` e fuso da origem |

Exemplo sanitizado de recusa: `{"code":"unsupported_for_asset_or_version","cause":"provider_rejected","reason":"upstream_validation","http_status":400,"provider_code":100,"provider_subcode":33,"provider_is_transient":false}`. Os números são ilustrativos e não garantem a mesma causa para toda métrica.

## Permissões e privacidade

O token da Página é derivado só de Página selecionada e guardado cifrado. A inspeção usa `debug_token` com a credencial de origem, ou com o App ID e a chave salvos, quando existem. A resposta nunca expõe token de origem, token derivado, chave do aplicativo, URL, mensagem bruta ou outros ativos. Se a Meta não permitir a inspeção, o resultado fica desconhecido com o erro recebido; escopos do usuário não são usados como prova para a Página.

## Limites

Seguidores em `page_profile` não provam que `page_follows` estará disponível numa janela histórica. Permissão verificada também não garante todos os produtos e métricas. A Meta pode devolver vazio sem explicar a causa; o plugin preserva essa incerteza e não preenche uma série com o total atual do perfil.

O intervalo usa `since` no início do dia UTC e `until` no início do dia seguinte ao fim pedido; o `end_time` original fica no resultado. Comparações com outras fontes exigem a mesma definição, janela, fuso e `end_time`, no ativo autorizado.

A visualização do perfil da Página (`page_views_total`) tem guia próprio em PAGE-VIEWS.md.
