# Solução de problemas

Este guia parte do sintoma. Para o significado de cada código de erro, veja CONTRACTS.md; para os códigos de `issues` de `meta/health`, WORKER.md; para recusas da Meta em coletas, COLLECTION-DIAGNOSTICS.md.

## Primeiro passo

1. Abra **Diagnóstico** ou chame `meta/health`. Não altera nada e não consulta a Meta.
2. Se precisar conferir o ambiente local, use `meta/selftest` (ou **Executar autoteste local**). Ele confere armazenamento, cifra, cursores, lista de endpoints e schemas, sem validar credenciais.
3. Se precisar confirmar a Meta, use `meta/validate-connection` para um ativo. Essa ação consulta a Meta.
4. Consulte `meta/audit` para ver as operações recentes, com código e instante.

## Sintomas

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| Painel mostra “A sessão do painel expirou” | Nonce da sessão vencido | Recarregar a página e repetir; nada foi gravado |
| `not_authorized` no painel ou na REST | Usuário sem `manage_options` | Usar conta administradora |
| `not_authorized` pelo MCP com usuário administrador | Perfil do transporte não autoriza a operação | Conferir o perfil e as operações liberadas no Fator3 MCP |
| `not_authorized` com `auth_scope=connection` | A Meta também recusou a credencial em `/me` | Renovar o token ou restaurar as permissões do aplicativo |
| `invalid_input` | Parâmetro fora do schema | Ler `details.field` e `details.problem` |
| `revision_conflict` ao salvar | Outra gravação mudou o registro | Reler e repetir com a revisão atual |
| `token_expired` ou `token_rejected` | Token vencido, revogado ou inválido | Renovar a credencial; o histórico local continua legível |
| `asset_access_denied` | Ativo não selecionado, ou recusado pela Meta | Conferir a seleção em Ativos e as permissões na Meta |
| `credential_identity_mismatch` ao salvar | Token de outra identidade | Usar **Trocar identidade e regravar agendas** |
| `rate_limited` | Quota da Meta | Aguardar `details.retry_after`; as agendas adiam sozinhas |
| `budget_exhausted` | Limite local da execução | Aguardar a próxima execução (EXECUTION-BUDGET.md) |
| `upstream_validation` | A Meta recusou o pedido | Conferir versão da API, campo, produto e aprovação do aplicativo |
| `history_changed` | O histórico mudou durante a leitura | Recomeçar a consulta ou exportação |
| `response_limit` | Resposta grande demais | Reduzir campos ou `limit`; não considerar a resposta completa |
| `cipher_unreadable` | Salts diferentes dos usados para cifrar | Conferir o `wp-config.php` contra o backup; não regravar sobre o dado |
| `storage_unavailable` ou `persistence_unconfirmed` | Banco indisponível, sem espaço ou travado | Conferir o banco; reler o estado antes de repetir |
| Agenda não roda | Cron parado, worker ausente ou agenda sem autorização | Ver `issues` em `meta/health` |
| Coleta `partial` | Algumas métricas indisponíveis, dados úteis preservados | COLLECTION-DIAGNOSTICS.md |
| Métrica vazia ou `null` | Supressão, falta de dados ou recusa por métrica | Ler `rows[].diagnostic`; não concluir falta de permissão sem código da Meta |
| E-mail de alerta não chegou | `wp_mail` aceito não prova entrega | Conferir `notification.state` e o serviço de e-mail |
| Leitura da ajuda recusa com `revision_conflict` | A instalação mudou durante a leitura | Recomeçar pelo índice; se persistir, reinstalar a versão |

## Cron

O WP-Cron depende de visitas ao site, a menos que o servidor o chame. Sem tráfego, as agendas atrasam e aparecem em `schedule_overdue`. Execute uma passagem manual com `wp f3-meta run` e configure o agendador do servidor. Coletas grandes exigem várias passagens.

## Páginas do Facebook

Seguidores em `page_profile` não provam permissão `read_insights` nem disponibilidade histórica. Um resultado vazio sem erro da Meta não autoriza afirmar falta de permissão. Siga PAGE-DIAGNOSTICS.md.

## Datasets e anúncios

O código 100 da Meta, sozinho, não prova falta de permissão. Leia `provider_call`, `request_stage`, `provider_message` e `diagnostic_action` na coleta e na agenda, e `datasets.diagnostics` em `meta/health`. Depois de corrigir a causa, repita a coleta ou crie uma carga retroativa. MONITORING.md e COLLECTION-DIAGNOSTICS.md detalham.

## Registros ilegíveis

`queue_record_unreadable` e `schedule_job_unreadable` indicam registros que a chave atual não abre. Eles não são executados nem apagados. Restaure os salts corretos; não apague registros para destravar (WORKER.md).
