# Meta Ads somente leitura

O plugin lê insights diários de contas de anúncios e guarda o acervo cifrado sem prazo. Não cria, edita, publica, pausa nem gasta em anúncios. Pixel/CAPI, Lead Ads, contatos e associação com parceiros ficam no Site Core; a gestão de campanhas fica no MCP oficial da Meta.

## Configuração

1. Em Conexão, confira que o token tem `ads_read` (CONFIGURATION.md).
2. Em Ativos, descubra e selecione as contas de anúncios. Os IDs são strings numéricas sem o prefixo `act_`; o prefixo é aplicado só na chamada à Meta.
3. O token precisa estar validado na geração atual da credencial.

Sem ativo selecionado, a resposta é `asset_access_denied`; sem escopo comprovado, `ads_read_required`. Credenciais nunca aparecem em saída, histórico ou SDK.

## Consulta

`meta/query` e `meta/create-job` aceitam `channel=ads`, `report=ads_insights`, `connection_id`, `account_id`, `date_from` e `date_to` (obrigatórias, no máximo até ontem no fuso IANA da conta), `ads_level` (`account`, `campaign`, `adset` ou `ad`; padrão `campaign`) e `limit` de 1 a 100.

- Omita `fields` ou envie lista vazia: a coleta usa o conjunto completo disponível.
- Filtros orgânicos, detalhamentos e `granularity` não são aceitos.
- O calendário é diário (`time_increment=1`); cada página consulta um dia.
- No nível `ad`, há no máximo 10 linhas por página, para reservar chamadas aos criativos.
- O cursor preserva consulta, identidade, autorização, geração da credencial e limites.

## Campos

`spend`, `account_currency`, `impressions`, `reach`, `frequency`, `clicks`, `inline_link_clicks`; IDs e nomes de conta, campanha, conjunto e anúncio conforme o nível; `actions`, `cost_per_action_type`, `results` e `cost_per_result` tipados; `creative_id` e nome do criativo no nível `ad`, quando disponíveis; `leads_native` e `leads_website`.

- IDs, valores monetários e contagens são strings. Não some moeda com ponto flutuante no consumidor.
- Datas e fuso originais são preservados. Alcance e frequência não devem ser somados entre entidades ou dias.
- Criativo e nomes são os observados na coleta, não versões históricas. Níveis acima de `ad` não têm um único criativo.

**Atribuição fixa:** `use_unified_attribution_setting=true` e `action_report_time=mixed`. `results` e `cost_per_result` preservam os objetos da Meta, sem escolher um resultado principal. Se esses campos forem recusados, a página básica é lida e os opcionais ficam isolados, com conferência das entidades antes de anexar. Campo ausente fica `null` com diagnóstico, sem apagar `spend`, `impressions` ou `clicks`.

**Leads:** `leads_native` usa `actions.onsite_conversion.lead_grouped`; `leads_website` usa `actions.offsite_conversion.fb_pixel_lead`. O agregado `lead` fica separado em `actions` e nunca é somado aos subtipos. Ausência é desconhecida, não zero.

## Carga retroativa

`meta/create-backfill` usa início explícito, término congelado e coletas retomáveis (padrão 5.000 páginas, máximo 10.000). A coleta vai do dia mais recente para o mais antigo e preserva o que já coletou se um dia antigo for recusado. A disponibilidade do passado depende do ativo, da métrica e da versão da API: uma recusa não prova, sozinha, limite histórico, e um período vazio não prova cobertura integral. Divida cargas grandes em intervalos e confira `coverage`, `errors`, `plan_complete` e `last_code`.

## Agendas e revisita

Agendas de Ads usam, por padrão, intervalo de 1440 minutos e revisitam os últimos 7 dias completos; `lookback_days` aceita 1 a 30. O período de cada execução é calculado no fuso da conta, inclusive em mudanças de horário; `next_at` é Unix UTC. Crie uma agenda por conta e nível. Revisões tardias além do `lookback_days` exigem nova carga retroativa.

## Acervo

O histórico de Ads é cifrado e não expira, mesmo em conexão com prazo finito. A identidade de cada linha inclui conexão, conta, nível, entidade, dia, atribuição, moeda e fuso. Uma revisita substitui a observação corrente dessa identidade, sem somar investimento duas vezes.

- `last_available_fields` guarda o último valor não nulo de cada campo com sua data, separado da observação atual. Não trate esse valor como confirmado na consulta atual.
- Um dia sem linhas não cria zeros nem apaga linhas já observadas. Compare `last_seen` e a cobertura antes de concluir ausência.

`meta/history-query` e `meta/history-export` aceitam `channel=ads`, `ads_level` (padrão `campaign`) e datas. A exportação por coleta continua disponível, com `allow_partial` explícito quando necessário. Outros plugins leem esse acervo pelo SDK de META-ADS-READER.md.

## Validação externa

Testes com dados simulados validam armazenamento e contratos, não a Meta. A conferência real compara, com o Gerenciador de Anúncios, os mesmos 30 dias completos, nível campanha, fuso, moeda, atribuição e instante: `spend`, `impressions` e `clicks` por `campaign_id`, paginando tudo e sem somar alcance. Ela exige credenciais e contas do operador. CHANGELOG.md registra as validações externas pendentes.
