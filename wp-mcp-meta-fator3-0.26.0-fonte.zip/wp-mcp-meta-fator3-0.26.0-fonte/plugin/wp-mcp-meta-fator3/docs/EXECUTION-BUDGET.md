# Orçamento de execução

`budget_exhausted` é um limite local de segurança por fase da execução PHP. Ele vale para as chamadas HTTP feitas dentro da fase. Não é quota diária por conexão, conta ou agenda, não é orçamento financeiro de anúncios e não se repõe à meia-noite. A quota da Meta é separada e aparece como `rate_limited`.

## Limites

| Fase | Chamadas HTTP máximas | Janela |
| --- | ---: | --- |
| Operação pública | 40 | 25 segundos |
| Despacho das agendas | 40, compartilhadas entre as agendas da passagem | 25 segundos, limitada pelo prazo do worker |
| Página de uma coleta | 40, renovadas antes de cada página | 25 segundos, limitada pelo prazo do worker |
| Passagem do worker | até 20 coletas, agendas prioritárias primeiro | 22 segundos; não inicia coleta depois de 19 segundos |
| Operação interna sem alocação explícita | 15 | 25 segundos |

Uma chamada conta quando chega ao transporte HTTP, inclusive se a resposta for erro. Uma recusa local por quota remota não consome chamada. Há margem de dois segundos antes do prazo para chamadas normais e de três para miniaturas. O timeout de cada chamada é limitado pelo tempo restante.

Cada página de coleta e cada despacho de agendas recebem alocação própria, respeitando o prazo da passagem. Pausar uma carga retroativa não renova o orçamento de uma fase já iniciada. Não há contador diário a limpar nem opção para zerar quota pelo banco.

## Onde ver o consumo

- `meta/health` traz `execution_budget_policy` (a política) e `budgets[]` (estado por agenda habilitada).
- `meta/list-schedules` traz `schedules[].budget`, inclusive para agendas desabilitadas.
- Em caso de falha local, `last_error.execution_budget` guarda a mesma observação.

`local.last_observation` contém `scope`, `request_limit`, `requests_used`, `requests_remaining`, `started_at`, `deadline_at`, `seconds_remaining`, `observed_at` e `exhausted_by` (`requests`, `time`, `not_initialized` ou `null`). Registros antigos sem esses dados mostram `null`; o plugin não inventa consumo passado. Os tempos são observações, não um cronômetro.

`local.blocked_since` é a primeira falha local persistente observada. Em registro antigo, usa `last_error.observed_at` quando o último código ainda é `budget_exhausted`; a data real pode ser anterior. Um despacho bem-sucedido mantém esse relógio até a coleta progredir. Uma página gravada, ou um erro de outra natureza, encerra o bloqueio. Alterar a seleção da agenda reinicia seus diagnósticos; salvar a mesma seleção os preserva.

`local.next_replenishment_at` é o próximo instante elegível estimado, combinando agenda, coleta recuperável e evento do worker. `replenishment_estimated=true` e `requires_worker_execution=true` deixam claro que nada se renova sem execução. Em agenda desabilitada o valor é `null`. `remote.blocked_until` mostra a janela de quota da Meta por conexão. `provider_limit` e `provider_consumption` são `null`, porque o plugin não mede o saldo da plataforma. Renovar o orçamento local nunca libera a quota remota.

## Prioridade e recuperação

As últimas coletas de agendas habilitadas entram antes das cargas retroativas, mesmo com muitas cargas antigas na fila. Só entram coletas `queued` ou `retry` já elegíveis. O espaço e o tempo que sobram vão para as cargas retroativas; sob carga contínua de agendas, não há prazo garantido para concluí-las. A seleção é limitada a 100 agendas e 20 coletas por passagem.

Uma falha local de orçamento espera cinco minutos e continua recuperável mesmo após seis tentativas. Outros erros seguem suas próprias regras. Agendas também esperam cinco minutos após falha no despacho. Histórico e resultados já gravados são reaproveitados.

## Incidente após 24 horas

Um bloqueio local de agenda habilitada por mais de 86.400 segundos aparece como `schedule_budget_exhausted` em `meta/health`, com conexão, agenda, duração, último erro, orçamento e ação recomendada. O worker tenta avisar o `admin_email` uma vez por incidente (WORKER.md). Health e list-schedules são leituras: não coletam, não enviam e-mail e não renovam orçamento. A recuperação encerra o incidente.

## Verificação operacional

1. Confira `meta/health`, o worker e o orçamento das agendas.
2. Preserve pausas deliberadas. Para retomar uma carga retroativa, use `meta/control-job` com a revisão atual.
3. Com agendas diárias habilitadas, confira `last_job`, `last_success_at` e o dia de ontem no fuso da conta.
4. Consulte o histórico diário. O plugin não cria linhas para datas ainda não coletadas.
5. Com `rate_limited`, aguarde a janela da Meta. Com `budget_exhausted` persistente, examine o último consumo, o prazo e o funcionamento do worker.

Resultados de laboratório não provam coleta real na Meta.
