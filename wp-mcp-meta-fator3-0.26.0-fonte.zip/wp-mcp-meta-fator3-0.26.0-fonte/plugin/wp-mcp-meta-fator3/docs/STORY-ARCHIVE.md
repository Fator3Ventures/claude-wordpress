# Métricas e arquivo de Stories

Este guia cobre as métricas de Stories e de mídia com detalhamento, a supressão por poucos espectadores e o arquivo privado de Stories. A versão do catálogo e a disponibilidade de cada campo aparecem em `meta/list-fields`. Todo campo catalogado continua sujeito ao ativo, ao tipo de mídia, às permissões e à Meta.

## Métricas

| Relatório | Campos | Detalhamento |
|---|---|---|
| `stories_insights` | `follows`, `profile_visits`, `shares`, `total_interactions`, `link_clicks`, `profile_activity`, `navigation` | `profile_activity` usa `action_type`; `navigation` usa `story_navigation_action_type` |
| `media_insights` | `profile_visits`, `follows`, `profile_activity` | `profile_activity` usa `action_type`; use o post ou álbum pai |
| `account_insights` | `reach`, `views` | `breakdown=media_product_type`, quando pedido explicitamente |

As consultas de `media_insights` conferem o proprietário. O inventário percorre posts e álbuns da conta, não os filhos do carrossel como posts independentes. Se um filho for informado manualmente e a Meta recusar, a recusa é preservada por métrica, com orientação para o álbum pai.

`media_product_type` separa tipos de mídia; **não** separa orgânico de anúncio. Os buckets devolvidos são preservados, sem repartir o total. Se a Meta devolver só o total, a linha informa `breakdown_not_returned`. `profile_activity` e `navigation` usam consultas com seus próprios detalhamentos.

## Supressão

A mensagem exata da Meta `(#10) Not enough viewers for the media to show insights` é classificada como supressão de Story: valor `null`, sem concluir revogação da conexão. Um erro 10 genérico não prova poucos espectadores. Resposta vazia informa causa não confirmada. `follows_and_unfollows` vazio não é atribuído automaticamente a poucos seguidores. Código e HTTP medidos ficam nos erros; texto arbitrário da Meta não é guardado. COLLECTION-DIAGNOSTICS.md explica `story_expired` e `story_insights_unavailable`.

## Captura

1. Na aba **Arquivo de Stories**, escolha conexão e conta Instagram.
2. Use **Criar agenda horária de Stories**. Ela cria uma agenda comum, sem filtro fixo de datas, com as métricas de Stories. O painel evita duplicar uma agenda horária equivalente ativa.
3. Revise ou pause a agenda na aba Coletas, subvisão Agendas.

Também é possível criar a coleta diretamente:

```json
{"query":{"connection_id":"conexao-exemplo","channel":"instagram","account_id":"111","report":"stories_insights","fields":["reach","views","profile_activity","navigation","link_clicks"]},"idempotency_key":"stories-exemplo"}
```

Envie a entrada acima a `meta/create-job` e avance com `meta/run-job` até o fim.

Coletas persistentes de `stories` e `stories_insights` capturam data de publicação, tipo, link permanente, legenda e miniatura antes de pedir insights. Uma consulta simples por `meta/query` não grava o arquivo. O cron depende de execução do WordPress. Stories podem expirar entre execuções, e a API não reconstrói Stories nunca observados; métricas só existem se coletadas enquanto a Meta as oferecia.

## Miniaturas

| Limite | Política |
|---|---|
| Retenção | Sem expiração automática |
| Registros e armazenamento | Sem limite total nem descarte por quantidade |
| Origem da imagem | HTTPS, só subdomínios `cdninstagram.com` e `fbcdn.net`, sem redirecionamento, credenciais ou porta |
| Download | Máximo 1 MiB, 5 segundos, sem token |
| Imagem aceita | JPEG, PNG ou WebP, até 4.096 px por lado e 12 megapixels |
| Miniatura guardada | JPEG reprocessado, até 256 px, qualidade 60, máximo 32 KiB |

A miniatura exige editor de imagem do WordPress (GD ou Imagick). Sem editor ou arquivo válido, os metadados são mantidos com o diagnóstico `thumbnail_editor_unavailable` ou a causa correspondente. Vídeo completo nunca é baixado: vídeo usa `thumbnail_url`; imagem usa a miniatura ou `media_url`. Arquivos temporários são removidos; não há anexo nem arquivo em uploads. A imagem fica cifrada no banco. O link permanente é reduzido a HTTPS do Instagram sem parâmetros; a legenda é limitada a 2.200 caracteres.

Uma miniatura indisponível não apaga os metadados nem transforma a coleta em falha de autenticação. Enquanto o Story ainda aparecer nas coletas, uma miniatura ausente pode ser tentada de novo após cinco minutos.

## Leitura

- `meta/story-archive`: `connection_id`, `account_id`, datas opcionais em par, `limit` de 1 a 25 e `cursor`. Devolve metadados e disponibilidade. Páginas podem vir vazias depois do filtro de datas; siga a continuação.
- `meta/story-archive-thumbnail`: `connection_id`, `account_id` e `story_id`. Devolve o JPEG em base64, numa resposta privada autenticada, sem URL pública.

A leitura confere administrador e seleção atual. Uma mudança de autorização bloqueia o acesso aos registros capturados sob a revisão anterior (`archive_unavailable`). O arquivo continua legível depois das 24 horas de vida do Story.

A homologação com Stories reais (publicar, coletar antes de expirar, ler depois e comparar com a Meta) depende dos ativos e credenciais do operador.
