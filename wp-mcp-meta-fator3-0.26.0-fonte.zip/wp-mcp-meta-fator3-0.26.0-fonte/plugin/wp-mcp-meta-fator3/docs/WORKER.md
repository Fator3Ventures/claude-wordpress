# Coletas, worker e alertas

Este guia descreve a fila de coletas, o worker, a manutenção horária, a diferença entre `meta/health` e `meta/status`, os códigos de `issues` e os avisos por e-mail. O resumo operacional está em OPERATIONS.md.

## Fila e worker

Cada coleta é um registro cifrado na tabela do plugin. Uma projeção técnica sem dados de negócio (`queue_state`, `queue_next` e o índice `runnable`) permite escolher as coletas a executar sem decifrar as concluídas. O registro e a projeção são gravados juntos, com conferência de revisão.

Em cada passagem, o worker:

1. Materializa as agendas vencidas em coletas.
2. Seleciona até 20 coletas `queued` ou `retry` já vencidas, por duas buscas indexadas, com prioridade para as últimas coletas de agendas ativas (EXECUTION-BUDGET.md).
3. Revalida estado, prazo e autorização de cada coleta sob a trava dela e executa uma página.
4. Pré-agenda a passagem seguinte e confere de novo o evento ao sair, mesmo após exceção.

Registros de coleta ainda sem projeção (de instalações antigas) são migrados em lotes de 100 por passagem, sem alterar conteúdo cifrado, revisão ou prazo; enquanto isso, o worker continua necessário. Depois de confirmada a migração, a opção `f3_meta_queue_settled` e as marcas de schema ficam no autoload, e uma requisição comum não executa consulta SQL própria do plugin.

Travas de banco impedem duas passagens concorrentes e dois reagendamentos simultâneos. Coletas concluídas, pausadas ou canceladas não são retomadas sozinhas.

## Manutenção horária

O evento `f3_meta_maintenance` roda a cada hora e:

1. Confere e, se preciso, recria o evento do worker.
2. Avança a migração da fila e a migração do histórico (lotes de 25 páginas de resultado).
3. Aplica a retenção apenas a registros com prazo vencido (RETENTION.md).
4. Confere o worker de novo e avalia os avisos por e-mail.

Se a manutenção sumir do cron, a primeira requisição seguinte do site a reagenda para cinco minutos depois, sob trava. Enquanto falta, `meta/health` mostra `maintenance_missing`.

## Health e status

| | `meta/health` | `meta/status` |
|---|---|---|
| Modo | Leitura | Escrita local |
| Rearma o worker | Não (`repair=not_attempted`) | Sim, se faltar o evento e houver agenda ativa, coleta pendente ou migração pendente |
| Envia e-mail | Não | Não |
| Consulta a Meta | Não | Não |
| Perfil MCP | Leitura basta | Exige perfil que autorize escrita |

As duas devolvem o mesmo diagnóstico: `state` (`ok` ou `degraded`), `observed_at`, `issues[]`, `active_schedules`, `partial_schedules`, `failed_schedules`, `worker_required`, `cron`, `queue`, `execution_budget_policy`, `budgets[]`, `schedules[]` (até 100 agendas) e `notification`. `meta/health` acrescenta `maintenance`, `messaging` e `datasets` (MONITORING.md). `meta/status` acrescenta `recovery` (`attempted`, `scheduled`, `code`) e `cron.observed_next`, que mostra o evento antes da tentativa; `cron.next` mostra o evento depois.

Quando o WordPress recusa o agendamento, `recovery.scheduled=false` e `recovery.code` informa o código dessa tentativa. Com agendamento confirmado, o código é `ok`. Sem tentativa, ambos são `null`. Na manutenção horária, `maintenance.last.recovery` indica se, ao concluir a manutenção, havia evento para o trabalho pendente ou a fila dispensava agendamento.

O estado é observado antes da recuperação. Uma consulta seguinte pode mostrar `ok`. `audit_health` trata só da auditoria e não substitui `state`.

`queue.oldest_due_lag_seconds` é o atraso da coleta vencida mais antiga, ou zero; `queue.oldest_due_at` é `null` sem coletas vencidas. Durante a migração da fila, `queue.migration_pending=true` indica que o atraso cobre só os registros já migrados.

## Códigos de `issues`

| Código | Significado | Ação | E-mail |
|---|---|---|---|
| `worker_missing` | Há trabalho e o evento do worker não está no cron | `meta/status` ou **Verificar e recuperar agendamento**; conferir o cron do servidor | Sim |
| `schedule_overdue` | Agenda ativa com `next_at` vencido há mais de duas vezes o intervalo | Conferir o cron e a autorização da agenda | Sim |
| `schedule_authorization_failed` | O usuário ou a concessão de origem perdeu autorização, ou a revisão mudou | Restaurar o acesso ou salvar a agenda pela concessão válida | Sim |
| `connection_authorization_failed` | A Meta recusou a credencial também em `/me` (uma issue por conexão) | Renovar o token ou restaurar as permissões do aplicativo; não precisa recriar agendas | Sim |
| `schedule_resource_access_failed` | A Meta recusou o recurso da consulta, sem revogação comprovada da conexão | Conferir a seleção e as permissões do relatório | Sim |
| `schedule_budget_exhausted` | Agenda bloqueada pelo orçamento local há mais de 24 horas | EXECUTION-BUDGET.md | Sim |
| `schedule_partial` | A última execução terminou parcial, com dados úteis preservados | Conferir as métricas indisponíveis | Não |
| `schedule_job_unreadable` | A última coleta da agenda está ilegível | Conferir os salts; os dados foram preservados | Não |
| `queue_record_unreadable` | Há coletas que a chave atual não abre (`count`) | Conferir os salts do `wp-config.php` | Não |
| `queue_migration_pending` | A migração da fila ainda não terminou | Aguardar as passagens do worker | Não |
| `maintenance_missing` | A manutenção horária não está no cron | Aguardar a próxima requisição; conferir o cron do servidor | Não |
| `dataset_optimized_event_zero` | Evento otimizado com zero confirmado (só em `meta/health`) | MONITORING.md | Não |

Recusas isoladas de Story têm código próprio e não geram issue de autorização (COLLECTION-DIAGNOSTICS.md).

## Registros ilegíveis

Uma coleta cujo conteúdo cifrado a chave atual não abre recebe `queue_state=unreadable`. O plugin não reescreve conteúdo, revisão, datas ou prazo; o registro sai da seleção do worker e da retenção e não é apagado. A decisão usa o mesmo conteúdo lido sob trava e conferido na gravação, para não confundir uma falha transitória de banco com corrupção.

Registros isolados não voltam sozinhos à fila. Restaure os salts corretos e avalie a reparação com o administrador. Não apague registros para destravar a fila.

## Avisos por e-mail

O worker e a manutenção enviam ao `admin_email` (Configurações → Geral do WordPress) os problemas atuais marcados na tabela acima. O texto traz o endereço do site, nome e ID da agenda ou conexão, a ação recomendada e, quando há, a causa medida (código, HTTP, código e subcódigo da Meta, instante). Não traz token, concessão, dados coletados nem conteúdo de resposta.

- Há uma única tentativa por incidente ativo, registrada antes do envio, inclusive quando o resultado é incerto.
- O mesmo incidente não gera novo aviso na hora seguinte. Quando a recuperação é observada, o incidente se encerra; uma falha nova permite outro aviso.
- `notification.state=accepted` significa que `wp_mail` aceitou a mensagem, não que ela chegou. `failed` ou `sending` pedem conferir o serviço de e-mail.
- `meta/health`, `meta/status` e `meta/list-schedules` nunca enviam e-mail.

## Autorização das agendas

Uma agenda guarda o principal que a criou. Se esse usuário perder `manage_options` ou a concessão do transporte for revogada, a agenda falha com `not_authorized` e aparece em `schedule_authorization_failed`. Trocar a concessão do transporte não transfere a propriedade nem libera resultados antigos. Salve a agenda pela concessão válida.

Uma revogação confirmada da conexão é agregada em `connection_authorization_failed` e marca todas as agendas da conexão, inclusive as pausadas, sem alterar seleção, principal ou estado. O alerta só some quando uma execução seguinte comprova a retomada.

## Limites

O WP-Cron é uma lista global: código de outro plugin que grave o cron ao mesmo tempo pode apagar um evento depois da conferência. A manutenção horária reduz a falha persistente, mas não garante atomicidade do WordPress. Se todo o cron estiver parado, nenhuma recuperação automática acontece: configure o agendador do servidor.
