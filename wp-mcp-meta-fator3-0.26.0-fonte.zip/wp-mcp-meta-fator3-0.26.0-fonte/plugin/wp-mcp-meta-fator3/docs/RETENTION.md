# Preservação de dados

A política do plugin é preservar os dados ao máximo. Nada de valor é apagado por idade, quantidade ou tamanho total. Só comprovantes técnicos de curta duração têm prazo.

## Sem expiração automática

| Dado | Política |
|---|---|
| Resultados das coletas e histórico de métricas | Sem prazo no modo `unlimited` (padrão) |
| Histórico de Meta Ads e de monitoramento (atividades, contagens, EMQ) | Sempre sem prazo, mesmo em conexão com prazo finito |
| Coletas concluídas, parciais e canceladas | Sem prazo |
| Auditoria de operações, gravações de conexão e worker | Sem prazo |
| Exportações de coleta e do histórico | Sem prazo, sem URL pública |
| Arquivo de Stories (metadados e miniatura) | Sem prazo, sem teto de quantidade ou de tamanho |
| Diário de mensagens, recibos e bloqueios de eliminação | Sem prazo, sem teto de quantidade |

Não há descarte do mais antigo para liberar espaço. A preservação depende da continuidade do banco e das chaves do site: mantenha backups próprios do banco e dos salts.

## Prazo finito opcional

Uma conexão pode usar `retention_mode=finite` com `retention_days` de 1 a 3650. O prazo vale só para resultados e histórico de métricas orgânicas dessa conexão. Mudar de `finite` para `unlimited` retira a expiração do histórico existente e das próximas páginas, mas não recupera o que já foi apagado. Mudar a retenção preserva a seleção de ativos e a auditoria.

## Prazos técnicos que continuam

Cursores de continuação, confirmações de troca de identidade, prévias, continuações de conversas (uma hora) e janelas de quota mantêm seus prazos curtos. Limites por chamada, tamanho de download, quantidade por página e memória também continuam. Preservar os dados não significa chamadas ilimitadas à Meta.

## Escopo do que é guardado

A coleta não inclui texto de mensagens, anexos ou vídeo completo. São guardados as miniaturas reduzidas e os metadados previstos. Cada remetente, conta e conexão tem um único candidato e recibo de primeira mensagem; mensagens seguintes não formam um arquivo de conversa.

## Exclusão

Exclusão é uma decisão administrativa deliberada, alinhada à política de privacidade do responsável pelo site. O plugin oferece apenas a eliminação local de mensagens por remetente ou evento (MESSAGE-PRIVACY.md), que prevalece sobre a retenção ilimitada. Não há rotina de limpeza de contatos do Site Core: a política e a deduplicação são do Core.

Registros que a chave do site não abre não são apagados pela manutenção; precisam de recuperação dos salts (WORKER.md).

## Marca de preservação

A opção `f3_meta_retention0110` registra que a política de preservação foi aplicada aos registros existentes. Se a aplicação for interrompida, ela recomeça na próxima carga do plugin. A aplicação não concede acesso, não reativa credenciais e não recupera dados já apagados.
