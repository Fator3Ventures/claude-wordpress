# Atividades de anúncios e qualidade de datasets

Este guia cobre os relatórios `ads_activity` e `dataset_quality`, o diagnóstico em `meta/health` e o contrato local `meta-ads-monitoring/1.0.0`. A configuração do consumidor no Site Core está em CORE-MONITORING.md.

## Seleção

| Relatório | Canal | `account_id` | Outro campo |
|---|---|---|---|
| `ads_activity` | `ads` | Conta de anúncios | — |
| `dataset_quality` | `dataset` | Dataset | `ads_account_id` = conta de anúncios autorizada |

Os dois exigem datas explícitas de dias completos no fuso da conta e token conferido com `ads_read`. Dataset e conta precisam estar selecionados na conexão; a coleta confere também o vínculo entre eles na Meta.

1. Em Ativos, autorize primeiro a conta de anúncios.
2. Selecione essa conta para descobrir datasets e salve a seleção.
3. Em Relatórios, escolha o relatório; em Coletas, subvisão Agendas, crie uma agenda de 1440 minutos. Revisita e `meta/create-backfill` usam os mesmos controles de coleta.

Não há ativação automática nem alteração de anúncios. O acervo destes dois relatórios não expira, mesmo em conexão com prazo finito.

Para ler resultados de dataset, a conta de anúncios vinculada precisa continuar selecionada na mesma conexão. Isso vale para o histórico, as páginas de uma coleta, a preparação e o download de exportações. Retirar um dos dois ativos bloqueia novas leituras com `asset_access_denied`, inclusive de exportações já completas; os dados cifrados continuam guardados. Com os dois selecionados de novo e o principal ainda autorizado, a leitura volta. Um cursor em andamento pode exigir reinício se o histórico ou a seleção mudou.

## Dados coletados

**Atividades.** `GET /act_{conta}/activities`, incluindo filhos, por dia, com cursor da Meta. Guarda horário, objeto, tipo de alteração, autor, aplicativo e `extra_data`; `old_value` e `new_value` ficam nulos quando ausentes. A Meta não garante ID de atividade: a chave local deriva de conta, instante, objeto, tipo, autor, aplicativo e detalhe. Revisitas não multiplicam eventos indistinguíveis, e esse limite aparece em cada linha.

**Contagens.** `GET /{dataset}/stats` com agregação horária `event`, uma consulta `WEB_ONLY` e outra `SERVER_ONLY` por dia. A cobertura por evento exige paginação completa, todas as horas do dia e presença explícita do evento em cada hora. Horas ou eventos ausentes, buckets duplicados ou fora da janela, contagens negativas ou estouro nunca confirmam zero. Dias de 23 e 25 horas seguem o fuso da conta. Navegador e servidor não devem ser somados como eventos únicos. Cada evento traz `browser_count`, `server_count` e `count_coverage`; o consumidor só pode tratar zero como confirmado quando `count_coverage` e `zero_confirmed` o indicam. Contagens incompletas ficam consultáveis com `count_coverage=false`.

**EMQ.** `GET /dataset_quality` com projeção `web{event_name,event_match_quality}`. Cada observação é guardada como `emq_snapshot` separado, com data e `emq_observed_at`. Não há reconstrução de EMQ de dias passados: a coleta do dia completo mais recente captura a nota atual, e a carga retroativa só busca contagens. A Meta pode exigir `ads_read` com `ads_management` ou `business_management`, ou autorização específica do dataset; essas permissões não habilitam escrita pelo plugin.

**Conjuntos de anúncios.** `GET /act_{conta}/adsets` com status efetivo `ACTIVE`, conta e pixel conferidos. Eventos padrão são mapeados explicitamente; conversões personalizadas sem evento padrão não geram inferência de zero. O estado ativo é observado agora e não afirma atividade durante todo o dia passado.

O vínculo entre conta e dataset usa `GET /act_{conta}/adspixels` e é obrigatório antes de ler contagens e EMQ.

## Limites

Cada aresta é limitada a 10 páginas e 3.000 registros; vínculos e conjuntos, a 5 páginas, dentro do orçamento de execução. Atingir um limite produz cobertura incompleta, nunca truncamento silencioso nem zero. A documentação pública da Meta descreve sete dias de recuperação para contagens; dados fora desse intervalo são preservados sem declarar cobertura completa. O horizonte de atividades é o que a Meta devolver.

## Resultado parcial

Falhas de contagem de navegador, de servidor, de conjuntos ativos ou de EMQ são diagnosticadas separadamente; os dados úteis das outras partes permanecem. Permissão, validação, resposta inválida, limite remoto, transporte e orçamento local podem terminar como parcial quando há dados úteis. Autorização local, revisão concorrente e persistência continuam impedindo a coleta. Não há repetição automática das partes faltantes de um dia: depois de resolver a causa, faça nova coleta ou carga retroativa.

## Health

`meta/health` traz `datasets`:

- `datasets.diagnostics[]`: erros atuais das coletas ligadas a agendas autorizadas, mesmo sem linhas, com `schedule_id`, `state`, `last_error`, `errors` e `action`. COLLECTION-DIAGNOSTICS.md descreve os campos.
- A issue `dataset_optimized_event_zero` aparece só com: dois zeros explícitos, cobertura das duas fontes, dia completo mais recente, evento padrão usado por conjunto ativo e agenda autorizada. Vazio, erro, parcial sem cobertura, plano revogado ou observação antiga não geram o aviso.

A leitura é local e não envia e-mail. O aviso ao responsável é decidido pelo Site Core (CORE-MONITORING.md).

## Contrato local meta-ads-monitoring/1.0.0

- Classe `Fator3\Meta\MonitoringReader`, gancho `f3_meta_register_monitoring_consumers`.
- Registro: `register_consumer(id, version, contract, configurationCallback, label)` devolve um cliente com `status` e `query`.
- O callback devolve `ready:true`, `connection_id`, `account_id` (conta de anúncios), `revision` crescente, `reports` (`ads_activity`, `dataset_quality`) e `dataset_ids`.
- A concessão explícita precisa ser igual à seleção do callback. Operações: `meta/monitoring-consumers`, `meta/get-monitoring-grant`, `meta/save-monitoring-grant`.

Exemplo sintético de leitura:

```php
$client->query(['connection_id'=>'conexao-exemplo','account_id'=>'333','report'=>'dataset_quality','dataset_id'=>'444','date_from'=>'2026-01-01','date_to'=>'2026-01-02','limit'=>50]);
```

Para notas de EMQ observadas hoje, consulte também a data de hoje. Nenhum token é entregue ao consumidor. Cursores vinculam consumidor, concessão, seleção, revisões e geração do histórico; a revogação invalida leitura e continuação. O contrato `meta-ads-reader/1.0.0` continua dedicado à performance de anúncios (META-ADS-READER.md).

Fixtures de laboratório não homologam essas permissões na Meta. A disponibilidade por versão, ativo e permissão depende de validação com credenciais reais.
