# Segurança e dados

Este guia descreve como o plugin protege credenciais e dados, quem pode acessar o quê, como as chamadas à Meta são limitadas e o que fica fora do plugin.

## Cifragem

Credenciais, resultados, histórico, cursores, auditoria, exportações, confirmações, arquivo de Stories e diário de mensagens são cifrados com criptografia autenticada (sodium; na falta, OpenSSL AES-256-GCM). A chave é derivada do salt de autenticação do WordPress, do ID do site e da finalidade do dado. Por isso:

- O backup precisa incluir o banco e os salts do `wp-config.php`.
- Trocar os salts torna os dados cifrados ilegíveis (`cipher_unreadable`).
- Um cursor ou comprovante de outro site é recusado.

Nenhuma operação devolve token, App Secret ou token derivado de Página. Não coloque tokens em tickets, documentação ou capturas de tela.

## Autorização

- Todas as operações, inclusive leituras e documentação, exigem `manage_options`, validado no servidor para painel, REST, Abilities API e MCP.
- A lista `users` da conexão não concede acesso a ninguém.
- Pelo MCP, a política do transporte é conferida antes da execução.
- Ativos vazios significam nenhum ativo autorizado. Descobrir um ativo não o autoriza.
- Coletas e agendas revalidam o usuário de origem, a concessão do transporte, a seleção e a revisão antes de cada chamada à Meta e antes de gravar. Revogação suspende a coleta e bloqueia a leitura local.
- Um ID de coleta ou de exportação não concede acesso: a leitura confere o principal e a seleção atual. Para resultados de dataset, a conta de anúncios vinculada também precisa continuar selecionada (MONITORING.md).
- Consumidores SDK concedidos podem ler sem usuário na sessão, mas a origem administrativa da concessão é revalidada a cada leitura (SDK-PHP.md).

## Chamadas à Meta

- Só `GET`, só em `graph.facebook.com` com a versão da conexão, só em caminhos da lista permitida (`endpoint_forbidden` para os demais).
- TLS verificado, nenhum redirecionamento, no máximo 8 segundos por chamada e resposta menor que 1,8 milhão de bytes.
- Orçamento local de chamadas e tempo por execução (EXECUTION-BUDGET.md) e janela de quota por conexão após `rate_limited`.
- `paging.next` da Meta nunca é seguido como URL; a continuação usa o cursor no endpoint fixo.
- Miniaturas de Stories vêm só de subdomínios `cdninstagram.com` e `fbcdn.net`, por HTTPS, sem token (STORY-ARCHIVE.md).

Dados vindos da API nunca são tratados como instruções ou caminhos. O CSV exportado neutraliza células que começam com caracteres de fórmula.

## Diagnóstico sanitizado

Mensagens da Meta passam por uma projeção de vocabulário técnico antes de serem guardadas: nomes, identificadores e números desconhecidos são substituídos; URLs, e-mails, IPs e credenciais são removidos; o texto fica limitado a 512 bytes. Rotas aparecem como modelos sem IDs. O corpo bruto, os cabeçalhos e a URL completa não são guardados (COLLECTION-DIAGNOSTICS.md).

## Auditoria

A auditoria guarda operação, ator, transporte, conexão, código e instante. Não guarda token, segredo, payload de leads nem dados coletados. As linhas não expiram (OPERATIONS.md).

## Documentação

A leitura documental só aceita IDs do índice fixado no build, confere tamanho e SHA-256 do arquivo e recusa caminhos arbitrários, travessia de diretório e links simbólicos que saiam da pasta `docs/`. Não consulta a Meta, não grava nada e exige `manage_options`.

## Privacidade

- Conversas: só metadados mínimos, sem texto, anexos ou cookies (INSTAGRAM-MESSAGING.md).
- Eliminação local por remetente ou evento, com bloqueio de reimportação (MESSAGE-PRIVACY.md).
- Exemplos e diagnósticos são sanitizados.

## Fora do plugin

O plugin não apaga cópias já baixadas, backups externos, dados no Site Core ou na Meta. Retirar um ativo não apaga o histórico, e desinstalar preserva os dados cifrados (OPERATIONS.md). Contatos, consentimento e deduplicação comercial são do Site Core.
