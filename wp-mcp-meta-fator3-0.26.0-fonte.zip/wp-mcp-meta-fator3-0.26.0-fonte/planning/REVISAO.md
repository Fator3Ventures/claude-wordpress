# Revisão corretiva da Meta 0.22.0

Origem: instalador e fonte fornecidos, relatório externo e quatro capturas da revisão anterior. Pedido direto de revisão, testes e correções; patch 0.22.1 conforme a orientação do dono para correções em versão implementada por outra sessão. Basename, fornecedor, rotas, 47 operações e hooks públicos preservados.

Revisões consultadas: os dois documentos centrais na revisão 5 (02/11/2026), Regra comum de 16/10, aba histórica de pedidos Meta e relatórios dos pacotes enviados. Em caso de divergência histórica vale o padrão atual. O único encaminhamento individual anexado (Pipedrive para Core, revisão 2) trata do consumo do Pipedrive no Core, sem mudança no contrato Meta.

Fronteiras examinadas antes de implementar: corpo da REST administrativa, acesso com manage_options, auditoria local, estado do editor e associação dos resultados ao alvo no Diagnóstico. O Site Core usa os hooks de mensagens, de Ads e de monitoramento; nenhum foi alterado. O MCP usa o registro de abilities com operações e schemas inalterados. Nenhuma mudança correspondente exigida no LinkedIn, Pipedrive ou Google. Verificações: reprodução na base, WordPress limpo, migração sem reativação, PHP/build, navegador, instalação e documentação pelo transporte no Site-Teste. Escopo externo do Pedido 27 continua com a frota.
