"""Package the editable source, tested runtime and internal pre-closing report, once."""
import sys,zipfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
out=Path(sys.argv[1]).resolve();out.mkdir(exist_ok=True,parents=True)
name=root.name;prefix=name.removesuffix('-fonte');report=root/(prefix+'-relatorio.md')
if not report.is_file() or 'cópia anterior ao fechamento do fonte' not in report.read_text():raise SystemExit('Missing pre-closing report.')
target=out/(name+'.zip')
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(root.rglob('*')):
  rel=p.relative_to(root)
  if not p.is_file() or rel.parts[:2]==('build','dist') or any(x in rel.parts for x in ('node_modules','__pycache__','.git')):continue
  if p.is_symlink() or p.suffix in ('.zip','.pyc','.gz','.sql'):raise SystemExit('Unexpected input: '+str(rel))
  i=zipfile.ZipInfo(name+'/'+rel.as_posix(),date_time=(2026,11,5,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.create_system=3;i.external_attr=0o100644<<16;z.writestr(i,p.read_bytes(),compresslevel=9)
print(target)
