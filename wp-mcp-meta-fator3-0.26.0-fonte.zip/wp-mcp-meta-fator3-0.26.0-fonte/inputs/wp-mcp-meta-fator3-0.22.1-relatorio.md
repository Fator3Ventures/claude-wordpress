# Entrega — Fator3 MCP Meta 0.22.1

Revisão 1 · 2026-11-10T22:43-03:00 · Revisão corretiva da entrega de outro agente · Slug `wp-mcp-meta-fator3` · **Apta no escopo testado; homologação comercial do Pedido MCP Meta 27 pendente.** Classificação global: `com-pendencias`.

## 1. De onde esta versão entra

A base de desenvolvimento e migração é a **0.22.0 fornecida pelo dono**. Conferidos os 71 arquivos do runtime: a árvore no fonte é idêntica ao instalador. Instalador-base: 258589 bytes, SHA-256 `c2685701485e2103bdfe52758f86ad72cf6ccba38b4af623586d92415f32a548`; fonte-base: 2393214 bytes, SHA-256 `36efe3e21b353c4f6aefc77ab7fd253215614f8ab2e6a76eb762d49efdd261fd`. As quatro capturas e os testes relatados pelo outro agente documentam a base; não foram somados às verificações desta revisão.

A 0.22.1 entra em instalação limpa ou diretamente da 0.22.0, sem desinstalar. O Site-Teste ainda estava na 0.21.0 e recebeu a 0.22.1 diretamente. Esse salto observado fica separado da prova de migração semeada da base vigente. Patch conforme solicitação prévia do dono para correções na revisão de outra entrega.

Requisitos: WordPress ≥ 7.1.4 e PHP ≥ 8.3 de 64 bits. Laboratório: WordPress 7.1.4, PHP 8.3.6 e MySQL 8.0.46; navegador Chromium 156.0.8078.79. Site-Teste: WordPress 7.1.4, PHP 8.3.36 e MySQL 8.4.11. Regras centrais lidas na revisão 5 de 02/11/2026, regra comum de 16/10 e aba histórica Meta consideradas à luz dos pacotes atuais.

## 2. Convivência e encaminhamentos

| Pacote ativo no Site-Teste | Versão final | Fronteira examinada |
|---|---:|---|
| Fator3 Site Core | 1.80.0 | SDKs de monitoramento e Ads: o consumidor do Core, na versão 1.80.0, continua registrado em ambos. Hooks de mensagens, Ads e monitoramento preservados. |
| Fator3 MCP | 0.44.0 | Instalação por ZIP com hash, catálogo, permissões de transporte e execução efetiva das leituras e diagnósticos da Meta. |
| Fator3 MCP Google | 0.31.0 | Coexistência no inventário e registro ativo; sem ZIP novo fornecido nem alteração em integração Google. |
| Fator3 MCP LinkedIn | 0.20.0 | Pacote distinto, sem uso das rotas REST de administração alteradas; não usa o JavaScript instalado pela Meta. |
| Fator3 MCP Pipedrive | 0.9.0 | O impacto entregue, revisão 2, trata da fronteira Pipedrive–Core; não há ação para Meta. |

Foram verificados versão interna, integridade dos dez ZIPs enviados e a correspondência de cada árvore instalável com o seu fonte. No MCP, 55 arquivos `index.php` com a mesma linha de proteção são gerados pelo build do próprio pacote. Não há alteração de schema público, nomes, rótulos, SDK ou contrato entre plugins. A REST da Meta passa a recusar corpos fora do formato contratado. Nenhum acompanhante precisa ser alterado ou reinstalado. Não houve impacto que justificasse um relatório individual, inclusive para o LinkedIn. Evidências: `source-comparison.json`, `inputs.json` e `site-teste.json` em `evidence/0221/`.

## 3. Mudanças e evidência

Pedido desta rodada: revisão e correção de versão de outro agente; sem número novo atribuído pelo dono.

| Achado reproduzido na 0.22.0 | Correção e prova |
|---|---|
| Um corpo REST como `null`, `true`, número, texto ou formulário era convertido em chamada sem parâmetros. Quando faltava o evento do worker e havia agenda ativa, o simples envio desse corpo a `status` recriava o evento. | O transporte verifica o tipo antes de despachar. A resposta à entrada inválida mantém o envelope `invalid_input` e o evento continua ausente. Chamadas autorizadas sem argumentos (objeto vazio, lista vazia ou corpo ausente) ainda reparam o cron. Ver `release0221.json`. |
| Um objeto enviado por engano em `connection_id` era copiado integralmente para a auditoria de retenção ilimitada, mesmo após a recusa do pedido. | O registro de recusa mantém operação, ator e código, com `connection_id: null` em entrada inválida. Identificadores válidos continuam disponíveis para erros de negócio. Sem remoção retroativa de eventos. |
| No Diagnóstico, uma validação podia continuar visível sob outro ativo; uma resposta atrasada podia substituir um autoteste mais recente ou exibir erro em outra aba. | O painel associa o resultado à seleção e à ação que o iniciaram. Prova em Chromium: troca A→B→A, mudança de aba, resposta tardia, autoteste concorrente e controle positivo da validação atual. |
| Voltar à lista não limpava os campos de credenciais ocultos. Digitar só no formulário de renovação não acionava confirmação. O atalho de primeiros passos podia focar um editor invisível. | Cancelar a saída conserva os campos. Confirmar descarta token, segredo e token de renovação; o atalho abre e foca o editor visível. Ver `ui-base.json`, `ui-final.json` e suítes de identidade e formulário. |

Atualizados os guias de administração, migração e contrato REST, as notas e os exemplos capturados em WordPress. As 47 operações e seus schemas de entrada permanecem idênticos. Nenhuma mudança de DDL, retenção ou credencial requerida.

## 4. Instalação e prova da troca

**352 verificações automatizadas aprovadas, zero falhas na candidata**. Os números abaixo são de execução própria; leituras de aceite do site compartilhado e verificações de pacote ficam fora dessa soma.

| Ambiente | Cenário | Verificações |
|---|---|---:|
| WordPress isolado, apenas Meta | Instalação, autorização, erros de transporte, preservação da auditoria, configuração, histórico, exportação e dataset; 32 documentos e manifesto instalado | 233 |
| WordPress isolado em processo novo | Migração direta da 0.22.0 para 0.22.1 com dados sintéticos | 16 |
| Chromium com login no WordPress local | Editor, renovação, diagnóstico e trocas de seleção; controle dos atrasos com respostas simuladas, saúde e autoteste reais, editor em 390 px | 11 |
| Chromium com renderer PHP e REST simulada | Formulário, retenção, ajuda, troca de identidade, confirmação, revisão e validade do token | 42 |
| Python/PHP, sem WordPress | Integridade, paginação UTF-8 e regras do build documental, inclusive testes negativos | 50 |

Na 0.22.0, antes da correção, as duas suítes focadas registraram **11 de 20 falhas no servidor e 7 de 11 no navegador**. Os controles positivos passaram na candidata. O assinante recebeu HTTP 403 na REST para conta, gravação e documentação; o mesmo perfil não executou essas três abilities registradas. Exemplos de fornecedor são sintéticos. Scripts reproduzíveis em `tests/`; arquivos estruturados em `evidence/0221/`.

**Site-Teste, pelo MCP autorizado.** Backup privado das duas tabelas Meta e das oito opções do pacote antes da troca, sem exportar valores para os artefatos. Conferido novamente o inventário e executado `plugins/upload-base64` com `activate=true`, `overwrite=true`, `expected_slug=wp-mcp-meta-fator3`, SHA da seção 8 e chave de idempotência. Operação `bb5090a73140da9557ca98278eb8c2a3`; pré-imagem de arquivos `1e49c422bb26639b567baa87`. O recibo confirmou versão ativa 0.22.1 no mesmo basename e hash do ZIP. Sondas à home e à REST aprovadas antes e depois. Não houve publicação no repositório; para distribuir pela frota, conferir também o SHA servido na URL raw e usar `plugins/upload` com o mesmo slug/hash.

**Aceite após instalação:** `plugins/list` confirmou os acompanhantes da seção 2 e a Meta ativa; `system/health` saudável, `meta/health` em `ok`, armazenamento e criptografia prontos, os oito itens de `meta/selftest` aprovados. Antes e depois: zero conexões, agendas ativas e linhas de histórico. Sem fixtures, contas de laboratório ou extensões temporárias instaladas no site compartilhado. Só os backups administrativos, o recibo da instalação e as trilhas normais das leituras ficam preservados.

**Aceite documental pelo transporte:** redescoberta das 47 operações e inspeção do schema de `meta/documentation` já na versão 0.22.1. O índice expôs 32 documentos. Foram lidas as 49 páginas com revisão fixa; bytes e SHA-256 de cada documento reconstruído conferem com o manifesto do instalador. Caminho externo ao índice: `not_found`. Continuação sem revisão: `invalid_input`. Revisão divergente: `revision_conflict`. No WordPress isolado, a ajuda não gravou auditoria nem fez requisição ao fornecedor. Resultados individuais: `documentos-mcp.json`.

## 5. Banco, migração e correção por nova versão

A atualização não exige SQL manual nem altera os salts. Na migração semeada, contagem e digest se mantiveram para 13 registros de negócio, quatro linhas históricas e a opção monitorada. Foram conferidos prazo explícito e retenção ilimitada, seleção e permissões, pausa e cursor da coleta, agenda, concessão de monitoramento, recibos e marca parcial de migração. Não houve exclusão de histórico, eventos de auditoria ou dados comerciais. Na edição do painel, descartar refere-se somente aos campos digitados no navegador.

Preservar backup consistente dos dados e chaves existentes. Se surgir falha depois da instalação, conter o fluxo afetado, conservar cursores e recibos e corrigir em versão posterior; sem downgrade. A rodada não examinou valores históricos da auditoria em produção.

## 6. O que permanece pendente

- **Pedidos MCP Meta 27:** cabe à frota validar com as credenciais e os ativos reais em korvena.com.br e ctooffice.com.br. Nenhum site de produção foi alterado e nenhuma solicitação comercial foi enviada à Meta.
- Prova visual própria em navegador de desktop com viewport móvel; sem aparelho físico ou leitor de tela. Não se executaram todas as suítes históricas nem uma campanha completa de regressão dos outros fornecedores. Os testes de API externos e de produção não estão substituídos pelas fixtures.
- Distribuição pelo repositório raw: responsabilidade da frota. Não foi necessária para a instalação autorizada de homologação.

## 7. Credenciais e configuração do dono

Nenhuma credencial nova é necessária para atualizar. Para conectar um ativo: **Ferramentas → Fator3 MCP Meta → Configurar → Conexão**; preencher nome, App ID, App Secret e token de usuário do sistema, com permissões e ativos correspondentes. Informar validade UTC quando aplicável. Na edição, campos secretos vazios preservam os valores salvos; remoção exige a opção explícita. Em **Ativos**, conferir as seleções e, para dataset, a conta de anúncios vinculada. Os detalhes de escopos e recuperação estão nos manuais instalados.

## 8. Identidade dos arquivos

| Artefato | Nome | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador WordPress | [wp-mcp-meta-fator3-0.22.1-instalador.zip](wp-mcp-meta-fator3-0.22.1-instalador.zip) | 258974 | `c52f3098c0b08accf8e79672687b1bc428cb08f04d4dc38a1c97c78758a15a2a` |
| Fonte com testes | [wp-mcp-meta-fator3-0.22.1-fonte.zip](wp-mcp-meta-fator3-0.22.1-fonte.zip) | 730423 | `53f92bee29b2088902f5b9324bcefb0f9d6a54697ef729ad67e32ccf7e4e8629` |

Somente o instalador é instalável. A árvore no fonte é idêntica aos 71 arquivos do ZIP instalado. O relatório externo é canônico; o fonte inclui uma cópia identificada como anterior ao fechamento, sem seu próprio hash. Este relatório identifica os dois ZIPs finais.
