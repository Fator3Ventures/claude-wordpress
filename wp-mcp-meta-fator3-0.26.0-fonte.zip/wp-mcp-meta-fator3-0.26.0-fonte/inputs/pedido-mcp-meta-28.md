# Pedidos — Fator3 MCP Meta (wp-mcp-meta-fator3)

Pedidos de funcionalidade e correção em aberto no pacote **wp-mcp-meta-fator3**. Cite como "Pedidos MCP Meta N". Próximo número: 29; número retirado fica vago.

## wp-mcp-meta-fator3 — pendentes

**28. Leitura do anúncio de origem para o Site Core (Pedidos core 390).** Pedido do dono de 11/11/2026 às 01:36 (texto no core 390). O pacote já lê criativos pela concessão do contrato meta-ads-reader/1.0.0 (Conector, Ref. §3.6, 0.13.0); não foi conferido se o contrato entrega o criativo por anúncio. Pedido: dado conta e ad\_id (vindo do `utm_content` do contrato de URL v1 ou do lead do formulário nativo), devolver ao Site Core numa chamada, só leitura: nome e ID do anúncio, do conjunto e da campanha; do criativo, texto principal, título, descrição, botão e destino; tipo de mídia; imagem (`image_url`) ou vídeo (`video_id`, com miniatura e link de reprodução), com a validade do endereço; `effective_object_story_id` e `instagram_permalink_url` quando houver; e o link do Gerenciador de Anúncios (`adsmanager.facebook.com/adsmanager/manage/ads?act=<conta>&selected_ad_ids=<anúncio>`). Se o contrato atual já entrega isso, a entrega aponta os campos e o item sai. Aceite: em korvena.com.br, o anúncio ativo da campanha 120256596454580242 devolve os campos e a imagem ou miniatura baixável, sem escrita na conta.
