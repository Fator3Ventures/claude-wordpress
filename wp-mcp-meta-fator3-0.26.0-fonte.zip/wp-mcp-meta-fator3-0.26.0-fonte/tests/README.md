# Testes do Fator3 MCP Meta 0.24.1

WordPress 7.1.4, PHP CLI 8.3+ de 64 bits com mysqli, mbstring, JSON e criptografia. Use um MySQL de laboratório isolado em 127.0.0.1:34793 (root sem senha, sem acesso externo). O executor cria e remove um banco e uma raiz temporários por cenário; não use o banco do Site-Teste. Reserve 34893 para o painel. Defina F3_SOCIAL_PHP, F3_QA_WP_CORE (WordPress extraído), F3_QA_BASE (pasta oficial Meta 0.24.0) e F3_QA_CORE (pasta oficial Core 1.80.0). Para simular a atualização direta da frota a partir de 0.23.0, informe sua pasta de instalador em F3_QA_FLEET_BASE e execute upgrade-fleet. Para ui-origin, instale Playwright para Python e informe o caminho do Chromium em F3_QA_CHROME.

    python3 build/build.py
    for fase in clean upgrade regression origin ui-origin core-alone; do python3 tests/lab/review024.py "$fase" || exit 1; done
    python3 tests/docs/check.py "$F3_SOCIAL_PHP" build/dist/wp-mcp-meta-fator3

Em origin e ui-origin, o executor aplica integration/core/core-390.patch a uma cópia do Core antes de ativá-la. As chamadas Graph e a entrega externa de e-mail estão bloqueadas no laboratório. O teste PHP intercepta apenas os GETs previstos e a UI usa REST e banco reais. A migração parte do instalador oficial e confere o digest dos dados. Para regenerar os exemplos, faça primeiro o build com F3_EXAMPLES_BOOTSTRAP=1, execute capture e refaça o build normal. As evidências atuais estão em evidence/024; os demais diretórios de evidências e testes de releases identificadas são históricos.

## Rodada 0.25.0

O runner `tests/lab/review025.py` aceita origin-base, origin, clean, upgrade, capture, ui-origin, without-provider e combination. Use WordPress 7.1.4, PHP 8.3+ e MySQL local em 127.0.0.1:34793. Defina F3_QA_BASE (instalador 0.24.1 extraído), F3_QA_CORE (Core 1.81.1 oficial extraído), F3_QA_WP_CORE (WordPress limpo), F3_SOCIAL_PHP e, para UI, F3_QA_CHROME. Para combination, F3_QA_COMPANIONS aponta para os quatro acompanhantes MCP, Google, LinkedIn e Pipedrive já extraídos; o Core é adicionado separadamente. O banco isolado é descartado ao encerrar. O tráfego de Graph e CDN é simulado; produção não é requisito para a suíte. A base deve reproduzir falhas, a candidata deve passar.

## Rodada 0.26.0 — pedido 29

Runner: tests/lab/review026.py. Use o mesmo ambiente MySQL local descrito acima, com F3_QA_BASE=Meta 0.25.0, F3_QA_CORE=Core 1.85.1, e F3_QA_COMPANIONS apontando para os outros quatro instaladores vigentes já extraídos. As fases grant-base e grant testam as mesmas asserções no MCP 0.45.0 e WordPress real. A primeira reproduz o erro. As demais incluem clean, upgrade, origin, combination, without-provider, ui-origin e capture. O banco e o site do runner são temporários. No Site-Teste, o auxiliar fechado tests/site/026 verificou as duas credenciais de aplicativo e o perfil MCP restrito; não faz parte do instalador e foi excluído do site depois da homologação. Use exclusivamente no host de teste indicado no próprio arquivo. Resultados sanitizados: evidence/026.
