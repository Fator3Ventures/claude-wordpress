<?php
/* Executar somente no WP isolado; a ação de controle usa uma agenda sintética. */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$checks=[];$ck=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$send=static function($body,$media='application/json',$op='status'){
 $r=new WP_REST_Request('POST','/'.M\Config::REST.'/'.$op);$r->set_header('Content-Type',$media);$r->set_body($body);return rest_do_request($r);
};
$remote=0;add_filter('pre_http_request',static function()use(&$remote){++$remote;return new WP_Error('qa_blocked');},1);
M\Store::put('schedule','qa-shape',['id'=>'qa-shape','label'=>'QA','enabled'=>true,'query'=>['connection_id'=>'any','account_id'=>'1','channel'=>'instagram','report'=>'profile'],'next_at'=>time()+3600],0);
$hook=M\Config::KEY.'_worker';
foreach([['null','application/json'],['"x"','application/json'],['true','application/json'],['7','application/json'],['[1]','application/json'],['x=1','application/x-www-form-urlencoded']] as [$body,$media]){
 wp_clear_scheduled_hook($hook); $r=$send($body,$media);$data=$r->get_data();
 $ck('Reject shape: '.$body,$r->get_status()===200&&($data['code']??null)==='invalid_input');
 $ck('No worker repair: '.$body,!wp_next_scheduled($hook));
}
foreach(['{}','[]',''] as $body){wp_clear_scheduled_hook($hook);$d=$send($body)->get_data();$ck('Authorized empty request can repair: '.($body?:'no body'),($d['data']['recovery']['scheduled']??false)===true&&(bool)wp_next_scheduled($hook));}
M\Store::remove('schedule','qa-shape',M\Store::get('schedule','qa-shape')['revision']);wp_clear_scheduled_hook($hook);
$secret=['mistyped_field'=>'SENTINEL-QA-only'];$a=M\Api::dispatch('get-connection',['connection_id'=>$secret]);$aud=M\Audit::list([]);
$hit=false;foreach($aud['events'] as $event)if($event['operation']==='get-connection'&&$event['code']==='invalid_input'){$hit=true;$ck('Rejected ID is not retained in audit',array_key_exists('connection_id',$event)&&$event['connection_id']===null&&!str_contains(wp_json_encode($event),'SENTINEL-QA-only'));break;}
$ck('Refusal is still audited',$a['code']==='invalid_input'&&$hit);
M\Api::dispatch('get-connection',['connection_id'=>'qa-missing']);$ck('Valid identifier kept for business failure',in_array('qa-missing',array_column(M\Audit::list([])['events'],'connection_id'),true));
wp_set_current_user(0);$ck('Unauthenticated malformed request refused before execution',in_array($send('"x"')->get_status(),[401,403],true));wp_set_current_user(1);
$ck('No external HTTP',$remote===0);
$failed=count(array_filter($checks,fn($v)=>!$v['passed']));echo wp_json_encode(['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>$failed])."\n";exit($failed?1:0);
