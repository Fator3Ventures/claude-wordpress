<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();wp_set_current_user(1);
$checks=[];$verify=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$verify('Effective Meta '.F3QA_CANDIDATE,M\Config::VERSION===F3QA_CANDIDATE);
$verify('Only Meta active',get_option('active_plugins')===['wp-mcp-meta-fator3/wp-mcp-meta-fator3.php']);
$h=M\Api::dispatch('health');$verify('First health read succeeds without repair',$h['success']&&$h['data']['storage_ready']===true&&$h['data']['repair']==='not_attempted');
$registered=array_filter(array_keys(wp_get_abilities()),static fn($n)=>str_starts_with($n,M\Config::PREFIX.'/'));
$published=json_decode(file_get_contents(M\Config::DIR.'docs/input-schemas.json'),true,512,JSON_THROW_ON_ERROR);
$verify('Operation count agrees across schemas, registered abilities and published schemas ('.count(M\Schemas::all()).')',count(M\Schemas::all())===count($registered)&&array_keys(M\Schemas::all())===array_keys($published)&&count($registered)>0);
$dir=realpath(M\Config::DIR);$manifest=json_decode(file_get_contents($dir.'/manifest.sha256.json'),true,512,JSON_THROW_ON_ERROR);
$actual=[];foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir,FilesystemIterator::SKIP_DOTS)) as $f){
    $name=substr($f->getPathname(),strlen($dir)+1);if($name!=='manifest.sha256.json')$actual[$name]=hash_file('sha256',$f->getPathname());
}
ksort($actual);ksort($manifest);$verify('Complete runtime matches manifest with no unexpected files',$actual===$manifest);
$docs=M\Documentation::read(['document'=>'index']);$idx=array_column($docs['documents'],'document');
$expected=array_map('basename',glob($dir.'/docs/*'));sort($idx);sort($expected);
$verify('Document catalogue contains exactly the installed documents',$idx===$expected);
foreach($docs['documents'] as $d){
    $at=0;$text='';$ok=true;
    do{
        $v=M\Documentation::read(['document'=>$d['document'],'offset'=>$at,'expected_revision'=>$d['sha256'],'limit_bytes'=>16384]);
        $next=$v['next_offset'];if($v['offset']!==$at||$v['revision']!==$d['sha256']||$v['plugin_version']!==F3QA_CANDIDATE||$v['title']!==$d['title']||($next!==null&&$next<=$at)){$ok=false;break;}
        $at=$next;$text.=$v['content'];
    }while($at!==null);
    $verify('Document integrity: '.$d['document'],$ok&&strlen($text)===$d['bytes']&&hash('sha256',$text)===$d['sha256']&&$text===file_get_contents($dir.'/docs/'.$d['document']));
}
$q=new WP_REST_Request('POST','/f3-meta/v1/health');$q->set_header('Content-Type','application/json');$q->set_body('{}');$verify('Native REST health succeeds',rest_do_request($q)->get_status()===200);
$u=wp_create_user('qa022sub',wp_generate_password(),'qa022sub@example.invalid');if(is_wp_error($u))throw new RuntimeException('Subscriber setup failed');(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);$verify('Native REST rejects subscriber',rest_do_request($q)->get_status()===403);wp_set_current_user(1);
$r=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>M\Config::VERSION,'abilities_api_available'=>function_exists('wp_get_ability'),'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed']))];echo wp_json_encode($r)."\n";exit($r['failed']?1:0);
