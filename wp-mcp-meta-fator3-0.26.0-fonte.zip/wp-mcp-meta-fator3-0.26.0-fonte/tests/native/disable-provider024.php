<?php
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/plugin.php';deactivate_plugins('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');
