<?php
use Fator3\McpFiles\Persistence;
use WpMcpUltimate\Server\Abilities\ExecuteAbilityAbility;
use WpMcpUltimate\Server\Abilities\DiscoverAbilitiesAbility;
use WpMcpUltimate\Server\Abilities\GetAbilityInfoAbility;
use Fator3\Meta\Config;
require __DIR__.'/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();
wp_set_current_user(1);
require_once ABSPATH.'wp-admin/includes/plugin.php';
$checks=[];
function checkCombination(string $name,bool $ok): void {
    global $checks;
    $checks[]=['name'=>$name,'passed'=>$ok];
    if (!$ok) fwrite(STDERR,"Failed: ".$name."\n");
}
$expected=['wp-mcp-meta-fator3'=>F3QA_CANDIDATE,'base-site-core-fator3'=>'1.85.1','wp-mcp-fator3'=>'0.45.0','wp-mcp-google-fator3'=>'0.34.0','wp-mcp-pipedrive-fator3'=>'0.10.0','wp-mcp-linkedin-fator3'=>'0.22.0'];
foreach($expected as $slug=>$version){
    $file=$slug.'/'.$slug.'.php';
    checkCombination($slug.' active '.$version,is_plugin_active($file) && get_plugin_data(WP_PLUGIN_DIR.'/'.$file,false,false)['Version']===$version);
}
$id='integration:user:1';
Persistence::put('connections',$id,['user_id'=>1,'connection_id'=>$id,'profile'=>'maintenance','status'=>'active','policy_version'=>1,'time'=>time(),'expires'=>0],true);
function metaRead(string $op,array $input=[]): array {
    $r=ExecuteAbilityAbility::execute(['ability_name'=>'meta/'.$op,'parameters'=>$input]);
    if(empty($r['success']) || empty($r['data']['success'])) throw new RuntimeException($op.' failed: '.($r['error_code']??$r['error']??'missing success'));
    return $r['data']['data'];
}
$discover=DiscoverAbilitiesAbility::execute(['prefix'=>'meta/','per_page'=>100]);
checkCombination('Discover 47 Meta operations',count($discover['abilities']??[])===47);
$info=GetAbilityInfoAbility::execute(['ability_name'=>'meta/documentation']);
checkCombination('Discover documentation schema',isset($info['input_schema']['properties']['document']));
foreach(['monitoring-consumers','ads-consumers'] as $op){
    $rows=metaRead($op)['consumers'];
    checkCombination($op.' registers Core 1.80.0',count(array_filter($rows,fn($r)=>$r['consumer_id']==='base-site-core-fator3' && $r['version']==='1.85.1'))===1);
}
$health=metaRead('health');
checkCombination('Healthy local Meta through MCP',$health['storage_ready'] && $health['crypto_ready'] && $health['state']==='ok');
checkCombination('Self-test through MCP',metaRead('selftest')['local_checks_ok']===true);
$pages=0;
foreach(metaRead('documentation',['document'=>'index'])['documents'] as $doc){
    $text='';$at=0;
    do {
        $page=metaRead('documentation',['document'=>$doc['document'],'limit_bytes'=>8192,'expected_revision'=>$doc['sha256'],'offset'=>$at]);
        ++$pages;
        if($page['offset']!==$at || $page['plugin_version']!==Config::VERSION || $page['returned_bytes']!==strlen($page['content'])) throw new RuntimeException('Non-contiguous or mixed document');
        $text.=$page['content'];$at=$page['next_offset'];
    }while($at!==null);
    checkCombination('MCP bytes and revision: '.$doc['document'],strlen($text)===$doc['bytes'] && hash('sha256',$text)===$doc['sha256'] && $text===file_get_contents(Config::DIR.'docs/'.$doc['document']));
}
$failed=count(array_filter($checks,fn($r)=>!$r['passed']));
echo wp_json_encode(['version'=>Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'pages'=>$pages,'total'=>count($checks),'failed'=>$failed])."\n";
exit($failed?1:0);
