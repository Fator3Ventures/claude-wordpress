<?php
use Fator3\Meta as M;
use Fator3\McpFiles\ConnectionContext as Context;
use Fator3\McpFiles\Persistence as Policies;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$checks=[];function check26($name,$ok){global $checks;$checks[]=['name'=>$name,'passed'=>(bool)$ok];}
$owner=wp_insert_user(['user_login'=>'qa26owner','user_pass'=>wp_generate_password(40),'role'=>'administrator']);wp_set_current_user($owner);
$selection=['connection_id'=>'qa26-local','account_id'=>'160'];$id='qa26-reader';$s=$selection+['consumer_id'=>$id];$reports=['ads_activity','dataset_quality'];$resources=['reports'=>$reports,'dataset_ids'=>['161']];
M\Connections::save(['connection_id'=>'qa26-local','assets'=>['ads'=>['160'],'dataset'=>['161']],'expected_revision'=>0,'enabled'=>true]);
$cfg=$selection+['revision'=>'1','ready'=>true];$ad=M\AdsReader::register_consumer($id,'1.0.0',M\AdsReader::CONTRACT,static function()use(&$cfg){return $cfg;});
$mo=M\MonitoringReader::register_consumer($id,'1.0.0',M\MonitoringReader::CONTRACT,static function()use(&$cfg,$resources){return $cfg+$resources;});
$login=static function($key,$profile)use($owner){$v=['user_id'=>$owner,'grant_id'=>$key,'profile'=>$profile,'status'=>'active','expires'=>time()+180];Policies::put('oauth-grants',$key,$v,true);Context::oauth($v);return $v;};
$a=$login('qa26-previous','maintenance');
$save=static fn($type,$rev,$on,$extra=[])=>M\Api::dispatch('save-'.$type.'-grant',$s+['enabled'=>$on,'expected_revision'=>$rev]+$extra,true);
$gethealth=static fn()=>M\Api::dispatch('health')['data']??[];
$fields=static fn($r,$kind)=>array_values(array_filter($r['consumer_grants']??[],static fn($g)=>$g['resource']===$kind))[0]??[];
$r=$save('ads',0,true,['allow_ad_origin'=>true]);$m=$save('monitoring',0,true,$resources);
check26('Authorized MCP writes both grants',!empty($r['success'])&&!empty($m['success']));
$key=hash('sha256',M\Util::json([$id,$selection['connection_id'],$selection['account_id']]));
$stored=M\Store::get('ads_grant',$key);
check26('New grants do not store a transport policy',isset($stored['value']['principal']['user_id'])&&$stored['value']['principal']['channel']===null);
// Create dated local history through the normal ingestion path; later prove actual payload delivery.
$day=gmdate('Y-m-d',time()-86400);$basic=['connection_id'=>'qa26-local','api_version'=>M\Config::API_VERSION,'temporal'=>'daily','timezone'=>'UTC','currency'=>'BRL','fetched_at'=>gmdate('c'),'coverage'=>[]];
foreach([['ads','ads_insights','160','campaign'],['ads','ads_activity','160',''],['dataset','dataset_quality','161','']] as [$ch,$rep,$acc,$lvl]){
 $q=$basic+['channel'=>$ch,'report'=>$rep,'account_id'=>$acc,'selection'=>$ch==='dataset'?['ads_account_id'=>'160']:['ads_level'=>'campaign'],'rows'=>[['id'=>'qa-row-'.$rep,'entity_id'=>'qa-row-'.$rep,'record_kind'=>'event_counts','date'=>$day]]];
 M\History::ingest($q,M\Access::principal(),M\Connections::get('qa26-local'),'qa26-grant');
}
// Legacy shape: same explicit permissions, previous MCP snapshot still present in the encrypted value.
foreach(['ads_grant','monitoring_grant'] as $type){$r=M\Store::get($type,$key);$v=$r['value'];$v['principal']=M\Access::principal();M\Store::put($type,$key,$v,$r['revision']);}
$before=$gethealth();check26('Local health reports both active resources and repair operations',($fields($before,'ads')['state']??'')==='ready'&&($fields($before,'monitoring')['repair_operation']??'')==='meta/save-monitoring-grant');
$original=M\Access::principal();$a['status']='revoked';Policies::put('oauth-grants',$a['grant_id'],$a);
check26('Revoked administrative transport cannot rewrite a grant',$save('ads',2,true)['code']==='not_authorized');
try{M\Access::checkPrincipal($original);$blocked=false;}catch(M\Fault $e){$blocked=$e->reason==='not_authorized';}
check26('Original job/interactive principal still requires its valid credential',$blocked);
$b=$login('qa26-replacement','maintenance');check26('Distinct authorized replacement transport exists',M\Access::principal()['channel']['connection_id']==='grant:qa26-replacement');
Context::restore_identity(null,0);$window=['date_from'=>$day,'date_to'=>$day];
$as=$ad->status($selection);$ms=$mo->status($selection);
check26('Registered SDK clients remain ready in cron after MCP rotation',!empty($as['data']['ready'])&&!empty($ms['data']['ready']));
check26('The old explicit ad-origin opt-in survives',($as['data']['allow_ad_origin']??false)===true);
foreach([['ads',$ad->query($selection+$window)],['monitoring',$mo->query($selection+$window+['report'=>'ads_activity'])],['dataset',$mo->query($selection+$window+['report'=>'dataset_quality','dataset_id'=>'161'])]] as [$label,$r])check26('Reads actual stored row after rotation: '.$label,count($r['data']['rows']??[])===1);
check26('Wrong account and dataset are denied',$ad->status(array_replace($selection,['account_id'=>'777']))['code']==='consumer_scope_mismatch'&&$mo->query($selection+$window+['report'=>'dataset_quality','dataset_id'=>'999'])['success']===false);
Context::restore_identity(null,1);
$h=$gethealth();check26('Existing grants become effective without rewriting a revision',($fields($h,'ads')['revision']??0)===2&&($fields($h,'ads')['state']??'')==='ready'&&M\Store::get('ads_grant',$key)['value']['principal']['channel']!==null);
$user=new WP_User($owner);$user->set_role('subscriber');$h=$gethealth();$f=$fields($h,'monitoring');
check26('Role loss blocks both SDKs and exposes the real reason',($f['reason']??null)==='not_authorized'&&($f['state']??null)==='blocked'&&$ad->status($selection)['code']==='not_authorized'&&$mo->status($selection)['code']==='not_authorized'&&$h['state']==='degraded');
$user->set_role('administrator');$cfg['revision']='2';$h=$gethealth();check26('Configuration revision blocks both readers',($fields($h,'ads')['reason']??null)==='revision_conflict'&&$mo->status($selection)['code']==='revision_conflict');$cfg['revision']='1';
wp_set_current_user($owner);Context::oauth($b);$r=$save('ads',2,true);check26('New connector preserves unchanged explicit opt-in',($r['data']['allow_ad_origin']??false)===true);
$r=$save('ads',3,false);$m=$save('monitoring',2,false,$resources);$h=$gethealth();check26('Explicit revocation stays effective; health distinguishes disabled',$r['success']&&$m['success']&&$ad->status($selection)['code']==='grant_revoked'&&$mo->status($selection)['code']==='grant_revoked'&&($fields($h,'ads')['state']??'')==='disabled');
check26('Stale revision cannot restore the grant',$save('ads',1,true)['code']==='revision_conflict');
$h=json_encode($gethealth()['consumer_grants']??[]);check26('Health excludes user and transport policy',!str_contains($h,'qa26-previous')&&!str_contains($h,'qa26-replacement')&&!str_contains($h,'user_id'));
wp_set_current_user(0);check26('Anonymous caller cannot read grant health',M\Api::dispatch('health')['code']==='not_authorized');
$out=['total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'meta'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks];echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
