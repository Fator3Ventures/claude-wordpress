<?php
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
require_once ABSPATH.'wp-admin/includes/plugin.php';wp_set_current_user(1);
$r=activate_plugin('base-site-core-fator3/base-site-core-fator3.php');
if(is_wp_error($r))throw new RuntimeException($r->get_error_code());echo wp_json_encode(['core'=>F3BASE_PLUGIN_VERSAO,'activated'=>true])."\n";
