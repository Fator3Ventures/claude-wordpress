<?php
require __DIR__.'/guard.php';
$_SERVER['HTTP_HOST']='example.invalid';$_SERVER['SERVER_NAME']='example.invalid';$_SERVER['REQUEST_URI']='/';
define('WP_INSTALLING',true);
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();
require_once ABSPATH.'wp-admin/includes/upgrade.php';
require_once ABSPATH.'wp-admin/includes/plugin.php';
if(is_blog_installed())throw new RuntimeException('Expected fresh tables');
$flavor=getenv('F3_LAB_FLAVOR');
if(!in_array($flavor,['current','baseline','upgrade'],true))throw new RuntimeException('Invalid installation flavor');
$expected=$flavor==='current'?F3QA_CANDIDATE:F3QA_BASE;
wp_install('Meta isolated review','qa022admin','qa022@example.invalid',false,'',bin2hex(random_bytes(20)),'pt_BR');
wp_set_current_user(1);
$r=activate_plugin('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');
if(is_wp_error($r))throw new RuntimeException($r->get_error_code());
if(Fator3\Meta\Config::VERSION!==$expected)throw new RuntimeException('Unexpected activated version');
// A7: estado da migração do histórico lido logo após a ativação, antes de qualquer manutenção (WP-Cron desligado no laboratório).
$migration=Fator3\Meta\Store::get('migration','history-020');
file_put_contents(f3qa022_root().'/evidence/activation.json',wp_json_encode(['version'=>Fator3\Meta\Config::VERSION,'flavor'=>$flavor,'migration'=>$migration['value']??null,'result_pages'=>count(Fator3\Meta\Store::scan('result','',100))]));
$summary=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'version'=>Fator3\Meta\Config::VERSION,'flavor'=>$flavor,'active_plugins'=>get_option('active_plugins'),'installed'=>true];
if($flavor==='upgrade'){$summary['seed']=require __DIR__.'/migration-seed.php';}
echo wp_json_encode($summary)."\n";
