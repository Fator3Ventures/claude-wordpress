<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
require __DIR__.'/seed-connection090.php';
$cfg=array_replace(F3Base_Meta_Ads::padroes(),['ativo'=>true,'conexao'=>'qa-origin','conta_id'=>'160','revisao'=>1]);F3Base_Options::gravar(F3Base_Meta_Ads::OPTION,$cfg);
if(!F3Base_Meta_Ads::configuracao()['ready'])throw new RuntimeException('Core configuration failed.');
lab_seed_connection090(['connection_id'=>'qa-origin','expected_revision'=>0,'token'=>'qa-fixture-token','assets'=>['ads'=>['160']],'users'=>[1],'enabled'=>true]);
$row=M\Store::get('connection','qa-origin');$v=$row['value'];$v['token_identity']=['app_verified'=>true,'validated_generation'=>$v['credential_generation'],'scopes'=>['ads_read']];M\Store::put('connection','qa-origin',$v,$row['revision']);
if(getenv('F3_UI_SEED')){echo '{"seeded":true}';return;}
$checks=[];function ck24($n,$ok){global $checks;$checks[]=['name'=>$n,'passed'=>(bool)$ok];}
$scope=['consumer_id'=>F3Base_Meta_Ads::CONSUMER,'connection_id'=>'qa-origin','account_id'=>'160'];$core=fn($id='410',$a='160')=>F3Base_Meta_Ads::anuncio_origem($a,$id);
$save=fn($rev,$flag=null,$enabled=true)=>M\Api::dispatch('save-ads-grant',$scope+['enabled'=>$enabled,'expected_revision'=>$rev]+($flag===null?[]:['allow_ad_origin'=>$flag]));
function reply24($x,$code=200){return ['response'=>['code'=>$code,'message'=>'fixture'],'headers'=>[],'body'=>wp_json_encode($x),'cookies'=>[]];}
$mode='image';$req=[];$a='https://cdn.fbcdn.net/img.jpg?oe=70000001';$h=str_repeat('a',32);$h2=str_repeat('b',32);
add_filter('pre_http_request',static function($pre,$args,$url)use(&$req,&$mode,$a,$h,$h2,$scope){
 $p=parse_url($url);$path=preg_replace('~^/v[0-9.]+/~','',$p['path']);parse_str($p['query']??'',$q);$req[]=[$args['method'],$p['host'],$path,$q];
 if($path==='act_160/ads'){
  $ad=['id'=>'410','name'=>'Anúncio alfa','account_id'=>'160','campaign_id'=>'309','campaign'=>['id'=>'309','name'=>'Campanha'],'adset_id'=>'311','adset'=>['id'=>'311','name'=>'Conjunto']];
  $creative=['id'=>'515','body'=>'Corpo','effective_object_story_id'=>'1_2','instagram_permalink_url'=>'https://www.instagram.com/p/ref/',
   'object_story_spec'=>['link_data'=>['message'=>'Texto do anúncio','name'=>'Título','description'=>'Descrição','call_to_action'=>['type'=>'LEARN_MORE','value'=>['link'=>'https://site.example/origem']],'image_hash'=>$h]]];
  if($mode==='foreign')$ad['account_id']='161';
  if($mode==='missing')return reply24(['data'=>[]]);
  if($mode==='wrong-ad')$ad['id']='411';
  if($mode==='token')return reply24(['error'=>['code'=>190]],400);
  if($mode==='revoked')M\AdsReader::save($scope+['enabled'=>false,'expected_revision'=>M\AdsReader::grant($scope)['revision']]);
  if($mode==='dynamic')$creative=['id'=>'516','asset_feed_spec'=>['bodies'=>[['text'=>'A'],['text'=>'B']],'images'=>[['hash'=>$h],['hash'=>$h2]]]];
  if($mode==='carousel')$creative=['object_story_spec'=>['link_data'=>['child_attachments'=>[['name'=>'Card A','link'=>'https://a.example/x'],['name'=>'Card B','link'=>'https://b.example/y']]]]];
  if(str_starts_with($mode,'video'))$creative=['id'=>'517','object_story_spec'=>['video_data'=>['message'=>'Vídeo','video_id'=>'617']],'thumbnail_url'=>$a];
  if($mode==='secret')$creative=['image_url'=>'https://cdn.fbcdn.net/x?access_token=secret','link_url'=>'javascript:alert(1)','thumbnail_url'=>'https://example.com/not-meta'];
  if($mode==='post')$creative=['id'=>'1','effective_object_story_id'=>'1_2'];
  $ad['creative']=$creative;return reply24(['data'=>[$ad]]);
 }
 if($path==='act_160/adimages')return reply24(['data'=>[['hash'=>$h,'url'=>$a],['hash'=>$h2,'url'=>'https://cdn.fbcdn.net/b.png']]]);
 if($path==='617')return $mode==='video-denied'?reply24(['error'=>['code'=>200]],403):reply24(['id'=>'617','source'=>'https://video.fbcdn.net/clip.mp4','picture'=>$a]);
 if($path==='1_2')return reply24(['id'=>'1_2','message'=>'Texto da publicação','attachments'=>['data'=>[['title'=>'Título da publicação','media'=>['image'=>['src'=>$a]]]]]]);
 throw new RuntimeException('Unexpected provider request');
},2,3);
$ab=wp_get_ability('meta/save-ads-grant');$desc=$ab->get_description();$input=$ab->get_input_schema();
ck24('Discoverable grant explains online lookup and local save',str_contains($desc,'anúncio de origem')&&str_contains($desc,'configuração local')&&str_contains($input['properties']['allow_ad_origin']['description'],'GET')&&M\Api::effects('save-ads-grant')['remote_effect']==='none');
ck24('Core registered on the real hook',F3Base_Meta_Ads::status()['sdk']==='registrado'&&F3BASE_PLUGIN_VERSAO==='1.80.0');
ck24('No grant, no HTTP',$core()['codigo']==='grant_revoked'&&!$req);
$r=$save(0);ck24('Legacy grant permits local history only',$r['success']&&!$r['data']['allow_ad_origin']&&F3Base_Meta_Ads::status()['pronto']&&$core()['codigo']==='ad_origin_not_granted'&&!$req);
ck24('Core rejects foreign selection and nonnumeric IDs before HTTP',$core('410','161')['codigo']==='conta_sem_selecao_compativel'&&!$core('https://other.example/')['ok']&&!$req);
ck24('Explicit admin opt-in',$save(1,true)['success']&&M\AdsReader::grant($scope)['allow_ad_origin']);
ck24('Stale admin write rejected',$save(1,false)['code']==='revision_conflict');
$hget=$core();$d=$hget['origem'];$c=$d['creative']??[];
ck24('Core → registered SDK → scoped Graph hierarchy',($d['ad']['name']??'')==='Anúncio alfa'&&$d['adset']===['id'=>'311','name'=>'Conjunto']&&$d['campaign']===['id'=>'309','name'=>'Campanha']);
ck24('Copy, title, description, CTA and destination',($c['primary_text']??'')==='Texto do anúncio'&&$c['title']==='Título'&&$c['description']==='Descrição'&&$c['button']==='LEARN_MORE'&&$c['destination']==='https://site.example/origem');
ck24('Image hash resolves only in scoped account; expiry provenance',($c['image']['url']??'')===$a&&$c['image']['expiry_source']==='cdn_oe_hint'&&$c['image']['expires_at']===gmdate('c',hexdec('70000001'))&&$c['media_type']==='image'&&$c['image_url']===$a);
ck24('Post identifiers and Ads Manager deep link',($c['effective_object_story_id']??'')==='1_2'&&$c['instagram_permalink_url']==='https://www.instagram.com/p/ref/'&&$d['ads_manager_url']==='https://adsmanager.facebook.com/adsmanager/manage/ads?act=160&selected_ad_ids=410');
ck24('Account path, exact ID filter and bounded image lookup',count($req)===2&&$req[0][2]==='act_160/ads'&&json_decode($req[0][3]['filtering'],true)===[['field'=>'ad.id','operator'=>'IN','value'=>['410']]]&&$req[1][2]==='act_160/adimages');
foreach(['foreign'=>'asset_access_denied','wrong-ad'=>'asset_access_denied','missing'=>'resource_not_found','token'=>'token_rejected'] as $mode=>$code){$n=count($req);$r=$core();ck24('Scope/error isolation: '.$mode,$r['codigo']===$code&&$r['origem']===null&&count($req)===$n+1);}
$mode='video';$r=$core()['origem']['creative'];ck24('Actual video playback and thumbnail; no invented expiry',$r['video_id']==='617'&&$r['playback']['url']==='https://video.fbcdn.net/clip.mp4'&&$r['thumbnail']['url']===$a&&$r['playback']['expires_at']===null&&$r['playback_url']===$r['playback']['url']);
$mode='video-denied';$r=$core()['origem'];ck24('Unavailable video keeps thumbnail and precise notice',$r['creative']['playback']===null&&$r['creative']['thumbnail']!==null&&in_array('video:asset_access_denied',$r['notices'],true));
$mode='dynamic';$r=$core()['origem']['creative'];ck24('Dynamic alternatives preserved without a fabricated match',$r['media_type']==='dynamic'&&$r['primary_text']===null&&$r['variants']['primary_text']===['A','B']&&count($r['media_variants'])===2&&$r['media_variants'][1]['image']['url']==='https://cdn.fbcdn.net/b.png');
$mode='carousel';$r=$core()['origem']['creative'];ck24('Carousel retains card positions and destinations',$r['media_type']==='carousel'&&$r['cards'][0]['title']==='Card A'&&$r['cards'][1]['destination']==='https://b.example/y');
$mode='secret';$r=$core()['origem'];ck24('Reject bearer query strings, non-HTTPS links and foreign media origins',!str_contains(wp_json_encode($r),'secret')&&$r['creative']['image']===null&&$r['creative']['destination']===null&&$r['creative']['thumbnail']===null);
$mode='post';$r=$core()['origem'];ck24('Post-backed creative follows only returned story',$r['creative']['primary_text']==='Texto da publicação'&&$r['creative']['image']['url']===$a);
$n=count($req);$mode='revoked';$r=$core();ck24('Revocation during GET: no data and no subsequent provider call',!$r['ok']&&$r['origem']===null&&count($req)===$n+1);
$rev=M\AdsReader::grant($scope)['revision'];$save($rev);ck24('Regrant after revoke never silently restores remote privilege',$core()['codigo']==='ad_origin_not_granted');
$clone=new M\AdsReaderClient();$n=count($req);ck24('Fabricated SDK client refused',$clone->ad_origin(['connection_id'=>'qa-origin','account_id'=>'160','ad_id'=>'410'])['code']==='not_authorized'&&count($req)===$n);
$user=wp_create_user('originreader',wp_generate_password());wp_set_current_user($user);ck24('Subscriber cannot change the grant',$save(M\Store::get('ads_grant',hash('sha256',M\Util::json(array_values($scope))))['revision']??3,true)['success']===false);wp_set_current_user(1);
ck24('Every remote operation GET on graph.facebook.com',!!$req&&!array_filter($req,fn($x)=>$x[0]!=='GET'||$x[1]!=='graph.facebook.com'));
$r=M\Audit::list([]);ck24('Audit stores no ad copy, signed URLs or token',!preg_match('~Texto do anúncio|fbcdn|qa-fixture-token~u',M\Util::json($r)));
$out=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'meta'=>M\Config::VERSION,'core_experimental'=>F3BASE_PLUGIN_VERSAO,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($c)=>!$c['passed'])),'checks'=>$checks];echo wp_json_encode($out)."\n";exit($out['failed']?1:0);
