<?php
require __DIR__.'/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();
wp_set_current_user(1);
require_once ABSPATH.'wp-admin/includes/plugin.php';
$plugins=['base-site-core-fator3','wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-linkedin-fator3','wp-mcp-pipedrive-fator3'];
foreach ($plugins as $slug) {
    $r=activate_plugin($slug.'/'.$slug.'.php');
    if (is_wp_error($r)) throw new RuntimeException($slug.': '.$r->get_error_code());
}
echo wp_json_encode(['active'=>get_option('active_plugins')])."\n";
