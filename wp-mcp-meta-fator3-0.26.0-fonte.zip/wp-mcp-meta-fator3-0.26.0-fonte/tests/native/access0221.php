<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$checks=[];$ck=static function($name,$ok)use(&$checks){$checks[]=['name'=>$name,'passed'=>(bool)$ok];};
$c='qa-grant0221';M\Connections::save(['connection_id'=>$c,'label'=>'Somente laboratório','users'=>[1],'expected_revision'=>0]);
$args=['get-connection'=>['connection_id'=>$c],'save-connection'=>['connection_id'=>$c,'label'=>'Alteração não autorizada','expected_revision'=>1],'documentation'=>['document'=>'index']];
$u=wp_create_user('review0221reader',wp_generate_password(),'review0221@example.invalid');if(is_wp_error($u))throw new RuntimeException('fixture');
(new WP_User($u))->set_role('subscriber');wp_set_current_user($u);$http=0;add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('qa_blocked');},1);
foreach($args as $op=>$in){
 $q=new WP_REST_Request('POST','/'.M\Config::REST.'/'.$op);$q->set_header('Content-Type','application/json');$q->set_body(wp_json_encode($in));
 $ability=wp_get_ability('meta/'.$op);
 $ck('REST subscriber denied: '.$op,rest_do_request($q)->get_status()===403);
 $ck('Registered ability subscriber denied: '.$op,$ability&&is_wp_error($ability->execute($in)));
}
wp_set_current_user(1);$ck('Denied write preserved label and revision',M\Connections::get($c)['label']==='Somente laboratório'&&M\Connections::get($c)['revision']===1);
$before=count(M\Store::scan('audit','',100));$doc=M\Api::dispatch('documentation',['document'=>'README.md']);
$ck('Static help does not append audit or contact provider',$doc['success']&&count(M\Store::scan('audit','',100))===$before&&$http===0);
$failed=count(array_filter($checks,fn($v)=>!$v['passed']));echo wp_json_encode(['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>$failed])."\n";exit($failed?1:0);
