<?php
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
F3Base_Options::gravar(F3Base_Meta_Ads::OPTION,array_replace(F3Base_Meta_Ads::padroes(),['ativo'=>true,'conexao'=>'qa-origin','conta_id'=>'160','revisao'=>1]));
$calls=0;add_filter('pre_http_request',static function()use(&$calls){$calls++;return new WP_Error('forbidden');});
$r=F3Base_Meta_Ads::anuncio_origem('160','410');$ok=$r===['ok'=>false,'codigo'=>'extensao_origem_indisponivel','origem'=>null]&&$calls===0&&!class_exists('Fator3\Meta\AdsReader');
echo wp_json_encode(['total'=>1,'failed'=>$ok?0:1,'checks'=>[['name'=>'Full experimental Core active without provider: explicit absence and zero HTTP','passed'=>$ok]]])."\n";exit($ok?0:1);
