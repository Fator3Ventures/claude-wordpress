<?php
/**
 * Mapa de efeitos por operação lido do registro de habilidades do WordPress (anotações e metadados fator3).
 * Roda igual na base e na candidata; a comparação fica em tests/native/effects-compare.py.
 */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
$map=[];
foreach(wp_get_abilities() as $a){
    if(!str_starts_with($a->get_name(),M\Config::PREFIX.'/'))continue;
    $m=$a->get_meta();$map[substr($a->get_name(),strlen(M\Config::PREFIX)+1)]=['mode'=>$m['fator3']['mode'],'local_effect'=>$m['fator3']['local_effect'],'remote_effect'=>$m['fator3']['remote_effect'],'readonly'=>$m['annotations']['readonly'],'destructive'=>$m['annotations']['destructive'],'idempotent'=>$m['annotations']['idempotent']];
}
ksort($map);
echo wp_json_encode(['version'=>M\Config::VERSION,'source'=>'wp_get_abilities','operations'=>count($map),'effects'=>$map],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\n";
