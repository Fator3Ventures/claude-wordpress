"""Compara os mapas de efeitos da base e da candidata (saídas de effects-map.php).

uso: python3 tests/native/effects-compare.py <mapa_base.json> <mapa_candidata.json>
Reprova se o conjunto de operações ou qualquer valor (mode, local_effect, remote_effect, readonly, destructive, idempotent) divergir.
"""
import json, sys
base, cand = (json.load(open(p, encoding='utf-8')) for p in sys.argv[1:3])
diff = []
for op in sorted(set(base['effects']) | set(cand['effects'])):
    a, b = base['effects'].get(op), cand['effects'].get(op)
    if a != b:
        diff.append({'operation': op, 'base': a, 'candidate': b})
out = {'base_version': base['version'], 'candidate_version': cand['version'], 'base_operations': len(base['effects']),
       'candidate_operations': len(cand['effects']), 'fields_compared': sorted({k for v in base['effects'].values() for k in v}),
       'differences': diff, 'identical': not diff and bool(base['effects'])}
print(json.dumps(out, ensure_ascii=False, indent=2))
sys.exit(0 if out['identical'] else 1)
