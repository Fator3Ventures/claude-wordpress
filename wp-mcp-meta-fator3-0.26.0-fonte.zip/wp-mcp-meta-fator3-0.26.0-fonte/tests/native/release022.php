<?php
/**
 * Verificações da rodada 0.22.0 (A1, A2, A7, A8, C6 e efeitos por operação) no WordPress isolado.
 * Não exige a versão candidata: rodada contra a base (setup baseline) serve de reprodução e deve reprovar os itens corrigidos.
 */
use Fator3\Meta as M;
require __DIR__.'/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
require_once ABSPATH.'wp-admin/includes/plugin.php';
$checks=[];$ck=static function(string $name,bool $ok,array $info=[])use(&$checks){$checks[]=['name'=>$name,'passed'=>$ok]+($ok||!$info?[]:['info'=>$info]);};
$http=0;add_filter('pre_http_request',static function()use(&$http){++$http;return new WP_Error('qa022_blocked');},1);
$rest=static function(string $op,array $input){$q=new WP_REST_Request('POST','/'.M\Config::REST.'/'.$op);$q->set_header('Content-Type','application/json');$q->set_body(wp_json_encode($input));$r=rest_do_request($q);return ['status'=>$r->get_status(),'body'=>wp_json_encode($r->get_data())];};

// ---- A1: recusa de schema nomeia o parâmetro, sem ecoar o valor enviado.
$s='SENTINELA'.bin2hex(random_bytes(6));
$q=['connection_id'=>'qa-a1','channel'=>'instagram','account_id'=>'1','report'=>'profile'];
$cases=[
    ['status',['desconhecido'=>$s],'desconhecido','unknown_parameter'],
    ['get-connection',[],'connection_id','missing_required'],
    ['list-connections',['offset'=>$s],'offset','invalid_type'],
    ['list-connections',['offset'=>100001],'offset','out_of_range'],
    ['admin-options',['kind'=>$s],'kind','invalid_value'],
    ['admin-options',['kind'=>'users','search'=>str_repeat('x',101)],'search','out_of_range'],
    ['get-connection',['connection_id'=>'-'.$s],'connection_id','invalid_format'],
    ['documentation',['limit_bytes'=>10],'limit_bytes','out_of_range'],
    ['create-job',['query'=>['report'=>$s]+$q,'idempotency_key'=>'qa-a1'],'query.report','invalid_value'],
    ['create-job',['query'=>array_diff_key($q,['report'=>1]),'idempotency_key'=>'qa-a1'],'query.report','missing_required'],
    ['create-job',['query'=>$q+['extra'=>$s],'idempotency_key'=>'qa-a1'],'query.extra','unknown_parameter'],
    ['create-job',['query'=>$q+['limit'=>$s],'idempotency_key'=>'qa-a1'],'query.limit','invalid_type'],
    ['save-connection',['connection_id'=>'qa-a1','expected_revision'=>0,'users'=>[1,1]],'users','invalid_value'],
    ['save-connection',['connection_id'=>'qa-a1','expected_revision'=>0,'assets'=>['instagram'=>[$s]]],'assets.instagram','invalid_format'],
];
foreach($cases as [$op,$input,$field,$problem]){
    $r=M\Api::dispatch($op,$input);$d=$r['details']??[];
    $ok=!$r['success']&&$r['code']==='invalid_input'&&($d['field']??null)===$field&&($d['problem']??null)===$problem&&($d['schema']??null)===$op&&is_string($d['validation_code']??null)&&str_contains($r['message'],$field);
    $ck("A1 $op → field=$field problem=$problem",$ok,['details'=>$d,'message'=>$r['message']??null]);
    $wire=$rest($op,$input);
    $ck("A1 $op: sentinel value absent from dispatch and REST responses",!str_contains(wp_json_encode($r),$s)&&!str_contains($wire['body'],$s)&&$wire['status']===200);
}
$sem=M\Api::dispatch('history-query',['connection_id'=>'qa-a1','channel'=>'instagram','account_id'=>'1','report'=>'profile','date_from'=>'2026-01-01']);
$ck('A1 semantic validation after schema unchanged',$sem['code']==='invalid_input'&&$sem['message']==='Informe as duas datas.'&&$sem['details']===[],['got'=>$sem]);

// ---- A2: continuação sem expected_revision é entrada inválida, não conflito.
$a2=M\Api::dispatch('documentation',['document'=>'README.md','offset'=>256]);
$ck('A2 offset>0 without expected_revision → invalid_input expected_revision/missing_required',!$a2['success']&&$a2['code']==='invalid_input'&&$a2['conflict']===false&&$a2['details']===['field'=>'expected_revision','problem'=>'missing_required']&&$a2['message']==='Para continuar a leitura (offset maior que zero), informe expected_revision com o valor de revision da primeira página.',['got'=>$a2]);
$a2b=M\Api::dispatch('documentation',['document'=>'README.md','offset'=>256,'expected_revision'=>str_repeat('0',64)]);
$ck('A2 divergent revision still revision_conflict',$a2b['code']==='revision_conflict'&&$a2b['conflict']===true);
$a2c=M\Api::dispatch('documentation',['document'=>'README.md','offset'=>0]);
$ck('A2 first page without expected_revision still served',$a2c['success']&&$a2c['data']['offset']===0);

// ---- A7: instalação limpa conclui a migração na ativação; ativação sem usuário (WP-CLI) também.
$act=json_decode((string)@file_get_contents(f3qa022_root().'/evidence/activation.json'),true);
$ck('A7 clean install: history migration complete right after activation',is_array($act)&&$act['result_pages']===0&&($act['migration']['complete']??null)===true&&($act['migration']['pages']??null)===0,['activation'=>$act]);
$status=M\Api::dispatch('history-status');
$ck('A7 history-status reports migration complete before any maintenance',($status['data']['migration']['complete']??null)===true&&!did_action(M\Config::KEY.'_maintenance'),['got'=>$status['data']['migration']??null]);
deactivate_plugins('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');
$m=M\Store::get('migration','history-020');if($m)M\Store::remove('migration','history-020',$m['revision']);
$pending=M\Store::scan('result','',1)!==[];
wp_set_current_user(0);$re=activate_plugin('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');$after=M\Store::get('migration','history-020');wp_set_current_user(1);
$active=!is_wp_error($re)&&is_plugin_active('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php')&&wp_next_scheduled(M\Config::KEY.'_maintenance')!==false;
// Sem páginas (release022 rodada antes das suítes que coletam): a ativação conclui. Com páginas: a ativação não migra nem cria marca.
$ck($pending?'A7 activation without logged-in user (WP-CLI) succeeds and leaves pending pages to maintenance':'A7 activation without logged-in user (WP-CLI) succeeds and completes empty migration',$active&&($pending?$after===null:($after['value']['complete']??null)===true),['error'=>is_wp_error($re)?$re->get_error_code():null,'pending'=>$pending,'after'=>$after['value']??null]);

// ---- A8 e efeitos: registro de habilidades.
$base=f3qa022_root().'/baseline/wp-mcp-meta-fator3/docs/';
$baseLabels=json_decode((string)@file_get_contents($base.'abilities-pt-br.json'),true);$baseSchemas=json_decode((string)@file_get_contents($base.'input-schemas.json'),true);
$status=wp_get_ability(M\Config::PREFIX.'/status');
$ck('A8 meta/status label',$status&&$status->get_label()==='Meta: verificar estado e recuperar agendamento',['label'=>$status?$status->get_label():null]);
$ck('A8 meta/status description and input schema unchanged from base',is_array($baseLabels)&&$status&&$status->get_description()===$baseLabels['status']['description']&&wp_json_encode($status->get_input_schema())===wp_json_encode($baseSchemas['status']));
$documented=['health'=>1,'status'=>1,'ads-consumers'=>1,'get-ads-grant'=>1,'save-ads-grant'=>1];
$ck('Labels/descriptions outside the documented grant operations remain identical',is_array($baseLabels)&&array_diff_key(M\AbilityLabels::all(),$documented)===array_diff_key($baseLabels,$documented));
$ck('Health description includes consumer grants and preserves a read-only effect',str_contains(M\AbilityLabels::all()['health']['description'],'concessões a consumidores')&&M\Api::effects('health')['readonly']);
$abilities=array_filter(wp_get_abilities(),static fn($a)=>str_starts_with($a->get_name(),M\Config::PREFIX.'/'));
$pure=method_exists(M\Api::class,'effects');$same=$pure;
foreach($abilities as $a){if(!$pure)break;$meta=$a->get_meta();$op=substr($a->get_name(),strlen(M\Config::PREFIX)+1);$e=M\Api::effects($op);
    $fromRegistry=['mode'=>$meta['fator3']['mode'],'local_effect'=>$meta['fator3']['local_effect'],'remote_effect'=>$meta['fator3']['remote_effect'],'readonly'=>$meta['annotations']['readonly'],'destructive'=>$meta['annotations']['destructive'],'idempotent'=>$meta['annotations']['idempotent']];
    if($e!==$fromRegistry)$same=false;}
$ck('Effects: Api::effects() is the source of every registered ability annotation',$pure&&$same&&count($abilities)===count(M\Schemas::all()));

// ---- C6: índice com título, resumo e tema; leitura devolve título.
$idx=M\Api::dispatch('documentation',['document'=>'index']);$docs=$idx['data']['documents']??[];$topics=$idx['data']['topics']??null;
$files=array_map('basename',glob(M\Config::DIR.'docs/*'));sort($files);$listed=array_column($docs,'document');sort($listed);
$ck('C6 index lists exactly the installed documents',$files===$listed&&$files!==[]);
$valid=is_array($topics)&&$docs!==[];foreach($docs as $d)if(!is_string($d['title']??null)||trim($d['title'])===''||!is_string($d['summary']??null)||trim($d['summary'])===''||mb_strlen($d['summary'])>200||!isset($topics[$d['topic']??'']))$valid=false;
$ck('C6 every document has title, summary (≤200) and a known topic',$valid);
$used=array_unique(array_column($docs,'topic'));
$ck('C6 topics map covers the eight logical documents',is_array($topics)&&!array_diff(['indice','especificacao','configuracao','uso','contratos','agentes','operacao','notas'],$used));
$titles=true;foreach($docs as $d){$r=M\Api::dispatch('documentation',['document'=>$d['document'],'limit_bytes'=>256]);if(($r['data']['title']??null)!==($d['title']??'')||$r['data']['title']==='')$titles=false;}
$ck('C6 reading any document returns its catalogue title',$titles&&$docs!==[]);
$readme=M\Api::dispatch('documentation',['document'=>'README.md']);
$ck('C6 README.md read keeps documents with the new fields',($readme['data']['documents']??null)===$docs&&$docs!==[]);
$ck('No provider request during these checks',$http===0);

$o=['version'=>M\Config::VERSION,'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>count(array_filter($checks,fn($x)=>!$x['passed']))];
echo wp_json_encode($o,JSON_UNESCAPED_UNICODE)."\n";exit($o['failed']?1:0);
