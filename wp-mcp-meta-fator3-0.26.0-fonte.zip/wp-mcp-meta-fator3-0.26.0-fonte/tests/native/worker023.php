<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();
wp_set_current_user(1);
$checks = [];
function check023(string $name, bool $value): void {
    global $checks;
    $checks[] = ['name' => $name, 'passed' => $value];
}
$hook = M\Config::KEY.'_worker';
$status = static fn() => M\Api::dispatch('status')['data']['recovery'];
$maintenance = static function () {
    M\Worker::maintenance();
    return get_option(M\Config::KEY.'_last_maintenance')['recovery'];
};
check023('Idle status does not attempt a repair', $status() === ['attempted'=>false,'scheduled'=>null,'code'=>null]);
M\Store::put('schedule','qa-cron',[
    'id'=>'qa-cron','label'=>'QA cron','enabled'=>true,'interval_minutes'=>60,'next_at'=>time()+3600,
    'query'=>['connection_id'=>'missing','account_id'=>'1','channel'=>'instagram','report'=>'profile'],
],0);
wp_clear_scheduled_hook($hook);
$attempts = 0;
$reject = static function ($pre, $event) use ($hook, &$attempts) {
    if ($event->hook !== $hook) return $pre;
    ++$attempts;
    return new WP_Error('qa_schedule_denied');
};
add_filter('pre_schedule_event',$reject,10,2);
$r=$status();
check023('Failed scheduling retains the actual cron code', $r['scheduled']===false && $r['code']==='qa_schedule_denied');
check023('Failed scheduling leaves no worker', !wp_next_scheduled($hook));
check023('Maintenance records false when both scheduling attempts fail', $maintenance()===false);
check023('Both maintenance attempts ran', $attempts===3);
remove_filter('pre_schedule_event',$reject,10);
$attempts=0;
$onlyFirst=static function ($pre,$event) use ($hook,&$attempts) {
    if ($event->hook === $hook && ++$attempts===1) return new WP_Error('qa_once');
    return $pre;
};
add_filter('pre_schedule_event',$onlyFirst,10,2);
check023('Maintenance reports recovery on its second attempt', $maintenance()===true && $attempts===2 && (bool)wp_next_scheduled($hook));
remove_filter('pre_schedule_event',$onlyFirst,10);
wp_clear_scheduled_hook($hook);
check023('Authorized status restores worker', $status()===['attempted'=>true,'scheduled'=>true,'code'=>'ok'] && (bool)wp_next_scheduled($hook));
check023('Existing event is kept', $status()===['attempted'=>false,'scheduled'=>null,'code'=>null]);
$failed=count(array_filter($checks,fn($r)=>!$r['passed']));
echo wp_json_encode(['version'=>M\Config::VERSION,'checks'=>$checks,'total'=>count($checks),'failed'=>$failed])."\n";
exit($failed?1:0);
