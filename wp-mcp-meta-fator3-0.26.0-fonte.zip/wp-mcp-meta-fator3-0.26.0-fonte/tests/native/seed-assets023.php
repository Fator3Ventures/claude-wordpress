<?php
use Fator3\Meta as M;
require __DIR__.'/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';
f3qa022_guard_db();
wp_set_current_user(1);
$c=M\Connections::get('qa-alfa');
M\Connections::save(['connection_id'=>$c['id'],'expected_revision'=>$c['revision'],'assets'=>['ads'=>['101','102'],'dataset'=>['700']]]);
