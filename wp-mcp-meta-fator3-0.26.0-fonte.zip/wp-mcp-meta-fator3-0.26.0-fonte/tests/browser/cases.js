// Runs in Chromium or any modern browser on the actual panel HTML and assets.
(async()=>{
 const out=document.querySelector('#qa-summary'),checks=[],sel=s=>document.querySelector(s),f=sel('#f3-connection'),rot=sel('#f3-rotate'),wait=()=>new Promise(ok=>setTimeout(ok,20));
 const check=(name,ok)=>{checks.push({name,passed:!!ok});if(!ok)throw Error(name);};
 const click=async s=>{sel(s).click();await wait();};const choose=async idx=>{document.querySelectorAll('#f3-connection-list button')[idx].click();await wait();};
 const run=async()=>{
  await wait();check('abertura não envia credenciais',!qaCalls.some(x=>x.op==='save-connection'||x.op==='rotate-token'));
  check('nova conexão não oferece renovar/remover',sel('#f3-rotate-details').hidden&&sel('#f3-remove-credentials').hidden);
  check('rótulo e descrição associados aos sete campos de credencial',[...document.querySelectorAll('.f3-field input[name]')].length===7&&[...document.querySelectorAll('.f3-field input[name]')].every(n=>n.labels.length===1&&document.getElementById(n.getAttribute('aria-describedby'))));
  check('IDs dos campos são únicos',new Set([...document.querySelectorAll('[id]')].map(n=>n.id)).size===document.querySelectorAll('[id]').length);
  await choose(0);check('edição finita exibe 120 dias',!f.elements.retention_days.disabled&&f.elements.retention_days.value==='120');
  sel('#f3-rotate-details').open=true;rot.elements.token.value='SINTETICO-ALFA';rot.elements.expires.value='2027-01-01T11:00';sel('#f3-remove-credentials').open=true;f.elements.clear_token.checked=true;
  await choose(1);check('troca A → B limpa token e validade da renovação',!rot.elements.token.value&&!rot.elements.expires.value);
  check('destino e controles de remoção acompanham B',sel('#f3-rotate-target').textContent==='Conta Beta'&&!sel('#f3-rotate-details').open&&!sel('#f3-remove-credentials').open&&!f.elements.clear_token.checked);
  check('retenção ilimitada não valida campo invisível',f.elements.retention_days.disabled&&!f.elements.retention_days.required);
  f.requestSubmit();await wait();const save=qaCalls.find(x=>x.op==='save-connection').i;check('edição ilimitada preserva prazo salvo e revisão',save.connection_id==='lab-b'&&save.expected_revision===4&&!('retention_days'in save)&&qaRecords[1].retention_days===120);
  await choose(1);
  f.elements.retention_mode.value='finite';f.elements.retention_mode.dispatchEvent(new Event('change'));f.elements.retention_days.value='45';f.requestSubmit();await wait();
  check('retenção finita envia escolha explícita',qaRecords[1].retention_mode==='finite'&&qaRecords[1].retention_days===45);
  const before=qaCalls.length;await click('[data-tab="diagnostics"]');check('abrir diagnóstico só chama health',qaCalls.slice(before).map(x=>x.op).join(',')==='health');
  check('diagnóstico oferece somente contexto pertinente',f.ownerDocument.querySelector('#f3-context [name="report"]').closest('label').hidden&&!sel('#f3-context').hidden);
  const count=qaCalls.length;sel('#f3-context [name="account_id"]').dispatchEvent(new Event('change'));await wait();check('trocar ativo em diagnóstico não consulta campos nem fornecedor',qaCalls.length===count);
  await click('#f3-status');check('recuperação é explícita',qaCalls.at(-1).op==='status');
  await click('[data-tab="help"]');const picker=sel('#f3-help-document');check('ajuda começa no guia do painel',picker.value==='ADMINISTRATION.md');
  await click('#f3-help-read');check('ajuda concatena páginas e fixa revisão',sel('#f3-help-content').textContent==='início:fim'&&qaCalls.at(-1).i.expected_revision==='test-rev');
  let release;qaDeferred=new Promise(ok=>release=ok);sel('#f3-help-read').click();await wait();picker.value='CONFIGURATION.md';picker.dispatchEvent(new Event('change'));release();qaDeferred=null;await wait();
  check('resposta anterior não aparece sob outro documento',!sel('#f3-help-content').textContent&&!sel('#f3-help-state').textContent.includes('completa.'));
  await click('[data-tab="connections"]');await click('#f3-new-connection');check('novo cadastro restaura retenção máxima e seleção de usuário',f.elements.retention_mode.value==='unlimited'&&sel('#f3-user-options input:checked')?.value==='1');
  check('não houve envio de renovação nem contato comercial',!qaCalls.some(x=>['rotate-token','save-messaging-settings','process-messages'].includes(x.op)));
  if(window.F3_LAYOUT_TEST!==false)check('formulário cabe na largura disponível',f.getBoundingClientRect().right<=innerWidth+1);
 };
 try{await run();out.textContent=checks.length+' testes aprovados — Meta '+F3Social.version;}catch(e){out.textContent='Falha: '+e.message+' ('+checks.filter(x=>x.passed).length+' aprovados)';}
 out.dataset.result=JSON.stringify(checks);document.title=out.textContent;
})();
