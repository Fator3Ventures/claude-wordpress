// Synthetic transport. Keeps interactive state; no request goes to a provider.
const qaCalls=[],qaRecords=structuredClone(F3Social.bootstrap.connections);let qaDeferred=null;
window.fetch=async(url,init)=>{
 const op=url.split('/').pop(),i=JSON.parse(init.body);qaCalls.push({op,i});let data={};
 if(op==='admin-options'){data={rows:i.kind==='users'?[{id:1,name:'QA Admin',can_administer:true}]:[],next_offset:null};}
 else if(op==='list-connections')data={connections:structuredClone(qaRecords),next_offset:null};
 else if(op==='save-connection'){const c=qaRecords.find(c=>c.id===i.connection_id);if(!c||c.revision!==i.expected_revision)throw Error('Revisão incorreta');Object.assign(c,{label:i.label,retention_mode:i.retention_mode},i.retention_days?{retention_days:i.retention_days}:{});c.revision++;data={connection:structuredClone(c)};}
 else if(op==='documentation'){if(i.document==='index'){data={documents:['ADMINISTRATION.md','CONFIGURATION.md'].map(document=>({document}))};}else{if(qaDeferred)await qaDeferred;data={document:i.document,offset:i.offset||0,revision:'test-rev',content:i.offset?'fim':'início:',next_offset:i.offset?null:8};}}
 else if(op==='health'||op==='status')data={state:'ok',repair:op==='health'?'not_attempted':'checked'};
 else if(op==='list-fields')data={fields:[]};
 else throw Error('Chamada inesperada: '+op);
 return {ok:true,status:200,json:async()=>({success:true,code:'ok',version:F3Social.version,data})};};
