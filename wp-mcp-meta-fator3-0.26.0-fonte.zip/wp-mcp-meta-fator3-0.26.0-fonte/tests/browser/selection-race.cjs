'use strict';
// Usage: node selection-race.cjs <identity JSON from render.php> <runtime admin.js> <result.json>
// Deliberately pause individual synthetic REST responses until after a real DOM interaction.
const fs = require('node:fs'), assert = require('node:assert/strict'), crypto = require('node:crypto');
const { JSDOM, VirtualConsole } = require('jsdom');
const [input, script, output] = process.argv.slice(2);
const fixture = JSON.parse(fs.readFileSync(input)), js = fs.readFileSync(script, 'utf8');
const checks = [], settle = () => new Promise(r => setImmediate(r));
function deferred() { let resolve;const p = new Promise(r => {resolve=r;});return {p, resolve}; }
async function run(name, fn) {
  let dom;
  try {
    const errors=[],vc = new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
    dom = new JSDOM(fixture.html,{url:'https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3',runScripts:'outside-only',virtualConsole:vc});
    const w=dom.window,d=w.document,q=d.querySelector('#f3-query'),cfg=structuredClone(fixture.config);
    const A=cfg.bootstrap.connections[0],B=structuredClone(A);B.id='lab-b';B.label='Beta';A.assets.instagram=['101','102'];B.assets.instagram=['201'];A.assets.facebook=['501'];B.assets.facebook=['502'];cfg.bootstrap.connections=[A,B];w.F3Social=cfg;
    const $=s=>d.querySelector(s),calls=[],delays=new Map(),files=[];
    w.URL.createObjectURL=()=>'blob:fixture';
    w.URL.revokeObjectURL=()=>{};const follow=w.HTMLAnchorElement.prototype.click;w.HTMLAnchorElement.prototype.click=function(){if(this.download)files.push(this.download);else follow.call(this);};
    const result = (op,i) => {
      const id=i.account_id||i.query?.account_id||'',mark='row-'+id+(i.cursor?'-next':'-first');
      switch(op){
        case 'admin-options': {const c=cfg.bootstrap.connections.find(c=>c.id===i.connection_id);
          return {rows:i.kind==='users'?[{id:1,name:'Admin',can_administer:true}]:(c?.assets[i.channel]||[]).map(id=>({id,name:'Ativo '+id})),next_offset:null,connection_revision:c?.revision};}
        case 'list-jobs':return {jobs:[{job_id:'job-a',query:{connection_id:'lab-a',channel:'instagram',account_id:'101',report:'profile'},status:'complete',pages:1,rows:1}],next_offset:null};
        case 'job-results':return {data:{rows:[{result:'job-a-only'}],coverage:{complete:true}}};
        case 'list-schedules':return {schedules:[]};
        case 'save-schedule':return {revision:1};
        case 'list-fields':return {fields:[{name:'views'}]};
        case 'query':case 'history-query':case 'conversations':case 'story-archive':
          return {rows:[{name:mark,story_id:mark}],coverage:op==='story-archive'?'fixture':{complete:true},next_cursor:i.cursor?null:'cursor-'+id};
        case 'messaging-status':return {revision:7,enabled:true,contacts_enabled:false,page_id:i.connection_id==='lab-b'?'502':'501',app_review:{declared_by_operator:'standard'},consumer:{available:true}};
        case 'save-messaging-settings':return {persisted:true};
        case 'documentation':return {documents:[{document:'README.md'}]};
        case 'history-export':return {state:'queued',export_id:'qa-export'};
        case 'history-export-step':return {state:'complete',export_id:'qa-export',filename:'history.csv',parts:1};
        case 'history-export-read':return {content_base64:'YQ==',next_offset:null};
        default:throw Error('Unexpected fixture call: '+op);
      }
    };
    w.fetch=async(url,init)=>{const op=url.split('/').pop(),i=JSON.parse(init.body);calls.push({op,i});
      const gate=delays.get(op); if(gate){delays.delete(op);gate.started=true;await gate.p;if(gate.error)throw Error(gate.error);}
      return {ok:true,status:200,json:async()=>({success:true,code:'ok',version:cfg.version,data:result(op,i)})};
    };
    const click=async s=>{const n=$(s);assert.ok(n,s);n.click();await settle();};
    const select=async(k,val)=>{const n=q.elements[k];n.value=val;assert.equal(n.value,val,k+' option');n.dispatchEvent(new w.Event('change',{bubbles:true}));await settle();};
    const tab=async id=>{await click('[data-tab="'+id+'"]');assert.equal($('#f3-'+id).hidden,false,'tab did not change: '+id+'; '+$('#f3-message').textContent+'; '+errors.join(';'));};
    const launch = async spec=>{if(spec.op==='query')q.dispatchEvent(new w.Event('submit',{cancelable:true,bubbles:true}));else await click(spec.open); await settle();};
    const delay=op=>{const g=deferred();delays.set(op,g);return g;};
    w.eval(js);await settle();await fn({w,d,q,$,click,select,tab,launch,delay,calls,files});
    assert.deepEqual(errors,[]);checks.push({name,passed:true});
  }catch(e){checks.push({name,passed:false,reason:String(e.message).slice(0,160)});}
  finally{dom?.window.close();}
}
const areas=[
  {tab:'reports',op:'query',open:'#f3-query',next:'#f3-next',box:'#f3-result',change:'account'},
  {tab:'history',op:'history-query',open:'#f3-history-query',next:'#f3-history-next',box:'#f3-history-result',change:'date'},
  {tab:'messaging',op:'conversations',open:'#f3-msg-query',next:'#f3-msg-next',box:'#f3-msg-result',change:'tab'},
  {tab:'archive',op:'story-archive',open:'#f3-archive-query',next:'#f3-archive-next',box:'#f3-archive-result',change:'connection'},
];
(async()=>{
 for(const spec of areas){
  await run(spec.tab+': valid pagination preserves the initiating selection',async h=>{
   await h.tab(spec.tab);await h.launch(spec);assert.match(h.$(spec.box).textContent,/row-101-first/);
   assert.equal(h.$(spec.next).hidden,false);await h.click(spec.next);
   const [first,page]=h.calls.filter(x=>x.op===spec.op);assert.deepEqual(page.i,{...first.i,cursor:'cursor-101'});assert.match(h.$(spec.box).textContent,/row-101-next/);assert.equal(h.$(spec.next).hidden,true);
  });
  await run(spec.tab+': already-visible data and pagination are invalidated by a new selection',async h=>{
   await h.tab(spec.tab);await h.launch(spec);assert.match(h.$(spec.box).textContent,/row-101-first/);
   if(spec.change==='date')await h.select('date_from','2026-11-01');
   else if(spec.change==='connection')await h.select('connection_id','lab-b');
   else await h.select('account_id','102');
   assert.doesNotMatch(h.$(spec.box).textContent,/row-101-first/);assert.equal(h.$(spec.next).hidden,true);
   const before=h.calls.filter(x=>x.op===spec.op).length;
   // Dispatch even on a hidden button: its handler also must reject a discarded cursor.
   await h.click(spec.next);assert.equal(h.calls.filter(x=>x.op===spec.op).length,before);
  });
  await run(spec.tab+': delayed page cannot reappear after selection leaves and returns',async h=>{
   await h.tab(spec.tab);await h.launch(spec);const g=h.delay(spec.op);await h.click(spec.next);assert.ok(g.started,'page request dispatched');
   if(spec.change==='date'){await h.select('date_from','2026-11-01');await h.select('date_from','');}
   else if(spec.change==='tab'){await h.tab('help');await h.tab(spec.tab);}
   else if(spec.change==='connection'){await h.select('connection_id','lab-b');await h.select('connection_id','lab-a');}
   else{await h.select('account_id','102');await h.select('account_id','101');}
   g.resolve();await settle();assert.doesNotMatch(h.$(spec.box).textContent,/row-101-next/);
   await h.launch(spec);assert.match(h.$(spec.box).textContent,/row-101-first/);assert.equal(h.$(spec.next).hidden,false);
  });
 }
 await run('reports: a provider or network error from the abandoned account is not announced',async h=>{
  await h.tab('reports');const g=h.delay('query');g.error='QA-falha-obsoleta';await h.launch(areas[0]);assert.ok(g.started);
  await h.select('connection_id','lab-b');g.resolve();await settle();
  assert.doesNotMatch(h.$('#f3-message').textContent,/QA-falha-obsoleta/);
 });
 await run('reports: the error for the currently selected account is still announced',async h=>{
  await h.tab('reports');const g=h.delay('query');g.error='QA-falha-atual';await h.launch(areas[0]);assert.ok(g.started);g.resolve();await settle();
  assert.match(h.$('#f3-message').textContent,/QA-falha-atual/);
 });
 await run('history: download completes for unchanged selection',async h=>{
  await h.tab('history');await h.click('#f3-history-csv');
  assert.deepEqual(h.files,['history.csv']);assert.equal(h.calls.find(x=>x.op==='history-export').i.query.account_id,'101');
 });
 await run('history: abandoning an export before its first receipt prevents further steps or download',async h=>{
  await h.tab('history');const g=h.delay('history-export');await h.click('#f3-history-csv');assert.ok(g.started);
  await h.select('connection_id','lab-b');g.resolve();await settle();
  assert.deepEqual(h.calls.filter(x=>['history-export-step','history-export-read'].includes(x.op)),[]);
  assert.deepEqual(h.files,[]);
 });
 await run('messaging: date-only edit preserves the loaded settings and pending webhook value',async h=>{
  await h.tab('messaging');await h.click('#f3-msg-load');const f=h.$('#f3-messaging-form');f.elements.verify_token.value='synthetic-draft';await h.select('date_to','2026-11-01');
  assert.equal(f.elements.verify_token.value,'synthetic-draft');f.dispatchEvent(new h.w.Event('submit',{cancelable:true,bubbles:true}));await settle();
  const v=h.calls.find(x=>x.op==='save-messaging-settings')?.i;assert.equal(v.account_id,'101');assert.equal(v.expected_revision,7);assert.equal(v.verify_token,'synthetic-draft');
 });
 await run('messaging: changing account clears webhook draft and requires a fresh settings read, even on return',async h=>{
  await h.tab('messaging');await h.click('#f3-msg-load');const f=h.$('#f3-messaging-form');f.elements.verify_token.value='only-for-101';
  await h.select('account_id','102');assert.equal(f.elements.verify_token.value,'');await h.select('account_id','101');
  f.dispatchEvent(new h.w.Event('submit',{cancelable:true,bubbles:true}));await settle();
  assert.equal(h.calls.filter(x=>x.op==='save-messaging-settings').length,0);
  await h.click('#f3-msg-load');f.dispatchEvent(new h.w.Event('submit',{cancelable:true,bubbles:true}));await settle();assert.equal(h.calls.filter(x=>x.op==='save-messaging-settings').length,1);
 });
 await run('jobs: first result for job A stays in its card while live account B is selected',async h=>{
  await h.tab('jobs');await h.select('connection_id','lab-b');assert.equal(h.q.elements.account_id.value,'201');
  const card=h.$('#f3-job-list .f3-card'),btn=[...card.querySelectorAll('button')].find(n=>n.textContent==='Ver primeira página');
  assert.ok(btn);btn.click();await settle();
  assert.equal(h.calls.find(x=>x.op==='job-results')?.i.job_id,'job-a');
  assert.equal(h.$('#f3-jobs').hidden,false);assert.match(card.textContent,/job-a-only/);
  assert.doesNotMatch(h.$('#f3-result').textContent,/job-a-only/);
 });
 await run('archive: changing asset during schedule lookup does not create a schedule',async h=>{
  await h.tab('archive');const g=h.delay('list-schedules');await h.click('#f3-archive-schedule');assert.ok(g.started);
  await h.select('account_id','102');g.resolve();await settle();assert.equal(h.calls.filter(x=>x.op==='save-schedule').length,0);
  await h.click('#f3-archive-schedule');const saves=h.calls.filter(x=>x.op==='save-schedule');
  assert.equal(saves.length,1);assert.equal(saves[0].i.query.account_id,'102');
 });
 await run('messaging: B can load while A is pending; A cannot restore its old settings',async h=>{
  await h.tab('messaging');const g=h.delay('messaging-status');await h.click('#f3-msg-load');assert.ok(g.started);
  await h.select('connection_id','lab-b');const f=h.$('#f3-messaging-form');await h.click('#f3-msg-load');
  const reads=h.calls.filter(x=>x.op==='messaging-status');assert.deepEqual(reads.map(x=>x.i.account_id),['101','201']);
  assert.equal(f.elements.page_id.value,'502');f.elements.verify_token.value='draft-for-beta';
  g.resolve();await settle();assert.equal(f.elements.page_id.value,'502');assert.equal(f.elements.verify_token.value,'draft-for-beta');
 });
 const failed=checks.filter(x=>!x.passed);const e={scope:'rendered admin HTML and production JS in jsdom; delayed synthetic REST; no remote effects',plugin_version:fixture.config.version,js_sha256:crypto.createHash('sha256').update(js).digest('hex'),checks,total:checks.length,failed:failed.length};
 fs.writeFileSync(output,JSON.stringify(e,null,2)+'\n');console.log(e.total+' cases; '+e.failed+' failed');failed.forEach(x=>console.log(x.name+': '+x.reason));process.exitCode=failed.length?1:0;
})().catch(e=>{console.error(e);process.exitCode=1;});
