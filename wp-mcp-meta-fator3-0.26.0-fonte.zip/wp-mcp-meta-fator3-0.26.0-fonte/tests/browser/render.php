<?php
// Standalone panel fixture. Only WordPress presentation helpers are stubbed.
// The actual Admin renderer, CSS, JS, documents and schemas come from the supplied runtime.
declare(strict_types=1);
define('ABSPATH',__DIR__.'/'); function current_user_can($s){return $s==='manage_options';}
function esc_html($s){return htmlspecialchars($s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function esc_attr($s){return esc_html($s);} function esc_url($s){return esc_html($s);}
function sanitize_key($s){return preg_replace('/[^a-z0-9_-]/','',strtolower($s));}function wp_unslash($s){return stripslashes($s);}
function checked($a,$b,$echo=false){return $a===$b?'checked="checked"':'';}
function admin_url($s){return 'https://example.invalid/wp-admin/'.$s;}function add_query_arg($q,$u){return $u.'?'.http_build_query($q);}
$r=$argv[1];require "$r/includes/Config.php";require "$r/includes/Admin.php";require "$r/includes/Catalog.php";require "$r/includes/Adapter.php";
use Fator3\Meta as M;
ob_start();M\Admin::screen();$html=ob_get_clean();
$c=['id'=>'lab-a','label'=>'Conta Alfa','revision'=>3,'users'=>[1],'enabled'=>true,'assets'=>['instagram'=>['101'],'facebook'=>[],'ads'=>[],'dataset'=>[]],'token_configured'=>true,'secret_configured'=>true,'client_id'=>'12345','retention_days'=>120,'retention_mode'=>'finite','api_version'=>'v24.0','expires_at'=>0];$b=$c;$b['id']='lab-b';$b['label']='Conta Beta';$b['revision']=4;$b['retention_mode']='unlimited';
$cfg=['root'=>'https://example.invalid/wp-json/f3-meta/v1/','nonce'=>'synthetic','channels'=>M\Config::CHANNELS,'reports'=>M\Adapter::reports(),'provider'=>'meta','apiVersion'=>M\Config::API_VERSION,'version'=>M\Config::VERSION,'tab'=>'connections','bootstrap'=>['connections'=>[$c,$b],'error'=>null,'currentUser'=>1]];
if(($argv[2]??'')==='identity'){
$c['revision']=7;$c['identity']=['app_verified'=>true,'subject_id'=>'901','subject_name'=>'QA Sistema','application_id'=>'123456789012345','application_name'=>'QA App','remote_expires_at'=>0,'scopes'=>[],'extra_scopes'=>[]];$cfg['bootstrap']['connections']=[$c];
echo json_encode(['html'=>$html,'config'=>$cfg]);return;
}
echo '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Teste do painel Meta</title><style>body{font:14px system-ui;background:#f0f0f1;margin:18px}input,select,button{font:inherit}.button{padding:5px 12px}.button-primary{background:#2271b1;color:white;border:0}';
echo file_get_contents("$r/assets/admin.css"),'</style><body><output id="qa-summary" role="status">Executando testes</output>',$html,'<script>window.F3Social=',json_encode($cfg,JSON_UNESCAPED_SLASHES),';</script><script>',file_get_contents(__DIR__.'/fixture.js'),'</script><script>',file_get_contents("$r/assets/admin.js"),'</script><script>',file_get_contents(__DIR__.'/cases.js'),'</script>';
