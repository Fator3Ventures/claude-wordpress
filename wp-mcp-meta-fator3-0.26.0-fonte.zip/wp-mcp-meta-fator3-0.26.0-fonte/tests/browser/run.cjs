'use strict';
const fs=require('node:fs'),{JSDOM,VirtualConsole}=require('jsdom');
const [,,page,output]=process.argv,errors=[],vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(fs.readFileSync(page,'utf8'),{url:'https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3',runScripts:'dangerously',virtualConsole:vc,beforeParse(w){w.structuredClone=structuredClone;w.F3_LAYOUT_TEST=false;}});
(async()=>{const o=dom.window.document.querySelector('#qa-summary');for(let n=0;n<200&&!o.dataset.result;n++)await new Promise(r=>setTimeout(r,50));
const checks=JSON.parse(o.dataset.result||'[]');const ok=checks.length>0&&checks.every(c=>c.passed)&&!errors.length&&!o.textContent.startsWith('Falha');const result={engine:'jsdom',version:require('jsdom/package.json').version,summary:o.textContent,checks,errors,success:ok};fs.writeFileSync(output,JSON.stringify(result,null,2));console.log(JSON.stringify({summary:o.textContent,errors,success:ok}));dom.window.close();process.exitCode=ok?0:1;})();
