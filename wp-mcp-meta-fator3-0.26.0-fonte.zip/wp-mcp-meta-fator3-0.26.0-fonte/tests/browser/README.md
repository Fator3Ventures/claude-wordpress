# Testes do painel Meta (jsdom)

Após o build, com PHP 8.3 de 64 bits, Node e as dependências do package-lock instaladas em tests/browser (`npm ci`), a
partir da raiz do fonte:

```sh
P=build/dist/wp-mcp-meta-fator3
php tests/browser/render.php $P > /tmp/meta-painel.html
php tests/browser/render.php $P identity > /tmp/meta-identidade.json
node tests/browser/run.cjs /tmp/meta-painel.html /tmp/meta-ui.json
for s in identity monitoring messaging selection-race; do node tests/browser/$s.cjs /tmp/meta-identidade.json $P/assets/admin.js /tmp/meta-$s.json; done
node tests/browser/panel.cjs /tmp/meta-identidade.json $P/assets/admin.js tests/browser/fixtures/diagnostics.json /tmp/meta-painel-022.json
```

`panel.cjs` cobre A3 (Enter e digitação na busca de usuários), A4 (papéis ARIA, dispensar, troca de aba), A5 (sessão
expirada), A6 (saídas reais de `health`/`status`/`selftest` sem "Detalhe técnico" nem epoch de 10 dígitos), B1
(navegação em dois níveis), B2 (lista ↔ editor, blocos recolhíveis, campo inválido em bloco fechado), B6 (Markdown hostil
e índice com/sem `title`/`summary`/`topic`), B7 (seletor de canal), B10/B11 (subvisões) e a ausência de sumidouros de HTML
no admin.js. As chamadas REST são simuladas; layout real fica em `tests/visual`.

`fixtures/diagnostics.json` é a saída completa de `health`, `status` e `selftest` do WordPress de laboratório (dados
sintéticos), gerada por `fixtures/capture-diagnostics.php`:

```sh
php /caminho/wp-run.php <dir_site> <admin> tests/browser/fixtures/capture-diagnostics.php > tests/browser/fixtures/diagnostics.json
```

Para reproduzir na base, passe ao renderer o diretório do instalador 0.21.0 e o admin.js dele.
