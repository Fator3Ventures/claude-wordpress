<?php
// Captura a saída completa (sem corte) de health, status e selftest num WordPress de laboratório.
// uso: php tests/lab/wp-run.php <dir_site> qaadmin tests/browser/fixtures/capture-diagnostics.php > tests/browser/fixtures/diagnostics.json
$out = [];
foreach (['health', 'status', 'selftest'] as $op) {
    $req = new WP_REST_Request('POST', '/f3-meta/v1/' . $op);
    $req->set_header('Content-Type', 'application/json');
    $req->set_body('{}');
    $res = rest_do_request($req);
    $d = $res->get_data();
    $out[$op] = ['http' => $res->get_status(), 'success' => $d['success'] ?? null, 'version' => $d['version'] ?? null, 'data' => $d['data'] ?? null];
}
echo wp_json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), "\n";
