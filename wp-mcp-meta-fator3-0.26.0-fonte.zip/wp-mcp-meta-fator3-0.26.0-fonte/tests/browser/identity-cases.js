(async function(w,fixture,js){
const d=w.document,assert=(v,n)=>{if(!v)throw Error(n);};
w.F3Social=fixture.config;let conn=structuredClone(fixture.config.bootstrap.connections[0]);const calls=[],checks=[];let action='mismatch';
w.fetch=async(url,options)=>{const op=url.split('/').pop(),i=JSON.parse(options.body);calls.push({op,i});let data={},success=true,code='ok',message='',avisos=[];
 if(op==='admin-options')data={rows:[{id:1,name:'QA Admin',can_administer:true}],next_offset:null};
 else if(op==='list-connections')data={connections:[conn],next_offset:null};
 else if(op==='save-connection'||op==='rotate-token'){success=false;code=action==='invalid'?'token_rejected':'credential_identity_mismatch';message=action==='invalid'?"A Meta recusou este token. Confira a janela 'Token criado' do usuário do sistema.":"O token novo é de outra identidade (QA Novo). Para trocar, use 'Trocar identidade e regravar agendas': o token é conferido, a seleção de ativos é mantida e as agendas são regravadas na nova revisão.";}
 if(action==='invalid'&&['save-connection','rotate-token'].includes(op))avisos=[{campo:'token',codigo:'possible_app_secret',motivo:'O valor tem aparência de chave secreta; a Meta recusou o token.'}];
 else if(op==='switch-identity'){const identity={...(conn.identity||conn.token_identity),subject_id:'902',subject_name:'QA Novo',remote_expires_at:1796000000,extra_scopes:['ads_management']};
  if(i.dry_run)data={persisted:false,connection_label:i.label??conn.label,identity,schedules:['a','b'],confirmation:'qa-opaque-confirmation',message:'Confira e confirme a identidade.'};
  else{conn={...conn,label:i.label??conn.label,revision:8,token_identity:identity,identity,expires_at:identity.remote_expires_at};data={connection:conn,schedules_rebased:2,persisted:true};}
 }
 return {ok:true,status:200,json:async()=>({success,code,message,data,avisos,version:fixture.config.version})};};
const tick=()=>new Promise(r=>setTimeout(r,20));const check=(n,ok)=>{checks.push({name:n,passed:!!ok});assert(ok,n)};
const clickText=(root,text)=>{const b=[...root.querySelectorAll('button')].find(b=>b.textContent===text);assert(b,'Missing '+text);b.click();};
w.eval(js);await tick();
 check('Unusual credentials are not blocked by HTML patterns',!d.querySelector('[name="client_id"]').pattern&&!d.querySelector('[name="client_secret"]').pattern&&d.querySelector('[name="client_secret"]').maxLength===16384);
 check('Name placeholder',d.querySelector('[name="label"]').placeholder==='Usuário do sistema · Aplicativo');
 check('Saved identity shown above editor',d.querySelector('#f3-connection-list').textContent.includes('Token de: QA Sistema · App: QA App (123456789012345) · Validade: não expira · Permissões:'));
 clickText(d,'Editar conexão');await tick();const cf=d.querySelector('#f3-connection');cf.elements.token.value='a'.repeat(32);action='invalid';cf.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();check('Invalid token reason displayed and candidate retained',d.querySelector('#f3-message').textContent.includes('A Meta recusou')&&cf.elements.token.value==='a'.repeat(32));
 check('Structured warning beside token field',cf.elements.token.closest('.f3-field').querySelector('.f3-credential-warning').textContent.includes('aparência de chave'));
 check('Invalid token does not expose identity switch',d.querySelector('#f3-switch-save').hidden);
 action='mismatch';cf.elements.label.value='New editable name';cf.elements.token.value='E'+'B'.repeat(198);cf.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();check('Identity mismatch offers explicit switch',!d.querySelector('#f3-switch-save').hidden);
 d.querySelector('#f3-switch-save').click();await tick();const preview=d.querySelector('#f3-identity-preview-save');check('Preview has identity, app, count and excess scope warning',!preview.hidden&&preview.textContent.includes('QA Novo')&&preview.textContent.includes('2 agendas')&&preview.textContent.includes('ads_management'));
 check('Editor preview is outside collapsed renewal block',!preview.closest('details')&&!d.querySelector('#f3-rotate-details').open);check('Preview focus and announcement',d.activeElement===preview&&preview.getAttribute('aria-live')==='polite');check('Identity mismatch message remains beside source form',d.querySelector('#f3-identity-error-save').previousElementSibling===cf);
 check('Preview is not a commit',calls.filter(c=>c.op==='switch-identity').every(c=>c.i.dry_run===true));
 clickText(preview,'Confirmar troca de identidade e regravar agendas');await tick();const commit=calls.find(c=>c.op==='switch-identity'&&!c.i.dry_run);check('Commit binds confirmation, same candidate and expected revision',commit?.i.confirmation==='qa-opaque-confirmation'&&commit.i.expected_revision===7&&commit.i.token==='E'+'B'.repeat(198));
 check('Successful switch clears candidate secrets and preview',cf.elements.token.value===''&&d.querySelector('#f3-identity-preview-save').hidden);
 clickText(d,'Editar conexão');await tick();
 check('Expiry field reflects provider UTC and current revision',cf.elements.expected_revision.value==='8'&&cf.elements.expires.value===new Date(1796000000*1000).toISOString().slice(0,16));
 check('Name sent in preview and commit and shown after save',commit.i.label==='New editable name'&&cf.elements.label.value==='New editable name');
 check('Updated identity and excess permissions visible',d.querySelector('#f3-connection-list').textContent.includes('QA Novo')&&d.querySelector('#f3-connection-list').textContent.includes('ads_management'));
 const rf=d.querySelector('#f3-rotate');rf.elements.token.value='E'+'C'.repeat(198);rf.dispatchEvent(new w.Event('submit',{bubbles:true,cancelable:true}));await tick();check('Rotate mismatch has its own guided button',!d.querySelector('#f3-switch-rotate').hidden);d.querySelector('#f3-switch-rotate').click();await tick();const rotatePreview=d.querySelector('#f3-identity-preview-rotate');check('Renewal opens details and focuses its own visible preview',d.querySelector('#f3-rotate-details').open&&!rotatePreview.hidden&&d.activeElement===rotatePreview);check('Editor preview cleared before renewal',preview.hidden);check('Rotate preview preserves its own candidate',calls.filter(c=>c.op==='switch-identity').at(-1).i.token===rf.elements.token.value);
 rf.dispatchEvent(new w.Event('input',{bubbles:true}));check('Changing candidate dismisses confirmation',rotatePreview.hidden);
 return {checks,total:checks.length,failed:0};
})
