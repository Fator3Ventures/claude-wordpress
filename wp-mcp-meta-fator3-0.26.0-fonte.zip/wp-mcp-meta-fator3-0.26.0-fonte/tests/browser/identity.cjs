const fs=require('fs'),assert=require('assert'),{JSDOM}=require('jsdom');
const [,,input,script,output]=process.argv;const fixture=JSON.parse(fs.readFileSync(input));
const dom=new JSDOM(fixture.html,{url:'https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3',runScripts:'outside-only'}),w=dom.window,d=w.document;
const runner=w.eval(fs.readFileSync(require('path').join(__dirname,'identity-cases.js'),'utf8'));
runner(w,fixture,fs.readFileSync(script,'utf8')).then(result=>{result.scope='jsdom interaction; provider and REST simulated';fs.writeFileSync(output,JSON.stringify(result,null,2));console.log(JSON.stringify({total:result.total,failed:result.failed}));dom.window.close();}).catch(e=>{console.error(e);fs.writeFileSync(output,JSON.stringify({error:e.message}));process.exit(1);});
