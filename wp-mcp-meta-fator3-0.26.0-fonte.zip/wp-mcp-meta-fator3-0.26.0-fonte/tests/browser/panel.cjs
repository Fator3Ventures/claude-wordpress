'use strict';
// Painel 0.22.0 — A3, A4, A5, A6, B2, B6 em jsdom sobre o HTML real do renderer e o admin.js do runtime.
// Uso: node panel.cjs <identity JSON de render.php> <admin.js> <diagnostics.json real> <resultado.json>
// REST simulado; nenhuma chamada sai da máquina. Layout real fica em tests/visual/layout.cjs.
const fs = require('node:fs'), assert = require('node:assert/strict');
const { JSDOM, VirtualConsole } = require('jsdom');
const [input, script, diagFile, output] = process.argv.slice(2);
const fixture = JSON.parse(fs.readFileSync(input)), js = fs.readFileSync(script, 'utf8'), diag = JSON.parse(fs.readFileSync(diagFile));
const checks = [], settle = () => new Promise(r => setTimeout(r, 15));
const EPOCH = /(^|[^0-9])[0-9]{10}([^0-9]|$)/;
const SESSION = 'A sessão do painel expirou. Recarregue a página e repita a ação; nada foi gravado por esta tentativa.';

async function run(name, fn, routes = {}) {
  let dom;
  try {
    const errors = [], vc = new VirtualConsole(); vc.on('jsdomError', e => errors.push(e.message));
    dom = new JSDOM(fixture.html, { url: 'https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3', runScripts: 'outside-only', virtualConsole: vc });
    const w = dom.window, d = w.document, cfg = structuredClone(fixture.config); routes.__config?.(cfg); w.F3Social = cfg; w.F3_ALERTS = 0; w.alert = () => { w.F3_ALERTS++; };
    const calls = [];
    w.fetch = async (url, init) => {
      const op = url.split('/').pop(), i = JSON.parse(init.body); calls.push({ op, i });
      if (routes[op]) { const r = await routes[op](i); if (r && r.__raw) return { ok: r.status < 400, status: r.status, json: async () => r.body }; return env(r); }
      if (op === 'admin-options') return env({ rows: i.kind === 'users' ? [{ id: 1, name: 'QA Admin', can_administer: true }] : [], next_offset: null, connection_revision: 7 });
      if (op === 'list-connections') return env({ connections: cfg.bootstrap.connections, next_offset: null });
      if (op === 'list-fields') return env({ fields: [] });
      if (op === 'health') return env(diag.health.data);
      if (op === 'status') return env(diag.status.data);
      if (op === 'selftest') return env(diag.selftest.data);
      if (op === 'documentation') return env(i.document === 'index' ? { documents: [{ document: 'ADMINISTRATION.md' }] } : { document: i.document, offset: 0, revision: 'r', content: 'x', next_offset: null });
      throw Error('Chamada inesperada: ' + op);
    };
    function env(data) { return { ok: true, status: 200, json: async () => ({ success: true, code: 'ok', version: cfg.version, data }) }; }
    const $ = s => d.querySelector(s);
    const click = async s => { const n = typeof s === 'string' ? $(s) : s; assert.ok(n, String(s)); n.click(); await settle(); };
    w.eval(js); await settle();
    await fn({ w, d, $, click, calls });
    assert.deepEqual(errors, []);
    checks.push({ name, passed: true });
  } catch (e) { checks.push({ name, passed: false, reason: String(e.message).slice(0, 220) }); }
  finally { dom?.window.close(); }
}
const submit = (w, f) => f.dispatchEvent(new w.Event('submit', { bubbles: true, cancelable: true }));

(async () => {
  // ---------- A3 ----------
  await run('A3: Enter na busca de usuários é cancelado, busca pelo nome e não envia save-connection', async h => {
    const s = h.$('#f3-user-search'); s.value = 'qaed';
    const ev = new h.w.KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true });
    s.dispatchEvent(ev); await settle();
    assert.equal(ev.defaultPrevented, true, 'Enter não foi cancelado (envio implícito do formulário)');
    assert.ok(h.calls.some(c => c.op === 'admin-options' && c.i.kind === 'users' && c.i.search === 'qaed'), 'busca não executada');
    assert.equal(h.calls.filter(c => c.op === 'save-connection').length, 0);
  });
  await run('A3: digitar na busca não marca alterações nem limpa a prévia de identidade', async h => {
    const prev = h.$('#f3-identity-preview-save'); prev.hidden = false; prev.textContent = 'prévia';
    const s = h.$('#f3-user-search'); s.value = 'q'; s.dispatchEvent(new h.w.Event('input', { bubbles: true })); await settle();
    assert.equal(h.$('#f3-dirty').textContent, '', 'busca marcou alteração');
    assert.equal(prev.hidden, false, 'busca limpou a prévia');
    const n = h.$('#f3-connection [name="label"]'); n.value = 'x'; n.dispatchEvent(new h.w.Event('input', { bubbles: true }));
    assert.equal(h.$('#f3-dirty').textContent, 'Alterações ainda não salvas.', 'controle: campo real deve marcar alteração');
  });

  // ---------- A4 ----------
  const failSave = { 'save-connection': () => ({ __raw: true, status: 409, body: { success: false, code: 'revision_conflict', message: 'Revisão desatualizada.' } }) };
  await run('A4: erro usa role="alert", aparece e tem botão de dispensar com nome acessível', async h => {
    submit(h.w, h.$('#f3-connection')); await settle();
    const m = h.$('#f3-message');
    assert.equal(m.hidden, false); assert.equal(m.getAttribute('role'), 'alert'); assert.match(m.textContent, /Revisão desatualizada/);
    const b = m.querySelector('button'); assert.ok(b, 'sem botão'); assert.equal(b.getAttribute('aria-label'), 'Dispensar aviso');
    await h.click(b); assert.equal(m.hidden, true); assert.equal(m.textContent, '');
  }, failSave);
  await run('A4: sucesso usa role="status"', async h => {
    const conn = structuredClone(fixture.config.bootstrap.connections[0]);
    await h.click(h.d.querySelector('#f3-connection-list .f3-edit-connection'));
    submit(h.w, h.$('#f3-connection')); await settle();
    const m = h.$('#f3-message'); assert.equal(m.hidden, false); assert.equal(m.getAttribute('role'), 'status'); assert.match(m.textContent, /Conexão salva/);
  }, { 'save-connection': i => ({ connection: { ...structuredClone(fixture.config.bootstrap.connections[0]), revision: i.expected_revision + 1 }, schedules_rebased: 0 }) });
  await run('A4: o aviso some ao trocar de aba (e não some ao clicar na aba atual)', async h => {
    submit(h.w, h.$('#f3-connection')); await settle();
    const m = h.$('#f3-message'); assert.equal(m.hidden, false);
    await h.click('[data-tab="connections"]'); assert.equal(m.hidden, false, 'mesma aba não deveria limpar');
    await h.click('[data-tab="help"]'); assert.equal(m.hidden, true); assert.equal(m.textContent, '');
  }, failSave);
  await run('A4: resultado anunciado depois da troca de aba (Coletar todas as páginas)', async h => {
    await h.click('[data-tab="reports"]'); await h.click('#f3-collect');
    const m = h.$('#f3-message'); assert.equal(h.$('#f3-jobs').hidden, false); assert.equal(m.hidden, false); assert.match(m.textContent, /Coleta criada/);
  }, { 'admin-options': i => ({ rows: i.kind === 'users' ? [] : [{ id: '101', name: 'IG' }], next_offset: null, connection_revision: 7 }), 'create-job': () => ({ job_id: 'j' }), 'list-jobs': () => ({ jobs: [], next_offset: null }), 'list-schedules': () => ({ schedules: [] }) });

  // ---------- A5 ----------
  for (const [status, code] of [[403, 'rest_cookie_invalid_nonce'], [401, 'rest_forbidden'], [403, 'rest_forbidden']]) {
    await run(`A5: HTTP ${status} ${code} mostra sessão expirada`, async h => {
      submit(h.w, h.$('#f3-connection')); await settle();
      const t = h.$('#f3-message').textContent;
      assert.ok(t.includes(SESSION), 'mensagem: ' + t); assert.ok(!/Cookie check failed|\[rest_/.test(t), 'código cru exibido');
      assert.equal(h.$('#f3-message').getAttribute('role'), 'alert');
    }, { 'save-connection': () => ({ __raw: true, status, body: { code, message: code === 'rest_cookie_invalid_nonce' ? 'Cookie check failed' : 'Sorry, you are not allowed to do that.', data: { status } } }) });
  }
  await run('A5: outra recusa 403 mantém a mensagem do servidor', async h => {
    submit(h.w, h.$('#f3-connection')); await settle();
    const t = h.$('#f3-message').textContent; assert.ok(t.includes('Recusa específica [asset_access_denied]'), t); assert.ok(!t.includes('sessão do painel expirou'));
  }, { 'save-connection': () => ({ __raw: true, status: 403, body: { success: false, code: 'asset_access_denied', message: 'Recusa específica' } }) });

  // ---------- A6 ----------
  for (const op of ['health', 'status', 'selftest']) {
    await run(`A6: ${op} real (fixture) sem "Detalhe técnico" e sem epoch de 10 dígitos`, async h => {
      await h.click('[data-tab="diagnostics"]');
      if (op !== 'health') await h.click(op === 'status' ? '#f3-status' : '#f3-selftest');
      const box = h.$('#f3-diagnostic-result'), t = box.textContent;
      assert.ok(box.querySelectorAll('dt').length > 5, 'saída não renderizada');
      assert.ok(!t.includes('Detalhe técnico'), 'há rótulo genérico: ' + [...box.querySelectorAll('dt[title]')].map(n => n.title).join(','));
      assert.ok(!EPOCH.test(t), 'epoch bruto: ' + (t.match(EPOCH) || [])[0]);
      if (op !== 'selftest') { assert.match(t, /UTC/); assert.ok(box.querySelector('.f3-stats'), 'sem resumo'); assert.match(box.querySelector('.f3-stats').textContent, /Estado geral.*Conexões.*Agendas ativas.*Agendas parciais.*Agendas com falha/s); }
      else assert.match(box.querySelector('.f3-stats').textContent, /8 de 8 aprovadas/);
      assert.ok(!/not_attempted|not_run|local_execution/.test(t), 'código cru conhecido não traduzido');
    });
  }
  await run('A6: health tem "Próxima manutenção" no resumo', async h => {
    await h.click('[data-tab="diagnostics"]'); assert.match(h.$('#f3-diagnostic-result .f3-stats').textContent, /Próxima manutenção/);
  });
  await run('A6: chave realmente desconhecida de outra operação continua como "Detalhe técnico"', async h => {
    await h.click('[data-tab="diagnostics"]'); await h.click('#f3-validate');
    const t = h.$('#f3-diagnostic-result').textContent; assert.ok(t.includes('Detalhe técnico'), t.slice(0, 200));
    assert.equal(h.$('#f3-diagnostic-result dt[title="chave_inedita_qa"]')?.textContent, 'Detalhe técnico');
  }, { 'validate-connection': () => ({ chave_inedita_qa: 'x', is_valid: true }), 'admin-options': i => ({ rows: i.kind === 'users' ? [] : [{ id: '101', name: 'IG' }], next_offset: null, connection_revision: 7 }) });

  // ---------- B2 ----------
  await run('B2: Primeiros passos refletem as conexões carregadas e cartão oferece "Escolher ativos"', async h => {
    const states = [...h.d.querySelectorAll('#f3-steps li')].map(li => li.dataset.step + ':' + li.dataset.state).join(',');
    assert.equal(states, 'connection:done,assets:done,query:available');
    const a = h.d.querySelector('#f3-connection-list .f3-choose-assets'); assert.ok(a); assert.equal(a.textContent, 'Escolher ativos');
    await h.click(a); assert.equal(h.$('#f3-assets').hidden, false); assert.equal(h.$('#f3-assets-connection').value, fixture.config.bootstrap.connections[0].id);
    assert.ok(h.$('#f3-connection-list').textContent.includes('Identidade conferida'));
  });
  await run('B2: sem conexões os três passos ficam pendentes', async h => {
    assert.equal([...h.d.querySelectorAll('#f3-steps li')].map(li => li.dataset.state).join(','), 'pending,pending,pending');
  }, { __config: c => { c.bootstrap.connections = []; }, 'list-connections': () => ({ connections: [], next_offset: null }) });

  // ---------- B6 ----------
  const hostile = '# Título <script>alert(1)</script>\n\nParágrafo com <img src=x onerror=alert(1)> e `código <b>` e **negrito** e [link](javascript:alert(1)).\nContinua na mesma linha.\n\n## Lista\n\n- item **um**\n- item `dois`\n  - aninhado\n\n1. primeiro\n2. segundo\n\n| Coluna A | Coluna B |\n|---|---|\n| `a` \\| b | <img src=x onerror=alert(1)> |\n\n```php\n<?php echo "<script>alert(1)</script>"; ?>\n```\n\n##### Cinco cerquilhas viram texto\n\n<script>alert(2)</script>\n';
  const richIndex = { documents: [
    { document: 'README.md', bytes: 1, sha256: 'x', title: 'Índice da documentação', summary: 'Como ler os manuais.', topic: 'indice' },
    { document: 'HOSTIL.md', bytes: 1, sha256: 'y', title: 'Documento <b>de teste</b>', summary: 'Resumo <img src=x onerror=alert(1)>', topic: 'uso' },
    { document: 'input-schemas.json', bytes: 1, sha256: 'z', title: 'Schemas de entrada', summary: 'JSON', topic: 'schema' }],
    topics: { indice: 'Índice', uso: 'Uso', schema: 'Schemas e catálogos' } };
  const docRoute = i => i.document === 'index' ? richIndex : { document: i.document, offset: 0, revision: 'r1', content: i.document === 'input-schemas.json' ? '{"a":"<script>"}' : hostile, next_offset: null, title: i.document === 'HOSTIL.md' ? 'Documento hostil' : undefined };
  await run('B6: índice novo — temas, títulos e resumos como texto; leitura usa title', async h => {
    await h.click('[data-tab="help"]');
    const groups = [...h.d.querySelectorAll('#f3-help-document optgroup')].map(g => g.label); assert.deepEqual(groups, ['Índice', 'Uso', 'Schemas e catálogos']);
    const nav = h.$('#f3-help-index'); assert.deepEqual([...nav.querySelectorAll('summary > span:first-child')].map(n => n.textContent), ['Índice', 'Uso', 'Schemas e catálogos']);
    assert.ok(nav.textContent.includes('Documento <b>de teste</b>') && nav.textContent.includes('Resumo <img src=x onerror=alert(1)>'));
    assert.equal(nav.querySelectorAll('b,img').length, 0);
    assert.equal(h.$('#f3-help-content').hidden, true, 'área de leitura visível antes de ler');
    await h.click([...nav.querySelectorAll('.f3-doc-link')].find(b => b.dataset.document === 'HOSTIL.md'));
    assert.equal(h.$('#f3-help-document').value, 'HOSTIL.md'); assert.equal(h.$('#f3-help-state').textContent, 'Documento hostil (HOSTIL.md) · leitura completa.');
  }, { documentation: docRoute });
  await run('B6: Markdown hostil não cria script/img; tabela, listas, código, negrito viram os elementos certos', async h => {
    await h.click('[data-tab="help"]'); h.$('#f3-help-document').value = 'HOSTIL.md'; await h.click('#f3-help-read');
    const box = h.$('#f3-help-content'); assert.equal(box.hidden, false);
    assert.equal(box.querySelectorAll('script,img,a,b,iframe').length, 0, 'elemento vindo do texto');
    assert.equal(h.d.querySelectorAll('script').length, 0); assert.equal(h.w.F3_ALERTS, 0);
    assert.ok(box.textContent.includes('<script>alert(1)</script>') && box.textContent.includes('<img src=x onerror=alert(1)>'), 'texto perdido');
    assert.equal(box.querySelector('h3').textContent, 'Título <script>alert(1)</script>'); assert.equal(box.querySelector('h4').textContent, 'Lista');
    const ul = box.querySelector('ul'); assert.equal(ul.children.length, 2); assert.equal(ul.querySelector('li strong').textContent, 'um'); assert.equal(ul.querySelector('li ul li').textContent, 'aninhado');
    assert.deepEqual([...box.querySelectorAll('ol > li')].map(n => n.textContent), ['primeiro', 'segundo']);
    const t = box.querySelector('table'); assert.ok(t); assert.deepEqual([...t.querySelectorAll('th')].map(n => n.textContent), ['Coluna A', 'Coluna B']);
    assert.equal(t.querySelectorAll('tbody tr').length, 1); assert.equal(t.querySelector('td').textContent, 'a | b'); assert.equal(t.querySelector('td code').textContent, 'a');
    assert.equal(box.querySelector('pre code').textContent, '<?php echo "<script>alert(1)</script>"; ?>');
    assert.ok([...box.querySelectorAll('p > code')].some(c => c.textContent === 'código <b>')); assert.ok([...box.querySelectorAll('p strong')].some(c => c.textContent === 'negrito'));
    assert.ok([...box.querySelectorAll('p')].some(p => p.textContent.startsWith('##### Cinco')), 'cinco # devem ser texto');
    assert.ok([...box.querySelectorAll('p')].some(p => p.textContent.includes('[link](javascript:alert(1))') && p.textContent.includes('Continua na mesma linha.')));
  }, { documentation: docRoute });
  await run('B6: documento JSON é exibido como bloco de código', async h => {
    await h.click('[data-tab="help"]'); h.$('#f3-help-document').value = 'input-schemas.json'; await h.click('#f3-help-read');
    assert.equal(h.$('#f3-help-content pre code').textContent, '{"a":"<script>"}');
  }, { documentation: docRoute });
  await run('B6: índice antigo (sem title/summary/topic) continua funcionando pelo nome do arquivo', async h => {
    await h.click('[data-tab="help"]');
    assert.equal(h.d.querySelectorAll('#f3-help-document optgroup').length, 0);
    assert.deepEqual([...h.d.querySelectorAll('#f3-help-document option')].map(o => o.value + '=' + o.textContent), ['ADMINISTRATION.md=Guia do painel · ADMINISTRATION.md', 'OUTRO.md=OUTRO.md']);
    assert.equal(h.$('#f3-help-index summary > span').textContent, 'Documentos'); assert.equal(h.d.querySelectorAll('#f3-help-index .f3-doc-summary').length, 0);
    await h.click('#f3-help-read'); assert.equal(h.$('#f3-help-state').textContent, 'Guia do painel · ADMINISTRATION.md (ADMINISTRATION.md) · leitura completa.');
    assert.equal(h.$('#f3-help-content p').textContent, 'conteúdo');
  }, { documentation: i => i.document === 'index' ? { documents: [{ document: 'ADMINISTRATION.md' }, { document: 'OUTRO.md' }] } : { document: i.document, offset: 0, revision: 'r', content: 'conteúdo', next_offset: null } });

  // ---------- B1 navegação em dois níveis ----------
  const TABS = { connections: 'configurar', assets: 'configurar', 'ads-access': 'configurar', reports: 'dados', jobs: 'dados', history: 'dados', messaging: 'dados', archive: 'dados', diagnostics: 'suporte', help: 'suporte' };
  await run('B1: dez links a[data-tab] no DOM com endereços ?page=…&tab=…; só o grupo ativo visível', async h => {
    const links = [...h.d.querySelectorAll('a[data-tab]')]; assert.equal(links.length, 10);
    for (const a of links) { assert.equal(new URL(a.href).search, '?page=wp-mcp-meta-fator3&tab=' + a.dataset.tab); assert.equal(a.dataset.groupOf, TABS[a.dataset.tab], a.dataset.tab); }
    const visible = () => { const v = links.filter(a => !a.hidden).map(a => a.dataset.tab).join(','); assert.equal(v, links.filter(a => !a.closest('[hidden]')).map(a => a.dataset.tab).join(','), 'link e contêiner divergem'); return v; };
    assert.equal(visible(), 'connections,assets,ads-access'); assert.equal(h.$('[data-group="configurar"]').getAttribute('aria-current'), 'true');
    await h.click('[data-tab="messaging"]'); assert.equal(visible(), 'reports,jobs,history,messaging,archive'); assert.equal(h.$('[data-tab="messaging"]').getAttribute('aria-current'), 'page');
    assert.equal(h.$('[data-group="dados"]').getAttribute('aria-current'), 'true'); assert.equal(h.$('[data-group="configurar"]').getAttribute('aria-current'), null);
    await h.click('[data-group="suporte"]'); assert.equal(h.$('#f3-diagnostics').hidden, false, 'grupo não abriu a primeira aba'); assert.equal(visible(), 'diagnostics,help');
    assert.equal(new URL(h.w.location.href).searchParams.get('tab'), 'diagnostics');
  }, { 'admin-options': i => ({ rows: i.kind === 'users' ? [] : [{ id: '101', name: 'IG' }], next_offset: null, connection_revision: 7 }), 'messaging-status': () => ({}) });
  await run('B1: sem JavaScript todos os links ficam visíveis (marcação do servidor)', async () => {
    const dom = new JSDOM(fixture.html), d = dom.window.document;
    assert.equal(d.querySelectorAll('a[data-tab]').length, 10); assert.equal(d.querySelectorAll('a[data-tab][hidden], [data-group-tabs][hidden]').length, 0);
    assert.equal(d.querySelectorAll('[data-subview-of][hidden]').length, 0, 'subvisão escondida sem JS'); dom.window.close();
  });

  // ---------- B2 lista ↔ editor ----------
  await run('B2: com conexões abre na lista; Editar abre o editor; Voltar respeita alterações não salvas', async h => {
    assert.equal(h.$('#f3-connection-list-view').hidden, false); assert.equal(h.$('#f3-connection-editor').hidden, true);
    await h.click(h.$('#f3-connection-list .f3-edit-connection')); assert.equal(h.$('#f3-connection-editor').hidden, false); assert.equal(h.$('#f3-connection-list-view').hidden, true);
    assert.match(h.$('#f3-connection-state').textContent, /^Editando /);
    const n = h.$('#f3-connection [name="label"]'); n.value = 'mudou'; n.dispatchEvent(new h.w.Event('input', { bubbles: true }));
    let asked = 0; h.w.confirm = () => { asked++; return false; }; await h.click('#f3-connection-back');
    assert.equal(asked, 1); assert.equal(h.$('#f3-connection-editor').hidden, false, 'saiu sem confirmar');
    h.w.confirm = () => { asked++; return true; }; await h.click('#f3-connection-back'); assert.equal(h.$('#f3-connection-list-view').hidden, false);
    await h.click('#f3-new-connection'); assert.equal(h.$('#f3-connection-editor').hidden, false); assert.equal(h.$('#f3-connection-state').textContent, 'Nova conexão');
  });
  await run('B2: salvar com sucesso volta à lista com o aviso', async h => {
    await h.click(h.$('#f3-connection-list .f3-edit-connection')); submit(h.w, h.$('#f3-connection')); await settle();
    assert.equal(h.$('#f3-connection-list-view').hidden, false); assert.equal(h.$('#f3-connection-editor').hidden, true); assert.match(h.$('#f3-message').textContent, /Conexão salva/);
  }, { 'save-connection': i => ({ connection: { ...structuredClone(fixture.config.bootstrap.connections[0]), revision: i.expected_revision + 1 }, schedules_rebased: 0 }) });
  await run('B2: sem conexões abre direto no editor', async h => {
    assert.equal(h.$('#f3-connection-editor').hidden, false); assert.equal(h.$('#f3-connection-list-view').hidden, true);
  }, { __config: c => { c.bootstrap.connections = []; }, 'list-connections': () => ({ connections: [], next_offset: null }) });
  await run('B2: blocos 3, 4, remoção e renovação fechados com resumo de uma linha; 1 e 2 abertos', async h => {
    await h.click(h.$('#f3-connection-list .f3-edit-connection'));
    for (const sel of ['[data-block="retention"]', '[data-block="users"]', '#f3-remove-credentials', '#f3-rotate-details']) assert.equal(h.$(sel).open, false, sel);
    assert.equal(h.d.querySelectorAll('#f3-connection fieldset.f3-form-block').length, 2);
    assert.equal(h.$('#f3-retention-summary').textContent, 'Prazo de 120 dias'); assert.equal(h.$('#f3-users-summary').textContent, '1 usuário associado');
    assert.equal(h.$('#f3-remove-summary').textContent, 'Nenhuma remoção marcada');
    const c = h.$('#f3-connection [name="clear_token"]'); c.checked = true; c.dispatchEvent(new h.w.Event('change', { bubbles: true })); assert.equal(h.$('#f3-remove-summary').textContent, 'Remover ao salvar: token');
  }, { __config: c => { const x = c.bootstrap.connections[0]; x.retention_mode = 'finite'; x.retention_days = 120; } });
  await run('B2: campo inválido dentro de bloco fechado abre o bloco e não envia', async h => {
    await h.click(h.$('#f3-connection-list .f3-edit-connection'));
    const f = h.$('#f3-connection'), block = h.$('[data-block="retention"]'); assert.equal(block.open, false);
    f.elements.retention_mode.value = 'finite'; f.elements.retention_mode.dispatchEvent(new h.w.Event('change', { bubbles: true })); f.elements.retention_days.value = '';
    f.requestSubmit(); await settle();
    assert.equal(block.open, true, 'bloco continuou fechado'); assert.equal(h.calls.filter(c => c.op === 'save-connection').length, 0);
  });

  // ---------- B7 ativos por canal ----------
  await run('B7: seletor de canal com contagem; trocar de canal preserva marcações; um Salvar grava todos', async h => {
    await h.click('[data-tab="assets"]'); h.$('#f3-assets-connection').value = fixture.config.bootstrap.connections[0].id; h.$('#f3-assets-connection').dispatchEvent(new h.w.Event('change', { bubbles: true })); await settle();
    const sw = () => [...h.d.querySelectorAll('#f3-asset-options [data-switch="assets"] button')];
    assert.ok(sw().some(b => b.textContent === 'Instagram (1)'), sw().map(b => b.textContent).join('|'));
    assert.equal(h.d.querySelectorAll('#f3-asset-options fieldset[data-channel]:not([hidden])').length, 1, 'mais de um canal visível');
    await h.click(sw().find(b => b.dataset.view === 'facebook'));
    const fb = h.$('#f3-assets-channel-facebook'); assert.equal(fb.hidden, false); assert.equal(sw().find(b => b.dataset.view === 'facebook').getAttribute('aria-pressed'), 'true');
    await h.click([...fb.querySelectorAll('button')].find(b => b.textContent === 'Carregar ativos disponíveis'));
    const box = fb.querySelector('input[type=checkbox]'); box.checked = true; box.dispatchEvent(new h.w.Event('change', { bubbles: true }));
    assert.ok(sw().some(b => b.textContent === 'Facebook (1)'));
    await h.click(sw().find(b => b.dataset.view === 'instagram')); await h.click(sw().find(b => b.dataset.view === 'facebook'));
    assert.equal(fb.querySelector('input[type=checkbox]').checked, true, 'marcação perdida');
    await h.click('#f3-save-assets'); const save = h.calls.find(c => c.op === 'save-connection').i;
    assert.deepEqual(save.assets.facebook, ['501']); assert.deepEqual(save.assets.instagram, ['101']);
  }, { 'admin-options': i => ({ rows: i.kind === 'users' ? [] : i.kind === 'assets' && i.channel === 'facebook' ? [{ id: '501', name: 'Página' }] : i.kind === 'selected' ? (i.channel === 'instagram' ? [{ id: '101', name: 'IG' }] : []) : [], next_offset: null, next_cursor: null, connection_revision: 7 }), 'save-connection': i => ({ connection: { ...structuredClone(fixture.config.bootstrap.connections[0]), assets: i.assets, revision: 8 } }) });

  // ---------- B10/B11 subvisões ----------
  const ctxRoutes = { 'admin-options': i => ({ rows: i.kind === 'users' ? [] : i.channel === 'facebook' ? [{ id: '920', name: 'Página' }] : [{ id: '101', name: 'IG' }], next_offset: null, connection_revision: 7 }), 'list-jobs': () => ({ jobs: [], next_offset: null }), 'list-schedules': () => ({ schedules: [{ schedule_id: 's1', label: 'Agenda QA', revision: 1, enabled: true, query: { connection_id: fixture.config.bootstrap.connections[0].id, channel: 'instagram', account_id: '101', report: 'profile' }, next_at: 1793000000, interval_minutes: 1440, lookback_days: 7 }] }), 'messaging-status': () => ({ revision: 3, enabled: false, contacts_enabled: false, page_id: '920', app_review: { declared_by_operator: 'unknown' }, consumer: { available: false } }), conversations: i => ({ rows: [], coverage: {}, next_cursor: null }) };
  await run('B10: Coletas ↔ Agendas não muda a aba nem a seleção; Editar agenda leva a Agendas', async h => {
    await h.click('[data-tab="jobs"]'); const q = h.$('#f3-query'); const before = [q.elements.connection_id.value, q.elements.account_id.value];
    assert.equal(h.$('#f3-jobs-runs').hidden, false); assert.equal(h.$('#f3-jobs-schedules').hidden, true);
    const n = h.calls.length; await h.click('[data-switch="jobs"] [data-view="schedules"]');
    assert.equal(h.calls.length, n, 'subvisão disparou chamada'); assert.equal(h.$('#f3-jobs').hidden, false); assert.equal(h.$('[data-tab="jobs"]').getAttribute('aria-current'), 'page');
    assert.equal(h.$('#f3-jobs-schedules').hidden, false); assert.deepEqual([q.elements.connection_id.value, q.elements.account_id.value], before);
    await h.click('[data-switch="jobs"] [data-view="runs"]'); await h.click([...h.d.querySelectorAll('#f3-schedule-list button')].find(b => b.textContent === 'Editar agenda'));
    assert.equal(h.$('#f3-jobs-schedules').hidden, false); assert.equal(h.$('#f3-schedule').elements.schedule_id.value, 's1');
  }, ctxRoutes);
  await run('B11: Consulta ↔ Configuração da recepção mantém estado em memória e a aba', async h => {
    await h.click('[data-tab="messaging"]'); assert.equal(h.$('#f3-messaging-query').hidden, false); assert.equal(h.$('#f3-messaging-setup').hidden, true);
    await h.click('[data-switch="messaging"] [data-view="setup"]'); await h.click('#f3-msg-load');
    const f = h.$('#f3-messaging-form'); f.elements.verify_token.value = 'rascunho-qa';
    await h.click('[data-switch="messaging"] [data-view="query"]'); assert.equal(h.$('#f3-messaging').hidden, false);
    await h.click('#f3-msg-query'); assert.equal(h.calls.find(c => c.op === 'conversations').i.page_id, '920');
    await h.click('[data-switch="messaging"] [data-view="setup"]'); assert.equal(f.elements.verify_token.value, 'rascunho-qa'); assert.equal(f.elements.page_id.value, '920');
    assert.equal(h.$('[data-switch="messaging"] [data-view="setup"]').getAttribute('aria-pressed'), 'true');
  }, ctxRoutes);

  // ---------- Fonte: nenhum sumidouro de HTML ----------
  await run('Fonte: admin.js sem innerHTML, outerHTML, insertAdjacentHTML, document.write ou eval', async () => {
    const hits = js.match(/innerHTML|outerHTML|insertAdjacentHTML|document\.write|\beval\s*\(|new Function/g); assert.equal(hits, null, String(hits));
  });

  const failed = checks.filter(c => !c.passed);
  fs.writeFileSync(output, JSON.stringify({ scope: 'jsdom; HTML do renderer real e admin.js do runtime; REST simulado; health/status/selftest de fixture capturada no WordPress local', checks, total: checks.length, failed: failed.length }, null, 2) + '\n');
  console.log(JSON.stringify({ total: checks.length, failed: failed.length }));
  failed.forEach(c => console.log('FALHA ' + c.name + ': ' + c.reason));
  process.exitCode = failed.length ? 1 : 0;
})().catch(e => { console.error(e); process.exitCode = 1; });
