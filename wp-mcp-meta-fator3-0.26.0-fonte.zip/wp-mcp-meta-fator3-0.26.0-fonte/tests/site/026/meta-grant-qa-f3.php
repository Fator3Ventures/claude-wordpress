<?php
/**
 * Plugin Name: Fator3 QA temporário — concessões Meta
 * Version: 1.0.1
 */
declare(strict_types=1);
namespace F3MetaQA026;
use Fator3\Meta as M;
use Fator3\McpFiles\ConnectionContext as Context;
use Fator3\McpFiles\Persistence as Policies;
defined('ABSPATH') || exit;
function allowed():bool{return wp_parse_url(home_url('/'),PHP_URL_HOST)==='fator3-teste-mcp-1.dreamhosters.com'&&current_user_can('manage_options')&&Context::maintenance()&&M\Config::VERSION==='0.26.0';}
function run():array{
 if(!allowed())return ['success'=>false,'stage'=>'guard'];
 $original=Context::transport_identity();$uid=get_current_user_id();$login=wp_get_current_user()->user_login;
 $suffix=bin2hex(random_bytes(6));$id='qa26-reader-'.$suffix;$conn='qa26-site-'.$suffix;$sel=['connection_id'=>$conn,'account_id'=>'160'];
 $s=['consumer_id'=>$id]+$sel;$res=['reports'=>['ads_activity'],'dataset_ids'=>[]];$cfg=$sel+['ready'=>true,'revision'=>'1'];
 $key=hash('sha256',M\Util::json([$id,$conn,'160']));$keys=[];$checks=[];$stage='setup';$error=null;$clean=[];
 $assert=static function($n,$ok)use(&$checks,&$stage){$stage=$n;$checks[$n]=(bool)$ok;if(!$ok)throw new \RuntimeException('test_step');};
 $app=static function(string $label)use($uid,$suffix,&$keys){$r=\WP_Application_Passwords::create_new_application_password($uid,['name'=>'QA Meta 026 '.$suffix.' '.$label]);if(is_wp_error($r))throw new \RuntimeException('app_create');$uuid=$r[1]['uuid'];$keys[]=$uuid;$p=['user_id'=>$uid,'connection_id'=>'app:'.$uuid,'profile'=>'custom','policy_version'=>1,'status'=>'active','expires'=>time()+180,'abilities'=>['meta/save-ads-grant','meta/save-monitoring-grant','meta/health']];if(!Policies::put('connections',$p['connection_id'],$p,true))throw new \RuntimeException('policy_create');return [$r[0],$uuid];};
 $auth=static function(string $pw,string $uuid)use($uid,$login){$u=wp_authenticate_application_password(null,$login,$pw);return $u instanceof \WP_User&&$u->ID===$uid&&Context::key()==='app:'.$uuid;};
 $save=static fn($kind,$rev,$on,$extra=[])=>M\Api::dispatch('save-'.$kind.'-grant',$s+['expected_revision'=>$rev,'enabled'=>$on]+$extra,true);
 try{
  if(!wp_is_application_passwords_available_for_user(get_userdata($uid)))throw new \RuntimeException('app_disabled');
  M\Connections::save(['connection_id'=>$conn,'expected_revision'=>0,'enabled'=>true,'assets'=>['ads'=>['160']]]);
  $ads=M\AdsReader::register_consumer($id,'1.0.0',M\AdsReader::CONTRACT,static function()use(&$cfg){return $cfg;});
  $mon=M\MonitoringReader::register_consumer($id,'1.0.0',M\MonitoringReader::CONTRACT,static function()use(&$cfg,$res){return $cfg+$res;});
  [$pw,$uuid]=$app('A');$assert('autenticacao_A',$auth($pw,$uuid));unset($pw);
  $assert('concedeu_anuncios',$save('ads',0,true)['success']);$assert('concedeu_monitoramento',$save('monitoring',0,true,$res)['success']);
  $before=$ads->status($sel);$assert('prontas_antes',$before['success']&&$mon->status($sel)['success']);
  [$pw2,$uuid2]=$app('B');$assert('autenticacao_B',$auth($pw2,$uuid2));unset($pw2);
  $gone=\WP_Application_Passwords::delete_application_password($uid,$uuid);$assert('A_revogada_B_ativa',$gone===true&&!Context::credential_active('app:'.$uuid,$uid)&&Context::credential_active('app:'.$uuid2,$uid));
  $a=$ads->query($sel);$m=$mon->query($sel+['report'=>'ads_activity']);$assert('historico_anuncios_apos_troca',$a['success']&&is_array($a['data']['rows']));$assert('historico_monitoramento_apos_troca',$m['success']&&is_array($m['data']['rows']));
  $state=static function()use($id){$v=M\Api::dispatch('health',[],true);if(empty($v['success']))return [];return array_values(array_filter($v['data']['consumer_grants'],static fn($g)=>$g['consumer_id']===$id));};
  $rows=$state();$assert('duas_prontas_sem_regravar',count($rows)===2&&!array_diff(array_column($rows,'state'),['ready'])&&array_unique(array_column($rows,'revision'))===[1]);
  $cfg['revision']='2';$rows=$state();$assert('saude_mostra_interrupcao_e_rotas',count($rows)===2&&!array_diff(array_column($rows,'state'),['blocked'])&&!array_diff(array_column($rows,'reason'),['revision_conflict'])&&count(array_unique(array_column($rows,'repair_operation')))===2);$cfg['revision']='1';
  $assert('revogacao_explicita',$save('ads',1,false)['success']&&$save('monitoring',1,false,$res)['success']&&$ads->status($sel)['code']==='grant_revoked'&&$mon->status($sel)['code']==='grant_revoked');
 }catch(\Throwable $e){$error=$e instanceof M\Fault?$e->reason:($e instanceof \RuntimeException&&in_array($e->getMessage(),['test_step','app_create','app_disabled','policy_create'],true)?$e->getMessage():'exception');}
 finally{
  Context::restore_identity($original,$uid);
  foreach($keys as $uuid){$k='app:'.$uuid;if(\WP_Application_Passwords::get_user_application_password($uid,$uuid))\WP_Application_Passwords::delete_application_password($uid,$uuid);if(Policies::get('connections',$k))Policies::delete('connections',$k);$clean[]=!\WP_Application_Passwords::get_user_application_password($uid,$uuid)&&(Policies::get('connections',$k)['_storage']['status']??'deleted')==='deleted';}
  foreach([['ads_grant',$key],['monitoring_grant',$key],['connection',$conn]] as [$bucket,$k]){$r=M\Store::get($bucket,$k);if($r)M\Store::remove($bucket,$k,$r['revision']);$clean[]=M\Store::get($bucket,$k)===null;}
 }
 return ['success'=>$error===null&&!in_array(false,$clean,true),'stage'=>$stage,'error'=>$error,'checks'=>$checks,'clean'=>!in_array(false,$clean,true),'version'=>M\Config::VERSION];
}
add_action('wp_abilities_api_init',static function(){if(wp_parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com')return;wp_register_ability('meta/qa-grant-cycle-026',['label'=>'Aceite temporário Meta 29','description'=>'Exercita exclusivamente concessões sintéticas, sem acesso à Graph.','category'=>'meta','input_schema'=>['type'=>'object','properties'=>[],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>__NAMESPACE__.'\\allowed','execute_callback'=>__NAMESPACE__.'\\run','meta'=>['mcp'=>['public'=>true],'annotations'=>['readonly'=>false,'idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>'0.26.0','policy_contract'=>1,'mode'=>'write','remote_effect'=>'none','local_effect'=>'write']]]);},30);
