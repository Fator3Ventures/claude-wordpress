<?php
defined('ABSPATH') || exit;
function f3lab022_bundle(){
 $p=__DIR__.'/f3-qa022.bundle.gz';
 if(!is_file($p)||hash_file('sha256',$p)!=='__BUNDLE_SHA256__')throw new RuntimeException('Bundle integrity failed');
 $b=json_decode(gzdecode(file_get_contents($p)),true,512,JSON_THROW_ON_ERROR);
 foreach($b['pool'] as $hash=>&$data){
  $data=base64_decode($data,true);
  if($data===false||hash('sha256',$data)!==$hash)throw new RuntimeException('Invalid bundle data');
 }unset($data);
 return $b;
}
/** Temporary Site-Teste-only isolated release lab. No supplied paths, PHP or SQL. */
function f3lab022_manifest(){return get_option('f3_meta_qa022_lab',[]);}
function f3lab022_valid($m){return isset($m['root'],$m['prefix'],$m['php'])&&preg_match('/^f3qa022_[a-f0-9]{12}_$/D',$m['prefix'])&&$m['root']===sys_get_temp_dir().'/'.$m['prefix']&&$m['php']==='/usr/local/php83/bin/php'&&in_array($m['flavor']??'', ['current','baseline','upgrade'],true);}
function f3lab022_copy($a,$b){if(is_dir($a)){if(!is_dir($b))mkdir($b,0700,true);foreach(new DirectoryIterator($a) as $p)if(!$p->isDot())f3lab022_copy($p->getPathname(),$b.'/'.$p->getFilename());}elseif(!copy($a,$b))throw new RuntimeException('lab copy failed');}
function f3lab022_rm($p){if(is_link($p)||is_file($p)){if(!unlink($p))throw new RuntimeException('lab unlink failed');}elseif(is_dir($p)){foreach(new DirectoryIterator($p) as $i)if(!$i->isDot())f3lab022_rm($i->getPathname());if(!rmdir($p))throw new RuntimeException('lab rmdir failed');}}
function f3lab022_exec($m,$script){
 if(!f3lab022_valid($m))throw new RuntimeException('invalid lab manifest');
 $cli=[$m['php']];$env=['PATH'=>'/usr/bin:/bin','F3_LAB_ROOT'=>$m['root'],'F3_LAB_FLAVOR'=>$m['flavor']];$p=proc_open(array_merge($cli,['-d','disable_functions=mail,fsockopen,pfsockopen,stream_socket_client,curl_exec,curl_multi_exec','-d','allow_url_fopen=0','-d','pcre.jit=0','-d','display_errors=stderr','-d','memory_limit=256M',$m['root'].'/'.$script]),[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,$m['root'],$env);
 if(!is_resource($p))throw new RuntimeException('CLI unavailable');fclose($pipes[0]);stream_set_blocking($pipes[1],false);stream_set_blocking($pipes[2],false);$out='';$err='';$start=microtime(true);$rc=null;
 do{$out.=stream_get_contents($pipes[1]);$err.=stream_get_contents($pipes[2]);$s=proc_get_status($p);if(!$s['running']){$rc=$s['exitcode'];break;}if(microtime(true)-$start>50){proc_terminate($p);$err.='lab timeout';$rc=124;break;}usleep(20000);}while(true);
 $out.=stream_get_contents($pipes[1]);$err.=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$closed=proc_close($p);if($rc===null||$rc<0)$rc=$closed;
 foreach([DB_PASSWORD,DB_USER,DB_HOST,DB_NAME,$m['root']] as $secret)if(is_string($secret)&&$secret!==''){$out=str_replace($secret,'[redacted]',$out);$err=str_replace($secret,'[redacted]',$err);}
 return ['exit_code'=>$rc,'stdout'=>substr($out,-150000),'stderr'=>substr($err,-15000),'seconds'=>round(microtime(true)-$start,3)];
}
function f3lab022_run($args){
 if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||!current_user_can('manage_options'))return new WP_Error('forbidden');
 global $wpdb;
 $lock='f3-meta-qa022:'.substr(hash('sha256',$wpdb->prefix.'|'.DB_NAME),0,32);
 if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!=='1')return new WP_Error('lab_busy');
 try{return f3lab022_operation($args);}finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
}
function f3lab022_operation($args){
 $op=$args['operation'];$m=f3lab022_manifest();
 if($op==='setup'){
  if($m)return new WP_Error('lab_exists','Clean previous lab first');$flavor=$args['flavor']??'current';if(!in_array($flavor,['current','baseline','upgrade'],true))return new WP_Error('invalid_flavor');$bundle=f3lab022_bundle();$prefix='f3qa022_'.bin2hex(random_bytes(6)).'_';$root=sys_get_temp_dir().'/'.$prefix;$m=['root'=>$root,'prefix'=>$prefix,'php'=>'/usr/local/php83/bin/php','flavor'=>$flavor];
  if(!mkdir($root,0700))throw new RuntimeException('lab setup failed');if(!add_option('f3_meta_qa022_lab',$m,'',false)){rmdir($root);throw new RuntimeException('lab setup failed');}mkdir($root.'/evidence',0700);mkdir($root.'/wordpress',0700);
  {foreach(['wp-admin','wp-includes'] as $d)if(!symlink(ABSPATH.$d,$root.'/wordpress/'.$d))throw new RuntimeException('lab code link failed');foreach(glob(ABSPATH.'*.php') as $p)if(basename($p)!=='wp-config.php')copy($p,$root.'/wordpress/'.basename($p));}
  $content=$root.'/wordpress/wp-content';if(!is_dir($content))mkdir($content,0700);if(!is_dir($content.'/plugins'))mkdir($content.'/plugins',0700);if(!is_dir($content.'/mu-plugins'))mkdir($content.'/mu-plugins',0700);
  file_put_contents($content.'/mu-plugins/no-external.php','<?php add_filter("pre_http_request",static fn($pre)=>$pre!==false?$pre:new WP_Error("lab_external_blocked"),PHP_INT_MAX);add_filter("pre_wp_mail",static fn()=>true,PHP_INT_MAX);');
  $config='<?php ';foreach(['DB_NAME','DB_USER','DB_PASSWORD','DB_HOST','DB_CHARSET','DB_COLLATE'] as $k)$config.='define('.var_export($k,true).','.var_export(defined($k)?constant($k):'',true).');';
  foreach(['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'] as $k)$config.='define('.var_export($k,true).','.var_export(bin2hex(random_bytes(48)),true).');';
  $config.='$table_prefix='.var_export($prefix,true).';define("DISABLE_WP_CRON",true);define("WP_HOME","https://example.invalid");define("WP_SITEURL","https://example.invalid");define("WP_DEBUG",true);define("WP_DEBUG_DISPLAY",false);define("WP_DEBUG_LOG",true);define("WP_HTTP_BLOCK_EXTERNAL",true);if(!defined("ABSPATH"))define("ABSPATH",__DIR__."/");require ABSPATH."wp-settings.php";';file_put_contents($root.'/wordpress/wp-config.php',$config);chmod($root.'/wordpress/wp-config.php',0600);unset($config);
  foreach($bundle['files'] as $name=>$hash){
   if(!preg_match('~^(?:(?:candidate|baseline)/wp-mcp-meta-fator3/|tests/native/)[A-Za-z0-9_./-]+$~D',$name)||str_contains($name,'..')||!isset($bundle['pool'][$hash]))throw new RuntimeException('Invalid bundle path');
   $file=$root.'/'.$name;if(!is_dir(dirname($file))&&!mkdir(dirname($file),0700,true))throw new RuntimeException('Bundle directory failed');
   if(file_put_contents($file,$bundle['pool'][$hash])===false)throw new RuntimeException('Bundle file failed');
  }unset($bundle);
  $plugin=$content.'/plugins/wp-mcp-meta-fator3';f3lab022_copy($root.'/'.($flavor==='current'?'candidate':'baseline').'/wp-mcp-meta-fator3',$plugin);
  return ['flavor'=>$flavor,'install'=>f3lab022_exec($m,'tests/native/install.php')];
 }
 if(!f3lab022_valid($m))return new WP_Error('lab_missing');
 if($op==='export')return f3lab022_exec($m,'tests/native/export-integrity.php');
 if($op==='dataset')return f3lab022_exec($m,'tests/native/dataset.php');
 if($op==='smoke')return f3lab022_exec($m,'tests/native/smoke.php');
 if($op==='configuration')return f3lab022_exec($m,'tests/native/configuration.php');
 if($op==='release022')return f3lab022_exec($m,'tests/native/release022.php');
 if($op==='effects-map')return f3lab022_exec($m,'tests/native/effects-map.php');
 if($op==='upgrade'){if($m['flavor']!=='upgrade')return new WP_Error('not_upgrade_lab');$dest=$m['root'].'/wordpress/wp-content/plugins/wp-mcp-meta-fator3';f3lab022_rm($dest);f3lab022_copy($m['root'].'/candidate/wp-mcp-meta-fator3',$dest);return f3lab022_exec($m,'tests/native/migrate.php');}
 if($op==='cleanup'){global $wpdb;$tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($m['prefix']).'%'));if($wpdb->last_error)throw new RuntimeException('Lab table enumeration failed');foreach($tables as $t){if(!str_starts_with($t,$m['prefix'])||!preg_match('/^[a-zA-Z0-9_]+$/D',$t))throw new RuntimeException('unsafe lab table');if($wpdb->query('DROP TABLE `'.$t.'`')===false)throw new RuntimeException('lab drop failed');}$remaining=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($m['prefix']).'%'));if($wpdb->last_error||$remaining)throw new RuntimeException('Lab cleanup incomplete');f3lab022_rm($m['root']);delete_option('f3_meta_qa022_lab');return ['tables_dropped'=>count($tables),'remaining_tables'=>count($remaining),'directory_removed'=>!file_exists($m['root']),'manifest_removed'=>!get_option('f3_meta_qa022_lab')];}
 return new WP_Error('operation_invalid');
}
function f3qa022_shared_state(){
 if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com'||!current_user_can('manage_options'))return new WP_Error('forbidden');
 global $wpdb;require_once ABSPATH.'wp-admin/includes/plugin.php';$out=['wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'db'=>$wpdb->db_version(),'meta_version'=>\Fator3\Meta\Config::VERSION];
 foreach(['records'=>\Fator3\Meta\Store::table(),'history'=>\Fator3\Meta\History::table()] as $kind=>$table){
  $hash=hash_init('sha256');$count=0;$complete=false;
  for($at=0;$at<50000;$at+=200){$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i '.($kind==='records'?"WHERE bucket<>'audit' ":'').'ORDER BY '.($kind==='records'?'bucket,record_key':'row_key').' LIMIT 200 OFFSET %d',$table,$at),ARRAY_A);if($wpdb->last_error)return new WP_Error('snapshot_unavailable');foreach($rows as $r){hash_update($hash,wp_json_encode($r)."\n");$count++;}if(count($rows)<200){$complete=true;break;}}
  $out[$kind]=['rows'=>$count,'sha256'=>hash_final($hash),'complete'=>$complete];
 }
 $options=$wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3_meta_%' AND option_name NOT LIKE 'f3_meta_qa022%' AND option_name<>'f3_meta_audit_health' ORDER BY option_name",ARRAY_A);if($wpdb->last_error)return new WP_Error('snapshot_unavailable');$out['options']=['count'=>count($options),'sha256'=>hash('sha256',wp_json_encode($options))];$out['option_hashes']=[];foreach($options as $o)$out['option_hashes'][]=['name'=>$o['option_name'],'sha256'=>hash('sha256',$o['option_value'])];unset($options);
 $core=get_option('f3base_meta_monitoramento',null);$out['core_monitoring_config_sha256']=hash('sha256',wp_json_encode($core));unset($core);$out['plugins']=[];$plugins=get_plugins();
 foreach(['base-site-core-fator3','wp-mcp-fator3','wp-mcp-google-fator3','wp-mcp-linkedin-fator3','wp-mcp-pipedrive-fator3','wp-mcp-meta-fator3'] as $slug){$root=WP_PLUGIN_DIR.'/'.$slug;$files=[];foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $f)if($f->isFile())$files[substr($f->getPathname(),strlen($root)+1)]=hash_file('sha256',$f->getPathname());ksort($files);$hash=hash_init('sha256');foreach($files as $path=>$sha)hash_update($hash,$path."\0".$sha."\n");$out['plugins'][$slug]=['version'=>$plugins[$slug.'/'.$slug.'.php']['Version']??null,'active'=>is_plugin_active($slug.'/'.$slug.'.php'),'files'=>count($files),'tree_sha256'=>hash_final($hash)];}
 return $out;
}

add_action('wp_abilities_api_init',static function(){
 if(parse_url(home_url('/'),PHP_URL_HOST)!=='fator3-teste-mcp-1.dreamhosters.com')return;
 foreach(['lab','state'] as $kind)wp_register_ability('meta/qa-022-'.$kind,['label'=>'Bancada temporária Meta '.$kind,'description'=>'Suíte fechada do painel em instalação própria no Site-Teste.','category'=>'meta','input_schema'=>$kind==='state'?['type'=>'object','properties'=>[],'additionalProperties'=>false]:['type'=>'object','properties'=>['operation'=>['type'=>'string','enum'=>['setup','smoke','dataset','configuration','export','release022','effects-map','upgrade','cleanup']],'flavor'=>['type'=>'string','enum'=>['current','baseline','upgrade']]],'required'=>['operation'],'additionalProperties'=>false],'output_schema'=>['type'=>'object'],'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>$kind==='state'?'f3qa022_shared_state':'f3lab022_run','meta'=>['mcp'=>['public'=>true,'type'=>'tool'],'annotations'=>['readonly'=>$kind==='state','destructive'=>$kind==='lab','idempotent'=>false],'fator3'=>['provider'=>'wp-mcp-meta-fator3','version'=>'0.22.1','policy_contract'=>1,'mode'=>$kind==='state'?'read':'write','remote_effect'=>'none','local_effect'=>$kind==='state'?'none':'write']]]);
},30);
