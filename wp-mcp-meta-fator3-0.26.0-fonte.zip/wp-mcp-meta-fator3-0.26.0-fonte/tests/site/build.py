"""Pack a hash-bound test lab, not an installable WordPress plugin."""
import argparse
import base64
import gzip
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath

BASE_SHA256 = "c2685701485e2103bdfe52758f86ad72cf6ccba38b4af623586d92415f32a548"  # instalador 0.22.0 (base vigente)
SLUG = "wp-mcp-meta-fator3"
parser = argparse.ArgumentParser()
parser.add_argument("baseline", type=Path)
parser.add_argument("candidate", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
tests = Path(__file__).resolve().parents[1]
pool, entries = {}, {}


def put(name, data):
    if name in entries:
        raise ValueError(f"Duplicate bundle path: {name}")
    sha = hashlib.sha256(data).hexdigest()
    entries[name] = sha
    if sha not in pool:
        pool[sha] = base64.b64encode(data).decode("ascii")


def read_installer(archive, stage, version):
    with zipfile.ZipFile(archive) as z:
        data = {}
        for item in z.infolist():
            path = PurePosixPath(item.filename)
            if (not path.parts or path.parts[0] != SLUG or ".." in path.parts or
                    "\\" in item.filename or (item.external_attr >> 16) & 0o170000 == 0o120000):
                raise ValueError("Unsafe installer member")
            if item.is_dir():
                continue
            key = str(path.relative_to(SLUG))
            if key in data or str(path) != item.filename:
                raise ValueError("Invalid or duplicate installer member")
            data[key] = z.read(item)
        header = data[SLUG + ".php"].decode("utf-8")
        if not re.search(r"(?m)^ \* Version: " + re.escape(version) + r"\s*$", header):
            raise ValueError(f"Expected {version} in {archive.name}")
        manifest = json.loads(data["manifest.sha256.json"])
        if manifest != {k: hashlib.sha256(v).hexdigest() for k, v in data.items()
                        if k != "manifest.sha256.json"}:
            raise ValueError("Manifest mismatch in " + archive.name)
        for key, value in data.items():
            put(f"{stage}/{SLUG}/{key}", value)


if hashlib.sha256(args.baseline.read_bytes()).hexdigest() != BASE_SHA256:
    parser.error("The baseline must be the exact delivered 0.22.0 installer.")
read_installer(args.baseline, "baseline", "0.22.0")
read_installer(args.candidate, "candidate", "0.22.1")
required = {"guard.php", "install.php", "smoke.php", "configuration.php", "dataset.php",
            "export-integrity.php", "migrate.php", "seed-connection090.php", "migration-state.php",
            "migration-seed.php", "migration-consumer.php", "release022.php", "effects-map.php"}
for name in sorted(required):
    put("tests/native/" + name, (tests / "native" / name).read_bytes())
# Identical runtime files occur only once, even if both trees contain them.
raw = gzip.compress(json.dumps({"files": entries, "pool": pool}, sort_keys=True,
                               separators=(",", ":")).encode("ascii"), mtime=0)
sha = hashlib.sha256(raw).hexdigest()
args.output.mkdir(exist_ok=True, parents=True)
(args.output / "f3-qa022.bundle.gz").write_bytes(raw)
code = (tests / "site/controller.php").read_text()
assert code.count("__BUNDLE_SHA256__") == 1
(args.output / "f3-qa022.php").write_text(code.replace("__BUNDLE_SHA256__", sha))
print(json.dumps({"bundle_sha256": sha, "bundle_bytes": len(raw), "paths": len(entries),
                  "unique_files": len(pool), "baseline_sha256": BASE_SHA256,
                  "candidate_sha256": hashlib.sha256(args.candidate.read_bytes()).hexdigest()}))
