"""Casos do build documental (C8, C6, R6/R8 duros, captura de outra versão), sobre uma cópia temporária de build/.

uso: python3 tests/docs/build-cases.py
Cada caso copia build/ (sem dist) para um diretório temporário, altera a cópia e roda build.py com F3_DOCS_LINT=warn.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parents[2] / 'build'
results = []


def build(mutate, lint='warn'):
    tmp = Path(tempfile.mkdtemp(prefix='f3-build-case-'))
    try:
        dst = tmp / 'build'
        shutil.copytree(SRC, dst, ignore=shutil.ignore_patterns('dist', '__pycache__'))
        mutate(dst)
        env = dict(os.environ, F3_DOCS_LINT=lint)
        env.pop('F3_EXAMPLES_BOOTSTRAP', None)
        r = subprocess.run([sys.executable, str(dst / 'build.py')], capture_output=True, text=True, env=env)
        return r, dst / 'dist' / 'wp-mcp-meta-fator3', tmp
    except Exception:
        shutil.rmtree(tmp)
        raise


def add_manual(dst, name, text, entry=True):
    (dst / 'docs/meta' / name).write_text(text, encoding='utf-8')
    if entry:
        cat = json.loads((dst / 'docs/meta/catalog.json').read_text(encoding='utf-8'))
        cat['documents'].append({'document': name, 'title': 'Caso de marcadores', 'summary': 'Documento temporário do teste de build.', 'topic': 'uso'})
        (dst / 'docs/meta/catalog.json').write_text(json.dumps(cat, ensure_ascii=False), encoding='utf-8')


def check(name, ok, info=None):
    results.append({'name': name, 'passed': bool(ok)} | ({} if ok or info is None else {'info': info}))


# 1. Marcadores resolvidos e hashes calculados depois da resolução.
r, plugin, tmp = build(lambda d: add_manual(d, 'MARCADORES.md', '# Marcadores\n\nV={{VERSION}} B={{BASE_VERSION}} O={{OPERATION_COUNT}} D={{DOCUMENT_COUNT}}\n'))
try:
    ok = r.returncode == 0
    check('build com marcadores conhecidos conclui', ok, r.stderr[-600:])
    if ok:
        text = (plugin / 'docs/MARCADORES.md').read_text(encoding='utf-8')
        ops = len(json.loads((plugin / 'docs/input-schemas.json').read_text(encoding='utf-8')))
        docs = len([p for p in (plugin / 'docs').iterdir() if p.is_file()])
        version = re.search(r"VERSION='([0-9.]+)'", (SRC / 'build.py').read_text()).group(1)
        base = re.search(r"BASE_VERSION='([0-9.]+)'", (SRC / 'build.py').read_text()).group(1)
        check('C8 marcadores resolvidos com versão, base e contagens reais', text == f'# Marcadores\n\nV={version} B={base} O={ops} D={docs}\n', text)
        data = (plugin / 'includes/Data/Documentation.php').read_text(encoding='utf-8')
        digest = hashlib.sha256((plugin / 'docs/MARCADORES.md').read_bytes()).hexdigest()
        check('C8 índice compilado usa o SHA-256 do arquivo resolvido', f"'MARCADORES.md'=>['document'=>'MARCADORES.md','bytes'=>{len(text.encode())},'sha256'=>'{digest}'" in data)
        manifest = json.loads((plugin / 'manifest.sha256.json').read_text())
        check('C8 manifesto usa o SHA-256 do arquivo resolvido', manifest.get('docs/MARCADORES.md') == digest)
        order = re.findall(r"^'([^']+)'=>\['document'", data, re.M)
        cat = json.loads((SRC / 'docs/meta/catalog.json').read_text(encoding='utf-8'))
        check('C6 índice compilado segue a ordem do catálogo', order == [d['document'] for d in cat['documents']] + ['MARCADORES.md'])
finally:
    shutil.rmtree(tmp)

# 2. Recusas duras.
for name, mutate, expect, lint in [
    ('R8 marcador desconhecido reprova mesmo em warn', lambda d: add_manual(d, 'MARCADORES.md', '# M\n\n{{DESCONHECIDO}}\n'), 'R8', 'warn'),
    ('R6 arquivo fora do catálogo reprova mesmo em warn', lambda d: add_manual(d, 'SOLTO.md', '# Solto\n\nTexto.\n', entry=False), 'R6', 'warn'),
    ('captura de outra versão recusada', lambda d: (d / 'docs/examples/captured.json').write_text(
        (d / 'docs/examples/captured.json').read_text(encoding='utf-8').replace('"plugin_version": "', '"plugin_version": "9.', 1), encoding='utf-8'), 'outra versão', 'warn'),
    ('REFERENCE.md escrito à mão recusado', lambda d: (d / 'docs/meta/REFERENCE.md').write_text('# x\n'), 'gerado pelo build', 'warn'),
    ('F3_DOCS_LINT inválido recusado', lambda d: None, 'F3_DOCS_LINT', 'off'),
]:
    r, plugin, tmp = build(mutate, lint)
    try:
        check(name, r.returncode != 0 and expect in r.stderr, r.stderr[-400:])
    finally:
        shutil.rmtree(tmp)

out = {'total': len(results), 'failed': sum(not r['passed'] for r in results), 'checks': results}
print(json.dumps(out, ensure_ascii=False, indent=1))
sys.exit(1 if out['failed'] else 0)
