"""Casos do lint documental (build/docs_lint.py): um caso mínimo por regra que a faz disparar e um caso limpo que passa.

uso: python3 tests/docs/lint-cases.py
Não altera a árvore: cada caso usa um diretório temporário.
"""
import copy
import json
import sys
import tempfile
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'build'))
import docs_lint as L  # noqa: E402

OPS = ['alpha', 'beta']
REGISTRY = {op: {'schema': {'type': 'object', 'properties': {'connection_id': {'type': 'string', 'maxLength': 64}}, 'required': ['connection_id'] if op == 'alpha' else []},
                 'effects': {'mode': 'read' if op == 'alpha' else 'write', 'local_effect': 'none' if op == 'alpha' else 'write', 'remote_effect': 'none',
                             'readonly': op == 'alpha', 'destructive': False, 'idempotent': op == 'alpha'},
                 'label': 'Meta: operação ' + op, 'description': 'Descrição sintética da operação ' + op + '.'} for op in OPS}
TOPICS = {t: t.capitalize() for t in L.LOGICAL_TOPICS}
LONG = ('Este parágrafo sintético tem mais de cento e sessenta caracteres para que a regra de repetição possa ser exercitada '
        'sem depender dos manuais reais do plugin, que mudam em outra frente.')
CLEAN = {
    'README.md': '# Índice\n\nVeja `meta/alpha` e CONTRACTS.md. São 2 operações e 9 documentos.\n\n' + LONG + '\n',
    'SPEC.md': '# Especificação\n\nTexto.\n', 'CONFIG.md': '# Configuração\n\nTexto.\n', 'USAGE.md': '# Uso\n\nTexto.\n',
    'CONTRACTS.md': '# Contratos\n\nTexto.\n', 'AGENTS.md': '# Agentes\n\nTexto.\n', 'OPERATIONS.md': '# Operação\n\nTexto.\n',
    'CHANGELOG.md': '# Notas da versão\n\n## 0.22.0\n\nTexto com versão fora do H1.\n',
}
TOPIC_OF = {'README.md': 'indice', 'SPEC.md': 'especificacao', 'CONFIG.md': 'configuracao', 'USAGE.md': 'uso', 'CONTRACTS.md': 'contratos',
            'AGENTS.md': 'agentes', 'OPERATIONS.md': 'operacao', 'CHANGELOG.md': 'notas', 'REFERENCE.md': 'contratos'}


def catalog(files):
    return {'topics': dict(TOPICS), 'documents': [{'document': f, 'title': 'Título ' + f, 'summary': 'Resumo de ' + f, 'topic': TOPIC_OF.get(f, 'indice')} for f in files]}


def run(docs, cat=None, mode='fail', registry=REGISTRY, ops=OPS):
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp) / 'plugin'
        (root / 'docs').mkdir(parents=True)
        (root / 'wp-mcp-meta-fator3.php').write_text('<?php\n')
        files = dict(docs)
        if 'REFERENCE.md' not in files:
            files['REFERENCE.md'] = L.reference_markdown(registry, 'meta', '0.22.0')
        for name, text in files.items():
            (root / 'docs' / name).write_text(text, encoding='utf-8')
        return L.lint(root / 'docs', root, cat if cat is not None else catalog(sorted(files)), ops, 'meta', mode)


results = []


def case(name, docs=None, cat=None, rule=None, mode='fail', registry=REGISTRY, warn_rule=None):
    errors, warnings = run(CLEAN if docs is None else docs, cat, mode, registry)
    if rule is None and warn_rule is None:
        ok = not errors and not warnings
    elif rule is not None:
        ok = any(e.startswith(rule + ' ') for e in errors) and all(e.startswith(rule + ' ') for e in errors)
    else:
        ok = not errors and any(w.startswith(warn_rule + ' ') for w in warnings)
    results.append({'name': name, 'passed': ok, 'errors': errors[:3], 'warnings': warnings[:3]})


def with_doc(name, text):
    d = dict(CLEAN)
    d[name] = text
    return d


case('limpo: nenhum erro nem aviso')
case('R1 H1 com número de versão', with_doc('SPEC.md', '# Especificação 0.22.0\n\nTexto.\n'), rule='R1')
case('R2 parágrafo longo repetido em dois .md', with_doc('USAGE.md', '# Uso\n\n' + LONG + '\n'), rule='R2')
case('R2 não conta bloco de código', with_doc('USAGE.md', '# Uso\n\n```\n' + LONG + '\n```\n'))
case('R3 operação citada fora do registro', with_doc('USAGE.md', '# Uso\n\nChame `meta/gamma`.\n'), rule='R3')
case('R3 ignora a rota REST f3-meta/v1', with_doc('USAGE.md', '# Uso\n\nRota `f3-meta/v1/alpha` e pasta docs/meta/x.\n'))
case('R4 arquivo citado fora do conjunto instalado', with_doc('USAGE.md', '# Uso\n\nLeia catalog.json e OUTRO.md.\n'), rule='R4')
case('R4 aceita arquivo instalado com caminho relativo', with_doc('USAGE.md', '# Uso\n\nLeia docs/SPEC.md e SPEC.md; ignore https://example.invalid/a.json.\n'))
case('R5 operação do registro ausente do REFERENCE.md', with_doc('REFERENCE.md', L.reference_markdown(REGISTRY, 'meta', '0.22.0').replace('### `meta/beta`', '### beta')), rule='R5')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
bad['documents'][0]['summary'] = 'x' * 201
case('R6 summary com mais de 200 caracteres', cat=bad, rule='R6')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
del bad['documents'][1]['title']
case('R6 entrada sem title', cat=bad, rule='R6')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
bad['documents'] = [d for d in bad['documents'] if d['document'] != 'USAGE.md']
case('R6 arquivo instalado fora do catálogo', cat=bad, rule='R6')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
bad['documents'].append({'document': 'FANTASMA.md', 'title': 'x', 'summary': 'y', 'topic': 'uso'})
case('R6 entrada do catálogo sem arquivo', cat=bad, rule='R6')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
for d in bad['documents']:
    if d['topic'] == 'agentes':
        d['topic'] = 'indice'
case('R6 tema lógico sem documento', cat=bad, rule='R6')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
bad['documents'][2]['topic'] = 'inexistente'
case('R6 topic fora do mapa', cat=bad, rule='R6')
case('R7 contagem literal divergente', with_doc('USAGE.md', '# Uso\n\nO plugin tem 3 operações.\n'), rule='R7')
case('R7 contagem de documentos divergente', with_doc('USAGE.md', '# Uso\n\nLeia os 4 documentos.\n'), rule='R7')
case('R8 marcador não resolvido', with_doc('USAGE.md', '# Uso\n\nVersão {{VERSION}}.\n'), rule='R8')
case('modo warn: R1 vira aviso', with_doc('SPEC.md', '# Especificação 0.22.0\n\nTexto.\n'), mode='warn', warn_rule='R1')
case('modo warn: R8 continua erro', with_doc('USAGE.md', '# Uso\n\n{{OPERATION_COUNT}}\n'), mode='warn', rule='R8')
bad = catalog(sorted(list(CLEAN) + ['REFERENCE.md']))
bad['documents'][0]['summary'] = ''
case('modo warn: R6 continua erro', cat=bad, mode='warn', rule='R6')

# Validação da captura de exemplos (EXAMPLES.md).
base = json.loads((Path(__file__).resolve().parents[2] / 'build/docs/examples/captured.json').read_text(encoding='utf-8'))
modes = None


def examples_case(name, mutate, expect_ok):
    data = copy.deepcopy(base)
    mutate(data)
    try:
        L.validate_examples(data, base['plugin_version'], modes)
        ok = expect_ok
    except RuntimeError:
        ok = not expect_ok
    results.append({'name': name, 'passed': ok})


examples_case('captura atual aceita', lambda d: None, True)
examples_case('captura de outra versão recusada', lambda d: d.update(plugin_version='0.21.0'), False)
examples_case('segredo preenchido recusado', lambda d: d['examples'][0]['entrada'].update(token='abc'), False)
examples_case('falta exemplo parcial recusada', lambda d: d.update(examples=[e for e in d['examples'] if e['tipo'] != 'parcial']), False)
examples_case('falta revision_conflict recusada', lambda d: d.update(examples=[e for e in d['examples'] if e['saida'].get('code') != 'revision_conflict']), False)

out = {'total': len(results), 'failed': sum(not r['passed'] for r in results), 'checks': results}
print(json.dumps(out, ensure_ascii=False, indent=1))
sys.exit(1 if out['failed'] else 0)
