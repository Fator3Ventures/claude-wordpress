"""Run integrity checks without changing a package file."""
import sys,subprocess,tempfile,shutil
from pathlib import Path
with tempfile.TemporaryDirectory() as tmp:
 p=Path(tmp)/'plugin';shutil.copytree(sys.argv[2],p)
 subprocess.run([sys.argv[1],str(Path(__file__).with_name('read.php')),str(p)],check=True)
