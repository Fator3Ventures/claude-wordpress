<?php
/**
 * Captura os exemplos de EXAMPLES.md executando o plugin construído no laboratório isolado (HTTP bloqueado).
 * Só dados sintéticos. A chamada ao fornecedor do exemplo parcial é simulada por pre_http_request, restrita a este script.
 * Saída: JSON para build/docs/examples/captured.json. Ver tests/README.md (seção Exemplos).
 */
use Fator3\Meta as M;
require is_file(__DIR__.'/guard.php')?__DIR__.'/guard.php':__DIR__.'/../native/guard.php';
require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();
require is_file(__DIR__.'/seed-connection090.php')?__DIR__.'/seed-connection090.php':__DIR__.'/../native/seed-connection090.php';
wp_set_current_user(1);
$token='EXEMPLO-TOKEN-SINTETICO-'.bin2hex(random_bytes(8));
$call=static function(string $op,array $input){$q=new WP_REST_Request('POST','/'.M\Config::REST.'/'.$op);$q->set_header('Content-Type','application/json');$q->set_body(wp_json_encode($input));$r=rest_do_request($q);if($r->get_status()!==200)throw new RuntimeException("HTTP {$r->get_status()} em $op");return json_decode(wp_json_encode($r->get_data()),true);};
$examples=[];$add=static function(string $id,string $titulo,string $tipo,string $op,array $in,array $out,?string $recorte=null)use(&$examples){$examples[]=['id'=>$id,'titulo'=>$titulo,'tipo'=>$tipo,'operacao'=>$op,'entrada'=>$in===[]?new stdClass:$in,'saida'=>$out]+($recorte?['recorte'=>$recorte]:[]);};
$blocked=0;$block=static function($pre)use(&$blocked){if($pre!==false)return $pre;++$blocked;return new WP_Error('lab_external_blocked');};add_filter('pre_http_request',$block,5);

// 1. Gravação de conexão sem credencial.
$in=['connection_id'=>'exemplo-alfa','expected_revision'=>0,'label'=>'Exemplo Alfa','enabled'=>false,'retention_mode'=>'finite','retention_days'=>90,'assets'=>['instagram'=>['17841400000000001']],'users'=>[1]];
$saved=$call('save-connection',$in);if(!$saved['success'])throw new RuntimeException('save-connection');
$add('gravar-conexao-sem-credencial','Gravar conexão sem credencial','sucesso','save-connection',$in,$saved);
// 2. Leitura.
$in=['connection_id'=>'exemplo-alfa'];$read=$call('get-connection',$in);if(!$read['success'])throw new RuntimeException('get-connection');
$add('ler-conexao','Ler uma conexão','sucesso','get-connection',$in,$read);
// 3. Vazio.
$in=[];$empty=$call('list-schedules',$in);if(!$empty['success']||$empty['data']['schedules']!==[])throw new RuntimeException('list-schedules');
$add('listar-agendas-vazio','Listar agendas sem nenhuma cadastrada','vazio','list-schedules',$in,$empty);
// 4. Erro de schema com o parâmetro identificado.
$in=['query'=>['connection_id'=>'exemplo-alfa','channel'=>'instagram','account_id'=>'17841400000000001','report'=>'relatorio-inexistente'],'idempotency_key'=>'exemplo-1'];
$bad=$call('create-job',$in);if($bad['code']!=='invalid_input'||($bad['details']['field']??'')==='')throw new RuntimeException('invalid_input');
$add('erro-parametro-invalido','Recusa de schema com parâmetro identificado','erro','create-job',$in,$bad);
// 5. Ativo não selecionado na conexão.
$in=['connection_id'=>'exemplo-alfa','channel'=>'instagram','account_id'=>'17841400000000002','report'=>'profile'];
$denied=$call('query',$in);if($denied['code']!=='asset_access_denied')throw new RuntimeException('asset_access_denied: '.$denied['code']);
$add('erro-ativo-nao-selecionado','Consulta a ativo não selecionado na conexão','erro','query',$in,$denied);
// 6. Revisão desatualizada.
$in=['connection_id'=>'exemplo-alfa','expected_revision'=>0,'label'=>'Exemplo Alfa renomeada'];
$conflict=$call('save-connection',$in);if($conflict['code']!=='revision_conflict')throw new RuntimeException('revision_conflict');
$add('erro-revisao-desatualizada','Gravação com revisão desatualizada','erro','save-connection',$in,$conflict);

// 7. Resultado parcial: dataset com contagens disponíveis e qualidade (EMQ) recusada pelo fornecedor simulado.
$account='19001';$dataset='19002';$id='exemplo-dataset';$calls=0;
$tz=new DateTimeZone('America/Sao_Paulo');$day=(new DateTimeImmutable('yesterday',$tz))->format('Y-m-d');
$fixture=static function($pre,$args,$url)use(&$calls,$account,$dataset){
    if(!str_starts_with($url,'https://graph.facebook.com/'))return new WP_Error('unexpected_host');++$calls;
    $path=preg_replace('~^/v[0-9.]+/~','',parse_url($url,PHP_URL_PATH));parse_str(parse_url($url,PHP_URL_QUERY)??'',$x);
    $resp=static fn($v,$http=200)=>['response'=>['code'=>$http],'headers'=>[],'body'=>wp_json_encode($v)];
    if($path==='me')return $resp(['id'=>'19000']);
    if($path==='act_'.$account)return $resp(['id'=>'act_'.$account,'account_id'=>$account,'timezone_name'=>'America/Sao_Paulo','currency'=>'BRL']);
    if($path==='act_'.$account.'/adspixels')return $resp(['data'=>[['id'=>$dataset]]]);
    if($path===$dataset.'/stats'){$b=[];for($at=(int)$x['start_time'];$at<(int)$x['end_time'];$at+=3600)$b[]=['aggregation'=>'event','start_time'=>$at,'data'=>[['value'=>'Lead','count'=>$at===(int)$x['start_time']?(($x['event_source']??'')==='WEB_ONLY'?5:7):0]]];return $resp(['data'=>$b]);}
    if($path==='act_'.$account.'/adsets')return $resp(['data'=>[['id'=>'19003','account_id'=>$account,'effective_status'=>'ACTIVE','name'=>'Conjunto sintético','promoted_object'=>['pixel_id'=>$dataset,'custom_event_type'=>'LEAD']]]]);
    if($path==='dataset_quality')return $resp(['error'=>['message'=>'(#100) Simulação de laboratório: permissão insuficiente','type'=>'OAuthException','code'=>100]],400);
    return new WP_Error('unexpected_path');
};
add_filter('pre_http_request',$fixture,1,3);
lab_seed_connection090(['connection_id'=>$id,'expected_revision'=>0,'token'=>$token,'assets'=>['ads'=>[$account],'dataset'=>[$dataset]]]);
$r=M\Store::get('connection',$id);$v=$r['value'];$v['token_identity']=['app_verified'=>true,'validated_generation'=>$v['credential_generation'],'scopes'=>['ads_read']];M\Store::put('connection',$id,$v,$r['revision']);
$in=['connection_id'=>$id,'channel'=>'dataset','account_id'=>$dataset,'ads_account_id'=>$account,'report'=>'dataset_quality','date_from'=>$day,'date_to'=>$day];
$partial=$call('query',$in);remove_filter('pre_http_request',$fixture,1);
if(!$partial['success']||($partial['data']['coverage']['complete']??true)!==false||!$partial['data']['rows'])throw new RuntimeException('partial: '.wp_json_encode($partial));
$shown=$partial;$catalog=count($partial['data']['field_catalog']);$shown['data']['field_catalog']=array_slice($partial['data']['field_catalog'],0,1);
$add('consulta-parcial','Consulta de dataset com parte indisponível','parcial','query',$in,$shown,'data.field_catalog reduzido ao primeiro de '.$catalog.' itens; demais campos da saída completos.');

// Nenhum segredo nem chamada fora da simulação.
$json=wp_json_encode($examples);
if(str_contains($json,$token))throw new RuntimeException('token sintético vazou para a captura');
if($blocked!==0)throw new RuntimeException('chamada HTTP fora da simulação');
echo wp_json_encode(['plugin_version'=>M\Config::VERSION,'captured_at'=>gmdate('Y-m-d\TH:i:s\Z'),'wordpress'=>$GLOBALS['wp_version'],'php'=>PHP_VERSION,'simulated_provider_calls'=>$calls,'examples'=>$examples],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
