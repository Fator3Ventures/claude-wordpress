<?php
/**
 * Simulador local da Graph API para o WordPress de laboratório. Nunca integra o instalador.
 * Responde somente a graph.facebook.com; qualquer outro destino continua bloqueado.
 * Dados sintéticos. Registra URLs sem correspondência em wp-content/lab-graph-miss.log.
 */
add_filter('pre_http_request', static function ($pre, $args, $url) {
    $p = wp_parse_url($url);
    if (($p['host'] ?? '') !== 'graph.facebook.com') return new WP_Error('lab_external_blocked', 'bloqueado no laboratório');
    $path = preg_replace('~^/v[0-9.]+/~', '', $p['path'] ?? '');
    parse_str($p['query'] ?? '', $q);
    $auth = $args['headers']['Authorization'] ?? '';
    $token = preg_replace('/^Bearer\s+/', '', $auth);
    $ok = static fn(array $body, int $code = 200) => ['headers' => new WpOrg\Requests\Utility\CaseInsensitiveDictionary(['content-type' => 'application/json']), 'body' => wp_json_encode($body), 'response' => ['code' => $code, 'message' => $code === 200 ? 'OK' : 'Error'], 'cookies' => [], 'filename' => null];
    $err = static fn(string $m, int $code = 190, int $http = 400) => $ok(['error' => ['message' => $m, 'type' => 'OAuthException', 'code' => $code, 'fbtrace_id' => 'LABTRACE']], $http);
    $scopes = ['pages_show_list', 'pages_read_engagement', 'read_insights', 'instagram_basic', 'instagram_manage_insights', 'ads_read'];
    $subjects = ['LABTOKENALFA' => ['111000111', 'Usuário do sistema Alfa'], 'LABTOKENBETA' => ['222000222', 'Usuário do sistema Beta']];
    if ($path === 'debug_token') {
        $in = $q['input_token'] ?? '';
        if (!isset($subjects[$in]) && !str_starts_with($in, 'PAGETOKEN')) return $ok(['data' => ['is_valid' => false, 'error' => ['message' => 'Token inválido (laboratório)', 'code' => 190]]]);
        $s = $subjects[$in] ?? ['111000111', 'Página'];
        return $ok(['data' => ['is_valid' => true, 'app_id' => '123456789012345', 'application' => 'App de Laboratório', 'type' => 'SYSTEM_USER', 'user_id' => $s[0], 'expires_at' => 0, 'scopes' => $scopes]]);
    }
    if (!isset($subjects[$token]) && !str_starts_with($token, 'PAGETOKEN')) return $err('Invalid OAuth access token (laboratório).');
    if ($path === 'me') return $ok(['id' => $subjects[$token][0] ?? '111000111', 'name' => $subjects[$token][1] ?? 'Página']);
    if ($path === 'me/permissions') return $ok(['data' => array_map(static fn($s) => ['permission' => $s, 'status' => 'granted'], $scopes)]);
    $pages = [['id' => '700000000000001', 'name' => 'Korvena — Página institucional', 'instagram_business_account' => ['id' => '17841400000000001', 'username' => 'korvena.lab', 'name' => 'Korvena Lab']], ['id' => '700000000000002', 'name' => 'CTO Office — Página', 'instagram_business_account' => ['id' => '17841400000000002', 'username' => 'ctooffice.lab', 'name' => 'CTO Office Lab']]];
    if ($path === 'me/accounts') return $ok(['data' => $pages]);
    $ads = [['id' => 'act_900000000000001', 'account_id' => '900000000000001', 'name' => 'Conta de anúncios Korvena', 'currency' => 'BRL', 'timezone_name' => 'America/Sao_Paulo'], ['id' => 'act_900000000000002', 'account_id' => '900000000000002', 'name' => 'Conta de anúncios CTO Office', 'currency' => 'BRL', 'timezone_name' => 'America/Sao_Paulo']];
    if ($path === 'me/adaccounts') return $ok(['data' => $ads]);
    if (preg_match('~^act_([0-9]+)$~', $path, $m)) { foreach ($ads as $a) if ($a['account_id'] === $m[1]) return $ok($a); return $err('Unsupported get request.', 100); }
    if (preg_match('~^act_([0-9]+)/adspixels$~', $path)) return $ok(['data' => [['id' => '500000000000001', 'name' => 'Pixel Korvena']]]);
    if (preg_match('~^([0-9]+)$~', $path, $m)) {
        $fields = explode(',', $q['fields'] ?? 'id');
        foreach ($pages as $pg) {
            if ($pg['id'] === $m[1]) { $o = ['id' => $pg['id'], 'name' => $pg['name']]; if (in_array('access_token', $fields, true)) $o['access_token'] = 'PAGETOKEN' . $pg['id']; return $ok($o); }
            if ($pg['instagram_business_account']['id'] === $m[1]) return $ok(['id' => $m[1], 'username' => $pg['instagram_business_account']['username'], 'name' => $pg['instagram_business_account']['name'], 'biography' => 'Perfil sintético de laboratório.', 'website' => 'https://example.invalid', 'followers_count' => 4812, 'follows_count' => 312, 'media_count' => 96, 'profile_picture_url' => 'https://example.invalid/p.jpg']);
        }
        if ($m[1] === '500000000000001') return $ok(['id' => $m[1], 'name' => 'Pixel Korvena']);
        return $err('Unsupported get request. Object does not exist (laboratório).', 100);
    }
    if (preg_match('~^([0-9]+)/media$~', $path)) return $ok(['data' => [['id' => '18000000000000001', 'caption' => 'Lançamento do novo serviço', 'media_type' => 'IMAGE', 'media_product_type' => 'FEED', 'timestamp' => '2026-11-01T12:00:00+0000', 'permalink' => 'https://www.instagram.com/p/LAB1/', 'like_count' => 120, 'comments_count' => 8], ['id' => '18000000000000002', 'caption' => 'Bastidores da equipe', 'media_type' => 'VIDEO', 'media_product_type' => 'REELS', 'timestamp' => '2026-11-03T15:30:00+0000', 'permalink' => 'https://www.instagram.com/reel/LAB2/', 'like_count' => 342, 'comments_count' => 27]]]);
    @file_put_contents(WP_CONTENT_DIR . '/lab-graph-miss.log', $path . '?' . ($p['query'] ?? '') . "\n", FILE_APPEND);
    return $err('Rota não simulada no laboratório: ' . $path, 100);
}, 10, 3);
