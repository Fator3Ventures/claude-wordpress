"""Checks the installed admin renderer with synthetic account lists and controlled REST responses."""
import copy
import json
import os
import subprocess
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[2]
runtime, output = map(Path, sys.argv[1:])
fixture = json.loads(subprocess.check_output([os.environ['F3_SOCIAL_PHP'], str(root/'tests/browser/render.php'), str(runtime), 'identity']))
config = fixture['config']
source = config['bootstrap']['connections'][0]
checks = []
def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'], args=['--no-sandbox','--no-zygote'])
    page = browser.new_page(viewport={'width':1440,'height':900})
    page.set_default_timeout(4000)
    page.route('**/*',lambda r:r.fulfill(body='<!doctype html><meta charset="utf-8">'+fixture['html'],content_type='text/html; charset=utf-8'))
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    def load(connections):
        page.goto('https://example.invalid/')
        config['bootstrap']['connections']=connections
        page.evaluate('(cfg)=>window.F3Social=cfg',config)
        page.add_style_tag(content=(runtime/'assets/admin.css').read_text())
        page.evaluate("""()=>{window.qa={deferred:null,requests:[]};
          window.fetch=async (url,opts)=>{
            const input=JSON.parse(opts.body);qa.requests.push(input);
            const result=data=>({ok:true,status:200,json:async()=>({success:true,data})});
            if(input.kind==='assets' && input.channel==='dataset'){
              if(qa.delay){qa.delay=false;return new Promise(resolve=>qa.deferred=()=>resolve(result({rows:[{id:'919',name:'A atrasado'}],next_cursor:'obsolete',connection_revision:7})));}
              const a=input.ads_account_id==='101';
              return result({rows:a?[{id:'811',name:'A marcado'},{id:'812',name:'A livre'}]:[{id:'822',name:'B disponível'}],next_cursor:'page',connection_revision:7});
            }
            if(input.kind==='selected' && input.channel==='ads')return result({rows:[{id:'101',name:'Ads A'},{id:'102',name:'Ads B'}],next_offset:null,connection_revision:7});
            return result({rows:[],next_offset:null,connection_revision:7});
          }}""")
        page.add_script_tag(content=(runtime/'assets/admin.js').read_text())
        page.wait_for_selector('.f3-connection-card')
    panel=page.locator('.f3-steps')
    step=page.locator('[data-step=query]')
    good=copy.deepcopy(source)
    for label,overrides in [('paused',{'enabled':False}),('expired',{'expires_at':1}),('only dataset',{'assets':{'dataset':['101']}})]:
        load([dict(good,**overrides)])
        check(label+' does not unlock first query',panel.is_visible() and step.get_attribute('data-state')=='pending')
    load([dict(good,assets={}),dict(good,id='other',token_configured=False)])
    check('Token and asset must belong to one connection',panel.is_visible() and step.get_attribute('data-state')=='pending')
    good['assets']={'ads':['101','102'],'dataset':['700'],'instagram':[],'facebook':[]}
    load([good])
    check('One active complete connection dismisses setup',panel.is_hidden())
    page.locator('[data-tab=assets]').click()
    page.locator('[data-switch=assets] [data-view=dataset]').click()
    box=page.locator('#f3-assets-channel-dataset')
    first=box.get_by_role('button',name='Carregar ativos disponíveis')
    more=box.get_by_role('button',name='Carregar mais ativos')
    select=box.locator('select')
    first.click()
    box.locator('input[value="811"]').check()
    select.select_option('102')
    check('Already selected and draft selections survive switch',all(box.locator('[value="'+i+'"]').is_checked() for i in ('700','811')))
    check('Unselected results of prior account removed',box.locator('[value="812"]').count()==0)
    check('Old cursor removed',more.is_hidden())
    select.select_option('101')
    page.evaluate('window.qa.delay=true')
    first.click();page.wait_for_function('typeof qa.deferred==="function"')
    select.select_option('102');select.select_option('101')
    page.evaluate('qa.deferred()')
    page.wait_for_function("!document.querySelector('#f3-assets-channel-dataset .f3-channel-actions button').disabled")
    check('Late A response after A-B-A discarded',box.locator('[value="919"]').count()==0 and more.is_hidden())
    select.select_option('102')
    first.click();box.locator('[value="822"]').wait_for()
    check('Current account can discover and paginate',more.is_visible() and box.locator('[value="822"]').count()==1)
    for width in (1440,390):
        page.set_viewport_size({'width':width,'height':844})
        check(f'Dataset selector inside panel at {width} px',select.evaluate('(s)=>s.getBoundingClientRect().width>0 && s.getBoundingClientRect().right<=window.innerWidth+1'))
    check('No script errors',not errors)
    browser.close()
failed=sum(not row['passed'] for row in checks)
output.write_text(json.dumps({'version':config['version'],'browser':browser.version,'checks':checks,'total':len(checks),'failed':failed},indent=2)+'\n')
print(len(checks),failed)
sys.exit(1 if failed else 0)
