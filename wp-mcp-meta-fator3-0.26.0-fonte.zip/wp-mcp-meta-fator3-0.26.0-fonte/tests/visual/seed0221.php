<?php
use Fator3\Meta as M;
require __DIR__.'/../native/guard.php';require f3qa022_root().'/wordpress/wp-load.php';f3qa022_guard_db();wp_set_current_user(1);
if(!getenv('F3_QA_PASSWORD'))exit(1);wp_set_password(getenv('F3_QA_PASSWORD'),1);
foreach(['alfa'=>['101','102'],'beta'=>['201']] as $id=>$assets){$r=M\Connections::save(['connection_id'=>'qa-'.$id,'expected_revision'=>0,'label'=>'Conta '.$id,'enabled'=>false,'users'=>[1],'assets'=>['instagram'=>$assets]]);}
