"""Painel real com login; somente respostas da validação de conta são controladas para testar a ordem."""
import json,os,sys,time
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
URL=os.environ.get('F3_QA_URL','http://127.0.0.1:34891')
assert urlparse(URL).hostname in ('127.0.0.1','localhost')
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.environ.get('F3_QA_CHROME'),args=['--no-zygote','--no-sandbox'])
 p=browser.new_page(viewport={'width':1440,'height':900});p.set_default_timeout(6000)
 errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.route('**/*',lambda r:r.continue_() if r.request.url.startswith(URL+'/') else r.abort())
 p.goto(URL+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 p.goto(URL+'/wp-admin/tools.php?page=wp-mcp-meta-fator3');p.wait_for_selector('.f3-edit-connection');results=[]
 def ck(name,val):results.append({'name':name,'passed':bool(val)})
 def tab(g):p.locator('[data-group="'+g+'"]').click()
 L=p.locator
 def editor():L('.f3-edit-connection').first.click();L('#f3-connection-back').wait_for()
 editor();L('#f3-rotate-details summary').click();L('#f3-rotate [name=token]').fill('synthetic-unsaved')
 p.evaluate("()=>{window.prompts=0;window.confirm=()=>{window.prompts++;return false}}")
 L('#f3-connection-back').click();ck('Rotate-only draft offers discard and Cancel keeps editor',p.evaluate('window.prompts')==1 and L('#f3-connection-editor').is_visible() and L('#f3-rotate [name=token]').input_value()=='synthetic-unsaved')
 if not L('#f3-connection-editor').is_visible():editor()
 p.evaluate("window.confirm=()=>true")
 L('#f3-connection [name=token]').fill('synthetic-token');L('#f3-connection [name=client_secret]').fill('synthetic-secret')
 L('#f3-rotate-details').evaluate('(d)=>d.open=true');L('#f3-rotate [name=token]').fill('synthetic-rotation')
 L('#f3-connection-back').click()
 ck('Discard wipes all three password controls',all(L(i).input_value()=='' for i in ['#f3-connection [name=token]','#f3-connection [name=client_secret]','#f3-rotate [name=token]']))
 L('[data-goto=connections]').click();ck('First steps opens a visible focused editor',L('#f3-connection-editor').is_visible() and L('#f3-connection [name=label]').evaluate('(e)=>document.activeElement===e'))
 tab('suporte');L('#f3-diagnostic-result h3').wait_for();ck('Local health displayed on real REST',L('#f3-diagnostic-result h3').inner_text()=='Saúde local')
 p.evaluate("""()=>{const native=window.fetch;window.releaseQA=null;window.fetch=(url,init)=>String(url).includes('validate-connection')?new Promise(resolve=>{window.releaseQA=(fail=false)=>resolve(new Response(JSON.stringify(fail?{success:false,code:'qa',message:'ERRO-ALFA'}:{success:true,data:{label:'VALIDACAO-ALFA'} }),{status:200,headers:{'Content-Type':'application/json'}}))}):native(url,init)}""")
 sel=L('#f3-context [name=account_id]');sel.select_option('101')
 def start():p.evaluate('window.releaseQA=null');L('#f3-validate').click();p.wait_for_function('typeof window.releaseQA==="function"')
 def finish(fail=False):p.evaluate('(fail)=>window.releaseQA(fail)',fail);p.wait_for_function("!document.querySelector('#f3-validate').disabled")
 def shown():return 'VALIDACAO-ALFA' in L('#f3-diagnostic-result').text_content()
 start();sel.select_option('102');sel.select_option('101');finish();ck('Late validation discarded even after selecting A-B-A',not shown())
 start();finish();ck('Current validation rendered',shown());sel.select_option('102');ck('Previous account result removed immediately',not shown())
 start();L('#f3-selftest').click();p.wait_for_function("document.querySelector('#f3-diagnostic-result h3')?.textContent==='Autoteste local'");finish();ck('Latest action wins',L('#f3-diagnostic-result h3').inner_text()=='Autoteste local')
 start();tab('configurar');finish(True);ck('Late validation error does not follow user to another tab','ERRO-ALFA' not in L('#f3-message').text_content())
 p.set_viewport_size({'width':390,'height':844});
 if not L('#f3-connection-editor').is_visible():editor()
 ck('Mobile editor has no horizontal overflow',p.evaluate("document.documentElement.scrollWidth<=window.innerWidth"));ck('No JavaScript error',not errors)
 report={'engine':'Chromium '+browser.version,'version':p.evaluate('window.F3Social.version'),'checks':results,'total':len(results),'failed':sum(not r['passed'] for r in results)}
 Path(sys.argv[1]).write_text(json.dumps(report,indent=2)+'\n');print(report['version'],report['total'],report['failed'],flush=True);browser.close()
 if report['failed'] and os.environ['F3_LAB_FLAVOR']!='baseline':sys.exit(1)
