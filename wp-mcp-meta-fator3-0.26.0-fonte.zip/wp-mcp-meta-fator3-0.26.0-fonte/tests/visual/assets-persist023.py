"""Real login, REST save and new page load; synthetic dataset discovery only."""
import json
import os
from pathlib import Path
import sys
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

url=os.environ['F3_QA_URL']
assert urlparse(url).hostname=='127.0.0.1'
checks=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-sandbox','--no-zygote'])
    page=browser.new_page(viewport={'width':390,'height':844})
    page.set_default_timeout(6000)
    rev=None
    def route(r):
        if not r.request.url.startswith(url+'/'):return r.abort()
        if r.request.method=='POST' and 'admin-options' in r.request.url:
            i=r.request.post_data_json
            if i.get('kind')=='assets' and i.get('channel')=='dataset':
                rows=[{'id':'811','name':'Dataset Alfa'},{'id':'812','name':'Outro dataset'}] if i['ads_account_id']=='101' else [{'id':'822','name':'Dataset Beta'}]
                return r.fulfill(json={'success':True,'data':{'rows':rows,'connection_revision':rev,'next_cursor':None}})
        return r.continue_()
    page.route('**/*',route)
    page.goto(url+'/wp-login.php')
    page.locator('#user_login').fill('qa022admin')
    page.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD'])
    page.locator('#wp-submit').click()
    page.goto(url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab=assets')
    def snapshot():
        page.wait_for_function("typeof window.F3Social==='object'")
        return page.evaluate('Object.fromEntries(F3Social.bootstrap.connections.map(c=>[c.id,c]))')
    before=snapshot()
    rev=before['qa-alfa']['revision']
    page.locator('[data-switch=assets] [data-view=dataset]').click()
    box=page.locator('#f3-assets-channel-dataset')
    box.get_by_role('button',name='Carregar ativos disponíveis').click()
    box.locator('[value="811"]').check()
    box.locator('select').select_option('102')
    box.get_by_role('button',name='Carregar ativos disponíveis').click()
    box.locator('[value="822"]').check()
    page.locator('#f3-save-assets').click()
    page.get_by_text('Seleção de ativos salva.',exact=False).wait_for()
    page.reload()
    after=snapshot()
    for name,ok in [
        ('Persist only checked datasets from both accounts',sorted(after['qa-alfa']['assets']['dataset'])==['700','811','822']),
        ('Save advances expected revision once',after['qa-alfa']['revision']==rev+1),
        ('Preserve other channels',all(after['qa-alfa']['assets'][ch]==before['qa-alfa']['assets'][ch] for ch in ('ads','instagram','facebook'))),
        ('Other connection unchanged',before['qa-beta']==after['qa-beta']),
    ]:checks.append({'name':name,'passed':ok})
    version=page.evaluate('F3Social.version')
    browser.close()
failed=sum(not row['passed'] for row in checks)
Path(sys.argv[1]).write_text(json.dumps({'version':version,'browser':browser.version,'total':len(checks),'failed':failed,'checks':checks},indent=2)+'\n')
sys.exit(bool(failed))
