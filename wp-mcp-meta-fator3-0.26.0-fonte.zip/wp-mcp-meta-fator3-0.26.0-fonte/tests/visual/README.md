# Suíte de layout em navegador real

`layout.cjs` abre o painel num WordPress real com Chrome (puppeteer-core), percorre as dez abas e as subvisões
(Conexão → editor, Coletas → Agendas, Conversas → Configuração da recepção) em 1440, 1024, 782 e 390 px e mede:
rolagem horizontal, distância entre botões vizinhos (≥ 8 px), nome acessível de todo controle visível, alinhamento do
título da seção com "Seleção da consulta", largura de campo ≤ 720 px (1440), alvos de toque ≥ 40 px (390), contraste
≥ 4,5:1 calculado das cores computadas, rótulo separado do campo (≥ 8 px), recuo igual dos blocos da conexão, Ajuda sem
área vazia, aba ativa na cor do esquema do admin, orçamento de altura de `.f3-social` (≤ 1080 px em 1440×900,
≤ 2110 px em 390×844), Enter na busca de usuários sem `save-connection`, aviso visível depois de salvar com a página
rolada e aviso que some ao trocar de aba. Sai com JSON (`total`, `failed`, `by_check`, `heights`, `checks`) e código ≠ 0
em falha.

## Montar o site

1. WordPress ≥ 7.1.4 com PHP ≥ 8.3, o plugin instalado e ativo, um administrador.
2. Copie `graph-simulator.php` para `wp-content/mu-plugins/` (simula a Graph API com dados sintéticos; nenhum acesso à Meta).
3. Crie duas conexões sintéticas como administrador, uma ativa com ativos (token `LABTOKENALFA`, App ID
   `123456789012345`) e outra pausada (`LABTOKENBETA`), ex.: pela operação `meta/save-connection`.
4. `npm ci` (ou `npm install`) nesta pasta; Chrome/Chromium local.

## Executar

```sh
node layout.cjs --base http://127.0.0.1:8102 --user qaadmin --pass '…' \
  --chrome /usr/bin/google-chrome --shots ./capturas --prefix candidato --out ./resultado.json
```

Variáveis equivalentes: `F3_BASE_URL`, `F3_USER`, `F3_PASS`, `F3_CHROME`, `F3_SHOTS`, `F3_PREFIX`, `F3_OUT`, `F3_WIDTHS`,
`F3_PUPPETEER` (caminho do módulo puppeteer-core). Rode um site por vez: o servidor embutido do PHP atende uma requisição
por vez e duas execuções simultâneas estouram o tempo de navegação.

Efeitos: a suíte intercepta `save-connection` e responde localmente; nada é gravado por ela. A abertura das abas executa
leituras (`health`, listas), que o plugin registra na auditoria. Diálogos `beforeunload` são aceitos e registrados no log.

Limites: não substitui leitor de tela nem dispositivo físico; o contraste ignora texto sobre imagem e controles
desabilitados. Resultados da rodada em `results/`.

## Fluxos reais contra o servidor

`realflow.cjs` não intercepta nada: salva de verdade o nome da primeira conexão, lê um documento pela Ajuda com o índice do servidor, abre o Diagnóstico, força uma sessão expirada e percorre as dez abas conferindo erros de script e respostas HTTP de erro. Use só em laboratório.

```sh
F3_USER=qaadmin F3_PASS='…' node realflow.cjs http://127.0.0.1:8102
```
