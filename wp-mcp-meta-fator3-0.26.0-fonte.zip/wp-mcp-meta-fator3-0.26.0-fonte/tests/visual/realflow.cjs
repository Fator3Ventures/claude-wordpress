// Fluxos reais (sem interceptação) no painel, contra o servidor: salvar conexão, Ajuda com o índice real,
// diagnóstico, sessão expirada e as dez abas sem erro. GRAVA de verdade o nome da primeira conexão: use só em laboratório.
// uso: node realflow.cjs <url_base>   (F3_PUPPETEER, F3_CHROME, F3_USER, F3_PASS opcionais)
const puppeteer=require(process.env.F3_PUPPETEER||'puppeteer-core');
(async()=>{const base=process.argv[2];const b=await puppeteer.launch({executablePath:process.env.F3_CHROME||'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--disable-gpu']});const p=await b.newPage();await p.setViewport({width:1440,height:900});
const errors=[];p.on('pageerror',e=>errors.push(String(e).slice(0,200)));const bad=[];p.on('response',r=>{if(r.status()>=400&&!r.url().endsWith('/favicon.ico'))bad.push(r.status()+' '+r.url().replace(base,'').slice(0,120));});
const posts=[];p.on('request',r=>{if(r.method()==='POST'&&r.url().includes('/f3-meta/v1/'))posts.push(r.url().split('/f3-meta/v1/')[1]);});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));const out={checks:[]};const ck=(name,ok,detail='')=>out.checks.push({name,passed:!!ok,detail:String(detail).slice(0,200)});
await p.goto(base+'/wp-login.php',{waitUntil:'networkidle2'});await p.type('#user_login',process.env.F3_USER||'qaadmin');await p.type('#user_pass',process.env.F3_PASS||'');await Promise.all([p.waitForNavigation({waitUntil:'networkidle2'}),p.click('#wp-submit')]);
const U=base+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab=';
// 1. Editar e salvar de verdade
await p.goto(U+'connections',{waitUntil:'networkidle2'});await sleep(500);
await p.evaluate(()=>[...document.querySelectorAll('#f3-connection-list button')].find(x=>x.textContent==='Editar conexão').click());await sleep(900);
const label='Korvena · Alfa '+Date.now();await p.$eval('#f3-connection-label',(e,v)=>{e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));},label);
posts.length=0;await p.evaluate(()=>document.querySelector('#f3-connection .button-primary').click());await sleep(2500);
const st=await p.evaluate(()=>({msg:document.querySelector('#f3-message').textContent.trim(),role:document.querySelector('#f3-message').getAttribute('role'),list:document.querySelector('#f3-connection-list').textContent,editorHidden:!document.querySelector('#f3-connection').checkVisibility()}));
ck('salvar de verdade envia save-connection uma vez',posts.filter(x=>x==='save-connection').length===1,posts.join(','));
ck('depois de salvar a lista mostra o nome novo e o editor some',st.list.includes(label)&&st.editorHidden,st.msg);
ck('aviso de sucesso com role=status',st.role==='status'&&/Conexão salva/.test(st.msg),st.role+' | '+st.msg);
// 2. Ajuda com o índice real
await p.goto(U+'help',{waitUntil:'networkidle2'});await sleep(800);
const idx=await p.evaluate(()=>({groups:document.querySelectorAll('#f3-help-index details').length,links:document.querySelectorAll('#f3-help-index .f3-doc-link').length,options:document.querySelector('#f3-help-document').options.length,first:document.querySelector('#f3-help-document').selectedOptions[0]?.textContent}));
ck('índice real: grupos por tema e um item por documento',idx.groups>=8&&idx.links===idx.options&&idx.options>=30,JSON.stringify(idx));
await p.select('#f3-help-document','USAGE.md');await p.click('#f3-help-read');await sleep(2500);
const doc=await p.evaluate(()=>{const c=document.querySelector('#f3-help-content');return {h:c.querySelectorAll('h1,h2,h3,h4,h5,h6').length,tags:[...new Set([...c.querySelectorAll('h1,h2,h3,h4,h5,h6')].map(x=>x.tagName))].join(','),tables:c.querySelectorAll('table').length,code:c.querySelectorAll('code').length,scripts:c.querySelectorAll('script,img,iframe').length,state:document.querySelector('#f3-help-state').textContent,raw:/\*\*|^#{1,4} /m.test(c.textContent)};});
ck('USAGE.md lido do servidor e formatado, com estado de leitura completa',doc.h>3&&doc.code>3&&doc.scripts===0&&/leitura completa/.test(doc.state),JSON.stringify(doc));
// 3. Diagnóstico real
await p.goto(U+'diagnostics',{waitUntil:'networkidle2'});await sleep(1200);
const dg=await p.evaluate(()=>{const r=document.querySelector('#f3-diagnostic-result');for(const d of r.querySelectorAll('details'))d.open=true;const t=r.innerText;return {generic:(t.match(/Detalhe técnico/g)||[]).length,epoch:(t.match(/\b1[0-9]{9}\b/g)||[]).length,cards:r.querySelectorAll('.f3-stat, .f3-summary-card, [class*=card]').length,len:t.length};});
ck('diagnóstico real sem "Detalhe técnico" e sem epoch bruto',dg.generic===0&&dg.epoch===0&&dg.len>200,JSON.stringify(dg));
await p.click('#f3-selftest');await sleep(1500);
const sf=await p.evaluate(()=>{const r=document.querySelector('#f3-diagnostic-result');for(const d of r.querySelectorAll('details'))d.open=true;return (r.innerText.match(/Detalhe técnico/g)||[]).length;});
ck('autoteste real sem "Detalhe técnico"',sf===0,sf);
// 4. Sessão expirada de verdade
await p.evaluate(()=>{window.F3Social.nonce='expirado';});await p.click('#f3-selftest');await sleep(1200);
const ex=await p.$eval('#f3-message',e=>e.textContent.trim());ck('nonce inválido no servidor real mostra a mensagem de sessão expirada',/sessão do painel expirou/i.test(ex),ex);
// 5. Todas as abas sem erro de script
errors.length=0;bad.length=0;await p.reload({waitUntil:'networkidle2'});for(const t of 'connections,assets,ads-access,reports,jobs,history,messaging,archive,diagnostics,help'.split(',')){await p.goto(U+t,{waitUntil:'networkidle2'});await sleep(300);}
ck('dez abas sem erro de JavaScript e sem resposta HTTP de erro',errors.length===0&&bad.length===0,errors.concat(bad).join(' | '));
out.total=out.checks.length;out.failed=out.checks.filter(c=>!c.passed).length;console.log(JSON.stringify(out,null,1));await b.close();process.exit(out.failed?1:0);})().catch(e=>{console.error(e);process.exit(2);});
