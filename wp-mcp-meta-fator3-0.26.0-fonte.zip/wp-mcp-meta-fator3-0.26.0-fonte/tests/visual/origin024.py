"""Real local wp-admin, REST, Core registry, persistence and mobile viewport."""
import os,sys,json
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright
url=os.environ['F3_QA_URL'];assert urlparse(url).hostname=='127.0.0.1'
out=Path(sys.argv[1]);checks=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path=os.environ['F3_QA_CHROME'],args=['--no-zygote','--no-sandbox'])
 p=b.new_page(viewport={'width':1440,'height':900});p.set_default_timeout(8000)
 p.route('**/*',lambda r:r.continue_() if r.request.url.startswith(url+'/') else r.abort())
 errors=[];p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto(url+'/wp-login.php');p.locator('#user_login').fill('qa022admin');p.locator('#user_pass').fill(os.environ['F3_QA_PASSWORD']);p.locator('#wp-submit').click()
 p.goto(url+'/wp-admin/tools.php?page=wp-mcp-meta-fator3');p.locator('[data-tab="ads-access"]').click()
 def btn(n):return p.get_by_role('button',name=n,exact=True)
 def ck(n,v):checks.append({'name':n,'passed':bool(v)})
 local=btn('Autorizar leitura desta conta');local.wait_for();ck('Origin controls hidden before history grant',btn('Autorizar consulta por ID').count()==0);local.click()
 btn('Autorizar consulta por ID').wait_for();ck('History alone leaves online lookup off',p.get_by_text('Consulta à Meta por ID de anúncio: desligada.',exact=False).is_visible());btn('Autorizar consulta por ID').click()
 btn('Desativar consulta por ID').wait_for();p.reload();btn('Desativar consulta por ID').wait_for()
 ck('Explicit opt-in survives reload',p.get_by_text('Consulta à Meta por ID de anúncio: autorizada.',exact=False).is_visible())
 p.set_viewport_size({'width':390,'height':844});btn('Desativar consulta por ID').scroll_into_view_if_needed()
 ck('Mobile card fits viewport',p.locator('#f3-ads-consumers').evaluate('(e)=>e.getBoundingClientRect().right<=innerWidth'))
 btn('Desativar consulta por ID').click();btn('Autorizar consulta por ID').wait_for()
 ck('Disable online lookup preserves local grant',btn('Revogar esta concessão').is_visible())
 btn('Revogar esta concessão').click();local.wait_for();ck('Revocation removes the online control',btn('Autorizar consulta por ID').count()==0)
 ck('Browser has no uncaught errors',not errors);b.close()
out.write_text(json.dumps({'total':len(checks),'failed':sum(not c['passed'] for c in checks),'checks':checks},ensure_ascii=False,indent=2)+'\n')
assert all(c['passed'] for c in checks)
