'use strict';
// Suíte de layout do painel Fator3 MCP Meta em navegador real (puppeteer-core + Chrome) contra um WordPress real.
// Uso: node layout.cjs --base http://127.0.0.1:8102 [--user qaadmin] [--pass …] [--chrome /usr/bin/google-chrome]
//                      [--shots dir] [--prefix nome] [--out resultado.json] [--widths 1440,1024,782,390]
// Variáveis equivalentes: F3_BASE_URL, F3_USER, F3_PASS, F3_CHROME, F3_SHOTS, F3_PREFIX, F3_OUT, F3_WIDTHS, F3_PUPPETEER (caminho do módulo).
// Nenhuma gravação chega ao servidor pelas ações da suíte: save-connection é interceptado e respondido localmente
// (a abertura das abas ainda executa leituras, que o plugin audita).
const path = require('node:path'), fs = require('node:fs');
const arg = (k, env, d) => { const i = process.argv.indexOf('--' + k); return i > 0 ? process.argv[i + 1] : (process.env[env] ?? d); };
const BASE = arg('base', 'F3_BASE_URL', 'http://127.0.0.1:8102').replace(/\/$/, '');
const USER = arg('user', 'F3_USER', 'qaadmin'), PASS = arg('pass', 'F3_PASS', '');
const CHROME = arg('chrome', 'F3_CHROME', '/usr/bin/google-chrome');
const SHOTS = arg('shots', 'F3_SHOTS', ''), PREFIX = arg('prefix', 'F3_PREFIX', 'layout'), OUT = arg('out', 'F3_OUT', '');
const WIDTHS = arg('widths', 'F3_WIDTHS', '1440,1024,782,390').split(',').map(Number);
const HEIGHTS = { 1440: 900, 1024: 768, 782: 1024, 390: 844 };
const BUDGET = { 1440: 1080, 390: 2110 };
let puppeteer; try { puppeteer = require(arg('puppeteer', 'F3_PUPPETEER', 'puppeteer-core')); } catch (e) { console.error('puppeteer-core não encontrado: rode npm ci em tests/visual ou informe F3_PUPPETEER'); process.exit(2); }
const PAGE = '/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab=';
const TABS = ['connections', 'assets', 'ads-access', 'reports', 'jobs', 'history', 'messaging', 'archive', 'diagnostics', 'help'];
// Subvisões além da padrão: [aba, nome, ação no navegador]. Ignoradas quando a marcação não as tem (base 0.21.0).
const SUBVIEWS = [
  ['connections', 'editor', `(()=>{const b=[...document.querySelectorAll('#f3-connection-list button')].find(b=>b.textContent==='Editar conexão');if(!document.querySelector('#f3-connection-editor')||!b)return false;b.click();return true;})()`],
  ['jobs', 'schedules', `(()=>{const b=document.querySelector('[data-switch="jobs"] [data-view="schedules"]');if(!b)return false;b.click();return true;})()`],
  ['messaging', 'setup', `(()=>{const b=document.querySelector('[data-switch="messaging"] [data-view="setup"]');if(!b)return false;b.click();return true;})()`],
];
const checks = [], heights = {}, log = [];
const add = (id, width, view, passed, detail = '') => checks.push({ id, width, view, passed: !!passed, detail: String(detail).slice(0, 400) });
const sleep = ms => new Promise(r => setTimeout(r, ms));

// Executado na página: medições estáticas de uma vista.
function measure(width, budget) {
  const root = document.querySelector('.f3-social'), out = [];
  const vis = e => { if (!e || e.closest('[hidden]')) return false; for (let d = e.parentElement && e.parentElement.closest('details:not([open])'); d; d = d.parentElement && d.parentElement.closest('details:not([open])')) { const sm = d.querySelector(':scope > summary'); if (!sm || !sm.contains(e)) return false; } if (typeof e.checkVisibility === 'function' && !e.checkVisibility({ contentVisibilityAuto: true, visibilityProperty: true })) return false; const s = getComputedStyle(e); if (s.visibility === 'hidden' || s.display === 'none') return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const nameOf = e => e.id ? '#' + e.id : e.tagName.toLowerCase() + (e.name ? '[name=' + e.name + ']' : '') + (e.className && typeof e.className === 'string' ? '.' + e.className.trim().split(/\s+/)[0] : '') + (e.textContent ? '«' + e.textContent.trim().slice(0, 30) + '»' : '');
  const push = (id, passed, detail) => out.push({ id, passed, detail });
  // 1. rolagem horizontal
  push('sem-rolagem-horizontal', document.documentElement.scrollWidth <= innerWidth, document.documentElement.scrollWidth + ' > ' + innerWidth);
  // 2. espaçamento entre botões adjacentes na mesma linha
  const btns = [...root.querySelectorAll('button, .button, input[type=submit]')].filter(vis).map(e => ({ e, r: e.getBoundingClientRect() }));
  const close = [];
  for (const a of btns) {
    let best = null;
    for (const b of btns) { if (a === b || a.e.contains(b.e) || b.e.contains(a.e)) continue; const ov = Math.min(a.r.bottom, b.r.bottom) - Math.max(a.r.top, b.r.top); if (ov < 0.5 * Math.min(a.r.height, b.r.height)) continue; if (b.r.left < a.r.left) continue; const gap = b.r.left - a.r.right; if (best === null || gap < best.gap) best = { gap, b }; }
    if (best && best.gap < 8) close.push(nameOf(a.e) + '→' + nameOf(best.b.e) + ' ' + best.gap.toFixed(1) + 'px');
  }
  push('botoes-adjacentes-8px', close.length === 0, close.slice(0, 6).join('; '));
  // 3. nome acessível
  const unnamed = [];
  for (const e of root.querySelectorAll('input:not([type=hidden]), select, textarea, button')) {
    if (!vis(e)) continue;
    let n = (e.getAttribute('aria-labelledby') || '').split(/\s+/).filter(Boolean).map(id => document.getElementById(id)?.textContent || '').join(' ').trim();
    n = n || (e.getAttribute('aria-label') || '').trim() || [...(e.labels || [])].map(l => l.textContent).join(' ').trim() || (e.getAttribute('title') || '').trim();
    if (!n && (e.tagName === 'BUTTON')) n = e.textContent.trim();
    if (!n && e.tagName === 'INPUT' && ['submit', 'button'].includes(e.type)) n = e.value.trim();
    if (!n) unnamed.push(nameOf(e));
  }
  push('controles-com-nome-acessivel', unnamed.length === 0, unnamed.slice(0, 6).join('; '));
  // 4. alinhamento do título da seção e de "Seleção da consulta"
  const ctx = document.querySelector('#f3-context'), sec = [...document.querySelectorAll('section.f3-section')].find(vis);
  if (ctx && vis(ctx) && sec) { const a = ctx.querySelector('h2').getBoundingClientRect().left, b = sec.querySelector('h2').getBoundingClientRect().left; push('titulo-secao-e-selecao-alinhados', Math.abs(a - b) <= 1, 'Seleção x=' + a.toFixed(1) + ' seção x=' + b.toFixed(1)); }
  // 5. largura máxima de campo em 1440
  if (width === 1440) { const wide = [...root.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea')].filter(vis).filter(e => e.getBoundingClientRect().width > 720).map(e => nameOf(e) + ' ' + Math.round(e.getBoundingClientRect().width) + 'px'); push('campos-ate-720px', wide.length === 0, wide.slice(0, 6).join('; ')); }
  // 6. alvos de toque em 390
  if (width === 390) { const small = [...root.querySelectorAll('nav a, button, .button')].filter(vis).filter(e => e.getBoundingClientRect().height < 39.5).map(e => nameOf(e) + ' ' + e.getBoundingClientRect().height.toFixed(1) + 'px'); push('alvos-de-toque-40px', small.length === 0, small.slice(0, 6).join('; ')); }
  // 7. contraste do texto corrente
  const rgba = c => { const m = c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(/[\s,/]+/).filter(Boolean).map(Number); return [p[0], p[1], p[2], p.length > 3 ? p[3] : 1]; };
  const lum = ([r, g, b]) => { const f = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const bgOf = e => { const layers = []; for (let n = e; n; n = n.parentElement) { const c = rgba(getComputedStyle(n).backgroundColor); if (c && c[3] > 0) { layers.push(c); if (c[3] >= 1) break; } } let base = [255, 255, 255]; for (const l of layers.reverse()) base = base.map((v, i) => l[i] * l[3] + v * (1 - l[3])); return base; };
  const low = [];
  for (const e of root.querySelectorAll('*')) {
    if (!vis(e) || ['OPTION', 'SELECT', 'SCRIPT', 'STYLE', 'TEXTAREA', 'INPUT'].includes(e.tagName)) continue;
    if (![...e.childNodes].some(n => n.nodeType === 3 && n.textContent.trim())) continue;
    if (e.closest(':disabled, [aria-disabled=true]')) continue;
    const s = getComputedStyle(e), fg = rgba(s.color); if (!fg) continue;
    const bg = bgOf(e), f = fg.slice(0, 3).map((v, i) => v * fg[3] + bg[i] * (1 - fg[3]));
    const L1 = lum(f), L2 = lum(bg), ratio = (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
    const large = parseFloat(s.fontSize) >= 24 || (parseFloat(s.fontSize) >= 18.66 && Number(s.fontWeight) >= 700);
    if (ratio < (large ? 3 : 4.5)) low.push(nameOf(e) + ' ' + ratio.toFixed(2) + ':1');
  }
  push('contraste-texto-4,5', low.length === 0, low.slice(0, 6).join('; '));
  // 8. rótulo separado do campo na mesma linha
  const glued = [];
  for (const c of root.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea')) {
    if (!vis(c)) continue; const cr = c.getBoundingClientRect();
    for (const l of c.labels || []) {
      const range = document.createRange(), rects = [];
      for (const t of [...l.querySelectorAll('*'), l].flatMap(n => [...n.childNodes]).filter(n => n.nodeType === 3 && n.textContent.trim() && !c.contains(n))) { range.selectNodeContents(t); rects.push(...range.getClientRects()); }
      if (!rects.length) continue;
      const tr = { left: Math.min(...rects.map(r => r.left)), right: Math.max(...rects.map(r => r.right)), top: Math.min(...rects.map(r => r.top)), bottom: Math.max(...rects.map(r => r.bottom)) };
      const ov = Math.min(tr.bottom, cr.bottom) - Math.max(tr.top, cr.top);
      if (ov > 0 && tr.right <= cr.left + 1 && cr.left - tr.right < 8) glued.push(nameOf(c) + ' ' + (cr.left - tr.right).toFixed(1) + 'px');
    }
  }
  push('rotulo-separado-do-campo', glued.length === 0, glued.slice(0, 6).join('; '));
  // 9. blocos do formulário de conexão com o mesmo recuo
  const form = document.querySelector('#f3-connection');
  if (form && vis(form)) { const blocks = [...form.children].filter(e => (e.tagName === 'FIELDSET' || e.classList.contains('f3-form-block')) && vis(e)); const xs = blocks.map(b => (b.querySelector(':scope > legend, :scope > summary') || b).getBoundingClientRect().left); push('blocos-da-conexao-mesmo-recuo', blocks.length >= 4 && Math.max(...xs) - Math.min(...xs) <= 1, blocks.length + ' blocos; x=' + xs.map(x => x.toFixed(1)).join(',')); }
  // 10. Ajuda sem área vazia antes da leitura
  const help = document.querySelector('#f3-help-content');
  if (help && document.querySelector('#f3-help') && vis(document.querySelector('#f3-help'))) push('ajuda-sem-area-vazia', !(vis(help) && !help.textContent.trim()), vis(help) ? Math.round(help.getBoundingClientRect().height) + 'px vazios' : '');
  // 11. aba ativa com a cor de destaque do esquema do admin
  const theme = (getComputedStyle(document.body).getPropertyValue('--wp-admin-theme-color') || getComputedStyle(document.documentElement).getPropertyValue('--wp-admin-theme-color') || '#2271b1').trim();
  const probe = document.createElement('span'); probe.style.color = theme; document.body.append(probe); const themeRgb = getComputedStyle(probe).color; probe.remove();
  const act = document.querySelector('a[data-tab][aria-current=page]');
  if (act) { const s = getComputedStyle(act), parts = [s.borderBottomColor, s.borderTopColor, s.backgroundColor, s.boxShadow]; push('aba-ativa-cor-do-esquema', parts.some(p => p.includes(themeRgb)), 'tema ' + themeRgb + ' · aba ' + parts.join(' | ')); }
  // 12. orçamento de altura
  const h = root.getBoundingClientRect().height;
  if (budget) push('altura-ate-' + budget + 'px', h <= budget, Math.round(h) + 'px');
  return { out, height: Math.round(h) };
}

(async () => {
  const browser = await puppeteer.launch({ protocolTimeout: 120000, executablePath: CHROME, headless: 'new', args: ['--no-sandbox', '--disable-gpu', '--hide-scrollbars', '--font-render-hinting=none'] });
  const page = await browser.newPage();
  page.on('console', m => { if (m.type() === 'error') log.push(m.text().slice(0, 200)); });
  page.on('dialog', async d => { log.push('diálogo ' + d.type() + ' aceito'); await d.accept(); });
  page.on('pageerror', e => log.push('pageerror ' + String(e).slice(0, 200)));
  page.on('response', r => { if (r.status() >= 400) log.push(r.status() + ' ' + r.url().slice(0, 160)); });
  let saves = 0, connectionsSeen = [], pluginVersion = null;
  await page.setRequestInterception(true);
  page.on('request', req => {
    if (req.url().includes('/f3-meta/v1/save-connection')) {
      saves++; let i = {}; try { i = JSON.parse(req.postData() || '{}'); } catch (_) {}
      const c = connectionsSeen.find(x => x.id === i.connection_id) || connectionsSeen[0] || {};
      return req.respond({ status: 200, contentType: 'application/json', body: JSON.stringify({ success: true, code: 'ok', version: pluginVersion, data: { connection: c, schedules_rebased: 0 } }) });
    }
    req.continue();
  });
  await page.setViewport({ width: 1440, height: 900 });
  await page.goto(BASE + '/wp-login.php', { waitUntil: 'networkidle2' });
  await page.type('#user_login', USER); await page.type('#user_pass', PASS);
  await Promise.all([page.waitForNavigation({ waitUntil: 'networkidle2' }), page.click('#wp-submit')]);
  const open = async (tab) => { try { await page.goto(BASE + PAGE + tab, { waitUntil: 'networkidle0', timeout: 45000 }); } catch (e) { log.push('espera de rede esgotada em ' + tab + ': ' + e.message.slice(0, 80)); } await sleep(350); const cfg = await page.evaluate(() => window.F3Social ? { c: F3Social.bootstrap.connections, v: F3Social.version } : null); if (cfg) { connectionsSeen = cfg.c; pluginVersion = cfg.v; } };
  for (const width of WIDTHS) {
    await page.setViewport({ width, height: HEIGHTS[width] || 900, isMobile: width < 600, hasTouch: width < 600 });
    const views = [...TABS.map(t => [t, 'padrao', null]), ...SUBVIEWS];
    for (const [tab, view, action] of views) {
      await open(tab);
      if (action) { const ok = await page.evaluate(action); if (!ok) continue; await sleep(500); }
      const key = tab + (view === 'padrao' ? '' : ':' + view);
      const { out, height } = await page.evaluate(measure, width, BUDGET[width] || 0);
      (heights[key] ||= {})[width] = height;
      for (const c of out) add(c.id, width, key, c.passed, c.detail);
      if (SHOTS) { fs.mkdirSync(SHOTS, { recursive: true }); await page.screenshot({ path: path.join(SHOTS, `${PREFIX}-${width}-${key.replace(':', '-')}.png`), fullPage: true }); }
    }
    // Comportamento: Enter na busca de usuários não gera save-connection.
    await open('connections');
    // Editando uma conexão existente: o formulário está válido, então um Enter não cancelado submete de fato.
    await page.evaluate(() => { const b = [...document.querySelectorAll('#f3-connection-list button')].find(b => b.textContent === 'Editar conexão'); b?.click(); });
    await sleep(900);
    await page.evaluate(() => { const s = document.querySelector('#f3-user-search'); let d = s.closest('details'); while (d) { d.open = true; d = d.parentElement.closest('details'); } s.scrollIntoView({ block: 'center' }); });
    let before = saves; await page.focus('#f3-user-search'); await page.keyboard.type('qa'); await page.keyboard.press('Enter'); await sleep(900);
    add('enter-na-busca-sem-save-connection', width, 'connections', saves === before, (saves - before) + ' requisições save-connection');
    // Comportamento: aviso visível depois de salvar com a página rolada até "Salvar conexão"; some ao trocar de aba.
    await open('connections');
    await page.evaluate(() => { const b = [...document.querySelectorAll('#f3-connection-list button')].find(b => b.textContent === 'Editar conexão'); b?.click(); });
    await sleep(700);
    await page.evaluate(() => document.querySelector('#f3-connection .button-primary').scrollIntoView({ block: 'end' }));
    await sleep(200); before = saves;
    const scrolled = await page.evaluate(() => scrollY);
    await page.evaluate(() => document.querySelector('#f3-connection .button-primary').click());
    await sleep(1500);
    const notice = await page.evaluate(() => { const m = document.querySelector('#f3-message'), r = m.getBoundingClientRect(), s = getComputedStyle(m); return { text: m.textContent.trim(), top: r.top, bottom: r.bottom, h: r.height, shown: !m.hidden && s.display !== 'none' && s.visibility !== 'hidden', vh: innerHeight }; });
    add('aviso-visivel-apos-salvar-rolado', width, 'connections', saves > before && notice.shown && notice.text && notice.h > 0 && notice.top >= 0 && notice.bottom <= notice.vh, `rolagem ${Math.round(scrolled)}px; aviso top=${Math.round(notice.top)} bottom=${Math.round(notice.bottom)} viewport=${notice.vh}; texto="${notice.text.slice(0, 60)}"`);
    if (SHOTS) await page.screenshot({ path: path.join(SHOTS, `${PREFIX}-${width}-aviso-apos-salvar.png`) });
    await page.evaluate(() => { const a = [...document.querySelectorAll('a[data-tab]')].find(a => a.dataset.tab !== 'connections' && a.offsetParent); a.click(); });
    await sleep(900);
    const after = await page.evaluate(() => { const m = document.querySelector('#f3-message'); return { shown: !m.hidden && getComputedStyle(m).display !== 'none' && m.textContent.trim() !== '', text: m.textContent.trim().slice(0, 60) }; });
    add('aviso-some-ao-trocar-de-aba', width, 'connections', !after.shown, after.text);
  }
  await browser.close();
  const failed = checks.filter(c => !c.passed);
  const result = { base_url: BASE, plugin_version: pluginVersion, widths: WIDTHS, total: checks.length, failed: failed.length, heights, by_check: Object.fromEntries([...new Set(checks.map(c => c.id))].map(id => [id, { total: checks.filter(c => c.id === id).length, failed: checks.filter(c => c.id === id && !c.passed).length }])), checks, log: [...new Set(log)].slice(0, 30) };
  if (OUT) fs.writeFileSync(OUT, JSON.stringify(result, null, 2) + '\n');
  console.log(JSON.stringify({ base_url: BASE, plugin_version: pluginVersion, total: result.total, failed: result.failed, by_check: result.by_check }, null, 1));
  process.exitCode = failed.length ? 1 : 0;
})().catch(e => { console.error(e); process.exitCode = 2; });
