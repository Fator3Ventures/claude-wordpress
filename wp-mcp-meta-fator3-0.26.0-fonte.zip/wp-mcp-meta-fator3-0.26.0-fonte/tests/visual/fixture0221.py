"""Exercita as mesmas asserções de cases.js e identity-cases.js com renderer real e REST simulada."""
import json,os,subprocess,sys
from pathlib import Path
from playwright.sync_api import sync_playwright
src=Path(__file__).resolve().parents[2];rt=src/'plugin/wp-mcp-meta-fator3';f=src/'tests/browser';out=src/'evidence/0221'
def render(*args):return subprocess.check_output([os.getenv('F3_SOCIAL_PHP','php'),str(f/'render.php'),str(rt),*args],text=True)
with sync_playwright() as pw:
 browser=pw.chromium.launch(executable_path=os.getenv('F3_QA_CHROME'),args=['--no-sandbox','--no-zygote'])
 page=browser.new_page()
 def load(html):
  page.unroute_all();page.route('**/*',lambda r:r.fulfill(body=html,content_type='text/html; charset=utf-8') if r.request.is_navigation_request() else r.abort());page.goto('https://example.invalid/wp-admin/tools.php?page=wp-mcp-meta-fator3')
 load(render());page.wait_for_function("document.querySelector('#qa-summary').dataset.result!==undefined");checks=json.loads(page.locator('#qa-summary').get_attribute('data-result'));assert checks and all(c['passed'] for c in checks),checks
 fixture=json.loads(render('identity'));load(fixture['html']);identity=page.evaluate('(arg)=>eval(arg.cases)(window,arg.fixture,arg.js)',{'cases':(f/'identity-cases.js').read_text(),'fixture':fixture,'js':(rt/'assets/admin.js').read_text()})
 for name,rows in [('browser-general',checks),('browser-identity',identity['checks'])]:
  (out/(name+'.json')).write_text(json.dumps({'engine':browser.version,'scope':'Chromium, renderer PHP; REST e fornecedor simulados','checks':rows,'total':len(rows),'failed':sum(not c['passed'] for c in rows)},indent=2)+'\n');print(name,len(rows))
 browser.close()
