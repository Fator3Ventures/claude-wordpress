#!/usr/bin/env bash
# Cria (ou recria) um WordPress local com o plugin informado, o simulador da Graph API e duas conexões sintéticas.
# uso: ui-site.sh <nome> <porta> <dir_plugin_construido>
set -euo pipefail
NAME="$1"; PORT="$2"; PLUGIN="$3"
S=/home/claude/work/scripts; LAB=/home/claude/work/lab
"$S/lab-up.sh" >/dev/null
"$S/provision.sh" "$NAME" "wp_$NAME" "$PORT" 2>/dev/null | tail -1
SITE="$LAB/sites/$NAME"
mkdir -p "$SITE/wp-content/mu-plugins"; cp "$S/lab-graph.php" "$SITE/wp-content/mu-plugins/lab-graph.php"
rm -rf "$SITE/wp-content/plugins/wp-mcp-meta-fator3"; cp -r "$PLUGIN" "$SITE/wp-content/plugins/wp-mcp-meta-fator3"
php "$S/wp-run.php" "$SITE" qaadmin "$S/activate.php"
php "$S/wp-run.php" "$SITE" qaadmin "$S/probe.php" '[["save-connection",{"connection_id":"conexao-alfa","expected_revision":0,"label":"Korvena · Usuário do sistema Alfa","client_id":"123456789012345","client_secret":"0123456789abcdef0123456789abcdef","token":"LABTOKENALFA","enabled":true,"users":[1],"retention_mode":"unlimited"}],["save-connection",{"connection_id":"conexao-alfa","expected_revision":1,"assets":{"instagram":["17841400000000001"],"facebook":["700000000000001"],"ads":["900000000000001"],"dataset":[]}}],["save-connection",{"connection_id":"conexao-beta","expected_revision":0,"label":"CTO Office · Usuário do sistema Beta","client_id":"123456789012345","client_secret":"0123456789abcdef0123456789abcdef","token":"LABTOKENBETA","enabled":false,"users":[1],"retention_mode":"finite","retention_days":180}]]' | cut -c1-120
"$S/lab-up.sh" "$NAME" "$PORT"
