#!/usr/bin/env bash
# Laboratório WordPress isolado local para as suítes tests/native (mesmo formato do laboratório do Site-Teste).
# uso: native-lab.sh setup <flavor> <tag> <candidate_dir> <baseline_dir> <tests_native_dir>
#      native-lab.sh run <script.php>
#      native-lab.sh upgrade            (troca os arquivos pelo candidato e roda migrate.php)
#      native-lab.sh cleanup
# <tag> = prefixo de guarda da suíte (ex.: f3qaui021 ou f3qa022).
set -euo pipefail
LAB=/home/claude/work/lab
SOCK="$LAB/run/mysql.sock"
STATE="$LAB/run/native-${LAB_NAME:-main}.env"
DB="wp_native_${LAB_NAME:-main}"
cmd="$1"; shift
if [ "$cmd" = setup ]; then
  FLAVOR="$1"; TAG="$2"; CAND="$3"; BASE="$4"; TESTS="$5"
  [ -f "$STATE" ] && { echo "laboratório já existe; rode cleanup" >&2; exit 2; }
  PREFIX="${TAG}_$(php -r 'echo bin2hex(random_bytes(6));')_"
  ROOT="/tmp/$PREFIX"
  mkdir -m 700 "$ROOT" "$ROOT/evidence" "$ROOT/wordpress"
  mariadb --socket="$SOCK" -uroot -e "CREATE DATABASE IF NOT EXISTS \`$DB\` CHARACTER SET utf8mb4; GRANT ALL ON \`$DB\`.* TO 'wp'@'127.0.0.1'; GRANT ALL ON \`$DB\`.* TO 'wp'@'localhost'; FLUSH PRIVILEGES;"
  for d in wp-admin wp-includes; do ln -s "$LAB/wp-src/wordpress/$d" "$ROOT/wordpress/$d"; done
  for p in "$LAB"/wp-src/wordpress/*.php; do [ "$(basename "$p")" = wp-config.php ] || cp "$p" "$ROOT/wordpress/"; done
  mkdir -p "$ROOT/wordpress/wp-content/plugins" "$ROOT/wordpress/wp-content/mu-plugins"
  printf '%s' '<?php add_filter("pre_http_request",static fn($pre)=>$pre!==false?$pre:new WP_Error("lab_external_blocked"),PHP_INT_MAX);add_filter("pre_wp_mail",static fn()=>true,PHP_INT_MAX);' > "$ROOT/wordpress/wp-content/mu-plugins/no-external.php"
  SALT() { php -r 'echo bin2hex(random_bytes(48));'; }
  {
    echo "<?php define('DB_NAME','$DB');define('DB_USER','wp');define('DB_PASSWORD','${F3_LAB_DB_PASS}');define('DB_HOST','127.0.0.1:33306');define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');"
    for k in AUTH_KEY SECURE_AUTH_KEY LOGGED_IN_KEY NONCE_KEY AUTH_SALT SECURE_AUTH_SALT LOGGED_IN_SALT NONCE_SALT; do echo "define('$k','$(SALT)');"; done
    echo "\$table_prefix='$PREFIX';define('DISABLE_WP_CRON',true);define('WP_HOME','https://example.invalid');define('WP_SITEURL','https://example.invalid');define('WP_DEBUG',true);define('WP_DEBUG_DISPLAY',false);define('WP_DEBUG_LOG',true);define('WP_HTTP_BLOCK_EXTERNAL',true);if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require ABSPATH.'wp-settings.php';"
  } > "$ROOT/wordpress/wp-config.php"
  mkdir -p "$ROOT/candidate" "$ROOT/baseline" "$ROOT/tests"
  cp -r "$CAND" "$ROOT/candidate/wp-mcp-meta-fator3"
  [ -d "$BASE" ] && cp -r "$BASE" "$ROOT/baseline/wp-mcp-meta-fator3"
  cp -r "$TESTS" "$ROOT/tests/native"
  if [ "$FLAVOR" = current ]; then cp -r "$ROOT/candidate/wp-mcp-meta-fator3" "$ROOT/wordpress/wp-content/plugins/"; else cp -r "$ROOT/baseline/wp-mcp-meta-fator3" "$ROOT/wordpress/wp-content/plugins/"; fi
  printf 'ROOT=%s\nPREFIX=%s\nFLAVOR=%s\n' "$ROOT" "$PREFIX" "$FLAVOR" > "$STATE"
  cmd=run; set -- install.php
fi
[ -f "$STATE" ] || { echo "sem laboratório" >&2; exit 2; }
. "$STATE"
exec_php() {
  (cd "$ROOT" && env -i PATH=/usr/bin:/bin F3_LAB_ROOT="$ROOT" F3_LAB_FLAVOR="$FLAVOR" php -d allow_url_fopen=0 -d display_errors=stderr -d memory_limit=256M "$ROOT/tests/native/$1")
}
case "$cmd" in
  run) exec_php "$1" ;;
  upgrade)
    [ "$FLAVOR" = upgrade ] || { echo "não é laboratório de upgrade" >&2; exit 2; }
    rm -rf "$ROOT/wordpress/wp-content/plugins/wp-mcp-meta-fator3"
    cp -r "$ROOT/candidate/wp-mcp-meta-fator3" "$ROOT/wordpress/wp-content/plugins/"
    exec_php migrate.php ;;
  cleanup)
    TABLES=$(mariadb --socket="$SOCK" -uroot -N -e "SELECT table_name FROM information_schema.tables WHERE table_schema='$DB' AND table_name LIKE '${PREFIX//_/\\_}%'")
    n=0; for t in $TABLES; do mariadb --socket="$SOCK" -uroot -e "DROP TABLE \`$DB\`.\`$t\`"; n=$((n+1)); done
    REM=$(mariadb --socket="$SOCK" -uroot -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='$DB' AND table_name LIKE '${PREFIX//_/\\_}%'")
    rm -rf "$ROOT"; rm -f "$STATE"
    echo "{\"tables_dropped\":$n,\"remaining_tables\":$REM,\"directory_removed\":$([ -e "$ROOT" ] && echo false || echo true)}" ;;
  *) echo "comando inválido" >&2; exit 2 ;;
esac
