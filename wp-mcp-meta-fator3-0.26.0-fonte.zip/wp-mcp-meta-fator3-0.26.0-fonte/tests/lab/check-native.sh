#!/usr/bin/env bash
# Constrói a árvore e roda UMA checagem; sai com o código da checagem. Sempre limpa o laboratório.
# uso: check-native.sh <dir_fonte> <checagem>
#   build | release022 | smoke | configuration | migrate | effects | docs-check | lint-cases | build-cases
set -uo pipefail
SRC="$1"; WHAT="$2"; cd "$SRC"
S=/home/claude/work/scripts/native-lab.sh; BASE=/home/claude/work/instalador/wp-mcp-meta-fator3; export LAB_NAME=mut
/home/claude/work/scripts/lab-up.sh >/dev/null
python3 build/build.py >/tmp/mut-build.log 2>&1 || { echo "build reprovou: $(tail -1 /tmp/mut-build.log | cut -c1-240)"; exit 3; }
[ "$WHAT" = build ] && exit 0
case "$WHAT" in
  lint-cases) python3 tests/docs/lint-cases.py >/tmp/mut-out.log 2>&1; rc=$?; tail -1 /tmp/mut-out.log | cut -c1-200; exit $rc;;
  build-cases) python3 tests/docs/build-cases.py >/tmp/mut-out.log 2>&1; rc=$?; exit $rc;;
  docs-check) python3 tests/docs/check.py /usr/bin/php build/dist/wp-mcp-meta-fator3 >/tmp/mut-out.log 2>&1; rc=$?; python3 -c "
import json;d=json.load(open('/tmp/mut-out.log'));print('falhas:',[c['name'] for c in d['checks'] if not c['passed']][:4])" 2>/dev/null; exit $rc;;
esac
$S cleanup >/dev/null 2>&1 || true
report(){ python3 -c "
import json,sys
try:
    d=json.loads(open('/tmp/mut-out.log').read().strip().split('\n')[-1]);print('falhas:',[c['name'][:70] for c in d.get('checks',[]) if not c['passed']][:5])
except Exception as e: print('saída não-JSON:',open('/tmp/mut-out.log').read()[-200:])"; }
if [ "$WHAT" = migrate ]; then
  $S setup upgrade f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" >/dev/null 2>&1; $S upgrade >/tmp/mut-out.log 2>&1; rc=$?
elif [ "$WHAT" = effects ]; then
  $S setup baseline f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" >/dev/null 2>&1; $S run effects-map.php >/tmp/mut-eff-base.json 2>/dev/null; $S cleanup >/dev/null
  $S setup current f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" >/dev/null 2>&1; $S run effects-map.php >/tmp/mut-eff-cand.json 2>/dev/null
  python3 tests/native/effects-compare.py /tmp/mut-eff-base.json /tmp/mut-eff-cand.json >/tmp/mut-out.log 2>&1; rc=$?; $S cleanup >/dev/null 2>&1; python3 -c "
import json;d=json.load(open('/tmp/mut-out.log'));print('diferenças:',[x['operation'] for x in d['differences']][:5])" 2>/dev/null; exit $rc
else
  $S setup current f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" >/tmp/mut-setup.log 2>&1; $S run "$WHAT.php" >/tmp/mut-out.log 2>&1; rc=$?
fi
report; $S cleanup >/dev/null 2>&1; exit $rc
