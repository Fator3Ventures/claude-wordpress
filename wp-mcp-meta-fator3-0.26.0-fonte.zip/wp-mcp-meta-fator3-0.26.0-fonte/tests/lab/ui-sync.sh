#!/usr/bin/env bash
# Reconstrói o plugin de uma árvore fonte e troca os arquivos no site local (sem reativar).
# uso: ui-sync.sh <dir_fonte> <nome_site> <porta>
set -euo pipefail
SRC="$1"; NAME="$2"; PORT="$3"
S=/home/claude/work/scripts; LAB=/home/claude/work/lab
(cd "$SRC" && F3_DOCS_LINT="${F3_DOCS_LINT:-warn}" python3 build/build.py | tail -1 | cut -c1-200)
SITE="$LAB/sites/$NAME"
rm -rf "$SITE/wp-content/plugins/wp-mcp-meta-fator3"; cp -r "$SRC/build/dist/wp-mcp-meta-fator3" "$SITE/wp-content/plugins/wp-mcp-meta-fator3"
"$S/lab-up.sh" "$NAME" "$PORT"
