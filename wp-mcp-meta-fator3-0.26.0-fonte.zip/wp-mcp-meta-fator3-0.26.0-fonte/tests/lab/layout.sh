#!/usr/bin/env bash
# Roda a suíte de layout contra um site local. uso: layout.sh <dir_fonte> <site> <porta> <prefixo> <out.json> [dir_capturas]
set -uo pipefail
SRC="$1"; NAME="$2"; PORT="$3"; PFX="$4"; OUT="$5"; SHOTS="${6:-/home/claude/work/shots/$NAME}"
mkdir -p "$SHOTS"; /home/claude/work/scripts/lab-up.sh "$NAME" "$PORT" >/dev/null
F3_PUPPETEER=/home/claude/work/pptr/node_modules/puppeteer-core NODE_PATH=/home/claude/work/pptr/node_modules node "$SRC/tests/visual/layout.cjs" --base "http://127.0.0.1:$PORT" --user qaadmin --pass "${F3_LAB_PASS}" --chrome /usr/bin/google-chrome --shots "$SHOTS" --prefix "$PFX" --out "$OUT" > /tmp/layout-$NAME.log 2>&1; rc=$?
python3 -c "
import json,sys
d=json.load(open(sys.argv[1]));print(sys.argv[2]+': total',d['total'],'failed',d['failed'],sorted({(c['id'],c['view']) for c in d['checks'] if not c['passed']})[:8])" "$OUT" "$PFX" 2>/dev/null || tail -3 /tmp/layout-$NAME.log
exit $rc
