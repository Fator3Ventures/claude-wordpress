#!/usr/bin/env python3
"""Verificação por mutação na árvore real.
uso: mutate.py <id> <arquivo> <regex_python> <substituto> <log_json> -- <comando de checagem...>
Planta o defeito, roda a checagem, exige que ela ACUSE (saída != 0), restaura o arquivo e confere o hash.
Sai 0 quando a mutação foi detectada; 1 quando sobreviveu; 2 quando não foi possível aplicar/restaurar."""
import sys,re,hashlib,subprocess,json,shutil,os,time
i=sys.argv.index('--');mid,path,pattern,repl,log=sys.argv[1:i];cmd=sys.argv[i+1:]
repl=repl.replace('\\n','\n')
orig=open(path,'rb').read();h=hashlib.sha256(orig).hexdigest()
text=orig.decode('utf-8');new,n=re.subn(pattern,lambda m:m.expand(repl) if '\\g<' in repl or re.search(r'\\\d',repl) else repl,text,count=1,flags=re.S)
if n!=1 or new==text:
    print(json.dumps({'id':mid,'status':'nao_aplicada','file':path}));sys.exit(2)
bak=path+'.mutbak';shutil.copy2(path,bak)
try:
    open(path,'w',encoding='utf-8').write(new)
    t=time.time();r=subprocess.run(cmd,capture_output=True,text=True)
    out=(r.stdout+r.stderr)[-600:]
finally:
    shutil.copy2(bak,path);os.remove(bak)
ok=hashlib.sha256(open(path,'rb').read()).hexdigest()==h
res={'id':mid,'file':os.path.relpath(path),'detectada':r.returncode!=0,'exit_checagem':r.returncode,'restaurado':ok,'segundos':round(time.time()-t,1),'cauda':out.strip().split('\n')[-1][:300]}
rows=json.load(open(log)) if os.path.exists(log) else []
rows=[x for x in rows if x['id']!=mid]+[res];json.dump(rows,open(log,'w'),ensure_ascii=False,indent=1)
print(json.dumps(res,ensure_ascii=False))
sys.exit(2 if not ok else (0 if res['detectada'] else 1))
