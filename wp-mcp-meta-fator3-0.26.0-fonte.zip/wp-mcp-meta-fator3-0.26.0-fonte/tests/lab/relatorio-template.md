# Entrega — Fator3 MCP Meta 0.22.0

Revisão 1 · [[NOW]] · Rodada de implementação · Slug `wp-mcp-meta-fator3` · Status: **com-pendencias**.

O instalador está apto no escopo testado em WordPress 7.1.4 local (instalação limpa, migração da 0.21.0 e painel em Chrome real). **A instalação no Site-Teste e a leitura da documentação pelo MCP não foram feitas nesta rodada** (seção 6, itens 1 e 2). A homologação do Pedido MCP Meta 27 com credenciais dos sites de produção continua pendente e não foi reaberta.

[[COPY_NOTE]]

## 1. De onde esta versão entra

Base direta **0.21.0**, conferida pelos bytes recebidos: instalador de 243040 bytes, SHA-256 `9589456a2ee5ed13cb72941437e4350c0815907f6ba20b8eb47837a77064334a`; fonte de 672186 bytes, SHA-256 `d53c738b10c59084f5c1e581cfcd408caffb45f004c04683e47f56fcbf3e9b49`. O runtime dentro do fonte da base é idêntico ao do instalador da base, e o `build.py` da base reproduz a mesma árvore. Entra por WordPress limpo ou por troca direta da 0.21.0. Depois da troca só a 0.22.0 fica em operação. Sem downgrade.

Pedido do dono, sem ID de frota: analisar e testar o plugin, implementar melhorias, correções e ajustes, melhorar a documentação e o layout da tela de configuração. Em 10/11/2026 o dono fixou o critério do layout: abas existem para evitar telas longas e separar responsabilidades.

Requisitos declarados no cabeçalho, no readme e no build: **WordPress ≥ 7.1.4 e PHP ≥ 8.3 de 64 bits**. Runtimes efetivamente usados nas provas: WordPress [[WP_V]] (pacote oficial, SHA-1 conferido), PHP [[PHP_V]], MariaDB [[DB_V]], [[CHROME]], Node [[NODE_V]]. Não exercitados: o patch exato PHP 8.3.0 e o MySQL 8.4 do Site-Teste. Normativos aplicados: `instrucoes-agentes-plugins-fator3.md` e `padrao-desenvolvimento-plugins-fator3.md`, ambos revisão 5 (02/11/2026), lidos integralmente nas fontes do projeto. Plano e análise de fronteiras em `planning/`.

## 2. Convivência e encaminhamentos

Conjunto vigente lido do Site-Teste em 10/11/2026: Core 1.78.0, MCP 0.43.0, Google 0.31.0, LinkedIn 0.19.0, Pipedrive 0.8.0, Meta 0.21.0. O conjunto avançou desde o relatório da 0.21.0 (Core 1.71.0, MCP 0.40.0, Google 0.28.0, LinkedIn 0.18.0, Pipedrive 0.7.0).

**Nenhum impacto técnico relevante identificado; nenhum relatório individual de impacto emitido.** Escopo avaliado: busca no código instalado dos cinco acompanhantes por consumo das interfaces tocadas. O Core 1.78.0 usa os três hooks de registro de consumidores e as leituras `meta/health` e `meta/list-connections`; nenhuma dessas saídas muda. Os efeitos declarados das operações são idênticos aos da base: [[EFF_BASE]] operações na base, [[EFF_CAND]] na candidata, [[EFF_DIFF]] diferenças. Mudanças de saída são aditivas; a troca de código na leitura paginada sem `expected_revision` atinge uma chamada que já era recusada. Detalhe e limites do exame em `planning/fronteiras.md`. Não se exige ordem especial de troca.

**Não avaliado:** a convivência em execução com a 0.22.0 instalada junto dos acompanhantes. Depende da instalação no Site-Teste.

## 3. Mudanças e evidência

Cada defeito foi medido na 0.21.0 antes de qualquer alteração. Estados: *validado-wordpress* = WordPress 7.1.4 real local; *validado-localmente* = fora do WordPress ou em jsdom.

| Item | Problema medido na 0.21.0 | Mudança na 0.22.0 | Evidência e estado |
|---|---|---|---|
| A1 | Recusa de schema devolvia `invalid_input` sem dizer qual parâmetro falhou. | `details` ganha `field` (notação de ponto) e `problem`; a mensagem nomeia o parâmetro. O valor enviado nunca aparece na resposta. | `release022`: [[A1_CASES]] casos de `field`/`problem` e prova de que um valor-sentinela não vaza. validado-wordpress |
| A2 | `documentation` com `offset>0` sem `expected_revision` respondia “Documento alterado”. | Passa a `invalid_input` com `field=expected_revision`. Revisão divergente continua `revision_conflict`. | `release022`, `docs-integrity`. validado-wordpress |
| A3 | Enter em “Buscar usuário por nome” enviava `save-connection`; digitar ali marcava alterações. | Enter só busca; digitar não marca alterações. | `ui-panel` e, em Chrome real, `layout`. Na base: [[B_ENTER]] falham. validado-wordpress |
| A4 | A mensagem de resultado ficava fora da área visível e persistia ao trocar de aba. | Aviso fixo abaixo da barra do admin, com variantes de sucesso e erro e botão de dispensar; some ao trocar de aba. | `ui-panel`, `layout`. Na base: [[B_AVISO]] e [[B_AVISO_ABA]] falham. validado-wordpress |
| A5 | Sessão expirada mostrava “Cookie check failed”. | Mensagem própria, dizendo que nada foi gravado. | `ui-panel`, `realflow` (nonce inválido no servidor). validado-wordpress |
| A6 | Diagnóstico com campos sob o rótulo genérico “Detalhe técnico” e horários em epoch. | Rótulo próprio para toda chave de `health`, `status` e `selftest`; data e hora em UTC; resumo em cartões. | `ui-panel` com a saída real das três operações; `realflow`. validado-wordpress |
| A7 | Instalação limpa informava migração do histórico incompleta até a primeira manutenção. | A ativação conclui a marca quando não há páginas a migrar. Com páginas pendentes, nada muda. | `release022` (limpa, inclusive ativação sem usuário) e `migrate` (marca e progresso preservados). validado-wordpress |
| A8 | `meta/status` grava, mas o rótulo dizia “consultar”. | Rótulo “Meta: verificar estado e recuperar agendamento”. ID, schema e descrição iguais. | `release022`. validado-wordpress |
| B | Telas longas e responsabilidades misturadas (tabela abaixo); botões e rótulos colados; cartão de seleção desalinhado; campo com [[WIDE_PX]] px de largura; cor da aba fora do esquema do admin. | Navegação em dois níveis (Configurar · Dados · Suporte) com os dez endereços mantidos; Conexão em lista ou editor; blocos recolhíveis; versão da API levada do Diagnóstico para a Conexão; Ativos um canal por vez; subvisões em Coletas e Conversas; orçamento de altura por tela. | `layout`: [[CAND_LAYOUT_T]] medições em 4 larguras, 0 falhas. Na base: [[BASE_LAYOUT_F]] de [[BASE_LAYOUT_T]] falham. validado-wordpress |
| C | [[OLD_MD]] manuais, [[OLD_STALE]] com versão antiga no título, [[OLD_DUP]] parágrafos repetidos entre documentos, [[OLD_UNMENTIONED]] operações sem menção, guias organizados por release, índice sem título nem resumo. | [[NEW_MD]] documentos Markdown pelo estado atual, dois deles gerados; índice com `title`, `summary`, `topic` e `topics`; REFERENCE.md gerado do registro ([[OPS]] operações); EXAMPLES.md gerado de execução real; lint R1–R8 no build. | Build com lint ativo; `docs-lint-cases`, `docs-build-cases`, `smoke` (leitura integral paginada dos [[NEW_ALL]] documentos). validado-wordpress |

Não mudam: schemas de entrada, envelope, SDKs locais, hooks, options, tabela e cron.

**Altura de cada tela** (painel inteiro, estado inicial, duas conexões sintéticas; px). Orçamento: 1080 em 1440×900 e 2110 em 390×844. Maior valor da candidata: [[MAX1440]] e [[MAX390]]. Na base, [[B_ALT1440]] e [[B_ALT390]] telas estouram.

| Tela | Base 1440 | 0.22.0 1440 | Base 390 | 0.22.0 390 |
|---|---:|---:|---:|---:|
[[HEIGHTS]]

Demais medições de layout que falham na base: botões colados [[B_BOTOES]]; rótulo colado ao campo [[B_ROTULO]]; campo acima de 720 px [[B_CAMPO]]; título desalinhado [[B_ALINHA]]; cor da aba ativa [[B_COR]]; alvo de toque abaixo de 40 px [[B_TOQUE]]; área vazia na Ajuda [[B_AJUDA]]. Rolagem horizontal, nome acessível e contraste passam na base e na candidata: são só de regressão.

**Manuais:** [[OLD_MD_BYTES]] → [[NEW_MD_BYTES]] bytes de Markdown; documentos instalados [[OLD_ALL]] → [[NEW_ALL]]. Exemplos capturados em [[EX_AT]]: [[EX_N]] ([[EX_TYPES]]). O rastreio seção a seção do conteúdo antigo está em `planning/docs-migracao.md`. Os códigos de erro citados nas tabelas dos manuais foram conferidos mecanicamente contra o código.

**Matriz da versão entregue: [[TOTAL]] verificações, [[FAILED]] falhas.** Números lidos das saídas gravadas em `evidence/`.

| Ambiente | Suíte | Verificações | Falhas |
|---|---|---:|---:|
[[MATRIX]]

Por ambiente: [[SCOPES]]. As chamadas à Meta são simuladas em todas as suítes.

**Reprodução na base, fora da soma:** `release022` na 0.21.0 falha em [[BASE_REL_F]] de [[BASE_REL_T]]; `ui-panel` em [[BASE_PANEL_F]] de [[BASE_PANEL_T]]; `layout` em [[BASE_LAYOUT_F]] de [[BASE_LAYOUT_T]].

**Verificação por mutação**, feita pelo responsável da rodada na árvore real: [[MUT_N]] mutações plantadas, [[MUT_DET]] acusadas, [[MUT_REST]] restauradas com hash conferido. Sobrevivente: [[MUT_SURV]]. Essa é a mutação do aviso fixo rodada só em 1440 px: depois de salvar a tela volta para a lista, que cabe na área visível, e o aviso aparece com ou sem fixação. Em 390 px a mesma mutação é acusada. Três mutações precisaram ser refeitas porque a primeira forma era equivalente ou mal plantada (parágrafo repetido, instante em epoch, canais dos ativos). Registro em `evidence/mutations.json`.

Achados da integração, corrigidos antes do fechamento: a suíte de layout contava como visíveis os botões dentro de blocos fechados e acusava falso positivo na Ajuda com o índice real; o teste de visibilidade foi corrigido e continua acusando os defeitos na base.

## 4. Instalação e prova de prontidão

**WordPress 7.1.4 local, isolado, sem acompanhantes.** Instalação limpa da 0.22.0: ativação, primeira leitura de saúde sem reparo, [[OPS]] schemas, runtime igual ao manifesto, leitura integral e paginada dos [[NEW_ALL]] documentos com bytes e SHA-256 conferidos (`smoke`, [[SMOKE_T]] verificações). Migração direta de uma 0.21.0 ativada e semeada: registros, histórico, opções, agenda, pausa, cursor, concessões, retenção e marca de migração preservados (`migrate`, [[MIG_T]] verificações). Os três laboratórios terminaram com [[CLEAN_TABLES]], [[UP_TABLES]] e [[BASE_TABLES]] tabelas remanescentes e diretório removido.

**Navegador real.** Chrome contra WordPress local com simulador da Graph API: salvar conexão de verdade, Ajuda com o índice do servidor, Diagnóstico, sessão expirada e as dez abas sem erro de script nem resposta HTTP de erro (`realflow`). Capturas em `evidence/capturas/`.

**Site-Teste: não instalado nesta rodada.** O instalador tem [[INST_BYTES]] bytes. Nesta sessão, levá-lo ao servidor exigiria digitar o conteúdo em Base64 como argumento de `plugins/upload-base64`, o que não é viável nem confiável nesse tamanho, ou expô-lo numa URL pública, o que é publicação e cabe à frota. Só foram feitas leituras: inventário, `meta/health` (`ok`, zero conexões), `meta/list-connections`, `meta/history-status` e a busca de fronteiras. Estado inicial em `evidence/site-teste-estado-inicial.json`. Nada foi instalado, gravado ou removido no Site-Teste.

Procedimento para a frota, depois de publicar o instalador:

1. Conferir os bytes servidos pela URL raw contra o SHA-256 da seção 8.
2. `plugins/upload` com `expected_slug=wp-mcp-meta-fator3` e `expected_sha256` da seção 8.
3. `plugins/list`: Meta 0.22.0 ativo. `meta/health`: `state=ok`, `storage_ready` e `crypto_ready` verdadeiros.
4. Descoberta com prefixo `meta/`: [[OPS]] operações na versão 0.22.0; rótulo de `meta/status` “Meta: verificar estado e recuperar agendamento”.
5. `meta/documentation` com `{"document":"index"}`: [[NEW_ALL]] documentos, cada um com `title`, `summary` e `topic`, e o mapa `topics`. Ler um documento longo até `next_offset=null` repetindo `expected_revision`. Pedir `offset` maior que zero sem `expected_revision` deve devolver `invalid_input` com `details.field=expected_revision`.
6. `meta/history-status` e `meta/list-connections`: mesmos dados de antes da troca.
7. `manifest.sha256.json` instalado com [[MANIFEST_N]] arquivos. Digest da árvore (SHA-256 das linhas `caminho:sha256` ordenadas do manifesto): `[[TREE]]`.

## 5. Banco, migração e correção por nova versão

Sem DDL, sem option de negócio nova, sem regravação em massa. A única gravação nova é na ativação de uma instalação sem páginas de resultado: o registro `migration/history-020` já nasce concluído. Em atualização por troca de arquivos nada é regravado. Resultados, partes cifradas, revisões, concessões e retenção permanecem no formato vigente.

Antes de instalar, preserve backup consistente de banco e salts. Falha depois da instalação é contida e corrigida em nova versão a partir do estado alcançado. Não há downgrade nem migração reversa.

## 6. O que permanece pendente

1. **Instalação no Site-Teste** e conferência da troca real em MySQL 8.4 e PHP 8.3.36. Motivo: transporte do instalador (seção 4). Responsável: frota.
2. **Leitura da documentação pelo MCP** na versão instalada (aceite da seção 7.3 do padrão) e convivência em execução com os acompanhantes vigentes. Dependem do item 1. Responsável: frota ou a próxima sessão deste pacote.
3. **Pedido MCP Meta 27:** aceite externo em korvena.com.br e ctooffice.com.br, com o token salvo nesses sites. Responsável: frota. Não reaberto.
4. **Fornecedor real:** nenhuma chamada à Meta; sem credenciais nesta rodada. Sem gasto Ads, publicação, contato comercial ou e-mail real.
5. **Não exercitados:** leitor de tela, dispositivo móvel físico, foco visível por medição, PHP 8.3.0 exato, MySQL 8.4 nas suítes nativas, o ramo LinkedIn do template `Admin.php` (só sintaxe), o controlador de laboratório do Site-Teste em `tests/site` (atualizado e não executado) e as regressões herdadas em `tests/regressions`.
6. **Decisão do dono, sem alteração nesta versão:** toda operação despachada, inclusive leituras do painel, grava uma linha de auditoria sem expiração. É política declarada em CONTRACTS.md; o crescimento é ilimitado.
7. **Conversas** continua num único endereço, com subvisões. Separar configuração e consulta em endereços distintos exigiria rever a proteção contra troca de conta entregue na 0.21.0.

## 7. Credenciais e configuração do dono

A atualização não exige novos segredos nem escopos. Para uma conexão: Ferramentas → Fator3 MCP Meta → Configurar → Conexão → Nova conexão: nome, App ID, App Secret e token de usuário do sistema; validade em UTC só quando houver. A versão da API por conexão passou para essa mesma aba. Ativos em Configurar → Ativos, um canal por vez; para dataset, confira também a conta de anúncios vinculada. Referências instaladas: ADMINISTRATION.md, CONFIGURATION.md, USAGE.md e SECURITY.md. Nenhum valor de credencial real está na entrega.

## 8. Identidade dos arquivos

| Artefato | Nome | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | [[INST_NAME]] | [[INST_BYTES]] | `[[INST_SHA]]` |
[[FONTE_ROW]]

Somente o instalador é instalável. O build é determinístico neste ambiente: duas execuções produziram o mesmo ZIP. O fonte contém o runtime idêntico em `plugin/`, o build, os testes, as evidências, o plano e a cópia deste relatório anterior ao fechamento do fonte. Nenhum ZIP da entrega contém outro ZIP.
