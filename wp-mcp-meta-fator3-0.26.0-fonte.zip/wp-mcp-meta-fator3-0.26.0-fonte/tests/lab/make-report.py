#!/usr/bin/env python3
"""Gera o relatório da entrega com todos os números lidos de disco.
uso: make-report.py <dir_fonte> <instalador.zip> <saida.md> interno|externo [fonte.zip]"""
import sys, json, hashlib, os, glob, re, subprocess, datetime, zoneinfo
src, inst, out, mode = sys.argv[1:5]
fonte = sys.argv[5] if len(sys.argv) > 5 else None
ev = os.path.join(src, 'evidence')
J = lambda f: json.load(open(os.path.join(ev, f), encoding='utf-8'))
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
size = lambda p: os.path.getsize(p)

def tot(f):
    d = J(f)
    t = d.get('total', len(d.get('checks', [])))
    fl = d.get('failed', sum(1 for c in d.get('checks', []) if not c.get('passed')))
    return t, fl

suites = [
    ('DOM (jsdom)', 'ui-dom', 'ui-dom.json'), ('DOM (jsdom)', 'ui-identity', 'ui-identity.json'),
    ('DOM (jsdom)', 'ui-messaging', 'ui-messaging.json'), ('DOM (jsdom)', 'ui-monitoring', 'ui-monitoring.json'),
    ('DOM (jsdom)', 'ui-selection-race', 'ui-selection-race.json'), ('DOM (jsdom)', 'ui-panel (nova)', 'ui-panel.json'),
    ('Build e manuais, fora do WordPress', 'docs-lint-cases', 'docs-lint-cases.json'),
    ('Build e manuais, fora do WordPress', 'docs-build-cases', 'docs-build-cases.json'),
    ('Build e manuais, fora do WordPress', 'docs-integrity', 'docs-integrity.json'),
    ('WordPress local, instalação limpa', 'release022 (nova)', 'lab-current-release022.json'),
    ('WordPress local, instalação limpa', 'smoke', 'lab-current-smoke.json'),
    ('WordPress local, instalação limpa', 'configuration', 'lab-current-configuration.json'),
    ('WordPress local, instalação limpa', 'export-integrity', 'lab-current-export-integrity.json'),
    ('WordPress local, instalação limpa', 'dataset', 'lab-current-dataset.json'),
    ('WordPress local, migração 0.21.0 → 0.22.0', 'migrate', 'lab-upgrade-migrate.json'),
    ('Chrome real sobre WordPress local', 'layout (nova)', 'layout-candidato.json'),
    ('Chrome real sobre WordPress local', 'realflow (nova)', 'realflow.json'),
]
rows, by_scope, total, failed = [], {}, 0, 0
for scope, name, f in suites:
    t, fl = tot(f); rows.append(f'| {scope} | {name} | {t} | {fl} |'); by_scope[scope] = by_scope.get(scope, 0) + t; total += t; failed += fl
matrix = '\n'.join(rows)
json.dump({'suites': [{'scope': s, 'suite': n, 'file': f, 'total': tot(f)[0], 'failed': tot(f)[1]} for s, n, f in suites], 'total': total, 'failed': failed, 'by_scope': by_scope}, open(os.path.join(ev, 'matrix.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)

base_rel = tot('lab-baseline-release022.json'); base_panel = tot('ui-panel-base.json'); base_layout = tot('layout-base.json')
lb, lc = J('layout-base.json'), J('layout-candidato.json')
mut = J('mutations.json'); mut_det = sum(1 for m in mut if m['detectada']); mut_rest = sum(1 for m in mut if m['restaurado'])
mut_surv = [m['id'] for m in mut if not m['detectada']]
eff = J('effects-compare.json')
views = [('connections', 'Conexão (lista)'), ('connections:editor', 'Conexão (editor)'), ('assets', 'Ativos'), ('ads-access', 'Consumidores de anúncios'), ('reports', 'Relatórios'), ('jobs', 'Coletas'), ('jobs:schedules', 'Coletas → Agendas'), ('history', 'Histórico'), ('messaging', 'Conversas → Consulta'), ('messaging:setup', 'Conversas → Configuração da recepção'), ('archive', 'Arquivo de Stories'), ('diagnostics', 'Diagnóstico'), ('help', 'Ajuda')]
h = lambda d, v, w: str(d['heights'].get(v, {}).get(w, '—'))
heights = '\n'.join(f'| {label} | {h(lb, v, "1440")} | {h(lc, v, "1440")} | {h(lb, v, "390")} | {h(lc, v, "390")} |' for v, label in views)
max1440 = max(int(x['1440']) for x in lc['heights'].values()); max390 = max(int(x['390']) for x in lc['heights'].values())
bc = lb['by_check']
def bfail(k): return f"{bc[k]['failed']} de {bc[k]['total']}" if k in bc else '—'

old_docs = '/home/claude/work/instalador/wp-mcp-meta-fator3/docs'; new_docs = os.path.join(src, 'plugin/wp-mcp-meta-fator3/docs')
md_bytes = lambda d: sum(size(p) for p in glob.glob(d + '/*.md'))
old_md, new_md = len(glob.glob(old_docs + '/*.md')), len(glob.glob(new_docs + '/*.md'))
old_all, new_all = len(os.listdir(old_docs)), len(os.listdir(new_docs))
ops = len(json.load(open(os.path.join(new_docs, 'input-schemas.json'), encoding='utf-8')))
captured = json.load(open(os.path.join(src, 'build/docs/examples/captured.json'), encoding='utf-8'))
ex_types = {}
for e in captured['examples']: ex_types[e['tipo']] = ex_types.get(e['tipo'], 0) + 1
manifest = json.load(open(os.path.join(src, 'plugin/wp-mcp-meta-fator3/manifest.sha256.json')))
tree = hashlib.sha256('\n'.join(f'{k}:{v}' for k, v in sorted(manifest.items())).encode()).hexdigest()
# medições da base refeitas a partir dos arquivos da 0.21.0
import collections
old_ops=set(json.load(open(old_docs+'/input-schemas.json',encoding='utf-8')))
stale=0;paras=collections.defaultdict(set);alltext=''
for f in glob.glob(old_docs+'/*.md'):
    t=open(f,encoding='utf-8').read();alltext+=t
    if any(v!='0.21.0' for v in re.findall(r'\b0\.\d+\.\d+\b',t.split('\n',1)[0])):stale+=1
    for para in re.split(r'\n\s*\n',t):
        para=para.strip()
        if len(para)>=160:paras[para].add(f)
old_dup=sum(1 for v in paras.values() if len(v)>1)
old_unmentioned=sum(1 for o in old_ops if not re.search(r'(?<![a-z-])'+re.escape(o)+r'(?![a-z-])',alltext))
rel=J('lab-current-release022.json');a1_cases=sum(1 for c in rel['checks'] if c['name'].startswith('A1 ') and 'field=' in c['name'])
sm=J('lab-current-smoke.json')
wide=[c['detail'] for c in lb['checks'] if c['id']=='campos-ate-720px' and not c['passed']]
wide_px=max([int(x) for d in wide for x in re.findall(r'(\d{3,4})\s*px',d)] or [0])
node_v=subprocess.run(['node','-v'],capture_output=True,text=True).stdout.strip().lstrip('v')
db_v=subprocess.run(['mariadb','--version'],capture_output=True,text=True).stdout
db_v=re.search(r'Distrib ([0-9.]+)',db_v).group(1)
chrome = subprocess.run(['google-chrome', '--version'], capture_output=True, text=True).stdout.strip()
now = datetime.datetime.now(zoneinfo.ZoneInfo('America/Sao_Paulo')).isoformat(timespec='seconds')
inst_name = os.path.basename(inst)
if mode == 'externo':
    fonte_row = f'| Fonte | {os.path.basename(fonte)} | {size(fonte)} | `{sha(fonte)}` |'
    copy_note = 'Este é o relatório externo canônico. A cópia dentro do fonte é anterior ao fechamento do fonte e não traz o tamanho nem o hash do próprio fonte.'
else:
    fonte_row = '| Fonte | wp-mcp-meta-fator3-0.22.0-fonte.zip | a preencher no relatório externo após empacotamento | a preencher no relatório externo após empacotamento |'
    copy_note = 'Esta é a **cópia anterior ao fechamento do fonte**. O relatório externo canônico é `wp-mcp-meta-fator3-0.22.0-relatorio.md`, entregue junto do fonte, e traz o tamanho e o SHA-256 finais do fonte.'

T = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'relatorio-template.md'), encoding='utf-8').read()
vals = dict(OLD_STALE=stale, OLD_DUP=old_dup, OLD_UNMENTIONED=old_unmentioned, A1_CASES=a1_cases, WP_V=sm['wordpress'], PHP_V=sm['php'], NODE_V=node_v, DB_V=db_v, WIDE_PX=wide_px, NOW=now, MATRIX=matrix, TOTAL=total, FAILED=failed, SCOPES='; '.join(f'{v} em {k.lower()}' for k, v in by_scope.items()),
            BASE_REL_T=base_rel[0], BASE_REL_F=base_rel[1], BASE_PANEL_T=base_panel[0], BASE_PANEL_F=base_panel[1], BASE_LAYOUT_T=base_layout[0], BASE_LAYOUT_F=base_layout[1],
            CAND_LAYOUT_T=lc['total'], MUT_N=len(mut), MUT_DET=mut_det, MUT_REST=mut_rest, MUT_SURV=', '.join(mut_surv) or 'nenhuma',
            EFF_BASE=eff['base_operations'], EFF_CAND=eff['candidate_operations'], EFF_DIFF=len(eff['differences']), HEIGHTS=heights, MAX1440=max1440, MAX390=max390,
            B_ENTER=bfail('enter-na-busca-sem-save-connection'), B_AVISO=bfail('aviso-visivel-apos-salvar-rolado'), B_AVISO_ABA=bfail('aviso-some-ao-trocar-de-aba'),
            B_BOTOES=bfail('botoes-adjacentes-8px'), B_ROTULO=bfail('rotulo-separado-do-campo'), B_CAMPO=bfail('campos-ate-720px'), B_ALINHA=bfail('titulo-secao-e-selecao-alinhados'),
            B_COR=bfail('aba-ativa-cor-do-esquema'), B_TOQUE=bfail('alvos-de-toque-40px'), B_ALT1440=bfail('altura-ate-1080px'), B_ALT390=bfail('altura-ate-2110px'), B_AJUDA=bfail('ajuda-sem-area-vazia'),
            OLD_MD=old_md, NEW_MD=new_md, OLD_MD_BYTES=md_bytes(old_docs), NEW_MD_BYTES=md_bytes(new_docs), OLD_ALL=old_all, NEW_ALL=new_all, OPS=ops,
            EX_N=len(captured['examples']), EX_TYPES=', '.join(f'{v} de {k}' for k, v in ex_types.items()), EX_AT=captured['captured_at'],
            MANIFEST_N=len(manifest), TREE=tree, CHROME=chrome, INST_NAME=inst_name, INST_BYTES=size(inst), INST_SHA=sha(inst), FONTE_ROW=fonte_row, COPY_NOTE=copy_note,
            SMOKE_T=tot('lab-current-smoke.json')[0], MIG_T=tot('lab-upgrade-migrate.json')[0], REL_T=tot('lab-current-release022.json')[0],
            CLEAN_TABLES=J('lab-current-cleanup.json')['remaining_tables'], UP_TABLES=J('lab-upgrade-cleanup.json')['remaining_tables'], BASE_TABLES=J('lab-baseline-cleanup.json')['remaining_tables'])
missing = set(re.findall(r'\[\[([A-Z0-9_]+)\]\]', T)) - set(vals)
if missing: raise SystemExit('marcadores sem valor: ' + ', '.join(sorted(missing)))
for k, v in vals.items(): T = T.replace('[[' + k + ']]', str(v))
open(out, 'w', encoding='utf-8').write(T)
print(out, size(out), 'bytes')
