<?php
// Executa um trecho PHP dentro de um WordPress do laboratório, como um usuário.
// uso: php wp-run.php <site_dir> <user_login|-> <arquivo.php> [args...]
// Variáveis com prefixo próprio: o core usa $file, $plugin etc. no escopo global.
$GLOBALS['lab_site'] = $argv[1]; $GLOBALS['lab_login'] = $argv[2]; $GLOBALS['lab_script'] = $argv[3];
$GLOBALS['lab_args'] = array_slice($argv, 4);
preg_match('#http://(127\.0\.0\.1:[0-9]+)#', file_get_contents($GLOBALS['lab_site'] . '/wp-config.php'), $lab_m);
$_SERVER['HTTP_HOST'] = $lab_m[1];
$_SERVER['REQUEST_URI'] = '/';
$_SERVER['REQUEST_METHOD'] = 'GET';
require $GLOBALS['lab_site'] . '/wp-load.php';
if ($GLOBALS['lab_login'] !== '-') { $lab_u = get_user_by('login', $GLOBALS['lab_login']); if (!$lab_u) { fwrite(STDERR, "usuário ausente\n"); exit(2); } wp_set_current_user($lab_u->ID); }
require $GLOBALS['lab_script'];
