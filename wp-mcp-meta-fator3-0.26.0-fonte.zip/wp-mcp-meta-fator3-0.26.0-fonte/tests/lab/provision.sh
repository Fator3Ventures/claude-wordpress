#!/usr/bin/env bash
# Provisiona um WordPress 7.1.4 local descartável.
# uso: provision.sh <nome> <banco> <porta>
set -euo pipefail
NAME="$1"; DB="$2"; PORT="$3"
LAB=/home/claude/work/lab
SITE="$LAB/sites/$NAME"
SOCK="$LAB/run/mysql.sock"
rm -rf "$SITE"; mkdir -p "$LAB/sites"
cp -r "$LAB/wp-src/wordpress" "$SITE"
mariadb --socket="$SOCK" -uroot -e "DROP DATABASE IF EXISTS \`$DB\`; CREATE DATABASE \`$DB\` CHARACTER SET utf8mb4; GRANT ALL ON \`$DB\`.* TO 'wp'@'127.0.0.1'; GRANT ALL ON \`$DB\`.* TO 'wp'@'localhost'; FLUSH PRIVILEGES;"
SALT() { php -r 'echo bin2hex(random_bytes(32));'; }
cat > "$SITE/wp-config.php" <<PHP
<?php
define('DB_NAME', '$DB');
define('DB_USER', 'wp');
define('DB_PASSWORD', '${F3_LAB_DB_PASS}');
define('DB_HOST', '127.0.0.1:33306');
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');
define('AUTH_KEY', '$(SALT)');
define('SECURE_AUTH_KEY', '$(SALT)');
define('LOGGED_IN_KEY', '$(SALT)');
define('NONCE_KEY', '$(SALT)');
define('AUTH_SALT', '$(SALT)');
define('SECURE_AUTH_SALT', '$(SALT)');
define('LOGGED_IN_SALT', '$(SALT)');
define('NONCE_SALT', '$(SALT)');
\$table_prefix = 'wp_';
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
define('DISABLE_WP_CRON', true);
define('WP_HTTP_BLOCK_EXTERNAL', true);
define('AUTOMATIC_UPDATER_DISABLED', true);
define('WP_HOME', 'http://127.0.0.1:$PORT');
define('WP_SITEURL', 'http://127.0.0.1:$PORT');
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
require_once ABSPATH . 'wp-settings.php';
PHP
php -d display_errors=1 -r '
define("WP_INSTALLING", true);
$_SERVER["HTTP_HOST"]="127.0.0.1:'"$PORT"'"; $_SERVER["REQUEST_URI"]="/";
require $argv[1]."/wp-load.php";
require_once ABSPATH."wp-admin/includes/upgrade.php";
$r = wp_install("Lab '"$NAME"'", "qaadmin", "qa@example.invalid", false, "", "'"$F3_LAB_PASS"'", "pt_BR");
$u = wp_insert_user(["user_login"=>"qaeditor","user_pass"=>"'"$F3_LAB_PASS"'","user_email"=>"editor@example.invalid","role"=>"editor"]);
$s = wp_insert_user(["user_login"=>"qasub","user_pass"=>"'"$F3_LAB_PASS"'","user_email"=>"sub@example.invalid","role"=>"subscriber"]);
update_option("permalink_structure","/%postname%/");
echo json_encode(["admin"=>$r["user_id"],"editor"=>$u,"subscriber"=>$s,"wp"=>get_bloginfo("version"),"php"=>PHP_VERSION,"db"=>$GLOBALS["wpdb"]->db_version()]),"\n";
' "$SITE"
echo "site=$SITE port=$PORT"
