#!/usr/bin/env bash
# Constrói e roda UMA checagem de interface; sai com o código da checagem.
# uso: check-ui.sh <dir_fonte> dom|layout [larguras]
set -uo pipefail
SRC="$1"; WHAT="$2"; W="${3:-1440}"; cd "$SRC"
python3 build/build.py >/tmp/mut-build.log 2>&1 || { echo "build reprovou: $(tail -1 /tmp/mut-build.log | cut -c1-200)"; exit 3; }
if [ "$WHAT" = dom ]; then
  php tests/browser/render.php build/dist/wp-mcp-meta-fator3 identity > /tmp/mut-id.json
  node tests/browser/panel.cjs /tmp/mut-id.json build/dist/wp-mcp-meta-fator3/assets/admin.js tests/browser/fixtures/diagnostics.json /tmp/mut-panel.json >/dev/null 2>/tmp/mut-panel.err; rc=$?
  python3 -c "
import json
d=json.load(open('/tmp/mut-panel.json'));print('falhas:',[c['name'][:80] for c in d['checks'] if not c['passed']][:4])" 2>/dev/null || tail -2 /tmp/mut-panel.err
  exit $rc
fi
SITE=/home/claude/work/lab/sites/int
rm -rf "$SITE/wp-content/plugins/wp-mcp-meta-fator3"; cp -r build/dist/wp-mcp-meta-fator3 "$SITE/wp-content/plugins/wp-mcp-meta-fator3"
/home/claude/work/scripts/lab-up.sh int 8103 >/dev/null
F3_WIDTHS="$W" F3_PUPPETEER=/home/claude/work/pptr/node_modules/puppeteer-core NODE_PATH=/home/claude/work/pptr/node_modules node tests/visual/layout.cjs --base http://127.0.0.1:8103 --user qaadmin --pass "${F3_LAB_PASS}" --chrome /usr/bin/google-chrome --shots /tmp/mut-shots --prefix mut --out /tmp/mut-layout.json >/tmp/mut-layout.log 2>&1; rc=$?
python3 -c "
import json
d=json.load(open('/tmp/mut-layout.json'));print('falhas:',sorted({c['id']+'@'+c['view'] for c in d['checks'] if not c['passed']})[:5])" 2>/dev/null || tail -2 /tmp/mut-layout.log
exit $rc
