// Mede a altura do documento por aba (estado inicial) e a altura da navegação. uso: node heights.cjs <url>
const puppeteer=require('/home/claude/work/pptr/node_modules/puppeteer-core');
(async()=>{const base=process.argv[2];const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--disable-gpu','--hide-scrollbars']});const p=await b.newPage();
await p.setViewport({width:1440,height:900});await p.goto(base+'/wp-login.php',{waitUntil:'networkidle2'});await p.type('#user_login','qaadmin');await p.type('#user_pass',process.env.F3_LAB_PASS);await Promise.all([p.waitForNavigation({waitUntil:'networkidle2'}),p.click('#wp-submit')]);
const tabs='connections,assets,jobs,reports,history,ads-access,messaging,archive,diagnostics,help'.split(',');const out={};
for(const [label,vp] of [['1440x900',{width:1440,height:900}],['390x844',{width:390,height:844,isMobile:true}]]){await p.setViewport(vp);out[label]={};
for(const t of tabs){await p.goto(base+'/wp-admin/tools.php?page=wp-mcp-meta-fator3&tab='+t,{waitUntil:'networkidle2'});await new Promise(r=>setTimeout(r,500));
out[label][t]=await p.evaluate(()=>{const root=document.querySelector('.f3-social').getBoundingClientRect();const nav=document.querySelector('.f3-tabs');return {painel:Math.round(root.height),telas:+(root.height/innerHeight).toFixed(2),nav:nav?Math.round(nav.getBoundingClientRect().height):null};});}}
console.log(JSON.stringify(out));await b.close();})();
