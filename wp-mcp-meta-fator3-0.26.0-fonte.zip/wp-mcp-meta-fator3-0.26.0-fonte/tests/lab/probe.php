<?php
// Sondagem exploratória: chama operações REST internas como um usuário e imprime o envelope resumido.
// uso: php wp-run.php <site> <login|-> probe.php '<json: [[op, input], ...]>'
$calls = json_decode($GLOBALS['lab_args'][0], true);
foreach ($calls as [$op, $input]) {
    $req = new WP_REST_Request('POST', '/f3-meta/v1/' . $op);
    $req->set_header('Content-Type', 'application/json');
    $req->set_body(wp_json_encode($input, JSON_FORCE_OBJECT * (int) empty($input)));
    $res = rest_do_request($req);
    $d = $res->get_data();
    $out = ['op' => $op, 'http' => $res->get_status()];
    if (is_array($d)) {
        foreach (['success', 'code', 'message', 'details', 'avisos', 'audit_warning'] as $k) if (array_key_exists($k, $d)) $out[$k] = $d[$k];
        if (isset($d['data']) && is_array($d['data'])) { $j = wp_json_encode($d['data'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); $out['data'] = strlen($j) > 900 ? substr($j, 0, 900) . '…(' . strlen($j) . ' bytes)' : $d['data']; }
    } else $out['raw'] = $d;
    echo wp_json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), "\n";
}
