import os,pathlib as pl,secrets,shutil,json,sys,subprocess
src=pl.Path(__file__).resolve().parents[2]; base=pl.Path(os.environ['F3_QA_BASE']).resolve();slug='wp-mcp-meta-fator3';php=os.environ.get('F3_SOCIAL_PHP','php')
env=os.environ.copy(); phase=sys.argv[1]; tests=src/'tests/native'; core=pl.Path(os.environ['F3_QA_WP_CORE']).resolve(); ev=src/'evidence/026'
env.setdefault('F3_QA_URL','http://127.0.0.1:34893')
def proc(script,*args,env=env):
 return subprocess.run([php,str(script),*map(str,args)],env=env,stdout=subprocess.PIPE,stderr=sys.stderr,text=True)
def sql(stmt):
 subprocess.run([php,'-r',"""$m=new mysqli('127.0.0.1','root','','',34793);$m->query($argv[1]);""",stmt],check=True)
def testfile(name,script,expect=0):
 x=proc(script); result=json.loads(x.stdout.strip().splitlines()[-1])
 (ev/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(name,x.returncode,result.get('total'),result.get('failed'),[c.get('name') for c in result.get('checks',[]) if c.get('passed')==False],flush=True)
 if x.returncode!=expect:raise RuntimeError(name+' '+str(x.returncode))
def prepare(kind,base):
 prefix='f3qa022_'+secrets.token_hex(6)+'_'; root=pl.Path('/tmp')/prefix; root.mkdir(mode=0o700); site=root/'wordpress';site.mkdir();(root/'evidence').mkdir()
 db=prefix.rstrip('_');sql('CREATE DATABASE '+db+' CHARACTER SET utf8mb4')
 for d in ('wp-admin','wp-includes'):
  if phase.startswith('ui-'):shutil.copytree(core/d,site/d)
  else:(site/d).symlink_to((core/d).resolve(),True)
 for p in core.glob('*.php'):
  if p.name not in ['wp-config.php','wp-config-sample.php'] and (p.name.startswith('wp-') or p.name in ['xmlrpc.php','index.php']): shutil.copyfile(p,site/p.name)
 plugins=site/'wp-content/plugins';plugins.mkdir(parents=True);mu=site/'wp-content/mu-plugins';mu.mkdir()
 (mu/'no-external.php').write_text('<?php add_filter("pre_http_request",static fn($pre)=>$pre!==false?$pre:new WP_Error("lab_external_blocked"),PHP_INT_MAX);add_filter("pre_wp_mail",static fn()=>true,PHP_INT_MAX);')
 (site/'wp-config.php').write_text("""<?php define('DB_NAME','"""+db+"""');define('DB_USER','root');define('DB_PASSWORD','');define('DB_HOST','127.0.0.1:34793');define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');"""+''.join(f"define('{key}','{secrets.token_hex(48)}');" for key in 'AUTH_KEY SECURE_AUTH_KEY LOGGED_IN_KEY NONCE_KEY AUTH_SALT SECURE_AUTH_SALT LOGGED_IN_SALT NONCE_SALT'.split())+"$table_prefix='"+prefix+"';define('WP_HOME','http://127.0.0.1:34893');define('WP_SITEURL',WP_HOME);define('DISABLE_WP_CRON',true);define('WP_HTTP_BLOCK_EXTERNAL',true);define('WP_DEBUG',false);if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require ABSPATH.'wp-settings.php';")
 (root/'baseline').mkdir();shutil.copytree(pl.Path(os.environ['F3_QA_BASE']),root/'baseline'/slug);shutil.copytree(base,plugins/slug);env.update(F3_LAB_ROOT=str(root),F3_LAB_FLAVOR=kind)
 return root,db,plugins/slug
cand=src/'build/dist'/slug
root,db,installed=prepare('upgrade' if phase=='upgrade' else ('baseline' if phase=='grant-base' else 'current'),base if phase in ('upgrade','grant-base') else cand)
try:
 testfile(phase+'-install',tests/'install.php')
 if phase in ('origin','origin-base','ui-origin'):
  shutil.copytree(os.environ['F3_QA_CORE'],installed.parent/'base-site-core-fator3')
  testfile('activate-core',tests/'activate-core024.php')
  if phase!='ui-origin':testfile(phase,tests/'origin026.php',1 if phase=='grant-base' else 0)
  else:
   proc(tests/'origin026.php',env=env|{'F3_UI_SEED':'1'}).check_returncode()
   env['F3_QA_PASSWORD']=secrets.token_urlsafe(26)
   proc(src/'tests/visual/seed0221.php').check_returncode()
   server=subprocess.Popen([php,'-S','127.0.0.1:34893','-t',str(root/'wordpress')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   try:subprocess.run([sys.executable,str(src/'tests/visual/origin024.py'),str(ev/(phase+'.json'))],env=env,check=True)
   finally:server.terminate();server.wait()
 if phase in ('grant-base','grant'):
  shutil.copytree(pl.Path(os.environ['F3_QA_COMPANIONS'])/'wp-mcp-fator3',installed.parent/'wp-mcp-fator3')
  testfile('mcp-'+phase,tests/'activate-mcp026.php')
  testfile(phase,tests/'grant026.php',1 if phase=='grant-base' else 0)
 if phase=='combination':
  for plug in sorted(pl.Path(os.environ['F3_QA_COMPANIONS']).iterdir()):shutil.copytree(plug,installed.parent/plug.name)
  shutil.copytree(os.environ['F3_QA_CORE'],installed.parent/'base-site-core-fator3')
  testfile('activate-companions',tests/'activate023.php')
  testfile('combination',tests/'combination026.php')
 if phase=='without-provider':
  shutil.copytree(os.environ['F3_QA_CORE'],installed.parent/'base-site-core-fator3')
  testfile('activate-core',tests/'activate-core024.php')
  proc(tests/'disable-provider024.php').check_returncode()
  testfile('core-alone',tests/'core-alone024.php')
 if phase=='capture':
  r=proc(src/'tests/docs/capture-examples.php');r.check_returncode();(src/'build/docs/examples/captured.json').write_text(json.dumps(json.loads(r.stdout),ensure_ascii=False,indent=4)+'\n')
 if phase=='upgrade':
  shutil.rmtree(installed);shutil.copytree(cand,installed);testfile('migration',tests/'migrate.php')
 if phase=='clean':
  for t in ['release022','release0221','smoke','configuration','export-integrity','dataset','access0221','worker023']: testfile(t,tests/(t+'.php'))
finally:
 sql('DROP DATABASE '+db);shutil.rmtree(root)
