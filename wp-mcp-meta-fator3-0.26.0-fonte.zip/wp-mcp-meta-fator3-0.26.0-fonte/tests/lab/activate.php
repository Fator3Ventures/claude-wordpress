<?php
require_once ABSPATH.'wp-admin/includes/plugin.php';
$r = activate_plugin('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php');
echo json_encode(['activate'=>is_wp_error($r)?$r->get_error_message():'ok','active'=>is_plugin_active('wp-mcp-meta-fator3/wp-mcp-meta-fator3.php'),'version'=>defined('ABSPATH')&&class_exists('Fator3\Meta\Config')?Fator3\Meta\Config::VERSION:null]),"\n";
