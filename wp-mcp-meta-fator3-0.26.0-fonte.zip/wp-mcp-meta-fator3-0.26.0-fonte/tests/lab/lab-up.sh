#!/usr/bin/env bash
# Sobe (de forma idempotente) o MariaDB local e o servidor PHP de um site do laboratório.
# uso: lab-up.sh <nome> <porta>
set -uo pipefail
LAB=/home/claude/work/lab
SOCK="$LAB/run/mysql.sock"
if ! mariadb --socket="$SOCK" -uroot -e 'select 1' >/dev/null 2>&1; then
  setsid nohup mariadbd --user=root --datadir="$LAB/mysql" --socket="$SOCK" --pid-file="$LAB/run/mysql.pid" --port=33306 --bind-address=127.0.0.1 > "$LAB/log/mariadb.log" 2>&1 < /dev/null &
  for i in $(seq 1 30); do mariadb --socket="$SOCK" -uroot -e 'select 1' >/dev/null 2>&1 && break; sleep 1; done
fi
if [ $# -ge 2 ]; then
  NAME="$1"; PORT="$2"
  if ! curl -s -o /dev/null "http://127.0.0.1:$PORT/wp-login.php"; then
    PHP_CLI_SERVER_WORKERS=4 setsid nohup php -d display_errors=0 -d memory_limit=512M -S "127.0.0.1:$PORT" -t "$LAB/sites/$NAME" > "$LAB/log/php-$NAME.log" 2>&1 < /dev/null &
    for i in $(seq 1 20); do curl -s -o /dev/null "http://127.0.0.1:$PORT/wp-login.php" && break; sleep 0.5; done
  fi
  curl -s -o /dev/null -w "site $NAME http=%{http_code}\n" "http://127.0.0.1:$PORT/wp-login.php"
fi
