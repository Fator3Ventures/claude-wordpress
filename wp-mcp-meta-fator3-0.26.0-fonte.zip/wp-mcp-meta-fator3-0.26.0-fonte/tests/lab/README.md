# Scripts do laboratório local da rodada

Cópia dos scripts usados para montar o WordPress local, rodar as suítes, plantar as mutações e gerar o relatório. Foram executados com a raiz fixa `/home/claude/work` (WordPress oficial extraído em `lab/wp-src/wordpress`, MariaDB com socket em `lab/run/mysql.sock`, `puppeteer-core` em `pptr/node_modules`, instalador da base extraído em `instalador/`). Para reproduzir em outra máquina, ajuste essa raiz nos scripts ou monte a mesma estrutura.

As senhas do laboratório não ficam nos arquivos: defina `F3_LAB_PASS` (senha do administrador local) e `F3_LAB_DB_PASS` (senha do usuário do banco local) antes de usar. Todos os dados são sintéticos e nenhum script alcança a Meta.

| Script | Função |
|---|---|
| `lab-up.sh` | sobe MariaDB e o servidor PHP de um site, de forma idempotente |
| `provision.sh` | cria um WordPress local com três usuários (administrador, editor, assinante) |
| `ui-site.sh`, `ui-sync.sh` | site com o plugin, o simulador da Graph API e duas conexões sintéticas; troca dos arquivos do plugin |
| `native-lab.sh` | laboratório isolado das suítes `tests/native` (instalação limpa, base, migração) |
| `wp-run.php`, `probe.php`, `activate.php` | execução de PHP e de operações REST dentro do WordPress como um usuário |
| `run-suites.sh` | suítes documentais, DOM e nativas, gravando a saída bruta em `evidence/` |
| `layout.sh` | suíte de layout em Chrome contra um site |
| `check-native.sh`, `check-ui.sh`, `mutate.py` | verificação por mutação: planta o defeito na árvore real, roda a checagem, restaura e confere o hash |
| `heights.cjs` | altura de cada aba e da navegação |
| `make-report.py`, `relatorio-template.md` | relatório com os números lidos de `evidence/` |
