#!/usr/bin/env bash
# Executa as suítes que não dependem de navegador real e grava a saída bruta de cada uma em <evidence_dir>.
# uso: run-suites.sh <dir_fonte> <evidence_dir> [nativas|dom|docs|todas]
set -uo pipefail
SRC="$1"; EV="$2"; WHAT="${3:-todas}"
S=/home/claude/work/scripts/native-lab.sh; BASE=/home/claude/work/instalador/wp-mcp-meta-fator3
export LAB_NAME="${LAB_NAME:-main}"
mkdir -p "$EV"; cd "$SRC"
/home/claude/work/scripts/lab-up.sh >/dev/null
last_json() { python3 -c "
import sys,json
t=sys.stdin.read().strip()
try: json.loads(t); print(t)
except Exception: print(t.split('\n')[-1] if t else '')
"; }
if [ "$WHAT" = docs ] || [ "$WHAT" = todas ]; then
  python3 tests/docs/lint-cases.py > "$EV/docs-lint-cases.json" 2>"$EV/docs-lint-cases.err"; echo "lint-cases exit=$?"
  python3 tests/docs/build-cases.py > "$EV/docs-build-cases.json" 2>"$EV/docs-build-cases.err"; echo "build-cases exit=$?"
  python3 tests/docs/check.py /usr/bin/php build/dist/wp-mcp-meta-fator3 > "$EV/docs-integrity.json" 2>"$EV/docs-integrity.err"; echo "docs-integrity exit=$?"
fi
if [ "$WHAT" = dom ] || [ "$WHAT" = todas ]; then
  ( cd tests/browser && [ -d node_modules ] || npm ci --no-audit --no-fund >/dev/null 2>&1 )
  php tests/browser/render.php build/dist/wp-mcp-meta-fator3 > /tmp/f3-painel.html
  php tests/browser/render.php build/dist/wp-mcp-meta-fator3 identity > /tmp/f3-identidade.json
  node tests/browser/run.cjs /tmp/f3-painel.html "$EV/ui-dom.json" >/dev/null 2>"$EV/ui-dom.err"; echo "ui-dom exit=$?"
  for s in identity monitoring messaging selection-race; do node tests/browser/$s.cjs /tmp/f3-identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js "$EV/ui-$s.json" >/dev/null 2>"$EV/ui-$s.err"; echo "ui-$s exit=$?"; done
  node tests/browser/panel.cjs /tmp/f3-identidade.json build/dist/wp-mcp-meta-fator3/assets/admin.js tests/browser/fixtures/diagnostics.json "$EV/ui-panel.json" >/dev/null 2>"$EV/ui-panel.err"; echo "ui-panel exit=$?"
fi
if [ "$WHAT" = nativas ] || [ "$WHAT" = todas ]; then
  $S cleanup >/dev/null 2>&1 || true
  $S setup current f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" 2>"$EV/lab-current-install.err" | last_json > "$EV/lab-current-install.json"
  for t in release022 smoke configuration export-integrity dataset effects-map; do $S run $t.php 2>"$EV/lab-current-$t.err" | last_json > "$EV/lab-current-$t.json"; echo "current/$t exit=${PIPESTATUS[0]}"; done
  $S cleanup > "$EV/lab-current-cleanup.json"
  $S setup baseline f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" 2>"$EV/lab-baseline-install.err" | last_json > "$EV/lab-baseline-install.json"
  for t in release022 effects-map; do $S run $t.php 2>"$EV/lab-baseline-$t.err" | last_json > "$EV/lab-baseline-$t.json"; echo "baseline/$t exit=${PIPESTATUS[0]} (reprodução: falha esperada em release022)"; done
  $S cleanup > "$EV/lab-baseline-cleanup.json"
  $S setup upgrade f3qa022 "$PWD/build/dist/wp-mcp-meta-fator3" "$BASE" "$PWD/tests/native" 2>"$EV/lab-upgrade-install.err" | last_json > "$EV/lab-upgrade-install.json"
  $S upgrade 2>"$EV/lab-upgrade-migrate.err" | last_json > "$EV/lab-upgrade-migrate.json"; echo "upgrade/migrate exit=${PIPESTATUS[0]}"
  $S cleanup > "$EV/lab-upgrade-cleanup.json"
  python3 tests/native/effects-compare.py "$EV/lab-baseline-effects-map.json" "$EV/lab-current-effects-map.json" > "$EV/effects-compare.json" 2>&1; echo "effects-compare exit=$?"
fi
find "$EV" -name '*.err' -size 0 -delete
python3 - "$EV" <<'PY'
import json,sys,glob,os
ev=sys.argv[1]
for f in sorted(glob.glob(ev+'/*.json')):
    try:d=json.load(open(f))
    except Exception as e:print('%-34s NÃO-JSON'%os.path.basename(f));continue
    if isinstance(d,dict):
        t=d.get('total');fl=d.get('failed')
        if t is None and 'checks' in d:t=len(d['checks']);fl=sum(1 for c in d['checks'] if not c.get('passed'))
        extra={k:d[k] for k in ('version','identical','remaining_tables','tables_dropped','installed') if k in d}
        print('%-34s total=%s failed=%s %s'%(os.path.basename(f),t,fl,extra or ''))
PY
