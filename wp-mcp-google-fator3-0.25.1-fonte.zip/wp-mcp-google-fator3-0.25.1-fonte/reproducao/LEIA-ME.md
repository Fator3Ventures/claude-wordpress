# Reprodução — Google 0.25.1

Base publicada exata: Google0.24.0. Runtime:172 arquivos,168 PHP. Rota corrente: tools/release025.py. Só evidence/025/closed e o relatório externo contêm os totais finais; evidências anteriores são históricas. Normas r5 preservadas em entradas/. Relatórios/pedido atual em entradas025/. Sem ZIP aninhado.

## Insumos

Linux amd64, Python3, PHP8.3.6/MySQL8.0.46. runtime-dependencies.json fixa pacotes oficiais; download-runtime.py exige SHA256 e extrai em diretório novo. Use php024.ini.template substituindo RUNTIME_DIRECTORY. PHP_INI_SCAN_DIR vazio; LD_LIBRARY_PATH=runtime/usr/lib/x86_64-linux-gnu; wrapper chama runtime/usr/bin/php8.3 -c PHP_INI.

WordPress oficial: https://wordpress.org/wordpress-7.1.2.zip e https://wordpress.org/wordpress-7.1.4.zip. Hashes exatos nos manifest025-*.json; caminhos devem ser ajustados à nova máquina, conservando hashes/versões. Instalador candidato e baseline, Core1.65.1, MCP0.38.0, Meta0.17.0 e LinkedIn0.13.0 são entradas externas imutáveis; não estão aninhados no fonte. Pipedrive0.5.0 foi analisado e observado remotamente; exige PHP8.3.36 e não foi ativado na bancada PHP8.3.6. Meta0.18.0 e LinkedIn0.14.0 foram observados remotos depois, com changelogs instalados lidos e sem pacotes recebidos nesta execução.

## Execução

No plugin/wp-mcp-google-fator3: execute PHP_WRAPPER build/export-contracts.php --check, python3 build/check-docs.py e python3 build/build.py candidate --output NOVO/wp-mcp-google-fator3-0.25.1-instalador.zip. O hash deve coincidir com o candidato do manifesto e do relatório externo.

Execute python3 tools/release025.py --case CASO --manifest MANIFESTO --workdir NOVO_LAB --evidence NOVA_PROVA --php PHP_WRAPPER. Casos:

- minimum: WordPress7.1.2, Google isolado, mínimo e regressão dos pedidos43–46.
- current: WordPress7.1.4, acompanhantes originais, configuração, pedidos43–46, documentação completa via MCP e reprodução do SDK Core ilegível.
- core: Core original,14 provas de integração e85 de acervos Ads/GSC com fornecedor sintético.
- renewal: Core1.65.1 com correção proposta em core1651-fix, configuração com simulação/MCP/UI, política de avisos, recuperação, falhas de persistência e deduplicação, documentos completos.
- upgrade: baseGoogle0.24.0, Core com a mesma proposta, atualização autenticada pelo MCP0.38, preservação de dados/concessões/ciphertexts, rollback/reaplicação e documentação.

patch-core025 aplica um único arquivo somente dentro do laboratório com marcador de propriedade; exige hash da entrada e da base original. Arquivos acompanhantes distribuídos permanecem imutáveis. A variante não representa Core corrigido instalado no Site-Teste. As verificações de inventário registram explicitamente a diferença.

Não executar scripts de rodada histórica como se fossem gate0.25. PHPUnit integral indisponível (HTTP403 do PHAR oficial); nenhum total antigo aproveitado. Correio e HTTP externo interceptados; não há homologação de fornecedor nem entrega postal. Relatórios nativos registram hashes, versões e checks.

## Site-Teste e fechamento

A sonda temporária site-test-request47.php aceita somente o domínio de teste, administrador, versões0.24/0.25 e identificador sintético fixo livre. Intercepta todo correio/HTTP na requisição, remove seus incidentes/recibos, preserva a configuração de entrega. É removida após a prova; não integra instalador. A instalação compartilhada troca somente Google, com rollback de arquivos em prévia e inventários antes/depois.

empacotar-fonte.py fecha uma única vez o fonte com relatório anterior ao fechamento; hash final somente no relatório externo. Reconstrua instalador do fonte fechado e compare bytes. Nenhum banco, credencial, cookie, log privado ou binário de dependência integra o fonte.
