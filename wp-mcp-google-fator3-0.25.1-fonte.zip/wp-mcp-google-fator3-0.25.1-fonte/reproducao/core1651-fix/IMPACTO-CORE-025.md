# Google 0.25.1 → Site Core — incompatibilidade do SDK de medição

Etapa: implementação entregue; correção preparada sob autorização; 31/10/2026. Destinatário: mantenedor Site Core. Base Core 1.65.1 original, sem alteração do pacote recebido. Prioridade alta: bloqueio de leitura de medição e verificação GA4; também afeta contexto de conversões.

## Evidência e causa

Em WordPress 7.1.4/PHP 8.3.6, o Core original retorna `site-measurement-context/1.0.0`, `ok:false`, `code:unreadable`. O mesmo estado foi observado no Site-Teste antes de instalar Google 0.25.1. A validação da fotografia original informa `ga4 is not a valid property of Object`. `F3Base_Medicao_Contexto::politica()` emite ga4/google_ads/gtm no objeto fechado `policy.destination_loading.destinations`, enquanto o schema publicado define somente meta/linkedin/clarity. Também emite `clock` e `accelerate_conversion`, ausentes no mesmo schema fechado. Os schemas copiados pelo Google coincidem com os schemas do Core recebido.

## Correção proposta, antes dos ensaios

Restaurar a projeção do SDK 1.0.0 ao contrato já publicado: destination_loading contém enabled e os três destinos declarados. As configurações e o comportamento real do Core permanecem intactos. Google conserva leitura exclusivamente pelo SDK público e não lê opções privadas nem mascara erro do produtor. Novas informações de política exigem extensão administrativa/contrato aditivo próprio, fora desta correção.

Implementar um patch mínimo sobre `includes/class-f3base-medicao-contexto.php`, sem aguardar resposta, conforme autorização do dono. Testar fotografia/contrato e conversões em WordPress nativo com fixture e Core corrigido em laboratório separado. Entregar patch e arquivo corrigido ao dono para incorporação pelo Core; não instalar Core no Site-Teste nesta rodada Google. O relatório deve distinguir acompanhante original (falha reproduzida) de variante corrigida (proposta).

Aceite: contexto SDK válido, ID GA4 lido via SDK, verificações sintéticas GA4/Ads renovadas, contratos antigos aceitos, revisão e políticas reais preservadas, configuração original sem reescrita. A incorporação/versionamento/distribuição Core ficam com seu mantenedor. Google 0.25.1 não depende de novo contrato; permanece bloqueado para GA4 quando o Core presente retorna unreadable.

## Provas executadas e encaminhamento

O Core original foi reproduzido como ilegível no laboratório e no Site-Teste antes de trocar Google. A variante proposta permite as provas sintéticas GA4/Ads e o ciclo de renovação completo:57 verificações próprias, incluindo MCP0.38 e tela nativa. O relatório principal identifica os hashes e a matriz final0.25.1. Incorporação pelo Core continua pendente; nenhum arquivo Core foi alterado no Site-Teste.

Nota adicional de convivência: a renderização administrativa observou notice do Core ao atribuir estratégia defer ao alias f3base-tracking sem src. O patch fornecido trata exclusivamente o bloqueio de contrato; esse notice não foi causado pela política Google e permanece para revisão do Core.

## Aplicação e identidade

Arquivo: `includes/class-f3base-medicao-contexto.php`. SHA256 original `d99de348f72b7623a0cbb04c5d4a0d4cb15c07ec288ce94e893fb35b195bb3e9`; corrigido `3a831b0baedc404dc1c37767bfe32e9240a016a79dbe95cc3887527e5c8a51fc`. Aplicar somente sobre a base exata1.65.1. O arquivo completo corrigido e este patch estão no fonte Google em reproducao/core1651-fix/. O mantenedor Core deve incorporar, versionar e executar sua matriz antes de distribuir.

```diff
--- a/includes/class-f3base-medicao-contexto.php
+++ b/includes/class-f3base-medicao-contexto.php
@@ -101,11 +101,11 @@
     }
     private static function politica(array $v): array {
         $c=$v['f3base_consentimento'];$g=$v['f3base_google_carregamento'];$d=$v['f3base_carregamento_destinos'];$t=$v['f3base_testes'];$m=$v['f3base_comportamento'];
-        $dest=array();foreach(array('ga4','google_ads','gtm','meta','linkedin','clarity') as $name) { $dest[$name]=array('mode'=>$d[$name]??'herdar','deadline_seconds'=>$d[$name.'_teto_segundos']??5); }
+        $dest=array();foreach(array('meta','linkedin','clarity') as $name) { $dest[$name]=array('mode'=>$d[$name]??'herdar','deadline_seconds'=>$d[$name.'_teto_segundos']??5); }
         $tests=array();foreach(array('ga4','gtm','google_ads','meta','linkedin','clarity') as $name) { $tests[$name]=$t['destinos'][$name]??'suprimir'; }
         $selections=array();foreach(array('ga4','data_layer') as $target) { foreach(array('f3base_saida','f3base_rolagem_salto','f3base_clique_interno','f3base_clique_inerte') as $event) { $key=$target.'_'.$event;$selections[$key]=$v['f3base_eventos_destinos'][$key]??true; } }
         return array('consent_mode'=>$c['modo']??'legado','measurement_default'=>$c['padrao']??'negado','advertising_default'=>$c['publicidade_politica']??'exigir_decisao','gtm_category_separation_verified'=>(bool)($c['gtm_separacao_verificada']??false),
-            'google_loading'=>array('mode'=>$g['modo']??'imediato','deadline_seconds'=>$g['teto_segundos']??5),'destination_loading'=>array('enabled'=>(bool)($d['ativo']??false),'destinations'=>$dest,'clock'=>$d['referencia']??'load','accelerate_conversion'=>(bool)($d['antecipar_conversao']??false)),
+            'google_loading'=>array('mode'=>$g['modo']??'imediato','deadline_seconds'=>$g['teto_segundos']??5),'destination_loading'=>array('enabled'=>(bool)($d['ativo']??false),'destinations'=>$dest),
             'test_policy'=>array('enabled'=>(bool)($t['habilitado']??false),'exclude_reports'=>(bool)($t['excluir_relatorios']??true),'destinations'=>$tests),
             'audience_exclusions'=>array('404','editor'),'local_collection'=>(bool)($m['ligado']??false),'event_selection'=>$selections);
     }
```
