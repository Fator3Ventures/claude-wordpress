<?php
require __DIR__.'/common.php';require __DIR__.'/rpc.php';
use Fator3\McpGoogle\{Options,Documentation,Delivery,Records,McpBridge};
use Fator3\McpGoogle\Automation\{Jobs,Results};
function rpcTool018(string $tool,array $arguments): array {
 global $auth;
 $response=wp_remote_post(rest_url('mcp/wp-mcp-fator3'),['timeout'=>75,'headers'=>['Authorization'=>$auth,'Content-Type'=>'application/json','Accept'=>'application/json','Mcp-Protocol-Version'=>'2026-07-28','Mcp-Method'=>'tools/call','Mcp-Name'=>$tool],'body'=>json_encode(['jsonrpc'=>'2.0','id'=>1,'method'=>'tools/call','params'=>['_meta'=>['io.modelcontextprotocol/protocolVersion'=>'2026-07-28','io.modelcontextprotocol/clientCapabilities'=>new stdClass()],'name'=>$tool,'arguments'=>$arguments]])]);
 if(is_wp_error($response))return ['success'=>false,'error_code'=>$response->get_error_code()];
 $body=json_decode(wp_remote_retrieve_body($response),true);$data=$body['result']['structuredContent']??$body;while(isset($data['data'])&&is_array($data['data']))$data=$data['data'];return $data;
}
$credential=rpc_identityLab();$auth=$credential['auth'];Options::set(Options::ENABLED,true);wp_get_abilities();
$network=0;add_filter('pre_http_request',static function($pre,$args,$url)use(&$network){if(!str_starts_with($url,getenv('F3_LAB_URL').'/'))++$network;return $pre;},5,3);
$schema=rpcTool018('wp-mcp-ultimate-get-ability-info',['ability_name'=>'google/documentation']);verifyLab('G91-06 documented route discoverable through MCP info',str_contains(json_encode($schema),'expected_revision')&&str_contains(json_encode($schema),'limit_bytes'));
$index=rpcLab('google/documentation');verifyLab('G91-06 HTTP index identifies installed version',!empty($index['success'])&&$index['plugin_version']===expectedLab('candidate'),$index);
$compiled=require F3_MCP_GOOGLE_DIR.'includes/Data/Documentation.php';$listed=array_column($index['documents'],'document');sort($listed);$declared=array_keys($compiled);sort($declared);verifyLab('Every embedded document is listed and reachable',$listed===$declared);
$hashes=[];
foreach($index['documents'] as $doc){$offset=0;$content='';$pages=0;do{$part=rpcLab('google/documentation',['document'=>$doc['document'],'offset'=>$offset,'limit_bytes'=>65521,'expected_revision'=>$doc['revision']]);verifyLab('G91-06 document page '.$doc['document'].' '.$pages,!empty($part['success'])&&$part['revision']===$doc['revision']&&mb_check_encoding($part['content'],'UTF-8'),$part['error_code']??null);$content.=$part['content'];$offset=$part['next_offset'];++$pages;}while($offset!==null);verifyLab('G91-06 complete document hash '.$doc['document'],hash('sha256',$content)===$doc['revision']&&strlen($content)===$doc['bytes']);$hashes[$doc['document']]=['sha256'=>$doc['revision'],'pages'=>$pages,'bytes'=>strlen($content)];}
foreach(['../wp-config.php','https://example.invalid/','/etc/passwd'] as $id){$r=rpcLab('google/documentation',['document'=>$id]);verifyLab('G91-06 confines document ID '.$id,($r['error_code']??'')==='f3_google_document_missing',$r);}
$r=rpcLab('google/documentation',['document'=>'README.md','offset'=>1]);verifyLab('G91-06 continuation requires revision',($r['error_code']??'')==='f3_google_document_revision',$r);
$before=google_config_digestLab();Options::set(Options::ENABLED,false);$disabled=google_config_digestLab();$r=wp_get_ability('google/documentation')->execute([]);verifyLab('G91-06 local docs with closed Google channel',!is_wp_error($r)&&$r['success']&&$disabled===google_config_digestLab()&&$network===0);Options::set(Options::ENABLED,true);
$subscriber=wp_create_user('docs_subscriber013',bin2hex(random_bytes(16)),'docs013@example.invalid');wp_set_current_user($subscriber);
verifyLab('P13 static help requires administrator',!Documentation::read([])['success']);wp_set_current_user(1);require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($subscriber);
verifyLab('P13 installed guide and conversion contract present',isset($hashes['GUIA-'.expectedLab('candidate').'.md'],$hashes['CONVERSOES.md'],$hashes['ability-catalog.json']));
$guide=rpcLab('google/documentation',['document'=>'CONVERSOES.md']);verifyLab('P13 delivered help describes conflict and delivery limit',str_contains($guide['content'],'conflict:true')&&str_contains($guide['content'],'retryable:false')&&str_contains($guide['content'],'site-conversion-delivery/1.0.0'));
$guide=rpcLab('google/documentation',['document'=>'GUIA-'.expectedLab('candidate').'.md']);verifyLab('0.18.0 guide documents readiness, selection and descriptions',!empty($guide['success'])&&str_contains($guide['content'],'google/readiness-status')&&str_contains($guide['content'],'stream')&&str_contains($guide['content'],'português'));
$agents=rpcLab('google/documentation',['document'=>'AGENT-GUIDE.md']);verifyLab('Agent guide points to readiness first',!empty($agents['success'])&&str_contains($agents['content'],'google/readiness-status'));
$catalog=rpcLab('google/documentation',['document'=>'ability-catalog.json','limit_bytes'=>65521]);verifyLab('Installed catalog page declares 0.18.0',!empty($catalog['success'])&&str_contains($catalog['content'],'"plugin_version": "'.expectedLab('candidate').'"'));
WP_Application_Passwords::delete_application_password(1,$credential['uuid']);
finishLab('documentation018',['document_hashes'=>$hashes,'external_calls'=>$network]);
