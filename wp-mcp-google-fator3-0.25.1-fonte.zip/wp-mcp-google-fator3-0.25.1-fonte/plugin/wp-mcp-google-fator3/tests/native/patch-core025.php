<?php
/** Apply only to owned disposable lab; never to a supplied companion archive or shared site. */
require __DIR__.'/common.php';
$manifest=json_decode(file_get_contents(getenv('F3_LAB_MANIFEST')),true);$source=$manifest['inputs']['core_fix'];
$target=F3BASE_PLUGIN_DIR.'includes/class-f3base-medicao-contexto.php';
verifyLab('Core original has documented unreadable measurement snapshot',F3BASE_PLUGIN_VERSAO==='1.65.1'&&F3Base_Medicao_Contexto::snapshot()['code']==='unreadable');
$zip=new ZipArchive();$zip->open($manifest['inputs']['core']['path']);$original=$zip->getFromName('base-site-core-fator3/includes/class-f3base-medicao-contexto.php');$zip->close();
verifyLab('Core proposal applies to exact original file',hash_file('sha256',$target)===hash('sha256',$original)&&hash_file('sha256',$source['path'])===$source['sha256']);
verifyLab('Core patch confined to owned laboratory',str_starts_with(realpath($target),realpath(getenv('F3_FIXTURE_ROOT')).'/wordpress/wp-content/plugins/'));
file_put_contents($target,file_get_contents($source['path']));
verifyLab('Proposed file installed for next PHP request',hash_file('sha256',$target)===$source['sha256']);
finishLab('patch-core025',['core_variant'=>'1.65.1 plus proposed SDK projection correction','shared_site_modified'=>false]);
