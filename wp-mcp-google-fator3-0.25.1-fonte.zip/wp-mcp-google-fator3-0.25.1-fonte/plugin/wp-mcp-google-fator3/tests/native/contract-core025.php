<?php
require __DIR__.'/common.php';
$r=F3Base_Medicao_Contexto::snapshot();$f=(new ReflectionMethod('F3Base_Medicao_Contexto','fotografia'))->invoke(null);$d=$f['data'];$d['revision']=hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($d)));$d['observed_at']=gmdate('c');$response=['ok'=>true,'code'=>'ok','contract'=>F3Base_Medicao_Contexto::CONTRATO,'provider'=>F3Base_Medicao_Contexto::PRODUTOR,'data'=>$d];
$v=rest_validate_value_from_schema($response,F3Base_Medicao_Contexto::schema('snapshot'),'measurement');
verifyLab('Original Core projection violates its declared schema',$r['code']==='unreadable'&&is_wp_error($v)&&str_contains($v->get_error_message(),'ga4'));
verifyLab('Google fails closed instead of reading private Core options',Fator3\McpGoogle\CoreContext::snapshot()['code']==='unreadable'&&Fator3\McpGoogle\ConversionDelivery::measurement_id()==='');
finishLab('contract-core025',['known_companion_defect'=>true,'schema_error'=>$v->get_error_message(),'correction'=>'reproducao/core1651-fix; validated separately']);
