"""Owned Google 0.24 lab: original Core1.65.1/MCP0.38/Meta0.17/LinkedIn0.13; no public providers."""
from pathlib import Path
import argparse,importlib.util,json,subprocess,os,shutil,hashlib,zipfile
ROOT=Path(__file__).resolve().parents[1]
CASES={
 'minimum':('clean','google-only','7.1.2',['minimum018','clean','requests023','standalone014']),
 'current':('clean','mcp-first','7.1.4',['companions024','minimum018','clean','requests023','prepare-core025','contract-core025','documentation018']),
 'renewal':('clean','mcp-first','7.1.4',['companions024','patch-core025','prepare-core025','renewal025','documentation018']),
 'core':('clean','mcp-first','7.1.4',['companions024','prepare-core025','integration024','core024']),
 'upgrade':('upgrade','mcp-first','7.1.4',['patch-core025','upgrade025','minimum018','documentation018'])}
def module(name,p):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for k in ['manifest','workdir','evidence','php']:p.add_argument('--'+k,required=True,type=Path)
 p.add_argument('--case',required=True,choices=CASES);a=p.parse_args();lab=module('lab024',ROOT/'tools/lab.py');build=module('build024',ROOT/'build/build.py')
 cfg,inputs=lab.checked_inputs(a.manifest.resolve());identity=build.identity();sha=lab.sha(inputs['candidate'])
 with zipfile.ZipFile(inputs['candidate']) as z:assert {n.removeprefix('wp-mcp-google-fator3/'):z.read(n) for n in z.namelist()}==build.manifest()
 ev=a.evidence.resolve();ev.mkdir(parents=True,exist_ok=False)
 for n in build.manifest():
  if n.endswith('.php'):subprocess.run([str(a.php.resolve()),'-l',str(ROOT/n)],check=True,stdout=subprocess.DEVNULL)
 subprocess.run([str(a.php.resolve()),str(ROOT/'build/export-contracts.php'),'--check'],check=True)
 subprocess.run(['python3',str(ROOT/'build/check-docs.py')],check=True)
 origin,order,wp,suites=CASES[a.case];env=os.environ.copy();env['F3_LAB_WP_EXPECTED']=wp
 cmd=['python3',str(ROOT/'tools/lab.py'),'--manifest',str(a.manifest.resolve()),'--workdir',str(a.workdir.resolve()),'--origin',origin,'--order',order]+['tests/native/'+s+'.php' for s in suites]
 with (ev/'execution.log').open('w') as log:subprocess.run(cmd,env=env,check=True,stdout=log,stderr=subprocess.STDOUT)
 shutil.copytree(a.workdir/'evidence',ev/'native');reports={}
 for name in suites:
  f=ev/'native'/(name+'.json');d=json.loads(f.read_text());assert d['failures']==0 and d['checks']==len(d['passed']) and d['checks']>0 and d['candidate_sha256']==sha and d['wordpress']==wp
  reports[name]={'checks':d['checks'],'sha256':lab.sha(f)}
 runtime=json.loads((ev/'native/environment.json').read_text());assert runtime['processes_stopped']
 inventories={}
 for key,slug in [('candidate','wp-mcp-google-fator3'),('core','base-site-core-fator3'),('mcp','wp-mcp-fator3'),('meta','wp-mcp-meta-fator3'),('linkedin','wp-mcp-linkedin-fator3')]:
  if (a.workdir/'wordpress/wp-content/plugins'/slug).exists():
   if key=='core' and a.case in ['renewal','upgrade']:
    target=a.workdir/'wordpress/wp-content/plugins'/slug/'includes/class-f3base-medicao-contexto.php'
    assert lab.sha(target)==lab.sha(inputs['core_fix'])
    with zipfile.ZipFile(inputs['core']) as z: original=z.read(slug+'/includes/class-f3base-medicao-contexto.php')
    patched=target.read_bytes()
    try:
     target.write_bytes(original); inventories[key]=lab.installed_inventory(inputs[key],a.workdir/'wordpress/wp-content/plugins',slug)
    finally: target.write_bytes(patched)
    inventories[key]['variant']='original plus proposed measurement SDK correction'; inventories[key]['patch_sha256']=lab.sha(inputs['core_fix']);inventories[key]['exact']=False
   else:inventories[key]=lab.installed_inventory(inputs[key],a.workdir/'wordpress/wp-content/plugins',slug)
 debug=a.workdir/'wordpress/wp-content/debug.log';findings=[l for l in (debug.read_text(errors='replace').splitlines() if debug.exists() else []) if 'wp-mcp-google-fator3' in l and any(t in l for t in ['PHP Warning','PHP Notice','PHP Deprecated','PHP Fatal'])]
 assert not findings,findings
 assert build.identity()==identity and lab.sha(inputs['candidate'])==sha
 proof={'release':'0.25.1','case':a.case,'candidate_sha256':sha,'identity':identity,'checks':sum(v['checks'] for v in reports.values()),'failures':0,'reports':reports,'inputs':cfg['inputs'],'installed_inventory':inventories,'google_php_notices':findings,'runtime_files':len(build.manifest()),'php_lint_files':sum(n.endswith('.php') for n in build.manifest())}
 (ev/'validation025.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'case':a.case,'checks':proof['checks'],'passed':True}),flush=True)
if __name__=='__main__':main()
