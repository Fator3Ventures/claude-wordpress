# Validação — 0.25.1

Base exata 0.24.0. Rotas executáveis: tools/release025.py e manifests025 em reproducao. WordPress real 7.1.2 (isolado) e 7.1.4, PHP 8.3.6, MySQL 8.0.46; Core 1.65.1, MCP 0.38.0, Meta 0.17.0, LinkedIn 0.13.0 originais. Pipedrive 0.5.0 exige PHP 8.3.36, portanto sua ativação local não faz parte dessa matriz; convivência remota é separada.

Pedido 47: falha recuperada sem aviso, janela de validade, esgotamento, recuperação única, ciclos, legado, falha/incerteza no transporte, conexão, revisão, autorização, leitura sem efeitos e trava. HTTP de fornecedor e correio interceptados; não são testes de entrega postal ou de Google real. Atualização autenticada 0.24→0.25, preservação de ciphertexts, concessões, registros e rollback/reaplicação. Documentação instalada comparada integralmente.

Somente evidence/025 e o relatório externo contêm resultados desta rodada. Diretórios anteriores são históricos. PHPUnit integral depende de ferramenta externa; indisponibilidade é registrada, sem aproveitar totais antigos. Site-Teste, aceites reais pendentes e identidade final são discriminados no relatório externo.

## Compatibilidade Core 1.65.1 observada nesta rodada

O SDK de medição do Core 1.65.1 original emite campos fora do próprio schema, retorna `unreadable` e bloqueia a prova GA4. Isso foi reproduzido antes da atualização Google. A entrega fonte inclui correção mínima proposta ao mantenedor em `reproducao/core1651-fix`, validada separadamente. O Google não lê opções privadas para contornar a recusa. Acompanhante original e variante corrigida são discriminados nas evidências; o Core não foi atualizado no Site-Teste por esta rodada.
