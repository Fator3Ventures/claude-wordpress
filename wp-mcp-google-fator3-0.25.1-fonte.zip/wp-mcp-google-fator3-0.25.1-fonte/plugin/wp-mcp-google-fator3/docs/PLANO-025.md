# Plano — Google 0.25.0

31/10/2026 · nova rodada minor · base direta publicada Google 0.24.0 (SHA-256 803fa058182b9f43625352f2b4a1572a3cd4b728f8c07fd58314a9a111d41849). Alvo previsto 0.25.0; instalador ainda não gerado.

Pedido MCP Google 47: incidente imediato na tela/status, e-mail de atenção somente após falha inicial mais cinco retentativas (5, 10, 20, 40, 60 minutos) ou vencimento dentro do prazo configurável; padrão 6 horas. Retentativas de manutenção continuam a cada hora após a sequência inicial. Recuperação encerra incidente e só envia aviso uma vez quando a atenção foi aceita pelo transporte. Aceitação por wp_mail não prova entrega na caixa postal. Estado de envio incerto não autoriza repetir.

Configuração por conexão com simulação sem efeitos e aplicação vinculada à revisão/plano; ajuste de prazo não altera destino, prova, concessão ou credencial. O executor reavalia o prazo mesmo entre tentativas; status é leitura sem envio. Preservar incidentes antigos e distinguir novo ciclo de falha após recuperação. Recibos persistentes evitam duplicação e isolam conexão/destino/ciclo.

Acompanhantes considerados: Core 1.65.1, MCP 0.38.0, Meta 0.17.0 e Pipedrive 0.5.0 anexados; LinkedIn 0.13.0 da matriz anterior/estado a conferir. Sem mudança proposta no contrato de entrega Core, no transporte MCP ou nos demais leitores. Nenhum novo impacto a outro mantenedor identificado no planejamento; registrar diagnóstico/evidência no relatório principal conforme norma r5 preservada. Não editar pacotes alheios ou listas centrais.

Provas previstas: reprodução da falha na base, testes de transição/pré-expiração/esgotamento/recuperação/deduplicação/persistência/autorização/concorrência; configuração simulada, revisão obsoleta, isolamento de conexões; WordPress mínimo isolado, conjunto atual, atualização 0.24→0.25 e rollback local; documentação instalada completa via MCP. Somente Google atualizado no Site-Teste, conferindo inventário/backup/configuração antes/depois. E-mails e Google HTTP interceptados nos testes, sem destinatários reais. Fornecedor real/entrega postal permanecem aceites separados.

## Achado durante execução

Core 1.65.1 original falha na validação do próprio SDK de medição. Implementada proposta de correção da projeção ao schema publicado, sem alterar configuração ou contrato. Ver `reproducao/core1651-fix/IMPACTO-CORE-025.md`; a matriz separa Core original de variante proposta. O Core não é instalado no ambiente compartilhado nesta rodada.
