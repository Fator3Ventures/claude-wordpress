# Guia Google 0.25.1

Base direta 0.24.0. Pedido 47 entregue no próprio Google.


Pedido 47. Aplica-se à renovação automática das provas de aquisição GA4 e Google Ads, por conexão e destino. Não altera conversões por etapa nem seus contratos.

1. A primeira falha abre imediatamente o incidente de renovação, preservando a prova até sua validade normal. Não envia e-mail enquanto a sequência inicial não terminar e o vencimento estiver distante.
2. A sequência usa intervalos de 5, 10, 20, 40 e 60 minutos após falhas. A sexta falha consecutiva (inicial mais cinco retentativas) habilita um aviso de atenção. Falhas de verificação manual também integram o contador existente, mas somente o executor envia atenção. Após essa sequência, as retentativas continuam de hora em hora.
3. Independentemente do contador, uma renovação falha com prova a até `expiry_warning_hours` horas de vencer habilita o aviso. Padrão 6; inteiros de 0 a 24; zero significa no vencimento. Sem prova prévia, só o esgotamento habilita o aviso. O executor reavalia entre tentativas; na tentativa já vencida, tenta renovar primeiro e evita um aviso desnecessário quando há recuperação.
4. Recuperação resolve o incidente. Envia uma única recuperação somente se a atenção do mesmo ciclo foi aceita pelo `wp_mail`. Um novo ciclo após recuperação recebe identidade nova. Incidentes abertos antigos com atenção aceita não recebem atenção novamente; incidentes antigos já resolvidos permanecem intactos.

## Configuração com prévia

Em Ferramentas → Fator3 MCP Google → Conversões → Avisos de renovação, informe as horas, clique Simular e revise antes de Aplicar. No MCP: `google/plan-renewal-notifications` recebe `configuration:{expiry_warning_hours:6}`. Use `configuration_revision` e `plan_hash` da resposta como `expected_revision` e `expected_plan_hash` em `google/configure-renewal-notifications`, junto da configuração exata. A prévia é vinculada a conexão, usuário e valor corrente; uma prévia obsoleta é recusada. Repetir aplicação sem mudança é permitido com nova prévia.

O ajuste não altera credenciais, destinos, grants ou provas. Não consulta Google nem envia e-mail durante simulação/aplicação. O próximo passe autorizado do executor avalia incidentes abertos. Estado aparece em `conversion_delivery.<destino>.renewal.notification`; leituras não executam trabalhos. A pausa e os gates de autorização continuam vigentes.

## Entrega e persistência

Destinatário: e-mail administrativo do WordPress. Uma reserva persistente por conexão/destino/ciclo/tipo precede o envio, dentro da trava de conversões. `accepted` significa aceitação pelo transporte WordPress; não prova entrega na caixa postal. `failed` significa recusa; `unknown` inclui interrupção ou exceção. Para impedir duplicatas, não há reenvio automático após uma tentativa de correio, mesmo falha/incerta. Nessa condição confira o transporte e o incidente; retentativas da verificação continuam normalmente. Sem atenção aceita, a recuperação não envia correio.

Sem nova tabela, nova credencial ou migração. Uma opção não autoload por conexão armazena a política; incidentes e recibos usam o repositório corrente. Instalação/upgrade não materializa o padrão nem reescreve registros antigos. Rollback de arquivos para 0.24 preserva dados, mas restaura a política antiga de alerta imediato; não reverte correio enviado nem promete deduplicação entre algoritmos de versões diferentes.

Consulte [integração de acervos](CORE-ACERVOS.md), [credenciais e instalação](../README.md) e [validação](VALIDACAO.md).

## Compatibilidade Core 1.65.1 observada nesta rodada

O SDK de medição do Core 1.65.1 original emite campos fora do próprio schema, retorna `unreadable` e bloqueia a prova GA4. Isso foi reproduzido antes da atualização Google. A entrega fonte inclui correção mínima proposta ao mantenedor em `reproducao/core1651-fix`, validada separadamente. O Google não lê opções privadas para contornar a recusa. Acompanhante original e variante corrigida são discriminados nas evidências; o Core não foi atualizado no Site-Teste por esta rodada.

## Diagnóstico e seleção

Comece por `google/readiness-status`; seus códigos distinguem configuração e prova remota. O destino GA4 usa o `stream` selecionado na aba Conversões e o Measurement ID fornecido pelo SDK Core. O catálogo publica descrições em português; consulte `google/ability-catalog` e os schemas antes de executar operações.
