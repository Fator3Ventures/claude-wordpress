<?php
/** Delayed conversion renewal notices. Call observe only inside the delivery lock. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if (!defined('ABSPATH')) { exit; }

final class RenewalNotifications {
    public const OPTION = 'f3_mcp_google_conversion_renewal_notice';
    public const FAILURE_LIMIT = 6; // Initial failure plus retries after 5, 10, 20, 40 and 60 minutes.

    public static function schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['expiry_warning_hours'],
            'properties'=>['expiry_warning_hours'=>['type'=>'integer','minimum'=>0,'maximum'=>24,'default'=>6,
                'description'=>'Avisar quando a prova sem renovação estiver a até este número de horas do vencimento. Zero avisa no vencimento.']]];
    }
    public static function config() {
        $state=Options::stored(Options::storage_name(self::OPTION));
        if (!$state['success'] || ($state['exists'] && !ContractSchema::valid($state['value'],self::schema()))) {
            return new \WP_Error('f3_google_renewal_notice_read','Não foi possível ler a configuração dos avisos de renovação.');
        }
        return $state['exists']?$state['value']:['expiry_warning_hours'=>6];
    }
    private static function revision() {
        $state=Options::stored(Options::storage_name(self::OPTION));
        return $state['success']?hash('sha256',wp_json_encode([Connections::id(),$state['exists'],$state['value']])):
            new \WP_Error('f3_google_renewal_notice_read','Não foi possível ler a revisão dos avisos.');
    }
    public static function plan(array $input): array {
        if (!Options::authorized()) return Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa necessária.'));
        $proposed=$input['configuration']??null;
        if (!is_array($proposed)||!ContractSchema::valid($proposed,self::schema())) {
            return Response::fail(new \WP_Error('f3_google_renewal_notice_input','Informe expiry_warning_hours inteiro entre 0 e 24.'));
        }
        $before=self::config();$revision=self::revision();
        if (is_wp_error($before)||is_wp_error($revision)) return Response::fail(is_wp_error($before)?$before:$revision);
        $hash=hash_hmac('sha256',wp_json_encode(['renewal-notice/1',get_current_blog_id(),Connections::id(),get_current_user_id(),$revision,$proposed]),wp_salt('auth'));
        return Response::ok(['dry_run'=>true,'persisted'=>false,'changed'=>false,'would_change'=>$before!==$proposed,
            'connection_id'=>Connections::id(),'configuration_revision'=>$revision,'plan_hash'=>$hash,'before'=>$before,'configuration'=>$proposed,
            'effects'=>['Altera somente o prazo de aviso nesta conexão.','Mantém provas, concessões, destinos e tentativas automáticas.','O próximo passe do executor reavalia incidentes abertos; simular ou aplicar não envia e-mail.'],
            'google_checks_performed'=>false]);
    }
    public static function configure(array $input): array {
        return ConversionDelivery::locked(static function($lock) use($input) {
            $plan=self::plan($input);
            if (empty($plan['success'])) return $plan;
            if (!hash_equals($plan['configuration_revision'],(string)($input['expected_revision']??'')) ||
                !hash_equals($plan['plan_hash'],(string)($input['expected_plan_hash']??'')) || !Lock::owned($lock)) return Settings::conflict();
            if (!$plan['would_change']) return Response::ok(['persisted'=>true,'changed'=>false,'configuration'=>$plan['configuration'],'configuration_revision'=>$plan['configuration_revision']]);
            $saved=Options::set(self::OPTION,$plan['configuration']);
            if (empty($saved['success'])) return Response::fail(new \WP_Error('f3_google_renewal_notice_save','Não foi possível confirmar a gravação do prazo.'),['persisted'=>false]);
            return Response::ok(['persisted'=>true,'changed'=>true,'configuration'=>$plan['configuration'],'configuration_revision'=>self::revision()]);
        });
    }
    public static function incident_id(string $target): string {
        return hash('sha256',Connections::id().'|conversion_renewal|'.$target);
    }
    public static function decision(array $config,array $c,string $target,?int $now=null): array {
        $now=$now??time();$r=$c['renewal'][$target]??[];$expiry=(int)($c['verified'][$target]['expires']??0);
        $failed=($r['result']??'')==='failed';
        $due=$expiry>0?$expiry-$config['expiry_warning_hours']*HOUR_IN_SECONDS:null;
        $reason=$failed && (int)($r['failures']??0)>=self::FAILURE_LIMIT?'retry_sequence_exhausted':
            ($failed && $due!==null && $now>=$due?'proof_near_expiry':'retrying');
        return ['eligible'=>$reason!=='retrying','reason'=>$failed?$reason:'not_failed','warning_at'=>$due,
            'expiry_warning_hours'=>$config['expiry_warning_hours'],'failure_limit'=>self::FAILURE_LIMIT];
    }
    /** Read-only diagnostic, including uncertain transport outcomes. */
    public static function status(array $c,string $target): array {
        $config=self::config();
        if (is_wp_error($config)) return ['available'=>false,'error_code'=>$config->get_error_code()];
        $old=Records::get('incident',self::incident_id($target));
        return ['available'=>true]+self::decision($config,$c,$target)+[
            'attention_state'=>self::mail_state($old,'attention'),'recovery_state'=>self::mail_state($old,'recovery'),
            'transport_acceptance_is_delivery'=>false];
    }
    private static function mail_state(?array $incident,string $kind): string {
        $key=$kind==='attention'?'email_state':'recovery_email_state';
        $receipt=!empty($incident['notification_cycle'])?Records::get('mail',self::receipt_id($incident,$kind)):null;
        $state=$receipt['status']??$incident[$key]??'not_started';
        return $state==='dispatching'?'unknown':$state;
    }
    /** Called between attempts, under the delivery lock. No repeated writes while waiting. */
    public static function poll(array $c,string $target): void {
        $old=Records::get('incident',self::incident_id($target));
        if (!$old) return;
        if (($c['renewal'][$target]['result']??'')==='success') {
            if (($old['status']??'')==='open' || ($old['recovery_email_state']??'')==='pending') self::observe($target,$c,false);
            return;
        }
        if (($old['status']??'')!=='open' || !in_array($old['email_state']??'',['deferred','pending'],true)) return;
        $config=self::config();
        if (!is_wp_error($config) && self::decision($config,$c,$target)['eligible']) self::observe($target,$c,true);
    }
    /** Existing legacy accepted notices count as attention; already resolved legacy cycles stay untouched. */
    public static function observe(string $target,array $c,bool $failed,?array $result=null): void {
        $id=self::incident_id($target);$old=Records::get('incident',$id);
        if (!$failed && (!$old || (($old['status']??'')==='resolved' && empty($old['notification_cycle'])))) return;
        $new=$failed && (!$old || ($old['status']??'')!=='open');
        $incident=$new?[]:($old??[]);
        $incident=array_merge($incident,[
            'id'=>$id,'connection_id'=>Connections::id(),'event'=>'conversion_renewal',
            'resource'=>$target==='ga4'?'Google Analytics':'Google Ads','status'=>$failed?'open':'resolved',
            'code'=>'verification_renewal_failed','cause_code'=>$result['code']??$incident['cause_code']??null,
            'phase'=>$result['provider_error']['phase']??$incident['phase']??null,
            'provider_error'=>$result['provider_error']??$incident['provider_error']??null,
            'action'=>$failed?'A renovação será tentada novamente automaticamente. Confira o acesso e o destino na aba Conversões se a falha persistir.':'A verificação de conversões foi renovada.',
            'created_at'=>$incident['created_at']??time(),'updated_at'=>time(),'generation'=>($incident['generation']??0)+1,
            'notification_cycle'=>$incident['notification_cycle']??($new?bin2hex(random_bytes(16)):'legacy'),
            'email_state'=>$incident['email_state']??'deferred','recovery_email_state'=>$incident['recovery_email_state']??'not_needed',
            'task'=>'renewal_notice']);
        if ($failed) {
            $config=self::config();
            $decision=is_wp_error($config)?['eligible'=>false,'reason'=>'configuration_unreadable','warning_at'=>null]:self::decision($config,$c,$target);
            $incident['notification_reason']=$decision['reason'];$incident['warning_at']=$decision['warning_at'];
        } elseif (self::mail_state($incident,'attention')==='accepted' && $incident['recovery_email_state']==='not_needed') {
            $incident['recovery_email_state']='pending';
        }
        // No message may precede a confirmed incident write.
        if (empty(Records::put('incident',$id,$incident)['success'])) return;
        if ($failed && !empty($decision['eligible'])) self::send_once($incident,'attention');
        if (!$failed) {
            $receipt=Records::get('mail',self::receipt_id($incident,'attention'));
            $accepted=($receipt['status']??$incident['email_state'])==='accepted';
            if ($accepted) self::send_once($incident,'recovery');
        }
    }
    private static function receipt_id(array $incident,string $kind): string {
        return hash('sha256',$incident['id'].'|'.$incident['notification_cycle'].'|'.$kind);
    }
    private static function send_once(array $incident,string $kind): void {
        $key=$kind==='attention'?'email_state':'recovery_email_state';
        $id=self::receipt_id($incident,$kind);
        // Legacy dispatching is uncertain, not permission to send another message.
        if ($kind==='attention' && in_array($incident[$key]??'',['accepted','dispatching','unknown'],true)) return;
        $attempt=['status'=>'dispatching','created_at'=>time(),'incident_id'=>$incident['id'],
            'notification_cycle'=>$incident['notification_cycle'],'kind'=>$kind,'connection_id'=>Connections::id()];
        if (!Records::insert('mail',$id,$attempt)) {
            $prior=Records::get('mail',$id);
            $incident[$key]=($prior['status']??'')==='dispatching'?'unknown':($prior['status']??'unknown');
            Records::put('incident',$incident['id'],$incident);
            return;
        }
        $incident[$key]='dispatching';
        if (empty(Records::put('incident',$incident['id'],$incident)['success'])) return;
        $subject=$kind==='attention'?'Fator3 — Verificação de conversões precisa de atenção':'Fator3 — Verificação de conversões recuperada';
        $body=($kind==='attention'?'A verificação de ':'A renovação da verificação de ').$incident['resource'].' em '.home_url().".\n".$incident['action'];
        try { $attempt['status']=wp_mail(get_option('admin_email'),$subject,$body)?'accepted':'failed'; }
        catch (\Throwable $error) { $attempt['status']='unknown'; }
        $attempt['finished_at']=time();
        $saved=Records::put('mail',$id,$attempt);
        $incident[$key]=!empty($saved['success'])?$attempt['status']:'unknown';
        Records::put('incident',$incident['id'],$incident);
    }
    public static function register(): void {
        $properties=['configuration'=>self::schema()];$required=['configuration'];
        foreach (['plan-renewal-notifications'=>'plan','configure-renewal-notifications'=>'configure'] as $name=>$method) {
            if ($method==='configure') {
                foreach (['expected_revision','expected_plan_hash'] as $field) $properties[$field]=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
                $required=['configuration','expected_revision','expected_plan_hash'];
            }
            Ability::register('google/'.$name,'any',['label'=>$method==='plan'?'Simular avisos de renovação':'Aplicar avisos de renovação',
                'description'=>'Pedido 47. Prazo por conexão, de 0 a 24 horas. Simulação local; aplicação exige revisão e hash da prévia. Não envia e-mail nem consulta Google.',
                'mode'=>$method==='plan'?'read':'write','input_schema'=>['properties'=>$properties,'required'=>$required],
                'callback'=>[self::class,$method],
                'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean'],'message'=>['type'=>'string'],
                    'dry_run'=>['type'=>'boolean'],'persisted'=>['type'=>'boolean'],'changed'=>['type'=>'boolean'],'would_change'=>['type'=>'boolean'],
                    'configuration'=>self::schema(),'before'=>self::schema(),'configuration_revision'=>['type'=>'string'],
                    'plan_hash'=>['type'=>'string'],'connection_id'=>['type'=>'string'],'google_checks_performed'=>['type'=>'boolean'],
                    'effects'=>['type'=>'array','items'=>['type'=>'string']]]]]);
        }
    }
}
