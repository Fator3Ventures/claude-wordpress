<?php
/** Core delivery contract. The Core owns eligibility, the queue and deduplication. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Automation\Execution;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ConversionDelivery {
    public const CONTRACT='site-conversion-delivery/1.1.0';
    public const LEGACY_CONTRACT='site-conversion-delivery/1.0.0';
    public const CONFIG='f3_mcp_google_conversion_delivery';
    public const SECRET='f3_mcp_google_mp_secret';
    private string $target;
    private string $connection;
    private ?string $selection_error;
    private string $contract=self::CONTRACT;
    public function __construct(string $target,?string $connection=null,?string $error=null) {
        $this->target=$target;
        $this->connection=$connection??Connections::id();
        $this->selection_error=$error;
    }
    public static function init(): void {
        add_filter('f3base_conversoes_adaptador',[self::class,'adapter'],20,4);

    }
    public static function adapter($existing,$target,$contract,$context=[]) {
        if ($existing===null && $target==='google_ads' && $contract===StageConversionDelivery::CONTRACT) return StageConversionDelivery::select($context);
        if ($existing!==null || !in_array($contract,[self::CONTRACT,self::LEGACY_CONTRACT],true) || !in_array($target,['ga4','google_ads'],true)) return $existing;
        // Selection only: dispatch and verification read the Core again inside their own fences.
        $adapter=CoreContext::within_read_scope(static fn()=>self::select_connection($target));
        $adapter->contract=$contract;
        return $adapter;
    }
    private static function select_connection(string $target): self {
        $registry=Connections::registry_verified();
        if (is_wp_error($registry)) return new self($target,'default','connections_unreadable');
        $selected=[];
        foreach (array_keys($registry) as $cid) {
            $value=Connections::run($cid,static fn()=>self::read());
            $c=['success'=>!is_wp_error($value),'value'=>is_wp_error($value)?[]:$value];
            if (empty($c['success'])) return new self($target,'default','configuration_unreadable');
            // The GA4 destination of a connection is its stream: the measurement ID comes from the
            // Site Core and is the same for every connection, so it cannot select one (0.18.0).
            if (!empty($c['value']['enabled']) && !empty($c['value'][$target==='ga4'?'stream':'conversion_action'])) $selected[]=$cid;
        }
        return new self($target,$selected[0]??'default',count($selected)>1?'ambiguous_connection':null);
    }
    public static function defaults(): array {
        return ['enabled'=>false,'measurement_id'=>'','stream'=>'','customer_id'=>'','conversion_action'=>''];
    }
    public static function read() {
        $r=Options::stored(Options::storage_name(self::CONFIG));
        if (!$r['success'] || ($r['exists']&&!is_array($r['value']))) return new \WP_Error('configuration_unreadable','Configuração de conversões ilegível.');
        $c=($r['value']??[])+self::defaults();
        $c['measurement_id']=self::measurement_id();
        return $c;
    }
    public static function measurement_id(): string {
        $snapshot=CoreContext::snapshot();
        $id=$snapshot['data']['slots']['ga4']['effective']['fields']['measurement_id']??'';
        return !empty($snapshot['ok'])&&is_string($id)&&preg_match('/^G-[A-Z0-9]+$/D',$id)?$id:'';
    }
    public static function revision(): string {
        $r=Options::stored(Options::storage_name(self::CONFIG));
        return $r['success']?hash('sha256',(string)wp_json_encode($r['value']??[])):'';
    }
    private static function identity(array $c,string $target): string {
        $destination=$target==='ga4'?[$c['measurement_id'],$c['stream']]:[$c['customer_id'],$c['conversion_action']];
        return hash('sha256',wp_json_encode([get_current_blog_id(),Connections::id(),Credentials::execution_identity(),$target,$destination]));
    }
    public static function proof_revision(array $c,string $target): string {
        $parts=[self::identity($c,$target),Credentials::identity_key(),
            $target==='ga4'?Options::get_secret(self::SECRET):Options::get_secret(Options::ADS_DEVELOPER_TOKEN),
            Options::ads_api_version(),Options::get(Connections::SERVICES),Policy::current(),Recovery::generation()];
        if ($target==='google_ads') $parts[]='data-manager-v1';
        return hash_hmac('sha256',wp_json_encode($parts),wp_salt('auth'));
    }
    /** Rebind only existing, matching proofs during a validated same-principal rotation.
     * The caller commits this option with the credential under Settings' revision/rollback fence.
     * No grant, expiry, pending state or queue entry is created or extended here.
     */
    public static function rotation_values(array $candidate) {
        $stored=Options::stored(Options::storage_name(self::CONFIG));
        if (!$stored['success']||($stored['exists']&&!is_array($stored['value']))) return new \WP_Error('configuration_unreadable','Configuração de conversões ilegível.');
        if (!$stored['exists'])return [];
        $raw=$stored['value'];$c=$raw+self::defaults();$c['measurement_id']=self::measurement_id();$changed=false;
        foreach(['ga4','google_ads'] as $target){
            $old=self::proof_revision($c,$target);
            $new=Auth\Candidate::preview($candidate,static fn()=>self::proof_revision($c,$target));
            foreach(['verified','pending_verification'] as $kind){
                $entry=$raw[$kind][$target]??[];
                if (($entry['revision']??'')===$old && (int)($entry['by']??0)===self::grant($c,$target) && Options::user_authorized(self::grant($c,$target))) {
                    $raw[$kind][$target]['revision']=$new;$changed=true;
                }
            }
        }
        return $changed?[self::CONFIG=>$raw]:[];
    }
    public static function legacy_ads_eligible(string $customer): bool {
        $c=self::read();if(is_wp_error($c)||$c['customer_id']!==$customer) return false;
        $proof=$c['verified']['google_ads']??[];
        if (($proof['eligibility_source']??'')!=='administrator_attestation_and_action_read'||($proof['expires']??0)<=time()) return false;
        $parts=[self::identity($c,'google_ads'),Credentials::identity_key(),Options::get_secret(Options::ADS_DEVELOPER_TOKEN),Options::ads_api_version(),Options::get(Connections::SERVICES),Policy::current(),Recovery::generation()];
        return hash_equals(hash_hmac('sha256',wp_json_encode($parts),wp_salt('auth')),(string)($proof['revision']??''));
    }
    private static function grant(array $c,string $target): int {
        return (int)($c['granted_by_target'][$target]??$c['granted_by']??0);
    }
    private static function renewable(array $c,string $target): bool {
        $revision=self::proof_revision($c,$target);
        foreach (['verified','pending_verification'] as $kind) {
            $entry=$c[$kind][$target]??[];
            if (hash_equals($revision,(string)($entry['revision']??''))&&
                (int)($entry['by']??0)===self::grant($c,$target)) return true;
        }
        return false;
    }
    public static function local_reason(array $c,string $target): ?string {
        if (!Options::is_enabled()) return 'channel_disabled';
        if (!$c['enabled']) return 'integration_disabled';
        if (!Options::user_authorized(self::grant($c,$target))) return 'grant_revoked';
        $service=$target==='ga4'?'ga':'ads';
        if (!Connections::enabled($service)||($service==='ga'?!Options::ga_enabled():!Options::ads_enabled())) return 'service_disabled';
        if (Operation::profile($service,'write')) return 'service_read_only';
        if (is_wp_error(Credentials::current())) return 'credential_unavailable';
        if ($target==='ga4' && (!$c['measurement_id']||!$c['stream'])) return 'destination_missing';
        if ($target==='google_ads' && (!$c['customer_id']||!$c['conversion_action'])) return 'destination_missing';
        if ($target==='ga4' && Options::get_secret(self::SECRET)==='') return 'mp_secret_missing';
        if ($target==='google_ads' && Options::get_secret(Options::ADS_DEVELOPER_TOKEN)==='') return 'ads_developer_token_missing';
        $url=$target==='ga4'?GoogleClient::HOST_MP.'/mp/collect':Ads\DataManager::BASE.'/events:ingest';
        if ($target==='google_ads'&&class_exists('F3Base_Conversoes_Servidor')&&!is_callable(['F3Base_Conversoes_Servidor','reconciliar'])) return 'core_async_unsupported';
        $opts=$target==='ga4'?self::http_options($target):Ads\DataManager::options($c);
        $opts['query']=$target==='ga4'?['measurement_id'=>$c['measurement_id']]:[];
        if (Policy::check_http('POST',$url,null,$opts)) return 'resource_not_permitted';
        if (Storage\Admission::dispatch_guard()) return 'storage_or_recovery_unavailable';
        return null;
    }
    public function capabilities(): array {
        return Connections::run($this->connection,function() {
            $c=self::read();
            $reason=$this->selection_error;
            if (!in_array($this->target,['ga4','google_ads'],true)) $reason='unsupported_destination';
            if (is_wp_error($c)) {
                $reason='configuration_unreadable';
                $c=self::defaults();
            }
            if (!$reason) $reason=self::local_reason($c,$this->target);
            $proof=$c['verified'][$this->target]??[];
            if (!$reason && (!hash_equals(self::proof_revision($c,$this->target),(string)($proof['revision']??'')) || ($proof['expires']??0)<=time())) $reason='verification_required';
            return ['contract'=>$this->contract,'supported_contracts'=>$this->target==='google_ads'?[StageConversionDelivery::CONTRACT,self::CONTRACT,self::LEGACY_CONTRACT]:[self::CONTRACT,self::LEGACY_CONTRACT],
                'enhanced_leads'=>$this->target==='google_ads'?Ads\EnhancedLeads::capability($c,$reason):null,
                'ready'=>$reason===null,'destination_ref'=>'google:'.$this->target.':'.self::identity($c,$this->target),
                'reason'=>$reason??'ok','connection_id'=>$this->connection,'verified_at'=>$proof['at']??null,'verification_expires_at'=>$proof['expires']??null,
                'async_reconciliation'=>$this->target==='google_ads'?Ads\DataManager::RECONCILE:null,
                'renewal'=>self::renewal_status($c,$this->target,true),
                'verification_pending'=>!empty($c['pending_verification'][$this->target])&&self::renewable($c,$this->target),
                'evidence'=>$this->target==='ga4'?'http_received':'single_event_request_status','analytics_homologated'=>false];
            });
    }
    private static function status_capability(string $target): array {
        $selected=self::adapter(null,$target,self::CONTRACT);
        return (new self($target,null,$selected->selection_error))->capabilities();
    }
    public static function status(array $input=[]): array {
        if (!Options::authorized()) return self::fail('not_authorized');
        // One Core snapshot for the whole read-only report (0.18.0); dispatch keeps fresh reads.
        return CoreContext::within_read_scope(static fn()=>self::status_report());
    }
    public static function status_compact(): array {
        if(!Options::authorized())return self::fail('not_authorized');
        return CoreContext::within_read_scope(static function(){
            $out=['connection_id'=>Connections::id(),'google_checks_performed'=>false];
            foreach(['ga4','google_ads'] as $target) {
                $cap=self::status_capability($target);
                $out[$target]=array_intersect_key($cap,array_flip(['contract','supported_contracts','ready','reason','verified_at','verification_expires_at','enhanced_leads']));
            }
            return $out;
        });
    }
    private static function status_report(): array {
        $c=self::read();
        if (is_wp_error($c)) return self::fail($c->get_error_code());
        return Response::ok(['ok'=>true,'revision'=>self::revision(),'connection_id'=>Connections::id(),
                'config'=>array_intersect_key($c,self::defaults()),'ga4'=>self::status_capability('ga4'),
                'google_ads'=>self::status_capability('google_ads'),'mp_secret_present'=>Options::get_secret(self::SECRET)!=='',
                'ads_eligibility_source'=>$c['verified']['google_ads']['eligibility_source']??null,'core_transport'=>self::core_transport(),
                'google_checks_performed'=>false]);
    }
    public static function core_transport(): array {
        if (!is_callable(['F3Base_Conversoes_Contexto','snapshot'])) return ['ok'=>false,'code'=>'core_absent'];
        try {
            $out=\F3Base_Conversoes_Contexto::snapshot(['contract'=>'site-conversion-purposes/1.1.0']);
            $schema=require __DIR__.'/Data/CoreTransport140.php';
            return ContractSchema::valid($out,$schema)?$out:['ok'=>false,'code'=>'core_unsupported'];
        }
        catch (\Throwable $e) {
            return ['ok'=>false,'code'=>'core_unsupported'];
        }
    }
    private static function fail(string $code,array $extra=[]): array {
        return Response::fail(new \WP_Error('f3_google_delivery_'.$code,'Conversões Google: '.$code),['ok'=>false,'code'=>$code]+$extra);
    }
    public static function locked(callable $callback,bool $background=false): array {
        if (!$background&&!Options::authorized()) return self::fail('not_authorized');
        return Recovery::run(static function() use($callback) {
            $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);
            if (!$lock) return self::fail('busy');
            try {
                return $callback($lock);
            }
            finally {
                Lock::release($lock);
            }
            });
    }
    public static function configure(array $v): array {
        return self::locked(static function($lock) use($v) {
            $revision=self::revision();
            if (!$revision||!hash_equals($revision,(string)($v['expected_revision']??''))) return self::fail('revision_conflict',['conflict'=>true]);
            $c=$v['config']??null;
            if (!is_array($c)||!ContractSchema::valid($c,self::config_schema())) return self::fail('invalid_config');
            $old=self::read();
            if (is_wp_error($old)) return self::fail('configuration_unreadable');
            $c=array_replace($old,$c);
            $c['measurement_id']=self::measurement_id();
            if ($c['conversion_action'] && !str_starts_with($c['conversion_action'],'customers/'.$c['customer_id'].'/')) return self::fail('action_customer_mismatch');
            if (!empty($v['clear_mp_secret'])&&!empty($v['mp_secret'])) return self::fail('secret_action_conflict');
            if (isset($v['mp_secret'])&&(!is_string($v['mp_secret'])||strlen($v['mp_secret'])>256||preg_match('/[\x00-\x20\x7f]/',$v['mp_secret']))) return self::fail('invalid_secret');
            $secret=Options::get_secret(self::SECRET);
            $secret_changed=(!empty($v['clear_mp_secret'])&&$secret!=='')||(!empty($v['mp_secret'])&&!hash_equals($secret,$v['mp_secret']));
            $revoked=[];
            foreach (['ga4'=>['stream','measurement_id'],'google_ads'=>['customer_id','conversion_action']] as $target=>$keys) {
                $changed=$c['enabled']!==$old['enabled']||($target==='ga4'&&$secret_changed);
                foreach ($keys as $key) $changed=$changed||$c[$key]!==$old[$key];
                // An explicit save can restore a revoked grant; editing the other destination cannot transfer a valid grant.
                $changed=$changed||!Options::user_authorized(self::grant($old,$target));
                $c['granted_by_target'][$target]=$changed?get_current_user_id():self::grant($old,$target);
                if ($changed) {
                    $revoked[]=$target;
                    unset($c['verified'][$target],$c['renewal'][$target],$c['pending_verification'][$target]);
                }
            }
            // Older runtimes understand only the shared grant: fail closed if target grants differ.
            $c['granted_by']=$c['granted_by_target']['ga4']===$c['granted_by_target']['google_ads']?$c['granted_by_target']['ga4']:0;
            if ($c===$old&&!$secret_changed) return Response::ok(['ok'=>true,'persisted'=>true,'changed'=>false,'revision'=>self::revision(),'verification_required'=>false]);
            // Invalidate only affected proofs durably before replacing the secret.
            if (!Lock::owned($lock)) return self::fail('lock_lost');
            $r=Options::set(self::CONFIG,$c);
            if (empty($r['success'])) return self::fail('configuration_not_saved');
            if (!empty($v['clear_mp_secret'])||!empty($v['mp_secret'])) {
                $r=Options::set_secret(self::SECRET,!empty($v['clear_mp_secret'])?'':$v['mp_secret']);
                if (empty($r['success'])) return self::fail('secret_not_saved',['revision'=>self::revision(),'persisted'=>true,'ready'=>false]);
            }
            return Response::ok(['ok'=>true,'persisted'=>true,'revision'=>self::revision(),'verification_required'=>!empty($revoked),'revoked_targets'=>$revoked]);
            });
    }
    private static function http_options(string $target): array {
        return ['auth'=>$target!=='ga4','connector'=>$target==='ga4'?'ga':'ads',
            'operation_id'=>$target==='ga4'?'measurementprotocol.collect':'googleads.customers.uploadClickConversions',
            'mode'=>'write','retries'=>0,'timeout'=>8,'budget_seconds'=>12,'headers'=>$target==='google_ads'?Ads\AdsApi::headers():[]];
    }
    private static function mp(array $c,array $body,bool $debug) {
        $opts=self::http_options('ga4');
        $opts['query']=['measurement_id'=>$c['measurement_id'],'api_secret'=>Options::get_secret(self::SECRET)];
        return GoogleClient::request('POST',GoogleClient::HOST_MP.($debug?'/debug':'').'/mp/collect',$body,$opts);
    }
    public static function verify(array $v): array { return self::verify_internal($v,false); }
    private static function verification_error($error,string $code,string $phase,string $message='Resposta de verificação incompatível.'): array {
        return Ads\DataManager::verification_error(is_wp_error($error)?$error:new \WP_Error($code,$message,['status'=>200]),$code,$phase);
    }
    /** Every attempted verification has an executor/manual origin and an audit reference. */
    public static function verification_attempt(array $c,string $target,array $result,bool $background,array $auditContext=[]): array {
        $now=time();$old=$c['renewal'][$target]??[];$proof=$c['verified'][$target]??[];
        $history=($old['result']??'')==='success'?[]:($old['attempts']??[]);
        $count=($old['result']??'')==='success'?0:(int)($old['attempt_count']??0);
        $entry=['at'=>$now,'code'=>$result['code']??(!empty($result['ok'])?'ok':'verification_failed'),
            'origin'=>$background?'executor':'administrator','phase'=>$result['provider_error']['phase']??'complete',
            'provider_error'=>$result['provider_error']??null];
        $audit=Audit::append('conversion:verification',$auditContext['action']??$target,['origin'=>$entry['origin'],'status'=>!empty($result['ok'])?'success':'error',
            'code'=>$entry['code'],'phase'=>$entry['phase'],'http_status'=>$entry['provider_error']['http_status']??null,
            'result'=>['provider_error'=>$entry['provider_error']]]+$auditContext);
        $entry['audit_marker']=$audit['marker'];$history[]=$entry;
        $history=array_slice($history,-50);
        $expiry=(int)($proof['expires']??0);
        return ['attempts'=>$history,'attempt_count'=>$count+1,'attempts_omitted'=>max(0,$count+1-count($history)),
            'attempts_complete'=>$count+1===count($history),'audit_action'=>'conversion:verification','audit_success'=>$audit['success'],
            'cycle_started_at'=>$proof['at']??$old['cycle_started_at']??$now,
            'provider_error'=>$entry['provider_error'],'phase'=>$entry['phase'],
            'unverified_since'=>$expiry>0&&$expiry<=$now?$expiry:null,'unverified_seconds'=>$expiry>0?max(0,$now-$expiry):null];
    }
    public static function renewal_status(array $c,string $target,bool $with_notifications=false): ?array {
        $r=$c['renewal'][$target]??null;if(!is_array($r))return null;
        $expires=(int)($c['verified'][$target]['expires']??0);
        if($expires>0&&$expires<=time()){
            $r['unverified_since']=$expires;$r['unverified_seconds']=time()-$expires;
        }
        $r['proof_status']=$expires===0?'unverified':($expires>time()?'valid':'expired');
        if ($with_notifications) $r['notification']=RenewalNotifications::status($c,$target);
        return $r;
    }
    private static function verify_internal(array $v,bool $background): array {
        return self::locked(static function($lock) use($v,$background) {
            $revision=self::revision();
            if (!$revision||!hash_equals($revision,(string)($v['expected_revision']??''))) return self::fail('revision_conflict',['conflict'=>true]);
            $target=$v['target']??'';
            $c=self::read();
            if (is_wp_error($c)||!in_array($target,['ga4','google_ads'],true)) return self::fail('invalid_target');
            if ($background&&!self::renewable($c,$target)) return self::fail('verification_required');
            if ($reason=self::local_reason($c,$target)) return self::fail($reason);
            $before=self::proof_revision($c,$target);
            try { $result=Execution::run(static function() use($target,$c,$v) {
                if ($target==='ga4') {
                    $read=['connector'=>'ga','operation_id'=>'analyticsadmin.properties.dataStreams.get','mode'=>'read','retries'=>0,'scopes'=>Credentials::scopes_for('ga')];
                    $stream=GoogleClient::request('GET',GoogleClient::HOST_GA_ADMIN.'/v1beta/'.$c['stream'],null,$read);
                    if (is_wp_error($stream)||($stream['name']??'')!==$c['stream']||($stream['webStreamData']['measurementId']??'')!==$c['measurement_id']) return self::verification_error($stream,'stream_unverified','ga4_stream_read','O fluxo retornado não corresponde ao destino configurado.');
                    $read['operation_id']='analyticsadmin.properties.dataStreams.measurementProtocolSecrets.list';
                    $found=false;
                    $page='';
                    $secret=Options::get_secret(self::SECRET);
                    for($n=0;$n<10;$n++) {
                        $read['query']=$page?['pageToken'=>$page]:[];
                        $secrets=GoogleClient::request('GET',GoogleClient::HOST_GA_ADMIN.'/v1beta/'.$c['stream'].'/measurementProtocolSecrets',null,$read);
                        if (is_wp_error($secrets)) return self::verification_error($secrets,'mp_secret_unverified','ga4_secret_read');
                        foreach ($secrets['measurementProtocolSecrets']??[] as $s) if (is_string($s['secretValue']??null)&&hash_equals($secret,$s['secretValue'])) $found=true;
                        $page=$secrets['nextPageToken']??'';
                        if ($found||!$page) break;
                    }
                    if (!$found) return self::verification_error(null,'mp_secret_unverified','ga4_secret_match','O segredo configurado não foi encontrado no fluxo dentro do limite de páginas.');
                    $body=['client_id'=>'1.1','events'=>[['name'=>'generate_lead','params'=>['session_id'=>time(),'event_id'=>str_repeat('0',32)]]],'validation_behavior'=>'ENFORCE_RECOMMENDATIONS'];
                    $debug=self::mp($c,$body,true);
                    if (is_wp_error($debug)) return self::verification_error($debug,'ga4_prevalidation_failed','ga4_debug_validation');
                    if (($debug['validationMessages']??null)!==[]) {
                        $messages=$debug['validationMessages']??[];
                        $first=is_array($messages)?($messages[0]??[]):[];
                        return self::verification_error(new \WP_Error('ga4_prevalidation_failed',is_string($first['description']??null)?$first['description']:'Resposta de validação GA4 incompatível.',
                            ['status'=>200,'reason'=>$first['validationCode']??'INVALID_RESPONSE']),'ga4_prevalidation_failed','ga4_debug_validation');
                    }
                    return ['ok'=>true,'source'=>'admin_api_secret_match_and_debug'];
                }
                return Ads\DataManager::verify($c);
                },18,static function() use($lock,$revision,$c,$target,$before) {
                    return Lock::owned($lock)&&self::revision()===$revision&&!self::local_reason($c,$target)&&hash_equals($before,self::proof_revision($c,$target))?null:new \WP_Error('f3_google_verification_changed','Autorização alterada durante a verificação.');
                }); }
            catch (\Throwable $error) {
                $result=self::verification_error(new \WP_Error('verification_exception','Falha interna durante a verificação; nenhuma causa privada foi incluída.'),'verification_failed','execution');
            }
            if(is_wp_error($result))$result=self::verification_error($result,'verification_failed','execution');
            if(!is_array($result))$result=self::verification_error(null,'verification_failed','execution');
            if (!Lock::owned($lock)||self::revision()!==$revision||!hash_equals($before,self::proof_revision($c,$target))) {
                self::verification_attempt($c,$target,self::fail('revision_conflict'),$background);
                return self::fail('revision_conflict',['conflict'=>true]);
            }
            $attempt=self::verification_attempt($c,$target,$result,$background);
            if (empty($result['ok'])) {
                $retry=!empty($result['retry_verification']);
                if ($retry) $c['pending_verification'][$target]=['revision'=>$before,'by'=>self::grant($c,$target),'at'=>time()];
                $scheduled=$retry||$background||self::renewable($c,$target);
                $n=(int)($c['renewal'][$target]['failures']??0)+1;
                $c['renewal'][$target]=['last_at'=>time(),'result'=>'failed','code'=>$result['code']??'verification_failed',
                    'failures'=>$n,'next_attempt'=>$scheduled?time()+min(3600,300*(2**min(4,$n-1))):null]+$attempt;
                $saved=Options::set(self::CONFIG,$c);
                if (empty($saved['success'])) return self::fail('verification_not_saved');
                self::verification_incident($target,$result);
                if ($background) RenewalNotifications::observe($target,$c,true,$result);
                $result['revision']=self::revision();$result['retry_scheduled']=$scheduled;
                $result['audit_success']=$attempt['audit_success'];
                $result['next_attempt']=$c['renewal'][$target]['next_attempt'];
                return $result;
            }
            unset($c['pending_verification'][$target]);
            $c['verified'][$target]=['revision'=>$before,'at'=>time(),'expires'=>time()+DAY_IN_SECONDS,'by'=>self::grant($c,$target),'eligibility_source'=>$result['source']];
            foreach (['value','currency','enhanced_leads'] as $key) if (isset($result[$key])) $c['verified'][$target][$key]=$result[$key];
            if($attempt['unverified_since']!==null)$attempt['last_unverified_period']=['started_at'=>$attempt['unverified_since'],'ended_at'=>time(),'seconds'=>$attempt['unverified_seconds']];
            $attempt['unverified_since']=null;
            $c['renewal'][$target]=['last_at'=>time(),'result'=>'success','next_attempt'=>time()+12*HOUR_IN_SECONDS,'failures'=>0]+$attempt;
            $r=Options::set(self::CONFIG,$c);
            if (!empty($r['success'])) {self::verification_incident($target,null);RenewalNotifications::observe($target,$c,false);}
            return empty($r['success'])?self::fail('verification_not_saved'):Response::ok(['ok'=>true,'persisted'=>true,'revision'=>self::revision(),'verification_expires_at'=>$c['verified'][$target]['expires'],'audit_success'=>$attempt['audit_success'],'analytics_homologated'=>false]);
            },$background);
    }
    /** Called by the existing bounded executor, never by status reads. */
    public static function renew_due(): array {
        $out=[];
        foreach (['ga4','google_ads'] as $target) {
            if (Execution::remaining()<3) break;
            $c=self::read();
            if (is_wp_error($c)||empty($c['enabled'])) break;
            $proof=$c['verified'][$target]??[];
            if (!self::renewable($c,$target)||self::local_reason($c,$target)) continue;
            $renew=$c['renewal'][$target]??[];
            if (($renew['next_attempt']??(($proof['at']??time())+12*HOUR_IN_SECONDS))>time()) {
                // A threshold can arrive between supplier attempts. Revalidate under the same lock.
                self::locked(static function($lock) use($target) {
                    $current=self::read();
                    if (!is_wp_error($current) && !self::local_reason($current,$target) && self::renewable($current,$target) && Lock::owned($lock)) RenewalNotifications::poll($current,$target);
                    return ['success'=>true];
                },true);
                continue;
            }
            $r=self::verify_internal(['target'=>$target,'expected_revision'=>self::revision()],true);
            $out[$target]=['success'=>!empty($r['success']),'code'=>$r['code']??(!empty($r['success'])?'ok':'verification_failed')];
        }
        if (Execution::remaining()>3) { $stage=StageConversionDelivery::renew_due(); if($stage){$failed=(bool)array_filter($stage,static fn($r)=>empty($r['success']));$out['crm_stage']=['success'=>!$failed,'code'=>$failed?'stage_renewal_failed':'ok','actions'=>$stage];} }
        return $out;
    }
    private static function verification_incident(string $target,?array $result): void {
        $id=hash('sha256',Connections::id().'|conversion_verification|'.$target);
        $old=Records::get('incident',$id);
        if (!$old&&$result===null) return;
        $incident=['id'=>$id,'connection_id'=>Connections::id(),'event'=>'conversion_verification',
            'resource'=>$target==='ga4'?'Google Analytics':'Google Ads','status'=>$result===null?'resolved':'open',
            'code'=>$result['code']??$old['code']??'verification_failed',
            'action'=>$result['message']??$old['action']??'Confira o acesso e o destino na aba Conversões.',
            'provider_error'=>$result['provider_error']??$old['provider_error']??null,
            'phase'=>$result['provider_error']['phase']??$old['phase']??null,
            'created_at'=>$old['created_at']??time(),'updated_at'=>time(),'generation'=>($old['generation']??0)+1];
        Records::put('incident',$id,$incident);
    }
    /** Optional read-only extension. Never ingest or reconstruct a missing receipt. */
    public function reconcileBound(string $recordId,string $destinationRef): array {
        if ($this->target!=='google_ads'||!preg_match('/^[a-f0-9]{32}$/D',$recordId)||$destinationRef==='') return ['status'=>'incerto','code'=>'reconciliation_invalid'];
        return Connections::run($this->connection,function() use($recordId,$destinationRef) {
            return Recovery::run(function() use($recordId,$destinationRef) {
                $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);
                if (!$lock) return ['status'=>'incerto','code'=>'reconciliation_busy'];
                try {
                    $c=self::read();
                    if (is_wp_error($c)||self::local_reason($c,'google_ads')||!hash_equals($destinationRef,'google:google_ads:'.self::identity($c,'google_ads'))) return ['status'=>'incerto','code'=>'reconciliation_not_authorized'];
                    return Execution::run(fn()=>Ads\DataManager::reconcile($recordId,$destinationRef,$c),12,function() use($lock,$destinationRef) {
                        $now=self::read();
                        return !is_wp_error($now)&&Lock::owned($lock)&&!self::local_reason($now,'google_ads')&&hash_equals($destinationRef,'google:google_ads:'.self::identity($now,'google_ads'))?null:new \WP_Error('f3_google_reconcile_guard','Consulta suspensa.');
                    });
                } catch (\Throwable $e) {return ['status'=>'incerto','code'=>'reconciliation_unknown'];}
                finally {Lock::release($lock);}
            });
        });
    }
    private static function refused(string $code): array {
        return ['status'=>'recusado','non_delivery_proven'=>true,'code'=>$code,'retry_after'=>3600];
    }
    public function sendBound(array $p,string $destinationRef): array {
        if($destinationRef===''||strlen($destinationRef)>191) return self::refused('destination_mismatch');
        return $this->dispatch($p,$destinationRef);
    }
    public function send(array $p): array { return $this->dispatch($p,null); }
    private function dispatch(array $p,?string $destinationRef): array {
        // Core 1.41 binds the accepted destination with sendBound; send remains for older consumers.
        // There is no REST/ability dispatch endpoint. The stored administrator grant is rechecked below.
        return Connections::run($this->connection,function() use($p,$destinationRef) {
            if (empty($this->capabilities()['ready'])) return self::refused($this->target==='google_ads'&&empty($p['click_ids'])&&isset($p['user_data'])?'enhanced_leads_not_ready':'not_ready');
            return Recovery::run(function() use($p,$destinationRef) {
                $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);
                if (!$lock) return self::refused('busy');
                try {
                    if (empty($this->capabilities()['ready'])) return self::refused($this->target==='google_ads'&&empty($p['click_ids'])&&isset($p['user_data'])?'enhanced_leads_not_ready':'not_ready');
                    $c=self::read();
                    if($destinationRef!==null&&!hash_equals($destinationRef,'google:'.$this->target.':'.self::identity($c,$this->target))) return self::refused('destination_mismatch');
                    $expected=self::proof_revision($c,$this->target);
                    $dispatchRef='google:'.$this->target.':'.self::identity($c,$this->target);
                    return Execution::run(fn()=>$this->deliver($p,$c),18, function() use($lock,$c,$expected,$dispatchRef,$p) {
                        // Read the current identity, not just the configuration captured before debug/token HTTP.
                        $current=$this->capabilities();
                        if (!hash_equals($dispatchRef,$current['destination_ref'])) return new \WP_Error('f3_google_delivery_destination_mismatch','Destino de conversão alterado.',['operation_outcome'=>'not_applied']);
                        if($this->target==='google_ads'&&isset($p['user_data'])&&empty($current['enhanced_leads']['ready']))return new \WP_Error('f3_google_delivery_authorization_changed','Prontidão das conversões otimizadas alterada.',['operation_outcome'=>'not_applied']);
                        return Lock::owned($lock)&&!empty($current['ready'])&&hash_equals($expected,self::proof_revision($c,$this->target))?null:new \WP_Error('f3_google_delivery_authorization_changed','Autorização de conversão alterada.',['operation_outcome'=>'not_applied']);
                        });
                }
                catch (\Throwable $e) {
                    return ['status'=>'incerto','code'=>'dispatch_exception'];
                }
                finally {
                    Lock::release($lock);
                }
                });
            });
    }
    private static function dispatch_refusal($result): ?array {
        // Only our pre-dispatch fence proves non-delivery; provider/network errors stay uncertain.
        if (!is_wp_error($result)) return null;
        $codes=['f3_google_delivery_destination_mismatch'=>'destination_mismatch','f3_google_delivery_authorization_changed'=>'authorization_changed'];
        $code=$codes[$result->get_error_code()]??null;
        return $code!==null?self::refused($code):null;
    }
    private function deliver(array $p,array $c): array {
        if (!is_string($p['record_id']??null)||!preg_match('/^[a-f0-9]{32}$/D',$p['record_id'])||($p['event_id']??'')!==$p['record_id']) return self::refused('invalid_identity');
        if (!is_string($p['occurred_at']??null)||!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:Z|[+-]\d{2}:\d{2})$/D',$p['occurred_at'])) return self::refused('invalid_time');
        $stamp=strtotime($p['occurred_at']);
        if (!$stamp||$stamp>time()) return self::refused('invalid_time');
        if ($this->target==='ga4') {
            if (($p['measurement_id']??'')!==$c['measurement_id']||($p['event_name']??'')!=='generate_lead'||!is_string($p['client_id']??null)||!preg_match('/^[0-9]{1,20}\.[0-9]{1,20}$/D',$p['client_id'])||!is_string($p['session_id']??null)||!preg_match('/^[1-9][0-9]{0,19}$/D',$p['session_id'])||!is_int($p['timestamp_micros']??null)||intdiv($p['timestamp_micros'],1000000)!==$stamp||$stamp<time()-72*HOUR_IN_SECONDS) return self::refused('ga4_identity_or_time_invalid');
            $params=['session_id'=>$p['session_id'],'event_id'=>$p['event_id']];
            if (isset($p['engagement_time_msec'])) {
                if (!is_int($p['engagement_time_msec'])||$p['engagement_time_msec']<0) return self::refused('invalid_engagement');
                $params['engagement_time_msec']=$p['engagement_time_msec'];
            }
            $body=['client_id'=>$p['client_id'],'timestamp_micros'=>$p['timestamp_micros'],'consent'=>['ad_user_data'=>'DENIED','ad_personalization'=>'DENIED'],'events'=>[['name'=>'generate_lead','params'=>$params]]];
            $validation=self::mp($c,$body+['validation_behavior'=>'ENFORCE_RECOMMENDATIONS'],true);
            if ($refused=self::dispatch_refusal($validation)) return $refused;
            if (is_wp_error($validation)||($validation['validationMessages']??null)!==[]) return self::refused('ga4_prevalidation_failed');
            $r=self::mp($c,$body,false);
            if ($refused=self::dispatch_refusal($r)) return $refused;
            return is_wp_error($r)?['status'=>'incerto','code'=>'ga4_receipt_unknown']:['status'=>'entregue','evidence'=>'http_received','processed'=>null];
        }
        $ids=$p['click_ids']??[];
        if (!is_array($ids)||count($ids)>1||array_diff(array_keys($ids),['gclid','gbraid','wbraid'])) return self::refused('ambiguous_click_identifiers');
        $click=$ids?reset($ids):null;
        if (($ids&&(!is_string($click)||!preg_match('/^[A-Za-z0-9._~-]{1,500}$/D',$click)))||($p['order_id']??'')!==$p['record_id']||($p['ad_user_data']??'')!=='GRANTED'||$stamp<time()-90*DAY_IN_SECONDS) return self::refused('ads_payload_invalid');
        $user=[];
        if(array_key_exists('user_data',$p)) {
            $user=Ads\EnhancedLeads::normalize($p['user_data']);
            if(is_wp_error($user))return self::refused('enhanced_leads_user_data_invalid');
            if(empty($this->capabilities()['enhanced_leads']['ready']))return self::refused('enhanced_leads_not_ready');
        }
        if(!$ids&&!$user)return self::refused('ambiguous_click_identifiers');
        unset($p['user_data']);$p['click_ids']=$ids;
        return Ads\DataManager::send($p,$c,'google:google_ads:'.self::identity($c,'google_ads'),$user);
    }
    public static function config_schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['enabled'],'properties'=>[
                'enabled'=>['type'=>'boolean'],'measurement_id'=>['type'=>'string','pattern'=>'^(G-[A-Z0-9]+)?$'],
                'stream'=>['type'=>'string','pattern'=>'^(properties/[0-9]+/dataStreams/[0-9]+)?$'],
                'customer_id'=>['type'=>'string','pattern'=>'^([0-9]{10})?$'],
                'conversion_action'=>['type'=>'string','pattern'=>'^(customers/[0-9]{10}/conversionActions/[0-9]+)?$']]];
    }
    public static function status_schema(): array {
        $s=['type'=>'string'];
        $b=['type'=>'boolean'];
        $n=['type'=>['integer','null']];
        $cap=['type'=>'object','properties'=>['contract'=>$s,'ready'=>$b,'destination_ref'=>$s,'reason'=>$s,'connection_id'=>$s,'verified_at'=>$n,'verification_expires_at'=>$n,'evidence'=>$s,'analytics_homologated'=>$b,'async_reconciliation'=>['type'=>['string','null']],'renewal'=>['type'=>['object','null']],'verification_pending'=>$b]];
        $cap['properties']['supported_contracts']=['type'=>'array','items'=>$s];
        $cap['properties']['enhanced_leads']=Ads\EnhancedLeads::schema();
        $diagnostic=Ads\DataManager::diagnostic_schema();
        $cap['properties']['renewal']=['type'=>['object','null'],'properties'=>[
            'last_at'=>['type'=>'integer'],'result'=>$s,'code'=>$s,'failures'=>['type'=>'integer'],'next_attempt'=>$n,
            'provider_error'=>$diagnostic,'phase'=>$s,'attempt_count'=>['type'=>'integer'],'attempts_omitted'=>['type'=>'integer'],
            'attempts_complete'=>$b,'audit_action'=>$s,'audit_success'=>$b,'cycle_started_at'=>['type'=>'integer'],
            'proof_status'=>$s,'unverified_since'=>$n,'unverified_seconds'=>$n,'notification'=>['type'=>'object','properties'=>['available'=>$b,'eligible'=>$b,'reason'=>$s,'warning_at'=>$n,'expiry_warning_hours'=>['type'=>'integer'],'failure_limit'=>['type'=>'integer'],'attention_state'=>$s,'recovery_state'=>$s,'error_code'=>$s,'transport_acceptance_is_delivery'=>$b]],
            'last_unverified_period'=>['type'=>'object','properties'=>['started_at'=>['type'=>'integer'],'ended_at'=>['type'=>'integer'],'seconds'=>['type'=>'integer']]],
            'attempts'=>['type'=>'array','items'=>['type'=>'object','properties'=>['at'=>['type'=>'integer'],'code'=>$s,'origin'=>$s,'phase'=>$s,'provider_error'=>$diagnostic,'audit_marker'=>['type'=>['string','null']]]]]]];
        // 0.18.0: documents every field the status already returned (message, eligibility source, pending flag).
        return ['type'=>'object','properties'=>['success'=>$b,'message'=>$s,'ok'=>$b,'revision'=>$s,'connection_id'=>$s,'config'=>self::config_schema(),'ga4'=>$cap,'google_ads'=>$cap,'mp_secret_present'=>$b,'ads_eligibility_source'=>['type'=>['string','null']],'core_transport'=>['anyOf'=>[require __DIR__.'/Data/CoreTransport140.php',['type'=>'object','required'=>['ok','code'],'properties'=>['ok'=>$b,'code'=>$s]]]],'google_checks_performed'=>$b]];
    }
    public static function register(): void {
        $rev=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $definitions=[
            'conversion-delivery-status'=>['status',[],[]],
            'configure-conversion-delivery'=>['configure',['expected_revision'=>$rev,'config'=>self::config_schema(),'mp_secret'=>['type'=>'string','maxLength'=>256],'clear_mp_secret'=>['type'=>'boolean']],['expected_revision','config']],
            'verify-conversion-delivery'=>['verify',['expected_revision'=>$rev,'target'=>['type'=>'string','enum'=>['ga4','google_ads']],
                    'eligibility_receipt'=>['type'=>'object','additionalProperties'=>false,'required'=>['customer_id','conversion_action','successful_upload_confirmed','request_id'],
                        'properties'=>['customer_id'=>['type'=>'string'],'conversion_action'=>['type'=>'string'],'successful_upload_confirmed'=>['type'=>'boolean'],'request_id'=>['type'=>'string','maxLength'=>200]]]],['expected_revision','target']]
        ];
        foreach ($definitions as $name=>$d) Ability::register('google/'.$name,'any',[
                'label'=>'Conversões Google: '.$name,'description'=>'Contrato Core 1.1.0, compatível com 1.0.0. Configurar e verificar explicitamente; status local não chama fornecedor.',
                'mode'=>$d[0]==='status'?'read':'write','input_schema'=>['properties'=>$d[1],'required'=>$d[2]],
                'callback'=>[self::class,$d[0]],'output_schema'=>self::status_schema()]);
    }
    public static function screen(): void {
        Admin\ConversionScreen::render();
    }
}

/** Notice lifecycle shares the delivery lock and the same installed module. */
final class RenewalNotifications {
    public const OPTION = 'f3_mcp_google_conversion_renewal_notice';
    public const FAILURE_LIMIT = 6; // Initial failure plus retries after 5, 10, 20, 40 and 60 minutes.

    public static function schema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['expiry_warning_hours'],
            'properties'=>['expiry_warning_hours'=>['type'=>'integer','minimum'=>0,'maximum'=>24,'default'=>6,
                'description'=>'Avisar quando a prova sem renovação estiver a até este número de horas do vencimento. Zero avisa no vencimento.']]];
    }
    public static function config() {
        $state=Options::stored(Options::storage_name(self::OPTION));
        if (!$state['success'] || ($state['exists'] && !ContractSchema::valid($state['value'],self::schema()))) {
            return new \WP_Error('f3_google_renewal_notice_read','Não foi possível ler a configuração dos avisos de renovação.');
        }
        return $state['exists']?$state['value']:['expiry_warning_hours'=>6];
    }
    private static function revision() {
        $state=Options::stored(Options::storage_name(self::OPTION));
        return $state['success']?hash('sha256',wp_json_encode([Connections::id(),$state['exists'],$state['value']])):
            new \WP_Error('f3_google_renewal_notice_read','Não foi possível ler a revisão dos avisos.');
    }
    public static function plan(array $input): array {
        if (!Options::authorized()) return Response::fail(new \WP_Error('f3_google_forbidden','Permissão administrativa necessária.'));
        $proposed=$input['configuration']??null;
        if (!is_array($proposed)||!ContractSchema::valid($proposed,self::schema())) {
            return Response::fail(new \WP_Error('f3_google_renewal_notice_input','Informe expiry_warning_hours inteiro entre 0 e 24.'));
        }
        $before=self::config();$revision=self::revision();
        if (is_wp_error($before)||is_wp_error($revision)) return Response::fail(is_wp_error($before)?$before:$revision);
        $hash=hash_hmac('sha256',wp_json_encode(['renewal-notice/1',get_current_blog_id(),Connections::id(),get_current_user_id(),$revision,$proposed]),wp_salt('auth'));
        return Response::ok(['dry_run'=>true,'persisted'=>false,'changed'=>false,'would_change'=>$before!==$proposed,
            'connection_id'=>Connections::id(),'configuration_revision'=>$revision,'plan_hash'=>$hash,'before'=>$before,'configuration'=>$proposed,
            'effects'=>['Altera somente o prazo de aviso nesta conexão.','Mantém provas, concessões, destinos e tentativas automáticas.','O próximo passe do executor reavalia incidentes abertos; simular ou aplicar não envia e-mail.'],
            'google_checks_performed'=>false]);
    }
    public static function configure(array $input): array {
        return ConversionDelivery::locked(static function($lock) use($input) {
            $plan=self::plan($input);
            if (empty($plan['success'])) return $plan;
            if (!hash_equals($plan['configuration_revision'],(string)($input['expected_revision']??'')) ||
                !hash_equals($plan['plan_hash'],(string)($input['expected_plan_hash']??'')) || !Lock::owned($lock)) return Settings::conflict();
            if (!$plan['would_change']) return Response::ok(['persisted'=>true,'changed'=>false,'configuration'=>$plan['configuration'],'configuration_revision'=>$plan['configuration_revision']]);
            $saved=Options::set(self::OPTION,$plan['configuration']);
            if (empty($saved['success'])) return Response::fail(new \WP_Error('f3_google_renewal_notice_save','Não foi possível confirmar a gravação do prazo.'),['persisted'=>false]);
            return Response::ok(['persisted'=>true,'changed'=>true,'configuration'=>$plan['configuration'],'configuration_revision'=>self::revision()]);
        });
    }
    public static function incident_id(string $target): string {
        return hash('sha256',Connections::id().'|conversion_renewal|'.$target);
    }
    public static function decision(array $config,array $c,string $target,?int $now=null): array {
        $now=$now??time();$r=$c['renewal'][$target]??[];$expiry=(int)($c['verified'][$target]['expires']??0);
        $failed=($r['result']??'')==='failed';
        $due=$expiry>0?$expiry-$config['expiry_warning_hours']*HOUR_IN_SECONDS:null;
        $reason=$failed && (int)($r['failures']??0)>=self::FAILURE_LIMIT?'retry_sequence_exhausted':
            ($failed && $due!==null && $now>=$due?'proof_near_expiry':'retrying');
        return ['eligible'=>$reason!=='retrying','reason'=>$failed?$reason:'not_failed','warning_at'=>$due,
            'expiry_warning_hours'=>$config['expiry_warning_hours'],'failure_limit'=>self::FAILURE_LIMIT];
    }
    /** Read-only diagnostic, including uncertain transport outcomes. */
    public static function status(array $c,string $target): array {
        $config=self::config();
        if (is_wp_error($config)) return ['available'=>false,'error_code'=>$config->get_error_code()];
        $old=Records::get('incident',self::incident_id($target));
        return ['available'=>true]+self::decision($config,$c,$target)+[
            'attention_state'=>self::mail_state($old,'attention'),'recovery_state'=>self::mail_state($old,'recovery'),
            'transport_acceptance_is_delivery'=>false];
    }
    private static function mail_state(?array $incident,string $kind): string {
        $key=$kind==='attention'?'email_state':'recovery_email_state';
        $receipt=!empty($incident['notification_cycle'])?Records::get('mail',self::receipt_id($incident,$kind)):null;
        $state=$receipt['status']??$incident[$key]??'not_started';
        return $state==='dispatching'?'unknown':$state;
    }
    /** Called between attempts, under the delivery lock. No repeated writes while waiting. */
    public static function poll(array $c,string $target): void {
        $old=Records::get('incident',self::incident_id($target));
        if (!$old) return;
        if (($c['renewal'][$target]['result']??'')==='success') {
            if (($old['status']??'')==='open' || ($old['recovery_email_state']??'')==='pending') self::observe($target,$c,false);
            return;
        }
        if (($old['status']??'')!=='open' || !in_array($old['email_state']??'',['deferred','pending'],true)) return;
        $config=self::config();
        if (!is_wp_error($config) && self::decision($config,$c,$target)['eligible']) self::observe($target,$c,true);
    }
    /** Existing legacy accepted notices count as attention; already resolved legacy cycles stay untouched. */
    public static function observe(string $target,array $c,bool $failed,?array $result=null): void {
        $id=self::incident_id($target);$old=Records::get('incident',$id);
        if (!$failed && (!$old || (($old['status']??'')==='resolved' && empty($old['notification_cycle'])))) return;
        $new=$failed && (!$old || ($old['status']??'')!=='open');
        $incident=$new?[]:($old??[]);
        $incident=array_merge($incident,[
            'id'=>$id,'connection_id'=>Connections::id(),'event'=>'conversion_renewal',
            'resource'=>$target==='ga4'?'Google Analytics':'Google Ads','status'=>$failed?'open':'resolved',
            'code'=>'verification_renewal_failed','cause_code'=>$result['code']??$incident['cause_code']??null,
            'phase'=>$result['provider_error']['phase']??$incident['phase']??null,
            'provider_error'=>$result['provider_error']??$incident['provider_error']??null,
            'action'=>$failed?'A renovação será tentada novamente automaticamente. Confira o acesso e o destino na aba Conversões se a falha persistir.':'A verificação de conversões foi renovada.',
            'created_at'=>$incident['created_at']??time(),'updated_at'=>time(),'generation'=>($incident['generation']??0)+1,
            'notification_cycle'=>$incident['notification_cycle']??($new?bin2hex(random_bytes(16)):'legacy'),
            'email_state'=>$incident['email_state']??'deferred','recovery_email_state'=>$incident['recovery_email_state']??'not_needed',
            'task'=>'renewal_notice']);
        if ($failed) {
            $config=self::config();
            $decision=is_wp_error($config)?['eligible'=>false,'reason'=>'configuration_unreadable','warning_at'=>null]:self::decision($config,$c,$target);
            $incident['notification_reason']=$decision['reason'];$incident['warning_at']=$decision['warning_at'];
        } elseif (self::mail_state($incident,'attention')==='accepted' && $incident['recovery_email_state']==='not_needed') {
            $incident['recovery_email_state']='pending';
        }
        // No message may precede a confirmed incident write.
        if (empty(Records::put('incident',$id,$incident)['success'])) return;
        if ($failed && !empty($decision['eligible'])) self::send_once($incident,'attention');
        if (!$failed) {
            $receipt=Records::get('mail',self::receipt_id($incident,'attention'));
            $accepted=($receipt['status']??$incident['email_state'])==='accepted';
            if ($accepted) self::send_once($incident,'recovery');
        }
    }
    private static function receipt_id(array $incident,string $kind): string {
        return hash('sha256',$incident['id'].'|'.$incident['notification_cycle'].'|'.$kind);
    }
    private static function send_once(array $incident,string $kind): void {
        $key=$kind==='attention'?'email_state':'recovery_email_state';
        $id=self::receipt_id($incident,$kind);
        // Legacy dispatching is uncertain, not permission to send another message.
        if ($kind==='attention' && in_array($incident[$key]??'',['accepted','dispatching','unknown'],true)) return;
        $attempt=['status'=>'dispatching','created_at'=>time(),'incident_id'=>$incident['id'],
            'notification_cycle'=>$incident['notification_cycle'],'kind'=>$kind,'connection_id'=>Connections::id()];
        if (!Records::insert('mail',$id,$attempt)) {
            $prior=Records::get('mail',$id);
            $incident[$key]=($prior['status']??'')==='dispatching'?'unknown':($prior['status']??'unknown');
            Records::put('incident',$incident['id'],$incident);
            return;
        }
        $incident[$key]='dispatching';
        if (empty(Records::put('incident',$incident['id'],$incident)['success'])) return;
        $subject=$kind==='attention'?'Fator3 — Verificação de conversões precisa de atenção':'Fator3 — Verificação de conversões recuperada';
        $body=($kind==='attention'?'A verificação de ':'A renovação da verificação de ').$incident['resource'].' em '.home_url().".\n".$incident['action'];
        try { $attempt['status']=wp_mail(get_option('admin_email'),$subject,$body)?'accepted':'failed'; }
        catch (\Throwable $error) { $attempt['status']='unknown'; }
        $attempt['finished_at']=time();
        $saved=Records::put('mail',$id,$attempt);
        $incident[$key]=!empty($saved['success'])?$attempt['status']:'unknown';
        Records::put('incident',$incident['id'],$incident);
    }
    public static function register(): void {
        $properties=['configuration'=>self::schema()];$required=['configuration'];
        foreach (['plan-renewal-notifications'=>'plan','configure-renewal-notifications'=>'configure'] as $name=>$method) {
            if ($method==='configure') {
                foreach (['expected_revision','expected_plan_hash'] as $field) $properties[$field]=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
                $required=['configuration','expected_revision','expected_plan_hash'];
            }
            Ability::register('google/'.$name,'any',['label'=>$method==='plan'?'Simular avisos de renovação':'Aplicar avisos de renovação',
                'description'=>'Pedido 47. Prazo por conexão, de 0 a 24 horas. Simulação local; aplicação exige revisão e hash da prévia. Não envia e-mail nem consulta Google.',
                'mode'=>$method==='plan'?'read':'write','input_schema'=>['properties'=>$properties,'required'=>$required],
                'callback'=>[self::class,$method],
                'output_schema'=>['type'=>'object','properties'=>['success'=>['type'=>'boolean'],'message'=>['type'=>'string'],
                    'dry_run'=>['type'=>'boolean'],'persisted'=>['type'=>'boolean'],'changed'=>['type'=>'boolean'],'would_change'=>['type'=>'boolean'],
                    'configuration'=>self::schema(),'before'=>self::schema(),'configuration_revision'=>['type'=>'string'],
                    'plan_hash'=>['type'=>'string'],'connection_id'=>['type'=>'string'],'google_checks_performed'=>['type'=>'boolean'],
                    'effects'=>['type'=>'array','items'=>['type'=>'string']]]]]);
        }
    }
}
