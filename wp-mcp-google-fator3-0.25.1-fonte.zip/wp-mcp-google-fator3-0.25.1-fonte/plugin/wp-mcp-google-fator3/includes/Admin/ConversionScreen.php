<?php
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{ConversionDelivery as Delivery,StageConversionDelivery as Stage,Connections,Options,Admin,Automation\Execution,RenewalNotifications as Notices};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class ConversionScreen {
    public static function render(): void {
        if (!Options::authorized()) wp_die('Permissão insuficiente.');
        OperationsScreen::render(true);
        $s=Delivery::status();$c=$s['config']??Delivery::defaults();$property=explode('/',$c['stream'])[1]??'';$result=null;
        if (($_SERVER['REQUEST_METHOD']??'GET')==='POST') {
            check_admin_referer('f3-google-conversions');
            $kind=sanitize_key($_POST['action_kind']??'configure');
            if ($kind==='renewal-preview' || $kind==='renewal-apply') {
                $raw=Admin::posted('expiry_warning_hours');
                $hours=ctype_digit($raw)?(int)$raw:-1;
                $input=['configuration'=>['expiry_warning_hours'=>$hours]];
                $result=$kind==='renewal-preview'?Notices::plan($input):Notices::configure($input+['expected_revision'=>Admin::posted('revision'),'expected_plan_hash'=>Admin::posted('plan_hash')]);
            }
            elseif ($kind==='stage-grant') $result=Stage::configure(['expected_revision'=>Admin::posted('revision'),'action'=>Admin::posted('stage_action'),'enabled'=>isset($_POST['stage_enabled']),'renew_grant'=>isset($_POST['stage_renew_grant'])]);
            elseif ($kind==='stage-verify') $result=Stage::verify(['expected_revision'=>Admin::posted('revision'),'action'=>Admin::posted('stage_action')]);
            elseif ($kind==='verify') $result=Delivery::verify(['expected_revision'=>Admin::posted('revision'),'target'=>Admin::posted('target')]);
            elseif ($kind==='resources') {
                foreach(['stream','customer_id','conversion_action'] as $key) $c[$key]=Admin::posted($key);
                $property=Admin::posted('property_id');
                $result=Execution::run(static function() use($c,$property) {
                    $results=[ResourceChoices::load('ga'),ResourceChoices::load('ads')];
                    if ($property) $results[]=ResourceChoices::load('stream','properties/'.$property);
                    if ($c['customer_id']) $results[]=ResourceChoices::load('action',$c['customer_id']);
                    return ['success'=>!array_filter($results,static fn($r)=>empty($r['success'])||empty($r['complete']))];
                });
            } else {
                $config=['enabled'=>isset($_POST['enabled'])];
                foreach(['stream','customer_id','conversion_action'] as $key) $config[$key]=Admin::posted($key);
                $result=Delivery::configure(['expected_revision'=>Admin::posted('revision'),'config'=>$config,'mp_secret'=>wp_unslash($_POST['mp_secret']??''),'clear_mp_secret'=>isset($_POST['clear_mp_secret'])]);
            }
            $s=Delivery::status();if ($kind!=='resources') $c=$s['config']??$c;
        }
        if ($result) echo '<div class="notice '.(!empty($result['success'])?'notice-success':'notice-warning').'"><p>'.esc_html(!empty($result['success'])?(!empty($result['dry_run'])?'Simulação pronta; confira o prazo antes de aplicar.':'Operação concluída.'):($result['message']??'Operação não concluída. Confira o acesso e as seleções.')).'</p>'.self::diagnostic($result['provider_error']??null).'</div>';
        self::readiness_card();
        echo '<section class="f3-card"><h2>Entrega de conversões</h2><p>Autorize os destinos, verifique o acesso e selecione o transporte pelo servidor no Site Core.</p><table class="widefat striped"><thead><tr><th>Destino</th><th>Prontidão</th><th>Última verificação</th><th>Próxima renovação</th></tr></thead><tbody>';
        $reasons=['ok'=>'Pronto','integration_disabled'=>'Integração desabilitada','channel_disabled'=>'Ative o canal na aba Conexão','destination_missing'=>'Selecione um destino; configure a medição no Site Core','verification_required'=>'Verifique o destino','core_async_unsupported'=>'Instale a atualização do Core com consulta de confirmação Ads','grant_revoked'=>'Renove a autorização administrativa','mp_secret_missing'=>'Informe o segredo do fluxo de dados','service_disabled'=>'Habilite o serviço na aba Conexão','service_read_only'=>'Autorize escrita na aba Conexão','ads_developer_token_missing'=>'Informe o token de desenvolvedor na aba Conexão','resource_not_permitted'=>'Revise as permissões por recurso','ambiguous_connection'=>'Mantenha uma única conexão habilitada por destino'];
        foreach(['ga4'=>'Google Analytics','google_ads'=>'Google Ads'] as $target=>$label) {
            $v=$s[$target]??[];$renew=$v['renewal']??[];
            echo '<tr><td>'.esc_html($label).'</td><td>'.esc_html(!empty($v['verification_pending'])?(!empty($v['ready'])?'Pronto; nova validação agendada':'Aguardando nova validação automática'):($reasons[$v['reason']??'']??'Confira a conexão e as credenciais')).'</td><td>'.esc_html(!empty($v['verified_at'])?wp_date('d/m/Y H:i',$v['verified_at']):'Ainda não verificado').'</td><td>'.esc_html(!empty($renew['next_attempt'])?wp_date('d/m/Y H:i',$renew['next_attempt']):'Após a primeira verificação').'</td></tr>';
        }
        echo '</tbody></table><p>O cron renova a verificação antes de vencer. Falhas ficam na aba Incidentes. O aviso por e-mail aguarda as retentativas ou o prazo de vencimento configurado abaixo.</p></section><section class="f3-card"><h2>Destinos</h2><p><strong>ID de medição GA4:</strong> '.esc_html(Delivery::measurement_id()?:'Configure no Site Core').'. Lido do Site Core.</p><form method="post" class="f3-form">';
        self::hidden($s['revision']??'');
        echo '<p><label><input type="checkbox" name="enabled" '.checked(!empty($c['enabled']),true,false).'> Autorizar entregas pelo Core nesta conexão</label></p>';
        ResourceChoices::select('property_id','Propriedade Google Analytics',$property,ResourceChoices::items('ga'));
        ResourceChoices::select('stream','Fluxo de dados',$c['stream'],ResourceChoices::items('stream','properties/'.$property));
        ResourceChoices::select('customer_id','Conta Google Ads',$c['customer_id'],ResourceChoices::items('ads'));
        ResourceChoices::select('conversion_action','Ação de conversão importada',$c['conversion_action'],ResourceChoices::items('action',$c['customer_id']));
        echo '<p><button class="button" name="action_kind" value="resources">Consultar listas da conta</button></p><p>Após escolher outra conta ou propriedade, consulte novamente para carregar suas ações e fluxos. A ação Ads precisa ser do tipo Site — Importação de cliques, estar ativa e ter valor e moeda configurados. O envio usa o valor e a moeda lidos da ação.</p><p><label for="mp_secret">Segredo da API do fluxo de dados</label><input id="mp_secret" name="mp_secret" type="password" autocomplete="new-password"></p><p>Vazio preserva o segredo. Estado: '.(!empty($s['mp_secret_present'])?'presente':'ausente').'.</p><label><input type="checkbox" name="clear_mp_secret"> Remover segredo</label><p><button class="button button-primary" name="action_kind" value="configure">Salvar destinos e autorização</button></p></form></section><section class="f3-card"><h2>Verificar acesso</h2><p>Consulta o destino e valida um evento sem coletá-lo. Mudanças de credencial, segredo, destino ou autorização exigem nova verificação. Ads usa Data Manager; não é necessário um comprovante de envio anterior.</p><form method="post">';
        self::hidden($s['revision']??'');
        echo '<input type="hidden" name="action_kind" value="verify"><label for="f3-verify-target">Destino</label> <select id="f3-verify-target" name="target"><option value="ga4">Google Analytics</option><option value="google_ads">Google Ads</option></select> <button class="button">Verificar destino</button></form></section>';
        self::renewal_settings($result);
        self::stages();
        OperationsScreen::profiles();
    }
    private static function renewal_settings(?array $result): void {
        $config=Notices::config();
        if (is_wp_error($config)) { echo '<p>'.esc_html($config->get_error_message()).'</p>'; return; }
        echo '<section class="f3-card" id="f3-renewal-notices"><h2>Avisos da renovação</h2><p>O incidente aparece na primeira falha. O e-mail administrativo sai após cinco retentativas sem sucesso ou quando a prova chega ao prazo abaixo. As tentativas horárias continuam. A recuperação só avisa se o e-mail de atenção foi aceito pelo serviço de e-mail.</p><form method="post" class="f3-form">';
        self::hidden('');
        echo '<label for="f3-renewal-hours">Avisar quantas horas antes do vencimento?</label><input id="f3-renewal-hours" name="expiry_warning_hours" type="number" min="0" max="24" step="1" value="'.esc_attr((string)$config['expiry_warning_hours']).'" required><p>De 0 a 24 horas; zero avisa no vencimento. Padrão: 6 horas. A simulação e a aplicação não enviam e-mail.</p><button class="button" name="action_kind" value="renewal-preview">Simular alteração</button></form>';
        if (!empty($result['success']) && !empty($result['dry_run']) && isset($result['plan_hash'],$result['configuration']['expiry_warning_hours'])) {
            $hours=$result['configuration']['expiry_warning_hours'];
            echo '<p>Prazo atual: '.esc_html((string)$result['before']['expiry_warning_hours']).' h. Prazo proposto: '.esc_html((string)$hours).' h. Provas e destinos permanecem iguais.</p><form method="post">';
            self::hidden($result['configuration_revision']);
            echo '<input type="hidden" name="expiry_warning_hours" value="'.esc_attr((string)$hours).'"><input type="hidden" name="plan_hash" value="'.esc_attr($result['plan_hash']).'"><button class="button button-primary" name="action_kind" value="renewal-apply">Aplicar prazo simulado</button></form>';
        }
        echo '</section>';
    }
    private static function stages(): void {
        $status=Stage::status();
        echo '<section class="f3-card" id="f3-commercial-actions"><h2>Ações comerciais por etapa</h2><p>Autorize cada ação do Site Core separadamente. Use uma ação exclusiva por etapa; a ação de aquisição não pode ser reutilizada. O envio comercial usa valor zero em BRL.</p><table class="widefat striped"><thead><tr><th>Ação</th><th>Prontidão</th><th>Motivo</th></tr></thead><tbody>';
        foreach((array)($status['actions']??[]) as $action=>$cap){$entry=$cap['actions'][$action]??[];echo '<tr><td>'.esc_html($action).'</td><td>'.esc_html(!empty($entry['ready'])?'Pronta':'Bloqueada').'</td><td>'.esc_html($entry['reason']??'indisponível').'</td></tr>';}
        echo '</tbody></table><form method="post" class="f3-form">';self::hidden($status['revision']??'');
        echo '<p><label for="f3-stage-action">Recurso completo da ação Google Ads</label><input id="f3-stage-action" name="stage_action" type="text" maxlength="120" placeholder="customers/1234567890/conversionActions/222" required></p><p><label><input name="stage_enabled" type="checkbox"> Autorizar esta ação para etapas comerciais do Site Core</label></p><p><label><input name="stage_renew_grant" type="checkbox"> Renovar a concessão e invalidar referências anteriores</label></p><button class="button" name="action_kind" value="stage-grant">Salvar concessão</button> <button class="button" name="action_kind" value="stage-verify">Verificar ação</button></form><p>Salvar sem autorização marcada revoga a ação. Verificar consulta a conta e valida o destino sem coletar conversões. As provas são renovadas pelo executor; resultados de envio incertos exigem consulta do recibo, sem reenvio. Consulte o guia desta versão para configuração e reconciliação.</p></section>';
    }
    public static function diagnostic($diagnostic): string {
        if (!is_array($diagnostic)) return '';
        $items=[];
        foreach (['http_status'=>'HTTP','status'=>'Estado Google','reason'=>'Motivo','message'=>'Mensagem Google'] as $key=>$label)
            if (!empty($diagnostic[$key])) $items[]=$label.': '.$diagnostic[$key];
        foreach ($diagnostic['field_violations']??[] as $v) $items[]='Campo: '.($v['field']??'').' · '.($v['reason']??'').' · '.($v['message']??'');
        return '<ul class="f3-provider-diagnostic"><li>'.implode('</li><li>',array_map('esc_html',$items)).'</li></ul>';
    }
    private static function hidden(string $revision): void {
        wp_nonce_field('f3-google-conversions');
        echo '<input type="hidden" name="connection_id" value="'.esc_attr(Connections::id()).'"><input type="hidden" name="revision" value="'.esc_attr($revision).'">';
    }
    /** Local verdict of google/readiness-status at the top of the screen (0.18.0). */
    private static function readiness_card(): void {
        $r=\Fator3\McpGoogle\Readiness::read([]);
        if (empty($r['success'])) return;
        $names=['ready'=>'Pronta','attention'=>'Requer atenção','blocked'=>'Bloqueada'];
        echo '<section class="f3-card" id="f3-readiness" data-state="'.esc_attr($r['state']).'"><h2>Prontidão operacional</h2><p><strong>'.esc_html($names[$r['state']]??$r['state']).'</strong>. Leitura local da conexão, sem consulta ao Google.</p>';
        if (!empty($r['actions'])) {
            echo '<ol>';
            foreach ($r['actions'] as $action) echo '<li>'.esc_html($action).'</li>';
            echo '</ol>';
        }
        echo '<p class="description">A mesma leitura está em google/readiness-status.</p></section>';
    }
}
