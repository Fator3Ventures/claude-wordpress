<?php
/**
 * Roteador do servidor embutido da bancada.
 *
 * `php -S` serve arquivo que existe e devolve 404 para o resto. O WordPress
 * precisa do contrário: endereço que não é arquivo tem de chegar ao `index.php`
 * para que `template_redirect` rode — e é exatamente ali que moram as rotas
 * virtuais que esta bancada mede (`/llms.txt`, `/llms-full.txt`, os redirects
 * declarados). Sem este roteador, `/servicos/` devolveria 404 do servidor e o
 * laço de redirecionamento que a bancada existe para acusar nunca apareceria.
 *
 * @package F3Base\Suite
 */

declare( strict_types = 1 );

$f3b_raiz    = (string) getenv( 'F3BASE_DOCROOT' );
$f3b_caminho = (string) parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '/' ), PHP_URL_PATH );
$f3b_alvo    = $f3b_raiz . urldecode( $f3b_caminho );

/* Arquivo real (tema, asset, wp-admin/*.php) é servido pelo próprio php -S. */
if ( '/' !== $f3b_caminho && is_file( $f3b_alvo ) ) {
	return false;
}

if ( is_dir( $f3b_alvo ) && is_file( rtrim( $f3b_alvo, '/' ) . '/index.php' ) ) {
	require rtrim( $f3b_alvo, '/' ) . '/index.php';
	return true;
}

require $f3b_raiz . '/index.php';
return true;
