<?php
/** Fotografia operacional comum à administração, abilities, CLI e Saúde do Site. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Saude {
	public static function iniciar(): void {
		add_filter( 'site_status_tests', array( __CLASS__, 'testes_do_site' ) );
		add_filter( 'debug_information', array( __CLASS__, 'informacoes' ) );
	}

	/** Nenhuma sonda, reparação, migração ou agendamento ocorre nesta consulta. */
	public static function resumo(): array {
		$modulos = array();
		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			$estado    = $modulo->estado();
			$modulos[] = array(
				'id'        => $modulo->id(),
				'nome'      => $modulo->nome(),
				'estado'    => $estado['estado'],
				'motivo'    => $estado['motivo'],
				'atividade' => $modulo->atividade(),
			);
		}
		return array(
			'versao'        => F3BASE_PLUGIN_VERSAO,
			'consultado_em' => time(),
			'modulos'       => $modulos,
			'agenda'        => F3Base_Operacao::agenda(),
			'fila'          => F3Base_Capi_Fila::resumo(),
			'cache'         => F3Base_Cache_Pagina::resumo(),
			'publicacao'    => F3Base_Llms::responsaveis(),
			'escopo'        => 'estado_e_evidencias_existentes; consulta_nao_executa_acoes',
		);
	}

	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		wp_register_ability(
			'f3base/saude-ler',
			array(
				'label'               => 'Estado operacional do Core',
				'description'         => 'Consulta saúde, agenda e evidências existentes, sem executar verificações ou correções.',
				'category'            => 'f3base',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
				'permission_callback' => static fn() => current_user_can( 'manage_options' ),
				'execute_callback'    => static fn() => self::resumo(),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	public static function testes_do_site( array $testes ): array {
		$testes['direct']['f3base_estado'] = array(
			'label' => 'Estado do Base Site Core',
			'test'  => array( __CLASS__, 'teste' ),
		);
		return $testes;
	}

	public static function teste(): array {
		$r          = self::resumo();
		$pendencias = array();
		foreach ( $r['modulos'] as $m ) {
			if ( 'degradado' === $m['estado'] ) {
				$pendencias[] = $m['nome'] . ': ' . $m['motivo']; }
		}
		foreach ( $r['agenda'] as $a ) {
			if ( $a['atrasado'] && $a['registrada'] ) {
				$pendencias[] = $a['rotulo'] . ': execução atrasada.'; }
		}
		$html = '<p>A consulta usa o estado e as evidências existentes do Core.</p>';
		if ( $pendencias ) {
			$html .= '<ul>';
			foreach ( $pendencias as $p ) {
				$html .= '<li>' . esc_html( $p ) . '</li>';
			} $html .= '</ul>'; }
		return array(
			'label'       => $pendencias ? 'O Core tem pendências operacionais' : 'O Core não informa degradação nos módulos',
			'status'      => $pendencias ? 'recommended' : 'good',
			'badge'       => array(
				'label' => 'Base Site Core',
				'color' => 'blue',
			),
			'description' => $html,
			'actions'     => '<a href="' . esc_url(
				add_query_arg(
					array(
						'page' => F3Base_Admin_Tela::SLUG,
						'aba'  => 'tecnica',
					),
					admin_url( 'admin.php' )
				)
			) . '">Ver estado técnico do Core</a>',
			'test'        => 'f3base_estado',
		);
	}

	public static function informacoes( array $informacoes ): array {
		$agenda                = self::agenda_texto();
		$informacoes['f3base'] = array(
			'label'       => 'Base Site Core',
			'description' => 'Estado existente. Não inclui tokens, corpos de leads ou identificadores de visitantes.',
			'fields'      => array(
				'versao' => array(
					'label' => 'Versão',
					'value' => F3BASE_PLUGIN_VERSAO,
				),
				'agenda' => array(
					'label' => 'Tarefas',
					'value' => $agenda,
				),
			),
		);
		return $informacoes;
	}

	private static function agenda_texto(): string {
		$r = array();
		foreach ( F3Base_Operacao::agenda() as $a ) {
			$r[] = $a['rotulo'] . ': ' . $a['codigo'];
		} return implode( '; ', $r );
	}
}
