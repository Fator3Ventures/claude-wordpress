<?php
/**
 * Módulo llms-txt-reserva.
 *
 * Rota virtual `/llms.txt` servida quando ela é a responsável pelo endereço. A
 * precedência é declarada e medida em `F3Base_Llms::veredito_do_emissor()`:
 * arquivo físico na raiz vence, emissor concorrente medido vem em seguida, e só
 * então esta rota.
 *
 * Registrada em `template_redirect` com prioridade 0, antes de
 * `redirect_canonical`, que acrescentaria barra à rota virtual e devolveria 301
 * para `/llms.txt/`.
 *
 * A SELEÇÃO tem dois eixos, e o modo declarado diz quais valem: a CURADORIA,
 * que é a lista escolhida por quem entrega o site, e a ENUMERAÇÃO do conteúdo
 * publicado, que é o que mantém o arquivo vivo depois que o implantador dorme.
 * A regra de seleção, de ordem e de descrição mora em `F3Base_Llms` e é a mesma
 * que o `/llms-full.txt` usa.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reserva do /llms.txt.
 */
final class F3Base_Modulo_Llms_Txt_Reserva extends F3Base_Modulo {

	/**
	 * Caminho público do recurso.
	 */
	public const CAMINHO = '/llms.txt';

	/**
	 * Palavras do resumo de última instância.
	 */
	public const PALAVRAS_DO_RESUMO = 28;

	/**
	 * Teto de itens enumerados. Arquivo de índice é índice, não catálogo.
	 */
	public const TETO_DE_ITENS = 200;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'llms-txt-reserva';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Reserva do llms.txt', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Serve /llms.txt por rota virtual quando ela é a responsável pelo endereço: arquivo físico na raiz vence, emissor concorrente medido vem depois, e só então esta rota. A lista junta a seleção curada da configuração com a enumeração do conteúdo publicado, conforme o modo declarado, e exclui o que está em noindex. Registrada em template_redirect prioridade 0 para não receber a barra final de redirect_canonical.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_servir',
				'prioridade' => 0,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$emissor = self::emissor();
		$sitemap = F3Base_Llms::sitemap_medido();

		return array(
			array(
				'rotulo'   => __( 'Endereço público sem outro dono', 'f3base' ),
				'presente' => (bool) $emissor['serve'],
				'detalhe'  => (string) $emissor['motivo'],
			),
			array(
				'rotulo'   => __( 'Sitemap que o rodapé do arquivo aponta', 'f3base' ),
				'presente' => '' !== (string) $sitemap['url'],
				'detalhe'  => '' !== (string) $sitemap['url']
					? sprintf(
						/* translators: 1: endereço do sitemap, 2: quem o serve. */
						__( 'servido em %1$s pelo %2$s: é este endereço que o arquivo imprime.', 'f3base' ),
						(string) $sitemap['url'],
						(string) $sitemap['fonte']
					)
					: __( 'nenhum sitemap servido neste site: a seção é OMITIDA do arquivo, em vez de apontar um endereço que ninguém responde.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LLMS, __( 'Última resposta pela rota reserva', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( ! F3Base_Llms::site_publico() ) {
			return $this->inativo( 'Publicação de llms suspensa: a visibilidade do site está desestimulando a indexação.' ); }
		if ( empty( $config['ligado'] ) ) {
			return $this->inativo(
				__( 'recurso llms.txt desligado na configuração de bots de IA: nenhum hook, nenhuma rota e nenhuma superfície pública.', 'f3base' )
			);
		}

		$emissor = self::emissor();

		if ( ! $emissor['serve'] ) {
			return $this->ativo( (string) $emissor['motivo'] );
		}

		// Diagnóstico não enumera o acervo nem consulta o SEO de cada post. A seleção
		// efetiva é validada ao servir ou gerar uma prévia explícita da publicação.
		return $this->ativo(
			sprintf(
				/* translators: %s: modo de seleção configurado. */
				__( 'rota habilitada pelo Core, com seleção %s. Conteúdo e quantidade serão verificados na prévia ou na entrega; consulte a evidência HTTP datada para confirmar a publicação.', 'f3base' ),
				$this->modo()
			)
		);
	}

	/**
	 * Serve a rota quando ela é a responsável pelo endereço.
	 *
	 * @return void
	 */
	public function talvez_servir(): void {
		if ( ! self::requisicao_de( self::CAMINHO ) ) {
			return;
		}

		if ( ! F3Base_Llms::site_publico() || ! self::emissor()['serve'] ) {
			return;
		}

		$config = $this->config();
		if ( empty( $config['ligado'] ) ) {
			return; }
		$itens    = $this->itens();
		$conteudo = F3Base_Modulo_Cache_Publico::lembrar( 'llms-indice:' . hash( 'sha256', wp_json_encode( array( $itens, $config ) ) ), fn() => $this->montar( $itens ) );

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMO_LLMS,
			array(
				'bytes'     => strlen( $conteudo ),
				'itens'     => count( $itens ),
				'respondeu' => F3Base_Llms::QUEM_NOSSA_ROTA,
			)
		);

		self::responder( $conteudo, $this->config(), F3Base_Llms::QUEM_NOSSA_ROTA );
	}

	/**
	 * Emite a resposta de texto puro, com os cabeçalhos declarados.
	 *
	 * O `X-Robots-Tag: noindex` SÓ SAI quando a configuração pede. O arquivo
	 * é um recurso de descoberta. `noindex` regula inclusão em índices,
	 * não a permissão de acessar ou usar o texto por um agente. `nocache_headers()` sai nos dois
	 * casos — o conteúdo muda quando o site muda.
	 *
	 * `X-F3Base-Mecanismo` DIZ QUEM RESPONDEU, e por isso ele é argumento e não
	 * literal. Até a 1.0.1 as DUAS rotas — o índice curto e o texto integral —
	 * saíam carimbadas `rota-reserva`, e quem depurava pelo cabeçalho não tinha
	 * como distinguir uma resposta da outra: o mesmo carimbo em dois endereços
	 * diferentes é um cabeçalho que não mede nada.
	 *
	 * @param string              $conteudo  Corpo servido.
	 * @param array<string,mixed> $config    Configuração normalizada.
	 * @param string              $mecanismo Quem respondeu, para o cabeçalho.
	 * @return void
	 */
	/** Falha explícita: nunca identifica um corpo parcial como documento integral. */
	public static function responder_incompleto( string $motivo ): void {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); }
		if ( ! headers_sent() ) {
			status_header( 503 );
			nocache_headers();
			header( 'Content-Type: text/plain; charset=utf-8' );
			header( 'X-F3Base-Conversao: incompleta' );
			header( 'X-Robots-Tag: noindex' ); }
		if ( 'HEAD' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) {
			echo "Documento indisponível: conversão editorial incompleta.\n" . sanitize_text_field( $motivo ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Resposta text/plain; escape HTML alteraria o documento de texto.
		}
		exit;
	}

	public static function responder( string $conteudo, array $config, string $mecanismo = F3Base_Llms::QUEM_NOSSA_ROTA, string $tipo = 'text/plain' ): void {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); }
		if ( ! headers_sent() ) {
			status_header( 200 );
			header( 'Content-Type: ' . ( 'text/markdown' === $tipo ? 'text/markdown' : 'text/plain' ) . '; charset=utf-8' );

			if ( empty( $config['indexavel'] ) ) {
				header( 'X-Robots-Tag: noindex' );
			}

			header( 'X-F3Base-Mecanismo: ' . ( '' !== $mecanismo ? $mecanismo : F3Base_Llms::QUEM_NOSSA_ROTA ) );
			nocache_headers();
			header( 'Cache-Control: no-cache, max-age=0, must-revalidate' );
			$etag = '"' . hash( 'sha256', $conteudo ) . '"';
			header( 'ETag: ' . $etag );
			$recebido = wp_unslash( (string) ( $_SERVER['HTTP_IF_NONE_MATCH'] ?? '' ) );
			if ( in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) && ( '*' === trim( $recebido ) || in_array( $etag, array_map( static fn( $v ) => preg_replace( '~^W/~', '', trim( $v ) ), explode( ',', $recebido ) ), true ) ) ) {
				status_header( 304 );
				exit; }
		}

		if ( 'HEAD' !== ( $_SERVER['REQUEST_METHOD'] ?? 'GET' ) ) {
			echo $conteudo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Resposta text/plain ou text/markdown; escape HTML alteraria o documento editorial.
		}
		exit;
	}

	/**
	 * A PRIMEIRA FRASE do arquivo, com a precedência que a tela promete.
	 *
	 * A ORDEM É A DA TELA, e ela estava invertida no código até a 1.0.1: o campo
	 * "Primeira frase do arquivo" (`introducao`) diz, em voz alta, que ela é a
	 * primeira frase que um leitor automático encontra e que, vazia, o site usa
	 * a apresentação abaixo. O código lia `apresentacao` primeiro e só caía para
	 * `introducao` quando ela estivesse vazia — quem preenchesse os dois campos
	 * via publicado o que a tela dizia ser a reserva.
	 *
	 * A `tagline` fecha a cadeia, e só ela é medida do WordPress: é a descrição
	 * cadastrada nas configurações gerais, que serve e foi escrita para outra
	 * finalidade — o que a tela também diz.
	 *
	 * @param array<string,mixed> $config  Configuração normalizada.
	 * @param string              $tagline Descrição cadastrada no WordPress.
	 * @return string Frase, ou vazio quando as três estão vazias.
	 */
	public static function primeira_frase( array $config, string $tagline = '' ): string {
		$introducao = isset( $config['introducao'] ) ? trim( (string) $config['introducao'] ) : '';

		if ( '' !== $introducao ) {
			return $introducao;
		}

		$apresentacao = isset( $config['apresentacao'] ) ? trim( (string) $config['apresentacao'] ) : '';

		if ( '' !== $apresentacao ) {
			return $apresentacao;
		}

		return trim( $tagline );
	}

	/**
	 * PRECEDÊNCIA do endereço público, medida. Ponto único para os dois módulos.
	 *
	 * @return array{serve:bool,quem:string,motivo:string}
	 */
	public static function emissor(): array {
		$fisico      = self::arquivo_fisico();
		$concorrente = F3Base_Llms::concorrente_de_llms();

		return F3Base_Llms::veredito_do_emissor(
			'' !== $fisico,
			$fisico,
			(bool) $concorrente['ligado'],
			(string) $concorrente['nome']
		);
	}

	/**
	 * A requisição atual é de um caminho público do recurso?
	 *
	 * @param string $caminho Caminho declarado, com barra inicial.
	 * @return bool
	 */
	public static function requisicao_de( string $caminho ): bool {
		if ( ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) ) {
			return false; }
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $uri ) {
			return false;
		}

		$partes = wp_parse_url( $uri );
		$atual  = is_array( $partes ) && isset( $partes['path'] ) ? (string) $partes['path'] : '';
		$atual  = rtrim( $atual, '/' );

		if ( '' === $atual ) {
			return false;
		}

		$casa    = wp_parse_url( home_url( '/' ) );
		$prefixo = is_array( $casa ) && isset( $casa['path'] ) ? rtrim( (string) $casa['path'], '/' ) : '';

		return $atual === $prefixo . $caminho || $atual === $caminho;
	}

	/**
	 * Caminho do arquivo físico, quando existir.
	 *
	 * @return string Caminho absoluto, ou vazio.
	 */
	public static function arquivo_fisico(): string {
		return F3Base_Llms::arquivo_publico( 'llms.txt' );
	}

	/**
	 * Monta o índice curto.
	 *
	 * @param array<int,array<string,mixed>> $itens Itens já selecionados e ordenados.
	 * @return string
	 */
	public function montar( array $itens ): string {
		$config = $this->config();

		$nome    = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$tagline = wp_specialchars_decode( (string) get_bloginfo( 'description' ), ENT_QUOTES );

		$linhas   = array();
		$linhas[] = '# ' . ( F3Base_Llms::texto_markdown( $nome ) ?: 'Site' );
		$linhas[] = '';

		/*
		 * A FRASE DE ABERTURA vem antes da lista porque é ela que diz o que o
		 * site é, para quem e com que oferta. Sem ela o arquivo é uma lista de
		 * links, e o leitor automático tem de inferir o posicionamento das
		 * páginas. Qual das três é a frase, e em que ordem, é a regra de
		 * `primeira_frase()` — a mesma que a tela descreve.
		 */
		$frase = self::primeira_frase( $config, $tagline );

		if ( '' !== $frase ) {
			$linhas[] = '> ' . F3Base_Llms::texto_markdown( $frase );
			$linhas[] = '';
		}

		$secoes = array(
			'page' => array(),
			'post' => array(),
		);

		foreach ( $itens as $item ) {
			$md = F3Base_Modulo_Llms_Markdown::url_do_item( $item );
			if ( '' !== $md ) {
				$item['markdown_url'] = $md; }
			$linha = F3Base_Llms::linha_de_item( $item );

			if ( '' === $linha ) {
				continue;
			}

			$tipo              = 'post' === (string) ( $item['tipo'] ?? 'page' ) ? 'post' : 'page';
			$secoes[ $tipo ][] = $linha;
		}

		if ( array() !== $secoes['page'] ) {
			$linhas[] = '## ' . __( 'Páginas', 'f3base' );
			$linhas   = array_merge( $linhas, $secoes['page'] );
			$linhas[] = '';
		}

		if ( array() !== $secoes['post'] ) {
			$linhas[] = '## ' . __( 'Artigos', 'f3base' );
			$linhas   = array_merge( $linhas, $secoes['post'] );
			$linhas[] = '';
		}

		$sitemap = F3Base_Llms::sitemap_medido();

		if ( '' !== (string) $sitemap['url'] ) {
			$linhas[] = '## ' . __( 'Mapa do site', 'f3base' );
			$linhas[] = '- [' . __( 'Sitemap', 'f3base' ) . '](' . F3Base_Llms::url_markdown( (string) $sitemap['url'] ) . ')';
			$linhas[] = '';
		}

		if ( ! empty( $config['ligado'] ) && ! empty( $config['full'] ) && $itens && F3Base_Modulo_Llms_Full_Txt::emissor()['serve'] ) {
			$linhas[] = '## Optional';
			$linhas[] = '- [Texto integral](' . home_url( F3Base_Modulo_Llms_Full_Txt::CAMINHO ) . '): o conteúdo integral em Markdown das páginas listadas acima';
			$linhas[] = '';
		}

		return implode( "\n", $linhas ) . "\n";
	}

	/**
	 * Itens selecionados e ordenados. Ponto único para os dois módulos.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function itens(): array {
		return self::selecao( $this->config() );
	}

	/**
	 * A SELEÇÃO inteira, a partir da configuração normalizada.
	 *
	 * @param array<string,mixed> $config Configuração normalizada.
	 * @return array<int,array<string,mixed>>
	 */
	public static function selecao( array $config ): array {
		if ( ! F3Base_Llms::site_publico() ) {
			return array(); }
		$itens = F3Base_Modulo_Cache_Publico::lembrar( 'llms-selecao:' . hash( 'sha256', wp_json_encode( array( $config, get_post_types( array( 'public' => true ), 'names' ) ) ) ), static fn() => self::montar_selecao( $config ) );
		// Revalida cada conteúdo local; cache nunca autoriza divulgar um post que perdeu acesso público.
		return array_values(
			array_filter(
				$itens,
				static function ( $item ) {
					$id = (int) ( $item['id'] ?? 0 );
					if ( ! $id ) {
						return true; }
					$p = get_post( $id );
					return $p && 'publish' === $p->post_status && '' === $p->post_password && ! F3Base_Modulo_Noindex_Honrado::post_e_noindex( $id );
				}
			)
		);
	}
	public static function selecao_sem_cache( array $config ): array {
		return self::montar_selecao( $config ); }
	private static function montar_selecao( array $config ): array {
		if ( ! F3Base_Llms::site_publico() ) {
			return array(); }
		$modo = isset( $config['modo'] ) ? (string) $config['modo'] : F3Base_Llms::MODO_MISTO;

		$curados = F3Base_Llms::modo_cura( $modo ) ? F3Base_Llms::validar_curados( self::curados( $config ) ) : array();

		$enumerados = array();

		if ( F3Base_Llms::modo_enumera( $modo ) ) {
			$declarados = isset( $config['tipos'] ) && is_array( $config['tipos'] ) ? array_map( 'strval', $config['tipos'] ) : array();
			$validos    = F3Base_Llms::tipos_validos( $declarados, array_values( (array) get_post_types( array( 'public' => true ), 'names' ) ) );

			$enumerados = F3Base_Llms::enumerar( $validos['tipos'], self::PALAVRAS_DO_RESUMO, self::TETO_DE_ITENS );
		}

		$selecionado = F3Base_Llms::selecionar( $curados, $enumerados, self::excluidos_por_declaracao( $config ) );

		// Dedupe adicional por URL cobre referências livres sem ID. O teto inclui curadoria.
		$vistos = array();
		$itens  = array();
		foreach ( F3Base_Llms::ordenar( $selecionado['itens'] ) as $item ) {
			$url = F3Base_Llms::url_markdown( (string) ( $item['url'] ?? '' ) );
			if ( '' === $url || isset( $vistos[ $url ] ) ) {
				continue; }
			$vistos[ $url ] = true;
			$itens[]        = $item;
			if ( count( $itens ) >= self::TETO_DE_ITENS ) {
				break; }
		}
		return $itens;
	}

	/**
	 * Os itens da CURADORIA, na ordem declarada, com a página inicial marcada.
	 *
	 * @param array<string,mixed> $config Configuração normalizada.
	 * @return array<int,array<string,mixed>>
	 */
	private static function curados( array $config ): array {
		$home  = (int) get_option( 'page_on_front', 0 );
		$itens = array();

		$livres = isset( $config['livres'] ) && is_array( $config['livres'] ) ? $config['livres'] : array();

		foreach ( $livres as $item ) {
			if ( ! is_array( $item ) || empty( $item['url'] ) ) {
				continue;
			}

			$id = (int) ( $item['id'] ?? 0 );

			$itens[] = array(
				'id'        => $id,
				'titulo'    => (string) ( $item['titulo'] ?? '' ),
				'url'       => (string) $item['url'],
				'descricao' => (string) ( $item['descricao'] ?? '' ),
				'fonte'     => F3Base_Llms::FONTE_RESUMO,
				'tipo'      => 'page',
				'data'      => '',
				'origem'    => ( $id > 0 && $id === $home ) ? F3Base_Llms::ORIGEM_HOME : F3Base_Llms::ORIGEM_CURADO,
				'noindex'   => false,
			);
		}

		$politica = isset( $config['politica_privacidade'] ) && is_array( $config['politica_privacidade'] ) ? $config['politica_privacidade'] : array();

		if ( ! empty( $politica['url'] ) ) {
			$itens[] = array(
				'id'        => (int) ( $politica['id'] ?? 0 ),
				'titulo'    => (string) ( $politica['titulo'] ?? '' ),
				'url'       => (string) $politica['url'],
				'descricao' => (string) ( $politica['descricao'] ?? '' ),
				'fonte'     => F3Base_Llms::FONTE_RESUMO,
				'tipo'      => 'page',
				'data'      => '',
				'origem'    => F3Base_Llms::ORIGEM_CURADO,
				'noindex'   => false,
			);
		}

		return $itens;
	}

	/**
	 * IDs excluídos por DECLARAÇÃO, e a regra é a que já existia.
	 *
	 * A política de privacidade fica fora quando a seleção curada não a inclui —
	 * e quem decide isso continua sendo a configuração, que chega aqui como o
	 * slot `politica_privacidade` VAZIO. A exclusão precisa existir também no
	 * eixo automático: sem ela, a mesma página que a curadoria deixou de fora
	 * voltaria pela enumeração, e a chave não teria efeito nenhum.
	 *
	 * @param array<string,mixed> $config Configuração normalizada.
	 * @return array<int,int>
	 */
	private static function excluidos_por_declaracao( array $config ): array {
		$politica = isset( $config['politica_privacidade'] ) && is_array( $config['politica_privacidade'] ) ? $config['politica_privacidade'] : array();

		if ( ! empty( $politica['url'] ) ) {
			return array();
		}

		$id = (int) get_option( 'wp_page_for_privacy_policy', 0 );

		return $id > 0 ? array( $id ) : array();
	}

	/**
	 * Modo de seleção declarado, já normalizado.
	 *
	 * @return string
	 */
	private function modo(): string {
		$config = $this->config();

		return isset( $config['modo'] ) ? (string) $config['modo'] : F3Base_Llms::MODO_MISTO;
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_llms' );

		return is_array( $config ) ? $config : array();
	}
}
