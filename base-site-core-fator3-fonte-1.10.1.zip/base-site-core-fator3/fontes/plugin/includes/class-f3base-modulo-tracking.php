<?php
/**
 * Módulo tracking.
 *
 * O QUE MUDOU NA 1.1.0, dito com a medida que motivou a mudança: até a 1.0.19
 * este pacote não tinha GA4, não tinha Google Ads e não tinha Meta. Zero
 * ocorrência de measurement ID, de `gtag.js`, de `AW-`, de `send_to`, de `fbq`,
 * de `gclid`, de `fbclid` e de `li_fat_id`. O único `gtag` era o STUB do Consent
 * Mode — que torna `typeof gtag === 'function'` verdadeiro em toda página — e os
 * eventos do CTA entravam no `dataLayer` como arrays de comando que ninguém
 * consumia, porque nada carregava o `gtag.js`. Medição que parece existir é pior
 * que medição ausente: ninguém vai procurar o que o console não acusa.
 *
 * O desenho agora é dirigido por VALOR, e nunca por interruptor:
 *
 * - Slot vazio é inerte. Sem ID não sai marcação nenhuma — nunca um placeholder,
 *   nunca um `undefined` no `send_to`. A ausência é dita pelo nome da chave.
 * - `f3base_gtm_container_id` PREENCHIDO decide o caminho e ele é um só: o site
 *   emite o contêiner e alimenta o `dataLayer` com objetos `{event: …}`, e
 *   NENHUMA tag direta é emitida — duas fontes para a mesma conversão é conversão
 *   contada em dobro, e conversão em dobro reescreve o lance do leilão.
 * - Vazio, o site emite as tags diretas dos IDs presentes: `gtag.js` (GA4 e Ads
 *   no mesmo gtag), o Pixel da Meta e o Insight Tag do LinkedIn.
 * - As QUATRO tags passam pelo mesmo portão de consentimento, no servidor e de
 *   novo no navegador. Consent Mode v2 continua valendo para o `gtag`; Pixel e
 *   Insight não têm equivalente, e por isso na negativa eles NÃO SÃO CARREGADOS
 *   — não existe "atualizar para negado" para quem já carregou.
 *
 * O QUE MUDOU NA 1.1.3: o site NASCE INSTRUMENTADO. Até a 1.1.2 este pacote
 * media só conversão — `generate_lead`, `form_start` e `select_content` —, e
 * ninguém sabia se a página era lida, onde o visitante parava, o que ele
 * tentava clicar nem qual era a experiência real de carregamento. Agora o
 * carregador também instala seis coletores de COMPORTAMENTO: marcos de
 * rolagem, seção vista, clique em link externo, fricção, erro de JavaScript do
 * próprio site e Core Web Vitals de campo.
 *
 * Três invariantes carregam essa metade, e as três são estruturais:
 *
 * - **Mesmo portão.** A instrumentação viaja dentro de `dados_de_medicao()`,
 *   que só é publicado quando `enfileirar()` atravessa os dois portões. Slot
 *   vazio → o carregador não chega ao HTML → não há instrumentação. Sem
 *   consentimento, idem.
 * - **Nome e número num lugar só.** `dados/eventos-comportamento.tsv` declara
 *   evento, parâmetro, teto por página e limiar. O cliente não escreve nenhum
 *   dos dois, e `tracking.eventos_de_comportamento_declarados` reprova
 *   qualquer literal de nome declarado dentro do JavaScript. Quem lê a série
 *   histórica é um agente comparando períodos: nome que muda entre releases é
 *   medição que sumiu sem erro nenhum.
 * - **Teto por página.** Rolagem é contínua, clique é repetível e erro em laço
 *   de render dispara milhares de vezes. O teto está declarado para que o
 *   descarte do excesso seja NOSSO, e não uma amostragem silenciosa da conta
 *   de medição.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tags de terceiro e eventos de medição.
 */
final class F3Base_Modulo_Tracking extends F3Base_Modulo {

	/**
	 * Handle do carregador único das tags.
	 */
	public const HANDLE = 'f3base-tracking';

	/**
	 * Origem do Insight Tag do LinkedIn.
	 */
	public const ORIGEM_LINKEDIN = 'https://snap.licdn.com/li.lms-analytics/insight.min.js';

	/**
	 * Origem do carregador do Google (gtag.js e gtm.js saem daqui).
	 */
	public const ORIGEM_GOOGLE = 'https://www.googletagmanager.com/';

	/**
	 * Origem do Pixel da Meta.
	 */
	public const ORIGEM_META = 'https://connect.facebook.net/en_US/fbevents.js';

	/**
	 * Arquivo da declaração ÚNICA dos eventos de comportamento.
	 */
	public const ARQUIVO_EVENTOS = 'dados/eventos-comportamento.tsv';

	/**
	 * Arquivo da declaração ÚNICA das medidas de carregamento.
	 *
	 * A explicação e o limiar de cada medida envelhecem JUNTO com ela, e por
	 * isso moram no diretório de declarações, ao lado dos eventos — nunca no
	 * PHP da tela, onde seriam uma segunda descrição da mesma coisa.
	 */
	public const ARQUIVO_VITAIS = 'dados/vitais.tsv';

	/**
	 * Prefixo da classe que NOMEIA uma seção medida no markup.
	 *
	 * O nome sai daqui e do markup, nunca do texto: derivar o nome de um título
	 * produziria uma série histórica que muda sozinha na primeira revisão de
	 * copy, e quem vai ler a série é um agente comparando períodos. Seção sem a
	 * classe não é medida — é a escolha certa entre não medir e medir errado.
	 */
	public const PREFIXO_SECAO = 'f3base-secao-';

	/**
	 * Caminhos fechados de emissão.
	 */
	public const CAMINHO_GTM    = 'gtm';
	public const CAMINHO_DIRETO = 'direto';
	public const CAMINHO_NENHUM = 'nenhum';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'tracking';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Tracking', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Emite as tags de GA4, Google Ads, Meta e LinkedIn a partir dos IDs gravados, sob um único portão de consentimento, e instrumenta o COMPORTAMENTO do visitante pelo mesmo portão: marcos de rolagem, seção vista, clique em link externo, fricção, erro de JavaScript do próprio site e Core Web Vitals de campo, todos com nome, parâmetro e teto por página declarados num arquivo só. Container do GTM preenchido decide o caminho e desliga toda tag direta, para que nada dispare em dobro; slot vazio é inerte e nada é emitido.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 20,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array(
			'f3base_gtm_container_id',
			'f3base_ga4_measurement_id',
			'f3base_google_ads',
			'f3base_meta_pixel_id',
			'f3base_linkedin_partner_id',
			'f3base_linkedin_conversion_id',
		);
	}

	/**
	 * Os IDs gravados, por nome de option.
	 *
	 * FONTE ÚNICA dos slots: o estado, as dependências, o aviso de formato e o
	 * que vai para o navegador leem daqui. Duas listas de slots divergiriam no
	 * primeiro canal acrescentado.
	 *
	 * @return array<string,string>
	 */
	public static function ids(): array {
		$ads = F3Base_Options::ler( 'f3base_google_ads' );
		$ads = is_array( $ads ) ? $ads : array();

		return array(
			'f3base_gtm_container_id'            => (string) F3Base_Options::ler( 'f3base_gtm_container_id' ),
			'f3base_ga4_measurement_id'          => (string) F3Base_Options::ler( 'f3base_ga4_measurement_id' ),
			'f3base_google_ads.conversion_id'    => (string) ( $ads['conversion_id'] ?? '' ),
			'f3base_google_ads.conversion_label' => (string) ( $ads['conversion_label'] ?? '' ),
			'f3base_meta_pixel_id'               => (string) F3Base_Options::ler( 'f3base_meta_pixel_id' ),
			'f3base_linkedin_partner_id'         => (string) F3Base_Options::ler( 'f3base_linkedin_partner_id' ),
			'f3base_linkedin_conversion_id'      => (string) F3Base_Options::ler( 'f3base_linkedin_conversion_id' ),
		);
	}

	/**
	 * FORMA declarada de cada identificador, por nome de chave.
	 *
	 * A forma não recusa a escrita — o sanitizador guarda o que foi gravado. Ela
	 * existe para o aviso: `G-` faltando no measurement ID produz um `gtag.js`
	 * que carrega e não mede nada, e o silêncio disso custa uma campanha
	 * inteira. Rótulo de conversão do Ads não tem forma pública declarada pelo
	 * fornecedor, e por isso não está aqui: inventar um formato seria pior.
	 *
	 * @return array<string,array{regex:string,forma:string}>
	 */
	public static function formas(): array {
		return array(
			'f3base_gtm_container_id'         => array(
				'regex' => '/^GTM-[A-Z0-9]{4,}$/',
				'forma' => 'GTM-XXXXXXX',
			),
			'f3base_ga4_measurement_id'       => array(
				'regex' => '/^G-[A-Z0-9]{4,}$/',
				'forma' => 'G-XXXXXXXXXX',
			),
			'f3base_google_ads.conversion_id' => array(
				'regex' => '/^AW-[0-9]{6,}$/',
				'forma' => 'AW-000000000',
			),
			'f3base_meta_pixel_id'            => array(
				'regex' => '/^[0-9]{8,}$/',
				'forma' => 'somente dígitos',
			),
			'f3base_linkedin_partner_id'      => array(
				'regex' => '/^[0-9]{4,}$/',
				'forma' => 'somente dígitos',
			),
			'f3base_linkedin_conversion_id'   => array(
				'regex' => '/^[0-9]{4,}$/',
				'forma' => 'somente dígitos',
			),
		);
	}

	/**
	 * Caminho do arquivo ÚNICO que declara os emissores conhecidos.
	 *
	 * Ele viaja dentro deste plugin. O implantador lê a MESMA declaração da
	 * cópia de origem em `fontes/plugin/dados/`, que é este arquivo antes do
	 * empacotamento — duas cópias divergiriam no primeiro slug acrescentado.
	 *
	 * @return string
	 */
	public static function arquivo_de_emissores(): string {
		return ( defined( 'F3BASE_PLUGIN_DIR' ) ? (string) F3BASE_PLUGIN_DIR : '' ) . 'dados/emissores-conhecidos.tsv';
	}

	/**
	 * A DECLARAÇÃO dos emissores conhecidos.
	 *
	 * A leitura e o veredito moram em `F3Base_Emissores`, que é o MESMO arquivo
	 * que o implantador carrega no preflight: a regra do segundo emissor precisa
	 * rodar antes de este plugin existir na instalação, e duas cópias dela
	 * divergiriam na primeira condição acrescentada.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public static function emissores_conhecidos(): array {
		return F3Base_Emissores::declarados( self::arquivo_de_emissores() );
	}

	/**
	 * Emissores CONCORRENTES observados nesta instalação.
	 *
	 * Estado, nunca bloqueio: a premissa desta release é que quem opera o site
	 * é o agente, e o pacote não desativa plugin de ninguém. O que ele faz é
	 * NOMEAR — porque contagem em dobro que ninguém acusa reescreve o lance do
	 * leilão em silêncio.
	 *
	 * @return array<int,array{slug:string,fornecedor:string,veredito:string,motivo:string}>
	 */
	public static function emissores_concorrentes(): array {
		$conhecidos = self::emissores_conhecidos();

		if ( array() === $conhecidos ) {
			return array();
		}

		if ( ! function_exists( 'get_plugins' ) || ! function_exists( 'is_plugin_active' ) ) {
			return array();
		}

		$saida = array();

		foreach ( array_keys( (array) get_plugins() ) as $arquivo ) {
			$slug = (string) dirname( (string) $arquivo );

			if ( ! isset( $conhecidos[ $slug ] ) || ! is_plugin_active( (string) $arquivo ) ) {
				continue;
			}

			$observadas = array();

			foreach ( $conhecidos[ $slug ]['condicoes'] as $condicao ) {
				$nome = (string) $condicao['option'];
				$lido = get_option( $nome, null );

				if ( null !== $lido ) {
					$observadas[ $nome ] = $lido;
				}
			}

			$veredito = F3Base_Emissores::veredito( $conhecidos[ $slug ], $observadas );

			if ( F3Base_Emissores::LEITOR === $veredito['veredito'] ) {
				continue;
			}

			$saida[] = array(
				'slug'       => $slug,
				'fornecedor' => (string) $conhecidos[ $slug ]['fornecedor'],
				'veredito'   => $veredito['veredito'],
				'motivo'     => $veredito['motivo'],
			);
		}

		return $saida;
	}

	/**
	 * Caminho do arquivo ÚNICO que declara os eventos de comportamento.
	 *
	 * Ele viaja dentro deste plugin, como o dos emissores. A suíte lê a MESMA
	 * declaração da cópia de origem em `fontes/plugin/dados/`, que é este
	 * arquivo antes do empacotamento.
	 *
	 * @return string
	 */
	public static function arquivo_de_eventos(): string {
		return ( defined( 'F3BASE_PLUGIN_DIR' ) ? (string) F3BASE_PLUGIN_DIR : '' ) . self::ARQUIVO_EVENTOS;
	}

	/**
	 * AS MEDIDAS DE CARREGAMENTO, com o que cada uma diz e o limiar de "bom".
	 *
	 * O LIMIAR É RÉGUA, E NÃO SELO: a tela mostra o valor medido e o limiar
	 * lado a lado e não classifica a página. Os cortes são do fornecedor e
	 * mudam por calendário; um selo impresso por nós discordaria do console
	 * dele no dia em que ele se movesse, sem uma linha dizendo por quê.
	 *
	 * @param string $arquivo Caminho alternativo, para a bancada.
	 * @return array<string,array{bom_ate:float,unidade:string,explicacao:string}>
	 */
	public static function vitais_declarados( string $arquivo = '' ): array {
		$caminho = '' !== $arquivo ? $arquivo : self::arquivo_de_vitais();

		if ( '' === $caminho || ! is_file( $caminho ) || ! is_readable( $caminho ) ) {
			return array();
		}

		$saida = array();

		foreach ( (array) file( $caminho, FILE_IGNORE_NEW_LINES ) as $linha ) {
			$linha = trim( (string) $linha );

			if ( '' === $linha || str_starts_with( $linha, '#' ) ) {
				continue;
			}

			$colunas = explode( "\t", $linha );

			if ( count( $colunas ) < 4 ) {
				continue;
			}

			$metrica    = trim( (string) $colunas[0] );
			$explicacao = trim( (string) $colunas[3] );

			if ( '' === $metrica || '' === $explicacao ) {
				continue;
			}

			$saida[ $metrica ] = array(
				'bom_ate'    => (float) trim( (string) $colunas[1] ),
				'unidade'    => trim( (string) $colunas[2] ),
				'explicacao' => $explicacao,
			);
		}

		return $saida;
	}

	/**
	 * Caminho do arquivo de declaração das medidas de carregamento.
	 *
	 * @return string
	 */
	public static function arquivo_de_vitais(): string {
		return defined( 'F3BASE_PLUGIN_DIR' ) ? F3BASE_PLUGIN_DIR . self::ARQUIVO_VITAIS : '';
	}

	/**
	 * A DECLARAÇÃO dos eventos de comportamento, lida do arquivo único.
	 *
	 * O cliente não escreve nome de evento nem de parâmetro: ele os recebe
	 * daqui. Dois lugares declarando o mesmo nome são duas séries históricas
	 * que divergem na primeira release, e quem lê a série é um agente
	 * comparando períodos — para ele, nome que muda é medição que sumiu.
	 *
	 * @param string $arquivo Caminho absoluto do TSV declarado.
	 * @return array<string,array{parametros:array<int,string>,teto:int,gatilho:string,limiar:array<string,array<int,string>>}>
	 */
	public static function eventos_de_comportamento( string $arquivo = '' ): array {
		$caminho = '' !== $arquivo ? $arquivo : self::arquivo_de_eventos();

		if ( '' === $caminho || ! is_file( $caminho ) || ! is_readable( $caminho ) ) {
			return array();
		}

		$saida = array();

		foreach ( (array) file( $caminho, FILE_IGNORE_NEW_LINES ) as $linha ) {
			$linha = trim( (string) $linha );

			if ( '' === $linha || str_starts_with( $linha, '#' ) ) {
				continue;
			}

			$colunas = explode( "\t", $linha );

			if ( count( $colunas ) < 5 ) {
				continue;
			}

			$nome = trim( (string) $colunas[0] );
			$teto = (int) trim( (string) $colunas[2] );

			if ( '' === $nome || $teto < 1 ) {
				continue;
			}

			$saida[ $nome ] = array(
				'parametros' => array_values( array_filter( array_map( 'trim', explode( ',', (string) $colunas[1] ) ) ) ),
				'teto'       => $teto,
				'gatilho'    => trim( (string) $colunas[3] ),
				'limiar'     => self::limiar_declarado( (string) $colunas[4] ),
				/*
				 * A PERGUNTA QUE O EVENTO RESPONDE, em português comum, e ela
				 * sai daqui porque o nome sai daqui. Escrita na tela, seria uma
				 * segunda descrição do mesmo evento, e as duas divergiriam na
				 * primeira vez que alguém mudasse o limiar sem mexer no texto.
				 * Coluna ausente devolve vazio: arquivo antigo continua sendo
				 * lido, e a tela diz que a pergunta não foi declarada em vez de
				 * inventar uma.
				 */
				'pergunta'   => trim( (string) ( $colunas[5] ?? '' ) ),
				/*
				 * A FRASE que a tabela bruta imprime, em português comum. Mesma
				 * razão da pergunta: escrita na tela, seria uma segunda
				 * descrição do mesmo evento, divergindo desta na primeira
				 * edição apressada.
				 */
				'frase'      => trim( (string) ( $colunas[6] ?? '' ) ),
				/*
				 * A NATUREZA do evento: `uso` é o que a pessoa fez na página,
				 * `tecnica` é o que o navegador ou o servidor relatou. Só a
				 * primeira entra na tabela de acionamentos. Coluna ausente cai
				 * em `tecnica` de propósito — o silêncio não pode promover um
				 * evento novo a comportamento de uso sem que alguém decida.
				 */
				'natureza'   => 'uso' === trim( (string) ( $colunas[7] ?? '' ) ) ? 'uso' : 'tecnica',
			);
		}

		return $saida;
	}

	/**
	 * O LIMIAR declarado de um evento, em `chave=valor;chave=lista,de,valores`.
	 *
	 * Nenhum número do comportamento é escrito dentro do cliente: os quatro
	 * cliques da fricção, a janela de 1200 ms, o raio de 24 px e os marcos de
	 * rolagem saem todos daqui. Um limiar escrito no JavaScript seria um número
	 * que ninguém revisa junto com a declaração que ele contradiz.
	 *
	 * @param string $bruto Coluna do limiar.
	 * @return array<string,array<int,string>>
	 */
	private static function limiar_declarado( string $bruto ): array {
		$bruto = trim( $bruto );
		$saida = array();

		if ( '' === $bruto || '—' === $bruto ) {
			return $saida;
		}

		foreach ( explode( ';', $bruto ) as $par ) {
			$partes = explode( '=', trim( $par ), 2 );

			if ( 2 !== count( $partes ) || '' === trim( $partes[0] ) ) {
				continue;
			}

			$saida[ trim( $partes[0] ) ] = array_values(
				array_filter( array_map( 'trim', explode( ',', $partes[1] ) ) )
			);
		}

		return $saida;
	}

	/**
	 * O que o navegador precisa saber para INSTRUMENTAR o comportamento.
	 *
	 * A forma é a mesma dos slots de tag: sem declaração o array sai vazio e o
	 * cliente não instala ouvinte nenhum — instrumentação sem nome declarado
	 * emitiria evento que a série histórica não sabe ler.
	 *
	 * @return array<string,mixed>
	 */
	public static function comportamento(): array {
		$declarados = self::eventos_de_comportamento();
		$eventos    = array();

		foreach ( $declarados as $nome => $dados ) {
			$eventos[ $nome ] = array(
				'parametros' => $dados['parametros'],
				'teto'       => $dados['teto'],
				'gatilho'    => $dados['gatilho'],
				'limiar'     => $dados['limiar'],
			);
		}

		return array(
			'eventos'      => $eventos,
			'prefixoSecao' => self::PREFIXO_SECAO,
			'tempoAtivo'   => ! empty( F3Base_Options::ler( 'f3base_comportamento' )['tempo_ativo'] ),
		);
	}

	/**
	 * Algum slot de medição está preenchido?
	 *
	 * @return bool
	 */
	public static function ha_slot_preenchido(): bool {
		foreach ( self::ids() as $valor ) {
			if ( '' !== $valor ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * O CAMINHO desta instalação, e ele é um só.
	 *
	 * @return string Uma das constantes de caminho.
	 */
	public static function caminho(): string {
		$ids = self::ids();

		if ( '' !== $ids['f3base_gtm_container_id'] ) {
			return self::CAMINHO_GTM;
		}

		return self::ha_slot_preenchido() ? self::CAMINHO_DIRETO : self::CAMINHO_NENHUM;
	}

	/**
	 * O que o navegador precisa saber para emitir e para converter.
	 *
	 * Publicado também para o cliente de leads: a conversão do clique sai de um
	 * lugar só, e esse lugar precisa dos mesmos IDs que as tags usam. Duas
	 * cópias dos IDs seriam duas verdades sobre a mesma conta.
	 *
	 * @return array<string,mixed>
	 */
	public static function dados_de_medicao(): array {
		$ids     = self::ids();
		$caminho = self::caminho();

		/*
		 * O CAMINHO É ESTRUTURAL, e não um `if` no cliente. No caminho do
		 * container, os IDs diretos nem chegam ao navegador: disparar em dobro
		 * deixa de ser um ramo esquecido e passa a ser impossível, porque não há
		 * com o que disparar. E no caminho direto o container também não vai —
		 * pelo mesmo motivo, na direção contrária.
		 */
		$direto = self::CAMINHO_DIRETO === $caminho;

		return array(
			'caminho'               => $caminho,
			'gtm'                   => self::CAMINHO_GTM === $caminho ? $ids['f3base_gtm_container_id'] : '',
			'ga4'                   => $direto ? $ids['f3base_ga4_measurement_id'] : '',
			'ads'                   => array(
				'id'    => $direto ? $ids['f3base_google_ads.conversion_id'] : '',
				'label' => $direto ? $ids['f3base_google_ads.conversion_label'] : '',
			),
			'meta'                  => array(
				'pixelId' => $direto ? $ids['f3base_meta_pixel_id'] : '',
				'origem'  => self::ORIGEM_META,
			),
			'linkedin'              => array(
				'partnerId'    => $direto ? $ids['f3base_linkedin_partner_id'] : '',
				'conversionId' => $direto ? $ids['f3base_linkedin_conversion_id'] : '',
				'origem'       => self::ORIGEM_LINKEDIN,
			),
			'origemGoogle'          => self::ORIGEM_GOOGLE,
			/*
			 * A INSTRUMENTAÇÃO VIAJA PELO MESMO CANAL DAS TAGS, e isso é
			 * estrutural: este array só é publicado quando `enfileirar()`
			 * atravessa os dois portões — há slot preenchido E o consentimento
			 * permite. Sem `ga4_measurement_id` nem container, o carregador não
			 * chega ao HTML e a instrumentação não existe; sem consentimento,
			 * idem. Um segundo caminho para a medição de comportamento seria
			 * um segundo portão para manter e uma segunda chance de esquecer.
			 */
			'comportamento'         => self::comportamento(),
			'vitaisMaxAtualizacoes' => F3Base_Vitais::MAX_ATUALIZACOES,
			/*
			 * O SEGUNDO DESTINO, e ele é o que a 1.1.4 acrescenta. Até a 1.1.3
			 * o único destino do comportamento era a conta de medição: com o
			 * slot vazio os eventos não existiam em lugar nenhum, e a pergunta
			 * "onde vejo os dados desta instrumentação" não tinha resposta
			 * dentro do site. O resumo local é um destino de verdade — tabela
			 * própria, retenção declarada e leitura por rota de banco —, e por
			 * isso ele entra aqui, ao lado dos IDs, e não num segundo objeto
			 * com um segundo portão para manter.
			 */
			'resumo'                => class_exists( 'F3Base_Modulo_Comportamento' )
				? F3Base_Modulo_Comportamento::dados_do_cliente()
				: array(
					'ativo'    => false,
					'endpoint' => '',
					'token'    => '',
					'maximo'   => 0,
				),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$saida = array();

		foreach ( self::ids() as $chave => $valor ) {
			$saida[] = array(
				'rotulo'   => $chave,
				'presente' => '' !== $valor,
				'detalhe'  => '' !== $valor
					? __( 'slot preenchido: entra na emissão sob consentimento.', 'f3base' )
					: __( 'vazio por configuração: o slot permanece inerte e nada é emitido por ele.', 'f3base' ),
			);
		}

		$saida[] = array(
			'rotulo'   => __( 'Módulo de consentimento', 'f3base' ),
			'presente' => class_exists( 'F3Base_Modulo_Consentimento' ),
			'detalhe'  => __( 'portão único das quatro tags E da instrumentação de comportamento, conferido no servidor e de novo no navegador.', 'f3base' ),
		);

		$declarados = self::eventos_de_comportamento();

		$saida[] = array(
			'rotulo'   => self::ARQUIVO_EVENTOS,
			'presente' => array() !== $declarados,
			'detalhe'  => array() !== $declarados
				? sprintf(
					/* translators: 1: quantidade de eventos, 2: teto somado por página. */
					__( '%1$d evento(s) de comportamento declarado(s), com teto somado de %2$d disparo(s) por página. Nome, parâmetro, teto e limiar saem daqui e de mais lugar nenhum.', 'f3base' ),
					count( $declarados ),
					array_sum( array_column( $declarados, 'teto' ) )
				)
				: __( 'declaração ausente ou ilegível: nenhum coletor de comportamento é instalado. Instrumentação sem nome declarado emitiria evento que a série histórica não sabe ler, e por isso a ausência desliga em vez de improvisar.', 'f3base' ),
		);

		return $saida;
	}

	/**
	 * {@inheritDoc}
	 */
	public function avisos(): array {
		$ids    = self::ids();
		$avisos = array();

		foreach ( self::formas() as $chave => $forma ) {
			$valor = (string) ( $ids[ $chave ] ?? '' );

			if ( '' === $valor || 1 === preg_match( $forma['regex'], $valor ) ) {
				continue;
			}

			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: 1: nome da chave, 2: valor gravado, 3: forma declarada. */
					__( '%1$s está gravada como "%2$s", fora da forma %3$s. O valor foi preservado — o pacote não apaga o que alguém gravou —, e a consequência é esta: a tag carrega e a conta não recebe nada, sem erro no console e sem linha no relatório do fornecedor.', 'f3base' ),
					$chave,
					$valor,
					$forma['forma']
				),
			);
		}

		$ads_id    = (string) $ids['f3base_google_ads.conversion_id'];
		$ads_label = (string) $ids['f3base_google_ads.conversion_label'];

		if ( ( '' === $ads_id ) !== ( '' === $ads_label ) ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => __( 'a conversão do Google Ads precisa das DUAS metades do send_to: com só uma preenchida, nenhuma conversão é enviada — o disparo iria para a conta e não para a ação, e o pacote prefere não disparar a disparar no lugar errado.', 'f3base' ),
			);
		}

		/*
		 * O SEGUNDO EMISSOR, e ele é o buraco que `caminho_unico` não vê. Aquela
		 * regra prova que ESTE módulo não emite pelos dois caminhos dele mesmo —
		 * container × direto — e não enxerga um plugin de console imprimindo o
		 * `gtag.js` ao lado dele. Contagem em dobro que nenhuma configuração
		 * declarou não é número errado num relatório: ela reescreve o lance do
		 * leilão. O aviso vem DEPOIS dos de forma, de propósito: quem lê o
		 * primeiro aviso está procurando o ID que não bate.
		 */
		foreach ( self::emissores_concorrentes() as $emissor ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: 1: slug do plugin, 2: fornecedor, 3: veredito medido, 4: motivo. */
					__( 'GA4 emitido também por %1$s (%2$s): contagem em dobro. Veredito de emissão: %3$s — %4$s A emissão de toda tag de medição é deste módulo; o plugin é admitido como leitor, com o snippet e a medição automática de conversões desligados. Quem confere no HTML publicado é tracking.emissor_unico.', 'f3base' ),
					$emissor['slug'],
					$emissor['fornecedor'],
					$emissor['veredito'],
					$emissor['motivo']
				),
			);
		}

		return $avisos;
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$caminho = self::caminho();
		$segundo = $this->frase_do_segundo_emissor();

		/*
		 * DUAS COISAS DIFERENTES MORAM NESTE MÓDULO, e confundi-las apagou a
		 * medição de um site inteiro em produção. Uma é a TAG DE FORNECEDOR,
		 * que sem ID não tem para onde disparar. A outra é o COLETOR DE
		 * COMPORTAMENTO, que é nosso, grava no próprio site e não depende de
		 * fornecedor nenhum — ele existe justamente para o operador saber o que
		 * acontece na página sem depender do Google.
		 *
		 * Até aqui o estado olhava só para `caminho()`: sem ID de fornecedor o
		 * módulo fechava INATIVO, e módulo inativo NÃO REGISTRA HOOK. O
		 * `wp_enqueue_scripts` nunca era registrado, `enfileirar()` — que já
		 * sabia perguntar por `ha_destino()` — nunca era chamado, o carregador
		 * não chegava ao HTML e a tabela do resumo ficava em zero linha para
		 * sempre. O site medido em produção tinha exatamente isso: nenhum
		 * script no HTML e a tabela vazia, com todas as options certas.
		 *
		 * O estado agora responde pelo DESTINO, que é a mesma pergunta que
		 * `enfileirar()` faz. Sem NENHUM dos dois destinos — nem conta de
		 * fornecedor, nem resumo no próprio site — aí sim não há o que medir.
		 */
		if ( ! self::ha_destino() ) {
			return $this->inativo(
				__( 'nenhum slot de medição preenchido E o resumo no próprio site desligado: não há tag no HTML, não há coleta de comportamento e nada é gravado. Preencher qualquer um dos IDs, ou religar o resumo, faz a medição passar a existir na página seguinte, sem passo manual.', 'f3base' ) . $segundo
			);
		}

		if ( ! F3Base_Modulo_Consentimento::permite_tags() ) {
			return $this->degradado(
				__( 'consentimento negado no navegador desta requisição: nenhuma das quatro tags é carregada nele. O carregador continua no HTML — ele é o mesmo para todo visitante e por isso é cacheável —, e o portão é conferido no cliente, que é o único lugar que o cache de página não congela. Pixel e Insight Tag não têm modo de consentimento — carregar e "atualizar para negado" seria carregar assim mesmo —, e por isso a negativa vira ausência de carga.', 'f3base' ) . $segundo
			);
		}

		if ( self::CAMINHO_NENHUM === $caminho ) {
			return $this->ativo(
				__( 'sem ID de fornecedor: nenhuma tag de terceiro é emitida e nenhuma conversão sai para conta nenhuma — o slot vazio continua inerte, como deve ser. O que ESTÁ no ar é o coletor de comportamento do próprio site, que não depende de fornecedor: rolagem, seção vista, clique para fora, fricção, erro de JavaScript e Core Web Vitals são somados na tabela do site e aparecem no menu Medição. Preencher qualquer um dos IDs acrescenta a emissão para a conta, sem tirar nada daqui.', 'f3base' ) . $segundo
			);
		}

		if ( self::CAMINHO_GTM === $caminho ) {
			return $this->ativo(
				sprintf(
					/* translators: %s: container do GTM. */
					__( 'container %s emitido sozinho: o site alimenta o dataLayer com eventos em objeto e NENHUMA tag direta é emitida, para que a mesma conversão não seja contada duas vezes.', 'f3base' ),
					self::ids()['f3base_gtm_container_id']
				) . $segundo
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: quantidade de slots preenchidos. */
				_n(
					'%d slot preenchido, emitido direto a partir do ID gravado e sob consentimento vigente.',
					'%d slots preenchidos, emitidos direto a partir dos IDs gravados e sob consentimento vigente.',
					count( array_filter( self::ids(), static fn ( string $valor ): bool => '' !== $valor ) ),
					'f3base'
				),
				count( array_filter( self::ids(), static fn ( string $valor ): bool => '' !== $valor ) )
			) . $segundo
		);
	}

	/**
	 * A frase do SEGUNDO EMISSOR, que o estado carrega em todos os ramos.
	 *
	 * Ela sai nos DOIS lados: com emissor detectado, nomeando o plugin e o
	 * motivo; sem emissor detectado, dizendo que a emissão é deste módulo e
	 * só dele. Estado que só fala quando há problema é estado que ninguém
	 * consegue distinguir de estado que não mediu nada.
	 *
	 * @return string
	 */
	private function frase_do_segundo_emissor(): string {
		$emissores = self::emissores_concorrentes();

		if ( array() === $emissores ) {
			return ' ' . __( 'Nenhum emissor concorrente detectado entre os plugins ativos: a emissão de tag deste site é deste módulo. A contagem no HTML publicado é de tracking.emissor_unico.', 'f3base' );
		}

		$nomes = array();

		foreach ( $emissores as $emissor ) {
			$nomes[] = $emissor['slug'] . ' (' . $emissor['veredito'] . ')';
		}

		return ' ' . sprintf(
			/* translators: %s: lista de plugins emissores detectados. */
			__( 'GA4 emitido também por %s: contagem em dobro. O pacote NÃO desativa nada — quem opera o site é o agente —, e a contagem no HTML publicado é de tracking.emissor_unico.', 'f3base' ),
			implode( ', ', $nomes )
		);
	}

	/**
	 * HÁ DESTINO para o que este site mede?
	 *
	 * A pergunta mudou na 1.1.4, e a mudança é o assunto da release. Até a
	 * 1.1.3 ela era "há slot de medição preenchido?", e a resposta negativa
	 * deixava a instrumentação inerte com um motivo bom: emitir comportamento
	 * sem uma conta para recebê-lo é emitir para lugar nenhum. Com o resumo
	 * local existindo, "lugar nenhum" deixou de ser verdade — o próprio site é
	 * um destino, com tabela, prazo e leitura. Sem NENHUM dos dois, a regra
	 * anterior continua valendo inteira: nada é enfileirado e nada é emitido.
	 *
	 * @return bool
	 */
	public static function ha_destino(): bool {
		if ( self::CAMINHO_NENHUM !== self::caminho() ) {
			return true;
		}

		return class_exists( 'F3Base_Modulo_Comportamento' ) && F3Base_Modulo_Comportamento::ligado();
	}

	/**
	 * Enfileira o carregador único quando HÁ DESTINO — e o portão fica no cliente.
	 *
	 * O DEFEITO MEDIDO, e ele é de cache. Este método lia `permite_tags()`, que
	 * lê `$_COOKIE`, para decidir se o `<script>` entra no HTML. Nenhum `Vary:
	 * Cookie` e nenhum `DONOTCACHEPAGE` acompanhavam a decisão, e o HTML de uma
	 * página de site de tráfego pago é servido de cache: a decisão do PRIMEIRO
	 * visitante a gerar aquela página ficava congelada para todos os seguintes.
	 * Um visitante que recusou gerava a versão sem medição para o site inteiro;
	 * um que aceitou gerava a versão com o carregador para quem tinha recusado.
	 *
	 * As duas saídas eram ruins. `Vary: Cookie` sobre o cookie de consentimento
	 * fragmenta o cache em três versões da mesma página e, na prática, desliga o
	 * cache — o cookie muda por visitante. `DONOTCACHEPAGE` desliga o cache
	 * daquela página de vez. As duas pagam com desempenho de todo mundo por uma
	 * decisão que o navegador sabe tomar sozinho.
	 *
	 * A saída é a terceira: o HTML deixa de depender do cookie. O carregador é
	 * servido SEMPRE que há destino — ele é o mesmo bytes para todo visitante,
	 * cacheável —, e quem decide é o cliente, que lê a decisão no navegador em
	 * que ela foi tomada. O portão não sumiu nem afrouxou: `f3base-tracking.js`
	 * confere `permiteTags()` antes de carregar QUALQUER tag de fornecedor, e
	 * refaz a conferência a cada mudança de decisão, na mesma navegação. O que
	 * mudou é onde ele mora — e ele agora mora no único lugar que o cache não
	 * congela.
	 *
	 * O que continua decidido AQUI é o destino: sem conta de fornecedor e sem o
	 * resumo do próprio site, não há o que medir e nada é enfileirado. Essa
	 * decisão não depende de visitante nenhum, e por isso ela é cacheável.
	 *
	 * @return void
	 */
	public function enfileirar(): void {
		if ( ! self::ha_destino() ) {
			return;
		}

		$dependencias = array( F3Base_Modulo_Consentimento::HANDLE, 'f3base-web-vitals' );
		if ( ! empty( F3Base_Options::ler( 'f3base_comportamento' )['tempo_ativo'] ) ) {
			wp_enqueue_script(
				'f3base-tempo-ativo',
				F3BASE_PLUGIN_URL . 'assets/f3base-tempo-ativo' . ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min' ) . '.js',
				array(),
				F3BASE_PLUGIN_VERSAO,
				array(
					'in_footer' => true,
					'strategy'  => 'defer',
				)
			);
			$dependencias[] = 'f3base-tempo-ativo';
		}
		wp_enqueue_script(
			'f3base-web-vitals',
			F3BASE_PLUGIN_URL . 'assets/vendor/web-vitals.js',
			array(),
			F3BASE_PLUGIN_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_enqueue_script(
			self::HANDLE,
			F3BASE_PLUGIN_URL . 'assets/f3base-tracking' . ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min' ) . '.js',
			$dependencias,
			F3BASE_PLUGIN_VERSAO,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);

		wp_localize_script( self::HANDLE, 'f3baseTrackingDados', self::dados_de_medicao() );
	}
}
