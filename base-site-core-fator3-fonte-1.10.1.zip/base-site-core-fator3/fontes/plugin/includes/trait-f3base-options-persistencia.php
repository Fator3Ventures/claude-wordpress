<?php
/** Serviço interno de persistencia composto exclusivamente pela fachada F3Base_Options. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

trait F3Base_Options_Persistencia {
	/**
	 * Escrita física. ÚNICO ponto de `update_option` do plugin.
	 *
	 * @param string $nome     Nome da option.
	 * @param mixed  $valor    Valor já sanitizado.
	 * @param bool   $autoload Carregar automaticamente.
	 * @return void
	 */
	private static function escrever( string $nome, $valor, bool $autoload ): void {
		update_option( $nome, $valor, $autoload );
	}

	private static function revisao_do_bruto( string $nome, ?array $r ): string {
		return hash_hmac( 'sha256', $nome . '|' . ( null === $r ? 'ausente' : 'presente|' . $r['option_value'] ), wp_salt( 'auth' ) );
	}

	/** Compare-and-swap no banco: uma escrita concorrente não pode ser sobrescrita entre a leitura e o UPDATE. */
	private static function escrever_condicional( string $nome, $valor, bool $autoload, string $esperada, ?bool &$aplicada = null ): bool {
		$aplicada = false;
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $nome ), ARRAY_A );
		if ( ! empty( $wpdb->last_error ) || ! hash_equals( self::revisao_do_bruto( $nome, $r ), $esperada ) ) {
			return false; }
		$anterior  = null === $r ? false : maybe_unserialize( $r['option_value'] );
		$preparado = sanitize_option( $nome, $valor );
		$preparado = apply_filters( "pre_update_option_{$nome}", $preparado, $anterior, $nome );
		$preparado = apply_filters( 'pre_update_option', $preparado, $nome, $anterior );
		if ( ! self::equivalente( $preparado, $valor ) ) {
			return false; }
		$serializado = (string) maybe_serialize( $preparado );
		if ( null === $r ) {
			$ok = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,%s)", $nome, $serializado, $autoload ? 'yes' : 'no' ) );
		} else {
			$ok = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value=%s,autoload=%s WHERE option_name=%s AND HEX(option_value)=HEX(%s)", $serializado, $autoload ? 'yes' : 'no', $nome, $r['option_value'] ) );
			if ( 0 === $ok && $serializado === (string) $r['option_value'] ) {
				$ok = 1; }
		}
		wp_cache_delete( $nome, 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		wp_cache_delete( 'notoptions', 'options' );
		if ( 1 !== $ok ) {
			return false; }
		$aplicada   = true;
		$confirmado = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $nome ), ARRAY_A );
		if ( ! $confirmado || $serializado !== (string) $confirmado['option_value'] ) {
			return false; }
		if ( null === $r ) {
			do_action( 'added_option', $nome, $preparado ); } elseif ( $serializado !== (string) $r['option_value'] ) {
			do_action( "update_option_{$nome}", $anterior, $preparado, $nome );
			do_action( 'updated_option', $nome, $anterior, $preparado ); }
			return true;
	}

	private static function remover_persistencia( string $nome ): bool {
		if ( ! in_array( $nome, self::proprias(), true ) ) {
			return false;
		}

		delete_option( $nome );

		$removida = ! self::existe( $nome );
		if ( $removida && null !== self::declaracao( $nome ) && ! in_array( $nome, self::estado_de_execucao(), true ) ) {
			$foto = self::fotografia( $nome );
			self::registrar_proveniencia( $nome, self::ORIGEM_MANUAL, $foto['revisao'], $foto['valor'], 'remover' );
		}
		return $removida;
	}

	private static function revisao_persistida( string $nome ): string {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $nome ), ARRAY_A );
		return self::revisao_do_bruto( $nome, $r );
	}

	private static function fotografia_persistida( string $nome ): array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $nome ), ARRAY_A );
		return self::fotografia_do_bruto( $nome, $r, ! empty( $wpdb->last_error ) );
	}

	/** Projeção única para fotografias individuais ou obtidas no mesmo SELECT. */
	private static function fotografia_do_bruto( string $nome, ?array $r, bool $erro ): array {
		$d       = self::declaracao( $nome );
		$interno = in_array( $nome, array( self::OPTION_PROVENIENCIA, self::OPTION_TENTATIVAS ), true );
		$valor   = null === $r ? ( $d['padrao'] ?? ( $interno ? array() : null ) ) : ( $interno ? maybe_unserialize( $r['option_value'] ) : self::sanitizar( $nome, maybe_unserialize( $r['option_value'] ) ) );
		return array(
			'valor'   => $valor,
			'revisao' => self::revisao_do_bruto( $nome, $r ),
			'existe'  => null !== $r,
			'erro'    => $erro,
		);
	}

	/** Leitura em lote apenas para apresentação; nenhuma escrita usa estas fotografias. */
	private static function fotografias_persistidas( array $nomes ): array {
		global $wpdb;
		$nomes = array_values( array_unique( array_intersect( array_filter( $nomes, 'is_string' ), self::proprias() ) ) );
		if ( ! $nomes ) {
			return array();
		}
		$marcas = implode( ',', array_fill( 0, count( $nomes ), '%s' ) );
		$linhas = $wpdb->get_results( $wpdb->prepare( "SELECT option_name,option_value FROM %i WHERE option_name IN ({$marcas})", array_merge( array( $wpdb->options ), $nomes ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- O fragmento contém apenas placeholders; nomes permitidos são preparados como valores.
		$erro   = ! empty( $wpdb->last_error );
		$mapa   = array_column( $linhas ? $linhas : array(), null, 'option_name' );
		$fotos  = array();
		foreach ( $nomes as $nome ) {
			$fotos[ $nome ] = self::fotografia_do_bruto( $nome, $mapa[ $nome ] ?? null, $erro );
		}
		return $fotos;
	}

	private static function atualizar_estado_condicional( string $nome, callable $transformar, int $tentativas = self::TENTATIVAS_CAS ): array {
		$permitidas = array_merge( self::estado_de_execucao(), array( self::OPTION_PROVENIENCIA, self::OPTION_TENTATIVAS ) );
		if ( ! in_array( $nome, $permitidas, true ) ) {
			return array(
				'persisted' => false,
				'codigo'    => 'estado_nao_permitido',
				'lido'      => null,
				'revisao'   => '',
			); }
		$foto   = array(
			'valor'   => null,
			'revisao' => '',
		);
		$limite = max( 1, min( self::TENTATIVAS_CAS, $tentativas ) );
		for ( $i = 0; $i < $limite; $i++ ) {
			$foto = self::fotografia( $nome );
			if ( $foto['erro'] ) {
				return array(
					'persisted' => false,
					'codigo'    => 'leitura_falhou',
					'lido'      => null,
					'revisao'   => '',
				); }
			try {
				$novo = $transformar( $foto['valor'] );
			} catch ( Throwable $falha ) {
				return array(
					'persisted' => false,
					'codigo'    => 'transformacao_falhou',
					'lido'      => $foto['valor'],
					'revisao'   => $foto['revisao'],
				); }
			if ( null === $novo ) {
				return array(
					'persisted' => false,
					'codigo'    => 'transformacao_recusada',
					'lido'      => $foto['valor'],
					'revisao'   => $foto['revisao'],
				); }
			if ( null !== self::declaracao( $nome ) ) {
				$novo = self::cortar_na_escrita( $nome, self::sanitizar( $nome, $novo ), self::declaracao( $nome ) ); }
			$aplicada = false;
			if ( self::escrever_condicional( $nome, $novo, false, $foto['revisao'], $aplicada ) ) {
				$confirmada = self::fotografia( $nome );
				if ( ! $confirmada['erro'] && $confirmada['existe'] && self::equivalente( $novo, $confirmada['valor'] ) ) {
					return array(
						'persisted' => true,
						'codigo'    => 'estado_confirmado',
						'lido'      => $confirmada['valor'],
						'revisao'   => $confirmada['revisao'],
					); }
			}
			// Uma escrita aceita pode ter sido sucedida: repetir o callback duplicaria seu evento.
			if ( $aplicada ) {
				return array(
					'persisted' => false,
					'codigo'    => 'escrita_sem_confirmacao',
					'lido'      => null,
					'revisao'   => $foto['revisao'],
				); }
		}
		return array(
			'persisted' => false,
			'codigo'    => 'conflito_ou_falha_de_escrita',
			'lido'      => $foto['valor'],
			'revisao'   => $foto['revisao'],
		);
	}
}
