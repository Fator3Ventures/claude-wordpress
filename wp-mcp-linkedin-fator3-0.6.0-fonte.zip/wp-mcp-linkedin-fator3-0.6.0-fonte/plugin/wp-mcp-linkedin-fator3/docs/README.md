# Fator3 MCP LinkedIn 0.6.0

Plugin independente. Configure em Ferramentas > Fator3 MCP LinkedIn. Entradas humanas (painel, REST, abilities/MCP, arquivos e tarefas iniciadas por usuário) exigem `manage_options`. A lista legada `users` não concede acesso a pessoas sem essa capacidade. O transporte MCP é opcional; o plugin não chama Google, Core ou outro provedor para executar relatórios.

## Índice instalado

- ADMINISTRATION.md — abas, seletores e fluxos de administração.
- AGENTS.md — operação por agentes e limites de autorização.
- CONFIGURATION.md — tokens, seleção e acesso.
- OPERATIONS.md — consultas, processamento e exportações.
- CONTRACTS.md — contratos, REST/MCP, schemas e erros.
- SDK-PHP.md — SDK local e responsabilidade de consumidores.
- SECURITY.md — isolamento, dados e autorização.
- MIGRATION.md — atualização, retenção e rollback.
- TROUBLESHOOTING.md — diagnóstico, limites e falhas.
- CHANGELOG.md — alterações da versão.
- input-schemas.json e output-schema.json — contratos gerados pelo build.

Todos estes arquivos integram o instalador e o conteúdo retornado por `linkedin/documentation`. Consulte `{"document":"index"}`. Para ler um documento use `document`, `offset` (bytes) e `limit_bytes` (256–65536). Continue por `next_offset`, repetindo `expected_revision` igual a `revision`. Concatene `content` sem separadores; confira o SHA-256 integral indicado. O cursor documental não faz HTTP, não migra armazenamento, não grava auditoria nem lê caminhos arbitrários. A resposta identifica slug, versão, origem local, tamanho e hash. O painel usa a mesma operação.

## Instalação e dependências

WordPress 6.4+, PHP 8.1.2+ de 64 bits, MySQL/MariaDB com InnoDB e bloqueios nomeados, criptografia sodium ou AES-256-GCM, HTTPS externo e WP-Cron ou cron real. Abilities exigem a API de abilities disponível; em WordPress sem ela o painel e REST continuam operando. Instale o ZIP instalador; o ZIP fonte é para desenvolvimento. Consulte o relatório da entrega para a matriz de versões efetivamente testadas.

Tokens nunca são retornados por APIs de configuração. Configuração local, teste com respostas simuladas e homologação externa são estados distintos. Acesso real depende de produtos, permissões, ativos e versões liberados pelo fornecedor.

## Capacidades da versão 0.6.0

79 operações: os 73 identificadores da 0.5.0 permanecem; seis novas operações cobrem regras, concessão, prontidão e envio CAPI unitário/lote. Todos os rótulos e descrições permanecem em português. Leia também:

- MANAGEMENT.md — especificação, prévia, execução, reconciliação e exemplos de anúncios/publicações.
- CREDENTIALS.md — autorização opcional pelo navegador, renovação, avisos e preservação do acesso.
- CONVERSIONS.md — SDK CAPI, concessão e riscos de entrega.
- FIELD-HELP.md — nomes e localização dos campos.
- RELEASE-0.6.0.md — pedidos 8 a 11 e limites de aceite.
- RELEASE-0.5.0.md — histórico da versão anterior.

A atualização de referência é 0.5.0 → 0.6.0. O diário local contém antes/depois. O descritor mutation-audit/1.0.0 permite ao MCP 0.26.1 consultar snapshots autorizados de escritas humanas. Não confunda entrega do código com homologação real do LinkedIn.
