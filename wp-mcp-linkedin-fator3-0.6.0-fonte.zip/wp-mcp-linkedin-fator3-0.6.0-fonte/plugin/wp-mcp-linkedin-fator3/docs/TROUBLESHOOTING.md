# Diagnóstico — 0.6.0

`status` informa versão, banco, criptografia e execução do cron. `selftest` realiza verificações locais; não valida credenciais externas. `validate-connection` lê identidade do ativo, sem prometer todas as métricas. Consulte auditoria paginada para códigos sanitizados.

- not_authorized: confirme manage_options ou a concessão vigente do consumidor SDK.
- revision_conflict: releia a configuração; uma revisão não é intercambiável com outra.
- token_expired/token_rejected: renove e valide a credencial; resultados históricos locais não dependem de token válido.
- rate_limited: aguarde retry_after; o agendador aplica adiamento.
- upstream_validation: confirme versão, campo, produto e aprovação do aplicativo.
- operation_uncertain: consulte e reconcilie o diário; não gere outra chave para contornar o bloqueio.
- history_changed: a visão paginada mudou; reinicie consulta/exportação com nova chave.
- response_limit: reduza campos ou limit. Não considere uma resposta truncada completa.
- cipher_unreadable: confira salts e restauração; não tente regravar sobre dado ilegível.
- storage_unavailable/persistence_unconfirmed: verifique banco, espaço e bloqueios; preserve o backup.

Cron depende de visitas se não houver agendador do servidor. Execução alternativa: `wp f3-meta run` / `wp f3-linkedin run`. Cada passo tem orçamento; grandes coletas exigem múltiplas execuções. O usuário que criou uma agenda precisa continuar autorizado.

## Novos códigos e ações

scope_missing: reautorize o app com a permissão requerida; não altere somente rótulos locais. application_required: configure ID e segredo para introspecção. targeting_ambiguous: escolha um resultado da busca e mantenha search_offset. preview_required/preview_stale: releia e gere prévia. revision_conflict: confronte a versão atual antes de nova decisão. operation_uncertain/verification_pending: consulte operation_id e reconcilie sem reenviar. refresh_unavailable/refresh_expired: aplicativo não emitiu refresh ou prazo venceu; reautorize. oauth_rejected: conferir app, produto e credenciais. O token atual é preservado em falha de refresh.
