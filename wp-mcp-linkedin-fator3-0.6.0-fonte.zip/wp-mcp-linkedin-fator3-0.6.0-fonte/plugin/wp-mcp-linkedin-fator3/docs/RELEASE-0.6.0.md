# Notas e aceite — 0.6.0

Base direta 0.5.0. Pedidos MCP LinkedIn 8, 9, 10 e 11. Identidade, relatórios, Lead Reader 1.0/1.1 e gestão 1.0.0 preservados. Seis novas operações; total 79.

8: adaptador CAPI implementado e testável com fornecedor simulado; escopos rw_conversions e r_ads, papel na conta, seleção de regra API ativa e concessão própria. Não transforma Insight Tag em API: não há contrato oficial comprovado para tal operação. Core 1.47.0 exige regra igual à do navegador, enquanto a documentação orienta regras separadas com eventId comum. A homologação 31692506 está bloqueada por essa divergência e por aprovação rw_conversions. Serviço background tem diário local, sem Registro central enquanto o MCP não admitir principal de serviço.
9: enum de seguidores corrigido, mensagem remota sanitizada e serviceErrorCode. Comparação do total com as telas das duas Páginas exige conta real autorizada.
10: descritor público registrado; leitor conserva administrador, proprietário e ativo. CentralAudit status reflete admissão real. Sem MCP, funções próprias continuam disponíveis.
11: ajuda nos campos e tabela, callback copiável e erro contextual. Referências oficiais consultadas em 22/10/2026. Nomes em sessão autenticada e preenchimento pelo dono são aceites externos pendentes.

As verificações próprias não concedem produtos no LinkedIn. Não enviar conversões, publicações ou Ads reais para homologar sem ordem específica. WordPress/PHP mínimos herdados 6.4/8.1.2 não são prova de execução; consulte o relatório externo para a matriz efetivamente testada.
