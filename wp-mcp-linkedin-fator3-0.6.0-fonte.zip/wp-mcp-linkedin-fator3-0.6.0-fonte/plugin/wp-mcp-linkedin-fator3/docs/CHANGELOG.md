# Alterações — 0.6.0
- Pedidos 8–11: CAPI com concessão site-core-conversions, regra API, leitura local de prontidão, envio unitário/lote, prévia humana e diário sem PII.
- follower_total usa COMPANY_FOLLOWED_BY_MEMBER; recusas trazem provider_message sanitizada e serviceErrorCode.
- Registro explícito mutation-audit/1.0.0 no MCP 0.26.1; estado detectado.
- Campos com nomes do LinkedIn, caminhos, links e retorno OAuth pronto para copiar; erros distinguem Access Token do par Client ID / Primary Client Secret.
- Limites: regra única browser/API exigida pelo Core 1.47.0 diverge da orientação do fornecedor; serviço background sem identidade humana não é admitido pelo Registro central atual. Nenhuma regra externa é transformada automaticamente.

## Histórico anterior (não representa limites atuais)

# Alterações — 0.5.0

- Pedido 5: rótulos e descrições em português para todas as abilities; 42 IDs originais preservados.
- Pedido 6: gestão Ads/Páginas, prévia, confirmação, revisão, chave idempotente, trava e diário/reconciliação. Criação Ads DRAFT; ativação separada; pesquisa de segmentação por nome; nova aba administrativa sem JSON.
- Pedido 7: refresh cifrado, manutenção automática, incidentes/avisos, introspecção e OAuth opcional com retorno local. Renovação preserva revisão de autorização; reautorização exige reconfirmação.
- Contratos aditivos linkedin-management/1.0.0 e linkedin-mutation/1.0.0. MCP central mantém resumo até implementação do contrato de antes/depois.

## Histórico anterior, recebido com a base

# Alterações — 0.4.1

- Tradução dos rótulos e estados de diagnóstico, cobertura e concessões; campos técnicos não catalogados usam rótulo em português e conservam a chave em dica técnica. Códigos de API continuam íntegros nos contratos.
- A 0.4.0 foi um marco intermediário instalado no Site-Teste. Seus ZIPs não foram reescritos. O patch 0.4.1 segue a orientação do dono para revisões dentro do mesmo ciclo. Esta entrega atualiza diretamente 0.3.0 e 0.4.0.

## Implementação da 0.4.0

# Alterações — 0.4.0

Atualização direta da 0.3.0, sem migração de tabela ou mudança de identidade.

- LinkedIn 4: abas por assunto com URL própria; conexões locais na abertura; usuários, contas, objetos e formulários selecionados pelo nome; carregamento e falhas por seção; versão da API em Diagnóstico > configuração avançada.
- Agendas: nome, próxima execução em UTC e edição com revisão; edição preserva consulta, horário exato e último recibo quando não alterados.
- Nova operação administrativa `admin-options`, com seleção explícita e revalidação de autorização/revisão. Contratos de relatórios e SDK preservados.
- Formulários e concessões por seletores e caixas; paginação de descobertas; contas e campanhas com nomes; pivôs em português. Não muda o SDK Lead Reader 1.0/1.1 nem o cliente comercial do Core.

## Histórico da 0.3.0

# Alterações — 0.3.0

Atualização direta da 0.2.0; nenhuma migração de banco, seleção ou autorização.

- Pedido MCP LinkedIn 1: Description exata com responsabilidade do Core e local de configuração. APIs, SDK, assinaturas, autorização e armazenamento permanecem byte a byte iguais à 0.2.0.

## Histórico da 0.2.0

# 0.2.0

- Administração humana restrita a manage_options; SDK com grant explícito preservado para usuário zero.
- Índice e documentação completa paginada com SHA-256, UTF-8 e revisão.
- R3-LI-01: bloqueio persistido por recurso entre chaves, consumidores e conexões; migração de intenções 0.1.
- R3-LI-02: guarda junto ao despacho de POST/DELETE e preservação de recibo em revogação durante o envio.
- R3-LI-03: SDK 1.1, consulta/reconciliação do diário, efeito remoto e reatrelamento explícito de contexto conhecido.
- Paginação de concessões, projeções diretas e painel de consulta administrativa.
- Desinstalação conserva dados. Pages, Ads e ingestão comercial mantêm suas fronteiras.

Operação real de Lead Sync e migração do Core dependem de homologação autorizada; nenhuma assinatura real foi criada pelos testes locais.
