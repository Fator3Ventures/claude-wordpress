# Atualização 0.5.0 → 0.6.0

Instale o ZIP de raiz wp-mcp-linkedin-fator3 sobre o plugin existente e confirme versão 0.6.0, selftest, documentação e próxima manutenção em status. Não exige desativar acompanhantes. Core 1.47.0 e MCP 0.26.1 são as versões integradas desta rodada.

Schema SQL permanece 1. Conexões cifradas, credenciais sobrepostas, concessões Lead Sync, agendas, cursores, diários e resultados são preservados. Nenhum ativo ou CAPI é concedido na atualização. Configure explicitamente a nova concessão em Ativos. Campos adicionais de CAPI usam buckets conversion_grant, conversion_event e conversion_preview no armazenamento existente. O diário de eventos não expira automaticamente e não armazena payload de identificação; a prévia expira em dez minutos.

Voltar os arquivos à 0.5.0 desabilita CAPI e o descritor explícito, preservando registros. A 0.5.0 continua usando a sobreposição de credenciais. Suspenda fila/escritores e faça backup integral, incluindo salts e banco, antes do rollback. Restaurar arquivos ou banco não desfaz evento aceito, publicação ou efeito remoto. O Core pode ter marcado eventos como entregues/incertos: não recrie IDs para reenviar. A referência congelada de destino não é transferida para outra conexão/regra.

Desativação remove somente hooks próprios; desinstalação conserva os dados. Mudança de configuração invalida concessão até reconfirmação. Não restaure banco alheio ou apague o Site-Teste para simular instalação limpa.
