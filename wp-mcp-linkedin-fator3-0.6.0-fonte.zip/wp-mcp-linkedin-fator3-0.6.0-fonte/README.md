# Fonte — Fator3 MCP LinkedIn 0.6.0

Fonte exclusivo de `wp-mcp-linkedin-fator3`, atualização direta da 0.5.0, Pedidos MCP LinkedIn 8, 9, 10 e 11. Instale somente o ZIP instalador entregue separadamente. O fonte contém o runtime exato em `plugin/`, templates e documentação em `build/`, testes PHP e navegador, evidências sanitizadas em `evidence/`, normas e documentos recebidos em `inputs/` e o histórico de decisões em `planning/`. Não contém dependências binárias, credenciais reais ou capturas de navegador.

## Reprodução

Use Python 3 e PHP de 64 bits. Execute `F3_SOCIAL_PHP=/caminho/php python3 build/build.py`. O instalador determinístico em `build/dist/` deve ter 189130 bytes e SHA-256 `edfed426b2e0e4fce14a5c5c6241b12bed25186ab1da2102da96b2032a8af45e`. O build valida a sintaxe de 24 arquivos PHP. Os 49 arquivos em `plugin/wp-mcp-linkedin-fator3/` são idênticos aos do instalador. Nenhum ZIP está aninhado neste fonte.

Ambiente efetivamente certificado: WordPress 7.1.3, PHP 8.3.6 de 64 bits, MySQL 8.0.46; navegador Chromium 153.0.8010.0. `tools/runtime-dependencies.json` contém os pins públicos PHP 8.3.6 Ubuntu `.13` e dependências recebidos com o MCP 0.26.1; `tools/fetch-runtime.py` pode buscá-los para `F3_RUNTIME_DOWNLOAD_ROOT` fora do projeto. Forneça separadamente o WordPress e os instaladores. O script de mínimos PHP 8.1 e os auxiliares antigos de navegador são históricos: não constituem prova da matriz atual nem substituem os hashes certificados.

Copie `tools/dependencies.example.json` (isolado) ou `tools/integrated-dependencies.example.json` (integrado), trocando somente os caminhos pelos artefatos correspondentes. O runner verifica os hashes. Para diretório, o hash é SHA-256 da sequência ordenada de caminho relativo UTF-8, byte zero e SHA-256 binário de cada arquivo. Dependências sempre ficam fora da árvore fonte.

```sh
python3 tools/lab.py --manifest /caminho/manifest-isolado.json --workdir /caminho/lab-novo --order linkedin-only
python3 tools/lab.py --manifest /caminho/manifest-integrado.json --workdir /caminho/lab-upgrade-novo --order linkedin-integrated --origin upgrade
```

O segundo comando usa a base imutável LinkedIn 0.5.0 e os pacotes recebidos Core 1.47.0, MCP 0.26.1, Google 0.17.0 e Meta 0.4.1. O laboratório cria seu banco e processos descartáveis, intercepta saída HTTP/e-mail e encerra apenas seus próprios processos. Não use um diretório de laboratório já existente.

Para acrescentar as oito verificações reais de navegador ao cenário limpo, instale Playwright em dependência externa, defina `NODE_PATH` para seu `node_modules`, `F3_CHROMIUM` para o executável Chromium verificado e acrescente `--ui`. `tests/native/ui060.cjs` testa HTML e JavaScript servidos pelo WordPress, introspecção, seleção de regra, concessão/revogação persistentes e ajuda. As capturas produzidas são apenas auxiliares locais de inspeção, não parte dos artefatos desta entrega. `--ui-only` executa o cenário de interface separadamente. Os demais modos multi-provider/DOM do runner foram herdados e não compõem as contagens certificadas da 0.6.0.

## Evidências e limites

Instalação limpa isolada: 86 verificações aprovadas. Atualização direta com os quatro acompanhantes: 119 aprovadas. Navegador: oito aprovadas, sem erro de JavaScript. As contagens são execuções por cenário, com regressões comuns, não casos únicos somáveis. `evidence/clean`, `evidence/upgrade`, `evidence/site-teste-060.json` e `evidence/mcp-documentation-060.json` identificam exatamente as provas.

Site-Teste: WordPress 7.1.3/PHP 8.3.36, 0.5.0→0.6.0 aplicada, backup, sondas de página/REST 200, manutenção preservada, 11 verificações simuladas e oito autotestes. Escritas via ability MCP e via rota REST administrativa apresentam antes/depois no Registro central. A rota foi chamada internamente com usuário autorizado; isso não é aceite manual do dono no navegador. Catálogo de 79 abilities; 19 documentos lidos integralmente em 20 páginas via MCP, idênticos ao instalador.

`tools/site-qa-060.php` é auxiliar temporário exclusivo do Site-Teste autorizado com configuração LinkedIn vazia; exige administrador, intercepta toda a rede/e-mail e limpa apenas dados próprios. Foi removido após a prova. Referências centrais de auditoria sintética e backups das operações permanecem, sem credenciais/PII. Nunca instalar esse auxiliar em produção ou deixá-lo ativo. O auxiliar 0.5.0 é histórico.

A entrega tem pendências: aprovação `rw_conversions` e aceite real; definição pelo Core dos IDs browser/server; contrato de auditoria do MCP para principal de serviço; contagens de seguidores reais; conferência autenticada das telas LinkedIn e aceite de conexão pelo dono. PHP 8.1.2/WordPress 6.4 são mínimos herdados, não exercitados nesta rodada. Veja o relatório e os impactos vigentes; não considere a integração dupla Insight Tag/CAPI homologada.

## Fechamento

Prepare a pasta `wp-mcp-linkedin-fator3-0.6.0-fonte` e execute `python3 tools/package-source.py --output-dir /caminho/fora-do-fonte`. O script recusa sobrescrever uma fonte fechada. O relatório interno é a cópia anterior ao fechamento e não contém o hash circular deste próprio ZIP; bytes e SHA-256 finais constam somente do relatório externo canônico.
