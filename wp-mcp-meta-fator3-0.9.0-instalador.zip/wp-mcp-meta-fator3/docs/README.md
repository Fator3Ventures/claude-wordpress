# Fator3 MCP Meta 0.9.0

Plugin independente. Configure em Ferramentas > Fator3 MCP Meta. Entradas humanas (painel, REST, abilities/MCP, arquivos e tarefas iniciadas por usuário) exigem `manage_options`. A lista legada `users` não concede acesso a pessoas sem essa capacidade. O transporte MCP é opcional; o plugin não chama Google, Core ou outro provedor para executar relatórios.

## Índice instalado

- ADMINISTRATION.md — abas, seletores e fluxos de administração.
- AGENTS.md — operação por agentes e limites de autorização.
- CONFIGURATION.md — tokens, seleção e acesso.
- OPERATIONS.md — consultas, processamento e exportações.
- CONTRACTS.md — contratos, REST/MCP, schemas e erros.
- SDK-PHP.md — SDK local e responsabilidade de consumidores.
- SECURITY.md — isolamento, dados e autorização.
- MIGRATION.md — atualização, retenção e rollback.
- PAGE-VIEWS.md — campo de visualizações do perfil e limites de validação.
- PAGE-DIAGNOSTICS.md — diagnóstico de permissões e insights por Página.
- TROUBLESHOOTING.md — diagnóstico, limites e falhas.
- CHANGELOG.md — alterações da versão.
- WORKER.md — fila, recuperação, diagnóstico somente leitura (`meta/health`) e alertas.
- abilities-pt-br.json — rótulos e descrições das 35 habilidades, gerados do registro.
- input-schemas.json e output-schema.json — contratos gerados pelo build.

Todos estes arquivos integram o instalador e o conteúdo retornado por `meta/documentation`. Consulte `{"document":"index"}`. Para ler um documento use `document`, `offset` (bytes) e `limit_bytes` (256–65536). Continue por `next_offset`, repetindo `expected_revision` igual a `revision`. Concatene `content` sem separadores; confira o SHA-256 integral indicado. O cursor documental não faz HTTP, não migra armazenamento, não grava auditoria nem lê caminhos arbitrários. A resposta identifica slug, versão, origem local, tamanho e hash. O painel usa a mesma operação.

## Instalação e dependências

WordPress 6.4+, PHP 8.1.2+ de 64 bits (mínimos exercitados na 0.7.0: WordPress 6.4 com PHP 8.1.2, sem Abilities API; e WordPress 7.1.3 com PHP 8.3.6), MySQL/MariaDB com InnoDB e bloqueios nomeados, criptografia sodium ou AES-256-GCM, HTTPS externo e WP-Cron ou cron real. Abilities exigem a API de abilities disponível; em WordPress sem ela o painel e REST continuam operando. Instale o ZIP instalador; o ZIP fonte é para desenvolvimento. Consulte o relatório da entrega para a matriz de versões efetivamente testadas.

Tokens nunca são retornados por APIs de configuração. Configuração local, teste com respostas simuladas e homologação externa são estados distintos. Acesso real depende de produtos, permissões, ativos e versões liberados pelo fornecedor.

## Habilidades em português — Pedido 12

Os rótulos e descrições são definidos pelo Meta e exibidos pelo MCP em Clientes conectados, no filtro Habilidade do Registro e na descoberta. Por exemplo: `meta/save-schedule` aparece como “Meta: salvar agenda de coleta”. Os identificadores técnicos permanecem iguais para preservar perfis e integrações. Leia `abilities-pt-br.json` pela operação documental para o mapeamento completo.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.

## Novidades da 0.7.0

- `meta/health` (nova, leitura): o mesmo diagnóstico de `meta/status` sem rearmar o worker, sem e-mail e sem chamar a Meta. Grava apenas a linha de auditoria local, como toda operação despachada. O perfil de leitura do Fator3 MCP pode usá-la; `meta/status` continua exigindo escrita local porque recupera o worker.
- Recuperação: a manutenção horária `f3_meta_maintenance` é recriada na requisição seguinte se desaparecer do cron; o diagnóstico mostra `maintenance_missing` enquanto isso.
- Carregamento: nenhuma consulta SQL própria do pacote por requisição depois da primeira (marcas em autoload e migração confirmada); um registro de coleta que a chave atual do site não abre fica marcado `unreadable`, não bloqueia a migração dos demais e sai da seleção da retenção, e aparece como `queue_record_unreadable`.
- Registro (`meta/audit`): eventos do mais recente ao mais antigo, com filtro opcional `since` (Unix, segundos).
- 35 operações públicas: as 33 anteriores, com identificadores, rótulos e schemas preservados (exceto o campo opcional `since` em `meta/audit`), e `meta/health`.


## Entrega 0.9.0

Base direta 0.8.0. Pedido 15 entregue: credenciais conferidas antes da escrita, campos orientados, identidade visível e agendas regravadas atomicamente. Leia CONFIGURATION.md para fluxo de troca e CONTRACTS.md para meta/switch-identity. São 35 operações administrativas. A disponibilidade de métricas reais depende do token, ativos e permissões homologados pelo operador.
