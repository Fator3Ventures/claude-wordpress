# Administração por assunto — 0.9.0

Abra Ferramentas > Fator3 MCP Meta. Cada aba tem endereço próprio com `tab`, pode ser recarregada e respeita Voltar/Avançar do navegador. Os controles comuns usam a mesma seleção em Relatórios, Coletas, Histórico (Meta) e Diagnóstico.

1. Conexão: nome, credenciais, validade UTC, retenção e usuários pelo nome. Abertura lê conexões locais; os nomes de usuários têm estado próprio de carregamento. Identificador interno é automático.
2. Ativos: escolha uma conexão. Carregue nomes selecionados e/ou ativos disponíveis por canal; use carregar mais quando indicado. Novos resultados não são marcados automaticamente. Marque e salve. LinkedIn: salve contas de formulários antes de descobrir os respectivos formulários; depois marque-os e salve novamente.
3. Relatórios: conexão, canal e conta pelo nome; relatório e campos em português; mídias/publicações/vídeos por seletor, campanhas por caixas. Defina datas quando exigidas. Consultar página não cria coleta. Próxima página preserva a seleção original. Stories são capturados em conjunto conforme o relatório existente. Zero é valor; ausência, recusa e múltiplos buckets continuam distintos.
4. Coletas: criar, avançar, pausar, retomar, cancelar e baixar CSV/JSON. Use nomes nas agendas e horário UTC. O cron decide a execução efetiva. Editar nome/intervalo não altera a consulta armazenada; Nova agenda usa a seleção atual.
5. Histórico: consultar valores locais e exportar; manutenção de registros legados fica em detalhes.
6. Diagnóstico: autoteste local, estado, validação do ativo e versão avançada da API por conexão.
7. Ajuda: índice e leitura completa da documentação instalada, sem depender do transporte MCP.

Credenciais existentes não são preenchidas no navegador. Erros não apagam seleções. Quando a origem não informa um nome, a identificação fica visível apenas como referência de um item já selecionado; não é preciso digitá-la. Nomes podem repetir e não substituem as identidades internas. As áreas técnicas de diagnóstico preservam códigos do fornecedor para investigação.


## Pedido 15 — contrato de credenciais 0.9.0

`save-connection`/`rotate-token`: a candidata é validada na Meta antes de escrever. Entradas existentes são preservadas, mas valores novos inválidos agora são recusados. `save-connection`, `rotate-token` e `switch-identity` anunciam efeito remoto de leitura e efeito local de escrita; todas exigem manage_options. Identificadores anteriores não são renomeados.

Nova `meta/switch-identity`: `{connection_id, expected_revision, token, dry_run, client_id?, client_secret?, expires_at?, confirmation?}`. Simulação obrigatória com dry_run=true devolve `persisted=false`, identity, schedules, connection_revision, confirmation e confirmation_expires_in=600. Execução com dry_run=false exige a confirmation da mesma candidata/revisão. O comprovante é cifrado/autenticado e específico do site, nunca contém o token em claro. Simulação faz HTTP de leitura e a auditoria usual; não grava conexão/agenda.

Gravações de conexão retornam `persisted`, connection pública, schedules_rebased (quantidade) e schedules_requiring_review (IDs). `token_identity` inclui os nomes confirmados, validade, scopes/extra_scopes e instante da conferência; nenhum segredo é retornado. Códigos estáveis: invalid_token_format, invalid_app_id, invalid_app_secret, app_proof_required, credential_app_mismatch, credential_identity_mismatch, credential_scopes_reduced, token_rejected, token_expired, asset_access_denied, validation_limit, confirmation_mismatch, invalid_cursor/cursor_expired, revision_conflict, storage_unavailable e persistence_unconfirmed. Mensagens são em português e não reproduzem corpo bruto da Meta.

`retryable` não prova ausência de efeitos. Em persistence_unconfirmed, releia conexão, agendas e auditoria antes de repetir. A confirmação consumida na troca deixa a revisão antiga inválida. Não reenvie segredos em logs/relatórios. Formatos e exemplos completos são os schemas instalados.
