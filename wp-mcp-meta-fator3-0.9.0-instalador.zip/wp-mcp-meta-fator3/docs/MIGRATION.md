# Atualização 0.6.0 → 0.9.0

Base direta: 0.6.0. Também admite instalação nova. Use o ZIP instalador com a pasta estável `wp-mcp-meta-fator3/`; não desinstale. Faça backup de arquivos, banco e salts e confira o SHA-256 do relatório.

Sem tabela nova e sem mudança de schema (permanece 2). A atualização não altera registros, cifra, revisões, agendas, conexões, concessões nem histórico. Opções novas, criadas sob demanda: `f3_meta_queue_settled` (autoload), `f3_meta_maintenance_rearmed` e campos `unreadable`/`unreadable_total` em `f3_meta_queue_migration`. Na primeira requisição, `f3_meta_schema` e `f3_meta_history_schema` passam a autoload (só a coluna `autoload` muda). Perfis MCP existentes continuam válidos; para diagnóstico pelo perfil read use a nova `meta/health`.

Prova da troca: em nova requisição, `meta/health` com `version=0.7.0` e `state` coerente, `meta/selftest` aprovado, descoberta com 35 operações `meta/*` e `meta/documentation` com `document=index`.

Volta para a 0.6.0: arquivos da base funcionam com o mesmo banco; perdem `meta/health`, o autorreparo da manutenção e o tratamento de registro ilegível (a migração volta a parar no primeiro registro ilegível). Projeções `unreadable` permanecem e não são executadas pela 0.6.0. Restaurar arquivos não desfaz coletas nem avisos enviados.

# Histórico — atualização 0.4.1 → 0.6.0


A base direta desta release é 0.4.1. Também admite instalação nova. Use o ZIP instalador com a pasta estável `wp-mcp-meta-fator3/`; não execute a desinstalação. Faça backup dos arquivos e banco e confira o SHA-256 do relatório antes da troca.

A 0.6.0 altera rótulos e descrições das habilidades e sua documentação. Não muda schema, formato de cifra, identificadores, parâmetros, permissões, conexões, agendas, coletas ou histórico. Não exige recadastrar credenciais, reautorizar planos ou recriar perfis MCP. Os campos opcionais de agenda existentes na 0.4.1 permanecem válidos.

Após a troca, em uma nova requisição, confira `meta/status`, `meta/selftest`, a descoberta `meta/` e `meta/documentation` com `document=index`. A versão deve ser 0.6.0 e as 33 habilidades devem ter rótulos em português. Reabra Clientes conectados e Registro para carregar os textos novos.

Reversão de arquivos para a 0.4.1 restaura os rótulos anteriores. Não desfaz coletas, auditoria nem efeitos realizados após a troca. Preserve backup coordenado, salts e dados atuais; não restaure um banco antigo sobre filas vivas. Os comprovantes e limites dos testes constam no relatório da entrega.

## Histórico anterior

Na rodada anterior, 0.4.0 foi intermediária apenas no Site-Teste e 0.4.1 foi a entrega final, com correções de apresentação do diagnóstico. Isso não estabelece uma etapa intermediária para atualizar da 0.4.1 à 0.6.0.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.


## Correção 0.7.1 — registros ilegíveis

Jobs cujo ciphertext ou JSON interno não pode ser lido são isolados com `queue_state=unreadable`, sem reescrever payload, revisão, timestamps ou retenção. O worker trata também jobs já indexados; eles deixam de ocupar repetidamente as 20 posições executáveis. Migração e retenção usam a mesma trava e conferência de revisão/payload; registros legíveis, alterados concorrentemente ou com falha transitória de banco não recebem essa marca.

Se a agenda aponta para um job ilegível, `meta/health` e `meta/status` retornam diagnóstico degradado com `schedule_job_unreadable` e nome da agenda. Health continua sem reparo operacional e status mantém a recuperação explícita do evento. O aviso de ilegibilidade permanece no diagnóstico, fora do e-mail horário. `queue_record_unreadable` informa a contagem já isolada.

A restauração dos salts ou a reparação de dados exige avaliação do administrador. Registros isolados não voltam automaticamente à fila e não são apagados pela retenção; não há reautorização ou exportação automática de conteúdo ilegível.

## Entrada da 0.9.0

Atualização direta da 0.7.1 e instalação limpa. Sem novo schema ou migração de dados. Manter credenciais, salts, concessões, agendas e backups. Registros unreadable continuam preservados e não são reabertos automaticamente. Restaurar arquivos para 0.7.1 reintroduz a janela de duas leituras; não reverte dados, cron ou auditoria.


## Atualização 0.8.0 → 0.9.0

Não altera schema, tabelas, options, credenciais, agendas ou dados ao instalar. O novo comportamento ocorre numa gravação administrativa. Conexões antigas sem prova podem continuar a consultar; novas credenciais exigem App ID/secret e validação. Rollback de arquivos não desfaz trocas de credencial/agendas; a 0.8.0 não oferece a nova validação nem confirmação. Preservar dados e usar backup verificável, sem desinstalar para voltar.
