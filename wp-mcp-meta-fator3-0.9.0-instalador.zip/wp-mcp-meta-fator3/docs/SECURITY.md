# Segurança e dados — 0.9.0

Credenciais, resultados, cursores, diários e exportações são cifrados com chave derivada dos salts do site e do blog. Backup deve incluir banco e salts. Não há URL pública de exportação. Nunca coloque tokens em tickets, documentação ou capturas de tela. Trocar salts pode tornar os dados cifrados ilegíveis.

Ativos vazios significam nenhum ativo autorizado. Todas as entradas humanas exigem manage_options. Tarefas revalidam o usuário de origem, concessão do transporte, seleção e contexto antes do HTTP e antes da entrega persistente. Revogação suspende a coleta e impede leitura local. SDK de consumidor explicitamente concedido não depende de usuário WordPress autenticado.

HTTP usa hosts fixos, caminhos permitidos, TLS, nenhuma redireção, limite de tempo/bytes e quota local por conexão. Dados da API nunca são interpretados como instruções ou caminhos executáveis. CSV neutraliza prefixos de fórmula. Auditoria guarda operação, identidade e código; não guarda token, secret ou payload de leads.

Desativação e desinstalação preservam dados cifrados; removem somente cron deste plugin. Remoção definitiva de dados exige procedimento administrativo deliberado com backup. Não há limpeza automática de dados de outros plugins.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.


## Pedido 15 — contrato de credenciais 0.9.0

`save-connection`/`rotate-token`: a candidata é validada na Meta antes de escrever. Entradas existentes são preservadas, mas valores novos inválidos agora são recusados. `save-connection`, `rotate-token` e `switch-identity` anunciam efeito remoto de leitura e efeito local de escrita; todas exigem manage_options. Identificadores anteriores não são renomeados.

Nova `meta/switch-identity`: `{connection_id, expected_revision, token, dry_run, client_id?, client_secret?, expires_at?, confirmation?}`. Simulação obrigatória com dry_run=true devolve `persisted=false`, identity, schedules, connection_revision, confirmation e confirmation_expires_in=600. Execução com dry_run=false exige a confirmation da mesma candidata/revisão. O comprovante é cifrado/autenticado e específico do site, nunca contém o token em claro. Simulação faz HTTP de leitura e a auditoria usual; não grava conexão/agenda.

Gravações de conexão retornam `persisted`, connection pública, schedules_rebased (quantidade) e schedules_requiring_review (IDs). `token_identity` inclui os nomes confirmados, validade, scopes/extra_scopes e instante da conferência; nenhum segredo é retornado. Códigos estáveis: invalid_token_format, invalid_app_id, invalid_app_secret, app_proof_required, credential_app_mismatch, credential_identity_mismatch, credential_scopes_reduced, token_rejected, token_expired, asset_access_denied, validation_limit, confirmation_mismatch, invalid_cursor/cursor_expired, revision_conflict, storage_unavailable e persistence_unconfirmed. Mensagens são em português e não reproduzem corpo bruto da Meta.

`retryable` não prova ausência de efeitos. Em persistence_unconfirmed, releia conexão, agendas e auditoria antes de repetir. A confirmação consumida na troca deixa a revisão antiga inválida. Não reenvie segredos em logs/relatórios. Formatos e exemplos completos são os schemas instalados.
