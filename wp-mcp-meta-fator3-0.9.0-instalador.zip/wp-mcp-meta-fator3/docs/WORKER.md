# Coletas, recuperação e alertas — 0.9.0

Pedidos MCP Meta 13 e 14. Há 33 operações públicas; nomes e schemas de entrada são preservados.

## Estado e efeitos

`meta/status` exige administrador e, pelo MCP, perfil maintenance ou custom com a operação autorizada. Os perfis read/content não permitem esta escrita local. Metadados: mode=write, readonly=false, local_effect=write, remote_effect=none. O estado observado aparece em `state` (ok/degraded), `issues`, `observed_at` e `cron.observed_next`. Se faltar evento e houver agenda ativa, coleta queued/retry (inclusive futura) ou migração pendente, tenta rearmar o worker. `recovery.attempted/scheduled/code` e `cron.next` mostram o resultado, sem ocultar a degradação inicialmente observada. A consulta seguinte pode retornar ok. Não executa uma coleta, não muda o proprietário de agendas e não consulta o fornecedor; também mantém a auditoria local existente. O efeito de reparo é exceção explicitamente solicitada à regra comum de diagnóstico somente leitura.

`queue.oldest_due_lag_seconds` informa atraso em segundos da coleta queued/retry vencida mais antiga, ou zero sem vencidas; `oldest_due_at` é null sem vencidas. Durante a migração o atraso cobre apenas registros já indexados; `migration_pending=true` sinaliza cobertura incompleta. `audit_health` trata apenas auditoria e não substitui `state`.

A aba Diagnóstico carrega esse estado e contém botão para atualizar. Problemas mostram nome/ID da agenda, código e ação. Agenda ativa cujo next_at venceu há mais de duas vezes interval_minutes × 60 é degradada. Autorização recusada no last_code da agenda ou de sua última coleta também degrada; confira os ativos e salve novamente a agenda pela concessão atual autorizada. O alerta só desaparece quando a passagem seguinte comprova a retomada. Trocar concessão OAuth não transfere propriedade nem libera resultados antigos.

## Recuperação

Manutenção horária `f3_meta_maintenance` confere o evento antes da retenção e novamente ao sair. O worker pré-agenda a próxima passagem e repete a conferência em finally, inclusive após exceção. A gravação do evento usa retorno WP_Error e confirmação de presença; últimas tentativa/falha ficam em cron.last_schedule_attempt/last_schedule_failure, sem mensagens com segredos. A falha histórica permanece após recuperar, mas não mantém o estado degradado se o problema atual foi resolvido. Há trava de banco para impedir passagens concorrentes e outra para o reagendamento.

O cron precisa ser acionado pelo servidor ou tráfego. O watchdog horário é a recuperação programada até a próxima manutenção efetivamente executada, não uma garantia de relógio se todo o cron estiver parado. Uma nova consulta de status também pode recuperar. Verifique o agendador do servidor quando nenhum hook roda. WP-Cron usa uma lista global: escrita concorrente por código alheio ainda pode apagar um evento após a conferência; o watchdog reduz a falha persistente, sem prometer atomicidade global do WordPress.

## Fila e migração

Schema 2 adiciona `queue_state`, `queue_next` e índice `runnable(bucket,queue_state,queue_next,record_key)` na tabela de registros. Apenas estado técnico e vencimento ficam nessa projeção; consulta, resultado e identidade continuam cifrados. A mesma instrução CAS grava payload e projeção. O worker seleciona até 20 candidatos, por duas buscas indexadas limitadas (queued/retry), ordenadas por next_at e chave. Não percorre coletas concluídas. Revalida estado, prazo e autoridade sob a trava da coleta. Agendas vencidas são materializadas antes dessa seleção; orçamento de 22 segundos entre coletas, com orçamento HTTP de cada coleta preservado.

A base 0.5.0 é migrada em lotes de 100 registros por passagem/entrada durante o bootstrap, sem alterar ciphertext, revisão, retenção ou identidade. Registros novos entram imediatamente no índice; migração pendente mantém o worker necessário. Falha de cifra/banco não é convertida em sucesso: progresso para e diagnóstico segue degradado. Não apague registros para destravar; preserve banco e salts e corrija a causa. Retenção remove a projeção junto do registro, sem índice separado órfão.

## E-mail operacional

Worker e manutenção enviam problemas atuais (worker ausente, atraso de agenda, autorização) ao `admin_email` configurado em Configurações → Geral do WordPress. O status não envia e-mail. Conteúdo: endereço do site, nome/ID da agenda e ação; sem token, concessão opaca, payload ou dados coletados. Não há destinatário de cliente nem envio ao fornecedor. Uma trava e uma reserva persistida limitam a uma tentativa por hora por site, inclusive após falha; enquanto houver problema o aviso pode se repetir na hora seguinte. `notification.state=accepted` significa que wp_mail aceitou, não entrega comprovada. `failed/sending` exigem conferir o serviço de e-mail. Não há confirmação de leitura ou retry imediato.

## Atualização e reversão

Instale o ZIP 0.6.0 sobre a 0.5.0; não desinstale. Migração aditiva preserva dados. Backup de arquivos não cobre banco; guarde backup de banco e salts. Voltar aos arquivos 0.5.0 conserva colunas extras, mas perde fila indexada, alertas e recuperação. A 0.5.0 redefine seu marcador schema=1 no bootstrap; ao voltar à 0.6.0, projeções são reconstruídas e a migração pode ficar pendente. Não há promessa de execução de jobs durante downgrade; pause o cron durante a troca e verifique o estado depois. Nenhum rollback desfaz consultas/avisos já executados.

## Mudanças da 0.7.0

`meta/health` devolve o mesmo estado observado (`state`, `issues`, `queue`, `cron`, `notification`) e ainda `maintenance.next/last` e `repair=not_attempted`. Não rearma eventos, não envia e-mail e não chama a Meta. Como toda operação despachada (exceto a leitura documental), grava uma linha no registro de auditoria local (`meta/audit`, retenção de 30 dias) e mantém `f3_meta_audit_health`; não altera configuração, fila, agendas nem credenciais. O perfil read do MCP permite a chamada. Para recuperar, use `meta/status` (perfil maintenance ou custom com a operação) ou aguarde a manutenção horária.

A manutenção horária é conferida em `init` (prioridade 20): se `f3_meta_maintenance` não estiver no cron, é reagendada para 5 minutos depois, sob trava de banco; a opção `f3_meta_maintenance_rearmed` guarda o último reagendamento. Diagnóstico `maintenance_missing` enquanto o evento falta.

Migração da fila: registros de coleta ilegíveis recebem `queue_state=unreadable` e entram em `queue.unreadable_jobs` e na issue `queue_record_unreadable`; os demais seguem migrando em lotes de 100. Esses registros não são executados nem apagados automaticamente e saem da seleção da retenção, que continua para os demais (um registro ilegível encontrado pela retenção também é marcado `unreadable`). Confira as chaves (salts) do wp-config; restaurar a chave correta e reconstruir as projeções (troca de schema) devolve o estado real. Depois de confirmada a migração, a marca `f3_meta_queue_settled=2` (autoload) dispensa a consulta de migração; `f3_meta_schema` e `f3_meta_history_schema` também passam ao autoload na primeira requisição. Resultado: nenhuma consulta SQL própria do pacote no carregamento de uma requisição comum. Um retorno à 0.5.0 e nova atualização apaga a marca e reconstrói as projeções.

O e-mail operacional não inclui `queue_migration_pending`, `queue_record_unreadable` nem `maintenance_missing`.


## Correção 0.7.1 — registros ilegíveis

Jobs cujo ciphertext ou JSON interno não pode ser lido são isolados com `queue_state=unreadable`, sem reescrever payload, revisão, timestamps ou retenção. O worker trata também jobs já indexados; eles deixam de ocupar repetidamente as 20 posições executáveis. Migração e retenção usam a mesma trava e conferência de revisão/payload; registros legíveis, alterados concorrentemente ou com falha transitória de banco não recebem essa marca.

Se a agenda aponta para um job ilegível, `meta/health` e `meta/status` retornam diagnóstico degradado com `schedule_job_unreadable` e nome da agenda. Health continua sem reparo operacional e status mantém a recuperação explícita do evento. O aviso de ilegibilidade permanece no diagnóstico, fora do e-mail horário. `queue_record_unreadable` informa a contagem já isolada.

A restauração dos salts ou a reparação de dados exige avaliação do administrador. Registros isolados não voltam automaticamente à fila e não são apagados pela retenção; não há reautorização ou exportação automática de conteúdo ilegível.

## Isolamento na 0.9.0

A rotina adquire a trava do job, lê revisão e payload uma vez, decodifica esse payload e compara os mesmos bytes/revisão no UPDATE. Não mistura a decisão de corrupção de uma segunda leitura com o snapshot da primeira. Isso protege inclusive o ciclo de alteração/restauração de um gravador externo que não respeite a trava consultiva. Apenas a projeção muda. O teste é sintético e não prova frequência desse cenário em produção.
