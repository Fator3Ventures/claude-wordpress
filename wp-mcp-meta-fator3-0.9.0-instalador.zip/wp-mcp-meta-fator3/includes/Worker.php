<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

final class Worker {
    private const AUTH_CODES=['not_authorized','grant_revoked','credential_revoked','authorization_revoked','asset_access_denied','revision_conflict','credential_revalidation_required'];
    public static function ensure(int $delay=60): bool {
        if(Schedules::active()||Queue::waiting())return Jobs::scheduleTick($delay);
        return true;
    }
    /** Runs on plugins_loaded: no SQL once the migration is confirmed complete under schema 2. */
    public static function bootstrap(): void {
        if(Queue::settled())return;
        if(Queue::pending()){Result::run(static fn()=>Queue::migrate());self::ensure();}else Queue::markSettled();
    }
    public static function maintenance(): void {
        // Recovery must precede retention, whose failure cannot break the chain.
        $recovery=Result::run(static fn()=>['scheduled'=>self::ensure()]);
        try{Result::run(static fn()=>Queue::migrate());$prune=Result::run(static fn()=>['removed'=>Store::prune()]);}
        finally{Result::run(static fn()=>['scheduled'=>self::ensure()]);self::notifySafely();}
        update_option(Config::KEY.'_last_maintenance',['at'=>time(),'recovery'=>$recovery['success'],'retention_code'=>$prune['code']],false);
    }
    public static function health(): array {
        $now=time();$queue=Queue::health();$issues=[];$active=0;
        foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];if(empty($v['enabled']))continue;$active++;
            $common=['schedule_id'=>$r['key'],'label'=>$v['label']??$r['key']];$code=$v['last_code']??null;
            // A grant may be revoked after the schedule creates its job.
            if(!empty($v['last_job'])){try{$job=Store::get('job',$v['last_job']);if($job&&in_array($job['value']['last_code']??null,self::AUTH_CODES,true))$code=$job['value']['last_code'];}
                catch(Fault $e){if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;$issues[]=$common+['code'=>'schedule_job_unreadable','action'=>'A última coleta desta agenda está ilegível. Confira as chaves (salts) e a integridade do registro; seus dados foram preservados.'];}}
            if(in_array($code,self::AUTH_CODES,true))$issues[]=$common+['code'=>'schedule_authorization_failed','last_code'=>$code,'action'=>'Confira a conexão e salve novamente esta agenda com a concessão atual autorizada.'];
            $lag=max(0,$now-(int)$v['next_at']);if($lag>2*60*(int)$v['interval_minutes'])$issues[]=$common+['code'=>'schedule_overdue','lag_seconds'=>$lag,'action'=>'Confira o cron e a autorização da agenda.'];
        }
        $next=wp_next_scheduled(Config::KEY.'_worker')?:null;$needed=$active>0||Queue::waiting();
        if($needed&&$next===null)$issues[]=['code'=>'worker_missing','action'=>'Rearmar o worker local e conferir o cron do servidor.'];
        if($queue['migration_pending'])$issues[]=['code'=>'queue_migration_pending','action'=>'Aguarde as passagens do worker; consulte a migração se não houver progresso.'];
        if(!wp_next_scheduled(Config::KEY.'_maintenance'))$issues[]=['code'=>'maintenance_missing','action'=>'A manutenção horária é recriada na próxima requisição do site; confira o cron do servidor.'];
        if($queue['unreadable_jobs']>0)$issues[]=['code'=>'queue_record_unreadable','count'=>$queue['unreadable_jobs'],'action'=>'Há coletas cifradas que a chave atual do site não abre. Confira as chaves (salts) do wp-config; esses registros não são executados nem apagados automaticamente.'];
        return ['state'=>$issues?'degraded':'ok','observed_at'=>$now,'issues'=>$issues,'active_schedules'=>$active,'worker_required'=>$needed,'cron'=>['next'=>$next,'last'=>get_option(Config::KEY.'_last_worker',null),'traffic_required'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON),'last_schedule_attempt'=>get_option(Config::KEY.'_worker_schedule_attempt',null),'last_schedule_failure'=>get_option(Config::KEY.'_worker_schedule_failure',null)],'queue'=>$queue,'notification'=>get_option(Config::KEY.'_operation_notice',null)];
    }
    /** Read-only observation for meta/health: same diagnosis as status, never repairs, schedules or sends e-mail. */
    public static function observe(): array {
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown'),'maintenance'=>['next'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null,'last'=>get_option(Config::KEY.'_last_maintenance',null)],'repair'=>'not_attempted']+self::health();
    }
    public static function status(): array {
        $h=self::health();$observed=$h['cron']['next'];$attempted=$h['worker_required']&&$observed===null;
        $repair=$attempted?Result::run(static fn()=>['scheduled'=>Jobs::scheduleTick()]):null;
        $h['cron']['observed_next']=$observed;$h['cron']['next']=wp_next_scheduled(Config::KEY.'_worker')?:null;
        $h['recovery']=['attempted'=>$attempted,'scheduled'=>$attempted?($repair['data']['scheduled']??false):null,'code'=>$repair['code']??null];
        $h['cron']['last_schedule_attempt']=get_option(Config::KEY.'_worker_schedule_attempt',null);$h['cron']['last_schedule_failure']=get_option(Config::KEY.'_worker_schedule_failure',null);
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown')]+$h;
    }
    public static function notifySafely(): void {Result::run(static function(){self::notify();return [];});}
    public static function notify(): void {
        Store::lock('operation-notice',static function(){
            $h=self::health();$issues=array_values(array_filter($h['issues'],static fn($i)=>!in_array($i['code'],['queue_migration_pending','queue_record_unreadable','schedule_job_unreadable','maintenance_missing'],true)));
            if(!$issues)return;
            $old=get_option(Config::KEY.'_operation_notice',[]);$now=time();
            // Site-wide throttle, including failures/uncertain sends, prevents per-minute storms.
            if($now-(int)($old['attempted_at']??0)<3600)return;
            $notice=['attempted_at'=>$now,'state'=>'sending','issue_count'=>count($issues)];
            update_option(Config::KEY.'_operation_notice',$notice,false);
            if(get_option(Config::KEY.'_operation_notice')!==$notice)return;
            $to=sanitize_email((string)get_option('admin_email',''));$lines=['Fator3 MCP Meta: a coleta requer atenção.',home_url('/'),''];
            foreach($issues as $i)$lines[]=($i['label']??'Worker').' ('.($i['schedule_id']??'cron').'): '.$i['action'];
            $lines[]='Abra Ferramentas → Fator3 MCP Meta → Diagnóstico. Nenhuma concessão foi renovada automaticamente.';
            $sent=false;try{if(is_email($to))$sent=wp_mail($to,'Fator3 MCP Meta: atenção às coletas',implode("\n",$lines));}catch(\Throwable $e){$sent=false;}
            $notice['state']=$sent?'accepted':'failed';$notice['finished_at']=time();update_option(Config::KEY.'_operation_notice',$notice,false);
        });
    }
}
