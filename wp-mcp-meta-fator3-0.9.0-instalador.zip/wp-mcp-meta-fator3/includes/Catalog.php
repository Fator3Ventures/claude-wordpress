<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;
/** Explicit catalogue. A listed field is not a claim of entitlement for a given asset. */
final class Catalog {
    public const REVISION='2026-10-21.1';
    public static function reports(): array {return ['profile','media','stories','account_insights','media_insights','audience','page_profile','page_insights','page_posts','post_insights','page_videos','video_insights','page_audience','page_ratings','stories_insights'];}
    public static function channel(string $report): string {return str_starts_with($report,'page_')||in_array($report,['post_insights','video_insights'],true)?'facebook':'instagram';}
    public static function fields(string $report,string $version='v24.0'): array {
        $lists=[
            'profile'=>['id','username','name','biography','website','followers_count','follows_count','media_count','profile_picture_url'],
            'media'=>['id','caption','media_type','media_product_type','timestamp','permalink','like_count','comments_count'],
            'stories'=>['id','media_type','media_product_type','timestamp','permalink'],
            'account_insights'=>['reach','views','accounts_engaged','total_interactions','likes','comments','shares','saves','profile_links_taps','follows_and_unfollows','follower_count','online_followers'],
            'media_insights'=>['reach','views','likes','comments','shares','saved','total_interactions','ig_reels_video_view_total_time','ig_reels_avg_watch_time','replies','navigation'],
            'stories_insights'=>['reach','views','replies','navigation'],
            'audience'=>['follower_demographics','engaged_audience_demographics','reached_audience_demographics'],
            'page_profile'=>['id','name','about','category','fan_count','followers_count','link','website'],
            'page_posts'=>['id','message','created_time','permalink_url','shares','reactions.summary(true)','comments.summary(true)'],
            'page_videos'=>['id','title','description','created_time','permalink_url','length'],
            'page_ratings'=>['created_time','recommendation_type','review_text'],
            'page_insights'=>['page_media_view','page_total_media_view_unique','page_post_engagements','page_daily_follows','page_daily_unfollows','page_follows','page_views_total'],
            'post_insights'=>['post_media_view','post_media_view_unique','post_clicks','post_reactions_by_type_total'],
            'video_insights'=>['total_video_views','total_video_views_unique','total_video_view_total_time','total_video_avg_time_watched'],
            'page_audience'=>['page_fans_city','page_fans_country','page_fans_gender_age']
        ];
        if(!isset($lists[$report]))throw new Fault('unsupported','Relatório não suportado.');
        $out=[];foreach($lists[$report] as $f){
            $snapshot=in_array($report,['profile','page_profile','media_insights','stories_insights','post_insights','video_insights','audience','page_audience'],true);
            $conditional=in_array($f,['follower_count','online_followers'],true)||self::channel($report)==='facebook';
            $out[]=['name'=>$f,'source_field'=>$f,'catalog_revision'=>self::REVISION,'api_version'=>$version,'api_family'=>self::channel($report),'availability'=>'requires_remote_validation','compatibility'=>$version==='v24.0'?'catalogued_candidate':'version_not_validated','conditional'=>$conditional,'periods'=>$snapshot?['lifetime']:['day'],'metric_type'=>in_array($f,['follower_count','online_followers'],true)?'time_series':'total_value','breakdowns'=>$f==='follows_and_unfollows'?['follow_type']:($report==='audience'?['country','city','age','gender']:[]),'timeframes'=>$report==='audience'?self::timeframes($f,$version):[],'timeframe_evidence'=>$f==='engaged_audience_demographics'&&$version==='v24.0'?'observed_constraint_Pedidos_MCP_Meta_3':'requires_remote_validation','media_types'=>in_array($report,['media_insights','stories_insights'],true)?['provider_conditional']:[],'availability_reason'=>$f==='page_views_total'?'Métrica de visualizações do perfil; confirme a disponibilidade nesta versão e Página. Recusas da Graph são preservadas por linha; não há substituição automática por visualizações de mídia.':null,'deprecated'=>false,'replacement'=>null,'unit'=>str_contains($f,'time')?'provider_time_unit':'provider_defined','temporal'=>$snapshot?'snapshot_or_lifetime':'provider_period','aggregation'=>in_array($f,['reach','accounts_engaged','followers_count','fan_count'],true)?'native_unique_or_snapshot':'preserve_source','historical_horizon_days'=>null,'history_requires_explicit_start'=>true];
        }return $out;
    }
    public static function timeframes(string $metric,string $version): array {
        // Recorded v24 rejection in Pedidos MCP Meta 3. Do not generalize it to other metrics/versions.
        if($metric==='engaged_audience_demographics'&&$version==='v24.0')return ['this_month','this_week'];
        return ['this_month','this_week','last_14_days','last_30_days','last_90_days','prev_month','prev_week'];
    }
    public static function validateSelection(array $c,array $i): void {
        if($i['report']!=='audience')return;
        foreach($i['fields']??['follower_demographics'] as $metric){$accepted=self::timeframes($metric,$c['api_version']);$timeframe=$i['timeframe']??(in_array('last_30_days',$accepted,true)?'last_30_days':$accepted[0]);
            if(!in_array($timeframe,$accepted,true))throw new Fault('unsupported_timeframe','Timeframe incompatível com a métrica nesta versão.',['metric'=>$metric,'api_version'=>$c['api_version'],'accepted'=>$accepted]);
        }
    }
    public static function metrics(array $i): array {
        $version=$i['api_version']??(isset($i['connection_id'])?Connections::get($i['connection_id'])['api_version']:Config::API_VERSION);if(isset($i['channel'])&&$i['channel']!==self::channel($i['report']))throw new Fault('invalid_input','Relatório de outro canal.');$fields=self::fields($i['report'],$version);
        return ['report'=>$i['report'],'channel'=>self::channel($i['report']),'catalog_revision'=>self::REVISION,'api_version'=>$version,'fields'=>$fields,'retired_or_not_exposed'=>['impressions','profile_views','website_clicks'],'live_validation_required'=>true];
    }
}
