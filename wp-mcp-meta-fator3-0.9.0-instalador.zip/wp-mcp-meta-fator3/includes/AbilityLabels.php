<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Textos públicos do Pedido MCP Meta 12; identificadores permanecem estáveis. */
final class AbilityLabels {
    public static function all(): array {
        return [
            'capabilities' => ['label' => 'Meta: consultar recursos disponíveis', 'description' => 'Lista os recursos, contratos, canais e limites disponíveis no plugin.'],
            'status' => ['label' => 'Meta: consultar estado da integração', 'description' => 'Mostra saúde, atrasos e agendas sem autorização; rearma o worker local ausente, sem consultar o fornecedor. Exige permissão de escrita local.'],
            'health' => ['label' => 'Meta: consultar saúde das coletas (somente leitura)', 'description' => 'Mostra o mesmo diagnóstico do estado (agendas atrasadas ou sem autorização, worker, fila e manutenção) sem rearmar nada, sem e-mail e sem chamar a Meta; disponível ao perfil de leitura.'],
            'selftest' => ['label' => 'Meta: executar diagnóstico local', 'description' => 'Verifica armazenamento, criptografia, permissões e contratos locais, sem validar credenciais no fornecedor.'],
            'configuration-schema' => ['label' => 'Meta: consultar campos de configuração', 'description' => 'Descreve os campos, regras de revisão e tratamento de credenciais da conexão.'],
            'contracts' => ['label' => 'Meta: consultar contratos das operações', 'description' => 'Retorna os esquemas de entrada, o formato de resposta e as capacidades das operações.'],
            'documentation' => ['label' => 'Meta: ler documentação instalada', 'description' => 'Lê o índice ou um documento local por páginas, com versão e integridade, sem consultar o fornecedor.'],
            'admin-options' => ['label' => 'Meta: listar opções dos formulários', 'description' => 'Lista usuários, ativos e objetos pelos nomes para os formulários administrativos, sem selecioná-los automaticamente.'],
            'list-connections' => ['label' => 'Meta: listar conexões', 'description' => 'Lista as conexões cadastradas com paginação, sem revelar credenciais.'],
            'get-connection' => ['label' => 'Meta: consultar conexão', 'description' => 'Mostra a configuração e a revisão de uma conexão, sem revelar credenciais.'],
            'audit' => ['label' => 'Meta: consultar registros de auditoria', 'description' => 'Lista os registros locais de operações, autores, resultados e datas, com paginação.'],
            'save-connection' => ['label' => 'Meta: salvar conexão', 'description' => 'Salva a conexão cifrada com revisão esperada. Credencial vazia mantém a atual; ativos vazios não concedem acesso.'],
            'validate-connection' => ['label' => 'Meta: validar conexão no fornecedor', 'description' => 'Consulta a identidade e as permissões no fornecedor e grava o diagnóstico da conexão ou da Página selecionada.'],
            'list-accounts' => ['label' => 'Meta: listar contas e páginas disponíveis', 'description' => 'Consulta contas e Páginas acessíveis à conexão, com continuação; a descoberta não concede acesso aos ativos.'],
            'list-fields' => ['label' => 'Meta: listar campos e métricas', 'description' => 'Descreve campos, métricas, períodos e disponibilidade para o relatório e a versão da interface selecionados.'],
            'switch-identity' => ['label'=>'Meta: trocar identidade e regravar agendas','description'=>'Confere identidade e ativos, simula a troca e exige confirmação vinculada à revisão para gravar conexão e agendas.'],
            'rotate-token' => ['label' => 'Meta: renovar credencial preservando as agendas', 'description' => 'Valida a nova credencial e preserva a autorização das agendas quando aplicativo, identidade, permissões e ativos coincidem.'],
            'history-status' => ['label' => 'Meta: consultar estado do histórico', 'description' => 'Informa estrutura, quantidade de registros e andamento da migração do histórico local.'],
            'history-migrate' => ['label' => 'Meta: migrar resultados para o histórico', 'description' => 'Avança a migração dos resultados locais já armazenados para o histórico cifrado, com retomada.'],
            'history-query' => ['label' => 'Meta: consultar histórico armazenado', 'description' => 'Consulta o histórico local por ativo, relatório e período, com paginação e autorização atual.'],
            'create-backfill' => ['label' => 'Meta: criar carga retroativa', 'description' => 'Cria uma coleta para o período passado solicitado; a cobertura disponível depende dos limites do fornecedor.'],
            'history-export' => ['label' => 'Meta: preparar exportação do histórico', 'description' => 'Cria uma exportação do histórico em CSV ou JSON; etapas posteriores processam e disponibilizam as partes.'],
            'history-export-step' => ['label' => 'Meta: processar etapa da exportação do histórico', 'description' => 'Avança uma etapa da exportação persistida e informa progresso, conclusão ou falha.'],
            'history-export-read' => ['label' => 'Meta: ler parte da exportação do histórico', 'description' => 'Lê uma parte da exportação concluída, com verificação de integridade e continuação por bytes.'],
            'query' => ['label' => 'Meta: consultar relatório', 'description' => 'Consulta uma página do relatório. Preserve a seleção e a continuação; ausência de métricas não comprova acesso integral.'],
            'create-job' => ['label' => 'Meta: criar coleta de dados', 'description' => 'Cria uma coleta persistente vinculada à identidade e à chave de repetição; execução e resultados são consultados separadamente.'],
            'list-jobs' => ['label' => 'Meta: listar coletas de dados', 'description' => 'Lista as coletas acessíveis ao usuário, com estado, progresso e paginação.'],
            'job-status' => ['label' => 'Meta: consultar andamento da coleta', 'description' => 'Informa estado, progresso, próxima execução e falhas registradas de uma coleta.'],
            'run-job' => ['label' => 'Meta: executar etapa da coleta', 'description' => 'Executa uma página da coleta persistida, grava os resultados e atualiza o progresso para retomada.'],
            'control-job' => ['label' => 'Meta: pausar, retomar ou cancelar coleta', 'description' => 'Altera o estado de uma coleta autorizada, preservando os resultados já armazenados.'],
            'job-results' => ['label' => 'Meta: ler resultados da coleta', 'description' => 'Lê uma página de resultados já armazenados de uma coleta autorizada.'],
            'save-schedule' => ['label' => 'Meta: salvar agenda de coleta', 'description' => 'Cria ou atualiza uma agenda com revisão esperada, consulta, intervalo, nome e próxima execução.'],
            'list-schedules' => ['label' => 'Meta: listar agendas de coleta', 'description' => 'Lista as agendas acessíveis ao usuário, incluindo habilitação, próxima execução e último resultado.'],
            'export' => ['label' => 'Meta: exportar resultados da coleta', 'description' => 'Prepara resultados da coleta em CSV ou JSON; resultados parciais exigem autorização explícita.'],
            'export-read' => ['label' => 'Meta: ler arquivo exportado da coleta', 'description' => 'Lê o arquivo exportado em partes autenticadas, com integridade e continuação; não cria endereço público.'],
        ];
    }
}
