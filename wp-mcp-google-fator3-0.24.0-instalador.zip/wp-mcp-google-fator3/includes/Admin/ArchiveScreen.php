<?php
/** Native forms for collection and independent reader grants. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Admin;
use Fator3\McpGoogle\{Admin,Ads\Archive,Ads\ArchiveQuery,Integration\AdsServiceApi,Integration\QueryServiceApi,Settings,Response};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class ArchiveScreen {
    public static function init(): void { add_action('admin_post_f3_google_archive',[self::class,'handle']); }
    private static function input(string $name,string $label,string $value=''): void { echo '<p><label>'.esc_html($label).' <input name="'.esc_attr($name).'" value="'.esc_attr($value).'" required></label></p>'; }
    private static function form(string $op): void { Screen::form('f3_google_archive');echo '<input type="hidden" name="archive_operation" value="'.esc_attr($op).'">'; }
    private static function datasets(array $selected): void {
        $labels=['clicks'=>'Cliques e GCLID','customer'=>'Totais da conta','campaign'=>'Campanhas','ad_group'=>'Grupos de anúncios','ad'=>'Anúncios','search_terms'=>'Termos de pesquisa','changes'=>'Histórico de alterações'];
        echo '<fieldset><legend>Dados autorizados</legend>';
        foreach($labels as $id=>$label)echo '<p><label><input type="checkbox" name="archive_datasets[]" value="'.esc_attr($id).'" '.checked(in_array($id,$selected,true),true,false).'> '.esc_html($label).'</label></p>';
        echo '</fieldset>';
    }
    private static function enabled(string $label,bool $value=false): void { echo '<p><label><input type="checkbox" name="archive_enabled" value="1" '.checked($value,true,false).'> '.esc_html($label).'</label></p>'; }
    private static function submit(string $label): void { echo '<p><button class="button button-primary">'.esc_html($label).'</button></p></form>'; }
    public static function render(): void {
        $status=Archive::status();
        echo '<section class="f3-card" id="f3-ads-archive"><h2>Acervo Google Ads</h2><p>Guarde o histórico diário das contas selecionadas. A coleta revisita dias recentes e recupera dias anteriores dentro dos limites do Google. Os dados ficam cifrados e sem expiração automática. Autorizar a coleta e permitir que outro plugin leia o acervo são ações separadas.</p>';
        foreach($status['accounts']??[] as $a)echo '<p><strong>'.esc_html($a['account_id']).'</strong> · '.esc_html($a['currency']??'').' · '.esc_html($a['time_zone']??'').' · '.esc_html($a['ready']?'Coleta autorizada':($a['reason_code']??'Pausada')).'</p>';
        self::form('collection');self::input('archive_account','Conta anunciante (10 dígitos)');self::datasets(ArchiveQuery::DATASETS);self::input('archive_backfill','Dias anteriores a recuperar (1–1125)','90');self::input('archive_revisit','Dias recentes a revisitar (1–30)','7');self::enabled('Autorizar coleta diária desta conta');self::submit('Salvar coleta');
        echo '<h3>Leitores do acervo</h3><p>Escolha os dados que cada consumidor poderá ler nesta conta. Esta permissão não concede acesso para alterar anúncios ou enviar conversões.</p>';
        $consumers=AdsServiceApi::status()['consumers'];
        if(!$consumers)echo '<p>Nenhum consumidor de acervo Ads registrado nesta instalação.</p>';
        foreach($consumers as $c){echo '<h4>'.esc_html($c['id']).'</h4>';foreach($c['grants'] as $g)echo '<p>'.esc_html($g['account_id']).' · '.esc_html($g['enabled']?'Autorizado':'Revogado').' · '.esc_html(implode(', ',$g['datasets'])).'</p>';self::form('reader');echo '<input type="hidden" name="archive_consumer" value="'.esc_attr($c['id']).'">';self::input('archive_account','Conta (selecionada também no consumidor)');self::datasets(ArchiveQuery::DATASETS);self::enabled('Permitir leitura local');self::submit('Salvar permissão do leitor');}
        echo '</section>';
    }
    public static function gsc(): void {
        echo '<section class="f3-card" id="f3-gsc-query-reader"><h2>Leitura de consultas, páginas e dias</h2><p>Autorize separadamente os consumidores que precisam das consultas de busca. Consultas anonimizadas são omitidas pelo Google; diferenças nos totais também podem decorrer dos limites da API.</p>';
        $consumers=QueryServiceApi::status()['consumers'];if(!$consumers)echo '<p>Nenhum consumidor compatível registrado.</p>';
        foreach($consumers as $c){echo '<p><strong>'.esc_html($c['id']).'</strong> · '.esc_html($c['configuration']['property']??'Propriedade pendente').'</p>';self::form('gsc');echo '<input type="hidden" name="archive_consumer" value="'.esc_attr($c['id']).'">';self::enabled('Permitir consultas por página e dia',!empty($c['grant']['enabled']));self::submit('Salvar permissão de consultas');}
        echo '</section>';
    }
    public static function handle(): void {
        Admin::guard('f3_google_archive');$op=Admin::posted('archive_operation');$i=['account_id'=>Admin::posted('archive_account'),'enabled'=>Admin::posted('archive_enabled')==='1','expected_revision'=>Admin::posted_revision()];
        // Structured allowlist is validated again by the same service used by MCP.
        $i['datasets']=isset($_POST['archive_datasets'])&&is_array($_POST['archive_datasets'])?array_values(wp_unslash($_POST['archive_datasets'])):[];
        if($op==='collection'){$i['backfill_days']=(int)Admin::posted('archive_backfill');$i['revisit_days']=(int)Admin::posted('archive_revisit');$r=Archive::configure($i);}
        elseif($op==='reader'){$i['consumer_id']=Admin::posted('archive_consumer');$r=AdsServiceApi::configure($i);}
        elseif($op==='gsc')$r=QueryServiceApi::configure(['contract'=>QueryServiceApi::CONTRACT,'consumer_id'=>Admin::posted('archive_consumer'),'enabled'=>$i['enabled'],'expected_revision'=>$i['expected_revision']]);
        else $r=Response::fail(new \WP_Error('f3_google_archive_operation','Operação inválida.'));
        Admin::require_saved($r);wp_safe_redirect(Admin::url('saved',$op==='gsc'?'gsc':'archive'));exit;
    }
}
