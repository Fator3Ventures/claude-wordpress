<?php
/**
 * Connection contexts share the current default without copying credentials.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle;
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
final class Connections {
    public const MAX_CONNECTIONS = 20;
    public const ID_PATTERN = '/^[a-z][a-z0-9_-]{0,39}$/D';
    public const LABEL_MAX_LENGTH = 100;
    public const REGISTRY = 'f3_mcp_google_connections';
    public const SERVICES = 'f3_mcp_google_services';
    public const BINDINGS = 'f3_mcp_google_bindings';
    private static string $active = 'default';
    private static array $preview = array();
    private static array $preview_secrets = array();
    public static function preview_secrets(): array {
        return self::$preview_secrets;
    }
    public static function preview_credentials( array $values, array $secrets, callable $callback ) {
        $before = self::$preview_secrets;
        self::$preview_secrets = $secrets;
        try {
            return self::preview( $values, $callback );
        }
        finally {
            self::$preview_secrets = $before;
        }
    }
    public static function preview_values(): array {
        return self::$preview;
    }
    public static function preview( array $values, callable $callback ) {
        $before = self::$preview;
        self::$preview = $values;
        try {
            return $callback();
        }
        finally {
            self::$preview = $before;
        }
    }
    public static function id(): string {
        return self::$active;
    }
    public static function registry(): array {
        $items = get_option( self::REGISTRY, array() );
        return (is_array($items)?$items:[]) + array('default'=>array('label'=>'Padrão'));
    }
    /** Fresh read for authorization: an unreadable registry cannot prove uniqueness. */
    public static function registry_verified() {
        $r = Options::stored( self::REGISTRY );
        if ( ! $r['success'] || ( $r['exists'] && ! is_array( $r['value'] ) ) ) {
            return new \WP_Error( 'f3_google_connections_read', 'Registro de conexões ilegível.' );
        }
        $items = $r['value'] ?? array();
        foreach ( $items as $id => $meta ) {
            if ( ! is_string( $id ) || ! preg_match( self::ID_PATTERN, $id ) || ! is_array( $meta ) ) {
                return new \WP_Error( 'f3_google_connections_read', 'Registro de conexões inválido.' );
            }
        }
        return $items + array('default'=>array('label'=>'Padrão'));
    }
    public static function select( string $id ) {
        if ( ! preg_match( self::ID_PATTERN, $id ) || ! isset( self::registry()[ $id ] ) ) {
            return new \WP_Error( 'f3_google_connection', 'Conexão inexistente. Consulte google/list-connections.' );
        }
        self::$active = $id;
        foreach ( Options::secret_names() as $name ) {
            add_filter( 'pre_option_' . self::option_name( $name ), array( Options::class, 'hide_secret' ), 10, 3 );
        }
        return true;
    }
    public static function run( string $id, callable $callback ) {
        $prior = self::$active;
        $selected = self::select( $id );
        if ( is_wp_error( $selected ) ) {
            return Response::fail( $selected );
        }
        try {
            return $callback();
        }
        finally {
            self::$active = $prior;
        }
    }
    public static function scoped_names(): array {
        return array( Auth\Validation::RECEIPTS, ConversionDelivery::CONFIG, ConversionDelivery::SECRET, Integration\ServiceApi::GRANTS, Integration\Ga4ServiceApi::GRANTS, Integration\QueryServiceApi::GRANTS, Integration\AdsServiceApi::GRANTS, Ads\Archive::CONFIG, Automation\Alerts::OPTION, Policy::OPTION, Auth\Candidate::SA, Auth\Candidate::OAUTH, 'f3_mcp_google_auth_ready', 'f3_mcp_google_configuration_revision', Options::AUTH_MODE, Options::SA_JSON, Options::SA_SUBJECT, Options::OAUTH_CLIENT_ID, Options::OAUTH_CLIENT_SECRET, Options::OAUTH_REFRESH_TOKEN, Options::OAUTH_EMAIL, Options::OAUTH_SCOPES, Options::ADS_DEVELOPER_TOKEN, Options::ADS_LOGIN_CUSTOMER_ID, Options::ADS_API_VERSION, Options::GA_DEFAULT_PROPERTY, Options::TOKEN_INDEX, Options::GA_ENABLED, Options::ADS_ENABLED, self::SERVICES, self::BINDINGS );
    }
    public static function option_name( string $name ): string {
        return 'default' !== self::$active && in_array( $name, self::scoped_names(), true ) ? 'f3_mcp_google_conn_' . self::$active . '_' . substr( $name, strlen( 'f3_mcp_google_' ) ) : $name;
    }
    public static function protected_names(): array {
        $names = array_merge( array( self::REGISTRY ), self::scoped_names() );
        foreach ( self::registry() as $id => $meta ) {
            if ( 'default' === $id ) {
                continue;
            }
            foreach ( self::scoped_names() as $name ) {
                $names[] = 'f3_mcp_google_conn_' . $id . '_' . substr( $name, strlen( 'f3_mcp_google_' ) );
            }
        }
        return $names;
    }
    public static function create( string $id, string $label ): array {
        if ( ! Options::authorized() ) {
            return Response::fail( new \WP_Error( 'f3_google_forbidden', 'Permissão insuficiente.' ) );
        }
        if ( ! preg_match( self::ID_PATTERN, $id ) || 'default' === $id || '' === trim( $label ) ) {
            return Response::fail( new \WP_Error( 'f3_google_connection_input', 'Informe connection_id válido e label.' ) );
        }
        $lock = Lock::acquire( 'connections-registry' );
        if ( null === $lock ) {
            return Response::fail( new \WP_Error( 'f3_google_connection_busy', 'Outra conexão está sendo criada.' ) );
        }
        try {
            $all = self::registry();
            if ( isset( $all[ $id ] ) ) {
                return Response::ok(
                    array(
                        'connection_id' => $id,
                        'created' => false,
                    )
                );
            }
            if ( count( $all ) >= self::MAX_CONNECTIONS ) {
                return Response::fail( new \WP_Error( 'f3_google_connection_limit', 'Limite de 20 conexões por site.' ) );
            }
            $all[ $id ] = array( 'label' => substr( sanitize_text_field( $label ), 0, self::LABEL_MAX_LENGTH ) );
            $result = Options::batch_verified(
                array(
                    self::REGISTRY => $all,
                    'f3_mcp_google_conn_' . $id . '_resource_policy' => array(
                        'mode' => 'restricted',
                        'services' => array(),
                    ),
                )
            );
            return $result['success'] ? Response::ok(
                array(
                    'connection_id' => $id,
                    'created' => true,
                )
            ) : $result;
        }
        finally {
            Lock::release( $lock );
        }
    }
    public static function rename(string $label,string $expected): array {
        if (!Options::authorized())return Response::fail(new \WP_Error('f3_google_forbidden','Permissão insuficiente.'));
        $label=trim(sanitize_text_field($label));
        if($label===''||strlen($label)>self::LABEL_MAX_LENGTH)return Response::fail(new \WP_Error('f3_google_connection_label','Informe um nome de conexão com até 100 bytes.'));
        $lock=Lock::acquire('connections-registry');
        if($lock===null)return Response::fail(new \WP_Error('f3_google_connection_busy','Outra conexão está sendo alterada.'));
        try {
            $all=self::registry_verified();if(is_wp_error($all))return Response::fail($all);
            $all[self::id()]['label']=$label;
            return Settings::save([self::REGISTRY=>$all],[],[],$expected)+['connection_id'=>self::id(),'label'=>$label];
        } finally {Lock::release($lock);}
    }
    /** A missing selection preserves existing installations' service availability. */
    public static function enabled( string $service ): bool {
        $services = Options::get( self::SERVICES, null );
        return ! is_array( $services ) ? 'gtm' !== $service : isset( $services[ $service ] );
    }
    public static function scopes( string $service ): ?array {
        $selected = Options::get( self::SERVICES, null );
        if ( ! is_array( $selected ) ) {
            return 'gtm' === $service ? array() : null;
        }
        $level = $selected[ $service ] ?? '';
        $base = 'https://www.googleapis.com/auth/';
        $map = array(
            'ga' => array(
                'read' => array( 'analytics.readonly' ),
                'write' => array( 'analytics.readonly', 'analytics.edit' ),
                'admin' => array( 'analytics.readonly', 'analytics.edit', 'analytics.manage.users' ),
            ),
            'gsc' => array(
                'read' => array( 'webmasters.readonly' ),
                'write' => array( 'webmasters' ),
            ),
            'ads' => array(
                'read' => array( 'adwords', 'datamanager' ),
                'write' => array( 'adwords', 'datamanager' ),
            ),
            'siteverification' => array( 'write' => array( 'siteverification' ) ),
            'sheets' => array(
                'read' => array( 'spreadsheets.readonly', 'drive.file' ),
                'write' => array( 'spreadsheets', 'drive.file' ),
            ),
            'drive' => array( 'write' => array( 'drive.file' ) ),
            'gtm' => array(
                'read' => array( 'tagmanager.readonly' ),
                'write' => array( 'tagmanager.readonly', 'tagmanager.edit.containers', 'tagmanager.edit.containerversions', 'tagmanager.publish' ),
                'admin' => array( 'tagmanager.readonly', 'tagmanager.edit.containers', 'tagmanager.delete.containers', 'tagmanager.edit.containerversions', 'tagmanager.publish', 'tagmanager.manage.users', 'tagmanager.manage.accounts' ),
            ),
        );
        return array_map( static fn ( $scope ) => $base . $scope, $map[ $service ][ $level ] ?? array() );
    }
}
