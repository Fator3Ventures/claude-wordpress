<?php
/**
 * Account-specific conversion metrics, without duplicating unsegmented totals.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\{Connections,Records,Policy};
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\Unified\Accounts;
use Fator3\McpGoogle\Unified\Catalog;
use Fator3\McpGoogle\Unified\Filters;
use Fator3\McpGoogle\Unified\Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Conversions {

	public static function fields( string $account ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return new \WP_Error( 'f3_google_ads_access', (string) ( $gate['message'] ?? 'Acesso Ads não disponível.' ) );
		}
		$cid = Accounts::resolve_one( 'ads', $account );
		if ( is_wp_error( $cid ) ) {
			return $cid;
		}
		$query  = Gaql::build( 'conversion_action', array( 'conversion_action.resource_name', 'conversion_action.name', 'conversion_action.status', 'conversion_action.primary_for_goal' ), array( "conversion_action.status != 'REMOVED'" ) );
		$result = AdsApi::search( $cid, $query, array( 'max_rows' => Options::max_rows() ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		if ( ! empty( $result['truncated'] ) ) {
			return new \WP_Error( 'f3_google_conversion_catalog_truncated', 'O catálogo de ações de conversão excedeu o limite do site. Aumente o limite de linhas para resolver nomes sem omissões.' );
		}
		$fields = array();
		$seen   = array();
		foreach ( $result['rows'] as $row ) {
			$name = (string) ( $row['conversion_action.name'] ?? '' );
			if ( '' === $name ) {
				continue;
			}
			$resource = (string) ( $row['conversion_action.resource_name'] ?? '' );
			if ( isset( $seen[ $name ] ) && $seen[ $name ] !== $resource ) {
				return new \WP_Error( 'f3_google_conversion_ambiguous', 'Mais de uma ação de conversão usa o nome "' . $name . '". Renomeie as ações para distinguir as métricas por nome.' );
			}
			$seen[ $name ] = $resource;
			foreach ( array(
				'conversions'       => 'float',
				'conversions_value' => 'currency',
			) as $metric => $kind ) {
				$fields[] = array(
					'id'                              => $metric . ':' . $name,
					'label'                           => ( 'conversions' === $metric ? 'Conversões: ' : 'Valor de conversões: ' ) . $name,
					'native'                          => 'metrics.' . $metric,
					'type'                            => 'metric',
					'kind'                            => $kind,
					'account_id'                      => $cid,
					'conversion_action_name'          => $name,
					'conversion_action_resource_name' => $resource,
					'primary_for_goal'                => (bool) ( $row['conversion_action.primary_for_goal'] ?? false ),
					'description'                     => 'Métrica segmentada por segments.conversion_action_name; preserva a semântica de metrics.' . $metric . ' da Google Ads API.',
				);
			}
		}
		return $fields;
	}

	/** Reuses Query for dates, comparison, account fanout and native field conversion. */
	public static function query( array $input ): array {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate;
		}
		$limit = $input['limit'] ?? Options::max_rows();
		if ( ! is_numeric( $limit ) || (float) $limit < 1 || floor( (float) $limit ) !== (float) $limit ) {
			return self::error( 'limit deve ser um inteiro positivo.' );
		}
		$metrics    = self::list( $input['metrics'] ?? array() );
		$dimensions = self::list( $input['dimensions'] ?? array() );
		if ( empty( $metrics ) ) {
			return self::error( 'Informe metrics.' );
		}
		foreach ( $dimensions as $dimension ) {
			$entry = Catalog::ads_resolve( $dimension );
			if ( is_wp_error( $entry ) ) {
				return Response::fail( $entry );
			}
			if ( 'segments.conversion_action_name' === ( $entry['native'] ?? '' ) || 'segments.conversion_action' === ( $entry['native'] ?? '' ) ) {
				return self::error( 'As métricas conversions:<nome> já representam ações em colunas. Remova conversion_action_name das dimensões ou use conversions nativa segmentada.' );
			}
		}
		$filters = Filters::normalize( $input['filters'] ?? array() );
		if ( is_wp_error( $filters ) ) {
			return Response::fail( $filters );
		}
		$orders = self::orders( $input['order_by'] ?? ( $input['order_bys'] ?? array() ) );
		if ( is_wp_error( $orders ) ) {
			return Response::fail( $orders );
		}
		$custom          = array();
		$common          = array();
		$base_filters    = array();
		$segment_filters = array();
		$custom_filters  = array();
		foreach ( $metrics as $metric ) {
			if ( self::custom( $metric ) ) {
				$custom[ $metric ] = self::custom( $metric );
			} else {
				$common[] = $metric;
			}
		}
		foreach ( $filters as $filter ) {
			$field      = (string) $filter['field'];
			$definition = self::custom( $field );
			if ( $definition ) {
				$custom[ $field ] = $definition;
				$custom_filters[] = $filter;
			} else {
				$entry = Catalog::ads_resolve( $field );
				if ( is_wp_error( $entry ) ) {
					return Response::fail( $entry );
				}
				$base_filters[] = $filter;
				if ( 'dimension' === $entry['type'] ) {
					$segment_filters[] = $filter;
				}
			}
		}
		foreach ( $orders as $ordering ) {
			if ( ! in_array( $ordering['field'], array_merge( $metrics, $dimensions, array( 'account_id', 'account_name', 'date_range_name' ) ), true ) ) {
				return self::error( 'Na consulta com conversões personalizadas, inclua o campo de order_by em metrics ou dimensions.' );
			}
		}
		$selectors = self::list( $input['accounts'] ?? ( $input['account_id'] ?? array() ) );
		$accounts  = Accounts::resolve_many( 'ads', $selectors );
		if ( is_wp_error( $accounts ) ) {
			return Response::fail( $accounts );
		}
		foreach ( $accounts as $account ) {
			$catalog = self::fields( (string) $account );
			if ( is_wp_error( $catalog ) ) {
				return Response::fail( $catalog );
			}
			$ids = array_column( $catalog, 'id' );
			foreach ( $custom as $id => $definition ) {
				if ( ! in_array( $id, $ids, true ) ) {
					return self::error( 'A ação de conversão "' . $definition['name'] . '" não existe no catálogo acessível da conta ' . $account . '. Consulte google/list-fields com account_id dessa conta.' );
				}
			}
		}
		$base_input              = $input;
		$base_input['connector'] = 'google-ads';
		$base_input['accounts']  = $accounts;
		$base_input['metrics']   = ! empty( $common ) ? $common : array( 'conversions' );
		$base_input['filters']   = $base_filters;
		$base_input['order_by']  = array();
		unset( $base_input['order_bys'] );
		$base_input['limit'] = Options::max_rows();
		$base                = Query::run( $base_input );
		if ( empty( $base['success'] ) ) {
			return $base;
		}
		$segment_input               = $base_input;
		$segment_input['metrics']    = array( 'conversions', 'conversions_value' );
		$segment_input['dimensions'] = array_merge( $dimensions, array( 'conversion_action_name' ) );
		$segment_input['filters']    = $segment_filters;
		$segmented                   = Query::run( $segment_input );
		if ( empty( $segmented['success'] ) ) {
			return $segmented;
		}
		if ( ! empty( $segmented['truncated'] ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_conversions_truncated', 'A consulta segmentada por ação atingiu o limite de linhas. Reduza o período/dimensões ou aumente o limite do site; não é seguro transformar ações ausentes em zero.' ),
				array(
					'truncated' => true,
					'warnings'  => $segmented['warnings'] ?? array(),
				)
			);
		}
		$base_accounts    = array_column( $base['accounts'] ?? array(), 'account_id' );
		$segment_accounts = array_column( $segmented['accounts'] ?? array(), 'account_id' );
		if ( array_diff( $base_accounts, $segment_accounts ) || ! empty( $segmented['warnings'] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_conversions_incomplete', 'Uma conta ou período falhou na consulta segmentada; as métricas por ação não podem ser tratadas como zero.' ), array( 'warnings' => $segmented['warnings'] ?? array() ) );
		}
		$base_columns  = $base['columns'];
		$base_index    = array_flip( array_column( $base_columns, 'id' ) );
		$segment_index = array_flip( array_column( $segmented['columns'], 'id' ) );
		$key_fields    = array();
		$columns       = array();
		foreach ( $base_columns as $column ) {
			if ( 'metric' !== $column['type'] ) {
				$key_fields[] = $column['id'];
				$columns[]    = $column;
			}
		}
		foreach ( $metrics as $metric ) {
			if ( isset( $custom[ $metric ] ) ) {
				$columns[] = array(
					'id'    => $metric,
					'label' => $metric,
					'type'  => 'metric',
					'kind'  => 'conversions_value' === $custom[ $metric ]['metric'] ? 'currency' : 'float',
				);
			} elseif ( isset( $base_index[ $metric ] ) ) {
				$columns[] = $base_columns[ $base_index[ $metric ] ];
			}
		}
		$pivot = array();
		foreach ( $segmented['rows'] as $row ) {
			$key  = self::key( $row, $segment_index, $key_fields );
			$name = (string) ( $row[ $segment_index['conversion_action_name'] ] ?? '' );
			foreach ( $custom as $id => $definition ) {
				if ( $name === $definition['name'] ) {
					// These two metrics are additive across actions. Common totals never enter this sum.
					$pivot[ $key ][ $id ] = ( $pivot[ $key ][ $id ] ?? 0.0 ) + (float) ( $row[ $segment_index[ $definition['metric'] ] ] ?? 0 );
				}
			}
		}
		$rows = array();
		$seen = array();
		foreach ( $base['rows'] as $row ) {
			$key = self::key( $row, $base_index, $key_fields );
			if ( isset( $seen[ $key ] ) ) {
				return self::error( 'Dimensões ambíguas geraram duas linhas para a mesma chave. Acrescente campaign_id/ad_group_id às dimensões; não somamos totais ou médias de linhas indistinguíveis.' );
			}
			$seen[ $key ]  = true;
			$custom_values = array();
			foreach ( $custom as $id => $definition ) {
				$custom_values[ $id ] = $pivot[ $key ][ $id ] ?? 0.0;
			}
			$keep = true;
			foreach ( $custom_filters as $filter ) {
				$matches = self::matches( (float) $custom_values[ $filter['field'] ], $filter );
				if ( is_wp_error( $matches ) ) {
					return Response::fail( $matches );
				}
				if ( ! $matches ) {
					$keep = false;
					break;
				}
			}
			if ( ! $keep ) {
				continue;
			}
			$line = array();
			foreach ( $columns as $column ) {
				$id     = $column['id'];
				$line[] = array_key_exists( $id, $custom_values ) ? $custom_values[ $id ] : ( $row[ $base_index[ $id ] ] ?? null );
			}
			$rows[] = $line;
		}
		$index = array_flip( array_column( $columns, 'id' ) );
		foreach ( $orders as $order ) {
			if ( ! isset( $index[ $order['field'] ] ) ) {
				return self::error( 'Campo de ordenação ausente da tabela: ' . $order['field'] . '. Inclua-o nas dimensões ou métricas.' );
			}
		}
		if ( ! empty( $orders ) ) {
			usort(
				$rows,
				static function ( $left, $right ) use ( $orders, $index ) {
					foreach ( $orders as $order ) {
						$i   = $index[ $order['field'] ];
						$cmp = $left[ $i ] <=> $right[ $i ];
						if ( 0 !== $cmp ) {
							return 'asc' === $order['direction'] ? $cmp : -$cmp;
						}
					} return 0;
				}
			);
		}
		$limit = $input['limit'] ?? Options::max_rows();
		if ( ! is_numeric( $limit ) || (float) $limit < 1 || floor( (float) $limit ) !== (float) $limit ) {
			return self::error( 'limit deve ser um inteiro positivo.' );
		}
		$limit                               = min( (int) $limit, Options::max_rows() );
		$base['truncated']                   = ! empty( $base['truncated'] ) || count( $rows ) > $limit;
		$base['columns']                     = $columns;
		$base['rows']                        = array_slice( $rows, 0, $limit );
		$base['row_count']                   = count( $base['rows'] );
		$base['request']['conversion_query'] = $segmented['request'] ?? array();
		$base['request']['aggregation']      = 'Totais comuns sem segmentação; conversões por nome obtidas separadamente e cruzadas pelas dimensões, conta e período.';
		$base['message']                     = $base['row_count'] . ' linha(s), preservando totais sem duplicar segmentos de conversão.';
		return $base;
	}

	private static function custom( string $field ): ?array {
		if ( preg_match( '/^(conversions|conversions_value):(.+)$/usD', $field, $parts ) ) {
			return array(
				'metric' => $parts[1],
				'name'   => $parts[2],
			);
		}
		return null;
	}
	private static function list( $value ): array {
		if ( is_string( $value ) || is_int( $value ) ) {
			$value = array( $value );
		}
		return is_array( $value ) ? array_values(
			array_unique(
				array_map(
					static function ( $item ) {
						return is_scalar( $item ) ? trim( (string) $item ) : '';
					},
					$value
				)
			)
		) : array();
	}
	private static function key( array $row, array $index, array $fields ): string {
		$values = array();
		foreach ( $fields as $field ) {
			$values[] = $row[ $index[ $field ] ] ?? null;
		}
		return (string) wp_json_encode( $values );
	}
	private static function orders( $value ) {
		if ( is_string( $value ) ) {
			$value = array( array( 'field' => $value ) );
		}
		if ( isset( $value['field'] ) ) {
			$value = array( $value );
		}
		if ( ! is_array( $value ) ) {
			return new \WP_Error( 'f3_google_order_by', 'order_by deve ser uma lista.' );
		}
		$out = array();
		foreach ( $value as $item ) {
			if ( is_string( $item ) ) {
				$item = array( 'field' => $item );
			}
			$direction = strtolower( (string) ( $item['direction'] ?? 'desc' ) );
			if ( ! is_array( $item ) || empty( $item['field'] ) || ! in_array( $direction, array( 'asc', 'desc' ), true ) ) {
				return new \WP_Error( 'f3_google_order_by', 'Cada ordem exige field e direction asc ou desc.' );
			}
			$out[] = array(
				'field'     => $item['field'],
				'direction' => $direction,
			);
		} return $out;
	}
	private static function matches( float $value, array $filter ) {
		$wanted = $filter['value'];
		$op     = $filter['operator'];
		if ( 'null' === $op ) {
			return false;
		} if ( 'notnull' === $op ) {
			return true;
		}
		if ( 'in' === $op ) {
			foreach ( (array) $wanted as $item ) {
				if ( ! is_numeric( $item ) ) {
					return new \WP_Error( 'f3_google_conversion_filter', 'Valores do filtro de conversão devem ser numéricos.' );
				}
			}
			return in_array( $value, array_map( 'floatval', (array) $wanted ), true );
		}
		if ( ! is_numeric( $wanted ) ) {
			return new \WP_Error( 'f3_google_conversion_filter', 'Valor do filtro de conversão deve ser numérico.' );
		}
		$wanted = (float) $wanted;
		switch ( $op ) {
			case 'eq':
				return $value === $wanted;
			case 'neq':
				return $value !== $wanted;
			case 'gt':
				return $value > $wanted;
			case 'gte':
				return $value >= $wanted;
			case 'lt':
				return $value < $wanted;
			case 'lte':
				return $value <= $wanted;
			default:
				return new \WP_Error( 'f3_google_conversion_filter', 'Métricas de conversão aceitam eq, neq, gt, gte, lt, lte, in, null e notnull.' );
		}
	}
	private static function error( string $message ): array {
		return Response::fail( new \WP_Error( 'f3_google_conversion_query', $message ) );
	}
}

/** One event per request: asynchronous receipts cannot acknowledge another record. */
final class DataManager {
    public static function diagnostic_schema(): array {
        $s=['type'=>'string'];
        return ['type'=>['object','null'],'properties'=>['phase'=>$s,'http_status'=>['type'=>'integer'],'status'=>$s,'reason'=>$s,'message'=>$s,
            'field_violations'=>['type'=>'array','items'=>['type'=>'object','properties'=>['field'=>$s,'reason'=>$s,'message'=>$s]]]]];
    }
    public const BASE='https://datamanager.googleapis.com/v1';
    public const SCOPE='https://www.googleapis.com/auth/datamanager';
    public const RECONCILE='site-conversion-reconcile/1.0.0';
    public static function destination(array $c): array {
        $d=['operatingAccount'=>['accountType'=>'GOOGLE_ADS','accountId'=>$c['customer_id']],
            'productDestinationId'=>basename($c['conversion_action'])];
        $login=Options::ads_login_customer_id();
        if ($login) $d['loginAccount']=['accountType'=>'GOOGLE_ADS','accountId'=>$login];
        return $d;
    }
    public static function options(array $c,bool $read=false): array {
        return ['connector'=>'ads','operation_id'=>$read?'datamanager.requestStatus.retrieve':'datamanager.events.ingest',
            'mode'=>$read?'read':'write','scopes'=>[self::SCOPE],'retries'=>0,'timeout'=>8,'budget_seconds'=>12,
            'policy_customer_id'=>$c['customer_id']];
    }
    public static function verify(array $c,bool $commercial=false): array {
        $opts=['connector'=>'ads','operation_id'=>'googleads.customers.googleAds.search','mode'=>'read','retries'=>0,
            'headers'=>AdsApi::headers(),'scopes'=>Credentials::scopes_for('ads')];
        $query='SELECT conversion_action.resource_name, conversion_action.type, conversion_action.status, conversion_action.value_settings.default_value, conversion_action.value_settings.default_currency_code'.($commercial?', conversion_action.value_settings.always_use_default_value':'').' FROM conversion_action WHERE conversion_action.resource_name = "'.$c['conversion_action'].'"';
        $r=GoogleClient::request('POST',AdsApi::base().'/customers/'.$c['customer_id'].'/googleAds:search',['query'=>$query],$opts);
        if (is_wp_error($r)) return self::verification_error($r,'ads_action_unverified');
        $a=$r['results'][0]['conversionAction']??[];
        $value=$a['valueSettings']['defaultValue']??null;
        $currency=$a['valueSettings']['defaultCurrencyCode']??'';
        if (($a['resourceName']??'')!==$c['conversion_action']||($a['type']??'')!=='UPLOAD_CLICKS'||($a['status']??'')!=='ENABLED'||!is_numeric($value)||!is_finite((float)$value)||(float)$value<0||!preg_match('/^[A-Z]{3}$/D',$currency)) return self::verification_error(new \WP_Error('invalid_action','A ação precisa estar ativa, aceitar importações de cliques e ter valor e moeda válidos.'),'ads_action_unverified');
        if ($commercial) {
            $forced=$a['valueSettings']['alwaysUseDefaultValue']??false;
            if(!is_bool($forced)||($forced&&((float)$value!==0.0||$currency!=='BRL')))return self::verification_error(new \WP_Error('stage_value_conflict','A ação comercial não pode substituir o valor zero em BRL por outro valor padrão.'),'ads_action_unverified');
            $value=0.0; $currency='BRL';
        }
        // A validate-only request checks the destination/permissions without collecting a conversion.
        $body=['destinations'=>[self::destination($c)],'validateOnly'=>true,'events'=>[[
            'transactionId'=>'verification-'.bin2hex(random_bytes(16)),'eventTimestamp'=>gmdate('c'),'eventSource'=>'WEB',
            'adIdentifiers'=>['gclid'=>'GCLID_1'],'consent'=>['adUserData'=>'CONSENT_GRANTED'],
            'conversionValue'=>(float)$value,'currency'=>$currency]]];
        $check=GoogleClient::request('POST',self::BASE.'/events:ingest',$body,self::options($c));
        if (is_wp_error($check)) return self::verification_error($check,'data_manager_unverified');
        if (!is_array($check)||!empty($check['error'])) return self::verification_error(new \WP_Error('invalid_response','Resposta de validação inesperada.'),'data_manager_unverified');
        return ['ok'=>true,'source'=>'data_manager_validate_only_and_action_read','value'=>(float)$value,'currency'=>$currency,'enhanced_leads'=>EnhancedLeads::observe($c)];
    }
    /** Store only bounded diagnostic fields, never the provider's raw response or request. */
    private static function diagnostic_text($value,int $limit=400): string {
        if (!is_scalar($value)) return '';
        $text=(string)\Fator3\McpGoogle\Ability::scrub((string)$value);
        $text=strip_tags($text);
        $text=preg_replace('/\b[a-f0-9]{64}\b/i','[hash removido]',$text);
        $text=preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i','[e-mail removido]',$text);
        $text=preg_replace('/(?:Bearer\s+\S+|(?:access_token|refresh_token|api_secret|gclid|gbraid|wbraid|developer.token)\s*[=:]\s*["\x27]?[^\s,"\x27]+)/i','[segredo removido]',$text);
        $text=preg_replace('/\+?\d[\d ().-]{7,}\d/','[número removido]',$text);
        return mb_substr(preg_replace('/[\x00-\x1f\x7f]/',' ',$text),0,$limit);
    }
    private static function diagnostic_code($value): string {
        return is_string($value)&&preg_match('/^[A-Z][A-Z0-9_]{0,95}$/D',$value)?$value:'';
    }
    public static function verification_error(\WP_Error $error,string $code,?string $phase=null): array {
        $data=$error->get_error_data();$data=is_array($data)?$data:[];
        $root=is_array($data['details']??null)?$data['details']:[];
        $diag=['phase'=>$phase??($code==='ads_action_unverified'?'ads_action_read':'data_manager_validation'),'http_status'=>(int)($data['status']??0),
            'status'=>self::diagnostic_code($root['status']??$data['reason']??''),
            'reason'=>self::diagnostic_code($data['reason']??''),
            'message'=>self::diagnostic_text($error->get_error_message()),'field_violations'=>[]];
        $retry=false;
        foreach (array_slice((array)($root['details']??[]),0,10) as $detail) {
            if (!is_array($detail)) continue;
            if (self::diagnostic_code($detail['reason']??'')) $diag['reason']=self::diagnostic_code($detail['reason']);
            foreach (array_slice((array)($detail['fieldViolations']??[]),0,10) as $violation) {
                if (!is_array($violation)) continue;
                $field=$violation['field']??'';
                $field=is_string($field)&&preg_match('/^[a-zA-Z0-9_.\[\]]{1,180}$/D',$field)?$field:'';
                $reason=self::diagnostic_code($violation['reason']??'');
                $diag['field_violations'][]=['field'=>$field,'reason'=>$reason,
                    'message'=>self::diagnostic_text($violation['description']??$violation['localizedMessage']['message']??'')];
                if ($reason==='NOT_FOUND'&&preg_match('/(?:^|\.)(?:destination_references|destinationReferences)(?:\[\d+\])?$/D',$field)) $retry=true;
            }
        }
        $retry=$retry&&$code==='data_manager_unverified';
        $message=$retry?'A ação de conversão ainda não está disponível na Data Manager. Confira o destino selecionado; a validação será repetida automaticamente enquanto a configuração e a autorização permanecerem iguais.':
            'Não foi possível verificar o destino Google. Confira o acesso e a configuração. '.$diag['message'];
        return \Fator3\McpGoogle\Response::fail(new \WP_Error('f3_google_delivery_'.$code,$message),
            ['ok'=>false,'code'=>$code,'provider_error'=>$diag,'retry_verification'=>$retry]);
    }
    private static function id(string $record): string { return hash('sha256',(str_starts_with($record,'stage:')?'stage|'.get_current_blog_id():Connections::id()).'|'.$record); }
    private static function unknown(string $code='data_manager_pending'): array { return ['status'=>'incerto','code'=>$code,'retry_after'=>1800]; }
    public static function send(array $p,array $c,string $ref,array $userIdentifiers=[],?string $transactionId=null,?string $contextHash=null): array {
        $id=self::id($p['record_id']);
        $existing=Records::get('conversion',$id);
        if ($existing) {
            if($contextHash!==null&&!hash_equals((string)($existing['context_hash']??''),$contextHash))return self::unknown('data_manager_event_conflict');
            return self::result($existing,$ref);
        }
        $proof=$c['verified']['google_ads']??[];
        if (!isset($proof['value'],$proof['currency'])) return ['status'=>'recusado','non_delivery_proven'=>true,'code'=>'ads_value_unverified'];
        $event=['transactionId'=>$transactionId??$p['record_id'],'eventTimestamp'=>$p['occurred_at'],'eventSource'=>'WEB',
            'adIdentifiers'=>$p['click_ids'],'consent'=>['adUserData'=>'CONSENT_GRANTED'],
            'conversionValue'=>$proof['value'],'currency'=>$proof['currency']];
        if(!$p['click_ids'])unset($event['adIdentifiers']);
        if($userIdentifiers)$event['userData']=EnhancedLeads::data_manager($userIdentifiers);
        if (isset($p['ad_personalization'])&&in_array($p['ad_personalization'],['GRANTED','DENIED'],true)) $event['consent']['adPersonalization']='CONSENT_'.$p['ad_personalization'];
        $destination=self::destination($c);
        $record=['connection_id'=>Connections::id(),'record_id'=>$p['record_id'],'destination_ref'=>$ref,'destination'=>$destination,
            'principal'=>Credentials::execution_identity(),'status'=>'dispatching','created_at'=>time(),'request_id'=>'','next_attempt'=>time()+1800,'attempts'=>0];
        if($contextHash!==null)$record['context_hash']=$contextHash;
        // A lost response or process crash cannot turn this intent back into a new ingestion.
        if (!Records::insert('conversion',$id,$record)) return self::unknown('data_manager_intent_unconfirmed');
        $body=['destinations'=>[$destination],'events'=>[$event]];
        if($userIdentifiers)$body['encoding']='HEX';
        $r=GoogleClient::request('POST',self::BASE.'/events:ingest',$body,self::options($c));
        if (!is_wp_error($r)&&is_string($r['requestId']??null)&&strlen($r['requestId'])<=512&&$r['requestId']!=='') {
            $record['request_id']=$r['requestId'];$record['status']='pending';
        } else {
            $record['status']='unknown';
            // Our execution fence runs before HTTP; it alone proves this attempt did not send.
            if (is_wp_error($r)&&in_array($r->get_error_code(),['f3_google_delivery_destination_mismatch','f3_google_delivery_authorization_changed'],true)) {
                $record['status']='refused';$record['code']='authorization_changed';
            }
        }
        if (empty(Records::put('conversion',$id,$record)['success'])) return self::unknown('data_manager_receipt_unconfirmed');
        return self::result($record,$ref);
    }
    private static function result(array $r,string $ref): array {
        if (!hash_equals($r['destination_ref'],$ref)) return self::unknown('data_manager_destination_mismatch');
        if ($r['status']==='delivered') return ['status'=>'entregue','code'=>'data_manager_confirmed','evidence'=>'single_event_request_status','processed'=>true];
        if ($r['status']==='refused') return ['status'=>'recusado','non_delivery_proven'=>true,'code'=>$r['code']??'data_manager_rejected'];
        return self::unknown($r['request_id']?'data_manager_pending':'data_manager_receipt_unknown');
    }
    public static function reconcile(string $record,string $ref,array $c): array {
        $id=self::id($record);$r=Records::get('conversion',$id);
        if (!$r) return self::unknown('data_manager_receipt_unknown');
        if (!hash_equals($r['destination_ref'],$ref)||!hash_equals($r['principal'],Credentials::execution_identity())) return self::unknown('data_manager_destination_mismatch');
        if (in_array($r['status'],['delivered','refused'],true)||!$r['request_id']||$r['next_attempt']>time()) return self::result($r,$ref);
        $opts=self::options($c,true);$opts['query']=['requestId'=>$r['request_id']];
        $response=GoogleClient::request('GET',self::BASE.'/requestStatus:retrieve',null,$opts);
        $items=is_wp_error($response)?[]:($response['requestStatusPerDestination']??[]);
        $one=count($items)===1?$items[0]:[];
        $d=$one['destination']??[];$expected=$r['destination'];
        $matches=($d['operatingAccount']['accountId']??'')===$expected['operatingAccount']['accountId']
            &&($d['operatingAccount']['accountType']??'')==='GOOGLE_ADS'
            &&($d['productDestinationId']??'')===$expected['productDestinationId']
            &&($d['loginAccount']??null)===($expected['loginAccount']??null)
            &&($one['eventsIngestionStatus']['recordCount']??null)==='1';
        if ($matches&&($one['requestStatus']??'')==='SUCCESS'&&empty($one['errorInfo']['errorCounts'])) $r['status']='delivered';
        if ($matches&&($one['requestStatus']??'')==='FAILED') {
            $errors=$one['errorInfo']['errorCounts']??[];
            // Duplicate/unknown/internal errors do not prove that the logical conversion was never delivered.
            $safe=['PROCESSING_ERROR_REASON_INVALID_GCLID','PROCESSING_ERROR_REASON_INVALID_GBRAID','PROCESSING_ERROR_REASON_INVALID_WBRAID','PROCESSING_ERROR_REASON_DENIED_CONSENT','PROCESSING_ERROR_REASON_EVENT_TOO_OLD','PROCESSING_ERROR_REASON_INVALID_EVENT'];
            if ($errors&&!array_filter($errors,static fn($e)=>!in_array($e['reason']??'',$safe,true)||($e['recordCount']??null)!=='1')) {$r['status']='refused';$r['code']='data_manager_rejected';}
        }
        ++$r['attempts'];$r['next_attempt']=time()+min(21600,1800*(2**min(4,$r['attempts'])));$r['updated_at']=time();
        if (empty(Records::put('conversion',$id,$r)['success'])) return self::unknown('data_manager_status_unconfirmed');
        return self::result($r,$ref);
    }
}
