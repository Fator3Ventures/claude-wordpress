<?php
/** Fixed GAQL, provider windows and closed archive rows. No arbitrary query execution. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class ArchiveQuery {
    public const DATASETS=['clicks','customer','campaign','ad_group','ad','search_terms','changes'];
    public static function valid_date(string $date): bool {
        $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$date,new \DateTimeZone('UTC'));
        return $d&&$d->format('Y-m-d')===$date;
    }
    public static function first_day(string $dataset,string $today): string {
        $d=new \DateTimeImmutable($today,new \DateTimeZone('UTC'));
        // Whole change-event days must be strictly inside the rolling 30-day window.
        if($dataset==='clicks'||$dataset==='changes')return $d->modify($dataset==='clicks'?'-90 days':'-29 days')->format('Y-m-d');
        $month=$d->modify('first day of this month')->modify('-37 months');
        return $month->setDate((int)$month->format('Y'),(int)$month->format('m'),min((int)$d->format('d'),(int)$month->format('t')))->format('Y-m-d');
    }
    public static function fields(string $dataset): array {
        if($dataset==='changes')return ['change_event.resource_name','change_event.change_date_time','change_event.change_resource_name','change_event.change_resource_type','change_event.resource_change_operation','change_event.changed_fields','change_event.old_resource','change_event.new_resource','change_event.user_email','change_event.client_type'];
        $fields=['customer.id','customer.currency_code','customer.time_zone','segments.date'];
        if($dataset!=='customer')$fields=array_merge($fields,['campaign.id','campaign.name']);
        if(in_array($dataset,['clicks','ad_group','ad','search_terms'],true))$fields=array_merge($fields,['ad_group.id','ad_group.name']);
        if($dataset==='clicks')return array_merge($fields,['click_view.resource_name','click_view.gclid','click_view.ad_group_ad','click_view.keyword','click_view.keyword_info.text','click_view.keyword_info.match_type','segments.ad_network_type','segments.device']);
        if($dataset==='ad')$fields[]='ad_group_ad.ad.id';
        if($dataset==='search_terms')$fields[]='search_term_view.search_term';
        return array_merge($fields,['metrics.cost_micros','metrics.clicks','metrics.impressions','metrics.conversions']);
    }
    public static function gaql(string $dataset,string $date,array $range=[0,86400]): string {
        if(!in_array($dataset,self::DATASETS,true)||!self::valid_date($date))throw new \InvalidArgumentException('Recorte inválido.');
        $resource=['clicks'=>'click_view','ad'=>'ad_group_ad','search_terms'=>'search_term_view','changes'=>'change_event'][$dataset]??$dataset;
        $q='SELECT '.implode(', ',self::fields($dataset)).' FROM '.$resource;
        if($dataset==='changes'){
            $start=new \DateTimeImmutable($date.' 00:00:00',new \DateTimeZone('UTC'));
            $a=$start->modify('+'.$range[0].' seconds')->format('Y-m-d H:i:s');
            $b=$start->modify('+'.$range[1].' seconds')->format('Y-m-d H:i:s');
            return $q." WHERE change_event.change_date_time >= '$a' AND change_event.change_date_time < '$b' ORDER BY change_event.change_date_time ASC LIMIT 10000";
        }
        return $q." WHERE segments.date = '$date'";
    }
    public static function normalize(array $raw,string $dataset,string $account,string $date,array $cfg) {
        $v=AdsApi::flatten_row($raw,self::fields($dataset));
        $row=['account_id'=>$account,'date'=>$date,'dataset'=>$dataset,'currency'=>$cfg['currency'],'time_zone'=>$cfg['time_zone']];
        if($dataset==='changes'){
            foreach(['resource_name'=>'event_id','change_date_time'=>'changed_at','change_resource_name'=>'resource','change_resource_type'=>'entity_type','resource_change_operation'=>'operation','changed_fields'=>'changed_fields','old_resource'=>'old','new_resource'=>'new','user_email'=>'author','client_type'=>'client_type'] as $field=>$key)$row[$key]=$v['change_event.'.$field]??null;
            if(!is_string($row['event_id'])||!str_starts_with($row['event_id'],'customers/'.$account.'/changeEvents/')||!is_string($row['changed_at'])||substr($row['changed_at'],0,10)!==$date)return new \WP_Error('f3_google_archive_response','Evento de outra conta/data ou sem identidade.');
            return $row;
        }
        if((string)($v['customer.id']??'')!==$account||($v['segments.date']??'')!==$date||($v['customer.currency_code']??'')!==$cfg['currency']||($v['customer.time_zone']??'')!==$cfg['time_zone'])return new \WP_Error('f3_google_archive_response','Resposta Ads de outra conta, data, moeda ou fuso.');
        foreach(['campaign.id'=>'campaign_id','campaign.name'=>'campaign_name','ad_group.id'=>'ad_group_id','ad_group.name'=>'ad_group_name','ad_group_ad.ad.id'=>'ad_id'] as $field=>$key)if(array_key_exists($field,$v))$row[$key]=$v[$field]===null?null:(string)$v[$field];
        if($dataset==='clicks'){
            foreach(['resource_name'=>'click_id','gclid'=>'gclid','ad_group_ad'=>'ad','keyword'=>'keyword_resource','keyword_info.text'=>'keyword','keyword_info.match_type'=>'match_type'] as $field=>$key)$row[$key]=$v['click_view.'.$field]??null;
            $row['network']=$v['segments.ad_network_type']??null;$row['device']=$v['segments.device']??null;
            $row['search_term']=null;$row['search_term_reason']='not_exposed_per_click';
            if($row['gclid']==='')$row['gclid']=null;
            $row['gclid_unavailable']=$row['gclid']===null;
            if(($row['gclid']!==null&&!is_string($row['gclid']))||!is_string($row['click_id'])||!str_starts_with($row['click_id'],'customers/'.$account.'/clickViews/'.$date.'~'))return new \WP_Error('f3_google_archive_response','Clique sem identidade válida ou com GCLID inválido.');
            return $row;
        }
        if($dataset==='search_terms')$row['search_term']=$v['search_term_view.search_term']??null;
        foreach(['cost_micros','clicks','impressions','conversions'] as $field){
            $value=$v['metrics.'.$field]??0; // Proto3 omits default zero values.
            if(!is_numeric($value)||!is_finite((float)$value)||$value<0)return new \WP_Error('f3_google_archive_response','Métrica Ads inválida.');
            $row[$field]=$field==='conversions'?(float)$value:(string)$value;
        }
        return $row;
    }
}
