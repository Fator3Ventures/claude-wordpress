<?php
/** Encrypted permanent snapshots in the existing indexed repository. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;
use Fator3\McpGoogle\{Connections,Crypto,Response,Storage\Repository};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class ArchiveStore {
    public static function key(string $account,string $dataset,string $date): string {
        return hash('sha256',Connections::id().'|'.$account.'|'.$dataset.'|'.$date);
    }
    public static function get(string $kind,string $id) {
        $row=Repository::get($kind,$id);
        if($row===null||is_wp_error($row))return $row;
        $plain=Crypto::decrypt((string)($row['ciphertext']??''));
        $v=is_string($plain)?json_decode($plain,true):null;
        if(!is_array($v)||($v['kind']??'')!==$kind||($v['id']??'')!==$id||($v['connection_id']??'')!==Connections::id()||!is_array($v['data']??null))return new \WP_Error('f3_google_archive_corrupt','Acervo ilegível ou de outra conexão.');
        return $v['data'];
    }
    public static function put(string $kind,string $id,array $data): array {
        $cipher=Crypto::encrypt(wp_json_encode(['kind'=>$kind,'id'=>$id,'connection_id'=>Connections::id(),'data'=>$data]));
        if(!$cipher)return Response::fail(new \WP_Error('f3_google_archive_crypto','Falha ao cifrar o acervo.'));
        return Repository::put($kind,$id,['connection_id'=>Connections::id(),'ciphertext'=>$cipher,'status'=>$data['state']??'saved','expires_at'=>0]);
    }
    public static function latest(string $account,string $dataset,string $date) {
        $pointer=self::get('adslatest',self::key($account,$dataset,$date));
        if($pointer===null||is_wp_error($pointer))return $pointer;
        $m=self::get('adssnapshot',$pointer['revision']??'invalid');
        if(!is_array($m)||($m['account_id']??'')!==$account||($m['dataset']??'')!==$dataset||($m['date']??'')!==$date)return is_wp_error($m)?$m:new \WP_Error('f3_google_archive_corrupt','Revisão do acervo inválida.');
        return $m;
    }
    /** One immutable published revision; old cursors fail when a revisitation publishes. */
    public static function page(array $m,int $offset,int $limit) {
        $out=[];$skip=$offset;
        foreach($m['chunks'] as $chunk){
            if($skip>=$chunk['count']){$skip-=$chunk['count'];continue;}
            $r=self::get('adsrows',$chunk['id']);
            if(is_wp_error($r)||!is_array($r)||!is_array($r['rows']??null)||count($r['rows'])!==$chunk['count'])return is_wp_error($r)?$r:new \WP_Error('f3_google_archive_corrupt','Página incompleta do acervo.');
            $out=array_merge($out,array_slice($r['rows'],$skip,$limit-count($out)));$skip=0;
            if(count($out)>=$limit)break;
        }
        return $out;
    }
}
