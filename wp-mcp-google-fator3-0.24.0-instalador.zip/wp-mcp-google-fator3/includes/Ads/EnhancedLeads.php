<?php
/** Enhanced-lead identities are transient; only readiness observations may be stored. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;
use Fator3\McpGoogle\{Auth\Credentials,Http\GoogleClient};
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class EnhancedLeads {
    public static function schema(): array {
        $s=['type'=>'string'];$nullable=['type'=>['boolean','null']];$n=['type'=>['integer','null']];
        return ['type'=>['object','null'],'properties'=>['supported'=>['type'=>'boolean'],'ready'=>['type'=>'boolean'],'reason'=>$s,
            'customer_id'=>$s,'conversion_action'=>$s,'accepted_customer_data_terms'=>$nullable,'enabled'=>$nullable,
            'checked_at'=>$n,'expires_at'=>$n,'provider_error'=>DataManager::diagnostic_schema(),'transport'=>$s,'user_data_fields'=>['type'=>'array','items'=>$s]]];
    }
    public static function normalize($user) {
        if(!is_array($user)||array_diff(array_keys($user),['email','telefone']))return new \WP_Error('enhanced_leads_user_data_invalid','user_data aceita somente email e telefone.');
        $raw=[];
        foreach(['email'=>'email','telefone'=>'phone'] as $input=>$field) {
            if(!array_key_exists($input,$user))continue;
            if(!is_string($user[$input])||strlen($user[$input])>($input==='email'?254:40))return new \WP_Error('enhanced_leads_user_data_invalid','Identificador pessoal inválido.');
            if(trim($user[$input])!=='')$raw[$field]=$user[$input];
        }
        if(!$raw)return new \WP_Error('enhanced_leads_user_data_invalid','Informe email ou telefone válido.');
        $ids=WriteAbilities::normalize_user($raw);
        return is_wp_error($ids)?new \WP_Error('enhanced_leads_user_data_invalid','Email inválido ou telefone fora de E.164.'):$ids['userIdentifiers'];
    }
    /** Called only during explicit verification/renewal, never by capabilities or status. */
    public static function observe(array $c): array {
        $base=['customer_id'=>$c['customer_id'],'conversion_action'=>$c['conversion_action'],'checked_at'=>time(),
            'accepted_customer_data_terms'=>null,'enabled'=>null,'ready'=>false,'reason'=>'enhanced_leads_unverified','provider_error'=>null];
        $query='SELECT customer.id, customer.conversion_tracking_setting.accepted_customer_data_terms, customer.conversion_tracking_setting.enhanced_conversions_for_leads_enabled FROM customer';
        $opts=['connector'=>'ads','operation_id'=>'googleads.customers.googleAds.search','mode'=>'read','retries'=>0,
            'headers'=>AdsApi::headers(),'scopes'=>Credentials::scopes_for('ads')];
        $r=GoogleClient::request('POST',AdsApi::base().'/customers/'.$c['customer_id'].'/googleAds:search',['query'=>$query],$opts);
        if(is_wp_error($r)) {
            $base['provider_error']=DataManager::verification_error($r,'enhanced_leads_unverified','ads_customer_read')['provider_error'];
            return $base;
        }
        $customer=$r['results'][0]['customer']??[];
        if(count($r['results']??[])!==1||(string)($customer['id']??'')!==$c['customer_id'])return $base;
        $s=$customer['conversionTrackingSetting']??[];
        foreach(['acceptedCustomerDataTerms'=>'accepted_customer_data_terms','enhancedConversionsForLeadsEnabled'=>'enabled'] as $k=>$out) {
            // Omitted proto3 booleans are false; malformed values never grant readiness.
            $value=$s[$k]??false;
            if(!is_bool($value))return $base;
            $base[$out]=$value;
        }
        $base['ready']=$base['accepted_customer_data_terms']&&$base['enabled'];
        $base['reason']=$base['ready']?'ok':(!$base['accepted_customer_data_terms']?'customer_data_terms_not_accepted':'enhanced_leads_disabled');
        return $base;
    }
    public static function capability(array $c,?string $localReason): array {
        $proof=$c['verified']['google_ads']??[];$o=$proof['enhanced_leads']??[];
        $matches=is_array($o)&&($o['customer_id']??null)===$c['customer_id']&&($o['conversion_action']??null)===$c['conversion_action'];
        $reason=$localReason??($matches?($o['reason']??'enhanced_leads_unverified'):'enhanced_leads_unverified');
        return ['supported'=>true,'ready'=>$localReason===null&&$matches&&($o['ready']??false)===true,
            'reason'=>$reason,'customer_id'=>$c['customer_id'],'conversion_action'=>$c['conversion_action'],
            'accepted_customer_data_terms'=>$matches?($o['accepted_customer_data_terms']??null):null,'enabled'=>$matches?($o['enabled']??null):null,
            'checked_at'=>$matches?($o['checked_at']??null):null,'expires_at'=>$matches?($proof['expires']??null):null,
            'provider_error'=>$matches?($o['provider_error']??null):null,'transport'=>'data_manager','user_data_fields'=>['email','telefone']];
    }
    /** translate normalized Google Ads oneof identifiers to the current Data Manager API. */
    public static function data_manager(array $ids): array {
        return ['userIdentifiers'=>array_map(static function($id){
            return isset($id['hashedEmail'])?['emailAddress'=>$id['hashedEmail']]:['phoneNumber'=>$id['hashedPhoneNumber']];
        },$ids)];
    }
}
