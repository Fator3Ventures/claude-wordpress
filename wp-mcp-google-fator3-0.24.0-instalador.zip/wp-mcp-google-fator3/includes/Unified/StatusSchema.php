<?php
/** Public diagnostic projections. Success means observation completed, not remote readiness. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Unified;
use Fator3\McpGoogle\{
    Cache,McpServer,Storage\State,Storage\Maintenance,Automation\CronHistory
};
if (!defined( 'ABSPATH' )) {
    exit;
}
final class StatusSchema {
    private static function t($type,string $description=''): array {
        return ['type'=>$type,'description'=>$description];
    }
    private static function obj(array $properties,string $description=''): array {
        return ['type'=>'object','properties'=>$properties,'description'=>$description];
    }
    private static function list(array $items): array {
        return ['type'=>'array','items'=>$items];
    }
    private static function map(array $values): array {
        return ['type'=>'object','additionalProperties'=>$values];
    }
    private static function nullable(array $schema): array {
        $schema['type']=['object','null'];
        return $schema;
    }
    public static function properties(): array {
        $s=self::t('string');
        $b=self::t('boolean');
        $n=self::t('integer');
        $ns=self::t(['string','null']);
        $nb=self::t(['boolean','null']);
        $nn=self::t(['integer','null']);
        $strings=self::list($s);
        $recovery=self::obj(['paused'=>$b,'generation'=>$s,'prepared_at'=>$nn,'resumed_at'=>$nn,'drained'=>$b,'error_code'=>$s],'Pausa local; não reverte operações remotas.');
        $health=self::obj(['state'=>$s,'at'=>$n,'phase'=>$s,'error_code'=>$s,'connection_id'=>$s,'cause'=>$s,'storage_state'=>$s,'historical_gap'=>$b,'recovered_at'=>$n,'verified_event'=>$s,'persisted'=>$b]);
        $api=self::obj(['enabled'=>$nb,'status'=>$s,'checked_at'=>$ns,'note'=>$s,'last_http_status'=>$n,'source'=>$s,'revision'=>$ns,'resource_tested'=>$s,'context_changed'=>$b,'stale'=>$b],'Observação de resposta passada; null não equivale a API desativada.');
        $quota_values=self::obj(['consumed'=>$nn,'remaining'=>$nn,'unit'=>$s,'window'=>$s,'limit'=>$nn,'reset_at'=>$nn]);
        $quota=self::obj(['available'=>$b,'error_code'=>$s,'truncated'=>$b,'scope'=>$s,'global_google_quota_known'=>$b,'observations'=>self::list(self::obj(['connection_id'=>$s,'property_id'=>$s,'source'=>$s,'source_documentation'=>$s,'observed_at'=>$n,'expires_at'=>$n,'response_index'=>$n,'stale'=>$b,'observations'=>self::map($quota_values)]))]);
        $budget=self::obj(['source'=>$s,'unit'=>$s,'scope'=>$s,'google_quota_known'=>$b,'observed_at'=>$n,'site_url'=>$s,'minute_limit'=>$n,'day_limit'=>$n,'available'=>$b,'reason'=>$s,'attempts_last_minute'=>$n,'attempts_last_day'=>$n,'remaining_minute'=>$n,'remaining_day'=>$n,'next_eligible_at'=>$n,'window_type'=>$s,'window_seconds'=>self::list($n)],'Orçamento local de tentativas; não é a cota global do Google.');
        $trace=self::nullable(self::obj(['request_id'=>$s,'site_url'=>$s,'plugin_version'=>$s,'connection_id'=>$s,'method'=>$s,'host'=>$ns,'body_bytes'=>$nn,'content_length'=>self::t(['string','integer','null']),'http_status'=>$nn,'attempt'=>$n,'checked_at'=>$s]));
        $last_service=self::nullable(self::obj(['at'=>$nn,'success'=>$nb,'rows'=>$nn,'run_id'=>$ns,'request_id'=>$ns,'error_code'=>$ns]));
        $config=self::obj(['ready'=>$b,'property'=>$s,'revision'=>$s,'error_code'=>$s]);
        $grant=self::obj(['enabled'=>$b,'capability'=>$ns]);
        $local=self::nullable(self::obj(['configuration'=>$config,'grant'=>$grant,'google_enabled'=>$nb,'gsc_enabled'=>$nb,'configuration_error'=>$ns,'configured'=>$nb,'policy_allowed'=>$nb,'recovery'=>self::obj(['paused'=>$nb,'error_code'=>$ns]),'last_service'=>$last_service,'last_service_error'=>$ns,'remote_access_verified'=>$b,'consumer_commit_verified'=>$b]));
        $effective=self::nullable(self::obj(['contract'=>$s,'consumer_id'=>$s,'resolution'=>$s,'connection_id'=>$ns,'reason_codes'=>$strings,'local_status'=>$local,'checked_at'=>$n]));
        $integration=self::obj(['contract'=>$s,'connection_id'=>$s,'grants_error'=>$ns,'google_enabled'=>$b,'configured'=>$b,'consumers'=>self::list(self::obj(['effective_status'=>$effective,'id'=>$s,'version'=>$s,'configuration'=>$config,'grant'=>self::nullable($grant),'last_service'=>$last_service]))]);
        $incident=self::obj(['id'=>$s,'connection_id'=>$s,'event'=>$s,'resource'=>$s,'status'=>$s,'code'=>$s,'action'=>$s,'created_at'=>$n,'updated_at'=>$n,'generation'=>$n,'email_state'=>$s,'last_notified_at'=>$n,'next_notification_at'=>$n,'task'=>$s,'run_after'=>$n]);
        $incident['properties']+=['phase'=>$ns,'cause_code'=>$ns,'provider_error'=>\Fator3\McpGoogle\Ads\DataManager::diagnostic_schema()];
        $mcp=self::obj(['contract_compatible'=>$b,'contract'=>$s,'provider'=>$s,'server_id'=>$s,'route'=>self::t(['string','object','null']),'aliases'=>self::list(self::t(['string','object'])),'core_loaded'=>$b,'channel_enabled'=>$b,'server_enabled'=>$b,'registry_checked'=>$nb,'server_registered'=>$nb,'tools_ready'=>$nb,'endpoints'=>self::list(self::t(['string','object'])),'external_connectivity_tested'=>$nb,'reason'=>$s,'errors'=>$strings,'diagnostic'=>McpServer::diagnostic_schema()],'Registro local no MCP; não testa conexão externa.');
        return [
            'success'=>self::t('boolean','Execução da consulta de estado. Use storage.ready, saúde do cron e testes de recurso para avaliar operação.'),'message'=>$s,'error_code'=>$ns,'details'=>self::t(['object','array','null']),
            'scope'=>['type'=>'string','enum'=>['selected','all_connections'],'description'=>'selected é a conexão corrente; all_connections contém resumos locais sem testes de token.'],
            'compact'=>$b,'enabled'=>$b,'ga_enabled'=>$b,'ads_enabled'=>$b,
            'auth'=>self::obj(['mode'=>['type'=>'string','enum'=>['service_account','oauth']],'configured'=>self::t('boolean','Credencial local configurada; não comprova acesso remoto.'),'identity'=>$s,'reason'=>$s,'error_code'=>$s]),
            'crypto_backend'=>self::t(['string','null']),'ads_api_version'=>$s,'ads_developer_token_configured'=>$b,'ads_login_customer_id'=>$s,'api_status'=>self::map($api),
            'scopes_requested'=>$strings,'scopes_granted'=>['type'=>['array','null'],'items'=>$s],'scopes_note'=>$s,'ga_default_property'=>$s,'max_rows'=>$n,
            'abilities_registered'=>self::map($n),'mcp_server_detected'=>$b,'wordpress_version'=>$s,'site_url'=>$s,'integration'=>$integration,'recovery'=>$recovery,'mcp_server'=>$mcp,
            'conversion_delivery'=>\Fator3\McpGoogle\ConversionDelivery::status_schema(),'cron'=>CronHistory::schema(),'storage'=>State::schema(),'maintenance'=>Maintenance::schema(),'cache'=>Cache::schema(),
            'telemetry'=>self::obj(['available'=>$b,'error_code'=>$s,'window_start'=>$n,'window_end'=>$n,'bucket_seconds'=>$n,'counters'=>self::map($n),'apis'=>self::map(self::obj(['attempts'=>$n,'completed'=>$n,'duration_ms'=>$n,'errors'=>$n])),'approximate'=>$b,'incomplete_since'=>$nn,'source'=>$s]),
            'quota_observations'=>$quota,'inspection_budget'=>$budget,'incidents'=>self::list($incident),'audit_health'=>$health,'connection_id'=>$s,'last_http'=>$trace,'plugin_version'=>$s,
            'token_ok'=>self::map($b)+['description'=>'Presente somente em live:true; obter token não valida recursos.'],
        ];
    }
    public static function schema(): array {
        $p=self::properties();
        $summary=array_intersect_key($p,array_flip(['conversion_delivery','connection_id','auth','api_status','cron','integration','recovery','telemetry','quota_observations','inspection_budget','last_http','incidents']));
        $summary+=['label'=>self::t('string'),'services'=>['anyOf'=>[\Fator3\McpGoogle\Setup::services_schema(),['type'=>'null']]],'bindings'=>self::map(self::t('string'))];
        $p+=['site'=>self::obj(['url'=>self::t('string'),'plugin_version'=>self::t('string')]),'connections'=>self::list(self::obj($summary)),'google_checks_performed'=>self::t('boolean')];
        return self::obj($p,'Observação local por padrão; extensível para metadados do envelope MCP. Campos do resumo e do escopo selecionado são condicionais.');
    }
}
