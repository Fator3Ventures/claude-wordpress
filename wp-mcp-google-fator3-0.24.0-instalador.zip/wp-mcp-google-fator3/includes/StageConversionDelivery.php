<?php
/** Explicit commercial-action grants; no acquisition authorization is inherited. */
declare(strict_types=1);
namespace Fator3\McpGoogle;
use Fator3\McpGoogle\Ads\{DataManager,EnhancedLeads};
use Fator3\McpGoogle\Automation\Execution;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class StageConversionDelivery {
    public const CONTRACT='site-conversion-delivery/1.2.0';
    public const RECONCILE='site-stage-conversion-reconcile/1.0.0';
    public const CONSUMER='site-core-quality';
    public const PURPOSE='crm_stage';
    public const ACTION_PATTERN='~^customers/([0-9]{10})/conversionActions/[1-9][0-9]{0,29}$~D';
    private function __construct(private string $connection,private string $action,private ?string $selectionError=null) {}
    private static function valid_action($action): bool { return is_string($action)&&preg_match(self::ACTION_PATTERN,$action)===1; }
    private static function context($context): bool {
        return is_array($context)&&!array_diff(array_keys($context),['consumer_id','purpose','action'])
            &&($context['consumer_id']??'')===self::CONSUMER&&($context['purpose']??'')===self::PURPOSE&&self::valid_action($context['action']??null);
    }
    private static function resolve(string $action): array {
        $registry=Connections::registry_verified();
        if(is_wp_error($registry))return ['default','connections_unreadable'];
        $found=[];
        foreach(array_keys($registry) as $cid) {
            $c=Connections::run($cid,static fn()=>ConversionDelivery::read());
            if(is_wp_error($c)||isset($c['stage_actions'])&&!is_array($c['stage_actions']))return ['default','configuration_unreadable'];
            if(array_key_exists($action,$c['stage_actions']??[]))$found[]=$cid;
        }
        return [$found[0]??'default',count($found)>1?'ambiguous_stage_connection':null];
    }
    public static function select($context): self {
        if(!self::context($context))return new self('default','', 'stage_context_invalid');
        [$cid,$error]=self::resolve($context['action']);return new self($cid,$context['action'],$error);
    }
    /** Null is returned only after every stored acquisition selection was read successfully. */
    public static function acquisition(): array {
        $registry=Connections::registry_verified();if(is_wp_error($registry))return ['error'=>'acquisition_unreadable'];
        $actions=[];
        foreach(array_keys($registry) as $cid) {
            $c=Connections::run($cid,static fn()=>ConversionDelivery::read());
            if(is_wp_error($c)||!is_string($c['conversion_action']??null))return ['error'=>'acquisition_unreadable'];
            if($c['conversion_action']==='')continue;
            if(!self::valid_action($c['conversion_action']))return ['error'=>'acquisition_unreadable'];
            $actions[$c['conversion_action']]=true;
        }
        if(count($actions)>1)return ['error'=>'acquisition_ambiguous'];
        return ['action'=>$actions?array_key_first($actions):null];
    }
    private static function delivery_config(string $action,array $grant): array {
        preg_match(self::ACTION_PATTERN,$action,$matches);
        $c=ConversionDelivery::defaults();$c['enabled']=!empty($grant['enabled']);
        $c['customer_id']=$matches[1]??'';$c['conversion_action']=$action;
        $c['granted_by_target']['google_ads']=(int)($grant['by']??0);
        $c['verified']['google_ads']=$grant['proof']??[];$c['renewal']['google_ads']=$grant['renewal']??null;
        return $c;
    }
    private static function binding(array $c): string { return ConversionDelivery::proof_revision($c,'google_ads'); }
    private static function proof_binding(array $c,array $grant): string {
        return hash('sha256',self::binding($c).'|'.($grant['generation']??'').'|'.($grant['by']??0).'|'.self::CONSUMER.'|'.self::PURPOSE);
    }
    private static function local_reason(array $c,array $grant): ?string {
        if(($grant['consumer_id']??'')!==self::CONSUMER||($grant['purpose']??'')!==self::PURPOSE)return 'stage_grant_missing';
        if(empty($grant['enabled'])||!Options::user_authorized((int)($grant['by']??0)))return 'stage_grant_revoked';
        if(!is_string($grant['generation']??null)||!preg_match('/^[a-f0-9]{32}$/D',$grant['generation']))return 'stage_grant_invalid';
        if(!hash_equals(self::binding($c),(string)($grant['binding']??'')))return 'stage_grant_changed';
        return ConversionDelivery::local_reason($c,'google_ads');
    }
    /** Reads only; authorization, proof and selection are re-evaluated on every call. */
    private function snapshot(bool $requireProof=true): array {
        $raw=ConversionDelivery::read();$acq=self::acquisition();
        $reason=$this->selectionError;
        if(is_wp_error($raw)||isset($raw['stage_actions'])&&!is_array($raw['stage_actions'])){$raw=[];$reason='configuration_unreadable';}
        [$selected,$selection]=self::valid_action($this->action)?self::resolve($this->action):['default','stage_context_invalid'];
        $reason=$reason??$selection??($selected!==$this->connection?'stage_selection_changed':null);
        $grant=$raw['stage_actions'][$this->action]??[];
        if(!is_array($grant)){$grant=[];$reason='stage_grant_invalid';}
        $c=self::delivery_config($this->action,$grant);
        $reason=$reason??($acq['error']??null);
        if(!$reason&&($acq['action']??null)===$this->action)$reason='acquisition_action_reused';
        $reason=$reason??self::local_reason($c,$grant);
        if(!$reason&&$requireProof&&(!hash_equals(self::proof_binding($c,$grant),(string)($grant['proof']['revision']??''))||($grant['proof']['expires']??0)<=time()))$reason='stage_verification_required';
        $ref='google:crm_stage:'.hash('sha256',wp_json_encode([get_current_blog_id(),$this->connection,self::CONSUMER,self::PURPOSE,$this->action,
            self::proof_binding($c,$grant),$acq['action']??$acq['error']??'unreadable']));
        return ['config'=>$c,'grant'=>$grant,'reason'=>$reason,'acquisition'=>$acq,'reference'=>$ref];
    }
    public function capabilities(): array {
        return Connections::run($this->connection,function(){
            $s=$this->snapshot();$ready=$s['reason']===null;$g=$s['grant'];
            $entry=['action'=>$this->action,'purpose'=>self::PURPOSE,'ready'=>$ready,'reason'=>$s['reason']??'ok',
                'destination_ref'=>$s['reference'],'customer_id'=>$s['config']['customer_id'],
                'verified_at'=>$g['proof']['at']??null,'verification_expires_at'=>$g['proof']['expires']??null,
                'enhanced_leads'=>EnhancedLeads::capability($s['config'],$s['reason']),
                'renewal'=>ConversionDelivery::renewal_status($s['config'],'google_ads')];
            $cap=['contract'=>self::CONTRACT,'supported_contracts'=>[self::CONTRACT,ConversionDelivery::CONTRACT,ConversionDelivery::LEGACY_CONTRACT],
                'consumer_id'=>self::CONSUMER,'purposes'=>[self::PURPOSE],'ready'=>$ready,'reason'=>$s['reason']??'ok','connection_id'=>$this->connection,
                'actions'=>$this->action!==''?[$this->action=>$entry]:new \stdClass(),
                'async_reconciliation'=>self::RECONCILE,'analytics_homologated'=>false];
            if(array_key_exists('action',$s['acquisition']))$cap['acquisition_action']=$s['acquisition']['action'];
            return $cap;
        });
    }
    private static function fail(string $code,array $extra=[]): array {
        return Response::fail(new \WP_Error('f3_google_stage_'.$code,'Etapas comerciais Google: '.$code),['code'=>$code]+$extra);
    }
    public static function status(array $input=[]): array {
        if(!Options::authorized())return self::fail('not_authorized');
        $raw=ConversionDelivery::read();if(is_wp_error($raw)||isset($raw['stage_actions'])&&!is_array($raw['stage_actions']))return self::fail('configuration_unreadable');
        if(isset($input['action'])&&!self::valid_action($input['action']))return self::fail('invalid_action');
        $actions=isset($input['action'])?[$input['action']]:array_keys($raw['stage_actions']??[]);$out=[];
        foreach($actions as $action){if(!self::valid_action($action))return self::fail('configuration_unreadable');$out[$action]=(new self(Connections::id(),$action))->capabilities();}
        return Response::ok(['contract'=>self::CONTRACT,'connection_id'=>Connections::id(),'revision'=>ConversionDelivery::revision(),
            'max_actions'=>100,'actions'=>$out?:new \stdClass(),'google_checks_performed'=>false]);
    }
    public static function configure(array $v): array {
        return ConversionDelivery::locked(static function($lock)use($v){
            if(!hash_equals(ConversionDelivery::revision(),(string)($v['expected_revision']??'')))return self::fail('revision_conflict',['conflict'=>true]);
            if(!self::valid_action($v['action']??null)||!is_bool($v['enabled']??null)||($v['consumer_id']??self::CONSUMER)!==self::CONSUMER||($v['purpose']??self::PURPOSE)!==self::PURPOSE)return self::fail('invalid_grant');
            $raw=ConversionDelivery::read();if(is_wp_error($raw)||isset($raw['stage_actions'])&&!is_array($raw['stage_actions']))return self::fail('configuration_unreadable');
            $action=$v['action'];$old=$raw['stage_actions'][$action]??[];
            if(!is_array($old))return self::fail('invalid_grant');
            if(!isset($raw['stage_actions'][$action])&&count($raw['stage_actions']??[])>=100)return self::fail('action_limit');
            if($v['enabled']){
                $acq=self::acquisition();if(isset($acq['error']))return self::fail($acq['error']);
                if($acq['action']===$action)return self::fail('acquisition_action_reused');
                [$cid,$error]=self::resolve($action);if($error||($old===[]&&$cid!=='default'&&$cid!==Connections::id()))return self::fail('ambiguous_stage_connection');
                // A grant cannot silently become active under another connection's existing selection.
                $registry=Connections::registry_verified();if(is_wp_error($registry))return self::fail('connections_unreadable');
                foreach(array_keys($registry) as $other){if($other===Connections::id())continue;$r=Connections::run($other,static fn()=>ConversionDelivery::read());if(is_wp_error($r))return self::fail('configuration_unreadable');if(isset($r['stage_actions'][$action]))return self::fail('ambiguous_stage_connection');}
            }
            $grant=['consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE,'enabled'=>$v['enabled'],'by'=>get_current_user_id()];
            $c=self::delivery_config($action,$grant);$grant['binding']=self::binding($c);
            if($v['enabled']&&($reason=ConversionDelivery::local_reason($c,'google_ads')))return self::fail($reason);
            if(($old['enabled']??null)===$v['enabled']&&($old['by']??0)===$grant['by']&&($old['binding']??'')===$grant['binding']&&empty($v['renew_grant']))return Response::ok(['changed'=>false,'persisted'=>true,'revision'=>ConversionDelivery::revision()]);
            $grant['generation']=bin2hex(random_bytes(16));$grant['updated_at']=time();
            $raw['stage_actions'][$action]=$grant;
            if(!Lock::owned($lock))return self::fail('lock_lost');
            $saved=Options::set(ConversionDelivery::CONFIG,$raw);
            if(empty($saved['success']))return self::fail('grant_not_saved');
            $audit=Audit::append('stage:grant',$action,['consumer_id'=>self::CONSUMER,'purpose'=>self::PURPOSE,'enabled'=>$v['enabled'],'status'=>'success']);
            return Response::ok(['changed'=>true,'persisted'=>true,'revision'=>ConversionDelivery::revision(),'verification_required'=>$v['enabled'],'audit_success'=>$audit['success']]);
        });
    }
    public static function verify(array $v): array { return self::verify_internal($v,false); }
    private static function verify_internal(array $v,bool $background): array {
        return ConversionDelivery::locked(static function($lock)use($v,$background){
            $revision=ConversionDelivery::revision();
            if(!hash_equals($revision,(string)($v['expected_revision']??'')))return self::fail('revision_conflict',['conflict'=>true]);
            if(!self::valid_action($v['action']??null))return self::fail('invalid_action');
            $adapter=new self(Connections::id(),$v['action']);$s=$adapter->snapshot(false);
            if($s['reason'])return self::fail($s['reason']);
            $guard=static function()use($adapter,$s,$lock,$revision){$now=$adapter->snapshot(false);return Lock::owned($lock)&&ConversionDelivery::revision()===$revision&&!$now['reason']&&hash_equals($s['reference'],$now['reference'])?null:new \WP_Error('f3_google_delivery_authorization_changed','Concessão comercial alterada.');};
            try{$result=Execution::run(static fn()=>DataManager::verify($s['config'],true),18,$guard);}
            catch(\Throwable $e){$result=new \WP_Error('stage_verification_exception','Falha interna na verificação comercial.');}
            if(is_wp_error($result))$result=DataManager::verification_error($result,'stage_verification_failed','stage_verification');
            if(!is_array($result))$result=['ok'=>false,'code'=>'stage_verification_failed'];
            $attempt=ConversionDelivery::verification_attempt($s['config'],'google_ads',$result,$background,['purpose'=>self::PURPOSE,'consumer_id'=>self::CONSUMER,'action'=>$v['action']]);
            if($guard())return self::fail('revision_conflict',['conflict'=>true]);
            $raw=ConversionDelivery::read();if(is_wp_error($raw))return self::fail('configuration_unreadable');
            $grant=$s['grant'];$ok=!empty($result['ok']);$n=$ok?0:(int)($grant['renewal']['failures']??0)+1;
            if($ok)$grant['proof']=['revision'=>self::proof_binding($s['config'],$grant),'at'=>time(),'expires'=>time()+DAY_IN_SECONDS,'by'=>$grant['by'],
                'value'=>0.0,'currency'=>'BRL','enhanced_leads'=>$result['enhanced_leads']??[]];
            if($ok&&$attempt['unverified_since']!==null)$attempt['last_unverified_period']=['started_at'=>$attempt['unverified_since'],'ended_at'=>time(),'seconds'=>$attempt['unverified_seconds']];
            if($ok){$attempt['unverified_since']=null;$attempt['unverified_seconds']=0;}
            $grant['renewal']=['last_at'=>time(),'result'=>$ok?'success':'failed','code'=>$result['code']??'ok','failures'=>$n,
                'next_attempt'=>time()+($ok?12*HOUR_IN_SECONDS:min(3600,300*(2**min(4,$n-1))))]+$attempt;
            $raw['stage_actions'][$v['action']]=$grant;
            if(empty(Options::set(ConversionDelivery::CONFIG,$raw)['success']))return self::fail('verification_not_saved');
            $id=hash('sha256',Connections::id().'|stage_verification|'.$v['action']);$old=Records::get('incident',$id);
            if(!$ok||$old)Records::put('incident',$id,['id'=>$id,'connection_id'=>Connections::id(),'event'=>'stage_verification','resource'=>$v['action'],
                'status'=>$ok?'resolved':'open','code'=>$result['code']??$old['code']??'ok','phase'=>$result['provider_error']['phase']??$old['phase']??null,
                'provider_error'=>$result['provider_error']??$old['provider_error']??null,'action'=>'Confira a concessão e verifique a ação comercial Google.',
                'created_at'=>$old['created_at']??time(),'updated_at'=>time(),'generation'=>($old['generation']??0)+1]);
            $fields=['verified'=>$ok,'revision'=>ConversionDelivery::revision(),'code'=>$result['code']??'ok',
                'provider_error'=>$result['provider_error']??null,'audit_success'=>$attempt['audit_success'],'capability'=>$adapter->capabilities()];
            return $ok?Response::ok($fields):self::fail($result['code']??'stage_verification_failed',$fields);
        },$background);
    }
    public static function renew_due(): array {
        $raw=ConversionDelivery::read();if(is_wp_error($raw)||isset($raw['stage_actions'])&&!is_array($raw['stage_actions']))return [];$out=[];
        foreach($raw['stage_actions']??[] as $action=>$grant){
            if(count($out)>=2||Execution::remaining()<3)break;
            if(!is_array($grant)||empty($grant['enabled'])||empty($grant['renewal']['next_attempt'])||$grant['renewal']['next_attempt']>time())continue;
            $r=self::verify_internal(['action'=>$action,'expected_revision'=>ConversionDelivery::revision()],true);
            $out[$action]=['success'=>!empty($r['verified']),'code'=>$r['code']??'stage_verification_failed'];
        }return $out;
    }
    private static function refused(string $code): array { return ['status'=>'recusado','code'=>$code,'non_delivery_proven'=>true]; }
    private static function receipt_key(string $action,string $event): string { return 'stage:'.hash('sha256',self::CONSUMER.'|'.$action.'|'.$event); }
    public static function payload_schema(): array {
        $s=['type'=>'string'];$click=['type'=>'string','pattern'=>'^[A-Za-z0-9._~-]{1,500}$'];
        return ['type'=>'object','additionalProperties'=>false,'required'=>['contract','purpose','record_id','stage_id','action','event_id','occurred_at','click_ids','order_id','ad_user_data','value','currency'],
            'properties'=>['contract'=>['const'=>self::CONTRACT,'type'=>'string'],'purpose'=>['const'=>self::PURPOSE,'type'=>'string'],
                'record_id'=>['type'=>'string','pattern'=>'^[a-f0-9]{32}$'],'stage_id'=>['type'=>'string','pattern'=>'^[a-zA-Z0-9_-]{1,60}$'],
                'action'=>self::action_schema(),'event_id'=>['type'=>'string','pattern'=>'^[A-Za-z0-9._~-]{1,128}$'],'order_id'=>['type'=>'string','maxLength'=>128],
                'occurred_at'=>['type'=>'string','maxLength'=>40],'click_ids'=>['type'=>'object','maxProperties'=>1,'additionalProperties'=>false,'properties'=>['gclid'=>$click,'gbraid'=>$click,'wbraid'=>$click]],
                'ad_user_data'=>['type'=>'string','enum'=>['GRANTED']],'value'=>['type'=>'number','minimum'=>0,'maximum'=>0],'currency'=>['type'=>'string','enum'=>['BRL']],
                'user_data'=>['type'=>'object','minProperties'=>1,'additionalProperties'=>false,'properties'=>['email'=>['type'=>'string','maxLength'=>254],'telefone'=>['type'=>'string','maxLength'=>40]]]]];
    }
    public function sendBound(array $payload,string $destinationRef): array {
        return Connections::run($this->connection,function()use($payload,$destinationRef){
            if(!ContractSchema::valid($payload,self::payload_schema())||($payload['contract']??'')!==self::CONTRACT||($payload['purpose']??'')!==self::PURPOSE||$payload['action']!==$this->action||$payload['order_id']!==$payload['event_id']||!is_array($payload['click_ids'])||count($payload['click_ids'])>1)return self::refused('stage_payload_invalid');
            $stamp=strtotime($payload['occurred_at']);$date=date_parse($payload['occurred_at']);
            if(!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/D',$payload['occurred_at'])||$date['warning_count']||$date['error_count']||$stamp===false||$stamp>time()||$stamp<time()-7*DAY_IN_SECONDS)return self::refused('stage_time_invalid');
            $ids=[];if(isset($payload['user_data'])){$ids=EnhancedLeads::normalize($payload['user_data']);if(is_wp_error($ids))return self::refused('enhanced_leads_user_data_invalid');}
            if(!$payload['click_ids']&&!$ids)return self::refused('ambiguous_click_identifiers');
            return $this->with_delivery($destinationRef,true,function($s)use($payload,$ids){
                if($ids&&empty(EnhancedLeads::capability($s['config'],$s['reason'])['ready']))return self::refused('enhanced_leads_not_ready');
                $p=['record_id'=>self::receipt_key($this->action,$payload['event_id']),'occurred_at'=>$payload['occurred_at'],'click_ids'=>$payload['click_ids']];
                $context=hash('sha256',wp_json_encode([$payload['record_id'],$payload['stage_id'],$payload['event_id'],$this->action,$payload['occurred_at']]));
                return DataManager::send($p,$s['config'],$s['reference'],$ids,$payload['event_id'],$context);
            },(bool)$ids);
        });
    }
    private function with_delivery(string $ref,bool $send,callable $callback,bool $enhanced=false): array {
        if($ref===''||strlen($ref)>191)return self::refused('destination_mismatch');
        return Recovery::run(function()use($ref,$send,$callback,$enhanced){
            $lock=Lock::acquire('conversion-delivery:'.Connections::id(),90);if(!$lock)return $send?self::refused('busy'):['status'=>'incerto','code'=>'reconciliation_busy'];
            try{
                $s=$this->snapshot($send);
                if($s['reason']||!hash_equals($s['reference'],$ref))return $send?self::refused($s['reason']??'destination_mismatch'):['status'=>'incerto','code'=>'reconciliation_not_authorized'];
                $guard=function()use($lock,$ref,$send,$enhanced){
                    $now=$this->snapshot($send);
                    $ok=Lock::owned($lock)&&!$now['reason']&&hash_equals($ref,$now['reference']);
                    if($enhanced)$ok=$ok&&!empty(EnhancedLeads::capability($now['config'],$now['reason'])['ready']);
                    return $ok?null:new \WP_Error('f3_google_delivery_authorization_changed','Concessão ou destino comercial alterado.');
                };
                return Execution::run(static fn()=>$callback($s),18,$guard);
            }catch(\Throwable $e){return ['status'=>'incerto','code'=>$send?'stage_dispatch_exception':'stage_reconciliation_unknown'];}
            finally{Lock::release($lock);}
        });
    }
    public function reconcileBound(string $eventId,string $destinationRef): array {
        if(!preg_match('/^[A-Za-z0-9._~-]{1,128}$/D',$eventId))return ['status'=>'incerto','code'=>'reconciliation_invalid'];
        return Connections::run($this->connection,fn()=>$this->with_delivery($destinationRef,false,fn($s)=>DataManager::reconcile(self::receipt_key($this->action,$eventId),$destinationRef,$s['config'])));
    }
    public static function reconcile(array $v): array {
        if(!Options::authorized())return self::fail('not_authorized');
        if(!self::valid_action($v['action']??null)||!is_string($v['event_id']??null)||!is_string($v['destination_ref']??null))return self::fail('invalid_input');
        return Response::ok(['result'=>(new self(Connections::id(),$v['action']))->reconcileBound($v['event_id'],$v['destination_ref'])]);
    }
    private static function action_schema(): array { return ['type'=>'string','pattern'=>'^customers/[0-9]{10}/conversionActions/[1-9][0-9]{0,29}$']; }
    public static function capability_schema(): array {
        $s=['type'=>'string'];$b=['type'=>'boolean'];$n=['type'=>['integer','null']];
        $renew=ConversionDelivery::status_schema()['properties']['google_ads']['properties']['renewal'];
        $entry=['type'=>'object','properties'=>['action'=>$s,'purpose'=>$s,'ready'=>$b,'reason'=>$s,'destination_ref'=>$s,'customer_id'=>$s,
            'verified_at'=>$n,'verification_expires_at'=>$n,'enhanced_leads'=>EnhancedLeads::schema(),'renewal'=>$renew]];
        return ['type'=>'object','properties'=>['contract'=>$s,'supported_contracts'=>['type'=>'array','items'=>$s],'consumer_id'=>$s,'purposes'=>['type'=>'array','items'=>$s],
            'ready'=>$b,'reason'=>$s,'connection_id'=>$s,'acquisition_action'=>['type'=>['string','null']],'actions'=>['type'=>'object','additionalProperties'=>$entry],
            'async_reconciliation'=>$s,'analytics_homologated'=>$b]];
    }
    public static function register(): void {
        $s=['type'=>'string'];$b=['type'=>'boolean'];$rev=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];$action=self::action_schema();
        $out=['type'=>'object','properties'=>['success'=>$b,'message'=>$s,'code'=>$s,'revision'=>$s,'persisted'=>$b,'changed'=>$b,'verification_required'=>$b,
            'contract'=>$s,'connection_id'=>$s,'max_actions'=>['type'=>'integer'],'google_checks_performed'=>$b,
            'actions'=>['type'=>'object','additionalProperties'=>self::capability_schema()],
            'verified'=>$b,'provider_error'=>DataManager::diagnostic_schema(),'audit_success'=>$b,'capability'=>self::capability_schema(),
            'result'=>['type'=>'object','properties'=>['status'=>$s,'code'=>$s,'non_delivery_proven'=>$b,'retry_after'=>['type'=>'integer'],'evidence'=>$s,'processed'=>$b]]]];
        $definitions=[
            'stage-conversion-status'=>['status',['action'=>$action],[],'Consultar concessões e provas comerciais por ação; leitura local sem Google.','read','none'],
            'configure-stage-conversion'=>['configure',['expected_revision'=>$rev,'action'=>$action,'enabled'=>$b,'renew_grant'=>$b,'consumer_id'=>['type'=>'string','enum'=>[self::CONSUMER]],'purpose'=>['type'=>'string','enum'=>[self::PURPOSE]]],['expected_revision','action','enabled'],'Conceder ou revogar ação comercial exata; autorização independente da aquisição.','write','none'],
            'verify-stage-conversion'=>['verify',['expected_revision'=>$rev,'action'=>$action],['expected_revision','action'],'Verificar ação comercial, termos e destino Google sem coletar conversão; registra prova e diagnóstico.','write','read'],
            'reconcile-stage-conversion'=>['reconcile',['action'=>$action,'event_id'=>['type'=>'string','pattern'=>'^[A-Za-z0-9._~-]{1,128}$'],'destination_ref'=>['type'=>'string','minLength'=>1,'maxLength'=>191]],['action','event_id','destination_ref'],'Consultar recibo comercial sem reenvio; atualizar confirmação local, respeitando concessão e intervalo.','write','read'],
        ];
        foreach($definitions as $name=>$d)Ability::register('google/'.$name,'any',['label'=>$d[3],'description'=>$d[3],'mode'=>$d[4],'remote_effect'=>$d[5],
            'input_schema'=>['type'=>'object','properties'=>$d[1],'required'=>$d[2]],'output_schema'=>$out,'callback'=>[self::class,$d[0]]]);
    }
}
