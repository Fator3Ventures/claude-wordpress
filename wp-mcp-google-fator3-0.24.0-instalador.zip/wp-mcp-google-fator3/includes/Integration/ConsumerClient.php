<?php
/**
 * Public client bound by object identity to a registered consumer.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
final class ConsumerClient {
    private string $service;
    public function __construct(string $service=ServiceApi::class) {
        if(!in_array($service,[ServiceApi::class,QueryServiceApi::class],true))throw new \InvalidArgumentException('Serviço inválido.');
        $this->service=$service;
    }
	public function query( array $input ): array {
		return ($this->service)::query( $this, $input );
	}
	public function effective_status(): array {
		return ($this->service)::effective_status( $this );
	}
	public function status(): array {
		return ($this->service)::client_status( $this );
	}
}
