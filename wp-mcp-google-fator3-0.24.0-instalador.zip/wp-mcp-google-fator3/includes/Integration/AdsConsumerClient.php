<?php
/** Object identity binds the local Ads reader to a registered consumer. */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class AdsConsumerClient {
    public function capabilities(): array { return AdsServiceApi::capabilities(); }
    public function status(): array { return AdsServiceApi::client_status($this); }
    public function query(array $input): array { return AdsServiceApi::query($this,$input); }
}
