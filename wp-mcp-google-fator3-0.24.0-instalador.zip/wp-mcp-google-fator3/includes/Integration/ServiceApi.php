<?php
/**
 * Public, versioned Search Console reader for registered local plugins.
 *
 * @package Fator3\McpGoogle
 */
declare(strict_types=1);
namespace Fator3\McpGoogle\Integration;
use Fator3\McpGoogle\{
    Ability, Audit, Auth\Credentials, Automation\Execution, Connections, Crypto, Gate, Http\GoogleClient, Options, Policy, Records, Response, Settings, Storage\Admission, Storage\State
};
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class ServiceApi {
    public const CONTRACT = 'search-console-reader/1.0.0';
    public const VERSION = '1.0.0';
    public const CAPABILITY = 'gsc.page-day.read';
    public const GRANTS = 'f3_mcp_google_consumer_grants';
    public const MAX_LIMIT = 5000;
    public const MAX_BUDGET_MS = 20000;
    protected static array $consumers = array();
    protected static function dimensions(): array { return ['date','page']; }
    protected static function more(int $count,int $limit,int $start): bool { return $count===$limit && $start+$count<50000; }
    protected static function coverage(array $coverage): array { return $coverage; }
    protected static function new_grant(string $id,bool $enabled) { return ['enabled'=>$enabled,'capability'=>static::CAPABILITY,'revision'=>bin2hex(random_bytes(16)),'at'=>time()]; }
    public static function init(): void {
        add_action( 'plugins_loaded', array( static::class, 'discover' ), 30 );
    }
    public static function discover(): void {
        do_action( 'f3_mcp_google_register_consumers', new static(), static::CONTRACT );
    }
    public static function capabilities(): array {
        return array(
            'contract' => static::CONTRACT,
            'contract_version' => static::VERSION,
            'plugin_version' => F3_MCP_GOOGLE_VERSION,
            'registration_hook' => 'f3_mcp_google_register_consumers',
            'client_methods' => array( 'query', 'status', 'effective_status' ),
            'capabilities' => array( static::CAPABILITY ),
            'input_schema' => static::schema(),
            'max_budget_ms' => static::MAX_BUDGET_MS,
            'return_margin_ms' => 2000,
            'limit_max' => min( static::MAX_LIMIT, Options::max_rows() ),
            'calendar' => 'America/Los_Angeles',
            'all_rows_guaranteed' => false,
        );
    }
    public static function schema(): array {
        return array(
            'type' => 'object',
            'additionalProperties' => false,
            'required' => array( 'contract_version', 'property', 'consumer_revision', 'date', 'run_id', 'trigger', 'budget_ms' ),
            'properties' => array(
                'contract_version' => array(
                    'type' => 'string',
                    'enum' => array( static::VERSION ),
                ),
                'property' => array(
                    'type' => 'string',
                    'minLength' => 1,
                    'maxLength' => 512,
                ),
                'consumer_revision' => array(
                    'type' => 'string',
                    'minLength' => 1,
                    'maxLength' => 128,
                ),
                'date' => array(
                    'type' => 'string',
                    'pattern' => '^\\d{4}-\\d{2}-\\d{2}$',
                ),
                'limit' => array(
                    'type' => 'integer',
                    'minimum' => 1,
                    'maximum' => min( static::MAX_LIMIT, Options::max_rows() ),
                    'default' => min( 1000, Options::max_rows() ),
                ),
                'cursor' => array(
                    'type' => array( 'string', 'null' ),
                    'maxLength' => 4096,
                ),
                'run_id' => array(
                    'type' => 'string',
                    'minLength' => 1,
                    'maxLength' => 100,
                    'pattern' => '^[A-Za-z0-9._:-]+$',
                ),
                'trigger' => array(
                    'type' => 'string',
                    'enum' => array( 'cli', 'http_cron', 'manual' ),
                ),
                'budget_ms' => array(
                    'type' => 'integer',
                    'minimum' => 1,
                    'maximum' => static::MAX_BUDGET_MS,
                ),
            ),
        );
    }
    /** $configuration returns {property:string,revision:string,ready:bool}. */
    public static function register_consumer( string $id, string $version, string $contract, callable $configuration ) {
        if ( ! preg_match( '/^[a-z][a-z0-9-]{1,79}$/D', $id ) || ! preg_match( '/^\d+\.\d+\.\d+(?:[-+][A-Za-z0-9.-]+)?$/D', $version ) ) {
            return new \WP_Error( 'f3_google_consumer_input', 'Identidade/versão do consumidor inválida.' );
        }
        if ( static::CONTRACT !== $contract ) {
            return new \WP_Error( 'f3_google_consumer_contract', 'Contrato de consumidor incompatível.' );
        }
        if ( isset( static::$consumers[ $id ] ) ) {
            return new \WP_Error( 'f3_google_consumer_duplicate', 'Consumidor já registrado.' );
        }
        $client = new ConsumerClient(static::class);
        static::$consumers[ $id ] = array(
            'id' => $id,
            'version' => $version,
            'configuration' => $configuration,
            'client' => $client,
        );
        return $client;
    }
    protected static function find( ConsumerClient $client ): ?array {
        foreach ( static::$consumers as $consumer ) {
            if ( $consumer['client'] === $client ) {
                return $consumer;
            }
        }
        return null;
    }
    protected static function config( array $consumer ) {
        try {
            $c = ( $consumer['configuration'] )();
        }
        catch ( \Throwable $e ) {
            return new \WP_Error( 'f3_google_consumer_configuration', 'Consumidor não forneceu configuração válida.' );
        }
        if ( ! is_array( $c ) || ! is_bool( $c['ready'] ?? null ) ) {
            return new \WP_Error( 'f3_google_consumer_configuration', 'Callback exige propriedade, revisão e prontidão.' );
        }
        if ( ! $c['ready'] ) {
            return new \WP_Error(
                'f3_google_consumer_not_ready',
                'Estrutura/configuração do consumidor ainda não está pronta.',
                array(
                    'retryable' => true,
                    'retry_after_ms' => 15000,
                )
            );
        }
        if ( ! is_string( $c['property'] ?? null ) || ! static::valid_property( $c['property'] ) || ! is_string( $c['revision'] ?? null ) || strlen( $c['revision'] ) < 1 || strlen( $c['revision'] ) > 128 ) {
            return new \WP_Error( 'f3_google_consumer_configuration', 'Propriedade ou revisão inválida no consumidor.' );
        }
        return array_intersect_key( $c, array_flip( array( 'property', 'revision', 'ready' ) ) );
    }
    public static function valid_property( string $p ): bool {
        if ( strlen( $p ) > 512 || preg_match( '/[\x00-\x20]/', $p ) ) {
            return false;
        }
        if ( str_starts_with( $p, 'sc-domain:' ) ) {
            return (bool) preg_match( '/^sc-domain:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9-]{2,63}$/Di', $p );
        }
        $url = wp_parse_url( $p );
        return is_array( $url ) && in_array( $url['scheme'] ?? '', array( 'http', 'https' ), true ) && ! empty( $url['host'] ) && ! isset( $url['user'] ) && ! isset( $url['pass'] ) && ! isset( $url['query'] ) && ! isset( $url['fragment'] );
    }
    protected static function grants() {
        $r = Options::stored( Options::storage_name( static::GRANTS ) );
        if ( ! $r['success'] || ( $r['exists'] && ! is_array( $r['value'] ) ) ) {
            return new \WP_Error( 'f3_google_consumer_grants_read', 'Autorizações ilegíveis.' );
        }
        return $r['value'] ?? array();
    }
    protected static function guard( array $consumer, array $configuration, string $revision, array $grant ): ?\WP_Error {
        $recovery = \Fator3\McpGoogle\Recovery::guard();
        if ( $recovery ) {
            return $recovery;
        }
        if ( ! Options::is_enabled() ) {
            return new \WP_Error( 'f3_google_disabled', 'Google desativado.' );
        }
        if ($storage = State::guard()) {
            return $storage;
        }
        if ( ! Connections::enabled( 'gsc' ) ) {
            return new \WP_Error( 'f3_google_connector_off', 'Search Console desativado.' );
        }
        $grants = static::grants();
        if ( is_wp_error( $grants ) ) {
            return $grants;
        }
        if ( ( $grants[ $consumer['id'] ] ?? null ) !== $grant || empty( $grant['enabled'] ) || ( $grant['capability'] ?? '' ) !== static::CAPABILITY ) {
            return new \WP_Error( 'f3_google_consumer_unauthorized', 'Consumidor sem concessão vigente nesta conexão.' );
        }
        $now = static::config( $consumer );
        if ( is_wp_error( $now ) ) {
            return $now;
        }
        if ( $now !== $configuration ) {
            return new \WP_Error( 'f3_google_consumer_changed', 'Configuração do consumidor mudou; reinicie a página.' );
        }
        $current = Settings::execution_revision();
        if ( is_wp_error( $current ) ) {
            return $current;
        }
        if ( ! hash_equals( $revision, $current ) ) {
            return new \WP_Error( 'f3_google_context_changed', 'Credencial ou política mudou durante a consulta.' );
        }
        if ( ! Policy::permitted( 'gsc', $configuration['property'] ) ) {
            return new \WP_Error( 'f3_google_policy', 'Propriedade fora da política da conexão.' );
        }
        $credentials = Credentials::current();
        return is_wp_error( $credentials ) ? $credentials : null;
    }
    public static function query( ConsumerClient $client, array $input ): array {
        $consumer = static::find( $client );
        if ( ! $consumer ) {
            return static::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
        }
        $error = static::validate_input( $input );
        if ( $error ) {
            return static::failure( $error );
        }
        return Execution::run( static fn()=>static::authorized_query( $consumer, $input ), $input['budget_ms'] / 1000 );
    }
    protected static function authorized_query( array $consumer, array $input ): array {
        $cfg = static::config( $consumer );
        if ( is_wp_error( $cfg ) ) {
            return static::failure( $cfg );
        }
        if ( $input['property'] !== $cfg['property'] || $input['consumer_revision'] !== $cfg['revision'] ) {
            return static::failure( new \WP_Error( 'f3_google_consumer_property', 'Consulta deve usar propriedade e revisão atuais do consumidor.' ) );
        }
        $resolved = static::resolve_grant( $consumer['id'] );
        if ( is_wp_error( $resolved ) ) {
            return static::failure( $resolved );
        }
        if ( 'resolved' !== $resolved['resolution'] ) {
            return static::failure( new \WP_Error( 'f3_google_consumer_unauthorized', 'Autorize o consumidor em exatamente uma conexão.' ) );
        }
        $cid = $resolved['connection_id'];
        $grant = $resolved['grant'];
        return Connections::run(
            $cid,
            static function () use ( $consumer, $cfg, $input, $grant ): array {
            $revision = Settings::execution_revision();
            if ( is_wp_error( $revision ) ) {
                return static::failure( $revision );
            }
            $guard = static fn()=>static::guard( $consumer, $cfg, $revision, $grant );
            $error = $guard();
            if ( $error ) {
                return static::failure( $error );
            }
            return Admission::run(
                'plugin:'.static::CAPABILITY,
                static fn()=>Execution::run(
                    static fn()=>static::page( $consumer, $cfg, $input, $revision, $grant, $guard ),
                    $input['budget_ms'] / 1000,
                    $guard
                )
            );
            }
        );
    }
    protected static function validate_input( array $i ): ?\WP_Error {
        $schema = static::schema();
        if ( array_diff( array_keys( $i ), array_keys( $schema['properties'] ) ) || array_diff( $schema['required'], array_keys( $i ) ) ) {
            return new \WP_Error( 'f3_google_consumer_input', 'Parâmetros ausentes ou não permitidos.' );
        }
        if ( ( $i['contract_version'] ?? '' ) !== static::VERSION ) {
            return new \WP_Error( 'f3_google_consumer_contract', 'Versão de contrato incompatível.' );
        }
        foreach ( array( 'property', 'consumer_revision', 'date', 'run_id', 'trigger' ) as $k ) {
            if ( ! is_string( $i[ $k ] ) ) {
                return new \WP_Error( 'f3_google_consumer_input', 'Tipo inválido: ' . $k );
            }
        }
        if ( ! in_array( $i['trigger'], array( 'cli', 'http_cron', 'manual' ), true ) || ! preg_match( '/^[A-Za-z0-9._:-]{1,100}$/D', $i['run_id'] ) || ! is_int( $i['budget_ms'] ) || $i['budget_ms'] < 1 || $i['budget_ms'] > static::MAX_BUDGET_MS || ( isset( $i['limit'] ) && ( ! is_int( $i['limit'] ) || $i['limit'] < 1 || $i['limit'] > min( static::MAX_LIMIT, Options::max_rows() ) ) ) || ( isset( $i['cursor'] ) && ( ! is_string( $i['cursor'] ) || strlen( $i['cursor'] ) > 4096 ) ) ) {
            return new \WP_Error( 'f3_google_consumer_input', 'Origem, prazo, limite ou cursor inválido.' );
        }
        $d = \DateTimeImmutable::createFromFormat( '!Y-m-d', $i['date'], new \DateTimeZone( 'America/Los_Angeles' ) );
        if ( ! $d || $d->format( 'Y-m-d' ) !== $i['date'] || $d >= new \DateTimeImmutable( 'today', new \DateTimeZone( 'America/Los_Angeles' ) ) ) {
            return new \WP_Error( 'f3_google_consumer_date', 'Informe um dia passado válido no calendário Search Console.' );
        }
        return null;
    }
    protected static function page( array $consumer, array $cfg, array $i, string $revision, array $grant, callable $guard ): array {
        $limit = $i['limit'] ?? min( 1000, Options::max_rows() );
        $start = 0;
        $binding = array( $consumer['id'], Connections::id(), $cfg['property'], $cfg['revision'], $i['date'], $limit, $revision, $grant['revision'] );
        if ( ! empty( $i['cursor'] ) ) {
            $plain = Crypto::decrypt( $i['cursor'] );
            $c = is_string( $plain ) ? json_decode( $plain, true ) : null;
            if ( ! is_array( $c ) || ( $c['binding'] ?? null ) !== $binding || ( $c['expires'] ?? 0 ) < time() || ! is_int( $c['start'] ?? null ) || $c['start'] < 0 ) {
                return static::failure( new \WP_Error( 'f3_google_consumer_cursor', 'Cursor inválido, expirado ou de outro contexto.' ) );
            }
            $start = $c['start'];
        }
        $body = array(
            'startDate' => $i['date'],
            'endDate' => $i['date'],
            'dimensions' => static::dimensions(),
            'type' => 'web',
            'dataState' => 'final',
            'aggregationType' => 'auto',
            'rowLimit' => $limit,
            'startRow' => $start,
        );
        $request = Records::id();
        $ctx = array(
            'actor' => array(
                'type' => 'plugin',
                'id' => $consumer['id'],
                'version' => $consumer['version'],
            ),
            'run_id' => $i['run_id'],
            'trigger' => $i['trigger'],
            'request_id' => $request,
            'property' => $cfg['property'],
            'consumer_revision' => $cfg['revision'],
            'body' => $body,
            'http_attempts' => 0,
            'query_dispatched' => false,
        );
        return Context::run(
            $ctx,
            static function () use ( $cfg, $i, $body, $request, $binding, $start, $limit, $guard ): array {
            $common = array(
                'contract_version' => static::VERSION,
                'request_id' => $request,
                'connection_id' => Connections::id(),
                'property' => $cfg['property'],
                'consumer_revision' => $cfg['revision'],
                'date' => $i['date'],
                'run_id' => $i['run_id'],
            );
            $deadline = Execution::check();
            if ( $deadline ) {
                return static::failure( $deadline, $common );
            }
            $before = Audit::append(
                'plugin:'.str_replace('.read','',static::CAPABILITY).'.begin',
                $cfg['property'],
                array(
                    'mode' => 'read',
                    'status' => 'started',
                )
            );
            if ( ! $before['success'] ) {
                return static::failure( new \WP_Error( 'f3_google_audit_persistence', 'Consulta suspensa: auditoria indisponível.' ), $common );
            }
            $raw = GoogleClient::post(
                GoogleClient::HOST_GOOGLE . '/webmasters/v3/sites/' . rawurlencode( $cfg['property'] ) . '/searchAnalytics/query',
                $body,
                array(
                    'connector' => 'gsc',
                    'mode' => 'read',
                    'operation_id' => 'webmasters.searchanalytics.query',
                    'scopes' => array( 'https://www.googleapis.com/auth/webmasters.readonly' ),
                    'retries' => 0,
                )
            );
            $context = Context::current();
            $common['remote_dispatched'] = ! empty( $context['query_dispatched'] );
            $common['http_attempts'] = $context['http_attempts'];
            $error = is_wp_error( $raw ) ? $raw : $guard();
            $rows = array();
            if ( ! $error ) {
                if ( ( array_key_exists( 'responseAggregationType', $raw ) || ! empty( $raw['rows'] ) ) && ( $raw['responseAggregationType'] ?? null ) !== 'byPage' ) {
                    $error = new \WP_Error( 'f3_google_consumer_response', 'Agregação inesperada; esperado por página.' );
                }
                if ( array_key_exists( 'rows', $raw ) && ! is_array( $raw['rows'] ) ) {
                    $error = new \WP_Error( 'f3_google_consumer_response', 'Linhas inválidas.' );
                }
                foreach ( is_array( $raw['rows'] ?? null ) ? $raw['rows'] : array() as $r ) {
                    if ( ! is_array( $r ) || ! is_array( $r['keys'] ?? null ) || count( $r['keys'] ) !== count(static::dimensions()) || (count(static::dimensions())===3 && !is_string($r['keys'][2]??null)) || $r['keys'][0] !== $i['date'] || ! is_string( $r['keys'][1] ) || ( ! filter_var( $r['keys'][1], FILTER_VALIDATE_URL ) || ! in_array( wp_parse_url( $r['keys'][1], PHP_URL_SCHEME ), array( 'https', 'http' ), true ) ) ) {
                        $error = new \WP_Error( 'f3_google_consumer_response', 'Dimensões inválidas.' );
                        break;
                    }
                    foreach ( array( 'clicks', 'impressions', 'ctr', 'position' ) as $n ) {
                        if ( ! isset( $r[ $n ] ) || ! is_numeric( $r[ $n ] ) || ! is_finite( (float) $r[ $n ] ) || $r[ $n ] < 0 ) {
                            $error = new \WP_Error( 'f3_google_consumer_response', 'Métricas inválidas.' );
                            break 2;
                        }
                    }
                    $rows[] = array(
                        'date' => $r['keys'][0],
                        'page' => $r['keys'][1],
                        'clicks' => (float) $r['clicks'],
                        'impressions' => (float) $r['impressions'],
                        'ctr' => (float) $r['ctr'],
                        'position' => (float) $r['position'],
                    ) + (count(static::dimensions())===3?['query'=>$r['keys'][2]]:[]);
                }
                if ( count( $rows ) > $limit ) {
                    $error = new \WP_Error( 'f3_google_consumer_response', 'Resposta excedeu o limite solicitado.' );
                }
            }
            $next = null;
            $full = count( $rows ) === $limit;
            $ceiling = $start + count( $rows ) >= 50000;
            if ( ! $error && static::more(count($rows),$limit,$start) ) {
                $next = Crypto::encrypt(
                    wp_json_encode(
                        array(
                            'binding' => $binding,
                            'start' => $start + count( $rows ),
                            'expires' => time() + 86400,
                        )
                    )
                );
                if ( ! $next ) {
                    $error = new \WP_Error( 'f3_google_crypto_encrypt', 'Não foi possível criar cursor.' );
                }
            }
            $result = $error ? static::failure( $error, $common ) : Response::ok(
                $common + array(
                    'extracted_at' => time(),
                    'rows' => $rows,
                    'next_cursor' => $next,
                    'coverage' => static::coverage(array(
                        'limit' => $limit,
                        'returned_rows' => count( $rows ),
                        'pagination_complete' => ! $full,
                        'truncated' => $full,
                        'truncation_reason' => $full ? ( $ceiling ? 'api_daily_row_limit' : 'page_pending' ) : null,
                        'all_rows_guaranteed' => false,
                        'calendar' => 'America/Los_Angeles',
                        'data_state' => 'final',
                        'dimensions' => static::dimensions(),
                        'type' => 'web',
                        'aggregation' => 'byPage',
                        'start_row' => $start,
                        'filters' => array(),
                    )),
                )
            );
            $after = Audit::append(
                'plugin:'.str_replace('.read','',static::CAPABILITY).'.end',
                $cfg['property'],
                array(
                    'mode' => 'read',
                    'status' => $result['success'] ? 'completed' : 'failed',
                    'rows' => count( $rows ),
                    'error_code' => $result['error_code'] ?? null,
                )
            );
            if ( ! $after['success'] ) {
                return static::failure(
                    new \WP_Error( 'f3_google_audit_incomplete', 'Consulta concluída; registro final não confirmado. Não avance o cursor.' ),
                    $common + array(
                        'query_result' => $result,
                        'audit_success' => false,
                    )
                );
            }
            $result['audit_success'] = true;
            $saved = Options::set(
                (static::VERSION==='1.0.0'?'f3_mcp_google_consumer_last_':'f3_mcp_google_query_consumer_last_') . Connections::id() . '_' . hash( 'sha256', Context::current()['actor']['id'] ),
                array(
                    'at' => time(),
                    'success' => $result['success'],
                    'error_code' => $result['error_code'] ?? null,
                    'request_id' => $request,
                    'run_id' => $i['run_id'],
                    'rows' => count( $rows ),
                )
            );
            if ( ! $saved['success'] ) {
                return static::failure( new \WP_Error( 'f3_google_consumer_state', 'Último atendimento não confirmado.' ), $common + array( 'query_result' => $result ) );
            }
            return $result;
            }
        );
    }
    protected static function failure( \WP_Error $e, array $extra = array() ): array {
        $d = (array) $e->get_error_data();
        $result = Response::fail(
            $e,
            $extra + array(
                'contract_version' => static::VERSION,
                'retryable' => (bool) ( $d['retryable'] ?? false ),
                'retry_after_ms' => $d['retry_after_ms'] ?? ( isset( $d['retry_after'] ) ? (int) $d['retry_after'] * 1000 : null ),
                'next_eligible_at' => $d['next_eligible_at'] ?? null,
                'remote_dispatched' => false,
            )
        );
        // Preserve the service correlation; an HTTP request id remains in details.
        if ( isset( $extra['request_id'] ) ) {
            $result['request_id'] = $extra['request_id'];
        }
        return $result;
    }
    /** Internal resolution reused by query and the optional local diagnostic. */
    protected static function resolve_grant( string $id ) {
        $registry = Connections::registry_verified();
        if ( is_wp_error( $registry ) ) {
            return $registry;
        }
        $matches = array();
        foreach ( array_keys( $registry ) as $cid ) {
            $g = Connections::run( $cid, static fn()=>static::grants() );
            if ( is_wp_error( $g ) ) {
                return $g;
            }
            if ( ! is_array( $g ) || isset( $g['error_code'] ) || ( isset( $g[ $id ] ) && ( ! is_array( $g[ $id ] ) || ! is_bool( $g[ $id ]['enabled'] ?? null ) ) ) ) {
                return new \WP_Error( 'f3_google_consumer_grants_read', 'Autorizações ilegíveis.' );
            }
            if ( ! empty( $g[ $id ]['enabled'] ) ) {
                $matches[ $cid ] = $g[ $id ];
            }
        }
        $resolution = count( $matches ) === 1 ? 'resolved' : ( $matches ? 'ambiguous' : 'not_granted' );
        return array(
            'resolution' => $resolution,
            'connection_id' => 'resolved' === $resolution ? key( $matches ) : null,
            'grant' => 'resolved' === $resolution ? current( $matches ) : null,
        );
    }
    public static function effective_status( ConsumerClient $client ): array {
        $consumer = static::find( $client );
        if ( ! $consumer ) {
            return static::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
        }
        $resolved = static::resolve_grant( $consumer['id'] );
        $out = array(
            'contract' => static::CONTRACT,
            'consumer_id' => $consumer['id'],
            'resolution' => 'unreadable',
            'connection_id' => null,
            'reason_codes' => array(),
            'local_status' => null,
            'checked_at' => time(),
        );
        if ( is_wp_error( $resolved ) ) {
            $out['reason_codes'] = array( $resolved->get_error_code() );
            return $out;
        }
        $out['resolution'] = $resolved['resolution'];
        $out['connection_id'] = $resolved['connection_id'];
        if ( 'resolved' !== $out['resolution'] ) {
            $out['reason_codes'] = array( 'ambiguous' === $out['resolution'] ? 'f3_google_consumer_ambiguous' : 'f3_google_consumer_unauthorized' );
            return $out;
        }
        $out['local_status'] = Connections::run( $out['connection_id'], static fn()=>static::local_status( $consumer, $resolved['grant'] ) );
        return $out;
    }
    /** Explicit nested projections: stored arrays never pass through to another plugin. */
    protected static function local_status( array $consumer, array $grant ): array {
        $cfg = static::config( $consumer );
        $last = Options::stored( (static::VERSION==='1.0.0'?'f3_mcp_google_consumer_last_':'f3_mcp_google_query_consumer_last_') . Connections::id() . '_' . hash( 'sha256', $consumer['id'] ) );
        $recovery = \Fator3\McpGoogle\Recovery::status();
        $last_service = null;
        $last_error = null;
        if ( ! $last['success'] || ( $last['exists'] && ! is_array( $last['value'] ) ) ) {
            $last_error = 'f3_google_consumer_state_read';
        }
        elseif ( $last['exists'] ) {
            $v = $last['value'];
            $last_service = array(
                'at' => is_int( $v['at'] ?? null ) ? $v['at'] : null,
                'success' => is_bool( $v['success'] ?? null ) ? $v['success'] : null,
                'rows' => is_int( $v['rows'] ?? null ) ? max( 0, $v['rows'] ) : null,
            );
            foreach ( array( 'run_id', 'request_id' ) as $k ) {
                $last_service[ $k ] = is_string( $v[ $k ] ?? null ) && preg_match( '/^[A-Za-z0-9._:-]{1,100}$/D', $v[ $k ] ) ? $v[ $k ] : null;
            }
            $last_service['error_code'] = static::diagnostic_code( $v['error_code'] ?? null );
        }
        $states = Options::snapshot( array( Options::ENABLED, Options::storage_name( Connections::SERVICES ) ) );
        $revision = Settings::revision();
        $read_ok = ! is_wp_error( $revision ) && ! in_array( false, array_column( $states, 'success' ), true );
        return array(
            'configuration' => is_wp_error( $cfg ) ? array(
                'ready' => false,
                'error_code' => $cfg->get_error_code(),
            ) : $cfg,
            'grant' => array(
                'enabled' => ( $grant['enabled'] ?? null ) === true,
                'capability' => ( $grant['capability'] ?? null ) === static::CAPABILITY ? static::CAPABILITY : null,
            ),
            'google_enabled' => $read_ok ? Options::is_enabled() : null,
            'gsc_enabled' => $read_ok ? Connections::enabled( 'gsc' ) : null,
            'configuration_error' => $read_ok ? null : 'f3_google_option_read',
            'configured' => $read_ok ? Credentials::is_configured() : null,
            'policy_allowed' => $read_ok && ! is_wp_error( $cfg ) ? Policy::permitted( 'gsc', $cfg['property'] ) : null,
            'recovery' => array(
                'paused' => is_bool( $recovery['paused'] ?? null ) ? $recovery['paused'] : null,
                'error_code' => static::diagnostic_code( $recovery['error_code'] ?? null ),
            ),
            'last_service' => $last_service,
            'last_service_error' => $last_error,
            'remote_access_verified' => false,
            'consumer_commit_verified' => false,
        );
    }
    protected static function diagnostic_code( $value ): ?string {
        return is_string( $value ) && preg_match( '/^f3_[a-z0-9_]{1,95}$/D', $value ) ? $value : null;
    }
    public static function administrative_status( array $input = array() ): array {
        $revision = Settings::revision();
        if ( is_wp_error( $revision ) ) {
            return Response::fail(
                $revision,
                array(
                    'contract' => static::CONTRACT,
                    'connection_id' => Connections::id(),
                    'configuration_revision' => null,
                    'read_success' => false,
                )
            );
        }
        if ( ! empty( $input['compact'] ) ) {
            return Response::ok(
                array(
                    'contract' => static::CONTRACT,
                    'connection_id' => Connections::id(),
                    'configuration_revision' => $revision,
                    'read_success' => true,
                    'contracts' => [static::CONTRACT,QueryServiceApi::CONTRACT,Ga4ServiceApi::CONTRACT,AdsServiceApi::CONTRACT],
                    'compact' => true,
                ) + \Fator3\McpGoogle\Auth\Credentials::service_account_identity()
            );
        }
        return Response::ok(
            static::status() + \Fator3\McpGoogle\Auth\Credentials::service_account_identity() + array(
                'ga4' => Ga4ServiceApi::status(),
                'gsc_query' => QueryServiceApi::status(),
                'ads_archive' => AdsServiceApi::status(),
                'configuration_revision' => $revision,
                'read_success' => true,
                    'contracts' => [static::CONTRACT,QueryServiceApi::CONTRACT,Ga4ServiceApi::CONTRACT,AdsServiceApi::CONTRACT],
            )
        );
    }
    public static function client_status( ConsumerClient $client ): array {
        $c = static::find( $client );
        return $c ? static::status( $c['id'] ) : static::failure( new \WP_Error( 'f3_google_consumer_unregistered', 'Cliente não registrado.' ) );
    }
    public static function status( ?string $only = null ): array {
        $g = static::grants();
        $items = array();
        foreach ( static::$consumers as $id => $c ) {
            if ( null !== $only && $id !== $only ) {
                continue;
            }
            $cfg = static::config( $c );
            $items[] = array(
                'effective_status' => null === $only ? static::effective_status( $c['client'] ) : null,
                'id' => $id,
                'version' => $c['version'],
                'configuration' => is_wp_error( $cfg ) ? array(
                    'ready' => false,
                    'error_code' => $cfg->get_error_code(),
                ) : $cfg,
                'grant' => is_wp_error( $g ) ? null : ( $g[ $id ] ?? null ),
                'last_service' => Options::get( (static::VERSION==='1.0.0'?'f3_mcp_google_consumer_last_':'f3_mcp_google_query_consumer_last_') . Connections::id() . '_' . hash( 'sha256', $id ), null ),
            );
        }
        return array(
            'contract' => static::CONTRACT,
            'connection_id' => Connections::id(),
            'consumers' => $items,
            'grants_error' => is_wp_error( $g ) ? $g->get_error_code() : null,
            'google_enabled' => Options::is_enabled(),
            'configured' => Credentials::is_configured(),
        );
    }
    public static function configure( array $input ): array {
        if (static::class===self::class && ($input['contract']??'')===QueryServiceApi::CONTRACT) return QueryServiceApi::configure($input);
        if (($input['contract']??static::CONTRACT)===Ga4ServiceApi::CONTRACT) return Ga4ServiceApi::configure($input);
        if (($input['contract']??static::CONTRACT)!==static::CONTRACT || isset($input['property'])) return static::failure(new \WP_Error('f3_google_consumer_contract','Contrato ou propriedade não permitido.'));
        if ( ! current_user_can( 'manage_options' ) || ! Options::authorized() ) {
            return static::failure( new \WP_Error( 'f3_google_forbidden', 'Permissão administrativa exigida.' ) );
        }
        $id = $input['consumer_id'] ?? '';
        $enabled = $input['enabled'] ?? null;
        if ( ! is_string( $id ) || ! isset( static::$consumers[ $id ] ) || ! is_bool( $enabled ) || ! is_string( $input['expected_revision'] ?? null ) ) {
            return static::failure( new \WP_Error( 'f3_google_consumer_input', 'Consumidor, enabled e expected_revision são obrigatórios.' ) );
        }
        // Single site lock prevents two simultaneous grants on different connections.
        $lock = \Fator3\McpGoogle\Lock::acquire( 'consumer-grants', 30 );
        if ( ! $lock ) {
            return static::failure( new \WP_Error( 'f3_google_consumer_busy', 'Concessão em atualização.' ) );
        }
        try {
            if ( $enabled ) {
                foreach ( array_keys( Connections::registry() ) as $cid ) {
                    if ( Connections::id() === $cid ) {
                        continue;
                    }
                    $other = Connections::run( $cid, static fn()=>static::grants() );
                    if ( is_wp_error( $other ) ) {
                        return static::failure( $other );
                    }
                    if ( ! empty( $other[ $id ]['enabled'] ) ) {
                        return static::failure( new \WP_Error( 'f3_google_consumer_connection', 'Revogue a concessão na outra conexão antes de transferir.' ) );
                    }
                }
            }
            $grants = static::grants();
            if ( is_wp_error( $grants ) ) {
                return static::failure( $grants );
            }
            if ( ! isset( $grants[ $id ] ) || $grants[ $id ]['enabled'] !== $enabled || (static::VERSION!=='1.0.0' && $enabled) ) {
                $grant=static::new_grant($id,$enabled);
                if(is_wp_error($grant))return static::failure($grant);
                $prior=$grants[$id]??[];
                $stable=static fn($g)=>array_diff_key($g,['revision'=>true,'at'=>true]);
                $grants[$id]=$stable($prior)===$stable($grant)?$prior:$grant;
            }
            return Settings::save( array( static::GRANTS => $grants ), array(), array(), $input['expected_revision'] ) + array( 'integration' => static::status() );
        }
        finally {
            \Fator3\McpGoogle\Lock::release( $lock );
        }
    }
    public static function register(): void {
        Ability::register(
            'google/integration-status',
            'any',
            array(
                'label' => 'Google: integração com plugins',
                'description' => 'Contrato, revisão da conexão selecionada e consumidores. compact:true permite ler a revisão em uma resposta pequena, sem credenciais ou chamadas Google.',
                'input_schema' => array(
                    'properties' => array(
                        'compact' => array(
                            'type' => 'boolean',
                            'default' => false,
                        ),
                    ),
                ),
                'output_schema' => array(
                    'type' => 'object',
                    'properties' => array(
                        'success' => array( 'type' => 'boolean' ),
                        'message' => array( 'type' => 'string' ),
                        'contract' => array( 'type' => 'string' ),
                        'connection_id' => array( 'type' => 'string' ),
                        'configuration_revision' => array( 'type' => array( 'string', 'null' ) ),
                        'read_success' => array( 'type' => 'boolean' ),
                        'compact' => array( 'type' => 'boolean' ),
                        'client_email'=>['type'=>['string','null']],
                        'project_id'=>['type'=>['string','null']],
                        'contracts' => ['type'=>'array','items'=>['type'=>'string']],
                        'ga4' => ['type'=>'object'],
                        'gsc_query' => ['type'=>'object'],
                        'ads_archive' => ['type'=>'object'],
                        'consumers' => array(
                            'type' => 'array',
                            'items' => array( 'type' => 'object' ),
                        ),
                    ),
                ),
                'callback' => array( static::class, 'administrative_status' ),
            )
        );
        Ability::register(
            'google/configure-consumer',
            'any',
            array(
                'label' => 'Google: autorizar consumidor',
                'description' => 'Concede ou revoga leitura para plugin registrado nesta conexão. Search Console 1.0 lê página/dia; 1.1 lê consulta/página/dia com concessão própria. GA4 exige contract ga4-reader/1.0.0 e property canônica. Novas concessões fixam a propriedade.',
                'mode' => 'write',
                'input_schema' => array(
                    'required' => array( 'consumer_id', 'enabled', 'expected_revision' ),
                    'properties' => array(
                        'contract' => ['type'=>'string','enum'=>[static::CONTRACT,QueryServiceApi::CONTRACT,Ga4ServiceApi::CONTRACT],'default'=>static::CONTRACT],
                        'property' => ['type'=>'string','description'=>'Obrigatória para GA4: properties/123.'],
                        'consumer_id' => array( 'type' => 'string' ),
                        'enabled' => array( 'type' => 'boolean' ),
                        'expected_revision' => array( 'type' => 'string' ),
                    ),
                ),
                'callback' => array( static::class, 'configure' ),
            )
        );
    }
}
