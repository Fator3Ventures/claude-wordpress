<?php
declare(strict_types=1);
namespace Fator3\Meta;
defined('ABSPATH') || exit;

/** Searchable technical projection only; payload and authority remain encrypted. */
final class Queue {
    public static function pending(): bool {
        global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state='' LIMIT 1",Store::table()));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Índice da fila indisponível.');return $v!==null;
    }
    public static function migrate(): array {
        return Store::lock('queue-migration',static function(){
            global $wpdb;$keys=$wpdb->get_col($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state='' ORDER BY queue_next,record_key LIMIT 100",Store::table()));
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao migrar índice da fila.');$count=0;
            foreach($keys as $key){$r=Store::get('job',$key);if(!$r)continue;$v=$r['value'];
                $n=$wpdb->query($wpdb->prepare("UPDATE %i SET queue_state=%s,queue_next=%d WHERE bucket='job' AND record_key=%s AND revision=%d AND queue_state=''",Store::table(),$v['status']??'invalid',max(0,(int)($v['next_at']??0)),$key,$r['revision']));
                if($n===false)throw new Fault('storage_unavailable','Falha ao projetar coleta.');$count+=$n;
            }
            $result=['processed'=>$count,'complete'=>!self::pending(),'at'=>time()];update_option(Config::KEY.'_queue_migration',$result,false);return $result;
        });
    }
    /** Two bounded range scans, then merge, avoiding a filesort over terminal jobs. */
    public static function due(int $limit=20): array {
        global $wpdb;$rows=[];$limit=max(1,min(20,$limit));
        foreach(['queued','retry'] as $state){$batch=$wpdb->get_results($wpdb->prepare("SELECT record_key,queue_next FROM %i WHERE bucket='job' AND queue_state=%s AND queue_next<=%d ORDER BY queue_next,record_key LIMIT %d",Store::table(),$state,time(),$limit),ARRAY_A);
            if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao selecionar fila executável.');$rows=array_merge($rows,$batch);}
        usort($rows,static fn($a,$b)=>((int)$a['queue_next']<=>(int)$b['queue_next'])?:strcmp($a['record_key'],$b['record_key']));return array_slice($rows,0,$limit);
    }
    public static function waiting(): bool {
        global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT record_key FROM %i WHERE bucket='job' AND queue_state IN ('queued','retry','') LIMIT 1",Store::table()));
        if($wpdb->last_error)throw new Fault('storage_unavailable','Falha ao conferir fila.');return $v!==null;
    }
    public static function health(): array {
        $first=self::due(1);$next=$first?(int)$first[0]['queue_next']:null;
        return ['oldest_due_at'=>$next,'oldest_due_lag_seconds'=>$next===null?0:max(0,time()-$next),'migration_pending'=>self::pending(),'migration'=>get_option(Config::KEY.'_queue_migration',null)];
    }
}

final class Worker {
    private const AUTH_CODES=['not_authorized','grant_revoked','credential_revoked','authorization_revoked','asset_access_denied','revision_conflict','credential_revalidation_required'];
    public static function ensure(int $delay=60): bool {
        if(Schedules::active()||Queue::waiting())return Jobs::scheduleTick($delay);
        return true;
    }
    public static function bootstrap(): void {
        if(Queue::pending()){Result::run(static fn()=>Queue::migrate());self::ensure();}
    }
    public static function maintenance(): void {
        // Recovery must precede retention, whose failure cannot break the chain.
        $recovery=Result::run(static fn()=>['scheduled'=>self::ensure()]);
        try{Result::run(static fn()=>Queue::migrate());$prune=Result::run(static fn()=>['removed'=>Store::prune()]);}
        finally{Result::run(static fn()=>['scheduled'=>self::ensure()]);self::notifySafely();}
        update_option(Config::KEY.'_last_maintenance',['at'=>time(),'recovery'=>$recovery['success'],'retention_code'=>$prune['code']],false);
    }
    public static function health(): array {
        $now=time();$queue=Queue::health();$issues=[];$active=0;
        foreach(Store::list('schedule',0,100) as $r){$v=$r['value'];if(empty($v['enabled']))continue;$active++;
            $common=['schedule_id'=>$r['key'],'label'=>$v['label']??$r['key']];$code=$v['last_code']??null;
            // A grant may be revoked after the schedule creates its job.
            if(!empty($v['last_job'])){$job=Store::get('job',$v['last_job']);if($job&&in_array($job['value']['last_code']??null,self::AUTH_CODES,true))$code=$job['value']['last_code'];}
            if(in_array($code,self::AUTH_CODES,true))$issues[]=$common+['code'=>'schedule_authorization_failed','last_code'=>$code,'action'=>'Confira a conexão e salve novamente esta agenda com a concessão atual autorizada.'];
            $lag=max(0,$now-(int)$v['next_at']);if($lag>2*60*(int)$v['interval_minutes'])$issues[]=$common+['code'=>'schedule_overdue','lag_seconds'=>$lag,'action'=>'Confira o cron e a autorização da agenda.'];
        }
        $next=wp_next_scheduled(Config::KEY.'_worker')?:null;$needed=$active>0||Queue::waiting();
        if($needed&&$next===null)$issues[]=['code'=>'worker_missing','action'=>'Rearmar o worker local e conferir o cron do servidor.'];
        if($queue['migration_pending'])$issues[]=['code'=>'queue_migration_pending','action'=>'Aguarde as passagens do worker; consulte a migração se não houver progresso.'];
        return ['state'=>$issues?'degraded':'ok','observed_at'=>$now,'issues'=>$issues,'active_schedules'=>$active,'worker_required'=>$needed,'cron'=>['next'=>$next,'last'=>get_option(Config::KEY.'_last_worker',null),'traffic_required'=>!(defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON),'last_schedule_attempt'=>get_option(Config::KEY.'_worker_schedule_attempt',null),'last_schedule_failure'=>get_option(Config::KEY.'_worker_schedule_failure',null)],'queue'=>$queue,'notification'=>get_option(Config::KEY.'_operation_notice',null)];
    }
    public static function status(): array {
        $h=self::health();$observed=$h['cron']['next'];$attempted=$h['worker_required']&&$observed===null;
        $repair=$attempted?Result::run(static fn()=>['scheduled'=>Jobs::scheduleTick()]):null;
        $h['cron']['observed_next']=$observed;$h['cron']['next']=wp_next_scheduled(Config::KEY.'_worker')?:null;
        $h['recovery']=['attempted'=>$attempted,'scheduled'=>$attempted?($repair['data']['scheduled']??false):null,'code'=>$repair['code']??null];
        $h['cron']['last_schedule_attempt']=get_option(Config::KEY.'_worker_schedule_attempt',null);$h['cron']['last_schedule_failure']=get_option(Config::KEY.'_worker_schedule_failure',null);
        return ['provider'=>Config::SLUG,'version'=>Config::VERSION,'storage_ready'=>Store::ready(),'crypto_ready'=>Crypto::available(),'connection_count'=>count(Connections::list()),'mcp_installed'=>class_exists('\\Fator3\\McpFiles\\ExtensionContract'),'abilities_available'=>function_exists('wp_register_ability'),'audit_health'=>get_option(Config::KEY.'_audit_health','unknown')]+$h;
    }
    public static function notifySafely(): void {Result::run(static function(){self::notify();return [];});}
    public static function notify(): void {
        Store::lock('operation-notice',static function(){
            $h=self::health();$issues=array_values(array_filter($h['issues'],static fn($i)=>$i['code']!=='queue_migration_pending'));
            if(!$issues)return;
            $old=get_option(Config::KEY.'_operation_notice',[]);$now=time();
            // Site-wide throttle, including failures/uncertain sends, prevents per-minute storms.
            if($now-(int)($old['attempted_at']??0)<3600)return;
            $notice=['attempted_at'=>$now,'state'=>'sending','issue_count'=>count($issues)];
            update_option(Config::KEY.'_operation_notice',$notice,false);
            if(get_option(Config::KEY.'_operation_notice')!==$notice)return;
            $to=sanitize_email((string)get_option('admin_email',''));$lines=['Fator3 MCP Meta: a coleta requer atenção.',home_url('/'),''];
            foreach($issues as $i)$lines[]=($i['label']??'Worker').' ('.($i['schedule_id']??'cron').'): '.$i['action'];
            $lines[]='Abra Ferramentas → Fator3 MCP Meta → Diagnóstico. Nenhuma concessão foi renovada automaticamente.';
            $sent=false;try{if(is_email($to))$sent=wp_mail($to,'Fator3 MCP Meta: atenção às coletas',implode("\n",$lines));}catch(\Throwable $e){$sent=false;}
            $notice['state']=$sent?'accepted':'failed';$notice['finished_at']=time();update_option(Config::KEY.'_operation_notice',$notice,false);
        });
    }
}
