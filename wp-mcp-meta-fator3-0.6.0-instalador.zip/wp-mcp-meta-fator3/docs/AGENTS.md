# Guia para agentes — 0.6.0

Leia `documentation` com document=index e continue cada documento por next_offset e expected_revision. Confira SHA-256. O catálogo não comprova disponibilidade remota. Entradas humanas exigem administrador; `users` não amplia esse direito. Não obtenha credenciais pelo navegador nem escreva arquivos para expô-las.

Antes de gravar, releia a configuração e use a revisão. Descubra nomes por `admin-options` e mantenha seleção explícita. Nunca interprete uma lista descoberta como autorização. Preservar campos não enviados é a forma de atualizar apenas a seção desejada. Confirme o retorno persistido e a revisão. Não repita mutações incertas.

Meta orgânico permanece neste plugin; anúncios/Pixel/CAPI não são incorporados. LinkedIn mantém Lead Reader 1.0/1.1; o consumidor Core detém ingestão e deduplicação comercial. `admin-options` é auxílio administrativo e não substitui o cliente SDK nem conclui demandas de outro pacote.

Distinguir testes de fixtures, WordPress real e fornecedor real. As credenciais do dono e aprovação do produto são necessárias para homologação externa. Não publicar, gastar Ads, enviar notificações reais ou criar assinaturas comerciais como teste sem autorização específica.

Na 0.6.0, descubra os rótulos/descrições em português pelo registro MCP. Use os mesmos IDs `meta/*` nas chamadas. Consulte `abilities-pt-br.json` pelo leitor documental; versão/hash confirmam a instalação. Um rótulo antigo após a troca exige nova descoberta/reabertura da tela, sem recriar perfis.

## Operação da fila na 0.6.0

Consulte `WORKER.md` no índice documental para recuperação automática, efeitos de `meta/status`, índice SQL, migração, alertas por e-mail e concessões revogadas. O estado é observado antes do reparo; `cron.next` mostra o evento depois da tentativa. `meta/status` exige escrita local; a leitura de documentação continua sem efeitos.
