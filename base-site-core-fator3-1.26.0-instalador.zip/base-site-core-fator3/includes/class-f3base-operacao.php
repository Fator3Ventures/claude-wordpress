<?php
/** Registro fechado dos trabalhos Core; cron nativo, CLI e ability usam o mesmo executor. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Operacao {
    const OPTION='f3base_operacao_estado';const MAX_TRABALHOS=3;const MAX_SEGUNDOS=30;const LEASE_SEGUNDOS=180;
    private static array $callbacks=array();private static array $nativos=array();private static bool $consumindo=false;private static bool $desativando=false;
    /** Align a planned date in the WordPress timezone, preserving its calendar day. */
    public static function alinhar(int $at,string $clock): int {$d=(new DateTimeImmutable('@'.$at))->setTimezone(wp_timezone());[$h,$m]=array_map('intval',explode(':',$clock));$x=$d->setTime($h,$m);if($x->getTimestamp()<=time()){$x=$x->modify('+1 day');}return $x->getTimestamp();}
    public static function reconciliar_horarios(): void {
        $tz=wp_timezone_string();$state=get_option('f3base_agenda',array());if(($state['fuso']??null)===$tz){return;}$ok=true;
        foreach(array('f3base_retencao_limpeza'=>'01:00','f3base_cadencia_relatorio'=>'06:00') as $hook=>$clock){$e=wp_get_scheduled_event($hook);if(!$e){continue;}$at=self::alinhar((int)$e->timestamp,$clock);if($at===$e->timestamp){continue;}$l=F3Base_Trava::adquirir('horario-'.hash('sha256',$hook),30);if(!$l){$ok=false;continue;}try{$deleted=wp_unschedule_event($e->timestamp,$hook,$e->args,true);$new=$deleted===true?wp_schedule_event($at,$e->schedule,$hook,$e->args,true):false;if($new!==true||wp_next_scheduled($hook)!==$at){if($deleted===true){wp_schedule_event($e->timestamp,$e->schedule,$hook,$e->args);}$ok=false;}elseif($hook==='f3base_cadencia_relatorio'){F3Base_Options::atualizar_estado('f3base_cadencia_estado',static fn($s)=>array_merge($s,array('previsto'=>$at)));}}finally{F3Base_Trava::liberar($l);}}
        if($ok){F3Base_Options::atualizar_estado('f3base_agenda',static fn($v)=>array_merge($v,array('fuso'=>$tz,'em'=>time(),'retencao'=>'01:00','cadencia'=>'06:00','cache'=>'minuto 10, antes da validade da prova')));}
    }
    public static function cache_regular(int $expires): int {$d=(new DateTimeImmutable('@'.$expires))->setTimezone(wp_timezone());$d=$d->setTime((int)$d->format('H'),10);if($d->getTimestamp()>$expires){$d=$d->modify('-1 hour');}return max(time()+F3Base_Cache_Evidencia::INTERVALO,$d->getTimestamp());}
    public static function tarefas(): array {
        $r=array(
            'migracao'=>array('Atualização de estrutura',array('f3base_migrar_estrutura')),
            'acessos'=>array('Logs fechados e continuação',array('f3base_acessos_somar','f3base_acessos_continuar')),
            'editorial'=>array('Catálogo e agregados editoriais',array('f3base_editorial_atualizar')),
            'clarity'=>array('Acervo Clarity',array('f3base_clarity_coletar','f3base_clarity_retomar')),
            'gsc'=>array('Search Console',array('f3base_gsc_coletar','f3base_gsc_continuar')),
            'redes_robos'=>array('Redes oficiais dos robôs',array('f3base_redes_robos_atualizar')),
            'llms'=>array('Índices Markdown',array('f3base_llms_converter_lote','f3base_llms_regenerar')),
            'robots'=>array('Entrega de robots',array('f3base_robots_verificar')),
            'servidor'=>array('Prova de regras do servidor',array(F3Base_Servidor::EVENTO)),
            'ofertas'=>array('Verificação de ofertas',array('f3base_ofertas_verificar')),
            'navegacao'=>array('Prova de navegação',array('f3base_navegacao_verificar_cron','f3base_navegacao_rever')),
            'schema'=>array('Dados estruturados',array('f3base_schema_verificar')),
            'cache'=>array('Cache e diretórios públicos',array('f3base_cache_verificar')),
            'gtm'=>array('Diagnóstico GTM',array('f3base_gtm_verificar')),
            'capi'=>array('Conversões Meta',array('f3base_capi_recuperar','f3base_meta_capi_enviar')),
            'manutencao'=>array('Avisos, respostas e manutenção',array('f3base_leads_resumo','f3base_consentimento_indexar')),
            'pipedrive'=>array('Pipedrive e eliminação',array('f3base_pipedrive_processar')),
            'anuncios'=>array('Anúncios Meta',array('f3base_anuncios_consultar')),
            'integracoes'=>array('Verificação de integrações',array('f3base_integracoes_verificar','f3base_integracoes_reverificar')),
            'avisos_crm'=>array('Avisos de entrega ao CRM',array('f3base_pipedrive_alertas')),
            'avisos_contatos'=>array('Avisos de contatos',array(F3Base_Leads_Notificacoes::AVISOS,F3Base_Avisos::EVENTO)),
            'aparelhos'=>array('Classificação histórica de aparelhos',array('f3base_aparelhos_historico')),
            'retencao'=>array('Retenção e eliminação',array(F3Base_Modulo_Retencao_Eliminacao::EVENTO,'f3base_intencoes_podar','f3base_cache_podar')),
            'cadencia'=>array('Relatório periódico',array('f3base_cadencia_relatorio')),
        );foreach($r as $id=>$v){$r[$id]=array('rotulo'=>$v[0],'hooks'=>$v[1]);}return $r;
    }
    public static function identificar_hook(string $hook): string {foreach(self::tarefas() as $id=>$t){if(in_array($hook,$t['hooks'],true)){return $id;}}return '';}
    /** Existing module registration stays transparent until all modules have registered. */
    public static function callback(string $hook,callable $callback): callable {return $callback;}
    public static function sanitizar_estado($v,$p=array()): array {return is_array($v)?array_intersect_key($v,self::tarefas()):array();}
    private static function proprio($cb): bool {
        try{$ref=is_array($cb)?new ReflectionMethod($cb[0],$cb[1]):(is_string($cb)&&str_contains($cb,'::')?new ReflectionMethod($cb):new ReflectionFunction($cb));$path=realpath($ref->getFileName()?:'');return $path&&str_starts_with($path,realpath(F3BASE_PLUGIN_DIR).DIRECTORY_SEPARATOR);}catch(Throwable $e){return false;}
    }
    public static function registrar_callbacks(): void {
        global $wp_filter;
        foreach(self::tarefas() as $t){foreach($t['hooks'] as $hook){if(isset(self::$callbacks[$hook])||empty($wp_filter[$hook])){continue;}$entries=array();
            foreach($wp_filter[$hook]->callbacks as $priority=>$callbacks){foreach($callbacks as $entry){if(self::proprio($entry['function'])){$entry['priority']=$priority;$entries[]=$entry;}}}
            if(!$entries){continue;}self::$callbacks[$hook]=$entries;
            foreach($entries as $entry){remove_action($hook,$entry['function'],$entry['priority']);}
            add_action($hook,static function(...$args)use($hook){self::nativo($hook,$args);},min(array_column($entries,'priority')),99);
        }}
    }
    public static function iniciar(): void {
        add_action('init',array(__CLASS__,'reconciliar_horarios'),99);
        F3Base_Execucoes::iniciar_hooks();
        add_action('init',array(__CLASS__,'registrar_callbacks'),PHP_INT_MAX-10);
        add_action('init',array(__CLASS__,'recuperar_agendamentos'),PHP_INT_MAX-5);add_action('f3base_operacao_retomar',static fn()=>self::executar_pendentes());
        add_filter('pre_unschedule_event',static function($pre,$at,$hook,$args){if(!self::$consumindo&&self::identificar_hook($hook)&&((defined('WP_CLI')&&WP_CLI)||wp_doing_cron())){self::$nativos[$hook.'|'.serialize($args)][]=(int)$at;}return $pre;},10,4);
        add_filter('schedule_event',array(__CLASS__,'alinhar_evento'));
    }
    public static function proximo_horario(string $hhmm,array $hours=array()): int {
        $now=new DateTimeImmutable('now',wp_timezone());$candidates=array();
        foreach($hours?:array($hhmm) as $h){$d=$now->setTime((int)substr($h,0,2),(int)substr($h,3,2),0);if($d<=$now){$d=$d->modify('+1 day');}$candidates[]=$d->getTimestamp();}return min($candidates);
    }
    public static function alinhar_evento($event){
        if(!$event||!empty($event->args)||empty($event->schedule)){return $event;}
        if(in_array($event->hook,array('f3base_retencao_limpeza','f3base_cadencia_relatorio'),true)){$event->timestamp=self::alinhar((int)$event->timestamp,$event->hook==='f3base_retencao_limpeza'?'01:00':'06:00');return $event;}
        $map=array('f3base_redes_robos_atualizar'=>'02:00','f3base_clarity_coletar'=>'03:00','f3base_gtm_verificar'=>'04:00','f3base_gsc_coletar'=>F3Base_Options::ler('f3base_gsc')['horario']??'05:00');
        if(isset($map[$event->hook])){$event->timestamp=self::proximo_horario($map[$event->hook]);}
        elseif($event->hook==='f3base_navegacao_verificar_cron'){$event->timestamp=self::proximo_horario('00:00',array('00:00','12:00'));}
        elseif($event->hook==='f3base_leads_resumo'){$now=new DateTimeImmutable('now',wp_timezone());$event->timestamp=$now->setTime((int)$now->format('H'),0,0)->modify('+1 hour')->getTimestamp();}
        return $event;
    }
    private static function eventos(): array {
        $r=array();foreach(_get_cron_array()?:array() as $at=>$hooks){foreach($hooks as $hook=>$events){$id=self::identificar_hook($hook);if(!$id){continue;}foreach($events as $event){$r[]=array('id'=>$id,'hook'=>$hook,'timestamp'=>(int)$at,'args'=>$event['args']??array(),'schedule'=>$event['schedule']??false);}}}
        foreach(F3Base_Operacao_Intencoes::listar(1,true) as $event){if(($event['tentar_em']??0)>time()){continue;}$exists=false;foreach($r as $old){if($old['hook']===$event['hook']&&$old['args']===$event['args']&&$old['timestamp']===$event['timestamp']){$exists=true;break;}}if(!$exists){$r[]=$event;}}
        usort($r,static fn($a,$b)=>[$a['timestamp'],$a['hook'],serialize($a['args'])]<=>[$b['timestamp'],$b['hook'],serialize($b['args'])]);return $r;
    }
    public static function excecao(Throwable $e,string $etapa='callback',string $tarefa=''): array {
        $raw=$e->getMessage();$known=array('checkpoint_nao_persistido','reagendamento_recusado','consumo_agendamento_recusado','checkpoint_falhou','etapa_nao_confirmada','sentinela_gravacao_falhou','linha_nao_persistida','commit_falhou','consulta_falhou','intencao_nao_persistida','intencoes_leitura_falhou');$causas=array('checkpoint_nao_persistido'=>'O banco não confirmou a reserva da tarefa.','reagendamento_recusado'=>'A agenda recusou a próxima recorrência.','consumo_agendamento_recusado'=>'A agenda recusou o consumo da ocorrência.','checkpoint_falhou'=>'O banco não confirmou o checkpoint.','etapa_nao_confirmada'=>'A etapa não confirmou a conclusão.','sentinela_gravacao_falhou'=>'O arquivo da guarda não confirmou a gravação.');$causas+=array('linha_nao_persistida'=>'O banco não confirmou a gravação da linha.','commit_falhou'=>'O banco não confirmou a transação.','consulta_falhou'=>'A consulta ao banco falhou.','intencao_nao_persistida'=>'O banco não confirmou a intenção ou sua reserva.','intencoes_leitura_falhou'=>'A leitura das intenções falhou.');$file=str_replace('\\','/',$e->getFile());$base=rtrim(str_replace('\\','/',F3BASE_PLUGIN_DIR),'/').'/';$interno=str_starts_with($file,$base);$codigo=$interno&&preg_match('/^[a-z][a-z0-9_]{2,63}$/D',$raw)?$raw:null;if($codigo===null&&(($interno&&str_contains(basename($file),'llms'))||str_starts_with($tarefa,'llms'))){$codigo='llms_excecao_nao_catalogada';}$causas+=F3Base_Erros::mensagens();$message=$causas[$raw]??($codigo?'Falha local identificada pelo código interno deste retorno.':'Falha local sem mensagem estruturada segura; confira classe, etapa, arquivo e linha deste retorno.');
        foreach(array('Cannot access offset of type'=>'Acesso a índice em tipo incompatível.','Call to undefined method'=>'Método não disponível.','Call to undefined function'=>'Função não disponível.','Undefined array key'=>'Chave de array ausente.','Typed property'=>'Propriedade tipada indisponível.','Argument #'=>'Tipo de argumento incompatível.') as $prefix=>$safe){if(str_starts_with($raw,$prefix)){$message=$safe;break;}}
        $file=str_replace('\\','/',$e->getFile());$base=str_replace('\\','/',F3BASE_PLUGIN_DIR);
        return array('codigo_interno'=>$codigo,'etapa'=>$etapa,'classe'=>get_class($e),'mensagem'=>mb_substr($message,0,300),'arquivo'=>str_starts_with($file,$base)?substr($file,strlen($base)):'fora_do_plugin','linha'=>$e->getLine());
    }
    public static function agenda(): array {
        $state=F3Base_Options::ler(self::OPTION);$events=self::eventos();$r=array();
        foreach(self::tarefas() as $id=>$t){$matches=array_values(array_filter($events,static fn($e)=>$e['id']===$id));$e=$matches[0]??array();$at=$e['timestamp']??0;$v=$state[$id]??array();$registered=(bool)array_intersect($t['hooks'],array_keys(self::$callbacks));
            $r[$id]=array('id'=>$id,'rotulo'=>$t['rotulo'],'hook'=>$e['hook']??'','registrada'=>$registered,'proxima_execucao'=>$at,'proxima_formatada'=>$at?wp_date('d/m/Y H:i:s T',$at):null,'argumentos'=>$e['args']??array(),'ocorrencias'=>count($matches),'atraso_segundos'=>$at?max(0,time()-$at):0,'atrasado'=>$at>0&&$at<=time(),'reservada'=>($v['lease']['ate']??0)>time(),'reserva_ate'=>$v['lease']['ate']??0,'ultima_execucao'=>$v['ultima']??array(),'ultimo_sucesso'=>$v['ultimo_sucesso']??array(),'saldo'=>self::saldo($id,$v),'recuperacao'=>$v['recuperacao']??array(),'codigo'=>!$registered?'inativa':(!$at?'sem_agendamento':($at<=time()?'atrasada':'agendada')));
        }return $r;
    }
    private static function nativo(string $hook,array $args): void {
        $key=$hook.'|'.serialize($args);$at=!empty(self::$nativos[$key])?array_shift(self::$nativos[$key]):null;
        if(!F3Base_Execucoes::atual()){F3Base_Execucoes::iniciar('cron_nativo');}
        self::executar_evento(array('id'=>self::identificar_hook($hook),'hook'=>$hook,'args'=>$args,'timestamp'=>$at,'schedule'=>false),true);
    }
    private static function intencao_chave(array $e): string {return hash('sha256',$e['hook'].'|'.serialize($e['args']).'|'.($e['timestamp']??''));}
    private static function adiar(array $e,string $codigo,bool $falha=false,int $minimo=0): array {
        if($codigo==='ocorrencia_ja_processada'){F3Base_Operacao_Intencoes::concluir($e);return array('id'=>$e['id'],'ok'=>true,'status'=>'concluida','codigo'=>$codigo);}
        if(in_array($codigo,array('trava_banco_falhou','trava_arquivo_inacessivel','trava_arquivo_falhou','diario_indisponivel','tarefa_lancou_excecao','resultado_pendente','diario_persistencia_falhou','diario_leitura_falhou'),true)){$falha=true;}
        return F3Base_Operacao_Intencoes::adiar($e,$codigo,$falha,$minimo);
    }
    private static function tentativa_observada(array $e,array $r): array {$r['observabilidade']=F3Base_Execucoes::tentativa($e['id'],$e['hook'],$e['timestamp'],$r['codigo']??'reserva_indisponivel')?'registrada':'falhou';return $r;}
    private static function executar_evento(array $e,bool $nativo=false): array {
        $id=$e['id'];$hook=$e['hook'];$args=$e['args'];if($e['timestamp']===null){$e['timestamp']=time();}$apresentada=array('timestamp'=>(int)$e['timestamp'],'schedule'=>$e['schedule']??false);try{$deferred=F3Base_Operacao_Intencoes::obter($e);}catch(Throwable $x){return array('id'=>$id,'ok'=>false,'codigo'=>'intencoes_leitura_falhou','erro'=>self::excecao($x,'intencoes'));}if($deferred){if($e['timestamp']>$deferred['timestamp']){F3Base_Operacao_Intencoes::cobrir($deferred,(int)$e['timestamp']);}$e=array_merge($e,$deferred);if(($deferred['estado']??'')==='esgotada'&&$deferred['tentar_em']<=time()&&F3Base_Operacao_Intencoes::sondar($deferred['intencao'])){$deferred['estado']=$e['estado']='pendente';$deferred['falhas']=$e['falhas']=7;}}if(in_array($deferred['estado']??'',array('esgotada','suspensa'),true)){return array('ok'=>true,'status'=>$deferred['estado'],'codigo'=>'intencao_'. $deferred['estado'],'id'=>$id,'intencao'=>$deferred['intencao']);}if(($deferred['tentar_em']??0)>time()){return array('ok'=>true,'status'=>'pendente','codigo'=>'aguardando_retomada','id'=>$id,'tentar_em'=>$deferred['tentar_em']);}
        if(self::$desativando||empty(self::$callbacks[$hook])){return array('ok'=>false,'codigo'=>'tarefa_inativa','id'=>$id);}
        if(!F3Base_Recuperacao::entrar()){ $r=$nativo?self::adiar($e,'core_em_recuperacao'):array('ok'=>false,'codigo'=>'core_em_recuperacao','id'=>$id);$r['observabilidade']=F3Base_Execucoes::tentativa($id,$hook,$e['timestamp'],'core_em_recuperacao')?'registrada':'falhou';return $r;}
        global $wpdb;$lock='f3core:'.substr(hash('sha256',$wpdb->prefix.$id),0,48);$locked=false;$fileLock=null;$task=null;$r=array('id'=>$id,'status'=>'pendente','ok'=>false,'codigo'=>'reserva_indisponivel');
        $etapa='reserva';try{
            if(!F3Base_Execucoes::pode_trabalhar()){$r=self::adiar($e,'orcamento_esgotado');return self::tentativa_observada($e,$r);}
            $fileLock=F3Base_Recuperacao::reservar_tarefa($id);if(!$fileLock){$r=self::adiar($e,F3Base_Recuperacao::erro_tarefa());return self::tentativa_observada($e,$r);}
            $dbLock=$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock));$locked=(int)$dbLock===1;if(!$locked){$r=self::adiar($e,$dbLock===null?'trava_banco_falhou':'reserva_ocupada');return self::tentativa_observada($e,$r);}
            $task=F3Base_Execucoes::iniciar_tarefa($id,$hook,$args,$e['timestamp']);
            if(!$task){$claim=F3Base_Execucoes::reivindicacao();$r=array_merge(self::adiar($e,$claim['codigo']??'diario_indisponivel'),$claim);return self::tentativa_observada($e,$r);}
            $etapa='checkpoint';if(!F3Base_Operacao_Intencoes::registrar($e)||!F3Base_Operacao_Intencoes::reservar($e,$task)){throw new RuntimeException('intencao_nao_persistida');}$start=time();$save=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($id,$hook,$args,$start,$task,$e){$v[$id]['lease']=array('token'=>$task,'ate'=>$start+180);$v[$id]['recuperacao']=array('hook'=>$hook,'args'=>$args,'pendente'=>true,'timestamp'=>$e['timestamp'],'quando'=>$start+180);$v[$id]['ultima']=array('origem'=>F3Base_Execucoes::origem(),'inicio'=>$start,'run_id'=>$task,'status'=>'executando');return $v;});
            if(empty($save['persisted'])){throw new RuntimeException('checkpoint_nao_persistido');}
            if(!$nativo&&$e['timestamp']!==null){$etapa='agenda';self::$consumindo=true;try{
                if($e['schedule']&&!wp_reschedule_event($e['timestamp'],$e['schedule'],$hook,$args)){if((int)wp_next_scheduled($hook,$args)<=$e['timestamp']){throw new RuntimeException('reagendamento_recusado');}}
                if(!wp_unschedule_event($e['timestamp'],$hook,$args)&&wp_get_scheduled_event($hook,$args,$e['timestamp'])){throw new RuntimeException('consumo_agendamento_recusado');}
                if($apresentada['timestamp']!==(int)$e['timestamp']&&wp_get_scheduled_event($hook,$args,$apresentada['timestamp'])){
                    if($apresentada['schedule']&&!wp_reschedule_event($apresentada['timestamp'],$apresentada['schedule'],$hook,$args)){throw new RuntimeException('reagendamento_recusado');}
                    if(!wp_unschedule_event($apresentada['timestamp'],$hook,$args)&&wp_get_scheduled_event($hook,$args,$apresentada['timestamp'])){throw new RuntimeException('consumo_agendamento_recusado');}
                }
            }finally{self::$consumindo=false;}}
            if(!$nativo){self::$consumindo=true;try{foreach(_get_cron_array()?:array() as $at=>$hooks){if($at>time()||empty($hooks[$hook])){continue;}foreach($hooks[$hook] as $cron){if(($cron['args']??array())!==$args){continue;}if(!empty($cron['schedule'])&&!wp_reschedule_event($at,$cron['schedule'],$hook,$args)){throw new RuntimeException('reagendamento_recusado');}if(!wp_unschedule_event($at,$hook,$args)&&wp_get_scheduled_event($hook,$args,$at)){throw new RuntimeException('consumo_agendamento_recusado');}}}}finally{self::$consumindo=false;}}
            $etapa='callback';$results=array();$ok=true;$confirmed=true;$partial=false;$waiting=false;$next=0;
            foreach(self::$callbacks[$hook] as $entry){
                if(F3Base_Execucoes::restante_ms()<1000){$ok=false;$partial=true;$results[]=array('codigo'=>'orcamento_esgotado');break;}
                $out=call_user_func_array($entry['function'],array_slice($args,0,$entry['accepted_args']));
                if(is_wp_error($out)||$out===false){$ok=false;$results[]=array('ok'=>false,'codigo'=>'callback_recusou');}
                elseif(is_array($out)){$safe=self::resultado_seguro($out);$results[]=$safe;if(in_array($safe['codigo']??'',array('atualizacao_em_recuo','atualizacao_em_lotes','atualizacao_em_execucao','aguardando_servico','aguardando_retomada','consentimento_aguardando_trava','verificacao_em_recuo','verificacao_ocupada','catalogo_em_continuacao','orcamento_execucao','orcamento_local_esgotado','janela_requisicoes','aguarda_limite','limite_api','quota_aguardando','orcamento_esgotado'),true)){$waiting=true;$next=max($next,(int)($out['proxima_tentativa']??$out['tentar_em']??0));}if(isset($safe['ok'])&&!$safe['ok']){$ok=false;}if(!isset($safe['ok'])){$confirmed=false;}$partial=$partial||!empty($safe['parcial'])||!empty($safe['incompleto'])||($safe['restantes']??0)>0||($safe['saldo']??0)>0;}
                else{$confirmed=false;$results[]=array('codigo'=>'callback_sem_confirmacao');}
            }
            $r=array('id'=>$id,'ok'=>$ok,'status'=>$ok?($partial?'parcial':($confirmed?'concluido':'executado')):'pendente','codigo'=>$ok?($confirmed?'lote_concluido':'executado_sem_confirmacao'):'resultado_pendente','parcial'=>$partial,'aguardando'=>$waiting,'tentar_em'=>$next,'resultado_modulo_confirmado'=>$confirmed&&$ok&&!$partial,'resultados_modulos'=>$results,'run_id'=>$task,'origem'=>F3Base_Execucoes::origem());if($waiting){$r['ok']=true;$r['status']='aguardando';$r['codigo']='quota_aguardando';$r['resultado_modulo_confirmado']=false;}
        }catch(Throwable $x){$r=array('id'=>$id,'ok'=>false,'status'=>'falha','codigo'=>'tarefa_lancou_excecao','run_id'=>$task,'origem'=>F3Base_Execucoes::origem(),'erro'=>self::excecao($x,$etapa,$id));@error_log('F3BASE tarefa='.sanitize_key($id).' '.wp_json_encode($r['erro']));if(!$task){$r['observabilidade']=F3Base_Execucoes::tentativa($id,$hook,$e['timestamp'],$r['codigo'],$r['erro'])?'registrada':'falhou';}}
        finally{
            if($task){$done=time();$persist=F3Base_Options::atualizar_estado(self::OPTION,static function($v)use($id,$task,$done,$r){if(($v[$id]['lease']['token']??'')!==$task){return $v;}$v[$id]['lease']=array();$v[$id]['ultima']=array_merge($v[$id]['ultima'],array('fim'=>$done,'status'=>$r['status'],'codigo'=>$r['codigo']));$v[$id]['recuperacao']['pendente']=empty($r['ok'])||!empty($r['aguardando']);$v[$id]['recuperacao']['quando']=max($done+60,(int)($r['tentar_em']??0));if(!empty($r['resultado_modulo_confirmado'])){$v[$id]['ultimo_sucesso']=$v[$id]['ultima'];}return $v;});$r['confirmado_localmente']=!empty($persist['persisted']);if(!$r['confirmado_localmente']&&!empty($r['ok'])){$r['ok']=false;$r['status']='pendente';$r['codigo']='checkpoint_nao_persistido';$r['resultado_modulo_confirmado']=false;}
                $journal=$r;if(!empty($r['aguardando'])){$journal['ok']=false;}if(empty($r['aguardando'])&&empty($r['resultado_modulo_confirmado'])&&!empty($r['ok'])){unset($journal['ok']);}F3Base_Execucoes::concluir_tarefa($task,$journal);if(!F3Base_Operacao_Intencoes::liberar_reserva($e,$task)){$r['ok']=false;$r['codigo']='intencao_nao_persistida';}
            }
            if($locked){$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}F3Base_Recuperacao::liberar_tarefa($fileLock);F3Base_Recuperacao::sair();
        }
        if(empty($r['ok'])||!empty($r['aguardando'])){$r['recuperacao']=self::adiar($e,!empty($r['aguardando'])?'quota_aguardando':$r['codigo'],empty($r['aguardando']),(int)($r['tentar_em']??0));}else{F3Base_Operacao_Intencoes::concluir($e);}return $r;
    }
    public static function executar_uma(string $id,string $origem='administracao',bool $somente_vencida=true,string $hook_especifico=''): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)&&!wp_doing_cron()){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(!isset(self::tarefas()[$id])){return array('ok'=>false,'codigo'=>'tarefa_nao_permitida');}
        self::registrar_callbacks();$own=F3Base_Execucoes::iniciar('executor');if(!F3Base_Execucoes::atual()){return array('ok'=>false,'codigo'=>'diario_indisponivel');}$r=array('id'=>$id,'ok'=>true,'codigo'=>'nenhuma_execucao_vencida','status'=>'sem_pendencia');
        try{$events=array_values(array_filter(self::eventos(),static fn($e)=>$e['id']===$id&&(!$hook_especifico||$e['hook']===$hook_especifico)&&$e['timestamp']<=time()));
            if($events){$r=self::executar_evento($events[0]);}
            elseif(!$somente_vencida){$hook=$hook_especifico?:self::tarefas()[$id]['hooks'][0];$r=self::executar_evento(array('id'=>$id,'hook'=>$hook,'args'=>array(),'timestamp'=>null,'schedule'=>false));}
        }finally{if($own){F3Base_Execucoes::encerrar();}}return $r+array('execucoes'=>F3Base_Execucoes::resumo());
    }
    public static function executar_pendentes(array $entrada=array()): array {
        if(!current_user_can('manage_options')&&!(defined('WP_CLI')&&WP_CLI)&&!wp_doing_cron()){return array('ok'=>false,'codigo'=>'sem_permissao','resultados'=>array());}
        $ids=$entrada['tarefas']??array_keys(self::tarefas());if(!empty($entrada['reativar_esgotada'])){if(count($ids)!==1||empty($entrada['intencao'])){return array('ok'=>false,'codigo'=>'reativacao_exige_tarefa_e_intencao');}$rr=F3Base_Operacao_Intencoes::reativar($entrada['intencao'],$ids[0]);if(empty($rr['ok'])){return $rr;}}if(!is_array($ids)||array_diff($ids,array_keys(self::tarefas()))){return array('ok'=>false,'codigo'=>'tarefa_nao_permitida');}
        self::registrar_callbacks();$limit=max(1,min(3,(int)($entrada['limite']??3)));$own=F3Base_Execucoes::iniciar('executor');if(!F3Base_Execucoes::atual()){return array('ok'=>false,'codigo'=>'diario_indisponivel','resultados'=>array());}$rows=array();
        if(!empty(F3Base_Recuperacao::ler()['ok'])&&empty(F3Base_Recuperacao::ler()['pausado'])){F3Base_Operacao_Intencoes::retomar();}
        $vistos=array();try{foreach(self::eventos() as $e){if(count($rows)>=$limit||!F3Base_Execucoes::pode_trabalhar()){break;}if($e['timestamp']>time()||!in_array($e['id'],$ids,true)||empty(self::$callbacks[$e['hook']])){continue;}$scope=$e['hook'].'|'.serialize($e['args']);if(isset($vistos[$scope])){continue;}$vistos[$scope]=true;$rows[]=self::executar_evento($e);}}
        finally{if($own){F3Base_Execucoes::encerrar();}}
        F3Base_Operacao_Intencoes::podar();$agenda=self::agenda();$saldo=count(array_filter($agenda,static fn($a)=>$a['atrasado']&&$a['registrada']));$ok=!array_filter($rows,static fn($r)=>empty($r['ok']));
        return array('ok'=>$ok,'codigo'=>$saldo||!$ok?'execucao_parcial':'execucao_concluida','origem'=>F3Base_Execucoes::origem(),'resultados'=>$rows,'agenda'=>$agenda,'tarefas_vencidas_restantes'=>$saldo,'limite_trabalhos'=>$limit,'orcamento_segundos'=>30,'intencoes'=>F3Base_Operacao_Intencoes::resumo(),'execucoes'=>F3Base_Execucoes::resumo());
    }
    public static function alinhar_agenda(): void {
        $signature=hash('sha256',wp_timezone_string().'|'.(F3Base_Options::ler('f3base_gsc')['horario']??'05:00'));
        if((get_option('f3base_agenda',array())['assinatura']??'')===$signature){return;}$ok=true;
        foreach(self::eventos() as $e){if(!$e['schedule']||$e['args']||$e['timestamp']<=time()){continue;}$o=(object)array('hook'=>$e['hook'],'timestamp'=>$e['timestamp'],'args'=>$e['args'],'schedule'=>$e['schedule']);$new=self::alinhar_evento(clone $o);if($new->timestamp===$o->timestamp){continue;}
            self::$consumindo=true;try{$saved=wp_schedule_event($new->timestamp,$new->schedule,$new->hook,$new->args);if($saved){$ok=wp_unschedule_event($o->timestamp,$o->hook,$o->args)&&$ok;}else{$ok=false;}}finally{self::$consumindo=false;}
        }if($ok){F3Base_Options::atualizar_estado('f3base_agenda',static fn($v)=>array_merge($v,array('assinatura'=>$signature)));}
    }
    public static function recuperar_agendamentos(): void {
        if(self::$desativando||!empty(F3Base_Recuperacao::ler()['pausado'])){return;}
        self::alinhar_agenda();
        foreach(F3Base_Options::ler(self::OPTION) as $id=>$s){$r=$s['recuperacao']??array();if(!empty($r['pendente'])&&($s['lease']['ate']??0)<=time()&&($r['quando']??0)<=time()&&isset(self::$callbacks[$r['hook']??''])){self::adiar(array('id'=>$id,'hook'=>$r['hook'],'args'=>$r['args']??array(),'timestamp'=>$r['timestamp']??null),'retomada_apos_interrupcao');}}
    }
    public static function registrar(): void {
        F3Base_Servicos::ability('executar-pendentes','Executar tarefas vencidas do Core sob reserva e orçamento',array(__CLASS__,'executar_pendentes'),array('tarefas'=>array('type'=>'array','maxItems'=>count(self::tarefas()),'items'=>array('type'=>'string','enum'=>array_keys(self::tarefas()))),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>3),'intencao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'reativar_esgotada'=>array('type'=>'boolean','default'=>false)),array(),false);
    }
    public static function desativar(): void {wp_unschedule_hook('f3base_operacao_retomar');self::$desativando=true;}
	private static function saldo( string $id, array $estado ): array {
		$r = array(
			'conhecido'    => false,
			'quantidade'   => null,
			'observado_em' => null,
			'escopo'       => 'nao_medido',
			'fonte'        => 'nenhuma',
		);
		if ( 'acessos' === $id ) {
			$v           = F3Base_Options::ler( 'f3base_acessos_estado' );
			$r['escopo'] = 'arquivos_pendentes_na_ultima_inspecao';
			$r['fonte']  = 'f3base_acessos_estado';
			if ( ! empty( $v['tentativa'] ) && array_key_exists( 'pendentes', $v ) && empty( $v['erro'] ) && ( $v['config_hash'] ?? '' ) === F3Base_Modulo_Acessos_Servidor::config_hash() ) {
				$r['quantidade']   = max( 0, (int) $v['pendentes'] );
				$r['observado_em'] = (int) $v['tentativa'];
				$r['conhecido']    = true;
			}
		} elseif ( 'capi' === $id && F3Base_Capi_Fila::pronta() ) {
			global $wpdb;
			$linhas      = F3Base_Capi_Fila::resumo();
			$r['escopo'] = 'eventos_nao_terminais_inclui_reconciliacao';
			$r['fonte']  = 'fila_capi_estados';
			if ( '' === $wpdb->last_error ) {
				$r['quantidade'] = 0;
				foreach ( $linhas as $linha ) {
					if ( in_array( $linha['estado'], array( 'pendente', 'reservado', 'enviando', 'cancelando', 'suspenso', 'incerto' ), true ) ) {
						$r['quantidade'] += (int) $linha['eventos']; }
				}
				$r['observado_em'] = time();
				$r['conhecido']    = true;
			}
		} elseif ( ! empty( $estado['saldo_resultado'] ) ) {
			$r = array_merge(
				$r,
				$estado['saldo_resultado'],
				array(
					'conhecido' => true,
					'fonte'     => 'ultimo_resultado_do_modulo',
				)
			);
		}
		return $r;
	}

	private static function resultado_seguro( array $r ): array {
		$saida = array();
        $error=$r['erro_detalhes']??$r['entrega']['erro_detalhes']??(is_array($r['erro']??null)?$r['erro']:null);if(is_array($error)){$saida['erro']=array_intersect_key($error,array_flip(array('codigo_interno','etapa','classe','mensagem','arquivo','linha')));}
		foreach ( array( 'processados', 'restantes', 'saldo', 'expirados', 'arquivados', 'eliminados', 'falhas_confirmacao', 'limpezas_pendentes' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_numeric( $r[ $k ] ) ) {
				$saida[ $k ] = max( 0, (int) $r[ $k ] ); }
		}
		foreach ( array( 'ok', 'parcial', 'reagendado', 'persisted', 'local_confirmado', 'incompleto' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_bool( $r[ $k ] ) ) {
				$saida[ $k ] = $r[ $k ]; }
		}
		if ( isset( $r['codigo'] ) && is_string( $r['codigo'] ) ) {
			$saida['codigo'] = substr( sanitize_key( $r['codigo'] ), 0, 64 ); }
		if ( isset( $r['agenda']['saldo'] ) ) {
			$saida['saldo'] = max( 0, (int) $r['agenda']['saldo'] ); }
		return $saida;
	}

}
