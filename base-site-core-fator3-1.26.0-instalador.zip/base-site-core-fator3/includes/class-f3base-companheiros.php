<?php
/** Matriz explícita. Diagnóstico local não inicializa o canal nem concede permissões. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Companheiros {
    const MCP_MINIMA='0.16.0';const GOOGLE_MINIMA='0.7.1';const MCP_CONTRATO='server-integration/1.0.0';
    public static function atende($v,string $minima): bool {return is_string($v)&&preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/D',$v)===1&&version_compare($v,$minima,'>=');}
    public static function mcp(): array {
        $r=array('requerida'=>self::MCP_MINIMA,'regra'=>'minima','versoes_com_sufixo'=>'recusadas; somente X.Y.Z estável','observada'=>defined('F3_MCP_FILES_VERSION')?F3_MCP_FILES_VERSION:null,'compativel'=>false,'codigo'=>'mcp_ausente');
        if(!$r['observada']){return $r;}if(!self::atende($r['observada'],self::MCP_MINIMA)){$r['codigo']='versao_mcp_incompativel';return $r;}
        try {if(!is_callable(array('Fator3\\McpFiles\\ServerContract','capabilities'))){$r['codigo']='contrato_mcp_indisponivel';return $r;}$c=\Fator3\McpFiles\ServerContract::capabilities();$r['compativel']=($c['contract']??'')===self::MCP_CONTRATO&&($c['policy_contract']??null)===1&&self::atende($c['version']??null,self::MCP_MINIMA);$r['codigo']=$r['compativel']?'compativel':'contrato_mcp_incompativel';}catch(Throwable $e){$r['codigo']='contrato_mcp_indisponivel';}return $r;
    }
    public static function google(): array {$v=defined('F3_MCP_GOOGLE_VERSION')?F3_MCP_GOOGLE_VERSION:null;$ok=self::atende($v,self::GOOGLE_MINIMA);$sdk=F3Base_Gsc::registro();return array('requerida'=>self::GOOGLE_MINIMA,'regra'=>'minima','versoes_com_sufixo'=>'recusadas; somente X.Y.Z estável','observada'=>$v,'compativel'=>$ok&&$sdk==='registrado','codigo'=>$v===null?'google_ausente':(!$ok?'versao_google_incompativel':($sdk==='registrado'?'compativel':$sdk)));}
}
