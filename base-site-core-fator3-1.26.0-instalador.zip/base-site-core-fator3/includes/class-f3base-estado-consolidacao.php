<?php
/** Retire exact release markers only after the current installation has committed. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Estado_Consolidacao {
    const RETIRADOS=array('f3base_release_1120','f3base_1120_trava','f3base_reparo_1120','f3base_migracao_1110','f3base_release_1130','f3base_release_1140','f3base_release_1150','f3base_release_1160','f3base_release_1170','f3base_release_1180','f3base_release_1190','f3base_release_1200','f3base_release_1210','f3base_release_1220','f3base_release_1221','f3base_release_1230','f3base_release_1240','f3base_1130_trava','f3base_1190_trava','f3base_agenda_1200','f3base_agenda_1210');
    public static function concluir(): bool {
        $s=get_option(F3Base_Instalacao::OPTION,array());if(empty($s['concluido_em'])||empty($s['confirmada_no_executor_em'])){return false;}if(!empty($s['consolidacao']['concluido_em'])){return true;}
        if(!F3Base_Recuperacao::entrar()){return false;}
        try{
            $receipt=$s['consolidacao']??array();$receipt['versao']='1.26.0';$receipt['marcos']=$receipt['marcos']??array();$previous=get_option('f3base_release_1250',array());$initial=$s['coleta_adicional_desde']??$previous['coleta_adicional_desde']??$previous['concluido_em']??null;
            foreach(self::RETIRADOS as $n){$f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return false;}if(!$f['existe']){continue;}$v=$f['valor'];
                if($n==='f3base_release_1140'&&is_array($v)&&!empty($v['concluido_em'])){$initial=$v['concluido_em'];}
                $meta=is_array($v)?array_intersect_key($v,array_flip(array('versao','origem','iniciado_em','concluido_em','transferencia_intencoes'))):array();
                $receipt['marcos'][$n]=$meta+array('sha256'=>hash('sha256',maybe_serialize($v)),'revisao'=>$f['revisao']);
                if(is_array($v)&&empty($v['concluido_em'])&&(!empty($v['iniciado_em'])||in_array($n,array('f3base_release_1120','f3base_reparo_1120','f3base_migracao_1110'),true))){$receipt['marcos'][$n]['preservado']='progresso_incompleto';}
            }
            $save=F3Base_Options::atualizar_estado(F3Base_Instalacao::OPTION,static function($v)use($receipt,$initial){$v['consolidacao']=$receipt;$v['coleta_adicional_desde']=$initial??$v['concluido_em'];return $v;});if(empty($save['persisted'])){return false;}
            foreach($receipt['marcos'] as $n=>$m){if(!in_array($n,self::RETIRADOS,true)||!empty($m['preservado'])){continue;}$f=F3Base_Options::fotografia_bruta($n);if($f['erro']){return false;}if(!$f['existe']){continue;}if(!hash_equals($m['revisao'],$f['revisao'])||!F3Base_Options::remover($n)){return false;}}
            return !empty(F3Base_Options::atualizar_estado(F3Base_Instalacao::OPTION,static function($v){$v['consolidacao']['concluido_em']=time();return $v;})['persisted']);
        }finally{F3Base_Recuperacao::sair();}
    }
}
