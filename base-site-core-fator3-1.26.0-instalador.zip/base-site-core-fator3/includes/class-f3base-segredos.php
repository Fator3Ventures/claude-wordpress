<?php
/** Segredos de terceiros cifrados no banco, vinculados ao site e ao nome da opção. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Segredos {
    const PREFIXO='f3sec:v1:';
    const NOMES=array('f3base_avisos_webhook_url','f3base_avisos_webhook_chave','f3base_slack_webhook','f3base_clarity_api_token','f3base_meta_capi_token','f3base_pipedrive_token','f3base_anuncios_meta_token','f3base_anuncios_google_chave','f3base_anuncios_linkedin_token');
    public static function recusar(string $nome,$v): string {if(!is_string($v)){return 'Informe uma credencial textual.';}$v=trim($v);if(strlen($v)>8192||preg_match('/[\x00-\x1f\x7f]/',$v)){return 'Credencial inválida: remova controles e confira o valor.';}if($nome==='f3base_avisos_webhook_url'){return $v===''||F3Base_Avisos::webhook_url_valida($v)?'':'Use URL HTTPS pública, sem credenciais, porta, query ou fragmento.';}if($nome==='f3base_avisos_webhook_chave'&&$v!==''&&!preg_match('/^[A-Za-z0-9_-]{32,256}$/D',$v)){return 'Use chave aleatória de 32 a 256 caracteres: letras, números, hífen ou sublinhado.';}if($nome==='f3base_slack_webhook'){return $v===''||F3Base_Avisos::url_valida($v)?'':'Use a URL HTTPS exata de Incoming Webhook do Slack, sem porta, credenciais, query ou fragmento.';}if(self::gerenciado($nome)&&$v!==''&&(preg_match('/\s/u',$v)||preg_match('~^(?:https?://|(?:Bearer|Basic)[ :]|x-api-token:|api[_-]?token[:=])~i',$v))){return 'Cole somente a credencial, sem espaços internos, URL ou prefixo de cabeçalho. Depois verifique o acesso à conta.';}return '';}
    public static function motivo_seguro(string $nome,$valor): array {$m=self::recusar($nome,$valor);return array('codigo'=>$m===''?'formato_local_aceito':(!is_string($valor)?'credencial_tipo_invalido':(strlen($valor)>8192?'credencial_tamanho_excedido':(preg_match('/[\x00-\x1f\x7f]/',$valor)?'credencial_controles':'credencial_conteudo_invalido'))),'motivo'=>$m);}
    public static function gerenciado(string $nome): bool{return in_array($nome,self::NOMES,true);}
    public static function chave(string $nome): string {return hash_hkdf('sha256',wp_salt('secure_auth'),32,'f3base:segredos:v1:'.$nome,'f3base-secretbox');}
    public static function cifrar(string $nome,string $valor): string {
        if($valor===''){return '';}
        if(!self::gerenciado($nome)||!function_exists('sodium_crypto_secretbox')){throw new RuntimeException('cifra_indisponivel');}
        $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        return self::PREFIXO.base64_encode($nonce.sodium_crypto_secretbox($valor,$nonce,self::chave($nome)));
    }
    public static function abrir(string $nome,?string $cipher=null): string {
        if($cipher===null){$proposta=F3Base_Options::segredo_proposto($nome);if($proposta!==null){return $proposta;}}
        $cipher=$cipher??get_option($nome,'');if(!is_string($cipher)||$cipher===''||!self::gerenciado($nome)||!str_starts_with($cipher,self::PREFIXO)||!function_exists('sodium_crypto_secretbox_open')){return '';}
        $v=base64_decode(substr($cipher,strlen(self::PREFIXO)),true);
        if($v===false||strlen($v)<SODIUM_CRYPTO_SECRETBOX_NONCEBYTES+SODIUM_CRYPTO_SECRETBOX_MACBYTES){return '';}
        try{$p=sodium_crypto_secretbox_open(substr($v,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($v,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),self::chave($nome));return is_string($p)?$p:'';}catch(Throwable $e){return '';}
    }
    public static function status(string $nome): array {
        $v=get_option($nome,'');$present=is_string($v)&&$v!=='';
        return array('presente'=>$present,'versao'=>$present&&str_starts_with($v,self::PREFIXO)?1:null,'estado'=>!$present?'ausente':(self::abrir($nome)!==''?'disponivel':'recadastrar'));
    }
    public static function migrar(): array {
        $out=array();foreach(self::NOMES as $nome){$f=F3Base_Options::fotografia_bruta($nome);if($f['erro']){$out[$nome]='leitura_falhou';continue;}$v=$f['valor'];
            if(!$f['existe']||$v===''||(is_string($v)&&str_starts_with($v,self::PREFIXO))){$out[$nome]=self::status($nome)['estado'];continue;}
            if(!is_string($v)||!function_exists('sodium_crypto_secretbox')){$out[$nome]='recadastrar';continue;}
            $r=F3Base_Options::gravar($nome,$v,F3Base_Options::ORIGEM_MIGRACAO,$f['revisao']);
            $out[$nome]=!empty($r['persisted'])&&hash_equals($v,self::abrir($nome))?'migrado':'recadastrar';
        }return $out;
    }
}
