<?php
/** Transporte limitado a destinos HTTP públicos; cada redirecionamento é revalidado. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Http_Publico {
	public static function buscar( string $url, int $limite = 2097152, float $fim = 0, string $metodo = 'GET', array $headers = array(), bool $seguir = true, bool $prefixo = false ): array {
		$inicio   = microtime( true );
		$original = $url;
		$cadeia   = array();
        $falha=static function(string $codigo,int $status=0)use(&$url,&$cadeia,$original,$inicio):array{return array('ok'=>false,'codigo'=>$codigo,'status'=>$status,'url_inicial'=>$original,'http_inicial'=>$cadeia[0]['status']??0,'url_final'=>$url,'cadeia'=>$cadeia,'redirecionou'=>$url!==$original,'duracao_ms'=>round((microtime(true)-$inicio)*1000,1));};
		$fim      = $fim ? $fim : $inicio + 10;
		for ( $salto = 0; $salto <= 3; ++$salto ) {
			if(!F3Base_Testes::origem_propria($url)){unset($headers['X-F3Base-Teste']);}
			$p    = wp_parse_url( $url );
			$host = (string) ( $p['host'] ?? '' );
			if ( ! in_array( $p['scheme'] ?? '', array( 'http', 'https' ), true ) || isset( $p['user'] ) || isset( $p['pass'] ) || ! wp_http_validate_url( $url ) || ( strtolower( $host ) !== strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) && ! self::host_publico( $host ) ) ) {
				return $falha('destino_nao_publico',0); }
			$restante = $fim - microtime( true );
			if ( $restante <= 0 ) {
				return $falha('orcamento_esgotado',0); }
			$r = wp_safe_remote_request(
				$url,
				array(
					'method'              => 'HEAD' === $metodo ? 'HEAD' : 'GET',
					'timeout'             => min( 10, $restante ),
					'redirection'         => 0,
					'limit_response_size' => $limite + 1,
					'cookies'             => array(),
					'headers'             => array( 'Accept' => '*/*' ) + array_intersect_key( $headers, array_flip( array( 'If-None-Match', 'If-Modified-Since', 'Accept-Encoding', 'X-F3Base-Teste' ) ) ),
					'reject_unsafe_urls'  => true,
				)
			);
			if ( is_wp_error( $r ) ) {
				return $falha('http_indisponivel',0); }
			$status   = wp_remote_retrieve_response_code( $r );
			$cadeia[] = array(
				'url'    => $url,
				'status' => $status,
			);
			if ( $seguir && in_array( $status, array( 301, 302, 303, 307, 308 ), true ) ) {
				$destino = wp_remote_retrieve_header( $r, 'location' );
				if ( ! $destino || 3 === $salto ) {
					return $falha('redirecionamento_limite',$status); }
				$url = WP_Http::make_absolute_url( $destino, $url );
				continue;
			}
			$corpo = wp_remote_retrieve_body( $r );
			if ( strlen( $corpo ) > $limite ) {
				return $prefixo?($falha('resposta_truncada',$status)+array('corpo'=>substr($corpo,0,$limite),'corpo_completo'=>false,'bytes_lidos'=>$limite)): $falha('resposta_truncada',$status); }
			$cabecalhos = array();
			foreach ( array( 'content-type', 'cache-control', 'x-robots-tag', 'etag', 'last-modified', 'location', 'x-redirect-by', 'content-encoding', 'expires' ) as $h ) {
				$cabecalhos[ $h ] = (string) wp_remote_retrieve_header( $r, $h ); }
			return array(
				'ok'           => 200 === $status,
				'codigo'       => 200 === $status ? 'http_200' : 'http_status',
				'status'       => $status,
				'url_final'    => $url,
				'cadeia'       => $cadeia,
				'redirecionou' => $url !== $original,
				'corpo'        => $corpo,
				'cabecalhos'   => $cabecalhos,
				'duracao_ms'   => round( ( microtime( true ) - $inicio ) * 1000, 1 ),
			);
		}
		return $falha('http_indisponivel',0);
	}
	private static function host_publico( string $host ): bool {
		$host = trim( $host, '[]' );
		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			$ips = array( $host ); } else {
			$v4  = gethostbynamel( $host );
			$v6  = @dns_get_record( $host, DNS_AAAA ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de resolução produz destino recusado, sem expor aviso ao cliente.
			$ips = array_merge( is_array( $v4 ) ? $v4 : array(), array_column( is_array( $v6 ) ? $v6 : array(), 'ipv6' ) );
			}
			if ( ! $ips ) {
				return false; }
			foreach ( $ips as $ip ) {
				if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) || str_starts_with( strtolower( $ip ), '::ffff:' ) ) {
					return false; }
			}
			return true;
	}
}
