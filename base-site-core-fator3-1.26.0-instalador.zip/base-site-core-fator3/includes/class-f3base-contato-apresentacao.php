<?php
/** Projeção comum; somente dados locais. Entradas públicas impõem suas próprias permissões. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Contato_Apresentacao {
    const VERSAO=3;
    const ROTULO_REGISTRO='Consultar contato no WordPress';
    public static function link_permitido(string $secao,string $rotulo): bool {return $secao==='Acontecimento'&&in_array($rotulo,array('Página','Destino'),true);}
    public static function linha_aparelho(array $ap): string {return implode(' · ',array_filter(array(self::rotulo_aparelho((string)($ap['tipo']??'')),$ap['sistema']??'',$ap['navegador']??'')));}
    public static function aparelho(string $ua,array $h=array(),bool $nativo=false): array {
        $r=array('tipo'=>'nao_identificado','fonte'=>$h?'user_agent_client_hints':'user_agent','versao'=>self::VERSAO,'familia'=>F3Base_Audiencia::navegador($ua),'motivo'=>'sinais_insuficientes','sistema'=>'','navegador'=>'');
        if($nativo){$r['fonte']='origem_nativa';$r['motivo']='conector_nao_representa_visitante';return $r;}
        if(preg_match('/bot|crawler|spider|curl|python|headless|postman/i',$ua)){$r['motivo']='agente_automatizado';return $r;}
        $tablet=preg_match('/iPad|Tablet|Silk|Kindle/i',$ua)||(stripos($ua,'Android')!==false&&!preg_match('/Mobile/i',$ua));$mobile=preg_match('/iPhone|iPod|Android.*Mobile|Windows Phone/i',$ua);$desktop=preg_match('/Windows NT|Macintosh|X11.*Linux|CrOS/i',$ua);
        $r['tipo']=$tablet?'tablet':($mobile?'celular':($desktop?'computador':'nao_identificado'));
        if(isset($h['mobile'])&&in_array($h['mobile'],array('?0','?1'),true)&&(($h['mobile']==='?1'&&in_array($r['tipo'],array('computador','tablet'),true))||($h['mobile']==='?0'&&$r['tipo']==='celular'))){$r['tipo']='nao_identificado';$r['motivo']='sinais_conflitantes';}elseif($r['tipo']!=='nao_identificado'){$r['motivo']='declaracao_do_cliente';}
        foreach(array('Android'=>'Android','iPhone|iPad|iPod'=>'iOS/iPadOS','Windows NT'=>'Windows','Macintosh'=>'macOS','CrOS'=>'ChromeOS','Linux'=>'Linux') as $p=>$v){if(preg_match('/'.$p.'/i',$ua)){$r['sistema']=$v;break;}}
        foreach(array('Edg/'=>'Edge','OPR/'=>'Opera','Firefox/'=>'Firefox','Chrome/|CriOS/'=>'Chrome','Safari/'=>'Safari') as $p=>$v){if(preg_match('~'.$p.'~i',$ua)){$r['navegador']=$v;break;}}
        if(str_contains($ua,'Macintosh')&&($h['max_touch_points']??0)>1){$r['tipo']='tablet';$r['sistema']='iPadOS (inferido)';$r['motivo']='inferido_mac_com_toque';$r['fonte']='user_agent_e_toque';}elseif(str_contains($ua,'Macintosh')&&!is_numeric($h['max_touch_points']??null)){$r['limite']='User agent compatível com Mac; iPad em modo desktop não pode ser distinguido sem sinais complementares.';}return $r;
    }
    public static function url(string $url): string {
        $p=wp_parse_url($url);if(!is_array($p)||isset($p['user'])||isset($p['pass'])){return '';}$scheme=strtolower($p['scheme']??'');$path=$p['path']??'';
        if($scheme==='tel'){return preg_match('/^\+?[0-9 ().-]{3,30}$/D',$path)?'tel:'.$path:'';}
        if($scheme==='mailto'){return is_email($path)?'mailto:'.$path:'';}
        if(!in_array($scheme,array('','http','https'),true)){return '';}
        if(preg_match('~/f3base/(?:arquivo|download)|f3base-privad~i',$path)){return '[arquivo privado]';}
        $host=strtolower($p['host']??'');$out=($host?($scheme?:'https').'://'.$host.(isset($p['port'])?':'.$p['port']:''):'').$path;
        if(in_array($host,array('api.whatsapp.com','web.whatsapp.com'),true)){parse_str($p['query']??'',$q);if(is_string($q['phone']??null)&&preg_match('/^\+?[0-9]{8,15}$/D',$q['phone'])){$out.='?phone='.rawurlencode($q['phone']);}}
        return $out;
    }
    private static function caminho_canonico(string $url): string {
        static $cache=array();if(isset($cache[$url])){return $cache[$url];}$p=wp_parse_url($url);$home=wp_parse_url(home_url('/'));if(!$p||(!empty($p['host'])&&strtolower($p['host'])!==strtolower($home['host']))){return $cache[$url]=$url;}
        $path=$p['path']??'/';$id=url_to_postid(home_url($path));return $cache[$url]=$id?(string)wp_parse_url(get_permalink($id),PHP_URL_PATH):($path==='/'?'/':untrailingslashit($path));
    }
    public static function rotulo(string $v): string {
        return array('captura_sem_referencia'=>'Captura sem referência granular; histórico restrito','referencia_perdida_historico_permitido'=>'Referência de consentimento não localizada; histórico exibido conforme configuração do dono, preservando a decisão registrada na captura','referencia_perdida_historico_restrito'=>'Referência de consentimento não localizada; histórico restrito pela configuração','decisao_leitura_falhou'=>'Não foi possível conferir a decisão de consentimento','historico_registrado'=>'Decisão histórica registrada','decisao_revogada'=>'Consentimento revogado','referencia_invalida_ou_conflitante'=>'Referência histórica inválida ou conflitante','medicao_nao_permitida_ou_revogada'=>'Medição não autorizada ou revogada','atribuicao_publicitaria_reduzida'=>'Detalhes publicitários reduzidos pela autorização','formulario_nativo_sem_jornada_web'=>'Formulário recebido diretamente da plataforma, sem navegação web associada','sessao_indisponivel'=>'Identificador de sessão ausente','sem_eventos_retidos'=>'Nenhum evento disponível dentro da retenção','observado'=>'Jornada observada','jornada_nao_solicitada'=>'Jornada não solicitada','plataforma'=>'Plataforma','utm_source'=>'Origem','utm_medium'=>'Mídia','utm_campaign'=>'Campanha','utm_term'=>'Termo','canal'=>'Canal','referrer'=>'Referência','entrada'=>'Página de entrada','primeiro_toque'=>'Primeiro toque','ultimo_toque'=>'Último toque','sessao_origem'=>'Origem da sessão','campanha_id'=>'ID da campanha','anuncio_id'=>'ID do anúncio','conta_id'=>'ID da conta','grupo_id'=>'ID do grupo','f3_ads_ad_name'=>'Nome do anúncio','utm_id'=>'ID UTM','utm_content'=>'Conteúdo do anúncio','modelo'=>'Modelo de atribuição','cobertura'=>'Cobertura','ip'=>'IP','ip_fonte'=>'Fonte do IP','user_agent'=>'User agent','post_id'=>'ID do conteúdo','sessao'=>'Sessão','faixa_janela'=>'Faixa da janela (histórico)','largura_janela'=>'Largura da janela (px)','teste_origem'=>'Origem da marca de teste')[$v]??F3Base_Relatorios::rotulo($v);
    }
    public static function consentimento_atual(array $d): array {
        $p=$d['consentimento_snapshot']??array();$ref=$p['decisao_ref']??$p['ref']??'';$v=$p['politica_versao']??'';$med=!empty($p['medicao']);$ads=!empty($p['publicidade']);
        if(str_starts_with($v,'legado:')){$ok=F3Base_Consentimento_Decisoes::permite_capi('',(string)$v);$med=$med&&$ok;$ads=$ads&&$ok;}elseif($ref){$med=$med&&F3Base_Consentimento_Decisoes::permite($ref,$v,'medicao');$ads=$ads&&F3Base_Consentimento_Decisoes::permite($ref,$v,'publicidade');}else{$med=false;$ads=false;}
        return array('medicao'=>$med,'publicidade'=>$ads);
    }
    public static function consentimento(array $d): array {
        $p=is_array($d['consentimento_snapshot']??null)?$d['consentimento_snapshot']:array();$ref=F3Base_Leads_Consentimento::referencia($d);$med=!empty($p['medicao']);$ads=!empty($p['publicidade']);$codigo='historico_registrado';
        if(!empty($p['revogada'])){$med=$ads=false;$codigo='decisao_revogada';}
        if($ref){global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT medicao,publicidade,revogada FROM %i WHERE ref=%s',$wpdb->prefix.F3Base_Consentimento_Decisoes::TABELA,$ref),ARRAY_A);
            if($wpdb->last_error){$med=$ads=false;$codigo='decisao_leitura_falhou';}
            elseif($row){$med=$med&&empty($row['revogada'])&&!empty($row['medicao']);$ads=$ads&&empty($row['revogada'])&&!empty($row['publicidade']);$codigo=!empty($row['revogada'])?'decisao_revogada':'historico_registrado';}
            else{$permit=(F3Base_Options::ler('f3base_contato')['historico_sem_decisao']??'permitir')==='permitir';$med=$med&&$permit;$ads=$ads&&$permit;$codigo=$permit?'referencia_perdida_historico_permitido':'referencia_perdida_historico_restrito';}
        }elseif(!str_starts_with((string)($p['politica_versao']??''),'legado:')){$med=$ads=false;$codigo='captura_sem_referencia';}elseif(!empty($p['ref'])||!empty($p['decisao_ref'])){$med=$ads=false;$codigo='referencia_invalida_ou_conflitante';}
        return array('medicao'=>$med,'publicidade'=>$ads,'codigo'=>$codigo);
    }
    public static function atribuicao(array $a,bool $ads): array {
        $allowed=array('plataforma','utm_source','utm_medium','utm_campaign','utm_term','canal','referrer','entrada','primeiro_toque','ultimo_toque','sessao_origem','campanha_id','anuncio_id','conta_id','grupo_id','f3_ads_ad_name','utm_id','utm_content','modelo','cobertura');$r=array_intersect_key($a,array_flip($allowed));
        if(!$ads){foreach(array('campanha_id','anuncio_id','conta_id','grupo_id','f3_ads_ad_name','utm_id','utm_content') as $k){unset($r[$k]);}}
        foreach($r as $k=>&$v){if(is_array($v)){$v=self::atribuicao($v,$ads);foreach(array('modelo','cobertura') as $meta){if(isset($a[$meta])&&($v[$meta]??null)===$a[$meta]){unset($v[$meta]);}}}elseif(is_string($v)&&preg_match('~^(?:https?://|/)~',$v)){$v=self::url($v);}elseif(!is_scalar($v)){unset($r[$k]);}}unset($v);return $r;
    }
    public static function jornada(array $r): array {
        $out=array('ok'=>true,'record_id'=>$r['record_id'],'eventos'=>array(),'paginas'=>array(),'duracao_observada_segundos'=>null,'corte'=>false,'aviso'=>'Somente observações anteriores à captura. Retenção, consentimento e múltiplas abas limitam a reconstrução.');
        if(!empty($r['dados']['audiencia_excluida'])){$out['codigo']='audiencia_excluida';return $out;}
        if(!empty($r['dados']['origem_nativa'])){$out['codigo']='formulario_nativo_sem_jornada_web';return $out;}
        if(!self::consentimento($r['dados'])['medicao']){$out['codigo']='medicao_nao_permitida_ou_revogada';return $out;}
        if(empty($r['sessao'])){$out['codigo']='sessao_indisponivel';return $out;}
        global $wpdb;$end=strtotime($r['criado_em'].' UTC');$from=max($end-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS,time()-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS);$params=array($r['sessao'],$r['classe_trafego'],$from,$end);
        $a=$wpdb->get_results($wpdb->prepare('SELECT id,criado_em,recebido_em,caminho,metrica,detalhe,valor,ocorrencia,ms,ancora,navegacao FROM %i WHERE sessao=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d ORDER BY criado_em DESC,id DESC LIMIT 501',array_merge(array($wpdb->prefix.F3Base_Modulo_Comportamento::TABELA_EVENTOS),$params)),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'leitura_comportamento_falhou');}
        $b=$wpdb->get_results($wpdb->prepare('SELECT evento AS id,criado_em,recebido_em,caminho,tipo AS metrica,detalhe,valor,qualidade AS ancora,navegacao FROM %i WHERE sessao=%s AND classe_trafego=%s AND criado_em BETWEEN %d AND %d ORDER BY criado_em DESC,evento DESC LIMIT 501',array_merge(array(F3Base_Analise::tabela()),$params)),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'leitura_analise_falhou');}
        foreach($a as &$e){$e['fonte']='comportamento';}unset($e);foreach($b as &$e){$e['fonte']='analise';}unset($e);
        $clicks=$wpdb->get_results($wpdb->prepare("SELECT record_id,criado_em,pagina,metodo,dados FROM %i WHERE sessao=%s AND classe_trafego=%s AND captura='clique' AND lixeira=0 AND eliminacao_pendente=0 AND criado_em BETWEEN %s AND %s ORDER BY criado_em DESC,id DESC LIMIT 101",F3Base_Leads_Repositorio::tabela(),$r['sessao'],$r['classe_trafego'],gmdate('Y-m-d H:i:s',$from),$r['criado_em']),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'leitura_cliques_falhou');}foreach($clicks as $x){$d=json_decode($x['dados'],true)?:array();$b[]=array('id'=>$x['record_id'],'fonte'=>'clique','criado_em'=>strtotime($x['criado_em'].' UTC'),'caminho'=>self::url($x['pagina']),'metrica'=>$x['metodo'],'detalhe'=>self::url($d['destino']??''),'valor'=>null,'ancora'=>'recebimento','navegacao'=>$d['navegacao']??'');}
        $rows=array_merge($a,$b);usort($rows,static fn($x,$y)=>[(int)$x['criado_em'],(int)($x['ms']??0)%1000,$x['fonte'],(string)$x['id']]<=>[(int)$y['criado_em'],(int)($y['ms']??0)%1000,$y['fonte'],(string)$y['id']]);$out['recebidos_apos_captura']=count(array_filter($rows,static fn($e)=>(int)($e['recebido_em']??0)>$end));$out['recebimento_desconhecido']=count(array_filter($rows,static fn($e)=>(int)($e['recebido_em']??0)===0));$out['corte']=count($rows)>500||count($clicks)>100;$rows=array_slice($rows,-500);$groups=array();$seen=array();
        $section=F3Base_Modulo_Comportamento::evento_do_gatilho('interseccao');$active=F3Base_Modulo_Comportamento::evento_do_gatilho('tempo-ativo');$scroll=F3Base_Modulo_Comportamento::evento_do_gatilho('rolagem');
        foreach($rows as $e){$key=$e['fonte'].':'.$e['id'];if(isset($seen[$key])){continue;}$seen[$key]=true;$e['recebido_apos_captura']=isset($e['recebido_em'])&&(int)$e['recebido_em']>0?(int)$e['recebido_em']>$end:null;$out['eventos'][]=$e;$nav=$e['navegacao']??'';$path=self::caminho_canonico(self::url($e['caminho']));$g=$nav!==''?$nav.'|'.$path:'sem-vinculo:'.$key;
            if(!isset($groups[$g])){$groups[$g]=array('pagina'=>$path,'navegacao'=>$nav,'primeiro_em'=>(int)$e['criado_em'],'ultimo_em'=>(int)$e['criado_em'],'tempo_ativo_ms'=>null,'rolagem_maxima'=>null,'secoes'=>array(),'cliques'=>array(),'eventos'=>0,'vinculo'=>$nav?'carregamento':'evento_sem_navegacao');}
            $p=&$groups[$g];$p['ultimo_em']=max($p['ultimo_em'],(int)$e['criado_em']);$p['eventos']++;
            if($e['metrica']===$active&&is_numeric($e['valor'])&&$e['valor']>0&&$e['valor']<=30000){$p['tempo_ativo_ms']=($p['tempo_ativo_ms']??0)+(float)$e['valor'];}
            if($e['metrica']===$scroll&&is_numeric($e['valor'])){$p['rolagem_maxima']=max($p['rolagem_maxima']??0,(float)$e['valor']);}
            if(($e['metrica']===$section||str_contains($e['metrica'],'secao'))&&$e['detalhe']!==''){$p['secoes'][]=$e['detalhe'];}if($e['fonte']==='clique'||in_array($e['metrica'],array('f3base_link_externo','f3base_clique','clique','click','cta_click','f3base_whatsapp_clique'),true)){$p['cliques'][]=$e['detalhe'];}unset($p);
        }
        foreach($groups as &$p){$p['intervalo_observado_segundos']=$p['eventos']>1?$p['ultimo_em']-$p['primeiro_em']:null;$p['secoes']=array_values(array_unique($p['secoes']));}unset($p);$out['simultaneidade_observada']=false;$values=array_values($groups);foreach($values as $i=>$x){foreach(array_slice($values,$i+1) as $y){if($x['navegacao']&&$y['navegacao']&&$x['navegacao']!==$y['navegacao']&&min($x['ultimo_em'],$y['ultimo_em'])>max($x['primeiro_em'],$y['primeiro_em'])){$out['simultaneidade_observada']=true;}}}$out['paginas']=$values;$out['paginas_distintas']=count(array_unique(array_column($values,'pagina')));$out['limites']=array('eventos'=>500,'cliques'=>100);$out['cobertura']=array('eventos_retidos'=>count($rows),'cliques_retidos'=>min(100,count($clicks)),'retencao_dias'=>F3Base_Modulo_Comportamento::retencao_eventos_dias());$times=array_column($rows,'criado_em');$out['duracao_observada_segundos']=count($times)>1?max($times)-min($times):null;$out['numero_carregamentos_vinculados']=count(array_unique(array_filter(array_column($groups,'navegacao'))));$out['codigo']=$rows?'observado':'sem_eventos_retidos';return $out;
    }
    public static function montar(array $r,bool $com_jornada=true): array {
        $d=$r['dados'];$permit=self::consentimento($d);$a=array('versao'=>self::VERSAO,'montado_em'=>time(),'corte_em'=>strtotime($r['criado_em'].' UTC'),'record_id'=>$r['record_id'],'site'=>$d['snapshot']['site_host']??strtolower((string)wp_parse_url(home_url(),PHP_URL_HOST)),'nome'=>$r['nome'],'email'=>$r['email'],'telefone'=>$d['telefone']??'','empresa'=>$d['empresa']??'','cargo'=>$d['cargo']??'','linkedin'=>$d['linkedin']??'','servicos'=>$d['servicos']??array(),'formulario_id'=>$r['formulario'],'formulario'=>$d['formulario_titulo']??$r['formulario'],'metodo'=>$r['metodo'],'capturado_em'=>$r['criado_em'],'pagina'=>self::url($r['pagina']),'pagina_titulo'=>$d['snapshot']['pagina_titulo']??'','destino'=>self::url($d['destino']??''),'campos'=>$r['captura']==='clique'?array():($d['campos']??array()),'respostas'=>array(),'atribuicao'=>($permit['medicao']||!empty($d['origem_nativa']))?self::atribuicao($d['atribuicao']??array(),$permit['publicidade']||!empty($d['origem_nativa'])):array(),'qualidade'=>array(),'aparelho'=>$d['contexto']['aparelho']??self::aparelho($d['contexto']['user_agent']??'',array(),!empty($d['origem_nativa'])),'tecnicos'=>array_intersect_key($d['contexto']??array(),array_flip(array('ip','ip_fonte','user_agent','post_id'))),'teste'=>$r['classe_trafego']==='teste','teste_origem'=>$d['teste_origem']??'desconhecida','registro_url'=>admin_url('admin.php?page=f3base-leads&record_id='.$r['record_id']));
        if((int)($a['aparelho']['versao']??0)<self::VERSAO){$a['aparelho']=self::aparelho($d['contexto']['user_agent']??'',$d['contexto']['client_hints']??array(),!empty($d['origem_nativa']));}
        if(is_numeric($d['contexto']['client_hints']['max_touch_points']??null)){unset($a['aparelho']['limite']);}
        $a['tecnicos']['sessao']=$r['sessao']??'';$a['tecnicos']['largura_janela']=$d['contexto']['largura_janela']??'';$a['tecnicos']['faixa_janela']=$d['dispositivo']??'';if($a['teste']){$a['tecnicos']['teste_origem']=$a['teste_origem'];}$a['consentimento_captura']=$d['consentimento_snapshot']??array();$a['consentimento_atual']=self::consentimento_atual($d);$a['consentimento_historico']=$permit;
        $snap=array();foreach($d['campos_snapshot']??array() as $f){$snap[$f['nome']]=$f;}foreach($a['campos'] as $k=>$v){$f=$snap[$k]??array();if(($f['tipo']??'')==='file'){unset($a['campos'][$k]);continue;}if($v===''||$v===null||$v===array()){continue;}$role=$f['papel']??'';if($role===''){foreach(array('nome','email','telefone','empresa','cargo','linkedin') as $candidate){if(preg_match('/(?:^|[-_])'.preg_quote($candidate,'/').'$/iu',$k)&&is_scalar($v)&&(string)$v===(string)($a[$candidate]??'')){$role=$candidate;break;}}}if(in_array($role,array('nome','email','telefone','empresa','cargo','linkedin'),true)&&isset($a[$role])&&(string)$a[$role]===(is_scalar($v)?(string)$v:'')){continue;}$label=$f['rotulo']??$k.' (rótulo histórico indisponível)';$options=$f['opcoes']??array();$values=is_array($v)?$v:array($v);$print=array();foreach($values as $item){if(is_bool($item)){$print[]=$item?'Sim':'Não';}elseif(is_scalar($item)){$mapped=null;foreach($options as $o){if(is_array($o)&&($o['valor']??'')===(string)$item){$mapped=$o['rotulo']??null;break;}}$print[]=$mapped??(string)$item;}}$a['respostas'][$label]=$print;}
        $a['qualidade'][]=$permit['codigo'];$a['jornada']=$com_jornada?self::jornada($r):array('ok'=>false,'codigo'=>'jornada_nao_solicitada','eventos'=>array(),'paginas'=>array());$a['journey']=$a['jornada']['eventos']??array();$a['journey_corte']=$a['jornada']['corte']??false;$a['qualidade'][]=$a['jornada']['codigo']??'jornada_indisponivel';if(!$permit['medicao']){$a['qualidade'][]='medicao_nao_permitida_ou_revogada';}if(!$permit['publicidade']){$a['qualidade'][]='atribuicao_publicitaria_reduzida';}if(!empty($d['origem_nativa'])){$a['origem_nativa']=$d['origem_nativa'];}return $a;
    }
    public static function html_contato(array $a): void {
        echo '<p><strong>'.esc_html($a['site']).'</strong></p>';
        foreach(self::secoes($a) as $section=>$items){
            if($section==='Dados técnicos'){echo '<details><summary>Dados técnicos</summary>';}
            else{echo '<h3>'.esc_html($section).'</h3>';}
            
            echo '<dl>';foreach($items as $label=>$values){echo '<dt><strong>'.esc_html($label).'</strong></dt><dd style="white-space:pre-wrap">'.esc_html(implode("\n",(array)$values)).'</dd>';}echo '</dl>';
            if($section==='Comportamento no site'&&!empty($a['jornada']['eventos'])){echo '<details><summary>Eventos e detalhes técnicos</summary>';F3Base_Relatorios::tabela($a['jornada']['eventos']);echo '</details>';}
            if($section==='Dados técnicos'){echo '</details>';}
        }
    }
    public static function secoes(array $a,?array $incluir=null): array {
        $sections=array('Contato'=>array(),'Acontecimento'=>array(),'Comportamento no site'=>array(),'Origem'=>array(),'Dados técnicos'=>array());
        foreach(array('nome'=>'Nome','email'=>'E-mail','telefone'=>'Telefone','empresa'=>'Empresa','cargo'=>'Cargo','linkedin'=>'LinkedIn') as $k=>$label){if($a[$k]!==''){$sections['Contato'][$label]=$a[$k];}}
        if(!$a['email']&&!$a['telefone']&&!$a['linkedin']){$sections['Contato']['Meio de contato']=$a['metodo']==='whatsapp_formulario'?'Não informado neste envio; o contato depende da conversa iniciada no WhatsApp.':'Não informado neste envio.';}
        foreach($a['respostas'] as $k=>$v){$sections['Contato'][$k]=$v;}
        $e=&$sections['Acontecimento'];$e['Método']=F3Base_Relatorios::rotulo($a['metodo']);$e['Quando']=wp_date('d/m/Y H:i:s P',strtotime($a['capturado_em'].' UTC'));
        foreach(array('formulario'=>'Formulário','pagina_titulo'=>'Título da página','pagina'=>'Página','destino'=>'Destino') as $k=>$label){if($a[$k]!==''){$e[$label]=$a[$k];}}
        $e['Aparelho']=self::linha_aparelho($a['aparelho']);if(!empty($a['aparelho']['limite'])){$e['Limite da identificação']=$a['aparelho']['limite'];}unset($e);
        foreach($a['jornada']['paginas']??array() as $i=>$pg){$lines=array(wp_date('H:i:s',$pg['primeiro_em']).' · '.$pg['pagina']);$lines[]=$pg['tempo_ativo_ms']!==null?round($pg['tempo_ativo_ms']/1000,1).' s ativos':($pg['intervalo_observado_segundos']!==null?$pg['intervalo_observado_segundos'].' s de intervalo observado':'Tempo indisponível');if($pg['rolagem_maxima']!==null){$lines[]='Rolagem: '.$pg['rolagem_maxima'].'%';}foreach($pg['secoes'] as $v){$lines[]='Seção: '.$v;}foreach($pg['cliques'] as $v){$lines[]='Clique: '.$v;}$sections['Comportamento no site']['Carregamento '.($i+1)]=$lines;}
        $j=$a['jornada'];$sections['Comportamento no site']['Cobertura']=self::rotulo($j['codigo']??'jornada_indisponivel');$sections['Comportamento no site']['Páginas distintas']=$j['paginas_distintas']??'Indisponível';$sections['Comportamento no site']['Carregamentos vinculados']=$j['numero_carregamentos_vinculados']??'Indisponível';$sections['Comportamento no site']['Duração observada']=isset($j['duracao_observada_segundos'])?$j['duracao_observada_segundos'].' s':'Indisponível';$sections['Comportamento no site']['Limites']=$j['aviso']??'Jornada indisponível';if(!empty($j['corte'])){$sections['Comportamento no site']['Corte']='Recorte limitado a 500 eventos e 100 cliques.';}if(!empty($j['simultaneidade_observada'])){$sections['Comportamento no site']['Abas']='Há carregamentos simultâneos; os tempos não foram somados como uma única leitura.';}
        $lines=self::linhas_atribuicao($a['atribuicao']);$sections['Origem']['Atribuição']=$lines?:array('Origem não observada ou não autorizada.');
        foreach($a['tecnicos'] as $k=>$v){if(in_array($k,array('ip','ip_fonte','user_agent'),true)&&empty($a['consentimento_atual']['medicao'])){continue;}if(is_scalar($v)&&$v!==''){$sections['Dados técnicos'][self::rotulo($k)]=(string)$v;}}
        $capture=$a['consentimento_captura']??array();$sections['Dados técnicos']['Consentimento na captura']=$capture?array('Medição: '.(!empty($capture['medicao'])?'permitida':'não permitida'),'Publicidade: '.(!empty($capture['publicidade'])?'permitida':'não permitida'),'Versão: '.($capture['politica_versao']??'não informada')):array('Evidência histórica ausente');
        $sections['Dados técnicos']['Autorização atual']=array('Medição: '.(!empty($a['consentimento_atual']['medicao'])?'permitida':'não permitida ou revogada'),'Publicidade: '.(!empty($a['consentimento_atual']['publicidade'])?'permitida':'não permitida ou revogada'));
        $sections['Dados técnicos']['Qualidade']=array_values(array_unique(array_map(array(__CLASS__,'rotulo'),$a['qualidade'])));return self::sem_repeticoes($incluir===null?$sections:array_intersect_key($sections,array_flip($incluir)));
    }
    public static function sem_repeticoes(array $sections): array {
        $seen=array();
        foreach($sections as $section=>&$items){foreach($items as $label=>&$values){
            $array=is_array($values);$lines=$array?$values:array($values);
            foreach($lines as &$value){if(!is_scalar($value)){continue;}$text=trim(preg_replace('/\s+/u',' ',html_entity_decode((string)$value,ENT_QUOTES|ENT_HTML5,'UTF-8')));if($text===''){continue;}
                $prefix='';$key=$text;
                if(preg_match('/^(\d{2}:\d{2}:\d{2} · )(.*)$/u',$text,$m)){$prefix=$m[1];$key=$m[2];}
                elseif(preg_match('/^([^:]{1,100}): (.+)$/u',$text,$m)){$prefix=$m[1].': ';$key=$m[2];}
                // Numbers and boolean-like values have distinct meanings under distinct labels.
                if(is_numeric($key)||in_array(mb_strtolower($key),array('sim','não','permitida','não permitida','não permitida ou revogada','indisponível'),true)){continue;}
                if(isset($seen[$key])){$value=$prefix.'Ver '.$seen[$key]['label'].' em '.$seen[$key]['section'].'.';}
                else{$seen[$key]=array('label'=>$prefix!==''?rtrim($prefix,': '):$label,'section'=>$section);}
            }unset($value);$values=$array?$lines:$lines[0];
        }unset($values);}unset($items);return $sections;
    }
    public static function linhas_atribuicao(array $a): array {
        $nested=array('sessao_origem'=>'Sessão','primeiro_toque'=>'Primeiro toque','ultimo_toque'=>'Último toque');
        $clean=static function(array $v): array {return array_filter($v,static fn($x,$k)=>!is_array($x)&&$x!==''&&$x!==null&&!($k==='plataforma'&&$x==='nao_identificada')&&!($k==='modelo'&&$x==='informado'),ARRAY_FILTER_USE_BOTH);};
        $top=$clean(array_diff_key($a,$nested));$lines=array();self::achatado($top,$lines);$same=0;$present=0;
        foreach($nested as $key=>$label){if(!isset($a[$key])||!is_array($a[$key])){continue;}++$present;$values=$clean($a[$key]);$diff=array_filter($values,static fn($v,$k)=>!array_key_exists($k,$top)||(string)$top[$k]!== (string)$v,ARRAY_FILTER_USE_BOTH);if(!$diff){++$same;continue;}self::achatado($diff,$lines,$label.' / ');}
        if($present===3&&$same===3){$lines[]='Sessão, primeiro toque e último toque coincidem.';}
        return array_values(array_unique($lines));
    }
    private static function achatado(array $v,array &$lines,string $prefix=''): void {foreach($v as $k=>$x){$label=$prefix.self::rotulo((string)$k);if(is_array($x)){self::achatado($x,$lines,$label.' / ');}elseif($x!==null&&$x!==''){$value=(string)$x;if(in_array($k,array('plataforma','canal','utm_medium','modelo','cobertura'),true)){$value=array('meta_ads'=>'Anúncios Meta','google_ads'=>'Google Ads','linkedin_ads'=>'Anúncios LinkedIn','openai_ads'=>'Anúncios OpenAI','nao_identificada'=>'Não identificada','organic'=>'Busca orgânica','cpc'=>'Clique pago','paid_social'=>'Anúncio em rede social','social'=>'Rede social','referral'=>'Referência de outro site','sessao'=>'Sessão','primeiro-toque'=>'Primeiro toque','ultimo-toque'=>'Último toque','informado'=>'Informado na captura','parcial'=>'Parcial','anuncio'=>'Anúncio identificado','campanha'=>'Campanha identificada','macro_nao_substituida'=>'Macro do anúncio não substituída')[$value]??$value;}$lines[]=$label.': '.$value;}}}
    public static function texto(array $a): string {
        $lines=array('Site: '.$a['site']);if($a['teste']){$lines[]='TESTE — origem: '.$a['teste_origem'];}
        foreach(self::secoes($a) as $section=>$items){$lines[]='';$lines[]=mb_strtoupper($section);foreach($items as $label=>$values){$lines[]=$label.':';foreach((array)$values as $v){$lines[]='  - '.$v;}}}
        return implode("\n",$lines)."\n\nConsultar contato (login necessário): ".$a['registro_url'];
    }
    public static function nota(array $a,string $mark): string {
        $end='<p><a href="'.esc_url($a['registro_url']).'">'.esc_html(self::ROTULO_REGISTRO).'</a></p><p>'.esc_html($mark.':nota').'</p>';$out='<p><strong>'.esc_html($a['site']).($a['teste']?' · TESTE':'').'</strong></p>';$budget=30000-mb_strlen($end)-150;
        foreach(self::secoes($a) as $section=>$items){$part='<p><strong>'.esc_html($section).'</strong></p><ul>';foreach($items as $label=>$values){$part.='<li><strong>'.esc_html($label).':</strong> ';$print=array();foreach((array)$values as $v){$v=(string)$v;$print[]=self::link_permitido($section,$label)&&preg_match('~^(?:https?://|tel:|mailto:)~',$v)?'<a href="'.esc_url($v).'">'.esc_html($v).'</a>':esc_html($v);}$part.=count($print)>1?'<ul><li>'.implode('</li><li>',$print).'</li></ul>':implode('',$print);$part.='</li>';}$part.='</ul>';if(mb_strlen($out.$part)>$budget){$out.='<p>Resumo cortado. Consulte o registro completo no WordPress.</p>';break;}$out.=$part;}return $out.$end;
    }
    public static function rotulo_aparelho(string $v): string {return array('celular'=>'Celular','tablet'=>'Tablet','computador'=>'Computador','nao_identificado'=>'Não identificado')[$v]??'Não identificado';}
    public static function historico(): array {
        global $wpdb;$state=get_option('f3base_aparelho_migracao',array());$cursor=(int)($state['cursor']??0);$t=F3Base_Leads_Repositorio::tabela();
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,record_id,dados FROM %i WHERE id>%d AND captura<>'eliminado' ORDER BY id LIMIT 100",$t,$cursor),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'leitura_historico_falhou');}
        $n=0;$skipped=0;foreach($rows as $r){$d=json_decode((string)($r['dados']??''),true);if(!is_array($d)||array_is_list($d)||(int)($d['contexto']['aparelho']['versao']??0)>=self::VERSAO){$skipped++;$cursor=(int)$r['id'];continue;}
            $x=self::aparelho($d['contexto']['user_agent']??'',$d['contexto']['client_hints']??array(),!empty($d['origem_nativa']));$d['contexto']['aparelho']=$x;
            $changed=$wpdb->update($t,array('aparelho'=>$x['tipo'],'dados'=>wp_json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),array('record_id'=>$r['record_id'],'dados'=>$r['dados']));
            if($changed===false){return array('ok'=>false,'codigo'=>'historico_gravacao_falhou','cursor'=>$cursor,'processados'=>$n);}if($changed===1){$n++;}else{$skipped++;}$cursor=(int)$r['id'];
        }
        $remaining=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE id>%d AND captura<>'eliminado'",$t,$cursor));
        $save=F3Base_Options::atualizar_estado('f3base_aparelho_migracao',static fn()=>array('versao'=>3,'cursor'=>$cursor,'em'=>time(),'restantes'=>$remaining,'pulados'=>$skipped));
        return array('ok'=>!empty($save['persisted'])&&!$wpdb->last_error,'processados'=>$n,'examinados'=>count($rows),'restantes'=>$remaining,'pulados_concorrencia_ou_dados'=>$skipped,'cursor'=>$cursor);
    }
}
