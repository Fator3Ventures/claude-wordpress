# Core 1.26.0 → responsável pelo MCP 0.19.0

Nenhum fonte MCP foi alterado. O Core mantém provider base-site-core-fator3, contrato de política 1 e 103 abilities; configuração sobe para 6.2.0. Mínimo estável permanece 0.16.0; matriz local desta entrega é MCP 0.19.0.

Pedido Core163: init público apenas agenda; reconciliação/consolidação ficam no executor. Marcador 1250 e contrato estrutural compartilhado são preservados. A sonda pode aprovar o site antes de a migração terminar: isso é esperado e a captura da base continua funcional. Saúde expõe a pendência; não converter pendência de migração em falha de resposta pública.

Exercitado com código MCP real: upload-base64, sonda home/REST com nonce PHP fresco, applied na primeira chamada, rollback antes e depois da finalização, tags e clique HTTP persistido. Tempos e recibos no relatório da entrega e ciclo-instalacao.json. WordPress/PHP/MariaDB locais; não é homologação de Apache ou rede pública da frota.

Orientação operacional continua: verification_pending exige operation-status/reconcile; não repetir upload. Rollback é de arquivos, database_effects_reversible permanece false. Após uso dos canais novos, uma volta prolongada à 1.25 exige pausa/reconciliação dos avisos HMAC, que a versão antiga não implementa.

Como-usar agora lista avisos. Conteudo-instrumentacao-ler adiciona url/por_url e GETs de teste para home, arquivo, busca e 404. Limite de leitura é 5 URLs/20 s por chamada; consumidores devem seguir proxima_pagina e conferir cobertura. Não gravar tema como efeito da auditoria.

Nenhuma mudança obrigatória solicitada ao MCP. Preserve a distinção entre resposta pública saudável, migração concluída, evidência do servidor e resultado de serviços externos. Este relatório é para encaminhamento; nenhuma mensagem foi enviada.
