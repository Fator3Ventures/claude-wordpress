# Avisos de contatos — 1.26

## Configurar

Em **Contatos → Integrações → Avisos**, escolha E-mail, Slack, E-mail e Slack, Webhook JSON assinado ou E-mail e webhook JSON. Padrão: E-mail. Um destino externo por captura; não há envio simultâneo para Slack e receptor JSON nesta versão. A mudança vale para novas capturas; não redireciona pendências.

Para Slack, o dono cola a URL de Incoming Webhook de hooks.slack.com. Para JSON, cola a URL HTTPS do receptor e uma chave aleatória compartilhada de 32 a 256 caracteres (`A-Z`, `a-z`, `0-9`, `_`, `-`); por exemplo, 32 bytes aleatórios codificados em hexadecimal. URL sem porta explícita, credenciais, query ou fragmento. Destinos inseguros são recusados pelo validador HTTP do WordPress. Não seguem redirecionamentos.

URL e chave são cifradas com sodium secretbox e salt do site; campos vazios mantêm o valor, apagar é explícito, a tela só mostra estado. O agente não precisa ler/transportar o segredo. Políticas de teste têm destinos separados `slack` e `webhook`, ambos suprimidos por padrão. Marcar exige escolha explícita e conserva `teste: true` / `classe_trafego: teste`.

## Contrato JSON e assinatura

Um aviso tem schema `f3base.aviso.v1`, event_id, record_id, ciclo, site, method, capturado_em (UTC no formato do registro), classe_trafego, teste, secoes e registro_url. Seções: Contato, Acontecimento e Origem, com os mesmos rótulos e referências do resumo humano. Não inclui anexos, IP, user agent, credenciais nem a jornada bruta. Campos de formulário podem conter informações pessoais fornecidas pelo visitante; só configure receptor autorizado pela equipe.

Cabeçalhos:

- `Content-Type: application/json; charset=utf-8`
- `X-F3Base-Timestamp`: epoch em segundos da tentativa.
- `X-F3Base-Event-ID`: identidade estável do aviso ou lote.
- `X-F3Base-Signature`: `sha256=` seguido do HMAC-SHA256 hexadecimal de `timestamp + "." + corpo_original`, com a chave compartilhada.

O receptor deve conferir o corpo recebido antes de decodificar/reformatar JSON, comparar assinatura em tempo constante, recusar timestamps antigos (sugestão: tolerância de cinco minutos, relógios sincronizados) e deduplicar por event_id. Exemplo PHP do lado receptor:

```php
$raw = file_get_contents('php://input');
$at = $_SERVER['HTTP_X_F3BASE_TIMESTAMP'] ?? '';
$sig = $_SERVER['HTTP_X_F3BASE_SIGNATURE'] ?? '';
$expected = 'sha256=' . hash_hmac('sha256', $at . '.' . $raw, $sharedKey);
if (!ctype_digit($at) || abs(time() - (int)$at) > 300 || !hash_equals($expected, $sig)) {
    http_response_code(401); exit;
}
$event = json_decode($raw, true, 64, JSON_THROW_ON_ERROR);
// Gravar atomicamente event_id e trabalho a executar; identidade repetida é sucesso sem repetir o efeito.
http_response_code(204);
```

JSON aceita qualquer 2xx como confirmação. Slack mantém 200 com corpo `ok`. Receptor deve confirmar só depois de persistir sua intenção. HMAC autentica conteúdo; não garante entrega exatamente uma vez. Não transformar `method`: é dimensão histórica também usada no GA4.

## Fila, contingência e limites

Usa `f3base_avisos_fila`, payload cifrado e unicidade contato/ciclo. Transporte e revisão do destino ficam congelados em `dados.aviso_intencao`; payload identifica o schema. A chave inclui record_id/transporte/ciclo. Não cria segunda fila nem modifica o schema comercial. A coluna interna `aviso=slack`, herdada da 1.25, significa **aguardando destino externo exclusivo** também no JSON; para distinguir, leia aviso_intencao.transporte/canal. A consulta de avisos não expõe payload nem segredo.

Até 30 envios individuais por hora/classe/destino, com cadência local de um por segundo. Excesso vai ao resumo da hora seguinte, até 50 contatos por lote. JSON em lote usa `f3base.aviso.lote.v1`, event_id e eventos; cada evento mantém seu event_id individual. O receptor deve deduplicar também os itens, pois a composição de um lote pode mudar após uma interrupção. Registro e política de teste são revalidados antes de enviar.

429 respeita Retry-After; 5xx usa recuo até cinco tentativas. Timeout/resposta perdida vira incerto e não é reenviado automaticamente. Falha permanente, credencial indisponível, destino alterado ou estado incerto usam contingência por e-mail, respeitando destinatários e testes. E-mail já processado não é duplicado. Trocar URL/chave invalida a revisão das pendências; reenvio exige confirmação do destino atual. Incerto/suspenso exige aceite de possível duplicação e cria novo ciclo.

Consulte `f3base/avisos-fila-ler`, `f3base/avisos-reenviar`, `f3base/como-usar` (assuntos: avisos) e Saúde do Site. Até um minuto depende de executor nessa cadência, rede e limites externos. WP-Cron por visitas não garante prazo.

## Desinstalar, restaurar e eliminar

Desinstalação preserva contatos, fila cifrada e segredos para não perder intenções nem impedir conciliação; suspende pendências. Reinstalar/restaurar não autoriza replay automático. Revise estado e use reenvio explícito. Estados terminais têm retenção de 90 dias; pendências permanecem. Eliminar contato cancela a fila e limpa seu payload. Mensagens/dados já entregues não são apagados no receptor pelo Core. Preservar não é permissão para o agente exportar segredos.
