# Validação — Core 1.26.0

Executada em laboratório em 08/10/2026 com WordPress 7.1.2, PHP 8.3.6, MariaDB 10.11.14, servidor HTTP PHP com quatro workers e fontes finais MCP 0.19.0 / Google 0.8.2. Dados sintéticos. Destinos externos bloqueados; Slack, webhook, e-mail e API Google respondidos por simulações explícitas. Nenhum site/conta de produção foi usado. O servidor PHP local não substitui Apache/AllowOverride da frota.

Evidências e scripts estão no ZIP fonte, `suite/versao-1260/`. Fontes dos companheiros não foram modificados. Provas de releases anteriores não são contadas como testes novos.

| Área | Aceite local | Evidência |
|---|---|---|
| Nova | Estrutura pronta, e-mail padrão, webhook de teste suprimido, finalização agendada sem reconciliação síncrona nem âncora anterior inventada | instalacao-nova.json |
| Upgrade e retorno | MCP real upload-base64/applied na primeira chamada; home e REST com nonce PHP fresco; tags presentes antes da migração; clique HTTP capturado antes e depois de rollback; novo ciclo com migração/finalização e retorno também capturando | ciclo-instalacao.json |
| Tempo | Medidos total HTTP e geração das sondas MCP, além do primeiro GET manual; valores exatos e ambiente no relatório externo e na evidência. Todas as amostras aceitas do cenário final devem ficar abaixo de 2 s | ciclo-instalacao.json |
| 164 | 404 de 100.000 bytes e 403 aceitos por prefixo; índice, HTTP200 e controle truncado recusados; cron com usuário 0 reverifica sem alterar arquivo/revisão | funcional.json |
| 150,151,159 | Código llms seguro inclusive dependência; sufixo recusado; valor entre seções/URL de jornada referenciado; horários/números preservados; consolidação exata, progresso e terceiros preservados | funcional.json |
| 152 | Tema real local com home, arquivo, busca, 404 e post; HTML/URL indexados, cobertura completa e zero faixas faltantes. HTML truncado e tema sem seção têm resultado negativo | ciclo-instalacao.json, funcional.json |
| Slack | Cifra, intenção única, sucesso/403/429/5xx/timeout, reenvio explícito, cancelamento, suspensão, resumo de 50 e e-mail sem duplicar | avisos.json |
| Webhook | Validação de URL/chave, cifra, HMAC dos bytes exatos, HTTP204, identidade em retry, 429, timeout incerto, falha permanente/contingência, rotação sem redirecionar, teste suprimido/marcado, lote com IDs individuais, tela sem reapresentar segredo | webhook.json |
| Companheiros | Duas ordens frias, contratos e SDK, autenticação da documentação, guardas independentes e retorno separado | companheiros-reais.json |
| Google | 20 checks de concessão não padrão, effective_status, coleta sem usuário, commit real no acervo e falha estrutural; respostas Google simuladas | google-sdk.json |
| Empacotamento | PHP lint, CRC, raiz única, igualdade de fontes e instalador, documentação distribuída, hashes | lint.json, pacote.json |

Durante o ciclo, o intervalo de 60 segundos da finalização é exercitado por envelhecimento explícito do checkpoint **apenas no fixture**, não por mudança do relógio/código de produção. O endpoint de captura é chamado por HTTP sem sessão WordPress e marcado como teste. Instalação nova e upgrade usam bancos e content dirs separados.

## Homologação da frota

Ainda deve confirmar os 14 sites, Apache/proxy reais, recepção Slack/JSON/e-mail, cron e tempo da hospedagem. A auditoria não corrige o tema nem promete zero faixas em tema não instrumentado. Não foram repetidos PageSpeed, aparelho físico, DebugView ou fluxos CRM sem mudança nesta release.
