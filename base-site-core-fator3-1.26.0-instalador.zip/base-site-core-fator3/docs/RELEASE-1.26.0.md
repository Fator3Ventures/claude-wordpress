# Release 1.26.0 — 08/10/2026

Base nova/1.25.0, sem gate por versão anterior. Configuração 6.2.0, schema de leads 7, perfil piso-padrao-3.3. Não muda nomes de method nem eventos GA4.

## Pedidos atendidos

| Pedido | Implementação e aceite local |
|---|---|
| 17(e,f,i) | Como-usar inclui avisos; Saúde do Site mostra segredo indisponível, falhas/incerteza e contingência. Webhook JSON HMAC na mesma fila, além de Slack e e-mail. Preservação na desinstalação é intencional e documentada. |
| 150(7) | Exceção textual da tarefa llms recebe código seguro llms_excecao_nao_catalogada. Contrato declara que versões com sufixo são recusadas. |
| 151(e) | Resumo comum referencia o primeiro valor, inclusive URL repetida na jornada e atribuição. Rótulos, horários, métricas diferentes e decisões de consentimento continuam legíveis. Dados brutos não são apagados. |
| 152(d) | GET das URLs renderizadas, incluindo tema, home, arquivo de posts, busca e 404 representativas; saída por_url. Cobertura só é completa quando o documento inteiro e o status esperado foram observados. |
| 159 | Inventário e consolidação incluem release_1120, 1120_trava, reparo_1120 e migracao_1110. Estado incompleto fica preservado e identificado no recibo. |
| 163 | Init público apenas observa/agende. Reconciliação e consolidação ficam em passagem posterior do executor. Marcador 1250 fica como âncora de retorno. Teste MCP real inclui upload, captura pública e rollback antes/depois da finalização. |
| 164 | Diretório usa prefixo de até 65.536 bytes, aceita 403/404 truncado sem sinais de índice, mantém controle positivo 200/token exato e reverificação periódica. |

## Atualização e retorno

A requisição pública agenda `f3base_migrar_estrutura`. O executor aplica checkpoints idempotentes; a finalização ocorre em outra passagem, pelo menos 60 segundos após a conclusão estrutural. A reconciliação de servidor pode ficar pendente: seu resultado e a prova vigente continuam consultáveis; concluir a migração não equivale a provar a configuração pública.

A captura compatível da 1.25 permanece disponível enquanto a migração está pendente. `f3base_estrutura_estado.versao` continua 1.25.0 porque as tabelas compartilhadas não ganharam mudança incompatível. Versão de produto, marcador de release e versão de estrutura têm funções distintas.

`f3base_release_1250` é preservado intencionalmente, inclusive após finalização. `plugins/rollback` restaura arquivos, não dados, e não desfaz capturas nem envios externos. O teste cobre retorno operacional à 1.25; não promete que a tela antiga entenda opções introduzidas pela 1.26. Antes de retorno após adoção do webhook JSON, pause/reconcilie avisos: a 1.25 não é emissor HMAC. Não apague marcadores para forçar atualização.

Em site novo, ativação cria a estrutura local e agenda os efeitos demorados. Nada é aplicado em outro plugin/tema. A instalação não envia mensagem de teste nem ativa serviço externo.

## Limites do aceite

Ensaios locais usam WordPress/PHP/MariaDB reais e fontes finais dos companheiros. Destinos remotos são simulados; não houve implantação na frota, envio real ao Slack, webhook, CRM ou caixa postal. O responsável pela frota confirma os 14 sites, latência de sua hospedagem, cron, arquivos .htaccess e recebimento real. A auditoria diagnostica lacunas do tema; não torna o tema instrumentado por si só.
