# Changelog

## 1.26.0 — 08/10/2026

- Atualização fora da visita pública, finalização em executor e âncora de retorno 1.25.
- Webhook JSON HMAC na fila de avisos; Saúde do Site e como-usar completos.
- Deduplicação entre seções e auditoria por HTML/URL incluindo tema.
- Consolidação 1110/1120 com progresso preservado; prova 403/404 grande por prefixo.
- Código seguro llms, regra estável de versões e matriz MCP 0.19.0/Google 0.8.2.

## 1.25.0 — 08/10/2026

- Captura independente de audiência, contexto privado para editores em cache e atendimento com guarda ilegível.
- Slack com fila própria, contingência, suspensão em restore e configuração segura.
- Melhora eventos/tempo visível, superfícies, WhatsApp por formulário e apresentação da origem.
- Limita cache, amostra 404, agrega sondas explícitas e documenta propriedade de estado.
- Poda intenções, controla verificações/quota CRM e protege templates HTML em Apache.
- Perfil 3.3; contratos conferidos com MCP 0.18.0 e Google 0.8.1; documentação e testes incluídos.

## 1.24.0 — 07/10/2026

- Corrige coordenação de captura, recuperação, intenções, migração e redirects.
- Endurece checkpoints, reconciliação, diagnósticos e avisos do Pipedrive.
- Unifica apresentação humana de contatos e e-mails MIME.
- Adiciona saída, duração, profundidade, saltos e cliques internos/inertes.
- Adiciona largura, navegador, sistema, novo/recorrente e aparelho por sessão.
- Exclui 404 e editores autenticados da audiência; agrega 404 por caminho.
- Adiciona duração por anúncio e campanha.
- Atualiza documentação, contratos e validação instalados.

# 1.22.1

- Migração retomável com valores NULL, vazios, inválidos e escalares preservados.
- Retomada do executor com prazo estável; log seguro e diário antes da reserva.
- Conta/catálogos Pipedrive preservados em falhas transitórias; mapas com diagnóstico separado.
- Histórico de consentimento, jornada e captura de sinais de aparelho corrigidos.
- Reconciliação administrativa em Entregas, execução explícita de lote e avisos limitados.
- Documentação e contratos atualizados; consulte RELEASE-1.22.1.md.

> Entrega 1.22.0 revisada em 06/10/2026: pedido 135 (campo/teste Clarity, vínculo/cota/acervo e ajuda) e conciliação Google revisão 5. Substitui o pacote anterior da mesma versão.

# Alterações

## 1.22.0 — 2026-10-06

- Procedência preservada ao completar padrões; trilha de subchaves e reparo administrativo comprovado da 1.21.
- Brasil para telefone ausente/vazio, validação remota de token candidato e contexto de formulário renovável.
- Recuperação mínima documentada, recriação pausada e ocorrência estável com diário das tentativas.
- Prova local GSC/PSL, mensagens do SDK, render técnico com tokens e limpeza de lacunas na desinstalação.
- Jornada/permissão de leitura, aparelho, CSV, apresentação comum de contatos, notas/links e avisos por episódio.
- Atividade CRM v2 complementar, reconciliação por referência, e-mail alternativo explícito, mapas tipados e ajuda efetiva.
- Operações nativas de retirada de URLs históricas. Documentação e schemas acompanham o plugin.

# 1.21.0 — 06/10/2026

- Corrige delta/tipos de configuração e o fatal da aba técnica com tokens; seis áreas de Medição e anúncios.
- Cookie de testes de 365 dias; aparelho e proveniência da marca nos contatos.
- Apresentação comum de e-mail, tela e nota; jornada por navegação e recebimento tardio.
- Recuperação explícita, reivindicação concorrente de ocorrência, erros sanitizados, filtro de tarefa, horários reconciliáveis e lacunas GSC persistidas.
- Pipedrive confirma pessoa por ID, enriquece somente identificadores ausentes, reutiliza lead da própria instalação e inclui mapas, prévia, alertas e diagnóstico de prontidão.
- Instalação nova ou 1.20.0; contrato 5.1.0; schema leads 6; documentação instalada regenerada.

# 1.20.0 — 2026-10-01

- Coleta diária via contrato público Google 0.7.0, fotografias GSC e publicação atômica por dia.
- Executor comum, argumentos/ocorrências preservados, orçamento e diário independente por origem.
- Barreira local de recuperação com drenagem e geração fora do banco.
- Migração 1.19 retomável; correção CAPI schema 3 e recuo após falha.
- Menu Site Core, contrato 5.0.0 e documentação integrada atualizada.

# 1.19.0 — 01/10/2026

Menu de relatórios; coorte comum e filtros; IA por conteúdo, rede e assinatura; cron da navegação; formulários/confirmação/assunto; arquivos privados por agentes; ofertas; carregamento ocioso e GTM aditivo; Meta PageView/Lead por modos com homologação e fila cifrada; Clarity com acervo sanitizado integral, retenção própria, consulta, comparação e reprocessamento; MCP 0.13.0. Origem: 1.18.0 concluída ou instalação nova. Contrato 4.3.0, leads schema 5. Ver RELEASE-1.19.md e VALIDACAO.md.

# 1.18.0 — 30/09/2026

Base exclusiva 1.17.0 concluída ou instalação nova; contrato 4.2.0. Corrige aliases de templates/queries, normalização de caminhos, totais editoriais de IA e OAuth técnico. Reconcilia fontes antigas com arquivo separado e publicação independente dos dias novos. Acrescenta gestão auditada de anotações aplicadas por padrão, saúde da coleta, grupos de robôs e catálogo de origens IA. Amplia redes oficiais e documenta assinaturas sem finalidade confirmada. Corrige P32, navegação divergente, consentimento padrão explícito e Markdown permanentemente incompleto. Preferências e registros preservados; integrações não são ativadas automaticamente.

# 1.17.0 — 29/09/2026

Medição editorial por conteúdo, sessões e aquisição; origem de IA, automação explicável, HTML/Markdown nos logs, verificação de listas oficiais, referências observadas, Search Console autorizado e histórico anônimo. Nova interface com cobertura, horários legíveis e CSV filtrado.

Correções: LLMS por item e retentativas limitadas; robots com modo original; fronteiras de publicação dos logs; defaults/P00 e histórico 1.16/1.17; ofertas no executor; prova pública de navegação; consentimento tema; dependências de redirects e diagnóstico TTL/schema. Base exclusiva 1.16.0 concluída ou instalação nova.

# 1.16.0 — 2026-09-29

Revisão 2 do pacote: captura de CTA sem WhatsApp, invalidação por revisão de credencial/configuração no Pipedrive e Meta, releitura de campos após resposta perdida e recusa de alternativas sem catálogo confirmado. Mesmos caminhos de instalação; sem migração adicional.

- Base exclusiva: instalação nova ou 1.15.0 concluída; recuperação na própria versão, sem downgrade.
- Navegação tipada (tema/menu clássico/bloco), busca paginada, seção correta no admin e ajuda unificada por campo.
- Agentes e buscadores: OpenAI, Claude, Gemini e famílias específicas; frequência com cobertura, horários e CSV.
- Assunto de e-mail sem nome duplicado, classificação de CTA por destino, inventário limitado e atribuição idempotente apesar de cookies auxiliares.
- Pipedrive opcional: segredos cifrados, verificação de conta/campos, intenção durável, fila com checkpoints, conciliação, prévia, jornada limitada e eliminação conservadora.
- Origens nativas Meta/Google com deduplicação/retomada/tombstones; OpenAI oppref web. LinkedIn e captura nativa OpenAI condicionados ao acesso/contrato.
- Correções de cache/redirects, autoria pública, backups privados, prova de ofertas, consentimento e publicação LLMS; retentativa de análise após 503 corrigida.
- Contrato 4.0.0, perfil piso-padrao-3.2 e documentação instalada. Homologações remotas explicitamente pendentes em VALIDACAO.md.

# Changelog

## 1.25.0 — 08/10/2026

- Captura independente de audiência, contexto privado para editores em cache e atendimento com guarda ilegível.
- Slack com fila própria, contingência, suspensão em restore e configuração segura.
- Melhora eventos/tempo visível, superfícies, WhatsApp por formulário e apresentação da origem.
- Limita cache, amostra 404, agrega sondas explícitas e documenta propriedade de estado.
- Poda intenções, controla verificações/quota CRM e protege templates HTML em Apache.
- Perfil 3.3; contratos conferidos com MCP 0.18.0 e Google 0.8.1; documentação e testes incluídos.

## 1.15.0 — 2026-09-28

- Somente instalação nova e atualização 1.14.0; política, listas vazias e escolhas preservadas.
- Redirects recuperam QUERY_STRING original, respeitam veto por par e consolidam provas por variante em lotes com concorrência/expiração.
- Atribuição/consentimento comum e envelope CAPI a partir do lead persistido, incluindo formulário, fbc/fbp e marca de teste.
- Contrato 3.0.0: mescla parcial por dependências, diagnóstico por caminho, simulação sem efeitos, auditoria ability, piso integral e respostas compactas com evidência única.
- Ofertas múltiplas por plano/período, preço brasileiro, mínimo/grátis/sob consulta, prova pública e conflito de emissor; snapshot privado na migração inequívoca.
- Person incluído na verificação de recursos sameAs; navegação distingue referência válida e vínculo observado.
- Análise com prazo absoluto de 5 segundos após load e saída antecipada; diagnóstico do TTL sem confundir configuração e garantia de idade.
- Confirmação sem JS com noindex/nofollow coerentes; pares de cores acessíveis no consentimento e cadência documentada como registro local.
- Documentação e exemplos novos dentro do instalador; implantador/tema e CRM fora do escopo.

## 1.14.0 — 2026-09-28

- Configurações em sub-abas, ajuda por campo com vantagens/limitações, default de e-mail administrativo somente quando ausente e entrega do índice por arquivo gerado.
- Marcação simples de teste por cookie/cabeçalho/contexto de sonda, preservada em filas; filtros padrão e políticas independentes dos destinos externos/avisos.
- Atribuição comum por anúncio, primeiro/último toque, IDs canônicos e documentação de cruzamentos Meta/Google/LinkedIn.
- Medição em áreas, filtros SQL antes dos limites, cobertura explícita, exportação e jornada; caixa de entrada e editor de formulário organizados.
- Análise com defer, confirmação por evento, idempotência concorrente, retentativas limitadas e diagnóstico de armazenamento. Rapidez de preenchimento deixa de bloquear envio isoladamente.
- Gerações LLMS retomáveis, preservação de publicação e retirada prioritária; operação explícita de cabeçalhos com backup, revisão e recuperação.
- Redirects com preservação de query, host externo autorizado e verificação final/âncora; navegação clássica opcional, instrumentação de CTA e dados estruturados.
- Classificação positiva de acessos e repetição separada; proteção pública configurável, CSS de consentimento por variáveis e cadência observável.
- Documentação técnica completa em diretório protegido, dicionário JSON/Markdown, métricas, SQL e guia de agentes distribuídos no instalador.


## 1.13.0 — 2026-09-24

- Relatórios integrados no painel, CSV e abilities; jornada no contato; cobertura, filtros e comparação.
- Coleta local de funil, navegação, atribuição de sessão, dispositivo e revisão final de vitais; consentimento, quotas e deduplicação.
- Snapshot de opções estruturadas e histórico transacional de atendimento.
- Política explícita Todas/Selecionadas/Nenhuma, prévia de alterações, revisões e gestão por agentes reversível.
- Instalação direta e atualização mínima 1.12.0; preserva políticas existentes, inclusive lista vazia (backlog 29), sem reabrir permissões.
- Sonda de cache reconhece artefatos `wp-cache-*.php` e HTML (backlog 28), sem reduzir a exigência de corpo vazio.
- Retira gravação Flamingo/CPT, reparador histórico, conversão antiga da fila CAPI e desativação automática de cópias antigas.
- Documentação operacional e de agentes incluída no plugin instalado; contrato 2.0.0.

## Histórico até 1.12.0

# Alterações — 1.12.0 — 24/09/2026

- Seletores para campos enumerados; caixas de seleção pesquisáveis para blocos, preservando identificadores indisponíveis.
- Contato organizado em avisos internos, WhatsApp e instrumentação dos botões, com rótulos e ajuda. Até cinco destinatários em campos de e-mail.
- Operação Core integrada à aba Operação do menu F3 Base; o endereço administrativo anterior encaminha ao novo.
- Política de gestão e catálogo operável habilitados na primeira atualização, com fotografia, revisão e marcador por site.
- Leads com sessão canônica, correlação, post_id resolvido no servidor e contexto de IP/user agent. Ausência de sessão tem motivo; não se inventa vínculo histórico.
- Métodos de CTA definidos pelo destino, incluindo `contato_cta` para destino interno, telefone e e-mail. Abrir diálogo continua sem registrar lead.
- Reparo em lotes dos registros já copiados, com evidência preservada ou mapeamento explícito de canal/formulário/campos. Nenhum importador CF7/Flamingo no runtime.
- Saúde e instruções do endpoint identificam o destino `f3base_leads`.
- Arquivos sem `max_bytes` ou com zero ficam sem teto do plugin; extensões vazias não restringem. Limites positivos existentes são preservados.
- Provisionamento e teste de escrita/leitura/remoção da pasta privada; diagnóstico distingue ausência criável e impossibilidade.
- Sonda HTTP do artefato de cache exige corpo vazio, persiste prova e afeta o sucesso agregado na mesma cadência de tokens.
- Web Vitals 6.2.1 local carregado após `load`, com retenção mínima das interações curtas anteriores e correção local de CLS preservada. O arquivo anterior já era minificado; não há alegação de ganho de nota por minificação.
- Resposta ao visitante opcional por formulário, independente do aviso interno, com estado persistente, reserva de envio, limite de frequência e retentativa explícita para estado incerto.
- Documentação versionada incluída no instalador e consultável por ability.
