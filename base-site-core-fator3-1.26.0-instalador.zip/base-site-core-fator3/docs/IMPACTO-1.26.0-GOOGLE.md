# Core 1.26.0 → responsável pelo MCP Google 0.8.2

Nenhum fonte Google foi alterado. SDK search-console-reader/1.0.0, gsc.page-day.read, grant por consumidor, effective_status e provider base-site-core-fator3 permanecem. Mínimo estável é 0.7.1; matriz testada é 0.8.2 com MCP 0.19.0.

O impacto recebido da 0.8.2 foi incorporado à documentação: guardas independentes; pausa Google também protege manutenção, histórico, auditoria e cache; f3_google_cron entra no backup conjunto. Não transformar estado desconhecido/null em zero e não repetir consulta/commit por falha posterior de manutenção. Retomada exige geração/reconciliação de cada plugin.

Passaram duas ordens frias, recuperação separada e 20 verificações com Core/Google reais: registro do consumidor, ausência/grant em conexão não padrão, propriedade correta, effective_status, coleta sem usuário e commit no acervo. Respostas HTTP Google simuladas; nenhuma credencial/conta real usada. Relatórios em companheiros-reais.json e google-sdk.json.

O Core não alterou carregamento/manutenção do Google nem reivindica correção da sobrecarga p95 acima de 100 ms apontada na entrega Google. O teste de atualização Core adia sua própria reconciliação; não mascara timeout do canal ou diagnóstico do companheiro.

Nenhuma alteração obrigatória ao Google identificada nesta versão. Este relatório é para encaminhamento; nenhuma mensagem foi enviada.
