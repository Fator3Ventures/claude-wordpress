# Fator3 Site Core 1.26.0

Instalação nova ou atualização da 1.25.0: referência de manutenção, sem bloqueio por versão de origem. A troca agenda a migração; a primeira visita não executa reconciliação de servidor ou consolidação. O marcador 1.25.0 e o contrato estrutural de captura são preservados para retorno imediato dos arquivos.

Matriz local: **MCP 0.19.0 e MCP Google 0.8.2**, fontes finais recebidos. Contrato de configuração 6.2.0; 103 abilities. Não altera os companheiros, o tema ou o implantador.

[Documentação instalada](docs/DOCUMENTACAO.md) · [Release](docs/RELEASE-1.26.0.md) · [Agentes](docs/AGENTES-1.26.0.md) · [Avisos](docs/AVISOS-WEBHOOK-1.26.md) · [Auditoria por URL](docs/INSTRUMENTACAO-1.26.md) · [Validação](docs/VALIDACAO.md).

Inclui os pedidos 17(e,f,i), 150(7), 151(e), 152(d), 159, 163 e 164. Segredos são colados pelo dono na tela. Documentação e schemas acompanham o plugin instalado e podem ser lidos por `f3base/documentacao-ler`, com manage_options, inclusive em recuperação. Guias com outras versões no nome são históricos.
