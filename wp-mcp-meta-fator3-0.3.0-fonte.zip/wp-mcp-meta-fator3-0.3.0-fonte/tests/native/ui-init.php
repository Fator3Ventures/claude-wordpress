<?php
require getenv('F3_LAB_ROOT').'/wordpress/wp-load.php';wp_set_current_user(1);wp_set_password(getenv('F3_UI_PASSWORD'),1);update_option('home',getenv('F3_UI_URL'));update_option('siteurl',getenv('F3_UI_URL'));
foreach(['Meta','LinkedIn'] as $p){$ns='Fator3\\'.$p.'\\';$conn=$ns.'Connections';$store=$ns.'Store';if(!class_exists($conn))continue;$conn::save(['connection_id'=>'ui','expected_revision'=>0,'label'=>'UI test','token'=>'ui-synthetic-token','assets'=>$p==='Meta'?['instagram'=>['111'],'facebook'=>['900']]:['pages'=>['111'],'ads'=>['222'],'leads'=>[]]]);}
