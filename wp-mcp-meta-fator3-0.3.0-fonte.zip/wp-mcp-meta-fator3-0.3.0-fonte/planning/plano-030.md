# Implementação Meta e LinkedIn 0.3.0

Etapa: planejamento · 17/10/2026 · Base imutável: 0.2.0.

Meta: Pedidos MCP Meta 1 (Description exata) e 9 (diagnóstico de Page Insights). LinkedIn: Pedido MCP LinkedIn 1 (Description exata). Atualização direta 0.2.0 → 0.3.0 e instalação limpa. Sem retomada dos pedidos retirados pelo dono.

1. Preservar identidades, APIs, capacidades e seleção explícita. Alteração funcional somente em Meta. Cabeçalhos e documentação da release em ambos.
2. Conservar códigos/subcódigos numéricos da Graph API e HTTP em erros diretos, resultados parciais e coletas pausadas; nunca retornar mensagem bruta, token ou URL. Identificar resposta vazia sem atribuir causa não demonstrada. Diagnosticar grupos vazios com requisições individuais limitadas.
3. Inspecionar o token derivado da Página explicitamente solicitada em validate-connection, separando permissões verificadas, negadas e desconhecidas. Não inferir read_insights de acesso ao perfil ou da quantidade de seguidores. Uso do App ID/secret existente quando disponível; falha de inspeção permanece explícita.
4. Exercitar período e limites since/until e preservar end_time da origem. Qualquer alteração de datas depende de evidência; não redistribuir snapshots em série histórica nem preencher ausência com zero.
5. Verificar MCP 0.24.0, Core 1.35.0 e Google 0.11.0. Uma validação de transporte é pertinente ao MCP; nenhum novo contrato ou alteração necessária foi identificado para Core/Google/LinkedIn/Implantador. Implantador não disponibilizado.
6. Testar WordPress limpo e atualização com dados e tarefas da 0.2.0; PHP/WP mínimos e convivência; erros 100/10/190/429, subcódigos, vazio, zero, grupos, escopos granulares e sanitização. Teste do fornecedor exige ativos autorizados; o fator3-teste não deve receber credenciais copiadas de produção.
7. Instalar somente os sociais no fator3-teste, uma troca por vez, com hashes, pré-imagens, sondas e leitura integral da ajuda. Sem publicação GitHub ou distribuição na frota.
8. Entregar seis artefatos principais e somente impactos técnicos pertinentes. Fontes com código, build, testes, evidências e relatório pré-fechamento; hash final no relatório externo.

Impacto emitido antes da implementação: wp-mcp-meta-fator3-0.3.0-impacto-wp-mcp-fator3.md. Instaladores-alvo ainda não gerados.

Premissa a verificar: seguidores presentes não demonstram permissão, disponibilidade da métrica nem cobertura em um dia. Sem erro explícito, a causa do vazio permanece indeterminada. O aceite real da Página Fator3/Porter será separado da prova de implementação.

## Encerramento da implementação — 17/10/2026

Plano acima preservado como registro inicial. Implementados Meta 1 e a correção/diagnóstico de Meta 9; LinkedIn 1 implementado. Instaladores 0.3.0 fechados e instalados, um por vez, no fator3-teste. Impacto MCP atualizado no mesmo arquivo para revisão 2/resolvido.

Provas finais: 68 verificações na atualização 0.2.0 → 0.3.0; 65 na instalação limpa com o trio atual; 63 no mínimo WordPress 6.4/PHP 8.1.2. São 196 execuções com cenários repetidos, não 196 casos únicos. O mínimo declarado foi precisado para PHP 8.1.2, efetivamente testado. Cenário dedicado de HTTP 429 não foi executado nesta rodada; o tratamento anterior não foi alterado fora da projeção numérica do Meta. Os relatórios discriminam outros limites.

No fator3-teste: WordPress 7.1.3/PHP 8.3.30; 64 arquivos conferidos por SHA-256; 23 documentos lidos integralmente em 27 páginas com hashes exatos; autotestes locais aprovados; home/REST HTTP 200 antes/depois; nenhuma conexão social cadastrada. Meta 9 segue com aceite externo pendente: o dono da conexão deve executar os 14 dias da Página Fator3 e comparar ao Porter ou registrar a recusa precisa da Graph. Sem inferir causa do vazio e sem publicar na frota.
