# Impacto de Fator3 MCP Meta 0.3.0 em wp-mcp-fator3

Data: 17/10/2026 · Revisão: 2 · Etapa: entrega · Situação: resolvido no escopo da validação coordenada.
Base: 0.2.0, SHA-256 f5cb81781038e487741adc3a1d82791f149d37a5219f7d4747b0acf9ae27d57f. Alvo: 0.3.0; instalador de 89.768 bytes, SHA-256 0f77360b0afca8c1040c411d7bd8b56a431428993f78b9d1504384fce8b6dd03.
Destinatário: MCP 0.24.0, SHA-256 e2c78fcf0e99da55237808bc51fe408405e367fd76a71172b497707996f8aa95.
Natureza: contrato de diagnóstico/validação coordenada · Classificação: validacao-coordenada · Pedido MCP Meta 9.

## Mudança e consequência

Erros de meta/query, job-status e run-job passam a conservar http_status, provider_code e provider_subcode numéricos, além de bool/null de permissões verificadas na Página. meta/validate-connection acrescenta page_permissions com escopos públicos e estado observado; nenhum token/URL/mensagem bruta integra essa projeção. Campos novos são aditivos; envelopes e seleções permanecem.

## Ação ou decisão do responsável

Validar preservação dos tipos e números pelo transporte atual, sem ampliar a projeção de segredos. Responsável pela prova: mantenedor social nesta rodada. Aceite: números, booleanos e null preservados e nenhuma credencial/mensagem bruta da Graph na saída. Ticket: Pedido MCP Meta 9, sem identificador externo adicional. Não foi necessária mudança no MCP; a prova usa sua implementação original 0.24.0. Não há ação de desenvolvimento pendente para seu mantenedor.

## Compatibilidade e sequência

Meta continua independente de MCP para REST e painel. Não é proposta atualização obrigatória do transporte. O bloqueio de idempotência da 0.22 será reavaliado na 0.24 com chave de domínio sem criar efeitos externos.

## Validação e evidência

Executados: respostas simuladas da Graph no WordPress nativo; códigos/subcódigos numéricos, booleanos true/false e null de desconhecido; erros por campo e tentativa de incluir segredos na resposta da origem. SafeOutput e ExecuteAbilityAbility reais do MCP 0.24.0 preservaram os diagnósticos em resultado parcial e recusa. O teste configura o perfil da conexão pelo serviço administrativo público; a recusa inicial por perfil não configurado é respeitada. Campo público novo is_valid evita nome de credencial, sem alterar filtro do MCP.

Evidências no fonte: evidence/lab-upgrade/native-tests.json (68/68), evidence/lab-clean/native-tests.json (65/65), evidence/site-validation.json e evidence/documentation-validation.json. Os dois testes do executor são PHP nativo com HTTP da Graph interceptado, não homologação do fornecedor nem teste MCP HTTP local.

No fator3-teste, MCP 0.24.0 via OAuth: meta/create-job recebeu a chave de domínio e devolveu not_configured para conexão propositalmente inexistente, operação 7c34133dcde48ca14fad0fb6. Nenhum job ou chamada ao fornecedor foi criado. A falha histórica de chave da 0.22 não foi reproduzida. Documentação Meta completa: 12 arquivos, 14 páginas, hashes iguais ao instalador; guards de revisão e caminho aprovados.

## Evolução e encerramento

Revisão 1: proposta aberta no planejamento antes da implementação; instalador ainda não gerado, critérios e testes previstos definidos.

Revisão 2: implementação aditiva e validação concluídas; instalador identificado acima. Encerrada a validação coordenada com evidências próprias, sem declarar trabalho de outro responsável. Homologação da Página Fator3 real permanece pendente no relatório Meta por ausência de conexão social no teste; não é defeito demonstrado do transporte. Documento entregue ao dono, sem envio a terceiros.
