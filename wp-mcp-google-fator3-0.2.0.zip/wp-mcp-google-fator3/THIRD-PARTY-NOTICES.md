# Atribuições

O plugin parte do código WP MCP Google Fator3 0.1.0 enviado pelo usuário, de autoria Fator3 e licenciado GPL-2.0-or-later. Os arquivos e avisos existentes foram preservados quando aplicáveis.

Os testes herdados contêm apoio da Abilities API e trechos do WP MCP Ultimate, mantidos com seus avisos de origem. As dependências de desenvolvimento são instaladas separadamente por Composer e não integram o ZIP de instalação.

O pacote-fonte inclui documentos de descoberta publicados pelo Google como fixtures de teste. Sua origem, revisão e SHA256 estão em tests/fixtures/discovery/sources.json. Google Analytics, Google Ads, Search Console, Sheets e Drive são serviços do Google. A inclusão das fixtures não representa patrocínio ou certificação pelo Google.
