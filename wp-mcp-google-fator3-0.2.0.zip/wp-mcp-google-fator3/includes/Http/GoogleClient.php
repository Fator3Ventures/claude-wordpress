<?php
/**
 * Único ponto de saída para as APIs do Google.
 *
 * Tudo que fala com a rede passa por aqui, e por três motivos concretos.
 *
 * O primeiro é a lista de hosts. Boa parte dos parâmetros destas rotas vem do
 * agente (ids de propriedade, de conta, nomes de recurso) e acaba dentro de uma
 * URL. Concentrar a montagem num lugar que recusa qualquer host fora dos quatro
 * conhecidos transforma um erro de validação lá na frente em "destino não
 * permitido" aqui, antes de qualquer conexão — e mantém o Authorization com o
 * access token longe de um servidor de terceiros.
 *
 * O segundo é o token: nenhuma rota precisa saber se a credencial é service
 * account ou OAuth de usuário.
 *
 * O terceiro é o erro. A Google responde em dois formatos diferentes (o das
 * APIs REST e o do Google Ads, com `details[].errors[]` e `requestId`), e um
 * `{"error":{"code":403,...}}` cru não diz a ninguém o que fazer. Aqui isso
 * vira uma frase e um `reason` estável para quem chamou.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Http;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Options;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class GoogleClient {

	public const HOST_TOKEN    = 'https://oauth2.googleapis.com';
	public const HOST_GA_ADMIN = 'https://analyticsadmin.googleapis.com';
	public const HOST_GA_DATA  = 'https://analyticsdata.googleapis.com';
	public const HOST_ADS      = 'https://googleads.googleapis.com';
	public const HOST_GSC      = 'https://searchconsole.googleapis.com';
	public const HOST_GOOGLE   = 'https://www.googleapis.com';
	public const HOST_SHEETS   = 'https://sheets.googleapis.com';
	public const HOST_MP       = 'https://www.google-analytics.com';

	/** Códigos que valem uma nova tentativa: cota momentânea e falha do lado deles. */
	private const RETRY_CODES = array( 429, 500, 502, 503, 504 );

	/** Teto de páginas em get_all_pages, para uma paginação sem fim não travar a requisição. */
	private const MAX_PAGES = 100;

	/**
	 * @param string     $method HTTP.
	 * @param string     $url    URL absoluta em host permitido.
	 * @param array|null $body   Corpo (JSON, ou formulário com opts['form']).
	 * @param array      $opts   scopes, auth, headers, query, timeout, retries, form, connector.
	 * @return array|\WP_Error Corpo JSON decodificado em 2xx.
	 */
	public static function request( string $method, string $url, ?array $body = null, array $opts = array() ) {
		if ( ! self::assert_allowed_host( $url ) ) {
			return new \WP_Error(
				'f3_google_host',
				__( 'Destino não permitido: este plugin só fala com as APIs do Google.', 'wp-mcp-google-fator3' ),
				array( 'url' => self::safe_url( $url ) )
			);
		}

		$query = isset( $opts['query'] ) && is_array( $opts['query'] ) ? $opts['query'] : array();
		if ( ! empty( $query ) ) {
			$url .= ( false === strpos( $url, '?' ) ? '?' : '&' )
				. self::query_string( $query );
		}

		$headers = array(
			'Accept'     => 'application/json',
			'User-Agent' => self::user_agent(),
		);

		$auth  = ! array_key_exists( 'auth', $opts ) || false !== $opts['auth'];
		$token = '';

		if ( $auth ) {
			$credentials = Credentials::current();
			if ( is_wp_error( $credentials ) ) {
				return $credentials;
			}

			$scopes = isset( $opts['scopes'] ) && is_array( $opts['scopes'] ) ? $opts['scopes'] : array();
			$token  = $credentials->get_access_token( $scopes );
			if ( is_wp_error( $token ) ) {
				return $token;
			}

			$headers['Authorization'] = 'Bearer ' . $token;
		}

		if ( isset( $opts['headers'] ) && is_array( $opts['headers'] ) ) {
			$headers = array_merge( $headers, $opts['headers'] );
		}

		$args = array(
			'method'      => strtoupper( $method ),
			'timeout'     => isset( $opts['timeout'] ) ? max( 5, (int) $opts['timeout'] ) : Options::http_timeout(),
			// Nenhuma API do Google usada aqui redireciona; seguir um 302 seria
			// mandar o Authorization para onde a checagem de host não olhou.
			'redirection' => 0,
			'sslverify'   => true,
			'headers'     => $headers,
		);

		if ( isset( $opts['raw_body'] ) ) {
			if ( ! is_string( $opts['raw_body'] ) || null !== $body || empty( $opts['content_type'] ) || preg_match( '/[\r\n]/', (string) $opts['content_type'] ) ) {
				return new \WP_Error( 'f3_google_raw_body', 'Corpo binário exige content_type válido e não pode ser combinado com body JSON.' );
			}
			$args['body']                    = $opts['raw_body'];
			$args['headers']['Content-Type'] = (string) $opts['content_type'];
		}

		if ( null !== $body ) {
			if ( ! empty( $opts['form'] ) ) {
				// Só o endpoint de token fala formulário; o resto é JSON.
				$args['headers']['Content-Type'] = 'application/x-www-form-urlencoded';
				$args['body']                    = $body;
			} else {
				$args['headers']['Content-Type'] = 'application/json';
				$args['body']                    = (string) wp_json_encode( array() === $body ? (object) array() : $body );
			}
		}

		$retries  = 'write' === ( $opts['mode'] ?? '' ) ? 0 : ( isset( $opts['retries'] ) ? max( 0, (int) $opts['retries'] ) : 2 );
		$response = null;

		for ( $attempt = 0; $attempt <= $retries; $attempt++ ) {
			$response = wp_remote_request( $url, $args );

			if ( is_wp_error( $response ) ) {
				if ( $attempt < $retries ) {
					self::wait( $attempt );
					continue;
				}

				return new \WP_Error(
					'f3_google_network',
					sprintf(
						/* translators: %s: mensagem do erro de rede. */
						__( 'Falha de rede ao falar com a Google: %s', 'wp-mcp-google-fator3' ),
						\Fator3\McpGoogle\Ability::scrub( $response->get_error_message() )
					),
					array( 'url' => self::safe_url( $url ) )
				);
			}

			$code = (int) wp_remote_retrieve_response_code( $response );

			if ( in_array( $code, self::RETRY_CODES, true ) && $attempt < $retries ) {
				self::wait( $attempt );
				continue;
			}

			break;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = (string) wp_remote_retrieve_body( $response );
		$data = json_decode( $raw, true );

		if ( $code >= 200 && $code < 300 ) {
			self::observe( $url, $code, '' );
			if ( '' === trim( $raw ) ) {
				return array();
			}
			if ( is_array( $data ) ) {
				return $data;
			}
			$content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
			if ( false !== stripos( $content_type, 'json' ) || '' === $content_type ) {
				return new \WP_Error(
					'f3_google_json',
					'A API retornou conteúdo JSON inválido.',
					array(
						'status' => $code,
						'url'    => self::safe_url( $url ),
					)
				);
			}
			return array(
				'content_type'   => $content_type,
				// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
				'content_base64' => base64_encode( $raw ),
				'bytes'          => strlen( $raw ),
			);
		}

		return self::error_from( $code, is_array( $data ) ? $data : array(), $url, is_string( $token ) ? $token : '' );
	}

	/**
	 * @param string $url   URL absoluta.
	 * @param array  $query Parâmetros de query.
	 * @param array  $opts  Ver request().
	 * @return array|\WP_Error
	 */
	public static function get( string $url, array $query = array(), array $opts = array() ) {
		if ( ! empty( $query ) ) {
			$opts['query'] = array_merge( isset( $opts['query'] ) && is_array( $opts['query'] ) ? $opts['query'] : array(), $query );
		}

		return self::request( 'GET', $url, null, $opts );
	}

	/**
	 * @param string $url  URL absoluta.
	 * @param array  $body Corpo.
	 * @param array  $opts Ver request().
	 * @return array|\WP_Error
	 */
	public static function post( string $url, array $body, array $opts = array() ) {
		return self::request( 'POST', $url, $body, $opts );
	}

	/**
	 * Segue `nextPageToken` juntando os itens de `$items_key`.
	 *
	 * @param string $url       URL absoluta.
	 * @param array  $query     Parâmetros fixos.
	 * @param string $items_key Chave da lista na resposta (ex.: 'accountSummaries').
	 * @param array  $opts      Ver request().
	 * @param int    $max_items 0 = tudo.
	 * @return array|\WP_Error Lista de itens.
	 */
	public static function get_all_pages( string $url, array $query, string $items_key, array $opts = array(), int $max_items = 0 ) {
		$items       = array();
		$token       = '';
		$seen_tokens = array();

		for ( $page = 0; $page < self::MAX_PAGES; $page++ ) {
			$page_query = $query;
			if ( '' !== $token ) {
				$page_query['pageToken'] = $token;
			}

			$response = self::get( $url, $page_query, $opts );
			if ( is_wp_error( $response ) ) {
				return $response;
			}

			$batch = isset( $response[ $items_key ] ) && is_array( $response[ $items_key ] )
				? $response[ $items_key ]
				: array();

			foreach ( $batch as $item ) {
				$items[] = $item;

				if ( $max_items > 0 && count( $items ) >= $max_items ) {
					return $items;
				}
			}

			$token = isset( $response['nextPageToken'] ) ? (string) $response['nextPageToken'] : '';

			if ( '' === $token ) {
				return $items;
			}
			if ( isset( $seen_tokens[ $token ] ) ) {
				return new \WP_Error( 'f3_google_pagination', 'A API repetiu um page token. A listagem não está completa; nenhum total parcial foi confirmado.' );
			}
			$seen_tokens[ $token ] = true;
		}

		return new \WP_Error( 'f3_google_pagination_limit', 'A listagem excedeu 100 páginas. Use filtros ou páginas explícitas; não é um catálogo completo.' );
	}

	/**
	 * Só https, porta padrão e um dos quatro hosts conhecidos.
	 */
	public static function assert_allowed_host( string $url ): bool {
		$parts = wp_parse_url( $url );

		if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return false;
		}

		if ( 'https' !== strtolower( (string) $parts['scheme'] ) ) {
			return false;
		}

		if ( ! empty( $parts['port'] ) && 443 !== (int) $parts['port'] ) {
			return false;
		}

		// Credenciais na URL (https://user:pass@host/) seriam um jeito de
		// disfarçar o destino real em alguns parsers; aqui nenhuma API precisa.
		if ( ! empty( $parts['user'] ) || ! empty( $parts['pass'] ) ) {
			return false;
		}

		$host = strtolower( (string) $parts['host'] );

		foreach ( self::allowed_hosts() as $allowed ) {
			if ( $host === $allowed ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @return string[]
	 */
	public static function allowed_hosts(): array {
		$hosts = array();

		foreach ( array( self::HOST_TOKEN, self::HOST_GA_ADMIN, self::HOST_GA_DATA, self::HOST_ADS, self::HOST_GSC, self::HOST_GOOGLE, self::HOST_SHEETS, self::HOST_MP ) as $base ) {
			$host = wp_parse_url( $base, PHP_URL_HOST );
			if ( is_string( $host ) ) {
				$hosts[] = strtolower( $host );
			}
		}

		return $hosts;
	}

	/**
	 * Espera entre tentativas: 1s, depois 2s.
	 *
	 * O filtro existe para os testes rodarem sem dormir de verdade.
	 */
	private static function wait( int $attempt ): void {
		$seconds = (int) apply_filters( 'f3_mcp_google_retry_wait', $attempt + 1, $attempt );

		if ( $seconds > 0 ) {
			sleep( $seconds );
		}
	}

	private static function user_agent(): string {
		$version = defined( 'F3_MCP_GOOGLE_VERSION' ) ? F3_MCP_GOOGLE_VERSION : '0.1.0';

		return 'wp-mcp-google-fator3/' . $version . ' (+' . home_url() . ')';
	}

	/**
	 * URL sem query: a query pode carregar filtros e, no fluxo OAuth, o `code`.
	 */
	private static function safe_url( string $url ): string {
		$cut = strpos( $url, '?' );

		return false === $cut ? $url : substr( $url, 0, $cut );
	}

	/**
	 * Monta o WP_Error a partir do corpo de erro da Google.
	 *
	 * @param int    $code  Código HTTP.
	 * @param array  $data  Corpo decodificado.
	 * @param string $url   URL chamada.
	 * @param string $token Access token usado nesta chamada, para redigir se ecoado de volta.
	 */
	private static function error_from( int $code, array $data, string $url, string $token = '' ) {
		$reason  = '';
		$message = '';
		$details = array();

		$error = $data['error'] ?? null;

		if ( is_array( $error ) ) {
			$message = isset( $error['message'] ) ? (string) $error['message'] : '';
			$reason  = isset( $error['status'] ) ? (string) $error['status'] : '';
			$details = self::sanitize_details( $error );

			$parts      = array();
			$request_id = '';
			$ads_reason = '';

			// Formato do Google Ads: a mensagem útil está enterrada em
			// details[].errors[].message, e o requestId é o que o suporte pede.
			foreach ( (array) ( $error['details'] ?? array() ) as $detail ) {
				if ( ! is_array( $detail ) ) {
					continue;
				}

				if ( ! empty( $detail['requestId'] ) && is_scalar( $detail['requestId'] ) ) {
					$request_id = (string) $detail['requestId'];
				}

				foreach ( (array) ( $detail['errors'] ?? array() ) as $item ) {
					if ( ! is_array( $item ) ) {
						continue;
					}

					if ( ! empty( $item['message'] ) && is_scalar( $item['message'] ) ) {
						$parts[] = (string) $item['message'];
					}

					// O errorCode do Google Ads ('queryError: BAD_FIELD_NAME')
					// diz o que corrigir; o status genérico da camada REST
					// ('INVALID_ARGUMENT') não diz nada. Quando os dois
					// existem, o específico vale.
					if ( '' === $ads_reason && isset( $item['errorCode'] ) && is_array( $item['errorCode'] ) ) {
						$key = array_key_first( $item['errorCode'] );
						if ( null !== $key && is_scalar( $item['errorCode'][ $key ] ) ) {
							$ads_reason = $key . ':' . (string) $item['errorCode'][ $key ];
						}
					}
				}
			}

			if ( '' !== $ads_reason ) {
				$reason = $ads_reason;
			}

			if ( ! empty( $parts ) ) {
				$message = implode( ' | ', $parts );

				if ( '' !== $request_id ) {
					$message .= sprintf(
						/* translators: %s: identificador da requisição no Google Ads. */
						__( ' (requestId: %s)', 'wp-mcp-google-fator3' ),
						$request_id
					);
				}
			}
		} elseif ( is_string( $error ) && '' !== $error ) {
			// O endpoint de token traz o código no campo error e texto em error_description.
			$reason  = $error;
			$message = isset( $data['error_description'] ) ? (string) $data['error_description'] : $error;
			$details = array( 'error' => $reason );
		}

		if ( '' === $message ) {
			$message = sprintf(
				/* translators: %d: código HTTP. */
				__( 'A API do Google respondeu HTTP %d.', 'wp-mcp-google-fator3' ),
				$code
			);
		}

		$hint = self::error_action( $reason . ' ' . (string) wp_json_encode( $data ), $url, $code );
		if ( '' !== $hint ) {
			$message .= ' Ação: ' . $hint;
		}
		self::observe( $url, $code, $reason . ' ' . (string) wp_json_encode( $data ) );
		$message = \Fator3\McpGoogle\Ability::scrub( $message );
		$details = \Fator3\McpGoogle\Audit::redact( $details );

		// A Google nunca ecoa o Authorization de volta, mas $message vem de
		// texto livre do corpo de erro e $details vai inteiro para a resposta
		// da habilidade; um proxy ou API mal comportada que devolvesse a
		// própria requisição no corpo do erro não pode fazer o access token
		// sair por aqui. `sanitize_details()` já tira campos com nome de
		// credencial; isto cobre o caso do valor aparecer dentro de um texto.
		if ( strlen( $token ) >= 8 ) {
			$message = (string) self::redact_token( $message, $token );
			$reason  = (string) self::redact_token( $reason, $token );
			$details = self::redact_token( $details, $token );
		}

		return new \WP_Error(
			'f3_google_http',
			$message,
			array(
				'status'  => $code,
				'reason'  => $reason,
				'message' => $message,
				'details' => $details,
				'url'     => self::safe_url( $url ),
				'action'  => $hint,
			)
		);
	}

	/** Parâmetros repeated da Discovery usam a mesma chave, nunca colchetes PHP. */
	private static function query_string( array $query ): string {
		$parts = array();
		foreach ( $query as $name => $value ) {
			foreach ( is_array( $value ) ? $value : array( $value ) as $item ) {
				if ( null === $item ) {
					continue;
				}
				$text    = is_bool( $item ) ? ( $item ? 'true' : 'false' ) : (string) $item;
				$parts[] = rawurlencode( (string) $name ) . '=' . rawurlencode( $text );
			}
		}
		return implode( '&', $parts );
	}

	private static function error_action( string $error, string $url, int $code ): string {
		$upper = strtoupper( $error );
		if ( false !== strpos( $upper, 'DEVELOPER_TOKEN_NOT_APPROVED' ) || false !== strpos( $upper, 'DEVELOPER_TOKEN_PROHIBITED' ) ) {
			return 'Solicite aprovação do developer token no API Center da conta administradora Google Ads; um token de teste só alcança contas de teste.';
		}
		if ( false !== strpos( $upper, 'ACCESS_TOKEN_SCOPE_INSUFFICIENT' ) || false !== strpos( $upper, 'INSUFFICIENTPERMISSIONS' ) || false !== strpos( $upper, 'INSUFFICIENT AUTHENTICATION SCOPES' ) ) {
			return 'Reconecte o OAuth autorizando os escopos da versão 0.2.0. Em delegação de domínio, autorize os escopos exigidos na administração do Workspace.';
		}
		if ( false !== strpos( $upper, 'SERVICE_DISABLED' ) || false !== strpos( $upper, 'ACCESSNOTCONFIGURED' ) || false !== strpos( $upper, 'API HAS NOT BEEN USED' ) ) {
			return 'Habilite esta API no projeto Google Cloud da credencial; aguarde a propagação e repita a chamada.';
		}
		if ( false !== strpos( $upper, 'STORAGEQUOTAEXCEEDED' ) ) {
			return 'Service accounts não possuem quota de Meu Drive. Use planilha existente compartilhada, pasta de Drive compartilhado ou OAuth de usuário.';
		}
		if ( false !== strpos( $upper, 'USER_PERMISSION_DENIED' ) || 403 === $code ) {
			if ( false !== strpos( $url, 'googleads.googleapis.com' ) ) {
				return 'Adicione o e-mail da credencial à conta Ads/MCC com papel suficiente (Administrador para usuários e faturamento) e confira login-customer-id e customer_id.';
			}
			if ( false !== strpos( $url, 'analytics' ) ) {
				return 'Conceda acesso à conta/propriedade GA4 para o e-mail da credencial; Editor para alterações e Administrador para gerenciar usuários.';
			}
			if ( false !== strpos( $url, 'webmasters' ) || false !== strpos( $url, 'searchconsole' ) || false !== strpos( $url, 'siteVerification' ) ) {
				return 'Conceda acesso à propriedade exata na Search Console; operações de propriedade/verificação exigem proprietário e comprovação de controle do site ou DNS.';
			}
			return 'Compartilhe o arquivo/pasta com o e-mail da credencial e papel suficiente. Confira também os escopos OAuth exigidos pelo método.';
		}
		if ( 401 === $code ) {
			return 'Verifique a chave da service account ou reconecte a conta OAuth; a credencial foi recusada.';
		}
		return '';
	}

	/** Estado observado, separado de emissão de token e de permissão no recurso. */
	private static function observe( string $url, int $code, string $reason ): void {
		if ( false !== strpos( $url, '/discovery/' ) || false !== strpos( $url, '$discovery' ) || false !== strpos( $url, 'oauth2.googleapis.com' ) ) {
			return;
		}
		$service            = self::service_for( $url );
		$key                = 'f3_mcp_google_api_' . Credentials::identity_key();
		$states             = get_transient( $key );
		$states             = is_array( $states ) ? $states : array();
		$disabled           = (bool) preg_match( '/SERVICE_DISABLED|accessNotConfigured|API has not been used/i', $reason );
		$prior              = $states[ $service ]['enabled'] ?? null;
		$states[ $service ] = array(
			'enabled'          => $disabled ? false : ( $code >= 200 && $code < 300 ? true : $prior ),
			'last_http_status' => $code,
			'checked_at'       => gmdate( 'c' ),
		);
		set_transient( $key, $states, 86400 );
	}

	public static function api_status(): array {
		$states = get_transient( 'f3_mcp_google_api_' . Credentials::identity_key() );
		$out    = array();
		foreach ( array( 'analytics-admin', 'analytics-data', 'google-ads', 'search-console', 'site-verification', 'sheets', 'drive', 'measurement-protocol' ) as $service ) {
			$out[ $service ] = $states[ $service ] ?? array(
				'enabled'    => null,
				'checked_at' => null,
				'note'       => 'Ainda não observada; token válido não comprova habilitação ou acesso ao recurso.',
			);
		}
		return $out;
	}

	private static function service_for( string $url ): string {
		foreach ( array(
			'analyticsadmin'           => 'analytics-admin',
			'analyticsdata'            => 'analytics-data',
			'googleads'                => 'google-ads',
			'searchconsole'            => 'search-console',
			'/webmasters/'             => 'search-console',
			'siteVerification'         => 'site-verification',
			'sheets.googleapis'        => 'sheets',
			'/drive/'                  => 'drive',
			'www.google-analytics.com' => 'measurement-protocol',
		) as $part => $service ) {
			if ( false !== strpos( $url, $part ) ) {
				return $service;
			}
		}
		return 'google';
	}

	/**
	 * Substitui qualquer ocorrência do access token por um marcador, em uma
	 * string ou recursivamente dentro de um array.
	 *
	 * @param mixed  $value Valor a limpar.
	 * @param string $token Access token desta chamada (já validado com ao menos 8 caracteres).
	 * @return mixed
	 */
	private static function redact_token( $value, string $token ) {
		if ( is_string( $value ) ) {
			return false === strpos( $value, $token ) ? $value : str_replace( $token, '[token redigido]', $value );
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = self::redact_token( $item, $token );
			}
		}

		return $value;
	}

	/**
	 * Tira do bloco de detalhes qualquer campo com cara de credencial.
	 *
	 * A Google não devolve token em mensagem de erro, mas este array vai
	 * inteiro para a resposta da habilidade — a checagem custa nada.
	 *
	 * @param mixed $value Valor a limpar.
	 * @param int   $depth Profundidade atual.
	 * @return mixed
	 */
	private static function sanitize_details( $value, int $depth = 0 ) {
		if ( $depth > 6 || ! is_array( $value ) ) {
			return is_array( $value ) ? array() : $value;
		}

		$suspect = array( 'access_token', 'refresh_token', 'id_token', 'assertion', 'client_secret', 'private_key', 'developer_token', 'authorization' );
		$clean   = array();

		foreach ( $value as $key => $item ) {
			if ( is_string( $key ) && in_array( strtolower( $key ), $suspect, true ) ) {
				continue;
			}

			$clean[ $key ] = is_array( $item ) ? self::sanitize_details( $item, $depth + 1 ) : $item;
		}

		return $clean;
	}
}
