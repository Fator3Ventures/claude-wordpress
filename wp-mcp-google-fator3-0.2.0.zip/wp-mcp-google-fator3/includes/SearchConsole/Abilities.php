<?php
/**
 * Habilidades nomeadas da Search Console.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\SearchConsole;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Abilities {
	public static function register(): void {
		self::register_one( 'list-sites', 'Lista propriedades Search Console e suas permissões.', array(), array(), 'read' );
		self::register_one( 'get-site', 'Obtém a permissão da credencial na propriedade.', self::site_schema(), array( 'site_url' ), 'read' );
		self::register_one( 'query', 'Consulta desempenho orgânico: métricas nativas, dimensões, filtros e paginação até 25.000 linhas.', self::query_schema(), array( 'site_url' ), 'read' );
		self::register_one( 'list-sitemaps', 'Lista sitemaps enviados, opcionalmente filtrados por índice.', self::site_schema() + array( 'sitemap_index' => array( 'type' => 'string' ) ), array( 'site_url' ), 'read' );
		self::register_one(
			'inspect-url',
			'Inspeciona a versão indexada de uma URL. Não solicita indexação.',
			self::site_schema() + array(
				'inspection_url' => array( 'type' => 'string' ),
				'language_code'  => array(
					'type'    => 'string',
					'default' => 'pt-BR',
				),
			),
			array( 'site_url', 'inspection_url' ),
			'read'
		);
		foreach ( array(
			'submit-sitemap' => 'Envia um sitemap à Search Console.',
			'delete-sitemap' => 'Remove um sitemap da lista da Search Console; não remove o arquivo do site.',
		) as $name => $description ) {
			self::register_one( $name, $description, self::site_schema() + array( 'sitemap_url' => array( 'type' => 'string' ) ), array( 'site_url', 'sitemap_url' ), 'write' );
		}
		self::register_one( 'add-site', 'Adiciona a propriedade à lista da credencial. A verificação de propriedade é separada.', self::site_schema(), array( 'site_url' ), 'write' );
		self::register_one( 'delete-site', 'Remove a propriedade da lista da credencial; não exclui o site.', self::site_schema(), array( 'site_url' ), 'write' );
	}

	private static function register_one( string $name, string $description, array $properties, array $required, string $mode ): void {
		if ( 'write' === $mode ) {
			$properties['dry_run'] = array(
				'type'        => 'boolean',
				'description' => 'Estas operações não têm validateOnly; true é recusado sem executar a mutação.',
			);
		}
		Ability::register(
			'gsc/' . $name,
			'gsc',
			array(
				'label'        => 'Search Console: ' . $name,
				'description'  => $description,
				'mode'         => $mode,
				'input_schema' => array(
					'properties' => $properties,
					'required'   => $required,
				),
				'callback'     => static function ( array $input ) use ( $name ): array {
					return self::run( $name, $input ); },
			)
		);
	}

	public static function run( string $name, array $input ): array {
		$write = in_array( $name, array( 'submit-sitemap', 'delete-sitemap', 'add-site', 'delete-site' ), true );
		if ( $write && ! empty( $input['dry_run'] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_dry_run_unsupported', 'Search Console não oferece validateOnly nesta operação. Nenhuma alteração foi enviada.' ) );
		}
		if ( 'list-sites' === $name ) {
			$accounts = Api::accounts();
			return is_wp_error( $accounts ) ? Response::fail( $accounts ) : Response::ok(
				array(
					'sites' => $accounts,
					'count' => count( $accounts ),
				),
				'Propriedades Search Console acessíveis.'
			);
		}
		$site = Api::site( $input['site_url'] ?? '' );
		if ( is_wp_error( $site ) ) {
			return Response::fail( $site );
		}
		if ( 'query' === $name ) {
			return self::query_response( $input );
		}
		$path   = array( 'siteUrl' => $site );
		$query  = array();
		$body   = null;
		$method = '';
		switch ( $name ) {
			case 'get-site':
				$method = 'webmasters.sites.get';
				break;
			case 'list-sitemaps':
				$method = 'webmasters.sitemaps.list';
				if ( ! empty( $input['sitemap_index'] ) ) {
					$query['sitemapIndex'] = $input['sitemap_index'];
				}
				break;
			case 'inspect-url':
				if ( ! self::http_url( $input['inspection_url'] ?? null ) ) {
					return Response::fail( new \WP_Error( 'f3_google_gsc_input', 'inspection_url precisa ser URL http/https sem credenciais ou fragmento.' ) );
				}
				$method = 'searchconsole.urlInspection.index.inspect';
				$path   = array();
				$body   = array(
					'siteUrl'       => $site,
					'inspectionUrl' => $input['inspection_url'],
					'languageCode'  => $input['language_code'] ?? 'pt-BR',
				);
				break;
			case 'submit-sitemap':
			case 'delete-sitemap':
				if ( ! self::http_url( $input['sitemap_url'] ?? null ) ) {
					return Response::fail( new \WP_Error( 'f3_google_gsc_input', 'sitemap_url precisa ser URL http/https sem credenciais ou fragmento.' ) );
				}
				$path['feedpath'] = $input['sitemap_url'];
				$method           = 'webmasters.sitemaps.' . ( 'submit-sitemap' === $name ? 'submit' : 'delete' );
				break;
			case 'add-site':
				$method = 'webmasters.sites.add';
				break;
			case 'delete-site':
				$method = 'webmasters.sites.delete';
				break;
			default:
				return Response::fail( new \WP_Error( 'f3_google_gsc_input', 'Operação Search Console desconhecida.' ) );
		}
		$snapshot_method = isset( $path['feedpath'] ) ? 'webmasters.sitemaps.get' : 'webmasters.sites.get';
		if ( $write ) {
			Audit::before( self::snapshot( $snapshot_method, $path ) );
		}
		$response = ExecuteAction::call( 'search-console', $method, $path, $query, $body, array( 'mode' => $write ? 'write' : 'read' ) );
		if ( is_wp_error( $response ) ) {
			return Response::fail( $response );
		}
		if ( $write ) {
			Audit::after( self::snapshot( $snapshot_method, $path ) );
		}
		return Response::ok(
			array(
				'site_url' => $site,
				'data'     => $response,
			),
			$write ? 'Operação Search Console concluída.' : 'Resposta Search Console.'
		);
	}

	private static function query_response( array $input ): array {
		$body = Api::body( $input );
		if ( is_wp_error( $body ) ) {
			return Response::fail( $body );
		}
		$response = Api::query( $input );
		if ( is_wp_error( $response ) ) {
			return Response::fail( $response );
		}
		$native_rows = isset( $response['rows'] ) && is_array( $response['rows'] ) ? $response['rows'] : array();
		$truncated   = count( $native_rows ) >= $body['rowLimit'];
		$meta        = array(
			'site_url'                  => $input['site_url'],
			'row_count'                 => count( $native_rows ),
			'row_limit'                 => $body['rowLimit'],
			'start_row'                 => $body['startRow'],
			'next_start_row'            => $truncated ? $body['startRow'] + count( $native_rows ) : null,
			'truncated'                 => $truncated,
			'metadata'                  => $response['metadata'] ?? array(),
			'response_aggregation_type' => $response['responseAggregationType'] ?? null,
			'data_timezone'             => 'America/Los_Angeles',
			'warnings'                  => array( 'A API retorna as principais linhas; consultas anonimizadas e limites internos podem impedir a recuperação de todos os dados.' ),
		);
		if ( 'raw' === ( $input['format'] ?? 'table' ) ) {
			return Response::ok( $meta + array( 'data' => $response ), 'Dados Search Console no formato nativo.' );
		}
		$dimensions = Api::field_list( $input['dimensions'] ?? array(), array( 'date', 'query', 'page', 'country', 'device', 'searchAppearance', 'hour' ) );
		$catalog    = array_column( Api::fields(), null, 'id' );
		$fields     = array_merge( $dimensions, array( 'clicks', 'impressions', 'ctr', 'position' ) );
		$columns    = array();
		foreach ( $fields as $field ) {
			$columns[] = $catalog[ $field ];
		}
		$rows = array();
		foreach ( $native_rows as $record ) {
			$row = array();
			foreach ( $dimensions as $index => $dimension ) {
				$row[] = (string) ( $record['keys'][ $index ] ?? '' );
			}
			foreach ( array( 'clicks', 'impressions', 'ctr', 'position' ) as $metric ) {
				$row[] = isset( $record[ $metric ] ) && is_numeric( $record[ $metric ] ) ? $record[ $metric ] + 0 : null;
			}
			$rows[] = $row;
		}
		return Response::ok(
			$meta + array(
				'columns' => $columns,
				'rows'    => $rows,
			),
			count( $rows ) . ' linha(s) Search Console.'
		);
	}

	private static function snapshot( string $method, array $path ): array {
		$response = ExecuteAction::call( 'search-console', $method, $path, array(), null, array( 'mode' => 'read' ) );
		if ( ! is_wp_error( $response ) ) {
			return array(
				'available' => true,
				'exists'    => true,
				'resource'  => $response,
			);
		}
		$data = $response->get_error_data();
		if ( is_array( $data ) && 404 === (int) ( $data['status'] ?? 0 ) ) {
			return array(
				'available' => true,
				'exists'    => false,
			);
		}
		return array(
			'available' => false,
			'reason'    => $response->get_error_message(),
		);
	}

	private static function http_url( $value ): bool {
		if ( ! is_string( $value ) || preg_match( '/[\x00-\x20]/', $value ) ) {
			return false;
		}
		$parts = wp_parse_url( $value );
		return false !== $parts && ! empty( $parts['host'] ) && in_array( $parts['scheme'] ?? '', array( 'http', 'https' ), true ) && ! isset( $parts['user'] ) && ! isset( $parts['fragment'] );
	}

	private static function site_schema(): array {
		return array(
			'site_url' => array(
				'type'        => 'string',
				'description' => 'URL exata da propriedade, sc-domain:dominio.com, nome único ou * para expandir propriedades acessíveis.',
			),
		);
	}

	private static function query_schema(): array {
		$properties = self::site_schema() + array(
			'date_range' => array(
				'type'        => array( 'object', 'string' ),
				'description' => 'Preset ou {from,to}; alternativamente use start_date e end_date.',
			),
			'dimensions' => array(
				'type'        => array( 'array', 'string' ),
				'items'       => array( 'type' => 'string' ),
				'description' => 'date, query, page, country, device, searchAppearance, hour. Datas Google usam PT.',
			),
			'filters'    => array(
				'type'        => array( 'array', 'object' ),
				'items'       => array( 'type' => 'object' ),
				'description' => 'Filtros unificados de dimensão {field,operator,value}, combinados com AND.',
			),
			'format'     => array(
				'type'    => 'string',
				'enum'    => array( 'table', 'raw' ),
				'default' => 'table',
			),
		);
		foreach ( array( 'start_date', 'startDate', 'end_date', 'endDate', 'type', 'search_type', 'searchType', 'data_state', 'dataState', 'aggregation_type', 'aggregationType' ) as $name ) {
			$properties[ $name ] = array( 'type' => 'string' );
		}
		foreach ( array( 'row_limit', 'rowLimit', 'limit' ) as $name ) {
			$properties[ $name ] = array(
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => Api::MAX_ROWS,
			);
		}
		foreach ( array( 'start_row', 'startRow', 'offset' ) as $name ) {
			$properties[ $name ] = array(
				'type'    => 'integer',
				'minimum' => 0,
				'maximum' => 2147483647,
			);
		}
		foreach ( array( 'dimension_filter_groups', 'dimensionFilterGroups' ) as $name ) {
			$properties[ $name ] = array(
				'type'        => 'array',
				'items'       => array( 'type' => 'object' ),
				'description' => 'Grupos nativos {groupType:"and",filters:[{dimension,operator,expression}]}.',
			);
		}
		return $properties;
	}
}
