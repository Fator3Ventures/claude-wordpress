<?php
/**
 * Search Console: dados nativos e consultas no formato unificado.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\SearchConsole;

use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\Unified\Accounts;
use Fator3\McpGoogle\Unified\DateRange;
use Fator3\McpGoogle\Unified\Filters;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Api {
	public const MAX_ROWS    = 25000;
	private const DIMENSIONS = array( 'date', 'query', 'page', 'country', 'device', 'searchAppearance', 'hour' );
	private const METRICS    = array( 'clicks', 'impressions', 'ctr', 'position' );

	/** @return array|\WP_Error */
	public static function accounts() {
		$response = ExecuteAction::call( 'search-console', 'webmasters.sites.list', array(), array(), null, array( 'mode' => 'read' ) );
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$rows = array();
		foreach ( $response['siteEntry'] ?? array() as $site ) {
			if ( ! is_array( $site ) || empty( $site['siteUrl'] ) ) {
				continue;
			}
			$rows[] = array(
				'connector'         => 'search-console',
				'account_id'        => (string) $site['siteUrl'],
				'native_account_id' => (string) $site['siteUrl'],
				'name'              => (string) $site['siteUrl'],
				'permission_level'  => (string) ( $site['permissionLevel'] ?? '' ),
			);
		}
		return $rows;
	}

	public static function fields(): array {
		$labels = array(
			'clicks'           => 'Cliques',
			'impressions'      => 'Impressões',
			'ctr'              => 'CTR (fração)',
			'position'         => 'Posição média',
			'date'             => 'Data (PT)',
			'query'            => 'Consulta',
			'page'             => 'URL canônica',
			'country'          => 'País (ISO alpha-3)',
			'device'           => 'Dispositivo',
			'searchAppearance' => 'Aparência na pesquisa',
			'hour'             => 'Hora (PT)',
		);
		$out    = array();
		foreach ( array_merge( self::DIMENSIONS, self::METRICS ) as $id ) {
			$metric = in_array( $id, self::METRICS, true );
			$out[]  = array(
				'id'    => $id,
				'label' => $labels[ $id ],
				'type'  => $metric ? 'metric' : 'dimension',
				'kind'  => $metric ? 'number' : 'string',
			);
		}
		return $out;
	}

	/** Valida os parâmetros e produz o corpo nativo, sem executar HTTP. */
	public static function body( array $input ) {
		$range = DateRange::resolve(
			$input['date_range'] ?? array(
				'from' => $input['start_date'] ?? ( $input['startDate'] ?? '' ),
				'to'   => $input['end_date'] ?? ( $input['endDate'] ?? '' ),
			)
		);
		if ( is_wp_error( $range ) ) {
			return $range;
		}
		$dimensions = self::field_list( $input['dimensions'] ?? array(), self::DIMENSIONS );
		if ( is_wp_error( $dimensions ) ) {
			return $dimensions;
		}
		$limit  = $input['row_limit'] ?? ( $input['rowLimit'] ?? ( $input['limit'] ?? min( Options::max_rows(), self::MAX_ROWS ) ) );
		$offset = $input['start_row'] ?? ( $input['startRow'] ?? ( $input['offset'] ?? 0 ) );
		if ( ! self::integer( $limit, 1, self::MAX_ROWS ) || ! self::integer( $offset, 0, 2147483647 ) ) {
			return self::error( 'row_limit deve ser inteiro entre 1 e 25.000; start_row deve ser inteiro não negativo (máximo 2147483647).' );
		}
		$body = array(
			'startDate'  => $range['from'],
			'endDate'    => $range['to'],
			'dimensions' => array_map( array( self::class, 'enum_dimension' ), $dimensions ),
			'rowLimit'   => (int) $limit,
			'startRow'   => (int) $offset,
		);
		foreach ( array(
			'type'            => array( array( 'type', 'search_type', 'searchType' ), array( 'WEB', 'IMAGE', 'VIDEO', 'NEWS', 'DISCOVER', 'GOOGLE_NEWS' ) ),
			'dataState'       => array( array( 'data_state', 'dataState' ), array( 'FINAL', 'ALL', 'HOURLY_ALL' ) ),
			'aggregationType' => array( array( 'aggregation_type', 'aggregationType' ), array( 'AUTO', 'BY_PROPERTY', 'BY_PAGE', 'BY_NEWS_SHOWCASE_PANEL' ) ),
		) as $target => $definition ) {
			foreach ( $definition[0] as $alias ) {
				if ( ! isset( $input[ $alias ] ) ) {
					continue;
				}
				$value = self::enum_value( $input[ $alias ] );
				if ( ! in_array( $value, $definition[1], true ) ) {
					return self::error( $target . ' inválido. Valores: ' . implode( ', ', $definition[1] ) . '.' );
				}
				$body[ $target ] = $value;
				break;
			}
		}
		if ( in_array( 'hour', $dimensions, true ) && 'HOURLY_ALL' !== ( $body['dataState'] ?? '' ) ) {
			return self::error( 'A dimensão hour exige data_state=hourly_all; a Google disponibiliza até 10 dias de dados horários.' );
		}
		$groups = $input['dimension_filter_groups'] ?? ( $input['dimensionFilterGroups'] ?? array() );
		$groups = self::native_filter_groups( $groups );
		if ( is_wp_error( $groups ) ) {
			return $groups;
		}
		if ( ! empty( $input['filters'] ) ) {
			$filters = Filters::normalize( $input['filters'] );
			if ( is_wp_error( $filters ) ) {
				return $filters;
			}
			$translated = self::translate_filters( $filters );
			if ( is_wp_error( $translated ) ) {
				return $translated;
			}
			if ( ! empty( $translated['local'] ) ) {
				return self::error( 'A API Search Console aceita filtros de dimensão. Use google/query para filtros locais de métricas na página retornada.' );
			}
			if ( ! empty( $translated['native'] ) ) {
				$groups[] = array(
					'groupType' => 'AND',
					'filters'   => $translated['native'],
				);
			}
		}
		if ( ! empty( $groups ) ) {
			$body['dimensionFilterGroups'] = $groups;
		}
		if ( 'BY_PROPERTY' === ( $body['aggregationType'] ?? '' ) ) {
			$has_page = in_array( 'page', $dimensions, true );
			foreach ( $groups as $group ) {
				foreach ( $group['filters'] as $filter ) {
					$has_page = $has_page || 'PAGE' === $filter['dimension'];
				}
			}
			if ( $has_page ) {
				return self::error( 'aggregation_type=byProperty não pode agrupar ou filtrar por page. Use auto ou byPage.' );
			}
		}
		return $body;
	}

	/** @return array|\WP_Error Resposta original da API. */
	public static function query( array $input ) {
		$site = self::site( $input['site_url'] ?? '' );
		if ( is_wp_error( $site ) ) {
			return $site;
		}
		$body = self::body( $input );
		if ( is_wp_error( $body ) ) {
			return $body;
		}
		return ExecuteAction::call( 'search-console', 'webmasters.searchanalytics.query', array( 'siteUrl' => $site ), array(), $body, array( 'mode' => 'read' ) );
	}

	/** Mantém URLs de propriedade exatamente como cadastradas na Google. */
	public static function site( $value ) {
		if ( ! is_string( $value ) || '' === trim( $value ) || preg_match( '/[\x00-\x20]/', $value ) ) {
			return self::error( 'Informe site_url: URL exata da propriedade ou sc-domain:dominio.com.' );
		}
		if ( 0 === strpos( $value, 'sc-domain:' ) ) {
			$domain = substr( $value, 10 );
			if ( preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $domain ) ) {
				return $value;
			}
			return self::error( 'Propriedade de domínio inválida. Use sc-domain:dominio.com, sem protocolo ou caminho.' );
		}
		$parts = wp_parse_url( $value );
		if ( false === $parts || empty( $parts['host'] ) || ! in_array( $parts['scheme'] ?? '', array( 'http', 'https' ), true ) || isset( $parts['user'] ) || isset( $parts['fragment'] ) ) {
			return self::error( 'site_url deve ser URL http/https sem credenciais/fragmento ou sc-domain:dominio.com.' );
		}
		return $value;
	}

	/** Consulta multi-conta, com comparação e sem somar CTR/posição média. */
	public static function unified( array $input ): array {
		$gate = Gate::check( 'gsc' );
		if ( null !== $gate ) {
			return is_wp_error( $gate ) ? Response::fail( $gate ) : $gate;
		}
		$selectors = $input['accounts'] ?? ( $input['account_id'] ?? ( $input['site_url'] ?? array() ) );
		$selectors = is_string( $selectors ) ? array( $selectors ) : $selectors;
		if ( ! is_array( $selectors ) || array() === $selectors ) {
			return Response::fail( self::error( 'Informe accounts com URLs, sc-domain:dominio.com, nomes únicos ou ["*"].' ) );
		}
		$accounts   = Accounts::resolve_many( 'search-console', $selectors );
		$dimensions = self::field_list( $input['dimensions'] ?? array(), self::DIMENSIONS );
		$metrics    = self::field_list( $input['metrics'] ?? self::METRICS, self::METRICS );
		$range      = DateRange::resolve( $input['date_range'] ?? null );
		$filters    = Filters::normalize( $input['filters'] ?? array() );
		foreach ( array( $accounts, $dimensions, $metrics, $range, $filters ) as $result ) {
			if ( is_wp_error( $result ) ) {
				return Response::fail( $result );
			}
		}
		if ( array() === $metrics ) {
			return Response::fail( self::error( 'Informe ao menos uma métrica: clicks, impressions, ctr, position.' ) );
		}
		$translated = self::translate_filters( $filters );
		if ( is_wp_error( $translated ) ) {
			return Response::fail( $translated );
		}
		$ranges = array( 'current' => $range );
		if ( ! empty( $input['compare_date_range'] ) ) {
			$compare = DateRange::compare( $range, $input['compare_date_range'] );
			if ( is_wp_error( $compare ) ) {
				return Response::fail( $compare );
			}
			$ranges['previous'] = $compare;
		}
		$limit = $input['limit'] ?? Options::max_rows();
		if ( ! self::integer( $limit, 1, self::MAX_ROWS ) ) {
			return Response::fail( self::error( 'limit deve ser inteiro entre 1 e 25.000.' ) );
		}
		$effective_limit = min( (int) $limit, Options::max_rows(), self::MAX_ROWS );
		$warnings        = array( 'Search Console fornece as principais linhas, não garante todas as consultas; consultas anonimizadas podem ser omitidas. Datas e horas de origem usam America/Los_Angeles.' );
		if ( (int) $limit > $effective_limit ) {
			$warnings[] = 'limit foi reduzido ao limite configurado do plugin: ' . $effective_limit . '.';
		}
		if ( ! empty( $translated['local'] ) ) {
			$warnings[] = 'Filtros de métricas foram aplicados localmente somente à página retornada pela Google; não são filtros nativos da Search Console.';
		}
		$order = self::ordering( $input['order_by'] ?? ( $input['order_bys'] ?? array() ), array_merge( $dimensions, $metrics ) );
		if ( is_wp_error( $order ) ) {
			return Response::fail( $order );
		}
		if ( ! empty( $order ) ) {
			$warnings[] = 'Ordenação aplicada localmente somente à página retornada pela API; ela não altera quais linhas a Google selecionou.';
		}
		$multi   = count( $accounts ) > 1;
		$columns = array();
		if ( isset( $ranges['previous'] ) ) {
			$columns[] = array(
				'id'    => 'date_range_name',
				'label' => 'Período',
				'type'  => 'meta',
				'kind'  => 'string',
			);
		}
		if ( $multi ) {
			$columns[] = array(
				'id'    => 'account_id',
				'label' => 'ID da conta',
				'type'  => 'meta',
				'kind'  => 'string',
			);
			$columns[] = array(
				'id'    => 'account_name',
				'label' => 'Conta',
				'type'  => 'meta',
				'kind'  => 'string',
			);
		}
		$catalog = array_column( self::fields(), null, 'id' );
		foreach ( array_merge( $dimensions, $metrics ) as $field ) {
			$columns[] = $catalog[ $field ];
		}
		$rows       = array();
		$successful = array();
		$requests   = array();
		$truncated  = (int) $limit > $effective_limit;
		foreach ( $accounts as $account ) {
			foreach ( $ranges as $range_name => $dates ) {
				$native_input               = $input;
				$native_input['site_url']   = $account;
				$native_input['date_range'] = array(
					'from' => $dates['from'],
					'to'   => $dates['to'],
				);
				$native_input['row_limit']  = $effective_limit;
				$native_input['dimensions'] = $dimensions;
				unset( $native_input['filters'] );
				if ( ! empty( $translated['native'] ) ) {
					$native_input['dimension_filter_groups'] = array_merge(
						(array) ( $native_input['dimension_filter_groups'] ?? ( $native_input['dimensionFilterGroups'] ?? array() ) ),
						array(
							array(
								'groupType' => 'AND',
								'filters'   => $translated['native'],
							),
						)
					);
				}
				$response = self::query( $native_input );
				if ( is_wp_error( $response ) ) {
					$warnings[] = $account . ' (' . $range_name . '): ' . $response->get_error_message();
					continue;
				}
				$successful[ $account ] = array(
					'account_id' => $account,
					'name'       => $account,
				);
				$raw_rows               = isset( $response['rows'] ) && is_array( $response['rows'] ) ? $response['rows'] : array();
				$offset                 = (int) ( $input['start_row'] ?? ( $input['startRow'] ?? ( $input['offset'] ?? 0 ) ) );
				$has_more               = count( $raw_rows ) >= $effective_limit;
				$truncated              = $truncated || $has_more;
				$requests[]             = array(
					'account_id'                => $account,
					'date_range_name'           => $range_name,
					'date_range'                => $dates,
					'start_row'                 => $offset,
					'row_limit'                 => $effective_limit,
					'rows_received'             => count( $raw_rows ),
					'next_start_row'            => $has_more ? $offset + count( $raw_rows ) : null,
					'metadata'                  => $response['metadata'] ?? array(),
					'response_aggregation_type' => $response['responseAggregationType'] ?? null,
				);
				$records                = array();
				foreach ( $raw_rows as $native_row ) {
					$record = array();
					foreach ( $dimensions as $position => $dimension ) {
						$record[ $dimension ] = (string) ( $native_row['keys'][ $position ] ?? '' );
					}
					foreach ( self::METRICS as $metric ) {
						$record[ $metric ] = isset( $native_row[ $metric ] ) && is_numeric( $native_row[ $metric ] ) ? $native_row[ $metric ] + 0 : null;
					}
					if ( self::matches_metrics( $record, $translated['local'] ) ) {
						$records[] = $record;
					}
				}
				if ( ! empty( $order ) ) {
					usort(
						$records,
						static function ( array $left, array $right ) use ( $order ): int {
							foreach ( $order as $ordering ) {
								$comparison = ( $left[ $ordering['field'] ] ?? null ) <=> ( $right[ $ordering['field'] ] ?? null );
								if ( 0 !== $comparison ) {
									return 'asc' === $ordering['direction'] ? $comparison : -$comparison;
								}
							}
							return 0;
						}
					);
				}
				foreach ( $records as $record ) {
					$row = isset( $ranges['previous'] ) ? array( $range_name ) : array();
					if ( $multi ) {
						$row[] = $account;
						$row[] = $account;
					}
					foreach ( array_merge( $dimensions, $metrics ) as $field ) {
						$row[] = $record[ $field ];
					}
					$rows[] = $row;
				}
			}
		}
		if ( empty( $successful ) ) {
			return Response::fail( new \WP_Error( 'f3_google_query_failed', 'Nenhuma propriedade Search Console respondeu com sucesso. ' . implode( ' | ', $warnings ) ), array( 'warnings' => $warnings ) );
		}
		$data = array(
			'connector'     => 'search-console',
			'columns'       => $columns,
			'rows'          => $rows,
			'row_count'     => count( $rows ),
			'accounts'      => array_values( $successful ),
			'warnings'      => $warnings,
			'truncated'     => $truncated,
			'date_range'    => $range,
			'request'       => $requests,
			'data_timezone' => 'America/Los_Angeles',
		);
		if ( isset( $ranges['previous'] ) ) {
			$data['compare_date_range'] = $ranges['previous'];
		}
		return Response::ok( $data, count( $rows ) . ' linha(s) de ' . count( $successful ) . ' propriedade(s) Search Console.' );
	}

	/** @return array|\WP_Error */
	public static function field_list( $value, array $allowed ) {
		if ( is_string( $value ) ) {
			$value = '' === trim( $value ) ? array() : explode( ',', $value );
		}
		if ( ! is_array( $value ) ) {
			return self::error( 'Dimensões e métricas devem ser listas de nomes.' );
		}
		$out = array();
		foreach ( $value as $item ) {
			$item      = is_array( $item ) ? ( $item['id'] ?? ( $item['name'] ?? '' ) ) : $item;
			$canonical = self::field( $item );
			if ( ! in_array( $canonical, $allowed, true ) ) {
				return self::error( 'Campo Search Console inválido: ' . ( is_scalar( $item ) ? (string) $item : '(objeto)' ) . '. Valores: ' . implode( ', ', $allowed ) . '.' );
			}
			if ( ! in_array( $canonical, $out, true ) ) {
				$out[] = $canonical;
			}
		}
		return $out;
	}

	private static function field( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}
		$key = strtolower( str_replace( '_', '', trim( $value ) ) );
		return 'searchappearance' === $key ? 'searchAppearance' : $key;
	}

	public static function enum_dimension( string $value ): string {
		return 'searchAppearance' === $value ? 'SEARCH_APPEARANCE' : strtoupper( $value );
	}

	private static function enum_value( $value ): string {
		return is_string( $value ) ? strtoupper( (string) preg_replace( '/([a-z])([A-Z])/', '$1_$2', trim( $value ) ) ) : '';
	}

	private static function integer( $value, int $minimum, int $maximum ): bool {
		return ! is_bool( $value ) && is_numeric( $value ) && is_finite( (float) $value ) && floor( (float) $value ) === (float) $value && $value >= $minimum && $value <= $maximum;
	}

	private static function native_filter_groups( $groups ) {
		if ( ! is_array( $groups ) ) {
			return self::error( 'dimension_filter_groups deve ser uma lista de grupos AND.' );
		}
		$out = array();
		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) || 'AND' !== self::enum_value( $group['groupType'] ?? ( $group['group_type'] ?? 'AND' ) ) || ! isset( $group['filters'] ) || ! is_array( $group['filters'] ) ) {
				return self::error( 'Search Console aceita grupos de filtros AND com filters como lista.' );
			}
			$clean = array();
			foreach ( $group['filters'] as $filter ) {
				if ( ! is_array( $filter ) ) {
					return self::error( 'Cada filtro nativo precisa de dimension, operator e expression.' );
				}
				$dimension = self::field( $filter['dimension'] ?? '' );
				$operator  = self::enum_value( $filter['operator'] ?? 'EQUALS' );
				if ( ! in_array( $dimension, array( 'query', 'page', 'country', 'device', 'searchAppearance' ), true ) || ! in_array( $operator, array( 'EQUALS', 'NOT_EQUALS', 'CONTAINS', 'NOT_CONTAINS', 'INCLUDING_REGEX', 'EXCLUDING_REGEX' ), true ) || ! isset( $filter['expression'] ) || ! is_string( $filter['expression'] ) || strlen( $filter['expression'] ) > 4096 ) {
					return self::error( 'Filtro Search Console inválido: use dimensão suportada, operador nativo e expressão string de até 4096 bytes.' );
				}
				$clean[] = array(
					'dimension'  => self::enum_dimension( $dimension ),
					'operator'   => $operator,
					'expression' => $filter['expression'],
				);
			}
			$out[] = array(
				'groupType' => 'AND',
				'filters'   => $clean,
			);
		}
		return $out;
	}

	private static function translate_filters( array $filters ) {
		$native = array();
		$local  = array();
		foreach ( $filters as $filter ) {
			$field    = self::field( $filter['field'] );
			$operator = $filter['operator'];
			$value    = $filter['value'];
			if ( in_array( $field, self::METRICS, true ) ) {
				if ( ! in_array( $operator, array( 'eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'null', 'notnull' ), true ) || ( ! in_array( $operator, array( 'null', 'notnull' ), true ) && ( ! is_numeric( $value ) || is_bool( $value ) ) ) ) {
					return self::error( 'Filtro de métrica Search Console deve usar comparação numérica ou null/notnull.' );
				}
				$filter['field'] = $field;
				$local[]         = $filter;
				continue;
			}
			if ( ! in_array( $field, array( 'query', 'page', 'country', 'device', 'searchAppearance' ), true ) ) {
				return self::error( 'Não há filtro nativo para ' . $field . '. Datas são limitadas por date_range.' );
			}
			$map = array(
				'eq'        => 'EQUALS',
				'neq'       => 'NOT_EQUALS',
				'contains'  => 'CONTAINS',
				'ncontains' => 'NOT_CONTAINS',
				'regex'     => 'INCLUDING_REGEX',
			);
			if ( isset( $map[ $operator ] ) && is_scalar( $value ) && ! is_bool( $value ) ) {
				$translated = $map[ $operator ];
				$expression = (string) $value;
			} elseif ( in_array( $operator, array( 'begins_with', 'ends_with' ), true ) && is_scalar( $value ) && ! is_bool( $value ) ) {
				$translated = 'INCLUDING_REGEX';
				$expression = 'begins_with' === $operator ? '^' . self::quote_re2( (string) $value ) : self::quote_re2( (string) $value ) . '$';
			} elseif ( 'in' === $operator && is_array( $value ) && ! empty( $value ) ) {
				$parts = array();
				foreach ( $value as $item ) {
					if ( ! is_scalar( $item ) || is_bool( $item ) ) {
						return self::error( 'Filtro in deve conter somente strings/números.' );
					}
					$parts[] = self::quote_re2( (string) $item );
				}
				$translated = 'INCLUDING_REGEX';
				$expression = '^(?:' . implode( '|', $parts ) . ')$';
			} elseif ( in_array( $operator, array( 'null', 'notnull' ), true ) ) {
				$translated = 'null' === $operator ? 'EQUALS' : 'NOT_EQUALS';
				$expression = '';
			} else {
				return self::error( 'Operador ' . $operator . ' não é suportado para dimensões Search Console.' );
			}
			if ( strlen( $expression ) > 4096 ) {
				return self::error( 'Expressão de filtro Search Console excede 4096 bytes.' );
			}
			$native[] = array(
				'dimension'  => self::enum_dimension( $field ),
				'operator'   => $translated,
				'expression' => $expression,
			);
		}
		return array(
			'native' => $native,
			'local'  => $local,
		);
	}

	/** RE2 recebe expressão sem delimitadores PHP: só os metacaracteres são escapados. */
	private static function quote_re2( string $value ): string {
		return preg_quote( $value, '' );
	}

	private static function matches_metrics( array $record, array $filters ): bool {
		foreach ( $filters as $filter ) {
			$actual = $record[ $filter['field'] ] ?? null;
			$value  = $filter['value'];
			switch ( $filter['operator'] ) {
				case 'null':
					$matches = null === $actual;
					break;
				case 'notnull':
					$matches = null !== $actual;
					break;
				case 'eq':
					$matches = null !== $actual && (float) $actual === (float) $value;
					break;
				case 'neq':
					$matches = null !== $actual && (float) $actual !== (float) $value;
					break;
				case 'gt':
					$matches = null !== $actual && $actual > $value;
					break;
				case 'gte':
					$matches = null !== $actual && $actual >= $value;
					break;
				case 'lt':
					$matches = null !== $actual && $actual < $value;
					break;
				case 'lte':
					$matches = null !== $actual && $actual <= $value;
					break;
				default:
					$matches = false;
			}
			if ( ! $matches ) {
				return false;
			}
		}
		return true;
	}

	private static function ordering( $value, array $fields ) {
		if ( null === $value || '' === $value || array() === $value ) {
			return array();
		}
		$value = is_string( $value ) ? array( $value ) : $value;
		$value = is_array( $value ) && isset( $value['field'] ) ? array( $value ) : $value;
		if ( ! is_array( $value ) ) {
			return self::error( 'order_by deve ser lista de {field,direction}.' );
		}
		$out = array();
		foreach ( $value as $item ) {
			$item = is_string( $item ) ? array( 'field' => $item ) : $item;
			if ( ! is_array( $item ) ) {
				return self::error( 'Cada ordenação deve informar field e direction.' );
			}
			$field     = self::field( $item['field'] ?? '' );
			$direction = is_string( $item['direction'] ?? null ) ? strtolower( $item['direction'] ) : 'desc';
			if ( ! in_array( $field, $fields, true ) || ! in_array( $direction, array( 'asc', 'desc' ), true ) ) {
				return self::error( 'Ordenação deve referenciar campo selecionado, com direction asc ou desc.' );
			}
			$out[] = array(
				'field'     => $field,
				'direction' => $direction,
			);
		}
		return $out;
	}

	private static function error( string $message ): \WP_Error {
		return new \WP_Error( 'f3_google_gsc_input', $message );
	}
}
