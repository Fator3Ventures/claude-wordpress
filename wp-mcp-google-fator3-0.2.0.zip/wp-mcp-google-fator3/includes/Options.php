<?php
/**
 * Nomes e leitura/gravação das opções do plugin.
 *
 * Toda opção mora aqui por dois motivos. O primeiro é banal: um único lugar
 * para o `uninstall.php` e para o filtro `wp_mcp_ultimate_protected_options`
 * saberem o que existe. O segundo é a razão de o arquivo ser maior do que
 * parece necessário — os segredos.
 *
 * Este site expõe o banco e as opções por MCP (`db/query` do WP MCP Fator3,
 * `options/get` do WP MCP Ultimate). Um agente com essas rotas leria a chave da
 * service account com uma chamada. Por isso a chave, o client secret, o refresh
 * token e o developer token são gravados cifrados (ver `Crypto`) e, além disso,
 * um filtro `pre_option_*` faz `get_option()` devolver vazio para eles: nem o
 * blob cifrado sai daqui. A trava só se abre pelo tempo exato de uma leitura
 * feita pelo próprio plugin, em `get_secret()`.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Options {

	public const ENABLED               = 'f3_mcp_google_enabled';
	public const GA_ENABLED            = 'f3_mcp_google_ga_enabled';
	public const ADS_ENABLED           = 'f3_mcp_google_ads_enabled';
	public const AUTH_MODE             = 'f3_mcp_google_auth_mode';
	public const SA_JSON               = 'f3_mcp_google_sa_json';
	public const SA_SUBJECT            = 'f3_mcp_google_sa_subject';
	public const OAUTH_CLIENT_ID       = 'f3_mcp_google_oauth_client_id';
	public const OAUTH_CLIENT_SECRET   = 'f3_mcp_google_oauth_client_secret';
	public const OAUTH_REFRESH_TOKEN   = 'f3_mcp_google_oauth_refresh_token';
	public const OAUTH_EMAIL           = 'f3_mcp_google_oauth_email';
	public const OAUTH_SCOPES          = 'f3_mcp_google_oauth_scopes';
	public const ADS_DEVELOPER_TOKEN   = 'f3_mcp_google_ads_developer_token';
	public const ADS_LOGIN_CUSTOMER_ID = 'f3_mcp_google_ads_login_customer_id';
	public const ADS_API_VERSION       = 'f3_mcp_google_ads_api_version';
	public const GA_DEFAULT_PROPERTY   = 'f3_mcp_google_ga_default_property';
	public const MAX_ROWS              = 'f3_mcp_google_max_rows';
	public const HTTP_TIMEOUT          = 'f3_mcp_google_http_timeout';
	public const AUDIT                 = 'f3_mcp_google_audit';

	/**
	 * Índice das chaves de transient onde há token em cache.
	 *
	 * Existe porque não dá para enumerar transients sem SQL: quando a
	 * credencial muda, `Credentials::invalidate_cache()` precisa saber quais
	 * apagar, senão um token da credencial antiga continuaria valendo por até
	 * uma hora.
	 */
	public const TOKEN_INDEX = 'f3_mcp_google_token_index';

	/**
	 * A trava dos segredos está aberta?
	 *
	 * Contador, não booleano: `set_secret()` chama `update_option()`, que por
	 * dentro chama `get_option()`, e uma leitura aninhada não pode fechar a
	 * trava que a de fora abriu.
	 */
	private static int $unlocked = 0;

	/**
	 * Liga o filtro que esconde os segredos de qualquer `get_option()`.
	 */
	public static function init(): void {
		foreach ( self::secret_names() as $name ) {
			add_filter( 'pre_option_' . $name, array( self::class, 'hide_secret' ), 10, 3 );
		}
	}

	/**
	 * Filtro `pre_option_*`: devolve string vazia (curto-circuito) enquanto a
	 * trava estiver fechada, e deixa passar quando o próprio plugin está lendo.
	 *
	 * @param mixed  $pre           Valor de curto-circuito atual.
	 * @param string $option        Nome da opção.
	 * @param mixed  $default_value Valor padrão pedido pelo chamador.
	 * @return mixed
	 */
	public static function hide_secret( $pre, $option = '', $default_value = false ) {
		unset( $option, $default_value );
		if ( self::$unlocked > 0 ) {
			return $pre;
		}

		return '';
	}

	/**
	 * Executa uma leitura/gravação com a trava aberta.
	 *
	 * @param callable $callback Trecho que precisa enxergar o valor cifrado.
	 * @return mixed
	 */
	private static function unlocked( callable $callback ) {
		++self::$unlocked;
		try {
			return $callback();
		} finally {
			--self::$unlocked;
		}
	}

	/**
	 * @return string[]
	 */
	public static function all_names(): array {
		return array(
			self::ENABLED,
			self::GA_ENABLED,
			self::ADS_ENABLED,
			self::AUTH_MODE,
			self::SA_JSON,
			self::SA_SUBJECT,
			self::OAUTH_CLIENT_ID,
			self::OAUTH_CLIENT_SECRET,
			self::OAUTH_REFRESH_TOKEN,
			self::OAUTH_EMAIL,
			self::OAUTH_SCOPES,
			self::ADS_DEVELOPER_TOKEN,
			self::ADS_LOGIN_CUSTOMER_ID,
			self::ADS_API_VERSION,
			self::GA_DEFAULT_PROPERTY,
			self::MAX_ROWS,
			self::HTTP_TIMEOUT,
			self::AUDIT,
			self::TOKEN_INDEX,
		);
	}

	/**
	 * Opções que guardam segredo: cifradas em repouso e invisíveis a
	 * `get_option()`.
	 *
	 * @return string[]
	 */
	public static function secret_names(): array {
		return array(
			self::SA_JSON,
			self::OAUTH_CLIENT_SECRET,
			self::OAUTH_REFRESH_TOKEN,
			self::ADS_DEVELOPER_TOKEN,
		);
	}

	/**
	 * Autoload só para o que é lido em toda requisição.
	 *
	 * O log de auditoria e os segredos ficam de fora: o log é grande e os
	 * segredos não devem entrar no cache `alloptions`.
	 */
	private static function autoload_for( string $name ): bool {
		if ( self::AUDIT === $name || self::TOKEN_INDEX === $name ) {
			return false;
		}

		return ! in_array( $name, self::secret_names(), true );
	}

	/**
	 * @param string $name    Nome da opção.
	 * @param mixed  $default Valor devolvido quando ausente.
	 * @return mixed
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.defaultFound -- Preserva argumento nomeado público da 0.1.0.
	public static function get( string $name, $default = null ) {
		return get_option( $name, $default );
	}

	/**
	 * @param string $name  Nome da opção.
	 * @param mixed  $value Valor.
	 */
	public static function set( string $name, $value ): void {
		$autoload = self::autoload_for( $name );
		self::unlocked(
			static function () use ( $name, $value, $autoload ) {
				return update_option( $name, $value, $autoload );
			}
		);
	}

	public static function delete( string $name ): void {
		self::unlocked(
			static function () use ( $name ) {
				return delete_option( $name );
			}
		);
	}

	/**
	 * Lê um segredo já decifrado.
	 *
	 * Devolve '' quando ausente ou quando a decifra falha — o que acontece, por
	 * exemplo, se as salts do `wp-config.php` forem trocadas. Falha silenciosa
	 * aqui é proposital: quem chama trata "sem credencial", e a tela de
	 * administração mostra o estado.
	 */
	public static function get_secret( string $name ): string {
		$stored = self::unlocked(
			static function () use ( $name ) {
				return get_option( $name, '' );
			}
		);

		if ( ! is_string( $stored ) || '' === $stored ) {
			return '';
		}

		$plain = Crypto::decrypt( $stored );

		return is_wp_error( $plain ) ? '' : (string) $plain;
	}

	/**
	 * Grava um segredo cifrado. String vazia apaga a opção.
	 */
	public static function set_secret( string $name, string $plain ): void {
		if ( '' === $plain ) {
			self::delete( $name );
			return;
		}

		$cipher = Crypto::encrypt( $plain );

		// Sem backend de cifra não se grava em claro: melhor ficar sem
		// credencial do que deixar a chave privada legível na tabela options.
		if ( '' === $cipher ) {
			return;
		}

		self::unlocked(
			static function () use ( $name, $cipher ) {
				return update_option( $name, $cipher, false );
			}
		);
	}

	public static function has_secret( string $name ): bool {
		return '' !== self::get_secret( $name );
	}

	/**
	 * Kill switch geral. O filtro tem a última palavra.
	 */
	public static function is_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_google_enabled', (bool) self::get( self::ENABLED, false ) );
	}

	public static function ga_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_google_ga_enabled', (bool) self::get( self::GA_ENABLED, false ) );
	}

	public static function ads_enabled(): bool {
		return (bool) apply_filters( 'f3_mcp_google_ads_enabled', (bool) self::get( self::ADS_ENABLED, false ) );
	}

	/**
	 * @return string 'service_account' ou 'oauth'.
	 */
	public static function auth_mode(): string {
		$mode = (string) self::get( self::AUTH_MODE, 'service_account' );
		if ( ! in_array( $mode, array( 'service_account', 'oauth' ), true ) ) {
			$mode = 'service_account';
		}

		$mode = (string) apply_filters( 'f3_mcp_google_auth_mode', $mode );

		return in_array( $mode, array( 'service_account', 'oauth' ), true ) ? $mode : 'service_account';
	}

	/**
	 * Versão da Google Ads API.
	 *
	 * Fica em opção porque o Google encerra versões a cada ~12 meses e o site
	 * não pode depender de uma atualização do plugin para voltar a funcionar.
	 * O formato é validado porque este valor entra na URL.
	 */
	public static function ads_api_version(): string {
		$version = (string) self::get( self::ADS_API_VERSION, 'v25' );
		$version = (string) apply_filters( 'f3_mcp_google_ads_api_version', $version );

		return preg_match( '/^v\d{1,3}$/', $version ) ? $version : 'v25';
	}

	/**
	 * @return string Só dígitos, ou ''.
	 */
	public static function ads_login_customer_id(): string {
		$id = preg_replace( '/\D+/', '', (string) self::get( self::ADS_LOGIN_CUSTOMER_ID, '' ) );

		return is_string( $id ) ? $id : '';
	}

	/**
	 * Teto de linhas por relatório. 10.000 é limite absoluto: acima disso a
	 * resposta estoura a janela de contexto de quem chamou.
	 */
	public static function max_rows(): int {
		$rows = (int) self::get( self::MAX_ROWS, 1000 );
		$rows = (int) apply_filters( 'f3_mcp_google_max_rows', $rows );

		return max( 1, min( 10000, $rows ) );
	}

	public static function http_timeout(): int {
		$timeout = (int) self::get( self::HTTP_TIMEOUT, 30 );
		$timeout = (int) apply_filters( 'f3_mcp_google_http_timeout', $timeout );

		return max( 5, min( 120, $timeout ) );
	}

	/**
	 * Capacidade exigida em toda habilidade.
	 *
	 * `manage_options` por padrão: quem lê Analytics e Ads pelo agente é o
	 * administrador do site, e o mínimo que o WP MCP Ultimate exige
	 * (`edit_posts`) alcançaria qualquer editor.
	 */
	public static function capability(): string {
		$capability = (string) apply_filters( 'f3_mcp_google_capability', 'manage_options' );

		return '' !== $capability ? $capability : 'manage_options';
	}
}
