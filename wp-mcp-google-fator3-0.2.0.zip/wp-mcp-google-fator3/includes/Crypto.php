<?php
/**
 * Cifra dos segredos em repouso.
 *
 * A chave da service account, o client secret, o refresh token e o developer
 * token ficam na tabela `options`, que neste site é alcançável por MCP
 * (`db/query`, `options/get`). Cifrar não protege contra quem já executa PHP no
 * servidor — a chave de cifra sai das salts do `wp-config.php`, que estão ali
 * do lado. Protege contra o caso realista: um agente lendo a tabela, um dump de
 * banco, um backup que vaza. É a diferença entre uma chave privada em texto
 * puro e um blob inútil sem o `wp-config.php`.
 *
 * Dois backends porque nem toda hospedagem tem libsodium: sodium quando existe,
 * AES-256-GCM via OpenSSL como reserva. O prefixo do texto gravado diz qual
 * gerou a cifra, então trocar de backend (ou migrar de servidor) não
 * inutiliza o que já está gravado, desde que o backend antigo ainda exista.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Crypto {

	/** Versão do formato gravado; muda se o esquema mudar. */
	private const VERSION = 'v1';

	/** Tamanho da tag de autenticação do AES-GCM. */
	private const GCM_TAG_BYTES = 16;

	/** Tamanho do IV do AES-GCM (o recomendado pelo NIST). */
	private const GCM_IV_BYTES = 12;

	public static function available(): bool {
		return 'none' !== self::backend();
	}

	/**
	 * @return string 'sodium' | 'openssl' | 'none'
	 */
	public static function backend(): string {
		$backend = self::detect();

		// Filtro existe para o autoteste conseguir exercitar os dois caminhos
		// no mesmo servidor; forçar um backend indisponível não é aceito.
		$forced = (string) apply_filters( 'f3_mcp_google_crypto_backend', $backend );
		if ( $forced !== $backend && self::supports( $forced ) ) {
			return $forced;
		}

		return $backend;
	}

	private static function detect(): string {
		if ( self::supports( 'sodium' ) ) {
			return 'sodium';
		}

		if ( self::supports( 'openssl' ) ) {
			return 'openssl';
		}

		return 'none';
	}

	private static function supports( string $backend ): bool {
		if ( 'sodium' === $backend ) {
			return function_exists( 'sodium_crypto_secretbox' )
				&& function_exists( 'sodium_crypto_secretbox_open' )
				&& defined( 'SODIUM_CRYPTO_SECRETBOX_NONCEBYTES' );
		}

		if ( 'openssl' === $backend ) {
			return function_exists( 'openssl_encrypt' )
				&& function_exists( 'openssl_decrypt' )
				&& in_array( 'aes-256-gcm', array_map( 'strtolower', (array) openssl_get_cipher_methods() ), true );
		}

		return false;
	}

	/**
	 * Chave de 32 bytes derivada das salts do site.
	 *
	 * Trocar as salts torna os segredos ilegíveis — de propósito: é o mesmo
	 * efeito de trocar as senhas, e a tela de administração pede a credencial
	 * de novo em vez de decifrar lixo.
	 */
	private static function key(): string {
		return hash( 'sha256', wp_salt( 'auth' ) . '|' . wp_salt( 'secure_auth' ) . '|f3-mcp-google', true );
	}

	/**
	 * @return string Texto seguro para gravar em option, ou '' se não há backend.
	 */
	public static function encrypt( string $plain ): string {
		$backend = self::backend();
		$key     = self::key();

		if ( 'sodium' === $backend ) {
			$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = sodium_crypto_secretbox( $plain, $nonce, $key );

			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
			return self::VERSION . ':sodium:' . base64_encode( $nonce ) . ':' . base64_encode( $cipher );
		}

		if ( 'openssl' === $backend ) {
			$iv  = random_bytes( self::GCM_IV_BYTES );
			$tag = '';

			$cipher = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', self::GCM_TAG_BYTES );
			if ( false === $cipher ) {
				return '';
			}

			// Tag no fim do texto cifrado: um só campo para gravar e conferir.
			// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
			return self::VERSION . ':openssl:' . base64_encode( $iv ) . ':' . base64_encode( $cipher . $tag );
		}

		return '';
	}

	/**
	 * @param string $stored Texto produzido por encrypt().
	 * @return string|\WP_Error
	 */
	public static function decrypt( string $stored ) {
		$parts = explode( ':', $stored, 4 );

		if ( 4 !== count( $parts ) || self::VERSION !== $parts[0] ) {
			return new \WP_Error(
				'f3_google_crypto',
				__( 'O segredo gravado não está no formato esperado.', 'wp-mcp-google-fator3' )
			);
		}

		$backend = $parts[1];
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		$nonce = base64_decode( $parts[2], true );
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		$cipher = base64_decode( $parts[3], true );

		if ( false === $nonce || false === $cipher ) {
			return new \WP_Error( 'f3_google_crypto', __( 'O segredo gravado está corrompido.', 'wp-mcp-google-fator3' ) );
		}

		if ( ! self::supports( $backend ) ) {
			return new \WP_Error(
				'f3_google_crypto',
				sprintf(
					/* translators: %s: nome do backend de cifra. */
					__( 'O segredo foi cifrado com %s, que não está disponível neste servidor.', 'wp-mcp-google-fator3' ),
					$backend
				)
			);
		}

		$key = self::key();

		if ( 'sodium' === $backend ) {
			if ( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES !== strlen( $nonce ) ) {
				return new \WP_Error( 'f3_google_crypto', __( 'O segredo gravado está corrompido.', 'wp-mcp-google-fator3' ) );
			}

			$plain = sodium_crypto_secretbox_open( $cipher, $nonce, $key );

			return false === $plain
				? new \WP_Error( 'f3_google_crypto', __( 'Não foi possível decifrar o segredo (as salts do wp-config.php mudaram?).', 'wp-mcp-google-fator3' ) )
				: $plain;
		}

		// O IV precisa ter o tamanho exato: `openssl_decrypt()` com um IV de
		// outro tamanho emite um aviso do PHP antes de devolver false, e um
		// aviso disparado por um blob adulterado acabaria no log de erros do
		// site — ou, pior, impresso no meio da tela de administração.
		if ( self::GCM_IV_BYTES !== strlen( $nonce ) || strlen( $cipher ) <= self::GCM_TAG_BYTES ) {
			return new \WP_Error( 'f3_google_crypto', __( 'O segredo gravado está corrompido.', 'wp-mcp-google-fator3' ) );
		}

		$tag  = substr( $cipher, -self::GCM_TAG_BYTES );
		$body = substr( $cipher, 0, -self::GCM_TAG_BYTES );

		$plain = openssl_decrypt( $body, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag );

		return false === $plain
			? new \WP_Error( 'f3_google_crypto', __( 'Não foi possível decifrar o segredo (as salts do wp-config.php mudaram?).', 'wp-mcp-google-fator3' ) )
			: $plain;
	}
}
