<?php
/**
 * Catálogo estático dos recursos consultáveis por GAQL.
 *
 * Lista copiada de `gaql_resources.txt`, o arquivo que o MCP oficial do
 * Google Ads embute na descrição da ferramenta `search` — é a mesma lista que
 * https://developers.google.com/google-ads/api/fields/latest/overview
 * publica, congelada na versão da API que este plugin usa (ver
 * `Options::ads_api_version()`). Fica estática porque a API não tem um
 * endpoint "liste os recursos"; só o `googleAdsFields:search` por campo
 * individual, que é o que `AdsApi::resource_metadata()` consulta depois que o
 * agente já escolheu um recurso daqui.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Ads;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Resources {

	/**
	 * Os 181 recursos GAQL válidos, em ordem alfabética.
	 *
	 * @var string[]
	 */
	private const ALL = array(
		'accessible_bidding_strategy',
		'account_budget',
		'account_budget_proposal',
		'account_link',
		'ad',
		'ad_group',
		'ad_group_ad',
		'ad_group_ad_asset_combination_view',
		'ad_group_ad_asset_view',
		'ad_group_ad_label',
		'ad_group_asset',
		'ad_group_asset_set',
		'ad_group_audience_view',
		'ad_group_bid_modifier',
		'ad_group_criterion',
		'ad_group_criterion_customizer',
		'ad_group_criterion_label',
		'ad_group_criterion_simulation',
		'ad_group_customizer',
		'ad_group_label',
		'ad_group_simulation',
		'ad_parameter',
		'ad_schedule_view',
		'age_range_view',
		'ai_max_search_term_ad_combination_view',
		'android_privacy_shared_key_google_ad_group',
		'android_privacy_shared_key_google_campaign',
		'android_privacy_shared_key_google_network_type',
		'app_top_combination_view',
		'applied_incentive',
		'asset',
		'asset_field_type_view',
		'asset_group',
		'asset_group_asset',
		'asset_group_listing_group_filter',
		'asset_group_product_group_view',
		'asset_group_signal',
		'asset_group_top_combination_view',
		'asset_set',
		'asset_set_asset',
		'asset_set_type_view',
		'audience',
		'batch_job',
		'bidding_data_exclusion',
		'bidding_seasonality_adjustment',
		'bidding_strategy',
		'bidding_strategy_simulation',
		'billing_setup',
		'call_view',
		'campaign',
		'campaign_aggregate_asset_view',
		'campaign_asset',
		'campaign_asset_set',
		'campaign_audience_view',
		'campaign_bid_modifier',
		'campaign_budget',
		'campaign_conversion_goal',
		'campaign_criterion',
		'campaign_customizer',
		'campaign_draft',
		'campaign_goal_config',
		'campaign_group',
		'campaign_label',
		'campaign_search_term_insight',
		'campaign_search_term_view',
		'campaign_shared_set',
		'campaign_simulation',
		'carrier_constant',
		'cart_data_sales_view',
		'change_event',
		'change_status',
		'channel_aggregate_asset_view',
		'click_view',
		'combined_audience',
		'content_criterion_view',
		'conversion_action',
		'conversion_custom_variable',
		'conversion_goal_campaign_config',
		'conversion_value_rule',
		'conversion_value_rule_set',
		'currency_constant',
		'custom_audience',
		'custom_conversion_goal',
		'custom_interest',
		'customer',
		'customer_asset',
		'customer_asset_set',
		'customer_client',
		'customer_client_link',
		'customer_conversion_goal',
		'customer_customizer',
		'customer_label',
		'customer_manager_link',
		'customer_negative_criterion',
		'customer_search_term_insight',
		'customer_user_access',
		'customer_user_access_invitation',
		'customizer_attribute',
		'data_link',
		'detail_content_suitability_placement_view',
		'detail_placement_view',
		'detailed_demographic',
		'display_keyword_view',
		'distance_view',
		'domain_category',
		'dynamic_search_ads_search_term_view',
		'expanded_landing_page_view',
		'experiment',
		'experiment_arm',
		'final_url_expansion_asset_view',
		'gender_view',
		'geo_target_constant',
		'geographic_view',
		'goal',
		'group_content_suitability_placement_view',
		'group_placement_view',
		'hotel_group_view',
		'hotel_performance_view',
		'hotel_reconciliation',
		'income_range_view',
		'keyword_plan',
		'keyword_plan_ad_group',
		'keyword_plan_ad_group_keyword',
		'keyword_plan_campaign',
		'keyword_plan_campaign_keyword',
		'keyword_theme_constant',
		'keyword_view',
		'label',
		'landing_page_view',
		'language_constant',
		'lead_form_submission_data',
		'life_event',
		'local_services_employee',
		'local_services_lead',
		'local_services_lead_conversation',
		'local_services_verification_artifact',
		'location_interest_view',
		'location_view',
		'managed_placement_view',
		'matched_location_interest_view',
		'media_file',
		'mobile_app_category_constant',
		'mobile_device_constant',
		'multi_party_auth_review',
		'offline_conversion_upload_client_summary',
		'offline_conversion_upload_conversion_action_summary',
		'offline_user_data_job',
		'operating_system_version_constant',
		'paid_organic_search_term_view',
		'parental_status_view',
		'per_store_view',
		'performance_max_placement_view',
		'product_category_constant',
		'product_group_view',
		'product_link',
		'product_link_invitation',
		'qualifying_question',
		'recommendation',
		'recommendation_subscription',
		'remarketing_action',
		'search_term_view',
		'shared_criterion',
		'shared_set',
		'shopping_performance_view',
		'shopping_product',
		'smart_campaign_search_term_view',
		'smart_campaign_setting',
		'targeting_expansion_view',
		'third_party_app_analytics_link',
		'topic_constant',
		'topic_view',
		'travel_activity_group_view',
		'travel_activity_performance_view',
		'user_interest',
		'user_list',
		'user_list_customer_type',
		'user_location_view',
		'video',
		'video_enhancement',
		'webpage_view',
		'you_tube_video_upload',
	);

	/**
	 * @return string[] Todos os recursos, em ordem alfabética.
	 */
	public static function all(): array {
		return self::ALL;
	}

	/**
	 * Filtra os recursos por um pedaço do nome — sem `$q`, devolve tudo.
	 *
	 * @param string $q Trecho a procurar (case-insensitive).
	 * @return string[]
	 */
	public static function search( string $q ): array {
		$q = strtolower( trim( $q ) );

		if ( '' === $q ) {
			return self::ALL;
		}

		return array_values(
			array_filter(
				self::ALL,
				// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.resourceFound -- Preserva os nomes dos parâmetros da API interna existente na versão 0.1.0.
				static function ( $resource ) use ( $q ) {
					return false !== strpos( $resource, $q );
				}
			)
		);
	}
}
