<?php
/**
 * Chamadas à Google Ads API (REST).
 *
 * Três endpoints, todos de leitura: `customers:listAccessibleCustomers`,
 * `customers/{cid}/googleAds:search` (o único que devolve dados de campanha,
 * palavra-chave, etc.) e `googleAdsFields:search` (o catálogo de campos da
 * própria API, usado para não deixar o agente chutar nome de campo).
 *
 * A REST da Google Ads devolve as linhas em `camelCase` (`descriptiveName`,
 * `costMicros`), enquanto o GAQL — e o `fieldMask` que a resposta traz — fala
 * `snake_case` (`descriptive_name`, `cost_micros`). `flatten_row()` é a ponte
 * entre os dois: para cada caminho do `fieldMask`, converte cada segmento para
 * `camelCase`, desce na linha e devolve o valor com a CHAVE em `snake_case` —
 * é o formato que o agente pediu e que a camada `Unified` (fase 2c) espera
 * receber de volta.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdsApi {

	/**
	 * Cache de metadados de recurso: 24 horas, em segundos. A API não define
	 * campo novo todo dia, e o valor fica literal porque `DAY_IN_SECONDS` não
	 * é uma dependência garantida do núcleo (não consta nos stubs de teste).
	 */
	private const METADATA_TTL = 86400;

	/** Teto de idas ao `googleAds:search` numa só chamada de `search()`, para uma paginação sem fim não travar a requisição. */
	private const MAX_PAGES = 50;

	/** Campos padrão de `ads/get-customer` e do detalhamento de `ads/list-accessible-customers`. */
	private const CUSTOMER_FIELDS = array(
		'customer.id',
		'customer.descriptive_name',
		'customer.currency_code',
		'customer.time_zone',
		'customer.manager',
		'customer.status',
		'customer.test_account',
	);

	/** Campos padrão de `ads/list-customer-clients`. */
	private const CUSTOMER_CLIENT_FIELDS = array(
		'customer_client.id',
		'customer_client.descriptive_name',
		'customer_client.level',
		'customer_client.manager',
		'customer_client.status',
		'customer_client.currency_code',
		'customer_client.time_zone',
		'customer_client.hidden',
	);

	/**
	 * Base da API: host fixo + versão configurável (a Google encerra versões
	 * a cada ~12 meses).
	 */
	public static function base(): string {
		return GoogleClient::HOST_ADS . '/' . Options::ads_api_version();
	}

	/**
	 * Cabeçalhos exigidos pela Google Ads API.
	 *
	 * `login-customer-id` é opcional na API, mas obrigatório na prática sempre
	 * que a credencial acessa a conta através de uma gerenciadora (MCC) — sem
	 * ele a chamada falha com "USER_PERMISSION_DENIED" mesmo com acesso válido.
	 *
	 * @param string $login_customer_id Explícito na chamada; vazio usa a opção do plugin.
	 * @return array<string,string>
	 */
	public static function headers( string $login_customer_id = '' ): array {
		$headers = array(
			'developer-token' => Options::get_secret( Options::ADS_DEVELOPER_TOKEN ),
		);

		$login = '' !== trim( $login_customer_id )
			? preg_replace( '/\D+/', '', $login_customer_id )
			: Options::ads_login_customer_id();

		if ( is_string( $login ) && '' !== $login ) {
			$headers['login-customer-id'] = $login;
		}

		return $headers;
	}

	/**
	 * @return string[]|\WP_Error IDs de cliente (10 dígitos), sem o prefixo "customers/".
	 */
	public static function list_accessible_customers() {
		$response = GoogleClient::get(
			self::base() . '/customers:listAccessibleCustomers',
			array(),
			self::request_opts()
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$names = isset( $response['resourceNames'] ) && is_array( $response['resourceNames'] )
			? $response['resourceNames']
			: array();

		$ids = array();
		foreach ( $names as $name ) {
			if ( is_string( $name ) && '' !== $name ) {
				$ids[] = 0 === strpos( $name, 'customers/' ) ? substr( $name, strlen( 'customers/' ) ) : $name;
			}
		}

		return $ids;
	}

	/**
	 * Executa uma consulta GAQL, paginando até `max_rows`.
	 *
	 * @param string $customer_id ID do cliente (10 dígitos).
	 * @param string $query       Consulta GAQL completa e já validada.
	 * @param array  $opts        {
	 *     @type string $login_customer_id ID da gerenciadora, se houver.
	 *     @type string $page_token        Token da página a continuar.
	 *     @type int    $max_rows          Teto de linhas a devolver.
	 * }
	 * @return array{rows:array,next_page_token:?string,field_mask:array,truncated:bool}|\WP_Error
	 */
	public static function search( string $customer_id, string $query, array $opts = array() ) {
		$customer_id = CustomerId::normalize( $customer_id );
		if ( is_wp_error( $customer_id ) ) {
			return $customer_id;
		}

		$max_rows = isset( $opts['max_rows'] ) ? (int) $opts['max_rows'] : Options::max_rows();
		$max_rows = max( 1, min( Options::max_rows(), $max_rows ) );

		$login_customer_id = isset( $opts['login_customer_id'] ) ? (string) $opts['login_customer_id'] : '';
		$token             = isset( $opts['page_token'] ) ? (string) $opts['page_token'] : '';

		$rows       = array();
		$field_mask = array();
		$total      = null;

		$request_opts = self::request_opts( $login_customer_id );

		for ( $page = 0; $page < self::MAX_PAGES; $page++ ) {
			$body = array( 'query' => $query );
			if ( '' !== $token ) {
				$body['pageToken'] = $token;
			}

			$response = GoogleClient::post(
				self::base() . '/customers/' . $customer_id . '/googleAds:search',
				$body,
				$request_opts
			);

			if ( is_wp_error( $response ) ) {
				return $response;
			}

			if ( empty( $field_mask ) ) {
				$field_mask = self::parse_field_mask( $response['fieldMask'] ?? '' );
			}

			if ( null === $total && isset( $response['totalResultsCount'] ) ) {
				$total = (int) $response['totalResultsCount'];
			}

			$results = isset( $response['results'] ) && is_array( $response['results'] ) ? $response['results'] : array();

			foreach ( $results as $result ) {
				if ( is_array( $result ) ) {
					$rows[] = self::flatten_row( $result, $field_mask );
				}
			}

			$token = isset( $response['nextPageToken'] ) && is_string( $response['nextPageToken'] )
				? $response['nextPageToken']
				: '';

			// Sem mais páginas, ou já temos linhas suficientes: para de pedir
			// páginas inteiras a mais só para descartar a maior parte delas.
			if ( '' === $token || count( $rows ) >= $max_rows ) {
				break;
			}
		}

		$truncated       = false;
		$next_page_token = null;

		if ( count( $rows ) > $max_rows ) {
			$rows            = array_slice( $rows, 0, $max_rows );
			$truncated       = true;
			$next_page_token = '' !== $token ? $token : null;
		} elseif ( '' !== $token ) {
			// A última página buscada coube inteira no limite, mas a API diz que
			// há mais: ainda é uma resposta cortada, só que na fronteira exata.
			$truncated       = true;
			$next_page_token = $token;
		}

		return array(
			'rows'                => $rows,
			'next_page_token'     => $next_page_token,
			'field_mask'          => $field_mask,
			'truncated'           => $truncated,
			'total_results_count' => $total,
		);
	}

	/**
	 * Detalhes de uma conta (resource `customer`), usando o próprio ID como
	 * `login-customer-id` — é o que a API exige para uma consulta de metadados
	 * da conta em si, gerenciadora ou não.
	 *
	 * @param string $customer_id ID do cliente.
	 * @return array{id:string,name:string,currency:string,timezone:string,is_manager:bool,status:string,is_test:bool}|\WP_Error
	 */
	public static function customer( string $customer_id ) {
		$cid = CustomerId::normalize( $customer_id );
		if ( is_wp_error( $cid ) ) {
			return $cid;
		}

		$query = Gaql::build( 'customer', self::CUSTOMER_FIELDS, array(), array(), 1 );

		$result = self::search(
			$cid,
			$query,
			array(
				'login_customer_id' => $cid,
				'max_rows'          => 1,
			)
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( empty( $result['rows'] ) ) {
			return new \WP_Error(
				'f3_google_ads_customer_not_found',
				__( 'A Google Ads não devolveu dados para esta conta — confira o ID e se a credencial tem acesso a ela.', 'wp-mcp-google-fator3' )
			);
		}

		return self::map_customer_row( $result['rows'][0] );
	}

	/**
	 * Hierarquia de clientes sob uma conta gerenciadora (MCC).
	 *
	 * @param string $manager_id     ID da gerenciadora.
	 * @param bool   $include_hidden Inclui clientes marcados como ocultos.
	 * @param bool   $all_levels     Sem limite de nível (padrão: só nível ≤ 1, os diretos).
	 * @param bool   $complete       Catálogo interno integral, sem LIMIT de relatório e com recusa explícita se a paginação não completar.
	 * @return array{rows:array,next_page_token:?string,field_mask:array,truncated:bool}|\WP_Error
	 */
	public static function customer_clients( string $manager_id, bool $include_hidden = false, bool $all_levels = false, bool $complete = false ) {
		$cid = CustomerId::normalize( $manager_id );
		if ( is_wp_error( $cid ) ) {
			return $cid;
		}

		$conditions = array();
		if ( ! $all_levels ) {
			$conditions[] = 'customer_client.level <= 1';
		}
		if ( ! $include_hidden ) {
			$conditions[] = 'customer_client.hidden = FALSE';
		}

		$max_rows = Options::max_rows();
		$query    = Gaql::build( 'customer_client', self::CUSTOMER_CLIENT_FIELDS, $conditions, array(), $complete ? null : $max_rows );

		if ( $complete ) {
			// O catálogo de contas não pode perder clientes dentro de uma página
			// nem herdar o LIMIT configurado para relatórios. A API é paginada
			// até o fim; uma resposta parcial nunca é apresentada como completa.
			$rows        = array();
			$token       = '';
			$seen_tokens = array();
			$field_mask  = array();
			for ( $page = 0; $page < self::MAX_PAGES; ++$page ) {
				$body = array( 'query' => $query );
				if ( '' !== $token ) {
					$body['pageToken'] = $token;
				}
				$response = GoogleClient::post( self::base() . '/customers/' . $cid . '/googleAds:search', $body, self::request_opts( $cid ) );
				if ( is_wp_error( $response ) ) {
					return $response;
				}
				if ( empty( $field_mask ) ) {
					$field_mask = self::parse_field_mask( $response['fieldMask'] ?? '' );
				}
				foreach ( (array) ( $response['results'] ?? array() ) as $result ) {
					if ( is_array( $result ) ) {
						$rows[] = self::flatten_row( $result, $field_mask );
					}
				}
				$token = isset( $response['nextPageToken'] ) && is_string( $response['nextPageToken'] ) ? $response['nextPageToken'] : '';
				if ( '' === $token ) {
					return array(
						'rows'                => $rows,
						'next_page_token'     => null,
						'field_mask'          => $field_mask,
						'truncated'           => false,
						'total_results_count' => count( $rows ),
					);
				}
				if ( isset( $seen_tokens[ $token ] ) ) {
					return new \WP_Error( 'f3_google_ads_catalog_pagination', 'A API repetiu um token de paginação; a hierarquia completa não foi obtida.' );
				}
				$seen_tokens[ $token ] = true;
			}
			return new \WP_Error( 'f3_google_ads_catalog_pagination', 'A hierarquia excedeu o limite de páginas por chamada; o catálogo não foi tratado como completo.' );
		}

		return self::search(
			$cid,
			$query,
			array(
				'login_customer_id' => $cid,
				'max_rows'          => $max_rows,
			)
		);
	}

	/**
	 * Campos selecionáveis, filtráveis e ordenáveis de um recurso GAQL —
	 * inclusive as métricas e segmentos combináveis com ele. Cache de 24h: a
	 * lista de campos da API muda raramente e cada consulta é uma chamada de
	 * rede a mais só para descobrir nomes de campo.
	 *
	 * @param string $resource Nome do recurso (ex.: 'campaign').
	 * @return array{resource:string,selectable:string[],filterable:string[],sortable:string[],cached:bool}|\WP_Error
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.resourceFound -- Preserva o argumento público da versão 0.1 para chamadas nomeadas PHP.
	public static function resource_metadata( string $resource ) {
		if ( ! Gaql::identifier_ok( $resource ) ) {
			return new \WP_Error(
				'f3_google_ads_resource_invalid',
				sprintf(
					/* translators: %s: nome de recurso recebido. */
					__( 'Nome de recurso GAQL inválido: "%s".', 'wp-mcp-google-fator3' ),
					$resource
				)
			);
		}

		$cache_key = self::metadata_cache_key( $resource );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			$cached['cached'] = true;

			return $cached;
		}

		$selectable = array();
		$filterable = array();
		$sortable   = array();

		// Consulta 1: atributos do próprio recurso (campos "campaign.*" etc.).
		$attributes = self::fields_search(
			sprintf(
				"SELECT name, selectable, filterable, sortable, category, selectable_with WHERE name LIKE '%s.%%' AND category = 'ATTRIBUTE'",
				$resource
			)
		);

		if ( is_wp_error( $attributes ) ) {
			// A cláusula `category` nem sempre existe nas versões mais antigas
			// da API; sem ela, o mesmo filtro por prefixo ainda funciona.
			$attributes = self::fields_search(
				sprintf(
					"SELECT name, selectable, filterable, sortable, category, selectable_with WHERE name LIKE '%s.%%'",
					$resource
				)
			);
		}

		if ( is_wp_error( $attributes ) ) {
			return $attributes;
		}

		self::merge_fields( $attributes, $selectable, $filterable, $sortable );

		// Consulta 2: métricas e segmentos que podem ser selecionados junto com
		// este recurso.
		$metrics_segments = self::fields_search(
			sprintf(
				"SELECT name, selectable, filterable, sortable, category, selectable_with WHERE selectable_with CONTAINS ANY('%s')",
				$resource
			)
		);

		if ( is_wp_error( $metrics_segments ) ) {
			return $metrics_segments;
		}

		self::merge_fields( $metrics_segments, $selectable, $filterable, $sortable );

		sort( $selectable );
		sort( $filterable );
		sort( $sortable );

		$result = array(
			'resource'   => $resource,
			'selectable' => array_values( array_unique( $selectable ) ),
			'filterable' => array_values( array_unique( $filterable ) ),
			'sortable'   => array_values( array_unique( $sortable ) ),
		);

		set_transient( $cache_key, $result, self::METADATA_TTL );

		$result['cached'] = false;

		return $result;
	}

	/**
	 * Achata uma linha da resposta (aninhada, em camelCase) para as chaves
	 * pedidas pelo `fieldMask` (planas, em snake_case), acrescentando as
	 * derivadas de campos em micros.
	 *
	 * @param array    $row   Linha crua de `results[]`.
	 * @param string[] $paths Caminhos do `fieldMask`, em snake_case (ex.: 'metrics.cost_micros').
	 * @return array<string,mixed>
	 */
	public static function flatten_row( array $row, array $paths ): array {
		$flat = array();

		foreach ( $paths as $path ) {
			$path = (string) $path;
			if ( '' === $path ) {
				continue;
			}

			$segments = array_map( array( self::class, 'to_camel_case' ), explode( '.', $path ) );
			$value    = self::dig( $row, $segments );

			$flat[ $path ] = $value;

			self::add_derived( $flat, $path, $value );
		}

		return $flat;
	}

	/**
	 * Cabeçalhos + escopo + conector para toda chamada à Google Ads API.
	 *
	 * @param string $login_customer_id Ver headers().
	 */
	private static function request_opts( string $login_customer_id = '' ): array {
		return array(
			'scopes'    => Credentials::scopes_for( 'ads' ),
			'connector' => 'ads',
			'headers'   => self::headers( $login_customer_id ),
		);
	}

	private static function fields_search( string $query ) {
		return GoogleClient::post(
			self::base() . '/googleAdsFields:search',
			array( 'query' => $query ),
			self::request_opts()
		);
	}

	/**
	 * @param array    $response   Corpo de `googleAdsFields:search`.
	 * @param string[] $selectable Acumulador (por referência).
	 * @param string[] $filterable Acumulador (por referência).
	 * @param string[] $sortable   Acumulador (por referência).
	 */
	private static function merge_fields( array $response, array &$selectable, array &$filterable, array &$sortable ): void {
		$results = isset( $response['results'] ) && is_array( $response['results'] ) ? $response['results'] : array();

		foreach ( $results as $field ) {
			if ( ! is_array( $field ) || empty( $field['name'] ) || ! is_string( $field['name'] ) ) {
				continue;
			}

			$name = $field['name'];

			if ( ! empty( $field['selectable'] ) ) {
				$selectable[] = $name;
			}
			if ( ! empty( $field['filterable'] ) ) {
				$filterable[] = $name;
			}
			if ( ! empty( $field['sortable'] ) ) {
				$sortable[] = $name;
			}
		}
	}

	/**
	 * @param mixed $field_mask String CSV ('a,b,c') ou array — a REST manda string.
	 * @return string[]
	 */
	private static function parse_field_mask( $field_mask ): array {
		if ( is_array( $field_mask ) ) {
			return array_values( array_filter( array_map( 'trim', $field_mask ) ) );
		}

		if ( is_string( $field_mask ) && '' !== $field_mask ) {
			return array_values( array_filter( array_map( 'trim', explode( ',', $field_mask ) ) ) );
		}

		return array();
	}

	/**
	 * 'cost_micros' → 'costMicros'; segmentos sem `_` voltam iguais.
	 */
	private static function to_camel_case( string $segment ): string {
		if ( false === strpos( $segment, '_' ) ) {
			return $segment;
		}

		$parts = explode( '_', $segment );
		$camel = (string) array_shift( $parts );

		foreach ( $parts as $part ) {
			if ( '' === $part ) {
				continue;
			}
			$camel .= strtoupper( $part[0] ) . substr( $part, 1 );
		}

		return $camel;
	}

	/**
	 * Desce na linha aninhada seguindo os segmentos já convertidos; um
	 * caminho ausente (campo não devolvido pela API para esta linha) vira
	 * `null` em vez de erro.
	 *
	 * @param array    $row      Linha crua.
	 * @param string[] $segments Segmentos em camelCase.
	 * @return mixed
	 */
	private static function dig( array $row, array $segments ) {
		$current = $row;

		foreach ( $segments as $segment ) {
			if ( is_array( $current ) && array_key_exists( $segment, $current ) ) {
				$current = $current[ $segment ];
				continue;
			}

			return null;
		}

		return $current;
	}

	/**
	 * Campos em micros ganham uma coluna irmã em unidade de moeda.
	 *
	 * Regra: todo campo cujo nome termina em `_micros` ganha `<sem _micros>`
	 * = valor / 1e6. Os quatro campos que já vêm em micros mas não terminam
	 * em `_micros` (`average_cpc`, `average_cpm`, `cost_per_conversion`,
	 * `cost_per_all_conversions`) ganham `<caminho>_currency` = valor / 1e6.
	 *
	 * @param array<string,mixed> $flat  Acumulador (por referência).
	 * @param string              $path  Caminho em snake_case (ex.: 'metrics.cost_micros').
	 * @param mixed               $value Valor já lido da linha.
	 */
	private static function add_derived( array &$flat, string $path, $value ): void {
		if ( ! is_numeric( $value ) ) {
			return;
		}

		$number   = (float) $value / 1000000;
		$last_dot = strrpos( $path, '.' );
		$leaf     = false === $last_dot ? $path : substr( $path, $last_dot + 1 );

		if ( strlen( $leaf ) > 7 && '_micros' === substr( $leaf, -7 ) ) {
			$flat[ substr( $path, 0, -7 ) ] = $number;

			return;
		}

		$already_in_micros = array( 'average_cpc', 'average_cpm', 'cost_per_conversion', 'cost_per_all_conversions' );

		if ( in_array( $leaf, $already_in_micros, true ) ) {
			$flat[ $path . '_currency' ] = $number;
		}
	}

	/**
	 * @param array $row Linha já achatada de uma consulta em `customer`.
	 */
	private static function map_customer_row( array $row ): array {
		return array(
			'id'         => (string) ( $row['customer.id'] ?? '' ),
			'name'       => (string) ( $row['customer.descriptive_name'] ?? '' ),
			'currency'   => (string) ( $row['customer.currency_code'] ?? '' ),
			'timezone'   => (string) ( $row['customer.time_zone'] ?? '' ),
			'is_manager' => (bool) ( $row['customer.manager'] ?? false ),
			'status'     => (string) ( $row['customer.status'] ?? '' ),
			'is_test'    => (bool) ( $row['customer.test_account'] ?? false ),
		);
	}

	private static function metadata_cache_key( string $resource_name ): string {
		return 'f3_mcp_google_adsmeta_' . Options::ads_api_version() . '_' . $resource_name;
	}
}
