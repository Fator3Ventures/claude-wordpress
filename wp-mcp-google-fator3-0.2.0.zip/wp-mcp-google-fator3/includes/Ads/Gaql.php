<?php
/**
 * Montagem e validação de consultas GAQL (Google Ads Query Language).
 *
 * Este plugin é só de leitura, e a única porta de saída para o Ads é o
 * endpoint `googleAds:search` — que, por construção, não muta nada. Mesmo
 * assim, a consulta pode chegar pronta do agente (um `query` completo) ou ser
 * montada aqui a partir de pedaços (`resource` + `fields` + `conditions` +
 * `orderings` + `limit`); dos dois jeitos, o que sai daqui precisa ser uma
 * única instrução `SELECT`, sem `;` e sem comentário — não porque a API
 * aceitasse outra coisa, mas porque a mensagem de erro de "consulta inválida"
 * é muito mais clara vinda daqui do que da Google.
 *
 * `build()` não escapa nada: os `conditions` são strings prontas do agente,
 * como no MCP oficial do Google Ads — a validação de segurança (sem `;`, sem
 * comentário) é feita por quem monta a chamada, não por este método. `build()`
 * só junta as partes na ordem certa.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Ads;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Gaql {

	/** Tamanho máximo de uma consulta, em bytes. */
	private const MAX_BYTES = 8192;

	/**
	 * Monta a consulta a partir das partes estruturadas.
	 *
	 * @param string   $resource   Recurso GAQL (ex.: 'campaign').
	 * @param string[] $fields     Campos do SELECT.
	 * @param string[] $conditions Condições já prontas, combinadas com AND.
	 * @param string[] $orderings  Ordenações, ex.: 'metrics.clicks DESC'.
	 * @param int|null $limit      LIMIT, se houver.
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.resourceFound -- Preserva os nomes dos parâmetros da API interna existente na versão 0.1.0.
	public static function build( string $resource, array $fields, array $conditions = array(), array $orderings = array(), ?int $limit = null ): string {
		$fields = self::clean_list( $fields );
		$query  = 'SELECT ' . implode( ', ', $fields ) . ' FROM ' . trim( $resource );

		$conditions = self::clean_list( $conditions );
		if ( ! empty( $conditions ) ) {
			$query .= ' WHERE ' . implode( ' AND ', $conditions );
		}

		$orderings = self::clean_list( $orderings );
		if ( ! empty( $orderings ) ) {
			$query .= ' ORDER BY ' . implode( ', ', $orderings );
		}

		if ( null !== $limit ) {
			$query .= ' LIMIT ' . max( 1, $limit );
		}

		// A cláusula PARAMETERS é o que faz a REST omitir os `resourceName` que
		// o agente não pediu explicitamente — sem ela cada linha viria inflada
		// com um `resourceName` por recurso selecionado.
		$query .= ' PARAMETERS omit_unselected_resource_names=true';

		return $query;
	}

	/**
	 * @param string[] $values Lista bruta.
	 * @return string[] Sem itens vazios, reindexada.
	 */
	private static function clean_list( array $values ): array {
		$clean = array();

		foreach ( $values as $value ) {
			$value = trim( (string) $value );
			if ( '' !== $value ) {
				$clean[] = $value;
			}
		}

		return $clean;
	}

	/**
	 * Uma consulta é segura para mandar ao `googleAds:search` quando: é uma
	 * única instrução (sem `;`), começa com `SELECT`, contém `FROM`, não tem
	 * comentário e cabe no tamanho máximo.
	 *
	 * @param string $query Consulta completa.
	 * @return true|\WP_Error
	 */
	public static function validate( string $query ) {
		$trimmed = trim( $query );

		if ( '' === $trimmed ) {
			return new \WP_Error(
				'f3_google_ads_gaql_empty',
				__( 'A consulta GAQL está vazia.', 'wp-mcp-google-fator3' )
			);
		}

		if ( strlen( $query ) > self::MAX_BYTES ) {
			return new \WP_Error(
				'f3_google_ads_gaql_size',
				__( 'A consulta GAQL passa de 8 KiB.', 'wp-mcp-google-fator3' )
			);
		}

		if ( false !== strpos( $trimmed, ';' ) ) {
			return new \WP_Error(
				'f3_google_ads_gaql_semicolon',
				__( 'A consulta GAQL não pode conter ";" — uma única instrução por chamada, sem ponto e vírgula no fim.', 'wp-mcp-google-fator3' )
			);
		}

		if ( false !== strpos( $trimmed, '--' ) || false !== strpos( $trimmed, '/*' ) ) {
			return new \WP_Error(
				'f3_google_ads_gaql_comment',
				__( 'A consulta GAQL não pode conter comentários ("--" ou "/*").', 'wp-mcp-google-fator3' )
			);
		}

		// Caractere de controle (NUL à frente) não tem uso legítimo em GAQL e é
		// o truque clássico para uma string parecer terminar antes do que
		// termina de fato em alguma camada do caminho. Tabulação e quebra de
		// linha continuam válidas: são espaço em branco na gramática.
		if ( 1 === preg_match( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $query ) ) {
			return new \WP_Error(
				'f3_google_ads_gaql_control',
				__( 'A consulta GAQL tem caractere de controle (por exemplo NUL). Use só texto.', 'wp-mcp-google-fator3' )
			);
		}

		// `LIMIT` sem um número logo depois passaria intacto por
		// `ensure_limit()` (que só reconhece `LIMIT <dígitos>`) e chegaria à
		// Google como `... LIMIT -5 LIMIT 1000`, cujo erro de sintaxe não
		// explica nada a quem chamou.
		if ( 1 === preg_match( '/\bLIMIT\b/i', $trimmed ) && 1 !== preg_match( '/\bLIMIT[ \t]+\d+\b/i', $trimmed ) ) {
			return new \WP_Error(
				'f3_google_ads_gaql_limit',
				__( 'A cláusula LIMIT da consulta GAQL precisa de um número inteiro positivo.', 'wp-mcp-google-fator3' )
			);
		}

		if ( 1 !== preg_match( '/^SELECT\b/i', $trimmed ) ) {
			return new \WP_Error(
				'f3_google_ads_gaql_select',
				__( 'A consulta GAQL precisa começar com SELECT.', 'wp-mcp-google-fator3' )
			);
		}

		if ( 1 !== preg_match( '/\sFROM\s/i', ' ' . $trimmed . ' ' ) ) {
			return new \WP_Error(
				'f3_google_ads_gaql_from',
				__( 'A consulta GAQL precisa ter uma cláusula FROM com o recurso.', 'wp-mcp-google-fator3' )
			);
		}

		return true;
	}

	/**
	 * Acrescenta `LIMIT $max` quando a consulta ainda não tem um.
	 *
	 * A cláusula PARAMETERS vem depois de LIMIT na gramática do GAQL, então o
	 * LIMIT entra antes dela quando ela já existir, nunca depois.
	 *
	 * @param string $query Consulta original.
	 * @param int    $max   Limite a impor.
	 */
	public static function ensure_limit( string $query, int $max ): string {
		if ( preg_match( '/\bLIMIT\s+\d+\b/i', $query ) ) {
			return $query;
		}

		$max = max( 1, $max );

		if ( preg_match( '/\bPARAMETERS\b/i', $query, $matches, PREG_OFFSET_CAPTURE ) ) {
			$pos = $matches[0][1];

			return rtrim( substr( $query, 0, $pos ) ) . ' LIMIT ' . $max . ' ' . substr( $query, $pos );
		}

		return rtrim( $query ) . ' LIMIT ' . $max;
	}

	/**
	 * Um identificador de campo GAQL é sempre minúsculo, começa com letra e só
	 * tem letras, dígitos, `_` e `.` (ex.: 'campaign.id', 'metrics.cost_micros').
	 *
	 * @param string $s Identificador a checar.
	 */
	public static function identifier_ok( string $s ): bool {
		// `\z` e não `$`: em PCRE, `$` casa também ANTES de uma quebra de linha
		// final, então "campaign.id\n" passaria por esta checagem e a quebra
		// entraria na consulta concatenada mais adiante.
		return 1 === preg_match( '/^[a-z][a-z0-9_.]*\z/', $s );
	}

	/**
	 * Uma ordenação é um identificador válido, opcionalmente seguido de
	 * ` ASC` ou ` DESC` (maiúsculo ou minúsculo).
	 *
	 * @param string $s Ordenação a checar, ex.: 'metrics.clicks DESC'.
	 */
	public static function ordering_ok( string $s ): bool {
		$s = trim( $s );

		if ( preg_match( '/^([a-z][a-z0-9_.]*)[ \t]+(ASC|DESC)\z/i', $s, $matches ) ) {
			return self::identifier_ok( $matches[1] );
		}

		return self::identifier_ok( $s );
	}

	/**
	 * Uma condição de WHERE vinda do agente não pode carregar outra instrução
	 * nem comentário — o resto (aspas, operadores, funções GAQL) é dela.
	 *
	 * @param string $s Fragmento de condição.
	 */
	public static function condition_ok( string $s ): bool {
		return false === strpos( $s, ';' ) && false === strpos( $s, '--' ) && false === strpos( $s, '/*' );
	}
}
