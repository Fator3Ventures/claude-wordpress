<?php
/**
 * Normalização do ID de cliente do Google Ads.
 *
 * O agente pode mandar o ID de várias formas — com hífens (como aparece na
 * interface do Google Ads, "123-456-7890"), como nome de recurso
 * ("customers/1234567890") ou já limpo. Toda chamada à API espera exatamente
 * 10 dígitos sem pontuação nenhuma; validar aqui, num único lugar, evita que
 * um ID mal formado vaze para dentro de uma URL montada à mão.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Ads;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CustomerId {

	/**
	 * @param mixed $value Valor bruto vindo do agente.
	 * @return string|\WP_Error 10 dígitos, sem hífens.
	 */
	public static function normalize( $value ) {
		if ( is_int( $value ) || is_float( $value ) ) {
			$value = (string) $value;
		}

		if ( ! is_string( $value ) || '' === trim( $value ) ) {
			return new \WP_Error(
				'f3_google_ads_customer_id',
				__( 'Informe o ID do cliente do Google Ads (10 dígitos, com ou sem hífens).', 'wp-mcp-google-fator3' )
			);
		}

		$value = trim( $value );

		// Nome de recurso completo: "customers/1234567890".
		if ( 0 === stripos( $value, 'customers/' ) ) {
			$value = substr( $value, strlen( 'customers/' ) );
		}

		// Hífens e espaços são só formatação de exibição ("123-456-7890").
		$digits = preg_replace( '/[\s-]+/', '', $value );

		if ( ! is_string( $digits ) || ! preg_match( '/^\d{10}$/', $digits ) ) {
			return new \WP_Error(
				'f3_google_ads_customer_id',
				sprintf(
					/* translators: %s: valor recebido. */
					__( 'ID de cliente do Google Ads inválido: "%s". Use 10 dígitos, com ou sem hífens (ex.: 123-456-7890 ou 1234567890).', 'wp-mcp-google-fator3' ),
					$value
				)
			);
		}

		return $digits;
	}
}
