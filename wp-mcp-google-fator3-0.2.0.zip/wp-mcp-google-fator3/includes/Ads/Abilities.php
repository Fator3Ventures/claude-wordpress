<?php
/**
 * Habilidades `ads/*`.
 *
 * Seis rotas, todas de leitura: descobrir contas (`list-accessible-customers`,
 * `get-customer`, `list-customer-clients`), descobrir o esquema
 * (`list-resources`, `get-resource-metadata`) e consultar dados
 * (`search`). A ordem de descoberta importa — é por isso que as descrições
 * longas (gramática GAQL, formato de data, o limite do `change_event`, "não
 * chute campos") ficam nas propriedades do `input_schema`: é o texto que o
 * agente lê exatamente na hora de decidir o próximo parâmetro.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Abilities {

	/** Acima disto, `list-accessible-customers` não busca detalhe por conta — seriam N+1 chamadas à API só para uma listagem. */
	private const MAX_DETAILED_CUSTOMERS = 25;

	public static function register(): void {
		self::register_list_accessible_customers();
		self::register_get_customer();
		self::register_search();
		self::register_get_resource_metadata();
		self::register_list_resources();
		self::register_list_customer_clients();
	}

	// =========================================================================
	// ads/list-accessible-customers
	// =========================================================================

	private static function register_list_accessible_customers(): void {
		Ability::register(
			'ads/list-accessible-customers',
			'ads',
			array(
				'label'        => __( 'Listar contas acessíveis do Google Ads', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista os IDs de cliente do Google Ads acessíveis pela credencial configurada. Use antes de qualquer outra rota quando não souber o customer_id. Com with_details (padrão), também traz nome, moeda, fuso e se cada conta é gerenciadora (MCC) ou de teste.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'with_details' => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => __( 'Quando verdadeiro (padrão), busca nome, moeda, fuso e tipo de cada conta com uma chamada extra por conta. Só acontece com até 25 contas; acima disso a resposta traz só os IDs, com um aviso em "warnings".', 'wp-mcp-google-fator3' ),
						),
					),
				),
				'callback'     => array( self::class, 'list_accessible_customers' ),
			)
		);
	}

	/**
	 * @param array $input Ver input_schema acima.
	 * @return array|\WP_Error
	 */
	public static function list_accessible_customers( array $input ) {
		$ids = AdsApi::list_accessible_customers();
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}

		$with_details = ! array_key_exists( 'with_details', $input ) || (bool) $input['with_details'];

		$customers = array();
		$warnings  = array();

		if ( $with_details && count( $ids ) > self::MAX_DETAILED_CUSTOMERS ) {
			$with_details = false;
			$warnings[]   = sprintf(
				/* translators: 1: número de contas, 2: teto de detalhamento. */
				__( '%1$d contas acessíveis passam do teto de %2$d para buscar detalhes automaticamente; a lista abaixo traz só os IDs. Use ads/get-customer para os detalhes de uma conta específica.', 'wp-mcp-google-fator3' ),
				count( $ids ),
				self::MAX_DETAILED_CUSTOMERS
			);
		}

		foreach ( $ids as $id ) {
			if ( ! $with_details ) {
				$customers[] = array( 'id' => $id );
				continue;
			}

			$detail = AdsApi::customer( $id );

			// Uma conta cancelada ou sem permissão não pode derrubar a lista
			// inteira: vira uma linha de erro, e as demais seguem normais.
			if ( is_wp_error( $detail ) ) {
				$customers[] = array(
					'id'    => $id,
					'error' => $detail->get_error_message(),
				);
				continue;
			}

			$customers[] = array_merge( array( 'id' => $id ), $detail );
		}

		return Response::ok(
			array(
				'customers' => $customers,
				'count'     => count( $customers ),
				'warnings'  => $warnings,
			),
			sprintf(
				/* translators: %d: número de contas. */
				__( '%d conta(s) acessível(is).', 'wp-mcp-google-fator3' ),
				count( $customers )
			)
		);
	}

	// =========================================================================
	// ads/get-customer
	// =========================================================================

	private static function register_get_customer(): void {
		Ability::register(
			'ads/get-customer',
			'ads',
			array(
				'label'        => __( 'Detalhes de uma conta do Google Ads', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Detalhes de uma única conta do Google Ads: nome, moeda, fuso horário, status e se é gerenciadora (MCC) ou de teste.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'customer_id' => self::customer_id_property( __( 'ID da conta a consultar.', 'wp-mcp-google-fator3' ) ),
					),
					'required'   => array( 'customer_id' ),
				),
				'callback'     => array( self::class, 'get_customer' ),
			)
		);
	}

	/**
	 * @param array $input Ver input_schema acima.
	 * @return array|\WP_Error
	 */
	public static function get_customer( array $input ) {
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid;
		}

		$customer = AdsApi::customer( $cid );
		if ( is_wp_error( $customer ) ) {
			return $customer;
		}

		return Response::ok( array( 'customer' => $customer ) );
	}

	// =========================================================================
	// ads/search
	// =========================================================================

	private static function register_search(): void {
		$resources_hint = sprintf(
			/* translators: %s: lista dos recursos GAQL, separados por vírgula. */
			__( 'Recursos válidos (use ads/list-resources para filtrar): %s', 'wp-mcp-google-fator3' ),
			implode( ', ', Resources::all() )
		);

		Ability::register(
			'ads/search',
			'ads',
			array(
				'label'        => __( 'Consultar dados do Google Ads (GAQL)', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Executa uma consulta GAQL de leitura contra a Google Ads API, com paginação automática até o teto de linhas configurado. Informe "query" pronta OU "resource" + "fields" para montar a consulta. Sempre devolve a consulta final usada, mesmo em erro.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'customer_id'       => self::customer_id_property( __( 'ID da conta a consultar.', 'wp-mcp-google-fator3' ) ),
						'query'             => array(
							'type'        => 'string',
							'description' => __( 'Consulta GAQL completa e pronta (ex.: "SELECT campaign.id, campaign.name, metrics.clicks FROM campaign WHERE segments.date DURING LAST_7_DAYS"). Use isto OU resource+fields, nunca os dois. Gramática completa: https://developers.google.com/google-ads/api/docs/query/grammar — uma única instrução, sem ";" e sem comentários. Datas sempre no formato YYYY-MM-DD, com início e fim finitos. Consultas ao recurso change_event exigem LIMIT menor ou igual a 10000. Não chute nomes de campo: rode ads/get-resource-metadata antes para confirmar o que existe.', 'wp-mcp-google-fator3' ),
						),
						'resource'          => array(
							'type'        => 'string',
							'description' => $resources_hint,
						),
						'fields'            => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Campos a selecionar, sempre com o nome completo (ex.: "campaign.id", "metrics.clicks", "segments.date") — nada de nome parcial ou coringa. Use com "resource". Descubra os campos válidos de um recurso com ads/get-resource-metadata antes de adivinhar.', 'wp-mcp-google-fator3' ),
						),
						'conditions'        => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Condições do WHERE, combinadas com AND (ex.: ["segments.date DURING LAST_7_DAYS", "campaign.status = \'ENABLED\'"]). Cada uma entra na consulta como está — sem ";" e sem comentários.', 'wp-mcp-google-fator3' ),
						),
						'orderings'         => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'string' ),
							'description' => __( 'Ordenações do ORDER BY, cada uma um campo com sufixo opcional ASC ou DESC (ex.: ["metrics.clicks DESC", "campaign.name"]).', 'wp-mcp-google-fator3' ),
						),
						'limit'             => array(
							'type'        => 'integer',
							'minimum'     => 1,
							'description' => __( 'Máximo de linhas a devolver. Padrão e teto seguem o limite configurado no plugin. Consultas ao recurso change_event exigem LIMIT menor ou igual a 10000.', 'wp-mcp-google-fator3' ),
						),
						'page_token'        => array(
							'type'        => 'string',
							'description' => __( 'Token de página (next_page_token) de uma chamada anterior, para continuar de onde parou.', 'wp-mcp-google-fator3' ),
						),
						'login_customer_id' => array(
							'type'        => 'string',
							'description' => __( 'ID da conta gerenciadora (MCC) a usar como login-customer-id nesta chamada específica, quando diferente do configurado no plugin.', 'wp-mcp-google-fator3' ),
						),
						'format'            => array(
							'type'        => 'string',
							'enum'        => array( 'table', 'raw' ),
							'default'     => 'table',
							'description' => __( '"table" (padrão): colunas e linhas compactas, mais econômico em tokens. "raw": uma linha por objeto, com todas as chaves achatadas (inclusive as derivadas de campos em micros).', 'wp-mcp-google-fator3' ),
						),
					),
					'required'   => array( 'customer_id' ),
				),
				'callback'     => array( self::class, 'search' ),
			)
		);
	}

	/**
	 * @param array $input Ver input_schema acima.
	 * @return array|\WP_Error
	 */
	public static function search( array $input ) {
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid;
		}

		$limit = self::resolve_limit( $input['limit'] ?? null );
		if ( is_wp_error( $limit ) ) {
			return $limit;
		}

		$raw_query = isset( $input['query'] ) ? trim( (string) $input['query'] ) : '';

		if ( '' !== $raw_query ) {
			$valid = Gaql::validate( $raw_query );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}

			$query = Gaql::ensure_limit( $raw_query, $limit );
		} else {
			$query = self::build_structured_query( $input, $limit );
			if ( is_wp_error( $query ) ) {
				return $query;
			}
		}

		$opts = array( 'max_rows' => $limit );

		$page_token = isset( $input['page_token'] ) ? trim( (string) $input['page_token'] ) : '';
		if ( '' !== $page_token ) {
			$opts['page_token'] = $page_token;
		}

		$login_customer_id = isset( $input['login_customer_id'] ) ? trim( (string) $input['login_customer_id'] ) : '';
		if ( '' !== $login_customer_id ) {
			$opts['login_customer_id'] = $login_customer_id;
		}

		$result = AdsApi::search( $cid, $query, $opts );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$format = isset( $input['format'] ) && 'raw' === $input['format'] ? 'raw' : 'table';

		if ( 'raw' === $format ) {
			return Response::ok(
				array(
					'rows'            => $result['rows'],
					'next_page_token' => $result['next_page_token'],
					'field_mask'      => $result['field_mask'],
					'query'           => $query,
				),
				sprintf(
					/* translators: %d: número de linhas. */
					__( '%d linha(s).', 'wp-mcp-google-fator3' ),
					count( $result['rows'] )
				)
			);
		}

		$columns = self::table_columns( $result['rows'], $result['field_mask'] );
		$rows    = array();

		foreach ( $result['rows'] as $row ) {
			$line = array();
			foreach ( $columns as $column ) {
				$line[] = array_key_exists( $column, $row ) ? $row[ $column ] : null;
			}
			$rows[] = $line;
		}

		return Response::ok(
			array(
				'columns'         => $columns,
				'rows'            => $rows,
				'row_count'       => count( $rows ),
				'truncated'       => $result['truncated'],
				'next_page_token' => $result['next_page_token'],
				'query'           => $query,
			),
			sprintf(
				/* translators: %d: número de linhas. */
				__( '%d linha(s).', 'wp-mcp-google-fator3' ),
				count( $rows )
			)
		);
	}

	/**
	 * Monta e valida a consulta a partir de resource+fields+conditions+orderings.
	 *
	 * @param array $input Entrada da habilidade.
	 * @param int   $limit Limite já resolvido (padrão ou informado, dentro do teto).
	 * @return string|\WP_Error
	 */
	private static function build_structured_query( array $input, int $limit ) {
		$resource = isset( $input['resource'] ) ? trim( (string) $input['resource'] ) : '';
		$fields   = isset( $input['fields'] ) && is_array( $input['fields'] )
			? array_values( array_map( 'strval', $input['fields'] ) )
			: array();

		if ( '' === $resource || empty( $fields ) ) {
			return new \WP_Error(
				'f3_google_ads_search_params',
				__( 'Informe "query" já pronta, ou "resource" junto com "fields" para montar a consulta.', 'wp-mcp-google-fator3' )
			);
		}

		if ( ! Gaql::identifier_ok( $resource ) ) {
			return new \WP_Error(
				'f3_google_ads_bad_resource',
				sprintf(
					/* translators: %s: nome de recurso recebido. */
					__( 'Nome de recurso GAQL inválido: "%s". Veja ads/list-resources.', 'wp-mcp-google-fator3' ),
					$resource
				)
			);
		}

		foreach ( $fields as $field ) {
			if ( ! Gaql::identifier_ok( $field ) ) {
				return new \WP_Error(
					'f3_google_ads_bad_field',
					sprintf(
						/* translators: %s: nome de campo recebido. */
						__( 'Nome de campo GAQL inválido: "%s". Use ads/get-resource-metadata para descobrir os campos válidos — não chute.', 'wp-mcp-google-fator3' ),
						$field
					)
				);
			}
		}

		$conditions = isset( $input['conditions'] ) && is_array( $input['conditions'] )
			? array_values( array_map( 'strval', $input['conditions'] ) )
			: array();

		foreach ( $conditions as $condition ) {
			if ( ! Gaql::condition_ok( $condition ) ) {
				return new \WP_Error(
					'f3_google_ads_bad_condition',
					sprintf(
						/* translators: %s: condição recebida. */
						__( 'Condição inválida (não pode conter ";" nem comentários): "%s".', 'wp-mcp-google-fator3' ),
						$condition
					)
				);
			}
		}

		$orderings = isset( $input['orderings'] ) && is_array( $input['orderings'] )
			? array_values( array_map( 'strval', $input['orderings'] ) )
			: array();

		foreach ( $orderings as $ordering ) {
			if ( ! Gaql::ordering_ok( $ordering ) ) {
				return new \WP_Error(
					'f3_google_ads_bad_ordering',
					sprintf(
						/* translators: %s: ordenação recebida. */
						__( 'Ordenação inválida: "%s". Use um campo, opcionalmente seguido de ASC ou DESC.', 'wp-mcp-google-fator3' ),
						$ordering
					)
				);
			}
		}

		return Gaql::build( $resource, $fields, $conditions, $orderings, $limit );
	}

	/**
	 * Colunas da tabela: as chaves da primeira linha (fieldMask + derivadas),
	 * na ordem em que `flatten_row()` as produziu. Sem linhas, cai para o
	 * próprio fieldMask — não há como saber quais derivadas existiriam.
	 *
	 * @param array    $rows       Linhas já achatadas.
	 * @param string[] $field_mask Caminhos do fieldMask.
	 * @return string[]
	 */
	private static function table_columns( array $rows, array $field_mask ): array {
		if ( ! empty( $rows ) ) {
			return array_keys( $rows[0] );
		}

		return $field_mask;
	}

	// =========================================================================
	// ads/get-resource-metadata
	// =========================================================================

	private static function register_get_resource_metadata(): void {
		Ability::register(
			'ads/get-resource-metadata',
			'ads',
			array(
				'label'        => __( 'Campos de um recurso do Google Ads', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Descobre quais campos um recurso GAQL aceita: selecionáveis, filtráveis, ordenáveis, e quais métricas/segmentos combinam com ele. Use sempre antes de montar uma consulta em ads/search — não chute nomes de campo. A resposta fica em cache por 24 horas.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'resource_name' => array(
							'type'        => 'string',
							'description' => __( 'Nome do recurso GAQL (ex.: "campaign", "ad_group", "keyword_view"). Veja ads/list-resources para a lista completa.', 'wp-mcp-google-fator3' ),
						),
					),
					'required'   => array( 'resource_name' ),
				),
				'callback'     => array( self::class, 'get_resource_metadata' ),
			)
		);
	}

	/**
	 * @param array $input Ver input_schema acima.
	 * @return array|\WP_Error
	 */
	public static function get_resource_metadata( array $input ) {
		$resource = isset( $input['resource_name'] ) ? trim( (string) $input['resource_name'] ) : '';

		if ( '' === $resource || ! Gaql::identifier_ok( $resource ) ) {
			return new \WP_Error(
				'f3_google_ads_resource_invalid',
				__( 'Informe um nome de recurso GAQL válido (ex.: "campaign"). Veja ads/list-resources.', 'wp-mcp-google-fator3' )
			);
		}

		$meta = AdsApi::resource_metadata( $resource );
		if ( is_wp_error( $meta ) ) {
			return $meta;
		}

		$metrics    = array();
		$segments   = array();
		$attributes = array();

		foreach ( $meta['selectable'] as $field ) {
			if ( 0 === strpos( $field, 'metrics.' ) ) {
				$metrics[] = $field;
			} elseif ( 0 === strpos( $field, 'segments.' ) ) {
				$segments[] = $field;
			} else {
				$attributes[] = $field;
			}
		}

		return Response::ok(
			array(
				'resource'   => $meta['resource'],
				'selectable' => $meta['selectable'],
				'filterable' => $meta['filterable'],
				'sortable'   => $meta['sortable'],
				'metrics'    => $metrics,
				'segments'   => $segments,
				'attributes' => $attributes,
				'cached'     => (bool) ( $meta['cached'] ?? false ),
			)
		);
	}

	// =========================================================================
	// ads/list-resources
	// =========================================================================

	private static function register_list_resources(): void {
		Ability::register(
			'ads/list-resources',
			'ads',
			array(
				'label'        => __( 'Listar recursos GAQL', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista os recursos GAQL válidos (campaign, ad_group, search_term_view, etc.), filtrando por um trecho do nome. Use para descobrir o recurso certo antes de chamar get-resource-metadata ou search.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'query' => array(
							'type'        => 'string',
							'description' => __( 'Trecho do nome do recurso a procurar (ex.: "campaign"). Vazio lista todos os recursos.', 'wp-mcp-google-fator3' ),
						),
					),
				),
				'callback'     => array( self::class, 'list_resources' ),
			)
		);
	}

	/**
	 * @param array $input Ver input_schema acima.
	 */
	public static function list_resources( array $input ): array {
		$query     = isset( $input['query'] ) ? trim( (string) $input['query'] ) : '';
		$resources = Resources::search( $query );

		return Response::ok(
			array(
				'resources' => $resources,
				'count'     => count( $resources ),
			)
		);
	}

	// =========================================================================
	// ads/list-customer-clients
	// =========================================================================

	private static function register_list_customer_clients(): void {
		Ability::register(
			'ads/list-customer-clients',
			'ads',
			array(
				'label'        => __( 'Listar clientes de uma gerenciadora do Google Ads', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista as contas-cliente sob uma conta gerenciadora (MCC) do Google Ads: id, nome, nível na hierarquia, se também é gerenciadora, status, moeda, fuso e se está oculta.', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'manager_customer_id' => self::customer_id_property( __( 'ID da conta gerenciadora (MCC) cuja hierarquia será listada.', 'wp-mcp-google-fator3' ) ),
						'include_hidden'      => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Inclui clientes marcados como ocultos (hidden = TRUE). Padrão: false.', 'wp-mcp-google-fator3' ),
						),
						'all_levels'          => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => __( 'Lista todos os níveis da hierarquia, não só os clientes diretos (nível ≤ 1). Padrão: false.', 'wp-mcp-google-fator3' ),
						),
					),
					'required'   => array( 'manager_customer_id' ),
				),
				'callback'     => array( self::class, 'list_customer_clients' ),
			)
		);
	}

	/**
	 * @param array $input Ver input_schema acima.
	 * @return array|\WP_Error
	 */
	public static function list_customer_clients( array $input ) {
		$manager_id = CustomerId::normalize( $input['manager_customer_id'] ?? '' );
		if ( is_wp_error( $manager_id ) ) {
			return $manager_id;
		}

		$include_hidden = ! empty( $input['include_hidden'] );
		$all_levels     = ! empty( $input['all_levels'] );

		$result = AdsApi::customer_clients( $manager_id, $include_hidden, $all_levels );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$clients = array();

		foreach ( $result['rows'] as $row ) {
			$clients[] = array(
				'id'         => (string) ( $row['customer_client.id'] ?? '' ),
				'name'       => (string) ( $row['customer_client.descriptive_name'] ?? '' ),
				'level'      => (int) ( $row['customer_client.level'] ?? 0 ),
				'is_manager' => (bool) ( $row['customer_client.manager'] ?? false ),
				'status'     => (string) ( $row['customer_client.status'] ?? '' ),
				'currency'   => (string) ( $row['customer_client.currency_code'] ?? '' ),
				'timezone'   => (string) ( $row['customer_client.time_zone'] ?? '' ),
				'hidden'     => (bool) ( $row['customer_client.hidden'] ?? false ),
			);
		}

		return Response::ok(
			array(
				'clients'   => $clients,
				'count'     => count( $clients ),
				'truncated' => $result['truncated'],
			)
		);
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	/**
	 * Propriedade `customer_id` / `manager_customer_id` compartilhada pelas
	 * habilidades: mesmo tipo e mesma dica de formato em todas.
	 *
	 * @param string $lead Frase inicial específica desta habilidade.
	 */
	/**
	 * Limite pedido pelo agente, dentro do teto do site.
	 *
	 * Zero e negativo são recusados em vez de virarem o padrão: devolver mil
	 * linhas para quem pediu zero é uma resposta que o agente não tem como
	 * perceber que está errada. O esquema já declara `minimum: 1` (o WordPress
	 * 6.9 recusaria sozinho); isto mantém o mesmo comportamento onde a
	 * Abilities API vem de polyfill.
	 *
	 * @param mixed $requested Valor recebido.
	 * @return int|\WP_Error
	 */
	private static function resolve_limit( $requested ) {
		$ceiling = Options::max_rows();

		if ( null === $requested || '' === $requested ) {
			return $ceiling;
		}

		$number = is_numeric( $requested ) ? (float) $requested : 0.0;

		if ( ! is_numeric( $requested ) || 1 > $number || floor( $number ) !== $number ) {
			return new \WP_Error(
				'f3_google_bad_limit',
				__( 'limit precisa ser um número inteiro maior que zero.', 'wp-mcp-google-fator3' )
			);
		}

		return (int) min( $ceiling, (int) $requested );
	}

	private static function customer_id_property( string $lead ): array {
		return array(
			// `integer` entra na lista porque um ID de conta é dez dígitos e o
			// agente frequentemente o manda como número JSON. O WordPress 6.9+
			// valida a entrada contra este esquema antes de executar: com
			// `type: string` sozinho, 1234567890 seria recusado pelo núcleo
			// antes de chegar ao `CustomerId::normalize()`, que aceita os dois.
			'type'        => array( 'string', 'integer' ),
			'description' => $lead . ' ' . __( 'Aceita com ou sem hífens (123-456-7890 ou 1234567890) ou o nome de recurso "customers/1234567890".', 'wp-mcp-google-fator3' ),
		);
	}
}
