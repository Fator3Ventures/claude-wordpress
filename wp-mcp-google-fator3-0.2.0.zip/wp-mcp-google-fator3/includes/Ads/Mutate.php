<?php
/**
 * Google Ads mutations backed by the live REST discovery contract.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Generic\Discovery;
use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class Mutate {
	public static function register(): void {
		Ability::register(
			'ads/mutate',
			'ads',
			array(
				'label'        => 'Mutação genérica do Google Ads',
				'description'  => 'Executa googleAds:mutate com mutateOperations oficiais, inclusive operações de serviços combinados e IDs temporários negativos. operations usa a estrutura MutateOperation da API. dry_run envia validateOnly; partial_failure preserva resultados e erros individuais. Para serviços ausentes de MutateOperation, use google/execute-action.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'customer_id'           => array( 'type' => array( 'string', 'integer' ) ),
						'operations'            => array(
							'type'     => 'array',
							'minItems' => 1,
							'maxItems' => 10000,
							'items'    => array(
								'type'                 => 'object',
								'additionalProperties' => true,
							),
						),
						'partial_failure'       => array(
							'type'    => 'boolean',
							'default' => false,
						),
						'dry_run'               => array(
							'type'    => 'boolean',
							'default' => false,
						),
						'response_content_type' => array(
							'type' => 'string',
							'enum' => array( 'RESOURCE_NAME_ONLY', 'MUTABLE_RESOURCE' ),
						),
						'login_customer_id'     => array( 'type' => 'string' ),
					),
					'required'   => array( 'customer_id', 'operations' ),
				),
				'callback'     => array( self::class, 'run' ),
			)
		);
	}

	public static function run( array $input ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		$ops = $input['operations'] ?? array();
		if ( ! is_array( $ops ) || empty( $ops ) || count( $ops ) > 10000 ) {
			return new \WP_Error( 'f3_google_ads_operations', 'Informe entre 1 e 10000 operações oficiais MutateOperation.' );
		}
		self::audit_before_operations( $cid, $ops );
		foreach ( $ops as $wrapped ) {
			foreach ( $wrapped as $operation ) {
				if ( is_array( $operation ) && isset( $operation['update']['resourceName'] ) ) {
					$input['_snapshot_fields'][ $operation['update']['resourceName'] ] = explode( ',', (string) ( $operation['updateMask'] ?? '' ) ); }
			}
		}
		$body = array(
			'mutateOperations' => array_values( $ops ),
			'partialFailure'   => ! empty( $input['partial_failure'] ),
		);
		if ( isset( $input['response_content_type'] ) ) {
			$body['responseContentType'] = $input['response_content_type']; }
		$result = self::call( 'googleads.customers.googleAds.mutate', $cid, $body, $input );
		return self::result( $result, $input, $cid );
	}

	/** Raw request; inspect the actual request schema for validateOnly support. */
	public static function call( string $method, string $cid, array $body, array $input = array(), array $path = array() ) {
		$doc = Discovery::document( 'google-ads' );
		if ( is_wp_error( $doc ) ) {
			return $doc; }
		$meta = self::find_method( $doc, $method );
		if ( null === $meta ) {
			return new \WP_Error( 'f3_google_ads_method', 'Método inexistente nesta versão da Google Ads API: ' . $method ); }
		$schema = $doc['schemas'][ $meta['request']['$ref'] ?? '' ]['properties'] ?? array();
		$dry    = ! empty( $input['dry_run'] );
		if ( $dry && ! isset( $schema['validateOnly'] ) ) {
			return new \WP_Error( 'f3_google_dry_run_unsupported', 'A Google Ads API não oferece validateOnly para este método. Nenhuma gravação foi enviada; execute sem dry_run quando desejar aplicar a alteração.' );
		}
		if ( isset( $schema['validateOnly'] ) ) {
			$body['validateOnly'] = $dry; }
		if ( ! isset( $schema['partialFailure'] ) ) {
			unset( $body['partialFailure'] ); }
		if ( ! isset( $schema['responseContentType'] ) ) {
			unset( $body['responseContentType'] ); }
		if ( empty( $path ) ) {
			$path = array( 'customerId' => $cid ); }
		return ExecuteAction::call(
			'google-ads',
			$method,
			$path,
			array(),
			$body,
			array(
				'mode'    => 'write',
				'dry_run' => $dry,
				'retries' => 0,
				'headers' => AdsApi::headers( (string) ( $input['login_customer_id'] ?? '' ) ),
			)
		);
	}

	private static function find_method( array $resource_tree, string $id ): ?array {
		foreach ( $resource_tree['methods'] ?? array() as $method ) {
			if ( ( $method['id'] ?? '' ) === $id ) {
				return $method; }
		}
		foreach ( $resource_tree['resources'] ?? array() as $child ) {
			$found = self::find_method( $child, $id );
			if ( null !== $found ) {
				return $found; }
		}
		return null;
	}

	/** A resource name must stay in the explicitly selected customer. */
	public static function resource_name( string $cid, string $collection, $value ) {
		if ( ! is_scalar( $value ) ) {
			return new \WP_Error( 'f3_google_ads_resource', 'Nome de recurso inválido.' ); }
		$value = trim( (string) $value );
		if ( preg_match( '/^-?\d+(?:~[-A-Za-z0-9_]+)*$/D', $value ) ) {
			$value = 'customers/' . $cid . '/' . $collection . '/' . $value; }
		$pattern = '#^customers/' . preg_quote( $cid, '#' ) . '/' . preg_quote( $collection, '#' ) . '/-?\d+(?:~[-A-Za-z0-9_]+)*$#D';
		return preg_match( $pattern, $value ) ? $value : new \WP_Error( 'f3_google_ads_resource', 'Informe um recurso ' . $collection . ' pertencente à conta selecionada (' . $cid . ').' );
	}

	/** Read a real bounded snapshot through GAQL; absence is never inferred from an error. */
	public static function snapshot( string $cid, string $name, array $fields = array() ): array {
		if ( ! preg_match( '#^customers/' . preg_quote( $cid, '#' ) . '/([A-Za-z]+)/[-0-9]+(?:~[-A-Za-z0-9_]+)*$#D', $name, $match ) ) {
			return array(
				'available' => false,
				'reason'    => 'Nome de recurso não disponível para leitura.',
			);
		}
		$map = array(
			'campaigns'                     => 'campaign',
			'campaignBudgets'               => 'campaign_budget',
			'adGroups'                      => 'ad_group',
			'adGroupAds'                    => 'ad_group_ad',
			'adGroupCriteria'               => 'ad_group_criterion',
			'campaignCriteria'              => 'campaign_criterion',
			'conversionActions'             => 'conversion_action',
			'assets'                        => 'asset',
			'campaignAssets'                => 'campaign_asset',
			'adGroupAssets'                 => 'ad_group_asset',
			'assetGroups'                   => 'asset_group',
			'assetGroupAssets'              => 'asset_group_asset',
			'experiments'                   => 'experiment',
			'experimentArms'                => 'experiment_arm',
			'labels'                        => 'label',
			'campaignLabels'                => 'campaign_label',
			'adGroupLabels'                 => 'ad_group_label',
			'userLists'                     => 'user_list',
			'customerUserAccesses'          => 'customer_user_access',
			'customerUserAccessInvitations' => 'customer_user_access_invitation',
			'billingSetups'                 => 'billing_setup',
			'offlineUserDataJobs'           => 'offline_user_data_job',
		);
		if ( ! isset( $map[ $match[1] ] ) ) {
			return array(
				'available' => false,
				'reason'    => 'Este recurso não tem um snapshot GAQL mapeado.',
			); }
		$resource = $map[ $match[1] ];
		$select   = array( $resource . '.resource_name' );
		foreach ( $fields as $field ) {
			$field = self::snake( (string) $field );
			if ( 'resource_name' !== $field && Gaql::identifier_ok( $field ) ) {
				$select[] = $resource . '.' . $field; }
		}
		$query  = Gaql::build( $resource, array_values( array_unique( $select ) ), array( $resource . '.resource_name = ' . \Fator3\McpGoogle\Unified\Filters::quote( $name ) ), array(), 1 );
		$result = AdsApi::search( $cid, $query, array( 'max_rows' => 1 ) );
		if ( is_wp_error( $result ) ) {
			return array(
				'available'     => false,
				'reason'        => $result->get_error_message(),
				'resource_name' => $name,
			); }
		return array(
			'available'     => true,
			'exists'        => ! empty( $result['rows'] ),
			'resource_name' => $name,
			'state'         => $result['rows'][0] ?? array(),
		);
	}

	public static function snake( string $value ): string {
		return strtolower( (string) preg_replace( '/([a-z0-9])([A-Z])/', '$1_$2', $value ) );
	}

	public static function field_mask( array $body, string $prefix = '' ): string {
		$paths = array();
		foreach ( $body as $key => $value ) {
			if ( 'resourceName' === $key ) {
				continue; }
			$path = $prefix . self::snake( (string) $key );
			if ( is_array( $value ) && ! empty( $value ) && array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
				$nested = self::field_mask( $value, $path . '.' );
				if ( '' !== $nested ) {
					$paths[] = $nested; }
			} else {
				$paths[] = $path; }
		}
		return implode( ',', $paths );
	}

	public static function audit_before_operations( string $cid, array $operations ): void {
		$states = array();
		foreach ( array_slice( $operations, 0, 10 ) as $operation ) {
			if ( ! is_array( $operation ) ) {
				continue; }
			if ( ! isset( $operation['create'], $operation['update'], $operation['remove'] ) ) {
				foreach ( $operation as $key => $candidate ) {
					if ( is_array( $candidate ) && substr( (string) $key, -9 ) === 'Operation' ) {
						$operation = $candidate;
						break; }
				}
			}
			if ( isset( $operation['create'] ) ) {
				$states[] = array( 'exists' => false ); } elseif ( isset( $operation['update']['resourceName'] ) ) {
				$states[] = self::snapshot( $cid, (string) $operation['update']['resourceName'], explode( ',', (string) ( $operation['updateMask'] ?? '' ) ) ); } elseif ( isset( $operation['remove'] ) ) {
					$states[] = self::snapshot( $cid, (string) $operation['remove'] ); } else {
					$states[] = array(
						'available' => false,
						'reason'    => 'Operação não permite identificar estado anterior.',
					); }
		}
		Audit::before(
			array(
				'resources' => $states,
				'truncated' => count( $operations ) > 10,
			)
		);
	}

	public static function result( $result, array $input, string $cid = '' ) {
		if ( is_wp_error( $result ) ) {
			return $result; }
		$dry    = ! empty( $input['dry_run'] );
		$names  = self::result_names( $result );
		$states = array();
		if ( ! $dry && '' !== $cid ) {
			foreach ( array_slice( $names, 0, 10 ) as $name ) {
				$states[] = self::snapshot( $cid, $name, $input['_snapshot_fields'][ $name ] ?? array() ); }
		}
		Audit::after(
			! empty( $states ) ? array(
				'resources' => $states,
				'truncated' => count( $names ) > 10,
			) : array(
				'available' => false,
				'reason'    => $dry ? 'validateOnly: nenhuma alteração aplicada.' : 'A API respondeu sem recurso consultável; a resposta da operação não é um snapshot.',
			)
		);
		$data = array(
			'dry_run'        => $dry,
			'result'         => $result,
			'resource_names' => $names,
		);
		if ( ! empty( $result['partialFailureError']['code'] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_ads_partial_failure', (string) ( $result['partialFailureError']['message'] ?? 'Algumas operações falharam; os resultados informam as operações já aplicadas.' ) ), $data + array( 'partial_failure' => true ) );
		}
		return Response::ok( $data, $dry ? 'Validação concluída pela Google Ads API; nenhuma alteração aplicada.' : 'Operação aceita pela Google Ads API.' );
	}

	private static function result_names( array $data ): array {
		$names = array();
		foreach ( $data as $key => $value ) {
			if ( 'resourceName' === $key && is_string( $value ) ) {
				$names[] = $value; } elseif ( is_array( $value ) ) {
				$names = array_merge( $names, self::result_names( $value ) ); }
		}
		return array_values( array_unique( $names ) );
	}
}
