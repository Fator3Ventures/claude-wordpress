<?php
/**
 * Account-specific conversion metrics, without duplicating unsegmented totals.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\Unified\Accounts;
use Fator3\McpGoogle\Unified\Catalog;
use Fator3\McpGoogle\Unified\Filters;
use Fator3\McpGoogle\Unified\Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class Conversions {
	public static function fields( string $account ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return new \WP_Error( 'f3_google_ads_access', (string) ( $gate['message'] ?? 'Acesso Ads não disponível.' ) ); }
		$cid = Accounts::resolve_one( 'ads', $account );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		$query  = Gaql::build( 'conversion_action', array( 'conversion_action.resource_name', 'conversion_action.name', 'conversion_action.status', 'conversion_action.primary_for_goal' ), array( "conversion_action.status != 'REMOVED'" ) );
		$result = AdsApi::search( $cid, $query, array( 'max_rows' => Options::max_rows() ) );
		if ( is_wp_error( $result ) ) {
			return $result; }
		if ( ! empty( $result['truncated'] ) ) {
			return new \WP_Error( 'f3_google_conversion_catalog_truncated', 'O catálogo de ações de conversão excedeu o limite do site. Aumente o limite de linhas para resolver nomes sem omissões.' ); }
		$fields = array();
		$seen   = array();
		foreach ( $result['rows'] as $row ) {
			$name = (string) ( $row['conversion_action.name'] ?? '' );
			if ( '' === $name ) {
				continue; }
			$resource = (string) ( $row['conversion_action.resource_name'] ?? '' );
			if ( isset( $seen[ $name ] ) && $seen[ $name ] !== $resource ) {
				return new \WP_Error( 'f3_google_conversion_ambiguous', 'Mais de uma ação de conversão usa o nome "' . $name . '". Renomeie as ações para distinguir as métricas por nome.' ); }
			$seen[ $name ] = $resource;
			foreach ( array(
				'conversions'       => 'float',
				'conversions_value' => 'currency',
			) as $metric => $kind ) {
				$fields[] = array(
					'id'                              => $metric . ':' . $name,
					'label'                           => ( 'conversions' === $metric ? 'Conversões: ' : 'Valor de conversões: ' ) . $name,
					'native'                          => 'metrics.' . $metric,
					'type'                            => 'metric',
					'kind'                            => $kind,
					'account_id'                      => $cid,
					'conversion_action_name'          => $name,
					'conversion_action_resource_name' => $resource,
					'primary_for_goal'                => (bool) ( $row['conversion_action.primary_for_goal'] ?? false ),
					'description'                     => 'Métrica segmentada por segments.conversion_action_name; preserva a semântica de metrics.' . $metric . ' da Google Ads API.',
				);
			}
		}
		return $fields;
	}

	/** Reuses Query for dates, comparison, account fanout and native field conversion. */
	public static function query( array $input ): array {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		$limit = $input['limit'] ?? Options::max_rows();
		if ( ! is_numeric( $limit ) || (float) $limit < 1 || floor( (float) $limit ) !== (float) $limit ) {
			return self::error( 'limit deve ser um inteiro positivo.' ); }
		$metrics    = self::list( $input['metrics'] ?? array() );
		$dimensions = self::list( $input['dimensions'] ?? array() );
		if ( empty( $metrics ) ) {
			return self::error( 'Informe metrics.' ); }
		foreach ( $dimensions as $dimension ) {
			$entry = Catalog::ads_resolve( $dimension );
			if ( is_wp_error( $entry ) ) {
				return Response::fail( $entry ); }
			if ( 'segments.conversion_action_name' === ( $entry['native'] ?? '' ) || 'segments.conversion_action' === ( $entry['native'] ?? '' ) ) {
				return self::error( 'As métricas conversions:<nome> já representam ações em colunas. Remova conversion_action_name das dimensões ou use conversions nativa segmentada.' ); }
		}
		$filters = Filters::normalize( $input['filters'] ?? array() );
		if ( is_wp_error( $filters ) ) {
			return Response::fail( $filters ); }
		$orders = self::orders( $input['order_by'] ?? ( $input['order_bys'] ?? array() ) );
		if ( is_wp_error( $orders ) ) {
			return Response::fail( $orders ); }
		$custom          = array();
		$common          = array();
		$base_filters    = array();
		$segment_filters = array();
		$custom_filters  = array();
		foreach ( $metrics as $metric ) {
			if ( self::custom( $metric ) ) {
				$custom[ $metric ] = self::custom( $metric );
			} else {
				$common[] = $metric; }
		}
		foreach ( $filters as $filter ) {
			$field      = (string) $filter['field'];
			$definition = self::custom( $field );
			if ( $definition ) {
				$custom[ $field ] = $definition;
				$custom_filters[] = $filter; } else {
				$entry = Catalog::ads_resolve( $field );
				if ( is_wp_error( $entry ) ) {
					return Response::fail( $entry ); }
				$base_filters[] = $filter;
				if ( 'dimension' === $entry['type'] ) {
					$segment_filters[] = $filter; }
				}
		}
		foreach ( $orders as $ordering ) {
			if ( ! in_array( $ordering['field'], array_merge( $metrics, $dimensions, array( 'account_id', 'account_name', 'date_range_name' ) ), true ) ) {
				return self::error( 'Na consulta com conversões personalizadas, inclua o campo de order_by em metrics ou dimensions.' ); }
		}
		$selectors = self::list( $input['accounts'] ?? ( $input['account_id'] ?? array() ) );
		$accounts  = Accounts::resolve_many( 'ads', $selectors );
		if ( is_wp_error( $accounts ) ) {
			return Response::fail( $accounts ); }
		foreach ( $accounts as $account ) {
			$catalog = self::fields( (string) $account );
			if ( is_wp_error( $catalog ) ) {
				return Response::fail( $catalog ); }
			$ids = array_column( $catalog, 'id' );
			foreach ( $custom as $id => $definition ) {
				if ( ! in_array( $id, $ids, true ) ) {
					return self::error( 'A ação de conversão "' . $definition['name'] . '" não existe no catálogo acessível da conta ' . $account . '. Consulte google/list-fields com account_id dessa conta.' ); }
			}
		}
		$base_input              = $input;
		$base_input['connector'] = 'google-ads';
		$base_input['accounts']  = $accounts;
		$base_input['metrics']   = ! empty( $common ) ? $common : array( 'conversions' );
		$base_input['filters']   = $base_filters;
		$base_input['order_by']  = array();
		unset( $base_input['order_bys'] );
		$base_input['limit'] = Options::max_rows();
		$base                = Query::run( $base_input );
		if ( empty( $base['success'] ) ) {
			return $base; }
		$segment_input               = $base_input;
		$segment_input['metrics']    = array( 'conversions', 'conversions_value' );
		$segment_input['dimensions'] = array_merge( $dimensions, array( 'conversion_action_name' ) );
		$segment_input['filters']    = $segment_filters;
		$segmented                   = Query::run( $segment_input );
		if ( empty( $segmented['success'] ) ) {
			return $segmented; }
		if ( ! empty( $segmented['truncated'] ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_conversions_truncated', 'A consulta segmentada por ação atingiu o limite de linhas. Reduza o período/dimensões ou aumente o limite do site; não é seguro transformar ações ausentes em zero.' ),
				array(
					'truncated' => true,
					'warnings'  => $segmented['warnings'] ?? array(),
				)
			); }
		$base_accounts    = array_column( $base['accounts'] ?? array(), 'account_id' );
		$segment_accounts = array_column( $segmented['accounts'] ?? array(), 'account_id' );
		if ( array_diff( $base_accounts, $segment_accounts ) || ! empty( $segmented['warnings'] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_conversions_incomplete', 'Uma conta ou período falhou na consulta segmentada; as métricas por ação não podem ser tratadas como zero.' ), array( 'warnings' => $segmented['warnings'] ?? array() ) ); }
		$base_columns  = $base['columns'];
		$base_index    = array_flip( array_column( $base_columns, 'id' ) );
		$segment_index = array_flip( array_column( $segmented['columns'], 'id' ) );
		$key_fields    = array();
		$columns       = array();
		foreach ( $base_columns as $column ) {
			if ( 'metric' !== $column['type'] ) {
				$key_fields[] = $column['id'];
				$columns[]    = $column; }
		}
		foreach ( $metrics as $metric ) {
			if ( isset( $custom[ $metric ] ) ) {
				$columns[] = array(
					'id'    => $metric,
					'label' => $metric,
					'type'  => 'metric',
					'kind'  => 'conversions_value' === $custom[ $metric ]['metric'] ? 'currency' : 'float',
				); } elseif ( isset( $base_index[ $metric ] ) ) {
				$columns[] = $base_columns[ $base_index[ $metric ] ]; }
		}
		$pivot = array();
		foreach ( $segmented['rows'] as $row ) {
			$key  = self::key( $row, $segment_index, $key_fields );
			$name = (string) ( $row[ $segment_index['conversion_action_name'] ] ?? '' );
			foreach ( $custom as $id => $definition ) {
				if ( $name === $definition['name'] ) {
					// These two metrics are additive across actions. Common totals never enter this sum.
					$pivot[ $key ][ $id ] = ( $pivot[ $key ][ $id ] ?? 0.0 ) + (float) ( $row[ $segment_index[ $definition['metric'] ] ] ?? 0 );
				}
			}
		}
		$rows = array();
		$seen = array();
		foreach ( $base['rows'] as $row ) {
			$key = self::key( $row, $base_index, $key_fields );
			if ( isset( $seen[ $key ] ) ) {
				return self::error( 'Dimensões ambíguas geraram duas linhas para a mesma chave. Acrescente campaign_id/ad_group_id às dimensões; não somamos totais ou médias de linhas indistinguíveis.' ); }
			$seen[ $key ]  = true;
			$custom_values = array();
			foreach ( $custom as $id => $definition ) {
				$custom_values[ $id ] = $pivot[ $key ][ $id ] ?? 0.0; }
			$keep = true;
			foreach ( $custom_filters as $filter ) {
				$matches = self::matches( (float) $custom_values[ $filter['field'] ], $filter );
				if ( is_wp_error( $matches ) ) {
					return Response::fail( $matches ); }
				if ( ! $matches ) {
					$keep = false;
					break; }
			}
			if ( ! $keep ) {
				continue; }
			$line = array();
			foreach ( $columns as $column ) {
				$id     = $column['id'];
				$line[] = array_key_exists( $id, $custom_values ) ? $custom_values[ $id ] : ( $row[ $base_index[ $id ] ] ?? null ); }
			$rows[] = $line;
		}
		$index = array_flip( array_column( $columns, 'id' ) );
		foreach ( $orders as $order ) {
			if ( ! isset( $index[ $order['field'] ] ) ) {
				return self::error( 'Campo de ordenação ausente da tabela: ' . $order['field'] . '. Inclua-o nas dimensões ou métricas.' ); }
		}
		if ( ! empty( $orders ) ) {
			usort(
				$rows,
				static function ( $left, $right ) use ( $orders, $index ) {
					foreach ( $orders as $order ) {
						$i   = $index[ $order['field'] ];
						$cmp = $left[ $i ] <=> $right[ $i ];
						if ( 0 !== $cmp ) {
										return 'asc' === $order['direction'] ? $cmp : -$cmp;
						}
					} return 0;
				}
			);
		}
		$limit = $input['limit'] ?? Options::max_rows();
		if ( ! is_numeric( $limit ) || (float) $limit < 1 || floor( (float) $limit ) !== (float) $limit ) {
			return self::error( 'limit deve ser um inteiro positivo.' ); }
		$limit                               = min( (int) $limit, Options::max_rows() );
		$base['truncated']                   = ! empty( $base['truncated'] ) || count( $rows ) > $limit;
		$base['columns']                     = $columns;
		$base['rows']                        = array_slice( $rows, 0, $limit );
		$base['row_count']                   = count( $base['rows'] );
		$base['request']['conversion_query'] = $segmented['request'] ?? array();
		$base['request']['aggregation']      = 'Totais comuns sem segmentação; conversões por nome obtidas separadamente e cruzadas pelas dimensões, conta e período.';
		$base['message']                     = $base['row_count'] . ' linha(s), preservando totais sem duplicar segmentos de conversão.';
		return $base;
	}

	private static function custom( string $field ): ?array {
		if ( preg_match( '/^(conversions|conversions_value):(.+)$/usD', $field, $parts ) ) {
			return array(
				'metric' => $parts[1],
				'name'   => $parts[2],
			); }
		return null;
	}
	private static function list( $value ): array {
		if ( is_string( $value ) || is_int( $value ) ) {
			$value = array( $value ); }
		return is_array( $value ) ? array_values(
			array_unique(
				array_map(
					static function ( $item ) {
						return is_scalar( $item ) ? trim( (string) $item ) : '';
					},
					$value
				)
			)
		) : array();
	}
	private static function key( array $row, array $index, array $fields ): string {
		$values = array();
		foreach ( $fields as $field ) {
			$values[] = $row[ $index[ $field ] ] ?? null; }
		return (string) wp_json_encode( $values );
	}
	private static function orders( $value ) {
		if ( is_string( $value ) ) {
			$value = array( array( 'field' => $value ) ); }
		if ( isset( $value['field'] ) ) {
			$value = array( $value ); }
		if ( ! is_array( $value ) ) {
			return new \WP_Error( 'f3_google_order_by', 'order_by deve ser uma lista.' ); }
		$out = array(); foreach ( $value as $item ) {
			if ( is_string( $item ) ) {
				$item = array( 'field' => $item ); }
			$direction = strtolower( (string) ( $item['direction'] ?? 'desc' ) );
			if ( ! is_array( $item ) || empty( $item['field'] ) || ! in_array( $direction, array( 'asc', 'desc' ), true ) ) {
				return new \WP_Error( 'f3_google_order_by', 'Cada ordem exige field e direction asc ou desc.' ); }
			$out[] = array(
				'field'     => $item['field'],
				'direction' => $direction,
			);
		} return $out;
	}
	private static function matches( float $value, array $filter ) {
		$wanted = $filter['value'];
		$op     = $filter['operator'];
		if ( 'null' === $op ) {
			return false;
		} if ( 'notnull' === $op ) {
			return true; }
		if ( 'in' === $op ) {
			foreach ( (array) $wanted as $item ) {
				if ( ! is_numeric( $item ) ) {
					return new \WP_Error( 'f3_google_conversion_filter', 'Valores do filtro de conversão devem ser numéricos.' ); }
			}
			return in_array( $value, array_map( 'floatval', (array) $wanted ), true );
		}
		if ( ! is_numeric( $wanted ) ) {
			return new \WP_Error( 'f3_google_conversion_filter', 'Valor do filtro de conversão deve ser numérico.' ); }
		$wanted = (float) $wanted;
		switch ( $op ) {
			case 'eq':
				return $value === $wanted;
			case 'neq':
				return $value !== $wanted;
			case 'gt':
				return $value > $wanted;
			case 'gte':
				return $value >= $wanted;
			case 'lt':
				return $value < $wanted;
			case 'lte':
				return $value <= $wanted;
			default:
				return new \WP_Error( 'f3_google_conversion_filter', 'Métricas de conversão aceitam eq, neq, gt, gte, lt, lte, in, null e notnull.' );
		}
	}
	private static function error( string $message ): array {
		return Response::fail( new \WP_Error( 'f3_google_conversion_query', $message ) ); }
}
