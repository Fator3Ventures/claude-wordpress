<?php
/**
 * Named Google Ads writes and complementary resource reads.
 *
 * @package Fator3\McpGoogle\Ads
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Ads;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;
use Fator3\McpGoogle\Unified\Filters;

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class WriteAbilities {
	/** Collection, operation, singular request operation, native resource. */
	private const ROUTES = array(
		'create-campaign'             => array( 'campaigns', 'create' ),
		'update-campaign'             => array( 'campaigns', 'update' ),
		'remove-campaign'             => array( 'campaigns', 'remove' ),
		'create-budget'               => array( 'campaignBudgets', 'create' ),
		'update-budget'               => array( 'campaignBudgets', 'update' ),
		'create-ad-group'             => array( 'adGroups', 'create' ),
		'update-ad-group'             => array( 'adGroups', 'update' ),
		'remove-ad-group'             => array( 'adGroups', 'remove' ),
		'create-responsive-search-ad' => array( 'adGroupAds', 'create' ),
		'update-ad-status'            => array( 'adGroupAds', 'update' ),
		'remove-ad'                   => array( 'adGroupAds', 'remove' ),
		'add-keywords'                => array( 'adGroupCriteria', 'create', 'batch' ),
		'update-keyword'              => array( 'adGroupCriteria', 'update' ),
		'remove-keywords'             => array( 'adGroupCriteria', 'remove', 'batch' ),
		'add-negative-keywords'       => array( 'criteria', 'create', 'batch' ),
		'remove-negative-keywords'    => array( 'criteria', 'remove', 'batch' ),
		'create-conversion-action'    => array( 'conversionActions', 'create' ),
		'update-conversion-action'    => array( 'conversionActions', 'update' ),
		'create-asset'                => array( 'assets', 'create' ),
		'link-asset'                  => array( 'assetLinks', 'create' ),
		'create-asset-group'          => array( 'assetGroups', 'create' ),
		'create-experiment'           => array( 'experiments', 'create' ),
		'add-label'                   => array( 'labels', 'create' ),
		'apply-label'                 => array( 'labelLinks', 'create' ),
		'add-audience-to-campaign'    => array( 'campaignCriteria', 'create' ),
		'create-user-list'            => array( 'userLists', 'create' ),
		'invite-user'                 => array( 'customerUserAccessInvitations', 'create', 'singular' ),
		'update-user-access'          => array( 'customerUserAccesses', 'update', 'singular' ),
		'remove-user'                 => array( 'customerUserAccesses', 'remove', 'singular' ),
		'create-billing-setup'        => array( 'billingSetups', 'create', 'singular' ),
	);
	private const READS  = array(
		'get-campaign'            => array( 'campaign', array( 'resource_name', 'id', 'name', 'status', 'advertising_channel_type', 'campaign_budget', 'bidding_strategy_type', 'start_date_time', 'end_date_time' ) ),
		'list-conversion-actions' => array( 'conversion_action', array( 'resource_name', 'id', 'name', 'status', 'type', 'category', 'primary_for_goal', 'counting_type' ) ),
		'list-assets'             => array( 'asset', array( 'resource_name', 'id', 'name', 'type' ) ),
		'list-audiences'          => array( 'audience', array( 'resource_name', 'id', 'name', 'description', 'status' ) ),
		'list-users'              => array( 'customer_user_access', array( 'resource_name', 'user_id', 'email_address', 'access_role', 'access_creation_date_time' ) ),
		'list-experiments'        => array( 'experiment', array( 'resource_name', 'experiment_id', 'name', 'status', 'type', 'start_date', 'end_date' ) ),
	);

	public static function register(): void {
		foreach ( self::ROUTES as $route => $spec ) {
			$properties = self::common_schema();
			$required   = array( 'customer_id' );
			if ( 'remove' === $spec[1] ) {
				if ( 'batch' === ( $spec[2] ?? '' ) ) {
					$properties['resource_names'] = array(
						'type'     => 'array',
						'items'    => array( 'type' => 'string' ),
						'minItems' => 1,
					);
					$required[]                   = 'resource_names'; } else {
					$properties['resource_name'] = array( 'type' => 'string' );
					$required[]                  = 'resource_name'; }
			} elseif ( 'batch' === ( $spec[2] ?? '' ) ) {
				$properties['resources'] = self::object_list( 'Recursos oficiais adGroupCriterion ou campaignCriterion (camelCase), um objeto por palavra-chave; inclua keyword.text e keyword.matchType.' );
				$required[]              = 'resources';
			} else {
				$properties['resource'] = self::object_schema( 'Recurso oficial da API em camelCase. Atualizações incluem resourceName. Descubra os campos em google/list-actions. Valores monetários em micros seguem o contrato Google.' );
				$required[]             = 'resource';
			}
			if ( 'update' === $spec[1] ) {
				$properties['update_mask'] = array(
					'type'        => 'string',
					'description' => 'FieldMask em snake_case; ausente é calculada dos campos enviados, incluindo caminhos aninhados.',
				); }
			if ( in_array( $spec[0], array( 'criteria', 'assetLinks', 'labelLinks' ), true ) ) {
				$properties['level'] = array(
					'type'    => 'string',
					'enum'    => array( 'campaign', 'ad_group' ),
					'default' => 'campaign',
				); }
			if ( 'create-asset-group' === $route ) {
				$properties['assets'] = self::object_list( 'Recursos AssetGroupAsset (asset, fieldType, etc.). Ligação ao novo grupo é acrescentada usando ID temporário, em uma única mutação atômica.' ); }
			if ( 'create-experiment' === $route ) {
				$properties['arms'] = self::object_list( 'Recursos ExperimentArm: name, campaigns, control e trafficSplit. experiment é preenchido com ID temporário em uma mutação atômica.' ); }
			Ability::register(
				'ads/' . $route,
				'ads',
				array(
					'label'        => 'Google Ads: ' . $route,
					'description'  => self::description( $route, $spec ),
					'mode'         => 'write',
					'input_schema' => array(
						'properties' => $properties,
						'required'   => $required,
					),
					'callback'     => static function ( array $input ) use ( $route ) {
						return self::execute( $route, $input ); },
				)
			);
		}
		foreach ( self::READS as $route => $spec ) {
			$props    = array(
				'customer_id'       => array( 'type' => array( 'string', 'integer' ) ),
				'fields'            => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'description' => 'Campos GAQL completos opcionais; padrão seleciona identidade e configuração do recurso.',
				),
				'conditions'        => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
				'limit'             => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'page_token'        => array( 'type' => 'string' ),
				'login_customer_id' => array( 'type' => 'string' ),
			);
			$required = array( 'customer_id' );
			if ( 'get-campaign' === $route ) {
				$props['resource_name'] = array(
					'type'        => 'string',
					'description' => 'Nome customers/{customer}/campaigns/{id} ou ID da campanha.',
				);
				$required[]             = 'resource_name'; }
			Ability::register(
				'ads/' . $route,
				'ads',
				array(
					'label'        => 'Google Ads: ' . $route,
					'description'  => 'Consulta GAQL de leitura de ' . $spec[0] . ', com paginação e limite explícitos.',
					'input_schema' => array(
						'properties' => $props,
						'required'   => $required,
					),
					'callback'     => static function ( array $input ) use ( $route ) {
						return self::read( $route, $input ); },
				)
			);
		}
		self::register_special();
	}

	private static function description( string $route, array $spec ): string {
		$text = 'Aplica ' . $route . ' via Google Ads API. O recurso usa campos oficiais camelCase, sem alterar status ou orçamento implicitamente. ';
		return $text . ( 'singular' === ( $spec[2] ?? '' ) ? 'Este método não aceita validateOnly: dry_run=true é recusado antes da gravação.' : 'dry_run=true usa validateOnly real.' );
	}
	private static function common_schema(): array {
		return array(
			'customer_id'       => array( 'type' => array( 'string', 'integer' ) ),
			'dry_run'           => array(
				'type'    => 'boolean',
				'default' => false,
			),
			'partial_failure'   => array(
				'type'    => 'boolean',
				'default' => false,
			),
			'login_customer_id' => array( 'type' => 'string' ),
		);
	}
	private static function object_schema( string $description = '' ): array {
		return array(
			'type'                 => 'object',
			'additionalProperties' => true,
			'description'          => $description,
		); }
	private static function object_list( string $description = '' ): array {
		return array(
			'type'        => 'array',
			'items'       => self::object_schema(),
			'maxItems'    => 10000,
			'description' => $description,
		); }

	public static function execute( string $route, array $input ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		if ( ! isset( self::ROUTES[ $route ] ) ) {
			return new \WP_Error( 'f3_google_ads_route', 'Rota Ads desconhecida.' ); }
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		$spec       = self::ROUTES[ $route ];
		$collection = $spec[0];
		$kind       = $spec[1];
		if ( 'singular' === ( $spec[2] ?? '' ) && ! empty( $input['dry_run'] ) ) {
			return new \WP_Error( 'f3_google_dry_run_unsupported', 'Este método não oferece validateOnly. Nenhuma alteração foi enviada; execute sem dry_run para aplicar.' );
		}
		$level = $input['level'] ?? 'campaign';
		if ( ! in_array( $level, array( 'campaign', 'ad_group' ), true ) ) {
			return new \WP_Error( 'f3_google_ads_level', 'level precisa ser campaign ou ad_group.' ); }
		if ( 'criteria' === $collection ) {
			$collection = 'ad_group' === $level ? 'adGroupCriteria' : 'campaignCriteria'; }
		if ( 'assetLinks' === $collection ) {
			$collection = 'ad_group' === $level ? 'adGroupAssets' : 'campaignAssets'; }
		if ( 'labelLinks' === $collection ) {
			$collection = 'ad_group' === $level ? 'adGroupLabels' : 'campaignLabels'; }
		$batch = 'batch' === ( $spec[2] ?? '' );
		$items = 'remove' === $kind ? ( $batch ? ( $input['resource_names'] ?? array() ) : array( $input['resource_name'] ?? '' ) ) : ( $batch ? ( $input['resources'] ?? array() ) : array( $input['resource'] ?? array() ) );
		if ( ! is_array( $items ) || empty( $items ) || count( $items ) > 10000 ) {
			return new \WP_Error( 'f3_google_ads_resources', 'Informe entre 1 e 10000 recursos.' ); }
		$operations = array();
		foreach ( $items as $item ) {
			if ( 'remove' === $kind ) {
				$name = Mutate::resource_name( $cid, $collection, $item );
				if ( is_wp_error( $name ) ) {
					return $name; }
				$operations[] = array( 'remove' => $name );
				continue;
			}
			if ( ! is_array( $item ) || empty( $item ) ) {
				return new \WP_Error( 'f3_google_ads_resource', 'Informe o objeto resource com os campos oficiais da API.' ); }
			if ( 'create-responsive-search-ad' === $route && empty( $item['ad']['responsiveSearchAd'] ) ) {
				return new \WP_Error( 'f3_google_ads_rsa', 'resource deve conter adGroup e ad.responsiveSearchAd (headlines, descriptions e ad.finalUrls).' ); }
			if ( 'update-ad-status' === $route ) {
				if ( ! isset( $item['status'] ) ) {
					return new \WP_Error( 'f3_google_ads_status', 'Informe resource.resourceName e resource.status.' ); }
				$item                 = array_intersect_key( $item, array_flip( array( 'resourceName', 'status' ) ) );
				$input['update_mask'] = 'status';
			}
			if ( 'add-negative-keywords' === $route ) {
				$item['negative'] = true; }
			if ( 'add-keywords' === $route && ! empty( $item['negative'] ) ) {
				return new \WP_Error( 'f3_google_ads_keyword', 'Para palavras-chave negativas, use ads/add-negative-keywords.' ); }
			if ( 'update' === $kind ) {
				$name = Mutate::resource_name( $cid, $collection, $item['resourceName'] ?? '' );
				if ( is_wp_error( $name ) ) {
					return $name; }
				$item['resourceName'] = $name;
				$mask                 = trim( (string) ( $input['update_mask'] ?? Mutate::field_mask( $item ) ) );
				if ( '' === $mask || ! preg_match( '/^[a-zA-Z][a-zA-Z0-9_.]*(?:,[a-zA-Z][a-zA-Z0-9_.]*)*$/D', $mask ) ) {
					return new \WP_Error( 'f3_google_ads_mask', 'Informe uma update_mask válida, com os campos alterados.' ); }
				$operations[] = array(
					'update'     => $item,
					'updateMask' => $mask,
				);
			} else {
				$operations[] = array( 'create' => $item ); }
		}
		if ( 'create-asset-group' === $route && ! empty( $input['assets'] ) ) {
			return self::compound_create( $cid, $operations[0]['create'], 'assetGroupOperation', 'assetGroups', 'assetGroupAssetOperation', 'assetGroup', $input['assets'], $input ); }
		if ( 'create-experiment' === $route && ! empty( $input['arms'] ) ) {
			return self::compound_create( $cid, $operations[0]['create'], 'experimentOperation', 'experiments', 'experimentArmOperation', 'experiment', $input['arms'], $input ); }
		Mutate::audit_before_operations( $cid, $operations );
		foreach ( $operations as $operation ) {
			if ( isset( $operation['update']['resourceName'] ) ) {
				$input['_snapshot_fields'][ $operation['update']['resourceName'] ] = explode( ',', (string) $operation['updateMask'] ); }
		}
		$body   = 'singular' === ( $spec[2] ?? '' ) ? array( 'operation' => $operations[0] ) : array(
			'operations'     => $operations,
			'partialFailure' => ! empty( $input['partial_failure'] ),
		);
		$result = Mutate::call( 'googleads.customers.' . $collection . '.mutate', $cid, $body, $input );
		return Mutate::result( $result, $input, $cid );
	}

	private static function compound_create( string $cid, array $new_resource, string $parent_operation, string $collection, string $child_operation, string $parent_field, $children, array $input ) {
		if ( ! is_array( $children ) || count( $children ) > 9999 ) {
			return new \WP_Error( 'f3_google_ads_children', 'Lista de recursos dependentes inválida (máximo 9999).' ); }
		if ( ! empty( $input['partial_failure'] ) ) {
			return new \WP_Error( 'f3_google_ads_atomic', 'Criação com recursos dependentes exige partial_failure=false para manter as referências temporárias e a atomicidade.' ); }
		$temp                         = 'customers/' . $cid . '/' . $collection . '/-1';
		$new_resource['resourceName'] = $temp;
		$operations                   = array( array( $parent_operation => array( 'create' => $new_resource ) ) );
		foreach ( $children as $child ) {
			if ( ! is_array( $child ) || empty( $child ) ) {
				return new \WP_Error( 'f3_google_ads_child', 'Cada recurso dependente deve ser um objeto oficial da API.' ); }
			$child[ $parent_field ] = $temp;
			$operations[]           = array( $child_operation => array( 'create' => $child ) );
		}
		return Mutate::run(
			array_merge(
				$input,
				array(
					'customer_id'     => $cid,
					'operations'      => $operations,
					'partial_failure' => false,
				)
			)
		);
	}

	public static function read( string $route, array $input ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		if ( ! isset( self::READS[ $route ] ) ) {
			return new \WP_Error( 'f3_google_ads_route', 'Rota Ads desconhecida.' ); }
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		$spec     = self::READS[ $route ];
		$resource = $spec[0];
		$fields   = $input['fields'] ?? array_map(
			static function ( $field ) use ( $resource ) {
				return $resource . '.' . $field;
			},
			$spec[1]
		);
		if ( ! is_array( $fields ) || empty( $fields ) ) {
			return new \WP_Error( 'f3_google_ads_fields', 'fields deve ser uma lista de campos GAQL.' ); }
		foreach ( $fields as $field ) {
			if ( ! is_string( $field ) || ! Gaql::identifier_ok( $field ) ) {
				return new \WP_Error( 'f3_google_ads_field', 'Campo GAQL inválido.' ); }
		}
		$conditions = $input['conditions'] ?? array();
		if ( ! is_array( $conditions ) ) {
			return new \WP_Error( 'f3_google_ads_conditions', 'conditions deve ser uma lista.' ); }
		foreach ( $conditions as $condition ) {
			if ( ! is_string( $condition ) || ! Gaql::condition_ok( $condition ) ) {
				return new \WP_Error( 'f3_google_ads_condition', 'Condição GAQL inválida.' ); }
		}
		if ( 'get-campaign' === $route ) {
			$name = Mutate::resource_name( $cid, 'campaigns', $input['resource_name'] ?? '' );
			if ( is_wp_error( $name ) ) {
				return $name; }
			$conditions[] = 'campaign.resource_name = ' . Filters::quote( $name );
		}
		$limit = $input['limit'] ?? Options::max_rows();
		if ( ! is_numeric( $limit ) || (float) $limit < 1 || floor( (float) $limit ) !== (float) $limit ) {
			return new \WP_Error( 'f3_google_bad_limit', 'limit deve ser inteiro positivo.' ); }
		$limit  = 'get-campaign' === $route ? 1 : min( (int) $limit, Options::max_rows() );
		$query  = Gaql::build( $resource, array_values( $fields ), $conditions, array(), $limit );
		$result = AdsApi::search(
			$cid,
			$query,
			array(
				'max_rows'          => $limit,
				'page_token'        => (string) ( $input['page_token'] ?? '' ),
				'login_customer_id' => (string) ( $input['login_customer_id'] ?? '' ),
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result; }
		return Response::ok(
			array(
				'rows'            => $result['rows'],
				'row_count'       => count( $result['rows'] ),
				'truncated'       => $result['truncated'],
				'next_page_token' => $result['next_page_token'],
				'query'           => $query,
			)
		);
	}

	private static function register_special(): void {
		$props                  = self::common_schema();
		$props['resource_name'] = array(
			'type'        => 'string',
			'description' => 'customers/{customer}/experiments/{experiment} ou ID.',
		);
		Ability::register(
			'ads/schedule-experiment',
			'ads',
			array(
				'label'        => 'Agendar experimento Google Ads',
				'description'  => 'Agenda um experimento já criado com braços e datas configurados. Retorna a operação assíncrona da Google. dry_run usa validateOnly.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => $props,
					'required'   => array( 'customer_id', 'resource_name' ),
				),
				'callback'     => array( self::class, 'schedule_experiment' ),
			)
		);
		$props                               = self::common_schema();
		$props['partial_failure']['default'] = true;
		$props['conversions']                = self::object_list( 'ClickConversion oficiais: gclid/gbraid/wbraid, conversionAction, conversionDateTime, conversionValue, currencyCode, etc.' );
		$props['job_id']                     = array(
			'type'    => 'integer',
			'minimum' => 0,
			'maximum' => 2147483647,
		);
		Ability::register(
			'ads/upload-click-conversions',
			'ads',
			array(
				'label'        => 'Enviar conversões de clique',
				'description'  => 'Envia ClickConversion para a conta selecionada. A API exige partialFailure=true; erros por conversão ficam explícitos na resposta. dry_run usa validateOnly.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => $props,
					'required'   => array( 'customer_id', 'conversions' ),
				),
				'callback'     => array( self::class, 'upload_click_conversions' ),
			)
		);
		$props                               = self::common_schema();
		$props['partial_failure']['default'] = true;
		$props['user_list']                  = array(
			'type'        => 'string',
			'description' => 'customers/{customer}/userLists/{id}; necessário ao criar um job.',
		);
		$props['job_resource_name']          = array(
			'type'        => 'string',
			'description' => 'Job PENDING existente. Obrigatório para dry_run, pois validateOnly não cria um ID de job.',
		);
		$props['users']                      = self::object_list( 'Usuários com email, phone (E.164), first_name, last_name, country_code, postal_code, mobile_id, third_party_user_id ou userIdentifiers oficiais já hasheados. Identificadores pessoais são normalizados e SHA-256 antes do envio; não entram na auditoria.' );
		$props['operation']                  = array(
			'type'    => 'string',
			'enum'    => array( 'create', 'remove' ),
			'default' => 'create',
		);
		$props['consent']                    = self::object_schema( 'Consent oficial, adUserData e adPersonalization. Não presumimos consentimento.' );
		$props['run_job']                    = array(
			'type'    => 'boolean',
			'default' => true,
		);
		Ability::register(
			'ads/upload-customer-match',
			'ads',
			array(
				'label'        => 'Enviar Customer Match',
				'description'  => 'Executa create → addOperations → run de OfflineUserDataJob, com SHA-256 e retorno da operação assíncrona. Disponível para integrações Ads elegíveis existentes; desde abril de 2026 a Google exige Data Manager API para a maioria das novas integrações. dry_run precisa de job_resource_name existente e valida cada chamada sem criar/executar o job.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => $props,
					'required'   => array( 'customer_id', 'users' ),
				),
				'callback'     => array( self::class, 'upload_customer_match' ),
			)
		);
	}

	public static function schedule_experiment( array $input ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		$name = Mutate::resource_name( $cid, 'experiments', $input['resource_name'] ?? '' );
		if ( is_wp_error( $name ) ) {
			return $name; }
		Audit::before( Mutate::snapshot( $cid, $name, array( 'status', 'startDate', 'endDate' ) ) );
		$result = Mutate::call( 'googleads.customers.experiments.scheduleExperiment', $cid, array(), $input, array( 'resourceName' => $name ) );
		if ( ! is_wp_error( $result ) ) {
			Audit::after(
				! empty( $input['dry_run'] ) ? array(
					'available' => false,
					'reason'    => 'validateOnly: nenhuma alteração aplicada.',
				) : Mutate::snapshot( $cid, $name, array( 'status', 'longRunningOperation' ) )
			); }
		return is_wp_error( $result ) ? $result : Response::ok(
			array(
				'dry_run'       => ! empty( $input['dry_run'] ),
				'operation'     => $result,
				'resource_name' => $name,
				'asynchronous'  => empty( $input['dry_run'] ),
			)
		);
	}

	public static function upload_click_conversions( array $input ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		if ( empty( $input['conversions'] ) || ! is_array( $input['conversions'] ) ) {
			return new \WP_Error( 'f3_google_ads_conversions', 'Informe conversions com ClickConversion oficiais.' ); }
		if ( isset( $input['partial_failure'] ) && ! $input['partial_failure'] ) {
			return new \WP_Error( 'f3_google_ads_partial_failure_required', 'uploadClickConversions exige partial_failure=true.' ); }
		$body = array(
			'conversions'    => array_values( $input['conversions'] ),
			'partialFailure' => true,
		);
		if ( isset( $input['job_id'] ) ) {
			$body['jobId'] = $input['job_id']; }
		Audit::before(
			array(
				'available' => false,
				'reason'    => 'Conversões enviadas não possuem leitura individual de estado anterior.',
			)
		);
		return Mutate::result( Mutate::call( 'googleads.customers.uploadClickConversions', $cid, $body, $input ), $input );
	}

	public static function upload_customer_match( array $input ) {
		$gate = Gate::check( 'ads' );
		if ( null !== $gate ) {
			return $gate; }
		$cid = CustomerId::normalize( $input['customer_id'] ?? '' );
		if ( is_wp_error( $cid ) ) {
			return $cid; }
		$dry = ! empty( $input['dry_run'] );
		$job = trim( (string) ( $input['job_resource_name'] ?? '' ) );
		if ( $dry && '' === $job ) {
			return new \WP_Error( 'f3_google_ads_customer_match_dry_run', 'Para validar usuários sem criar um job, informe job_resource_name de um job PENDING existente. validateOnly de create não devolve um ID para validar addOperations. Nenhuma requisição de gravação foi enviada.' ); }
		$operation = $input['operation'] ?? 'create';
		if ( ! in_array( $operation, array( 'create', 'remove' ), true ) ) {
			return new \WP_Error( 'f3_google_ads_customer_match_operation', 'operation deve ser create ou remove; não misture os dois no mesmo job.' ); }
		$users = $input['users'] ?? array();
		if ( ! is_array( $users ) || empty( $users ) || count( $users ) > 10000 ) {
			return new \WP_Error( 'f3_google_ads_customer_match_users', 'Informe de 1 a 10000 usuários por chamada.' ); }
		$operations = array();
		foreach ( $users as $index => $user ) {
			if ( ! is_array( $user ) ) {
				return new \WP_Error( 'f3_google_ads_customer_match_user', 'Cada usuário deve ser um objeto.' ); }
			$data = self::normalize_user( $user );
			if ( is_wp_error( $data ) ) {
				return new \WP_Error( $data->get_error_code(), 'Usuário ' . ( $index + 1 ) . ': ' . $data->get_error_message() ); }
			$operations[] = array( $operation => $data );
		}
		$created = false;
		if ( '' === $job ) {
			$list = Mutate::resource_name( $cid, 'userLists', $input['user_list'] ?? '' );
			if ( is_wp_error( $list ) ) {
				return $list; }
			$metadata = array( 'userList' => $list );
			if ( isset( $input['consent'] ) ) {
				$metadata['consent'] = $input['consent']; }
			Audit::before( array( 'exists' => false ) );
			$response = Mutate::call(
				'googleads.customers.offlineUserDataJobs.create',
				$cid,
				array(
					'job' => array(
						'type'                          => 'CUSTOMER_MATCH_USER_LIST',
						'customerMatchUserListMetadata' => $metadata,
					),
				),
				$input
			);
			if ( is_wp_error( $response ) ) {
				return $response; }
			$job     = (string) ( $response['resourceName'] ?? '' );
			$created = true;
		}
		$job = Mutate::resource_name( $cid, 'offlineUserDataJobs', $job );
		if ( is_wp_error( $job ) ) {
			return $job; }
		if ( ! $created ) {
			Audit::before( Mutate::snapshot( $cid, $job, array( 'status', 'type' ) ) ); }
		$response = Mutate::call(
			'googleads.customers.offlineUserDataJobs.addOperations',
			$cid,
			array(
				'operations'           => $operations,
				'enablePartialFailure' => ! isset( $input['partial_failure'] ) || (bool) $input['partial_failure'],
				'enableWarnings'       => true,
			),
			$input,
			array( 'resourceName' => $job )
		);
		if ( is_wp_error( $response ) ) {
			Audit::after(
				array(
					'available'         => true,
					'job_resource_name' => $job,
					'job_created'       => $created,
					'stage'             => 'addOperations_failed',
				)
			);
			return Response::fail(
				$response,
				array(
					'job_resource_name' => $job,
					'job_created'       => $created,
					'stage'             => 'addOperations',
					'dry_run'           => $dry,
				)
			);
		}
		$run        = $input['run_job'] ?? true;
		$run_result = null;
		// Preserve accepted operations in PENDING on partial failure so the caller can inspect and explicitly run the retained job.
		if ( ! empty( $response['partialFailureError']['code'] ) ) {
			Audit::after(
				array(
					'available'         => true,
					'job_resource_name' => $job,
					'job_created'       => $created,
					'stage'             => 'operations_partially_accepted',
					'run_requested'     => false,
				)
			);
			return Response::fail(
				new \WP_Error( 'f3_google_ads_partial_failure', (string) ( $response['partialFailureError']['message'] ?? 'Parte dos usuários falhou.' ) ),
				array(
					'job_resource_name' => $job,
					'result'            => $response,
					'partial_failure'   => true,
					'job_started'       => false,
					'dry_run'           => $dry,
					'next_action'       => 'Inspecione os erros. Operações aceitas permanecem no job PENDING; execute offlineUserDataJobs.run via google/execute-action quando desejar processá-las.',
				)
			);
		}
		if ( $run ) {
			$run_result = Mutate::call( 'googleads.customers.offlineUserDataJobs.run', $cid, array(), $input, array( 'resourceName' => $job ) );
			if ( is_wp_error( $run_result ) ) {
				Audit::after(
					array(
						'available'         => true,
						'job_resource_name' => $job,
						'stage'             => 'operations_accepted_run_failed',
					)
				);
				return Response::fail(
					$run_result,
					array(
						'job_resource_name' => $job,
						'stage'             => 'run',
						'users_uploaded'    => count( $users ),
						'dry_run'           => $dry,
					)
				);
			}
		}
		Audit::after(
			$dry ? array(
				'available' => false,
				'reason'    => 'validateOnly: usuários não adicionados e job não executado.',
			) : Mutate::snapshot( $cid, $job, array( 'status', 'type' ) )
		);
		return Response::ok(
			array(
				'job_resource_name' => $job,
				'job_created'       => $created,
				'job_started'       => $run && ! $dry,
				'dry_run'           => $dry,
				'users_submitted'   => count( $users ),
				'result'            => $response,
				'operation'         => $run_result,
				'asynchronous'      => $run && ! $dry,
				'warnings'          => array( 'Desde 01/04/2026, a maioria das novas integrações Customer Match deve usar a Data Manager API. Este fluxo requer elegibilidade para OfflineUserDataJob na Google Ads API.', 'Aceitação do job não confirma correspondência nem disponibilidade imediata da audiência.' ),
			)
		);
	}

	/** Google normalization rules; never log or return input identifiers. */
	public static function normalize_user( array $user ) {
		$ids = array();
		if ( isset( $user['userIdentifiers'] ) ) {
			if ( ! is_array( $user['userIdentifiers'] ) ) {
				return new \WP_Error( 'f3_google_ads_identifiers', 'userIdentifiers deve ser uma lista.' ); }
			foreach ( $user['userIdentifiers'] as $id ) {
				if ( ! is_array( $id ) ) {
					return new \WP_Error( 'f3_google_ads_identifiers', 'Identificador inválido.' ); }
				$oneof = array_intersect( array_keys( $id ), array( 'hashedEmail', 'hashedPhoneNumber', 'addressInfo', 'mobileId', 'thirdPartyUserId' ) );
				if ( 1 !== count( $oneof ) || array_diff( array_keys( $id ), array_merge( $oneof, array( 'userIdentifierSource' ) ) ) ) {
					return new \WP_Error( 'f3_google_ads_identifiers', 'Cada userIdentifier deve conter exatamente um identificador oficial.' ); }
				foreach ( array( 'hashedEmail', 'hashedPhoneNumber' ) as $key ) {
					if ( isset( $id[ $key ] ) && ! preg_match( '/^[a-f0-9]{64}$/iD', (string) $id[ $key ] ) ) {
						return new \WP_Error( 'f3_google_ads_hash', 'Hashes existentes devem ser SHA-256 hexadecimal (64 caracteres).' ); }
				}
				if ( isset( $id['addressInfo'] ) ) {
					foreach ( array( 'hashedFirstName', 'hashedLastName', 'hashedStreetAddress' ) as $hash_field ) {
						if ( isset( $id['addressInfo'][ $hash_field ] ) && ! preg_match( '/^[a-f0-9]{64}$/iD', (string) $id['addressInfo'][ $hash_field ] ) ) {
							return new \WP_Error( 'f3_google_ads_hash', 'Campos hashed de addressInfo devem ser hashes SHA-256 de 64 caracteres.' ); }
					}
					foreach ( array( 'hashedFirstName', 'hashedLastName' ) as $key ) {
						if ( empty( $id['addressInfo'][ $key ] ) || ! preg_match( '/^[a-f0-9]{64}$/iD', (string) $id['addressInfo'][ $key ] ) ) {
							return new \WP_Error( 'f3_google_ads_hash', 'addressInfo exige nome e sobrenome previamente hasheados em SHA-256.' ); }
					}
				}
				$ids[] = $id;
			}
		}
		if ( ! empty( $user['email'] ) ) {
			$email = strtolower( (string) preg_replace( '/\s+/u', '', trim( (string) $user['email'] ) ) );
			if ( ! filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
				return new \WP_Error( 'f3_google_ads_email', 'Email inválido.' ); }
			list( $local, $domain ) = explode( '@', $email, 2 );
			if ( in_array( $domain, array( 'gmail.com', 'googlemail.com' ), true ) ) {
				$local = str_replace( '.', '', $local ); }
			$ids[] = array( 'hashedEmail' => hash( 'sha256', $local . '@' . $domain ) );
		}
		if ( ! empty( $user['phone'] ) ) {
			$phone = (string) preg_replace( '/[\s().-]+/', '', (string) $user['phone'] );
			if ( ! preg_match( '/^\+[1-9][0-9]{7,14}$/D', $phone ) ) {
				return new \WP_Error( 'f3_google_ads_phone', 'phone deve estar em E.164 com código do país, por exemplo +5511999999999; não presumimos DDI.' ); }
			$ids[] = array( 'hashedPhoneNumber' => hash( 'sha256', $phone ) );
		}
		if ( isset( $user['first_name'] ) || isset( $user['last_name'] ) ) {
			foreach ( array( 'first_name', 'last_name', 'country_code', 'postal_code' ) as $key ) {
				if ( empty( $user[ $key ] ) ) {
					return new \WP_Error( 'f3_google_ads_address', 'Endereço exige first_name, last_name, country_code e postal_code.' ); }
			}
			if ( ! function_exists( 'mb_strtolower' ) && preg_match( '/[^\x00-\x7f]/', (string) $user['first_name'] . (string) $user['last_name'] ) ) {
				return new \WP_Error( 'f3_google_ads_unicode_hash', 'A normalização de nomes com caracteres Unicode exige a extensão PHP mbstring; habilite-a ou informe userIdentifiers já normalizados e hasheados.' );
			}
			$first   = self::normalize_name( (string) $user['first_name'] );
			$last    = self::normalize_name( (string) $user['last_name'] );
			$country = strtoupper( trim( (string) $user['country_code'] ) );
			if ( ! preg_match( '/^[A-Z]{2}$/D', $country ) ) {
				return new \WP_Error( 'f3_google_ads_country', 'country_code deve ser ISO de duas letras.' ); }
			$ids[] = array(
				'addressInfo' => array(
					'hashedFirstName' => hash( 'sha256', $first ),
					'hashedLastName'  => hash( 'sha256', $last ),
					'countryCode'     => $country,
					'postalCode'      => trim( (string) $user['postal_code'] ),
				),
			);
		}
		foreach ( array(
			'mobile_id'           => 'mobileId',
			'third_party_user_id' => 'thirdPartyUserId',
		) as $key => $native ) {
			if ( ! empty( $user[ $key ] ) ) {
				$ids[] = array( $native => trim( (string) $user[ $key ] ) ); }
		}
		if ( empty( $ids ) || count( $ids ) > 20 ) {
			return new \WP_Error( 'f3_google_ads_identifiers', 'Cada usuário exige de 1 a 20 identificadores.' ); }
		$data = array( 'userIdentifiers' => $ids );
		if ( isset( $user['consent'] ) ) {
			$data['consent'] = $user['consent']; }
		return $data;
	}

	private static function normalize_name( string $name ): string {
		$name = trim( $name );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
	}
}
