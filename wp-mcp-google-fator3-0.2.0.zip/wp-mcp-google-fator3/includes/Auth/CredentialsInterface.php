<?php
/**
 * Contrato das credenciais Google.
 *
 * Os dois modos de autenticação (service account e OAuth de usuário) diferem em
 * tudo — um assina JWT, o outro troca refresh token — mas o resto do plugin só
 * precisa de duas coisas: um access token para certos escopos e uma descrição
 * sem segredos para mostrar na tela. É o que esta interface fixa.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Auth;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface CredentialsInterface {

	/**
	 * @param array $scopes Escopos OAuth pedidos.
	 * @return string|\WP_Error Access token válido.
	 */
	public function get_access_token( array $scopes );

	/**
	 * Descrição sem segredos.
	 *
	 * @return array{mode:string,identity:string,configured:bool}
	 */
	public function describe(): array;
}
