<?php
/**
 * Executor REST limitado ao contrato de cada método oficial de descoberta.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Generic;

use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Ads\CustomerId;
use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ExecuteAction {

	/**
	 * Uma chamada interna não substitui snapshots registrados pelo módulo.
	 *
	 * @return array|\WP_Error Resultado JSON cru da API.
	 */
	public static function call( string $api, string $method, array $path_params = array(), array $query = array(), ?array $body = null, array $opts = array() ) {
		$api = Discovery::canonical( $api );
		if ( is_wp_error( $api ) ) {
			return $api;
		}
		$connector = Discovery::connector( $api );
		$gate      = Gate::check( $connector );
		if ( null !== $gate ) {
			return new \WP_Error( (string) ( $gate['error_code'] ?? 'f3_google_forbidden' ), (string) $gate['message'], $gate['details'] ?? null );
		}
		$document = Discovery::document( $api );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$metadata = Discovery::method( $api, $method );
		if ( is_wp_error( $metadata ) ) {
			return $metadata;
		}
		$prepared = self::prepare( $api, $metadata, $document, $path_params, $query, $body, $opts );
		if ( is_wp_error( $prepared ) ) {
			return $prepared;
		}
		$scopes = self::scopes( $metadata, $connector );
		if ( is_wp_error( $scopes ) ) {
			return $scopes;
		}
		$http_opts = array(
			'scopes'    => $scopes,
			'connector' => $connector,
			'mode'      => 'read' === ( $opts['mode'] ?? 'write' ) ? 'read' : 'write',
			'query'     => $prepared['query'],
		);
		if ( 'write' === $http_opts['mode'] ) {
			$http_opts['retries'] = 0;
		} elseif ( isset( $opts['retries'] ) ) {
			$http_opts['retries'] = max( 0, min( 2, (int) $opts['retries'] ) );
		}
		if ( 'google-ads' === $api ) {
			$http_opts['headers'] = array( 'developer-token' => Options::get_secret( Options::ADS_DEVELOPER_TOKEN ) );
			$login                = Options::ads_login_customer_id();
			if ( isset( $opts['headers']['login-customer-id'] ) ) {
				$login = CustomerId::normalize( $opts['headers']['login-customer-id'] );
				if ( is_wp_error( $login ) ) {
					return $login;
				}
			}
			if ( '' !== $login ) {
				$http_opts['headers']['login-customer-id'] = $login;
			}
		}
		if ( isset( $prepared['raw_body'] ) ) {
			$http_opts['raw_body']     = $prepared['raw_body'];
			$http_opts['content_type'] = $prepared['content_type'];
		}
		return GoogleClient::request( $prepared['method'], $prepared['url'], $prepared['body'], $http_opts );
	}

	/**
	 * Montagem verificável sem rede. Só documentos já validados devem chegar aqui.
	 * Mesmo assim confere a origem e o template para não criar uma segunda fronteira HTTP.
	 *
	 * @return array|\WP_Error
	 */
	public static function prepare( string $api, array $metadata, array $document, array $path_params, array $query, ?array $body, array $opts = array() ) {
		$config = Discovery::config( $api );
		if ( empty( $config ) || ( $document['rootUrl'] ?? null ) !== $config['root'] || ( $document['servicePath'] ?? '' ) !== $config['service'] ) {
			return new \WP_Error( 'f3_google_action_origin', 'Origem de execução incompatível com a API selecionada.' );
		}
		// Não aceitar um método montado à mão ou alterado fora do documento.
		$methods = Discovery::methods( $document );
		$id      = (string) ( $metadata['id'] ?? '' );
		if ( ! isset( $methods[ $id ] ) || ( $metadata['path'] ?? null ) !== ( $methods[ $id ]['path'] ?? null )
			|| ( $metadata['httpMethod'] ?? null ) !== ( $methods[ $id ]['httpMethod'] ?? null ) ) {
			return new \WP_Error( 'f3_google_action_method', 'O método e o caminho devem corresponder exatamente ao documento de descoberta.' );
		}
		$metadata   = $methods[ $id ];
		$parameters = array_merge( $document['parameters'] ?? array(), $metadata['parameters'] ?? array() );
		$template   = (string) ( $metadata['path'] ?? '' );
		$verb       = (string) ( $metadata['httpMethod'] ?? '' );
		if ( array_key_exists( 'access_token', $query ) || array_key_exists( 'oauth_token', $query ) ) {
			return new \WP_Error( 'f3_google_action_auth_override', 'Não envie access_token ou oauth_token na query: o plugin autentica com a credencial configurada para este site.' );
		}
		if ( '' === $template || '/' === substr( $template, 0, 1 ) || false !== strpos( $template, '://' )
			|| preg_match( '/[?#\\\\\x00-\x20]/', $template ) || self::traversal( $template )
			|| ! in_array( $verb, array( 'GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS' ), true ) ) {
			return new \WP_Error( 'f3_google_action_path', 'Template de método inválido no documento de descoberta.' );
		}
		foreach ( array(
			'path'  => $path_params,
			'query' => $query,
		) as $location => $values ) {
			foreach ( $values as $name => $value ) {
				if ( ! isset( $parameters[ $name ] ) || ( $parameters[ $name ]['location'] ?? '' ) !== $location ) {
					return new \WP_Error( 'f3_google_action_parameter', 'Parâmetro não declarado em ' . $location . ': ' . (string) $name );
				}
				$error = self::parameter( $value, $parameters[ $name ], $location . '.' . $name, $document );
				if ( null !== $error ) {
					return $error;
				}
			}
		}
		foreach ( $parameters as $name => $schema ) {
			$values = 'path' === ( $schema['location'] ?? '' ) ? $path_params : $query;
			if ( ! empty( $schema['required'] ) && ! array_key_exists( $name, $values ) ) {
				return new \WP_Error( 'f3_google_action_required', 'Parâmetro obrigatório ausente: ' . $name );
			}
		}
		$error = null;
		$path  = preg_replace_callback(
			'/\{(\+?)([^{}]+)\}/',
			static function ( array $matches ) use ( $path_params, &$error ): string {
				$name = $matches[2];
				if ( ! array_key_exists( $name, $path_params ) || ! is_scalar( $path_params[ $name ] ) ) {
					$error = new \WP_Error( 'f3_google_action_required', 'Parâmetro obrigatório do template ausente: ' . $name );
					return '';
				}
				$value = (string) $path_params[ $name ];
				if ( '' === $value || preg_match( '/[\\\\\x00-\x1f\x7f]/', $value ) || self::traversal( $value )
				|| ( '+' === $matches[1] && ( '/' === substr( $value, 0, 1 ) || preg_match( '/^[a-z][a-z0-9+.-]*:\/\//i', $value ) ) ) ) {
					$error = new \WP_Error( 'f3_google_action_path', 'Valor de caminho inválido: ' . $name . '. Use o identificador do recurso, sem traversal ou URL de destino.' );
					return '';
				}
				// A expansão + só preserva barras. ?/#/: e percentuais continuam escapados,
				// logo o valor nunca altera a query, o verbo de ação ou a origem.
				$encoded = rawurlencode( $value );
				return '+' === $matches[1] ? str_replace( '%2F', '/', $encoded ) : $encoded;
			},
			$template
		);
		if ( null !== $error ) {
			return $error;
		}
		if ( null === $path || preg_match( '/[{}]/', $path ) ) {
			return new \WP_Error( 'f3_google_action_path', 'Template URI não suportado no documento de descoberta.' );
		}
		$request_schema = Discovery::schema( $metadata['request'] ?? array(), $document );
		if ( ! empty( $opts['dry_run'] ) ) {
			if ( isset( $request_schema['properties']['validateOnly'] ) ) {
				$body                 = $body ?? array();
				$body['validateOnly'] = true;
			} elseif ( isset( $parameters['validateOnly'] ) && 'query' === ( $parameters['validateOnly']['location'] ?? '' ) ) {
				$query['validateOnly'] = true;
			} else {
				return new \WP_Error( 'f3_google_dry_run_unsupported', 'Este método não oferece validateOnly. Nenhuma gravação foi enviada; remova dry_run somente para executar de fato.' );
			}
		}
		if ( isset( $metadata['request'] ) ) {
			$body  = $body ?? array();
			$error = self::validate( $body, $metadata['request'], $document, 'body', 0 );
			if ( null !== $error ) {
				return $error;
			}
			// WordPress decodifica tanto {} como [] em array PHP. O schema recupera
			// a distinção antes de serializar, inclusive addSheet:{} e mapas vazios.
			$body = (array) self::json_types( $body, $metadata['request'], $document );
		} elseif ( null !== $body && array() !== $body ) {
			return new \WP_Error( 'f3_google_action_body', 'Este método não declara corpo de requisição.' );
		} else {
			$body = null;
		}
		$prepared = array(
			'method' => $verb,
			'url'    => $config['root'] . $config['service'] . $path,
			'query'  => $query,
			'body'   => $body,
		);
		if ( isset( $opts['media'] ) ) {
			return self::media( $prepared, $metadata, $config, $path_params, (array) $opts['media'] );
		}
		return $prepared;
	}

	/** Upload multipart pelo caminho oficial do mesmo método; não recebe URL livre. */
	private static function media( array $prepared, array $metadata, array $config, array $path_params, array $media ) {
		$protocol = $metadata['mediaUpload']['protocols']['simple'] ?? null;
		if ( ! is_array( $protocol ) || empty( $protocol['multipart'] ) || empty( $protocol['path'] ) ) {
			return new \WP_Error( 'f3_google_media_unsupported', 'Este método não declara upload multipart na descoberta oficial.' );
		}
		$encoded = (string) ( $media['content_base64'] ?? '' );
		$type    = (string) ( $media['mime_type'] ?? 'application/octet-stream' );
		if ( strlen( $encoded ) > 28 * 1024 * 1024 ) {
			return new \WP_Error( 'f3_google_media_size', 'O envio inline pelo MCP aceita até 20 MiB de conteúdo. Use um cliente de upload resumível para arquivos maiores.' );
		}
		// Decodifica somente bytes de arquivo para upload; nunca executa conteúdo.
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		$content = base64_decode( $encoded, true );
		if ( false === $content || ! preg_match( '~^[a-zA-Z0-9!#$&^_.+-]+/[a-zA-Z0-9!#$&^_.+-]+$~D', $type ) ) {
			return new \WP_Error( 'f3_google_media_input', 'media exige content_base64 válido e mime_type sem cabeçalhos adicionais.' );
		}
		$max = min( 20 * 1024 * 1024, (int) ( $metadata['mediaUpload']['maxSize'] ?? PHP_INT_MAX ) );
		if ( strlen( $content ) > $max ) {
			return new \WP_Error( 'f3_google_media_size', 'Conteúdo maior que o limite deste upload: ' . $max . ' bytes.' );
		}
		$template = ltrim( $protocol['path'], '/' );
		if ( false !== strpos( $template, '://' ) || preg_match( '/[?#\\\\\x00-\x20]/', $template ) || self::traversal( $template ) ) {
			return new \WP_Error( 'f3_google_action_path', 'Template de upload inválido no documento oficial.' );
		}
		$path = preg_replace_callback(
			'/\{(\+?)([^{}]+)\}/',
			static function ( array $matches ) use ( $path_params ): string {
				if ( ! isset( $path_params[ $matches[2] ] ) ) {
					return $matches[0];
				}
				$value = rawurlencode( (string) $path_params[ $matches[2] ] );
				return '+' === $matches[1] ? str_replace( '%2F', '/', $value ) : $value;
			},
			$template
		);
		if ( null === $path || preg_match( '/[{}]/', $path ) ) {
			return new \WP_Error( 'f3_google_action_path', 'Identificador do upload ausente.' );
		}
		$boundary                        = 'f3_google_' . bin2hex( random_bytes( 16 ) );
		$json                            = (string) wp_json_encode( empty( $prepared['body'] ) ? (object) array() : $prepared['body'] );
		$prepared['url']                 = $config['root'] . $path;
		$prepared['query']['uploadType'] = 'multipart';
		$prepared['body']                = null;
		$prepared['content_type']        = 'multipart/related; boundary=' . $boundary;
		$prepared['raw_body']            = '--' . $boundary . "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" . $json
			. "\r\n--" . $boundary . "\r\nContent-Type: " . $type . "\r\n\r\n" . $content . "\r\n--" . $boundary . "--\r\n";
		return $prepared;
	}

	/** Reconhece traversal inclusive com múltiplas camadas de percent-encoding. */
	private static function traversal( string $value ): bool {
		for ( $i = 0; $i < 8; ++$i ) {
			if ( preg_match( '~(?:^|[/\\\\])\.{1,2}(?:[/\\\\?#]|$)~', $value ) || preg_match( '/[\x00-\x1f\x7f]/', $value ) ) {
				return true;
			}
			$decoded = rawurldecode( $value );
			if ( $decoded === $value ) {
				return false;
			}
			$value = $decoded;
		}
		// Codificação ainda recursiva não é um identificador REST legítimo.
		return rawurldecode( $value ) !== $value;
	}

	private static function parameter( $value, array $schema, string $label, array $document ): ?\WP_Error {
		if ( ! empty( $schema['repeated'] ) ) {
			if ( ! is_array( $value ) || ! self::is_list( $value ) ) {
				return new \WP_Error( 'f3_google_action_parameter', $label . ' deve ser uma lista de valores.' );
			}
			unset( $schema['repeated'] );
			foreach ( $value as $index => $item ) {
				$error = self::validate( $item, $schema, $document, $label . '[' . $index . ']', 0 );
				if ( null !== $error ) {
					return $error;
				}
			}
			return null;
		}
		return self::validate( $value, $schema, $document, $label, 0 );
	}

	/** Validação de JSON Discovery, incluindo mapas e referências recursivas. */
	private static function validate( $value, array $schema, array $document, string $label, int $depth ): ?\WP_Error {
		if ( $depth > 64 ) {
			return new \WP_Error( 'f3_google_action_depth', 'Corpo excede 64 níveis de aninhamento em ' . $label );
		}
		if ( isset( $schema['$ref'] ) ) {
			if ( ! isset( $document['schemas'][ $schema['$ref'] ] ) ) {
				return new \WP_Error( 'f3_google_discovery_schema', 'Referência de schema ausente no documento: ' . $schema['$ref'] );
			}
			$schema = $document['schemas'][ $schema['$ref'] ];
		}
		$type = (string) ( $schema['type'] ?? 'any' );
		// ProtoJSON admite null, tratado pela API como campo não informado.
		if ( null === $value && 0 === strpos( $label, 'body.' ) ) {
			return null;
		}
		$numeric_string = 'string' === $type && in_array( $schema['format'] ?? '', array( 'int64', 'uint64' ), true ) && is_int( $value );
		$valid          = 'any' === $type
			|| ( 'string' === $type && ( is_string( $value ) || $numeric_string ) )
			|| ( 'integer' === $type && is_int( $value ) )
			|| ( 'number' === $type && ( is_int( $value ) || is_float( $value ) ) )
			|| ( 'boolean' === $type && is_bool( $value ) )
			|| ( 'object' === $type && ( $value instanceof \stdClass || ( is_array( $value ) && ( empty( $value ) || ! self::is_list( $value ) ) ) ) )
			|| ( 'array' === $type && is_array( $value ) && self::is_list( $value ) );
		if ( ! $valid ) {
			return new \WP_Error( 'f3_google_action_type', $label . ' deve ter o tipo ' . $type . ' do documento de descoberta.' );
		}
		if ( isset( $schema['enum'] ) && ! in_array( $value, $schema['enum'], true ) ) {
			return new \WP_Error( 'f3_google_action_enum', 'Valor fora do enum documentado em ' . $label . '. Valores: ' . implode( ', ', $schema['enum'] ) );
		}
		if ( isset( $schema['pattern'] ) && is_scalar( $value ) ) {
			$matched = preg_match( '~' . str_replace( '~', '\\~', $schema['pattern'] ) . '~D', (string) $value );
			if ( 1 !== $matched ) {
				return new \WP_Error( 'f3_google_action_pattern', $label . ' não corresponde ao padrão do recurso: ' . $schema['pattern'] );
			}
		}
		if ( is_numeric( $value ) ) {
			if ( ( isset( $schema['minimum'] ) && $value < $schema['minimum'] ) || ( isset( $schema['maximum'] ) && $value > $schema['maximum'] ) ) {
				return new \WP_Error( 'f3_google_action_range', 'Valor fora dos limites documentados em ' . $label );
			}
		}
		if ( 'array' === $type ) {
			foreach ( $value as $index => $item ) {
				$error = self::validate( $item, $schema['items'] ?? array(), $document, $label . '[' . $index . ']', $depth + 1 );
				if ( null !== $error ) {
					return $error;
				}
			}
		}
		if ( 'object' === $type ) {
			$value      = (array) $value;
			$properties = $schema['properties'] ?? array();
			foreach ( (array) ( $schema['required'] ?? array() ) as $required ) {
				if ( is_string( $required ) && ! array_key_exists( $required, $value ) ) {
					return new \WP_Error( 'f3_google_action_required', 'Campo obrigatório ausente: ' . $label . '.' . $required );
				}
			}
			foreach ( $value as $name => $item ) {
				$field_schema = $properties[ $name ] ?? ( $schema['additionalProperties'] ?? false );
				if ( false === $field_schema ) {
					return new \WP_Error( 'f3_google_action_field', 'Campo não declarado no corpo: ' . $label . '.' . $name );
				}
				if ( true === $field_schema ) {
					continue;
				}
				$error = self::validate( $item, $field_schema, $document, $label . '.' . $name, $depth + 1 );
				if ( null !== $error ) {
					return $error;
				}
			}
		}
		return null;
	}

	private static function is_list( array $value ): bool {
		return array() === $value || array_keys( $value ) === range( 0, count( $value ) - 1 );
	}

	/** Preserva objetos e listas JSON segundo o schema, depois da validação. */
	private static function json_types( $value, array $schema, array $document ) {
		$schema = Discovery::schema( $schema, $document );
		$type   = $schema['type'] ?? 'any';
		if ( 'object' === $type && ( is_array( $value ) || $value instanceof \stdClass ) ) {
			$object = new \stdClass();
			foreach ( (array) $value as $name => $item ) {
				$field_schema    = $schema['properties'][ $name ] ?? ( $schema['additionalProperties'] ?? array() );
				$object->{$name} = is_array( $field_schema ) ? self::json_types( $item, $field_schema, $document ) : $item;
			}
			return $object;
		}
		if ( 'array' === $type && is_array( $value ) ) {
			return array_map( static fn( $item ) => self::json_types( $item, $schema['items'] ?? array(), $document ), $value );
		}
		return $value;
	}

	/** @return array|\WP_Error Um escopo aceito é suficiente; a lista Google representa OR. */
	private static function scopes( array $metadata, string $connector ) {
		$accepted = $metadata['scopes'] ?? array();
		if ( empty( $accepted ) ) {
			return Credentials::scopes_for( $connector );
		}
		$granted = Options::get( Options::OAUTH_SCOPES, array() );
		if ( is_string( $granted ) ) {
			$granted = preg_split( '/\s+/', trim( $granted ) );
		}
		if ( 'oauth' === Options::auth_mode() && ! empty( $granted ) ) {
			foreach ( $granted as $scope ) {
				if ( in_array( $scope, $accepted, true ) ) {
					return array( $scope );
				}
			}
			return new \WP_Error( 'f3_google_missing_scope', 'O OAuth conectado não possui um escopo aceito por este método. Reconecte autorizando um destes escopos: ' . implode( ', ', $accepted ) );
		}
		foreach ( Credentials::scopes_for( $connector ) as $scope ) {
			if ( in_array( $scope, $accepted, true ) ) {
				return array( $scope );
			}
		}
		return array( reset( $accepted ) );
	}

	/** Callback da habilidade genérica: audita a operação, inclusive GET chamado por ela. */
	public static function run( array $input ): array {
		$api     = (string) ( $input['api'] ?? '' );
		$method  = (string) ( $input['method'] ?? '' );
		$path    = (array) ( $input['path_params'] ?? array() );
		$query   = (array) ( $input['query'] ?? array() );
		$body    = isset( $input['body'] ) ? (array) $input['body'] : null;
		$dry_run = ! empty( $input['dry_run'] ) || true === ( $body['validateOnly'] ?? false ) || true === ( $query['validateOnly'] ?? false );
		$before  = self::snapshot( $api, $method, $path );
		Audit::before( $before );
		$opts = array(
			'mode'    => 'write',
			'dry_run' => $dry_run,
		);
		if ( isset( $input['media'] ) ) {
			$opts['media'] = (array) $input['media'];
		}
		$result = self::call( $api, $method, $path, $query, $body, $opts );
		if ( is_wp_error( $result ) ) {
			Audit::after(
				array(
					'available'  => false,
					'reason'     => 'A operação retornou erro; o estado não foi confirmado.',
					'error_code' => $result->get_error_code(),
				)
			);
			return Response::fail( $result );
		}
		if ( $dry_run ) {
			Audit::after(
				array(
					'available' => false,
					'reason'    => 'validateOnly: validação da Google sem gravação.',
				)
			);
		} elseif ( ! empty( $result ) ) {
			Audit::after(
				array(
					'source' => 'api_response',
					'data'   => $result,
				)
			);
		} else {
			$after = self::snapshot( $api, $method, $path );
			Audit::after( $after );
		}
		if ( ! empty( $result['partialFailureError']['code'] ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_partial_failure', 'A Google devolveu falhas parciais. Consulte data.partialFailureError e os resultados antes de repetir operações; algumas podem ter sido aplicadas.' ),
				array(
					'api'             => $api,
					'method'          => $method,
					'dry_run'         => $dry_run,
					'partial_failure' => true,
					'data'            => $result,
				)
			);
		}
		return Response::ok(
			array(
				'api'     => $api,
				'method'  => $method,
				'dry_run' => $dry_run,
				'data'    => $result,
			)
		);
	}

	/** GET irmão somente quando todos os identificadores podem ser obtidos sem adivinhação. */
	private static function snapshot( string $api, string $method, array $path ): array {
		$gate_api = Discovery::canonical( $api );
		if ( is_wp_error( $gate_api ) || null !== Gate::check( Discovery::connector( $gate_api ) ) ) {
			return array(
				'available' => false,
				'reason'    => 'API ou permissão indisponível para obter estado.',
			);
		}
		$suffix = substr( $method, strrpos( $method, '.' ) + 1 );
		if ( in_array( $suffix, array( 'create', 'insert' ), true ) ) {
			return array(
				'exists' => false,
				'source' => 'new_resource_operation',
			);
		}
		$sibling = substr( $method, 0, strrpos( $method, '.' ) + 1 ) . 'get';
		$get     = Discovery::method( $api, $sibling );
		if ( is_wp_error( $get ) || 'GET' !== ( $get['httpMethod'] ?? '' ) ) {
			return array(
				'available' => false,
				'reason'    => 'Este método não possui GET irmão para um snapshot inequívoco.',
			);
		}
		$get_path  = array();
		$get_query = array();
		foreach ( $get['parameters'] as $name => $parameter ) {
			if ( 'path' === ( $parameter['location'] ?? '' ) ) {
				if ( ! array_key_exists( $name, $path ) ) {
					return array(
						'available' => false,
						'reason'    => 'GET irmão exige identificadores não fornecidos: ' . $name,
					);
				}
				$get_path[ $name ] = $path[ $name ];
			} elseif ( ! empty( $parameter['required'] ) ) {
				return array(
					'available' => false,
					'reason'    => 'GET irmão exige parâmetros próprios.',
				);
			}
		}
		$result = self::call(
			$api,
			$sibling,
			$get_path,
			$get_query,
			null,
			array(
				'mode'    => 'read',
				'retries' => 0,
			)
		);
		return is_wp_error( $result )
			? array(
				'available'  => false,
				'reason'     => 'Não foi possível ler o recurso.',
				'error_code' => $result->get_error_code(),
			)
			: array(
				'available' => true,
				'source'    => $sibling,
				'data'      => $result,
			);
	}
}
