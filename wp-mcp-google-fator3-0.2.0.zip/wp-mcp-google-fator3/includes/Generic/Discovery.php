<?php
/**
 * Catálogo integral das APIs, carregado dos documentos oficiais de descoberta.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Generic;

use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Discovery {

	public const CACHE_TTL = 86400;

	/** Os nove documentos; a versão Ads continua sendo a opção da instalação. */
	public static function apis(): array {
		return array(
			'analytics-admin-v1alpha',
			'analytics-admin-v1beta',
			'analytics-data-v1beta',
			'analytics-data-v1alpha',
			'google-ads',
			'search-console',
			'site-verification',
			'sheets',
			'drive',
		);
	}

	/** @return string|\WP_Error */
	public static function canonical( string $api ) {
		$api     = strtolower( trim( $api ) );
		$aliases = array(
			'analytics-admin'  => 'analytics-admin-v1alpha',
			'ga-admin'         => 'analytics-admin-v1alpha',
			'analytics-data'   => 'analytics-data-v1beta',
			'ga-data'          => 'analytics-data-v1beta',
			'ads'              => 'google-ads',
			'gsc'              => 'search-console',
			'siteverification' => 'site-verification',
		);
		$api     = $aliases[ $api ] ?? $api;
		if ( ! in_array( $api, self::apis(), true ) ) {
			return new \WP_Error( 'f3_google_discovery_api', 'API desconhecida. Consulte google/list-actions.', array( 'details' => self::apis() ) );
		}
		return $api;
	}

	/** @return string Conector para Gate e Credentials. */
	public static function connector( string $api ): string {
		if ( 0 === strpos( $api, 'analytics-' ) ) {
			return 'ga';
		}
		$map = array(
			'google-ads'        => 'ads',
			'search-console'    => 'gsc',
			'site-verification' => 'siteverification',
		);
		return $map[ $api ] ?? $api;
	}

	/** Metadados fixos: nem a URL da descoberta nem a origem da API vêm do cliente. */
	public static function config( string $api ): array {
		$apis = array(
			'analytics-admin-v1alpha' => array( 'analyticsadmin', 'v1alpha', 'https://analyticsadmin.googleapis.com/', '' ),
			'analytics-admin-v1beta'  => array( 'analyticsadmin', 'v1beta', 'https://analyticsadmin.googleapis.com/', '' ),
			'analytics-data-v1beta'   => array( 'analyticsdata', 'v1beta', 'https://analyticsdata.googleapis.com/', '' ),
			'analytics-data-v1alpha'  => array( 'analyticsdata', 'v1alpha', 'https://analyticsdata.googleapis.com/', '' ),
			'google-ads'              => array( 'googleads', Options::ads_api_version(), 'https://googleads.googleapis.com/', '' ),
			'search-console'          => array( 'searchconsole', 'v1', 'https://searchconsole.googleapis.com/', '' ),
			'site-verification'       => array( 'siteVerification', 'v1', 'https://www.googleapis.com/', 'siteVerification/v1/' ),
			'sheets'                  => array( 'sheets', 'v4', 'https://sheets.googleapis.com/', '' ),
			'drive'                   => array( 'drive', 'v3', 'https://www.googleapis.com/', 'drive/v3/' ),
		);
		if ( ! isset( $apis[ $api ] ) ) {
			return array();
		}
		list( $name, $version, $root, $service ) = $apis[ $api ];
		$url                                     = 'https://www.googleapis.com/' === $root
			? $root . 'discovery/v1/apis/' . $name . '/' . $version . '/rest'
			: $root . '$discovery/rest?version=' . rawurlencode( $version );
		return array(
			'name'    => $name,
			'version' => $version,
			'root'    => $root,
			'service' => $service,
			'url'     => $url,
		);
	}

	/** Publicado para invalidação e para fixtures; o hash inclui versão e URL. */
	public static function cache_key( string $api ): string {
		$config = self::config( $api );
		return 'f3_mcp_google_discovery_' . md5( (string) ( $config['url'] ?? $api ) );
	}

	/** @return array|\WP_Error */
	public static function document( string $api ) {
		$api = self::canonical( $api );
		if ( is_wp_error( $api ) ) {
			return $api;
		}
		$config = self::config( $api );
		$key    = self::cache_key( $api );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) {
			$error = self::validate_document( $cached, $config );
			return $error ?? $cached;
		}
		$document = GoogleClient::request(
			'GET',
			$config['url'],
			null,
			array(
				'auth'      => false,
				'mode'      => 'read',
				'connector' => 'discovery',
			)
		);
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$error = self::validate_document( $document, $config );
		if ( null !== $error ) {
			return $error;
		}
		set_transient( $key, $document, self::CACHE_TTL );
		return $document;
	}

	private static function validate_document( array $document, array $config ): ?\WP_Error {
		if ( ( $document['name'] ?? null ) !== $config['name']
			|| ( $document['version'] ?? null ) !== $config['version']
			|| ( $document['rootUrl'] ?? null ) !== $config['root']
			|| ( $document['servicePath'] ?? '' ) !== $config['service']
			|| ( isset( $document['baseUrl'] ) && $document['baseUrl'] !== $config['root'] . $config['service'] )
			|| ! isset( $document['resources'] ) || ! is_array( $document['resources'] ) ) {
			return new \WP_Error( 'f3_google_discovery_document', 'Documento de descoberta inválido: nome, versão e origem devem corresponder à API oficial selecionada.' );
		}
		return null;
	}

	/** @return array<string,array> Índice integral por ID, sem lista de métodos permitidos. */
	public static function methods( array $document ): array {
		$result = array();
		self::walk( $document, $result );
		ksort( $result );
		return $result;
	}

	private static function walk( array $node, array &$result ): void {
		foreach ( $node['methods'] ?? array() as $method ) {
			if ( is_array( $method ) && isset( $method['id'] ) ) {
				$result[ (string) $method['id'] ] = $method;
			}
		}
		foreach ( $node['resources'] ?? array() as $resource ) {
			if ( is_array( $resource ) ) {
				self::walk( $resource, $result );
			}
		}
	}

	/** @return array|\WP_Error Metadados oficiais, com parâmetros globais incorporados. */
	public static function method( string $api, string $method ) {
		$api = self::canonical( $api );
		if ( is_wp_error( $api ) ) {
			return $api;
		}
		$document = self::document( $api );
		if ( is_wp_error( $document ) ) {
			return $document;
		}
		$methods = self::methods( $document );
		if ( ! isset( $methods[ $method ] ) ) {
			return new \WP_Error( 'f3_google_discovery_method', 'Método ausente do documento oficial desta API. Use o id exato devolvido por google/list-actions.' );
		}
		$metadata                   = $methods[ $method ];
		$metadata['api']            = $api;
		$metadata['parameters']     = array_merge( $document['parameters'] ?? array(), $metadata['parameters'] ?? array() );
		$metadata['http_method']    = $metadata['httpMethod'];
		$metadata['request_schema'] = self::schema( $metadata['request'] ?? array(), $document );
		return $metadata;
	}

	/** Resolve somente o nível corrente. Referências aninhadas são preservadas. */
	public static function schema( array $schema, array $document ): array {
		if ( isset( $schema['$ref'] ) ) {
			return $document['schemas'][ $schema['$ref'] ] ?? array();
		}
		return $schema;
	}

	/** Catálogo paginado com schemas completos, deduplicados no envelope. */
	public static function catalog( array $input ): array {
		$gate = Gate::check( 'any' );
		if ( null !== $gate ) {
			return $gate;
		}
		$apis = self::apis();
		if ( ! empty( $input['api'] ) && 'all' !== $input['api'] ) {
			$api = self::canonical( (string) $input['api'] );
			if ( is_wp_error( $api ) ) {
				return Response::fail( $api );
			}
			$apis = array( $api );
		}
		$task     = strtolower( trim( (string) ( $input['task'] ?? '' ) ) );
		$offset   = max( 0, (int) ( $input['offset'] ?? 0 ) );
		$limit    = max( 1, min( 100, (int) ( $input['limit'] ?? 25 ) ) );
		$full     = ! array_key_exists( 'include_schemas', $input ) || (bool) $input['include_schemas'];
		$actions  = array();
		$schemas  = array();
		$total    = 0;
		$errors   = array();
		$versions = array();
		foreach ( $apis as $api ) {
			$doc = self::document( $api );
			if ( is_wp_error( $doc ) ) {
				$errors[] = array(
					'api'        => $api,
					'error_code' => $doc->get_error_code(),
					'message'    => $doc->get_error_message(),
				);
				continue;
			}
			$versions[ $api ] = array(
				'version'  => $doc['version'],
				'revision' => (string) ( $doc['revision'] ?? '' ),
				'source'   => self::config( $api )['url'],
			);
			foreach ( self::methods( $doc ) as $method ) {
				$haystack = strtolower( $method['id'] . ' ' . ( $method['description'] ?? '' ) . ' ' . ( $method['path'] ?? '' ) );
				if ( '' !== $task && ! self::matches_task( $haystack, $task ) ) {
					continue;
				}
				$index = $total++;
				if ( $index < $offset || count( $actions ) >= $limit ) {
					continue;
				}
				$action = array(
					'api'            => $api,
					'id'             => $method['id'],
					'http_method'    => $method['httpMethod'],
					'path'           => $method['path'],
					'description'    => (string) ( $method['description'] ?? '' ),
					'parameters'     => (object) array_merge( $doc['parameters'] ?? array(), $method['parameters'] ?? array() ),
					'request_schema' => (object) self::schema( $method['request'] ?? array(), $doc ),
					'scopes'         => $method['scopes'] ?? array(),
				);
				if ( isset( $method['mediaUpload'] ) ) {
					$action['media_upload'] = $method['mediaUpload'];
				}
				$actions[] = $action;
				if ( $full && isset( $method['request'] ) ) {
					if ( ! isset( $schemas[ $api ] ) ) {
						$schemas[ $api ] = array();
					}
					self::collect_schemas( $method['request'], $doc, $schemas[ $api ] );
				}
			}
		}
		if ( count( $errors ) === count( $apis ) ) {
			return Response::fail( 'Não foi possível carregar os documentos de descoberta.', array( 'errors' => $errors ) );
		}
		return Response::ok(
			array(
				'actions'     => $actions,
				'count'       => count( $actions ),
				'total'       => $total,
				'offset'      => $offset,
				'next_offset' => $offset + count( $actions ) < $total ? $offset + count( $actions ) : null,
				'schemas'     => (object) $schemas,
				'apis'        => (object) $versions,
				'cache_ttl'   => self::CACHE_TTL,
				'complete'    => empty( $errors ),
				'warnings'    => $errors,
			),
			'Referências $ref em request_schema apontam para schemas[api]. A busca task usa o texto original em inglês da documentação Google.'
		);
	}

	private static function matches_task( string $haystack, string $task ): bool {
		foreach ( preg_split( '/\s+/', $task ) as $word ) {
			if ( false === strpos( $haystack, $word ) ) {
				return false;
			}
		}
		return true;
	}

	private static function collect_schemas( array $node, array $doc, array &$found ): void {
		if ( isset( $node['$ref'] ) ) {
			$name = $node['$ref'];
			if ( isset( $found[ $name ] ) || ! isset( $doc['schemas'][ $name ] ) ) {
				return;
			}
			$found[ $name ] = $doc['schemas'][ $name ];
			self::collect_schemas( $found[ $name ], $doc, $found );
		}
		foreach ( $node as $value ) {
			if ( is_array( $value ) ) {
				self::collect_schemas( $value, $doc, $found );
			}
		}
	}
}
