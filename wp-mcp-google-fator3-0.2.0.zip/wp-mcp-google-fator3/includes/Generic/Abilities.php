<?php
/**
 * Descoberta, execução de método e consulta da auditoria pelo MCP.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Generic;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Abilities {

	public static function register(): void {
		Ability::register(
			'google/list-actions',
			'any',
			array(
				'label'        => 'Google: catálogo de ações',
				'description'  => 'Lista os métodos das nove APIs Google a partir dos documentos oficiais, com cache de 24 h e paginação. task procura palavras no texto em inglês; o id completo identifica a execução. request_schema usa referências em schemas[api].',
				'input_schema' => array(
					'properties' => array(
						'api'             => array(
							'type'        => 'string',
							'description' => 'API ou alias. Omitir/all pesquisa as nove APIs.',
						),
						'task'            => array(
							'type'        => 'string',
							'description' => 'Palavras do id, caminho ou descrição em inglês. Ex.: create audience.',
						),
						'offset'          => array(
							'type'    => 'integer',
							'minimum' => 0,
						),
						'limit'           => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
						'include_schemas' => array(
							'type'        => 'boolean',
							'description' => 'true inclui todos os schemas referenciados pelos corpos da página; false reduz a resposta.',
						),
					),
				),
				'callback'     => array( Discovery::class, 'catalog' ),
			)
		);
		Ability::register(
			'google/execute-action',
			'any',
			array(
				'label'        => 'Google: executar ação',
				'description'  => 'Executa o id exato de google/list-actions usando parâmetros e corpo definidos no documento oficial. A URL é construída pelo plugin. Gravações são imediatas; dry_run só funciona quando o método aceita validateOnly. Audita estados disponíveis antes/depois.',
				'mode'         => 'write',
				'input_schema' => array(
					'required'   => array( 'api', 'method' ),
					'properties' => array(
						'api'         => array( 'type' => 'string' ),
						'method'      => array(
							'type'        => 'string',
							'description' => 'ID completo e com a capitalização exata do catálogo.',
						),
						'path_params' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
							'description'          => 'Parâmetros location=path, com nomes e tipos oficiais.',
						),
						'query'       => array(
							'type'                 => 'object',
							'additionalProperties' => true,
							'description'          => 'Parâmetros location=query. Parâmetro repeated aceita array.',
						),
						'body'        => array(
							'type'                 => 'object',
							'additionalProperties' => true,
							'description'          => 'Corpo JSON com os nomes de campos e tipos request_schema do método.',
						),
						'dry_run'     => array( 'type' => 'boolean' ),
						'media'       => array(
							'type'                 => 'object',
							'additionalProperties' => false,
							'required'             => array( 'content_base64', 'mime_type' ),
							'properties'           => array(
								'content_base64' => array(
									'type'        => 'string',
									'description' => 'Conteúdo inline até 20 MiB, somente para método com mediaUpload multipart.',
								),
								'mime_type'      => array( 'type' => 'string' ),
							),
						),
					),
				),
				'callback'     => array( ExecuteAction::class, 'run' ),
			)
		);
		Ability::register(
			'google/audit',
			'any',
			array(
				'label'        => 'Google: consultar auditoria',
				'description'  => 'Lê o log circular local (até 100 entradas) com filtros. before/after refletem snapshots disponíveis e limitados; segredos e identificadores de Customer Match são removidos.',
				'input_schema' => array(
					'properties' => array(
						'action' => array(
							'type'        => 'string',
							'description' => 'Nome exato da habilidade/evento.',
						),
						'target' => array(
							'type'        => 'string',
							'description' => 'Alvo exato registrado.',
						),
						'user'   => array(
							'type'    => 'integer',
							'minimum' => 0,
						),
						'status' => array(
							'type'        => 'string',
							'description' => 'Valor status registrado, como ok ou error.',
						),
						'mode'   => array(
							'type' => 'string',
							'enum' => array( 'read', 'write' ),
						),
						'from'   => array(
							'type'        => 'string',
							'description' => 'Início inclusivo, ISO 8601 ou YYYY-MM-DD; UTC se sem fuso.',
						),
						'to'     => array(
							'type'        => 'string',
							'description' => 'Fim inclusivo, ISO 8601; YYYY-MM-DD inclui o dia inteiro.',
						),
						'offset' => array(
							'type'    => 'integer',
							'minimum' => 0,
						),
						'limit'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
						),
					),
				),
				'callback'     => array( self::class, 'audit' ),
			)
		);
	}

	public static function audit( array $input ): array {
		$from = isset( $input['from'] ) ? self::date( (string) $input['from'], false ) : null;
		$to   = isset( $input['to'] ) ? self::date( (string) $input['to'], true ) : null;
		if ( false === $from || false === $to || ( null !== $from && null !== $to && $to < $from ) ) {
			return Response::fail( new \WP_Error( 'f3_google_audit_dates', 'Filtro de datas inválido: use início e fim em ISO 8601 e fim igual ou posterior ao início.' ) );
		}
		$entries = array();
		foreach ( Audit::recent( 0 ) as $entry ) {
			$skip = false;
			foreach ( array( 'action', 'target', 'user', 'status', 'mode' ) as $key ) {
				$wanted   = (string) ( $input[ $key ] ?? '' );
				$observed = (string) ( $entry[ $key ] ?? ( $entry['extra'][ $key ] ?? '' ) );
				if ( isset( $input[ $key ] ) && $wanted !== $observed ) {
					$skip = true;
					break;
				}
			}
			$time = self::date( (string) ( $entry['time'] ?? '' ), false );
			if ( $skip || ( null !== $from && $time < $from ) || ( null !== $to && $time > $to ) ) {
				continue;
			}
			$entries[] = Audit::redact( $entry );
		}
		$offset  = max( 0, (int) ( $input['offset'] ?? 0 ) );
		$limit   = max( 1, min( 100, (int) ( $input['limit'] ?? 30 ) ) );
		$total   = count( $entries );
		$entries = array_slice( $entries, $offset, $limit );
		return Response::ok(
			array(
				'entries'     => $entries,
				'count'       => count( $entries ),
				'total'       => $total,
				'offset'      => $offset,
				'next_offset' => $offset + count( $entries ) < $total ? $offset + count( $entries ) : null,
				'capacity'    => Audit::MAX,
			)
		);
	}

	/** @return int|false */
	private static function date( string $text, bool $end ) {
		if ( '' === trim( $text ) ) {
			return false;
		}
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $text ) ) {
			$text .= $end ? 'T23:59:59Z' : 'T00:00:00Z';
		}
		try {
			return ( new \DateTimeImmutable( $text, new \DateTimeZone( 'UTC' ) ) )->getTimestamp();
		} catch ( \Exception $error ) {
			return false;
		}
	}
}
