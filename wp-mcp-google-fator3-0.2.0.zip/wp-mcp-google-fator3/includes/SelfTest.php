<?php
/**
 * Autoteste: o que dá para conferir sem depender da Google.
 *
 * Existe porque a maior parte do que quebra neste plugin quebra em silêncio —
 * uma cifra que não decifra depois de trocar as salts, um servidor sem OpenSSL,
 * uma lista de hosts frouxa. Nada disso aparece até a primeira chamada real
 * falhar com uma mensagem que não ajuda. Aqui cada peça é exercitada de
 * verdade, sem rede, e o resultado cabe numa tabela na tela.
 *
 * As fases seguintes acrescentam checagens (presets de data, montador GAQL,
 * catálogo) mantendo o mesmo formato de retorno.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Auth\ServiceAccount;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Unified\Catalog;
use Fator3\McpGoogle\Unified\DateRange;
use Fator3\McpGoogle\Unified\Filters;
use Fator3\McpGoogle\Unified\Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class SelfTest {

	/**
	 * @param array $opts 'live' => true também pede um token de verdade.
	 * @return array{success:bool,passed:int,failed:int,checks:array<int,array{name:string,ok:bool,detail:string}>}
	 */
	public static function run( array $opts = array() ): array {
		$checks = array(
			self::check_crypto(),
			self::check_jwt(),
			self::check_hosts(),
			self::check_gate(),
			self::check_config(),
		);

		// A camada unificada é carregada só se existir (ver o bootstrap): o
		// núcleo continua diagnosticável sozinho.
		if ( class_exists( DateRange::class ) ) {
			$checks[] = self::check_date_presets();
			$checks[] = self::check_date_compare();
			$checks[] = self::check_catalog();
			$checks[] = self::check_filters_ga();
			$checks[] = self::check_filters_gaql();
			$checks[] = self::check_query_build();
		}

		if ( ! empty( $opts['live'] ) ) {
			$checks[] = self::check_token();

			if ( Options::ga_enabled() && class_exists( '\\Fator3\\McpGoogle\\Analytics\\AdminApi' ) ) {
				$checks[] = self::check_live_ga();
			}

			if ( Options::ads_enabled() && class_exists( '\\Fator3\\McpGoogle\\Ads\\AdsApi' ) ) {
				$checks[] = self::check_live_ads();
			}
		}

		$passed = 0;
		$failed = 0;

		foreach ( $checks as $check ) {
			if ( ! empty( $check['ok'] ) ) {
				++$passed;
			} else {
				++$failed;
			}
		}

		return array(
			'success' => 0 === $failed,
			'passed'  => $passed,
			'failed'  => $failed,
			'checks'  => $checks,
		);
	}

	/**
	 * Cifra e decifra em todos os backends disponíveis.
	 */
	private static function check_crypto(): array {
		if ( ! Crypto::available() ) {
			return self::check(
				'crypto',
				false,
				__( 'Nem libsodium nem OpenSSL com AES-256-GCM estão disponíveis: os segredos não podem ser gravados.', 'wp-mcp-google-fator3' )
			);
		}

		$sample  = 'f3-selftest-' . wp_generate_password( 24, false );
		$tested  = array();
		$default = Crypto::backend();

		foreach ( array( 'sodium', 'openssl' ) as $backend ) {
			$force = static function () use ( $backend ): string {
				return $backend;
			};

			add_filter( 'f3_mcp_google_crypto_backend', $force );
			$active = Crypto::backend();

			if ( $active === $backend ) {
				$cipher = Crypto::encrypt( $sample );
				$plain  = Crypto::decrypt( $cipher );

				if ( is_wp_error( $plain ) || $plain !== $sample || false !== strpos( $cipher, $sample ) ) {
					remove_filter( 'f3_mcp_google_crypto_backend', $force );

					return self::check(
						'crypto',
						false,
						sprintf(
							/* translators: %s: nome do backend de cifra. */
							__( 'O backend %s não fez o ciclo cifra/decifra corretamente.', 'wp-mcp-google-fator3' ),
							$backend
						)
					);
				}

				$tested[] = $backend;
			}

			remove_filter( 'f3_mcp_google_crypto_backend', $force );
		}

		return self::check(
			'crypto',
			! empty( $tested ),
			sprintf(
				/* translators: 1: backend em uso, 2: backends verificados. */
				__( 'Em uso: %1$s. Verificados: %2$s.', 'wp-mcp-google-fator3' ),
				$default,
				implode( ', ', $tested )
			)
		);
	}

	/**
	 * Assina um JWT com um par de chaves gerado na hora e confere a assinatura.
	 *
	 * Não usa a chave real: o objetivo é provar que este servidor assina RS256 e
	 * que o JWT montado tem o formato que a Google espera.
	 */
	private static function check_jwt(): array {
		if ( ! function_exists( 'openssl_pkey_new' ) || ! function_exists( 'openssl_verify' ) ) {
			return self::check( 'jwt', false, __( 'A extensão OpenSSL não está disponível: a service account não funciona neste servidor.', 'wp-mcp-google-fator3' ) );
		}

		$pair = openssl_pkey_new(
			array(
				'private_key_bits' => 2048,
				'private_key_type' => OPENSSL_KEYTYPE_RSA,
			)
		);

		if ( ! $pair ) {
			// Servidor sem openssl.cnf não gera par de chaves, mas ainda assina
			// com uma chave existente — que é tudo de que o plugin precisa.
			return self::check( 'jwt', true, __( 'Pulado: este servidor não consegue gerar um par de chaves de teste (falta openssl.cnf). A assinatura com a chave real não depende disso.', 'wp-mcp-google-fator3' ) );
		}

		$private = '';
		openssl_pkey_export( $pair, $private );
		$details = openssl_pkey_get_details( $pair );
		$public  = is_array( $details ) ? (string) ( $details['key'] ?? '' ) : '';

		if ( '' === $private || '' === $public ) {
			return self::check( 'jwt', false, __( 'Não foi possível exportar o par de chaves de teste.', 'wp-mcp-google-fator3' ) );
		}

		$now = time();
		$jwt = ServiceAccount::build_jwt(
			array(
				'client_email' => 'selftest@exemplo.iam.gserviceaccount.com',
				'private_key'  => $private,
				'token_uri'    => ServiceAccount::DEFAULT_TOKEN_URI,
			),
			array( Credentials::SCOPE_GA ),
			$now
		);

		$parts = explode( '.', $jwt );
		if ( 3 !== count( $parts ) ) {
			return self::check( 'jwt', false, __( 'O JWT gerado não tem as três partes esperadas.', 'wp-mcp-google-fator3' ) );
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		$signature = base64_decode( strtr( $parts[2], '-_', '+/' ), false );
		$verified  = is_string( $signature )
			? openssl_verify( $parts[0] . '.' . $parts[1], $signature, $public, OPENSSL_ALGO_SHA256 )
			: 0;

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Codificação de dados binários/JWT; nunca executa o conteúdo.
		$claims = json_decode( (string) base64_decode( strtr( $parts[1], '-_', '+/' ), false ), true );
		$ok     = 1 === $verified
			&& is_array( $claims )
			&& ServiceAccount::DEFAULT_TOKEN_URI === ( $claims['aud'] ?? '' )
			&& Credentials::SCOPE_GA === ( $claims['scope'] ?? '' )
			&& ( $claims['exp'] ?? 0 ) === $now + 3600;

		return self::check(
			'jwt',
			$ok,
			$ok
				? __( 'JWT RS256 assinado e verificado, com iss, scope, aud, iat e exp corretos.', 'wp-mcp-google-fator3' )
				: __( 'A assinatura RS256 não foi verificada ou as claims saíram erradas.', 'wp-mcp-google-fator3' )
		);
	}

	/**
	 * A lista de hosts recusa o que tem de recusar?
	 */
	private static function check_hosts(): array {
		$must_pass = array(
			GoogleClient::HOST_GA_DATA . '/v1beta/properties/1:runReport',
			GoogleClient::HOST_ADS . '/v25/customers:listAccessibleCustomers',
			GoogleClient::HOST_TOKEN . '/token',
			GoogleClient::HOST_GA_ADMIN . '/v1beta/accountSummaries',
		);

		$must_fail = array(
			'http://analyticsdata.googleapis.com/v1beta',
			'https://analyticsdata.googleapis.com.exemplo.com/v1beta',
			'https://169.254.169.254/latest/meta-data/',
			'https://googleads.googleapis.com:8443/v25',
			'https://user:senha@googleads.googleapis.com/v25',
			'https://evil.example/v1beta',
		);

		foreach ( $must_pass as $url ) {
			if ( ! GoogleClient::assert_allowed_host( $url ) ) {
				return self::check( 'hosts', false, __( 'Um host legítimo do Google foi recusado.', 'wp-mcp-google-fator3' ) );
			}
		}

		foreach ( $must_fail as $url ) {
			if ( GoogleClient::assert_allowed_host( $url ) ) {
				return self::check(
					'hosts',
					false,
					sprintf(
						/* translators: %s: URL indevidamente aceita. */
						__( 'Um destino que deveria ser recusado passou: %s', 'wp-mcp-google-fator3' ),
						$url
					)
				);
			}
		}

		return self::check( 'hosts', true, __( 'Só os quatro hosts do Google, por https e na porta padrão.', 'wp-mcp-google-fator3' ) );
	}

	/**
	 * Com o canal fechado, o portão recusa?
	 *
	 * Usa o filtro em vez de mexer na opção: o autoteste não pode desligar o
	 * canal de verdade no meio de um site em uso.
	 */
	private static function check_gate(): array {
		$close = '__return_false';

		add_filter( 'f3_mcp_google_enabled', $close, 99 );
		$closed = Gate::check( 'any' );
		$allow  = Gate::permission( 'any' );
		remove_filter( 'f3_mcp_google_enabled', $close, 99 );

		$ok = is_array( $closed )
			&& false === ( $closed['success'] ?? null )
			&& 'f3_google_disabled' === ( $closed['error_code'] ?? '' )
			&& false === $allow;

		return self::check(
			'gate',
			$ok,
			$ok
				? __( 'Com o canal fechado, as habilidades recusam e o permission_callback devolve falso.', 'wp-mcp-google-fator3' )
				: __( 'O portão não recusou com o canal fechado.', 'wp-mcp-google-fator3' )
		);
	}

	/**
	 * Configuração coerente: versão da API no formato certo, limites sãos.
	 */
	private static function check_config(): array {
		$problems = array();

		if ( ! preg_match( '/^v\d{1,3}$/', Options::ads_api_version() ) ) {
			$problems[] = __( 'versão da Ads API inválida', 'wp-mcp-google-fator3' );
		}

		$rows = Options::max_rows();
		if ( $rows < 1 || $rows > 10000 ) {
			$problems[] = __( 'teto de linhas fora da faixa', 'wp-mcp-google-fator3' );
		}

		$timeout = Options::http_timeout();
		if ( $timeout < 5 || $timeout > 120 ) {
			$problems[] = __( 'tempo limite HTTP fora da faixa', 'wp-mcp-google-fator3' );
		}

		if ( Options::ads_enabled() && '' === Options::get_secret( Options::ADS_DEVELOPER_TOKEN ) ) {
			$problems[] = __( 'conector Ads ligado sem developer token', 'wp-mcp-google-fator3' );
		}

		return self::check(
			'config',
			empty( $problems ),
			empty( $problems )
				? sprintf(
					/* translators: 1: versão da API do Ads, 2: teto de linhas, 3: tempo limite. */
					__( 'Ads %1$s, até %2$d linhas, %3$ds de tempo limite.', 'wp-mcp-google-fator3' ),
					Options::ads_api_version(),
					$rows,
					$timeout
				)
				: implode( '; ', $problems )
		);
	}

	// =========================================================================
	// Camada unificada (google/*) — tudo offline
	// =========================================================================

	/**
	 * Cada preset com um dia fixo e o valor esperado escrito à mão.
	 *
	 * O dia é 05/09/2026, um sábado — escolhido porque expõe as duas regras que
	 * mais confundem: `last_N_days` termina ONTEM (04/09) e `this_week` começa
	 * na segunda (31/08), não no domingo.
	 */
	private static function check_date_presets(): array {
		$today = new \DateTimeImmutable( '2026-09-05' );

		$expected = array(
			'today'        => array( '2026-09-05', '2026-09-05' ),
			'yesterday'    => array( '2026-09-04', '2026-09-04' ),
			'last_7_days'  => array( '2026-08-29', '2026-09-04' ),
			'last_14_days' => array( '2026-08-22', '2026-09-04' ),
			'last_28_days' => array( '2026-08-08', '2026-09-04' ),
			'last_30_days' => array( '2026-08-06', '2026-09-04' ),
			'last_90_days' => array( '2026-06-07', '2026-09-04' ),
			'this_week'    => array( '2026-08-31', '2026-09-05' ),
			'last_week'    => array( '2026-08-24', '2026-08-30' ),
			'this_month'   => array( '2026-09-01', '2026-09-05' ),
			'last_month'   => array( '2026-08-01', '2026-08-31' ),
			'this_quarter' => array( '2026-07-01', '2026-09-05' ),
			'last_quarter' => array( '2026-04-01', '2026-06-30' ),
			'this_year'    => array( '2026-01-01', '2026-09-05' ),
			'last_year'    => array( '2025-01-01', '2025-12-31' ),
		);

		foreach ( $expected as $preset => $dates ) {
			$range = DateRange::resolve( $preset, $today );

			if ( is_wp_error( $range ) || $range['from'] !== $dates[0] || $range['to'] !== $dates[1] ) {
				return self::check(
					'date_presets',
					false,
					sprintf(
						/* translators: 1: preset, 2: esperado, 3: obtido. */
						__( 'O preset %1$s deveria dar %2$s e deu %3$s.', 'wp-mcp-google-fator3' ),
						$preset,
						$dates[0] . '..' . $dates[1],
						is_wp_error( $range ) ? $range->get_error_message() : $range['from'] . '..' . $range['to']
					)
				);
			}
		}

		// Presets faltando na lista acima passariam despercebidos.
		$missing = array_diff( DateRange::presets(), array_keys( $expected ) );

		if ( ! empty( $missing ) ) {
			return self::check(
				'date_presets',
				false,
				sprintf(
					/* translators: %s: presets sem valor esperado. */
					__( 'Presets sem valor conferido: %s.', 'wp-mcp-google-fator3' ),
					implode( ', ', $missing )
				)
			);
		}

		// E uma data impossível não pode passar por simpatia do PHP.
		$bad = DateRange::resolve(
			array(
				'from' => '2026-02-31',
				'to'   => '2026-03-01',
			)
		);

		if ( ! is_wp_error( $bad ) ) {
			return self::check( 'date_presets', false, __( '31 de fevereiro foi aceito como data válida.', 'wp-mcp-google-fator3' ) );
		}

		return self::check(
			'date_presets',
			true,
			sprintf(
				/* translators: %d: quantidade de presets. */
				__( '%d presets conferidos com 05/09/2026 como hoje, e datas inválidas recusadas.', 'wp-mcp-google-fator3' ),
				count( $expected )
			)
		);
	}

	/**
	 * Período anterior e mesmo período do ano passado.
	 */
	private static function check_date_compare(): array {
		$today = new \DateTimeImmutable( '2026-09-05' );
		$base  = DateRange::resolve( 'last_30_days', $today );

		if ( is_wp_error( $base ) ) {
			return self::check( 'date_compare', false, $base->get_error_message() );
		}

		$previous = DateRange::compare( $base, 'previous_period', $today );
		$year     = DateRange::compare( $base, 'previous_year', $today );

		$ok = ! is_wp_error( $previous )
			&& '2026-07-07' === $previous['from']
			&& '2026-08-05' === $previous['to']
			&& ! is_wp_error( $year )
			&& '2025-08-06' === $year['from']
			&& '2025-09-04' === $year['to'];

		return self::check(
			'date_compare',
			$ok,
			$ok
				? __( 'last_30_days (06/08 a 04/09) compara com 07/07 a 05/08 e com 06/08/2025 a 04/09/2025.', 'wp-mcp-google-fator3' )
				: __( 'O período de comparação saiu errado.', 'wp-mcp-google-fator3' )
		);
	}

	/**
	 * Integridade do catálogo do Google Ads.
	 */
	private static function check_catalog(): array {
		$fields   = Catalog::ads_fields();
		$ids      = array();
		$prefixes = array( 'metrics.', 'segments.', 'campaign.', 'campaign_budget.', 'ad_group.', 'ad_group_ad.', 'ad_group_criterion.', 'search_term_view.', 'geographic_view.', 'customer.' );
		$kinds    = array( 'integer', 'float', 'currency', 'percent', 'string', 'date' );
		$problems = array();

		foreach ( $fields as $field ) {
			$id = (string) ( $field['id'] ?? '' );

			if ( '' === $id || isset( $ids[ $id ] ) ) {
				$problems[] = sprintf(
					/* translators: %s: id repetido ou vazio. */
					__( 'id repetido ou vazio: "%s"', 'wp-mcp-google-fator3' ),
					$id
				);
				continue;
			}

			$ids[ $id ] = true;

			if ( ! in_array( (string) ( $field['type'] ?? '' ), array( 'metric', 'dimension' ), true ) ) {
				$problems[] = sprintf(
					/* translators: %s: id do campo. */
					__( '%s tem type fora de metric/dimension', 'wp-mcp-google-fator3' ),
					$id
				);
			}

			if ( ! in_array( (string) ( $field['kind'] ?? '' ), $kinds, true ) ) {
				$problems[] = sprintf(
					/* translators: %s: id do campo. */
					__( '%s tem kind desconhecido', 'wp-mcp-google-fator3' ),
					$id
				);
			}

			$native = (string) ( $field['native'] ?? '' );

			// Campo derivado (ROAS) não tem nativo — é calculado no PHP.
			if ( '' === $native ) {
				if ( empty( $field['derived'] ) ) {
					$problems[] = sprintf(
						/* translators: %s: id do campo. */
						__( '%s está sem nome nativo e não está marcado como derivado', 'wp-mcp-google-fator3' ),
						$id
					);
				}

				continue;
			}

			$prefixed = false;
			foreach ( $prefixes as $prefix ) {
				if ( 0 === strpos( $native, $prefix ) ) {
					$prefixed = true;
					break;
				}
			}

			if ( ! $prefixed ) {
				$problems[] = sprintf(
					/* translators: 1: id, 2: nome nativo. */
					__( '%1$s aponta para "%2$s", que não tem prefixo de recurso conhecido', 'wp-mcp-google-fator3' ),
					$id,
					$native
				);
			}
		}

		// Resolução pelos dois caminhos, e recusa do que não é campo.
		$by_id     = Catalog::ads_resolve( 'cost' );
		$by_native = Catalog::ads_resolve( 'metrics.clicks' );
		$synth     = Catalog::ads_resolve( 'metrics.video_quartile_p75_rate' );
		$refused   = Catalog::ads_resolve( 'nao existe' );

		if ( is_wp_error( $by_id ) || 'metrics.cost_micros' !== $by_id['native'] ) {
			$problems[] = __( 'cost não resolve para metrics.cost_micros', 'wp-mcp-google-fator3' );
		}

		if ( is_wp_error( $by_native ) || 'clicks' !== $by_native['id'] ) {
			$problems[] = __( 'metrics.clicks não volta pelo id do catálogo', 'wp-mcp-google-fator3' );
		}

		if ( is_wp_error( $synth ) || 'metric' !== $synth['type'] ) {
			$problems[] = __( 'um nativo fora do catálogo não foi sintetizado', 'wp-mcp-google-fator3' );
		}

		if ( ! is_wp_error( $refused ) ) {
			$problems[] = __( 'um nome sem sentido foi aceito como campo', 'wp-mcp-google-fator3' );
		}

		return self::check(
			'catalog',
			empty( $problems ),
			empty( $problems )
				? sprintf(
					/* translators: %d: quantidade de campos do catálogo. */
					__( '%d campos, ids únicos, nativos com prefixo de recurso e resolução pelos dois caminhos.', 'wp-mcp-google-fator3' ),
					count( $fields )
				)
				: implode( '; ', array_slice( $problems, 0, 5 ) )
		);
	}

	/**
	 * Tradução de filtros para a árvore de expressões do GA4.
	 */
	private static function check_filters_ga(): array {
		$translated = Filters::to_ga(
			array(
				array(
					'field'    => 'channel',
					'operator' => 'contains',
					'value'    => 'Organic',
				),
				array(
					'field'    => 'country',
					'operator' => 'in',
					'value'    => array( 'Brazil', 'Portugal' ),
				),
				array(
					'field'    => 'sessions',
					'operator' => 'gte',
					'value'    => 100,
				),
			),
			array( 'sessionDefaultChannelGroup', 'country' ),
			array( 'sessions' )
		);

		if ( is_wp_error( $translated ) ) {
			return self::check( 'filters_ga', false, $translated->get_error_message() );
		}

		$dimension = $translated['dimensionFilter'] ?? array();
		$metric    = $translated['metricFilter'] ?? array();

		$ok = isset( $dimension['andGroup']['expressions'] )
			&& 2 === count( $dimension['andGroup']['expressions'] )
			&& 'sessionDefaultChannelGroup' === ( $dimension['andGroup']['expressions'][0]['filter']['fieldName'] ?? '' )
			&& 'CONTAINS' === ( $dimension['andGroup']['expressions'][0]['filter']['stringFilter']['matchType'] ?? '' )
			&& isset( $dimension['andGroup']['expressions'][1]['filter']['inListFilter']['values'] )
			&& 'sessions' === ( $metric['filter']['fieldName'] ?? '' )
			&& 'GREATER_THAN_OR_EQUAL' === ( $metric['filter']['numericFilter']['operation'] ?? '' )
			&& '100' === ( $metric['filter']['numericFilter']['value']['int64Value'] ?? '' );

		return self::check(
			'filters_ga',
			$ok,
			$ok
				? __( 'Dimensão vira dimensionFilter (andGroup com CONTAINS e inListFilter) e métrica vira metricFilter numérico.', 'wp-mcp-google-fator3' )
				: __( 'A tradução de filtros para o GA4 saiu fora do formato esperado.', 'wp-mcp-google-fator3' )
		);
	}

	/**
	 * Tradução de filtros para o WHERE da GAQL.
	 */
	private static function check_filters_gaql(): array {
		$conditions = Filters::to_gaql(
			array(
				array(
					'field'    => 'campaign_status',
					'operator' => 'eq',
					'value'    => 'enabled',
				),
				array(
					'field'    => 'campaign_name',
					'operator' => 'contains',
					'value'    => "Black Friday's",
				),
				array(
					'field'    => 'cost',
					'operator' => 'gt',
					'value'    => 100,
				),
			),
			array( Catalog::class, 'ads_resolve' )
		);

		if ( is_wp_error( $conditions ) ) {
			return self::check( 'filters_gaql', false, $conditions->get_error_message() );
		}

		$expected = array(
			'campaign.status = ENABLED',
			"campaign.name LIKE '%Black Friday\\'s%'",
			'metrics.cost_micros > 100000000',
		);

		$ok = $conditions === $expected;

		return self::check(
			'filters_gaql',
			$ok,
			$ok
				? __( 'Enum sem aspas e em maiúsculas, string com aspa escapada dentro do LIKE, e valor em moeda convertido para micros.', 'wp-mcp-google-fator3' )
				: sprintf(
					/* translators: %s: condições obtidas. */
					__( 'Condições GAQL inesperadas: %s', 'wp-mcp-google-fator3' ),
					implode( ' | ', $conditions )
				)
		);
	}

	/**
	 * Um `google/query` de exemplo vira o corpo GA e a GAQL esperados, sem rede.
	 */
	private static function check_query_build(): array {
		if ( ! class_exists( Query::class ) ) {
			return self::check( 'query_build', true, __( 'Pulado: a camada unificada não está carregada.', 'wp-mcp-google-fator3' ) );
		}

		$ga = Query::preview(
			array(
				'connector'          => 'ga4',
				'accounts'           => array( 'properties/123456' ),
				'metrics'            => array( 'sessions' ),
				'dimensions'         => array( 'channel' ),
				'date_range'         => array(
					'from' => '2026-08-01',
					'to'   => '2026-08-31',
				),
				'compare_date_range' => 'previous_period',
				'order_by'           => array(
					array(
						'field'     => 'sessions',
						'direction' => 'desc',
					),
				),
				'limit'              => 25,
			)
		);

		if ( is_wp_error( $ga ) ) {
			return self::check( 'query_build', false, $ga->get_error_message() );
		}

		$body = $ga['ga_body'];

		$ga_ok = 2 === count( $body['dateRanges'] )
			&& '2026-08-01' === $body['dateRanges'][0]['startDate']
			&& 'current' === $body['dateRanges'][0]['name']
			&& '2026-07-01' === $body['dateRanges'][1]['startDate']
			&& '2026-07-31' === $body['dateRanges'][1]['endDate']
			&& 'sessionDefaultChannelGroup' === $body['dimensions'][0]['name']
			&& 'sessions' === $body['metrics'][0]['name']
			&& 'sessions' === ( $body['orderBys'][0]['metric']['metricName'] ?? '' )
			&& true === ( $body['orderBys'][0]['desc'] ?? false )
			&& 25 === $body['limit']
			&& 'date_range_name' === ( $ga['columns'][0]['id'] ?? '' );

		if ( ! $ga_ok ) {
			return self::check( 'query_build', false, __( 'O corpo do runReport saiu fora do esperado.', 'wp-mcp-google-fator3' ) );
		}

		if ( ! class_exists( '\\Fator3\\McpGoogle\\Ads\\Gaql' ) ) {
			return self::check( 'query_build', true, __( 'Corpo do GA4 conferido; o módulo do Google Ads não está carregado.', 'wp-mcp-google-fator3' ) );
		}

		$ads = Query::preview(
			array(
				'connector'  => 'google-ads',
				'accounts'   => array( '1234567890' ),
				'metrics'    => array( 'cost', 'clicks' ),
				'dimensions' => array( 'campaign_name', 'date' ),
				'date_range' => array(
					'from' => '2026-08-01',
					'to'   => '2026-08-31',
				),
				'filters'    => array(
					array(
						'field'    => 'campaign_status',
						'operator' => 'eq',
						'value'    => 'ENABLED',
					),
				),
				'order_by'   => array(
					array(
						'field'     => 'cost',
						'direction' => 'desc',
					),
				),
				'limit'      => 50,
			)
		);

		if ( is_wp_error( $ads ) ) {
			return self::check( 'query_build', false, $ads->get_error_message() );
		}

		$expected = 'SELECT campaign.name, segments.date, metrics.cost_micros, metrics.clicks FROM campaign'
			. " WHERE campaign.status = ENABLED AND segments.date BETWEEN '2026-08-01' AND '2026-08-31'"
			. ' ORDER BY metrics.cost_micros DESC LIMIT 50 PARAMETERS omit_unselected_resource_names=true';

		$ads_ok = 'campaign' === $ads['resource'] && $expected === $ads['gaql'];

		return self::check(
			'query_build',
			$ads_ok,
			$ads_ok
				? __( 'Corpo do runReport e GAQL montados como esperado, com período, filtros, ordenação e limite.', 'wp-mcp-google-fator3' )
				: sprintf(
					/* translators: %s: consulta obtida. */
					__( 'GAQL inesperada: %s', 'wp-mcp-google-fator3' ),
					(string) $ads['gaql']
				)
		);
	}

	/**
	 * Pede um access token de verdade — o único teste que sai para a rede.
	 */
	private static function check_token(): array {
		$credentials = Credentials::current();

		if ( is_wp_error( $credentials ) ) {
			return self::check( 'token', false, $credentials->get_error_message() );
		}

		$described = $credentials->describe();
		$token     = $credentials->get_access_token( Credentials::scopes_for( 'any' ) );

		if ( is_wp_error( $token ) ) {
			return self::check( 'token', false, $token->get_error_message() );
		}

		// Só o comprimento e a identidade — nunca o token.
		return self::check(
			'token',
			true,
			sprintf(
				/* translators: 1: modo de autenticação, 2: identidade da credencial. */
				__( 'Access token obtido (%1$s, %2$s).', 'wp-mcp-google-fator3' ),
				(string) ( $described['mode'] ?? '' ),
				(string) ( $described['identity'] ?? '' )
			)
		);
	}

	/**
	 * Uma chamada mínima ao Analytics: prova que o token vale para o GA e que a
	 * credencial enxerga alguma propriedade.
	 */
	private static function check_live_ga(): array {
		$summaries = \Fator3\McpGoogle\Analytics\AdminApi::account_summaries();

		if ( is_wp_error( $summaries ) ) {
			$skip = self::token_problem( $summaries );

			return '' !== $skip
				? self::check( 'live_ga', true, $skip )
				: self::check( 'live_ga', false, $summaries->get_error_message() );
		}

		$properties = 0;
		foreach ( (array) $summaries as $summary ) {
			$properties += is_array( $summary ) ? count( (array) ( $summary['propertySummaries'] ?? array() ) ) : 0;
		}

		return self::check(
			'live_ga',
			true,
			sprintf(
				/* translators: 1: contas, 2: propriedades. */
				__( 'accountSummaries respondeu: %1$d conta(s), %2$d propriedade(s).', 'wp-mcp-google-fator3' ),
				count( (array) $summaries ),
				$properties
			)
		);
	}

	/**
	 * Uma chamada mínima ao Google Ads: prova token, developer token e
	 * login-customer-id de uma vez só.
	 */
	private static function check_live_ads(): array {
		// Sem developer token a Google Ads recusa qualquer chamada com um 401
		// que não diz o que falta. Dizer aqui poupa a requisição e nomeia o
		// campo que está vazio na tela.
		if ( '' === Options::get_secret( Options::ADS_DEVELOPER_TOKEN ) ) {
			return self::check(
				'live_ads',
				true,
				__( 'Pulado: a Google Ads API exige um developer token e ele não está configurado.', 'wp-mcp-google-fator3' )
			);
		}

		$customers = \Fator3\McpGoogle\Ads\AdsApi::list_accessible_customers();

		if ( is_wp_error( $customers ) ) {
			$skip = self::token_problem( $customers );

			return '' !== $skip
				? self::check( 'live_ads', true, $skip )
				: self::check( 'live_ads', false, $customers->get_error_message() );
		}

		return self::check(
			'live_ads',
			true,
			sprintf(
				/* translators: %d: quantidade de contas acessíveis. */
				__( 'listAccessibleCustomers respondeu: %d conta(s) acessível(is).', 'wp-mcp-google-fator3' ),
				count( (array) $customers )
			)
		);
	}

	/**
	 * O erro é da obtenção do token, e não da API consultada?
	 *
	 * Cada conector pede o token com o seu próprio escopo, então uma credencial
	 * quebrada faz `live_ga` e `live_ads` falharem pelo mesmo motivo que a
	 * checagem `token` já reportou. Repetir a mesma falha três vezes esconde a
	 * causa em vez de mostrá-la: quando o erro veio do endpoint de token, estas
	 * duas checagens saem como puladas e apontam para a que manda no assunto.
	 *
	 * @param \WP_Error $error Erro devolvido pela API.
	 * @return string Motivo do pulo, ou '' quando a falha é da própria API.
	 */
	private static function token_problem( \WP_Error $error ): string {
		$code = (string) $error->get_error_code();
		$data = $error->get_error_data();
		$url  = is_array( $data ) && isset( $data['url'] ) ? (string) $data['url'] : '';

		$from_token = 0 === strpos( $url, GoogleClient::HOST_TOKEN )
			|| in_array( $code, array( 'f3_google_not_configured', 'f3_google_oauth_revoked', 'f3_google_sa_invalid' ), true );

		if ( ! $from_token ) {
			return '';
		}

		return sprintf(
			/* translators: %s: mensagem do erro. */
			__( 'Pulado: não foi possível obter um access token para este conector (%s). Ver a checagem "token".', 'wp-mcp-google-fator3' ),
			$error->get_error_message()
		);
	}

	/**
	 * @return array{name:string,ok:bool,detail:string}
	 */
	private static function check( string $name, bool $ok, string $detail ): array {
		return array(
			'name'   => $name,
			'ok'     => $ok,
			'detail' => $detail,
		);
	}
}
