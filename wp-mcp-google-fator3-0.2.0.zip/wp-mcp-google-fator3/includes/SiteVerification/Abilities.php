<?php
/**
 * Verificação de propriedade e proprietários Google. Não instala tokens.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\SiteVerification;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Abilities {
	public static function register(): void {
		$site         = array(
			'type'                 => 'object',
			'properties'           => array(
				'type'       => array(
					'type' => 'string',
					'enum' => array( 'SITE', 'INET_DOMAIN' ),
				),
				'identifier' => array( 'type' => 'string' ),
			),
			'required'             => array( 'type', 'identifier' ),
			'additionalProperties' => false,
		);
		$verification = array(
			'site'                => $site,
			'verification_method' => array(
				'type'        => 'string',
				'enum'        => array( 'FILE', 'META', 'DNS_TXT', 'DNS_CNAME', 'ANALYTICS', 'TAG_MANAGER', 'DNS' ),
				'description' => 'SITE: FILE/META/ANALYTICS/TAG_MANAGER; INET_DOMAIN: DNS_TXT/DNS_CNAME. DNS é alias legado para DNS_TXT.',
			),
		);
		self::register_one( 'get-token', 'read', 'Obtém o token e o método de verificação. Instalar arquivo, meta tag ou DNS é tarefa separada.', $verification, array( 'site', 'verification_method' ) );
		self::register_one(
			'verify',
			'write',
			'Confirma um token já instalado e torna a credencial proprietária verificada.',
			$verification + array(
				'owners' => array(
					'type'  => 'array',
					'items' => array( 'type' => 'string' ),
				),
			),
			array( 'site', 'verification_method' )
		);
		self::register_one(
			'update-owners',
			'write',
			'Substitui a lista completa de proprietários; a API exige preservar o proprietário autenticado.',
			array(
				'id'     => array(
					'type'        => 'string',
					'description' => 'ID exato devolvido por siteverification/list ou verify.',
				),
				'owners' => array(
					'type'     => 'array',
					'items'    => array( 'type' => 'string' ),
					'minItems' => 1,
				),
				'site'   => $site,
			),
			array( 'id', 'owners' )
		);
		self::register_one( 'list', 'read', 'Lista sites e domínios verificados pela credencial.', array(), array() );
	}

	private static function register_one( string $name, string $mode, string $description, array $properties, array $required ): void {
		if ( 'write' === $mode ) {
			$properties['dry_run'] = array(
				'type'        => 'boolean',
				'description' => 'A API não oferece validateOnly; true é recusado antes da mutação.',
			);
		}
		Ability::register(
			'siteverification/' . $name,
			'siteverification',
			array(
				'label'        => 'Site Verification: ' . $name,
				'description'  => $description,
				'mode'         => $mode,
				'input_schema' => array(
					'properties' => $properties,
					'required'   => $required,
				),
				'callback'     => static function ( array $input ) use ( $name ): array {
							return self::run( $name, $input );
				},
			)
		);
	}

	public static function run( string $name, array $input ): array {
		$write = in_array( $name, array( 'verify', 'update-owners' ), true );
		if ( $write && ! empty( $input['dry_run'] ) ) {
			return Response::fail( new \WP_Error( 'f3_google_dry_run_unsupported', 'Site Verification não oferece validateOnly. Nenhuma alteração foi enviada.' ) );
		}
		if ( 'list' === $name ) {
			$result = ExecuteAction::call( 'site-verification', 'siteVerification.webResource.list', array(), array(), null, array( 'mode' => 'read' ) );
			return is_wp_error( $result ) ? Response::fail( $result ) : Response::ok(
				array(
					'sites' => $result['items'] ?? array(),
					'count' => count( $result['items'] ?? array() ),
				),
				'Recursos verificados.'
			);
		}
		if ( 'update-owners' === $name ) {
			return self::update_owners( $input );
		}
		if ( ! in_array( $name, array( 'get-token', 'verify' ), true ) ) {
			return Response::fail( self::error( 'Operação Site Verification desconhecida.' ) );
		}
		$site = self::site( $input['site'] ?? null );
		if ( is_wp_error( $site ) ) {
			return Response::fail( $site );
		}
		$method  = is_string( $input['verification_method'] ?? null ) ? strtoupper( $input['verification_method'] ) : '';
		$method  = 'DNS' === $method ? 'DNS_TXT' : $method;
		$allowed = 'INET_DOMAIN' === $site['type'] ? array( 'DNS_TXT', 'DNS_CNAME' ) : array( 'FILE', 'META', 'ANALYTICS', 'TAG_MANAGER' );
		if ( ! in_array( $method, $allowed, true ) ) {
			return Response::fail( self::error( 'Método incompatível com ' . $site['type'] . '. Use ' . implode( ', ', $allowed ) . '.' ) );
		}
		if ( 'get-token' === $name ) {
			$result = ExecuteAction::call(
				'site-verification',
				'siteVerification.webResource.getToken',
				array(),
				array(),
				array(
					'site'               => $site,
					'verificationMethod' => $method,
				),
				array( 'mode' => 'read' )
			);
			return is_wp_error( $result ) ? Response::fail( $result ) : Response::ok(
				array(
					'site'                => $site,
					'verification_method' => $method,
					'token'               => $result['token'] ?? '',
					'data'                => $result,
					'next_step'           => 'Instale o token conforme o método no site ou DNS; depois execute siteverification/verify.',
				),
				'Token de verificação obtido.'
			);
		}
		$body = array( 'site' => $site );
		if ( isset( $input['owners'] ) ) {
			$owners = self::owners( $input['owners'] );
			if ( is_wp_error( $owners ) ) {
				return Response::fail( $owners );
			}
			$body['owners'] = $owners;
		}
		Audit::before( self::find_snapshot( $site ) );
		$result = ExecuteAction::call( 'site-verification', 'siteVerification.webResource.insert', array(), array( 'verificationMethod' => $method ), $body, array( 'mode' => 'write' ) );
		if ( is_wp_error( $result ) ) {
			return Response::fail( $result );
		}
		Audit::after(
			array(
				'available' => true,
				'exists'    => true,
				'resource'  => $result,
			)
		);
		return Response::ok( array( 'data' => $result ), 'Propriedade verificada.' );
	}

	private static function update_owners( array $input ): array {
		$id = $input['id'] ?? '';
		if ( ! is_string( $id ) || '' === trim( $id ) || preg_match( '/[\x00-\x20]/', $id ) ) {
			return Response::fail( self::error( 'Informe o id exato de siteverification/list ou verify.' ) );
		}
		$owners = self::owners( $input['owners'] ?? null );
		if ( is_wp_error( $owners ) ) {
			return Response::fail( $owners );
		}
		$before = ExecuteAction::call( 'site-verification', 'siteVerification.webResource.get', array( 'id' => $id ), array(), null, array( 'mode' => 'read' ) );
		Audit::before(
			is_wp_error( $before ) ? array(
				'available' => false,
				'reason'    => $before->get_error_message(),
			) : array(
				'available' => true,
				'exists'    => true,
				'resource'  => $before,
			)
		);
		$site = self::site( $input['site'] ?? ( is_wp_error( $before ) ? null : ( $before['site'] ?? null ) ) );
		if ( is_wp_error( $site ) ) {
			return Response::fail( is_wp_error( $before ) ? $before : $site );
		}
		$result = ExecuteAction::call(
			'site-verification',
			'siteVerification.webResource.update',
			array( 'id' => $id ),
			array(),
			array(
				'id'     => $id,
				'site'   => $site,
				'owners' => $owners,
			),
			array( 'mode' => 'write' )
		);
		if ( is_wp_error( $result ) ) {
			return Response::fail( $result );
		}
		Audit::after(
			array(
				'available' => true,
				'exists'    => true,
				'resource'  => $result,
			)
		);
		return Response::ok( array( 'data' => $result ), 'Lista de proprietários atualizada.' );
	}

	private static function find_snapshot( array $site ): array {
		$result = ExecuteAction::call( 'site-verification', 'siteVerification.webResource.list', array(), array(), null, array( 'mode' => 'read' ) );
		if ( is_wp_error( $result ) ) {
			return array(
				'available' => false,
				'reason'    => $result->get_error_message(),
			);
		}
		foreach ( $result['items'] ?? array() as $resource ) {
			if ( ( $resource['site']['type'] ?? null ) === $site['type'] && ( $resource['site']['identifier'] ?? null ) === $site['identifier'] ) {
				return array(
					'available' => true,
					'exists'    => true,
					'resource'  => $resource,
				);
			}
		}
		return array(
			'available' => true,
			'exists'    => false,
			'scope'     => 'verified_resources_visible_to_current_credential',
		);
	}

	private static function site( $site ) {
		if ( ! is_array( $site ) || ! is_string( $site['identifier'] ?? null ) || ! in_array( $site['type'] ?? '', array( 'SITE', 'INET_DOMAIN' ), true ) ) {
			return self::error( 'site exige {type:SITE|INET_DOMAIN, identifier:URL|domínio}.' );
		}
		$identifier = $site['identifier'];
		if ( 'INET_DOMAIN' === $site['type'] ) {
			$valid = preg_match( '/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $identifier );
		} else {
			$parts = wp_parse_url( $identifier );
			$valid = false !== $parts && ! empty( $parts['host'] ) && in_array( $parts['scheme'] ?? '', array( 'http', 'https' ), true ) && ! isset( $parts['user'] ) && ! isset( $parts['fragment'] ) && ! preg_match( '/[\x00-\x20]/', $identifier );
		}
		return $valid ? array(
			'type'       => $site['type'],
			'identifier' => $identifier,
		) : self::error( 'Identificador inválido para o tipo ' . $site['type'] . '.' );
	}

	private static function owners( $owners ) {
		if ( ! is_array( $owners ) || empty( $owners ) ) {
			return self::error( 'owners deve ser a lista completa não vazia de emails dos proprietários.' );
		}
		$out = array();
		foreach ( $owners as $owner ) {
			if ( ! is_string( $owner ) || false === filter_var( $owner, FILTER_VALIDATE_EMAIL ) ) {
				return self::error( 'Cada proprietário precisa ser um email válido.' );
			}
			$out[] = $owner;
		}
		return array_values( array_unique( $out ) );
	}

	private static function error( string $message ): \WP_Error {
		return new \WP_Error( 'f3_google_verification_input', $message );
	}
}
