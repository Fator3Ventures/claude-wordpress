<?php
/**
 * Normalização do identificador de propriedade do GA4.
 *
 * O agente pode mandar `123456`, `"123456"` ou `"properties/123456"` — e às
 * vezes nada, contando com a propriedade padrão da tela. Concentrar essa
 * leitura aqui evita que cada habilidade monte a própria expressão regular e,
 * principalmente, evita concatenar entrada do agente numa URL sem validar que
 * é mesmo uma sequência de dígitos.
 *
 * @package Fator3\McpGoogle\Analytics
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Options;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class PropertyId {

	/**
	 * Aceita int, string, 'properties/123' ou ' 123 '. Vazio usa
	 * `GA_DEFAULT_PROPERTY`.
	 *
	 * @param mixed $value Valor recebido do agente (pode ser ausente/null).
	 * @return string|\WP_Error 'properties/123', ou erro.
	 */
	public static function normalize( $value ) {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';

		if ( '' === $value ) {
			$default = trim( (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ) );

			if ( '' === $default ) {
				return new \WP_Error(
					'f3_google_property_required',
					__( 'Informe property_id: nenhuma propriedade padrão está configurada em Ferramentas > MCP Google.', 'wp-mcp-google-fator3' )
				);
			}

			$value = $default;
		}

		$digits = '';

		if ( preg_match( '/^properties\/(\d+)\z/', $value, $matches ) ) {
			$digits = $matches[1];
		} elseif ( preg_match( '/^\d+\z/', $value ) ) {
			$digits = $value;
		}

		if ( '' !== $digits ) {
			// `properties/0` é o pseudo-recurso do catálogo universal de
			// metadados, não uma propriedade: quem o quer chama
			// `DataApi::metadata( null )`. Vindo do agente, um zero é sempre
			// engano — e sem esta checagem viraria uma chamada à Google que
			// volta com um erro que não explica nada.
			if ( '' === ltrim( $digits, '0' ) ) {
				return new \WP_Error(
					'f3_google_bad_property_id',
					__( 'property_id inválido: 0 não é uma propriedade. Use ga/get-account-summaries para descobrir o número certo.', 'wp-mcp-google-fator3' )
				);
			}

			return 'properties/' . $digits;
		}

		return new \WP_Error(
			'f3_google_bad_property_id',
			__( 'property_id inválido: use um número ou o formato "properties/<número>".', 'wp-mcp-google-fator3' )
		);
	}

	/**
	 * Só o número, sem o prefixo `properties/`.
	 *
	 * @param mixed $value Ver normalize().
	 * @return string|\WP_Error
	 */
	public static function number( $value ) {
		$normalized = self::normalize( $value );

		if ( is_wp_error( $normalized ) ) {
			return $normalized;
		}

		return substr( $normalized, strlen( 'properties/' ) );
	}
}
