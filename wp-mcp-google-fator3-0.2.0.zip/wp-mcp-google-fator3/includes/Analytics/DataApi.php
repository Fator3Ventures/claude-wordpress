<?php
/**
 * Chamadas à Data API do GA4 (relatórios) e as duas conversões que toda
 * habilidade de relatório precisa: `normalize_keys()` para aceitar filtros e
 * `order_bys` tanto em snake_case (como nos exemplos do MCP oficial do Google,
 * em Python) quanto em camelCase (como na REST), e `to_table()` para poupar
 * tokens do agente devolvendo colunas e linhas em vez do JSON aninhado da
 * Google.
 *
 * O corpo de cada requisição já vem pronto de `Abilities.php` — esta classe só
 * decide a URL (v1beta ou v1alpha, `:runReport` etc.) e faz o POST/GET.
 *
 * @package Fator3\McpGoogle\Analytics
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DataApi {

	/**
	 * Metadados de dimensões/métricas: os dois catálogos que existem no GA4.
	 *
	 * @param mixed $property_id_or_null `null` pede o catálogo universal
	 *                                    (`properties/0`, sem dimensões/métricas
	 *                                    customizadas); qualquer outro valor
	 *                                    passa por `PropertyId::normalize()`.
	 * @return array|\WP_Error
	 */
	public static function metadata( $property_id_or_null ) {
		if ( null === $property_id_or_null ) {
			$rn = 'properties/0';
		} else {
			$rn = PropertyId::normalize( $property_id_or_null );
			if ( is_wp_error( $rn ) ) {
				return $rn;
			}
		}

		return GoogleClient::get(
			GoogleClient::HOST_GA_DATA . '/v1beta/' . $rn . '/metadata',
			array(),
			self::opts()
		);
	}

	/**
	 * @param string $property_rn 'properties/123'.
	 * @param array  $body        Corpo já em camelCase, pronto para a API.
	 * @return array|\WP_Error
	 */
	public static function run_report( string $property_rn, array $body ) {
		return GoogleClient::post(
			GoogleClient::HOST_GA_DATA . '/v1beta/' . $property_rn . ':runReport',
			$body,
			self::opts()
		);
	}

	/**
	 * @param string $property_rn 'properties/123'.
	 * @param array  $body        Corpo já em camelCase.
	 * @return array|\WP_Error
	 */
	public static function run_realtime_report( string $property_rn, array $body ) {
		return GoogleClient::post(
			GoogleClient::HOST_GA_DATA . '/v1beta/' . $property_rn . ':runRealtimeReport',
			$body,
			self::opts()
		);
	}

	/**
	 * @param string $property_rn 'properties/123'.
	 * @param array  $body        Corpo já em camelCase.
	 * @return array|\WP_Error
	 */
	public static function check_compatibility( string $property_rn, array $body ) {
		return GoogleClient::post(
			GoogleClient::HOST_GA_DATA . '/v1beta/' . $property_rn . ':checkCompatibility',
			$body,
			self::opts()
		);
	}

	/**
	 * v1alpha: funil ainda não tem versão estável na Data API.
	 *
	 * @param string $property_rn 'properties/123'.
	 * @param array  $body        Corpo já em camelCase.
	 * @return array|\WP_Error
	 */
	public static function run_funnel_report( string $property_rn, array $body ) {
		return GoogleClient::post(
			GoogleClient::HOST_GA_DATA . '/v1alpha/' . $property_rn . ':runFunnelReport',
			$body,
			self::opts()
		);
	}

	/**
	 * v1alpha: `runReport` com `conversionSpec` — o recurso de conversões
	 * ainda não chegou ao v1beta.
	 *
	 * @param string $property_rn 'properties/123'.
	 * @param array  $body        Corpo já em camelCase, incluindo `conversionSpec`.
	 * @return array|\WP_Error
	 */
	public static function run_conversions_report( string $property_rn, array $body ) {
		return GoogleClient::post(
			GoogleClient::HOST_GA_DATA . '/v1alpha/' . $property_rn . ':runReport',
			$body,
			self::opts()
		);
	}

	/**
	 * Converte recursivamente as CHAVES de um valor de snake_case para
	 * camelCase — nunca os valores. É o que deixa o agente escrever um
	 * `dimension_filter` copiado dos exemplos em Python do MCP oficial do
	 * Google (`field_name`, `and_group`, `match_type`, `int64_value`, ...) e
	 * ainda assim produzir o JSON que a REST API espera (`fieldName`,
	 * `andGroup`, `matchType`, `int64Value`, ...).
	 *
	 * Uma chave já em camelCase (sem underscore) sai igual. Enums como
	 * `CONTAINS`, `DATA_DRIVEN` ou `ALPHANUMERIC` são VALORES, não chaves —
	 * por isso nunca são tocados aqui, e continuam em maiúsculas como a API
	 * exige.
	 *
	 * @param mixed $value Estrutura (array associativo, lista, ou escalar).
	 * @return mixed
	 */
	public static function normalize_keys( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$result = array();

		foreach ( $value as $key => $item ) {
			$normalized_item = self::normalize_keys( $item );

			if ( is_int( $key ) ) {
				$result[ $key ] = $normalized_item;
			} else {
				$result[ self::camel_case( (string) $key ) ] = $normalized_item;
			}
		}

		return $result;
	}

	/**
	 * @param string $key Nome de campo, ex.: 'field_name' ou já 'fieldName'.
	 */
	private static function camel_case( string $key ): string {
		if ( false === strpos( $key, '_' ) ) {
			return $key;
		}

		$parts = explode( '_', $key );
		$first = (string) array_shift( $parts );

		foreach ( $parts as $part ) {
			$first .= '' === $part ? '' : ucfirst( $part );
		}

		return $first;
	}

	/**
	 * Formato `table`: colunas + linhas posicionais, em vez do JSON aninhado
	 * da Google — é o que poupa tokens do agente num relatório de milhares de
	 * linhas.
	 *
	 * A resposta da Google já traz a dimensão `dateRange` como a primeira de
	 * `dimensionHeaders` quando o pedido tinha 2+ `dateRanges` — este método
	 * não precisa (nem deve) inserir nada: só lê os cabeçalhos como vieram.
	 *
	 * @param array $response Resposta decodificada de runReport/
	 *                         runRealtimeReport/checkCompatibility (ou
	 *                         `funnelTable` de um relatório de funil).
	 * @return array {columns, rows, row_count, row_count_total, truncated,
	 *                totals?, maximums?, minimums?, property_quota?, metadata?}
	 */
	public static function to_table( array $response ): array {
		$dimension_headers = self::list_of( $response, 'dimensionHeaders' );
		$metric_headers    = self::list_of( $response, 'metricHeaders' );

		$columns = array();
		foreach ( $dimension_headers as $header ) {
			$columns[] = isset( $header['name'] ) ? (string) $header['name'] : '';
		}
		foreach ( $metric_headers as $header ) {
			$columns[] = isset( $header['name'] ) ? (string) $header['name'] : '';
		}

		$metric_types = array();
		foreach ( $metric_headers as $header ) {
			$metric_types[] = isset( $header['type'] ) ? (string) $header['type'] : '';
		}

		$rows     = array();
		$raw_rows = self::list_of( $response, 'rows' );
		foreach ( $raw_rows as $row ) {
			$rows[] = self::row_values( is_array( $row ) ? $row : array(), $metric_types );
		}

		$row_count       = count( $rows );
		$row_count_total = isset( $response['rowCount'] ) && is_numeric( $response['rowCount'] )
			? (int) $response['rowCount']
			: $row_count;

		$table = array(
			'columns'         => $columns,
			'rows'            => $rows,
			'row_count'       => $row_count,
			'row_count_total' => $row_count_total,
			// Sem saber o `offset` pedido (não faz parte desta resposta), o
			// melhor palpite é comparar contra zero; quem conhece o offset
			// (a habilidade que chamou run_report) recalcula com precisão.
			'truncated'       => $row_count_total > $row_count,
		);

		foreach ( array( 'totals', 'maximums', 'minimums' ) as $key ) {
			$items = self::list_of( $response, $key );
			if ( ! empty( $items ) ) {
				$table[ $key ] = array_map(
					static function ( $row ) use ( $metric_types ): array {
						return self::row_values( is_array( $row ) ? $row : array(), $metric_types );
					},
					$items
				);
			}
		}

		if ( isset( $response['propertyQuota'] ) && is_array( $response['propertyQuota'] ) ) {
			$table['property_quota'] = $response['propertyQuota'];
		}

		if ( isset( $response['metadata'] ) && is_array( $response['metadata'] ) ) {
			$table['metadata'] = $response['metadata'];
		}

		return $table;
	}

	/**
	 * Uma linha (rows/totals/maximums/minimums) para o formato posicional:
	 * valores de dimensão como veio, valores de métrica convertidos para
	 * número.
	 *
	 * @param array    $row          {dimensionValues?, metricValues?}.
	 * @param string[] $metric_types Tipo de cada métrica, na mesma ordem.
	 * @return array
	 */
	private static function row_values( array $row, array $metric_types ): array {
		$values = array();

		foreach ( self::list_of( $row, 'dimensionValues' ) as $dv ) {
			$values[] = isset( $dv['value'] ) ? (string) $dv['value'] : '';
		}

		foreach ( self::list_of( $row, 'metricValues' ) as $index => $mv ) {
			$raw      = isset( $mv['value'] ) ? (string) $mv['value'] : '';
			$type     = $metric_types[ $index ] ?? '';
			$values[] = self::metric_number( $raw, $type );
		}

		return $values;
	}

	/**
	 * `TYPE_CURRENCY` e `TYPE_FLOAT` sempre viram float (mesmo "10" vira
	 * 10.0 — é dinheiro/proporção, não contagem). Os demais tipos (contagem,
	 * segundos, etc.) viram int quando o texto é um inteiro, e float quando
	 * não é.
	 *
	 * @param string $raw  Valor como string, do jeito que a API devolve.
	 * @param string $type `metricHeaders[].type` (ex.: 'TYPE_INTEGER').
	 * @return int|float|string
	 */
	private static function metric_number( string $raw, string $type ) {
		if ( in_array( $type, array( 'TYPE_CURRENCY', 'TYPE_FLOAT' ), true ) ) {
			return is_numeric( $raw ) ? (float) $raw : $raw;
		}

		if ( preg_match( '/^-?\d+$/', $raw ) ) {
			return (int) $raw;
		}

		return is_numeric( $raw ) ? (float) $raw : $raw;
	}

	/**
	 * @param array  $data Estrutura decodificada.
	 * @param string $key  Chave esperada como lista.
	 * @return array
	 */
	private static function list_of( array $data, string $key ): array {
		return isset( $data[ $key ] ) && is_array( $data[ $key ] ) ? $data[ $key ] : array();
	}

	/**
	 * Escopo e conector padrão de toda chamada desta classe.
	 */
	private static function opts(): array {
		return array(
			'scopes'    => Credentials::scopes_for( 'ga' ),
			'connector' => 'ga',
		);
	}
}
