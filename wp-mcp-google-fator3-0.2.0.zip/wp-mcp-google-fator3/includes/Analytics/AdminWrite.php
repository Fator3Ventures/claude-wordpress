<?php
/**
 * Administração GA4: operações nomeadas sobre a descoberta oficial v1alpha.
 *
 * @package Fator3\McpGoogle\Analytics
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Generic\ExecuteAction;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminWrite {

	private const API = 'analytics-admin-v1alpha';

	/**
	 * Método, tipo de alvo e operação. IDs conferidos na descoberta 20260901.
	 * O corpo usa os nomes oficiais em camelCase; snake_case também é aceito.
	 */
	private static function definitions(): array {
		return array(
			'create-property'             => array( 'properties.create', 'property', 'create' ),
			'update-property'             => array( 'properties.patch', 'property', 'patch' ),
			'delete-property'             => array( 'properties.delete', 'property', 'delete' ),
			'provision-account'           => array( 'accounts.provisionAccountTicket', 'account', 'provision' ),
			'delete-account'              => array( 'accounts.delete', 'account', 'delete' ),
			'create-web-stream'           => array( 'properties.dataStreams.create', 'dataStreams', 'create' ),
			'update-web-stream'           => array( 'properties.dataStreams.patch', 'dataStreams', 'patch' ),
			'delete-web-stream'           => array( 'properties.dataStreams.delete', 'dataStreams', 'delete' ),
			'update-enhanced-measurement' => array( 'properties.dataStreams.updateEnhancedMeasurementSettings', 'enhancedMeasurementSettings', 'patch' ),
			'create-key-event'            => array( 'properties.keyEvents.create', 'keyEvents', 'create' ),
			'update-key-event'            => array( 'properties.keyEvents.patch', 'keyEvents', 'patch' ),
			'delete-key-event'            => array( 'properties.keyEvents.delete', 'keyEvents', 'delete' ),
			'create-custom-dimension'     => array( 'properties.customDimensions.create', 'customDimensions', 'create' ),
			'archive-custom-dimension'    => array( 'properties.customDimensions.archive', 'customDimensions', 'archive' ),
			'create-custom-metric'        => array( 'properties.customMetrics.create', 'customMetrics', 'create' ),
			'archive-custom-metric'       => array( 'properties.customMetrics.archive', 'customMetrics', 'archive' ),
			'update-data-retention'       => array( 'properties.updateDataRetentionSettings', 'dataRetentionSettings', 'patch' ),
			'update-attribution'          => array( 'properties.updateAttributionSettings', 'attributionSettings', 'patch' ),
			'update-google-signals'       => array( 'properties.updateGoogleSignalsSettings', 'googleSignalsSettings', 'patch' ),
			'create-annotation'           => array( 'properties.reportingDataAnnotations.create', 'reportingDataAnnotations', 'create' ),
			'update-annotation'           => array( 'properties.reportingDataAnnotations.patch', 'reportingDataAnnotations', 'patch' ),
			'delete-annotation'           => array( 'properties.reportingDataAnnotations.delete', 'reportingDataAnnotations', 'delete' ),
			'create-audience'             => array( 'properties.audiences.create', 'audiences', 'create' ),
			'update-audience'             => array( 'properties.audiences.patch', 'audiences', 'patch' ),
			'archive-audience'            => array( 'properties.audiences.archive', 'audiences', 'archive' ),
			'create-mp-secret'            => array( 'properties.dataStreams.measurementProtocolSecrets.create', 'measurementProtocolSecrets', 'create' ),
			'delete-mp-secret'            => array( 'properties.dataStreams.measurementProtocolSecrets.delete', 'measurementProtocolSecrets', 'delete' ),
			'create-google-ads-link'      => array( 'properties.googleAdsLinks.create', 'googleAdsLinks', 'create' ),
			'delete-google-ads-link'      => array( 'properties.googleAdsLinks.delete', 'googleAdsLinks', 'delete' ),
			'add-user'                    => array( 'properties.accessBindings.create', 'accessBindings', 'create' ),
			'update-user'                 => array( 'properties.accessBindings.patch', 'accessBindings', 'patch' ),
			'remove-user'                 => array( 'properties.accessBindings.delete', 'accessBindings', 'delete' ),
		);
	}

	public static function register(): void {
		foreach ( self::definitions() as $route => $definition ) {
			Ability::register(
				'ga/' . $route,
				'ga',
				array(
					'label'        => 'GA4: ' . $route,
					'description'  => self::description( $route, $definition ),
					'mode'         => 'write',
					'input_schema' => self::input_schema( $definition ),
					'callback'     => static function ( array $input ) use ( $route ): array {
						return self::run( $route, $input );
					},
				)
			);
		}

		Ability::register(
			'ga/list-users',
			'ga',
			array(
				'label'        => 'GA4: listar usuários',
				'description'  => 'Lista accessBindings de parent=accounts/123 ou properties/123; property_id usa a propriedade padrão. Inclui todas as páginas, com limite explícito e token de continuação.',
				'input_schema' => array(
					'properties' => array_intersect_key( self::selectors(), array_flip( array( 'property_id', 'account_id', 'parent' ) ) ) + array(
						'page_size'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 500,
							'default' => 200,
						),
						'page_token' => array( 'type' => 'string' ),
						'max_pages'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
							'default' => 100,
						),
					),
				),
				'callback'     => array( self::class, 'list_users' ),
			)
		);
		Ability::register(
			'ga/get-settings',
			'ga',
			array(
				'label'        => 'GA4: configurações completas',
				'description'  => 'Retorna propriedade, conta, retenção, atribuição, Google Signals, streams e medição avançada, eventos-chave, dimensões, métricas, anotações, públicos, vínculos Ads, usuários e metadados de segredos MP. Segredos são mascarados. Erros parciais ficam explícitos em errors; paginação completa ou truncamento informado.',
				'input_schema' => array(
					'properties' => array(
						'property_id' => self::selectors()['property_id'],
						'max_pages'   => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 100,
							'default' => 100,
						),
					),
				),
				'callback'     => array( self::class, 'get_settings' ),
			)
		);
	}

	private static function selectors(): array {
		return array(
			'property_id' => array(
				'type'        => array( 'string', 'integer' ),
				'description' => 'ID GA4, properties/123, nome único ou *. Ausente: propriedade padrão, quando necessária.',
			),
			'account_id'  => array(
				'type'        => array( 'string', 'integer' ),
				'description' => 'ID numérico da conta Analytics, distinto da propriedade; aceita accounts/123.',
			),
			'parent'      => array(
				'type'        => 'string',
				'description' => 'Recurso pai oficial: accounts/123, properties/123 ou properties/123/dataStreams/456 conforme a operação.',
			),
			'name'        => array(
				'type'        => 'string',
				'description' => 'Nome completo do recurso existente. Ex.: properties/123/keyEvents/456. Deve concordar com property_id quando ambos são enviados.',
			),
			'stream_id'   => array(
				'type'        => array( 'string', 'integer' ),
				'description' => 'ID do stream ou properties/123/dataStreams/456; necessário para medição avançada e segredos MP quando name/parent não é informado.',
			),
			'resource_id' => array(
				'type'        => array( 'string', 'integer' ),
				'description' => 'ID do subrecurso existente, combinado com property_id (e stream_id para um segredo MP). Para vínculos Ads, é o ID do vínculo e não customerId.',
			),
		);
	}

	private static function input_schema( array $definition ): array {
		$target    = $definition[1];
		$operation = $definition[2];
		if ( 'provision' === $operation ) {
			$keys = array();
		} elseif ( 'property' === $target && 'create' === $operation ) {
			$keys = array( 'account_id', 'parent' );
		} elseif ( 'account' === $target ) {
			$keys = array( 'account_id', 'name', 'resource_id' );
		} else {
			$keys = 'create' === $operation ? array( 'property_id', 'parent' ) : array( 'property_id', 'name', 'resource_id' );
			if ( in_array( $target, array( 'dataStreams', 'measurementProtocolSecrets', 'enhancedMeasurementSettings' ), true ) ) {
				$keys[] = 'stream_id';
			}
			if ( 'accessBindings' === $target ) {
				$keys[] = 'account_id';
				$keys[] = 'parent';
			}
		}
		$properties = array_intersect_key( self::selectors(), array_flip( $keys ) );
		$required   = array();
		if ( in_array( $definition[2], array( 'create', 'patch', 'provision' ), true ) ) {
			$properties['body'] = array(
				'type'        => 'object',
				'description' => 'Corpo JSON oficial de analyticsadmin.' . $definition[0] . '. ' . self::body_hint( $definition[1] ),
			);
			$required[]         = 'body';
		}
		if ( 'patch' === $definition[2] && 'accessBindings' !== $definition[1] ) {
			$properties['update_mask'] = array(
				'type'        => 'string',
				'description' => 'FieldMask explícita, separada por vírgulas; camelCase ou snake_case. Omitida: calculada a partir dos campos de body, sem name. Inclua um campo ausente na máscara para limpar seu valor.',
			);
		}
		$properties['dry_run'] = array(
			'type'        => 'boolean',
			'default'     => false,
			'description' => 'A Admin API não oferece validateOnly nestes métodos. true é recusado antes de qualquer chamada de escrita.',
		);
		return array(
			'properties' => $properties,
			'required'   => $required,
		);
	}

	private static function body_hint( string $target ): string {
		$hints = array(
			'property'                    => 'Ex.: {"parent":"accounts/123","displayName":"Site","timeZone":"America/Sao_Paulo","currencyCode":"BRL"}.',
			'account'                     => 'Provisionamento: {"account":{"displayName":"Empresa","regionCode":"BR"},"redirectUri":"https://seu-site/retorno"}. redirectUri precisa estar registrado no projeto OAuth.',
			'dataStreams'                 => 'Ex.: {"displayName":"Site","webStreamData":{"defaultUri":"https://seu-site"}}. A criação fixa type=WEB_DATA_STREAM.',
			'enhancedMeasurementSettings' => 'Ex.: {"streamEnabled":true,"scrollsEnabled":true,"outboundClicksEnabled":true}.',
			'keyEvents'                   => 'Ex.: {"eventName":"generate_lead","countingMethod":"ONCE_PER_EVENT"}; atualizações aceitam countingMethod e defaultValue.',
			'customDimensions'            => 'Ex.: {"parameterName":"lead_type","displayName":"Tipo de lead","scope":"EVENT"}.',
			'customMetrics'               => 'Ex.: {"parameterName":"lead_score","displayName":"Pontuação","scope":"EVENT","measurementUnit":"STANDARD"}.',
			'dataRetentionSettings'       => 'Ex.: {"eventDataRetention":"FOURTEEN_MONTHS","resetUserDataOnNewActivity":true}.',
			'attributionSettings'         => 'Ex.: {"reportingAttributionModel":"PAID_AND_ORGANIC_CHANNELS_DATA_DRIVEN"}.',
			'googleSignalsSettings'       => 'Ex.: {"state":"GOOGLE_SIGNALS_ENABLED"}; o consentimento exigido pela Google continua aplicável.',
			'reportingDataAnnotations'    => 'Ex.: {"title":"Lançamento","color":"BLUE","annotationDate":{"year":2026,"month":9,"day":8}}; admite annotationDateRange em vez de annotationDate.',
			'audiences'                   => 'Criação: displayName, description, membershipDurationDays e filterClauses oficiais. Atualização: campos permitidos pela API, como displayName/description/eventTrigger.',
			'measurementProtocolSecrets'  => 'Ex.: {"displayName":"Servidor"}. secretValue só sai no retorno da criação; não é persistido pelo plugin.',
			'googleAdsLinks'              => 'Ex.: {"customerId":"1234567890","adsPersonalizationEnabled":true}. Requer os papéis correspondentes também no Google Ads.',
			'accessBindings'              => 'Ex.: {"user":"pessoa@empresa.com","roles":["predefinedRoles/editor"]}. roles vazia remove o vínculo na atualização. Requer analytics.manage.users e papel de administrador.',
		);
		return $hints[ $target ] ?? '';
	}

	private static function description( string $route, array $definition ): string {
		if ( 'provision-account' === $route ) {
			return 'Gera um ticket de criação de conta GA4 e a URL oficial dos termos. A conta só será criada quando uma pessoa aceitar os termos nessa URL.';
		}
		return 'Executa analyticsadmin.' . $definition[0] . ' na Admin API. Usa body com campos oficiais e name ou IDs do alvo; aplica imediatamente, com auditoria antes/depois quando recuperável. ' . self::body_hint( $definition[1] );
	}

	/** Executa uma das operações nomeadas; também usado pelos testes de contrato. */
	public static function run( string $route, array $input ): array {
		$definitions = self::definitions();
		if ( ! isset( $definitions[ $route ] ) ) {
			return self::fail( 'f3_google_ga_action', 'Operação de administração GA4 desconhecida.' );
		}
		if ( ! empty( $input['dry_run'] ) ) {
			return self::fail( 'f3_google_dry_run_unsupported', 'Este método da Admin API não oferece validateOnly. Nenhuma alteração foi enviada.' );
		}
		$definition                          = $definitions[ $route ];
		list( $method, $target, $operation ) = $definition;
		$needs_body                          = in_array( $operation, array( 'create', 'patch', 'provision' ), true );
		if ( $needs_body && ( ! isset( $input['body'] ) || ! is_array( $input['body'] ) || ( array() !== $input['body'] && array_keys( $input['body'] ) === range( 0, count( $input['body'] ) - 1 ) ) ) ) {
			return self::fail( 'f3_google_ga_body', 'body precisa ser um objeto JSON com os campos oficiais da Admin API.' );
		}
		$body = $needs_body ? DataApi::normalize_keys( $input['body'] ) : null;
		if ( isset( $body['name'] ) ) {
			if ( isset( $input['name'] ) && (string) $input['name'] !== (string) $body['name'] ) {
				return self::fail( 'f3_google_ga_target_mismatch', 'name e body.name identificam recursos diferentes.' );
			}
			$input['name'] = $body['name'];
			unset( $body['name'] );
		}
		if ( 'create-web-stream' === $route ) {
			if ( isset( $body['type'] ) && 'WEB_DATA_STREAM' !== $body['type'] ) {
				return self::fail( 'f3_google_ga_stream_type', 'create-web-stream aceita type=WEB_DATA_STREAM. Para streams de app use google/execute-action.' );
			}
			$body['type'] = 'WEB_DATA_STREAM';
		}
		if ( 'create-property' === $route ) {
			$parent = self::text( $input['parent'] ?? $body['parent'] ?? '' );
			if ( '' === $parent && isset( $input['account_id'] ) ) {
				$parent = self::account_name( $input['account_id'] );
			}
			if ( is_wp_error( $parent ) ) {
				return Response::fail( $parent );
			}
			if ( '' !== $parent ) {
				if ( isset( $body['parent'] ) && $body['parent'] !== $parent ) {
					return self::fail( 'f3_google_ga_target_mismatch', 'parent e body.parent identificam recursos diferentes.' );
				}
				$body['parent'] = $parent;
			}
		}
		$path = self::path( $definition, $input );
		if ( is_wp_error( $path ) ) {
			return Response::fail( $path );
		}
		if ( 'accessBindings' === $target && 0 === strpos( (string) reset( $path ), 'accounts/' ) ) {
			$method = str_replace( 'properties.accessBindings', 'accounts.accessBindings', $method );
		}
		$query = array();
		if ( 'patch' === $operation && 'accessBindings' !== $target ) {
			$mask                = self::text( $input['update_mask'] ?? '' );
			$query['updateMask'] = '' === $mask ? self::update_mask( $body ) : self::normalize_mask( $mask );
			if ( '' === $query['updateMask'] ) {
				return self::fail( 'f3_google_ga_update_mask', 'Informe campos em body ou update_mask explícita; uma atualização vazia não foi enviada.' );
			}
		}
		if ( 'archive' === $operation ) {
			$body = array();
		}
		if ( in_array( $operation, array( 'create', 'provision' ), true ) ) {
			Audit::before(
				array(
					'exists'   => false,
					'resource' => $path['parent'] ?? null,
				)
			);
		} else {
			Audit::before( self::snapshot( $target, $path['name'] ?? '', $method ) );
		}
		$raw = ExecuteAction::call( self::API, 'analyticsadmin.' . $method, $path, $query, $body, array( 'mode' => 'write' ) );
		if ( is_wp_error( $raw ) ) {
			Audit::after(
				array(
					'available' => false,
					'reason'    => 'A operação falhou; o estado posterior não foi confirmado.',
				)
			);
			return Response::fail( $raw );
		}
		if ( 'provision' === $operation ) {
			Audit::after(
				array(
					'account_created'           => false,
					'ticket_created'            => isset( $raw['accountTicketId'] ),
					'requires_terms_acceptance' => true,
				)
			);
			return Response::ok(
				array(
					'data'                      => $raw,
					'account_created'           => false,
					'requires_terms_acceptance' => true,
					'terms_url'                 => isset( $raw['accountTicketId'] ) ? 'https://analytics.google.com/analytics/web/?provisioningSignup=false#/termsofservice/' . rawurlencode( (string) $raw['accountTicketId'] ) : null,
				),
				'Ticket solicitado. A criação da conta depende da aceitação dos termos na URL devolvida.'
			);
		}
		if ( ! empty( $raw ) ) {
			Audit::after( $raw );
		} elseif ( in_array( $operation, array( 'delete', 'archive' ), true ) ) {
			// DELETE e :archive retornam Empty; isto registra a confirmação da API,
			// sem alegar que um recurso soft-deleted deixou de existir.
			Audit::after(
				array(
					'name'             => $path['name'] ?? '',
					'operation'        => $operation,
					'confirmed_by_api' => true,
					'state_available'  => false,
				)
			);
		} else {
			Audit::after( self::snapshot( $target, $path['name'] ?? '', $method ) );
		}
		$data = array(
			'data'      => $raw,
			'operation' => $operation,
			'resource'  => $raw['name'] ?? $path['name'] ?? $path['parent'] ?? null,
		);
		if ( isset( $raw['webStreamData']['measurementId'] ) ) {
			$data['measurement_id'] = $raw['webStreamData']['measurementId'];
		}
		if ( 'create-mp-secret' === $route ) {
			$data['secret_persisted'] = false;
		}
		return Response::ok( $data, 'Operação confirmada pela Admin API.' );
	}

	/** @return array|\WP_Error */
	private static function path( array $definition, array $input ) {
		list( $method, $target, $operation ) = $definition;
		unset( $method );
		if ( 'provision' === $operation || ( 'property' === $target && 'create' === $operation ) ) {
			return array();
		}
		$creating = 'create' === $operation;
		$selector = self::text( $input[ $creating ? 'parent' : 'name' ] ?? '' );
		if ( ! $creating && 'dataStreams' === $target && '' === $selector && 0 === strpos( self::text( $input['stream_id'] ?? '' ), 'properties/' ) ) {
			$selector = self::text( $input['stream_id'] );
		}
		if ( '' !== $selector ) {
			$check = self::consistent_property( $selector, $input );
			return is_wp_error( $check ) ? $check : array( $creating ? 'parent' : 'name' => $selector );
		}
		if ( 'account' === $target ) {
			$name = self::account_name( $input['account_id'] ?? $input['resource_id'] ?? '' );
			return is_wp_error( $name ) ? $name : array( 'name' => $name );
		}
		if ( 'accessBindings' === $target && isset( $input['account_id'] ) ) {
			$parent = self::account_name( $input['account_id'] );
		} elseif ( 'accessBindings' === $target && ! empty( $input['parent'] ) ) {
			$parent = self::text( $input['parent'] );
		} else {
			$parent = PropertyId::normalize( $input['property_id'] ?? null );
		}
		if ( is_wp_error( $parent ) ) {
			return $parent;
		}
		if ( 'property' === $target ) {
			return array( 'name' => $parent );
		}
		if ( in_array( $target, array( 'dataRetentionSettings', 'attributionSettings', 'googleSignalsSettings' ), true ) ) {
			return array( 'name' => $parent . '/' . $target );
		}
		if ( in_array( $target, array( 'measurementProtocolSecrets', 'enhancedMeasurementSettings' ), true ) ) {
			$stream = self::text( $input['stream_id'] ?? '' );
			if ( 0 === strpos( $stream, 'properties/' ) ) {
				if ( 0 !== strpos( $stream, $parent . '/dataStreams/' ) || ! preg_match( '~^properties/[0-9]+/dataStreams/[0-9]+$~D', $stream ) ) {
					return new \WP_Error( 'f3_google_ga_target_mismatch', 'stream_id não pertence à propriedade informada ou tem formato inválido.' );
				}
				$parent = $stream;
			} elseif ( preg_match( '/^[0-9]+$/D', $stream ) && '' !== ltrim( $stream, '0' ) ) {
				$parent .= '/dataStreams/' . $stream;
			} else {
				return new \WP_Error( 'f3_google_ga_stream_required', 'Informe stream_id ou o nome completo do recurso em name/parent.' );
			}
		}
		if ( $creating ) {
			return array( 'parent' => $parent );
		}
		if ( 'enhancedMeasurementSettings' === $target ) {
			return array( 'name' => $parent . '/enhancedMeasurementSettings' );
		}
		$id = self::text( $input['resource_id'] ?? ( 'dataStreams' === $target ? ( $input['stream_id'] ?? '' ) : '' ) );
		if ( '' === $id || ! preg_match( '/^[A-Za-z0-9_-]+$/D', $id ) ) {
			return new \WP_Error( 'f3_google_ga_resource_required', 'Informe resource_id do subrecurso ou name no formato oficial completo.' );
		}
		return array( 'name' => $parent . '/' . $target . '/' . $id );
	}

	/** @return true|\WP_Error */
	private static function consistent_property( string $name, array $input ) {
		if ( isset( $input['property_id'] ) ) {
			$property = PropertyId::normalize( $input['property_id'] );
			if ( is_wp_error( $property ) ) {
				return $property;
			}
			if ( $name !== $property && 0 !== strpos( $name, $property . '/' ) ) {
				return new \WP_Error( 'f3_google_ga_target_mismatch', 'O name/parent fornecido não pertence a property_id.' );
			}
		}
		return true;
	}

	/** @return string|\WP_Error */
	private static function account_name( $value ) {
		$value = self::text( $value );
		if ( preg_match( '~^(?:accounts/)?([0-9]+)$~D', $value, $match ) && '' !== ltrim( $match[1], '0' ) ) {
			return 'accounts/' . $match[1];
		}
		return new \WP_Error( 'f3_google_ga_account_required', 'Informe account_id numérico ou accounts/123. Uma conta Analytics é diferente de uma propriedade.' );
	}

	private static function text( $value ): string {
		return is_scalar( $value ) ? trim( (string) $value ) : '';
	}

	/** ProtoJSON FieldMask usa lowerCamelCase; mantém máscara explícita de limpeza. */
	private static function normalize_mask( string $mask ): string {
		return implode(
			',',
			array_map(
				static function ( string $path ): string {
					return (string) preg_replace_callback(
						'/_([a-z])/',
						static function ( array $matched_part ): string {
							return strtoupper( $matched_part[1] );
						},
						trim( $path )
					);
				},
				explode( ',', $mask )
			)
		);
	}

	private static function update_mask( array $body, string $prefix = '' ): string {
		$paths = array();
		foreach ( $body as $key => $value ) {
			if ( 'name' === $key || ! is_string( $key ) ) {
				continue;
			}
			$path = $prefix . $key;
			// Objetos aninhados são parciais; listas/repeated fields são substituídos.
			if ( is_array( $value ) && array() !== $value && array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
				$nested  = self::update_mask( $value, $path . '.' );
				$paths[] = '' === $nested ? $path : $nested;
			} else {
				$paths[] = $path;
			}
		}
		return implode( ',', $paths );
	}

	/** Snapshot real por GET irmão, ou list quando Google Ads links não oferece get. */
	private static function snapshot( string $target, string $name, string $method ): array {
		if ( '' === $name ) {
			return array(
				'available' => false,
				'reason'    => 'A API não forneceu nome de recurso para consultar o estado.',
			);
		}
		$singles = array(
			'dataRetentionSettings'       => 'properties.getDataRetentionSettings',
			'attributionSettings'         => 'properties.getAttributionSettings',
			'googleSignalsSettings'       => 'properties.getGoogleSignalsSettings',
			'enhancedMeasurementSettings' => 'properties.dataStreams.getEnhancedMeasurementSettings',
		);
		if ( 'googleAdsLinks' === $target ) {
			$parent = substr( $name, 0, (int) strpos( $name, '/googleAdsLinks/' ) );
			$result = self::pages( 'properties.googleAdsLinks.list', $parent, 'googleAdsLinks', array() );
			if ( ! is_wp_error( $result ) ) {
				foreach ( $result['items'] as $item ) {
					if ( ( $item['name'] ?? '' ) === $name ) {
						return $item;
					}
				}
				return array(
					'available' => false,
					'reason'    => 'O vínculo não foi encontrado na listagem atual.',
					'truncated' => $result['truncated'],
				);
			}
		} else {
			$get    = $singles[ $target ] ?? preg_replace( '/\.(?:patch|delete|archive|create)$/', '.get', $method );
			$result = ExecuteAction::call( self::API, 'analyticsadmin.' . $get, array( 'name' => $name ), array(), null, array( 'mode' => 'read' ) );
		}
		return is_wp_error( $result ) ? array(
			'available'  => false,
			'reason'     => $result->get_error_message(),
			'error_code' => $result->get_error_code(),
		) : $result;
	}

	/** @return array|\WP_Error */
	private static function pages( string $method, string $parent_name, string $field, array $input ) {
		$items = array();
		$token = self::text( $input['page_token'] ?? '' );
		$seen  = array();
		$max   = max( 1, min( 100, (int) ( $input['max_pages'] ?? 100 ) ) );
		$size  = max( 1, min( 'accessBindings' === $field ? 500 : ( 'measurementProtocolSecrets' === $field ? 10 : 200 ), (int) ( $input['page_size'] ?? 200 ) ) );
		for ( $page = 0; $page < $max; ++$page ) {
			$query = array( 'pageSize' => $size );
			if ( '' !== $token ) {
				$query['pageToken'] = $token;
			}
			$result = ExecuteAction::call( self::API, 'analyticsadmin.' . $method, array( 'parent' => $parent_name ), $query, null, array( 'mode' => 'read' ) );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$items = array_merge( $items, is_array( $result[ $field ] ?? null ) ? $result[ $field ] : array() );
			$token = self::text( $result['nextPageToken'] ?? '' );
			if ( '' === $token ) {
				break;
			}
			if ( isset( $seen[ $token ] ) ) {
				return new \WP_Error( 'f3_google_ga_pagination', 'A Admin API repetiu um nextPageToken; paginação interrompida para evitar repetição.' );
			}
			$seen[ $token ] = true;
		}
		return array(
			'items'           => $items,
			'count'           => count( $items ),
			'truncated'       => '' !== $token,
			'next_page_token' => $token,
		);
	}

	public static function list_users( array $input ): array {
		$parent = self::text( $input['parent'] ?? '' );
		if ( '' === $parent ) {
			$parent = isset( $input['account_id'] ) ? self::account_name( $input['account_id'] ) : PropertyId::normalize( $input['property_id'] ?? null );
		}
		if ( is_wp_error( $parent ) ) {
			return Response::fail( $parent );
		}
		$check = self::consistent_property( $parent, $input );
		if ( is_wp_error( $check ) ) {
			return Response::fail( $check );
		}
		$method = ( 0 === strpos( $parent, 'accounts/' ) ? 'accounts' : 'properties' ) . '.accessBindings.list';
		$result = self::pages( $method, $parent, 'accessBindings', $input );
		return is_wp_error( $result ) ? Response::fail( $result ) : Response::ok(
			array(
				'parent' => $parent,
				'users'  => $result['items'],
			) + $result
		);
	}

	/** Agrega configurações sem transformar erro parcial em sucesso completo. */
	public static function get_settings( array $input ): array {
		$property = PropertyId::normalize( $input['property_id'] ?? null );
		if ( is_wp_error( $property ) ) {
			return Response::fail( $property );
		}
		$settings  = array();
		$errors    = array();
		$truncated = array();
		$reads     = array(
			'property'       => array( 'properties.get', $property ),
			'data_retention' => array( 'properties.getDataRetentionSettings', $property . '/dataRetentionSettings' ),
			'attribution'    => array( 'properties.getAttributionSettings', $property . '/attributionSettings' ),
			'google_signals' => array( 'properties.getGoogleSignalsSettings', $property . '/googleSignalsSettings' ),
		);
		foreach ( $reads as $key => $read ) {
			$value = ExecuteAction::call( self::API, 'analyticsadmin.' . $read[0], array( 'name' => $read[1] ), array(), null, array( 'mode' => 'read' ) );
			if ( 'property' === $key && is_wp_error( $value ) ) {
				return Response::fail( $value );
			}
			self::collect_setting( $key, $value, $settings, $errors );
		}
		$account = $settings['property']['account'] ?? $settings['property']['parent'] ?? '';
		if ( is_string( $account ) && preg_match( '~^accounts/[0-9]+$~D', $account ) ) {
			foreach ( array(
				'account'      => array( 'accounts.get', $account ),
				'data_sharing' => array( 'accounts.getDataSharingSettings', $account . '/dataSharingSettings' ),
			) as $key => $read ) {
				$value = ExecuteAction::call( self::API, 'analyticsadmin.' . $read[0], array( 'name' => $read[1] ), array(), null, array( 'mode' => 'read' ) );
				self::collect_setting( $key, $value, $settings, $errors );
			}
		}
		$lists = array(
			'data_streams'      => 'dataStreams',
			'key_events'        => 'keyEvents',
			'custom_dimensions' => 'customDimensions',
			'custom_metrics'    => 'customMetrics',
			'annotations'       => 'reportingDataAnnotations',
			'audiences'         => 'audiences',
			'google_ads_links'  => 'googleAdsLinks',
			'users'             => 'accessBindings',
		);
		foreach ( $lists as $key => $field ) {
			$value = self::pages( 'properties.' . $field . '.list', $property, $field, $input );
			self::collect_list( $key, $value, $settings, $errors, $truncated );
		}
		if ( is_string( $account ) && preg_match( '~^accounts/[0-9]+$~D', $account ) ) {
			self::collect_list( 'account_users', self::pages( 'accounts.accessBindings.list', $account, 'accessBindings', $input ), $settings, $errors, $truncated );
		}
		$settings['stream_settings'] = array();
		foreach ( $settings['data_streams'] ?? array() as $stream ) {
			$name = $stream['name'] ?? '';
			if ( ! is_string( $name ) || ! preg_match( '~^properties/[0-9]+/dataStreams/[0-9]+$~D', $name ) ) {
				continue;
			}
			$stream_settings = array();
			if ( 'WEB_DATA_STREAM' === ( $stream['type'] ?? '' ) ) {
				$value = ExecuteAction::call( self::API, 'analyticsadmin.properties.dataStreams.getEnhancedMeasurementSettings', array( 'name' => $name . '/enhancedMeasurementSettings' ), array(), null, array( 'mode' => 'read' ) );
				self::collect_setting( $name . '/enhanced_measurement', $value, $stream_settings, $errors );
			}
			$value = self::pages( 'properties.dataStreams.measurementProtocolSecrets.list', $name, 'measurementProtocolSecrets', $input );
			self::collect_list( $name . '/mp_secrets', $value, $stream_settings, $errors, $truncated );
			$settings['stream_settings'][ $name ] = self::scrub_settings( $stream_settings );
		}
		return Response::ok(
			array(
				'property_id'        => $property,
				'settings'           => self::scrub_settings( $settings ),
				'complete'           => empty( $errors ) && empty( $truncated ),
				'errors'             => $errors,
				'truncated_sections' => $truncated,
			),
			empty( $errors ) && empty( $truncated ) ? 'Configurações consultadas.' : 'Consulta parcial: examine errors e truncated_sections antes de concluir a análise.'
		);
	}

	/** Mascarar valores sensíveis sem truncar a estrutura de configurações retornada. */
	private static function scrub_settings( $value ) {
		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$normalized    = strtolower( (string) preg_replace( '/[^a-z0-9]/i', '', (string) $key ) );
				$value[ $key ] = in_array( $normalized, array( 'secretvalue', 'apisecret', 'privatekey', 'accesstoken', 'refreshtoken' ), true ) ? '[REDACTED]' : self::scrub_settings( $item );
			}
			return $value;
		}
		return is_string( $value ) ? Ability::scrub( $value ) : $value;
	}

	private static function collect_setting( string $key, $value, array &$settings, array &$errors ): void {
		if ( is_wp_error( $value ) ) {
			$errors[ $key ] = Response::fail( $value );
		} else {
			$settings[ $key ] = $value;
		}
	}

	private static function collect_list( string $key, $value, array &$settings, array &$errors, array &$truncated ): void {
		if ( is_wp_error( $value ) ) {
			$errors[ $key ] = Response::fail( $value );
		} else {
			$settings[ $key ] = $value['items'];
			if ( $value['truncated'] ) {
				$truncated[ $key ] = array(
					'next_page_token' => $value['next_page_token'],
					'count'           => $value['count'],
				);
			}
		}
	}

	private static function fail( string $code, string $message ): array {
		return Response::fail( new \WP_Error( $code, $message ) );
	}
}
