<?php
/**
 * Envio/validação de eventos de web streams pela Measurement Protocol GA4.
 *
 * @package Fator3\McpGoogle\Analytics
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Audit;
use Fator3\McpGoogle\Http\GoogleClient;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class MeasurementProtocol {

	public static function register(): void {
		Ability::register(
			'ga/send-event',
			'ga',
			array(
				'label'        => 'GA4: enviar ou validar eventos',
				'description'  => 'Envia até 25 eventos de um web stream ao Measurement Protocol. debug=true usa somente /debug/mp/collect: valida o payload e não coleta eventos. A validação não confirma api_secret. Em produção, HTTP 2xx confirma recebimento HTTP, sem garantir processamento/inclusão nos relatórios. O segredo não é persistido.',
				'mode'         => 'write',
				'input_schema' => array(
					'properties' => array(
						'measurement_id'      => array(
							'type'        => 'string',
							'pattern'     => '^G-[A-Z0-9]+$',
							'description' => 'measurementId do web stream, ex.: G-ABCDEFGHIJ.',
						),
						'api_secret'          => array(
							'type'        => 'string',
							'minLength'   => 1,
							'description' => 'Segredo MP desse stream, obtido pela interface GA4 ou ga/create-mp-secret. Usado somente nesta chamada.',
						),
						'client_id'           => array(
							'type'        => 'string',
							'minLength'   => 1,
							'description' => 'Identificador de cliente GA4 correspondente à interação, ex.: 123456789.1234567890.',
						),
						'events'              => array(
							'type'     => 'array',
							'minItems' => 1,
							'maxItems' => 25,
							'items'    => array(
								'type'                 => 'object',
								'properties'           => array(
									'name'   => array(
										'type'        => 'string',
										'minLength'   => 1,
										'description' => 'Nome oficial ou customizado do evento. O endpoint debug devolve os erros de validação.',
									),
									'params' => array(
										'type'        => 'object',
										'description' => 'Parâmetros originais do evento: session_id, engagement_time_msec, currency, value, items etc. As chaves são preservadas.',
									),
								),
								'required'             => array( 'name' ),
								'additionalProperties' => false,
							),
						),
						'debug'               => array(
							'type'    => 'boolean',
							'default' => false,
						),
						'dry_run'             => array(
							'type'        => 'boolean',
							'default'     => false,
							'description' => 'Alias de debug=true: usa o endpoint real de validação, sem coletar eventos.',
						),
						'user_id'             => array( 'type' => 'string' ),
						'timestamp_micros'    => array(
							'type'        => array( 'string', 'integer' ),
							'description' => 'Timestamp Unix em microssegundos. Os limites de retroatividade da API continuam aplicáveis.',
						),
						'user_properties'     => array(
							'type'        => 'object',
							'description' => 'Mapa de propriedades; cada valor usa {value, timestamp_micros?}.',
						),
						'consent'             => array(
							'type'        => 'object',
							'description' => 'Estado explícito de consentimento: ad_user_data e ad_personalization, GRANTED ou DENIED. O plugin não presume consentimento.',
						),
						'user_location'       => array( 'type' => 'object' ),
						'ip_override'         => array( 'type' => 'string' ),
						'device'              => array( 'type' => 'object' ),
						'validation_behavior' => array(
							'type'        => 'string',
							'enum'        => array( 'RELAXED', 'ENFORCE_RECOMMENDATIONS' ),
							'description' => 'Debug usa ENFORCE_RECOMMENDATIONS por padrão; produção omite a opção por padrão, conforme orientação Google.',
						),
					),
					'required'   => array( 'measurement_id', 'api_secret', 'client_id', 'events' ),
				),
				'callback'     => array( self::class, 'run' ),
			)
		);
	}

	public static function run( array $input ): array {
		$measurement = is_string( $input['measurement_id'] ?? null ) ? trim( $input['measurement_id'] ) : '';
		$secret      = is_string( $input['api_secret'] ?? null ) ? $input['api_secret'] : '';
		$client      = is_string( $input['client_id'] ?? null ) ? trim( $input['client_id'] ) : '';
		$events      = $input['events'] ?? null;
		$debug       = ! empty( $input['debug'] ) || ! empty( $input['dry_run'] );
		if ( ! preg_match( '/^G-[A-Z0-9]+$/D', $measurement ) || '' === trim( $secret ) || '' === $client ) {
			return self::fail( 'f3_google_mp_parameters', 'Informe measurement_id G-..., api_secret do stream e client_id não vazio.' );
		}
		if ( ! is_array( $events ) || count( $events ) < 1 || count( $events ) > 25 || array_keys( $events ) !== range( 0, count( $events ) - 1 ) ) {
			return self::fail( 'f3_google_mp_events', 'events precisa ser uma lista com 1 a 25 objetos de evento.' );
		}
		foreach ( $events as $index => &$event ) {
			if ( ! is_array( $event ) || ! is_string( $event['name'] ?? null ) || '' === trim( $event['name'] ) ) {
				return self::fail( 'f3_google_mp_event', 'Cada evento precisa de name não vazio; índice inválido: ' . $index . '.' );
			}
			if ( isset( $event['params'] ) && ! is_array( $event['params'] ) ) {
				return self::fail( 'f3_google_mp_event', 'params precisa ser um objeto JSON; índice inválido: ' . $index . '.' );
			}
			if ( isset( $event['params'] ) && array() === $event['params'] ) {
				$event['params'] = (object) array();
			}
		}
		unset( $event );
		$body = array(
			'client_id' => $client,
			'events'    => $events,
		);
		foreach ( array( 'user_id', 'timestamp_micros', 'user_properties', 'consent', 'user_location', 'ip_override', 'device', 'validation_behavior' ) as $key ) {
			if ( array_key_exists( $key, $input ) ) {
				$body[ $key ] = $input[ $key ];
			}
		}
		if ( $debug && ! isset( $body['validation_behavior'] ) ) {
			$body['validation_behavior'] = 'ENFORCE_RECOMMENDATIONS';
		}
		if ( isset( $body['timestamp_micros'] ) && ( ! is_scalar( $body['timestamp_micros'] ) || ! preg_match( '/^[0-9]+$/D', (string) $body['timestamp_micros'] ) ) ) {
			return self::fail( 'f3_google_mp_timestamp', 'timestamp_micros precisa ser um inteiro Unix positivo em microssegundos.' );
		}
		$encoded = wp_json_encode( $body );
		if ( false === $encoded || strlen( (string) $encoded ) >= 130 * 1024 ) {
			return self::fail( 'f3_google_mp_payload_size', 'O corpo MP precisa ser JSON válido e menor que 130 kB. Divida os eventos em chamadas menores.' );
		}
		Audit::before(
			array(
				'available' => false,
				'reason'    => 'O Measurement Protocol não oferece leitura do estado anterior dos eventos.',
				'debug'     => $debug,
			)
		);
		try {
			$raw = GoogleClient::request(
				'POST',
				'https://www.google-analytics.com/' . ( $debug ? 'debug/' : '' ) . 'mp/collect',
				$body,
				array(
					'auth'    => false,
					'mode'    => 'write',
					'retries' => 0,
					'query'   => array(
						'measurement_id' => $measurement,
						'api_secret'     => $secret,
					),
				)
			);
		} catch ( \Throwable $error ) {
			Audit::after(
				array(
					'available' => false,
					'reason'    => 'O transporte foi interrompido; o recebimento não foi confirmado.',
					'debug'     => $debug,
				)
			);
			return self::redact_secret( self::fail( 'f3_google_mp_transport', $error->getMessage() ), $secret );
		}
		if ( is_wp_error( $raw ) ) {
			Audit::after(
				array(
					'available' => false,
					'reason'    => 'Falha HTTP; o recebimento não foi confirmado.',
					'debug'     => $debug,
				)
			);
			// api_secret desta chamada pode não estar entre os segredos configurados.
			return self::redact_secret( Response::fail( $raw ), $secret );
		}
		if ( $debug ) {
			if ( ! isset( $raw['validationMessages'] ) || ! is_array( $raw['validationMessages'] ) ) {
				Audit::after(
					array(
						'debug'     => true,
						'validated' => false,
						'reason'    => 'Resposta de validação inesperada.',
					)
				);
				return self::fail( 'f3_google_mp_validation_response', 'O endpoint debug não devolveu validationMessages. A validação não foi confirmada.' );
			}
			$messages = self::redact_secret( $raw['validationMessages'], $secret );
			$valid    = empty( $messages );
			Audit::after(
				array(
					'debug'               => true,
					'validated'           => $valid,
					'events_collected'    => false,
					'validation_messages' => $messages,
				)
			);
			$result = array(
				'debug'                => true,
				'dry_run'              => true,
				'validated'            => $valid,
				'events_collected'     => false,
				'credential_validated' => false,
				'validation_messages'  => $messages,
			);
			return $valid ? Response::ok( $result, 'Payload validado; nenhum evento coletado. O endpoint debug não valida api_secret.' ) : Response::fail( new \WP_Error( 'f3_google_mp_validation', 'O Google encontrou erros de validação. Corrija validation_messages antes do envio.' ), $result );
		}
		Audit::after(
			array(
				'debug'                 => false,
				'accepted_by_transport' => true,
				'processed'             => null,
				'event_count'           => count( $events ),
			)
		);
		return Response::ok(
			array(
				'debug'                 => false,
				'dry_run'               => false,
				'measurement_id'        => $measurement,
				'event_count'           => count( $events ),
				'accepted_by_transport' => true,
				'processed'             => null,
				'secret_persisted'      => false,
			),
			'Recebimento HTTP confirmado. A API de coleta não confirma processamento dos eventos; verifique os relatórios/DebugView conforme a configuração GA4.'
		);
	}

	private static function redact_secret( $value, string $secret ) {
		if ( is_string( $value ) ) {
			return str_replace( array( $secret, rawurlencode( $secret ) ), '[REDACTED]', $value );
		}
		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = self::redact_secret( $item, $secret );
			}
		}
		return $value;
	}

	private static function fail( string $code, string $message ): array {
		return Response::fail( new \WP_Error( $code, $message ) );
	}
}
