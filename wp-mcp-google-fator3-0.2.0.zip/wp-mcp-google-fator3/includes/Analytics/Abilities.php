<?php
/**
 * As 10 habilidades `ga/*` — paridade com o MCP oficial do Google Analytics
 * (`analytics_mcp`, em Python) mais `ga/check-compatibility`.
 *
 * Cada callback aqui faz três coisas na mesma ordem: (1) resolve e valida
 * `property_id` com `PropertyId::normalize()`, que já cai na propriedade
 * padrão quando o agente não manda nada; (2) monta o corpo da requisição em
 * camelCase a partir de uma entrada tolerante (snake_case OU camelCase nas
 * chaves de filtros/order_bys/date_ranges, dimensões/métricas como string OU
 * `{name}`); (3) formata a resposta — tabela posicional por padrão (poupa
 * tokens do agente) ou bruta quando `format: raw` é pedido.
 *
 * As descrições longas com exemplos de JSON (filtros, order_bys, funil) ficam
 * na `description` de cada propriedade do `input_schema` — é o que
 * `get-ability-info` devolve sob pedido — e não na descrição da habilidade,
 * que o `discover-abilities` lista todas de uma vez e por isso precisa ficar
 * curta.
 *
 * @package Fator3\McpGoogle\Analytics
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Abilities {

	/**
	 * Registra as 10 habilidades `ga/*`.
	 */
	public static function register(): void {
		self::register_get_account_summaries();
		self::register_get_property_details();
		self::register_list_google_ads_links();
		self::register_list_property_annotations();
		self::register_get_metadata();
		self::register_check_compatibility();
		self::register_run_report();
		self::register_run_realtime_report();
		self::register_run_funnel_report();
		self::register_run_conversions_report();
	}

	// =========================================================================
	// Catálogo (Admin API)
	// =========================================================================

	private static function register_get_account_summaries(): void {
		Ability::register(
			'ga/get-account-summaries',
			'ga',
			array(
				'label'        => __( 'GA4: contas e propriedades', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista todas as contas e propriedades do Google Analytics 4 acessíveis pela credencial configurada (Admin API, com paginação seguida até o fim). Sem parâmetros.', 'wp-mcp-google-fator3' ),
				'input_schema' => array( 'properties' => array() ),
				'callback'     => static function ( array $input ): array {
					unset( $input );

					$raw = AdminApi::account_summaries();
					if ( is_wp_error( $raw ) ) {
						return Response::fail( $raw );
					}

					return Response::ok( self::format_account_summaries( $raw ) );
				},
			)
		);
	}

	/**
	 * @param array $raw Lista de accountSummaries, já com todas as páginas.
	 */
	private static function format_account_summaries( array $raw ): array {
		$accounts         = array();
		$count_properties = 0;

		foreach ( $raw as $summary ) {
			if ( ! is_array( $summary ) ) {
				continue;
			}

			$properties = array();

			foreach ( self::as_list( $summary, 'propertySummaries' ) as $property ) {
				if ( ! is_array( $property ) ) {
					continue;
				}

				$properties[] = array(
					'property'      => (string) ( $property['property'] ?? '' ),
					'display_name'  => (string) ( $property['displayName'] ?? '' ),
					'property_type' => (string) ( $property['propertyType'] ?? '' ),
					'parent'        => (string) ( $property['parent'] ?? '' ),
				);
				++$count_properties;
			}

			$accounts[] = array(
				'account'      => (string) ( $summary['account'] ?? '' ),
				'display_name' => (string) ( $summary['displayName'] ?? '' ),
				'properties'   => $properties,
			);
		}

		return array(
			'accounts'         => $accounts,
			'count_accounts'   => count( $accounts ),
			'count_properties' => $count_properties,
		);
	}

	private static function register_get_property_details(): void {
		Ability::register(
			'ga/get-property-details',
			'ga',
			array(
				'label'        => __( 'GA4: detalhes da propriedade', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Devolve os detalhes de uma propriedade GA4: nome de exibição, fuso horário, moeda, categoria do setor e datas de criação/atualização. Params: property_id (opcional; usa a propriedade padrão configurada em Ferramentas > MCP Google quando ausente).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'property_id' => self::schema_property_id(),
					),
				),
				'callback'     => static function ( array $input ): array {
					$response = AdminApi::property( $input['property_id'] ?? null );
					if ( is_wp_error( $response ) ) {
						return Response::fail( $response );
					}

					return Response::ok( array( 'property' => self::scrub_deep( $response ) ) );
				},
			)
		);
	}

	private static function register_list_google_ads_links(): void {
		Ability::register(
			'ga/list-google-ads-links',
			'ga',
			array(
				'label'        => __( 'GA4: vínculos com o Google Ads', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista os vínculos entre uma propriedade GA4 e contas do Google Ads (Admin API, com paginação seguida até o fim). Params: property_id (opcional; usa a propriedade padrão).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'property_id' => self::schema_property_id(),
					),
				),
				'callback'     => static function ( array $input ): array {
					$raw = AdminApi::google_ads_links( $input['property_id'] ?? null );
					if ( is_wp_error( $raw ) ) {
						return Response::fail( $raw );
					}

					$links = array();
					foreach ( $raw as $item ) {
						if ( ! is_array( $item ) ) {
							continue;
						}

						$links[] = array(
							'name'                        => (string) ( $item['name'] ?? '' ),
							'customer_id'                 => (string) ( $item['customerId'] ?? '' ),
							'ads_personalization_enabled' => isset( $item['adsPersonalizationEnabled'] ) ? (bool) $item['adsPersonalizationEnabled'] : null,
							'can_manage_clients'          => isset( $item['canManageClients'] ) ? (bool) $item['canManageClients'] : null,
							'creator_email_address'       => (string) ( $item['creatorEmailAddress'] ?? '' ),
							'create_time'                 => (string) ( $item['createTime'] ?? '' ),
						);
					}

					return Response::ok(
						array(
							'links' => $links,
							'count' => count( $links ),
						)
					);
				},
			)
		);
	}

	private static function register_list_property_annotations(): void {
		Ability::register(
			'ga/list-property-annotations',
			'ga',
			array(
				'label'        => __( 'GA4: anotações da propriedade', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista as anotações de uma propriedade GA4 — notas sobre lançamentos, campanhas de marketing ou variações de tráfego, marcadas em datas ou períodos específicos (Admin API v1alpha). Params: property_id (opcional; usa a propriedade padrão).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'property_id' => self::schema_property_id(),
					),
				),
				'callback'     => static function ( array $input ): array {
					$raw = AdminApi::annotations( $input['property_id'] ?? null );
					if ( is_wp_error( $raw ) ) {
						return Response::fail( $raw );
					}

					return Response::ok(
						array(
							'annotations' => self::scrub_deep( $raw ),
							'count'       => count( $raw ),
						)
					);
				},
			)
		);
	}

	// =========================================================================
	// Catálogo de dimensões/métricas (Data API)
	// =========================================================================

	private static function register_get_metadata(): void {
		Ability::register(
			'ga/get-metadata',
			'ga',
			array(
				'label'        => __( 'GA4: dimensões e métricas disponíveis', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Lista as dimensões e métricas disponíveis para relatórios GA4: catálogo universal (sem property_id/padrão) ou catálogo de uma propriedade, com as customizadas. Use antes de run-report para achar nomes válidos. Params: property_id (opcional), custom_only (opcional, padrão true), query (opcional, filtra por nome/descrição).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'property_id' => self::schema_property_id(
							__( 'Propriedade cujo catálogo (dimensões/métricas customizadas incluídas) você quer ver. Ausente, e sem propriedade padrão configurada: devolve o catálogo universal (properties/0), que não tem customizações — nesse caso custom_only é ignorado e tratado como false.', 'wp-mcp-google-fator3' )
						),
						'custom_only' => array(
							'type'        => 'boolean',
							'default'     => true,
							'description' => __( 'Padrão true: devolve só as dimensões/métricas customizadas da propriedade (as que aparecem em get_custom_dimensions_and_metrics no MCP oficial do Google). Use false para ver também as dimensões/métricas padrão do GA4, disponíveis em toda propriedade.', 'wp-mcp-google-fator3' ),
						),
						'query'       => array(
							'type'        => 'string',
							'description' => __( 'Busca case-insensitive em api_name, ui_name e description. Ex.: "sessão" encontra dimensões/métricas com essa palavra na descrição em qualquer um dos três campos.', 'wp-mcp-google-fator3' ),
						),
					),
				),
				'callback'     => array( self::class, 'run_get_metadata' ),
			)
		);
	}

	/**
	 * @param array $input Entrada já normalizada por Ability::normalize_input.
	 */
	public static function run_get_metadata( array $input ): array {
		$raw_property = array_key_exists( 'property_id', $input ) ? $input['property_id'] : null;
		$has_input    = null !== $raw_property && is_scalar( $raw_property ) && '' !== trim( (string) $raw_property );
		$has_default  = '' !== trim( (string) Options::get( Options::GA_DEFAULT_PROPERTY, '' ) );
		$universal    = ! $has_input && ! $has_default;

		$response = $universal ? DataApi::metadata( null ) : DataApi::metadata( $raw_property );
		if ( is_wp_error( $response ) ) {
			return Response::fail( $response );
		}

		// Sem propriedade não há como haver customização: o parâmetro do
		// agente é ignorado neste caso específico, senão custom_only=true
		// (o padrão) devolveria uma lista sempre vazia sem explicar por quê.
		$custom_only = $universal ? false : ( ! array_key_exists( 'custom_only', $input ) || (bool) $input['custom_only'] );

		$query = isset( $input['query'] ) && is_scalar( $input['query'] ) ? trim( (string) $input['query'] ) : '';

		$dimensions = self::filter_metadata_fields(
			self::as_list( $response, 'dimensions' ),
			$custom_only,
			$query,
			false
		);
		$metrics    = self::filter_metadata_fields(
			self::as_list( $response, 'metrics' ),
			$custom_only,
			$query,
			true
		);

		return Response::ok(
			array(
				'dimensions' => $dimensions,
				'metrics'    => $metrics,
				'counts'     => array(
					'dimensions' => count( $dimensions ),
					'metrics'    => count( $metrics ),
				),
			)
		);
	}

	/**
	 * @param array  $fields      dimensions[] ou metrics[] da resposta de metadata.
	 * @param bool   $custom_only Só entradas com customDefinition=true.
	 * @param string $query       Busca (já aparada); vazio não filtra.
	 * @param bool   $is_metric   Inclui o campo `type`, exclusivo de métrica.
	 */
	private static function filter_metadata_fields( array $fields, bool $custom_only, string $query, bool $is_metric ): array {
		$out = array();

		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$is_custom = ! empty( $field['customDefinition'] );
			if ( $custom_only && ! $is_custom ) {
				continue;
			}

			$row = array(
				'api_name'    => (string) ( $field['apiName'] ?? '' ),
				'ui_name'     => (string) ( $field['uiName'] ?? '' ),
				'description' => (string) ( $field['description'] ?? '' ),
				'custom'      => $is_custom,
				'category'    => (string) ( $field['category'] ?? '' ),
			);

			if ( $is_metric ) {
				$row['type'] = (string) ( $field['type'] ?? '' );
			}

			if ( '' !== $query && ! self::matches_query( $row, $query ) ) {
				continue;
			}

			$out[] = $row;
		}

		return $out;
	}

	/**
	 * @param array  $row   Linha já traduzida (api_name, ui_name, description).
	 * @param string $query Termo de busca.
	 */
	private static function matches_query( array $row, string $query ): bool {
		foreach ( array( 'api_name', 'ui_name', 'description' ) as $key ) {
			if ( isset( $row[ $key ] ) && false !== stripos( (string) $row[ $key ], $query ) ) {
				return true;
			}
		}

		return false;
	}

	private static function register_check_compatibility(): void {
		Ability::register(
			'ga/check-compatibility',
			'ga',
			array(
				'label'        => __( 'GA4: checar compatibilidade', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Verifica se uma combinação de dimensões, métricas e filtros é válida no GA4 antes de gastar cota com run-report. Params: property_id (opcional), dimensions (required), metrics (required), dimension_filter, metric_filter, compatibility_filter, format (opcionais).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'property_id'          => self::schema_property_id(),
						'dimensions'           => self::schema_dimensions_or_metrics( __( 'dimensão', 'wp-mcp-google-fator3' ) ),
						'metrics'              => self::schema_dimensions_or_metrics( __( 'métrica', 'wp-mcp-google-fator3' ) ),
						'dimension_filter'     => self::schema_filter( self::hint_dimension_filter() ),
						'metric_filter'        => self::schema_filter( self::hint_metric_filter() ),
						'compatibility_filter' => array(
							'type'        => 'string',
							'enum'        => array( 'COMPATIBLE', 'INCOMPATIBLE' ),
							'description' => __( 'Restringe a lista devolvida só ao que é compatível ou só ao que é incompatível com o restante da combinação. Omitido: devolve os dois grupos.', 'wp-mcp-google-fator3' ),
						),
						'format'               => self::schema_format( 'table' ),
					),
					'required'   => array( 'dimensions', 'metrics' ),
				),
				'callback'     => array( self::class, 'run_check_compatibility' ),
			)
		);
	}

	/**
	 * @param array $input Entrada já normalizada.
	 */
	public static function run_check_compatibility( array $input ): array {
		$property_rn = PropertyId::normalize( $input['property_id'] ?? null );
		if ( is_wp_error( $property_rn ) ) {
			return Response::fail( $property_rn );
		}

		$body = array(
			'dimensions' => self::normalize_field_list( $input['dimensions'] ?? array() ),
			'metrics'    => self::normalize_field_list( $input['metrics'] ?? array() ),
		);

		if ( ! empty( $input['dimension_filter'] ) && is_array( $input['dimension_filter'] ) ) {
			$body['dimensionFilter'] = DataApi::normalize_keys( $input['dimension_filter'] );
		}
		if ( ! empty( $input['metric_filter'] ) && is_array( $input['metric_filter'] ) ) {
			$body['metricFilter'] = DataApi::normalize_keys( $input['metric_filter'] );
		}
		if ( ! empty( $input['compatibility_filter'] ) && is_scalar( $input['compatibility_filter'] ) ) {
			$body['compatibilityFilter'] = strtoupper( (string) $input['compatibility_filter'] );
		}

		$response = DataApi::check_compatibility( $property_rn, $body );
		if ( is_wp_error( $response ) ) {
			return Response::fail( $response );
		}

		$compatible_dimensions = array();
		$compatible_metrics    = array();
		$incompatible          = array();

		foreach ( self::as_list( $response, 'dimensionCompatibilities' ) as $item ) {
			self::split_compatibility( $item, 'dimensionMetadata', 'dimension', $compatible_dimensions, $incompatible );
		}
		foreach ( self::as_list( $response, 'metricCompatibilities' ) as $item ) {
			self::split_compatibility( $item, 'metricMetadata', 'metric', $compatible_metrics, $incompatible );
		}

		$data = array(
			'compatible_dimensions' => $compatible_dimensions,
			'compatible_metrics'    => $compatible_metrics,
			'incompatible'          => $incompatible,
		);

		if ( isset( $input['format'] ) && 'raw' === $input['format'] ) {
			$data['raw'] = self::scrub_deep( $response );
		}

		return Response::ok( $data );
	}

	/**
	 * @param mixed  $item          Um item de dimensionCompatibilities/metricCompatibilities.
	 * @param string $metadata_key  'dimensionMetadata' ou 'metricMetadata'.
	 * @param string $type          'dimension' ou 'metric', para o registro de incompatível.
	 * @param array  $compatible    Lista de nomes compatíveis (por referência).
	 * @param array  $incompatible  Lista de incompatíveis (por referência).
	 */
	private static function split_compatibility( $item, string $metadata_key, string $type, array &$compatible, array &$incompatible ): void {
		if ( ! is_array( $item ) ) {
			return;
		}

		$metadata = is_array( $item[ $metadata_key ] ?? null ) ? $item[ $metadata_key ] : array();
		$name     = (string) ( $metadata['apiName'] ?? '' );
		$status   = (string) ( $item['compatibility'] ?? '' );

		if ( 'COMPATIBLE' === $status ) {
			$compatible[] = $name;
		} else {
			$incompatible[] = array(
				'name'          => $name,
				'type'          => $type,
				'compatibility' => $status,
			);
		}
	}

	// =========================================================================
	// Relatórios (Data API)
	// =========================================================================

	private static function register_run_report(): void {
		Ability::register(
			'ga/run-report',
			'ga',
			array(
				'label'        => __( 'GA4: relatório', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Executa um relatório GA4 (Data API runReport): dimensões, métricas, filtros, ordenação e período livres. Ver a description de cada parâmetro para exemplos de JSON. Params: date_ranges, dimensions, metrics (required); property_id, dimension_filter, metric_filter, order_bys, limit, offset, currency_code, keep_empty_rows, return_property_quota, format (opcionais).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => self::schema_report_properties( false ),
					'required'   => array( 'date_ranges', 'dimensions', 'metrics' ),
				),
				'callback'     => array( self::class, 'run_run_report' ),
			)
		);
	}

	private static function register_run_realtime_report(): void {
		Ability::register(
			'ga/run-realtime-report',
			'ga',
			array(
				'label'        => __( 'GA4: relatório em tempo real', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Executa um relatório em tempo real do GA4 (últimos ~30 minutos de atividade). Só aceita dimensões/métricas realtime — sem métricas customizadas. Params: property_id (opcional), dimensions (required), metrics (required), dimension_filter, metric_filter, order_bys, limit, offset, minute_ranges, return_property_quota, format (opcionais).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => self::schema_report_properties( true ),
					'required'   => array( 'dimensions', 'metrics' ),
				),
				'callback'     => array( self::class, 'run_run_realtime_report' ),
			)
		);
	}

	private static function register_run_conversions_report(): void {
		$properties                               = self::schema_report_properties( false );
		$properties['conversion_spec']            = self::schema_conversion_spec();
		$properties['dimensions']['description'] .= ' ' . self::hint_conversion_dimensions();
		$properties['metrics']['description']    .= ' ' . self::hint_conversion_metrics();
		unset( $properties['keep_empty_rows'] );

		Ability::register(
			'ga/run-conversions-report',
			'ga',
			array(
				'label'        => __( 'GA4: relatório de conversões', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Executa um relatório de conversões, custo de anúncio e ROAS do GA4 (v1alpha runReport com conversionSpec). Use no lugar de run-report para conversões/anúncio. Params: date_ranges, dimensions, metrics, conversion_spec (required); property_id, dimension_filter, metric_filter, order_bys, limit, offset, currency_code, return_property_quota, format (opcionais).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => $properties,
					'required'   => array( 'date_ranges', 'dimensions', 'metrics', 'conversion_spec' ),
				),
				'callback'     => array( self::class, 'run_run_conversions_report' ),
			)
		);
	}

	private static function register_run_funnel_report(): void {
		Ability::register(
			'ga/run-funnel-report',
			'ga',
			array(
				'label'        => __( 'GA4: relatório de funil', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Executa um relatório de funil GA4 (v1alpha runFunnelReport): progressão dos usuários por uma sequência de passos, com desdobramento e próxima ação opcionais. Sem date_ranges, usa os últimos 30 dias. Params: property_id (opcional), funnel_steps (required), date_ranges, funnel_breakdown, funnel_next_action, segments, return_property_quota, format (opcionais; padrão raw).', 'wp-mcp-google-fator3' ),
				'input_schema' => array(
					'properties' => array(
						'property_id'           => self::schema_property_id(),
						'funnel_steps'          => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'object' ),
							'description' => self::hint_funnel_steps(),
						),
						'date_ranges'           => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'object' ),
							'description' => __( 'Opcional; sem isto, os últimos 30 dias (30daysAgo até yesterday). ', 'wp-mcp-google-fator3' ) . self::hint_date_ranges(),
						),
						'funnel_breakdown'      => array(
							'type'        => 'object',
							'description' => __( 'Desdobra o funil por uma dimensão — um funil inteiro é calculado para cada valor dela. Formato: {"breakdown_dimension":"deviceCategory"}. Dimensões comuns: deviceCategory, country, operatingSystem, browser.', 'wp-mcp-google-fator3' ),
						),
						'funnel_next_action'    => array(
							'type'        => 'object',
							'description' => __( 'Analisa o que os usuários fazem em seguida, tenham completado o funil ou abandonado. Formato: {"next_action_dimension":"eventName","limit":5}. Dimensões comuns: eventName, pagePath.', 'wp-mcp-google-fator3' ),
						),
						'segments'              => array(
							'type'        => 'array',
							'items'       => array( 'type' => 'object' ),
							'description' => __( 'Opcional: segmenta o funil por critério de usuário. Cada item é um Segment da Data API v1alpha, chaves em snake_case ou camelCase — ver a referência do FunnelSegment na documentação de funis do GA4.', 'wp-mcp-google-fator3' ),
						),
						'return_property_quota' => self::schema_return_property_quota(),
						'format'                => self::schema_format( 'raw' ),
					),
					'required'   => array( 'funnel_steps' ),
				),
				'callback'     => array( self::class, 'run_run_funnel_report' ),
			)
		);
	}

	/**
	 * @param array $input Entrada já normalizada.
	 */
	public static function run_run_report( array $input ): array {
		return self::execute_report(
			$input,
			static function ( string $property_rn, array $body ) {
				return DataApi::run_report( $property_rn, $body );
			},
			false,
			'table'
		);
	}

	/**
	 * @param array $input Entrada já normalizada.
	 */
	public static function run_run_realtime_report( array $input ): array {
		return self::execute_report(
			$input,
			static function ( string $property_rn, array $body ) {
				return DataApi::run_realtime_report( $property_rn, $body );
			},
			true,
			'table'
		);
	}

	/**
	 * @param array $input Entrada já normalizada.
	 */
	public static function run_run_conversions_report( array $input ): array {
		return self::execute_report(
			$input,
			static function ( string $property_rn, array $body ) {
				$spec = DataApi::normalize_keys( $body['__conversion_spec'] ?? array() );
				unset( $body['__conversion_spec'] );

				$body['conversionSpec'] = array(
					'conversionActions' => self::conversion_actions( $spec ),
					'attributionModel'  => self::attribution_model( $spec ),
				);

				return DataApi::run_conversions_report( $property_rn, $body );
			},
			false,
			'table',
			static function ( array $body, array $input ): array {
				$body['__conversion_spec'] = $input['conversion_spec'] ?? array();

				return $body;
			}
		);
	}

	/**
	 * @param array $spec conversion_spec já com as chaves em camelCase.
	 * @return string[]
	 */
	private static function conversion_actions( array $spec ): array {
		$actions = $spec['conversionActions'] ?? array();
		if ( ! is_array( $actions ) ) {
			return array();
		}

		return array_values( array_map( 'strval', $actions ) );
	}

	private static function attribution_model( array $spec ): string {
		$model = isset( $spec['attributionModel'] ) && is_scalar( $spec['attributionModel'] )
			? strtoupper( (string) $spec['attributionModel'] )
			: 'DATA_DRIVEN';

		return in_array( $model, array( 'DATA_DRIVEN', 'LAST_CLICK' ), true ) ? $model : 'DATA_DRIVEN';
	}

	/**
	 * @param array $input Entrada já normalizada.
	 */
	public static function run_run_funnel_report( array $input ): array {
		$property_rn = PropertyId::normalize( $input['property_id'] ?? null );
		if ( is_wp_error( $property_rn ) ) {
			return Response::fail( $property_rn );
		}

		$steps = self::build_funnel_steps( is_array( $input['funnel_steps'] ?? null ) ? $input['funnel_steps'] : array() );
		if ( is_wp_error( $steps ) ) {
			return Response::fail( $steps );
		}

		$body = array(
			'funnel'     => array( 'steps' => $steps ),
			'dateRanges' => self::funnel_date_ranges( $input['date_ranges'] ?? null ),
		);

		if ( ! empty( $input['funnel_breakdown'] ) && is_array( $input['funnel_breakdown'] ) ) {
			$breakdown = DataApi::normalize_keys( $input['funnel_breakdown'] );
			if ( isset( $breakdown['breakdownDimension'] ) && is_scalar( $breakdown['breakdownDimension'] ) ) {
				$body['funnelBreakdown'] = array(
					'breakdownDimension' => array( 'name' => (string) $breakdown['breakdownDimension'] ),
				);
			}
		}

		if ( ! empty( $input['funnel_next_action'] ) && is_array( $input['funnel_next_action'] ) ) {
			$next_action = DataApi::normalize_keys( $input['funnel_next_action'] );
			if ( isset( $next_action['nextActionDimension'] ) && is_scalar( $next_action['nextActionDimension'] ) ) {
				$next = array( 'nextActionDimension' => array( 'name' => (string) $next_action['nextActionDimension'] ) );
				if ( isset( $next_action['limit'] ) && is_numeric( $next_action['limit'] ) ) {
					$next['limit'] = (int) $next_action['limit'];
				}
				$body['funnelNextAction'] = $next;
			}
		}

		if ( ! empty( $input['segments'] ) && is_array( $input['segments'] ) ) {
			$body['segments'] = DataApi::normalize_keys( $input['segments'] );
		}

		if ( ! empty( $input['return_property_quota'] ) ) {
			$body['returnPropertyQuota'] = true;
		}

		$response = DataApi::run_funnel_report( $property_rn, $body );
		if ( is_wp_error( $response ) ) {
			return Response::fail( $response );
		}

		$format = isset( $input['format'] ) && 'table' === $input['format'] ? 'table' : 'raw';

		if ( 'table' === $format ) {
			$funnel_table = $response['funnelTable'] ?? null;
			if ( is_array( $funnel_table ) ) {
				return Response::ok( DataApi::to_table( $funnel_table ) );
			}
		}

		return Response::ok( array( 'raw' => self::scrub_deep( $response ) ) );
	}

	/**
	 * @param array $steps Cada item: {name, event} ou {name, filter_expression|filterExpression}.
	 * @return array|\WP_Error Lista de FunnelStep já em camelCase.
	 */
	private static function build_funnel_steps( array $steps ) {
		if ( empty( $steps ) ) {
			return new \WP_Error(
				'f3_google_funnel_steps_required',
				__( 'funnel_steps precisa ter ao menos um passo.', 'wp-mcp-google-fator3' )
			);
		}

		$out = array();

		foreach ( $steps as $index => $step ) {
			if ( ! is_array( $step ) ) {
				return new \WP_Error(
					'f3_google_funnel_step_invalid',
					sprintf(
						/* translators: %d: posição do passo (a partir de 1). */
						__( 'O passo %d de funnel_steps precisa ser um objeto.', 'wp-mcp-google-fator3' ),
						(int) $index + 1
					)
				);
			}

			$name = isset( $step['name'] ) && is_scalar( $step['name'] )
				? (string) $step['name']
				: sprintf(
					/* translators: %d: posição do passo (a partir de 1). */
					__( 'Passo %d', 'wp-mcp-google-fator3' ),
					(int) $index + 1
				);

			if ( isset( $step['event'] ) && is_scalar( $step['event'] ) ) {
				$out[] = array(
					'name'             => $name,
					'filterExpression' => array(
						'funnelEventFilter' => array( 'eventName' => (string) $step['event'] ),
					),
				);
				continue;
			}

			$filter_expression = $step['filter_expression'] ?? $step['filterExpression'] ?? null;
			if ( is_array( $filter_expression ) ) {
				$out[] = array(
					'name'             => $name,
					'filterExpression' => DataApi::normalize_keys( $filter_expression ),
				);
				continue;
			}

			return new \WP_Error(
				'f3_google_funnel_step_invalid',
				sprintf(
					/* translators: %d: posição do passo (a partir de 1). */
					__( 'O passo %d de funnel_steps precisa ter "event" ou "filter_expression".', 'wp-mcp-google-fator3' ),
					(int) $index + 1
				)
			);
		}

		return $out;
	}

	/**
	 * @param mixed $date_ranges Entrada do agente, ou ausente.
	 */
	private static function funnel_date_ranges( $date_ranges ): array {
		if ( ! is_array( $date_ranges ) || empty( $date_ranges ) ) {
			// Mesmo padrão do MCP oficial do Google para relatórios: os
			// últimos 30 dias fechados, terminando ontem.
			return array(
				array(
					'startDate' => '30daysAgo',
					'endDate'   => 'yesterday',
				),
			);
		}

		return DataApi::normalize_keys( $date_ranges );
	}

	// =========================================================================
	// Montagem comum de run-report / run-realtime-report / run-conversions-report
	// =========================================================================

	/**
	 * @param array         $input      Entrada já normalizada.
	 * @param callable      $caller     function(string $property_rn, array $body): array|\WP_Error.
	 * @param bool          $realtime   True para runRealtimeReport (sem dateRanges/currencyCode/keepEmptyRows).
	 * @param string        $default_format 'table' ou 'raw'.
	 * @param callable|null $extend     Ajuste extra ao corpo antes de chamar $caller (usado por conversions para carregar o conversion_spec).
	 */
	private static function execute_report( array $input, callable $caller, bool $realtime, string $default_format, ?callable $extend = null ): array {
		$property_rn = PropertyId::normalize( $input['property_id'] ?? null );
		if ( is_wp_error( $property_rn ) ) {
			return Response::fail( $property_rn );
		}

		$body = array();

		if ( $realtime ) {
			if ( ! empty( $input['minute_ranges'] ) && is_array( $input['minute_ranges'] ) ) {
				$body['minuteRanges'] = DataApi::normalize_keys( $input['minute_ranges'] );
			}
		} else {
			$body['dateRanges'] = DataApi::normalize_keys( is_array( $input['date_ranges'] ?? null ) ? $input['date_ranges'] : array() );
		}

		$body['dimensions'] = self::normalize_field_list( $input['dimensions'] ?? array() );
		$body['metrics']    = self::normalize_field_list( $input['metrics'] ?? array() );

		if ( ! empty( $input['dimension_filter'] ) && is_array( $input['dimension_filter'] ) ) {
			$body['dimensionFilter'] = DataApi::normalize_keys( $input['dimension_filter'] );
		}
		if ( ! empty( $input['metric_filter'] ) && is_array( $input['metric_filter'] ) ) {
			$body['metricFilter'] = DataApi::normalize_keys( $input['metric_filter'] );
		}
		if ( ! empty( $input['order_bys'] ) && is_array( $input['order_bys'] ) ) {
			$body['orderBys'] = DataApi::normalize_keys( $input['order_bys'] );
		}

		$resolved = self::resolve_limit( $input['limit'] ?? null );
		if ( is_wp_error( $resolved ) ) {
			return Response::fail( $resolved );
		}

		list( $limit, $limit_truncated ) = $resolved;
		$body['limit']                   = $limit;

		$offset = 0;
		if ( array_key_exists( 'offset', $input ) && is_numeric( $input['offset'] ) && (int) $input['offset'] > 0 ) {
			$offset         = (int) $input['offset'];
			$body['offset'] = $offset;
		}

		if ( ! $realtime ) {
			if ( ! empty( $input['currency_code'] ) && is_scalar( $input['currency_code'] ) ) {
				$body['currencyCode'] = strtoupper( (string) $input['currency_code'] );
			}
			if ( array_key_exists( 'keep_empty_rows', $input ) ) {
				$body['keepEmptyRows'] = (bool) $input['keep_empty_rows'];
			}
		}

		if ( ! empty( $input['return_property_quota'] ) ) {
			$body['returnPropertyQuota'] = true;
		}

		if ( null !== $extend ) {
			$body = $extend( $body, $input );
		}

		$response = $caller( $property_rn, $body );
		if ( is_wp_error( $response ) ) {
			return Response::fail( $response );
		}

		$format = isset( $input['format'] ) && 'raw' === $input['format'] ? 'raw' : $default_format;

		if ( 'raw' === $format ) {
			return Response::ok( array( 'raw' => self::scrub_deep( $response ) ) );
		}

		$table              = DataApi::to_table( $response );
		$table['truncated'] = $limit_truncated || ( $table['row_count_total'] > ( $offset + $table['row_count'] ) );

		return Response::ok( $table );
	}

	/**
	 * @param mixed $requested Valor de `limit` pedido pelo agente.
	 * @return array{0:int,1:bool}|\WP_Error [limite efetivo, se foi cortado pelo teto].
	 */
	private static function resolve_limit( $requested ) {
		$max = Options::max_rows();

		if ( null === $requested || '' === $requested ) {
			return array( $max, false );
		}

		// `limit: 0` ou `limit: -5` cai aqui, e não num silencioso "usa o
		// padrão": devolver mil linhas para quem pediu zero é uma resposta que
		// o agente não tem como perceber que está errada. O esquema declara
		// `minimum: 1`, então o WordPress 6.9 já recusaria — esta checagem
		// mantém o mesmo comportamento onde a Abilities API vem de polyfill.
		$number = is_numeric( $requested ) ? (float) $requested : 0.0;

		if ( ! is_numeric( $requested ) || 1 > $number || floor( $number ) !== $number ) {
			return new \WP_Error(
				'f3_google_bad_limit',
				__( 'limit precisa ser um número inteiro maior que zero.', 'wp-mcp-google-fator3' )
			);
		}

		$limit = (int) $requested;

		if ( $limit > $max ) {
			return array( $max, true );
		}

		return array( $limit, false );
	}

	/**
	 * Dimensões/métricas: cada item pode ser uma string ('eventName') ou um
	 * objeto ({"name":"eventName"}), do jeito que os dois formatos convivem
	 * nos exemplos do MCP oficial do Google.
	 *
	 * @param mixed $list Lista de dimensões ou métricas.
	 * @return array[] Lista de {name: string}.
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.listFound -- Preserva os nomes dos parâmetros da API interna existente na versão 0.1.0.
	private static function normalize_field_list( $list ): array {
		// Uma dimensão só chega frequentemente como string em vez de lista de um
		// item — e o núcleo do WordPress 6.9 deixa passar (`rest_is_array()`
		// aceita escalar e o validador não converte). Descartar em silêncio
		// produziria um relatório sem a dimensão pedida, que é pior do que um
		// erro: o agente reportaria o número errado sem suspeitar de nada.
		if ( is_scalar( $list ) ) {
			$list = '' === trim( (string) $list ) ? array() : explode( ',', (string) $list );
		}

		if ( ! is_array( $list ) ) {
			return array();
		}

		$out = array();

		foreach ( $list as $item ) {
			if ( is_scalar( $item ) ) {
				$name = trim( (string) $item );

				if ( '' !== $name ) {
					$out[] = array( 'name' => $name );
				}
			} elseif ( is_array( $item ) ) {
				$out[] = DataApi::normalize_keys( $item );
			}
		}

		return $out;
	}

	/**
	 * Remove qualquer segredo configurado de toda string dentro de uma
	 * estrutura, antes de sair como resposta `raw`. A Data/Admin API do GA4
	 * nunca devolve token, mas o custo desta passada é baixo perto do de uma
	 * chave vazando por coincidência de texto.
	 *
	 * @param mixed $value Estrutura ou escalar.
	 * @return mixed
	 */
	private static function scrub_deep( $value ) {
		if ( is_string( $value ) ) {
			return Ability::scrub( $value );
		}

		if ( is_array( $value ) ) {
			return array_map( array( self::class, 'scrub_deep' ), $value );
		}

		return $value;
	}

	/**
	 * @param array  $data Estrutura decodificada.
	 * @param string $key  Chave esperada como lista.
	 * @return array
	 */
	private static function as_list( array $data, string $key ): array {
		return isset( $data[ $key ] ) && is_array( $data[ $key ] ) ? $data[ $key ] : array();
	}

	// =========================================================================
	// Esquemas de entrada reutilizados
	// =========================================================================

	/**
	 * @param string $extra Complemento opcional à descrição padrão.
	 */
	private static function schema_property_id( string $extra = '' ): array {
		$description = __( 'ID da propriedade GA4: um número (123456) ou "properties/123456". Ausente: usa a propriedade padrão configurada em Ferramentas > MCP Google, quando houver.', 'wp-mcp-google-fator3' );

		// `type` como lista, e não `oneOf`: o WordPress 6.9+ valida a entrada com
		// `rest_validate_value_from_schema`, e ali `oneOf` exige que o valor case
		// com EXATAMENTE um dos ramos. Como `rest_is_integer( '123456' )` é
		// verdadeiro, a string "123456" — a forma mais natural de mandar um
		// property_id — casaria com os dois ramos e seria recusada com "matches 2
		// schemas". Com `type` em lista o núcleo escolhe o melhor tipo e aceita as
		// duas formas, que é o que `PropertyId::normalize()` já sabe tratar.
		return array(
			'type'        => array( 'string', 'integer' ),
			'description' => '' === $extra ? $description : $description . ' ' . $extra,
		);
	}

	private static function schema_dimensions_or_metrics( string $label ): array {
		return array(
			'type'        => 'array',
			// Mesma razão do property_id: com `oneOf`, uma string vazia casaria
			// com os dois ramos (o núcleo converte '' em objeto vazio) e a lista
			// inteira seria recusada.
			'items'       => array(
				'type' => array( 'string', 'object' ),
			),
			/* translators: %s: 'dimensão' ou 'métrica'. */
			'description' => sprintf(
				__( 'Lista de nomes de %s do GA4 — cada item pode ser uma string ("eventName") ou um objeto ({"name":"eventName"}). Use ga/get-metadata para descobrir os nomes válidos (padrão do GA4 e, quando houver property_id, também os customizados da propriedade).', 'wp-mcp-google-fator3' ),
				$label
			),
		);
	}

	private static function schema_filter( string $hint ): array {
		return array(
			'type'        => 'object',
			'description' => $hint,
		);
	}

	private static function schema_order_bys(): array {
		return array(
			'type'        => 'array',
			'items'       => array( 'type' => 'object' ),
			'description' => self::hint_order_bys(),
		);
	}

	private static function schema_date_ranges(): array {
		return array(
			'type'        => 'array',
			'items'       => array( 'type' => 'object' ),
			'description' => self::hint_date_ranges(),
		);
	}

	private static function schema_return_property_quota(): array {
		return array(
			'type'        => 'boolean',
			'default'     => false,
			'description' => __( 'Inclui o uso de cota da propriedade (tokens do dia, por hora, etc.) na resposta.', 'wp-mcp-google-fator3' ),
		);
	}

	/**
	 * @param string $default 'table' ou 'raw'.
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.defaultFound -- Preserva os nomes dos parâmetros da API interna existente na versão 0.1.0.
	private static function schema_format( string $default ): array {
		return array(
			'type'        => 'string',
			'enum'        => array( 'table', 'raw' ),
			'default'     => $default,
			'description' => 'table' === $default
				? __( 'table (padrão): {columns, rows, row_count, row_count_total, truncated, totals?} — poupa tokens. raw: resposta da API Google sem alteração (camelCase).', 'wp-mcp-google-fator3' )
				: __( 'raw (padrão): resposta bruta, incluindo funnelVisualization — a estrutura de um funil não cabe bem numa tabela única. table: converte só o funnelTable em {columns, rows}.', 'wp-mcp-google-fator3' ),
		);
	}

	private static function schema_conversion_spec(): array {
		return array(
			'type'        => 'object',
			'description' => __(
				'Obrigatório nesta habilidade. Formato: {"conversion_actions":["conversionActions/12345"],"attribution_model":"DATA_DRIVEN"}. Use [] em conversion_actions para todos os eventos de conversão. attribution_model aceita DATA_DRIVEN (padrão) ou LAST_CLICK. Chaves em snake_case ou camelCase.',
				'wp-mcp-google-fator3'
			),
		);
	}

	/**
	 * Propriedades comuns a run-report, run-realtime-report e
	 * run-conversions-report — a diferença entre elas é `date_ranges`
	 * (ausente no realtime, que usa `minute_ranges`) e `currency_code`/
	 * `keep_empty_rows` (ausentes no realtime).
	 *
	 * @param bool $realtime True para run-realtime-report.
	 */
	private static function schema_report_properties( bool $realtime ): array {
		$properties = array(
			'property_id'           => self::schema_property_id(),
			'dimensions'            => self::schema_dimensions_or_metrics( __( 'dimensão', 'wp-mcp-google-fator3' ) ),
			'metrics'               => self::schema_dimensions_or_metrics( __( 'métrica', 'wp-mcp-google-fator3' ) ),
			'dimension_filter'      => self::schema_filter( self::hint_dimension_filter() ),
			'metric_filter'         => self::schema_filter( self::hint_metric_filter() ),
			'order_bys'             => self::schema_order_bys(),
			'limit'                 => array(
				'type'        => 'integer',
				'minimum'     => 1,
				'description' => __( 'Máximo de linhas devolvidas. Padrão e teto: o limite configurado do plugin (Options::max_rows, 1000 de fábrica); pedidos maiores são cortados e a resposta vem com truncated=true.', 'wp-mcp-google-fator3' ),
			),
			'return_property_quota' => self::schema_return_property_quota(),
			'format'                => self::schema_format( 'table' ),
		);

		if ( $realtime ) {
			$properties['minute_ranges'] = array(
				'type'        => 'array',
				'items'       => array( 'type' => 'object' ),
				'description' => __( 'Períodos em minutos antes de agora (janela realtime, até 30 minutos). Formato: [{"start_minutes_ago":29,"end_minutes_ago":0}]. Omitido: os últimos 30 minutos.', 'wp-mcp-google-fator3' ),
			);
		} else {
			$properties['offset']          = array(
				'type'        => 'integer',
				'minimum'     => 0,
				'description' => __( 'Linha inicial (a primeira é 0). Use com limit para paginar relatórios grandes.', 'wp-mcp-google-fator3' ),
			);
			$properties['date_ranges']     = self::schema_date_ranges();
			$properties['currency_code']   = array(
				'type'        => 'string',
				'description' => __( 'Código de moeda ISO 4217 (ex.: "USD", "BRL", "JPY") para os valores monetários do relatório. Vazio: usa a moeda padrão da propriedade.', 'wp-mcp-google-fator3' ),
			);
			$properties['keep_empty_rows'] = array(
				'type'        => 'boolean',
				'default'     => false,
				'description' => __( 'Se true, inclui linhas cujas métricas são todas zero. Padrão false, como a API.', 'wp-mcp-google-fator3' ),
			);
		}

		return $properties;
	}

	// =========================================================================
	// Dicas longas (exemplos de JSON), convertidas dos textos do MCP oficial
	// do Google (analytics_mcp/tools/reporting/*.py) para camelCase compacto.
	//
	// As cinco funções abaixo concatenam vários exemplos de JSON num único
	// texto de descrição de parâmetro (não é string de interface exibida em
	// tela). Quebrar cada exemplo num __() separado fragmentaria o contexto do
	// tradutor sem ganho real — quem traduzisse perderia a view do texto
	// inteiro que o agente MCP lê de uma vez. `phpcs:ignore
	// WordPress.WP.I18n.NonSingularStringLiteralText` documenta essa exceção
	// em cada uma.
	// =========================================================================

	private static function hint_date_ranges(): string {
		// phpcs:disable WordPress.WP.I18n.NonSingularStringLiteralText -- texto de referência técnica concatenado por legibilidade; ver nota acima.
		return __(
			'Lista de períodos. Cada item: {"startDate":"YYYY-MM-DD"|"today"|"yesterday"|"NdaysAgo","endDate":"...","name":"opcional"} (aceita start_date/end_date em vez de startDate/endDate). '
			. 'Exemplos: '
			. '1) Um período: [{"startDate":"2025-01-01","endDate":"2025-01-31","name":"Jan2025"}]. '
			. '2) Relativo: [{"startDate":"yesterday","endDate":"today"}]. '
			. '3) Relativo com "NdaysAgo": [{"startDate":"30daysAgo","endDate":"yesterday"}]. '
			. '4) Múltiplos períodos (a resposta ganha uma dimensão "dateRange" identificando cada linha): [{"startDate":"2025-01-01","endDate":"2025-01-31","name":"Jan2025"},{"startDate":"2025-02-01","endDate":"2025-02-28","name":"Feb2025"}].',
			'wp-mcp-google-fator3'
		);
		// phpcs:enable WordPress.WP.I18n.NonSingularStringLiteralText
	}

	private static function filter_notes(): string {
		return __(
			'Nota: dimension_filter e metric_filter são aplicados de forma independente pela API — não é possível combinar "(dimensão=X E métrica>Y) OU (dimensão=Z E métrica<W)" numa única chamada. Para isso, rode um relatório com a condição de dimensão que a API suporta e filtre o resultado no lado do agente, ou rode uma chamada separada para cada combinação.',
			'wp-mcp-google-fator3'
		);
	}

	private static function hint_dimension_filter(): string {
		// phpcs:disable WordPress.WP.I18n.NonSingularStringLiteralText -- texto de referência técnica concatenado por legibilidade; ver nota acima.
		return __(
			'FilterExpression da Data API para as DIMENSÕES do relatório (não use para métrica — use metric_filter). Chaves aceitas em snake_case ou camelCase (field_name/fieldName, match_type/matchType, and_group/andGroup...); os VALORES (o texto procurado, o nome do campo) nunca mudam de caixa. '
			. 'Exemplos: '
			. '1) Simples: {"filter":{"fieldName":"eventName","stringFilter":{"matchType":"BEGINS_WITH","value":"add"}}}. '
			. '2) Negação: {"notExpression":{"filter":{"fieldName":"eventName","stringFilter":{"matchType":"BEGINS_WITH","value":"add"}}}}. '
			. '3) Valor vazio: {"filter":{"fieldName":"source","emptyFilter":{}}}. '
			. '4) Lista: {"filter":{"fieldName":"eventName","inListFilter":{"caseSensitive":true,"values":["first_visit","purchase","add_to_cart"]}}}. '
			. '5) E (andGroup): {"andGroup":{"expressions":[{"filter":{"fieldName":"sourceMedium","stringFilter":{"matchType":"EXACT","value":"google / cpc"}}},{"filter":{"fieldName":"eventName","inListFilter":{"values":["first_visit","purchase"]}}}]}}. '
			. '6) Ou (orGroup): mesma forma do andGroup, trocando a chave por "orGroup". '
			. 'match_type aceita EXACT, BEGINS_WITH, ENDS_WITH, CONTAINS, FULL_REGEXP, PARTIAL_REGEXP (maiúsculas, é enum). '
			. self::filter_notes(),
			'wp-mcp-google-fator3'
		);
		// phpcs:enable WordPress.WP.I18n.NonSingularStringLiteralText
	}

	private static function hint_metric_filter(): string {
		// phpcs:disable WordPress.WP.I18n.NonSingularStringLiteralText -- texto de referência técnica concatenado por legibilidade; ver nota acima.
		return __(
			'FilterExpression da Data API para as MÉTRICAS do relatório (não use para dimensão — use dimension_filter). Mesmas regras de chaves de dimension_filter. '
			. 'Exemplos: '
			. '1) Simples: {"filter":{"fieldName":"eventCount","numericFilter":{"operation":"GREATER_THAN","value":{"int64Value":"10"}}}}. '
			. '2) Negação: {"notExpression":{"filter":{"fieldName":"eventCount","numericFilter":{"operation":"GREATER_THAN","value":{"int64Value":"10"}}}}}. '
			. '3) Valor vazio: {"filter":{"fieldName":"purchaseRevenue","emptyFilter":{}}}. '
			. '4) Intervalo: {"filter":{"fieldName":"purchaseRevenue","betweenFilter":{"fromValue":{"doubleValue":10},"toValue":{"doubleValue":25}}}}. '
			. '5) E/Ou (andGroup/orGroup): {"andGroup":{"expressions":[<filtro 1>,<filtro 2>]}}. '
			. 'operation aceita EQUAL, LESS_THAN, LESS_THAN_OR_EQUAL, GREATER_THAN, GREATER_THAN_OR_EQUAL (maiúsculas, é enum); o valor vai em int64Value (string) ou doubleValue (número), nunca os dois. '
			. self::filter_notes(),
			'wp-mcp-google-fator3'
		);
		// phpcs:enable WordPress.WP.I18n.NonSingularStringLiteralText
	}

	private static function hint_order_bys(): string {
		// phpcs:disable WordPress.WP.I18n.NonSingularStringLiteralText -- texto de referência técnica concatenado por legibilidade; ver nota acima.
		return __(
			'Lista de OrderBy da Data API. Cada item ordena por uma dimensão ({"dimension":{"dimensionName":"...","orderType":"ALPHANUMERIC"|"CASE_INSENSITIVE_ALPHANUMERIC"|"NUMERIC"}}) ou por uma métrica ({"metric":{"metricName":"..."}}), com "desc":true|false (padrão false, ascendente). '
			. 'A dimensão/métrica citada precisa também estar em dimensions/metrics. '
			. 'Exemplos: '
			. '1) [{"dimension":{"dimensionName":"eventName","orderType":"ALPHANUMERIC"}}]. '
			. '2) [{"dimension":{"dimensionName":"campaignName","orderType":"CASE_INSENSITIVE_ALPHANUMERIC"},"desc":true}]. '
			. '3) [{"metric":{"metricName":"eventCount"}}]. '
			. '4) [{"metric":{"metricName":"eventValue"},"desc":true}]. '
			. '5) Combinando vários: [{"dimension":{"dimensionName":"eventName","orderType":"ALPHANUMERIC"}},{"metric":{"metricName":"eventValue"},"desc":true}].',
			'wp-mcp-google-fator3'
		);
		// phpcs:enable WordPress.WP.I18n.NonSingularStringLiteralText
	}

	private static function hint_conversion_dimensions(): string {
		return __(
			'Nesta habilidade (conversões), as dimensões padrão aceitas são: campaignName, continent, country, defaultChannelGroup, deviceCategory, medium, platform, primaryChannelGroup, source, sourceMedium, sourcePlatform, subcontinent.',
			'wp-mcp-google-fator3'
		);
	}

	private static function hint_conversion_metrics(): string {
		return __(
			'Nesta habilidade (conversões), as métricas padrão aceitas são: advertiserAdClicks, advertiserAdCost, advertiserAdCostPerAllConversionsByConversionDate, advertiserAdCostPerAllConversionsByInteractionDate, advertiserAdCostPerClick, advertiserAdImpressions, allConversionsByConversionDate, allConversionsByInteractionDate, returnOnAdSpendByConversionDate, returnOnAdSpendByInteractionDate, totalRevenueByConversionDate, totalRevenueByInteractionDate.',
			'wp-mcp-google-fator3'
		);
	}

	private static function hint_funnel_steps(): string {
		// phpcs:disable WordPress.WP.I18n.NonSingularStringLiteralText -- texto de referência técnica concatenado por legibilidade; ver nota acima.
		return __(
			'Lista de passos do funil, na ordem. Cada passo: {"name":"rótulo","event":"nome_do_evento"} (forma simples) OU {"name":"rótulo","filter_expression":{...}} (FunnelFilterExpression completo, para condições compostas). Chaves em snake_case ou camelCase. '
			. 'Exemplos: '
			. '1) Passo simples por evento: {"name":"Compra","event":"purchase"}. '
			. '2) Vários eventos equivalentes (orGroup): {"name":"Primeira visita","filterExpression":{"orGroup":{"expressions":[{"funnelEventFilter":{"eventName":"first_open"}},{"funnelEventFilter":{"eventName":"first_visit"}}]}}}. '
			. '3) Filtro de campo: {"name":"Tráfego orgânico","filterExpression":{"funnelFieldFilter":{"fieldName":"firstUserMedium","stringFilter":{"matchType":"CONTAINS","value":"organic"}}}}. '
			. '4) Evento com filtro de parâmetro: {"name":"Add to cart > 50","filterExpression":{"funnelEventFilter":{"eventName":"add_to_cart","funnelParameterFilterExpression":{"funnelParameterFilter":{"eventParameterName":"value","numericFilter":{"operation":"GREATER_THAN","value":{"doubleValue":50}}}}}}}. '
			. 'Um funil típico de e-commerce: [{"name":"Visita","event":"first_visit"},{"name":"Visualização de produto","event":"view_item"},{"name":"Adicionar ao carrinho","event":"add_to_cart"},{"name":"Início do checkout","event":"begin_checkout"},{"name":"Compra","event":"purchase"}].',
			'wp-mcp-google-fator3'
		);
		// phpcs:enable WordPress.WP.I18n.NonSingularStringLiteralText
	}
}
