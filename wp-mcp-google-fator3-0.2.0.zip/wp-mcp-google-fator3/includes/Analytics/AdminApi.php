<?php
/**
 * Chamadas à Admin API do GA4 (contas, propriedades, links, anotações).
 *
 * Fica separada da Data API (relatórios) porque fala com um host diferente
 * (`analyticsadmin.googleapis.com`) e porque suas respostas são paginadas por
 * `nextPageToken`/`pageToken` em vez de vir prontas — `GoogleClient::get_all_pages()`
 * já sabe seguir isso, então cada método aqui só precisa indicar a URL e a
 * chave da lista na resposta.
 *
 * @package Fator3\McpGoogle\Analytics
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Analytics;

use Fator3\McpGoogle\Auth\Credentials;
use Fator3\McpGoogle\Http\GoogleClient;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class AdminApi {

	/**
	 * Todas as contas e propriedades acessíveis pela credencial, com paginação
	 * seguida até o fim — é uma lista de catálogo, não um relatório que possa
	 * crescer sem limite por conta do agente.
	 *
	 * @return array|\WP_Error
	 */
	public static function account_summaries() {
		return GoogleClient::get_all_pages(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/accountSummaries',
			array( 'pageSize' => 200 ),
			'accountSummaries',
			self::opts()
		);
	}

	/**
	 * @param mixed $property_id Ver PropertyId::normalize().
	 * @return array|\WP_Error
	 */
	public static function property( $property_id ) {
		$rn = PropertyId::normalize( $property_id );
		if ( is_wp_error( $rn ) ) {
			return $rn;
		}

		return GoogleClient::get(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/' . $rn,
			array(),
			self::opts()
		);
	}

	/**
	 * @param mixed $property_id Ver PropertyId::normalize().
	 * @return array|\WP_Error
	 */
	public static function google_ads_links( $property_id ) {
		$rn = PropertyId::normalize( $property_id );
		if ( is_wp_error( $rn ) ) {
			return $rn;
		}

		return GoogleClient::get_all_pages(
			GoogleClient::HOST_GA_ADMIN . '/v1beta/' . $rn . '/googleAdsLinks',
			array( 'pageSize' => 200 ),
			'googleAdsLinks',
			self::opts()
		);
	}

	/**
	 * v1alpha: anotações ainda não têm versão estável na Admin API.
	 *
	 * @param mixed $property_id Ver PropertyId::normalize().
	 * @return array|\WP_Error
	 */
	public static function annotations( $property_id ) {
		$rn = PropertyId::normalize( $property_id );
		if ( is_wp_error( $rn ) ) {
			return $rn;
		}

		return GoogleClient::get_all_pages(
			GoogleClient::HOST_GA_ADMIN . '/v1alpha/' . $rn . '/reportingDataAnnotations',
			array( 'pageSize' => 200 ),
			'reportingDataAnnotations',
			self::opts()
		);
	}

	/**
	 * Opções padrão de toda chamada desta classe: escopo de leitura do GA e
	 * rótulo do conector para auditoria/erro.
	 */
	private static function opts(): array {
		return array(
			'scopes'    => Credentials::scopes_for( 'ga' ),
			'connector' => 'ga',
		);
	}
}
