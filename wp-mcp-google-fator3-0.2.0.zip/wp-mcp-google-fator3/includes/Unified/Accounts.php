<?php
/**
 * Resolução explícita de IDs, nomes únicos e contas acessíveis.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);
namespace Fator3\McpGoogle\Unified;

use Fator3\McpGoogle\Gate;
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class Accounts {
	public static function resolve_one( string $connector, $selector ) {
		$ids = self::resolve_many( $connector, array( (string) $selector ) );
		if ( is_wp_error( $ids ) ) {
			return $ids; }
		if ( 1 !== count( $ids ) ) {
			return new \WP_Error( 'f3_google_account_multiple', 'Esta operação exige exatamente uma conta. Use um ID ou nome único.', array( 'candidates' => $ids ) );
		}
		return $ids[0];
	}

	public static function resolve_many( string $connector, array $selectors ) {
		$canonical = Query::connector( $connector );
		if ( is_wp_error( $canonical ) ) {
			return $canonical; }
		$gate_name = array(
			'ga4'            => 'ga',
			'google-ads'     => 'ads',
			'search-console' => 'gsc',
		)[ $canonical ] ?? 'any';
		$out       = array();
		$catalog   = null;
		foreach ( $selectors as $selector ) {
			if ( ! is_scalar( $selector ) || '' === trim( (string) $selector ) ) {
				return new \WP_Error( 'f3_google_account_selector', 'Informe ID, nome único ou *.' );
			}
			$selector = trim( (string) $selector );
			if ( self::is_id( $canonical, $selector ) ) {
				$out[] = self::canonical_id( $canonical, $selector );
				continue; }
			if ( null === $catalog ) {
				$gate = Gate::check( $gate_name );
				if ( null !== $gate ) {
					return new \WP_Error( (string) $gate['error_code'], (string) $gate['message'] ); }
				$result = Query::accounts(
					array(
						'connector'       => $canonical,
						'expand_managers' => true,
					)
				);
				if ( empty( $result['success'] ) || ! empty( $result['warnings'] ) ) {
					return new \WP_Error( 'f3_google_account_catalog', 'Não foi possível obter um catálogo completo de contas: ' . implode( ' | ', (array) ( $result['warnings'] ?? array( $result['message'] ?? '' ) ) ) );
				}
				$catalog = $result['accounts'] ?? array();
			}
			$matches = array();
			foreach ( $catalog as $account ) {
				$id = (string) ( $account['account_id'] ?? '' );
				if ( '' === $id ) {
					continue; }
				if ( '*' === $selector || self::fold( $selector ) === self::fold( (string) ( $account['name'] ?? '' ) ) || $selector === $id || (string) ( $account['native_account_id'] ?? '' ) === $selector ) {
					$matches[ $id ] = array(
						'account_id' => $id,
						'name'       => (string) ( $account['name'] ?? '' ),
						'parent'     => $account['parent'] ?? '',
					);
				}
			}
			if ( ! $matches ) {
				return new \WP_Error( 'f3_google_account_not_found', 'Nenhuma conta acessível corresponde a "' . $selector . '". Consulte google/list-accounts.' ); }
			if ( '*' !== $selector && count( $matches ) > 1 ) {
				return new \WP_Error( 'f3_google_account_ambiguous', 'Nome de conta ambíguo: "' . $selector . '". Informe um dos IDs: ' . implode( ', ', array_keys( $matches ) ), array( 'candidates' => array_values( $matches ) ) );
			}
			$out = array_merge( $out, array_map( 'strval', array_keys( $matches ) ) );
		}
		return array_values( array_unique( array_map( static fn( $id ) => self::canonical_id( $canonical, (string) $id ), $out ) ) );
	}

	private static function canonical_id( string $connector, string $selector ): string {
		if ( 'ga4' === $connector ) {
			return 'properties/' . preg_replace( '#^properties/#', '', $selector );
		}
		if ( 'google-ads' === $connector ) {
			return str_replace( '-', '', (string) preg_replace( '#^customers/#', '', $selector ) );
		}
		return $selector;
	}

	private static function is_id( string $connector, string $selector ): bool {
		if ( 'ga4' === $connector ) {
			return (bool) preg_match( '#^(?:properties/)?[0-9]+$#D', $selector ); }
		if ( 'google-ads' === $connector ) {
			return (bool) preg_match( '#^(?:customers/)?(?:[0-9]{10}|[0-9]{3}-[0-9]{3}-[0-9]{4})$#D', $selector ); }
		if ( 'search-console' === $connector ) {
			return (bool) preg_match( '#^(?:https?://[^\s]+|sc-domain:[^/\s]+)$#D', $selector ); }
		return false;
	}

	private static function fold( string $name ): string {
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( $name ), 'UTF-8' ) : strtolower( trim( $name ) );
	}
}
