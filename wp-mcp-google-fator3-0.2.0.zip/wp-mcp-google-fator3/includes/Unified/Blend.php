<?php
/**
 * Junção de relatórios, sem multiplicar ou somar métricas implicitamente.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Unified;

use Fator3\McpGoogle\Ability;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Blend {

	public static function register(): void {
		Ability::register(
			'google/blend',
			'any',
			array(
				'label'        => __( 'Google: combinar relatórios', 'wp-mcp-google-fator3' ),
				'description'  => __( 'Combina consultas GA4, Ads e Search Console por date, campaign ou page. Preserva linhas sem par e períodos comparados; recusa chaves duplicadas para não multiplicar métricas.', 'wp-mcp-google-fator3' ),
				'input_schema' => self::schema(),
				'callback'     => array( self::class, 'run' ),
			)
		);
	}

	/** Esquema reutilizado pela exportação. */
	public static function schema(): array {
		return array(
			'type'       => 'object',
			'properties' => array(
				'queries'            => array(
					'type'        => 'array',
					'minItems'    => 2,
					'maxItems'    => 10,
					'items'       => array( 'type' => 'object' ),
					'description' => 'Consultas google/query, com prefix opcional. Também aceita {query:{...},prefix:"ga4"}. date/campaign/page são acrescentados às dimensões quando faltam.',
				),
				'on'                 => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'string' ),
					'minItems'    => 1,
					'description' => 'Padrão ["date"]. Aceita date, campaign, page e IDs de dimensões presentes em todas as consultas.',
				),
				'join'               => array(
					'type'        => 'string',
					'enum'        => array( 'full', 'left', 'inner' ),
					'description' => 'Padrão full: conserva linhas sem par, com null nas colunas ausentes.',
				),
				'date_range'         => array(
					'type'        => array( 'string', 'object' ),
					'description' => 'Padrão de período para consultas que não informam o próprio date_range.',
				),
				'compare_date_range' => array( 'type' => array( 'string', 'object' ) ),
				'filters'            => array(
					'type'        => 'array',
					'items'       => array( 'type' => 'object' ),
					'description' => 'Filtros comuns; use filtros dentro de cada consulta para campos específicos do conector.',
				),
			),
			'required'   => array( 'queries' ),
		);
	}

	public static function run( array $input ): array {
		$gate = Gate::check( 'any' );
		if ( null !== $gate ) {
			return $gate;
		}
		$prepared = self::prepare( $input );
		if ( is_wp_error( $prepared ) ) {
			return Response::fail( $prepared );
		}
		$tables = array();
		foreach ( $prepared as $entry ) {
			$table = Query::run( $entry['query'] );
			if ( empty( $table['success'] ) ) {
				return Response::fail(
					new \WP_Error( 'f3_google_blend_query_failed', 'A consulta ' . $entry['prefix'] . ' falhou: ' . ( $table['message'] ?? 'erro sem mensagem' ) ),
					array(
						'failed_query' => $entry['prefix'],
						'query_error'  => $table,
					)
				);
			}
			$tables[] = array(
				'prefix' => $entry['prefix'],
				'table'  => $table,
			);
		}
		return self::combine( $tables, $input );
	}

	/** Valida toda a estrutura antes da primeira consulta. @return array|\WP_Error */
	private static function prepare( array $input ) {
		$queries = $input['queries'] ?? null;
		if ( ! is_array( $queries ) || count( $queries ) < 2 || count( $queries ) > 10 ) {
			return new \WP_Error( 'f3_google_blend_queries', 'Informe entre 2 e 10 consultas em queries.' );
		}
		$on = self::keys( $input );
		if ( is_wp_error( $on ) ) {
			return $on;
		}
		$prepared = array();
		$prefixes = array();
		foreach ( array_values( $queries ) as $number => $entry ) {
			if ( ! is_array( $entry ) ) {
				return new \WP_Error( 'f3_google_blend_query', 'Cada consulta deve ser um objeto.' );
			}
			$query = isset( $entry['query'] ) ? $entry['query'] : $entry;
			if ( ! is_array( $query ) ) {
				return new \WP_Error( 'f3_google_blend_query', 'query deve conter os argumentos de google/query.' );
			}
			$connector = self::connector( (string) ( $query['connector'] ?? '' ) );
			if ( '' === $connector ) {
				return new \WP_Error( 'f3_google_blend_connector', 'Informe connector ga4, google-ads ou search-console em cada consulta.' );
			}
			$prefix = (string) ( $entry['prefix'] ?? $query['prefix'] ?? $connector );
			if ( ! preg_match( '/^[A-Za-z][A-Za-z0-9_-]{0,63}$/', $prefix ) || isset( $prefixes[ $prefix ] ) ) {
				return new \WP_Error( 'f3_google_blend_prefix', 'Cada prefix deve ser único, começar por letra e conter somente letras, números, _ e -. Repita um conector usando prefixos diferentes.' );
			}
			$prefixes[ $prefix ] = true;
			unset( $query['prefix'], $query['name'] );
			$query['connector'] = $connector;
			foreach ( array( 'date_range', 'compare_date_range', 'filters' ) as $common ) {
				if ( ! isset( $query[ $common ] ) && isset( $input[ $common ] ) ) {
					$query[ $common ] = $input[ $common ];
				}
			}
			if ( empty( $query['metrics'] ) || ! is_array( $query['metrics'] ) || ! isset( $query['date_range'] ) ) {
				return new \WP_Error( 'f3_google_blend_query', 'Cada consulta exige metrics e date_range (este pode ser informado no blend).' );
			}
			$dimensions = $query['dimensions'] ?? array();
			if ( ! is_array( $dimensions ) ) {
				return new \WP_Error( 'f3_google_blend_dimensions', 'dimensions deve ser uma lista de nomes de dimensões.' );
			}
			foreach ( $on as $key ) {
				$aliases = self::aliases( $key );
				if ( array_intersect( $dimensions, $aliases ) ) {
					continue;
				}
				$native = self::native_key( $key, $connector );
				if ( null === $native ) {
					return new \WP_Error( 'f3_google_blend_key', 'A dimensão ' . $key . ' não existe no conector ' . $connector . '. Separe os blends por dimensões compatíveis.' );
				}
				$dimensions[] = $native;
			}
			$query['dimensions'] = array_values( array_unique( $dimensions ) );
			$prepared[]          = array(
				'prefix' => $prefix,
				'query'  => $query,
			);
		}
		return $prepared;
	}

	/**
	 * Função determinística de junção, compartilhada pelos testes de regressão.
	 * Cada entrada é {prefix,table}; table é a resposta real de Query::run.
	 */
	public static function combine( array $tables, array $input = array() ): array {
		$on = self::keys( $input );
		if ( is_wp_error( $on ) ) {
			return Response::fail( $on );
		}
		if ( count( $tables ) < 2 ) {
			return Response::fail( new \WP_Error( 'f3_google_blend_queries', 'A junção exige ao menos duas tabelas.' ) );
		}
		$join       = (string) ( $input['join'] ?? 'full' );
		$comparison = null;
		$periods    = null;
		$warnings   = array();
		$truncated  = false;
		$sources    = array();
		$indexes    = array();
		$output     = array();
		$keys       = array();
		$widths     = array();
		$seen       = array();

		foreach ( array_values( $tables ) as $entry ) {
			$table  = $entry['table'] ?? array();
			$prefix = (string) ( $entry['prefix'] ?? '' );
			if ( '' === $prefix || isset( $seen[ $prefix ] ) || empty( $table['success'] ) || ! isset( $table['columns'], $table['rows'] ) || ! is_array( $table['columns'] ) || ! is_array( $table['rows'] ) ) {
				return Response::fail( new \WP_Error( 'f3_google_blend_table', 'Resposta de consulta inválida ou prefixo repetido na junção.' ) );
			}
			$seen[ $prefix ] = true;
			$col_index       = array();
			foreach ( $table['columns'] as $pos => $column ) {
				if ( ! is_array( $column ) || ! isset( $column['id'] ) || isset( $col_index[ $column['id'] ] ) ) {
					return Response::fail( new \WP_Error( 'f3_google_blend_columns', 'Coluna inválida ou repetida em ' . $prefix . '.' ) );
				}
				$col_index[ $column['id'] ] = $pos;
			}
			$has_comparison = isset( $col_index['date_range_name'] );
			if ( null === $comparison ) {
				$comparison = $has_comparison;
			} elseif ( $comparison !== $has_comparison ) {
				return Response::fail( new \WP_Error( 'f3_google_blend_periods', 'Use comparação de períodos em todas as consultas do blend ou em nenhuma.' ) );
			}
			$this_periods = array( self::period( $table['date_range'] ?? null ), self::period( $table['compare_date_range'] ?? null ) );
			if ( null === $periods ) {
				$periods = $this_periods;
			} elseif ( $periods !== $this_periods ) {
				return Response::fail( new \WP_Error( 'f3_google_blend_periods', 'As consultas devem usar os mesmos intervalos de datas e de comparação.' ) );
			}
			$key_positions = array();
			if ( $comparison ) {
				$key_positions['date_range_name'] = $col_index['date_range_name'];
			}
			foreach ( $on as $key ) {
				$matches = array_values( array_intersect( self::aliases( $key ), array_keys( $col_index ) ) );
				if ( 1 !== count( $matches ) ) {
					return Response::fail( new \WP_Error( 'f3_google_blend_key', 'A chave ' . $key . ' deve corresponder a uma única dimensão em ' . $prefix . '.' ) );
				}
				$key_positions[ $key ] = $col_index[ $matches[0] ];
			}
			$extra_positions = array();
			foreach ( $table['columns'] as $pos => $column ) {
				if ( in_array( $pos, $key_positions, true ) ) {
					continue;
				}
				$extra_positions[]   = $pos;
				$column['native_id'] = $column['id'];
				$column['id']        = $prefix . '.' . $column['id'];
				$column['label']     = $prefix . ': ' . ( $column['label'] ?? $column['native_id'] );
				$column['source']    = $prefix;
				$output[]            = $column;
			}
			$index = array();
			foreach ( $table['rows'] as $row_number => $row ) {
				if ( ! is_array( $row ) || count( $row ) !== count( $table['columns'] ) || array_values( $row ) !== $row ) {
					return Response::fail( new \WP_Error( 'f3_google_blend_row', 'Linha posicional inválida em ' . $prefix . '.' ) );
				}
				$values = array();
				foreach ( $key_positions as $key => $position ) {
					$value = self::normalize( $key, $row[ $position ] );
					if ( is_wp_error( $value ) ) {
						return Response::fail(
							$value,
							array(
								'source' => $prefix,
								'row'    => $row_number + 1,
							)
						);
					}
					$values[] = $value;
				}
				$key_string = (string) wp_json_encode( $values );
				if ( isset( $index[ $key_string ] ) ) {
					return Response::fail(
						new \WP_Error( 'f3_google_blend_duplicate_key', 'Chave repetida em ' . $prefix . '. Refine on/dimensions, filtre uma conta por consulta ou agregue na origem. O blend não soma métricas nem multiplica linhas automaticamente.' ),
						array(
							'source'        => $prefix,
							'duplicate_key' => $values,
							'on'            => array_keys( $key_positions ),
						)
					);
				}
				$index[ $key_string ] = array_map(
					static function ( int $pos ) use ( $row ) {
						return $row[ $pos ];
					},
					$extra_positions
				);
				$keys[ $key_string ]  = $values;
			}
			$indexes[ $prefix ] = $index;
			$widths[ $prefix ]  = count( $extra_positions );
			$sources[]          = array(
				'prefix'             => $prefix,
				'connector'          => $table['connector'] ?? '',
				'accounts'           => $table['accounts'] ?? array(),
				'row_count'          => count( $table['rows'] ),
				'date_range'         => $table['date_range'] ?? null,
				'compare_date_range' => $table['compare_date_range'] ?? null,
			);
			foreach ( (array) ( $table['warnings'] ?? array() ) as $warning ) {
				$warnings[] = $prefix . ': ' . ( is_scalar( $warning ) ? (string) $warning : (string) wp_json_encode( $warning ) );
			}
			$truncated = $truncated || ! empty( $table['truncated'] );
		}

		$join_columns = array();
		foreach ( array_merge( $comparison ? array( 'date_range_name' ) : array(), $on ) as $key ) {
			$join_columns[] = array(
				'id'    => $key,
				'label' => $key,
				'type'  => 'dimension',
				'kind'  => 'string',
			);
		}
		$rows      = array();
		$unmatched = array_fill_keys( array_keys( $indexes ), 0 );
		$first     = array_key_first( $indexes );
		foreach ( $keys as $key => $values ) {
			$present = 0;
			foreach ( $indexes as $prefix => $index ) {
				$present += isset( $index[ $key ] ) ? 1 : 0;
			}
			if ( $present < count( $indexes ) ) {
				foreach ( $indexes as $prefix => $index ) {
					if ( isset( $index[ $key ] ) ) {
						++$unmatched[ $prefix ];
					}
				}
			}
			if ( ( 'inner' === $join && $present < count( $indexes ) ) || ( 'left' === $join && ! isset( $indexes[ $first ][ $key ] ) ) ) {
				continue;
			}
			$row = $values;
			foreach ( $indexes as $prefix => $index ) {
				$row = array_merge( $row, $index[ $key ] ?? array_fill( 0, $widths[ $prefix ], null ) );
			}
			$rows[] = $row;
		}
		foreach ( $unmatched as $prefix => $count ) {
			if ( $count > 0 ) {
				$warnings[] = $prefix . ': ' . $count . ' linha(s) sem correspondência em todas as fontes (join=' . $join . ').';
			}
		}
		if ( $truncated ) {
			$warnings[] = 'Pelo menos uma consulta foi truncada; o blend cobre somente as linhas recebidas.';
		}
		$data = array(
			'connector'     => 'blend',
			'on'            => $on,
			'join'          => $join,
			'columns'       => array_merge( $join_columns, $output ),
			'rows'          => $rows,
			'row_count'     => count( $rows ),
			'sources'       => $sources,
			'accounts'      => array_column( $sources, 'accounts', 'prefix' ),
			'date_range'    => $tables[0]['table']['date_range'] ?? null,
			'warnings'      => $warnings,
			'unmatched'     => $unmatched,
			'truncated'     => $truncated,
			'normalization' => array(
				'date'     => 'YYYY-MM-DD',
				'campaign' => 'exact, case-sensitive',
				'page'     => 'URL path; query/fragment removed; case and trailing slash preserved',
			),
		);
		if ( $comparison ) {
			$data['compare_date_range'] = $tables[0]['table']['compare_date_range'] ?? null;
		}
		return Response::ok( $data, count( $rows ) . ' linha(s) combinadas, sem agregação implícita.' );
	}

	/** @return array|\WP_Error */
	private static function keys( array $input ) {
		$keys = $input['on'] ?? array( 'date' );
		if ( ! is_array( $keys ) || empty( $keys ) || count( $keys ) > 10 ) {
			return new \WP_Error( 'f3_google_blend_keys', 'on deve conter de 1 a 10 nomes de dimensões.' );
		}
		foreach ( $keys as $key ) {
			if ( ! is_string( $key ) || '' === $key || 'date_range_name' === $key ) {
				return new \WP_Error( 'f3_google_blend_keys', 'Use nomes de dimensões em on; date_range_name é preservado automaticamente.' );
			}
		}
		if ( count( array_unique( $keys ) ) !== count( $keys ) || ! in_array( $input['join'] ?? 'full', array( 'full', 'left', 'inner' ), true ) ) {
			return new \WP_Error( 'f3_google_blend_keys', 'on não aceita repetições; join deve ser full, left ou inner.' );
		}
		return array_values( $keys );
	}

	private static function connector( string $value ): string {
		$aliases = array(
			'ga'             => 'ga4',
			'ga4'            => 'ga4',
			'analytics'      => 'ga4',
			'ads'            => 'google-ads',
			'google_ads'     => 'google-ads',
			'google-ads'     => 'google-ads',
			'gsc'            => 'search-console',
			'search_console' => 'search-console',
			'search-console' => 'search-console',
		);
		return $aliases[ strtolower( $value ) ] ?? '';
	}

	private static function aliases( string $key ): array {
		return array(
			'date'     => array( 'date', 'segments.date' ),
			'campaign' => array( 'campaign', 'campaign_name', 'campaign.name', 'sessionCampaignName' ),
			'page'     => array( 'page', 'pagePath', 'pagePathPlusQueryString', 'pageLocation' ),
		)[ $key ] ?? array( $key );
	}

	private static function native_key( string $key, string $connector ): ?string {
		if ( 'campaign' === $key ) {
			return 'ga4' === $connector ? 'sessionCampaignName' : ( 'google-ads' === $connector ? 'campaign_name' : null );
		}
		if ( 'page' === $key ) {
			return 'ga4' === $connector ? 'pagePath' : ( 'search-console' === $connector ? 'page' : null );
		}
		return $key;
	}

	/** @return string|\WP_Error */
	private static function normalize( string $key, $value ) {
		if ( ! is_scalar( $value ) || '' === (string) $value ) {
			return new \WP_Error( 'f3_google_blend_null_key', 'A chave ' . $key . ' está vazia ou inválida; filtre ou corrija a consulta antes de combinar.' );
		}
		$value = (string) $value;
		if ( 'date' === $key ) {
			if ( preg_match( '/^\d{8}$/', $value ) ) {
				$value = substr( $value, 0, 4 ) . '-' . substr( $value, 4, 2 ) . '-' . substr( $value, 6, 2 );
			}
			$date = \DateTimeImmutable::createFromFormat( '!Y-m-d', $value );
			if ( ! $date || $date->format( 'Y-m-d' ) !== $value ) {
				return new \WP_Error( 'f3_google_blend_date', 'Data de junção inválida: ' . $value . '.' );
			}
		}
		if ( 'page' === $key ) {
			if ( preg_match( '~^https?://~i', $value ) ) {
				$path  = wp_parse_url( $value, PHP_URL_PATH );
				$value = is_string( $path ) && '' !== $path ? $path : '/';
			} else {
				$value = preg_split( '/[?#]/', $value, 2 )[0];
			}
			$value = '/' . ltrim( $value, '/' );
		}
		return $value;
	}

	private static function period( $period ): ?array {
		return is_array( $period ) ? array( $period['from'] ?? null, $period['to'] ?? null ) : null;
	}
}
