<?php
/**
 * Tradução dos filtros do agente para as duas linguagens de filtro do Google.
 *
 * O agente escreve `{field: 'campaign_status', operator: 'eq', value:
 * 'ENABLED'}` — a mesma forma para os dois conectores. Do outro lado estão duas
 * gramáticas que não se parecem em nada: o GA4 usa uma árvore de expressões em
 * JSON (`andGroup`, `notExpression`, `stringFilter`, `numericFilter`) e o Google
 * Ads usa SQL (`WHERE campaign.status = ENABLED`).
 *
 * Este arquivo é onde mora o risco de injeção do plugin inteiro: valores vindos
 * do agente entram numa consulta GAQL. Por isso nada aqui concatena valor sem
 * passar por `quote()` ou por uma checagem numérica, e o nome do campo nunca
 * vem do agente cru — vem sempre da entrada do catálogo que o chamador resolveu.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Unified;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Filters {

	/** Operadores aceitos, iguais para GA4 e Google Ads. */
	public const OPERATORS = array(
		'eq',
		'neq',
		'gt',
		'gte',
		'lt',
		'lte',
		'contains',
		'ncontains',
		'begins_with',
		'ends_with',
		'in',
		'regex',
		'null',
		'notnull',
	);

	/** Operadores que não levam valor. */
	private const NO_VALUE = array( 'null', 'notnull' );

	/**
	 * Sufixos que denunciam um campo enumerado do Google Ads.
	 *
	 * Enum em GAQL vai sem aspas e em maiúsculas (`campaign.status = ENABLED`);
	 * com aspas a API responde um erro de tipo que não diz o que corrigir.
	 */
	private const ENUM_SUFFIXES = array( 'status', 'type', 'device', 'ad_network_type', 'match_type' );

	/**
	 * Normaliza a lista de filtros vinda do agente.
	 *
	 * Aceita `{field, operator, value}` e também `{field, op, value}` /
	 * `{name, operator, value}`, porque os três aparecem nos clientes MCP.
	 *
	 * @param mixed $filters Lista crua.
	 * @return array<int,array{field:string,operator:string,value:mixed}>|\WP_Error
	 */
	public static function normalize( $filters ) {
		if ( null === $filters || '' === $filters || array() === $filters ) {
			return array();
		}

		if ( ! is_array( $filters ) ) {
			return self::error( __( 'filters precisa ser uma lista de objetos {field, operator, value}.', 'wp-mcp-google-fator3' ) );
		}

		// Um filtro solto (objeto em vez de lista) é engano comum; aceita.
		if ( isset( $filters['field'] ) || isset( $filters['name'] ) ) {
			$filters = array( $filters );
		}

		$clean = array();

		foreach ( $filters as $filter ) {
			if ( ! is_array( $filter ) ) {
				return self::error( __( 'Cada filtro precisa ser um objeto {field, operator, value}.', 'wp-mcp-google-fator3' ) );
			}

			$field = '';
			foreach ( array( 'field', 'name', 'field_name', 'fieldName' ) as $key ) {
				if ( isset( $filter[ $key ] ) && is_scalar( $filter[ $key ] ) && '' !== trim( (string) $filter[ $key ] ) ) {
					$field = trim( (string) $filter[ $key ] );
					break;
				}
			}

			if ( '' === $field ) {
				return self::error( __( 'Filtro sem campo: informe field.', 'wp-mcp-google-fator3' ) );
			}

			$operator = 'eq';
			foreach ( array( 'operator', 'op', 'comparison' ) as $key ) {
				if ( isset( $filter[ $key ] ) && is_scalar( $filter[ $key ] ) && '' !== trim( (string) $filter[ $key ] ) ) {
					$operator = strtolower( trim( (string) $filter[ $key ] ) );
					break;
				}
			}

			if ( ! in_array( $operator, self::OPERATORS, true ) ) {
				return self::error(
					sprintf(
						/* translators: 1: operador recebido, 2: lista de operadores válidos. */
						__( 'Operador desconhecido: %1$s. Válidos: %2$s.', 'wp-mcp-google-fator3' ),
						$operator,
						implode( ', ', self::OPERATORS )
					)
				);
			}

			$value = $filter['value'] ?? ( $filter['values'] ?? null );

			if ( in_array( $operator, self::NO_VALUE, true ) ) {
				$value = null;
			} elseif ( 'in' === $operator ) {
				if ( is_scalar( $value ) ) {
					// 'a,b,c' é como o agente costuma mandar uma lista.
					$value = array_map( 'trim', explode( ',', (string) $value ) );
				}

				if ( ! is_array( $value ) || array() === $value ) {
					return self::error(
						sprintf(
							/* translators: %s: campo do filtro. */
							__( 'O operador in exige uma lista de valores (campo %s).', 'wp-mcp-google-fator3' ),
							$field
						)
					);
				}

				$value = array_values( $value );
			} elseif ( null === $value || is_array( $value ) ) {
				return self::error(
					sprintf(
						/* translators: %s: campo do filtro. */
						__( 'Filtro sem valor no campo %s.', 'wp-mcp-google-fator3' ),
						$field
					)
				);
			}

			$clean[] = array(
				'field'    => $field,
				'operator' => $operator,
				'value'    => $value,
			);
		}

		return $clean;
	}

	// =========================================================================
	// Google Analytics 4
	// =========================================================================

	/**
	 * Monta `dimensionFilter` e `metricFilter` do runReport.
	 *
	 * O GA4 separa os dois: filtro de métrica é aplicado depois da agregação,
	 * filtro de dimensão antes. Mandar um no lugar do outro é erro 400 com uma
	 * mensagem enigmática, então a decisão é feita aqui pela lista de métricas do
	 * próprio relatório.
	 *
	 * A decisão olha só a lista de métricas: o que não é métrica é dimensão,
	 * inclusive um campo fora do relatório (o GA4 aceita filtrar por uma
	 * dimensão que não está no `dimensions`). `$dimension_names` fica na
	 * assinatura por causa do contrato e para quem quiser conferir a lista.
	 *
	 * @param array $filters         Filtros já normalizados ou crus.
	 * @param array $dimension_names Nomes de dimensão do relatório (já traduzidos).
	 * @param array $metric_names    Nomes de métrica do relatório (já traduzidos).
	 * @return array{dimensionFilter?:array,metricFilter?:array}|\WP_Error
	 */
	public static function to_ga( array $filters, array $dimension_names, array $metric_names ) {
		$filters = self::normalize( $filters );
		if ( is_wp_error( $filters ) ) {
			return $filters;
		}

		unset( $dimension_names );

		$metric_names = array_map( 'strval', $metric_names );
		$dimensions   = array();
		$metrics      = array();

		foreach ( $filters as $filter ) {
			$field = Catalog::ga_resolve( (string) $filter['field'] );

			$expression = self::ga_expression( $field, (string) $filter['operator'], $filter['value'], in_array( $field, $metric_names, true ) );
			if ( is_wp_error( $expression ) ) {
				return $expression;
			}

			if ( in_array( $field, $metric_names, true ) ) {
				$metrics[] = $expression;
			} else {
				$dimensions[] = $expression;
			}
		}

		$out = array();

		if ( ! empty( $dimensions ) ) {
			$out['dimensionFilter'] = self::ga_group( $dimensions );
		}

		if ( ! empty( $metrics ) ) {
			$out['metricFilter'] = self::ga_group( $metrics );
		}

		return $out;
	}

	/**
	 * Uma condição só vai solta; várias entram num andGroup.
	 *
	 * @param array<int,array> $expressions Expressões.
	 */
	private static function ga_group( array $expressions ): array {
		if ( 1 === count( $expressions ) ) {
			return $expressions[0];
		}

		return array( 'andGroup' => array( 'expressions' => array_values( $expressions ) ) );
	}

	/**
	 * @param string $field    Nome do campo já traduzido para a API.
	 * @param string $operator Operador.
	 * @param mixed  $value    Valor.
	 * @param bool   $numeric  O campo é métrica (comparação numérica por padrão).
	 * @return array|\WP_Error
	 */
	// phpcs:ignore Universal.NamingConventions.NoReservedKeywordParameterNames.numericFound -- Preserva os nomes dos parâmetros da API interna existente na versão 0.1.0.
	private static function ga_expression( string $field, string $operator, $value, bool $numeric ) {
		switch ( $operator ) {
			case 'eq':
				return $numeric
					? self::ga_numeric( $field, 'EQUAL', $value )
					: self::ga_string( $field, 'EXACT', $value );

			case 'neq':
				$inner = $numeric
					? self::ga_numeric( $field, 'EQUAL', $value )
					: self::ga_string( $field, 'EXACT', $value );

				return is_wp_error( $inner ) ? $inner : array( 'notExpression' => $inner );

			case 'contains':
				return self::ga_string( $field, 'CONTAINS', $value );

			case 'ncontains':
				$inner = self::ga_string( $field, 'CONTAINS', $value );

				return is_wp_error( $inner ) ? $inner : array( 'notExpression' => $inner );

			case 'begins_with':
				return self::ga_string( $field, 'BEGINS_WITH', $value );

			case 'ends_with':
				return self::ga_string( $field, 'ENDS_WITH', $value );

			case 'regex':
				return self::ga_string( $field, 'FULL_REGEXP', $value );

			case 'in':
				return array(
					'filter' => array(
						'fieldName'    => $field,
						'inListFilter' => array(
							'values'        => array_values( array_map( 'strval', (array) $value ) ),
							'caseSensitive' => false,
						),
					),
				);

			case 'gt':
				return self::ga_numeric( $field, 'GREATER_THAN', $value );

			case 'gte':
				return self::ga_numeric( $field, 'GREATER_THAN_OR_EQUAL', $value );

			case 'lt':
				return self::ga_numeric( $field, 'LESS_THAN', $value );

			case 'lte':
				return self::ga_numeric( $field, 'LESS_THAN_OR_EQUAL', $value );

			case 'null':
				return array(
					'filter' => array(
						'fieldName'   => $field,
						'emptyFilter' => (object) array(),
					),
				);

			case 'notnull':
				return array(
					'notExpression' => array(
						'filter' => array(
							'fieldName'   => $field,
							'emptyFilter' => (object) array(),
						),
					),
				);
		}

		return self::error(
			sprintf(
				/* translators: %s: operador. */
				__( 'Operador não suportado no Google Analytics: %s.', 'wp-mcp-google-fator3' ),
				$operator
			)
		);
	}

	/**
	 * @param mixed $value Valor.
	 */
	private static function ga_string( string $field, string $match_type, $value ): array {
		return array(
			'filter' => array(
				'fieldName'    => $field,
				'stringFilter' => array(
					'matchType'     => $match_type,
					'value'         => is_scalar( $value ) ? (string) $value : '',
					// Comparação insensível por padrão: quem pede "organic"
					// espera casar com "Organic". Quem precisa do contrário usa
					// regex.
					'caseSensitive' => false,
				),
			),
		);
	}

	/**
	 * @param mixed $value Valor.
	 * @return array|\WP_Error
	 */
	private static function ga_numeric( string $field, string $operation, $value ) {
		if ( ! is_numeric( $value ) ) {
			return self::error(
				sprintf(
					/* translators: 1: campo, 2: valor recebido. */
					__( 'O campo %1$s é numérico e recebeu um valor não numérico: %2$s.', 'wp-mcp-google-fator3' ),
					$field,
					is_scalar( $value ) ? (string) $value : gettype( $value )
				)
			);
		}

		// Inteiro vira int64Value — e, na representação JSON do protobuf, int64
		// é string. Qualquer coisa com casa decimal vira doubleValue, que é
		// número mesmo.
		$number = is_int( $value ) || ( is_string( $value ) && preg_match( '/^-?\d+$/', trim( $value ) ) )
			? array( 'int64Value' => (string) (int) $value )
			: array( 'doubleValue' => (float) $value );

		return array(
			'filter' => array(
				'fieldName'     => $field,
				'numericFilter' => array(
					'operation' => $operation,
					'value'     => $number,
				),
			),
		);
	}

	// =========================================================================
	// Google Ads (GAQL)
	// =========================================================================

	/**
	 * Traduz os filtros para condições da cláusula WHERE.
	 *
	 * @param array    $filters Filtros normalizados ou crus.
	 * @param callable $resolve Recebe o id do campo e devolve a entrada do catálogo (ou WP_Error).
	 * @return array<int,string>|\WP_Error Condições prontas.
	 */
	public static function to_gaql( array $filters, callable $resolve ) {
		$filters = self::normalize( $filters );
		if ( is_wp_error( $filters ) ) {
			return $filters;
		}

		$conditions = array();

		foreach ( $filters as $filter ) {
			$entry = $resolve( (string) $filter['field'] );
			if ( is_wp_error( $entry ) ) {
				return $entry;
			}

			if ( ! is_array( $entry ) || empty( $entry['native'] ) ) {
				return self::error(
					sprintf(
						/* translators: %s: campo do filtro. */
						__( 'Não dá para filtrar por %s: é um campo calculado, sem equivalente na API.', 'wp-mcp-google-fator3' ),
						(string) $filter['field']
					)
				);
			}

			$condition = self::gaql_condition( $entry, (string) $filter['operator'], $filter['value'] );
			if ( is_wp_error( $condition ) ) {
				return $condition;
			}

			$conditions[] = $condition;
		}

		return $conditions;
	}

	/**
	 * @param array  $entry    Entrada do catálogo.
	 * @param string $operator Operador.
	 * @param mixed  $value    Valor.
	 * @return string|\WP_Error
	 */
	private static function gaql_condition( array $entry, string $operator, $value ) {
		$field = (string) $entry['native'];

		if ( 'null' === $operator ) {
			return $field . ' IS NULL';
		}

		if ( 'notnull' === $operator ) {
			return $field . ' IS NOT NULL';
		}

		if ( 'regex' === $operator ) {
			return sprintf( 'REGEXP_MATCH(%s, %s)', $field, self::quote( (string) $value ) );
		}

		if ( 'in' === $operator ) {
			$parts = array();

			foreach ( (array) $value as $item ) {
				$literal = self::literal( $entry, $item );
				if ( is_wp_error( $literal ) ) {
					return $literal;
				}

				$parts[] = $literal;
			}

			return $field . ' IN (' . implode( ', ', $parts ) . ')';
		}

		if ( in_array( $operator, array( 'contains', 'ncontains', 'begins_with', 'ends_with' ), true ) ) {
			$keyword = 'ncontains' === $operator ? 'NOT LIKE' : 'LIKE';

			return $field . ' ' . $keyword . ' ' . self::quote_like( $operator, (string) $value );
		}

		$symbols = array(
			'eq'  => '=',
			'neq' => '!=',
			'gt'  => '>',
			'gte' => '>=',
			'lt'  => '<',
			'lte' => '<=',
		);

		if ( ! isset( $symbols[ $operator ] ) ) {
			return self::error(
				sprintf(
					/* translators: %s: operador. */
					__( 'Operador não suportado no Google Ads: %s.', 'wp-mcp-google-fator3' ),
					$operator
				)
			);
		}

		$literal = self::literal( $entry, $value );
		if ( is_wp_error( $literal ) ) {
			return $literal;
		}

		return $field . ' ' . $symbols[ $operator ] . ' ' . $literal;
	}

	/**
	 * Literal GAQL para um valor, conforme o tipo do campo.
	 *
	 * Três casos e cada um quebra de um jeito diferente se errar: enum vai sem
	 * aspas e em maiúsculas; número vai sem aspas; string vai entre aspas
	 * simples com escape. Campo em moeda vira micros — quem filtra
	 * `cost > 100` quer cem reais, não cem milionésimos.
	 *
	 * @param array $entry Entrada do catálogo.
	 * @param mixed $value Valor.
	 * @return string|\WP_Error
	 */
	private static function literal( array $entry, $value ) {
		$value  = is_scalar( $value ) ? $value : '';
		$native = (string) $entry['native'];

		if ( self::is_enum( $native ) ) {
			// Enum vai sem aspas na GAQL, ou seja, o valor é concatenado cru na
			// consulta. Limpar por dentro (apagar o que não presta) produziria
			// um filtro silenciosamente diferente do pedido — `ENABLED; DELETE`
			// viraria `ENABLEDDELETE` e o agente veria "nenhuma linha" sem saber
			// por quê. Recusar é a única resposta honesta, e é também a que
			// mantém a concatenação segura.
			$candidate = strtoupper( trim( (string) $value ) );

			if ( '' === $candidate || 1 !== preg_match( '/^[A-Z0-9_]+\z/', $candidate ) ) {
				return self::error(
					sprintf(
						/* translators: 1: campo, 2: valor recebido. */
						__( 'O campo %1$s é enumerado: o valor precisa ser um identificador em MAIÚSCULAS (letras, dígitos e _), como ENABLED. Recebido: "%2$s".', 'wp-mcp-google-fator3' ),
						$native,
						is_scalar( $value ) ? (string) $value : ''
					)
				);
			}

			return $candidate;
		}

		if ( is_numeric( $value ) && ( self::is_numeric_kind( $entry ) || self::is_id_field( $native ) ) ) {
			// Campo em moeda: quem filtra `cost > 100` quer cem reais, e a API
			// compara com micros. Sem esta conversão o filtro passaria a valer
			// um décimo de milésimo de real e não filtraria nada.
			if ( ! empty( $entry['micros'] ) ) {
				return (string) (int) round( (float) $value * Catalog::MICROS );
			}

			return self::number( $value );
		}

		return self::quote( (string) $value );
	}

	private static function is_numeric_kind( array $entry ): bool {
		return in_array( (string) ( $entry['kind'] ?? 'string' ), array( 'integer', 'float', 'currency', 'percent' ), true );
	}

	/**
	 * Ids em GAQL são int64 e vão sem aspas.
	 */
	private static function is_id_field( string $native ): bool {
		$parts = explode( '.', strtolower( $native ) );
		$last  = (string) end( $parts );

		return 'id' === $last || '_id' === substr( $last, -3 );
	}

	/**
	 * Enum pelo sufixo do último segmento do campo.
	 *
	 * `campaign.status`, `ad_group_ad.ad.type`, `segments.device`,
	 * `segments.ad_network_type`, `ad_group_criterion.keyword.match_type` e
	 * `campaign.bidding_strategy_type` caem todos aqui.
	 */
	public static function is_enum( string $native ): bool {
		$parts = explode( '.', strtolower( $native ) );
		$last  = (string) end( $parts );

		foreach ( self::ENUM_SUFFIXES as $suffix ) {
			if ( $last === $suffix || substr( $last, -strlen( $suffix ) - 1 ) === '_' . $suffix ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Número sem notação científica e sem separador de milhar.
	 *
	 * @param mixed $value Valor numérico.
	 */
	private static function number( $value ): string {
		if ( is_int( $value ) || ctype_digit( ltrim( (string) $value, '-' ) ) ) {
			return (string) (int) $value;
		}

		return rtrim( rtrim( number_format( (float) $value, 6, '.', '' ), '0' ), '.' );
	}

	/**
	 * Literal já entre aspas para um LIKE, com os curingas na posição certa.
	 *
	 * A ordem do escape importa: primeiro a barra invertida e a aspa (que valem
	 * para qualquer string), depois os curingas do valor original — se o `%`
	 * fosse escapado antes, a barra do escape seria duplicada no passo seguinte
	 * e a API veria uma barra literal.
	 */
	private static function quote_like( string $operator, string $value ): string {
		$value = str_replace( '\\', '\\\\', $value );
		$value = str_replace( "'", "\\'", $value );
		$value = str_replace( array( "\r", "\n" ), ' ', $value );

		// Curingas dentro do valor viram literais: quem procura "50% off" não
		// está pedindo um curinga no meio da frase.
		$value = str_replace( array( '%', '_' ), array( '\\%', '\\_' ), $value );

		if ( 'begins_with' === $operator ) {
			return "'" . $value . "%'";
		}

		if ( 'ends_with' === $operator ) {
			return "'%" . $value . "'";
		}

		return "'%" . $value . "%'";
	}

	/**
	 * String entre aspas simples, com escape.
	 *
	 * A barra invertida é escapada antes da aspa, senão `\'` viraria `\\'` e
	 * fecharia a string mesmo assim.
	 */
	public static function quote( string $value ): string {
		$value = str_replace( '\\', '\\\\', $value );
		$value = str_replace( "'", "\\'", $value );

		// Quebra de linha dentro de um literal GAQL é erro de sintaxe.
		$value = str_replace( array( "\r", "\n" ), ' ', $value );

		return "'" . $value . "'";
	}

	private static function error( string $message ): \WP_Error {
		return new \WP_Error( 'f3_google_filter', $message );
	}
}
