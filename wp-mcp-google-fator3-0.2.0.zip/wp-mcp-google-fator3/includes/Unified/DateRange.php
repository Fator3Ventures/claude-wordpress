<?php
/**
 * Períodos nomeados, no fuso do site.
 *
 * Existe porque "últimos 30 dias" é a pergunta que o agente faz e ninguém
 * concorda sobre o que ela significa. Aqui a regra é a mesma do Porter, que é a
 * que o pessoal de mídia já tem na cabeça: `last_N_days` termina ONTEM (o dia
 * corrente ainda está sendo coletado e entraria como uma queda falsa no
 * gráfico), enquanto `today`, `this_week`, `this_month`, `this_quarter` e
 * `this_year` incluem hoje de propósito, porque quem pede "este mês" quer saber
 * como está indo agora.
 *
 * O fuso é o do WordPress (`wp_timezone()`), não o do servidor: um site
 * brasileiro num servidor em UTC vira o dia três horas cedo demais, e todo
 * relatório do começo da noite sairia com um dia a mais.
 *
 * `$today` é injetável para o autoteste e para os testes automatizados: sem
 * isso não há como afirmar nada sobre um preset sem esperar o relógio.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Unified;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class DateRange {

	/** Formato aceito e devolvido em toda data. */
	public const FORMAT = 'Y-m-d';

	/**
	 * Presets aceitos em `date_range`.
	 *
	 * @return string[]
	 */
	public static function presets(): array {
		return array(
			'today',
			'yesterday',
			'last_7_days',
			'last_14_days',
			'last_28_days',
			'last_30_days',
			'last_90_days',
			'this_week',
			'last_week',
			'this_month',
			'last_month',
			'this_quarter',
			'last_quarter',
			'this_year',
			'last_year',
		);
	}

	/**
	 * Modos aceitos em `compare_date_range`.
	 *
	 * @return string[]
	 */
	public static function comparisons(): array {
		return array( 'previous_period', 'previous_year' );
	}

	/**
	 * Resolve a especificação de período para datas concretas.
	 *
	 * Aceita, nesta ordem de preferência:
	 * - string: `'last_30_days'` (atalho para `{preset: ...}`);
	 * - array `{preset: 'last_30_days'}`;
	 * - array `{from: 'YYYY-MM-DD', to: 'YYYY-MM-DD'}` (também `start_date`/`end_date`).
	 *
	 * @param mixed                   $spec  Especificação.
	 * @param \DateTimeImmutable|null $today Dia de referência; null usa o de hoje no fuso do site.
	 * @return array{from:string,to:string,name:string}|\WP_Error
	 */
	public static function resolve( $spec, ?\DateTimeImmutable $today = null ) {
		$today = self::today( $today );

		if ( is_string( $spec ) ) {
			$spec = trim( $spec );
			if ( '' === $spec ) {
				return self::error( __( 'Informe date_range: um preset (ex.: last_30_days) ou {from, to}.', 'wp-mcp-google-fator3' ) );
			}

			$spec = array( 'preset' => $spec );
		}

		if ( ! is_array( $spec ) || array() === $spec ) {
			return self::error( __( 'date_range precisa ser um preset (ex.: last_30_days) ou um objeto {from, to}.', 'wp-mcp-google-fator3' ) );
		}

		$preset = '';
		foreach ( array( 'preset', 'name', 'range' ) as $key ) {
			if ( isset( $spec[ $key ] ) && is_string( $spec[ $key ] ) && '' !== trim( $spec[ $key ] ) ) {
				$preset = strtolower( trim( $spec[ $key ] ) );
				break;
			}
		}

		if ( '' !== $preset ) {
			return self::from_preset( $preset, $today );
		}

		$from = self::pick( $spec, array( 'from', 'start_date', 'startDate', 'start' ) );
		$to   = self::pick( $spec, array( 'to', 'end_date', 'endDate', 'end' ) );

		if ( '' === $from || '' === $to ) {
			return self::error( __( 'Período personalizado exige from e to no formato YYYY-MM-DD.', 'wp-mcp-google-fator3' ) );
		}

		return self::from_pair( $from, $to, 'custom' );
	}

	/**
	 * Resolve o período de comparação a partir do período base já resolvido.
	 *
	 * @param array                   $base  Saída de resolve().
	 * @param mixed                   $spec  'previous_period' | 'previous_year' | {from,to} | {preset}.
	 * @param \DateTimeImmutable|null $today Dia de referência.
	 * @return array{from:string,to:string,name:string}|\WP_Error
	 */
	public static function compare( array $base, $spec, ?\DateTimeImmutable $today = null ) {
		$today = self::today( $today );

		$from = self::parse( (string) ( $base['from'] ?? '' ) );
		$to   = self::parse( (string) ( $base['to'] ?? '' ) );

		if ( null === $from || null === $to ) {
			return self::error( __( 'O período base precisa estar resolvido antes de calcular a comparação.', 'wp-mcp-google-fator3' ) );
		}

		if ( is_string( $spec ) ) {
			$spec = array( 'preset' => trim( $spec ) );
		}

		if ( ! is_array( $spec ) || array() === $spec ) {
			return self::error( __( 'compare_date_range precisa ser previous_period, previous_year ou {from, to}.', 'wp-mcp-google-fator3' ) );
		}

		$mode = '';
		foreach ( array( 'preset', 'name', 'range', 'mode' ) as $key ) {
			if ( isset( $spec[ $key ] ) && is_string( $spec[ $key ] ) && '' !== trim( $spec[ $key ] ) ) {
				$mode = strtolower( trim( $spec[ $key ] ) );
				break;
			}
		}

		if ( 'previous_period' === $mode ) {
			// Mesmo número de dias, imediatamente antes do início do período
			// base. Sem isso, comparar 30 dias com 31 daria uma variação que não
			// existe.
			$days      = (int) $from->diff( $to )->days + 1;
			$prev_to   = $from->modify( '-1 day' );
			$prev_from = $prev_to->modify( '-' . ( $days - 1 ) . ' days' );

			return self::result( $prev_from, $prev_to, 'previous_period' );
		}

		if ( 'previous_year' === $mode ) {
			return self::result( $from->modify( '-1 year' ), $to->modify( '-1 year' ), 'previous_year' );
		}

		if ( '' !== $mode ) {
			// Um preset comum também serve como comparação explícita.
			if ( in_array( $mode, self::presets(), true ) ) {
				return self::from_preset( $mode, $today );
			}

			return self::error(
				sprintf(
					/* translators: %s: valor recebido. */
					__( 'Comparação desconhecida: %s. Use previous_period, previous_year, um preset ou {from, to}.', 'wp-mcp-google-fator3' ),
					$mode
				)
			);
		}

		$custom_from = self::pick( $spec, array( 'from', 'start_date', 'startDate', 'start' ) );
		$custom_to   = self::pick( $spec, array( 'to', 'end_date', 'endDate', 'end' ) );

		if ( '' === $custom_from || '' === $custom_to ) {
			return self::error( __( 'compare_date_range personalizado exige from e to no formato YYYY-MM-DD.', 'wp-mcp-google-fator3' ) );
		}

		return self::from_pair( $custom_from, $custom_to, 'custom' );
	}

	/**
	 * Hoje no fuso do site, sem hora.
	 */
	public static function today( ?\DateTimeImmutable $today = null ): \DateTimeImmutable {
		if ( $today instanceof \DateTimeImmutable ) {
			// Zera a hora: um "hoje" às 23h e outro às 01h resolveriam presets
			// diferentes por causa de aritmética de meses.
			return new \DateTimeImmutable( $today->format( self::FORMAT ), self::zone() );
		}

		return new \DateTimeImmutable( ( new \DateTimeImmutable( 'now', self::zone() ) )->format( self::FORMAT ), self::zone() );
	}

	/**
	 * @return array{from:string,to:string,name:string}|\WP_Error
	 */
	private static function from_preset( string $preset, \DateTimeImmutable $today ) {
		$yesterday = $today->modify( '-1 day' );

		switch ( $preset ) {
			case 'today':
				return self::result( $today, $today, $preset );

			case 'yesterday':
				return self::result( $yesterday, $yesterday, $preset );

			case 'last_7_days':
			case 'last_14_days':
			case 'last_28_days':
			case 'last_30_days':
			case 'last_90_days':
				$days = (int) preg_replace( '/\D+/', '', $preset );

				return self::result( $yesterday->modify( '-' . ( $days - 1 ) . ' days' ), $yesterday, $preset );

			case 'this_week':
				return self::result( self::monday( $today ), $today, $preset );

			case 'last_week':
				$monday = self::monday( $today )->modify( '-7 days' );

				return self::result( $monday, $monday->modify( '+6 days' ), $preset );

			case 'this_month':
				return self::result( self::first_of_month( $today ), $today, $preset );

			case 'last_month':
				$first = self::first_of_month( $today )->modify( '-1 month' );

				return self::result( $first, $first->modify( '+1 month' )->modify( '-1 day' ), $preset );

			case 'this_quarter':
				return self::result( self::quarter_start( $today ), $today, $preset );

			case 'last_quarter':
				$start = self::quarter_start( $today )->modify( '-3 months' );

				return self::result( $start, $start->modify( '+3 months' )->modify( '-1 day' ), $preset );

			case 'this_year':
				return self::result( self::day( (int) $today->format( 'Y' ), 1, 1 ), $today, $preset );

			case 'last_year':
				$year = (int) $today->format( 'Y' ) - 1;

				return self::result( self::day( $year, 1, 1 ), self::day( $year, 12, 31 ), $preset );
		}

		return self::error(
			sprintf(
				/* translators: 1: preset recebido, 2: lista de presets válidos. */
				__( 'Preset de data desconhecido: %1$s. Válidos: %2$s.', 'wp-mcp-google-fator3' ),
				$preset,
				implode( ', ', self::presets() )
			)
		);
	}

	/**
	 * @return array{from:string,to:string,name:string}|\WP_Error
	 */
	private static function from_pair( string $from, string $to, string $name ) {
		$start = self::parse( $from );
		$end   = self::parse( $to );

		if ( null === $start ) {
			return self::error(
				sprintf(
					/* translators: %s: valor recebido. */
					__( 'Data inicial inválida: %s. Use YYYY-MM-DD.', 'wp-mcp-google-fator3' ),
					$from
				)
			);
		}

		if ( null === $end ) {
			return self::error(
				sprintf(
					/* translators: %s: valor recebido. */
					__( 'Data final inválida: %s. Use YYYY-MM-DD.', 'wp-mcp-google-fator3' ),
					$to
				)
			);
		}

		if ( $start > $end ) {
			return self::error( __( 'A data inicial precisa ser menor ou igual à final.', 'wp-mcp-google-fator3' ) );
		}

		return self::result( $start, $end, $name );
	}

	/**
	 * Segunda-feira da semana de $day, contada pelo dia ISO.
	 *
	 * Não usa `modify( 'monday this week' )` porque a interpretação de "esta
	 * semana" muda com o dia da semana em algumas versões do PHP; o cálculo pelo
	 * número ISO é o mesmo em todas.
	 */
	private static function monday( \DateTimeImmutable $day ): \DateTimeImmutable {
		return $day->modify( '-' . ( (int) $day->format( 'N' ) - 1 ) . ' days' );
	}

	private static function quarter_start( \DateTimeImmutable $day ): \DateTimeImmutable {
		$month = ( intdiv( (int) $day->format( 'n' ) - 1, 3 ) ) * 3 + 1;

		return self::day( (int) $day->format( 'Y' ), $month, 1 );
	}

	/**
	 * Primeiro dia do mês de $day — sem aritmética relativa, que muda de
	 * comportamento quando o dia corrente não existe no mês de destino.
	 */
	private static function first_of_month( \DateTimeImmutable $day ): \DateTimeImmutable {
		return self::day( (int) $day->format( 'Y' ), (int) $day->format( 'n' ), 1 );
	}

	private static function day( int $year, int $month, int $day ): \DateTimeImmutable {
		return new \DateTimeImmutable( sprintf( '%04d-%02d-%02d', $year, $month, $day ), self::zone() );
	}

	/**
	 * Converte 'YYYY-MM-DD' em data, recusando o que o PHP aceitaria por
	 * simpatia ('2026-02-31' vira 3 de março se não conferirmos).
	 */
	private static function parse( string $value ): ?\DateTimeImmutable {
		$value = trim( $value );

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
			return null;
		}

		$date = \DateTimeImmutable::createFromFormat( '!' . self::FORMAT, $value, self::zone() );

		if ( ! $date instanceof \DateTimeImmutable || $date->format( self::FORMAT ) !== $value ) {
			return null;
		}

		return $date;
	}

	/**
	 * @param array    $spec Especificação.
	 * @param string[] $keys Nomes aceitos, em ordem de preferência.
	 */
	private static function pick( array $spec, array $keys ): string {
		foreach ( $keys as $key ) {
			if ( isset( $spec[ $key ] ) && is_scalar( $spec[ $key ] ) ) {
				$value = trim( (string) $spec[ $key ] );
				if ( '' !== $value ) {
					return $value;
				}
			}
		}

		return '';
	}

	/**
	 * @return array{from:string,to:string,name:string}
	 */
	private static function result( \DateTimeImmutable $from, \DateTimeImmutable $to, string $name ): array {
		return array(
			'from' => $from->format( self::FORMAT ),
			'to'   => $to->format( self::FORMAT ),
			'name' => $name,
		);
	}

	private static function zone(): \DateTimeZone {
		$zone = function_exists( 'wp_timezone' ) ? wp_timezone() : null;

		return $zone instanceof \DateTimeZone ? $zone : new \DateTimeZone( 'UTC' );
	}

	private static function error( string $message ): \WP_Error {
		return new \WP_Error( 'f3_google_date_range', $message );
	}
}
