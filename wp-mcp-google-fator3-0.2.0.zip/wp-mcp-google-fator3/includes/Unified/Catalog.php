<?php
/**
 * Vocabulário da camada unificada.
 *
 * O Google Ads não tem nomes amigáveis: quem quer "custo" precisa saber que o
 * campo se chama `metrics.cost_micros`, vem em milionésimos da moeda e nunca
 * aparece sozinho — precisa de um recurso na cláusula FROM. Este catálogo é a
 * tradução curada desses nomes, com o tipo de cada um, para que o agente peça
 * `cost` e receba reais.
 *
 * O Google Analytics é o caso oposto: os nomes da API já são legíveis
 * (`sessions`, `bounceRate`), então aqui só existe um punhado de apelidos para
 * as armadilhas conhecidas — `users` não é uma métrica do GA4 (é
 * `activeUsers`), `pageviews` virou `screenPageViews` na migração do Universal
 * Analytics, e `channel` é `sessionDefaultChannelGroup`. Qualquer outro nome
 * passa direto para a API, que é quem sabe o catálogo completo e o das
 * dimensões personalizadas de cada propriedade.
 *
 * O catálogo é curado de propósito: a lista viva de campos do Google Ads tem
 * milhares de entradas e não cabe num prompt. Quem precisa de um campo fora
 * daqui informa o nome nativo qualificado (`metrics.video_quartile_p75_rate`) e
 * ele é aceito do mesmo jeito — ver `ads_resolve()`.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Unified;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Catalog {

	/** Divisor dos campos em micros do Google Ads. */
	public const MICROS = 1000000;

	/** @var array<int,array>|null Catálogo montado uma vez por requisição. */
	private static ?array $ads_cache = null;

	/** @var array<string,array>|null Índice por id. */
	private static ?array $ads_by_id = null;

	/** @var array<string,array>|null Índice por nome nativo. */
	private static ?array $ads_by_native = null;

	/**
	 * Catálogo curado do Google Ads.
	 *
	 * Cada entrada: id (o nome amigável), native (o campo GAQL), type
	 * (metric|dimension), label (pt-BR), kind (integer|float|currency|percent|
	 * string|date), micros (o valor vem em milionésimos), derived (calculado no
	 * PHP) e resource_hint (recurso que o campo exige na cláusula FROM).
	 *
	 * @return array<int,array>
	 */
	public static function ads_fields(): array {
		if ( null !== self::$ads_cache ) {
			return self::$ads_cache;
		}

		$fields = array();

		// ------------------------------------------------------------------
		// Métricas
		// ------------------------------------------------------------------
		$metrics = array(
			array( 'impressions', 'metrics.impressions', 'Impressões', 'integer' ),
			array( 'clicks', 'metrics.clicks', 'Cliques', 'integer' ),
			array( 'cost', 'metrics.cost_micros', 'Custo', 'currency', true ),
			array( 'ctr', 'metrics.ctr', 'CTR (taxa de cliques)', 'percent' ),
			array( 'average_cpc', 'metrics.average_cpc', 'CPC médio', 'currency', true ),
			array( 'average_cpm', 'metrics.average_cpm', 'CPM médio', 'currency', true ),
			array( 'conversions', 'metrics.conversions', 'Conversões', 'float' ),
			array( 'conversions_value', 'metrics.conversions_value', 'Valor das conversões', 'currency' ),
			array( 'cost_per_conversion', 'metrics.cost_per_conversion', 'Custo por conversão', 'currency', true ),
			array( 'conversion_rate', 'metrics.conversions_from_interactions_rate', 'Taxa de conversão', 'percent' ),
			array( 'all_conversions', 'metrics.all_conversions', 'Todas as conversões', 'float' ),
			array( 'all_conversions_value', 'metrics.all_conversions_value', 'Valor de todas as conversões', 'currency' ),
			array( 'search_impression_share', 'metrics.search_impression_share', 'Parcela de impressões (rede de pesquisa)', 'percent' ),
			array( 'search_top_impression_share', 'metrics.search_top_impression_share', 'Parcela de impressões no topo', 'percent' ),
			array( 'absolute_top_impression_percentage', 'metrics.absolute_top_impression_percentage', 'Percentual na primeira posição', 'percent' ),
			array( 'interactions', 'metrics.interactions', 'Interações', 'integer' ),
			array( 'interaction_rate', 'metrics.interaction_rate', 'Taxa de interação', 'percent' ),
			array( 'video_views', 'metrics.video_views', 'Visualizações de vídeo', 'integer' ),
			array( 'view_through_conversions', 'metrics.view_through_conversions', 'Conversões por visualização', 'integer' ),
		);

		foreach ( $metrics as $metric ) {
			$fields[] = array(
				'id'     => $metric[0],
				'native' => $metric[1],
				'type'   => 'metric',
				'label'  => $metric[2],
				'kind'   => $metric[3],
				'micros' => ! empty( $metric[4] ?? false ),
			);
		}

		// ROAS não existe na API: é conversions_value / cost. Fica no catálogo
		// para o agente poder pedi-la pelo nome, e o Query calcula depois de
		// converter o custo de micros para a moeda da conta.
		$fields[] = array(
			'id'       => 'roas',
			'native'   => '',
			'type'     => 'metric',
			'label'    => 'ROAS (retorno sobre investimento)',
			'kind'     => 'float',
			'micros'   => false,
			'derived'  => true,
			'requires' => array( 'conversions_value', 'cost' ),
		);

		// ------------------------------------------------------------------
		// Dimensões
		// ------------------------------------------------------------------
		$dimensions = array(
			array( 'date', 'segments.date', 'Data', 'date' ),
			array( 'week', 'segments.week', 'Semana', 'date' ),
			array( 'month', 'segments.month', 'Mês', 'date' ),
			array( 'quarter', 'segments.quarter', 'Trimestre', 'date' ),
			array( 'year', 'segments.year', 'Ano', 'integer' ),
			array( 'day_of_week', 'segments.day_of_week', 'Dia da semana', 'string' ),
			array( 'device', 'segments.device', 'Dispositivo', 'string' ),
			array( 'ad_network_type', 'segments.ad_network_type', 'Rede', 'string' ),
			array( 'conversion_action_name', 'segments.conversion_action_name', 'Ação de conversão', 'string' ),
			array( 'campaign_id', 'campaign.id', 'ID da campanha', 'string', 'campaign' ),
			array( 'campaign_name', 'campaign.name', 'Campanha', 'string', 'campaign' ),
			array( 'campaign_status', 'campaign.status', 'Status da campanha', 'string', 'campaign' ),
			array( 'campaign_type', 'campaign.advertising_channel_type', 'Tipo de campanha', 'string', 'campaign' ),
			array( 'campaign_bidding_strategy_type', 'campaign.bidding_strategy_type', 'Estratégia de lances', 'string', 'campaign' ),
			array( 'campaign_budget', 'campaign_budget.amount_micros', 'Orçamento da campanha', 'currency', 'campaign', true ),
			array( 'ad_group_id', 'ad_group.id', 'ID do grupo de anúncios', 'string', 'ad_group' ),
			array( 'ad_group_name', 'ad_group.name', 'Grupo de anúncios', 'string', 'ad_group' ),
			array( 'ad_group_status', 'ad_group.status', 'Status do grupo de anúncios', 'string', 'ad_group' ),
			array( 'ad_id', 'ad_group_ad.ad.id', 'ID do anúncio', 'string', 'ad_group_ad' ),
			array( 'ad_name', 'ad_group_ad.ad.name', 'Anúncio', 'string', 'ad_group_ad' ),
			array( 'ad_type', 'ad_group_ad.ad.type', 'Tipo de anúncio', 'string', 'ad_group_ad' ),
			array( 'ad_status', 'ad_group_ad.status', 'Status do anúncio', 'string', 'ad_group_ad' ),
			array( 'keyword', 'ad_group_criterion.keyword.text', 'Palavra-chave', 'string', 'keyword_view' ),
			array( 'keyword_match_type', 'ad_group_criterion.keyword.match_type', 'Correspondência da palavra-chave', 'string', 'keyword_view' ),
			array( 'search_term', 'search_term_view.search_term', 'Termo de pesquisa', 'string', 'search_term_view' ),
			array( 'geo_country', 'geographic_view.country_criterion_id', 'País (critério geográfico)', 'string', 'geographic_view' ),
			array( 'account_id', 'customer.id', 'ID da conta', 'string' ),
			array( 'account_name', 'customer.descriptive_name', 'Conta', 'string' ),
			array( 'currency', 'customer.currency_code', 'Moeda', 'string' ),
		);

		foreach ( $dimensions as $dimension ) {
			$entry = array(
				'id'     => $dimension[0],
				'native' => $dimension[1],
				'type'   => 'dimension',
				'label'  => $dimension[2],
				'kind'   => $dimension[3],
				'micros' => ! empty( $dimension[5] ?? false ),
			);

			if ( ! empty( $dimension[4] ?? false ) ) {
				$entry['resource_hint'] = (string) $dimension[4];
			}

			$fields[] = $entry;
		}

		/**
		 * Permite acrescentar campos ao catálogo curado sem editar o plugin.
		 *
		 * @param array $fields Entradas do catálogo.
		 */
		$fields = apply_filters( 'f3_mcp_google_ads_catalog', $fields );

		self::$ads_cache     = is_array( $fields ) ? array_values( $fields ) : array();
		self::$ads_by_id     = null;
		self::$ads_by_native = null;

		return self::$ads_cache;
	}

	/**
	 * Resolve um campo do Google Ads: id do catálogo ou nome nativo qualificado.
	 *
	 * Aceitar o nativo é o que impede o catálogo de virar uma gaiola: a API tem
	 * milhares de campos e nenhum catálogo curado acompanha. Um nome
	 * desconhecido, desde que pareça um identificador GAQL, é sintetizado — se
	 * não existir mesmo, quem recusa é a Google, com uma mensagem melhor do que
	 * a que este arquivo poderia dar.
	 *
	 * @param string $id Id amigável ou nome nativo.
	 * @return array|\WP_Error Entrada do catálogo.
	 */
	public static function ads_resolve( string $id ) {
		$id = trim( $id );

		if ( '' === $id ) {
			return new \WP_Error( 'f3_google_field', __( 'Campo vazio na lista de métricas ou dimensões.', 'wp-mcp-google-fator3' ) );
		}

		$by_id = self::ads_index_by_id();
		$key   = strtolower( $id );

		if ( isset( $by_id[ $key ] ) ) {
			return $by_id[ $key ];
		}

		$by_native = self::ads_index_by_native();
		if ( isset( $by_native[ $key ] ) ) {
			return $by_native[ $key ];
		}

		// Nativo desconhecido: precisa ser qualificado (tem ponto) e ter forma
		// de identificador GAQL. Sem o ponto seria um id errado do catálogo, e
		// dizer isso ajuda mais do que mandar a Google recusar.
		if ( false !== strpos( $key, '.' ) && self::identifier_ok( $key ) ) {
			return array(
				'id'     => $key,
				'native' => $key,
				'type'   => 0 === strpos( $key, 'metrics.' ) ? 'metric' : 'dimension',
				'label'  => $key,
				'kind'   => 0 === strpos( $key, 'metrics.' ) ? 'float' : 'string',
				'micros' => (bool) preg_match( '/_micros$/', $key ),
			);
		}

		return new \WP_Error(
			'f3_google_field',
			sprintf(
				/* translators: %s: campo informado. */
				__( 'Campo desconhecido no Google Ads: %s. Use um id do catálogo (google/list-fields) ou o nome nativo qualificado, como metrics.clicks.', 'wp-mcp-google-fator3' ),
				$id
			)
		);
	}

	/**
	 * Entrada do catálogo para um nome nativo, ou null.
	 *
	 * Serve para o caminho de volta: a linha da API vem indexada pelo nativo e a
	 * coluna precisa sair com o id amigável.
	 */
	public static function ads_by_native( string $native ): ?array {
		$index = self::ads_index_by_native();

		return $index[ strtolower( trim( $native ) ) ] ?? null;
	}

	/**
	 * Apelidos do GA4.
	 *
	 * Curto de propósito: só o que muda de nome entre o que as pessoas dizem e
	 * o que a API aceita. O resto vai como veio.
	 *
	 * @return array<string,string>
	 */
	public static function ga_aliases(): array {
		$aliases = array(
			'users'                => 'activeUsers',
			'pageviews'            => 'screenPageViews',
			'page_views'           => 'screenPageViews',
			'cost'                 => 'advertiserAdCost',
			'conversions'          => 'conversions',
			'revenue'              => 'totalRevenue',
			'bounce_rate'          => 'bounceRate',
			'engagement_rate'      => 'engagementRate',
			'avg_session_duration' => 'averageSessionDuration',
			'channel'              => 'sessionDefaultChannelGroup',
			'source_medium'        => 'sessionSourceMedium',
			'landing_page'         => 'landingPage',
			'page'                 => 'pagePath',
			'country'              => 'country',
			'device'               => 'deviceCategory',
			'date'                 => 'date',
		);

		/**
		 * Permite acrescentar apelidos do GA4.
		 *
		 * @param array $aliases Mapa apelido => nome da API.
		 */
		$aliases = apply_filters( 'f3_mcp_google_ga_aliases', $aliases );

		return is_array( $aliases ) ? $aliases : array();
	}

	/**
	 * Traduz um nome pedido pelo agente para o nome da API do GA4.
	 */
	public static function ga_resolve( string $name ): string {
		$name    = trim( $name );
		$aliases = self::ga_aliases();

		return $aliases[ $name ] ?? ( $aliases[ strtolower( $name ) ] ?? $name );
	}

	/**
	 * Limpa os índices — só os testes precisam, depois de mexer no filtro.
	 */
	public static function flush(): void {
		self::$ads_cache     = null;
		self::$ads_by_id     = null;
		self::$ads_by_native = null;
	}

	/**
	 * @return array<string,array>
	 */
	private static function ads_index_by_id(): array {
		if ( null === self::$ads_by_id ) {
			$index = array();

			foreach ( self::ads_fields() as $field ) {
				$index[ strtolower( (string) $field['id'] ) ] = $field;
			}

			self::$ads_by_id = $index;
		}

		return self::$ads_by_id;
	}

	/**
	 * @return array<string,array>
	 */
	private static function ads_index_by_native(): array {
		if ( null === self::$ads_by_native ) {
			$index = array();

			foreach ( self::ads_fields() as $field ) {
				$native = strtolower( (string) $field['native'] );

				// Campos derivados não têm nativo; não entram neste índice.
				if ( '' !== $native && ! isset( $index[ $native ] ) ) {
					$index[ $native ] = $field;
				}
			}

			self::$ads_by_native = $index;
		}

		return self::$ads_by_native;
	}

	/**
	 * Forma de identificador GAQL.
	 *
	 * Delega ao módulo do Ads quando ele está carregado (é ele quem manda no
	 * assunto) e cai numa cópia da mesma regra quando não está — este arquivo
	 * precisa funcionar com o conector Ads ausente.
	 */
	private static function identifier_ok( string $value ): bool {
		if ( class_exists( '\\Fator3\\McpGoogle\\Ads\\Gaql' )
			&& method_exists( '\\Fator3\\McpGoogle\\Ads\\Gaql', 'identifier_ok' ) ) {
			return (bool) \Fator3\McpGoogle\Ads\Gaql::identifier_ok( $value );
		}

		// `\z` e não `$` — ver a nota em Gaql::identifier_ok(): `$` aceitaria uma
		// quebra de linha no fim do identificador.
		return (bool) preg_match( '/^[a-z][a-z0-9_.]*\z/', $value );
	}
}
