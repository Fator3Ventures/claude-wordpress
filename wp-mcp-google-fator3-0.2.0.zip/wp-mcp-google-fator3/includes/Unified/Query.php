<?php
/**
 * O motor de `google/query`, `google/list-accounts` e `google/list-fields`.
 *
 * A camada `ga/*` e a `ads/*` existem para quem sabe exatamente o que quer: elas
 * são a API do Google com um verniz de WordPress. Esta aqui é para o outro caso,
 * o mais comum — o agente sabe a pergunta de negócio ("custo por campanha no mês
 * passado") e não sabe que o campo se chama `metrics.cost_micros`, que ele só
 * existe junto de um recurso na cláusula FROM, nem que o GA4 chama sessão por
 * canal de `sessionDefaultChannelGroup`.
 *
 * Três decisões moldam o arquivo:
 *
 * 1. **As colunas saem numa ordem previsível**, e diferente da do Porter:
 *    primeiro os eixos (período comparado, conta), depois as DIMENSÕES na ordem
 *    pedida, depois as MÉTRICAS na ordem pedida. Uma tabela onde a métrica vem
 *    antes da dimensão que a explica é ilegível para quem lê a resposta.
 *
 * 2. **Uma conta que falha não derruba o relatório.** Quem pede cinco contas
 *    quase sempre prefere quatro respostas e um aviso a um erro só. O erro da
 *    conta que falhou vai inteiro para `warnings`.
 *
 * 3. **Número volta como número.** A Google Ads devolve custo em micros e o GA4
 *    devolve tudo como string; deixar assim faz o agente somar textos.
 *
 * @package Fator3\McpGoogle
 */

declare(strict_types=1);

namespace Fator3\McpGoogle\Unified;

use Fator3\McpGoogle\Ads\AdsApi;
use Fator3\McpGoogle\Ads\CustomerId;
use Fator3\McpGoogle\Ads\Gaql;
use Fator3\McpGoogle\Analytics\AdminApi;
use Fator3\McpGoogle\Analytics\DataApi;
use Fator3\McpGoogle\Analytics\PropertyId;
use Fator3\McpGoogle\Gate;
use Fator3\McpGoogle\Options;
use Fator3\McpGoogle\Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Query {

	/** Nome do período principal nas duas APIs. */
	public const RANGE_CURRENT = 'current';

	/** Nome do período de comparação. */
	public const RANGE_PREVIOUS = 'previous';

	/** Prefixo do transient com a lista de contas. */
	public const ACCOUNTS_CACHE = 'f3_mcp_google_accounts_';

	/** Validade do cache de contas: 10 minutos. */
	public const ACCOUNTS_TTL = 600;

	/**
	 * Teto de contas por chamada de `google/query`.
	 *
	 * `accounts` vem do agente e o laço que a percorre faz uma chamada à Google
	 * por conta (duas, com comparação de período). Sem teto, uma lista de
	 * trezentas contas viraria seiscentas requisições dentro de um único
	 * request do WordPress — tempo limite do PHP, cota queimada e nenhuma
	 * resposta. Vinte e cinco é o mesmo teto de `ads/list-accessible-customers`.
	 */
	public const MAX_ACCOUNTS = 25;

	// =========================================================================
	// google/query
	// =========================================================================

	/**
	 * @param array $input Entrada da habilidade.
	 * @return array Resposta pronta (Response::ok/fail).
	 */
	public static function run( array $input ): array {
		$connector = self::connector( $input['connector'] ?? '' );
		if ( 'search-console' === $connector ) {
			return \Fator3\McpGoogle\SearchConsole\Api::unified( $input );
		}
		if ( 'google-ads' === $connector ) {
			$metrics = self::string_list( $input['metrics'] ?? array() );
			foreach ( $metrics as $metric ) {
				if ( preg_match( '/^conversions(?:_value)?:/', $metric ) ) {
					return \Fator3\McpGoogle\Ads\Conversions::query( $input );
				}
			}
		}
		$plan = self::plan( $input );
		if ( is_wp_error( $plan ) ) {
			return Response::fail( $plan );
		}

		$gate = Gate::check( $plan['gate'] );
		if ( null !== $gate ) {
			return $gate;
		}

		return 'ga' === $plan['gate'] ? self::run_ga( $plan ) : self::run_ads( $plan );
	}

	/**
	 * Monta a consulta sem executá-la.
	 *
	 * É o que o autoteste usa para provar, sem rede, que um `google/query` de
	 * exemplo vira o corpo GA e a GAQL esperados.
	 *
	 * @param array $input Entrada da habilidade.
	 * @return array|\WP_Error
	 */
	public static function preview( array $input ) {
		$plan = self::plan( $input );
		if ( is_wp_error( $plan ) ) {
			return $plan;
		}

		$out = array(
			'connector'          => $plan['connector'],
			'date_range'         => $plan['range'],
			'compare_date_range' => $plan['compare'],
			'columns'            => self::columns( $plan ),
		);

		if ( 'ga' === $plan['gate'] ) {
			$body = self::ga_body( $plan );
			if ( is_wp_error( $body ) ) {
				return $body;
			}

			$out['ga_body'] = $body;

			return $out;
		}

		$query = self::ads_query( $plan, $plan['range'] );
		if ( is_wp_error( $query ) ) {
			return $query;
		}

		$out['resource'] = $plan['resource'];
		$out['gaql']     = $query;

		return $out;
	}

	// =========================================================================
	// Plano
	// =========================================================================

	/**
	 * Valida e normaliza a entrada inteira antes de qualquer chamada de rede.
	 *
	 * @param array $input Entrada crua.
	 * @return array|\WP_Error
	 */
	private static function plan( array $input ) {
		$connector = self::connector( $input['connector'] ?? '' );
		if ( is_wp_error( $connector ) ) {
			return $connector;
		}

		if ( 'all' === $connector ) {
			return new \WP_Error(
				'f3_google_query_connector',
				__( 'google/query pede um conector por vez: ga4, google-ads ou search-console. Os dois têm métricas diferentes e não se somam numa tabela só.', 'wp-mcp-google-fator3' )
			);
		}

		$gate = 'ga4' === $connector ? 'ga' : 'ads';

		$accounts = self::string_list( $input['accounts'] ?? ( $input['account_id'] ?? null ) );
		if ( empty( $accounts ) ) {
			return new \WP_Error(
				'f3_google_query_accounts',
				'ga4' === $connector
					? __( 'Informe accounts: uma ou mais propriedades do GA4 (ex.: "properties/123456").', 'wp-mcp-google-fator3' )
					: __( 'Informe accounts: uma ou mais contas do Google Ads (ex.: "123-456-7890").', 'wp-mcp-google-fator3' )
			);
		}

		$wildcard = in_array( '*', $accounts, true );
		$accounts = Accounts::resolve_many( $connector, $accounts );
		if ( is_wp_error( $accounts ) ) {
			return $accounts; }
		$dropped = 0;
		if ( ! $wildcard && count( $accounts ) > self::MAX_ACCOUNTS ) {
			$dropped  = count( $accounts ) - self::MAX_ACCOUNTS;
			$accounts = array_slice( $accounts, 0, self::MAX_ACCOUNTS );
		}

		$metric_names    = self::string_list( $input['metrics'] ?? null );
		$dimension_names = self::string_list( $input['dimensions'] ?? null );

		if ( empty( $metric_names ) ) {
			return new \WP_Error(
				'f3_google_query_metrics',
				__( 'Informe ao menos uma métrica em metrics. Use google/list-fields para descobrir os nomes.', 'wp-mcp-google-fator3' )
			);
		}

		$metrics = self::resolve_fields( $metric_names, $gate, 'metric' );
		if ( is_wp_error( $metrics ) ) {
			return $metrics;
		}

		$dimensions = self::resolve_fields( $dimension_names, $gate, 'dimension' );
		if ( is_wp_error( $dimensions ) ) {
			return $dimensions;
		}

		$range = DateRange::resolve( $input['date_range'] ?? null );
		if ( is_wp_error( $range ) ) {
			return $range;
		}

		$compare = null;
		if ( ! empty( $input['compare_date_range'] ) ) {
			$compare = DateRange::compare( $range, $input['compare_date_range'] );
			if ( is_wp_error( $compare ) ) {
				return $compare;
			}
		}

		$filters = Filters::normalize( $input['filters'] ?? array() );
		if ( is_wp_error( $filters ) ) {
			return $filters;
		}

		$order_by = self::order_by( $input['order_by'] ?? ( $input['order_bys'] ?? array() ) );
		if ( is_wp_error( $order_by ) ) {
			return $order_by;
		}

		$max   = Options::max_rows();
		$limit = $max;

		if ( isset( $input['limit'] ) && '' !== $input['limit'] ) {
			// Recusa em vez de silenciosamente virar o padrão: quem pede
			// `limit: 0` e recebe mil linhas não tem como perceber o engano.
			$number = is_numeric( $input['limit'] ) ? (float) $input['limit'] : 0.0;

			if ( ! is_numeric( $input['limit'] ) || 1 > $number || floor( $number ) !== $number ) {
				return new \WP_Error(
					'f3_google_bad_limit',
					__( 'limit precisa ser um número inteiro maior que zero.', 'wp-mcp-google-fator3' )
				);
			}

			$limit = (int) min( $max, (int) $input['limit'] );
		}

		$plan = array(
			'connector'  => $connector,
			'gate'       => $gate,
			'accounts'   => $accounts,
			'dropped'    => $dropped,
			'metrics'    => $metrics,
			'dimensions' => $dimensions,
			'range'      => $range,
			'compare'    => $compare,
			'filters'    => $filters,
			'order_by'   => $order_by,
			'limit'      => $limit,
			'resource'   => '',
		);

		if ( 'ads' === $gate ) {
			$resource = self::ads_resource_for( $plan, $input['resource'] ?? '' );
			if ( is_wp_error( $resource ) ) {
				return $resource;
			}

			$plan['resource'] = $resource;
		}

		return $plan;
	}

	/**
	 * 'ga4' | 'google-ads' | 'all', tolerando os apelidos que os agentes usam.
	 *
	 * @param mixed $value Valor recebido.
	 * @return string|\WP_Error
	 */
	public static function connector( $value ) {
		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';

		$map = array(
			'ga4'              => 'ga4',
			'ga'               => 'ga4',
			'analytics'        => 'ga4',
			'google-analytics' => 'ga4',
			'google_analytics' => 'ga4',
			'google-ads'       => 'google-ads',
			'google_ads'       => 'google-ads',
			'googleads'        => 'google-ads',
			'ads'              => 'google-ads',
			'adwords'          => 'google-ads',
			'gsc'              => 'search-console',
			'search-console'   => 'search-console',
			'search_console'   => 'search-console',
			'google-search'    => 'search-console',
			'all'              => 'all',
			''                 => 'all',
		);

		if ( isset( $map[ $value ] ) ) {
			return $map[ $value ];
		}

		return new \WP_Error(
			'f3_google_connector',
			sprintf(
				/* translators: %s: valor recebido. */
				__( 'Conector desconhecido: %s. Use ga4, google-ads ou search-console.', 'wp-mcp-google-fator3' ),
				$value
			)
		);
	}

	/**
	 * Resolve nomes de campo para entradas com id, nativo, tipo e kind.
	 *
	 * @param string[] $names Nomes pedidos.
	 * @param string   $gate  'ga' | 'ads'.
	 * @param string   $type  'metric' | 'dimension'.
	 * @return array<int,array>|\WP_Error
	 */
	private static function resolve_fields( array $names, string $gate, string $type ) {
		$out  = array();
		$seen = array();

		foreach ( $names as $name ) {
			if ( isset( $seen[ strtolower( $name ) ] ) ) {
				continue;
			}
			$seen[ strtolower( $name ) ] = true;

			if ( 'ads' === $gate ) {
				$entry = Catalog::ads_resolve( $name );
				if ( is_wp_error( $entry ) ) {
					return $entry;
				}

				// Um campo do catálogo pedido no lugar errado (dimensão em
				// metrics) só produziria uma GAQL que a Google recusa; dizer
				// aqui é mais barato e mais claro.
				if ( $entry['type'] !== $type ) {
					return new \WP_Error(
						'f3_google_field_type',
						sprintf(
							/* translators: 1: campo, 2: lista onde deveria estar. */
							__( 'O campo %1$s é uma %2$s — mova-o para a lista certa.', 'wp-mcp-google-fator3' ),
							$name,
							'metric' === $entry['type'] ? __( 'métrica', 'wp-mcp-google-fator3' ) : __( 'dimensão', 'wp-mcp-google-fator3' )
						)
					);
				}

				// O id pedido é o que sai na coluna: quem perguntou por `cost`
				// não quer ler `metrics.cost_micros` no cabeçalho.
				$entry['id'] = $name;
				$out[]       = $entry;

				continue;
			}

			$out[] = array(
				'id'     => $name,
				'native' => Catalog::ga_resolve( $name ),
				'type'   => $type,
				'label'  => $name,
				'kind'   => 'metric' === $type ? 'float' : 'string',
				'micros' => false,
			);
		}

		return $out;
	}

	/**
	 * @param mixed $value Lista crua de ordenações.
	 * @return array<int,array{field:string,direction:string}>|\WP_Error
	 */
	private static function order_by( $value ) {
		if ( null === $value || '' === $value || array() === $value ) {
			return array();
		}

		if ( is_string( $value ) ) {
			$value = array( array( 'field' => $value ) );
		}

		if ( ! is_array( $value ) ) {
			return new \WP_Error( 'f3_google_order_by', __( 'order_by precisa ser uma lista de {field, direction}.', 'wp-mcp-google-fator3' ) );
		}

		if ( isset( $value['field'] ) ) {
			$value = array( $value );
		}

		$out = array();

		foreach ( $value as $item ) {
			if ( is_string( $item ) ) {
				$item = array( 'field' => $item );
			}

			if ( ! is_array( $item ) || empty( $item['field'] ) || ! is_scalar( $item['field'] ) ) {
				return new \WP_Error( 'f3_google_order_by', __( 'Cada ordenação precisa de field.', 'wp-mcp-google-fator3' ) );
			}

			$direction = isset( $item['direction'] ) && is_scalar( $item['direction'] )
				? strtolower( trim( (string) $item['direction'] ) )
				: 'desc';

			if ( ! in_array( $direction, array( 'asc', 'desc' ), true ) ) {
				return new \WP_Error(
					'f3_google_order_by',
					sprintf(
						/* translators: %s: direção recebida. */
						__( 'Direção de ordenação inválida: %s. Use asc ou desc.', 'wp-mcp-google-fator3' ),
						$direction
					)
				);
			}

			$out[] = array(
				'field'     => trim( (string) $item['field'] ),
				'direction' => $direction,
			);
		}

		return $out;
	}

	/**
	 * Colunas na ordem da casa: eixos, dimensões, métricas.
	 *
	 * @param array $plan Plano.
	 * @return array<int,array{id:string,label:string,type:string,kind:string}>
	 */
	private static function columns( array $plan ): array {
		$columns = array();

		if ( null !== $plan['compare'] ) {
			$columns[] = array(
				'id'    => 'date_range_name',
				'label' => __( 'Período', 'wp-mcp-google-fator3' ),
				'type'  => 'meta',
				'kind'  => 'string',
			);
		}

		if ( count( $plan['accounts'] ) > 1 ) {
			$columns[] = array(
				'id'    => 'account_id',
				'label' => __( 'ID da conta', 'wp-mcp-google-fator3' ),
				'type'  => 'meta',
				'kind'  => 'string',
			);
			$columns[] = array(
				'id'    => 'account_name',
				'label' => __( 'Conta', 'wp-mcp-google-fator3' ),
				'type'  => 'meta',
				'kind'  => 'string',
			);
		}

		foreach ( array( $plan['dimensions'], $plan['metrics'] ) as $group ) {
			foreach ( $group as $field ) {
				$columns[] = array(
					'id'    => (string) $field['id'],
					'label' => (string) ( $field['label'] ?? $field['id'] ),
					'type'  => (string) $field['type'],
					'kind'  => (string) ( $field['kind'] ?? 'string' ),
				);
			}
		}

		return $columns;
	}

	// =========================================================================
	// Google Analytics 4
	// =========================================================================

	/**
	 * @param array $plan Plano.
	 * @return array Resposta pronta.
	 */
	private static function run_ga( array $plan ): array {
		$body = self::ga_body( $plan );
		if ( is_wp_error( $body ) ) {
			return Response::fail( $body );
		}

		$columns   = self::columns( $plan );
		$rows      = array();
		$warnings  = self::initial_warnings( $plan );
		$accounts  = array();
		$truncated = false;
		$multi     = count( $plan['accounts'] ) > 1;

		foreach ( $plan['accounts'] as $account ) {
			$property = PropertyId::normalize( $account );
			if ( is_wp_error( $property ) ) {
				$warnings[] = self::account_warning( $account, $property );
				continue;
			}

			$name = self::account_name( 'ga', $property );

			$response = DataApi::run_report( $property, $body );
			if ( is_wp_error( $response ) ) {
				$warnings[] = self::account_warning( $property, $response );
				continue;
			}

			// A conta só entra na lista depois de responder: assim uma resposta
			// sem nenhuma linha e sem nenhuma conta viva é reportada como falha,
			// e não como "zero cliques".
			$accounts[] = array(
				'account_id' => $property,
				'name'       => $name,
			);

			$table = DataApi::to_table( $response );

			if ( ! empty( $table['truncated'] ) ) {
				$truncated = true;
			}

			$index = self::index_of( isset( $table['columns'] ) && is_array( $table['columns'] ) ? $table['columns'] : array() );

			foreach ( $table['rows'] as $raw ) {
				$row = array();

				if ( null !== $plan['compare'] ) {
					$row[] = isset( $index['dateRange'] ) ? (string) ( $raw[ $index['dateRange'] ] ?? '' ) : self::RANGE_CURRENT;
				}

				if ( $multi ) {
					$row[] = $property;
					$row[] = $name;
				}

				foreach ( $plan['dimensions'] as $dimension ) {
					$position = $index[ $dimension['native'] ] ?? null;
					$row[]    = self::ga_dimension_value( (string) $dimension['native'], null === $position ? '' : ( $raw[ $position ] ?? '' ) );
				}

				foreach ( $plan['metrics'] as $metric ) {
					$position = $index[ $metric['native'] ] ?? null;
					$value    = null === $position ? null : ( $raw[ $position ] ?? null );
					$row[]    = is_numeric( $value ) ? $value + 0 : $value;
				}

				$rows[] = $row;
			}
		}

		return self::result(
			$plan,
			$columns,
			$rows,
			$accounts,
			$warnings,
			$truncated,
			array(
				'connector' => 'ga4',
				'ga_body'   => $body,
			)
		);
	}

	/**
	 * Corpo do `runReport`.
	 *
	 * @param array $plan Plano.
	 * @return array|\WP_Error
	 */
	private static function ga_body( array $plan ) {
		$ranges = array(
			array(
				'startDate' => $plan['range']['from'],
				'endDate'   => $plan['range']['to'],
				'name'      => self::RANGE_CURRENT,
			),
		);

		if ( null !== $plan['compare'] ) {
			$ranges[] = array(
				'startDate' => $plan['compare']['from'],
				'endDate'   => $plan['compare']['to'],
				'name'      => self::RANGE_PREVIOUS,
			);
		}

		$dimensions = array();
		foreach ( $plan['dimensions'] as $dimension ) {
			$dimensions[] = array( 'name' => (string) $dimension['native'] );
		}

		$metrics = array();
		foreach ( $plan['metrics'] as $metric ) {
			$metrics[] = array( 'name' => (string) $metric['native'] );
		}

		$body = array(
			'dateRanges' => $ranges,
			'dimensions' => $dimensions,
			'metrics'    => $metrics,
		);

		if ( ! empty( $plan['filters'] ) ) {
			$translated = Filters::to_ga(
				$plan['filters'],
				self::natives( $plan['dimensions'] ),
				self::natives( $plan['metrics'] )
			);

			if ( is_wp_error( $translated ) ) {
				return $translated;
			}

			$body = array_merge( $body, $translated );
		}

		$order_bys = array();
		foreach ( $plan['order_by'] as $ordering ) {
			$field  = Catalog::ga_resolve( $ordering['field'] );
			$is_dim = in_array( $field, self::natives( $plan['dimensions'] ), true );
			$entry  = $is_dim
				? array( 'dimension' => array( 'dimensionName' => $field ) )
				: array( 'metric' => array( 'metricName' => $field ) );

			if ( 'desc' === $ordering['direction'] ) {
				$entry['desc'] = true;
			}

			$order_bys[] = $entry;
		}

		if ( ! empty( $order_bys ) ) {
			$body['orderBys'] = $order_bys;
		}

		$body['limit'] = $plan['limit'];

		return $body;
	}

	/**
	 * A dimensão `date` do GA4 volta como `20260904`; sai daqui como
	 * `2026-09-04`, igual ao `segments.date` do Google Ads. Sem isso a mesma
	 * pergunta feita nos dois conectores devolveria datas em formatos
	 * diferentes.
	 *
	 * @param string $native Nome da dimensão na API.
	 * @param mixed  $value  Valor cru.
	 */
	private static function ga_dimension_value( string $native, $value ): string {
		$value = is_scalar( $value ) ? (string) $value : '';

		if ( 'date' === $native && 1 === preg_match( '/^(\d{4})(\d{2})(\d{2})$/', $value, $parts ) ) {
			return $parts[1] . '-' . $parts[2] . '-' . $parts[3];
		}

		return $value;
	}

	// =========================================================================
	// Google Ads
	// =========================================================================

	/**
	 * @param array $plan Plano.
	 * @return array Resposta pronta.
	 */
	private static function run_ads( array $plan ): array {
		$queries = array( self::RANGE_CURRENT => self::ads_query( $plan, $plan['range'] ) );

		if ( null !== $plan['compare'] ) {
			$queries[ self::RANGE_PREVIOUS ] = self::ads_query( $plan, $plan['compare'] );
		}

		foreach ( $queries as $query ) {
			if ( is_wp_error( $query ) ) {
				return Response::fail( $query );
			}
		}

		$columns   = self::columns( $plan );
		$rows      = array();
		$warnings  = self::initial_warnings( $plan );
		$accounts  = array();
		$truncated = false;
		$multi     = count( $plan['accounts'] ) > 1;

		foreach ( $plan['accounts'] as $account ) {
			$customer = CustomerId::normalize( $account );
			if ( is_wp_error( $customer ) ) {
				$warnings[] = self::account_warning( $account, $customer );
				continue;
			}

			$name   = self::account_name( 'ads', $customer );
			$listed = false;

			foreach ( $queries as $range_name => $query ) {
				$result = AdsApi::search( $customer, $query, array( 'max_rows' => $plan['limit'] ) );

				if ( is_wp_error( $result ) ) {
					$warnings[] = self::account_warning( $customer, $result );
					continue;
				}

				// A conta só entra na lista depois de responder: assim uma
				// resposta sem nenhuma linha e sem nenhuma conta viva é
				// reportada como falha, e não como "zero cliques".
				if ( ! $listed ) {
					$listed     = true;
					$accounts[] = array(
						'account_id' => $customer,
						'name'       => $name,
					);
				}

				if ( ! empty( $result['truncated'] ) ) {
					$truncated = true;
				}

				foreach ( $result['rows'] as $raw ) {
					$row = array();

					if ( null !== $plan['compare'] ) {
						$row[] = $range_name;
					}

					if ( $multi ) {
						$row[] = $customer;
						$row[] = $name;
					}

					foreach ( $plan['dimensions'] as $dimension ) {
						$row[] = self::ads_value( $dimension, $raw );
					}

					foreach ( $plan['metrics'] as $metric ) {
						$row[] = self::ads_value( $metric, $raw );
					}

					$rows[] = $row;
				}
			}
		}

		return self::result(
			$plan,
			$columns,
			$rows,
			$accounts,
			$warnings,
			$truncated,
			array(
				'connector' => 'google-ads',
				'resource'  => $plan['resource'],
				'gaql'      => $queries[ self::RANGE_CURRENT ],
			)
		);
	}

	/**
	 * Monta a GAQL de um período.
	 *
	 * @param array $plan  Plano.
	 * @param array $range Período resolvido.
	 * @return string|\WP_Error
	 */
	private static function ads_query( array $plan, array $range ) {
		$fields = self::ads_select( $plan );

		if ( empty( $fields ) ) {
			return new \WP_Error( 'f3_google_query_fields', __( 'Nada a selecionar: informe métricas ou dimensões com equivalente na API.', 'wp-mcp-google-fator3' ) );
		}

		$conditions = Filters::to_gaql( $plan['filters'], array( Catalog::class, 'ads_resolve' ) );
		if ( is_wp_error( $conditions ) ) {
			return $conditions;
		}

		// O período é sempre uma condição, nunca um parâmetro à parte: a Google
		// Ads devolve o histórico inteiro quando não há BETWEEN, e uma conta
		// grande derruba o limite de linhas antes de chegar ao mês pedido.
		$conditions[] = sprintf(
			"segments.date BETWEEN '%s' AND '%s'",
			$range['from'],
			$range['to']
		);

		$orderings = array();
		foreach ( $plan['order_by'] as $ordering ) {
			$entry = Catalog::ads_resolve( $ordering['field'] );
			if ( is_wp_error( $entry ) ) {
				return $entry;
			}

			if ( '' === (string) $entry['native'] ) {
				return new \WP_Error(
					'f3_google_order_by',
					sprintf(
						/* translators: %s: campo pedido. */
						__( 'Não dá para ordenar por %s: é um campo calculado, sem equivalente na API.', 'wp-mcp-google-fator3' ),
						$ordering['field']
					)
				);
			}

			$orderings[] = $entry['native'] . ( 'desc' === $ordering['direction'] ? ' DESC' : ' ASC' );
		}

		$query = Gaql::build( $plan['resource'], $fields, $conditions, $orderings, $plan['limit'] );

		$valid = Gaql::validate( $query );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}

		return $query;
	}

	/**
	 * Campos do SELECT: os nativos pedidos mais os que uma métrica derivada
	 * precisa (ROAS não existe na API e é calculada a partir de duas outras).
	 *
	 * @param array $plan Plano.
	 * @return string[]
	 */
	private static function ads_select( array $plan ): array {
		$fields = array();

		foreach ( array( $plan['dimensions'], $plan['metrics'] ) as $group ) {
			foreach ( $group as $field ) {
				if ( '' !== (string) $field['native'] ) {
					$fields[ (string) $field['native'] ] = true;
					continue;
				}

				foreach ( (array) ( $field['requires'] ?? array() ) as $required ) {
					$entry = Catalog::ads_resolve( (string) $required );
					if ( ! is_wp_error( $entry ) && '' !== (string) $entry['native'] ) {
						$fields[ (string) $entry['native'] ] = true;
					}
				}
			}
		}

		return array_keys( $fields );
	}

	/**
	 * Valor de um campo numa linha achatada da Google Ads, já no tipo certo.
	 *
	 * @param array $field Entrada do catálogo.
	 * @param array $raw   Linha achatada por AdsApi::flatten_row().
	 * @return mixed
	 */
	private static function ads_value( array $field, array $raw ) {
		if ( ! empty( $field['derived'] ) ) {
			return self::ads_derived( (string) $field['id'], $raw );
		}

		$value = $raw[ (string) $field['native'] ] ?? null;

		if ( null === $value ) {
			return null;
		}

		if ( ! empty( $field['micros'] ) && is_numeric( $value ) ) {
			// Micros para a moeda da conta. Seis casas: é o máximo que os
			// micros conseguem representar, então não há arredondamento
			// inventado aqui.
			return round( ( (float) $value ) / Catalog::MICROS, 6 );
		}

		switch ( (string) ( $field['kind'] ?? 'string' ) ) {
			case 'integer':
				return is_numeric( $value ) ? (int) $value : $value;

			case 'float':
			case 'currency':
			case 'percent':
				return is_numeric( $value ) ? (float) $value : $value;
		}

		return is_scalar( $value ) ? (string) $value : $value;
	}

	/**
	 * Métricas que a API não tem e o plugin calcula.
	 *
	 * @param string $id  Id da métrica derivada.
	 * @param array  $raw Linha achatada.
	 * @return float
	 */
	private static function ads_derived( string $id, array $raw ): float {
		if ( 'roas' !== $id ) {
			return 0.0;
		}

		$value = isset( $raw['metrics.conversions_value'] ) && is_numeric( $raw['metrics.conversions_value'] )
			? (float) $raw['metrics.conversions_value']
			: 0.0;

		$cost = isset( $raw['metrics.cost_micros'] ) && is_numeric( $raw['metrics.cost_micros'] )
			? ( (float) $raw['metrics.cost_micros'] ) / Catalog::MICROS
			: 0.0;

		// Custo zero com receita não é ROAS infinito, é uma linha sem
		// investimento; devolver INF quebraria o JSON da resposta.
		if ( 0.0 === $cost ) {
			return 0.0;
		}

		return round( $value / $cost, 4 );
	}

	/**
	 * Escolhe o recurso da cláusula FROM.
	 *
	 * A regra é a especificidade: o recurso mais fundo vence, porque ele
	 * consegue devolver os campos dos recursos acima dele (um `ad_group_ad`
	 * traz `campaign.name`), mas não o contrário.
	 *
	 * @param array  $plan     Plano (dimensões, métricas, filtros, ordenações).
	 * @param mixed  $explicit Recurso informado pelo agente.
	 * @return string|\WP_Error
	 */
	private static function ads_resource_for( array $plan, $explicit ) {
		$explicit = is_scalar( $explicit ) ? trim( (string) $explicit ) : '';

		if ( '' !== $explicit ) {
			if ( ! Gaql::identifier_ok( $explicit ) || false !== strpos( $explicit, '.' ) ) {
				return new \WP_Error(
					'f3_google_resource',
					sprintf(
						/* translators: %s: recurso informado. */
						__( 'Recurso GAQL inválido: %s.', 'wp-mcp-google-fator3' ),
						$explicit
					)
				);
			}

			return $explicit;
		}

		$natives = array_merge( self::natives( $plan['dimensions'] ), self::natives( $plan['metrics'] ) );

		foreach ( $plan['filters'] as $filter ) {
			$entry = Catalog::ads_resolve( (string) $filter['field'] );
			if ( ! is_wp_error( $entry ) ) {
				$natives[] = (string) $entry['native'];
			}
		}

		foreach ( $plan['order_by'] as $ordering ) {
			$entry = Catalog::ads_resolve( (string) $ordering['field'] );
			if ( ! is_wp_error( $entry ) ) {
				$natives[] = (string) $entry['native'];
			}
		}

		return self::ads_resource( $natives );
	}

	/**
	 * Recurso GAQL a partir dos campos nativos envolvidos.
	 *
	 * @param string[] $natives Nomes nativos.
	 */
	public static function ads_resource( array $natives ): string {
		$prefixes = array(
			'search_term_view.'   => 'search_term_view',
			'ad_group_criterion.' => 'keyword_view',
			'ad_group_ad.'        => 'ad_group_ad',
			'ad_group.'           => 'ad_group',
			'geographic_view.'    => 'geographic_view',
			'campaign.'           => 'campaign',
			'campaign_budget.'    => 'campaign',
		);

		foreach ( $prefixes as $prefix => $resource ) {
			foreach ( $natives as $native ) {
				if ( 0 === strpos( (string) $native, $prefix ) ) {
					return $resource;
				}
			}
		}

		// Só métricas e segmentos: `customer` é o recurso que agrega a conta
		// inteira sem exigir nenhuma entidade.
		return 'customer';
	}

	// =========================================================================
	// google/list-accounts
	// =========================================================================

	/**
	 * Lista unificada de contas dos dois conectores.
	 *
	 * @param array $input connector, query, expand_managers, refresh.
	 * @return array Resposta pronta.
	 */
	public static function accounts( array $input ): array {
		$connector = self::connector( $input['connector'] ?? 'all' );
		if ( is_wp_error( $connector ) ) {
			return Response::fail( $connector );
		}

		$refresh  = ! empty( $input['refresh'] );
		$expand   = ! empty( $input['expand_managers'] );
		$search   = isset( $input['query'] ) && is_scalar( $input['query'] ) ? trim( (string) $input['query'] ) : '';
		$rows     = array();
		$warnings = array();

		if ( in_array( $connector, array( 'all', 'ga4' ), true ) ) {
			$gate = Gate::check( 'ga' );

			if ( null !== $gate ) {
				$warnings[] = __( 'Google Analytics:', 'wp-mcp-google-fator3' ) . ' ' . (string) $gate['message'];
			} else {
				$ga = self::ga_accounts( $refresh );

				if ( is_wp_error( $ga ) ) {
					$warnings[] = __( 'Google Analytics:', 'wp-mcp-google-fator3' ) . ' ' . $ga->get_error_message();
				} else {
					$rows = array_merge( $rows, $ga );
				}
			}
		}

		if ( in_array( $connector, array( 'all', 'google-ads' ), true ) ) {
			$gate = Gate::check( 'ads' );

			if ( null !== $gate ) {
				$warnings[] = __( 'Google Ads:', 'wp-mcp-google-fator3' ) . ' ' . (string) $gate['message'];
			} else {
				$ads = self::ads_accounts( $refresh, $expand );

				if ( is_wp_error( $ads ) ) {
					$warnings[] = __( 'Google Ads:', 'wp-mcp-google-fator3' ) . ' ' . $ads->get_error_message();
				} else {
					$rows = array_merge( $rows, $ads );
				}
			}
		}

		if ( in_array( $connector, array( 'all', 'search-console' ), true ) ) {
			$gate  = Gate::check( 'gsc' );
			$key   = self::ACCOUNTS_CACHE . 'gsc_' . \Fator3\McpGoogle\Auth\Credentials::identity_key();
			$sites = $refresh ? false : get_transient( $key );
			if ( null !== $gate ) {
				$sites = new \WP_Error( 'f3_google_gsc_gate', $gate['message'] ); } elseif ( ! is_array( $sites ) ) {
				$sites = \Fator3\McpGoogle\SearchConsole\Api::accounts();
				if ( ! is_wp_error( $sites ) ) {
					set_transient( $key, $sites, self::ACCOUNTS_TTL ); }
				}
				if ( is_wp_error( $sites ) ) {
					$warnings[] = 'Search Console: ' . $sites->get_error_message(); } else {
								$rows = array_merge( $rows, $sites ); }
		}

		if ( '' !== $search ) {
			$needle = self::fold( $search );
			$rows   = array_values(
				array_filter(
					$rows,
					static function ( array $row ) use ( $needle ): bool {
						foreach ( array( 'name', 'account_id', 'native_account_id', 'parent' ) as $key ) {
							if ( isset( $row[ $key ] ) && false !== strpos( self::fold( (string) $row[ $key ] ), $needle ) ) {
								return true;
							}
						}

						return false;
					}
				)
			);
		}

		return Response::ok(
			array(
				'connector' => $connector,
				'accounts'  => $rows,
				'count'     => count( $rows ),
				'warnings'  => $warnings,
			),
			sprintf(
				/* translators: %d: quantidade de contas. */
				__( '%d conta(s) encontrada(s).', 'wp-mcp-google-fator3' ),
				count( $rows )
			)
		);
	}

	/**
	 * Propriedades do GA4, achatadas a partir dos accountSummaries.
	 *
	 * @param bool $refresh Ignora o cache.
	 * @return array|\WP_Error
	 */
	private static function ga_accounts( bool $refresh ) {
		$key = self::ACCOUNTS_CACHE . 'ga_' . \Fator3\McpGoogle\Auth\Credentials::identity_key();

		if ( ! $refresh ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$summaries = AdminApi::account_summaries();
		if ( is_wp_error( $summaries ) ) {
			return $summaries;
		}

		$rows = array();

		foreach ( (array) $summaries as $summary ) {
			if ( ! is_array( $summary ) ) {
				continue;
			}

			$account = (string) ( $summary['displayName'] ?? ( $summary['account'] ?? '' ) );

			foreach ( (array) ( $summary['propertySummaries'] ?? array() ) as $property ) {
				if ( ! is_array( $property ) ) {
					continue;
				}

				$resource = (string) ( $property['property'] ?? '' );

				$rows[] = array(
					'connector'         => 'ga4',
					'account_id'        => $resource,
					'native_account_id' => '' !== $resource ? (string) preg_replace( '#^properties/#', '', $resource ) : '',
					'name'              => (string) ( $property['displayName'] ?? '' ),
					'parent'            => $account,
					'property_type'     => (string) ( $property['propertyType'] ?? '' ),
				);
			}
		}

		set_transient( $key, $rows, self::ACCOUNTS_TTL );

		return $rows;
	}

	/**
	 * Contas do Google Ads, com nome, moeda e fuso.
	 *
	 * @param bool $refresh Ignora o cache.
	 * @param bool $expand  Também lista os clientes de cada gerenciadora.
	 * @return array|\WP_Error
	 */
	private static function ads_accounts( bool $refresh, bool $expand ) {
		$key = self::ACCOUNTS_CACHE . 'ads' . ( $expand ? '_mcc' : '' ) . '_' . \Fator3\McpGoogle\Auth\Credentials::identity_key();

		if ( ! $refresh ) {
			$cached = get_transient( $key );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$ids = AdsApi::list_accessible_customers();
		if ( is_wp_error( $ids ) ) {
			return $ids;
		}

		$rows = array();
		$seen = array();
		foreach ( (array) $ids as $id ) {
			$id = CustomerId::normalize( $id );
			if ( is_wp_error( $id ) ) {
				return $id;
			}
			if ( isset( $seen[ $id ] ) ) {
				continue;
			}
			$seen[ $id ] = true;
			// A resolução por nome/* precisa de nomes e de toda a hierarquia.
			// O limite de linhas de relatórios não é um limite de contas.
			$details = AdsApi::customer( $id );
			if ( is_wp_error( $details ) ) {
				return new \WP_Error( 'f3_google_ads_account_catalog', 'Catálogo Ads incompleto: não foi possível ler a conta ' . $id . '. ' . $details->get_error_message() . ' Consulte com account_id explícito ou corrija o acesso antes de usar nomes ou *.' );
			}
			$rows[] = self::ads_account_row( $id, $details, '' );
			if ( ! $expand || empty( $details['is_manager'] ) ) {
				continue;
			}
			// true,true,true inclui ocultas, todos os níveis e paginação integral.
			$clients = AdsApi::customer_clients( $id, true, true, true );
			if ( is_wp_error( $clients ) ) {
				return new \WP_Error( 'f3_google_ads_account_catalog', 'Catálogo Ads incompleto: falhou a hierarquia da gerenciadora ' . $id . '. ' . $clients->get_error_message() );
			}
			if ( ! empty( $clients['truncated'] ) ) {
				return new \WP_Error( 'f3_google_ads_account_catalog', 'Catálogo Ads incompleto: a hierarquia da gerenciadora ' . $id . ' foi truncada. Nenhum catálogo parcial foi armazenado.' );
			}
			foreach ( (array) ( $clients['rows'] ?? array() ) as $client ) {
				$child = CustomerId::normalize( $client['customer_client.id'] ?? '' );
				if ( is_wp_error( $child ) ) {
					return new \WP_Error( 'f3_google_ads_account_catalog', 'A hierarquia Ads devolveu um cliente sem ID válido; a completude do catálogo não foi confirmada.' );
				}
				if ( isset( $seen[ $child ] ) ) {
					continue;
				}
				$seen[ $child ] = true;
				$rows[]         = self::ads_account_row(
					$child,
					array(
						'name'       => (string) ( $client['customer_client.descriptive_name'] ?? '' ),
						'currency'   => (string) ( $client['customer_client.currency_code'] ?? '' ),
						'timezone'   => (string) ( $client['customer_client.time_zone'] ?? '' ),
						'is_manager' => ! empty( $client['customer_client.manager'] ),
					),
					$id
				);
			}
		}
		set_transient( $key, $rows, self::ACCOUNTS_TTL );
		return $rows;
	}

	/**
	 * @param string $id      ID de 10 dígitos.
	 * @param array  $details Saída de AdsApi::customer() ou equivalente.
	 * @param string $parent  Gerenciadora, quando a conta veio de uma expansão.
	 */
	private static function ads_account_row( string $id, array $details, string $parent_name ): array {
		return array(
			'connector'         => 'google-ads',
			'account_id'        => $id,
			'native_account_id' => $id,
			'name'              => (string) ( $details['name'] ?? '' ),
			'parent'            => '' !== $parent_name ? $parent_name : (string) Options::ads_login_customer_id(),
			'currency'          => (string) ( $details['currency'] ?? '' ),
			'timezone'          => (string) ( $details['timezone'] ?? '' ),
			'is_manager'        => ! empty( $details['is_manager'] ),
		);
	}

	/**
	 * Nome de exibição de uma conta, quando ele já estiver no cache.
	 *
	 * Não faz chamada de rede de propósito: um relatório de cinco contas não
	 * pode virar cinco chamadas extras só para preencher um rótulo. Quem quiser
	 * os nomes garantidos chama `google/list-accounts` antes — o cache dura dez
	 * minutos e é o mesmo.
	 *
	 * @param string $connector 'ga' | 'ads'.
	 * @param string $id        Identificador da conta.
	 */
	public static function account_name( string $connector, string $id ): string {
		foreach ( array( self::ACCOUNTS_CACHE . $connector, self::ACCOUNTS_CACHE . $connector . '_mcc' ) as $key ) {
			$cached = get_transient( $key . '_' . \Fator3\McpGoogle\Auth\Credentials::identity_key() );

			if ( ! is_array( $cached ) ) {
				continue;
			}

			foreach ( $cached as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}

				if ( (string) ( $row['account_id'] ?? '' ) === $id || (string) ( $row['native_account_id'] ?? '' ) === $id ) {
					return (string) ( $row['name'] ?? '' );
				}
			}
		}

		return '';
	}

	// =========================================================================
	// google/list-fields
	// =========================================================================

	/**
	 * Catálogo de campos de um conector.
	 *
	 * @param array $input connector, field_type, query, account_id, resource.
	 * @return array Resposta pronta.
	 */
	public static function fields( array $input ): array {
		$connector = self::connector( $input['connector'] ?? '' );
		if ( is_wp_error( $connector ) ) {
			return Response::fail( $connector );
		}

		if ( 'all' === $connector ) {
			return Response::fail(
				new \WP_Error(
					'f3_google_connector',
					__( 'Informe connector: ga4, google-ads ou search-console. Os catálogos são diferentes e não se misturam.', 'wp-mcp-google-fator3' )
				)
			);
		}

		$gate = Gate::check( 'ga4' === $connector ? 'ga' : ( 'search-console' === $connector ? 'gsc' : 'ads' ) );
		if ( null !== $gate ) {
			return $gate;
		}

		$type   = self::field_type( $input['field_type'] ?? '' );
		$search = isset( $input['query'] ) && is_scalar( $input['query'] ) ? trim( (string) $input['query'] ) : '';

		if ( ! empty( $input['account_id'] ) ) {
			$account = Accounts::resolve_one( $connector, $input['account_id'] );
			if ( is_wp_error( $account ) ) {
				return Response::fail( $account ); }
			$input['account_id'] = $account;
		}
		$fields = 'ga4' === $connector
			? self::ga_fields( $input['account_id'] ?? null )
			: ( 'search-console' === $connector ? \Fator3\McpGoogle\SearchConsole\Api::fields() : self::ads_fields_list( $input['resource'] ?? '' ) );
		if ( 'google-ads' === $connector && ! empty( $input['account_id'] ) && ! is_wp_error( $fields ) ) {
			$custom = \Fator3\McpGoogle\Ads\Conversions::fields( (string) $input['account_id'] );
			if ( is_wp_error( $custom ) ) {
				return Response::fail( $custom ); }
			$fields = array_merge( $fields, $custom );
		}

		if ( is_wp_error( $fields ) ) {
			return Response::fail( $fields );
		}

		if ( '' !== $type ) {
			$fields = array_values(
				array_filter(
					$fields,
					static function ( array $field ) use ( $type ): bool {
						return $field['type'] === $type;
					}
				)
			);
		}

		$exact = null;

		if ( '' !== $search ) {
			$needle = self::fold( $search );

			foreach ( $fields as $field ) {
				if ( self::fold( (string) $field['id'] ) === $needle || self::fold( (string) ( $field['native'] ?? $field['id'] ) ) === $needle ) {
					$exact = $field;
					break;
				}
			}

			$fields = array_values(
				array_filter(
					$fields,
					static function ( array $field ) use ( $needle ): bool {
						foreach ( array( 'id', 'native', 'label' ) as $key ) {
							if ( false !== strpos( self::fold( (string) ( $field[ $key ] ?? '' ) ), $needle ) ) {
								return true;
							}
						}

						return false;
					}
				)
			);
		}

		$data = array(
			'connector' => $connector,
			'fields'    => $fields,
			'count'     => count( $fields ),
		);

		if ( null !== $exact ) {
			$data['exact_match'] = $exact;
		}

		return Response::ok(
			$data,
			sprintf(
				/* translators: %d: quantidade de campos. */
				__( '%d campo(s).', 'wp-mcp-google-fator3' ),
				count( $fields )
			)
		);
	}

	/**
	 * Campos do GA4: apelidos da casa primeiro, depois o catálogo da API (o
	 * universal, ou o da propriedade quando ela é informada — é aí que aparecem
	 * as dimensões e métricas personalizadas).
	 *
	 * @param mixed $account_id Propriedade, ou null para o catálogo universal.
	 * @return array|\WP_Error
	 */
	private static function ga_fields( $account_id ) {
		$property = is_scalar( $account_id ) && '' !== trim( (string) $account_id ) ? $account_id : null;

		$metadata = DataApi::metadata( $property );
		if ( is_wp_error( $metadata ) ) {
			return $metadata;
		}

		$fields = array();
		$seen   = array();

		foreach ( Catalog::ga_aliases() as $alias => $target ) {
			if ( $alias === $target ) {
				continue;
			}

			$fields[] = array(
				'id'     => $alias,
				'native' => $target,
				'type'   => 'unknown',
				'label'  => $alias,
				'kind'   => 'string',
				'custom' => false,
				'alias'  => true,
			);
		}

		foreach ( array(
			'dimensions' => 'dimension',
			'metrics'    => 'metric',
		) as $key => $type ) {
			foreach ( (array) ( $metadata[ $key ] ?? array() ) as $item ) {
				if ( ! is_array( $item ) || empty( $item['apiName'] ) ) {
					continue;
				}

				$name = (string) $item['apiName'];

				if ( isset( $seen[ $name ] ) ) {
					continue;
				}
				$seen[ $name ] = true;

				$fields[] = array(
					'id'     => $name,
					'native' => $name,
					'type'   => $type,
					'label'  => (string) ( $item['uiName'] ?? $name ),
					'kind'   => 'metric' === $type ? self::ga_kind( (string) ( $item['type'] ?? '' ) ) : ( 'date' === $name ? 'date' : 'string' ),
					'custom' => ! empty( $item['customDefinition'] ),
				);
			}
		}

		// O tipo dos apelidos só se sabe depois de ver o catálogo.
		foreach ( $fields as $index => $field ) {
			if ( empty( $field['alias'] ) ) {
				continue;
			}

			foreach ( $fields as $real ) {
				if ( empty( $real['alias'] ) && $real['id'] === $field['native'] ) {
					$fields[ $index ]['type'] = $real['type'];
					$fields[ $index ]['kind'] = $real['kind'];
					break;
				}
			}
		}

		return $fields;
	}

	/**
	 * `metricHeaders[].type` do GA4 para o vocabulário da casa.
	 */
	private static function ga_kind( string $type ): string {
		switch ( $type ) {
			case 'TYPE_INTEGER':
				return 'integer';

			case 'TYPE_CURRENCY':
				return 'currency';

			case 'TYPE_STANDARD':
			case 'TYPE_FLOAT':
				return 'float';
		}

		if ( 0 === strpos( $type, 'TYPE_' ) && false !== strpos( $type, 'SECONDS' ) ) {
			return 'float';
		}

		return 'float';
	}

	/**
	 * Campos do Google Ads: o catálogo curado e, quando um recurso é informado,
	 * os campos vivos que a API diz serem selecionáveis com ele.
	 *
	 * @param mixed $resource Recurso GAQL.
	 * @return array|\WP_Error
	 */
	private static function ads_fields_list( $resource_name ) {
		$fields = array();
		$seen   = array();

		foreach ( Catalog::ads_fields() as $field ) {
			$seen[ strtolower( (string) $field['native'] ) ] = true;

			$fields[] = array(
				'id'     => (string) $field['id'],
				'native' => (string) $field['native'],
				'type'   => (string) $field['type'],
				'label'  => (string) $field['label'],
				'kind'   => (string) $field['kind'],
				'custom' => false,
			);
		}

		$resource_name = is_scalar( $resource_name ) ? trim( (string) $resource_name ) : '';

		if ( '' === $resource_name ) {
			return $fields;
		}

		$metadata = AdsApi::resource_metadata( $resource_name );
		if ( is_wp_error( $metadata ) ) {
			return $metadata;
		}

		foreach ( (array) ( $metadata['selectable'] ?? array() ) as $native ) {
			$native = strtolower( (string) $native );

			if ( '' === $native || isset( $seen[ $native ] ) ) {
				continue;
			}
			$seen[ $native ] = true;

			$fields[] = array(
				'id'       => $native,
				'native'   => $native,
				'type'     => 0 === strpos( $native, 'metrics.' ) ? 'metric' : 'dimension',
				'label'    => $native,
				'kind'     => 0 === strpos( $native, 'metrics.' ) ? 'float' : 'string',
				'custom'   => false,
				'resource' => $resource_name,
			);
		}

		return $fields;
	}

	/**
	 * @param mixed $value Valor recebido.
	 * @return string '' | 'metric' | 'dimension'.
	 */
	private static function field_type( $value ): string {
		$value = is_scalar( $value ) ? strtolower( trim( (string) $value ) ) : '';

		if ( in_array( $value, array( 'metric', 'metrics' ), true ) ) {
			return 'metric';
		}

		if ( in_array( $value, array( 'dimension', 'dimensions' ), true ) ) {
			return 'dimension';
		}

		return '';
	}

	// =========================================================================
	// Apoio
	// =========================================================================

	/**
	 * Monta a resposta final comum aos dois conectores.
	 *
	 * @param array $plan      Plano.
	 * @param array $columns   Colunas.
	 * @param array $rows      Linhas.
	 * @param array $accounts  Contas efetivamente consultadas.
	 * @param array $warnings  Avisos.
	 * @param bool  $truncated Alguma conta teve resposta cortada.
	 * @param array $request   Resumo do que foi enviado.
	 */
	private static function result( array $plan, array $columns, array $rows, array $accounts, array $warnings, bool $truncated, array $request ): array {
		$data = array(
			'connector'  => $plan['connector'],
			'columns'    => $columns,
			'rows'       => $rows,
			'row_count'  => count( $rows ),
			'truncated'  => $truncated,
			'date_range' => $plan['range'],
			'accounts'   => $accounts,
			'warnings'   => $warnings,
			'request'    => $request,
		);

		if ( null !== $plan['compare'] ) {
			$data['compare_date_range'] = $plan['compare'];
		}

		// Todas as contas falharam: isso é um erro, não uma tabela vazia — o
		// agente precisa ver `success: false` para não reportar "zero cliques".
		if ( empty( $rows ) && ! empty( $warnings ) && empty( $accounts ) ) {
			return Response::fail(
				new \WP_Error( 'f3_google_query_failed', implode( ' | ', $warnings ) ),
				array( 'warnings' => $warnings )
			);
		}

		return Response::ok(
			$data,
			sprintf(
				/* translators: 1: linhas, 2: contas. */
				__( '%1$d linha(s) de %2$d conta(s).', 'wp-mcp-google-fator3' ),
				count( $rows ),
				count( $accounts )
			)
		);
	}

	/**
	 * Avisos que já se sabem antes de falar com a Google — hoje, só o corte da
	 * lista de contas pelo teto de `MAX_ACCOUNTS`. Cortar em silêncio faria o
	 * agente reportar um total que não é o pedido.
	 *
	 * @param array $plan Plano.
	 * @return string[]
	 */
	private static function initial_warnings( array $plan ): array {
		$dropped = (int) ( $plan['dropped'] ?? 0 );

		if ( $dropped < 1 ) {
			return array();
		}

		return array(
			sprintf(
				/* translators: 1: contas ignoradas, 2: teto por chamada. */
				__( '%1$d conta(s) além do teto de %2$d por chamada foram ignoradas. Divida o pedido em várias chamadas.', 'wp-mcp-google-fator3' ),
				$dropped,
				self::MAX_ACCOUNTS
			),
		);
	}

	/**
	 * @param array $fields Entradas.
	 * @return string[]
	 */
	private static function natives( array $fields ): array {
		$out = array();

		foreach ( $fields as $field ) {
			if ( '' !== (string) $field['native'] ) {
				$out[] = (string) $field['native'];
			}
		}

		return $out;
	}

	/**
	 * Posição de cada coluna da tabela devolvida pelo DataApi.
	 *
	 * @param array $columns Nomes das colunas.
	 * @return array<string,int>
	 */
	private static function index_of( array $columns ): array {
		$index = array();

		foreach ( $columns as $position => $name ) {
			$name = (string) $name;

			if ( '' !== $name && ! isset( $index[ $name ] ) ) {
				$index[ $name ] = (int) $position;
			}
		}

		return $index;
	}

	/**
	 * @param mixed $value Lista crua (array, string, ou string com vírgulas).
	 * @return string[]
	 */
	private static function string_list( $value ): array {
		if ( null === $value || '' === $value ) {
			return array();
		}

		if ( is_string( $value ) ) {
			$value = explode( ',', $value );
		}

		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}

		$out = array();

		foreach ( $value as $item ) {
			if ( ! is_scalar( $item ) ) {
				continue;
			}

			$item = trim( (string) $item );

			if ( '' !== $item ) {
				$out[] = $item;
			}
		}

		return $out;
	}

	/**
	 * @param string   $account Conta.
	 * @param \WP_Error $error  Erro ocorrido.
	 */
	private static function account_warning( string $account, \WP_Error $error ): string {
		return sprintf(
			/* translators: 1: conta, 2: mensagem de erro. */
			__( 'Conta %1$s: %2$s', 'wp-mcp-google-fator3' ),
			$account,
			$error->get_error_message()
		);
	}

	/**
	 * Minúsculas e sem acento, para busca por substring que funcione com
	 * "Análise" e "analise".
	 */
	private static function fold( string $value ): string {
		// `strtolower()` só conhece ASCII; com mbstring "ANÁLISE" vira
		// "análise" e a substituição seguinte encontra o acento.
		$value = function_exists( 'mb_strtolower' ) ? mb_strtolower( $value, 'UTF-8' ) : strtolower( $value );

		return strtr(
			$value,
			array(
				'á' => 'a',
				'à' => 'a',
				'â' => 'a',
				'ã' => 'a',
				'ä' => 'a',
				'é' => 'e',
				'ê' => 'e',
				'í' => 'i',
				'ó' => 'o',
				'ô' => 'o',
				'õ' => 'o',
				'ú' => 'u',
				'ü' => 'u',
				'ç' => 'c',
			)
		);
	}
}
