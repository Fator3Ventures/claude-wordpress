> Versão corrente: **1.50.0**, contrato **8.15.0**. Leia [RELEASE-1.50.0.md](RELEASE-1.50.0.md), [AGENTES-1.50.0.md](AGENTES-1.50.0.md) e [CREDENCIAIS-1.50.md](CREDENCIAIS-1.50.md). Conteúdo anterior abaixo é histórico.

> Atualização 1.49.1, contrato administrativo 8.14.1: leia [RELEASE-1.49.1.md](RELEASE-1.49.1.md) e [AGENTES-1.49.1.md](AGENTES-1.49.1.md). Pedido 291 (nomes/fontes e Campanha no Pipedrive), schemas de contato/consentimento e falhas de consulta/agendamento da fila. O conteúdo anterior abaixo é histórico.

> Atualização 1.49.0, contrato administrativo 8.14.0: consulte RELEASE-1.49.0.md e AGENTES-1.49.0.md para as melhorias M1–M11 (tradução antes de init, motivo das recusas nativas, rotas públicas, prioridade e leitura da fila de conversões, catálogo LinkedIn sem conta, custo do contexto de medição, estado LinkedIn sem resposta do SDK, link do relatório Search Console). As seções de versões anteriores abaixo são históricas.

> Atualização 1.48.0, contrato administrativo 8.13.0: consulte RELEASE-1.48.0.md e AGENTES-1.48.0.md para os pedidos 288–290. As seções de versões anteriores abaixo são históricas.

> Versão vigente: Core **1.43.0**, contrato **8.8.0**. Leia [RELEASE-1.43.0.md](RELEASE-1.43.0.md) e [AGENTES-1.43.0.md](AGENTES-1.43.0.md). Conteúdo de versões anteriores abaixo é histórico.

> Versão atual 1.39.0, contrato administrativo 8.4.0. Consulte [RELEASE-1.39.0.md](RELEASE-1.39.0.md) e [AGENTES-1.39.0.md](AGENTES-1.39.0.md) para alterações 230–235 e bloqueios de aceite. Seções anteriores permanecem referência histórica.

> Atualização 1.37.0: consulte RELEASE-1.37.0.md e PIPEDRIVE-1.37.md; base direta 1.36.0, contrato administrativo 8.2.0. Evidências atuais no relatório externo; provas históricas abaixo mantêm seu escopo original.

# Instruções do plugin

Leia DOCUMENTACAO.md, AGENTES-1.36.0.md e CONVERSOES-SDK-1.36.md. Documentos anteriores são históricos quando houver divergência. Normas comuns revisão 4.
