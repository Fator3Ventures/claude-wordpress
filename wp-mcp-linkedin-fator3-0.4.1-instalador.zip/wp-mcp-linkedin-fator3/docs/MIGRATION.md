# Atualização 0.3.0 / 0.4.0 → 0.4.1

Preserva conexões cifradas, grants, agendas, histórico, jobs e tabelas. Sem alteração de schema ou formato de cifra. O ZIP deve substituir a pasta estável do plugin; não executar uninstall. Instalação limpa e atualização direta são suportadas. Cabeçalhos novos aparecem em plugins/list. Reversão de arquivos não desfaz coleta/efeito externo realizado durante operação; preserve backup compatível e salts.

Nenhuma mudança de protocolo Lead Sync ou callback. O Core continua responsável pela seleção e ingestão comercial; esta rodada não reabre sua homologação externa.

As agendas passam a aceitar `label` e `next_at` opcionais. Agendas anteriores sem nome continuam válidas. Reverter somente os arquivos para 0.3.0 conserva os dados; nomes e horários deixam de ser editáveis pela interface anterior. Faça cópia de arquivos e banco antes de reverter. Não executar uninstall para atualizar.

A 0.4.0 foi instalada apenas no Site-Teste nesta rodada. A revisão visual encontrou rótulos técnicos em inglês no diagnóstico. A 0.4.1 corrige a apresentação sem trocar códigos dos contratos nem reutilizar o instalador 0.4.0 com bytes diferentes.
