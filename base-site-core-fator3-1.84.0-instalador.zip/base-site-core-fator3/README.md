# Fator3 Site Core 1.84.0

Plugin WordPress `base-site-core-fator3`. Requer WordPress 7.1.4 e PHP 8.3. Contrato administrativo 8.40.0. Base de atualização: 1.83.0.

Comece em docs/DOCUMENTACAO.md (índice completo). Notas da versão: docs/RELEASE-1.84.0.md. Guia para agentes: docs/AGENTES-1.84.0.md. Lista das abilities: docs/REFERENCIA-ABILITIES.md.
