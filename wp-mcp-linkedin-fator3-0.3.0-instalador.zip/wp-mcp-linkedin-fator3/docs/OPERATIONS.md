# Operações LinkedIn — 0.3.0

Relatórios de Pages/Ads mantêm o comportamento da 0.1.0. list-fields publica catálogo fechado. Query é paginada, vinculada à seleção, principal e revisão da conexão. create-job/run-job/job-status/control-job/job-results gerenciam coleta durável; schedules criam coletas, não ingerem leads. export/export-read geram CSV/JSON local autenticado. Ausência de resultado não equivale a zero. Consulte schemas instalados para relatórios, granularidades, pivôs e limites.

Lead Sync oferece metadados, respostas, verificação e gerenciamento de assinaturas próprias. Respostas preservam raw e submitted_at_ms de 13 dígitos; não convertem milissegundos nem cadastram contatos. Webhook, persistência antes do ACK, deduplicação e ingestão pertencem ao consumidor. A validação de HMAC não persiste recibo de entrega.

## Diário de assinaturas

O bloqueio persistido considera owner, leadType e formulário versionado. Callback é preservado na intenção, mas não permite contornar bloqueio do mesmo recurso. Conexão, consumidor, revisão ou nova chave idempotente não liberam uma intenção pendente. Um bloqueio nomeado de banco serializa todos os escritores de assinaturas deste site. Registros 0.1 são indexados em lotes antes de qualquer novo POST.

Estados: prepared, dispatching, uncertain, confirmed, deleting, deleted e rejected_before_dispatch; registros legados creating/rejected são tratados conservadoramente. A transição dispatching é gravada antes do POST. Timeout ou queda deixa bloqueio persistido. Recibo remoto com ID é gravado antes de nova leitura ou checagem de acesso. Revogação durante o envio retorna erro com remote_effect conhecido e ownership_key; não apaga o recibo.

As concessões, seleção, callback, usuário humano quando aplicável e revisões são revalidados imediatamente antes de POST/DELETE. A pré-consulta pode revogar acesso; nesse caso nenhuma mutação posterior é enviada. Uma assinatura externa equivalente nunca é adotada como própria.

get_subscription_operation lê o diário do próprio consumidor. reconcile_subscription exige ownership_key e expected_operation_revision. Intenção sem recibo remoto nunca é liberada por listagem vazia: a origem pode estar atrasada. Um prepared comprovadamente sem despacho pode ser marcado rejected_before_dispatch. Com recibo conhecido, GET do ID deve confirmar o mesmo objeto; mudança de credencial exige authorize_current_context, mesma identidade de aplicativo configurada e nova concessão válida. Registros antigos sem application_id não são reatrelados automaticamente; preserve o contexto anterior e use revisão administrativa com evidência do fornecedor.

DELETE exige autoria local, estado confirmado e contexto vigente. Falha de confirmação mantém estado deleting para reconciliação; não é reenviado automaticamente. delivery_verified permanece false: criar assinatura não comprova challenge nem entrega real.
