# Atualização 0.2.0 → 0.3.0

Preserva conexões cifradas, grants, agendas, histórico, jobs e tabelas. Sem alteração de schema ou formato de cifra. O ZIP deve substituir a pasta estável do plugin; não executar uninstall. Instalação limpa e atualização direta são suportadas. Cabeçalhos novos aparecem em plugins/list. Reversão de arquivos não desfaz coleta/efeito externo realizado durante operação; preserve backup compatível e salts.

Nenhuma mudança de protocolo Lead Sync ou callback. O Core continua responsável pela seleção e ingestão comercial; esta rodada não reabre sua homologação externa.
