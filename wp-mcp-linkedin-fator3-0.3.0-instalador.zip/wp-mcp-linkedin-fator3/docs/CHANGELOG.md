# Alterações — 0.3.0

Atualização direta da 0.2.0; nenhuma migração de banco, seleção ou autorização.

- Pedido MCP LinkedIn 1: Description exata com responsabilidade do Core e local de configuração. APIs, SDK, assinaturas, autorização e armazenamento permanecem byte a byte iguais à 0.2.0.

## Histórico da 0.2.0

# 0.2.0

- Administração humana restrita a manage_options; SDK com grant explícito preservado para usuário zero.
- Índice e documentação completa paginada com SHA-256, UTF-8 e revisão.
- R3-LI-01: bloqueio persistido por recurso entre chaves, consumidores e conexões; migração de intenções 0.1.
- R3-LI-02: guarda junto ao despacho de POST/DELETE e preservação de recibo em revogação durante o envio.
- R3-LI-03: SDK 1.1, consulta/reconciliação do diário, efeito remoto e reatrelamento explícito de contexto conhecido.
- Paginação de concessões, projeções diretas e painel de consulta administrativa.
- Desinstalação conserva dados. Pages, Ads e ingestão comercial mantêm suas fronteiras.

Operação real de Lead Sync e migração do Core dependem de homologação autorizada; nenhuma assinatura real foi criada pelos testes locais.
