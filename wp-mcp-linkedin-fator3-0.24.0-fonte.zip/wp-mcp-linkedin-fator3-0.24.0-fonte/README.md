# Fonte — Fator3 MCP LinkedIn 0.24.0

**Pedido 26.** A tela fica em Ferramentas → Fator3 MCP LinkedIn. O arquivo instalado `docs/ADMINISTRATION.md` explica as seis seções, as 12 abas e como consultar tabelas em telas estreitas. Os arquivos editáveis ficam em `build/common`, `build/linkedin`, `build/assets`, `build/manuals` e `build/docs/linkedin`. A árvore `plugin/wp-mcp-linkedin-fator3` é a cópia exata do instalador. Existe um único arquivo JavaScript administrativo principal: a paginação das listas aproveita esse carregamento já existente. Os assets do painel não são enfileirados nas páginas públicas.

## Build e verificação

Na raiz do fonte, use Python 3, PHP 8.3 de 64 bits com mbstring e as extensões exigidas pelo WordPress. Para o build, aponte F3_SOCIAL_PHP para o binário PHP local.

```sh
F3_SOCIAL_PHP=/caminho/php8.3 python3 build/build.py
python3 tools/verify-installer024.py build/dist/wp-mcp-linkedin-fator3-0.24.0-instalador.zip plugin/wp-mcp-linkedin-fator3
```

## Testes reproduzíveis

Copie `tools/lab-release0240.example.json` para um arquivo de trabalho e indique caminhos e hashes reais das dependências locais. A entrada PHP identifica o executável ou wrapper da máquina de teste: verifique o runtime com `php -v` e substitua a impressão do wrapper pela do seu executável. Os hashes dos pacotes WordPress e Fator3 são os efetivamente usados na rodada. O cliente MySQL deve estar no PATH e o usuário de um banco **descartável** deve poder criar e descartar databases. O runner bloqueia as saídas ao fornecedor. Nunca use este laboratório em um site compartilhado.

```sh
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li24-isolado --order linkedin-only --tests suite.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li24-integrado --order linkedin-integrated --tests suite.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li24-mig --origin upgrade --order linkedin-integrated --tests migration024.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li24-doc --origin upgrade --order linkedin-integrated --tests mcp-docs080.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li24-concessoes --order linkedin-integrated --tests rotation023.php
```

Para as fronteiras com o Core use também, em bancos distintos, `ad-source022.php` e `conversions023.php` na ordem `linkedin-integrated`; para documentação em instalação limpa, omita `--origin upgrade`.

Para as telas, instale Playwright para Python e informe um Chromium Headless Shell utilizável localmente. O teste faz login em WordPress temporário em loopback com senha aleatória, usa 56 conexões sintéticas e bloqueia requisições a origens externas.

```sh
F3_CHROME_HEADLESS_SHELL=/caminho/chromium-headless-shell python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li24-telas --order linkedin-integrated --tests webui024.php
```

Em host de testes isolado sem suporte a sandbox do navegador, o ensaio admite `F3_LAB_CHROME_NO_SANDBOX=1`. Para a prova da base, use o mesmo comando com `F3_UI_BASELINE=1`, outro diretório e `--candidate /dependencias/wp-mcp-linkedin-fator3-0.23.0-instalador.zip`. Confira `evidence/visual024/results.json` de cada diretório de execução. O controle negativo registra as divergências esperadas na base, sem exigir que 0.23.0 passe no padrão da versão nova.

No fonte, `evidence/release0240/` reúne resultados sanitizados de laboratório e Site-Teste. Abra `evidence/release0240/capturas/index.html` para navegar pelas capturas. O relatório interno precede o fechamento do fonte. Os hashes finais do fonte e do instalador estão no relatório externo; os diretórios anteriores são históricos.
