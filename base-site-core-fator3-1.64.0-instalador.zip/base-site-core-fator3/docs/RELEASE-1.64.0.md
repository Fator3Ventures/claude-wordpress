# Fator3 Site Core 1.64.0

Contrato administrativo 8.29.0, aditivo. Base direta 1.63.0. Acompanhantes considerados: MCP 0.38.0, Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0 e Pipedrive 0.5.0. O relatório externo distingue implementação, prova de bancada e aceite da frota.

## 357 — Spam por sinal

Cada sinal de formulário aceita spam booleano, padrão false, independente de suspeita/aviso. Um sinal spam prevalece sobre avisos permitidos: captura com classificacao suspeito e atendimento spam, sem criar aviso/entrega. Complemento de etapa 2 cancela intenções pendentes de aviso, CRM e e-mail; entregas já concluídas não são desfeitas. Conversões revalidam elegibilidade antes de executar. O snapshot sinais_politica guarda spam e sinais_spam. Spam não entra na revisão nem na contagem de suspeitos; spam_por_sinal apresenta janelas de 7 e 30 dias. Restaurar um contato exige a decisão administrativa existente de aceitar como novo e entregar; deduplicação e auditoria permanecem.

## 358 — Persistência de robots.txt

f3base_avisos_tecnicos.robots_sem_confirmacao_minutos: inteiro 15–1440, padrão 120. Cada ciclo registra tentativas, última falha/código e tempo transcorrido. Falhas transitórias dentro da janela não enviam atenção. Após a janela, há uma reserva de atenção por ciclo. Recuperação só avisa se a atenção anterior foi aceita por wp_mail. Aceitação pelo transporte não comprova recebimento na caixa. Consulte robots_retomada em f3base/saude-ler.

## 359 — E-mails nativos

f3base_email_wordpress aceita nove booleanos: plugin_sucesso, tema_sucesso e nucleo_sucesso false; plugin_falha, tema_falha, nucleo_falha, nucleo_critico, nucleo_manual e recuperacao_fatal true. Leitura, simulação e gravação usam o catálogo/CAS existentes. Lote misto mantém a notificação quando contém falha permitida. Atualizações automáticas não são desativadas. A regra alcança também atualização manual necessária e recuperação fatal, pelos filtros nativos específicos. Não altera e-mail de usuário, pedido ou lead. O aceite da próxima atualização automática real depende de observação externa.

## 354 e 360 — Página pública e manutenção

- f3base_llms_mapa e f3base_llms_assinatura têm autoload e guardam somente descoberta/assinatura/prazo. A página não lê a geração completa. Alterar publicação, senha, exclusão ou metadados Yoast invalida o item imediatamente; a rota Markdown revalida a elegibilidade. A geração cron repõe a seleção completa em até uma hora. Com CLI recente, visita não verifica geração.
- f3base_esquema guarda versão inteira por tabela e dona do reparo. Prontidão pública consulta o mapa; DDL fica na instalação/atualização/reparo. Primeira escrita recusada por tabela/coluna ausente invalida a prontidão, reserva aviso e agenda reparo; não confirma a escrita recusada nem repete automaticamente o contato.
- Zelador central: condições nomeadas em zelador-condicoes.php, classificação/recorrência em cron-tarefas.php. Declarações não carregam classes donas. Executa na ativação, atualização, passagem CLI e alteração das options operáveis; conserva guardas e condições específicas. Página e login não percorrem filas/agendas. Rotinas ficam no cron do servidor; urgente mantém o caminho de entrega. Despertadores de retomada urgente e de rotina são separados.
- O servidor deve executar `wp cron event run --due-now` a cada 15 minutos. O heartbeat só é confirmado quando a passagem CLI consta do diário. Após uma hora sem passagem, rotinas voltam ao WP-Cron por visita e há reserva de aviso técnico; próxima CLI reativa a proteção. O filtro cobre tarefas WordPress de atualização/transients/lixeira. Outros plugins só aderem por `f3base_cron_rotina`.
- Configuração normalizada pública tem snapshot/revisão; mudança atualiza o snapshot na mesma requisição. Captura, consentimento, cabeçalhos, redirecionamentos e retirada de conteúdo restrito continuam imediatos. Resposta de gravação inclui efeito_ate e efeitos_imediatos; prazo não é confirmação de execução.
- Registro SDK usa contratos existentes e callbacks de configuração sob demanda. Barreira de recuperação e geração de cache são memorizadas na requisição. Cache de schema passa por lembrar, com chave da página, revisão/configuração, geração e grafo de origem; 32 slots PHP protegidos de até 256 KiB (8 MiB), TTL 300 s, sem escrita SQL nem entrada na barreira na visita. Sem diretório já provisionado, calcula sem persistir. O grafo original integra a chave para preservar extensões de terceiros.

## Diagnóstico e limites

`f3base/desempenho-ler {"contexto":"pagina","amostras":3}` e `GET /f3base/v1/desempenho` exigem manage_options. Contextos atual/pagina/login; 1–3 amostras. Callbacks do Core nos sete ganchos solicitados, inclusive anônimos, são instrumentados. Somar proprio_ms evita dupla contagem. Consultas guardam somente operação/tabela/nome de option/callback, sem literais. Há classes carregadas, OPcache e realpath_cache. Medição termina no footer.

nao_instrumentado_ms é o tempo do início do arquivo principal ao footer menos tempo próprio medido; inclui WordPress, tema e acompanhantes. Não deve ser atribuído integralmente ao Core. A lista fechada tests/public-classes-1640.json e a sonda HTTP falham por classe inesperada, mais de 60 classes, mais de cinco consultas, DDL/UPDATE ou latência própria acima do limite. A primeira passagem fria e as aquecidas são identificadas separadamente.

## Banco, reversão e homologação

Sem tabela/coluna nova nesta versão. Options de mapa, snapshot, esquema, heartbeat e política são aditivas. Contatos, filas, credenciais, CAS e permissões são preservados. Rollback de código para 1.63.0 conserva dados, porém restaura comportamento anterior de spam, avisos e manutenção; não restaure o banco para desfazer este incremento. Os caches derivados são regeneráveis. Preservar a guarda de recuperação fora da pasta do plugin.

A homologação de 48/47 itens em korvena.com.br/fator3.com.br, queda diária de POST /wp-cron.php e próximo e-mail de atualização real pertencem à frota. Não declarar aceite desses ambientes a partir de fixture ou apenas desta documentação. Provas com o ZIP exato, tempos e limitações estão no relatório externo.
