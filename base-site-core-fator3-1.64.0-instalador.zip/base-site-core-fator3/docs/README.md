> Vigente em 1.64.0: contrato 8.29.0; pedidos 357–360 e 354 em RELEASE-1.64.0.md e AGENTES-1.64.0.md. As notas atuais prevalecem nos pontos alterados.

> Atualização vigente: Core 1.60.0, contrato 8.24.0. Leia RELEASE-1.60.0.md e os guias 1.60 para as alterações dos pedidos 322 e 330–334; as regras anteriores incompatíveis são históricas.

> Consolidação 1.57.1: leia RELEASE-1.57.1.md para as correções e campos opcionais dos pedidos 312/313. Base direta canônica 1.57.0.

# Fator3 Site Core 1.57.1

Comece em DOCUMENTACAO.md e AGENTES-1.57.1.md. Pedidos 312/313 em RELEASE-1.57.1.md, ACERVO-GA4-1.57.md e INSTAGRAM-EXCLUSAO-1.57.md. Pedidos anteriores 307–311 permanecem documentados em history/RELEASE-1.56.0.md e CONVERSAS-1.56.md; contatos externos do pedido 302 em CONTATOS-EXTERNOS-1.54.md. Contrato administrativo 8.22.1, cliente pipedrive-api-client/1.0.0 preservado.
