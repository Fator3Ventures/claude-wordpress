# Guia de agentes — Core 1.64.0

Leia DOCUMENTACAO.md e RELEASE-1.64.0.md; contrato 8.29.0. Descubra schemas antes da escrita, simule e preserve revisão/CAS. Não invente credenciais nem concessões dos acompanhantes.

Build: autoload-map.php por build/autoload.py; bootstrap-hooks.php por build/bootstrap-methods.php; consumer-hooks.php por build/consumer-methods.php; cron-tarefas.php por build/cron-map.php; zelador-condicoes.php por build/keeper-map.php. Compile em WordPress descartável. Mudança em iniciar() ou condições exige recompilação. Teste a lista fechada de classes públicas e renderização real até footer.

Use cron CLI a cada 15 minutos. Confirme heartbeat e run_id no diário antes de atribuir a rotina ao servidor. Retirada de público deve remover descoberta e impedir Markdown imediatamente. No reparo de estrutura, confira a escrita recusada, aviso, job e sucesso posterior em bancada; não derrube coluna de produção para fabricar evidência.

MCP 0.38.0 evita catálogo antecipado; SDKs Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0 e Pipedrive 0.5.0 preservados. Pipedrive exige PHP 8.3.36; Core mantém PHP 8.3.6 / WP 7.1.2. Teste abaixo do mínimo do acompanhante não comprova ativação dele.

Somente o instalador vai ao WordPress. Fonte inclui compiladores e evidências sanitizadas. Consulte relatório externo para hashes, tamanho, ambiente e pendências de aceite.
