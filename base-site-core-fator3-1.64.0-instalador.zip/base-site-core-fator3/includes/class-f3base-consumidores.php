<?php
/** Lightweight SDK declarations, retaining the original registration window and identity. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Consumidores {
    private static ?array $map=null;
    private static array $state=[];
    public static function descobrir(string $class,$sdk,string $contract): void {
        if(defined('F3BASE_BUILD_CONSUMERS')&&F3BASE_BUILD_CONSUMERS){$class::descobrir($sdk,$contract);return;}
        if(self::$map===null){self::$map=require __DIR__.'/consumer-hooks.php';}
        if(!isset(self::$map[$class])){return;}
        self::$state[$class]??=self::$map[$class]['defaults'];
        (self::$map[$class]['register'])($sdk,$contract,self::$state[$class]);
        self::vincular($class);
    }
    public static function vincular(string $class): void {
        if(!isset(self::$state[$class])||!class_exists($class,false)){return;}
        foreach(self::$state[$class] as $name=>$value){$p=new ReflectionProperty($class,$name);$p->setValue(null,$value);}
    }
}
