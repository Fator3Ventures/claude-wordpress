<?php
/** Registros mínimos gerados; a implementação só é carregada quando o hook é usado. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Bootstrap {
    private static ?array $hooks=null;
    private static array $iniciadas=array();
    public static function iniciar(string $class): void {
        if(isset(self::$iniciadas[$class])){return;}self::$iniciadas[$class]=true;
        if(defined('F3BASE_BUILD_BOOTSTRAP')&&F3BASE_BUILD_BOOTSTRAP){$class::iniciar();return;}
        if(self::$hooks===null){self::$hooks=require __DIR__.'/bootstrap-hooks.php';}
        if(isset(self::$hooks[$class])){(self::$hooks[$class])();}else{$class::iniciar();}
    }
}
