<?php
/** Clarity live exports and local quota. Reads never perform HTTP. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Clarity {
    const EVENTO='f3base_clarity_coletar';
    const API='https://www.clarity.ms/export-data/api/v1/project-live-insights';
    const DIMENSOES=array('Browser','Device','Country/Region','OS','Source','Medium','Campaign','Channel','URL');
    public static function iniciar(): void {
        add_action('admin_post_f3base_clarity_testar',array(F3Base_Admin_Clarity::class,'enviar'));
        add_action('f3base_clarity_retomar',array(__CLASS__,'cron'));
        add_action('f3base_zelador',array(__CLASS__,'agendar'),45);add_action(self::EVENTO,array(__CLASS__,'cron'));add_action('wp_abilities_api_init',array(__CLASS__,'registrar'));
        add_action('updated_option',array(__CLASS__,'alteracao'),20,3);add_action('added_option',static function($n,$v){self::alteracao($n,null,$v);},20,2);
        add_action('admin_post_f3base_clarity_csv',array(__CLASS__,'csv'));
    }
    public static function catalogo(array $c): array {
        $c['f3base_clarity_api_token']=array('rotulo'=>'Token de exportação do Clarity','descricao'=>'Cole o token gerado em Settings → Data Export do projeto acima. É cifrado no servidor e nunca reapresentado. Salve primeiro; depois use Testar token e coletar agora.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'segredo','padrao'=>'','autoload'=>false,'sanitiza'=>static fn($v)=>is_string($v)?trim($v):'','schema_config'=>array('type'=>'string','maxLength'=>8192),'schema_entrada'=>array('type'=>'string','maxLength'=>8192),'recusa'=>static fn($v)=>F3Base_Segredos::recusar('f3base_clarity_api_token',$v));
        $c['f3base_clarity']=array('rotulo'=>'Histórico analítico do Clarity','descricao'=>'Coletas móveis independentes de 24, 48 e 72 horas. Reduzir a retenção elimina consultas antigas na próxima limpeza. Padrão de 60 meses em instalação nova. Não inclui gravações individuais.','operavel'=>true,'secao'=>F3Base_Options::SECAO_MEDICAO,'campo'=>'grupo','padrao'=>array('coleta_ativa'=>true,'retencao_meses'=>0),'subcampos'=>array('coleta_ativa'=>array('tipo'=>'booleano','rotulo'=>'Coletar diariamente quando houver token vinculado','descricao'=>'Sem projeto/token, nenhuma chamada. Oito recortes automáticos por dia. Duas consultas adicionais são compartilhadas entre testes manuais e retentativas; teto total de dez por projeto/dia.'),'retencao_meses'=>array('tipo'=>'inteiro','rotulo'=>'Retenção do acervo em meses (0: preservar)','descricao'=>'Política independente da retenção editorial. Reduzir apaga definitivamente consultas anteriores ao corte.')),'sanitiza'=>array(F3Base_Evolucao::class,'sanitizar'),'recusa'=>static function($v,$d){$error=F3Base_Evolucao::recusar($v,$d);if($error){return $error;}return isset($v['retencao_meses'])&&(!is_int($v['retencao_meses'])||$v['retencao_meses']<1||$v['retencao_meses']>120)?'Informe 1 a 120 meses.':'';});
        $c['f3base_clarity_estado']=array('rotulo'=>'Estado Clarity','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));
        return $c;
    }
    public static function alteracao($nome,$antes,$depois): void {
        if($nome!=='f3base_clarity_api_token'||$antes===$depois){return;}
        // Bind only to the persisted project, never to an uncommitted proposal.
        $projeto=(string)get_option('f3base_clarity_project_id','');$rev=F3Base_Options::revisao($nome);
        F3Base_Options::atualizar_estado('f3base_clarity_estado',static function($s)use($projeto,$rev){$s['credencial']=array_merge(($s['credencial']['projeto']??'')===$projeto?($s['credencial']??array()):array(),array('projeto'=>$projeto,'revisao'=>$rev));if(!isset($s['credencial']['vinculada_em'])){$s['credencial']['vinculada_em']=time();}return $s;});
    }
    public static function configurado(): bool {
        $project=(string)F3Base_Options::ler('f3base_clarity_project_id');$s=F3Base_Options::ler('f3base_clarity_estado');
        return $project!==''&&($s['credencial']['projeto']??'')===$project&&($s['credencial']['revisao']??'')===F3Base_Options::revisao('f3base_clarity_api_token')&&F3Base_Segredos::status('f3base_clarity_api_token')['estado']==='disponivel';
    }
    public static function agendar(): void {
        if(self::configurado()&&!empty(F3Base_Options::ler('f3base_clarity')['coleta_ativa'])){if(!wp_next_scheduled(self::EVENTO)){wp_schedule_event(time()+300,'daily',self::EVENTO);}}
        elseif(wp_next_scheduled(self::EVENTO)){wp_clear_scheduled_hook(self::EVENTO);}
    }
    public static function orcamento(string $project,string $tipo='exportacao'): array {
        $key='f3base_clarity_cota_'.hash('sha256',$project.'|'.$tipo);$s=get_option($key,array());$day=gmdate('Y-m-d');
        if(($s['dia']??'')!==$day){$s=array('dia'=>$day,'automaticas'=>0,'manuais'=>0,'retentativas'=>0,'bloqueado_ate'=>$s['bloqueado_ate']??0);}
        $s['chamadas_reservadas_total']=(int)$s['automaticas']+(int)$s['manuais'];return $s+array('projeto'=>$project,'retentativas'=>0,'reserva_compartilhada'=>2,'limite_automatico'=>$tipo==='exportacao'?8:0,'limite_manual'=>$tipo==='exportacao'?2:4,'contador'=>'consumo_local_conhecido; outros consumidores podem usar a cota do projeto','reinicio'=>'dia UTC operacional local; hora exata do fornecedor não especificada');
    }
    public static function reservar_cota(string $project,bool $auto,string $tipo='exportacao',bool $retry=false): array {
        // Caller holds the project lock; write must be read back before any HTTP.
        $s=self::orcamento($project,$tipo);$bucket=$auto?'automaticas':'manuais';$limit=$auto?$s['limite_automatico']:$s['limite_manual'];
        if((int)($s['bloqueado_ate']??0)>time()){return array('ok'=>false,'codigo'=>'aguardando_cota_remota','cota'=>$s);}
        if(($auto?($retry?$s['retentativas']+$s['manuais']>=2:$s['automaticas']-$s['retentativas']>=$limit):($s['manuais']+$s['retentativas']>=$limit))||$s['automaticas']+$s['manuais']>=($tipo==='exportacao'?10:4)){return array('ok'=>false,'codigo'=>'cota_local_esgotada','cota'=>$s);}
        ++$s[$bucket];if($auto&&$retry){++$s['retentativas'];}$key='f3base_clarity_cota_'.hash('sha256',$project.'|'.$tipo);update_option($key,$s,false);
        if(get_option($key)!==$s){return array('ok'=>false,'codigo'=>'reserva_cota_falhou');}return array('ok'=>true,'cota'=>$s);
    }
    public static function limitar_remoto(string $project,$response,string $tipo='exportacao'): void {
        $s=self::orcamento($project,$tipo);$retry=wp_remote_retrieve_header($response,'retry-after');$delay=is_numeric($retry)?(int)$retry:max(0,(int)strtotime((string)$retry)-time());
        $s['bloqueado_ate']=$delay>0?time()+min(7*DAY_IN_SECONDS,$delay):strtotime('tomorrow UTC');update_option('f3base_clarity_cota_'.hash('sha256',$project.'|'.$tipo),$s,false);
    }
    public static function consultar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        return self::executar($e,false);
    }
    /** Bounded local diagnostic; never persist the credential or an unfiltered response. */
    public static function diagnostico_erro(string $body,string $token,string $retry=''): array {
        $original=strlen($body);
        if($token!==''){$body=str_replace(array($token,rawurlencode($token),base64_encode($token),htmlspecialchars($token,ENT_QUOTES,'UTF-8')),'[credencial removida]',$body);}
        $json=json_decode($body,true,24);if(is_array($json)){$removed=array();$body=wp_json_encode(F3Base_Clarity_Acervo::sanear($json,$removed),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
        if($token!==''){$body=str_replace($token,'[credencial removida]',$body);}
        $body=wp_strip_all_tags($body);
        $body=preg_replace('~\bBearer\s+[^\s,;]+|\b(?:token|api[_-]?key|authorization|password|secret|cookie)\s*[:=]\s*[^\s,;]+~i','[credencial removida]',$body);
        $body=preg_replace('~[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|\b(?:\d{1,3}\.){3}\d{1,3}\b~i','[dado removido]',$body);
        $body=wp_check_invalid_utf8(substr(preg_replace('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/','',$body),0,1024),true);
        $retry=trim($retry);$safe=preg_match('/^\d{1,9}$/D',$retry)?$retry:((strlen($retry)<=64&&preg_match('/^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} [A-Za-z]{3} \d{4} \d{2}:\d{2}:\d{2} GMT$/D',$retry))?$retry:'');
        return array('corpo'=>$body,'truncado'=>$original>1024,'retry_after'=>$safe,'saneamento'=>'erro-http-1','limite_bytes'=>1024);
    }
    private static function executar(array $e,bool $auto): array {
        $days=$e['dias']??1;$dims=$e['dimensoes']??array();
        if(!is_int($days)||!in_array($days,array(1,2,3),true)||!is_array($dims)||count($dims)>3||count(array_unique($dims))!==count($dims)||array_diff($dims,self::DIMENSOES)){return array('ok'=>false,'codigo'=>'parametros_invalidos');}
        if(!self::configurado()){return array('ok'=>false,'codigo'=>'projeto_ou_credencial_nao_vinculada');}
        $project=(string)F3Base_Options::ler('f3base_clarity_project_id');$lock=F3Base_Trava::adquirir('clarity-'.$project,120);if(!$lock){return array('ok'=>false,'codigo'=>'coleta_em_andamento');}
        global $wpdb;
        try{
            $fotos=array('revisao_projeto'=>F3Base_Options::fotografia_bruta('f3base_clarity_project_id'),'revisao_token'=>F3Base_Options::fotografia_bruta('f3base_clarity_api_token'));$credencial=F3Base_Options::ler('f3base_clarity_estado')['credencial']??array();
            if($fotos['revisao_projeto']['erro']||$fotos['revisao_token']['erro']||$project!==$fotos['revisao_projeto']['valor']||($credencial['projeto']??'')!==$project||($credencial['revisao']??'')!==$fotos['revisao_token']['revisao']){return array('ok'=>false,'codigo'=>'configuracao_alterada');}
            foreach($fotos as $key=>$foto){if(isset($e[$key])&&(!is_string($e[$key])||!hash_equals($foto['revisao'],$e[$key]))){return array('ok'=>false,'codigo'=>'configuracao_alterada');}}
            $token=F3Base_Segredos::abrir('f3base_clarity_api_token',$fotos['revisao_token']['valor']);
            if($token===''){return array('ok'=>false,'codigo'=>'projeto_ou_credencial_nao_vinculada');}
            F3Base_Clarity_Acervo::recuperar();$params=array('dias'=>$days,'dimensoes'=>$dims);$given=(string)($e['idempotency_key']??wp_generate_uuid4());
            if(strlen($given)<8||strlen($given)>128){return array('ok'=>false,'codigo'=>'chave_invalida');}
            $key=hash('sha256',$given);$old=$wpdb->get_row($wpdb->prepare('SELECT id,parametros,estado,motivo,http FROM %i WHERE projeto=%s AND chave=%s',F3Base_Clarity_Acervo::tabela(),$project,$key),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
            if($old){return $old['parametros']!==wp_json_encode($params)?array('ok'=>false,'codigo'=>'idempotencia_divergente'):array('ok'=>in_array($old['estado'],array('resposta_disponivel','possivelmente_truncada'),true),'codigo'=>$old['motivo']?:$old['estado'],'coleta'=>$old['id'],'estado'=>$old['estado'],'http'=>(int)$old['http'],'duplicado'=>true,'http_repetido'=>false);}
            $remaining=min(28,F3Base_Execucoes::deadline()-microtime(true)-3);if($remaining<25){return array('ok'=>false,'codigo'=>'adiada_por_orcamento_de_tempo');}$timeout=min(25,(int)$remaining);$budget=self::reservar_cota($project,$auto,'exportacao',$auto&&!empty($e['retentativa']));if(empty($budget['ok'])){return $budget;}
            $id=bin2hex(random_bytes(16));$start=time();$m=microtime(true);$row=array('id'=>$id,'projeto'=>$project,'chave'=>$key,'parametros'=>wp_json_encode($params),'origem'=>$auto?'cron':'manual','solicitado_em'=>$start,'janela_dias'=>$days,'inicio_nominal'=>$start-$days*DAY_IN_SECONDS,'fim_nominal'=>$start,'estado'=>'solicitando','cobertura'=>wp_json_encode(array('cota'=>$budget['cota'],'motivo'=>$e['motivo']??'solicitacao_explicita')));
            if(!$wpdb->insert(F3Base_Clarity_Acervo::tabela(),$row)){return array('ok'=>false,'codigo'=>'tentativa_nao_persistida');}
            $q=array('numOfDays'=>$days);foreach($dims as $i=>$dim){$q['dimension'.($i+1)]=$dim;}
            $response=wp_safe_remote_get(add_query_arg($q,self::API),array('timeout'=>$timeout,'redirection'=>0,'limit_response_size'=>F3Base_Clarity_Acervo::MAX_RESPOSTA+1,'headers'=>array('Authorization'=>'Bearer '.$token,'Accept'=>'application/json')));
            $received=time();$ms=(int)round((microtime(true)-$m)*1000);$http=is_wp_error($response)?0:(int)wp_remote_retrieve_response_code($response);$body=is_wp_error($response)?'':wp_remote_retrieve_body($response);
            if($http===429){self::limitar_remoto($project,$response);}
            if($http!==200||strlen($body)>F3Base_Clarity_Acervo::MAX_RESPOSTA){$code=$http===429?'cota_remota':($http===401||$http===403?'credencial_recusada':($http===200?'resposta_excessiva':'falha_http'));$wpdb->update(F3Base_Clarity_Acervo::tabela(),array('estado'=>'falha','motivo'=>$code,'http'=>$http,'recebido_em'=>$received,'duracao_ms'=>$ms,'cobertura'=>wp_json_encode(array('cota'=>$budget['cota'],'erro_http'=>self::diagnostico_erro($body,$token,is_wp_error($response)?'':(string)wp_remote_retrieve_header($response,'retry-after'))))),array('id'=>$id));return array('ok'=>false,'codigo'=>$code,'coleta'=>$id,'http'=>$http);}
            $json=json_decode($body,true,32,JSON_BIGINT_AS_STRING);
            if(!is_array($json)){$wpdb->update(F3Base_Clarity_Acervo::tabela(),array('estado'=>'invalida','motivo'=>'json_invalido','http'=>$http,'recebido_em'=>$received,'duracao_ms'=>$ms),array('id'=>$id));return array('ok'=>false,'codigo'=>'json_invalido','coleta'=>$id);}
            $result=F3Base_Clarity_Acervo::receber($id,$json,$http,$received,$ms);
            if(empty($result['ok'])){$wpdb->update(F3Base_Clarity_Acervo::tabela(),array('estado'=>'persistencia_pendente','motivo'=>$result['codigo']),array('id'=>$id));}
            return $result+array('cota'=>$budget['cota']);
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function cron(): void {if(!empty(F3Base_Options::ler('f3base_clarity')['coleta_ativa'])){self::coletar_interno();}F3Base_Clarity_Acervo::reter();}
    public static function plano(): array {return array(array(1,array()),array(1,array('URL','Device')),array(1,array('URL','Channel')),array(3,array()),array(3,array('URL','Device')),array(3,array('URL','Channel')),array(1,array('Source','Medium','Campaign')),array(1,array('Browser','OS','Country/Region')));}
    public static function plano_resumo(string $project): array {
        $p=F3Base_Options::ler('f3base_clarity_estado')['plano']??array();$id=gmdate('Y-m-d').'|'.$project.'|'.F3Base_Options::revisao('f3base_clarity_api_token');$rows=($p['identidade']??'')===$id?($p['recortes']??array()):array();$ok=count(array_filter($rows,static fn($r)=>!empty($r['ok'])));
        $quota=self::orcamento($project);
        foreach(self::plano() as [$days,$dims]){$hash=hash('sha256',wp_json_encode(array($days,$dims)));if(!empty($rows[$hash]['tentativas_http'])){continue;}$reason=(int)($quota['bloqueado_ate']??0)>time()?'cota_remota':(($quota['automaticas']+$quota['manuais'])>=10?'cota_local':'janela');$rows[$hash]=array('dias'=>$days,'dimensoes'=>$dims,'tentativas_http'=>0,'ok'=>false,'estado'=>'nao_consultado','codigo'=>$reason,'em'=>time());}
        return array('dia_utc'=>gmdate('Y-m-d'),'recortes_previstos'=>8,'recortes_com_resposta'=>$ok,'recortes_sem_resposta'=>max(0,8-$ok),'completo'=>$ok===8,'recortes'=>array_values($rows),'cota_reservada'=>'Duas consultas compartilhadas entre manual e retentativa; todas as tentativas HTTP contam no teto de dez.');
    }
    public static function coletar(array $e=array()): array {return current_user_can('manage_options')?self::coletar_interno():array('ok'=>false,'codigo'=>'sem_permissao');}
    private static function coletar_interno(): array {
        if(!self::configurado()){return array('ok'=>false,'codigo'=>'projeto_ou_credencial_nao_vinculada');}
        $plan=self::plano();
        $project=(string)F3Base_Options::ler('f3base_clarity_project_id');$identity=gmdate('Y-m-d').'|'.$project.'|'.F3Base_Options::revisao('f3base_clarity_api_token');$saved=F3Base_Options::ler('f3base_clarity_estado');$progress=($saved['plano']['identidade']??'')===$identity?$saved['plano']:array('identidade'=>$identity,'recortes'=>array());
        $selected=null;$retry=null;foreach($plan as [$days,$dims]){$hash=hash('sha256',wp_json_encode(array($days,$dims)));$prev=$progress['recortes'][$hash]??array();if(empty($prev['tentativas_http'])&&($prev['tentar_em']??0)<=time()&&$selected===null){$selected=[$days,$dims,$hash];}if($prev&&empty($prev['ok'])&&($prev['tentar_em']??0)<=time()&&$retry===null){$retry=[$days,$dims,$hash];}}
        $quota=self::orcamento($project);$podeRetry=$retry&&(empty($progress['recortes'][$retry[2]]['tentativas_http'])||$quota['retentativas']+$quota['manuais']<2);$selected=$selected??($podeRetry?$retry:null);if(!$selected){$completa=count(array_filter($progress['recortes'],static fn($x)=>!empty($x['ok'])))===count($plan);return array('ok'=>$completa,'parcial'=>!$completa,'codigo'=>$completa?'plano_diario_concluido':'plano_diario_incompleto','recortes_pendentes'=>count($plan)-count(array_filter($progress['recortes'],static fn($x)=>!empty($x['ok']))),'plano'=>$progress);}
        [$days,$dims,$hash]=$selected;$attempt=(int)($progress['recortes'][$hash]['tentativa']??0)+1;
        $r=self::executar(array('dias'=>$days,'dimensoes'=>$dims,'idempotency_key'=>'cron-'.hash('sha256',$identity.'|'.$hash).'|'.$attempt,'motivo'=>'plano_diario','retentativa'=>!empty($progress['recortes'][$hash]['tentativas_http'])),true);
        $quota=self::orcamento($project);$next=max(time()+300,(int)($quota['bloqueado_ate']??0));if(($quota['automaticas']+$quota['manuais'])>=10||(($quota['automaticas']-$quota['retentativas'])>=8&&($quota['retentativas']+$quota['manuais'])>=2)){$next=max($next,strtotime('tomorrow UTC')+300);}
        $progress['recortes'][$hash]=array('dias'=>$days,'dimensoes'=>$dims,'tentativa'=>$attempt,'tentativas_http'=>(int)($progress['recortes'][$hash]['tentativas_http']??0)+(!empty($r['coleta'])?1:0),'http'=>$r['http']??null,'em'=>time(),'ok'=>!empty($r['ok']),'estado'=>$r['estado']??'nao_concluido','codigo'=>$r['codigo']??'','coleta'=>$r['coleta']??null,'tentar_em'=>$next);
        foreach($plan as [$pd,$pm]){$ph=hash('sha256',wp_json_encode(array($pd,$pm)));if(!empty($progress['recortes'][$ph]['tentativas_http'])){continue;}$reason=(int)($quota['bloqueado_ate']??0)>time()?'cota_remota':(($quota['automaticas']+$quota['manuais'])>=10?'cota_local':(($r['codigo']??'')==='adiada_por_orcamento_de_tempo'?'orcamento_de_tempo':'janela'));$progress['recortes'][$ph]=array('dias'=>$pd,'dimensoes'=>$pm,'tentativas_http'=>0,'ok'=>false,'estado'=>'nao_consultado','codigo'=>$reason,'em'=>time(),'tentar_em'=>0);}
        $all=count(array_filter($progress['recortes'],static fn($x)=>!empty($x['ok'])))===count($plan);$s=array('em'=>time(),'consultas'=>array_values($progress['recortes']),'completa'=>$all,'recortes_previstos'=>count($plan),'recortes_concluidos'=>count(array_filter($progress['recortes'],static fn($x)=>!empty($x['ok']))),'recortes_pendentes'=>count($plan)-count(array_filter($progress['recortes'],static fn($x)=>!empty($x['ok']))),'proxima'=>$all?null:$next);
        F3Base_Options::atualizar_estado('f3base_clarity_estado',static function($state)use($s,$progress){$state['ultima_execucao']=$s;if(!empty($state['plano']['identidade'])&&$state['plano']['identidade']!==$progress['identidade']){$state['historico_planos'][$state['plano']['identidade']]=$state['plano'];$state['historico_planos']=array_slice($state['historico_planos'],-90,null,true);}$state['plano']=$progress;return $state;});if(!$all){F3Base_Fila::agendar('f3base_clarity_retomar',$next);}return array('ok'=>!empty($r['ok']),'parcial'=>!$all,'execucao'=>$s,'credencial'=>array('estado'=>F3Base_Segredos::status('f3base_clarity_api_token')['estado'],'projeto'=>$project,'vinculada'=>self::configurado()));
    }

    public static function registrar(): void {
        $dims=array('type'=>'array','maxItems'=>3,'uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>self::DIMENSOES));$id=array('type'=>'string','pattern'=>'^[a-f0-9]{32}$');
        F3Base_Servicos::ability('clarity-ler','Histórico local de consultas móveis; nenhuma chamada externa',array(F3Base_Clarity_Acervo::class,'ler'),array('modo'=>array('type'=>'string','enum'=>array('resumo','consultas','resposta')),'projeto'=>array('type'=>'string','pattern'=>'^[a-z0-9]{1,32}$'),'coleta'=>$id,'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'pagina'=>array('type'=>'integer','minimum'=>1,'maximum'=>100000),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>100)));
        F3Base_Servicos::ability('clarity-comparar','Comparar consultas locais compatíveis sem inventar decomposição diária',array(F3Base_Clarity_Acervo::class,'comparar'),array('anterior'=>$id,'atual'=>$id,'pagina'=>array('type'=>'integer','minimum'=>1)),array('anterior','atual'));
        F3Base_Servicos::ability('clarity-consultar','Consultar API ao vivo e guardar resposta sanitizada, consumindo cota',array(__CLASS__,'consultar'),array('dias'=>array('type'=>'integer','enum'=>array(1,2,3)),'dimensoes'=>$dims,'idempotency_key'=>array('type'=>'string','minLength'=>8,'maxLength'=>128)),array('idempotency_key'),false);
        F3Base_Servicos::ability('clarity-coletar','Executar plano diário dentro da cota automática e preservar histórico',array(__CLASS__,'coletar'),array(),array(),false);
        F3Base_Servicos::ability('clarity-reprocessar','Reprocessar fonte sanitizada local sem consumir API',static fn($e)=>F3Base_Clarity_Acervo::normalizar($e['coleta']),array('coleta'=>$id),array('coleta'),false);
        F3Base_Servicos::ability('clarity-exportar','Exportar consulta sanitizada com hash e resposta comprimida',array(F3Base_Clarity_Acervo::class,'exportar'),array('coleta'=>$id),array('coleta'));
        F3Base_Servicos::ability('clarity-restaurar','Restaurar consulta sanitizada verificada sem consumir API',array(F3Base_Clarity_Acervo::class,'restaurar'),array('arquivo'=>array('type'=>'object')),array('arquivo'),false);
        F3Base_Clarity_Gravacoes::registrar();
    }
    private static function linhas_visiveis(array $rows): array {
        $out=array();$names=array('totalSessionCount'=>'Sessões','distinctUserCount'=>'Usuários distintos','distantUserCount'=>'Usuários distintos (campo do fornecedor)','deadClickCount'=>'Cliques sem efeito','rageClickCount'=>'Cliques de frustração');
        foreach($rows as $r){$dims=array();foreach($r['dimensoes'] as $k=>$v){if($k!=='URL'){$dims[]=$k.': '.(is_scalar($v)?(string)$v:wp_json_encode($v));}}foreach($r['valores'] as $k=>$v){if(array_key_exists($k,$r['dimensoes'])||in_array($k,array('URL','url'),true)){continue;}$out[]=array('pagina'=>$r['caminho']?:'Outro recorte / não resolvido','recorte'=>$dims?implode(' · ',$dims):'Total do recorte','metrica'=>$r['metrica'].' · '.($names[$k]??$k),'valor'=>$v);}}
        return $out;
    }
    public static function render(): void {
        if(!current_user_can('manage_options')){return;}
        $e=array('modo'=>'consultas');foreach(array('projeto','coleta','de','ate') as $k){if(isset($_GET[$k])&&is_string($_GET[$k])){$e[$k]=sanitize_text_field(wp_unslash($_GET[$k]));}}$e['pagina']=max(1,(int)($_GET['pagina']??1));
        $r=F3Base_Clarity_Acervo::ler($e);echo '<h2>Clarity — consultas preservadas</h2><p>As janelas de 24, 48 e 72 horas se sobrepõem. Não são totais diários nem parcelas somáveis de um mês.</p><p>Retenção própria: '.esc_html((string)($r['retencao_meses']??0)).' meses. Token ausente ou vinculado a outro projeto mantém a coleta inativa.</p>';
        echo '<form class="f3m-filters" method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="clarity">';foreach(array('projeto'=>'Projeto','de'=>'Consultas desde (UTC)','ate'=>'Consultas até (UTC)') as $key=>$label){echo '<label>'.esc_html($label).' <input type="'.($key==='projeto'?'text':'date').'" name="'.esc_attr($key).'" value="'.esc_attr($e[$key]??($key==='projeto'?($r['projeto']??''):'')).'"></label> ';}echo '<button class="button">Consultar acervo local</button></form>';
        if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']).'</p>';return;}
        $choices=F3Base_Clarity_Acervo::ler(array('modo'=>'consultas','projeto'=>$r['projeto'],'limite'=>100));
        if(count($choices['consultas']??array())>1){
            echo '<details><summary>Comparar duas consultas preservadas</summary><p>Escolha recortes completos do mesmo projeto, dimensões e janela. Os valores são apresentados lado a lado, sem somar janelas móveis.</p><form class="f3m-filters" method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="clarity"><input type="hidden" name="projeto" value="'.esc_attr($r['projeto']).'">';
            foreach(array('anterior'=>'Consulta anterior','atual'=>'Consulta atual') as $key=>$label){echo '<label>'.esc_html($label).' <select name="'.$key.'">';foreach($choices['consultas'] as $c){echo '<option value="'.esc_attr($c['id']).'" '.selected($_GET[$key]??'',$c['id'],false).'>'.esc_html(wp_date('d/m H:i:s',(int)$c['solicitado_em']).' · '.$c['janela_dias'].'d · '.implode(' × ',$c['parametros']['dimensoes']).' · '.$c['estado']).'</option>';}echo '</select></label> ';}echo '<button class="button">Comparar</button></form></details>';
        }
        if(isset($_GET['anterior'],$_GET['atual'])&&is_string($_GET['anterior'])&&is_string($_GET['atual'])){
            $comparison=F3Base_Clarity_Acervo::comparar(array('anterior'=>sanitize_key($_GET['anterior']),'atual'=>sanitize_key($_GET['atual']),'pagina'=>$e['pagina']));
            if(empty($comparison['ok'])){echo '<p role="alert">Consultas incompatíveis ou indisponíveis para comparação.</p>';}else{
                echo '<h3>Comparação de consultas</h3><p>'.esc_html($comparison['comparacao']).'</p><div class="f3base-clarity-comparacao">';foreach(array('anterior'=>'Anterior','atual'=>'Atual') as $key=>$label){$part=$comparison[$key];echo '<section><h4>'.esc_html($label.' · '.wp_date('d/m/Y H:i:s',(int)$part['coleta']['solicitado_em'])).'</h4>';F3Base_Relatorios::tabela(self::linhas_visiveis($part['linhas']));echo '</section>';}echo '</div>';if($comparison['anterior']['proxima_pagina']||$comparison['atual']['proxima_pagina']){echo '<a class="button" href="'.esc_url(add_query_arg('pagina',$e['pagina']+1)).'">Próximas linhas da comparação</a>';}
            }
        }
        if(isset($r['coleta'])){
            $c=$r['coleta'];echo '<h3>Consulta '.esc_html($c['id']).'</h3><p>Janela nominal: '.esc_html(gmdate('d/m/Y H:i:s',(int)$c['inicio_nominal']).' a '.gmdate('d/m/Y H:i:s',(int)$c['fim_nominal'])).' UTC. Estado: '.esc_html($c['estado']).'.</p>';
            F3Base_Relatorios::tabela(self::linhas_visiveis($r['linhas']));
            if(!empty($r['contexto_core']['linhas'])){echo '<h3>Contexto do Core nas mesmas páginas e instantes nominais</h3><p>'.esc_html($r['contexto_core']['limite']).'</p>';F3Base_Relatorios::tabela($r['contexto_core']['linhas']);}
            echo '<p>Para contexto de leads, seções e IA, abra o mesmo conteúdo no relatório do Core com período próprio. Esse vínculo agregado não identifica pessoas nem associa uma gravação a um contato.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_clarity_csv"><input type="hidden" name="coleta" value="'.esc_attr($c['id']).'"><input type="hidden" name="projeto" value="'.esc_attr($c['projeto']).'">';wp_nonce_field('f3base-clarity-csv');echo '<button class="button">CSV desta consulta</button></form>';
        }else{
            echo '<table class="widefat striped"><thead><tr><th>Consulta (horário do site)</th><th>Janela / dimensões</th><th>Qualidade</th><th>Duração</th></tr></thead><tbody>';
            foreach($r['consultas'] as $c){$url=add_query_arg(array('page'=>'f3base-medicao','area'=>'clarity','coleta'=>$c['id'],'projeto'=>$c['projeto']),admin_url('admin.php'));echo '<tr><td><a href="'.esc_url($url).'">'.esc_html(wp_date('d/m/Y H:i:s P',(int)$c['solicitado_em'])).'</a></td><td>'.(int)$c['janela_dias'].' dia(s) · '.esc_html(implode(' × ',$c['parametros']['dimensoes']??array())?:'Total do projeto').'</td><td>'.esc_html($c['estado'].($c['motivo']?' · '.$c['motivo']:'')).'</td><td>'.(int)$c['duracao_ms'].' ms</td></tr>';}
            echo '</tbody></table><details><summary>Acervo, consumo conhecido e limites</summary><pre>'.esc_html(wp_json_encode(array('acervo'=>$r['acervo'],'cota'=>$r['cota'],'cobertura_nominal'=>$r['cobertura_nominal']??array()),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</pre></details>';
        }
        if($r['proxima_pagina']){echo '<p><a class="button" href="'.esc_url(add_query_arg('pagina',$r['proxima_pagina'])).'">Próxima página</a></p>';}
        echo '<p><a href="'.esc_url(F3Base_Interface::url('f3base_clarity_api_token')).'">Configurar ou testar o token de exportação</a>. Abrir este relatório não faz chamadas externas. Contrato em docs/CLARITY-1.22.md; coleta e reprocessamento também estão disponíveis no canal autenticado.</p>';
    }
    public static function csv(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-clarity-csv');
        $e=array('coleta'=>sanitize_key($_POST['coleta']??''),'projeto'=>sanitize_key($_POST['projeto']??''),'pagina'=>1,'limite'=>100);$all=array();do{$r=F3Base_Clarity_Acervo::ler($e);if(empty($r['ok'])||empty($r['coleta'])||count($all)>50000){wp_die('Consulta indisponível.',400);}$all=array_merge($all,$r['linhas']);$e['pagina']=$r['proxima_pagina'];}while($e['pagina']);
        nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="f3base-clarity-consulta.csv"');$h=fopen('php://output','w');fputcsv($h,array('coleta','projeto','inicio_nominal_utc','fim_nominal_utc','janela_dias','estado','metrica','dimensoes','valores','post_id','caminho'));
        foreach($all as $row){$c=$r['coleta'];$v=array($c['id'],$c['projeto'],gmdate('c',(int)$c['inicio_nominal']),gmdate('c',(int)$c['fim_nominal']),$c['janela_dias'],$c['estado'],$row['metrica'],wp_json_encode($row['dimensoes']),wp_json_encode($row['valores']),$row['post_id'],$row['caminho']);fputcsv($h,array_map(array(F3Base_Acessos_Relatorio::class,'celula_csv'),$v));}fclose($h);exit;
    }
}
