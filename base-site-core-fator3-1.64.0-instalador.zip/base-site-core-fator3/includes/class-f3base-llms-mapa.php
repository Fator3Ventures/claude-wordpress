<?php
/** Small autoloaded discovery index; representations stay out of the page bootstrap. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Llms_Mapa {
    const MAPA='f3base_llms_mapa';
    const ASSINATURA='f3base_llms_assinatura';
    public static function iniciar(): void {
        add_action('save_post',array(__CLASS__,'invalidar'),1);
        add_action('transition_post_status',array(__CLASS__,'transicao'),1,3);
        add_action('wpseo_saved_postdata',array(__CLASS__,'invalidar'),1);
        foreach(array('added_post_meta','updated_post_meta','deleted_post_meta') as $h){add_action($h,array(__CLASS__,'meta'),1,4);}
        add_action('before_delete_post',array(__CLASS__,'invalidar'),1);
        add_action('updated_option',array(__CLASS__,'opcao'),1,3);
    }
    public static function transicao($new,$old,$post): void {if($new!==$old){self::invalidar((int)$post->ID);}}
    public static function meta($mid,$id,$key,$value): void {if(str_starts_with((string)$key,'_yoast_wpseo_')){self::invalidar((int)$id);}}
    public static function opcao($name,$old,$new): void {
        if(in_array($name,array('f3base_llms','blog_public','permalink_structure','wpseo','wpseo_titles','home','siteurl'),true)){update_option(self::MAPA,array(),true);self::pendente();}
    }
    public static function invalidar($id): void {
        $id=(int)$id;if(!$id||wp_is_post_revision($id)||wp_is_post_autosave($id)){return;}
        $map=(array)get_option(self::MAPA,array());if(isset($map['itens'][$id])){unset($map['itens'][$id]);update_option(self::MAPA,$map,true);}
        self::pendente();
    }
    public static function pendente(): void {
        $s=(array)get_option(self::ASSINATURA,array());$s['pendente']=true;$s['proxima_verificacao']=0;update_option(self::ASSINATURA,$s,true);
        F3Base_Llms_Cobertura::agendar();
    }
    public static function publicar(array $g,bool $pending=false): void {
        $items=array();$cfg=F3Base_Options::ler('f3base_llms');$serve=!empty($cfg['ligado'])&&F3Base_Llms::site_publico()&&!empty(F3Base_Modulo_Llms_Txt_Reserva::emissor()['serve']);
        if($serve&&!empty($cfg['markdown'])){foreach($g['itens']??array() as $i){if(empty(F3Base_Llms_Cobertura::item($i)['completo'])){continue;}$id=(int)($i['id']??0);$url=F3Base_Modulo_Llms_Markdown::url_do_item($i,false);if($id&&$url!==''){$items[$id]=$url;}}}
        update_option(self::MAPA,array('revisao'=>$g['id']??'','gerada_em'=>time(),'serve'=>$serve,'describedby'=>$serve?home_url('/llms.txt'):'','itens'=>$items),true);
        update_option(self::ASSINATURA,array('assinatura_publicada'=>$g['assinatura']??'','proxima_verificacao'=>time()+3600,'pendente'=>$pending),true);
    }
}
