<?php
/** Daily GA4 snapshots: a failed or partial refresh never replaces the published snapshot. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Ga4_Acervo {
    public const ESQUEMA_VERSAO=16400;
    const VERSION='1';
    public static function tabela(string $s='coletas'): string {global $wpdb;return $wpdb->prefix.'f3base_ga4_'.$s;}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();$t=self::tabela();
        dbDelta("CREATE TABLE $t (
            id char(32) NOT NULL,
            sequencia bigint unsigned NOT NULL AUTO_INCREMENT,
            propriedade varchar(40) NOT NULL,
            recorte varchar(32) NOT NULL,
            dia date NOT NULL,
            revision char(64) NOT NULL,
            estado varchar(24) NOT NULL,
            publicado tinyint NOT NULL DEFAULT 0,
            `cursor` longtext NOT NULL,
            linhas bigint unsigned NOT NULL DEFAULT 0,
            total bigint unsigned NOT NULL DEFAULT 0,
            metadata longtext NOT NULL,
            codigo varchar(100) NOT NULL DEFAULT '',
            tentar_em bigint unsigned NOT NULL DEFAULT 0,
            criado_em bigint unsigned NOT NULL,
            atualizado_em bigint unsigned NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY sequencia (sequencia),
            KEY escopo (propriedade,recorte,dia,publicado),
            KEY pendentes (estado,tentar_em),
            KEY dia (dia)
        ) ENGINE=InnoDB $c;");$l=self::tabela('linhas');
        dbDelta("CREATE TABLE $l (
            coleta_id char(32) NOT NULL,
            chave char(64) NOT NULL,
            dimensoes longtext NOT NULL,
            metricas longtext NOT NULL,
            PRIMARY KEY  (coleta_id,chave)
        ) ENGINE=InnoDB $c;");return self::pronta();
    }
    public static function pronta(): bool { if(!F3Base_Esquema::manutencao()){return F3Base_Esquema::pronta(__CLASS__);}
        global $wpdb;
        $schema=array('coletas'=>array('id','sequencia','propriedade','recorte','dia','revision','estado','publicado','cursor','linhas','total','metadata','codigo','tentar_em','criado_em','atualizado_em'),'linhas'=>array('coleta_id','chave','dimensoes','metricas'));
        foreach($schema as $suffix=>$required){$t=self::tabela($suffix);$status=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS LIKE %s',$wpdb->esc_like($t)),ARRAY_A);if(!$status||strtolower($status['Engine']??'')!=='innodb'||array_diff($required,$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t)))){return false;}}return true;
    }
    public static function autocommit(): bool {return F3Base_Transacao::autocommit();}
    public static function tamanho(): array {
        global $wpdb;$tables=array();foreach(array('coletas','linhas') as $s){$t=self::tabela($s);$r=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS LIKE %s',$wpdb->esc_like($t)),ARRAY_A);$tables[$s]=array('linhas_estimadas'=>(int)($r['Rows']??0),'bytes_dados'=>(int)($r['Data_length']??0),'bytes_indices'=>(int)($r['Index_length']??0));}
        return array('fonte'=>'GA4','tabelas'=>$tables,'bytes_total'=>array_sum(array_column($tables,'bytes_dados'))+array_sum(array_column($tables,'bytes_indices')),'contagens_estimadas'=>true,'retencao_meses'=>F3Base_Options::ler(F3Base_Retencao_Prazos::OPTION)['retencao_ga4_meses']??0);
    }
    public static function criar(string $p,string $day,string $slice,string $revision): ?array {
        global $wpdb;$r=array('id'=>bin2hex(random_bytes(16)),'propriedade'=>$p,'recorte'=>$slice,'dia'=>$day,'revision'=>$revision,'estado'=>'em_curso','publicado'=>0,'cursor'=>'','linhas'=>0,'total'=>0,'metadata'=>'[]','codigo'=>'','tentar_em'=>0,'criado_em'=>time(),'atualizado_em'=>time());
        return $wpdb->insert(self::tabela(),$r)===1?$r:null;
    }
    public static function falhar(array $c,string $code,int $next,bool $restart=false): array {
        global $wpdb;$code=preg_match('/^[a-zA-Z0-9_:.-]{1,100}$/D',$code)?$code:'sdk_falha';$ok=$wpdb->update(self::tabela(),array('estado'=>$restart?'reiniciar':'aguardando','codigo'=>$code,'tentar_em'=>$next,'atualizado_em'=>time()),array('id'=>$c['id']))!==false;
        return array('ok'=>false,'persisted'=>$ok,'codigo'=>$code,'coleta'=>$c['id'],'proxima_tentativa'=>$next,'parcial'=>true);
    }
    public static function receber(array $c,array $r): array {
        if(!self::autocommit()){return array('ok'=>false,'codigo'=>'transacao_ativa_ou_indisponivel');}global $wpdb;$spec=F3Base_Ga4::recortes()[$c['recorte']];$rows=$r['rows']??null;$meta=$r['metadata']??null;
        $coverage=$r['coverage']??null;$next=$r['next_cursor']??null;
        $bad=($r['success']??null)!==true||($r['audit_success']??null)!==true||($r['contract_version']??'')!=='1.0.0'||($r['property']??'')!==$c['propriedade']||($r['consumer_revision']??'')!==$c['revision'];
        $bad=$bad||!is_array($rows)||!is_array($meta)||!is_array($r['quality']??null)||!is_array($r['quota']??null)||!is_array($coverage)||!is_int($r['extracted_at']??null)||!is_int($r['row_count']??null)||($r['row_count']??-1)<0;
        $bad=$bad||!is_array($r['dimension_headers']??null)||!is_array($r['metric_headers']??null);
        if(!$bad){$bad=array_column($r['dimension_headers'],'name')!==$spec['dimensions']||array_column($r['metric_headers'],'name')!==$spec['metrics']||($coverage['offset']??-1)!==(int)$c['linhas']||!is_bool($coverage['pagination_complete']??null)||count($rows)>1000;}
        if($bad){return self::falhar($c,'resposta_ga4_invalida',time()+300,true);}
        $newCount=(int)$c['linhas']+count($rows);$more=!$coverage['pagination_complete'];
        if(($more&&(!is_string($next)||$next===''))||(!$more&&$next!==null)||$newCount>$r['row_count']||($more&&(!$rows||$newCount>=$r['row_count']))||(!$more&&$newCount!==$r['row_count'])||((int)$c['linhas']>0&&(int)$c['total']!==$r['row_count'])){return self::falhar($c,'paginacao_ga4_alterada',time()+300,true);}
        if($more&&$c['cursor']!==''){ $previous=F3Base_Contato_Comunicacao::abrir($c['cursor']);if(($previous['cursor']??null)===$next){return self::falhar($c,'cursor_ga4_repetido',time()+300,true);} }
        $values=array();foreach($rows as $row){if(!is_array($row)||!is_array($row['dimensionValues']??null)||!is_array($row['metricValues']??null)){return self::falhar($c,'linha_ga4_invalida',time()+300,true);}$d=array_column($row['dimensionValues'],'value');$m=array_column($row['metricValues']??array(),'value');if(count($d)!==count($spec['dimensions'])||count($m)!==count($spec['metrics'])||array_filter(array_merge($d,$m),static fn($x)=>!is_string($x))||($d[0]??'')!==str_replace('-','',$c['dia'])){return self::falhar($c,'linha_ga4_invalida',time()+300,true);}
            foreach($m as $value){if(strlen($value)>100||!preg_match('/^-?[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?$/D',$value)){return self::falhar($c,'metrica_ga4_invalida',time()+300,true);}}
            $dimensions=array_combine($spec['dimensions'],$d);$metrics=array_combine($spec['metrics'],$m);$json=wp_json_encode($dimensions);if(strlen($json)>32000){return self::falhar($c,'linha_ga4_excede_limite',time()+300,true);}$values[]=array('coleta_id'=>$c['id'],'chave'=>hash('sha256',$json),'dimensoes'=>$json,'metricas'=>wp_json_encode($metrics));}
        $metadata=json_decode($c['metadata'],true)?:array();$quality=$r['quality'];$quality['other_row_observed']=false;foreach($rows as $row){if(in_array('(other)',array_column($row['dimensionValues'],'value'),true)){$quality['other_row_observed']=true;}}
        $metadata[]=array('extraido_em'=>$r['extracted_at']??time(),'metadata'=>$meta,'qualidade'=>$quality,'cota'=>$r['quota'],'cobertura'=>$r['coverage'],'request_id'=>$r['request_id']??null,'run_id'=>$r['run_id']??null,'connection_id'=>$r['connection_id']??null);
        $cipher=$more?F3Base_Contato_Comunicacao::cifrar(array('cursor'=>$r['next_cursor'])):'';$state=$more?'em_curso':($newCount?'concluida':'sem_dados');if($more&&!$cipher){return self::falhar($c,'cursor_nao_cifrado',time()+60,true);}
        if(false===$wpdb->query('START TRANSACTION')){return self::falhar($c,'transacao_indisponivel',time()+60);}
        try{
            $current=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE id=%s FOR UPDATE',self::tabela(),$c['id']),ARRAY_A);
            if(!$current||$current['cursor']!==$c['cursor']||(int)$current['linhas']!==(int)$c['linhas']){throw new RuntimeException('coleta_alterada');}
            foreach($values as $v){if($wpdb->insert(self::tabela('linhas'),$v)!==1){throw new RuntimeException('linha_duplicada_ou_nao_persistida');}}
            if((int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE coleta_id=%s',self::tabela('linhas'),$c['id']))!==$newCount){throw new RuntimeException('contagem_linhas_divergente');}
            if(!$more&&$newCount){if(false===$wpdb->query($wpdb->prepare('UPDATE %i SET publicado=0 WHERE propriedade=%s AND recorte=%s AND dia=%s AND publicado=1',self::tabela(),$c['propriedade'],$c['recorte'],$c['dia']))){throw new RuntimeException('publicacao_nao_persistida');}}
            $next=$state==='sem_dados'?time()+DAY_IN_SECONDS:0;
            if(false===$wpdb->update(self::tabela(),array('estado'=>$state,'publicado'=>(int)(!$more&&$newCount>0),'cursor'=>$cipher,'linhas'=>$newCount,'total'=>$r['row_count'],'metadata'=>wp_json_encode($metadata),'codigo'=>$state==='sem_dados'?'dia_sem_dados':'','tentar_em'=>$next,'atualizado_em'=>time()),array('id'=>$c['id']))){throw new RuntimeException('coleta_nao_persistida');}
            if(false===$wpdb->query('COMMIT')){throw new RuntimeException('commit_nao_confirmado');}
            return array('ok'=>true,'coleta'=>$c['id'],'estado'=>$state,'codigo'=>$state,'linhas'=>$newCount,'publicado'=>!$more&&$newCount>0,'parcial'=>$more,'proxima_tentativa'=>$next,'fonte'=>'GA4');
        }catch(Throwable $e){$wpdb->query('ROLLBACK');return self::falhar($c,$e->getMessage(),time()+300,true);}
    }
    public static function janela(array $e): array {
        $cfg=F3Base_Ga4::opcoes();$p=$e['propriedade']??$cfg['propriedade'];$to=$e['ate']??(new DateTimeImmutable('yesterday',new DateTimeZone($cfg['fuso'])))->format('Y-m-d');$from=$e['de']??(new DateTimeImmutable($to))->modify('-29 days')->format('Y-m-d');
        if(!is_string($p)||!preg_match('~^properties/[1-9][0-9]{0,19}$~D',$p)||!F3Base_Gsc::data_valida($from)||!F3Base_Gsc::data_valida($to)||$from>$to||(new DateTimeImmutable($from))->diff(new DateTimeImmutable($to))->days>365){throw new InvalidArgumentException('propriedade_ou_periodo_invalido_1_a_366_dias');}
        $slice=$e['recorte']??'resumo';if(!isset(F3Base_Ga4::recortes()[$slice])){throw new InvalidArgumentException('recorte_invalido');}return array($p,$from,$to,$slice);
    }
    public static function historico(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}try{[$p,$from,$to,$slice]=self::janela($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>$x->getMessage());}
        global $wpdb;$page=max(1,(int)($e['pagina']??1));$limit=min(50,max(1,(int)($e['limite']??50)));$filter=isset($e['coleta'])?$wpdb->prepare(' AND id=%s',$e['coleta']):'';$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE propriedade=%s AND dia BETWEEN %s AND %s AND recorte=%s'.$filter.' ORDER BY dia DESC,sequencia DESC LIMIT %d OFFSET %d',self::tabela(),$p,$from,$to,$slice,$limit+1,($page-1)*$limit),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'acervo_indisponivel');}$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);foreach($rows as &$r){unset($r['cursor']);$r['metadata']=json_decode($r['metadata'],true);$r['total_paginas_qualidade']=count($r['metadata']?:array());if(isset($e['pagina_qualidade'])){$qp=max(1,(int)$e['pagina_qualidade']);$r['metadata']=array_slice($r['metadata']?:array(),($qp-1)*10,10);$r['proxima_pagina_qualidade']=$qp*10<$r['total_paginas_qualidade']?$qp+1:null;}}if(strlen(wp_json_encode($rows))>262144){return array('ok'=>false,'codigo'=>'reduza_limite_ou_use_pagina_qualidade');}$out=array('ok'=>true,'fonte'=>'GA4','linhas'=>$rows,'pagina'=>$page,'proxima_pagina'=>$more?$page+1:null);return $out;
    }
    public static function lacunas(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}try{[$p,$from,$to,$slice]=self::janela($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>$x->getMessage());}
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT dia,estado,codigo,tentar_em,publicado,atualizado_em FROM %i WHERE propriedade=%s AND recorte=%s AND dia BETWEEN %s AND %s ORDER BY sequencia DESC',self::tabela(),$p,$slice,$from,$to),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'acervo_indisponivel');}$seen=array();foreach($rows as $r){if(!isset($seen[$r['dia']])){$seen[$r['dia']]=$r;}}
        $gaps=array();for($d=new DateTimeImmutable($from);$d->format('Y-m-d')<=$to;$d=$d->modify('+1 day')){$day=$d->format('Y-m-d');$r=$seen[$day]??array('estado'=>'nao_coletado','codigo'=>'','tentar_em'=>0);if($r['estado']!=='concluida'){$gaps[]=array('dia'=>$day,'recorte'=>$slice,'estado'=>$r['estado'],'codigo'=>$r['codigo'],'tentar_em'=>(int)$r['tentar_em']);}}
        return array('ok'=>true,'fonte'=>'GA4','propriedade'=>$p,'de'=>$from,'ate'=>$to,'lacunas'=>$gaps,'sem_dados_nao_equivale_a_zero'=>true);
    }
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}try{[$p,$from,$to,$slice]=self::janela($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>$x->getMessage());}
        global $wpdb;$t=self::tabela();$l=self::tabela('linhas');$page=max(1,(int)($e['pagina']??1));$limit=min(100,max(1,(int)($e['limite']??100)));
        $heads=$wpdb->get_results($wpdb->prepare('SELECT id,dia FROM %i WHERE propriedade=%s AND recorte=%s AND dia BETWEEN %s AND %s AND publicado=1 ORDER BY dia,id',$t,$p,$slice,$from,$to),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'acervo_indisponivel');}
        $revision=hash('sha256',wp_json_encode(array($p,$from,$to,$slice,$heads)));if(isset($e['revisao'])&&!hash_equals($revision,$e['revisao'])){return array('ok'=>false,'codigo'=>'acervo_alterado_reinicie_paginacao','revisao'=>$revision);}
        $rows=$wpdb->get_results($wpdb->prepare('SELECT c.id coleta,c.dia,l.dimensoes,l.metricas FROM %i c JOIN %i l ON l.coleta_id=c.id WHERE c.propriedade=%s AND c.recorte=%s AND c.dia BETWEEN %s AND %s AND c.publicado=1 ORDER BY c.dia,l.chave LIMIT %d OFFSET %d',$t,$l,$p,$slice,$from,$to,$limit+1,($page-1)*$limit),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'acervo_indisponivel');}
        // Detect publication between the selection and the row read; do not mix generations.
        $after=$wpdb->get_col($wpdb->prepare('SELECT id FROM %i WHERE propriedade=%s AND recorte=%s AND dia BETWEEN %s AND %s AND publicado=1 ORDER BY dia,id',$t,$p,$slice,$from,$to));if($after!==array_column($heads,'id')){return array('ok'=>false,'codigo'=>'acervo_alterado_reinicie_paginacao');}
        $more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);foreach($rows as &$row){$row['dimensoes']=json_decode($row['dimensoes'],true);$row['metricas']=json_decode($row['metricas'],true);}$quality=array();foreach(array_unique(array_column($rows,'coleta')) as $id){$h=$wpdb->get_row($wpdb->prepare('SELECT dia,metadata FROM %i WHERE id=%s',$t,$id),ARRAY_A);if(!$h){return array('ok'=>false,'codigo'=>'acervo_alterado_reinicie_paginacao');}$pages=json_decode($h['metadata'],true)?:array();$qp=isset($e['pagina_qualidade'])?max(1,(int)$e['pagina_qualidade']):null;$quality[]=array('coleta'=>$id,'dia'=>$h['dia'],'paginas'=>$qp?array_slice($pages,($qp-1)*10,10):$pages,'total_paginas'=>count($pages),'proxima_pagina_qualidade'=>$qp&&$qp*10<count($pages)?$qp+1:null);}if(strlen(wp_json_encode(array($rows,$quality)))>262144){return array('ok'=>false,'codigo'=>'reduza_limite_ou_periodo');}
        return array('ok'=>true,'fonte'=>'GA4','propriedade'=>$p,'recorte'=>$slice,'de'=>$from,'ate'=>$to,'revisao'=>$revision,'linhas'=>$rows,'qualidade_por_dia'=>$quality,'pagina'=>$page,'proxima_pagina'=>$more?$page+1:null,'semantica'=>'Valores brutos por dia e dimensão. Não somar usuários distintos entre dias, sessões entre páginas, recortes entre si ou GA4 com medição própria.','snapshot_guaranteed'=>false,'all_rows_guaranteed'=>false);
    }
    public static function comparar(array $e): array {
        $a=self::consultar($e);if(empty($a['ok'])){return $a;}$b=$e;unset($b['revisao']);if(isset($e['revisao_anterior'])){$b['revisao']=$e['revisao_anterior'];}$b['de']=$e['anterior_de']??'';$b['ate']=$e['anterior_ate']??'';$b=self::consultar($b);return array('ok'=>!empty($b['ok']),'fonte'=>'GA4','atual'=>$a,'anterior'=>$b,'totais_distintos_recalculados'=>false,'aviso'=>'Comparação de séries diárias; nenhuma soma de usuários nem inferência causal.');
    }
    public static function exportar(array $e): array {
        $r=self::consultar($e);if(empty($r['ok'])){return $r;}$format=$e['formato']??'json';if(!in_array($format,array('json','csv'),true)){return array('ok'=>false,'codigo'=>'formato_invalido');}
        if($format==='json'){$bytes=wp_json_encode($r,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}else{$fp=fopen('php://temp','w+');$spec=F3Base_Ga4::recortes()[$r['recorte']];fputcsv($fp,array_merge(array('fonte','coleta','dia'),$spec['dimensions'],$spec['metrics']),',','"','');foreach($r['linhas'] as $v){$vals=array_merge(array('GA4',$v['coleta'],$v['dia']),array_values($v['dimensoes']),array_values($v['metricas']));$vals=array_map(static fn($v)=>preg_match('/^[=+@\-\t\r\n]/',(string)$v)?"'".$v:$v,$vals);fputcsv($fp,$vals,',','"','');}rewind($fp);$bytes=stream_get_contents($fp);fclose($fp);}
        if(strlen($bytes)>524288){return array('ok'=>false,'codigo'=>'reduza_limite_ou_periodo_exportacao');}
        return array('ok'=>true,'fonte'=>'GA4','formato'=>$format,'conteudo_base64'=>base64_encode($bytes),'bytes'=>strlen($bytes),'sha256'=>hash('sha256',$bytes),'revisao'=>$r['revisao'],'pagina'=>$r['pagina'],'proxima_pagina'=>$r['proxima_pagina'],'qualidade_por_dia'=>$r['qualidade_por_dia'],'csv_cabecalho_por_parte'=>$format==='csv');
    }
    public static function limpar(): void {
        if(!self::autocommit()){return;}$months=(int)(F3Base_Options::ler(F3Base_Retencao_Prazos::OPTION)['retencao_ga4_meses']??0);if($months<=0){return;}global $wpdb;$cut=wp_date('Y-m-d',F3Base_Retencao_Prazos::deslocar(-$months));$ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM %i WHERE dia<%s AND estado NOT IN ('em_curso','aguardando') LIMIT 100",self::tabela(),$cut));
        foreach($ids?:array() as $id){if(false===$wpdb->query('START TRANSACTION')){return;}if(false===$wpdb->delete(self::tabela('linhas'),array('coleta_id'=>$id))||false===$wpdb->delete(self::tabela(),array('id'=>$id))){$wpdb->query('ROLLBACK');}else{$wpdb->query('COMMIT');}}
    }
}
