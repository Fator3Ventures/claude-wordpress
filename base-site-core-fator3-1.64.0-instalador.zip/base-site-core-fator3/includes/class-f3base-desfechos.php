<?php
/** Commercial outcomes are local observations, independent of advertising eligibility. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Desfechos {
    public const ESQUEMA_VERSAO=16400;
    public const OPCAO = 'f3base_desfechos';
    public static function padroes(): array { return array('campo_icp'=>'','campo_motivo_perda'=>'','campo_motivo_arquivamento'=>'','campo_motivo_desqualificacao'=>'', 'motivos_perda'=>array(), 'meta_enviar_valor'=>false); }
    public static function catalogo(array $c): array {
        $props=array('campo_icp'=>array('type'=>'string','pattern'=>'^([a-f0-9]{40})?$'), 'meta_enviar_valor'=>array('type'=>'boolean'), 'motivos_perda'=>array('type'=>'array','maxItems'=>100,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('codigo','valor_crm','rotulo'),'properties'=>array('codigo'=>array('type'=>'string','pattern'=>'^[a-z0-9_-]{1,60}$'),'valor_crm'=>array('type'=>'string','minLength'=>1,'maxLength'=>300),'rotulo'=>array('type'=>'string','minLength'=>1,'maxLength'=>100)))));
        foreach(array('campo_motivo_perda','campo_motivo_arquivamento','campo_motivo_desqualificacao') as $field){$props[$field]=$props['campo_icp'];}
        $c[self::OPCAO]=F3Base_Conversas::catalogo_grupo(self::OPCAO,'Desfechos comerciais',self::padroes(),$props,array(__CLASS__,'validar'));
        $c[self::OPCAO]['descricao']='Valor e moeda do negócio, motivos fechados e campo ICP. Valor não é enviado à Meta por padrão.';
        return $c;
    }
    public static function validar($v): string {
        if (!is_array($v)||array_diff(array_keys($v),array_keys(self::padroes()))) { return 'Configuração de desfechos inválida.'; }
        $v=array_replace(self::padroes(),$v);$codes=array();$values=array();
        foreach($v['motivos_perda'] as $m){if(in_array($m['codigo'],$codes,true)||in_array($m['valor_crm'],$values,true)){return 'Códigos e valores de motivo precisam ser únicos.';}$codes[]=$m['codigo'];$values[]=$m['valor_crm'];}
        foreach(array('campo_icp','campo_motivo_perda','campo_motivo_arquivamento','campo_motivo_desqualificacao') as $role){if($v[$role]!==''){$found=false;foreach(get_option('f3base_pipedrive_estado',array())['catalogos']['campos']??array() as $f){if(($f['field_code']??$f['key']??'')===$v[$role]&&in_array($f['field_type']??'',array('enum','set'),true)){$found=true;}}if(!$found){return 'Selecione campos de opções fechadas do catálogo Pipedrive.';}}}
        return '';
    }
    public static function config(): array {return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPCAO));}
    /** CRM dimensions use closed option IDs. Legacy rows explicitly expose current mapping, never a claimed historic readback. */
    public static function dimensoes_comerciais(array $lead,?array $remote=null): array {
        $d=is_array($lead['dados']??null)?$lead['dados']:(json_decode((string)($lead['dados']??''),true)?:array());
        if($remote===null){$observed=F3Base_Capi_Fila::abrir_payload($d['desfecho_comercial']??'');if(is_array($observed['dimensoes_comerciais']??null)){return $observed['dimensoes_comerciais'];}}
        $cfg=F3Base_Options::ler('f3base_pipedrive');$state=get_option('f3base_pipedrive_estado',array());$catalog=$state['catalogos']['campos']??array();
        $saved=F3Base_Contato_Comunicacao::ler(array('dados'=>$d));$a=F3Base_Atribuicao::normalizar($saved['atribuicao']??$d['atribuicao']??array());
        $acquisition=F3Base_Pipedrive_Configuracao::aquisicao(array('atribuicao'=>$a),$cfg);$partner=$acquisition['parceiro']??null;
        if(($acquisition['fonte']??'')==='nome_legado'){$campaign=F3Base_Atribuicao::nome_campanha($a);$key=$campaign?'fora_do_padrao':($a?'sem_campanha':'origem_nao_observada');if(preg_match('/^([^_]+)_([^_]+)_(.+)_([0-9]{6})$/u',$campaign,$m)){$key=strtolower(remove_accents($m[2]));}$partner=$cfg['mapa_parceiros'][$key]??null;}
        $private=F3Base_Contato_Comunicacao::abrir((string)($d['contato_externo_cifrado']??''))??array();$platform=$private['origem_declarada']['canal']??$a['plataforma'];
        if(isset($private['origem_declarada']['parceiro'])){$partner=$cfg['mapa_parceiros'][$private['origem_declarada']['parceiro']]??null;}
        $ids=array('canal'=>$cfg['mapa_canais'][$platform]??null,'parceiro'=>$partner);$out=array('comercial_fonte'=>$remote===null?'mapeamento_atual_nao_comprova_envio':'campos_observados_crm');
        foreach($ids as $role=>$mapped){$field=$cfg['mapa_campos'][$role]??'';$raw=$remote===null?$mapped:($remote['custom_fields'][$field]??$remote[$field]??null);if(is_array($raw)){$raw=$raw['id']??$raw['value']??null;}$id=is_scalar($raw)?(string)$raw:'';$label=null;
            if($field!==''&&($state['dominio']??'')===($cfg['dominio']??'')){foreach($catalog as $f){if(($f['field_code']??$f['key']??'')!==$field||($f['field_type']??'')!=='enum'){continue;}foreach($f['options']??array() as $o){if((string)($o['id']??'')===$id){$label=sanitize_text_field((string)($o['label']??''));break;}}}}
            // Unknown values may be free text: never turn them into report dimensions.
            $out[$role.'_id']=$label!==null?$id:null;$out[$role]=$label;
        }return $out;
    }
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_desfechos';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$t} (\nid bigint unsigned NOT NULL AUTO_INCREMENT,\nchave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\nconta varchar(100) NOT NULL,\nnegocio_id varchar(40) NOT NULL,\nocorreu_em bigint unsigned NOT NULL,\nrecebido_em bigint unsigned NOT NULL,\ndados longtext NOT NULL,\nPRIMARY KEY  (id),\nUNIQUE KEY identidade (chave),\nKEY contato (record_id,ocorreu_em)\n) ENGINE=InnoDB {$cc};");
        return !$wpdb->last_error && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    /** Six decimal places, bounded before integer arithmetic; never mix currencies. */
    public static function valor($v): ?string {
        if(is_int($v)){$v=(string)$v;}elseif(is_float($v)&&is_finite($v)){$v=sprintf('%.6F',$v);}
        if(!is_string($v)||!preg_match('/^([0-9]{1,11})(?:\.([0-9]{1,6}))?$/D',$v,$m)){return null;}
        return (string)(int)$m[1].'.'.str_pad($m[2]??'',6,'0');
    }
    public static function instante($s): ?int {
        if(!is_string($s)||!preg_match('/^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:?\d{2})?$/D',$s)){return null;}
        $at=strtotime($s.(preg_match('/(?:Z|[+-]\d{2}:?\d{2})$/D',$s)?'':' UTC'));return $at&&$at<=time()+60?$at:null;
    }
    public static function preparar(array $data): array {
        $cfg=self::config();$state=in_array($data['status']??'',array('open','won','lost','deleted'),true)?$data['status']:'desconhecido';
        $value=self::valor($data['value']??null);$currency=preg_match('/^[A-Z]{3}$/D',(string)($data['currency']??''))?(string)$data['currency']:null;
        $reason=null;foreach($cfg['motivos_perda'] as $m){if((string)($data['lost_reason']??'')===$m['valor_crm']){$reason=array('codigo'=>$m['codigo'],'rotulo'=>$m['rotulo']);break;}}
        $closed=self::selecoes($data,$cfg['campo_motivo_perda']);if($closed){$reason=$closed[0];}
        $icp=array();$field=$cfg['campo_icp'];$raw=$field!==''?($data['custom_fields'][$field]??$data[$field]??null):null;
        if(is_scalar($raw)){$raw=explode(',',(string)$raw);}elseif(is_array($raw)&&isset($raw['values'])){$raw=$raw['values'];}
        foreach(get_option('f3base_pipedrive_estado',array())['catalogos']['campos']??array() as $f){if(($f['field_code']??$f['key']??'')===$field&&$field!==''){foreach($f['options']??array() as $o){if(in_array((string)$o['id'],array_map('strval',(array)$raw),true)){$icp[]=array('codigo'=>(string)$o['id'],'rotulo'=>sanitize_text_field($o['label']??''));}}}}
        return array('estado'=>$state,'valor'=>$value,'moeda'=>$currency,'valor_codigo'=>$value!==null&&$currency!==null?'observado':'valor_ou_moeda_ausente','fechado_em'=>in_array($state,array('won','lost'),true)?self::instante($data[$state==='won'?'won_time':'lost_time']??$data['close_time']??null):null,'negocio_criado_em'=>self::instante($data['add_time']??null),'motivo_perda'=>$state==='lost'?$reason:null,'motivo_perda_codigo'=>$state!=='lost'?'nao_aplicavel':($reason?'mapeado':'nao_mapeado'),'icp'=>$icp);
    }
    /** Only labels from the verified account's enum/set catalog, never free text. */
    public static function selecoes(array $data,string $field): array {
        if($field===''){return array();}$raw=$data['custom_fields'][$field]??$data[$field]??array();if(is_scalar($raw)){$raw=explode(',',(string)$raw);}elseif(is_array($raw)&&isset($raw['values'])){$raw=$raw['values'];}$values=array_filter((array)$raw,'is_scalar');$out=array();
        foreach(get_option('f3base_pipedrive_estado',array())['catalogos']['campos']??array() as $f){if(($f['field_code']??$f['key']??'')!==$field||!in_array($f['field_type']??'',array('enum','set'),true)){continue;}foreach($f['options']??array() as $o){if(in_array((string)$o['id'],array_map('strval',$values),true)){$out[]=array('codigo'=>(string)$o['id'],'rotulo'=>sanitize_text_field($o['label']??''));}}}return $out;
    }
    public static function observar_contato(array $lead,string $entity,array $data,int $at): bool {
        global $wpdb;$cfg=self::config();$safe=array('entidade'=>$entity,'id'=>(string)($data['id']??''),'ocorreu_em'=>$at,'observado_em'=>time(),'icp'=>self::selecoes($data,$cfg['campo_icp']),'motivos_arquivamento'=>self::selecoes($data,$cfg['campo_motivo_arquivamento']),'motivos_desqualificacao'=>self::selecoes($data,$cfg['campo_motivo_desqualificacao']),'motivos_perda'=>self::selecoes($data,$cfg['campo_motivo_perda']),'arquivado'=>!empty($data['is_archived']),'negocio_criado_em'=>$entity==='deal'?self::instante($data['add_time']??null):null,'dimensoes_comerciais'=>self::dimensoes_comerciais($lead,$data),'limite'=>'Valores fora do catálogo ou campos sem mapeamento não fornecem rótulos.');
        for($i=0;$i<3;$i++){$raw=$wpdb->get_var($wpdb->prepare('SELECT dados FROM %i WHERE record_id=%s AND eliminacao_pendente=0',F3Base_Leads_Repositorio::tabela(),$lead['record_id']));if(!is_string($raw)){return false;}$d=json_decode($raw,true);$old=F3Base_Capi_Fila::abrir_payload($d['desfecho_comercial']??'');if((int)($old['ocorreu_em']??0)>$at){return true;}$d['desfecho_comercial']=F3Base_Capi_Fila::cifrar_payload($safe);$n=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d)),array('record_id'=>$lead['record_id'],'dados'=>$raw,'eliminacao_pendente'=>0));if($n===1){return true;}if($n===false){return false;}}return false;
    }
    public static function contato(array $lead): array {$d=is_array($lead['dados'])?$lead['dados']:json_decode($lead['dados'],true);return (F3Base_Capi_Fila::abrir_payload($d['desfecho_comercial']??'')??array())+array('primeira_atividade_concluida_em'=>$d['primeira_atividade_concluida_em']??null,'primeira_resposta'=>$d['primeira_resposta']??null);}
    public static function historico(string $record,int $limite=101): array {
        global $wpdb;$rows=$wpdb->get_results($wpdb->prepare('SELECT id,record_id,conta,negocio_id,ocorreu_em,recebido_em,dados FROM %i WHERE record_id=%s ORDER BY ocorreu_em DESC,id DESC LIMIT %d',self::tabela(),$record,$limite),ARRAY_A)?:array();
        foreach($rows as &$r){$r['dados']=F3Base_Capi_Fila::abrir_payload($r['dados']);}unset($r);return $rows;
    }
    public static function observar(array $lead,array $data,int $at,string $key,string $origem): array {
        global $wpdb;$id=$lead['record_id'];$s=get_option('f3base_pipedrive_estado',array());$account=hash('sha256',($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??''));$deal=(string)($data['id']??'');
        if(!preg_match('/^[1-9][0-9]{0,19}$/D',$deal)||$at<1||$at>time()+60){return array('ok'=>false,'codigo'=>'desfecho_invalido');}
        $l=F3Base_Trava::adquirir('desfecho-'.$id,30);if(!$l){return array('ok'=>false,'codigo'=>'desfecho_ocupado');}
        try{
            $fresh=F3Base_Leads_Repositorio::obter($id);if(!$fresh||!empty($fresh['eliminacao_pendente'])||in_array($fresh['captura'],array('eliminando','eliminado'),true)){return array('ok'=>false,'codigo'=>'contato_indisponivel');}
            $k=hash('sha256',$id.'|'.$account.'|'.$deal.'|'.$key);if($wpdb->get_var($wpdb->prepare('SELECT id FROM %i WHERE chave=%s',self::tabela(),$k))){return array('ok'=>true,'codigo'=>'desfecho_repetido');}
            $old=$wpdb->get_var($wpdb->prepare('SELECT dados FROM %i WHERE record_id=%s AND conta=%s AND negocio_id=%s AND ocorreu_em<=%d ORDER BY ocorreu_em DESC,id DESC LIMIT 1',self::tabela(),$id,$account,$deal,$at));$prior=$old?F3Base_Capi_Fila::abrir_payload($old):array();
            $new=self::preparar($data);$new['dimensoes_comerciais']=self::dimensoes_comerciais($lead,$data);$before=$prior['atual']??null;if($new===$before){return array('ok'=>true,'codigo'=>'desfecho_sem_alteracao');}
            $safe=array('atual'=>$new,'anterior'=>$before,'tipo'=>$before&&$before['estado']===$new['estado']&&($before['valor']!==$new['valor']||$before['moeda']!==$new['moeda'])?'alteracao_valor':'observacao_comercial','origem'=>$origem);
            $ok=$wpdb->insert(self::tabela(),array('chave'=>$k,'record_id'=>$id,'conta'=>$account,'negocio_id'=>$deal,'ocorreu_em'=>$at,'recebido_em'=>time(),'dados'=>F3Base_Capi_Fila::cifrar_payload($safe)))===1;
            return array('ok'=>$ok,'codigo'=>$ok?'desfecho_registrado':'desfecho_nao_persistido','tipo'=>$safe['tipo']);
        }finally{F3Base_Trava::liberar($l);}
    }
    public static function ler(string $id): array {$rows=self::historico($id);return array('atual'=>$rows[0]??null,'historico'=>array_slice($rows,0,100),'mais_historico'=>count($rows)>100);}
    public static function relatorio(array $leads): array {
        if(!$leads){return array();}global $wpdb;$ids=array_column($leads,'record_id');$in=implode(',',array_fill(0,count($ids),'%s'));
        // Keep every distinct deal, then take its latest observation across contacts in this cohort.
        $rows=$wpdb->get_results($wpdb->prepare('SELECT d.* FROM %i d LEFT JOIN %i n ON n.record_id=d.record_id AND n.conta=d.conta AND n.negocio_id=d.negocio_id AND (n.ocorreu_em>d.ocorreu_em OR (n.ocorreu_em=d.ocorreu_em AND n.id>d.id)) WHERE n.id IS NULL AND d.record_id IN ('.$in.')',array_merge(array(self::tabela(),self::tabela()),$ids)),ARRAY_A);
        if($wpdb->last_error||!is_array($rows)){return array('ok'=>false,'codigo'=>'desfechos_leitura_falhou','linhas'=>array(),'regra'=>'Leitura indisponível; nenhum total foi calculado.');}
        $byDeal=array();$owners=array();$byContact=array_column($leads,null,'record_id');
        foreach($rows as $row){$key=$row['conta'].'|'.$row['negocio_id'];$old=$byDeal[$key]??null;
            if(!$old||(int)$row['ocorreu_em']>(int)$old['ocorreu_em']||((int)$row['ocorreu_em']===(int)$old['ocorreu_em']&&(int)$row['id']>(int)$old['id'])){$byDeal[$key]=$row;}
            $candidate=$byContact[$row['record_id']];$owner=$owners[$key]??null;
            if(!$owner||strcmp($candidate['criado_em'].'|'.$candidate['record_id'],$owner['criado_em'].'|'.$owner['record_id'])<0){$owners[$key]=$candidate;}
        }
        uasort($byDeal,static fn($a,$b)=>strcmp($owners[$a['conta'].'|'.$a['negocio_id']]['criado_em'],$owners[$b['conta'].'|'.$b['negocio_id']]['criado_em'])?:strcmp($a['conta'].'|'.$a['negocio_id'],$b['conta'].'|'.$b['negocio_id']));$out=array();
        foreach($byDeal as $deal=>$r){$lead=$owners[$deal];$x=F3Base_Capi_Fila::abrir_payload($r['dados'])['atual']??null;if(!is_array($x)){return array('ok'=>false,'codigo'=>'desfecho_ilegivel','linhas'=>array(),'regra'=>'Observação ilegível; nenhum total parcial foi calculado.');}$d=is_array($lead['dados'])?$lead['dados']:json_decode($lead['dados'],true);$a=F3Base_Atribuicao::normalizar($d['atribuicao']??array());
            $dim=array('plataforma'=>$a['plataforma'],'conta_id'=>$a['conta_id'],'campanha_id'=>$a['campanha_id'],'campanha'=>$a['utm_campaign'],'anuncio_id'=>$a['anuncio_id'],'formulario'=>$lead['formulario'],'moeda'=>$x['moeda']??'desconhecida')+($x['dimensoes_comerciais']??self::dimensoes_comerciais($lead));$k=wp_json_encode($dim);
            $out[$k]=$out[$k]??$dim+array('negocios'=>0,'ganhos'=>0,'perdidos'=>0,'abertos'=>0,'valor_ganho'=>'0.000000','valor_pipeline_aberto'=>'0.000000','valor_ausente'=>0,'motivos_perda'=>array(),'icp'=>array());$o=&$out[$k];$o['negocios']++;
            if(($x['estado']??'')==='won'){$o['ganhos']++;}elseif(($x['estado']??'')==='lost'){$o['perdidos']++;}elseif(($x['estado']??'')==='open'){$o['abertos']++;}
            $money=($x['estado']??'')==='won'?'valor_ganho':(($x['estado']??'')==='open'?'valor_pipeline_aberto':'');
            if(($x['valor']??null)===null||($x['moeda']??null)===null){$o['valor_ausente']++;}elseif($money!==''){$o[$money]=self::somar($o[$money],$x['valor']);}
            if(!empty($x['motivo_perda'])){$code=$x['motivo_perda']['codigo'];$o['motivos_perda'][$code]=$o['motivos_perda'][$code]??$x['motivo_perda']+array('quantidade'=>0);$o['motivos_perda'][$code]['quantidade']++;}
            foreach($x['icp']??array() as $icp){$code=$icp['codigo'];$o['icp'][$code]=$o['icp'][$code]??$icp+array('quantidade'=>0);$o['icp'][$code]['quantidade']++;}unset($o);
        }
        return array('ok'=>true,'linhas'=>array_values($out),'regra'=>'Um negócio por conta, atribuído ao primeiro contato do recorte; fotografia mais recente, sem conversão cambial.','observacoes_consideradas'=>count($rows));
    }
    public static function somar(string $a,string $b): string {
        // Decimal string addition keeps large report totals exact without bcmath.
        $a=str_replace('.','',$a);$b=str_replace('.','',$b);$n=max(strlen($a),strlen($b));$a=str_pad($a,$n,'0',STR_PAD_LEFT);$b=str_pad($b,$n,'0',STR_PAD_LEFT);$s='';$carry=0;
        for($i=$n-1;$i>=0;$i--){$v=(int)$a[$i]+(int)$b[$i]+$carry;$s=($v%10).$s;$carry=intdiv($v,10);}if($carry){$s=$carry.$s;}$s=str_pad($s,7,'0',STR_PAD_LEFT);return (ltrim(substr($s,0,-6),'0')?:'0').'.'.substr($s,-6);
    }
    public static function eliminar(string $id): bool {global $wpdb;$l=F3Base_Trava::adquirir('desfecho-'.$id,30);if(!$l){return false;}try{return $wpdb->delete(self::tabela(),array('record_id'=>$id))!==false;}finally{F3Base_Trava::liberar($l);}}
}
