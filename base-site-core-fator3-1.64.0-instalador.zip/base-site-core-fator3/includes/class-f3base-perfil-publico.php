<?php
/** Registration and normalized configuration needed by an anonymous page. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Perfil_Publico {
    const OPTION='f3base_config_publica';
    private static bool $ativo=false;
    private static bool $gerando=false;
    private static ?array $config=null;
    public static function ativo(): bool {return self::$ativo&&!self::$gerando;}
    public static function completo(): void {self::$ativo=false;}
    public static function hooks(): void {
        add_action('updated_option',array(__CLASS__,'alterada'),250,3);
        add_action('added_option',array(__CLASS__,'adicionada'),250,2);
        add_action('deleted_option',array(__CLASS__,'apagada'),250);
        add_action('f3base_zelador',array(__CLASS__,'atualizar'),2);
    }
    public static function adicionada($name,$value): void {self::alterada($name,null,$value);}
    public static function apagada($name): void {self::alterada($name,null,null);}
    public static function alterada($name,$old,$new): void {
        if(self::$gerando||$name===self::OPTION){return;}
        $c=self::config();if(isset($c['valores'])&&array_key_exists($name,$c['valores'])){self::atualizar($name);}
    }
    public static function config(): array {if(self::$config===null){self::$config=(array)get_option(self::OPTION,array());}return self::$config;}
    public static function ler(string $name,bool &$found) {
        $c=self::config();$found=isset($c['valores'])&&array_key_exists($name,$c['valores']);return $found?$c['valores'][$name]:null;
    }
    public static function revisao(string $name): ?string {return self::config()['revisoes'][$name]??null;}
    public static function atualizar($only=null): void {
        if(self::$gerando){return;}self::$gerando=true;
        try{
            $c=self::config();if($only!==false&&!is_string($only)&&($c['versao']??'')===F3BASE_PLUGIN_VERSAO&&(int)($c['gerada_em']??0)>time()-3600){return;}
            $names=require __DIR__.'/opcoes-publicas.php';$values=$c['valores']??array();$revs=$c['revisoes']??array();
            foreach($names as $name){if(is_string($only)&&$only!==$name){continue;}$values[$name]=F3Base_Options::ler($name);$revs[$name]=F3Base_Options::revisao($name);}
            self::$config=array('versao'=>F3BASE_PLUGIN_VERSAO,'gerada_em'=>time(),'valores'=>$values,'revisoes'=>$revs);update_option(self::OPTION,self::$config,true);
        }finally{self::$gerando=false;}
    }
    public static function iniciar(bool $login=false,bool $contexto=false): void {
        self::$ativo=true;
        F3Base_Bootstrap::iniciar('F3Base_Sessao_Admin');
        add_action('rest_api_init',array('F3Base_Audiencia','registrar_contexto'));
        add_action('wp_abilities_api_categories_init',array('F3Base_Site_Core','iniciar_completo'),0);
        add_filter('pre_wp_mail',static function($pre){F3Base_Site_Core::iniciar_completo();return $pre;},PHP_INT_MIN+1);
        if($login||$contexto){return;}
        foreach(array('F3Base_Artigos','F3Base_Autoria','F3Base_Formularios','F3Base_Conteudo_Privado','F3Base_Protecao','F3Base_Testes','F3Base_Captura_Contexto','F3Base_Confirmacao','F3Base_Conteudo_Instrumentacao','F3Base_Llms_Mapa','F3Base_Analise','F3Base_Meta_Transporte','F3Base_Ofertas_Medicao','F3Base_Llms_Arquivo') as $class){F3Base_Bootstrap::iniciar($class);}
        add_action('wp_enqueue_scripts',array('F3Base_Atribuicao','enfileirar'),5);
        add_action('wp_head',array('F3Base_Ofertas','marcador'),PHP_INT_MAX);
        if(isset($_GET['f3base_nav_sonda'])){F3Base_Bootstrap::iniciar('F3Base_Navegacao');}
        add_action('init',array('F3Base_Site_Core','registrar'),5);
        add_action('rest_api_init',array('F3Base_Site_Core','iniciar_completo'),0);
        add_action('template_redirect',array('F3Base_Audiencia_Exclusoes','registrar'),999);
        add_filter('wpseo_meta_author',array('F3Base_Autoria','metaauthor'),999);
        add_filter('wpseo_enhanced_slack_data',array('F3Base_Autoria','slack'),999);
        add_filter('render_block',static function($html,$block){$header=($block['blockName']??'')==='core/template-part'&&($block['attrs']['area']??'')==='header';return F3Base_Servicos::carimbar_cta($html,$header?'cabecalho':'conteudo');},30,2);
        add_filter('the_content',array('F3Base_Servicos','carimbar_cta'),30);
        add_filter('wp_nav_menu',static fn($html)=>F3Base_Servicos::carimbar_superficie($html,'menu'),30);
        add_filter('nav_menu_link_attributes',array('F3Base_Servicos','carimbar_menu'),30,2);
    }
}
