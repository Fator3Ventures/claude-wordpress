<?php
/** Amostras de Web Vitals por carregamento, atualizáveis e sem identidade de visitante. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Vitais {
    public const ESQUEMA_VERSAO=16400;
	public const TABELA           = 'f3base_vitais';
	public const BIBLIOTECA       = '6.2.1-f3.1';
	public const TETO_AMOSTRAS    = 75000;
	public const MAX_ATUALIZACOES = 60;
	public static function tabela(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABELA; }
	public static function pronta(): bool { if(!F3Base_Esquema::manutencao()){return F3Base_Esquema::pronta(__CLASS__);}
		global $wpdb;
		$t = self::tabela();
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) === $t && count(array_intersect(array('classe_trafego','automacao','automacao_motivos','automacao_regra','atribuicao'),$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t))))===5;
	}
    public static function instalar(): void {F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
	public static function instalar_estrutura(): void {
		global $wpdb;
		$t = self::tabela();
		if ( ! self::pronta() ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta(
				"CREATE TABLE {$t} (
				amostra char(64) NOT NULL,
                classe_trafego varchar(16) NOT NULL DEFAULT 'nao_marcado',
                automacao varchar(20) NOT NULL DEFAULT 'legado_desconhecido',
                automacao_motivos varchar(190) NOT NULL DEFAULT '',
                automacao_regra varchar(40) NOT NULL DEFAULT '',
                atribuicao text NULL,
				dia date NOT NULL,
				caminho varchar(760) NOT NULL,
				metrica varchar(8) NOT NULL,
				dispositivo varchar(16) NOT NULL,
				sequencia int unsigned NOT NULL,
				valor double NOT NULL,
				PRIMARY KEY  (amostra),
				KEY periodo (dia,metrica,dispositivo),
                KEY classe_dia (classe_trafego,dia),
				KEY pagina (caminho(190))
			) {$wpdb->get_charset_collate()};"
			);
		}
		if ( ! get_transient( 'f3base_vitais_limpeza' ) && self::pronta() ) {
			$corte = gmdate( 'Y-m-d', time() - ( F3Base_Modulo_Comportamento::retencao_eventos_dias() - 1 ) * DAY_IN_SECONDS );
			if ( false !== $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE dia<%s", $corte ) ) ) {
				set_transient( 'f3base_vitais_limpeza', true, HOUR_IN_SECONDS ); }
		}
	}
	public static function amostra_valida( $a ): bool {
		return is_array( $a ) && !array_diff(array_keys($a),array('id','dispositivo','sequencia','atribuicao')) && (!isset($a['atribuicao'])||self::atribuicao_valida($a['atribuicao'])) && is_string( $a['id'] ?? null ) && preg_match( '/^[a-zA-Z0-9_-]{8,80}$/D', $a['id'] ) && in_array( $a['dispositivo'] ?? '', array( 'movel', 'desktop' ), true ) && is_int( $a['sequencia'] ?? null ) && $a['sequencia'] >= 1 && $a['sequencia'] <= self::MAX_ATUALIZACOES;
	}
    public static function atribuicao_valida($a): bool {
        if(!is_array($a)||array_diff(array_keys($a),array('alvo','tipo','recurso','origem_script','fases','loaf'))){return false;}
        if(isset($a['alvo'])&&(!is_string($a['alvo'])||strlen($a['alvo'])>190||!preg_match('/^(?:(?:html|body|main|header|footer|nav|section|article|div|span|p|h[1-6]|button|a|input|select|textarea|label|form|img|picture|video|svg|ul|li)(?::nth-of-type\([1-9][0-9]{0,3}\))?)(?:>(?:html|body|main|header|footer|nav|section|article|div|span|p|h[1-6]|button|a|input|select|textarea|label|form|img|picture|video|svg|ul|li)(?::nth-of-type\([1-9][0-9]{0,3}\))?){0,3}$/D',$a['alvo']))){return false;}
        if(isset($a['tipo'])&&!in_array($a['tipo'],array('ponteiro','teclado','imagem','texto'),true)){return false;}
        if(isset($a['loaf'])&&!is_bool($a['loaf'])){return false;}
        foreach(array('recurso','origem_script') as $key){if(!isset($a[$key])){continue;}$v=$a[$key];if(!is_string($v)||strlen($v)>500){return false;}$u=wp_parse_url($v);if(!is_array($u)||!in_array($u['scheme']??'',array('http','https'),true)||empty($u['host'])||isset($u['query'])||isset($u['fragment'])||isset($u['user'])||isset($u['pass'])||str_contains(rawurldecode($v),'@')){return false;}if($key==='origem_script'&&!empty($u['path'])&&$u['path']!=='/'){return false;}}
        if(isset($a['fases'])){if(!is_array($a['fases'])||array_diff(array_keys($a['fases']),array('entrada','processamento','apresentacao','ttfb','atraso_carga','duracao_carga','atraso_renderizacao'))){return false;}foreach($a['fases'] as $v){if((!is_float($v)&&!is_int($v))||!is_finite((float)$v)||$v<0||$v>3600000){return false;}}}
        return true;
    }
    public static function gravar(string $dia,string $caminho,array $linha,string $classe='nao_marcado',array $automacao=array()): bool {
        if(!self::pronta()||!self::amostra_valida($linha['amostra']??null)){return false;}
        global $wpdb;$t=self::tabela();$a=$linha['amostra'];
        $id=hash('sha256',($classe==='teste'?'teste|':'').$caminho.'|'.$linha['detalhe'].'|'.$a['id']);
        $auto=in_array($automacao['automacao']??'',array('nao_identificada','provavel','declarada'),true)?$automacao['automacao']:'nao_identificada';
        $motivos=substr(sanitize_text_field($automacao['automacao_motivos']??''),0,190);$regra=substr(sanitize_key($automacao['automacao_regra']??''),0,40);
        $attr=isset($a['atribuicao'])?wp_json_encode($a['atribuicao']):null;
        $existe=$wpdb->get_var($wpdb->prepare('SELECT amostra FROM %i WHERE amostra=%s',$t,$id));
        if(!$existe){
            if((int)$wpdb->get_var("SELECT COUNT(*) FROM {$t}")>=self::TETO_AMOSTRAS){return false;}
            $ok=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (amostra,dia,caminho,metrica,dispositivo,sequencia,valor,classe_trafego,automacao,automacao_motivos,automacao_regra,atribuicao) VALUES (%s,%s,%s,%s,%s,%d,%f,%s,%s,%s,%s,%s)',$t,$id,$dia,$caminho,$linha['detalhe'],$a['dispositivo'],$a['sequencia'],$linha['soma'],$classe==='teste'?'teste':'nao_marcado',$auto,$motivos,$regra,$attr));
            if($ok===false){return false;}if($ok===1){return true;}
        }
        // Classification is monotonic: a later report cannot erase observed automation.
        return false!==$wpdb->query($wpdb->prepare("UPDATE %i SET valor=%f,sequencia=%d,atribuicao=%s,automacao=IF(automacao IN ('provavel','declarada'),automacao,%s),automacao_motivos=IF(automacao_motivos<>'',automacao_motivos,%s),automacao_regra=IF(automacao_regra<>'',automacao_regra,%s) WHERE amostra=%s AND sequencia<%d",$t,$linha['soma'],$a['sequencia'],$attr,$auto,$motivos,$regra,$id,$a['sequencia']));
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::registrar_ability('f3base/vitais-ler',array('label'=>'Desempenho de campo por caminho e métrica','description'=>'p75 das últimas amostras por carregamento, atribuição INP/LCP e contagem de automação e legado excluídos. Leitura local sem coleta.','category'=>F3BASE_PREFIXO,'input_schema'=>array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros_schema()),'output_schema'=>array('type'=>'object','properties'=>array('ok'=>array('type'=>'boolean'),'codigo'=>array('type'=>'string'),'linhas'=>array('type'=>'array','items'=>array('type'=>'object','required'=>array('metrica','amostras','p75','excluidas_automacao','excluidas_legado'),'properties'=>array('metrica'=>array('type'=>'string'),'amostras'=>array('type'=>'integer'),'p75'=>array('type'=>array('number','null')),'excluidas_automacao'=>array('type'=>'integer'),'excluidas_legado'=>array('type'=>'integer'),'alvos'=>array('type'=>'array'),'scripts'=>array('type'=>'array'),'fase_dominante'=>array('type'=>array('string','null'))))))),'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>array(__CLASS__,'consultar'),'meta'=>array('mcp'=>array('public'=>true,'type'=>'tool'),'annotations'=>array('readonly'=>true,'idempotent'=>true,'destructive'=>false))));
        });
    }
    public static function filtros_schema(): array {return array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'dias'=>array('type'=>'integer','minimum'=>1,'maximum'=>90),'caminho'=>array('type'=>'string','maxLength'=>760),'metrica'=>array('type'=>'string','enum'=>array('INP','LCP','CLS','TTFB')),'dispositivo'=>array('type'=>'string','enum'=>array('movel','desktop')),'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),'automacao'=>array('type'=>'string','enum'=>array('audiencia','todas')));}
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(is_wp_error(rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros_schema())))){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        if(!self::pronta()){return array('ok'=>false,'codigo'=>'estrutura_indisponivel');}
        $e+=array('dias'=>28,'ate'=>wp_date('Y-m-d'),'automacao'=>'audiencia','segmento'=>'sem_testes');
        $e+=array('de'=>(new DateTimeImmutable($e['ate'],wp_timezone()))->modify('-'.($e['dias']-1).' days')->format('Y-m-d'));
        $start=new DateTimeImmutable($e['de'],wp_timezone());$end=new DateTimeImmutable($e['ate'],wp_timezone());
        if($start>$end||$start->diff($end)->days>=90){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$t=self::tabela();$where=$wpdb->prepare('dia BETWEEN %s AND %s',$e['de'],$e['ate']).F3Base_Testes::sql($e['segmento']);
        foreach(array('caminho','metrica','dispositivo') as $k){if(!empty($e[$k])){$where.=$wpdb->prepare(" AND {$k}=%s",$e[$k]);}}
        $counts=$wpdb->get_results("SELECT metrica,automacao,COUNT(*) n FROM {$t} WHERE {$where} GROUP BY metrica,automacao",ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
        $out=array();foreach($counts as $row){$m=$row['metrica'];$out[$m]=$out[$m]??array('metrica'=>$m,'amostras'=>0,'p75'=>null,'excluidas_automacao'=>0,'excluidas_legado'=>0,'amostras_atribuidas'=>0,'alvos'=>array(),'scripts'=>array(),'fases_media_ms'=>array(),'fase_dominante'=>null);
            if($e['automacao']==='audiencia'&&$row['automacao']!=='nao_identificada'){$out[$m][in_array($row['automacao'],array('provavel','declarada'),true)?'excluidas_automacao':'excluidas_legado']+=(int)$row['n'];}else{$out[$m]['amostras']+=(int)$row['n'];}}
        $eligible=$where.($e['automacao']==='audiencia'?" AND automacao='nao_identificada'":'');
        foreach($out as $m=>&$row){if(!$row['amostras']){continue;}
            $row['p75']=(float)$wpdb->get_var($wpdb->prepare("SELECT valor FROM {$t} WHERE {$eligible} AND metrica=%s ORDER BY valor,amostra LIMIT 1 OFFSET %d",$m,max(0,(int)ceil($row['amostras']*.75)-1)));
            $targets=array();$scripts=array();$phases=array();$phaseN=array();
            for($offset=0;$offset<$row['amostras'];$offset+=500){$batch=$wpdb->get_col($wpdb->prepare("SELECT atribuicao FROM {$t} WHERE {$eligible} AND metrica=%s ORDER BY amostra LIMIT 500 OFFSET %d",$m,$offset));if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
                foreach($batch as $raw){$a=json_decode((string)$raw,true);if(!$a){continue;}++$row['amostras_atribuidas'];foreach(array('alvo'=>'targets','origem_script'=>'scripts') as $key=>$dest){if(!empty($a[$key])){${$dest}[$a[$key]]=(${$dest}[$a[$key]]??0)+1;}}foreach($a['fases']??array() as $key=>$v){$phases[$key]=($phases[$key]??0)+$v;$phaseN[$key]=($phaseN[$key]??0)+1;}}
            }
            foreach(array('alvos'=>$targets,'scripts'=>$scripts) as $key=>$values){arsort($values);foreach(array_slice($values,0,10,true) as $value=>$n){$row[$key][]=array('valor'=>$value,'amostras'=>$n);}}
            foreach($phases as $key=>$v){$row['fases_media_ms'][$key]=round($v/$phaseN[$key],2);}if($row['fases_media_ms']){arsort($row['fases_media_ms']);$row['fase_dominante']=array_key_first($row['fases_media_ms']);}
        }unset($row);
        return array('ok'=>true,'de'=>$e['de'],'ate'=>$e['ate'],'fuso'=>wp_timezone_string(),'automacao'=>$e['automacao'],'linhas'=>array_values($out),'limite'=>'Sem automação identificada não comprova humanidade. Legado sem classificação não é incluído por padrão. A amostra guarda o último valor; o evento detalhado registra só a primeira emissão e exige pseudônimos. Limites e retenções independentes também impedem correspondência individual histórica. Fases ausentes não são zero; scripts são origens observadas, não prova de causalidade.');
    }
    public static function estatisticas(int $dias,string $caminho='',string $dispositivo='',?string $segmento=null): array {
        $e=array('dias'=>max(1,min(90,$dias)),'segmento'=>$segmento??'sem_testes');if($caminho!==''){$e['caminho']=$caminho;}if($dispositivo!==''){$e['dispositivo']=$dispositivo;}return self::consultar($e)['linhas']??array();
    }
	public static function render( int $dias ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return; }
		if ( ! self::pronta() ) {
			echo '<div class="notice notice-error inline"><p>Armazenamento de Web Vitals indisponível. As amostras permanecem pendentes no navegador dentro do prazo da visita.</p></div>';
			return; }
		$caminho     = isset( $_GET['vital_pagina'] ) && is_string( $_GET['vital_pagina'] ) ? substr( wp_unslash( $_GET['vital_pagina'] ), 0, 760 ) : '';
		$dispositivo = isset( $_GET['vital_dispositivo'] ) && in_array( $_GET['vital_dispositivo'], array( 'movel', 'desktop' ), true ) ? $_GET['vital_dispositivo'] : '';
		echo '<section class="f3base-bloco"><h2>Web Vitals — percentil 75</h2><form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="dias" value="' . esc_attr( (string) $dias ) . '"><label>Caminho <input name="vital_pagina" placeholder="/servicos/" value="' . esc_attr( $caminho ) . '"></label> <label>Tela <select name="vital_dispositivo">';
		foreach ( array(
			''        => 'Todas',
			'movel'   => 'Móvel',
			'desktop' => 'Desktop',
		) as $k => $v ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $dispositivo, $k, false ), esc_html( $v ) ); }
		echo '</select></label> <button class="button">Atualizar</button></form><p>Um último valor por métrica e carregamento, calculado pela biblioteca oficial. Retentativas não duplicam amostras. O dispositivo é estimado pela largura da tela. O período respeita a retenção do registro detalhado; dados antigos sem amostras individuais não permitem reconstruir percentis.</p><table class="widefat striped"><thead><tr><th>Métrica</th><th>Percentil 75</th><th>Amostras</th></tr></thead><tbody>';
		$rows = self::estatisticas( $dias, $caminho, $dispositivo );
		foreach ( $rows as $r ) {
			printf( '<tr><td>%s</td><td>%s%s</td><td>%d</td></tr>', esc_html( $r['metrica'] ), esc_html( number_format_i18n( $r['p75'], 'CLS' === $r['metrica'] ? 3 : 0 ) ), 'CLS' === $r['metrica'] ? '' : ' ms', $r['amostras'] ); }
		if ( ! $rows ) {
			echo '<tr><td colspan="3">Sem amostras neste filtro.</td></tr>'; }
		echo '</tbody></table></section>';
	}
	public static function remover(): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', self::tabela() ) ); }
}
