<?php
/** Cache versionado de conteúdo público, invalidado pelas mudanças do WordPress. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Modulo_Cache_Publico extends F3Base_Modulo {
    /** Registro depende da configuração; diagnóstico detalhado só na consulta de saúde. */
    public function deve_registrar(): bool {return true;}

	public const GERACAO   = 'f3base_publico_geracao';
	public const TTL       = 300;
	public const MAX_BYTES = 4194304;
	public function id(): string {
		return 'cache-publico'; }
	public function nome(): string {
		return 'Cache de conteúdo público'; }
	public function descricao(): string {
		return 'Atualiza o índice de caminhos e os textos llms quando conteúdo, visibilidade ou configuração mudam.'; }
	public function options_que_controlam(): array {
		return array( 'f3base_llms' );
	}
	protected function calcular_estado(): array {
		if ( ! empty( F3Base_Cache_Pagina::estado()['pendente'] ) ) {
			return $this->degradado( 'Atualização do cache de página pendente. A configuração permanece gravada.' ); }
		$r = F3Base_Cache_Pagina::requisitos();
		if ( 'failed' === $r['status'] ) {
			$motivos = array();
			if ( $r['exclusoes']['faltantes'] ) {
				$motivos[] = 'Entradas de cache_rejected_uri não encontradas: ' . implode( ', ', $r['exclusoes']['faltantes'] ); }
			if ( ! $r['rastreamento']['ativado'] ) {
				$motivos[] = 'wpsc_ignore_tracking_parameters precisa estar ativado'; }
			if ( $r['rastreamento']['faltantes'] ) {
				$motivos[] = 'Faltam em wpsc_tracking_parameters: ' . implode( ', ', $r['rastreamento']['faltantes'] ); }
			if ( $r['rastreamento']['proibidos_presentes'] ) {
				$motivos[] = 'ref deve permanecer fora da lista de rastreamento ignorado'; }
			return $this->degradado( implode( '. ', $motivos ) . '. Configure pelo WP Super Cache e atualize o cache.' );
		}
		return $this->ativo( 'Cache interno invalidável e limpeza de página coordenada com o provedor disponível.' );
	}
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'f3base_zelador',
				'metodo'     => 'preparar',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'shutdown',
				'metodo'     => 'concluir',
				'prioridade' => 9999,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => F3Base_Cache_Pagina::CRON,
				'metodo'     => 'verificar',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'rest_pre_dispatch',
				'metodo'     => 'proteger_rota',
				'prioridade' => 0,
				'args'       => 3,
			),
			array(
				'tipo'       => 'filter',
				'hook'       => 'rest_post_dispatch',
				'metodo'     => 'proteger_resposta',
				'prioridade' => 9999,
				'args'       => 3,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_head',
				'metodo'     => 'marcador',
				'prioridade' => 1,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wpseo_saved_postdata',
				'metodo'     => 'seo_salvo',
				'prioridade' => 100,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wpseo_saved_indexable',
				'metodo'     => 'indexavel_salvo',
				'prioridade' => 100,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'post_updated',
				'metodo'     => 'post_atualizado',
				'prioridade' => 100,
				'args'       => 3,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'save_post',
				'metodo'     => 'conteudo_alterado',
				'prioridade' => 100,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'before_delete_post',
				'metodo'     => 'conteudo_removido',
				'prioridade' => 100,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'transition_post_status',
				'metodo'     => 'visibilidade_alterada',
				'prioridade' => 100,
				'args'       => 3,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'added_post_meta',
				'metodo'     => 'meta_alterado',
				'prioridade' => 100,
				'args'       => 4,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'updated_post_meta',
				'metodo'     => 'meta_alterado',
				'prioridade' => 100,
				'args'       => 4,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'deleted_post_meta',
				'metodo'     => 'meta_alterado',
				'prioridade' => 100,
				'args'       => 4,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'set_object_terms',
				'metodo'     => 'conteudo_alterado',
				'prioridade' => 100,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'edited_term',
				'metodo'     => 'invalidar',
				'prioridade' => 100,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'delete_term',
				'metodo'     => 'invalidar',
				'prioridade' => 100,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'switch_theme',
				'metodo'     => 'invalidar',
				'prioridade' => 100,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'updated_option',
				'metodo'     => 'opcao_alterada',
				'prioridade' => 100,
				'args'       => 3,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'added_option',
				'metodo'     => 'opcao_criada',
				'prioridade' => 100,
				'args'       => 2,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'deleted_option',
				'metodo'     => 'opcao_excluida',
				'prioridade' => 100,
				'args'       => 1,
			),
		);
	}
	/** Leads, revisões e métricas internas nunca invalidam páginas públicas. */
	public function conteudo_alterado( $id ): void {
		$post = is_numeric( $id ) ? get_post( (int) $id ) : null;
		if ( $post instanceof WP_Post && ( is_post_publicly_viewable( $post ) || 'wp_block' === $post->post_type ) ) {
			self::invalidar(); }
	}
	public function meta_alterado( $meta_id, $post_id, $chave = '', $valor = null ): void {
		$ignorar = (array) apply_filters( 'f3base_cache_metas_internas', array( '_edit_lock', '_edit_last', '_wp_old_slug', '_wp_old_date', '_wp_trash_meta_status', '_wp_trash_meta_time', '_yoast_wpseo_linkdex', '_yoast_wpseo_content_score' ) );
		if ( in_array( $chave, $ignorar, true ) ) {
			return; }
		$this->conteudo_alterado( $post_id );
		if ( in_array( $chave, array( F3Base_Chaves_Seo::NOINDEX, '_yoast_wpseo_canonical', '_f3base_autoria' ), true ) ) {
			self::invalidar( true ); }
	}
	/** Os eventos de metadados têm o diff; o evento genérico do Yoast não deve duplicar purgas. */
	public function seo_salvo( $id ): void {}
	public function conteudo_removido( $id ): void {
		$post = get_post( (int) $id );
		if ( $post instanceof WP_Post && ( is_post_publicly_viewable( $post ) || 'wp_block' === $post->post_type ) ) {
			self::invalidar( true ); }
	}
	public function post_atualizado( $id, $depois, $antes ): void {
		if ( $antes instanceof WP_Post && $depois instanceof WP_Post && $antes->post_password !== $depois->post_password && ( is_post_publicly_viewable( $antes ) || 'wp_block' === $antes->post_type ) ) {
			self::invalidar( true ); }
	}
	public function visibilidade_alterada( $novo, $antigo, $post ): void {
		if ( ! $post instanceof WP_Post || $novo === $antigo ) {
			return; }
		$antes              = clone $post;
		$antes->post_status = $antigo;
		if ( 'wp_block' === $post->post_type ) {
			self::invalidar( true );
			return; }
		if ( is_post_publicly_viewable( $post ) || is_post_publicly_viewable( $antes ) ) {
			self::invalidar( is_post_publicly_viewable( $antes ) && ! is_post_publicly_viewable( $post ) ); }
	}
	public function indexavel_salvo( $indexavel ): void {
		if ( ! is_object( $indexavel ) || 'post' !== ( $indexavel->object_type ?? '' ) ) {
			return; }
		// A reconstrução inicial em uma leitura não deve limpar a página a cada MISS.
		// Os eventos de publicação/metadados acima já coordenam o cache de página.
		$post = get_post( (int) ( $indexavel->object_id ?? 0 ) );
		if ( $post instanceof WP_Post && ( is_post_publicly_viewable( $post ) || 'wp_block' === $post->post_type ) ) {
			self::nova_geracao(); }
	}
	public function opcao_criada( string $nome, $valor ): void {
		$this->opcao_alterada( $nome, null, $valor ); }
	public function opcao_excluida( string $nome ): void {
		$this->opcao_alterada( $nome, true, null ); }
	public function opcao_alterada( string $nome, $antes = null, $depois = null ): void {
		if ( F3Base_Options::gravando( $nome ) ) {
			return; }
		if ( in_array( $nome, array( 'home', 'siteurl', 'blogname', 'blogdescription', 'blog_public', 'show_on_front', 'page_on_front', 'page_for_posts', 'permalink_structure', 'category_base', 'tag_base', 'active_plugins', 'f3base_llms', 'f3base_robots', 'f3base_redirects' ), true ) || F3Base_Adaptador_Yoast::opcao_publica_alterada( $nome, $antes, $depois ) || F3Base_Cache_Pagina::afeta( $nome ) ) {
			self::invalidar( 'blog_public' === $nome || str_starts_with( $nome, 'wpseo' ) ); }
	}
	public static function invalidar( bool $imediata = false ): void {
		self::nova_geracao();
		if ( F3Base_Cache_Pagina::perfil()['limpeza_disponivel'] || F3Base_Cache_Pagina::perfil()['ativo'] ) {
			F3Base_Cache_Pagina::solicitar();
			if ( $imediata ) {
				F3Base_Cache_Pagina::limpar( true, 'visibilidade_alterada' ); }
		}
	}
	public function instalar(): void {
		F3Base_Cache_Pagina::ativar(); }
	public function preparar(): void {
		F3Base_Cache_Pagina::preparar(); }
	public function concluir(): void {
		F3Base_Cache_Pagina::concluir(); }
	public function verificar(): array {
		return F3Base_Cache_Pagina::tarefa(); }
	public function proteger_rota( $r, $s, $p ) {
		return F3Base_Cache_Pagina::proteger_rota( $r, $s, $p ); }
	public function proteger_resposta( $r, $s, $p ) {
		return F3Base_Cache_Pagina::proteger_resposta( $r, $s, $p ); }
	public function marcador(): void {
		if ( F3Base_Cache_Pagina::perfil()['ativo'] ) {
			echo '<!-- F3BASE-CACHE-PROBE:' . esc_html( wp_generate_uuid4() ) . ' F3BASE-CONFIG:' . esc_html( F3Base_Cache_Pagina::contexto() ) . ' -->' . "\n"; }
	}
	public function desinstalar(): void {
		F3Base_Cache_Pagina::desativar(); }

    private static ?string $geracao_memoria=null;
    public static function geracao(): string {
        if(self::$geracao_memoria===null){$g=get_option('f3base_cache_geracao','');self::$geracao_memoria=is_string($g)&&$g!==''?$g:'inicial-'.F3BASE_PLUGIN_VERSAO;}
        return self::$geracao_memoria;
    }
    private static function nova_geracao(): void {self::$geracao_memoria=wp_generate_uuid4();update_option('f3base_cache_geracao',self::$geracao_memoria,true);}

    /** Public schema cache: 32 bounded PHP-guarded slots, no SQL write or recovery barrier on visits. */
    private static function lembrar_schema(string $chave,callable $gerar) {
        $key=hash('sha256',self::geracao().'|'.F3BASE_PLUGIN_VERSAO.'|'.home_url('/').'|'.get_locale().'|'.$chave);
        $group='f3base-schema';$cached=wp_cache_get($key,$group);if(is_array($cached)&&array_key_exists('valor',$cached)){return $cached['valor'];}
        $dir=WP_CONTENT_DIR.'/f3-core-state';$slot=hexdec(substr($key,0,2))%32;
        $path=$dir.'/schema-'.get_current_blog_id().'-'.$slot.'.php';$guard="<?php exit; ?>\n";
        if(is_dir($dir)&&!is_link($dir)&&!is_link($path)&&is_file($path)){
            $raw=@file_get_contents($path,false,null,0,262145);
            $data=is_string($raw)&&strlen($raw)<=262144&&str_starts_with($raw,$guard)?json_decode(substr($raw,strlen($guard)),true):null;
            if(is_array($data)&&($data['key']??'')===$key&&($data['expira']??0)>time()&&array_key_exists('valor',$data)){wp_cache_set($key,$data,$group,300);return $data['valor'];}
        }
        $value=$gerar();$data=array('key'=>$key,'expira'=>time()+300,'valor'=>$value);wp_cache_set($key,$data,$group,300);
        $raw=$guard.wp_json_encode($data);if(strlen($raw)<=262144&&is_dir($dir)&&!is_link($dir)&&!is_link($path)){
            $tmp=$path.'.'.bin2hex(random_bytes(6)).'.php';$f=@fopen($tmp,'x');if($f){$ok=fwrite($f,$raw)===strlen($raw);fclose($f);@chmod($tmp,0600);if(!$ok||!@rename($tmp,$path)){@unlink($tmp);}}
        }
        return $value;
    }

	public static function lembrar( string $chave, callable $gerar ) {
        if(str_starts_with($chave,'schema:')){return self::lembrar_schema($chave,$gerar);}
		$g        = self::geracao();
		$contexto = array( $g, F3BASE_PLUGIN_VERSAO, home_url( '/' ), get_locale(), get_option( 'permalink_structure' ), apply_filters( 'f3base_cache_contexto', '' ) );
		$nome     = 'f3base_publico_' . hash( 'sha256', $chave . wp_json_encode( $contexto ) );
		$cache    = get_transient( $nome );
		if ( is_array( $cache ) && array_key_exists( 'valor', $cache ) ) {
			return $cache['valor']; }
		$valor = $gerar();
		if ( $g === self::geracao() && strlen( serialize( $valor ) ) <= self::MAX_BYTES ) {
			F3Base_Cache_Orcamento::guardar($nome,$valor,$g); }
		return $valor;
	}
}
