<?php
/** Incremental Slack bridge. Explicit trusted sender and direction; no name-based inference. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Whatsapp_Conversa {
    const OPTION='f3base_whatsapp_site';const STATE='f3base_whatsapp_site_estado';const HOOK='f3base_whatsapp_conversa_coletar';
    public static function padroes(): array {return array('ativo'=>false,'janela_horas'=>24,'canal'=>'','numero'=>'','bots'=>array(),'usuarios_equipe'=>array(),'numeros_ignorados'=>array(),'ponto'=>'','mapa_codigos'=>array(),'campos'=>array('telefone'=>'metadata.event_payload.telefone','nome'=>'metadata.event_payload.nome','texto'=>'metadata.event_payload.texto','sentido'=>'metadata.event_payload.sentido'),'sentido_entrada'=>'entrada');}
    public static function cfg(): array {return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function props(): array {
        $str=array('type'=>'string','maxLength'=>250);$list=array('type'=>'array','maxItems'=>100,'uniqueItems'=>true,'items'=>$str);
        return array('janela_horas'=>array('type'=>'integer','minimum'=>1,'maximum'=>168),'ativo'=>array('type'=>'boolean'),'canal'=>array('type'=>'string','pattern'=>'^(?:[CG][A-Z0-9]{8,63})?$'),'numero'=>$str,'bots'=>$list,'usuarios_equipe'=>$list,'numeros_ignorados'=>$list,'ponto'=>$str,'sentido_entrada'=>$str,'campos'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('telefone','nome','texto','sentido'),'properties'=>array_fill_keys(array('telefone','nome','texto','sentido'),array('type'=>'string','pattern'=>'^[A-Za-z0-9_.]{1,150}$'))),'mapa_codigos'=>array('type'=>'object','maxProperties'=>100,'additionalProperties'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array('canal','parceiro','utm_campaign','utm_content'),$str))));
    }
    public static function validar($v): string {
        $check=rest_validate_value_from_schema($v,array('type'=>'object','additionalProperties'=>false,'properties'=>self::props()));if(is_wp_error($check)){return $check->get_error_message();}$v=array_replace(self::padroes(),$v);
        foreach($v['bots'] as $bot){if(!preg_match('/^[BU][A-Z0-9]{8,63}$/D',$bot)){return 'Identificador do bot/usuário da ponte inválido.';}}
        if($v['ativo']&&($v['canal']===''||!$v['bots']||$v['numero']===''||$v['sentido_entrada']===''||$v['ponto']==='')){return 'Prepare canal, número, bots autorizados, direção de entrada e ponto de conversão.';}
        if($v['numero']!==''&&!preg_match('/^\+?[1-9][0-9]{7,14}$/D',$v['numero'])){return 'Informe o número do site com código de país.';}
        foreach($v['mapa_codigos'] as $code=>$map){if(!preg_match('/^[A-Z0-9_-]{1,30}$/D',$code)){return 'Códigos sem colchetes, em maiúsculas.';}}
        return '';
    }
    public static function revisao(): string {return hash('sha256',F3Base_Options::revisao(self::OPTION).'|'.F3Base_Options::revisao(F3Base_Slack::SEGREDO).'|'.wp_json_encode(get_option(self::STATE,array())));}
    public static function mudou(string $name,$before,$after): void {
        if($name!==self::OPTION){return;}if(!empty($after['ativo'])){F3Base_Options::atualizar_estado(self::STATE,static function($s)use($after){$identity=hash('sha256',$after['canal'].'|'.$after['numero']);if(isset($s['identidade'])&&$s['identidade']!==$identity&&!empty($s['pendentes'])){$s['revisao_necessaria']=true;return $s;}if(($s['identidade']??'')!==$identity){$s=array('identidade'=>$identity,'ultimo_ts'=>sprintf('%.6f',microtime(true)));}$s['operador']=get_current_user_id();return $s;});F3Base_Fila::agendar(self::HOOK,time()+60);}
    }
    public static function campo(array $v,string $path): string {foreach(explode('.',$path) as $part){if(!is_array($v)||!array_key_exists($part,$v)){return '';}$v=$v[$part];}return is_scalar($v)?(string)$v:'';}
    public static function interpretar(array $m,array $cfg): array {
        if(!preg_match('/^[0-9]{10,12}\.[0-9]{1,6}$/D',(string)($m['ts']??''))){return array('codigo'=>'mensagem_sem_instante');}
        if(in_array($m['user']??'',$cfg['usuarios_equipe'],true)||!array_intersect(array_filter(array($m['bot_id']??'',$m['user']??'')),$cfg['bots'])){return array('codigo'=>'remetente_fora_da_ponte');}
        if(self::campo($m,$cfg['campos']['sentido'])===''){return array('codigo'=>'ponte_formato_nao_reconhecido');}
        if(self::campo($m,$cfg['campos']['sentido'])!==$cfg['sentido_entrada']){return array('codigo'=>'sentido_nao_entrada');}
        $phone=self::campo($m,$cfg['campos']['telefone']);$phone=preg_replace('/[ ().-]/','',$phone);if(!preg_match('/^\+?[1-9][0-9]{7,14}$/D',$phone)){return array('codigo'=>'telefone_sem_identidade');}$phone='+'.ltrim($phone,'+');
        $ignored=array_map(static fn($x)=>'+'.ltrim(preg_replace('/[ ().-]/','',$x),'+'),array_merge($cfg['numeros_ignorados'],array($cfg['numero'])));if(in_array($phone,$ignored,true)){return array('codigo'=>'numero_ignorado');}
        $text=self::campo($m,$cfg['campos']['texto']);if($text===''){return array('codigo'=>'texto_ausente_no_envelope');}$test=str_contains($text,'[TESTE F3BASE]');$codes=array();preg_match_all('/\[([A-Z0-9_-]{1,30})\]/u',$text,$codes);$code='';foreach($codes[1] as $candidate){if(isset($cfg['mapa_codigos'][$candidate])){$code=$candidate;break;}}
        $origin=$code!==''?$cfg['mapa_codigos'][$code]:array('canal'=>'WhatsApp sem origem');$origin['parceiro']=$origin['parceiro']??'interno';
        return array('codigo'=>'conversa_elegivel','identidade'=>hash_hmac('sha256','whatsapp|'.$cfg['numero'].'|'.$phone,wp_salt('secure_auth')),'privado'=>array('nome'=>mb_substr(sanitize_text_field(self::campo($m,$cfg['campos']['nome'])),0,250),'telefone'=>$phone,'email'=>'','empresa'=>'','mensagem_ts'=>$m['ts'],'primeiro_contato_em'=>gmdate('c',(int)(float)$m['ts']),'origem_declarada'=>$origin,'codigo_origem'=>$code,'triagem'=>mb_substr(sanitize_textarea_field($text),0,300),'contexto_teste'=>$test));
    }
    public static function verificar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$cfg=self::cfg();if($cfg['canal']===''){return array('ok'=>false,'codigo'=>'whatsapp_canal_ausente');}
        $r=F3Base_Slack::api('conversations.history',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$cfg['canal'],'limit'=>15));if(empty($r['ok'])){return $r+array('escopos_possiveis'=>array('channels:history','groups:history'));}
        $codes=array();foreach($r['messages'] as $m){$code=self::interpretar($m,$cfg)['codigo'];$codes[$code]=($codes[$code]??0)+1;}
        return array('ok'=>true,'simular'=>true,'codigo'=>'slack_leitura_confirmada','amostra'=>$codes,'revisao'=>self::revisao(),'contatos_criados'=>0,'limite'=>'Valide os caminhos de campos contra o envelope da ponte. Mensagens sem identidade/direção explícitas não são importadas.');
    }
    public static function consultar(array $e=array()): array {if(!current_user_can('manage_options')||!current_user_can('f3base_gerir_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}if(($e['simular']??true)!==false){return self::verificar()+array('reler_janela'=>!empty($e['reler_janela']),'efeito_releitura'=>'Descarta apenas o preparo cifrado da janela; mantém marco anterior, contatos persistidos e deduplicação.');}if(!hash_equals(self::revisao(),(string)($e['revisao']??''))){return array('ok'=>false,'codigo'=>'conflito');}if(!empty($e['reler_janela'])){$lock=F3Base_Trava::adquirir('whatsapp-conversa-worker',60);if(!$lock){return array('ok'=>false,'codigo'=>'whatsapp_ocupado');}try{$cfg=self::cfg();$s=get_option(self::STATE,array());if(!hash_equals((string)($s['identidade']??''),hash('sha256',$cfg['canal'].'|'.$cfg['numero']))){return array('ok'=>false,'codigo'=>'whatsapp_contexto_divergente');}unset($s['janela_revisao'],$s['cursor'],$s['pendentes'],$s['completo']);$saved=F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>$s);return array('ok'=>!empty($saved['persisted']),'persisted'=>!empty($saved['persisted']),'codigo'=>'whatsapp_janela_repreparada','revisao'=>self::revisao());}finally{F3Base_Trava::liberar($lock);}}return self::coletar();}
    public static function coletar(): array {
        $lock=F3Base_Trava::adquirir('whatsapp-conversa-worker',60);if(!$lock){return array('ok'=>false,'codigo'=>'whatsapp_ocupado');}
        try{
            $cfg=self::cfg();$s=get_option(self::STATE,array());if(empty($cfg['ativo'])||!empty($s['revisao_necessaria'])||empty($s['operador'])||!user_can($s['operador'],'manage_options')||!user_can($s['operador'],'f3base_gerir_leads')){return array('ok'=>false,'codigo'=>'whatsapp_pausado');}
            $revision=F3Base_Options::revisao(self::OPTION);if(isset($s['janela_revisao'])&&$s['janela_revisao']!==$revision){return array('ok'=>false,'codigo'=>'whatsapp_janela_configuracao_alterada');}
            $s['janela_revisao']=$revision;$s['ate']=$s['ate']??sprintf('%.6f',microtime(true));$pending=empty($s['pendentes'])?array():F3Base_Contato_Comunicacao::abrir($s['pendentes']);if($pending===null){return array('ok'=>false,'codigo'=>'whatsapp_pendentes_ilegivel');}
            if(empty($s['completo'])){
                $r=F3Base_Slack::api('conversations.history',F3Base_Segredos::abrir(F3Base_Slack::SEGREDO),array('channel'=>$cfg['canal'],'oldest'=>$s['ultimo_ts']??$s['ate'],'latest'=>$s['ate'],'inclusive'=>true,'limit'=>15,'cursor'=>$s['cursor']??''));if(empty($r['ok'])){return $r;}
                $stats=$s['estatisticas']??array();foreach($r['messages'] as $m){if((float)($m['ts']??0)<=(float)($s['ultimo_ts']??0)||(float)($m['ts']??0)>(float)$s['ate']){continue;}$parsed=self::interpretar($m,$cfg);$code=$parsed['codigo'];if(in_array($code,array('ponte_formato_nao_reconhecido','telefone_sem_identidade','texto_ausente_no_envelope'),true)){return array('ok'=>false,'codigo'=>'whatsapp_envelope_requer_mapeamento','motivo'=>$code,'cursor_preservado'=>true);}$stats[$code]=($stats[$code]??0)+1;if(empty($parsed['privado'])){continue;}$key=$parsed['identidade'];$candidate=$parsed['privado'];if(!isset($pending[$key])||(float)$candidate['mensagem_ts']<(float)$pending[$key]['mensagem_ts']){$pending[$key]=$candidate;}}
                if(count($pending)>500){return array('ok'=>false,'codigo'=>'whatsapp_janela_excede_limite_revisar');}if($r['has_more']&&($r['cursor']===''||$r['cursor']===($s['cursor']??''))){return array('ok'=>false,'codigo'=>'slack_cursor_incompleto');}
                $s['estatisticas']=$stats;$s['cursor']=$r['cursor'];$s['completo']=!$r['has_more'];$s['pendentes']=F3Base_Contato_Comunicacao::cifrar($pending);$save=F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>F3Base_Options::revisao(self::OPTION)===$revision?$s:null);if(empty($save['persisted'])){return array('ok'=>false,'codigo'=>'whatsapp_checkpoint_falhou');}
                if(!$s['completo']){return array('ok'=>true,'codigo'=>'whatsapp_paginacao_pendente','continuacao'=>true);}
            }
            $done=0;foreach($pending as $key=>$private){if($done>=15){break;}if(F3Base_Options::revisao(self::OPTION)!==$revision||empty(self::cfg()['ativo'])||!user_can($s['operador'],'manage_options')||!user_can($s['operador'],'f3base_gerir_leads')){return array('ok'=>false,'codigo'=>'whatsapp_politica_alterada');}$receipt=F3Base_Conversas::persistir('whatsapp_conversa',$key,$private,array('pipedrive'=>true,'slack'=>true,'ponto'=>$cfg['ponto'],'operador'=>$s['operador']));if(empty($receipt['persisted'])&&empty($receipt['suppressed'])){return array('ok'=>false,'codigo'=>$receipt['codigo']??'whatsapp_persistencia_pendente');}unset($pending[$key]);$done++;}
            $s['pendentes']=F3Base_Contato_Comunicacao::cifrar($pending);if(!$pending){$s['ultimo_ts']=$s['ate'];unset($s['ate'],$s['cursor'],$s['completo'],$s['pendentes'],$s['janela_revisao']);}$s['ultima_passagem']=time();$save=F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>F3Base_Options::revisao(self::OPTION)===$revision?$s:null);return array('ok'=>!empty($save['persisted']),'codigo'=>'whatsapp_passagem_concluida','processados'=>$done,'pendentes'=>count($pending),'revisao'=>self::revisao());
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function apagar_pendente(array $lead): bool {
        if(($lead['metodo']??'')!=='whatsapp_conversa'){return true;}$lock=F3Base_Trava::adquirir('whatsapp-conversa-worker',60);if(!$lock){return false;}
        try{$s=get_option(self::STATE,array());if(empty($s['pendentes'])){return true;}$p=F3Base_Contato_Comunicacao::abrir($s['pendentes']);if($p===null){return false;}if(!isset($p[$lead['idempotencia']])){return true;}unset($p[$lead['idempotencia']]);$s['pendentes']=F3Base_Contato_Comunicacao::cifrar($p);return !empty(F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>$s)['persisted']);}finally{F3Base_Trava::liberar($lock);}
    }
    public static function iniciar(): void {
        add_filter('f3base_options_catalogo',static function($c){$c[self::OPTION]=F3Base_Conversas::catalogo_grupo(self::OPTION,'Conversas WhatsApp pela ponte Slack',self::padroes(),self::props(),array(__CLASS__,'validar'));$c[self::STATE]=array('rotulo'=>'Cursor de conversas WhatsApp','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','autoload'=>false,'padrao'=>array(),'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;});
        add_action('updated_option',array(__CLASS__,'mudou'),40,3);add_action('added_option',static fn($n,$v)=>self::mudou($n,null,$v),40,2);
        add_action(self::HOOK,static function(){try{self::coletar();}finally{if(!empty(self::cfg()['ativo'])){F3Base_Fila::agendar(self::HOOK,time()+300);}}});
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),92);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('whatsapp-conversa-verificar','Provar leitura Slack e envelope da ponte, sem importar ou avisar',array(__CLASS__,'verificar'),array('simular'=>array('type'=>'boolean','enum'=>array(true),'default'=>true)));F3Base_Servicos::ability('whatsapp-conversa-consultar','Simular ou processar janela incremental da ponte Slack',array(__CLASS__,'consultar'),array('simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'reler_janela'=>array('type'=>'boolean','default'=>false)),array(),false);});
    }
    public static function conferir_agenda_1(): void {if(!empty(self::cfg()['ativo'])&&!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+60);}}
}
