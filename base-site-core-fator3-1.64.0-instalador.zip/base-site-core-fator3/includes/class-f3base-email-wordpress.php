<?php
/** Policy for native administrative mail; never changes automatic update execution. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Wordpress {
    const OPTION='f3base_email_wordpress';
    private static string $marcador='';
    public static function padroes(): array {return array('plugin_sucesso'=>false,'tema_sucesso'=>false,'nucleo_sucesso'=>false,'plugin_falha'=>true,'tema_falha'=>true,'nucleo_falha'=>true,'nucleo_critico'=>true,'nucleo_manual'=>true,'recuperacao_fatal'=>true);}
    public static function catalogo(array $c): array {
        $d=self::padroes();$s=array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array_keys($d),array('type'=>'boolean')));
        $c[self::OPTION]=array('rotulo'=>'E-mails nativos do WordPress','descricao'=>'Política das notificações administrativas nativas. Sucesso de atualização automática desativado por padrão; falhas, atualização manual necessária e recuperação fatal preservadas. Não desliga atualizações.','operavel'=>true,'secao'=>'conexoes','campo'=>'grupo','autoload'=>true,'padrao'=>$d,'schema_config'=>$s,'schema_entrada'=>$s,'sanitiza'=>static fn($v)=>array_replace($d,is_array($v)?$v:array()),'recusa'=>static fn($v)=>is_wp_error(rest_validate_value_from_schema($v,$s))?'Use somente as chaves documentadas com valores booleanos.':'');return $c;
    }
    public static function iniciar(): void {
        add_filter('auto_plugin_update_send_email',array(__CLASS__,'plugins'),20,2);
        add_filter('auto_theme_update_send_email',array(__CLASS__,'temas'),20,2);
        add_filter('auto_core_update_send_email',array(__CLASS__,'nucleo'),20,2);
        add_filter('auto_core_update_email',array(__CLASS__,'email_nucleo'),20,2);
        add_filter('recovery_mode_email',array(__CLASS__,'recuperacao'),20);
        add_filter('pre_wp_mail',array(__CLASS__,'suprimir'),PHP_INT_MIN,2);
    }
    public static function resumo(): array {return array('option'=>self::OPTION,'politica'=>F3Base_Options::ler(self::OPTION),'destino'=>'admin_email definido pelo WordPress','atualizacoes_automaticas'=>'inalteradas','lote_misto'=>'Mantém o lote quando há falha permitida, inclusive seus sucessos.');}
    private static function lote($send,array $results,string $kind): bool {
        if(!$send){return false;}$c=F3Base_Options::ler(self::OPTION);$success=false;$failure=false;
        foreach($results as $r){if(is_object($r)&&($r->result??null)===true){$success=true;}else{$failure=true;}}
        return ($failure&&!empty($c[$kind.'_falha']))||($success&&!empty($c[$kind.'_sucesso']));
    }
    public static function plugins($send,$results=array()): bool {return self::lote($send,(array)$results,'plugin');}
    public static function temas($send,$results=array()): bool {return self::lote($send,(array)$results,'tema');}
    public static function nucleo($send,string $type): bool {
        $keys=array('success'=>'nucleo_sucesso','fail'=>'nucleo_falha','critical'=>'nucleo_critico','manual'=>'nucleo_manual');
        return (bool)$send&&(!isset($keys[$type])||!empty(F3Base_Options::ler(self::OPTION)[$keys[$type]]));
    }
    /** WordPress skips the boolean filter for manual; recovery has only an email-arguments filter. */
    public static function email_nucleo(array $email,string $type): array {return $type==='manual'&&!self::nucleo(true,$type)?self::marcar($email):$email;}
    public static function recuperacao(array $email): array {return empty(F3Base_Options::ler(self::OPTION)['recuperacao_fatal'])?self::marcar($email):$email;}
    private static function marcar(array $email): array {
        if(self::$marcador===''){self::$marcador=bin2hex(random_bytes(16));}
        $headers=$email['headers']??array();if(!is_array($headers)){$headers=preg_split('/\r?\n/',(string)$headers);}
        $headers[]='X-F3Base-Suprimir: '.self::$marcador;$email['headers']=$headers;return $email;
    }
    public static function suprimir($pre,array $mail) {
        if(self::$marcador===''){return $pre;}$headers=$mail['headers']??array();if(!is_array($headers)){$headers=preg_split('/\r?\n/',(string)$headers);}
        return in_array('X-F3Base-Suprimir: '.self::$marcador,$headers,true)?true:$pre;
    }
}
