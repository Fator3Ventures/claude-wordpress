<?php
/** Native LinkedIn acquisition. Polling and notification details share one durable ingestion. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin {
    const OPCAO='f3base_anuncios_linkedin';const ESTADO='f3base_linkedin_estado';const EVENTO='f3base_linkedin_consultar';
    public static function config(): array {return F3Base_Linkedin_Integracoes::config();}
    public static function contexto(): string {return F3Base_Linkedin_Integracoes::contexto();}
    public static function dono(array $cfg): string {return 'urn:li:sponsoredAccount:'.$cfg['conta_id'];}
    public static function form_id(string $v): string {if(preg_match('/^(?:urn:li:(?:leadGenForm|adForm):)?([0-9]{1,40})$/D',$v,$m)){return $m[1];}if(preg_match('/^urn:li:versionedLeadGenForm:\(urn:li:leadGenForm:([0-9]{1,40}),\s*[0-9]+\)$/D',$v,$m)){return $m[1];}return '';}
    public static function versionada(string $v): ?array {return preg_match('/^urn:li:versionedLeadGenForm:\(urn:li:leadGenForm:([0-9]{1,40}),\s*([0-9]+)\)$/D',$v,$m)?array('id'=>$m[1],'versao'=>$m[2],'urn'=>'urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$m[1].','.$m[2].')'):null;}
    public static function formularios(array $cfg): array {return array_values(array_unique(array_filter(array_map(array(__CLASS__,'form_id'),$cfg['formularios']??array()))));}
    public static function instante($value): ?array {
        if(!is_int($value)&&!is_string($value)){return null;}$s=(string)$value;if(!preg_match('/^[0-9]{10,13}$/D',$s)){return null;}$ms=strlen($s)>10?(int)$s:(int)$s*1000;$sec=intdiv($ms,1000);if($sec<946684800||$sec>time()+300){return null;}return array('ms'=>(string)$ms,'segundos'=>$sec);
    }
    public static function localizado($text,array $locale=array()): string {if(is_string($text)){return sanitize_text_field($text);}$all=is_array($text)?($text['localized']??array()):array();$all=is_array($all)?$all:array();$key=($locale['language']??'pt').'_'.($locale['country']??'BR');$v=$all[$key]??$all['pt_BR']??reset($all);return is_string($v)?sanitize_text_field($v):'';}
    public static function definicao(array $form): array {
        $fields=array();$loc=$form['creationLocale']??array();foreach($form['content']['questions']??array() as $q){$id=(string)($q['questionId']??'');if(!preg_match('/^[0-9]+$/D',$id)){continue;}$opts=array();foreach($q['questionDetails']['multipleChoiceQuestionDetails']['options']??array() as $o){$opts[]=array('valor'=>(string)$o['id'],'rotulo'=>self::localizado($o['text']??'', $loc));}$fields[]=array('nome'=>$id,'nome_remoto'=>(string)($q['name']??''),'rotulo'=>self::localizado($q['question']??'',$loc)?:$id,'tipo'=>$opts?'multiple_choice':'text','predefinido'=>$q['predefinedField']??'','opcoes'=>$opts);}
        return array('id'=>'linkedin-'.$form['id'],'titulo'=>self::localizado($form['name']??'',$loc)?:'LinkedIn '.$form['id'],'campos'=>$fields,'versao'=>(string)($form['versionId']??''),'revisao'=>hash('sha256',wp_json_encode($form['content']??array())),'obtido_em'=>time());
    }
    public static function catalogo(string $id): ?array {if(!F3Base_Linkedin_Integracoes::tem_escopo()&&count(F3Base_Linkedin_Integracoes::colecao())!==1){$found=array();foreach(F3Base_Linkedin_Integracoes::colecao() as $key=>$cfg){$one=F3Base_Linkedin_Integracoes::executar((string)$key,static fn()=>self::catalogo($id));if(is_array($one)&&isset($one['campos'])){$found[]=$one;}}return count($found)===1?$found[0]:null;}$s=F3Base_Linkedin_Integracoes::estado();$f=$s['formularios'][$id]??null;return is_array($f)&&($f['owner']['sponsoredAccount']??'')===self::dono(self::config())?self::definicao($f):null;}
    public static function formulario(string $id,array $cfg): array {
        $r=F3Base_Linkedin_Cliente::pedir('GET','leadForms/'.$id);$f=$r['data']??array();if(empty($r['ok'])){return $r;}
        if((string)($f['id']??'')!==$id||($f['owner']['sponsoredAccount']??'')!==self::dono($cfg)||!preg_match('/^[0-9]+$/D',(string)($f['versionId']??''))||!is_array($f['content']['questions']??null)){return array('ok'=>false,'codigo'=>'formulario_ou_proprietario_divergente');}
        $ctx=F3Base_Linkedin_Integracoes::revisao_execucao();$save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($id,$f,$ctx){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$ctx){return null;}$s['formularios'][$id]=$f;return $s;});return empty($save['persisted'])?array('ok'=>false,'codigo'=>'catalogo_linkedin_nao_persistido'):array('ok'=>true,'formulario'=>$f);
    }
    /** Read only the authenticated member's roles, with bounded, explicit coverage. */
    private static function papel(string $path,string $finder,string $field,string $asset,array $allowed): array {
        $base=array('estado'=>'nao_comprovado','fonte'=>$path.'?q='.$finder,'em'=>time(),'ativo'=>$asset);$start=0;$seen=array();$observed=array();
        for($page=0;$page<20;$page++){
            $r=F3Base_Linkedin_Cliente::pedir('GET',$path,array('q'=>$finder,'start'=>$start,'count'=>50));
            if(empty($r['ok'])){return $base+array('codigo'=>$r['codigo'],'http'=>$r['http']??null,'retry_after'=>$r['retry_after']??null);}
            $rows=$r['data']['elements']??null;$paging=$r['data']['paging']??null;
            if(!is_array($rows)||!is_array($paging)||(int)($paging['start']??-1)!==$start||count($rows)>50){return $base+array('codigo'=>'papeis_resposta_invalida');}
            $hash=hash('sha256',wp_json_encode($rows));if($rows&&isset($seen[$hash])){return $base+array('codigo'=>'papeis_paginacao_repetida');}$seen[$hash]=true;
            foreach($rows as $row){if(!is_array($row)){return $base+array('codigo'=>'papeis_resposta_invalida');}if(($row[$field]??'')!==$asset){continue;}$role=$row['role']??'';$state=$row['state']??null;
                if(is_string($role)){$observed[]=array('papel'=>$role,'estado'=>$state);}
                if(in_array($role,$allowed,true)&&($path!=='organizationAcls'||$state==='APPROVED')){return array_replace($base,array('estado'=>'comprovado','codigo'=>'papel_confirmado','papel'=>$role));}
            }
            $links=$paging['links']??array();$hasNext=is_array($links)&&array_filter($links,static fn($l)=>is_array($l)&&($l['rel']??'')==='next');
            $more=isset($paging['total'])?$start+count($rows)<(int)$paging['total']:($hasNext||count($rows)===50);
            if(!$more){return array_replace($base,array('estado'=>'recusado','codigo'=>'papel_elegivel_ausente','papeis_observados'=>$observed));}
            if(!$rows){return $base+array('codigo'=>'papeis_paginacao_sem_progresso');}$start+=count($rows);
        }
        return $base+array('codigo'=>'papeis_limite_paginas','limite_paginas'=>20);
    }
    private static function papeis(array $cfg): array {
        $account=self::dono($cfg);$out=array('conta'=>array('estado'=>'nao_comprovado','fonte'=>'adAccounts','em'=>time()),'papel_conta'=>array('estado'=>'nao_comprovado','permissao_necessaria'=>'r_ads ou rw_ads'),'pagina'=>array('estado'=>'nao_comprovado'),'papel_pagina'=>array('estado'=>'nao_comprovado','permissao_necessaria'=>'r_organization_admin ou rw_organization_admin'));
        $r=F3Base_Linkedin_Cliente::pedir('GET','adAccounts/'.$cfg['conta_id']);
        if(empty($r['ok'])){$out['conta']+=array('codigo'=>$r['codigo'],'http'=>$r['http']??null,'permissao_necessaria'=>'r_ads ou rw_ads');return $out;}
        if((string)($r['data']['id']??'')!==$cfg['conta_id']){$out['conta']['codigo']='conta_metadados_divergente';return $out;}
        $out['conta']=array('estado'=>'comprovado','fonte'=>'adAccounts/'.$cfg['conta_id'],'em'=>time(),'urn'=>$account);
        $out['papel_conta']=self::papel('adAccountUsers','authenticatedUser','account',$account,array('ACCOUNT_BILLING_ADMIN','ACCOUNT_MANAGER','CAMPAIGN_MANAGER','CREATIVE_MANAGER','VIEWER'))+array('permissao_necessaria'=>'r_ads ou rw_ads');
        $org=$r['data']['reference']??'';if(!is_string($org)||!preg_match('/^urn:li:organization:[0-9]+$/D',$org)){$out['pagina']['codigo']='pagina_associada_nao_informada';return $out;}
        $out['pagina']=array('estado'=>'comprovado','fonte'=>'adAccounts.reference','em'=>time(),'urn'=>$org);
        $out['papel_pagina']=self::papel('organizationAcls','roleAssignee','organization',$org,array('ADMINISTRATOR','LEAD_GEN_FORMS_MANAGER','CURATOR','CONTENT_ADMINISTRATOR','ANALYST'))+array('permissao_necessaria'=>'r_organization_admin ou rw_organization_admin');return $out;
    }
    public static function verificar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$cfg=self::config();if(($e['simular']??true)!==false){return array('ok'=>true,'simular'=>true,'efeito'=>'Introspecção do token e leitura dos formulários selecionados; não consulta contatos nem cria assinaturas.','diagnostico'=>self::diagnostico());}
        if(!preg_match('/^[0-9]+$/D',$cfg['conta_id'])){return array('ok'=>false,'codigo'=>'conta_linkedin_ausente');}$lock=F3Base_Trava::adquirir('linkedin-acesso:'.F3Base_Linkedin_Integracoes::id(),60);if(!$lock){return array('ok'=>false,'codigo'=>'verificacao_ocupada');}
        try{$ctx=F3Base_Linkedin_Integracoes::revisao_execucao();F3Base_Linkedin_Cliente::prazo(microtime(true)+20);$r=F3Base_Linkedin_Cliente::introspectar($cfg);$forms=array();$ok=!empty($r['ok']);foreach(self::formularios($cfg) as $id){$f=self::formulario($id,$cfg);$forms[$id]=array('ok'=>!empty($f['ok']),'codigo'=>$f['codigo']??'formulario_confirmado','versao'=>$f['formulario']['versionId']??null);$ok=$ok&&!empty($f['ok']);if(empty($f['ok'])){break;}}
            $roles=($cfg['cliente']??'core')==='linkedin_plugin'?($r['papeis']??array()):(!empty($r['ok'])?self::papeis($cfg):array());$denied=(bool)array_filter($roles,static fn($v)=>($v['estado']??'')==='recusado');$complete=!empty($r['escopo_comprovado'])&&count($roles)===4&&!array_filter($roles,static fn($v)=>($v['estado']??'')!=='comprovado')&&count($forms)>0&&$ok;$ok=$ok&&!$denied;
            $result=array('ok'=>$ok,'em'=>time(),'contexto'=>$ctx,'token'=>$r,'formularios'=>$forms,'selecionados'=>count(self::formularios($cfg)),'leitura_respostas'=>'nao_executada','papeis_conta_pagina'=>$roles,'verificacao_completa'=>$complete,'codigo'=>$denied?'papel_linkedin_recusado':(!$ok?'acesso_linkedin_pendente':($complete?'acesso_preparado_leads_nao_consultados':'verificacao_parcial')));
            $save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($result,$ctx){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$ctx){return null;}$s['acesso']=$result;return $s;});$result['persisted']=!empty($save['persisted']);return $result;
        }finally{F3Base_Linkedin_Cliente::prazo(0);F3Base_Trava::liberar($lock);}
    }
    public static function mudou(string $name,$before,$after): void {
        if(!in_array($name,array(self::OPCAO,F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET),true)||$before===$after){return;}
        F3Base_Linkedin_Integracoes::alterada($name,$before,$after);
    }
    /** Only this adapter can produce a LinkedIn native envelope; there is no public import. */
    public static function traduzir(array $response,array $cfg,array $form): array {
        $v=self::versionada((string)($response['versionedLeadGenFormUrn']??''));$at=self::instante($response['submittedAt']??null);$id=(string)($response['id']??'');
        if(!$v||!$at||!preg_match('/^[A-Za-z0-9_-]{1,150}$/D',$id)||!in_array($v['id'],self::formularios($cfg),true)||($response['owner']['sponsoredAccount']??'')!==self::dono($cfg)||($response['leadType']??'')!=='SPONSORED'||!is_bool($response['testLead']??null)){return array('ok'=>false,'codigo'=>'resposta_linkedin_fora_do_escopo');}
        // Prefer the decorated version-specific form. A current form with a different
        // version must not silently label old answers with new questions.
        if(isset($response['form'])&&is_array($response['form'])){$form=$response['form']+array('id'=>$v['id'],'versionId'=>$v['versao']);}
        if((string)($form['id']??'')!==$v['id']||(string)($form['versionId']??'')!==$v['versao']){return array('ok'=>false,'codigo'=>'versao_formulario_nao_resolvida');}
        $def=self::definicao($form);$byid=array_column($def['campos'],null,'nome');$names=array_count_values(array_column($def['campos'],'nome_remoto'));$fieldData=array();$roles=array();$roleValues=array();$first='';$last='';
        $mapping=array_replace($cfg['mapeamento']['campos']??array(),$cfg['mapeamento']['formularios'][$v['id']]['campos']??array());
        foreach($response['formResponse']['answers']??array() as $answer){$qid=(string)($answer['questionId']??'');$q=$byid[$qid]??null;if(!$q){return array('ok'=>false,'codigo'=>'pergunta_sem_definicao');}$details=$answer['answerDetails']??array();$value=$details['textQuestionAnswer']['answer']??$details['multipleChoiceAnswer']['options']??null;if(!is_string($value)&&!is_array($value)){return array('ok'=>false,'codigo'=>'resposta_pergunta_invalida');}
            $vals=is_array($value)?array_map('strval',$value):array($value);$options=array_column($q['opcoes'],'rotulo','valor');if($options){$vals=array_map(static fn($x)=>$options[$x]??$x,$vals);}$fieldData[]=array('name'=>$qid,'values'=>$vals);
            $role=$mapping[$qid]??(($q['nome_remoto']!==''&&($names[$q['nome_remoto']]??0)===1)?($mapping[$q['nome_remoto']]??''):'');
            if($role===''){$role=array('EMAIL'=>'email','PHONE_NUMBER'=>'telefone','COMPANY_NAME'=>'empresa','JOB_TITLE'=>'cargo','FULL_NAME'=>'nome')[$q['predefinido']]??'';}
            if($role!==''&&($role==='servicos'||count($vals)===1)){$roleValues[$role][]=$role==='servicos'?$vals:$vals[0];}
            if($q['predefinido']==='FIRST_NAME'){$first=$vals[0]??'';}if($q['predefinido']==='LAST_NAME'){$last=$vals[0]??'';}
        }
        foreach($roleValues as $role=>$values){if(count($values)===1){$roles[$role]=$values[0];}}
        if(empty($roles['nome'])&&trim($first.' '.$last)!==''){$roles['nome']=trim($first.' '.$last);}
        $nativeConsents=array();$consentDefs=array_column($form['content']['legalInfo']['consents']??array(),null,'id');
        foreach($response['formResponse']['consentResponses']??array() as $c){if(!is_bool($c['accepted']??null)){return array('ok'=>false,'codigo'=>'consentimento_nativo_invalido');}$cid=(string)($c['consentId']??'');$nativeConsents[]=array('id'=>$cid,'aceito'=>$c['accepted'],'texto'=>self::localizado($c['consent']??$consentDefs[$cid]['consent']??'',$form['creationLocale']??array()));$fieldData[]=array('name'=>'consentimento_'.$cid,'values'=>array($c['accepted']?'sim':'nao'));}
        $urnid=static fn($urn,$type)=>is_string($urn)&&preg_match('/^urn:li:'.preg_quote($type,'/').':([0-9]+)$/D',$urn,$m)?$m[1]:'';
        $campaign=$urnid($response['leadMetadata']['sponsoredLeadMetadata']['campaign']??'','sponsoredCampaign');$creative=$urnid($response['associatedEntity']['associatedCreative']??'','sponsoredCreative');$cn=$response['leadMetadataInfo']['sponsoredLeadMetadataInfo']['campaign']??array();
        $p=array('lead_id'=>$id,'form_id'=>$v['id'],'created_time'=>gmdate('c',$at['segundos']),'is_test'=>$response['testLead'],'campaign_id'=>$campaign,'creative_id'=>$creative,'campaign_name'=>($cn['id']??'')==='urn:li:sponsoredCampaign:'.$campaign?self::localizado($cn['name']??''):'','field_data'=>$fieldData,'_linkedin'=>array('submitted_at_ms'=>$at['ms'],'response_urn'=>'urn:li:leadGenFormResponse:'.$id,'versioned_form'=>$v['urn'],'respostas_ids'=>$response['formResponse']['answers']??array(),'campos_ocultos'=>$response['form']['hiddenFields']??array(),'consentimentos'=>$nativeConsents,'catalogo'=>$def,'papeis'=>$roles));
        return array('ok'=>true,'payload'=>$p);
    }
    public static function ingerir_resposta(array $response,string $via): array {
        $cfg=self::config();$execution=F3Base_Linkedin_Integracoes::revisao_execucao();$v=self::versionada((string)($response['versionedLeadGenFormUrn']??''));if(!$v){return array('ok'=>false,'codigo'=>'formulario_versionado_ausente');}$form=F3Base_Linkedin_Integracoes::estado()['formularios'][$v['id']]??array();
        if(!$form&&!isset($response['form'])){$f=self::formulario($v['id'],$cfg);if(empty($f['ok'])){return $f;}$form=$f['formulario'];}
        $r=self::traduzir($response,$cfg,$form);if(empty($r['ok'])){return $r;}$lock=F3Base_Trava::adquirir('linkedin-submissao:'.hash('sha256',$cfg['conta_id'].'|'.$v['id'].'|'.$r['payload']['lead_id']),30);if(!$lock){return array('ok'=>false,'codigo'=>'submissao_ocupada');}try{if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){return array('ok'=>false,'codigo'=>'revision_conflict');}$r['payload']['_linkedin']['integracao_id']=F3Base_Linkedin_Integracoes::id();$r['payload']['_linkedin']['cliente']=$cfg['cliente'];$r['payload']['_linkedin']['connection_id']=$cfg['connection_id'];return F3Base_Anuncios::ingerir('linkedin',$r['payload'],$via);}finally{F3Base_Trava::liberar($lock);}
    }
    public static function consultar(): array {
        $cfg=self::config();if(!F3Base_Linkedin_Integracoes::liberada()){return array('ok'=>false,'codigo'=>'transicao_em_curso');}if(empty($cfg['ativo'])||empty($cfg['proprietario_confirmado'])){return array('ok'=>true,'codigo'=>'linkedin_desligado');}
        if(F3Base_Linkedin_Cliente::externo()){return F3Base_Linkedin_Cliente::coletar();}if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('linkedin-coleta:'.F3Base_Linkedin_Integracoes::id(),30);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>true,'codigo'=>'linkedin_coleta_ocupada');}
        $deadline=microtime(true)+min(20,F3Base_Execucoes::restante_ms(1500)/1000);F3Base_Linkedin_Cliente::prazo($deadline);$out=array();$next=time()+HOUR_IN_SECONDS;
        try{$ctx=F3Base_Linkedin_Integracoes::revisao_execucao();$s=F3Base_Linkedin_Integracoes::estado();$ids=self::formularios($cfg);usort($ids,static fn($a,$b)=>(($s['cursores'][$a]['proxima']??0)<=>($s['cursores'][$b]['proxima']??0)));
            foreach($ids as $id){if(microtime(true)>$deadline-3){$next=time()+60;break;}$root=$s['cursores'][$id]??array('desde'=>time(),'proxima'=>time(),'versoes'=>array());if(($root['proxima']??0)>time()){$next=min($next,$root['proxima']);continue;}
                $result=array('ok'=>false,'codigo'=>'consulta_nao_concluida');$f=self::formulario($id,$cfg);
                if(empty($f['ok'])){$result=$f;$root['proxima']=time()+max(60,(int)($f['retry_after']??3600));}
                else{
                    $version='urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$id.','.$f['formulario']['versionId'].')';
                    if(!isset($root['versoes'][$version])){$root['versoes'][$version]=array('desde'=>$root['desde'],'ate'=>$root['desde'],'inicio'=>0,'proxima'=>0);}
                    uasort($root['versoes'],static fn($a,$b)=>(($a['proxima']??0)<=>($b['proxima']??0)));$version=array_key_first($root['versoes']);$c=$root['versoes'][$version];
                    if(empty($c['janela_fim'])){$c['janela_inicio']=max($c['desde'],($c['ate']??$c['desde'])-600);$c['janela_fim']=time();$c['inicio']=0;}
                    $r=F3Base_Linkedin_Cliente::pedir('GET','leadFormResponses',array('q'=>'owner','owner'=>array('sponsoredAccount'=>self::dono($cfg)),'leadType'=>array('leadType'=>'SPONSORED'),'versionedLeadGenFormUrn'=>$version,'submittedAtTimeRange'=>array('start'=>$c['janela_inicio']*1000,'end'=>$c['janela_fim']*1000),'start'=>$c['inicio'],'count'=>50,'limitedToTestLeads'=>false,'fields'=>F3Base_Linkedin_Api::CAMPOS));
                    $complete=false;$accepted=0;$more=false;$result=$r;
                    if(!empty($r['ok'])){$rows=$r['data']['elements']??null;$paging=$r['data']['paging']??null;
                        if(!is_array($rows)||!is_array($paging)||count($rows)>50||(int)($paging['start']??-1)!==$c['inicio']){$result=array('ok'=>false,'codigo'=>'paginacao_linkedin_invalida');}
                        else{$complete=true;foreach($rows as $response){if(!is_array($response)||microtime(true)>$deadline-2||F3Base_Linkedin_Integracoes::revisao_execucao()!==$ctx){$complete=false;$result=array('ok'=>false,'codigo'=>'pagina_nao_concluida');break;}$stamp=self::instante($response['submittedAt']??null);$vf=self::versionada((string)($response['versionedLeadGenFormUrn']??''));if(!$stamp||!$vf||$vf['urn']!==$version||$stamp['segundos']<$c['janela_inicio']||$stamp['segundos']>$c['janela_fim']){$complete=false;$result=array('ok'=>false,'codigo'=>'resposta_fora_da_janela');break;}$one=self::ingerir_resposta($response,'consulta_periodica');if(empty($one['ok'])){$result=$one;$complete=false;break;}$accepted++;}
                            $more=isset($paging['total'])?$c['inicio']+count($rows)<(int)$paging['total']:count($rows)===50;if($more&&!$rows){$complete=false;$result=array('ok'=>false,'codigo'=>'paginacao_sem_progresso');}
                        }
                    }
                    if($complete){$c['ultimo_sucesso']=time();$c['falhas']=0;$c['proxima']=time()+($more?60:HOUR_IN_SECONDS);$c['inicio']=$more?$c['inicio']+count($rows):0;if(!$more){$c['ate']=$c['janela_fim'];unset($c['janela_inicio'],$c['janela_fim']);}$result=array('ok'=>true,'codigo'=>$more?'pagina_persistida':'janela_concluida','itens'=>$accepted,'parcial'=>$more);}
                    else{$c['falhas']=(int)($c['falhas']??0)+1;$c['proxima']=time()+max((int)($result['retry_after']??0),min(21600,60*2**min(8,$c['falhas']-1)));$c['ultima_falha']=$result['codigo']??'resposta_recusada';}
                    $root['versoes'][$version]=$c;$root['proxima']=min(array_column($root['versoes'],'proxima'));
                }
                if(!F3Base_Trava::renovar($lock,30)){return array('ok'=>false,'codigo'=>'worker_reserva_perdida');}$root['ultima_passagem']=time();$save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($v)use($ctx,$root,$id,$result){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$ctx){return null;}$v['cursores'][$id]=$root;if(!empty($result['ok'])){$v['leads_leitura_confirmada_em']=time();}return $v;});$out[$id]=!empty($save['persisted'])?$result:array('ok'=>false,'codigo'=>'checkpoint_linkedin_falhou');$next=min($next,max(time()+5,$root['proxima']));
            }
            return array('ok'=>!array_filter($out,static fn($v)=>empty($v['ok'])),'formularios'=>$out,'proxima'=>$next);
        }finally{F3Base_Linkedin_Cliente::prazo(0);F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();if(!empty(self::config()['ativo'])){F3Base_Fila::agendar(self::EVENTO,$next);}}
    }
    public static function diagnostico(): array {if(!F3Base_Linkedin_Integracoes::tem_escopo()&&count(F3Base_Linkedin_Integracoes::colecao())!==1){$out=array();foreach(F3Base_Linkedin_Integracoes::colecao() as $id=>$cfg){$out[$id]=F3Base_Linkedin_Integracoes::executar((string)$id,static fn()=>self::diagnostico());}return array('integracoes'=>$out);}$s=F3Base_Linkedin_Integracoes::estado();$cfg=self::config();return array('cliente'=>F3Base_Linkedin_Cliente::estado(),'ativo'=>!empty($cfg['ativo']),'conta'=>$cfg['conta_id'],'formularios'=>self::formularios($cfg),'versao_api'=>F3Base_Linkedin_Api::VERSAO,'verificacao'=>$s['acesso']??null,'verificacao_atual'=>($s['acesso']['contexto']??'')===F3Base_Linkedin_Integracoes::revisao_execucao(),'cursores'=>F3Base_Linkedin_Integracoes::cursores_publicos($s['cursores']??array()),'pausa_ate'=>$s['pausa_ate']??0,'leads_leitura_confirmada_em'=>$s['leads_leitura_confirmada_em']??null,'proxima_consulta'=>wp_next_scheduled(self::EVENTO)?:null,'webhook'=>F3Base_Linkedin_Webhook::diagnostico(),'limite'=>'App aprovado no programa Lead Sync e escopo r_marketing_leadgen_automation necessários. Leitura dos formulários não comprova leitura de contatos. Nenhuma sessão web é criada.');}
    public static function iniciar(): void {
        add_action('updated_option',array(__CLASS__,'mudou'),32,3);add_action('added_option',static fn($n,$v)=>self::mudou($n,null,$v),32,2);add_action(self::EVENTO,static fn()=>F3Base_Linkedin_Integracoes::todas('consultar'));
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),91);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('anuncios-linkedin-acesso-verificar','Conferir token e formulários LinkedIn sem ler respostas pessoais',static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>self::verificar($e)),array('integracao_id'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array(),false);F3Base_Servicos::ability('anuncios-linkedin-consultar','Importar uma página de respostas LinkedIn autorizadas',static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>($e['simular']??true)!==false?array('ok'=>true,'simular'=>true,'diagnostico'=>self::diagnostico()):self::consultar()),array('integracao_id'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true)),array(),false);});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('anuncios-linkedin-cliente-alterar','Prévia e troca explícita por integração LinkedIn',array(F3Base_Linkedin_Transicao::class,'executar'),array('integracao_id'=>array('type'=>'string'),'cliente'=>array('type'=>'string','enum'=>array('core','linkedin_plugin')),'connection_id'=>array('type'=>'string'),'conta_id'=>array('type'=>'string'),'formularios'=>array('type'=>'array','items'=>array('type'=>'string')),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'chave_operacao'=>array('type'=>'string')),array('integracao_id','cliente','connection_id'),false);});
        F3Base_Linkedin_Webhook::iniciar();F3Base_Linkedin_Admin::iniciar();
    }
    public static function conferir_agenda_1(): void {if(F3Base_Linkedin_Integracoes::ativas()&&!wp_next_scheduled(self::EVENTO)){F3Base_Fila::agendar(self::EVENTO,time()+60);}}
}
