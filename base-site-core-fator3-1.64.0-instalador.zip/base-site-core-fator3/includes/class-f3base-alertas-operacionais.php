<?php
/** Canal exclusivo de alertas operacionais. A reserva/deduplicação pertence ao chamador. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Alertas_Operacionais {
    const POLITICA='avisos-tecnicos/1';
    public static function catalogo(array $c): array {
        $defaults=array('email'=>'','atraso_minutos'=>60,'imap_falhas_consecutivas'=>3,'imap_sem_leitura_minutos'=>20,'robots_sem_confirmacao_minutos'=>120);$props=array('email'=>array('type'=>'string','maxLength'=>254,'description'=>'Vazio usa admin_email. Destino técnico independente de avisos de contato.'),'atraso_minutos'=>array('type'=>'integer','minimum'=>60,'maximum'=>1440,'description'=>'Sem erro, aguarda este prazo desde a última leitura completa; padrão 60 minutos.'));
        $props['imap_falhas_consecutivas']=array('type'=>'integer','minimum'=>1,'maximum'=>100,'description'=>'Respostas IMAP incompletas consecutivas antes do aviso; padrão 3.');$props['imap_sem_leitura_minutos']=array('type'=>'integer','minimum'=>1,'maximum'=>1440,'description'=>'Minutos sem leitura completa para avisar resposta IMAP incompleta; padrão 20. Basta um dos dois limites.');
        $props['robots_sem_confirmacao_minutos']=array('type'=>'integer','minimum'=>15,'maximum'=>1440,'description'=>'Prazo de retomada sem confirmação HTTP antes de avisar; padrão 120 minutos.');
        $c['f3base_avisos_tecnicos']=F3Base_Conversas::catalogo_grupo('f3base_avisos_tecnicos','Avisos técnicos por e-mail',$defaults,$props,static function($v)use($props){$r=rest_validate_value_from_schema($v,array('type'=>'object','additionalProperties'=>false,'properties'=>$props));if(is_wp_error($r)){return $r->get_error_message();}return isset($v['email'])&&$v['email']!==''&&!is_email($v['email'])?'E-mail técnico inválido.':'';});$c['f3base_avisos_tecnicos']['sanitiza']=static fn($v)=>array_replace($defaults,is_array($v)?$v:array());$c['f3base_avisos_tecnicos']['descricao']='Destino próprio de avisos técnicos por e-mail; vazio usa admin_email. IMAP incompleto aguarda a persistência configurada (3 passagens ou 20 minutos por padrão); robots aguarda 120 minutos por padrão; outros erros avisam imediatamente; atraso sem erro espera ao menos 60 minutos. Não usa o canal de contatos.';return $c;
    }
    public static function resumo(): array {$c=F3Base_Options::ler('f3base_avisos_tecnicos');return array('canal'=>'email','destinatario'=>self::destinatario(),'atraso_minutos'=>$c['atraso_minutos']??60,'primeiro_erro'=>'imediato_exceto_imap_e_robots','robots_sem_confirmacao_minutos'=>$c['robots_sem_confirmacao_minutos'],'imap_falhas_consecutivas'=>$c['imap_falhas_consecutivas'],'imap_sem_leitura_minutos'=>$c['imap_sem_leitura_minutos'],'recuperacao'=>'somente_apos_atencao_aceita','origem'=>'f3base/config-core-ler: f3base_avisos_tecnicos');}
    public static function destinatario(): string {
        $c=F3Base_Options::ler('f3base_avisos_tecnicos');$v=!empty($c['email'])?$c['email']:get_option('admin_email','');return is_string($v)&&is_email($v)?$v:'';
    }
    public static function enviar(string $titulo,string $texto,bool $teste=false): array {
        $r=array('politica'=>self::POLITICA,'canal'=>'email','recebimento'=>'nao_comprovado','em'=>time());
        if($teste&&F3Base_Testes::politica('email','teste')==='suprimir'){return $r+array('estado'=>'suprimido_teste','ok'=>true);}
        $to=self::destinatario();if($to===''){return $r+array('estado'=>'sem_destinatarios','codigo'=>'admin_email_invalido','ok'=>false);}
        try{$ok=wp_mail($to,($teste?'[TESTE] ':'').$titulo,$texto,array('Content-Type: text/plain; charset=UTF-8'));
            return $r+array('ok'=>$ok,'estado'=>$ok?'processado':'falhou','codigo'=>$ok?'aceito_wp_mail':'envio_recusado');
        }catch(Throwable $e){return $r+array('ok'=>false,'estado'=>'incerto','codigo'=>'envio_sem_confirmacao');}
    }
}
