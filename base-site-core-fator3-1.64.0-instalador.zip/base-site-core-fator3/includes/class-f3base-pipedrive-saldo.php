<?php
/** Pipedrive SDK support; loaded only when used. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Saldo {
    const OPTION='f3base_pipedrive_saldo_conta';
    public static function chave(string $token,string $domain): string {return hash_hmac('sha256',home_url().'|'.$domain.'|'.$token,wp_salt('auth'));}
    public static function ler(?string $token=null,?string $domain=null): ?array {
        $token=$token??F3Base_Segredos::abrir('f3base_pipedrive_token');$domain=$domain??(string)(F3Base_Options::fotografia('f3base_pipedrive')['valor']['dominio']??'');
        $f=F3Base_Options::fotografia_bruta(self::OPTION);if($f['erro']){return null;}$v=$f['valor']['observacoes'][self::chave($token,$domain)]??null;
        return is_array($v)&&is_int($v['restante']??null)&&$v['restante']>=0&&is_string($v['lido_em']??null)?array_intersect_key($v,array_flip(array('restante','lido_em'))):null;
    }
    public static function observar($response,string $token,string $domain): void {
        if(is_wp_error($response)||!is_array($response)||$token===''||!preg_match('/^[a-z0-9][a-z0-9-]{0,62}\.pipedrive\.com$/D',$domain)){return;}
        $left=wp_remote_retrieve_header($response,'x-daily-ratelimit-token-remaining');
        if(is_scalar($left)&&preg_match('/^[0-9]{1,15}$/D',(string)$left)){
            $key=self::chave($token,$domain);$value=array('restante'=>(int)$left,'lido_em'=>gmdate('Y-m-d\TH:i:s\Z'));
            F3Base_Options::atualizar_estado(self::OPTION,static function($s)use($key,$value){$v=is_array($s['observacoes']??null)?$s['observacoes']:array();unset($v[$key]);$v[$key]=$value;return array('observacoes'=>array_slice($v,-8,null,true));});
        }
        // A candidata de outra conta não pausa a credencial corrente.
        $cfg=F3Base_Options::fotografia('f3base_pipedrive');$current=F3Base_Segredos::abrir('f3base_pipedrive_token');
        if($cfg['erro']||($cfg['valor']['dominio']??'')!==$domain||$current===''||!hash_equals($current,$token)){return;}
        $http=(int)wp_remote_retrieve_response_code($response);$burst=wp_remote_retrieve_header($response,'x-ratelimit-remaining');
        if($http!==429&&!(is_scalar($burst)&&(string)$burst==='0')){return;}
        $retry=(string)wp_remote_retrieve_header($response,'retry-after');$reset=wp_remote_retrieve_header($response,'x-ratelimit-reset');
        $after=ctype_digit($retry)?(int)$retry:max(0,(int)strtotime($retry)-time());$delay=max(3,min(86400,$after),is_numeric($reset)?min(86400,(int)$reset>time()?(int)$reset-time():(int)$reset):0);
        F3Base_Options::atualizar_estado('f3base_pipedrive_estado',static function($s)use($delay){$s['pausa_ate']=max((int)($s['pausa_ate']??0),time()+$delay);return $s;});
    }
}

