<?php
/** Table versions on the request path; DDL only in installation or scheduled repair. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Esquema {
    const OPTION='f3base_esquema';
    private static int $manutencao=0;
    private static array $pilha=array();
    private static array $falhas=array();
    private static bool $registrando=false;
    public static function iniciar(): void {
        add_filter('query',array(__CLASS__,'consulta'),PHP_INT_MIN);
        add_action('shutdown',array(__CLASS__,'observar'),1);
        add_action('shutdown',array(__CLASS__,'registrar_falhas'),2);
        add_action('f3base_esquema_reparar',array(__CLASS__,'reparar'));
    }
    public static function manutencao(): bool {return self::$manutencao>0;}
    public static function executar(callable $f) {++self::$manutencao;try{return $f();}finally{--self::$manutencao;}}
    public static function pronta(string $class): bool {$s=(array)get_option(self::OPTION,array());return (int)($s['_classes'][$class]??0)===(int)$class::ESQUEMA_VERSAO;}
    public static function instalar(string $class,string $method,callable $f) {
        if(!self::manutencao()){return self::pronta($class);}
        global $wpdb;self::$pilha[]=array('classe'=>$class,'metodo'=>$method,'tabelas'=>array());
        try{$result=$f();$ok=$result!==false&&$wpdb->last_error==='';}finally{$entry=array_pop(self::$pilha);}
        if($ok){$s=(array)get_option(self::OPTION,array());foreach(array_keys($entry['tabelas']) as $table){$s[$table]=(int)$class::ESQUEMA_VERSAO;$s['_donos'][$table]=array($class,$method);}$s['_classes'][$class]=(int)$class::ESQUEMA_VERSAO;update_option(self::OPTION,$s,true);}
        return $result;
    }
    public static function consulta(string $sql): string {
        self::observar();
        if(self::$pilha&&preg_match_all('/(?:TABLE(?: IF NOT EXISTS)?|FROM|INTO|UPDATE)\s+`?([A-Za-z0-9_]*f3base_[A-Za-z0-9_]+)`?/i',$sql,$m)){$i=count(self::$pilha)-1;foreach($m[1] as $t){self::$pilha[$i]['tabelas'][$t]=true;}}
        return $sql;
    }
    /** Examine the previous query before wpdb flushes it, and once at shutdown. No values are retained. */
    public static function observar(): void {
        global $wpdb;if(defined('WP_UNINSTALL_PLUGIN')||self::$registrando||self::manutencao()||empty($wpdb->last_error)||!preg_match('/^\s*(?:INSERT|UPDATE|REPLACE|DELETE)\b/i',(string)$wpdb->last_query)){return;}
        if(!preg_match('/(?:doesn.t exist|Unknown column|no such (?:table|column))/i',$wpdb->last_error)){return;}
        if(preg_match('/(?:INTO|UPDATE|FROM)\s+`?([A-Za-z0-9_]*f3base_[A-Za-z0-9_]+)`?/i',$wpdb->last_query,$m)){self::$falhas[$m[1]]='estrutura_ausente';}
    }
    public static function registrar_falhas(): void {
        if(!self::$falhas||self::$registrando){return;}self::$registrando=true;
        try{
            $s=(array)get_option(self::OPTION,array());$pending=(array)get_option('f3base_esquema_reparos',array());$new=array();
            foreach(self::$falhas as $table=>$code){if(!isset($s['_donos'][$table])){continue;}if(!isset($pending[$table])){$new[]=$table;$pending[$table]=array('em'=>time(),'codigo'=>$code,'dono'=>$s['_donos'][$table]);}unset($s['_classes'][$s['_donos'][$table][0]]);$s[$table]=0;}
            update_option(self::OPTION,$s,true);update_option('f3base_esquema_reparos',$pending,false);
            if($pending&&!wp_next_scheduled('f3base_esquema_reparar')){wp_schedule_single_event(time()+1,'f3base_esquema_reparar');}
            if($new){F3Base_Alertas_Operacionais::enviar('Estrutura do Site Core requer reparo','Uma escrita foi recusada por tabela ou coluna ausente. Reparo agendado: '.implode(', ',$new).'. O registro recusado não foi confirmado.');}
            self::$falhas=array();
        }finally{self::$registrando=false;}
    }
    public static function reparar(): array {
        $pending=(array)get_option('f3base_esquema_reparos',array());$done=array();
        foreach($pending as $table=>$row){$cb=$row['dono']??null;if(!is_array($cb)||count($cb)!==2||!class_exists($cb[0])||!method_exists($cb[0],$cb[1])){continue;}$class=$cb[0];$method=new ReflectionMethod($class,$cb[1]);if(!$method->isPublic()||$method->getNumberOfRequiredParameters()){continue;}if(!$method->isStatic()){$cb[0]=new $class();}$r=self::executar(static fn()=>$cb());if($r!==false&&self::pronta($class)){unset($pending[$table]);$done[]=$table;}}
        update_option('f3base_esquema_reparos',$pending,false);if($pending&&!wp_next_scheduled('f3base_esquema_reparar')){wp_schedule_single_event(time()+900,'f3base_esquema_reparar');}
        return array('ok'=>!$pending,'reparadas'=>$done,'pendentes'=>array_keys($pending));
    }
}
