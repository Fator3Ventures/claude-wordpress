<?php
/** Fotografia operacional comum à administração, abilities, CLI e Saúde do Site. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Saude {
	public static function iniciar(): void {add_action('admin_notices',static function(){if(current_user_can('manage_options')&&in_array($_GET['page']??'',array('base-site-core-fator3','f3base-integracoes'),true)&&empty(F3Base_Execucoes::resumo()['cron_servidor_ativo'])){echo '<div class="notice notice-warning"><p>Nenhuma passagem CLI foi observada nas últimas duas horas. Isso não comprova que o cron da hospedagem esteja desligado; confira o histórico de execução.</p></div>';}});
		add_filter( 'site_status_tests', array( __CLASS__, 'testes_do_site' ) );
		add_filter( 'debug_information', array( __CLASS__, 'informacoes' ) );
	}

	/** Nenhuma sonda, reparação, migração ou agendamento ocorre nesta consulta. */
	public static function resumo(array $entrada=array()): array {
        if(!empty($entrada['compacto'])){return F3Base_Resumo_Operacional::ler();}
		$modulos = array();
		foreach ( F3Base_Registro::instanciar() as $modulo ) {
			$estado    = $modulo->estado();
			$modulos[] = array(
				'id'        => $modulo->id(),
				'nome'      => $modulo->nome(),
				'estado'    => $estado['estado'],
				'motivo'    => $estado['motivo'],
				'atividade' => $modulo->atividade(),
			);
		}
		return F3Base_Evidencias::projetar(array(
			'versao'                 => F3BASE_PLUGIN_VERSAO,
			'consultado_em'          => time(),
            'execucoes'=>F3Base_Execucoes::resumo(),
            'atualizacao'=>F3Base_Instalacao::resumo(),
            'recuperacao'=>F3Base_Recuperacao::ler(),'protecao_pasta'=>F3Base_Recuperacao::protecao(),'esperas'=>F3Base_Operacao::esperas(),'intencoes'=>F3Base_Operacao_Intencoes::resumo(),'indice_consentimento'=>F3Base_Leads_Consentimento::resumo(),'avisos_configuracao'=>F3Base_Configuracao_Medicao::avisos(),
            'gsc'=>F3Base_Gsc::resumo(),'companheiros'=>array('mcp'=>F3Base_Companheiros::mcp(),'google'=>F3Base_Companheiros::google()),
			'modulos'                => $modulos,
            'robots_retomada'=>F3Base_Robots_Entrega::retomada_resumo(),
			'auditoria_configuracao' => F3Base_Auditoria::resumo(),
			'agenda'                 => F3Base_Operacao::agenda(),
            'cadencia' => F3Base_Modulo_Cadencia_Relatorio::consultar(),
			'fila'                   => F3Base_Capi_Fila::resumo(),
            'captacao'=>F3Base_Captacao_Operacao::diagnostico(),'qualidade_comercial'=>F3Base_Qualidade::resumo(),'classificacao_capturas'=>F3Base_Captura_Contexto::resumo(),'agenda_confirmacao'=>F3Base_Fila::resumo(),'avisos_slack'=>F3Base_Avisos::resumo(),'cache_conteudo'=>F3Base_Cache_Orcamento::resumo(),
			'cache'                  => F3Base_Cache_Pagina::resumo(),
			'publicacao'             => F3Base_Llms::responsaveis(),
			'schema_publicado'       => F3Base_Schema_Verificacao::consultar(),
			'llms_arquivo'           => F3Base_Llms_Arquivo::consultar(),
			'escopo'                 => 'estado_e_evidencias_existentes; consulta_nao_executa_acoes',
		));
	}

	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		F3Base_Servicos::registrar_ability(
			'f3base/saude-ler',
			array(
				'label'               => 'Estado operacional do Core',
				'description'         => 'Consulta saúde, agenda e evidências existentes, sem executar verificações ou correções.',
				'category'            => 'f3base',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array('compacto'=>array('type'=>'boolean','default'=>false)),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
				'permission_callback' => static fn() => current_user_can( 'manage_options' ),
				'execute_callback'    => static fn($e=array()) => self::resumo($e),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	public static function testes_do_site( array $testes ): array {
		$testes['direct']['f3base_estado'] = array(
			'label' => 'Estado do Fator3 Site Core',
			'test'  => array( __CLASS__, 'teste' ),
		);
		return $testes;
	}

	public static function teste(): array {
		$r          = self::resumo();
		$pendencias = array();
        foreach(F3Base_Operacao::esperas()['itens'] as $espera){if(!$espera['agenda_confirmada']||$espera['parada']||str_contains($espera['causa'],'persist')||str_contains($espera['causa'],'agenda')){$pendencias[]=$espera['tarefa'].': '.$espera['causa'].'; elegível há '.$espera['atraso_elegivel_segundos'].' segundos. '.$espera['acao'];}}
        if(empty($r['recuperacao']['ok'])||!empty($r['recuperacao']['pausado'])||in_array($r['recuperacao']['entrada_requisicao']??'',array('trava_inacessivel','trava_ocupada','trava_falhou','protecao_degradada'),true)){$pendencias[]=(empty($r['recuperacao']['modulos_inicializados'])?'Módulos não inicializados: ':'Tarefas e gravações paradas: ').($r['recuperacao']['codigo']??'recuperacao_indisponivel').'. Consulte f3base/operacao-recuperacao-ler.';}
        if(empty($r['execucoes']['cron_servidor_ativo'])){$pendencias[]='Nenhuma passagem CLI observada nas últimas duas horas. Confira o executor da hospedagem; isto não comprova crontab desligado.';}
		foreach ( $r['modulos'] as $m ) {
			if ( 'degradado' === $m['estado'] ) {
				$pendencias[] = $m['nome'] . ': ' . $m['motivo']; }
		}
		foreach ( $r['agenda'] as $a ) {
			if ( $a['atrasado'] && $a['registrada'] ) {
				$pendencias[] = $a['rotulo'] . ': execução atrasada.'; }
		}
		foreach($r['intencoes']['por_tarefa']??array() as $i){if($i['estado']==='esgotada'){$pendencias[]=(F3Base_Operacao::tarefas()[$i['tarefa']]['rotulo']??$i['tarefa']).': '.(int)$i['quantidade'].' intenção(ões) com tentativas esgotadas; nova tentativa a cada hora.';}}
        foreach(F3Base_Configuracao_Medicao::avisos() as $a){$pendencias[]='Configuração '.($a['nome']??'').': '.($a['motivo']??'').'. '.($a['acao']??'');}
        foreach(array('mcp','google') as $c){$comp=F3Base_Companheiros::$c();if(!in_array($comp['codigo'],array('compativel','mcp_ausente','google_ausente'),true)){$pendencias[]='Companheiro '.$c.' incompatível: '.$comp['codigo'].'. Confira o contrato publicado pelo plugin.';}}
        $pendencias=array_merge($pendencias,F3Base_Avisos::pendencias_saude($r['avisos_slack']??array()));
        $html = '<p>A consulta usa o estado e as evidências existentes do Core.</p>';
		if ( $pendencias ) {
			$html .= '<ul>';
			foreach ( $pendencias as $p ) {
				$html .= '<li>' . esc_html( $p ) . '</li>';
			} $html .= '</ul>'; }
		return array(
			'label'       => $pendencias ? 'O Core tem pendências operacionais' : 'O Core não informa degradação nos módulos',
			'status'      => (empty($r['recuperacao']['ok'])||in_array($r['recuperacao']['entrada_requisicao']??'',array('trava_inacessivel','trava_ocupada','trava_falhou','protecao_degradada'),true))?'critical':($pendencias?'recommended':'good'),
			'badge'       => array(
				'label' => 'Fator3 Site Core',
				'color' => 'blue',
			),
			'description' => $html,
			'actions'     => '<a href="' . esc_url(
				add_query_arg(
					array(
						'page' => empty($r['recuperacao']['modulos_inicializados'])?'f3base-recuperacao':F3Base_Admin_Tela::SLUG,
						'aba'  => 'tecnica',
					),
					admin_url( 'admin.php' )
				)
			) . '">Ver estado técnico do Core</a>',
			'test'        => 'f3base_estado',
		);
	}

	public static function informacoes( array $informacoes ): array {
		$agenda                = self::agenda_texto();
		$informacoes['f3base'] = array(
			'label'       => 'Fator3 Site Core',
			'description' => 'Estado existente. Não inclui tokens, corpos de leads ou identificadores de visitantes.',
			'fields'      => array(
				'versao' => array(
					'label' => 'Versão',
					'value' => F3BASE_PLUGIN_VERSAO,
				),
				'agenda' => array(
					'label' => 'Tarefas',
					'value' => $agenda,
				),
			),
		);
		return $informacoes;
	}

	private static function agenda_texto(): string {
		$r = array();
		foreach ( F3Base_Operacao::agenda() as $a ) {
			$r[] = $a['rotulo'] . ': ' . $a['codigo'];
		} return implode( '; ', $r );
	}
}
