<?php
/** Diagnóstico privado de recusas. Valores nunca compõem lead, evento de medição ou fila externa. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Formulario_Tentativas {
    public const ESQUEMA_VERSAO=16400;
    const OPTION='f3base_formulario_tentativas';
    const REGRAS=array('valueMissing','typeMismatch','tooShort','tooLong','patternMismatch','rangeUnderflow','rangeOverflow','stepMismatch','badInput','customError','exigir-um-de','telefone_formato','arquivo_limite');
    const MOTIVOS=array('sem_ddd','ddd_invalido','quantidade_digitos','prefixo_invalido','caracteres_invalidos','formato_internacional','formato_pais');
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_formulario_tentativas';}
    public static function pronta(): bool { if(!F3Base_Esquema::manutencao()){return F3Base_Esquema::pronta(__CLASS__);}global $wpdb;return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela();}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();
        dbDelta("CREATE TABLE {$t} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            evento char(32) NOT NULL,
            formulario varchar(80) NOT NULL,
            instancia char(32) NOT NULL,
            sessao char(32) NOT NULL,
            sequencia int unsigned NOT NULL,
            etapa tinyint unsigned NOT NULL,
            tipo varchar(16) NOT NULL,
            criado_em bigint(20) NOT NULL,
            ocorrido_ms bigint(20) NOT NULL,
            caminho varchar(190) NOT NULL DEFAULT '',
            classe_trafego varchar(16) NOT NULL DEFAULT 'nao_marcado',
            campos longtext NOT NULL,
            valores longtext NULL,
            titulares text NOT NULL,
            record_id char(32) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY evento (evento),
            KEY sessao (sessao,criado_em),
            KEY instancia (instancia,sequencia),
            KEY formulario (formulario,criado_em),
            KEY retencao (criado_em)
        ) {$wpdb->get_charset_collate()};");return self::pronta();
    }
    public static function catalogo(array $c): array {
        $c[self::OPTION]=array('rotulo'=>'Tentativas barradas nos formulários','descricao'=>'Guarda campos, estados e regras das tentativas recusadas para entender dificuldades de preenchimento. Valores ficam cifrados somente neste WordPress, acessíveis com a permissão de leitura de contatos. Não são enviados a avisos, CRM nem plataformas de anúncio.','operavel'=>true,'secao'=>F3Base_Options::SECAO_PRIVACIDADE,'campo'=>'grupo','padrao'=>array('capturar_valores'=>true,'retencao_meses'=>60),'subcampos'=>array('capturar_valores'=>array('tipo'=>'booleano','rotulo'=>'Guardar valores de tentativas barradas e campos isca','descricao'=>'Ligado, registra o conteúdo no momento da recusa e os valores dos campos isca, inclusive em envios não concluídos. Desligado, novas tentativas guardam somente campo, estado e regra; valores já guardados seguem o prazo de retenção ou a eliminação do contato.'),'retencao_meses'=>array('tipo'=>'inteiro','rotulo'=>'Meses de guarda das tentativas e iscas','minimo'=>1,'maximo'=>120,'descricao'=>'Padrão de 60 meses, configurável de 1 a 120. A leitura oculta registros vencidos imediatamente; a rotina de retenção os elimina do banco. A eliminação de um contato também remove as tentativas da mesma sessão.')),'schema_config'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array('capturar_valores'=>array('type'=>'boolean'),'retencao_meses'=>array('type'=>'integer','minimum'=>1,'maximum'=>120))),'sanitiza'=>array(F3Base_Evolucao::class,'sanitizar'),'recusa'=>static function($v,$d){$err=F3Base_Evolucao::recusar($v,$d);if($err){return $err;}return isset($v['retencao_meses'])&&(filter_var($v['retencao_meses'],FILTER_VALIDATE_INT)===false||(int)$v['retencao_meses']<1||(int)$v['retencao_meses']>120)?'Escolha de 1 a 120 meses para guardar tentativas.':'';});
        $c[self::OPTION]['schema_entrada']=$c[self::OPTION]['schema_config'];return $c;
    }
    public static function iniciar(): void {
        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/formularios/tentativas',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>static function(WP_REST_Request $req){if($req->get_header('origin')&&!F3Base_Testes::origem_propria($req->get_header('origin'))){return F3Base_Formularios::resposta(array('ok'=>false,'codigo'=>'origem_invalida'),403);}if(strlen($req->get_body())>65536){return F3Base_Formularios::resposta(array('ok'=>false,'codigo'=>'corpo_excedido'),413);}$input=$req->get_json_params();$r=is_array($input)?self::receber($input):array('ok'=>false,'codigo'=>'tentativa_invalida');return F3Base_Formularios::resposta($r,$r['http']??($r['ok']?200:400));}));});
        add_action('f3base_retencao_limpeza',array(__CLASS__,'limpar'));add_action('f3base_retencao_limpeza',array('F3Base_Formulario_Antispam','limpar'));
        add_action(F3Base_Leads_Notificacoes::EVENTO,array(__CLASS__,'limpar'));
        add_filter('wp_privacy_personal_data_erasers',static function($a){$a['f3base-formulario-tentativas']=array('eraser_friendly_name'=>'Tentativas barradas nos formulários Core','callback'=>array(__CLASS__,'apagar_titular'));return $a;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::registrar_ability('f3base/formularios-tentativas-ler',array('label'=>'Ler tentativas barradas dos formulários','description'=>'Leitura privada de campo, estado, regra e valor digitado, por sessão e instância. Valores somente com f3base_ler_leads; retenção própria e sem repasse a integrações.','category'=>F3BASE_PREFIXO,'input_schema'=>array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros()),'output_schema'=>self::schema_saida(),'permission_callback'=>static fn()=>current_user_can('f3base_ler_leads'),'execute_callback'=>array(__CLASS__,'consultar'),'meta'=>array('mcp'=>array('public'=>true),'annotations'=>array('readonly'=>true,'idempotent'=>true,'destructive'=>false))));});
    }
    public static function filtros(): array {return array('formulario'=>array('type'=>'string','pattern'=>'^[a-z0-9_-]{1,80}$'),'sessao'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'instancia'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'dias'=>array('type'=>'integer','minimum'=>1,'maximum'=>120),'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),'apos_id'=>array('type'=>'integer','minimum'=>0),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>100));}
    public static function schema_saida(): array {
        $field=array('type'=>'object','additionalProperties'=>false,'required'=>array('nome','estado','regras'),'properties'=>array('nome'=>array('type'=>'string'),'estado'=>array('type'=>'string','enum'=>array('vazio','preenchido','invalido')),'regras'=>array('type'=>'array','items'=>array('type'=>'string','enum'=>self::REGRAS)),'motivo'=>array('type'=>'string'),'pais'=>array('type'=>'string'),'valor'=>array('type'=>'string'),'valor_truncado'=>array('type'=>'boolean')));
        $props=array();foreach(array('evento','formulario','instancia','sessao','tipo','caminho','classe_trafego','record_id') as $k){$props[$k]=array('type'=>'string');}foreach(array('id','sequencia','etapa','criado_em','ocorrido_ms') as $k){$props[$k]=array('type'=>'integer');}$props['campos']=array('type'=>'array','items'=>$field);$props['valores_estado']=array('type'=>'string');
        return array('type'=>'object','properties'=>array('ok'=>array('type'=>'boolean'),'codigo'=>array('type'=>'string'),'retencao_meses'=>array('type'=>'integer'),'proximo_id'=>array('type'=>'integer'),'limite'=>array('type'=>'integer'),'linhas'=>array('type'=>'array','items'=>array('type'=>'object','properties'=>$props)),'limitacao'=>array('type'=>'string')));
    }
    private static function cfg(): array {return F3Base_Options::ler(self::OPTION);}
    private static function hash_email(string $email): string {return hash_hmac('sha256',strtolower(trim($email)),wp_salt('secure_auth').'|tentativas-titular');}
    private static function chave(): string {return hash_hkdf('sha256',wp_salt('secure_auth'),SODIUM_CRYPTO_SECRETBOX_KEYBYTES,'f3base:tentativas:v1');}
    private static function cifrar(array $v): ?string {try{$nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);return 'f3tent:v1:'.base64_encode($nonce.sodium_crypto_secretbox(wp_json_encode($v,JSON_UNESCAPED_UNICODE),$nonce,self::chave()));}catch(Throwable $e){return null;}}
    private static function abrir(?string $v): ?array {try{if(!$v||!str_starts_with($v,'f3tent:v1:')){return null;}$raw=base64_decode(substr($v,10),true);if(!$raw||strlen($raw)<SODIUM_CRYPTO_SECRETBOX_NONCEBYTES+SODIUM_CRYPTO_SECRETBOX_MACBYTES){return null;}$plain=sodium_crypto_secretbox_open(substr($raw,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),substr($raw,0,SODIUM_CRYPTO_SECRETBOX_NONCEBYTES),self::chave());return $plain===false?null:json_decode($plain,true);}catch(Throwable $e){return null;}}
    private static function chave_bloqueio(string $sessao): string {return 'tentativas-eliminadas:'.hash_hmac('sha256',$sessao,wp_salt('auth'));}
    private static function bloqueada(string $sessao): bool {global $wpdb;$n=$wpdb->get_var($wpdb->prepare('SELECT total FROM %i WHERE chave=%s AND expira>=%d',F3Base_Leads_Repositorio::tabela('leads_janelas'),self::chave_bloqueio($sessao),time()));return $wpdb->last_error!==''||$n!==null;}
    public static function receber(array $e): array {
        $bad=array('ok'=>false,'codigo'=>'tentativa_invalida');
        if(strlen(wp_json_encode($e))>65536||array_diff(array_keys($e),array('token','formulario','instancia','sessao','evento','sequencia','etapa','tipo','ocorrido_ms','caminho','campos','record_id'))){return $bad;}
        foreach(array('instancia','sessao','evento') as $k){if(!is_string($e[$k]??null)||!preg_match('/^[a-f0-9]{32}$/D',$e[$k])){return $bad;}}
        if(!is_string($e['formulario']??null)||!is_string($e['token']??null)||!is_int($e['sequencia']??null)||$e['sequencia']<1||$e['sequencia']>1000||!in_array($e['etapa']??null,array(1,2),true)||!in_array($e['tipo']??'',array('recusado','correcao','saida','envio'),true)||!is_int($e['ocorrido_ms']??null)||abs((int)floor($e['ocorrido_ms']/1000)-time())>86400){return $bad;}
        $f=F3Base_Formularios::obter($e['formulario']);$token=F3Base_Formularios::token($e['token']);
        if(!$f||!$token||$token['f']!==$f['id']||!hash_equals(F3Base_Formularios::revisao($f),$token['r'])){return array('ok'=>false,'codigo'=>'token_ou_revisao_invalida','http'=>403);}
        if(!is_array($e['campos']??null)||count($e['campos'])>40){return $bad;}
        $defs=array_column(F3Base_Formularios::etapa($f,$e['etapa'])['campos'],null,'nome');$campos=array();$valores=array();$titulares=array();$seen=array();$barrou=false;
        foreach($e['campos'] as $c){
            if(!is_array($c)||array_diff(array_keys($c),array('nome','estado','regras','motivo','pais','valor','valor_truncado'))||!is_string($c['nome']??null)||isset($seen[$c['nome']])||!isset($defs[$c['nome']])||$defs[$c['nome']]['tipo']==='static'||!in_array($c['estado']??'',array('vazio','preenchido','invalido'),true)||!is_array($c['regras']??null)||!array_is_list($c['regras'])||count(array_filter($c['regras'],'is_string'))!==count($c['regras'])||array_diff($c['regras'],self::REGRAS)){return $bad;}
            $seen[$c['nome']]=true;if($c['regras']){$barrou=true;}
            if(isset($c['motivo'])&&!in_array($c['motivo'],self::MOTIVOS,true)){return $bad;}if(isset($c['pais'])&&!in_array($c['pais'],array('BR','PT','US','CA'),true)){return $bad;}
            if(isset($c['valor'])){if($e['tipo']!=='recusado'||!is_string($c['valor'])||strlen($c['valor'])>16000||$defs[$c['nome']]['tipo']==='file'){return $bad;}if(!empty(self::cfg()['capturar_valores'])){$valores[$c['nome']]=$c['valor'];if(($defs[$c['nome']]['tipo']==='email'||($defs[$c['nome']]['papel']??'')==='email')&&trim($c['valor'])!==''){$titulares[]=self::hash_email($c['valor']);}}}
            if(isset($c['valor_truncado'])&&!is_bool($c['valor_truncado'])){return $bad;}unset($c['valor']);$campos[]=$c;
        }
        if($e['tipo']==='recusado'&&!$barrou){return $bad;}
        if(in_array($e['tipo'],array('envio','saida'),true)&&$campos){return $bad;}
        $record='';if($e['tipo']==='envio'){$lead=is_string($e['record_id']??null)?F3Base_Leads_Repositorio::obter($e['record_id']):null;if(!$lead||($lead['correlacao']??'')!==$e['instancia']||$lead['formulario']!==$f['id']||$lead['eliminacao_pendente']||$lead['lixeira']){return $bad;}if($e['etapa']===2&&!F3Base_Formulario_Complementos::listar($lead['record_id'])){return $bad;}$record=$lead['record_id'];}
        if(!self::pronta()){return array('ok'=>false,'codigo'=>'estrutura_indisponivel','http'=>503);}
        $instance_lock=F3Base_Trava::adquirir('tentativa-instancia|'.$e['instancia'],30);if(!$instance_lock){return array('ok'=>false,'codigo'=>'tente_novamente','http'=>409);}$lock=F3Base_Trava::adquirir('tentativa|'.$e['sessao'],30);if(!$lock){F3Base_Trava::liberar($instance_lock);return array('ok'=>false,'codigo'=>'tente_novamente','http'=>409);}
        try{
            global $wpdb;if(self::bloqueada($e['sessao'])||self::bloqueada($e['instancia'])){return array('ok'=>false,'codigo'=>'sessao_eliminada','http'=>410);}
            $old=$wpdb->get_row($wpdb->prepare('SELECT sessao,instancia FROM %i WHERE evento=%s',self::tabela(),$e['evento']),ARRAY_A);if($old){return $old['sessao']===$e['sessao']&&$old['instancia']===$e['instancia']?array('ok'=>true,'duplicado'=>true):$bad;}
            if(!F3Base_Formularios::limite('tentativas',180)||!F3Base_Leads_Repositorio::quota('tentativas:'.$e['sessao'].':'.gmdate('Ymd'),200,time()+2*DAY_IN_SECONDS)){return array('ok'=>false,'codigo'=>'limite_tentativas','http'=>429);}
            $cipher=$valores?self::cifrar($valores):null;if($valores&&$cipher===null){return array('ok'=>false,'codigo'=>'cifragem_indisponivel','http'=>503);}
            $path=is_string($e['caminho']??null)?F3Base_Modulo_Comportamento::normalizar_caminho($e['caminho']):'';
            $marca=F3Base_Testes::resolver();if(!$marca['ok']){return $bad;}$classe=$marca['classe_trafego'];
            $ok=$wpdb->insert(self::tabela(),array('evento'=>$e['evento'],'formulario'=>$f['id'],'instancia'=>$e['instancia'],'sessao'=>$e['sessao'],'sequencia'=>$e['sequencia'],'etapa'=>$e['etapa'],'tipo'=>$e['tipo'],'criado_em'=>time(),'ocorrido_ms'=>$e['ocorrido_ms'],'caminho'=>substr($path,0,190),'classe_trafego'=>$classe,'campos'=>wp_json_encode($campos),'valores'=>$cipher,'titulares'=>wp_json_encode(array_values(array_unique($titulares))),'record_id'=>$record));
            return array('ok'=>$ok!==false,'codigo'=>$ok!==false?'registrada':'persistencia_indisponivel');
        }finally{F3Base_Trava::liberar($lock);F3Base_Trava::liberar($instance_lock);}
    }
    private static function where(array $e): string {
        global $wpdb;$e+=array('ate'=>wp_date('Y-m-d'));if(!isset($e['de'])){$e['de']=(new DateTimeImmutable($e['ate'],wp_timezone()))->modify('-'.(max(1,min(90,(int)($e['dias']??30)))-1).' days')->format('Y-m-d');}$j=F3Base_Relatorios::janela($e);$cut=F3Base_Retencao_Prazos::corte(self::OPTION);$w=$wpdb->prepare('criado_em>=%d AND criado_em<%d',max($cut,$j['inicio']),$j['fim']);
        $w.=F3Base_Testes::sql(F3Base_Testes::segmento($e['segmento']??null));foreach(array('formulario','sessao','instancia','caminho') as $k){if(!empty($e[$k])){$w.=$wpdb->prepare(" AND {$k}=%s",$e[$k]);}}return $w;
    }
    public static function consultar(array $e=array()): array {
        if(!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(is_wp_error(rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros())))){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        if(!self::pronta()){return array('ok'=>false,'codigo'=>'estrutura_indisponivel');}
        try{$where=self::where($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$limit=$e['limite']??50;$rows=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE '.$where.' AND id>%d ORDER BY id LIMIT %d',self::tabela(),$e['apos_id']??0,$limit+1),ARRAY_A);
        if($wpdb->last_error){return array('ok'=>false,'codigo'=>'leitura_indisponivel');}$more=count($rows)>$limit;$rows=array_slice($rows,0,$limit);
        foreach($rows as &$row){$values=self::abrir($row['valores']);$row['valores_estado']=$row['valores']===null?'nao_capturados':($values===null?'chave_indisponivel':'disponiveis');$row['campos']=json_decode($row['campos'],true)?:array();foreach($row['campos'] as &$c){if(is_array($values)&&array_key_exists($c['nome'],$values)){$c['valor']=$values[$c['nome']];}}unset($c);unset($row['valores'],$row['titulares']);foreach(array('id','sequencia','etapa','criado_em','ocorrido_ms') as $k){$row[$k]=(int)$row[$k];}}unset($row);
        return array('ok'=>true,'retencao_meses'=>(int)self::cfg()['retencao_meses'],'limite'=>$limit,'linhas'=>$rows,'proximo_id'=>$more?(int)end($rows)['id']:0,'limitacao'=>'Sequência declarada pelo navegador; recebimento em criado_em. Saída observada não comprova abandono: pode haver retorno. Ausência de envio também pode decorrer de bloqueio de rede, consentimento, retenção ou JavaScript indisponível. Sem sessão de medição, a sessão operacional dura somente esta página.');
    }
    public static function resumo(array $e): array {
        if(!current_user_can('manage_options')&&!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(!self::pronta()){return array('ok'=>false,'codigo'=>'estrutura_indisponivel');}
        try{$where=self::where($e);}catch(Throwable $x){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$last=0;$total=0;$counts=array();$cut=false;
        do{$rows=$wpdb->get_results($wpdb->prepare("SELECT id,formulario,campos FROM %i WHERE {$where} AND tipo='recusado' AND id>%d ORDER BY id LIMIT 500",self::tabela(),$last),ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'leitura_indisponivel');}foreach($rows as $row){if($total>=50000){$cut=true;break 2;}$total++;$last=(int)$row['id'];foreach(json_decode($row['campos'],true)?:array() as $field){foreach($field['regras'] as $rule){$k=$row['formulario'].'|'.$field['nome'].'|'.$rule;if(!isset($counts[$k])){$counts[$k]=array('formulario'=>$row['formulario'],'campo'=>$field['nome'],'regra'=>$rule,'contagem'=>0);}$counts[$k]['contagem']++;}}}}while(count($rows)===500);
        return array('ok'=>true,'tentativas'=>$total,'contagens_exatas'=>!$cut,'corte'=>$cut,'retencao_meses'=>(int)self::cfg()['retencao_meses'],'linhas'=>array_values($counts),'escopo'=>'Somente tentativas capturadas desde 1.44.0 dentro da retenção. Uma tentativa pode ter vários campos e regras; não equivale à contagem histórica de eventos f3base_form_recusado.');
    }
    public static function limpar(): void {if(!self::pronta()){return;}global $wpdb;$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE criado_em<%d',self::tabela(),F3Base_Retencao_Prazos::corte(self::OPTION)));}
    private static function eliminar_sessao(string $sessao): bool {
        global $wpdb;$lock=F3Base_Trava::adquirir('tentativa|'.$sessao,30);if(!$lock){return false;}
        try{$wpdb->query('START TRANSACTION');$t=F3Base_Leads_Repositorio::tabela('leads_janelas');$ok=$wpdb->query($wpdb->prepare('INSERT INTO %i (chave,total,expira) VALUES (%s,1,%d) ON DUPLICATE KEY UPDATE total=1,expira=VALUES(expira)',$t,self::chave_bloqueio($sessao),F3Base_Retencao_Prazos::deslocar(F3Base_Retencao_Prazos::meses(self::OPTION))+DAY_IN_SECONDS));$deleted=$ok!==false?$wpdb->query($wpdb->prepare('DELETE FROM %i WHERE sessao=%s',self::tabela(),$sessao)):false;if($deleted===false){$wpdb->query('ROLLBACK');return false;}return $wpdb->query('COMMIT')!==false;}finally{F3Base_Trava::liberar($lock);}
    }
    public static function eliminar_lead(array $lead): bool {
        $lock=F3Base_Trava::adquirir('tentativa-instancia|'.(string)($lead['correlacao']??''),30);if(!$lock){return false;}try{return self::eliminar_lead_reservado($lead);}finally{F3Base_Trava::liberar($lock);}
    }
    private static function eliminar_lead_reservado(array $lead): bool {
        if(!self::pronta()){return false;}global $wpdb;$inst=(string)($lead['correlacao']??'');$session=(string)($lead['sessao']??'');
        // A non-personal keyed tombstone also rejects delayed retries of this instance.
        if($inst!==''&&!F3Base_Leads_Repositorio::quota(self::chave_bloqueio($inst),PHP_INT_MAX,F3Base_Retencao_Prazos::deslocar(F3Base_Retencao_Prazos::meses(self::OPTION))+DAY_IN_SECONDS)){return false;}
        $ss=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT sessao FROM %i WHERE instancia=%s OR sessao=%s',self::tabela(),$inst,$session));if($wpdb->last_error){return false;}if($session!==''){$ss[]=$session;}foreach(array_unique($ss) as $s){if(!self::eliminar_sessao($s)){return false;}}return true;
    }
    public static function apagar_titular(string $email,int $page=1): array {
        global $wpdb;$removed=false;$ok=self::pronta();if($ok){$ss=$wpdb->get_col($wpdb->prepare('SELECT DISTINCT sessao FROM %i WHERE titulares LIKE %s LIMIT 100',self::tabela(),'%'.$wpdb->esc_like(self::hash_email($email)).'%'));$ok=!$wpdb->last_error;foreach($ss as $s){if(!self::eliminar_sessao($s)){$ok=false;break;}$removed=true;}}
        return array('items_removed'=>$removed,'items_retained'=>!$ok,'messages'=>$ok?array():array('Não foi possível confirmar a eliminação das tentativas. Repita a solicitação.'),'done'=>$ok&&count($ss??array())<100);
    }
}
