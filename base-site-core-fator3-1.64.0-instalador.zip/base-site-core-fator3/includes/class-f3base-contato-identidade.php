<?php
/** Exact, site-local identifier matching. No probabilistic or cross-site identity. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Contato_Identidade {
    public const ESQUEMA_VERSAO=16400;
    public const OPCAO='f3base_contato_identidade';
    public static function padroes(): array {return array('janela_dias'=>30,'suprimir_conversoes'=>array('ga4'=>false,'google_ads'=>false,'meta'=>false,'linkedin'=>false));}
    public static function config(): array {return array_replace_recursive(self::padroes(),(array)F3Base_Options::ler(self::OPCAO));}
    public static function catalogo(array $c): array {
        $props=array('janela_dias'=>array('type'=>'integer','minimum'=>1,'maximum'=>365),'suprimir_conversoes'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array('ga4','google_ads','meta','linkedin'),array('type'=>'boolean'))));
        $c[self::OPCAO]=F3Base_Conversas::catalogo_grupo(self::OPCAO,'Recorrência de contatos',self::padroes(),$props,static fn($v)=>'');$c[self::OPCAO]['descricao']='Associação exata por e-mail ou telefone no mesmo site; supressão opcional por destino, desligada por padrão.';return $c;
    }
    public static function identificadores(array $r): array {
        $d=$r['dados']??$r;if(is_string($d)){$d=json_decode($d,true)?:array();}
        $private=isset($d['contato_externo_cifrado'])?F3Base_Contato_Comunicacao::abrir($d['contato_externo_cifrado']):array();
        $email=strtolower(trim((string)($private['email']??$r['email']??$d['email']??'')));$phone=F3Base_Pipedrive_Api::telefone((string)($private['telefone']??$d['telefone']??''));
        return array('email'=>is_email($email)?$email:'','telefone'=>$phone);
    }
    /** Bounded scan over the time index also covers encrypted external contacts from 1.57.1. */
    public static function procurar(array $ident,int $at,int $window,bool $test,string $exclude='',bool $site=false): array {
        global $wpdb;if(($ident['email']??'')===''&&($ident['telefone']??'')===''){return array('ok'=>true,'codigo'=>'sem_identificadores','candidatos'=>array());}
        $cursor=0;$scanned=0;$found=array();$methods=$site?" AND metodo IN ('formulario','whatsapp_formulario','conteudo')":'';
        do{
            $rows=$wpdb->get_results($wpdb->prepare("SELECT id,record_id,metodo,criado_em,email,dados FROM %i WHERE id>%d AND criado_em>=%s AND criado_em<=%s AND captura='aceito' AND lixeira=0 AND eliminacao_pendente=0 AND (classe_trafego='teste')=%d AND record_id<>%s {$methods} ORDER BY id LIMIT 500",F3Base_Leads_Repositorio::tabela(),$cursor,gmdate('Y-m-d H:i:s',$at-$window),gmdate('Y-m-d H:i:s',$at),(int)$test,$exclude),ARRAY_A);
            if($wpdb->last_error){return array('ok'=>false,'codigo'=>'identidade_leitura_falhou','candidatos'=>array());}
            foreach($rows as $r){$cursor=(int)$r['id'];$scanned++;$other=self::identificadores($r);$by=array();foreach(array('email','telefone') as $k){if(($ident[$k]??'')!==''&&$ident[$k]===$other[$k]){$by[]=$k;}}if($by){$found[]=array('record_id'=>$r['record_id'],'metodo'=>$r['metodo'],'criado_em'=>$r['criado_em'],'minutos'=>max(0,(int)floor(($at-strtotime($r['criado_em'].' UTC'))/60)),'correspondencia'=>$by,'id'=>(int)$r['id']);}}
            if($scanned>=20000&&count($rows)===500){return array('ok'=>false,'codigo'=>'identidade_janela_excede_20000','candidatos'=>array());}
        }while(count($rows)===500);
        usort($found,static fn($a,$b)=>strcmp($b['criado_em'],$a['criado_em'])?:$b['id']<=>$a['id']);foreach($found as &$x){unset($x['id'],$x['criado_em']);}unset($x);
        return array('ok'=>true,'codigo'=>$found?'identidade_encontrada':'sem_registro_anterior','candidatos'=>$found);
    }
    public static function enriquecer(array $d,string $record): array {
        unset($d['registro_anterior'],$d['identidade_verificacao']);$at=strtotime(($d['criado_em']??gmdate('Y-m-d H:i:s')).' UTC')?:time();
        $r=self::procurar(self::identificadores($d),$at,self::config()['janela_dias']*DAY_IN_SECONDS,!empty($d['contexto_teste']),$record);
        $d['identidade_verificacao']=array('codigo'=>$r['codigo'],'completa'=>$r['ok'],'janela_dias'=>self::config()['janela_dias'],'em'=>time());if($r['ok']&&$r['candidatos']){$d['registro_anterior']=$r['candidatos'][0];}return $d;
    }
    public static function bloqueio(array $lead,string $target): string {
        if(empty(self::config()['suprimir_conversoes'][$target])){return '';}
        if(!empty($lead['dados']['registro_anterior'])){return 'registro_anterior_na_janela';}
        if(isset($lead['dados']['identidade_verificacao']['completa'])&&!$lead['dados']['identidade_verificacao']['completa']){return 'identidade_verificacao_incompleta';}return '';
    }
    public static function linha(array $a): string {$r=$a['registro_anterior']??array();return $r?'Já era contato há '.(int)$r['minutos'].' min por '.F3Base_Relatorios::rotulo($r['metodo']).'.':'';}
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_conversa_vinculos';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE {$t} (\nchave char(64) NOT NULL,\nrecord_id char(32) NOT NULL,\nprimeira_em bigint unsigned NOT NULL,\ncriado_em bigint unsigned NOT NULL,\neliminado tinyint NOT NULL DEFAULT 0,\nPRIMARY KEY  (chave),\nKEY contato (record_id)\n) ENGINE=InnoDB {$cc};");return !$wpdb->last_error&&$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
    }
    /** Called under the bridge's conversation lock; linking never emits capture hooks. */
    public static function whatsapp(string $key,array $private,bool $trava_mantida=false): array {
        if($trava_mantida){return self::whatsapp_interno($key,$private);}
        $lock=F3Base_Trava::adquirir('identidade-captura',120);if(!$lock){return array('persisted'=>false,'codigo'=>'identidade_ocupada');}
        try{return self::whatsapp_interno($key,$private);}finally{F3Base_Trava::liberar($lock);}
    }
    private static function whatsapp_interno(string $key,array $private): array {
        global $wpdb;$old=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);if($wpdb->last_error){return array('persisted'=>false,'codigo'=>'vinculo_leitura_falhou');}
        if($old){return array('persisted'=>!$old['eliminado'],'suppressed'=>(bool)$old['eliminado'],'record_id'=>$old['record_id'],'duplicado'=>true,'vinculado'=>true,'codigo'=>$old['eliminado']?'conversa_eliminada':'conversa_ja_vinculada');}
        $at=strtotime($private['primeiro_contato_em']??'')?:0;$phone=F3Base_Pipedrive_Api::telefone((string)($private['telefone']??''));if(!$at||$phone===''){return array('continuar'=>true,'codigo'=>'telefone_ou_instante_ausente');}
        $r=self::procurar(array('telefone'=>$phone),$at,F3Base_Whatsapp_Conversa::cfg()['janela_horas']*HOUR_IN_SECONDS,!empty($private['contexto_teste']),'',true);
        if(!$r['ok']){return array('persisted'=>false,'codigo'=>$r['codigo']);}
        if(count($r['candidatos'])!==1){return array('continuar'=>true,'codigo'=>$r['candidatos']?'mais_de_um_contato_na_janela':'nenhum_contato_na_janela');}
        $id=$r['candidatos'][0]['record_id'];$started=false;
        try{
            // Re-read the candidate set after taking the shared capture lock.
            $again=self::procurar(array('telefone'=>$phone),$at,F3Base_Whatsapp_Conversa::cfg()['janela_horas']*HOUR_IN_SECONDS,!empty($private['contexto_teste']),'',true);if(!$again['ok']||count($again['candidatos'])!==1||$again['candidatos'][0]['record_id']!==$id){return array('persisted'=>false,'codigo'=>'vinculo_contexto_alterado');}
            $row=$wpdb->get_row($wpdb->prepare('SELECT dados FROM %i WHERE record_id=%s AND captura=%s AND lixeira=0 AND eliminacao_pendente=0',F3Base_Leads_Repositorio::tabela(),$id,'aceito'),ARRAY_A);if(!$row){return array('persisted'=>false,'codigo'=>'contato_indisponivel');}$d=json_decode($row['dados'],true);$d['conversa_confirmada']=array('fonte'=>'whatsapp_ponte','primeira_mensagem_em'=>min($at,(int)($d['conversa_confirmada']['primeira_mensagem_em']??$at)),'correspondencia'=>'telefone_e164_unico','janela_horas'=>F3Base_Whatsapp_Conversa::cfg()['janela_horas']);
            if(!F3Base_Transacao::autocommit()){return array('persisted'=>false,'codigo'=>'transacao_ativa_ou_indisponivel');}
            if($wpdb->query('START TRANSACTION')===false){return array('persisted'=>false,'codigo'=>'transacao_indisponivel');}$started=true;
            if($wpdb->insert(self::tabela(),array('chave'=>$key,'record_id'=>$id,'primeira_em'=>$at,'criado_em'=>time()))!==1){throw new RuntimeException('vinculo_nao_persistido');}
            $encoded=wp_json_encode($d);$changed=$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>$encoded),array('record_id'=>$id,'dados'=>$row['dados'],'eliminacao_pendente'=>0,'lixeira'=>0,'captura'=>'aceito'));
            // A second conversation can confirm the same earliest instant. Accept a no-op only after the unchanged CAS target is proven under row lock.
            if($changed===false||($changed===0&&($encoded!==$row['dados']||$wpdb->get_var($wpdb->prepare('SELECT record_id FROM %i WHERE record_id=%s AND BINARY dados=BINARY %s AND eliminacao_pendente=0 AND lixeira=0 AND captura=%s FOR UPDATE',F3Base_Leads_Repositorio::tabela(),$id,$encoded,'aceito'))!==$id))){throw new RuntimeException('vinculo_nao_persistido');}
            if($wpdb->query('COMMIT')===false){throw new RuntimeException('vinculo_commit_incerto');}$started=false;return array('persisted'=>true,'record_id'=>$id,'duplicado'=>false,'vinculado'=>true,'codigo'=>'conversa_confirmada','efeitos'=>array('novo_registro'=>false,'pipedrive'=>false,'conversoes'=>false));
        }catch(Throwable $e){return array('persisted'=>false,'codigo'=>sanitize_key($e->getMessage()));}finally{if($started){$wpdb->query('ROLLBACK');}}
    }
    public static function eliminar(string $id): bool {global $wpdb;return $wpdb->update(self::tabela(),array('eliminado'=>1,'record_id'=>''),array('record_id'=>$id))!==false;}
    public static function relatorio(array $leads): array {
        $parent=array();$by=array();$without=0;$confirmed=array();$find=static function($id)use(&$parent,&$find){return $parent[$id]===$id?$id:($parent[$id]=$find($parent[$id]));};
        foreach($leads as $lead){$id=$lead['record_id'];$parent[$id]=$id;$ids=self::identificadores($lead);$has=false;foreach($ids as $kind=>$v){if($v===''){continue;}$has=true;$hash=hash('sha256',$kind.'|'.$v);if(isset($by[$hash])){$parent[$find($id)]=$find($by[$hash]);}else{$by[$hash]=$id;}}if(!$has){$without++;}$d=is_array($lead['dados'])?$lead['dados']:json_decode($lead['dados'],true);$a=F3Base_Atribuicao::normalizar($d['atribuicao']??array());if(($lead['metodo']??'')==='whatsapp_formulario'){$dim=array('superficie'=>$d['superficie']??$lead['formulario'],'campanha_id'=>$a['campanha_id'],'campanha'=>$a['utm_campaign']);$key=wp_json_encode($dim);$confirmed[$key]=$confirmed[$key]??$dim+array('contatos'=>0,'conversas_confirmadas'=>0);$confirmed[$key]['contatos']++;if(!empty($d['conversa_confirmada'])){$confirmed[$key]['conversas_confirmadas']++;}}}
        $roots=array();foreach(array_keys($parent) as $id){$roots[$find($id)]=true;}return array('registros'=>count($leads),'pessoas_distintas_por_identificadores'=>count($roots),'registros_sem_identificador'=>$without,'conversas_whatsapp'=>array_values($confirmed),'limite'=>'Estimativa por e-mail ou telefone compartilhado no recorte; não prova identidade civil nem inclui vínculos fora do recorte. Registros sem identificador contam separadamente.');
    }
}
