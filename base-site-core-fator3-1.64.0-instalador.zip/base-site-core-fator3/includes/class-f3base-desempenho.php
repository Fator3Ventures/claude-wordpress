<?php
/** Per-request inclusive/self timers. Never stores visit data or changes plugin activation. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Desempenho {
    private static array $rows=[];
    private static array $stack=[];
    private static array $contexts=[];
    private static bool $printed=false;
    private static ?WeakMap $wrapped=null;
    private static array $queries=[];
    private static int $query_count=0;
    private static array $hooks=['plugins_loaded','init','wp_loaded','wp','template_redirect','wp_head','wp_footer','login_head','login_footer','render_block','the_content','wp_enqueue_scripts','wp_nav_menu','nav_menu_link_attributes','wpseo_schema_graph','wpseo_schema_organization','wpseo_schema_person','wpseo_schema_webpage'];
    public static function instrumentar($hook): void {
        if(!in_array($hook,self::$hooks,true)){return;}global $wp_filter;if(empty($wp_filter[$hook])){return;}
        foreach($wp_filter[$hook]->callbacks as $priority=>$callbacks){foreach($callbacks as $id=>$entry){
            $cb=$entry['function'];if($cb instanceof Closure&&self::$wrapped!==null&&isset(self::$wrapped[$cb])){continue;}
            $own=false;if(is_array($cb)){$own=str_starts_with(is_object($cb[0])?get_class($cb[0]):(string)$cb[0],'F3Base_')&&$cb[0]!==__CLASS__;}
            elseif($cb instanceof Closure){$file=(new ReflectionFunction($cb))->getFileName();$own=$file&&str_starts_with($file,F3BASE_PLUGIN_DIR)&&!str_ends_with($file,'class-f3base-desempenho.php');}
            elseif(is_string($cb)){$own=str_starts_with($cb,'f3base_')||str_starts_with($cb,'F3Base_');}
            if($own){$wp_filter[$hook]->callbacks[$priority][$id]['function']=self::callback($hook,$cb);}
        }}
    }
    public static function consulta(string $sql): string {
        if(self::$stack){++self::$query_count;if(count(self::$queries)<200){
            // Store shape only: no contact values, credentials, content or literal WHERE clauses.
            preg_match('/^\s*([A-Z]+)/i',$sql,$verb);preg_match('/(?:FROM|INTO|UPDATE|TABLE)\s+`?([A-Za-z0-9_]+)`?/i',$sql,$table);
            preg_match("/option_name\\s*=\\s*'([a-zA-Z0-9_]+)'/",$sql,$option);
            self::$queries[]=array('operacao'=>strtoupper($verb[1]??'OUTRA'),'tabela'=>$table[1]??'','option'=>$option[1]??null,'callback'=>end(self::$contexts),'estrutura'=>(bool)preg_match('/^\s*(?:SHOW|ALTER|CREATE|DESCRIBE|DROP)\b/i',$sql));
        }}return $sql;
    }
    public static function ambiente(): array {
        $s=function_exists('opcache_get_status')?@opcache_get_status(false):false;
        return array('opcache'=>array('ligado'=>is_array($s)&&!empty($s['opcache_enabled']),'acertos'=>(int)($s['opcache_statistics']['hits']??0),'validate_timestamps'=>ini_get('opcache.validate_timestamps'),'revalidate_freq'=>ini_get('opcache.revalidate_freq')),'realpath_cache'=>array('bytes'=>function_exists('realpath_cache_size')?realpath_cache_size():null,'entradas'=>function_exists('realpath_cache_get')?count(realpath_cache_get()):null,'limite'=>ini_get('realpath_cache_size'),'ttl'=>ini_get('realpath_cache_ttl')));
    }
    public static function medir(string $module,string $phase,callable $fn){
        $start=hrtime(true);self::$stack[]=0;self::$contexts[]=$module.':'.$phase;$i=count(self::$stack)-1;
        try{return $fn();}finally{
            $elapsed=(hrtime(true)-$start)/1e6;$children=array_pop(self::$stack);array_pop(self::$contexts);
            if($i>0){self::$stack[$i-1]+=$elapsed;}
            $key=$phase.':'.$module;$r=self::$rows[$key]??['modulo'=>$module,'fase'=>$phase,'chamadas'=>0,'total_ms'=>0.0,'proprio_ms'=>0.0];
            $r['chamadas']++;$r['total_ms']+=$elapsed;$r['proprio_ms']+=max(0,$elapsed-$children);self::$rows[$key]=$r;
        }
    }
    public static function callback(string $hook,$fn): callable {
        $name=is_array($fn)?(is_object($fn[0])?get_class($fn[0]):$fn[0]).'::'.$fn[1]:($fn instanceof Closure?'callback':(string)$fn);
        if($fn instanceof Closure){$reflection=new ReflectionFunction($fn);$name='anonima:'.basename((string)$reflection->getFileName()).':'.$reflection->getStartLine();}
        $wrapper=static fn(...$args)=>self::medir($name,$hook,static fn()=>$fn(...$args));if(self::$wrapped===null){self::$wrapped=new WeakMap();}self::$wrapped[$wrapper]=true;return $wrapper;
    }
    public static function resumo(): array {
        $rows=array_values(self::$rows);foreach($rows as &$r){$r['total_ms']=round($r['total_ms'],3);$r['proprio_ms']=round($r['proprio_ms'],3);}unset($r);
        usort($rows,static fn($a,$b)=>$b['proprio_ms']<=>$a['proprio_ms']);
        return ['ok'=>true,'versao'=>F3BASE_PLUGIN_VERSAO,'contexto'=>wp_doing_cron()?'cron':(is_admin()?'administracao':((defined('REST_REQUEST')&&REST_REQUEST)?'rest':(($GLOBALS['pagenow']??'')==='wp-login.php'?'login':'pagina'))),'escopo'=>'callbacks_core_e_carga','consultas'=>self::$queries,'consultas_total'=>self::$query_count,'classes_carregadas'=>array_values(array_filter(get_declared_classes(),static fn($c)=>str_starts_with($c,'F3Base_'))),'ambiente'=>self::ambiente(),'nao_instrumentado_ms'=>round(max(0,(microtime(true)-(defined('F3BASE_INICIO')?F3BASE_INICIO:microtime(true)))*1000-array_sum(array_column($rows,'proprio_ms'))),3),'nao_instrumentado_escopo'=>'Janela do arquivo principal ao relatório menos tempo medido; inclui WordPress, tema e outros plugins, sem atribuí-los ao Core','modulos'=>$rows,'total_proprio_ms'=>round(array_sum(array_column($rows,'proprio_ms')),3),'geracao_ate_agora_ms'=>round((microtime(true)-(float)($_SERVER['REQUEST_TIME_FLOAT']??microtime(true)))*1000,3),'includes_core'=>count(array_filter(get_included_files(),static fn($f)=>str_starts_with($f,F3BASE_PLUGIN_DIR)))];
    }
    public static function iniciar(): void {
        add_action('all',array(__CLASS__,'instrumentar'),PHP_INT_MIN);add_filter('query',array(__CLASS__,'consulta'),PHP_INT_MAX);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('desempenho-ler','Tempos por módulo desta requisição ou de sondagem interna assinada da página/login',[self::class,'ler'],['contexto'=>['type'=>'string','enum'=>['atual','pagina','login']],'amostras'=>['type'=>'integer','minimum'=>1,'maximum'=>3]]);});
        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/desempenho',['methods'=>'GET','permission_callback'=>static fn()=>current_user_can('manage_options'),'callback'=>static fn($r)=>rest_ensure_response(self::ler($r->get_params())),'args'=>['contexto'=>['type'=>'string','enum'=>['atual','pagina','login']],'amostras'=>['type'=>'integer','minimum'=>1,'maximum'=>3]]]);});
        add_action('init',static function(){if(self::sonda()){if(!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE',true);}nocache_headers();}},0);
        add_action('wp_footer',[self::class,'imprimir'],PHP_INT_MAX);
        add_action('login_footer',[self::class,'imprimir'],PHP_INT_MAX);
    }
    private static function sonda(): bool {
        $v=$_SERVER['HTTP_X_F3BASE_DESEMPENHO']??'';
        if(!is_string($v)||!preg_match('/^([0-9]{10})\.([a-f0-9]{32})\.([a-f0-9]{64})$/D',$v,$m)||abs(time()-(int)$m[1])>60){return false;}
        $path=(string)wp_parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH);
        return hash_equals(hash_hmac('sha256',$m[1].'.'.$m[2].'|'.$path,wp_salt('auth')),$m[3]);
    }
    public static function imprimir(): void {
        if(self::$printed||!self::sonda()){return;}self::$printed=true;
        echo "\n".'<!--f3base-desempenho:'.base64_encode(wp_json_encode(self::resumo())).'-->'."\n";
    }
    public static function ler(array $e=[]): array {
        if(!current_user_can('manage_options')){return ['ok'=>false,'codigo'=>'sem_permissao'];}
        $kind=$e['contexto']??'atual';if($kind==='atual'){return self::resumo();}
        if(!in_array($kind,['pagina','login'],true)){return ['ok'=>false,'codigo'=>'contexto_invalido'];}
        $n=max(1,min(3,(int)($e['amostras']??1)));$url=$kind==='login'?site_url('wp-login.php'):home_url('/');$path=(string)wp_parse_url($url,PHP_URL_PATH);$samples=[];
        for($i=0;$i<$n;$i++){
            $nonce=time().'.'.bin2hex(random_bytes(16));$signed=$nonce.'.'.hash_hmac('sha256',$nonce.'|'.$path,wp_salt('auth'));
            $r=wp_safe_remote_get(add_query_arg('f3base_perf',substr(hash('sha256',$nonce),0,16),$url),['timeout'=>12,'redirection'=>0,'limit_response_size'=>2097152,'cookies'=>[],'headers'=>['Cache-Control'=>'no-cache','X-F3Base-Desempenho'=>$signed],'user-agent'=>'F3Base-Sonda/desempenho']);
            if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200||!preg_match('/<!--f3base-desempenho:([A-Za-z0-9+\/=]+)-->/',wp_remote_retrieve_body($r),$m)){$samples[]=['ok'=>false,'codigo'=>'sonda_sem_relatorio'];continue;}
            $parsed=json_decode((string)base64_decode($m[1],true),true);$samples[]=is_array($parsed)?$parsed:['ok'=>false,'codigo'=>'sonda_invalida'];
        }
        return ['ok'=>count(array_filter($samples,static fn($s)=>!empty($s['ok'])))===$n,'contexto'=>$kind,'origem'=>'sonda_interna_mesma_origem_sem_cache','amostras'=>$samples,'limite'=>'Tempos inclusivos contêm filhos; proprio_ms evita somá-los duas vezes. A medição termina no footer e não inclui transporte nem callbacks posteriores.'];
    }
}
