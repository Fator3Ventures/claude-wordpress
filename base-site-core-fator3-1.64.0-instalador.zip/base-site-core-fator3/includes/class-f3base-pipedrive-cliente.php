<?php
/** Pipedrive SDK support; loaded only when used. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Cliente {
    public function capabilities(): array {return array('contract'=>F3Base_Pipedrive_Operacao::CONTRACT,'methods'=>array('GET','POST','PUT','PATCH','DELETE'),'host'=>'api.pipedrive.com','consumer'=>'operacao','max_body_bytes'=>65536,'timeout'=>20,'automatic_write_retry'=>false);}
    public function status(): array {return F3Base_Pipedrive_Operacao::status($this);}
    public function request(string $method,string $path,array $query=array(),array $body=array(),array $context=array()): array {return F3Base_Pipedrive_Operacao::request($this,$method,$path,$query,$body,$context);}
}
