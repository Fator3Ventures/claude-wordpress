<?php
/** Cliente interno: credencial e transporte permanecem no Core. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}

/** Serializa despacho com alterações administrativas da identidade/autorização. */
final class F3Base_Pipedrive_Operacao {
    const CONTRACT='pipedrive-api-client/1.0.0';
    const OPTION='f3base_pipedrive_operacao';
    private static array $consumers=array();
    private static bool $registering=false;
    public static function iniciar(): void {add_action('plugins_loaded',static function(){self::$registering=true;try{do_action('f3base_register_pipedrive_consumers',new self(),self::CONTRACT);}finally{self::$registering=false;}},30);}
    public static function catalogo(array $c): array {
        $schema=array('type'=>'object','additionalProperties'=>false,'properties'=>array('ativo'=>array('type'=>'boolean'),'consumidores'=>array('type'=>'array','maxItems'=>20,'uniqueItems'=>true,'items'=>array('type'=>'string','pattern'=>'^[a-z0-9]+(?:-[a-z0-9]+)*$','maxLength'=>100)),'orcamento_diario'=>array('type'=>'integer','minimum'=>1,'maximum'=>1000000)));
        $c[self::OPTION]=array('rotulo'=>'Operação administrativa no Pipedrive','descricao'=>'Autorize explicitamente os plugins que podem operar a API pelo Core neste site. Padrão desligado e sem consumidores. O orçamento diário local é separado das entregas; a reserva mínima de saldo da conta é 3000. Configure por config-core-escrever com revisão e procedência.','operavel'=>true,'campo'=>'grupo','padrao'=>array('ativo'=>false,'consumidores'=>array(),'orcamento_diario'=>3000),'autoload'=>false,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>static fn($v,$p)=>is_array($v)?array_replace($p,$v):$p,'recusa'=>static function($v)use($schema){$r=rest_validate_value_from_schema($v,$schema);return is_wp_error($r)?$r->get_error_message():'';});
        foreach(array('f3base_pipedrive_operacao_orcamento',F3Base_Pipedrive_Saldo::OPTION) as $n){$c[$n]=array('rotulo'=>$n,'operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));}
        return $c;
    }
    public function register_consumer($provider,$version,$contract,$configuration) {
        if(!self::$registering||!is_string($provider)||!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D',$provider)||strlen($provider)>100||!is_string($version)||strlen($version)>80||$version===''||$contract!==self::CONTRACT||!is_callable($configuration)||isset(self::$consumers[$provider])){return new WP_Error('consumidor_recusado','Registro de consumidor recusado.');}
        $client=new F3Base_Pipedrive_Cliente();self::$consumers[$provider]=array('client'=>$client,'version'=>$version,'configuration'=>$configuration);return $client;
    }
    private static function registro(F3Base_Pipedrive_Cliente $client): ?array {foreach(self::$consumers as $p=>$r){if($r['client']===$client){return array('provider'=>$p)+$r;}}return null;}
    public static function resposta(bool $ok,string $code,array $data=array(),?bool $dispatched=false): array {
        $messages=array('ok'=>'Consulta concluída.','operacao_nao_autorizada'=>'Operação não autorizada para este consumidor neste site.','credencial_invalida'=>'Conta e credencial precisam estar verificadas no Core.','core_em_recuperacao'=>'O Core está em recuperação ou não pôde confirmar a barreira.','revisao_conflitante'=>'A configuração mudou; gere uma nova prévia.','contexto_alterado'=>'O consumidor ou administrador mudou; gere uma nova prévia.','saldo_conta_baixo'=>'O último saldo oficial é menor que a reserva de 3000.','orcamento_esgotado'=>'O orçamento local de operação foi atingido.','pausa_remota'=>'A conta aguarda a pausa remota compartilhada.','entrada_invalida'=>'Método, caminho, parâmetros ou tamanho recusados.','core_indisponivel'=>'Não foi possível confirmar o estado ou adquirir a trava.','resultado_incerto'=>'Transporte sem confirmação; reconcilie antes de repetir qualquer escrita.','fornecedor_recusou'=>'O fornecedor recusou a requisição; o corpo de erro foi omitido.','resposta_excedeu_limite'=>'Resposta maior que 512 KiB; use paginação e reconcilie escritas.');
        return array('success'=>$ok,'code'=>$code,'message'=>$messages[$code]??'Operação recusada.','data'=>$data,'remote_dispatched'=>$dispatched);
    }
    private static function foto(F3Base_Pipedrive_Cliente $client): array {
        if(!current_user_can('manage_options')){return self::resposta(false,'operacao_nao_autorizada');}
        $recovery=F3Base_Recuperacao::ler();if(empty($recovery['ok'])||!empty($recovery['pausado'])){return self::resposta(false,'core_em_recuperacao');}
        $record=self::registro($client);if(!$record){return self::resposta(false,'operacao_nao_autorizada');}
        try{$consumer=call_user_func($record['configuration']);}catch(Throwable $e){return self::resposta(false,'contexto_alterado');}
        if(!is_array($consumer)||($consumer['ready']??null)!==true||($consumer['provider']??'')!==$record['provider']||!is_string($consumer['revision']??null)||$consumer['revision']===''||strlen($consumer['revision'])>200){return self::resposta(false,'contexto_alterado');}
        $balanceState=F3Base_Options::fotografia_bruta(F3Base_Pipedrive_Saldo::OPTION);if($balanceState['erro']){return self::resposta(false,'core_indisponivel');}
        $o=F3Base_Options::fotografia(self::OPTION);$c=F3Base_Options::fotografia('f3base_pipedrive');$t=F3Base_Options::fotografia_bruta('f3base_pipedrive_token');$s=F3Base_Options::fotografia_bruta('f3base_pipedrive_estado');
        if($o['erro']||$c['erro']||$t['erro']||$s['erro']){return self::resposta(false,'core_indisponivel');}
        if(($o['valor']['ativo']??false)!==true||!in_array($record['provider'],(array)($o['valor']['consumidores']??array()),true)){return self::resposta(false,'operacao_nao_autorizada',array('contract'=>self::CONTRACT,'autorizado'=>false));}
        $state=is_array($s['valor'])?$s['valor']:array();$token=F3Base_Segredos::abrir('f3base_pipedrive_token',is_string($t['valor'])?$t['valor']:'');$domain=$c['valor']['dominio']??'';
        if(!preg_match('/^[a-z0-9][a-z0-9-]{0,62}\.pipedrive\.com$/D',$domain)||!preg_match('/^[a-fA-F0-9]{40}$/D',$token)||!F3Base_Integracoes::pipedrive_verificado($state)||!ctype_digit((string)($state['conta_id']??''))||(int)$state['conta_id']<1||!ctype_digit((string)($state['usuario_id']??''))||(int)$state['usuario_id']<1||($state['dominio']??'')!==$domain){return self::resposta(false,'credencial_invalida');}
        $budget=F3Base_Pipedrive_Orcamento::resumo()['consumidores']['operacao'];
        $data=array('contract'=>self::CONTRACT,'autorizado'=>true,'conta'=>array('dominio'=>$domain,'conta_id'=>$state['conta_id'],'usuario_id'=>$state['usuario_id']),'revisao'=>hash('sha256',wp_json_encode(array($o['revisao'],$c['revisao'],$t['revisao'],$state['conta_id'],$state['usuario_id'],$state['instalacao']??'',$record['provider'],$record['version'],$consumer['revision'],$recovery['geracao'],get_current_blog_id(),home_url()))),'orcamento'=>array('teto'=>(int)$budget['limite'],'consumido'=>(int)$budget['consumido_estimado'],'reservado'=>(int)$budget['reservado']),'saldo_conta'=>F3Base_Pipedrive_Saldo::ler($token,$domain));
        return self::resposta(true,'ok',$data)+array('_token'=>$token,'_cfg'=>$c['valor'],'_provider'=>$record['provider'],'_pausa'=>(int)($state['pausa_ate']??0));
    }
    public static function status(F3Base_Pipedrive_Cliente $client): array {$r=self::foto($client);unset($r['_token'],$r['_cfg'],$r['_provider'],$r['_pausa']);return $r;}
    public static function resumo(): array {
        $cfg=F3Base_Options::fotografia(self::OPTION);$budget=F3Base_Pipedrive_Orcamento::resumo()['consumidores']['operacao'];
        return array('contract'=>self::CONTRACT,'ativo'=>!$cfg['erro']&&($cfg['valor']['ativo']??false)===true,'consumidores_autorizados'=>$cfg['erro']?array():($cfg['valor']['consumidores']??array()),'consumidores_registrados'=>array_keys(self::$consumers),'orcamento'=>$budget,'saldo_conta'=>F3Base_Pipedrive_Saldo::ler(),'reserva_minima_conta'=>3000,'documentacao'=>'docs/PIPEDRIVE-OPERACAO.md');
    }
    private static function dados_validos($v,int $depth=0): bool {
        if($depth>20){return false;}if(is_array($v)){foreach($v as $k=>$item){if(is_string($k)&&preg_match('/^(?:ids|api[_-]?token|access[_-]?token|authorization)$/iD',$k)){return false;}if(!self::dados_validos($item,$depth+1)){return false;}}return true;}return $v===null||is_scalar($v);
    }
    private static function limpar($v,string $token,int $depth=0) {
        if($depth>40){return null;}if(is_array($v)){$out=array();foreach($v as $k=>$item){$key=is_string($k)?str_replace($token,'[credencial removida]',$k):$k;if(is_string($key)&&preg_match('/(?:token|secret|authorization|cookie|password)/i',$key)){$out[$key]='[credencial removida]';}else{$out[$key]=self::limpar($item,$token,$depth+1);}}return $out;}
        return is_string($v)?str_replace(array($token,rawurlencode($token)),'[credencial removida]',$v):$v;
    }
    public static function request(F3Base_Pipedrive_Cliente $client,string $method,string $path,array $query,array $body,array $context): array {
        if(!in_array($method,array('GET','POST','PUT','PATCH','DELETE'),true)||strlen($path)>1000||!preg_match('#^/(?:v1|api/v2)/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*$#D',$path)||stripos($path,'merge')!==false||!self::dados_validos($query)||!self::dados_validos($body)||$method==='GET'&&$body){return self::resposta(false,'entrada_invalida');}
        $json=wp_json_encode($body);$q=wp_json_encode($query);if(!is_string($json)||strlen($json)>65536||!is_string($q)||strlen($q)>16384){return self::resposta(false,'entrada_invalida');}
        if(!F3Base_Recuperacao::entrar()){return self::resposta(false,'core_em_recuperacao');}
        try{$result=F3Base_Pipedrive_Trava::executar(static function()use($client,$method,$path,$query,$body,$context,$json){
            $snapshot=self::foto($client);if(!$snapshot['success']){return $snapshot;}
            if(($context['contract']??'')!==self::CONTRACT||($context['consumer']??'')!=='operacao'||($context['provider']??'')!==$snapshot['_provider']||($context['actor_id']??null)!==get_current_user_id()||($method!=='GET'&&(!is_string($context['previa_id']??null)||!preg_match('/^[A-Za-z0-9_-]{1,100}$/D',$context['previa_id'])))){return self::resposta(false,'contexto_alterado');}
            if(!is_string($context['revisao_esperada']??null)||!hash_equals($snapshot['data']['revisao'],$context['revisao_esperada'])){return self::resposta(false,'revisao_conflitante');}
            if($snapshot['_pausa']>time()){return self::resposta(false,'pausa_remota');}
            if($snapshot['data']['saldo_conta']!==null&&$snapshot['data']['saldo_conta']['restante']<3000){return self::resposta(false,'saldo_conta_baixo',array('saldo_conta'=>$snapshot['data']['saldo_conta']));}
            $reservation=F3Base_Pipedrive_Orcamento::reservar('operacao',$snapshot['_cfg'],$method==='GET'?20:10);if(empty($reservation['ok'])){return self::resposta(false,'orcamento_esgotado');}$sent=false;
            try{
                $fresh=self::foto($client);if(!$fresh['success']){return $fresh;}if(!hash_equals($snapshot['data']['revisao'],$fresh['data']['revisao'])){return self::resposta(false,'revisao_conflitante');}
                $barreira=F3Base_Recuperacao::ler();if(empty($barreira['ok'])||!empty($barreira['pausado'])){return self::resposta(false,'core_em_recuperacao');}
                if(!F3Base_Pipedrive_Trava::atual()){return self::resposta(false,'core_indisponivel');}
                if($fresh['_pausa']>time()){return self::resposta(false,'pausa_remota');}if($fresh['data']['saldo_conta']!==null&&$fresh['data']['saldo_conta']['restante']<3000){return self::resposta(false,'saldo_conta_baixo');}
                $url='https://api.pipedrive.com'.$path.($query?'?'.http_build_query($query,'','&',PHP_QUERY_RFC3986):'');
                $args=array('method'=>$method,'timeout'=>20,'redirection'=>0,'sslverify'=>true,'limit_response_size'=>524289,'headers'=>array('x-api-token'=>$fresh['_token'],'Accept'=>'application/json','Content-Type'=>'application/json'));if($method!=='GET'){$args['body']=$json;}
                $sent=true;try{$response=wp_remote_request($url,$args);}catch(Throwable $e){return self::resposta(false,'resultado_incerto',array('http_status'=>null,'body'=>null,'saldo_conta'=>F3Base_Pipedrive_Saldo::ler()),null);}
                F3Base_Pipedrive_Saldo::observar($response,$fresh['_token'],$fresh['_cfg']['dominio']);
                if(is_wp_error($response)){return self::resposta(false,'resultado_incerto',array('http_status'=>null,'body'=>null,'saldo_conta'=>F3Base_Pipedrive_Saldo::ler()),null);}
                $http=(int)wp_remote_retrieve_response_code($response);$raw=wp_remote_retrieve_body($response);$large=strlen($raw)>524288;$data=$large?null:json_decode($raw,true,64,JSON_BIGINT_AS_STRING);$valid=!$large&&json_last_error()===JSON_ERROR_NONE;
                $ok=$http>=200&&$http<300&&($http===204||$valid)&&(!is_array($data)||($data['success']??true)!==false);
                $code=$ok?'ok':($large?'resposta_excedeu_limite':($http>=500||$http<100||$http>=200&&$http<300?'resultado_incerto':'fornecedor_recusou'));
                return self::resposta($ok,$code,array('http_status'=>$http,'body'=>$ok?self::limpar($data,$fresh['_token']):null,'saldo_conta'=>F3Base_Pipedrive_Saldo::ler()),true);
            }finally{F3Base_Pipedrive_Orcamento::finalizar($reservation,$sent);}
        });return is_array($result)?$result:self::resposta(false,'core_indisponivel');}finally{F3Base_Recuperacao::sair();}
    }
}
