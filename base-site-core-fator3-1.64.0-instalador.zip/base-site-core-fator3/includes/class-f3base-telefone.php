<?php
/** A permissividade é do campo declarado no servidor; a marca não concede identidade. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Telefone {
    const OPTION='f3base_converter_contato_sem_identificador';
    public static function classificacao(string $v,string $pais='BR'): array {
        $n=F3Base_Pipedrive_Api::telefone($v,$pais);$tipo='nao_classificado';$regra='telefone-internacional-sintatico';
        if(str_starts_with($n,'+55')&&F3Base_Pipedrive_Api::telefone(substr($n,3),'BR')===$n){$s=substr($n,5);$tipo=preg_match('/^(?:[6-9][0-9]{7}|9[0-9]{8})$/D',$s)?'celular':'fixo';$regra=$tipo==='fixo'?'br-fixo-8-prefixo-2-5':(strlen($s)===8?'br-celular-8-prefixo-6-9':'br-celular-9-prefixo-9');}
        elseif(str_starts_with($n,'+351')){$tipo=preg_match('/^\+3519[0-9]{8}$/D',$n)?'celular':'fixo';$regra='pt-prefixo-9';}
        elseif($n!==''){$tipo=str_starts_with($n,'+55')?'nao_classificado':'internacional';}
        return array('tipo'=>$tipo,'regra'=>$regra,'versao_regra'=>'1.56.0','nono_digito_inserido'=>false);
    }
    public static function livre(array $c): bool {return F3Base_Formularios::telefone_livre($c);}
    public static function diagnostico(string $v,string $pais,bool $livre=false): array {
        $normal=F3Base_Pipedrive_Api::telefone($v,$pais);$n=preg_replace('/[ ().-]/','',trim($v));$motivo='';
        if($normal===''){
            if(!preg_match('/^[+0-9]*$/D',$n)){$motivo='caracteres_invalidos';}
            elseif(str_starts_with($n,'+')){$motivo='formato_internacional';}
            elseif($pais==='BR'){
                if(in_array(strlen($n),array(8,9),true)){$motivo='sem_ddd';}
                elseif(!in_array(strlen($n),array(10,11),true)){$motivo='quantidade_digitos';}
                elseif(F3Base_Pipedrive_Api::telefone(substr($n,0,2).'987654321','BR')===''){$motivo='ddd_invalido';}
                elseif((strlen($n)===10&&$n[2]==='9')||(strlen($n)===11&&$n[2]!=='9')){$motivo='quantidade_digitos';}
                else{$motivo='prefixo_invalido';}
            }else{$motivo='formato_pais';}
        }
        $classe=$normal!==''?'valido':($motivo==='sem_ddd'?'sem_ddd':($motivo==='quantidade_digitos'&&strlen($n)<($pais==='BR'?11:($pais==='PT'?9:10))?'incompleto':'outro'));
        return array('classe'=>$classe,'motivo'=>$motivo,'pais'=>$pais,'normalizado'=>$normal,'formato_livre'=>$livre,'regra'=>self::classificacao($v,$pais)['regra'],'classificacao'=>self::classificacao($v,$pais));
    }
    /** The single contact field accepts presence; only a valid normalized identity leaves this boundary. */
    public static function contato(string $digitado): array {
        $v=trim($digitado);$email=is_email($v)?strtolower($v):'';
        $out=array('digitado'=>wp_check_invalid_utf8($digitado),'tipo'=>$email!==''?'email':'telefone','classe'=>'valido','email'=>$email,'telefone'=>'','regra'=>'contato-1.47.0');
        if($email!==''){return $out;}
        $d=self::diagnostico($v,F3Base_Options::ler('f3base_pipedrive')['pais_telefone']??'BR',true);
        $d['classe']=in_array($d['classe'],array('valido','sem_ddd'),true)?$d['classe']:'invalido';
        return array_replace($out,array('classe'=>$d['classe'],'telefone'=>$d['normalizado'],'diagnostico'=>$d));
    }
    public static function nao_normalizado(array $d): bool {$m=$d['telefone_normalizacao']??array();if((self::classificacao((string)($d['telefone']??''),(string)($m['pais']??'BR'))['regra'])==='br-celular-8-prefixo-6-9'){return false;}return !empty($m['formato_livre'])&&($m['classe']??'valido')!=='valido';}
    public static function sem_identificador(array $lead): bool {$d=$lead['dados']??$lead;return self::nao_normalizado($d)&&!is_email((string)($lead['email']??$d['email']??''));}
    public static function converter(array $lead): bool {return !self::sem_identificador($lead)||F3Base_Options::ler(self::OPTION)!==false;}
    public static function marca(array $lead): string {$d=$lead['dados']??$lead;return (string)($d['telefone_normalizacao']['classe']??'nao_observado');}
    public static function catalogo(array $c): array {
        $c[self::OPTION]=array('rotulo'=>'Contar contato com telefone não normalizado e sem e-mail válido','descricao'=>'Ligado mantém as conversões de contato no GA4, Google Ads e Meta. Desligado impede novas conversões desse caso; o contato continua aceito e encaminhado. Não altera conversões já entregues nem autorizações de consentimento.','operavel'=>true,'secao'=>'medicao','campo'=>'booleano','padrao'=>true,'schema_config'=>array('type'=>'boolean'),'schema_entrada'=>array('type'=>'boolean'),'sanitiza'=>static fn($v)=>(bool)filter_var($v,FILTER_VALIDATE_BOOLEAN),'recusa'=>static fn($v)=>in_array($v,array(true,false,0,1,'0','1'),true)?'':'Escolha ligado ou desligado.');return $c;
    }
}
