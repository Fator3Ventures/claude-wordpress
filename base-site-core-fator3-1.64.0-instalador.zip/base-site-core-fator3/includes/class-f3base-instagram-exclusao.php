<?php
/** Durable erasure outbox. Personal targets are encrypted until a verified Meta receipt. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Instagram_Exclusao {
    public const ESQUEMA_VERSAO=16400;
    const CONTRACT='instagram-message-erasure/1.0.0';
    const SDK='Fator3\\Meta\\Messaging';
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_instagram_exclusoes';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();$collate=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $t (
            record_id char(32) NOT NULL,
            chave varchar(100) NOT NULL,
            alvo longtext NOT NULL,
            pedido longtext NULL,
            estado varchar(64) NOT NULL,
            recibo longtext NOT NULL,
            codigo varchar(96) NOT NULL DEFAULT '',
            atualizado_em bigint unsigned NOT NULL,
            PRIMARY KEY  (record_id),
            UNIQUE KEY chave (chave),
            KEY estado (estado,atualizado_em)
        ) ENGINE=InnoDB $collate;");return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t&&in_array('pedido',$wpdb->get_col($wpdb->prepare('SHOW COLUMNS FROM %i',$t)),true);
    }
    private static function row(string $id): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',self::tabela(),$id),ARRAY_A);}
    public static function preparar(array $r): bool {
        if(($r['metodo']??'')!=='instagram_conversa'){return true;}global $wpdb;
        if(self::row($r['record_id'])){return true;}if($wpdb->last_error){return false;}
        $private=F3Base_Contato_Comunicacao::abrir($r['dados']['contato_externo_cifrado']??'');$ig=$private['instagram']??array();
        $target=array_intersect_key($ig,array_flip(array('connection_id','account_id','event_id')));$valid=count($target)===3;
        $cipher=$valid?F3Base_Contato_Comunicacao::cifrar($target):'';if($valid&&!$cipher){return false;}
        return 1===$wpdb->insert(self::tabela(),array('record_id'=>$r['record_id'],'chave'=>'core-erasure-'.bin2hex(random_bytes(24)),'alvo'=>$cipher,'estado'=>'pendente','codigo'=>$valid?'aguardando_eliminacao_core':'alvo_anterior_indisponivel','recibo'=>'{}','atualizado_em'=>time()));
    }
    public static function estado(string $id,bool $instagram=false): array {
        $r=self::row($id);if(!$r){return array('estado'=>$instagram?'pendente_alvo_anterior_indisponivel':'nao_aplicavel','pendente'=>$instagram,'recibo'=>null);}
        return array('estado'=>$r['estado'],'pendente'=>$r['estado']!=='erased','codigo'=>$r['codigo'],'recibo'=>json_decode($r['recibo'],true)?:null,'atualizado_em'=>(int)$r['atualizado_em']);
    }
    private static function falhar(string $id,string $code): bool {global $wpdb;$wpdb->update(self::tabela(),array('estado'=>'pendente','codigo'=>preg_match('/^[a-zA-Z0-9_:-]{1,96}$/D',$code)?$code:'meta_falha','atualizado_em'=>time()),array('record_id'=>$id));return false;}
    public static function executar(string $id): bool {
        if(!F3Base_Transacao::autocommit()){return false;}
        $r=self::row($id);if(!$r){return false;}if($r['estado']==='erased'){return true;}
        if(!current_user_can('manage_options')||!current_user_can('f3base_gerir_leads')){return self::falhar($id,'retomar_com_administrador');}
        $lead=F3Base_Leads_Repositorio::obter($id);if(!$lead||$lead['captura']!=='eliminado'||!empty($lead['eliminacao_pendente'])){return self::falhar($id,'aguardando_eliminacao_core');}
        if(!class_exists(self::SDK)||!is_callable(array(self::SDK,'eraseLocalData'))){return self::falhar($id,'meta_sdk_indisponivel');}
        $lock=F3Base_Trava::adquirir('ig-erase-'.$id,60);if(!$lock){return false;}
        try{
            $r=self::row($id);if($r['estado']==='erased'){return true;}$target=F3Base_Contato_Comunicacao::abrir($r['alvo']);
            if(!$target){return self::falhar($id,'alvo_anterior_indisponivel');}
            $sdk=self::SDK;if(($sdk::privacyContract()['contract']??'')!==self::CONTRACT){return self::falhar($id,'meta_contrato_incompativel');}
            // Retain the exact revision across a partial failure, encrypted beside the target.
            $request=!empty($r['pedido'])?F3Base_Contato_Comunicacao::abrir($r['pedido']):null;
            if(!empty($r['pedido'])&&!$request){return self::falhar($id,'pedido_cifrado_ilegivel');}
            if(!$request){
                $state=$sdk::privacyStatus($target);$request=$target+array('expected_revision'=>$state['revision'],'idempotency_key'=>$r['chave']);
                $cipher=F3Base_Contato_Comunicacao::cifrar($request);global $wpdb;
                if(!$cipher||false===$wpdb->update(self::tabela(),array('pedido'=>$cipher),array('record_id'=>$id))){return false;}
            }
            $receipt=$sdk::eraseLocalData($request);
            $confirmed=$sdk::erasureReceipt($r['chave']);
            $state=$sdk::privacyStatus($target);
            if($receipt!==$confirmed||($receipt['contract']??'')!==self::CONTRACT||($receipt['state']??'')!=='erased'||empty($receipt['local_identifiers_removed'])||empty($receipt['reimportation_blocked'])||($state['state']??'')!=='erased'){return self::falhar($id,'meta_recibo_nao_confirmado');}
            $receipt=array_intersect_key($receipt,array_flip(array('contract','receipt_id','state','local_identifiers_removed','reimportation_blocked','revision','completed_at','external_copies_erased')));
            global $wpdb;return 1===$wpdb->update(self::tabela(),array('estado'=>'erased','codigo'=>'','recibo'=>wp_json_encode($receipt),'alvo'=>'','pedido'=>'','atualizado_em'=>time()),array('record_id'=>$id,'estado'=>'pendente'));
        }catch(Throwable $e){$code=is_string($e->reason??null)?$e->reason:'meta_exclusao_falhou';if($code==='revision_conflict'&&isset($sdk,$target)){try{$now=$sdk::privacyStatus($target);if(empty($now['reimportation_blocked'])&&in_array($now['state']??'',array('retained','absent'),true)){global $wpdb;$wpdb->update(self::tabela(),array('pedido'=>null),array('record_id'=>$id));}}catch(Throwable $ignored){/* Keep the original request when acceptance is uncertain. */}}return self::falhar($id,$code);}
        finally{F3Base_Trava::liberar($lock);}
    }
}
