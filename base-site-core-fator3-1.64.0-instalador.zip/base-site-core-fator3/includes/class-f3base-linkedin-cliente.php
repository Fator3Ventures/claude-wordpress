<?php
/** Explicit adapters. External credentials and stores never cross this boundary. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Cliente {
    const CONTRATO='linkedin-lead-reader/1.1.0';
    private static array $registrados=array();
    public static function registrar($api=null): void {
        if(!class_exists('Fator3\\LinkedIn\\PublicApi')){return;}
        $caps=\Fator3\LinkedIn\PublicApi::capabilities();if(!in_array(self::CONTRATO,$caps['contracts']??array(),true)){return;}
        // Discovery only declares identities. Raw mutation snapshots and the
        // administrative catalog belong to execution, not every public visit.
        $found=false;$value=F3Base_Perfil_Publico::ativo()?F3Base_Perfil_Publico::ler('f3base_anuncios_linkedin',$found):null;
        if(!$found){$value=get_option('f3base_anuncios_linkedin',array());}
        $all=is_array($value)&&isset($value['integracoes'])?$value['integracoes']:array('principal'=>$value);
        foreach($all as $id=>$cfg){if(!is_array($cfg)||empty($cfg['uuid'])){continue;}$consumer='site-core-li-'.str_replace('-','',(string)$cfg['uuid']);$r=\Fator3\LinkedIn\PublicApi::register_consumer(array('id'=>$consumer,'label'=>'Site Core · '.$id,'contract'=>self::CONTRATO));self::$registrados[$consumer]=!empty($r['success']);}
    }
    public static function externo(): bool {return (F3Base_Linkedin::config()['cliente']??'core')==='linkedin_plugin';}
    public static function chamar(string $method,array $input=array()): array {
        $cfg=F3Base_Linkedin::config();$consumer=F3Base_Linkedin_Integracoes::consumer();
        if(!class_exists('Fator3\\LinkedIn\\PublicApi')){return array('ok'=>false,'codigo'=>'sdk_ausente','data'=>array());}
        try{
            self::registrar();if(empty(self::$registrados[$consumer])){return array('ok'=>false,'codigo'=>'contrato_incompativel','data'=>array());}
            $reader=\Fator3\LinkedIn\PublicApi::lead_reader($consumer);$desc=$reader->descriptor();
            if(($desc['contract']??'')!==self::CONTRATO||!in_array($method,$desc['methods']??array(),true)){return array('ok'=>false,'codigo'=>'capacidade_ausente','data'=>array());}
            $r=$reader->$method(array('connection_id'=>$cfg['connection_id'],'account_id'=>$cfg['conta_id'])+$input);
            return array('ok'=>!empty($r['success']),'codigo'=>$r['error_code']??$r['code']??'sdk_resposta_invalida','data'=>$r['data']??array(),'detalhes'=>$r['details']??array(),'retry_after'=>$r['details']['retry_after']??$r['retry_after']??60,'http'=>($r['error_code']??'')==='resource_not_found'?404:($r['http_status']??0),'incerto'=>in_array($r['error_code']??'',array('operation_uncertain','transport_error'),true),'envelope'=>$r);
        }catch(Throwable $e){return array('ok'=>false,'codigo'=>'sdk_incompativel','data'=>array());}
    }
    /** Public admin catalog, distinct from the consumer's restricted lead-reader grant. */
    public static function catalogo(string $kind,string $cursor=''): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(!in_array($kind,array('formularios','campanhas'),true)){return array('ok'=>false,'codigo'=>'catalogo_nao_aplicavel');}
        $cfg=F3Base_Linkedin::config();
        // Same guard as the Core client (1.49.0): without a saved account or plugin
        // connection the input would be refused by the ability schema anyway.
        if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$/D',(string)($cfg['connection_id']??''))){return array('ok'=>false,'codigo'=>'selecione_a_conexao_linkedin','mensagem'=>'Selecione e salve a conexão do plugin LinkedIn nesta integração antes de atualizar a lista.');}
        if(!preg_match('/^[0-9]+$/D',(string)($cfg['conta_id']??''))){return array('ok'=>false,'codigo'=>'salve_a_conta','mensagem'=>'Salve a conta de anúncios LinkedIn desta integração antes de atualizar a lista.');}
        $ability=function_exists('wp_get_ability')?wp_get_ability('linkedin/admin-options'):null;
        if(!$ability){return array('ok'=>false,'codigo'=>'atualize_o_plugin_linkedin_para_0_4_1');}
        $input=array('connection_id'=>$cfg['connection_id'],'account_id'=>$cfg['conta_id'],'channel'=>$kind==='formularios'?'leads':'ads','kind'=>$kind==='formularios'?'forms':'objects');
        if($kind==='campanhas'){$input['report']='campaigns';}
        $revision=null;
        if($cursor!==''){
            $c=json_decode(base64_decode($cursor,true)?:'',true);
            if(!is_array($c)||($c['kind']??'')!==$kind||!is_int($c['revision']??null)||!isset($c['next'])){return array('ok'=>false,'codigo'=>'cursor_invalido');}
            $revision=$c['revision'];$input[$kind==='formularios'?'offset':'cursor']=$c['next'];
        }
        try{$r=$ability->execute($input);}catch(Throwable $e){return F3Base_Abilities_Nativas::falha($e,'linkedin_catalogo_indisponivel','linkedin/admin-options');}
        if(is_wp_error($r)||!is_array($r)||empty($r['success'])){return F3Base_Abilities_Nativas::falha($r,'linkedin_catalogo_indisponivel','linkedin/admin-options');}
        $d=$r['data']??array();if(!is_int($d['connection_revision']??null)){return array('ok'=>false,'codigo'=>'contrato_catalogo_invalido');}
        if($revision!==null&&$revision!==$d['connection_revision']){return array('ok'=>false,'codigo'=>'configuracao_alterada');}
        $rows=array();foreach($d['rows']??array() as $row){$id=(string)($row['id']??'');if(ctype_digit($id)){$rows[]=array('id'=>$id,'name'=>sanitize_text_field($row['name']??'Item sem nome'));}}
        $next=$d[$kind==='formularios'?'next_offset':'next_cursor']??null;
        return array('ok'=>true,'linhas'=>$rows,'cursor'=>$next===null?'':base64_encode(wp_json_encode(array('kind'=>$kind,'revision'=>$d['connection_revision'],'next'=>$next))));
    }
    public static function estado(): array {
        $cfg=F3Base_Linkedin::config();$r=array('selecionado'=>$cfg['cliente']??'core','contrato'=>self::CONTRATO,'consumer_id'=>F3Base_Linkedin_Integracoes::consumer(),'connection_id'=>$cfg['connection_id']??'','fallback_automatico'=>false);
        if(self::externo()){$status=self::chamar('effective_status');$r['disponivel']=!empty($status['ok']);$r['codigo']=$status['codigo'];$r['autorizacao']=$status['data']??array();}else{$r['disponivel']=true;}$r['troca']='previa_e_transicao_explicita';return $r;
    }
    public static function pedir(string $method,string $path,array $data=array()): array {
        if(!self::externo()){unset($data['form_id']);return F3Base_Linkedin_Api::pedir($method,$path,$data);}
        if($method==='GET'&&preg_match('~^leadForms/([0-9]+)$~D',$path,$m)){$r=self::chamar('get_form',array('form_id'=>$m[1]));$r['data']=$r['data']['form']??array();return $r;}
        if($method==='GET'&&preg_match('~^leadFormResponses/([A-Za-z0-9_-]+)$~D',$path,$m)&&isset($data['form_id'])){$r=self::chamar('get_response',array('form_id'=>$data['form_id'],'response_id'=>$m[1]));$r['data']=$r['data']['response']['raw']??array();return $r;}
        return array('ok'=>false,'codigo'=>'operacao_requer_metodo_sdk_tipado');
    }
    public static function prazo(float $at): void {F3Base_Linkedin_Api::prazo($at);}
    public static function introspectar(array $cfg): array {if(!self::externo()){return F3Base_Linkedin_Api::introspectar($cfg);}$r=self::chamar('check_access');$r['escopo_comprovado']=!empty($r['ok'])&&empty($r['data']['forms_remaining']);$r['cobertura']=empty($r['data']['forms_remaining'])?'completa':'parcial';$r['leitura_de_respostas_testada']=false;return $r;}
    public static function coletar(): array {
        $cfg=F3Base_Linkedin::config();if(!F3Base_Recuperacao::entrar()){return array('ok'=>false,'codigo'=>'core_em_recuperacao');}$lock=F3Base_Trava::adquirir('linkedin-coleta:'.F3Base_Linkedin_Integracoes::id(),30);if(!$lock){F3Base_Recuperacao::sair();return array('ok'=>false,'codigo'=>'linkedin_coleta_ocupada');}
        $deadline=microtime(true)+20;$out=array();$next=time()+3600;
        try{
            $execution=F3Base_Linkedin_Integracoes::revisao_execucao();$status=self::chamar('effective_status');if(empty($status['ok'])){return $status;}$binding=array_intersect_key($status['data'],array_flip(array('credential_revision','grant_revision')));
            $state=F3Base_Linkedin_Integracoes::estado();$ids=F3Base_Linkedin::formularios($cfg);usort($ids,static fn($a,$b)=>(($state['cursores'][$a]['proxima']??0)<=>($state['cursores'][$b]['proxima']??0)));
            foreach($ids as $id){if(microtime(true)>$deadline-3){$next=time()+60;break;}$c=$state['cursores'][$id]??array('desde'=>time(),'ate'=>time(),'proxima'=>0);if(($c['proxima']??0)>time()){$next=min($next,$c['proxima']);continue;}
                $f=F3Base_Linkedin::formulario($id,$cfg);if(empty($f['ok'])){$out[$id]=$f;continue;}
                if(($c['vinculo']??null)!==$binding){unset($c['cursor_opaco'],$c['janela_inicio'],$c['janela_fim']);$c['vinculo']=$binding;}
                if(empty($c['janela_fim'])){$c['janela_inicio']=max((int)($c['desde']??time()),(int)($c['ate']??time())-600);$c['janela_fim']=min(time(),$c['janela_inicio']+30*DAY_IN_SECONDS);$c['versao']=(string)$f['formulario']['versionId'];}
                $input=$binding+array('form_id'=>(string)$id,'form_version'=>$c['versao'],'from_ms'=>(string)($c['janela_inicio']*1000),'to_ms'=>(string)($c['janela_fim']*1000),'test_only'=>false);if(!empty($c['cursor_opaco'])){$input['cursor']=$c['cursor_opaco'];}
                $r=self::chamar('read_responses',$input);$count=0;
                if(!empty($r['ok'])){
                    foreach($r['data']['responses']??array() as $one){$fresh=self::chamar('effective_status');
                        if(empty($fresh['ok'])||array_intersect_key($fresh['data'],$binding)!==$binding||F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution||!F3Base_Linkedin_Integracoes::liberada()||!F3Base_Trava::renovar($lock,30)){$r=array('ok'=>false,'codigo'=>'revision_conflict');break;}
                        if(microtime(true)>$deadline-2){$r=array('ok'=>false,'codigo'=>'pagina_nao_concluida');break;}
                        $accepted=F3Base_Linkedin::ingerir_resposta($one['raw']??array(),'consulta_periodica');if(empty($accepted['ok'])){$r=$accepted;break;}$count++;
                    }
                }
                $fresh=self::chamar('effective_status');if(empty($fresh['ok'])||array_intersect_key($fresh['data'],$binding)!==$binding||F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){return array('ok'=>false,'codigo'=>'revision_conflict');}
                if(!empty($r['ok'])){$c['cursor_opaco']=$r['data']['next_cursor']??null;$c['proxima']=time()+($c['cursor_opaco']?60:3600);if(!$c['cursor_opaco']){$c['ate']=$c['janela_fim'];unset($c['janela_inicio'],$c['janela_fim']);}$c['ultimo_sucesso']=time();$c['falhas']=0;}
                else{$c['falhas']=(int)($c['falhas']??0)+1;$c['proxima']=time()+max((int)($r['retry_after']??60),min(21600,60*2**min(8,$c['falhas'])));if(in_array($r['codigo']??'',array('cursor_expired','revision_conflict','cursor_invalid'),true)){unset($c['cursor_opaco'],$c['janela_inicio'],$c['janela_fim']);}}
                if(!F3Base_Trava::renovar($lock,30)){return array('ok'=>false,'codigo'=>'worker_reserva_perdida');}$saved=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($c,$id,$execution,$r){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){return null;}$s['cursores'][$id]=$c;if(!empty($r['ok'])){$s['leads_leitura_confirmada_em']=time();}return $s;});$out[$id]=empty($saved['persisted'])?array('ok'=>false,'codigo'=>'checkpoint_linkedin_falhou'):array('ok'=>!empty($r['ok']),'codigo'=>$r['codigo'],'itens'=>$count,'parcial'=>!empty($c['cursor_opaco']));$next=min($next,$c['proxima']);
            }
            return array('ok'=>!array_filter($out,static fn($r)=>empty($r['ok'])),'formularios'=>$out,'proxima'=>$next);
        }finally{F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();F3Base_Fila::agendar(F3Base_Linkedin::EVENTO,$next);}
    }
}
