<?php
/** Gerado por build/consumer-methods.php; não executa configuração no registro. */
if(!defined('ABSPATH')){exit;}
return [
'F3Base_Gsc'=>['defaults'=>array (
  'client' => NULL,
  'capabilities' => 
  array (
  ),
  'registro' => 'sdk_ausente',
),'register'=>static function($sdk,string $contract,array &$state):void{
if($contract!=='search-console-reader/1.0.0'){return;}$state['client']=null;$state['capabilities']=array();
        if($contract!=='search-console-reader/1.0.0'||!is_object($sdk)||!is_callable(array($sdk,'capabilities'))||!is_callable(array($sdk,'register_consumer'))){$state['registro']='contrato_incompativel';return;}
        try {
        $caps=$sdk::capabilities();if(!is_array($caps)||($caps['contract']??'')!=='search-console-reader/1.0.0'||!is_array($caps['capabilities']??null)||!in_array('gsc.page-day.read',$caps['capabilities'],true)){$state['registro']='capacidade_ausente';return;}if(!is_array($caps['client_methods']??null)||array_diff(array('effective_status','query'),$caps['client_methods'])){$state['registro']='diagnostico_sdk_indisponivel';return;}
        $client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,'search-console-reader/1.0.0',static fn()=>F3Base_Gsc::configuracao());
        if(!is_wp_error($client)&&(!is_object($client)||!is_callable(array($client,'effective_status'))||!is_callable(array($client,'query')))){$state['registro']='diagnostico_sdk_indisponivel';return;}if(is_wp_error($client)){$state['registro']=$client->get_error_code();return;}$state['client']=$client;$state['capabilities']=$caps;$state['registro']='registrado';
        } catch(Throwable $e){$state['client']=null;$state['registro']='sdk_incompativel';}
    
}],
'F3Base_Gsc_Consultas'=>['defaults'=>array (
  'client' => NULL,
  'capabilities' => 
  array (
  ),
  'registro' => 'sdk_ausente',
),'register'=>static function($sdk,string $contract,array &$state):void{
if($contract!=='search-console-reader/1.1.0'){return;}$state['client']=null;$state['capabilities']=array();
        if($contract!=='search-console-reader/1.1.0'||!is_object($sdk)||!is_callable(array($sdk,'capabilities'))||!is_callable(array($sdk,'register_consumer'))){$state['registro']='contrato_incompativel';return;}
        try {
        $caps=$sdk::capabilities();if(!is_array($caps)||($caps['contract']??'')!=='search-console-reader/1.1.0'||!is_array($caps['capabilities']??null)||!in_array('gsc.query-page-day.read',$caps['capabilities'],true)){$state['registro']='capacidade_ausente';return;}if(!is_array($caps['client_methods']??null)||array_diff(array('effective_status','query'),$caps['client_methods'])){$state['registro']='diagnostico_sdk_indisponivel';return;}
        $client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,'search-console-reader/1.1.0',static fn()=>F3Base_Gsc_Consultas::configuracao());
        if(!is_wp_error($client)&&(!is_object($client)||!is_callable(array($client,'effective_status'))||!is_callable(array($client,'query')))){$state['registro']='diagnostico_sdk_indisponivel';return;}if(is_wp_error($client)){$state['registro']=$client->get_error_code();return;}$state['client']=$client;$state['capabilities']=$caps;$state['registro']='registrado';
        } catch(Throwable $e){$state['client']=null;$state['registro']='sdk_incompativel';}
    
}],
'F3Base_Ga4'=>['defaults'=>array (
  'client' => NULL,
  'registro' => 'sdk_ausente',
  'caps' => 
  array (
  ),
),'register'=>static function($sdk,string $contract,array &$state):void{

        if($contract!=='ga4-reader/1.0.0'){return;}$state['client']=null;$state['registro']='contrato_incompativel';
        try{if(!is_object($sdk)||!is_callable(array($sdk,'capabilities'))){return;}$caps=$sdk::capabilities();if(($caps['contract']??'')!=='ga4-reader/1.0.0'||!in_array('ga4.report.read',$caps['capabilities']??array(),true)){return;}
            $client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,'ga4-reader/1.0.0',static fn()=>F3Base_Ga4::configuracao());if(is_wp_error($client)){$state['registro']=$client->get_error_code();return;}if(!is_object($client)||!is_callable(array($client,'query'))||!is_callable(array($client,'effective_status'))){return;}$state['client']=$client;$state['caps']=$caps;$state['registro']='registrado';
        }catch(Throwable $e){$state['registro']='sdk_incompativel';}
    
}],
'F3Base_Google_Acervo'=>['defaults'=>array (
  'client' => NULL,
),'register'=>static function($sdk,string $contract,array &$state):void{

        if($contract!=='google-ads-reader/1.0.0'||$state['client'])return;
        try{$caps=$sdk::capabilities();if(($caps['contract']??'')!=='google-ads-reader/1.0.0'||($caps['remote_calls']??null)!==false)return;$client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,'google-ads-reader/1.0.0',static fn()=>F3Base_Google_Acervo::configuracao());if(is_object($client)&&is_callable([$client,'query'])&&is_callable([$client,'status']))$state['client']=$client;}catch(Throwable $e){$state['client']=null;}
    
}],
'F3Base_Meta_Ads'=>['defaults'=>array (
  'client' => NULL,
  'registro' => 'sdk_ausente',
),'register'=>static function($sdk,string $contract,array &$state):void{

        if($contract!=='meta-ads-reader/1.0.0'||$state['client']){return;}
        if(!is_callable(array($sdk,'register_consumer'))){$state['registro']='sdk_incompativel';return;}
        try{$client=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,'meta-ads-reader/1.0.0',static fn()=>F3Base_Meta_Ads::configuracao(),'Fator3 Site Core — campanhas e contatos');if(!is_object($client)||!is_callable(array($client,'query'))||!is_callable(array($client,'status'))){$state['registro']='sdk_incompativel';return;}$state['client']=$client;$state['registro']='registrado';}catch(Throwable $e){$state['registro']='registro_indisponivel';}
    
}],
'F3Base_Meta_Monitoramento'=>['defaults'=>array (
  'client' => NULL,
),'register'=>static function($sdk,string $contract,array &$state):void{
if($contract!=='meta-ads-monitoring/1.0.0'||$state['client'])return;try{$c=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,'meta-ads-monitoring/1.0.0',static fn()=>F3Base_Meta_Monitoramento::configuracao(),'Core — alterações e qualidade de eventos');if(is_object($c)&&is_callable([$c,'query'])&&is_callable([$c,'status']))$state['client']=$c;}catch(Throwable $e){$state['client']=null;}
}],
];
