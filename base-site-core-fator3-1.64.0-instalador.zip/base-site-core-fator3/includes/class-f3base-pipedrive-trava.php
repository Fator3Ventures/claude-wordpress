<?php
/** Pipedrive SDK support; loaded only when used. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Trava {
    private static int $depth=0;
    private static string $connection='';
    private static function nome(): string {global $wpdb;return 'f3pd:'.substr(hash('sha256',DB_NAME.'|'.$wpdb->prefix),0,48);}
    public static function protegida(string $nome): bool {return in_array($nome,array('f3base_pipedrive','f3base_pipedrive_token','f3base_pipedrive_estado','f3base_pipedrive_operacao'),true);}
    public static function atual(): bool {global $wpdb;return self::$depth>0&&(string)$wpdb->get_var('SELECT CONNECTION_ID()')===self::$connection&&(string)$wpdb->get_var($wpdb->prepare('SELECT IS_USED_LOCK(%s)',self::nome()))===self::$connection;}
    public static function executar(callable $fn) {
        global $wpdb;
        if(self::$depth){if(!self::atual()){return null;}++self::$depth;try{return $fn();}finally{--self::$depth;}}
        if((string)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',self::nome()))!=='1'){return null;}
        self::$connection=(string)$wpdb->get_var('SELECT CONNECTION_ID()');self::$depth=1;
        try{return self::atual()?$fn():null;}finally{self::$depth=0;$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',self::nome()));self::$connection='';}
    }
}

/** Última observação oficial por credencial/conta; nunca deduz saldo do contador local. */
