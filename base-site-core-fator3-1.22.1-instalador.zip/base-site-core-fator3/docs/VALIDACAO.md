# Validação 1.22.1

Ambiente local: WordPress 7.1.2, PHP 8.3.6, MariaDB 10.11.14. Dados sintéticos com a forma descrita no relatório de produção. Nenhuma chamada real a Pipedrive, Google, Clarity ou SMTP; transportes substituídos por respostas controladas.

- **21 scripts PHP**, todos com saída zero: configuração sem alteração, procedência e falhas de persistência, mapas e apresentação, operação/jornada, avisos, CRM, reconciliação, atividade, executor sob falhas, serviços, GSC/cache e SDK opcional, contexto administrativo, Clarity, credenciais e regressões da conferência.
- **Processos concorrentes reais** (CLI, cron HTTP e manual): uma ocorrência e um efeito; origens separadas. Uma observação em espera não gera nova linha de tarefa; a passagem continua registrada.
- **Recuperação em processos separados**: sentinela ausente, inválida, pausada, trava ocupada e recriação com pausa contínua. Documentação acessível com permissão e bloqueada ao anônimo.
- **Instalação e atualização**: WordPress limpo; fonte real 1.21.0; fonte publicado 1.22.0 provocando a falha NULL, seguido de 1.22.1. 130 contatos em cada cenário de atualização e validação em nova requisição.
- **PHP e assets**: lint de todos os PHP; build minificado reprodutível; testes JavaScript/DOM em jsdom 26.1.0 para renovação de contexto e seletores de moeda, sem armazenamento de segredos no navegador.
- **Renderização PHP**: configuração, operação, técnica com tokens presentes, integração e contato. Não é homologação visual em navegador real.

Evidências e scripts no ZIP de fontes, em `suite/versao-1221/`. Diretórios de versões anteriores contêm somente evidência histórica e não substituem essa rodada. `execucao-resultados.json` lista os 21 resultados, `falhas-1221.json` cobre preparação mínima, exceção anterior à reserva e restauração de endereço, `verificacao-crm.json` cobre timeout/catálogos/mapa legado e 401.

O instalador final deve passar por extração, comparação de manifesto e pelos três ciclos acima antes da entrega; a prova do ZIP fechado acompanha o relatório externo e o fonte. O resultado não comprova entrega de e-mail ao destinatário, funcionamento da conta Pipedrive/Clarity real, acesso de visitantes nem implantação na frota.

Aceites restantes e limites estão detalhados por letra em ENTREGA-1.22.1.md. Não foi testado ou alterado korvena.net.br nem qualquer outro site da frota.
