# Pipedrive — Core 1.22.0

## Ativação

A integração vem desligada. Em **Contatos → Integrações → Pipedrive**, configure o domínio da empresa (somente `empresa.pipedrive.com`), responsável, etiqueta opcional, unidade, campos comerciais, mapas de alternativas e credencial. O token fica cifrado no servidor; campo vazio mantém o valor e apagar é explícito. Salvar agenda a verificação da identidade da conta e dos catálogos de usuários, etiquetas, atividades e campos. Nenhum campo, funil ou usuário é criado pelo pacote.

A verificação fica vinculada às revisões da configuração e da credencial. Trocar ou apagar o token invalida imediatamente essa prova e os catálogos. Entrega e eliminação remota aguardam nova verificação; uma consulta em andamento não pode certificar a nova credencial usando respostas da anterior. Cada lote conserva seu próprio contexto e para antes da chamada seguinte quando ele muda. Uma chamada já enviada pode ter sido executada: seus IDs e checkpoints continuam sujeitos à conciliação.

Os seletores mostram as chaves/tipos encontrados na conta. Serviço exige campo de seleção múltipla (`set`); os demais mapas devem usar os tipos validados. Os valores dos mapas são IDs de alternativas, não rótulos traduzidos. Use `formulario_id:valor` quando dois formulários usam o mesmo texto para serviços diferentes. `unidade` é o ID da alternativa da unidade deste site. `atividade_tipo` deve existir no catálogo; a atividade inicial é opcional.

Ative o módulo somente após conferir a conta e o mapeamento. Cada formulário tem checkbox próprio de envio ao Pipedrive (true por padrão, subordinado ao módulo global), papéis nome/e-mail/telefone/empresa/cargo/serviço/LinkedIn e serviço fixo opcional. Desativar o checkbox exclui novas capturas desse formulário. Integração não retroenvia histórico. Cliques anônimos, spam e capturas não aceitas ficam fora. Contato aceito com nome pode criar pessoa mesmo sem identificador; não se pesquisa pessoa por nome.

Consulte a prévia privada `f3base/pipedrive-previa` com `record_id`. A autorização de coleta/contato e o aviso de privacidade são responsabilidade da operação do site. A prévia não envia dados. Homologação real ainda é pré-requisito de ativação: veja os limites de evidência em VALIDACAO.md.

## O que é enviado

| Destino | Dados e regra |
|---|---|
| Organização | Busca exata pelo nome informado; cria quando não existe. Não modifica organização existente. Ambiguidade suspende. |
| Pessoa | Busca cada identificador válido: e-mail, telefone E.164 e LinkedIn no campo de pessoa mapeado, com releitura por ID. Identificadores em pessoas diferentes exigem revisão. Completa somente identificadores ausentes; preserva valores e etiquetas existentes. Nova pessoa recebe etiqueta opcional e é confirmada pelo ID retornado, sem depender do índice de pesquisa. Cargo fica na nota e no campo comercial opcional; não depende de `job_title` restrito por contact sync. |
| Oportunidade | Reutiliza somente lead aberto de autoria comprovada da mesma instalação (journal local + origin_id relido). Negócios e leads de outra origem não bloqueiam a criação de lead próprio; nos diários operacionais ficam somente tipo/ID, sem título ou dados pessoais. Mais de um lead próprio exige revisão. Reutilização acrescenta nota, sem reescrever campos comerciais anteriores. |
| Campos comerciais | Site/host canônico; unidade do site; canal da plataforma; parceiro da convenção da campanha; ponto nativo/site/whatsapp_formulario; serviços; campanha; anúncio/criativo; cargo opcional. Mapeamento vinculado à conta, sem IDs fixos universais. |
| Nota | Identificação do registro/formulário, campos enviados, página sem query, atribuição permitida, qualidade e jornada observada. HTML escapado e limite de tamanho. Link para o detalhe privado no WordPress. |
| Atividade | Primeiro contato, quando habilitada e oportunidade nova; etapa separada para evitar repetir nota ao retomar tarefa. |

A convenção de campanha é `unidade_parceiro_objetivo_AAAAMM`. O parceiro é procurado no mapa; campanha fora do padrão ou parceiro desconhecido fica visível em `journal.qualidade` e na nota. Ausência de medição não prova origem orgânica: a qualidade declara ausência/recusa/revogação. Um mapa vazio não adivinha valores. Nas fontes que não entregam nome de campanha, configure `mapeamento.campanhas` por ID na origem nativa.

A projeção usa até 500 eventos e 100 cliques anteriores à captura, da mesma sessão e classe de tráfego e dentro da retenção disponível. Falta de vínculo ou consentimento é sinalizada; não junta por IP, e-mail ou similaridade. Eventos de análise, comportamento e cliques têm fontes diferentes e não equivalem a pessoas únicas. Testes ficam fora por padrão; modo explícito de homologação permite apenas fluxo sintético marcado. Formulários nativos não têm jornada web inventada.

IP e user agent disponíveis entram nos dados técnicos da nota, conforme autorização do dono. Não são enviados cookies, fbc/fbp, oppref, click IDs, anexos ou URLs privadas. A atribuição publicitária elegível é reduzida pelo consentimento vigente; não identifica pessoas. Consentimento é reavaliado no despacho da nota; revogação reduz dados de medição/publicidade. Retirada posterior à entrega exige procedimento de eliminação, não apaga automaticamente a cópia remota.

## Fila e operação

A captura grava intenção durável no próprio lead. A fila contém referências, IDs remotos e checkpoints, sem copiar o corpo do contato. Cron/loopback processa até dez itens por rodada, com orçamento de 20 segundos; formulário não espera o CRM. Se WP-Cron estiver desabilitado, configure executor externo. E-mail e CRM possuem estados independentes.

Estados efetivos incluem `pendente`, `enviando`, `entregue`, `suspenso`, `falhou`, `incerto`, `revisao`, `cancelando` e `cancelado`. Posse temporária dura 120 segundos. Entrega só termina após etapas obrigatórias e releitura dos campos comerciais da nova oportunidade. A API v1 recebe Serviço como string de IDs separados por vírgulas, e a releitura normaliza a representação antes da comparação. Homologue esse contrato na conta real antes de ativar.

Uma execução inicial e até seis retentativas de falha transitória usam 1, 5, 15, 60, 180 e 720 minutos, com jitter. Pausas por credencial/orçamento não consomem tentativas. 429 respeita Retry-After. Resposta perdida após POST fica incerta e é conciliada antes de qualquer nova criação. Checkpoint persistido impede repetir etapas concluídas. Reenvio exige revisão atual e é recusado quando incompatível com o estado.

Contatos → Integrações → Entregas mostra estado, motivo, tentativas, próxima execução e etapas. No detalhe do contato, `crm.pipedrive` traz IDs e resultado. Abilities: `integracoes-ler`, `pipedrive-verificar` (somente leitura), `integracoes-verificar-agora` (consulta conta e atualiza catálogos), `pipedrive-processar` (pode enviar), `pipedrive-reenviar` (revisão/simulação), `pipedrive-previa` (dados privados). Leia o schema instalado antes de executar.

Orçamento diário **local** limita o consumo desta instalação e reinicia em UTC. Não é a cota restante global da empresa. Cabeçalhos de limite observados podem pausar o executor. Várias instalações não compartilham trava nem orçamento; a revisão posterior detecta ambiguidades observadas, mas não garante criação exatamente única entre sites. Não configurar duas origens para importar a mesma conta/formulário sem uma autoridade definida.

Os campos esperados do lead têm suas chaves e hash registrados antes do POST, sem guardar o conteúdo comercial no diário. Se a resposta se perder, a retomada localiza a oportunidade pelo marcador e relê os campos; divergência suspende a entrega antes de acrescentar nota/atividade. Catálogo vazio de alternativas não valida IDs configurados.

## Eliminação e retenção

Expiração por retenção local cancela despachos futuros e não apaga atividade comercial no CRM. Eliminação explícita a pedido primeiro cancela a fila e marca recibos nativos; só então remove o contato local. A limpeza externa tem estado próprio e pode permanecer pendente.

Notas/atividades próprias são removidas apenas com ID, marcador e hash compatível. Lead/pessoa criados exclusivamente pelo Core só são candidatos se permanecem inalterados, sem vínculo comercial independente e com prova suficiente. Organização, entidade preexistente, oportunidade compartilhada/convertida/editada ou prova incompleta ficam preservadas e exigem revisão comercial. Não se declara eliminação remota concluída ao apagar apenas o registro local. IDs mínimos e hashes permanecem para conclusão e auditoria; não são expostos publicamente.

Histórico técnico de entregas é compactado após 30 dias por padrão (7–90 configurável); recibos/etapas necessários à conciliação e eliminação pendente permanecem. Tombstones de origem nativa duram 90 dias e o marco de ingestão evita recriação fora da janela. Troca de conta não reinterpreta IDs antigos; suspense e reconciliação são explícitos.

## Exemplo da conta informado pelo dono

Referência fornecida no plano, **não verificada por esta entrega e não aplicada como default**. Confirme IDs na conta de destino, especialmente em sandbox, onde serão diferentes.

| Papel | Chave / exemplos fornecidos |
|---|---|
| Responsável / etiqueta | 24617815 / 77570ba0-b933-11f1-9be3-955dbf3be411 |
| Unidade | a6856374537cc03694d68f8a242b083fc20d0e2c; fator3=44, ctooffice=45, korvena=46 |
| Canal | 53bf9d1b48b76933f8b5cead0fb07112d064961a; Meta=80, LinkedIn=81, Google=82, OpenAI Ads=83, não identificada=85 |
| Parceiro | c980b55160e74cd39d67a1666e65e750011c2b3a; apex=47, saask=48, datta=49, interno=50, sem_campanha=51 |
| Ponto | cd1662eaac4c279d069f158256289c5d72b8e854; nativo=52, site=53, whatsapp_formulario=54 |
| Serviço | 5a81949e986c3f117cc748791e72a0f3c0d24e9e; opções 89–96 conforme catálogo da conta |
| Campanha | c3a9451e31d91c3002155884d68c68f67cf7fcfa |
| Anúncio | 0017e916e1b899c61a97452e23aede3d7a01db22 |

Documentação primária: https://developers.pipedrive.com/docs/api/v1/Persons ; https://developers.pipedrive.com/docs/api/v1/Leads ; https://developers.pipedrive.com/docs/api/v1/Notes ; https://developers.pipedrive.com/docs/api/v1/Activities . Adaptadores atuais usam v2 para pessoas/organizações/atividades/negócios/campos e v1 para leads/notas/catálogos que mantêm esse contrato. Rota alterada/ID removido suspende com motivo, sem fallback cego.

## Configuração e mapas

- `modelo_titulo`: variáveis empresa, nome, servicos, formulario, site. Vazio usa empresa/nome — serviços/formulário · host. Teto de 255 caracteres preserva host e marca de teste; não retitula lead reutilizado.
- `mapa_campos.site`: texto recebe host; seleção única exige `site_alternativa` conferida no catálogo. Nunca copiar IDs de outro site como padrão.
- `rotulo_pessoa`: etiqueta apenas novas pessoas. É catálogo de pessoa, separado da etiqueta de lead.
- `mapa_pessoa.linkedin`: chave de campo textual de pessoa. HTTP/HTTPS, www e subdomínio de país são normalizados para https://www.linkedin.com/in/perfil; query e fragmento saem. Hosts falsos/rotas que não são perfil pessoal ficam fora da identidade.
- `mapa_respostas`: objeto por ID de formulário e nome estável de campo. Texto ou seleção simples/múltipla conforme catálogo. Alternativas são IDs existentes. Colisões no mesmo destino/formulário são recusadas. Valores sem mapa ficam na nota e em qualidade.
- `mapa_parceiros`: aceita `sem_campanha`, `fora_do_padrao` e `origem_nao_observada` como alternativas configuradas. Isso não comprova origem orgânica.

A prévia mostra elegibilidade/motivo, identificadores, título, host, campos, nota e qualidade. Não consulta nem grava no CRM. PATCH de pessoa usa leitura antes/depois, preenchendo ausências; API sem compare-and-swap não permite prometer exclusão mútua entre vários sites e operadores remotos.

## Atividade, alertas e reconciliação na 1.22

Atividade v2 envia `participants: [{person_id, primary: true}]`, `lead_id`, owner/tipo e `due_date` no fuso WordPress. A releitura confere o vínculo. Pessoa, lead e nota confirmados são o núcleo entregue: atividade recusada/incerta mantém esse núcleo e tem estado próprio em `journal.atividade_estado` (pendente, confirmada, recusada, incerta ou dispensada quando desligada). Retomada automática de pendente/incerta é limitada a três passagens e procura o marcador antes de novo POST. `pipedrive-atividade-reparar` permite reiniciar só essa etapa, com revisão/simulação.

Episódios de alerta têm causa e ação específicas. A mesma causa aberta não gera novo episódio ao reagendar; resolução fecha o episódio e recorrência efetiva pode gerar outro. Falha de transporte recebe até três tentativas progressivas; resultado incerto exige conferência. Aviso de conta depende de contato elegível aguardando verificação, pelo menos duas passagens e cinco minutos de graça. Diagnóstico expõe essa observação.

`f3base/pipedrive-reconciliar` aceita ações pessoa, lead e email_alternativo. A prévia faz GETs e retorna revisão local e prova remota. Aplicar exige as duas provas, `confirmar: true` e administração. Pessoa sem identificador após resposta perdida requer seleção administrativa por ID e nome compatível, sem pesquisa/união automática por nome. Mais de um lead próprio exige seleção explícita; lead arquivado é inelegível. Dados de terceiros não autorizam apropriar a oportunidade.

E-mail diferente permanece na nota. Acrescentar à pessoa exige `adicionar_email_alternativo: true`, referência comprovada por outro identificador, busca de colisão, releitura antes/depois e preservação do principal/demais endereços. A API não fornece CAS distribuído: operador remoto ainda pode concorrer. Divergência é revisão, não sucesso presumido.

País `BR` é persistido em instalação e upgrade quando ausente/vazio; números nacionais completos são normalizados para +55 antes da pesquisa/comparação. Número sem DDD não ganha região presumida. Outro país válido explícito é preservado. O contato conserva o valor digitado. LinkedIn aceita perfil pessoal em host real com variantes móveis/locais/Unicode; empresa, host semelhante e barra codificada são recusados como identidade. Sem campo de pessoa, perfil fica na nota.

No mapa de respostas, número/monetário exige formato `decimal_ponto` ou `decimal_virgula`, sem separador de milhar; monetário exige moeda ISO de três letras. Data exige Y-m-d ou d/m/Y e calendário válido. Seleção única com múltiplas respostas é omitida do campo, com qualidade e respostas integrais na nota. Limite de texto usa catálogo quando disponível; fallback documentado: 255 caracteres em varchar/varchar_auto, 65535 em text. Corte Unicode é sinalizado. Opcionais inválidos (como Site) são omitidos com qualidade; não tornam a conta inteira inválida.

A tela oferece seletores de formulário, resposta, destino e alternativas, com JSON técnico preservado. Catálogo incompleto aparece pendente; prévia não adivinha tipo. Etiquetas só são comprovadas na criação; mudanças posteriores de operador não suspendem retroativamente a entrega.

Token candidato é verificado por GET v1/users/me antes de ser aceito, inclusive em simulação. Campo intocado não é verificado ao salvar GTM; apagar é explícito e dispensa autenticar com a credencial apagada. Identidade confirmada não liga integração nem substitui verificação dos catálogos. Timeout, 429 e resposta sem identidade deixam “não verificado” e preservam o segredo atual.

Notas históricas não são editadas em massa. Reparo seletivo de suspensões elegíveis usa cursor estável e registra motivo de cada item pulado. Restauração mantém efeitos externos incertos/suspensos até reconciliação. Homologação em conta real e renderização da nota no Pipedrive não foram feitas nesta entrega.
