# Fator3 Site Core 1.22.1

Instale o ZIP instalador em WordPress novo ou atualize a partir da **1.21.0 concluída** ou da **1.22.0**, inclusive interrompida em `diarios_sanitizados`. O ZIP de fontes é para desenvolvimento. Não há downgrade implementado.

Esta versão corrige o bloqueio da migração e os problemas descritos no relatório de conferência da 1.22.0. A migração é dividida em lotes, mantém valores NULL/vazios/inválidos e preserva a procedência das configurações válidas. Configuração antiga fora do contrato é preservada e diagnosticada.

Leia [ENTREGA-1.22.1.md](ENTREGA-1.22.1.md) para a resposta **por letra**, os testes e os limites. [RELEASE-1.22.1.md](RELEASE-1.22.1.md) documenta instalação, novos comportamentos e contratos. [VALIDACAO.md](VALIDACAO.md) distingue testes locais de homologação nas contas reais.

Documentação instalada em `docs/`, também acessível por `f3base/documentacao-ler`, inclusive no modo de recuperação. Os documentos de versões anteriores são históricos e não substituem a matriz desta entrega. MCP, MCP Google, tema e implantador não foram alterados.

O token Clarity fica em Configurações → Medição e anúncios → Clarity: campo secreto, estado e projeto vinculado; botão **Testar token e coletar agora**, compartilhando o limite diário da integração. Nunca envie o token ao agente.
