> Versão atual: **1.22.1**. Leia [RELEASE-1.22.1.md](RELEASE-1.22.1.md) e a matriz por letra em [ENTREGA-1.22.1.md](ENTREGA-1.22.1.md).

# Documentação instalada — Fator3 Site Core 1.22.0

Índice estável em `wp-content/plugins/base-site-core-fator3/docs/DOCUMENTACAO.md`. Por canal autenticado, execute `f3base/documentacao-ler` sem argumentos. Para leitura paginada, use `arquivo`, `linha` e `limite` (máximo 200); o retorno identifica SHA-256 e próxima linha. Exige `manage_options`, mesmo em recuperação. Não habilita módulos de negócio para oferecer leitura.

| Documento | Finalidade |
|---|---|
| RELEASE-1.22.md | Instalação, migração e mudanças efetivas |
| AGENTES-1.22.md | Operação, consultas, permissões e exemplos |
| PROCEDENCIA-1.22.md | Complementação, revisões e reparo comprovado da 1.21 |
| OPERACAO-1.22.md | Recuperação, cron, ocorrências e limites do GSC |
| CLARITY-1.22.md | Cadastro humano do token, teste com cota e primeira coleta |
| PIPEDRIVE.md | Configuração, identidade, mapas, atividade e reconciliação |
| CONTATOS-1.22.md | Jornada, apresentação, consentimento e CSV |
| CONTRACTS.md | Contratos e semântica de respostas |
| dados/configuracao-schema.json | Schemas/padrões declarativos gerados, sem valores do site |
| dados/abilities-*.json | Registro executável das abilities da instalação ativa |
| AJUDA-OPCOES.md / dados/ajuda-opcoes.json | Ajuda efetiva das opções, gerada do código |
| REFERENCIA-CATALOGO.md | Descrições executáveis dos módulos |
| DICIONARIO-DADOS.md / dados/contrato.json | Relações, tabelas e semântica dos dados |
| CONSULTAS-EXEMPLO.sql | Exemplos de leitura; nunca escrever nas tabelas pelo canal |
| CONFIGURACAO.md / LEADS-E-FORMULARIOS.md | Recursos preservados de configuração e formulários |
| MEDICAO-1.19.md / RELATORIOS.md / METRICAS.md | Recursos preservados de medição e fórmulas |
| ANALISAR-CONTEUDO-ORGANICO.md / ANALISAR-PRESENCA-IA.md | Análise de audiência e IA, com limites de observação |
| ORIGENS-ANUNCIOS.md / CRUZAMENTOS-PUBLICIDADE.md | Atribuição web e cruzamentos por IDs |
| IMPACTO-1.22-MCP.md / IMPACTO-1.22-GOOGLE.md | Encaminhamentos finais aos outros plugins |
| VALIDACAO.md / ENTREGA-1.22.md | Provas locais, rastreabilidade e homologação externa pendente |
| CHANGELOG.md | Histórico de versões |

**Precedência:** guias 1.22, schemas gerados e PIPEDRIVE.md descrevem a versão atual. Arquivos com versões anteriores no nome são históricos de recursos preservados; não autorizam outro caminho de instalação. A chave `documentacao` é estável; `documentacao_1210` permanece como transição documental nesta atualização. Não inferir autorização pelo texto humano, usar permissões e schema.

Versões: pacote 1.22.0; contrato/configuração 5.2.0; dicionário de dados 5.2.0; tabela de leads schema 6; política MCP 1; SDK Google search-console-reader/1.0.0. O endpoint chamado `config-core-contrato-v1` conserva o nome do serviço; leia `contract_version` no conteúdo.

A proteção HTTP dos documentos distribuída depende de Apache/AllowOverride compatível; Nginx exige regra equivalente da hospedagem. Documentação não contém credenciais. Dados privados de contatos e exportações exigem suas próprias permissões.
