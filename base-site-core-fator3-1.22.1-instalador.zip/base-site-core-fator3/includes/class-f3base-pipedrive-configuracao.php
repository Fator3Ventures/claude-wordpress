<?php
/** Configuração comercial declarativa. Catálogos locais não fazem consultas externas. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Pipedrive_Configuracao {
    public static function rotulos(): array {return array('pais_telefone'=>'País dos telefones nacionais','modelo_titulo'=>'Modelo do título do lead','site_alternativa'=>'Site — ID da alternativa','rotulo_pessoa'=>'Etiqueta das novas pessoas','mapa_pessoa'=>'Campos de pessoa (LinkedIn)','mapa_respostas'=>'Respostas por formulário → campos de lead');}
    public static function ajuda(): array {return array('pais_telefone'=>'Brasil (+55) na instalação e atualização. Usado apenas em números nacionais completos; nunca acrescenta DDD. Valores internacionais com + preservam o país.','modelo_titulo'=>'Opcional. Variáveis: {empresa}, {nome}, {servicos}, {formulario}, {site}. Vazio: empresa ou nome — serviços ou formulário · host. Não retitula lead reutilizado. O host e a marca de teste são preservados no limite de 255 caracteres.','site_alternativa'=>'Somente se mapa_campos.site aponta para seleção única. Informe o ID da alternativa desta instalação. Campo de texto recebe o host canônico automaticamente.','rotulo_pessoa'=>'Etiqueta apenas a pessoa criada por este contato. Pessoas existentes conservam todas as etiquetas.','mapa_pessoa'=>'Opcional: objeto {"linkedin":"chave de campo de pessoa"}. Vazio usa automaticamente um único campo textual chamado LinkedIn, Perfil LinkedIn ou URL LinkedIn no catálogo da conta. Sem campo ou com mais de um candidato, configure explicitamente; o perfil permanece na nota e não se torna identificador. O catálogo de pessoa é separado do catálogo de negócio. Perfil inválido permanece na nota e não é usado em busca.','mapa_respostas'=>'Objeto por ID do formulário e nome estável: {"contato":{"interesse":{"campo":"chave CRM","alternativas":{"consultoria":"12"}}}}. Texto dispensa alternativas. Número e moeda exigem formato decimal_ponto ou decimal_virgula (sem milhar); monetário exige moeda ISO. Data exige Y-m-d ou d/m/Y. Valores sem mapa ficam na nota, com diagnóstico de qualidade.','mapa_parceiros'=>'Código do parceiro → ID. Chaves reservadas: sem_campanha (origem observada sem campanha), fora_do_padrao (campanha ou parceiro fora da convenção) e origem_nao_observada (sem informação por consentimento/retenção). Exemplo: {"sem_campanha":"1","fora_do_padrao":"2","origem_nao_observada":"3"}. Ausência de informação não comprova visita orgânica.');}
    public static function validar_entrada(array $c): string {
        foreach($c['mapa_pessoa']??array() as $role=>$key){if($role!=='linkedin'||!is_string($key)||!preg_match('/^[a-f0-9]{40}$/D',$key)){return 'mapa_pessoa: use linkedin e a chave de um campo de pessoa.';}}
        if(preg_match_all('/\{([^}]+)\}/',$c['modelo_titulo']??'',$m)&&array_diff($m[1],array('empresa','nome','servicos','formulario','site'))){return 'modelo_titulo: variável desconhecida.';}
        $used=array_values($c['mapa_campos']??array());if(count($used)!==count(array_unique($used))){return 'mapa_campos: dois papéis não podem escrever no mesmo campo.';}
        foreach($c['mapa_respostas']??array() as $form=>$map){if(!is_array($map)){return 'mapa_respostas: informe objeto por formulário.';}$keys=$used;foreach($map as $name=>$v){if(!is_array($v)||array_diff(array_keys($v),array('campo','alternativas','formato','moeda'))||!preg_match('/^[a-f0-9]{40}$/D',(string)($v['campo']??''))||in_array($v['campo'],$keys,true)){return 'mapa_respostas: campo inválido ou colisão no formulário '.$form.'.';}$keys[]=$v['campo'];if(isset($v['alternativas'])&&!is_array($v['alternativas'])){return 'mapa_respostas: alternativas precisam ser um objeto.';}foreach($v['alternativas']??array() as $id){if(!is_scalar($id)||!ctype_digit((string)$id)||(int)$id<1){return 'mapa_respostas: ID de alternativa inválido.';}}}}
        foreach($c['mapa_parceiros']??array() as $key=>$id){if(!preg_match('/^[a-z0-9_-]+$/D',(string)$key)){return 'mapa_parceiros.'. $key .': use código sem espaços.';}}
        foreach($c['mapa_respostas']??array() as $form=>$map){foreach($map as $name=>$v){if(isset($v['formato'])&&!in_array($v['formato'],array('decimal_ponto','decimal_virgula','Y-m-d','d/m/Y'),true)){return 'mapa_respostas.'.$form.'.'.$name.'.formato: conversão desconhecida.';}if(isset($v['moeda'])&&!preg_match('/^[A-Z]{3}$/D',(string)$v['moeda'])){return 'mapa_respostas.'.$form.'.'.$name.'.moeda: use código ISO de três letras.';}}}
        return '';
    }
    public static function rotulos_pessoa(array $cat): array {foreach($cat['pessoa_campos']??array() as $f){if(in_array($f['key']??$f['field_code']??'',array('label','label_ids'),true)){return $f['options']??array();}}return array();}
    public static function validar_catalogo(array $c,array $cat): string {
        $error=self::validar_entrada($c);if($error){return $error;}$fields=array();foreach($cat['campos']??array() as $f){$fields[$f['field_code']??$f['key']??'']=$f;}
        if(!empty($c['rotulo_pessoa'])&&!in_array((string)$c['rotulo_pessoa'],array_map('strval',array_column(self::rotulos_pessoa($cat),'id')),true)){return 'rotulo_pessoa_nao_confirmado';}
        $person=array();foreach($cat['pessoa_campos']??array() as $f){$person[$f['key']??$f['field_code']??'']=$f;}foreach($c['mapa_pessoa']??array() as $role=>$key){if(!isset($person[$key])||!in_array($person[$key]['field_type']??'',array('varchar','text','varchar_auto'),true)){return 'campo_pessoa_nao_confirmado:'.$role;}}
        foreach($c['mapa_respostas']??array() as $form=>$map){$def=F3Base_Formularios::obter((string)$form);foreach($map as $name=>$v){$f=$fields[$v['campo']]??null;if(!$f||!in_array($f['field_type']??'',array('varchar','text','varchar_auto','enum','set','double','monetary','date'),true)){return 'tipo_resposta_incompativel:'.$name;}if(!$def||!in_array((string)$name,array_column($def['campos'],'nome'),true)){return 'campo_formulario_nao_confirmado:'.$name;}if(in_array($f['field_type'],array('double','monetary'),true)&&!in_array($v['formato']??'',array('decimal_ponto','decimal_virgula'),true)){return 'formato_numerico_obrigatorio:'.$name;}if($f['field_type']==='monetary'&&empty($v['moeda'])){return 'moeda_obrigatoria:'.$name;}if($f['field_type']==='date'&&!in_array($v['formato']??'',array('Y-m-d','d/m/Y'),true)){return 'formato_data_obrigatorio:'.$name;}$source=null;foreach($def['campos'] as $item){if($item['nome']===$name){$source=$item;break;}}$sourceOptions=array_map(static fn($x)=>is_array($x)?(string)($x['valor']??$x['value']??''):(string)$x,$source['opcoes']??array());foreach($v['alternativas']??array() as $value=>$id){if($sourceOptions&&!in_array((string)$value,$sourceOptions,true)){return 'alternativa_origem_nao_confirmada:'.$name;}}$opts=array_map('strval',array_column($f['options']??array(),'id'));foreach($v['alternativas']??array() as $id){if(!in_array((string)$id,$opts,true)){return 'alternativa_resposta_nao_confirmada:'.$name;}}}}
        return '';
    }
    public static function titulo(array $ctx,array $cfg): string {
        $host=(string)$ctx['site'];$vars=array('empresa'=>$ctx['empresa']?:$ctx['nome']?:'Contato','nome'=>$ctx['nome'],'servicos'=>implode(', ',(array)$ctx['servicos']),'formulario'=>$ctx['formulario'],'site'=>$host);$model=$cfg['modelo_titulo']??'';
        if($model===''){$model='{empresa} — '.($vars['servicos']!==''?'{servicos}':($vars['formulario']!==''?'{formulario}':'Contato'));}
        $prefix=!empty($ctx['teste'])?'[TESTE F3BASE] ':'';
        $hasSite=str_contains($model,'{site}');$pieces=explode('{site}',$model,2);
        $expand=static fn($text)=>preg_replace_callback('/\{([^}]+)\}/u',static fn($m)=>$vars[$m[1]]??'',$text);
        $left=$expand($pieces[0]);$right=$hasSite?$expand($pieces[1]):'';
        $budget=max(0,255-mb_strlen($prefix.$host)-($hasSite?0:3));
        if(mb_strlen($left.$right)>$budget){$left=mb_substr($left,0,max(0,$budget-mb_strlen($right)));$right=mb_substr($right,0,max(0,$budget-mb_strlen($left)));}
        if($hasSite){return trim($prefix.$left.$host.$right);}
        $left=preg_replace('/^[\s·—-]+|[\s·—-]+$/u','',$left);
        return $prefix.$left.' · '.$host;
    }
    public static function campos(array $ctx,array $cfg): array {
        $cat=get_option('f3base_pipedrive_estado',array())['catalogos']??array();$fields=array();foreach($cat['campos']??array() as $f){$fields[$f['field_code']??$f['key']??'']=$f;}$out=array();$quality=array();
        if(!empty($cfg['mapa_campos']['site'])){$key=$cfg['mapa_campos']['site'];$f=$fields[$key]??array();$type=$f['field_type']??'';
            if(in_array($type,array('varchar','text','varchar_auto'),true)){$out[$key]=$ctx['site'];}
            elseif($type==='enum'&&in_array((string)($cfg['site_alternativa']??''),array_map('strval',array_column($f['options']??array(),'id')),true)){$out[$key]=(string)$cfg['site_alternativa'];}
            else{$quality[]='campo_site_omitido';}
        }
        foreach($cfg['mapa_respostas'][$ctx['formulario_id']]??array() as $name=>$map){
            $v=$ctx['campos'][$name]??null;if($v===null||$v===''){continue;}$key=$map['campo'];$f=$fields[$key]??array();$type=$f['field_type']??'';
            if(!$f){$quality[]='catalogo_pendente:'.$name;continue;}
            $values=is_array($v)?array_values($v):array($v);
            if(in_array($type,array('enum','set'),true)){
                if($type==='enum'&&count($values)>1){$quality[]='selecao_unica_ambigua:'.$name;continue;}
                $ids=array();$allowed=array_map('strval',array_column($f['options']??array(),'id'));
                foreach($values as $value){$id=is_scalar($value)?(string)($map['alternativas'][(string)$value]??''):'';if($id!==''&&in_array($id,$allowed,true)){$ids[]=$id;}else{$quality[]='alternativa_sem_mapa:'.$name;}}
                if($ids){$out[$key]=$type==='enum'?$ids[0]:implode(',',array_unique($ids));}continue;
            }
            if(in_array($type,array('double','monetary','date'),true)){
                if(count($values)!==1||!is_scalar($values[0])){$quality[]='valor_ambiguo:'.$name;continue;}$raw=trim((string)$values[0]);$format=$map['formato']??'';
                if($type==='date'){$d=in_array($format,array('Y-m-d','d/m/Y'),true)?DateTimeImmutable::createFromFormat('!'.$format,$raw):false;if(!$d||$d->format($format)!==$raw){$quality[]='data_invalida:'.$name;continue;}$out[$key]=$d->format('Y-m-d');}
                else{$pattern=$format==='decimal_ponto'?'/^-?[0-9]+(?:\.[0-9]+)?$/D':($format==='decimal_virgula'?'/^-?[0-9]+(?:,[0-9]+)?$/D':'');if(!$pattern||!preg_match($pattern,$raw)||!is_finite((float)str_replace(',','.',$raw))){$quality[]='numero_invalido:'.$name;continue;}$out[$key]=(float)str_replace(',','.',$raw);if($type==='monetary'){if(!preg_match('/^[A-Z]{3}$/D',$map['moeda']??'')){unset($out[$key]);$quality[]='moeda_ausente:'.$name;continue;}$out[$key.'_currency']=$map['moeda'];}}continue;
            }
            if(!in_array($type,array('varchar','text','varchar_auto'),true)){$quality[]='tipo_incompativel:'.$name;continue;}
            $text=implode('; ',array_map(static fn($x)=>is_bool($x)?($x?'Sim':'Não'):(is_scalar($x)?(string)$x:''),$values));
            $limit=(int)($f['max_length']??($type==='text'?65535:255));if($limit<1){$limit=$type==='text'?65535:255;}
            if(mb_strlen($text)>$limit){$text=mb_substr($text,0,$limit);$quality[]='texto_cortado:'.$name;}$out[$key]=$text;
        }
        return array('campos'=>$out,'qualidade'=>array_values(array_unique($quality)));
    }
    public static function previa(array $lead): array {$c=F3Base_Options::ler('f3base_pipedrive');$a=F3Base_Contato_Apresentacao::montar($lead);$extra=self::campos($a,$c);$intent=F3Base_Pipedrive_Fila::intencao(array_merge($lead,$lead['dados']))['pipedrive'];return array('elegivel'=>$intent['solicitado'],'motivo'=>$intent['motivo'],'identificadores'=>F3Base_Pipedrive_Api::identificadores($lead),'titulo'=>self::titulo($a,$c),'host'=>$a['site'],'campos_lead'=>F3Base_Pipedrive_Fila::campos($a,$c),'destinos'=>self::destinos(F3Base_Pipedrive_Fila::campos($a,$c),$c),'mapa_pessoa'=>$c['mapa_pessoa'],'rotulo_pessoa'=>$c['rotulo_pessoa'],'qualidade'=>array_merge($a['qualidade'],$extra['qualidade']),'nota'=>F3Base_Contato_Apresentacao::nota($a,'f3base:previa'),'limite'=>'Prévia local. Identidade e oportunidade serão conferidas no despacho.');}
    public static function mapa_ui(array $value,array $catalog): void {
        $forms=array();foreach((array)F3Base_Options::ler('f3base_formularios') as $form){$fields=array();foreach($form['campos']??array() as $f){if(($f['tipo']??'')==='file'){continue;}$fields[]=array_intersect_key($f,array_flip(array('nome','rotulo','tipo','opcoes')));}$forms[]=array('id'=>$form['id'],'titulo'=>$form['titulo']??$form['id'],'campos'=>$fields);}
        $fields=array_values(array_filter($catalog['campos']??array(),static fn($f)=>preg_match('/^[a-f0-9]{40}$/D',$f['field_code']??$f['key']??'')&&in_array($f['field_type']??'',array('varchar','varchar_auto','text','enum','set','double','monetary','date'),true)));
        echo '<div data-f3base-mapa-respostas><p>Escolha uma resposta e seu destino. As alterações entram no mapa abaixo e só são gravadas ao salvar a integração.</p><p><label>Formulário <select data-form></select></label> <label>Resposta <select data-source></select></label></p><p><label>Campo no CRM <select data-target></select></label></p><div data-conversion></div><div data-alternatives></div><button type="button" class="button" data-apply>Aplicar ao mapa</button> <button type="button" class="button" data-remove>Remover esta resposta do mapa</button><p role="status" data-status></p><script type="application/json" data-catalog>'.wp_json_encode(array('forms'=>$forms,'fields'=>$fields),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script></div>';
        echo '<details><summary>Mapa técnico completo (JSON)</summary><textarea id="f3base-integ-mapa_respostas" name="config[mapa_respostas]" rows="6" class="large-text code">'.esc_textarea(wp_json_encode((object)$value,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</textarea></details><noscript><p>Sem JavaScript, edite o JSON com os exemplos da ajuda.</p></noscript>';
        wp_enqueue_script('f3base-mapa-respostas',F3BASE_PLUGIN_URL.'assets/f3base-mapa-respostas.js',array(),F3BASE_PLUGIN_VERSAO,true);
    }
    public static function destinos(array $fields,array $cfg): array {
        $cat=get_option('f3base_pipedrive_estado',array())['catalogos']['campos']??array();$out=array();foreach($fields as $key=>$value){$known=null;foreach($cat as $f){if(($f['field_code']??$f['key']??'')===$key){$known=$f;break;}}$role=array_search($key,$cfg['mapa_campos']??array(),true);$out[]=array('papel'=>$role?:'resposta','nome'=>$known['name']??'Catálogo pendente','tipo'=>$known['field_type']??'desconhecido','campo_id'=>$key,'valor'=>$known?$value:null,'pronto'=>$known!==null);}return $out;
    }
    public static function estado(): array {
        $s=get_option('f3base_pipedrive_estado',array());$c=F3Base_Options::ler('f3base_pipedrive');$credential=F3Base_Segredos::status('f3base_pipedrive_token');$valid=F3Base_Integracoes::pipedrive_verificado($s);$budget=get_option('f3base_pipedrive_orcamento',array());$exhausted=($budget['dia']??'')===gmdate('Y-m-d')&&((int)($budget['usados']??0)+20>(int)($c['orcamento_local_diario']??3000));$guard=F3Base_Recuperacao::ler();$paused=$exhausted||(int)($s['pausa_ate']??0)>time()||empty($guard['ok'])||!empty($guard['pausado']);
        if($credential['estado']!=='disponivel'){$label='Sem credencial';$reason='credencial_ausente';$action='Configure e confirme a credencial da conta.';}
        elseif(!$valid){$label='Verificação pendente';$reason=$s['codigo']??'verificacao_pendente';$action=F3Base_Pipedrive_Alertas::motivo($reason).' Use Verificar integração para conferir conta e catálogos.';}
        elseif(empty($c['ativo'])){$label='Conectado, mas desligado';$reason='integracao_desligada';$action='Habilite a integração quando desejar enviar contatos.';}
        elseif($paused){$label='Conectado, com despacho pausado';$reason=$exhausted?'orcamento_local_esgotado':'pausa_operacional';$action='Confira o orçamento e a pausa na área de operação.';}
        else{$label='Entregando';$reason='pronta';$action='A integração está pronta para enviar contatos. Consulte a confirmação de cada contato na fila.';}
        return array_merge($s,array('entregando'=>$reason==='pronta','rotulo'=>$label,'motivo'=>$reason,'acao'=>$action));
    }
    public static function painel(): void {
        $s=self::estado();$counts=array('suspenso'=>0,'falhou'=>0,'revisao'=>0);foreach(F3Base_Pipedrive_Fila::diagnostico()['estados']??array() as $v){if(isset($counts[$v['estado']])){$counts[$v['estado']]=(int)$v['quantidade'];}}
        echo '<div class="f3base-crm-cabecalho"><h2>'.esc_html($s['rotulo']).'</h2><nav aria-label="Entregas que precisam de atenção">';foreach($counts as $status=>$count){echo '<a class="button" href="'.esc_url(admin_url('admin.php?page=f3base-integracoes&integracao=entregas&estado='.$status)).'">'.esc_html(array('suspenso'=>'Suspensas','falhou'=>'Falhas','revisao'=>'Em revisão')[$status].': '.$count).'</a> ';}echo '</nav></div><p>'.esc_html($s['acao']).'</p>';
    }
}
