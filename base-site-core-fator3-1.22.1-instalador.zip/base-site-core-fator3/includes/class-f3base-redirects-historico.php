<?php
/** Retirada de uma rota histórica sem apagar o fallback de outros caminhos. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Redirects_Historico {
    const RETIRADOS='_f3base_retired_path';
    public static function registrar(): void {
        F3Base_Servicos::ability('redirects-historico-ler','Consultar rotas históricas e conflitos por conteúdo',array(__CLASS__,'ler'),array('post_id'=>array('type'=>'integer','minimum'=>1)),array('post_id'));
        F3Base_Servicos::ability('redirects-historico-escrever','Retirar um caminho antigo preservando os demais',array(__CLASS__,'escrever'),array('post_id'=>array('type'=>'integer','minimum'=>1),'caminho'=>array('type'=>'string'),'acao'=>array('type'=>'string','enum'=>array('retirar','restaurar'),'default'=>'retirar'),'revisao_esperada'=>array('type'=>'string'),'simular'=>array('type'=>'boolean','default'=>true),'confirmar'=>array('type'=>'boolean')),array('post_id','caminho','revisao_esperada'),false);
    }
    public static function retirado(int $id,string $path): bool {return in_array(F3Base_Modulo_Redirects::normalizar($path),get_post_meta($id,self::RETIRADOS,false),true);}
    public static function ler(array $e): array {
        $id=(int)($e['post_id']??0);if(!current_user_can('manage_options')||!current_user_can('edit_post',$id)){return array('ok'=>false,'codigo'=>'sem_permissao');}$post=get_post($id);if(!$post){return array('ok'=>false,'codigo'=>'conteudo_ausente');}
        $meta=array();foreach(array('_f3base_old_path','_f3base_old_slug','_wp_old_slug',self::RETIRADOS) as $key){$meta[$key]=get_post_meta($id,$key,false);}
        $paths=array_values(array_unique(array_merge($meta['_f3base_old_path'],array_map(static fn($slug)=>'/'.$slug.'/',$meta['_f3base_old_slug']))));$lines=array();
        foreach($paths as $path){$lines[]=array('caminho'=>$path,'destino'=>get_permalink($id),'retirado'=>self::retirado($id,$path),'outros_responsaveis'=>self::conflitos($id,$path));}
        return array('ok'=>true,'post_id'=>$id,'revisao'=>hash('sha256',wp_json_encode(array($meta,get_permalink($id),get_option('f3base_redirects',array())))),'metadados'=>$meta,'linhas'=>$lines,'limite'=>'Fallbacks de slug podem cobrir caminhos não registrados. A retirada marca somente o caminho informado; cache externo exige purga e prova HTTP.');
    }
    private static function conflitos(int $id,string $path): array {
        $out=array();$canon=F3Base_Modulo_Redirects::normalizar($path);$live=url_to_postid(home_url($path));if($live){$out[]=array('tipo'=>'conteudo_atual','post_id'=>$live);}
        foreach((array)get_option('f3base_redirects',array()) as $rule){if(is_array($rule)&&F3Base_Modulo_Redirects::normalizar($rule['de']??'')===$canon){$out[]=array('tipo'=>'regra_explicita','de'=>$rule['de']);}}
        global $wpdb;$slug=basename(trim($path,'/'));$ids=$wpdb->get_col($wpdb->prepare("SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE post_id<>%d AND ((meta_key IN ('_f3base_old_slug','_wp_old_slug') AND meta_value=%s) OR (meta_key='_f3base_old_path' AND meta_value=%s))",$id,$slug,$path));foreach($ids as $other){$out[]=array('tipo'=>'historico_outro_conteudo','post_id'=>(int)$other);}return $out;
    }
    public static function escrever(array $e): array {
        $sim=($e['simular']??true)!==false;$restaurar=($e['acao']??'retirar')==='restaurar';$before=self::ler($e);if(empty($before['ok'])){return $before;}$id=$before['post_id'];$path=$e['caminho']??'';
        if(!is_string($path)||!str_starts_with($path,'/')||str_starts_with($path,'//')||strpbrk($path,'?#')!==false||preg_match('~(?:^|/)\.\.?(/|$)|%2f|%5c|[\x00-\x20]~i',$path)){return array('ok'=>false,'codigo'=>'caminho_invalido');}
        if(!hash_equals($before['revisao'],(string)$e['revisao_esperada'])){return array('ok'=>false,'codigo'=>'conflito');}
        $found=in_array($path,$before['metadados']['_f3base_old_path'],true)||in_array(basename(trim($path,'/')),$before['metadados']['_f3base_old_slug'],true)||in_array(basename(trim($path,'/')),$before['metadados']['_wp_old_slug'],true)||self::retirado($id,$path);
        if(!$found){return array('ok'=>false,'codigo'=>'caminho_nao_historico');}
        $conflicts=self::conflitos($id,$path);$result=array('ok'=>true,'simulado'=>$sim,'persisted'=>false,'alteraria'=>$restaurar?self::retirado($id,$path):!self::retirado($id,$path),'caminho'=>$path,'destino'=>get_permalink($id),'outros_responsaveis'=>$conflicts,'revisao'=>$before['revisao']);if($sim){return $result;}
        if(($e['confirmar']??false)!==true){return array('ok'=>false,'codigo'=>'confirmacao_necessaria');}
        $lock=F3Base_Trava::adquirir('redirect-history-'.$id,30);if(!$lock){return array('ok'=>false,'codigo'=>'ocupado');}
        try{$fresh=self::ler($e);if(!hash_equals($before['revisao'],$fresh['revisao'])){return array('ok'=>false,'codigo'=>'conflito');}
            if($restaurar){
                if(!in_array($path,get_post_meta($id,'_f3base_old_path',false),true)&&!add_post_meta($id,'_f3base_old_path',$path)){return array('ok'=>false,'codigo'=>'restauracao_nao_persistida');}
                delete_post_meta($id,self::RETIRADOS,F3Base_Modulo_Redirects::normalizar($path));$ok=!self::retirado($id,$path);if($ok){F3Base_Cache_Pagina::limpar(false,'historico_redirect_restaurado');}
                return array_merge($result,array('ok'=>$ok,'persisted'=>$ok,'codigo'=>'historico_restaurado_verificar_http','revisao'=>self::ler($e)['revisao']));
            }
            if(!self::retirado($id,$path)&&!add_post_meta($id,self::RETIRADOS,F3Base_Modulo_Redirects::normalizar($path))){return array('ok'=>false,'codigo'=>'retirada_nao_persistida');}
            delete_post_meta($id,'_f3base_old_path',$path);$slug=basename(trim($path,'/'));$other=array_filter(get_post_meta($id,'_f3base_old_path',false),static fn($p)=>basename(trim($p,'/'))===$slug);if(!$other){delete_post_meta($id,'_f3base_old_slug',$slug);}$ok=self::retirado($id,$path)&&!in_array($path,get_post_meta($id,'_f3base_old_path',false),true);if($ok){F3Base_Cache_Pagina::limpar(false,'historico_redirect_retirado');}
            return array_merge($result,array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$conflicts?'retirado_com_outros_responsaveis':($ok?'historico_retirado_verificar_http':'retirada_parcial'),'revisao'=>self::ler($e)['revisao']));
        }finally{F3Base_Trava::liberar($lock);}
    }
}
