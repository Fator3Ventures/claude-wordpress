<?php
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
trait F3Base_Pipedrive_Reconciliacao {
    public static function reconciliar(array $e): array {
        $sim=($e['simular']??true)!==false;$fail=static fn($c)=>array('ok'=>false,'codigo'=>$c,'simulado'=>$sim,'persisted'=>false);
        if(!current_user_can('manage_options')){return $fail('sem_permissao');}
        $j=self::ler($e['chave']??'');if(!$j||!hash_equals(self::revisao($j),(string)($e['revisao']??''))){return $fail('revisao_divergente');}
        if(in_array($j['estado'],array('enviando','cancelado','cancelando'),true)||$j['lease']!==''){return $fail('estado_nao_reconciliavel');}
        $lead=F3Base_Leads_Repositorio::obter($j['record_id']);if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']||$lead['captura']!=='aceito'){return $fail('registro_nao_elegivel');}
        F3Base_Pipedrive_Api::iniciar_lote();$s=get_option('f3base_pipedrive_estado',array());if(!F3Base_Integracoes::pipedrive_verificado($s)||$j['conta']!==($s['dominio']??'').'|'.($s['conta_id']??'').'|'.($s['instalacao']??'')){return $fail('conta_nao_confirmada');}
        $action=$e['acao']??'';$id=(string)($e['referencia_remota']??'');$person=(int)($j['journal']['pessoa']??0);
        if($action==='pessoa'){
            if(!ctype_digit($id)||(int)$id<1||$person||$j['etapa']!=='pessoa'){return $fail('pessoa_nao_elegivel');}
            $remote=F3Base_Pipedrive_Api::pedir('GET','v2/persons/'.$id);
            if(empty($remote['ok'])){return $fail($remote['codigo']);}
            if((int)($remote['data']['id']??0)!==(int)$id||!F3Base_Pipedrive_Api::identidade_confirmada($remote['data'],$lead,true)){return $fail('pessoa_divergente');}
        }elseif($action==='lead'){
            if(!$person||!preg_match('/^[a-f0-9-]{36}$/D',$id)||!empty($j['journal']['oportunidade'])){return $fail('lead_nao_elegivel');}
            $remote=F3Base_Pipedrive_Api::pedir('GET','v1/leads/'.$id);if(empty($remote['ok'])){return $fail($remote['codigo']);}
            if(!empty($remote['data']['is_archived'])||!self::autoria($remote['data'],$j['conta'],$person)){return $fail('lead_proprio_nao_confirmado');}
        }elseif($action==='email_alternativo'){
            if(!$person||$id!==(string)$person||empty($e['adicionar_email_alternativo'])||!is_email($lead['email'])){return $fail('email_alternativo_nao_autorizado');}
            $remote=F3Base_Pipedrive_Api::pedir('GET','v2/persons/'.$person);if(empty($remote['ok'])){return $fail($remote['codigo']);}
            if(!F3Base_Pipedrive_Api::identidade_confirmada($remote['data'],$lead,false)){return $fail('pessoa_divergente');}
            $collision=F3Base_Pipedrive_Api::buscar_pessoa(array('email'=>$lead['email'],'dados'=>array()));if(empty($collision['ok'])){return $fail($collision['codigo']);}
            if(!empty($collision['pessoa'])&&(int)$collision['pessoa']['id']!==$person){return $fail('email_em_outra_pessoa');}
        }else{return $fail('acao_invalida');}
        $proof=hash('sha256',wp_json_encode($remote['data']));$result=array('ok'=>true,'simulado'=>$sim,'persisted'=>false,'acao'=>$action,'referencia_remota'=>$id,'prova_remota'=>$proof,'revisao'=>self::revisao($j),'alteraria'=>true,'verificacao_remota'=>true);
        $again=self::ler($j['chave']);if(!$again||!hash_equals(self::revisao($again),self::revisao($j))||!F3Base_Pipedrive_Api::lote_atual()){return $fail('contexto_alterado');}
        if($sim){return $result;}
        if(($e['confirmar']??false)!==true||!hash_equals($proof,(string)($e['prova_remota']??''))){return $fail('confirmacao_ou_prova_divergente');}
        $before=$j['estado'];$lease=F3Base_Fila::lease();if(!self::salvar($j,array('lease'=>$lease,'lease_ate'=>time()+120))){return $fail('reserva_divergente');}
        try {
            $journal=$j['journal'];
            if($action==='pessoa'){$journal['pessoa']=(int)$id;$journal['pessoa_reconciliada']=array('id'=>(int)$id,'em'=>time(),'operador'=>get_current_user_id(),'prova'=>$proof);}
            elseif($action==='lead'){$journal['oportunidade']=array('tipo'=>'lead','id'=>$id,'nova'=>false,'autoria'=>'selecao_administrativa_confirmada');}
            else {
                $emails=$remote['data']['emails']??array();$target=strtolower(trim($lead['email']));$exists=false;foreach($emails as $mail){if(strtolower(trim((string)($mail['value']??'')))===$target){$exists=true;}}
                if(!$exists){$reread=F3Base_Pipedrive_Api::pedir('GET','v2/persons/'.$person);if(empty($reread['ok'])||!hash_equals($proof,hash('sha256',wp_json_encode($reread['data'])))){return $fail('pessoa_alterada_concorrentemente');}
                    $emails[]=array('value'=>$target,'primary'=>false,'label'=>'work');$patch=F3Base_Pipedrive_Api::pedir('PATCH','v2/persons/'.$person,array('emails'=>$emails));if(empty($patch['ok'])){return $fail(!empty($patch['incerto'])?'email_alternativo_incerto_reler':$patch['codigo']);}
                    $check=F3Base_Pipedrive_Api::pedir('GET','v2/persons/'.$person);if(empty($check['ok'])||($check['data']['emails']??array())!==$emails){return $fail('email_alternativo_requer_conferencia');}
                }$journal['email_alternativo_confirmado_em']=time();
            }
            $status=$action==='email_alternativo'?$before:'pendente';$journal['reconciliacao_administrativa']=array('acao'=>$action,'em'=>time(),'operador'=>get_current_user_id(),'prova'=>$proof);
            $ok=self::salvar($j,array('journal'=>$journal,'estado'=>$status,'etapa'=>$action==='pessoa'?'':$j['etapa'],'lease'=>'','lease_ate'=>0,'proxima'=>time(),'codigo'=>'reconciliacao_confirmada'));
            if($ok&&$status==='pendente'){F3Base_Fila::agendar(self::EVENTO);}
            return array_merge($result,array('ok'=>$ok,'persisted'=>$ok,'codigo'=>$ok?'reconciliacao_confirmada':'checkpoint_pendente'));
        }finally{if($j['lease']===$lease){self::salvar($j,array('lease'=>'','lease_ate'=>0));}}
    }
    public static function sanear_diarios(array $cursor=array(),int $limite=50): array {
        global $wpdb;$defs=array(array(self::tabela(),'chave','journal'),array(F3Base_Leads_Repositorio::tabela(),'record_id','entrega'));$index=max(0,(int)($cursor['tabela']??0));$after=(string)($cursor['apos']??'');$total=(int)($cursor['examinados']??0);$changed=(int)($cursor['alterados']??0);$start=microtime(true);$count=0;
        $result=static function(bool $ok,string $code,bool $done=false)use(&$index,&$after,&$total,&$changed,&$count){return array('ok'=>$ok,'codigo'=>$code,'concluido'=>$done,'processados'=>$count,'cursor'=>array('tabela'=>$index,'apos'=>$after,'examinados'=>$total,'alterados'=>$changed));};
        while($index<count($defs)&&$count<$limite&&microtime(true)-$start<3){[$t,$key,$field]=$defs[$index];$rows=$wpdb->get_results($wpdb->prepare('SELECT %i,%i FROM %i WHERE %i>%s ORDER BY %i LIMIT %d',$key,$field,$t,$key,$after,$key,$limite-$count),ARRAY_A);if($wpdb->last_error){return $result(false,'diarios_leitura_falhou');}
            if(!$rows){++$index;$after='';continue;}
            foreach($rows as $row){$raw=$row[$field];$safe=F3Base_Json_Diario::sanear($raw);
                if($safe!==$raw){$n=$wpdb->query($wpdb->prepare('UPDATE %i SET %i=%s WHERE %i=%s AND BINARY %i=BINARY %s',$t,$field,$safe,$key,$row[$key],$field,$raw));if($n===false){return $result(false,'diarios_escrita_falhou');}if($n===0){return $result(true,'diarios_concorrencia');}++$changed;}
                $after=$row[$key];++$count;++$total;if($count>=$limite||microtime(true)-$start>=3){break;}
            }
        }return $result(true,$index>=count($defs)?'diarios_sanitizados':'diarios_em_lotes',$index>=count($defs));
    }
    public static function journal_sanitizado(array $v): array {
        foreach($v as $k=>&$x){if($k==='outras_oportunidades'&&is_array($x)){$x=array_map(static fn($r)=>is_array($r)?array_intersect_key($r,array_flip(array('tipo','id'))):array(),$x);}elseif(is_array($x)){$x=self::journal_sanitizado($x);}}unset($x);return $v;
    }
}
