# Fator3 MCP 0.33.0

Entrega do pedido MCP 68: apresentação contextual de lido após escrita aplicada, texto token_indisponivel e nomes chaves_herdadas. Base direta 0.32.0; Core 1.54.0. Reteste da autorização de correio corrigida pelo Core, sem concessão de capacidades pelo MCP. WordPress mínimo 7.1.2 / PHP 8.3.6.

Instale somente wp-mcp-fator3-0.33.0-instalador.zip. Consulte o relatório externo para hashes, evidências próprias, reversão e limites. Código em fontes/wp-mcp-fator3, ferramentas em tools, manuais em docs. system/guide fornece documentação autenticada; documentos release-0330 e redacao descrevem esta entrega. Documentos de versões anteriores são históricos.
