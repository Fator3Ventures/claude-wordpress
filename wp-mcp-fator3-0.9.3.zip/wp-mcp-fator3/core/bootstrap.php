<?php
/** Bundled Ultimate core. No separate plugin installation is required. */
declare(strict_types=1);
namespace WpMcpUltimate;
defined('ABSPATH') || exit;

define('WP_MCP_ULTIMATE_DIR', __DIR__ . '/');
define('WP_MCP_ULTIMATE_URL', plugin_dir_url(__FILE__));
define('WP_MCP_ULTIMATE_VERSION', F3_MCP_FILES_VERSION);
require_once __DIR__ . '/includes/Autoloader.php';
if (Autoloader::register()) {
	Plugin::instance();
}
