<?php
/** Run only on disposable WordPress: php upstream-regressions.php /absolute/wp-root [report.json]. */
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || empty($argv[1])) { exit(1); }
$_SERVER['HTTP_HOST']='127.0.0.1:8787'; $_SERVER['REQUEST_URI']='/';
require rtrim($argv[1],'/').'/wp-load.php';
require_once ABSPATH.'wp-admin/includes/user.php';
use WpMcpUltimate\Abilities\Helpers;
$checks=[]; $ids=[]; $uid=0;
function check_pr(string $name,bool $ok):void { global $checks; $checks[]=['test'=>$name,'ok'=>$ok]; }
function pr_denied(string $name,array $input):bool {
    $r=wp_get_ability($name)->execute($input);
    return is_wp_error($r) || (is_array($r) && isset($r['success']) && !$r['success']);
}
try {
    wp_set_current_user(1);
    $uid=wp_insert_user(['user_login'=>'f3-pr-'.bin2hex(random_bytes(5)),'user_pass'=>wp_generate_password(),'role'=>'subscriber']);
    if(is_wp_error($uid))throw new Exception($uid->get_error_message());
    wp_set_current_user($uid);
    check_pr('pr9:subscriber_discovery_denied',pr_denied('wp-mcp-ultimate/discover-abilities',[]));
    $u=get_userdata($uid); foreach(['edit_posts','edit_pages','delete_pages'] as $cap)$u->add_cap($cap);
    wp_set_current_user(1);
    foreach(['post','page'] as $type)$ids[$type]=wp_insert_post(['post_type'=>$type,'post_author'=>1,'post_status'=>'draft','post_content'=>'original']);
    wp_set_current_user($uid);
    foreach($ids as $type=>$id)check_pr('pr9:object_patch_'.$type,pr_denied('content/patch-'.$type,['id'=>$id,'find'=>'original','replace'=>'changed']) && get_post($id)->post_content==='original');
    check_pr('pr9:object_page_delete',pr_denied('content/delete-page',['id'=>$ids['page'],'force'=>true]) && null!==get_post($ids['page']));
    wp_set_current_user(1);
    $limits=[ini_get('pcre.backtrack_limit'),ini_get('pcre.recursion_limit')];
    foreach(['/x/e','/[invalid/'] as $regex){
        $r=Helpers::guarded_preg_replace($regex,'z','x');
        check_pr('pr9:regex_reject_'.md5($regex),!$r['success'] && $limits===[ini_get('pcre.backtrack_limit'),ini_get('pcre.recursion_limit')]);
    }
    foreach(['plugins/upload','plugins/upload-base64'] as $ability){
        $schema=wp_get_ability($ability)->get_input_schema();
        check_pr('pr9:install_defaults_'.$ability,false===$schema['properties']['activate']['default'] && false===$schema['properties']['overwrite']['default']);
    }
    $calls=[];
    $http=static function($pre,$args,$url)use(&$calls){
        $calls[]=$url;
        return ['headers'=>['location'=>'http://169.254.169.254/latest'],'body'=>'','response'=>['code'=>302,'message'=>'Found'],'cookies'=>[]];
    };
    add_filter('pre_http_request',$http,10,3);
    try { $r=Helpers::safe_download_url('http://93.184.216.34/fixture'); }
    finally { remove_filter('pre_http_request',$http,10); }
    check_pr('pr9:redirect_to_link_local_rejected',is_wp_error($r) && count($calls)===1);
    check_pr('pr9:toggle_debug_default_denied',pr_denied('system/toggle-debug',['debug'=>true]));
} catch(Throwable $e) { $checks[]=['test'=>'unexpected_exception','ok'=>false,'detail'=>$e->getMessage()]; }
finally { wp_set_current_user(1); foreach($ids as $id)wp_delete_post($id,true); if(is_int($uid)&&$uid)wp_delete_user($uid); }
$failed=count(array_filter($checks,static fn($c)=>!$c['ok']));
$report=['wordpress'=>get_bloginfo('version'),'passed'=>count($checks)-$failed,'failed'=>$failed,'checks'=>$checks];
if(!empty($argv[2]))file_put_contents($argv[2],json_encode($report,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo json_encode($report,JSON_UNESCAPED_UNICODE).PHP_EOL; exit($failed?1:0);
