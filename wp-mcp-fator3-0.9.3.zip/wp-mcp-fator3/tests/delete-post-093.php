<?php
/**
 * Destructive regression tests: run ONLY in a disposable WordPress installation.
 * php delete-post-093.php /absolute/wordpress enabled|disabled report.json
 * Requires F3_DELETE_POST_DISPOSABLE_LAB=true in that installation's wp-config.php.
 * Uses real WordPress abilities, database, permissions, hooks and trash functions.
 */
declare(strict_types=1);

if ( PHP_SAPI !== 'cli' || empty( $argv[1] ) || ! in_array( $argv[2] ?? '', array( 'enabled', 'disabled' ), true ) ) {
	fwrite( STDERR, "Usage: php delete-post-093.php WORDPRESS enabled|disabled REPORT.json\n" );
	exit( 2 );
}
$enabled = 'enabled' === $argv[2];
define( 'EMPTY_TRASH_DAYS', $enabled ? 30 : 0 );
define( 'WP_DISABLE_FATAL_ERROR_HANDLER', true );
$_SERVER['HTTP_HOST'] = '127.0.0.1';
$_SERVER['REQUEST_URI'] = '/';
require rtrim( $argv[1], '/' ) . '/wp-load.php';
if ( ! defined( 'F3_DELETE_POST_DISPOSABLE_LAB' ) || true !== F3_DELETE_POST_DISPOSABLE_LAB ) {
	fwrite( STDERR, "Refusing to run outside an explicitly disposable lab.\n" );
	exit( 2 );
}
wp_set_current_user( 1 );
register_post_type( 'f3_fixture', array( 'public' => true, 'show_in_rest' => true ) );

$checks = array();
$ids = array();
function f3_check( string $name, bool $ok ): void {
	global $checks;
	$checks[] = array( 'test' => $name, 'ok' => $ok );
}
function f3_fixture( string $type = 'f3_fixture' ): int {
	global $ids;
	$id = wp_insert_post( wp_slash( array(
		'post_type' => $type,
		'post_title' => 'Disposable delete-post regression',
		'post_status' => 'attachment' === $type ? 'inherit' : 'draft',
		'post_author' => 1,
		'post_content' => 'Literal \\u00e3 and C:\\path "quoted"',
	) ), true );
	if ( is_wp_error( $id ) || ! $id ) {
		throw new RuntimeException( 'Unable to create fixture: ' . $type );
	}
	$ids[] = $id;
	return $id;
}
function f3_delete( array $args ) {
	return wp_get_ability( 'content/delete-post' )->execute( $args );
}
function f3_ok( $result ): bool {
	return is_array( $result ) && true === ( $result['success'] ?? null );
}
function f3_failed( $result ): bool {
	return is_wp_error( $result ) || ( is_array( $result ) && false === ( $result['success'] ?? null ) );
}

try {
	$ability = wp_get_ability( 'content/delete-post' );
	if ( ! $ability || ! current_user_can( 'manage_options' ) ) {
		throw new RuntimeException( 'Missing ability or administrator ID 1.' );
	}
	$expected = json_decode( file_get_contents( __DIR__ . '/expected-abilities.json' ), true );
	f3_check( 'original_ability_inventory_preserved', ! array_diff( $expected, array_keys( wp_get_abilities() ) ) );
	$info = wp_get_ability( 'wp-mcp-ultimate/get-ability-info' )->execute( array( 'ability_name' => 'content/delete-post' ) );
	f3_check( 'metatool_exposes_updated_schema', is_array( $info ) && false === $info['input_schema']['properties']['force']['default'] && str_contains( $info['input_schema']['properties']['force']['description'], 'Never falls back' ) );

	foreach ( array( 'post', 'page', 'f3_fixture', 'wp_navigation', 'wp_block', 'wp_template', 'attachment' ) as $type ) {
		$id = f3_fixture( $type );
		$before = get_post( $id );
		add_post_meta( $id, 'f3_preserved', 'keep-me' );
		$comment = wp_insert_comment( array( 'comment_post_ID' => $id, 'comment_content' => 'Preserve me', 'comment_approved' => 1 ) );
		$result = f3_delete( array( 'id' => $id, 'force' => false ) );
		$after = get_post( $id );
		f3_check( $type . ':false_preserves_record_and_content', null !== $after && $before->post_content === $after->post_content && 'keep-me' === get_post_meta( $id, 'f3_preserved', true ) && null !== get_comment( $comment ) );
		f3_check( $type . ':trash_result_matches_state', $enabled ? ( f3_ok( $result ) && 'trash' === $after->post_status ) : ( f3_failed( $result ) && $before->post_status === $after->post_status ) );
		f3_check( $type . ':output_schema', true === rest_validate_value_from_schema( $result, $ability->get_output_schema() ) );
		if ( $enabled ) {
			$stamp = get_post_meta( $id, '_wp_trash_meta_time', true );
			f3_check( $type . ':trash_metadata', $before->post_status === get_post_meta( $id, '_wp_trash_meta_status', true ) && (int) $stamp > 0 );
			$result = f3_delete( array( 'id' => $id ) );
			f3_check( $type . ':repeat_omitted_force_keeps_trash', f3_ok( $result ) && 'trash' === get_post( $id )->post_status && $stamp === get_post_meta( $id, '_wp_trash_meta_time', true ) );
			wp_untrash_post( $id );
			f3_check( $type . ':restorable_with_content_and_comments', null !== get_post( $id ) && 'trash' !== get_post( $id )->post_status && $before->post_content === get_post( $id )->post_content && '1' === get_comment( $comment )->comment_approved );
		} else {
			$result = f3_delete( array( 'id' => $id ) );
			f3_check( $type . ':omitted_force_refuses_disabled_trash', f3_failed( $result ) && null !== get_post( $id ) );
		}
		$result = f3_delete( array( 'id' => $id, 'force' => true ) );
		f3_check( $type . ':true_permanently_deletes', f3_ok( $result ) && null === get_post( $id ) && null === get_comment( $comment ) && '' === get_post_meta( $id, 'f3_preserved', true ) );
	}

	$id = f3_fixture();
	wp_update_post( array( 'ID' => $id, 'post_status' => 'trash' ) );
	$result = f3_delete( array( 'id' => $id, 'force' => false ) );
	f3_check( 'already_trashed_never_deleted_with_false', f3_ok( $result ) && 'trash' === get_post( $id )->post_status );
	f3_check( 'already_trashed_can_be_permanently_deleted_with_true', f3_ok( f3_delete( array( 'id' => $id, 'force' => true ) ) ) && null === get_post( $id ) );

	$id = f3_fixture();
	foreach ( array( 'false', 'true', 1, 0, null, array() ) as $index => $invalid ) {
		$result = f3_delete( array( 'id' => $id, 'force' => $invalid ) );
		f3_check( 'invalid_force_' . $index . '_preserves_record', f3_failed( $result ) && 'draft' === get_post( $id )->post_status );
	}
	foreach ( array( array(), array( 'id' => 0 ), array( 'id' => -1 ), array( 'id' => PHP_INT_MAX ) ) as $index => $input ) {
		f3_check( 'missing_or_invalid_id_' . $index, f3_failed( f3_delete( $input ) ) );
	}

	// Deny only the object capability while retaining the outer delete_posts gate.
	$deny = static function ( $caps, $cap, $user_id, $args ) use ( $id ) {
		return 'delete_post' === $cap && (int) ( $args[0] ?? 0 ) === $id ? array( 'do_not_allow' ) : $caps;
	};
	add_filter( 'map_meta_cap', $deny, 10, 4 );
	try {
		foreach ( array( false, true ) as $force ) {
			f3_check( 'object_permission_' . (int) $force, f3_failed( f3_delete( array( 'id' => $id, 'force' => $force ) ) ) && 'draft' === get_post( $id )->post_status );
		}
	} finally {
		remove_filter( 'map_meta_cap', $deny, 10 );
	}
	wp_set_current_user( 0 );
	f3_check( 'anonymous_permission', f3_failed( f3_delete( array( 'id' => $id, 'force' => true ) ) ) && null !== get_post( $id ) );
	wp_set_current_user( 1 );

	foreach ( array( false, true ) as $force ) {
		if ( ! $force && ! $enabled ) {
			continue;
		}
		$hook = $force ? 'pre_delete_post' : 'pre_trash_post';
		foreach ( array( false, true, new WP_Error( 'fixture_veto', 'Fixture veto' ), get_post( $id ) ) as $index => $value ) {
			$veto = static function ( $pre, $post ) use ( $id, $value ) {
				return $post->ID === $id ? $value : $pre;
			};
			add_filter( $hook, $veto, 10, 2 );
			try {
				$result = f3_delete( array( 'id' => $id, 'force' => $force ) );
				f3_check( $hook . ':veto_' . $index . '_never_claims_success', f3_failed( $result ) && 'draft' === get_post( $id )->post_status );
			} finally {
				remove_filter( $hook, $veto, 10 );
			}
		}
	}
	if ( $enabled ) {
		$keep_draft = static function ( $data, $postarr ) use ( $id ) {
			if ( (int) ( $postarr['ID'] ?? 0 ) === $id && 'trash' === $data['post_status'] ) {
				$data['post_status'] = 'draft';
			}
			return $data;
		};
		add_filter( 'wp_insert_post_data', $keep_draft, 10, 2 );
		try {
			f3_check( 'status_filter_cannot_produce_false_trash_success', f3_failed( f3_delete( array( 'id' => $id ) ) ) && 'draft' === get_post( $id )->post_status );
		} finally {
			remove_filter( 'wp_insert_post_data', $keep_draft, 10 );
		}
	}

	foreach ( array( false, true ) as $as_json ) {
		$id = f3_fixture();
		$params = array( 'id' => $id, 'force' => false );
		$result = wp_get_ability( 'wp-mcp-ultimate/execute-ability' )->execute( array(
			'ability_name' => 'content/delete-post',
			'parameters' => $as_json ? wp_json_encode( $params ) : $params,
		) );
		$data = is_array( $result ) ? ( $result['data'] ?? null ) : null;
		f3_check( 'execute_metatool_' . (int) $as_json . '_preserves_record', null !== get_post( $id ) && ( $enabled ? ( f3_ok( $data ) && 'trash' === get_post( $id )->post_status ) : ( f3_failed( $data ) && 'draft' === get_post( $id )->post_status ) ) );
	}
} catch ( Throwable $error ) {
	$checks[] = array( 'test' => 'unexpected_exception', 'ok' => false, 'detail' => $error->getMessage() );
} finally {
	wp_set_current_user( 1 );
	foreach ( $ids as $id ) {
		if ( get_post( $id ) ) {
			wp_delete_post( $id, true );
		}
	}
}
$failed = count( array_filter( $checks, static fn( $check ) => ! $check['ok'] ) );
$report = array(
	'plugin_version' => F3_MCP_FILES_VERSION,
	'wordpress' => get_bloginfo( 'version' ),
	'php' => PHP_VERSION,
	'environment' => 'Real WordPress with SQLite Database Integration; no stubs for WordPress content APIs',
	'empty_trash_days' => EMPTY_TRASH_DAYS,
	'passed' => count( $checks ) - $failed,
	'failed' => $failed,
	'checks' => $checks,
);
if ( ! empty( $argv[3] ) ) {
	file_put_contents( $argv[3], wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) . "\n" );
}
echo wp_json_encode( array_diff_key( $report, array( 'checks' => true ) ) ) . "\n";
exit( $failed ? 1 : 0 );
