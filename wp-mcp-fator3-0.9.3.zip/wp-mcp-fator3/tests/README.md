# Verificações do Fator3

Os scripts que recebem um caminho WordPress devem ser executados somente em instalação descartável, com usuário administrador ID 1, o Fator3 como único plugin ativo e o canal aberto. Os scripts criam e removem fixtures e registram eventos de auditoria. Não os execute em produção.

## Regressões da 0.9.3

Em uma instalação WordPress descartável, adicione `define('F3_DELETE_POST_DISPOSABLE_LAB', true);` ao `wp-config.php`. Não defina `EMPTY_TRASH_DAYS` nesse arquivo durante estes testes: o runner define a constante antes de carregar o WordPress, em dois processos separados.

```bash
php delete-post-093.php /caminho/wordpress enabled trash-enabled.json
php delete-post-093.php /caminho/wordpress disabled trash-disabled.json
```

Requer o Fator3 ativo e administrador ID 1. Cria e remove somente os registros de teste que o runner registra para limpeza. Usa APIs WordPress reais, incluindo Abilities API e metatools, sete tipos de conteúdo, lixeira/restauração, metadados, comentários, permissões e filtros. São 77 verificações com lixeira ativada e 58 com lixeira desativada. Não usa stubs das funções de conteúdo do WordPress. Resultados e limites em `docs/ATUALIZACAO-0.9.3.md` e `docs/validation-0.9.3.json`.

## Regressões da 0.9.2

```bash
php rmdir-092.php rmdir-092.json
```

O runner executa PHP e operações reais de filesystem em uma árvore temporária criada por ele. As funções WordPress são stubs explícitos; esta suíte não substitui a integração em WordPress real. Cobre exclusão de pasta vazia, arquivos/subpastas/ocultos, symlinks, confinamento, capacidades, canal fechado, validações, auditoria, concorrência controlada e preservação da exclusão de arquivos com backup. O teste de concorrência cria um arquivo imediatamente antes da chamada nativa de `rmdir`.

## Regressões da 0.9.1

```bash
php -d memory_limit=64M files-read-delete-091.php /caminho/wordpress regressions-091.json
```

Execute em processo novo: o teste comprova que `request_filesystem_credentials()` ainda não foi carregada antes da primeira exclusão. Exclui somente plugins descartáveis que ele próprio cria e valida o desinstalador real, erros de credenciais/conexão, limpeza de filtros/cache, leitura integral e parcial, filtro literal/PCRE, LF/CRLF, limite de bytes, log de 64 MiB, schemas, metatool e permissões. Requer espaço temporário para esse log.

Resultados e limites desta atualização em `docs/ATUALIZACAO-0.9.1.md` e `docs/validation-0.9.1.json`. A execução local usou WordPress 6.9.4 e PHP 8.3.6, com SQLite Database Integration 3.0.1 somente como banco do laboratório; esse componente não integra o ZIP de produção.

## Suíte herdada da 0.9.0

```bash
php integration.php /caminho/wordpress integration.json
php upstream-regressions.php /caminho/wordpress prs.json
php confine.php /caminho/wordpress wp confine.json
php confine.php /caminho/wordpress edit disallow-edit.json
php confine.php /caminho/wordpress mods disallow-mods.json
```

`integration.php` verifica o inventário original, round-trip de conteúdo e outros campos, arquivos fora de ABSPATH, restauração, SQL em duas fases, gates e o auto-teste. `upstream-regressions.php` verifica as proteções do PR #9 incorporadas pelo upstream. `confine.php` carrega as constantes antes do WordPress.

O relatório em `docs/RELATORIO.md` também documenta testes de migração com o desinstalador real, HTTP/Application Password, OAuth completo e mutação realizados no laboratório. Os arquivos em `upstream/` são testes do repositório de origem preservados como referência; a suíte Playwright upstream não foi executada nesta entrega.
