<?php
/** php confine.php /absolute/wp-root [wp|edit|mods] [report.json] */
if(PHP_SAPI!=='cli'||empty($argv[1]))exit(1);
$mode=$argv[2]??'wp';
if($mode==='wp')define('F3_MCP_FILES_CONFINE','wp');
elseif($mode==='edit')define('DISALLOW_FILE_EDIT',true);
elseif($mode==='mods')define('DISALLOW_FILE_MODS',true);
$_SERVER['HTTP_HOST']='127.0.0.1:8787';$_SERVER['REQUEST_URI']='/';
require rtrim($argv[1],'/').'/wp-load.php';wp_set_current_user(1);
use Fator3\McpFiles\PathGuard;
$c=[];
if($mode==='wp'){
	$c['constant_restores_roots']=PathGuard::roots()===PathGuard::wp_roots()&&count(PathGuard::roots())>=2;
	$c['constant_restores_denylist']=in_array('wp-config.php',PathGuard::denied_basenames(),true)&&in_array('.ssh',PathGuard::denied_basenames(),true);
	$c['constant_denies_wp_config']=is_wp_error(PathGuard::resolve(ABSPATH.'wp-config.php',false));
	$c['constant_allows_theme']=!is_wp_error(PathGuard::resolve(get_theme_root(),false));
	$r=wp_get_ability('files/selftest')->execute([]);
	$c['selftest_with_constant']=!is_wp_error($r)&&$r['failed']===0;
}else{
	add_filter('f3_mcp_files_enabled','__return_true',PHP_INT_MAX);
	$c['constant_cannot_be_overridden']=!PathGuard::is_enabled();
	foreach(['files/read'=>['path'=>ABSPATH.'wp-config.php'],'files/write'=>['path'=>ABSPATH.'f3-not-created.php','content'=>'<?php'],'db/query'=>['sql'=>'SELECT 1']] as $n=>$args){$r=wp_get_ability($n)->execute($args);$c[$n.'_denied']=is_wp_error($r)||empty($r['success']);}
}
$report=['mode'=>$mode,'passed'=>count(array_filter($c)),'failed'=>count(array_filter($c,fn($v)=>!$v)),'checks'=>$c];
if(!empty($argv[3]))file_put_contents($argv[3],json_encode($report,JSON_PRETTY_PRINT));
echo json_encode($report).PHP_EOL;exit($report['failed']?1:0);
