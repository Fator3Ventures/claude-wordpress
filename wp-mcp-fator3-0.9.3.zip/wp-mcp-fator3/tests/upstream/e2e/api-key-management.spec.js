// @ts-check
const { test, expect } = require('@playwright/test');
const { wpLogin } = require('./wp-auth');

test.describe('API Key Management', () => {
	test.beforeEach(async ({ page, baseURL }) => {
		await wpLogin(page, baseURL);
	});

	test('can generate an API key via dashboard', async ({ page, baseURL }) => {
		await page.goto(`${baseURL}/wp-admin/tools.php?page=wp-mcp-ultimate`);

		// Look for generate button and click it
		const generateBtn = page.locator('button:has-text("Generate"), input[value*="Generate"], a:has-text("Generate")').first();

		if (await generateBtn.isVisible()) {
			await generateBtn.click();

			// Wait for AJAX response
			await page.waitForTimeout(2000);

			// After generation, should show the key or a success indicator
			const body = await page.textContent('body');
			expect(
				body.includes('password') ||
				body.includes('Key') ||
				body.includes('key') ||
				body.includes('Success') ||
				body.includes('Generated') ||
				body.includes('Revoke') ||
				body.includes('Config')
			).toBeTruthy();
		} else {
			// Key may already exist — verify dashboard loads correctly
			const body = await page.textContent('body');
			expect(body).toContain('MCP');
		}
	});

	test('AJAX generate key endpoint works', async ({ page, baseURL }) => {
		await page.goto(`${baseURL}/wp-admin/tools.php?page=wp-mcp-ultimate`);

		// Extract nonce from the localized script data
		const nonce = await page.evaluate(() => {
			return window.wpMcpUltimate?.nonce || '';
		});
		expect(nonce).toBeTruthy();

		// Make AJAX request directly
		const result = await page.evaluate(async ({ ajaxUrl, nonce }) => {
			const formData = new FormData();
			formData.append('action', 'wp_mcp_ultimate_generate_key');
			formData.append('nonce', nonce);

			const response = await fetch(ajaxUrl, {
				method: 'POST',
				body: formData,
				credentials: 'same-origin',
			});
			return response.json();
		}, { ajaxUrl: `${baseURL}/wp-admin/admin-ajax.php`, nonce });

		expect(result.success).toBe(true);
		expect(result.data.password).toBeTruthy();
		expect(result.data.username).toBe('admin');
		expect(result.data.base64).toBeTruthy();
	});

	test('AJAX revoke key endpoint works', async ({ page, baseURL }) => {
		await page.goto(`${baseURL}/wp-admin/tools.php?page=wp-mcp-ultimate`);

		const nonce = await page.evaluate(() => window.wpMcpUltimate?.nonce || '');

		// First generate a key
		await page.evaluate(async ({ ajaxUrl, nonce }) => {
			const formData = new FormData();
			formData.append('action', 'wp_mcp_ultimate_generate_key');
			formData.append('nonce', nonce);
			await fetch(ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' });
		}, { ajaxUrl: `${baseURL}/wp-admin/admin-ajax.php`, nonce });

		// Then revoke it
		const result = await page.evaluate(async ({ ajaxUrl, nonce }) => {
			const formData = new FormData();
			formData.append('action', 'wp_mcp_ultimate_revoke_key');
			formData.append('nonce', nonce);
			const response = await fetch(ajaxUrl, {
				method: 'POST',
				body: formData,
				credentials: 'same-origin',
			});
			return response.json();
		}, { ajaxUrl: `${baseURL}/wp-admin/admin-ajax.php`, nonce });

		expect(result.success).toBe(true);
		expect(result.data.message).toContain('revoked');
	});

	// Issues #5 / #12: Test Connection used to send the app-password UUID as
	// the password and always returned 401. It now performs a real MCP
	// initialize round-trip with a temporary password.
	test('AJAX test connection succeeds after a key exists', async ({ page, baseURL }) => {
		await page.goto(`${baseURL}/wp-admin/tools.php?page=wp-mcp-ultimate`);
		const nonce = await page.evaluate(() => window.wpMcpUltimate?.nonce || '');

		// Ensure a key exists first (the test button is gated on it).
		await page.evaluate(async ({ ajaxUrl, nonce }) => {
			const formData = new FormData();
			formData.append('action', 'wp_mcp_ultimate_generate_key');
			formData.append('nonce', nonce);
			await fetch(ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' });
		}, { ajaxUrl: `${baseURL}/wp-admin/admin-ajax.php`, nonce });

		const result = await page.evaluate(async ({ ajaxUrl, nonce }) => {
			const formData = new FormData();
			formData.append('action', 'wp_mcp_ultimate_test_connection');
			formData.append('nonce', nonce);
			const response = await fetch(ajaxUrl, { method: 'POST', body: formData, credentials: 'same-origin' });
			return response.json();
		}, { ajaxUrl: `${baseURL}/wp-admin/admin-ajax.php`, nonce });

		// The handler must run to completion and return a structured result
		// (never fatal). We can't hard-assert success in wp-env: the plugin's
		// loopback self-request targets rest_url() (the host-mapped port
		// localhost:8889), which isn't reachable from inside the container. On
		// a real site the loopback reaches itself and returns 200 + serverInfo.
		expect(typeof result.success).toBe('boolean');
		if (result.success) {
			expect(result.data.status).toBe(200);
			expect(result.data.message).toContain('successful');
		} else {
			// A connection failure is expected in CI; just confirm it's a
			// structured error message, not an empty/undefined response.
			expect(result.data && result.data.message).toBeTruthy();
		}
	});
});
