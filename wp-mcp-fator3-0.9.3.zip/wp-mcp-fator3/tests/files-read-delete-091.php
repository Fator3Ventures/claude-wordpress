<?php
/** Run only on disposable WordPress: php files-read-delete-091.php WP_ROOT [report.json]. */
declare(strict_types=1);
if ( PHP_SAPI !== 'cli' || empty( $argv[1] ) ) { exit( 1 ); }
$_SERVER['HTTP_HOST'] = '127.0.0.1:8787';
$_SERVER['REQUEST_URI'] = '/';
require rtrim( $argv[1], '/' ) . '/wp-load.php';
wp_set_current_user( 1 );

$checks = array();
$fixtures = array();
$prefix = 'f3-regression-091-' . bin2hex( random_bytes( 5 ) );
$marker = $prefix . '-uninstall';
$log = sys_get_temp_dir() . '/' . $prefix . '.log';
$big = sys_get_temp_dir() . '/' . $prefix . '-large.log';

function verify091( string $name, bool $ok ): void {
	global $checks;
	$checks[] = array( 'test' => $name, 'ok' => $ok );
}
function call091( string $name, array $args ): array {
	$result = wp_get_ability( $name )->execute( $args );
	if ( is_wp_error( $result ) || ! is_array( $result ) || empty( $result['success'] ) ) {
		throw new RuntimeException( $name . ': ' . wp_json_encode( $result ) );
	}
	$valid = rest_validate_value_from_schema( $result, wp_get_ability( $name )->get_output_schema() );
	if ( is_wp_error( $valid ) ) { throw new RuntimeException( 'Output schema: ' . $valid->get_error_message() ); }
	return $result;
}
function refused091( string $name, array $args ): bool {
	$result = wp_get_ability( $name )->execute( $args );
	return is_wp_error( $result ) || ( is_array( $result ) && empty( $result['success'] ) );
}
function fixture091( string $suffix ): string {
	global $prefix, $fixtures;
	$slug = $prefix . '-' . $suffix;
	$dir = WP_PLUGIN_DIR . '/' . $slug;
	mkdir( $dir );
	file_put_contents( $dir . '/fixture.php', "<?php\n/* Plugin Name: Fator3 temporary regression fixture */\n" );
	$fixtures[] = $dir;
	wp_clean_plugins_cache( false );
	return $slug . '/fixture.php';
}

try {
	$delete = wp_get_ability( 'plugins/delete' );
	verify091( 'cold_request_has_no_filesystem_credentials_function', ! function_exists( 'request_filesystem_credentials' ) );
	$plugin = fixture091( 'delete' );
	file_put_contents( WP_PLUGIN_DIR . '/' . dirname( $plugin ) . '/uninstall.php', "<?php\nif (defined('WP_UNINSTALL_PLUGIN')) update_option(" . var_export( $marker, true ) . ", 'called');\n" );
	ob_start();
	$result = call091( 'plugins/delete', array( 'plugin' => $plugin ) );
	$output = ob_get_clean();
	clearstatcache();
	verify091( 'delete_inactive_plugin_files_and_directory', ! file_exists( WP_PLUGIN_DIR . '/' . dirname( $plugin ) ) );
	verify091( 'delete_runs_real_uninstall_hook', 'called' === get_option( $marker ) );
	verify091( 'delete_loads_filesystem_functions', function_exists( 'request_filesystem_credentials' ) );
	verify091( 'delete_does_not_emit_html', '' === $output );
	verify091( 'delete_refuses_active_fator3', refused091( 'plugins/delete', array( 'plugin' => 'wp-mcp-fator3/wp-mcp-fator3.php' ) ) && is_file( F3_MCP_FILES_DIR . 'wp-mcp-fator3.php' ) );
	verify091( 'delete_refuses_missing_plugin', refused091( 'plugins/delete', array( 'plugin' => $plugin ) ) );
	verify091( 'delete_removes_temporary_credential_filter', ! isset( $GLOBALS['wp_filter']['request_filesystem_credentials'] ) || empty( $GLOBALS['wp_filter']['request_filesystem_credentials']->callbacks ) );

	$plugin = fixture091( 'credentials' );
	$missing_credentials = static function () { echo '<form>FTP credentials</form>'; return false; };
	add_filter( 'request_filesystem_credentials', $missing_credentials );
	ob_start();
	try { $refused = refused091( 'plugins/delete', array( 'plugin' => $plugin ) ); }
	finally { remove_filter( 'request_filesystem_credentials', $missing_credentials ); $output = ob_get_clean(); }
	verify091( 'credentials_required_is_structured_error', $refused && '' === $output && is_file( WP_PLUGIN_DIR . '/' . $plugin ) );

	$unavailable_method = static fn() => 'f3_missing_filesystem_transport';
	add_filter( 'filesystem_method', $unavailable_method );
	add_filter( 'request_filesystem_credentials', '__return_true' );
	ob_start();
	try { $refused = refused091( 'plugins/delete', array( 'plugin' => $plugin ) ); }
	finally {
		remove_filter( 'filesystem_method', $unavailable_method );
		remove_filter( 'request_filesystem_credentials', '__return_true' );
		$output = ob_get_clean();
	}
	verify091( 'filesystem_connection_failure_is_error_without_exit_or_html', $refused && '' === $output && is_file( WP_PLUGIN_DIR . '/' . $plugin ) );
	call091( 'plugins/delete', array( 'plugin' => $plugin ) );
	verify091( 'filesystem_failure_does_not_poison_next_call', ! is_file( WP_PLUGIN_DIR . '/' . $plugin ) );

	$content = "INFO first\nERROR alpha\ninfo lower\nERROR beta\r\n\nEND";
	file_put_contents( $log, $content );
	$r = call091( 'files/read', array( 'path' => $log ) );
	verify091( 'legacy_full_read_content_bytes_hash_and_shape', $r['content'] === $content && $r['bytes'] === strlen( $content ) && $r['sha256'] === hash( 'sha256', $content ) && ! isset( $r['partial'] ) );
	$cases = array(
		'tail' => array( array( 'tail_lines' => 2 ), "\nEND", true, 2 ),
		'tail_offset' => array( array( 'tail_lines' => 2, 'offset' => 1 ), "ERROR beta\r\n\n", true, 3 ),
		'page' => array( array( 'offset' => 1, 'limit' => 2 ), "ERROR alpha\ninfo lower\n", true, 3 ),
		'grep_before_offset' => array( array( 'grep' => 'ERROR', 'offset' => 1, 'limit' => 2 ), "ERROR beta\r\n", false, null ),
		'grep_before_tail' => array( array( 'grep' => 'ERROR', 'tail_lines' => 1 ), "ERROR beta\r\n", true, 1 ),
		'grep_tail_previous_page' => array( array( 'grep' => 'ERROR', 'tail_lines' => 1, 'offset' => 1 ), "ERROR alpha\n", false, null ),
		'grep_case_sensitive' => array( array( 'grep' => 'info' ), "info lower\n", false, null ),
		'regex_case_insensitive_and_crlf_anchor' => array( array( 'grep' => '/^error (alpha|beta)$/i', 'grep_regex' => true ), "ERROR alpha\nERROR beta\r\n", false, null ),
		'no_matches' => array( array( 'grep' => 'not present' ), '', false, null ),
		'offset_past_end' => array( array( 'offset' => 99 ), '', false, null ),
		'tail_offset_past_end' => array( array( 'tail_lines' => 2, 'offset' => 99 ), '', false, null ),
	);
	foreach ( $cases as $name => [ $args, $expected, $more, $next ] ) {
		$r = call091( 'files/read', array( 'path' => $log ) + $args );
		verify091( 'read_' . $name, $r['content'] === $expected && $r['has_more'] === $more && $r['next_offset'] === $next && $r['bytes'] === strlen( $expected ) );
		verify091( 'partial_hash_scope_' . $name, $r['partial'] && $r['sha256_scope'] === 'returned_content' && $r['sha256'] === hash( 'sha256', $expected ) && $r['file_bytes'] === strlen( $content ) );
	}
	$invalid = array(
		array( 'tail_lines' => 0 ), array( 'tail_lines' => -1 ), array( 'tail_lines' => 10001 ),
		array( 'offset' => -1 ), array( 'offset' => 0.5 ), array( 'limit' => 0 ), array( 'limit' => 10001 ),
		array( 'limit' => 1, 'tail_lines' => 1 ), array( 'grep' => 12 ), array( 'grep' => str_repeat( 'x', 4097 ) ),
		array( 'grep_regex' => true ), array( 'grep' => '/[invalid/', 'grep_regex' => true ),
		array( 'grep_regex' => 'yes' ),
	);
	foreach ( $invalid as $i => $args ) { verify091( 'invalid_input_' . $i, refused091( 'files/read', array( 'path' => $log ) + $args ) ); }

	foreach ( array( '', "\n", 'x', "x\n", "x\n\n", "a\r\nb", "\r\n", "a\rb\r", str_repeat( 'a', 65535 ) . "\r\nç\n" ) as $i => $text ) {
		file_put_contents( $log, $text );
		foreach ( array( array( 'tail_lines' => 10 ), array( 'limit' => 10 ) ) as $args ) {
			$r = call091( 'files/read', array( 'path' => $log ) + $args );
			verify091( 'line_endings_' . $i . '_' . key( $args ), $r['content'] === $text && ! $r['has_more'] );
		}
	}
	file_put_contents( $log, "A.B\nAXB\n0\nCR\r" );
	verify091( 'grep_literal_metacharacters', call091( 'files/read', array( 'path' => $log, 'grep' => 'A.B' ) )['content'] === "A.B\n" );
	verify091( 'grep_literal_zero', call091( 'files/read', array( 'path' => $log, 'grep' => '0' ) )['content'] === "0\n" );
	verify091( 'grep_preserves_lone_carriage_return', call091( 'files/read', array( 'path' => $log, 'grep' => "CR\r" ) )['content'] === "CR\r" );

	file_put_contents( $log, "aaa\nbbb\nccc\n" );
	$cap = static fn() => 8;
	add_filter( 'f3_mcp_files_max_bytes', $cap );
	try {
		$r = call091( 'files/read', array( 'path' => $log, 'limit' => 10 ) );
		verify091( 'byte_cap_preserves_whole_lines_and_cursor', $r['content'] === "aaa\nbbb\n" && $r['bytes'] === 8 && $r['next_offset'] === 2 );
		$r = call091( 'files/read', array( 'path' => $log, 'tail_lines' => 10 ) );
		verify091( 'byte_cap_tail_preserves_recent_lines', $r['content'] === "bbb\nccc\n" && $r['next_offset'] === 2 );
		$r = call091( 'files/read', array( 'path' => $log, 'limit' => 10, 'offset' => 2 ) );
		verify091( 'byte_cap_next_page', $r['content'] === "ccc\n" && ! $r['has_more'] );
		file_put_contents( $log, str_repeat( 'x', 9 ) );
		verify091( 'oversized_line_is_explicit_error', refused091( 'files/read', array( 'path' => $log, 'limit' => 1 ) ) );
	} finally { remove_filter( 'f3_mcp_files_max_bytes', $cap ); }

	$handle = fopen( $big, 'wb' );
	$block = str_repeat( str_repeat( 'i', 63 ) . "\n", 16384 );
	for ( $i = 0; $i < 64; ++$i ) { fwrite( $handle, $block ); }
	fwrite( $handle, "ERROR older\nINFO final\nERROR latest\n" );
	fclose( $handle );
	unset( $block );
	verify091( 'legacy_large_file_rejected', refused091( 'files/read', array( 'path' => $big ) ) );
	$r = call091( 'files/read', array( 'path' => $big, 'tail_lines' => 2 ) );
	verify091( 'tail_64_mib_log', $r['content'] === "INFO final\nERROR latest\n" && $r['file_bytes'] > 64 * 1024 * 1024 );
	$r = call091( 'files/read', array( 'path' => $big, 'offset' => 1048576, 'limit' => 3 ) );
	verify091( 'offset_64_mib_log', $r['content'] === "ERROR older\nINFO final\nERROR latest\n" && ! $r['has_more'] );
	$r = call091( 'files/read', array( 'path' => $big, 'grep' => 'ERROR', 'tail_lines' => 1 ) );
	verify091( 'grep_tail_64_mib_log', $r['content'] === "ERROR latest\n" && $r['has_more'] );
	$r = call091( 'files/read', array( 'path' => $big, 'grep' => 'ABSENT', 'limit' => 1 ) );
	verify091( 'grep_scans_large_file_without_matches', '' === $r['content'] && ! $r['has_more'] );

	file_put_contents( $log, "one\ntwo\nthree\n" );
	$r = call091( 'wp-mcp-ultimate/execute-ability', array( 'ability_name' => 'files/read', 'parameters' => wp_json_encode( array( 'path' => $log, 'tail_lines' => 1 ) ) ) );
	verify091( 'metatool_executes_new_parameters', $r['data']['content'] === "three\n" );
	$schema = wp_get_ability( 'files/read' )->get_input_schema();
	verify091( 'schema_exposes_all_new_parameters', ! array_diff( array( 'offset', 'limit', 'tail_lines', 'grep', 'grep_regex' ), array_keys( $schema['properties'] ) ) );
	$expected = json_decode( file_get_contents( __DIR__ . '/expected-abilities.json' ), true );
	verify091( 'all_original_abilities_preserved', ! array_diff( $expected, array_keys( wp_get_abilities() ) ) );

	add_filter( 'f3_mcp_files_enabled', '__return_false', PHP_INT_MAX );
	try { verify091( 'partial_read_respects_closed_channel', refused091( 'files/read', array( 'path' => $log, 'tail_lines' => 1 ) ) ); }
	finally { remove_filter( 'f3_mcp_files_enabled', '__return_false', PHP_INT_MAX ); }
	$confine = static fn() => array( get_theme_root() );
	add_filter( 'f3_mcp_files_roots', $confine, PHP_INT_MAX );
	try { verify091( 'partial_read_respects_confinement', refused091( 'files/read', array( 'path' => $log, 'tail_lines' => 1 ) ) ); }
	finally { remove_filter( 'f3_mcp_files_roots', $confine, PHP_INT_MAX ); }
	wp_set_current_user( 0 );
	verify091( 'anonymous_cannot_read', refused091( 'files/read', array( 'path' => $log, 'limit' => 1 ) ) );
	verify091( 'anonymous_cannot_delete', refused091( 'plugins/delete', array( 'plugin' => 'wp-mcp-fator3/wp-mcp-fator3.php' ) ) );
	wp_set_current_user( 1 );
	verify091( 'memory_below_64_mib_file_size', memory_get_peak_usage( true ) < 64 * 1024 * 1024 );
} catch ( Throwable $e ) {
	while ( ob_get_level() ) { ob_end_clean(); }
	$checks[] = array( 'test' => 'unexpected_exception', 'ok' => false, 'detail' => $e->getMessage() );
} finally {
	wp_set_current_user( 1 );
	delete_option( $marker );
	foreach ( $fixtures as $dir ) {
		foreach ( array( '/fixture.php', '/uninstall.php' ) as $suffix ) { if ( is_file( $dir . $suffix ) ) { unlink( $dir . $suffix ); } }
		if ( is_dir( $dir ) ) { rmdir( $dir ); }
	}
	foreach ( array( $log, $big ) as $file ) { if ( is_file( $file ) ) { unlink( $file ); } }
	wp_clean_plugins_cache( false );
}
$failed = count( array_filter( $checks, static fn( $row ) => ! $row['ok'] ) );
$report = array( 'wordpress' => get_bloginfo( 'version' ), 'php' => PHP_VERSION, 'passed' => count( $checks ) - $failed, 'failed' => $failed, 'peak_memory_bytes' => memory_get_peak_usage( true ), 'checks' => $checks );
if ( ! empty( $argv[2] ) ) { file_put_contents( $argv[2], wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); }
echo wp_json_encode( array( 'passed' => $report['passed'], 'failed' => $failed, 'peak_memory_bytes' => $report['peak_memory_bytes'], 'failures' => array_values( array_filter( $checks, static fn( $row ) => ! $row['ok'] ) ) ), JSON_UNESCAPED_UNICODE ) . PHP_EOL;
exit( $failed ? 1 : 0 );
