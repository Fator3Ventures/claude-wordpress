<?php
/** PHP/real-filesystem regression harness; WordPress API calls use explicit stubs. */
declare(strict_types=1);
namespace Fator3\McpFiles {
	function rmdir( $path ) {
		if ( isset( $GLOBALS['before_rmdir'] ) ) { ( $GLOBALS['before_rmdir'] )( $path ); }
		return \rmdir( $path );
	}
}
namespace {
	if ( PHP_SAPI !== 'cli' ) { exit( 1 ); }
	$root = sys_get_temp_dir() . '/f3-rmdir-092-' . bin2hex( random_bytes( 8 ) );
	mkdir( $root . '/wp/wp-content/plugins/self', 0777, true );
	mkdir( $root . '/wp/wp-content/themes', 0777, true );
	define( 'ABSPATH', $root . '/wp/' );
	define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
	define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );
	define( 'F3_MCP_FILES_DIR', WP_PLUGIN_DIR . '/self/' );
	$options = array(); $filters = array(); $caps = array( 'edit_themes' => true, 'manage_options' => true );
	$abilities = array(); $checks = array();
	class WP_Error {
		public function __construct( public string $code, public string $message ) {}
		public function get_error_message(): string { return $this->message; }
		public function get_error_code(): string { return $this->code; }
	}
	function is_wp_error( $value ): bool { return $value instanceof WP_Error; }
	function __( $text, $domain = '' ) { return $text; }
	function esc_html( $text ) { return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' ); }
	function esc_html__( $text, $domain = '' ) { return esc_html( $text ); }
	function wp_normalize_path( $path ) { return str_replace( '\\', '/', $path ); }
	function untrailingslashit( $path ) { return rtrim( $path, '/\\' ); }
	function get_option( $key, $default = false ) { return $GLOBALS['options'][ $key ] ?? $default; }
	function update_option( $key, $value, $autoload = null ) { $GLOBALS['options'][ $key ] = $value; return true; }
	function current_user_can( $cap ) { return $GLOBALS['caps'][ $cap ] ?? false; }
	function apply_filters( $name, $value, ...$args ) { return isset( $GLOBALS['filters'][ $name ] ) ? ( $GLOBALS['filters'][ $name ] )( $value, ...$args ) : $value; }
	function get_theme_root() { return WP_CONTENT_DIR . '/themes'; }
	function get_current_user_id() { return 1; }
	function wp_mkdir_p( $path ) { return is_dir( $path ) || mkdir( $path, 0777, true ); }
	function wp_json_encode( $value ) { return json_encode( $value ); }
	function wp_register_ability( $name, $args ) { $GLOBALS['abilities'][ $name ] = $args; }
	function check092( string $name, bool $ok ) { $GLOBALS['checks'][] = array( 'test' => $name, 'ok' => $ok ); }
	function remove092( string $path, array $args = array() ): array {
		return ( $GLOBALS['abilities']['files/delete']['execute_callback'] )( array( 'path' => $path ) + $args );
	}
	function dir092( string $path ): string { mkdir( $path, 0777, true ); return $path; }
	require __DIR__ . '/../includes/PathGuard.php';
	require __DIR__ . '/../includes/FileReader.php';
	require __DIR__ . '/../includes/Files.php';
	\Fator3\McpFiles\Files::register();
	try {
		$schema = $abilities['files/delete']['input_schema'];
		check092( 'boolean_flag_defaults_false', $schema['properties']['empty_dir']['type'] === 'boolean' && $schema['properties']['empty_dir']['default'] === false );
		check092( 'recursive_option_not_accepted_by_schema', $schema['additionalProperties'] === false && ! isset( $schema['properties']['recursive'] ) );
		$empty = dir092( ABSPATH . 'empty' );
		check092( 'legacy_call_refuses_empty_directory', ! remove092( 'empty' )['success'] && is_dir( $empty ) );
		check092( 'false_flag_refuses_directory', ! remove092( 'empty', array( 'empty_dir' => false ) )['success'] && is_dir( $empty ) );
		check092( 'invalid_flag_is_rejected', ! remove092( 'empty', array( 'empty_dir' => 'true' ) )['success'] && is_dir( $empty ) );
		$r = remove092( 'empty', array( 'empty_dir' => true ) );
		check092( 'relative_empty_directory_removed', $r['success'] && ! file_exists( $empty ) && $r['path'] === 'empty' );
		check092( 'empty_directory_has_no_fake_backup', $r['backup_id'] === '' && ! is_dir( WP_CONTENT_DIR . '/f3-mcp-backups' ) );
		$log = get_option( 'f3_mcp_files_audit' );
		check092( 'audit_records_rmdir', count( $log ) === 1 && $log[0]['action'] === 'rmdir' && $log[0]['path'] === 'empty' );
		$empty = dir092( $root . '/outside' );
		check092( 'absolute_outside_wordpress_supported', remove092( $empty, array( 'empty_dir' => true ) )['success'] && ! file_exists( $empty ) );
		$empty = dir092( ABSPATH . 'suffix' );
		check092( 'trailing_slash_supported', remove092( $empty . '/', array( 'empty_dir' => true ) )['success'] && ! file_exists( $empty ) );
		$parent = dir092( ABSPATH . 'parent/child' );
		check092( 'subdirectory_counts_as_content', ! remove092( ABSPATH . 'parent', array( 'empty_dir' => true ) )['success'] && is_dir( $parent ) );
		check092( 'only_named_child_removed', remove092( $parent, array( 'empty_dir' => true ) )['success'] && is_dir( dirname( $parent ) ) );
		foreach ( array( 'regular.txt', '.hidden', '0' ) as $entry ) {
			$dir = dir092( $root . '/entry-' . bin2hex( random_bytes( 3 ) ) );
			file_put_contents( $dir . '/' . $entry, 'keep' );
			check092( 'nonempty_' . $entry, ! remove092( $dir, array( 'empty_dir' => true ) )['success'] && file_get_contents( $dir . '/' . $entry ) === 'keep' );
		}
		$empty = dir092( $root . '/target' ); $link = $root . '/link'; symlink( $empty, $link );
		foreach ( array( '', '/', '/.' ) as $suffix ) {
			check092( 'symlink_target_preserved_' . $suffix, ! remove092( $link . $suffix, array( 'empty_dir' => true ) )['success'] && is_dir( $empty ) && is_link( $link ) );
		}
		$holder = dir092( $root . '/holder' ); symlink( $root . '/missing-target', $holder . '/dangling' );
		check092( 'dangling_child_symlink_counts_as_content', ! remove092( $holder, array( 'empty_dir' => true ) )['success'] && is_link( $holder . '/dangling' ) );
		check092( 'missing_directory_refused', ! remove092( $root . '/not-found', array( 'empty_dir' => true ) )['success'] );
		check092( 'self_directory_protected', ! remove092( F3_MCP_FILES_DIR, array( 'empty_dir' => true ) )['success'] && is_dir( F3_MCP_FILES_DIR ) );
		$filters['f3_mcp_files_roots'] = static fn() => array( ABSPATH );
		check092( 'confinement_applies', ! remove092( $empty, array( 'empty_dir' => true ) )['success'] && is_dir( $empty ) );
		symlink( $empty, ABSPATH . 'outside-link' );
		check092( 'confinement_checks_parent_symlinks', ! remove092( ABSPATH . 'outside-link/.', array( 'empty_dir' => true ) )['success'] && is_dir( $empty ) );
		unset( $filters['f3_mcp_files_roots'] );
		$filters['f3_mcp_files_enabled'] = static fn() => false;
		check092( 'closed_channel_blocks_rmdir', ! remove092( $empty, array( 'empty_dir' => true ) )['success'] && is_dir( $empty ) );
		check092( 'permission_callback_respects_channel', ! ( $abilities['files/delete']['permission_callback'] )() );
		unset( $filters['f3_mcp_files_enabled'] );
		$caps['manage_options'] = false;
		check092( 'capabilities_block_rmdir', ! remove092( $empty, array( 'empty_dir' => true ) )['success'] && is_dir( $empty ) );
		check092( 'permission_callback_respects_capabilities', ! ( $abilities['files/delete']['permission_callback'] )() );
		$caps['manage_options'] = true;
		foreach ( array( 'php://filter/x', "{$empty}\0", '' ) as $bad ) {
			check092( 'invalid_path_' . bin2hex( $bad ), ! remove092( $bad, array( 'empty_dir' => true ) )['success'] );
		}
		check092( 'file_hash_refused_for_directory', ! remove092( $empty, array( 'empty_dir' => true, 'expected_sha256' => '0' ) )['success'] && is_dir( $empty ) );
		$filters['f3_mcp_files_allowed_extensions'] = static fn() => array( 'php' );
		check092( 'file_extension_filter_does_not_apply_to_directory', remove092( $empty, array( 'empty_dir' => true ) )['success'] );
		unset( $filters['f3_mcp_files_allowed_extensions'] );
		$race = dir092( $root . '/race' );
		$before_rmdir = static function ( $path ) { file_put_contents( $path . '/arrived.txt', 'keep' ); };
		$count = count( get_option( 'f3_mcp_files_audit' ) );
		check092( 'concurrent_content_is_preserved_by_native_rmdir', ! remove092( $race, array( 'empty_dir' => true ) )['success'] && file_get_contents( $race . '/arrived.txt' ) === 'keep' );
		unset( $before_rmdir );
		check092( 'failed_rmdir_not_audited_as_success', count( get_option( 'f3_mcp_files_audit' ) ) === $count );
		$file = $root . '/file.txt'; file_put_contents( $file, 'preserve file' );
		check092( 'directory_mode_never_deletes_files', ! remove092( $file, array( 'empty_dir' => true ) )['success'] && file_get_contents( $file ) === 'preserve file' );
		check092( 'legacy_stale_hash_still_blocks_file_delete', ! remove092( $file, array( 'expected_sha256' => str_repeat( '0', 64 ) ) )['success'] && is_file( $file ) );
		$r = remove092( $file );
		check092( 'legacy_file_deletion_and_backup_preserved', $r['success'] && ! is_file( $file ) && $r['backup_id'] !== '' && file_get_contents( WP_CONTENT_DIR . '/f3-mcp-backups/' . $r['backup_id'] . '.bak' ) === 'preserve file' );
		$expected = json_decode( file_get_contents( __DIR__ . '/expected-abilities.json' ), true );
		$expected_files = array_values( array_filter( $expected, static fn( $n ) => str_starts_with( $n, 'files/' ) ) );
		check092( 'file_ability_inventory_preserved', ! array_diff( $expected_files, array_keys( $abilities ) ) );
	} catch ( \Throwable $e ) {
		$checks[] = array( 'test' => 'unexpected_exception', 'ok' => false, 'detail' => $e->getMessage() );
	} finally {
		$iterator = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS ), \RecursiveIteratorIterator::CHILD_FIRST );
		foreach ( $iterator as $item ) { if ( $item->isLink() || ! $item->isDir() ) { unlink( $item->getPathname() ); } else { \rmdir( $item->getPathname() ); } }
		\rmdir( $root );
	}
	$failed = count( array_filter( $checks, static fn( $row ) => ! $row['ok'] ) );
	$report = array( 'php' => PHP_VERSION, 'environment' => 'WordPress API stubs; actual PHP filesystem operations', 'passed' => count( $checks ) - $failed, 'failed' => $failed, 'checks' => $checks );
	if ( ! empty( $argv[1] ) ) { file_put_contents( $argv[1], json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); }
	echo json_encode( $report, JSON_UNESCAPED_UNICODE ) . PHP_EOL;
	exit( $failed ? 1 : 0 );
}
