# WP MCP Fator3 0.9.1

Atualização de 08/09/2026 sobre o ZIP `wp-mcp-fator3-0.9.0.zip` entregue anteriormente. Inclui a correção de exclusão de plugins e leitura parcial/filtrada de arquivos. O complemento Google permanece independente.

## Origem das habilidades

| Habilidade | Origem | Arquivo na versão unificada |
|---|---|---|
| `plugins/delete` | WP MCP Ultimate; já estava no ZIP original recebido | `core/includes/Abilities/Plugins/Plugins.php` |
| `files/read` | Complemento Fator3 0.8.0; já estava no complemento original recebido | `includes/Files.php` |

O arquivo `Plugins.php` do Ultimate original e o arquivo incorporado ao Fator3 0.9.0 são **idênticos byte a byte**, com SHA-256 `953fe10c87e6941f56bcc2a713416aea350a1b7bf34b9b3824cf6f6f872af05a`. Portanto, tanto a habilidade quanto essa falta de carregamento vieram do Ultimate e permaneceram na unificação. A regressão não havia sido detectada pela validação da 0.9.0.

## Exclusão de plugins

A habilidade chama `delete_plugins()`. É essa função do WordPress que chama internamente `request_filesystem_credentials()`. As funções `request_filesystem_credentials()` e `WP_Filesystem()` são definidas em `wp-admin/includes/file.php`, que não é carregado automaticamente nessa requisição MCP. A dependência é carregada antes da operação:

```php
require_once ABSPATH . 'wp-admin/includes/file.php';
```

A localização da função e o fluxo interno estão na [referência de delete_plugins()](https://developer.wordpress.org/reference/functions/delete_plugins/). O [controlador REST de plugins do WordPress](https://developer.wordpress.org/reference/classes/wp_rest_plugins_controller/delete_item/) também carrega esse arquivo explicitamente.

A versão 0.9.1 também:

- Obtém as credenciais configuradas sem deixar um formulário FTP/SSH entrar na resposta MCP.
- Retorna `success=false` quando faltam credenciais ou quando o filesystem falha. Um filtro temporário impede que o tratamento de erro do WordPress abra uma página administrativa e encerre a requisição; o filtro é removido em `finally`.
- Só informa sucesso quando `delete_plugins()` retorna `true`.
- Limpa o cache de plugins após a exclusão. O teste de duas chamadas seguidas encontrou o inventário desatualizado e comprovou a correção.
- Mantém a capacidade `delete_plugins`, a recusa de plugin ativo e a execução do desinstalador nativo do plugin excluído.

## Contrato de files/read

**Apenas `path`:** preserva a leitura integral e a resposta anterior, incluindo conteúdo, bytes e SHA-256 do arquivo. O limite padrão continua sendo 16 MiB, ajustável por `f3_mcp_files_max_bytes`.

Informar qualquer opção abaixo ativa a leitura por linhas:

| Parâmetro | Tipo e padrão | Comportamento |
|---|---|---|
| `tail_lines` | Inteiro de 1 a 10.000; opcional | Seleciona as últimas N linhas correspondentes. O retorno mantém a ordem original. |
| `offset` | Inteiro >= 0; padrão 0 | Pula essa quantidade de linhas correspondentes. Com `tail_lines`, conta do fim; nos demais casos, do início. A unidade é linha. |
| `limit` | Inteiro de 1 a 10.000; padrão 1.000 no modo parcial | Tamanho máximo da página contada do início. Não combinar com `tail_lines`. |
| `grep` | String; padrão vazio | Filtra por substring literal, sensível a maiúsculas/minúsculas. Vazio aceita todas as linhas. Máximo de 4.096 bytes. |
| `grep_regex` | Booleano; padrão `false` | Interpreta `grep` como PCRE com delimitadores, por exemplo `/error\|fatal/i`. Erros de sintaxe e de execução retornam erro estruturado. |

**Ordem:** filtrar com `grep`, aplicar `offset`, selecionar até `limit` ou `tail_lines`. O filtro considera uma linha sem seu terminador LF/CRLF; o conteúdo devolvido preserva os terminadores originais. Não há execução de comandos de shell.

### Exemplos de parâmetros da habilidade

Últimas 100 linhas do log:

```json
{"path":"wp-content/debug.log","tail_lines":100}
```

As 100 linhas anteriores, em um arquivo que não mudou entre chamadas:

```json
{"path":"wp-content/debug.log","tail_lines":100,"offset":100}
```

Últimas 50 ocorrências de erro fatal:

```json
{"path":"wp-content/debug.log","grep":"PHP Fatal error","tail_lines":50}
```

Uma página de 200 linhas depois das primeiras 1.000 linhas:

```json
{"path":"/home/usuario/logs/dominio/https/access.log","offset":1000,"limit":200}
```

Filtro por expressão regular:

```json
{"path":"wp-content/debug.log","grep":"/fatal|warning/i","grep_regex":true,"tail_lines":100}
```

No metatool Execute Ability, use `ability_name="files/read"` e esses objetos em `parameters`. Caminhos dos exemplos precisam corresponder a arquivos existentes e alcançáveis pelo PHP; o `path` continua aceitando absolutos e relativos à raiz do WordPress.

### Resposta e limites

- `bytes`: quantidade de bytes efetivamente devolvidos no conteúdo.
- `file_bytes`: tamanho do arquivo observado ao abrir, no modo por linhas.
- `returned_lines`: quantidade de linhas devolvidas.
- `has_more`: há mais linhas correspondentes na direção escolhida.
- `next_offset`: deslocamento para a próxima página, mantendo os demais parâmetros; `null` quando a consulta terminou.
- `mode`: `lines` ou `tail`. `partial=true` identifica o modo por linhas, mesmo quando um arquivo pequeno coube inteiro na seleção.
- `sha256_scope="returned_content"`: no modo parcial, o hash cobre somente o trecho devolvido. Para obter `expected_sha256` de uma escrita, use a leitura integral do arquivo.

O modo parcial aceita logs acima de 16 MiB, limita o conteúdo da resposta pelo filtro de bytes existente e não corta linhas ao atingir esse teto. Uma linha isolada maior que o limite gera erro explícito; o mesmo limite é aplicado ao montar as linhas durante a busca. Um filtro sem correspondências devolve sucesso com conteúdo vazio e `has_more=false`.

O leitor percorre blocos de 64 KiB; `tail_lines` começa pelo final. Buscas sem correspondências podem precisar percorrer o arquivo inteiro. A duração depende do tamanho, armazenamento e limites de execução da hospedagem. O tamanho inicial delimita cada chamada; não existe snapshot persistente entre páginas. Crescimento, rotação ou reescrita do log entre chamadas pode alterar quais linhas um offset seleciona. LF e CRLF são separadores suportados; CR isolado é preservado como conteúdo.

Permissões, canal fechado, confinamento opcional, validação de caminhos e demais regras existentes são aplicados antes da leitura parcial.

## Como a atualização foi verificada

1. Extração e comparação dos ZIPs originais do Ultimate, complemento e Fator3 0.9.0.
2. Reprodução do erro usando o `Plugins.php` original da 0.9.0 em uma nova requisição WordPress: `Call to undefined function request_filesystem_credentials()`.
3. Execução da habilidade corrigida em WordPress real local, removendo um plugin descartável criado pela suíte e confirmando o desinstalador nativo.
4. Validação das novas opções pelo schema da Abilities API nativa e pelo metatool Execute Ability, além de conteúdo, paginação, filtros, permissões, LF/CRLF e arquivos grandes.

| Verificação executada | Resultado |
|---|---|
| Regressões específicas da 0.9.1 | 85 aprovadas; 0 falhas |
| Suíte de integração herdada | 105 aprovadas; 0 falhas funcionais |
| Sintaxe PHP | 96 arquivos verificados; 0 erros |
| Arquivo grande | Log de 64 MiB + sufixo; tail, offset e grep corretos |
| Memória máxima da suíte específica | 40 MiB, com `memory_limit=64M` |
| Inventário | Todos os nomes originais preservados; nenhuma nova metatool |

Ambiente: WordPress 6.9.4, PHP 8.3.6 e SQLite Database Integration 3.0.1 como banco do laboratório. O componente SQLite não acompanha o plugin de produção. A suíte herdada emitiu avisos de validação em schemas de opções e em uma entrada JSON inválida; esses avisos ocorreram em caminhos fora das duas habilidades alteradas. As contagens acima são verificações executadas, não percentuais de cobertura.

Os resultados estruturados estão em `docs/validation-0.9.1.json`; o runner reproduzível fica em `tests/files-read-delete-091.php`. Esta atualização foi validada localmente; a conexão HTTP externa, FTP/SSH reais e a hospedagem do usuário não foram exercitados nesta rodada. Falhas de credenciais/transporte foram simuladas por filtros WordPress; a exclusão pelo filesystem direto e as leituras de arquivos foram reais.

## Instalação e compatibilidade

Envie `wp-mcp-fator3-0.9.1.zip` em **Plugins → Adicionar plugin → Enviar plugin** e escolha substituir a versão instalada. Atualize o mesmo plugin, preservando sua pasta `wp-mcp-fator3` e o arquivo principal `wp-mcp-fator3.php`. Não é necessário desinstalar o Fator3 para atualizar.

O endpoint permanece `/wp-json/mcp/wp-mcp-ultimate`, com Discover Abilities, Get Ability Info e Execute Ability. Configurações, credenciais e integração com o complemento Google são preservadas. Para usar as correções do núcleo integrado, o Ultimate separado deve estar desativado; a regra de coexistência da 0.9.0 continua em vigor.

Esta atualização altera quatro arquivos PHP de produção: o arquivo principal, `includes/Files.php`, o novo `includes/FileReader.php` e `core/includes/Abilities/Plugins/Plugins.php`. A origem do pacote e os hashes estão em `docs/provenance-0.9.1.json`.
