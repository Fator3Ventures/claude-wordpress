# Instalação e migração para 0.9.0

## Atualização do complemento existente

O ZIP tem uma única pasta raiz, `wp-mcp-fator3/`. O arquivo principal continua `wp-mcp-fator3.php`; não renomeie essa pasta ao instalar.

1. Confirme WordPress 6.7+ e PHP 8.0+. O requisito de PHP acompanha o Ultimate integrado; o complemento antigo isolado tinha requisito menor.
2. Para sites que devem continuar limitados a temas/plugins, defina `F3_MCP_FILES_CONFINE` como `'wp'` no `wp-config.php` antes de instalar. Essa é a configuração indicada para o caso korvena descrito no plano.
3. Envie o ZIP pelo instalador do WordPress e substitua o Fator3 atual. Mantenha-o ativo.
4. Desative apenas o WP MCP Ultimate separado, normalmente instalado na pasta `wp-mcp-ultimate-main` ou `wp-mcp-ultimate`.
5. Exclua o Ultimate pelo painel, com o Fator3 ativo. Não exclua a pasta `wp-mcp-fator3`.
6. Abra Ferramentas → MCP Fator3. Em Conexão MCP, confira a URL e execute Test Connection. Esse teste faz `initialize` e `tools/list` e exige as três ferramentas padrão.
7. No conector existente, execute Discover Abilities. Em seguida, Execute Ability com `ability_name: "files/selftest"` e `parameters: {}`. O canal de arquivos precisa estar aberto para esse teste, que cria e remove arquivos temporários próprios.

## O que é preservado

| Item | Comportamento da atualização |
|---|---|
| Slug e arquivo principal Fator3 | Mantidos; atualização sobre o complemento |
| Endpoint e nomes das três ferramentas MCP | Mantidos, inclusive o nome Ultimate na URL |
| Habilidades | Todas as 73 dos dois pacotes, incluindo as três meta-habilidades |
| Application Password existente | Preservada sem alterar o valor; posse migrada para o Fator3 |
| Clientes e tokens OAuth válidos | Migrados, respeitando o prazo de expiração original |
| Canal aberto/fechado, escrita SQL e auditoria | Opções existentes mantidas |
| Backups antigos | Mantidos em `wp-content/f3-mcp-backups` e aceitos na restauração |
| Conteúdo do site | Nenhuma conversão em massa durante a ativação |

O processo foi exercitado com a exclusão real do Ultimate pelo WordPress. A proteção do desinstalador depende de o Fator3 atualizado estar ativo nessa requisição. Se o Ultimate já tiver sido excluído antes disso, ou se suas credenciais já tiverem sido revogadas, configure uma nova autenticação no painel/conector.

Tokens OAuth podem expirar normalmente durante a atualização. A migração não prolonga sua validade. Se um cliente armazenar uma sessão MCP antiga, inicie uma nova sessão usando a mesma autenticação.

## Instalação nova

Instale somente o ZIP Fator3, ative e configure a conexão na aba Conexão MCP. O canal de arquivos e a escrita SQL ficam habilitados na primeira ativação, como no complemento fornecido. Os controles do painel permitem desligá-los.

## Escopo dos controles

Fechar o canal Fator3 bloqueia `files/*` e as rotas de banco que dependem dele. Não equivale a desativar todo o servidor MCP: as habilidades de conteúdo e administração do Ultimate continuam usando suas próprias capacidades. Desativar o plugin inteiro interrompe o servidor integrado.

Desativação preserva configurações e backups. Este pacote não inclui o desinstalador destrutivo do Ultimate. A remoção do próprio Fator3 também deixa os dados preservados para eventual reinstalação.

## Validação na hospedagem

Não houve instalação no site DreamHost citado no plano. A validação entregue foi executada em WordPress local descartável, com HTTP e banco reais. Depois da atualização, Test Connection e `files/selftest` verificam o ambiente da hospedagem. Acesso fora do WordPress continua dependendo das permissões do usuário do PHP e de `open_basedir`.

O auto-teste não lê segredos reais para provar alcance: verifica a resolução dos caminhos e usa arquivos próprios. Não é necessário enviar o conteúdo do `wp-config.php` ao conector para conferir a instalação.
