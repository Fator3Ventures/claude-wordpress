# WP MCP Fator3 0.9.0 — relatório da entrega

Data da revisão: 8 de setembro de 2026.

Foi produzido um plugin autônomo com o mesmo slug `wp-mcp-fator3` e o mesmo arquivo principal do complemento enviado. A instalação final usa somente o Fator3. O pacote contém código-fonte, núcleo integrado, instruções de migração, inventário de habilidades e testes de regressão.

## Atualização: primeiro Fator3, depois excluir Ultimate

1. Envie `wp-mcp-fator3-0.9.0.zip` pelo instalador do WordPress e substitua o complemento atual. Mantenha o Fator3 ativo.
2. Desative e exclua o WP MCP Ultimate separado, mantendo o Fator3 ativo durante a exclusão.
3. Em Ferramentas → MCP Fator3 → Conexão MCP, execute Test Connection. No conector, confira Discover Abilities e execute `files/selftest` com o canal aberto.

Essa ordem é necessária porque o desinstalador do Ultimate remove configurações, senhas de aplicação gerenciadas por ele e dados OAuth. O Fator3 intercepta a etapa anterior à desinstalação, preserva os dados e transfere sua posse. O teste usou o desinstalador real, seguido de autenticação HTTP com a senha antiga e com um token OAuth antigo.

Durante a coexistência, o Fator3 usa temporariamente o núcleo externo para evitar classes duplicadas. O núcleo integrado e suas correções entram em uso depois da desativação do Ultimate. Se o Ultimate já tiver sido excluído e os dados apagados antes dessa atualização, a migração não recupera credenciais revogadas.

Requisitos do pacote: **WordPress 6.7+ e PHP 8.0+**. A URL `/wp-json/mcp/wp-mcp-ultimate`, os nomes das três ferramentas, as opções de canal Fator3, a auditoria e os backups existentes foram preservados. A migração não altera a validade original dos tokens OAuth.

## Base upstream e PRs abertos

O ZIP Ultimate fornecido coincide com os 114 arquivos versionados do `main` consultado, no [commit d5eff50ff3d5609fa491dfb9af7946c261b00c89](https://github.com/AgriciDaniel/wp-mcp-ultimate/commit/d5eff50ff3d5609fa491dfb9af7946c261b00c89), versão 2.1.0. Portanto, nesse snapshot o ZIP já contém as melhorias integradas pelo [PR #16](https://github.com/AgriciDaniel/wp-mcp-ultimate/pull/16).

Foram examinados os patches e as discussões dos quatro PRs que permaneciam abertos:

| PR | Melhoria | Tratamento no pacote |
|---|---|---|
| [#9](https://github.com/AgriciDaniel/wp-mcp-ultimate/pull/9) | Permissões por objeto, capacidade mínima `edit_posts`, limites de regex, SSRF, instalação de plugins, opções protegidas e debug | Mantida a implementação já incorporada no main, com suas correções posteriores; regressões adicionais passaram |
| [#14](https://github.com/AgriciDaniel/wp-mcp-ultimate/pull/14) | Servidor OAuth com PKCE, registro dinâmico e descoberta | Integrado, com endpoints `/wp-mcp-oauth/`, consentimento protegido, limite de registros, escopo Bearer restrito ao MCP e correção de `?rest_route=` |
| [#11](https://github.com/AgriciDaniel/wp-mcp-ultimate/pull/11) | `actions/checkout` v7 | Já presente nos workflows upstream preservados em `maintenance/upstream-workflows/`; mudança de CI, sem efeito no runtime WordPress |
| [#7](https://github.com/AgriciDaniel/wp-mcp-ultimate/pull/7) | `softprops/action-gh-release` v3 | Já presente no workflow de release upstream preservado; mudança de publicação, sem efeito no runtime WordPress |

Os comentários do mantenedor nos PRs #9 e #14 confirmam que foram integrados via #16 e deixados abertos para encerramento posterior. Reaplicar os diffs originais substituiria correções posteriores: o hook de redirecionamento HTTP proposto originalmente não existe no core; houve correções de caminhos Windows, restauração de limites PCRE e escopo OAuth. A versão entregue preserva o código corrigido do main. `blogdescription` continua editável, conforme a revisão do mantenedor; a proteção dessa opção foi retirada intencionalmente no upstream.

Os workflows preservados são referências do repositório Ultimate e ainda usam sua estrutura de build. Não foram apresentados como CI executada para o Fator3 nem ativados em um repositório remoto.

## Bugs reportados

| Relato | Resultado |
|---|---|
| Issue unslash anexada | Corrigidos criação, atualização e patch de posts/páginas, incluindo regex e edições sucessivas; auditoria adicional de campos de mídia, comentários e usuários |
| [#3](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/3) — parâmetros como JSON em string | Correção upstream preservada; objeto, string `"{}"` e JSON inválido exercitados |
| [#5](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/5) / [#12](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/12) — Test Connection | Preservado o uso de uma senha temporária real; teste ampliado para validar `initialize` e as três ferramentas em `tools/list` |
| [#12](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/12) / [#13](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/13) — registro tardio de habilidades | Hooks registrados antes da inicialização da Abilities API; verificado no core nativo e no polyfill |
| [#17](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/17) — ferramentas vazias | Screenshots mostram versão 2.0.0/custom fork e o problema de registro tardio; a correção do main foi mantida e `tools/list` retornou as três ferramentas em HTTP real |
| [#15](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/15) — classe Plugins ausente / erro com Wordfence | Arquivo completo presente; ausência simulada de `Plugins.php` gera diagnóstico e não derruba as outras habilidades nem uma rota REST independente |
| [#8](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/8) — imagem destacada | Implementação de `featured_media` já presente no main e preservada |
| [#4](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/4) — autenticação de conectores | OAuth integrado pelo PR #14/#16; fluxo PKCE, troca de código e rotação exercitados |

A [issue #6](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/6) descreve problema de certificado/TLS do ambiente; o pacote não desativa a verificação TLS das conexões externas para contorná-lo. A [#2](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/2) é uma proposta de novas ações do diretório de plugins, fora do plano 0.9.0; não foi tratada como bug existente. A [#18](https://github.com/AgriciDaniel/wp-mcp-ultimate/issues/18) discute periodicidade de releases, sem correção de runtime a aplicar.

## Implementação do plano 0.9.0

| Área | Comportamento entregue |
|---|---|
| Caminhos | Absolutos e relativos a ABSPATH, `..` e symlinks canonicalizados; alcance padrão até o limite do usuário PHP e de `open_basedir` |
| Confinamento | `f3_mcp_files_roots` vazio abre; lista não vazia confina; raízes inválidas recusam acesso; constante `F3_MCP_FILES_CONFINE='wp'` restaura o escopo antigo |
| Nomes/extensões | Sem lista padrão de nomes bloqueados; política aberta de extensões da 0.8.0 preservada; filtros mantidos |
| Travas | Capacidades `edit_themes` + `manage_options`, kill-switch, `DISALLOW_FILE_EDIT` e `DISALLOW_FILE_MODS`; NUL e wrappers recusados |
| Autoedição | Leitura do próprio código permitida; edição do próprio plugin bloqueada por padrão, ajustável por filtro |
| Arquivos novos | Criação de diretórios com verificação de ancestral e confinamento, inclusive para caminhos absolutos |
| Listagem | Caminho vazio lista ABSPATH; recursão não percorre links de diretórios, evitando ciclos e fuga de escopo |
| Backup/restauração | Backup de exclusão já existia e foi mantido; restore verifica ID/SHA-256, sintaxe PHP e cria backup do destino anterior |
| Integridade | Backup incompleto e escrita parcial impedem sucesso; patch confere tamanho antes de ler o arquivo inteiro |
| Painel | Um menu Fator3, abas de arquivos/banco e conexão MCP, alcance efetivo, `open_basedir`, diagnóstico e banner permanente enquanto aberto |
| Auto-teste | Reescrito para provar sintaxe, backup/restore, autorização, kill-switch e confinamento opcional; usa arquivos temporários próprios |

O alcance total inclui `wp-config.php`, chaves legíveis pelo PHP e gravação de PHP em uploads, como solicitado no plano. Para manter o caso korvena restrito, defina a constante `'wp'` antes da atualização. Backups continuam habilitados por padrão; os parâmetros explícitos existentes foram preservados.

O controle de arquivos/banco não substitui as capacidades das demais habilidades Ultimate. A proteção de SSRF foi mantida; o próprio upstream documenta a limitação de validação DNS separada da conexão, portanto ela não representa uma garantia absoluta contra DNS rebinding.

## Correção unslash

O conteúdo passa por `wp_slash()` imediatamente antes das APIs que esperam dados com barras. Isso protege o texto inteiro, inclusive trechos fora do patch. A implementação respeita os contratos de [wp_update_post](https://developer.wordpress.org/reference/functions/wp_update_post/), [wp_insert_comment](https://developer.wordpress.org/reference/functions/wp_insert_comment/) e [wp_insert_user](https://developer.wordpress.org/reference/functions/wp_insert_user/). A senha do usuário permanece bruta: aplicar barras à senha antes do hash alteraria a credencial.

Os testes incluem JSON de blocos com escapes Unicode válidos, `\u002d`, barras em caminhos, aspas, conteúdo de navegação e três patches consecutivos. Há também correção do patch literal limitado de páginas para que `$1` e barras não virem referências de regex.

Para testar o defeito corretamente, foram usados escapes reais: o serializador Gutenberg pode emitir Unicode sem escapes, portanto a presença de texto acentuado isoladamente não prova a regressão. Conteúdo já corrompido não recebe reparo automático; exige revisão ou backup confiável.

## Três ferramentas ou mais?

**Recomendação para esta entrega: manter as três ferramentas como padrão.** Elas dão acesso às 70 habilidades operacionais preservadas. O total original registrado é 73 ao contar as três meta-habilidades; WordPress 6.9.4 acrescentou três habilidades nativas no laboratório, totalizando 76.

A [especificação MCP de ferramentas](https://modelcontextprotocol.io/specification/2026-07-28/server/tools) define descoberta, esquemas e chamada de ferramentas, mas não exige esse padrão de três nem estabelece uma quantidade ideal. A recomendação abaixo é uma decisão de arquitetura para este plugin.

| Modelo | Quando é útil | Custo |
|---|---|---|
| Três meta-ferramentas | Muitas habilidades, evolução do catálogo e compatibilidade com o conector existente | O agente precisa descobrir o nome e consultar o esquema antes de executar; a indicação de leitura/escrita do executor é genérica |
| Híbrido: três mais ações selecionadas | Operações frequentes como busca e leitura de conteúdo; clientes se beneficiam de esquemas e descrições específicos | Mais definições no conector e necessidade de manter a seleção coerente |
| Todas as habilidades diretamente | Clientes que possuem boa seleção de ferramentas sob demanda e necessidade comprovada | Catálogo maior, nomes semelhantes e mais definições para seleção/contexto, dependendo do cliente |

Expor algumas ações diretamente pode reduzir chamadas e melhorar a clareza dos parâmetros e das anotações de leitura/escrita. Isso não cria funcionalidades novas e não substitui a autorização da habilidade. O filtro upstream `mcp_adapter_default_server_config` permanece disponível para configurar uma seleção. Não foi alterada a lista padrão nesta entrega, pois não houve pedido de uma seleção concreta.

`resources/list` vazio não significa ausência de ferramentas: ferramentas devem ser verificadas com `tools/list`. O Test Connection agora faz essa verificação explicitamente.

## Evidência de validação

Ambientes locais descartáveis: Linux, PHP 8.3.6, MariaDB 10.11.14, WordPress 6.9.4 com Abilities API nativa e WordPress 6.8.3 com polyfill integrado. Os testes executam o código instalado no WordPress; as verificações HTTP usam o servidor e o banco reais do laboratório.

| Bateria | Aprovados | Falhas |
|---|---:|---:|
| Integração WordPress 6.9.4 | 105 | 0 |
| Integração WordPress 6.8.3 / polyfill | 105 | 0 |
| Migração e desinstalador antigo | 11 | 0 |
| MCP HTTP, credenciais antigas, painel e Test Connection | 11 | 0 |
| Constante de confinamento `'wp'` | 5 | 0 |
| `DISALLOW_FILE_EDIT` | 4 | 0 |
| `DISALLOW_FILE_MODS` | 4 | 0 |
| Regressões específicas PR #9 | 10 | 0 |
| Fluxo OAuth/PKCE e proteções PR #14 | 11 | 0 |
| Classe Plugins ausente, diagnóstico e REST independente | 3 | 0 |
| Sintaxe PHP | 94 arquivos | 0 |

Uma mutação removeu `wp_slash()` do `content/patch-post` no plugin instalado do laboratório. A suíte detectou seis regressões de conteúdo; o arquivo foi restaurado e a suíte final voltou a 105 aprovações/zero falhas. Isso verifica que os testes conseguem detectar o defeito reportado.

Os resultados sem credenciais estão em `docs/validation.json`; as bases e os hashes dos anexos estão em `docs/provenance.json`; os arquivos de núcleo modificados estão em `docs/UPSTREAM.md`.

Limites: não houve deploy no WordPress do usuário ou no DreamHost citado no plano. O ambiente WordPress 7.1 informado no relato não foi reproduzido. Não houve execução da suíte Playwright upstream, teste de multisite, hospedagem Windows/FTP ou instalação do Wordfence; para #15 foi reproduzida diretamente a falha de classe ausente. O inventário completo foi conferido, mas os testes funcionais se concentram nas regressões e nos fluxos descritos, sem exercitar todas as variantes das 70 habilidades.
