# WP MCP Fator3 0.9.2 — diretórios vazios

Data: 11/09/2026. Base: ZIP 0.9.1 entregue anteriormente.

## Resultado

O apontamento foi confirmado: `files/delete` na 0.9.1 recusava todos os diretórios por uma condição explícita `is_dir()`. A versão 0.9.2 acrescenta `empty_dir=true` à mesma habilidade, para remover exclusivamente uma pasta vazia.

O modo padrão continua apagando arquivos, com as opções anteriores de backup e SHA-256. O inventário de habilidades e as três metatools permanecem iguais.

## Uso

No Execute Ability:

```json
{
  "ability_name": "files/delete",
  "parameters": {
    "path": "wp-content/uploads/pasta-vazia",
    "empty_dir": true
  }
}
```

Também são aceitos caminhos absolutos, respeitando as permissões do PHP e o confinamento configurado. Informe uma pasta existente no servidor.

| Situação | Resultado |
|---|---|
| Pasta vazia com `empty_dir=true` | Remove a própria pasta e registra `rmdir` na auditoria. |
| Pasta sem a opção, ou com `empty_dir=false` | Recusa; preserva o contrato anterior. |
| Pasta com arquivo, inclusive oculto | Recusa e preserva o conteúdo. |
| Pasta com subpasta, mesmo vazia | Recusa; cada pasta deve ser tratada explicitamente. |
| Pasta com link simbólico, inclusive quebrado | Recusa; o link conta como conteúdo. |
| Link simbólico como pasta final | Recusa e preserva o destino. |
| Arquivo com `empty_dir=true` | Recusa; não muda automaticamente para exclusão de arquivo. |
| Caminho inexistente | Devolve `success=false`. |
| `expected_sha256` preenchido com `empty_dir=true` | Recusa; o hash é uma condição para arquivos. |

Na remoção de pasta vazia, `backup_id` é uma string vazia. `backup` aplica-se somente a arquivos; `files/restore` não recria diretórios removidos por essa opção. Não há remoção recursiva nem remoção automática de pastas ancestrais.

## Implementação e verificação

1. Confirmado o bloqueio no código do ZIP 0.9.1.
2. Acrescentados o parâmetro booleano no schema e o tratamento separado para diretórios vazios.
3. Mantida a validação do destino real no PathGuard. A chamada nativa recebe a entrada original validada, para que a resolução de um link final não resulte em remoção de seu destino.
4. O leitor de diretório considera todas as entradas, exceto `.` e `..`, e fecha o handle antes de remover. A função nativa [`rmdir()`](https://www.php.net/manual/en/function.rmdir.php) exige que a pasta esteja vazia no momento da operação. O teste que cria um arquivo depois da inspeção confirmou a recusa e a preservação desse arquivo.
5. Capacidades, canal fechado, confinamento opcional e proteção de autoedição são verificados antes da operação. O filtro de extensões continua sendo aplicado aos arquivos; nomes de diretórios não são extensões de arquivo.

**Validação executada:** 38 verificações aprovadas em PHP 8.3.6, com 0 falhas; sintaxe de 97 arquivos PHP verificada, com 0 erros. Os resultados ficam em `docs/validation-0.9.2.json` e o runner em `tests/rmdir-092.php`.

O ambiente de testes usa stubs explícitos das funções WordPress e operações reais de filesystem. Foram criadas e removidas somente as fixtures temporárias da suíte. Não houve execução desta versão em uma instalação WordPress completa nem na hospedagem do usuário. Os relatórios de 0.9.0 e 0.9.1 incluídos no pacote são evidências históricas, não testes repetidos nesta rodada.

Os testes cobrem diretórios vazios e ocupados, entradas ocultas e nomes como `0`, subpastas, links simbólicos, caminhos absolutos/relativos, barra final, validações, permissões, confinamento, auditoria, chegada concorrente de conteúdo e exclusão de arquivos com backup.

## Atualização

Envie `wp-mcp-fator3-0.9.2.zip` no WordPress e escolha substituir o plugin instalado. A pasta permanece `wp-mcp-fator3` e o arquivo principal `wp-mcp-fator3.php`. Não é necessário desinstalar para atualizar.

A URL continua `/wp-json/mcp/wp-mcp-ultimate`. O complemento Google usa o mesmo servidor, e esta atualização preserva as configurações e credenciais existentes.

Foram alterados três arquivos PHP de produção: `wp-mcp-fator3.php`, `includes/Files.php` e `includes/PathGuard.php`. As melhorias de `files/read` e a correção de `plugins/delete` da 0.9.1 foram preservadas.
