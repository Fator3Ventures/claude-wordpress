# Núcleo integrado e origem

Base: Ultimate 2.1.0, commit `d5eff50ff3d5609fa491dfb9af7946c261b00c89`. Os 114 arquivos versionados do ZIP fornecido coincidiram com os hashes Git do upstream consultado.

`core/includes` e `core/assets` preservam todos os arquivos equivalentes do núcleo. `core/bootstrap.php` substitui o ponto de entrada do plugin separado, sem um segundo cabeçalho de plugin. O desinstalador destrutivo antigo não foi incluído.

## Arquivos do núcleo adaptados

- `core/includes/Abilities/Comments/Comments.php`
- `core/includes/Abilities/Content/Pages.php`
- `core/includes/Abilities/Content/Posts.php`
- `core/includes/Abilities/Media/Media.php`
- `core/includes/Abilities/Registry.php`
- `core/includes/Abilities/Users/Users.php`
- `core/includes/Admin/Ajax.php`
- `core/includes/Admin/Dashboard.php`
- `core/includes/Admin/views/dashboard.php`
- `core/includes/OAuth/AuthorizationEndpoint.php`
- `core/includes/OAuth/RegistrationEndpoint.php`
- `core/includes/OAuth/TokenStore.php`
- `core/includes/Plugin.php`
- `core/includes/Server/Abilities/DiscoverAbilitiesAbility.php`
- `core/includes/Server/Abilities/ExecuteAbilityAbility.php`
- `core/includes/Server/Abilities/GetAbilityInfoAbility.php`
- `core/includes/Server/DefaultServerFactory.php`

Arquivos de runtime upstream preservados sem alterações: 66.

## Camada Fator3 e testes PHP

- `includes/Admin.php`
- `includes/Database.php`
- `includes/Files.php`
- `includes/Http.php`
- `includes/Migration.php`
- `includes/PathGuard.php`
- `includes/SelfTest.php`
- `includes/SqlGuard.php`
- `tests/confine.php`
- `tests/integration.php`
- `tests/upstream-regressions.php`
- `wp-mcp-fator3.php`

Os ajustes do núcleo cobrem migração de identidade, interface integrada, diagnóstico e contratos de escrita do WordPress. A lista de PRs e as decisões de integração estão no relatório. Autoria e licença upstream permanecem nos arquivos.
