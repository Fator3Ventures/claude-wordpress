# WP MCP Fator3 0.9.3 — correção de content/delete-post

Data: 11/09/2026. Base: pacote entregue `wp-mcp-fator3-0.9.2.zip`.

## Defeito confirmado

A versão 0.9.2 executava `wp_delete_post($id, $force)` e escolhia a mensagem pelo parâmetro recebido. O schema dizia que `force=false` enviava para a lixeira. Essa correspondência não existe para todos os tipos e estados de conteúdo.

No código oficial do WordPress, `wp_delete_post()` redireciona para a lixeira automaticamente apenas para `post`/`page` ainda fora dela e com a lixeira ativada. Anexos possuem um caminho específico via `wp_delete_attachment()`. Tipos personalizados podem ser apagados definitivamente mesmo com o segundo argumento `false`. Posts/páginas já na lixeira, ou com a lixeira desativada, também podem ser apagados. [Código e documentação de wp_delete_post](https://developer.wordpress.org/reference/functions/wp_delete_post/).

O defeito foi reproduzido com o `Posts.php` original da 0.9.2 em WordPress 6.9.4, para `f3_fixture` (tipo personalizado registrado no laboratório) e `wp_navigation`. Nas duas chamadas com `force=false`, o retorno foi `success=true` e `Post moved to trash`, mas o registro deixou de existir no banco. A evidência está em `validation-0.9.3.json`.

## Contrato corrigido

| Entrada e estado | Resultado na 0.9.3 |
|---|---|
| `force=false` ou omitido; item fora da lixeira; lixeira ativada | Chama `wp_trash_post($id)`, inclusive para tipos personalizados. Sucesso exige que o registro permaneça com `post_status=trash`. |
| `force=false` ou omitido; item já na lixeira | Sucesso sem alterações. Não reinicia o prazo de retenção. |
| `force=false` ou omitido; item fora da lixeira; `EMPTY_TRASH_DAYS=0` | Falha sem chamar a operação de lixeira ou exclusão definitiva. |
| `force=true` booleano | Chama `wp_delete_post($id, true)`. Sucesso exige que o registro não exista mais. |
| `force` com tipo inválido | Recusado pela validação de entrada ou pelo callback. Strings e números não autorizam exclusão definitiva. |
| Permissão negada, item inexistente ou veto/falha da operação | Falha; não informa que o item foi movido/apagado com sucesso. |

A verificação da configuração é indispensável: `wp_trash_post()` também faz exclusão definitiva quando a lixeira está desativada. A 0.9.3 impede esse fallback antes da chamada. [Código e documentação de wp_trash_post](https://developer.wordpress.org/reference/functions/wp_trash_post/).

A checagem do resultado trata `WP_Error` e valores falsos. Um retorno verdadeiro de filtro que apenas interrompa a função não basta para anunciar sucesso: a ability consulta o estado do registro após a operação. Filtros e hooks WordPress continuam sendo executados normalmente; essa confirmação não desfaz efeitos causados por código de terceiros.

Para anexos, a solicitação explícita de lixeira nesta ability usa `wp_trash_post()` e preserva o registro, mesmo quando a interface de mídia não oferece a ação. O pacote não altera `MEDIA_TRASH` nem a interface administrativa. As regras normais de retenção e limpeza programada da lixeira continuam valendo para todos os itens.

## Uso pelo conector

Em **Execute Ability**, envie:

```json
{
  "ability_name": "content/delete-post",
  "parameters": {
    "id": 123,
    "force": false
  }
}
```

Para exclusão definitiva, use `force: true`. Atualize a descoberta/consulte **Get Ability Info** após instalar para obter o schema corrigido.

O contrato da ability continua retornando `success` e `message`. No metatool, esse resultado fica em `data`: confira `data.success` para saber se a operação de conteúdo teve sucesso. O `success` externo indica que a chamada da ability foi executada, conforme o comportamento já existente.

## O que mudou no pacote

Somente dois arquivos PHP de produção mudaram em relação à 0.9.2:

- `core/includes/Abilities/Content/Posts.php`: implementação, descrição e schema de `content/delete-post`.
- `wp-mcp-fator3.php`: cabeçalho e constante de versão para 0.9.3.

Também foram acrescentados o runner de testes e os relatórios desta versão, e atualizados README/CHANGELOG. O manifesto `provenance-0.9.3.json` registra os hashes dos arquivos PHP de produção. As correções de `plugins/delete`, leitura parcial de arquivos, `rmdir` e conteúdo com barras foram preservadas.

## Validação executada

- WordPress **6.9.4**, PHP **8.3.6**, SQLite Database Integration **3.0.1** usado exclusivamente como banco do laboratório, sem integrar o plugin distribuído.
- Reprodução do defeito anterior em dois tipos de conteúdo, antes de testar o código corrigido.
- **77 verificações aprovadas** com `EMPTY_TRASH_DAYS=30`.
- **58 verificações aprovadas** em processo separado com `EMPTY_TRASH_DAYS=0`.
- **98 arquivos PHP** com sintaxe válida; nenhum erro nos testes e nenhum log de depuração gerado pelo WordPress nessas execuções.

Os testes usam funções, permissões, banco e Abilities API reais do WordPress. Cobrem `post`, `page`, tipo personalizado `f3_fixture`, `wp_navigation`, `wp_block`, `wp_template` e `attachment`; conteúdo e metadados preservados; comentários e restauração; chamadas repetidas; exclusão definitiva; entradas inválidas; permissões do objeto e usuário anônimo; filtros de veto com retornos falsos, verdadeiros, objeto e `WP_Error`; alteração de status por filtro; schema e chamadas pelo metatool com parâmetros objeto/JSON; inventário anterior de abilities.

Limites: não houve instalação no site do usuário, teste HTTP externo do conector ou execução em MySQL/MariaDB nesta atualização. As suítes completas de versões anteriores não foram reexecutadas; seus relatórios no ZIP são históricos. Os demais arquivos PHP de produção foram conferidos por comparação de bytes com a 0.9.2.

## Instalação

Envie `wp-mcp-fator3-0.9.3.zip` em **Plugins → Adicionar plugin → Enviar plugin**, escolhendo substituir a versão atual. O ZIP mantém a pasta `wp-mcp-fator3` e o arquivo principal `wp-mcp-fator3.php`.

A URL de conexão permanece `/wp-json/mcp/wp-mcp-ultimate`, com as mesmas três ferramentas MCP. Configurações e credenciais são preservadas. Se o Ultimate separado ainda estiver ativo, siga a migração descrita no README: o núcleo integrado só passa a ser usado após desativar a cópia externa. O plugin Google continua separado.

Esta atualização evita novas exclusões indevidas pela ability; conteúdo já apagado definitivamente depende de backup para recuperação.
