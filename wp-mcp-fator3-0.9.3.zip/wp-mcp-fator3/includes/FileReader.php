<?php
/**
 * Bounded, line-oriented reads for logs, without shell commands.
 *
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class FileReader {

	public const MAX_LINES = 10000;

	/** Read a page of matching lines, preserving their original bytes/order. */
	public static function read( string $path, array $input, int $max_bytes ): array|\WP_Error {
		foreach ( array( 'offset', 'limit', 'tail_lines' ) as $key ) {
			if ( array_key_exists( $key, $input ) && ( ! is_int( $input[ $key ] ) || $input[ $key ] < ( 'offset' === $key ? 0 : 1 ) || ( 'offset' !== $key && $input[ $key ] > self::MAX_LINES ) ) ) {
				return new \WP_Error( 'invalid_line_option', 'offset deve ser um inteiro >= 0; limit e tail_lines devem ser inteiros entre 1 e 10000.' );
			}
		}
		if ( isset( $input['tail_lines'], $input['limit'] ) ) {
			return new \WP_Error( 'conflicting_line_options', 'Use tail_lines ou limit, sem combinar os dois.' );
		}
		if ( array_key_exists( 'grep', $input ) && ( ! is_string( $input['grep'] ) || strlen( $input['grep'] ) > 4096 ) ) {
			return new \WP_Error( 'invalid_grep', 'grep deve ser uma string de até 4096 bytes.' );
		}
		if ( array_key_exists( 'grep_regex', $input ) && ! is_bool( $input['grep_regex'] ) ) {
			return new \WP_Error( 'invalid_grep', 'grep_regex deve ser booleano.' );
		}

		$tail    = isset( $input['tail_lines'] );
		$limit   = $input['tail_lines'] ?? $input['limit'] ?? 1000;
		$offset  = $input['offset'] ?? 0;
		$grep    = $input['grep'] ?? '';
		$regex   = $input['grep_regex'] ?? false;
		if ( $regex && ( '' === $grep || false === @preg_match( $grep, '' ) ) ) {
			return new \WP_Error( 'invalid_grep_regex', 'grep_regex exige uma expressão PCRE válida com delimitadores, ex.: /error|fatal/i.' );
		}

		$handle = @fopen( $path, 'rb' );
		if ( false === $handle ) {
			return new \WP_Error( 'file_read_failed', 'Falha ao abrir o arquivo para leitura.' );
		}

		$lines    = array();
		$bytes    = 0;
		$skipped  = 0;
		$has_more = false;
		try {
			$stat = fstat( $handle );
			if ( false === $stat || $stat['size'] < 0 ) {
				throw new \RuntimeException( 'Não foi possível determinar o tamanho do arquivo.' );
			}
			$size   = (int) $stat['size'];
			$stream = $tail ? self::backward( $handle, $size, $max_bytes ) : self::forward( $handle, $size, $max_bytes );
			foreach ( $stream as $line ) {
				// grep operates on one logical line, excluding its LF/CRLF terminator.
				$text = $line;
				if ( str_ends_with( $text, "\n" ) ) {
					$text = substr( $text, 0, -1 );
					if ( str_ends_with( $text, "\r" ) ) {
						$text = substr( $text, 0, -1 );
					}
				}
				$match = $regex ? @preg_match( $grep, $text ) : ( '' === $grep || false !== strpos( $text, $grep ) );
				if ( $regex && false === $match ) {
					throw new \RuntimeException( 'Falha ao aplicar grep: ' . preg_last_error_msg() );
				}
				if ( ! $match ) {
					continue;
				}
				if ( $skipped < $offset ) {
					++$skipped;
					continue;
				}
				if ( count( $lines ) >= $limit || strlen( $line ) > $max_bytes - $bytes ) {
					if ( array() === $lines ) {
						throw new \RuntimeException( 'Uma linha excede o limite de bytes da resposta.' );
					}
					$has_more = true;
					break;
				}
				$lines[] = $line;
				$bytes  += strlen( $line );
			}
		} catch ( \RuntimeException $error ) {
			return new \WP_Error( 'file_read_failed', $error->getMessage() );
		} finally {
			fclose( $handle );
		}

		if ( $tail ) {
			$lines = array_reverse( $lines );
		}
		$content = implode( '', $lines );
		return array(
			'success'        => true,
			'message'        => 'Leitura por linhas concluída.',
			'path'           => PathGuard::to_relative( $path ),
			'content'        => $content,
			'bytes'          => $bytes,
			'file_bytes'     => $size,
			'sha256'         => hash( 'sha256', $content ),
			'sha256_scope'   => 'returned_content',
			'partial'        => true,
			'mode'           => $tail ? 'tail' : 'lines',
			'returned_lines' => count( $lines ),
			'offset'         => $offset,
			'has_more'       => $has_more,
			'next_offset'    => $has_more ? $offset + count( $lines ) : null,
		);
	}

	/** Read only the size captured when opening; appends cannot extend a scan. */
	private static function block( $handle, int $position, int $length ): string {
		if ( 0 !== fseek( $handle, $position ) ) {
			throw new \RuntimeException( 'Falha ao posicionar a leitura do arquivo.' );
		}
		$data = fread( $handle, $length );
		if ( false === $data || strlen( $data ) !== $length ) {
			throw new \RuntimeException( 'Leitura incompleta: o arquivo mudou de tamanho ou houve uma falha de I/O. Repita a consulta.' );
		}
		return $data;
	}

	/** LF is the separator; CRLF is preserved byte for byte. */
	private static function forward( $handle, int $size, int $max_bytes ): \Generator {
		$position = 0;
		$buffer   = '';
		while ( $position < $size ) {
			$length    = min( 65536, $size - $position );
			$buffer   .= self::block( $handle, $position, $length );
			$position += $length;
			while ( false !== ( $newline = strpos( $buffer, "\n" ) ) ) {
				$line   = substr( $buffer, 0, $newline + 1 );
				$buffer = substr( $buffer, $newline + 1 );
				if ( strlen( $line ) > $max_bytes ) {
					throw new \RuntimeException( 'Uma linha excede o limite de bytes do canal.' );
				}
				yield $line;
			}
			if ( strlen( $buffer ) > $max_bytes ) {
				throw new \RuntimeException( 'Uma linha excede o limite de bytes do canal.' );
			}
		}
		if ( '' !== $buffer ) {
			yield $buffer;
		}
	}

	/** Seek backward in blocks instead of loading a whole log for tail. */
	private static function backward( $handle, int $size, int $max_bytes ): \Generator {
		$position = $size;
		$buffer   = '';
		$ending   = '';
		$at_end   = true;
		while ( $position > 0 ) {
			$length    = min( 65536, $position );
			$position -= $length;
			$buffer    = self::block( $handle, $position, $length ) . $buffer;
			while ( false !== ( $newline = strrpos( $buffer, "\n" ) ) ) {
				$line   = substr( $buffer, $newline + 1 ) . $ending;
				$buffer = substr( $buffer, 0, $newline );
				if ( strlen( $line ) > $max_bytes ) {
					throw new \RuntimeException( 'Uma linha excede o limite de bytes do canal.' );
				}
				// A terminal LF terminates the last line; it is not an extra line.
				if ( ! $at_end || '' !== $line ) {
					yield $line;
				}
				$ending = "\n";
				$at_end = false;
			}
			if ( strlen( $buffer ) + strlen( $ending ) > $max_bytes ) {
				throw new \RuntimeException( 'Uma linha excede o limite de bytes do canal.' );
			}
		}
		if ( '' !== $buffer || '' !== $ending ) {
			yield $buffer . $ending;
		}
	}
}
