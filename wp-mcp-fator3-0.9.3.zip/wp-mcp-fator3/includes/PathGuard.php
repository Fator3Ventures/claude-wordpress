<?php
/**
 * Canonical filesystem paths and optional confinement for files/*.
 * The default boundary is the PHP process permissions and open_basedir.
 * Capabilities, kill-switch, backups and PHP syntax checks remain in place.
 * @package Fator3\McpFiles
 */

declare(strict_types=1);

namespace Fator3\McpFiles;

final class PathGuard {

	/**
	 * Teto padrão de bytes para leitura e escrita (16 MiB).
	 *
	 * Era 2 MiB, o que recusava arquivos legítimos de tema e de plugin —
	 * bundle de JS, sprite, fonte grande. Use o filtro `f3_mcp_files_max_bytes`
	 * para apertar ou afrouxar; a constante permanece como o padrão.
	 */
	public const MAX_BYTES = 16777216;

	/** Nome da opção que guarda o estado do canal. */
	public const OPTION_ENABLED = 'f3_mcp_files_enabled';

	/**
	 * O canal está ligado?
	 *
	 * **Ligado ao ativar o plugin**, como qualquer plugin de WordPress: ativar
	 * já é o ato humano explícito. Uma segunda confirmação seria teatro de
	 * segurança neste site específico, porque o conector MCP existente já
	 * expõe `plugins/upload-base64` + `plugins/activate` (capacidades
	 * `install_plugins` e `activate_plugins`) — ou seja, quem alcança este
	 * canal já consegue instalar e ativar PHP arbitrário no servidor. Uma
	 * trava aqui não conteria um agente comprometido; só atrapalharia o uso
	 * legítimo.
	 *
	 * O que a tela de controle oferece de útil é o contrário: desligar rápido,
	 * ver o log e conferir a configuração efetiva.
	 *
	 * Precedência: DISALLOW_FILE_EDIT / DISALLOW_FILE_MODS fecham o canal e
	 * não podem ser reabertos por filtro nem pela tela.
	 */
	public static function is_enabled(): bool {
		if ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ) {
			return false;
		}
		if ( defined( 'DISALLOW_FILE_MODS' ) && DISALLOW_FILE_MODS ) {
			return false;
		}

		$enabled = (bool) get_option( self::OPTION_ENABLED, true );

		/**
		 * Permite forçar o estado do canal por código.
		 *
		 * Use `__return_false` num mu-plugin para travar o canal fechado de
		 * um jeito que a tela de administração não reabre.
		 *
		 * @param bool $enabled Estado vindo da opção.
		 */
		return (bool) apply_filters( 'f3_mcp_files_enabled', $enabled );
	}

	/**
	 * Capacidade exigida.
	 *
	 * `edit_themes` é a capacidade que o próprio WordPress usa no editor de
	 * arquivos de tema (Aparência > Editor). `manage_options` é exigido junto
	 * para que um Editor de conteúdo nunca alcance o canal.
	 */
	public static function can_edit(): bool {
		return current_user_can( 'edit_themes' ) && current_user_can( 'manage_options' );
	}

	/** Raízes da política 0.8.0, usadas por F3_MCP_FILES_CONFINE='wp'. */
	public static function wp_roots(): array {
		$roots = array( get_theme_root() );
		foreach ( (array) ( $GLOBALS['wp_theme_directories'] ?? array() ) as $root ) {
			$roots[] = $root;
		}
		foreach ( array( 'WP_PLUGIN_DIR', 'WPMU_PLUGIN_DIR' ) as $constant ) {
			if ( defined( $constant ) ) {
				$roots[] = constant( $constant );
			}
		}
		return self::canonical_roots( $roots );
	}

	private static function canonical_roots( array $roots ): array {
		$out = array();
		foreach ( $roots as $root ) {
			if ( ! is_string( $root ) || '' === $root || false !== strpos( $root, "\0" ) ) {
				continue;
			}
			$real = realpath( $root );
			if ( false !== $real && is_dir( $real ) ) {
				$out[] = self::normalize( $real );
			}
		}
		return array_values( array_unique( $out ) );
	}

	private static function configured_roots(): array {
		$defaults = defined( 'F3_MCP_FILES_CONFINE' ) && 'wp' === F3_MCP_FILES_CONFINE
			? self::wp_roots() : array();
		return (array) apply_filters( 'f3_mcp_files_roots', $defaults );
	}

	/** Vazio = sem confinamento. Lista configurada inválida falha fechada. */
	public static function roots(): array {
		return self::canonical_roots( self::configured_roots() );
	}

	public static function is_confined(): bool {
		return array() !== self::configured_roots();
	}

	public static function denied_basenames(): array {
		$classic = array(
			'wp-config.php', 'wp-config-sample.php', 'wp-settings.php', '.htaccess',
			'.htpasswd', '.user.ini', 'php.ini', '.env', '.git', '.svn', '.ssh',
			'authorized_keys', 'id_rsa', 'id_ed25519', '.npmrc', '.netrc',
		);
		$defaults = defined( 'F3_MCP_FILES_CONFINE' ) && 'wp' === F3_MCP_FILES_CONFINE ? $classic : array();
		return (array) apply_filters( 'f3_mcp_files_denied_basenames', $defaults );
	}

	/**
	 * Teto efetivo de bytes por arquivo.
	 *
	 * @return int
	 */
	public static function max_bytes(): int {
		$max = (int) apply_filters( 'f3_mcp_files_max_bytes', self::MAX_BYTES );
		return $max > 0 ? $max : self::MAX_BYTES;
	}

	/**
	 * Restrição opcional de extensões. Vazio permite qualquer extensão,
	 * inclusive arquivos sem extensão. Um array não vazio limita os formatos.
	 * @return string[]
	 */
	public static function allowed_extensions(): array {
		$list = apply_filters( 'f3_mcp_files_allowed_extensions', array() );
		return is_array( $list ) ? array_values( array_filter( array_map( 'strval', $list ) ) ) : array();
	}

	/**
	 * Extensões recusadas mesmo com a política aberta.
	 *
	 * Vazio por padrão. Existe para quem quiser barrar um formato específico
	 * sem ter que montar uma allowlist inteira.
	 *
	 * @return string[]
	 */
	public static function denied_extensions(): array {
		$list = apply_filters( 'f3_mcp_files_denied_extensions', array() );
		return is_array( $list ) ? array_map( 'strtolower', array_map( 'strval', $list ) ) : array();
	}

	/**
	 * Extensões que só fazem sentido em bytes crus (nunca como texto).
	 *
	 * Usado para avisar quando alguém tenta gravar binário via `content`.
	 *
	 * @return string[]
	 */
	public static function binary_extensions(): array {
		return array( 'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'ico', 'woff', 'woff2', 'ttf', 'otf', 'eot' );
	}

	/** Teto para download por URL — maior que o de escrita direta. */
	public static function max_fetch_bytes(): int {
		$max = (int) apply_filters( 'f3_mcp_files_max_fetch_bytes', 33554432 ); // 32 MiB
		return $max > 0 ? $max : 33554432;
	}

	/** Preserva a raiz Unix e a raiz de volume Windows. */
	private static function normalize( string $path ): string {
		$path = wp_normalize_path( $path );
		return '/' === $path || preg_match( '#^[A-Za-z]:/$#', $path ) ? $path : rtrim( $path, '/' );
	}

	/** @return string|\WP_Error Caminho absoluto ainda não canonicalizado. */
	private static function candidate( string $path ) {
		// Verificar ANTES de trim(): trim também remove bytes nulos nas pontas.
		if ( false !== strpos( $path, "\0" ) ) {
			return new \WP_Error( 'f3_files_null_byte', 'Caminho contém byte nulo.' );
		}
		$path = wp_normalize_path( trim( $path ) );
		if ( '' === $path ) {
			return new \WP_Error( 'f3_files_empty_path', 'O caminho é obrigatório.' );
		}
		if ( preg_match( '#^[a-zA-Z][a-zA-Z0-9+.\-]*:#', $path ) && ! preg_match( '#^[A-Za-z]:/#', $path ) ) {
			return new \WP_Error( 'f3_files_scheme', 'Wrappers de stream não são permitidos.' );
		}
		$denied = self::check_names( $path );
		if ( is_wp_error( $denied ) ) {
			return $denied;
		}
		if ( '/' === $path[0] || preg_match( '#^[A-Za-z]:/#', $path ) ) {
			return $path;
		}
		$base = realpath( ABSPATH );
		if ( false === $base ) {
			return new \WP_Error( 'f3_files_no_base', 'Não foi possível resolver ABSPATH.' );
		}
		return rtrim( wp_normalize_path( $base ), '/' ) . '/' . $path;
	}

	private static function check_names( string $path ) {
		$denied = array_map( 'strtolower', self::denied_basenames() );
		foreach ( explode( '/', $path ) as $segment ) {
			if ( in_array( strtolower( $segment ), $denied, true ) ) {
				return new \WP_Error( 'f3_files_denied', 'Caminho contém um nome protegido: ' . $segment );
			}
		}
		return true;
	}

	private static function inside( string $path, string $root ): bool {
		if ( '\\' === DIRECTORY_SEPARATOR ) {
			$path = strtolower( $path );
			$root = strtolower( $root );
		}
		return $path === $root || 0 === strpos( $path, rtrim( $root, '/' ) . '/' );
	}

	/** @return true|\WP_Error Valida também o alvo real de symlinks. */
	private static function scope( string $resolved, bool $for_write ) {
		$names = self::check_names( $resolved );
		if ( is_wp_error( $names ) ) {
			return $names;
		}
		if ( $for_write && defined( 'F3_MCP_FILES_DIR' ) && apply_filters( 'f3_mcp_files_protect_self', true ) ) {
			$self = self::normalize( realpath( F3_MCP_FILES_DIR ) ?: F3_MCP_FILES_DIR );
			if ( self::inside( $resolved, $self ) ) {
				return new \WP_Error( 'f3_files_self', 'Este canal não edita os próprios arquivos. Atualize o plugin pelo painel.' );
			}
		}
		$configured = self::configured_roots();
		if ( array() === $configured ) {
			return true;
		}
		foreach ( self::canonical_roots( $configured ) as $root ) {
			if ( self::inside( $resolved, $root ) ) {
				return true;
			}
		}
		return new \WP_Error( 'f3_files_outside_root', 'Caminho fora das raízes configuradas neste site.' );
	}

	/** Aceita absoluto ou relativo a ABSPATH; resolve .. e symlinks pelo SO. */
	public static function resolve( string $relative, bool $for_write ) {
		$candidate = self::candidate( $relative );
		if ( is_wp_error( $candidate ) ) {
			return $candidate;
		}
		if ( is_link( $candidate ) && ! file_exists( $candidate ) ) {
			return new \WP_Error( 'f3_files_broken_symlink', 'Link simbólico sem destino válido.' );
		}
		$real = realpath( $candidate );
		if ( false === $real ) {
			if ( ! $for_write ) {
				return new \WP_Error( 'f3_files_not_found', 'Arquivo ou diretório não encontrado.' );
			}
			$parent = realpath( dirname( $candidate ) );
			if ( false === $parent || ! is_dir( $parent ) ) {
				return new \WP_Error( 'f3_files_no_parent', 'O diretório de destino não existe. Use create_dirs=true.' );
			}
			if ( in_array( basename( $candidate ), array( '.', '..', '' ), true ) ) {
				return new \WP_Error( 'f3_files_empty_path', 'Nome de arquivo inválido.' );
			}
			$real = rtrim( wp_normalize_path( $parent ), '/' ) . '/' . basename( $candidate );
		}
		$resolved = self::normalize( $real );
		$valid = self::scope( $resolved, $for_write );
		return is_wp_error( $valid ) ? $valid : $resolved;
	}

	/**
	 * Validate the real target, but keep the directory entry passed to rmdir.
	 * Canonicalizing the final symlink would remove its target instead of
	 * letting the filesystem reject the link. Parent symlinks still obey scope.
	 *
	 * @return string|\WP_Error
	 */
	public static function rmdir_path( string $requested ) {
		$candidate = self::candidate( $requested );
		if ( is_wp_error( $candidate ) ) {
			return $candidate;
		}
		$resolved = self::resolve( $candidate, true );
		if ( is_wp_error( $resolved ) ) {
			return $resolved;
		}
		if ( is_link( rtrim( $candidate, '/' ) ) ) {
			return new \WP_Error( 'f3_files_directory_symlink', 'empty_dir não remove links simbólicos nem seus destinos. Informe o caminho real do diretório.' );
		}
		return $candidate;
	}

	/** Cria pais após validar o ancestral existente e cada nível novo. */
	public static function prepare_parent( string $relative ) {
		$candidate = self::candidate( $relative );
		if ( is_wp_error( $candidate ) ) {
			return $candidate;
		}
		$parent = dirname( $candidate );
		$missing = array();
		while ( ! is_dir( $parent ) ) {
			if ( is_link( $parent ) || file_exists( $parent ) || dirname( $parent ) === $parent ) {
				return new \WP_Error( 'f3_files_no_parent', 'Diretório-pai inválido ou inacessível.' );
			}
			array_unshift( $missing, basename( $parent ) );
			$parent = dirname( $parent );
		}
		$real = realpath( $parent );
		if ( false === $real ) {
			return new \WP_Error( 'f3_files_no_parent', 'Diretório-pai inacessível.' );
		}
		$valid = self::scope( self::normalize( $real ), true );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}
		foreach ( $missing as $segment ) {
			$next = rtrim( wp_normalize_path( $real ), '/' ) . '/' . $segment;
			if ( '.' === $segment || '..' === $segment ) {
				$next = realpath( $next );
				if ( false === $next ) {
					return new \WP_Error( 'f3_files_no_parent', 'Diretório-pai inválido.' );
				}
			}
			$valid = self::scope( self::normalize( $next ), true );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}
			if ( ! is_dir( $next ) && ! @mkdir( $next, 0755 ) && ! is_dir( $next ) ) {
				return new \WP_Error( 'f3_files_mkdir', 'Falha ao criar o diretório de destino.' );
			}
			$real = realpath( $next );
			if ( false === $real ) {
				return new \WP_Error( 'f3_files_no_parent', 'Não foi possível resolver o novo diretório.' );
			}
			$valid = self::scope( self::normalize( $real ), true );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}
		}
		$resolved = self::resolve( $relative, true );
		return is_wp_error( $resolved ) ? $resolved : true;
	}

	/**
	 * A extensão é permitida?
	 *
	 * Aberta por padrão — ver `allowed_extensions()`. Arquivo sem extensão
	 * passa: `LICENSE`, `Makefile` e `.gitignore` são arquivos normais de
	 * plugin e de tema.
	 *
	 * @param string $path Caminho absoluto já resolvido.
	 * @return true|\WP_Error
	 */
	public static function check_extension( string $path ) {
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );

		if ( in_array( $ext, self::denied_extensions(), true ) && '' !== $ext ) {
			return new \WP_Error(
				'f3_files_denied_extension',
				sprintf(
					/* translators: %s: extensão do arquivo. */
					__( 'Extensão ".%s" está na lista de bloqueio deste site.', 'wp-mcp-fator3' ),
					$ext
				)
			);
		}

		$allowed = array_map( 'strtolower', self::allowed_extensions() );

		// Lista vazia = política aberta, que é o padrão.
		if ( empty( $allowed ) ) {
			return true;
		}

		if ( ! in_array( $ext, $allowed, true ) ) {
			return new \WP_Error(
				'f3_files_bad_extension',
				sprintf(
					/* translators: %s: extensão do arquivo. */
					__( 'Extensão ".%s" não permitida: este site restringiu as extensões por filtro.', 'wp-mcp-fator3' ),
					$ext
				)
			);
		}

		return true;
	}

	/**
	 * Checagem de sintaxe PHP sem executar o código e sem shell.
	 *
	 * token_get_all() com TOKEN_PARSE lança ParseError em código inválido —
	 * é um "php -l" em processo. Isso existe por um motivo específico: gravar
	 * PHP quebrado em functions.php derruba o site inteiro, inclusive o
	 * endpoint MCP usado para consertar. Sem esta checagem, um erro de sintaxe
	 * fecharia o próprio canal de correção.
	 *
	 * @param string $code Conteúdo a gravar.
	 * @return true|\WP_Error
	 */
	public static function check_php_syntax( string $code ) {
		if ( ! function_exists( 'token_get_all' ) || ! defined( 'TOKEN_PARSE' ) ) {
			return new \WP_Error( 'f3_files_no_tokenizer', 'A checagem de sintaxe PHP está indisponível; nada foi gravado.' );
		}

		try {
			// @phpcs:ignore Generic.PHP.NoSilencedErrors -- avisos de token não interessam; só o ParseError.
			@token_get_all( $code, TOKEN_PARSE );
		} catch ( \ParseError $e ) {
			return new \WP_Error(
				'f3_files_php_syntax',
				sprintf(
					/* translators: %s: mensagem do erro de sintaxe. */
					__( 'Erro de sintaxe PHP — nada foi gravado: %s', 'wp-mcp-fator3' ),
					$e->getMessage()
				)
			);
		} catch ( \Throwable $e ) {
			return new \WP_Error( 'f3_files_php_syntax', $e->getMessage() );
		}

		return true;
	}

	/**
	 * Diretório de backups, criado sob demanda e protegido contra acesso web.
	 *
	 * @return string|\WP_Error
	 */
	public static function backup_dir() {
		$dir = untrailingslashit( wp_normalize_path( WP_CONTENT_DIR ) ) . '/f3-mcp-backups';

		if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return new \WP_Error( 'f3_files_backup_dir', __( 'Não foi possível criar o diretório de backups.', 'wp-mcp-fator3' ) );
		}

		// Backups de functions.php são código-fonte; não podem ser servidos pela web.
		$htaccess = $dir . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		}
		$index = $dir . '/index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" );
		}

		return $dir;
	}

	/**
	 * Caminho relativo a ABSPATH, para exibir ao usuário sem vazar o layout do servidor.
	 */
	public static function to_relative( string $absolute ): string {
		$base = realpath( ABSPATH );
		if ( false === $base ) {
			return $absolute;
		}
		$base = untrailingslashit( wp_normalize_path( $base ) ) . '/';
		if ( 0 === strpos( $absolute, $base ) ) {
			return substr( $absolute, strlen( $base ) );
		}
		return $absolute;
	}

	/**
	 * Registra a operação num buffer circular, para auditoria posterior.
	 *
	 * @param string $action Ação executada.
	 * @param string $path   Caminho relativo.
	 * @param array  $extra  Dados adicionais.
	 */
	public static function audit( string $action, string $path, array $extra = array() ): void {
		$log   = get_option( 'f3_mcp_files_audit', array() );
		$log   = is_array( $log ) ? $log : array();
		$log[] = array_merge(
			array(
				'time'   => gmdate( 'c' ),
				'user'   => get_current_user_id(),
				'action' => $action,
				'path'   => $path,
			),
			$extra
		);

		if ( count( $log ) > 100 ) {
			$log = array_slice( $log, -100 );
		}

		update_option( 'f3_mcp_files_audit', $log, false );
	}
}
