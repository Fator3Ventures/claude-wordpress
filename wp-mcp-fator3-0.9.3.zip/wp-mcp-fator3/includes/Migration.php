<?php
/** Preserve connection identities when the separate Ultimate is uninstalled. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class Migration {
	public const MARKER = 'f3_mcp_ultimate_migrated';
	public const APP_META = 'f3_mcp_app_password';
	public const CLIENTS = 'f3_mcp_oauth_clients';

	public static function init(): void {
		add_action( 'pre_uninstall_plugin', array( self::class, 'before_uninstall' ), 5, 1 );
	}

	public static function migrate( bool $force = false ): void {
		if ( ! $force && get_option( self::MARKER, false ) ) {
			return;
		}
		foreach ( array( 'wp_mcp_ultimate_settings' => 'f3_mcp_settings', 'wp_mcp_ultimate_oauth_clients' => self::CLIENTS ) as $old => $new ) {
			$value = get_option( $old, null );
			$current = get_option( $new, null );
			if ( null !== $value && null === $current ) {
				add_option( $new, $value, '', false );
			} elseif ( self::CLIENTS === $new && is_array( $value ) && is_array( $current ) ) {
				update_option( $new, array_replace( $value, $current ), false );
			}
		}
		foreach ( get_users( array( 'meta_key' => 'wp_mcp_ultimate_app_password', 'fields' => 'ID', 'blog_id' => 0 ) ) as $user_id ) {
			$uuid = get_user_meta( $user_id, 'wp_mcp_ultimate_app_password', true );
			if ( $uuid && ! get_user_meta( $user_id, self::APP_META, true ) ) {
				update_user_meta( $user_id, self::APP_META, $uuid );
			}
		}
		// Copy only nonexpired tokens and preserve their original deadlines.
		// External object caches are handled by TokenStore's legacy fallback;
		// Ultimate's uninstaller cannot enumerate/delete that cache group.
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
			$wpdb->esc_like( '_transient_mcp_oauth_' ) . '%'
		) );
		foreach ( (array) $rows as $row ) {
			$old = substr( $row->option_name, strlen( '_transient_' ) );
			$new = 'f3_' . $old;
			$expiry = (int) get_option( '_transient_timeout_' . $old, 0 );
			$remaining = $expiry - time();
			if ( $remaining <= 0 || false !== get_transient( $new ) ) {
				continue;
			}
			$value = get_transient( $old );
			if ( false !== $value ) {
				set_transient( $new, $value, $remaining );
			}
		}
		update_option( self::MARKER, array( 'version' => F3_MCP_FILES_VERSION, 'time' => time() ), false );
	}

	public static function before_uninstall( string $plugin ): void {
		if ( 'wp-mcp-ultimate.php' !== basename( $plugin ) ) {
			return;
		}
		self::migrate( true );
		// Ultimate enumerates this pointer before deleting Application Passwords.
		// Move ownership of the pointer; never delete or recreate the password.
		foreach ( get_users( array( 'meta_key' => 'wp_mcp_ultimate_app_password', 'fields' => 'ID', 'blog_id' => 0 ) ) as $user_id ) {
			if ( get_user_meta( $user_id, self::APP_META, true ) ) {
				delete_user_meta( $user_id, 'wp_mcp_ultimate_app_password' );
			}
		}
	}
}
