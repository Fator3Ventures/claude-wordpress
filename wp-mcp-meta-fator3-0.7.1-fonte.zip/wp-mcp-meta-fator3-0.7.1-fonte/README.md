# Fator3 MCP Meta 0.7.1 — revisão concluída

Versão corrente desta entrega: **0.7.1**, instalada e ativa no Site-Teste. A base 0.7.0 recebida de outra sessão foi revisada contra 0.6.0; dois defeitos foram reproduzidos e corrigidos, com proteção adicional de concorrência. O dono autorizou o incremento de patch para achados.

Código canônico: `build/common` e `build/meta`. Documentação instalada: `build/docs/meta`. Runtime distribuído: `plugin/wp-mcp-meta-fator3`, byte a byte igual ao instalador testado. `evidence/review071` contém as provas próprias desta revisão; as demais evidências, entradas e relatórios históricos são recebidos, não execução desta rodada. O relatório externo `wp-mcp-meta-fator3-0.7.1-relatorio.md` é canônico; sua cópia neste fonte é anterior ao fechamento do ZIP.

## Build

```sh
F3_SOCIAL_PHP=/caminho/absoluto/php python3 build/build.py
```

Saída: `build/dist/wp-mcp-meta-fator3-0.7.1-instalador.zip`, 150734 bytes, SHA-256 `0adbea179f3a89cd66b6dce289fa8658e1723f4a9b38568794fc7c3aea5963f2`. `build/dist` fica fora do ZIP fonte para evitar ZIPs aninhados. `tools/package-source.py` confere a igualdade do runtime e fecha o fonte uma única vez.

## Validação desta rodada

392 verificações passaram: 144 no Site-Teste integrado; 162 em instalação limpa isolada WP 7.1.3/PHP 8.3.36; 81 em instalação limpa WP 6.4/PHP 8.1.34; 5 na atualização direta 0.7.0 → 0.7.1 com registros cifrados e histórico. Mais 17 documentos conferidos integralmente pelo MCP. Não houve chamadas a APIs sociais reais nem envio efetivo de e-mail. PHP 8.1.2 exato teve lint; a prova funcional desta revisão na linha 8.1 usa 8.1.34.

Testes de correção: `tests/native/review071.php` e `tests/site/meta-review071-qa.php`. Regressões integradas: `tests/site/meta-regression071-qa.php`. Laboratório remoto isolado: `tests/site/isolated071-controller.php`, gerado com `tools/build-isolated071-probe.py --baseline <runtime-070-imutavel> --output <arquivo-fora-do-fonte>`. Requer Site-Teste autorizado, PHP CLI nos caminhos declarados, MySQL e ZIP. A preparação usa diretório privado e prefixo aleatório de tabelas; o cleanup remove somente esses recursos. Credenciais permanecem no servidor, fora da entrega. As sondas não fazem parte do instalador e não devem permanecer ativas durante troca de plugin; todas possuem guarda para Meta inativo. O controlador isolado expõe apenas cenários fixos de teste, sem entrada de PHP, SQL ou caminhos arbitrários.

Os auxiliares e provas anteriores mantêm seus nomes históricos. `tools/matrix.sh` e manifestos de laboratório da 0.7.0 são referências históricas com caminhos/dependências a adaptar; não representam execução da 0.7.1. Consulte a matriz e os limites no relatório desta entrega antes de repetir os testes.

## Impactos

O documento recebido LinkedIn 0.8.1 → Meta está preservado em `inputs/0.7.1`. A resposta e o alerta de concorrência remanescente estão em `impacts/wp-mcp-meta-fator3-0.7.1-impacto-wp-mcp-linkedin-fator3.md`, revisão 3. Nenhum código de outro plugin foi alterado. O checkpoint de interrupção anterior à recuperação permanece em `history`, identificado como histórico.
