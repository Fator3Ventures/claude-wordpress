# Fator3 MCP LinkedIn 0.14.0 — fonte da entrega

Pedidos MCP LinkedIn 16/17, base aceita 0.13.0. Diagnóstico do retorno OAuth e avisos por incidente de primeira renovação manual, com janela configurável e simulação. Versão ativa no Site-Teste; homologação na conta real permanece pendente. Leia o relatório principal para provas, identidades e limites.

## Organização

- plugin/wp-mcp-linkedin-fator3/: runtime idêntico ao instalador final.
- build/: fontes autorais e documentação; este build gera somente LinkedIn.
- tests/native/: WordPress/MySQL reais com fornecedor e mail sintéticos; request01617.php, mcp-request01617.php, upgrade0140.php e ui0140.* cobrem esta rodada.
- tools/lab.py e lab-release0140.example.json: laboratório descartável, dependências externas conferidas por SHA-256.
- evidence/release0140/: matrizes, contraste da base, integridade, documentação, Site-Teste e ensaios intermediários identificados.
- inputs/0.14.0/: pedidos/relatórios recebidos e identidades dos originais. Normas r5 em inputs/0.13.0.
- planning/RELEASE-0140.md: planejamento anterior à implementação e análise de impactos.
- history/received-0.13.0/: README/relatório da base preservados; demais versões/impactos são históricos.

## Reprodução

Requisitos próprios: WordPress 6.4+, PHP 8.1.2+64 bits, criptografia autenticada e banco com travas nomeadas. Bancada atual WordPress 7.1.4/PHP 8.3.6; mínimo WordPress 6.4/PHP 8.1.2; MySQL 8.0.46. Integrados originais: Core 1.65.1/MCP 0.38.0/Google 0.24.0/Meta 0.17.0. Pipedrive 0.5.0 somente instalado/inativo no PHP 8.3.6 por seu mínimo8.3.36.

Execute python3 build/build.py com PHP disponível ou F3_SOCIAL_PHP. Saída: build/dist/wp-mcp-linkedin-fator3-0.14.0-instalador.zip;325350 bytes, SHA-256 91b49ab4aaac5487657496d22d2d1e3a31334a4afa2547dd7946ebdf1d9868ef. build/dist não integra o fonte fechado. Metadados ZIP são determinísticos.

Copie tools/lab-release0140.example.json, ajuste caminhos e usuário/senha do MySQL em ambiente descartável. WordPress, runtimes PHP e instaladores acompanhantes são dependências externas, não incluídas. O runner cria schema próprio em diretório vazio; nunca aponte para produção. DOM requer Node e F3_JSDOM apontando para jsdom 27.4.0.

```bash
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li014-clean --order linkedin-integrated --tests request01617.php,mcp-request01617.php,suite.php,request012.php,request013.php,request014.php,mcp-history011.php,request015.php,stages012.php,mcp-stages012.php,mcp-request015.php,mcp-docs080.php,ui0140.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li014-upgrade --order linkedin-integrated --origin upgrade --tests upgrade0140.php,request01617.php,mcp-request01617.php,suite.php,request012.php,request013.php,request014.php,mcp-history011.php,request015.php,stages012.php,mcp-stages012.php,mcp-request015.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab-local.json --workdir /tmp/li014-min --order linkedin-only --wordpress wordpress_minimum --php php81 --tests request01617.php,suite.php,request012.php,request013.php,request014.php,request015.php,stages012.php
```

As matrizes aprovam 1094 verificações funcionais (6 não aplicáveis),68 documentais e38 DOM. São execuções entre ambientes, não requisitos distintos. Limpo/mínimo/DOM usaram a candidata funcional cd22fcc1; o fechamento mudou somente documentação e manifesto, preservando todo PHP funcional/JS byte a byte. Upgrade completo e documentação foram repetidos no instalador final91b49ab4; veja documentation-only-closure.json. Nenhum ensaio de fornecedor real foi convertido em sucesso.

package-source.py --output-dir /diretorio/externo compara plugin/ com o ZIP final e fecha uma raiz versionada, sem ZIP aninhado; recusa sobrescrever fonte fechado. Relatório interno antecede o fechamento; bytes/hash finais do fonte constam no relatório externo canônico. Não altere o runtime 0.14.0 instalado sem nova versão.
