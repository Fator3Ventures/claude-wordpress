# Ensaios intermediários — não são os resultados finais

Preservados para rastreabilidade. focused: fixture devolvia o mesmo token e houve validação permissiva de string numérica; fixture corrigida e credential_notice_days passou a exigir inteiro. clean: mensagem voltou a citar Primary Client Secret; fixture de renovação automática passou a estabelecer vínculo antes do cron, pois refresh manual exige primeira confirmação desde 0.14.0. upgrade: igualdade estrita comparava a ordem das chaves da projeção aditiva, embora as duas tabelas já coincidissem byte a byte; comparação ajustada para preservar os campos originais e verificar o novo default separadamente.

Nenhum desses candidatos foi instalado no Site-Teste. Os resultados finais estão nos diretórios da matriz final.
