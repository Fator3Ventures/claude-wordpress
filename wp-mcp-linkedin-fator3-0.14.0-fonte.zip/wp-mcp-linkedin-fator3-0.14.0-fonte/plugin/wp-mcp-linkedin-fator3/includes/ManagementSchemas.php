<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;
final class ManagementSchemas {
    public static function all(): array {
        $s=static fn(int $n=200)=>['type'=>'string','minLength'=>1,'maxLength'=>$n];
        $num=['type'=>'string','pattern'=>'^[0-9]{1,40}$'];$hash=['type'=>'string','pattern'=>'^[a-f0-9]{64}$'];
        $id=['type'=>'string','pattern'=>'^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$'];$bool=['type'=>'boolean'];
        $enum=static fn(array $v)=>['type'=>'string','enum'=>$v];
        $c=['connection_id'=>$id];$a=$c+['account_id'=>$num];$p=$c+['page_id'=>$num];
        $money=Schemas::obj(['amount'=>['type'=>'string','pattern'=>'^[0-9]{1,12}(\.[0-9]{1,4})?$'],'currency'=>['type'=>'string','pattern'=>'^[A-Z]{3}$']],['amount','currency']);
        $schedule=Schemas::obj(['start'=>['type'=>'integer','minimum'=>1],'end'=>['type'=>'integer','minimum'=>1]],['start']);
        $target=Schemas::obj(['facet'=>$enum(array_keys(Management::FACETS)),'name'=>$s(),'selected_urn'=>$s(),'search_offset'=>['type'=>'integer','minimum'=>0,'maximum'=>10000],'exclude'=>$bool],['facet','name']);
        $group=['name'=>$s(),'total_budget'=>$money,'schedule'=>$schedule];
        $campaign=$group+['campaign_group_id'=>$num,'type'=>$enum(['TEXT_AD','SPONSORED_UPDATES','SPONSORED_INMAILS','DYNAMIC']),'cost_type'=>$enum(['CPC','CPM','CPV']),'objective'=>$enum(['BRAND_AWARENESS','WEBSITE_VISIT','ENGAGEMENT','VIDEO_VIEW','LEAD_GENERATION','WEBSITE_CONVERSION','JOB_APPLICANT']),'format'=>$s(60),'optimization'=>$s(60),'bidding_strategy'=>$s(60),'daily_budget'=>$money,'bid'=>$money,'language'=>['type'=>'string','pattern'=>'^[a-z]{2}$'],'country'=>['type'=>'string','pattern'=>'^[A-Z]{2}$'],'offsite_delivery'=>$bool,'targeting'=>['type'=>'array','items'=>$target,'maxItems'=>20],'audience_expansion'=>$bool];
        $postUrn=['type'=>'string','pattern'=>'^urn:li:(share|ugcPost):[0-9]+$'];$media=['type'=>'string','pattern'=>'^urn:li:(image|video):[A-Za-z0-9_-]+$'];
        $creative=['campaign_id'=>$num,'page_id'=>$num,'post_id'=>$postUrn,'name'=>$s(),'form_id'=>$num,'call_to_action'=>$enum(['APPLY_NOW','DOWNLOAD','GET_QUOTE','LEARN_MORE','SIGN_UP','SUBSCRIBE','REGISTER','REQUEST_DEMO'])];
        $post=['text'=>$s(3000),'content_type'=>$enum(['text','image','video','article']),'media_id'=>$media,'title'=>$s(200),'description'=>$s(500),'article_url'=>['type'=>'string','format'=>'uri','maxLength'=>2048],'thumbnail_id'=>['type'=>'string','pattern'=>'^urn:li:image:[A-Za-z0-9_-]+$']];
        $common=['dry_run'=>['type'=>'boolean','default'=>true],'expected_revision'=>$hash,'request_key'=>$id,'confirm_token'=>$hash,'confirm'=>$bool];
        $out=[];
        foreach(['campaign-group'=>$group,'campaign'=>$campaign,'creative'=>$creative] as $kind=>$fields){
            $oid=[$kind==='creative'?'creative_id':str_replace('-','_',$kind).'_id'=>$num];
            $out['get-'.$kind]=Schemas::obj($a+$oid,array_keys($a+$oid));
            $required=match($kind){'campaign-group'=>['name'],'campaign'=>['name','campaign_group_id','type','cost_type','objective','language','country','targeting'],'creative'=>['campaign_id','page_id','post_id']};
            $out['create-'.$kind]=Schemas::obj($a+$common+['fields'=>Schemas::obj($fields,$required)],array_merge(array_keys($a),['expected_revision','request_key','fields']));
            $updateFields=$fields;unset($updateFields['campaign_group_id'],$updateFields['campaign_id'],$updateFields['page_id'],$updateFields['post_id'],$updateFields['form_id'],$updateFields['form_version']);
            $out['update-'.$kind]=Schemas::obj($a+$oid+$common+['fields'=>Schemas::obj($kind==='creative'?['status'=>$enum(['PAUSED','ARCHIVED'])]:$updateFields+['status'=>$enum(['PAUSED','ARCHIVED'])])],array_merge(array_keys($a+$oid),['expected_revision','request_key','fields']));
            foreach(['activate','delete'] as $verb)$out[$verb.'-'.$kind]=Schemas::obj($a+$oid+$common,array_merge(array_keys($a+$oid),['expected_revision','request_key']));
        }
        $out['get-ad-account']=Schemas::obj($a,array_keys($a));$out['get-organization']=Schemas::obj($p,array_keys($p));
        $out['get-post']=Schemas::obj($p+['post_id'=>$postUrn],['connection_id','page_id','post_id']);
        $out['create-post']=Schemas::obj($p+$common+['fields'=>Schemas::obj($post,['text','content_type'])],array_merge(array_keys($p),['expected_revision','request_key','fields']));
        $out['update-post']=Schemas::obj($p+['post_id'=>$postUrn]+$common+['fields'=>Schemas::obj(['text'=>$s(3000)],['text'])],['connection_id','page_id','post_id','expected_revision','request_key','fields']);
        $out['delete-post']=Schemas::obj($p+['post_id'=>$postUrn]+$common,['connection_id','page_id','post_id','expected_revision','request_key']);
        $out['create-comment']=Schemas::obj($p+['post_id'=>$postUrn]+$common+['fields'=>Schemas::obj(['text'=>$s(1250)],['text'])],['connection_id','page_id','post_id','expected_revision','request_key','fields']);
        foreach(['image','video'] as $kind)$out['initialize-'.$kind.'-upload']=Schemas::obj($p+$common+($kind==='video'?['file_size'=>['type'=>'integer','minimum'=>1,'maximum'=>5368709120]]:[]),array_merge(array_keys($p),['expected_revision','request_key'], $kind==='video'?['file_size']:[]));
        $out['search-targeting']=Schemas::obj($a+['facet'=>$enum(array_keys(Management::FACETS)),'search'=>$s(),'offset'=>['type'=>'integer','minimum'=>0,'maximum'=>10000],'language'=>['type'=>'string','pattern'=>'^[a-z]{2}$'],'country'=>['type'=>'string','pattern'=>'^[A-Z]{2}$']],['connection_id','account_id','facet','search']);
        $out['search-locations']=Schemas::obj($a+['search'=>$s(),'offset'=>['type'=>'integer','minimum'=>0,'maximum'=>10000]],['connection_id','account_id','search']);
        $out['get-write-operation']=Schemas::obj(['operation_id'=>$hash],['operation_id']);
        $out['reconcile-write-operation']=Schemas::obj(['operation_id'=>$hash,'expected_operation_revision'=>['type'=>'integer','minimum'=>1]],['operation_id','expected_operation_revision']);
        $out['inspect-token']=Schemas::obj($c,array_keys($c));
        $out['refresh-token']=Schemas::obj($c+['expected_revision'=>['type'=>'integer','minimum'=>1]],['connection_id','expected_revision']);
        $out['oauth-start']=Schemas::obj($c+['expected_revision'=>['type'=>'integer','minimum'=>1],'scopes'=>['type'=>'array','items'=>$enum(Credentials::SCOPES),'minItems'=>1,'maxItems'=>count(Credentials::SCOPES),'uniqueItems'=>true]],['connection_id','expected_revision','scopes']);
        return $out;
    }
}
