<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** Credential material is stored only in the encrypted provider store. */
final class Credentials {
    private static ?array $authorizationTrace=null;
    public const SCOPES=['openid','profile','r_ads','rw_ads','r_ads_reporting','r_organization_social','w_organization_social','r_organization_admin','rw_organization_admin','r_marketing_leadgen_automation','rw_conversions'];
    public static function binding(array $c): string {return hash('sha256',Util::json([$c['token'],$c['client_id'],$c['client_secret']]));}
    public static function effective(array $c): array {
        $r=Store::get('credential',$c['id']);
        if($r&&hash_equals($r['value']['binding'],self::binding($c)))foreach(['token','refresh_token','expires_at','refresh_expires_at','credential_generation','refresh_binding_verified'] as $k)if(isset($r['value'][$k]))$c[$k]=$r['value'][$k];
        $p=Store::get('token_proof',$c['id']);
        if($p&&hash_equals($p['value']['binding'],self::binding($c))){$proof=$p['value'];unset($proof['binding']);$c['identity']=ConnectionChanges::publicProof($proof,$c);$c['expires_at']=$proof['expires_at'];}
        $pending=Store::get('credential_candidate',$c['id']);$c['authorization_pending']=$pending&&($pending['value']['user']??0)===get_current_user_id()&&$pending['expires_at']>time()?['expires_at'=>$pending['expires_at'],'expected_revision'=>$pending['value']['revision']]:null;
        return $c+['refresh_token'=>'','refresh_expires_at'=>0];
    }
    /** A closed diagnostic projection: never persist a response body or OAuth material. */
    private static function traceResponse(string $endpoint,?int $http,?array $v,array $body,string $outcome): void {
        if(self::$authorizationTrace===null)return;
        $step=['step'=>$endpoint==='accessToken'?'exchange':'introspection','endpoint'=>$endpoint,'http_status'=>$http,'result'=>$outcome];
        if($v!==null&&$endpoint==='introspectToken'){
            $client=$v['client_id']??null;
            if(!is_string($client)||!preg_match('/^[a-zA-Z0-9_-]{1,160}$/D',$client))$client=null;
            foreach(['token','client_secret'] as $k)if($client!==null&&!empty($body[$k])&&str_contains($client,$body[$k]))$client=null;
            $step+=['active'=>is_bool($v['active']??null)?$v['active']:null,'client_id'=>$client,
                'expires_at'=>is_int($v['expires_at']??null)&&$v['expires_at']>=0?$v['expires_at']:null,
                'status'=>in_array($v['status']??null,['active','expired','revoked'],true)?$v['status']:null,
                'verified_scopes'=>is_string($v['scope']??null)?array_values(array_intersect(self::SCOPES,preg_split('/[\s,]+/',$v['scope']))):[]];
        }elseif($v!==null&&$endpoint==='accessToken')$step['expires_in']=is_int($v['expires_in']??null)&&$v['expires_in']>=0?$v['expires_in']:null;
        self::$authorizationTrace['steps'][]=$step;
    }
    private static function request(string $endpoint,array $body): array {
        if(!in_array($endpoint,['accessToken','introspectToken'],true))throw new Fault('endpoint_forbidden','Endpoint de autorização não permitido.');
        $r=wp_remote_post('https://www.linkedin.com/oauth/v2/'.$endpoint,['body'=>http_build_query($body,'','&',PHP_QUERY_RFC3986),'headers'=>['Content-Type'=>'application/x-www-form-urlencoded','Accept'=>'application/json'],'redirection'=>0,'sslverify'=>true,'timeout'=>12,'limit_response_size'=>65536]);
        if(is_wp_error($r)){self::traceResponse($endpoint,null,null,$body,'transport_error');throw new Fault('oauth_unavailable','O LinkedIn não confirmou a solicitação de credencial.');}
        $http=wp_remote_retrieve_response_code($r);$raw=wp_remote_retrieve_body($r);$v=json_decode($raw,true);
        $ok=$http>=200&&$http<300&&strlen($raw)<65536&&is_array($v);
        self::traceResponse($endpoint,$http,$ok?$v:null,$body,$ok?'http_ok':'response_rejected');
        if(!$ok)throw new Fault('oauth_rejected',$endpoint==='introspectToken'?'O LinkedIn recusou a introspecção. Confira o aplicativo e o token; HTTP 400 pode indicar Client ID ou token inválido, e HTTP 401 indica Primary Client Secret inválido.':'O LinkedIn recusou a troca OAuth. Confira o aplicativo, seu segredo e o código ou Refresh Token.',['http_status'=>$http,'credential_context'=>$endpoint==='introspectToken'?'client_id_and_primary_client_secret':'oauth_authorization','fields_to_check'=>$endpoint==='introspectToken'?['client_id','client_secret','token']:['client_id','client_secret','refresh_token']]);
        return $v;
    }
    private static function app(array $c): void {if(empty($c['client_id'])||empty($c['client_secret']))throw new Fault('application_required','Informe Client ID e Primary Client Secret (Developers → aplicativo → Auth → Application credentials) para verificar as permissões.');}
    public static function inspect(array $c): array {
        Connections::usable($c);self::app($c);
        $r=self::request('introspectToken',['client_id'=>$c['client_id'],'client_secret'=>$c['client_secret'],'token'=>$c['token']]);
        if((isset($r['scope'])&&!is_string($r['scope']))||(isset($r['client_id'])&&!is_string($r['client_id']))||(isset($r['expires_at'])&&!is_numeric($r['expires_at'])))throw new Fault('oauth_invalid_response','A introspecção devolveu campos com tipos inválidos.');
        $reason=($r['active']??false)!==true?'inactive':(!empty($r['client_id'])&&(!is_string($r['client_id'])||!hash_equals($c['client_id'],$r['client_id']))?'client_id_mismatch':(!empty($r['expires_at'])&&(!is_numeric($r['expires_at'])||(int)$r['expires_at']<=time())?'expired':null));
        if($reason!==null)throw new Fault('token_rejected',match($reason){'inactive'=>'A introspecção devolveu active=false ou não confirmou atividade. Confira o vínculo entre aplicativo e token.','client_id_mismatch'=>'A introspecção devolveu Client ID diferente do aplicativo utilizado.','expired'=>'A introspecção devolveu validade vencida ou inválida.'}.' O token salvo foi preservado.',['verification_reason'=>$reason]);
        $scopes=array_values(array_filter(preg_split('/[\s,]+/',(string)($r['scope']??''))));
        return ['active'=>true,'client_id'=>(string)($r['client_id']??''),'scopes'=>$scopes,'expires_at'=>(int)($r['expires_at']??0),'checked_at'=>time(),'source'=>'linkedin_introspection'];
    }
    public static function member(array $c,array $scopes): ?array {
        if(array_diff(['openid','profile'],$scopes))return null;
        $r=wp_remote_get('https://api.linkedin.com/v2/userinfo',['headers'=>['Authorization'=>'Bearer '.$c['token'],'Accept'=>'application/json'],'redirection'=>0,'sslverify'=>true,'timeout'=>12,'limit_response_size'=>16384]);
        if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200)return null;
        $raw=wp_remote_retrieve_body($r);$v=json_decode($raw,true);
        if(strlen($raw)>=16384||!is_array($v)||!is_string($v['sub']??null)||$v['sub']===''||strlen($v['sub'])>512)return null;
        return ['subject'=>$v['sub'],'name'=>is_string($v['name']??null)?mb_substr(sanitize_text_field($v['name']),0,180):null,'source'=>'linkedin_userinfo'];
    }
    public static function requireScopes(array $c,array $needed): array {
        $proof=self::inspect($c);$missing=array_values(array_diff($needed,$proof['scopes']));
        if($missing)throw new Fault('scope_missing','O token não recebeu as permissões necessárias. Autorize o aplicativo novamente.',['required_scopes'=>$needed,'missing_scopes'=>$missing,'remote_write_sent'=>false]);
        return $proof;
    }
    public static function inspectOperation(array $i): array {
        Access::admin();return Store::lock('connection:'.$i['connection_id'],static function()use($i){$c=Connections::get($i['connection_id']);$proof=ConnectionChanges::verify($c);Connections::revalidate($c);ConnectionChanges::storeProof($c,$proof);return ConnectionChanges::publicProof($proof,$c);});
    }
    public static function status(): array {
        $out=[];foreach(Store::list('connection',0,100) as $row){$c=Connections::get($row['key']);$h=Store::get('credential_health',$c['id']);$proof=Store::get('token_proof',$c['id']);$v=$h['value']??[];
            $out[]=['connection_id'=>$c['id'],'enabled'=>$c['enabled'],'days_remaining'=>$c['expires_at']?(int)ceil(($c['expires_at']-time())/86400):null,'expires_at'=>$c['expires_at'],'refresh_configured'=>!empty($c['refresh_token']),'refresh_expires_at'=>$c['refresh_expires_at'],'credential_generation'=>$c['credential_generation'],'last_refresh_at'=>$v['last_refresh_at']??null,'last_result'=>$v['last_result']??'not_attempted','failures'=>$v['failures']??0,'next_attempt'=>($v['incident']['code']??null)==='identity_change_required'?null:($v['next_attempt']??($c['expires_at']&&!empty($c['refresh_token'])?max(time(),$c['expires_at']-3*86400):null)),'incident'=>self::publicIncident($v['incident']??null),'credential_notice_days'=>$c['credential_notice_days']??14,'notification_due_at'=>$c['expires_at']?max(0,$c['expires_at']-($c['credential_notice_days']??14)*86400):null,'notices'=>$v['notices']??[],'scopes'=>$proof&&hash_equals($proof['value']['binding'],self::binding($c))?$proof['value']['scopes']:[]];}
        return ['connections'=>$out,'next_maintenance'=>wp_next_scheduled(Config::KEY.'_maintenance')?:null,'oauth_callback'=>self::callbackUrl(),'refresh_requires_provider_approval'=>true,'conversion_access'=>Conversions::scopeStatus()];
    }
    private static function health(string $id,array $patch): void {$r=Store::get('credential_health',$id);Store::put('credential_health',$id,array_replace($r['value']??[],$patch),$r['revision']??0);}
    public static function refresh(array $i,bool $automatic=false): array {
        if(!$automatic)Access::admin();
        return Store::lock('connection:'.$i['connection_id'],static function()use($i,$automatic){
            $c=Connections::get($i['connection_id']);if(!$automatic&&$c['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a conexão antes de renovar.');
            if(!$c['enabled'])throw new Fault('connection_paused','Conexão pausada.');
            if(empty($c['refresh_token']))throw new Fault('refresh_unavailable','Este aplicativo não forneceu token de renovação. Autorize novamente.');
            $admin=get_userdata((int)$c['updated_by']);if(!$admin||!user_can($admin,'manage_options'))throw new Fault('not_authorized','Administrador da conexão não está autorizado.');
            try{
                self::app($c);if($c['refresh_expires_at']&&$c['refresh_expires_at']<=time())throw new Fault('refresh_expired','A autorização de renovação expirou.');
                $v=self::request('accessToken',['grant_type'=>'refresh_token','refresh_token'=>$c['refresh_token'],'client_id'=>$c['client_id'],'client_secret'=>$c['client_secret']]);
                $new=self::tokens($v,$c);$candidate=array_replace($c,$new);ConnectionChanges::formats($candidate,$c,$new);$proof=ConnectionChanges::verify($candidate);$new['expires_at']=$proof['expires_at'];
                $different=!empty($c['identity']['member']['subject'])&&!empty($proof['member']['subject'])&&!hash_equals($c['identity']['member']['subject'],$proof['member']['subject']);
                // A manually supplied refresh credential is not proof of continuity with the saved bearer.
                if($different||(empty($c['refresh_binding_verified'])&&!ConnectionChanges::sameIdentity($c,$candidate,$proof))){
                    Connections::revalidate($c);$pending=Store::get('credential_candidate',$c['id']);
                    Store::put('credential_candidate',$c['id'],['credentials'=>$new,'revision'=>$c['revision'],'user'=>(int)$c['updated_by']],$pending['revision']??0,time()+600);
                    throw new Fault('identity_change_required',self::identityAction());
                }
                Connections::revalidate($c);
                // Overlay keeps the authorization revision used by Core, grants and subscription journals stable.
                $raw=Store::get('connection',$c['id']);$old=Store::get('credential',$c['id']);
                ConnectionChanges::transaction(static function()use($c,$new,$raw,$old,$candidate,$proof){Store::put('credential',$c['id'],$new+['binding'=>self::binding($raw['value']),'credential_generation'=>$c['credential_generation']+1],$old['revision']??0);ConnectionChanges::storeProof($candidate,$proof);});
                self::health($c['id'],['last_refresh_at'=>time(),'last_result'=>'refreshed','failures'=>0,'next_attempt'=>max(time()+3600,$new['expires_at']-3*86400),'incident'=>null,'notices'=>[]]);
                return ['refreshed'=>true,'grants_preserved'=>true,'credential_revision'=>$c['revision'],'expires_at'=>$new['expires_at'],'credential_generation'=>$c['credential_generation']+1];
            }catch(Fault $e){$h=Store::get('credential_health',$c['id']);$fails=($h['value']['failures']??0)+1;
                $incident=self::incident($e->reason,$h['value']['incident']??null);
                self::health($c['id'],['last_result'=>$e->reason,'failures'=>$fails,'next_attempt'=>$e->reason==='identity_change_required'?null:time()+min(86400,300*(2**min($fails-1,8))),'incident'=>$incident]);
                self::notice($c,$e->reason==='identity_change_required'?'identity_confirmation':'refresh_failure');throw $e;
            }
        });
    }
    private static function tokens(array $v,array $old): array {
        if(!is_string($v['access_token']??null)||$v['access_token']===''||strlen($v['access_token'])>16384||preg_match('/[\x00-\x20]/',$v['access_token'])||!is_numeric($v['expires_in']??null)||(int)$v['expires_in']<1)throw new Fault('oauth_invalid_response','A resposta de renovação não contém token e validade utilizáveis.');
        $refresh=$v['refresh_token']??$old['refresh_token'];if(!is_string($refresh)||strlen($refresh)>16384||preg_match('/[\x00-\x20]/',$refresh))throw new Fault('oauth_invalid_response','Token de renovação inválido.');
        return ['token'=>$v['access_token'],'expires_at'=>time()+(int)$v['expires_in'],'refresh_token'=>$refresh,'refresh_binding_verified'=>true,'refresh_expires_at'=>isset($v['refresh_token_expires_in'])?time()+max(0,(int)$v['refresh_token_expires_in']):($old['refresh_expires_at']??0)];
    }
    public static function identityAction(): string {return 'A primeira renovação precisa de confirmação de identidade. Use Renovar agora; depois marque Usar autorização candidata, simule e confirme a identidade e as concessões. O token salvo continua em uso.';}
    private static function incident(string $code,?array $old): array {
        $same=($old['code']??null)===$code;
        return ['code'=>$code,'id'=>$same?($old['id']??hash('sha256',$code.':'.($old['opened_at']??0))):wp_generate_uuid4(),'opened_at'=>$same?($old['opened_at']??time()):time(),'last_at'=>time()];
    }
    private static function publicIncident(?array $incident): ?array {
        if($incident!==null&&($incident['code']??null)==='identity_change_required')$incident+=['action'=>'refresh_and_confirm_identity','message'=>self::identityAction(),'button'=>'Renovar agora'];
        return $incident;
    }
    /** Called inside the connection transaction; it never sends mail or contacts LinkedIn. */
    public static function saved(array $c,bool $verified): void {
        $h=Store::get('credential_health',$c['id']);$v=$h['value']??[];
        if(!empty($c['refresh_token'])&&empty($c['refresh_binding_verified'])){
            self::health($c['id'],['last_result'=>'identity_change_required','next_attempt'=>null,'incident'=>self::incident('identity_change_required',$v['incident']??null)]);
        }elseif($verified||($v['incident']['code']??null)==='identity_change_required'){
            self::health($c['id'],['last_result'=>$verified?'verified':($v['last_result']??'not_attempted'),'failures'=>0,'next_attempt'=>null,'incident'=>null,'notices'=>[]]);
        }
    }
    private static function notice(array $c,string $kind): void {
        $h=Store::get('credential_health',$c['id']);$v=$h['value']??[];$notices=$v['notices']??[];
        if($kind==='identity_confirmation'){
            if(($v['incident']['code']??null)!=='identity_change_required')return;
            if(!empty($c['identity']['active'])&&$c['expires_at']&&$c['expires_at']-time()>($c['credential_notice_days']??14)*86400)return;
            $incident=self::incident('identity_change_required',$v['incident']);$key=$kind.':'.$incident['id'];
            if(isset($notices[$key]))return;
            // Preserve legacy receipts for this still-open incident, even across token replacements.
            foreach($notices as $oldKey=>$receipt)if(str_starts_with($oldKey,'refresh_failure:')&&!empty($receipt['sent'])&&($receipt['at']??0)>=$incident['opened_at'])return;
            $notices[$key]=['at'=>time(),'sent'=>false,'attempted'=>true,'connection_revision'=>$c['revision']??null,'notice_days'=>$c['credential_notice_days']??14];self::health($c['id'],['incident'=>$incident,'notices'=>$notices]);
        }else{
            $key=$kind.':'.$c['expires_at'];
            if(isset($notices[$key])&&($notices[$key]['sent']||$notices[$key]['at']>time()-86400))return;
        }
        $destination=get_option('admin_email');$sent=false;
        $text=match($kind){'identity_confirmation'=>self::identityAction(),'refresh_failure'=>'a renovação automática falhou. O token atual será preservado até seu vencimento.','expires_14'=>'o token vence em até '.($c['credential_notice_days']??14).' dias.','expires_3'=>'o token vence em até 3 dias.',default=>'o token está vencido.'};
        if(is_email($destination))$sent=(bool)wp_mail($destination,'Fator3 MCP LinkedIn — atenção à credencial','A conexão '.$c['label'].' exige atenção: '.$text.' Acesse Ferramentas → Fator3 MCP LinkedIn → Conexões.');
        $notices[$key]=['at'=>time(),'sent'=>$sent,'attempted'=>true,'connection_revision'=>$c['revision']??null,'notice_days'=>$c['credential_notice_days']??14];self::health($c['id'],['notices'=>$notices]);
    }
    public static function tick(): void {
        $until=microtime(true)+20;
        foreach(Store::list('connection',0,100) as $row){if(microtime(true)>$until)break;
            try{Store::lock('connection:'.$row['key'],static function()use($row){
                $c=Connections::get($row['key']);if(!$c['enabled']||!$c['token']||!$c['expires_at'])return;
                $h=Store::get('credential_health',$c['id']);$remaining=$c['expires_at']-time();
                if(($h['value']['incident']['code']??null)==='identity_change_required'){self::notice($c,'identity_confirmation');return;}
                if(!empty($c['refresh_token'])&&$remaining<=3*86400&&($h['value']['next_attempt']??0)<=time())self::refresh(['connection_id'=>$c['id']],true);
                elseif(empty($c['refresh_token'])&&$remaining<=($c['credential_notice_days']??14)*86400)self::notice($c,$remaining<=0?'expired':($remaining<=3*86400?'expires_3':'expires_14'));
            });}catch(\Throwable $e){/* Failure state remains visible; other connections continue. */}
        }
    }
    public static function callbackUrl(): string {return admin_url('admin-post.php?action=f3_linkedin_oauth_callback');}
    public static function start(array $i): array {
        Access::admin();$c=Connections::get($i['connection_id']);self::app($c);if($c['revision']!==$i['expected_revision'])throw new Fault('revision_conflict','Releia a conexão.');
        if(wp_parse_url(self::callbackUrl(),PHP_URL_SCHEME)!=='https')throw new Fault('https_required','O retorno de autorização exige HTTPS.');
        $state=bin2hex(random_bytes(32));$key=hash('sha256',$state);
        Store::put('oauth_state',$key,['connection_id'=>$c['id'],'revision'=>$c['revision'],'user'=>get_current_user_id(),'session'=>hash('sha256',wp_get_session_token()),'expires'=>time()+600,'scopes'=>$i['scopes'],'callback_url'=>self::callbackUrl(),'app_binding'=>hash_hmac('sha256',Util::json([$c['client_id'],$c['client_secret']]),wp_salt('auth')),'used'=>false],0,time()+600);
        return ['consent_url'=>'https://www.linkedin.com/oauth/v2/authorization?'.http_build_query(['response_type'=>'code','client_id'=>$c['client_id'],'redirect_uri'=>self::callbackUrl(),'scope'=>implode(' ',$i['scopes']),'state'=>$state],'','&',PHP_QUERY_RFC3986),'expires_at'=>time()+600,'callback_url'=>self::callbackUrl()];
    }
    public static function finish(string $state,string $code,string $providerError=''): array {
        Access::admin();$prior=self::$authorizationTrace;
        self::$authorizationTrace=['operation_id'=>wp_generate_uuid4(),'connection_id'=>null,'requested_scopes'=>[],'steps'=>[]];
        try{
            $r=Result::run(static fn()=>self::finishCandidate($state,$code,$providerError));
            self::$authorizationTrace['result']=$r['code'];
            self::$authorizationTrace['verification_reason']=$r['details']['verification_reason']??null;
            Audit::record('oauth-finish',['connection_id'=>self::$authorizationTrace['connection_id']],$r,null,'oauth_callback',self::$authorizationTrace);
            $diagnostic=self::$authorizationTrace;
            if(!$r['success'])throw new Fault($r['code'],$r['message'],($r['details']??[])+['authorization_diagnostic'=>$diagnostic,'audit_warning'=>$r['audit_warning']??null]);
            return $r['data']+['authorization_diagnostic'=>$diagnostic,'audit_warning'=>$r['audit_warning']??null];
        }finally{self::$authorizationTrace=$prior;}
    }
    private static function finishCandidate(string $state,string $code,string $providerError): array {
        Access::admin();if(!preg_match('/^[a-f0-9]{64}$/D',$state)||($code===''&&$providerError==='')||strlen($code)>4096)throw new Fault('oauth_state_invalid','Retorno de autorização inválido.');
        $key=hash('sha256',$state);
        return Store::lock('oauth:'.$key,static function()use($key,$code,$providerError){$r=Store::get('oauth_state',$key);$v=$r['value']??[];
            if(!$r||($v['used']??true)||($v['expires']??0)<time()||($v['user']??0)!==get_current_user_id()||!hash_equals($v['session'],hash('sha256',wp_get_session_token())))throw new Fault('oauth_state_invalid','Retorno expirado, já usado ou de outra sessão.');
            self::$authorizationTrace['connection_id']=$v['connection_id'];self::$authorizationTrace['requested_scopes']=array_values(array_intersect(self::SCOPES,$v['scopes']??[]));
            $v['used']=true;Store::put('oauth_state',$key,$v,$r['revision'],$v['expires']);
            if($providerError!=='')throw new Fault('oauth_denied','O LinkedIn não concluiu o consentimento. A autorização salva foi preservada.');
            return Store::lock('connection:'.$v['connection_id'],static function()use($v,$code){$c=Connections::get($v['connection_id']);if($c['revision']!==$v['revision'])throw new Fault('revision_conflict','A conexão mudou durante a autorização.');self::app($c);
                if(isset($v['app_binding'])&&!hash_equals($v['app_binding'],hash_hmac('sha256',Util::json([$c['client_id'],$c['client_secret']]),wp_salt('auth'))))throw new Fault('revision_conflict','O aplicativo mudou durante a autorização.');
                $reply=self::request('accessToken',['grant_type'=>'authorization_code','code'=>$code,'client_id'=>$c['client_id'],'client_secret'=>$c['client_secret'],'redirect_uri'=>$v['callback_url']??self::callbackUrl()]);
                // New authorization is never silently attached to the old refresh credential.
                $tokens=self::tokens($reply,['refresh_token'=>'','refresh_expires_at'=>0]);
                $new=array_replace($c,$tokens);ConnectionChanges::formats($new,$c,$tokens);$proof=ConnectionChanges::verify($new);$tokens['expires_at']=$proof['expires_at'];Connections::revalidate($c);
                $old=Store::get('credential_candidate',$c['id']);Store::put('credential_candidate',$c['id'],['credentials'=>$tokens,'revision'=>$c['revision'],'user'=>get_current_user_id()],$old['revision']??0,time()+600);
                return ['authorized'=>true,'connection_id'=>$c['id'],'pending_confirmation'=>true,'expires_at'=>time()+600,'consumer_reconfirmation_required'=>true];
            });
        });
    }
    public static function callback(): void {
        nocache_headers();header('Referrer-Policy: no-referrer');
        $input=static fn($key)=>is_string($_GET[$key]??null)?wp_unslash($_GET[$key]):'';
        $r=Result::run(static fn()=>self::finish($input('state'),$input('code'),$input('error')));
        set_transient('f3_linkedin_oauth_notice_'.get_current_user_id(),['success'=>$r['success'],'code'=>$r['code'],'message'=>$r['message']??'Autorização conferida. Use a candidata, simule e confirme para salvar.','diagnostic'=>$r['data']['authorization_diagnostic']??$r['details']['authorization_diagnostic']??null],300);
        wp_safe_redirect(add_query_arg(['page'=>Config::SLUG,'tab'=>'connections','connection_id'=>$r['data']['authorization_diagnostic']['connection_id']??$r['details']['authorization_diagnostic']['connection_id']??''],admin_url('tools.php')));exit;
    }
}
