# Fator3 MCP LinkedIn 0.14.0

31/10/2026. Base aceita diretamente: 0.13.0. Pedidos MCP LinkedIn 16 e 17.

- Retorno OAuth auditado com diagnóstico fechado, motivos específicos e exibição na tela; aplicativo/URI vinculados ao início e state de uso único. A interface conserva os escopos conferidos, incluindo openid/profile quando presentes.
- Incidente de primeira renovação manual visível sem e-mail na gravação. Aviso apenas na janela configurada (padrão 14 dias) para token ativo, uma tentativa por incidente, independente de nova validade. A manutenção aguarda confirmação humana.
- Configuração credential_notice_days por conexão com simulação, revisão e confirmação; recibo guarda a revisão e a janela utilizadas.
- Permanecem 93 operações; campo aditivo em save-connection e limite oauth-start corrigido para as 11 opções já publicadas. Sem migração destrutiva, nova tabela ou dependência de outro pacote.

Leia CREDENTIALS.md para diagnóstico, recuperação, política e limites. O relato de token recém-emitido inativo não tem causa comprovada sem nova autorização real. Fixtures não homologam consentimento, refresh ou entrega de e-mail no fornecedor. Documentos/code dos acompanhantes permanecem de seus responsáveis.
