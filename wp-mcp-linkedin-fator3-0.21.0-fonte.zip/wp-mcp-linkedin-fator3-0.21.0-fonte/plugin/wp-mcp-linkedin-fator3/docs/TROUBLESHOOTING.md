# Diagnóstico e códigos — 0.21.0

Como descobrir o que está errado, o que cada código significa e o que fazer. Os nomes em negrito são botões da aba **Diagnóstico**.

## Por onde começar

| Pergunta | Ação | Como interpretar |
|---|---|---|
| O worker, o armazenamento e a criptografia estão disponíveis? | **Consultar estado local** ou `linkedin/status` | Leia o resumo, os avisos das agendas e os incidentes de credencial. **Ver detalhes técnicos** mostra os dados completos. O diagnóstico não repara o worker nem renova tokens. |
| O plugin passa nas verificações internas? | **Executar autoteste local** ou `linkedin/selftest` | O painel mostra quantas verificações locais foram aprovadas. O resultado não confirma produtos nem permissões no LinkedIn. |
| Esta conexão consegue ler este ativo? | Escolha conexão, canal e ativo e use **Validar ativo no LinkedIn**, ou `linkedin/validate-connection` | Consulta o fornecedor e guarda a prova local dos metadados. Seleção vazia ou conexão pausada não habilita o botão. |
| Quais escopos o token realmente tem? | **Verificar permissões**, na aba **Conexão**, ou `linkedin/inspect-token` | Mostra o que o LinkedIn concedeu, não o que foi pedido. |
| A Conversions API está pronta? | `linkedin/diagnose-conversions` | Siga a ação de cada item com `ok=false`. |
| Por que uma concessão aparece obsoleta? | Leia as revisões e a seleção vigentes | Validar de novo não reconfirma uma concessão obsoleta. Se o vínculo ainda corresponde ao objetivo, simule e reconfirme a concessão afetada. |
| O que aconteceu e quando? | `linkedin/audit` | Eventos do mais recente para o mais antigo, com código sanitizado. Use `since`. |

Em **Verificar acesso a um ativo**, trocar conexão, canal ou identificador só muda a seleção. O canal de formulários mostra as contas autorizadas, não os formulários; validar confere os metadados da conta, não o acesso às respostas. Em **Estado local**, uma segunda consulta substitui a anterior. Uma validação externa já enviada ainda pode concluir e guardar a prova do alvo original.

## Códigos mais frequentes

| Código | Significado | O que fazer |
|---|---|---|
| `not_authorized` | Falta `manage_options`, a política do transporte recusou ou a concessão do consumidor não vale. | Confirme o perfil do usuário ou a concessão vigente. |
| `invalid_input` | Parâmetro fora do schema ou combinação recusada. | Leia `message` e `details`; confira `input-schemas.json`. |
| `revision_conflict` | O registro mudou depois da leitura. | Releia e decida de novo. Uma revisão não substitui outra. |
| `not_configured` | Conexão inexistente, sem token ou sem segredo. | Confira a conexão e suas credenciais. |
| `connection_paused` | A conexão está pausada. | Ative-a na aba **Conexão**, se for o caso. |
| `application_required` | Faltam Client ID e Primary Client Secret, ou tentou-se ativar a conexão sem as três credenciais. | Informe as três, ou salve a conexão pausada para autorizar depois. |
| `asset_access_denied` | O ativo não está selecionado na conexão ou não pertence a ela. | Grave a seleção em **Ativos**. |
| `scope_missing` | O token não tem o escopo exigido. | Autorize de novo com a permissão necessária. Mudar rótulos locais não resolve. |
| `token_expired`, `token_rejected` | Token vencido ou recusado pelo LinkedIn. | Renove e valide a credencial. O histórico local continua legível. |
| `rate_limited` | Quota do fornecedor. | Aguarde `retry_after`. O agendador adia sozinho. |
| `upstream_validation` | O LinkedIn recusou campo, versão ou produto. | Confira versão da API, campo, produto e aprovação do aplicativo. |
| `app_account_not_listed` | A conta de anúncios não está associada ao aplicativo. | Developers → aplicativo → Products → Advertising API → View Ad Accounts → Add Ad Account. |
| `operation_uncertain`, `verification_pending` | O efeito remoto não foi confirmado. | Consulte a operação e reconcilie sem reenviar. O bloqueio vale só para a mesma intenção. |
| `preview_required`, `preview_stale` | Falta a prévia ou ela expirou. | Releia o objeto e gere nova prévia. |
| `simulation_required` | A mudança exige simulação e confirmação. | Simule e confirme na mesma revisão. |
| `identity_change_required` | O token novo é de outra identidade. | Siga a troca guiada de CREDENTIALS.md. Não repita tentativas automáticas. |
| `refresh_unavailable`, `refresh_expired` | O aplicativo não emitiu token de renovação ou o prazo venceu. | Autorize de novo. O token atual é preservado. |
| `oauth_rejected` | O LinkedIn recusou a introspecção ou a troca OAuth. | Confira aplicativo, segredo e token. HTTP 400 costuma indicar Client ID ou token inválido; HTTP 401, segredo inválido. |
| `targeting_ambiguous` | A busca de segmentação devolveu mais de um resultado. | Escolha um resultado da busca. |
| `history_changed` | O acervo ou a autorização mudou durante a paginação. | Reinicie a consulta ou a exportação com nova chave. |
| `response_limit` | A resposta passaria do orçamento. | Reduza campos ou `limit`. Resposta truncada não é completa. |
| `cipher_unreadable` | Registro cifrado ilegível. | Confira salts e restauração. Não regrave por cima. |
| `storage_unavailable`, `persistence_unconfirmed` | O banco não respondeu ou não confirmou a gravação. | Verifique banco, espaço e bloqueios. Releia antes de repetir. |
| `busy` | Outra operação concorrente está em andamento. | Repita depois. |

## Avisos do worker em `linkedin/status`

`issues` pode trazer `worker_missing`, `maintenance_missing`, `schedule_overdue`, `schedule_authorization_failed`, `schedule_retry_pending`, `schedule_job_unreadable`, `queue_migration_pending` e `queue_record_unreadable`. A tabela de ações está em WORKER.md.

`schedule_retry_pending` indica que a agenda aguarda nova tentativa da mesma ocorrência. Não recrie a agenda para antecipar a execução.

O cron depende de visitas ao site quando não há agendador do servidor. `wp f3-linkedin run` executa uma passagem. O usuário que criou a agenda precisa continuar autorizado.

## Autorização pelo navegador

No retorno OAuth, `token_rejected` vem acompanhado de um diagnóstico que distingue token inativo, Client ID divergente e token vencido. Resposta HTTP 200 com `active=false` pode indicar token e aplicativo que não se correspondem. O corpo bruto da resposta nunca é exposto. O retorno exige HTTPS (`https_required`).

## Anúncios e publicações

Criação recusada pelo LinkedIn sem recibo fica com estado `rejected`, com o HTTP e a mensagem sanitizada; depois de corrigir a causa, use nova chave. Quando não há recibo conciliável, `close-write-operation` exige decisão explícita, revisão e aceite do risco de duplicação. Não apague o diário e não trate `closed` ou `unknown` como ausência comprovada. Veja MANAGEMENT.md.

## Formulários de contato

`leadNotifications` usa `q=criteria` e `owner.value`; `leadFormResponses` continua com `q=owner`. Falha anterior ao envio informa `remote_effect:none`, a fase e o motivo; um recibo incerto já existente continua `unknown`. Para formulários novos, confira LEAD-DISCOVERY.md, as duas seleções, o contrato do consumidor, o endereço de notificações e `lead-discovery-status`.

## Conversões pelo servidor

| Código | O que fazer |
|---|---|
| `service_principal_unsupported` | O site está sem o Fator3 MCP ou o MCP instalado não oferece o registro central de serviço. Não é problema de credencial do LinkedIn. |
| `service_record_unconfirmed` | Confira persistência e digest no canal compatível. Não repita o envio. |
| `service_authority_unavailable`, `service_identity_mismatch` | Verifique concessão, revisão, ativo e prova local. Não vincule referência antiga a concessão nova. |
| `service_operation_unbound` | Diário anterior ao vínculo de serviço. |
| `regra_divergente` | A regra de servidor do Site Core difere da regra concedida. |

Veja SERVICE-AUDIT.md e CONVERSIONS.md.

## Conexão ativa sem token

O aviso `connection_without_token` identifica uma conexão preservada na atualização. Abra a conexão em Conexões: configure o acesso ou salve-a pausada. Uma criação ou reativação sem token retorna `application_required`. O diagnóstico não faz reparo automático.

## Referência gerada

Exemplos de mensagens literais do runtime. O mesmo código admite mensagens distintas conforme a causa. Erros dinâmicos do fornecedor também são possíveis.

| Código | Exemplo de mensagem |
|---|---|
| `acao_comercial` | Esta regra já tem concessão comercial ativa. Escolha outra regra para aquisição. |
| `acao_de_aquisicao` | A etapa comercial exige regra distinta da aquisição. |
| `acao_invalida` | Escolha o ID numérico da regra comercial. |
| `ad_source_binding_invalid` | O anúncio não corresponde à identidade solicitada. |
| `ad_source_not_associated` | A resposta não identifica um anúncio patrocinado. |
| `application_required` | Informe Access Token, Client ID e Primary Client Secret para ativar a conexão. Para preparar OAuth sem token, salve a conexão pausada. |
| `asset_access_denied` | Identidade do recurso divergente. |
| `automatic_grant_incomplete` | Seleção automática exige contrato 1.2, quatro permissões e callback do consumidor. |
| `budget_exhausted` | Orçamento da execução atingido. |
| `busy` | Operação concorrente em andamento. |
| `campaign_binding_invalid` | Campanha retornada fora da conta ou referência do lead. |
| `campaign_metadata_invalid` | Metadados da campanha não correspondem à resposta autorizada. |
| `catalog_limit` | Catálogo atingiu 10000 formulários nesta conta. |
| `cipher_unreadable` | Dados cifrados ilegíveis; confira a chave do site. |
| `concessao_divergente` | Concessão de outra finalidade ou ação. |
| `confirmation_required` | Informe o motivo e reconheça o risco de duplicação. |
| `connection_limit` | Limite de 100 conexões. |
| `connection_paused` | Conexão pausada. |
| `consumer_conflict` | Registro de consumidor divergente. |
| `consumer_unavailable` | Consumidor 1.2 indisponível. |
| `consumer_unregistered` | O consumidor precisa estar disponível para reconfirmar. |
| `context_rebind_required` | A reconciliação requer autorização explícita e identidade de aplicativo preservada. |
| `coverage_incomplete` | Listagem de assinaturas incompleta; criação recusada. |
| `credential_revalidation_required` | A nova credencial precisa ser validada antes de retomar este plano. |
| `crypto_unavailable` | Criptografia autenticada indisponível. |
| `cursor_expired` | A continuação expirou. Inicie uma nova consulta. |
| `destination_binding_required` | Informe a referência vinculada. |
| `destino_alterado` | O destino vinculado mudou. |
| `documentation_unavailable` | O conteúdo instalado difere do índice. Confira o pacote. |
| `encoding_failed` | Falha ao codificar os dados. |
| `endpoint_forbidden` | Endpoint de autorização não permitido. |
| `escopo_nao_verificado` | Valide a credencial atual. |
| `event_id_divergente` | Preserve o mesmo ID original do evento. |
| `evento_repetido_no_lote` | O lote contém o mesmo evento mais de uma vez. |
| `explicit_start_required` | Informe a data inicial desejada. |
| `export_limit` | Exportação limitada a 8 MiB de dados; divida a coleta. |
| `export_unavailable` | Arquivo ausente ou expirado. |
| `grant_confirmation_required` | Reconfirme as concessões do Lead Sync nesta tela. |
| `grant_revoked` | Concessão automática indisponível. |
| `grant_selection_invalid` | A concessão contém recursos fora da seleção candidata. |
| `history_changed` | O histórico ou a autorização mudou. Reinicie a consulta. |
| `https_required` | O retorno de autorização exige HTTPS. |
| `idempotency_conflict` | O evento já foi admitido com outro conteúdo ou instante. |
| `identity_selection_changed` | Troque primeiro a identidade mantendo a seleção salva. Altere a seleção em outro salvamento. |
| `incomplete_collection` | Exportação exige coleta completa ou allow_partial explícito. |
| `instante_invalido` | O instante original deve estar dentro de 90 dias, em milissegundos. |
| `internal_error` | A operação não foi concluída. Consulte o diagnóstico local. |
| `invalid_application_id` | O número do aplicativo (App ID no endereço) aceita somente dígitos. |
| `invalid_cursor` | Continuação inválida. |
| `invalid_input` | Escolha conexão e canal. |
| `invalid_state` | Esta operação já está encerrada. |
| `job_terminal` | Coleta encerrada. |
| `journal_inconsistent` | Referência do diário ausente; envio bloqueado. |
| `label_missing` | Rótulo não definido. |
| `lote_invalido` | Envie de 1 a 100 eventos. |
| `media_not_ready` | A mídia ainda não está disponível para publicação. |
| `migration_pending` | O diário de assinaturas está sendo indexado. Repita a operação; nenhum POST foi enviado. |
| `not_authorized` | Política do transporte recusou esta habilidade. |
| `not_configured` | Conexão não cadastrada. |
| `not_found` | Operação ausente. |
| `notification_out_of_scope` | Notificação fora do escopo. |
| `oauth_denied` | O LinkedIn não concluiu o consentimento. A autorização salva foi preservada. |
| `oauth_invalid_response` | A introspecção devolveu campos com tipos inválidos. |
| `oauth_state_invalid` | Retorno de autorização inválido. |
| `oauth_unavailable` | O LinkedIn não confirmou a solicitação de credencial. |
| `operation_uncertain` | Intenção sem confirmação; consulte o diário pelo contrato 1.1. |
| `outside_retention_window` | O período está fora da janela histórica publicada pelo LinkedIn. |
| `ownership_mismatch` | O objeto remoto não corresponde ao recibo próprio. |
| `ownership_missing` | Assinatura sem autoria local. |
| `papel_insuficiente` | A conta exige papel de gestão para Conversions API. |
| `papel_nao_comprovado` | O papel do membro na conta selecionada não foi comprovado. |
| `payload_invalido` | Evento fora do contrato site-linkedin-conversion/1.0.0. |
| `persistence_unconfirmed` | O banco não confirmou o salvamento. Releia a conexão antes de tentar novamente. |
| `preview_required` | Gere e confirme a prévia do mesmo evento e destino. |
| `preview_stale` | A prévia expirou. |
| `rate_limited` | A conexão aguarda a janela de quota. |
| `refresh_expired` | A autorização de renovação expirou. |
| `refresh_unavailable` | Este aplicativo não forneceu token de renovação. Autorize novamente. |
| `regra_divergente` | A regra não pertence à conta selecionada. |
| `regra_inativa` | A regra de conversão está desativada. |
| `regra_sem_fonte_api` | Escolha uma regra com Data source Direct API / Conversions API no Campaign Manager → Measurement → Conversion tracking. Regras Insight Tag não são convertidas automaticamente. |
| `response_limit` | Resposta excedeu o orçamento. |
| `result_unavailable` | A coleta ainda não possui páginas. |
| `revision_conflict` | A candidata, a identidade, as agendas ou as concessões mudaram. Simule novamente. |
| `schedule_limit` | Limite de 100 agendas. |
| `scope_missing` | O token não recebeu as permissões necessárias. Autorize o aplicativo novamente. |
| `selection_disabled` | Seleção automática desativada. |
| `selftest_failed` | Diagnóstico local reprovado. |
| `sem_concessao` | Conceda Conversions API explicitamente ao Site Core. |
| `sem_conexao` | Conexão não disponível. |
| `sem_escopo` | O Access Token precisa de rw_conversions e r_ads. Confira Auth → OAuth 2.0 scopes e gere nova autorização. |
| `sem_identificador` | O evento não contém identificador utilizável. |
| `service_grant_changed` | Concessão alterada antes do envio. |
| `service_grant_inactive` | Concessão de serviço indisponível. |
| `service_grant_invalid` | Concessão desconhecida. |
| `service_identity_invalid` | Identidade de serviço inválida. |
| `service_identity_mismatch` | Identidade ou revisão de serviço divergente. |
| `service_journal_invalid` | Recibo técnico inválido. |
| `service_operation_unbound` | Operação sem vínculo de serviço desta versão. |
| `service_rule_invalid` | Regra API não comprovada. |
| `service_scope_unverified` | Escopos locais não comprovados para a credencial vigente. |
| `signature_invalid` | Assinatura recusada. |
| `simulation_required` | Simule as alterações e confirme antes de mudar a antecedência dos avisos. |
| `source_row_limit` | A origem atingiu 15.000 elementos; restrinja período ou campanhas. |
| `storage_corrupt` | A identidade da página diverge da seleção original. |
| `storage_unavailable` | Não foi possível iniciar o salvamento atômico. |
| `subscription_exists_unowned` | Assinatura equivalente já existe; autoria não foi presumida. |
| `subscription_intent_blocked` | Este formulário possui uma intenção ativa ou sem confirmação. Reconcilie a operação existente antes de criar outra. |
| `targeting_ambiguous` | Escolha um resultado único da busca de segmentação. |
| `token_expired` | O prazo cadastrado do token expirou. |
| `unsupported` | Relatório não suportado. |
| `unsupported_field` | Campo fora do catálogo. |
| `upstream_changed` | Partições de campos divergiram; repita a consulta. |
| `upstream_invalid` | Identidade divergente. |
| `verification_failed` | O comentário relido diverge da solicitação. |
| `verification_incomplete` | O LinkedIn não confirmou o Client ID e a validade deste token. O token salvo continua em uso. |
| `verification_pending` | A exclusão ainda não foi confirmada na releitura. |
