# Guia para agentes — 0.21.0

Para quem opera este plugin por ferramentas: Fator3 MCP, REST do site ou Abilities API. Descreve a versão instalada. O histórico de versões está em CHANGELOG.md.

## Regras que valem para toda sessão

1. Toda operação exige um administrador do WordPress (`manage_options`). Associar um usuário a uma conexão não amplia esse direito.
2. O catálogo mostra o que existe, não o que o LinkedIn autoriza. Uma operação listada pode falhar por escopo, produto ou papel ausentes na conta.
3. Uma lista descoberta não é autorização. Só valem os ativos e formulários gravados na conexão e nas concessões.
4. Não repita uma escrita com resultado incerto. Consulte o diário e reconcilie.
5. Nunca peça, exiba ou grave em arquivo token, segredo ou código OAuth. As respostas não devolvem segredos; não tente obtê-los por outro caminho.
6. Publicar, comentar, ativar campanha, criar assinatura e enviar conversão produzem efeito real. Faça isso somente com autorização explícita do dono para aquele alvo.

## Sequência de trabalho

### 1. Descobrir

Liste as operações pelo descobridor do transporte, com prefixo `linkedin/`. São 100. ABILITIES.md traz o mesmo catálogo por assunto, com tipo, efeito no LinkedIn e parâmetros obrigatórios.

### 2. Ler

- `linkedin/documentation` com `{"document":"index"}` devolve os documentos e seus hashes. Leia README.md para escolher o manual. A paginação está descrita no README.
- `linkedin/contracts` devolve os schemas de entrada de todas as operações. Todos os objetos são fechados: propriedade desconhecida é recusada.
- `linkedin/capabilities` devolve contratos, canais (`pages`, `ads`, `leads`), relatórios e consumidores registrados.

### 3. Diagnosticar

| Chamada | O que confirma | O que não confirma |
|---|---|---|
| `linkedin/status` com `{}` | Armazenamento, criptografia, cron, fila, agendas, validade e incidentes das credenciais. `state` é `ok` ou indica atenção; `issues` lista ações. | Acesso ao LinkedIn. Não repara nada. |
| `linkedin/selftest` com `{}` | Nove verificações locais. | Credenciais, escopos ou produtos. |
| `linkedin/list-connections` com `{}` | Conexões sem segredos, 50 por página; continue por `next_offset`. | — |
| `linkedin/inspect-token` com `{"connection_id":"…"}` | Escopos efetivamente concedidos pelo LinkedIn. Consulta o fornecedor. | Papel do membro em cada conta. |
| `linkedin/validate-connection` com conexão, canal e ativo | Leitura dos metadados daquele ativo. Guarda uma prova local sem mudar a revisão da conexão. | Relatórios, respostas de formulários, conversões. |
| `linkedin/diagnose-conversions` | Requisitos locais da Conversions API, item a item. | Entrega real de eventos. |

O diagnóstico indica `connection_without_token` quando uma conexão antiga está ativa sem token. Inspecione o registro, depois configure a credencial ou pause-o.

### 4. Configurar

Leia antes de gravar e envie a revisão lida.

- **Conexão.** `get-connection` → `save-connection` com `connection_id` e `expected_revision` (0 ao criar). Envie só os campos que quer alterar; os demais são preservados. Segredo ausente ou vazio mantém o salvo. Para remover um segredo use `clear_token`, `clear_client_secret` ou `clear_refresh_token`; enviar o valor e a remoção do mesmo segredo é recusado. Com `dry_run:true` a resposta traz a prévia dos vínculos afetados e uma `confirmation`; troca de identidade e mudança de `credential_notice_days` exigem repetir a chamada com essa `confirmation`.
- **Ativos.** Descubra com `list-accounts` ou `admin-options` e grave em `save-connection` no campo `assets` (`pages`, `ads`, `leads`) e, para formulários, `forms`. Lista vazia não concede acesso.
- **Concessão de formulários.** `list-grants` → `save-grant` com consumidor, conexão, `permissions`, `forms` e `expected_revision`.
- **Concessões de conversão.** `save-conversion-grant` e `save-stage-conversion-grant`. Leia CONVERSIONS.md e STAGE-CONVERSIONS.md antes.
- **Retenção da auditoria.** `get-retention` → `save-retention`. Simula por padrão; grava com `dry_run:false`.
- **Agenda.** `save-schedule` com a consulta completa, `interval_minutes` de 60 a 43200 e `expected_revision`.

Exemplo de simulação de retenção, substituindo `N` pela revisão lida:

```json
{"expected_revision": N, "audit_mode": "finite", "audit_days": 30, "dry_run": true}
```

### 5. Consultar

- `list-fields` devolve os campos aceitos por relatório.
- `query` exige `connection_id`, `channel`, `account_id` e `report`. Guarde a seleção e siga `next_cursor` até acabar. Ausência de linha não é zero.
- Para volumes maiores use `create-job` com `idempotency_key`, avance com `run-job`, acompanhe com `job-status` e leia com `job-results`. Exporte com `export` e `export-read`.
- O histórico diário local é lido com `history-query`; veja HISTORY.md.

### 6. Alterar anúncios e publicações

Essas operações têm duas fases. Leia MANAGEMENT.md por inteiro antes da primeira.

1. Leia o objeto e sua revisão (`get-campaign`, `get-post` e semelhantes).
2. Chame a operação com `request_key` única por intenção e `dry_run:true`, que é o padrão. A resposta traz a proposta e um `confirm_token` válido por dez minutos.
3. Para aplicar, repita o mesmo conteúdo e a mesma `request_key` com `dry_run:false`, `confirm:true` e o `confirm_token`.
4. Guarde `operation_id`. Criações de Ads nascem em rascunho; ativar é outra operação, com nova leitura e nova prévia.

Se o transporte aceitar uma chave de idempotência própria, omita-a nessas operações ou use chaves diferentes na prévia e na aplicação.

### 7. Verificar

Releia o que gravou (`get-connection`, `get-grant`, `list-schedules`, `get-write-operation`) e compare a revisão. `linkedin/audit` lista os eventos do mais recente para o mais antigo; use `since` para limitar.

### 8. Retomar depois de falha

| Código | Significado | Próxima ação |
|---|---|---|
| `revision_conflict` | O registro mudou depois da sua leitura. | Releia e decida de novo. Não reaproveite a revisão antiga. |
| `operation_uncertain`, `verification_pending` | O efeito remoto não foi confirmado. | `get-write-operation` e `reconcile-write-operation`. Não crie outra chave para contornar. |
| `preview_required`, `preview_stale` | A prévia falta ou expirou. | Releia e gere nova prévia. |
| `rate_limited` | Quota do fornecedor. | Aguarde o prazo indicado. |
| `response_limit` | A resposta passaria do orçamento. | Reduza campos ou `limit`. |
| `asset_access_denied` | O ativo não está selecionado na conexão. | Grave a seleção antes; não insista com outro ID. |
| `not_configured` | A conexão não existe ou falta credencial. | Confira `list-connections`. |

A tabela completa está em TROUBLESHOOTING.md.

## Formato das respostas

Sucesso: `success`, `code`, `provider`, `version` e `data`. Falha: `success:false`, `code`, `error_code`, `message`, `conflict`, `retryable`, `details` e `data:null`. Pelo Fator3 MCP, esse envelope vem dentro de `data` do resultado da ferramenta, com `request_id`. Entrada com propriedade desconhecida é recusada pelo transporte com `ability_invalid_input`, antes de chegar ao plugin.

## Contrato para o agente MCP

Em `configuration-schema`, leia `input_method` e `blank_keeps_existing`. Um campo secreto vazio preserva o valor salvo; a remoção é uma ação explícita. Em `status`, `maintenance.last.renewal_result` resume a manutenção; `notice_days` indica a antecedência em dias nas projeções da conexão. Em `capabilities`, use `local_sdk.features.dispatch_checks_access`. Revisões numéricas e indicadores booleanos mantêm nome e tipo. Os campos existentes continuam no SDK e no REST. Nenhum indicador revela o token.

Para continuar a leitura de um manual, envie o mesmo ID, `next_offset` e o hash da primeira página como `expected_revision`. Se o hash divergir, obtenha novamente o índice e recomece. A leitura da ajuda não consulta o LinkedIn. IDs dos ativos são strings numéricas; datas de configuração usam segundos Unix, datas de programação de anúncios usam milissegundos. Avance coletas longas em etapas e preserve o cursor.

## O que este plugin não faz

Não cadastra contatos, não deduplica leads e não decide consentimento: isso é do Fator3 Site Core. Não homologa aplicativo nem concede produto do LinkedIn. `admin-options` serve ao painel e não substitui o SDK usado pelo consumidor.

Em uma investigação de origem, use a operação descrita em AD-SOURCE.md. Identifique conta e criativo ou a resposta de um formulário patrocinado. Consulte o fornecedor apenas após validar a autorização da integração.
