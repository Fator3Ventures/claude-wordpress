<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

/** A directed read: only identifiers returned by the scoped parent may be followed. */
final class AdSource {
    public const CONTRACT='linkedin-ad-source/1.0.0';
    public static function creativeId($urn): ?string {
        return is_string($urn)&&preg_match('~^urn:li:sponsoredCreative:([0-9]{1,40})$~D',$urn,$m)?$m[1]:null;
    }
    private static function url($value,bool $cdn=false): ?string {
        if(!is_string($value)||strlen($value)>8192||preg_match('~[\x00-\x20\x7f\\\\]~',$value))return null;
        $p=parse_url($value);
        if(!is_array($p)||!isset($p['host'],$p['scheme'])||isset($p['user'])||isset($p['pass'])||!in_array(strtolower($p['scheme']),$cdn?['https']:['https','http'],true))return null;
        if($cdn&&(isset($p['port'])&&$p['port']!==443||!preg_match('~(?:^|\.)(?:licdn\.com|licdn-ei\.com|linkedin\.com)$~iD',$p['host'])))return null;
        return $value;
    }
    private static function text($s): ?string {return is_string($s)&&trim($s)!==''?mb_substr($s,0,16000):null;}
    private static function epochMs($n): ?int {return (is_string($n)||is_int($n))&&preg_match('~^[0-9]{13}$~D',(string)$n)?(int)$n:null;}
    private static function urlExpiry(?string $url): ?int {
        if($url===null)return null;
        parse_str((string)parse_url($url,PHP_URL_QUERY),$q);
        return isset($q['e'])&&is_string($q['e'])&&preg_match('~^[0-9]{10}$~D',$q['e'])?((int)$q['e'])*1000:null;
    }
    private static function link($url,$timestamp): array {
        $url=self::url($url,true);$expires=self::epochMs($timestamp);$signed=self::urlExpiry($url);
        if($signed!==null)$expires=$expires===null?$signed:min($signed,$expires);
        return ['url'=>$expires!==null&&$expires<=((int)floor(microtime(true)*1000))?null:$url,'expires_at_ms'=>$expires];
    }
    private static function read(array $c,string $path,callable $guard): array {
        $guard();$body=Http::request($c,$path,[],'GET',null,$guard)['body'];$guard();return $body;
    }
    public static function resolve(array $c,string $account,string $creative,callable $guard,?string $fromCampaign=null): array {
        $accountUrn='urn:li:sponsoredAccount:'.$account;$adUrn='urn:li:sponsoredCreative:'.$creative;
        $prefix='adAccounts/'.$account.'/';$guard();
        $ad=self::read($c,$prefix.'creatives/'.rawurlencode($adUrn),$guard);
        if(($ad['id']??null)!==$adUrn||($ad['account']??null)!==$accountUrn)throw new Fault('ad_source_binding_invalid','O anúncio não corresponde à identidade solicitada.');
        $campaign=LeadCampaign::campaignId($ad['campaign']??null);
        if(!$campaign||($fromCampaign!==null&&$fromCampaign!==$campaign))throw new Fault('ad_source_binding_invalid','A campanha do anúncio não corresponde à origem.');
        $cp=self::read($c,$prefix.'adCampaigns/'.$campaign,$guard);
        if((string)($cp['id']??'')!==$campaign||($cp['account']??null)!==$accountUrn)throw new Fault('ad_source_binding_invalid','Campanha fora da conta solicitada.');
        $empty=['url'=>null,'expires_at_ms'=>null];
        $out=['contract'=>self::CONTRACT,'account_id'=>$account,'creative_id'=>$creative,'creative_name'=>self::text($ad['name']??null),'campaign_id'=>$campaign,'campaign_name'=>self::text($cp['name']??null),
            'text'=>null,'title'=>null,'description'=>null,'button'=>self::text($ad['leadgenCallToAction']['label']??null),'destination_url'=>null,
            'lead_form_urn'=>null,'post_urn'=>null,'content_type'=>'unknown','media_type'=>null,'media_urn'=>null,'media'=>$empty,'thumbnail'=>$empty,'media_status'=>'not_provided',
            'campaign_manager_url'=>'https://www.linkedin.com/campaignmanager/accounts/'.$account.'/campaigns/'.$campaign.'/creatives','post_url'=>null,'media_links_temporary'=>true];
        $form=$ad['leadgenCallToAction']['destination']??null;
        if(is_string($form)&&preg_match('~^urn:li:(?:adForm|leadGenForm):[0-9]{1,40}$~D',$form))$out['lead_form_urn']=$form;
        $ref=$ad['content']['reference']??null;
        if($ref===null)return $out;
        if(!is_string($ref)||!preg_match('~^urn:li:(?:share|ugcPost):[0-9]{1,40}$~D',$ref))return array_replace($out,['media_status'=>'unsupported_reference']);
        $post=self::read($c,'posts/'.rawurlencode($ref),$guard);$author=$post['author']??null;
        if(($post['id']??null)!==$ref||!is_string($author)||!preg_match('~^urn:li:(?:organization:[0-9]{1,40}|person:[A-Za-z0-9_-]{1,100})$~D',$author)||
            (isset($post['adContext']['dscAdAccount'])&&$post['adContext']['dscAdAccount']!==$accountUrn))throw new Fault('ad_source_binding_invalid','Publicação fora da cadeia de origem do anúncio.');
        $out['post_urn']=$ref;$out['post_url']='https://www.linkedin.com/feed/update/'.$ref.'/';
        $out['text']=self::text($post['commentary']??null);$content=$post['content']??[];$article=$content['article']??[];$medium=$content['media']??[];$multi=$content['multiImage']['images']??[];
        $out['content_type']=$article?'article':($medium?'media':($multi?'multi_image':($content?'other':'text')));
        $out['title']=self::text($article['title']??$medium['title']??null);$out['description']=self::text($article['description']??$medium['description']??null);
        $out['button']=$out['button']??self::text($post['contentCallToActionLabel']??null);
        $out['destination_url']=self::url($post['contentLandingPage']??null)??self::url($article['source']??null);
        $urn=$article['thumbnail']??$medium['id']??$multi[0]['id']??null;
        if($urn===null)return $out;
        if(!is_string($urn)||!preg_match('~^urn:li:(image|video):[A-Za-z0-9_-]{1,150}$~D',$urn,$m))return array_replace($out,['media_status'=>'unsupported_media']);
        $out['media_type']=$m[1];$out['media_urn']=$urn;
        $asset=self::read($c,($m[1]==='image'?'images/':'videos/').rawurlencode($urn),$guard);
        if(($asset['id']??null)!==$urn||!in_array($asset['owner']??null,[$author,$accountUrn,'urn:li:sponsoredContentAccount:'.$account],true))
            throw new Fault('ad_source_binding_invalid','Mídia fora da cadeia de origem do anúncio.');
        if(($asset['status']??'')!=='AVAILABLE')return array_replace($out,['media_status'=>'not_available']);
        $out['media']=self::link($asset['downloadUrl']??null,$asset['downloadUrlExpiresAt']??null);
        $out['thumbnail']=$m[1]==='image'?$out['media']:self::link($asset['thumbnail']??null,$asset['thumbnailExpiresAt']??null);
        $out['media_status']=$out['media']['url']?'available':'url_unavailable';
        return $out;
    }
}
