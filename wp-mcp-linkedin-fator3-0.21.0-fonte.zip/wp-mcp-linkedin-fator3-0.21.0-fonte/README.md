# Fonte — Fator3 MCP LinkedIn 0.21.0

Modelos editáveis em build/common, build/linkedin, build/assets e build/docs/linkedin. O runtime integral fica em plugin/wp-mcp-linkedin-fator3. Documentos e schemas são compilados no build; não edite o runtime à mão.

```sh
F3_SOCIAL_PHP=/caminho/php8.3 python3 build/build.py
python3 tools/verify-installer021.py build/dist/wp-mcp-linkedin-fator3-0.21.0-instalador.zip plugin/wp-mcp-linkedin-fator3
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li21-source --order linkedin-integrated --tests ad-source021.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li21-core --order linkedin-integrated --tests core-frontier021.php
python3 tools/lab.py --manifest /dependencias/lab.json --workdir /tmp/li21-migration --origin upgrade --order linkedin-integrated --tests migration021.php
```

Use um diretório e banco descartáveis por suíte. O manifesto de exemplo da rodada identifica os instaladores e o WordPress exercitados. Para o PHP forneça o executável local e seu hash; não insira credenciais no manifesto. A senha de banco vem da variável indicada. core-frontier021.php aplica o patch experimental só no Core descartável, confere o hash original e restaura o arquivo ao encerrar. Não execute os testes em produção. O navegador webui020.php exige Chrome Headless com sandbox e Playwright.

O teste ad-source021 cobre a projeção em dois modos, imagem, vídeo, restrições de titularidade, revogação e acesso pelo adaptador oficial do Site Core e pelo executor do MCP. O fornecedor dos cenários automatizados é simulado. As provas do site e os limites estão no relatório canônico e em evidence/release0210. As pastas de versões anteriores são históricas. O pacote público do Core não foi modificado.
