<?php
/** Local CLI entry point. The signed, site-bound receipt supplies all operation parameters. */
declare(strict_types=1);
if (PHP_SAPI!=='cli' || $argc!==5 || !ctype_digit($argv[2]) || !preg_match('/^sqljob:[a-f0-9]{32}$/D',$argv[3])) exit(1);
$site=parse_url($argv[4]);
$_SERVER['HTTP_HOST']=$site['host'].(isset($site['port'])?':'.$site['port']:'');
$_SERVER['REQUEST_URI']=$site['path']??'/';
if (($site['scheme']??'')==='https') $_SERVER['HTTPS']='on';
require rtrim($argv[1],'/').'/wp-load.php';
if ((int)$argv[2]!==get_current_blog_id() || !class_exists('Fator3\McpFiles\SqlWork')) exit(1);
\Fator3\McpFiles\SqlWork::worker($argv[3]);
