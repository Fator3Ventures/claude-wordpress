<?php
/** Native WordPress package management with captured filesystem prompts. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Packages {
	public static function register(): void {
		Registry::add('themes/list', 'List installed themes, active template/stylesheet, parent and compatibility.', [], [], [self::class, 'listing'], 'edit_theme_options');
		Registry::add('themes/validate', 'Validate an installed theme and parent requirements before activation. Does not execute theme code or render the site.', ['stylesheet' => Registry::string()], ['stylesheet'], [self::class, 'validate'], 'edit_theme_options');
		Registry::add('themes/install', 'Install a theme by its WordPress.org catalog slug. Does not activate it.', ['slug' => Registry::string()], ['slug'], static fn($a) => self::install($a, 'theme'), 'install_themes', false);
		Registry::add('themes/activate', 'Activate a validated installed theme with switch_theme and verify the effective stylesheet/template.', ['stylesheet' => Registry::string()], ['stylesheet'], [self::class, 'activate'], 'switch_themes', false);
		Registry::add('plugins/install', 'Install a plugin by its WordPress.org catalog slug. Does not activate it.', ['slug' => Registry::string()], ['slug'], static fn($a) => self::install($a, 'plugin'), 'install_plugins', false);
		Registry::add('plugins/update', 'Atualiza pela oferta WordPress, preserva ativação em nova requisição PHP, pré-imagem e sonda anônima. Retorna versões/ativação antes e depois; autoatualização MCP requer recuperação independente homologada.', ['plugin' => Registry::string('folder/main.php')], ['plugin'], [self::class, 'update'], 'update_plugins', false);
	}
	private static function info(\WP_Theme $theme): array {
		$error = $theme->errors();
		return ['stylesheet' => $theme->get_stylesheet(), 'template' => $theme->get_template(), 'name' => $theme->get('Name'), 'version' => $theme->get('Version'), 'parent' => $theme->get('Template'), 'active' => get_stylesheet() === $theme->get_stylesheet(), 'block_theme' => $theme->is_block_theme(), 'requires_wordpress' => $theme->get('RequiresWP'), 'requires_php' => $theme->get('RequiresPHP'), 'errors' => is_wp_error($error) ? $error->get_error_messages() : []];
	}
	public static function listing(array $input = []): array { return Result::ok(['themes' => array_values(array_map([self::class, 'info'], wp_get_themes(['errors' => null]))), 'stylesheet' => get_stylesheet(), 'template' => get_template()]); }
	public static function validate(array $input): array {
		$theme = wp_get_theme($input['stylesheet']);
		if (!$theme->exists()) return Result::fail('theme_not_found', 'O tema instalado não foi encontrado.');
		$info = self::info($theme); $errors = $info['errors'];
		if ($theme->get('RequiresWP') && !is_wp_version_compatible($theme->get('RequiresWP'))) $errors[] = 'WordPress version requirement not met.';
		if ($theme->get('RequiresPHP') && !is_php_version_compatible($theme->get('RequiresPHP'))) $errors[] = 'PHP version requirement not met.';
		if (is_multisite() && !$theme->is_allowed()) $errors[] = 'Theme is not enabled for this site/network.';
		return $errors ? Result::fail('theme_invalid', implode(' ', $errors), ['theme' => $info, 'valid' => false]) : Result::ok(['theme' => $info, 'valid' => true]);
	}
	public static function activate(array $input): array {
		$valid = self::validate($input); if (!$valid['success']) return $valid;
		$before = get_stylesheet(); if ($before === $input['stylesheet']) return Result::ok(['changed' => false, 'stylesheet' => $before, 'template' => get_template()]);
		switch_theme($input['stylesheet']);
		if (get_stylesheet() !== $input['stylesheet']) return Result::fail('theme_activation_failed', 'O WordPress não ativou a folha de estilos solicitada.');
		return Result::ok(['changed' => true, 'stylesheet' => get_stylesheet(), 'template' => get_template(), 'previous_stylesheet' => $before]);
	}
	private static function filesystem() {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS) return new \WP_Error('file_modifications_disabled', 'As alterações de pacotes do WordPress estão desativadas.');
		ob_start(); try { $credentials = request_filesystem_credentials(''); } finally { ob_end_clean(); }
		if (false === $credentials || !WP_Filesystem($credentials)) return new \WP_Error('filesystem_credentials_required', 'Configure o acesso do WordPress ao sistema de arquivos antes de usar as habilidades de pacotes.');
		return $credentials;
	}
	private static function upgrade(callable $run): array {
		$credentials = self::filesystem(); if (is_wp_error($credentials)) return Result::error($credentials);
		$filter = static fn($value, $url, $type, $error) => $error ? false : $credentials;
		add_filter('request_filesystem_credentials', $filter, PHP_INT_MAX, 4);
		ob_start();
		try { return $run(); }
		finally { ob_end_clean(); remove_filter('request_filesystem_credentials', $filter, PHP_INT_MAX); }
	}
	public static function install(array $input, string $kind): array {
		$slug = $input['slug'];
		if (!preg_match('/^[a-z0-9][a-z0-9-]{0,99}$/D', $slug)) return Result::fail('invalid_slug', 'Informe o slug no catálogo do WordPress.org.');
		if ('theme' === $kind && wp_get_theme($slug)->exists()) return Result::fail('package_exists', 'O tema já está instalado.');
		return self::upgrade(static function () use ($slug, $kind) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php'; require_once ABSPATH . 'wp-admin/includes/theme-install.php'; require_once ABSPATH . 'wp-admin/includes/theme.php';
			$api = 'theme' === $kind ? themes_api('theme_information', ['slug' => $slug, 'fields' => ['sections' => false]]) : plugins_api('plugin_information', ['slug' => $slug, 'fields' => ['sections' => false]]);
			if (is_wp_error($api)) return Result::error($api);
			$url = $api->download_link ?? ''; $parts = wp_parse_url($url);
			if (!$parts || ($parts['scheme'] ?? '') !== 'https' || ($parts['host'] ?? '') !== 'downloads.wordpress.org') return Result::fail('catalog_download_invalid', 'O catálogo não retornou uma URL HTTPS oficial para o pacote.');
			if (!is_wp_version_compatible($api->requires ?? '') || !is_php_version_compatible($api->requires_php ?? '')) return Result::fail('package_requirements', 'O ambiente não atende ao requisito de versão do PHP ou do WordPress do pacote.');
			$skin = new \Automatic_Upgrader_Skin(); $upgrader = 'theme' === $kind ? new \Theme_Upgrader($skin) : new \Plugin_Upgrader($skin);
			$result = $upgrader->install($url);
			if (is_wp_error($result)) return Result::error($result);
			if (!$result || is_wp_error($upgrader->result)) return Result::fail('package_install_failed', 'O WordPress não confirmou a instalação do pacote.');
			if ('theme' === $kind) { wp_clean_themes_cache(); $theme = wp_get_theme($slug); if (!$theme->exists()) return Result::fail('package_verify_failed', 'O tema instalado não foi encontrado após a atualização.'); return Result::ok(['slug' => $slug, 'theme' => self::info($theme), 'activated' => false]); }
			wp_clean_plugins_cache(false); $plugin = $upgrader->plugin_info(); $all = get_plugins();
			if (!$plugin || !isset($all[$plugin])) return Result::fail('package_verify_failed', 'O plugin instalado não foi encontrado após a atualização.');
			return Result::ok(['plugin' => $plugin, 'version' => $all[$plugin]['Version'], 'activated' => false]);
		});
	}
	public static function update(array $input): array { return PackageService::update($input); }
}
