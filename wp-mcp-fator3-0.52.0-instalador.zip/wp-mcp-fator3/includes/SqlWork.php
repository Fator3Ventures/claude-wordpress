<?php
/** A single authorized SQL call owns one worker and its original database session. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class SqlWork {
    public const ABILITIES=['db/execute','db/export','db/restore','db/batch','db/search-replace'];
    private static ?string $active=null;
    private static string $name='';
    private static float $last=0;
    private static float $deadline=0;
    private static ?string $phase=null;
    private static string $stage='preparacao';

    public static function init(): void {
        add_action('f3_mcp_sql_work', [self::class,'cron']);
        add_action('f3_mcp_sql_dispose', [self::class,'dispose']);
    }
    public static function current(string $name): bool { return self::$active!==null && self::$name===$name; }

    // Bind the job to the site and filename. SQL, confirmation tokens and result rows are private.
    private static function path(string $id): string {
        if (!preg_match('/^sqljob:[a-f0-9]{32}$/D',$id)) throw new \InvalidArgumentException('invalid_sql_job');
        return StateStore::path('sql-work',$id);
    }
    private static function key(): string {
        return hash('sha256',wp_salt('auth').'|f3-sql-work-v1',true);
    }
    private static function write(string $id,array $state): void {
        $nonce=random_bytes(12);
        $data=openssl_encrypt(wp_json_encode($state,JSON_THROW_ON_ERROR),'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,$nonce,$tag,get_current_blog_id().'|'.$id);
        if ($data===false) throw new \RuntimeException('sql_job_write_failed');
        StateStore::write(self::path($id),StateStore::HEADER.base64_encode($nonce.$tag.$data));
    }
    private static function read(string $id): ?array {
        $path=self::path($id);
        clearstatcache(true,$path);
        if (!is_file($path) || is_link($path)) return null;
        $data=file_get_contents($path);
        if ($data===false || !str_starts_with($data,StateStore::HEADER)) throw new \RuntimeException('sql_job_invalid');
        $bytes=base64_decode(substr($data,strlen(StateStore::HEADER)),true);
        if ($bytes===false || strlen($bytes)<28) throw new \RuntimeException('sql_job_invalid');
        $plain=openssl_decrypt(substr($bytes,28),'aes-256-gcm',self::key(),OPENSSL_RAW_DATA,substr($bytes,0,12),substr($bytes,12,16),get_current_blog_id().'|'.$id);
        if ($plain===false) throw new \RuntimeException('sql_job_invalid');
        return json_decode($plain,true,512,JSON_THROW_ON_ERROR);
    }
    private static function log(string $id,array $s,string $stage,array $result=[]): void {
        Audit::record($s['ability'],[],['operation_id'=>$id,'job_stage'=>$stage]+$result,(int)((microtime(true)-$s['start'])*1000));
    }
    // Only the server's CLI and this bundled script are executable. No SQL/secret travels in argv.
    private static function launch(string $id): bool {
        $binary=PHP_SAPI==='cli'||PHP_SAPI==='cli-server' ? PHP_BINARY : PHP_BINDIR.'/php';
        if (!function_exists('proc_open') || !is_executable($binary) || !is_executable('/bin/sh')) return false;
        $args=['/bin/sh','-c','"$@" </dev/null >/dev/null 2>&1 &','f3-sql',$binary,__DIR__.'/sql-worker.php',
            realpath(ABSPATH), (string)get_current_blog_id(), $id, home_url('/')];
        $proc=proc_open($args,[0=>['file','/dev/null','r'],1=>['file','/dev/null','w'],2=>['file','/dev/null','w']],$pipes);
        return is_resource($proc) && proc_close($proc)===0;
    }
    public static function submit(string $name,array $input): array {
        $owner=ConnectionContext::key();
        $request=$input;
        if (isset($request['confirm_token'])) unset($request['idempotency_key']);
        ksort($request);
        $intent=hash('sha256',serialize($request));
        $dedup=$input['confirm_token']??$input['idempotency_key']??bin2hex(random_bytes(16));
        $id='sqljob:'.substr(hash_hmac('sha256',serialize([get_current_user_id(),$owner,$name,$dedup]),self::key()),0,32);
        $replayed=false;
        $s=Locks::run(['sql-submit:'.$id=>LOCK_EX],static function()use($id,$owner,$name,$input,$intent,&$replayed){
            $s=self::read($id);
            if ($s) {
                if (!hash_equals($s['intent'],$intent)) return Result::fail('confirmation_invalid','A identidade da solicitação mudou.');
                $replayed=true;return $s;
            }
            $s=['user'=>get_current_user_id(),'connection'=>$owner,'ability'=>$name,'input'=>$input,'intent'=>$intent,
                'version'=>F3_MCP_FILES_VERSION,'status'=>'pending','start'=>microtime(true)];
            self::write($id,$s);
            self::log($id,$s,'accepted');
            if (Audit::status()['current_request_write_failed']) {
                $s['status']='failed';$s['result']=Result::fail('audit_unavailable','A auditoria não confirmou o início. Nenhum efeito aplicado.',['applied'=>false]);
                unset($s['input']);self::write($id,$s);
                return $s;
            }
            wp_schedule_single_event(time()+30,'f3_mcp_sql_work',[$id]);
            wp_schedule_single_event(time()+DAY_IN_SECONDS,'f3_mcp_sql_dispose',[$id]);
            self::launch($id);
            return $s;
        });
        if (isset($s['error_code'])) return $s;
        $limit=(int)ini_get('max_execution_time');
        $deadline=microtime(true)+max(0,min(3,(float)apply_filters('f3_mcp_sql_http_wait',3)));
        if ($limit>0) $deadline=min($deadline,($_SERVER['REQUEST_TIME_FLOAT']??microtime(true))+$limit-3);
        while (!isset($s['result']) && microtime(true)<$deadline) {
            usleep(80000);$s=self::read($id);
        }
        return isset($s['result']) ? $s['result']+['sql_job_id'=>$id,'replayed'=>$replayed] : self::pending($id,$s['status']);
    }
    private static function pending(string $id,string $state): array {
        return Result::ok(['operation_id'=>$id,'status'=>$state,'retryable'=>true,'retry_after_ms'=>1000],
            'Operação em andamento. Consulte operations/status com o operation_id.');
    }
    public static function cron(string $id): void {
        if (PHP_SAPI==='cli') self::worker($id);
        elseif ((self::read($id)['status']??'')==='pending') self::launch($id);
    }
    public static function dispose(string $id): void {
        Locks::run(['sql-run:'.$id=>LOCK_EX],static function()use($id){
            $s=self::read($id);
            if ($s && time()-$s['start']>=DAY_IN_SECONDS) {
                if (!isset($s['result'])) self::log($id,$s,'expired',['success'=>false,'error_code'=>'operation_expired']);
                unlink(self::path($id));
            }
        });
    }
    public static function tick(string $stage,?string $phase=null): void {
        if (self::$active===null) return;
        if ($phase!==null) self::$phase=$phase;
        $now=microtime(true);
        if ($now>self::$deadline) throw new \RuntimeException('sql_worker_budget');
        if ($stage===self::$stage && $now-self::$last<2) return;
        self::$last=$now;self::$stage=$stage;
        $s=self::read(self::$active);
        if (!$s) throw new \RuntimeException('sql_job_missing');
        $s['stage']=$stage;
        $s['phase']=self::$phase;
        $s['heartbeat']=time();
        self::write(self::$active,$s);
        do_action('f3_mcp_sql_work_progress',self::$active,$stage);
    }
    public static function before_effect(): void {
        if (self::$active===null) return;
        $s=self::read(self::$active);
        $ability=wp_get_ability(self::$name);
        if (!$s || !$ability || $ability->check_permissions($s['input'])!==true || $s['connection']!==ConnectionContext::key())
            throw new \RuntimeException('job_permission_revoked');
        self::tick('aplicar',self::$phase);
    }
    public static function worker(string $id): void {
        if (PHP_SAPI!=='cli' || !preg_match('/^sqljob:[a-f0-9]{32}$/D',$id)) return;
        Locks::run(['sql-run:'.$id=>LOCK_EX],static function()use($id){
            $s=self::read($id);
            if (!$s || $s['status']!=='pending') return;
            $old=get_current_user_id();
            $identity=ConnectionContext::resume($s['connection'],$s['user']);
            try {
                $ability=wp_get_ability($s['ability']);
                if (!in_array($s['ability'],self::ABILITIES,true) || !$ability || $ability->check_permissions($s['input'])!==true ||
                    ConnectionContext::key()!==$s['connection']) {
                    $result=Result::fail('permission_denied','A conexão já não possui acesso à operação.',['applied'=>false]);
                } elseif ($s['version']!==F3_MCP_FILES_VERSION || time()-$s['start']>600) {
                    $result=Result::fail('operation_expired','A versão ou o prazo da solicitação mudou. Faça nova prévia.',['applied'=>false]);
                } else {
                    self::$active=$id;self::$name=$s['ability'];self::$last=0;self::$phase=null;
                    $limit=(int)ini_get('max_execution_time');
                    self::$deadline=microtime(true)+($limit>0?max(0,$limit-5):3600);
                    $s['status']='running';$s['heartbeat']=time();self::write($id,$s);
                    $result=Result::normalize($ability->execute($s['input']));
                }
            } catch (\Throwable $e) {
                $result=Result::fail('operation_uncertain','Consulte o recibo da fase antes de repetir.',['applied'=>null]);
            } finally {
                self::$active=null;
                $s['phase']=self::$phase;
                $s['result']=$result??Result::fail('operation_uncertain','Resultado inconclusivo.');
                $s['status']=empty($s['result']['success'])?'failed':'complete';
                unset($s['input']);
                self::log($id,$s,$s['status'],$s['result']);self::write($id,$s);
                ConnectionContext::restore_identity($identity,$old);
            }
        });
    }
    public static function status(string $id): array {
        if (!preg_match('/^sqljob:[a-f0-9]{32}$/D',$id)) return Result::fail('operation_not_found','Operação não encontrada.');
        $s=self::read($id);
        if (!$s || $s['user']!==get_current_user_id() || $s['connection']!==ConnectionContext::key()) return Result::fail('operation_not_found','Operação não encontrada.');
        $ability=wp_get_ability($s['ability']);
        if (!$ability || $ability->check_permissions($s['input']??[])!==true) return Result::fail('permission_denied','Acesso à operação revogado.');
        if ($s['status']==='running' && time()-$s['heartbeat']>10) {
            // A live worker holds this lease across the entire transaction. Only record loss after acquiring it.
            $reconcile=Locks::run(['sql-run:'.$id=>LOCK_EX],static function()use($id){
                $current=self::read($id);
                if ($current['status']==='running') {
                    $current['status']='interrupted';unset($current['input']);
                    $current['result']=Result::fail('operation_uncertain','Executor interrompido. Confira o recibo da fase e a auditoria.',['applied'=>null,'retryable'=>false]);
                    self::log($id,$current,'interrupted',$current['result']);self::write($id,$current);
                }
                return $current;
            });
            if (isset($reconcile['status'])) $s=$reconcile;
        }
        if ($s['status']==='pending' && time()-$s['start']>600) {
            $expired=Locks::run(['sql-run:'.$id=>LOCK_EX],static function()use($id){
                $current=self::read($id);
                if ($current && $current['status']==='pending') {
                    $current['status']='expired';
                    $current['result']=Result::fail('sql_worker_unavailable','O executor CLI não assumiu a operação no prazo. Confira o cron CLI antes de uma nova prévia.',['applied'=>false]);
                    unset($current['input']);
                    self::log($id,$current,'expired',$current['result']);
                    self::write($id,$current);
                }
                return $current;
            });
            if (isset($expired['status'])) $s=$expired;
        }
        $result=isset($s['result'])?Result::ok(['operation_id'=>$id,'status'=>$s['status'],'result'=>$s['result']]):self::pending($id,$s['status']);
        if (!empty($s['phase'])) $result['phase_operation_id']=$s['phase'];
        if (!empty($s['stage'])) $result['stage']=$s['stage'];
        return $result;
    }
}
