<?php
/** Bounded projections of the same diagnostic snapshot; no repair or external I/O. */
declare(strict_types=1);
namespace Fator3\McpFiles;
final class Diagnostics {
    public static function schema(array $fields): array {return ['compact'=>Registry::boolean(),'fields'=>['type'=>'array','items'=>['type'=>'string','enum'=>$fields],'minItems'=>1,'uniqueItems'=>true]];}
    public static function incidents(array $rows,string $type,bool $complete): array {
        $out=[];$since=time()-DAY_IN_SECONDS;
        foreach($rows as $row){if(($row['time']??0)<$since||($row['time']??0)>time())continue;$key=(string)($row[$type]??'unknown');
            if(!isset($out[$key]))$out[$key]=['count'=>0,'latest'=>null];$out[$key]['count']++;
            if(($out[$key]['latest']['time']??0)<=$row['time'])$out[$key]['latest']=array_intersect_key($row,array_flip(['time','status','error_code','diagnostic_id']));
        }
        ksort($out);return ['window_seconds'=>DAY_IN_SECONDS,'counts_complete'=>$complete,'scope'=>'retained_history','by_type'=>$out];
    }
    public static function project(array $full,array $input,array $compact): array {
        if(empty($full['success']))return $full;
        $data=!empty($input['compact'])?$compact:$full;
        if(isset($input['fields']))$data=array_intersect_key($data,array_flip($input['fields']));
        unset($data['success'],$data['message']);$result=Result::ok($data);
        // Reserve room for the request_id/result_contract added by the dispatch boundary.
        if(!empty($input['compact'])&&strlen(wp_json_encode($result))>1850)return Result::fail('diagnostic_compact_limit','Selecione menos blocos em fields para a leitura curta.');
        return $result;
    }
    public static function health(array $full,array $input): array {
        $s=$full['cron']['scheduling'];$schedule=array_intersect_key($s,array_flip(['contract','current_state','desired_state']));$schedule['readback']=['consistent'=>$s['readback']['consistent']];
        $compact=['healthy'=>$full['healthy'],'plugin_version'=>$full['environment']['plugin_version'],'mutation_audit'=>$full['environment']['mutation_audit'],'cron'=>['scheduling'=>$schedule], 'recovery'=>array_intersect_key($full['recovery'],array_flip(['status','unresolved','runtime_refresh','reason'])), 'incidents_24h'=>$s['incidents_24h']??self::incidents($s['incidents'],'operation',(bool)$s['history_complete'])];
        if (current_user_can('manage_options') && (!isset($input['fields']) || in_array('incidents_24h', $input['fields'], true))) {
            $packages = self::package_incidents();
            if ($packages !== null) {
                $compact['incidents_24h']['pacotes_fator3'] = $packages;
                $full['incidents_24h'] = $compact['incidents_24h'];
            }
        }
        if (!in_array('cron', $input['fields'] ?? [], true)) unset($full['cron']['scheduling']['incidents']);
        return self::project($full,$input,$compact);
    }

    /** Optional Site Core aggregate. Keep the payload bounded regardless of the episode count. */
    private static function package_incidents(): ?array {
        $summary = apply_filters('f3base_cron_incidentes_24h_v1', null);
        if (!is_array($summary) || !is_int($summary['episodios'] ?? null) || $summary['episodios'] < 0
            || !array_key_exists('ultimo_em', $summary)
            || ($summary['ultimo_em'] !== null && (!is_int($summary['ultimo_em']) || $summary['ultimo_em'] < 0))
            || !is_string($summary['detalhe'] ?? null) || strlen($summary['detalhe']) > 191
            || !preg_match('~^[a-z0-9-]+/[a-z0-9-]+$~D', $summary['detalhe'])) {
            return null;
        }
        return array_intersect_key($summary, array_flip(['episodios', 'ultimo_em', 'detalhe']));
    }
    public static function oauth(array $input=[]): array {
        $full=\WpMcpUltimate\OAuth\ClientDiagnostics::listing();if(empty($full['success']))return $full;
        $compact=['total'=>$full['total'],'limit'=>$full['limit'],'retention'=>$full['retention'],'incidents_24h'=>self::incidents($full['entries'],'category',$full['total']<$full['limit'])];
        return self::project($full,$input,$compact);
    }
}
