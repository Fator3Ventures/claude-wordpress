<?php
namespace Fator3\McpFiles;
defined('ABSPATH') || exit;
$automatic=AutomaticMaintenance::policy();$last=StateStore::get('automation','last');
$previewKey=is_string($_GET['automatic_preview']??null)?sanitize_text_field(wp_unslash($_GET['automatic_preview'])):'';
$preview=preg_match('/^[a-f0-9-]{36}$/D',$previewKey)?get_transient('f3_mcp_notice_'.get_current_user_id().'_'.$previewKey):false;
?>
<section class="f3-card" id="f3-automatic"><h3>Manutenção automática</h3>
<p>O WordPress verifica o acervo a cada 15 minutos, conforme a passagem do cron. Cópias sem dependências e resultados de operações concluídas são elegíveis após o prazo escolhido. Operações pendentes e comprovantes que impedem repetição ficam protegidos.</p>
<?php if (!empty($automatic['invalid'])): ?><p role="alert">A política armazenada é inválida. A exclusão está pausada até salvar valores válidos.</p><?php endif; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="f3-settings-form">
<?php Admin::nonce('f3_mcp_automatic_maintenance'); ?>
<input type="hidden" name="action" value="f3_mcp_automatic_maintenance"><input type="hidden" name="revision" value="<?php echo esc_attr(AutomaticMaintenance::revision()); ?>">
<p><input type="hidden" name="enabled" value="0"><label><input type="checkbox" name="enabled" value="1" <?php checked($automatic['enabled']); ?>> Ativar limpeza automática</label></p>
<div class="f3-field-grid"><?php foreach ([
'backups_days'=>['Cópias e exportações (dias)',1,3650,'Inclui backups de arquivos, pré-imagens e cópias SQL. O padrão é 1 dia (24 horas).'],
'idempotency_days'=>['Resultados de operações (dias)',1,3650,'Expira o resultado volumoso. Um comprovante mínimo impede executar novamente a mesma chave.'],
'oauth_receipts_days'=>['Comprovantes OAuth vencidos (dias)',1,3650,'Tokens válidos e controles de reutilização de concessões ativas são preservados.'],
'audit_days'=>['Histórico de auditoria (dias)',0,3650,'Zero preserva o histórico. Um valor positivo permite retirar os registros mais antigos.'],
'refresh_notice_days'=>['Avisar antes do vencimento (dias)',1,3650,'O Core recebe um aviso quando a concessão OAuth entra neste prazo sem renovação.'],
'stall_passes'=>['Passagens sem avanço',1,96,'Avise quando a mesma seleção continuar parada por este número de passagens. Padrão: 3.'],
'cron_late_seconds'=>['Tolerância de atraso do cron (segundos)',1,86400,'O Core recebe um aviso quando a próxima passagem da manutenção excede esta tolerância.'],
] as $key=>$field): ?><div><label for="f3-auto-<?php echo esc_attr($key); ?>"><?php echo esc_html($field[0]); ?></label>
<input type="number" required step="1" id="f3-auto-<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>" min="<?php echo (int)$field[1]; ?>" max="<?php echo (int)$field[2]; ?>" value="<?php echo (int)$automatic[$key]; ?>" aria-describedby="f3-auto-help-<?php echo esc_attr($key); ?>">
<?php Admin::help('f3-auto-help-'.$key,$field[3]); ?></div><?php endforeach; ?></div>
<div class="f3-actions"><button class="button" name="intent" value="preview">Simular estes critérios</button><button class="button button-primary" name="intent" value="save">Salvar política</button></div>
<p class="description">A simulação preserva o acervo. Salvar ativa os critérios para as próximas passagens. Pausar a limpeza mantém os avisos técnicos.</p></form>
<?php if (is_array($preview) && isset($preview['automatic_preview'])): $r=$preview['automatic_preview']; ?>
<h4>Resultado da simulação</h4>
<?php if (empty($r['success'])): ?><p role="alert"><?php echo esc_html($r['message']??'Não foi possível concluir a simulação.'); ?></p><?php else: ?>
<ul><?php foreach ($r['categories'] as $key=>$row): $labels=['oauth'=>'OAuth','oauth-tokens'=>'OAuth','idempotency'=>'Resultados de operações','backups'=>'Backups','sql_artifacts'=>'Cópias SQL','audit'=>'Auditoria']; ?><li><?php echo esc_html($labels[$key]??$key); ?>: <?php echo empty($row['success'])?'seleção indisponível':(int)($row['selected']??0).' selecionados'; ?><?php if (!empty($row['protected'])) echo ' · '.(int)$row['protected'].' protegidos'; ?><?php if (!empty($row['has_more'])) echo ' · existem outros lotes'; ?></li><?php endforeach; ?></ul>
<p>Esta simulação usa os critérios enviados. A política só muda ao salvar.</p><?php endif; endif; ?>
<dl class="f3-facts"><dt>Próxima passagem prevista</dt><dd><?php $next=wp_next_scheduled(AutomaticMaintenance::HOOK); echo $next?esc_html(wp_date('d/m/Y H:i:s',$next)):'Agenda ausente'; ?></dd>
<dt>Última passagem</dt><dd><?php $labels=['complete'=>'Lote concluído','partial'=>!empty($last['stalled'])?'Lote sem avanço; confira as proteções':'Lote em continuação','paused'=>'Limpeza pausada','failed'=>'Falha; confira o diagnóstico','invalid_policy'=>'Política inválida','running'=>'Em execução ou sem confirmação de término']; echo $last?esc_html(($labels[$last['status']]??'Estado não reconhecido').' · '.wp_date('d/m/Y H:i:s',$last['finished_at']??$last['started_at'])):'Aguardando a primeira passagem'; ?></dd></dl>
<p>Os avisos são entregues pelo e-mail técnico configurado no Fator3 Site Core. Cada emissão ou renovação OAuth concede 90 dias para a próxima renovação. Credenciais anteriores conservam a data gravada; o aviso solicita a ação de quem opera a conexão.</p>
<p><a href="<?php echo esc_url(add_query_arg('document','release-0500',Admin::url('help'))); ?>">Ver regras e diagnóstico da manutenção</a></p></section>
