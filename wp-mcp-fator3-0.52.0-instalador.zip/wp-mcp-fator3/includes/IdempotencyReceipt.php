<?php
/** Minimal, durable replay barrier after bulky terminal results expire. */
declare(strict_types=1);
namespace Fator3\McpFiles;

final class IdempotencyReceipt {
    public static function get(string $key): ?array {
        return StateStore::get('idempotency',$key)
            ?? StateStore::get('idempotency-receipts',hash('sha256',get_current_blog_id().'|idempotency|'.$key));
    }
    public static function retire(array $row,string $selection): array {
        global $wpdb;
        try { $result=Persistence::transaction(static function() use ($row,$selection,$wpdb) {
            $table=Persistence::table('idempotency');
            $current=Persistence::rows($wpdb->prepare("SELECT revision,status,payload FROM `$table` WHERE record_key=%s FOR UPDATE",$row['record_key']))[0]??null;
            $receipt=Persistence::get('idempotency-receipts',$row['record_key'],true);
            if (!$current && ($receipt['maintenance_selection']??'')===$selection) return Result::ok(['replayed'=>true]);
            if (!$current || (int)$current['revision']!==$row['revision'] || !in_array($current['status'],['complete','compacted'],true)) return new \WP_Error('maintenance_selection_conflict','Registro mudou desde a prévia.');
            $value=json_decode($current['payload'],true,512,JSON_THROW_ON_ERROR);
            if (!is_string($value['fingerprint']??null) || !is_string($value['operation_id']??null)) return new \WP_Error('maintenance_selection_conflict','Comprovante insuficiente para impedir repetição.');
            $compact=['status'=>'compacted','time'=>$value['time']??time(),'compacted_at'=>time(),'maintenance_selection'=>$selection]
                +array_intersect_key($value,array_flip(['fingerprint','operation_id','connection_id','user_id']));
            if (!Persistence::put('idempotency-receipts',$row['record_key'],$compact)) throw new \RuntimeException();
            if (Persistence::query($wpdb->prepare("DELETE FROM `$table` WHERE record_key=%s AND revision=%d",$row['record_key'],$row['revision']))!==1) throw new \RuntimeException();
            return Result::ok(['changed'=>true]);
        }); return is_wp_error($result)?Result::error($result):$result; } catch (\Throwable $e) { return Result::fail('maintenance_write_failed','Retirada não confirmada; transação revertida.'); }
    }
}
