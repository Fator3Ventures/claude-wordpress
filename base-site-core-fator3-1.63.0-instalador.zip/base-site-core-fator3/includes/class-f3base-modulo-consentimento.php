<?php
/** Política legado/granular, interface acessível e decisões verificáveis para a fila. */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Política de consentimento e seu controle permanente.
 */
final class F3Base_Modulo_Consentimento extends F3Base_Modulo {
    /** Registro depende da configuração; diagnóstico detalhado só na consulta de saúde. */
    public function deve_registrar(): bool {return true;}


    public static function textos_configuraveis(array $padrao): array {
        $c=F3Base_Options::ler('f3base_consentimento');foreach($padrao as $key=>$value){$custom=$c['texto_'.$key]??'';if(is_string($custom)&&trim($custom)!==''){$padrao[$key]=sanitize_textarea_field($custom);}}return $padrao;
    }

	/**
	 * Handle do script.
	 */
	public const HANDLE = 'f3base-consentimento';

	/**
	 * Cookie que persiste a decisão do titular.
	 */
	public const COOKIE = 'f3base_consentimento';

	/**
	 * Suporte que o tema declara quando ele próprio fornece o controle no rodapé.
	 */
	public const SUPORTE_TEMA = 'f3base-consentimento-rodape';

	/**
	 * `id` do banner, e o alvo do `aria-controls` do controle do rodapé.
	 *
	 * FONTE ÚNICA: o markup do tema, o markup de reserva deste módulo e o
	 * elemento que o JavaScript cria leem daqui. Um `aria-controls` apontando
	 * para um `id` que ninguém cria é referência pendurada — o leitor de tela
	 * anuncia um controle de alguma coisa que não existe —, e foi por isso que
	 * o banner passou a ser construído no `iniciar()`, e não no primeiro clique.
	 */
	public const ID_BANNER = 'f3base-consentimento-banner';

	/**
	 * O VOCABULÁRIO FECHADO do estado de consentimento — três valores, e só.
	 *
	 * O defeito que ele fecha estava no registro do lead: `consentimento: true`
	 * virava `_f3base_consentimento = sim` em TODO lead, porque o campo booleano
	 * que o navegador manda é o PORTÃO das tags, e sob a política pré-aprovada
	 * ele vale `true` sem que ninguém tenha decidido nada. O arquivo do lead
	 * passava a afirmar uma decisão do titular que não existiu — que é o oposto
	 * do que um registro de consentimento serve para provar.
	 *
	 * São três valores porque são três situações materialmente diferentes, e
	 * duas delas permitem tags: decisão explícita de permitir, decisão explícita
	 * de recusar, e ausência de decisão sob política pré-aprovada. A ausência de
	 * decisão sob política de NEGATIVA por padrão não é um quarto valor — ali
	 * não há consentimento nenhum, e o nome disso é `nao`.
	 */
	public const ESTADO_SIM    = 'sim';
	public const ESTADO_NAO    = 'nao';
	public const ESTADO_PADRAO = 'padrao-pre-aprovado';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'consentimento';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Consentimento', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Preserva a política legada e oferece modo opcional por categorias. O controle permite revisar e revogar medição e publicidade; decisões de publicidade são verificadas no servidor antes de enviar pela fila.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_enqueue_scripts',
				'metodo'     => 'enfileirar',
				'prioridade' => 1,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'wp_footer',
				'metodo'     => 'render_controle',
				'prioridade' => 20,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_consentimento' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		$tema = current_theme_supports( self::SUPORTE_TEMA );

		return array(
			array(
				'rotulo'   => __( 'Controle no rodapé', 'f3base' ),
				'presente' => true,
				'detalhe'  => $tema
					? __( 'fornecido pela part do tema, que declara suporte; o comportamento continua sendo do site-core.', 'f3base' )
					: __( 'fornecido pelo próprio site-core em wp_footer, porque o tema não declara suporte.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'JavaScript no navegador', 'f3base' ),
				'presente' => true,
				'detalhe'  => __( 'sem JavaScript o controle não opera: perda declarada no relatório, como no fluxo de WhatsApp.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$config = $this->config();

		if ( self::modo_granular() && empty( $config['controle_rodape'] ) ) {
			return $this->degradado( 'Consentimento granular exige controle permanente para revisar e revogar escolhas.' ); }
		if ( self::modo_granular() ) {
			return $this->ativo( 'Medição por categoria e publicidade conforme política da instalação; negativas explícitas prevalecem e o servidor reconfere antes do envio. Revogação não desfaz entregas já iniciadas.' ); }

		if ( !F3Base_Options::fotografia_bruta('f3base_consentimento')['existe'] ) {
			return $this->degradado(
				__( 'Configuração de consentimento ausente no banco; confira a conclusão da instalação. O padrão efetivo está disponível na configuração.', 'f3base' )
			);
		}

		if ( empty( $config['controle_rodape'] ) ) {
			return $this->degradado(
				__( 'controle no rodapé desligado na configuração: o titular fica sem instrumento permanente de revisão.', 'f3base' )
			);
		}

		if ( 'pre-aprovado' === ( $config['padrao'] ?? 'pre-aprovado' ) ) {
			return $this->ativo(
				sprintf(
					/* translators: %d: prazo em dias. */
					__( 'política pré-aprovada com controle no rodapé; a negativa persiste por %d dias e o re-aceite religa. O script sai com defer, fora do caminho crítico: o default granted deste modo não muda o que seria enviado sem Consent Mode nenhum.', 'f3base' ),
					(int) ( $config['ttl_dias'] ?? 180 )
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %d: prazo em dias. */
				__( 'política de negativa por padrão: as tags só carregam após o aceite, que persiste por %d dias. O script sai BLOQUEANTE no cabeçalho: aqui a ordem é a garantia, e chegar depois de uma tag de terceiro seria um primeiro page_view sem o denied.', 'f3base' ),
				(int) ( $config['ttl_dias'] ?? 180 )
			)
		);
	}

	/**
	 * A ESTRATÉGIA DE CARGA É DECIDIDA PELA POLÍTICA, e não por um interruptor.
	 *
	 * Aqui é onde a decisão acontece, então é aqui que o motivo dela mora.
	 *
	 * **Pré-aprovado devolve `defer`.** O `default` deste modo é `granted`, que é
	 * materialmente o que o gtag faz sem Consent Mode nenhum: chegar tarde com
	 * `granted` não muda o que foi enviado. E a ordem que importa continua de pé
	 * sem custo — `defer` executa depois do parse e NA ORDEM DO DOCUMENTO, e o
	 * carregador de tags é `defer` no rodapé, atrás deste no documento e
	 * declarado como dependente deste handle. O consentimento continua rodando
	 * antes do carregador, e o script sai do caminho crítico do parser.
	 *
	 * **Negado por padrão devolve bloqueante.** Ali o `default` é `denied`, e a
	 * ordem deixa de ser conveniência para virar a garantia inteira: o que
	 * dispara antes de o `denied` chegar é um primeiro `page_view` com
	 * consentimento pleno de quem ainda não consentiu. E a ordem do `defer` só
	 * ordena scripts `defer` ENTRE SI — um `gtag.js` `async` de outro plugin, ou
	 * um snippet colado no cabeçalho, executa antes de qualquer `defer` da
	 * página. Bloquear o parser é o preço de não disparar antes de saber, e
	 * neste modo ele é o preço certo.
	 *
	 * A permissividade autorizada para o modo pré-aprovado NÃO se aplica aqui:
	 * ela foi autorizada descrevendo o cenário de pré-aprovação, em que a
	 * medição já começa na chegada por decisão declarada do projeto.
	 *
	 * @param string|null $padrao Política; nulo lê a option.
	 * @return string `defer`, ou string vazia para script bloqueante.
	 */
	public static function estrategia_de_carga( ?string $padrao = null ): string {
		if ( self::modo_granular() ) {
			return ''; }
		if ( null === $padrao ) {
			$config = F3Base_Options::ler( 'f3base_consentimento' );
			$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';
		}

		return 'pre-aprovado' === $padrao ? 'defer' : '';
	}

	/**
	 * Enfileira o script de consentimento no cabeçalho.
	 *
	 * O script mora no `<head>` nos DOIS modos — é de lá que a ordem do
	 * documento o põe antes do carregador de tags, que vive no rodapé. O que a
	 * política decide é se ele BLOQUEIA o parser; o motivo de cada lado está em
	 * `estrategia_de_carga()`, que é onde a decisão acontece.
	 *
	 * @return void
	 */
	public static function url_politica_opcional(): string {
		$id   = (int) get_option( 'wp_page_for_privacy_policy', 0 );
		$post = $id > 0 ? get_post( $id ) : null;
		if ( ! $post || 'publish' !== $post->post_status || ! empty( $post->post_password ) || ! is_post_publicly_viewable( $post ) ) {
			return ''; }
		return esc_url_raw( (string) get_privacy_policy_url(), array( 'http', 'https' ) );
	}

	public function enfileirar(): void {
		if ( apply_filters( 'f3base_consentimento_css_externo', false ) ) {
			wp_enqueue_style( 'f3base-consentimento', F3BASE_PLUGIN_URL . 'assets/f3base-consentimento.css', array(), F3BASE_PLUGIN_VERSAO );
		} else {
			wp_register_style( 'f3base-consentimento', false, array(), F3BASE_PLUGIN_VERSAO );
			wp_enqueue_style( 'f3base-consentimento' );
			wp_add_inline_style( 'f3base-consentimento', (string) file_get_contents( F3BASE_PLUGIN_DIR . 'assets/f3base-consentimento.css' ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Lê somente o CSS local fixo do próprio pacote, sem URL externa.
		}
		$config = $this->config();
		$padrao = (string) ( $config['padrao'] ?? 'pre-aprovado' );

		$argumentos = array(
			'in_footer' => false,
		);

		// Essencial no head: resolve a política local antes do Pixel e dos observadores.

		wp_enqueue_script(
			self::HANDLE,
			F3BASE_PLUGIN_URL . 'assets/f3base-consentimento' . ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min' ) . '.js',
			array(),
			F3BASE_PLUGIN_VERSAO,
			$argumentos
		);

		wp_localize_script(
			self::HANDLE,
			'f3baseConsentimentoDados',
			array(
				'publicidadePreAutorizada'=>F3Base_Publicidade::preautorizada(),
                'padrao'                 => $padrao,
				'modo'                   => self::modo_granular() ? 'granular' : 'legado',
				'politicaVersao'         => self::politica_versao(),
				'gtmSeparacaoVerificada' => ! empty( $config['gtm_separacao_verificada'] ),
				'endpoint'               => esc_url_raw( rest_url( F3BASE_REST_NAMESPACE . F3Base_Consentimento_Decisoes::ROTA ) ),
				'ttlDias'                => (int) ( $config['ttl_dias'] ?? 180 ),
				'controleRodape'         => ! empty( $config['controle_rodape'] ),
				'avisoPrimeiraVisita'    => ! empty( $config['aviso_primeira_visita'] ),
				'cookie'                 => self::COOKIE,
				'seletorControle'        => '[data-f3base-consentimento]',
				'idBanner'               => self::ID_BANNER,
                'painel'=>($config['painel']??'padrao')==='tema'||current_theme_supports('f3base-consentimento-painel')?'tema':'padrao',
				'categorias'             => array( 'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization' ),
				'textos'                 => self::textos_configuraveis(array(
					'titulo'       => __( 'Política de Cookie', 'f3base' ),
					'explicacao'   => self::modo_granular() ? __( 'Escolha as finalidades permitidas. A medição depende da escolha por categoria. A publicidade segue a política do site na ausência de escolha; uma negativa explícita prevalece. Funções essenciais, incluindo contato e sua escolha, continuam disponíveis.', 'f3base' ) : ( 'pre-aprovado' === $padrao
						? __( 'A medição começa ligada neste modo. A publicidade segue a política do site. Você pode recusar ambas agora; a escolha fica guardada neste navegador.', 'f3base' )
						: __( 'A medição exige aceite neste modo. A publicidade segue a política do site. O controle permite recusar ou autorizar ambas, e rever a escolha depois.', 'f3base' ) ),
					'aceitar'      => self::modo_granular() ? __( 'Permitir todas', 'f3base' ) : __( 'Permitir medição e publicidade', 'f3base' ),
					'recusar'      => self::modo_granular() ? __( 'Recusar todas', 'f3base' ) : __( 'Recusar medição e publicidade', 'f3base' ),
					'fechar'       => __( 'Fechar', 'f3base' ),
					'estadoAtivo'  => __( 'Medição ligada neste navegador.', 'f3base' ),
					'estadoNegado' => __( 'Medição desligada neste navegador.', 'f3base' ),
					'aviso'        => __( 'Este site usa medição por padrão. Ajuste no controle de privacidade do rodapé.', 'f3base' ),
					'avisoOk'      => __( 'Entendi', 'f3base' ),
					'politica'     => __( 'Política de Privacidade', 'f3base' ),
                    'salvar'=>'Salvar escolhas','finalidades'=>'Escolha as finalidades','medicao'=>'Medição de uso e desempenho','publicidade'=>'Publicidade e conversões','controle'=>'Política de Cookie',
				)),
				'politicaUrl'            => self::url_politica_opcional(),
			)
		);
	}

	/**
	 * Publica o controle de revisão no rodapé.
	 *
	 * Se o tema declara `f3base-consentimento-rodape`, ele já fornece o botão na
	 * part e nada é impresso aqui — o comportamento continua sendo deste módulo.
	 *
	 * @return void
	 */
	public function render_controle(): void {
		$config = $this->config();

		if ( empty( $config['controle_rodape'] ) ) {
			return;
		}

		if ( current_theme_supports( self::SUPORTE_TEMA ) ) {
			return;
		}

		printf(
			'<p class="f3base-consentimento-rodape"><button type="button" class="f3base-consentimento-abrir" data-f3base-consentimento="abrir" aria-haspopup="dialog" aria-expanded="false" aria-controls="%1$s">%2$s</button></p>',
			esc_attr( self::ID_BANNER ),
			esc_html(self::textos_configuraveis(array('controle'=>'Política de Cookie'))['controle'])
		);
	}

	/**
	 * Decisão registrada no navegador do visitante, lida no servidor.
	 *
	 * @return string `granted`, `denied` ou `sem-decisao`.
	 */
	public static function decisao_do_visitante(): string {
		if ( self::modo_granular() ) {
			return self::permite_categoria( 'publicidade' ) ? 'granted' : 'denied'; }
		if ( ! isset( $_COOKIE[ self::COOKIE ] ) ) {
			return 'sem-decisao';
		}

		$valor = is_string( $_COOKIE[ self::COOKIE ] ) ? sanitize_key( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';

		return in_array( $valor, array( 'granted', 'denied' ), true ) ? $valor : 'sem-decisao';
	}

	/**
	 * Há consentimento efetivo para carregar tags de terceiro?
	 *
	 * @return bool
	 */
	public static function permite_tags(): bool {
		if ( self::modo_granular() ) {
			return self::permite_categoria( 'publicidade' ); }
		$config = F3Base_Options::ler( 'f3base_consentimento' );
		$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';

		$decisao = self::decisao_do_visitante();

		if ( 'denied' === $decisao ) {
			return false;
		}

		if ( 'granted' === $decisao ) {
			return true;
		}

		return 'pre-aprovado' === $padrao;
	}

	/**
	 * Os três valores do vocabulário, para quem precisa validar contra a lista.
	 *
	 * @return array<int,string>
	 */
	public static function vocabulario_do_estado(): array {
		return array( self::ESTADO_SIM, self::ESTADO_NAO, self::ESTADO_PADRAO );
	}

	/**
	 * O ESTADO REAL do consentimento desta requisição, no vocabulário fechado.
	 *
	 * A decisão do titular vem do cookie, que é onde ela mora; a política vem da
	 * option. O parâmetro é o que o CLIENTE declarou — o portão de `permiteTags()`
	 * — e ele entra pela metade RESTRITIVA: um cliente que diz "não" é ouvido
	 * (o beacon pode ter viajado sem cookie, ou a recusa pode ser mais nova que
	 * a página), e um cliente que diz "sim" NUNCA promove a ausência de decisão
	 * a consentimento. Foi essa promoção que arquivou todo lead como consentido.
	 *
	 * @param bool|null $declarado O que o cliente declarou; nulo quando o campo não veio.
	 * @return string Um dos três valores do vocabulário.
	 */
	public static function estado_medido( ?bool $declarado = null ): string {
		if ( self::modo_granular() ) {
			if(false===$declarado){return self::ESTADO_NAO;}$p=F3Base_Publicidade::requisicao();return !$p['permitida']?self::ESTADO_NAO:($p['fundamento']==='decisao_explicita'?self::ESTADO_SIM:self::ESTADO_PADRAO); }
		if ( false === $declarado ) {
			return self::ESTADO_NAO;
		}

		$decisao = self::decisao_do_visitante();

		if ( 'granted' === $decisao ) {
			return self::ESTADO_SIM;
		}

		if ( 'denied' === $decisao ) {
			return self::ESTADO_NAO;
		}

		$config = F3Base_Options::ler( 'f3base_consentimento' );
		$padrao = is_array( $config ) && isset( $config['padrao'] ) ? (string) $config['padrao'] : 'pre-aprovado';

		return 'pre-aprovado' === $padrao ? self::ESTADO_PADRAO : self::ESTADO_NAO;
	}

	/**
	 * Este estado permite mandar evento a terceiro?
	 *
	 * É o MESMO portão de `permite_tags()`, respondido a partir do estado já
	 * medido: quem já mediu não mede de novo, e duas leituras da mesma coisa
	 * dentro da mesma requisição são duas chances de divergir.
	 *
	 * @param string $estado Estado do vocabulário fechado.
	 * @return bool
	 */
	public static function estado_permite_tags( string $estado ): bool {
		return self::ESTADO_NAO !== $estado && in_array( $estado, self::vocabulario_do_estado(), true );
	}

	/**
	 * Configuração normalizada.
	 *
	 * @return array<string,mixed>
	 */
	public function registrar_rota(): void {
		F3Base_Consentimento_Decisoes::registrar_rota(); }

	public static function modo_granular(): bool {
		$config = F3Base_Options::ler( 'f3base_consentimento' );
		return is_array( $config ) && 'granular' === ( $config['modo'] ?? 'legado' );
	}

	public static function politica_versao(): string {
		$config = F3Base_Options::ler( 'f3base_consentimento' );
		return substr(
			hash(
				'sha256',
				wp_json_encode(
					array(
						'v'      => (string) ( $config['politica_versao'] ?? '1' ),
						'modo'   => (string) ( $config['modo'] ?? 'legado' ),
						'padrao' => (string) ( $config['padrao'] ?? 'pre-aprovado' ),
						'gtm'    => ! empty( $config['gtm_separacao_verificada'] ),
					)
				)
			),
			0,
			48
		);
	}

	public static function referencia_confirmada(): array {
		if ( ! self::modo_granular() ) {
			return array(
				'decisao_ref'     => '',
				'politica_versao' => '',
			); }
		$cookie = isset( $_COOKIE[ self::COOKIE ] ) && is_string( $_COOKIE[ self::COOKIE ] ) ? wp_unslash( $_COOKIE[ self::COOKIE ] ) : '';
		$valor  = json_decode( $cookie, true );
		if ( ! is_array( $valor ) || ! isset( $valor['v'], $valor['comprovante'] ) || ! is_string( $valor['comprovante'] ) || self::politica_versao() !== $valor['v'] ) {
			return array(
				'decisao_ref'     => '',
				'politica_versao' => self::politica_versao(),
			); }
		return array(
			'decisao_ref'     => F3Base_Consentimento_Decisoes::referencia( $valor['comprovante'] ),
			'politica_versao' => $valor['v'],
		);
	}

	public static function permite_categoria( string $categoria ): bool {
		if ( ! in_array( $categoria, array( 'medicao', 'publicidade' ), true ) ) {
			return false; }
		if($categoria==='publicidade'){return F3Base_Publicidade::requisicao()['permitida'];}
		if ( ! self::modo_granular() ) {
			return self::permite_tags(); }
		$ref = self::referencia_confirmada();
		return F3Base_Consentimento_Decisoes::permite( $ref['decisao_ref'], $ref['politica_versao'], $categoria );
	}

	private function config(): array {
		$config = F3Base_Options::ler( 'f3base_consentimento' );

		return is_array( $config ) ? $config : array();
	}
}
