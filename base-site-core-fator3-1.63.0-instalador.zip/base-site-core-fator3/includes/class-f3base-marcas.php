<?php
/** Public-page cross-brand inspection. Configuration never supplies automatic brand exceptions. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Marcas {
    const ALGORITMO='variacoes-longas/2';
    const OPCAO='f3base_marcas_vigiadas';const STATE='f3base_marcas_inspecao';const HOOK='f3base_marcas_inspecionar';
    public static function catalogo(array $c): array {
        $text=array('type'=>'string','minLength'=>1,'maxLength'=>100);$schema=array('type'=>'array','maxItems'=>50,'items'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('nome','variacoes','dominios','caminhos_permitidos'),'properties'=>array('superficies_permitidas'=>array('type'=>'array','maxItems'=>4,'uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>array('corpo','cabecalho','rodape','dados_estruturados'))),'nome'=>$text+array('description'=>'Rótulo da marca; não participa da busca.'),'variacoes'=>array('description'=>'Somente estas formas são buscadas no texto. Ignora maiúsculas/minúsculas, distingue acentos e exige limites de letras/números Unicode. Em sobreposição vence a variação mais longa; empate usa a ordem das marcas.','type'=>'array','maxItems'=>30,'uniqueItems'=>true,'items'=>$text),'dominios'=>array('type'=>'array','maxItems'=>30,'uniqueItems'=>true,'items'=>$text),'caminhos_permitidos'=>array('type'=>'array','maxItems'=>200,'uniqueItems'=>true,'items'=>array('type'=>'string','maxLength'=>500)))));
        $c[self::OPCAO]=array('rotulo'=>'Marcas a vigiar neste site','descricao'=>'Nome é somente rótulo. Busca variações sem distinguir maiúsculas, mas distingue acentos, com limites de letras/números Unicode. Cada trecho pertence à variação mais longa; empate usa a ordem das marcas. Domínios casam host exato/subdomínio; o mais específico vence. Exceções são caminhos exatos, sem curingas, ou superfícies permitidas em todo o site; lista vazia não inspeciona.','operavel'=>true,'campo'=>'grupo','secao'=>'conteudo','padrao'=>array(),'autoload'=>false,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static function($v)use($schema){$r=rest_validate_value_from_schema($v,$schema);if(is_wp_error($r)){return $r->get_error_message();}$seen=array();foreach($v as $brand){$n=mb_strtolower($brand['nome']);if(isset($seen[$n])){return 'Nomes de marcas precisam ser únicos.';}$seen[$n]=true;foreach($brand['dominios'] as $host){if(!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/iD',$host)){return 'Informe domínio sem protocolo, caminho, porta ou curinga.';}}foreach($brand['caminhos_permitidos'] as $path){if(!str_starts_with($path,'/')||str_starts_with($path,'//')||preg_match('/[?#*\x00-\x20]/',$path)){return 'Exceções precisam de caminhos exatos, sem consulta ou curinga.';}}}return '';});
        $c[self::STATE]=array('rotulo'=>'Fotografia da inspeção de marcas','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));return $c;
    }
    private static function superficie(DOMNode $node): string {for($p=$node;$p instanceof DOMNode;$p=$p->parentNode){if($p instanceof DOMElement){$tag=strtolower($p->tagName);$role=$p->getAttribute('role');if($tag==='header'||$role==='banner'||$p->getAttribute('data-f3base-superficie')==='cabecalho'){return 'cabecalho';}if($tag==='footer'||$role==='contentinfo'){return 'rodape';}}}return 'corpo';}
    private static function dominio(string $url,array $hosts): bool {$host=strtolower((string)wp_parse_url(str_starts_with($url,'//')?'https:'.$url:$url,PHP_URL_HOST));foreach($hosts as $wanted){$wanted=strtolower($wanted);if($host===$wanted||str_ends_with($host,'.'.$wanted)){return true;}}return false;}
    /** All candidates compete before permissions; an allowed long name never leaks into a shorter brand. */
    private static function nomes(string $text,array $cfg,bool &$cut): array {
        $candidates=array();
        foreach($cfg as $index=>$brand){
            $names=array_values(array_unique(array_filter($brand['variacoes'],static fn($v)=>$v!=='')));if(!$names){continue;}
            usort($names,static fn($a,$b)=>mb_strlen($b)<=>mb_strlen($a));
            $pattern='/(?=((?<![\pL\pN\pM])(?:'.implode('|',array_map(static fn($x)=>preg_quote($x,'/'),$names)).')(?![\pL\pN\pM])))/iu';
            $matches=array();$n=preg_match_all($pattern,$text,$matches,PREG_OFFSET_CAPTURE);
            if($n===false){$cut=true;continue;}if($n>1000){$cut=true;}
            foreach(array_slice($matches[1]??array(),0,1000) as $m){$candidates[]=array('marca_indice'=>$index,'inicio'=>$m[1],'fim'=>$m[1]+strlen($m[0]),'tamanho'=>mb_strlen($m[0]));}
        }
        usort($candidates,static fn($a,$b)=>($b['tamanho']<=>$a['tamanho'])?:($a['inicio']<=>$b['inicio'])?:($a['marca_indice']<=>$b['marca_indice']));$selected=array();
        foreach($candidates as $v){$overlap=false;foreach($selected as $old){if($v['inicio']<$old['fim']&&$v['fim']>$old['inicio']){$overlap=true;break;}}if(!$overlap){$pos=mb_strlen(substr($text,0,$v['inicio']));$v['trecho']=mb_substr($text,max(0,$pos-25),80);$selected[]=$v;if(count($selected)>200){$cut=true;break;}}}
        usort($selected,static fn($a,$b)=>$a['inicio']<=>$b['inicio']);return $selected;
    }
    private static function marca_dominio(string $url,array $cfg): ?int {
        $best=null;$length=-1;foreach($cfg as $i=>$brand){foreach($brand['dominios'] as $host){if(self::dominio($url,array($host))&&strlen($host)>$length){$best=$i;$length=strlen($host);}}}return $best;
    }
    public static function html(string $html,string $url): array {
        $cfg=array_values(F3Base_Options::ler(self::OPCAO));$out=array();if(!$cfg){return array('estado'=>'desligada','ocorrencias'=>array(),'total'=>0,'algoritmo'=>self::ALGORITMO);}
        if(!class_exists('DOMDocument')){return array('estado'=>'dom_indisponivel','ocorrencias'=>array(),'total'=>null);}
        $dom=new DOMDocument();$old=libxml_use_internal_errors(true);$ok=$dom->loadHTML('<?xml encoding="UTF-8">'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);if(!$ok){return array('estado'=>'html_invalido','ocorrencias'=>array(),'total'=>null);}$xp=new DOMXPath($dom);$texts=array();$nodes=0;$cut=false;
        foreach($xp->query('//body//text()[normalize-space(.)!=""]') as $n){if(++$nodes>15000){$cut=true;break;}$skip=false;for($p=$n->parentNode;$p instanceof DOMElement;$p=$p->parentNode){if(in_array(strtolower($p->tagName),array('script','style','template','noscript'),true)||$p->hasAttribute('hidden')||$p->getAttribute('aria-hidden')==='true'){$skip=true;break;}}if(!$skip){$surface=self::superficie($n);$texts[$surface]=($texts[$surface]??'').' '.$n->textContent;}}
        $path=rtrim(rawurldecode((string)wp_parse_url($url,PHP_URL_PATH)),'/')?:'/';
        $emit=static function(int $index,array $row)use(&$out,$cfg,$path){$brand=$cfg[$index];$allowed=in_array($path,array_map(static fn($p)=>rtrim(rawurldecode($p),'/')?:'/',$brand['caminhos_permitidos']),true);$surface=in_array($row['superficie'],$brand['superficies_permitidas']??array(),true);$out[]=array('marca'=>$brand['nome'],'permitida'=>$allowed||$surface,'motivo'=>$allowed?'caminho':($surface?'superficie':'sem_excecao'))+$row;};
        foreach($texts as $surface=>$text){$text=preg_replace('/\s+/u',' ',trim($text));foreach(self::nomes($text,$cfg,$cut) as $m){$emit($m['marca_indice'],array('tipo'=>'mencao','trecho'=>$m['trecho'],'superficie'=>$surface));}}
        foreach($xp->query('//a[@href]') as $n){$urlValue=$n->getAttribute('href');$index=self::marca_dominio($urlValue,$cfg);if($index!==null){$emit($index,array('tipo'=>'link','dominio'=>strtolower((string)wp_parse_url(str_starts_with($urlValue,'//')?'https:'.$urlValue:$urlValue,PHP_URL_HOST)),'trecho'=>mb_substr(trim(preg_replace('/\s+/u',' ',$n->textContent?:$urlValue)),0,80),'superficie'=>self::superficie($n)));}}
        foreach($xp->query('//script[@type="application/ld+json"]') as $n){$json=json_decode($n->textContent,true,64);if(!is_array($json)){$cut=true;continue;}$count=0;
            $walk=static function($v,string $key='')use(&$walk,&$count,&$cut,$cfg,$emit){if(++$count>5000){$cut=true;return;}if(is_array($v)){foreach($v as $k=>$x){$walk($x,is_string($k)?$k:$key);}return;}if(!is_string($v)){return;}$base=array('superficie'=>'dados_estruturados','propriedade'=>mb_substr($key,0,80));$index=self::marca_dominio($v,$cfg);if($index!==null){$emit($index,$base+array('tipo'=>'link_estruturado','trecho'=>mb_substr($v,0,80)));return;}foreach(self::nomes($v,$cfg,$cut) as $m){$emit($m['marca_indice'],$base+array('tipo'=>'mencao_estruturada','trecho'=>$m['trecho']));}};$walk($json);
        }
        if(count($out)>200){$cut=true;}$out=array_slice($out,0,200);return array('estado'=>$cut?'parcial':'inspecionada','algoritmo'=>self::ALGORITMO,'ocorrencias'=>$out,'total'=>count($out),'nao_permitidas'=>count(array_filter($out,static fn($x)=>!$x['permitida'])),'limite'=>'Até 200 ocorrências e 15 mil nós; HTML sem JavaScript. Texto visível e destino do link são superfícies de evidência distintas.');
    }
    /** A separate worker refreshes local totals; reading help and the existing audit never writes. */
    public static function processar(): array {
        $cfg=F3Base_Options::ler(self::OPCAO);if(!$cfg){return array('ok'=>true,'codigo'=>'marcas_desligadas');}$lock=F3Base_Trava::adquirir('marcas-inspecao',45);if(!$lock){return array('ok'=>false,'codigo'=>'marcas_ocupadas');}
        try{
            $rev=F3Base_Options::revisao(self::OPCAO);$s=get_option(self::STATE,array());if(($s['algoritmo']??'')!==self::ALGORITMO||($s['revisao']??'')!==$rev||(!empty($s['completa'])&&($s['em']??0)<time()-DAY_IN_SECONDS)){$s=array('algoritmo'=>self::ALGORITMO,'revisao'=>$rev,'cursor'=>0,'paginas'=>array(),'iniciada_em'=>time());}
            if(!empty($s['completa'])){return array('ok'=>true,'codigo'=>'fotografia_recente');}
            global $wpdb;$rows=$wpdb->get_col($wpdb->prepare("SELECT ID FROM %i WHERE ID>%d AND post_status='publish' AND post_password='' AND post_type IN ('post','page') ORDER BY ID LIMIT 2",$wpdb->posts,(int)$s['cursor']));
            foreach($rows as $id){$url=get_permalink((int)$id);$r=F3Base_Http_Publico::buscar($url,2097152,microtime(true)+8,'GET',array('X-F3Base-Teste'=>'1'),false);$parsed=self::html((string)($r['corpo']??''),$url);$complete=($r['status']??0)===200&&isset($r['corpo'])&&($r['codigo']??'')!=='resposta_truncada'&&$parsed['estado']==='inspecionada';$s['paginas'][(string)$id]=array('url'=>$url,'em'=>time(),'completa'=>$complete,'ocorrencias'=>$complete?$parsed['total']:null,'nao_permitidas'=>$complete?$parsed['nao_permitidas']:null);$s['cursor']=(int)$id;}
            $s['completa']=count($rows)<2;$s['em']=time();$saved=F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>F3Base_Options::revisao(self::OPCAO)===$rev?$s:null);return array('ok'=>!empty($saved['persisted']),'codigo'=>'marcas_fotografia_atualizada','paginas'=>count($rows),'completa'=>$s['completa']);
        }finally{F3Base_Trava::liberar($lock);}
    }
    public static function resumo(): array {
        $s=get_option(self::STATE,array());$active=(bool)F3Base_Options::ler(self::OPCAO);$current=($s['algoritmo']??'')===self::ALGORITMO&&($s['revisao']??'')===F3Base_Options::revisao(self::OPCAO);$rows=$current?($s['paginas']??array()):array();$valid=array();foreach($rows as $id=>$row){$p=get_post((int)$id);if($p&&$p->post_status==='publish'&&!$p->post_password){$valid[]=$row;}}
        return array('ativa'=>$active,'em'=>$current?($s['em']??null):null,'completa'=>$current&&!empty($s['completa'])&&!in_array(false,array_column($valid,'completa'),true),'paginas_inspecionadas'=>count($valid),'ocorrencias'=>$current?array_sum(array_column($valid,'ocorrencias')):null,'nao_permitidas'=>$current?array_sum(array_column($valid,'nao_permitidas')):null,'detalhe'=>'f3base/conteudo-instrumentacao-ler','atualizacao'=>'Fotografia diária em lotes de duas páginas publicadas por passagem; sem consultas HTTP nesta leitura.');
    }
    public static function iniciar(): void {
        add_action(self::HOOK,static function(){try{return self::processar();}finally{if(F3Base_Options::ler(self::OPCAO)){F3Base_Fila::agendar(self::HOOK,time()+300);}}});
        add_action('init',static function(){if(F3Base_Options::ler(self::OPCAO)&&!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+60);}},96);
        add_action('save_post',static function($id,$p){if(in_array($p->post_type,array('page','post'),true)&&F3Base_Options::ler(self::OPCAO)){F3Base_Options::atualizar_estado(self::STATE,static function($s){$s['revisao']='';return $s;});F3Base_Fila::agendar(self::HOOK,time()+60);}},10,2);
    }
}
