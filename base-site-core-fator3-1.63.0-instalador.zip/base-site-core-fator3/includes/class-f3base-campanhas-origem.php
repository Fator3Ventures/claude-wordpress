<?php
/** Optional attribution sources, frozen only while accepting a new contact. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Campanhas_Origem {
    const OPTION='f3base_campanhas_origem';
    public static function padroes(): array {return array('conta_meta_configurada'=>true,'nome_acervo_meta'=>true,'janela_acervo_dias'=>30);}
    public static function schema(): array {return array('type'=>'object','additionalProperties'=>false,'required'=>array('conta_meta_configurada','nome_acervo_meta','janela_acervo_dias'),'properties'=>array('conta_meta_configurada'=>array('type'=>'boolean','description'=>'Completa conta ausente somente para Meta Ads sem conflito, usando a seleção ativa do leitor Meta Core.'),'nome_acervo_meta'=>array('type'=>'boolean','description'=>'Completa nome ausente pelo campaign_name de campanha/conta exatas no acervo concedido; URL e mapas explícitos prevalecem.'),'janela_acervo_dias'=>array('type'=>'integer','minimum'=>1,'maximum'=>366,'description'=>'Janela de observações locais anteriores à captura; vence o dia mais recente com nome. Não infere nome pela data.')));}
    public static function catalogo(array $c): array {$schema=self::schema();$c[self::OPTION]=array('rotulo'=>'Fontes de conta e nome da campanha','descricao'=>'Afeta somente contatos novos aceitos com publicidade permitida. Fontes independentes, sem chamada externa. Não regrava contatos, mensagens ou journal anteriores. Simule por campanhas-origem-simular antes de gravar.','operavel'=>true,'secao'=>'medicao','campo'=>'grupo','padrao'=>self::padroes(),'autoload'=>false,'schema_config'=>$schema,'schema_entrada'=>$schema,'sanitiza'=>array(F3Base_Servicos::class,'identidade'),'recusa'=>static fn($v)=>is_wp_error(rest_validate_value_from_schema($v,$schema))?'Informe fontes booleanas e janela entre 1 e 366 dias.':'');return $c;}
    private static function toque(array $a,array $cfg,string $revision,int $now): array {
        $proof=array('revisao'=>$revision,'conta_fonte'=>$a['conta_fonte']??'','nome_fonte'=>$a['nome_campanha_fonte']??'','codigo'=>'nao_aplicavel','observado_em'=>$now);
        if(($a['plataforma']??'')!=='meta_ads'||!empty($a['conflito_plataforma'])||!preg_match('/^[0-9]{1,40}$/D',(string)($a['campanha_id']??''))){return array($a,$proof);}
        $meta=F3Base_Meta_Ads::configuracao();$metaRevision=F3Base_Options::revisao(F3Base_Meta_Ads::OPTION);$proof['selecao_meta_revisao']=$metaRevision;
        if(empty($a['conta_id'])&&$cfg['conta_meta_configurada']&&$meta['ready']){$a['conta_id']=$meta['account_id'];$a['f3_ads_account_id']=$meta['account_id'];$a['conta_fonte']='conta_da_configuracao';$proof['conta_fonte']='conta_da_configuracao';$snapshots=array_intersect_key($a,array_flip(array('sessao_origem','primeiro_toque','ultimo_toque')));$a=F3Base_Atribuicao::normalizar($a,false)+$snapshots;}
        $proof['conta_id']=$a['conta_id']??'';$proof['campanha_id']=$a['campanha_id'];
        if(F3Base_Atribuicao::nome_campanha($a)!==''){$proof['codigo']='nome_preservado';$proof['nome_fonte']=$a['nome_campanha_fonte']??'informado';return array($a,$proof);}
        if(!$cfg['nome_acervo_meta']){$proof['codigo']='nome_acervo_desligado';return array($a,$proof);}
        if(!$meta['ready']||($a['conta_id']??'')!==$meta['account_id']){$proof['codigo']='conta_sem_selecao_compativel';return array($a,$proof);}
        $to=gmdate('Y-m-d',$now);$from=gmdate('Y-m-d',$now-($cfg['janela_acervo_dias']-1)*DAY_IN_SECONDS);
        $r=F3Base_Meta_Ads::nome_campanha_local($a['conta_id'],$a['campanha_id'],$from,$to);$proof['codigo']=$r['codigo'];$proof['acervo']=$r['prova']??null;
        if(!empty($r['ok'])&&F3Base_Options::revisao(F3Base_Meta_Ads::OPTION)===$metaRevision){$a['utm_campaign']=$r['nome'];$a['nome_campanha_origem']=$r['nome'];$a['nome_campanha_fonte']='acervo_meta_ads';$proof['nome_fonte']='acervo_meta_ads';}
        elseif(!empty($r['ok'])){$proof['codigo']='selecao_alterada';}
        return array($a,$proof);
    }
    public static function resolver(array $entrada,?array $cfg=null,?int $now=null): array {
        $cfg=$cfg??F3Base_Options::ler(self::OPTION);$revision=hash('sha256',wp_json_encode(F3Base_Auditoria::ordenar($cfg)));$now=$now??time();$a=F3Base_Atribuicao::normalizar($entrada);$proof=array('politica'=>$cfg,'revisao'=>$revision,'toques'=>array());
        [$a,$proof['toques']['principal']]=self::toque($a,$cfg,$revision,$now);
        if(is_array($a['sessao_origem']??null)){[$a['sessao_origem'],$proof['toques']['sessao_origem']]=self::toque($a['sessao_origem'],$cfg,$revision,$now);}
        // The first/last historical touches are retained; this is not retrospective enrichment.
        return array('atribuicao'=>$a,'prova'=>$proof);
    }
    public static function capturar(array $dados): array {
        $permit=F3Base_Contato_Apresentacao::consentimento($dados);if(!$permit['publicidade']||!is_array($dados['atribuicao']??null)){return $dados;}
        $r=self::resolver($dados['atribuicao']);$dados['atribuicao']=$r['atribuicao'];$dados['campanha_resolucao']=$r['prova'];return $dados;
    }
    public static function simular(array $e): array {
        if(!current_user_can('manage_options')||!current_user_can('f3base_ler_leads')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $cfg=$e['configuracao']??F3Base_Options::ler(self::OPTION);if(is_wp_error(rest_validate_value_from_schema($cfg,self::schema()))||!F3Base_Atribuicao::validar($e['parametros']??null)){return array('ok'=>false,'codigo'=>'entrada_invalida');}
        return array('ok'=>true,'simulado'=>true,'persisted'=>false,'http_fornecedor'=>false,'revisao_atual'=>F3Base_Options::revisao(self::OPTION))+self::resolver($e['parametros'],$cfg);
    }
    public static function iniciar(): void {add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('campanhas-origem-simular','Simular fontes de conta e nome da campanha usando somente o acervo local concedido, sem gravar contato nem enviar ao CRM',array(__CLASS__,'simular'),array('parametros'=>array('type'=>'object','additionalProperties'=>true),'configuracao'=>self::schema()),array('parametros'),true,'manage_options',static fn()=>current_user_can('manage_options')&&current_user_can('f3base_ler_leads'));});}
}
