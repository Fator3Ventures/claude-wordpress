<?php
/** Manual matching is returned only with a classified, accepted browser Lead. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Correspondencia {
    const OPTION='f3base_meta_correspondencia';
    public static function catalogo(array $c): array {
        $c[self::OPTION]=['rotulo'=>'Correspondência manual do Lead Meta','descricao'=>'Fornece somente SHA-256 de e-mail/telefone válido no aceite do contato, com publicidade permitida e exclusões de teste, editor e automação. Não liga a correspondência automática Meta.','operavel'=>true,'secao'=>'medicao','campo'=>'booleano','autoload'=>false,'padrao'=>true,'schema_config'=>['type'=>'boolean'],'schema_entrada'=>['type'=>'boolean'],'sanitiza'=>static fn($v)=>(bool)filter_var($v,FILTER_VALIDATE_BOOLEAN),'recusa'=>static fn($v)=>is_bool($v)?'':'Informe ligado ou desligado.','impacto'=>'Afeta somente novos aceites no navegador; desligar não remove dados já recebidos pela Meta.','exemplo'=>'true'];return $c;
    }
    public static function dados(array $lead): array {
        $d=$lead['dados']??[];
        if(F3Base_Options::ler(self::OPTION)!==true||($lead['captura']??'')!=='aceito'||($lead['classe_trafego']??'')!=='nao_marcado'||!in_array($lead['metodo']??'',['formulario','whatsapp_formulario'],true)||!empty($d['contexto_teste'])||!empty($d['audiencia_excluida'])||F3Base_Audiencia::editor()){return [];}
        if(in_array($d['classificacao_contexto']??'',['pendente','falha','excluida','saida_sem_classificacao','consentimento_negado'],true)){return [];}
        $a=F3Base_Audiencia::automacao((array)($d['sinais_navegador']??$d['sinais']??[]),(string)($d['contexto']['user_agent']??$_SERVER['HTTP_USER_AGENT']??''));
        if(($a['automacao']??'nao_identificada')!=='nao_identificada'||!empty($d['automacao'])&&$d['automacao']!=='nao_identificada'){return [];}
        $cons=F3Base_Contato_Apresentacao::consentimento($d);if(empty($d['consentimento_snapshot']['publicidade'])||empty($cons['publicidade'])){return [];}
        $out=[];$email=strtolower(trim((string)($lead['email']??$d['email']??'')));
        if(is_email($email)){$out['em']=hash('sha256',$email);}
        $country=(string)($d['telefone_normalizacao']['pais']??F3Base_Options::ler('f3base_pipedrive')['pais_telefone']??'BR');
        $phone=F3Base_Pipedrive_Api::telefone((string)($d['telefone']??''),$country);
        if($phone!==''&&!F3Base_Telefone::nao_normalizado($d)&&preg_match('/^\+[1-9][0-9]{6,14}$/D',$phone)){$out['ph']=hash('sha256',substr($phone,1));}
        return $out;
    }
}
