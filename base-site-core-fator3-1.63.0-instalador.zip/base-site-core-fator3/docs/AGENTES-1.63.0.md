# Guia de agentes — Core 1.63.0

Leia DOCUMENTACAO.md e RELEASE-1.63.0.md; contrato 8.28.0. Descubra schemas e revisões antes de escrever. Faça simulação e preserve CAS. Somente administradores acessam configuração, conta, contatos e desempenho. Não use leitura de documentação como prova de entrega a fornecedor.

Diagnostique alertas por f3base/saude-ler, histórico da caixa e política f3base_avisos_tecnicos. Não reduza limiares para fabricar falha em produção. Observe os marcos robots_retomada e a entrega HTTP após uma passagem do cron. Não substitua robots.txt de terceiro manualmente.

Para desempenho, compare três amostras sem cache em / e /wp-login.php; registre o menor generation_ms com/sem Core, mantendo acompanhantes e tema. Restaure a ativação e verifique robots após o teste. O diagnóstico próprio não desativa plugins.

A compilação de bootstrap-hooks.php é reproduzível por build/bootstrap-methods.php em WordPress descartável; autoload-map.php por build/autoload.py. Alterações em iniciar() exigem recompilação. Não editar os gerados manualmente. A ausência de módulo sob demanda no array de classes já carregadas não significa indisponibilidade: use class_exists com autoload ou o catálogo público.

MCP 0.37.0, Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0, Pipedrive 0.5.0: contratos dos acompanhantes preservados. Pipedrive exige PHP 8.3.36 para ativação; o mínimo próprio do Core é PHP 8.3.6/WordPress 7.1.2. Fonte e instalador são artefatos distintos; somente o instalador é enviado ao WordPress.
