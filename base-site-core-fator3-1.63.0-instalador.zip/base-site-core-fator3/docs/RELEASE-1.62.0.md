# Fator3 Site Core 1.62.0

Contrato administrativo **8.27.0**, base direta **1.61.1**. Pedidos 348–351 de 29/10/2026. Piso preservado: WordPress 7.1.2 e PHP 8.3.6, instalação única de 64 bits.

## Comportamento entregue

| Pedido | Resultado |
| --- | --- |
| 348 | Marca usa somente variacoes/domínios; nome é rótulo. Sobreposição pertence à variação mais longa, com empate pela ordem da configuração. Ignora caixa, distingue acentos, exige fronteiras de letras/números/marcas Unicode. Domínio mais específico vence. Permissões são aplicadas após resolver a sobreposição. |
| 349 | Novas capturas Meta Ads podem completar conta ausente pela seleção Core e nome ausente pelo campaign_name concedido. Política configurável, simulável e registrada no contato. URL e mapas explícitos prevalecem. O recibo Pipedrive registra a fonte do campo Campanha. |
| 350 | canal_codigo expõe o valor da chave nas saídas públicas. chave continua no armazenamento e na resposta por compatibilidade, podendo ser redigida pelo MCP. canal_chave também é redigido pelo filtro do MCP 0.37.0, portanto não foi escolhido. |
| 351 | Perfil piso-padrao-3.6 mantém ID, passa a esperar no mínimo 120 meses por padrão e recebe revisão derivada da configuração. Piso configurável sem modificar guarda real. |

## Dependências e operação

Google **0.24.0** e Meta **0.16.0** recebidos mantêm os contratos de runtime de 0.23.0/0.15.0. Mantidos MCP **0.37.0**, LinkedIn **0.13.0**, Pipedrive **0.4.0**. O Pipedrive acompanhante tem piso próprio PHP 8.3.36; não ativá-lo no mínimo PHP do Core. Não aplicar patches de integração antigos dos produtores.

O leitor Meta usa meta-ads-reader/1.0.0 com seleção e concessão explícitas. A conta pode ser completada pela seleção ativa mesmo sem concessão de acervo; o nome exige concessão válida. Sem produtor, concessão, campanha exata ou leitura conclusiva, o contato continua sendo recebido e o nome permanece ausente com motivo. Nenhuma chamada à Graph API é feita para resolver nomes.

Não regrava contatos históricos, mensagens ou journal. Não reduz retenções operacionais. Não altera produtores ou publica em frota. Há aviso de validação coordenada ao Implantador sobre a revisão efetiva do perfil. Provas, hashes, implantação e limites de aceite estão no relatório externo; este guia não declara aceite de negócio em produção.

Leia CAMPANHAS-MARCAS-PERFIL-1.62.md e AGENTES-1.62.0.md. Documentos anteriores permanecem válidos nos assuntos não alterados.
