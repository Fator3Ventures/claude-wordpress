# Marcas, origem de campanhas, canal e perfil — 1.62

## Marcas vigiadas (348)

Em f3base_marcas_vigiadas, nome é rótulo; variacoes são as únicas formas textuais buscadas. A busca ignora caixa, distingue acentos e exige limites Unicode de letras, números e marcas combinantes. Cada intervalo sobreposto pertence à forma mais longa; empate usa a ordem das marcas. Domínios casam host exato ou subdomínio; o mais específico vence. Exceções de caminho/superfície são aplicadas à marca vencedora, sem transferir o trecho à marca curta.

Exemplo: configure Grupo Fator3, Fator3 Ventures, Fator3 Tech e CTO Office nas respectivas variacoes. O texto do rodapé com as quatro formas produz uma menção para cada marca; Fator3 não ganha ocorrências dentro das formas maiores. nome=Fator3 com variacoes=[Fator3 Tech] não busca Fator3 Ventures. Texto visível e destino de link são evidências distintas. JSON-LD aplica o mesmo critério. HTML sem JavaScript; limites de 200 ocorrências e 15 mil nós, com estado parcial explícito.

Fotografias da versão anterior ficam sem validade para o resumo até o worker produzir algoritmo variacoes-longas/2. Leitura não dispara HTTP nem regrava a fotografia.

## Conta e nome de campanha (349)

Opção f3base_campanhas_origem:

```json
{"conta_meta_configurada":true,"nome_acervo_meta":true,"janela_acervo_dias":30}
```

As fontes são independentes. janela_acervo_dias aceita 1–366. Alterações usam config-core-escrever com revisao_esperada e simulação padrão. A simulação funcional é f3base/campanhas-origem-simular com parametros e configuracao candidata opcional, exige administração e leitura de contatos, não grava contato e não chama fornecedor.

```json
{"parametros":{"utm_source":"ig","utm_medium":"paid","utm_campaign":"123456","utm_id":"123456"},"configuracao":{"conta_meta_configurada":true,"nome_acervo_meta":true,"janela_acervo_dias":30}}
```

Regras: plataforma meta_ads sem conflito e ID de campanha numérico; preserva conta explícita. Se faltar conta e houver seleção ativa em f3base_meta_ads, grava conta_id/f3_ads_account_id e conta_fonte=conta_da_configuracao. Reavalia mapa explícito por plataforma/conta/campanha. Nome humano da URL e mapas têm precedência. Faltando nome e com concessão válida, consulta somente o histórico local campaign-level da conta/campanha exatas; usa campaign_name não numérico/não macro da observação com nome mais recente dentro da janela. Não deriva nome de anúncio, e-mail ou data; o dia apenas delimita e ordena observações reais.

Leitura completa limitada a 10 páginas de 100 linhas e 2 segundos por toque. Nome divergente no mesmo dia, paginação não concluída, revisão/concessão alterada ou SDK inválido não produzem escolha arbitrária. Não usa last_available_fields como valor atual. A prova inclui dia, linha, geração, revisão da concessão/consumidor, seleção Meta e hash da política. Ausência/limite é registrada com código, sem bloquear a captura. A janela termina no dia UTC da captura; o vínculo no relatório usa o fuso da conta Meta.

Enriquece apenas novas capturas aceitas, não importadas, não e-mail/contato externo, com publicidade permitida segundo a política já existente do Core. Principal e sessao_origem recebem fontes; primeiro_toque/ultimo_toque permanecem históricos. Salva dados.campanha_resolucao e nome_campanha_fonte=acervo_meta_ads. O hash de idempotência permanece baseado na entrada antes do enriquecimento. A opção não concede acesso nem altera a política de publicidade.

O contato novo com conta persistida participa de relacao_core.contatos; antigos sem conta continuam fora, sem reclassificação automática. A prévia Pipedrive mostra campanha_resolucao. O journal alternativas_recibo.campanha guarda fonte, conta_fonte, resolução, campo e hash do valor pretendido. intencao_enviada não prova aceite: a conferência posterior mantém seu próprio estado. Campo Campanha precisa estar mapeado e confirmado no catálogo CRM, como antes.

## Canal legível (350)

canal_codigo é um alias de apresentação para chave. Aparece em resultado do simulador, gravada/simulada de contatos_30_dias e estruturas canal_crm nas abilities Core, inclusive registros e prévia Pipedrive. As regras e os dados armazenados não são migrados. O campo não reduz a guarda de segredos do MCP; canal_chave seria redigido pelo mesmo filtro.

## Piso de retenção (351)

O ID piso-padrao-3.6 continua válido e contém 92 condições. P02/P03/P10/P51/P81–P92 usam no_minimo, piso padrão 120, respeitando o máximo do schema operacional. f3base_perfil_retencoes aceita {"meses":120}, de 1 a 120. Comparação não aceita zero como retenção infinita nesses campos. Mudar o piso não altera qualquer option operacional de retenção.

```json
{"perfil_id":"piso-padrao-3.6","retencoes_candidatas":{"meses":60},"contexto":{"regime_whatsapp":true},"somente_divergencias":false}
```

A candidata é apenas simulação. A revisão pública é 2026-10-29-core-1.62.0 seguida de hash da configuração; não fixar a revisão estática do JSON. perfil_revisao antiga falha explicitamente. Planos e exceções antigos devem ser reavaliados. A avaliação continua distinguindo retenção, demais divergências e evidências indeterminadas. Perfil completo não significa site conforme.
