# Fator3 Site Core 1.63.0

Contrato administrativo 8.28.0, aditivo. Atualização direta da 1.62.0 e instalação limpa. Compatibilidade examinada: MCP 0.37.0, Google 0.24.0, Meta 0.17.0, LinkedIn 0.13.0, Pipedrive 0.5.0. A prova executada e seus limites constam do relatório externo.

## Pedidos 352–356

- 352: consentimento, contexto e tracking no head; PageView Meta iniciado assim que a política local permite, sem esperar contexto-publico ou DOMContentLoaded. Editor é excluído no servidor. Cookie de teste, marca de cabeçalho e webdriver são verificados antes do Pixel. O PageView conserva eventID para deduplicação. Lead e demais conversões continuam dependentes da classificação e do consentimento. Google mantém suas guardas e a política de carga configurada.
- 352: observação inicial efêmera de tempo visível, profundidade e gestos, com até 200 amostras de rolagem em memória. Não cria identificação, storage ou envio durante a classificação. A fila é incorporada apenas após classificação e consentimento; exclusão/negativa a descarta. Eventos próprios conservam o instante original e página usa ms=0 relativo à navegação. Os gestos anteriores à classificação impedem falso salto na reprodução da rolagem. Tempo visível inicial entra no evento de saída; tempo ativo por seção começa quando seu DOM está disponível e o coletor é autorizado.
- 353: resposta IMAP incompleta só abre incidente após 3 passagens consecutivas OU 20 minutos sem leitura completa, por padrão. Uma passagem incompleta seguida de leitura completa não envia abertura/recuperação. Outros erros preservam a regra anterior. Estado guarda as últimas 20 ocorrências, horário/código e revisão da política. Uma recuperação só avisa quando a abertura foi aceita pelo wp_mail. Isso não comprova entrega ao destinatário.
- 354: mapa fechado de classes sob demanda e registros de hooks compilados do código próprio. Implementações administrativas, handlers e integrações são carregados quando usados. Login e contexto-publico usam inicialização mínima; se outro plugin consultar habilidades, a inicialização completa precede o registro de categorias. O registro de hooks usa elegibilidade leve, separada do diagnóstico de saúde. Catálogo completo conserva filtros/sanitização/contratos. f3base/desempenho-ler e GET /f3base/v1/desempenho exigem manage_options e medem carga, registro e callbacks dos módulos. A sondagem interna opcional é assinada, limitada à página inicial/login e não altera ativação ou configuração.
- 355: ativação de instalação existente e troca de versão retomam robots.txt na primeira passagem do job. Há marcos de suspensão, retomada e confirmação em f3base/saude-ler. Falha gera um aviso técnico reservado por ciclo. Preserva arquivos de terceiros e a política de geração desligada. Configuração ligada é verificada pela resposta HTTP; agendamento não é prova de publicação.
- 356: correspondência manual configurável pelo booleano f3base_meta_correspondencia (padrão true). Somente contato de formulário aceito, classificado, sem teste/editor/automação e com publicidade permitida recebe hashes SHA-256 em conversao.meta_correspondencia. E-mail normalizado em minúsculas/trim; telefone normalizado com país e somente dígitos antes do hash. Identidade inválida é omitida. O navegador reaplica fbq('init', pixel, {em,ph}) antes de Lead com o mesmo eventID. A resposta contém hashes, nunca PII para este recurso; não grava esses hashes em HTML/localStorage/sessionStorage. Correspondência automática permanece desativada pela configuração vigente do Pixel.

## Configuração e operação

Em f3base_avisos_tecnicos: imap_falhas_consecutivas (inteiro 1–100, padrão 3) e imap_sem_leitura_minutos (inteiro 1–1440, padrão 20). Ambas aceitam simulação pelo canal administrativo existente, com revisão esperada. Valores antigos recebem os padrões sem apagar o destino técnico. O booleano f3base_meta_correspondencia usa a mesma leitura, simulação e escrita com CAS.

Exemplo de diagnóstico: `f3base/desempenho-ler {"contexto":"pagina","amostras":3}`; contextos atual, pagina, login; amostras 1–3. total_ms inclui filhos; proprio_ms evita dupla soma. A medição termina no footer, não inclui transporte nem callbacks posteriores. Não equivale a LCP ou entrega de anúncios. Rota REST exige autenticação administrativa (nonce para cookie, como nas demais rotas).

## Banco e reversão

Sem tabela ou coluna nova. Campos aditivos em estado interno da caixa/robots. Filas, contatos, credenciais e configurações são preservados. Reversão do código para 1.62.0 preserva esses campos, mas restaura o comportamento antigo de carga/avisos/retomada. Não restaurar banco para reverter este incremento. Não repetir operações comerciais para provar a atualização.

## Aceites externos

O recebimento efetivo da correspondência pela Meta, PageView mediano menor que 1000 ms em korvena/mvp, contexto antes do LCP e observação de sete dias pertencem à homologação da frota em ativos autorizados. Fixture não substitui aceite do fornecedor. Lead sintético para homologação comercial é diferente da marca técnica f3base_teste, que continua suprimindo Meta. Nenhum evento comercial real é necessário no Site-Teste.
