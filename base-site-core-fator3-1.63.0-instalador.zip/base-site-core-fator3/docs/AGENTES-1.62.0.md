# Operação por agentes — Core 1.62.0

Leia DOCUMENTACAO.md via f3base/documentacao-ler; percorra proxima_linha até null e confira SHA-256. Contrato administrativo 8.27.0, base 1.61.1. Notas 1.62 prevalecem apenas nos pedidos 348–351.

1. Confira opções/schema/revisões antes de escrever. As opções f3base_campanhas_origem e f3base_perfil_retencoes são operáveis com simulação e guarda de revisão. Não conceda acesso Meta implicitamente.
2. Simule a URL real em campanhas-origem-simular. Confira conta_fonte, nome_campanha_fonte e prova. Se nome ausente, verifique motivo/concessão/campanha; não invente nomes por anúncio/data/e-mail.
3. Confira canal_codigo no simulador, contatos e prévia. A chave interna e o mapa CRM continuam idênticos. Mantenha a política do MCP.
4. Leia o perfil vigente e sua revisão efetiva. Nunca reduza retenção operacional para fazer passar um perfil antigo. Simule retencoes_candidatas antes de mudar o piso; revalide planos do Implantador e exceções com a nova revisão.
5. Aceite em produção dos pedidos depende da frota: novo contato Meta com conta/nome no CRM e relatório; marcas nas URLs citadas; canal legível; ausência de divergência de retenção. O relatório do pacote separa prova sintética de aceite real.

Não reconstrua dados históricos para preencher fontes. Não reenvie eventos incertos nem mensagens. Testes de fornecedores devem usar as contas/sites expressamente autorizados. Site-Teste permite provas técnicas isoladas; não serve como conta comercial de Pipedrive.
