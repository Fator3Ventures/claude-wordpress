<?php
/**
 * Plugin Name:       Fator3 Site Core
 * Plugin URI:        https://github.com/Fator3Ventures/claude-wordpress
 * Description:       Núcleo dos sites Fator3: medição de visitas, robôs e assistentes de IA; contatos e formulários; consentimento; dados estruturados, /llms.txt, robots.txt, cabeçalhos e redirects; integrações opcionais com Pipedrive, Meta, Google, LinkedIn e Clarity. Requer PHP de 64 bits e instalação única (sem multisite).
 * Version:           1.63.0
 * Requires at least: 7.1.2
 * Requires PHP:      8.3.6
 * Author:            Fator3
 * Author URI:        https://www.fator3.com.br
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       f3base
 * Update URI:        https://fator3.com.br/plugins/base-site-core-fator3
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Referência de implantação: instalação nova ou atualização da 1.62.0. */

/*
 * Identidade e caminhos. Constantes definidas antes de qualquer require: as classes
 * do plugin as consomem no carregamento e o guard de PHP abaixo precisa da versão
 * para nomear o próprio motivo.
 *
 * A VERSÃO SAI DO CABEÇALHO, NUNCA DE UM LITERAL AO LADO DELE. O defeito era
 * medido e estava aqui: o cabeçalho dizia `Version: 1.3.6` e esta constante
 * dizia `'1.3.5'`. Ninguém acusava, porque as duas são verdadeiras isoladamente
 * — e quem lê a constante (a tela, o parâmetro de versão dos assets publicados)
 * carimbava um número que o WordPress não mostra em lugar nenhum. É a mesma
 * regra que o tema já cumpre com o cabeçalho do `style.css`: o contrato é o
 * cabeçalho que o código lê, e constante que repete o número sai de sincronia
 * na primeira release em que alguém esquece de mexer nos dois.
 *
 * `get_file_data()` mora em `wp-includes/functions.php`, carregado antes de
 * qualquer plugin: ela está disponível aqui e não exige `wp-admin`.
 *
 * `UPDATE URI: FALSE` NO CABEÇALHO, e ele é a linha mais barata deste arquivo.
 * Sem ela, o atualizador do wordpress.org confere o SLUG da pasta contra o
 * diretório público a cada verificação de atualização: qualquer plugin
 * publicado lá com o slug `base-site-core-fator3` passaria a ser oferecido — e,
 * com atualização automática ligada, INSTALADO — por cima deste. O valor
 * `false` é o que a documentação do núcleo declara para "nenhum servidor de
 * atualização", e ele desliga a consulta inteira.
 */

/**
 * O CABEÇALHO DESTE ARQUIVO, lido UMA VEZ por processo.
 *
 * O DEFEITO MEDIDO era de custo, não de correção: `get_file_data()` abre o
 * arquivo, lê 8 KiB e roda uma expressão regular por campo pedido, e a chamada
 * acontecia em TODA requisição do site — inclusive nas do beacon de
 * comportamento, que é a rota mais chamada do pacote. O valor não muda dentro
 * de um processo: o arquivo que ele lê é o arquivo que está executando.
 *
 * Memoizado em `static`, e não numa constante a mais: a constante já existe e é
 * `F3BASE_PLUGIN_VERSAO`. O que esta função guarda é a LEITURA, para que um
 * campo novo do cabeçalho não custe uma segunda abertura do arquivo.
 *
 * @return array<string,string> Campos declarados do cabeçalho.
 */
function f3base_site_core_cabecalho(): array {
	static $cabecalho = null;

	if ( null === $cabecalho ) {
		$cabecalho = get_file_data(
			__FILE__,
			array(
				'versao'     => 'Version',
				'php_minimo' => 'Requires PHP',
				'nome'       => 'Plugin Name',
			),
			'plugin'
		);
	}

	return array_map( 'strval', (array) $cabecalho );
}

if ( ! defined( 'F3BASE_PLUGIN_VERSAO' ) ) {
	define(
		'F3BASE_PLUGIN_VERSAO',
		(string) ( f3base_site_core_cabecalho()['versao'] ?? '' )
	);
}
if ( ! defined( 'F3BASE_PLUGIN_PHP_MINIMO' ) ) {
	/* O MÍNIMO SAI DO MESMO CABEÇALHO, pelo mesmo motivo da versão: o número que
	 * o WordPress mostra e usa para barrar a instalação é o do cabeçalho, e um
	 * literal ao lado dele sai de sincronia na primeira release em que alguém
	 * mexer em só um dos dois. O `?:` é a posição segura de um cabeçalho ilegível
	 * — sem mínimo declarado, o guard abaixo não tem contra o que comparar. */
	define( 'F3BASE_PLUGIN_PHP_MINIMO', (string) ( f3base_site_core_cabecalho()['php_minimo'] ?: '8.3.6' ) );
}
if ( ! defined( 'F3BASE_PREFIXO' ) ) {
	define( 'F3BASE_PREFIXO', 'f3base' );
}
if ( ! defined( 'F3BASE_TEXT_DOMAIN' ) ) {
	/*
	 * O TEXT DOMAIN EXISTE E O CARREGADOR NÃO, e a decisão é declarada aqui.
	 *
	 * O DEFEITO MEDIDO: o cabeçalho trazia `Domain Path: /languages` e a
	 * ativação chamava `load_plugin_textdomain()` apontando para essa pasta — e a
	 * pasta NÃO EXISTE no zip. Um caminho de tradução que não existe não falha e
	 * não avisa: ele faz o núcleo procurar arquivo em disco a cada carregamento e
	 * não achar nada, para sempre.
	 *
	 * DAS DUAS SAÍDAS — criar a pasta com um `.pot` gerado, ou tirar as duas
	 * linhas —, ESTE PACOTE É MONOLÍNGUE e escolhe a segunda. Toda string dele é
	 * escrita em português para quem opera o site, e um `.pot` sem nenhuma
	 * tradução é um arquivo que declara um processo de tradução que ninguém
	 * mantém. O domínio `f3base` continua declarado no cabeçalho e nas chamadas
	 * de `__()`, e é ele que um site que QUISER traduzir usa por
	 * `load_plugin_textdomain()` próprio ou pelo `.mo` de
	 * `wp-content/languages/plugins/` — que é o caminho que o núcleo carrega
	 * sozinho, sem `Domain Path` nenhum, desde a 4.6.
	 */
	define( 'F3BASE_TEXT_DOMAIN', 'f3base' );
}
if ( ! defined( 'F3BASE_REST_NAMESPACE' ) ) {
	define( 'F3BASE_REST_NAMESPACE', 'f3base/v1' );
}
if ( ! defined( 'F3BASE_PLUGIN_ARQUIVO' ) ) {
	define( 'F3BASE_PLUGIN_ARQUIVO', __FILE__ );
}
if ( ! defined( 'F3BASE_PLUGIN_DIR' ) ) {
	define( 'F3BASE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'F3BASE_PLUGIN_URL' ) ) {
	define( 'F3BASE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Guard de versão de PHP.
 *
 * `version_compare()` aqui usa `<`, operador da lista permitida pelo contrato
 * (`< lt <= le > gt >= ge == = eq != <> ne`).
 *
 * @return bool Verdadeiro quando o PHP em execução atende ao mínimo declarado.
 */
function f3base_site_core_php_suportado(): bool {
	return ! version_compare( PHP_VERSION, F3BASE_PLUGIN_PHP_MINIMO, '<' );
}

if ( ! f3base_site_core_php_suportado() ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html(
					sprintf(
						/* translators: 1: versão mínima de PHP exigida, 2: versão de PHP em execução. */
						__( 'Fator3 Site Core exige PHP %1$s ou superior. Este servidor executa PHP %2$s: o plugin ficou inerte e nenhum hook foi registrado.', 'f3base' ),
						F3BASE_PLUGIN_PHP_MINIMO,
						PHP_VERSION
					)
				)
			);
		}
	);

	return;
}

/** Registra o mapa de classes. O mesmo carregador atende runtime e uninstall. */
function f3base_site_core_carregar(): void {
    static $registered=false;if($registered){return;}$registered=true;
    $map=require __DIR__.'/includes/autoload-map.php';
    spl_autoload_register(static function(string $class)use($map):void{
        if(isset($map[$class])){F3Base_Desempenho::medir($class,'carga',static function()use($map,$class){require_once F3BASE_PLUGIN_DIR.$map[$class];});}
    });
}

require_once __DIR__.'/includes/class-f3base-desempenho.php';
F3Base_Desempenho::iniciar();
f3base_site_core_carregar();

/*
 * O BOOTSTRAP NÃO ACONTECE NA DESINSTALAÇÃO, e é ele que faz `uninstall.php`
 * poder carregar este arquivo inteiro.
 *
 * O DEFEITO MEDIDO, num WordPress real: `uninstall.php` fazia `require_once` de
 * `class-f3base-options.php` e MAIS NADA, e o catálogo daquela classe cita
 * `F3Base_Vocabulario` e `F3Base_Llms` nos padrões. O processo da desinstalação
 * morria em `Class "F3Base_Vocabulario" not found`, o WordPress mostrava "erro
 * crítico", e NADA do que a desinstalação promete limpar era limpo — a tabela do
 * registro detalhado, com apelido, sessão e carimbo, sobrevivia ao apagamento do
 * plugin. Manter uma segunda lista de `require` dentro do `uninstall.php` só
 * adiaria o mesmo defeito para o dia em que um padrão do catálogo citasse uma
 * classe a mais.
 *
 * A saída é esta: a lista de arquivos é UMA, mora em `f3base_site_core_carregar()`
 * logo acima, e o `uninstall.php` carrega ESTE arquivo. O que ele NÃO pode
 * herdar é o registro de hooks — a desinstalação roda com o plugin inativo e
 * registrar `init`, `admin_notices` e as duas telas ali seria ressuscitar o
 * plugin no processo que existe para apagá-lo. `WP_UNINSTALL_PLUGIN` é definida
 * pelo núcleo antes de incluir o arquivo, e é ela que separa os dois usos.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	register_activation_hook( __FILE__, array( 'F3Base_Site_Core', 'ativar' ) );
	register_deactivation_hook( __FILE__, array( 'F3Base_Site_Core', 'desativar' ) );

	add_action('f3_linkedin_register_consumers',array(F3Base_Linkedin_Cliente::class,'registrar'),20,1);
	add_action('f3_mcp_google_register_consumers', array(F3Base_Gsc::class,'descobrir'), 10, 2);
    add_action('f3_mcp_google_register_consumers', array(F3Base_Ga4::class,'descobrir'), 10, 2);
    add_action('f3_mcp_google_register_consumers',[F3Base_Gsc_Consultas::class,'descobrir'],10,2);
    add_action('f3_mcp_google_register_ads_consumers',[F3Base_Google_Acervo::class,'descobrir'],10,2);
    add_action('f3_meta_register_monitoring_consumers',[F3Base_Meta_Monitoramento::class,'descobrir'],10,2);
    add_action('f3_meta_register_ads_consumers', array(F3Base_Meta_Ads::class,'descobrir'), 10, 2);
	F3Base_Pipedrive_Operacao::iniciar();
	F3Base_Desempenho::medir('F3Base_Site_Core','registro',static fn()=>F3Base_Site_Core::iniciar());
}

/** API optativa de apresentação; não altera post_author. */
function f3base_autor_exibido( int $post_id ): string {
	return F3Base_Autoria::nome( $post_id ); }

// Adesão explícita. O canal nunca substitui as permissões nativas do Core.
add_action('f3_mcp_register_providers', static function ($contract) {
    if ($contract === 1 && F3Base_Companheiros::mcp()['compativel'] && class_exists('Fator3\\McpFiles\\ExtensionContract')) {
        try { \Fator3\McpFiles\ExtensionContract::register('base-site-core-fator3', F3BASE_PLUGIN_VERSAO, array('f3base/')); } catch (Throwable $e) { error_log('F3BASE contrato_mcp_registro_indisponivel'); }
    }
});

