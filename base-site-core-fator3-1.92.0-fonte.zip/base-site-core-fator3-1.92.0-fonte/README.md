# Fonte do Fator3 Site Core 1.92.0

Runtime em work/plugin/base-site-core-fator3. Instalação nova ou atualização da 1.91.0; WordPress 7.1.4+ e PHP 8.3+ de 64 bits. Normas comuns revisão 5 (02/11/2026). Pedidos 426/427 em reference/pedidos-1920.md; pacotes e fechamento dos impactos anteriores em reference/1920-companions.

## Reprodução

```sh
python3 build/gerar-catalogo-aparelhos.py
python3 build/gerar-google-play.py --data 2026-11-15
python3 tests/google-play-integridade.py
F3BASE_PHP=/caminho/php python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.92.0-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.92.0-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.92.0-fonte.zip
```

Evidências desta versão em evidence/1920. Testes nativos em tests/192 exigem WordPress real descartável, WP_ENVIRONMENT_TYPE=local e banco core192_*. A base original UTF-16 do Google Play está em reference/417; fichas e auditorias novas em reference/427. Os 30 códigos anteriores ficam em reference/419/codigos-frota.json. CSVs são referências internas do fonte.

Ensaios e evidências 1910 e anteriores são históricos. Os ativos JavaScript não mudam nesta rodada. Não há dependências instaladas, segredos, banco de laboratório ou ZIP aninhado no fonte. O relatório externo detalha validação e aceite pendente de 24 horas.
