# WP MCP Fator3 0.14.0 — guia e relatório da entrega

Data: 01/10/2026. Referência: plano 0.14.0, revisão 2, com 33 itens ativos (1–15 e 17–34). Item 16 retirado; não existe item 35.

**Esta entrega contém código, instaladores, fontes, testes e documentação para homologação. O gate de publicação está aberto: não é apresentada como versão estável homologada.** A versão 0.14.0 identifica uma única entrega funcional; não foram publicadas versões intermediárias nem executadas mudanças na frota.

## O que acompanha a entrega

| Arquivo | Uso |
| --- | --- |
| `wp-mcp-fator3-0.14.0.nao-homologado.zip` | Instalação do MCP completo em ambiente de homologação. Mantém pasta e entrypoint do canal. |
| `wp-mcp-fator3-migrator-0.14.0.nao-homologado.zip` | Componente temporário e independente para substituir o canal antigo com pré-imagem e recuperação. Não é outra versão intermediária do MCP. |
| `wp-mcp-fator3-fonte-0.14.0.zip` | Runtime, documentação, testes, ferramentas e fixtures dos complementos atuais. Não instalar este ZIP no WordPress. |
| `packages.json` e manifestos | Identidade, inventário e SHA-256 dos dois instaladores. URLs `.invalid` são modelos não publicados. |
| `OPERACAO.md` | Manual do contrato efetivo, também gerado como ajuda PHP protegida. |
| `CONTRATOS-INSTALADOS.json` | Schemas extraídos do registro real de habilidades do WordPress. |

Core 1.18.0 e Google 0.5.0 foram usados como fixtures de integração. Esta entrega não troca nem publica esses complementos. Não instale versões antigas de Core/Google para acompanhar o MCP.

## Conexão e compatibilidade

A URL principal continua `https://SEU-SITE/wp-json/mcp/wp-mcp-fator3`. A URL `https://SEU-SITE/wp-json/mcp/wp-mcp-ultimate` permanece como alias do mesmo servidor. Nas instalações sem permalink, a forma `https://SEU-SITE/?rest_route=/mcp/wp-mcp-fator3` também é válida.

Os conectores existentes não precisam ser recriados por causa do endereço. Uma sessão antiga sem registro confiável da revisão MCP negociada recebe HTTP 404 para reinicialização, sem revogar a credencial. O armazenamento e o servidor próprios do Elementor são preservados.

As três ferramentas de descoberta, informação e execução continuam sendo a interface principal. O catálogo oferece habilidades conforme a política e as permissões reais; autorização dependente de parâmetros é indicada como `requires_input`. Não é preciso expor cada habilidade como uma ferramenta separada.

## Mudanças desta versão

| Área | Mudança |
| --- | --- |
| Perfil Manutenção | Administração plena dentro das capacidades WordPress, permissões PHP/SO e bloqueios globais. Remove requisitos redundantes por conexão para raízes, SQL e exportação. |
| Migração de política | Credenciais válidas herdadas e Legado automático passam a Manutenção sem prazo de política. Escolhas explícitas e revogações são preservadas; TTL de token não é estendido. |
| OAuth | Escopos múltiplos normalizados, consentimento de perfil, herança de política no refresh legado e independência do novo grant. |
| Erros e catálogo | Códigos/dados estruturados preservados no transporte, segredos redigidos, descoberta e informação com a mesma elegibilidade. Versão de provedor identificada quando conhecida. |
| SQL de leitura | Consultas nativas com agregações, CTE, janelas, funções JSON/data, JOIN/UNION/subconsultas; sem o defeito de espaços entre função e parêntese. |
| Exportação de consulta | Snapshot imutável completo em CSV/JSONL, gzip opcional, execução assíncrona, consulta de estado, cancelamento e download em partes com hashes. |
| Administração SQL | DDL e DML complexo em duas fases, lote DML InnoDB, dump/restore com views/triggers e troca serializada com filtros de tabela/coluna. |
| Recuperação de banco | Controlador independente em mu-plugins, diário privado, preservação do estado operacional MCP e recuperação de restauração abandonada. wp_options permanece disponível durante a troca. |
| Administração WordPress | Endereço, e-mail, idioma, papéis, options com readback, cron, transients e cache de objeto. |
| Temas e arquivos | Upload/update/delete/rollback de temas, ativação protegida, ZIP de árvores e limite de arquivo configurável; transferência de 20 MiB em partes. |
| Conexões e ajustes | Listar, alterar e revogar identidade exata; revisão de política; confirmação forte para autorrestrição; configurar limite/feed/estado geral. |
| Documentação | Manual externo canônico e ajuda PHP autenticada. Markdown e catálogo bruto são retirados do instalador e os caminhos anteriores respondem 404. |
| Autoatualização | Invalidação também no processo PHP que atende HTTP; verificação da versão executada e recuperação de pacote novo com fatal. |

Também foram corrigidos, durante os testes, o tratamento de literais binários no dump SQL, o modo SQL da conexão independente de recuperação, a atualização do nome de papéis, a representação nativa de en_US e o acompanhamento durável de operações cron/confirmações.

## O que já existia e foi preservado

A base 0.13.0 já continha locks/CAS em arquivos, `files/move`/`copy`, busca `grep_regex` em arquivo único, binários/base64, gzip/offset/cursor, parte da seleção SQL JOIN/IN, retenção de backups legados, limpeza exata de auto-update e de uninstall órfão, patches com revisão/readback, proteção de filhos de blocos, recursos Elementor com metadados aninhados, mídia/ícone, sondas e recuperação de pacotes.

Essas funções são regressões preservadas. Não são contabilizadas como novas apenas porque aparecem no catálogo 0.14.0. A ampliação de Manutenção substitui decisões restritivas anteriores; o administrador com arquivos, instalação de código e banco não é isolado de segredos por uma máscara em db/query.

## Migração pelo canal antigo

Faça a homologação no site de teste com backup externo habitual. Confira os SHA-256 em `packages.json` antes de transmitir os ZIPs. A sequência abaixo descreve o mecanismo implementado; o aceite com o cliente real continua necessário.

1. **Instale e ative o migrador** usando o `plugins/upload` ou `plugins/upload-base64` do canal antigo. O alvo é o plugin novo `wp-mcp-fator3-migrator`, não a pasta do MCP ativo. Na 0.12.1, não envie diretamente o novo MCP ao self-upload destrutivo dessa versão.
2. **Descubra `f3-migration/apply`** pelo executor existente. Leia Get Ability Info. Forneça exatamente uma origem (`url` HTTPS ou `content_base64`) e os campos `expected_sha256`, `expected_version:"0.14.0"` e `expected_current_version` com a versão realmente instalada.
3. **Examine a prévia.** Ela confere identidade fixa do plugin, versão, requisitos, estrutura do pacote e pré-imagem antes da troca. Guarde o `confirm_token`.
4. **Confirme com os mesmos parâmetros e o token.** O componente prepara a cópia anterior e o diário fora da pasta substituída, instala a árvore preparada e verifica a versão em nova requisição, as duas rotas, home e REST anônimos. Falha leva a tentativa de reversão com resultado explícito.
5. **Se a resposta se perder**, consulte `f3-migration/status` pelo `confirm_token` ou `operation_id`. Repetir a confirmação concluída retorna a mesma operação, sem executar outra instalação. Não interprete timeout como sucesso nem como autorização para repetir hooks.
6. **Reconecte/inicialize a sessão se houver 404**, preservando a credencial. Confira `system/capabilities`, catálogo, execução e `system/health` nas URLs principal e legada.
7. **Finalize com `f3-migration/finish`** e o `operation_id`, apenas depois de estado `complete`. O componente é desativado; as sentinelas e pré-imagens necessárias à recuperação permanecem.

A pasta final é `wp-mcp-fator3`; o entrypoint é `wp-mcp-fator3/wp-mcp-fator3.php`. Não há promessa de continuidade de todas as requisições em voo durante a substituição.

Para instalação nova, use apenas o instalador MCP. Para atualização de uma 0.14.0 já instalada, o próprio upload do canal usa staging/preload/recuperação. Não apague manualmente o acervo privado ou os mu-plugins de recuperação.

## Operação das novas funções

**Consultas grandes.** Use `db/query` para inspeção (até 2.000 linhas/16 MiB). Para o resultado completo, crie `db/query-export`, acompanhe `operations/status` e leia `db/export-part`. CSV/JSONL e gzip são formatos de transporte; o arquivo completo só é oferecido após finalizar. Cada parte e o arquivo têm hash. `db/query-page` atende JSONL sem gzip com cursor do snapshot materializado.

**Escrita de banco.** `db/execute`, `db/batch`, `db/restore` e `db/search-replace` continuam exigindo prévia e `confirm_token`, mesmo em Manutenção. O token vincula conexão, intenção e pré-imagem. DML em lote usa transação InnoDB; DDL tem commits implícitos e recuperação por cópia. `operations/plan` continua sem SQL.

**Backup e recuperação.** `db/export` produz SQL gzip privado com dados originais, inclusive segredos. `db/restore` verifica o artefato e cria a cópia anterior. Consulte `db/recovery-status` pelo ID do diário. Se a pós-imagem registrada de uma mutação mudou, a restauração recusa com `restore_destination_changed`; examine o estado antes de iniciar outra prévia com `allow_changed_destination:true`. A recuperação de processo abandonado tenta reverter a restauração, não continuar um snapshot perdido de consulta.

**Operações com efeito incerto.** `operations/status` aceita IDs de exportação, `cron:…`, `phase:…` e o `plan_id` dos planos existentes. `applied:null`/`operation_uncertain` exige reconciliação. Não há repetição automática de callbacks de negócio sem prova de conclusão.

**Arquivos grandes.** Ajuste `file_bytes` por `system/settings-update` em duas fases; transfira por `files/upload-create`, `files/upload-part` e `files/upload-finalize`. O ensaio de 20 MiB usa partes de 256 KiB. O limite por arquivo não altera limites de resposta, memória ou duração PHP.

**Temas.** Upload aceita URL/base64, hash e slug. Ativação usa tema instalado, prévia, backup, sonda e reversão. Atualização preserva seleção; exclusão recusa tema/pai em uso e dependentes. Rollback não desfaz migrações arbitrárias feitas pelo código do tema.

**WordPress.** `site/set-admin-email` dispensa o link de confirmação e verifica o valor; isso não prova entrega de e-mail. `site/set-language` instala tradução antes de mudar idioma. Papéis e endereços usam confirmação. A mudança de domínio verifica o destino, mas não cria DNS/TLS. Alterar `stylesheet` usa seleção nativa; `active_plugins` orienta para as habilidades de ativação, preservando hooks.

**Cron/cache.** Um evento é selecionado por hook, timestamp, argumentos e revisão. A execução usa contexto cron sem usuário logado, registra o solicitante e não aceita função PHP arbitrária. Callback concluído informa `business_result:unknown`. `system/cache-flush` limpa cache de objeto, não cache de página.

**Conexões.** Use ID exato e `expected_policy_version`. A autorrestrição exige confirmação. Revogar a identidade legada não revoga um grant independente já criado. Feed HTTPS e auto-update são decisões distintas: nenhum feed foi publicado nem auto-update ligado nesta entrega.

## Exemplos de chamadas

Os exemplos abaixo são os parâmetros de Execute Ability. Consulte primeiro Get Ability Info da instalação; o token de confirmação sempre vem da prévia real.

Exportar uma consulta, preservando o SQL original:

```json
{"ability_name":"db/query-export","parameters":{"sql":"SELECT 1 AS exemplo","format":"jsonl","gzip":false,"async":true}}
```

Consultar a identidade devolvida pela chamada:

```json
{"ability_name":"operations/status","parameters":{"operation_id":"ID_DEVOLVIDO"}}
```

Preparar a mudança do limite de arquivo para 32 MiB:

```json
{"ability_name":"system/settings-update","parameters":{"file_bytes":33554432}}
```

Confirmar o mesmo pedido depois de examinar a prévia:

```json
{"ability_name":"system/settings-update","parameters":{"file_bytes":33554432,"confirm_token":"TOKEN_DA_PREVIA"}}
```

Buscar o contrato de uma nova função:

```json
{"ability_name":"system/guide","parameters":{"ability":"db/restore"}}
```

## Limites e decisões explícitas

- Backups de arquivos/pacotes restauram árvores e estado de ativação observado. Não prometem desfazer efeitos externos, envio de mensagens ou migrações arbitrárias de plugins/temas.
- A prévia de SQL complexo é conservadora. Quando não há seleção exata comprovada, informa `selection_exact:false`/seleção de snapshot, sem inventar número de linhas afetadas. O snapshot pode cobrir mais tabelas do que a instrução modifica; o custo cresce com o banco.
- Dump completo recusa bancos com rotinas/eventos SQL não suportados. Views, triggers, binários, NULL e Unicode têm ensaio próprio. Não se rotula como completo um arquivo sem objetos necessários.
- Troca serializada não instancia objetos PHP. Objetos não suportados, tabelas sem chave e alterações em chave primária são apontados em `skipped`; devem ser examinados. Mudanças de chave usam SQL explícito.
- Exportação assíncrona precisa de loopback ou WP-Cron; não exige daemon novo. Snapshot cuja conexão morreu exige nova operação. Tempo/disco/memória continuam finitos.
- Locks protegem operações cooperantes do MCP. Escritores externos e efeitos de plugins continuam exigindo conferência. O padrão é `lock_wait_seconds:2`.
- Manutenção é administração plena; a redação de resposta não é proteção contra inferência por SQL arbitrário ou execução de código instalado pelo administrador.
- Nenhuma rotina desta atualização limpa automaticamente pendências da frota, como `angie_snippet`, registros uninstall, metadados ou backups.

## Validação e gates de publicação

Os JSONs em `evidencias/` registram asserções e resultados; `evidencias/invocations/` registra hash do runtime/pacotes e scripts de cada execução. Arquivos de teste herdados podem conservar `0130` no nome: a versão executada e o hash da invocação determinam a qual pacote a evidência se aplica. Tentativas que falharam durante desenvolvimento permanecem no histórico; a síntese final lista a última verificação por suíte.

Ambiente funcional: WordPress 7.1.2, PHP 8.3.30, MySQL 8.0.46, processos separados e HTTP com servidor de desenvolvimento PHP. Há testes de concorrência e SIGKILL reais, não apenas mocks. Isso não equivale a Apache/FPM, clientes externos ou homologação do Site-Teste.

Gates que continuam abertos:

1. Executar a suíte reproduzível em Apache/pool PHP e conferir OPcache nesse ambiente. Docker/Compose não estão disponíveis nesta sessão; a configuração é fornecida em `tools/acceptance`.
2. Exercitar filesystem efetivamente cheio. Falha controlada de escrita não é automaticamente prova de ENOSPC real.
3. Completar os casos de migração sob SIGKILL entre renames pelo componente migrador específico. A troca normal, candidata com fatal, bases reais e resposta perdida têm ensaio; o motor de recuperação possui testes próprios que não substituem toda essa matriz.
4. Conferir clientes efetivos, reinitialização de sessão, domínio/TLS, cache público, permissões e complementos no Site-Teste. Chamadas locais de status do Google não validam credenciais/APIs remotas.
5. Executar os aceites de negócio: templates/SEO/cache, escrita de banco em tamanho representativo, cron de complementos com efeito previsto, mudança de endereço e tradução baixada. O ensaio de en_US não comprova download de outro idioma.
6. Publicar manifestos em origem HTTPS real e verificar bytes antes de habilitar o feed, quando essa publicação for decidida.

A matriz a seguir é rastreabilidade de implementação e testes, não aceite da frota. Nenhum item é retirado da lista operacional apenas por constar neste relatório.

| ID | Implementação | Evidência local | Limite/aceite |
| --- | --- | --- | --- |
| 1 | Upload/backup/rollback de plugins | packages-functional.json; self-update-0130.json | Fatal e ativação conferidos; efeito de hooks externos tem limite explícito. |
| 2 | Canal de atualização próprio | providers-0130.json; packages.json | Configuração/validação implementadas; feed HTTPS ainda não publicado. |
| 3 | Sonda e health | advanced-0130.json; packages-functional.json | HTTP local; cache real da frota continua no piloto. |
| 4 | Patch com revisão, unicidade e readback | contracts-0130.json; advanced-0130.json | Não se atribui causa à perda de barra não reproduzida. |
| 5 | Catálogo condicional e projeção de plugins | extended-0130.json; release014-http.json | Cache e elegibilidade variam com a conexão. |
| 6 | Binário integral/base64 e recusa de texto | contracts-0130.json; extended-0130.json | Roundtrip e hashes em laboratório. |
| 7 | Rótulos/retensão e legados | retention-0130.json; recovery-0130.json | Seleção explícita; sem limpeza na instalação. |
| 8 | Contagem exata no schema | advanced-0130.json | Estimativa permanece distinta. |
| 9 | Regeneração/ícone | media-0130.json | Metadados, recortes e pré-imagem nativos. |
| 10 | Plano com upload | advanced-0130.json | SQL permanece fora de operations/plan. |
| 11 | Contratos pequenos, JOIN/IN e exclusão | recovery-0130.json; additional-0130.json; companions014-http.json | Aliases/versionamento/auto-update exato preservados. |
| 12 | Atualização preserva ativação | packages-functional.json | Fixture de pacote com sucesso/fatal; SEO/cache reais no piloto. |
| 13 | Offset arbitrário de bytes | extended-0130.json | Cursor opaco permanece compatível. |
| 14 | Regras de permalink | additional-0130.json | APIs nativas e flush soft. |
| 15 | Recursos Elementor e diagnóstico | third-party-0130.json; providers-0130.json | Sete recursos reais do Elementor 4.3.0 conferidos localmente; cliente/site real no piloto. |
| 17 | Bloco com filhos | additional-0130.json | Não descarta árvore silenciosamente. |
| 18 | Busca/privado/uninstall órfão | additional-0130.json | Sem limpeza automática de angie_snippet. |
| 19 | Redação de SQL | advanced-0130.json; release014-extended.json | Backup conserva original; Manutenção não tem garantia anti-inferência. |
| 20 | Sonda/reversão de PHP | recovery-0130.json; crash-0130.json; opcache-recovery-0130.json | Opt-out explícito conserva demais proteções. |
| 21 | Imagem destacada e revisão final | additional-0130.json | Yoast 28.5 real testado localmente; template/cache do piloto precisa de aceite próprio. |
| 22 | Projeção de revisões | additional-0130.json | Hash/CHAR_LENGTH e resposta legada preservados. |
| 23 | Getters/options/gzip | maintenance-0130.json; additional-0130.json | Projeções, null/ausente e limites declarados. |
| 24 | Exclusão tipada menu/options/meta | maintenance-0130.json; release014.json | confirm:true limitado às rotas admitidas. |
| 25 | Migração/OAuth/erros/catálogo | migration014-0.12.1.json; migration014-0.13.0.json; oauth-http-0130.json; release014-http.json | Normal/fatal/replay nas duas bases; SIGKILL do migrador ainda exige ensaio específico. |
| 26 | Manutenção e compatibilidade | release014-extended.json; companions014-http.json; self-update-0130.json | D+8, política explícita e grants independentes conferidos localmente. |
| 27 | Documentação autenticada | migration014-0.12.1.json; release014-http.json; documentation-0140.json | Caminhos antigos 404 e guia/hash acessível autenticado. |
| 28 | Agregações e diagnóstico | release014.json; release014-http.json | Consultas nativas preservadas; valores/exceções sensíveis omitidos. |
| 29 | Exportação consistente | release014.json; query014-concurrency.json; release014-extended.json | Mais de 2.000 linhas, partes, hashes, cancelamento, interrupção e expiração. |
| 30 | DDL/DML/lote/dump/replace | release014.json; release014-extended.json; database014-crash.json | Prévia complexa conservadora; limitações de objetos/efeitos documentadas. |
| 31 | Administração WordPress | release014.json; release014-extended.json | Papéis, e-mail e idioma padrão; domínio/TLS e download de tradução no piloto. |
| 32 | Cron/transients/cache | release014.json | Contexto e estado durável; backend externo de cache não declarado como testado. |
| 33 | Temas/ZIP/20 MiB | release014.json; release014-extended.json; zip-validation-0130.json | Ativação/fatal/rollback e transferência por partes; limites físicos permanecem. |
| 34 | Conexões e ajustes | release014.json; release014-extended.json | Revisão e autorrestrição; nenhuma revogação real na frota. |

## Reprodução e conferência

Use `tools/build_packages.py --review` para gerar ZIPs determinísticos do inventário permitido. O build normal exige `release-gate.json` aprovado para os mesmos bytes e uma origem HTTPS real; não remova esse gate para mudar apenas o rótulo.

`tools/check_package.py` confere inventário, ausência de documentos públicos, bytes, sintaxe PHP e casos negativos de distribuição. `tools/check_documentation.py` cruza schemas efetivos, aliases, ajuda protegida e escopo. `tools/pack_source.py` produz o pacote fonte sem credenciais sintéticas, laboratórios executáveis ou ZIPs aninhados de teste.

O roteiro Docker fica em `tools/acceptance/README.md`. `tools/lab/local_runner.py` executa uma cópia isolada e imutável do ZIP com `F3_PACKAGE_TEST=1`; as migrações usam `F3_BASELINE_TEST=1` e as bases arquivadas 0.12.1/0.13.0. Os caminhos e dependências do ambiente atual são exemplos locais, não pré-requisitos novos da hospedagem.

## Síntese das verificações locais

Últimos resultados registrados: **379 asserções, zero falhas**, mais **14/14 verificações de pacote** e **429/429 arquivos PHP do runtime com sintaxe válida**. As 3 verificações de sintaxe do migrador estão incluídas no total de asserções. Nem toda asserção corresponde a um item de negócio completo.

| Suíte/evidência | Verificações | Falhas |
| --- | ---: | ---: |
| `additional-0130.json` | 11 | 0 |
| `advanced-0130.json` | 19 | 0 |
| `companions014-http.json` | 8 | 0 |
| `concurrency-0130.json` | 3 | 0 |
| `contracts-0130.json` | 23 | 0 |
| `crash-0130.json` | 6 | 0 |
| `database014-crash.json` | 4 | 0 |
| `documentation-0140.json` | 43 | 0 |
| `extended-0130.json` | 17 | 0 |
| `maintenance-0130.json` | 9 | 0 |
| `media-0130.json` | 9 | 0 |
| `migration014-0.12.1.json` | 20 | 0 |
| `migration014-0.13.0.json` | 20 | 0 |
| `migrator-lint014.json` | 3 | 0 |
| `oauth-http-0130.json` | 14 | 0 |
| `opcache-recovery-0130.json` | 7 | 0 |
| `packages-functional.json` | 10 | 0 |
| `providers-0130.json` | 11 | 0 |
| `query014-concurrency.json` | 3 | 0 |
| `recovery-0130.json` | 7 | 0 |
| `recovery-storage-0130.json` | 5 | 0 |
| `release014-extended.json` | 23 | 0 |
| `release014-http.json` | 20 | 0 |
| `release014.json` | 33 | 0 |
| `retention-0130.json` | 4 | 0 |
| `self-update-0130.json` | 7 | 0 |
| `third-party-0130.json` | 21 | 0 |
| `zip-validation-0130.json` | 19 | 0 |

Integrações locais: Core 1.18.0 (66 habilidades registradas), Google 0.5.0 (167), Yoast 28.5 e Elementor 4.3.0 (sete recursos reconhecidos). Essas contagens são do registro local; o catálogo visível depende das permissões e dos parâmetros. Não foram usadas credenciais Google nem dados da frota.

## Identidade dos instaladores

| Arquivo | SHA-256 |
| --- | --- |
| `wp-mcp-fator3-0.14.0.nao-homologado.zip` | `353268abc78766101fed44377dfde4144e7bdde8b5c8f57c9d2c4e9451a6ef31` |
| `wp-mcp-fator3-migrator-0.14.0.nao-homologado.zip` | `4e9d6d05b9af473dc7a680aa83a4ae48cbc8e8d7ac88a2809db86dbf5566cd86` |

O arquivo `SHA256SUMS.txt` do pacote completo também identifica fontes e documentos. O build e o relatório conservam `release_approved:false`; os manifestos têm origem modelo e não foram publicados.

