# WP MCP Fator3 0.14.0 — manual de operação

Este manual descreve o runtime 0.14.0. A evidência de testes e as pendências de homologação ficam no guia/relatório externo da entrega; presença de uma habilidade não comprova aceite em produção. Os contratos completos são consultados por Get Ability Info ou `system/guide` com `ability`.

## Conexão e descoberta

URL principal: `https://SEU-SITE/wp-json/mcp/wp-mcp-fator3`. A URL `https://SEU-SITE/wp-json/mcp/wp-mcp-ultimate` continua sendo um alias do mesmo serviço. Não é necessário recriar conectores existentes. Em instalações sem permalink, use `?rest_route=/mcp/wp-mcp-fator3`.

O transporte mantém suporte às revisões MCP implementadas na base, inclusive os clientes com sessão e o modo sem sessão. Uma sessão antiga sem prova da versão efetivamente negociada recebe HTTP 404 para o cliente inicializar outra, preservando a credencial. Não são removidas sessões nem o servidor próprio do Elementor.

Comece por `system/capabilities`, Discover Abilities e Get Ability Info. Há três metatools principais: descoberta, informação e execução. O executor de leitura é optativo conforme política. Não há necessidade de expor centenas de tools individuais. Executores que chamam outra habilidade por nome não podem ser alvos, inclusive executores de outros provedores: `ability_executor_forbidden`.

Discovery aceita filtros, paginação e `if_catalog_sha256`; `unchanged:true` significa que o catálogo efetivo daquela conexão não mudou. Permissões dependentes do alvo aparecem como `requires_input`, e serão conferidas com os parâmetros reais. Leia o schema; não deduza o contrato a partir do título ou de uma versão anterior.

## Perfis e migração de credenciais

Manutenção é o perfil administrativo pleno: observa capacidades WordPress, permissões PHP/sistema operacional, constantes de bloqueio e estado geral do canal. Não exige raízes por conexão, flag adicional de SQL ou permissão adicional de exportação. Quem instala código e administra o banco pode acessar dados sensíveis; redação de resposta evita exposição acidental e não isola esse administrador.

Credenciais válidas herdadas da 0.12.1 e políticas Legado atribuídas automaticamente pela 0.13.0 passam a Manutenção sem prazo de política. Isso não prolonga TTL de tokens, não reabre credenciais revogadas e não substitui escolhas explícitas de Leitura, Conteúdo, Personalizado ou uma exceção Legado justificada. Identidade WordPress sem configuração não ganha perfil automaticamente: aparece Sem acesso.

OAuth aceita uma lista de escopos separados por espaço e recusa escopos desconhecidos. O consentimento escolhe o perfil permitido. Ao renovar um token legado, o novo grant herda a política configurada e seus ajustes. Revogar depois a identidade legada não revoga esse grant independente.

`connections/list` pagina identidades sem tokens/senhas. `connections/update` e `connections/revoke` exigem ID exato e `expected_policy_version`. Alteração da própria identidade requer prévia e `confirm_token`. O painel e as habilidades usam o mesmo serviço. Senha de aplicação continua sendo emitida pelo painel WordPress do canal. Não confunda conexões do mesmo usuário com a mesma credencial.

## Confirmação, conflitos e resultados

Resultados incluem `success`, código estável de erro, identificação da operação quando pertinente e estado observado do efeito. No MCP, falha de tool usa `isError:true` e conteúdo estruturado. `data` de WP_Error é preservada com redação por chave. `applied:null` significa efeito incerto, não autorização para repetir.

Operações em duas fases fornecem uma identidade `phase:…` consultável por `operations/status`, inclusive se a resposta de confirmação se perder. Para operações em duas fases, faça a chamada sem `confirm_token`, examine a prévia e repita os mesmos parâmetros com o token. Ele se vincula à intenção, conexão e pré-imagem, e expira em 600 segundos. SQL, lotes, restauração, mudanças de endereço e autorrestrição continuam em duas fases. `confirm:true` dispensa a segunda chamada apenas em exclusões tipadas admitidas para Manutenção; não dispensa uma revisão/hash fornecida.

`expected_sha256`, `expected_revision` e revisões de política impedem sobrescrever uma pré-imagem diferente. Os locks de arquivo cobrem leitura, comparação, backup e substituição entre operações cooperantes. O tempo padrão `lock_wait_seconds` é 2 segundos; dois agentes no mesmo site devem tratar conflitos e reler antes de decidir. Editores externos que não usam o mesmo lock continuam podendo alterar arquivos.

## Arquivos, busca e transferências

`files/read` conserva bytes binários em base64 também na leitura integral. Use `offset_bytes` para iniciar em um byte arbitrário; o cursor opaco continua disponível. Cursor e offset incompatíveis são recusados. `tail_lines`, `offset`, `grep` e busca por `grep_regex` atendem logs/textos; `files/search` aceita arquivo único ou diretório. Erros de PCRE são identificáveis.

`files/write` recusa conteúdo textual para extensões binárias; use `content_base64`. Arquivos PHP têm validação sintática, pré-imagem, escrita atômica e sondas. Em Manutenção, `probe:false` é uma escolha explícita que pula apenas as sondas de execução; a resposta registra isso, e a operação concluída não é revertida como se estivesse abandonada.

`files/move`, `files/copy`, `files/delete`, `files/rmdir`, patch e restauração preservam seus contratos. Rótulos `label`/`rotulo` identificam backups; aliases conflitantes são recusados. O armazenamento `f3-mcp-private` não é uma pasta comum disponível por files/*: consulte `system/health` e os serviços de backup/exportação.

O limite padrão por arquivo é 16 MiB. `system/settings-update` ajusta `file_bytes` entre 1 MiB e 1 GiB, sujeito aos recursos físicos; a conexão pode ter limite próprio. Isso não aumenta o tamanho máximo de uma resposta nem elimina limites PHP. Para 20 MiB, configure pelo menos 20 MiB e use `files/upload-create`, partes de 256 KiB, `files/upload-part` e `files/upload-finalize`. SHA-256 e tamanho total são conferidos; partes repetidas idênticas são aceitas. Cancelar remove as partes da transferência, sem desfazer um arquivo já concluído.

`files/archive` compacta a origem incluindo seu nome. `files/extract` valida o ZIP e prepara o destino antes de substituir. `overwrite:true` substitui a árvore inteira, sem mesclar. Links, traversal, colisões, CRC inválido e expansão excessiva são recusados. `files/rollback-tree` usa o backup e recusa pós-imagem alterada. Limites adicionais do inventário de recuperação: 20.000 entradas e 256 MiB por árvore.

## Backups e recuperação

Backups e artefatos são privados, com envelope PHP e metadados assinados. A exportação contém valores originais quando destinada a recuperação, inclusive segredos. Base64 não é criptografia. `backups/list` permite rótulo/data. Retenção é explícita, com prévia/seleção congelada e tratamento de legados; instalar a versão não limpa pendências automaticamente.

A sentinela em mu-plugins preserva a recuperação fora da pasta substituível. Não a remova enquanto houver operação pendente. Rollback de arquivos/plugins/temas verifica a pós-imagem para não apagar mudança posterior. Restauração de arquivos não desfaz migrações arbitrárias realizadas por código de um plugin/tema.

`system/health` apresenta estado e localização do armazenamento, recuperação, cron e sondas. Consulte o código e o estado de erro antes de repetir. Uma operação interrompida pode precisar de recuperação explicitamente confirmada.

## Plugins, temas e atualização do canal

`plugins/upload` e base64 aceitam hash do ZIP, slug esperado, overwrite e ativação explícita. Omissão de `activate` equivale a false. A substituição cria pré-imagem e devolve versões/ativação antes e depois. Plugins que já estavam ativos permanecem ativos ao atualizar, com verificação em requisição nova e sondas anônimas. `plugins/rollback` recupera a árvore anterior. A exclusão verifica ausência e limpa somente a entrada correspondente em auto-update; limpeza de registro de uninstall não executa o callback.

O próprio canal pode receber upload na 0.14.0 por staging, preload e recuperação independente. Para partir da 0.12.1, use o componente `wp-mcp-fator3-migrator` desta entrega antes de substituir o canal. O guia externo contém a sequência. Não envie o novo ZIP diretamente ao self-upload destrutivo carregado na 0.12.1.

`plugins/list` permite projeção `fields`/`campos` e filtro `prefixes`/`prefixo`. `themes/upload`, `themes/activate`, `themes/update`, `themes/delete` e `themes/rollback` acrescentam pré-imagem, identidade, requisitos, pai/filho e recuperação. O tema em uso ou seu pai não pode ser excluído; tema com dependentes também é recusado.

O canal aceita fontes HTTPS de manifesto em `system/settings-update.update_channels`. Configurá-las não liga atualização automática. `Update URI: false` impede a oferta homônima padrão do wordpress.org; não é um feed publicado. O manifesto precisa apontar para bytes reais verificáveis por SHA-256. Não substitua Core/Google atuais pelos pacotes antigos usados em testes históricos.

## Leitura SQL e exportação de resultados

Em Manutenção, `db/query` aceita SELECT, WITH terminado em SELECT, JOIN, UNION, views do banco do site, subconsultas, agregações, CASE, janelas, funções JSON/data e leitura pertinente de information_schema. Há uma única instrução, sem escrita nem construções com efeito colateral. O SQL original é preservado; somente o LIMIT externo é limitado para a resposta interativa.

A resposta interativa tem até 2.000 linhas e 16 MiB. `timeout_seconds` é limitado pelo tempo efetivo do processo. Para o resultado completo, use `db/query-export` com `format:jsonl` ou `csv`, `gzip` opcional e `async:true` por padrão. A operação materializa um snapshot de leitura, informa contagem/bytes/SHA-256 e só publica artefato completo. `operations/status` recebe `operation_id`; `db/export-part` lê blocos base64 de até 256 KiB com offset/hash. `db/query-page` pagina JSONL sem gzip por uma chave sequencial criada no snapshot, sem OFFSET sobre tabelas vivas.

Jobs dependem do loopback ou WP-Cron, sem daemon novo. `db/export-cancel` solicita cancelamento cooperativo. Snapshot de worker encerrado não é retomado como se ainda existisse: o estado aponta interrupção e exige nova exportação. Artefatos de consulta expiram em sete dias. Espaço/tempo insuficientes geram falha sem disponibilizar arquivo parcial como concluído.

A redação usa origem da coluna, chave projetada e predicado exato comprovado. Aliases de colunas secretas continuam redigidos. `option_value`/`meta_value` com chave ambígua são redigidos conservadoramente; `redacted` informa célula, razão e origem. Transformações arbitrárias em SQL administrativo não têm garantia de impedir inferência. Respostas binárias preservam encoding explícito.

## Escrita SQL, dump e troca serializada

`db/execute` de Manutenção admite DML complexo e DDL de tabelas/índices. Continua exigindo duas fases, cópia prévia e comparação do banco. Não aceita alteração de credenciais/permissões do MySQL nem do estado transacional interno f3_mcp_*; use as rotas próprias do canal. A prévia é conservadora e relaciona as tabelas do snapshot; não executa DML de teste em produção.

`db/batch` executa até 100 instruções DML em uma conexão/transação InnoDB. Uma falha reverte o lote. DDL é recusado antes da primeira escrita. DDL sofre commits implícitos e usa recuperação por cópia, sem promessa de rollback transacional global. `operations/plan` não inclui SQL.

`db/export` produz SQL gzip privado de tabelas selecionadas ou do banco. Inclui schema, dados, índices, views em ordem de dependência, triggers e manifesto. Bytes binários, NULL e Unicode são preservados. Banco com rotinas/eventos SQL não suportados é recusado como dump completo; nenhum artefato parcial recebe esse rótulo. Dumps de recuperação não expiram automaticamente.

`db/restore` exige artefato íntegro, prévia do destino e confirmação; cria backup anterior e diário fora do banco afetado. O estado operacional MCP corrente é preservado, inclusive famílias/revogações e registros de autenticação pertinentes. Não é uma transação global. O controlador em mu-plugins mantém wp_options disponível durante a importação e, após abandono do processo, tenta restaurar a pré-imagem na requisição seguinte. Consulte `db/recovery-status` e `operations/status`; falha de recuperação permanece explícita. Backups de mutação com pós-imagem divergente exigem revisão e nova prévia com `allow_changed_destination:true`. Não repita cegamente uma restauração incompleta.

`db/search-replace` faz troca literal em strings, JSON e arrays serializados, com filtros `tables`/`columns`, amostras redigidas e lotes por chave primária dentro de uma transação. Não instancia objetos PHP. Valores serializados não suportados, tabelas sem chave e alterações em chave primária são apontados e preservados; alterações de chave usam SQL explícito. Contagens por tabela/coluna e backup acompanham o resultado. Confira `skipped`, mesmo quando a operação conclui.

`db/schema` com `contar:true` acrescenta `rows_exact`, mantendo distinta a estimativa.

## Conteúdo e mídia

Patch de post/página exige seleção única por padrão, aceita limite também no modo regex e suporta `expected_revision`. Readback inclui SHA-256 e CHAR_LENGTH; transformação observada é indicada por `content_filtered`. As descrições usam `parent`; `parent_id` é alias compatível, com recusa quando diverge.

`content/edit-block` não descarta filhos silenciosamente quando recebe `inner_html`; use `children` para substituir a árvore. `featured_media` e revisão final consideram as gravações pertinentes. Revisões e getters permitem projeção sem trazer conteúdo desnecessário.

`content/delete-post` explicita o comportamento real de lixeira para tipos de post e exclusão permanente. `media/regenerate` e `media/set-site-icon` usam as APIs nativas e verificam metadados/recortes. Não exigem mu-plugin descartável.

## Configuração, cron e cache

Em Manutenção, `options/update` administra options fora do estado interno do canal, com backup e readback. `stylesheet` usa `themes/activate`; `template`/`current_theme` orientam para essa seleção nativa. `active_plugins` orienta para as habilidades de ativação/desativação para preservar hooks. Nomes internos f3_mcp_* orientam para `system/settings-update`. Segredos podem ser gravados, mas não são repetidos em resultado/log. `auto_update_plugins` é administrável; instalar o canal não a habilita automaticamente.

`site/set-admin-email` grava o e-mail autorizado e limpa confirmação pendente; não comprova entrega de e-mail. `site/set-language` instala pacote oficial compatível antes de mudar WPLANG. `roles/list`/`roles/update` usam APIs nativas e confirmação. `site/set-address` faz prévia, exige destino alcançável e permite troca serializada de URLs, com verificação e reversão. Não cria DNS/TLS.

Permalink, category_base e tag_base são regenerados pelo serviço nativo; `rewrite/flush` executa flush soft e devolve comparação de regras. Não é necessário editar rewrite_rules por SQL.

`cron/list` mostra hook/timestamp/argumentos/recorrência e revisão. `cron/run` executa somente evento existente conferido, sob lock cooperativo e contexto cron sem usuário logado; conclusão do callback informa `business_result:unknown`. O resultado inclui `operation_id`; `operations/status` conserva conclusão ou efeito incerto após interrupção. Não é um executor de nomes de funções PHP. `cron/schedule` e `cron/unschedule` verificam a agenda nativa. Dois disparos cooperantes são serializados; callbacks com efeito externo precisam de verificação própria.

`system/delete-transient` remove chave exata e identifica backend. `system/cache-flush` limpa cache de objeto, não cache de página. `system/health.cron` informa wp_cron_desabilitado, eventos_vencidos e ultimo_disparo. Site sem disparo WP-Cron pode acumular agenda vencida.

## Sondas e limites da evidência

`system/probe` faz requisições anônimas ao próprio site, sem cookie, com asserções e informação de cache. Home/REST recebem verificação comum após operações protegidas. Uma medição de TTFB não identifica sozinha o tempo de geração PHP ou cache frio. Só considere `http_protection_tested` quando houver evidência efetiva da sonda.

Os documentos operacionais Markdown e o catálogo JSON bruto ficam no pacote fonte/documentação externa. O instalador fornece esta ajuda por recurso PHP protegido, lido por `system/guide` e wp-admin; não depende de regras manuais de .htaccess para esconder o manual. Atualização substitui a árvore do canal e remove os documentos residuais da distribuição anterior com pré-imagem.
