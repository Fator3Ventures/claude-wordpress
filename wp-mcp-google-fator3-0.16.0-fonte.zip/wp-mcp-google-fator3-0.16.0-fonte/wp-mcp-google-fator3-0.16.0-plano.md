# Plano — Fator3 MCP Google 0.16.0

21/10/2026. Base Google 0.15.0; acompanhante recebido Core 1.42.0. Pedidos 30, 31 e 32. Instalador ainda não gerado.

- 30: menu único com seis abas, identificação GA4 obtida da interface pública de medição do Core, seletores de recursos da conta, permissões e perfis em controles estruturados, incidentes em português.
- 31: renovação no executor existente, 12 horas após verificação, mesma prova remota sem coleta, autorização administrativa persistida, travas e orçamento. Falhas preservam validade anterior até expirar, abrem incidente e avisam admin_email; tentativas com espera crescente. Mudanças de identidade, segredo, destino ou autorização exigem verificação manual.
- 32: Data Manager events:ingest; exatamente um registro e um destino por pedido. Recibo persistido antes de retornar, consulta assíncrona e nenhuma repetição automática de ingestão incerta. SUCCESS com destino e recordCount=1 confirma esse único registro; aggregate parcial, ausência de recibo, destino divergente ou falha de consulta continuam incertos. Valores e moeda são lidos da ação. Verificação usa validateOnly, nunca coleta conversão.

Dependência concreta: Core precisa consultar reconcileBound(record_id, destination_ref) para suas linhas incertas, sem chamar send/sendBound nem reabrir envio. Implementar e entregar patch sobre Core 1.42.0, com negociação explícita e teste integrado; não alterar o instalador fechado do Core.

Validação prevista: fixtures negativas, WordPress limpo, upgrade direto 0.15, isolamento, Core 1.42 com dependência e sem dependência, permissões administrativas, leitura documental MCP, inspeção das telas. Aceites de dois dias e conversões reais 113/125 dependem de instalação/publicação pela frota e acompanhamento em produção; não serão declarados concluídos por simulação.

## Fechamento da implementação — revisão 2

2026-10-21T01:44:59-03:00. Pedidos 30–32 implementados e validados no escopo local. Instalador gerado: `wp-mcp-google-fator3-0.16.0-instalador.zip`, SHA-256 `e0dfee63fbd9ad9fcc6b5ab9a3b9d492d7e497822154e0572589a45f3116248c`. Matriz final: 493 verificações WordPress e 60 puras, zero falhas. Dependência Core implementada e entregue em fonte; impacto pertinente atualizado na revisão 2. Aceites remotos, navegador e dois dias permanecem pendentes conforme relatório. O texto inicial acima preserva a situação do planejamento; os dados desta seção registram a entrega.
