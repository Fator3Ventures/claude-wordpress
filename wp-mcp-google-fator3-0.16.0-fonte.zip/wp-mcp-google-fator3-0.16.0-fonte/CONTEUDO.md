# Fonte Google 0.16.0

`plugin/wp-mcp-google-fator3` contém fonte completo, runtime, docs, build, tools, tests e evidências históricas. A evidência desta rodada está em `evidence/016`; evidências anteriores não certificam esta versão. Somente o instalador externo é instalável no WordPress. `dependencia-core` contém a alteração implementada, não uma release Core.

## Reproduzir a bancada desta rodada

Use Python 3.12, PHP 8.3.6, MySQL 8.0.46, WordPress 7.1.2 e os insumos fixados por SHA-256 em `plugin/wp-mcp-google-fator3/evidence/016/inputs.example.json`. Os binários e instaladores acompanhantes não estão aninhados neste ZIP. Ajuste caminhos, sem alterar os hashes. `core` e `baseline_core` são o acompanhante exclusivo de bancada; `core142` é o original imutável. Reproduza o acompanhante com `dependencia-core/reproduzir-bancada.py` e o instalador Core original; nunca o publique nem instale na frota.

Dentro de `plugin/wp-mcp-google-fator3`: execute `php build/export-contracts.php`, `python build/compile-documents.py`, `python build/check-docs.py` e `python build/build.py candidate --output /insumos/wp-mcp-google-fator3-0.16.0-instalador.zip`. O candidato deve ter SHA-256 `e0dfee63fbd9ad9fcc6b5ab9a3b9d492d7e497822154e0572589a45f3116248c`. Use `python tools/release016.py --manifest /insumos/manifest.json --work-base /laboratorios/016 --evidence /resultados/016 --php /runtime/usr/bin/php8.3`; ajuste LD_LIBRARY_PATH às bibliotecas do runtime. Diretórios de bancada/evidência devem ser novos.

O README histórico de tools descreve versões anteriores; para 0.16 a entrada correta é release016.py. A bancada bloqueia fornecedores, usa Google/e-mail sintéticos e HTTP MCP real. O gate histórico integral permanece disponível, mas não foi executado nesta rodada. Validação exige candidato/identidade, inventários e provas sem falha. Copie os bytes certificados; não regenere o instalador após o fechamento.

Plano, impacto e cópia pré-fechamento do relatório estão na raiz. O relatório externo possui bytes/SHA-256 final do fonte; não há hash circular. Logs, cookies, banco, HTML com nonce, binários e ZIPs de laboratório não estão incluídos.
