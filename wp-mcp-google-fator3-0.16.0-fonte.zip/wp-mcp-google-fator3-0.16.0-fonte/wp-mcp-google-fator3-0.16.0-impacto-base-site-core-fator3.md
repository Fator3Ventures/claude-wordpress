# Impacto técnico — Google 0.16.0 → Site Core

Emissor: Fator3 MCP Google, base 0.15.0, alvo 0.16.0. Destinatário: Fator3 Site Core, base examinada 1.42.0; próxima versão definida pelo responsável Core. Revisão 2, 2026-10-21T01:44:59-03:00, entrega, **acao-necessaria**. Pedido MCP Google 32. Situação: dependência implementada e validada localmente; integração/publicação Core pendentes. Revisão 1 foi emitida no planejamento, antes da implementação, com instalador ainda não gerado.

## Por que o impacto existe

Data Manager confirma o processamento após a ingestão. O Core 1.42.0 original mantém `incerto` terminal e não consulta novamente o adaptador. É necessária uma alteração real no worker Core para consultar a confirmação sem repetir envio. O ID GA4 usa a interface de medição já existente e não exige alteração Core. Não há impacto apenas para comunicar versão, nem impactos adicionais para MCP/Meta/LinkedIn.

## Contrato entregue

Permanece `site-conversion-delivery/1.0.0`, com `send` e `sendBound`. Extensão opcional: `async_reconciliation=site-conversion-reconcile/1.0.0` e `reconcileBound(record_id,destination_ref)`. A extensão é somente leitura de recibo. Google vincula o recibo à conexão, identidade, registro e destino aceito; um evento e um destino por request. SUCCESS com destino correspondente e recordCount igual a um confirma esse único registro. Resultado parcial, divergente, duplicidade, perda de recibo e erro desconhecido permanecem incertos. Recusa exige prova de não entrega.

Alteração Core implementada em `includes/class-f3base-conversoes-servidor.php`: o worker chama `reconciliar()` sob sua trava; lê no máximo dez linhas incertas vencidas, respeita prazo, estado do contato e referência histórica, consulta o adaptador e atualiza com guarda de estado/destino. A consulta não incrementa tentativas de ingestão nem chama `send`/`sendBound`. A fila comercial, captura, consentimento e tags permanecem Core. Google bloqueia somente a prontidão Ads quando a extensão Core está ausente (`core_async_unsupported`).

## Entrega e provas

`wp-mcp-google-fator3-0.16.0-dependencia-base-site-core-fator3.zip` contém o arquivo modificado, diferença unificada, manifesto antes/depois, aplicador que recusa base divergente e reprodutor do acompanhante exclusivo de bancada. Não é instalador WordPress e não renumera nem substitui a release Core 1.42.0 publicada. SHA-256 da dependência: `9f4542b810b6b9817312beb236c782507a8bd589f182f19d83adbb525f630822`.

Matriz Google: 493 verificações WordPress, 60 contratuais puras, zero falhas finais. Inclui Core 1.42 original com bloqueio Ads; Core 1.42 acrescido da dependência com contato/fila sintéticos, ingestão única, consulta posterior e confirmação sem novo POST. Revogação, destino divergente, timeout e resultados parciais são exercitados. Aplicador: quatro verificações aprovadas; ZIP exclusivo de laboratório reproduzido byte a byte. Não se reivindica execução dos gates integrais do Core nem conversão comercial real.

Instalador Google: `wp-mcp-google-fator3-0.16.0-instalador.zip`, 756123 bytes, SHA-256 `e0dfee63fbd9ad9fcc6b5ab9a3b9d492d7e497822154e0572589a45f3116248c`. Evidência: `plugin/wp-mcp-google-fator3/evidence/016/validation016.json` no fonte Google.

## Ação por responsável e aceite restante

- Responsável Core: revisar/incorporar a mudança à sua próxima versão, repetir seus gates e entregar seu próprio fonte, instalador e relatório. O desenvolvimento necessário já está entregue; não há espera de implementação para concluir o Google.
- Frota: publicar/instalar a versão Core que incorporar a extensão antes de habilitar Ads no Google 0.16.0; conferir hashes e estado.
- Dono dos ativos/frota: selecionar ação Site — Importação de cliques habilitada, confirmar acesso/API/escopo, verificar destino e homologar 113/125 sem duplicar, além do primeiro contato real. A consulta atual de ações elegíveis em 5347668213 retornou zero linhas.

Aceite real e integração na release Core permanecem abertos. Nenhuma instalação Core remota nem mensagem a terceiros foi realizada. Este documento acompanha a entrega ao dono.
