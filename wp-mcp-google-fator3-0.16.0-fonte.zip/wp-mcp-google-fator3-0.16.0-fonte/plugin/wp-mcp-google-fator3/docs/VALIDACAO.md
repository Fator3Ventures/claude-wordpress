# Validação — 0.16.0

Escopo: pedidos 30–32, menu e formulários, leitura GA4 Core, renovação no executor, Data Manager e reconciliação assíncrona sem repetição de ingestão. Base direta Google 0.15.0. WordPress 7.1.2/PHP 8.3.6/MySQL 8.0.46; MCP 0.24.0; Core 1.42.0 original e com a dependência de fonte fornecida; Meta/LinkedIn 0.3.0 como sentinelas de preservação no upgrade.

`tools/release016.py` verifica inventário exato do candidato, lint, contratos, documentação e quatro cenários nativos: limpo com dependência Core; upgrade 0.15 com rollback/reaplicação; Core 1.42 original com bloqueio Ads; Google isolado. PHP CLI server com quatro workers, MySQL isolado e transporte HTTP MCP real. Google e e-mail são simulados; nenhum dado comercial é enviado. A página de conversões e demais abas são renderizadas pelo WordPress; POST administrativo exercita perfil estruturado e nonce.

Resultados e contagens efetivos ficam no relatório externo e em `evidence/016`. As demais evidências são históricas. Não se apresenta o conjunto dirigido como execução do gate integral histórico PHPUnit/tools/validate.py.

Pendentes reais: instalação pela frota, verificação de destinos com credenciais do dono, dois dias de renovação contínua sem tarefa externa, revogação de segredo com e-mail antes do vencimento, atribuição GA4/Android WebView e conversões Ads reais 113/125 e primeiro contato com clique. Instalação local e fixtures não encerram esses aceites. Chromium não disponível; tentativa de obter navegador falhou no download. Renderização/interação em navegador real permanece pendente, sem afirmar validação visual. Não há prova PHP-FPM, multisite/CDN ou outros runtimes.
