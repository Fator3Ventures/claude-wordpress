# Fechamento documental — 0.16.0

Fonte editável e documentação instalada são compilados por build/compile-documents.py. O registro gera 286 abilities, 36 opções e os schemas por build/export-contracts.php. build/check-docs.py confere correspondência, links e versão. Painel e google/documentation usam a mesma allowlist de 20 documentos, com leitura integral/paginada e hash.

O instalador testado é promovido sem reconstrução. O relatório externo é canônico; a cópia no fonte é anterior ao fechamento do ZIP fonte e não contém seu próprio hash. Evidência corrente em evidence/016. A dependência Core é separada e não instala outra versão de Core pelo Google. Versões antigas/testes históricos no fonte não contam como execução desta rodada.
