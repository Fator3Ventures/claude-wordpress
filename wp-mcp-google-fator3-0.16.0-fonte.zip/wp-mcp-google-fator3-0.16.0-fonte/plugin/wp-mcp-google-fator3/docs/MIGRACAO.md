# Instalação, atualização e recuperação — 0.16.0

Base direta: Google 0.15.0 ou WordPress limpo. Instale `wp-mcp-google-fator3-0.16.0-instalador.zip` substituindo a pasta original, sem desinstalar. Não há migração de banco, mudança de defaults, ativação de envio ou troca automática de credencial. Contratos/configurações/segredos/jobs permanecem no formato da base.

## Procedimento

1. Preserve backup coerente de arquivos, banco e material de cifra. Confira SHA-256 e slug do instalador contra o relatório externo.
2. Atualize pelo mecanismo autorizado. Na frota, verifique os bytes da URL raw publicada e use `plugins/upload` com `expected_sha256` e `expected_slug`. A existência do ZIP não prova publicação da URL. Upload-base64 é usado apenas na bancada local.
3. Em requisição nova, confira `google/status`, versão 0.16.0, `google/storage-status` e `google/documentation`. O índice deve apresentar `GUIA-0.16.0.md`; descarte paginação iniciada com hash anterior.
4. Confira conexão, serviços, bindings, concessão e política. A instalação preserva as escolhas existentes. Configuração por conexão, permissões de administração e confirmação de escritas continuam obrigatórias.
5. Para Core com a extensão de reconciliação entregue, configure/verifique Google e só então selecione servidor explicitamente. `sendBound()` liga o envio ao destino aceito; não transforme `destination_mismatch` ou resultado incerto em autorização de reenvio.

Google 0.16 bloqueia Ads no Core 1.42 original com `core_async_unsupported`. O responsável Core deve integrar a dependência de fonte em sua próxima versão. GA4 não exige essa extensão. O Google não modifica arquivos de acompanhantes durante a instalação.

## Recuperação e reversão

`google/recovery {"action":"prepare"}` pausa fora do banco e verifica drenagem. Somente `ready_for_restore:true` permite avançar na restauração. Preserve a sentinela de destino `wp-content/f3-google-state` durante restauração do banco; ela não é cache nem deve ser sobrescrita por uma cópia antiga.

Após reconciliar efeitos externos e conferir banco/arquivos, consulte `google/recovery-status` e retome com `expected_generation` atual e `acknowledge_reconciled:true`. A geração invalida caches e contextos anteriores. Escritas interrompidas permanecem desconhecidas até reconciliação explícita.

Rollback MCP conserva pré-imagem de arquivos; `dry_run` confere prontidão. Restaurar arquivos não restaura banco, credenciais, configuração ou efeitos nas APIs. Voltar à 0.15 remove Data Manager e renovação automática. Não retome Ads legado com recibos pendentes; suspenda o transporte e reconcilie antes de reverter. Preserve referências, fila e diário Core e avalie a combinação antes de retomar. Não apague filas para remover bloqueios.

Instalação limpa cria `{prefix}f3_google_records` e `{prefix}f3_google_cron`; a atualização usa as tabelas existentes, sem replay de jobs concluídos. Ativação não substitui diagnóstico/reparação de um plugin já ativo e incompleto. Consulte o relatório externo para provas e pendências da rodada.
