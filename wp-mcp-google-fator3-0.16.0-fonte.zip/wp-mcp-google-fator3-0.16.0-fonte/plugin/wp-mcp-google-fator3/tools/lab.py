"""Owned native WordPress lab. Only declared, hashed inputs; no old session/production paths."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, signal, socket, subprocess, tarfile, time, uuid, zipfile
ROOT=Path(__file__).resolve().parents[1]
MARKER='.google-lab-owner.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tree_hash(p):
    h=hashlib.sha256()
    for f in sorted(p.rglob('*')):
        if f.is_file():h.update(f.relative_to(p).as_posix().encode()+b'\0'+bytes.fromhex(sha(f)))
    return h.hexdigest()
def required_inputs(origin,order):
    required=['runtime','wordpress','wp_cli','candidate']
    if order!='google-only':required+=['mcp','core']
    if origin=='upgrade':
        required+=['baseline']
        if order!='google-only':required+=['baseline_mcp','baseline_core']
    return required
def checked_inputs(config, required=None):
    data=json.loads(config.read_text());inputs={}
    for name in (required if required is not None else data['inputs']):
        item=data['inputs'][name];p=(config.parent/item['path']).resolve()
        if (name in ['runtime','testing'] and not p.is_dir()) or (name not in ['runtime','testing'] and not p.is_file()):raise ValueError('Missing dependency: '+name)
        actual=tree_hash(p) if name in ['runtime','testing'] else sha(p)
        if actual!=item['sha256']:raise ValueError('Dependency SHA-256 mismatch: '+name)
        inputs[name]=p
    return data,inputs

def owned(path):
    if path.is_symlink() or not (path/MARKER).is_file():raise ValueError('Refused: directory does not belong to this lab')
    m=json.loads((path/MARKER).read_text())
    if m.get('kind')!='f3-google-lab/1' or m.get('path')!=str(path.resolve()) or not m.get('id'):raise ValueError('Refused: invalid lab ownership')
    if m.get('pid') and Path('/proc',str(m['pid'])).exists():raise ValueError('Refused: laboratory is running')
    return m

def port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def extract_zip(src,target):
    with zipfile.ZipFile(src) as z:
        for info in z.infolist():
            p=Path(info.filename)
            if p.is_absolute() or '..' in p.parts or (info.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe ZIP input')
        z.extractall(target)

def native_script(script):
    path=(ROOT/script).resolve()
    if not path.is_relative_to(ROOT/'tests/native') or not path.is_file():raise ValueError('Only existing native scripts in this source tree may run')
    return path

def installed_inventory(archive, plugins, slug):
    """Check the final tree independently of PHP stat/realpath caches and package receipts."""
    with zipfile.ZipFile(archive) as z:
        expected={n[len(slug)+1:]:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith(slug+'/') and not n.endswith('/')}
    directory=plugins/slug
    if not expected or not directory.is_dir() or directory.is_symlink():raise ValueError('Installed package missing: '+slug)
    actual={}
    for p in directory.rglob('*'):
        if p.is_symlink():raise ValueError('Linked installed package member: '+slug)
        if p.is_file():actual[p.relative_to(directory).as_posix()]=sha(p)
    if actual!=expected:
        raise ValueError('Installed inventory differs: '+slug+' '+json.dumps({'extra':sorted(actual.keys()-expected.keys()),'missing':sorted(expected.keys()-actual.keys()),'changed':sorted(k for k in actual.keys()&expected.keys() if actual[k]!=expected[k])}))
    return {'files':len(expected),'archive_sha256':sha(archive),'exact':True}

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--manifest',required=True,type=Path);parser.add_argument('--workdir',required=True,type=Path);parser.add_argument('--reset',action='store_true');parser.add_argument('--origin',choices=['clean','upgrade','mcp-install'],default='clean');parser.add_argument('--order',choices=['mcp-first','google-first','google-only'],default='mcp-first');parser.add_argument('scripts',nargs='*');a=parser.parse_args()
    scripts=[native_script(script) for script in a.scripts]
    config=a.manifest.resolve();data,inputs=checked_inputs(config,required_inputs(a.origin,a.order));lab=a.workdir.absolute()
    if a.reset:
        owned(lab);shutil.rmtree(lab)
    if lab.exists() and any(lab.iterdir()):raise ValueError('Refused: lab directory must be empty; use --reset only on an owned lab')
    lab.mkdir(parents=True,mode=0o700,exist_ok=True)
    started=time.time()
    report=None
    state={'kind':'f3-google-lab/1','id':uuid.uuid4().hex,'path':str(lab.resolve()),'pid':os.getpid()}
    (lab/MARKER).write_text(json.dumps(state));services=[];logs=[]
    rt=inputs['runtime'];lib=rt/'usr/lib/x86_64-linux-gnu';php=rt/'usr/bin/php8.3';wp=lab/'wordpress'
    ports={k:port() for k in ['db','fpm','http']}
    if len(set(ports.values()))!=3:raise ValueError('Port collision; retry with another isolated lab')
    url=f"http://127.0.0.1:{ports['http']}"
    modules=['ctype','fileinfo','tokenizer','phar','mbstring','mysqlnd','mysqli','pdo','pdo_mysql','dom','xml','simplexml','xmlreader','xmlwriter','curl','zip','iconv','posix']
    ini=f"extension_dir={rt/'usr/lib/php/20230831'}\n"+''.join('extension='+m+'.so\n' for m in modules)+'memory_limit=512M\ndate.timezone=UTC\n'
    (lab/'php.ini').write_text(ini)
    env=os.environ.copy();env.update(LD_LIBRARY_PATH=str(lib),PHPRC=str(lab/'php.ini'),F3_FIXTURE_ROOT=str(lab),F3_WP_ROOT=str(wp/'wp-load.php'),F3_LAB_ID=state['id'],F3_LAB_URL=url,F3_LAB_ORIGIN=a.origin,F3_LAB_ORDER=a.order,F3_CANDIDATE=str(inputs['candidate']),F3_WP_CLI=str(inputs['wp_cli']),F3_BASELINE=str(inputs.get('baseline','')),F3_LAB_MANIFEST=str(config),F3_EVIDENCE_DIR=str(lab/'evidence'),WP_CLI_ALLOW_ROOT='1')
    (lab/'evidence').mkdir();(lab/'mysql').mkdir(mode=0o700);(lab/'mysql-files').mkdir();(lab/'mcp-private').mkdir(mode=0o700)
    def run(cmd,**kw):return subprocess.run([str(x) for x in cmd],env=env,check=True,**kw)
    def php_run(script):return run([php,'-c',lab/'php.ini',script])
    def start(cmd,key):
        log=open(lab/(key+'.log'),'w');logs.append(log)
        p=subprocess.Popen([str(x) for x in cmd],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);services.append(p)
        until=time.monotonic()+30
        while time.monotonic()<until:
            if p.poll() is not None:raise RuntimeError(key+' exited; inspect '+str(lab/(key+'.log')))
            try:
                with socket.create_connection(('127.0.0.1',ports[key]),.2) as conn:
                    if key!='db' or conn.recv(8)[4:5]==b'\x0a':return
            except OSError:time.sleep(.1)
        raise RuntimeError(key+' not ready')
    try:
        with tarfile.open(inputs['wordpress']) as t:
            for member in t.getmembers():
                p=Path(member.name)
                if p.is_absolute() or '..' in p.parts or member.issym() or member.islnk():raise ValueError('Unsafe WordPress archive')
            t.extractall(lab,filter='data')
        if not (wp/'wp-load.php').is_file():raise ValueError('WordPress archive must contain wordpress/wp-load.php')
        plugins=wp/'wp-content/plugins';plugins.mkdir(parents=True,exist_ok=True)
        if a.order!='google-only':
            extract_zip(inputs['baseline_mcp' if a.origin=='upgrade' else 'mcp'],plugins);extract_zip(inputs['baseline_core' if a.origin=='upgrade' else 'core'],plugins)
        if a.origin!='mcp-install':extract_zip(inputs['baseline'] if a.origin=='upgrade' else inputs['candidate'],plugins)
        if (plugins/'wp-mcp-google-fator3/tests').exists():raise ValueError('Lab requires production installer, not source ZIP')
        mu=wp/'wp-content/mu-plugins';mu.mkdir(exist_ok=True)
        (mu/'00-google-lab.php').write_text("<?php\nadd_filter('pre_wp_mail',static fn()=>true);\nadd_filter('wp_is_application_passwords_available', '__return_true');\nadd_filter('pre_http_request',static function($pre,$args,$url){if($pre!==false)return $pre;if(str_starts_with($url,getenv('F3_LAB_URL').'/'))return $pre;return new WP_Error('lab_external_transport_disabled','External transport blocked');},PHP_INT_MAX,3);\n")
        dbname='google_'+state['id'][:16];mysql=rt/'usr/sbin/mysqld';args=[mysql,'--no-defaults','--user='+str(os.getuid()),'--basedir='+str(rt/'usr'),'--datadir='+str(lab/'mysql')]
        with open(lab/'mysql-init.log','w') as log:run(args+['--initialize-insecure'],stdout=log,stderr=subprocess.STDOUT)
        start(args+['--bind-address=127.0.0.1','--port='+str(ports['db']),'--socket=','--pid-file='+str(lab/'mysql.pid'),'--mysqlx=0','--secure-file-priv='+str(lab/'mysql-files')],'db')
        create=lab/'create-db.php';create.write_text("<?php $db=new mysqli('127.0.0.1','root','',null,"+str(ports['db'])+");$db->query('CREATE DATABASE "+dbname+" CHARACTER SET utf8mb4');")
        php_run(create)
        configphp="<?php\ndefine('DB_NAME',%s);define('DB_USER','root');define('DB_PASSWORD','');define('DB_HOST',%s);define('DB_CHARSET','utf8mb4');define('DB_COLLATE','');$table_prefix='wp_';\ndefine('DISABLE_WP_CRON',true);define('WP_DEBUG',true);define('WP_DEBUG_LOG',true);define('WP_DEBUG_DISPLAY',false);define('WP_ENVIRONMENT_TYPE','local');define('FS_METHOD','direct');define('F3_MCP_PRIVATE_ROOT',%s);\n"%(repr(dbname),repr('127.0.0.1:'+str(ports['db'])),repr(str(lab/'mcp-private')))
        configphp+=''.join("define('%s','%s');\n"%(k,os.urandom(32).hex()) for k in ['AUTH_KEY','SECURE_AUTH_KEY','LOGGED_IN_KEY','NONCE_KEY','AUTH_SALT','SECURE_AUTH_SALT','LOGGED_IN_SALT','NONCE_SALT'])+"if(!defined('ABSPATH'))define('ABSPATH',__DIR__.'/');require_once ABSPATH.'wp-settings.php';\n"
        (wp/'wp-config.php').write_text(configphp);(wp/'wp-config.php').chmod(0o600)
        router=lab/'router.php'
        router.write_text("<?php $path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);$file=realpath(__DIR__.'/wordpress'.rawurldecode($path));if($file && str_starts_with($file,__DIR__.'/wordpress/') && is_file($file))return false;require __DIR__.'/wordpress/index.php';")
        env['PHP_CLI_SERVER_WORKERS']='4'
        start([php,'-c',lab/'php.ini','-S',f"127.0.0.1:{ports['http']}",'-t',wp,router],'http')
        print(json.dumps({'lab_ready':url,'id':state['id'],'origin':a.origin}),flush=True)
        php_run(ROOT/'tests/native/init.php')
        for path in scripts:php_run(path)
        report={'schema_version':1,'candidate_sha256':sha(inputs['candidate']),'inputs':{k:{'sha256':data['inputs'][k]['sha256'],'version':data['inputs'][k].get('version')} for k in inputs},'ports':ports,'origin':a.origin,'order':a.order,'lab_id':state['id'],'started_at':started,'runtime':run([php,'-v'],capture_output=True,text=True).stdout.strip()}
    finally:
        for p in reversed(services):
            if p.poll() is None:
                os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
        for log in logs:log.close()
        state['pid']=None;(lab/MARKER).write_text(json.dumps(state))
        if report is not None:
            if a.origin=='upgrade':
                packages={'candidate':'wp-mcp-google-fator3'}
                if a.order!='google-only':packages.update(mcp='wp-mcp-fator3',core='base-site-core-fator3')
                report['installed_inventory']={name:installed_inventory(inputs[name],plugins,slug) for name,slug in packages.items()}
            report.update(finished_at=time.time(),processes_stopped=all(p.poll() is not None for p in services))
            (lab/'evidence/environment.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,OSError,RuntimeError,subprocess.CalledProcessError) as exc:raise SystemExit('Laboratory stopped: '+str(exc))
