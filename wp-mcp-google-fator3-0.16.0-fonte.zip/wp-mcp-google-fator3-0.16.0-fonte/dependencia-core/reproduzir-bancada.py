"""Reproduce the Core fixture ZIP for local tests only; not a public Core release."""
from pathlib import Path
import argparse, hashlib, json, zipfile

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('core_installer',type=Path)
p.add_argument('output',type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
if sha(a.core_installer.read_bytes())!='280f54f8afb58301fb686a659003d432195c62dbfb5b52d055a022335cf3aeac':
    raise SystemExit('Instalador-base divergente. Nada foi alterado.')
inventory=json.loads((root/'core-lab-inventory.json').read_text())
manifest=json.loads((root/'dependency.json').read_text())
replacement=(root/'base-site-core-fator3'/manifest['path']).read_bytes()
if sha(replacement)!=manifest['after_sha256']:
    raise SystemExit('Dependência divergente. Nada foi alterado.')
contents=[]
with zipfile.ZipFile(a.core_installer) as source:
    if source.namelist()!=[i['name'] for i in inventory]:
        raise SystemExit('Inventário-base divergente.')
    for entry in inventory:
        data=replacement if entry['name']=='base-site-core-fator3/'+manifest['path'] else source.read(entry['name'])
        if sha(data)!=entry['sha256']:
            raise SystemExit('Conteúdo divergente: '+entry['name'])
        contents.append((entry,data))
with zipfile.ZipFile(a.output,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as out:
    for entry,data in contents:
        info=zipfile.ZipInfo(entry['name'],tuple(entry['date_time']))
        info.external_attr=entry['external_attr']
        info.create_system=entry['create_system']
        info.compress_type=zipfile.ZIP_DEFLATED
        out.writestr(info,data,compresslevel=6)
digest=sha(a.output.read_bytes())
if digest!='316c1ee9006de5c96220c6760880564def164373d106854f8041c20f6501188b':
    raise SystemExit('Compressão divergente; não utilizar como a evidência certificada.')
print(json.dumps({'test_only':True,'sha256':digest,'bytes':a.output.stat().st_size}))
