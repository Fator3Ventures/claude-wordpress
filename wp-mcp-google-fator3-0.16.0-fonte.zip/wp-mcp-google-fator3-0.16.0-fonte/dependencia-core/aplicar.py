"""Apply the reviewed source dependency only to the exact Core 1.42.0 base."""
from pathlib import Path
import argparse,hashlib,json,os
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('source_root',type=Path);p.add_argument('--apply',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parent;manifest=json.loads((root/'dependency.json').read_text())
target=a.source_root.resolve()/manifest['path'];replacement=root/'base-site-core-fator3'/manifest['path']
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
if not target.is_file() or target.is_symlink() or sha(target)!=manifest['before_sha256']:raise SystemExit('Base divergente; compare e integre manualmente. Nada foi alterado.')
if sha(replacement)!=manifest['after_sha256']:raise SystemExit('Dependência divergente. Nada foi alterado.')
if a.apply:
 temporary=target.with_name(target.name+'.google016.tmp')
 with temporary.open('xb') as f:f.write(replacement.read_bytes());f.flush();os.fsync(f.fileno())
 temporary.chmod(target.stat().st_mode);temporary.replace(target)
print(json.dumps({'base_verified':True,'applied':a.apply,'target':str(target),'sha256':sha(target)}))
