# Dependência implementada — reconciliação Core para Google 0.16.0

Base exata: fontes do Fator3 Site Core 1.42.0 recebidos em 21/10/2026. Pedido MCP Google 32. Este pacote é fonte para o responsável Core, não um instalador WordPress nem uma release renumerada do Core.

Mudança única: includes/class-f3base-conversoes-servidor.php. O worker passa a consultar registros incertos pelo método opcional reconcileBound(record_id,destination_ref), anunciado pelo adaptador como site-conversion-reconcile/1.0.0. A consulta não chama envio, não muda a referência histórica e não incrementa tentativas de ingestão. Respeita a trava do worker, orçamento, exclusão do contato e guarda do estado na atualização SQL. O Google é responsável por verificar autorização, identidade e recibo. A fila comercial continua no Core.

Use `python aplicar.py /caminho/do/fonte/base-site-core-fator3` para conferir a base; acrescente `--apply` para substituir o único arquivo. O script recusa base divergente. Alternativamente, revise a diferença unificada e incorpore a mudança à próxima release Core. Não sobrescreva o instalador publicado 1.42.0 mantendo a mesma versão.

Validação própria: bancada WordPress 7.1.2/PHP 8.3.6/MySQL 8.0.46, Core 1.42.0 acrescido deste único arquivo, Google 0.16.0, MCP 0.24.0. O teste delivery016 cria um contato sintético, ingere uma vez, registra incerto e confirma por consulta posterior sem novo POST de ingestão. Todas as respostas Google são fixtures. O relatório Google e evidence/016 no fonte contêm contagens, hashes e limites finais.

Responsável Core: integrar em sua próxima versão, fechar seu próprio fonte/instalador/relatório e repetir seus gates. Frota: instalar Core com a extensão antes de habilitar Ads Data Manager no Google 0.16.0. Aceites reais de ctooffice 113/125, primeiro clique e dois dias de renovação permanecem pendentes. Nenhuma alteração de Core remoto foi realizada nesta entrega.

## Reprodução do acompanhante de bancada

`python reproduzir-bancada.py /insumos/base-site-core-fator3-1.42.0-instalador.zip /laboratorio/core142-dependencia-apenas-teste.zip` reproduz os bytes usados no teste local a partir do instalador original e do único arquivo modificado. O programa verifica base, conteúdo e hash final; recusa sobrescrever uma saída existente. O resultado conserva a versão 1.42.0 somente para isolar a prova da dependência em laboratório. Não publicar nem instalar esse ZIP na frota. Ele não acompanha esta entrega.
