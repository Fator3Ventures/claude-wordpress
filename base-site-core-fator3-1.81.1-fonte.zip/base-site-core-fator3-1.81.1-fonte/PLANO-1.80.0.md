# Site Core 1.80.0 · 10/11/2026

Base oficial 1.79.0. Revisar as pendências da entrega anterior e confrontar o cadastro de configuração, a navegação do painel, a captura de origem e o contrato pipedrive-api-client/1.0.0 com MCP 0.44.0, LinkedIn 0.20.0 e Pipedrive 0.9.0. Usar WordPress descartável para gravações e fronteiras HTTP sintéticas e Site-Teste para a sequência 1.78.0 → 1.79.0 → 1.80.0, controles públicos e leitura documental.

A revisão 2 do impacto do Pipedrive encerra a ação técnica em seu emissor. O MCP 0.44.0 já classifica uma habilidade sem readonly como escrita. Tornar explícita essa classificação no Core preserva a autorização vigente. Nenhuma troca coordenada de API prevista. O impacto de autoria do tema do Implantador da 1.78.0 segue sob responsabilidade do destinatário.

A prova com WP Super Cache 3.1.5 revelou erro fatal na gravação inicial de uninstall_plugins. O Core assumiu a correção da leitura prematura de diagnósticos no hook de opções. Validar a primeira carga com cadastro de desinstalação ausente e acompanhar a autoria em Yoast e PublishPress.

Fechamento do encaminhamento: a revisão 3 do relatório ao Implantador conserva aberto o ajuste no tema 2.20.0. Foram reexecutados o caso que reproduz a troca de autoria de outra página e o caso corrigido em cópia. O emissor está pronto.
