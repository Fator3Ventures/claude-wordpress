# Fator3 Site Core 1.81.1

O instalador contém a árvore `work/plugin/base-site-core-fator3/`. O plano está em `PLANO-1.81.1.md`, os testes em `tests/` e os resultados desta rodada em `evidence/1811/`. Os diretórios com outras versões preservam o histórico. As bases oficiais estão em `history/1.80.0-runtime/` e `history/1.81.0-runtime/`. O contrato administrativo é 8.38.0. Consulte `docs/DOCUMENTACAO.md` na árvore do plugin para operar a versão instalada.

## Testar

Use WordPress 7.1.4, PHP 8.3 de 64 bits com mysqli, mbstring, curl, DOM, XML e fileinfo, e MySQL 8 em loopback. O executor pressupõe instância descartável e cria um banco por fase. Ver `tests/README.md`.

## Empacotar

Execute na raiz extraída, mantendo o nome original da pasta do fonte. O empacotamento do fonte valida a árvore atual e a base histórica contra seus manifestos.

```sh
python3 tests/verificar-entrega.py
python3 build/reproduzir-instalador.py ../base-site-core-fator3-1.81.1-instalador.zip
python3 build/conferir-instalador.py ../base-site-core-fator3-1.81.1-instalador.zip
python3 build/empacotar-fonte.py ../base-site-core-fator3-1.81.1-fonte.zip
```

O relatório externo inclui a identidade dos dois arquivos finais. A cópia interna antecede a compactação do fonte. Os ZIPs de terceiros não integram o produto. A conferência por arquivo é portável e o SHA-256 do ZIP depende da implementação de deflate.
