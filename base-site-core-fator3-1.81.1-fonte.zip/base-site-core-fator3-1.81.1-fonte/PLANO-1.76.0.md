# Retomada da rodada 1.76.0

Base conferida 1.75.1. O registro de progresso da conversa apontava alterações em transporte, fila e prévia. O estado recuperável era o fonte da 1.75.1 e o Site-Teste na mesma versão. A implementação foi reconstituída a partir dos três pedidos e conferida por novas provas.

No pedido 383, preservar event_id e separar as classes de tráfego na captura, no navegador e na chamada ao fornecedor. No pedido 384, vincular a autorização de navegação à fila, distinguir falta de decisão e negativa e recuperar as suspensões antigas ainda elegíveis. No pedido 385, reconhecer formulários nativos por método e origem, aplicar a política do Core e manter a marca de teste restrita à prévia.

As três mudanças estão no Core. As capacidades externas de Meta Ads e dos adaptadores CRM não mudam. A revisão do contrato administrativo documenta as novas semânticas do Core. Não foi identificado novo impacto técnico para MCP, Google, Meta, LinkedIn, Pipedrive ou Implantador. O encaminhamento anterior ao Implantador relaciona-se ao pedido 379 e permanece histórico.
