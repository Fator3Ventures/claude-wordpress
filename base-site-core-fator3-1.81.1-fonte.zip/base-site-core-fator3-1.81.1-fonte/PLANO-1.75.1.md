# Rodada 1.75.1 — 09/11/2026

Base efetiva 1.74.0. Aplicar os oito pedidos da aba de 09/11 em quatro fluxos: caixa IMAP (375), medição e privacidade (376–379), agenda e teste de captura (380–381), execução do reaquecimento (382). O contrato muda de 8.35.0 para 8.36.0. Dados persistidos continuam legíveis pela nova versão.

O impacto no implantador-base é a marcação opcional dos alvos no tema-modelo. O Core faz o fallback nos temas em uso. Emitir a orientação individual com exemplo para a página-modelo. Validar em WordPress 7.1.4 e PHP 8.3, instalação limpa, atualização direta, regressões sintéticas e conferência do executor compartilhado. Registrar à parte as observações que dependem da frota ou dos fornecedores.

O candidato 1.75.0 foi instalado no Site-Teste. O segundo incremento do mesmo ciclo é o patch 1.75.1, que torna explícitos os três campos não observados também no evento de comportamento legado, pareado ou sem navegação. A aprovação do patch exige o fechamento moderno, dois fechamentos legados, contagem zero observada e dez alvos distintos na mesma sessão. O patch de prova do destinatário foi exercitado sobre o fonte do implantador-base 2.18.0.
