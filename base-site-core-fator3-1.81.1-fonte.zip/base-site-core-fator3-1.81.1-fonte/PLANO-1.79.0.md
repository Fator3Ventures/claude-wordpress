# Site Core 1.79.0 · planejamento · 10/11/2026

Base oficial 1.78.0 (instalador SHA-256 503a07a6fc1106d1582596c96f10fa9c558fb92cea968782efe26f923b2ccce6, instalada no Site-Teste). Padrão e instruções, revisão 5, lidos por inteiro em reference/. Regra 3.1: a 1.78.0 está instalada, portanto qualquer alteração sai como 1.79.0.

Pedido do dono, 10/11/2026: analisar e testar o Core, implementar melhorias, correções e ajustes, melhorar a documentação e melhorar o layout da tela de configuração. O pedido não traz números de "Pedidos core". Os itens abaixo recebem identificadores locais desta rodada (A, B, C, D, E); a numeração da frota não foi usada.

Regra de escopo: a tela de configuração e a documentação mudam por pedido expresso. No restante entram só defeitos medidos. Nenhuma regra de produto, contrato de ability, schema de dados, option, tabela, capability ou asset público muda.

## Linha de base medida na 1.78.0

Laboratório: WordPress 7.1.4, PHP 8.3.6, MySQL 8.0.46, Apache 2.4.58. Os números ficam em evidence/1790/base-1780/ e o relatório os lê de lá.

- Suíte da 1.78.0 reexecutada sem alteração, instalação limpa e migração da 1.77.0: passa nas duas fases.
- Painel, 23 telas em 1440 px e 390 px (painel-varredura.json): sem erro de JavaScript e sem erro de PHP. Problemas: alturas de 4 a 9 mil px nas áreas de configuração e 62 mil px em Informações técnicas; estouro horizontal em 390 px em Operação e Contatos; IDs duplicados em Conexões, Informações técnicas e Operação; violações do axe em Conteúdo privado, Conexões e Operação.
- Botão Salvar (painel-salvar.json): a folha declara `position: sticky`, mas o botão fica fora da janela no topo de todas as 12 áreas com formulário.
- Habilidades de leitura executadas sem acompanhantes (abilities-fumaca.json): nenhuma exceção; três leituras chamam `wp_get_ability()` para cinco habilidades de pacotes ausentes e disparam `_doing_it_wrong`.
- Documentação instalada: o índice cita menos da metade dos .md de docs/; documentos de entrada declaram versões antigas como vigentes; há referências a arquivos que não existem e uma ability citada que não está registrada.
- Fonte: `build/reproduzir-instalador.py` gera um ZIP de mesmo conteúdo (949 arquivos, mesmos CRC) e hash diferente do entregue quando o zlib é outro; `tests/verificar-entrega.py` aponta para evidence/1740, que não existe.
- Site-Teste (leitura): 1.78.0 ativa, atualização concluída, filas sem falhas, nenhum erro do plugin no log da hospedagem desde 09/11.

## A. Tela de configuração

Contratos que não mudam: nomes dos campos (`f3base[...]`, `f3base_revisao[...]`, `f3base_apagar[...]`), `data-f3base-campo`, ação e nonce do formulário, valores de `secao` e `aba`, URLs, slugs de página, `F3Base_Admin_Tela::ordem_dos_blocos()`, capabilities, textos de ajuda do catálogo. A tela continua renderizada no servidor a partir do registro de módulos e do catálogo; o JavaScript só acrescenta comportamento e a tela funciona sem ele. Sem dependência nova e sem etapa de build: CSS e JS escritos à mão em admin/assets/.

- A1. Uma folha do painel, `admin/assets/f3base-painel.css`, com variáveis de largura, espaçamento e cor (paleta do wp-admin). Uma largura máxima para todas as peças da tela. As regras concorrentes das folhas antigas saem; o seletor global `[hidden]{display:none!important}` passa a valer só dentro de `.f3base-tela`.
- A2. Cabeçalho: título, versão e navegação de áreas num bloco. Aviso de configuração escrito para o operador, sem códigos internos crus.
- A3. Áreas com formulário: índice dos grupos da área ao lado do conteúdo a partir de 1200 px, fixo durante a rolagem; abaixo disso, índice recolhível no topo. Cada grupo vira um bloco visual próprio com âncora.
- A4. Barra de salvar fixa na base da janela durante toda a edição, com estado "alterações não salvas".
- A5. Campo: um rótulo por campo (sem `legend` e `label` repetindo o mesmo texto, sem `label for` apontando para `fieldset`); o parágrafo "Como funciona" do detalhe não repete a descrição já visível; largura do controle conforme o tipo.
- A6. 390 px: nenhuma tela do plugin com rolagem horizontal da página.
- A7. Informações técnicas: seções recolhidas com resumo; blocos `pre` com altura máxima e rolagem própria; índice no topo.
- A8. Menu lateral: uma entrada por destino.
- A9. Zero IDs duplicados e zero violações do axe (WCAG 2.1 A e AA) nas 23 telas, nas duas larguras.

Aceite, medido por tests/painel-1790.cjs contra o laboratório: A4 visível em topo, meio e fim das 12 áreas; A6 e A9 em zero; A7 abaixo de 6000 px em 1440 px; A1 com as peças principais na mesma largura (tolerância de 2 px); A5 com uma ocorrência visível do rótulo por campo; A8 com destinos únicos; campos, nomes e `data-f3base-campo` de cada área idênticos aos da 1.78.0; gravação de um campo de cada tipo conferida por releitura.

## B. Correções

- B1. Consulta a habilidades de acompanhantes passa por `wp_has_ability()` antes de `wp_get_ability()`.
- B2. Triagem dos achados do PHPCS nas regras de SQL preparado, redirecionamento, escape de saída e entrada não validada. Corrige-se o que for defeito confirmado por leitura do caminho de dados; o restante fica registrado como falso positivo, com motivo.
- B3. `build/conferir-instalador.py`: confere um ZIP contra a árvore de runtime por nome, ordem e bytes de cada arquivo, independente do compressor, e informa o zlib usado. README passa a dizer em que condição o hash do ZIP se repete.
- B4. `tests/verificar-entrega.py` aponta para o manifesto da rodada.
- B5. Índice das linhas da interface de Qualidade e Meta passa por `esc_attr()` nos atributos `id` e `name`. Origem: suspeita da triagem B2. Conferido em execução que as interfaces do produto só gravam índice numérico; a gravação interna aceita chave de texto.

Resultado da triagem B2: nenhum defeito confirmado nas regras de SQL preparado, redirecionamento, escape e nonce. O registro completo está em evidence/1790/triagem-phpcs.md.

## C. Documentação

- C1. `docs/DOCUMENTACAO.md` como índice completo: mapa dos oito documentos lógicos do padrão (seção 7.1) para os arquivos reais, documentos vigentes por assunto, especificações por domínio, histórico de releases e dados. Todo .md de docs/ aparece no índice. Nenhum arquivo muda de caminho: os caminhos são identificadores lidos por agentes.
- C2. Documentos de entrada descrevem a versão instalada: README, INSTRUCOES-DO-PLUGIN, CONTRACTS, OPERACAO-E-RECUPERACAO, VALIDACAO. GUIA-PAINEL reescrito para a tela nova.
- C3. `docs/REFERENCIA-ABILITIES.md` gerado do registro: as habilidades por domínio, com rótulo, leitura ou escrita e parâmetros obrigatórios. Gerador em build/ e teste que falha quando registro e documento divergem.
- C4. Referências a arquivos inexistentes e ability não registrada corrigidas.
- C5. AGENTES-1.79.0.md, RELEASE-1.79.0.md, CHANGELOG e docs/dados com a versão nova.
- C6. No fonte: README e tests/README descrevem só a rodada vigente; o histórico fica identificado como histórico.
- C7. `docs/dados/abilities-*.json` gerado do registro por `build/gerar-catalogo-abilities.php`, com conferência na suíte. Acrescentado durante a implementação: os arquivos herdados eram uma captura da visão MCP feita na 1.72.1, com uma ability ausente e quatro listas de options desatualizadas, e cada release só regravava o campo de versão do topo.

## D. Gravação pela tela (itens acrescentados durante a implementação)

Os dois defeitos abaixo foram encontrados ao testar a tela nova e reproduzidos na 1.78.0 intocada (evidence/1790/base-1780/painel-gravar-sem-alteracao.json e painel-aceite-contra-1780.json). Entram como correção de defeito.

- D1. Em Coleta do site, Conteúdo e IA e SEO, todo envio do formulário era recusado. Seis options estruturadas sem editor (`f3base_campanhas_origem`, `f3base_contexto_sessao`, `f3base_canais_organicos`, `f3base_origens_ia`, `f3base_marcas_vigiadas`, `f3base_redirects`) saíam como campo de texto; o texto era recusado e a recusa de um campo impede a gravação da área. Correção: `F3Base_Admin_Entrada::sem_editor()` decide; essas options saem do contexto do formulário e aparecem como bloco somente leitura com o valor atual e a habilidade que as altera. Editor para elas é funcionalidade nova e fica fora da rodada.
- D2. A tela grava grupos por diferença e a recusa era avaliada só sobre as chaves alteradas. Em quatro options a regra exige o valor inteiro e toda alteração era recusada: `f3base_conversoes_conteudo`, `f3base_conversoes_transporte`, `f3base_navegacao`, `f3base_gsc_consultas`. Correção em `F3Base_Config_Mescla::escopo()`, no mecanismo que já existia para outras três options. A enumeração de todos os pares (option de grupo, chave) virou checagem permanente.

## E. Release

Versão 1.79.0. Contrato administrativo inalterado. Suíte: tests/run-1790.py (instalação limpa, migração direta da 1.78.0, pedidos-1790, regressões 1780, 1770 e 1760, fumaça das habilidades, conferência da referência e do catálogo, desinstalação e reativação) e tests/painel-1790.cjs. Cada checagem nova é provada por mutação: o defeito volta para a árvore real e a checagem precisa acusar.

Não reexecutável neste ambiente: o roteiro tests/INTEGRACAO-1780.md, que depende dos ZIPs de Yoast, PublishPress Authors e WP Super Cache. Os quatro arquivos PHP alterados na 1.78.0 para essas fronteiras são conferidos por hash contra a base; se algum mudar, a prova volta a ser exigida.

Site-Teste: leitura do estado e da documentação pelo conector. A instalação da 1.79.0 no site compartilhado fica com a frota: o conector desta sessão não transporta o ZIP de 4 MB. Enquanto essa homologação não ocorrer, a entrega sai `com-pendencias`.

Impactos em outros pacotes: nenhum identificado no planejamento. Escopo avaliado: abilities e schemas (inalterados), options e tabelas (inalteradas), assets públicos (bytes idênticos), contrato com o Implantador (inalterado). O encaminhamento aberto na 1.78.0 para o Implantador permanece como está em impactos/.
