# Operar o Fator3 Site Core 1.72.0

Use `f3base/documentacao-ler` para obter o índice. Leia RELEASE-1.72.0.md, MEDICAO-DESEMPENHO.md e VITAIS-VERSAO.md pelo mesmo canal. Exemplo de paginação: informe `arquivo=docs/VITAIS-VERSAO.md`, `linha=1` e `limite=10`. Siga em `proxima_linha`, conferindo a versão e o SHA-256 em todas as respostas.

Para conhecer a cobertura use `f3base/vitais-ler` com `{"dias":28,"somente_resumo":true,"versao_origem":"sem_versao"}`. Repita com a versão do Core e o mesmo período. O campo representa o código identificado na visita, independentemente do instante em que o servidor recebeu o lote. Um perfil autenticado com permissão de manutenção lê esses relatórios.

Confira os arquivos gerados pelo Core em `f3base/ativos-publicos-ler`. Para medir custo no servidor use sondas autorizadas em série separada do tráfego normal. Confira a operação por `f3base/saude-ler` em modo compacto. O ciclo precisa concluir e confirmar o novo esquema de vitais. Para intervenções de recuperação consulte OPERACAO-E-RECUPERACAO.md.
