# Agentes — Core 1.70.0

Leia as duas normas revisionadas do projeto, DOCUMENTACAO.md, RELEASE-1.70.0.md e GUIA-PAINEL.md. Base 1.69.0 e contrato administrativo 8.32.0. A prévia administrativa de troca do LinkedIn guarda a seleção pretendida por usuário e integração por dez minutos. Após revisão desatualizada, refaça a prévia. Confirme a finalidade antes de importar contatos ou modificar assinaturas. Os formulários centrais recusam campos ausentes e preservam opções intocadas.

Exemplo de leitura MCP: execute f3base/documentacao-ler com arquivo docs/GUIA-PAINEL.md, linha 1 e limite 20. Continue em proxima_linha com o mesmo arquivo e confira a versão e o hash. Um administrador pode ler o guia no painel local. Para abrir uma tela, use o endereço gerado pelo painel; para diagnóstico operacional, use f3base/saude-ler com compacto true. O relatório externo distingue o resultado no laboratório, no Site-Teste e os itens pendentes da frota.
