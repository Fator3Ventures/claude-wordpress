# Operação do Core 1.74.0

Consulte docs/RELEASE-1.74.0.md por f3base/documentacao-ler. Para investigar o pedido 374, releia f3base_meta_lead e f3base_meta_transporte em f3base/config-core-ler. Na tela Meta altere uma única opção e confira o recibo após salvar. Um conflito de revisão pede nova leitura da opção apontada. A credencial real de CAPI é digitada pelo dono no wp-admin. O operador confere a presença mascarada e testa o transporte separadamente. Uma entrega à Meta requer recibo do fornecedor.

Para marcar um Lead, descubra meta-lead-enviar, simule com motivo, aplique com a revisão esperada e consulte o recibo. O contrato vigente é 8.35.0.
