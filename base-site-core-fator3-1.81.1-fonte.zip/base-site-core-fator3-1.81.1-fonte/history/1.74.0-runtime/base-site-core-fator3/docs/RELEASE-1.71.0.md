# Fator3 Site Core 1.71.0

Base de atualização 1.70.0. Requer WordPress 7.1.4 e PHP 8.3. O contrato administrativo 8.33.0 acrescenta os denominadores por fase à resposta de f3base/vitais-ler e permite pedir somente contagens e p75 com somente_resumo. O painel usa essa consulta reduzida.

O registro PHP carrega os inicializadores necessários ao contexto da página. Uma operação que precisa das capacidades completas promove o registro durante a requisição. O login mantém seu perfil dedicado. A sonda detalhada deixa de executar na página pública e no login anônimos comuns. As sondas assinadas registram eventos específicos, agrupam apenas formas SQL reconhecidas e verificam que a resposta pertence à requisição atual.

No navegador, o conteúdo do diálogo de consentimento é montado na primeira abertura, e o botão de rodapé prepara suas cores perto da área visível. A decisão de consentimento está disponível desde o início. O formulário verifica os nós novos quando há mutações relevantes.

O relatório de vitais separa zero de ausência. O p75 usa as observações elegíveis e a fase dominante exige fases comparáveis. Veja MEDICAO-DESEMPENHO.md para os campos, permissões, retenção e limites. Verificação administrativa: Site Core → Configurações. Guia operacional do painel: GUIA-PAINEL.md.

A migração utiliza o ciclo nativo e conserva dados e configurações. O nível de contrato identifica os novos campos do resultado. As tabelas e a configuração do operador seguem a estrutura da base.
