# Fator3 Site Core 1.72.1

A versão 1.72.1 corrige a apresentação duplicada do painel de relatórios no WordPress. A atualização direta parte da 1.72.0 e mantém o contrato administrativo 8.34.0. Os requisitos são WordPress 7.1.4 ou superior e PHP 8.3 ou superior.

## O que mudou no painel

Na 1.72.0, ao abrir **Site Core → Relatórios → Técnico** e selecionar **Web Vitals por versão** em **Análise**, o administrador podia ver duas cópias dos filtros e da tabela na mesma página. O menu original de Medição e o submenu Relatórios registravam funções diferentes no mesmo gancho `toplevel_page_f3base-medicao`. As duas funções acabavam renderizando o mesmo painel.

Na 1.72.1 os dois registros usam a mesma função. O WordPress executa o painel uma vez. O endereço `admin.php?page=f3base-medicao&area=tecnico&visao=vitais` abre a visão diretamente e exige a capacidade `manage_options`. A visão de qualidade continua acessível no mesmo menu.

## Instalar e conferir

1. Instale o ZIP da 1.72.1 pelo painel de plugins. Na atualização, parta do instalador 1.72.0 já em uso.
2. Com uma conta administradora, abra **Site Core → Relatórios → Técnico** e selecione **Web Vitals por versão**. Confira que há um painel, um campo **Versão de origem** e uma tabela de métricas. Aplique um filtro e confira novamente.
3. Consulte `f3base/saude-ler` para identificar a versão em execução e a conclusão de seu ciclo. A correção usa o esquema de dados da 1.72.0. A coluna `versao_origem` e seu índice foram introduzidos na 1.72.0. As amostras e suas versões registradas permanecem disponíveis.

No teste comparativo, use a mesma rota, os mesmos dados e um administrador com as mesmas permissões. A 1.72.0 reproduz a duplicação e a 1.72.1 deve mostrar uma única cópia. Essa contagem verifica a renderização do painel. Para interpretar o p75 e os denominadores do tráfego, consulte VITAIS-VERSAO.md.
