# Agentes — Core 1.65.1

Leia RELEASE-1.65.1.md e DOCUMENTACAO.md antes de operar. A 1.65.0 é base imutável; não reduzir P2 a melhoria futura. Contrato 8.30.0 e mínimos WordPress 7.1.2/PHP 8.3.6 preservados. Testar o ZIP exato e registrar recibos. Não confundir código implementado com aceite de fator3.com.br ou 24 horas na frota.

354: medir três gerações PHP, distinguir cache CTA frio/quente, informar raízes e bytes por fase e conferir HTML. 362: primeira cópia da home depois da atualização deve usar wp-content/f3base-publico/; manifesto vigente antecede confirmação/prova. Falha de publicação mantém ciclo/prova pendentes. P2: sem recurso não baixar seu módulo; conteúdo dinâmico e eventos durante carga devem conservar instância/horário/consentimento. Testar primeiro uso e saída precoce.

Não usar perfis simulados como prova de uma conexão remota de baixa permissão. Não enviar conversões sintéticas a campanhas reais. Não alterar cron do servidor, credenciais ou dados de contato para medir. Estado derivado do cache expira em uma hora; arquivos públicos antigos duram 30 dias. Relatório externo é a fonte dos hashes e resultados da rodada.
