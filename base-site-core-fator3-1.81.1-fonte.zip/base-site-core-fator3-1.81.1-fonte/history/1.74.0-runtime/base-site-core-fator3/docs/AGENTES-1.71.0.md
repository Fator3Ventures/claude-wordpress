# Operação do Core 1.71.0

Leia DOCUMENTACAO.md, RELEASE-1.71.0.md e MEDICAO-DESEMPENHO.md. Execute f3base/documentacao-ler para listar os arquivos autorizados. Para leitura paginada, informe arquivo, linha e limite, continue em proxima_linha e confira versão e hash em todas as páginas.

Para medir, separe o tempo até o primeiro byte, a janela de geração PHP e o tempo instrumentado do Core. Confira cache, rota, dispositivo, perfil e amostra antes de comparar. Registre os denominadores ao interpretar p75. A visita sintética precisa de identificação de teste quando a rota coleta eventos. As sondas de perfil ficam em uma série separada das requisições cronometradas.

Valide a saúde por f3base/saude-ler e confirme a versão do código, o ciclo e os plugins ativos. Na recuperação utilize os procedimentos documentados em OPERACAO-E-RECUPERACAO.md. Para informações do laboratório, consulte o relatório externo e o diretório evidence/1710 do fonte.
