# Fator3 Site Core 1.65.1

Correção do mesmo ciclo; base imutável 1.65.0 e contrato administrativo 8.30.0. Preservados slug, basename, namespaces, tabelas, contatos, integrações e escolhas de consentimento/fornecedores. As regras 354/360/361 e Clarity da 1.65.0 continuam; orçamento CLI de 30 a 600 segundos, padrão 120. A base histórica da 1.65.0 é 1.64.0.

## 354(h–j) — profundidade e cache de CTA

A profundidade aumenta no último filtro pre_render_block, somente quando o bloco não foi substituído por outro filtro, e diminui em render_block. Chamadas internas de do_blocks não reiniciam a contagem. Só a raiz efetiva e o template-part de área header passam pelo carimbo; conteúdo recebe sua passada final no the_content. Não se usa mais pai nulo para inferir raiz. Menu e superfícies explícitas mantêm seus contratos.

O resultado de the_content pode ser reaproveitado entre requisições anônimas públicas. A chave reúne versão do algoritmo/plugin, SHA-256 do conteúdo, revisão de f3base_contato, configuração/superfície e geração de invalidação. Cache de objeto persistente quando disponível; transiente WordPress caso contrário; expiração de até 3600 segundos. Conteúdo autenticado, administrativo, preview, protegido por senha ou maior que 1 MiB não entra no cache persistente. Erro do parser não é memorizado entre requisições. save_post e adição/alteração/remoção de f3base_contato trocam a geração; entradas antigas vencem sem varredura ilimitada. Estado interno f3base_cta_cache não é configuração operável.

A primeira visita elegível após invalidação pode gravar o transiente. Visitas com cache aquecido só o leem. A memória da requisição continua limitada a 128 entradas e 2 MiB. desempenho-ler acrescenta raízes/cabeçalhos processados, profundidade restante e, por fase, chamadas, bytes de entrada/hash/parse/saída, acertos e gravações de cache. Bytes indicam trabalho da fase, não tráfego de rede. O total próprio de até 100 ms em três amostras de fator3.com.br exige medição nesse site; fixtures locais não substituem esse aceite.

## 362 — publicação antes da confirmação

A migração prepara e verifica arquivos e manifesto públicos. O executor não grava confirmada_no_executor_em sem manifesto da versão e revisão vigentes; registra hash e horário da publicação confirmada no ciclo. A prova pós-atualização verifica a mesma condição antes de sondar cabeçalhos/cache e reagenda se a publicação não estiver disponível. Arquivos imutáveis antigos continuam preservados por 30 dias. Falha de disco, revisão concorrente ou trava ocupada conserva a atualização pendente, sem confirmar prematuramente. A visita normal mantém a reserva inline quando necessária e marca DONOTCACHEPAGE enquanto o manifesto não estiver vigente, impedindo que o WP Super Cache congele essa reserva durante a troca. Não compila arquivos durante a visita.

## P2 — recursos por presença

A análise comum mantém transporte, recibos e a ponte pequena para eventos ocorridos durante carga. A análise específica de formulário e o módulo de ofertas têm arquivos separados. Renderização PHP declara os recursos presentes e escolhe uma das quatro composições prontas de análise (nenhum, formulário, oferta, ambos). Assim, a presença conhecida não exige uma cadeia de downloads. SCRIPT_DEBUG/falta de composição conserva os arquivos independentes.

Conteúdo inserido no navegador é detectado por observação de DOM e eventos delegados; cada módulo é solicitado uma vez, com repetição limitada para falha de carga. A API síncrona f3baseOfertas conserva contexto, instância e frequência antes da chegada do módulo. A ponte retém somente detalhes técnicos, horários e identificadores autorizados, sem copiar valores dos campos. Abertura/fechamento, primeiro foco/input e saída antes do download são reconciliados pelo coletor existente. Revogação descarta observações pendentes. O arquivo legado f3base-ofertas.min.js permanece para HTML antigo em cache.

O código funcional de formulário continua independente, carregado quando o formulário é renderizado. CSS permanece condicionado. A medição usa um IntersectionObserver compartilhado. Digitação atualiza apenas o campo lógico alterado; mudanças no DOM invalidam a associação dos campos, e encerramento faz reconciliação completa de valores atuais para preservar autofill e alterações programáticas. Não há nova amostragem nem retirada de eventos.

## Operação, reversão e evidência

Não há nova tabela/coluna nem mudança de contrato de fornecedor. A adição de diagnóstico é compatível. Rollback de arquivos para 1.65.0 preserva dados, mas devolve a ordem anterior de confirmação e os módulos antigos. Não restaurar banco apenas para reverter código. Após troca de versão, conferir a primeira cópia da home, manifesto e recibo de atualização, sem antecipar a prova de cache.

Consulte relatório externo para hashes, instalação e testes efetivamente executados. Ensaios com coletores simulados não comprovam SDK, replay ou entrega comercial. Acompanhamento por 24 horas na frota, navegadores internos e medições de produção exigem observação real; não são dispensados por esta implementação.
