# Core 1.73.0 — pedidos 371, 372 e 373

06/11/2026 · Contrato administrativo 8.35.0. Base: 1.72.1. PHP mínimo 8.3; WordPress mínimo 7.1.4.

## 371 — Lead da Meta por marcação

`f3base_meta_lead` define `modo: imediato|agente` (padrão imediato) e `formularios`, mapa de IDs para um dos modos. A escolha é fotografada no contato novo. A gravação usa a configuração normal com simulação e revisão; não marca nem envia contatos existentes. Em modo agente, o aceite continua criando o contato, mas a resposta suprime o Lead no Pixel e o agendamento automático na CAPI. Outros destinos mantêm suas regras.

No aceite de formulário, somente com publicidade permitida, o Core guarda um snapshot cifrado de fbc, fbp, IP e user agent do visitante, external_id, página, instante e event_id. Se fbc estiver ausente, o fbclid capturado gera fbc. A marcação administrativa nunca usa o IP ou user agent de quem executou a rota. E-mail, telefone e external_id entram no payload em SHA-256 normalizado; IP, user agent, fbc e fbp seguem o contrato CAPI sem hash. Não há consulta externa na captura.

### Operação pelo agente

1. Leia `f3base/leads-registros-ler` e sua revisão. Contato suspeito deve ser aprovado pelo fluxo já existente.
2. Chame `f3base/meta-lead-enviar` com `record_id` e `motivo`. O padrão é `simular:true`; a prévia retorna event_id, event_time, revisão e janela, sem escrever ou enviar.
3. Execute com os mesmos campos, `simular:false` e `revisao_esperada` inteira. O operador autenticado e o motivo são persistidos antes do enfileiramento. A rota exige `manage_options`.
4. O executor CAPI envia a ocorrência pelo servidor. Consulte `meta_lead` em `leads-registros-ler` e `lead-jornada-ler`, ou `f3base/meta-entregas-ler` com `modo:eventos`. A repetição retorna o recibo existente, sem novo evento.
5. Para resultado incerto, descubra e simule `f3base/capi-reconciliar`; preserve o event_id e confirme a decisão antes de retomar. Não recrie contatos para repetir efeitos.

Exemplo de prévia:

```json
{"record_id":"0123456789abcdef0123456789abcdef","motivo":"Contato conferido pelo operador","simular":true}
```

A rota preserva `action_source:website`, o instante original e a página de envio. Event_id é o mesmo da aquisição/Pixel. A janela nunca excede sete dias e ainda respeita `f3base_meta_janela`: sem conferência vigente, vale o limite conservador de uma hora; no transporte ambos aplica-se também a janela de deduplicação e a margem existente. Fora da janela retorna `meta_janela_encerrada` e não envia. Não se muda event_time para contornar o prazo.

Contato sem snapshot cifrado (inclusive histórico anterior à versão), sem publicidade permitida, excluído, removido ou ainda suspeito permanece sem envio. A resposta identifica a condição e a ação cabível. Não se inventa correspondência histórica. Trocar a política de modo não modifica contatos já capturados. Retenção e eliminação acompanham os dados do contato; eliminação continua cancelando entregas pendentes.

Para homologar, configure token/dataset/transporte, permita CAPI de teste em `f3base_testes` com `capi_test_event_code` e use contato marcado como teste. A aceitação local da fila não comprova recebimento nem qualidade de correspondência no Gerenciador de Eventos.

## 372 — Credencial CAPI

O token gerado no Gerenciador de Eventos é aceito para gravação cifrada, tanto na tela quanto em `config-core-escrever`, sem exigir `ads_management`, `/debug_token` ou leitura do Pixel. Salvar não produz evento. O aviso `capi_validacao_por_evento_pendente` permanece: a prova relevante é a resposta de um evento no dataset configurado. Formatos fora do padrão são avisos; tipo, tamanho e caracteres inseguros continuam sujeitos às validações de armazenamento.

A rota de verificação da credencial informa esse limite, sem simular aprovação do fornecedor. Consulte o recibo CAPI para HTTP/estado e confirme o evento no dataset. Falha de envio não remove a credencial salva.

## 373 — IMAP e avisos técnicos

`f3base_avisos_tecnicos.imap_codigos_passageiros` permite configurar, com simulação/revisão, os códigos que aguardam `imap_falhas_consecutivas` OU `imap_sem_leitura_minutos`. Os valores existentes de cada site são preservados.

Padrão da lista: resposta incompleta, transporte indisponível, tempo esgotado, TLS interrompido, DNS indisponível, prazo excedido, escrita incompleta e literal incompleto, nos códigos `imap_*` do leitor. Autenticação, senha/credencial, pasta e mailbox continuam exigindo ação imediata mesmo se incluídos indevidamente nessa lista. Outros códigos não listados continuam imediatos.

Sem incidente aberto não existe recuperação a avisar. Após abertura, a recuperação exige nova leitura completa e aviso de atenção previamente aceito; repetições não duplicam mensagens. A saúde usa os mesmos limites do alerta.

## Limites de validação

Provas locais: WordPress 7.1.4, PHP 8.4.27, MariaDB 11.8.6, com HTTP e e-mail externos interceptados. PHP 8.3, recebimento/EMQ em conta Meta real e queda real da DreamHost exigem homologação própria. A referência oficial de parâmetros retornou HTTP 429 durante esta rodada; a implementação mantém o teto e a conferência operacional existentes. Referências: https://developers.facebook.com/docs/marketing-api/conversions-api/parameters/server-event e https://github.com/facebook/capi-param-builder.

Sem novo schema de tabelas, sem downgrade. Configuração padrão não ativa marcação, troca token, envia histórico nem altera limites já escolhidos.
