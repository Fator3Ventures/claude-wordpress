# Fator3 Site Core 1.68.0

Base canônica imutável 1.67.0. Contrato administrativo 8.31.0, extensão aditiva. Pedidos 368–370; regressões 365/366/367 preservadas. WordPress mínimo 7.1.2, PHP mínimo 8.3.6. Nenhuma concessão, conta, token, destino ou seleção existente é ampliada na instalação.

## 368 — duplicidade e conflitos LinkedIn

As bordas das respostas textuais usam trim do PHP antes de persistir papéis e resposta nativa. Espaços internos e multisseleção permanecem. A comparação de valores textuais históricos também ignora bordas; não reescreve o registro antigo, inclusive na lixeira. A identidade continua conta/formulário/resposta/submittedAt em milissegundos.

Conflito real persiste ocorrência cifrada na tabela existente f3base_linkedin_webhook, tipo ocorrencia. Contém código, identidade, conta, formulário, resposta, instante nativo e nomes dos campos divergentes, sem valores digitados. O registro original permanece intacto. Retorno conteudo_conflitante_registrado com ok=true permite continuar a página. Falha ao salvar a ocorrência retorna ocorrencia_nao_persistida e não confirma a página. Repetições usam chave estável; últimos 50 itens e total ficam em anuncios-verificar/LinkedIn. Estado, backup e preservação na desinstalação seguem o diário existente.

O cliente SDK grava ultima_falha.codigo/em no cursor; resultados de formulário e integração propagam código, contagem de ocorrências e inclusões ao resumo de Execuções. O cliente direto conserva suas janelas e recebe o mesmo tratamento de conflitos. Uma ocorrência tratada não é falha de transporte. Não há reenvio comercial nem criação de outro contato para a mesma identidade.

## 369 — formulários automáticos LinkedIn

Campo opcional formularios_modo em cada integração: selecionados (padrão quando ausente) ou todos_conta_autorizada. A seleção automática exige cliente linkedin_plugin e LinkedIn 0.15.0 ou posterior com linkedin-lead-reader/1.2.0. O cliente Core direto continua com lista explícita; não é trocado automaticamente. Conexão e grant no produtor devem autorizar all_forms_accounts, quatro permissões metadata/responses/verify/subscriptions e a URL HTTPS do callback deste site. O recebimento imediato deve estar ligado no Core.

Painel Conexões → LinkedIn → Seleção de formulários e ability f3base/linkedin-formularios-configurar usam a mesma operação: simular=true retorna revisão e confirmação vinculada a configuração, concessão, credencial e administrador. Aplicar exige ambas; alteração posterior recusa a confirmação. Somente uma integração ativa pode abranger todos os formulários de uma conta. Voltar à lista explícita conserva recibos e cursores; para encerrar a descoberta/assinaturas no produtor, altere também a concessão lá. Alterar seleção não drena nem recria assinaturas equivalentes.

O hook f3_linkedin_lead_form_discovered agenda uma passagem. Os dados vêm de list_form_events pela API pública; um hook forjado não incorpora seleção. O Core guarda checkpoint por consumidor/conexão/conta, revisões e identificador do evento, até cinco eventos por passagem, revalidando a concessão antes da gravação. Eventos antigos de outra revisão são ignorados com contador visível; a outbox do produtor reemite contexto vigente. Membership, cursor inicial e recibo da assinatura são salvos no mesmo CAS. Falha de persistência repete a página. Novas notificações autenticadas consultam a outbox antes de aceitar formulário; continuação retorna 503 para repetição.

A leitura inicial começa no maior valor entre criação do formulário e marco de importação, nunca no instante da descoberta. Recibo de assinatura do produtor (ownership_key, state, remote_effect, operation_revision) é preservado e reconciliado; não é convertido em outra chave de criação. Falha de assinatura permanece visível e a consulta periódica pode recuperar respostas já autorizadas. Metadados de inclusão e instante aparecem em anuncios-verificar; Execuções registra formularios_incluidos. Registro 1.1 continua negociável com produtores anteriores no modo explícito.

Nome de campanha: mapeamento local tem precedência; sem mapa, o nome decorado na resposta do LinkedIn é preservado. Parceiro usa o mapa existente f3base_pipedrive.parceiros_plataforma (linkedin_ads); nenhum parceiro é inventado. Uma ocorrência de campanha sem mapeamento orienta a frota. Se a resposta não trouxer nome, o 0.15.0 não oferece método público de consulta de campanha ao consumidor de leads: registra campanha_sem_nome_e_mapeamento e conserva a importação. A garantia de obter esse nome em todos os casos do item 369(d) depende da extensão solicitada no impacto ao LinkedIn; não está encerrada nesta versão. Não copiar token, ler armazenamento privado do produtor ou assumir usuário administrador em cron para contornar a limitação.

## 370 — catálogo Meta

Cada coleta renova o catálogo autorizado, com id,name,status e páginas de dez itens; perguntas são consultadas separadamente apenas para formulário novo. Formulários já conferidos continuam elegíveis durante a paginação e durante falha na atualização da lista. Cada inclusão tem incluido_em; a conclusão da varredura tem atualizado_em. Formulários ausentes só são removidos após varredura completa. Cursor ausente, repetido ou sem progresso é recusado.

Continuação volta em 30 segundos. Modo todos_paginas_autorizadas limita espera de nova tentativa a uma hora, inclusive após falha. A cadência normal de coleta continua cinco minutos. WP-Cron precisa ser executado pelo servidor; a configuração de prazo não comprova observação de um formulário real em até uma hora. Falhas de acesso ao próprio formulário continuam diagnosticadas.

## Atualização e reversão

Sem tabela ou coluna nova. Opção formularios_modo é aditiva e facultativa; estado existente e 70 tabelas preservados. Contrato 8.31.0 documenta a nova operação/campo. Reverter arquivos à 1.67.0 exige antes voltar ao modo selecionados e remover a chave opcional via operação administrativa compatível; a 1.67.0 desconhece a chave e a descoberta. Não restaurar banco ou apagar recibos para reverter. Testar cópia e manter pré-imagem.

Os aceites externos 365/366/367 continuam como recebidos; esta rodada não equivale a implantação na frota. Validar 368 com conflitos reais autorizados, 369 em ctooffice com opt-in explícito, e 370 com novo formulário real após instalação. Não gerar contatos de teste nas campanhas reais. Metas anteriores de bytes permanecem abertas. Leia relatório externo para hashes, testes efetivamente executados e implantação do ZIP exato.
