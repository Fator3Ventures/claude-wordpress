# Padrão de desenvolvimento e entrega — plugins Fator3

Revisão 5 — 02/11/2026 — fuso de referência America/Sao_Paulo.

**Alterações desta revisão:** PHP mínimo 8.3 e WordPress mínimo 7.1.4; somente a versão vigente de cada pacote; correções por nova versão, sem reversão; impactos aprofundados, com proposta executável, prova em cópia do destinatário quando viável e prontidão da parte do emissor. Mantida a emissão somente para impactos técnicos relevantes, desde o planejamento. Substitui a revisão 4, de 16/10/2026, incorporando as instruções do usuário de 02/11/2026.

Aplicável aos responsáveis por Fator3 Site Core, Fator3 MCP, Fator3 MCP Google, Fator3 MCP Meta, Fator3 MCP LinkedIn e Fator3 Implantador. Este documento estabelece instruções comuns para as próximas rodadas. Sua criação não altera os plugins instalados.

**Origem das regras:** nomenclatura, artefatos por rodada, impactos individuais, documentação instalada, ambiente de testes, compatibilidade e incremento de versão decorrem da solicitação do usuário. Os detalhes de empacotamento, evidência, descoberta e coordenação abaixo operacionalizam essas exigências e preservam decisões anteriores do projeto.

**Referência adicional incorporada na revisão 4:** o usuário forneceu `Regra comum.md`, intitulado “Padrão de entrega dos pacotes Fator3”, datado de 16/10/2026. A revisão 4 registra sua leitura integral e conciliação, com o endereço Claude inacessível e sem afirmar acesso às demais abas remotas. A revisão 5 preserva esse histórico e aplica as novas instruções aos dois documentos centrais disponíveis nas fontes do projeto; não altera aquele anexo.

## 1. Aplicação e precedência

1. Antes de iniciar planejamento, implementação, revisão, teste ou entrega, localizar nas fontes do projeto e ler integralmente as revisões vigentes deste padrão e de `instrucoes-agentes-plugins-fator3.md`. Informar nomes e revisões efetivamente lidos na primeira atualização. Aplicar também o pedido específico, a regra comum mantida por “Site Geral | Todos”, a aba do pacote e os contratos vigentes. Em divergência entre os dois documentos, prevalece este padrão completo; instrução explícita posterior do usuário prevalece sobre ambos. Se algum documento estiver indisponível, incompleto ou com revisões conflitantes, registrar a pendência e prosseguir somente nas atividades independentes, sem declarar conformidade não verificada.
2. Uma instrução explícita do usuário para a rodada prevalece sobre o padrão. Registrar a exceção, o motivo e quais artefatos/testes ela afeta; não solicitar novamente uma autorização já concedida.
3. Cada agente mantém a release oficial do plugin sob sua responsabilidade. Mudanças necessárias em outro plugin devem ser aprofundadas no relatório de impacto correspondente. Está autorizada a alteração de uma cópia isolada do código destinatário para implementar e testar a proposta, conforme seção 6.4. A incorporação à release oficial, publicação e instalação compartilhada seguem a atribuição e a autorização operacional existentes. O pedido do usuário para atualizar estes documentos autoriza a revisão das regras centrais.
4. Preservar IDs de tarefas, decisões de arquitetura, permissões e contratos não alterados pelo escopo.
5. Distinguir requisito planejado, código implementado, prova local, prova em WordPress real e homologação no fornecedor. A presença de código ou de uma ferramenta descoberta não prova acesso externo.
6. Classificar a rodada como implementação, correção, homologação ou planejamento. Rodadas que produzem uma nova versão de software devem entregar o conjunto completo da seção 4. Em revisão de um candidato, manter todos os artefatos coerentes com aquele candidato.
7. Mesmo em rodada exclusivamente documental/de homologação, disponibilizar fonte e instalador da versão examinada, quando disponíveis, junto ao relatório e aos impactos pertinentes conforme a seção 6; identificá-los como base sem alteração. No planejamento, os impactos não dependem da existência do instalador da versão-alvo. Não inventar binários, renumerar software sem alteração ou declarar uma implementação inexistente. Se a base não estiver acessível, registrar exatamente o artefato faltante e a pendência da entrega.

A atualização exclusiva destes documentos centrais entrega apenas os documentos revisados e sua verificação de coerência; não exige pacotes, relatórios de release ou incremento da versão de software.

## 2. Identidade e nomenclatura

### 2.1 Identidades estáveis

| ID de coordenação | Nome do plugin | Slug/pasta estável |
|---|---|---|
| core | Fator3 Site Core | `base-site-core-fator3` |
| mcp | Fator3 MCP | `wp-mcp-fator3` |
| google | Fator3 MCP Google | `wp-mcp-google-fator3` |
| meta | Fator3 MCP Meta | `wp-mcp-meta-fator3` |
| linkedin | Fator3 MCP LinkedIn | `wp-mcp-linkedin-fator3` |
| implantador | Fator3 Implantador | Confirmar no pacote instalado/aba do responsável; não inventar ou renomear |

O anexo inclui o Implantador, mas não informa seu slug nem basename: o responsável deve registrar esses valores existentes antes de gerar arquivos ou impactos destinados a ele. Preservar o basename principal já publicado, identidades de atualização, provider IDs, text domains, namespaces, tabelas, options, hooks e nomes de abilities. Não renomear essas interfaces apenas para uniformizar a aparência. A pasta interna do instalador permanece o slug, sem versão; duas pastas para o mesmo plugin causam duplicidade de instalação.

Novos arquivos de entrega: minúsculas, ASCII, hífens, sem espaços, acentos ou sufixos como `final`, `novo`, `corrigido`, `(1)` ou `(2)`. Cópias renomeadas pela plataforma não alteram a identidade: confirmar versão e SHA-256. Referências a software entregue devem incluir slug, versão e hash do instalador. No planejamento, identificar slug, versão-base e versão-alvo prevista; citar o hash da base quando disponível e registrar o instalador-alvo como ainda não gerado, sem exigir ou inventar seu hash.

### 2.2 Arquivos de entrega

Usar `<slug>` da tabela, `<versao>` no formato `X.Y.Z`, sem sufixo, e `<destino>` igual ao slug existente do pacote destinatário. Homologação, validação, tentativa e hash ficam nos metadados/relatório, não no nome público da versão.

| Artefato | Nome | Obrigação |
|---|---|---|
| Fonte completo | `<slug>-<versao>-fonte.zip` | Principal, obrigatório |
| Instalador WordPress | `<slug>-<versao>-instalador.zip` | Principal, obrigatório; único ZIP instalável |
| Relatório da rodada | `<slug>-<versao>-relatorio.md` | Principal, obrigatório, em português |
| Impacto individual | `<slug>-<versao>-impacto-<destino>.md` | Obrigatório somente para destinatário com impacto técnico relevante; desde o planejamento, conforme a seção 6 |
| Manifesto externo | `<slug>-<versao>-manifesto.json` | Complementar, quando útil à automação |
| Checksums | `<slug>-<versao>-sha256.txt` | Complementar, quando útil à conferência em lote |

Os três artefatos principais são autossuficientes. Manifesto/checksums não substituem nome, tamanho e SHA-256 do fonte e do instalador no relatório. Complementos devem acrescentar função, como automação ou encaminhamento individual, sem reproduzir integralmente os artefatos principais. Nenhum ZIP contém outro ZIP da entrega.

Markdown é o formato canônico dos relatórios. HTML/PDF podem ser representações adicionais, sem substituir o Markdown. Cada pacote possui seus próprios fonte, instalador e relatório, inclusive quando um agente produz dois pacotes. O plano e o relatório trazem referências aos impactos pertinentes, quando houver; os detalhes ficam nos respectivos arquivos, sem duas cópias independentes do mesmo texto. Sem impacto relevante identificado, basta registrar essa conclusão e o escopo avaliado no plano/relatório, sem arquivos individuais nem matriz vazia.

Exemplo de impacto: `wp-mcp-linkedin-fator3-0.2.0-impacto-base-site-core-fator3.md`. A versão é a versão-alvo do emissor, identificada como prevista no planejamento; as versões do destinatário examinadas aparecem dentro do documento. Manter o mesmo documento durante o ciclo, atualizando etapa e revisão. Se a versão-alvo do plano mudar, atualizar nome e referências, preservando o vínculo com o encaminhamento anterior. O relatório cita sempre o nome final exato dos arquivos recebidos pelo dono. Versão já publicada não é renomeada retroativamente para aderir a este padrão.

### 2.3 Identificadores técnicos novos

Usar identificadores estáveis e específicos do domínio; manter os prefixos públicos existentes: `f3base/*` no Core, os namespaces administrativos registrados no MCP, `google/*`, `ga/*`, `gsc/*`, `ads/*`, `gtm/*` e `siteverification/*` no Google, `meta/*` e `linkedin/*` nos sociais. A lista Google descreve a base examinada; o catálogo vivo é a autoridade de descoberta.

Novas operações devem ter nomes que expressem ação e objeto, seguindo a convenção do namespace existente. Não criar aliases conflitantes, executor irrestrito ou nomes iguais com semânticas diferentes. Não confundir um prefixo de ability com o provider ID completo do plugin.

### 2.4 Cabeçalho e tela administrativa

| Campo | Regra |
|---|---|
| Plugin Name | Nome exibido da tabela, começando por `Fator3` |
| Plugin URI | `https://github.com/Fator3Ventures/claude-wordpress` |
| Description | Descrição específica da aba do pacote: função e local de configuração; não copiar a de outro pacote |
| Version | `X.Y.Z`, igual à versão dos arquivos |
| Requires at least | `7.1.4` — mínimo de WordPress definido pelo usuário |
| Requires PHP | `8.3` — mínimo de PHP definido pelo usuário |
| Author | `Fator3` |
| Author URI | `https://www.fator3.com.br` |
| License | `GPL-2.0-or-later` |
| Text Domain | Identificador atual do pacote, preservado |
| Update URI | `https://fator3.com.br/plugins/<slug>`, preservando o valor existente; não criar serviço de atualização automática |

Em Ferramentas ou no menu próprio já existente, usar o nome exibido no título. Não criar menu duplicado por padronização. A tela exige `manage_options` ou capacidade própria atribuída somente a administradores. Toda operação que lê dados de conta conectada ou grava configuração aplica a mesma restrição no servidor, tanto no painel quanto por MCP/REST; `read` não é autorização suficiente. Sanitizar dados retornados, inclusive diagnósticos e logs.

Manter slug, pasta, arquivo principal, Text Domain, Update URI, prefixos de options/tabelas/rotas e ferramentas MCP já consumidos pelos sites. Corrigir nome exibido e texto de tela sem alterar essas identidades. Se um campo está ausente, preenchê-lo; divergência de identidade publicada exige encaminhamento, não renomeação silenciosa.

## 3. Versionamento e janela de compatibilidade

### 3.1 Regra de versão do plugin

- Regra geral: `X.Y.Z` passa para `X.(Y+1).0`.
- Incrementar major ou patch somente mediante solicitação explícita do usuário.
- Exemplos aritméticos: `1.33.0 → 1.34.0`, `0.22.0 → 0.23.0`, `0.9.0 → 0.10.0`, `0.1.0 → 0.2.0`. Estes exemplos não designam a próxima versão efetiva de um projeto em andamento; conferir a base da rodada.
- A política de numeração é do projeto. O número minor não autoriza quebrar contratos públicos nem demonstra compatibilidade.
- Versão do plugin, schema de configuração, schema de dados, contratos SDK/API, revisão de documentação e identificador de build são campos distintos. Alterar somente os que realmente mudaram.
- Uma mudança incompatível deve ser declarada e coordenada para o conjunto vigente de pacotes. Não manter adaptadores ou contratos antigos apenas para suportar releases substituídas. Preservar contratos atuais fora do escopo e registrar as alterações autorizadas. Não alterar major por iniciativa própria para contornar a regra.

Antes de empacotar, conferir a mesma versão no cabeçalho PHP, constante, metadados, catálogo público, documentação da release e manifesto, quando emitido. Registrar o build de forma interna para rastrear tentativas; não usar sufixos na versão pública ou nos nomes fixos dos três artefatos.

Após instalação ou entrega declarada final, o conteúdo da versão é imutável. Qualquer correção de código/instalador exige uma nova versão, pela regra de numeração vigente. Antes da primeira instalação e da entrega final, correções no candidato podem manter a versão-alvo, atualizando build/hash e reexecutando as verificações afetadas. Relatórios externos podem receber revisão documental com histórico explícito, sem alterar os ZIPs certificados. Não corrigir uma versão instalada sobrescrevendo seu instalador sob o mesmo número.

### 3.2 Runtime mínimo e versão vigente

Os mínimos definidos pelo usuário são **PHP 8.3** e **WordPress 7.1.4**. Aplicar `Requires PHP: 8.3` e `Requires at least: 7.1.4`, além dos mesmos requisitos em documentação, dependências e configuração de build/testes. Não desenvolver, manter ou testar suporte a versões inferiores; não acrescentar polyfills, caminhos alternativos ou dependências legadas exclusivamente para essa finalidade. Uma API que exija runtime superior ao mínimo precisa de decisão explícita de requisito ou de implementação que funcione no piso adotado.

Esses números são requisitos de projeto informados pelo usuário. Sua declaração não comprova disponibilidade, instalação ou homologação do runtime. Registrar as versões efetivamente encontradas e testadas; se o piso não estiver disponível no ambiente, registrar a pendência de validação sem substituir silenciosamente os números, reduzir o requisito ou afirmar teste não executado. Versões superiores usadas nos sites entram na validação pertinente; não presumir homologação de toda versão futura.

Para cada plugin, a última versão fornecida pelo usuário como referência é a única versão vigente prevista para os sites. Um novo pacote substitui a referência anterior daquele plugin, incluindo acompanhantes. Conferir versão interna, slug e hash quando disponível; nomes de cópias ou planos não substituem essa identificação. Registrar o conjunto vigente e a origem de cada referência. Arquivos antigos podem servir de evidência histórica ou de origem de migração, sem ampliar a janela de suporte.

Não oferecer manutenção, backports, matriz de compatibilidade histórica, aliases, contratos duplos ou fallbacks destinados apenas a versões antigas do próprio pacote ou de outros plugins. Ao alterar a área pertinente, remover ou simplificar os caminhos que existam exclusivamente para esse suporte, preservando migrações necessárias, funções correntes, dados e contratos vigentes fora do escopo.

### 3.3 Instalação e atualização para a nova versão

Garantir:

1. Instalação nova em WordPress limpo, dentro dos requisitos declarados, sem exigir execução prévia de versões históricas.
2. Atualização direta da base vigente de referência para a versão-alvo, com preservação de dados, opções, credenciais, permissões, pausas e progresso.

Registrar `versao_base`, `versao_alvo`, origem da base e versão efetivamente instalada antes de implementar ou testar. A base é a origem da migração para a release nova; sua substituição encerra seu suporte operacional. Não presumir a base somente pelo maior número de um plano ou candidato. Uma base ou um salto explicitamente indicado pelo usuário prevalece.

Se o ambiente estiver em versão antiga fora da base vigente, registrar a divergência e delimitar a migração necessária para alcançar o alvo. Não ampliar automaticamente suporte histórico, impor instalação de intermediárias sem fundamento, executar atualização destrutiva ou transformar a instalação existente em instalação limpa. Pedir definição somente quando a origem ou o percurso não puderem ser determinados pelas evidências e pelo escopo autorizado.

### 3.4 Integração entre versões vigentes

Validar a combinação formada pelas versões vigentes fornecidas de todos os pacotes envolvidos. Não é obrigatório funcionar com versões antigas de acompanhantes nem testar combinações mistas de releases substituídas. A ordem de troca deve conduzir ao conjunto atual; durante a troca, uma integração pode ficar pausada até o contrato necessário estar disponível, com diagnóstico claro e preservação de filas, cursores e dados.

Detectar contratos/capacidades na operação integrada para validar o contrato corrente e controlar ausência/indisponibilidade. Não usar essa detecção para sustentar protocolos históricos. Instalação e funções próprias permanecem independentes de acompanhantes quando a arquitetura permitir; ausência de um contrato afeta somente a capacidade que o exige.

Registrar versões reais, contratos, ordem de instalação quando necessária, estado transitório e critério de prontidão do conjunto final. Não exigir produto cartesiano de versões nem declarar combinações não testadas como homologadas. Dependências nativas de WordPress/PHP/Abilities API devem ser declaradas separadamente. O emissor entrega sua integração pronta conforme seção 6.5.

### 3.5 Correção por nova versão, sem downgrade

Uma versão instalada não será revertida à anterior. Qualquer correção necessária será implementada, validada e entregue em uma nova versão. Não projetar, implementar, documentar como procedimento operacional ou testar downgrade do plugin, migrações reversas de schema, leitura por código antigo ou restauração de instalador anterior como solução de regressão.

Preservar integridade de dados, instalação segura, diagnósticos, idempotência e retomada após interrupção. Backups destinados à recuperação de dados permanecem aplicáveis; não criam compromisso de retorno à versão antiga. Havendo falha, registrar o estado alcançado, conter os efeitos do fluxo afetado e preparar a release corretiva para continuar a partir desse estado, sem duplicação de efeitos externos. Histórico Git e artefatos anteriores servem à rastreabilidade.

## 4. Entrega obrigatória por rodada

Para uma release, entregar **três artefatos principais: fonte, instalador e relatório**. Acrescentar um relatório de impacto por outro pacote efetivamente afetado, conforme a seção 6. A quantidade é variável e pode ser zero; não depende do total de plugins. Manifesto e lista de checksums são complementares. A documentação operacional integra o instalador e a árvore de runtime no fonte. Os impactos pertinentes devem existir já no planejamento da próxima versão, sem aguardar empacotamento ou implementação.

### 4.1 Fonte

O ZIP de fonte deve conter:

- Código-fonte completo do plugin e a árvore de runtime usada no instalador.
- Documentação editável e schemas que correspondem à versão.
- Scripts de build/empacotamento, instruções de reprodução e versões de ferramentas/dependências utilizadas.
- Lockfiles e informações de licença quando aplicáveis.
- Testes relevantes e fixtures sem segredos; evidências sanitizadas da rodada e instruções de execução.
- Cópia do relatório, identificada conforme a regra de fechamento da seção 4.3.

Usar uma única raiz `<slug>-<versao>-fonte/`, com diretórios documentados como `plugin/<slug>/`, `build/`, `tests/` e `evidence/`. Adaptar o build existente preservando reprodutibilidade; não reestruturar o runtime por estética. Dependências necessárias à execução devem estar incluídas no instalador ou ser um pré-requisito declarado, nunca depender de ferramenta de desenvolvimento no servidor.

### 4.2 Instalador

O ZIP deve conter somente uma raiz `<slug>/`, com arquivo principal `<slug>/<slug>.php`, runtime, assets, dependências de execução, licenças, documentação e metadados necessários. Se o basename efetivamente publicado for diferente, preservá-lo e registrar a exceção; não quebrar a identidade instalada para atender ao nome teórico. Excluir repositório Git, caches, credenciais, bancos de laboratório, ferramentas de QA, fixtures de execução e dependências exclusivamente de desenvolvimento.

Gerar a partir da árvore de runtime validada. Conferir os arquivos comuns entre fonte, instalador e instalação testada; diferenças geradas pelo build precisam estar documentadas e reproduzíveis. Atualização nativa e instalação inicial devem ser exercitadas em requisição/processo novo, conforme o mecanismo do WordPress e o contrato MCP disponível.

Nunca executar build do pacote final a partir de um diretório que contenha alterações de teste não revertidas. Código temporário de QA não pode sobreviver no instalador.

### 4.3 Identidade, relatório interno e fechamento

O relatório externo identifica instalador e fonte pelo nome final, tamanho em bytes e SHA-256. Esses campos são obrigatórios no próprio relatório. Os hashes correspondem aos bytes entregues e usados nos testes; alterar o instalador depois da homologação exige reavaliar e repetir as provas afetadas.

**Evitar a circularidade do hash do fonte:** não é possível fechar convencionalmente um ZIP que contenha, em seu relatório, o hash final desse mesmo ZIP. Adotar a sequência explícita abaixo:

1. Fechar runtime e documentação; gerar o instalador final, medir tamanho e SHA-256.
2. Preparar o relatório com resultados, pendências, encaminhamentos e identidade final do instalador.
3. Incluir no fonte uma cópia marcada “cópia anterior ao fechamento do fonte”, com referência ao nome exato do relatório externo. Nessa cópia, tamanho/hash do próprio fonte são `a preencher no relatório externo após empacotamento`, nunca valores simulados. O conteúdo funcional/evidências permanece igual ao da entrega externa.
4. Gerar o fonte uma única vez e calcular tamanho/SHA-256.
5. Completar a tabela de identidade no relatório externo canônico; não reabrir o ZIP fonte para inserir seu próprio hash. Atualizar os impactos pertinentes já emitidos com o resultado da entrega e, se usados, fechar os complementos.

Esta distinção entre cópia interna e relatório final é o ajuste técnico necessário para cumprir a cópia documental e a integridade exigidas no anexo; fica declarada nos dois relatórios. Revisões posteriores do relatório externo não alteram retroativamente a cópia congelada dentro do fonte.

Quando houver manifesto externo, registrar slug, nome, versão, build, base de migração, conjunto vigente, data/hora ISO 8601, requisitos, contratos, arquivos/tamanhos/hashes, commit quando disponível, ambiente e status. Um manifesto interno não contém hash do próprio ZIP. A lista de checksums, se emitida, inclui os artefatos e o manifesto externo, excluindo a si própria. Não inventar commit, hash ou teste.

### 4.4 Entrega ao dono e publicação pela frota

1. O agente entrega os três artefatos principais e os impactos pertinentes ao dono, com nomes finais e identidades conferidas.
2. A frota confere o SHA-256 do instalador contra o relatório e publica instalador e relatório na raiz de `https://raw.githubusercontent.com/Fator3Ventures/claude-wordpress/main/`, conforme a autorização operacional aplicável. O repositório é público; revisar os arquivos destinados a ele para segredos e dados pessoais.
3. Antes do primeiro `plugins/upload`, conferir os bytes efetivamente servidos pela URL raw e seu SHA-256. A instalação usa essa URL com `expected_sha256` e `expected_slug`, consultando o schema real da ferramenta. Se o contrato não estiver disponível, registrar o bloqueio; não omitir a verificação.
4. Na troca seguinte, a frota retira da árvore atual de `main` o instalador e relatório da versão anterior, preservando o histórico Git. Não renomear entregas antigas nem reescrever o histórico.
5. O fonte fica com o dono. Sua publicação no repositório público depende da decisão pendente 89 citada no anexo. Este padrão não autoriza publicar fonte, evidências privadas ou impactos sem destino definido.

O agente do pacote prepara a entrega; a frota responde pela publicação e distribuição. Esta descrição de fluxo não realiza nem autoriza, por si só, push, remoção, upload ou envio externo durante uma tarefa documental. Testes locais podem usar os bytes locais; a instalação via frota no WordPress compartilhado segue a verificação acima.

## 5. Relatório obrigatório da rodada

O relatório é autossuficiente, em português, e segue a ordem da regra comum:

1. **Título:** `Entrega — <nome exibido> <versao>`, seguido de revisão, data, natureza da rodada e status.
2. **De onde a versão entra:** WordPress limpo, base vigente de migração, sua origem e eventual salto definido. Declarar PHP mínimo 8.3 e WordPress mínimo 7.1.4, separados dos runtimes efetivamente testados. Não inventar uma versão intermediária ou ampliar suporte a versões antigas.
3. **Convivência:** versões dos outros pacotes efetivamente validadas e ordem de troca quando um contrato comum exigir. Quando houver impactos, relacionar somente os destinatários afetados, com classificação, situação, ticket quando existente e referência ao documento individual. Sem impacto relevante identificado, registrar essa conclusão e o escopo avaliado; lacunas de avaliação permanecem explícitas.
4. **Mudanças e evidência:** item por item, com ID exato do pedido (`Pedidos core N`, `Pedidos MCP N` etc.), problema, resultado e prova. Abranger interfaces/schemas, configuração, banco, jobs, callback, permissões e efeitos pertinentes.
5. **Instalação e prova de prontidão:** passos, rota/ability real, parâmetros, estado esperado e observado. Incluir acesso à documentação instalada, testes realizados e estado final do ambiente. Ferramenta listada não basta como prova funcional.
6. **Banco, migração e correção por nova versão:** dados gravados, migração/retomada, preservação, backup de dados e recuperação do estado para uma release corretiva. Registrar que não há downgrade nem obrigação de schema reverso; correções após instalação exigem nova versão.
7. **Pendências de validação:** o que não foi exercitado/homologado, incluindo conta real, API, navegador, instalação limpa ou mínimos de runtime; motivo e responsável.
8. **Credenciais:** nomes dos campos, tela, tipo de token/escopo/ativo e o que o dono deve preencher; nunca valores secretos.
9. **Identidade dos arquivos:** nome final, tamanho em bytes e SHA-256 do instalador e do fonte, seus links e a distinção da cópia interna anterior ao fechamento. Referenciar complementos quando houver.

Estados por item: `implementado`, `validado-localmente`, `validado-wordpress`, `homologado-fornecedor`, `pendente`, `bloqueado`, `nao-aplicavel`. São dimensões de evidência, não um único “OK”. Classificar a entrega como `apta-no-escopo-testado`, `com-pendencias` ou `bloqueada`, indicando exatamente o que pode ser usado.

Lint, fixtures, HTTP 200, registro de cron e ferramenta listada são provas específicas; não certificam sozinhos execução funcional, entrega remota ou permissão do aplicativo. Os mínimos de WordPress/PHP declarados no cabeçalho precisam da validação correspondente; se faltarem, registrar a pendência e não tratar o suporte como comprovado.

## 6. Impactos relevantes desde o planejamento

### 6.1 Quando emitir

Avaliar os efeitos sobre os outros plugins e suas fronteiras pertinentes em cada rodada. Gerar um documento por destinatário somente quando houver impacto técnico relevante para seu desenvolvimento, operação integrada ou validação. São exemplos: funcionalidade que exige adaptação; bug ou regressão que afeta outro pacote; mudança de contrato, API, schema ou comportamento; alteração de configuração, permissões, dados ou dependência; conflito de responsabilidade; ou teste coordenado necessário.

O relatório também cabe diante de risco técnico concreto que ainda dependa de confirmação ou decisão conjunta. Não é necessário haver alteração de código no destinatário: uma consequência relevante para seu uso, configuração, diagnóstico ou teste já pode justificar o encaminhamento. Consolidar os impactos da mesma versão-alvo para o mesmo destinatário em um documento.

Não gerar arquivos individuais para simples aviso de versão, repetição de status, informação sem consequência técnica relevante ou declaração de “sem ação/sem impacto”. Não existe quantidade fixa nem obrigação de relatório para todos os outros plugins. Mudanças estritamente internas, sem efeito relevante sobre outro pacote, ficam no relatório principal.

Quando não houver impacto relevante identificado, registrar brevemente a conclusão e o escopo avaliado no plano ou relatório principal. Uma interface pertinente não examinada deve constar como `nao-avaliado`, com motivo, nas pendências; isso não equivale a ausência de impacto nem exige, por si só, arquivo individual. Havendo risco concreto que precise de coordenação, emitir o encaminhamento com essa incerteza explícita.

### 6.2 Quando gerar e atualizar

1. **Planejamento da próxima versão:** registrar os impactos pertinentes assim que identificados, antes de consolidar a interface afetada. Explicitar a proposta técnica, consequências, conflitos, decisões, responsáveis e aceite. Esse registro inicial é preliminar, com prontidão e lacunas declaradas; não equivale a um encaminhamento pronto para implementação. Referenciá-lo no plano e usar protótipos/patches isolados para antecipar validações. Não esperar instalador-alvo para registrar o impacto. Antes de encaminhar a solicitação para implementação no destinatário, deixar a parte do emissor pronta conforme seção 6.5.
2. **Implementação:** aprofundar e atualizar os mesmos documentos quando mudarem escopo, contrato, dependência, risco ou decisão. Impacto descoberto durante o desenvolvimento deve ser registrado assim que identificado. Implementar e testar a parte do emissor e, quando viável, a proposta em cópia isolada do destinatário. Resolver decisões de contrato antes de consolidar a parte dependente; protótipos e atividades independentes podem prosseguir. O encaminhamento para execução deve permitir incorporar a mudança no destinatário sem exigir outra release do emissor para completar o mesmo contrato.
3. **Entrega:** atualizar os documentos pertinentes com o comportamento realmente entregue, decisões tomadas, evidências, compatibilidade, ações restantes e identidade do instalador existente. Distinguir proposta, implementação própria, patch experimental no destinatário e incorporação confirmada na release oficial do destinatário. Não emitir relatórios adicionais apenas para anunciar a nova versão.

Manter uma versão vigente de cada documento, com etapa, revisão, data e histórico conciso das decisões. Um impacto já emitido que seja resolvido, descartado ou deixe de se aplicar deve ter seu encerramento registrado no próprio documento e referenciado no plano/relatório; não apagar silenciosamente o encaminhamento nem criar outro arquivo só para informar seu encerramento.

### 6.3 Conteúdo e coordenação

| Campo | Conteúdo obrigatório |
|---|---|
| Identificação | Slug emissor, versão-base, versão-alvo prevista/entregue, destinatário, versões examinadas, etapa, data e revisão. Hash do instalador entregue quando existir; no planejamento, indicar que o alvo ainda não foi gerado |
| Etapa e situação | Etapa `planejamento`, `implementacao` ou `entrega`; situação `aberto`, `alinhado`, `resolvido` ou `cancelado`, com justificativa/evidência pertinente |
| Natureza | Desenvolvimento, bug/regressão, contrato, configuração, dados, segurança, dependência ou outra consequência técnica descrita concretamente |
| Classificação | `acao-necessaria`, `decisao-necessaria`, `validacao-coordenada`, `alerta-tecnico` ou `bloqueio`; explicar a consequência relevante, especialmente em alertas que não exigem ação imediata |
| Mudança e consequência | Comportamento atual e proposto/entregue, nomes públicos exatos, cenário afetado, risco e limites conhecidos |
| Ação ou decisão | Providência executável, arquivos/funções/contratos exatos, algoritmo ou patch/diff, responsável, ticket e aceite. Incluir alternativas e restrições quando houver decisão real de contrato |
| Proposta no destinatário | Versão/hash examinados, pontos de alteração, código/schema antes e depois, exemplos e efeitos pertinentes; patch aplicável quando viável, identificado como experimental até incorporação oficial |
| Prontidão do emissor | Código, testes e contrato já preparados; versão/hash quando existir; comportamento antes e depois da mudança no destinatário; lacunas explicitadas no registro preliminar |
| Compatibilidade e sequência | Conjunto vigente, ordem de troca e retomada, contrato exigido e dependência real; sem suporte obrigatório a versões antigas ou mistas e sem bloqueio global artificial |
| Evidência | Base da análise e incertezas; no planejamento, testes/validações previstos; na entrega, código/schema, resultados comprovados e pendências |
| Evolução | Alterações desde a revisão anterior, decisões acordadas e situação das ações de cada responsável |

O emissor descreve o que propõe, o que entregou, o que testou em cópia do destinatário e o que falta incorporar oficialmente. Um patch local validado é evidência própria; não comprova que a release oficial do outro responsável foi alterada. O destinatário recebe uma proposta técnica aplicável e responde por ticket/contrato, indicando incorporação, alternativa fundamentada, impedimento ou evidência. Conflitos devem ficar explícitos no planejamento e ser resolvidos antes da consolidação da parte dependente; a revisão de entrega confirma os contratos realmente fornecidos.

Preparar arquivos encaminháveis não equivale a enviá-los a pessoas ou sistemas. Publicação, envio de mensagens e alterações em ambientes compartilhados dependem da autorização aplicável. A criação do relatório e a implementação experimental em cópia isolada do destinatário estão autorizadas dentro do escopo do impacto.

### 6.4 Profundidade técnica e validação no destinatário

O relatório deve reduzir a necessidade de novas rodadas de esclarecimento: investigar o problema até os pontos concretos de implementação e entregar uma solução utilizável pelo responsável. A profundidade acompanha a fronteira afetada; não aumentar volume com descrições genéricas. Incluir, quando pertinente:

1. **Diagnóstico reproduzível:** cenário, entradas, passos, comportamento observado/esperado, causa identificada ou hipótese explicitamente não comprovada e evidência sanitizada.
2. **Localização precisa:** arquivos, classes, funções, hooks, abilities, rotas, schemas e versões/hash examinados; números de linha são auxiliares, vinculados à base exata.
3. **Alteração proposta:** fluxo e lógica necessários, entradas/saídas antes e depois, campos obrigatórios/opcionais, validação, defaults, erros e exemplos de chamada/resposta. Fornecer patch/diff aplicável ou trechos suficientes para implementar, quando o fonte estiver disponível. Uma instrução genérica como “adaptar o contrato” é insuficiente.
4. **Efeitos relevantes:** configuração, migração de dados, credenciais/permissões, filas/cursor, idempotência, cache, desempenho e isolamento de falhas, conforme o comportamento alterado.
5. **Prova da proposta:** com código e ambiente disponíveis, modificar uma cópia isolada da versão vigente do destinatário e executar testes que reproduzam o problema e validem a integração com o emissor preparado. Manter o original e o instalador oficial intactos; identificar a árvore experimental, registrar o diff e retirar instrumentação temporária dos artefatos finais. Uma prova local não exige publicar uma release alheia.
6. **Entrega reproduzível:** registrar base exata, patch, procedimento para aplicar, comandos/cenários de teste, resultado, limites e critérios de aceite. Preservar o patch, fixtures e evidências sanitizadas junto ao fonte do emissor ou como complemento referenciado no impacto, sem incluir código experimental no runtime. Se for necessário empacotar a cópia do destinatário para teste, identificá-la como experimental e mantê-la separada dos instaladores oficiais.
7. **Impedimentos concretos:** se não for possível implementar/testar a proposta, registrar fonte, runtime, credencial ou acesso faltante, a prova que não foi realizada e a próxima ação. Não inventar caminhos/código de um pacote não examinado, nem chamar uma proposta de validada.

O destinatário continua responsável por incorporar, revisar, versionar e entregar sua release oficial. Reaproveitar a prova e o patch para evitar redescoberta do problema, repetição sem causa e sucessão de relatórios incompletos. Alteração material posterior do contrato exige revalidar a fronteira afetada.

### 6.5 Parte do emissor pronta para a integração

Ao produzir o encaminhamento executável e ao fechar a entrega, o pacote emissor deve deixar implementada e testada toda a sua parte do contrato solicitado: registro/exposição ou consumo, schemas, tratamento de erros, persistência/migração, documentação e testes pertinentes. A alteração correspondente no destinatário deve bastar para completar a integração, com a configuração/retomada documentada, sem outra alteração de código ou nova release do emissor para o mesmo contrato.

Enquanto a alteração do destinatário não estiver disponível, detectar a ausência do contrato corrente e manter somente o fluxo dependente indisponível ou pausado, com diagnóstico explícito e dados preservados. Não ativar protocolo antigo por fallback. Documentar a condição de prontidão, a ordem de troca e como retomar; respeitar a seleção explícita exigida por integrações e impedir duplicidade de ingestão ou efeitos.

Validar ambos os estados: contrato ainda ausente e contrato solicitado atendido, preferencialmente contra a cópia alterada do destinatário. Um mock pode demonstrar o comportamento próprio, mas deve ser identificado como tal e não comprova integração real. Registrar a versão/hash do emissor e a base/patch do destinatário usados, quando existentes.

O registro preliminar no planejamento mantém visíveis as lacunas enquanto se prepara o código. Não apresentá-lo como solicitação pronta nem encerrar a implementação com a própria parte pendente. Se houver decisão externa que impeça completar essa preparação, manter o impacto como `decisao-necessaria` ou `bloqueio`, delimitar o ponto e concluir as atividades independentes; não afirmar prontidão artificialmente.

## 7. Documentação obrigatória dentro do instalador

### 7.1 Conteúdo mínimo

Manter documentação textual legível por máquina dentro do plugin, preferencialmente em `docs/`. Usar UTF-8 e Markdown como fonte; schemas e catálogos estruturados usam JSON. A versão instalada deve bastar para orientar o uso, mesmo sem acesso ao repositório, ao relatório externo ou a um link de conversa.

| Documento lógico | Conteúdo |
|---|---|
| Índice | Identidade, versão, mapa de documentos, contratos e formas de leitura |
| Especificação | Objetivo, responsabilidades, comportamento, dados, efeitos, limites e recursos indisponíveis |
| Configuração | Pré-requisitos, campos/defaults, credenciais, escopos/ativos, passos de conexão, validação e revogação |
| Uso | Operações principais, sequências completas e exemplos de sucesso, vazio, erro e resultado parcial |
| Contratos | Schemas de entrada/saída, SDKs, callbacks, erros, revisões, permissões e integrações |
| Guia para agentes | Descobrir → ler → diagnosticar → configurar/consultar → verificar; confirmação e retomada |
| Operação | Cron/jobs, cotas, retenção, logs, recuperação de dados/retomada, instalação, atualização, correção por nova versão e desinstalação; sem procedimento de downgrade |
| Notas da versão | Mudanças, base de migração, conjunto vigente, requisitos de runtime, contratos alterados, limites e pendências da release |

Mapeamento recomendado para novos documentos: `docs/README.md`, `SPECIFICATION.md`, `CONFIGURATION.md`, `USAGE.md`, `CONTRACTS.md`, `AGENT-GUIDE.md`, `OPERATIONS.md`, `CHANGELOG.md`, `schemas/` e `examples/`. Documentos existentes podem cobrir vários tópicos; publicar o mapeamento no índice, sem criar cópias divergentes só para cumprir nomes. O índice Core `docs/DOCUMENTACAO.md` permanece válido.

Gerar o catálogo de operações/schemas a partir do registro do próprio código quando possível. Redigir e revisar as explicações de semântica, pré-requisitos e exemplos. Se houver conteúdo compilado em PHP/JSON para leitura segura, produzi-lo no build a partir da mesma fonte e conferir a correspondência com a documentação empacotada.

Histórico deve estar identificado como histórico. O guia corrente descreve a release instalada; planos futuros e propostas não aparecem como capacidades disponíveis. Indicar explicitamente o que exige credencial, aprovação de produto ou contrato de outro plugin.

### 7.2 Acesso no WordPress e pelo MCP

Cada plugin, inclusive o Implantador, deve disponibilizar sua documentação no painel administrativo e por uma operação de leitura descoberta no catálogo MCP. O próprio plugin é dono do conteúdo e da autorização de domínio; o MCP fornece o transporte. A documentação local e o painel continuam acessíveis sem conexão ao fornecedor.

Requisitos funcionais comuns, preservando envelopes e nomes públicos existentes:

1. **Descoberta:** uma operação/documento inicial retorna índice, IDs permitidos, descrição e instruções reais de leitura. Deve ser encontrada pela descoberta usual de ferramentas, sem conhecer previamente caminhos de arquivos.
2. **Leitura completa:** obter documento ou seção por ID, com paginação para conteúdo extenso; nenhuma truncagem silenciosa. Limitar por bytes e/ou linhas com teto declarado, abaixo do limite do transporte após decoração.
3. **Identidade:** retornar slug, versão instalada, revisão ou hash do conteúdo, documento/seção, origem local e dados de continuação. Durante paginação, detectar alteração de revisão para evitar juntar versões diferentes.
4. **Schema:** documentar parâmetros, limites, erros e autorização. Quando o contrato de saída existente não puder mudar, acrescentar metadados de forma compatível ou publicar adaptação explícita.
5. **Confinamento:** usar IDs/allowlist do índice. Recusar travessia de diretórios, caminhos arbitrários, arquivos de credenciais, URLs externas e symlinks que saiam do conteúdo permitido.
6. **Leitura sem efeitos:** não consultar APIs dos fornecedores, criar conexão, renovar token, reparar agenda, instalar nada ou conceder permissões ao abrir ajuda.
7. **Autorização:** tela administrativa exige `manage_options` ou capacidade exclusiva de administrador. Leitura MCP de documentação exclusivamente estática usa o gate documental explícito do pacote, sem acesso genérico a arquivos. Se a operação incluir configuração efetiva, diagnósticos de conexão ou dados de conta, aplica-se também o gate administrativo, nunca somente `read`. Não reduzir a permissão de operação existente para facilitar a leitura.
8. **Atualidade:** a leitura reflete o pacote instalado. Conteúdo compilado/cacheado deve invalidar pela versão/hash; não misturar manual antigo com runtime novo.
9. **Privacidade:** somente exemplos sanitizados; nenhum segredo, dado de contato, dump real ou valor privado de configuração. A documentação serve como informação, sem executar seu texto como instrução privilegiada.

A pesquisa textual por assunto é recomendada; índice e leitura integral paginada são obrigatórios. Um link externo ou a possibilidade de usar `files/read` não substitui a operação de documentação do plugin. A leitura pelo MCP exige o MCP ativo e autorizado; isso não cria dependência de instalação do plugin de domínio.

### 7.3 Critério de aceite documental

Em uma nova sessão de agente, usando somente MCP autorizado e o plugin instalado:

1. Descobrir a operação de documentação e ler seu schema.
2. Obter índice e instruções de configuração.
3. Ler um documento completo, inclusive todas as páginas de um documento longo, conferindo revisão/hash e fim da leitura.
4. Identificar pré-requisitos, permissões, uma consulta válida, uma ação de configuração, seus efeitos e como verificar o resultado.
5. Conferir que a versão e os exemplos correspondem ao pacote e ao schema instalados.
6. Repetir a leitura após atualizar da base vigente de migração, verificando que o conteúdo novo substituiu o antigo sem cache obsoleto.
7. Demonstrar recusa de acesso indevido a arquivos e ausência de chamadas ao fornecedor durante leitura.
8. Com perfil sem autorização administrativa, comprovar recusa de leitura de conta conectada e de configuração, no painel e nas operações remotas afetadas; documentação estática não pode servir como desvio para dados privados.

Um teste com inspeção do fonte ou apenas com o arquivo fora do WordPress não encerra esse aceite.

## 8. Testes e ambiente compartilhado

Ambiente permitido para testes: `https://fator3-teste-mcp-1.dreamhosters.com/`, por meio do conector **WP MCP fator3-teste**. A disponibilidade desse ambiente autoriza seu uso no escopo de testes solicitado; não exige instalação durante uma rodada exclusivamente de elaboração de instruções.

### 8.1 Coordenação

- Ler estado e versões/hash disponíveis antes de modificar o site; registrar data/hora e escopo.
- Como vários responsáveis utilizam o mesmo WordPress, coordenar uma janela de alteração. Manter uma única operação de instalação/atualização por vez e evitar testes concorrentes que mudem plugins, configuração, cron ou banco. Detectar mudanças de terceiros e interromper a sequência incompatível sem sobrescrevê-las.
- Preservar dados, credenciais, filas e configurações alheios. Gerar backup recuperável dos dados/configurações que serão alterados; registrar o que ele cobre. Recuperar dados ou retomar uma operação não exige reinstalar versão anterior do plugin.
- Executar instalação limpa em WordPress descartável/local ou em contexto isolado que realmente represente estado limpo. Não apagar o banco do site compartilhado para fabricar essa prova.
- Acesso ao site de teste não autoriza gastos em Ads, envios a clientes, publicação, assinaturas reais ou ingestão comercial em produção. Usar fixtures e destinos de homologação dentro da autorização existente.
- Identificar dados sintéticos e limpar somente os recursos criados pela própria rodada. Documentar qualquer resíduo ou estado deixado no site.

### 8.2 Matriz mínima por release

| Cenário | Aceite |
|---|---|
| Sintaxe e empacotamento | PHP >= 8.3 e WordPress >= 7.1.4 declarados; versões efetivamente validadas registradas; árvore correta, dependências e docs presentes; nenhum segredo/QA no instalador |
| Instalação limpa | Ativar e usar funções próprias sem depender de estado histórico; primeira leitura anterior a qualquer reparo |
| Atualização da base vigente | Migração para a versão-alvo preserva dados, opções, permissões, pausas e progresso; novo processo confirma a versão efetiva; não implica suporte continuado à base |
| Plugin isolado | Ausência de acompanhantes não derruba painel, bootstrap ou funções próprias |
| Integrações afetadas | Conjunto vigente, contratos, permissões e indisponibilidade controlada; emissor pronto e proposta no destinatário validada quando viável, com limites declarados |
| Funcionalidade alterada | Resultado persistido/observável e erros pertinentes; teste deve verificar comportamento útil |
| Documentação pelo MCP | Descoberta e leitura completas conforme seção 7.3 |
| Encerramento | Saúde do WordPress, limpeza de fixtures e inventário final das versões instaladas |

Acrescentar testes conforme o risco concreto: repetição/idempotência, execução concorrente, interrupção e retomada para jobs; token revogado e troca de contexto para integrações; interface real quando o painel/JavaScript mudar; integridade e retomada após falha de instalação, com correção em nova versão quando necessária; operação nos mínimos PHP 8.3 e WordPress 7.1.4 e no ambiente atual pertinente. Não exigir testes de versões inferiores, pacotes antigos, combinações mistas históricas ou downgrade. Publicar os limites quando não houver matriz executada.

“Bootstrap sem acompanhantes numa requisição” e “instalação isolada limpa” são provas diferentes. “Atualizar o mesmo ZIP sobre si” e “atualizar da versão anterior” também são provas distintas. Registrar o cenário real, inclusive quando a versão é a primeira release e não há anterior: nesse caso, atualização anterior é `nao-aplicavel`.

Mocks e fixtures devem ficar restritos ao teste e não alterar políticas globais de rede/segurança ou código publicado. APIs reais exigem tokens/ativos autorizados; falta de acesso é pendência de homologação, não resultado aprovado. Testar somente o necessário para riscos, contratos e critérios de aceite da rodada; evitar repetição ampla sem causa.

## 9. Preservação de dados, autorização e recuperação

1. Atualização não reseta configurações, importa dados, ativa conexões ou agenda efeitos comerciais por conveniência. Novos defaults devem ser distinguidos de escolhas já persistidas.
2. Manter proteção de segredos, permissões de leitura/escrita, revisão otimista e restrição por ativo. Tela, leitura de dados de conta conectada e escrita de configuração exigem `manage_options` ou capacidade exclusiva de administrador; validar no servidor, inclusive MCP e REST. Registro de ferramenta não concede acesso ao alvo.
3. Diagnósticos e leitura de estado não fazem reparos silenciosos. Operações com efeito declaram o efeito real, inclusive quando o método remoto usa GET ou quando a ação é chamada “teste”.
4. Repetição de uma operação confirmada não deve duplicar o efeito. Resultado externo incerto exige reconciliação antes de repetir.
5. Jobs preservam origem e autorização, revisão da seleção, locks, checkpoint e pausa. Não avançar cursor comercial antes da persistência correspondente.
6. Desativação e desinstalação têm comportamentos documentados; remoção destrutiva de dados exige ação explícita no escopo autorizado.
7. Não há reversão da versão instalada para uma anterior. Documentar migrações de avanço, checkpoints, recuperação de dados e correção em nova release a partir do estado alcançado. Não exigir migração reversa nem compatibilidade do novo schema com código antigo. Preservar evidências de efeitos externos para reconciliar antes de retomar.
8. Logs, relatórios, fontes e exemplos entregues devem estar sanitizados. Não publicar credenciais, dados pessoais ou dumps de produção em evidências.

## 10. Fronteiras específicas preservadas

- **Core:** medição, consentimento, eventos, contatos, atribuição, pipeline comercial e histórico editorial GSC em seu recorte. Meta Lead Ads e Pixel/CAPI permanecem nele.
- **Google:** APIs e credenciais Google, GA4/GSC e recursos Google existentes. Configuração Google Ads e homologação devem ser comprovadas na instalação; presença de código não basta.
- **MCP:** transporte, autenticação, descoberta e administração WordPress. Não incorporar clientes das APIs sociais nem regras comerciais dos provedores.
- **Meta:** Instagram Insights, conexões e histórico próprios. Meta Ads e anúncios Instagram continuam no MCP oficial da Meta, utilizado pelo agente; não reimplementar esse conector nem criar cliente MCP remoto dentro do WordPress.
- **LinkedIn:** Pages, Ads e cliente/SDK Lead Sync próprios. Cliente Lead Sync Core e cliente do plugin LinkedIn convivem, com escolha explícita por integração; um cliente ativo por fluxo, sem duas ingestões/assinaturas equivalentes. Core mantém callback, contatos, deduplicação e efeitos. Ausência do selecionado pausa o fluxo; mudança para o outro é explícita.
- **Implantador:** manter seu domínio de implantação/configuração operacional e as pontes já publicadas. Inventariar contratos na própria aba/fonte antes de alterar; este padrão não transfere para ele clientes sociais, métricas ou regras comerciais.
- **Conexões sociais:** token manual é o padrão; aprovação de app, escopos, ativos e validade continuam necessários. Não impor OAuth interativo no plugin como requisito comum. OAuth do servidor MCP possui seu próprio domínio.
- **Escopo excluído nesta etapa:** BigQuery, migração Porter e nova exportação social para Google Sheets. CSV/JSON próprios permanecem. Sheets social só volta ao plano mediante solicitação; recursos Sheets existentes no Google são preservados.

Compartilhar schemas/fixtures e utilitários versionados quando isso reduzir trabalho, mantendo builds autônomos. Não introduzir novo plugin obrigatório de infraestrutura, leitura de options privadas ou importação de classes internas de outro plugin. Acoplamentos legados conhecidos, como adaptadores do Implantador, devem ser inventariados e tratados por encaminhamento específico; não removê-los fora do escopo por imposição genérica do padrão. Interfaces publicadas como contrato, inclusive recibos públicos, podem ser consumidas conforme a especificação.

## 11. Sequência de trabalho de cada agente

1. Ler pedido, padrão, última entrega, fonte-base, impactos recebidos e contratos relevantes.
2. Identificar versão-base/alvo, escopo, evidências, mínimos PHP 8.3/WordPress 7.1.4 e conjunto vigente dos acompanhantes; registrar divergências do ambiente.
3. Avaliar e registrar impactos preliminares no planejamento somente para destinatários tecnicamente afetados. Investigar código e contratos, propor a alteração concreta e resolver decisões antes de consolidar a interface, conforme seção 6; referenciar os documentos no plano.
4. Implementar a parte do emissor e deixá-la pronta para o contrato solicitado; quando viável, aplicar e testar a proposta em cópia isolada do destinatário, preservando patch/evidências. Manter instalação limpa e migração da base vigente, sem suporte histórico ou downgrade.
5. Atualizar documentação, exemplos, schemas e leitor documental dentro do runtime.
6. Executar testes necessários, incluindo WordPress real e consulta documental pelo MCP quando a release estiver em homologação; registrar bloqueios concretos.
7. Fechar runtime/instalador; conferir correspondência e testar a identidade final ou demonstrar correspondência byte a byte com a árvore testada.
8. Preparar o relatório e atualizar os impactos pertinentes desde o planejamento, distinguindo proposta, prova própria e informação de outro mantenedor. Sem impacto relevante identificado, registrar conclusão e escopo avaliado no relatório. Fechar fonte e relatório na sequência da seção 4.3.
9. Conferir nomes finais, tamanhos e SHA-256 no relatório, cabeçalho, documentação, conteúdo dos ZIPs e ausência de arquivos privados. Gerar manifesto/checksums somente quando úteis.
10. Disponibilizar todos os artefatos e informar o estado final do site. Uma pendência real deve aparecer no relatório e na resposta final; não substituir prova faltante por linguagem de conclusão.

## 12. Modelo do relatório de entrega

```markdown
# Entrega — <nome exibido> <versao>

Revisão: <n> · Data/hora: <ISO 8601> · Rodada: <tipo>
Slug: <slug> · Versão/build: <versao> / <build>
Status: <apta-no-escopo-testado | com-pendencias | bloqueada>

## 1. De onde esta versão entra

<WordPress limpo; base vigente de migração; origem da base;
salto explícito, se aplicável; somente a versão nova em operação após a troca.>
Requisitos do projeto: WordPress >= 7.1.4; PHP >= 8.3.
Runtimes efetivamente validados: WordPress <versao>, PHP <versao>, <outros>.
<Pendência de validação dos mínimos, quando não exercitados; não reduzir os requisitos.>

## 2. Convivência e encaminhamentos

<Conjunto vigente dos acompanhantes e versões efetivamente testadas; contratos;
ordem de troca, pausa e retomada se necessárias; sem suporte a versões antigas.>

| Destinatário | Versão examinada | Classificação / situação | Ticket | Impacto individual / revisão |
|---|---|---|---|---|
<Somente destinatários com impacto relevante; incluir o desfecho dos encaminhamentos
emitidos no planejamento. Se nenhum impacto foi identificado, substituir a tabela
por conclusão breve e escopo avaliado. Registrar lacunas de avaliação nas pendências.>

## 3. Mudanças e evidência

| Pedido exato | Problema | Mudança | Resultado e evidência |
|---|---|---|---|

<Contratos, configuração, dados, jobs e permissões afetados.>

## 4. Instalação e prova da troca

<Procedimento; URL raw final; expected_slug; SHA-256 da seção 8;
rota/ability de prontidão, parâmetros, estado esperado e observado.>

| ID | Ambiente | Cenário | Resultado | Evidência | Limite |
|---|---|---|---|---|---|

Documentação: <índice local, operação MCP, schema, versão/hash e leitura completa>.
Estado final do teste: <versões, limpeza e resíduos>.

## 5. Banco, migração e correção por nova versão

<Gravações/migrações de avanço, retomada, backup de dados e preservação.
Sem downgrade: uma correção após instalação exige nova release;
indicar estado necessário à recuperação e efeitos externos a reconciliar.>

## 6. O que permanece pendente

<Provas não realizadas, falhas, conta/API/navegador/runtime, motivo e responsável.>

## 7. Credenciais e configuração do dono

<Tela, campos e tipo/escopos/ativos; nenhum segredo.>

## 8. Identidade dos arquivos

| Artefato | Nome final e link | Bytes | SHA-256 |
|---|---|---:|---|
| Instalador | <slug>-<versao>-instalador.zip | <n> | <hash> |
| Fonte | <slug>-<versao>-fonte.zip | <n> | <hash> |

<Relatório externo canônico. A cópia no fonte é anterior ao fechamento;
seu próprio tamanho/hash só são preenchidos aqui após empacotamento.>
<Complementos, se emitidos; impactos pertinentes referenciados na seção 2.>
```

O título e as oito seções seguintes correspondem aos nove itens ordenados da seção 5. Preencher somente fatos apurados; marcadores não preenchidos representam pendências, não uma entrega conforme.

## 13. Modelo de impacto individual

```markdown
# Impacto de <emissor> <versao-alvo> em <destinatario>

Data/hora: <ISO 8601> · Revisão: <n>
Etapa: <planejamento | implementacao | entrega>
Situação: <aberto | alinhado | resolvido | cancelado>
Versão-base: <versao e origem> · Versão-alvo: <versao; prevista ou entregue>
Instalador emissor: <nome e SHA-256, quando existir;
no planejamento: alvo ainda não gerado; hash da base quando disponível>
Destinatário examinado: <versao/hash ou não disponível>
Natureza: <desenvolvimento | bug/regressão | contrato | outra, especificada>
Classificação: <acao-necessaria | decisao-necessaria | validacao-coordenada | alerta-tecnico | bloqueio>

## Mudança e consequência

<Contrato/campo/ability exatos, comportamento atual e proposto/entregue,
cenário afetado, consequência técnica relevante, risco e incertezas.>

## Ação ou decisão do responsável

<Providência executável, responsável, ticket e aceite observável.
No planejamento: conflito, alternativas/restrições e decisão necessária antes
da consolidação da interface. Em alerta técnico: consequência e orientação.>

## Diagnóstico e alteração proposta no destinatário

<Reprodução, causa identificada ou hipótese, arquivos/classes/funções/abilities,
contratos e schemas atuais/propostos, lógica da mudança, entradas/saídas,
erros, dados/permissões e outros efeitos pertinentes.>
<Patch/diff aplicável ou código preciso, base exata e instruções de aplicação;
referência ao complemento quando extenso. Se indisponível, motivo concreto.>

## Prontidão do emissor

<Código/contrato implementados, versão/hash quando existir, documentação e testes.
Como se comporta antes e depois da mudança no destinatário; configuração/retomada.
Confirmar que a mudança solicitada completa a integração sem nova alteração de
código do emissor para esse contrato. No registro preliminar: lacunas explícitas.>

## Compatibilidade e sequência

<Conjunto vigente previsto/verificado, ordem de troca, indisponibilidade controlada,
condição de prontidão e retomada; dependência real e atividades independentes.
Sem obrigação de suporte histórico, combinações antigas/mistas ou downgrade.>

## Validação e evidência

<Planejamento: base da análise, testes previstos e lacunas.
Implementação/entrega: base/hash e patch da cópia experimental do destinatário,
versão do emissor, comandos/cenários, resultados e evidências sanitizadas;
testar ausência do contrato e contrato atendido. Se não executado, impedimento.
Distinguir mocks, prova local, WordPress real e fornecedor. Patch experimental
validado não equivale a incorporação na release oficial do destinatário.>

## Resposta esperada

<Aceite da proposta / alternativa / implementação / validação / impedimento,
com versão/contrato e evidência quando disponível; dispensável para alerta sem ação imediata.>

## Evolução e encerramento

<Mudanças desde a revisão anterior, decisões, ações pendentes e responsáveis.
Se resolvido/cancelado: motivo, evidência e desfecho do encaminhamento original.>
```

## 14. Checklist de encerramento

- [ ] Ambos os documentos centrais lidos integralmente; nomes/revisões informados e divergências resolvidas pela precedência.
- [ ] Versão-base/alvo e conjunto vigente explícitos; incremento conforme a regra de versão aplicável.
- [ ] PHP mínimo 8.3 e WordPress mínimo 7.1.4 em cabeçalho, documentação e build/testes; runtimes efetivamente validados separados dos requisitos.
- [ ] Sem obrigação de suporte a runtimes inferiores, versões antigas próprias/acompanhantes ou combinações mistas históricas.
- [ ] Correção após instalação exige nova versão; nenhuma exigência de downgrade ou migração reversa; integridade/retomada de dados preservadas.
- [ ] Fonte, instalador e relatório próprios entregues.
- [ ] Impactos avaliados; documentos emitidos somente para consequências técnicas relevantes, ou ausência de impacto identificado registrada com escopo avaliado.
- [ ] Impactos preliminares registrados já no planejamento e decisões de contrato resolvidas antes da consolidação da interface; sem exigir instalador/hash futuro.
- [ ] Impactos aprofundados com diagnóstico, pontos exatos, proposta aplicável/patch, aceite, efeitos e evidências; impedimentos concretos declarados.
- [ ] Proposta testada em cópia isolada do destinatário quando viável; base e patch identificados, sem confundir prova local com release oficial.
- [ ] Emissor pronto no encaminhamento executável e na entrega; contrato ausente/atendido verificados, sem outra alteração de código própria para completar o mesmo contrato.
- [ ] Encaminhamentos existentes atualizados na implementação/entrega, com decisões, evidências, pendências ou encerramento, e referenciados no plano/relatório.
- [ ] Nomes finais, tamanhos e SHA-256 de fonte/instalador no próprio relatório.
- [ ] Fonte no singular, pasta fonte correta, cópia do relatório identificada; nenhum ZIP contém outro ZIP.
- [ ] Cabeçalho, título de tela e permissões administrativas conferidos.
- [ ] Fluxo raw/expected_sha256/expected_slug comprovado quando houver instalação pela frota; fonte fora do repositório público enquanto a decisão 89 estiver pendente.
- [ ] Documentação da release dentro do instalador e da árvore fonte.
- [ ] Agente consegue descobrir e ler integralmente essa documentação pelo MCP.
- [ ] Instalação limpa e migração da base vigente verificadas, ou pendência/não aplicabilidade explicitada.
- [ ] Funções próprias e integrações afetadas verificadas com limites declarados.
- [ ] Configurações, dados, credenciais, pausas e permissões preservados.
- [ ] Nenhum segredo, fixture ativa ou ferramenta temporária no instalador.
- [ ] Aprovações e acessos remotos separados de testes simulados.
- [ ] Estado final do WordPress e limpeza registrados.
- [ ] Alterações experimentais no destinatário isoladas, documentadas e encaminháveis; nenhuma release oficial alheia, instalação compartilhada, mensagem ou efeito externo fora da autorização existente.

Um item obrigatório não atendido deixa a entrega `com-pendencias` ou `bloqueada`, conforme o efeito. Não marcar o item como concluído para fechar a rodada.

Na atualização exclusiva das regras centrais, aplicar os itens documentais pertinentes: leitura das bases, revisão/data, consistência entre instruções e padrão, modelos e checklist sincronizados, preservação de conteúdo fora do escopo e entrega dos dois arquivos revisados. Itens de release, testes de runtime, ZIPs e instalação são `nao-aplicavel` nessa rodada.
