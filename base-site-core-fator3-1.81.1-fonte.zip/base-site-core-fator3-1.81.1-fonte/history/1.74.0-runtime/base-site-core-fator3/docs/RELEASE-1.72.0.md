# Fator3 Site Core 1.72.0

Base canônica 1.71.0. O pacote exige WordPress 7.1.4 e PHP 8.3. Instale pela administração do WordPress e confira a conclusão do ciclo da versão na saúde do Core. O contrato administrativo 8.34.0 acrescenta um filtro de origem na medição de vitais.

## Carregamento público

O cliente de contatos é selecionado pelas funções de publicidade configuradas no site. Os ativos distribuem as variantes já compiladas, e a escolha ocorre ao preparar a página. A captura local, as políticas de consentimento e os identificadores específicos dos formulários permanecem disponíveis nos cenários documentados em MEDICAO-DESEMPENHO.md. A seleção conserva um cliente completo de reserva para os caminhos que dele precisam. A folha do consentimento é compactada no build e publicada na ordem original.

Os POSTs anônimos das duas rotas públicas de comportamento e análise deixam de executar os cronômetros, a reflexão e a inspeção de SQL da sonda PHP. A validação do lote, o token, o consentimento e a resposta operacional seguem os controles das próprias rotas.

## Vitais por versão

A coluna aditiva `versao_origem` pertence à tabela local de amostras. A migração mantém os valores, sequências e classes de tráfego existentes. Linhas anteriores continuam disponíveis no filtro `sem_versao`. A ausência de filtro oferece a visão completa. Consulte VITAIS-VERSAO.md para a procedência do valor e para interpretar p75 com o denominador correto em cada versão.

Em Medição → Técnico, escolha Web Vitals por versão. O formulário reúne período, segmento, caminho, faixa de tela e versão. A área Web Vitals também oferece acesso a essa visão.

Em dados reais, compare as mesmas rotas e condições de cache, dispositivo e audiência. A identificação da versão permite separar os grupos, mas não elimina diferenças de tráfego entre eles.

## Reativação após desinstalação

Quando o site reativa o plugin após a remoção das tabelas operacionais, o WordPress agenda a migração. A manutenção das intenções e da fila Meta CAPI começa somente após a etapa que prepara essas tabelas. A mesma condição protege uma passagem antecipada do cron. A recuperação e as filas usam os dados preservados segundo a política de desinstalação de cada módulo.
