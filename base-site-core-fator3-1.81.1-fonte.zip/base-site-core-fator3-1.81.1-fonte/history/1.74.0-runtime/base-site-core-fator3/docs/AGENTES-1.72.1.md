# Operar o Fator3 Site Core 1.72.1

## Identificar a instalação

Consulte `f3base/saude-ler` e confira a versão 1.72.1 e o ciclo concluído. O contrato administrativo é 8.34.0. A atualização direta parte da 1.72.0. Use `f3base/documentacao-ler` para abrir o índice da instalação.

Para ler a nota desta correção, execute a mesma habilidade com `{"arquivo":"docs/RELEASE-1.72.1.md","linha":1,"limite":10}`. Continue em `proxima_linha` até receber `null`. Confira versão e SHA-256 entre as páginas. Consulte OPERACAO-E-RECUPERACAO.md para o procedimento de recuperação.

## Conferir a renderização

Entre com uma conta que tenha `manage_options`. Abra **Site Core → Relatórios → Técnico** e selecione **Web Vitals por versão** em **Análise**. Confira um painel, um controle **Versão de origem** e uma tabela com a coluna **Percentil 75**. Abra também a visão de qualidade pelo mesmo menu. Uma conta sem a capacidade exigida deve receber recusa ao abrir a rota administrativa diretamente.

O teste A/B percorre o registro real de `admin_menu` e renderiza a mesma rota com os mesmos dados nas duas versões. Na 1.72.0 havia duas renderizações. Na 1.72.1 o WordPress registra uma única função para `toplevel_page_f3base-medicao`. Registre a contagem de elementos e as versões testadas. A contagem de linhas do banco mede outra grandeza.

## Ler as amostras

A coluna `versao_origem` pertence à 1.72.0. Consulte `f3base/vitais-ler` com `{"dias":28,"somente_resumo":true,"versao_origem":"1.72.1"}`. Compare com a base 1.72.0 usando iguais período, métrica, rota, dispositivo e segmento de tráfego. Use `sem_versao` para a cobertura de amostras de origem desconhecida. VITAIS-VERSAO.md descreve a atribuição, as exclusões e o denominador da consulta.
