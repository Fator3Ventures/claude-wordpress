# Fator3 Site Core 1.67.0

Nova rodada minor sobre a base imutável 1.66.0. Pedidos 365/366/367 implementados no Core. Contrato administrativo 8.30.0 e SDKs de fornecedores preservados. A base recebida informa encerrados 354/362/363/364 na frota; esses aceites recebidos não são novas medições desta rodada. A regra de implementação integral permanece.

## 365 — estados internos e catálogo

O diagnóstico de opções gravadas consulta o catálogo de configurações e uma lista explícita de estados internos do inventário distribuído. Marcos históricos conhecidos e famílias fechadas de reserva, cota Clarity e arquivo de origem são reconhecidos sem abrir uma exceção genérica para f3base_. As configurações continuam dependendo de declaração no catálogo executável: um nome ausente, erro de digitação ou marco desconhecido continua gerando option_gravada_fora_catalogo. As duas opções de conversas Instagram são declaradas diretamente na composição do catálogo, independentemente da ordem dos consumidores; a configuração não é disfarçada como estado interno. O relatório devolve nomes, nunca valores. Reconhecer uma chave no diagnóstico não autoriza escrevê-la ou apagá-la, nem muda backup/desinstalação.

## 366 — artefato de cache e estado vigente

content_url usa o esquema da requisição. Em CLI isso podia produzir http para uma home https, e resolver_cache recusava a própria URL como outra origem. Agora a URL mantém diretório/filtros do WordPress e recebe explicitamente o esquema canônico da home antes da verificação de mesma origem. Host, porta, limite de bytes e seleção pública continuam validados; links simbólicos de arquivo são recusados. A sonda prioriza o arquivo exato vinculado ao corpo servido e registra diretório relativo pesquisado, limite/quantidade de entradas, varredura parcial e até 12 recusas com motivo. Não registra conteúdo de cache nem caminho absoluto do servidor.

A proteção do artefato exige corpo vazio e HTTP 200/403/404/410; conteúdo exposto, erro com corpo, redirecionamento, falha ou truncamento não viram sucesso. TTL configurado de 86400 segundos não equivale a prova de proteção ou idade máxima. Saúde, pós-atualização e seus avisos projetam a mesma verificação vigente. recibo_inicial conserva o resultado original sem reescrita; um sucesso novo remove o aviso atual automaticamente, e uma nova pendência mostra seu motivo atual. A leitura não dispara sonda nem reinicia o ciclo.

A retomada também corrigiu a diferença de contexto entre CLI e HTTP do WP Super Cache 3.1.4: quando o global wpsc_ignore_tracking_parameters está ausente, o Core lê exclusivamente uma atribuição literal de nível superior no arquivo de configuração do provedor. A leitura é limitada a 256 KiB, não executa PHP, não altera globais e não substitui false explícito. Configuração dinâmica, duplicada, condicional ou ilegível permanece sem confirmação. Com a configuração literal padrão, CLI e página pública calculam o mesmo contexto, evitando cache_obsoleto falso após a verificação automática.

## 367 — Lead local, identificador e recebimento Meta

A aquisição de formulário usa o record_id como event_id, enquanto sua correlacao pode ser outra. O coletor meta-eventos antes procurava somente correlacao e recusava o Lead legítimo com 409. A resolução agora usa a identidade canônica compartilhada com F3Base_Aquisicoes, admite somente contato aceito/clique elegível e confere método, classe, consentimento, exclusão, classificação e supressão. O clique que já usa correlacao continua compatível. Não reserva outra aquisição e não cria conversão adicional.

A tabela f3base_meta_eventos ganha event_id varchar(100), vazio nas linhas históricas. O hash anterior, instante original e deduplicação permanecem. Navegador observado pode passar de falso para verdadeiro, inclusive quando o Pixel ocorre durante um POST pendente. Conversão Meta explicitamente suprimida não cria sinal local pelo evento de confirmação. A exclusão do contato remove o identificador exato; as contagens técnicas podem permanecer. Não há reconstrução de ids antigos nem novos envios à Meta.

f3base/meta-entregas-ler, modo eventos, inclui observações locais sem fila do servidor e os recibos existentes da fila. Acrescenta event_id, identificador_disponivel, capturado_em, navegador_observado, pixel_navegador_id e origem_recibo. Recibo local usa estado observado_local e campos exclusivos de servidor nulos; não representa entrega externa. Paginação de 100 linhas usa ordem estável por instante, hash e recibo. Campos antigos e modos permanecem.

O diário mantém dia_utc, rota, classe, capturados e disparados_no_navegador; fuso_diario declara UTC. comparacao_meta coloca contagens locais e recebidas lado a lado no dia/fuso do produtor e dataset exato, com classes locais separadas. Browser e servidor externos podem se sobrepor; unicos permanece null. Ausência de concessão, cobertura parcial e valor desconhecido não viram zero. O total externo pertence ao dataset e não é atribuído a uma classe local ou a um event_id individual. Dados vêm do acervo local concedido meta-ads-monitoring/1.0.0; nenhum HTTP de fornecedor é iniciado por essa leitura. Páginas externas adicionais continuam em f3base/meta-monitoramento-ler.

## Atualização, reversão e aceite

Migração aditiva idempotente; coluna nova não exige restaurar banco para voltar à 1.66.0. Rollback de arquivos devolve as falhas antigas; conservar dados e estado de recuperação. A conclusão do ciclo verifica também a coluna event_id. O pacote não ativa destinos, não muda consentimento nem concessões e não altera acompanhantes. Considerados Google 0.26.0 e Meta 0.19.0; nenhum novo impacto de contrato para outro pacote.

Teste isolado e Site-Teste não substituem o aceite nos 12 sites (365), nos 11 sites do pedido 366 nem a observação do próximo contato real elegível (367). Não produzir contato comercial sintético para concluir esse aceite. Consulte o relatório externo para resultados, versões, hashes e pendências, incluindo as metas anteriores de bytes ainda sem fechamento.

## Reinstalação verificada nesta rodada

A desinstalação nativa arquiva o recibo de instalação e marca a necessidade de um novo ciclo antes de remover estruturas auxiliares. A reativação recria essas estruturas na mesma versão, preservando configurações e tabelas comerciais. A reconstrução confirmada retira falhas de estrutura observadas antes dela na mesma requisição, para que o shutdown não invalide o esquema que acabou de ser reparado. O teste confere todas as 70 tabelas do inventário após reinstalar. Isso corrige um defeito herdado encontrado na prova adicional de 1.67.0.
