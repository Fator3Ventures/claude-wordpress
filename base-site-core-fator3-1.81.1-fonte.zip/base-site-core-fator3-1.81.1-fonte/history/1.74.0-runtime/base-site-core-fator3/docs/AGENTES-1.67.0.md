# Agentes — Core 1.67.0

Leia RELEASE-1.67.0.md, DOCUMENTACAO.md e o relatório externo. Base imutável 1.66.0; contrato 8.30.0, WordPress mínimo 7.1.2, PHP mínimo 8.3.6. Aplicar e conferir o ZIP exato. Não reescrever versões publicadas nem alterar acompanhantes ou credenciais.

365: diagnóstico vazio após uso de todos os módulos; opção desconhecida deve continuar avisada. 366: testar executor CLI, home HTTPS, cache_max_time 86400, cópia servida e proteção vazia do artefato; saúde/pós-atualização devem concordar no motivo vigente e preservar recibo inicial. 367: confirmar event_id da aquisição, método, rota e classe sem PII, deduplicação, consentimento/revogação, paginação e comparação no fuso do produtor. Disparo local não prova recebimento; totais externos não identificam pessoas nem event_id individual. Não preencher desconhecidos com zero.

Não enviar eventos comerciais de teste para campanhas reais. A próxima captura real elegível e os aceites da frota dependem da operação nesses sites. Não declarar pendência de implementação como P2 nem confundir validação externa pendente com código entregue. Metas anteriores de bytes só fecham com medidas correspondentes.

Na validação 366, repetir com o global de rastreamento do WP Super Cache ausente em CLI, configuração literal 1 e comparação com o contexto HTTP. False explícito e configurações ambíguas continuam sem confirmação.
