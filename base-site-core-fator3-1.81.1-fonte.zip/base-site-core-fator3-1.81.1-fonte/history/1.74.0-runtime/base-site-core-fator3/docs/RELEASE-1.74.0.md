# Fator3 Site Core 1.74.0

## Configuração Meta e pedido 374

Em Site Core → Configurações → Meta, o seletor “Modo padrão” aplica imediato no aceite do formulário ou aguarda marcação por agente. Para criar uma exceção, informe o ID em “Exceções por ID de formulário”, clique em “Adicionar mapeamento”, escolha o modo e salve. Remover a linha devolve aquele formulário ao padrão. Os valores gravados aparecem ao reabrir a tela. O modo de um contato já capturado continua regido pela política registrada na captura.

A tela envia as opções editadas. Um grupo editado segue completo, com revisão, e o servidor valida o delta. Campos de outra área, final ausente, falta de permissão ou contexto vencido impedem o processamento. Uma opção inválida ou desatualizada recebe aviso próprio. As demais opções válidas são gravadas. Revise o campo apontado, confirme os valores atuais e reaplique a edição. O painel mostra o rascunho das opções não secretas recusadas. Para reenviá-lo, edite o campo ou marque a caixa que inclui o rascunho no próximo salvamento.

Para cadastrar só o token da API de Conversões, digite-o no campo de credencial e salve. O painel lê a presença da credencial, mantém o valor mascarado e exige a ação explícita de exclusão para apagar. A gravação é cifrada e a confirmação da Meta depende de recibo de evento. Em outra operação, altere apenas o transporte. Pixel e servidor exigem token e pixel/dataset. O modo somente servidor continua exigindo homologação.

## Instalação e operação por agentes

Instalação nova ou atualização direta da 1.73.0. WordPress 7.1.4 ou posterior e PHP de 64 bits a partir de 8.3. Basename base-site-core-fator3/base-site-core-fator3.php. A operação administrativa exige manage_options. Esta versão altera o painel e documentos. A estrutura do banco e o contrato administrativo 8.35.0 continuam vigentes. Para consultar o valor efetivo do grupo use f3base/config-core-ler com nome f3base_meta_lead. Os dados de autenticação e a credencial de CAPI não fazem parte do pacote.

Descubra f3base/documentacao-ler. Sem argumentos a operação retorna o índice. Informe arquivo docs/RELEASE-1.74.0.md para ler este texto e siga proxima_linha enquanto vier preenchida. Consulte AGENTES-1.74.0.md e DOCUMENTACAO.md para os demais pontos de entrada.
