# Operação Core 1.73.0

Leia RELEASE-1.73.0.md por f3base/documentacao-ler. Descubra o schema de meta-lead-enviar; simule com motivo, aplique com revisão esperada e consulte o recibo. A configuração f3base_meta_lead mantém imediato por padrão e permite sobrescrever por formulário. A revisão administrativa é 8.35.0. Não se presume recebimento no fornecedor a partir da fila.
