# Agentes — Core 1.66.0

Leia DOCUMENTACAO.md e RELEASE-1.66.0.md pela ability f3base/documentacao-ler, usando arquivo, linha e limite até 200; continuar em proxima_linha e conferir versão/hash. Ajuda não chama fornecedor nem grava configurações.

Após a troca 1.65.1 → 1.66.0, conferir ciclo e ativos públicos vigentes. Pedidos 354(k,l), 363 e 364: confirmar cache entre requisições nas raízes, snapshot legível, alias sem notice, seleção Meta preservada e ausência de aviso option_gravada_fora_catalogo. Aviso de catálogo informa nomes, nunca valores; não remover automaticamente opções. Diagnósticos exigem administrador.

Google 0.25.1 lê os SDKs publicados sem mudança. Meta 0.18.0 e LinkedIn 0.14.0 mantêm contratos. Nenhuma concessão, token, anúncio, lead ou mensagem real é criado pela leitura. Aceite de desempenho em fator3.com.br e aceites de contas em ctooffice/korvena exigem observação nesses sites; testes locais não os encerram.
