# Agentes — Core 1.69.0

Leia DOCUMENTACAO.md e RELEASE-1.69.0.md antes de operar. Base 1.68.0, contrato 8.32.0, normas revisão 5. Use somente os pacotes atuais da rodada. Instale o ZIP exato; confira versão, hash, ciclo e inventário dos acompanhantes antes/depois. Não gerar código diretamente no site.

369(f,g,h): união de selecionados e descobertos; preservar cursores/recibos confirmados, reconciliar pela chave canônica adotada do produtor. Não inferir exclusão por evento failed. 369(d): resolve_campaign público 1.0.0, concessão campaign_lookup + responses e conta ads/leads. Diagnóstico campanhas distingue falha/permissão/identidade/revisão; não simular ausência silenciosamente. Regra de novas tentativas configurável com revisão/simulação. Reabrir pelo método documentado com motivo, sem contornar concessão. A tarefa preenche somente nome vazio, sem reenvio comercial.

Site-Teste autoriza implantação do pacote. A conta e os aceites reais de ctooffice pertencem à frota; testes sintéticos não comprovam campanhas reais. O relatório externo registra execução efetiva, hashes, limitações e encerramento dos impactos recebidos. Não repetir pedido de aprovação para trabalho já autorizado pelo dono.
