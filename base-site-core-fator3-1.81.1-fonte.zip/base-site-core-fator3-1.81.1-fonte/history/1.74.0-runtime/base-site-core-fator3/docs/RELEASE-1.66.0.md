# Fator3 Site Core 1.66.0

Base direta 1.65.1; instalação limpa suportada. Contrato administrativo 8.30.0, site-measurement-context/1.0.0 e site-conversion-purposes/1.1.0 preservados. Sem novo schema SQL ou credencial. Slug, opções e escolhas do usuário permanecem.

## 354(k,l) — raízes de blocos

Raízes efetivas e template-part de cabeçalho usam cache entre requisições, com chave por SHA-256 do HTML, revisão do contato, superfície, versão e geração de invalidação. Filhos retornam antes de consultas de configuração, hash, cache ou busca de contexto de the_content. A contagem de profundidade e a classificação do cabeçalho permanecem.

Com cache de objetos persistente, cada resultado usa sua chave. Com transientes, as raízes compartilham uma leitura de recipiente limitado a 128 entradas/2 MiB; cada entrada mantém sua chave e vencimento individual de até 1 h. Publicação do recipiente no footer, antes do relatório de desempenho, e shutdown como reserva. Escritas concorrentes podem substituir entradas reaproveitáveis; a consequência é recalcular o carimbo, sem devolver HTML de outra chave. save_post e alteração do contato invalidam a geração e descartam gravações pendentes. O cache de the_content permanece separado. Conteúdo autenticado, administrativo, preview, protegido por senha, com falha de parser ou maior que 1 MiB não entra no cache persistente.

desempenho-ler continua expondo raízes, profundidade, bytes e acertos/gravações por fase. Uma gravação do recipiente persiste várias raízes; o contador é de gravações, não de entradas. O limite de 100 ms em fator3.com.br exige as três amostras nesse site. Nenhuma medida local substitui esse aceite.

## 363 — contexto legível e alias

A projeção destination_loading do SDK 1.0.0 contém enabled e somente meta/linkedin/clarity, conforme seu schema fechado. Não inclui ga4/google_ads/gtm, clock ou accelerate_conversion. As opções completas e a execução das tags continuam presentes; só a representação no contrato antigo foi corrigida. O consumidor Google 0.25.1 mantém seu SDK público e não precisa ler opções privadas. O contexto de finalidades de conversão volta a consumir a fotografia válida.

Aliases de scripts sem src não recebem defer. A estratégia continua no arquivo físico f3base-publico e nos scripts com src. Isso remove o notice sem alterar dependências, dados inline ou permissões.

## 364 — catálogo independente da ordem de carga

As declarações antes adicionadas pelos inicializadores de GA4, Google Ads, Meta Ads, monitoramento Meta, histórico/SMTP de e-mail e WhatsApp agora integram a construção preguiçosa do próprio catálogo. Sua existência não depende da ordem de registro dos módulos ou de requisição pública, REST, MCP, cron ou CLI. A leitura pública preparada continua evitando abrir o catálogo completo no caminho estável.

resumo-operacional-ler acrescenta avisos.catalogo: ok, quantidade, nomes (até dez) e parcial. A consulta administrativa considera até mil nomes f3base_ gravados; não lê valores nem apaga opções. Havendo opção gravada fora do catálogo, informa option_gravada_fora_catalogo. Falha da conferência ou limite alcançado também ficam explícitos. Esses nomes podem indicar estado legado; o aviso não autoriza exclusão. Gate manage_options mantido.

## Operação e reversão

Após atualizar, ler medicao-contexto-ler, conversoes-fila-ler, meta-ads-status, config-core-ler de f3base_meta_ads, resumo-operacional-ler e desempenho-ler. Conferir Google conversion-delivery-status/readiness-status e campanhas-origem-simular com a seleção real. Sem seleção/concessão, prontidão pendente permanece correta; não preencher credenciais ou conceder acesso automaticamente.

362 e módulos P2 da base preservados. A frota informou o aceite do 362 nos 12 sites; esta nota não transforma esse relato em teste próprio. Metas de bytes da base e aceites comerciais/de frota não medidos continuam pendentes no relatório externo. Rollback apenas de arquivos para 1.65.1 preserva dados, mas reintroduz os defeitos corrigidos. Não restaurar banco nem limpar filas para reverter código.
