# Fator3 Site Core 1.69.0

Base canônica 1.68.0. Contrato administrativo 8.32.0. Pedido 369(d,f,g,h). Normas Fator3 revisão 5, 02/11/2026: WordPress mínimo 7.1.4 e PHP mínimo 8.3. Validação efetiva e identidades dos pacotes no relatório externo. Sem tabela/coluna nova, downgrade ou alteração de concessões na instalação.

## Formulários e recibos — 369(f,g,h)

No modo todos_conta_autorizada, a operação usa a união, sem duplicações, da lista explicitamente salva e dos formulários descobertos ainda autorizados. Um evento parcial não retira os formulários selecionados. Alterar o modo exige a prévia/revisão já existente; excluir um formulário selecionado exige decisão explícita da frota. Cursores existentes são preservados. Para novo formulário, início max(criação, marco de importação).

O consumidor usa linkedin-lead-reader/1.2.0 do pacote LinkedIn 0.17.1 atual. Foi removida a negociação de contrato 1.1 para versões antigas do produtor. Recibos criados anteriormente pelo contrato 1.1 são dados de migração preservados: a descoberta adota a ownership_key canônica devolvida pelo produtor. Não substitui essa chave por uma intenção nova. Evento de descoberta failed, uncertain ou equivalente não comprova remoção: conserva recibo local confirmed com ownership_key e registra descoberta_pendente (código, estado e instante). Recibos confirmed ou deleted do produtor continuam atualizando o diário. O reconciliador usa o recibo canônico.

## Campanha — 369(d)

Prioridade: nome do mapeamento local, nome decorado válido da resposta, consulta resolve_campaign por linkedin-lead-campaign/1.0.0. A extensão já foi incorporada no produtor oficial recebido, LinkedIn 0.17.1. O Core envia somente conexão/conta/formulário/resposta autorizados e revisões; não consulta IDs arbitrários de campanha, não copia tokens nem acessa o armazenamento privado do produtor.

Se faltar nome e houver ID de campanha, a captura cria uma tarefa tipo campanha no diário cifrado existente f3base_linkedin_webhook. A chave inclui contexto, conexão, conta, formulário, resposta e submittedAt em milissegundos. Falha ao gravar a tarefa impede avanço do cursor; replay da captura continua deduplicado. O diário guarda record_id, campaign_id, revisões, política, código e auditoria, sem respostas pessoais. Falha de leitura remota não bloqueia a importação do contato.

Hook f3base_linkedin_campanhas, tarefa anuncios do executor: uma consulta por execução, reserva local de 45 segundos, despacho somente com 27 segundos disponíveis. O produtor limita a leitura a 25 segundos. Não há consulta longa dentro da janela de coleta de 20 segundos. A tarefa agenda continuação; WP-Cron pode atrasar, sem promessa de prazo real. A consulta usa campaign_lookup e responses na concessão, conta selecionada em leads e ads e escopo r_ads ou rw_ads. As permissões metadata/verify/subscriptions e callback continuam exigidas para descoberta e assinaturas.

Antes de preencher o nome, o Core confere conta, formulário, resposta, submittedAt, campanha, revisão da credencial e da concessão e configuração da integração. A transação bloqueia recibo e registro; confere origem nativa completa, revisão e identidade, ignora registros eliminados/na lixeira e preserva nome já preenchido. Somente atribuicao.utm_campaign, proveniência, versão de enriquecimento, revisão e atualizado_em mudam. Não reingere o contato nem cria novo aviso, CRM ou conversão. Um envio comercial já realizado não é reenviado pelo enriquecimento tardio.

O parceiro mantém f3base_pipedrive.parceiros_plataforma.linkedin_ads quando não existe campanha mapeada. Nenhum parceiro ou permissão é inventado. A ocorrência campanha_sem_mapeamento ou campanha_sem_nome_e_mapeamento continua orientando a frota a completar o mapa, mesmo que o nome seja obtido depois. Um mapa preenchido enquanto a tarefa aguarda tem prioridade sobre nova consulta.

## Tentativas, diagnóstico e recuperação

Campo facultativo por integração: campanhas_retry = {"max_tentativas":3,"intervalo_segundos":300}. Limites: 1–10 e 60–86400 segundos. Ausência usa esses padrões. A configuração usa o canal administrativo genérico, simulação e revisão; a tarefa registra política e revisão efetivamente utilizadas. Erros transitórios respeitam também retry_after. Cada tentativa é reservada antes da leitura; falha abrupta não gera laço ilimitado. Esgotamento, 403, escopo/concessão ausente, identidade divergente e revisão alterada ficam em estado revisao, com código do produtor ou código específico do Core.

f3base/anuncios-verificar → LinkedIn → campanhas e o painel Conexões → LinkedIn → Estado mostram as últimas 50 tarefas, chaves, estado, código, tentativas, próxima execução e política, sem valores pessoais. Uma falha não fica sem saída administrativa: f3base/linkedin-campanha-reabrir recebe integracao_id, chave, simular (padrão true), revisao e motivo (5–500 caracteres). Simular devolve revisão do registro/configuração; aplicar exige a mesma revisão e motivo. Reabre contagem e registra usuário, instante, motivo, revisão e tentativas anteriores no diário cifrado. A concessão atual continua sendo validada pelo produtor. Assinaturas, captura e CRM não são reenviados. O executor existente pode ser acionado sob demanda para a tarefa anuncios.

## Instalação e limites de aceite

Instalação limpa e atualização direta 1.68.0 → 1.69.0 usam as estruturas existentes. Nenhuma seleção, credencial ou conexão é ampliada automaticamente. O cliente direto Core continua disponível por escolha explícita; a nova consulta de campanha depende do cliente linkedin_plugin. Não há fallback automático entre clientes nem suporte negociado para produtores anteriores.

O teste do pacote começa com quatro formulários selecionados e quatro recibos 1.1, muda para todos, prova adoção canônica sem POST adicional e inclui o quinto. APIs remotas são simuladas sobre o código oficial LinkedIn 0.17.1; não equivalem ao aceite real em ctooffice. Esse aceite, com as quatro assinaturas reais e novo formulário do Campaign Manager, continua com a frota (pendência 20). Pedidos 368 e 370 recebem regressão; 365–368/370 já entregues não são reabertos. Metas anteriores de bytes continuam pendências externas. Sem implantação de produção nesta rodada.
