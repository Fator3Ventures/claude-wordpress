# Web Vitals por versão de origem

No menu **Site Core → Relatórios**, abra a aba **Técnico**, selecione **Web Vitals por versão** em **Análise** e clique em **Atualizar relatório**. A visão **Web Vitals** também apresenta um link para essa tabela. O endereço administrativo é `admin.php?page=f3base-medicao&area=tecnico&visao=vitais`. Use o campo **Versão de origem** para reunir as amostras de uma edição do Core. Informe uma versão com três números separados por ponto, como `1.72.1`. Deixe o campo vazio para ver todas as origens. Informe `sem_versao` para inspecionar o conjunto de origem desconhecida.

O p75, a contagem elegível, as exclusões por automação/legado e, no detalhamento, as fases usam o mesmo filtro. Para comparar edições, conserve caminho, dispositivo, período, segmento de testes e classe de automação. Leia o número de amostras ao lado do percentil. Com duas medidas, o p75 corresponde à maior. Uma diferença entre versões pode refletir mudanças na rede, no cache, no conteúdo ou na composição do público.

## Origem atribuída a cada carregamento

A página inclui a versão do Core que gerou o HTML e o JavaScript traz a versão do coletor que efetivamente executou. O build confere esse marcador com o cabeçalho do plugin. O navegador declara a versão na amostra somente quando os dois valores coincidem. O servidor valida o formato recebido e conserva a declaração original.

| Situação observada | Resultado |
| --- | --- |
| HTML e coletor declaram a mesma versão | A versão coincidente acompanha a amostra desde sua criação. |
| HTML e coletor de versões diferentes; HTML anterior à marcação; coletor anterior à marcação | A amostra entra no grupo de origem desconhecida. |
| Lote de um carregamento anterior enviado depois da atualização | Conserva a versão registrada originalmente ou a ausência dela. O servidor que recebeu o lote pode executar outra edição. |
| Linha que já existia quando o site recebeu a 1.72.0 | A migração conserva a medida e atribui origem desconhecida. |
| Duas emissões da mesma chave declaram origens diferentes, inclusive quando uma omite a versão | A única linha passa definitivamente ao grupo de origem desconhecida. O valor e a atribuição da maior sequência continuam a prevalecer. |

A versão é informação técnica declarada por um cliente. Ela identifica a combinação observada de HTML e coletor do Core. O cliente público pode simular valores válidos, e outros componentes da página, intermediários e provedores têm seus próprios ciclos. O mecanismo conserva os controles de consentimento, a chave da amostra e a retenção. Acrescenta apenas a versão numérica, sem URL, sessão, identificador de visitante ou dado de formulário.

## Contrato de leitura

A ability administrativa `f3base/vitais-ler` aceita o filtro opcional `versao_origem` a partir do contrato 8.34.0. Uma consulta de exemplo para obter contagens e p75:

```json
{
  "dias": 28,
  "metrica": "LCP",
  "dispositivo": "movel",
  "segmento": "sem_testes",
  "automacao": "audiencia",
  "versao_origem": "1.72.1",
  "somente_resumo": true
}
```

Use `"versao_origem": "sem_versao"` para histórico e demais origens desconhecidas. Quando omitido, o filtro inclui todas as versões e a resposta informa `"versao_origem": null`. Quando informado, a resposta devolve o valor aplicado. O modo resumo consulta somente as contagens e o p75. A leitura exige a mesma permissão administrativa da versão anterior.

Na gravação, o objeto `amostra` pode omitir `versao_origem`; se presente, o valor deve ter três componentes numéricos de até quatro dígitos, sem zeros à esquerda, exceto o próprio zero. Texto livre, rótulos, URLs e `sem_versao` como valor declarado pelo cliente são recusados.

## Dados e migração

`f3base_vitais.versao_origem` é `varchar(14) NOT NULL DEFAULT ''`. O índice `origem_periodo` usa `versao_origem, dia, metrica`. A chave primária `amostra` continua identificando um único carregamento por métrica/caminho e segmento de teste. A edição não integra a chave; assim, conflito de origem e reenvio preservam a unidade de contagem.

O WordPress novo cria a tabela com o esquema completo. Na atualização de uma tabela 1.71 existente, o instalador lê metadados e emite um único `ALTER TABLE` com `ADD COLUMN` e `ADD INDEX` quando faltam ambos. Se a coluna já está pronta, acrescenta somente o índice. O banco só registra o esquema 17200 depois de verificar a coluna e a definição do índice. Um objeto homônimo incompatível bloqueia a etapa com `vitais_coluna_origem_incompativel` ou `vitais_indice_origem_incompativel`; formato-base incompatível produz `vitais_base_incompativel`. A retomada verifica outra vez os metadados.

A introdução do esquema preserva cada linha, inclusive as vencidas. O instalador não executa consultas de dados, atualização de valores, reconciliação de colunas antigas ou exclusão durante essa alteração. O MySQL pode ler páginas e usar bloqueios próprios para construir o índice. A rotina regular de retenção e a manutenção subsequente com o esquema já pronto continuam a aplicar o prazo configurado. O caminho público de leitura usa o marcador de esquema. A migração requer a edição do Core e o próprio banco WordPress, sem atualização complementar de outros plugins.

A regressão nativa inclui base histórica, falha/retomada da alteração, repetição idempotente, filtros, painel e disputa de dois processos WordPress pela mesma chave. A regressão no navegador controlado inclui fonte, minificado e variantes de perfis, HTML antigo/novo e filas recuperadas em uma edição posterior.
