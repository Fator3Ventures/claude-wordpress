<?php
/** SMTP AUTH proof; never sends MAIL, RCPT or DATA. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
require_once ABSPATH.WPINC.'/PHPMailer/SMTP.php';
class F3Base_SMTP_Cliente extends \PHPMailer\PHPMailer\SMTP {
    public string $fase='preparo';
    public string $falha='smtp_preparo_falhou';
    public function connect($host,$port=null,$timeout=30,$options=array()) {
        $this->fase='porta';$this->falha='smtp_porta_sem_resposta';$ok=parent::connect($host,$port,$timeout,$options);
        if(!$ok){$e=$this->getError();$detail=strtolower((string)($e['detail']??''));$this->falha=preg_match('/ssl|crypto|certificate|tls/',$detail)?'smtp_tls_falhou':(str_contains($detail,'refused')||in_array((int)($e['smtp_code']??0),array(61,111),true)?'smtp_porta_recusada':'smtp_porta_sem_resposta');}
        return $ok;
    }
    public function hello($host='') {$this->fase='protocolo';$this->falha='smtp_protocolo_falhou';$ok=parent::hello($host);if(!$ok){$this->falha='smtp_protocolo_falhou';}return $ok;}
    public function startTLS() {$this->fase='tls';$this->falha='smtp_tls_falhou';$ok=parent::startTLS();if(!$ok){$this->falha='smtp_tls_falhou';}return $ok;}
    public function authenticate($username,$password,$authtype=null,$OAuth=null) {$this->fase='autenticacao';$this->falha='smtp_autenticacao_recusada';$ok=parent::authenticate($username,$password,$authtype,$OAuth);if(!$ok){$this->falha='smtp_autenticacao_recusada';}return $ok;}
}
final class F3Base_SMTP_Prova {
    const STATE='f3base_email_smtp_prova';
    const TTL=900;
    public static function assinatura(array $cfg): string {return hash('sha256',wp_json_encode(array_intersect_key($cfg,array_flip(array('smtp_host','smtp_porta','smtp_seguranca','usuario','endereco')))).'|'.F3Base_Options::revisao(F3Base_Email_Site_Config::SECRET));}
    public static function vigente(array $cfg): bool {$s=get_option(self::STATE,array());return !empty($s['ok'])&&(int)($s['em']??0)>time()-self::TTL&&hash_equals((string)($s['assinatura']??''),self::assinatura($cfg));}
    public static function resumo(): array {$s=get_option(self::STATE,array());unset($s['assinatura']);return $s+array('vigente'=>self::vigente(F3Base_Email_Site::cfg()),'validade_segundos'=>self::TTL);}
    public static function configurar($mail,array $cfg,string $password): void {
        $host=(string)($cfg['smtp_host']??'');$port=(int)($cfg['smtp_porta']??0);$sec=$cfg['smtp_seguranca']??'';
        if(!in_array($port,array(465,587),true)||($port===465)!==($sec==='ssl')||!in_array($sec,array('ssl','tls'),true)||!preg_match('/^[a-z0-9.-]+$/iD',$host)||!wp_http_validate_url('https://'.$host.'/')){throw new RuntimeException('smtp_destino_invalido');}
        $ips=gethostbynamel($host)?:array();if(!$ips){throw new RuntimeException('smtp_dns_indisponivel');}foreach($ips as $ip){if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)){throw new RuntimeException('smtp_destino_invalido');}}
        $mail->isSMTP();$mail->Host=$ips[0];$mail->Port=$port;$mail->SMTPSecure=$sec;$mail->SMTPAutoTLS=false;$mail->SMTPOptions=array('ssl'=>array('verify_peer'=>true,'verify_peer_name'=>true,'peer_name'=>$host,'allow_self_signed'=>false));$mail->SMTPAuth=true;$mail->Username=(string)($cfg['usuario']??$cfg['smtp_usuario']??'');$mail->Password=$password;$mail->Timeout=8;$mail->SMTPDebug=0;$mail->setSMTPInstance(new F3Base_SMTP_Cliente());$mail->getSMTPInstance()->Timelimit=15;
    }
    public static function codigo($mail,?Throwable $e=null): string {
        if($e&&preg_match('/^smtp_(?:destino_invalido|dns_indisponivel)$/D',$e->getMessage())){return $e->getMessage();}
        $smtp=$mail->getSMTPInstance();return $smtp instanceof F3Base_SMTP_Cliente?$smtp->falha:'smtp_preparo_falhou';
    }
    public static function verificar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $cfg=F3Base_Email_Site::cfg();foreach(array('smtp_porta','smtp_seguranca') as $k){if(isset($e[$k])){$cfg[$k]=$e[$k];}}
        $stamp=self::assinatura($cfg);$mail=null;$ok=false;$code='smtp_preparo_falhou';$phase='preparo';
        try{require_once ABSPATH.WPINC.'/PHPMailer/Exception.php';require_once ABSPATH.WPINC.'/PHPMailer/PHPMailer.php';$mail=new \PHPMailer\PHPMailer\PHPMailer(true);$password=F3Base_Segredos::abrir(F3Base_Email_Site_Config::SECRET);if($password===''||$cfg['usuario']===''){return array('ok'=>false,'codigo'=>'smtp_credencial_ausente');}self::configurar($mail,$cfg,$password);$ok=$mail->smtpConnect();$phase=$mail->getSMTPInstance()->fase;$code=$ok?'smtp_autenticado_sem_envio':self::codigo($mail);}
        catch(Throwable $x){$code=$mail?self::codigo($mail,$x):'smtp_preparo_falhou';$phase=$mail&&$mail->getSMTPInstance() instanceof F3Base_SMTP_Cliente?$mail->getSMTPInstance()->fase:'preparo';}
        finally{if($mail){$mail->smtpClose();}}
        $r=array('ok'=>$ok,'codigo'=>$code,'fase'=>$phase,'em'=>time(),'operador'=>get_current_user_id(),'smtp_porta'=>$cfg['smtp_porta'],'smtp_seguranca'=>$cfg['smtp_seguranca'],'assinatura'=>$stamp);
        // Diagnostic persists its receipt even in simulation; no message or commercial state is changed.
        $saved=F3Base_Options::atualizar_estado(self::STATE,static fn($old)=>$r);unset($r['assinatura']);return $r+array('prova_persistida'=>!empty($saved['persisted']),'simular'=>true,'mensagens_enviadas'=>0,'data_transmitido'=>false,'validade_segundos'=>self::TTL);
    }
    public static function iniciar(): void {
        /* Declaration belongs to F3Base_Options. */
        add_action('admin_post_f3base_smtp_provar',static function(){if(!current_user_can('manage_options')){wp_die('Sem permissão',403);}check_admin_referer('f3base_smtp_provar');self::verificar();wp_safe_redirect(admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_email_site'));exit;});
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('email-smtp-verificar','Provar conexão, TLS e AUTH sem DATA; grava recibo técnico válido por 15 minutos',array(__CLASS__,'verificar'),array('simular'=>array('type'=>'boolean','enum'=>array(true),'default'=>true),'smtp_porta'=>array('type'=>'integer','enum'=>array(465,587)),'smtp_seguranca'=>array('type'=>'string','enum'=>array('ssl','tls'))),array(),false);});
    }
    public static function tela(): void {
        if(!current_user_can('manage_options')){return;}echo '<div class="notice notice-info inline"><p>Prova SMTP: '.esc_html(wp_json_encode(self::resumo(),JSON_UNESCAPED_UNICODE)).'</p><p>A prova verifica conexão, TLS e autenticação, sem enviar mensagem. Salve a configuração com o envio desligado, prove e depois habilite em até 15 minutos.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_smtp_provar">';wp_nonce_field('f3base_smtp_provar');submit_button('Provar SMTP sem enviar','secondary','submit',false);echo '</form></div>';
    }
}
