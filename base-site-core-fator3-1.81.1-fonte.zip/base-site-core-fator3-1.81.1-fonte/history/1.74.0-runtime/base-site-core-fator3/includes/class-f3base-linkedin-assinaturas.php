<?php
/** Core journal over the provider's public subscription journal. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Assinaturas {
    private static function salvar(string $key,array $v): bool {$r=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($key,$v){$s['assinaturas_sdk'][$key]=$v;return $s;});return !empty($r['persisted']);}
    public static function sincronizar(string $action): array {
        $cfg=F3Base_Linkedin::config();$ctx=F3Base_Linkedin::contexto();$active=$action!=='drenar'&&!empty($cfg['ativo'])&&!empty($cfg['webhook']['ativo']);$out=array();$deadline=microtime(true)+20;
        $existing=F3Base_Linkedin_Integracoes::estado()['assinaturas_sdk']??array();
        foreach($existing as $key=>$entry){
            if(microtime(true)>$deadline-3){return array('ok'=>false,'codigo'=>'assinaturas_em_continuacao','resultados'=>$out);}
            if(($entry['state']??'')==='deleted'){continue;}
            if(empty($entry['ownership_key'])&&($entry['origem']??'')==='descoberta_produtor'){$out[$key]=array('ok'=>false,'codigo'=>$entry['code']??'assinatura_produtor_pendente','remote_effect'=>$entry['remote_effect']??'unknown');continue;}
            if(empty($entry['ownership_key'])){
                $replay=F3Base_Linkedin_Cliente::chamar('create_subscription',array('form_id'=>$entry['form_id'],'form_version'=>$entry['form_version'],'callback_url'=>F3Base_Linkedin_Webhook::url($entry['contexto']),'idempotency_key'=>$entry['idempotency_key']));
                if(!empty($replay['ok'])){$entry=array_replace($entry,$replay['data']);}elseif(!empty($replay['detalhes']['ownership_key'])){$entry['ownership_key']=$replay['detalhes']['ownership_key'];$entry['state']='uncertain';$entry['remote_effect']=$replay['detalhes']['remote_effect']??'unknown';}
                if(!self::salvar($key,$entry)||empty($entry['ownership_key'])){$out[$key]=array('ok'=>false,'codigo'=>'intencao_sem_recibo_reconciliar');continue;}
            }
            $r=F3Base_Linkedin_Cliente::chamar('get_subscription_operation',array('ownership_key'=>$entry['ownership_key']));
            if(empty($r['ok'])){$out[$key]=$r;continue;}$entry=array_replace($entry,$r['data']);
            if(!in_array($entry['state'],array('confirmed','deleted','rejected_before_dispatch'),true)){
                $r=F3Base_Linkedin_Cliente::chamar('reconcile_subscription',array('ownership_key'=>$entry['ownership_key'],'expected_operation_revision'=>$entry['operation_revision'],'authorize_current_context'=>false));
                if(empty($r['ok'])){self::salvar($key,$entry);$out[$key]=$r;continue;}$entry=array_replace($entry,$r['data']);
            }
            if(!$active&&$entry['state']==='confirmed'){$r=F3Base_Linkedin_Cliente::chamar('delete_subscription',array('ownership_key'=>$entry['ownership_key']));if(!empty($r['ok'])){$entry=array_replace($entry,$r['data']);}else{$entry['ultimo_erro']=$r['codigo'];$entry['remote_effect']=$r['detalhes']['remote_effect']??'unknown';}}
            $saved=self::salvar($key,$entry);$out[$key]=$saved?$r:array('ok'=>false,'codigo'=>'recibo_sdk_nao_persistido');
        }
        if($active){foreach(F3Base_Linkedin::formularios($cfg) as $form){
            if(microtime(true)>$deadline-3){$out[$form]=array('ok'=>false,'codigo'=>'assinaturas_em_continuacao');break;}
            $f=F3Base_Linkedin::formulario($form,$cfg);if(empty($f['ok'])){$out[$form]=$f;continue;}$version=(string)$f['formulario']['versionId'];$key=hash('sha256',$ctx.'|'.$cfg['conta_id'].'|'.$form.'|'.$version);
            if(isset($existing[$key])){continue;}
            // Persist exact intent before calling. A crash cannot choose a new key.
            $entry=array('state'=>'prepared','form_id'=>$form,'form_version'=>$version,'contexto'=>$ctx,'idempotency_key'=>$key,'em'=>time());
            if(!self::salvar($key,$entry)){$out[$key]=array('ok'=>false,'codigo'=>'intencao_nao_persistida');continue;}
            $r=F3Base_Linkedin_Cliente::chamar('create_subscription',array('form_id'=>$form,'form_version'=>$version,'callback_url'=>F3Base_Linkedin_Webhook::url($ctx),'idempotency_key'=>$key));
            if(!empty($r['ok'])){$entry=array_replace($entry,$r['data']);}else{$entry['state']='uncertain';$entry['ultimo_erro']=$r['codigo'];$entry['ownership_key']=$r['detalhes']['ownership_key']??null;$entry['remote_effect']=$r['detalhes']['remote_effect']??'unknown';}
            $saved=self::salvar($key,$entry);$out[$key]=$saved?$r:array('ok'=>false,'codigo'=>'recibo_sdk_nao_persistido');
        }}
        return array('ok'=>!array_filter($out,static fn($r)=>empty($r['ok'])||isset($r['data']['state'])&&!in_array($r['data']['state'],array('confirmed','deleted','rejected_before_dispatch'),true)),'codigo'=>'assinaturas_sdk_verificadas','resultados'=>$out,'entrega_remota_comprovada'=>false);
    }
}
