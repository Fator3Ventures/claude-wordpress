<?php
/** Os handlers são carregados somente quando o hook correspondente é executado. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }

final class F3Base_Bootstrap {
    private static ?array $publicos = null;
    private static ?array $complementares = null;
    private static array $iniciadas = [];

    public static function iniciar(string $class): void {
        if (isset(self::$iniciadas[$class])) {
            return;
        }
        self::$iniciadas[$class] = true;
        if (defined('F3BASE_BUILD_BOOTSTRAP') && F3BASE_BUILD_BOOTSTRAP) {
            $class::iniciar();
            return;
        }

        self::$publicos ??= require __DIR__ . '/bootstrap-hooks-publicos.php';
        // Um módulo público com registro nativo também dispensa o complemento.
        if (array_key_exists($class, self::$publicos)) {
            $registrar = self::$publicos[$class];
        } else {
            self::$complementares ??= require __DIR__ . '/bootstrap-hooks.php';
            $registrar = self::$complementares[$class] ?? null;
        }

        if ($registrar !== null) {
            $registrar();
        } else {
            $class::iniciar();
        }
    }
}
