<?php
/** LinkedIn controls in the existing integrations area; secrets never rendered. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Admin {
    public static function validar(array $v): string {
        foreach(array('conta_id','aplicativo_id') as $key){if(!empty($v[$key])&&!preg_match('/^[0-9]{1,40}$/D',(string)$v[$key])){return 'Informe somente a ID numérica em '.$key.'.';}}
        foreach($v['formularios']??array() as $f){if(!is_string($f)||F3Base_Linkedin::form_id($f)===''){return 'Formulário inválido: use a ID numérica ou a URN de formulário obtida no LinkedIn.';}}
        $maps=array($v['mapeamento']['campos']??array());foreach($v['mapeamento']['formularios']??array() as $f=>$m){if(F3Base_Linkedin::form_id((string)$f)===''||!is_array($m)){return 'Mapa por formulário inválido.';}$maps[]=$m['campos']??array();}
        foreach($maps as $map){if(!is_array($map)){return 'O mapa de campos deve ser um objeto.';}foreach($map as $key=>$role){if(!is_scalar($key)||!is_string($role)||!in_array($role,array('nome','email','telefone','empresa','cargo','servicos'),true)){return 'Papéis aceitos: nome, email, telefone, empresa, cargo e servicos.';}}}
        if(!empty($v['ativo'])&&(empty($v['conta_id'])||empty($v['proprietario_confirmado']))){return 'Para ativar, informe a conta e confirme a responsabilidade pelos formulários.';}return '';
    }
    public static function salvar_entrada(array $e): array {
        $cfg=$e['config']??null;if(!current_user_can('manage_options')||!is_array($cfg)){return array('ok'=>false,'codigo'=>'entrada_ou_permissao_invalida');}
        $all=F3Base_Linkedin_Integracoes::colecao();$all[F3Base_Linkedin_Integracoes::id()]=$cfg;$canonical=array('integracoes'=>$all);$error=F3Base_Options::recusar(F3Base_Linkedin::OPCAO,$canonical,F3Base_Options::declaracao(F3Base_Linkedin::OPCAO));if($error!==''){return array('ok'=>false,'codigo'=>'configuracao_recusada','motivo'=>$error);}
        $values=array(F3Base_Linkedin::OPCAO=>$canonical);foreach(array(F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET) as $name){$new=F3Base_Linkedin_Cliente::externo()?'':($e['segredos'][$name]??'');if(F3Base_Linkedin_Cliente::externo()&&!empty($e['apagar'][$name])){return array('ok'=>false,'codigo'=>'credencial_pertence_ao_core');}if(!is_string($new)){return array('ok'=>false,'codigo'=>'segredo_invalido');}if(!empty($e['apagar'][$name])||$new!==''){$values[$name]=!empty($e['apagar'][$name])?'':$new;$err=F3Base_Segredos::recusar($name,$values[$name]);if($err){return array('ok'=>false,'codigo'=>'segredo_recusado','motivo'=>$err);}}}
        foreach($values as $name=>$value){if(!hash_equals(F3Base_Options::revisao($name),(string)($e['revisoes'][$name]??''))){return array('ok'=>false,'codigo'=>'conflito','motivo'=>'A configuração mudou. Reabra esta área antes de salvar.');}}
        return F3Base_Options::com_proposta($values,static function()use($values,$e){
            foreach($values as $name=>$value){if(F3Base_Segredos::gerenciado($name)){$error=F3Base_Options::recusar($name,$value,F3Base_Options::declaracao($name));if($error!==''){return array('ok'=>false,'codigo'=>'credencial_recusada','motivo'=>$error,'verificacao'=>F3Base_Credenciais::ultima());}}}
        $results=array();foreach($values as $name=>$value){$r=F3Base_Options::pelo_canal('admin',static fn()=>F3Base_Options::gravar($name,$value,F3Base_Options::ORIGEM_MANUAL,$e['revisoes'][$name]));$results[$name]=array('persisted'=>!empty($r['persisted']),'codigo'=>$r['codigo']??'');if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'salvamento_parcial','motivo'=>'Uma parte não foi salva. Confira os resultados antes de repetir.','campos'=>$results);}}
        return array('ok'=>true,'codigo'=>'configuracao_salva','motivo'=>'Preferências salvas. Conferir acesso lê somente token e formulários; a coleta de contatos depende da ativação.','campos'=>$results);
        });
    }
    private static function terminar(array $r): void {set_transient('f3base_integracao_resultado_'.get_current_user_id(),$r,300);wp_safe_redirect(add_query_arg('linkedin_id',sanitize_key($_POST['integracao_id']??($r['integracao_id']??'')),admin_url('admin.php?page=base-site-core-fator3&secao=conexoes&integracao=f3base_anuncios_linkedin')));exit;}
    public static function post(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-linkedin');
        if(($_POST['operacao']??'')==='criar'){self::terminar(self::criar(wp_unslash($_POST)));}
        $r=F3Base_Linkedin_Integracoes::executar(isset($_POST['integracao_id'])?sanitize_key($_POST['integracao_id']):null,static function(){self::post_escopo();});if(is_array($r)){self::terminar($r);}
    }
    private static function chave_previa(string $tipo): string {
        return 'f3base_linkedin_'.$tipo.'_'.get_current_user_id().'_'.F3Base_Linkedin_Integracoes::id();
    }
    public static function troca_painel(array $e): array {
        if (!current_user_can('manage_options')) { return ['ok'=>false,'codigo'=>'sem_permissao']; }
        $chave=self::chave_previa('troca_previa');
        if (($e['confirmar']??'')==='1') {
            $previa=get_transient($chave);
            if (!is_array($previa) || !is_string($e['previa']??null) || !hash_equals($previa['id'],$e['previa'])) { return ['ok'=>false,'codigo'=>'previa_desatualizada','motivo'=>'Confira novamente a conexão antes de aplicar.']; }
            $pedido=$previa['pedido'];$pedido['simular']=false;
            $r=F3Base_Linkedin_Transicao::executar($pedido);
            if (!empty($r['ok'])) { delete_transient($chave); }
            return $r;
        }
        foreach (['cliente','connection_id','conta_id','formularios'] as $campo) {
            if (!is_string($e[$campo]??null)) { return ['ok'=>false,'codigo'=>'entrada_invalida']; }
        }
        $estado=F3Base_Linkedin_Integracoes::estado()['transicao']??[];
        $emCurso=isset($estado['chave'])&&!in_array($estado['fase']??'',['concluida','cancelada'],true);
        $pedido=['integracao_id'=>F3Base_Linkedin_Integracoes::id(),'cliente'=>sanitize_key($e['cliente']),'connection_id'=>sanitize_text_field($e['connection_id']),'conta_id'=>trim($e['conta_id']),
            'formularios'=>array_values(array_filter(array_map('trim',preg_split('/[\r\n,]+/',$e['formularios'])),static fn($id)=>$id!=='')),'simular'=>true,
            'chave_operacao'=>$emCurso?$estado['chave']:wp_generate_uuid4(),'revisao'=>F3Base_Options::revisao(F3Base_Linkedin::OPCAO)];
        if ($emCurso) { $pedido=array_replace($pedido,array_intersect_key($estado['destino']??[],array_flip(['cliente','connection_id','conta_id','formularios']))); }
        $r=F3Base_Linkedin_Transicao::executar($pedido);
        if (empty($r['ok'])) { delete_transient($chave);return $r; }
        $pedido['revisao']=$r['revisao'];$pedido['revisoes_conferidas']=$r['prova']['revisoes']??[];
        if (!set_transient($chave,['id'=>wp_generate_uuid4(),'pedido'=>$pedido],10*MINUTE_IN_SECONDS)) { return ['ok'=>false,'codigo'=>'previa_nao_guardada']; }
        return $r;
    }
    private static function salvar_painel(array $e): array {
        $cfg=F3Base_Linkedin::config();$campos=$e['config']??null;$mapa=$e['mapeamento']??null;
        if (!is_array($campos) || !is_string($mapa) || ($e['preferencias_completas']??'')!=='1') { return ['ok'=>false,'codigo'=>'formulario_incompleto','motivo'=>'Reabra as preferências da integração.']; }
        foreach (['ativo','proprietario_confirmado'] as $key) { $cfg[$key]=!empty($campos[$key]); }
        if (!F3Base_Linkedin_Cliente::externo()) {
            foreach (['client_id','aplicativo_id'] as $key) {
                if (!is_string($campos[$key]??null)) { return ['ok'=>false,'codigo'=>'formulario_incompleto']; }
                $cfg[$key]=trim($campos[$key]);
            }
        }
        $obj=json_decode($mapa,true);
        if (!is_array($obj)) { return ['ok'=>false,'codigo'=>'mapeamento_invalido','motivo'=>'Revise os campos e campanhas antes de salvar.']; }
        $cfg['mapeamento']=$obj;$e['config']=$cfg;
        return self::salvar_entrada($e);
    }
    private static function post_escopo(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-linkedin');$action=sanitize_key($_POST['operacao']??'');
        if($action==='trocar'){self::terminar(self::troca_painel(wp_unslash($_POST)));}
        if($action==='salvar'){self::terminar(self::salvar_painel(wp_unslash($_POST)));}
        if($action==='formularios_modo'){$e=wp_unslash($_POST);$e['simular']=($e['aplicar']??'')!=='1';$r=F3Base_Linkedin_Descoberta::configurar($e);if(!empty($r['simular'])&&!empty($r['ok'])){set_transient(self::chave_previa('previa'),$r,600);}else{delete_transient(self::chave_previa('previa'));}self::terminar($r);}
        if($action==='verificar'){self::terminar(F3Base_Linkedin::verificar(array('simular'=>false)));}
        if($action==='consultar'){self::terminar(F3Base_Linkedin::consultar());}
        if(in_array($action,array('ativar','desativar','reconciliar'),true)){$r=F3Base_Options::pelo_canal('admin',static fn()=>F3Base_Linkedin_Webhook::configurar(array('acao'=>$action,'simular'=>false,'revisao'=>sanitize_text_field($_POST['revisao']??''),'chave_operacao'=>sanitize_text_field($_POST['chave_operacao']??''))));self::terminar($r);}wp_die('Ação inválida.',400);
    }
    private static function abrir_form(string $op): void {echo '<form '.($op==='salvar'?'data-f3base-edicao ':'').'method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_linkedin"><input type="hidden" name="operacao" value="'.esc_attr($op).'">';echo '<input type="hidden" name="integracao_id" value="'.esc_attr(F3Base_Linkedin_Integracoes::id()).'">';wp_nonce_field('f3base-linkedin');}
    public static function render(): void {
        if (!current_user_can('manage_options')) { wp_die('Sem permissão.',403); }
        echo '<h2>Integrações LinkedIn</h2><ul>';
        foreach(F3Base_Linkedin_Integracoes::colecao() as $id=>$cfg){echo '<li><a href="'.esc_url(add_query_arg('linkedin_id',$id)).'">'.esc_html($cfg['rotulo'].' · '.$id).'</a> — '.esc_html($cfg['cliente'].' · conta '.$cfg['conta_id'].' · '.count($cfg['formularios']).' formulários').'</li>';}
        echo '</ul><details><summary>Adicionar integração</summary><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_linkedin"><input type="hidden" name="operacao" value="criar">';wp_nonce_field('f3base-linkedin');echo '<input type="hidden" name="revisao" value="'.esc_attr(F3Base_Options::revisao(F3Base_Linkedin::OPCAO)).'"><p><label>Identificador <input name="nova_id" required pattern="[a-z][a-z0-9_-]{0,39}"></label></p><p><label>Nome <input name="rotulo" required></label></p><button class="button">Criar integração pausada</button></form></details>';
        $id=isset($_GET['linkedin_id'])&&is_string($_GET['linkedin_id'])?sanitize_key($_GET['linkedin_id']):null;
        if($id===null&&count(F3Base_Linkedin_Integracoes::colecao())!==1){echo '<p>Selecione a integração que deseja configurar.</p>';return;}
        $r=F3Base_Linkedin_Integracoes::executar($id,static function(){self::render_escopo();});if(is_array($r)&&empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']).'</p>';}
    }
    private static function render_escopo(): void {
        $cfg=F3Base_Linkedin::config();$diag=F3Base_Linkedin::diagnostico();$externo=F3Base_Linkedin_Cliente::externo();
        echo '<section class="f3base-config-grupo"><h3>Conexão e formulários</h3><p>Cliente atual: <strong>'.esc_html($externo?'Plugin LinkedIn':'Core').'</strong> · Conta: '.esc_html($cfg['conta_id']?:'a configurar').' · Formulários salvos: '.esc_html(implode(', ',$cfg['formularios'])?:'nenhum').'.</p>';
        $estado=F3Base_Linkedin_Integracoes::estado()['transicao']??[];
        $pendente=isset($estado['chave'])&&!in_array($estado['fase']??'',['concluida','cancelada'],true);
        $selecionado=$pendente?array_replace($cfg,$estado['destino']??[]):$cfg;
        echo '<details><summary>'.($pendente?'Retomar alteração de conexão':'Alterar conexão, conta ou lista de formulários').'</summary>';
        self::abrir_form('trocar');
        echo '<p><label>Cliente <select name="cliente"><option value="core" '.selected($selecionado['cliente'],'core',false).'>Core</option><option value="linkedin_plugin" '.selected($selecionado['cliente'],'linkedin_plugin',false).'>Plugin LinkedIn</option></select></label></p><p><label>Referência da conexão <input name="connection_id" value="'.esc_attr($selecionado['connection_id']).'" required></label></p><p><label>ID da conta de anúncios <input name="conta_id" value="'.esc_attr($selecionado['conta_id']).'"></label></p>';
        F3Base_Anuncios_Selecao::campo(F3Base_Linkedin::OPCAO,'formularios',$selecionado['formularios'],'formularios','f3base-linkedin-formularios',true);
        echo '<p class="description">A lista consultada usa a conta salva. Para outra conta, informe os IDs dos formulários de destino. A prévia confere o acesso aos formulários.</p><button class="button" name="confirmar" value="0">Conferir prévia da conexão</button></form></details>';
        $previa=get_transient(self::chave_previa('troca_previa'));
        if (is_array($previa)) {
            $alvo=$previa['pedido']; self::abrir_form('trocar');
            echo '<div class="f3base-previa"><h4>Conexão conferida</h4><p>'.esc_html(($alvo['cliente']==='core'?'Core':'Plugin LinkedIn').' · '.$alvo['connection_id'].' · conta '.$alvo['conta_id'].' · formulários '.(implode(', ',$alvo['formularios'])?:'nenhum')).'</p><p>Aplicar inicia ou retoma a troca para esta seleção.</p><input type="hidden" name="previa" value="'.esc_attr($previa['id']).'"><button class="button button-primary" name="confirmar" value="1">Aplicar conexão conferida</button></div></form>';
        }
        echo '<h4>Seleção de formulários</h4><p>A lista salva permanece em operação no modo automático. Para incluir os novos formulários, habilite o recebimento imediato e conceda acesso à conta no Plugin LinkedIn.</p>';
        self::abrir_form('formularios_modo');$modo=$cfg['formularios_modo']??'selecionados';
        echo '<label>Importar <select name="formularios_modo"><option value="selecionados" '.selected($modo,'selecionados',false).'>Somente a lista salva</option><option value="todos_conta_autorizada" '.selected($modo,'todos_conta_autorizada',false).'>Todos os formulários autorizados da conta</option></select></label> <button class="button" name="aplicar" value="0">Conferir seleção</button></form>';
        $previa=get_transient(self::chave_previa('previa'));
        if (is_array($previa)) {
            self::abrir_form('formularios_modo');
            foreach (['formularios_modo','revisao','confirmacao'] as $key) { echo '<input type="hidden" name="'.esc_attr($key).'" value="'.esc_attr($previa[$key]).'">'; }
            echo '<div class="f3base-previa"><h4>Seleção conferida</h4><p>'.esc_html($previa['efeito']).'</p><button class="button button-primary" name="aplicar" value="1">Aplicar seleção conferida</button></div></form>';
        }
        echo '</section><section class="f3base-config-grupo"><h3>Coleta e mapeamento</h3><p>A consulta periódica recupera respostas dos formulários selecionados. A coleta e o recebimento imediato usam a mesma identidade de submissão.</p>';
        self::abrir_form('salvar');echo '<input type="hidden" name="revisoes['.esc_attr(F3Base_Linkedin::OPCAO).']" value="'.esc_attr(F3Base_Options::revisao(F3Base_Linkedin::OPCAO)).'">';
        foreach (['proprietario_confirmado'=>'Este site responde pela importação destes formulários','ativo'=>'Habilitar coleta periódica'] as $key=>$label) { echo '<p><label><input type="checkbox" name="config['.esc_attr($key).']" value="1" '.checked(!empty($cfg[$key]),true,false).'> '.esc_html($label).'</label></p>'; }
        if (!$externo) {
            foreach (['client_id'=>'Client ID do aplicativo','aplicativo_id'=>'ID numérica do aplicativo (opcional)'] as $key=>$label) { echo '<p><label>'.esc_html($label).'<br><input class="regular-text" name="config['.esc_attr($key).']" value="'.esc_attr($cfg[$key]).'"></label></p>'; }
            foreach ([F3Base_Linkedin_Api::TOKEN,F3Base_Linkedin_Api::SECRET] as $nome) { F3Base_Config_UI::segredo($nome,'segredos['.$nome.']','apagar['.$nome.']');echo '<input type="hidden" name="revisoes['.esc_attr($nome).']" value="'.esc_attr(F3Base_Options::revisao($nome)).'">'; }
        } else { echo '<p>As credenciais desta integração ficam no Plugin LinkedIn.</p><button type="button" class="button" id="f3base-linkedin-campanhas">Atualizar campanhas da conta</button> <span id="f3base-linkedin-campanhas-estado" role="status"></span>'; }
        echo '<details><summary>Campos e campanhas</summary><p>Associe cada pergunta a um campo do contato. O nome definido para uma campanha tem prioridade sobre o nome obtido no LinkedIn.</p><textarea id="f3base-linkedin-mapeamento" name="mapeamento" rows="8" class="large-text code">'.esc_textarea(wp_json_encode($cfg['mapeamento']?:new stdClass(),JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)).'</textarea></details><input type="hidden" name="preferencias_completas" value="1">';echo '<div class="f3base-acoes-secao">';submit_button('Salvar preferências da coleta','primary','submit',false);echo '<span role="status" data-f3base-situacao></span></div></form></section>';
        echo '<section class="f3base-config-grupo"><h3>Recebimento imediato</h3><p>Preferência atual: <strong>'.(!empty($cfg['webhook']['ativo'])?'habilitada':'desligada').'</strong>. Ativar cria ou adota assinaturas desta instalação no LinkedIn. Desativar encerra essas assinaturas e mantém a consulta periódica.</p><label for="f3base-linkedin-webhook-url">URL do webhook</label><input readonly id="f3base-linkedin-webhook-url" class="large-text" value="'.esc_attr(F3Base_Linkedin_Webhook::url()).'"><button type="button" class="button" data-copy="f3base-linkedin-webhook-url">Copiar URL</button><div class="f3base-config-acoes">';
        foreach (['ativar'=>'Ativar recebimento imediato','reconciliar'=>'Reconciliar assinaturas próprias','desativar'=>'Desativar recebimento imediato'] as $op=>$label) { self::abrir_form($op);echo '<input type="hidden" name="revisao" value="'.esc_attr(F3Base_Options::revisao(F3Base_Linkedin::OPCAO)).'"><input type="hidden" name="chave_operacao" value="'.esc_attr(wp_generate_uuid4()).'">';submit_button($label,'secondary');echo '</form>'; }
        echo '</div></section><section class="f3base-config-grupo"><h3>Verificação e operação</h3><p>Conferir acesso consulta a autorização e os formulários. Consultar novos contatos inicia a importação e pode acionar avisos e CRM conforme as regras do site.</p><div class="f3base-config-acoes">';
        foreach (['verificar'=>'Conferir acesso','consultar'=>'Consultar novos contatos agora'] as $op=>$label) { self::abrir_form($op);submit_button($label,'secondary');echo '</form>'; }
        echo '</div>';
        $state=F3Base_Linkedin_Integracoes::estado();echo '<h3>Estado</h3><table class="widefat striped"><thead><tr><th>Formulário</th><th>Versão</th><th>Página associada</th><th>Perguntas</th></tr></thead><tbody>';foreach(F3Base_Linkedin::formularios($cfg) as $id){$form=$state['formularios'][$id]??array();$def=$form?F3Base_Linkedin::definicao($form):null;echo '<tr><td>'.esc_html(($def['titulo']??'Ainda não conferido').' · '.$id).'</td><td>'.esc_html($def['versao']??'—').'</td><td>'.esc_html(is_string($form['associatedEntity']??null)?$form['associatedEntity']:'Não informada pela API').'</td><td>'.esc_html(implode(', ',array_map(static fn($q)=>$q['nome'].': '.$q['rotulo'],$def['campos']??array()))).'</td></tr>';}echo '</tbody></table><details><summary>Estado da coleta e do recebimento</summary><pre>'.esc_html(wp_json_encode($diag,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)).'</pre></details><p>Detalhes do contrato e permissões estão disponíveis em Informações técnicas.</p></section>';
    }
    public static function criar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}$id=sanitize_key($e['nova_id']??'');$all=F3Base_Linkedin_Integracoes::colecao();if(isset($all[$id])){return array('ok'=>false,'codigo'=>'integracao_ja_existe');}
        $all[$id]=array_replace(F3Base_Linkedin_Integracoes::padrao(),array('uuid'=>wp_generate_uuid4(),'rotulo'=>sanitize_text_field($e['rotulo']??$id)));
        $r=F3Base_Options::gravar(F3Base_Linkedin::OPCAO,array('integracoes'=>$all),F3Base_Options::ORIGEM_MANUAL,(string)($e['revisao']??''));return array('ok'=>!empty($r['persisted']),'codigo'=>$r['codigo']??'criacao_pendente','integracao_id'=>$id);
    }
    public static function iniciar(): void {add_action('admin_post_f3base_linkedin',array(__CLASS__,'post'));}
}
