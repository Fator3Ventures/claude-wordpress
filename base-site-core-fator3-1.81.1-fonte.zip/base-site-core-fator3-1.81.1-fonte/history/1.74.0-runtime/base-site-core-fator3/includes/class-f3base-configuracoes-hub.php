<?php
/** Entrada única das configurações; as telas de trabalho continuam em Contatos e Medição. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Configuracoes_Hub {
    public static function url(string $secao='inicio',string $integracao=''): string {
        $args=array('page'=>F3Base_Admin_Tela::SLUG,'secao'=>$secao);
        if($integracao!==''){$args['integracao']=$integracao;}
        return add_query_arg($args,admin_url('admin.php'));
    }
    public static function iniciar(): void { F3Base_Config_UI::iniciar();
        add_action('init',static function(){
            if(is_admin()&&($_GET['page']??'')==='f3base-integracoes'&&($_SERVER['REQUEST_METHOD']??'GET')==='GET'&&current_user_can('manage_options')){
                $args=array_intersect_key(wp_unslash($_GET),array_flip(array('integracao','pagina','estado')));
                wp_safe_redirect(add_query_arg($args,self::url('conexoes')));exit;
            }
        });
        add_action('admin_menu',static function(){remove_submenu_page('f3base-leads','f3base-integracoes');},1000);
    }
    public static function navegar(string $ativa): void {
        echo '<nav class="f3base-config-nav" aria-label="Configurações do site">';
        foreach(F3Base_Interface::ABAS as $key=>$label){$active=$ativa===$key||($key==='medicao'&&isset(F3Base_Interface::MEDICAO[$ativa]));
            echo '<a href="'.esc_url(self::url($key)).'" '.($active?'aria-current="page"':'').'>'.esc_html($label).'</a>';
        }echo '</nav>';
        if(isset(F3Base_Interface::MEDICAO[$ativa])){echo '<nav class="f3base-config-subnav" aria-label="Áreas da medição">';foreach(F3Base_Interface::MEDICAO as $key=>$label){echo '<a href="'.esc_url(self::url($key)).'" '.($ativa===$key?'aria-current="page"':'').'>'.esc_html($label).'</a>';}echo '</nav>';}
    }
    public static function inicio(): void {
        if (($_GET['guia']??'')==='configuracoes') { self::guia(); return; }
        $grupos=[
            'Atendimento e mensagens'=>[
                ['contato','','Contato e WhatsApp','Configure botões, telefone e confirmação de envio.','telefone formulário CTA'],
                ['conexoes','avisos','Avisos à equipe','Escolha canais, destinatários e formato das notificações.','slack mensagem e-mail resumo'],
                ['conexoes','f3base_pipedrive','Pipedrive','Conecte a conta e associe campos do site ao CRM.','crm pessoa lead negociação'],
                ['conexoes','f3base_email_site','E-mail do site','Configure a caixa de entrada e o servidor de envio.','email IMAP SMTP caixa senha remetente'],
                ['conexoes','f3base_email_novo_lead','E-mail ao novo contato','Edite remetente, mensagem e caixas de teste da resposta automática.','email novo lead smtp homologação'],
            ],
            'Captação de contatos'=>[
                ['conexoes','f3base_anuncios_google','Formulários do Google Ads','Escolha os formulários e obtenha a URL de recebimento.','importar webhook origens anúncios campanhas'],
                ['conexoes','f3base_anuncios_linkedin','Formulários do LinkedIn','Selecione a integração, os formulários e o modo de descoberta.','origens anúncios campanhas webhook assinatura'],
                ['conexoes','f3base_anuncios_meta','Formulários da Meta','Escolha páginas e formulários do Facebook e Instagram.','origens anúncios leads'],
                ['conexoes','qualidade','Qualidade e conversões','Relacione etapas comerciais e eventos autorizados.','meta dataset pipedrive funil pipeline regras'],
            ],
            'Medição e anúncios'=>[
                ['medicao-tags','','Tags e carregamento','Configure identificadores e quando carregar cada destino.','GTM Google Ads analytics LinkedIn'],
                ['medicao-meta','','Pixel e conversões Meta','Configure dataset e transporte dos eventos deste site.','facebook instagram capi token'],
                ['medicao-coleta','','Coleta e atribuição','Configure sessões, campanhas e identificação das visitas.','jornada robôs ia histórico'],
                ['medicao-ga4','','Acervo GA4','Defina a propriedade e os recortes do histórico analítico.','google analytics histórico métricas'],
                ['medicao-gsc','','Search Console','Defina a propriedade e a coleta do desempenho nas buscas.','google orgânico seo'],
                ['medicao-clarity','','Microsoft Clarity','Configure projeto, exportação e histórico.','mapa calor gravação token'],
                ['medicao-testes','','Testes e homologação','Separe visitas de teste e configure os destinos de homologação.','cookie CRM e-mail'],
            ],
            'Site e privacidade'=>[
                ['consentimento','','Consentimento','Edite o painel de escolhas e os textos exibidos ao visitante.','privacidade cookies banner'],
                ['privacidade','','Privacidade e retenção','Defina os prazos de guarda e as preferências de segurança.','exclusão cabeçalhos dados'],
                ['conteudo','','Conteúdo e navegação','Escolha a navegação e configure conteúdo para buscadores e IA.','menu markdown llms robots'],
                ['seo','','SEO','Edite informações institucionais e dados estruturados.','google organização schema'],
                ['conexoes','credenciais','Credenciais','Localize a tela responsável por cada token ou senha.','acesso segredo credencial'],
            ],
        ];
        echo '<section class="f3base-diretorio"><div class="f3base-diretorio-topo"><div><h2>Configurações por tarefa</h2><p>Escolha o que deseja ajustar neste site.</p></div><a href="'.esc_url(add_query_arg('guia','configuracoes',self::url())).'">Guia de configuração</a></div><form class="f3base-busca" role="search"><label for="f3base-busca-config">Buscar uma configuração</label><div><input type="search" id="f3base-busca-config" placeholder="WhatsApp, campanha, retenção…" aria-controls="f3base-diretorio-itens"><button type="button" class="button" id="f3base-busca-limpar" hidden>Limpar busca</button></div><p id="f3base-busca-status" role="status"></p></form><div id="f3base-diretorio-itens">';
        foreach ($grupos as $grupo=>$itens) {
            echo '<section class="f3base-diretorio-grupo" data-f3base-grupo><h3>'.esc_html($grupo).'</h3><div class="f3base-config-cards">';
            foreach ($itens as [$secao,$integracao,$titulo,$descricao,$termos]) {
                echo '<article class="f3base-config-card" data-f3base-busca="'.esc_attr("$grupo $titulo $descricao $termos").'"><h4><a href="'.esc_url(self::url($secao,$integracao)).'">'.esc_html($titulo).'</a></h4><p>'.esc_html($descricao).'</p></article>';
            }
            echo '</div></section>';
        }
        echo '</div><p>Para conferir filas e execuções, abra <a href="'.esc_url(add_query_arg('aba','operacao',self::url())).'">Operação</a>.</p></section>';
    }
    private static function guia(): void {
        echo '<section class="f3base-guia"><a href="'.esc_url(self::url()).'">Voltar às configurações</a>';
        $linha=1;
        do {
            $pagina=F3Base_Configuracao_Atual::documentacao(['arquivo'=>'docs/GUIA-PAINEL.md','linha'=>$linha,'limite'=>200]);
            if (empty($pagina['ok'])) { echo '<p role="alert">Guia indisponível.</p>';break; }
            foreach (explode("\n",$pagina['texto']) as $texto) {
                if ($texto==='') { continue; }
                if (str_starts_with($texto,'## ')) { echo '<h3>'.esc_html(substr($texto,3)).'</h3>'; }
                elseif (str_starts_with($texto,'# ')) { echo '<h2>'.esc_html(substr($texto,2)).'</h2>'; }
                else { echo '<p>'.esc_html($texto).'</p>'; }
            }
            $linha=$pagina['proxima_linha'];
        } while ($linha!==null);
        echo '</section>';
    }
    public static function campanhas(string $name,array $rows): void {
        echo '<table class="widefat" data-f3base-repetidor="campanhas"><thead><tr><th>Plataforma</th><th>ID da conta</th><th>ID da campanha</th><th>Nome para a equipe</th><th>Ação</th></tr></thead><tbody>';
        foreach(array_merge($rows,array(array())) as $i=>$r){echo '<tr>';foreach(array('plataforma','conta','campanha','nome') as $k){$n='f3base['.$name.']['.$i.']['.$k.']';echo '<td>';if($k==='plataforma'){echo '<select aria-label="Plataforma" name="'.esc_attr($n).'">';foreach(array(''=>'Selecione','meta_ads'=>'Meta Ads','google_ads'=>'Google Ads','linkedin_ads'=>'LinkedIn Ads','openai_ads'=>'OpenAI Ads') as $v=>$label){echo '<option value="'.esc_attr($v).'" '.selected($r[$k]??'',$v,false).'>'.esc_html($label).'</option>';}echo '</select>';}else{echo '<input aria-label="'.esc_attr($k).'" name="'.esc_attr($n).'" value="'.esc_attr($r[$k]??'').'">';}echo '</td>';}echo '<td><button type="button" class="button" data-remover-linha>Remover</button></td></tr>';}
        echo '</tbody></table><button type="button" class="button" data-adicionar-linha="campanhas">Adicionar campanha</button>';
    }
    public static function grupos(string $n): array {
        if($n==='f3base_pipedrive'){return array(
            'Conexão e identificação'=>array('ativo','dominio','homologacao','identidade_telefone','pais_telefone','linkedin_modo','sem_nome','modelo_nome'),
            'Responsabilidade e apresentação'=>array('responsavel','rotulo','rotulo_pessoa','unidade','modelo_titulo','site_alternativa'),
            'Campos e respostas'=>array('mapa_campos','mapa_pessoa','mapa_respostas','mapa_servicos','mapa_parceiros','mapa_canais','mapa_pontos','parceiros_plataforma','campos_fixos','mapa_servicos_formularios','mapa_servicos_campanhas'),
            'Atividades'=>array('atividade','atividade_canais','atividade_janela','whatsapp_texto'),
            'Limites operacionais'=>array('orcamento_verificacao_diario','orcamento_qualidade_diario','orcamento_local_diario','retencao_entregas_meses'));
        }
        if($n==='f3base_email_site'){return array('Conta de envio'=>array('endereco','usuario','imap_host','imap_porta','smtp_host','smtp_porta','smtp_seguranca'),'Importação'=>array('ativo','pasta_importados','dominios_ignorados','authserv_ids','termos_suspeitos','max_links'),'Envio'=>array('envio_ativo','nome_exibicao','assinatura','cco','pasta_enviados','cota_destinatarios_hora','alocacao_confirmada'),'Homologação'=>array('homologacao','homologacao_emails'));}
        if($n==='f3base_email_novo_lead'){return array('Envio'=>array('ativo','cota_destinatarios_hora','alocacao_confirmada'),'Conta de envio'=>array('smtp_host','smtp_porta','smtp_seguranca','smtp_usuario','remetente','nome_exibicao'),'Conteúdo'=>array('marca','assunto','saudacao','introducao','recebimento','origem_site','origem_meta','origem_google','origem_linkedin','texto_unidade','textos_servicos','contato','whatsapp_numero','whatsapp_texto','whatsapp_rotulo','convite_resposta','assinatura','assunto_atividade'),'Homologação'=>array('homologacao_emails'));}
        return array('Conexão'=>array('ativo','proprietario_confirmado','conta_id','modo'),'O que importar'=>array('paginas','formularios_modo','formularios'),'Campos e campanhas'=>array('campanhas','mapeamento'));
    }
    public static function grupo_ajuda(string $g): string {
        return [
            'Conexão e identificação'=>'Confira a conta e a credencial antes de habilitar a entrega de contatos.',
            'Conexão e autorização'=>'Confira os ativos desta conta. Preencha a credencial somente ao cadastrar ou substituir o acesso.',
            'Responsabilidade e apresentação'=>'Escolha o responsável e os rótulos usados nos novos contatos do CRM.',
            'Campos e respostas'=>'Relacione as perguntas do formulário aos campos da conta. Revise o mapa ao alterar as perguntas.',
            'Atividades'=>'Defina quando criar a primeira tarefa de acompanhamento e quem a executa.',
            'Limites operacionais'=>'Defina as cotas deste site. Quando a cota termina, a fila aguarda a próxima janela.',
            'Conta de envio'=>'Preencha endereço, usuário e servidor indicados pelo provedor da caixa. Salve a credencial nesta área.',
            'Importação'=>'Escolha a pasta e as regras para tratar mensagens recebidas nesta caixa.',
            'Envio'=>'Confira remetente, capacidade de envio e autorização antes de habilitar a entrega.',
            'Conteúdo'=>'Edite assunto, apresentação e assinatura. Confira a prévia da mensagem antes de enviar um teste.',
            'Homologação'=>'Use caixas da equipe autorizadas a receber mensagens de teste.',
            'Conexão'=>'Confirme a conta de anúncios e a responsabilidade deste site pelos formulários.',
            'O que importar'=>'Selecione os ativos do site. Ao usar páginas, salve a seleção antes de consultar seus formulários.',
            'Campos e campanhas'=>'Associe os dados do anúncio aos campos do contato e indique como identificar as campanhas.',
        ][$g]??'';
    }
}
