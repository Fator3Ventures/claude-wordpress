<?php
/** Formulários de retenção, destinatários e homologação no painel administrativo. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Config_Central {
    private const AREAS = [
        'privacidade' => ['Retenção de dados', 'Escolha por quanto tempo guardar cada histórico. A rotina de limpeza usa os novos prazos na próxima execução.', 'Salvar retenção'],
        'avisos' => ['Destinatários dos avisos', 'Informe as caixas da equipe que acompanha os contatos. A lista específica de um formulário prevalece sobre esta lista geral.', 'Salvar destinatários'],
        'medicao-testes' => ['Destinos de homologação', 'Escolha onde os contatos e e-mails de teste podem chegar. Use caixas acompanhadas pela equipe.', 'Salvar homologação'],
    ];

    public static function render(string $area): void {
        if (!isset(self::AREAS[$area]) || !current_user_can('manage_options')) { return; }
        [$titulo, $texto, $botao] = self::AREAS[$area];
        $grupos = F3Base_Config_UI::centrais($area);
        $fotos = F3Base_Options::fotografias(array_keys($grupos));
        $flash = 'f3base_central_'.get_current_user_id().'_'.$area;
        if ($resultado = get_transient($flash)) {
            echo '<p role="status" class="notice notice-inline '.(!empty($resultado['ok'])?'notice-success':'notice-error').'"><span>'.esc_html($resultado['mensagem']).'</span></p>';
            delete_transient($flash);
        }
        echo '<section class="f3base-config-grupo f3base-central"><h2>'.esc_html($titulo).'</h2><p>'.esc_html($texto).'</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-f3base-edicao><input type="hidden" name="action" value="f3base_config_central"><input type="hidden" name="area" value="'.esc_attr($area).'">';
        wp_nonce_field('f3base-config-central');
        foreach ($grupos as $nome=>$campos) {
            $foto=$fotos[$nome]??null;
            if (!$foto || $foto['erro']) { echo '<p role="alert">A leitura dos valores falhou. Reabra esta área antes de salvar.</p></form></section>'; return; }
            $def=F3Base_Options::declaracao($nome);
            echo '<fieldset class="f3base-central-grupo"><legend>'.esc_html($def['rotulo']??$nome).'</legend><input type="hidden" name="revisoes['.esc_attr($nome).']" value="'.esc_attr($foto['revisao']).'">';
            foreach ($campos as $chave=>$rotulo) {
                $valor=$chave==='_valor'?$foto['valor']:($foto['valor'][$chave]??'');
                self::campo($nome,$chave,$rotulo,$valor,$def);
            }
            echo '</fieldset>';
        }
        echo '<div class="f3base-acoes-secao">';submit_button($botao,'primary','submit',false,['id'=>'f3base-central-salvar-'.$area]);echo '<span class="description">Aplica as mudanças deste formulário.</span><span data-f3base-situacao role="status"></span></div></form>';
        if ($area==='medicao-testes') { echo '<p><a href="'.esc_url(F3Base_Configuracoes_Hub::url('conexoes','f3base_email_novo_lead')).'">Abrir prévia e envio de e-mail de teste</a></p>'; }
        echo '</section>';
    }
    private static function campo(string $nome,string $chave,string $rotulo,$valor,array $def): void {
        $id='central-'.$nome.'-'.$chave; $campo='valores['.$nome.']['.$chave.']';
        $descricao=$def['subcampos'][$chave]['descricao']??($chave==='_valor'?($def['descricao']??''):'');
        if ($chave==='email_leads') { $descricao='Um e-mail por linha, até cinco destinatários. Deixar a lista vazia retira os destinatários gerais.'; }
        if ($chave==='homologacao_emails') { $descricao='Informe uma caixa autorizada para teste por linha.'; }
        $ajuda=$descricao!==''?' aria-describedby="'.esc_attr($id.'-ajuda').'"':'';
        echo '<div class="f3base-central-campo"><label for="'.esc_attr($id).'">'.esc_html($rotulo).'</label>';
        if (is_bool($valor)) {
            echo '<input type="hidden" name="'.esc_attr($campo).'" value="0"><input type="checkbox" id="'.esc_attr($id).'" name="'.esc_attr($campo).'" value="1" '.checked($valor,true,false).$ajuda.'>';
        } elseif (is_array($valor) || $chave==='email_leads') {
            echo '<textarea class="large-text" rows="3" id="'.esc_attr($id).'" name="'.esc_attr($campo).'"'.$ajuda.'>'.esc_textarea(implode("\n",(array)$valor)).'</textarea>';
        } else {
            $schema=F3Base_Config_Contrato::schema_valor($def);
            $campoSchema=$chave==='_valor'?$schema:($schema['properties'][$chave]??[]);
            echo '<input class="small-text" type="number" step="1" required id="'.esc_attr($id).'" name="'.esc_attr($campo).'" value="'.esc_attr((string)$valor).'"'.(isset($campoSchema['minimum'])?' min="'.(int)$campoSchema['minimum'].'"':'').(isset($campoSchema['maximum'])?' max="'.(int)$campoSchema['maximum'].'"':'').$ajuda.'>';
        }
        if ($descricao!=='') { echo '<p id="'.esc_attr($id.'-ajuda').'" class="description">'.esc_html($descricao).'</p>'; }
        echo '</div>';
    }
    public static function processar(array $entrada): array {
        if (!current_user_can('manage_options')) { return self::erro(403,'Sem permissão para alterar esta área.'); }
        $area=$entrada['area']??null;
        if (!is_string($area) || !isset(self::AREAS[$area])) { return self::erro(400,'Área inválida. Reabra as configurações.'); }
        $grupos=F3Base_Config_UI::centrais($area); $valores=$entrada['valores']??null; $revisoes=$entrada['revisoes']??null;
        if (!is_array($valores) || !is_array($revisoes) || array_diff_key($valores,$grupos) || array_diff_key($grupos,$valores)) { return self::erro(400,'Formulário incompleto ou com campos de outra área. Reabra a tela.'); }
        $fotos=F3Base_Options::fotografias(array_keys($grupos)); $alteradas=[];
        foreach ($grupos as $nome=>$campos) {
            $foto=$fotos[$nome]??null;
            if (!$foto || $foto['erro']) { return self::erro(503,'Não foi possível ler a configuração atual.'); }
            if (!is_string($revisoes[$nome]??null) || !hash_equals($foto['revisao'],$revisoes[$nome])) { return self::erro(409,'Outro processo alterou a configuração. Reabra a área e confira os valores atuais.'); }
            $dados=$valores[$nome];
            if (!is_array($dados) || array_diff_key($campos,$dados) || array_diff_key($dados,$campos)) { return self::erro(400,'Um campo está ausente ou pertence a outra área. Reabra a tela.'); }
            $proposta=$foto['valor'];
            foreach ($campos as $chave=>$rotulo) {
                $raw=$dados[$chave]; $anterior=$chave==='_valor'?$proposta:($proposta[$chave]??'');
                if (!is_string($raw)) { return self::erro(400,'Valor inválido para '.$rotulo.'.'); }
                if (is_bool($anterior)) {
                    if (!in_array($raw,['0','1'],true)) { return self::erro(400,'Escolha uma opção válida para '.$rotulo.'.'); }
                    $valor=$raw==='1';
                } elseif (is_array($anterior) || $chave==='email_leads') {
                    $valor=array_values(array_filter(array_map('trim',preg_split('/[\r\n,]+/',$raw)),static fn($item)=>$item!==''));
                } else {
                    $valor=filter_var($raw,FILTER_VALIDATE_INT);
                    if ($valor===false) { return self::erro(400,'Informe um número inteiro para '.$rotulo.'.'); }
                }
                if ($chave==='_valor') { $proposta=$valor; } else { $proposta[$chave]=$valor; }
            }
            if (F3Base_Options::equivalente($proposta,$foto['valor'])) { continue; }
            $erro=F3Base_Options::recusar($nome,$proposta,F3Base_Options::declaracao($nome));
            if ($erro!=='') { return self::erro(400,$erro); }
            $alteradas[$nome]=$proposta;
        }
        $salvas=[];
        foreach ($alteradas as $nome=>$valor) {
            $r=F3Base_Options::pelo_canal('admin',static fn()=>F3Base_Options::gravar($nome,$valor,F3Base_Options::ORIGEM_MANUAL,$revisoes[$nome]));
            if (empty($r['persisted'])) { return self::erro(409,'Gravação interrompida. Grupos confirmados: '.count($salvas).'. Reabra a área e confira os valores.')+['salvas'=>$salvas]; }
            $salvas[]=$nome;
        }
        return ['ok'=>true,'salvas'=>$salvas,'mensagem'=>$salvas?'Alterações salvas e conferidas.':'Os valores já estavam salvos.'];
    }
    private static function erro(int $http,string $mensagem): array { return ['ok'=>false,'http'=>$http,'mensagem'=>$mensagem]; }
    public static function salvar(): void {
        if (!current_user_can('manage_options')) { wp_die('Sem permissão.',403); }
        check_admin_referer('f3base-config-central');
        $entrada=wp_unslash($_POST);$r=self::processar($entrada);
        if (!$r['ok']) { wp_die(esc_html($r['mensagem']),'Configuração não concluída',['response'=>$r['http'],'back_link'=>true]); }
        $area=$entrada['area'];set_transient('f3base_central_'.get_current_user_id().'_'.$area,$r,300);
        wp_safe_redirect($area==='avisos'?F3Base_Configuracoes_Hub::url('conexoes','avisos'):F3Base_Configuracoes_Hub::url($area));exit;
    }
}
