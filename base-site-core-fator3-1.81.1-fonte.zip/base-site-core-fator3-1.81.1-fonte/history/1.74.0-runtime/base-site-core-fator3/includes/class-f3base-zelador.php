<?php
/** Routine scheduling belongs to the server cron; visitors only dispatch urgent work. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Zelador {
    const ESTADO='f3base_cron_servidor';
    private static bool $executando=false;
    private static bool $desativado=false;
    private static bool $executado=false;
    private static ?array $tarefas=null;
    public static function iniciar(): void {
        add_filter('pre_get_ready_cron_jobs',array(__CLASS__,'filtrar'),20);
        add_action('wp_loaded',array(__CLASS__,'passagem'),PHP_INT_MAX-5);
        add_action('f3base_zelador_tick',array(__CLASS__,'executar'));
        add_action('updated_option',array(__CLASS__,'opcao'),200,3);
        add_action('added_option',array(__CLASS__,'adicionada'),200,2);
    }
    public static function cli_recente(): bool {$s=(array)get_option(self::ESTADO,array());return (int)($s['ultima_cli']??0)>=time()-3600;}
    public static function protegido(): bool {$s=(array)get_option(self::ESTADO,array());return max((int)($s['ultima_cli']??0),(int)($s['iniciado_em']??0))>=time()-3600;}
    public static function desativar(): void {self::$desativado=true;foreach(array('f3base_zelador_tick','f3base_esquema_reparar','f3base_operacao_urgente') as $hook){wp_unschedule_hook($hook);}}
    public static function tarefas(): array {if(self::$tarefas===null){self::$tarefas=require __DIR__.'/cron-tarefas.php';}return self::$tarefas;}
    public static function rotina(string $hook): bool {
        $map=self::tarefas();if(isset($map[$hook])){return $map[$hook]['classe']==='rotina';}
        if($hook==='f3base_operacao_retomar'){return true;}
        if(in_array($hook,array('wp_version_check','wp_update_plugins','wp_update_themes','wp_maybe_auto_update','wp_scheduled_delete','delete_expired_transients','wp_scheduled_auto_draft_delete','wp_site_health_scheduled_check','recovery_mode_clean_expired_keys'),true)){return true;}
        return in_array($hook,(array)apply_filters('f3base_cron_rotina',array()),true);
    }
    public static function filtrar($pre) {
        if((defined('WP_CLI')&&WP_CLI)||!self::protegido()){return $pre;}
        $jobs=is_array($pre)?$pre:_get_cron_array();$now=microtime(true);
        foreach($jobs as $at=>$hooks){if((float)$at>$now){unset($jobs[$at]);continue;}foreach($hooks as $hook=>$events){if(self::rotina($hook)){unset($jobs[$at][$hook]);}}if(!$jobs[$at]){unset($jobs[$at]);}}
        return $jobs;
    }
    public static function passagem(): void {
        if((wp_doing_cron()||current_user_can('manage_options'))&&!(defined('WP_CLI')&&WP_CLI)&&get_option('f3base_atualizacao_urgente_concluida','')!==F3BASE_PLUGIN_VERSAO){self::atualizacao_urgente();}
        if(wp_doing_cron()){F3Base_Operacao::registrar_callbacks();if(!self::protegido()){self::executar();}}
        if(defined('WP_CLI')&&WP_CLI&&class_exists('WP_CLI',false)){WP_CLI::add_hook('before_invoke:cron event run',static function($name){F3Base_Zelador::executar();F3Base_Zelador::atualizacao_urgente();
            if(method_exists('WP_CLI','get_runner')){$runner=WP_CLI::get_runner();$args=$runner->arguments??array();$assoc=$runner->assoc_args??array();
                if($args===array('cron','event','run')&&!empty($assoc['due-now'])&&empty($assoc['exclude'])){F3Base_Operacao::executar_pendentes(array('simular'=>false,'compacto'=>true));}}
            return $name;});}
    }
    /** Upgrade is exceptional; stable public requests only read an autoload marker. */
    public static function atualizacao_urgente(): void {
        if(get_option('f3base_atualizacao_urgente_concluida','')===F3BASE_PLUGIN_VERSAO){return;}
        F3Base_Site_Core::iniciar_completo();if(!empty(F3Base_Recuperacao::ler()['pausado'])){return;}
        F3Base_Operacao::executar_uma('migracao','atualizacao',false);
        $s=F3Base_Instalacao::resumo();
        if(!empty($s['ciclo_atual'])&&!empty($s['concluido_em'])&&empty($s['finalizacao_em'])){
            F3Base_Execucoes::com_prioridade(static fn()=>F3Base_Atualizacao::migrar());$s=F3Base_Instalacao::resumo();
        }
        if(!empty($s['finalizacao_em'])){F3Base_Operacao::executar_uma('pos_atualizacao','atualizacao',false);update_option('f3base_atualizacao_urgente_concluida',F3BASE_PLUGIN_VERSAO,true);}
    }
    public static function adicionada($name,$value): void {self::opcao($name,null,$value);}
    public static function opcao($name,$old,$new): void {
        if(self::$desativado||self::$executando||$old===$new||F3Base_Esquema::manutencao()){return;}
        $options=require __DIR__.'/cron-opcoes.php';
        if(in_array($name,$options,true)&&did_action('init')){self::executar(true);}
    }
    /** The closed declaration is independent of class loading and preserves callback priority. */
    public static function conferir(): void {
        global $wp_filter;$rows=require __DIR__.'/zelador-condicoes.php';
        // Registration stays backward compatible; the keeper is the sole dispatcher of Core conditions.
        foreach($wp_filter['f3base_zelador']->callbacks??array() as $priority=>$entries){foreach($entries as $entry){
            $cb=$entry['function'];try{$ref=is_array($cb)?new ReflectionMethod($cb[0],$cb[1]):new ReflectionFunction($cb);$file=$ref->getFileName();if($file&&str_starts_with($file,F3BASE_PLUGIN_DIR)){remove_action('f3base_zelador',$cb,$priority);}}catch(ReflectionException $e){}
        }}
        foreach($rows as $row){[$class,$method]=explode('::',$row['condicao'],2);$target=$row['instancia']?new $class():$class;call_user_func(array($target,$method));}
    }
    public static function executar($forcar=false): void {
        if(self::$desativado||self::$executando||(self::$executado&&!$forcar)){return;}
        self::$executando=true;self::$executado=true;
        try{
            if(!F3Base_Esquema::pronta('F3Base_Execucoes')){F3Base_Atualizacao::migrar();}
            $s=(array)get_option(self::ESTADO,array());if(empty($s['iniciado_em'])){$s['iniciado_em']=time();}
            if(defined('WP_CLI')&&WP_CLI){
                F3Base_Execucoes::iniciar('zelador_cli');
                if(F3Base_Execucoes::atual()){$s['ultima_cli']=time();$s['run_id']=F3Base_Execucoes::atual()['run_id'];unset($s['reserva_aviso']);}
            }
            update_option(self::ESTADO,$s,true);
            if(!self::protegido()&&empty($s['reserva_aviso'])){
                $s['reserva_aviso']=array('em'=>time(),'estado'=>'reservado');update_option(self::ESTADO,$s,true);
                $s['reserva_aviso']['resultado']=F3Base_Alertas_Operacionais::enviar('Cron do servidor sem passagem recente','Sem passagem CLI registrada há mais de uma hora. Rotinas voltaram ao WP-Cron por visita. Confira o cron do servidor.');update_option(self::ESTADO,$s,true);
            }
            if(!wp_next_scheduled('f3base_zelador_tick')){wp_schedule_event(time()+900,'hourly','f3base_zelador_tick');}
            // A etapa perfil_publico da instalação entra aqui em manutenção, após criar as filas.
            // Uma passagem comum de cron pode ocorrer antes dessa etapa na reinstalação.
            if (!F3Base_Esquema::manutencao() && F3Base_Instalacao::origem() !== 'atual') {
                F3Base_Atualizacao::agendar();
                return;
            }
            if(!F3Base_Recuperacao::entrar()){return;}
            try{self::conferir();do_action('f3base_zelador');F3Base_Llms_Cobertura::agendar();}finally{F3Base_Recuperacao::sair();}
        }finally{self::$executando=false;}
    }
}
