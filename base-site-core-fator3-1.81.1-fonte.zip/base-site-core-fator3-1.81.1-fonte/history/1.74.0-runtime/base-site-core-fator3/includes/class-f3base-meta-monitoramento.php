<?php
/** Core 340/341: granted local monitoring, independent of the performance reader. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Monitoramento {
    const OPTION='f3base_meta_monitoramento';const CONTRACT='meta-ads-monitoring/1.0.0';const HOOK='f3base_meta_monitorar';private static $client=null;
    public static function padroes(): array {return ['ativo'=>false,'conexao'=>'','conta_id'=>'','revisao'=>0,'reports'=>['ads_activity','dataset_quality'],'dataset_ids'=>[],'avisar'=>false,'canal'=>'slack','operador'=>0];}
    public static function props(): array {return ['ativo'=>['type'=>'boolean'],'conexao'=>['type'=>'string','pattern'=>'^([A-Za-z0-9][A-Za-z0-9_.-]{0,63})?$'],'conta_id'=>['type'=>'string','pattern'=>'^([0-9]{1,40})?$'],'revisao'=>['type'=>'integer','minimum'=>0,'maximum'=>2147483647],'reports'=>['type'=>'array','minItems'=>1,'uniqueItems'=>true,'items'=>['type'=>'string','enum'=>['ads_activity','dataset_quality']]],'dataset_ids'=>['type'=>'array','maxItems'=>12,'uniqueItems'=>true,'items'=>['type'=>'string','pattern'=>'^[0-9]{1,40}$']],'avisar'=>['type'=>'boolean'],'canal'=>['type'=>'string','enum'=>['slack','email']],'operador'=>['type'=>'integer','minimum'=>0,'description'=>'Gerado pelo Core ao salvar; preservar.']];}
    public static function opcoes(): array {return array_replace(self::padroes(),(array)F3Base_Options::ler(self::OPTION));}
    public static function validar($v): string {
        $e=rest_validate_value_from_schema($v,['type'=>'object','properties'=>self::props(),'required'=>array_keys(self::props()),'additionalProperties'=>false]);if(is_wp_error($e))return $e->get_error_message();$old=self::opcoes();
        if($v['ativo']&&($v['conexao']===''||$v['conta_id']===''||$v['revisao']<1))return 'Informe conexão, conta e revisão positiva.';
        if($v['operador']!==$old['operador'])return 'Operador é controlado pelo Core.';
        if($v!==$old&&$v['revisao']<=$old['revisao'])return 'Aumente a revisão; restaurar valores antigos não restaura concessões.';
        return '';
    }
    public static function preparar(array $v): array {$v['operador']=get_current_user_id();return $v;}
    public static function configuracao(): array {$c=self::opcoes();$s=F3Base_Recuperacao::ler();return ['ready'=>$c['ativo']&&$c['conexao']!==''&&$c['conta_id']!==''&&!empty($s['ok'])&&empty($s['pausado']),'connection_id'=>$c['conexao'],'account_id'=>$c['conta_id'],'revision'=>hash('sha256',wp_json_encode([$c,$s['geracao']??0])),'reports'=>$c['reports'],'dataset_ids'=>$c['dataset_ids']];}
    public static function descobrir($sdk,string $contract): void {if($contract!==self::CONTRACT||self::$client)return;try{$c=$sdk::register_consumer('base-site-core-fator3',F3BASE_PLUGIN_VERSAO,self::CONTRACT,[__CLASS__,'configuracao'],'Core — alterações e qualidade de eventos');if(is_object($c)&&is_callable([$c,'query'])&&is_callable([$c,'status']))self::$client=$c;}catch(Throwable $e){self::$client=null;}}
    private static function chamar(string $op,array $q): array {if(!self::$client)return ['success'=>false,'code'=>'sdk_ausente'];$deny=static fn()=>new WP_Error('monitoramento_local','Leitura local.');add_filter('pre_http_request',$deny,PHP_INT_MAX);try{$r=self::$client->$op($q);return is_array($r)?$r:['success'=>false,'code'=>'resposta_invalida'];}catch(Throwable $e){return ['success'=>false,'code'=>'sdk_indisponivel'];}finally{remove_filter('pre_http_request',$deny,PHP_INT_MAX);}}
    public static function status(array $e=[]): array {if(!current_user_can('manage_options'))return ['ok'=>false,'codigo'=>'sem_permissao'];$cfg=self::configuracao();$r=self::chamar('status',array_intersect_key($cfg,array_flip(['connection_id','account_id'])));return ['ok'=>true,'contrato'=>self::CONTRACT,'configuracao'=>$cfg,'registrado'=>self::$client!==null,'pronto'=>!empty($r['success']),'codigo'=>$r['code']??null,'concessao'=>$r['data']??null,'http_fornecedor'=>false];}
    public static function schema(): array {return ['de'=>['type'=>'string','format'=>'date'],'ate'=>['type'=>'string','format'=>'date'],'report'=>['type'=>'string','enum'=>['ads_activity','dataset_quality']],'dataset_id'=>['type'=>'string','pattern'=>'^[0-9]{1,40}$'],'limite'=>['type'=>'integer','minimum'=>1,'maximum'=>100,'default'=>100],'cursor'=>['type'=>'string','maxLength'=>100000],'entidade'=>['type'=>'string','maxLength'=>250],'campo'=>['type'=>'string','maxLength'=>250]];}
    public static function ler(array $e): array {
        if(!current_user_can('manage_options'))return ['ok'=>false,'codigo'=>'sem_permissao'];return self::pagina($e,current_user_can('f3base_ler_leads'));
    }
    private static function sem_autor($v) {if(!is_array($v))return null;foreach($v as $k=>&$x){if(preg_match('/actor|author|user|email|creator/i',(string)$k))unset($v[$k]);elseif(is_array($x))$x=self::sem_autor($x);}unset($x);return $v;}
    private static function pagina(array $e,bool $personal=false): array {
        $error=rest_validate_value_from_schema($e,['type'=>'object','properties'=>self::schema(),'required'=>['de','ate','report'],'additionalProperties'=>false]);
        if(is_wp_error($error)||!F3Base_Gsc::data_valida($e['de']??'')||!F3Base_Gsc::data_valida($e['ate']??'')||$e['de']>$e['ate']||(new DateTimeImmutable($e['de']))->diff(new DateTimeImmutable($e['ate']))->days>365)return ['ok'=>false,'codigo'=>'consulta_invalida','linhas'=>[]];
        $cfg=self::configuracao();if(!$cfg['ready'])return ['ok'=>false,'codigo'=>'configuracao_pendente','linhas'=>[]];
        $q=['connection_id'=>$cfg['connection_id'],'account_id'=>$cfg['account_id'],'report'=>$e['report'],'date_from'=>$e['de'],'date_to'=>$e['ate'],'limit'=>$e['limite']??100];if(isset($e['dataset_id']))$q['dataset_id']=$e['dataset_id'];
        $binding=hash('sha256',wp_json_encode([$q,$cfg,$e['entidade']??null,$e['campo']??null,$personal]));
        if(!empty($e['cursor'])){$parts=explode('.',$e['cursor']);if(count($parts)!==2||!hash_equals(hash_hmac('sha256',$parts[0],wp_salt('auth')),$parts[1]))return ['ok'=>false,'codigo'=>'cursor_invalido','linhas'=>[]];$c=json_decode(base64_decode($parts[0],true)?:'',true);if(($c['binding']??'')!==$binding||($c['expires']??0)<time())return ['ok'=>false,'codigo'=>'cursor_alterado_ou_expirado','linhas'=>[]];$q['cursor']=$c['provider'];}
        $r=self::chamar('query',$q);if(empty($r['success']))return ['ok'=>false,'codigo'=>$r['code']??'leitura_falhou','linhas'=>[]];$d=$r['data']??[];
        if(($d['contract']??'')!==self::CONTRACT||!is_array($d['rows']??null)||!array_key_exists('next_cursor',$d)||self::configuracao()!==$cfg)return ['ok'=>false,'codigo'=>'resposta_ou_configuracao_invalida','linhas'=>[]];
        $out=[];foreach($d['rows'] as $v){$row=$v['row']??null;if(!is_array($row)||($v['connection_id']??'')!==$cfg['connection_id']||($v['report']??'')!==$e['report']||($v['data_day']??'')<$e['de']||($v['data_day']??'')>$e['ate']||($v['account_id']??'')!==($e['report']==='dataset_quality'?($e['dataset_id']??''):$cfg['account_id']))return ['ok'=>false,'codigo'=>'linha_invalida','linhas'=>[]];
            if($e['report']==='dataset_quality'&&($row['ads_account_id']??'')!==$cfg['account_id'])return ['ok'=>false,'codigo'=>'conta_divergente','linhas'=>[]];
            if(!empty($e['entidade'])&&($row['object_id']??'')!==$e['entidade'])continue;
            if(!empty($e['campo'])&&!array_key_exists($e['campo'],(array)($row['extra_data']??[]))&&($row['event_type']??'')!==$e['campo'])continue;
            if(!$personal&&$e['report']==='ads_activity'){unset($row['actor_id'],$row['actor_name']);foreach(['extra_data','old_value','new_value'] as $k)if(is_array($row[$k]??null))$row[$k]=self::sem_autor($row[$k]);elseif($k==='extra_data')$row[$k]=null;}
            if(!$personal&&$e['report']==='ads_activity'){$v=self::sem_autor($v);unset($v['last_successful_observation'],$v['last_available_fields']);}$v['row']=$row;$out[]=$v;
        }
        $next=null;if($d['next_cursor']){$b=base64_encode(wp_json_encode(['binding'=>$binding,'provider'=>$d['next_cursor'],'expires'=>time()+86400]));$next=$b.'.'.hash_hmac('sha256',$b,wp_salt('auth'));}
        return ['ok'=>true,'contrato'=>self::CONTRACT,'linhas'=>$out,'proximo_cursor'=>$next,'cobertura'=>$d['coverage']??null,'geracao'=>$d['generation']??null,'revisao_concessao'=>$d['grant_revision']??null,'http_fornecedor'=>false,'recebidos_unicos'=>null,'nota'=>'Browser e servidor podem se sobrepor. EMQ é observação datada, não nota histórica do dia de contagens.'];
    }
    public static function qualidade(array $e=[]): array {
        if(!current_user_can('manage_options'))return ['ok'=>false,'codigo'=>'sem_permissao'];try{$j=F3Base_Relatorios::janela($e);}catch(Throwable $x){return ['ok'=>false,'codigo'=>'periodo_invalido'];}
        $out=[];foreach(self::opcoes()['dataset_ids'] as $id){$q=['de'=>$j['de'],'ate'=>$j['ate'],'report'=>'dataset_quality','dataset_id'=>$id];$out[$id]=self::pagina($q);$today=gmdate('Y-m-d');$out[$id]['emq_atual']=self::pagina(['de'=>gmdate('Y-m-d',time()-86400),'ate'=>gmdate('Y-m-d',time()+86400),'report'=>'dataset_quality','dataset_id'=>$id]);$out[$id]['emq_atual']['linhas']=array_values(array_filter($out[$id]['emq_atual']['linhas']??[],static fn($v)=>($v['row']['record_kind']??'')==='emq_snapshot'));$out[$id]['continuar_em']='f3base/meta-monitoramento-ler';}
        return ['ok'=>true,'datasets'=>$out,'status'=>self::status(),'http_fornecedor'=>false,'emq_calendario'=>'Cada snapshot conserva emq_observed_at e data do produtor.'];
    }
    public static function alteracoes(array $e): array {
        if(!current_user_can('manage_options'))return ['ok'=>false,'codigo'=>'sem_permissao'];$cfg=($e['plataforma']??'')==='google_ads'?F3Base_Google_Acervo::opcoes():self::opcoes();if(($e['conta_id']??$cfg['conta_id'])!==$cfg['conta_id'])return ['ok'=>false,'codigo'=>'conta_nao_selecionada'];
        if(($e['plataforma']??'')==='meta_ads'){$q=array_intersect_key($e,self::schema());$q['report']='ads_activity';return self::ler($q);}
        if(($e['plataforma']??'')!=='google_ads')return ['ok'=>false,'codigo'=>'plataforma_invalida'];
        $q=array_intersect_key($e,F3Base_Google_Acervo::schema());$q['dataset']='changes';$r=F3Base_Google_Acervo::consultar($q);$r['linhas']=array_values(array_filter($r['linhas']??[],static function($v)use($e){if(!empty($e['entidade'])&&($v['resource']??'')!==$e['entidade'])return false;if(!empty($e['campo'])){$fields=$v['changed_fields']['paths']??$v['changed_fields']??[];if(is_string($fields))$fields=explode(',',$fields);if(!in_array($e['campo'],(array)$fields,true))return false;}return true;}));return $r;
    }
    public static function avaliar(array $incident): array {
        $c=self::configuracao();if(($incident['code']??'')!=='dataset_optimized_event_zero'||($incident['connection_id']??'')!==$c['connection_id']||($incident['ads_account_id']??'')!==$c['account_id']||!in_array($incident['dataset_id']??'',$c['dataset_ids'],true)||!preg_match('/^[a-f0-9]{64}$/D',$incident['incident_key']??'')||!F3Base_Gsc::data_valida($incident['date']??''))return ['avisar'=>false,'codigo'=>'incidente_fora_selecao'];
        $query=['de'=>$incident['date'],'ate'=>$incident['date'],'report'=>'dataset_quality','dataset_id'=>$incident['dataset_id']];$emitted=false;$spend=false;$zero=false;$cursor=null;$pages=0;
        do{$r=self::pagina($query+($cursor?['cursor'=>$cursor]:[]));if(empty($r['ok']))return ['avisar'=>false,'codigo'=>$r['codigo']??'leitura_falhou'];
            foreach($r['linhas'] as $v){$row=$v['row'];if(($row['record_kind']??'')!=='event_counts'||($row['event_name']??'')!==$incident['event_name']||empty($row['zero_confirmed'])||empty($row['optimized_by'])||($row['browser_count']??null)!==0||($row['server_count']??null)!==0||empty($row['count_coverage']['browser'])||empty($row['count_coverage']['server']))continue;
                try{$a=new DateTimeImmutable($incident['date'],new DateTimeZone($v['timezone']));$b=$a->modify('+1 day');}catch(Throwable $x){continue;}$zero=true;
                global $wpdb;$emitted=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE pixel_id=%s AND nome=%s AND criado_em>=%d AND criado_em<%d AND classe_trafego='nao_marcado' AND navegador_observado=1",$wpdb->prefix.'f3base_meta_eventos',$incident['dataset_id'],$incident['event_name'],$a->getTimestamp(),$b->getTimestamp()))>0;
                $emitted=$emitted||(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM %i WHERE pixel_id=%s AND evento_nome=%s AND evento_em>=%d AND evento_em<%d AND classe_trafego='nao_marcado' AND estado='entregue'",F3Base_Capi_Fila::tabela(),$incident['dataset_id'],$incident['event_name'],$a->getTimestamp(),$b->getTimestamp()))>0;
            }$cursor=$r['proximo_cursor'];$pages++;
        }while(!$zero&&$cursor&&$pages<31);
        if(!$zero)return ['avisar'=>false,'codigo'=>$cursor?'cobertura_limitada':'zero_nao_confirmado'];
        // Positive spend is evidence; a missing/incomplete page is never evidence of zero.
        if(!$emitted&&F3Base_Meta_Ads::configuracao()['account_id']===$c['account_id']){$cursor=null;$pages=0;do{$p=F3Base_Meta_Ads::consultar(['de'=>$incident['date'],'ate'=>$incident['date'],'limite'=>100]+($cursor?['cursor'=>$cursor]:[]));foreach($p['linhas']??[] as $v)if(preg_match('/^[0-9]+(?:\.[0-9]+)?$/D',(string)($v['row']['spend']??''))&&preg_match('/[1-9]/',(string)$v['row']['spend']))$spend=true;$cursor=$p['proximo_cursor']??null;$pages++;}while(!$spend&&$cursor&&$pages<31);}
        return ['avisar'=>$emitted||$spend,'emitido'=>$emitted,'gasto_positivo'=>$spend,'codigo'=>$emitted||$spend?'incidente_e_atividade_confirmados':'atividade_nao_comprovada'];
    }
    public static function monitorar(): array {
        $cfg=self::opcoes();$actor=get_user_by('id',$cfg['operador']);if(!$cfg['ativo']||!$cfg['avisar']||!$actor||!user_can($actor,'manage_options')||!user_can($actor,'f3base_ler_leads'))return ['ok'=>false,'codigo'=>'avisos_desligados_ou_operador_revogado'];
        if(!F3Base_Recuperacao::entrar())return ['ok'=>false,'codigo'=>'core_em_recuperacao'];$lock=F3Base_Trava::adquirir('meta-monitoramento',90);if(!$lock){F3Base_Recuperacao::sair();return ['ok'=>false,'codigo'=>'ocupado'];}$previous=get_current_user_id();
        try{wp_set_current_user($actor->ID);$st=self::status();if(empty($st['pronto']))return ['ok'=>false,'codigo'=>'concessao_indisponivel'];$h=F3Base_Midia_Prontidao::publica('meta/health');if(empty($h['ok']))return $h;$count=0;
            foreach($h['dados']['datasets']['issues']??[] as $incident){$proof=self::avaliar($incident);if(!$proof['avisar'])continue;$key=$incident['incident_key'];$reserved=false;
                $r=F3Base_Options::atualizar_estado('f3base_meta_monitoramento_estado',static function($s)use($key,$incident,$proof,$cfg,&$reserved){if(isset($s[$key]))return null;$s[$key]=['estado'=>'incerto','incidente'=>$incident,'evidencia'=>$proof,'revisao'=>$cfg['revisao'],'canal'=>$cfg['canal'],'em'=>time()];$reserved=true;return $s;});
                if(!$reserved||empty($r['persisted'])||self::opcoes()!==$cfg)continue;
                $title='Meta — evento otimizado sem recebimento';$text='Pixel '.$incident['dataset_id'].' · '.$incident['event_name'].' · '.$incident['date']."\nZero confirmado pelo monitoramento Meta; atividade do site ou gasto comprovado.";
                $sent=$cfg['canal']==='email'?F3Base_Alertas_Operacionais::enviar($title,$text,false):F3Base_Email_Excedida::slack($title,$text,false);
                F3Base_Options::atualizar_estado('f3base_meta_monitoramento_estado',static function($s)use($key,$sent){$s[$key]['resultado']=$sent;$s[$key]['estado']=!empty($sent['ok'])?'confirmado':'incerto';return $s;});$count++;
            }return ['ok'=>true,'avisos'=>$count];
        }finally{wp_set_current_user($previous);F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function iniciar(): void {
        /* Catalog declaration belongs to F3Base_Options. */
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),125);add_action(self::HOOK,[__CLASS__,'monitorar']);
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('meta-monitoramento-status','Estado da concessão de monitoramento Meta',[__CLASS__,'status']);F3Base_Servicos::ability('meta-monitoramento-ler','Histórico local de alterações, contagens e EMQ, com paginação',[__CLASS__,'ler'],self::schema(),['de','ate','report']);$s=self::schema();unset($s['report'],$s['dataset_id']);$s['plataforma']=['type'=>'string','enum'=>['google_ads','meta_ads']];$s['conta_id']=['type'=>'string','pattern'=>'^[0-9]{1,40}$'];F3Base_Servicos::ability('anuncios-alteracoes-ler','Alterações por conta, dia, entidade e campo; autoria exige dados pessoais',[__CLASS__,'alteracoes'],$s,['de','ate','plataforma']);});
    }
    public static function conferir_agenda_1(): void {$c=self::opcoes();if($c['ativo']&&$c['avisar']&&!wp_next_scheduled(self::HOOK))wp_schedule_event(time()+120,'hourly',self::HOOK);if(!$c['ativo']||!$c['avisar'])wp_clear_scheduled_hook(self::HOOK);}
}
