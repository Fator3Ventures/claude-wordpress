<?php
/** Bounded catalog refresh; already verified forms remain available between pages. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Descoberta {
    public static function atualizar(string $page,array $catalog,callable $get,float $deadline): array {
        $catalog['itens']=$catalog['itens']??array();$scan=$catalog['varredura']??array('vistos'=>array(),'cursor'=>'','iniciada_em'=>time());
        try{
            $q=array('fields'=>'id,name,status','limit'=>10);if($scan['cursor']!==''){$q['after']=$scan['cursor'];}
            $r=$get($page.'/leadgen_forms',$q,$page);if(empty($r['ok'])){throw new RuntimeException($r['codigo']??'catalogo_indisponivel');}
            $rows=$r['json']['data']??null;if(!is_array($rows)||count($rows)>10){throw new RuntimeException('catalogo_resposta_invalida');}
            $next=!empty($r['json']['paging']['next'])?($r['json']['paging']['cursors']['after']??null):'';
            if(!is_string($next)||strlen($next)>2048||($next!==''&&($next===$scan['cursor']||!$rows))){throw new RuntimeException('catalogo_cursor_invalido');}
            foreach($rows as $f){
                $id=(string)($f['id']??'');if(!ctype_digit($id)||strlen($id)>100){throw new RuntimeException('catalogo_formulario_invalido');}
                if(!isset($catalog['itens'][$id])){
                    if(count($catalog['itens'])>=10000){throw new RuntimeException('catalogo_limite');}
                    if(microtime(true)>$deadline-5){throw new RuntimeException('catalogo_em_continuacao');}
                    $detail=$get($id,array('fields'=>'id,questions'),$page);
                    if(empty($detail['ok'])){throw new RuntimeException($detail['codigo']??'catalogo_perguntas_indisponiveis');}
                    if((string)($detail['json']['id']??'')!==$id||!is_array($detail['json']['questions']??null)){throw new RuntimeException('catalogo_perguntas_invalidas');}
                    $catalog['itens'][$id]=array('id'=>$id,'pagina_id'=>$page,'questions'=>$detail['json']['questions'],'incluido_em'=>time());
                }
                $catalog['itens'][$id]['nome']=substr(sanitize_text_field((string)($f['name']??'')),0,200);$catalog['itens'][$id]['status']=substr(sanitize_key((string)($f['status']??'')),0,64);$scan['vistos'][$id]=true;
            }
            $scan['cursor']=$next;$catalog['em']=time();
            if($next===''){$catalog['itens']=array_intersect_key($catalog['itens'],$scan['vistos']);$catalog['atualizado_em']=time();unset($catalog['varredura']);}
            else{$catalog['varredura']=$scan;}
            $catalog['completa']=true;unset($catalog['ultima_falha']);
            return array('ok'=>true,'catalogo'=>$catalog,'parcial'=>$next!=='');
        }catch(Throwable $e){
            $catalog['varredura']=$scan;$catalog['completa']=!empty($catalog['itens']);$catalog['ultima_falha']=array('codigo'=>$e->getMessage(),'em'=>time());
            return array('ok'=>false,'codigo'=>$e->getMessage(),'catalogo'=>$catalog,'parcial'=>true);
        }
    }
}
