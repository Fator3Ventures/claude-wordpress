<?php
/** Per-request inclusive/self timers. Never stores visit data or changes plugin activation. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Desempenho {
    private static bool $ativo=false;
    private static array $rows=[];
    private static array $stack=[];
    private static array $contexts=[];
    private static bool $printed=false;
    private static ?WeakMap $wrapped=null;
    private static array $queries=[];
    private static int $query_count=0;
    private static array $catalogo=array('aberturas'=>0,'primeira'=>null);
    public static function catalogo_aberto(): void {
        if(!self::$ativo){return;}
        ++self::$catalogo['aberturas'];if(self::$catalogo['primeira']!==null){return;}$trace=array();
        foreach(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS,12) as $f){$file=(string)($f['file']??'');$trace[]=array('chamador'=>($f['class']??'').($f['type']??'').($f['function']??''),'arquivo'=>str_starts_with($file,ABSPATH)?substr($file,strlen(ABSPATH)):'fora_do_wordpress','linha'=>$f['line']??null);}
        self::$catalogo['primeira']=array('hook'=>current_filter(),'perfil_publico'=>class_exists('F3Base_Perfil_Publico',false)&&F3Base_Perfil_Publico::ativo(),'trilha'=>$trace);
    }
    private static array $hooks=['plugins_loaded','init','wp_loaded','wp','template_redirect','wp_head','wp_footer','login_head','login_footer','render_block','the_content','wp_enqueue_scripts','wp_nav_menu','nav_menu_link_attributes','wpseo_schema_graph','wpseo_schema_organization','wpseo_schema_person','wpseo_schema_webpage'];
    public static function instrumentar($hook): void {
        if(!in_array($hook,self::$hooks,true)){return;}global $wp_filter;if(empty($wp_filter[$hook])){return;}
        foreach($wp_filter[$hook]->callbacks as $priority=>$callbacks){foreach($callbacks as $id=>$entry){
            $cb=$entry['function'];if($cb instanceof Closure&&self::$wrapped!==null&&isset(self::$wrapped[$cb])){continue;}
            $own=false;if(is_array($cb)){$own=str_starts_with(is_object($cb[0])?get_class($cb[0]):(string)$cb[0],'F3Base_')&&$cb[0]!==__CLASS__;}
            elseif($cb instanceof Closure){$file=(new ReflectionFunction($cb))->getFileName();$own=$file&&str_starts_with($file,F3BASE_PLUGIN_DIR)&&!str_ends_with($file,'class-f3base-desempenho.php');}
            elseif(is_string($cb)){$own=str_starts_with($cb,'f3base_')||str_starts_with($cb,'F3Base_');}
            if($own){$wp_filter[$hook]->callbacks[$priority][$id]['function']=self::callback($hook,$cb);}
        }}
    }
    /** Observador de prioridade inicial. Preserva o primeiro argumento de cada filtro. */
    public static function observar($valor=null) {
        self::instrumentar(current_filter());
        return $valor;
    }
    public static function consulta(string $sql): string {
        if(!self::$stack){return $sql;}
        ++self::$query_count;
        if(count(self::$queries)>=200){return $sql;}

        // Campos desconhecidos ficam vazios. Texto livre, valores e chaves dinâmicas não entram na sonda.
        $inicio=substr($sql,0,2048);
        preg_match('/^\s*(SELECT|INSERT|REPLACE|UPDATE|DELETE|SHOW|ALTER|CREATE|DESCRIBE|DROP|TRUNCATE|SET|START|COMMIT|ROLLBACK)\b/i',$inicio,$verbo);
        $operacao=strtoupper($verbo[1]??'OUTRA');
        $prefixo=match($operacao){
            'SELECT'=>'SELECT\s+[a-z0-9_`*.,()\s]+?\s+FROM',
            'DELETE'=>'DELETE\s+FROM',
            'INSERT','REPLACE'=>$operacao.'(?:\s+IGNORE)?\s+INTO',
            'UPDATE'=>'UPDATE(?:\s+IGNORE)?',
            'CREATE','DROP','ALTER','TRUNCATE'=>$operacao.'\s+TABLE(?:\s+IF\s+(?:NOT\s+)?EXISTS)?',
            'DESCRIBE'=>'DESCRIBE',
            default=>null,
        };
        $tabela='';
        if($prefixo!==null&&preg_match('/^\s*'.$prefixo.'\s+`?([a-z0-9_]+)`?(?=\s|\(|;|$)/i',$inicio,$nome)){
            $tabela=$nome[1];
        }
        $option=null;
        if($tabela!==''&&preg_match("/\boption_name`?\s*=\s*'([a-z0-9_]{1,128})'/i",$inicio,$nome)){
            static $publicas=null;
            $publicas??=array_fill_keys(array_merge(require __DIR__.'/opcoes-publicas.php',
                ['home','siteurl','blogname','active_plugins','stylesheet','template','f3base_config_publica']),true);
            if(isset($publicas[$nome[1]])){$option=$nome[1];}
        }
        self::$queries[]=[
            'operacao'=>$operacao,'tabela'=>$tabela,'option'=>$option,'callback'=>end(self::$contexts),
            'estrutura'=>in_array($operacao,['SHOW','ALTER','CREATE','DESCRIBE','DROP','TRUNCATE'],true),
        ];
        return $sql;
    }
    public static function ambiente(): array {
        $s=function_exists('opcache_get_status')?@opcache_get_status(false):false;
        return array('opcache'=>array('ligado'=>is_array($s)&&!empty($s['opcache_enabled']),'acertos'=>(int)($s['opcache_statistics']['hits']??0),'validate_timestamps'=>ini_get('opcache.validate_timestamps'),'revalidate_freq'=>ini_get('opcache.revalidate_freq')),'realpath_cache'=>array('bytes'=>function_exists('realpath_cache_size')?realpath_cache_size():null,'entradas'=>function_exists('realpath_cache_get')?count(realpath_cache_get()):null,'limite'=>ini_get('realpath_cache_size'),'ttl'=>ini_get('realpath_cache_ttl')));
    }
    public static function medir(string $module,string $phase,callable $fn){
        if(!self::$ativo){return $fn();}
        $start=hrtime(true);self::$stack[]=0;self::$contexts[]=$module.':'.$phase;$i=count(self::$stack)-1;
        try{return $fn();}finally{
            $elapsed=(hrtime(true)-$start)/1e6;$children=array_pop(self::$stack);array_pop(self::$contexts);
            if($i>0){self::$stack[$i-1]+=$elapsed;}
            $key=$phase.':'.$module;$r=self::$rows[$key]??['modulo'=>$module,'fase'=>$phase,'chamadas'=>0,'total_ms'=>0.0,'proprio_ms'=>0.0];
            $r['chamadas']++;$r['total_ms']+=$elapsed;$r['proprio_ms']+=max(0,$elapsed-$children);self::$rows[$key]=$r;
        }
    }
    public static function callback(string $hook,$fn): callable {
        if(!self::$ativo){return $fn;}
        $name=is_array($fn)?(is_object($fn[0])?get_class($fn[0]):$fn[0]).'::'.$fn[1]:($fn instanceof Closure?'callback':(string)$fn);
        if($fn instanceof Closure){$reflection=new ReflectionFunction($fn);$name='anonima:'.basename((string)$reflection->getFileName()).':'.$reflection->getStartLine();}
        $wrapper=static fn(...$args)=>self::medir($name,$hook,static fn()=>$fn(...$args));if(self::$wrapped===null){self::$wrapped=new WeakMap();}self::$wrapped[$wrapper]=true;return $wrapper;
    }
    public static function resumo(): array {
        if(!self::$ativo){return ['ok'=>false,'codigo'=>'requisicao_sem_perfil','versao'=>F3BASE_PLUGIN_VERSAO];}
        // Congelar o ponto de corte antes de ordenar linhas ou consultar o ambiente.
        $fim=microtime(true);
        $rows=array_values(self::$rows);
        $proprio=array_sum(array_column($rows,'proprio_ms'));
        usort($rows,static fn($a,$b)=>$b['proprio_ms']<=>$a['proprio_ms']);
        foreach($rows as &$row){
            $row['total_ms']=round($row['total_ms'],3);
            $row['proprio_ms']=round($row['proprio_ms'],3);
        }
        unset($row);
        $janela=max(0,($fim-(defined('F3BASE_INICIO')?F3BASE_INICIO:$fim))*1000);
        $contexto=wp_doing_cron()?'cron':(is_admin()?'administracao':((defined('REST_REQUEST')&&REST_REQUEST)?'rest':(($GLOBALS['pagenow']??'')==='wp-login.php'?'login':'pagina')));
        return [
            'ok'=>true,'versao'=>F3BASE_PLUGIN_VERSAO,'contexto'=>$contexto,'escopo'=>'callbacks_core_e_carga',
            'catalogo_completo'=>self::$catalogo,'cta'=>class_exists('F3Base_Servicos',false)?F3Base_Servicos::cta_diagnostico():null,
            'consultas'=>self::$queries,'consultas_total'=>self::$query_count,
            'classes_carregadas'=>array_values(array_filter(get_declared_classes(),static fn($c)=>str_starts_with($c,'F3Base_'))),
            'ambiente'=>self::ambiente(),'nao_instrumentado_ms'=>round(max(0,$janela-$proprio),3),
            'nao_instrumentado_escopo'=>'Janela do arquivo principal ao início do relatório menos intervalos concluídos. Inclui código do Core, WordPress, tema e outros plugins.',
            'modulos'=>$rows,'total_proprio_ms'=>round($proprio,3),
            'geracao_ate_agora_ms'=>round(max(0,($fim-(float)($_SERVER['REQUEST_TIME_FLOAT']??$fim))*1000),3),
            'includes_core'=>count(array_filter(get_included_files(),static fn($f)=>str_starts_with($f,F3BASE_PLUGIN_DIR))),
        ];
    }
    private static function requisicao_com_perfil(): bool {
        if((defined('F3BASE_PERFIL_PHP')&&F3BASE_PERFIL_PHP===true)||PHP_SAPI==='cli'||is_admin()||wp_doing_cron()){
            return true;
        }
        if ((defined('LOGGED_IN_COOKIE') && !empty($_COOKIE[LOGGED_IN_COOKIE]))
            || !empty($_SERVER['HTTP_AUTHORIZATION']) || !empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])
            || !empty($_SERVER['PHP_AUTH_USER'])) {
            return true;
        }
        $metodo = $_SERVER['REQUEST_METHOD'] ?? '';
        $caminho = (string) wp_parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        $prefixo = '/' . trim(rest_get_url_prefix(), '/') . '/';
        $inicio_rest = strpos(rtrim($caminho, '/') . '/', $prefixo);
        if ($metodo === 'POST') {
            // A rota explícita prevalece também nas instalações sem links permanentes.
            $rota = $_GET['rest_route'] ?? ($inicio_rest === false ? '' : substr($caminho, $inicio_rest + strlen($prefixo) - 1));
            $namespace = '/' . F3BASE_REST_NAMESPACE . '/';
            if (!is_string($rota) || !in_array(rtrim($rota, '/'), [$namespace . 'comportamento', $namespace . 'analise'], true)) {
                return true;
            }
        } elseif (!in_array($metodo, ['GET', 'HEAD'], true)
            || (defined('REST_REQUEST') && REST_REQUEST) || isset($_GET['rest_route']) || $inicio_rest !== false) {
            return true;
        }
        if(self::assinatura_sonda()===null){return false;}
        if(function_exists('wp_salt')){return self::sonda();}
        // WordPress disponibiliza wp_salt depois dos plugins. Validar assim que possível
        // permite que uma sonda genuína meça também o bootstrap anterior a plugins_loaded.
        add_action('plugins_loaded',[self::class,'confirmar_sonda'],PHP_INT_MIN);
        return true;
    }
    public static function confirmar_sonda(): void {
        if(self::sonda()){return;}
        self::$ativo=false;
        foreach(self::$hooks as $hook){remove_filter($hook,[self::class,'observar'],PHP_INT_MIN);}
        remove_filter('query',[self::class,'consulta'],PHP_INT_MAX);
    }
    public static function iniciar(): void {
        self::$ativo=self::requisicao_com_perfil();
        if(self::$ativo){
            foreach(self::$hooks as $hook){add_filter($hook,[self::class,'observar'],PHP_INT_MIN);}
            add_filter('query',[self::class,'consulta'],PHP_INT_MAX);
        }
        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('desempenho-ler','Tempos por módulo desta requisição ou de sondagem interna assinada da página/login',[self::class,'ler'],['contexto'=>['type'=>'string','enum'=>['atual','pagina','login']],'amostras'=>['type'=>'integer','minimum'=>1,'maximum'=>3]]);});
        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/desempenho',['methods'=>'GET','permission_callback'=>static fn()=>current_user_can('manage_options'),'callback'=>static fn($r)=>rest_ensure_response(self::ler($r->get_params())),'args'=>['contexto'=>['type'=>'string','enum'=>['atual','pagina','login']],'amostras'=>['type'=>'integer','minimum'=>1,'maximum'=>3]]]);});
        if(self::$ativo&&isset($_SERVER['HTTP_X_F3BASE_DESEMPENHO'])){
            add_action('init',static function(){if(self::sonda()){if(!defined('DONOTCACHEPAGE')){define('DONOTCACHEPAGE',true);}nocache_headers();}},0);
            add_action('wp_footer',[self::class,'imprimir'],PHP_INT_MAX);
            add_action('login_footer',[self::class,'imprimir'],PHP_INT_MAX);
        }
    }
    private static function assinatura_sonda(): ?array {
        $v=$_SERVER['HTTP_X_F3BASE_DESEMPENHO']??'';
        return is_string($v)&&preg_match('/^([0-9]{10})\.([a-f0-9]{32})\.([a-f0-9]{64})$/D',$v,$m)&&abs(time()-(int)$m[1])<=60?$m:null;
    }
    private static function sonda(): bool {
        $m=self::assinatura_sonda();
        if($m===null){return false;}
        $path=(string)wp_parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH);
        return hash_equals(hash_hmac('sha256',$m[1].'.'.$m[2].'|'.$path,wp_salt('auth')),$m[3]);
    }
    public static function imprimir(): void {
        if(self::$printed||!self::sonda()){return;}self::$printed=true;
        $prova=hash('sha256',$_SERVER['HTTP_X_F3BASE_DESEMPENHO']);
        echo "\n".'<!--f3base-amostra:'.$prova.'--><!--f3base-desempenho:'.base64_encode(wp_json_encode(self::resumo())).'-->'."\n";
    }
    public static function ler(array $e=[]): array {
        if(!current_user_can('manage_options')){return ['ok'=>false,'codigo'=>'sem_permissao'];}
        $kind=$e['contexto']??'atual';if($kind==='atual'){return self::resumo();}
        if(!in_array($kind,['pagina','login'],true)){return ['ok'=>false,'codigo'=>'contexto_invalido'];}
        $n=max(1,min(3,(int)($e['amostras']??1)));$url=$kind==='login'?site_url('wp-login.php'):home_url('/');$path=(string)wp_parse_url($url,PHP_URL_PATH);$samples=[];
        for($i=0;$i<$n;$i++){
            $nonce=time().'.'.bin2hex(random_bytes(16));$signed=$nonce.'.'.hash_hmac('sha256',$nonce.'|'.$path,wp_salt('auth'));
            $r=wp_safe_remote_get(add_query_arg('f3base_perf',substr(hash('sha256',$nonce),0,16),$url),['timeout'=>12,'redirection'=>0,'limit_response_size'=>2097152,'cookies'=>[],'headers'=>['Cache-Control'=>'no-cache','X-F3Base-Desempenho'=>$signed],'user-agent'=>'F3Base-Sonda/desempenho']);
            // Uma página de cache ou um comentário antigo não pode representar a amostra pedida.
            $marcador='/<!--f3base-amostra:'.hash('sha256',$signed).'--><!--f3base-desempenho:([A-Za-z0-9+\/=]+)-->/';
            if(is_wp_error($r)||wp_remote_retrieve_response_code($r)!==200||!preg_match($marcador,wp_remote_retrieve_body($r),$m)){
                $samples[]=['ok'=>false,'codigo'=>'sonda_sem_relatorio'];continue;
            }
            $parsed=json_decode((string)base64_decode($m[1],true),true);
            $valida=is_array($parsed)&&($parsed['ok']??null)===true&&($parsed['contexto']??null)===$kind&&($parsed['versao']??null)===F3BASE_PLUGIN_VERSAO;
            $samples[]=$valida?$parsed:['ok'=>false,'codigo'=>'sonda_invalida'];
        }
        return ['ok'=>count(array_filter($samples,static fn($s)=>!empty($s['ok'])))===$n,'contexto'=>$kind,'origem'=>'sonda_interna_mesma_origem_sem_cache','amostras'=>$samples,'limite'=>'proprio_ms soma o tempo decorrido nos intervalos concluídos, descontando filhos instrumentados. Inclui esperas e serviços chamados dentro desses intervalos. O corte ocorre no footer, antes da montagem do relatório. Transporte, navegador e callbacks posteriores ficam fora da janela.'];
    }
}
