<?php
/** Durable, authenticated notifications and explicit ownership of subscriptions. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Webhook {
    public const ESQUEMA_VERSAO=16400;
    const EVENTO='f3base_linkedin_notificacoes';const MANUTENCAO='f3base_linkedin_assinaturas';const ROTA='/anuncios/linkedin/notificacoes';
    public static function tabela(): string {global $wpdb;return $wpdb->prefix.'f3base_linkedin_webhook';}
    public static function instalar(): bool {return F3Base_Esquema::instalar(__CLASS__,'instalar',static fn()=>self::instalar_estrutura());}
    public static function instalar_estrutura(): bool {
        global $wpdb;$existing=self::tabela();if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($existing)))===$existing){return true;}require_once ABSPATH.'wp-admin/includes/upgrade.php';$t=self::tabela();dbDelta("CREATE TABLE {$t} (
chave char(64) NOT NULL,
tipo varchar(16) NOT NULL,
contexto char(64) NOT NULL,
conta varchar(100) NOT NULL DEFAULT '',
formulario varchar(100) NOT NULL DEFAULT '',
resposta varchar(191) NOT NULL DEFAULT '',
ocorrido_ms bigint unsigned NOT NULL DEFAULT 0,
acao varchar(16) NOT NULL DEFAULT '',
remoto_id varchar(100) NOT NULL DEFAULT '',
estado varchar(32) NOT NULL,
payload longtext NOT NULL,
tentativas int unsigned NOT NULL DEFAULT 0,
proxima bigint unsigned NOT NULL DEFAULT 0,
criado_em bigint unsigned NOT NULL,
atualizado_em bigint unsigned NOT NULL,
PRIMARY KEY  (chave),
KEY fila (tipo,estado,proxima),
KEY origem (conta,resposta,ocorrido_ms)
) ENGINE=InnoDB {$wpdb->get_charset_collate()};");return !$wpdb->last_error;
    }
    private static function erro(string $code,array $extra=array()): array {return array('ok'=>false,'codigo'=>$code)+$extra;}
    private static function linha(string $key): ?array {global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',self::tabela(),$key),ARRAY_A);}
    private static function inserir(array $row,array $data): bool {global $wpdb;$cipher=F3Base_Contato_Comunicacao::cifrar($data);return $cipher!==''&&false!==$wpdb->insert(self::tabela(),$row+array('payload'=>$cipher,'criado_em'=>time(),'atualizado_em'=>time()));}
    private static function mudar(string $key,array $patch,?array $data=null): bool {global $wpdb;if($data!==null){$patch['payload']=F3Base_Contato_Comunicacao::cifrar($data);if(!$patch['payload']){return false;}}$patch['atualizado_em']=time();return false!==$wpdb->update(self::tabela(),$patch,array('chave'=>$key));}
    /** One durable occurrence per class/context; read-only health never repairs it. */
    private static function registrar_resultado(string $kind,array $r): void {
        $ctx=F3Base_Linkedin::contexto();F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($kind,$r,$ctx){
            $s['webhook'][$kind]=array('em'=>time(),'ok'=>!empty($r['ok']),'contexto'=>$ctx,'codigo'=>$r['codigo']??null,'codigos'=>$r['codigos']??array());
            $key=hash('sha256',$kind.'|'.$ctx);$o=$s['webhook']['ocorrencias'][$key]??array('classe'=>$kind,'contexto'=>$ctx,'primeira_em'=>time(),'repeticoes'=>0);
            if(empty($r['ok'])){$o['aberta']=true;$o['ultima_em']=time();$o['repeticoes']++;$o['codigo']=$r['codigo']??$r['codigos']??'resultado_parcial';$s['webhook']['ocorrencias'][$key]=$o;}
            elseif(isset($s['webhook']['ocorrencias'][$key])){$s['webhook']['ocorrencias'][$key]['aberta']=false;$s['webhook']['ocorrencias'][$key]['resolvida_em']=time();}
            $s['webhook']['ocorrencias']=array_slice($s['webhook']['ocorrencias']??array(),-40,null,true);return $s;
        });
    }
    /** Stable occurrence identity; no submitted values, contact data or raw response. */
    public static function ocorrencia(string $code,string $identity,array $metadata): bool {
        if(!self::instalar()){return false;}$ctx=F3Base_Linkedin::contexto();
        $data=array('codigo'=>$code,'identidade'=>$identity);
        foreach(array('conta','formulario','resposta','submissao_ms','campanha') as $name){if(isset($metadata[$name])){$data[$name]=substr((string)$metadata[$name],0,191);}}
        $data['campos']=array_values(array_unique(array_map(static fn($v)=>substr(sanitize_text_field((string)$v),0,120),$metadata['campos']??array())));
        sort($data['campos']);$key=hash('sha256','ocorrencia|'.$ctx.'|'.$code.'|'.$identity.'|'.wp_json_encode($data['campos']));
        $old=self::linha($key);if($old){return self::mudar($key,array('tentativas'=>(int)$old['tentativas']+1));}
        if(self::inserir(array('chave'=>$key,'tipo'=>'ocorrencia','contexto'=>$ctx,'conta'=>$data['conta']??'','formulario'=>$data['formulario']??'','resposta'=>$data['resposta']??'','ocorrido_ms'=>$data['submissao_ms']??0,'estado'=>'aberta','tentativas'=>1),$data)){return true;}
        return self::linha($key)!==null; // Concurrent identical replay is already durable.
    }
    public static function ocorrencias(): array {
        global $wpdb;$ctx=F3Base_Linkedin::contexto();$rows=$wpdb->get_results($wpdb->prepare('SELECT payload,criado_em,atualizado_em,tentativas FROM %i WHERE tipo=%s AND contexto=%s ORDER BY atualizado_em DESC LIMIT 50',self::tabela(),'ocorrencia',$ctx),ARRAY_A);
        $out=array();foreach($rows??array() as $row){$d=F3Base_Contato_Comunicacao::abrir($row['payload']);if(is_array($d)){$out[]=$d+array('primeira_em'=>(int)$row['criado_em'],'ultima_em'=>(int)$row['atualizado_em'],'repeticoes'=>(int)$row['tentativas']);}}
        return array('total'=>(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM %i WHERE tipo=%s AND contexto=%s',self::tabela(),'ocorrencia',$ctx)),'ultimas'=>$out,'limite'=>50);
    }
    public static function url(?string $ctx=null): string {return add_query_arg('contexto',$ctx??F3Base_Linkedin::contexto(),rest_url(F3BASE_REST_NAMESPACE.self::ROTA));}
    public static function invalidar(): void {F3Base_Linkedin_Integracoes::atualizar_estado(static function($s){$s['webhook']['configuracao_alterada_em']=time();return $s;});F3Base_Fila::agendar(self::MANUTENCAO,time()+5);}
    private static function resposta(array $data,int $status=200): WP_REST_Response {return new WP_REST_Response($data,$status,array('Cache-Control'=>'no-store, private, max-age=0','Pragma'=>'no-cache','Content-Type'=>'application/json'));}
    public static function receber(WP_REST_Request $r): WP_REST_Response {
        $ctx=$r->get_param('contexto');$id=is_string($ctx)?F3Base_Linkedin_Integracoes::por_contexto($ctx):null;
        if($id===null){return self::resposta(self::erro('contexto_inativo'),403);}
        $lock=F3Base_Trava::adquirir('linkedin-callback:'.$id,10);if(!$lock){return self::resposta(self::erro('callback_ocupado'),503);}
        try{$result=F3Base_Linkedin_Integracoes::executar($id,static fn()=>self::receber_escopo($r));return $result instanceof WP_REST_Response?$result:self::resposta($result,503);}finally{F3Base_Trava::liberar($lock);}
    }
    private static function receber_escopo(WP_REST_Request $r): WP_REST_Response {
        if(!is_ssl()){return self::resposta(self::erro('https_obrigatorio'),400);}$cfg=F3Base_Linkedin::config();$ctx=F3Base_Linkedin::contexto();
        if(empty($cfg['ativo'])||empty($cfg['webhook']['ativo'])||empty($cfg['proprietario_confirmado'])){return self::resposta(self::erro('recebimento_desligado'),403);}
        if(!is_string($r->get_param('contexto'))||!hash_equals($ctx,$r->get_param('contexto'))){return self::resposta(self::erro('contexto_inativo'),403);}
        $external=F3Base_Linkedin_Cliente::externo();$secret=$external?'':F3Base_Segredos::abrir(F3Base_Linkedin_Api::SECRET);if(!$external&&$secret===''){return self::resposta(self::erro('assinatura_indisponivel'),503);}
        if($r->get_method()==='GET'){
            $code=$r->get_param('challengeCode');$application=$r->get_param('applicationId');
            if(!is_string($code)||$code===''||strlen($code)>1024||preg_match('/[\x00-\x1f]/',$code)||($application!==null&&!empty($cfg['aplicativo_id'])&&(string)$application!==$cfg['aplicativo_id'])){return self::resposta(self::erro('desafio_invalido'),400);}
            $verified=$external?F3Base_Linkedin_Cliente::chamar('verify_challenge',array('challenge_code'=>$code)+($application!==null?array('application_id'=>(string)$application):array())):array('ok'=>true,'data'=>array('challengeResponse'=>hash_hmac('sha256',$code,$secret)));unset($secret);if(empty($verified['ok'])){return self::resposta(self::erro($verified['codigo']),503);}$response=$verified['data']['challengeResponse'];$save=F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($ctx){$s['webhook']['ultimo_desafio_respondido_em']=time();$s['webhook']['desafio_contexto']=$ctx;return $s;});
            if(empty($save['persisted'])){return self::resposta(self::erro('desafio_registro_indisponivel'),503);}return self::resposta(array('challengeCode'=>$code,'challengeResponse'=>$response));
        }
        $raw=$r->get_body();if(strlen($raw)>131072){return self::resposta(self::erro('corpo_excede_limite'),413);}$signature=(string)$r->get_header('x-li-signature');
        $verified=$external?F3Base_Linkedin_Cliente::chamar('verify_notification',array('raw_body'=>$raw,'signature'=>$signature)):array('ok'=>preg_match('/^[a-f0-9]{64}$/D',$signature)&&hash_equals(hash_hmac('sha256','hmacsha256='.$raw,$secret),$signature));unset($secret);if(empty($verified['ok'])){return self::resposta(self::erro('assinatura_recusada'),403);}
        $p=json_decode($raw,true,32,JSON_BIGINT_AS_STRING);if(!is_array($p)||($p['type']??'')!=='LEAD_ACTION'||($p['leadType']??'')!=='SPONSORED'||!in_array($p['leadAction']??'',array('CREATED','DELETED'),true)||($p['owner']['sponsoredAccount']??'')!==F3Base_Linkedin::dono($cfg)){return self::resposta(self::erro('notificacao_fora_do_escopo'),400);}
        if($external&&F3Base_Linkedin_Descoberta::ativa($cfg)){$discovery=F3Base_Linkedin_Descoberta::atualizar(microtime(true)+10);if(empty($discovery['ok'])){return self::resposta(self::erro($discovery['codigo']),503);}}
        $v=F3Base_Linkedin::versionada((string)($p['leadGenForm']??''));$at=F3Base_Linkedin::instante($p['occurredAt']??null);$urn=(string)($p['leadGenFormResponse']??'');
        if($external&&F3Base_Linkedin_Descoberta::ativa($cfg)&&$v&&!in_array($v['id'],F3Base_Linkedin::formularios($cfg),true)){return self::resposta(self::erro('descoberta_em_continuacao'),503);}
        if(!$v||!$at||!in_array($v['id'],F3Base_Linkedin::formularios($cfg),true)||!preg_match('/^urn:li:leadGenFormResponse:([A-Za-z0-9_-]{1,150})$/D',$urn,$m)){return self::resposta(self::erro('formulario_ou_resposta_invalida'),400);}
        $response=$m[1];$activation=F3Base_Linkedin_Integracoes::estado()['aquisicao']['ativado_em']??0;if(!$activation||$at['segundos']<$activation){return self::resposta(array('ok'=>true,'codigo'=>'anterior_ao_marco'));}
        if(!F3Base_Leads_Repositorio::quota(hash('sha256','linkedin-hook|'.$cfg['conta_id'].'|'.gmdate('YmdHi')),300,time()+120)){return self::resposta(self::erro('limite_local'),429);}
        if(!F3Base_Recuperacao::entrar()){return self::resposta(self::erro('core_em_recuperacao'),503);}
        try{
            $key=hash('sha256',$cfg['conta_id'].'|'.$urn.'|'.$at['ms'].'|'.$p['leadAction']);global $wpdb;
            $cipher=F3Base_Contato_Comunicacao::cifrar(array('notificacao'=>$p,'formulario_versionado'=>$v['urn']));if(!$cipher){return self::resposta(self::erro('recibo_cifra_indisponivel'),503);}
            $saved=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO %i (chave,tipo,contexto,conta,formulario,resposta,ocorrido_ms,acao,estado,payload,proxima,criado_em,atualizado_em) VALUES (%s,'notificacao',%s,%s,%s,%s,%s,%s,'pendente',%s,%d,%d,%d)",self::tabela(),$key,$ctx,$cfg['conta_id'],$v['id'],$response,$at['ms'],$p['leadAction'],$cipher,time(),time(),time()));
            if($saved===false){return self::resposta(self::erro('recibo_nao_persistido'),503);}
            F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($ctx){$s['webhook']['ultima_notificacao_autenticada_em']=time();$s['webhook']['notificacao_contexto']=$ctx;return $s;});
            $schedule=F3Base_Fila::agendar_detalhe(self::EVENTO,time()+1);
            // Kick only WP-Cron. Processing is never part of the public response.
            $spawn=function_exists('spawn_cron')?spawn_cron():false;
            F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($schedule,$spawn){$s['webhook']['despacho']=array('em'=>time(),'agenda'=>$schedule,'loopback_solicitado'=>(bool)$spawn,'processamento_confirmado'=>false);return $s;});
            return self::resposta(array('ok'=>true,'codigo'=>$saved?'recibo_persistido':'recibo_repetido'));
        }finally{F3Base_Recuperacao::sair();}
    }
    /** Latest matching submission before a deletion; a delayed delete cannot cancel a newer one. */
    private static function remover_origem(array $row): array {
        global $wpdb;$native=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE origem='linkedin' AND conta=%s AND formulario=%s AND nativo_id=%s AND submissao_ms<=%s ORDER BY submissao_ms DESC LIMIT 1",F3Base_Anuncios::tabela(),$row['conta'],$row['formulario'],$row['resposta'],$row['ocorrido_ms']),ARRAY_A);
        if($wpdb->last_error){return self::erro('leitura_submissao_falhou');}if(!$native){return array('ok'=>true,'codigo'=>'remocao_registrada_sem_captura');}$lead=F3Base_Leads_Repositorio::obter($native['record_id']);if(!$lead){return array('ok'=>true,'codigo'=>'contato_ja_ausente');}
        $jobs=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s',F3Base_Pipedrive_Fila::tabela(),$lead['record_id']),ARRAY_A);if($wpdb->last_error){return self::erro('fila_indisponivel');}
        foreach($jobs as $job){if(!F3Base_Pipedrive_Fila::travar_linha($job['chave'])){return self::erro('entrega_ocupada');}try{$fresh=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE chave=%s',F3Base_Pipedrive_Fila::tabela(),$job['chave']),ARRAY_A);if(!$fresh){continue;}if($fresh['lease']!==''&&(int)$fresh['lease_ate']>time()){return self::erro('entrega_em_curso');}if($fresh['estado']!=='entregue'&&false===$wpdb->update(F3Base_Pipedrive_Fila::tabela(),array('estado'=>'cancelado','codigo'=>'origem_linkedin_removida','proxima'=>0),array('chave'=>$job['chave'],'journal'=>$fresh['journal'],'estado'=>$fresh['estado']))){return self::erro('cancelamento_fila_falhou');}}finally{F3Base_Pipedrive_Fila::liberar_linha($job['chave']);}}
        if(!F3Base_Avisos::cancelar($lead['record_id'])){return self::erro('cancelamento_avisos_pendente');}
        $d=$lead['dados'];$d['origem_nativa']['remocao_remota']=array('ocorrido_ms'=>(string)$row['ocorrido_ms'],'observada_em'=>time(),'efeito'=>'Pendências locais canceladas. Contato e registros já entregues preservados.');$ent=$lead['entrega'];$ent['pipedrive']['solicitado']=false;
        if(1!==$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('revisao'=>(int)$lead['revisao']+1,'dados'=>wp_json_encode($d),'entrega'=>wp_json_encode($ent),'aviso'=>in_array($lead['aviso'],array('pendente','falhou'),true)?'suprimido':$lead['aviso']),array('record_id'=>$lead['record_id'],'revisao'=>$lead['revisao']))){return self::erro('remocao_origem_checkpoint_falhou');}
        return array('ok'=>true,'codigo'=>'origem_removida_pendencias_canceladas','record_id'=>$lead['record_id']);
    }
    public static function removida(string $account,string $form,string $id,string $submitted): ?bool {global $wpdb;$v=$wpdb->get_var($wpdb->prepare("SELECT chave FROM %i WHERE tipo='notificacao' AND conta=%s AND formulario=%s AND resposta=%s AND acao='DELETED' AND ocorrido_ms>=%s LIMIT 1",self::tabela(),$account,$form,$id,$submitted));return $wpdb->last_error?null:(bool)$v;}
    public static function processar(): array {
        $cfg=F3Base_Linkedin::config();if(empty($cfg['ativo'])){return array('ok'=>true,'codigo'=>'linkedin_desligado');}if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}$lock=F3Base_Trava::adquirir('linkedin-notificacoes:'.F3Base_Linkedin_Integracoes::id(),30);if(!$lock){F3Base_Recuperacao::sair();return self::erro('processamento_ocupado');}$execution=F3Base_Linkedin_Integracoes::revisao_execucao();$deadline=microtime(true)+min(20,F3Base_Execucoes::restante_ms(1500)/1000);F3Base_Linkedin_Cliente::prazo($deadline);$n=0;$errors=array();
        try{global $wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE tipo='notificacao' AND contexto=%s AND estado='pendente' AND proxima<=%d ORDER BY ocorrido_ms,criado_em LIMIT 20",self::tabela(),F3Base_Linkedin::contexto(),time()),ARRAY_A);
            if($wpdb->last_error){$r=self::erro('fila_leitura_indisponivel');self::registrar_resultado('processamento',$r);return $r;}
            foreach($rows as $row){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){$errors[]='revision_conflict';break;}if(microtime(true)>$deadline-3){break;}if($row['conta']!==$cfg['conta_id']||!in_array($row['formulario'],F3Base_Linkedin::formularios($cfg),true)){self::mudar($row['chave'],array('estado'=>'fora_escopo'));continue;}
                if($row['acao']==='DELETED'){$sub=F3Base_Trava::adquirir('linkedin-submissao:'.hash('sha256',$row['conta'].'|'.$row['formulario'].'|'.$row['resposta']),30);if(!$sub){$r=self::erro('submissao_ocupada');}else{try{$r=self::remover_origem($row);}finally{F3Base_Trava::liberar($sub);}}}else{
                    $r=F3Base_Linkedin_Cliente::pedir('GET','leadFormResponses/'.$row['resposta'],array('fields'=>F3Base_Linkedin_Api::CAMPOS,'form_id'=>$row['formulario']));
                    if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){$errors[]='revision_conflict';break;}if(!empty($r['ok'])){$stamp=F3Base_Linkedin::instante($r['data']['submittedAt']??null);$v=F3Base_Linkedin::versionada((string)($r['data']['versionedLeadGenFormUrn']??''));
                        if(!$stamp||!$v||$v['id']!==$row['formulario']||(string)($r['data']['id']??'')!==$row['resposta']){$r=self::erro('detalhe_notificacao_divergente');}
                        elseif((int)$stamp['ms']>(int)$row['ocorrido_ms']){$r=array('ok'=>true,'codigo'=>'notificacao_superada_consulta_periodica_independente');}
                        else{$r=F3Base_Linkedin::ingerir_resposta($r['data'],'webhook');}
                    }elseif(($r['http']??0)===404){$r=self::erro('resposta_ainda_nao_disponivel',array('retry_after'=>60));}
                }
                if(!F3Base_Trava::renovar($lock,30)){$errors[]='worker_reserva_perdida';break;}$done=!empty($r['ok']);$data=F3Base_Contato_Comunicacao::abrir($row['payload']);$data['resultado']=array_intersect_key($r,array_flip(array('ok','codigo','record_id','http')));
                if(!self::mudar($row['chave'],array('estado'=>$done?'processado':((int)$row['tentativas']>=9?'revisao':'pendente'),'tentativas'=>(int)$row['tentativas']+1,'proxima'=>$done?0:time()+max((int)($r['retry_after']??0),min(21600,60*2**min(8,(int)$row['tentativas'])))),$data)){$errors[]='recibo_resultado_nao_persistido';break;}$n++;if(!$done){$errors[]=$r['codigo'];}
            }
            $next=$wpdb->get_var($wpdb->prepare("SELECT MIN(proxima) FROM %i WHERE contexto=%s AND tipo='notificacao' AND estado='pendente'",self::tabela(),F3Base_Linkedin::contexto()));if($next!==null){F3Base_Fila::agendar(self::EVENTO,max(time()+5,(int)$next));}
            $r=array('ok'=>!$errors,'processados'=>$n,'codigos'=>array_values(array_unique($errors)));self::registrar_resultado('processamento',$r);return $r;
        }finally{F3Base_Linkedin_Cliente::prazo(0);F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    private static function localizar(array $wanted): array {
        if(empty($wanted['owner'])||empty($wanted['webhook'])||empty($wanted['versionedForm'])){return self::erro('autoria_local_incompleta');}$all=array();for($start=0;$start<1000;$start+=100){$r=F3Base_Linkedin_Cliente::pedir('GET','leadNotifications',array('q'=>'criteria','owner'=>array('value'=>$wanted['owner']),'leadType'=>array('leadType'=>'SPONSORED'),'start'=>$start,'count'=>100));if(empty($r['ok'])){return $r;}$rows=$r['data']['elements']??null;$p=$r['data']['paging']??null;if(!is_array($rows)||!is_array($p)||(int)($p['start']??-1)!==$start){return self::erro('assinaturas_paginacao_invalida');}foreach($rows as $row){if(($row['webhook']??'')===$wanted['webhook']&&($row['owner']??null)===$wanted['owner']&&($row['versionedForm']??$row['versionedFormUrn']??'')===$wanted['versionedForm']&&($row['leadType']??'')==='SPONSORED'){$all[]=$row;}}
            $more=isset($p['total'])?$start+count($rows)<(int)$p['total']:count($rows)===100;if(!$more){return array('ok'=>true,'linhas'=>$all,'completa'=>true);}if(!$rows){break;}}
        return self::erro('assinaturas_consulta_incompleta');
    }
    public static function configurar(array $e): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}$action=$e['acao']??'consultar';if($action==='consultar'){return array('ok'=>true,'diagnostico'=>self::diagnostico());}
        if(!in_array($action,array('ativar','desativar','reconciliar'),true)){return self::erro('acao_invalida');}$cfg=F3Base_Linkedin::config();$rev=F3Base_Options::revisao(F3Base_Linkedin::OPCAO);
        if(($e['simular']??true)!==false){return array('ok'=>true,'simular'=>true,'acao'=>$action,'revisao'=>$rev,'formularios'=>F3Base_Linkedin::formularios($cfg),'efeito'=>'Gerenciar apenas assinaturas registradas por esta instalação. Desativar o webhook mantém a consulta periódica.','diagnostico'=>self::diagnostico());}
        $key=(string)($e['chave_operacao']??'');if(!preg_match('/^[A-Za-z0-9._:-]{8,128}$/D',$key)){return self::erro('chave_operacao_obrigatoria');}$op=hash('sha256',home_url().'|linkedin|'.F3Base_Linkedin_Integracoes::id().'|'.$key);$hash=hash('sha256',wp_json_encode($e));$old=self::linha($op);if($old){if(F3Base_Linkedin_Cliente::externo()){$access=F3Base_Linkedin_Cliente::chamar('effective_status');if(empty($access['ok'])){return $access;}}$data=F3Base_Contato_Comunicacao::abrir($old['payload']);return ($data['hash']??'')!==$hash?self::erro('chave_operacao_reutilizada'):($data['resultado']??self::erro('operacao_incerta_reconciliar'))+array('repetida'=>true);}
        if(!hash_equals($rev,(string)($e['revisao']??''))){return self::erro('conflito');}if(!is_ssl()||wp_parse_url(rest_url(),PHP_URL_SCHEME)!=='https'){return self::erro('https_obrigatorio');}
        if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}$lock=F3Base_Trava::adquirir('linkedin-assinaturas:'.F3Base_Linkedin_Integracoes::id(),60);if(!$lock){F3Base_Recuperacao::sair();return self::erro('assinaturas_ocupadas');}
        try{
            $data=array('hash'=>$hash,'acao'=>$action,'autor'=>get_current_user_id());if(!self::inserir(array('chave'=>$op,'tipo'=>'operacao','contexto'=>F3Base_Linkedin::contexto(),'estado'=>'iniciada'),$data)){return self::erro('operacao_nao_persistida');}
            if(in_array($action,array('ativar','desativar'),true)){$cfg['webhook']['ativo']=$action==='ativar';$save=F3Base_Linkedin_Integracoes::salvar($cfg,$rev,F3Base_Options::ORIGEM_MANUAL);if(empty($save['persisted'])){$r=self::erro('preferencia_nao_persistida');}else{$r=self::sincronizar($action);}}
            else{$r=self::sincronizar($action);}self::registrar_resultado('cadastro',$r);$data['resultado']=$r;if(!self::mudar($op,array('estado'=>!empty($r['ok'])?'concluida':'interrompida'),$data)){return self::erro('operacao_resultado_incerto');}return $r;
        }finally{F3Base_Linkedin_Cliente::prazo(0);F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function sincronizar(string $action): array {
        if(F3Base_Linkedin_Cliente::externo()){return F3Base_Linkedin_Assinaturas::sincronizar($action);}
        global $wpdb;$cfg=F3Base_Linkedin::config();$ctx=F3Base_Linkedin::contexto();$execution=F3Base_Linkedin_Integracoes::revisao_execucao();$active=$action!=='drenar'&&!empty($cfg['ativo'])&&!empty($cfg['webhook']['ativo']);$results=array();F3Base_Linkedin_Cliente::prazo(microtime(true)+40);
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE tipo='assinatura' AND contexto=%s AND estado<>'removida' ORDER BY criado_em LIMIT 200",self::tabela(),$ctx),ARRAY_A);
        foreach($rows as $row){if($active&&$row['contexto']===$ctx){continue;}$data=F3Base_Contato_Comunicacao::abrir($row['payload']);$id=$row['remoto_id'];
            if(!$id&&in_array($row['estado'],array('criando','incerto'),true)){$results[]=self::erro('criacao_incerta_sem_recibo');continue;}if(!$id){$found=self::localizar($data['pedido']??array());if(empty($found['ok'])){$results[]=$found;continue;}if(count($found['linhas'])>1){$results[]=self::erro('assinaturas_ambiguas');continue;}$id=(string)($found['linhas'][0]['id']??'');}
            if($id){$read=F3Base_Linkedin_Cliente::pedir('GET','leadNotifications/'.$id);if(empty($read['ok'])&&($read['http']??0)!==404){$results[]=$read;continue;}if(!empty($read['ok'])){$remote=$read['data'];$want=$data['pedido'];if(($remote['webhook']??'')!==$want['webhook']||($remote['owner']??null)!==$want['owner']||($remote['versionedForm']??$remote['versionedFormUrn']??'')!==$want['versionedForm']){$results[]=self::erro('assinatura_autoria_divergente');continue;}if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){$results[]=self::erro('revision_conflict');continue;}$del=F3Base_Linkedin_Cliente::pedir('DELETE','leadNotifications/'.$id);if(empty($del['ok'])&&($del['http']??0)!==404){$results[]=$del;continue;}}}
            $results[]=array('ok'=>self::mudar($row['chave'],array('estado'=>'removida')),'codigo'=>'assinatura_removida','id'=>$id);
        }
        if(!$active){return array('ok'=>!array_filter($results,static fn($r)=>empty($r['ok'])),'codigo'=>'webhook_desligado_consulta_periodica_preservada','resultados'=>$results);}
        if(empty($cfg['proprietario_confirmado'])||!F3Base_Segredos::abrir(F3Base_Linkedin_Api::SECRET)||!F3Base_Linkedin::formularios($cfg)){return self::erro('webhook_exige_formularios_proprietario_e_client_secret',array('resultados'=>$results));}
        foreach(F3Base_Linkedin::formularios($cfg) as $form){$f=F3Base_Linkedin::formulario($form,$cfg);if(empty($f['ok'])){$results[]=$f;continue;}$urn='urn:li:versionedLeadGenForm:(urn:li:leadGenForm:'.$form.','.$f['formulario']['versionId'].')';$wanted=array('webhook'=>self::url($ctx),'owner'=>array('sponsoredAccount'=>F3Base_Linkedin::dono($cfg)),'versionedForm'=>$urn,'leadType'=>'SPONSORED');$key=hash('sha256','subscription|'.$ctx.'|'.$urn);$row=self::linha($key);
            $found=self::localizar($wanted);if(empty($found['ok'])){$results[]=$found;continue;}if(count($found['linhas'])>1){$results[]=self::erro('assinaturas_ambiguas');continue;}$id=(string)($found['linhas'][0]['id']??'');
            if($row&&in_array($row['estado'],array('criando','incerto'),true)&&empty($row['remoto_id'])){$results[]=self::erro('criacao_incerta_sem_recibo');continue;}if(!$row&&$id){$results[]=self::erro('assinatura_sem_autoria_local');continue;}if($id&&$row&&!empty($row['remoto_id'])&&$row['remoto_id']!==$id){$results[]=self::erro('assinatura_autoria_divergente');continue;}
            if(!$row&&!self::inserir(array('chave'=>$key,'tipo'=>'assinatura','contexto'=>$ctx,'conta'=>$cfg['conta_id'],'formulario'=>$form,'estado'=>'preparada'),array('pedido'=>$wanted))){$results[]=self::erro('assinatura_checkpoint_falhou');continue;}
            if(!$id&&$row&&$row['estado']==='registrado'){self::mudar($key,array('estado'=>'ausencia_remota_confirmada'));$results[]=self::erro('assinatura_remota_ausente_ative_novamente');continue;}
            if(!$id){if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){$results[]=self::erro('revision_conflict');continue;}if(!self::mudar($key,array('estado'=>'criando','remoto_id'=>''))){$results[]=self::erro('assinatura_checkpoint_falhou');continue;}$r=F3Base_Linkedin_Cliente::pedir('POST','leadNotifications',$wanted);$id=(string)(($r['id']??'')?:($r['data']['id']??''));if(empty($r['ok'])||!preg_match('/^[0-9]+$/D',$id)){self::mudar($key,array('estado'=>!empty($r['incerto'])||!empty($r['ok'])?'incerto':'recusada'));$results[]=empty($r['ok'])?$r:self::erro('assinatura_sem_identificador');continue;}}
            if(!self::mudar($key,array('estado'=>'incerto','remoto_id'=>$id))){$results[]=self::erro('recibo_remoto_nao_persistido');continue;}if(F3Base_Linkedin_Integracoes::revisao_execucao()!==$execution){$results[]=self::erro('revision_conflict',array('id'=>$id));continue;}$confirmed=F3Base_Linkedin_Cliente::pedir('GET','leadNotifications/'.$id);$proof=$confirmed['data']??array();if(empty($confirmed['ok'])||($proof['webhook']??'')!==$wanted['webhook']||($proof['owner']??null)!==$wanted['owner']||($proof['versionedForm']??$proof['versionedFormUrn']??'')!==$wanted['versionedForm']){self::mudar($key,array('estado'=>'incerto','remoto_id'=>$id));$results[]=self::erro('assinatura_ainda_nao_confirmada',array('id'=>$id));continue;}
            $results[]=array('ok'=>self::mudar($key,array('estado'=>'registrado','remoto_id'=>$id)),'codigo'=>'assinatura_registrada','id'=>$id,'validacao_remota'=>'Aguardando prova; cadastro não comprova entrega.');
        }
        return array('ok'=>!array_filter($results,static fn($r)=>empty($r['ok'])),'resultados'=>$results,'diagnostico'=>self::diagnostico());
    }
    public static function diagnostico(): array {
        global $wpdb;$cfg=F3Base_Linkedin::config();$s=F3Base_Linkedin_Integracoes::estado()['webhook']??array();$exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like(self::tabela())))===self::tabela();if(!$exists){return array('desejado'=>!empty($cfg['webhook']['ativo']),'url'=>self::url(),'diagnostico_sql'=>'estrutura_pendente');}$rows=$wpdb->get_results($wpdb->prepare("SELECT tipo,estado,COUNT(*) quantidade,MIN(criado_em) primeira_em FROM %i WHERE contexto=%s AND tipo<>'operacao' GROUP BY tipo,estado",self::tabela(),F3Base_Linkedin::contexto()),ARRAY_A);$sql=!$wpdb->last_error;
        $subs=$wpdb->get_results($wpdb->prepare("SELECT chave,contexto,conta,formulario,remoto_id,estado,atualizado_em FROM %i WHERE contexto=%s AND tipo='assinatura' ORDER BY criado_em DESC LIMIT 100",self::tabela(),F3Base_Linkedin::contexto()),ARRAY_A);
        return array('desejado'=>!empty($cfg['webhook']['ativo']),'efetivo_local'=>!empty($cfg['ativo'])&&!empty($cfg['webhook']['ativo']),'url'=>self::url(),'revisao'=>F3Base_Options::revisao(F3Base_Linkedin::OPCAO),'client_secret'=>F3Base_Linkedin_Cliente::externo()?'gerido_pelo_plugin_linkedin':F3Base_Segredos::status(F3Base_Linkedin_Api::SECRET)['estado'],'assinaturas_sdk'=>F3Base_Linkedin_Integracoes::estado()['assinaturas_sdk']??array(),'estado_local'=>$s,'fila'=>$sql?$rows:null,'assinaturas'=>$subs?:array(),'diagnostico_sql'=>$sql?'consultado':'indisponivel','proxima_execucao'=>wp_next_scheduled(self::EVENTO)?:null,'validacao_remota'=>'Não inferida de desafios respondidos nem do silêncio. Última notificação autenticada é evidência de chegada.','latencia'=>'Webhook persiste e solicita executor próximo. WP-Cron/loopback podem atrasar; consulta periódica de uma hora continua como reconciliação.');
    }
    public static function manutencao(): array {
        if(!F3Base_Recuperacao::entrar()){return self::erro('core_em_recuperacao');}$lock=F3Base_Trava::adquirir('linkedin-assinaturas:'.F3Base_Linkedin_Integracoes::id(),60);if(!$lock){F3Base_Recuperacao::sair();return self::erro('assinaturas_ocupadas');}
        try{global $wpdb;$exists=$wpdb->get_var("SELECT chave FROM ".self::tabela()." WHERE tipo='assinatura' LIMIT 1");if(!$exists&&!F3Base_Linkedin_Cliente::externo()){return array('ok'=>true,'codigo'=>'nenhuma_assinatura_cadastrada');}$r=self::sincronizar('reconciliar');self::registrar_resultado('manutencao',$r);F3Base_Linkedin_Integracoes::atualizar_estado(static function($s)use($r){$s['webhook']['manutencao']=array('em'=>time(),'ok'=>!empty($r['ok']),'resultados'=>$r['resultados']??array());return $s;});F3Base_Fila::agendar(self::MANUTENCAO,time()+(!empty($r['ok'])?DAY_IN_SECONDS:HOUR_IN_SECONDS));return $r;}
        finally{F3Base_Linkedin_Cliente::prazo(0);F3Base_Trava::liberar($lock);F3Base_Recuperacao::sair();}
    }
    public static function todas(string $method): array {$out=array();foreach(F3Base_Linkedin_Integracoes::colecao() as $id=>$cfg){$out[$id]=F3Base_Linkedin_Integracoes::executar((string)$id,static fn()=>self::$method());}return array('integracoes'=>$out);}
    public static function iniciar(): void {
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,self::ROTA,array('methods'=>array('GET','POST'),'permission_callback'=>'__return_true','callback'=>array(__CLASS__,'receber'))));
        add_action(self::EVENTO,static fn()=>self::todas('processar'));add_action(self::MANUTENCAO,static fn()=>self::todas('manutencao'));add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),92);
        add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('anuncios-linkedin-webhook-configurar','Gerenciar assinaturas próprias LinkedIn; consulta e simulação por padrão',static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>self::configurar($e)),array('integracao_id'=>array('type'=>'string'),'acao'=>array('type'=>'string','enum'=>array('consultar','ativar','desativar','reconciliar')),'simular'=>array('type'=>'boolean','default'=>true),'revisao'=>array('type'=>'string'),'chave_operacao'=>array('type'=>'string','maxLength'=>128)),array(),false));
    }
    public static function conferir_agenda_1(): void {if(F3Base_Linkedin_Integracoes::ativas()&&!wp_next_scheduled(self::EVENTO)){F3Base_Fila::agendar(self::EVENTO,time()+60);}}
}
