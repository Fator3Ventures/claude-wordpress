<?php
/** One opening and recovery intent per mailbox incident, without message bodies. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Email_Alerta {
    const HOOK='f3base_email_site_saude';
    public static function iniciar(): void {
        add_action('f3base_zelador',array(__CLASS__,'conferir_agenda_1'),92);
        add_action(self::HOOK,static function(){try{self::observar();F3Base_Email_Site::continuacoes();}finally{F3Base_Fila::agendar(self::HOOK,time()+300);}});
    }
    public static function passageira(string $code,array $cfg): bool {
        if(preg_match('/autentic|senha|credencial|pasta|mailbox|login/i',$code)){return false;}
        return in_array($code,$cfg['imap_codigos_passageiros']??array('imap_resposta_incompleta','imap_transporte_indisponivel','imap_tempo_esgotado','imap_tls_interrompido','imap_dns_indisponivel','imap_prazo_excedido','imap_escrita_incompleta','imap_literal_incompleto'),true);
    }
    public static function observar(): void {
        if(!F3Base_Pipedrive_Fila::travar_linha('email-alerta')){return;}
        try{
            $health=F3Base_Email_Site::saude();if($health['estado']==='desligada'){return;}
            $state=get_option(F3Base_Email_Site_Config::STATE,array());$alarm=$state['alarme']??array();
            $code=(string)($health['codigo']??'');$error=$code!==''&&$code!=='sem_erro';
            $cfg=F3Base_Options::ler('f3base_avisos_tecnicos');$limit=max(60,(int)($cfg['atraso_minutos']??60))*MINUTE_IN_SECONDS;
            $complete=(int)($state['ultima_leitura_completa']??$state['ultimo_sucesso']??$state['ativado_em']??time());
            $transient=self::passageira($code,$cfg);
            $persistent=$transient&&((int)($code==='imap_resposta_incompleta'?($state['imap_incompletas_consecutivas']??0):($state['falhas']??0))>=(int)$cfg['imap_falhas_consecutivas']||time()-$complete>=(int)$cfg['imap_sem_leitura_minutos']*MINUTE_IN_SECONDS);
            $bad=($error&&(!$transient||$persistent))||(!$error&&time()-$complete>=$limit);
            // An incomplete successful page cannot close an incident before a full mailbox read.
            if(!$bad&&!empty($alarm['aberto'])){$newComplete=isset($alarm['sequencia_completa_ao_abrir'])?((int)($state['sequencia_leitura_completa']??0)>(int)$alarm['sequencia_completa_ao_abrir']):($complete>(int)($alarm['inicio']??0));if(!$newComplete){return;}}
            if($bad&&!empty($alarm['aberto'])){return;}if(!$bad&&empty($alarm['aberto'])){return;}
            $closing=!$bad;
            if($closing&&empty($alarm['atencao_aceita'])){$alarm['aberto']=false;$alarm['encerrado_sem_aviso_em']=time();F3Base_Email_Site::estado(array('alarme'=>$alarm));return;}
            $title=$closing?'Captação de e-mail recuperada':'Captação de e-mail requer atenção';$type=$closing?'recuperacao':'abertura';
            $alarm=$closing?array_replace($alarm,array('aberto'=>false)):array('aberto'=>true,'incidente'=>wp_generate_uuid4(),'inicio'=>time(),'atencao_aceita'=>false,'sequencia_completa_ao_abrir'=>(int)($state['sequencia_leitura_completa']??0),'politica_revisao'=>F3Base_Options::revisao('f3base_avisos_tecnicos'),'limites'=>array('falhas'=>$cfg['imap_falhas_consecutivas'],'minutos'=>$cfg['imap_sem_leitura_minutos']));
            $alarm[$type]=array('estado'=>'reservado','em'=>time());F3Base_Email_Site::estado(array('alarme'=>$alarm));
            $test=!empty(F3Base_Email_Site::cfg()['homologacao']);
            $text=$title.' — '.get_bloginfo('name')."\nEstado: ".$health['estado']."\nCódigo: ".($error?$code:'leitura_completa_atrasada')."\n".F3Base_Configuracoes_Hub::url('conexoes','f3base_email_site');
            $result=F3Base_Alertas_Operacionais::enviar($title,$text,$test);
            if(!$closing){$alarm['atencao_aceita']=!empty($result['ok'])&&($result['estado']??'')!=='suprimido_teste';}
            $alarm[$type]=$result+array('em'=>time());F3Base_Email_Site::estado(array('alarme'=>$alarm));
        }finally{F3Base_Pipedrive_Fila::liberar_linha('email-alerta');}
    }
    public static function conferir_agenda_1(): void {if(!wp_next_scheduled(self::HOOK)){F3Base_Fila::agendar(self::HOOK,time()+300);}}
}
