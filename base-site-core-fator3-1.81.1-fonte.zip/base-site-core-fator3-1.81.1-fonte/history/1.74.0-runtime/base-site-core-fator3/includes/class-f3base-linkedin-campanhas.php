<?php
/** Enriquecimento de campanha: somente leitura remota e preenchimento local vazio. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Linkedin_Campanhas {
    public const EVENTO = 'f3base_linkedin_campanhas';

    private static function resultado(string $code, bool $ok = true): array {
        return array('ok'=>$ok, 'codigo'=>$code);
    }
    private static function politica(array $cfg): array {
        $p = $cfg['campanhas_retry'] ?? array();
        return array('max_tentativas'=>max(1,min(10,(int)($p['max_tentativas']??3))),
            'intervalo_segundos'=>max(60,min(86400,(int)($p['intervalo_segundos']??300))));
    }
    /** A falha de persistência impede o avanço do cursor; replay usa o mesmo recibo. */
    public static function registrar(array $p, string $record): bool {
        if (!F3Base_Linkedin_Cliente::externo() || $p['campaign_name']!=='' || $p['campaign_id']==='') { return true; }
        if (!F3Base_Linkedin_Webhook::instalar()) { return false; }
        global $wpdb;
        $cfg=F3Base_Linkedin::config(); $ctx=F3Base_Linkedin::contexto();
        $data=array('integracao_id'=>F3Base_Linkedin_Integracoes::id(),'connection_id'=>$cfg['connection_id'],
            'record_id'=>$record,'campaign_id'=>$p['campaign_id'],'codigo'=>'campanha_aguarda_consulta',
            'config_revisao'=>F3Base_Linkedin_Integracoes::revisao_execucao());
        $key=hash('sha256','campanha|'.$ctx.'|'.$cfg['connection_id'].'|'.$cfg['conta_id'].'|'.$p['form_id'].'|'.$p['lead_id'].'|'.$p['_linkedin']['submitted_at_ms']);
        $cipher=F3Base_Contato_Comunicacao::cifrar($data);
        if ($cipher==='') { return false; }
        $ok=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (chave,tipo,contexto,conta,formulario,resposta,ocorrido_ms,estado,payload,proxima,criado_em,atualizado_em) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%d,%d,%d)',
            F3Base_Linkedin_Webhook::tabela(),$key,'campanha',$ctx,$cfg['conta_id'],$p['form_id'],$p['lead_id'],$p['_linkedin']['submitted_at_ms'],'pendente',$cipher,time(),time(),time()));
        if ($ok===false) { return false; }
        F3Base_Fila::agendar(self::EVENTO,time()+5);
        return true;
    }
    private static function salvar(array $row,array $data,string $state,int $next=0): bool {
        global $wpdb; $cipher=F3Base_Contato_Comunicacao::cifrar($data);
        return $cipher!=='' && false!==$wpdb->update(F3Base_Linkedin_Webhook::tabela(),
            array('payload'=>$cipher,'estado'=>$state,'proxima'=>$next,'tentativas'=>$row['tentativas'],'atualizado_em'=>time()),array('chave'=>$row['chave']));
    }
    private static function elegivel(array $row,array $data,array $cfg): bool {
        return !empty($cfg['ativo']) && !empty($cfg['proprietario_confirmado']) && F3Base_Linkedin_Integracoes::liberada()
            && ($cfg['cliente']??'')==='linkedin_plugin' && ($data['integracao_id']??'')===F3Base_Linkedin_Integracoes::id()
            && ($data['connection_id']??'')===$cfg['connection_id'] && $row['contexto']===F3Base_Linkedin::contexto()
            && $row['conta']===$cfg['conta_id'] && in_array($row['formulario'],F3Base_Linkedin::formularios($cfg),true);
    }
    /** Não chama ingerir(), CRM, avisos, conversões ou hooks comerciais. */
    private static function preencher(array $row,array $data,string $name,string $source): array {
        global $wpdb;
        $receipt=hash('sha256','linkedin|'.$row['conta'].'|'.$row['formulario'].'|'.$row['resposta'].'|'.$row['ocorrido_ms']);
        if (false===$wpdb->query('START TRANSACTION')) { return self::resultado('transacao_indisponivel',false); }
        try {
            $proof=$wpdb->get_row($wpdb->prepare('SELECT record_id,eliminado FROM %i WHERE chave=%s FOR UPDATE',F3Base_Anuncios::tabela(),$receipt),ARRAY_A);
            if (!$proof || $proof['record_id']!==$data['record_id'] || $proof['eliminado']) { $wpdb->query('ROLLBACK'); return self::resultado('campanha_registro_indisponivel'); }
            // A trava da linha protege também contra edição e eliminação simultâneas.
            $raw=$wpdb->get_row($wpdb->prepare('SELECT * FROM %i WHERE record_id=%s FOR UPDATE',F3Base_Leads_Repositorio::tabela(),$data['record_id']),ARRAY_A);
            if (!$raw || $raw['eliminacao_pendente'] || $raw['lixeira']) { $wpdb->query('ROLLBACK'); return self::resultado('campanha_registro_indisponivel'); }
            $d=json_decode($raw['dados'],true); $native=$d['origem_nativa']??array();
            $expected=array('origem'=>'linkedin','conta_id'=>$row['conta'],'formulario_id'=>$row['formulario'],'lead_id'=>$row['resposta'],
                'submitted_at_ms'=>$row['ocorrido_ms'],'integracao_id'=>$data['integracao_id'],'connection_id'=>$data['connection_id'],'cliente'=>'linkedin_plugin','campanha_id'=>$data['campaign_id']);
            foreach ($expected as $key=>$value) { if ((string)($native[$key]??'')!==(string)$value) { $wpdb->query('ROLLBACK'); return self::resultado('campanha_identidade_divergente',false); } }
            if (($d['atribuicao']['utm_campaign']??'')!=='') { $wpdb->query('ROLLBACK'); return self::resultado('campanha_nome_preservado'); }
            if (($d['atribuicao']['utm_id']??'')!==$data['campaign_id']) { $wpdb->query('ROLLBACK'); return self::resultado('campanha_identidade_divergente',false); }
            $d['atribuicao']['utm_campaign']=$name;
            $d['origem_nativa']['campanha_enriquecimento']=array('fonte'=>$source,'em'=>time(),'config_revisao'=>$data['config_revisao'],
                'credential_revision'=>$data['credential_revision']??null,'grant_revision'=>$data['grant_revision']??null);
            $d['enriquecimento_versao']=(int)($d['enriquecimento_versao']??0)+1;
            if (1!==$wpdb->update(F3Base_Leads_Repositorio::tabela(),array('dados'=>wp_json_encode($d),'revisao'=>(int)$raw['revisao']+1,'atualizado_em'=>gmdate('Y-m-d H:i:s')),
                array('record_id'=>$data['record_id'],'revisao'=>$raw['revisao']))) { throw new RuntimeException('campanha_persistencia_pendente'); }
            if (false===$wpdb->query('COMMIT')) { throw new RuntimeException('campanha_commit_pendente'); }
            return self::resultado('campanha_nome_preenchido');
        } catch (Throwable $e) { $wpdb->query('ROLLBACK'); return self::resultado('campanha_persistencia_pendente',false); }
    }
    private static function processar(array $row): array {
        $data=F3Base_Contato_Comunicacao::abrir($row['payload']); $cfg=F3Base_Linkedin::config();
        if (!is_array($data)) { return self::resultado('campanha_diario_ilegivel',false); }
        if (!self::elegivel($row,$data,$cfg)) {
            $data['codigo']='campanha_fora_escopo';
            return self::resultado(self::salvar($row,$data,'revisao')?$data['codigo']:'campanha_checkpoint_falhou',false);
        }
        $execution=F3Base_Linkedin_Integracoes::revisao_execucao(); $data['config_revisao']=$execution;
        $policy=self::politica($cfg); $data['politica']=$policy;
        if ((int)$row['tentativas'] >= $policy['max_tentativas']) { $data['codigo']='campanha_tentativas_esgotadas'; return self::resultado(self::salvar($row,$data,'revisao')?$data['codigo']:'campanha_checkpoint_falhou',false); }
        $row['tentativas']=(int)$row['tentativas']+1;
        // Reserva durável antes da leitura: encerramento abrupto não cria um laço infinito.
        if (!self::salvar($row,$data,'pendente',time()+$policy['intervalo_segundos'])) { return self::resultado('campanha_checkpoint_falhou',false); }
        $mapped=$cfg['mapeamento']['campanhas'][$data['campaign_id']]??'';
        $name=is_array($mapped)?($mapped['nome']??''):$mapped; $source='mapeamento'; $retry=false; $after=0;
        if (!is_string($name) || trim($name)==='') {
            $status=F3Base_Linkedin_Cliente::chamar('effective_status');
            $binding=array_intersect_key($status['data']??array(),array_flip(array('credential_revision','grant_revision')));
            $r=empty($status['ok'])?$status:F3Base_Linkedin_Cliente::chamar('resolve_campaign',$binding+array('form_id'=>$row['formulario'],'response_id'=>$row['resposta']));
            $data=array_replace($data,$binding); $campaign=$r['data']['campaign']??array(); $identity=$r['data']['response_identity']??array();
            $data['codigo']=$r['codigo']??'campanha_resposta_invalida';
            $data['status']=$campaign['status']??($r['detalhes']['campaign_status']??'indisponivel');
            $retry=!empty($r['detalhes']['retryable']); $after=max(0,(int)($r['retry_after']??0)); $name='';
            if (!empty($r['ok'])) {
                $valid=($campaign['contract']??'')==='linkedin-lead-campaign/1.0.0' && ($campaign['account_id']??'')===$row['conta']
                    && ($campaign['id']??'')===$data['campaign_id'] && ($identity['source']??'')==='linkedin'
                    && ($identity['account_id']??'')===$row['conta'] && ($identity['form_id']??'')===$row['formulario']
                    && ($identity['response_id']??'')===$row['resposta'] && (string)($identity['submitted_at_ms']??'')===(string)$row['ocorrido_ms']
                    && count($binding)===2 && array_intersect_key($r['data'],$binding)===$binding;
                $data['codigo']=$valid?($campaign['code']??'campanha_resposta_invalida'):'campanha_identidade_divergente';
                if ($valid && ($campaign['status']??'')==='available' && is_string($campaign['name']??null)) { $name=$campaign['name']; $source=$campaign['source']; }
            }
            $fresh=F3Base_Linkedin_Cliente::chamar('effective_status');
            if (empty($fresh['ok']) || count($binding)!==2 || array_intersect_key($fresh['data'],$binding)!==$binding) { $name=''; $data['codigo']='revision_conflict'; $retry=false; }
        }
        if ($execution!==F3Base_Linkedin_Integracoes::revisao_execucao()) { $name=''; $data['codigo']='revision_conflict'; $retry=false; }
        $name=sanitize_text_field(trim((string)$name));
        if ($name!=='' && strlen($name)<=1024) {
            $r=self::preencher($row,$data,$name,$source); $data['codigo']=$r['codigo'];
            $done=!empty($r['ok']); $retry=!$done && $r['codigo']==='campanha_persistencia_pendente';
        } else { $done=false; if ($name!=='') { $data['codigo']='campanha_nome_invalido'; } }
        $next=$retry && $row['tentativas']<$policy['max_tentativas']?time()+max($after,$policy['intervalo_segundos']):0;
        $state=$done?'processado':($next?'pendente':'revisao');
        if (!self::salvar($row,$data,$state,$next)) { return self::resultado('campanha_checkpoint_falhou',false); }
        return self::resultado($data['codigo'],$done)+array('estado'=>$state,'tentativas'=>$row['tentativas'],'proxima'=>$next);
    }
    /** Uma consulta por execução; contrato do produtor limita a leitura a 25 segundos. */
    public static function executar(): array {
        if (!F3Base_Recuperacao::entrar()) { return self::resultado('core_em_recuperacao',false); }
        $lock=F3Base_Trava::adquirir('linkedin-campanhas',45);
        if (!$lock) { F3Base_Recuperacao::sair(); return self::resultado('campanha_ocupada'); }
        global $wpdb;
        try {
            if (F3Base_Execucoes::restante_ms(500)<27000) { return self::resultado('campanha_aguarda_orcamento'); }
            $out=self::resultado('campanha_fila_vazia');
            // Rodízio por antiguidade entre integrações, sem consultar contas desativadas.
            $contexts=array();
            foreach (F3Base_Linkedin_Integracoes::colecao() as $id=>$cfg) {
                if (!empty($cfg['ativo']) && ($cfg['cliente']??'')==='linkedin_plugin') {
                    $contexts[]=F3Base_Linkedin_Integracoes::executar((string)$id,static fn()=>F3Base_Linkedin::contexto());
                }
            }
            if (!$contexts) { return $out; }
            $slots=implode(',',array_fill(0,count($contexts),'%s'));
            $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM %i WHERE tipo='campanha' AND estado='pendente' AND proxima<=%d AND contexto IN ($slots) ORDER BY proxima,criado_em,chave LIMIT 1",F3Base_Linkedin_Webhook::tabela(),time(),...$contexts),ARRAY_A);
            foreach ($rows??array() as $row) {
                $data=F3Base_Contato_Comunicacao::abrir($row['payload']); $id=$data['integracao_id']??'';
                $cfg=F3Base_Linkedin_Integracoes::colecao()[$id]??array();
                if (!$cfg || empty($cfg['ativo'])) { continue; }
                $out=F3Base_Linkedin_Integracoes::executar($id,static fn()=>self::processar($row)); break;
            }
            return $out;
        } finally { F3Base_Trava::liberar($lock); F3Base_Recuperacao::sair(); self::agendar(); }
    }
    public static function agendar(): void {
        global $wpdb;
        if (!F3Base_Linkedin_Integracoes::ativas()) { return; }
        $next=$wpdb->get_var($wpdb->prepare("SELECT MIN(proxima) FROM %i WHERE tipo='campanha' AND estado='pendente'",F3Base_Linkedin_Webhook::tabela()));
        if ($next!==null) { F3Base_Fila::agendar(self::EVENTO,max(time()+60,(int)$next)); }
    }
    public static function diagnostico(): array {
        global $wpdb;
        $rows=$wpdb->get_results($wpdb->prepare("SELECT chave,estado,tentativas,proxima,payload FROM %i WHERE tipo='campanha' AND contexto=%s ORDER BY atualizado_em DESC LIMIT 50",F3Base_Linkedin_Webhook::tabela(),F3Base_Linkedin::contexto()),ARRAY_A);
        $out=array(); foreach ($rows??array() as $row) { $d=F3Base_Contato_Comunicacao::abrir($row['payload']); unset($row['payload']); $out[]=$row+array('codigo'=>$d['codigo']??'diario_ilegivel'); }
        return array('ultimas'=>$out,'limite'=>50,'politica'=>self::politica(F3Base_Linkedin::config()),'proxima_execucao'=>wp_next_scheduled(self::EVENTO)?:null,
            'recuperacao'=>'f3base/linkedin-campanha-reabrir; simular, reler revisão e informar motivo. Não reenvia ao CRM.');
    }
    public static function reabrir(array $e): array {
        if (!current_user_can('manage_options')) { return self::resultado('sem_permissao',false); }
        global $wpdb;
        $lock=F3Base_Trava::adquirir('linkedin-campanhas',45); if (!$lock) { return self::resultado('campanha_ocupada',false); }
        try {
            $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM %i WHERE chave=%s AND tipo='campanha' AND contexto=%s",F3Base_Linkedin_Webhook::tabela(),$e['chave']??'',F3Base_Linkedin::contexto()),ARRAY_A);
            if (!$row) { return self::resultado('campanha_ausente',false); }
            $rev=hash('sha256',wp_json_encode($row).'|'.F3Base_Linkedin_Integracoes::revisao_execucao());
            if (($e['simular']??true)!==false) { return self::resultado('campanha_previa')+array('simular'=>true,'revisao'=>$rev,'estado'=>$row['estado'],'efeito'=>'Nova consulta de metadados, sujeita à concessão atual; preserva nome já preenchido e não reenvia o contato.'); }
            $reason=sanitize_text_field((string)($e['motivo']??''));
            if (!hash_equals($rev,(string)($e['revisao']??''))) { return self::resultado('revision_conflict',false); }
            if (strlen($reason)<5 || strlen($reason)>500) { return self::resultado('motivo_obrigatorio',false); }
            $data=F3Base_Contato_Comunicacao::abrir($row['payload']);
            if (!is_array($data) || !self::elegivel($row,$data,F3Base_Linkedin::config())) { return self::resultado('campanha_fora_escopo',false); }
            $data['reaberturas']=(int)($data['reaberturas']??0)+1;
            $data['ultima_reabertura']=array('motivo'=>$reason,'usuario'=>get_current_user_id(),'em'=>time(),'revisao'=>$rev,'tentativas_anteriores'=>$row['tentativas']);
            $data['codigo']='campanha_reaberta'; $row['tentativas']=0;
            if (!self::salvar($row,$data,'pendente',time())) { return self::resultado('campanha_checkpoint_falhou',false); }
            self::agendar(); return self::resultado('campanha_reaberta')+array('persisted'=>true,'risco'=>'O nome pode continuar indisponível; nenhuma permissão do fornecedor é ampliada.');
        } finally { F3Base_Trava::liberar($lock); }
    }
    public static function iniciar(): void {
        add_action(self::EVENTO,array(__CLASS__,'executar'));
        add_action('f3base_zelador',array(__CLASS__,'agendar'),92);
        add_action('wp_abilities_api_init',static function(){ F3Base_Servicos::ability('linkedin-campanha-reabrir','Reabrir consulta de campanha com revisão, prévia e motivo; sem reenvio comercial',
            static fn($e)=>F3Base_Linkedin_Integracoes::executar($e['integracao_id']??null,static fn()=>self::reabrir($e)),
            array('integracao_id'=>array('type'=>'string'),'chave'=>array('type'=>'string','pattern'=>'^[a-f0-9]{64}$'),'simular'=>array('type'=>'boolean','default'=>true),
                'revisao'=>array('type'=>'string'),'motivo'=>array('type'=>'string','maxLength'=>500)),array('integracao_id','chave','simular'),false); });
    }
}
