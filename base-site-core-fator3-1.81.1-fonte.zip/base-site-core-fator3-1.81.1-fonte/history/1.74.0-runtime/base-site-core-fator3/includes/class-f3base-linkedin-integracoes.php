<?php
/** Canonical configuration and execution scope for independent LinkedIn integrations. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Linkedin_Integracoes {
    private static ?string $escopo=null;
    private static bool $migrando=false;
    private static bool $transicionando=false;
    private static ?array $previa=null;
    public static function padrao(): array {return array('rotulo'=>'Principal','uuid'=>'','cliente'=>'core','connection_id'=>'principal','ativo'=>false,'conta_id'=>'','formularios'=>array(),'proprietario_confirmado'=>false,'client_id'=>'','aplicativo_id'=>'','mapeamento'=>array(),'webhook'=>array('ativo'=>false));}
    public static function definicao(): array {
        $string=array('type'=>'string','maxLength'=>100);$bool=array('type'=>'boolean');$props=array();
        foreach(self::padrao() as $k=>$v){$props[$k]=is_bool($v)?$bool:$string;}
        $props['cliente']=array('type'=>'string','enum'=>array('core','linkedin_plugin'));
        $props['formularios_modo']=array('type'=>'string','enum'=>array('selecionados','todos_conta_autorizada'));
        $props['formularios']=array('type'=>'array','maxItems'=>100,'items'=>$string);$props['mapeamento']=array('type'=>'object','additionalProperties'=>true);$props['webhook']=array('type'=>'object','additionalProperties'=>false,'properties'=>array('ativo'=>$bool));
        $props['campanhas_retry']=array('type'=>'object','additionalProperties'=>false,'properties'=>array('max_tentativas'=>array('type'=>'integer','minimum'=>1,'maximum'=>10),'intervalo_segundos'=>array('type'=>'integer','minimum'=>60,'maximum'=>86400)));
        $schema=array('type'=>'object','additionalProperties'=>false,'required'=>array_keys(self::padrao()),'properties'=>$props);
        return array('titulo'=>'LinkedIn — integrações de formulários','padrao'=>array('integracoes'=>array()),'props'=>array('integracoes'=>array('type'=>'object','maxProperties'=>20,'additionalProperties'=>$schema)));
    }
    public static function colecao(): array {$v=F3Base_Options::fotografia_bruta(F3Base_Linkedin::OPCAO)['valor'];return is_array($v)&&isset($v['integracoes'])?$v['integracoes']:array('principal'=>array_replace(self::padrao(),is_array($v)?$v:array()));}
    public static function id(?string $id=null): string {
        $all=self::colecao();$id=$id??self::$escopo;
        if($id===null){if(count($all)!==1){throw new RuntimeException('integracao_id_obrigatoria');}$id=(string)array_key_first($all);}
        if(!isset($all[$id])){throw new RuntimeException('integracao_ausente');}return $id;
    }
    public static function tem_escopo(): bool {return self::$escopo!==null;}
    public static function config(?string $id=null): array {return self::$previa??self::colecao()[self::id($id)];}
    public static function executar(?string $id,callable $fn) {$previous=self::$escopo;try{self::$escopo=self::id($id);return $fn();}catch(RuntimeException $e){return array('ok'=>false,'codigo'=>$e->getMessage());}finally{self::$escopo=$previous;}}
    public static function todas(string $method): array {$out=array();foreach(self::colecao() as $id=>$cfg){if(empty($cfg['ativo'])){continue;}$out[$id]=self::executar((string)$id,static fn()=>F3Base_Linkedin::$method());}return self::resumir($out)+array('integracoes'=>$out);}
    public static function resumir(array $results): array {
        $failed=array_filter($results,static fn($r)=>empty($r['ok']));$occurrences=array_sum(array_column($results,'ocorrencias'));$included=array_sum(array_column($results,'formularios_incluidos'));
        return array('ok'=>!$failed,'codigo'=>$failed?(reset($failed)['codigo']??'coleta_parcial'):($occurrences?'conteudo_conflitante_registrado':'coleta_concluida'),'ocorrencias'=>$occurrences,'formularios_incluidos'=>$included);
    }
    public static function ativas(): bool {return (bool)array_filter(self::colecao(),static fn($c)=>!empty($c['ativo']));}
    public static function estado(): array {$s=get_option(F3Base_Linkedin::ESTADO,array());return isset($s['integracoes'])?($s['integracoes'][self::id()]??array()):$s;}
    public static function atualizar_estado(callable $fn): array {
        $id=self::id();return F3Base_Options::atualizar_estado(F3Base_Linkedin::ESTADO,static function($s)use($fn,$id){$all=isset($s['integracoes']);$old=$all?($s['integracoes'][$id]??array()):$s;$new=$fn($old);if($new===null){return null;}if(!$all){return $new;}$s['integracoes'][$id]=$new;return $s;});
    }
    public static function contexto(): string {$s=self::estado();return (string)($s['contexto_callback']??hash('sha256',home_url().'|'.F3Base_Options::revisao(F3Base_Linkedin::OPCAO).'|'.F3Base_Options::revisao(F3Base_Linkedin_Api::TOKEN).'|'.F3Base_Options::revisao(F3Base_Linkedin_Api::SECRET)));}
    public static function revisao_execucao(): string {$c=self::config();return hash('sha256',wp_json_encode($c).'|'.self::contexto().'|'.(self::estado()['geracao']??0).'|'.(($c['cliente']??'core')==='core'?F3Base_Options::revisao(F3Base_Linkedin_Api::TOKEN).'|'.F3Base_Options::revisao(F3Base_Linkedin_Api::SECRET):''));}
    public static function liberada(): bool {$t=self::estado()['transicao']??array();return empty($t)||in_array($t['fase']??'',array('concluida','cancelada'),true);}
    public static function cursores_publicos(array $s): array {foreach($s as &$v){if(is_array($v)){$v=self::cursores_publicos($v);}}unset($v);foreach(array('cursor','cursor_opaco','next_cursor') as $k){if(isset($s[$k])){$s[$k]='[continuação protegida]';}}return $s;}
    public static function consumer(?array $cfg=null): string {return 'site-core-li-'.str_replace('-','',($cfg??self::config())['uuid']);}
    public static function validar(array $v): string {
        if(!isset($v['integracoes'])||!is_array($v['integracoes'])){return 'Use integracoes e uma ID explícita; contrato de configuração 8.0.0.';}$seen=array();$old=self::colecao();
        foreach($v['integracoes'] as $id=>$cfg){
            if(!preg_match('/^[a-z][a-z0-9_-]{0,39}$/D',(string)$id)||!is_array($cfg)){return 'ID de integração inválida.';}
            $err=F3Base_Linkedin_Admin::validar($cfg);if($err){return $err;}
            if(!preg_match('/^[a-f0-9-]{36}$/D',$cfg['uuid']??'')){return 'UUID estável obrigatório.';}
            if(($cfg['cliente']??'')==='linkedin_plugin'&&empty($cfg['connection_id'])){return 'Selecione a conexão do plugin LinkedIn.';}
            if(($cfg['cliente']??'')==='core'&&($cfg['connection_id']??'')!=='principal'){return 'Use a referência principal do cofre Core.';}
            if(isset($old[$id])&&!self::$migrando){
                if(($old[$id]['uuid']??'')!==$cfg['uuid']){return 'A identidade da integração é imutável.';}
                foreach(array('cliente','connection_id','conta_id','formularios','formularios_modo') as $key){if(($old[$id][$key]??null)!==($cfg[$key]??null)&&!self::$transicionando){return 'Use a prévia e a transição para alterar cliente, conexão, conta ou formulários.';}}
            }
            if(!empty($cfg['ativo'])){foreach($v['integracoes'] as $otherId=>$other){if($otherId!==$id&&!empty($other['ativo'])&&($other['conta_id']??'')===$cfg['conta_id']&&(F3Base_Linkedin_Descoberta::ativa($cfg)||F3Base_Linkedin_Descoberta::ativa($other))){return 'A seleção de todos os formulários exige uma única integração ativa para esta conta.';}}foreach(F3Base_Linkedin::formularios($cfg) as $form){$key=$cfg['conta_id'].'|'.$form;if(isset($seen[$key])){return 'Conta e formulário já ativos em '.$seen[$key].'.';}$seen[$key]=$id;}}
        }
        foreach($old as $id=>$cfg){if(!isset($v['integracoes'][$id])&&($cfg['uuid']??'')!==''){return 'Desative e drene a integração; exclusão do histórico não é permitida.';}}
        return '';
    }
    public static function prever(array $cfg,callable $fn) {$old=self::$previa;self::$previa=$cfg;try{return $fn();}finally{self::$previa=$old;}}
    public static function permitir_transicao(callable $fn) {self::$transicionando=true;try{return $fn();}finally{self::$transicionando=false;}}
    public static function salvar(array $cfg,string $revision,string $origin): array {$all=self::colecao();$all[self::id()]=$cfg;return F3Base_Options::gravar(F3Base_Linkedin::OPCAO,array('integracoes'=>$all),$origin,$revision);}
    public static function migrar(): bool {
        $f=F3Base_Options::fotografia_bruta(F3Base_Linkedin::OPCAO);if($f['erro']){return false;}
        $s=F3Base_Options::fotografia_bruta(F3Base_Linkedin::ESTADO);if($s['erro']){return false;}
        if(isset($f['valor']['integracoes'])&&isset($s['valor']['integracoes'])){return true;}
        self::$migrando=true;
        try{
            $legacy=is_array($f['valor'])?$f['valor']:array();$journal=$s['valor']['migracao_1340']??null;
            if(!$journal){$journal=array('uuid'=>wp_generate_uuid4(),'contexto'=>hash('sha256',home_url().'|'.$f['revisao'].'|'.F3Base_Options::revisao(F3Base_Linkedin_Api::TOKEN).'|'.F3Base_Options::revisao(F3Base_Linkedin_Api::SECRET)),'revisao_antes'=>$f['revisao'],'fase'=>'preparada','em'=>time());$r=F3Base_Options::atualizar_estado(F3Base_Linkedin::ESTADO,static function($v)use($journal){$v['migracao_1340']=$journal;return $v;});if(empty($r['persisted'])){return false;}}
            if(!isset($legacy['integracoes'])||$legacy['integracoes']===array()){
                $cfg=array_replace(self::padrao(),isset($legacy['integracoes'])?array():$legacy,array('uuid'=>$journal['uuid'],'cliente'=>'core','connection_id'=>'principal'));
                $new=array('integracoes'=>array('principal'=>$cfg));
                if(!$f['existe']){$r=F3Base_Options::gravar(F3Base_Linkedin::OPCAO,$new,F3Base_Options::ORIGEM_PADRAO,$f['revisao']);}
                else{$r=F3Base_Options::complementar_padrao(F3Base_Linkedin::OPCAO,$new,'1.34.0',static fn()=>$new);}
                if(empty($r['persisted'])||isset($r['ok'])&&!$r['ok']){return false;}
            }
            $canonical=F3Base_Options::fotografia_bruta(F3Base_Linkedin::OPCAO)['valor'];$finish=F3Base_Options::complementar_padrao(F3Base_Linkedin::OPCAO,$canonical,'1.34.0',static fn($v)=>$v);if(empty($finish['ok'])){return false;}
            $r=F3Base_Options::atualizar_estado(F3Base_Linkedin::ESTADO,static function($old)use($journal){if(isset($old['integracoes'])){return $old;}$j=$old['migracao_1340'];unset($old['migracao_1340']);$old['contexto_callback']=$journal['contexto'];$old['aquisicao']=get_option('f3base_anuncios_estado',array())['linkedin']??array();$old['geracao']=1;$j['fase']='concluida';return array('integracoes'=>array('principal'=>$old),'migracao_1340'=>$j);});return !empty($r['persisted']);
        }finally{self::$migrando=false;}
    }
    public static function alterada(string $name,$before,$after): void {
        if(self::$migrando||($name!==F3Base_Linkedin::OPCAO&&F3Base_Credenciais::preserva($name))){return;}$all=self::colecao();
        foreach($all as $id=>$cfg){self::executar((string)$id,static function()use($name,$before,$cfg,$id){
            $old=$before['integracoes'][$id]??array();if($name!==F3Base_Linkedin::OPCAO&&($cfg['cliente']??'core')!=='core'){return;}$changed=$name!==F3Base_Linkedin::OPCAO||$old!==$cfg;if(!$changed){return;}
            self::atualizar_estado(static function($s)use($cfg,$old,$name){
                if(empty($s['contexto_callback'])){$s['contexto_callback']=hash('sha256',wp_generate_uuid4());}$s['geracao']=(int)($s['geracao']??0)+1;
                if($name===F3Base_Linkedin::OPCAO&&!empty($cfg['ativo'])&&(empty($old['ativo'])||($old['conta_id']??'')!==$cfg['conta_id'])){$s['aquisicao']=array('ativado_em'=>time(),'conta_id'=>$cfg['conta_id']);}
                foreach(F3Base_Linkedin::formularios($cfg) as $form){if(!isset($s['cursores'][$form])){$s['cursores'][$form]=array('desde'=>time(),'ate'=>time(),'inicio'=>0,'proxima'=>time());}}
                return $s;
            });
            if(!empty($cfg['ativo'])){F3Base_Fila::agendar(F3Base_Linkedin::EVENTO,time()+5);}
        });}
    }
    public static function por_contexto(string $ctx): ?string {$s=get_option(F3Base_Linkedin::ESTADO,array());foreach($s['integracoes']??array() as $id=>$state){if(hash_equals((string)($state['contexto_callback']??''),$ctx)){return (string)$id;}}return null;}
}
