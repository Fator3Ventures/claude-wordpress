<?php
/** Gerado por build/bootstrap-methods.php. Somente registro; handlers carregados no hook correspondente. */
if(!defined('ABSPATH')){exit;}
return [
'F3Base_Analise'=>static function():void{

        add_action('rest_api_init',static function(){register_rest_route(F3BASE_REST_NAMESPACE,'/analise',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Analise','receber_seguro')));});
        add_action('wp_enqueue_scripts',array('F3Base_Analise','enfileirar'),30);
        add_filter('render_block',array('F3Base_Analise','inspecionar_recursos'),30);
        add_filter('the_content',array('F3Base_Analise','inspecionar_recursos'),30);
        add_action('f3base_leads_resumo',array('F3Base_Analise','reter'));
    
},
'F3Base_Artigos'=>static function():void{

        add_action('init',static function(){
            wp_register_script('f3base-artigos-editor',F3BASE_PLUGIN_URL.'assets/f3base-artigos-editor.js',array('wp-blocks','wp-element','wp-block-editor','wp-components','wp-server-side-render'),F3BASE_PLUGIN_VERSAO,true);
            register_block_type('f3base/artigo-indice',array('api_version'=>3,'editor_script'=>'f3base-artigos-editor','attributes'=>array('titulo'=>array('type'=>'string','default'=>'Neste artigo'),'aberto'=>array('type'=>'boolean','default'=>true)),'render_callback'=>array('F3Base_Artigos','indice')));
            register_block_type('f3base/artigo-compartilhar',array('api_version'=>3,'editor_script'=>'f3base-artigos-editor','render_callback'=>array('F3Base_Artigos','compartilhar')));
        });
        add_filter('the_content',array('F3Base_Artigos','marcar'),12);
        add_filter('script_loader_tag',static function($html,$handle){if(!str_starts_with($handle,'f3base')){return $html;}if(class_exists('WP_HTML_Tag_Processor')){$p=new WP_HTML_Tag_Processor($html);while($p->next_tag('SCRIPT')){$p->set_attribute('data-no-optimize','1');}return $p->get_updated_html();}return $html;},20,2);
        add_filter('wp_inline_script_attributes',static function($attrs){if(str_starts_with((string)($attrs['id']??''),'f3base')){$attrs['data-no-optimize']='1';}return $attrs;});
    
},
'F3Base_Autoria'=>static function():void{

        add_filter('the_author',static fn($name)=>F3Base_Autoria::proteger((int)get_the_ID())?F3Base_Autoria::publico()['name']:$name);
        add_filter('get_the_author_display_name',static fn($name,$id)=>F3Base_Autoria::proteger((int)get_the_ID(),(int)$id)?F3Base_Autoria::publico()['name']:$name,10,2);
        add_filter('author_link',static fn($url,$id)=>F3Base_Autoria::proteger((int)get_the_ID(),(int)$id)?(F3Base_Autoria::publico()['url']??home_url('/')):$url,10,2);
        add_filter('oembed_response_data',static function($data,$post){if(F3Base_Autoria::proteger((int)$post->ID)){$data['author_name']=F3Base_Autoria::publico()['name'];$data['author_url']=F3Base_Autoria::publico()['url']??home_url('/');}return $data;},10,2);
        add_filter('redirect_canonical',static function($url){$id=(int)get_query_var('author');return $id&&F3Base_Autoria::proteger(0,$id)?home_url('/'):$url;});
    
},
'F3Base_Captura_Contexto'=>static function():void{

        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/contexto-diagnostico',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Captura_Contexto','diagnostico_publico'))));
        add_action('f3base_leads_resumo',array('F3Base_Captura_Contexto','limpar_diagnostico'));
        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/leads/contexto',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Captura_Contexto','finalizar'))));
    
},
'F3Base_Confirmacao'=>static function():void{
add_action('template_redirect',array('F3Base_Confirmacao','pagina'),-999);
},
'F3Base_Conteudo_Instrumentacao'=>static function():void{
add_action('wp_abilities_api_init',static fn()=>F3Base_Servicos::ability('conteudo-instrumentacao-ler','Auditoria de seções, CTAs e formulários do conteúdo publicado',array('F3Base_Conteudo_Instrumentacao','consultar'),array('pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>5),'tipo'=>array('type'=>'string','enum'=>array('page','post')),'post_id'=>array('type'=>'integer','minimum'=>1),'url'=>array('type'=>'string','format'=>'uri'))));
},
'F3Base_Conteudo_Privado'=>static function():void{

		add_action( 'admin_post_f3base_conteudo', array( 'F3Base_Conteudo_Privado', 'download' ) );
		add_action( 'admin_post_nopriv_f3base_conteudo', array( 'F3Base_Conteudo_Privado', 'download' ) );
	
},
'F3Base_Email_Wordpress'=>static function():void{

        add_filter('auto_plugin_update_send_email',array('F3Base_Email_Wordpress','plugins'),20,2);
        add_filter('auto_theme_update_send_email',array('F3Base_Email_Wordpress','temas'),20,2);
        add_filter('auto_core_update_send_email',array('F3Base_Email_Wordpress','nucleo'),20,2);
        add_filter('auto_core_update_email',array('F3Base_Email_Wordpress','email_nucleo'),20,2);
        add_filter('recovery_mode_email',array('F3Base_Email_Wordpress','recuperacao'),20);
        add_filter('pre_wp_mail',array('F3Base_Email_Wordpress','suprimir'),PHP_INT_MIN,2);
    
},
'F3Base_Formularios'=>static function():void{


		add_action( 'init', array( 'F3Base_Formularios', 'registrar' ) );
		add_action( 'rest_api_init', array( 'F3Base_Formularios', 'rotas' ) );
		add_action( 'admin_post_f3base_formulario', array( 'F3Base_Formularios', 'post' ) );
		add_action( 'admin_post_nopriv_f3base_formulario', array( 'F3Base_Formularios', 'post' ) );
		add_action( 'admin_post_f3base_confirmacao', array( 'F3Base_Formularios', 'confirmacao' ) );
		add_action( 'admin_post_nopriv_f3base_confirmacao', array( 'F3Base_Formularios', 'confirmacao' ) );
	
},
'F3Base_Llms_Arquivo'=>static function():void{

		add_action( 'f3base_llms_regenerar', static fn()=>F3Base_Llms_Cobertura::executar(5) );
		add_action( 'wp_loaded', array( 'F3Base_Llms_Arquivo', 'visita' ), 30 );
		add_action( 'save_post', array( 'F3Base_Llms_Arquivo', 'post' ), 99, 2 );
		add_action( 'before_delete_post', array( 'F3Base_Llms_Arquivo', 'revogar' ) );
		foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $hook ) {
			add_action( $hook, array( 'F3Base_Llms_Arquivo', 'meta' ), 99, 4 ); }
		add_action( 'updated_option', array( 'F3Base_Llms_Arquivo', 'opcao' ), 99, 3 );
		add_action(
			'added_option',
			static function ( $n, $v ): void {
				F3Base_Llms_Arquivo::opcao( $n, null, $v );
			},
			99,
			2
		);
		add_action(
			'deleted_option',
			static function ( $n ): void {
				F3Base_Llms_Arquivo::opcao( $n, null, null );
			},
			99
		);
		foreach ( array( 'wpseo_saved_postdata', 'wpseo_saved_indexable', 'set_object_terms', 'edited_term', 'delete_term' ) as $hook ) {
            add_action($hook, static function():void { $c=F3Base_Options::ler('f3base_llms'); $atuais=F3Base_Modulo_Llms_Txt_Reserva::selecao_sem_cache($c); $ids=array_column($atuais,'id'); $g=(array)get_option('f3base_llms_geracao_publicada',array()); $retirado=false; foreach($g['itens']??array() as $i){if(!in_array($i['id']??0,$ids,true)){$retirado=true;break;}} F3Base_Llms_Arquivo::alterar($retirado); },99);
        }
        add_action('switch_theme',array('F3Base_Llms_Arquivo','revogar'),99);
	
},
'F3Base_Llms_Mapa'=>static function():void{

        add_action('save_post',array('F3Base_Llms_Mapa','invalidar'),1);
        add_action('transition_post_status',array('F3Base_Llms_Mapa','transicao'),1,3);
        add_action('wpseo_saved_postdata',array('F3Base_Llms_Mapa','invalidar'),1);
        foreach(array('added_post_meta','updated_post_meta','deleted_post_meta') as $h){add_action($h,array('F3Base_Llms_Mapa','meta'),1,4);}
        add_action('before_delete_post',array('F3Base_Llms_Mapa','invalidar'),1);
        add_action('updated_option',array('F3Base_Llms_Mapa','opcao'),1,3);
    
},
'F3Base_Meta_Transporte'=>static function():void{

        add_action('rest_api_init',static fn()=>register_rest_route(F3BASE_REST_NAMESPACE,'/meta-eventos',array('methods'=>'POST','permission_callback'=>'__return_true','callback'=>array('F3Base_Meta_Transporte','receber'))));
        add_action('wp_enqueue_scripts',array('F3Base_Meta_Transporte','enfileirar'),31);
        add_action('wp_abilities_api_init',static function(){
            F3Base_Meta_Lead::registrar();
            F3Base_Servicos::ability('meta-entregas-ler','Eventos Meta por rota e dia; evidência local separada da plataforma',array('F3Base_Meta_Transporte','relatorio'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'modo'=>array('type'=>'string','enum'=>array('resumo','eventos')),'pagina'=>array('type'=>'integer','minimum'=>1)));
            F3Base_Servicos::ability('meta-homologacao-registrar','Registrar evidência externa para avaliar elegibilidade do modo servidor',array('F3Base_Meta_Transporte','homologar'),array('inicio'=>array('type'=>'string','format'=>'date'),'fim'=>array('type'=>'string','format'=>'date'),'evidencia_url'=>array('type'=>'string','maxLength'=>2048),'credencial_validada'=>array('type'=>'boolean'),'catalogo_equivalente'=>array('type'=>'boolean'),'sem_meta_terceiros'=>array('type'=>'boolean'),'eventos'=>array('type'=>'object','additionalProperties'=>false,'properties'=>array_fill_keys(array (
  0 => 'PageView',
  1 => 'Lead',
  2 => 'MaterialDownload',
),array('type'=>'object','required'=>array('elegiveis','pixel','servidor','deduplicados','descartes_inexplicados'),'additionalProperties'=>false,'properties'=>array_fill_keys(array('elegiveis','pixel','servidor','deduplicados','descartes_inexplicados'),array('type'=>'integer','minimum'=>0)))))) ,array('inicio','fim','evidencia_url','credencial_validada','catalogo_equivalente','sem_meta_terceiros','eventos'),false);
        });
    
},
'F3Base_Ofertas_Medicao'=>static function():void{

        add_action('wp_abilities_api_init',static function(){F3Base_Servicos::ability('ofertas-diagnosticar','Inspecionar marcações de ofertas em HTML informado, sem executar nem buscar páginas',array('F3Base_Ofertas_Medicao','diagnosticar'),array('html'=>array('type'=>'string','maxLength'=>262144)),array('html'));});
    
},
'F3Base_Protecao'=>static function():void{

        add_filter('rest_pre_dispatch',array('F3Base_Protecao','usuarios'),9,3);
        add_filter('xmlrpc_enabled',static fn($v)=>empty(F3Base_Protecao::config()['xmlrpc_desativado'])?$v:false);
        add_filter('xmlrpc_methods',static fn($v)=>empty(F3Base_Protecao::config()['xmlrpc_desativado'])?$v:array());
        add_filter('wp_headers',static function($h){if(!empty(F3Base_Protecao::config()['xmlrpc_desativado'])){foreach(array_keys($h) as $k){if(strtolower($k)==='x-pingback'){unset($h[$k]);}}}return $h;});
        add_filter('login_errors',static fn($v)=>!empty(F3Base_Protecao::config()['login_generico'])?'Não foi possível entrar. Confira seus dados e tente novamente.':$v);
        add_action('init',static function(){if(!empty(F3Base_Protecao::config()['xmlrpc_desativado'])){remove_action('wp_head','rsd_link');remove_action('wp_head','wlwmanifest_link');if(defined('XMLRPC_REQUEST')&&XMLRPC_REQUEST){status_header(403);nocache_headers();header('Content-Type: text/plain; charset=utf-8');echo 'XML-RPC desativado neste site.';exit;}}},-100);
    
},
'F3Base_Sessao_Admin'=>static function():void{

        add_filter('auth_cookie_expiration', array('F3Base_Sessao_Admin', 'expiracao'), 10000, 3);
    
},
'F3Base_Testes'=>static function():void{
 add_action('template_redirect',array('F3Base_Testes','pagina'),-1000); 
},
'F3Base_Navegacao'=>null,
];
