<?php
/** Deferred website Lead, captured consent and immutable visitor correspondence. */
declare(strict_types=1);
if(!defined('ABSPATH')){exit;}
final class F3Base_Meta_Lead {
    const OPTION='f3base_meta_lead';
    public static function catalogo(array $c): array {
        $props=array('modo'=>array('type'=>'string','enum'=>array('imediato','agente')),'formularios'=>array('type'=>'object','maxProperties'=>200,'additionalProperties'=>array('type'=>'string','enum'=>array('imediato','agente'))));
        $d=F3Base_Conversas::catalogo_grupo(self::OPTION,'Quando enviar o Lead à Meta',array('modo'=>'imediato','formularios'=>array()),$props,static function($v)use($props){$r=rest_validate_value_from_schema($v,array('type'=>'object','properties'=>$props,'additionalProperties'=>false));if(is_wp_error($r)){return $r->get_error_message();}foreach(array_keys($v['formularios']??array()) as $id){if(!is_string($id)||!preg_match('/^[a-zA-Z0-9_-]{1,80}$/D',$id)){return 'Identificador de formulário inválido.';}}return '';});
        $d['secao']='medicao-meta';$d['descricao']='Imediato mantém o envio atual. Agente aguarda marcação em meta-lead-enviar e suprime o Lead automático no Pixel e no servidor. O mapa formularios sobrescreve o padrão por ID. Configuração pode ser simulada antes da gravação; não envia contatos anteriores.';
        $d['subcampos'] = array(
            'modo' => array(
                'tipo' => 'enum', 'rotulo' => 'Modo padrão',
                'opcoes' => array('imediato' => 'No aceite do formulário', 'agente' => 'Após marcação pelo agente'),
            ),
            'formularios' => array(
                'tipo' => 'json', 'objeto' => true, 'rotulo' => 'Exceções por ID de formulário',
                'descricao' => 'Adicione o ID do formulário e escolha o modo de envio. Remova a exceção para voltar a usar o modo padrão.',
                'exemplo' => 'O formulário orcamento pode aguardar o agente mesmo quando o padrão é imediato.',
            ),
        );
        $c[self::OPTION]=$d;return $c;
    }
    public static function modo(array $lead): string {
        if(!in_array($lead['metodo']??'',array('formulario','whatsapp_formulario'),true)){return 'imediato';}
        $cfg=F3Base_Options::ler(self::OPTION);$form=(string)($lead['formulario']??'');
        return (string)($lead['dados']['meta_lead_modo']??$cfg['formularios'][$form]??$cfg['modo']??'imediato');
    }
    public static function capturar(array $d,string $id): array {
        unset($d['meta_lead_cifrado'],$d['meta_lead_marcacao'],$d['meta_lead_modo'],$d['meta_lead_event_id']);
        if(!in_array($d['metodo']??'',array('formulario','whatsapp_formulario'),true)){return $d;}
        $d['meta_lead_modo']=self::modo($d);$d['meta_lead_event_id']=$id;
        if(empty($d['consentimento_snapshot']['publicidade'])){return $d;}
        $a=is_array($d['atribuicao']??null)?$d['atribuicao']:array();$fbc=(string)($a['fbc']??'');
        if($fbc===''){$click=$a['fbclid']??'';if(is_string($click)&&preg_match('/^[A-Za-z0-9_.-]{1,500}$/D',$click)){$fbc='fb.1.'.(time()*1000).'.'.$click;}}
        $ip=(string)($d['contexto']['ip']??'');$external=(string)($d['contexto']['audiencia']['visitante']??$d['sessao']??$id);
        $snapshot=array('record_id'=>$id,'event_id'=>$id,'event_time'=>time(),'pagina'=>(string)($d['pagina']??''),'fbc'=>$fbc,'fbp'=>(string)($a['fbp']??''),
            'ip'=>filter_var($ip,FILTER_VALIDATE_IP)?$ip:'','user_agent'=>substr((string)($d['contexto']['user_agent']??''),0,500),'external_id'=>$external?:$id,
            'politica_revisao'=>F3Base_Options::revisao(self::OPTION));
        $d['meta_lead_cifrado']=F3Base_Contato_Comunicacao::cifrar($snapshot);return $d;
    }
    public static function propriedades(): array {return array(
        'record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$'),
        'simular'=>array('type'=>'boolean','default'=>true),
        'revisao_esperada'=>array('type'=>'integer','minimum'=>1),
        'motivo'=>array('type'=>'string','minLength'=>1,'maxLength'=>300));}
    public static function registrar(): void {
        F3Base_Servicos::ability('meta-lead-enviar','Marcar Lead do contato para CAPI; simula por padrão, preserva consentimento e recibo',array(__CLASS__,'executar'),self::propriedades(),array('record_id','motivo'),false);
    }
    public static function recibo(array $lead): array {
        $r=F3Base_Capi_Fila::ler($lead['record_id']);
        return array('modo'=>self::modo($lead),'event_id'=>F3Base_Aquisicoes::event_id($lead),'marcacao'=>$lead['dados']['meta_lead_marcacao']??null,
            'recibo'=>$r?array_intersect_key($r,array_flip(array('estado','http','tentativas','evento_em','expira','motivo','pixel_id','evento_nome','evento_hash'))):null,
            'correspondencia_capturada'=>!empty($lead['dados']['meta_lead_cifrado']));
    }
    public static function executar(array $e): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        $validation=rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::propriedades(),'required'=>array('record_id','motivo')));
        if(is_wp_error($validation)||trim($e['motivo']??'')===''||preg_match('/[\x00-\x1f\x7f<>]/',$e['motivo']??'')){return array('ok'=>false,'codigo'=>'entrada_invalida');}
        $id=$e['record_id'];$sim=($e['simular']??true)!==false;$lock=$sim?null:F3Base_Trava::adquirir('meta-lead-'.$id,45);
        if(!$sim&&!$lock){return array('ok'=>false,'codigo'=>'ocupado','retryable'=>true);}
        try{
            $lead=F3Base_Leads_Repositorio::obter($id);
            if(!$lead||!empty($lead['lixeira'])||!empty($lead['eliminacao_pendente'])||!in_array($lead['captura'],array('aceito','clique'),true)){return array('ok'=>false,'codigo'=>'contato_nao_elegivel','acao'=>'Aprove o contato suspeito antes de marcar.');}
            $receipt=self::recibo($lead);if($receipt['recibo']){return array('ok'=>true,'codigo'=>'recibo_existente','repetido'=>true,'simulado'=>$sim)+$receipt;}
            if(!$sim&&($e['revisao_esperada']??0)!==(int)$lead['revisao']){return array('ok'=>false,'codigo'=>'conflito','revisao'=>(int)$lead['revisao']);}
            if(empty($lead['dados']['consentimento_snapshot']['publicidade'])||!F3Base_Publicidade::resolver($lead['dados'])['permitida']){return array('ok'=>false,'codigo'=>'consentimento_nao_permite');}
            $s=F3Base_Contato_Comunicacao::abrir((string)($lead['dados']['meta_lead_cifrado']??''));
            if(!$s||($s['record_id']??'')!==$id){return array('ok'=>false,'codigo'=>'correspondencia_capturada_indisponivel','acao'=>'Não reconstruir IP ou agente com a requisição administrativa.');}
            $mode=F3Base_Meta_Transporte::config()['modo']??'navegador';$deadline=F3Base_Meta_Transporte::prazo((int)$s['event_time'],$mode);
            if(time()>=(int)$s['event_time']+7*DAY_IN_SECONDS||time()>=$deadline['expira_em']){return array('ok'=>false,'codigo'=>'meta_janela_encerrada','aviso'=>'Evento não enviado: idade da ocorrência excede a janela vigente.','prazo'=>$deadline);}
            if(!F3Base_Meta_Transporte::servidor('Lead')||F3Base_Modulo_Meta_Capi::token()===''||F3Base_Modulo_Meta_Capi::pixel_id()===''){return array('ok'=>false,'codigo'=>'capi_configuracao_pendente','acao'=>'Configure token, dataset e transporte do Lead.');}
            if(!F3Base_Telefone::converter($lead)){return array('ok'=>false,'codigo'=>'contato_sem_identificador_suprimido');}
            if(!empty($lead['dados']['contexto_teste'])&&F3Base_Testes::politica('capi','teste')==='suprimir'){return array('ok'=>false,'codigo'=>'suprimido_teste','acao'=>'Configure test_event_code e a política de homologação antes de enviar.');}
            $duplicate=F3Base_Contato_Identidade::bloqueio($lead,'meta');if($duplicate!==''){return array('ok'=>false,'codigo'=>$duplicate);}
            if(!empty($lead['dados']['audiencia_excluida'])||in_array($lead['dados']['classificacao_contexto']??'',array('pendente','falha','excluida','saida_sem_classificacao','consentimento_negado'),true)){return array('ok'=>false,'codigo'=>'audiencia_ou_contexto_nao_permite');}
            $d=$lead['dados'];$d['email']=$lead['email'];$d['pagina']=$s['pagina'];$d['evento_em']=$s['event_time'];$d['correlation_id']=$s['event_id'];$d['meta_external_id']=$s['external_id'];
            $d['contexto']['ip']=$s['ip'];$d['contexto']['user_agent']=$s['user_agent'];$d['atribuicao']['fbc']=$s['fbc'];$d['atribuicao']['fbp']=$s['fbp'];
            $out=array('ok'=>true,'simulado'=>$sim,'revisao'=>(int)$lead['revisao'],'event_id'=>$s['event_id'],'event_time'=>$s['event_time'],'prazo'=>$deadline,
                'aviso'=>'Se o Pixel já enviou Lead, o event_id preservado permite deduplicação dentro da janela da Meta. Recebimento e qualidade exigem prova no fornecedor.');
            if($sim){return $out+array('codigo'=>'previa_sem_envio');}
            $dado=$lead['dados'];$dado['meta_lead_marcacao']=array('operador_id'=>get_current_user_id(),'motivo'=>sanitize_text_field($e['motivo']),'em'=>time(),'revisao_politica'=>F3Base_Options::revisao(self::OPTION),'event_id'=>$s['event_id']);
            global $wpdb;$changed=$wpdb->query($wpdb->prepare('UPDATE %i SET dados=%s,revisao=revisao+1 WHERE record_id=%s AND revisao=%d AND lixeira=0 AND eliminacao_pendente=0',F3Base_Leads_Repositorio::tabela(),wp_json_encode($dado),$id,(int)$lead['revisao']));
            if($changed!==1){return array('ok'=>false,'codigo'=>'conflito_ou_persistencia_falhou');}
            $queued=F3Base_Modulo_Meta_Capi::agendar($d,$id,$s['ip'],true,true);
            $out['ok']=!empty($queued['persistido']);$out['codigo']=$out['ok']?'lead_enfileirado':'lead_nao_enfileirado';$out['revisao']++;$out['agendamento']=$queued;
            return $out+self::recibo(F3Base_Leads_Repositorio::obter($id));
        }finally{if($lock){F3Base_Trava::liberar($lock);}}
    }
}
