<?php
/** Amostras de Web Vitals por carregamento, atualizáveis e sem identidade de visitante. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Vitais {
    public const ESQUEMA_VERSAO = 17200;
    private const FORMATO_VERSAO = '(?:0|[1-9][0-9]{0,3})\.(?:0|[1-9][0-9]{0,3})\.(?:0|[1-9][0-9]{0,3})';
    private const SEM_VERSAO = 'sem_versao';
	public const TABELA           = 'f3base_vitais';
	public const BIBLIOTECA       = '6.2.1-f3.1';
	public const TETO_AMOSTRAS    = 75000;
	public const MAX_ATUALIZACOES = 60;
    private const FASES = array(
        'INP' => array('entrada', 'processamento', 'apresentacao'),
        'LCP' => array('ttfb', 'atraso_carga', 'duracao_carga', 'atraso_renderizacao'),
    );
	public static function tabela(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABELA; }
    private static string $falha_estrutura = '';

    /** Inspeção exclusiva de instalação/reparo. Não lê linhas de medição. */
    private static function estrutura(string $table): array {
        global $wpdb;
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
        if ($wpdb->last_error) { return array('erro'=>'vitais_estrutura_indisponivel'); }
        if ($exists !== $table) { return array('nova'=>true); }
        $columns = $wpdb->get_results($wpdb->prepare('SHOW COLUMNS FROM %i', $table), OBJECT_K);
        if ($wpdb->last_error) { return array('erro'=>'vitais_estrutura_indisponivel'); }
        $parts = $wpdb->get_results($wpdb->prepare('SHOW INDEX FROM %i', $table));
        if ($wpdb->last_error) { return array('erro'=>'vitais_estrutura_indisponivel'); }
        $primary = $originIndex = array();
        foreach ($parts as $part) {
            if ($part->Key_name === 'PRIMARY') { $primary[(int)$part->Seq_in_index] = $part->Column_name; }
            if (strtolower($part->Key_name) === 'origem_periodo') {
                if ((int)$part->Non_unique !== 1 || $part->Sub_part !== null || $part->Collation !== 'A' ||
                    $part->Index_type !== 'BTREE' || ($part->Visible ?? 'YES') !== 'YES') {
                    return array('erro'=>'vitais_indice_origem_incompativel');
                }
                $originIndex[(int)$part->Seq_in_index] = $part->Column_name;
            }
        }
        $required = array('amostra','classe_trafego','automacao','automacao_motivos','automacao_regra','atribuicao',
            'dia','caminho','metrica','dispositivo','sequencia','valor');
        if (array_diff($required,array_keys($columns)) || $primary !== array(1=>'amostra') ||
            $columns['amostra']->Type !== 'char(64)' || $columns['amostra']->Null !== 'NO') {
            return array('erro'=>'vitais_base_incompativel');
        }
        $columns = array_change_key_case($columns, CASE_LOWER);
        $add = array();
        if (!isset($columns['versao_origem'])) {
            $add[] = "ADD COLUMN versao_origem varchar(14) NOT NULL DEFAULT ''";
        } else {
            $origin = $columns['versao_origem'];
            if ($origin->Type !== 'varchar(14)' || $origin->Null !== 'NO' || $origin->Default !== '' || $origin->Extra !== '') {
                return array('erro'=>'vitais_coluna_origem_incompativel');
            }
        }
        if (!$originIndex) {
            $add[] = 'ADD INDEX origem_periodo (versao_origem,dia,metrica)';
        } else {
            ksort($originIndex);
            if ($originIndex !== array(1=>'versao_origem',2=>'dia',3=>'metrica')) {
                return array('erro'=>'vitais_indice_origem_incompativel');
            }
        }
        return array('adicoes'=>$add);
    }

    public static function pronta(): bool {
        if (!F3Base_Esquema::manutencao()) { return F3Base_Esquema::pronta(__CLASS__); }
        $state = self::estrutura(self::tabela());
        return isset($state['adicoes']) && !$state['adicoes'];
    }
    public static function falha_estrutura(): string { return self::$falha_estrutura; }

    public static function instalar(): bool {
        return (bool)F3Base_Esquema::instalar(__CLASS__, 'instalar', static fn()=>self::instalar_estrutura());
    }
	public static function instalar_estrutura(): bool {
		global $wpdb;
		$t = self::tabela();
        self::$falha_estrutura = '';
        $state = self::estrutura($t);
        if (isset($state['erro'])) { self::$falha_estrutura=$state['erro']; return false; }
        if (!empty($state['nova'])) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta(
				"CREATE TABLE {$t} (
				amostra char(64) NOT NULL,
                classe_trafego varchar(16) NOT NULL DEFAULT 'nao_marcado',
                automacao varchar(20) NOT NULL DEFAULT 'legado_desconhecido',
                automacao_motivos varchar(190) NOT NULL DEFAULT '',
                automacao_regra varchar(40) NOT NULL DEFAULT '',
                atribuicao text NULL,
                versao_origem varchar(14) NOT NULL DEFAULT '',
				dia date NOT NULL,
				caminho varchar(760) NOT NULL,
				metrica varchar(8) NOT NULL,
				dispositivo varchar(16) NOT NULL,
				sequencia int unsigned NOT NULL,
				valor double NOT NULL,
				PRIMARY KEY  (amostra),
				KEY periodo (dia,metrica,dispositivo),
                KEY classe_dia (classe_trafego,dia),
                KEY origem_periodo (versao_origem,dia,metrica),
				KEY pagina (caminho(190))
			) {$wpdb->get_charset_collate()};"
			);
        } elseif ($state['adicoes']) {
            // O contrato 1.71 já existe. Nunca reconciliar seu DDL histórico contra o modelo para instalações novas.
            $sql = 'ALTER TABLE %i ' . implode(', ', $state['adicoes']);
            $wpdb->query($wpdb->prepare($sql, $t));
        } else {
            self::podar();
            return true;
        }
        // Após introdução efetiva não varremos linhas, nem mesmo as vencidas. A poda ocorre em sua rotina seguinte.
        $after = self::estrutura($t);
        if (!isset($after['adicoes']) || $after['adicoes']) {
            self::$falha_estrutura = $after['erro'] ?? 'vitais_ddl_nao_confirmado';
            return false;
        }
        return true;
	}

    public static function podar(): void {
        if (get_transient('f3base_vitais_limpeza') || !self::pronta()) { return; }
        global $wpdb;
        $cutoff = gmdate('Y-m-d',time()-(F3Base_Modulo_Comportamento::retencao_eventos_dias()-1)*DAY_IN_SECONDS);
        if (false !== $wpdb->query($wpdb->prepare('DELETE FROM %i WHERE dia<%s',self::tabela(),$cutoff))) {
            set_transient('f3base_vitais_limpeza',true,HOUR_IN_SECONDS);
        }
    }

	public static function amostra_valida( $a, ?string $metrica = null ): bool {
		return is_array( $a ) && !array_diff(array_keys($a),array('id','dispositivo','sequencia','atribuicao','versao_origem')) && (!array_key_exists('versao_origem',$a) || (is_string($a['versao_origem']) && preg_match('~^'.self::FORMATO_VERSAO.'$~D',$a['versao_origem']))) && (!isset($a['atribuicao'])||self::atribuicao_valida($a['atribuicao'], $metrica)) && is_string( $a['id'] ?? null ) && preg_match( '/^[a-zA-Z0-9_-]{8,80}$/D', $a['id'] ) && in_array( $a['dispositivo'] ?? '', array( 'movel', 'desktop' ), true ) && is_int( $a['sequencia'] ?? null ) && $a['sequencia'] >= 1 && $a['sequencia'] <= self::MAX_ATUALIZACOES;
	}
    public static function atribuicao_valida($a, ?string $metrica = null): bool {
        if(!is_array($a)||array_diff(array_keys($a),array('alvo','tipo','recurso','origem_script','fases','loaf'))){return false;}
        if ($metrica !== null) {
            if (!isset(self::FASES[$metrica])) { return false; }
            $interaction = $metrica === 'INP';
            $invalidKeys = $interaction ? array('recurso') : array('origem_script', 'loaf');
            $types = $interaction ? array('ponteiro', 'teclado') : array('imagem', 'texto');
            if (array_intersect($invalidKeys, array_keys($a)) ||
                (isset($a['tipo']) && !in_array($a['tipo'], $types, true)) ||
                (isset($a['fases']) && (!is_array($a['fases']) || array_diff(array_keys($a['fases']), self::FASES[$metrica])))) {
                return false;
            }
        }
        if(isset($a['alvo'])&&(!is_string($a['alvo'])||strlen($a['alvo'])>190||!preg_match('/^(?:(?:html|body|main|header|footer|nav|section|article|div|span|p|h[1-6]|button|a|input|select|textarea|label|form|img|picture|video|svg|ul|li)(?::nth-of-type\([1-9][0-9]{0,3}\))?)(?:>(?:html|body|main|header|footer|nav|section|article|div|span|p|h[1-6]|button|a|input|select|textarea|label|form|img|picture|video|svg|ul|li)(?::nth-of-type\([1-9][0-9]{0,3}\))?){0,3}$/D',$a['alvo']))){return false;}
        if(isset($a['tipo'])&&!in_array($a['tipo'],array('ponteiro','teclado','imagem','texto'),true)){return false;}
        if(isset($a['loaf'])&&!is_bool($a['loaf'])){return false;}
        foreach(array('recurso','origem_script') as $key){if(!isset($a[$key])){continue;}$v=$a[$key];if(!is_string($v)||strlen($v)>500){return false;}$u=wp_parse_url($v);if(!is_array($u)||!in_array($u['scheme']??'',array('http','https'),true)||empty($u['host'])||isset($u['query'])||isset($u['fragment'])||isset($u['user'])||isset($u['pass'])||str_contains(rawurldecode($v),'@')){return false;}if($key==='origem_script'&&!empty($u['path'])&&$u['path']!=='/'){return false;}}
        if(isset($a['fases'])){if(!is_array($a['fases'])||array_diff(array_keys($a['fases']),array('entrada','processamento','apresentacao','ttfb','atraso_carga','duracao_carga','atraso_renderizacao'))){return false;}foreach($a['fases'] as $v){if((!is_float($v)&&!is_int($v))||!is_finite((float)$v)||$v<0||$v>3600000){return false;}}}
        return true;
    }
    public static function gravar(string $dia,string $caminho,array $linha,string $classe='nao_marcado',array $automacao=array()): bool {
        if(!self::pronta()||!self::amostra_valida($linha['amostra']??null, $linha['detalhe'])){return false;}
        global $wpdb;$t=self::tabela();$a=$linha['amostra'];
        $id=hash('sha256',($classe==='teste'?'teste|':'').$caminho.'|'.$linha['detalhe'].'|'.$a['id']);
        $auto=in_array($automacao['automacao']??'',array('nao_identificada','provavel','declarada'),true)?$automacao['automacao']:'nao_identificada';
        $motivos=substr(sanitize_text_field($automacao['automacao_motivos']??''),0,190);$regra=substr(sanitize_key($automacao['automacao_regra']??''),0,40);
        $origin = $a['versao_origem'] ?? '';
        $attr=isset($a['atribuicao'])?wp_json_encode($a['atribuicao']):null;
        $existe=$wpdb->get_var($wpdb->prepare('SELECT amostra FROM %i WHERE amostra=%s',$t,$id));
        if(!$existe){
            if((int)$wpdb->get_var("SELECT COUNT(*) FROM {$t}")>=self::TETO_AMOSTRAS){return false;}
            $ok=$wpdb->query($wpdb->prepare('INSERT IGNORE INTO %i (amostra,dia,caminho,metrica,dispositivo,sequencia,valor,classe_trafego,automacao,automacao_motivos,automacao_regra,atribuicao,versao_origem) VALUES (%s,%s,%s,%s,%s,%d,%f,%s,%s,%s,%s,%s,%s)',$t,$id,$dia,$caminho,$linha['detalhe'],$a['dispositivo'],$a['sequencia'],$linha['soma'],$classe==='teste'?'teste':'nao_marcado',$auto,$motivos,$regra,$attr,$origin));
            if($ok===false){return false;}if($ok===1){return true;}
        }
        // O lock da linha serializa as revisões. A procedência requer concordância inclusive em reenvios antigos.
        // A sequência é atualizada por último: as expressões anteriores comparam contra o valor já persistido.
        $sequence = $a['sequencia'];
        $sql = "UPDATE %i SET versao_origem=IF(versao_origem=%s,versao_origem,''),
            valor=IF(sequencia<%d,%f,valor), atribuicao=IF(sequencia<%d,%s,atribuicao),
            automacao=IF(sequencia<%d AND automacao NOT IN ('provavel','declarada'),%s,automacao),
            automacao_motivos=IF(sequencia<%d AND automacao_motivos='',%s,automacao_motivos),
            automacao_regra=IF(sequencia<%d AND automacao_regra='',%s,automacao_regra),
            sequencia=GREATEST(sequencia,%d)
            WHERE amostra=%s AND (sequencia<%d OR (versao_origem<>'' AND versao_origem<>%s))";
        return false !== $wpdb->query($wpdb->prepare($sql,$t,$origin,$sequence,$linha['soma'],$sequence,$attr,
            $sequence,$auto,$sequence,$motivos,$sequence,$regra,$sequence,$id,$sequence,$origin));
    }
    public static function iniciar(): void {
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::registrar_ability('f3base/vitais-ler',array('label'=>'Desempenho de campo por caminho e métrica','description'=>'p75 das últimas amostras por carregamento, atribuição INP/LCP e contagem de automação e legado excluídos. Filtre por versão de origem do carregamento ou consulte sem_versao. somente_resumo retorna apenas contagens e p75. Leitura local sem coleta.','category'=>F3BASE_PREFIXO,'input_schema'=>array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros_schema()),'output_schema'=>array('type'=>'object','properties'=>array('ok'=>array('type'=>'boolean'),'somente_resumo'=>array('type'=>'boolean'),'versao_origem'=>array('type'=>array('string','null')),'codigo'=>array('type'=>'string'),'linhas'=>array('type'=>'array','items'=>array('type'=>'object','required'=>array('metrica','amostras','p75','excluidas_automacao','excluidas_legado'),'properties'=>array('metrica'=>array('type'=>'string'),'amostras'=>array('type'=>'integer'),'p75'=>array('type'=>array('number','null')),'excluidas_automacao'=>array('type'=>'integer'),'excluidas_legado'=>array('type'=>'integer'),'alvos'=>array('type'=>'array'),'scripts'=>array('type'=>'array'),'fases_amostras'=>array('type'=>array('object','array'),'additionalProperties'=>array('type'=>'integer')),'amostras_fases_completas'=>array('type'=>'integer'),'fase_dominante'=>array('type'=>array('string','null'))))))),'permission_callback'=>static fn()=>current_user_can('manage_options'),'execute_callback'=>array(__CLASS__,'consultar'),'meta'=>array('mcp'=>array('public'=>true,'type'=>'tool'),'annotations'=>array('readonly'=>true,'idempotent'=>true,'destructive'=>false))));
        });
    }
    public static function filtros_schema(): array {return array('versao_origem'=>array('type'=>'string','pattern'=>'^(?:'.self::FORMATO_VERSAO.'|'.self::SEM_VERSAO.')$','maxLength'=>14,'description'=>'Versão coincidente do HTML e coletor. sem_versao seleciona histórico, ausência de origem ou conflito; omitir inclui todas.'),'somente_resumo'=>array('type'=>'boolean','default'=>false,'description'=>'Calcula somente contagens e p75. Omite a leitura e a saída de atribuições.'),'de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'dias'=>array('type'=>'integer','minimum'=>1,'maximum'=>90),'caminho'=>array('type'=>'string','maxLength'=>760),'metrica'=>array('type'=>'string','enum'=>array('INP','LCP','CLS','TTFB')),'dispositivo'=>array('type'=>'string','enum'=>array('movel','desktop')),'segmento'=>array('type'=>'string','enum'=>F3Base_Testes::SEGMENTOS),'automacao'=>array('type'=>'string','enum'=>array('audiencia','todas')));}
    public static function consultar(array $e=array()): array {
        if(!current_user_can('manage_options')){return array('ok'=>false,'codigo'=>'sem_permissao');}
        if(is_wp_error(rest_validate_value_from_schema($e,array('type'=>'object','additionalProperties'=>false,'properties'=>self::filtros_schema())))){return array('ok'=>false,'codigo'=>'filtros_invalidos');}
        if(!self::pronta()){return array('ok'=>false,'codigo'=>'estrutura_indisponivel');}
        $e+=array('dias'=>28,'somente_resumo'=>false,'ate'=>wp_date('Y-m-d'),'automacao'=>'audiencia','segmento'=>'sem_testes');
        $e['somente_resumo'] = rest_sanitize_boolean($e['somente_resumo']);
        $e+=array('de'=>(new DateTimeImmutable($e['ate'],wp_timezone()))->modify('-'.($e['dias']-1).' days')->format('Y-m-d'));
        $start=new DateTimeImmutable($e['de'],wp_timezone());$end=new DateTimeImmutable($e['ate'],wp_timezone());
        if($start>$end||$start->diff($end)->days>=90){return array('ok'=>false,'codigo'=>'periodo_invalido');}
        global $wpdb;$t=self::tabela();$where=$wpdb->prepare('dia BETWEEN %s AND %s',$e['de'],$e['ate']).F3Base_Testes::sql($e['segmento']);
        foreach(array('caminho','metrica','dispositivo') as $k){if(!empty($e[$k])){$where.=$wpdb->prepare(" AND {$k}=%s",$e[$k]);}}
        if (isset($e['versao_origem'])) {
            $origin = $e['versao_origem'] === self::SEM_VERSAO ? '' : $e['versao_origem'];
            $where .= $wpdb->prepare(' AND versao_origem=%s', $origin);
        }
        $counts=$wpdb->get_results("SELECT metrica,automacao,COUNT(*) n FROM {$t} WHERE {$where} GROUP BY metrica,automacao",ARRAY_A);if($wpdb->last_error){return array('ok'=>false,'codigo'=>'consulta_indisponivel');}
        $out = array();
        foreach ($counts as $count) {
            $metric = $count['metrica'];
            if (!isset($out[$metric])) {
                $out[$metric] = array('metrica'=>$metric,'amostras'=>0,'p75'=>null,'excluidas_automacao'=>0,'excluidas_legado'=>0);
                if (!$e['somente_resumo']) {
                    $out[$metric] += array('amostras_atribuidas'=>0,'alvos'=>array(),'scripts'=>array(),'fases_media_ms'=>array(),'fases_amostras'=>array(),'amostras_fases_completas'=>0,'fase_dominante'=>null);
                }
            }
            $column = 'amostras';
            if ($e['automacao'] === 'audiencia' && $count['automacao'] !== 'nao_identificada') {
                $column = in_array($count['automacao'], array('provavel','declarada'), true) ? 'excluidas_automacao' : 'excluidas_legado';
            }
            $out[$metric][$column] += (int) $count['n'];
        }
        $eligible=$where.($e['automacao']==='audiencia'?" AND automacao='nao_identificada'":'');
        foreach ($out as $metrica => &$row) {
            if (!$row['amostras']) {
                continue;
            }
            $offset = (int) ceil(0.75 * $row['amostras']) - 1;
            $p75 = $wpdb->get_var($wpdb->prepare("SELECT valor FROM {$t} WHERE {$eligible} AND metrica=%s ORDER BY valor,amostra LIMIT 1 OFFSET %d", $metrica, $offset));
            if ($wpdb->last_error || $p75 === null) {
                return array('ok'=>false, 'codigo'=>'consulta_indisponivel');
            }
            $row['p75'] = (float) $p75;
            if (!$e['somente_resumo'] && !self::resumir_atribuicoes($row, $eligible)) {
                return array('ok'=>false, 'codigo'=>'consulta_indisponivel');
            }
        }
        unset($row);
        return array('ok'=>true,'de'=>$e['de'],'ate'=>$e['ate'],'fuso'=>wp_timezone_string(),'automacao'=>$e['automacao'],'somente_resumo'=>$e['somente_resumo'],'versao_origem'=>$e['versao_origem']??null,'linhas'=>array_values($out),'limite'=>'O denominador de cada p75 é o número de amostras elegíveis daquela métrica. A ausência de sinal de automação não identifica uma pessoa. A consulta de audiência exclui o legado sem classificação. A amostra conserva a maior sequência recebida; o registro detalhado exige pseudônimos e usa a primeira emissão. Cada média de fase informa quantas amostras trazem aquele dado. A fase dominante compara somente amostras com todas as fases; empate ou ausência desse conjunto deixa a fase vazia. Origens de scripts mostram coincidência temporal.');
    }

    /** Percorre apenas atribuições existentes, sem descartar repetidamente as linhas anteriores. */
    private static function resumir_atribuicoes(array &$row, string $eligible): bool {
        global $wpdb;
        $table = self::tabela();
        $metric = $row['metrica'];
        $expected = self::FASES[$metric] ?? array();
        if (!$expected) {
            return true;
        }
        $targets = $scripts = $sums = $completeSums = array();
        $cursor = '';
        do {
            $sql = "SELECT amostra,atribuicao FROM {$table} WHERE {$eligible} AND metrica=%s AND amostra>%s AND atribuicao IS NOT NULL AND atribuicao<>'' ORDER BY amostra LIMIT 500";
            $batch = $wpdb->get_results($wpdb->prepare($sql, $metric, $cursor), ARRAY_A);
            if ($wpdb->last_error) {
                return false;
            }
            foreach ($batch as $sample) {
                $cursor = $sample['amostra'];
                $attribution = json_decode($sample['atribuicao'], true);
                if (!$attribution || !self::atribuicao_valida($attribution, $metric)) {
                    continue;
                }
                ++$row['amostras_atribuidas'];
                if (isset($attribution['alvo'])) {
                    $target = $attribution['alvo'];
                    $targets[$target] = ($targets[$target] ?? 0) + 1;
                }
                if (isset($attribution['origem_script'])) {
                    $script = $attribution['origem_script'];
                    $scripts[$script] = ($scripts[$script] ?? 0) + 1;
                }
                $phases = $attribution['fases'] ?? array();
                foreach ($expected as $phase) {
                    if (isset($phases[$phase])) {
                        $sums[$phase] = ($sums[$phase] ?? 0) + $phases[$phase];
                        $row['fases_amostras'][$phase] = ($row['fases_amostras'][$phase] ?? 0) + 1;
                    }
                }
                if ($expected && !array_diff($expected, array_keys($phases))) {
                    ++$row['amostras_fases_completas'];
                    foreach ($expected as $phase) {
                        $completeSums[$phase] = ($completeSums[$phase] ?? 0) + $phases[$phase];
                    }
                }
            }
        } while (count($batch) === 500);
        foreach (array('alvos'=>$targets, 'scripts'=>$scripts) as $key => $values) {
            arsort($values);
            foreach (array_slice($values, 0, 10, true) as $value => $n) {
                $row[$key][] = array('valor'=>$value, 'amostras'=>$n);
            }
        }
        foreach ($sums as $phase => $sum) {
            $row['fases_media_ms'][$phase] = round($sum / $row['fases_amostras'][$phase], 2);
        }
        arsort($row['fases_media_ms']);
        // A mesma população sustenta a comparação; um empate não elege uma fase por ordem de leitura.
        if ($completeSums) {
            $max = max($completeSums);
            $dominant = array_keys($completeSums, $max);
            if (count($dominant) === 1) {
                $row['fase_dominante'] = $dominant[0];
            }
        }
        return true;
    }
    public static function estatisticas(int $dias,string $caminho='',string $dispositivo='',?string $segmento=null): array {
        $e=array('dias'=>max(1,min(90,$dias)),'segmento'=>$segmento??'sem_testes');if($caminho!==''){$e['caminho']=$caminho;}if($dispositivo!==''){$e['dispositivo']=$dispositivo;}return self::consultar($e)['linhas']??array();
    }
    private static function filtros_da_tela(): array {
        $device = $_GET['vital_dispositivo'] ?? '';
        $origin = $_GET['vital_versao'] ?? '';
        return array_filter(array(
            'dispositivo'=>in_array($device, array('movel','desktop'), true) ? $device : '',
            'versao_origem'=>is_string($origin) ? trim(wp_unslash($origin)) : '',
        ), static fn($value)=>$value !== '');
    }

    public static function campos_filtro(): void {
        $filters = self::filtros_da_tela();
        echo '<label>Tela <select name="vital_dispositivo">';
        foreach (array(''=>'Todas', 'movel'=>'Móvel', 'desktop'=>'Desktop') as $value=>$label) {
            printf('<option value="%s" %s>%s</option>', esc_attr($value), selected($filters['dispositivo']??'', $value, false), esc_html($label));
        }
        echo '</select></label> <label>Versão de origem <input name="vital_versao" maxlength="14" placeholder="Ex.: 1.72.0" value="' . esc_attr($filters['versao_origem']??'') . '" aria-describedby="f3base-vital-origem"></label> ';
    }

	/** O painel fornece o recorte validado e contém seu próprio formulário de navegação. */
	public static function render( int $dias, array $painel = array() ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return; }
		if ( ! self::pronta() ) {
			echo '<div class="notice notice-error inline"><p>Armazenamento de Web Vitals indisponível. As amostras permanecem pendentes no navegador dentro do prazo da visita.</p></div>';
			return; }
        $filters = self::filtros_da_tela() + array_intersect_key($painel, array_flip(array('de','ate','segmento','caminho')));
        $filters += array('dias'=>max(1, min(90, $dias)), 'segmento'=>'sem_testes', 'somente_resumo'=>true);
        echo '<section class="f3base-bloco">';
        if (!$painel) {
            // O método também pode ser renderizado separadamente. Seu formulário encaminha à visão real.
            $path = $_GET['caminho'] ?? $_GET['vital_pagina'] ?? '';
            if (is_string($path) && $path !== '') { $filters['caminho'] = substr(wp_unslash($path),0,760); }
            echo '<h2>Web Vitals por versão</h2><form method="get"><input type="hidden" name="page" value="f3base-medicao"><input type="hidden" name="area" value="tecnico"><input type="hidden" name="visao" value="vitais"><input type="hidden" name="de" value="' . esc_attr((new DateTimeImmutable('today',wp_timezone()))->modify('-'.($filters['dias']-1).' days')->format('Y-m-d')) . '"><input type="hidden" name="ate" value="' . esc_attr(wp_date('Y-m-d')) . '"><input type="hidden" name="segmento" value="sem_testes"><label>Caminho <input name="caminho" placeholder="/servicos/" value="' . esc_attr($filters['caminho']??'') . '"></label> ';
            self::campos_filtro();
            echo '<button class="button">Atualizar</button></form>';
        }
        echo '<p id="f3base-vital-origem">Deixe a versão de origem vazia para todas as versões. Digite uma versão para comparar carregamentos cujo HTML e coletor coincidem, ou <code>sem_versao</code> para histórico e origens ausentes ou conflitantes.</p><p>Cada linha usa o último valor recebido por métrica e carregamento. O p75 é o valor até o qual chegam 75% das amostras elegíveis, arredondando a posição para cima. A coleta depende do consentimento, do suporte do navegador e da entrega. INP exige interação. A largura da tela define o grupo de dispositivo. O segmento do painel controla os testes; a consulta de audiência separa automação detectada e registros antigos sem classificação.</p>';
        if (isset($filters['versao_origem']) && $filters['versao_origem'] !== self::SEM_VERSAO && !preg_match('~^' . self::FORMATO_VERSAO . '$~D', $filters['versao_origem'])) {
            echo '<div class="notice notice-error inline" role="alert"><p>Digite uma versão com três números separados por pontos ou sem_versao.</p></div></section>';
            return;
        }
		$result = self::consultar($filters);
		if (!$result['ok']) {
			echo '<div class="notice notice-error inline"><p>Não foi possível consultar as amostras deste período.</p></div></section>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>Métrica</th><th>Percentil 75</th><th>Amostras elegíveis</th><th>Excluídas por automação</th><th>Excluídas sem classificação</th></tr></thead><tbody>';
		foreach ($result['linhas'] as $row) {
			$value = 'Sem amostras elegíveis';
			if ($row['p75'] !== null) {
				$value = number_format_i18n($row['p75'], $row['metrica'] === 'CLS' ? 3 : 0);
				if ($row['metrica'] !== 'CLS') { $value .= ' ms'; }
			}
			printf('<tr><td>%s</td><td>%s</td><td>%d</td><td>%d</td><td>%d</td></tr>', esc_html($row['metrica']), esc_html($value), $row['amostras'], $row['excluidas_automacao'], $row['excluidas_legado']);
		}
		if (!$result['linhas']) {
			echo '<tr><td colspan="5">Sem amostras neste filtro.</td></tr>';
		}
		echo '</tbody></table></section>';
	}
	public static function remover(): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', self::tabela() ) ); }
}
