/* Preflight only after explicit form submission. No credential is copied into markup/storage/logs. */
(function () {
  'use strict';
  document.addEventListener('click', async function(event) {
    const button=event.target.closest('[data-credencial-verificar-salva]');if(!button)return;
    const info=button.closest('[data-credencial-nome]'), status=info.querySelector('[role="status"]');
    button.disabled=true;status.textContent='Verificando a credencial salva…';
    try {const data=new FormData();data.append('action','f3base_credenciais_previa');data.append('nonce',info.dataset.nonce);data.append('payload',JSON.stringify([{nome:info.dataset.credencialNome,revisao_esperada:info.dataset.revisao,usar_salva:true}]));const response=await fetch(window.ajaxurl,{method:'POST',credentials:'same-origin',body:data});const result=await response.json();if(!result.success)throw new Error((result.data?.motivo||'Verificação indisponível.')+' '+(result.data?.avisos||[]).map(a=>a.motivo).join(' '));const r=result.data[0];if(!r.ok)throw new Error(r.motivo||'Verificação não confirmada.');status.textContent=(r.remota?'Identidade verificada: '+JSON.stringify(r.identidade||{}):'Conferência local concluída; confirmação no fornecedor pendente')+'. A credencial foi mantida. '+(r.avisos||[]).map(a=>a.motivo).join(' ');}
    catch(error){status.textContent=error instanceof Error?error.message:'Verificação indisponível.';}finally{button.disabled=false;}
  });
  document.addEventListener('submit', async function (event) {
    const form = event.target;
    if (!(form instanceof HTMLFormElement) || form.hasAttribute('data-f3base-meta-edicao') || form.dataset.credenciaisConfirmadas === '1') return;
    const fields = Array.from(form.querySelectorAll('input[data-credencial]')).filter(input => input.value.trim() !== '');
    if (!fields.length) return;
    event.preventDefault();
    if (form.dataset.credenciaisVerificando === '1') return;
    form.dataset.credenciaisVerificando = '1';
    const submitter = event.submitter;
    const payload = fields.map(input => {
      const info = Array.from(form.querySelectorAll('[data-credencial-nome]')).find(node => node.dataset.credencialNome === input.dataset.credencial);
      return {nome: input.dataset.credencial, credential: input.value, revisao_esperada: info.dataset.revisao};
    });
    const status = form.querySelector('.f3base-credencial-mensagem');
    const before = JSON.stringify(payload);
    try {
      if (status) status.textContent = 'Verificando a credencial antes de salvar…';
      const data = new FormData();
      data.append('action', 'f3base_credenciais_previa');
      data.append('nonce', form.querySelector('[data-credencial-nome]').dataset.nonce);
      data.append('payload', before);
      const original = new FormData(form), context = {};
      for (const name of ['dominio','client_id','slack_canal_id','integracao_id']) {
        const value = original.get('config[' + name + ']') ?? original.get(name);
        if (typeof value === 'string') context[name] = value;
      }
      data.append('contexto', JSON.stringify(context));
      const response = await fetch(window.ajaxurl, {method: 'POST', credentials: 'same-origin', body: data});
      const result = await response.json();
      for (const item of (result.success ? result.data : [result.data])) {
        const info=Array.from(form.querySelectorAll('[data-credencial-nome]')).find(node=>node.dataset.credencialNome===item?.nome);
        const note=info?.querySelector('[role="status"]');if(note)note.textContent=(item.motivo||'')+' '+(item.avisos||[]).map(a=>a.regra+': '+a.motivo).join(' ');
      }
      if (!result.success) throw new Error((result.data?.motivo || 'Não foi possível verificar. A credencial salva continua em uso.')+' '+(result.data?.avisos||[]).map(a=>a.regra+': '+a.motivo).join(' '));
      if (fields.some((field, i) => field.value !== payload[i].credential)) throw new Error('O valor mudou durante a verificação. Salve novamente.');
      const confirmations = {};
      for (let i=0; i<result.data.length; i++) {
        const check=result.data[i];
        if (check.codigo === 'confirmacao_identidade_necessaria') {
          const previous=JSON.stringify(check.anterior || {}, null, 2), next=JSON.stringify(check.identidade || {}, null, 2);
          if (!window.confirm('Confirmar troca de identidade?\n\nSalva:\n'+previous+'\n\nNova:\n'+next)) {
            if (status) status.textContent='Troca cancelada. A credencial salva continua em uso.';
            return;
          }
          confirmations[payload[i].nome] = check.confirmacao;
        } else if (!check.ok) throw new Error(check.motivo || 'Credencial não confirmada.');
      }
      let hidden=form.querySelector('[name="f3base_credencial_confirmacoes"]');
      if (!hidden) {hidden=document.createElement('input');hidden.type='hidden';hidden.name='f3base_credencial_confirmacoes';form.appendChild(hidden);}
      hidden.value=JSON.stringify(confirmations);
      form.dataset.credenciaisConfirmadas='1';
      form.requestSubmit(submitter || undefined);
      delete form.dataset.credenciaisConfirmadas;
    } catch(error) {
      if (status) status.textContent=error instanceof Error ? error.message : 'Verificação indisponível.';
    } finally {delete form.dataset.credenciaisVerificando;}
  });
}());
