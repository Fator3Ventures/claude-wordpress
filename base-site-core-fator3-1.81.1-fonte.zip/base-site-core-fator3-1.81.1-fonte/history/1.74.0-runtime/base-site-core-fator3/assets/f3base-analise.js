/*! F3 Base 1.16 — análise com confirmação por evento e retentativa limitada. GPL-2.0-or-later. */
(function () {
 'use strict';
 var entradaComAncora=location.hash.length>1;
 var cfg=window.f3baseAnaliseDados||{},nav='',current='',mode=false,queue=[],inflight=null,timer=0,pageSent=false,views=new WeakSet(),vitals={},retry=0,next=0,loaded=document.readyState==='complete',KEY='f3base_analise_fila';
 var ATRASO_INICIAL_MS=0,initialDeadline=0,timerDue=0,urgentPending=false;
 var renewal='';
 var formStates=new Map();
 var counts={confirmados:0,recuperacoes:0,falhas:0,expirados:0,limite:0,rejeitados:0},dead=[];
 function permit(){return !!(window.f3baseTracking&&window.f3baseTracking.permiteTags()&&window.f3baseTracking.sessao());}
 function uuid(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function read(){try{return JSON.parse(sessionStorage.getItem(KEY)||'null');}catch(e){return null;}}
 function persist(){if(permit()){try{sessionStorage.setItem(KEY,JSON.stringify({eventos:queue,contagens:counts,rejeitados:dead}));}catch(e){}}}
 function clear(){renewal='';formStates=new Map();document.dispatchEvent(new CustomEvent('f3base-analise-reinicio'));queue=[];nav='';current='';pageSent=false;views=new WeakSet();vitals={};clearTimeout(timer);timer=0;timerDue=0;urgentPending=false;retry=0;next=0;initialDeadline=loaded?Date.now()+ATRASO_INICIAL_MS:0;try{sessionStorage.removeItem(KEY);sessionStorage.removeItem('f3base_analise_origem');}catch(e){}}
 function context(){
  if(!permit()){return null;}var s=window.f3baseTracking.sessao(),test=!!(window.f3baseContexto&&window.f3baseContexto.teste());
  if(current!==s||mode!==test){formStates=new Map();document.dispatchEvent(new CustomEvent('f3base-analise-reinicio'));current=s;mode=test;nav=window.f3baseContexto&&window.f3baseContexto.navegacao(s)?window.f3baseContexto.navegacao(s).navegacao:uuid();pageSent=false;views=new WeakSet();vitals={};}
  return {sessao:s,visitante:window.f3baseTracking.visitante(),navegacao:nav,navegacao_anterior:window.f3baseContexto&&window.f3baseContexto.navegacao(s)?window.f3baseContexto.navegacao(s).anterior:'',sinais:window.f3baseContexto?window.f3baseContexto.sinais():{},contexto_teste:test,largura:(window.f3baseContexto.audiencia()||{}).largura||0,max_touch_points:(window.f3baseContexto.audiencia()||{}).max_touch_points||0,retorno:(window.f3baseContexto.audiencia()||{}).retorno||'',dispositivo:matchMedia('(max-width: 767px)').matches?'movel':'desktop',atribuicao:window.f3baseContexto?window.f3baseContexto.atribuicao():{}};
 }
 function schedule(ms){
  if(!initialDeadline){initialDeadline=Date.now()+ATRASO_INICIAL_MS;}
  var due=Math.max(Date.now()+Math.max(ms||0,100),next,initialDeadline);
  if(timer&&timerDue<=due){return;}clearTimeout(timer);timerDue=due;
  timer=setTimeout(function(){timer=0;timerDue=0;flush(false);},Math.max(0,due-Date.now()));
 }
 function expire(){var cutoff=Math.floor(Date.now()/1000)-86400,n=queue.length;queue=queue.filter(function(e){return e.criado_em>=cutoff;});counts.expirados+=n-queue.length;}
 function reject(pack,code,id){var selected=id?pack.filter(function(e){return e.evento===id;}):pack.slice(0,1);selected.forEach(function(e){dead.push({evento:e.evento,sequencia:e.sequencia,codigo:code,em:Date.now()});queue=queue.filter(function(q){return q!==e;});counts.rejeitados++;});dead=dead.slice(-20);persist();}
 function flush(urgent,renewed){
  if(inflight&&urgent){urgentPending=true;}
  if(inflight||!queue.length||!permit()){return;}if(Date.now()<next){schedule(0);return;}if(!urgent&&Date.now()<initialDeadline){schedule(0);return;}expire();if(!queue.length){persist();return;}
  var pack=queue.filter(function(e){return e.contexto_teste===queue[0].contexto_teste;}).slice(0,20);
  while(pack.length>1&&new TextEncoder().encode(JSON.stringify(pack)).length>28000){pack.pop();}
  var control=new AbortController(),deadline=setTimeout(function(){control.abort();},20000);var run={pack:pack},again=false;inflight=run;
  var token=window.f3baseContexto?window.f3baseContexto.token(cfg,false):Promise.resolve(cfg.token);
  token.then(function(t){if(!permit()){throw new Error('consentimento_revogado');}return fetch(cfg.endpoint,{signal:control.signal,method:'POST',credentials:'same-origin',keepalive:true,headers:{'Content-Type':'application/json'},body:JSON.stringify({token:t,medicao:true,eventos:pack,renovacao:renewal})});}).then(function(r){
   var header=r.headers.get('Retry-After'),wait=Number(header);if(!Number.isFinite(wait)&&header){wait=(Date.parse(header)-Date.now())/1000;}
   return r.text().then(function(text){var body;try{body=JSON.parse(text);}catch(e){body={codigo:'resposta_nao_json'};}return {status:r.status,data:body,wait:Number.isFinite(wait)?Math.max(0,wait):0};});
  }).then(function(r){
   if(!permit()){clear();return;}var body=r.data||{},acks=Array.isArray(body.confirmados)?body.confirmados:[];
   var before=queue.length;queue=queue.filter(function(e){return !acks.some(function(a){return a.evento===e.evento&&a.sequencia===e.sequencia&&pack.some(function(p){return p===e;});});});counts.confirmados+=before-queue.length;persist();
   if(body.ok){renewal='';if(retry){counts.recuperacoes++;}retry=0;next=0;return;}
   if(r.status===403&&body.codigo==='token_invalido'&&!renewed&&window.f3baseContexto){renewal=typeof body.renovacao==='string'?body.renovacao:'';return window.f3baseContexto.token(cfg,true).then(function(){again=true;});}
   if(body.codigo==='medicao_nao_permitida'){clear();return;}
   if(r.status===400||r.status===409||r.status===413){reject(pack,body.codigo||'rejeitado',body.evento);retry=0;return;}
   var ex=new Error(body.codigo||'envio_nao_confirmado');ex.wait=r.wait;throw ex;
  }).catch(function(e){
   if(!permit()){clear();return;}counts.falhas++;retry=Math.min(8,retry+1);next=Date.now()+Math.max(Number(e.wait||0)*1000,Math.min(300000,2000*Math.pow(2,retry))*(0.8+Math.random()*0.4));persist();
  }).finally(function(){clearTimeout(deadline);if(inflight===run){inflight=null;}if(again){flush(urgent,true);}else if(queue.length&&permit()){if(urgentPending&&Date.now()>=next){urgentPending=false;flush(true);}else{urgentPending=false;schedule(1000);}}else{urgentPending=false;}});
 }
 function emit(type,detail){var c=context();if(!c||!c.visitante){return;}expire();if(queue.length>=100){counts.limite++;persist();return;}
  var pending=detail&&detail.complemento_pendente;if(detail){delete detail.complemento_pendente;}var e=Object.assign({evento:uuid(),tipo:type,caminho:cfg.caminho,criado_em:Math.floor(Date.now()/1000),formulario:'',formulario_revisao:'',correlacao:'',detalhe:'',valor:0,sequencia:1},c,detail||{});queue.push(e);persist();schedule(3000);if(type.indexOf('form_')===0){var key=e.formulario+'|'+e.correlacao,s=formStates.get(key)||{formulario:e.formulario,revisao:e.formulario_revisao,correlacao:e.correlacao,aberto:false,aceito:false,fechado:false};var names={form_vista:'aberto',form_dialogo:'aberto',form_inicio:'iniciado',form_erro:'recusado',form_aceito:'enviado',form_fechado:'fechado'},name=names[type];if(type==='form_vista'){s.vista=true;}if(type==='form_inicio'){s.iniciado=true;s.fechado=false;}if(type==='form_dialogo'&&!s.aceito){s.fechado=false;}if(type==='form_aceito'){s.aceito=!pending;}if(['form_complemento','form_pulada','form_conversa'].indexOf(type)>=0){s.aceito=true;}if(type==='form_fechado'){s.fechado=true;}if(name&&!(name==='aberto'&&s.aberto)){document.dispatchEvent(new CustomEvent('f3base-formulario-metrica',{detail:{evento:'f3base_form_'+name,formulario:e.formulario,codigo:e.detalhe,teste:e.contexto_teste}}));}if(name==='aberto'){s.aberto=true;}formStates.set(key,s);}return e;
 }
 document.addEventListener('f3base-contexto-pronto',function(){boot();});
 function boot(){if(!permit()){clear();return;}context();if(!pageSent){pageSent=true;emit('pagina',{detalhe:entradaComAncora?'ancora':''});}
  document.dispatchEvent(new CustomEvent('f3base-analise-pronta'));
  schedule(100);
 }
 var old=read();if(old&&Array.isArray(old.eventos)){queue=old.eventos.filter(function(e){return e&&typeof e.evento==='string';}).slice(-100).map(function(e){if(typeof e.contexto_teste!=='boolean'){e.contexto_teste=false;}return e;});expire();}
 document.addEventListener('f3base-tracking-pronto',boot);document.addEventListener('f3base-consentimento',boot);document.addEventListener('f3base-teste-alterado',function(){current='';boot();});
 window.addEventListener('load',function(){loaded=true;if(!initialDeadline){initialDeadline=Date.now()+ATRASO_INICIAL_MS;}schedule(0);});window.addEventListener('online',function(){next=0;flush(false);});window.addEventListener('pageshow',function(e){if(e.persisted){boot();}});
 window.addEventListener('pagehide',function(){document.dispatchEvent(new CustomEvent('f3base-analise-saida',{detail:{final:true}}));flush(true);});document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden'){document.dispatchEvent(new CustomEvent('f3base-analise-saida',{detail:{final:false}}));flush(true);}else{boot();}});
 document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a||a.closest('[data-f3base-formulario]')){return;}try{var u=new URL(a.href,location.href);if(u.origin!==location.origin||!/^https?:$/.test(u.protocol)||u.pathname===location.pathname||new TextEncoder().encode(u.pathname).length>190||/\/f3base\/(arquivo|download)/i.test(u.pathname)){return;}emit('clique_interno',{clique_rotulo:Array.from((a.getAttribute('aria-label')||a.textContent||'Link interno').replace(/\s+/g,' ').trim()).slice(0,160).join(''),clique_destino:u.pathname});flush(true);}catch(x){}},{capture:true});
 document.addEventListener('f3base:contato-capturado',function(){flush(true);});document.addEventListener('f3base-formulario-tentativa',function(){flush(true);});
 window.f3baseAnalise={interno:{permitir:permit,emitir:emit,formulariosEstados:function(){return formStates;}},oferta:function(type,details){if(['oferta_exibida','oferta_aberta','oferta_fechada'].indexOf(type)>=0){emit(type,details);}},contexto:context,atribuicao:function(){return window.f3baseContexto?window.f3baseContexto.atribuicao():{};},diagnostico:function(){return {pendentes:queue.length,em_voo:!!inflight,proxima_tentativa:next,prazo_inicial:initialDeadline,atraso_inicial_ms:ATRASO_INICIAL_MS,contagens:Object.assign({},counts),rejeitados:dead.slice()};},vital:function(name,value,seq){var c=context();if(!c){return;}var id=vitals[name]||(vitals[name]=uuid());emit('vital',{evento:id,detalhe:name,valor:value,sequencia:seq});if(document.visibilityState==='hidden'){Promise.resolve().then(function(){flush(true);});}}};
 if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);}else{boot();}
}());

/*! F3 Base — presença de recursos, API síncrona e retenção técnica durante carga. */
(function(w,d){'use strict';
 var api=w.f3baseAnalise;if(!api||w.f3baseRecursos){return;}
 var FORM_BUNDLE=/* f3module:formulario */false,OFFER_BUNDLE=/* f3module:oferta */false;
 var cfg=(w.f3baseAnaliseDados||{}).recursos||{},modules={},states=new WeakMap(),memory={},seenForms=new WeakSet(),seenOffers=new WeakSet(),pendingFocus=new WeakMap(),pendingDestinations=[],KEY='f3base_ofertas_v1';
 function uuid(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.from(a,function(x){return ('0'+x.toString(16)).slice(-2);}).join('');}
 function permit(){return api.interno.permitir();}
 function consent(){return !!(w.f3baseConsentimento&&w.f3baseConsentimento.permiteCategoria('medicao'));}
 function testing(){var c=api.contexto();return !!(c&&c.contexto_teste);}
 function storage(){if(!consent()||testing()){return memory;}try{return JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch(e){return memory;}}
 function mark(key,converted){var v=storage(),now=Date.now();v[key]=Object.assign(v[key]||{em:now},{convertida:converted||!!(v[key]&&v[key].convertida)});Object.keys(v).forEach(function(k){if(v[k].em<now-365*86400000){delete v[k];}});if(Object.keys(v).length>200){delete v[Object.keys(v).sort(function(a,b){return v[a].em-v[b].em;})[0]];}memory=v;if(consent()&&!testing()){try{localStorage.setItem(KEY,JSON.stringify(v));}catch(e){}}}
 function visible(f){if(!f||d.visibilityState==='hidden'||!f.isConnected){return false;}for(var n=f;n&&n.nodeType===1;n=n.parentElement){var s=getComputedStyle(n);if(n.hidden||n.getAttribute('aria-hidden')==='true'||s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0){return false;}}var r=f.getBoundingClientRect();return r.width>0&&r.height>0&&r.bottom>0&&r.right>0&&r.top<innerHeight&&r.left<innerWidth;}
 function offerState(n){if(!n){return null;}var key=n.getAttribute('data-f3base-oferta-id')||'',type=n.getAttribute('data-f3base-oferta'),forms=Array.from(n.querySelectorAll('[data-f3base-formulario]')).filter(function(f){return f.closest('[data-f3base-oferta]')===n;}),valid=/^[a-z][a-z0-9_-]{0,79}$/.test(key)&&['modal','folha','barra','bloco'].indexOf(type)>=0&&forms.length===1;
  if(valid){valid=d.querySelectorAll('[data-f3base-oferta-id="'+key+'"][data-f3base-oferta]').length===1;}
  var s=states.get(n);if(!s){s={id:key,type:type,form:forms[0],instance:uuid(),sent:{},valid:valid};states.set(n,s);}else{s.valid=valid&&s.id===key&&s.type===type&&s.form===forms[0];}return s;
 }
 function offerContext(f){var n=f.closest('[data-f3base-oferta]'),s=offerState(n);return s&&s.valid&&consent()?{id:s.id,tipo:s.type,instancia:s.instance}:null;}
 function forwardOffer(){if(!consent()){pendingDestinations=[];return;}if(w.f3baseOfertaEvento){pendingDestinations.splice(0).forEach(function(e){w.f3baseOfertaEvento(e[0],e[1],e[2]);});}}
 d.addEventListener('f3base-ofertas-destino-pronto',forwardOffer);
 function emitOffer(s,type,value,frame){if(!consent()||s.sent[type]){return;}var c=api.contexto();if(!c){return;}s.sent[type]=true;var offer={id:s.id,tipo:s.type,instancia:s.instance},form=frame?frame.formulario:s.form.dataset.f3baseFormulario;
  api.oferta(type,{formulario:form,formulario_revisao:frame?frame.revisao:(s.form.dataset.revisao||''),oferta:offer,detalhe:value||'',criado_em:Math.floor((frame?frame.at:Date.now())/1000)});
  var params={form_id:form,oferta_id:s.id,oferta_tipo:s.type,oferta_instancia:s.instance,navegacao:c.navegacao};if(type==='oferta_aberta'){params.gatilho=value;}if(type==='oferta_fechada'){params.motivo=value;}if(pendingDestinations.length<300){pendingDestinations.push([type,params,c.contexto_teste]);}forwardOffer();
 }
 function offerFrame(frame){var s=frame.state;if(!frame.valid||!s||!consent()){return;}var type=frame.type,v=frame.value;
  if(type==='aberta'&&['rolagem','saida','tempo','clique'].indexOf(v)<0){return;}
  if(type==='fechada'){if(s.sent.oferta_exibida&&['botao','esc','fora','navegacao'].indexOf(v)>=0){emitOffer(s,'oferta_fechada',v,frame);}return;}
  if(type==='aberta'&&!s.open){s.open=v;}if(frame.visible){emitOffer(s,'oferta_exibida','',frame);if(s.open){emitOffer(s,'oferta_aberta',s.open,frame);}if(s.sent.oferta_exibida){mark(s.id,false);}}
 }
 function finishOffers(){var m=module('ofertas');if(!m.handler&&permit()){m.pendentes.splice(0).forEach(offerFrame);}}
 var facade={contexto:offerContext,podeExibir:function(key,days){if(!/^[a-z][a-z0-9_-]{0,79}$/.test(key)){return false;}var v=storage()[key];return !v||(!v.convertida&&Date.now()-v.em>=Math.max(0,Math.min(365,Number(days)||0))*86400000);},registrarExibicao:function(key){if(/^[a-z][a-z0-9_-]{0,79}$/.test(key)){mark(key,false);}},diagnostico:function(){var nodes=Array.from(d.querySelectorAll('[data-f3base-oferta]'));return {marcacoes:nodes.length,invalidas:nodes.map(function(n){var s=offerState(n);return !s.valid?{id:s.id,motivos:['marcacao_invalida']}:null;}).filter(Boolean),instancias:nodes.map(function(n){var s=offerState(n);return {id:s.id,valida:s.valid,eventos:Object.keys(s.sent)};}),fonte:'ponte desta navegação; módulo '+((modules.ofertas||{}).status||'ausente')};}};
 w.f3baseOfertas=facade;
 function module(name){return modules[name]||(modules[name]={status:'ausente',tentativas:0,pendentes:[],handler:null,boot:null,limite:0});}
 function load(name){var m=module(name),c=cfg[name];if((name==='formularios'&&FORM_BUNDLE)||(name==='ofertas'&&OFFER_BUNDLE)){return;}if(m.handler||m.status==='carregando'||m.tentativas>=3||!c||!c.src){return;}var id=c.handle+'-js',tag=d.getElementById(id),own=!tag;m.status='carregando';m.tentativas++;
  if(!tag){tag=d.createElement('script');tag.id=id;tag.src=c.src;tag.async=true;tag.dataset.noOptimize='1';}
  tag.addEventListener('error',function(){m.status='falhou';if(own){tag.remove();}if(m.tentativas<3){setTimeout(function(){load(name);},250*m.tentativas);}} ,{once:true});
  tag.addEventListener('load',function(){if(!m.handler){m.status='sem_registro';}}, {once:true});
  if(own){(d.head||d.documentElement).appendChild(tag);}
 }
 function send(name,frame){var m=module(name);if(m.handler){m.handler(frame);return;}if(m.pendentes.length<1000){m.pendentes.push(frame);}else{m.limite++;}load(name);}
 function identify(f){if(w.f3baseFormularioInstancia){w.f3baseFormularioInstancia(f);}else if(f.elements.submissao&&!f.dataset.f3baseInstancia){if(!/^[a-f0-9]{32}$/.test(f.elements.submissao.value)){f.elements.submissao.value=uuid();}if(f.elements.token){f.elements.token.value='';}f.dataset.f3baseInstancia='1';}}
 function filled(x){return x.type==='file'?!!(x.files&&x.files.length):(/^(checkbox|radio)$/i.test(x.type)?x.checked:String(x.value||'').trim()!=='');}
 function technical(x){var m=(x&&x.name||'').match(/^campos\[([a-z][a-z0-9_-]{0,79})\](?:\[\])?$/);return m&&x.closest('.f3base-campo')&&!/^(hidden|password|submit|button)$/i.test(x.type||'')?m[1]:'';}
 function formFrame(type,f,event){var x={type:type,form:f,event:event,at:Date.now()};if(FORM_BUNDLE||module('formularios').handler){return x;}identify(f);var value=event&&event.detail||{},target=event&&event.target,fields=new Set();Array.from(f.elements).forEach(function(el){var n=technical(el);if(n&&filled(el)){fields.add(n);}});var offer=offerContext(f),detail=Object.assign(offer?{oferta:offer}:{},{formulario:f.dataset.f3baseFormulario,formulario_revisao:f.dataset.revisao||'',correlacao:f.elements.submissao&&f.elements.submissao.value||'',detalhe:value.codigo||'',complemento_pendente:!!(value.etapas_restantes&&value.etapas_restantes.length)}),position={ultimo_campo:technical(target)||pendingFocus.get(f)||'',etapa:w.f3baseFormularios?w.f3baseFormularios.etapa(f):1,campos_preenchidos:fields.size};if(f.dataset.analiseProva){position.formulario_prova=f.dataset.analiseProva;}
  if(technical(target)){pendingFocus.set(f,technical(target));}x.snapshot={detalhe:detail,posicao:position,campo:technical(target),preenchido:!!target&&filled(target)};x.detail={codigo:value.codigo||'',duplicado:!!value.duplicado};x.target=target;x.event=null;return x;
 }
 function formEvent(type,f,event){if(!f||!permit()){return;}api.contexto();send('formularios',formFrame(type,f,event));}
 ['focusin','input','change'].forEach(function(type){d.addEventListener(type,function(e){var f=e.target.closest&&e.target.closest('[data-f3base-formulario]');formEvent(type,f,e);},true);});
 ['dialogo-aberto','complemento-aceito','etapa-pulada','conversa-solicitada','inicio','tentativa','erro','aceito','fechado'].forEach(function(type){d.addEventListener('f3base-formulario-'+type,function(e){formEvent(type,e.target.closest&&e.target.closest('[data-f3base-formulario]'),e);},true);});
 d.addEventListener('close',function(e){if(e.target.tagName==='DIALOG'){e.target.querySelectorAll('[data-f3base-formulario]').forEach(function(f){formEvent('dialogo_fechado',f,e);});}},true);
 ['aberta','fechada'].forEach(function(type){d.addEventListener('f3base-oferta-'+type,function(e){var n=e.target.closest&&e.target.closest('[data-f3base-oferta]');if(!n){return;}var s=offerState(n);load('ofertas');if(permit()&&s&&s.valid){send('ofertas',{type:type,node:n,state:s,valid:s.valid,formulario:s.form.dataset.f3baseFormulario,revisao:s.form.dataset.revisao||'',value:e.detail&&(type==='aberta'?e.detail.gatilho:e.detail.motivo),visible:visible(s.form),at:Date.now()});}if(type==='fechada'){n.querySelectorAll('[data-f3base-formulario]').forEach(function(f){formEvent('oferta_fechada',f,e);});}},true);});
 function finishForms(){var m=module('formularios');if(m.handler||!permit()){return;}m.pendentes.splice(0).forEach(function(x){var frozen=x.snapshot;if(!frozen){return;}var info=Object.assign({},frozen.detalhe,{criado_em:Math.floor(x.at/1000)}),states=api.interno.formulariosEstados(),key=info.formulario+'|'+info.correlacao,s=states.get(key),type=x.type,pairs={vista:'form_vista',inicio:'form_inicio',tentativa:'form_tentativa',erro:'form_erro',aceito:'form_aceito','dialogo-aberto':'form_dialogo','complemento-aceito':'form_complemento','etapa-pulada':'form_pulada','conversa-solicitada':'form_conversa'};
   if(['focusin','input','change'].indexOf(type)>=0){if(type!=='focusin'&&frozen.campo&&frozen.preenchido&&(!s||!s.iniciado)){api.interno.emitir('form_inicio',info);s=states.get(key);}if(s){s.posicao=frozen.posicao;}return;}
   if(pairs[type]){if((type==='vista'&&s&&s.vista)||(type==='inicio'&&s&&s.iniciado)||(type==='aceito'&&x.detail.duplicado)){return;}api.interno.emitir(pairs[type],info);return;}
   var reasons={fechado:'adaptador_fechado',dialogo_fechado:'dialogo_fechado',oferta_fechada:'oferta_fechada',pagehide:'saida_sem_aceite_observado'};
   if(reasons[type]&&s&&(s.aberto||s.iniciado)&&!s.aceito&&!s.fechado&&(type!=='pagehide'||s.iniciado)){api.interno.emitir('form_fechado',Object.assign(info,frozen.posicao,{detalhe:reasons[type]}));}
  });}
 d.addEventListener('f3base-analise-saida',function(e){if(e.detail&&e.detail.final){var m=module('formularios');if(m.handler){m.handler({type:'pagehide',form:null,at:Date.now()});}else{var forms=new Set(d.querySelectorAll('[data-f3base-formulario]'));m.pendentes.forEach(function(x){if(x.form){forms.add(x.form);}});forms.forEach(function(f){formEvent('pagehide',f,e);});}}finishForms();finishOffers();});
 function scan(){var forms=d.querySelectorAll('[data-f3base-formulario]'),offers=d.querySelectorAll('[data-f3base-oferta]');if(forms.length){load('formularios');}if(offers.length){load('ofertas');}
  if(permit()){api.contexto();forms.forEach(function(f){if(!seenForms.has(f)&&visible(f)){seenForms.add(f);formEvent('vista',f);}});offers.forEach(function(n){var s=offerState(n);if(!seenOffers.has(n)&&s&&s.valid&&visible(s.form)){seenOffers.add(n);send('ofertas',{type:'detectada',node:n,state:s,valid:s.valid,formulario:s.form.dataset.f3baseFormulario,revisao:s.form.dataset.revisao||'',visible:true,at:Date.now()});}});}
  Object.keys(modules).forEach(function(n){var m=modules[n];if(m.boot){m.boot();}});
 }
 d.addEventListener('f3base-analise-reinicio',function(){Object.keys(modules).forEach(function(n){module(n).pendentes=[];});seenForms=new WeakSet();seenOffers=new WeakSet();pendingFocus=new WeakMap();});
 d.addEventListener('f3base-consentimento',function(){if(!consent()){memory={};pendingDestinations=[];Object.keys(modules).forEach(function(n){module(n).pendentes=[];});try{localStorage.removeItem(KEY);}catch(e){}}scan();});
 d.addEventListener('f3base-analise-pronta',scan);
 if(w.MutationObserver){new MutationObserver(function(changes){if(changes.some(function(x){return x.type==='childList'||/^data-f3base-(formulario|oferta)/.test(x.attributeName||'');})){scan();}}).observe(d.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['data-f3base-formulario','data-f3base-oferta','data-f3base-oferta-id']});}
 w.f3baseRecursos={identificar:identify,pronto:function(name){return !!module(name).handler;},registrar:function(name,handler,boot){var m=module(name);if(m.handler){return;}m.handler=handler;m.boot=boot||null;m.status='pronto';var pending=m.pendentes.splice(0);pending.forEach(handler);},ofertas:{states:states,mark:mark,storage:storage,context:offerContext,visible:visible,emit:emitOffer,frame:offerFrame},diagnostico:function(){var out={};Object.keys(modules).forEach(function(n){var m=modules[n];out[n]={estado:m.status,tentativas:m.tentativas,pendentes:m.pendentes.length,limite:m.limite};});return out;}};
 scan();
})(window,document);
