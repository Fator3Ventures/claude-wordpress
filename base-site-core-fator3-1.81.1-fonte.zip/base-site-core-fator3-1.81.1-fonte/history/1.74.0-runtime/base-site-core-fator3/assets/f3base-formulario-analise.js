/*! F3 Base — medição de formulários carregada por presença. GPL-2.0-or-later. */
(function(w,d){'use strict';
 var api=w.f3baseAnalise,rec=w.f3baseRecursos;if(!api||!rec||rec.pronto('formularios')){return;}
 var permit=api.interno.permitir,context=api.contexto,frame=null,views=new WeakSet(),observer=null;
 var formStates=api.interno.formulariosEstados(),formFocus=new WeakMap(),formFields=new WeakMap();
 // Membership is invalidated by DOM changes; typing updates only the touched
 // logical field. A final full reconciliation preserves programmatic changes.
 function fields(f){var e=formFields.get(f);if(e&&e.observer&&e.observer.takeRecords().length){e.dirty=true;}if(!e){e={dirty:true,items:[],groups:new Map(),filled:new Set(),observer:null};if(w.MutationObserver){e.observer=new MutationObserver(function(){e.dirty=true;});e.observer.observe(f,{childList:true,subtree:true,attributes:true,attributeFilter:['name','class','type']});}formFields.set(f,e);}if(e.dirty||!e.observer){e.items=Array.from(f.querySelectorAll('.f3base-campo input[name],.f3base-campo textarea[name],.f3base-campo select[name]'));e.groups=new Map();e.filled=new Set();e.items.forEach(function(x){var n=technicalField(x);if(!n){return;}if(!e.groups.has(n)){e.groups.set(n,[]);}e.groups.get(n).push(x);if(filledField(x)){e.filled.add(n);}});e.dirty=false;}return e;}
 function technicalField(x){var m=(x&&x.name||'').match(/^campos\[([a-z][a-z0-9_-]{0,79})\](?:\[\])?$/);return m&&x.closest('.f3base-campo')&&!/^(hidden|password|submit|button)$/i.test(x.type||'')?m[1]:'';}
 function filledField(x){return x.type==='file'?!!(x.files&&x.files.length):(/^(checkbox|radio)$/i.test(x.type)?x.checked:String(x.value||'').trim()!=='');}
 function formPosition(f,target){var e=fields(f);if(target){var n=technicalField(target);if((e.groups.get(n)||[]).some(filledField)){e.filled.add(n);}else{e.filled.delete(n);}}else{e.filled=new Set();e.groups.forEach(function(items,n){if(items.some(filledField)){e.filled.add(n);}});}
  var position={ultimo_campo:formFocus.get(f)||'',etapa:w.f3baseFormularios?w.f3baseFormularios.etapa(f):1,campos_preenchidos:e.filled.size};if(f.dataset.analiseProva){position.formulario_prova=f.dataset.analiseProva;}return position;
 }

 function formDetail(f,d){rec.identificar(f);var offer=window.f3baseOfertas&&window.f3baseOfertas.contexto(f);return Object.assign(offer?{oferta:offer}:{},{formulario:f.dataset.f3baseFormulario,formulario_revisao:f.dataset.revisao||'',correlacao:(f.elements.submissao&&f.elements.submissao.value)||'',detalhe:(d&&d.codigo)||'',complemento_pendente:!!(d&&d.etapas_restantes&&d.etapas_restantes.length)});}

 function fecharForm(f,motivo,soIniciados){formStates.forEach(function(s){if((!soIniciados||s.iniciado)&&(s.aberto||s.iniciado)&&!s.aceito&&!s.fechado&&(!f||(f.dataset.f3baseFormulario===s.formulario&&((f.elements.submissao&&f.elements.submissao.value)||'')===s.correlacao))){var el=f; if(!el){document.querySelectorAll('[data-f3base-formulario]').forEach(function(x){if(x.dataset.f3baseFormulario===s.formulario&&((x.elements.submissao&&x.elements.submissao.value)||'')===s.correlacao){el=x;}});}if(!el){el=s.element||null;}emit('form_fechado',Object.assign({formulario:s.formulario,formulario_revisao:s.revisao,correlacao:s.correlacao,detalhe:motivo},el?position(el):(s.posicao||{ultimo_campo:'',etapa:1,campos_preenchidos:0})));}});}

 function emit(type,detail){if(frame){detail=Object.assign({},detail,{criado_em:Math.floor(frame.at/1000)});}var e=api.interno.emitir(type,detail);if(!e){return;}

 }
 function position(f,target){return frame&&frame.snapshot&&frame.form===f?frame.snapshot.posicao:formPosition(f,target);}
 function detail(f,value){return frame&&frame.snapshot&&frame.form===f?Object.assign({},frame.snapshot.detalhe):formDetail(f,value);}
 function reset(){formStates=api.interno.formulariosEstados();formFocus=new WeakMap();views=new WeakSet();if(observer){observer.disconnect();}}
 function boot(){if(!permit()){reset();return;}context();
  if(!observer&&w.IntersectionObserver){observer=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting&&permit()&&!views.has(e.target)){views.add(e.target);emit('form_vista',formDetail(e.target));observer.unobserve(e.target);}});},{threshold:0.1});}
  d.querySelectorAll('[data-f3base-formulario]').forEach(function(f){var info=formDetail(f),state=formStates.get(info.formulario+'|'+info.correlacao);if(views.has(f)||(state&&state.vista)){views.add(f);return;}if(observer){observer.observe(f);}else{views.add(f);emit('form_vista',formDetail(f));}});
 }
 function handle(x){if(!permit()){return;}context();frame=x;try{
  var f=x.form,e=x.event||{},name=x.type,value=x.detail||e.detail||{};
  if(['focusin','input','change'].indexOf(name)>=0){var target=e.target||x.target,field=x.snapshot?x.snapshot.campo:technicalField(target);if(!field){return;}formFocus.set(f,field);var info=detail(f),key=info.formulario+'|'+info.correlacao,s=formStates.get(key),filled=x.snapshot?x.snapshot.preenchido:filledField(target);if(name!=='focusin'&&filled&&(!s||!s.iniciado)){emit('form_inicio',info);s=formStates.get(key);}if(s){s.element=f;s.posicao=position(f,target);if(s.iniciado&&!s.aceito){s.fechado=false;}}return;}
  var pairs={'dialogo-aberto':'form_dialogo','complemento-aceito':'form_complemento','etapa-pulada':'form_pulada','conversa-solicitada':'form_conversa'};
  if(pairs[name]){emit(pairs[name],detail(f,value));return;}
  if(['inicio','tentativa','erro','aceito'].indexOf(name)>=0){var info=detail(f,value),state=formStates.get(info.formulario+'|'+info.correlacao);if(name==='inicio'&&state&&state.iniciado){return;}if(name!=='aceito'||!value.duplicado){emit('form_'+name,info);}return;}
  if(name==='vista'){var info=detail(f),state=formStates.get(info.formulario+'|'+info.correlacao);if(!views.has(f)&&!(state&&state.vista)){views.add(f);emit('form_vista',detail(f));}return;}
  if(name==='fechado'){fecharForm(f,'adaptador_fechado');}
  if(name==='dialogo_fechado'){fecharForm(f,'dialogo_fechado');}
  if(name==='oferta_fechada'){fecharForm(f,'oferta_fechada');}
  if(name==='pagehide'){fecharForm(f,'saida_sem_aceite_observado',true);}
 }finally{frame=null;}}
 d.addEventListener('f3base-analise-reinicio',reset);
 d.addEventListener('f3base-analise-pronta',boot);
 rec.registrar('formularios',handle,boot);boot();
})(window,document);
