# Fator3 Site Core 1.72.1

Instale pelo painel de plugins em WordPress 7.1.4 ou superior, com PHP 8.3 ou superior. A atualização direta parte da 1.72.0 e mantém o contrato administrativo 8.34.0.

A 1.72.1 corrige a duplicação do painel de relatórios. Em **Site Core → Relatórios → Técnico**, selecione **Web Vitals por versão** para filtrar as amostras em uma única tabela. Consulte docs/DOCUMENTACAO.md para o índice e docs/RELEASE-1.72.1.md para a correção e os critérios de conferência.
