/* GPL-2.0-or-later. Filtro local; não altera escolhas. */
document.addEventListener('input',function(e){var id=e.target.getAttribute('data-f3base-buscar-blocos');if(!id)return;var root=document.getElementById(id),q=e.target.value.toLowerCase();if(root)root.querySelectorAll('[data-f3base-bloco]').forEach(function(n){n.style.display=!n.querySelector('input:checked')&&n.textContent.toLowerCase().indexOf(q)<0?'none':'block';});});

// Renew only the server-side form context. Secrets remain in the current input element.
document.querySelectorAll('input[name="f3base_contexto"]').forEach(function (input) {
  var form = input.form, ready = false, busy = false;
  if (!form) return;
  if (form.hasAttribute('data-f3base-meta-edicao')) {
    // Keep an ordered snapshot, including checkbox fallbacks and repeated names.
    function options(data) {
      const groups = new Map();
      for (const [key, value] of data) {
        const match = /^f3base(?:_apagar)?\[([^\]]+)\]/.exec(key);
        if (!match) continue;
        const name = match[1];
        if (!groups.has(name)) groups.set(name, []);
        groups.get(name).push([key, value]);
      }
      return groups;
    }
    const original = options(new FormData(form));
    form.addEventListener('submit', function () {
      form.addEventListener('formdata', function (event) {
        const data = event.formData;
        for (const [name, fields] of options(data)) {
          const row = document.getElementById('linha-' + name);
          if (row?.querySelector('[data-f3base-reaplicar]')?.checked ||
              JSON.stringify(fields) !== JSON.stringify(original.get(name))) continue;
          for (const [key] of fields) data.delete(key);
          data.delete('f3base_revisao[' + name + ']');
        }
      }, {once: true});
    });
    // admin-post verifies the signed-in user, nonce, context, sentinel and each edited revision.
    return;
  }
  form.addEventListener('submit', async function (event) {
    if (ready) return;
    event.preventDefault(); if (busy) return; busy = true;
    var notice = form.querySelector('[data-f3base-contexto-aviso]');
    try {
      var body = new URLSearchParams({action:'f3base_form_renovar',contexto:input.value,nonce:form.elements.f3base_renovar_nonce.value});
      var response = await fetch(ajaxurl, {method:'POST',credentials:'same-origin',body:body});
      var result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.data && result.data.mensagem || 'Não foi possível renovar o formulário.');
      ready = true; form.requestSubmit(event.submitter || undefined);
    } catch (error) { if (notice) { notice.textContent = error.message; notice.setAttribute('role','alert'); } }
    finally { busy = false; }
  });
});
