# Triagem dos achados PHPCS/WPCS — Fator3 Site Core 1.78.0 (PHP 8.3, WordPress 7.1.4)

Escopo: somente leitura. Nenhum arquivo do plugin foi alterado, sem rede, sem commits. Código analisado: cópia intocada em `/home/claude/work/fonte/base-site-core-fator3-1.78.0-fonte/work/plugin/base-site-core-fator3` (o plugin do laboratório é idêntico a ela: `diff -rq` vazio). Scripts de reprodução em `/home/claude/work/scripts/triagem/` (h1..h7.php). Saídas intermediárias do PHPCS em `/home/claude/work/scripts/triagem/` (sql-nonce.json, input.json).

**Resultado geral: 0 defeitos confirmados.** Todos os 23 achados de placeholders, os 225 de SQL, os 136 de escape, os 2 de redirecionamento e o de `InputNotValidated` são falsos positivos do tipo "o sniff não enxerga o valor dinâmico". Há 3 suspeitas de baixa gravidade (seção 2), nenhuma com caminho de dado comprovado até um sink inseguro.

Comportamento de `wpdb::prepare` em 7.1.4 (lido em `wp-includes/class-wpdb.php:1458-1750`, não presumido):
- Contagem de placeholders (`%s %d %f %i`, `%%` descontado) diferente do número de argumentos dispara `_doing_it_wrong` ("The query does not contain the correct number of placeholders...").
- Faltam argumentos: retorna `''` (query vazia) quando não há placeholder numerado que cubra; a consulta falha silenciosamente.
- Sobram argumentos: aviso, mas `vsprintf` ignora os extras e a query roda.
- Argumento de array/objeto: "Unsupported value type", vira `''`.
- Quando os argumentos vêm como 1 array único, são desempacotados (`passed_as_array`); com `...$array` de chaves string, o PHP 8.1+ os passa como argumentos nomeados e a contagem continua valendo.
- Saída leva `add_placeholder_escape` (um `%` vindo de dado vira hash), por isso fragmento já preparado pode entrar em outro `prepare()` sem ser reinterpretado.

Controle do detector (h1/h6): `prepare('SELECT %s,%s','a')` e `prepare('...8 ph...', 7 args)` foram capturados por `doing_it_wrong_run` ("(2) ... (1)" e "(8) ... (7)"). O detector acusa descompasso; as chamadas reais não acusaram nenhum.

---

## 1. DEFEITOS CONFIRMADOS

| arquivo:linha | regra | origem do dado | efeito concreto | correção mínima | como reproduzir |
|---|---|---|---|---|---|
| (nenhum) | — | — | — | — | — |

Nenhum item atingiu o critério de prova (caminho do dado até a origem + linha onde falta o tratamento).

## 2. SUSPEITAS

| arquivo:linha | por que suspeita | o que falta verificar |
|---|---|---|
| `includes/class-f3base-formularios.php:615` (`InputNotSanitized`/`MissingUnslash` em `$_SERVER['HTTP_REFERER']`) | Quando a página do token não está publicada, `lead.pagina` é montada com o **path do Referer** (controlado por quem posta; só exige origem própria, `Testes::origem_propria`). Esse texto é gravado no lead (via prepare, seguro) e depois exibido. | Sinks HTML verificados e escapados: `Email::corpo`, `Contato_Apresentacao::html_contato`, ficha do lead em `leads-admin.php:225-262` (teste dinâmico h5.php com `<script>`/`onerror` em nome/e-mail/telefone/empresa/página: saída escapada, sem tag crua). Não li o formatador Slack (`F3Base_Slack::mensagens`) nem o payload Pipedrive para esse campo; ambos não são HTML. Gravidade baixa. |
| `includes/trait-f3base-qualidade-interface.php:49,53,58` (12 `OutputNotEscaped`: `$i`) | `name="etapas['.$i.']..."`, `regras['.$i.']`, `autorizacoes['.$i.']` imprimem a **chave** do array sem `esc_attr`. As chaves vêm de option do plugin; são inteiros se a option for lista. Só tela de `manage_options`. | Confirmar que a gravação da option (`F3Base_Options::gravar` com schema `type:array`) sempre normaliza para lista (`array_values`). O `POST` da própria tela reconstrói com `[]`, mas a gravação por ability/REST não foi lida. Mesmo no pior caso é self-XSS de administrador. |
| REST públicas `POST` com `__return_true` (`/formularios/tentativas`, `/formularios/enviar`, `/formularios/complementar`, `/consentimento`, `/contexto-diagnostico`, `/leads/contexto`) | Sem nonce, como esperado para visitante anônimo. A prova é token HMAC efêmero (`/lead`, `/comportamento`, `/esquecer`, `/analise`, `/meta-eventos`, `/formularios/complementar`), segredo/assinatura (`/anuncios/google`, `/anuncios/linkedin/notificacoes`, `/pipedrive/qualidade`) ou só `Origin` igual ao site + rate limit (`/consentimento`, `/contexto-diagnostico`, `/leads/contexto`). `Origin` impede CSRF de navegador, não cliente que forja cabeçalho. | Li o cabeçalho de validação de 11 das 14 rotas. Não li o corpo completo de `/formularios/tentativas`, `/formularios/enviar` e do ramo principal de `/consentimento`. Nenhuma grava dado de outro visitante sem prova (a revogação exige comprovante hex de 64 caracteres). |

## 3. FALSOS POSITIVOS POR CLASSE

**PreparedSQLPlaceholders.ReplacementsWrongNumber (21) e UnfinishedPrepare (2): 23 FP.**
Motivo comum: o sniff conta placeholders no literal; aqui o número é dinâmico (`array_fill(0,count($x),'%s')`, `implode`, `...$args`, `array_merge`, `$where` acumulado) e **bate em execução**. Conferi cada chamada inteira (placeholders × argumentos, na ordem). Exemplos: `class-f3base-medicao-saude.php:11,12` (14 `%d` dos 7 dias + 3/4 fixos = 17/18 argumentos), `class-f3base-execucoes.php:116` (9 ou 10 conforme `$occ`), `class-f3base-sessoes.php:83` (`%i` + 1 formato por coluna), `trait-f3base-slack-gestao.php:29` (`IN (%s,...)` com 1..50 ids hex de 64 caracteres validados antes), `class-f3base-acessos-coleta.php:184` (25 `%s` por linha × linhas do lote = 25 valores por linha).
Execução no lab (h1/h2): `Medicao_Saude::consultar`, `Avisos::consultar`, `Sondas_Http::consultar`, `Email_Site::ler`, `Arquivos_Servico::listar`, `Clarity_Acervo::contexto_core`, `Desfechos::relatorio`, `Sessoes::revogacao`, `Options::fotografias_brutas`, `Slack_Gestao::selecionar_gestao`: 0 avisos de `prepare`. Os demais por leitura; `execucoes.php:116` e as UPDATE com `LIKE '%%..%%'` por réplica do template (h6.php), 0 avisos.
Extra (não pedido): `LikeWildcardsInQuery` (4) em `automacao-provavel.php:37`, `pipedrive-fila.php:87`, `slack-manutencao.php:42`: `%%` literal escapado, contagem confere. Falso positivo.

**PreparedSQL.NotPrepared (122) + InterpolatedNotPrepared (103) = 225: 225 FP.**
Motivos comuns (nenhum valor externo chega à string SQL cru):
1. Nome de tabela de `$wpdb->prefix`/constante/`self::tabela()` concatenado: `audiencia-exclusoes.php:15`, `capi-fila.php:77`, `modulo-acessos-servidor.php:157`, `email-novo-lead.php:234`, `wp-mail.php:182`, `vitais.php:170`.
2. `$where` acumulado só com `$wpdb->prepare(' AND coluna=%s', valor)` e coluna de lista fixa: `agentes.php:75`, `execucoes.php:159`, `formulario-tentativas.php:125,142`, `vitais.php:203`, `inteligencia.php:117`, `qualidade.php:124`, `relatorios.php:97,104,118`, `trait-f3base-slack-gestao.php:11,12`.
3. Fragmentos de helpers validados: `Testes::sql` (regex de coluna + `in_array` de segmento), `Inteligencia::exclusoes_sql`, `Caminho_Lead::filtro_fila` (regex na tabela + `%i`), `Contatos_Sessoes::filtro_sql`, `Sessao_Contexto::filtro_sql`, `Sessoes::filtro_sql`, `Agentes_Classificacao::expressao/fonte`.
4. Placeholders dinâmicos (`IN (%s,%s,..)`, CASE por dia, VALUES em lote) com argumentos em `array_merge`/`...`: `qualidade.php:130-132`, `contato-entregas.php:25-27`, `desfechos.php:100`, `meta-transporte.php:148,152,176`.
5. Filtros de entrada fechados antes da SQL: `rest_validate_value_from_schema` com `additionalProperties:false` (`agentes.php:67`, `formulario-tentativas.php:129`), `preg_match` de hex/data, `in_array` estrito, `(int)`.
6. SQL fixa sem dado: `COMMIT`, `ROLLBACK`, `SAVEPOINT 'f3_core_'.bin2hex(random_bytes(12))`, `LOCK TABLES` com `%i`, `SHOW COLUMNS` validado por `/^[a-z_]+$/D` (`acessos-legado.php:39`).
Reprodução hostil (h2.php): `record_id`/`caminho`/`classe`/`estado`/`id` = `x' OR 1=1 -- %s %d %1$s` em `Avisos`, `Slack_Manutencao::listar`, `Sondas_Http::consultar`, `Arquivos_Servico::listar`, `Desfechos::relatorio`, `Contato_Entregas::lote`, `Clarity_Acervo::contexto_core`: a consulta gerada fica `record_id='x\' OR 1=1 -- %s %d %1$s'` (aspas escapadas, sem aviso). `Arquivos_Servico::listar(id=array)` gera "Unsupported value type" e `id=''` (resultado vazio, sem injeção).

**EscapeOutput.OutputNotEscaped (114) + ExceptionNotEscaped (22) = 136: 136 FP.**
Motivos comuns:
1. Chave/rótulo de `foreach` sobre array literal (`$k`, `$v`, `$key`, `$tipo`, `$label`): `agentes.php:94,95`, `avisos.php:245`, `ga4.php:129`, `politica.php:79`, `relatorios.php:239,240,242`, `leads-admin.php:273`.
2. Retorno de função que já escapa: `self::link()` de `medicao-editorial-ui.php` aplica `esc_attr`/`esc_url`/`esc_html` (cobre ~44 dos 64 pontos); `Config_UI::estado` (só `esc_html`), `Config_UI::html`, `Config_UI::status` (`esc_html`), `Email::corpo`, `Contato_Apresentacao::html_contato`.
3. Inteiro/hash/base64: `$i+1`, `(int)$id`, `$r['http']`, `hash('sha256',..)` em `desempenho.php:182`, `base64_encode(wp_json_encode())` em `ofertas.php:95`, `max(1,round(..))` em `medicao-editorial-ui.php:81`, `printf('%d')` em `vitais.php:366`.
4. `$ajuda` = `' aria-describedby="'.esc_attr(..).'"'` (`config-central.php:47,49,53`); `$markup` de `verificacao-dominio.php:292` já vem de `esc_attr` (o `phpcs:ignore` lá usa o código errado `EscapingOutput`; o certo é `EscapeOutput.OutputNotEscaped`, por isso o achado persiste).
5. `ExceptionNotEscaped` (22): a mensagem só é exibida depois de `esc_html`/`esc_attr` (`integracoes.php:189` `wp_die(esc_html(...))`; `admin-tela.php:551` `esc_attr($e['caminho'])`, `esc_html($e['motivo'])`); em `editorial-relatorios.php:74-105` o `$d` é array de diagnóstico, não mensagem.
Reprodução (h4/h5/h7): `Config_UI::estado(['a'=>'<script>alert(1)</script>','b'=>['"><img src=x onerror=alert(1)>'=>'x']])` devolve `&lt;script&gt;...` e `&quot;&gt;&lt;Img ...`; `Email::corpo` e `html_contato` com lead de nome `"><script>alert(1)</script>`, e-mail com `onerror`, empresa com `onmouseover`: 0 `<script` cru e 0 atributo de evento; `Medicao_Editorial_UI::link()` com label/classe/caminho hostis sai escapado.

**SafeRedirect (2): 2 FP.**
- `class-f3base-formularios.php:757`: destino = `$r['redirecionar']`, montado em `Confirmacao::preparar` a partir de `confirmacao_url` do **formulário** (configuração de administrador, não de visitante), re-normalizada em execução por `Confirmacao::normalizar` (sem `//`, sem userinfo, sem `\`, http/https, mesmo host ou `https` + host em `f3base_confirmacao_hosts`, bloqueia `wp-admin`/`wp-login`/`wp-json`). `wp_redirect` em vez de `wp_safe_redirect` é intencional para o host externo autorizado. Reprodução: `https://evil.example/x`, `//evil.example/x`, `https://127.0.0.1:8137@evil.example/`, `http://127.0.0.1:8137\@evil.example/`, `javascript:alert(1)`, `/wp-admin/x` => `''`; `/obrigado` => `http://127.0.0.1:8137/obrigado`.
- `class-f3base-modulo-redirects.php:389`: destino = regra declarada (option) ou permalink do slug antigo, passado por `Redirects_Servico::preservar_query` -> `destino()` (host próprio ou `f3base_redirects_hosts`, bloqueio de controle/CRLF/`\`/`//`/`%2f`). A query do visitante só é anexada depois da validação e se passar em `query_valida` (sem controle, sem `%` malformado, até 8192). Reprodução: `https://evil.example/x`, `//evil.example`, `/\evil.example`, `/%2f%2fevil.example`, `/a%0d%0aSet-Cookie:x=1` => `NULL`; `preservar_query('/nova','/?utm=1&x=%0d%0a')` => `'/nova'`.

**ValidatedSanitizedInput.InputNotValidated (1): FP.** `desempenho.php:181` lê `$_SERVER['HTTP_X_F3BASE_DESEMPENHO']` sem `isset`, mas a linha 180 (`self::sonda()`) já exige o cabeçalho com formato `^\d{10}\.[a-f0-9]{32}\.[a-f0-9]{64}$` e HMAC (`hash_equals`) sobre o path; o valor impresso é `hash('sha256', ...)`. Reprodução: `Desempenho::imprimir()` sem cabeçalho => saída `""`, sem notice.

**InputNotSanitized (188) / MissingUnslash (204): amostragem dirigida, 0 defeitos.** Motivos comuns: valor usado só como booleano/seletor de lista fixa (`$_GET['page']`, `['aba']`, `['secao']`, `['area']` com `in_array`/`isset(self::AREAS[..])`), inteiro por cast (`pagina`), regex hex antes do uso (`$_GET['g']`, `['ref']`, `['f3base_confirmacao_ref']`, `['f3base_robots_sonda']`, cookie `f3base_capi_ref`), `sanitize_*` aplicado (a ausência de `wp_unslash` só afeta barra invertida em token hex/revisão), HMAC com `hash_equals` (`conteudo-privado.php:80-83`), `Host` usado só em comparação e o redirecionamento vai sempre para `home_url()` (`testes.php:88`; reprodução: Host `evil.example` => `http://127.0.0.1:8137/f3base-teste/`), `DOCUMENT_ROOT`/`SERVER_SOFTWARE` apenas em verificação local, `REQUEST_METHOD` já restrito a GET/HEAD (`sondas-http.php:47`). Busquei `$_GET/$_POST/$_REQUEST/$_COOKIE/$_SERVER` perto de `file_get_contents|fopen|unlink|include|require|header|setcookie|exec|unserialize|curl|wp_remote`: sem caminho de dado externo para esses sinks (os `maybe_unserialize` são de options do próprio plugin). CSV de contatos usa `celula_csv` contra injeção de fórmula.

**NonceVerification.Missing (52): 52 FP.** Todos em handlers que já têm `current_user_can('manage_options'|capacidade própria)` + `check_admin_referer`/`check_ajax_referer`/`wp_verify_nonce` no ponto de entrada, e o sniff não segue a chamada: `Avisos::salvar` (`check_admin_referer('f3base-avisos')`, :234), `Qualidade::post` (`'f3base-qualidade'`, 29 pontos), `Linkedin_Admin::post` (`'f3base-linkedin'`), `Admin_Clarity::processar` (`wp_verify_nonce(.., ACAO)`, :9), `Credenciais::confirmacao` (só lê a prova HMAC; o formulário original verifica nonce), `Modulo_Sessao_De_Login::lembrar` (só lê `log` no login para decidir `rememberme`, não grava estado). Enumeração dos 67 `admin_post_*`/`wp_ajax_*` (script `handlers.py`): todos com capacidade+nonce, exceto os que o heurístico marcou para conferir à mão e que conferi: `Config_Central::salvar` (cap + `'f3base-config-central'`), `Admin_Acessos::guarda` (cap + nonce), `wp_ajax_f3base_anuncios_catalogo` e `wp_ajax_f3base_navegacao_verificar` (só nonce no hook, mas `Anuncios_Selecao::consultar` e `Navegacao::verificar_publica` exigem `manage_options` dentro), `Conteudo_Privado::download` e `Formularios::post/confirmacao` (públicos: HMAC `hash_equals` + regex hex; token HMAC em `receber()`).

## 4. TOTAIS POR REGRA

| regra | achados | analisados | defeito | suspeita | falso positivo | NÃO analisados |
|---|---|---|---|---|---|---|
| PreparedSQLPlaceholders.ReplacementsWrongNumber | 21 | 21 | 0 | 0 | 21 | 0 |
| PreparedSQLPlaceholders.UnfinishedPrepare | 2 | 2 | 0 | 0 | 2 | 0 |
| PreparedSQLPlaceholders.LikeWildcardsInQuery (extra) | 4 | 4 | 0 | 0 | 4 | 0 |
| PreparedSQL.NotPrepared | 122 | 122 | 0 | 0 | 122 | 0 (ver nota 1) |
| PreparedSQL.InterpolatedNotPrepared | 103 | 103 | 0 | 0 | 103 | 0 (ver nota 1) |
| EscapeOutput.OutputNotEscaped | 114 | 114 | 0 | 12 (qualidade-interface, ver seção 2, risco baixo/admin) | 102 | 0 |
| EscapeOutput.ExceptionNotEscaped | 22 | 22 | 0 | 0 | 22 | 0 |
| SafeRedirect | 2 | 2 | 0 | 0 | 2 | 0 |
| ValidatedSanitizedInput.InputNotValidated | 1 | 1 | 0 | 0 | 1 | 0 |
| ValidatedSanitizedInput.InputNotSanitized | 188 | ~188 por agrupamento (176 pares arquivo/superglobal distintos) | 0 | 1 (formularios.php:615) | 187 | 0 por contagem; leitura individual só dos ~45 que tocam sinks |
| ValidatedSanitizedInput.MissingUnslash | 204 | idem (mesmos pares) | 0 | 0 | 204 | 0 por contagem; idem |
| NonceVerification.Missing | 52 | 52 | 0 | 0 | 52 | 0 |
| NonceVerification.Recommended (GET, fora do pedido) | 142 | 0 | — | — | — | **142 não analisados** (leitura por GET não conta, conforme o escopo) |
| Rotas REST públicas (extra, via `get_routes()` no lab) | 14 POST/GET abertas | 14 (cabeçalho) / 11 (validação lida) | 0 | 1 (agregada, seção 2) | — | corpo completo de 3 rotas |

Notas de limite:
1. SQL: os 225 pontos foram lidos (linha e variável interpolada). Em ~40 deles (nome de tabela, `COMMIT`, `SAVEPOINT`, `LOCK TABLES`) concluí pelo padrão após confirmar a origem da variável por leitura/grep, sem seguir toda cadeia de chamada. Nos fragmentos de `$where`, segui a construção até a origem (prepare com coluna de lista fixa ou helper validado). A execução com valor hostil cobriu 9 consultas; as demais são por leitura.
2. `InputNotSanitized`/`MissingUnslash` foram tratadas por amostragem dirigida (pedido do escopo): agrupei os 392 pontos em 176 pares (arquivo, superglobal), li o contexto de todos os pares e a função inteira dos que chegam a banco, arquivo, redirect, cabeçalho ou comparação de segurança. Pontos em telas administrativas que só alimentam `sanitize_*`/schema não foram lidos um a um.
3. Relatórios::dados (`relatorios.php`) não foi executado no lab (meu fixture falhou em `Inteligencia::anotacoes`); `relatorios.php:209` e `sessoes.php:83,101,110`, `contato-apresentacao.php:66,68`, `censo-demonstrativo.php:131`, `linkedin-campanhas.php:136`, `operacao-intencoes.php:102` ficaram só por leitura (placeholders × argumentos conferidos na ordem).
