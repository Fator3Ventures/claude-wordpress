# Site Core 1.81.0

Base oficial 1.80.0. Normas de plugins Fator3, revisão 5. Pedidos da lista de 11/11/2026, 12:03:33. O 389 demanda apenas a origem da sonda. Os itens 390 e 391 compartilham a resposta Origem e exigem edição posterior das respostas originais.

Os contratos em referência são os três encaminhamentos para o Core dos pacotes Meta, LinkedIn e Google. A parte consumidora valida a seleção de conta. A parte comercial resolve a oportunidade no diário do Core. Verificar fronteiras e entregas repetidas com transporte isolado, instalação limpa, atualização da base e leitura do instalador no site de teste.

## Patch 1.81.1
A bancada identificou uma inversão após uma hora de espera comercial. Aguardar o estado da oportunidade e respeitar a sequência em retentativas do Slack. Verificar a mesma resposta em threads antigos e as duas bases do ciclo.
