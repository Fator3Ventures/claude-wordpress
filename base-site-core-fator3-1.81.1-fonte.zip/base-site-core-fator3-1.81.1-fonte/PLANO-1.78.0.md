# Site Core 1.78.0 · planejamento · 10/11/2026

Base oficial 1.77.0. Padrão e instruções, revisão 5. O impacto 2.20.0 rev. 3 consolida o pedido de autoria do 2.19.0 rev. 2 e traz C6 e C7. O MCP 0.43.0 preserva as chamadas utilizadas. Validar as três correções no dono e executar instalação limpa, migração e requisições reais. A API de leitura do servidor pode informar o HTTP exato do diretório. Nenhuma alteração de configuração requerida nos outros provedores.

Verificar separadamente o filtro editorial do tema distribuído pelo Implantador: depois do Core, ele também percorre nós de páginas externas em grafos mistos. Se o ensaio reproduzir troca indevida, entregar impacto ao dono com proposta testada. O Core deve concluir sua parte independentemente da distribuição do tema.

Encaminhamento confirmado na homologação do tema. Consulte impactos/base-site-core-fator3-1.78.0-impacto-implantador-base.md e a proposta de patch para o Implantador 2.20.0.
