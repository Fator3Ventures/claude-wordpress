<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Read-only admin lists. The public MCP schemas retain their cursor contract. */
final class AdminList {
    public static function term():string {return wp_html_excerpt(trim(sanitize_text_field(Admin::text($_GET,'busca'))),100,'');}
    public static function page():int {return max(1,(int)Admin::text($_GET,'pagina','1'));}
    public static function form(string $tab,string $term,array $options=[],array $values=[]):void {
        echo '<form method="get" class="f3-list-tools" action="'.esc_url(admin_url('tools.php')).'">';
        $query=[];wp_parse_str((string)wp_parse_url(Admin::url($tab),PHP_URL_QUERY),$query);
        foreach($query as $name=>$value)echo '<input type="hidden" name="'.esc_attr($name).'" value="'.esc_attr($value).'">';
        echo '<label for="f3pd-search">Buscar <input id="f3pd-search" type="search" name="busca" maxlength="100" value="'.esc_attr($term).'"></label>';
        foreach($options as $key=>$choices){
            echo '<label for="f3pd-filter-'.esc_attr($key).'">'.($key==='classe'?'Classe':'Resultado').'<select id="f3pd-filter-'.esc_attr($key).'" name="'.esc_attr($key).'"><option value="">Todos</option>';
            foreach($choices as $k=>$label)echo '<option value="'.esc_attr($k).'" '.selected($values[$key]??'',$k,false).'>'.esc_html($label).'</option>';
            echo '</select></label>';
        }
        echo '<div class="f3-actions"><button class="button button-primary">Buscar</button> <a class="button" href="'.esc_url(Admin::url($tab)).'">Limpar</a></div></form>';
    }
    public static function pager(string $tab,array $p,array $filters):void {
        ['page'=>$n,'size'=>$size,'total'=>$total]=$p;$start=$total?(($n-1)*$size+1):0;
        echo '<nav class="f3-list-tools" aria-label="Paginação"><strong class="f3-list-total">'.esc_html($start.'–'.min($n*$size,$total).' de '.$total).'</strong>';
        foreach([$n-1=>'Anterior',$n+1=>'Próxima'] as $i=>$label){
            if($i<1||$i>ceil($total/$size))echo '<span aria-disabled="true">'.esc_html($label).'</span>';
            else echo '<a class="button" href="'.esc_url(Admin::url($tab,['pagina'=>$i]+array_filter($filters,static fn($v)=>$v!==''))).'">'.esc_html($label).'</a>';
        }
        echo '</nav>';
    }
    public static function journal(array $filters,int $page):array {
        Support::admin();global $wpdb;$table=Store::table('journal');$where=['1=1'];$args=[];
        // Only explicitly public scalar fields participate in the search (never the sealed proof).
        $field=static fn($k)=>"JSON_UNQUOTE(JSON_EXTRACT(IF(JSON_VALID(metadata),metadata,'{}'),'$.".$k."'))";
        foreach(['classe'=>'classe','resultado'=>'status'] as $key=>$col)if(!empty($filters[$key])){$where[]=$field($col).'=%s';$args[]=$filters[$key];}
        if(isset($filters['antes_id'])){$where[]='id<%d';$args[]=$filters['antes_id'];}
        $term=$filters['busca']??'';
        if($term!==''){
            $parts=[];$pattern='%'.$wpdb->esc_like($term).'%';
            foreach(['caminho','metodo','previa_id','registro_id','status','classe'] as $col){$parts[]=$field($col).' LIKE %s';$args[]=$pattern;}
            foreach(['operacao_concluida'=>'Operação concluída','resultado_parcial_ou_incerto'=>'Exige reconciliação','operacao_recusada'=>'Operação recusada','em_execucao'=>'Em execução'] as $status=>$label)if(stripos(remove_accents($label),remove_accents($term))!==false){$parts[]=$field('status').'=%s';$args[]=$status;}
            $where[]='('.implode(' OR ',$parts).')';
        }
        $base=" FROM $table WHERE ".implode(' AND ',$where);
        $sql='SELECT COUNT(*)'.$base;$total=(int)$wpdb->get_var($args?$wpdb->prepare($sql,...$args):$sql);
        if($wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Não foi possível contar os registros do diário.');
        $size=20;$page=min(max(1,$page),max(1,(int)ceil($total/$size)));
        $rows=$wpdb->get_results($wpdb->prepare('SELECT id,created,metadata'.$base.' ORDER BY id DESC LIMIT %d OFFSET %d',...array_merge($args,[$size,($page-1)*$size])),ARRAY_A);
        if($wpdb->last_error!=='')throw new Fault('armazenamento_indisponivel','Não foi possível ler o diário.');
        return ['items'=>Store::journalItems($rows),'total'=>$total,'page'=>$page,'size'=>$size];
    }
}
