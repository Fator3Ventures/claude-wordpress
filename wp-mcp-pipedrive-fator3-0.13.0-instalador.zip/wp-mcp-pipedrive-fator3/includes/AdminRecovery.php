<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** Only the explicit preview/confirm forms read the provider; opening the journal never does. */
final class AdminRecovery {
    private static function input(array $form,string $key): string {return trim(Admin::text($form,$key));}
    public static function post(string $action,array $form): array {
        Support::admin();
        if($action==='recovery_preview'){
            $i=[];foreach(['origem_id','lead_id'] as $key){$v=self::input($form,$key);if($v!=='')$i[$key]=$v;}
            $r=Api::dispatch('recuperacao-previa',$i);
            $state=['ok'=>$r['success'],'message'=>$r['message']];
            if($r['success'])$state['recovery']=array_intersect_key($r['data'],array_flip(['previa_id','resolucao','registro_id','atividade_id','origem_id','toque_preservado','confirmacao_exigida']))+['binding'=>CoreClient::binding(CoreClient::status())];
            return $state;
        }
        if($action!=='recovery_confirm')return ['ok'=>false,'message'=>'Ação de recuperação desconhecida.'];
        $r=Api::dispatch('recuperacao-confirmar',['previa_id'=>self::input($form,'previa_id'),'confirmacao'=>self::input($form,'confirmacao')]);
        return ['ok'=>$r['success'],'message'=>$r['message']];
    }
    private static function form(string $action): void {
        echo '<form method="post" action="'.esc_url(Admin::url('pendencias')).'">';
        AdminForms::fields('f3_pd_recovery');
        echo '<input type="hidden" name="f3_pipedrive_action" value="'.esc_attr($action).'">';
    }
    public static function render(): void {
        Incidents::panel();
        echo '<section class="f3-section" id="f3pd-recuperacao"><h2>Pendências e recuperação</h2><p>Consulte as tentativas bloqueadas nesta conta. Abrir esta lista não consulta o CRM. Revisar um caso consulta o registro; confirmar altera somente o estado no WordPress.</p>';
        $after=isset($_GET['apos_pendencia'])&&is_string($_GET['apos_pendencia'])&&ctype_digit($_GET['apos_pendencia'])?(int)$_GET['apos_pendencia']:0;
        $term=AdminList::term();$filters=['busca'=>$term];if($after)$filters['apos_pendencia']=$after;
        AdminList::form('pendencias',$term);
        try{$page=Recovery::adminPage($term,AdminList::page(),$after);}catch(Fault $e){echo Admin::chip('atencao','Consulta indisponível').'<p>'.esc_html($e->getMessage()).'</p></section>';return;}
        AdminList::pager('pendencias',$page,$filters);$pending=['itens'=>$page['items']];
        if(!$pending['itens'])echo Admin::chip('info',$term===''?'Nenhuma pendência':'Nenhuma correspondência').'<p>'.($term===''?'Não há bloqueios visíveis para esta conta e este administrador.':'Limpe a busca para ver as demais pendências da conta.').'</p>';
        foreach($pending['itens'] as $item){
            echo '<details class="f3-collapsible"><summary>'.esc_html(($item['operacao']?Admin::label($item['operacao']):'Operação anterior').' · '.($item['registro_id']??'Alvo não identificável')).'</summary>'.Admin::chip('atencao',Admin::label($item['situacao'])).'<p>Recibo: <code>'.esc_html($item['origem_id']).'</code></p>';
            if($item['etapas']){echo '<ul>';foreach($item['etapas'] as $step)echo '<li>'.esc_html(Admin::label((string)($step['etapa']??'Etapa')).' · '.Admin::label((string)($step['code']??'Sem confirmação'))).'</li>';echo '</ul>';}
            if($item['situacao']==='disponivel_para_conferencia'){
                self::form('recovery_preview');echo '<input type="hidden" name="origem_id" value="'.esc_attr($item['origem_id']).'"><button class="button">Revisar este bloqueio</button></form>';
            }else echo '<p>A tentativa anterior não deixou evidência suficiente. Preserve o bloqueio e examine o recibo original.</p>';
            echo '</details>';
        }
        echo '<h3>Nota da atividade editada</h3><p>Se a fila apontou progresso divergente, informe o ID do lead. Só é possível aceitar a nota atual da mesma atividade, mantendo o toque e a data já comprovados.</p>';
        self::form('recovery_preview');echo '<div class="f3-field"><label for="f3pd-review-lead">ID do lead (UUID)</label><input class="regular-text" id="f3pd-review-lead" name="lead_id" maxlength="36" required></div><button class="button">Conferir nota e progresso</button></form>';
        $p=AdminForms::state()['recovery']??null;
        $sameAccount=false;
        if(is_array($p)){try{$sameAccount=($p['binding']??null)===CoreClient::binding(CoreClient::status());}catch(Fault $e){/* Hide a preview after account revocation. */}}
        if($sameAccount){
            $labels=['efeito_confirmado'=>'Registrar o efeito confirmado e liberar o bloqueio.','nao_despachado'=>'Registrar que a operação não foi enviada e liberar o bloqueio.','realinhar_nota'=>'Aceitar a nota atual da atividade. O próximo toque continuará após o último toque confirmado.'];
            echo '<h3>Revise a resolução local</h3><p>'.esc_html($labels[$p['resolucao']]??'Reveja os dados.').'</p><dl><dt>Registro</dt><dd class="f3-stat-value">'.esc_html($p['registro_id']).'</dd><dt>Recibo original</dt><dd class="f3-stat-value"><code>'.esc_html($p['origem_id']).'</code></dd>';
            if($p['atividade_id']!==null)echo '<dt>Atividade</dt><dd class="f3-stat-value">'.esc_html((string)$p['atividade_id']).'</dd>';
            if($p['toque_preservado']!==null)echo '<dt>Último toque preservado</dt><dd class="f3-stat-value">'.esc_html($p['toque_preservado']).'</dd>';
            echo '</dl><p>Válida por 15 minutos. O registro será relido antes da confirmação.</p>';
            self::form('recovery_confirm');echo '<input type="hidden" name="previa_id" value="'.esc_attr($p['previa_id']).'"><input type="hidden" name="confirmacao" value="'.esc_attr($p['confirmacao_exigida']).'"><button class="button button-primary">Confirmar esta resolução local</button></form>';
        }
        echo '</section>';
    }
}
