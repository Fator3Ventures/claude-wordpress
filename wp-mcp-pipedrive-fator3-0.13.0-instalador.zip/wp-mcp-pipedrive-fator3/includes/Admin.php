<?php
declare(strict_types=1);
namespace Fator3\Pipedrive;
defined('ABSPATH') || exit;

/** WordPress admin only. Each section loads its own data; navigation never writes. */
final class Admin {
    private const TABS=['visao'=>'Visão geral','diario'=>'Diário','regras'=>'Regras de operação','retencao'=>'Retenção','pendencias'=>'Pendências','ajuda'=>'Ajuda'];
    private const GROUPS=['operacao'=>['Operação','visao','diario'],'configurar'=>['Configurar','regras','retencao'],'suporte'=>['Suporte','pendencias','ajuda']];
    private static function group(string $tab):string {
        foreach(self::GROUPS as $id=>[, $first,$second])if($tab===$first||$tab===$second)return $id;
        return 'operacao';
    }
    private static function active():string {
        $tab=self::text($_GET,'aba');
        if(($tab==='diario'||$tab==='')&&isset($_GET['apos_pendencia']))return 'pendencias';
        return isset(self::TABS[$tab])?$tab:(isset($_GET['documento'])?'ajuda':(isset($_GET['antes_id'])?'diario':'visao'));
    }
    public static function canonical():void {
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'||!current_user_can('manage_options'))return;
        $tab=self::active();if(self::text($_GET,'grupo')===self::group($tab)&&self::text($_GET,'aba')===$tab)return;
        $args=[];foreach(['antes_id','apos_pendencia','classe','resultado','pagina','busca','documento','revisao','offset','parte','modo','tentativa','alterada'] as $k)if(isset($_GET[$k])&&is_string($_GET[$k]))$args[$k]=self::text($_GET,$k);
        wp_safe_redirect(self::url($tab,$args),302);exit;
    }
    private const HELP=[
        'Começar a configurar'=>['painel'=>'Guia do painel','configuracao'=>'Configurar a integração','regras-iniciais'=>'Regras iniciais'],
        'Operar e investigar'=>['fluxos'=>'Cadência e operações','uso'=>'Exemplos de uso','operacao'=>'Operar e recuperar','release'=>'Notas da versão'],
        'Consultar a referência'=>['agentes'=>'Guia para agentes','contratos'=>'Contratos e permissões','schemas'=>'Schemas JSON','especificacao'=>'Especificação','index'=>'Índice técnico']
    ];
    public static function menu(): void {
        $hook=add_management_page('Fator3 MCP Pipedrive','Fator3 MCP Pipedrive','manage_options',SLUG,[self::class,'page']);
        if($hook){
            add_action('load-'.$hook,[self::class,'canonical']);
            add_action('load-'.$hook,[AdminForms::class,'handle']);
            add_action('admin_enqueue_scripts',static function($screen)use($hook){
                if($screen!==$hook)return;
                wp_enqueue_style('f3-pipedrive-ui',plugins_url('assets/f3-ui.css',ROOT.'/'.SLUG.'.php'),[],'1.0.0');
                wp_enqueue_style('f3-pipedrive-admin',plugins_url('assets/admin.css',ROOT.'/'.SLUG.'.php'),['f3-pipedrive-ui'],VERSION);
                wp_enqueue_script('f3-pipedrive-admin',plugins_url('assets/admin.js',ROOT.'/'.SLUG.'.php'),[],VERSION,true);
            });
        }
    }
    public static function url(string $tab,array $extra=[]): string {return add_query_arg(['page'=>SLUG,'grupo'=>self::group($tab),'aba'=>$tab]+$extra,admin_url('tools.php'));}
    public static function text(array $source,string $key,string $default=''): string {return isset($source[$key])&&is_string($source[$key])?wp_unslash($source[$key]):$default;}
    public static function notice(string $message,bool $ok=false): void {
        echo '<div class="f3-result '.($ok?'is-ok':'is-error').'" role="'.($ok?'status':'alert').'"><p>'.esc_html($message).'</p><button class="button" type="button" data-f3pd-dismiss hidden>Dispensar</button></div>';
    }
    public static function page(): void {
        if(!current_user_can('manage_options'))wp_die('Acesso administrativo necessário.');
        $tab=self::active();$group=self::group($tab);
        $description=match($group){'configurar'=>'Defina as regras da cadência e o prazo de conservação do diário.','suporte'=>'Investigue pendências e consulte a documentação da versão instalada.',default=>'Acompanhe a conexão, a cadência e o histórico de operações desta instalação.'};
        echo '<div class="wrap f3pd f3-ui"><header class="f3-heading"><h1>Fator3 MCP Pipedrive</h1><p>'.esc_html($description).'</p><span class="f3-version">Versão '.esc_html(VERSION).'</span></header><hr class="wp-header-end"><nav class="f3-nav" aria-label="Navegação do Pipedrive"><div class="f3-groups" role="group" aria-label="Grupos do Pipedrive">';
        foreach(self::GROUPS as $id=>[$name,$first])echo '<a '.($id===$group?'aria-current="true" ':'').'href="'.esc_url(self::url($first)).'">'.esc_html($name).'</a>';
        echo '</div><div class="f3-subtabs" role="group" aria-label="Seções do Pipedrive">';
        foreach(array_slice(self::GROUPS[$group],1) as $id)echo '<a '.($id===$tab?'aria-current="page" ':'').'href="'.esc_url(self::url($id)).'">'.esc_html(self::TABS[$id]).'</a>';
        echo '</div></nav><main>';
        $state=AdminForms::state();
        if(isset($state['message']))self::notice($state['message'],!empty($state['ok']));
        match($tab){'regras'=>AdminRules::render($state),'diario'=>self::journal(),'retencao'=>self::retention(),'pendencias'=>AdminRecovery::render(),'ajuda'=>self::help(),default=>self::overview()};
        echo '</main></div>';
    }
    private static function overview(): void {
        $status=Api::dispatch('status');$cfg=Api::dispatch('configuracao-ler');$s=is_array($status['data'])?$status['data']:[];
        $ready=$status['success'];$rules=$cfg['success']?$cfg['data']['regras']:null;
        $title=$ready?'Operação autorizada':match($status['code']){'core_indisponivel'=>'Cliente do Site Core indisponível','operacao_nao_autorizada'=>'Autorização pendente',default=>'Verificação necessária'};
        echo '<section class="f3-section"><div class="f3-callout is-warn"><h2>Estado da operação</h2>'.self::chip($ready&&!empty($rules['habilitada'])?'ok':'atencao',$ready&&!empty($rules['habilitada'])?'Cadência habilitada':($ready?'Cadência desligada':$title)).'<p>';
        if(!$ready)echo 'A conexão operacional ainda não permite consultar a conta.';
        elseif(empty($rules['habilitada']))echo 'A cadência está desligada. Complete e simule as regras para começar.';
        else echo 'A cadência está habilitada.';
        if($ready){$pending=Api::dispatch('pendencias-ler',['limite'=>5]);if($pending['success']){
            $items=$pending['data']['itens']??[];echo '<br>Pendências locais visíveis para esta conta e operador: <strong>'.count($items).(!empty($pending['data']['proximo_apos_id'])?' ou mais':'').'</strong>.';
        }else echo '<br>Pendências locais: não avaliadas ('.esc_html($pending['message']).').';}
        echo '</p><p>Leads com progresso divergente: não avaliados nesta tela. <a href="'.esc_url(self::url('pendencias')).'">Consultar pendências da conta</a>.</p></div></section>';
        echo '<section class="f3-section"><div class="description">Conexão com a conta</div><h2>Conexão com o Pipedrive</h2>'.self::chip($ready?'ok':($status['code']==='core_indisponivel'?'erro':'atencao'),$title).'<p>'.esc_html($ready?'O Site Core disponibilizou o cliente Pipedrive para esta instalação. Esta leitura é local.':($status['code']==='core_indisponivel'?'Esta instalação ainda não recebeu o cliente Pipedrive do Site Core.':$status['message'])).'</p>';
        if(!$ready)echo '<p>Confira a instalação do Site Core, a credencial da conta e a autorização do consumidor <code>operacao</code> no site que acessa o CRM.</p>';
        echo '<div class="f3-stats">';
        $facts=['Conta'=>$ready?($s['conta']['dominio']??'Não informada'):'Indisponível','Cadência'=>$rules===null?'Regras indisponíveis':($rules['habilitada']?'Habilitada':'Desligada'),'Orçamento de operação'=>$ready?number_format_i18n($s['orcamento']['consumido']).' de '.number_format_i18n($s['orcamento']['teto']).' unidades':'Indisponível'];
        foreach($facts as $k=>$v)echo '<div class="f3-stat"><span class="f3-stat-label">'.esc_html($k).'</span><strong class="f3-stat-value">'.esc_html((string)$v).'</strong></div>';
        echo '</div>';
        if($ready){$limit=(int)$s['orcamento']['teto'];$spent=(int)$s['orcamento']['consumido'];$reserved=(int)($s['orcamento']['reservado']??0);if($limit>0)echo '<p><label for="f3pd-budget">Orçamento local utilizado </label><progress id="f3pd-budget" value="'.min($spent+$reserved,$limit).'" max="'.$limit.'"></progress> · '.esc_html(number_format_i18n(max(0,$limit-$spent-$reserved))).' unidades disponíveis.</p>';
            echo '<p>Saldo da conta no último retorno do fornecedor: '.esc_html(isset($s['saldo_conta']['restante'])?number_format_i18n($s['saldo_conta']['restante']):'não informado').'.</p>';}
        echo '<details class="f3-collapsible"><summary>Detalhes do contrato</summary><p>Contrato exigido: <code>'.esc_html(CONTRACT).'</code>. Registro do cliente: '.esc_html((string)($s['registro_cliente']??'indisponível')).'. A autorização e o token são mantidos no Fator3 Site Core.</p></details></section>';
        if(!$cfg['success'])self::notice($cfg['message']);
        echo '<section class="f3-section"><h2>Próximos passos</h2><ul class="f3-cards">';
        foreach([['regras','Configurar regras','Revise os horários, motivos e textos antes de simular a cadência.'],['diario','Consultar o diário','Busque uma operação e confira o resultado de cada tentativa.'],['ajuda','Documentação instalada','Leia o guia do painel e os exemplos da versão instalada.']] as [$tab,$label,$desc])echo '<li class="f3-card"><h3><a href="'.esc_url(self::url($tab)).'">'.esc_html($label).'</a></h3><p>'.esc_html($desc).'</p></li>';
        echo '</ul></section>';
        if($ready){$log=Api::dispatch('registro-ler',['limite'=>3]);if($log['success']){
            echo '<section class="f3-section"><h2>Últimas escritas locais</h2>';
            if(empty($log['data']['itens']))echo '<p>Nenhuma tentativa registrada.</p>';else{echo '<ul>';foreach($log['data']['itens'] as $item)echo '<li>'.esc_html(wp_date('d/m H:i T',strtotime($item['instante_utc']))).' · '.esc_html(self::label(basename((string)($item['caminho']??'')))).' · '.esc_html(self::label($item['status']??'')).'</li>';echo '</ul>';}
            echo '</section>';}}
    }
    private static function journal(): void {
        $term=AdminList::term();$category=self::text($_GET,'classe');$result=self::text($_GET,'resultado');
        $opts=['classe'=>['registro'=>'Registro comercial','estrutura'=>'Estrutura ou configuração'],'resultado'=>['operacao_concluida'=>'Operação concluída','resultado_parcial_ou_incerto'=>'Exige reconciliação','operacao_recusada'=>'Operação recusada','em_execucao'=>'Em execução']];
        $filters=['busca'=>$term];foreach(['classe'=>$category,'resultado'=>$result] as $k=>$v)if(isset($opts[$k][$v]))$filters[$k]=$v;
        $before=self::text($_GET,'antes_id');if(ctype_digit($before))$filters['antes_id']=(int)$before;
        echo '<section class="f3-section" id="f3pd-recuperacao"><h2>Registro de escritas</h2><p>Pesquise em todo o diário por operação, resultado, identificador ou método. Para revisar um bloqueio, abra <a href="'.esc_url(self::url('pendencias')).'">Pendências</a>. Para alterar o prazo de conservação, abra <a href="'.esc_url(self::url('retencao')).'">Retenção</a>.</p>';
        AdminList::form('diario',$term,$opts,$filters);
        try{
            $page=AdminList::journal($filters,AdminList::page());$items=$page['items'];
            AdminList::pager('diario',$page,$filters);
            if(!$items)echo '<p class="f3-empty">Nenhuma tentativa de escrita nesta página para a seleção atual.</p>';
            else{
                echo '<div class="f3-table-scroll" role="region" aria-label="Tentativas de escrita" tabindex="0"><table class="widefat striped"><thead><tr><th>Quando</th><th>Operação</th><th>Resultado</th><th>Registro e etapas</th></tr></thead><tbody>';
                $binding=null;$account=null;try{$status=CoreClient::status();$account=$status['conta'];$binding=Support::digest($account);}catch(Fault){}
                foreach($items as $item){
                    $time=strtotime($item['instante_utc']);$label=self::label((string)($item['status']??''));
                    echo '<tr><td>'.esc_html($time?wp_date('d/m/Y H:i T',$time):'—').'<small>'.esc_html($item['instante_utc']).'</small></td><td><strong>'.esc_html(self::label(basename((string)($item['caminho']??'')))).'</strong><small>'.esc_html(trim(($item['metodo']??'').' '.($item['caminho']??''))).'</small></td><td>'.self::chip(match($item['status']??''){'operacao_concluida','configuracao_salva','ok'=>'ok','operacao_recusada'=>'erro','resultado_parcial_ou_incerto'=>'atencao',default=>'info'},$label).'</td><td>';
                    self::entity($item,$account,$binding);
                    echo '<details class="f3-collapsible"><summary>Detalhes da tentativa</summary><p>Prévia: <code>'.esc_html((string)($item['previa_id']??'—')).'</code></p><p>Chaves: '.esc_html(implode(', ',$item['chaves_alteradas']??[])?:'—').'</p>';
                    if(!empty($item['etapas'])){echo '<ol>';foreach($item['etapas'] as $step)echo '<li>'.esc_html(self::label((string)($step['etapa']??''))).': '.esc_html(self::label((string)($step['code']??'sem confirmação'))).'</li>';echo '</ol>';}
                    echo '</details></td></tr>';
                }
                echo '</tbody></table></div>';
            }
        }catch(Fault $e){self::notice($e->getMessage());}
        echo '</section>';
    }
    public static function chip(string $tone,string $label):string {
        $state=match($tone){'ok'=>'ok','atencao'=>'warn','erro'=>'error',default=>'info'};
        return '<span class="f3-pill is-'.esc_attr($state).'">'.esc_html($label).'</span>';
    }
    private static function retention(): void {
        $policy=Api::dispatch('retencao-ler');echo '<section class="f3-section"><h2>Retenção do diário</h2><p>O prazo controla a próxima limpeza. Reduzir o prazo não remove entradas neste momento.</p>';
        if(!$policy['success'])self::notice($policy['message']);else{
            $p=$policy['data'];echo self::chip('info',$p['diario_sem_prazo']?'Sem prazo':$p['diario_dias'].' dias de conservação');echo '<form method="post" action="'.esc_url(self::url('retencao')).'">';AdminForms::fields('f3_pipedrive_retention');
            echo '<input type="hidden" name="f3_pipedrive_action" value="retention"><input type="hidden" name="revisao_esperada" value="'.esc_attr($p['revisao']).'"><div class="f3-field"><label for="f3pd-days">Dias de conservação</label><input id="f3pd-days" type="number" min="0" max="36500" step="1" required name="diario_dias" aria-describedby="f3pd-days-help" value="'.esc_attr((string)$p['diario_dias']).'"><p id="f3pd-days-help" class="description">0 = sem prazo. Prazo atual: '.($p['diario_sem_prazo']?'sem prazo':esc_html((string)$p['diario_dias']).' dias').'.</p></div>';
            echo '<p><label class="f3-check"><input type="checkbox" name="confirmar_expurgo" value="1"> Para prazo finito, autorizo excluir entradas vencidas nas próximas limpezas.</label></p><p>Ampliar o prazo depois não recupera registros excluídos. Recibos necessários à reconciliação são preservados.</p>';submit_button('Salvar retenção','primary');echo '</form>';
        }echo '</section>';
    }
    public static function label(string $code):string {
        return match($code){'disponivel_para_conferencia'=>'Revisão disponível','sem_prova_de_intencao'=>'Sem prova da intenção','alvo_nao_identificavel'=>'Alvo não identificável','em_execucao'=>'Em execução','conferencia'=>'Conferência','reconciliacao'=>'Reconciliação','whatsapp-registrar'=>'Registrar WhatsApp','lead-encerrar'=>'Encerrar lead','negocio-perder'=>'Registrar perda','lead-arquivado-editar'=>'Editar lead arquivado','resultado_parcial_ou_incerto'=>'Exige reconciliação','operacao_concluida'=>'Concluída','operacao_recusada'=>'Recusada','configuracao_salva'=>'Regras salvas','resultado_incerto'=>'Resultado incerto','ok'=>'Concluído','enviada'=>'Enviada',''=>'Não informado',default=>ucfirst(str_replace(['_','-'],' ',$code))};
    }
    private static function entity(array $item,?array $account,?string $binding):void {
        $id=(string)($item['registro_id']??'');$kind=$item['entidade']??'';
        if(!in_array($kind,['lead','deal'],true)||!preg_match('/^[0-9a-f-]{1,40}$/Di',$id))return;
        $title=($kind==='lead'?'Lead ':'Negócio ').$id;
        if($binding===null||!hash_equals($binding,(string)($item['conta_resumo']??''))){echo esc_html($title);return;}
        $url='https://'.$account['dominio'].($kind==='lead'?'/leads/inbox/':'/deal/').rawurlencode($id);
        echo '<a href="'.esc_url($url).'" rel="noreferrer">'.esc_html($title).'</a>';
    }
    private static function help(): void {
        $id=self::text($_GET,'documento','painel');$offset=self::text($_GET,'offset','0');$hash=self::text($_GET,'revisao');
        $labels=array_merge(...array_values(self::HELP));
        echo '<section class="f3-section"><h2>Documentação instalada</h2><p>Escolha um assunto. A consulta é local e funciona mesmo sem autorização do CRM.</p><p><a href="#f3pd-help-current">Ir ao documento selecionado</a></p><nav data-f3pd-directory aria-label="Documentos">';
        foreach(self::HELP as $title=>$group){
            echo '<div><h3>'.esc_html($title).'</h3><ul class="f3-switch">';
            foreach($group as $key=>$label)echo '<li><a class="button" '.($key===$id?'aria-current="page" ':'').'href="'.esc_url(self::url('ajuda',['documento'=>$key])).'">'.esc_html($label).'</a></li>';
            echo '</ul></div>';
        }
        echo '</nav></section><section class="f3-section" id="f3pd-help-current" tabindex="-1"><h2>'.esc_html($labels[$id]??'Documento').'</h2>';
        $guide=str_ends_with(Documentation::DOCUMENTS[$id]??'', '.md');
        $args=['documento'=>$id,'offset'=>ctype_digit($offset)?(int)$offset:-1,'limite_bytes'=>$guide?24000:16000];if($hash!=='')$args['sha256_esperado']=$hash;
        $r=Api::dispatch('documentacao-ler',$args);if(!$r['success']){
            self::notice($r['message']);
            if(($offset!=='0'||$hash!=='') && isset($labels[$id]))echo '<a href="'.esc_url(self::url('ajuda',['documento'=>$id])).'">Voltar ao início do documento</a>';
        }else{
            $d=$r['data'];echo '<p class="description">Versão '.esc_html($d['version']).' · '.esc_html(number_format_i18n($d['total_bytes'])).' bytes no documento.</p>';
            if($guide && $d['offset']===0){
                // Read the installed guide against one revision, then paginate at semantic boundaries.
                try{
                    $content=$d['conteudo'];$next=$d['proximo_offset'];
                    while($next!==null){$chunk=Documentation::read(['documento'=>$id,'offset'=>$next,'limite_bytes'=>24000,'sha256_esperado'=>$d['sha256']]);$content.=$chunk['conteudo'];$next=$chunk['proximo_offset'];}
                    $pages=AdminDocument::pages($content);$input=self::text($_GET,'parte','1');
                    if(!ctype_digit($input)||(int)$input<1||(int)$input>count($pages)||((int)$input>1&&$hash===''))throw new Fault('parte_invalida','Parte indisponível. Reabra o documento pelo índice.');
                    $page=(int)$input;
                    if(count($pages)>1)echo '<p>Parte '.$page.' de '.count($pages).'</p>';
                    echo AdminDocument::render($pages[$page-1]);
                    foreach([$page-1=>'Parte anterior',$page+1=>'Ler próxima parte'] as $n=>$label)if($n>=1&&$n<=count($pages))echo '<a class="button" href="'.esc_url(self::url('ajuda',['documento'=>$id,'parte'=>$n,'revisao'=>$d['sha256']]).'#f3pd-help-current').'">'.esc_html($label).'</a> ';
                }catch(Fault $e){self::notice($e->getMessage());}
            }else{
                echo '<pre class="f3pd-source" tabindex="0">'.esc_html($d['conteudo']).'</pre>';
                if($d['proximo_offset']!==null)echo '<a class="button" href="'.esc_url(self::url('ajuda',['documento'=>$id,'offset'=>$d['proximo_offset'],'revisao'=>$d['sha256']])).'">Ler próxima parte</a>';
                if($d['offset']>0)echo ' <a href="'.esc_url(self::url('ajuda',['documento'=>$id])).'">Voltar ao início do documento</a>';
            }
        }echo '</section>';
    }
}
