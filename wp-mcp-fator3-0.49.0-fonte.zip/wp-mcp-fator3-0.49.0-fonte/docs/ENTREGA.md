# Entrega 0.49.0

MCP84 e Core430. A correção do registro tardio do REST está descrita em RELEASE-0490.md. Base direta 0.48.0. O relatório externo identifica os pacotes finais e as provas da rodada.
