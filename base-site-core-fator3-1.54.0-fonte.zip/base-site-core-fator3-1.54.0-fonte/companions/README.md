# Acompanhantes para reproduzir os testes

Os runtimes dos acompanhantes não são republicados no fonte Core: pertencem a outros pacotes. O instalador Core é autônomo.

Nesta rodada a integração exercitada é com o original wp-mcp-fator3 0.32.0. Forneça seu instalador de 885606 bytes, SHA-256 `fd2097055383a26e6ca5b79b655f0b3740c337a42dab6ce2b43b4236c07496b1`, e extraia sua pasta, sem mudanças, em companions/wp-mcp-fator3 e nos plugins do laboratório. Fonte recebido: 4443847 bytes, SHA-256 `d7413eda5cae051c35c9f08f21a3e47cb9fc02e8e0d22462dd094b2cbf445c4e`. Relatório e impacto recebidos estão em inputs/1540.

Os demais acompanhantes abaixo são bases herdadas; não houve nova homologação integral dos seus fornecedores nesta rodada. As provas anteriores permanecem identificadas por versão nos diretórios históricos.

| Pacote | Versão | Escopo desta rodada |
|---|---|---|
| wp-mcp-fator3 | 0.32.0 | Decorador real, permissões, recibos, idempotência e política tipada |
| wp-mcp-google-fator3 | 0.19.0 | Base preservada; sem teste de fornecedor |
| wp-mcp-meta-fator3 | 0.10.1 | Base preservada; sem teste de fornecedor |
| wp-mcp-linkedin-fator3 | 0.10.1 | Base preservada; sem teste de fornecedor |
| wp-mcp-pipedrive-fator3 | 0.1.0 | Base preservada; fluxo CRM do Core testado com transporte simulado |

Google 0.19.0 veio da base 1.51.0; seu instalador original está identificado pelo SHA-256 `d15868915e3fdf886d7e883a82d9d302df7242808fc94d45bf3e1857234759d1`. Pipedrive completo exige PHP 8.3.36 e não deve ser ativado no laboratório PHP 8.3.6. Não confundir o pacote acompanhante com o cliente Pipedrive público do Core, cujo contrato permanece 1.0.0.
