# Fonte Core 1.54.0

Base 1.53.0. Código instalável em work/plugin/base-site-core-fator3. Normas revisão 5 em inputs/1510; planejamento e impactos recebidos em inputs/1540. Evidências sanitizadas em evidence/1540, histórico em history. Não há dependência de um banco ou credencial real para reproduzir os testes.

Leia build/README.md e build/COMPANIONS.md. A suíte request-302 cobre registro/vínculo/leitura/filtros/privacidade/exclusão; request-302-crm cobre entrega opcional e vínculo existente com transportes simulados; permissions-1540 verifica capacidades nativas e MCP 0.32.0. O instalador contém somente runtime e documentação corrente.
