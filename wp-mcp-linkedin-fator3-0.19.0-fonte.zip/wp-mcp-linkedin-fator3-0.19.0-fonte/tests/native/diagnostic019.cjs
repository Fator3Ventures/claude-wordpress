const fs=require('fs');const {JSDOM,CookieJar,ResourceLoader,VirtualConsole}=require(process.env.F3_JSDOM);
(async()=>{const root=process.env.F3_UI_URL,jar=new CookieJar(),checks=[],errors=[];let pending=0;
async function request(url,options={}){const r=await fetch(url,{...options,signal:AbortSignal.timeout(60000),headers:{connection:'close',...options.headers,cookie:await jar.getCookieString(url)},redirect:'manual'});for(const c of r.headers.getSetCookie())await jar.setCookie(c,url);if(r.status>=300&&r.status<400){const next=new URL(r.headers.get('location'),url).href;await r.arrayBuffer();return request(next);}return r;}
await (await request(root+'/wp-login.php')).arrayBuffer();const signedIn=await request(root+'/wp-login.php',{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({log:'social_admin',pwd:process.env.F3_UI_PASSWORD,redirect_to:root+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab=connections',testcookie:'1'}).toString()});
class LocalResources extends ResourceLoader{fetch(url,opts){if(!url.startsWith(root+'/'))return null;return super.fetch(url,opts);}}
const url=root+'/wp-admin/tools.php?page=wp-mcp-linkedin-fator3&tab=connections',html=await signedIn.text(),vc=new VirtualConsole();vc.on('jsdomError',e=>{if(!/Not implemented|Could not parse CSS/.test(e.message))errors.push(e.message);});
const dom=new JSDOM(html,{url,cookieJar:jar,runScripts:'dangerously',resources:new LocalResources(),pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.fetch=(u,o)=>{pending++;return request(new URL(u,root).href,o).finally(()=>pending--);};w.matchMedia=()=>({matches:false,addListener(){},removeListener(){},addEventListener(){}});w.scrollTo=()=>{};w.confirm=(text)=>{w.lastConfirmation=text;return w.acceptDiscovery===true;};}});
const w=dom.window,d=w.document,$=s=>d.querySelector(s);function ok(v,n){if(!v)throw Error(n);checks.push({name:n,state:'ok'});}async function wait(fn,n){for(let i=0;i<1000;i++){if(fn())return;await new Promise(r=>setTimeout(r,40));}throw Error(n+': '+$('#f3-message')?.textContent+' / '+errors.join(';'));}


const failed=[],assertCase=(name,p)=>{checks.push({name,passed:Boolean(p)});if(!p)failed.push(name);};
const ops=[];let hold=null,release=null;
const fetch0=w.fetch;w.fetch=async(u,o)=>{if(!String(u).includes('f3-linkedin')||typeof o?.body!=='string')return fetch0(u,o);const op=decodeURIComponent(String(u)).split('/').pop();let input;try{input=JSON.parse(o.body);}catch{return fetch0(u,o);}ops.push({op,kind:input.kind});const resp=await fetch0(u,o);if(hold===op){hold=null;await new Promise(res=>release=res);}return resp;};
const api=async(op,input={})=>{const r=await request(w.F3Social.root+op,{method:'POST',headers:{'content-type':'application/json','X-WP-Nonce':w.F3Social.nonce},body:JSON.stringify(input)});return (await r.json()).data;};
await wait(()=>$('#f3-user-options input'),'user options');ops.length=0;
$('a[data-tab="diagnostics"]').click();await wait(()=>!$('#f3-diagnostics').hidden&&pending===0,'diagnostics ready');
assertCase('Opening diagnostics does not trigger a provider-backed option lookup',!ops.some(x=>x.op==='admin-options'&&x.kind==='selected'));
assertCase('Report filters do not occupy local diagnostics', $('#f3-context').hidden);
const newUI=Boolean($('#f3-diagnostic-channel'));
hold='selftest';$('#f3-selftest').click();await wait(()=>release,'hold local selftest');$('#f3-status').click();
await wait(()=>$('#f3-diagnostic-result').textContent.length>10&&pending===0,'state response');const beforeRelease=$('#f3-diagnostic-result').textContent;release();release=null;await new Promise(res=>setTimeout(res,50));
assertCase('Slower selftest does not replace newer status',beforeRelease===$('#f3-diagnostic-result').textContent);
if(newUI){
 assertCase('Status plainly states worker health and number of connections',$('#f3-diagnostic-result').textContent.includes('Estado do worker:')&&$('#f3-diagnostic-result').textContent.includes('1 conexão'));
 const details=$('#f3-diagnostic-result details');assertCase('Technical details are collapsed initially',details&&!details.open&&!details.querySelector('dl'));details.open=true;await wait(()=>details.querySelector('dl'),'lazy details');
 $('#f3-selftest').click();await wait(()=>$('#f3-diagnostic-result').textContent.includes('Autoteste local aprovado'),'selftest result');
 assertCase('Selftest explicitly distinguishes external validation',$('#f3-diagnostic-result').textContent.includes('acesso ao LinkedIn não foi testado'));
 const ch=$('#f3-diagnostic-channel'),acc=$('#f3-diagnostic-account');
 ch.value='pages';ch.dispatchEvent(new w.Event('change',{bubbles:true}));assertCase('Only saved page is auto-selected',acc.value==='111');
 const oldRev=(await api('get-connection',{connection_id:'ui'})).connection.revision;
 hold='validate-connection';$('#f3-validate').click();await wait(()=>release,'hold remote response');
 ch.value='ads';ch.dispatchEvent(new w.Event('change',{bubbles:true}));release();release=null;await new Promise(res=>setTimeout(res,50));
 assertCase('Old page response stays out of newly selected Ads panel',acc.value==='222'&&!$('#f3-diagnostic-remote').textContent);
 ch.value='leads';ch.dispatchEvent(new w.Event('change',{bubbles:true}));$('#f3-validate').click();
 await wait(()=>$('#f3-diagnostic-remote').textContent.includes('Metadados verificados'),'confirmed current asset');
 assertCase('Remote result identifies selected Lead Sync account',$('#f3-diagnostic-remote').textContent.includes('222'));
 assertCase('Successful validation leaves the saved configuration revision unchanged',(await api('get-connection',{connection_id:'ui'})).connection.revision===oldRev);
 assertCase('Local and remote results coexist',$('#f3-diagnostic-result').textContent.includes('Autoteste local aprovado'));
}
assertCase('No runtime JavaScript errors',errors.length===0);
fs.writeFileSync(process.env.F3_LAB_ROOT+'/evidence/diagnostic019.json',JSON.stringify({version:w.F3Social.version,checks,total:checks.length,failed:failed.length,errors},null,2));console.log(JSON.stringify({checks:checks.length,failed}));dom.window.close();process.exit(failed.length?1:0);
})().catch(e=>{console.error(e);process.exit(1)});
