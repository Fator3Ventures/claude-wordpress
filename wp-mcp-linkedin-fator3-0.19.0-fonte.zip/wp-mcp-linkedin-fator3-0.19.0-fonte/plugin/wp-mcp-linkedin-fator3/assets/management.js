/* LinkedIn administrative writes. All provider-controlled values are text nodes. */
(()=>{'use strict';
const cfg=window.F3Social;if(cfg.provider!=='linkedin')return;
const $=s=>document.querySelector(s),f=$('#f3-management-form'),box=$('#f3-management-result');
let connections=cfg.bootstrap.connections||[],revision=null,remoteSchedule=null,catalogScope=null,editScope=null,preview=null,draftEpoch=0,listEpoch=0,searchEpoch=0,reloadEpoch=0,executing=false,targets=[],searchRows=[],searchOffset=null,objectsCursor=null,operation=null,epoch=0;
const editedFields=new Set();
const labels={operation_revision:'Revisão da operação',replayed:'Resposta já registrada',last_code:'Último código',enabled:'Ativa',credential_generation:'Geração da credencial',credential_revision:'Revisão da conexão',type:'Tipo',costType:'Cobrança',objectiveType:'Objetivo',format:'Formato',optimizationTargetType:'Otimização',biddingStrategy:'Estratégia de lance',offsiteDeliveryEnabled:'Entrega fora da rede',audienceExpansionEnabled:'Expansão de público',lifecycleState:'Estado da publicação',PUBLISHED:'Publicada',visibility:'Visibilidade',PUBLIC:'Pública',distribution:'Distribuição',feedDistribution:'Distribuição no feed',MAIN_FEED:'Feed principal',targetEntities:'Público específico',thirdPartyDistributionChannels:'Canais adicionais',isReshareDisabledByAuthor:'Recompartilhamento bloqueado',leadgenCallToAction:'Chamada de formulário',destination:'Destino',label:'Texto',reference:'Referência',media:'Mídia',source:'Origem',owner:'Proprietário',code:'Código',opened_at:'Aberto em',last_at:'Atualizado em',before:'Antes',after:'Depois',proposed:'Alteração proposta',state:'Estado',name:'Nome',status:'Estado',intendedStatus:'Estado desejado',DRAFT:'Rascunho',ACTIVE:'Ativo',PAUSED:'Pausado',ARCHIVED:'Arquivado',PENDING_DELETION:'Remoção pendente',confirmed:'Confirmado',uncertain:'Incerto',awaiting_verification:'Aguardando verificação',operation_id:'Identificação da operação',remote_id:'Identificação remota',remote_effect:'Efeito remoto',dry_run:'Prévia',remote_write_sent:'Escrita enviada',requires_reconciliation:'Exige reconciliação',central_audit:'Registro central',registered:'Registrado no Fator3 MCP',unavailable:'MCP indisponível',not_registered:'Descritor não admitido',grants_preserved:'Autorização preservada',expires_at:'Validade do acesso',refresh_expires_at:'Validade da renovação',days_remaining:'Dias restantes',last_refresh_at:'Última renovação',last_result:'Último resultado',failures:'Falhas',next_attempt:'Próxima tentativa',refresh_configured:'Renovação disponível',connection_id:'Conexão',rw_conversions:'Conversões concedidas',r_ads:'Leitura de anúncios concedida',checked:'Escopos verificados',checked_at:'Verificação em',conversion_access:'Acesso à Conversions API',scopes:'Permissões',incident:'Incidente',notices:'Avisos',sent:'Enviado',at:'Data',text:'Texto',commentary:'Texto da publicação',method:'Método',destructive:'Efeito relevante',expected_revision:'Revisão conferida',concurrency:'Concorrência',optimistic_read_before_write:'Releitura imediatamente antes do envio; a API não oferece transação remota',scope_missing:'Permissão ausente',scope:'Permissão',revision:'Revisão',object:'Objeto',title:'Título',description:'Descrição',content:'Conteúdo',upload:'Instruções de envio',uploadUrl:'Endereço de envio',image:'Imagem',video:'Vídeo',uploadInstructions:'Partes do envio',firstByte:'Primeiro byte',lastByte:'Último byte',uploadToken:'Autorização de envio',uploadUrlExpiresAt:'Validade do endereço',id:'Identificação',account:'Conta',author:'Página autora',campaignGroup:'Grupo de campanhas',campaign:'Campanha',totalBudget:'Orçamento total',dailyBudget:'Orçamento diário',unitCost:'Lance',amount:'Valor',currency:'Moeda',runSchedule:'Datas',start:'Início',end:'Fim',targetingCriteria:'Segmentação',include:'Incluir',exclude:'Excluir',and:'Todas as condições',or:'Qualquer condição',locale:'Idioma e país',language:'Idioma',country:'País',true:'Sim',false:'Não',refreshed:'Renovado',oauth_rejected:'Autorização recusada',not_attempted:'Ainda não executado',next_maintenance:'Próxima manutenção',oauth_callback:'Retorno de autorização',refresh_requires_provider_approval:'Renovação depende do aplicativo',connections:'Conexões'};
const node=(tag,text)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;return n;};
function render(root,value){root.replaceChildren();function add(parent,v){if(v===null){parent.append(node('span','Não disponível'));return;}if(Array.isArray(v)){const ul=node('ul');for(const x of v){const li=node('li');add(li,x);ul.append(li);}parent.append(ul);return;}if(typeof v==='object'){const dl=node('dl');for(const [k,x]of Object.entries(v)){if(k==='confirm_token')continue;dl.append(node('dt',labels[k]||k));const dd=node('dd');add(dd,x);dl.append(dd);}parent.append(dl);return;}parent.append(node('span',labels[String(v)]||String(v)));}add(root,value);}
async function api(op,i={}){const r=await fetch(cfg.root+op,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-WP-Nonce':cfg.nonce},body:JSON.stringify(i)});const v=await r.json();if(!r.ok||!v.success){if(v.details?.operation_id){$('#f3-write-operation-id').value=v.details.operation_id;}throw Error((v.message||'Operação recusada.')+' ['+(v.code||r.status)+']');}return v.data;}
const task=fn=>async e=>{e?.preventDefault();try{await fn();}catch(e){box.textContent=e.message;$('#f3-message').textContent=e.message;}};
const bind=(selector,event,fn)=>$(selector)?.addEventListener(event,task(fn));
function options(select,rows,selected){select.replaceChildren(new Option('Selecione', ''));for(const row of rows)select.add(new Option(row.name||row.id,row.id));if(selected)select.value=selected;}
const value=n=>f.elements[n].value;const connection=()=>connections.find(c=>c.id===value('connection_id'));
function invalidate(message='Gere outra prévia para usar os dados atuais.'){
 draftEpoch++;if(preview)box.textContent=message;
 preview=null;$('#f3-management-execute').disabled=true;
}
function clearSearch(){searchEpoch++;searchRows=[];searchOffset=null;options(f.elements.target_result,[]);$('#f3-target-more').hidden=true;}
function clearTargets(){clearSearch();targets=[];$('#f3-target-selected').replaceChildren();}
function clearCatalog(){
 listEpoch++;objectsCursor=null;$('#f3-management-more').hidden=true;
 for(const n of ['object_id','campaign_group_id','campaign_id','post_id','form_id'])options(f.elements[n],[]);
 clearTargets();
}
function effect(kind,action){
 if(action==='activate')return ['Confirmar ativação','Ativar pode iniciar veiculação e gasto na conta de anúncios selecionada.'];
 if(action==='delete')return ['Confirmar exclusão','A exclusão afeta o objeto selecionado no LinkedIn. Confira o identificador e o efeito proposto.'];
 if(kind==='comment')return ['Publicar comentário','O comentário ficará visível na publicação selecionada em nome da Página.'];
 if(kind==='post')return action==='create'?['Publicar na Página','O conteúdo será publicado na Página selecionada.']:['Confirmar edição','A edição altera o texto da publicação já existente.'];
 if(action==='initialize')return ['Iniciar envio','A confirmação solicita instruções para envio de mídia ao LinkedIn.'];
 if(action==='create')return ['Criar rascunho','Novos grupos, campanhas e anúncios são criados em rascunho. A ativação é uma ação separada.'];
 return ['Confirmar alteração','A confirmação modifica o objeto existente. Confira orçamento, lance, datas e segmentação quando aplicáveis.'];
}
function selected(){const c=connection();if(!c)throw Error('Escolha uma conexão salva.');return c;}
const ads=k=>['campaign-group','campaign','creative'].includes(k);
function context(){const c=selected(),i={connection_id:c.id};if(ads(value('kind')))i.account_id=value('account_id');else i.page_id=value('page_id');if(!(i.account_id||i.page_id))throw Error('Escolha um ativo autorizado.');return i;}
function shape(){const kind=value('kind'),action=value('action');return kind.endsWith('-upload')?'initialize-'+kind:action+'-'+kind;}
// Lists belong to one catalog scope; the editable draft and its audience also belong to one target.
function syncSelection(){
 const kind=value('kind'),action=value('action'),scope=JSON.stringify([value('connection_id'),connection()?.revision??null,kind,ads(kind)?value('account_id'):null,(!ads(kind)||kind==='creative')?value('page_id'):null]);
 if(catalogScope!==scope){catalogScope=scope;clearCatalog();epoch++;}
 const target=JSON.stringify([scope,action,action==='create'||action==='initialize'?(kind==='comment'?value('post_id'):null):value('object_id')]);
 if(editScope===target)return;editScope=target;invalidate();revision=null;remoteSchedule=null;clearTargets();editedFields.clear();
 for(const control of $('#f3-management-fields').querySelectorAll('input,select,textarea')){
  if(kind==='comment'&&control.name==='post_id')continue;
  if(control.tagName==='SELECT'&&action!=='update')control.selectedIndex=0;else control.value='';
 }
}
function refreshAssets(){const c=connection(),prior={account_id:value('account_id'),page_id:value('page_id')};for(const [n,ch]of [['account_id','ads'],['page_id','pages']])options(f.elements[n],(c?.assets[ch]||[]).map(id=>({id,name:(ch==='ads'?'Conta ':'Página ')+id})),prior[n]);change();}
function change(){epoch++;invalidate();objectsCursor=null;$('#f3-management-more').hidden=true;const kind=value('kind'),previous=value('action');
 const actions=kind.endsWith('-upload')?[['initialize','Iniciar envio']]:kind==='comment'?[['create','Comentar']]:[['create','Criar'],['update','Alterar'],...(ads(kind)?[['activate','Ativar']]:[]),['delete','Excluir']];
 options(f.elements.action,actions.map(([id,name])=>({id,name})),previous);if(!f.elements.action.value)f.elements.action.value=actions[0][0];
 const action=value('action'),editing=action==='create'||action==='update';syncSelection();let fields=[];
 const [caption,description]=effect(kind,action);$('#f3-management-execute').textContent=caption;$('#f3-management-effect').textContent=description;
 if(editing&&ads(kind)){if(kind!=='creative')fields=['name','total_budget','currency','start','end'];if(kind==='campaign')fields.push(...(action==='create'?['campaign_group_id']:[]),'type','cost_type','objective','format','optimization','daily_budget','bid','language','country','offsite_delivery');if(kind==='creative'&&action==='create')fields=['name','campaign_id','post_id','form_id','call_to_action'];if(action==='update')fields.push('status');}
 if(kind==='post'&&editing)fields=action==='update'?['text']:['text','content_type','media_id','title','description','article_url','thumbnail_id'];
 if(kind==='comment')fields=['post_id','text'];if(kind.endsWith('-upload'))fields=['upload_file'];
 for(const control of $('#f3-management-fields').querySelectorAll('input,select,textarea')){const show=fields.includes(control.name);control.closest('label').hidden=!show;control.disabled=!show;}
 $('#f3-management-targeting').hidden=kind!=='campaign'||!editing;$('#f3-management-values').hidden=fields.length===0;
 f.elements.account_id.closest('label').hidden=!ads(kind);f.elements.page_id.closest('label').hidden=ads(kind)&&kind!=='creative';f.elements.object_id.closest('label').hidden=['create','initialize'].includes(action);
}
function edited(e){if(e.target.closest('#f3-management-fields'))editedFields.add(e.target.name);invalidate();}
f.addEventListener('input',edited);f.addEventListener('change',edited);
f.elements.connection_id.addEventListener('change',refreshAssets);f.elements.kind.addEventListener('change',change);f.elements.action.addEventListener('change',change);
for(const k of ['account_id','page_id','object_id','post_id'])f.elements[k].addEventListener('change',syncSelection);
async function load(report,ch,id,cursor){return api('query',{connection_id:selected().id,channel:ch,account_id:id,report,limit:50,...(cursor?{cursor}:{})});}
async function loadAll(report,ch,id){let cursor=null,out=[],seen=new Set();const current=epoch;do{const r=await load(report,ch,id,cursor);if(current!==epoch)throw Error('A seleção mudou. Carregue novamente.');out.push(...r.rows);cursor=r.next_cursor;if(cursor&&seen.has(cursor))throw Error('A paginação não avançou.');seen.add(cursor);}while(cursor);return {rows:out};}
function rows(r){return r.rows.map(v=>({id:String(v.id).replace(/^urn:li:sponsoredCreative:/,''),name:v.name||v.commentary?.slice(0,100)||('Objeto '+v.id)}));}
async function list(more=false){syncSelection();const generation=epoch,seq=++listEpoch,current=()=>generation===epoch&&seq===listEpoch,c=selected(),kind=value('kind'),account=value('account_id'),page=value('page_id'),report=kind==='campaign-group'?'campaign_groups':kind==='campaign'?'campaigns':kind==='creative'?'creatives':'posts';
 if(kind.endsWith('-upload')||(more&&!objectsCursor))return;
 const r=await load(report,ads(kind)?'ads':'pages',ads(kind)?account:page,more?objectsCursor:null);if(!current())return;
 const prior=more?[...f.elements.object_id.options].filter(o=>o.value).map(o=>({id:o.value,name:o.textContent})):[];const old=value('object_id');options(f.elements.object_id,[...prior,...rows(r)],old);if(value('object_id')!==old)syncSelection();objectsCursor=r.next_cursor;$('#f3-management-more').hidden=!objectsCursor;
 if(!more&&kind==='campaign'){const groups=await loadAll('campaign_groups','ads',account);if(!current())return;options(f.elements.campaign_group_id,rows(groups),value('campaign_group_id'));}
 if(!more&&kind==='creative'){const campaigns=await loadAll('campaigns','ads',account);if(!current())return;options(f.elements.campaign_id,rows(campaigns),value('campaign_id'));const posts=await loadAll('posts','pages',page);if(!current())return;options(f.elements.post_id,rows(posts),value('post_id'));options(f.elements.form_id,(c.forms[account]||[]).map(id=>({id,name:'Formulário '+id})));}
 if(kind==='comment'){options(f.elements.post_id,[...f.elements.object_id.options].filter(o=>o.value).map(o=>({id:o.value,name:o.textContent})),value('post_id'));syncSelection();}
}
function objectInput(){const i=context(),kind=value('kind'),action=value('action');if(!['create','initialize'].includes(action))i[kind==='post'?'post_id':kind.replaceAll('-','_')+'_id']=value('object_id');if(kind==='comment')i.post_id=value('post_id');return i;}
// Reading on behalf of a preview obtains only its revision. It must not fill or replace the user's draft.
async function read(show,stamp){
 const kind=value('kind'),action=value('action'),i=objectInput(),key=JSON.stringify([kind,action,i]);
 const op=['create','initialize'].includes(action)?(ads(kind)?'get-ad-account':kind==='comment'?'get-post':'get-organization'):'get-'+kind;
 const r=await api(op,i);if(stamp!==draftEpoch||key!==JSON.stringify([value('kind'),value('action'),objectInput()]))return null;
 revision=r.revision;remoteSchedule=r.object.runSchedule??null;if(!show)return r;
 render(box,r);
 if(action==='update'){
  editedFields.clear();
  for(const control of $('#f3-management-fields').querySelectorAll('input,select,textarea'))if(!control.disabled)control.value='';
  const map={name:'name',type:'type',costType:'cost_type',objectiveType:'objective',format:'format',optimizationTargetType:'optimization',commentary:'text',offsiteDeliveryEnabled:'offsite_delivery'};
  for(const [remote,local]of Object.entries(map))if(r.object[remote]!==undefined)f.elements[local].value=String(r.object[remote]);
  for(const [remote,local]of [['totalBudget','total_budget'],['dailyBudget','daily_budget'],['unitCost','bid']]){
   const money=r.object[remote];f.elements[local].value=money?.amount==null?'':String(money.amount);
   if(money?.currency)f.elements.currency.value=money.currency;
  }
  for(const k of ['language','country'])f.elements[k].value=r.object.locale?.[k]||'';
  for(const k of ['start','end'])f.elements[k].value=r.object.runSchedule?.[k]?new Date(r.object.runSchedule[k]).toISOString().slice(0,16):'';
 }
 if(r.object.currency)f.elements.currency.value=r.object.currency;
 return r;
}
function fields(){const kind=value('kind'),action=value('action'),out={},wanted=name=>action!=='update'||editedFields.has(name);
 for(const control of $('#f3-management-fields').querySelectorAll('input,select,textarea')){if(control.disabled||!control.value||!wanted(control.name)||['currency','start','end','upload_file','total_budget','daily_budget','bid'].includes(control.name))continue;out[control.name]=control.name==='offsite_delivery'?control.value==='true':control.value;}
 for(const key of ['total_budget','daily_budget','bid'])if(wanted(key)&&!f.elements[key].disabled&&value(key))out[key]={amount:value(key),currency:value('currency')};
 if(!f.elements.start.disabled){
  if(action==='update'){
   const schedule={};
   for(const key of ['start','end'])if(editedFields.has(key)){if(key==='start'&&!value(key))throw Error('Informe a data de início.');schedule[key]=value(key)?Date.parse(value(key)+'Z'):null;}
   if(Object.keys(schedule).length)out.schedule=schedule;
  }else if(value('start'))out.schedule={start:Date.parse(value('start')+'Z'),...(value('end')?{end:Date.parse(value('end')+'Z')}:{})};
  else if(value('end'))throw Error('Informe a data de início junto da data de fim.');
 }
 if(kind==='campaign'&&targets.length)out.targeting=targets;
 if(kind==='creative'&&action==='create')out.page_id=value('page_id');if(kind==='comment')delete out.post_id;
 if(action==='update'&&!Object.keys(out).length)throw Error('Altere ao menos um campo antes de gerar a prévia.');
 return out;
}
function draft(){
 const i=objectInput(),kind=value('kind'),action=value('action');
 if(['create','update'].includes(action))i.fields=fields();
 if(kind==='video-upload'){const file=f.elements.upload_file.files[0];if(!file)throw Error('Escolha o arquivo para informar seu tamanho.');i.file_size=file.size;}
 return JSON.stringify({op:shape(),input:i});
}
bind('#f3-management-list','click',()=>list());bind('#f3-management-more','click',()=>list(true));
bind('#f3-management-read','click',async()=>{syncSelection();invalidate();await read(true,draftEpoch);});
bind('#f3-management-form','submit',async()=>{
 if(executing)return;syncSelection();invalidate('Gerando nova prévia…');const stamp=draftEpoch,signature=draft(),cmd=JSON.parse(signature);
 if(!revision&&!await read(false,stamp))return;
 if(stamp!==draftEpoch||signature!==draft())return;
 // LinkedIn replaces runSchedule as a whole. Preserve untouched members from this exact revision,
 // including sub-minute precision that is not displayed by the datetime-local editor.
 if(value('action')==='update'&&cmd.input.fields?.schedule){
  const edited=cmd.input.fields.schedule,complete={};for(const key of ['start','end']){
   const v=Object.hasOwn(edited,key)?edited[key]:remoteSchedule?.[key];if(v!=null)complete[key]=v;
  }
  if(!complete.start)throw Error('A programação precisa de uma data de início.');cmd.input.fields.schedule=complete;
 }
 const input={...cmd.input,expected_revision:revision,request_key:Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>b.toString(16).padStart(2,'0')).join(''),dry_run:true};
 const result=await api(cmd.op,input);
 if(stamp!==draftEpoch||signature!==draft())return;
 render(box,result);
 if(result.dry_run===true&&typeof result.confirm_token==='string'&&result.confirm_token){
  preview={op:cmd.op,input,token:result.confirm_token,signature};$('#f3-management-execute').disabled=false;
 }
});
bind('#f3-management-execute','click',async()=>{
 syncSelection();const p=preview;if(executing||!p)return;
 // Capture and consume this exact preview before awaiting any I/O.
 invalidate('Executando a operação confirmada…');if(p.signature!==draft())throw Error('O formulário mudou. Gere uma nova prévia.');
 const stamp=draftEpoch;executing=true;try{
  const r=await api(p.op,{...p.input,dry_run:false,confirm_token:p.token,confirm:true});operation=r;
  $('#f3-write-operation-id').value=r.operation_id;render($('#f3-write-operation-result'),r);
  if(stamp===draftEpoch){render(box,r);revision=null;}
 }finally{executing=false;}
});
async function search(more=false){
 if(!more)clearSearch();if(more&&searchOffset===null)return;
 const stamp=++searchEpoch,ctx=epoch,facet=value('facet'),term=value('target_search'),account=value('account_id'),c=selected().id;
 const r=await api('search-targeting',{connection_id:c,account_id:account,facet,search:term,offset:more?searchOffset:0});
 if(stamp!==searchEpoch||ctx!==epoch||c!==value('connection_id')||account!==value('account_id')||facet!==value('facet')||term!==value('target_search'))return;
 searchRows=more?[...searchRows,...r.rows]:r.rows;searchOffset=r.next_offset;options(f.elements.target_result,searchRows.map((r,i)=>({id:String(i),name:r.name})));$('#f3-target-more').hidden=searchOffset===null;
}
f.elements.facet.addEventListener('change',clearSearch);f.elements.target_search.addEventListener('input',clearSearch);
bind('#f3-target-search','click',()=>search());bind('#f3-target-more','click',()=>search(true));bind('#f3-target-add','click',()=>{const r=searchRows[Number(value('target_result'))];if(!r||value('target_result')==='')throw Error('Escolha um resultado da busca.');targets.push({facet:r.facet,name:r.name,selected_urn:r.urn,search_offset:r.search_offset||0,exclude:value('target_mode')==='exclude'});invalidate();const list=$('#f3-target-selected');list.replaceChildren();targets.forEach((r,index)=>{const line=node('p',(r.exclude?'Excluir: ':'Incluir: ')+r.name),b=node('button','Remover');b.type='button';b.className='button';b.onclick=()=>{targets.splice(targets.indexOf(r),1);line.remove();invalidate();};line.append(b);list.append(line);});});
let journalCursor=null,journalEpoch=0;
function resetJournal(){journalEpoch++;journalCursor=null;$('#f3-write-journal-more').hidden=true;$('#f3-write-journal-result').replaceChildren();}
function journalConnections(){const j=$('#f3-write-journal');if(j)options(j.elements.connection_id,connections.map(c=>({id:c.id,name:c.label})),j.elements.connection_id.value);}
async function listJournal(more=false){const j=$('#f3-write-journal'),id=++journalEpoch,input={connection_id:j.elements.connection_id.value};if(j.elements.state.value)input.state=j.elements.state.value;if(more&&journalCursor)input.cursor=journalCursor;const r=await api('list-write-operations',input);if(id!==journalEpoch)return;journalCursor=r.next_cursor;$('#f3-write-journal-more').hidden=!journalCursor;const root=$('#f3-write-journal-result');if(!more)root.replaceChildren();for(const row of r.operations){const item=node('p');item.append(node('span',[row.operation_id,row.operation,row.state,row.account_id||row.page_id||'',row.created_at?new Date(row.created_at*1000).toLocaleString():'Data não registrada'].join(' · ')));const b=node('button','Consultar');b.type='button';b.className='button';b.addEventListener('click',task(async()=>{$('#f3-write-operation-id').value=row.operation_id;operation=await api('get-write-operation',{operation_id:row.operation_id});render($('#f3-write-operation-result'),operation);}));item.append(b);root.append(item);}if(!r.operations.length)root.append(node('p',journalCursor?'Nenhuma intenção visível nesta página. Continue a consulta.':'Nenhuma intenção encontrada.'));}
bind('#f3-write-journal','submit',()=>listJournal());bind('#f3-write-journal-more','click',()=>listJournal(true));$('#f3-write-journal')?.addEventListener('change',resetJournal);
bind('#f3-write-operation-read','click',async()=>{operation=await api('get-write-operation',{operation_id:$('#f3-write-operation-id').value});render($('#f3-write-operation-result'),operation);});
bind('#f3-write-operation-reconcile','click',async()=>{if(!operation||operation.operation_id!==$('#f3-write-operation-id').value)throw Error('Consulte a operação antes de reconciliar.');operation=await api('reconcile-write-operation',{operation_id:operation.operation_id,expected_operation_revision:operation.operation_revision});render($('#f3-write-operation-result'),operation);});
function credential(){const cf=$('#f3-connection'),id=cf.elements.connection_id.value,rev=Number(cf.elements.expected_revision.value);if(!id||!rev)throw Error('Salve ou escolha uma conexão antes desta ação.');return {connection_id:id,expected_revision:rev};}
bind('#f3-oauth-start','click',async()=>{const r=await api('oauth-start',{...credential(),scopes:[...$('#f3-oauth-scopes').querySelectorAll('input:checked')].map(n=>n.value)});location.assign(r.consent_url);});
bind('#f3-token-inspect','click',async()=>render($('#f3-token-status'),await api('inspect-token',{connection_id:credential().connection_id})));
bind('#f3-token-refresh','click',async()=>{const c=credential();try{render($('#f3-token-status'),await api('refresh-token',c));}finally{document.dispatchEvent(new CustomEvent('f3-linkedin-credential-change',{detail:c}));await tokenStatus();}});
async function tokenStatus(){const r=await api('status');render($('#f3-token-status'),r.access_lifecycle);}
bind('#f3-token-status-load','click',tokenStatus);
document.addEventListener('f3-linkedin-connection-saved',task(tokenStatus));
async function reload(){const stamp=++reloadEpoch;resetJournal();invalidate();const rows=await cfg.readConnections(api);if(stamp!==reloadEpoch)return;connections=rows;const old=value('connection_id');options(f.elements.connection_id,connections.map(c=>({id:c.id,name:c.label})),old);refreshAssets();journalConnections();}
for(const a of document.querySelectorAll('[data-tab]'))a.addEventListener('click',()=>{if(a.dataset.tab==='management')task(reload)();if(a.dataset.tab==='connections')task(tokenStatus)();});
options(f.elements.connection_id,connections.map(c=>({id:c.id,name:c.label})));change();journalConnections();if(cfg.tab==='connections')task(tokenStatus)();
})();
