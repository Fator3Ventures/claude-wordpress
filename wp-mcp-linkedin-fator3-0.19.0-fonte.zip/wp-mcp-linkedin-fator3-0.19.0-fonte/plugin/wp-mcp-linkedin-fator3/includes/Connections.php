<?php
declare(strict_types=1);
namespace Fator3\LinkedIn;
defined('ABSPATH') || exit;

final class Connections {
    public static function get(string $id): array {
        Util::id($id);$r=Store::get('connection',$id);if(!$r)throw new Fault('not_configured','Conexão não cadastrada.');
        $value=self::defaults($r['value']);if(Config::KEY==='f3_linkedin')$value=Credentials::effective($value);return $value+['revision'=>$r['revision']];
    }
    public static function defaults(array $c): array {
        $c['assets']=($c['assets']??[])+array_fill_keys(Config::CHANNELS,[]);
        return $c+['all_forms_accounts'=>[],'lead_discovery_interval_minutes'=>60,'credential_notice_days'=>14,'retention_mode'=>'finite','page_tokens'=>[],'authorization_revision'=>1,'credential_generation'=>1,'token_identity'=>null];
    }
    /** An unreadable diagnostic observation must not disable otherwise readable configuration. */
    private static function readValidation(callable $read): ?array {
        try{return $read();}catch(Fault $e){
            if(!in_array($e->reason,['cipher_unreadable','storage_corrupt'],true))throw $e;
            return ['read_issue'=>$e->reason];
        }
    }
    public static function public(array $c,?array $validation=null,bool $validationLoaded=false): array {
        $c=self::defaults($c);
        if(!$validationLoaded)$validation=self::readValidation(static fn()=>Store::get('validation_proof',$c['id'])['value']??null);
        if($validation!==null){
            $matches=($validation['connection_revision']??null)===($c['revision']??null)
                &&($validation['credential_generation']??null)===$c['credential_generation']
                &&hash_equals(Credentials::binding($c),(string)($validation['binding']??''));
            $c['remote_proof']=$matches?$validation['proof']:null;
            if(isset($validation['read_issue']))$c['remote_proof_error']=$validation['read_issue'];
        }
        $c['refresh_configured']=!empty($c['refresh_token']);unset($c['token'],$c['client_secret'],$c['page_tokens'],$c['refresh_token']);return $c;
    }
    /** One bounded, consistent SQL snapshot for the local administration page. */
    public static function list(int $offset=0,int $limit=100): array {
        global $wpdb;$table=Store::table();
        $rows=$wpdb->get_results($wpdb->prepare(
            "SELECT c.payload,c.revision,r.payload AS credential,p.payload AS proof,a.payload AS candidate,a.expires_at AS candidate_expiry,d.payload AS validation
             FROM %i c LEFT JOIN %i r ON r.bucket='credential' AND r.record_key=c.record_key
             LEFT JOIN %i p ON p.bucket='token_proof' AND p.record_key=c.record_key
             LEFT JOIN %i a ON a.bucket='credential_candidate' AND a.record_key=c.record_key
             LEFT JOIN %i d ON d.bucket='validation_proof' AND d.record_key=c.record_key
             WHERE c.bucket='connection' ORDER BY c.record_key LIMIT %d OFFSET %d",
             $table,$table,$table,$table,$table,min(100,max(0,$limit)),max(0,$offset)),ARRAY_A);
        if($wpdb->last_error)throw new Fault('storage_unavailable','Não foi possível listar as conexões.');
        $decoded=static fn($payload)=>$payload===null?null:['value'=>Store::decode($payload)];
        $out=[];foreach($rows as $row){
            $c=self::defaults(Store::decode($row['payload']));$pending=$decoded($row['candidate']);
            if($pending!==null)$pending['expires_at']=(int)$row['candidate_expiry'];
            $c=Credentials::withRecords($c,$decoded($row['credential']),$decoded($row['proof']),$pending);
            $out[]=self::public($c+['revision'=>(int)$row['revision']],$row['validation']===null?null:self::readValidation(static fn()=>Store::decode($row['validation'])),true);
        }
        return $out;
    }
    public static function save(array $i): array {
        Access::admin();Schemas::validate('save-connection',$i);if(isset($i['credential_notice_days'])&&!is_int($i['credential_notice_days']))throw new Fault('invalid_input','A antecedência dos avisos deve ser um número inteiro de dias.');$id=Util::id($i['connection_id']);
        return Store::lock('connection:'.$id,static function()use($i,$id){
            $old=Store::get('connection',$id);$expected=(int)$i['expected_revision'];
            if(($old['revision']??0)!==$expected)throw new Fault('revision_conflict','Revisão de conexão divergente.');
            if(!$old&&count(Store::list('connection',0,100))>=100)throw new Fault('connection_limit','Limite de 100 conexões.');
            $c=$old?self::defaults($old['value']):['id'=>$id,'label'=>$id,'token'=>'','client_secret'=>'','client_id'=>'','application_id'=>'','enabled'=>true,'expires_at'=>0,'users'=>[get_current_user_id()],'assets'=>array_fill_keys(Config::CHANNELS,[]),'forms'=>[],'api_version'=>Config::API_VERSION,'created_by'=>get_current_user_id(),'created_at'=>time(),'retention_days'=>90,'retention_mode'=>'unlimited','remote_proof'=>null];
            if(!$old&&isset($i['retention_days'])&&!isset($i['retention_mode']))$c['retention_mode']='finite';if(Config::KEY==='f3_linkedin')$c=Credentials::effective(self::defaults($c));$before=$c;
            if(Config::KEY==='f3_linkedin'&&!empty($i['use_pending_authorization'])){$pending=Store::get('credential_candidate',$id);if(!$pending||$pending['expires_at']<=time()||$pending['value']['user']!==get_current_user_id()||$pending['value']['revision']!==$expected)throw new Fault('revision_conflict','A autorização candidata expirou ou a conexão mudou. Autorize novamente.');foreach($pending['value']['credentials'] as $k=>$v)$i[$k]=$v;}
            $warnings=[];if(Config::KEY==='f3_linkedin')$i=ConnectionChanges::normalize($i,$warnings);
            foreach(['token','client_secret','refresh_token'] as $field){
                if(!empty($i['clear_'.$field])&&isset($i[$field])&&$i[$field]!=='')throw new Fault('invalid_input','Escolha entre substituir e remover a mesma credencial.',['field'=>$field]);
            }
            foreach((Config::KEY==='f3_linkedin'?['token','client_secret','refresh_token']:['token','client_secret']) as $k)if(array_key_exists($k,$i)){
                if(!is_string($i[$k])||strlen($i[$k])>16384||(Config::KEY!=='f3_linkedin'&&preg_match('/[\x00-\x20]/',$i[$k])))throw new Fault('invalid_input','Credencial inválida.');
                if($i[$k]!=='')$c[$k]=$i[$k];
            }
            if(Config::KEY==='f3_linkedin'){if(!empty($i['clear_refresh_token']))$c['refresh_token']='';if(isset($i['refresh_expires_at']))$c['refresh_expires_at']=$i['refresh_expires_at'];}
            if(!empty($i['clear_token']))$c['token']='';if(!empty($i['clear_client_secret']))$c['client_secret']='';
            foreach(['label','client_id','application_id'] as $k)if(array_key_exists($k,$i))$c[$k]=Config::KEY==='f3_linkedin'&&$k==='client_id'?$i[$k]:sanitize_text_field($i[$k]);
            foreach(['enabled','expires_at','retention_days','retention_mode','credential_notice_days'] as $k)if(array_key_exists($k,$i))$c[$k]=$i[$k];
            if(isset($i['api_version'])){if(!preg_match(Config::API_PATTERN,$i['api_version']))throw new Fault('invalid_input','Versão API inválida.');$c['api_version']=$i['api_version'];}
            if(isset($i['users'])){$c['users']=array_values(array_unique(array_map('intval',$i['users'])));foreach($c['users'] as $u)if($u<1||!get_userdata($u))throw new Fault('invalid_input','Usuário inexistente.');}
            if(isset($i['assets'])){Util::guardKeys($i['assets'],Config::CHANNELS);foreach($i['assets'] as $channel=>$ids){$ids=array_values(array_unique($ids));foreach($ids as $a)Util::numeric($a);$c['assets'][$channel]=$ids;}}
            if(isset($i['forms'])){if(!in_array('leads',Config::CHANNELS,true))throw new Fault('unsupported','Formulários não pertencem a este plugin.');$c['forms']=[];foreach($i['forms'] as $account=>$forms){$account=(string)$account;Util::numeric($account);if(!in_array($account,$c['assets']['leads'],true))throw new Fault('asset_access_denied','Conta de formulários não selecionada.');foreach($forms as $form)Util::numeric($form);$c['forms'][$account]=array_values(array_unique($forms));}}
            if(Config::KEY==='f3_linkedin'){
                if(isset($i['all_forms_accounts']))$c['all_forms_accounts']=array_values(array_unique($i['all_forms_accounts']));
                if(array_diff($c['all_forms_accounts']??[],$c['assets']['leads']))throw new Fault('asset_access_denied','Todos os formulários exige conta selecionada em leads.');
                if(isset($i['lead_discovery_interval_minutes']))$c['lead_discovery_interval_minutes']=$i['lead_discovery_interval_minutes'];
            }
            if(Config::KEY==='f3_meta'){
                $c=self::defaults($c);
                if(isset($i['retention_mode']))$c['retention_mode']=$i['retention_mode'];
                $authKeys=['enabled','assets','forms','api_version','users','client_id','application_id','client_secret'];$changed=false;
                foreach($authKeys as $k)if(($before[$k]??null)!==($c[$k]??null))$changed=true;
                if($changed)$c['authorization_revision']=($before['authorization_revision']??1)+1;
                if(($before['token']??'')!==$c['token']){$c['credential_generation']=($before['credential_generation']??1)+1;if($old)$c['authorization_revision']++;$c['page_tokens']=[];$c['token_identity']=null;}
            }
            if(Config::KEY==='f3_linkedin'&&(($before['token']??'')!==$c['token']||($before['client_id']??'')!==$c['client_id']||($before['client_secret']??'')!==$c['client_secret'])){if(empty($i['refresh_token'])){$c['refresh_token']='';$c['refresh_expires_at']=0;}$c['credential_generation']=($before['credential_generation']??1)+1;}
            $c['token_configured']=$c['token']!=='';$c['secret_configured']=$c['client_secret']!=='';
            $c['remote_proof']=null;$c['updated_by']=get_current_user_id();$c['updated_at']=time();
            if(Config::KEY==='f3_linkedin')return ConnectionChanges::save($i,$c,$before,$old,$warnings);
            $saved=Store::put('connection',$id,$c,$expected);if(Config::KEY==='f3_meta'&&class_exists(History::class))History::policyChanged($c);return ['persisted'=>true,'connection'=>self::public($c+['revision'=>$saved['revision']])];
        });
    }
    public static function checkpoint(array $c): array {return ['authorization_revision'=>$c['authorization_revision'],'credential_generation'=>$c['credential_generation']];}
    public static function checkPlan(array $v,array $c): void {
        if(Config::KEY==='f3_linkedin'){if(isset($v['authorization_revision'])){if($v['authorization_revision']!==$c['authorization_revision'])throw new Fault('revision_conflict','Ativos ou identidade foram alterados.');}elseif($v['connection_revision']!==$c['revision'])throw new Fault('revision_conflict','Plano legado requer confirmação.');return;}
        if(!isset($v['authorization_revision'])){if($v['connection_revision']!==$c['revision'])throw new Fault('revision_conflict','Plano legado requer confirmação da seleção.');return;}
        if($v['authorization_revision']!==$c['authorization_revision'])throw new Fault('revision_conflict','Ativos ou autorização foram alterados.');
        if($v['credential_generation']!==$c['credential_generation']&&($c['token_identity']['validated_generation']??0)!==$c['credential_generation'])throw new Fault('credential_revalidation_required','A nova credencial precisa ser validada antes de retomar este plano.');
    }
    public static function usable(array $c): void {
        if(!$c['enabled'])throw new Fault('connection_paused','Conexão pausada.');
        if(!$c['token'])throw new Fault('not_configured','Cadastre o token na conexão.');
        if($c['expires_at']&&$c['expires_at']<=time())throw new Fault('token_expired','O prazo cadastrado do token expirou.');
    }
    public static function revalidate(array $c): void {if(self::get($c['id'])['revision']!==$c['revision'])throw new Fault('revision_conflict','A conexão foi alterada durante a operação.');}
}
final class Access {
    public static function admin(): void {if(!current_user_can('manage_options'))throw new Fault('not_authorized','Administração da integração exige manage_options.');}
    public static function human(): void {if(!get_current_user_id())throw new Fault('not_authorized','Autenticação necessária.');}
    public static function connection(array $c,string $channel,?string $account=null): void {
        self::admin();
        self::asset($c,$channel,$account);
    }
    public static function asset(array $c,string $channel,?string $account): void {
        if(!in_array($channel,Config::CHANNELS,true))throw new Fault('unsupported','Capacidade não implementada.');
        if($account!==null&&!in_array($account,$c['assets'][$channel]??[],true))throw new Fault('asset_access_denied','Ativo não selecionado nesta conexão.');
    }
    public static function principal(): array {
        self::admin();$p=['user_id'=>get_current_user_id(),'channel'=>null];
        if(is_callable(['\\Fator3\\McpFiles\\ConnectionContext','get'])){
            $x=\Fator3\McpFiles\ConnectionContext::get();
            if($x&&preg_match('/^(grant:|app:)/',$x['connection_id']??''))$p['channel']=array_intersect_key($x,array_flip(['user_id','connection_id','profile','policy_version','status','expires','abilities']));
        }return $p;
    }
    public static function checkPrincipal(array $p): void {
        $u=get_userdata((int)$p['user_id']);if(!$u||!user_can($u,'manage_options'))throw new Fault('not_authorized','Usuário de origem indisponível.');
        if($p['channel']){
            $sdk='\\Fator3\\McpFiles\\ConnectionContext';$x=$p['channel'];
            if(!is_callable([$sdk,'policy'])||!is_callable([$sdk,'credential_active'])||!$sdk::credential_active($x['connection_id'],$p['user_id']))throw new Fault('not_authorized','Concessão de transporte indisponível ou revogada.');
            $cur=$sdk::policy($x['connection_id']);
            if(!$cur||($cur['_storage']['status']??'')!=='active')throw new Fault('not_authorized','Concessão revogada.');
            $a=array_intersect_key($cur,array_flip(['user_id','connection_id','profile','policy_version','status','expires','abilities']));ksort($a);ksort($x);
            if($a!==$x||!empty($cur['expires'])&&$cur['expires']<=time())throw new Fault('revision_conflict','Concessão de transporte alterada.');
        }
    }
    public static function owned(array $p): void {if(!Util::same(self::principal(),$p))throw new Fault('not_authorized','Resultado pertence a outra identidade/concessão.');self::checkPrincipal($p);}
    public static function worker(array $p,array $c,string $channel,string $account,bool $online=true): void {
        self::checkPrincipal($p);$u=get_userdata($p['user_id']);
        if(!user_can($u,'manage_options'))throw new Fault('not_authorized','Acesso da origem revogado.');
        self::asset($c,$channel,$account);if(!$c['enabled'])throw new Fault('connection_paused','Conexão pausada.');if($online)Connections::usable($c);
    }
}
