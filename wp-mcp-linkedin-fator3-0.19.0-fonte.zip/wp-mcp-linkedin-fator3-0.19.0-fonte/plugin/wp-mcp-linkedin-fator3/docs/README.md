# Fator3 MCP LinkedIn 0.19.0

A release corrente é 0.19.0. Requisitos: WordPress 7.1.4+, PHP 8.3+, ambiente de 64 bits, banco com InnoDB e travas nomeadas, criptografia autenticada e WP-Cron ou cron do sistema. Atualização direta da 0.18.0. A administração fica em **Ferramentas → Fator3 MCP LinkedIn** e exige permissão de administrador.

## Escolha pelo objetivo

| Quero… | Leia |
|---|---|
| Configurar a primeira conexão e conferir o resultado | PRIMEIROS-PASSOS.md |
| Entender as abas, nomes, campos e escopos | ADMINISTRATION.md, FIELD-HELP.md, CONFIGURATION.md e CREDENTIALS.md |
| Consultar Pages/Ads, montar relatórios e agendar coletas | OPERATIONS.md e WORKER.md |
| Escolher formulários, integrar o Core e consultar campanhas de leads | LEAD-DISCOVERY.md, CAMPAIGN-METADATA.md e SDK-PHP.md |
| Conferir o diagnóstico sem consultar o LinkedIn | PRIMEIROS-PASSOS.md e TROUBLESHOOTING.md |
| Revisar uma alteração de anúncio, publicação ou orçamento antes de executar | MANAGEMENT.md |
| Conceder conversões de aquisição ou etapas comerciais | CONVERSIONS.md e STAGE-CONVERSIONS.md |
| Consultar histórico, retenção e cobertura | HISTORY.md |
| Usar as operações como agente ou investigar uma recusa | AGENTS.md, CONTRACTS.md, SECURITY.md, SERVICE-AUDIT.md e TROUBLESHOOTING.md |
| Conferir a atualização | RELEASE-0.19.0.md, MIGRATION.md e CHANGELOG.md |

O pacote registra 99 operações. Os schemas publicados são input-schemas.json, output-schema.json e lead-campaign-schema.json. Notas RELEASE-* de versões anteriores são históricas. O Site Core 1.71.0 é o consumidor vigente de contatos; este plugin mantém as credenciais e o cliente do LinkedIn.

## Ler a ajuda por MCP

Chame `linkedin/documentation` com `{"document":"index"}`. Escolha o ID no índice e leia com `document`, `offset:0` e `limit_bytes` entre 256 e 65536. Enquanto `next_offset` não for nulo, use-o e repita `expected_revision` igual ao hash da primeira página. Concatene os trechos sem separadores e confira bytes e SHA-256. Em conflito de revisão, reinicie pelo índice. A leitura usa apenas documentação local permitida, não requer token LinkedIn e não altera dados nem agendas. O plugin não grava evento de auditoria para a própria operação de documentação.
