# Operações LinkedIn — 0.19.0

Relatórios de Pages/Ads usam os contratos existentes; desde 0.11.0 as estatísticas diárias de Página são percorridas em janelas de até sete dias e mantêm campos de data/identidade mesmo com projeção de métricas. list-fields publica catálogo fechado. Query é paginada, vinculada à seleção, principal e revisão da conexão. create-job/run-job/job-status/control-job/job-results gerenciam coleta durável; schedules criam coletas, não ingerem leads. export/export-read geram CSV/JSON local autenticado. Ausência de resultado não equivale a zero. Consulte schemas instalados para relatórios, granularidades, pivôs e limites.

Lead Sync oferece metadados, respostas, verificação e gerenciamento de assinaturas próprias. Respostas preservam raw e submitted_at_ms de 13 dígitos; não convertem milissegundos nem cadastram contatos. Webhook, persistência antes do ACK, deduplicação e ingestão pertencem ao consumidor. A validação de HMAC não persiste recibo de entrega.

## Diário de assinaturas

O bloqueio persistido considera owner, leadType e formulário versionado. Callback é preservado na intenção, mas não permite contornar bloqueio do mesmo recurso. Conexão, consumidor, revisão ou nova chave idempotente não liberam uma intenção pendente. Um bloqueio nomeado de banco serializa todos os escritores de assinaturas deste site. Registros 0.1 são indexados em lotes antes de qualquer novo POST.

Estados: prepared, dispatching, uncertain, confirmed, deleting, deleted e rejected_before_dispatch; registros legados creating/rejected são tratados conservadoramente. A transição dispatching é gravada antes do POST. Timeout ou queda deixa bloqueio persistido. Recibo remoto com ID é gravado antes de nova leitura ou checagem de acesso. Revogação durante o envio retorna erro com remote_effect conhecido e ownership_key; não apaga o recibo.

As concessões, seleção, callback, usuário humano quando aplicável e revisões são revalidados imediatamente antes de POST/DELETE. A pré-consulta pode revogar acesso; nesse caso nenhuma mutação posterior é enviada. Uma assinatura externa equivalente nunca é adotada como própria.

get_subscription_operation lê o diário do próprio consumidor. reconcile_subscription exige ownership_key e expected_operation_revision. Intenção sem recibo remoto nunca é liberada por listagem vazia: a origem pode estar atrasada. Um prepared comprovadamente sem despacho pode ser marcado rejected_before_dispatch. Com recibo conhecido, GET do ID deve confirmar o mesmo objeto; mudança de credencial exige authorize_current_context, mesma identidade de aplicativo configurada e nova concessão válida. Registros antigos sem application_id não são reatrelados automaticamente; preserve o contexto anterior e use revisão administrativa com evidência do fornecedor.

DELETE exige autoria local, estado confirmado e contexto vigente. Falha de confirmação mantém estado deleting para reconciliação; não é reenviado automaticamente. delivery_verified permanece false: criar assinatura não comprova challenge nem entrega real.

## Registro de serviço CAPI
A emissão ocorre dentro de sendBound, após o recibo local, sem cron de auditoria novo. Falha central não permite reenviar evento entregue/incerto. Leitor e introspector são locais, sem escrita; service_audit distingue capacidade de domínio e admissão central. Consulte SERVICE-AUDIT.md para código de retorno e recuperação.


## Retenção e histórico na 0.11.0

Consulte HISTORY.md: auditoria local configurável com padrão unlimited; conexões existentes preservam a política finita; o acervo diário independe da retenção dos resultados. Nove operações novas, total 90. A consulta local mantém as permissões e a partição da identidade/concessão de origem. A coleta retroativa usa janelas publicadas e não garante integralidade remota. Não alterar documentos de outros pacotes ao entregar esta versão.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central.

## Credenciais na 0.13.0

Pedido MCP LinkedIn 15: espaços externos aparados com aviso; espaços internos e heurísticas de formato são avisos por campo, com decisão remota. Controles, limites máximos, escopos, identidade, CAS e confirmação permanecem. Leia CREDENTIALS.md e RELEASE-0.13.0.md. Sucesso/prévia retornam data.warnings; erros de validação remota retornam details.warnings. Nenhum segredo aparece no aviso.

## Histórico 0.14.0 — pedidos 16/17

Após retorno OAuth, consulte audit (operation=oauth-finish), mensagem e diagnóstico na tela. Para identity_change_required use Renovar agora, Usar autorização candidata, Simular alterações e Confirmar alterações; leia CREDENTIALS.md. Configuração da janela não muda sem prévia.

Seleção automática opcional de formulários: veja LEAD-DISCOVERY.md para configuração da conexão e concessão, simulação, cron, eventos, callback, retomada e dependência real do consumidor Core. A seleção explícita existente permanece padrão.
