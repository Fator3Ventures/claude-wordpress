# Conversões comerciais por etapa — 0.19.0

Atende à fronteira LinkedIn do Pedido Core 323, impacto Core 1.58.0 revisão 2. Contrato opcional `site-conversion-delivery/1.2.0`, consumidor `site-core-quality`, finalidade `crm_stage`. O contrato de aquisição 1.0.0 e a concessão `site-core-conversions` permanecem independentes. São 93 operações: três adições, nenhuma remoção.

## Configuração

Em Ferramentas → Fator3 MCP LinkedIn → Ativos → Conversões de etapas comerciais, selecione conexão, conta previamente autorizada e regra. Carregue as regras, confira a concessão e confirme. Cada ação é um ID numérico string de 1 a 30 dígitos, sem zero inicial. Use regra distinta da aquisição e uma ação própria para cada etapa. Configure esse mapa no Core 1.58.0 ou posterior. Instalar o LinkedIn não cria concessões, regras remotas ou mapas comerciais.

O salvamento verifica `rw_conversions`, `r_ads`, papel de gestão na conta e regra ativa com `conversionMethod=CONVERSIONS_API`. A regra deve pertencer exatamente à conta. A concessão contém consumidor, finalidade, conta, ação, conexão, identidade do concedente, revisões e referência aleatória opaca. Uma nova confirmação gira a referência, inclusive se a seleção for igual. Revogar não depende de HTTP ou token válido. Para aquisição, uma ação com concessão comercial ativa é recusada; para etapas, a regra cadastrada na concessão de aquisição também é recusada. O Core confere adicionalmente sua própria regra de aquisição e a unicidade do mapa.

Operações administrativas (manage_options, REST POST `/wp-json/f3-linkedin/v1/<op>` ou ability `linkedin/<op>`):

| Operação | Entrada e efeito |
|---|---|
| get-stage-conversion-grants | `offset` opcional; até 50 registros examinados, continuar por `next_offset`; lista apenas concessões comerciais. |
| stage-conversion-capabilities | `action` obrigatória; prontidão local da ação exata. |
| save-stage-conversion-grant | `consumer_id`, `purpose`, `action`, `expected_revision`, `enabled`; para ativar também `connection_id`, `account_id`, `expected_connection_revision`. `dry_run` padrão true; persistir exige false e `confirm=true`. |

A prévia de concessão pode ler o fornecedor e atualizar a prova técnica do token; não grava concessão, fila comercial nem envia evento. A confirmação revalida acesso e CAS. Leituras pelo despacho administrativo podem gerar sua linha de auditoria local, como as demais operações. O SDK capabilities, usado pelo Core, é estritamente local, sem escrita/HTTP.

## Negociação e vínculo

```php
$adapter = apply_filters('f3base_conversoes_adaptador', null, 'linkedin',
    'site-conversion-delivery/1.2.0', [
        'consumer_id' => 'site-core-quality',
        'purpose' => 'crm_stage',
        'action' => '221',
    ]);
$cap = $adapter->capabilities();
$reference = $cap['actions']['221']['destination_ref'];
// O consumidor preserva a referência na reserva e só envia após sua elegibilidade.
$result = $adapter->sendBound($payload, $reference);
```

O adaptador de aquisição anuncia `supported_contracts=[1.0.0,1.2.0]` usando os nomes completos. O adaptador comercial retorna `contract`, `supported_contracts`, `purposes=['crm_stage']`, `ready`, `reason` e `actions[ID]` com `action`, `purpose`, `ready`, `reason`, `destination_ref`. Não escolhe outra ação nem reutiliza a concessão de aquisição. Uma referência vazia/divergente é recusada. A prontidão exige prova de token ligada à credencial atual; não herda escopos antigos da concessão. `ready` não certifica disponibilidade remota atual.

Alterações benignas da conexão preservam o vínculo. Mudanças de autorização invalidam a concessão. A troca explícita de identidade, após a confirmação guiada e revalidação das regras, gira as referências comerciais. Eventos já reservados para referências antigas devem ser bloqueados pelo Core, sem substituição automática.

## Envelope fechado

Campos obrigatórios, sem campos extras: `contract=site-conversion-delivery/1.2.0`, `purpose=crm_stage`, `record_id` 32 hex minúsculos, `stage_id` até 60 caracteres, `action` exata, `event_id=f3q-<64 hex>`, `occurred_at` RFC3339 com segundos, `eventId` igual ao event_id, `conversion=urn:lla:llaPartnerConversion:<action>`, `conversionHappenedAt` inteiro em milissegundos exatamente equivalente ao occurred_at e `user.userIds`.

A data original da etapa deve estar nos últimos sete dias, sem futuro. O Core também exige etapa posterior à captura. `userIds` contém um ou dois identificadores, sem tipo repetido: `SHA256_EMAIL` com 64 hex minúsculos e/ou `LINKEDIN_FIRST_PARTY_ADS_TRACKING_UUID` com 1–500 caracteres `[A-Za-z0-9._~-]`. Não admite email em texto, `userInfo`, nome, conteúdo do contato ou conversionValue. O Core calcula a identidade e verifica consentimento atual/snapshot, exclusões, tráfego, origem, contato ativo e janela. O LinkedIn não lê opções privadas nem tabelas de contatos do Core.

Só `eventId`, `conversion`, `conversionHappenedAt` e `user` chegam ao fornecedor. O diário guarda digest HMAC, destino, principal e recibos técnicos; não persiste payload, record_id, stage_id, hash de email ou li_fat_id.

## Entrega, concorrência e recuperação

Usuário WordPress zero é suportado sem impersonação. A ação e referência são revalidadas antes do envio; token, papel e regra são conferidos remotamente. Bloqueios seguem conexão → concessão → entrega; o callback anterior ao HTTP confere novamente revisões/vínculo. O diário passa a dispatching antes do efeito remoto.

A chave de deduplicação inclui consumidor, finalidade, conta, regra e eventId. O digest inclui o envelope validado; mudar conteúdo/instante de evento admitido gera conflito. Confirmado, dispatching ou incerto nunca volta ao HTTP, inclusive após reinício. Recusa comprovada pode ser avaliada pelo consumidor; não há retry comercial automático no LinkedIn.

Resposta: `status=entregue|recusado|incerto`, `code` técnico, `http`, `non_delivery_proven`, e, se admitido no diário, `operation_id`, `replayed`, `central_audit`. Recusa sem efeito é comprovada; timeout, 5xx, exceção ou recibo desconhecido ficam incertos. Aceite HTTP 201 não comprova atribuição da conversão no Campaign Manager.

O diário local e seu leitor de serviço aceitam os dois consumidores. **MCP 0.35.0 passou a aceitar site-core-quality; a 0.36.0 foi exercitada com recibo `recorded` para o consumidor comercial e para aquisição.** A limitação da 0.34.0 é histórica. Uma falha futura do registro central ainda pode retornar `service_record_unconfirmed`, sem autorizar repetição do evento. O tratamento do impacto anterior está no relatório principal da 0.13.0. Nenhum pacote MCP é modificado pelo instalador LinkedIn.

## Operação e recuperação

Os registros conversion_grant e conversion_event continuam no armazenamento cifrado. Para interromper uma etapa, revogue a ação e conserve seus recibos para reconciliação.

Testes usam WordPress e consumidores reais com HTTP sintético. Homologação de credenciais, regras e atribuição reais exige o responsável pelo aplicativo/conta. Referências oficiais: [Conversions API](https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads-reporting/conversions-api?view=li-lms-2026-09) e [schema](https://learn.microsoft.com/en-us/linkedin/marketing/integrations/ads-reporting/conversions-api-schema?view=li-lms-2026-09).
