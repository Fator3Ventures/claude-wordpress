# Instalação e atualização — 0.19.0

Atualização direta da **0.18.0**. Em WordPress 7.1.4+ com PHP 8.3+, substitua o plugin pelo ZIP instalador 0.19.0, sem desinstalar. Preserve o banco e as salts que protegem os registros cifrados. O schema físico continua em 2; não há conversão em massa nem necessidade de recriar conexões, concessões, agendas ou diários.

1. Em uma nova requisição, confira a versão no WordPress e leia RELEASE-0.19.0.md na aba Ajuda. Pelo MCP, consulte `linkedin/documentation` com `{"document":"index"}`.
2. Abra **Diagnóstico**. Consulte o estado local e execute o autoteste. Compare as conexões, as agendas e os avisos esperados com a situação anterior. Essas operações podem produzir auditoria local; não alteram configurações nem consultam o LinkedIn.
3. A prova de ativo anteriormente registrada na configuração continua como observação histórica; não há migração em massa. A atualização não reativa concessões que já estavam obsoletas na 0.18.0. Confira o vínculo atual antes de reconfirmar uma concessão. Quando o administrador pedir uma nova validação, o plugin guardará a prova separadamente, na mesma tabela cifrada. A revisão devolvida será a da configuração em uso. Veja CREDENTIALS.md para distinguir essa prova da introspecção do token.
4. Para conferir **Anúncios e publicações**, escolha destino e ação e leia o aviso de efeito. Pare antes de carregar objetos, gerar prévia ou executar se a verificação deve ser inteiramente local. Consulte MANAGEMENT.md para o procedimento de revisão com acesso autorizado ao fornecedor.

A atualização não concede permissões nem cria ativos ou assinaturas no fornecedor. Os contratos e operações existentes continuam disponíveis. Consulte o relatório da rodada para as versões e os ambientes efetivamente verificados. Falha observada após instalação é corrigida em nova versão; preserve backups para recuperar dados.
