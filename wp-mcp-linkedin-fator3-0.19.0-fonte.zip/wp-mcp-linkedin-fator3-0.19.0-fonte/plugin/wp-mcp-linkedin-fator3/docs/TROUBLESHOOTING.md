# Diagnóstico — 0.19.0

`status` informa versão, banco, criptografia e execução do cron. `selftest` realiza verificações locais; não valida credenciais externas. `validate-connection` lê identidade do ativo, sem prometer todas as métricas. Consulte auditoria paginada para códigos sanitizados.

| O que você quer saber | Ação | Como interpretar |
|---|---|---|
| O worker, o armazenamento e a criptografia estão disponíveis? | **Consultar estado local** | Leia o resumo, os avisos das agendas e os incidentes de credencial. Em **Ver detalhes técnicos**, consulte os dados completos. O diagnóstico não repara o worker nem renova tokens. |
| O plugin passa nas verificações internas? | **Executar autoteste local** | O painel mostra a quantidade de verificações locais aprovadas. O resultado não confirma produtos ou permissões no LinkedIn. |
| Esta conexão consegue ler este ativo? | Escolha conexão salva, canal e ativo autorizado; use **Validar ativo no LinkedIn**. | A ação consulta o fornecedor e guarda a prova local de metadados. Uma seleção vazia ou conexão pausada não habilita o botão. |
| Por que uma concessão antiga aparece obsoleta? | Leia suas revisões e a seleção vigentes. | Validar novamente não reconfirma uma concessão já obsoleta. Se o vínculo e as permissões ainda corresponderem ao objetivo, use a prévia e a reconfirmação da concessão afetada. |

No grupo **Verificar acesso a um ativo**, trocar a conexão, o canal ou o ID só atualiza a seleção salva. O canal de formulários/leads mostra as contas autorizadas, não os formulários individuais; validar confere metadados da conta, não acesso às respostas. No grupo **Estado local**, uma segunda consulta assume o lugar da anterior; mudar a seleção externa ou sair de Diagnóstico descarta a apresentação da resposta antiga. Isso protege a tela. Uma validação externa que já foi enviada ainda pode concluir e guardar a prova do alvo original.

- not_authorized: confirme manage_options ou a concessão vigente do consumidor SDK.
- revision_conflict: releia a configuração; uma revisão não é intercambiável com outra.
- token_expired/token_rejected: renove e valide a credencial; resultados históricos locais não dependem de token válido.
- rate_limited: aguarde retry_after; o agendador aplica adiamento.
- upstream_validation: confirme versão, campo, produto e aprovação do aplicativo.
- operation_uncertain: consulte e reconcilie o diário; não gere outra chave para contornar o bloqueio.
- history_changed: a visão paginada mudou; reinicie consulta/exportação com nova chave.
- response_limit: reduza campos ou limit. Não considere uma resposta truncada completa.
- cipher_unreadable: confira salts e restauração; não tente regravar sobre dado ilegível.
- storage_unavailable/persistence_unconfirmed: verifique banco, espaço e bloqueios; preserve o backup.
- schedule_retry_pending: a agenda aguarda nova tentativa da ocorrência original. Consulte o horário mínimo e o último código em WORKER.md; não recrie a agenda para antecipar a execução.

Cron depende de visitas se não houver agendador do servidor. Execução alternativa: `wp f3-meta run` / `wp f3-linkedin run`. Cada passo tem orçamento; grandes coletas exigem múltiplas execuções. O usuário que criou uma agenda precisa continuar autorizado.

## Novos códigos e ações

scope_missing: reautorize o app com a permissão requerida; não altere somente rótulos locais. application_required: configure ID e segredo para introspecção. targeting_ambiguous: escolha um resultado da busca e mantenha search_offset. preview_required/preview_stale: releia e gere prévia. revision_conflict: confronte a versão atual antes de nova decisão. operation_uncertain/verification_pending: consulte operation_id e reconcilie sem reenviar. refresh_unavailable/refresh_expired: aplicativo não emitiu refresh ou prazo venceu; reautorize. oauth_rejected: conferir app, produto e credenciais. O token atual é preservado em falha de refresh.

## Serviço CAPI
service_principal_unsupported é esperado sem o Fator3 MCP ou com MCP anterior à 0.28.0: falta consumidor central, não credencial LinkedIn. service_record_unconfirmed exige conferir persistência/digest no canal compatível, sem repetir POST. service_authority_unavailable ou service_identity_mismatch exige verificar concessão/revisão, ativo e prova local; não vincular automaticamente referência antiga a grant novo. service_operation_unbound identifica diário legado. Consulte SERVICE-AUDIT.md.

## Códigos novos da 0.8.0

`worker_missing`, `schedule_overdue`, `schedule_authorization_failed`, `queue_migration_pending`, `queue_record_unreadable` e `maintenance_missing` aparecem em `linkedin/status.issues`; a tabela de ações está em WORKER.md. `regra_divergente` em `diagnose-conversions` indica que a regra de servidor do Site Core difere da regra concedida.

## Histórico 0.14.0 — pedidos 16/17

token_rejected no retorno OAuth: o diagnóstico distingue inactive, client_id_mismatch e expired. HTTP200/active=false pode indicar vínculo token/aplicativo incorreto. Não há prova da causa histórica sem novo retorno. Nunca exponha corpo bruto. identity_change_required com token válido é incidente de confirmação; use Renovar agora e siga CREDENTIALS.md, sem repetir tentativas automáticas.

Criação 4xx sem recibo: consulte `state:rejected`, HTTP e mensagem sanitizada; nova chave pode seguir após corrigir a causa. `app_account_not_listed`: Developers → aplicativo → Products → Advertising API → View Ad Accounts → Add Ad Account. `operation_uncertain` bloqueia apenas a mesma intenção, não todo o site. Quando não há recibo conciliável, `close-write-operation` exige decisão explícita, revisão e risco de duplicação aceito; veja MANAGEMENT.md. Não apague diário nem confunda `closed/unknown` com ausência comprovada.

Lead Sync: `leadNotifications` usa `q=criteria` e `owner.value`; `leadFormResponses` continua `q=owner`. Falha anterior ao POST informa `remote_effect:none` e fase/motivo; recibo incerto já existente preserva `unknown`. Para novos formulários, confira LEAD-DISCOVERY.md, ambas as seleções, contrato do consumidor, callback e `lead-discovery-status`. Core 1.67.0 ainda não incorpora automaticamente formulários: requer implementação do consumidor; não é solucionado alterando options privadas.


## Atualização 0.17.0

Leia RELEASE-0.17.0.md: diário de intenções com filtro/IDs completos (MANAGEMENT.md), recuperação limitada de projeção de leads (CAMPAIGN-METADATA.md), descoberta em lote e adoção de recibos próprios (LEAD-DISCOVERY.md), preservação/reconfirmação por domínio (CREDENTIALS.md). 99 operações. Falha de enriquecimento opcional não autoriza ignorar erros de acesso, quota ou identidade. Não alterar documentos centrais de outros pacotes.
