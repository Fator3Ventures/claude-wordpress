# Segurança e dados — 0.19.0

Credenciais, resultados, cursores, diários e exportações são cifrados com chave derivada dos salts do site e do blog. Backup deve incluir banco e salts. Não há URL pública de exportação. Nunca coloque tokens em tickets, documentação ou capturas de tela. Trocar salts pode tornar os dados cifrados ilegíveis.

Ativos vazios significam nenhum ativo autorizado. Todas as entradas humanas exigem manage_options. Tarefas revalidam o usuário de origem, concessão do transporte, seleção e contexto antes do HTTP e antes da entrega persistente. Revogação suspende a coleta e impede leitura local. SDK de consumidor explicitamente concedido não depende de usuário WordPress autenticado.

HTTP usa hosts fixos, caminhos permitidos, TLS, nenhuma redireção, limite de tempo/bytes e quota local por conexão. Dados da API nunca são interpretados como instruções ou caminhos executáveis. CSV neutraliza prefixos de fórmula. Auditoria guarda operação, identidade e código; não guarda token, secret ou payload de leads.

Desativação e desinstalação preservam dados cifrados; removem somente cron deste plugin. Remoção definitiva de dados exige procedimento administrativo deliberado com backup. Não há limpeza automática de dados de outros plugins.

## Gestão e ciclo de acesso

Diário, refresh e confirmações usam criptografia autenticada existente. Travas por alvo/conexão, prova de escopos e revalidação imediatamente antes do envio reduzem repetição e acesso obsoleto. Seleções de Página/conta/formulário nunca são ampliadas pela busca. OAuth state é de uso único e depende da sessão administrativa. Ações de mídia podem devolver URLs assinadas somente ao administrador; não exporte esses recibos para logs ou impactos. Renovação não publica nem altera anúncios.

CAPI: nenhuma identificação pessoal do payload persiste no diário ou eventos. O digest é HMAC local cifrado e não é exposto. A concessão comprova dono/conta/regra e é revalidada no envio; fonte não API é bloqueada. Não existe bypass de usuário para inserir serviço no Registro central.

## Auditoria de serviço
A 0.7.0 separa principal de serviço de usuário WordPress/OAuth. O evento é uma projeção fechada sem PII; concessão e revisão atuais são conferidas por introspector PHP local. O leitor administrativo exige dono da concessão, seleção e perfil. Referências opacas não são autorização de envio. Revogação bloqueia detalhe e preserva histórico; não há importação retroativa. Veja SERVICE-AUDIT.md.


## Retenção e histórico na 0.11.0

Consulte HISTORY.md: auditoria local configurável com padrão unlimited; conexões existentes preservam a política finita; o acervo diário independe da retenção dos resultados. Nove operações novas, total 90. A consulta local mantém as permissões e a partição da identidade/concessão de origem. A coleta retroativa usa janelas publicadas e não garante integralidade remota. Não alterar documentos de outros pacotes ao entregar esta versão.

## Etapas comerciais na 0.12.0

Leia STAGE-CONVERSIONS.md e RELEASE-0.12.0.md: contrato opcional 1.2.0 para site-core-quality/crm_stage, concessão própria por ação, três operações novas (93 no total), referência vinculada e incerteza durável. A aquisição 1.0.0 continua independente. MCP 0.35.0 passou a admitir esse consumidor; a integração foi repetida com MCP 0.36.0 e recibo central recorded. Em MCP 0.34.0 a limitação histórica permanece. Não repetir evento por falta de recibo central.

## Credenciais na 0.13.0

Pedido MCP LinkedIn 15: espaços externos aparados com aviso; espaços internos e heurísticas de formato são avisos por campo, com decisão remota. Controles, limites máximos, escopos, identidade, CAS e confirmação permanecem. Leia CREDENTIALS.md e RELEASE-0.13.0.md. Sucesso/prévia retornam data.warnings; erros de validação remota retornam details.warnings. Nenhum segredo aparece no aviso.

## Histórico 0.14.0 — pedidos 16/17

OAuth 0.14.0: diagnóstico fechado de HTTP/atividade/cliente/validade/escopos, sem resposta bruta ou material OAuth. App e callback URI vinculados ao início; state/sessão/CAS preservados. A reserva do aviso evita duplicação após resultado incerto de wp_mail.

