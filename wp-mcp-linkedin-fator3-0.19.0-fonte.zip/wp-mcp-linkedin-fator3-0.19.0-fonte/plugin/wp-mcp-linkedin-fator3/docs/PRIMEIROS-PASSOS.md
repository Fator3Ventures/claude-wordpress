# Primeiros passos — 0.19.0

Em **Ferramentas → Fator3 MCP LinkedIn**, use a sequência abaixo. Os nomes de contas e membros ajudam a identificar escolhas; a autorização continua vinculada ao ID.

1. **Conexão.** Use a busca local por nome ou identificador para localizar uma conexão, ou Mostrar mais conexões para ver os próximos oito cartões. Escolha Nova conexão ou Editar conexão. Dê um nome reconhecível (membro · aplicativo). Em Credenciais do aplicativo, preencha Client ID, segredo e token conforme a integração. Confira a validade UTC. Um campo secreto vazio mantém o segredo salvo; marque a remoção somente no grupo destinado a isso. Informar e remover o mesmo segredo na mesma requisição é recusado antes de gravar.
2. **Acesso e guarda.** Associe usuários administradores. Em Guarda dos resultados de coleta, escolha sem expiração ou prazo em dias. O modo sem expiração desativa o campo de dias. O prazo de auditoria é separado, na aba Retenção. Salve a conexão; mudanças de identidade ou no aviso de vencimento exigem simulação e confirmação. A prévia explica o efeito sobre cada concessão.
3. **Ativos.** Escolha a conexão, carregue nomes e marque Páginas, contas de anúncios ou contas de formulários. Salve a seleção. Para formulários individuais, primeiro salve a conta e depois marque os formulários. Nenhum ativo descoberto é autorizado por aparecer na lista.
4. **Concessões.** Em Formulários e concessões, selecione consumidor, conta, formulários e permissões, com o callback do consumidor. Em Ativos, a aquisição e as etapas comerciais têm concessões separadas. Salvar a conexão não cria uma concessão CAPI, uma campanha ou um contato.
5. **Diagnóstico.** Use **Consultar estado local** e **Executar autoteste local**. No grupo **Verificar acesso a um ativo**, escolha a conexão salva, o canal e um ID já autorizado; essas escolhas são locais. Para consultar a origem, use **Validar ativo no LinkedIn**. Esse botão consulta metadados no fornecedor e guarda uma prova local. Um autoteste aprovado não certifica permissões no LinkedIn. Se precisar mudar a versão da API, simule, leia o efeito nas concessões e confirme a mesma seleção. Edite novamente se a revisão mudou.

| Situação | Próxima ação |
|---|---|
| Lista de ativos vazia | Confira conexão/canal, escopos e seleção salva antes de conceder algo. |
| Campo secreto em branco ao editar | Deixe vazio para manter. O painel nunca mostra o valor salvo. |
| Política de retenção editada após simular | Simule de novo e só confirme o prazo que aparece na prévia. |
| Concessão bloqueada | Confira conta, escopo e regra indicados; regrave somente o vínculo afetado. |
| Conflito de revisão | Reabra a conexão ou política para obter o estado atual e repita a simulação. |
| Operação com efeito remoto incerto | Consulte o diário e reconcilie o recibo. Não repita uma criação sem verificar seu estado. |

Exemplos de leitura administrativa: `linkedin/list-connections` com `{"offset":0}`; prossiga por `next_offset`. `linkedin/get-retention` com `{}` retorna a revisão da política. Para simular 30 dias, envie a `linkedin/save-retention` `{"expected_revision":N,"audit_mode":"finite","audit_days":30,"dry_run":true}` substituindo N pela revisão lida. A prévia retorna a quantidade elegível; a gravação explícita agenda o efeito para a manutenção. A simulação não remove eventos.

## Conferir a instalação sem dirigir operações ao LinkedIn

1. Abra **Ajuda** e consulte o índice e a nota desta versão. Para leitura estritamente sem gravação, também é possível abrir os arquivos instalados em `docs/` do plugin, sem invocar nenhuma operação.
2. Em **Diagnóstico**, use **Consultar estado local** ou **Executar autoteste local**. Confira o resumo e os avisos; abra **Ver detalhes técnicos** se precisar do código ou da versão. Esses comandos não alteram conexões nem consultam o fornecedor; a execução pode ficar na auditoria do plugin. Se iniciar uma nova consulta antes da resposta, o painel apresenta o resultado da mais recente.
3. Em **Anúncios e publicações**, escolha o recurso e a ação e leia o aviso da confirmação. Para verificar a interface sem acessar o fornecedor, pare antes de carregar objetos, solicitar uma leitura, gerar prévia ou executar. Para exercitar as etapas seguintes sem dados reais, use o instalador em uma bancada isolada com HTTP simulado.
4. Em bancada, simule duas respostas de leitura/validação em ordem inversa ou edite o rascunho enquanto a prévia está pendente. O resultado antigo não deve substituir o atual; a confirmação só deve ficar disponível depois da prévia do rascunho atual. Acompanhe MANAGEMENT.md para decidir quando a confirmação é apropriada em operação autorizada.

Aquisição, regras, campanhas, leads e assinaturas reais dependem do aplicativo e da conta autorizados. Este guia não concede acesso externo.
