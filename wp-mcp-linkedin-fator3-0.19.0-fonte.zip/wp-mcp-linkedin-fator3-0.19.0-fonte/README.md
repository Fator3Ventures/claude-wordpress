# Fator3 MCP LinkedIn 0.19.0 — fonte completo

Atualização direta da 0.18.0. Requisitos: WordPress 7.1.4+ e PHP 8.3+ em 64 bits. A documentação para o administrador está no instalador em docs/ e no painel **Ferramentas → Fator3 MCP LinkedIn → Ajuda**. Comece por PRIMEIROS-PASSOS.md, RELEASE-0.19.0.md e MIGRATION.md.

## Build e empacotamento

Use PHP 8.3+ no PATH (ou indique F3_SOCIAL_PHP) e execute `python3 build/build.py`. Código e manuais editáveis estão em build/common, build/linkedin, build/assets e build/docs/linkedin. O build monta os schemas e o catálogo da documentação, verifica PHP e produz o instalador determinístico em build/dist. A árvore plugin/wp-mcp-linkedin-fator3 contém exatamente os arquivos instaláveis. O compactador do fonte é `python3 tools/package-source.py --output-dir /diretorio/externo`. A cópia interna do relatório antecede seu fechamento.

## Reproduzir os testes

Copie tools/lab-release0190.example.json e ajuste os caminhos aos pacotes e runtimes verificados. A bancada usa um WordPress descartável 7.1.4, PHP 8.3.6 e MySQL 8.0.46, com schema exclusivo por execução. SQL de produção, credenciais reais e dados do Site-Teste não integram o fonte. Use diretório vazio e banco descartável, nunca o WordPress compartilhado. Cada teste PHP carrega um novo processo do WordPress; o HTTP de provedor é interceptado por fixtures.

```bash
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li019-worker --order linkedin-integrated --tests worker019.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li019-migration --order linkedin-integrated --origin upgrade --tests migration019.php,lifecycle019.php,mcp-docs080.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li019-management --order linkedin-integrated --tests management019.php
python3 tools/lab.py --manifest /caminho/lab.json --workdir /tmp/li019-diagnostics --order linkedin-only --tests diagnostic019.php
```

Para a interface com jsdom, forneça F3_JSDOM (27.4.0, lockfile em tests/dom) e CODEX_PRIMARY_RUNTIME_NODE. Para o Chrome real, consulte tests/browser/README.md e ajuste F3_CHROME_HEADLESS_SHELL; execute webui019.php em laboratório novo. As verificações de backend, gestão e interface usam bancos separados quando criam concessões/contas sintéticas. Para reproduzir a diferença no comportamento antigo, use o instalador 0.18.0 com --candidate no mesmo cenário de laboratório. Os relatórios JSON ficam em evidence/ da bancada.

## Evidências e limites

evidence/release0190/ contém as provas atuais, comparação com a base, regressão, ambiente e Site-Teste; inputs/0.19.0/ preserva entradas documentais e hashes. Evidências e notas anteriores são históricas. Nenhuma fixture, banco de laboratório, browser ou dependência de desenvolvimento entra no instalador. Leia o relatório da rodada para as versões dos acompanhantes e os limites da homologação de fornecedor.
