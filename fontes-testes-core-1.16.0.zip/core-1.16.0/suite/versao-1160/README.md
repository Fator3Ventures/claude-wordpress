# Bancada 1.16.0

Somente laboratório descartável. Os scripts exigem `.f3base-bancada-110` na raiz WordPress; o nome histórico da trava e dos diretórios runtime1150/lab1150 é interno à bancada, não uma dependência de runtime do plugin. Fixtures podem limpar tabelas sintéticas, trocar senha do usuário 1 e bloquear e-mails. Nunca execute em produção.

Ambiente usado: Linux, Python 3, Node, PHP 8.3.6 com mysqli/mbstring/dom/sodium, MySQL 8.0.46, WordPress 7.1.2, WP Super Cache 3.1.3; Chrome Headless Shell 151 e Playwright. Lighthouse 13.5.0 fica em lab1150/downloads/node_modules. Terser 5.44.0 é fixado por package-lock em suite/build-assets. Os executáveis/dependências não estão no ZIP de fontes. Provisionar pelos distribuidores oficiais.

Estrutura esperada sob F3BASE_TEST_WORKSPACE: work/core-1.16.0 (esta pasta); lab1150/wordpress (WordPress isolado com usuário administrador 1 e plugin instalado); runtime1150/php (PHP executável com libs), runtime1150/root/usr (MySQL), runtime1150/headless/chrome-headless-shell-linux64 (navegador). Leia os caminhos nos harnesses para adaptá-los ao ambiente local. wp-config deve apontar para MySQL 127.0.0.1:3316 / banco f3base1150; o harness inicia apenas essa instância local. Playwright está no caminho de dependências indicado no início dos scripts de navegador. Não baixar ou copiar credenciais de sites.

Com a bancada preparada, dentro desta pasta:

```bash
node suite/build-assets/build.cjs fontes/plugin --check
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/run-php.py core crm credenciais capi bordas llms novas origens fechamento
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/upgrade.py
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/run-http.py
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/concorrencia.py
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/run-admin.py
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/run-cta.py
F3BASE_TEST_WORKSPACE=/CAMINHO node suite/versao-1160/consentimento.cjs
F3BASE_TEST_WORKSPACE=/CAMINHO node suite/versao-1160/consentimento-tema.cjs
F3BASE_TEST_WORKSPACE=/CAMINHO node suite/versao-1160/transporte.cjs
F3BASE_TEST_WORKSPACE=/CAMINHO python3 suite/versao-1160/lab.py python3 suite/versao-1160/run-http.py performance
```

Execute os comandos que usam banco/servidor sequencialmente, após sincronizar fontes/plugin com wp-content/plugins/base-site-core-fator3. A atualização usa o binário real 1.15 incluído em referencias (hash conferido), ou a pasta local work/core-1.15.0. Nenhum ensaio de downgrade é necessário/distribuído na suíte atual. HTTP público usa fixtures; CRM/CAPI/Meta interceptam transporte com respostas sintéticas. Isso não homologa a conta real.

`evidencias/` contém os resultados finais e capturas. Algumas verificações são reexecuções/reutilização dos contratos da base; o número é de asserções, não cenários independentes. `pageshow.persisted` foi evento controlado. Performance conserva presets padrão do Lighthouse e registra trace/devtools/configuração resolvida; não equivale a PageSpeed externo.

`documentar.php` com F3BASE_DOCS_OUT gera contrato estrutural e matriz de ajuda, sem valores do site. `documentar-catalogo.php` exporta declarações. O instalador é construído por `python3 montar-release.py --saida /DESTINO`; `fechar-release.py` gera relatório, fontes e somas a partir das evidências. Confira VALIDACAO.md antes de declarar aceite.

Revisão 2: credenciais cobre verificação concorrente, revogação e alternativas sem catálogo; CRM cobre perda da resposta de lead e conferência posterior; origens cobre rotação preservando cursores. CTA sem WhatsApp usa navegação real e confere o banco pela correlação, sem depender da leitura do corpo da resposta após unload.
