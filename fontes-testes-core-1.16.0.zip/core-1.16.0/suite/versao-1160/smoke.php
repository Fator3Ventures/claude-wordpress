<?php
require __DIR__.'/bootstrap.php';
$r=F3Base_Instalacao::atualizar();echo wp_json_encode(array('versao'=>F3BASE_PLUGIN_VERSAO,'instalacao'=>$r,'estado'=>get_option('f3base_release_1160'),'navegacao'=>F3Base_Navegacao::diagnostico(),'sodium'=>function_exists('sodium_crypto_secretbox')))."\n";
