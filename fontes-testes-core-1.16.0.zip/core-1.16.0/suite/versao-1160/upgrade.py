"""Only fresh 1.16 and actual completed 1.15 -> 1.16, isolated local DBs. No downgrade."""
from pathlib import Path
import os,subprocess,json,shutil,uuid,re,zipfile,hashlib
root=Path(os.environ['F3BASE_TEST_WORKSPACE']);base=Path(os.environ['F3BASE_SITE']);php=root/'runtime1150/php';suite=Path(__file__).parent;out=[]
(suite/'evidencias').mkdir(exist_ok=True)
for origin in ['nova','1.15.0']:
 target=root/'lab1150'/('upgrade-1160-'+origin);target.mkdir(exist_ok=True)
 for p in base.iterdir():
  if p.name in ['wp-config.php','wp-content','llms.txt','robots.txt','.htaccess'] or p.name.startswith('.'):continue
  dest=target/p.name
  if not dest.exists():dest.symlink_to(p,target_is_directory=p.is_dir())
 (target/'.f3base-bancada-110').touch();wc=target/'wp-content';(wc/'plugins').mkdir(parents=True,exist_ok=True);(wc/'mu-plugins').mkdir(exist_ok=True)
 (wc/'mu-plugins/fixture.php').write_text("<?php add_filter('pre_wp_mail',static fn()=>true); add_filter('pre_http_request',static fn()=>new WP_Error('fixture_sem_rede','No external calls in lab')); ")
 if not (wc/'themes').exists():(wc/'themes').symlink_to(base/'wp-content/themes')
 db='f3base_upgrade1160_'+uuid.uuid4().hex[:10];config=(base/'wp-config.php').read_text().replace("'f3base1150'",repr(db));config=re.sub(r"define\('WP_CACHE',true\);define\('WPCACHEHOME',[^;]+;", "define('WP_CACHE',false);",config);(target/'wp-config.php').write_text(config)
 mysql=[str(root/'runtime1150/root/usr/bin/mysql'),'--no-defaults','--protocol=TCP','-h','127.0.0.1','-P','3316','-u','root'];subprocess.run(mysql+['-e',f'CREATE DATABASE {db} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;'],check=True)
 link=wc/'plugins/base-site-core-fator3'
 def install(version):
  if link.exists():shutil.rmtree(link)
  source=root/('work/core-'+version+'/fontes/plugin')
  if source.exists():shutil.copytree(source,link)
  elif version=='1.15.0':
   archive=suite.parents[1]/'referencias/base-site-core-fator3-1.15.0.zip'
   if hashlib.sha256(archive.read_bytes()).hexdigest()!='23a047da1873d9cc4372f672423e4536596cc06dcd24266209443384847cf05b':raise RuntimeError('Baseline 1.15 divergente')
   with zipfile.ZipFile(archive) as z:z.extractall(wc/'plugins')
  else:raise RuntimeError('Disponibilize as fontes atuais em work/core-1.16.0/fontes/plugin')
 install('1.16.0' if origin=='nova' else origin);env=os.environ|{'F3BASE_SITE':str(target),'F3BASE_ORIGEM':origin}
 for step in ['instalar','semear','atualizar','repetir','retomar']:
  if step=='atualizar':install('1.16.0')
  run=subprocess.run([str(php),str(suite/'upgrade.php'),step],env=env,capture_output=True,text=True)
  try:result=json.loads(run.stdout)
  except:result={'stdout':run.stdout[-4000:],'stderr':run.stderr[-3000:]}
  out.append({'origem':origin,'passo':step,'exit':run.returncode,'resultado':result,'stderr':run.stderr[-3000:]});print(origin,step,run.returncode,result.get('falhas',result),flush=True)
  if run.returncode:break
(suite/'evidencias/upgrade.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));raise SystemExit(any(x['exit'] for x in out))
