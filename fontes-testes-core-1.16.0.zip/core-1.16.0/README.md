# F3 Base Core 1.16.0 — fontes e entrega

Instalador: base-site-core-fator3-1.16.0.zip. Requisitos: WordPress 6.4+, PHP 8.1+ de 64 bits; não multisite. Recursos de Abilities/MCP dependem da API correspondente disponível no WordPress. Sodium é necessário para gravar/abrir segredos das integrações. Os únicos caminhos são instalação nova ou atualização da 1.15.0 concluída; não há suporte de downgrade.

Leia fontes/plugin/docs/DOCUMENTACAO.md para a documentação instalada. RELATORIO-1.16.0.md e docs/VALIDACAO.md distinguem implementação, testes locais e homologações pendentes. Nenhum site foi implantado nesta entrega. Pipedrive/Meta/Google começam desligados; contas reais não foram acessadas para homologação.

Build do instalador: `python3 montar-release.py --saida /DESTINO`. O script inclui todos os arquivos de fontes/plugin, produz ZIP com diretório WordPress único e manifesto SHA-256 por arquivo. Assets: `node suite/build-assets/build.cjs fontes/plugin --check`; package-lock fixa a ferramenta. Execução dos testes somente na bancada descartável descrita em suite/versao-1160/README.md; bloqueio de rede externa explícito no MU-plugin de fixture. Nunca copiar esse MU-plugin para produção.

Fechamento: `python3 fechar-release.py --saida /DESTINO --baseline /CAMINHO/base-site-core-fator3-1.15.0.zip`. Baseline real incluída em referencias com hash conferido; serve somente ao ensaio de atualização. Suite de versões anteriores e downgrade não integra o pacote de fontes atual. As dependências de PHP/MySQL/WordPress/Chrome/Playwright/Lighthouse são externas ao ZIP.

Os arquivos de código e documentação seguem a licença do plugin, GPL-2.0-or-later. Assets de terceiros mantêm seus avisos próprios.
