> Implementação autorizada em 29/09/2026. A decisão acima sobre ausência de downgrade prevalece sobre referências históricas à recuperação presentes no parecer.

# F3 Base — plano proposto para a versão 1.16.0

Data: 29/09/2026 (America/Sao_Paulo). Revisão 6: incorpora a análise das 16 recomendações técnicas de 29/09, com reconciliação Google, segredos cifrados, executor e motor compartilhado de filas, navegação em option única, métricas e catálogo de agentes revistos, macros OpenAI e contrato 4.0.0. Mantém Pipedrive, as origens de anúncios nos limites de disponibilidade já definidos, a correção dos assuntos de e-mail, pendências pós-1.15.0, navegação, UX e Agentes e buscadores. Estado: planejamento; nenhuma alteração aplicada ao plugin, ao CRM ou aos sites nesta análise.

## 1. Conclusão da verificação

**O suporte solicitado ao menu clássico ainda não foi atendido. As melhorias de configuração foram parcialmente implementadas, mas há um defeito funcional nas sub-abas e explicações que precisam de revisão.**

Também entra nesta release a melhoria **M1 — Agentes e buscadores**: tornar essa análise visível em Medição e ampliar o detalhamento de agentes, conteúdos requisitados e frequência observada. Na 1.15.0, a área existente está em Técnico → Acessos do servidor; a coleta não foi removida.

Dos 22 itens do relatório pós-1.15.0, **19 entram como código ou medição**, dois continuam como aceite em produção de correções anteriores (50 e 52) e o grupo 17 passa a ter escopo parcial nesta release: **Pipedrive entra**, enquanto webhook genérico de saída e confirmação por URL seguem adiados. Os detalhes e as ressalvas estão nas seções 7 e 8; nenhuma pendência será declarada encerrada apenas por constar deste plano.

Além dos itens do arquivo, entra **C4 — assunto dos e-mails de formulário sem duplicação do nome do site**, relatado pelo dono após a revisão 3. Esse identificador é interno ao plano e não altera a numeração do backlog da frota.

**CRM1 — Pipedrive** inclui registro local antes da entrega, fila persistente, configuração por site, mapeamento comercial e histórico de interação autorizado. **ADS1/ADS2** incluem captura nativa da Meta e do Google Ads. **ADS3 — LinkedIn** fica condicionado à aprovação do app; não bloqueará os demais itens. **ADS4 — OpenAI/ChatGPT Ads** inclui atribuição dos leads capturados no site; importar contatos de formulários dentro dos anúncios depende de contrato público e acesso ainda não confirmados. São etapas de implementação da mesma release, sem promessa de pacotes intermediários. A seção 13 registra a decisão sobre cada recomendação técnica R1–R16 do parecer de 29/09; essa numeração pertence ao parecer e não substitui o bloco R1 de pendências da seção 7.

Base examinada: pacote entregue **1.15.0**, com os 172 arquivos de fonte conferidos contra seu manifesto, sem diferenças. SHA-256 do instalador: `23a047da1873d9cc4372f672423e4536596cc06dcd24266209443384847cf05b`.

| Pedido ou achado | Situação na 1.15.0 | Tratamento na próxima versão |
|---|---|---|
| Aceitar `f3base_nav_id=92` como menu clássico | Não atendido: qualquer ID positivo é validado exclusivamente como post `wp_navigation` publicado. | Suportar referência explícita a menu clássico, distinguindo seu tipo. |
| Usar o bloco órfão 4 como solução | Não resolve o vínculo com o menu clássico. Um bloco publicado pode passar na validação de existência sem comprovar uso. | Nenhuma substituição automática; separar referência válida, associação ao tema e evidência de uso. |
| Deixar o tema administrar a navegação | Já existe a convenção `f3base_nav_id=0`. | Preservar a convenção. Ela não equivale a registrar o menu 92 nem comprova que um menu apareceu na página. |
| Dividir Configurações em sub-abas | Há seis sub-abas no código, mas o parâmetro dos links/formulários diverge do parâmetro lido. | Corrigir o fluxo completo de abrir, editar, salvar e retornar. |
| Ajuda com funcionamento, vantagens, limitações e exemplo | Estrutura existente, com alguns textos específicos; parte relevante usa conteúdo genérico ou repetido. | Revisar cada campo e alternativa com base no comportamento real. |
| Controles de escolha fechada | Já existem selects, checkboxes e listas de blocos. | Preservar e completar onde necessário; navegação terá seletor por nome e tipo. |
| Proteção contra perda de edição e gravações concorrentes | Há aviso de edição pendente, revisão e recuperação de rascunhos. | Testar os fluxos corrigidos e preservar essas proteções. |
| Documentação junto ao plugin | Já existe documentação em `docs/` e leitura autenticada por `f3base/documentacao-ler`. | Atualizar contrato, exemplos e ajudas, incluindo a mesma informação para operadores e agentes. |
| Análise de agentes de IA e buscadores | Existe em Técnico → Acessos do servidor, com totais por caminho e categoria. O armazenamento diário já distingue famílias de agentes. | Criar área própria, detalhar famílias e evolução temporal; ampliar a coleta de horários para frequência. |

O novo relatório identifica o caso do ID 92 como **fator3** e informa que o post com esse ID é uma revisão. Isso não determina se existe um termo `nav_menu` 92: posts e termos têm identificadores independentes. A existência, os itens e a associação do menu clássico ainda precisam ser conferidos no aceite do site. O post 4 permanece tratado como o bloco órfão relatado pelo usuário, não como objeto inspecionado remotamente.

## 2. Evidências e alcance da análise

Os caminhos abaixo são relativos à raiz do plugin instalado.

| Evidência | Localização | Consequência |
|---|---|---|
| Validador aceita zero ou `wp_navigation` publicado | `includes/class-f3base-servicos.php`, método `recusar()` | Um termo de menu clássico não satisfaz a regra atual. |
| Diagnóstico também consulta apenas posts | `includes/class-f3base-config-consultas.php`, método `navegacao()` | Não identifica menus clássicos nem suas localizações. Para bloco válido em tema clássico, retorna uso não aplicável. |
| Perfil usa a mesma interpretação de navegação | `includes/class-f3base-config-perfil.php` e condição P66 de `docs/perfis/piso-padrao-3.1.json` | Corrigir somente a gravação deixaria o diagnóstico e o perfil inconsistentes. |
| Links, campo oculto e retorno usam `secao`; leitores de GET e POST usam `subaba` | `admin/class-f3base-admin-tela.php` | As abas geradas caem em Contato; o envio de outra seção pode ser recusado como pertencente à aba errada. |
| Navegação é operável no catálogo, mas não tem seção de configuração atribuída | `includes/class-f3base-servicos.php`, catálogo-base e `F3Base_Interface::grupo()` | O renderizador de Configurações a omite por não reconhecer seu grupo. |
| Ajuda tem textos padrão e guias por grupo | `includes/class-f3base-interface.php`, método `ajuda()` | Ter seis títulos de ajuda não garante seis explicações úteis para cada opção. |
| Campos de SEO repetem “Dados declarados…” e “Valor confirmado pelo responsável…” | `includes/trait-f3base-options-catalogo.php`, `f3base_seo_entidade` | O operador não aprende o significado e formato específicos de cada campo. |
| Campos criados por `F3Base_Evolucao::campo()` reutilizam a descrição como exemplo | `includes/class-f3base-evolucao.php` | Diversos exemplos apenas repetem a regra, sem ilustrar uma escolha. |
| Orientações de contas e IDs reutilizam referência a “identificador/token” | `includes/class-f3base-interface.php` | Confunde identificador público de integração com credencial secreta. |
| Acessos aparece como análise dentro de Técnico | `includes/class-f3base-medicao-interface.php`, `AREAS`, `VISOES` e `render()` | A localização atual dificulta encontrar a análise de agentes. |
| Histórico agrega por dia, agente, classe de caminho, caminho, status e método | `includes/class-f3base-modulo-acessos-servidor.php`, `garantir_estrutura()` | Permite detalhar famílias e séries diárias existentes; não preserva horários individuais nem intervalo exato entre requisições. |
| Painel consolida famílias em categorias | `includes/class-f3base-acessos-relatorio.php` e `admin/class-f3base-admin-acessos.php` | A nova interface pode expor dimensões que já existem no histórico. |
| Repetição observa somente navegador provável/desconhecido, com janela limitada | `includes/class-f3base-acessos-repeticao.php`, `observar()` | É evidência de automação suspeita; não representa a cadência de todos os agentes conhecidos. |

Foi executada uma reprodução isolada em PHP, usando a classe real de seleção de abas e as chaves emitidas pelo código: as seis entradas `secao=...` foram resolvidas como Contato tanto na leitura quanto na validação do POST. Não foi uma navegação de navegador no wp-admin.

Também foi executada a validação real com funções WordPress simuladas: zero foi aceito; 92 sem post de navegação foi recusado; um post 4 publicado de tipo `wp_navigation` foi aceito, mas sem uso confirmado em tema clássico. Esse ensaio confirma a lógica do pacote, não o cadastro do site relatado.

## 3. N1 — referência de navegação para menu clássico e bloco

### Contrato e preservação dos dados

Adotar **uma option canônica**, `f3base_navegacao`, com objeto `{schema: 1, tipo: tema|menu_classico|bloco, id: inteiro}`. O tipo e o ID são gravados no mesmo valor, evitando duas linhas parcialmente atualizadas. Não criar `f3base_nav_tipo`. A configuração será apresentada como **Referência de navegação**.

| Escolha na tela | Valor canônico | Validação |
|---|---|---|
| Administrada pelo tema | `{schema: 1, tipo: tema, id: 0}` | Configuração válida; dispensa referência específica do plugin. |
| Menu clássico | `{schema: 1, tipo: menu_classico, id: ID}` | Termo existente `nav_menu` com ID positivo exato. |
| Bloco de navegação | `{schema: 1, tipo: bloco, id: ID}` | Post `wp_navigation` publicado, com ID positivo exato. |

Menus clássicos são termos; não se aplica a exigência de status `publish` de post. Recuperar o objeto e as localizações pela API WordPress [W1–W2], sem converter uma falha de busca por ID em busca por nome/slug. O tipo não será deduzido pelo tema ou pela mera existência de um número: termos e posts podem ter o mesmo ID. Selecionar o menu clássico 92 sempre significa aquele termo.

**Atualização da 1.15.0:** migrar uma vez `f3base_nav_id=0` para `tipo: tema`; valores positivos para `tipo: bloco`, preservando o significado anterior e o número mesmo se o objeto for inválido. Não trocar automaticamente o 92 por zero nem por outro objeto. Valores inválidos ficam diagnosticados em `avisos[]` e disponíveis para correção. Instalação nova começa com `tipo: tema, id: 0`. Migração usa checkpoint e revisão, sem sobrescrever uma configuração nova já salva.

**Projeção para consumidores existentes:** `f3base_nav_id` torna-se somente leitura pelo Core e por `get_option()`: devolve o ID para `tipo: bloco` e zero para os demais tipos. É projeção calculada do objeto canônico, sem segunda linha espelhada que precise ser gravada após cada mudança. A linha antiga, se conservada para recuperação, não é fonte de verdade; o contrato e os exemplos SQL apontam para `f3base_navegacao`. Essa mudança de escrita exige contrato 4.0.0, conforme D1. Não editar temas; documentar o adaptador de leitura e o limite de consumidores que consultam SQL diretamente.

### Escrita coerente e integração com o canal

UI, MCP e gravador genérico chamam o mesmo serviço da fachada de Options, com schema, validação semântica, revisão, simulação, auditoria sem dados sensíveis e releitura. A operação persiste o objeto completo em uma escrita condicional; uma linha única evita o par parcial, mas a verificação de revisão continua obrigatória contra perda de edição concorrente.

- Recusar escrita direta em `f3base_nav_id` com código e indicação de `f3base_navegacao`; anunciar no contrato o atributo derivado e a nova entrada editável.
- Não aceitar um `tipo: tema` com ID diferente de zero, nem um tipo de referência com ID zero em novas escritas.
- Confirmar a releitura do objeto e da projeção antes de declarar sucesso; simulação não altera option, revisão ou evidência.
- Testar falha antes/depois da escrita, duas edições simultâneas e cache persistente de options. Invalidar caches/evidências depois da gravação confirmada.
- Respeitar a política operável. `modo: todas` inclui a nova opção editável; lista explícita não ganha permissão nova. O atributo derivado permanece somente leitura mesmo em `modo: todas`.

### Diagnóstico honesto

Retornar separadamente:

1. **Referência:** tipo, ID, nome, existência e validade.
2. **Associação:** localizações registradas no tema ativo e vínculos observados; para blocos, referências encontradas nos templates e partes.
3. **Uso:** confirmado dentro do alcance observado, não confirmado, evidência desatualizada ou administrado pelo tema.

Atribuir um menu a uma localização não prova que o tema a renderiza no cabeçalho. Não presumir que a localização se chama `primary` ou que qualquer menu renderizado pertence ao topo. Uma referência em template também deve informar qual template/parte foi examinado, sem generalizar a todas as páginas.

O diagnóstico inicial deve usar consultas locais e mostrar seus limites. Se não houver evidência confiável de uso no cabeçalho, manter “não confirmado”, com orientação acionável; a validade do menu continua independente. Um bloco órfão publicado pode ser uma referência válida e continuar sem comprovação de uso.

Atualizar P66 para aceitar os três modos e distinguir configuração válida de uso comprovado. `tipo: tema, id: 0` é conforme também em tema clássico ou navegação inline, sem aviso de divergência apenas por delegar ao tema. Zero não será apresentado como prova visual. Consultas de configuração e saúde não farão novas requisições HTTP nem criarão objetos para produzir conformidade.

**Complemento do item 42:** problemas de referência e de associação também entram em `avisos[]`, com código e caminho únicos. Separar validade do tipo de dado de validade semântica da referência; um inteiro válido com objeto inexistente não poderá aparecer como configuração inteiramente conforme.

Para navegação de blocos com `ref` injetado em `render_block_data`, considerar o bloco efetivo depois dos filtros do tema. A observação deve identificar tema, template/parte e revisão; será produzida por verificação explícita e limitada, com contexto de teste, e apenas consultada nas leituras seguintes. Uma declaração de suporte do tema também pode registrar associação dinâmica, mas será rotulada **declarada**, sem virar prova de HTML servido. P66 deve distinguir referência válida, associação declarada e uso observado, sem reprovar uma associação apenas por ausência de `ref` literal no arquivo.

Quando o cabeçalho examinado usar navegação inline sem referência, informar que esse contexto não usa `wp_navigation` e recomendar zero se a administração for integralmente do tema. Não trocar o ID automaticamente: outros templates podem usar a referência. Preservar o controle relatado de fator3capital, inline com zero.

### Interface

Adicionar o grupo **Navegação do site** em **Conteúdo e IA**, com:

- Escolha entre administração pelo tema, menu clássico e bloco de navegação.
- Seletor pesquisável por nome, com tipo e ID visíveis; lista carregada sob demanda e limitada, com paginação quando necessário.
- Resumo da associação encontrada e mensagem específica para inexistente, excluído, bloco não publicado ou uso não confirmado.
- Valor salvo indisponível visível, sem selecionar automaticamente o primeiro item.
- Link para o editor apropriado do WordPress, quando disponível e permitido.
- Explicação curta: “Registra a referência usada pelo site. A posição e a renderização do menu dependem do tema.” Se o tema consumir essa opção, mudar a referência pode afetar o menu exibido; salvar não comprova o resultado público.

O plugin não converterá menus em blocos, não criará menus fictícios, não atribuirá localizações e não editará templates. Alterações de tema e implantador permanecem fora deste pacote.

## 4. U1 — abrir e salvar a seção correta

Adotar `secao` como parâmetro canônico, pois já é emitido pelos links, formulários, retornos e atalhos de Medição. Unificar a resolução de GET, POST e URL de retorno.

- GET sem seção pode abrir Contato. POST com seção ausente, inválida ou contraditória deve ser recusado de forma clara; não assumir Contato para uma escrita.
- Preservar a seção após sucesso, erro de validação e conflito de revisão. Focar o aviso ou campo correspondente.
- Gravar somente os campos autorizados da seção enviada. Valores de outras seções, false, zero e listas vazias permanecem intactos.
- Corrigir os atalhos de Medição e os links diretos para campos.
- Manter a proteção de alterações pendentes e os rascunhos existentes, sem incluir segredos em rascunhos ou mensagens.
- Cobrir navegação por teclado, recarga, voltar do navegador e envio sem JavaScript.

A existência dos links no HTML não será considerada aceite: é preciso seguir cada link e salvar pela interface real.

## 5. U2 — configuração mais clara e menos cansativa

### Organização

Manter as seis sub-abas existentes. Dentro de cada uma, agrupar configurações relacionadas e mostrar primeiro o resumo e os controles mais frequentes. Ajuda extensa e dados técnicos ficam em áreas expansíveis.

Na Medição, distinguir coleta local, contas de anúncios, atribuição, carregamento e testes. Em Contato, preservar a separação entre avisos internos, WhatsApp e instrumentação. Em SEO, explicar identidade, perfis oficiais, pessoas, serviços e ofertas com exemplos próprios. Navegação entra em Conteúdo e IA.

Inventariar todas as opções operáveis, inclusive as que hoje não possuem seção. Cada uma deve ter destino explícito em Configurações, Operação ou tela especializada, com link quando necessário. Gerar a matriz de ajuda dos mesmos metadados do catálogo usados por D1; o teste percorre folhas editáveis, exige explicação própria e falha para texto vazio ou igual ao fallback genérico do tipo. Mensagens estruturais compartilhadas continuam permitidas, mas não substituem a explicação da opção. Uma opção sem seção não pode desaparecer silenciosamente. Essa revisão não implica colocar estados técnicos internos em formulários editáveis.

Controles dependentes devem indicar por que estão inativos ou sem efeito. Ocultar/recolher não pode apagar seu valor nem fazer o salvamento substituí-lo pelo padrão. Preservar combinações legítimas e valores desconhecidos armazenados até uma alteração explícita.

### Conteúdo de cada ajuda

Criar uma matriz de todas as opções e folhas de subcampos visíveis. Para cada uma, registrar:

| Informação | Conteúdo exigido |
|---|---|
| Rótulo | Nome compreensível, com unidade quando houver número; chave técnica na referência de suporte. |
| Resumo | O que muda no site ou na operação ao alterar o campo. |
| Quando escolher | Situações práticas para cada alternativa, inclusive ligado/desligado. |
| Benefícios e limitações | Consequências específicas; não repetir a vantagem genérica de centralizar no plugin. |
| Padrão e valor atual | Diferenciar padrão declarado, herança e escolha explícita. Não chamar o padrão do pacote de “configuração deste site”. |
| Ausência e vazio | Explicar separadamente ausência, zero, desmarcado, string vazia e lista vazia, quando aceitos pelo campo. |
| Exemplo | Exemplo válido e ilustrativo, sem usar dados ou credenciais reais. Para segredo, explicar onde obter e como preservar/substituir. |
| Dependências e confirmação | O que precisa estar configurado e onde verificar o efeito, distinguindo persistência e entrega. |

Prioridades concretas: navegação, destinatários e herança por formulário, atribuição e retenção, GTM versus tags diretas, identificadores versus token CAPI, políticas de carregamento, exclusão de testes, campos de SEO, proteção pública e entrega do índice.

Exemplo de melhoria: “Same as” passa a **Perfis oficiais da organização**, com explicação de que os links identificam a mesma organização, exemplos com domínios ilustrativos e aviso de que responder HTTP 200 não comprova identidade. “Exemplo: valor confirmado pelo responsável” deixa de contar como exemplo específico.

Revisar frases categóricas sobre integrações contra o código vigente: conta configurada não garante recebimento; ausência de uma tag direta não significa ausência de tag instalada por GTM/tema; cookies e consentimento limitam vínculos. Textos de política devem descrever a opção existente, sem mudar decisões do dono nesta versão.

### Controles e retorno

- Manter selects para enums e checkboxes para booleanos e escolhas múltiplas.
- Usar seleção por nome para navegação; não exigir que o operador descubra um ID no banco.
- Mostrar erro junto ao campo, com ação para corrigir e resumo no topo.
- Manter o botão “Salvar [seção]” e indicar alterações pendentes.
- Explicar o que ficou salvo, o que requer execução em Operação e o que ainda não foi verificado.
- Garantir labels, foco visível, mensagens acessíveis e uso em telas estreitas. O fluxo básico deve funcionar sem JavaScript.

Não é necessário reescrever todos os editores avançados de JSON para concluir este escopo. Onde permanecer JSON, fornecer contrato, exemplo válido e validação compreensível.

## 6. M1 — Agentes e buscadores em Medição

### Objetivo e navegação

Criar **Medição → Agentes e buscadores**, no mesmo nível de Visão geral, Aquisição, Conversão, Comportamento e Técnico. As seis sub-abas de Configurações continuam independentes dessa organização.

A área terá três análises, mantendo os filtros ao alternar entre elas:

1. **Resumo:** requisições por categoria e família, conteúdos distintos requisitados, evolução diária e comparação de períodos com cobertura compatível.
2. **Agentes e conteúdos:** ranking por família de agente e caminho, nome do operador declarado quando conhecido, classe, método, status HTTP, primeira e última requisição disponíveis. Abrir um agente mostra seus conteúdos; abrir um conteúdo mostra os agentes que o requisitaram.
3. **Frequência:** dias com acesso atendido, mediana do intervalo entre dias ativos, requisições por dia coberto e última requisição por família/caminho. Histograma horário agregado por família/classe e média dentro do dia são detalhes complementares com os limites abaixo.

Usar filtros por período, família de agente, categoria, caminho/tipo de conteúdo, método e status nas análises diárias. O histograma horário usa somente as dimensões que armazena; com filtro incompatível por caminho, método ou status exato, mostrar indisponibilidade nessa granularidade, sem ignorar o filtro silenciosamente. Incluir páginas e artigos, `robots.txt`, sitemaps, `llms.txt`, `llms-full.txt`, representações Markdown e feeds quando aparecerem nos logs elegíveis. Separar requisições de conteúdo de chamadas técnicas e recursos estáticos, sem ampliar silenciosamente as rotas hoje excluídas.

O recorte inicial será **Buscadores e IA**, com alternativa explícita para todos os agentes classificados. Próprio, hospedagem, automação genérica e suspeita permanecem consultáveis com categorias separadas. A tela deve mostrar o recorte aplicado e a cobertura; total filtrado não será apresentado como total de todo o tráfego.

Preservar **Técnico → Acessos do servidor** para o diagnóstico e a tabela ampla já existentes, com atalho para a nova área. Manter os links atuais funcionais e evitar duas implementações divergentes de cálculo. A coleta manual, sua agenda e os erros continuam acessíveis pelo contexto da nova área.

### Nomes reconhecíveis e identificação dos principais agentes

Mostrar **OpenAI / ChatGPT**, **Anthropic / Claude** e **Google / Gemini** explicitamente na navegação, nos filtros e nas explicações. O nome do fornecedor/produto será acompanhado da família técnica observada e de sua finalidade declarada. Não agrupar os principais agentes apenas em “Treino IA”, “Resposta IA” ou “Outros”.

| Nome apresentado | Famílias e assinaturas mínimas | Tratamento |
|---|---|---|
| OpenAI / ChatGPT | `OAI-SearchBot`, `GPTBot`, `ChatGPT-User`, `OAI-AdsBot` | Separar busca, treino, acesso solicitado e verificação de anúncios. `OAI-AdsBot` tem categoria própria e não gera origem de aquisição [W3]. |
| Anthropic / Claude | `Claude-SearchBot`, `ClaudeBot`, `Claude-User` | Separar busca, coleta para possível treinamento e acesso solicitado pelo usuário [W4]. |
| Google / Gemini e outros serviços Google | `Google-GeminiNotebook`, `Google-Agent`, `Google-CloudVertexBot`, `Googlebot`, `GoogleOther` | Gemini Notebook é identificado por família específica; Google-Agent indica agentes hospedados na infraestrutura Google; CloudVertexBot indica coleta para Vertex AI solicitada por donos de sites. Googlebot/GoogleOther continuam separados [W5, W7]. |

**Limite específico do Gemini:** `Google-GeminiNotebook` identifica o fetcher do Gemini Notebook; registrar `Google-NotebookLM` como alias legado com período documentado, conservando a assinatura histórica observada. `Google-Agent` não comprova o modelo Gemini nem o produto que hospedou o agente. `Google-CloudVertexBot` é coleta Vertex AI e não resposta interativa do Gemini. `Google-Extended` continua sendo token de controle em robots.txt, sem User-Agent HTTP próprio; não produz contagem. Assim, mostrar cobertura identificável do Gemini Notebook e limites dos outros produtos, sem rotular todo acesso Google como Gemini [W5, W7].

A assinatura `Claude-User` pode ser usada por acessos solicitados tanto por visitantes quanto por agentes da operação. Mostrar esse limite junto à família; sem marcador por linha, o log não permite separar a equipe de terceiros. O mesmo princípio vale para as demais famílias acionadas por usuário.

Os três nomes devem permanecer encontráveis mesmo quando não houver registros no período. Diferenciar **nenhuma requisição identificada na cobertura disponível**, **sem dados de coleta** e **produto não distinguível pela fonte**.

Preservar as demais famílias reconhecidas no pacote, com nomes legíveis, e permitir expansão por fornecedor → família → conteúdo. Atualizar o catálogo para separar identificador estável do fornecedor, rótulo do produto/ecossistema, família técnica, classe, fonte oficial, data de revisão e regra de correspondência. Hoje a coluna de operador mistura nome e URL; não usar esse texto livre como chave de agrupamento. Manter aliases históricos sem promover uma marca antiga ou não confirmada a identificação verificada.

Conferir as assinaturas na documentação dos fornecedores no fechamento do pacote. Regras específicas devem preceder as genéricas; versões do navegador ou do bot não podem ser fixadas em um valor que descarte requisições novas. Identificação pelo User-Agent continua declarativa e não revela qual modelo de IA executou a ação. Essa revisão não altera automaticamente o `robots.txt` nem permissões de acesso aos agentes.

### Respostas atendidas, bloqueadas e cobertura

Separar volume, rankings e frequência pelos grupos **atendido/revalidado** (2xx e 304), **bloqueio HTTP** (403 e 429) e **outros** (demais 3xx, 4xx e 5xx). Conservar o status exato no diário. O ranking de conteúdo atendido usa o primeiro grupo por padrão; bloqueios têm quadro próprio. Exibir por família a fração `(403 + 429) / todas as requisições observadas da família no recorte`, denominador, período e cobertura. Sem denominador, a fração é indisponível.

Status 403/429 comprova resposta de recusa/limite no log, mas não identifica sozinho a camada responsável. Exibir `camada: desconhecida` até existir evidência da hospedagem, proxy ou aplicação. Respostas antes do WordPress entram somente se constarem dos arquivos que o coletor consegue ler. Ausência dessas linhas não prova ausência de bloqueio. Essa visibilidade apoia a pendência 24 relatada pela frota; não a declara resolvida nem solicita mudança à DreamHost.

### O que já pode ser analisado e o que precisa ser capturado

| Dado | Implementação prevista |
|---|---|
| Família, caminho, classe, método, status e contagem diária | Reutilizar `f3base_acessos` e sua chave diária existente; manter histórico. |
| Primeiro/último instante por caminho/dia | Acrescentar colunas UTC anuláveis `primeiro_em`, `ultimo_em` e contador de requisições com horário válido. Registros antigos permanecem sem horário. |
| Dias ativos e mediana entre dias ativos | Consulta sobre dias distintos do agregado diário, por família/caminho e filtros, com cobertura compatível. |
| Histograma por hora | Nova tabela sem caminho, chave `(hora_utc, agente, classe_caminho, grupo_status)` e contagem. Não reter status exato/método nessa tabela nem prometer seus filtros. |
| Procedência e completude | Registrar geração do arquivo, parser/classificador, fuso e contribuição de cada lote; soma diária e horária usam o mesmo checkpoint. |

Instantes novos ficam em UTC. Preservar a semântica de dia/fuso da coleta existente; a data diária não pode ser redistribuída para outro fuso só com seus extremos. Mostrar o fuso registrado e separar períodos incompatíveis. Converter as horas para apresentação quando houver dados suficientes, informando a granularidade.

A tabela horária sem caminho reduz cardinalidade, mas a estimativa de cerca de 86 mil linhas do parecer omite classes de caminho. Exemplo de teto combinatório: `famílias × horas × classes × 3 grupos`; o tamanho efetivo depende das combinações observadas. Dimensionar índices, retenção e orçamento por lote na bancada, sem garantir máximo de linhas por uma conta incompleta. Contribuições técnicas auxiliares não devem reintroduzir detalhe por caminho/hora sem necessidade.

### Definição das métricas e seus limites

- **Volume:** requisições registradas, sem equivalência com pessoas, sessões ou agentes únicos.
- **Família:** assinatura declarada no User-Agent, imitável e compartilhada por processos. A identidade por DNS/IP fica fora da release.
- **Dias ativos:** datas distintas, no fuso registrado, com ao menos uma resposta atendida/revalidada por família e caminho. Mostrar também dias cobertos e dias parciais.
- **Mediana entre dias ativos:** ordenar datas distintas e calcular a mediana das diferenças em dias de calendário entre datas consecutivas. Exige pelo menos duas datas; número par de intervalos usa média dos dois centrais. É intervalo entre dias observados, não tempo exato entre requisições nem periodicidade garantida de retorno. Várias requisições no mesmo dia contam como um dia ativo.
- **Cobertura da mediana:** pares atravessando dias sem cobertura completa/compatível são excluídos, com quantidade de pares usados e descartados. Sem par elegível, métrica indisponível. Não unir artificialmente bordas de lacunas nem tratar dia sem log como ausência de acesso. Dados diários antigos podem contribuir quando sua cobertura é comprovada, mesmo sem horários individuais.
- **Requisições por dia coberto:** total dos dias completos dividido por sua quantidade; hoje e demais dias parciais ficam separados.
- **Primeiro/último instante:** extremos observados com horário válido; antigos sem timestamp permanecem indisponíveis. Último observado é limitado pela atualização da coleta.
- **Média dentro do dia:** `(ultimo_em − primeiro_em) / (n_com_horario − 1)` para mesmo dia/família/caminho e filtros. Exige ao menos duas requisições, todas com horário válido e cobertura apropriada. A fórmula é a média aritmética exata dos intervalos da sequência observada; rajadas e processos paralelos limitam sua interpretação. Não usar como métrica principal de retorno entre dias, nem calcular média de médias entre grupos.

Respostas HEAD, 204 e 304 não comprovam entrega de corpo completo; 2xx também não demonstra leitura, indexação, treinamento ou citação. Correlação entre volume e alteração de conteúdo/campanha não estabelece causalidade. Não oferecer percentis de intervalos entre requisições sem dados suficientes.

### Coleta, desempenho, retenção e histórico

Ampliar a leitura incremental dos logs já autorizados e a mesma agenda/trava de coleta. A atualização preserva o estado ligado/desligado de `f3base_acessos`, o padrão de arquivos, exclusões e retenções existentes. Dados adicionais são produzidos quando a coleta estiver habilitada; não ativar uma coleta que o dono desligou.

- Processar em lotes limitados, com checkpoint, recuperação de falhas e publicação consistente da contribuição do lote. Concorrência ou repetição do trabalho não pode aumentar os totais.
- Tratar rotação, arquivos substituídos, linhas fora de ordem, mudança de fuso, formato inválido e sobreposição entre fotografia de hoje e histórico fechado. Não somar duas vezes a mesma contribuição.
- Preservar os totais e a classificação do histórico diário existente. Horários detalhados passam a existir a partir da nova coleta; reprocessar histórico somente mediante ação explícita e enquanto os arquivos estiverem disponíveis, substituindo suas contribuições.
- Propor detalhe horário com retenção padrão de **30 dias**, ajustável entre 1 e 90 dias; aplicar também qualquer limite menor já imposto à retenção de acessos. O agregado diário continua seguindo sua retenção atual. Expor a data de início e o fim da cobertura de cada granularidade.
- Não reter IP, User-Agent bruto, referer, cookies, query strings ou corpo de requisição para esta análise. Preservar a normalização/exclusão de caminhos sensíveis já existente. Não criar vínculo desses logs com contatos ou sessões individuais.
- Não acrescentar scripts públicos nem processamento de frequência em cada visita. Parser e agregação executam na coleta; a visualização consulta agregados paginados. A abertura do painel não dispara varredura integral de arquivos.
- Informar quando houver limite de leitura/consulta, coleta incompleta ou indisponibilidade do log. Nunca substituir esses estados por “nenhum agente acessou”.

A identificação de testes em leads/eventos por cookie/cabeçalho permanece independente. Os logs comuns não contêm esses marcadores. A nova área não excluirá agentes de IA externos como se fossem testes da equipe, nem alegará excluir visitas MCP por coincidência de IP/horário. Próprio/hospedagem são categorias declaradas, não prova de que toda atividade de manutenção foi identificada.

### Contrato, exportação e documentação

Disponibilizar a mesma consulta autenticada para UI, CSV e MCP, com filtros validados, paginação estável, granularidade, fuso, cobertura, versão da regra e motivos para métricas indisponíveis. Os nomes finais das abilities serão publicados no contrato instalado; não criar uma API paralela com cálculos diferentes.

Exportar todas as páginas do recorte ou declarar claramente o limite aplicado. Incluir unidades e distinção entre dia parcial, dia sem cobertura e zero confirmado. Os exemplos de consulta para agentes devem cobrir ranking por família/conteúdo, série diária/horária e frequência; os exemplos SQL precisam indicar chaves, unidade dos timestamps e limites de agregação.

O detector atual de automação suspeita continua sendo apresentado como diagnóstico separado. Ele não será reutilizado como medida de retorno de todos os buscadores.

## 7. R1 — pendências verificadas após a 1.15.0

### Origem, alcance e rastreabilidade

Fonte de requisitos: arquivo “Pendências do site-core após a 1.15.0.md”, de 28/09/2026, fornecido nesta conversa. A fonte local do pacote foi conferida para os 19 itens de código/medição. Quantidades e respostas dos sites são evidências relatadas pela frota, não novas medições desta revisão. Não foram acessados sites de produção nem executada nova bancada de desempenho. O risco de TypeError do item 61 permanece uma hipótese a reproduzir; a ausência da validação booleana está visível na fonte.

| Item | Decisão na 1.16.0 | Frente / resultado exigido |
|---|---|---|
| 70 | Incorporar, alta prioridade | C1: destino válido antes de marcar ou registrar clique; diagnóstico dos CTAs sem destino. |
| 67 | Incorporar, alta prioridade | C1: marcação por `wa.me` e número configurado, opcional e desligada por padrão. |
| 59 | Incorporar, alta prioridade | C2: identificadores Meta separados de origem e da igualdade semântica da análise. |
| 63 | Incorporar, alta prioridade | P1: autoria pública sem login nos campos e links cobertos, sem alterar contas. |
| 65 | Incorporar, alta prioridade | P1: filtro correto do Yoast e teste de saída real. |
| 69 | Incorporar junto de 67/70 | C1: superfície de navegação identificada pelo contexto do bloco. |
| 68 | Incorporar | C3: saúde de captura considera clique e formulário aceitos. |
| 42 | Ampliar N1 | Avisos coerentes, menu clássico, referência dinâmica e navegação inline. |
| 54 | Incorporar | E1: motivo específico da invalidação de evidência, sem reaproveitamento indevido. |
| 60 | Incorporar, incluindo reparação | E2: procedência de migração comprovada; não regravar listas vazias padrão. |
| 62 | Incorporar | P2: reserva privada de robots, migração retomável e restauração comprovada. |
| 64 | Incorporar só o contrato | E3: campos derivados explícitos; preservar a cadência já escolhida. |
| 41 | Incorporar | S1: ofertas mensal/anual no mesmo cartão, renovação antecipada e purga seletiva. |
| 45 | Incorporar | V1: consentimento respeita o painel e as cores do tema, com fallback acessível. |
| 36 | Incorporar com limite operacional | L1: conversão de contingência, geração antecipada e estado temporário correto. |
| 37 | Incorporar com diagnóstico conservador | E1: persistir idade observada e separar risco de informação; não ocultar incerteza. |
| 38 | Incorporar como medição | M2: repetir com configuração padrão; não prometer de antemão POST fora do trace. |
| 61 | Incorporar os seis subitens | E4: contrato, simulação, tipos, compactação e documentação consistentes. |
| 66 | Incorporar com revisão de dependências | D2: saúde completa, limpeza apenas do código sem uso e `full` padrão verdadeiro. |
| 50 | Sem nova correção por ora | Aceite da próxima soma dos logs disponíveis; manter teste de regressão de slug longo. |
| 52 | Sem nova correção por ora | Aceite de sete dias sem a falha relatada; preservar teste de concorrência/idempotência. |
| 17 | Incorporar parcialmente | CRM1/Pipedrive entra; webhook genérico de saída e confirmação por URL permanecem adiados. Ver seção 8 para origens de anúncio. |

### C1 — marcação e classificação de CTAs: 67, 69 e 70

Unificar a decisão de marcação entre conteúdo, blocos e menu clássico em `class-f3base-servicos.php`, preservando o destino e o HTML pertencentes ao tema. O contrato de destino precisa ser consistente também em `f3base-leads.js` e no endpoint para que um marcador antigo em `href="#"` não continue gerando lead.

- Aceitar URLs HTTP(S) de WhatsApp com host exato `wa.me` ou `api.whatsapp.com`, `tel:` e `mailto:` válidos, além de caminho interno resolvido para a mesma origem. Rejeitar vazio, fragmento isolado, `javascript:`, esquemas desconhecidos e hosts que apenas contenham o nome permitido. Não visitar o destino durante cada clique para validá-lo.
- Um caminho interno continua dependendo de classe/atributo explícito de CTA. A mudança não transforma todo link interno em lead. Botões sem `href` precisam de `data-f3base-destino` válido. Um caminho como `/contato/#formulario` difere de `#formulario` isolado.
- O valor `whatsapp` e o método correspondente ficam restritos a destino WhatsApp; `tel:`, `mailto:` e caminho interno usam a classificação já definida para esses destinos. Clique mede intenção de contato, sem afirmar que houve conversa ou envio de formulário.
- Adicionar `f3base_contato.carimbar_whatsapp_por_destino`, booleano, padrão **false**. Quando true, marcar também `<a>` sem classe com destino `https://wa.me/<numero>` ou `https://api.whatsapp.com/send?phone=<numero>` e telefone normalizado igual ao `whatsapp_e164`. `wa.me/message/<codigo>` não contém telefone e não participa da marcação automática por número; continua elegível como CTA WhatsApp explicitamente marcado quando o destino for válido. Não inferir país ou aceitar outro telefone. Não reescrever a URL nem duplicar marcador/evento já existente.
- Usar o nome e o contexto do bloco para `core/navigation-link` e `core/navigation-submenu`; a superfície será `menu`, mesmo antes da renderização do `<nav>` ancestral. Evitar que um carimbo automático anterior fixe `conteudo`. Preservar marcações explícitas válidas do projeto e documentar a precedência.
- Em `como-usar`, apresentar CTAs com classe reconhecida e destino rejeitado: página/template, motivo e cobertura da verificação. Produzir esse inventário em tarefa explícita ou programada, paginada e limitada; a simples leitura da ajuda não deve renderizar o site inteiro. Remover parâmetros sensíveis dos exemplos exibidos.

Aceite: fixtures de menu clássico, blocos aninhados, contêiner marcado, botão com destino explícito, âncora isolada, JavaScript, host disfarçado, telefone diferente e caminho interno. Cada clique válido produz no máximo um evento. A contagem dos 34 links de Twinia e o rodapé de fator3capital serão conferidos pela frota após a entrega. A retirada das compensações dos temas é responsabilidade dos temas. Documentar no CHANGELOG e na orientação da frota a data/versão em que `tel:` e `mailto:` passam à classificação correta e os efeitos em `form_id`/`method` no GA4; não reescrever séries históricas.

### C2 — origem e identificadores de publicidade: 59

Em `f3base-contexto.js`, reconhecer um toque somente por evidência de origem: campos de campanha/click IDs permitidos e referência externa elegível. `fbc` e `fbp` são identificadores auxiliares; sua presença ou alteração não cria primeiro/último toque, não atualiza seus horários e não substitui UTMs. Anexá-los separadamente ao contexto enviado ao lead, respeitando consentimento e modo de teste existentes.

Em `class-f3base-analise.php`, definir uma projeção canônica para comparar o mesmo evento/vital. Remover apenas `fbc`/`fbp` dessa comparação, inclusive quando aparecem dentro dos contextos de toque/sessão, e ordenar a estrutura antes do hash. Uma mudança real de origem ou dos demais campos imutáveis continua sendo conflito; não ignorar toda a atribuição para fazer desaparecer o 409. Normalizar também a linha já existente ao compará-la, de modo que o primeiro reenvio após a atualização funcione sem reescrever toda a tabela.

Aceite: UTM → página interna com `_fbp`; entrada direta com cookie → primeira campanha posterior; surgimento/alteração de cookie entre versões do mesmo vital; consentimento retirado; sessão de testes; reenvio concorrente. UTMs e horários válidos permanecem, o lead conserva identificadores autorizados e conflitos reais continuam visíveis. Não reconstruir UTMs históricas que já foram apagadas sem evidência independente.

### C3 — atividade e saúde de leads: 68

Registrar a atividade comum após a persistência confirmada de um lead aceito, nos dois caminhos. A saúde mostrará o último aceito global e, quando útil, os últimos de clique e formulário, com método, horário e classe de tráfego; um módulo específico de WhatsApp deve dizer que sua linha é específica desse canal.

Falha no aviso por e-mail não desfaz captura confirmada. Rejeição antispam, falha de banco e reenvio idempotente não criam nova atividade de captura. Testes não devem aparecer como último lead de produção sem identificação. Validar envio de formulário seguido de clique, a ordem inversa e retries. Fonte principal: repositório, endpoint de leads e receptor de formulários; evitar duas implementações divergentes de saúde.

### C4 — nome do site duplicado no assunto dos e-mails

Relato adicional do dono, 28/09/2026: os e-mails gerados ao preencher formulários estão repetindo o nome do site no assunto. A fonte da 1.15.0 confirma duas condições capazes de produzir a repetição; a mensagem recebida e os filtros de correio do site ainda não foram inspecionados, portanto a causa específica daquela entrega não está comprovada.

1. `class-f3base-formularios.php` envia o `assunto` configurado, ou o título do formulário, ao registro. `class-f3base-leads-notificacoes.php` sempre antepõe `[Nome do site]` antes de chamar `wp_mail()`. Se o assunto já inclui a marca, a composição a duplica.
2. `class-f3base-resposta-visitante.php` resolve `{{formulario}}` pelo assunto do aviso interno. Um template que também inclui `{{site}}` repete a marca quando o assunto já a contém. A resposta ao visitante é uma funcionalidade existente, desligada por padrão, e não está entre as demandas adiadas.

Correção planejada:

- Centralizar a composição do assunto do aviso interno. Se o assunto/título já identifica o site pelo nome completo, preservar o texto configurado e omitir o prefixo automático; caso contrário, incluir `[Nome do site]` uma vez. Comparar nomes completos normalizando espaços, caixa e entidades HTML para a detecção, sem remover palavras do texto salvo nem confundir nomes parcialmente coincidentes. Não executar substituição global do nome dentro do assunto.
- Preservar o marcador de teste e a identificação do método já usados, sem adicionar o mesmo marcador duas vezes. Assunto vazio recebe fallback útil. Não regravar configurações de formulário nem reenviar mensagens já processadas durante a atualização.
- Fazer `{{formulario}}` representar o título do formulário, independente do assunto de e-mail. Registrar esse título no contexto do envio para manter o significado em notificações posteriores. Para registros anteriores sem título capturado, usar o identificador do formulário como fallback, sem reconstruir um título histórico pela configuração atual.
- Documentar o formato e apresentar prévia do assunto na edição do formulário, usando a mesma regra do envio. A prévia inclui prefixo efetivo, assunto, marcador de teste e sufixo `— metodo`; é local e não dispara e-mail. Se o texto configurado já contém repetições literais, indicá-las para revisão, sem reescrever conteúdo livre silenciosamente.
- Na validação, observar o assunto antes do envio e após os filtros WordPress/PHPMailer para distinguir a composição do Core de um prefixo acrescentado por integração externa. Não desabilitar filtros de terceiros para mascarar a causa.

Aceite: assunto sem marca; marca no início, no fim e em prefixo entre colchetes; nomes com acentos/entidades; nome parcialmente coincidente; título como fallback; assunto vazio; modo de teste; resposta ao visitante com `{{site}}` e `{{formulario}}`; mensagem pendente criada na 1.15.0. Capturar as mensagens em transporte de teste, sem enviá-las a contatos reais. O Core não acrescenta uma segunda ocorrência do nome já presente, mantém o texto configurado e não altera destinatários, Reply-To ou estado de captura do lead.

### P1 — autoria pública e Yoast: 63 e 65

`f3base_protecao` é um objeto, não um switch único. Para esta correção, ligar a proteção de identidade pública à opção existente `usuarios_rest_restritos`, ampliando seu rótulo/ajuda para explicar REST, oEmbed, feed e links de autoria. Preservar false explícito. A autoria institucional continua obedecendo à política de autoria do conteúdo, independentemente da restrição de usuários REST.

Aplicar a identidade institucional quando a autoria efetiva for `organizacao` ou, com a proteção de identidade ligada, quando `display_name` **ou** `user_nicename` coincidirem com o login. Cobrir `author_name`, `author_url`, `dc:creator` e links de autor gerados pelas APIs WordPress relevantes. Usar nome e URL públicos da organização; na ausência de organização configurada, usar título público e home do site, nunca o login como fallback. Considerar também as rotas/redirects nativos de autor que reproduzem o slug protegido e evitar que a própria proteção o reexponha em `Location`.

Não alterar `user_login`, `user_nicename`, `display_name`, permissões ou senhas dos usuários. Não substituir autores públicos legítimos quando a regra não se aplica. Não prometer eliminar nomes já escritos manualmente no conteúdo, em sistemas externos ou por código de tema que ignora as APIs filtradas.

Corrigir o registro para `wpseo_meta_author`, conforme a API oficial do Yoast [W6]. Não manter um hook errado por compatibilidade presumida. Conferir a saída com o Yoast da bancada correspondente à frota: metadado de autoria e autor do Article coerentes, sem duplicação e sem remoção de pessoas legítimas da organização.

Aceite: oEmbed anônimo de página e artigo, RSS, link/redirect de autor e HTML SEO. Incluir `display_name != login` com `user_nicename == login`, autoria institucional e autoria individual válida. Os casos reportados em conselar/ctooffice serão homologados pela frota; correções na criação de contas pelo implantador ficam fora.

### P2 — reserva privada de robots.txt: 62

Em `class-f3base-robots-arquivo.php`, guardar a reserva no diretório privado do próprio pacote. Não criar dependência do diretório de outro plugin. Atualizar o registro de restauração com caminho privado, integridade e estado de migração; a ajuda autenticada mostrará localização e recuperação.

Na atualização, migrar apenas a reserva reconhecida pelo estado do módulo, nunca apagar arquivos por busca genérica de `.bak`. Confirmar propriedade do caminho, rejeitar travessia/symlink indevido, copiar e verificar bytes/hash, persistir a referência recuperável e só então remover a reserva pública. A operação deve suportar volumes diferentes e interrupção em cada etapa. Se a preparação privada falhar, conservar a cópia recuperável e declarar falha, sem marcar a migração como concluída.

Aceite em bancada: atualização com reserva antiga, pasta indisponível, interrupção/retomada e repetição; desativar/restaurar/reativar preserva o original. GET anônimo no caminho antigo deve terminar em 404 após limpeza do cache aplicável, sem disponibilizar a reserva no novo destino. A prova dos quatro sites pertence à frota. Nenhum passo depende de solicitação à DreamHost.

### E1 — evidências de redirects e cache: 54 e 37

**Redirects:** armazenar os componentes do contexto junto à evidência e informar quais mudaram: revisão das regras, geração do cache, contrato, host/permalinks ou outros componentes efetivamente usados. Ausência, expiração, erro de leitura e contexto alterado terão códigos distintos; alterações simultâneas retornarão a lista de motivos. Leituras continuam sem executar sondas. Preservar a prova anterior como histórica, sem tratá-la como válida.

Conservar cursor por lote e CAS, sem reiniciar uma rodada por uma simples leitura. Uma mudança relevante durante a rodada deve invalidá-la. Não reaproveitar prova 1.14 sem os requisitos atuais. Aceite: lista com 120 tarefas termina em `verified` em contexto estável; mudanças isoladas e combinadas explicam a invalidação e não misturam provas de gerações distintas.

**Cache:** persistir `idade_cache` em `F3Base_Cache_Evidencia::prova()`, incluindo idade em segundos, instante observado, vínculo com o corpo HTTP e estado indeterminado quando não comprovado. Não recalcular a idade histórica como se fosse uma nova medição. Atualizar schema e projeções compacta/completa para não perder o dado na serialização.

Reservar `aviso` a condições que requerem atenção; separar limitações informativas. Quando a situação não é aplicável ou há evidência suficiente sem risco identificado, o aviso pode ficar vazio. `nao_garantido`/`desconhecido`, coleta atrasada ou idade incompatível não podem virar garantia de segurança apenas porque o TTL configurado é 3600. A renovação do token e a idade do HTML são provas diferentes. Aceite funcional: HTML com token vencido após mais de 60 minutos renova antes do POST e conclui sem 403; falha real de renovação continua diagnosticada.

### E2 — procedência da migração de ofertas: 60

Evitar UPDATE quando a única diferença for materializar `ofertas: []` que o contrato já fornece por herança. Migrações que realmente transformam valores precisam registrar origem de migração, versão, revisões antes/depois e vínculo com o snapshot, sem atribuir a mudança a um operador humano.

Para sites já atualizados à 1.15.0, incluir reparação limitada: conferir checkpoint `f3base_release_1150`, snapshot e hashes da transformação; vincular a procedência à revisão atual somente se ela ainda corresponder ao resultado comprovado. Registrar a reparação como tal, sem regravar a option e sem fabricar uma aprovação passada. Operação idempotente e com controle de concorrência.

Se houve edição posterior ou falta evidência, manter o motivo real e oferecer reconfirmação explícita da revisão vigente sem regravar o valor. Documentar esse procedimento em `como-usar`. Aceite: reproduzir os seis casos relatados e distinguir migração comprovada de alteração posterior não atribuível. Não eliminar todo `revisao_divergente` indiscriminadamente para cumprir uma contagem.

### E3 — contrato único de cadência: 64

Adotar `mecanismo` e `hook` como dados controlados pelo serviço, explicitamente somente leitura. A preferência editável contém `periodicidade` e `apos_n_ajustes`. Leitura de valores existentes aceita e preserva os metadados reconhecidos; eles não geram `campo_desconhecido` nem recomendação de remoção.

O schema de escrita e o erro de tentativa de alterar metadados devem explicar esse limite. Uma escrita completa das preferências editáveis sem `mecanismo`/`hook` não apaga os metadados controlados pelo serviço; ecoar o mesmo valor pode ser aceito, mas mudar para callback arbitrário é recusado. Unificar essa regra em UI, MCP, sanitização, diagnóstico e perfil. Não alterar silenciosamente periodicidade ou quantidade de ajustes da frota. A escolha operacional da cadência continua pendente do dono e não bloqueia corrigir o contrato.

### E4 — seis correções de contrato: 61

1. Deduplicar erros e avisos por código/caminho/causa após unir validação estrutural e de domínio; preservar erros diferentes no mesmo campo e nunca apagar `servicos[n].publico` inválido automaticamente.
2. Retirar `docs/perfis/piso-core-1140.json` dos perfis ativos. Remover o arquivo se não houver referências necessárias; caso permaneça como registro histórico, identificá-lo como obsoleto e indisponível para nova aplicação.
3. Corrigir `CONTRACTS.md`: preservação byte a byte de query exige `QUERY_STRING` intacta na entrada. Reconstrução dos fluxos nativos recupera só os campos de atribuição previstos, sem prometer recuperar parâmetros, ordem ou codificação já perdidos.
4. Em simulação de redirects, retornar `changed: false`, `persisted: false` e `alteraria` com o resultado projetado. Na escrita real, `changed` continua descrevendo mudança efetivamente persistida. Simular não incrementa revisão nem purga cache.
5. Fazer `integracoes($compacto)` respeitar o parâmetro: resumo com referências e contexto no modo compacto, detalhes disponíveis no completo, ambos derivados da mesma evidência e sem sondas adicionais.
6. Validar `preservar_query` como booleano antes de chegar ao método tipado, inclusive na leitura de configuração preexistente. Ausência usa o padrão; `false` permanece false; strings como `"false"` não viram true por coerção. Valor inválido é preservado para diagnóstico e a regra inválida não é executada. Reproduzir o risco sob `strict_types` e testar que nenhuma URL termina em TypeError/500.

### S1 — prova e publicação de ofertas: 41

Em `class-f3base-ofertas.php`, reconhecer duas ofertas identificadas separadamente no mesmo cartão: nome do plano + preço/moeda + respectiva periodicidade. Não basta aceitar qualquer cartão com os dois períodos: o preço mensal não pode comprovar o anual nem vice-versa. Manter modalidades fixo, a partir de e sob consulta; evidência ambígua ou conteúdo oculto não comprova a oferta.

Manter validade de prova de 24 horas e antecipar a revisão programada para 12 horas, em lotes e com retomada. A validade deve superar o intervalo normal de renovação; cron atrasado continua visível e prova expirada não vira permanente. Substituir dependência indiscriminada de `get_lastpostmodified()` por dependências relevantes da página/serviço, templates, blocos reutilizados e regras do emissor. Alteração comprovadamente irrelevante em outro post não suspende ofertas; dependência sem rastreabilidade deve ser declarada.

Purgar somente páginas afetadas quando a elegibilidade ou o conteúdo emitido mudar, incluindo suspensão e restauração da prova. Atualizar apenas o horário de uma prova idêntica não dispara nova purga nem ciclo infinito. Conferir também o HTML servido depois da purga, não apenas o grafo PHP antes do cache.

Aceite: cartão “R$ 239/mês ou R$ 2.390/ano”, preços trocados, dois planos parecidos, conteúdo oculto, falha de rede, cron atrasado, alteração relevante/irrelevante e cache aquecido. No caso Twinia, a remoção do emissor do tema e o aceite das seis ofertas dos três planos ficam com a frota.

### V1 — consentimento integrado ao tema: 45

Corrigir `f3base-consentimento.js` e CSS do componente. Resolver as cores efetivamente computadas pelo navegador, formatos como `oklch` e composição de alfa sobre os ancestrais, sem interpretar automaticamente transparente como contraste zero. Preservar valores explícitos válidos do tema e os tokens documentados do componente.

Usar estilos de baixa especificidade para permitir a composição pelo tema. Separar estilos essenciais de controles/foco dos estilos de contêiner; o painel do tema deve poder definir fundo, borda, padding, largura e alinhamento sem um cartão interno imposto pelo pacote. Documentar um contrato explícito para painel controlado pelo tema e manter aparência completa quando o próprio plugin fornecer o contêiner. Não detectar autoria do layout apenas pela cor do `body`.

Para fundo sem contraste calculável de forma confiável, como imagem variável, aplicar fallback local acessível nos controles e informar a limitação; não garantir matematicamente contraste sobre qualquer imagem arbitrária. Preservar o nível atual de contraste e testar foco/teclado. Não alterar preferências ou regras de consentimento ao corrigir apresentação.

Aceite visual: 360 e 1440 px, claro/escuro, fundo transparente, alfa, `oklch`, contêiner do plugin e contêiner do tema; sem overflow, corte de ações ou perda de foco. Usar fixtures em bancada; a retirada das compensações de conselar/philon pertence à homologação dos temas.

### L1 — Markdown e índice integral sem geração publicada: 36

Incluir `f3base_llms_regenerar` na tarefa fechada `llms` de `executar-pendentes`, com trava, orçamento e retomada existentes. Antecipar geração na instalação e na atualização relevante. Servir a geração válida publicada enquanto a substituta é preparada, desde que sua seleção ainda respeite visibilidade e exclusões atuais.

Sem geração publicada, tentar conversão de contingência pelo mesmo conversor de conteúdo público elegível, com cache e trava contra concorrência. Para `.md` individual, limitar o trabalho à página; para `/llms-full.txt`, trabalhar com seleção consistente e nunca retornar texto truncado como índice integral concluído. Limites de tempo/memória são operacionais, não cortes editoriais silenciosos do conteúdo.

Esse caminho de resposta vale para `.md` e `/llms-full.txt` servidos pelo WordPress. `/llms.txt` físico é publicado/substituído pelo gerador e não recebe status ou headers desse handler; seu diagnóstico precisa distinguir publicação física de rota dinâmica. Se não for possível concluir a rota dinâmica no orçamento, responder estado temporário **503 com Retry-After e no-store**, agendar a conclusão e explicar a situação no diagnóstico. Não usar 404 para conteúdo existente apenas aguardando geração. Conteúdo inexistente, privado, excluído ou rota desabilitada mantém o comportamento de indisponibilidade apropriado.

Aceite: primeira instalação, janela após `atualizar_cache`, pedidos concorrentes, falha/interrupção do conversor, conteúdo grande e mudança para privado durante a geração. Fixtures usuais devem servir 200 sem o 404 temporário; fixture acima do orçamento deve falhar de forma temporária e recuperável, sem publicar conteúdo parcial ou privado. A solicitação de conversão síncrona ilimitada não será adotada.

### M2 — ensaio de desempenho representativo: 38

Repetir a medição sem `pauseAfterLoadMs: 12000` e sem alterações manuais nas janelas de quietude, usando a configuração padrão resolvida do Lighthouse, com versão registrada, presets mobile/desktop e condições de consentimento/cache explícitas. Guardar JSON, trace, log de rede, instante de `load`, primeiro POST e encerramento da coleta. A bancada anterior, que ampliava a janela para 12 segundos, não comprova a janela padrão.

Na cópia local do Lighthouse 13.5.0, `defaultSettings.pauseAfterLoadMs` é 1000 no modo simulado, mas existem overrides de 5250 para modos não simulados (`constants.js` e `config.js`). Portanto, registrar a configuração efetivamente resolvida, não apenas afirmar “o padrão é 1000”. Não equiparar automaticamente um ensaio local ao serviço PSI sem documentar suas diferenças.

O aceite é uma medição reproduzível do POST em relação à janela observada. Estar fora das requisições será uma conclusão possível, não um resultado imposto. Se estiver dentro, quantificar duração/custo e avaliar se existe regressão concreta; não alongar o prazo apenas para esconder a captura do teste. Fazer também observação funcional mais longa, confirmando envio e resposta após o prazo, e saída precoce por `pagehide`/`visibilitychange`. Ausência de POST no trace não demonstra que nenhum dado foi perdido.

### D2 — textos completos e limpeza de fonte: 66

- Saúde de Schema: informar todas as propriedades efetivamente declaradas, além de serviços e sameAs. Separar declaração, elegibilidade e emissão comprovada; leitura de configuração não pode afirmar que o HTML público contém o grafo sem evidência datada.
- `promover_cta()` está sem hook e é uma operação sem efeito. Remover esse resíduo de compatibilidade e comentários que prometem promoção automática. Conferir referências antes de excluir constantes: `HREF_DO_MODELO` ainda é usado por `hrefs_do_modelo()` na 1.15.0; não apagá-lo isoladamente como se não tivesse dependências. Remover a cadeia inteira apenas se não houver consumidor ativo no pacote.
- Alinhar `f3base_llms.full` com a decisão de frota relatada: **true** para instalação nova/chave ausente. Preservar false explícito. Textos devem separar padrão do pacote de valor atual do site; atualizar catálogo, exemplo, documentação e perfil juntos. A ampliação de conteúdo público segue os mesmos filtros de elegibilidade, sem publicar conteúdo fechado.

### O que permanece externo ou não será adotado literalmente

**50:** esperar a soma com a regra corrigida sobre logs ainda disponíveis. Sem logs antigos não há recuperação legítima. **52:** esperar o período de sete dias e verificar `Duplicate entry` e `persistencia_falhou`; a revisão local não substitui essa observação. O acompanhamento em korvena.net.br é do dono. Se a frota trouxer falha nova, ela reabre o diagnóstico; não inventar uma segunda correção antecipada.

**17:** o pedido de 29/09 revoga o adiamento do Pipedrive. Webhook genérico de saída e confirmação por URL continuam fora. A rota de entrada do Google Ads é parte da captura nativa descrita na seção 8. Nenhum trabalho no implantador, alteração de tema, remoção automática de compensações ou solicitação à DreamHost entra no pacote.

Detalhamento do item 17:

| Funcionalidade adiada | O que acrescentaria | Situação e motivo |
|---|---|---|
| Integração com CRM/Pipedrive | Encaminhar contatos/leads ao CRM, relacionar pessoa e organização e anexar formulário, origem, campanha/anúncio e contexto de navegação autorizado. | Incluída na 1.16.0 pelo pedido de 29/09, conforme CRM1. |
| Webhook de leads | Notificar uma URL externa após a captura, permitindo automações e integrações além do CRM, com contrato versionado, autenticação/assinatura, registro de tentativas e reenvios controlados. | Mantido para versão posterior no mesmo grupo de integrações; não substitui nem bloqueia o aviso interno atual. |
| Página de confirmação por URL, por formulário | Redirecionar o visitante após envio aceito para uma página configurada, como `/obrigado/`, em vez de depender apenas da confirmação atualmente fornecida pelo formulário. | Fora do schema atual e mantida fora desta release no backlog recebido; ctooffice usa solução própria, segundo o relatório. É tecnicamente independente de CRM/webhook e pode receber prioridade própria em decisão futura. |

As pendências **50** (classificação de slugs longos na soma dos logs) e **52** (concorrência de eventos repetidos causando erro de banco/503) aguardam aceite em produção de correções anteriores. A frequência operacional de **64** aguarda escolha do dono; a correção do contrato entra agora. Alterações de temas/implantador são responsabilidades externas. Essas situações devem permanecer distintas de funcionalidade adiada.

Também não entram: mascarar warning desconhecido como situação segura (37), prometer POST fora do trace independentemente da medição (38), confirmar toda procedência divergente sem prova (60), assumir uso de menu só pela declaração do tema (42) ou executar conversão integral sem limite operacional (36). São ajustes de critério para preservar evidências, dados e disponibilidade, não exclusões dos problemas correspondentes.

## 8. CRM1 e ADS1–ADS4 — Pipedrive, origens nativas e atribuição de anúncios

### Escopo e base examinada

Fonte de requisitos: **“Especificação leads do Base Site Core Fator3 no Pipedrive.md”**, datada de 25/09 e enviada pelo dono em 29/09. A implantação comercial inicial indicada é fator3.com.br, ctooffice.com.br e korvena.com.br; o pacote continua configurável para qualquer instalação. Conta informada: `fator3.pipedrive.com`, Lite, usuário Comercial Fator3. Esses dados e IDs são referências fornecidas, sem verificação autenticada nesta análise.

Implementar conexão direta, sem intermediário obrigatório. Escopo firme da 1.16.0: formulários do site → Pipedrive; Meta Lead Ads → registro local → Pipedrive; Google Lead Form → registro local → Pipedrive; atribuição OpenAI/ChatGPT Ads → formulário do site → Pipedrive. Importação de formulários nativos OpenAI depende da confirmação descrita em ADS4. LinkedIn depende de aprovação e homologação do acesso antes do fechamento: sem isso, ficará explicitamente indisponível por dependência externa, sem anunciar integração entregue ou criar outra rota pública de contingência.

O anexo descreve a 1.13.0. A base real deste plano é a **1.15.0**, estrutura de leads 3: `f3base-formularios.js` já usa `f3baseContexto.atribuicao()`, e `F3Base_Leads_Contexto` compartilha normalização, consentimento, sessão e contexto. Reaproveitar esse caminho e C2; não restaurar o JavaScript antigo nem criar armazenamento paralelo de atribuição. Novos papéis `empresa`, `cargo`, `servico`, fila CRM e adaptadores de anúncios ainda precisam ser implementados.

### Configuração, ativação e experiência de uso

Adicionar **Integrações** dentro do menu que centraliza Leads e Formulários, com sub-abas **Pipedrive**, **Origens de anúncios** e **Entregas**. Estado técnico e Operação Core mostram resumo e link para essas telas; não duplicar formulários de configuração em menus diferentes. Usar seletores de usuário, etiqueta, campos e opções descobertos na conta, mostrando nome e ID; mensagens distinguem configuração salva, credencial válida, integração ativa e entrega confirmada.

| Configuração | Conteúdo e regra |
|---|---|
| `f3base_pipedrive` | `ligado`, domínio da conta, identidade da conta verificada, responsável, etiqueta Novo, unidade padrão, mapeamento dos sete campos comerciais, traduções, serviços, tarefa, reserva de orçamento e política de testes. Padrão global desligado; valores explícitos preservados. |
| `f3base_pipedrive_token` | Segredo próprio; envio somente no cabeçalho `x-api-token`, sob HTTPS [PD3]. Sem segredo no navegador, URL, notas, erros, exportação ou documentação de exemplo. |
| `f3base_anuncios_meta` / `_token` | Ativação, páginas/formulários associados a este site, versão Graph, papéis das perguntas, intervalo, campanhas de contingência e credencial separada da CAPI. |
| `f3base_anuncios_google` / `_chave` | Ativação, formulários/campanhas admitidos, mapa campanha ID → nome, papéis por coluna e chave secreta da rota. |
| `f3base_anuncios_linkedin` / `_token` | Conta, versão, papéis, estado de aprovação e credenciais, quando a origem estiver habilitada para desenvolvimento. OAuth/refresh têm ciclo e diagnóstico próprios. |
| Formulário | `pipedrive` booleano, padrão true condicionado ao módulo global ativo; `servico_fixo` opcional, selecionado entre opções verificadas. False explícito exclui o formulário do CRM. |

Todas as opções seguem schema, revisão, simulação, auditoria e política de gestão existentes. Validar host de destino Pipedrive e identidade da conta antes de enviar segredos. Não aceitar host arbitrário ou seguir redirect que exponha a credencial. Trocar token para a mesma conta permite retomar; trocar de conta suspende os itens vinculados à anterior até reconciliação explícita, sem reinterpretar IDs.

O operador configura e habilita o módulo; salvar a credencial completa dispara verificação em segundo plano e libera os próximos leads elegíveis quando os requisitos forem satisfeitos, sem precisar apertar um segundo botão de sincronização. A saúde explica pendências de campo, permissão, credencial e executor. Guardar marco de ativação; não importar o histórico anterior nem passar a enviar formulários previamente excluídos por uma mudança implícita de padrão.

O token e os IDs reais serão fornecidos pela operação na implantação. O pacote não cria campos, etiquetas, funis ou usuários no CRM. As chaves/IDs do anexo ficam em exemplo de configuração da conta Fator3, separados dos padrões do produto, e precisam passar pela verificação de leitura antes da ativação. Política de privacidade e aviso do formulário são pré-requisitos de operação; o plugin oferece orientação, sem reescrever páginas ou temas.

Referência de configuração fornecida para a conta Fator3, observada pelo autor do anexo em 25/09, a reconfirmar na ativação:

| Campo | Chave / valores informados |
|---|---|
| Responsável / etiqueta Novo | `24617815` / `77570ba0-b933-11f1-9be3-955dbf3be411` |
| Unidade | `a6856374537cc03694d68f8a242b083fc20d0e2c`; fator3=44, ctooffice=45, korvena=46 |
| Canal | `53bf9d1b48b76933f8b5cead0fb07112d064961a`; instagram/facebook=80, linkedin=81, google=82, OpenAI/ChatGPT Ads=83 mediante regra ADS4; fallback do site=85 |
| Parceiro | `c980b55160e74cd39d67a1666e65e750011c2b3a`; apex=47, saask=48, datta=49, interno=50, sem campanha=51 |
| Ponto de conversão | `cd1662eaac4c279d069f158256289c5d72b8e854`; anúncio nativo=52, formulário do site=53, formulário WhatsApp=54 |
| Serviço, múltipla seleção | `5a81949e986c3f117cc748791e72a0f3c0d24e9e`; CTO Office: CTO-as-a-Service=89, Techlead-as-a-Service=90; Korvena: squad=91, profissional=92, escopo fechado=93, MVP=94; Fator3: Tech Advisor=95, CTO-as-a-Service Premium=96 |
| Campanha | `c3a9451e31d91c3002155884d68c68f67cf7fcfa` |
| Anúncio/criativo | `0017e916e1b899c61a97452e23aede3d7a01db22` |

As traduções são editáveis e vinculadas à conta. O rótulo comercial “OpenAI Ads” da opção 83 vem do cadastro informado. ADS4 condiciona seu uso ao sinal de anúncio registrado; `utm_source=chatgpt` ou referência ao ChatGPT, isoladamente, não classificam o acesso como pago nem comprovam captura nativa. Nenhum desses IDs será constante de código ou default aplicado a outra conta.

### S2 — segredos cifrados e limites da proteção (recomendação R3)

Centralizar segredos do CRM, tokens de anúncios (incluindo refresh tokens quando houver), chave Google e o `f3base_meta_capi_token` existente em um serviço de armazenamento cifrado. Usar `sodium_crypto_secretbox`, nonce aleatório novo por gravação e chave de 32 bytes derivada por HKDF de `wp_salt('secure_auth')`, com contexto versionado e específico por option/finalidade [W8]. Envelope contém versão, algoritmo, nonce e texto cifrado autenticado. Validar o segredo de entrada antes de cifrar; o envelope não passa pelo sanitizador de texto que trunca tokens. Releitura interna valida a decifra, sem comparar texto aberto com envelope nem expor um deles no resultado. Gravar com autoload desligado. Não criar constante em `wp-config.php`, chave no banco ou fallback em texto aberto.

Disponibilizar texto decifrado somente às rotinas internas que precisam autenticar chamadas. Configuração, contrato, simulação, prévia, auditoria, snapshots, exportação, erros e documentação mostram existência, estado de leitura e versão da cifra; não retornam token, tamanho ou últimos caracteres. Entrada vazia mantém o segredo e remoção exige a ação própria já existente. Revisão/comparação não pode depender de expor o valor. O modo operável `todas` permite substituir segredo pelo canal somente quando o serviço de cifra está apto.

Na atualização, migrar o token CAPI em escrita condicional e confirmar que a rotina interna decifra o mesmo valor, sem gerar backup/auditoria com o texto aberto. Falha não apaga a credencial antiga; marca migração pendente, suspende o consumo externo até resolver e recusa novas gravações inseguras. Se Sodium ou fonte de chave não estiverem disponíveis, dar diagnóstico acionável; captura local permanece. Troca de salts, corrupção ou autenticação da cifra inválida suspende somente integrações afetadas, sem consumir tentativas, com pedido de recadastro.

**Alcance:** a cifra protege a option em consultas SQL e cópias isoladas do banco. Um operador com execução PHP ou acesso às salts e ao banco consegue decifrar; backup completo que contém essas chaves não ganha isolamento absoluto. O Core controla suas saídas; correções de logs/prévias do pacote MCP e cópias históricas fora do Core continuam responsabilidade de seus componentes. Não declarar que a migração remove segredos de backups antigos. Testar com credencial sintética no banco, UI, canais do Core, auditoria e logs; não imprimir credenciais reais na evidência.

### Registro, fila e execução posterior

Manter `f3base_leads` como registro de captura. Enfileirar somente após persistência confirmada de formulário aceito, comercial e elegível, ou de origem nativa validada. Cliques `whatsapp_cta`/`contato_cta`, spam, eliminados e duplicatas de transporte não geram uma nova entrega. Formulário sem contato identificável permanece local com motivo de inelegibilidade; não inventar e-mail, telefone ou pessoa. Nome com e-mail ou telefone válido é o mínimo para conciliação automática segura.

Criar `f3base_pipedrive_fila`, com chave única por conta de destino, instalação e `record_id`, índices de estado/próxima execução, lease com dono e prazo, contador, última resposta resumida, motivo, versão da regra e etapas concluídas. Dados de contato continuam no registro local; a fila guarda referências, IDs remotos, revisão do mapeamento e metadados técnicos. Esses identificadores são protegidos pelas mesmas permissões do contato.

Garantir intenção de entrega durável junto à captura, por transação/outbox equivalente, e reconciliação limitada de registros elegíveis sem item. Uma queda entre salvar o lead e agendar o cron não pode perder a entrega. A resposta ao formulário depende da captura local, sem esperar a API do CRM. Aviso interno, resposta ao visitante e CRM têm estados independentes.

Estados: `pendente`, `reservado`, `entregando`, `entregue`, `suspenso`, `falhou`, `incerto` e `cancelado`. IDs de organização, pessoa, lead/negócio, nota e atividade são checkpoints de etapas distintas; `entregue` exige todas as etapas obrigatórias confirmadas. Se a nota foi salva e a tarefa falhou, repetir somente a tarefa. Publicar no detalhe do lead `crm.pipedrive` com destino, IDs, horários, resultado criado/anexado e motivo, sem sobrescrever dados concorrentes.

Após confirmar captura e intenção durável, agendar `f3base_pipedrive_entregar` para agora e, no encerramento da requisição, solicitar execução por loopback não bloqueante, com trava e supressão de disparos repetidos. Reutilizar o disparo por `spawn_cron()` observado em L1, sem executar chamada CRM no próprio shutdown; L1 também faz trabalho síncrono local, que não será copiado para o envio externo. Processar até dez itens por rodada com orçamento de tempo/chamadas. Respeitar executor externo configurado e políticas de cron; loopback pode falhar ou atrasar e não constitui garantia de entrega. Registrar disparo, início real, fim, falha e origem da execução; Operação Core oferece execução limitada e retomada.

O anexo diz “6 tentativas” e lista seis esperas. Fixar a semântica: **uma tentativa inicial e até seis novas tentativas**, após 1, 5, 15, 60, 180 e 720 minutos, com pequeno jitter; são até sete execuções da etapa que falhou. Pausa por orçamento/credencial não consome tentativas de envio. Erros permanentes 4xx suspendem; 429 respeita `Retry-After`/limites; 5xx e falha transitória seguem a política; resposta ambígua após escrita segue reconciliação antes de repetir. Esgotamento gera falha visível e reenvio manual controlado.

### F1 — motor compartilhado e retenção operacional (R16)

Extrair de `F3Base_Capi_Fila` as primitivas comprovadas de reserva condicional, posse/prazo, ordenação com cancelamento, recuperação, orçamento por lote e diagnóstico. CAPI e CRM usam esse motor com adaptadores próprios e tabelas separadas. A CAPI atual tem reserva de 120 segundos, seis tentativas, validade de payload limitada e histórico de sete dias; não transferir esses valores nem a limpeza de payload automaticamente ao CRM. O CRM precisa preservar etapas/IDs para reconciliar efeitos externos. Contratos e comportamento CAPI continuam cobertos por regressão de cancelamento, consentimento, timeout e concorrência.

Filas concluídas/canceladas CRM conservam histórico operacional por 30 dias, configurável entre 7 e 90, sem corpo de contato; depois podem ser compactadas. Manter no registro local os vínculos remotos e o recibo de conclusão necessários a reenvio idempotente enquanto o registro existir. Itens incertos, limpeza remota pendente e etapas parcialmente concluídas não são apagados pelo prazo de concluídos; ficam diagnosticados para resolução. Limite de capacidade provoca suspensão recuperável/aviso, sem descartar intenção de entrega.

Tombstones/recibos de origem têm prazo e marco próprios: precisam cobrir a janela admitida de reconciliação e retries. Adotar inicialmente 90 dias para recibos nativos mínimos, sem contato, e não aceitar reimportação anterior ao marco de cobertura desses recibos. A limpeza só avança esse marco após verificar ausência de recuperação pendente. Para provedor com janela não comprovada, restringir a recuperação ao intervalo coberto e declarar lacuna. Não prometer deduplicação histórica após apagar o único identificador que a torna possível.

### Conciliação, deduplicação e falhas parciais

1. Resolver pessoa por e-mail exato; sem e-mail, telefone normalizado quando houver país conhecido. Não escolher por nome de pessoa. Telefone sem país confiável fica preservado como recebido, sem acrescentar DDI por suposição. Mais de um candidato ou conflito de identidades suspende para revisão.
2. Resolver organização por nome exato quando empresa estiver informada. Correspondência única pode ser reutilizada segundo a regra do anexo; nome empresarial não é identidade universal, portanto homônimos/candidatos múltiplos exigem revisão. Sem empresa, não criar organização.
3. Não modificar pessoa ou organização preexistentes automaticamente. Empresa/telefone/cargo divergentes vão para a nota. Evitar criar organização nova órfã quando a pessoa já existente não será atualizada: nesse caso, a empresa informada é contexto da interação.
4. Procurar negócio aberto da pessoa antes de criar lead. Se houver destino único, anexar a interação ao negócio; senão, procurar lead não arquivado da pessoa. Havendo mais de um destino comercial elegível, suspender para escolha, sem escolher o primeiro por ordem da API. Paginar todas as buscas relevantes.
5. Sem negócio ou lead elegível, criar lead ligado à pessoa e, quando aplicável, à organização. Em reenvio de transporte, reaproveitar o resultado. Um novo formulário da mesma pessoa é nova interação: gera uma nota no destino existente, preservando os campos de origem originais do lead/negócio.
6. Criar **uma nota por captura**, inclusive no fluxo que reaproveita lead. Os passos 6a e 7 do anexo não produzirão duas notas iguais. Criar tarefa de primeiro contato quando o destino comercial for novo e a opção estiver ligada; em destino existente, registrar a interação e evitar nova tarefa idêntica pendente. Registrar também `atividade_id`.

Usar chave de operação estável com instalação + conta + `record_id` + etapa. Leases impedem dois workers locais de executar a mesma etapa. Registrar intenção antes da chamada mutante e checkpoint após confirmação; nota/atividade levam referência técnica reconciliável, e lead usa referência de integração compatível com a API.

**Timeout após o CRM gravar é diferente de falha confirmada.** Consultar/reconciliar o resultado antes de repetir POST. Se a API não permitir comprovação inequívoca, deixar `incerto` com ação de revisão. Não alegar garantia de execução única remota apenas porque IDs são salvos após a resposta. Testar também sucesso remoto seguido de falha ao gravar checkpoint local.

Sites independentes compartilham a conta CRM, mas não o lock local. Definir um único site responsável por cada formulário nativo e usar namespace global de origem nas notas. Busca prévia não constitui exclusão mútua entre os três sites; testar corrida entre instalações, detectar concorrência e encaminhar ambiguidades sem fusão destrutiva. Não prometer unicidade global absoluta de pessoas/organizações sem mecanismo de coordenação adicional. Para o volume inicial, preservar a arquitetura direta do anexo e explicitar esse limite operacional. Após criar pessoa, fazer uma busca exata adicional por e-mail quando disponível; se houver candidatos múltiplos, registrar `possivel_duplicidade` e suspender decisões ambíguas. Usar `duplicidade_detectada` quando houver evidência dos registros concorrentes, sem alegar autoria desta integração apenas por nome/data. Fazer uma rechecagem limitada posterior, pois a segunda criação pode ocorrer depois da busca imediata. Essa detecção não garante ausência de corrida nem substitui coordenação entre sites; incluir o custo no orçamento, sem fusão automática.

### Dados comerciais, atribuição e comportamento enviados

| Dado | Destino/regra |
|---|---|
| Nome, e-mail, telefone | Pessoa; normalização sem fabricar dados. |
| Empresa | Organização quando aplicável; divergências em nota. |
| Cargo | `job_title` apenas quando suportado pela conta; caso contrário, campo existente explicitamente mapeado ou nota, sem bloquear a entrega. |
| Título | Empresa ou nome da pessoa + serviço; sem serviço, “contato do site”; títulos de teste identificados. |
| Unidade, canal, parceiro, ponto de conversão | Campos personalizados configurados; preservar valor recebido, regra e motivo de fallback. |
| Serviço | IDs das opções existentes, inclusive seleção múltipla; resposta não mapeada fica na nota e na saúde. |
| Campanha e anúncio/criativo | Nomes recebidos sem alteração nos campos indicados; IDs de plataforma/conta/campanha/grupo/anúncio preservados separadamente no contexto e na nota. |
| Nota da interação | Mensagem, respostas comerciais autorizadas, formulário/versão, página ou formulário nativo, data, site, `record_id`, modelo/qualidade de atribuição e divergências. |
| Jornada existente | Resumo limitado de páginas e eventos vinculados à mesma sessão/navegação do lead, até a captura e dentro da retenção/consentimento: entrada, páginas visitadas, CTAs, início/conclusão do formulário e horários disponíveis. |

A jornada usa os vínculos já capturados, sem associação por IP, por horário aproximado ou por e-mail com sessões anônimas. Definir limites documentados (inicialmente até 20 páginas e 50 eventos por nota), indicar corte e cobertura, e fornecer link autenticado para o registro completo local. Ausência de consentimento, vínculo ou retenção aparece como indisponível. Não inventar duração ativa a partir de intervalo de timestamps nem afirmar que o usuário leu um conteúdo apenas por visitá-lo. Ingestão nativa de anúncio não produz sessão de navegação do site. **Aceite obrigatório de jornada:** cliques `whatsapp_cta` e `contato_cta` anteriores ao formulário, vinculados à mesma sessão e consentidos, aparecem na nota com horário, tipo e destino sanitizado. Remover texto pré-preenchido de WhatsApp, query sensível e identificadores de clique da URL exibida. Consultar também registros de clique quando necessários para cobrir o vínculo; deduplicar pelo identificador do evento. Clique sozinho continua local e não cria pessoa fictícia; atividades posteriores ao snapshot não entram automaticamente nesta entrega.

Exportar snapshot do contexto permitido da captura. Não acrescentar comportamento futuro automaticamente nem transferir IP, User-Agent bruto, cookies, tokens, senhas ou conteúdo de anexos por padrão. Anexos permanecem acessíveis pelo detalhe autenticado local. URLs são limitadas aos parâmetros de campanha permitidos; texto do usuário deve ser escapado para a nota HTML. Redução de consentimento e eliminação são reavaliadas antes da entrega.

Manter os modelos e o prazo configurados da atribuição compartilhada. Primeira/última origem e origem desta navegação ficam separados; usar o toque selecionado pela política para os campos comerciais e conservar o contexto permitido na nota. C2 impede que `fbc`/`fbp` substituam UTMs. Reutilizar os campos e timestamps canônicos já existentes; não criar `primeira_visita_em` com significado diferente de `primeiro_toque_em`.

**Diferença de consentimento no anexo:** a 1.15.0 ainda admite origem contextual da navegação sem armazenamento de histórico. Para o envio ao CRM, aplicar o requisito mais restrito do documento: sem medição permitida, não exportar atribuição publicitária nem jornada. O consentimento de publicidade continua necessário para os identificadores aos quais ele se aplica. Não ativar categoria ou ampliar coleta ao configurar o CRM. A evolução da política local deve ser documentada separadamente, sem apagar ou reclassificar dados históricos.

Ausência de UTM/consentimento **não comprova origem orgânica**. Para respeitar o cadastro comercial informado, permitir o fallback configurado 85/51, mas registrar `origem_nao_observada`/`medicao_nao_permitida`, explicar na nota e separar esse grupo nos relatórios. O nome “Site (orgânico)” da opção 85 não será tratado como evidência de tráfego orgânico. Analogamente, `utm_source` isolado é uma convenção declarada de mapeamento, não prova de investimento em anúncios.

### Regras e papéis dos formulários

Acrescentar `empresa`, `cargo` e `servico`, mantendo unicidade dos papéis por formulário. Serviço aceita select/radio/checkbox e segue presente em “Perfil da demanda”, mesmo sendo campo com papel. Validar lista de respostas/checkbox de ponta a ponta, sem converter múltiplos valores em uma string ambígua. O mapeamento por texto normalizado deve ser específico por formulário quando houver colisões; preservar o valor bruto e preferir identificador estável de opção quando disponível.

Serviço selecionado tem prioridade sobre `servico_fixo`; este cobre ausência de seleção e formulários de serviço único. Seleção inválida não é mascarada pelo fixo. Se houver múltiplos serviços, enviar todos os IDs válidos e registrar os não mapeados. Empresa, cargo e serviço são armazenados como dados declarados do formulário; o plugin não infere empresa por domínio de e-mail.

Oferecer modelo comercial com nome, e-mail, telefone e empresa obrigatórios, cargo/mensagem opcionais, serviço obrigatório salvo fixo e aviso de uso dos dados. Não modificar formulários existentes nem exigir e-mail corporativo por lista arbitrária de provedores. Na configuração, mostrar o que irá ao CRM e permitir excluir formulários não comerciais.

Campanha: interpretar `unidade_parceiro_objetivo_aaaamm` quando esse nome estiver disponível, comparar códigos sem acento/caixa e manter o original. Unidade inválida usa padrão do site com motivo; parceiro desconhecido fica vazio e gera aviso. Sem campanha usa o fallback configurado. Separar campanha ausente de ID nativo sem nome resolvido: o segundo não pode se transformar silenciosamente em orgânico.

### APIs, autenticação e orçamento

Usar versões por **operação**, com lista fechada de método/caminho e testes de contrato: criação/leitura de leads e notas permanecem v1; busca de leads possui v2; pessoas, organizações, negócios e atividades usam v2; leitura de definições `dealFields` já possui v2. O teste de identidade é `GET /api/v1/users/me`, corrigindo o `/api/v2/users/me` do anexo [PD1, PD2, PD6, PD7, PD8]. Os endpoints v1 de pessoas, organizações, negócios, atividades e busca que possuem substitutos estão sem suporte desde 01/08/2026 [PD9]: proibir seu uso e fallback para eles. Para os metadados necessários, manter somente leituras v1 documentadas de `users`/`users/me`, `leadLabels` e `activityTypes` quando usadas [PD2, PD11–PD12]; a lista do parecer limitada a leads/notes/users-me impediria os seletores previstos. A whitelist é por operação, sem liberar alterações de usuários/etiquetas/tipos. Usar somente parâmetros documentados; por exemplo, a listagem normal de leads já é de não arquivados, sem depender de `archived_status=not_archived` não descrito nesse endpoint.

`job_title` em pessoas pode responder 403 sem contact sync; a verificação deve detectar a capacidade antes do envio, usando a nota como fallback. Não confundir esse caso com token inválido [PD5]. Validar formatos de campos simples e de seleção múltipla no endpoint efetivamente usado, com teste de ida e releitura; não transportar cegamente a representação v2 para o corpo v1. Homologar Serviço com duas opções, enviando o formato aceito por `POST /api/v1/leads` e conferindo os mesmos IDs na releitura. Ensaiar representações string delimitada/array apenas no ambiente de teste; fixar a aceita no adaptador e não tentar um segundo POST em produção após resposta ambígua. Testar criação/releitura de lead e nota antes de consolidar conciliação. HTTP 404/410 de rota documentada suspende com `api_pipedrive_alterada` após distinguir de ID excluído ou URL configurada errada, sem consumir tentativas de contato.

Ler a identidade da conta/usuário, opções, etiquetas e tipos sem alterar a estrutura. Cachear metadados com revisão e invalidar quando a resposta demonstrar que mudaram. Contabilizar consultas de pessoa, negócio, paginação, reconciliação e tarefas: a estimativa de nove chamadas/60–110 tokens do anexo não é teto garantido.

O orçamento é compartilhado pela conta, incluindo agentes e outros sites; Lite com um assento corresponde à fórmula publicada de 30.000 tokens, sujeita ao estado real da conta [PD4]. Reserva inicial configurável: 3.000. Observar cabeçalhos realmente presentes e distinguir saldo diário de janela de rajada. Usar apenas os cabeçalhos documentados e sua unidade: `x-ratelimit-limit`, `x-ratelimit-remaining`, `x-ratelimit-reset` descrevem a janela de rajada; `x-daily-requests-left` descreve requisições POST/PUT restantes sob api_token, e não saldo do orçamento diário de tokens [PD4]. Não usar esse contador para aplicar a reserva de 3.000 tokens. O cabeçalho `x-daily-ratelimit-token-remaining` não é contrato confirmado e não será dependência. Sem saldo global de tokens comprovado, expor desconhecido e aplicar orçamento local conservador configurável, explicitando que outros sites/agentes não estão contabilizados. Mostrar saldo desconhecido/estimativa local como tal, nunca como saldo global confirmado.

Respeitar limites documentados de 10 buscas/2 s e 20 requisições/2 s para o Lite, 429 e demais limites de busca/rajada, retomar com atraso indicado e distinguir esgotamento diário de rajada. Para pausa diária, usar reset comprovado ou fuso do servidor Pipedrive verificado + margem de cinco minutos; não usar automaticamente meia-noite de São Paulo. Sem reset conhecido, manter pausa diagnosticada e reavaliação limitada. Não consumir tentativas de lead em espera por orçamento nem disparar dez itens em paralelo contra o mesmo token.

### ADS1 — Meta Lead Ads

Consultar páginas/formulários explicitamente associados a este site em intervalo alvo de cinco minutos; descobrir formulários para seleção e mapeamento. Coleta em lotes com paginação, cursor por formulário, janela sobreposta de dez minutos e deduplicação única por origem/conta/formulário/lead. Só avançar o cursor de forma que todos os itens do intervalo tenham sido persistidos; falha parcial não pula uma página. Após interrupção longa, retomar do cursor confirmado, sem limitar a recuperação aos últimos dez minutos.

No primeiro uso, iniciar no marco de ativação, sem carregar histórico anterior por padrão. Conservar o timestamp nativo e `recebido_em` local separadamente, ID de lead, formulário, campanha, grupo, anúncio e plataforma/superfície. Gravar método `anuncio_meta`; perguntas não mapeadas permanecem na nota, com tamanho e tipos limitados. Um lead eliminado não será reimportado pela sobreposição: manter tombstone técnico mínimo.

Manter token separado da CAPI. O guia oficial de recuperação de leads lista `ads_management` e `leads_retrieval`, com permissões de páginas/ativos aplicáveis; o índice oficial recuperado confirma essa exigência geral, mas a página completa retornou erro nesta consulta [AD6]. Incorporar a verificação de `pages_show_list`, `pages_read_engagement`, `pages_manage_ads`, acesso à página/conta/formulário e nível de acesso do app na versão Graph selecionada. `pages_manage_metadata` é associado a webhook; polling não ganha essa exigência sem operação que a necessite. Não afirmar que `ads_read` substitui todos os requisitos de recuperação de leads.

Antes da ativação, conferir também **Leads Access Manager** e a vinculação do usuário/app aos ativos. O diagnóstico separa permissão ausente comprovada, ativo inacessível e possível restrição do gerenciador; erros genéricos não permitem atribuir a causa com certeza. Registrar evidência mínima e pendência acionável, sem dados pessoais. Mapa por campanha cobre falta de nomes/enriquecimento, mas não substitui uma permissão obrigatória para ler o próprio lead.

Erro de token/permissão suspende a origem sem mover o cursor. Falha temporária usa recuo e protege o orçamento Graph. Preservar `is_organic` quando disponível. `platform` é opcional e não confirmado no contrato completo: guardar somente se vier, sem exigi-lo nem usá-lo sozinho para decidir canal 80. Quando Facebook/Instagram não forem distinguíveis pela resposta, registrar Meta/superfície desconhecida, sem inventar Instagram. Lead nativo orgânico tem qualidade/origem explícita. Avisar se a última consulta completa bem-sucedida ultrapassar 24 horas, mesmo quando nenhum lead novo for encontrado. A janela recuperável Meta permanece requisito de homologação, sem prometer retomada ilimitada.

### ADS2 — Google Ads Lead Form

Criar somente para essa origem `POST /wp-json/f3base/v1/anuncios/google`, HTTPS, sem cache e sem token/cookie de visitante. Autenticar `google_key` em tempo constante contra segredo próprio, antes de processar dados pessoais. Validar tamanho do corpo, formato, versão, identificadores e campos permitidos, preservando IDs numéricos grandes como strings. Nunca registrar a chave ou o corpo bruto em logs.

Deduplicar pela identidade canônica Google/conta/`lead_id`, com índice único, validação de formulário e hash da projeção comparável do conteúdo: retry idêntico retorna sucesso; estágio novo/atributos opcionais têm enriquecimento versionado, sem gerar nova captura; mesmo ID com conteúdo incompatível gera diagnóstico, sem sobrescrever silenciosamente o registro. Usar método `anuncio_google`; `gcl_id` pode alimentar o campo canônico `gclid`, preservando a origem nativa. Não inventar `adgroup_id`/`creative_id` quando não vierem.

Google recebe **200 e `{}` somente depois da persistência local durável**, incluindo intenção de entrega; duplicata confirmada recebe 200. Chave incorreta responde 403, erro permanente de payload 4xx, indisponibilidade recuperável de banco/capacidade 5xx [AD1]. Evitar reutilizar cegamente a quota por IP de visitante: Google pode compartilhar IP entre leads, e seu contrato não trata 4xx como repetível. Aplicar limite próprio de ingestão autenticada, com backpressure temporário 503 sem perda silenciosa.

Preservar também `asset_group_id`, `lead_stage`, `lead_submit_time` e `lead_source` quando presentes; `lead_submit_time` ISO-8601 vira instante nativo UTC, separado do horário de recepção [AD1]. Campo novo desconhecido não invalida o payload; descartar o que não é consumido conforme política documentada. `lead_source=CONVERSATIONAL_AGENT` permanece distinto de `LEAD_FORM`, sem inventar formulário/campo ausente ou apresentar conversa como formulário tradicional. Todos os IDs continuam strings. O método comercial de origem Google pode ser comum, mas o tipo nativo é explícito.

Campanha ID → nome fica em configuração; ausência usa unidade padrão, parceiro vazio e aviso. A leitura API para recuperação está incluída pelo contrato de reconciliação abaixo; enriquecimento de nomes pode usar dados fornecidos por essa operação, sem depender deles para capturar. Página/formulário do Google recebe URL e chave pela operação da conta; o Core não altera campanhas ou anúncios.

**Aceite por site antes de ativar webhook (recomendação R1):** o parecer relata respostas 429 da hospedagem antes do WordPress. Isso demonstra risco, sem provar que os servidores Google já foram bloqueados nesta rota. Executar o teste real “Enviar dados de teste” do Google Ads contra a URL final do site e conferir status 200 no retorno, linha de teste persistida e access.log quando disponível. Teste direto pelo agente não substitui esse percurso. Falta de log deixa a comprovação da camada limitada; falha/429 bloqueia o modo webhook nesse site até resolver ou selecionar reconciliação exclusiva comprovada. Um teste bem-sucedido não elimina a necessidade de recuperação periódica.

**Reconciliação incluída, sem dependência obrigatória de outro plugin.** A API Google Ads expõe `lead_form_submission_data`; a documentação de suporte informa recuperação de até 60 dias [AD4–AD5]. Acrescentar ability autenticada `f3base/anuncios-google-reconciliar`, que recebe lotes obtidos pela operação Google/GAQL ou por agente autorizado e usa a mesma ingestão local, deduplicação e fila CRM. O Core não recebe developer token/OAuth Google nem executa GAQL nesta release; o produtor externo precisa de acesso válido. A documentação entrega schema, consulta de exemplo, campos exigidos, paginação, janela e resultado por item.

A entrada contém conta/origem autorizada, janela consultada, cursor/lote, IDs e timestamps nativos, proveniência e indicação de teste quando comprovada. Deve respeitar simulação, revisão/configuração e permissões de mutação; o canal não pode importar dados de conta arbitrária nem apontar URLs externas para o servidor buscar. Limitar lote/tamanho e retornar aceitos, duplicados, eliminados, inválidos e pendentes, sem corpo pessoal na auditoria. `simular` não grava nem envia ao CRM.

Confirmar em contrato de ida/volta a equivalência entre o `id` da API e `lead_id` do webhook. Com equivalência comprovada, usar chave canônica Google + conta + ID de submissão, independente do transporte e do conjunto de campos disponível. Formulário é atributo validado; sua ausência na API não pode criar uma segunda chave. Sem correspondência comprovada, suspender o item para conciliação e não deduplicar por e-mail/horário. Mesmo ID por dois transportes complementa campos autorizados; payload parcial diferente não é automaticamente conflito. Dados incompatíveis geram revisão, sem sobrescrita silenciosa.

Marcar `capturado_via=webhook|reconciliacao_api` e preservar a origem comercial Google. Não contar uma recuperação como novo evento no navegador/CAPI, nem duplicar aviso/CRM de registro existente; tombstone impede recriação. Só avançar a janela confirmada depois de persistir todos os lotes. Recuperação parte do marco de ativação/cursor, usa sobreposição e respeita o limite de 60 dias e o marco de recibos; não importar histórico anterior por padrão nem declarar recuperável uma lacuna mais antiga.

A operação deve executar reconciliação ao menos diariamente e registrar responsável/executor, último lote completo, janela, quantidade recuperada, duplicatas, erros e lacunas. O endpoint receptor sozinho não cria uma rotina diária. Sem produtor externo validado e execução observada, indicar `reconciliacao_nao_configurada`; não anunciar proteção automática completa. Se webhook permanecer bloqueado, permitir modo `reconciliacao_exclusiva` somente com importação real homologada e cadência observada; atraso fica explícito. Não requer chamado à DreamHost nem contorno do filtro de segurança.

`is_test=true` é sempre classe de teste. Por padrão, testes ficam locais e fora dos relatórios comerciais; habilitar **modo de homologação CRM** explicitamente para os testes ponta a ponta, com `[TESTE]`, isolamento dos contatos de teste, sem resposta automática a visitante nem conversão publicitária real. O campo recebido não deve sobrepor a política global de testes e começar a criar registros comerciais sozinho.

### ADS3 — LinkedIn condicionado à aprovação

Respeitar a condição do anexo: iniciar desenvolvimento/homologação do adaptador somente após aprovação do app na Lead Sync API e acesso aos ativos. Registrar essa dependência na tela e no relatório; a recepção manual atual permanece até a aprovação.

A documentação atual **descreve webhooks de Lead Notification**, corrigindo a afirmação de que não existem. Manter consulta a cada quinze minutos como escolha de arquitetura deste plano, evitando nova rota pública; não justificar a escolha por ausência de recurso [AD2]. Paginação, timestamps, cursor, sobreposição e deduplicação seguem o modelo de ingestão, com identidade da ocorrência: um ID/URN de resposta isolado pode ser reutilizado. Para polling, confirmar `submittedAt`/identificador da ocorrência na versão homologada; para eventual webhook futuro, respeitar a chave composta documentada.

Permissões e cabeçalhos versionados serão verificados contra o app aprovado. Refresh token depende da autorização concedida à aplicação; implementar renovação quando disponível e reautorização diagnosticada quando não, sem prometer renovação perpétua. Usar `expires_in` e datas efetivamente retornadas, documentando os prazos publicados de 60 dias para acesso e 365 para refresh nas aplicações elegíveis; avisar sete dias antes de vencimentos conhecidos. Reautorização continua necessária se o acesso expirar ou for revogado [AD3]. Preservar método `anuncio_linkedin`, unidade/parceiro, campanha, conta, formulário e identificadores para cruzamento.

### ADS4 — OpenAI/ChatGPT Ads: atribuição incluída e captura nativa condicionada

**Verificação de pertinência em 29/09/2026:** a documentação oficial apresenta Advertiser API para gestão e relatórios de anúncios [OA1], além de medição de conversões [OA2/OA3]. Nas referências públicas consultadas não foi encontrado contrato de formulário nativo com recuperação de contatos, campos e entrega por API/webhook. Isso não comprova inexistência de recurso privado ou em teste; impede anunciar esse importador como disponível. O evento `lead_created` da Conversions API é informado pelo anunciante, e não demonstra uma API de download de leads [OA2].

| Frente | Decisão para 1.16.0 | Condição de conclusão |
|---|---|---|
| Identificar visitantes e leads do site provenientes de ChatGPT Ads | Incluída | Normalização, captura consentida, atribuição, relatório, documentação e mapeamento CRM testados. |
| Importar contato preenchido dentro do anúncio OpenAI | Condicionada à disponibilidade comprovada | Contrato oficial, acesso da conta e homologação de captura/deduplicação; sem isso, permanece pendente e não bloqueia a release. |
| Enviar conversões do site à OpenAI por Pixel/Conversions API | Fora deste pedido de captura | Planejar entrega específica com credencial, consentimento, fila e deduplicação quando solicitada; não instalar pixel nem ativar compartilhamento como consequência do CRM. |

**Implementação local incluída.** A 1.15.0 reconhece provedores Meta, Google e LinkedIn, mas não normaliza `openai_ads` nem captura `oppref` em `F3Base_Atribuicao`. Acrescentar o provedor e o campo ao contrato compartilhado do navegador/servidor, formulários, cliques, leitura autenticada e exportação. Reutilizar a estrutura de atribuição existente e o vínculo ao lead; não criar uma segunda cadeia de cookies ou medição paralela.

A OpenAI documenta `oppref` como referência de clique acrescentada à URL de chegada [OA3], e exige preservar seu valor original quando utilizado na Conversions API [OA2]. Para o plugin:

- Tratar `oppref` como identificador publicitário opaco. Fazer somente o parsing normal do parâmetro da URL, sem decodificação adicional, alteração de caixa, hash substitutivo ou tentativa de extrair campanha/anúncio. Não aplicar o truncamento genérico de 500 caracteres. Documentar limite defensivo próprio do campo (inicialmente 8 KiB); acima dele, omitir apenas o identificador com motivo diagnosticável, preservando a captura do formulário. Esse teto é do plugin, não um limite alegado da OpenAI.
- Coletar/persistir o identificador somente com medição e publicidade permitidas. Reutilizar prazo e remoção da atribuição existente, interromper coleta/transmissão na retirada de consentimento e não reconstruir o identificador a partir de logs. Reavaliar a permissão antes da entrega CRM. O contato comercial pode continuar sendo recebido sem esse dado.
- Guardar a referência junto ao toque em que apareceu. Reutilizar um identificador guardado não constitui novo clique nem substitui campanha atual. Se o novo toque mudar para outra origem, não herdar o `oppref` antigo para essa origem; manter primeira/última origem separadas. Seguir a separação de origem e identificadores auxiliares de C2, sem conflitos 409 causados apenas pelo enriquecimento auxiliar.
- Classificar como `openai_ads` quando houver `oppref` elegível no toque ou marcação explícita de campanha OpenAI paga: por exemplo, `utm_source=openai`, `utm_medium=paid` e `utm_source_platform=openai_ads`. Documentar aliases aceitos. Parâmetros são sinais declarados na URL, não prova antifraude de compra de mídia. Sinais conflitantes ficam diagnosticados, sem escolher outra plataforma silenciosamente.
- Visita com referência de host exato `chatgpt.com` (incluindo `www.chatgpt.com`) ou `utm_source=chatgpt` sem sinal publicitário fica como origem ChatGPT não confirmada como paga. Não converter acesso de `GPTBot`, `OAI-SearchBot`, `ChatGPT-User`, `OAI-AdsBot` ou sessão de agente/teste em anúncio. `OAI-AdsBot` é verificação de anúncio e não representa clique humano nem toque de aquisição. M1 continua medindo requisições de agentes separadamente da aquisição comercial.
- Preservar IDs de conta, campanha, grupo e anúncio pelas convenções existentes: `f3_ads_account_id`, `utm_id`, `f3_ads_group_id` e `utm_content` com `f3_ads_v=1`, além dos nomes quando fornecidos. O `oppref` não substitui esses IDs. Usar as macros oficialmente documentadas `{campaign_id}`, `{ad_group_id}`, `{ad_id}` e `{ad_account_id}` [OA4]. Documentar a configuração de parâmetros de landing page e sua precedência (URL do anúncio → anúncio → grupo → campanha), sem editar campanhas nesta release. Macro que chega sem expansão é erro de configuração, não ID válido. Sem IDs, mostrar campanha/anúncio indisponíveis, sem deduzi-los de nomes, custos agregados ou referência de clique.
- Acrescentar `oppref` à lista canônica de parâmetros de rastreamento do Core, a `configuracao_requerida` de cache e à preservação dos redirects gerenciados. O aceite confere redirects reais e, depois de aquecido o cache, um mesmo objeto/HIT para URLs que diferem somente por `oppref`, com captura correta no navegador e sem identificador no HTML compartilhado. A ausência da configuração necessária gera divergência diagnosticada; não afirmar que todo clique obrigatoriamente produz arquivo/MISS sem observar o modo de cache. Documentar o patch em `wp-cache-config.php` para a operação da frota, preservando os demais parâmetros; o Core não assume a responsabilidade do implantador nem altera esse arquivo de terceiro silenciosamente. Captura usa o código compartilhado existente, sem SDK publicitário adicional nem consulta externa no carregamento da página.

Modelo documentado de parâmetros de landing page OpenAI, a ser aplicado pelo operador da mídia:

```text
utm_source=openai&utm_medium=paid&utm_source_platform=openai_ads&utm_id={campaign_id}&f3_ads_group_id={ad_group_id}&utm_content={ad_id}&f3_ads_account_id={ad_account_id}&f3_ads_v=1
```

Adicionar `utm_campaign` com o nome comercial configurado quando desejado; as macros acima preenchem IDs e não autorizam inventar macro de nome. `oppref` chega pelo mecanismo da plataforma, preservado no clique. Testar precedência para parâmetros já presentes na URL e rejeitar marcadores literais `{...}` como IDs.

**Integração comercial e relatórios.** Na conta fornecida, canal 83 será aplicado ao toque selecionado apenas quando classificado como OpenAI Ads. Um formulário recebido no site mantém ponto de conversão 53, ou 54 no regime de formulário WhatsApp; ponto 52 é reservado a captura comprovadamente nativa da plataforma. Manter origem, plataforma, evidência usada, qualidade, modelo, IDs e vínculo ao registro disponíveis para cruzamento com dados de mídia obtidos pelos agentes. Relatórios devem distinguir “ChatGPT Ads”, “ChatGPT — origem sem confirmação de anúncio” e agentes/testes, respeitando os filtros existentes.

O `oppref` permanece no contexto local restrito; não será copiado por padrão para nota do CRM ou URL de acesso ao registro. Enviar ao Pipedrive o canal, os IDs de campanha/anúncio disponíveis e o contexto comercial consentido já definido em CRM1. Acesso autenticado ao identificador, quando necessário para análise autorizada, segue as permissões de dados publicitários. Não adicionar à chamada comum do Pipedrive uma dependência de API OpenAI.

**Critério para incorporar o importador nativo.** Revalidar a documentação no fechamento da implementação. Para habilitá-lo nesta release, exigir endpoint ou webhook oficial de formulários/leads, esquema dos campos, identificador de formulário e submissão/ocorrência, autenticação e permissões, limites, paginação ou política de retries e acesso de teste da conta. Usar a mesma ingestão local, fila CRM, proprietário da origem, tombstone, exclusão de testes e proteção contra reimportação de ADS1–ADS3. Sem essas evidências, mostrar na documentação “captura nativa pendente de contrato/acesso confirmado”; não criar polling fictício, rota pública sem contrato ou switch que prometa uma integração funcional.

**Aceite ADS4:** testar clique com `oppref` e IDs, somente `oppref`, marcação paga sem identificador, referência ChatGPT sem marcação paga, sinais conflitantes, ausência/retirada de consentimento, retorno em outro dia, mudança de campanha/plataforma e valor acima do limite. Confirmar classificação CRM 83 apenas nos casos elegíveis, ponto de conversão correto, separação dos testes/agentes, preservação do valor aceito, ausência de vazamento por cache e inexistência de dependência externa no envio do formulário. Fixtures validam o contrato local; a captura nativa só recebe aceite após teste real do contrato e acesso aprovados.

### Operação, documentação e execução sem tráfego

Detalhe/lista de leads mostram estado CRM, destino/link, entrega parcial, último erro seguro e ação de reenvio com simulação/revisão. A fila é paginada, sem nome/e-mail/corpo. Resumo de pendências inclui falha definitiva, com frequência limitada; não mandar um novo e-mail a cada retry. Preservar correção C4 nos assuntos.

Abilities previstas: `f3base/pipedrive-verificar` (somente leitura), `f3base/pipedrive-fila-ler`, `f3base/pipedrive-reenviar`, `f3base/anuncios-verificar` e `f3base/anuncios-consultar-agora`. A última é uma operação com efeitos: pode importar contatos e enfileirar entregas, exige permissão e oferece simulação. Cadastro de IDs, tokens e regras usa o contrato de opções existente. Todas aparecem no registro único de módulos e em `como-usar`/saúde.

Publicar atraso real dos últimos sete dias: CRM, da captura à primeira tentativa e à conclusão; consulta Meta/LinkedIn, do horário agendado ao início; Google, do timestamp nativo à ingestão e da janela prevista à reconciliação completa. p50/p95 são calculados sobre amostras observadas, com método declarado (`nearest-rank`), unidade, N, cobertura e exclusão identificada de testes. Manter amostras técnicas limitadas por sete dias, sem contato. Informar separadamente idade do item mais antigo, quantidade ainda pendente, falhas e ausência de ciclos: percentis só de sucessos ocultariam atrasos e falhas. Sem amostras, mostrar indisponível, nunca zero.

O anexo exige executor de cron a cada cinco minutos. Fornecer instrução compatível com executor já disponível, WP-CLI ou operação autenticada existente, e medir último início/sucesso, atraso, item mais antigo e próxima execução. Não instalar cron do servidor nem depender de chamado à DreamHost. Sem executor observado, o plugin conserva a fila e mostra degradação; não promete atraso máximo de cinco minutos só por usar WP-Cron. Os intervalos das origens e o executor são diferentes da opção de cadência de configuração do item 64.

Documentação instalada: `docs/PIPEDRIVE.md`, `docs/ORIGENS-ANUNCIOS.md`, contrato das abilities, dicionário das tabelas/estados, mapa de dados para campos CRM, convenções de campanhas, exemplos SQL de cruzamento e recuperação de falhas. Distinguir contato capturado, entrega CRM, interação anexada e oportunidade comercial; uma pessoa com três envios pode produzir três registros locais e um único lead CRM. Sem sincronização reversa, o site não pode apresentar venda ganha/perdida no CRM como dado conhecido.

### Retenção e eliminação remota

Retenção automática do site continua independente da retenção comercial no Pipedrive, conforme o anexo; expirar localmente não autoriza apagar um contato comercial remoto. Antes de apagar dados locais, preservar no journal de acesso restrito somente o vínculo técnico necessário à eliminação pendente e sua base/motivo. Revisar a retenção desse vínculo na política instalada, sem guardar payload pessoal indefinidamente.

Pedido explícito de eliminação cancela entregas ainda não iniciadas e gera tarefa própria de limpeza para objetos já entregues ou parcialmente criados. Leases, verificação antes de cada escrita e reconciliação cobrem exclusão concorrente com envio. A etapa local e a remota têm estados próprios: a falha do CRM não pode ser relatada como eliminação remota concluída. Retries nativos encontram o tombstone e não recriam o lead.

**Corrigir a regra de exclusão do anexo:** “pessoa sem negócio” é insuficiente para apagar. Uma pessoa pode ser preexistente ou compartilhar outros leads, atividades e histórico. Excluir automaticamente apenas objetos comprovadamente criados por esta integração para o registro e sem vínculos comerciais independentes, depois de reler o estado remoto. Remover notas/atividades próprias quando o destino foi reaproveitado; não excluir o lead/negócio compartilhado inteiro. Pessoa, organização ou negócio preexistente, convertido, alterado comercialmente ou compartilhado exige revisão humana registrada. A autorização de apagar dados do contato local não autoriza destruição automática de histórico alheio.

O caso 14 do anexo passa a ter duas variantes: lead/pessoa de teste exclusivos são eliminados e a operação é comprovada; entidades compartilhadas ficam preservadas com pendência explícita e limpeza dos artefatos próprios quando segura. Manter identidade e marcadores técnicos suficientes para detectar objetos criados antes de um timeout, sem depender de IDs que já foram apagados do registro local.

### Aceite da integração

Manter os 15 casos do anexo e registrá-los como **CRM-A01…CRM-A15** em `docs/VALIDACAO.md`, com ambiente, horário, conta, versão, evidência e limpeza. Adaptações: A10 sinaliza atribuição não observada em vez de comprovar orgânico; A12 exige modo de homologação CRM; A14 inclui objeto compartilhado; A15 usa reset real verificado. Nenhum caso pode ser marcado aprovado por existir apenas como teste unitário.

Acrescentar:

- Atualização 1.15.0/instalação nova; módulo desligado; formulário excluído; nenhum envio retroativo; captura e e-mail continuam funcionando com CRM indisponível.
- Falha entre captura e fila; dois workers; lease vencido; sucesso remoto com resposta perdida; falha ao salvar checkpoint; nota concluída/tarefa pendente; reenvio depois de entrega.
- Dois sites usando a conta, contato ambíguo, múltiplos negócios/leads abertos e origem nativa configurada em duplicidade; limites de coordenação explicitados, sem fusão automática.
- Conta sem `job_title`, campo/opção removido, seleção múltipla, campanha desconhecida, permissão insuficiente e troca de conta/token.
- Cookies publicitários entre toques, retorno em outro dia, retirada de consentimento e jornada sem vínculo; não preencher dados ausentes por inferência.
- Meta com múltiplas páginas, mesmo timestamp em vários leads, queda no meio do lote e atraso maior que a sobreposição; Google com retry/conflito, segredo errado, payload grande e falha recuperável de banco.
- Testes recebidos de plataforma mantidos fora da medição comercial; CAPI não é acionada por ingestão nativa como se houvesse nova conversão de formulário do site.
- Exclusão antes, durante e depois da entrega; destino compartilhado e tombstone impedindo reimportação; orçamento ausente/desatualizado, 429 de rajada e 429 diário.

Homologação em três níveis: (1) bancada com transporte controlado para falhas/timeout/429 sem esgotar API real; (2) Site-Teste com conta sandbox/developer Pipedrive [PD10], campos equivalentes e dados sintéticos, executando CRM-A01…A15 e contratos; (3) teste final limitado no Site-Teste contra a conta comercial informada, validando identidade, permissões, tipos/opções e uma entrega completa. A sandbox tem IDs próprios e pode ter capacidades/limites diferentes do Lite comercial; não copiar IDs nem tratar seu resultado como prova dos limites da conta real. Criar o esquema de teste pela preparação do ambiente, sem acrescentar gestão de campos ao produto.

Inventariar IDs de teste e eliminar apenas objetos sintéticos exclusivos após verificação. Não testar em korvena.net.br nem usar contatos reais para disparos. A conta sandbox e credenciais ainda são pré-requisitos externos, sem criação presumida nesta análise. Ausência de acesso deixa homologação pendente; não transferir automaticamente ensaios de falha/exclusão para a conta comercial. Nenhum registro externo foi criado ou apagado nesta revisão.

### Escolhas e dependências remanescentes

- **WhatsApp flutuante:** preservar link direto como padrão e comportamento atual. Formulários no regime `whatsapp` entram no CRM quando preenchidos. Trocar o flutuante por formulário é mudança de conversão ainda dependente do dono; não condiciona a entrega CRM dos formulários existentes.
- **Meta:** obter as permissões/ativos exigidos pelo fluxo de recuperação, inclusive `ads_management` quando requerido, com concessão pelo administrador da conta. O mapa por campanha é contingência apenas para enriquecimento, sem dispensar acesso obrigatório ao lead. O módulo não ganhará operações de alteração de anúncios.
- **LinkedIn:** aprovação e acesso do app são dependência externa; não presumir concessão ou refresh token disponível.
- **OpenAI:** a atribuição de cliques não exige token OpenAI. Captura de formulários nativos depende de contrato e acesso ainda não confirmados; não é uma decisão comercial bloqueante para o dono. Publicação de campanhas e concessão de acesso à conta de anúncios continuam na operação de mídia.
- **Google:** indicar produtor e executor da reconciliação diária, com acesso Ads API e evidência de entrega. O Core fornece a ingestão autenticada e o diagnóstico, sem assumir que um agente executará a tarefa espontaneamente.
- **Sandbox Pipedrive:** disponibilizar conta e acesso para homologação isolada; não é necessária nova decisão de arquitetura.
- **Cadência do item 64:** continua pendente, sem bloquear o contrato ou os intervalos operacionais próprios de CRM/anúncios.

Continuam fora desta release: sincronização bidirecional de estados CRM/site, exportação de leads anteriores à ativação, administração de campos/funis/etiquetas do Pipedrive, webhook genérico de saída, redirecionamento de confirmação por URL e upload automático de anexos ao CRM. A criação da rota nativa Google e o envio direto ao Pipedrive estão incluídos.

## 9. D1 — documentação integrada e contrato para agentes

Usar metadados de ajuda compartilhados por tela, contrato autenticado e geração de documentação. A mesma opção deve ter o mesmo significado nas três superfícies. A matriz gerada e o teste de cobertura U2 devem incluir campos aninhados, enums dinâmicos e segredos sem valores de exemplo. Evitar uma cópia de textos exclusiva da UI, sem acesso pelos agentes.

Atualizar `docs/CONFIGURACAO.md`, referência do catálogo, contratos, instruções para agentes, perfil de navegação, índice e histórico de mudanças. A documentação instalada deve incluir:

- Menus clássicos versus blocos; exemplo explícito de referência ao menu 92, identificado como ilustrativo e dependente do cadastro do site.
- Leitura, simulação, escrita conjunta e releitura do par tipo/ID, com revisão.
- Códigos de erro e distinção entre validade, associação e comprovação de uso.
- Mapeamento de campos para telas e sub-abas; defaults e significado de ausência/vazio.
- Responsabilidade do plugin e responsabilidade do tema.
- Como consultar tudo pela documentação autenticada já disponível.
- Área Agentes e buscadores, dicionário dos novos agregados, métricas, regras de identificação, cobertura, retenção, exclusões e exemplos de consulta/SQL/CSV. Diferenciar requisição observada de indexação e uso em IA.
- Regras de destino e superfície de CTA, opção de marcação por telefone e inventário de destinos rejeitados; origem de campanha versus identificadores publicitários; saúde de clique e formulário.
- Composição e prévia do assunto de e-mail, marcação de teste e significado independente de `{{site}}`/`{{formulario}}`, incluindo fallback para notificações anteriores à atualização.
- Proteção de autoria pública, localização/recuperação da reserva de robots, reparação e reconfirmação de procedência, contrato de cadência e motivos de invalidação de evidências.
- Ofertas com múltiplos períodos, validade/renovação/purga, composição visual do consentimento e estados temporários da publicação Markdown.
- Referência cruzada dos itens do backlog para alterações, testes executados e pendências de aceite. O relatório entregue conservará os números 17, 36–38, 41–42, 45, 50, 52, 54 e 59–70 conforme esta matriz, sem renumerar os pedidos.
- Pipedrive e origens nativas: configuração, dicionário de campos/tabelas, mapeamentos comerciais, qualidade de atribuição, jornada, fila, reconciliação, testes e eliminação. Distinguir webhook Google de entrada do webhook genérico de saída ainda adiado e identificar os estados condicionados do LinkedIn e da captura nativa OpenAI. Documentar `openai_ads`, `oppref`, IDs de anúncios, consentimento, classificação paga/não confirmada, cobertura e consultas para cruzar dados sem confundir importação de contatos com envio de conversões.

Os documentos continuam dentro do instalador, disponíveis por arquivo e canal autenticado. A nova ajuda não deve expor segredos nem tornar pública a documentação que hoje é protegida.

### Contrato 4.0.0 e perfil piso-padrao-3.2 (R14)

A fonte 1.15.0 declara contrato 3.0.0 e perfil `piso-padrao-3.1`. Publicar **contrato 4.0.0** porque `f3base_nav_id` passa de entrada editável a atributo derivado. A versão do contrato é distinta do identificador da ability `config-core-contrato-v1`; manter/alterar identificadores somente conforme o protocolo publicado, sem inventar uma versão de rota para refletir automaticamente o número semântico.

Entregar **`piso-padrao-3.2`**, com metadados compatíveis, schema e mapa de migração. P66 passa a validar `f3base_navegacao` e aceita `tipo: tema, id: 0`, menu clássico ou bloco válido. O perfil não força uma referência concreta a voltar ao tema. A atualização não executa aplicação automática de piso nem amplia lista explícita de opções operáveis.

Inventariar toda chave nova/alterada pelo catálogo e separar configuração, segredo, estado e atributo derivado. CRM e origens `f3base_anuncios_*` são decisões por site: não são exigidos como ligados nem preenchidos para conformidade do piso, não recebem contas/tokens/IDs globais e defaults das integrações são desligados. Segredos ficam fora de qualquer perfil. Preservar a decisão de consentimento por site. A ausência desses módulos opcionais é `nao_aplicavel` no piso; a validação de um módulo explicitamente ativo continua obrigatória em sua saúde.

A lista de “nove options” do parecer descreve o escopo previsto, mas o teste deve conferir o catálogo efetivo e detectar chave sem classificação, em vez de depender de contagem fixa. Gerar documentação de escrita de segredos, navegação canônica/projeção, novas tabelas, abilities, permissões, revisão e simulação. Documentar mudanças propostas ao Padrão da frota (perfil, tabelas, rastreamento, CTAs e navegação) como orientação de entrega; esta tarefa não altera documentos externos nem temas.

## 10. Atualização, escopo e ordem de implementação

Base de desenvolvimento e de atualização: **1.15.0**, conforme o novo relatório que informa essa versão nos 14 sites. Caminhos de aceite desta release: **instalação nova e atualização da 1.15.0**. Essa informação substitui a premissa anterior de frota na 1.14.0; não foi feita nova leitura remota para confirmá-la. Não acrescentar suporte nem matriz de compatibilidade com versões anteriores.

Não reexecutar toda a sequência histórica de releases. Preservar opções, listas vazias, false, zero, dados de leads, política e preferências explícitas. A adição do tipo de navegação não autoriza trocar o ID existente. Executar apenas migrações desta release, incluindo navegação canônica/projeção, migração cifrada do token CAPI, reserva de robots, colunas diárias/agregado horário, estrutura/estado de entrega CRM e reparação comprovada de procedência da 1.15.0. Cada uma terá trava, checkpoint, retomada e resultado consultável; a recuperação não deve substituir toda a base por um snapshot antigo. Atualizar não ativa CRM, não escolhe conta e não enfileira histórico anterior.

Ordem sugerida:

1. Criar fixtures dos defeitos de captura e corrigir C1/C2/C3/C4; implementar S2/segredos e extrair F1/primitivas de fila com regressão CAPI antes de CRM1. Preservar método, atribuição, idempotência, consentimento e a composição dos e-mails.
2. Corrigir autoria/Yoast e reserva privada P1/P2, com testes de acesso público e restauração.
3. Implementar N1, procedência E2, contrato E3 e ajustes E4; executar instalação nova e atualização com dados equivalentes aos casos relatados.
4. Corrigir seções U1 e integrar seletores, ajudas U2/D1 e diagnósticos E1, com teste de abrir, editar, salvar e retornar pelo formulário real.
5. Implementar ofertas S1, consentimento V1, publicação L1 e textos/limpeza D2.
6. Implementar extremos no diário, tabela horária sem caminho, grupos HTTP e catálogo/área M1, preservando histórico, cobertura, retenção e política de coleta.
7. Homologar primeiro contratos Pipedrive e seleção múltipla na sandbox; implementar CRM1 sobre captura corrigida, S2 e F1, com loopback e latência real. Implementar a rota ADS2 cedo para testar o percurso Google no Site-Teste e a reconciliação antes da ativação comercial; completar ADS1/Meta e ADS4/OpenAI. ADS3/LinkedIn só com aprovação e acesso; importador nativo OpenAI só com contrato oficial e homologação, conforme seção 8.
8. Executar M2, matriz geral e CRM-A01…CRM-A15 com as condições descritas; consolidar relatório por número de backlog e frente, empacotar e entregar todos os arquivos. Etapas internas não representam releases intermediárias.

Tema, implantador, webhook genérico de saída, confirmação por URL e redesenho amplo dos relatórios comerciais ficam fora. Estados de entrega CRM, origens nativas, serviço no Perfil da demanda e documentação de cruzamento fazem parte de CRM1/ADS1–ADS4 nos limites explicitados na seção 8. Ajustes nos contratos de integração com temas são responsabilidade do plugin; editar ou retirar compensações do tema é responsabilidade dos projetos. A ampliação dos dados de acessos descrita em M1 faz parte desta release. Verificação externa de identidade de robôs, monitoramento de citações em IA e automação de bloqueio por comportamento continuam fora. Também não cabe liberar qualquer inteiro como navegação; isso manteria a ambiguidade que o novo contrato precisa eliminar.

### Base suportada e limite de recuperação

Decisão final do dono em 29/09: a 1.16.0 será instalada do zero ou atualizada da 1.15.0. Não implementar downgrade, retorno operacional à 1.15.0 nem reserva de dados para versões anteriores. Preservar apenas retomada e consistência da atualização atual. Adaptadores de leitura usados pelos temas atuais continuam parte do contrato de navegação.

## 11. Critérios de aceite

| Cenário | Resultado exigido |
|---|---|
| Menu clássico 92 existente | Selecionado por nome, salvo com tipo clássico e reconhecido por UI, MCP, diagnóstico e perfil. Nenhum bloco criado. |
| Termo 92 e post 92 coexistem | O tipo escolhido determina o objeto; não há resolução silenciosa por tentativa. |
| Bloco publicado e bloco órfão 4 | Existência validada separadamente do uso. O órfão não é apresentado como solução comprovada para o cabeçalho. |
| Bloco em rascunho, revisão ou lixeira | Recusa específica; valor anterior preservado. |
| Menu excluído ou sem itens | Excluído fica inválido; menu existente vazio recebe diagnóstico próprio, sem inventar itens ou prova de uso. |
| Menu associado a localização do tema | Associação reportada com seu nome real; não promove automaticamente a confirmação de cabeçalho. |
| Menu usado diretamente sem localização | Referência pode ser válida; uso permanece limitado à evidência disponível, sem exigir que o tema adote `primary`. |
| Zero, valor ausente e ID antigo inválido | Convenções preservadas; nenhuma substituição automática por 4, 92 ou outro menu. |
| Troca de tema, remoção de menu ou alteração de template | Diagnóstico é atualizado/invalida evidência anterior, sem alterar a referência por conta própria. |
| Duas escritas simultâneas ou interrupção ao salvar navegação | Objeto único e projeção coerentes; revisão conflitante recusada; nenhuma segunda option gravada como espelho. |
| Política restrita e operador sem permissão | UI e canal respeitam a restrição; a migração não amplia a lista explícita. |
| Abrir as seis sub-abas pelos links reais | Cada URL abre a seção correta e indica a aba ativa. |
| Salvar, errar validação ou gerar conflito em cada seção | Retorno à mesma seção; dados e erro recuperados; outras seções não mudam. |
| POST com seção ausente/inválida | Recusa compreensível, sem gravação na seção padrão. |
| Desligado, zero, lista vazia e campo herdado | Semânticas preservadas após salvar e atualizar; ajuda corresponde ao resultado real. |
| Cobertura de ajudas | Todas as folhas editáveis têm descrição específica e exemplo ou orientação de obtenção; nenhuma depende apenas do texto genérico por tipo. |
| Tela versus contrato versus documentos | Valores permitidos, padrões, dependências e explicações concordam, inclusive em campos aninhados. |
| Acessibilidade e ausência de JavaScript | Navegar, selecionar e salvar continua possível; erros e foco são identificáveis. |
| Instalação nova e atualização da 1.15.0 | Mesmo contrato final; escolhas explícitas preservadas; nenhum arquivo de tema alterado; migrações novas retomáveis. |
| Custo no visitante em N1/U1/U2/M1 | Nenhum novo script público nem consulta remota por visita para essas funcionalidades; listas e ajuda carregadas somente na administração/canal. CRM e importação de anúncios executam no servidor em segundo plano, sem chamada ao Pipedrive na resposta do formulário. |
| Encontrar a análise de robôs | Agentes e buscadores aparece diretamente em Medição; filtros são preservados entre as três análises e os links antigos de Acessos continuam funcionando. |
| Nomes dos principais agentes | OpenAI/ChatGPT, Anthropic/Claude e Google/Gemini são encontráveis; famílias adicionais e aliases documentados são reconhecidos sem perder a assinatura observada. |
| Gemini e tokens de controle | Gemini Notebook identificado; Google-Agent não prova Gemini e CloudVertexBot fica como coleta Vertex. Googlebot/GoogleOther não viram visitas do Gemini; Google-Extended não vira requisição. |
| Assinaturas e estados sem dados | Variantes documentadas de versão são reconhecidas; marcas desconhecidas/legadas não ganham identidade confirmada. Ausência de registros, cobertura ausente e produto não distinguível têm estados diferentes. |
| Família e caminho no histórico existente | Totais por família/dia conferem com o agregado original; acesso antigo sem timestamp não recebe horário ou intervalo fictício. |
| Frequência diária e horários | Dias ativos 1, 3, 8 produzem intervalos 2 e 5 e mediana 3,5 dias com cobertura completa. Duas requisições no mesmo dia às 10:00/10:10 produzem média dentro do dia de 600 s; uma única, indisponível. |
| Rajadas, simultaneidade e filtros | Contagens no mesmo segundo são mantidas; combinar contagens/extremos sem média de médias. Filtros por caminho/método/status exato valem no diário; histograma sem essas dimensões informa granularidade indisponível. |
| Lacuna, log ausente ou formato inválido | Pares de dias que atravessam lacuna são descartados com contagem visível; não são unidos a outros dias como se houvesse cobertura completa. |
| Atualização, retomada e rotação dos logs | Reexecutar importação ou retomar após falha não duplica contagens; fotografia de hoje e histórico fechado não se sobrepõem. |
| Dados antigos, fuso e retenção | Série diária anterior preservada; detalhe novo tem início identificável; conversão de fuso não perde/duplica instantes. Expiração do detalhe não apaga o agregado diário ainda elegível. |
| Coleta desligada e exclusões explícitas | Atualização preserva desligamento, listas vazias e exclusões. Reprocessamento retroativo exige ação explícita. |
| Testes da equipe e agentes externos | IA/buscadores não são excluídos como testes; falta de marcador nos logs é declarada. Não há exclusão por correlação de IP e horário. |
| UI, CSV e MCP de agentes | Mesmos filtros e dados resultam nos mesmos totais e métricas; paginação não omite nem repete linhas e limites são informados. |
| Minimização e escala | Novos agregados não contêm IP, UA bruto, query, cookie ou corpo. Ensaio com logs volumosos comprova trabalho limitado por lote e consulta paginada sem varredura pública por visita. |
| Grupos HTTP e origem do bloqueio | 403/429 separados de atendido/revalidado; fração tem denominador; status sozinho não confirma camada e log inacessível não vira zero. |
| OAI-AdsBot e aquisição | Classificado como verificação de anúncio; nenhuma sessão/toque comercial criado por sua presença no log. |
| Contrato e piso | Contrato 4.0.0/perfil 3.2 consistentes; segredo fora do perfil; tema com zero conforme; módulos opcionais desligados não geram divergência do piso. |
| Segredos e migração CAPI | Banco contém envelope autenticado com autoload desligado; consumidores internos funcionam; saídas controladas não revelam valor, inclusive erros e simulação. |
| Salts alteradas, cifra corrompida ou Sodium ausente | Diagnóstico específico e envio suspenso sem gastar tentativa; captura local preservada; nenhum fallback em texto aberto. |
| Whitelist Pipedrive e seleção múltipla | Rotas fora da lista e v1 descontinuados falham no teste; exceções de metadados documentadas; opções de Serviço conferem na releitura. |
| Site sem novas visitas por 30 minutos | Captura solicita loopback, fila mede início/fim; bloqueio de loopback fica visível e trabalho permanece pendente. Não declarar prazo garantido por haver agenda. |
| Google Ads no percurso real | Teste da plataforma produz 200 e linha `is_test`; 429/erro impede ativar webhook até resolver ou homologar reconciliação exclusiva. |
| Google via API e webhook | Mesmo ID comprovado produz um registro; recuperação ausente é identificada, tombstone preservado, nenhum evento/aviso/CRM duplicado. Conta errada ou janela sem cobertura é recusada/diagnosticada. |
| Reconciliação sem executor externo | Saúde informa ausência/atraso; ability receptora não é apresentada como coleta diária automática. |
| Cliques anteriores ao formulário | Nota reúne cliques vinculados e consentidos, horário e destino sanitizado, sem inventar identidade de clique isolado. |
| Cache/redirect com oppref e macros | IDs expandidos capturados; placeholder literal diagnosticado; oppref preservado; HIT compartilhado aquecido sem valor de visitante no HTML. |
| Motor de filas compartilhado | CAPI mantém seu contrato; CRM conserva checkpoints na incerteza; retenção de concluídos não apaga limpeza pendente nem quebra deduplicação. |
| Recuperação para 1.15.0 | Webhook suspenso antes, navegação adaptada, CAPI cifrada não enviada como token bruto, captura local e tabelas preservadas; perda funcional conhecida documentada. |

Os aceites das seções 7 e 8 integram esta matriz e devem constar individualmente do relatório de entrega. Para o item 42, acrescentar fixtures com `ref` injetado depois da leitura do template, declaração de suporte sem observação pública, navegação inline e referências inválidas presentes em `avisos[]`. Para CRM1, registrar cada caso CRM-A01…CRM-A15, testes adicionais e dependências externas; estado não executado/bloqueado não equivale a aprovado.

Homologar em bancada WordPress com tema clássico e tema de blocos. Seguir depois no Site-Teste dentro do escopo autorizado para a implementação. A validação específica do menu 92 será feita no fator3 pela frota; a existência do termo não foi inspecionada nesta revisão. **Não testar em korvena.net.br:** o piloto e o aceite de sete dias do item 52 continuam sob responsabilidade do dono. As provas dos demais sites mencionados no relatório também não serão substituídas por resultados de fixtures.

## 12. Entrega e decisões

Entregar instalador versionado, fontes e testes, relatório de validação, manifesto e hashes, além da documentação dentro do plugin. O relatório deve separar testes locais, homologação em site e pendências externas; presença de um teste no repositório não equivale a execução bem-sucedida.

O número 1.16.0 continua proposto para a próxima release. Pipedrive entra pelo pedido de 29/09; webhook genérico de saída e confirmação por URL permanecem adiados. É possível iniciar a implementação de CRM1 preservando WhatsApp flutuante direto e com contingência de mapeamento de campanhas Meta; eventual mudança do botão e concessão de permissões Meta são escolhas da operação descritas na seção 8. A aprovação LinkedIn é dependência externa específica. A atribuição OpenAI entra; a captura de formulários nativos OpenAI depende de contrato e acesso confirmados. Credenciais/executor são necessários à homologação real das integrações externas. Não há credencial ou aprovação presumida neste plano.

A escolha operacional da cadência da frota, mencionada no item 64, ainda depende do dono; a versão preservará o valor existente e poderá corrigir o contrato sem essa decisão. A marcação automática por destino começa desligada e `llms.full` passa a true apenas para instalação nova/chave ausente, conforme o padrão relatado; preferências explícitas são preservadas.

Os itens 50 e 52 permanecerão abertos como aceite externo até haver evidência da frota. A entrega deve identificar separadamente “implementado”, “validado em bancada”, “validado no Site-Teste”, “aceito em produção” e “bloqueado por acesso externo”. Nesta revisão foi alterado apenas o plano; não há instalador 1.16.0 gerado, correção implantada ou envio de lead ao CRM.

## 13. Parecer de 29/09 — decisão sobre as recomendações

Fonte: **“Recomendações técnicas — plano do site-core 1.16.0.md”**, enviada pelo dono em 29/09, referente à revisão 5. A análise desta revisão confrontou o arquivo com a fonte local 1.15.0 e referências oficiais. As leituras remotas e observações da frota descritas no parecer continuam evidências relatadas por seu autor; não foram repetidas nesta tarefa. Os documentos externos do Padrão são considerados nos trechos reproduzidos no parecer, sem alegar nova leitura integral.

**Resultado:** incorporar 15 recomendações, com os ajustes abaixo; não adotar a execução pelo agente do piloto R15, preservando o aceite pelo dono. A matriz explicita os limites para impedir que uma melhoria de arquitetura seja interpretada como garantia externa não demonstrada.

| Recomendação | Decisão | Incorporação e justificativa |
|---|---|---|
| R1 — filtro da hospedagem/Google | Incorporar com ajuste | Teste real por site antes do webhook e ingestão de reconciliação pela API. Fonte externa/executor ficam explícitos; 429 genérico da hospedagem demonstra risco, não bloqueio Google já comprovado. Chave entre API/webhook precisa de teste de equivalência. |
| R2 — Pipedrive v2 | Incorporar com ajuste | V2 obrigatório nos recursos descontinuados e whitelist por método/rota. As exceções v1 também incluem leituras de usuários, etiquetas e tipos de atividade ainda documentadas; restringir a três rotas impediria a configuração prevista. |
| R3 — cifra | Incorporar com ajuste | Serviço cifrado, sem autoload, migração CAPI e ocultação de segredos nas saídas. Não expor sufixo/tamanho. Proteção de banco isolado; acesso às salts/PHP e backups completos permanecem fora dessa garantia. Recuperação de salts e versão anterior foi adicionada. |
| R4 — executor | Incorporar com ajuste | Disparo não bloqueante após captura, agenda/execução autenticada, atraso observado p50/p95 e pendências. Loopback não garante execução e não substitui executor para polling sem tráfego. Não copiar envio CRM síncrono para shutdown. |
| R5 — navegação atômica | Incorporar com ajuste | `f3base_navegacao` única com revisão; `f3base_nav_id` é projeção calculada de leitura. Espelho persistido recriaria a necessidade de duas gravações. Zero/tema é válido e conforme. |
| R6 — servido/bloqueado | Incorporar com ajuste | Grupos HTTP separados, fração bloqueada e cobertura. `atendido/revalidado` é rótulo mais preciso para 2xx/304; status isolado não comprova leitura do corpo nem camada que bloqueou. |
| R7 — catálogo | Incorporar com ajuste | As quatro famílias entram; Gemini Notebook é distinguível. Google-Agent representa agentes na infraestrutura Google, sem prova de Gemini; CloudVertexBot indica coleta Vertex. Claude-User não separa equipe/visitante. |
| R8 — frequência e armazenamento | Incorporar com ajuste | Diário recebe extremos; mediana de intervalos entre dias ativos; horário sem caminho. A média anterior é matematicamente exata para a sequência observada, mas pouco representativa de retorno típico. Mediana diária continua sujeita a lacunas, fuso e granularidade; estimativa de 86 mil linhas não é teto sem contar classes. |
| R9 — OpenAI/macros/cache | Incorporar | Macros oficiais confirmadas e modelo de URL incluído; oppref nas exigências de cache e preservação de redirects. Patch de terceiro documentado para operação; nenhuma gestão de campanha ou alteração de implantador. |
| R10 — Meta | Incorporar com ressalva de verificação | Requisitos de permissões e Leads Access Manager entram na ativação; mapa por campanha não substitui permissão de recuperação. `platform` opcional, superfície desconhecida honesta e alerta de atraso >24 h. Página completa indisponível nesta consulta: versão Graph/token exigem homologação. |
| R11 — formatos e limites | Incorporar com ajuste | Seleção múltipla com criação/releitura em sandbox; somente headers documentados e unidades corretas. `x-daily-requests-left` não equivale a tokens diários disponíveis. |
| R12 — sandbox | Incorporar | Falhas simuladas e contratos em ambiente isolado; teste final mínimo no Lite comercial. A sandbox não comprova todas as capacidades/limites da conta comercial e seu acesso não é presumido. |
| R13 — cliques/jornada e concorrência | Incorporar com ajuste | Cliques vinculados/consentidos antes do formulário tornam-se aceite da nota. Rebusca imediata e rechecagem limitada detectam candidatos; não garantem unicidade global entre sites nem autorizam fusão. |
| R14 — contrato/piso | Incorporar | Contrato 4.0.0, piso-padrao-3.2, módulos por site, segredos fora do piso e orientação de atualização do Padrão. Acesso `todas` não transforma campo derivado em editável. |
| R15 — piloto pelo agente em korvena.net.br | Não adotar nessa forma | Conflita com a instrução direta do dono de testar ele próprio após a entrega. Fornecer checklist de REST/coleta com integrações desligadas e registrar o aceite externo; Site-Teste continua sendo o ambiente de homologação executável. |
| R16 — reaproveitar fila | Incorporar com limite | Compartilhar primitivas com adaptadores e tabelas distintos; preservar os contratos CAPI e CRM. Definir retenção de concluídos, checkpoints/recibos e tombstones. Não unificar prazo/payload de integrações com semânticas diferentes. |

**Complementos sem número:** teste real das seis sub-abas e cobertura de ajuda pelo catálogo; suporte automático por telefone a `api.whatsapp.com/send`; exclusão de `wa.me/message` somente da inferência por número; documentação da quebra de série GA4; prévia completa do assunto com sufixo; distinção de `/llms.txt` físico; alertas de expiração LinkedIn; procedimento de recuperação 1.16.0 → 1.15.0, incluindo navegação e token CAPI cifrado. Todos estão incorporados nas frentes correspondentes.

**Condições que permanecem externas:** credenciais e identidade das contas, sandbox Pipedrive, concessões Meta, aprovação LinkedIn, contrato/acesso para formulários nativos OpenAI, produtor/executor Google e comprovação da hospedagem no percurso real. Essas condições não serão rotuladas como implementadas ou homologadas apenas pelo plano. A decisão sobre WhatsApp flutuante e a cadência do item 64 continua nas condições da seção 8; o plano preserva os comportamentos existentes até decisão.

## Referências técnicas

- [W1 — WordPress: `wp_get_nav_menu_object()`](https://developer.wordpress.org/reference/functions/wp_get_nav_menu_object/): recuperação de objeto de menu da taxonomia `nav_menu`.
- [W2 — WordPress: `get_nav_menu_locations()`](https://developer.wordpress.org/reference/functions/get_nav_menu_locations/): mapa de localizações e IDs associados no tema ativo.
- [W3 — OpenAI: Overview of OpenAI Crawlers](https://developers.openai.com/api/docs/bots): assinaturas e finalidades declaradas dos agentes OpenAI.
- [W4 — Anthropic: coleta da web e agentes Claude](https://privacy.claude.com/en/articles/8896518-does-anthropic-crawl-data-from-the-web-and-how-can-site-owners-block-the-crawler): ClaudeBot, Claude-SearchBot e Claude-User.
- [W5 — Google: common crawlers](https://developers.google.com/crawling/docs/crawlers-fetchers/google-common-crawlers): famílias Google e alcance de Google-Extended.
- [W6 — Yoast: Metadata API](https://developer.yoast.com/customization/apis/metadata-api/): filtro `wpseo_meta_author` do presenter de autoria.
- [W7 — Google: user-triggered fetchers](https://developers.google.com/crawling/docs/crawlers-fetchers/google-user-triggered-fetchers): Google-Agent, Gemini Notebook e alias legado.
- [W8 — PHP: sodium_crypto_secretbox](https://www.php.net/manual/en/function.sodium-crypto-secretbox.php): cifra autenticada; derivação/contexto e envelope são decisões deste plano.
- [W9 — WordPress: spawn_cron](https://developer.wordpress.org/reference/functions/spawn_cron/): disparo de cron por requisição não bloqueante e seus limites.
- [PD1 — Pipedrive: Leads](https://developers.pipedrive.com/docs/api/v1/Leads): operação v1/v2, vínculos e campos de lead.
- [PD2 — Pipedrive: Users](https://developers.pipedrive.com/docs/api/v1/Users): identidade da conta por `/api/v1/users/me`.
- [PD3 — Pipedrive: autenticação](https://pipedrive.readme.io/docs/core-api-concepts-authentication): cabeçalho `x-api-token`.
- [PD4 — Pipedrive: limites](https://pipedrive.readme.io/docs/core-api-concepts-rate-limiting): orçamento compartilhado, reset e limites de rajada.
- [PD5 — Pipedrive: Persons](https://developers.pipedrive.com/docs/api/v1/Persons): criação v2 e dependência de contact sync para `job_title`.
- [PD6 — Pipedrive: Activities](https://developers.pipedrive.com/docs/api/v1/Activities): tarefas e vínculo a lead/negócio.
- [PD7 — Pipedrive: Notes](https://developers.pipedrive.com/docs/api/v1/Notes): notas da interação.
- [PD8 — Pipedrive: DealFields](https://developers.pipedrive.com/docs/api/v1/DealFields): leitura de campos disponível em v2.
- [PD9 — Pipedrive: endpoints v1 fora de suporte](https://developers.pipedrive.com/changelog/post/deprecated-apiv1-endpoints-become-out-of-support): lista e vigência em 01/08/2026.
- [PD10 — Pipedrive: developer sandbox](https://pipedrive.readme.io/docs/developer-sandbox-account): ambiente isolado de desenvolvimento.
- [PD11 — Pipedrive: LeadLabels](https://developers.pipedrive.com/docs/api/v1/LeadLabels): leitura de etiquetas em v1.
- [PD12 — Pipedrive: ActivityTypes](https://developers.pipedrive.com/docs/api/v1/ActivityTypes): leitura de tipos em v1.
- [AD1 — Google: Lead Form Webhook](https://developers.google.com/google-ads/webhook/docs/implementation): payload e semântica de respostas/repetição.
- [AD2 — LinkedIn: Lead Sync](https://learn.microsoft.com/en-us/linkedin/marketing/lead-sync/leadsync?view=li-lms-2026-05): coleta, notificações e identidade das ocorrências.
- [AD3 — LinkedIn: refresh tokens](https://learn.microsoft.com/en-us/linkedin/shared/authentication/programmatic-refresh-tokens): disponibilidade condicionada à autorização do app.

- [AD4 — Google Ads: LeadFormSubmissionData](https://developers.google.com/google-ads/api/reference/rpc/latest/LeadFormSubmissionData): dados/identificador e timestamp da submissão pela API.
- [AD5 — Google Ads: recuperar leads pela API](https://support.google.com/google-ads/answer/12080108?hl=en): janela de recuperação de até 60 dias.
- [AD6 — Meta: Retrieving Leads](https://developers.facebook.com/documentation/ads-commerce/marketing-api/guides/lead-ads/retrieving): requisito de recuperação localizado no índice oficial; página integral não recuperada.
- [OA1 — OpenAI: Advertiser API overview](https://developers.openai.com/ads/api-overview): escopo público de gestão e relatórios de anúncios; não foi localizado contrato de importação de formulários nativos nas referências consultadas.
- [OA2 — OpenAI: Conversions API](https://developers.openai.com/ads/conversions-api): envio de eventos pelo anunciante, `lead_created` e referência de atribuição opaca.
- [OA3 — OpenAI: Conversion Measurement](https://help.openai.com/en/articles/20001409-conversion-measurement): referência de clique na URL de chegada e medição.

- [OA4 — OpenAI: Measure Results](https://help.openai.com/en/articles/20001214-measure-results): macros de landing page e precedência de configuração.

Documentação W1–W6 consultada inicialmente em 28/09/2026 e famílias adicionais revalidadas em 29/09; Pipedrive, Google Lead Form, LinkedIn e OpenAI Ads consultados em 29/09/2026. Os achados específicos do F3 Base decorrem da fonte da 1.15.0; as páginas dos fornecedores fundamentam os contratos indicados. Os parâmetros Lighthouse foram conferidos no pacote 13.5.0 da bancada anterior. Fatos dos sites e IDs da conta Pipedrive provêm dos anexos, sem nova verificação autenticada. Os detalhes completos de permissões/campos Meta ainda exigem conferência na versão Graph/token selecionados: o índice oficial confirmou requisitos gerais, mas a página integral não foi recuperada. Não foram executados testes de API autenticada, site, sandbox ou implantação nesta revisão.
