"""Generate evidence report, installer, sources and checksums. Does not deploy sites."""
from pathlib import Path
import json,hashlib,zipfile,shutil,argparse,subprocess,statistics,re
root=Path(__file__).resolve().parent;ev=root/'suite/versao-1160/evidencias';docs=root/'fontes/plugin/docs'
p=argparse.ArgumentParser();p.add_argument('--saida',default='dist');p.add_argument('--baseline',required=True);args=p.parse_args();dest=Path(args.saida).resolve();dest.mkdir(parents=True,exist_ok=True)
names=['core','crm','capi','bordas','llms','novas','origens','http','redirects-bordas','consentimento','consentimento-tema','transporte','transporte-retentativa','admin','concorrencia','fechamento','credenciais','cta-sem-whatsapp']
labels=['Contratos, navegação, captura, segredos e ingestão','CRM com API simulada','Regressão CAPI','Bordas de contrato/relatórios','Publicação LLMS','Ofertas, atribuição, agentes e reconciliação Google','Meta: paginação, retomada e duplicidade','HTTP local / formulário sem JS / cache PHP','Redirects e evidências','Consentimento: temas/contraste','Consentimento: transparência, alfa, oklch e tema','Transporte de análise','Regressão específica da retentativa após 503','Telas administrativas','Análise com 12 processos concorrentes','Documentação, inventário CTA e perfil','Troca concorrente de credenciais e validação de catálogo','CTA sem WhatsApp: navegador, endpoint e banco']
sets={}
for n in names:
 d=json.loads((ev/(n+'.json')).read_text());fail=d.get('falhas') or [k for k,v in d.get('checks',{}).items() if v is False];assert not fail,(n,fail);sets[n]=len(d.get('checks',{})) or d['total']
up=json.loads((ev/'upgrade.json').read_text());assert len(up)==10 and all(x['exit']==0 for x in up)
syntax=json.loads((ev/'sintaxe.json').read_text());assert not syntax['falhas'];perf=json.loads((ev/'performance/matriz.json').read_text());assert len(perf['rows'])==6 and not any(x['runtimeError'] for x in perf['rows'])
validation='''# Validação — Core 1.16.0

Data: 29/09/2026. Revisão 2 do pacote. **Pacote validado em bancada local; homologação das contas externas pendente.** Sem implantação no Site-Teste ou na frota nesta entrega. Não houve acesso/teste a korvena.net.br. Caminhos admitidos: instalação nova e atualização da 1.15.0 concluída; nenhum downgrade.

## Ambiente e evidências

WordPress 7.1.2, PHP 8.3.6, MySQL 8.0.46, WP Super Cache 3.1.3, servidor PHP local com oito workers, Chrome 151.0.7922.34, Lighthouse 13.5.0. Dados sintéticos; e-mails bloqueados. CRM/CAPI/Meta usam transporte interceptado. Os resultados finais e harnesses ficam em suite/versao-1160/evidencias no ZIP de fontes. Números abaixo são asserções, não casos independentes nem homologações remotas.

| Conjunto | Verificações aprovadas | Evidência |
|---|---:|---|
'''
for n,label in zip(names,labels):validation+=f'| {label} | {sets[n]} | {n}.json |\n'
validation+=f'''\nInstalação/atualização: dez etapas aprovadas, cinco em cada origem (instalar, semear, atualizar, repetir, retomar), incluindo preservação de valores explícitos. Sintaxe: {syntax['php']} arquivos PHP e {syntax['js']} JS; sete assets recompostos com Terser fixado, conferidos contra o manifesto.

O teste HTTP observou arquivo de cache PHP e corpo vazio no acesso direto, além de HIT e confirmação 303 sem JS com cabeçalhos/noindex. Isso não é prova de configuração Apache/Nginx de qualquer hospedagem. O ensaio de doze processos verifica deduplicação/maior sequência e falhas reais de banco induzidas com triggers, incluindo 503 e ACK parcial. Não demonstra a causa histórica dos cinco erros reportados nos sites.

Correções encontradas durante a implementação: retentativa podia ficar sem agendamento após um temporizador antecipado; registro do submenu Integrações antes de Contatos causava 403. Ambas foram corrigidas e reexecutadas. Fixtures foram isoladas para não somar contribuições de logs de execuções anteriores, e o timestamp concorrente foi fixado para representar a mesma identidade/payload. Esses ajustes não alteram o contrato de produção. `pageshow.persisted` é um evento controlado, sem provar elegibilidade real para bfcache.

## Revisão 2 — fechamento local

Corrigidas lacunas adicionais: CTAs sem WhatsApp agora carregam a captura mesmo sem formulário; Pipedrive e Meta invalidam a verificação após alteração de credencial/configuração; lotes não misturam credenciais e respostas superadas não certificam o novo estado; campos esperados do lead são registrados antes do POST e conferidos mesmo após resposta perdida; IDs de alternativas são recusados quando o catálogo não os confirma.

Reexecutados core, CRM, credenciais, origens, fechamento e navegação real do CTA. O teste do CTA confere resposta HTTP 201, destino preservado e a linha no banco pela correlação, incluindo método e post_id. Instalação nova/1.15 reexecutada no pacote revisado. Demais evidências conservadas para fluxos sem alterações; a matriz de desempenho abaixo precede a revisão 2 e não mede seu novo caminho de CTA sem WhatsApp. Sem contatos remotos, e-mails ou alterações nos sites.

## Desempenho com presets padrão

Seis rodadas, três mobile/três desktop. pauseAfterLoad, pauseAfterFcp, networkQuiet e cpuQuiet de 1000 ms, sem ampliar artificialmente a coleta. Configuração resolvida, trace e DevTools completos acompanham cada medição. HTML real de HIT WP Super Cache foi reproduzido no servidor de teste; gtag oficial foi servido localmente e coletores externos não foram usados. Não mede latência do Google nem equivale ao PageSpeed de produção.

| Rodada | Perfil | Nota | LCP ms | TBT ms | Primeiro POST de análise desde a navegação |
|---|---|---:|---:|---:|---|
'''
for row in perf['rows']:
 first='não observado na janela' if row['firstAnalysisMs'] is None else f"{row['firstAnalysisMs']:.0f} ms"
 validation+=f"| {row['rep']+1} | {row['formFactor']} | {row['score']*100:.0f} | {row['lcp']:.0f} | {row['tbt']:.1f} | {first} |\n"
validation+='''
O POST apareceu em cinco das seis janelas, com respostas 200 e eventos confirmados. Adiar cinco segundos após load **não garante ficar fora do trace** e não demonstrou ganho causal de nota. Mantido o prazo com saídas antecipadas e recuperação de erro; nenhum ajuste de tema/gtag foi incluído. A matriz mede o fluxo normal anterior à correção de retentativa (exercitada separadamente) e à retirada de funções sem consumidores; não afirma benchmark byte a byte do ZIP final.

## Homologação Pipedrive — CRM-A01…CRM-A15

Todos os casos abaixo estão **pendentes no destino real**. Ambiente externo: não disponibilizado; conta: não verificada; horário/evidência remota: não existem nesta execução; versão alvo: 1.16.0; limpeza remota: não aplicável, nenhum objeto externo criado. Os mocks aprovados acima não substituem essas linhas. Preparar sandbox/developer com IDs próprios, executar contratos e, depois, entrega sintética limitada na conta comercial autorizada. Guardar horário UTC, IDs/evidências e limpeza de cada caso.

| Caso | Aceite remoto pendente |
|---|---|
| CRM-A01 | Campanha Instagram, unidade/canal/parceiro/ponto, nota e atividade; conferência dos campos na releitura. |
| CRM-A02 | Retorno no dia seguinte sem nova UTM mantém a origem conforme a janela/modelo. |
| CRM-A03 | Sem UTM: mapa de fallback explícito, sem inventar atribuição. |
| CRM-A04 | Parceiro/campanha desconhecido: valor vazio e qualidade visível, sem inferência. |
| CRM-A05 | Segundo envio da mesma pessoa com oportunidade aberta: reutiliza e acrescenta nota. |
| CRM-A06 | Pessoa/empresa preexistentes: não duplicar nem sobrescrever. |
| CRM-A07 | Token inválido e recadastro: pausa/reenvio controlado sem duplicidade. |
| CRM-A08 | Falha 503 induzida em sandbox: retentativa e recuperação. |
| CRM-A09 | Resposta perdida entre pessoa e lead: conciliar antes de repetir criação. |
| CRM-A10 | Medição recusada/revogada: atribuição não observada; não afirmar orgânico. |
| CRM-A11 | Lead sintético Meta com marca de teste e campos comerciais/nativos confirmados. |
| CRM-A12 | Google Send test, duplicata e CRM em modo explícito de homologação. |
| CRM-A13 | Chave Google errada: 403 e nenhuma captura. |
| CRM-A14 | Eliminação: objeto sintético exclusivo apagado; compartilhado preservado com pendência. |
| CRM-A15 | Limites/429/reset real da conta observados; pausa sem perda nem cota inventada. |

Também pendem: seleção múltipla com dois IDs em lead v1 e releitura, campos/permissões da conta real, webhook Google público usando a ferramenta do provedor, equivalência de ID Google API/webhook, executor da reconciliação, permissões/ativos Meta e identificação efetiva dos testes Meta, corrida entre instalações independentes, latência de loopback/cron real e ensaio com o Yoast ativo na versão da frota. A reserva de robots usa cópia/hash/remoção condicionais no código; a restauração e proteção HTTP devem ser comprovadas no sistema de arquivos/hospedagem real. Não declarar esses aceites externos encerrados.

## Pendências e exclusões do escopo

- Backlog 50: nova soma sobre logs reais ainda disponíveis; sem log não há reconstrução legítima.
- Backlog 52: observar sete dias sem a falha de persistência; a bancada não substitui esse período.
- LinkedIn nativo: aprovação/acesso da API e homologação. OpenAI nativo: contrato oficial, acesso e homologação. Atribuição web dos dois está disponível nos limites documentados.
- Webhook genérico de saída e confirmação por URL de formulário seguem adiados. Custos, receita/ROI, identificação autenticada de robôs e automação de bloqueios estão fora.
- Implantador, tema, compensações locais e hospedagem não foram alterados. A mudança do WhatsApp flutuante direto para formulário continua decisão do dono.

Integrações vêm desligadas. A falta de acesso externo não impede instalar as correções locais, mas impede declarar a integração homologada para ativação comercial. Consulte PIPEDRIVE.md e ORIGENS-ANUNCIOS.md para os próximos passos concretos.
'''
(docs/'VALIDACAO.md').write_text(validation)
report='''# Entrega — F3 Base Core 1.16.0

**Revisão 2 do pacote — 29/09/2026.** Substitui o ZIP inicial de SHA-256 `7be3c99437f5f28a8fc4b733d75eb7da8987b03b7dc86f1e196bdb9592c60f6d`. A versão funcional permanece 1.16.0, com correções de fechamento e documentação atualizada; não exige nova migração de banco.

Implementação da versão 1.16.0, para instalação nova ou atualização da 1.15.0 concluída. Recuperação na própria versão, sem downgrade. Instalador acompanha documentação acessível no WordPress por arquivos e `f3base/documentacao-ler`.

## Alterações entregues e rastreabilidade

| Frente / backlog | Implementação |
|---|---|
| N1 / 42 | Navegação tipada: tema, menu clássico ou bloco; busca paginada, ID/título, validação própria e diagnóstico de uso sem alterar tema. |
| U1/U2/D1 | Sub-aba correta em leitura/POST/retorno, controles tipados, ajuda compartilhada, documentação instalada e contrato 4.0.0/perfil 3.2. |
| M1 | Agentes e buscadores em Medição; OpenAI/Claude/Gemini e famílias específicas, cobertura, extremos/horas, frequência e CSV. |
| C1 / 67,69,70 | CTA válido pelo destino, marcação opcional por número, superfície e inventário explícito limitado; retirada da cadeia sem consumidores de promoção pelo modelo. |
| C2/C3 / 59,68 | Cookies auxiliares não mudam origem/idempotência; atividade somente após persistência, inclusive formulário. |
| C4 | Composição comum do assunto elimina repetição do nome do site e alimenta a prévia do editor. |
| P1/P2 / 63,65,62 | Autoria pública, hook correto Yoast e reserva privada de robots; homologações externas descritas abaixo. |
| E1/E2/E3/E4 / 54,37,60,64,61 | Contexto/invalidação de evidência, idade persistida do cache, procedência comprovada, cadência preservada, tipos/simulação/diagnóstico consistentes. |
| S1/V1/L1/D2 / 41,45,36,66 | Preço e período associados, renovação antecipada de prova, contraste/painel do tema, LLMS pendente/contingência limitada, full padrão true preservando false explícito. |
| M2 / 38 | Presets padrão medidos; resultado sem promessa de POST fora do trace ou melhoria de nota. |
| CRM1/S2/F1 / 17 | Pipedrive opcional, segredo cifrado, fila comum com adaptadores, intenção durável, checkpoints, jornada, prévia, reenvio e eliminação conservadora. |
| ADS1/ADS2 | Consulta Meta e webhook/reconciliação Google com identidade durável, cursores e tombstones, sem inventar sessão web ou conversão CAPI. |
| ADS3/ADS4 | LinkedIn nativo condicionado; OpenAI atribuição web/oppref incluída, captura nativa condicionada ao contrato/acesso. |

## Mudanças operacionais

1. **Cache/servidor:** oppref entra na lista de parâmetros de rastreamento; consulte o delta do WP Super Cache na instalação. Não há edição automática de wp-cache-config.php ou .htaccess por ativação. Verificação do artefato PHP e cabeçalhos continuam separadas do valor configurado.
2. **Options/defaults:** navegação estruturada, configurações opcionais Pipedrive/Meta/Google/LinkedIn desligadas e estados técnicos de filas/coleta; cifragem de segredos; LLMS full true apenas quando ausente. Não substituir listas vazias, false/zero ou permissões salvas.
3. **Banco:** colunas de instantes/contribuições de acessos, agregados horários, fila CRM e recibos nativos. Dicionário e índices reais em docs/dados/contrato.json. Lead continua fonte de captura; não copiar o corpo para o journal.
4. **Migração:** somente nova/1.15 concluída; checkpoints e retomada. Sem reexecutar migradores antigos e sem suporte de downgrade. Nenhuma atualização da frota nesta entrega.
5. **Ativação externa:** requer credenciais/conta, mapeamentos e homologações abaixo. E-mail e captura não esperam Pipedrive. O plugin não cria campos comerciais nem administra anúncios.

## Arquivos

- base-site-core-fator3-1.16.0.zip: instalador WordPress.
- fontes-testes-core-1.16.0.zip: fontes, suíte, evidências, build e binário 1.15 usado como baseline.
- manifesto-1.16.0.json: tamanho e SHA-256 de cada arquivo instalado.
- SHA256SUMS-1.16.0.txt: hashes dos entregáveis.
- PLANO-APROVADO-1.16.0.md: plano com a decisão final de base/recuperação.

'''+validation
(root/'RELATORIO-1.16.0.md').write_text(report);shutil.copy2(root/'RELATORIO-1.16.0.md',dest/'RELATORIO-1.16.0.md');shutil.copy2(root/'PLANO-APROVADO.md',dest/'PLANO-APROVADO-1.16.0.md')
subprocess.run(['python3',str(root/'montar-release.py'),'--saida',str(dest)],check=True)
archive=dest/'base-site-core-fator3-1.16.0.zip';manifest=json.loads((dest/'manifesto-1.16.0.json').read_text());
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(manifest['arquivos'])
 for row in manifest['arquivos']:
  body=z.read('base-site-core-fator3/'+row['arquivo']);assert hashlib.sha256(body).hexdigest()==row['sha256'];assert body==(root/'fontes/plugin'/row['arquivo']).read_bytes()
 assert b'1.16.0' in z.read('base-site-core-fator3/docs/README.md')
final={'versao':'1.16.0','revisao_pacote':2,'conjuntos':sets,'upgrade_etapas':10,'sintaxe':syntax,'lighthouse_rodadas':6,'instalador_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'arquivos_instalador':len(manifest['arquivos']),'homologacao_externa':'pendente','sites_alterados':[]}
(ev/'pacote-final.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
baseline=Path(args.baseline).resolve();assert hashlib.sha256(baseline.read_bytes()).hexdigest()=='23a047da1873d9cc4372f672423e4536596cc06dcd24266209443384847cf05b'
with zipfile.ZipFile(dest/'fontes-testes-core-1.16.0.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 files=list((root/'fontes').rglob('*'))+list((root/'suite/build-assets').rglob('*'))+list((root/'suite/versao-1160').rglob('*'))+[root/n for n in ['README.md','PLANO-APROVADO.md','RELATORIO-1.16.0.md','montar-release.py','fechar-release.py']]
 for f in sorted(set(files)):
  if not f.is_file() or any(k in f.parts for k in ['__pycache__','gerados','barreira']):continue
  i=zipfile.ZipInfo('core-1.16.0/'+f.relative_to(root).as_posix(),(2026,9,29,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,f.read_bytes())
 i=zipfile.ZipInfo('core-1.16.0/referencias/base-site-core-fator3-1.15.0.zip',(2026,9,29,0,0,0));i.external_attr=0o100644<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,baseline.read_bytes())
outputs=[dest/n for n in ['base-site-core-fator3-1.16.0.zip','fontes-testes-core-1.16.0.zip','manifesto-1.16.0.json','RELATORIO-1.16.0.md','PLANO-APROVADO-1.16.0.md']]
(dest/'SHA256SUMS-1.16.0.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in outputs));print(json.dumps(final,ensure_ascii=False))
