# Contratos — plugin 1.13.0 / configuração 2.0.0

## Permissões e política

Operações administrativas exigem autenticação e capability. As abilities de relatórios, jornada, documentação e política exigem `manage_options`. O plugin não cria credenciais nem concede administração a outros papéis.

`f3base/config-core-politica-ler` retorna fotografias de `politica` e `gestao`, com valor, existência e revisão. `f3base/config-core-politica-escrever` aceita somente `politica`, `simular` (padrão true) e `revisao_esperada`. A escrita exige revisão atual e gestão por agentes habilitada. A simulação retorna `acrescimos` e `remocoes`. O contrato antigo de lista simples não é aceito por essa operação.

```json
{"politica":{"schema":1,"modo":"selecionadas","lista":["f3base_contato"]},"simular":true}
```

Modos `todas` e `nenhuma` exigem `lista:[]`; `selecionadas` exige itens únicos, elegíveis e não vazios. Somente a transformação inicial da base 1.12.0 interpreta lista simples vazia como `todas`. Uma lista explícita permanece explícita, mesmo se contém todos os itens atuais.

## Captura

POST `/wp-json/f3base/v1/lead` mantém schema fechado, token, quotas e deduplicação. `correlation_id` identifica a ação; a coluna persistida é `correlacao`. Sessão e navegação são 32 hex. O servidor classifica o método pelo destino e obtém IP, user agent e página do contexto da requisição. `cta` é um identificador estável limitado a 80 caracteres; `dispositivo` aceita `movel` ou `desktop` no contexto canônico. Sem medição autorizada, sessão/navegação/dispositivo não são persistidos como contexto analítico.

Formulários usam POST `/formularios/token` e `/formularios/enviar` dentro do mesmo namespace. Sem JS, usam `admin-post.php?action=f3base_formulario`. Token vincula formulário, revisão e página. Com JS, cada instância recebe uma chave nova, inclusive se o HTML veio de cache; retentativas mantêm a chave. O envio inclui atribuição de sessão, navegação e dispositivo quando disponíveis. O registro guarda snapshot da definição dos campos de opções fechadas para análise futura.

POST `/wp-json/f3base/v1/analise` aceita `token`, `medicao:true` e `eventos` (1–20). Limite de corpo: 32 KiB. Tipos: `pagina`, `form_vista`, `form_inicio`, `form_tentativa`, `form_erro`, `vital`. Identificadores: `evento`, `visitante`, `sessao`, `navegacao`; contexto: `caminho`, `formulario`, `formulario_revisao`, `correlacao`, `dispositivo`, `criado_em`, `detalhe`, `valor`, `sequencia`, `atribuicao`. Campos desconhecidos e valores digitados são recusados. O cliente envia lotes limitados por bytes.

Evento igual é idempotente. O mesmo ID com outro conteúdo é conflito, exceto revisão crescente de uma amostra de vital com identidade estável. A atualização é condicional e conserva a maior sequência. Horário fora da janela válida recebe âncora do servidor; a qualidade do horário fica registrada. Há quotas por origem (300 requisições/10 min) e sessão (1.000 eventos na janela). Rotas dinâmicas não devem ser armazenadas pelo cache.

## Relatórios e documentação

`f3base/relatorios-integrados-ler`: `de`, `ate` (YYYY-MM-DD, intervalo inclusivo de 1–90 dias), `visao`, `caminho`, `formulario`, `metodo`, `comparar`, `pagina` e `limite` (1–200). Visões: `resultados`, `campanhas`, `formularios`, `blocos`, `qualidade`, `operacao`, `materiais`, `demanda`, `metodos`. Retorna período/fuso, totais, cobertura, avisos, linhas e próxima página. Filtros de formulário/método restringem contatos; denominadores continuam sessões da página observada. Caminhos externos são recusados.

`f3base/lead-jornada-ler`: `record_id` (32 hex). Até 500 eventos anteriores ao recebimento, com indicação de corte. Sem sessão ou sem eventos, não inventa uma jornada.

`f3base/documentacao-ler`: `arquivo`, `linha`, `limite` (1–200). Sem arquivo, índice. Caminhos não catalogados são recusados. `f3base/arquivos-privados-preparar` cria/testa a raiz configurada, sem enviar mensagens.

As abilities de consulta/gestão de leads e resposta opcional permanecem nos schemas publicados. O importador, o reparador histórico, o destino de gravação Flamingo/CPT e a resolução de destino CAPI anterior à base suportada foram retirados. A leitura do acervo já incorporado continua disponível.

`persisted` confirma armazenamento. `verified` no acesso direto ao cache exige corpo completo vazio com HTTP 200/403/404/410; 403 com HTML falha na expectativa de corpo. Hash igual ao arquivo prova exposição. 5xx, redirecionamento, truncamento e ausência de arquivo permanecem inconclusivos.
