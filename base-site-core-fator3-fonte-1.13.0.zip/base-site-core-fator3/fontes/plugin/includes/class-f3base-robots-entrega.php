<?php
/** Confirma a resposta pública e mantém a alternativa física quando a rota virtual é interceptada. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Robots_Entrega {
	public const EVENTO      = 'f3base_robots_verificar';
	public const INTERVALO   = 3600;
	public const RETENTATIVA = 600;
	public const MARCA       = "# Gerenciado pelo Base Site Core Fator3.\n";

	/** A URL vem da configuração do WordPress. Nenhum cabeçalho Host recebido decide o destino. */
	public static function assinatura(): string {
		return hash( 'sha256', serialize( array( F3BASE_PLUGIN_VERSAO, home_url( '/' ), site_url( '/' ), get_option( 'blog_public' ), get_option( 'active_plugins', array() ), get_option( 'wpseo', array() ), F3Base_Options::ler( 'f3base_robots' ) ) ) );
	}
	public static function ligado(): bool {
		return ! empty( F3Base_Options::ler( 'f3base_robots' )['ligado'] ) && empty( F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION )['suspenso'] );
	}
	/** O carregamento só agenda. A rede é consultada pelo job, fora da trava dos arquivos. */
	public static function planejar(): void {
		if ( ! self::ligado() ) {
			wp_unschedule_hook( self::EVENTO );
			return; }
		$d       = (array) ( F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION )['entrega'] ?? array() );
		$mesma   = ( $d['assinatura'] ?? '' ) === self::assinatura();
		$quando  = $mesma ? max( time() + 5, (int) ( $d['verificado_em'] ?? 0 ) + ( ! empty( $d['ok'] ) ? self::INTERVALO : self::RETENTATIVA ) ) : time() + 5;
		$proxima = wp_next_scheduled( self::EVENTO );
		if ( $proxima && $proxima > $quando + 5 ) {
			wp_unschedule_hook( self::EVENTO );
			$proxima = false; }
		if ( ! $proxima ) {
			wp_schedule_single_event( $quando, self::EVENTO ); }
	}
	public static function parar(): void {
		wp_unschedule_hook( self::EVENTO ); }

	/** Cabeçalho de prova vinculado à requisição; a consulta usa o contexto real is_robots do front-end. */
	public static function cabecalhos(): void {
		if ( ! self::ligado() || headers_sent() ) {
			return; }
		nocache_headers();
		$sonda = $_GET['f3base_robots_sonda'] ?? '';
		if ( is_string( $sonda ) && preg_match( '/^[a-f0-9]{32}$/D', $sonda ) ) {
			header( 'X-F3Base-Robots-Sonda: ' . $sonda ); }
	}
	private static function requisitar( string $url ) {
		return wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 8,
				'redirection'         => 0,
				'limit_response_size' => F3Base_Robots_Arquivo::MAX_BYTES + 1,
				'headers'             => array(
					'Cache-Control' => 'no-cache',
					'Accept'        => 'text/plain',
				),
				'user-agent'          => F3Base_Publicacao_Sonda::user_agent( 'robots' ),
				'cookies'             => array(),
			)
		);
	}
	private static function ler_resposta( $r ): array {
		if ( is_wp_error( $r ) ) {
			throw new RuntimeException( 'Consulta HTTP falhou: ' . $r->get_error_message() ); }
		return array(
			'codigo' => (int) wp_remote_retrieve_response_code( $r ),
			'tipo'   => strtolower( (string) wp_remote_retrieve_header( $r, 'content-type' ) ),
			'corpo'  => (string) wp_remote_retrieve_body( $r ),
		);
	}
	/** Executado automaticamente pelo WP-Cron; também pode ser chamado por reconciliação explícita. Esta operação pode escrever arquivos; não é uma consulta de inspeção. */
	public static function verificar(): array {
		if ( ! self::ligado() ) {
			self::parar();
			return array(
				'ok'     => false,
				'motivo' => 'Gerador desligado.',
			); }
		$nome = get_temp_dir() . 'f3base-robots-entrega-' . hash( 'sha256', ABSPATH ) . '.lock';
		$lock = ! is_link( $nome ) ? @fopen( $nome, 'c' ) : false;
		if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Libera o descritor da trava flock; WP_Filesystem não oferece bloqueio equivalente.
			} return array(
				'ok'     => false,
				'motivo' => 'Verificação em curso ou trava indisponível.',
			); }
		$contexto = F3Base_Robots_Arquivo::contexto();
		$d        = array(
			'ok'              => false,
			'assinatura'      => self::assinatura(),
			'verificado_em'   => time(),
			'modo'            => 'virtual',
			'codigo'          => 0,
			'esperado_sha256' => '',
			'recebido_sha256' => '',
			'erro'            => '',
		);
		try {
			$r = F3Base_Robots_Arquivo::sincronizar();
			if ( empty( $r['ok'] ) ) {
				throw new RuntimeException( $r['motivo'] ); }
			$sonda = bin2hex( random_bytes( 16 ) );
			$r     = self::requisitar( home_url( '/?robots=1&f3base_robots_sonda=' . $sonda ) );
			$fonte = self::ler_resposta( $r );
			if ( 200 !== $fonte['codigo'] || ! str_starts_with( $fonte['tipo'], 'text/plain' ) || ! hash_equals( $sonda, (string) wp_remote_retrieve_header( $r, 'x-f3base-robots-sonda' ) ) || strlen( $fonte['corpo'] ) > F3Base_Robots_Arquivo::MAX_BYTES - strlen( self::MARCA ) || ! preg_match( '/^User-agent\s*:/im', $fonte['corpo'] ) ) {
				throw new RuntimeException( 'O gerador WordPress não respondeu texto válido com a prova desta consulta. Nenhum arquivo foi criado.' );
			}
			// Relê o estado: desligamento ou alteração em paralelo invalida a publicação dentro da trava.
			foreach ( array( F3Base_Robots_Arquivo::OPTION, 'f3base_robots', 'wpseo', 'blog_public', 'active_plugins', 'home', 'siteurl', 'alloptions', 'notoptions' ) as $chave ) {
				wp_cache_delete( $chave, 'options' ); }
			$e          = F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION );
			$gerenciado = ! empty( $e['gerenciado']['sha256'] );
			$esperado   = $fonte['corpo'];
			$publica    = null;
			if ( ! $gerenciado ) {
				$publica = self::ler_resposta( self::requisitar( home_url( '/robots.txt' ) ) );
				$igual   = 200 === $publica['codigo'] && str_starts_with( $publica['tipo'], 'text/plain' ) && hash_equals( hash( 'sha256', $esperado ), hash( 'sha256', $publica['corpo'] ) );
				if ( ! $igual && ! in_array( $publica['codigo'], array( 200, 404, 410 ), true ) ) {
					throw new RuntimeException( 'O endereço público respondeu HTTP ' . $publica['codigo'] . '; verifique redirecionamentos, cache ou bloqueios da hospedagem.' ); }
				$gerenciado = ! $igual;
			}
			if ( $gerenciado ) {
				$d['modo'] = 'gerenciado';
				$esperado  = self::MARCA . $fonte['corpo'];
				$r         = F3Base_Robots_Arquivo::publicar( $esperado, $contexto );
				if ( empty( $r['ok'] ) ) {
					throw new RuntimeException( $r['motivo'] ); }
				$publica = self::ler_resposta( self::requisitar( home_url( '/robots.txt' ) ) );
			}
			$d['codigo']          = $publica['codigo'];
			$d['esperado_sha256'] = hash( 'sha256', $esperado );
			$d['recebido_sha256'] = hash( 'sha256', $publica['corpo'] );
			if ( 200 !== $publica['codigo'] || ! str_starts_with( $publica['tipo'], 'text/plain' ) || ! hash_equals( $d['esperado_sha256'], $d['recebido_sha256'] ) ) {
				throw new RuntimeException( 'A resposta pública de /robots.txt diverge das regras geradas. Verifique o cache, a CDN ou as regras da hospedagem; a entrega ainda não foi confirmada.' ); }
			$d['ok'] = true;
		} catch ( Throwable $falha ) {
			$d['erro'] = $falha->getMessage(); }
		try {
			$r = F3Base_Robots_Arquivo::diagnostico( $d, $contexto );
			self::planejar();
			return array(
				'ok'      => $d['ok'] && ! empty( $r['ok'] ),
				'motivo'  => ! empty( $r['ok'] ) ? ( $d['erro'] ?: 'Entrega pública confirmada por HTTP.' ) : $r['motivo'],
				'entrega' => $d,
			);
		} finally {
			flock( $lock, LOCK_UN );
			fclose( $lock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Libera o descritor da trava flock; WP_Filesystem não oferece bloqueio equivalente.
		}
	}
}
