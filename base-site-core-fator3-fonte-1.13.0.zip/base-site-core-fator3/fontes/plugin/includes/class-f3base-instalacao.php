<?php
/** Dois fluxos: instalação direta e transformação da base 1.12.0+. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Instalacao {
    const OPTION='f3base_release_1130';
    public static function origem(): string {
        global $wpdb;
        $s=get_option(self::OPTION,array());
        if (($s['versao']??'')==='1.13.0') { return !empty($s['concluido_em'])?'atual':($s['origem']??'indefinida'); }
        $base=get_option('f3base_release_1120',array());
        if (($base['versao']??'')==='1.12.0' && !empty($base['concluido_em'])) { return '1.12.0'; }
        $n=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name<>%s",$wpdb->esc_like('f3base_').'%','f3base_1130_trava'));
        $tables=$wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($wpdb->prefix.'f3base_').'%'));
        return !$wpdb->last_error && (int)$n===0 && !$tables?'nova':'indefinida';
    }
    public static function permitida(): bool { return in_array(self::origem(),array('atual','nova','1.12.0'),true); }
    public static function aviso(): void { if(current_user_can('manage_options')){echo '<div class="notice notice-error"><p>F3 Base: atualização bloqueada. A versão mínima de origem é 1.12.0 concluída. Estado anterior sem versão confirmada exige recuperação; nenhum dado foi convertido.</p></div>';}}
    public static function atualizar(): array {
        $origem=self::origem();
        if($origem==='atual'){return array('ok'=>true,'codigo'=>'atual');}
        if(!self::permitida()){return array('ok'=>false,'codigo'=>'origem_nao_suportada');}
        global $wpdb;$lock=wp_generate_uuid4();$key='f3base_1130_trava';
        $old=get_option($key);if(is_array($old)&&($old['expira']??0)<time()){$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,maybe_serialize($old)));wp_cache_delete($key,'options');}
        $value=array('id'=>$lock,'expira'=>time()+120);if(!add_option($key,$value,'',false)){return array('ok'=>false,'codigo'=>'atualizacao_em_execucao');}
        try{
            $s=F3Base_Options::ler(self::OPTION);
            if(empty($s['versao'])){
                $foto=F3Base_Options::fotografia(F3Base_Options::OPTION_OPERAVEIS);$v=$foto['existe']?$foto['valor']:array();
                if($origem!=='nova' && (!is_array($v)||!array_is_list($v)||array_filter($v,static fn($x)=>!is_string($x))||array_diff($v,F3Base_Politica::elegiveis()))){return array('ok'=>false,'codigo'=>'politica_origem_invalida');}
                $p=array('schema'=>1,'modo'=>$origem==='nova'||!$v?'todas':'selecionadas','lista'=>$origem==='nova'?array():array_values(array_unique($v)));
                $s=array('versao'=>'1.13.0','origem'=>$origem,'iniciado_em'=>time(),'politica_antes'=>$foto,'politica_depois'=>$p);
                $r=F3Base_Options::atualizar_estado(self::OPTION,static fn()=>$s);if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'checkpoint_falhou');}
            }
            if(empty($s['politica_confirmada'])){
                $f=F3Base_Options::fotografia(F3Base_Options::OPTION_OPERAVEIS);
                if(!$f['existe'] || $f['valor']!==$s['politica_depois']){
                    if(!hash_equals($f['revisao'],$s['politica_antes']['revisao'])){return array('ok'=>false,'codigo'=>'conflito_politica');}
                    $r=F3Base_Options::gravar(F3Base_Options::OPTION_OPERAVEIS,$s['politica_depois'],F3Base_Options::ORIGEM_PADRAO,$f['revisao']);if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'politica_pendente');}
                }
                $r=F3Base_Options::atualizar_estado(self::OPTION,static function($v){$v['politica_confirmada']=true;return $v;});if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'checkpoint_falhou');}
            }
            if($s['origem']==='nova'){
                // Configurações ainda ausentes usam os padrões do catálogo. Não inventar IDs
                // de conteúdo (navegação, logo etc.) para semear um site sem esses recursos.
                $n='f3base_politica_canal';if(!F3Base_Options::fotografia($n)['existe']){
                    $r=F3Base_Options::gravar($n,true,F3Base_Options::ORIGEM_PADRAO,F3Base_Options::revisao($n));
                    if(empty($r['persisted'])){return array('ok'=>false,'codigo'=>'padroes_pendentes');}
                }
            }
            $r=F3Base_Atualizacao::migrar();
            F3Base_Modulo_Comportamento::criar_tabela();F3Base_Vitais::instalar();
            if(empty($r['ok']) || !F3Base_Leads_Repositorio::instalar() || !F3Base_Analise::instalar()){return array('ok'=>false,'codigo'=>'schema_pendente');}
            $privado=F3Base_Arquivos_Privados::provisionar();if(empty($privado['ok'])){return array('ok'=>false,'codigo'=>'diretorio_privado_pendente');}
            $r=F3Base_Options::atualizar_estado(self::OPTION,static function($v){$v['concluido_em']=time();return $v;});
            return array('ok'=>!empty($r['persisted']),'codigo'=>!empty($r['persisted'])?'concluido':'checkpoint_falhou');
        } finally{$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",$key,maybe_serialize($value)));wp_cache_delete($key,'options');}
    }
}
