<?php
/**
 * Módulo endpoint-leads.
 *
 * Rota REST pública e endurecida: schema fechado por campo com rejeição de campo
 * desconhecido, limites por campo MEDIDOS EM CARACTERES — a mesma unidade que o
 * cliente corta —, token efêmero assinado, honeypot, rate limit com incremento
 * ATÔMICO no banco e deduplicação atômica por chave única (índice UNIQUE em
 * tabela própria — o banco decide o empate, não o PHP).
 *
 * A reserva de deduplicação nasce PENDENTE, vira firme só depois da persistência
 * e é COMPENSADA quando nenhum destino aceita o lead: reserva que sobrevive à
 * falha bloqueia por 30 dias o visitante que tentou de novo. Reserva que falha
 * por MOTIVO DE BANCO — e não por chave repetida — não é duplicata: ela responde
 * 503 nomeado, com o carimbo de recusa, em vez de um 200 dizendo "duplicado"
 * com o identificador em branco.
 *
 * O TOKEN EFÊMERO TEM ESCOPO E VIDA CURTA, e a decisão é desta versão. Ele
 * assinava só a expiração, valia 12 h e era impresso em toda página: um bearer
 * público que autorizava qualquer POST de qualquer página do site. Agora a
 * assinatura cobre a ROTA e o CAMINHO DA PÁGINA em que ele foi emitido, e a
 * vida declarada é de uma hora (filtrável em `f3base_token_lead_ttl`). O que
 * isso custa é o caso da PÁGINA EM CACHE, e ele é tratado explicitamente em vez
 * de virar 403 mudo: quem recebe `f3base_token_invalido` pede um token novo na
 * rota GET barata `/token` — sem nonce, porque o token é público por natureza, e
 * limitada pelo MESMO balde de rate limit do registro — e reenvia UMA vez. A
 * recusa por token também passou a carimbar `ULTIMA_FALHA_LEAD`: um site em
 * cache cujo beacon voltava 403 há semanas ficava verde na tela do operador.
 *
 * O CONSENTIMENTO GRAVADO É O ESTADO MEDIDO, e não o portão. O campo booleano
 * que o navegador manda diz se as TAGS podem disparar; ele não distingue "o
 * titular permitiu" de "ninguém decidiu e a política é pré-aprovada". O que
 * fica no registro do lead é o vocabulário fechado de três valores de
 * `F3Base_Modulo_Consentimento` — `sim`, `nao`, `padrao-pre-aprovado` —, e é
 * ele que decide se o evento de servidor da Meta chega a ser agendado.
 *
 * DEPOIS DA PERSISTÊNCIA CONFIRMADA — e só depois dela — o evento de servidor da
 * Conversions API da Meta é AGENDADO, com o mesmo `event_id` que o navegador já
 * mandou no Pixel. Agendar antes mandaria à Meta a conversão de um lead que pode
 * não existir, e a Meta não desfaz o que recebeu. Sem token nada é agendado, e o
 * motivo sai NOMEADO no carimbo de atividade: a Conversions API não tem voto
 * sobre o registro do lead, em nenhum dos dois sentidos.
 *
 * Grava exclusivamente no repositório privado f3base_leads.
 * `f3base_lead`, e o módulo reporta o estado com o motivo. `from` e `subject` saem
 * legíveis na gravação. O `record_id` nasce no servidor; o `correlation_id` vem do
 * navegador — nome honesto para cada um.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Endpoint de registro de leads.
 */
final class F3Base_Modulo_Endpoint_Leads extends F3Base_Modulo {

	/**
	 * Rota, dentro do namespace do plugin.
	 */
	public const ROTA = '/lead';

	/**
	 * Rota de EMISSÃO de token, para a página que veio do cache.
	 *
	 * GET e sem nonce de propósito: o token é público por natureza — ele é
	 * impresso no HTML de toda página — e exigir nonce aqui obrigaria a página
	 * em cache a ter um nonce válido, que é exatamente o que ela não tem. O que
	 * a protege é um balde próprio de rate limit de emissão: quem pede token em
	 * rajada esgota a emissão de tokens; o registro de leads usa outro balde.
	 */
	public const ROTA_TOKEN = '/token';

	/**
	 * CPT privado de contingência.
	 */
	public const CPT = 'f3base_lead';

	/**
	 * Canal usado na caixa do Flamingo.
	 */
	public const CANAL = 'f3base-whatsapp';

	/**
	 * Sufixo da tabela de chaves do endpoint.
	 *
	 * A tabela guarda DOIS tipos de linha, discriminados pela coluna `tipo`: a
	 * reserva de deduplicação e o balde do rate limit. Uma só porque as duas
	 * precisam da MESMA propriedade — o banco decide o empate — e uma migração
	 * só é uma migração a menos para sair errada.
	 */
	public const TABELA = 'f3base_leads_dedup';

	/**
	 * Tipos de linha da tabela.
	 */
	public const TIPO_DEDUP  = 'dedup';
	public const TIPO_LIMITE = 'limite';

	/**
	 * Estados fechados de uma reserva de deduplicação.
	 *
	 * `pendente` é a reserva que ainda não tem lead gravado atrás dela; `firme`
	 * é a que tem. Só a firme recusa a tentativa seguinte.
	 */
	public const RESERVA_PENDENTE = 'pendente';
	public const RESERVA_FIRME    = 'firme';

	/**
	 * Vocabulário fechado do parser de booleano.
	 *
	 * Existe porque `(bool) 'false'` é `true` em PHP, e o campo que passava por
	 * esse molde era o CONSENTIMENTO: o lead era arquivado como tendo consentido.
	 */
	public const BOOLEANO_VERDADEIRO = array( '1', 'true', 'sim', 'yes', 'on', 'y', 's', 't', 'verdade' );
	public const BOOLEANO_FALSO      = array( '', '0', 'false', 'nao', 'não', 'no', 'off', 'n', 'f' );

	/**
	 * Memo da prontidão da tabela nesta requisição.
	 *
	 * @var bool|null
	 */
	private static ?bool $tabela_pronta = null;

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'endpoint-leads';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Endpoint de leads', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Rota REST pública endurecida que recebe o beacon do clique: schema fechado com rejeição de campo desconhecido, limites por campo, token efêmero assinado, honeypot, rate limit e deduplicação atômica por chave única. Grava no repositório privado f3base_leads, com sessão quando permitida, correlação e contexto de origem.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(

			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'garantir_estrutura',
				'prioridade' => 20,
				'args'       => 0,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'rest_api_init',
				'metodo'     => 'registrar_rota',
				'prioridade' => 10,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_contato', 'f3base_endpoint_segredo', 'f3base_origem_confiavel' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array( 'rotulo' => 'Repositório privado f3base_leads', 'presente' => F3Base_Leads_Repositorio::pronto(), 'detalhe' => 'Registro permanente no Core; CF7 e Flamingo não são dependências.' ),
			array(
				'rotulo'   => __( 'Tabela de chaves do endpoint (dedup e rate limit)', 'f3base' ),
				'presente' => self::tabela_pronta(),
				'detalhe'  => self::tabela_pronta()
					? __( 'chave única no banco decide o empate entre replay e duplo clique, e o incremento do rate limit é uma instrução só.', 'f3base' )
					: sprintf(
						/* translators: %s: nome da tabela. */
						__( 'ausente ou sem a coluna estado: a deduplicação e o rate limit caem para transiente, que faz ler-modificar-gravar e perde incremento sob concorrência. Reative o plugin para que %s seja migrada.', 'f3base' ),
						self::nome_tabela()
					),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_LEAD, __( 'Último registro aceito', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_FALHA_LEAD, __( 'Última recusa de gravação', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$token = F3Base_Cache_Pagina::verificacao_tokens()['endpoint-leads'] ?? array();
		if ( 'failed' === ( $token['status'] ?? '' ) ) {
			return $this->degradado( 'A rota pública de token falhou na verificação: ' . implode( ', ', $token['problemas'] ) . '. Confira o cache e execute Verificar entrega pública.' ); }
		$falha  = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_LEAD );
		$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_LEAD );

		$em_falha  = isset( $falha['em'] ) ? (int) $falha['em'] : 0;
		$em_aceito = isset( $aceito['em'] ) ? (int) $aceito['em'] : 0;

		if ( $em_falha > 0 && $em_falha > $em_aceito ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: data e hora da recusa, 2: destinos que recusaram. */
					__( 'a tentativa mais recente NÃO foi gravada em %1$s (%2$s) e nenhuma entrou depois dela. A reserva de deduplicação foi liberada, então a próxima tentativa com a mesma correlação é aceita.', 'f3base' ),
					(string) wp_date( 'd/m/Y H:i', $em_falha ),
					isset( $falha['motivo'] ) && '' !== (string) $falha['motivo'] ? (string) $falha['motivo'] : __( 'motivo não registrado', 'f3base' )
				)
			);
		}

		if ( ! self::tabela_pronta() ) {
			return $this->degradado(
				sprintf(
					/* translators: %s: nome da tabela. */
					__( 'tabela %s ausente ou sem a coluna de estado da reserva: a deduplicação e o rate limit caem para transiente, e transiente faz ler-modificar-gravar — sob concorrência ele perde incremento e o balde deixa de segurar.', 'f3base' ),
					self::nome_tabela()
				)
			);
		}

		if ( ! F3Base_Leads_Repositorio::pronto() ) { return $this->degradado( 'Repositório f3base_leads ausente ou schema incompleto; consulte Operação.' ); }

		$origem = self::cabecalho_confiavel();

		if ( '' === $origem['cabecalho'] ) {
			return $this->ativo(
				__( 'gravação no repositório f3base_leads, com deduplicação decidida pela chave única do banco. O rate limit conta por REMOTE_ADDR: nenhum cabeçalho de proxy está declarado em f3base_origem_confiavel, e cabeçalho aceito sem declaração é o próprio visitante escolhendo o balde em que quer contar.', 'f3base' )
			);
		}

		/*
		 * SEM FAIXA DECLARADA O MÓDULO NÃO ESTÁ DEGRADADO: ele faz exatamente o
		 * que a configuração pede, que é ler o cabeçalho declarado. O que existe
		 * ali é um RISCO de configuração, e risco com o principal funcionando é
		 * aviso — `avisos()` o emite, nomeando o campo que o fecha. Degradar aqui
		 * poria em vermelho toda instalação que sempre funcionou assim, e
		 * vermelho que sai sempre treina quem opera a ignorar vermelho.
		 */
		if ( array() === $origem['redes_confiaveis'] ) {
			return $this->ativo(
				sprintf(
					/* translators: 1: nome do cabeçalho declarado, 2: posição contada do fim da cadeia. */
					__( 'gravação no repositório f3base_leads, com deduplicação decidida pela chave única do banco. O rate limit conta pela origem lida do cabeçalho declarado %1$s, na posição %2$d contada do fim da cadeia — 1 é o último elemento, que é o que o proxy da frente escreveu. Nenhuma faixa de IP de proxy está declarada, então o cabeçalho é lido de QUALQUER conexão; o aviso ao lado nomeia o risco e o campo que o fecha.', 'f3base' ),
					$origem['cabecalho'],
					$origem['saltos']
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: 1: nome do cabeçalho declarado, 2: posição contada do fim da cadeia, 3: faixas de proxy confiáveis. */
				__( 'gravação no repositório f3base_leads, com deduplicação decidida pela chave única do banco. O rate limit conta pela origem lida do cabeçalho declarado %1$s, na posição %2$d contada do fim da cadeia — 1 é o último elemento, que é o que o proxy da frente escreveu —, e só quando a conexão vem de %3$s. Fora dessa declaração a contagem volta a REMOTE_ADDR.', 'f3base' ),
				$origem['cabecalho'],
				$origem['saltos'],
				implode( ', ', $origem['redes_confiaveis'] )
			)
		);
	}

	/**
	 * {@inheritDoc}
	 *
	 * O CABEÇALHO DECLARADO SEM FAIXA DE PROXY continua sendo LIDO — é o
	 * comportamento que toda instalação já entregue tem, e trocá-lo numa
	 * atualização quebraria cada uma delas em silêncio. O preço dele é este
	 * aviso, e ele nomeia as duas coisas que quem opera o site precisa: o que
	 * pode acontecer, e o campo que fecha a porta.
	 *
	 * O RAMO ADVERSO EXISTE E É O CASO NORMAL: com as faixas declaradas, ou sem
	 * cabeçalho nenhum declarado, esta lista sai vazia. Aviso que sai sempre
	 * treina quem opera a ignorar aviso.
	 *
	 * @return array<int,array{estado:string,motivo:string}>
	 */
	public function avisos(): array {
		$origem = self::cabecalho_confiavel();

		if ( '' === $origem['cabecalho'] || array() !== $origem['redes_confiaveis'] ) {
			return array();
		}

		return array(
			array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: %s: nome do cabeçalho declarado. */
					__( 'o cabeçalho %s está declarado e nenhuma faixa de IP de proxy está: ele é lido de QUALQUER conexão. Cabeçalho é texto que qualquer cliente manda, e quem alcança a origem por fora da CDN — pelo IP, o que costuma responder — escolhe o balde do limite de envios e o endereço que o site manda ao fornecedor de anúncio. Declare em f3base_origem_confiavel.redes_confiaveis as faixas dos seus proxies: a partir daí só o pedido que vier delas tem o cabeçalho lido, e os outros voltam a contar pelo endereço da conexão.', 'f3base' ),
					$origem['cabecalho']
				),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function instalar(): void {
		self::criar_tabela();
		self::instalar_recusas();
		self::segredo();
	}

	/**
	 * Migra a tabela quando o pacote foi trocado sem passar pela ativação.
	 *
	 * A atualização de um plugin nem sempre reexecuta o hook de ativação, e a
	 * coluna que a 1.0.1 do site-core acrescentou é o que separa a reserva
	 * PENDENTE da firme. Sem ela o módulo cai para o transiente — que é honesto,
	 * mas não é atômico —, então a migração acontece uma vez, no carregamento
	 * seguinte, com guarda para não repetir a cada requisição.
	 *
	 * @return void
	 */
	public function garantir_estrutura(): void {
		self::instalar_recusas();
		if ( self::tabela_pronta() ) {
			return;
		}

		if ( false === set_transient( 'f3base_leads_migrando', 1, 15 * MINUTE_IN_SECONDS ) ) {
			return;
		}

		self::criar_tabela();
	}

	/* ------------------------------------------------------------------ *
	 * Superfície pública
	 * ------------------------------------------------------------------ */

	/**
	 * Registra a rota REST.
	 *
	 * @return void
	 */
	public function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'receber' ),
				'permission_callback' => '__return_true',
				'args'                => array(),
			)
		);

		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA_TOKEN,
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'emitir' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'pagina' => array(
						'type'        => 'string',
						'required'    => false,
						'default'     => '',
						'description' => __( 'Caminho da página em que o token será usado; é ele que define o escopo da assinatura.', 'f3base' ),
					),
				),
			)
		);
	}

	/**
	 * Emite um token novo para a página que pediu — o caminho da PÁGINA EM CACHE.
	 *
	 * Uma página servida do cache carrega o token que foi impresso quando ela foi
	 * gerada, e ele expira. Sem esta rota, todo beacon daquela página passava a
	 * voltar 403 e nada na tela dizia isso. Com ela, o cliente troca o token e
	 * reenvia uma vez.
	 *
	 * Emissão tem cota própria: páginas antigas em cache não consomem a cota
	 * de registros para renovar. Ambos os contadores permanecem limitados por origem.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function emitir( WP_REST_Request $requisicao ): WP_REST_Response {
		if ( ! self::dentro_do_limite_token() ) {
			return self::resposta(
				429,
				array(
					'ok'     => false,
					'codigo' => 'f3base_rate_limit',
					'motivo' => __( 'Limite de pedidos por janela excedido para esta origem.', 'f3base' ),
				)
			);
		}

		$caminho = self::caminho_interno( (string) $requisicao->get_param( 'pagina' ) );

		return self::resposta(
			200,
			array(
				'ok'         => true,
				'token'      => self::emitir_token( $caminho ),
				'escopo'     => self::escopo_do_token( $caminho ),
				'ttl'        => self::ttl_token(),
				'emitido_em' => time(),
				'emissao_id' => wp_generate_uuid4(),
			)
		);
	}

	/**
	 * Recebe o beacon do clique.
	 *
	 * @param WP_REST_Request $requisicao Requisição REST.
	 * @return WP_REST_Response
	 */
	public function receber( WP_REST_Request $requisicao ): WP_REST_Response {
		$bruto = $requisicao->get_json_params();
		if ( ! is_array( $bruto ) ) {
			$bruto = $requisicao->get_body_params();
		}
		if ( ! is_array( $bruto ) ) {
			$bruto = array();
		}

		$campos = self::campos();

		// Schema fechado: campo desconhecido é recusado pelo nome, nunca ignorado.
		foreach ( array_keys( $bruto ) as $chave ) {
			if ( ! isset( $campos[ (string) $chave ] ) ) {
				return self::resposta(
					400,
					array(
						'ok'     => false,
						'codigo' => 'f3base_campo_desconhecido',
						'campo'  => sanitize_key( (string) $chave ),
						'motivo' => __( 'Campo fora do schema fechado do endpoint.', 'f3base' ),
					)
				);
			}
		}

		// Honeypot: preenchido significa automação. Nada é gravado.
		if ( isset( $bruto['website'] ) && ! is_scalar( $bruto['website'] ) ) {
			return self::resposta(
				400,
				array(
					'ok'     => false,
					'codigo' => 'f3base_tipo_invalido',
					'campo'  => 'website',
				)
			); }
		$honeypot = isset( $bruto['website'] ) ? trim( (string) $bruto['website'] ) : '';
		if ( '' !== $honeypot ) {
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'motivo'     => 'honeypot',
				)
			);
		}

		/*
		 * O ESCOPO SAI DA PÁGINA DECLARADA NO PAYLOAD, e por isso ele é lido
		 * ANTES da validação de campos: a assinatura do token cobre a rota e o
		 * caminho, então não há como conferi-la sem saber de qual página o
		 * clique veio. O caminho passa pelo mesmo redutor do campo `pagina` —
		 * um só lugar decide o que é caminho deste site.
		 */
		$caminho_do_clique = self::caminho_interno( isset( $bruto['pagina'] ) && is_scalar( $bruto['pagina'] ) ? (string) $bruto['pagina'] : '' );

		if ( ! self::validar_token( isset( $bruto['token'] ) && is_string( $bruto['token'] ) ? $bruto['token'] : '', $caminho_do_clique ) ) {
			/*
			 * A RECUSA POR TOKEN PASSOU A CARIMBAR, e o defeito que isso fecha é
			 * de silêncio: uma página em cache mais velha que o token fazia TODO
			 * beacon voltar 403, e nada na tela do operador mudava — o módulo
			 * continuava verde porque só a falha de GRAVAÇÃO era registrada. O
			 * carimbo nomeia a página, que é o que se precisa saber para
			 * descobrir que o problema é o cache dela.
			 */
			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_FALHA_LEAD,
				array(
					'destino' => 'f3base_token_invalido',
					'pagina'  => $caminho_do_clique,
					'motivo'  => __( 'token efêmero ausente, expirado ou fora do escopo da página: o cliente pede um token novo em /token e reenvia uma vez. Recusa que persiste indica página servida de cache mais velho que o prazo do token.', 'f3base' ),
				)
			);

			return self::resposta(
				403,
				array(
					'ok'     => false,
					'codigo' => 'f3base_token_invalido',
					'rota'   => F3BASE_REST_NAMESPACE . self::ROTA_TOKEN,
					'motivo' => __( 'Token efêmero ausente, expirado ou fora do escopo desta página. Peça um token novo na rota de emissão e reenvie uma vez.', 'f3base' ),
				)
			);
		}

		if ( ! self::dentro_do_rate_limit() ) {
			return self::resposta(
				429,
				array(
					'ok'     => false,
					'codigo' => 'f3base_rate_limit',
					'motivo' => __( 'Limite de registros por janela excedido para esta origem.', 'f3base' ),
				)
			);
		}

		$validado = self::validar_campos( $bruto, $campos );
		if ( isset( $validado['erro'] ) ) {
			return self::resposta( 400, $validado['erro'] );
		}

		$dados = $validado['dados'];
		if ( ! empty( $dados['correlacao'] ) && $dados['correlacao'] !== $dados['correlation_id'] ) { return self::resposta( 400, array( 'ok' => false, 'codigo' => 'correlacao_conflitante' ) ); }
		$dados['correlacao'] = $dados['correlation_id'];
		if ( ! empty( $dados['destino'] ) && 'invalido' === F3Base_Leads_Contexto::destino( $dados['destino'] )['tipo'] ) { return self::resposta( 400, array( 'ok' => false, 'codigo' => 'destino_invalido' ) ); }

		/*
		 * O ESTADO REAL DO CONSENTIMENTO, e não o portão que o navegador mandou.
		 * `consentimento: true` é o que o cliente responde quando NINGUÉM decidiu
		 * e a política é pré-aprovada — arquivar isso como "sim" põe no registro
		 * de todo lead uma decisão que o titular não tomou. O vocabulário fechado
		 * de três valores mora no módulo de consentimento, que é quem conhece a
		 * política, e o valor declarado pelo cliente entra como a metade
		 * RESTRITIVA: ele pode dizer "não" (o beacon pode ter viajado sem o
		 * cookie), nunca promover a ausência de decisão a consentimento.
		 */
		$dados['consentimento_estado'] = class_exists( 'F3Base_Modulo_Consentimento' )
			? F3Base_Modulo_Consentimento::estado_medido( array_key_exists( 'consentimento', $bruto ) ? (bool) $dados['consentimento'] : null )
			: F3Base_Modulo_Consentimento::ESTADO_PADRAO;

		$record_id = self::gerar_record_id();
		$reserva   = self::reservar( (string) $dados['correlation_id'], $record_id );

		/*
		 * FALHA DE BANCO NÃO É DUPLICATA. O `INSERT` da reserva roda com os erros
		 * silenciados porque a colisão de chave única é o caminho ESPERADO, e o
		 * ramo adverso lia a linha existente para devolver o `record_id` dela. Se
		 * o `INSERT` falhasse por outro motivo — tabela ausente, disco cheio,
		 * coluna divergente depois de uma migração pela metade —, não havia linha
		 * nenhuma para ler, e a rota respondia `200 duplicado:true` com
		 * `record_id` VAZIO: o cliente apagava o lead da fila como já registrado,
		 * e nada tinha sido escrito. Sem linha atrás da recusa, a recusa é do
		 * armazenamento e sai como tal.
		 */
		if ( ! $reserva['novo'] && '' === (string) $reserva['record_id'] ) {
			self::liberar_reserva( (string) $dados['correlation_id'] );

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_FALHA_LEAD,
				array(
					'record_id'  => $record_id,
					'destino'    => self::nome_tabela(),
					'formulario' => (string) $dados['formulario'],
					'motivo'     => __( 'a reserva de deduplicação não pôde ser gravada e não existe reserva anterior para esta correlação: a recusa é do armazenamento, e não de duplicata.', 'f3base' ),
				)
			);

			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_reserva_indisponivel',
					'destino'    => self::nome_tabela(),
					'motivo'     => __( 'A tabela de chaves do endpoint recusou a reserva e não há registro anterior desta correlação: nada foi gravado. Basta reenviar. A conversa no WhatsApp continua valendo como fonte da verdade do lead.', 'f3base' ),
				)
			);
		}

		if ( ! $reserva['novo'] ) {
			return self::resposta(
				200,
				array(
					'ok'         => true,
					'registrado' => false,
					'duplicado'  => true,
					'record_id'  => $reserva['record_id'],
					'motivo'     => __( 'Correlação já registrada: replay ou duplo clique.', 'f3base' ),
				)
			);
		}

		$gravacao = self::gravar_lead( $dados, $record_id );

		/*
		 * NADA É REGISTRADO ANTES DA PERSISTÊNCIA. A atividade que carimba
		 * "último registro aceito" com o destino da gravação que falhou faz a
		 * tela do site-core apontar para onde nada foi escrito — e 201 Created
		 * com `ok:false` diz ao cliente que o recurso existe quando ele não
		 * existe. Os dois ramos saem separados, e o adverso compensa a reserva.
		 */
		if ( ! $gravacao['ok'] ) {
			self::liberar_reserva( (string) $dados['correlation_id'] );

			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMA_FALHA_LEAD,
				array(
					'record_id'  => $record_id,
					'destino'    => $gravacao['destino'],
					'formulario' => (string) $dados['formulario'],
					'motivo'     => (string) $gravacao['motivo'],
				)
			);

			return self::resposta(
				503,
				array(
					'ok'         => false,
					'registrado' => false,
					'codigo'     => 'f3base_gravacao_indisponivel',
					'record_id'  => $record_id,
					'destino'    => $gravacao['destino'],
					'motivo'     => __( 'Nenhum destino aceitou o registro: nada foi gravado. A reserva de deduplicação foi liberada, então basta reenviar — a próxima tentativa com a mesma correlação é aceita. A conversa no WhatsApp continua valendo como fonte da verdade do lead.', 'f3base' ),
				)
			);
		}

		self::confirmar_reserva( (string) $dados['correlation_id'], $record_id );

		/*
		 * O EVENTO DE SERVIDOR DA META SÓ EXISTE DEPOIS DAQUI, e a posição é a
		 * regra. A transação lógica desta rota termina na linha acima: a reserva
		 * está firme porque o lead está gravado. Agendar o envio antes disso
		 * mandaria à Meta uma conversão de um lead que pode não existir — e a
		 * Meta não tem como desfazer o que recebeu.
		 *
		 * `agendar()` NÃO faz rede: ela guarda o payload e marca um evento único
		 * para a requisição seguinte. Sem token ela devolve o motivo NOMEADO e
		 * segue — a Meta não tem voto sobre o status de um lead, e o resultado
		 * do envio é assunto do carimbo do próprio módulo.
		 *
		 * O CONSENTIMENTO MEDIDO VAI JUNTO, e é o mesmo portão do navegador. O
		 * payload da Conversions API leva `em`, `ph`, `client_ip_address`, `fbc`
		 * e `fbp` — dado pessoal, ainda que hasheado — e ele era agendado sem
		 * ninguém perguntar pelo consentimento: o visitante que recusou a medição
		 * no controle do rodapé via o Pixel calar no navegador e o servidor
		 * mandar a mesma conversão pelas costas. Quem decide é o estado, aqui,
		 * porque é aqui que ele é medido; `agendar()` só recusa com o motivo.
		 */
		$capi = class_exists( 'F3Base_Modulo_Meta_Capi' )
			? F3Base_Modulo_Meta_Capi::agendar(
				$dados,
				$record_id,
				self::origem()['valor'],
				F3Base_Modulo_Consentimento::estado_permite_tags( (string) $dados['consentimento_estado'] ) && F3Base_Modulo_Consentimento::permite_categoria( 'publicidade' )
			)
			: array(
				'agendado' => false,
				'motivo'   => __( 'N/A: o módulo da Conversions API não está carregado nesta instalação.', 'f3base' ),
			);

		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMO_LEAD,
			array(
				'record_id'  => $record_id,
				'destino'    => $gravacao['destino'],
				'formulario' => (string) $dados['formulario'],
				'meta_capi'  => (string) $capi['motivo'],
			)
		);

		return self::resposta(
			201,
			array(
				'ok'         => true,
				'registrado' => true,
				'record_id'  => $record_id,
				'destino'    => $gravacao['destino'],
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Schema fechado
	 * ------------------------------------------------------------------ */

	/**
	 * Schema fechado do endpoint: um campo, um tipo, um limite.
	 *
	 * @return array<string,array{tipo:string,max:int,obrigatorio?:bool,regex?:string}>
	 */
	public static function campos(): array {
		return array(
			'token'          => array(
				'tipo'        => 'token',
				'max'         => 200,
				'obrigatorio' => true,
			),
			'correlation_id' => array(
				'tipo'        => 'identificador',
				'max'         => 64,
				'obrigatorio' => true,
				'regex'       => '/^[A-Za-z0-9_-]{8,64}$/',
			),
			/*
			 * O CARIMBO DE TEMPO DO CLIQUE é a chave da correlação com a
			 * conversa do WhatsApp, e por isso ele é campo do schema e não
			 * enfeite. A mensagem do `wa.me` não leva código nenhum — quem
			 * recebe leria um identificador que não significa nada para ela —,
			 * e o casamento entre o clique registrado aqui e a conversa que
			 * chegou lá é feito por data e hora, fora do site.
			 *
			 * Duas formas de propósito: a legível, com o fuso explícito, para
			 * quem compara as duas listas com os olhos; e a de milissegundos,
			 * para quem compara por programa. Ambas do NAVEGADOR, que é onde o
			 * clique aconteceu — o relógio do servidor pode estar em outro fuso
			 * e a diferença apareceria justamente na hora de casar.
			 */
			'consentimento_medicao' => array( 'tipo' => 'booleano', 'max' => 10 ),
            'navegacao' => array('tipo'=>'identificador','max'=>32,'regex'=>'/^[a-f0-9]{32}$/D'),
            'dispositivo' => array('tipo'=>'texto','max'=>16),
            'cta' => array('tipo'=>'texto','max'=>80),
            'sessao' => array( 'tipo' => 'identificador', 'max' => 32, 'regex' => '/^[a-f0-9]{32}$/D' ),
			'correlacao' => array( 'tipo' => 'identificador', 'max' => 64, 'regex' => '/^[A-Za-z0-9_-]{8,64}$/D' ),
			'destino' => array( 'tipo' => 'destino', 'max' => 2048 ),
			'clicado_em'     => array(
				'tipo'  => 'identificador',
				'max'   => 32,
				'regex' => '/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,3})?Z$/',
			),
			'clicado_em_ms'  => array(
				'tipo'  => 'identificador',
				'max'   => 20,
				'regex' => '/^[0-9]{1,20}$/',
			),
			'formulario'     => array(
				'tipo' => 'slug',
				'max'  => 64,
			),
			'nome'           => array(
				'tipo' => 'texto',
				'max'  => 120,
			),
			'email'          => array(
				'tipo' => 'email',
				'max'  => 190,
			),
			'telefone'       => array(
				'tipo' => 'telefone',
				'max'  => 40,
			),
			'mensagem'       => array(
				'tipo' => 'texto_longo',
				'max'  => 2000,
			),
			'pagina'         => array(
				'tipo' => 'url_interna',
				'max'  => 500,
			),
			'consentimento'  => array(
				'tipo' => 'booleano',
				'max'  => 8,
			),
			/*
			 * O `max` DA ATRIBUIÇÃO É APLICADO, e por isso ele é derivado. Ele
			 * valia 8 e não era conferido em lugar nenhum — o ramo do tipo
			 * `atribuicao` sai do laço antes da guarda de comprimento —, então o
			 * número publicado ao navegador descrevia um limite inexistente. O
			 * que existe para conferir num sub-objeto é a QUANTIDADE DE CHAVES, e
			 * ela sai da lista fechada: é a segunda tranca atrás da primeira, e a
			 * primeira é a recusa por chave desconhecida.
			 */
			'atribuicao'     => array(
				'tipo' => 'atribuicao',
				'max'  => 16,
			),
			'website'        => array(
				'tipo' => 'honeypot',
				'max'  => 0,
			),
		);
	}

	/**
	 * Limites por campo publicados para o navegador — só os que são APLICADOS.
	 *
	 * O DEFEITO MEDIDO: a lista publicava `atribuicao => 8`, e o servidor não
	 * media coisa nenhuma com aquele número — o ramo do sub-objeto sai do laço
	 * antes da guarda de comprimento. Um limite publicado que ninguém aplica é
	 * pior que limite nenhum: o cliente corta por ele achando que evita a
	 * recusa, e a recusa que ele evitaria não existia. O que sai daqui é o
	 * conjunto de campos ESCALARES do schema, que são exatamente aqueles cujo
	 * `max` a validação confere em caracteres antes de qualquer outra coisa.
	 *
	 * O limite do sub-objeto continua existindo e continua sendo aplicado — na
	 * quantidade de chaves, e por chave em `campos_atribuicao()` —; ele só não é
	 * um número de caracteres, e por isso não cabe nesta lista.
	 *
	 * @return array<string,int> Nome do campo => limite em caracteres, aplicado.
	 */
	public static function limites_publicos(): array {
		$limites = array();

		foreach ( self::campos() as $nome => $definicao ) {
			if ( in_array( $definicao['tipo'], array( 'token', 'honeypot', 'atribuicao' ), true ) ) {
				continue;
			}
			$limites[ $nome ] = (int) $definicao['max'];
		}

		return $limites;
	}

	/**
	 * A JANELA em que dois cliques no mesmo CTA são a MESMA interação.
	 *
	 * Ela morava dentro do JavaScript, valia cinco segundos, e cinco segundos é
	 * menos do que alguém leva para clicar, olhar o que abriu, voltar e clicar
	 * de novo: o segundo clique nascia com outra correlação, e o resultado eram
	 * dois leads na caixa, duas reservas de deduplicação e a mesma conversão
	 * contada duas vezes em todos os fornecedores — com `event_id` diferente,
	 * que é justamente o que impede a Meta de deduplicar.
	 *
	 * O número sai daqui porque o outro lado desta decisão também é daqui: é
	 * esta janela que dá sentido ao prazo da reserva de deduplicação, e um
	 * número escrito no cliente é um número que ninguém revisa junto com o do
	 * servidor. O teto de uma hora existe porque a correlação vive na PÁGINA:
	 * mais que isso e ela passa a valer entre navegações que já não são a mesma
	 * interação.
	 *
	 * @return int Segundos.
	 */
	public static function janela_de_correlacao(): int {
		$janela = (int) apply_filters( 'f3base_lead_janela_correlacao', MINUTE_IN_SECONDS );

		return max( 5, min( HOUR_IN_SECONDS, $janela ) );
	}

	/**
	 * Sub-chaves aceitas em `atribuicao`. Fechado como o resto.
	 *
	 * OS IDENTIFICADORES DE CLIQUE ENTRARAM NA 1.1.0, e o motivo é medido: o
	 * schema é fechado e recusa campo desconhecido com 400 nomeando a chave —
	 * acrescentar `gclid` só no cliente faria TODO lead de tráfego pago voltar
	 * recusado, que é o pior modo de falhar que este endpoint tem. Os dois lados
	 * mudam juntos, e é por isso que esta lista está aqui e não em dois lugares.
	 *
	 * Quem é cada um: `gclid`, `gbraid` e `wbraid` vêm do Google Ads (o segundo
	 * e o terceiro são os identificadores de app e de web sem cookie);
	 * `msclkid` é o do Microsoft Advertising, que chega pelo mesmo caminho;
	 * `fbclid` vem do Meta Ads e `fbc`/`fbp` são os cookies que a Meta espera
	 * receber de volta na Conversions API; `li_fat_id` é o do LinkedIn Ads.
	 *
	 * @return array<string,int> Chave para limite de caracteres.
	 */
	public static function campos_atribuicao(): array {
		return array(
			'fonte'             => 120,
			'meio'              => 120,
			'campanha'          => 160,
			'termo'             => 160,
			'conteudo'          => 160,
			'referrer'          => 500,
			'primeiro_toque_em' => 20,
			'modelo'            => 40,
			'gclid'             => 200,
			'gbraid'            => 200,
			'wbraid'            => 200,
			'msclkid'           => 200,
			'fbclid'            => 400,
			'fbc'               => 200,
			'fbp'               => 120,
			'li_fat_id'         => 120,
		);
	}

	/**
	 * Valida e normaliza os campos do payload.
	 *
	 * @param array<string,mixed>                         $bruto  Payload cru.
	 * @param array<string,array<string,mixed>>           $campos Schema fechado.
	 * @return array{dados?:array<string,mixed>,erro?:array<string,mixed>}
	 */
	private static function validar_campos( array $bruto, array $campos ): array {
		$dados = array(
			'correlation_id' => '',
			'formulario'     => '',
			'nome'           => '',
			'email'          => '',
			'telefone'       => '',
			'mensagem'       => '',
			'pagina'         => '',
			'clicado_em'     => '',
			'clicado_em_ms'  => '',
			'consentimento'  => false,
			'atribuicao'     => array(),
		);

		foreach ( $campos as $nome => $definicao ) {
			if ( in_array( $definicao['tipo'], array( 'token', 'honeypot' ), true ) ) {
				continue;
			}

			$presente = array_key_exists( $nome, $bruto );
			$valor    = $presente ? $bruto[ $nome ] : null;

			if ( ! empty( $definicao['obrigatorio'] ) && ( ! $presente || '' === $valor || null === $valor ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_campo_obrigatorio',
						'campo'  => $nome,
						'motivo' => __( 'Campo obrigatório ausente no payload.', 'f3base' ),
					),
				);
			}

			if ( ! $presente ) {
				continue;
			}

			if ( 'atribuicao' === $definicao['tipo'] ) {
				$atribuicao = self::validar_atribuicao( $valor );
				if ( isset( $atribuicao['erro'] ) ) {
					return array( 'erro' => $atribuicao['erro'] );
				}
				$dados['atribuicao'] = $atribuicao['dados'];
				continue;
			}

			/*
			 * A GUARDA DE ESTRUTURA E A DE LIMITE VÊM ANTES DO DESPACHO POR TIPO.
			 * Enquanto o booleano tinha ramo próprio com `continue`, ele pulava
			 * as duas: `{"consentimento":{}}` virava `true` e o `max` de 8 do
			 * schema era letra morta. Guarda que só vale para alguns tipos é
			 * guarda que o tipo seguinte descobre que não existe.
			 */
			if ( is_array( $valor ) || is_object( $valor ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_tipo_invalido',
						'campo'  => $nome,
						'motivo' => __( 'Campo escalar recebeu estrutura.', 'f3base' ),
					),
				);
			}

			$texto = self::escalar_para_texto( $valor );

			/*
			 * O limite é medido em CARACTERES, que é a unidade que o cliente
			 * corta (`f3base-leads.js`) e a unidade que `limites_publicos()`
			 * publica para ele. Medido em bytes, "José de Sá" ocupava mais do
			 * que o navegador contou e o servidor recusava com 400 o lead que a
			 * própria página tinha aprovado — em português, sempre.
			 */
			if ( self::comprimento( $texto ) > (int) $definicao['max'] ) {
				return array(
					'erro' => array(
						'ok'      => false,
						'codigo'  => 'f3base_limite_excedido',
						'campo'   => $nome,
						'limite'  => (int) $definicao['max'],
						'unidade' => 'caracteres',
						'motivo'  => __( 'Campo excedeu o limite declarado, medido em caracteres: recusado, nunca truncado em silêncio.', 'f3base' ),
					),
				);
			}

			if ( isset( $definicao['regex'] ) && '' !== $texto && ! preg_match( (string) $definicao['regex'], $texto ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_formato_invalido',
						'campo'  => $nome,
						'motivo' => __( 'Campo não casa com o formato declarado.', 'f3base' ),
					),
				);
			}

			if ( 'booleano' === $definicao['tipo'] ) {
				$booleano = self::interpretar_booleano( $texto );

				if ( null === $booleano ) {
					return array(
						'erro' => array(
							'ok'      => false,
							'codigo'  => 'f3base_valor_invalido',
							'campo'   => $nome,
							'aceitos' => array_merge( self::BOOLEANO_VERDADEIRO, self::BOOLEANO_FALSO ),
							'motivo'  => __( 'Campo booleano recebeu valor fora do vocabulário declarado. Em formulário urlencoded todo valor chega string, e converter string em booleano por molde da linguagem faz "false" valer true — no campo de consentimento isso arquiva como consentido quem não consentiu.', 'f3base' ),
						),
					);
				}

				$dados[ $nome ] = $booleano;
				continue;
			}

			$conclusao = self::inconclusivo( $definicao['tipo'], $texto );

			if ( '' !== $conclusao ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_formato_invalido',
						'campo'  => $nome,
						'motivo' => $conclusao,
					),
				);
			}

			$dados[ $nome ] = self::normalizar( $definicao['tipo'], $texto );
		}

		return array( 'dados' => $dados );
	}

	/**
	 * Texto de um valor escalar, sem o molde surpreendente da linguagem.
	 *
	 * `(string) false` é a string vazia e `(string) true` é "1": os dois entram
	 * no vocabulário fechado do parser de booleano pelo lado certo, e nenhum
	 * outro tipo escalar muda de forma no caminho.
	 *
	 * @param mixed $valor Valor recebido.
	 * @return string
	 */
	private static function escalar_para_texto( $valor ): string {
		if ( is_bool( $valor ) ) {
			return $valor ? '1' : '0';
		}

		if ( null === $valor ) {
			return '';
		}

		return (string) $valor;
	}

	/**
	 * Comprimento em CARACTERES — a unidade publicada em `limites_publicos()`.
	 *
	 * @param string $texto Texto medido.
	 * @return int
	 */
	public static function comprimento( string $texto ): int {
		if ( function_exists( 'mb_strlen' ) ) {
			return (int) mb_strlen( $texto, 'UTF-8' );
		}

		$contagem = preg_match_all( '/./us', $texto );

		return is_int( $contagem ) ? $contagem : strlen( $texto );
	}

	/**
	 * Parser explícito de booleano, com vocabulário fechado.
	 *
	 * Devolve `null` quando o valor não pertence a nenhum dos dois vocabulários:
	 * o schema deste endpoint é fechado, e valor de consentimento que ninguém
	 * sabe ler é recusado, nunca adivinhado.
	 *
	 * @param string $texto Valor já reduzido a texto.
	 * @return bool|null
	 */
	public static function interpretar_booleano( string $texto ): ?bool {
		$normal = trim( $texto );
		$normal = function_exists( 'mb_strtolower' ) ? mb_strtolower( $normal, 'UTF-8' ) : strtolower( $normal );

		if ( in_array( $normal, self::BOOLEANO_VERDADEIRO, true ) ) {
			return true;
		}

		if ( in_array( $normal, self::BOOLEANO_FALSO, true ) ) {
			return false;
		}

		return null;
	}

	/**
	 * Motivo pelo qual um valor NÃO é conclusivo para o tipo declarado.
	 *
	 * Devolve string vazia quando o valor passa. Existe porque `sanitize_email()`
	 * devolve string vazia para entrada inválida: sem conferir o retorno, o lead
	 * era aceito com e-mail vazio respondendo 201 e ninguém tinha como responder
	 * ao visitante.
	 *
	 * @param string $tipo  Tipo declarado no schema fechado.
	 * @param string $texto Valor recebido.
	 * @return string
	 */
	public static function inconclusivo( string $tipo, string $texto ): string {
		if ( 'email' !== $tipo || '' === trim( $texto ) ) {
			return '';
		}

		$limpo = sanitize_email( $texto );

		if ( '' === $limpo || false === is_email( $limpo ) ) {
			return __( 'E-mail inválido: a sanitização devolveria string vazia e o lead entraria sem endereço nenhum, com resposta de sucesso.', 'f3base' );
		}

		return '';
	}

	/**
	 * Valida o sub-objeto de atribuição, também fechado por chave.
	 *
	 * @param mixed $valor Valor bruto.
	 * @return array{dados?:array<string,string>,erro?:array<string,mixed>}
	 */
	private static function validar_atribuicao( $valor ): array {
		if ( null === $valor || '' === $valor ) {
			return array( 'dados' => array() );
		}

		if ( ! is_array( $valor ) ) {
			return array(
				'erro' => array(
					'ok'     => false,
					'codigo' => 'f3base_tipo_invalido',
					'campo'  => 'atribuicao',
					'motivo' => __( 'Atribuição precisa ser um objeto de chaves declaradas.', 'f3base' ),
				),
			);
		}

		$aceitos = self::campos_atribuicao();
		$saida   = array();

		/*
		 * A QUANTIDADE DE CHAVES É O LIMITE APLICADO deste campo, e ele é o que
		 * `limites_publicos()` deixou de publicar sem aplicar. A lista fechada
		 * já recusa chave desconhecida uma a uma; esta guarda é a que continua
		 * de pé no dia em que alguém acrescentar um ramo de aceitação e esquecer
		 * do teto — e é ela que torna o número do schema uma afirmação medida.
		 */
		$teto_de_chaves = (int) self::campos()['atribuicao']['max'];

		if ( count( $valor ) > $teto_de_chaves ) {
			return array(
				'erro' => array(
					'ok'      => false,
					'codigo'  => 'f3base_limite_excedido',
					'campo'   => 'atribuicao',
					'limite'  => $teto_de_chaves,
					'unidade' => 'chaves',
					'motivo'  => __( 'Atribuição com mais chaves do que o schema fechado declara.', 'f3base' ),
				),
			);
		}

		foreach ( $valor as $chave => $item ) {
			$chave = (string) $chave;

			if ( ! isset( $aceitos[ $chave ] ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_campo_desconhecido',
						'campo'  => 'atribuicao.' . sanitize_key( $chave ),
						'motivo' => __( 'Chave de atribuição fora do schema fechado.', 'f3base' ),
					),
				);
			}

			if ( is_array( $item ) || is_object( $item ) ) {
				return array(
					'erro' => array(
						'ok'     => false,
						'codigo' => 'f3base_tipo_invalido',
						'campo'  => 'atribuicao.' . $chave,
						'motivo' => __( 'Chave de atribuição escalar recebeu estrutura.', 'f3base' ),
					),
				);
			}

			$texto = self::escalar_para_texto( $item );

			if ( self::comprimento( $texto ) > $aceitos[ $chave ] ) {
				return array(
					'erro' => array(
						'ok'      => false,
						'codigo'  => 'f3base_limite_excedido',
						'campo'   => 'atribuicao.' . $chave,
						'limite'  => $aceitos[ $chave ],
						'unidade' => 'caracteres',
						'motivo'  => __( 'Chave de atribuição excedeu o limite declarado, medido em caracteres.', 'f3base' ),
					),
				);
			}

			$saida[ $chave ] = 'referrer' === $chave ? esc_url_raw( $texto ) : sanitize_text_field( $texto );
		}

		return array( 'dados' => $saida );
	}

	/**
	 * Normaliza um valor conforme o tipo declarado.
	 *
	 * @param string $tipo  Tipo do campo.
	 * @param string $texto Valor cru.
	 * @return string
	 */
	private static function normalizar( string $tipo, string $texto ): string {
		switch ( $tipo ) {
			case 'email':
				return sanitize_email( $texto );
			case 'slug':
				return sanitize_key( $texto );
			case 'destino':
				return esc_url_raw( $texto, array( 'http', 'https', 'mailto', 'tel', 'whatsapp' ) );
			case 'identificador':
				return $texto;
			case 'telefone':
				$limpo = preg_replace( '/[^0-9+()\s-]/', '', $texto );
				return is_string( $limpo ) ? trim( $limpo ) : '';
			case 'texto_longo':
				return sanitize_textarea_field( $texto );
			case 'url_interna':
				return self::caminho_interno( $texto );
			default:
				return sanitize_text_field( $texto );
		}
	}

	/**
	 * Reduz uma URL recebida ao caminho do próprio site.
	 *
	 * PÚBLICA porque o escopo do token depende dela: quem EMITE o token — o
	 * módulo do CTA, no enfileiramento — precisa reduzir a URL da requisição
	 * corrente pelo MESMO redutor que reduz o campo `pagina` do payload. Dois
	 * redutores produziriam dois escopos para a mesma página, e todo beacon
	 * daquela página voltaria 403.
	 *
	 * @param string $url URL bruta.
	 * @return string Caminho do próprio site, ou vazio.
	 */
	public static function caminho_interno( string $url ): string {
		$url = trim( $url );
		if ( '' === $url ) {
			return '';
		}

		$partes = wp_parse_url( $url );
		if ( ! is_array( $partes ) ) {
			return '';
		}

		if ( isset( $partes['host'] ) ) {
			$casa = wp_parse_url( home_url( '/' ) );
			$alvo = strtolower( (string) $partes['host'] );
			$meu  = is_array( $casa ) && isset( $casa['host'] ) ? strtolower( (string) $casa['host'] ) : '';

			if ( '' === $meu || $alvo !== $meu ) {
				return '';
			}
		}

		$caminho = isset( $partes['path'] ) ? (string) $partes['path'] : '/';
		if ( isset( $partes['query'] ) && '' !== $partes['query'] ) {
			$caminho .= '?' . (string) $partes['query'];
		}

		/*
		 * SEM CORTE PRÓPRIO AQUI. O limite do campo `pagina` é o do schema
		 * fechado, medido em caracteres antes desta função, e a sanitização só
		 * encurta — um segundo corte, em outra unidade, seria uma segunda fonte
		 * para o mesmo fato, e o corte por byte era exatamente o defeito que a
		 * 1.0.18 tirou do outro lado.
		 */
		return sanitize_text_field( $caminho );
	}

	/* ------------------------------------------------------------------ *
	 * Token efêmero assinado
	 * ------------------------------------------------------------------ */

	/**
	 * TTL do token efêmero, em segundos. UMA HORA, e o número é declarado.
	 *
	 * Ele valia doze horas, e doze horas de um bearer impresso em toda página é
	 * meio dia de autorização para qualquer POST vindo de qualquer lugar. O
	 * prazo curto só é praticável porque a página em cache tem tratamento
	 * explícito — a rota de emissão e o reenvio único do cliente —, e é essa
	 * dupla que substitui "dar prazo longo e torcer".
	 *
	 * O teto do filtro caiu junto: sete dias fazia do filtro uma porta para
	 * desfazer a decisão inteira sem que nada acusasse.
	 *
	 * @return int
	 */
	public static function ttl_token(): int {
		$ttl = (int) apply_filters( 'f3base_token_lead_ttl', HOUR_IN_SECONDS );

		return max( 300, min( DAY_IN_SECONDS, $ttl ) );
	}

	/**
	 * O ESCOPO de um token: a rota que ele autoriza e a página que o recebeu.
	 *
	 * O token assinava só a expiração, e assinatura que só cobre o prazo
	 * autoriza tudo o que couber dentro do prazo: o mesmo valor servia para o
	 * registro de lead vindo de qualquer página. Amarrar o caminho da página faz
	 * o token colhido numa página valer só para os cliques daquela página.
	 *
	 * A QUERY STRING FICA DE FORA, e isso é decisão: o token é impresso pelo
	 * servidor com o caminho da página, e o navegador manda `pathname + search`
	 * — com os UTM da campanha dentro. Incluir a query faria todo lead de
	 * tráfego pago cair no escopo errado, que é o pior modo de falhar que este
	 * endpoint tem.
	 *
	 * @param string $caminho Caminho da página, já reduzido ao próprio site.
	 * @return string Escopo normalizado.
	 */
	public static function escopo_do_token( string $caminho ): string {
		$sem_query = explode( '?', $caminho, 2 )[0];
		$sem_query = explode( '#', $sem_query, 2 )[0];
		$sem_query = '/' . ltrim( trim( $sem_query ), '/' );
		$sem_query = '/' === $sem_query ? '/' : rtrim( $sem_query, '/' );

		return self::ROTA . '|' . $sem_query;
	}

	/**
	 * Emite um token efêmero assinado: expiração E escopo, sob a mesma assinatura.
	 *
	 * @param string $caminho Caminho da página em que o token será usado.
	 * @return string
	 */
	public static function emitir_token( string $caminho = '' ): string {
		$expira = time() + self::ttl_token();

		return $expira . '.' . self::assinar( $expira . '|' . self::escopo_do_token( $caminho ) );
	}

	/**
	 * Valida um token efêmero contra o escopo da página que o apresentou.
	 *
	 * @param string $token   Token recebido.
	 * @param string $caminho Caminho da página declarado no payload.
	 * @return bool
	 */
	public static function validar_token( string $token, string $caminho = '' ): bool {
		if ( '' === $token || ! str_contains( $token, '.' ) ) {
			return false;
		}

		$partes = explode( '.', $token, 2 );
		$expira = $partes[0];
		$assina = $partes[1];

		if ( ! ctype_digit( $expira ) ) {
			return false;
		}

		$agora = time();
		$fim   = (int) $expira;

		if ( $fim < $agora ) {
			return false;
		}

		if ( $fim > $agora + self::ttl_token() + MINUTE_IN_SECONDS ) {
			return false;
		}

		return hash_equals( self::assinar( $expira . '|' . self::escopo_do_token( $caminho ) ), $assina );
	}

	/**
	 * Assina um payload com o segredo do endpoint.
	 *
	 * @param string $payload Conteúdo assinado.
	 * @return string
	 */
	private static function assinar( string $payload ): string {
		return hash_hmac( 'sha256', $payload, self::segredo() );
	}

	/**
	 * Segredo HMAC do endpoint, gerado uma vez.
	 *
	 * @return string
	 */
	private static function segredo(): string {
		$segredo = F3Base_Options::ler( 'f3base_endpoint_segredo' );
		$segredo = is_string( $segredo ) ? $segredo : '';

		if ( 32 > strlen( $segredo ) ) {
			$segredo   = bin2hex( random_bytes( 32 ) );
			$resultado = F3Base_Options::gravar( 'f3base_endpoint_segredo', $segredo, F3Base_Options::ORIGEM_PADRAO );
			$segredo   = is_string( $resultado['lido'] ) ? $resultado['lido'] : $segredo;
		}

		return $segredo . wp_salt( 'auth' );
	}

	/* ------------------------------------------------------------------ *
	 * Rate limit
	 * ------------------------------------------------------------------ */

	/**
	 * A origem está dentro do limite da janela?
	 *
	 * @return bool
	 */
	private static function dentro_do_rate_limit(): bool {
		$janela = max( 60, (int) apply_filters( 'f3base_lead_rate_limit_janela', 10 * MINUTE_IN_SECONDS ) );
		$limite = max( 1, (int) apply_filters( 'f3base_lead_rate_limit_maximo', 20 ) );

		$origem = self::origem();
		$chave  = hash( 'sha256', 'limite|' . $origem['valor'] . '|' . wp_salt( 'nonce' ) );

		return self::incrementar_janela( $chave, $janela ) <= $limite;
	}

	/** Cota independente, compartilhada somente entre as emissões de tokens do Core. */
	public static function limite_token(): array {
		return array(
			'janela' => max( 60, min( 3600, (int) apply_filters( 'f3base_token_rate_limit_janela', 10 * MINUTE_IN_SECONDS ) ) ),
			'maximo' => max( 1, min( 3000, (int) apply_filters( 'f3base_token_rate_limit_maximo', 60 ) ) ),
		);
	}
	public static function dentro_do_limite_token(): bool {
		$c = self::limite_token();
		$o = self::origem();
		return self::incrementar_janela( hash( 'sha256', 'token|' . $o['valor'] . '|' . wp_salt( 'nonce' ) ), $c['janela'] ) <= $c['maximo'];
	}

	/** Cabeçalhos também viajam em chamadas REST internas e respostas de erro. */
	public static function resposta_dinamica( array $corpo, int $status, int $espera = 0 ): WP_REST_Response {
		$r = new WP_REST_Response( $corpo, $status );
		$r->header( 'Cache-Control', 'no-store, private' );
		$r->header( 'Pragma', 'no-cache' );
		$r->header( 'Expires', F3Base_Cache_Pagina::EXPIRES_PASSADO );
		if ( 429 === $status ) {
			$r->header( 'Retry-After', (string) max( 1, $espera ) ); }
		return $r;
	}

	/**
	 * Incrementa o balde da janela e devolve a contagem DEPOIS do incremento.
	 *
	 * Uma instrução só, e é o banco que soma: `INSERT ... ON DUPLICATE KEY
	 * UPDATE` com `LAST_INSERT_ID()` devolve o valor pós-incremento da própria
	 * sessão, então N requisições concorrentes recebem N valores distintos. O
	 * caminho anterior lia com `get_transient()` e gravava com `set_transient()`
	 * sem lock: N requisições concorrentes liam o MESMO valor e gravavam o mesmo
	 * valor mais um, e o balde de 20 deixava passar quantas coubessem na janela.
	 *
	 * A linha do balde entra com estado VAZIO: ela não é uma reserva, e dar a
	 * ela o estado de uma reserva faria a poda e qualquer contagem por estado
	 * misturarem balde com lead.
	 *
	 * @param string $chave  Chave já derivada da origem.
	 * @param int    $janela Janela em segundos.
	 * @return int Contagem depois deste incremento.
	 */
	public static function incrementar_janela( string $chave, int $janela ): int {
		if ( ! self::tabela_pronta() ) {
			return self::incrementar_por_transiente( $chave, $janela );
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$agora  = time();
		$fim    = $agora + $janela;

		$anterior = $wpdb->suppress_errors( true );

		$linhas = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$tabela} (chave, tipo, estado, record_id, contador, expira_em, criado_em) VALUES (%s, %s, %s, %s, 1, %d, %d) ON DUPLICATE KEY UPDATE contador = LAST_INSERT_ID( IF( expira_em < %d, 1, contador + 1 ) ), expira_em = IF( expira_em < %d, %d, expira_em )", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				self::TIPO_LIMITE,
				'',
				'',
				$fim,
				$agora,
				$agora,
				$agora,
				$fim
			)
		);

		$wpdb->suppress_errors( $anterior );

		if ( false === $linhas ) {
			return self::incrementar_por_transiente( $chave, $janela );
		}

		if ( 1 === (int) $linhas ) {
			return 1;
		}

		$contagem = (int) $wpdb->insert_id;

		if ( $contagem > 0 ) {
			return $contagem;
		}

		/*
		 * O incremento JÁ ACONTECEU — ele é a instrução acima. Se o driver não
		 * devolveu o valor de LAST_INSERT_ID(), a leitura seguinte é só para
		 * saber quanto ficou; devolver 1 aqui seria um balde que nunca fecha,
		 * e um limite que nunca fecha é pior que limite nenhum, porque parece
		 * que existe.
		 */
		$lido = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT contador FROM {$tabela} WHERE chave = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave
			)
		);

		return is_numeric( $lido ) ? max( 1, (int) $lido ) : PHP_INT_MAX;
	}

	/**
	 * Contingência declarada do balde: ler, somar e gravar, sem atomicidade.
	 *
	 * Só existe quando a tabela não está pronta, e o módulo reporta esse estado
	 * como DEGRADADO com o motivo — porque é exatamente aqui que o incremento se
	 * perde sob concorrência.
	 *
	 * @param string $chave  Chave já derivada da origem.
	 * @param int    $janela Janela em segundos.
	 * @return int Contagem depois deste incremento.
	 */
	public static function incrementar_por_transiente( string $chave, int $janela ): int {
		$transiente = 'f3base_rl_' . substr( $chave, 0, 32 );
		$atual      = get_transient( $transiente );
		$atual      = is_numeric( $atual ) ? (int) $atual : 0;

		set_transient( $transiente, $atual + 1, $janela );

		return $atual + 1;
	}

	/**
	 * Cabeçalho de proxy em que este site confia, de quem, e em que posição.
	 *
	 * Vazio por padrão: cabeçalho de proxy é declaração do CLIENTE, e aceitar um
	 * sem declaração é deixar o visitante escolher em que balde ele conta —
	 * spoofing de limite.
	 *
	 * O QUE `saltos` SIGNIFICA, dito na aritmética que o código faz: ele é a
	 * POSIÇÃO CONTADA DO FIM da lista do cabeçalho, e `1` é o ÚLTIMO elemento —
	 * o que o proxy imediatamente à frente do site escreveu. Com dois proxies
	 * seus na frente, `2` é o penúltimo, e assim por diante. A frase antiga
	 * dizia "descontando os saltos da direita", que descreve uma conta com um
	 * elemento a menos e leva a declarar um número errado: quem tem uma CDN e lê
	 * "descontando 1" escreve 2, e o site passa a ler a ponta que o próprio
	 * visitante escreveu.
	 *
	 * `redes_confiaveis` É A PROTEÇÃO OPCIONAL, e ela é ligada por quem a declara.
	 * PREENCHIDA, só é lido o cabeçalho de um pedido cujo `REMOTE_ADDR` esteja
	 * numa das faixas — que são justamente os IPs dos proxies do projeto —, e um
	 * pedido que chega DIRETO ao servidor, contornando a CDN, volta a contar pelo
	 * endereço da conexão. VAZIA, o cabeçalho declarado é lido de qualquer
	 * conexão, que é o comportamento que este pacote sempre teve.
	 *
	 * POR QUE VAZIA NÃO É "NUNCA CONFIAR". Houve uma versão em que era, e ela
	 * quebrava em silêncio toda instalação existente: quem tinha `cabecalho`
	 * declarado e nunca ouviu falar de faixa passava, na atualização, a contar
	 * todo mundo no mesmo balde do rate limit e a mandar o IP da CDN ao
	 * fornecedor de anúncio — sem erro, sem aviso e sem ninguém ter mexido em
	 * nada. O risco de quem não declarou a faixa é real e continua sendo dito, em
	 * `avisos()`, com o nome do campo que o fecha.
	 *
	 * @return array{cabecalho:string,saltos:int,redes_confiaveis:array<int,string>}
	 */
	public static function cabecalho_confiavel(): array {
		$valor = F3Base_Options::ler( 'f3base_origem_confiavel' );
		$valor = is_array( $valor ) ? $valor : array();

		return array(
			'cabecalho'        => isset( $valor['cabecalho'] ) ? trim( (string) $valor['cabecalho'] ) : '',
			'saltos'           => isset( $valor['saltos'] ) ? max( 1, (int) $valor['saltos'] ) : 1,
			'redes_confiaveis' => self::redes_declaradas( $valor['redes_confiaveis'] ?? array() ),
		);
	}

	/**
	 * As faixas de IP declaradas como proxies do projeto, já limpas.
	 *
	 * Aceita lista ou texto separado por vírgula, quebra de linha ou espaço — a
	 * chave ainda não é campo declarado do catálogo (é preservada como chave
	 * desconhecida do grupo), e quem a escreve pelo canal escreve texto. O que
	 * não casa com IP ou CIDR é DESCARTADO em silêncio de propósito: uma faixa
	 * ilegível não pode virar uma faixa que aceita tudo.
	 *
	 * @param mixed $bruto Valor gravado.
	 * @return array<int,string> Faixas em notação `endereço` ou `endereço/prefixo`.
	 */
	public static function redes_declaradas( $bruto ): array {
		if ( is_string( $bruto ) ) {
			$bruto = preg_split( '/[\s,;]+/', $bruto );
		}

		if ( ! is_array( $bruto ) ) {
			return array();
		}

		$saida = array();

		foreach ( $bruto as $item ) {
			if ( ! is_scalar( $item ) ) {
				continue;
			}

			$texto = trim( (string) $item );

			if ( '' === $texto ) {
				continue;
			}

			$partes    = explode( '/', $texto, 2 );
			$endereco  = $partes[0];
			$prefixo   = $partes[1] ?? '';
			$e_valido  = false !== filter_var( $endereco, FILTER_VALIDATE_IP );
			$e_prefixo = '' === $prefixo || ( ctype_digit( $prefixo ) && (int) $prefixo <= self::bits_do_endereco( $endereco ) );

			if ( $e_valido && $e_prefixo ) {
				$saida[] = $texto;
			}
		}

		return array_values( array_unique( $saida ) );
	}

	/**
	 * Quantos bits tem o endereço — 32 em IPv4, 128 em IPv6.
	 *
	 * @param string $endereco Endereço já validado.
	 * @return int
	 */
	private static function bits_do_endereco( string $endereco ): int {
		return false !== filter_var( $endereco, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ? 32 : 128;
	}

	/**
	 * O endereço que abriu a conexão está numa das faixas declaradas?
	 *
	 * Comparação em BINÁRIO, bit a bit, e não em texto: `10.0.0.1` e `10.0.0.10`
	 * têm o mesmo começo como string, e prefixo casado por `str_starts_with()`
	 * aceitaria a segunda dentro de `10.0.0.1/32`.
	 *
	 * ESTA É UMA PERGUNTA DE PERTENCIMENTO, e só. Lista vazia devolve falso
	 * porque endereço nenhum pertence a conjunto nenhum; o que fazer quando a
	 * lista está vazia é decisão de quem chama, e ela mora em `origem()`, que é
	 * o único lugar onde a leitura do cabeçalho acontece.
	 *
	 * @param string            $endereco Endereço da conexão (`REMOTE_ADDR`).
	 * @param array<int,string> $redes    Faixas declaradas.
	 * @return bool
	 */
	public static function em_rede_confiavel( string $endereco, array $redes ): bool {
		$alvo = @inet_pton( $endereco ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( false === $alvo ) {
			return false;
		}

		foreach ( $redes as $rede ) {
			$partes = explode( '/', (string) $rede, 2 );
			$base   = @inet_pton( $partes[0] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$bits   = isset( $partes[1] ) && ctype_digit( $partes[1] ) ? (int) $partes[1] : strlen( (string) $base ) * 8;

			if ( false === $base || strlen( $base ) !== strlen( $alvo ) ) {
				continue;
			}

			$inteiros = intdiv( $bits, 8 );
			$resto    = $bits % 8;

			if ( 0 !== strncmp( $alvo, $base, $inteiros ) ) {
				continue;
			}

			if ( 0 === $resto ) {
				return true;
			}

			$mascara = chr( 0xFF << ( 8 - $resto ) & 0xFF );

			if ( ( $alvo[ $inteiros ] & $mascara ) === ( $base[ $inteiros ] & $mascara ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Nome de variável de servidor a partir do nome do cabeçalho declarado.
	 *
	 * @param string $cabecalho Nome do cabeçalho, com ou sem o prefixo HTTP_.
	 * @return string Vazio quando o nome declarado não sobra nada depois da limpeza.
	 */
	public static function chave_de_servidor( string $cabecalho ): string {
		$nome = strtoupper( str_replace( '-', '_', trim( $cabecalho ) ) );
		$nome = preg_replace( '/[^A-Z0-9_]/', '', $nome );
		$nome = is_string( $nome ) ? $nome : '';

		if ( '' === $nome ) {
			return '';
		}

		return str_starts_with( $nome, 'HTTP_' ) ? $nome : 'HTTP_' . $nome;
	}

	/**
	 * Origem da requisição, com a fonte NOMEADA.
	 *
	 * @param array<string,mixed>|null $servidor Superglobal a ler; nulo usa `$_SERVER`.
	 * @return array{valor:string,fonte:string,cabecalho:string}
	 */
	public static function origem( ?array $servidor = null ): array {
		if ( null === $servidor ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$servidor = $_SERVER;
		}

		$remoto = isset( $servidor['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $servidor['REMOTE_ADDR'] ) ) : '';
		$remoto = '' !== $remoto ? $remoto : 'desconhecida';

		$declarado = self::cabecalho_confiavel();
		$chave     = self::chave_de_servidor( $declarado['cabecalho'] );

		if ( '' === $chave ) {
			return array(
				'valor'     => $remoto,
				'fonte'     => 'remote_addr',
				'cabecalho' => '',
			);
		}

		/*
		 * COM FAIXA DECLARADA, QUEM FALOU COM ESTE SERVIDOR PRECISA SER UM PROXY
		 * DECLARADO. Sem esta conferência o nome do cabeçalho é a declaração
		 * inteira, e ele é texto que qualquer cliente manda: basta alcançar a
		 * origem por fora da CDN — pelo IP, o que costuma responder — para
		 * escolher o balde do rate limit e o `client_ip_address` que o servidor
		 * manda à Meta. É a proteção que este campo existe para ligar.
		 *
		 * SEM FAIXA DECLARADA A CONFERÊNCIA NÃO ACONTECE, e o cabeçalho é lido de
		 * qualquer conexão. Não é descuido: é o comportamento que toda instalação
		 * já entregue tem, e trocá-lo por "nunca confiar" numa atualização faria
		 * cada uma delas passar, sem ninguém ter mexido em nada, a contar todos os
		 * visitantes no mesmo balde e a mandar o endereço da CDN ao fornecedor. O
		 * risco de não declarar a faixa é dito em `avisos()`, com o nome do campo
		 * que o fecha.
		 */
		if ( array() !== $declarado['redes_confiaveis'] && ! self::em_rede_confiavel( $remoto, $declarado['redes_confiaveis'] ) ) {
			return array(
				'valor'     => $remoto,
				'fonte'     => 'remote_addr',
				'cabecalho' => $declarado['cabecalho'],
			);
		}

		$bruto = isset( $servidor[ $chave ] ) ? sanitize_text_field( wp_unslash( (string) $servidor[ $chave ] ) ) : '';
		$lista = array_values(
			array_filter(
				array_map( 'trim', explode( ',', $bruto ) ),
				static fn ( string $item ): bool => '' !== $item
			)
		);

		/*
		 * `saltos` É POSIÇÃO CONTADA DO FIM, e `1` é o último elemento: o que o
		 * proxy imediatamente à frente do site escreveu. Índice negativo, ou
		 * lista mais curta que a posição declarada, volta para `REMOTE_ADDR`.
		 */
		$indice = count( $lista ) - $declarado['saltos'];

		if ( $indice < 0 || ! isset( $lista[ $indice ] ) || false === filter_var( $lista[ $indice ], FILTER_VALIDATE_IP ) ) {
			return array(
				'valor'     => $remoto,
				'fonte'     => 'remote_addr',
				'cabecalho' => $declarado['cabecalho'],
			);
		}

		return array(
			'valor'     => $lista[ $indice ],
			'fonte'     => 'cabecalho-declarado',
			'cabecalho' => $declarado['cabecalho'],
		);
	}

	/* ------------------------------------------------------------------ *
	 * Deduplicação atômica
	 * ------------------------------------------------------------------ */

	/**
	 * Nome completo da tabela de deduplicação.
	 *
	 * @return string
	 */
	public static function nome_tabela(): string {
		global $wpdb;

		return $wpdb->prefix . self::TABELA;
	}

	/**
	 * A tabela está PRONTA — existe e traz as colunas que esta versão usa?
	 *
	 * Existir não basta: a 1.0.1 do site-core acrescentou a coluna que separa a
	 * reserva pendente da firme e as colunas do balde do rate limit. Tabela
	 * antiga responde ao `SHOW TABLES` e faz o `INSERT` desta versão falhar em
	 * silêncio, então a pergunta certa é a das colunas.
	 *
	 * @return bool
	 */
	public static function tabela_pronta(): bool {
		if ( null !== self::$tabela_pronta ) {
			return self::$tabela_pronta;
		}

		global $wpdb;

		$tabela = self::nome_tabela();
		$achado = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $tabela ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		if ( $achado !== $tabela ) {
			self::$tabela_pronta = false;

			return self::$tabela_pronta;
		}

		$colunas = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $tabela ) ); // phpcs:ignore WordPress.DB
		$colunas = is_array( $colunas ) ? array_map( 'strval', $colunas ) : array();

		$faltando = array_diff( array( 'chave', 'tipo', 'estado', 'record_id', 'contador', 'expira_em', 'criado_em' ), $colunas );

		self::$tabela_pronta = array() === $faltando;

		return self::$tabela_pronta;
	}

	/**
	 * Cria — ou migra — a tabela de chaves do endpoint.
	 *
	 * @return void
	 */
	public static function criar_tabela(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tabela  = self::nome_tabela();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$tabela} (
	chave char(64) NOT NULL,
	tipo varchar(12) NOT NULL DEFAULT 'dedup',
	estado varchar(10) NOT NULL DEFAULT 'pendente',
	record_id char(32) NOT NULL DEFAULT '',
	contador int(10) unsigned NOT NULL DEFAULT 0,
	expira_em bigint(20) unsigned NOT NULL DEFAULT 0,
	criado_em bigint(20) unsigned NOT NULL,
	PRIMARY KEY  (chave),
	KEY criado_em (criado_em),
	KEY tipo_expira (tipo,expira_em)
) {$collate};";

		dbDelta( $sql );

		self::$tabela_pronta = null;
	}

	/**
	 * Reserva a correlação. A chave única do banco decide o empate.
	 *
	 * O PRAZO É PARÂMETRO desde a 1.3.5, e a razão é que o mecanismo passou a
	 * ter um segundo consumidor: o SELO DE LOTE do resumo de comportamento, que
	 * precisa exatamente das três propriedades desta reserva — inserção atômica
	 * que decide o empate no banco, confirmação depois da persistência e
	 * compensação quando nada foi gravado — e de um prazo completamente
	 * diferente. Trinta dias é o prazo do LEAD, porque um lead reenviado no mês
	 * seguinte ainda é o mesmo lead; um lote de medição vive o tempo de uma
	 * visita. Fixar aqui os trinta dias obrigaria o segundo consumidor a
	 * escrever a própria cópia da instrução, e a segunda cópia é sempre a que
	 * fica para trás. Zero mantém o prazo do lead, e é o que todo chamador
	 * antigo continua recebendo.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @param string $record_id      Identificador nascido no servidor.
	 * @param int    $ttl            Prazo de guarda em segundos; zero usa o do lead.
	 * @return array{novo:bool,record_id:string,meio:string} `meio` nomeia o mecanismo que decidiu: tabela, tabela-retomada ou transiente.
	 */
	public static function reservar( string $correlation_id, string $record_id, int $ttl = 0 ): array {
		$chave = self::chave_de_dedup( $correlation_id );
		$ttl   = $ttl > 0 ? $ttl : self::ttl_dedup();

		if ( ! self::tabela_pronta() ) {
			return self::reservar_por_transiente( $chave, $record_id );
		}

		global $wpdb;

		$tabela   = self::nome_tabela();
		$agora    = time();
		$anterior = $wpdb->suppress_errors( true );

		$inserido = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"INSERT INTO {$tabela} (chave, tipo, estado, record_id, contador, expira_em, criado_em) VALUES (%s, %s, %s, %s, 0, %d, %d)", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				self::TIPO_DEDUP,
				self::RESERVA_PENDENTE,
				$record_id,
				$agora + $ttl,
				$agora
			)
		);

		$wpdb->suppress_errors( $anterior );

		if ( 1 === (int) $inserido ) {
			self::podar_dedup();

			return array(
				'novo'      => true,
				'record_id' => $record_id,
				'meio'      => 'tabela',
			);
		}

		$linha = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT record_id, estado, criado_em FROM {$tabela} WHERE chave = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave
			),
			ARRAY_A
		);

		$existente = is_array( $linha ) ? (string) $linha['record_id'] : '';
		$estado    = is_array( $linha ) ? (string) $linha['estado'] : self::RESERVA_FIRME;
		$nascida   = is_array( $linha ) ? (int) $linha['criado_em'] : 0;

		/*
		 * RESERVA PENDENTE ABANDONADA É RETOMADA, e a retomada é do banco: o
		 * `UPDATE` casa o carimbo que acabou de ser lido, então dois pedidos
		 * concorrentes disputando a mesma reserva morta produzem uma retomada só.
		 * Sem isto, uma requisição interrompida entre a reserva e a gravação
		 * deixaria a correlação bloqueada até o fim do TTL.
		 */
		if ( self::RESERVA_PENDENTE === $estado && $nascida < $agora - self::ttl_reserva_pendente() ) {
			$retomada = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				$wpdb->prepare(
					"UPDATE {$tabela} SET record_id = %s, criado_em = %d, expira_em = %d WHERE chave = %s AND estado = %s AND criado_em = %d", // phpcs:ignore WordPress.DB.PreparedSQL
					$record_id,
					$agora,
					$agora + $ttl,
					$chave,
					self::RESERVA_PENDENTE,
					$nascida
				)
			);

			if ( 1 === (int) $retomada ) {
				return array(
					'novo'      => true,
					'record_id' => $record_id,
					'meio'      => 'tabela-retomada',
				);
			}
		}

		return array(
			'novo'      => false,
			'record_id' => $existente,
			'meio'      => 'tabela',
		);
	}

	/**
	 * Chave da reserva de deduplicação.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @return string
	 */
	public static function chave_de_dedup( string $correlation_id ): string {
		return hash( 'sha256', $correlation_id );
	}

	/**
	 * Confirma a reserva DEPOIS que o lead está gravado.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @param string $record_id      Identificador nascido no servidor.
	 * @param int    $ttl            Prazo de guarda em segundos; zero usa o do lead.
	 * @return void
	 */
	public static function confirmar_reserva( string $correlation_id, string $record_id, int $ttl = 0 ): void {
		$chave = self::chave_de_dedup( $correlation_id );

		if ( ! self::tabela_pronta() ) {
			/*
			 * O PRAZO ACOMPANHA O DA RESERVA pela mesma razão que ele é
			 * parâmetro lá: a marca de contingência do selo de lote não pode
			 * viver trinta dias no armazenamento de options por causa de uma
			 * visita que durou meia hora.
			 */
			set_transient( self::transiente_de_dedup( $chave ), self::RESERVA_FIRME . '|' . $record_id, $ttl > 0 ? $ttl : self::ttl_dedup() );

			return;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$tabela} SET estado = %s WHERE chave = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				self::RESERVA_FIRME,
				$chave
			)
		);
	}

	/**
	 * Compensa a reserva quando NADA foi gravado.
	 *
	 * Só a reserva PENDENTE é apagada: uma firme guarda um lead que existe, e
	 * apagá-la traria o duplicado de volta.
	 *
	 * @param string $correlation_id Identificador nascido no navegador.
	 * @return void
	 */
	public static function liberar_reserva( string $correlation_id ): void {
		$chave = self::chave_de_dedup( $correlation_id );

		if ( ! self::tabela_pronta() ) {
			delete_transient( self::transiente_de_dedup( $chave ) );

			return;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE chave = %s AND estado = %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$chave,
				self::RESERVA_PENDENTE
			)
		);
	}

	/**
	 * Nome do transiente da reserva de contingência.
	 *
	 * @param string $chave Chave derivada da correlação.
	 * @return string
	 */
	private static function transiente_de_dedup( string $chave ): string {
		return 'f3base_dedup_' . substr( $chave, 0, 40 );
	}

	/**
	 * Reserva de contingência quando a tabela não existe.
	 *
	 * Declarado como não atômico: é o motivo que o módulo reporta.
	 *
	 * @param string $chave     Chave derivada da correlação.
	 * @param string $record_id Identificador do servidor.
	 * @return array{novo:bool,record_id:string,meio:string} `meio` sai sempre `transiente` aqui, e é o que distingue esta reserva da atômica.
	 */
	private static function reservar_por_transiente( string $chave, string $record_id ): array {
		$transiente = self::transiente_de_dedup( $chave );
		$existente  = get_transient( $transiente );

		if ( is_string( $existente ) && '' !== $existente ) {
			$partes = explode( '|', $existente, 2 );
			$estado = (string) $partes[0];
			$antigo = isset( $partes[1] ) ? (string) $partes[1] : $existente;

			/*
			 * Marca gravada por uma versão anterior não trazia estado: ela
			 * significava "já registrado", e é assim que continua sendo lida.
			 */
			if ( self::RESERVA_PENDENTE !== $estado && self::RESERVA_FIRME !== $estado ) {
				$antigo = $existente;
			}

			return array(
				'novo'      => false,
				'record_id' => $antigo,
				'meio'      => 'transiente',
			);
		}

		/*
		 * A reserva de contingência nasce PENDENTE e com TTL curto: se a
		 * requisição morrer entre a reserva e a gravação, ela some sozinha em
		 * minutos, em vez de bloquear a correlação pelo TTL de deduplicação.
		 */
		set_transient( $transiente, self::RESERVA_PENDENTE . '|' . $record_id, self::ttl_reserva_pendente() );

		return array(
			'novo'      => true,
			'record_id' => $record_id,
			'meio'      => 'transiente',
		);
	}

	/**
	 * Prazo em que uma reserva PENDENTE ainda segura a correlação.
	 *
	 * @return int
	 */
	public static function ttl_reserva_pendente(): int {
		$ttl = (int) apply_filters( 'f3base_lead_reserva_pendente_ttl', 5 * MINUTE_IN_SECONDS );

		return max( 30, min( HOUR_IN_SECONDS, $ttl ) );
	}

	/**
	 * Prazo de guarda das chaves de deduplicação.
	 *
	 * @return int
	 */
	private static function ttl_dedup(): int {
		$ttl = (int) apply_filters( 'f3base_lead_dedup_ttl', 30 * DAY_IN_SECONDS );

		return max( HOUR_IN_SECONDS, $ttl );
	}

	/**
	 * Poda oportunista das chaves expiradas.
	 *
	 * @return void
	 */
	private static function podar_dedup(): void {
		if ( 1 !== wp_rand( 1, 50 ) ) {
			return;
		}

		global $wpdb;

		$tabela = self::nome_tabela();

		$agora = time();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"DELETE FROM {$tabela} WHERE criado_em < %d OR ( expira_em > 0 AND expira_em < %d ) OR ( estado = %s AND criado_em < %d )", // phpcs:ignore WordPress.DB.PreparedSQL
				$agora - self::ttl_dedup(),
				$agora,
				self::RESERVA_PENDENTE,
				$agora - self::ttl_reserva_pendente()
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Gravação
	 * ------------------------------------------------------------------ */

	/**
	 * Gera o identificador do servidor.
	 *
	 * @return string
	 */
	private static function gerar_record_id(): string {
		return bin2hex( random_bytes( 16 ) );
	}

	/** Único destino de gravação desde a base suportada. */
    private static function gravar_lead(array $dados,string $record_id): array {
        return F3Base_Leads_Repositorio::clique($dados,$record_id);
    }

	/** Contadores agregados, sem corpo, IP, e-mail, campos ou caminhos recusados. */
	public const TABELA_RECUSAS = 'f3base_leads_recusas';
	public static function instalar_recusas(): void {
		global $wpdb;
		$t      = $wpdb->prefix . self::TABELA_RECUSAS;
		$existe = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) === $t;
		if ( $existe && ! array_diff( array( 'dia', 'motivo', 'total', 'primeiro', 'ultimo' ), (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $t ) ) ) ) {
			return; }
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta(
			"CREATE TABLE {$t} (
			dia date NOT NULL,
			motivo varchar(40) NOT NULL,
			total bigint unsigned NOT NULL DEFAULT 0,
			primeiro bigint unsigned NOT NULL,
			ultimo bigint unsigned NOT NULL,
			PRIMARY KEY  (dia,motivo)
		) {$wpdb->get_charset_collate()};"
		);
	}
	private static function registrar_recusa( string $codigo ): void {
		$permitidos = array( 'honeypot', 'f3base_token_invalido', 'f3base_rate_limit', 'f3base_reserva_indisponivel', 'f3base_gravacao_indisponivel', 'f3base_campo_desconhecido', 'f3base_campo_obrigatorio', 'f3base_tipo_invalido', 'f3base_limite_excedido', 'f3base_formato_invalido', 'f3base_valor_invalido' );
		$motivo     = in_array( $codigo, $permitidos, true ) ? $codigo : 'outra_recusa';
		global $wpdb;
		$t     = $wpdb->prefix . self::TABELA_RECUSAS;
		$agora = time();
		$wpdb->query( $wpdb->prepare( 'INSERT INTO %i (dia,motivo,total,primeiro,ultimo) VALUES (%s,%s,1,%d,%d) ON DUPLICATE KEY UPDATE total=total+1,ultimo=%d', $t, wp_date( 'Y-m-d', $agora ), $motivo, $agora, $agora, $agora ) );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE ultimo<%d', $t, $agora - 31 * DAY_IN_SECONDS ) );
	}
	public static function resumo_recusas( int $dias = 30 ): array {
		global $wpdb;
		$t = $wpdb->prefix . self::TABELA_RECUSAS;
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) !== $t ) {
			return array(
				'disponivel' => false,
				'linhas'     => array(),
				'motivo'     => 'Contadores ainda não instalados.',
			); }
		$dias   = max( 1, min( 31, $dias ) );
		$linhas = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT dia,motivo,total,primeiro,ultimo FROM %i WHERE dia>=%s ORDER BY dia,motivo LIMIT 372', $t, wp_date( 'Y-m-d', time() - ( $dias - 1 ) * DAY_IN_SECONDS ) ), ARRAY_A );
		return array(
			'disponivel'         => true,
			'dias'               => $dias,
			'retencao_dias'      => 31,
			'fuso'               => wp_timezone_string(),
			'linhas'             => $linhas,
			'historico_anterior' => 'nao_inferido',
			'observacao'         => 'Ausência de contador não prova ausência de recusas antes da ativação ou durante falha de armazenamento.',
		);
	}

	/**
	 * Monta a resposta REST.
	 *
	 * @param int                 $status Código HTTP.
	 * @param array<string,mixed> $corpo  Corpo da resposta.
	 * @return WP_REST_Response
	 */
	private static function resposta( int $status, array $corpo ): WP_REST_Response {
		if ( $status >= 400 || 'honeypot' === ( $corpo['motivo'] ?? '' ) ) {
			self::registrar_recusa( (string) ( $corpo['codigo'] ?? 'honeypot' ) ); }
		$corpo['fase'] = 'registro';

		return self::resposta_dinamica( $corpo, $status, max( self::limite_token()['janela'], (int) apply_filters( 'f3base_lead_rate_limit_janela', 10 * MINUTE_IN_SECONDS ) ) );
	}
}
