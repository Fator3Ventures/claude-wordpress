<?php
/** Avaliador declarativo somente leitura. O implantador mantém a política da frota. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Config_Perfil {
	public const OBSERVACOES = array( 'cache.publico', 'publicacao:/robots.txt', 'publicacao:/llms.txt', 'publicacao:/llms-full.txt' );
	public static function schema(): array {
		$texto    = array(
			'type'      => 'string',
			'minLength' => 1,
			'maxLength' => 120,
		);
		$condicao = array(
			'type'                 => 'object',
			'properties'           => array(
				'id'         => $texto,
				'nome'       => $texto,
				'campo'      => array(
					'type'     => 'array',
					'items'    => $texto,
					'maxItems' => 5,
				),
				'observacao' => $texto,
				'comparacao' => array(
					'type'    => 'string',
					'enum'    => array( 'igual', 'configurado', 'verificado' ),
					'default' => 'igual',
				),
				'esperado'   => F3Base_Config_Contrato::schema_dado( 'Expectativa declarada. Para segredos, somente booleano com comparacao=configurado.' ),
			),
			'required'             => array( 'id' ),
			'additionalProperties' => false,
		);
		$excecao  = array(
			'type'                 => 'object',
			'properties'           => array(
				'condicao'       => $texto,
				'responsavel'    => $texto,
				'motivo'         => array(
					'type'      => 'string',
					'minLength' => 1,
					'maxLength' => 500,
				),
				'expira_em'      => array(
					'type'    => 'integer',
					'minimum' => 1,
				),
				'perfil_id'      => $texto,
				'perfil_revisao' => $texto,
			),
			'required'             => array( 'condicao', 'responsavel', 'motivo', 'expira_em', 'perfil_id', 'perfil_revisao' ),
			'additionalProperties' => false,
		);
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'perfil'               => array(
					'type'                 => 'object',
					'properties'           => array(
						'id'        => $texto,
						'revisao'   => $texto,
						'condicoes' => array(
							'type'     => 'array',
							'items'    => $condicao,
							'maxItems' => 100,
							'minItems' => 1,
						),
						'excecoes'  => array(
							'type'     => 'array',
							'items'    => $excecao,
							'maxItems' => 100,
						),
					),
					'required'             => array( 'id', 'revisao', 'condicoes' ),
					'additionalProperties' => false,
				),
				'somente_divergencias' => array(
					'type'    => 'boolean',
					'default' => false,
				),
			),
			'additionalProperties' => false,
		);
	}
	public static function avaliar( $entrada = null ): array {
		if ( ! current_user_can( 'manage_options' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		$contadores = array(
			'conforme'       => 0,
			'divergente'     => 0,
			'excecao_valida' => 0,
			'indeterminado'  => 0,
		);
		if ( ! is_array( $entrada ) || ! isset( $entrada['perfil'] ) ) {
			$contadores['indeterminado'] = 1;
			return array(
				'ok'           => false,
				'estado'       => 'indeterminado',
				'codigo'       => 'perfil_ausente',
				'contadores'   => $contadores,
				'verificacoes' => 0,
				'itens'        => array(),
			); }
		if ( is_wp_error( rest_validate_value_from_schema( $entrada, self::schema() ) ) ) {
			return array(
				'ok'           => false,
				'estado'       => 'indeterminado',
				'codigo'       => 'perfil_invalido',
				'contadores'   => array_replace( $contadores, array( 'indeterminado' => 1 ) ),
				'verificacoes' => 0,
				'itens'        => array(),
			); }
		$perfil = $entrada['perfil'];
		$itens  = array();
		$vistos = array();
		foreach ( $perfil['condicoes'] as $condicao ) {
			if ( isset( $vistos[ $condicao['id'] ] ) ) {
				return array(
					'ok'           => false,
					'estado'       => 'indeterminado',
					'codigo'       => 'condicao_duplicada',
					'contadores'   => array_replace( $contadores, array( 'indeterminado' => 1 ) ),
					'verificacoes' => 0,
					'itens'        => array(),
				); }
			$vistos[ $condicao['id'] ] = true;
			$r                         = self::comparar( $condicao );
			if ( 'divergente' === $r['estado'] ) {
				foreach ( $perfil['excecoes'] ?? array() as $excecao ) {
					if ( $excecao['condicao'] === $condicao['id'] && $excecao['perfil_id'] === $perfil['id'] && $excecao['perfil_revisao'] === $perfil['revisao'] && $excecao['expira_em'] > time() ) {
						$r['estado']  = 'excecao_valida';
						$r['excecao'] = $excecao;
						break; }
				}
			}
			++$contadores[ $r['estado'] ];
			if ( empty( $entrada['somente_divergencias'] ) || in_array( $r['estado'], array( 'divergente', 'indeterminado' ), true ) ) {
				$itens[] = $r; }
		}
		$estado = $contadores['divergente'] ? 'divergente' : ( $contadores['indeterminado'] ? 'indeterminado' : ( $contadores['excecao_valida'] ? 'excecao_valida' : 'conforme' ) );
		return array(
			'ok'                    => true,
			'estado'                => $estado,
			'perfil'                => array(
				'id'      => $perfil['id'],
				'revisao' => $perfil['revisao'],
			),
			'checked_at'            => time(),
			'contadores'            => $contadores,
			'verificacoes'          => count( $perfil['condicoes'] ),
			'itens'                 => $itens,
			'configuracao_alterada' => false,
		);
	}
	private static function comparar( array $c ): array {
		$r = array(
			'id'     => $c['id'],
			'estado' => 'indeterminado',
			'codigo' => 'condicao_nao_suportada',
		);
		if ( isset( $c['observacao'] ) ) {
			if ( isset( $c['nome'] ) || ! in_array( $c['observacao'], self::OBSERVACOES, true ) || 'verificado' !== ( $c['comparacao'] ?? '' ) || ( isset( $c['esperado'] ) && true !== $c['esperado'] ) ) {
				return $r; }
			if ( 'cache.publico' === $c['observacao'] ) {
				$prova  = F3Base_Cache_Pagina::verificacao();
				$valida = 'verified' === ( $prova['status'] ?? '' ); } else {
				$prova  = F3Base_Publicacao_Sonda::consultar( array( 'caminho' => substr( $c['observacao'], strlen( 'publicacao:' ) ) ) );
				$valida = ! empty( $prova['valida'] ); }
				return array_merge(
					$r,
					array(
						'estado'    => $valida ? 'conforme' : 'indeterminado',
						'codigo'    => $valida ? 'evidencia_vigente' : 'evidencia_ausente_ou_vencida',
						'esperado'  => true,
						'observado' => $valida,
						'evidencia' => $prova,
						'acao'      => 'cache.publico' === $c['observacao'] ? F3Base_Config_Contrato::VERIFICAR : 'f3base/publicacao-verificar',
					)
				);
		}
		$nome = $c['nome'] ?? '';
		$d    = F3Base_Options::declaracao( $nome );
		if ( ! $d || ! empty( $d['estado_execucao'] ) || ! array_key_exists( 'esperado', $c ) ) {
			return $r; }
		$segredo    = F3Base_Options::e_segredo( $nome );
		$comparacao = $c['comparacao'] ?? 'igual';
		if ( $segredo && ( 'configurado' !== $comparacao || ! is_bool( $c['esperado'] ) || ! empty( $c['campo'] ) ) ) {
			$r['codigo'] = 'segredo_somente_presenca';
			return $r; }
		$foto = F3Base_Options::fotografia( $nome );
		if ( $foto['erro'] ) {
			$r['codigo'] = 'leitura_falhou';
			return $r; }
		$valor  = $foto['valor'];
		$schema = F3Base_Config_Contrato::schema_valor( $d );
		foreach ( $c['campo'] ?? array() as $campo ) {
			if ( ! isset( $schema['properties'][ $campo ] ) || ! is_array( $valor ) || ! array_key_exists( $campo, $valor ) ) {
				return $r; }
			$valor  = $valor[ $campo ];
			$schema = $schema['properties'][ $campo ];
		}
		if ( 'configurado' === $comparacao ) {
			if ( ! is_bool( $c['esperado'] ) ) {
				return $r;
			} $observado = ! in_array( $valor, array( null, '', array() ), true ); } elseif ( 'igual' === $comparacao ) {
			if ( is_wp_error( rest_validate_value_from_schema( $c['esperado'], $schema ) ) ) {
				$r['codigo'] = 'expectativa_invalida';
				return $r;
			} $observado = $valor; } else {
				return $r; }
			if ( ! hash_equals( $foto['revisao'], F3Base_Options::revisao( $nome ) ) ) {
				$r['codigo'] = 'configuracao_mudou';
				return $r; }
			return array_merge(
				$r,
				array(
					'estado'      => F3Base_Options::equivalente( $observado, $c['esperado'] ) ? 'conforme' : 'divergente',
					'codigo'      => 'comparado',
					'nome'        => $nome,
					'campo'       => $c['campo'] ?? array(),
					'esperado'    => $c['esperado'],
					'observado'   => $segredo ? array(
						'configurado' => $observado,
						'mascarado'   => true,
					) : $observado,
					'revisao'     => $foto['revisao'],
					'procedencia' => F3Base_Options::procedencia( $nome, $foto ),
				)
			);
	}
}
