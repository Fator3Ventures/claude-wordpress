<?php
/** Catálogo e serviços da versão atual. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Configuracao_Atual {
    public static function iniciar(): void {
        add_action('wp_abilities_api_init', array(__CLASS__, 'abilities'));
        add_action(F3Base_Leads_Notificacoes::EVENTO, array(F3Base_Resposta_Visitante::class, 'processar_pendentes'));
        F3Base_Politica::iniciar();
        F3Base_Analise::iniciar();
        F3Base_Relatorios::iniciar();
    }
    public static function catalogo( array $c ): array {
        $c['f3base_politica_canal']['padrao'] = true;
        $c['f3base_politica_canal']['descricao'] = 'Gestão autenticada da política pelo canal, habilitada por padrão; alterações exigem manage_options e revisão.';
        $c['f3base_contato']['rotulo'] = 'Contato, avisos e WhatsApp';
        $c['f3base_contato']['descricao'] = 'Defina os avisos da equipe, o destino do WhatsApp e a instrumentação dos botões.';
        $labels = array(
            'email_leads' => array( 'Quem recebe os avisos internos (até cinco)', 'E-mails da equipe, um por linha. A lista do formulário prevalece quando definida. Sem destinatário, o contato é salvo e o aviso fica desconfigurado.', 'registro' ),
            'avisar_por_clique' => array( 'Enviar aviso interno de clique', 'Avisa sobre clique registrado, inclusive sem nome/e-mail. Desligar mantém o registro. Até 30 avisos por hora; pendentes entram no resumo horário.', 'registro' ),
            'avisar_por_formulario' => array( 'Enviar aviso interno de formulário recebido', 'Envia aviso após salvar um envio aceito. Falha no e-mail mantém o contato. A lista de destinatários pode ser definida em cada formulário.', 'registro' ),
            'classes_cta' => array( 'Classes adicionais de botões de contato', 'Classes CSS sem ponto, uma por linha; exemplo: f3capital-acao-whatsapp. A marcação não altera o link e o método segue o destino.', 'instrumentacao' ),
        );
        foreach ( $c['f3base_contato']['subcampos'] as $k => &$sub ) {
            $spec = $labels[$k] ?? null;
            $sub['grupo_visual'] = $spec[2] ?? 'whatsapp';
            if ( $spec ) { $sub['rotulo'] = $spec[0]; $sub['descricao'] = $spec[1]; $sub['impacto'] = $spec[1]; }
        } unset( $sub );
        $c['f3base_contato']['subcampos']['email_leads']['tipo'] = 'emails';
        $c['f3base_contato']['subcampos']['classes_cta']['tipo'] = 'linhas';
        $c['f3base_llms']['subcampos']['blocos_interface']['tipo'] = 'blocos';
        $c['f3base_llms']['subcampos']['blocos_interface']['descricao'] = 'Selecione os blocos de interface que serão omitidos na conversão Markdown. Valores já salvos são preservados quando o bloco está indisponível.';
        foreach ( $c as &$declaracao ) {
            foreach ( $declaracao['subcampos'] ?? array() as $k => $sub ) {
                if ( 'select' === ( $sub['tipo'] ?? '' ) ) { $declaracao['subcampos'][$k]['tipo'] = 'enum'; }
            }
        } unset( $declaracao );
        return F3Base_Politica::catalogo($c);
    }
    public static function abilities(): void {
        F3Base_Servicos::ability( 'documentacao-ler', 'Índice e leitura paginada da documentação instalada do Core', array( __CLASS__, 'documentacao' ), array( 'arquivo' => array( 'type' => 'string' ), 'linha' => array( 'type' => 'integer', 'minimum' => 1 ), 'limite' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 200 ) ) );
        F3Base_Resposta_Visitante::registrar();
        F3Base_Servicos::ability( 'arquivos-privados-preparar', 'Criar e testar diretório privado configurado, sem enviar mensagens', static function () { return F3Base_Arquivos_Privados::provisionar(); }, array(), array(), false );
    }
    public static function documentacao( array $e = array() ): array {
        $arquivos = array( 'DOCUMENTACAO.md', 'INSTRUCOES-DO-PLUGIN.md', 'README.md', 'CHANGELOG.md', 'CONTRACTS.md', 'docs/CONFIGURACAO.md', 'docs/LEADS-E-FORMULARIOS.md', 'docs/OPERACAO-E-RECUPERACAO.md', 'docs/VALIDACAO.md', 'docs/REFERENCIA-CATALOGO.md', 'docs/RELATORIOS.md' );
        if ( empty( $e['arquivo'] ) ) { return array( 'ok' => true, 'versao' => F3BASE_PLUGIN_VERSAO, 'indice' => 'DOCUMENTACAO.md', 'arquivos' => $arquivos, 'base' => plugin_basename( F3BASE_PLUGIN_ARQUIVO ), 'ability' => 'f3base/documentacao-ler' ); }
        if ( ! in_array( $e['arquivo'], $arquivos, true ) ) { return array( 'ok' => false, 'codigo' => 'documento_nao_catalogado' ); }
        $p = F3BASE_PLUGIN_DIR . $e['arquivo'];
        if ( ! is_readable( $p ) || filesize( $p ) > 524288 ) { return array( 'ok' => false, 'codigo' => 'documento_indisponivel' ); }
        $lines = file( $p, FILE_IGNORE_NEW_LINES );
        $inicio = max( 1, (int) ( $e['linha'] ?? 1 ) ); $limite = max( 1, min( 200, (int) ( $e['limite'] ?? 120 ) ) );
        return array( 'ok' => true, 'versao' => F3BASE_PLUGIN_VERSAO, 'arquivo' => $e['arquivo'], 'sha256' => hash_file( 'sha256', $p ), 'linha' => $inicio, 'total_linhas' => count( $lines ), 'texto' => implode( "\n", array_slice( $lines, $inicio - 1, $limite ) ), 'proxima_linha' => $inicio + $limite <= count( $lines ) ? $inicio + $limite : null );
    }
}
