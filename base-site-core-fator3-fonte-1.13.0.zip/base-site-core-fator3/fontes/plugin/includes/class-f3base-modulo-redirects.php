<?php
/**
 * Módulo redirects.
 *
 * O WordPress não tem: `wp_check_for_changed_slugs()` ignora tipos hierárquicos e
 * `wp_old_slug_redirect()` só olha a query var `name` com `post_type = post`. Aqui
 * o redirecionamento lê `_f3base_old_slug` e trata `pagename` E `name` — com
 * permalinks `/%postname%/`, uma URL de um nível chega como `name`.
 *
 * Também aplica os pares declarados em `f3base_redirects`.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Redirecionamento de slug antigo e pares declarados.
 */
final class F3Base_Modulo_Redirects extends F3Base_Modulo {

	/**
	 * Meta que guarda o slug antigo de um conteúdo gerenciado.
	 */
	public const META = '_f3base_old_slug';

	/**
	 * Corpo mínimo do 410, em texto puro.
	 *
	 * Ele existe porque a requisição TERMINA no 410: um corpo vazio deixa o
	 * navegador imprimir a página de erro dele, e o tema do site não pode ser
	 * servido num endereço que este pacote declarou como removido.
	 */
	public const CORPO_DO_410 = '410 Gone';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'redirects';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Redirects de slug', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Redireciona slugs antigos de páginas e posts lendo _f3base_old_slug, tratando as query vars pagename e name, e aplica os pares declarados em f3base_redirects antes do 404.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => 'template_redirect',
				'metodo'     => 'talvez_redirecionar',
				'prioridade' => 1,
				'args'       => 0,
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( 'f3base_redirects' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => __( 'Permalinks com /%postname%/', 'f3base' ),
				'presente' => str_contains( (string) get_option( 'permalink_structure', '' ), '%postname%' ),
				'detalhe'  => __( 'com essa estrutura, uma URL de um nível chega como name e não como pagename — os dois são tratados.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::REDIRECTS_SERVIDOS, __( 'Redirects servidos', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		$declarados = $this->declarados();

		return $this->ativo(
			sprintf(
				/* translators: %d: quantidade de pares declarados. */
				_n(
					'lendo %d par declarado e o slug antigo gravado em cada conteúdo gerenciado, por pagename e por name.',
					'lendo %d pares declarados e o slug antigo gravado em cada conteúdo gerenciado, por pagename e por name.',
					count( $declarados ),
					'f3base'
				),
				count( $declarados )
			)
		);
	}

	/**
	 * Aplica o redirecionamento quando houver destino.
	 *
	 * @return void
	 */
	public function talvez_redirecionar(): void {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		$declarado = $this->casar_declarado();
		if ( null !== $declarado ) {
			$this->executar( $declarado['para'], $declarado['status'], 'declarado' );
			return;
		}

		if ( ! is_404() ) {
			return;
		}

		$destino = $this->destino_por_slug_antigo();
		if ( '' !== $destino ) {
			$this->executar( $destino, 301, 'slug-antigo' );
		}
	}

	/**
	 * NORMALIZAÇÃO de um caminho declarado. Regra pura, e ela decide os dois lados.
	 *
	 * A query sai e a barra final sai, porque é assim que o comparador do
	 * redirecionamento pergunta "é este caminho?" — e é justamente por isso que
	 * ela precisa ser aplicada TAMBÉM ao destino.
	 *
	 * @param string $caminho Caminho como foi declarado ou pedido.
	 * @return string Caminho com barra inicial e sem barra final.
	 */
	public static function normalizar( string $caminho ): string {
		return F3Base_Redirects_Servico::caminho( (string) strtok( $caminho, '?' ) ) ?? '';
	}

	/**
	 * O PAR DECLARADO GIRA? Regra pura sobre os dois lados já normalizados.
	 *
	 * O DEFEITO MEDIDO, e ele derrubava o endereço para o visitante: o
	 * sanitizador recusava `de === para` comparando o TEXTO CRU, e o comparador
	 * daqui normalizava barra final e query antes de casar. O par
	 * `/servicos/ → /servicos` passava nos dois e girava para sempre — o
	 * navegador cortava com `ERR_TOO_MANY_REDIRECTS` e a página deixava de
	 * existir. Origem e destino que normalizam IGUAL não são um
	 * redirecionamento: são o mesmo endereço escrito de duas formas.
	 *
	 * @param string $de   Origem declarada.
	 * @param string $para Destino declarado.
	 * @return bool
	 */
	public static function par_gira( string $de, string $para ): bool {
		return self::normalizar( $de ) === self::normalizar( $para );
	}

	/**
	 * Casa o caminho atual com os pares declarados.
	 *
	 * @return array{para:string,status:int}|null
	 */
	private function casar_declarado(): ?array {
		$declarados = $this->declarados();
		if ( array() === $declarados ) {
			return null;
		}

		$atual = $this->caminho_atual();
		if ( '' === $atual ) {
			return null;
		}

		$atual_norm = self::normalizar( $atual );

		foreach ( $declarados as $regra ) {
			if ( self::normalizar( (string) $regra['de'] ) !== $atual_norm ) {
				continue;
			}

			/*
			 * O PAR QUE GIRA É RECUSADO AQUI, e não só no sanitizador: o par pode
			 * ter sido gravado por uma versão anterior deste pacote, por outro
			 * agente ou à mão no banco. Quem serve a requisição é este módulo, e
			 * é ele que não pode devolver o visitante ao mesmo endereço. O par
			 * fica gravado e sai NOMEADO em `avisos()` — apagá-lo em silêncio
			 * seria decidir pelo operador.
			 */
			if ( 410 !== (int) $regra['status'] && self::par_gira( (string) $regra['de'], (string) $regra['para'] ) ) {
				continue;
			}

			return array(
				'para'   => home_url( (string) $regra['para'] ),
				'status' => (int) $regra['status'],
			);
		}

		return null;
	}

	/**
	 * {@inheritDoc}
	 */
	public function avisos(): array {
		$avisos = array();
		$giram  = array();

		foreach ( $this->declarados() as $regra ) {
			$de   = (string) ( $regra['de'] ?? '' );
			$para = (string) ( $regra['para'] ?? '' );

			if ( 410 === (int) ( $regra['status'] ?? 0 ) || '' === $de || '' === $para ) {
				continue;
			}

			if ( self::par_gira( $de, $para ) ) {
				$giram[] = $de . ' → ' . $para;
			}
		}

		if ( array() !== $giram ) {
			$avisos[] = array(
				'estado' => 'WARN',
				'motivo' => sprintf(
					/* translators: %s: os pares declarados cuja origem e destino normalizam para o mesmo caminho. */
					__( 'par declarado cuja origem e destino são o MESMO caminho depois da barra final e da query: %s. Ele foi RECUSADO na hora de servir — este módulo não devolve o visitante ao endereço que ele pediu, porque isso é o laço que o navegador corta com ERR_TOO_MANY_REDIRECTS. O par continua gravado, porque apagar o que alguém gravou seria decidir pelo operador; corrigir o destino faz o redirecionamento voltar a existir na requisição seguinte.', 'f3base' ),
					implode( ', ', $giram )
				),
			);
		}

		return $avisos;
	}

	/**
	 * Procura um conteúdo gerenciado pelo slug antigo pedido.
	 *
	 * @return string Permalink de destino, ou vazio.
	 */
	private function destino_por_slug_antigo(): string {
		$path       = $this->caminho_atual();
		$candidatos = array( array( '_f3base_old_path', $path ) );
		foreach ( array( 'name', 'pagename' ) as $var ) {
			$legado = (string) get_query_var( $var, '' );
			if ( '' !== $legado && ! str_contains( $legado, '/' ) ) {
				$candidatos[] = array( self::META, $legado ); }
		}

		$tipos = get_post_types( array( 'public' => true ), 'names' );
		$tipos = is_array( $tipos ) ? array_values( $tipos ) : array( 'post', 'page' );

		foreach ( $candidatos as $candidato ) {
			[$meta, $slug] = $candidato;
			$encontrados   = get_posts(
				array(
					'post_type'              => $tipos,
					'post_status'            => array( 'publish' ),
					'has_password'           => false,
					'numberposts'            => 2,
					'fields'                 => 'ids',
					'suppress_filters'       => false,
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
					'ignore_sticky_posts'    => true,
					'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery
						array(
							'key'     => $meta,
							'value'   => $slug,
							'compare' => '=',
						),
					),
				)
			);

			if ( ! is_array( $encontrados ) || 1 !== count( $encontrados ) ) {
				continue;
			}

			$permalink = get_permalink( (int) $encontrados[0] );

			if ( is_string( $permalink ) && '' !== $permalink && self::normalizar( (string) wp_parse_url( $permalink, PHP_URL_PATH ) ) !== self::normalizar( $path ) ) {
				return $permalink;
			}
		}

		return '';
	}

	/**
	 * Executa o redirecionamento e carimba a atividade.
	 *
	 * @param string $destino Destino absoluto.
	 * @param int    $status  Código HTTP.
	 * @param string $origem  Mecanismo que decidiu.
	 * @return void
	 */
	private function executar( string $destino, int $status, string $origem ): void {
		if ( 410 === $status ) {
			F3Base_Atividade::registrar(
				F3Base_Atividade::REDIRECTS_SERVIDOS,
				array(
					'ultimo_de' => $this->caminho_atual(),
					'mecanismo' => $origem,
					'status'    => 410,
				)
			);
			F3Base_Atividade::incrementar( F3Base_Atividade::REDIRECTS_SERVIDOS, 'total' );

			status_header( 410 );
			nocache_headers();

			/*
			 * O 410 TERMINA A REQUISIÇÃO, e o `return` não terminava. Sem o
			 * `exit`, `template_redirect` seguia adiante, o WordPress carregava o
			 * template e o visitante recebia a PÁGINA — com status 410 no
			 * cabeçalho e o conteúdo no corpo. Rastreador que lê o status remove
			 * o endereço; pessoa que lê o corpo vê a página funcionando. Duas
			 * respostas na mesma requisição, e nenhuma delas é a declarada.
			 *
			 * O corpo é MÍNIMO e de texto puro: "gone" não tem página, e servir
			 * o tema aqui é o defeito que este ramo fecha.
			 */
			if ( ! headers_sent() ) {
				header( 'Content-Type: text/plain; charset=utf-8' );
			}

			echo esc_html( self::CORPO_DO_410 );
			exit;
		}

		$destino = wp_validate_redirect( $destino, '' );
		if ( '' === $destino ) {
			return;
		}

		F3Base_Atividade::registrar(
			F3Base_Atividade::REDIRECTS_SERVIDOS,
			array(
				'ultimo_de'   => $this->caminho_atual(),
				'ultimo_para' => $destino,
				'mecanismo'   => $origem,
				'status'      => $status,
			)
		);
		F3Base_Atividade::incrementar( F3Base_Atividade::REDIRECTS_SERVIDOS, 'total' );

		wp_safe_redirect( $destino, $status, 'base-site-core-fator3' );
		exit;
	}

	/**
	 * Caminho pedido nesta requisição.
	 *
	 * @return string
	 */
	private function caminho_atual(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $uri ) {
			return '';
		}

		$partes = wp_parse_url( $uri );

		$path = is_array( $partes ) && isset( $partes['path'] ) ? (string) $partes['path'] : '';
		$base = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		if ( $base && str_starts_with( $path, $base . '/' ) ) {
			$path = substr( $path, strlen( $base ) ); }
		return F3Base_Redirects_Servico::caminho( $path ) ?? '';
	}

	/**
	 * Pares declarados normalizados.
	 *
	 * @return array<int,array{de:string,para:string,status:int}>
	 */
	private function declarados(): array {
		$regras = F3Base_Options::ler( 'f3base_redirects' );

		if ( ! is_array( $regras ) ) {
			return array(); }
		$out = array();
		foreach ( $regras as $p ) {
			$v = F3Base_Redirects_Servico::validar( array( $p ) );
			if ( $v['ok'] ) {
				$out[] = $v['lista'][0]; }
		}
		// Legacy lists can contain multi-node cycles even when every pair is valid alone.
		$grafo     = F3Base_Redirects_Servico::validar( $out );
		$recusadas = array_column( $grafo['erros'], 'de' );
		return array_values( array_filter( $grafo['lista'], static fn( $p ) => ! in_array( $p['de'], $recusadas, true ) ) );
	}
}
