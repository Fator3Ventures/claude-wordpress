<?php
/** Projeções explícitas e histórico de configuração; nenhuma consulta executa efeitos. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Config_Consultas {
	public const BLOCOS = array( 'integracoes', 'instrucoes', 'procedencia', 'mudancas', 'agenda', 'saude' );
	public static function propriedades(): array {
		return array(
			'compacto'     => array(
				'type'    => 'boolean',
				'default' => false,
			),
			'assuntos'     => array(
				'type'        => 'array',
				'items'       => array( 'type' => 'string' ),
				'uniqueItems' => true,
				'maxItems'    => 100,
			),
			'incluir'      => array(
				'type'        => 'array',
				'items'       => array(
					'type' => 'string',
					'enum' => self::BLOCOS,
				),
				'uniqueItems' => true,
			),
			'desde_versao' => array(
				'type'    => 'string',
				'pattern' => '^[0-9]+\\.[0-9]+\\.[0-9]+(?:-[A-Za-z0-9.-]+)?$',
			),
			'modulo'       => array(
				'type'      => 'string',
				'maxLength' => 80,
			),
			'tipo'         => array(
				'type' => 'string',
				'enum' => array( 'correcao', 'funcionalidade', 'manutencao' ),
			),
			'pagina'       => array(
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => 1000,
			),
			'limite'       => array(
				'type'    => 'integer',
				'minimum' => 1,
				'maximum' => 50,
			),
		);
	}
	public static function validar( $entrada, array $extras = array() ): string {
		if ( null === $entrada ) {
			return ''; }
		if ( ! is_array( $entrada ) ) {
			return 'entrada_invalida'; }
		if ( array_diff( array_keys( $entrada ), array_merge( array_keys( self::propriedades() ), $extras ) ) ) {
			return 'filtro_desconhecido'; }
		$r = rest_validate_value_from_schema(
			array_diff_key( $entrada, array_flip( $extras ) ),
			array(
				'type'                 => 'object',
				'properties'           => self::propriedades(),
				'additionalProperties' => false,
			)
		);
		if ( is_wp_error( $r ) ) {
			return 'filtro_invalido'; }
		$ids = array_map( static fn( $m ) => $m->id(), F3Base_Registro::modulos() );
		if ( isset( $entrada['modulo'] ) && ! in_array( $entrada['modulo'], array_merge( $ids, array( 'configuracao', 'operacao' ) ), true ) ) {
			return 'modulo_desconhecido'; }
		return array_diff( $entrada['assuntos'] ?? array(), $ids ) ? 'assunto_desconhecido' : '';
	}
	public static function incluir( array $entrada, string $bloco ): bool {
		return in_array( $bloco, $entrada['incluir'] ?? ( empty( $entrada['compacto'] ) ? array( 'integracoes', 'instrucoes' ) : array() ), true );
	}
	public static function nomes_por_assuntos( array $entrada ): ?array {
		if ( ! array_key_exists( 'assuntos', $entrada ) ) {
			return null; }
		$nomes = array();
		foreach ( F3Base_Registro::modulos() as $m ) {
			if ( in_array( $m->id(), $entrada['assuntos'], true ) ) {
				$nomes = array_merge( $nomes, $m->options_que_controlam() ); }
		}
		return array_values( array_unique( $nomes ) );
	}
	/** Histórico carregado somente por solicitação; a versão é comparada semanticamente. */
	public static function mudancas( array $entrada ): array {
		$arquivo = dirname( __DIR__ ) . '/dados/mudancas.json';
		$itens   = is_readable( $arquivo ) ? json_decode( (string) file_get_contents( $arquivo ), true ) : array(); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- arquivo local do pacote, sem origem remota.
		$itens   = is_array( $itens ) ? $itens : array();
		$desde   = $entrada['desde_versao'] ?? '0.0.0';
		$itens   = array_values( array_filter( $itens, static fn( $r ) => is_array( $r ) && version_compare( (string) ( $r['versao'] ?? '0.0.0' ), $desde, '>' ) && ( ! isset( $entrada['modulo'] ) || ( $r['modulo'] ?? '' ) === $entrada['modulo'] ) && ( ! isset( $entrada['tipo'] ) || ( $r['tipo'] ?? '' ) === $entrada['tipo'] ) && ( ! isset( $entrada['assuntos'] ) || in_array( $r['modulo'] ?? '', $entrada['assuntos'], true ) ) ) );
		usort( $itens, static fn( $a, $b ) => version_compare( $a['versao'], $b['versao'], '<' ) ? 1 : ( version_compare( $a['versao'], $b['versao'], '>' ) ? -1 : 0 ) );
		$pagina = (int) ( $entrada['pagina'] ?? 1 );
		$limite = (int) ( $entrada['limite'] ?? 20 );
		return array(
			'itens'          => array_slice( $itens, ( $pagina - 1 ) * $limite, $limite ),
			'total'          => count( $itens ),
			'pagina'         => $pagina,
			'limite'         => $limite,
			'proxima_pagina' => $pagina * $limite < count( $itens ) ? $pagina + 1 : null,
		);
	}
	/** Cópias são referências somente quando ID e geração coincidem. Estado atual é separado. */
	public static function integracoes( bool $compacto ): array {
		$cache = F3Base_Cache_Pagina::resumo();
		if ( $compacto ) {
			if ( isset( $cache['tokens'], $cache['evidencia']['tokens'] ) && $cache['tokens'] === $cache['evidencia']['tokens'] ) {
				$cache['evidencia']['tokens'] = array( 'referencia' => 'integracoes.cache.tokens' ); }
			foreach ( array( 'ultima_tentativa', 'ultimo_sucesso' ) as $chave ) {
				$prova = $cache['historico'][ $chave ] ?? array();
				$atual = $cache['evidencia'] ?? array();
				if ( ! empty( $prova['id'] ) && ! empty( $prova['geracao'] ) && ( $atual['id'] ?? null ) === $prova['id'] && ( $atual['geracao'] ?? null ) === $prova['geracao'] ) {
					$cache['historico'][ $chave ] = array(
						'id'         => $prova['id'],
						'geracao'    => $prova['geracao'],
						'referencia' => 'integracoes.cache.evidencia',
					); }
			}
		}
		return array(
			'cache'      => $cache,
			'publicacao' => F3Base_Llms::responsaveis(),
		);
	}
}
