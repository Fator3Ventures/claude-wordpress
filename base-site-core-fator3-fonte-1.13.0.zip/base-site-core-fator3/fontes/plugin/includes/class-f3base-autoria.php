<?php
/** Uma política de autoria para schema, metadados e integração dos temas. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Autoria {
	public static array $organizacao = array();
	public static function modo( int $id ): string {
		$meta = get_post_meta( $id, '_f3base_autoria', true );
		if ( in_array( $meta, array( 'usuario', 'organizacao' ), true ) ) {
			return $meta; }
		// Não ler a option normalizada: um padrão injetado ocultaria o legado.
		$v = get_option( 'f3base_seo_entidade', array() );
		if ( in_array( $v['autoria'] ?? '', array( 'usuario', 'organizacao' ), true ) ) {
			return $v['autoria']; }
		return ! empty( $v['autor_institucional'] ) ? 'organizacao' : 'usuario';
	}
	public static function organizacao_configurada(): array {
		$v = get_option( 'wpseo_titles', array() );
		if ( ! F3Base_Llms::plugin_de_seo_ativo() || 'company' !== ( $v['company_or_person'] ?? '' ) ) {
			return array(); }
		$nome = (string) ( $v['company_name'] ?? '' );
		if ( '' === $nome ) {
			$nome = get_bloginfo( 'name' ); }
		return array(
			'name' => $nome,
			'url'  => home_url( '/' ),
		);
	}
	public static function nome( int $id ): string {
		$post = get_post( $id );
		if ( ! $post ) {
			return ''; }
		if ( 'organizacao' === self::modo( $id ) ) {
			$org = self::$organizacao ? self::$organizacao : self::organizacao_configurada();
			if ( $org ) {
				return $org['name']; }
		}
		return (string) get_the_author_meta( 'display_name', (int) $post->post_author );
	}
	public static function grafo( array $grafo ): array {
		$id = (int) get_queried_object_id();
		if ( ! is_singular() || 'organizacao' !== self::modo( $id ) ) {
			return $grafo; }
		$org = null;
		foreach ( $grafo as $no ) {
			if ( is_array( $no ) && in_array( 'Organization', (array) ( $no['@type'] ?? array() ), true ) && ! empty( $no['@id'] ) && ( empty( self::$organizacao['@id'] ) || self::$organizacao['@id'] === $no['@id'] ) ) {
				$org = $no;
				break; }
		}
		if ( $org ) {
			self::$organizacao = $org; }
		if ( ! $org ) {
			return $grafo; }
		foreach ( $grafo as &$no ) {
			if ( ! is_array( $no ) || ! array_intersect( (array) ( $no['@type'] ?? array() ), array( 'Article', 'BlogPosting', 'NewsArticle' ) ) ) {
				continue; }
			// Só a peça principal vinculada à página consultada, sem apagar Persons.
			$pagina = $no['mainEntityOfPage']['@id'] ?? $no['isPartOf']['@id'] ?? '';
			if ( $pagina && strtok( $pagina, '#' ) !== strtok( get_permalink( $id ), '#' ) ) {
				continue; }
			$no['author'] = array_intersect_key( $org, array_flip( array( '@type', '@id', 'name', 'url' ) ) );
		}
		unset( $no );
		return $grafo;
	}
	public static function metaauthor( $nome ) {
		$id = (int) get_queried_object_id();
		return is_singular( 'post' ) && 'organizacao' === self::modo( $id ) && self::organizacao_configurada() ? self::nome( $id ) : $nome;
	}
	public static function slack( $dados ) {
		if ( ! is_array( $dados ) || ! is_singular( 'post' ) ) {
			return $dados; }
		$chave = __( 'Written by', 'wordpress-seo' );
		if ( array_key_exists( $chave, $dados ) ) {
			$dados[ $chave ] = self::metaauthor( $dados[ $chave ] ); }
		return $dados;
	}
	public static function caixas(): void {
		foreach ( get_post_types( array( 'public' => true ) ) as $tipo ) {
			add_meta_box( 'f3base-autoria', 'Autoria exibida', array( __CLASS__, 'caixa' ), $tipo, 'side' ); }
	}
	public static function caixa( $post ): void {
		wp_nonce_field( 'f3base_autoria', 'f3base_autoria_nonce' );
		$v = get_post_meta( $post->ID, '_f3base_autoria', true );
		echo '<select name="f3base_autoria">';
		foreach ( array(
			''            => 'Padrão do site',
			'usuario'     => 'Usuário',
			'organizacao' => 'Institucional',
		) as $k => $label ) {
			echo '<option value="' . esc_attr( $k ) . '" ' . selected( $v, $k, false ) . '>' . esc_html( $label ) . '</option>'; }
		echo '</select><p>O usuário responsável no WordPress é preservado.</p>';
		$user = get_userdata( (int) $post->post_author );
		if ( $user && $user->display_name === $user->user_login ) {
			echo '<p>Revise o nome de exibição: ele coincide com o login.</p>'; }
	}
	public static function salvar( int $id ): void {
		if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! current_user_can( 'edit_post', $id ) || ! isset( $_POST['f3base_autoria_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['f3base_autoria_nonce'] ) ), 'f3base_autoria' ) ) {
			return; }
		$v = sanitize_text_field( wp_unslash( $_POST['f3base_autoria'] ?? '' ) );
		if ( '' === $v ) {
			delete_post_meta( $id, '_f3base_autoria' ); } elseif ( in_array( $v, array( 'usuario', 'organizacao' ), true ) ) {
			update_post_meta( $id, '_f3base_autoria', $v ); }
	}
}
