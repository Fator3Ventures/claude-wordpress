<?php
/** Revocable content grants; a counted download is an authorized GET attempt. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Conteudo_Privado {
	public static function iniciar(): void {
		add_action( 'admin_post_f3base_conteudo', array( __CLASS__, 'download' ) );
		add_action( 'admin_post_nopriv_f3base_conteudo', array( __CLASS__, 'download' ) );
	}
	private static function assinatura( string $id ): string {
		return hash_hmac( 'sha256', 'f3base-conteudo|' . $id, wp_salt( 'secure_auth' ) ); }
	public static function link( string $id ): string {
		return add_query_arg(
			array(
				'action'     => 'f3base_conteudo',
				'g'          => $id,
				'assinatura' => self::assinatura( $id ),
			),
			admin_url( 'admin-post.php' )
		); }
	public static function conceder( string $record, array $f, string $email ): array {
		global $wpdb;
		$t     = F3Base_Leads_Repositorio::tabela( 'concessoes' );
		$ativo = F3Base_Arquivos_Privados::obter( $f['ativo'] ?? '' );
		if ( ! $ativo || 'conteudo' !== $ativo['finalidade'] || 'ativo' !== $ativo['estado'] || ! is_file( F3Base_Arquivos_Privados::caminho( $ativo['id'] ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'ativo_indisponivel',
			); }
		$dedup = hash_hmac( 'sha256', strtolower( $email ) . '|' . $ativo['id'] . '|' . $ativo['sha256'], wp_salt( 'auth' ) );
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET dedup=NULL WHERE dedup=%s AND (expira<%d OR usados>=quota OR revogada=1)', $t, $dedup, time() ) );
		$id  = bin2hex( random_bytes( 16 ) );
		$old = $wpdb->suppress_errors( true );
		$ok  = $wpdb->insert(
			$t,
			array(
				'id'             => $id,
				'lead_record_id' => $record,
				'ativo'          => $ativo['id'],
				'versao'         => $ativo['sha256'],
				'dedup'          => $dedup,
				'expira'         => time() + (int) ( $f['validade_dias'] ?? 7 ) * DAY_IN_SECONDS,
				'quota'          => (int) ( $f['quota'] ?? 5 ),
			)
		);
		$wpdb->suppress_errors( $old );
		if ( ! $ok ) {
			$r    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE dedup=%s', $t, $dedup ), ARRAY_A );
			$lead = $r ? F3Base_Leads_Repositorio::obter( $r['lead_record_id'] ) : null;
			if ( ! $r || ! $lead || $lead['eliminacao_pendente'] || $lead['lixeira'] || $r['revogada'] || $r['expira'] < time() || $r['usados'] >= $r['quota'] ) {
				return array(
					'ok'     => false,
					'codigo' => 'concessao_em_conciliacao',
				); }
			return array(
				'ok'        => true,
				'duplicado' => true,
				'record_id' => $r['lead_record_id'],
				'url'       => self::link( $r['id'] ),
			);
		}
		return array(
			'ok'        => true,
			'duplicado' => false,
			'record_id' => $record,
			'url'       => self::link( $id ),
		);
	}
	public static function download(): void {
		nocache_headers();
		header( 'Cache-Control: private, no-store' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		$id  = (string) ( $_GET['g'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public download validates a purpose-bound HMAC and stored grant; a logged-in WordPress nonce is not the credential.
		$sig = (string) ( $_GET['assinatura'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Public download validates a purpose-bound HMAC and stored grant; a logged-in WordPress nonce is not the credential.
		if ( ! preg_match( '/^[a-f0-9]{32}$/D', $id ) || ! hash_equals( self::assinatura( $id ), $sig ) ) {
			status_header( 404 );
			exit; }
		$head = 'HEAD' === ( $_SERVER['REQUEST_METHOD'] ?? 'GET' );
		if ( ! $head && 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			status_header( 405 );
			exit; }
		if ( ! empty( $_SERVER['HTTP_RANGE'] ) ) {
			status_header( 416 );
			exit; }
		global $wpdb;
		$t    = F3Base_Leads_Repositorio::tabela( 'concessoes' );
		$g    = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id=%s', $t, $id ), ARRAY_A );
		$lead = $g ? F3Base_Leads_Repositorio::obter( $g['lead_record_id'] ) : null;
		$a    = $g ? F3Base_Arquivos_Privados::obter( $g['ativo'] ) : null;
		if ( ! $g || ! $lead || ! $a || $lead['eliminacao_pendente'] || $lead['lixeira'] || $g['revogada'] || $g['expira'] < time() || $g['usados'] >= $g['quota'] || $a['sha256'] !== $g['versao'] || 'ativo' !== $a['estado'] ) {
			status_header( 410 );
			exit; }
		if ( ! $head && 1 !== $wpdb->query( $wpdb->prepare( 'UPDATE %i SET usados=usados+1,ultima=%d,primeira=CASE WHEN primeira=0 THEN %d ELSE primeira END WHERE id=%s AND revogada=0 AND expira>=%d AND usados<quota', $t, time(), time(), $id, time() ) ) ) {
			status_header( 410 );
			exit; }
		F3Base_Arquivos_Privados::entregar( $a, $head );
	}
}
