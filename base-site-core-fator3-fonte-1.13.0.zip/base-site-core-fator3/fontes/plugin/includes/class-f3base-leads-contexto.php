<?php
/** Contexto canônico compartilhado por cliques e formulários. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) { exit; }
final class F3Base_Leads_Contexto {
    public static function sessao( $valor ): ?string {
        return is_string( $valor ) && preg_match( '/^[a-f0-9]{32}$/D', $valor ) ? $valor : null;
    }
    /** Nunca usa nome/e-mail para inferir a ação de um CTA. */
    public static function destino( string $url ): array {
        if ( '' === $url ) { return array( 'metodo' => 'contato_cta', 'tipo' => 'indisponivel' ); }
        $p = wp_parse_url( $url );
        if ( false === $p || preg_match( '/[\x00-\x20\x7f]/', $url ) ) { return array( 'metodo' => 'contato_cta', 'tipo' => 'invalido' ); }
        $scheme = strtolower( $p['scheme'] ?? '' );
        $host = strtolower( $p['host'] ?? '' );
        $wa = ( 'whatsapp' === $scheme && 'send' === $host ) ||
            ( in_array( $scheme, array( 'http', 'https' ), true ) && in_array( $host, array( 'wa.me', 'api.whatsapp.com', 'web.whatsapp.com' ), true ) && empty( $p['user'] ) && empty( $p['pass'] ) && ( empty( $p['port'] ) || ( 'https' === $scheme && 443 === $p['port'] ) || ( 'http' === $scheme && 80 === $p['port'] ) ) );
        $tipo = $wa ? 'whatsapp' : ( 'tel' === $scheme ? 'telefone' : ( 'mailto' === $scheme ? 'email' : ( in_array( $scheme, array( '', 'http', 'https' ), true ) ? ( ! $host || $host === strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) ? 'interno' : 'externo' ) : 'invalido' ) ) );
        return array( 'metodo' => $wa ? 'whatsapp_cta' : 'contato_cta', 'tipo' => $tipo );
    }
    public static function pagina( string $url ): int {
        if ( '' === $url ) { return 0; }
        $p = wp_parse_url( $url );
        $site_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( false === $p || isset( $p['user'] ) || ( isset( $p['host'] ) && strtolower( $p['host'] ) !== $site_host ) ) { return 0; }
        $url = isset( $p['host'] ) ? $url : home_url( '/' . ltrim( $url, '/' ) );
        $id = url_to_postid( $url );
        if ( ! $id && untrailingslashit( $url ) === untrailingslashit( home_url() ) ) { $id = (int) get_option( 'page_on_front' ); }
        $post = $id ? get_post( $id ) : null;
        return $post instanceof WP_Post && is_post_publicly_viewable( $post ) && '' === $post->post_password ? (int) $id : 0;
    }
    /** Dados de rede vêm exclusivamente da requisição recebida pelo servidor. */
    public static function capturar( array $d, bool $medicao ): array {
        $origem = F3Base_Modulo_Endpoint_Leads::origem();
        $ip = filter_var( $origem['valor'] ?? '', FILTER_VALIDATE_IP ) ?: null;
        $d['navegacao'] = $medicao ? self::sessao($d['navegacao'] ?? null) : null;
        $d['dispositivo'] = $medicao && in_array($d['dispositivo']??'',array('movel','desktop'),true) ? $d['dispositivo'] : '';
        $d['sessao'] = $medicao ? self::sessao( $d['sessao'] ?? null ) : null;
        $d['correlacao'] = $d['correlacao'] ?? $d['correlation_id'] ?? null;
        $d['post_id'] = self::pagina( (string) ( $d['pagina'] ?? '' ) ) ?: null;
        $d['contexto'] = array(
            'ip' => $ip, 'ip_fonte' => $origem['fonte'] ?? 'indisponivel',
            'user_agent' => substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ), 0, 500 ),
            'post_id' => $d['post_id'], 'versao' => F3BASE_PLUGIN_VERSAO,
            'sessao_motivo' => $d['sessao'] ? 'informada_pelo_tracking' : ( $medicao ? 'tracking_sem_sessao' : 'medicao_nao_permitida' ),
        );
        $d['snapshot'] = array_merge( $d['snapshot'] ?? array(), array(
            'site' => get_bloginfo( 'name' ), 'pagina_titulo' => $d['post_id'] ? get_the_title( $d['post_id'] ) : '',
            'pagina_url' => $d['pagina'] ?? '',
        ) );
        return $d;
    }
}
