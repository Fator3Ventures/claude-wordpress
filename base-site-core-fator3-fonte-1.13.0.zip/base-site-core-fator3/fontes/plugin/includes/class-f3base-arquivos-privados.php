<?php
/** Private blob storage, never WordPress public media. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Arquivos_Privados {
	public static function raiz( bool $criar = false ): string {
		$doc      = (string) ( $_SERVER['DOCUMENT_ROOT'] ?? '' );
		$publicas = array_filter( array( realpath( ABSPATH ), realpath( WP_CONTENT_DIR ), '' !== $doc ? realpath( $doc ) : false ) );
		// The default is stable across HTTP, cron and CLI. A nested public install must configure an external directory.
		$publica = realpath( ABSPATH );
		$base    = defined( 'F3BASE_ARQUIVOS_PRIVADOS' ) ? (string) F3BASE_ARQUIVOS_PRIVADOS : dirname( $publica ) . '/f3-privado-' . substr( hash( 'sha256', ABSPATH ), 0, 16 );
		$parent  = realpath( dirname( $base ) );
		if ( ! $parent || is_link( $base ) ) {
			return ''; }
		$candidato = $parent . '/' . basename( $base );
		foreach ( $publicas as $pub ) {
			if ( $candidato === $pub || str_starts_with( $candidato, $pub . DIRECTORY_SEPARATOR ) ) {
				return ''; }
		}
		if ( ! is_dir( $candidato ) && $criar && ! @mkdir( $candidato, 0700 ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_mkdir -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			return ''; }
		$real = realpath( $candidato );
		if ( ! $real || $real !== $candidato || is_link( $candidato ) || ! is_writable( $real ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			return ''; }
		return $real;
	}
    public static function politica( array $campo = array() ): array {
        return array( 'teto_plugin_bytes' => isset( $campo['max_bytes'] ) && (int) $campo['max_bytes'] > 0 ? (int) $campo['max_bytes'] : null,
            'extensoes_plugin' => array_values( (array) ( $campo['extensoes'] ?? array() ) ), 'max_arquivos_campo' => (int) ( $campo['max_arquivos'] ?? 5 ) );
    }
    public static function inspecao(): array {
        $publica = realpath( ABSPATH );
        $base = defined( 'F3BASE_ARQUIVOS_PRIVADOS' ) ? (string) F3BASE_ARQUIVOS_PRIVADOS : dirname( $publica ) . '/f3-privado-' . substr( hash( 'sha256', ABSPATH ), 0, 16 );
        $parent = realpath( dirname( $base ) );
        $codigo = 'caminho_invalido'; $criavel = false;
        if ( $parent && str_starts_with( $base, DIRECTORY_SEPARATOR ) && ! is_link( $base ) ) {
            $path = $parent . '/' . basename( $base ); $codigo = '';
            foreach ( array_filter( array( realpath( ABSPATH ), realpath( WP_CONTENT_DIR ), ! empty( $_SERVER['DOCUMENT_ROOT'] ) ? realpath( $_SERVER['DOCUMENT_ROOT'] ) : false ) ) as $pub ) {
                if ( $path === $pub || str_starts_with( $path, $pub . DIRECTORY_SEPARATOR ) ) { $codigo = 'dentro_da_raiz_publica'; break; }
            }
            if ( ! $codigo ) {
                if ( is_dir( $path ) ) { $codigo = is_writable( $path ) ? 'pronto' : 'sem_permissao'; }
                elseif ( file_exists( $path ) ) { $codigo = 'caminho_invalido'; }
                else { $criavel = is_writable( $parent ); $codigo = $criavel ? 'ausente_criavel' : 'sem_permissao'; }
            }
        }
        return array( 'codigo' => $codigo, 'criavel' => $criavel, 'disponivel' => 'pronto' === $codigo, 'protecao' => 'fora_das_raizes_publicas_conhecidas', 'verificacao_alias_hospedagem' => 'pendente' );
    }
    public static function diagnostico( array $campo = array() ): array {
        $raiz = self::raiz(); $info = self::inspecao(); $free = $raiz ? disk_free_space( $raiz ) : false;
        if ( false !== $free && $free <= 0 ) { $info['codigo'] = 'espaco_insuficiente'; $info['disponivel'] = false; }
        $definicoes = array();
        foreach ( (array) F3Base_Options::ler( 'f3base_formularios' ) as $form ) {
            foreach ( $form['campos'] ?? array() as $f ) {
                if ( 'file' === ( $f['tipo'] ?? '' ) ) { $definicoes[] = array( 'formulario' => $form['id'], 'campo' => $f['nome'] ) + self::politica( $f ); }
            }
        }
        return $info + self::politica( $campo ) + array(
            'upload_max_filesize' => ini_get( 'upload_max_filesize' ), 'upload_max_filesize_bytes' => wp_convert_hr_to_bytes( ini_get( 'upload_max_filesize' ) ),
            'post_max_size' => ini_get( 'post_max_size' ), 'post_max_size_bytes' => wp_convert_hr_to_bytes( ini_get( 'post_max_size' ) ), 'post_limita' => 'requisicao_completa',
            'max_file_uploads' => (int) ini_get( 'max_file_uploads' ), 'max_input_time' => (int) ini_get( 'max_input_time' ),
            'servidor_proxy' => 'limite_desconhecido', 'alerta_ocupacao_bytes' => 1073741824, 'espaco_livre' => false === $free ? null : $free,
            'campos' => $definicoes, 'ultima_preparacao' => F3Base_Options::ler( 'f3base_leads_privado' ),
        );
    }
    public static function provisionar(): array {
        $antes = self::inspecao(); $raiz = self::raiz( true ); $ok = false;
        if ( $raiz ) {
            $path = $raiz . '/.teste-' . bin2hex( random_bytes( 12 ) ); $conteudo = bin2hex( random_bytes( 24 ) );
            $h = @fopen( $path, 'xb' );
            if ( $h ) {
                $ok = strlen( $conteudo ) === fwrite( $h, $conteudo ); fclose( $h );
                $ok = @chmod( $path, 0600 ) && $ok && hash_equals( $conteudo, (string) file_get_contents( $path ) );
                $ok = @unlink( $path ) && $ok;
            }
        }
        $r = array( 'ok' => $ok, 'codigo' => $ok ? 'pronto' : ( $raiz ? 'teste_escrita_falhou' : $antes['codigo'] ), 'em' => time(), 'teste' => 'criar_gravar_ler_remover', 'verificacao_alias_hospedagem' => 'pendente' );
        $salvo = F3Base_Options::atualizar_estado( 'f3base_leads_privado', static fn() => $r );
        $r['persisted'] = ! empty( $salvo['persisted'] ); return $r;
    }
	public static function caminho( string $id ): string {
		if ( ! preg_match( '/^[a-f0-9]{32}$/D', $id ) ) {
			return '';
		} $root = self::raiz();
		if ( ! $root ) {
			return ''; }
		$p = $root . '/' . $id;
		return is_link( $p ) ? '' : $p;
	}
	public static function receber( array $f, string $finalidade = 'anexo', array $campo = array() ): array {
		$erro = (int) ( $f['error'] ?? UPLOAD_ERR_NO_FILE );
		if ( UPLOAD_ERR_OK !== $erro ) {
			return array(
				'ok'     => false,
				'codigo' => 'upload_erro_' . $erro,
			); }
		if ( ! isset( $f['tmp_name'] ) || ! is_uploaded_file( $f['tmp_name'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'upload_nao_autentico',
			); }
		if ( ! class_exists( 'finfo' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'fileinfo_indisponivel',
			); }
		$raiz = self::raiz( true );
		if ( ! $raiz ) {
			return array(
				'ok'     => false,
				'codigo' => 'armazenamento_privado_indisponivel',
			); }
		if ( isset( $campo['max_bytes'] ) && ( ! is_int( $campo['max_bytes'] ) || $campo['max_bytes'] < 0 ) ) { return array( 'ok' => false, 'codigo' => 'limite_invalido' ); }
		$politica = self::politica( $campo );
		$nome = sanitize_file_name( (string) ( $f['name'] ?? 'arquivo' ) );
		$size = filesize( $f['tmp_name'] );
		if ( null !== $politica['teto_plugin_bytes'] && $size > $politica['teto_plugin_bytes'] ) {
			return array(
				'ok'     => false,
				'codigo' => 'limite_do_formulario',
			); }
		if ( ! empty( $politica['extensoes_plugin'] ) && ! in_array( strtolower( pathinfo( $nome, PATHINFO_EXTENSION ) ), $politica['extensoes_plugin'], true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'extensao_nao_permitida_no_formulario',
			); }
		$free = disk_free_space( $raiz );
		if ( false === $size || false === $free || $free < $size ) {
			return array(
				'ok'     => false,
				'codigo' => 'armazenamento_sem_espaco',
			); }
		$id   = bin2hex( random_bytes( 16 ) );
		$dest = $raiz . '/' . $id;
		if ( file_exists( $dest ) || ! move_uploaded_file( $f['tmp_name'], $dest ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'upload_nao_persistido',
			); }
		$permissao = @chmod( $dest, 0600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_chmod -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		if ( ! $permissao ) { @unlink( $dest ); return array( 'ok' => false, 'codigo' => 'permissao_privada_falhou' ); }
		$finfo     = new finfo( FILEINFO_MIME_TYPE );
		$detected  = $finfo->file( $dest );
		$mime      = $detected ? $detected : 'application/octet-stream';
		$hash      = hash_file( 'sha256', $dest );
		global $wpdb;
		$row = array(
			'id'         => $id,
			'dono'       => '',
			'finalidade' => $finalidade,
			'nome'       => $nome,
			'mime'       => $mime,
			'bytes'      => $size,
			'sha256'     => $hash,
			'criado_em'  => time(),
			'estado'     => 'preparado',
		);
		if ( ! $wpdb->insert( F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), $row ) ) {
			@unlink( $dest ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			return array(
				'ok'     => false,
				'codigo' => 'metadados_nao_persistidos',
			); }
		return array(
			'ok'      => true,
			'arquivo' => array(
				'id'     => $id,
				'nome'   => $nome,
				'mime'   => $mime,
				'bytes'  => $size,
				'sha256' => $hash,
			),
		);
	}
	/** Exceptional import calls this only after checking CF7's actual temporary directory. */
	public static function copiar_legado( string $path, string $raiz_temporaria ): array {
		$source = realpath( $path );
		$tmp    = realpath( $raiz_temporaria );
		$root   = self::raiz( true );
		if ( ! $source || ! $tmp || ! $root || is_link( $path ) || ! str_starts_with( $source, $tmp . DIRECTORY_SEPARATOR ) || ! is_file( $source ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'anexo_legado_fora_do_temporario',
			); }
		$size = filesize( $source );
		if ( false === $size || disk_free_space( $root ) < $size ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_espaco',
			); }
		$id   = bin2hex( random_bytes( 16 ) );
		$dest = $root . '/' . $id;
		$out  = fopen( $dest, 'xb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		$in   = fopen( $source, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		if ( ! $out || ! $in ) {
			if ( $out ) {
				fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics. // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
				@unlink( $dest ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics. // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			} if ( $in ) {
				fclose( $in ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics. // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			} return array(
				'ok'     => false,
				'codigo' => 'copia_indisponivel',
			); }
		$bytes = stream_copy_to_stream( $in, $out );
		fclose( $in ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		$permissao = @chmod( $dest, 0600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_chmod -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		if ( ! $permissao || $bytes !== $size || hash_file( 'sha256', $source ) !== hash_file( 'sha256', $dest ) ) {
			@unlink( $dest ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			return array(
				'ok'     => false,
				'codigo' => 'copia_divergente',
			); }
		$detected = ( new finfo( FILEINFO_MIME_TYPE ) )->file( $dest );
		$row      = array(
			'id'         => $id,
			'dono'       => '',
			'finalidade' => 'anexo',
			'nome'       => sanitize_file_name( basename( $source ) ),
			'mime'       => $detected ? $detected : 'application/octet-stream',
			'bytes'      => $size,
			'sha256'     => hash_file( 'sha256', $dest ),
			'criado_em'  => time(),
			'estado'     => 'preparado',
		);
		global $wpdb;
		if ( ! $wpdb->insert( F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), $row ) ) {
			@unlink( $dest ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			return array(
				'ok'     => false,
				'codigo' => 'metadados_nao_persistidos',
			); }
		return array(
			'ok'      => true,
			'arquivo' => array_intersect_key( $row, array_flip( array( 'id', 'nome', 'mime', 'bytes', 'sha256' ) ) ),
		);
	}
	private static function descartar( string $path ): void {
		if ( is_file( $path ) ) {
			@unlink( $path ); } // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Cleanup of an uncommitted opaque file; caller returns failure, never a public success.
	}
	public static function obter( string $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id=%s', F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), $id ), ARRAY_A );
		return $row ? $row : null; }
	public static function vincular( array $anexos, string $record ): bool {
		global $wpdb;
		foreach ( $anexos as $a ) {
			if ( 1 !== $wpdb->update(
				F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ),
				array(
					'dono'   => $record,
					'estado' => 'ativo',
				),
				array(
					'id'     => $a['id'],
					'estado' => 'preparado',
				)
			) ) {
				return false; }
		}
		return true;
	}
	public static function eliminar( string $id ): bool {
		global $wpdb;
		$r = self::obter( $id );
		if ( ! $r ) {
			return true; }
		$wpdb->update( F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), array( 'estado' => 'eliminacao' ), array( 'id' => $id ) );
		$path = self::caminho( $id );
		if ( ! $path || ( is_file( $path ) && ! @unlink( $path ) ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.unlink_unlink -- Local filesystem result is handled by the enclosing recovery/error path; avoid emitting private paths into the public response. Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			return false; }
		return false !== $wpdb->delete( F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), array( 'id' => $id ) );
	}
	public static function entregar( array $a, bool $head = false ): void {
		$path = self::caminho( $a['id'] );
		if ( ! $path || ! is_file( $path ) || ! in_array( $a['estado'], array( 'ativo' ), true ) ) {
			status_header( 404 );
			exit; }
		if ( ! empty( $_SERVER['HTTP_RANGE'] ) ) {
			status_header( 416 );
			exit; }
		nocache_headers();
		header( 'Cache-Control: private, no-store, max-age=0' );
		header( 'Content-Type: application/octet-stream' );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: no-referrer' );
		header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
		header( "Content-Disposition: attachment; filename=\"arquivo\"; filename*=UTF-8''" . rawurlencode( $a['nome'] ) );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Accept-Ranges: none' );
		if ( ! $head ) {
			$h = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
			if ( ! $h ) {
				status_header( 503 );
				exit;
			} while ( ! feof( $h ) ) {
				echo fread( $h, 1048576 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped,WordPress.WP.AlternativeFunctions.file_system_operations_fread -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics. Authenticated binary download uses application/octet-stream, attachment and nosniff; HTML escaping would corrupt the file.
			} fclose( $h ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Local private/atomic storage requires native stream and filesystem operations; WP_Filesystem FTP would not preserve these semantics.
		} exit;
	}
	public static function limpar_orfaos(): void {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT a.id FROM %i a LEFT JOIN %i l ON l.record_id=a.dono WHERE a.finalidade=%s AND a.criado_em<%d AND (a.estado=%s OR l.record_id IS NULL) LIMIT 50', F3Base_Leads_Repositorio::tabela( 'arquivos_leads' ), F3Base_Leads_Repositorio::tabela(), 'anexo', time() - DAY_IN_SECONDS, 'preparado' ) );
		foreach ( $ids as $id ) {
			self::eliminar( $id ); }
	}
}
