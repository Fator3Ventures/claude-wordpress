<?php
/** Importação reservada, com contribuições idempotentes por arquivo e calendário explícito. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Acessos_Coleta {
	public const TABELA = 'f3base_acessos_contribuicoes';
	public const VERSAO = 2;
	private static function estrutura( array &$e ): void {
		global $wpdb;
		if ( (int) ( $e['estrutura'] ?? 0 ) === self::VERSAO ) {
			return; }
		if ( ! ( new F3Base_Modulo_Acessos_Servidor() )->garantir_estrutura() ) {
			throw new RuntimeException( 'Estrutura dos acessos indisponível.' ); }
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t       = $wpdb->prefix . self::TABELA;
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$t} (
 fonte char(64) NOT NULL,
 chave char(64) NOT NULL,
 regra char(64) NOT NULL,
 dia date NOT NULL,
 agente varchar(64) NOT NULL,
 classe_caminho varchar(16) NOT NULL,
 caminho varchar(191) COLLATE utf8mb4_bin NOT NULL,
 status smallint unsigned NOT NULL,
 metodo varchar(5) NOT NULL,
 contagem bigint unsigned NOT NULL,
 PRIMARY KEY  (fonte,chave),
 KEY dia_regra (dia,regra)
 ) ENGINE=InnoDB {$charset};"
		);
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $t ) ) ) !== $t ) {
			throw new RuntimeException( 'Estrutura de contribuições indisponível.' ); }
		$e['estrutura'] = self::VERSAO;
		$e['legado']    = $e['dias'] ?? array();
	}
	/** Processar um arquivo é atômico; uma interrupção não apaga sua contribuição anterior. */
	public static function ler_arquivo( array $arquivo, array $excluidos, string $hoje ): array {
		$max = F3Base_Modulo_Acessos_Servidor::MAX_BYTES_ARQUIVO;
		if ( $arquivo['tamanho'] > $max ) {
			throw new RuntimeException( 'Arquivo excede 96 MiB; coleta externa necessária.' ); }
		$f = @fopen( $arquivo['nome'], 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte. Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		if ( ! $f ) {
			throw new RuntimeException( 'Fonte sem leitura.' ); }
		$ag           = array();
		$caminhos     = array();
		$n            = 0;
		$ignoradas    = 0;
		$adiados      = array();
		$dias         = array();
		$offsets      = array();
		$datas_origem = array();
		$prazo        = microtime( true ) + F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_DIA;
		try {
			while ( false !== ( $bruta = fgets( $f, 32769 ) ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- Laço de streaming encerra em EOF e verifica orçamento e leitura completa.
				if ( microtime( true ) > $prazo ) {
					throw new RuntimeException( 'Orçamento de leitura excedido; contribuição anterior preservada.' ); }
				++$n;
				if ( ! str_ends_with( $bruta, "\n" ) ) {
					while ( ! feof( $f ) && false !== ( $resto = fgets( $f, 32769 ) ) && ! str_ends_with( $resto, "\n" ) ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- Laço de streaming encerra em EOF e verifica orçamento e leitura completa.
						if ( microtime( true ) > $prazo ) {
							throw new RuntimeException( 'Linha excede orçamento.' ); }
					}
					++$ignoradas;
					continue;
				}
				$data = F3Base_Modulo_Acessos_Servidor::data_da_linha( $bruta );
				$r    = F3Base_Modulo_Acessos_Servidor::linha( $bruta, $excluidos );
				if ( ! $data || ! $r ) {
					++$ignoradas;
					continue; }
				$dia = $data->format( 'Y-m-d' );
				if ( preg_match( '~\[([^\]]+)\]~', $bruta, $tm ) ) {
					$original = DateTimeImmutable::createFromFormat( '!d/M/Y:H:i:s O', $tm[1] );
					if ( $original ) {
						$offsets[ $original->format( 'P' ) ]          = true;
						$datas_origem[ $original->format( 'Y-m-d' ) ] = true; }
				}
				if ( $dia >= $hoje ) {
					$adiados[ $dia ] = true;
					continue; }
				$dias[ $dia ] = true;
				$r['dia']     = $dia;
				$p            = $r['caminho'];
				$a            = $r['agente'];
				if ( '' !== $p ) {
					if ( ! isset( $caminhos[ $dia ][ $a ][ $p ] ) && count( $caminhos[ $dia ][ $a ] ?? array() ) >= F3Base_Modulo_Acessos_Servidor::TETO_CAMINHOS_POR_DIA ) {
						$r['caminho']        = '';
						$r['classe_caminho'] = 'outro'; } else {
						$caminhos[ $dia ][ $a ][ $p ] = true; }
				}
				$k = hash( 'sha256', wp_json_encode( array( $dia, $r['agente'], $r['classe_caminho'], $r['caminho'], $r['status'], $r['metodo'] ) ) );
				if ( isset( $ag[ $k ] ) ) {
					++$ag[ $k ]['contagem'];
				} else {
					$ag[ $k ] = $r; }
				if ( count( $ag ) > F3Base_Modulo_Acessos_Servidor::TETO_AGREGADOS ) {
					throw new RuntimeException( 'Teto de agregados excedido; contribuição anterior preservada.' ); }
			}
			if ( ! feof( $f ) || $ignoradas > $n / 2 ) {
				throw new RuntimeException( 'Leitura interrompida ou formato não reconhecido: ' . $ignoradas . ' de ' . $n . ' linhas ignoradas.' ); }
		} finally {
			fclose( $f ); } // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		clearstatcache( true, $arquivo['nome'] );
		if ( @filesize( $arquivo['nome'] ) !== $arquivo['tamanho'] || @filemtime( $arquivo['nome'] ) !== $arquivo['mtime'] ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte.
			throw new RuntimeException( 'Fonte mudou durante a coleta; contribuição anterior preservada.' ); }
		return array(
			'linhas'       => $ag,
			'dias'         => array_keys( $dias ),
			'adiados'      => array_keys( $adiados ),
			'lidas'        => $n,
			'ignoradas'    => $ignoradas,
			'offsets'      => array_keys( $offsets ),
			'datas_origem' => array_keys( $datas_origem ),
		);
	}
	private static function guardar( string $fonte, string $regra, array $linhas ): void {
		global $wpdb;
		$t = $wpdb->prefix . self::TABELA;
		if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
			throw new RuntimeException( 'Banco recusou transação.' ); }
		try {
			if ( false === $wpdb->delete( $t, array( 'fonte' => $fonte ) ) ) {
				throw new RuntimeException( 'Banco recusou contribuição.' ); }
			foreach ( array_chunk( $linhas, 100, true ) as $lote ) {
				$formas = array();
				$v      = array();
				foreach ( $lote as $chave => $r ) {
					$formas[] = '(%s,%s,%s,%s,%s,%s,%s,%d,%s,%d)';
					array_push( $v, $fonte, $chave, $regra, $r['dia'], $r['agente'], $r['classe_caminho'], $r['caminho'], $r['status'], $r['metodo'], $r['contagem'] ); }
				if ( false === $wpdb->query( $wpdb->prepare( "INSERT INTO {$t} (fonte,chave,regra,dia,agente,classe_caminho,caminho,status,metodo,contagem) VALUES " . implode( ',', $formas ), $v ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					throw new RuntimeException( 'Banco recusou lote de contribuições.' ); }
			}
			if ( false === $wpdb->query( 'COMMIT' ) ) {
				throw new RuntimeException( 'Banco não confirmou contribuição.' ); }
		} catch ( Throwable $x ) {
			$wpdb->query( 'ROLLBACK' );
			throw $x; }
	}
	private static function publicar( array &$e, string $regra, string $corte, string $hoje ): void {
		global $wpdb;
		$t    = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$f    = $wpdb->prefix . self::TABELA;
		$dias = (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT dia FROM {$f} WHERE dia >= %s AND dia < %s AND regra = %s", $corte, $hoje, $regra ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
		foreach ( $e['fontes'] ?? array() as $s ) {
			if ( ( $s['regra'] ?? '' ) === $regra && empty( $s['erro'] ) && $s['rotacao'] >= $corte && $s['rotacao'] < $hoje ) {
				$dias[] = $s['rotacao']; }
		}
		// Uma fonte que ainda sustenta um dia legado não é publicada em outro calendário:
		// isso contaria os mesmos acessos tanto no dia antigo quanto no novo.
		$dependencias = array();
		$bloqueadas   = array();
		foreach ( $e['legado'] ?? array() as $ldia => $legado ) {
			$ids = (array) ( $legado['fontes'] ?? array() );
			foreach ( $legado['arquivos'] ?? array() as $a ) {
				$ids[] = hash( 'sha256', $a['nome'] );
			} $dependencias[ $ldia ] = array_unique( $ids );
			$completa                = self::fontes_do_dia_completas( $ldia, $e, $regra );
			foreach ( $ids as $id ) {
				$fonte = $e['fontes'][ $id ] ?? array();
				if ( empty( $fonte['disponivel'] ) || ( $fonte['regra'] ?? '' ) !== $regra || ! empty( $fonte['erro'] ) ) {
					$completa = false; }
			}
			if ( ! $completa ) {
				foreach ( $ids as $id ) {
					$bloqueadas[ $id ] = true; }
			}
		}
		do {
			$antes = count( $bloqueadas );
			foreach ( $dependencias as $ids ) {
				if ( array_intersect( $ids, array_keys( $bloqueadas ) ) ) {
					foreach ( $ids as $id ) {
							$bloqueadas[ $id ] = true;
					}
				}
			}
		} while ( count( $bloqueadas ) !== $antes ); // phpcs:ignore Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- Convergência/teto depende do tamanho atualizado nesta iteração; coleção limitada pelo orçamento.
		foreach ( array_unique( $dias ) as $dia ) {
			$legado     = $e['legado'][ $dia ] ?? null;
			$incompleto = false;
			$fontes     = array();
			foreach ( (array) ( $legado['fontes'] ?? array() ) as $id ) {
				$anterior = $e['fontes'][ $id ] ?? array();
				if ( ( $anterior['regra'] ?? '' ) !== $regra || empty( $anterior['disponivel'] ) ) {
					$incompleto = true; }
			}
			foreach ( (array) ( $legado['arquivos'] ?? array() ) as $a ) {
				$estado = $e['fontes'][ hash( 'sha256', $a['nome'] ) ] ?? array();
				if ( ( $estado['regra'] ?? '' ) !== $regra || empty( $estado['disponivel'] ) || ! empty( $estado['erro'] ) ) {
					$incompleto = true; }
			}
			foreach ( $e['fontes'] ?? array() as $id => $s ) {
				if ( ! in_array( $dia, $s['dias'] ?? array(), true ) && $dia !== $s['rotacao'] ) {
					continue; }
				$fontes[] = $id;
				if ( isset( $bloqueadas[ $id ] ) ) {
					$incompleto = true; }
				if ( ( $s['regra'] ?? '' ) !== $regra || ! empty( $s['erro'] ) || ( ! empty( $s['adiados'] ) && min( $s['adiados'] ) <= $dia ) ) {
					$incompleto = true; }
			}
			if ( $incompleto || ( $legado && ! self::fontes_do_dia_completas( $dia, $e, $regra ) ) ) {
				continue; }
			$versoes = array();
			foreach ( $fontes as $id ) {
				$fonte          = $e['fontes'][ $id ];
				$versoes[ $id ] = array( $fonte['assinatura'] ?? '', $fonte['regra'] ?? '', $fonte['dias'] ?? array(), $fonte['adiados'] ?? array() );
			} ksort( $versoes );
			$assinatura = hash( 'sha256', wp_json_encode( array( $regra, $dia, $versoes ) ) );
			if ( ( $e['dias'][ $dia ]['assinatura_contribuicoes'] ?? '' ) === $assinatura ) {
				continue; }
			if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
				throw new RuntimeException( 'Banco recusou publicação.' ); }
			try {
				if ( false === $wpdb->delete( $t, array( 'dia' => $dia ) ) ) {
					throw new RuntimeException( 'Banco recusou atualização do dia.' ); }
				$sql = "INSERT INTO {$t} (dia,agente,classe_caminho,caminho,status,metodo,contagem) SELECT dia,agente,classe_caminho,caminho,status,metodo,SUM(contagem) FROM {$f} WHERE dia=%s AND regra=%s GROUP BY dia,agente,classe_caminho,caminho,status,metodo";
				if ( false === $wpdb->query( $wpdb->prepare( $sql, $dia, $regra ) ) || false === $wpdb->query( 'COMMIT' ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					throw new RuntimeException( 'Banco não confirmou publicação do dia.' ); }
			} catch ( Throwable $x ) {
				$wpdb->query( 'ROLLBACK' );
				throw $x; }
			$e['dias'][ $dia ] = array(
				'config_hash'              => $regra,
				'regra'                    => $regra,
				'fuso'                     => wp_timezone_string(),
				'fontes'                   => $fontes,
				'assinatura_contribuicoes' => $assinatura,
				'inspecionado_em'          => time(),
			);
			unset( $e['legado'][ $dia ] );
		}
	}
	public static function executar(): array {
		global $wpdb;
		if ( empty( F3Base_Modulo_Acessos_Servidor::config()['ligado'] ) ) {
			return array( 'erro' => 'Coleta desligada.' ); }
		$lock = @fopen( get_temp_dir() . 'f3base-acessos-' . hash( 'sha256', ABSPATH . $wpdb->prefix ) . '.lock', 'c' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- Falha de filesystem vira diagnóstico explícito; warnings nativos não podem contaminar o transporte. Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
		if ( ! $lock || ! flock( $lock, LOCK_EX | LOCK_NB ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			} return array( 'em_curso' => true ); }
		$e              = F3Base_Options::ler( 'f3base_acessos_estado' );
		$e['tentativa'] = time();
		$e['erro']      = '';
		$e['pendentes'] = 0;
		try {
			self::estrutura( $e );
			$c     = F3Base_Modulo_Acessos_Servidor::config();
			$regra = F3Base_Modulo_Acessos_Servidor::config_hash();
			$hoje  = wp_date( 'Y-m-d' );
			if ( isset( $e['config_hash'] ) && $e['config_hash'] !== $regra ) {
				foreach ( $e['dias'] ?? array() as $dia => $anterior ) {
					$e['legado'][ $dia ] = $anterior; }
			}
			$corte = F3Base_Modulo_Acessos_Servidor::corte( (int) $c['retencao_meses'] );
			foreach ( $e['fontes'] ?? array() as $id => $s ) {
				$e['fontes'][ $id ]['disponivel'] = false; }
			$arquivos                 = F3Base_Modulo_Acessos_Servidor::arquivos( $c['padrao_do_log'] );
			$e['inspecionado_em']     = time();
			$e['rotacoes_observadas'] = array_keys( $arquivos );
			$prazo                    = microtime( true ) + F3Base_Modulo_Acessos_Servidor::MAX_SEGUNDOS_LOTE;
			$falhas                   = array();
			foreach ( $arquivos as $rotacao => $grupo ) {
				if ( $rotacao < $corte ) {
					continue; }
				foreach ( $grupo as $arquivo ) {
					$id                 = hash( 'sha256', $arquivo['nome'] );
					$ass                = hash( 'sha256', wp_json_encode( $arquivo ) );
					$s                  = $e['fontes'][ $id ] ?? array();
					$s['disponivel']    = true;
					$s['rotacao']       = $rotacao;
					$e['fontes'][ $id ] = $s;
					$adiado             = ! empty( $s['adiados'] ) && min( $s['adiados'] ) < $hoje;
					if ( ( $s['assinatura'] ?? '' ) === $ass && ( $s['regra'] ?? '' ) === $regra && ! $adiado && empty( $s['erro'] ) ) {
						continue; }
					if ( microtime( true ) >= $prazo ) {
						++$e['pendentes'];
						continue; }
					try {
						$lido = self::ler_arquivo( $arquivo, $c['caminhos_excluidos'], $hoje );
						self::guardar( $id, $regra, $lido['linhas'] );
						$e['fontes'][ $id ] = array(
							'rotacao'         => $rotacao,
							'assinatura'      => $ass,
							'regra'           => $regra,
							'fuso'            => wp_timezone_string(),
							'dias'            => $lido['dias'],
							'offsets'         => $lido['offsets'],
							'datas_origem'    => $lido['datas_origem'],
							'adiados'         => $lido['adiados'],
							'disponivel'      => true,
							'inspecionado_em' => time(),
							'erro'            => '',
						);
						$e['ultima']        = array(
							'arquivo'   => basename( $arquivo['nome'] ),
							'linhas'    => $lido['lidas'],
							'ignoradas' => $lido['ignoradas'],
							'gravadas'  => count( $lido['linhas'] ),
						);
						$r                  = F3Base_Options::gravar( 'f3base_acessos_estado', $e );
						if ( array_key_exists( 'persisted', $r ) ? ! $r['persisted'] : empty( $r['ok'] ) ) {
							throw new RuntimeException( 'Checkpoint não persistido; arquivo será retomado idempotentemente.' ); }
					} catch ( Throwable $x ) {
						$e['fontes'][ $id ]['erro'] = $x->getMessage();
						$falhas[]                   = basename( $arquivo['nome'] ) . ': ' . $x->getMessage(); }
				}
			}
			foreach ( $e['fontes'] ?? array() as $s ) {
				if ( empty( $s['disponivel'] ) && ! empty( $s['adiados'] ) ) {
					$falhas[] = 'Fonte indisponível antes da revisita; cobertura adiada não recuperável.'; }
			}
			if ( ! $e['pendentes'] && ! $falhas ) {
				self::publicar( $e, $regra, $corte, $hoje ); }
			foreach ( array( F3Base_Modulo_Acessos_Servidor::TABELA, self::TABELA ) as $sufixo ) {
				$t = $wpdb->prefix . $sufixo;
				if ( false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE dia < %s", $corte ) ) ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
					throw new RuntimeException( 'Retenção recusada.' ); }
			}
			foreach ( array( 'dias', 'legado' ) as $campo ) {
				foreach ( $e[ $campo ] ?? array() as $d => $s ) {
					if ( $d < $corte ) {
						unset( $e[ $campo ][ $d ] ); }
				}
			}
			foreach ( $e['fontes'] ?? array() as $id => $s ) {
				if ( $s['rotacao'] < $corte ) {
					unset( $e['fontes'][ $id ] ); }
			}
			$e['config_hash']            = $regra;
			$e['dias_regras_anteriores'] = count( array_filter( $e['dias'] ?? array(), static fn( $d ) => ( $d['regra'] ?? '' ) !== $regra ) );
			$e['erro']                   = implode( ' | ', array_unique( array_slice( $falhas, 0, 5 ) ) );
			if ( ! $e['pendentes'] && ! $e['erro'] ) {
				$e['ultima_soma'] = time();
				F3Base_Atividade::registrar( 'ultima_soma_acessos', $e['ultima'] ?? array() ); }
			if ( $e['pendentes'] ) {
				F3Base_Modulo_Acessos_Servidor::solicitar(); }
		} catch ( Throwable $x ) {
			$e['erro'] = $x->getMessage(); } finally {
			$e['config_hash'] = F3Base_Modulo_Acessos_Servidor::config_hash();
			F3Base_Options::gravar( 'f3base_acessos_estado', $e );
			flock( $lock, LOCK_UN );
			fclose( $lock ); } // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Streaming/offset/flock requer recurso PHP; arquivo e leitura são limitados e verificados.
			return $e;
	}
	private static function fontes_do_dia_completas( string $dia, array $e, string $regra ): bool {
		$offsets  = array();
		$rotacoes = array();
		foreach ( $e['fontes'] ?? array() as $f ) {
			if ( ( $f['regra'] ?? '' ) !== $regra || ! empty( $f['erro'] ) ) {
				continue; }
			if ( count( $f['datas_origem'] ?? array() ) > 1 || ( ! empty( $f['datas_origem'] ) && $f['datas_origem'][0] !== $f['rotacao'] ) ) {
				continue; }
			foreach ( $f['offsets'] ?? array() as $offset ) {
				$offsets[ $offset ] = true; }
			$rotacoes[ $f['rotacao'] ] = true;
		}
		if ( ! $offsets ) {
			return false; }
		$a = new DateTimeImmutable( $dia, wp_timezone() );
		$b = $a->modify( '+1 day' )->modify( '-1 second' );
		foreach ( array_keys( $offsets ) as $offset ) {
			$zone = new DateTimeZone( $offset );
			$da   = $a->setTimezone( $zone )->format( 'Y-m-d' );
			$db   = $b->setTimezone( $zone )->format( 'Y-m-d' );
			for ( $d = new DateTimeImmutable( $da, $zone ); $d->format( 'Y-m-d' ) <= $db; $d = $d->modify( '+1 day' ) ) { // phpcs:ignore Generic.CodeAnalysis.ForLoopWithTestFunctionCall.NotAllowed -- Iteração de calendário/ascendentes limitada por janela ou profundidade explícita.
				if ( ! isset( $rotacoes[ $d->format( 'Y-m-d' ) ] ) ) {
					return false; }
			}
		}
		return true;
	}

	/** A ausência de fonte só é afirmada após descoberta bem-sucedida da janela. */
	public static function cobertura( string $inicio, string $fim ): array {
		$e     = F3Base_Options::ler( 'f3base_acessos_estado' );
		$r     = array();
		$regra = F3Base_Modulo_Acessos_Servidor::config_hash();
		$hoje  = wp_date( 'Y-m-d' );
		for ( $d = new DateTimeImmutable( $inicio, wp_timezone() ); $d->format( 'Y-m-d' ) <= $fim && count( $r ) < 180; $d = $d->modify( '+1 day' ) ) { // phpcs:ignore Generic.CodeAnalysis.ForLoopWithTestFunctionCall.NotAllowed,Squiz.PHP.DisallowSizeFunctionsInLoops.Found -- Iteração de calendário/ascendentes limitada por janela ou profundidade explícita. Convergência/teto depende do tamanho atualizado nesta iteração; coleção limitada pelo orçamento.
			$dia    = $d->format( 'Y-m-d' );
			$s      = $e['dias'][ $dia ] ?? array();
			$estado = 'desconhecido';
			$motivo = 'Sem inspeção de fonte para esta data.';
			if ( $dia === $hoje ) {
				$estado = 'parcial';
				$motivo = 'Dia aberto; fotografia temporária do arquivo ativo.'; } elseif ( $s && ( $s['regra'] ?? '' ) !== $regra ) {
				$estado = 'legado';
				$motivo = 'Calendário ou classificação anterior; reconstrução completa não confirmada.'; } elseif ( $s ) {
					$completo = self::fontes_do_dia_completas( $dia, $e, $regra );
					$estado   = $completo ? 'completo' : 'parcial';
					$motivo   = $completo ? 'Fontes datadas necessárias ao calendário observado processadas; tráfego fora dos logs não é medido.' : 'Contribuições disponíveis processadas; falta fonte adjacente ou evidência do calendário de rotação.'; } elseif ( ! empty( $e['inspecionado_em'] ) ) {
					$estado = in_array( $dia, $e['rotacoes_observadas'] ?? array(), true ) ? 'pendente' : 'sem_fonte_observada';
					$motivo = 'pendente' === $estado ? 'Fonte observada ainda não publicada.' : 'Inspeção não encontrou log datado elegível com esta data de rotação; não comprova ausência de acessos.'; }
					foreach ( $e['fontes'] ?? array() as $f ) {
						if ( $f['rotacao'] !== $dia && ! in_array( $dia, $f['dias'] ?? array(), true ) && ! in_array( $dia, $f['adiados'] ?? array(), true ) ) {
							continue; }
						if ( ! empty( $f['erro'] ) || ( empty( $f['disponivel'] ) && in_array( $dia, $f['adiados'] ?? array(), true ) ) ) {
							$estado = 'falha';
							$motivo = $f['erro'] ?? 'Fonte perdida antes da revisita.';
							break; }
						if ( in_array( $dia, $f['adiados'] ?? array(), true ) && $dia !== $hoje ) {
							$estado = 'pendente';
							$motivo = 'Contribuição adiada aguarda revisita.'; }
					}
					$r[] = array(
						'dia'             => $dia,
						'estado'          => $estado,
						'motivo'          => $motivo,
						'origem'          => $dia === $hoje ? 'arquivo_ativo' : 'logs_datados',
						'regra'           => (string) ( $s['regra'] ?? 'legado' ),
						'fuso'            => (string) ( $s['fuso'] ?? '' ),
						'inspecionado_em' => (int) ( $e['inspecionado_em'] ?? 0 ),
					);
		}
		return $r;
	}
}
