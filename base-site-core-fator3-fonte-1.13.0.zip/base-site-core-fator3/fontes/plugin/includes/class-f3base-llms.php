<?php
/**
 * Regra COMPARTILHADA do arquivo llms.txt: seleção, ordem, descrição e emissor.
 *
 * POR QUE ESTA CLASSE EXISTE. Dois módulos servem o mesmo conjunto de itens —
 * `llms-txt-reserva`, no índice curto, e `llms-full-txt`, no texto integral. A
 * seleção, as exclusões, a ordem, a origem de cada descrição e a precedência de
 * emissor são a MESMA pergunta nos dois, e duas cópias divergiriam na primeira
 * condição acrescentada: um arquivo passaria a listar o que o outro exclui, e
 * nada acusaria.
 *
 * A classe não estende `F3Base_Modulo` de propósito, pelo mesmo motivo de
 * `F3Base_Emissores`: ela é regra, não superfície. As funções que DECIDEM são
 * puras e recebem fatos já medidos; as que MEDEM estão separadas e nomeadas
 * como tal. É essa separação que dá teto e piso a cada uma sem precisar de um
 * WordPress para exercitá-la.
 *
 * O QUE ELA NÃO FAZ, e é decisão: ela não lê meta de noindex. Quem produz esse
 * fato é `F3Base_Modulo_Noindex_Honrado::post_e_noindex()`, e esta classe
 * PERGUNTA a ele. Dois leitores da mesma chave é como uma exclusão passa a
 * nunca disparar sem que nada acuse.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Seleção, ordem e apresentação do llms.txt.
 */
final class F3Base_Llms {

	/**
	 * Vocabulário FECHADO do modo de seleção.
	 */
	public const MODO_CURADA     = 'curada';
	public const MODO_AUTOMATICA = 'automatica';
	public const MODO_MISTO      = F3Base_Vocabulario::LLMS_MISTO;

	/**
	 * Vocabulário FECHADO da origem de cada item, que decide a ordem.
	 */
	public const ORIGEM_HOME       = 'home';
	public const ORIGEM_CURADO     = 'curado';
	public const ORIGEM_AUTOMATICO = 'automatico';

	/**
	 * Vocabulário FECHADO da fonte de uma descrição.
	 */
	public const FONTE_META     = 'meta-do-plugin-de-seo';
	public const FONTE_RESUMO   = 'resumo-declarado-no-conteudo';
	public const FONTE_CONTEUDO = 'resumo-do-conteudo-limpo';
	public const FONTE_NENHUMA  = 'nenhuma';

	/**
	 * Vocabulário FECHADO de quem responde pelo endereço público.
	 */
	public const QUEM_ARQUIVO     = 'arquivo-fisico';
	public const QUEM_CONCORRENTE = 'emissor-concorrente';
	public const QUEM_NOSSA_ROTA  = 'rota-reserva';

	/**
	 * Elementos que são INTERFACE e não texto, removidos COM o conteúdo.
	 *
	 * Removê-los é diferente de tirar as tags: `wp_strip_all_tags()` apaga a tag
	 * e PRESERVA o texto de dentro, e o texto de dentro de um formulário é o
	 * rótulo do botão. Um resumo que termina no rótulo do botão de busca
	 * descreve a interface do site, não o assunto da página.
	 *
	 * @return string[]
	 */
	public static function elementos_de_interface(): array {
		return array( 'form', 'script', 'style', 'nav', 'aside', 'button', 'svg' );
	}

	/**
	 * O modo declarado usa a CURADORIA?
	 *
	 * @param string $modo Modo declarado.
	 * @return bool
	 */
	public static function modo_cura( string $modo ): bool {
		return in_array( $modo, array( self::MODO_CURADA, self::MODO_MISTO ), true );
	}

	/**
	 * O modo declarado ENUMERA o conteúdo publicado?
	 *
	 * @param string $modo Modo declarado.
	 * @return bool
	 */
	public static function modo_enumera( string $modo ): bool {
		return in_array( $modo, array( self::MODO_AUTOMATICA, self::MODO_MISTO ), true );
	}

	/**
	 * Modos fechados, para o sanitizador e para a tela.
	 *
	 * @return string[]
	 */
	public static function modos(): array {
		return array( self::MODO_CURADA, self::MODO_AUTOMATICA, self::MODO_MISTO );
	}

	/**
	 * TIPOS válidos: os declarados que EXISTEM entre os públicos desta instalação.
	 *
	 * O conjunto válido é medido, nunca literal: tipo declarado que este site não
	 * tem é descartado COM O NOME, e tipo que o agente criar depois passa a poder
	 * ser declarado sem release nova.
	 *
	 * @param array<int,string> $declarados Tipos declarados na configuração.
	 * @param array<int,string> $publicos   Tipos públicos medidos na instalação.
	 * @return array{tipos:array<int,string>,descartados:array<int,string>}
	 */
	public static function tipos_validos( array $declarados, array $publicos ): array {
		$tipos       = array();
		$descartados = array();

		foreach ( $declarados as $tipo ) {
			$tipo = trim( (string) $tipo );

			if ( '' === $tipo ) {
				continue;
			}

			if ( ! in_array( $tipo, $publicos, true ) ) {
				$descartados[] = $tipo;
				continue;
			}

			if ( ! in_array( $tipo, $tipos, true ) ) {
				$tipos[] = $tipo;
			}
		}

		return array(
			'tipos'       => $tipos,
			'descartados' => $descartados,
		);
	}

	/**
	 * PRECEDÊNCIA de quem responde pelo endereço público. Regra pura.
	 *
	 * Três respostas possíveis, nesta ordem, e a ordem é a regra:
	 *
	 * 1. **Arquivo físico na raiz** — a mesma física do robots.txt: arquivo
	 *    existente vence, e a rota fica de reserva.
	 * 2. **Emissor concorrente medido** — outro plugin com a função ligada
	 *    serviria a MESMA URL. Nosso módulo sai de cena e o motivo NOMEIA quem
	 *    ficou, que é a mesma regra de `tracking.emissor_unico`: dois emissores
	 *    para o mesmo endereço é o defeito, e quem cala é quem chegou depois.
	 * 3. **Nossa rota** — não há arquivo e não há concorrente.
	 *
	 * @param bool   $arquivo_fisico   Existe arquivo físico na raiz.
	 * @param string $caminho_fisico   Caminho do arquivo, para a mensagem.
	 * @param bool   $concorrente      Outro emissor está ligado para esta URL.
	 * @param string $nome_concorrente Nome do outro emissor, para a mensagem.
	 * @return array{serve:bool,quem:string,motivo:string}
	 */
	public static function veredito_do_emissor( bool $arquivo_fisico, string $caminho_fisico, bool $concorrente, string $nome_concorrente ): array {
		if ( $arquivo_fisico ) {
			return array(
				'serve'  => false,
				'quem'   => self::QUEM_ARQUIVO,
				'motivo' => sprintf(
					/* translators: %s: caminho do arquivo físico. */
					__( 'arquivo físico presente em %s: é ele quem responde, e a rota fica em espera — que é o desenho.', 'f3base' ),
					'' !== $caminho_fisico ? $caminho_fisico : __( 'raiz do site', 'f3base' )
				),
			);
		}

		if ( $concorrente ) {
			return array(
				'serve'  => false,
				'quem'   => self::QUEM_CONCORRENTE,
				'motivo' => sprintf(
					/* translators: %s: nome do emissor concorrente medido. */
					__( 'EMISSOR CONCORRENTE MEDIDO: %s está com a publicação deste arquivo ligada e responderia pela MESMA URL. Este módulo sai de cena e não serve — duas respostas para um endereço é o defeito, e quem cala é quem chegou depois. Desligue lá para que a rota daqui volte a responder, ou deixe como está e o arquivo continua existindo, servido pelo outro.', 'f3base' ),
					'' !== $nome_concorrente ? $nome_concorrente : __( 'outro plugin instalado', 'f3base' )
				),
			);
		}

		return array(
			'serve'  => true,
			'quem'   => self::QUEM_NOSSA_ROTA,
			'motivo' => __( 'Sem arquivo físico ou concorrente com configuração reconhecida; a rota Core está elegível. Confirme a entrega pela inspeção HTTP.', 'f3base' ),
		);
	}

	/**
	 * RESUMO LIMPO do conteúdo, sem a interface junto. Regra pura.
	 *
	 * É `limpar()` seguida do CORTE EM PALAVRAS, e as duas estão separadas por
	 * um defeito medido: `/llms-full.txt` pedia o texto inteiro passando
	 * `PHP_INT_MAX` como teto, `wp_trim_words()` repassava `$palavras + 1` a
	 * `preg_split()`, e `PHP_INT_MAX + 1` é float — `TypeError` fatal no PHP
	 * 8.1+, com a rota pública respondendo 500 assim que a chave era ligada.
	 * Quem não corta agora chama `limpar()`, que não tem corte a fazer.
	 *
	 * @param string $conteudo Conteúdo bruto.
	 * @param int    $palavras Teto de palavras.
	 * @return string
	 */
	public static function resumo_limpo( string $conteudo, int $palavras ): string {
		$texto = self::limpar( $conteudo );

		if ( '' === $texto ) {
			return '';
		}

		return trim( wp_trim_words( $texto, max( 1, $palavras ), '…' ) );
	}

	/**
	 * O TEXTO LIMPO da interface, SEM corte. Regra pura.
	 *
	 * A ordem das quatro etapas é a regra, e cada uma existe por um defeito
	 * concreto que a anterior não resolve:
	 *
	 * 1. `strip_shortcodes()` — shortcode não renderizado vira texto literal no
	 *    resumo, com colchetes e atributos.
	 * 2. **Elementos de interface removidos COM o conteúdo.** Tirar só as tags
	 *    preserva o texto de dentro, e o texto de dentro de um formulário de
	 *    busca é o rótulo do botão: o resumo terminaria descrevendo a interface.
	 * 3. **Quebra de linha antes de tirar as tags.** Sem ela, o título de um
	 *    bloco e o parágrafo seguinte colam numa frase só, sem pontuação.
	 * 4. Só então tirar as tags — e o corte, quem o quer, o pede a
	 *    `resumo_limpo()`.
	 *
	 * @param string $conteudo Conteúdo bruto.
	 * @return string
	 */
	public static function limpar( string $conteudo ): string {
		if ( '' === trim( $conteudo ) ) {
			return '';
		}

		$texto = strip_shortcodes( $conteudo );

		foreach ( self::elementos_de_interface() as $elemento ) {
			$texto = (string) preg_replace(
				'#<' . $elemento . '\b[^>]*>.*?</' . $elemento . '\s*>#is',
				' ',
				$texto
			);

			/* Elemento sem par de fechamento não pode sobreviver por acidente de markup. */
			$texto = (string) preg_replace( '#<' . $elemento . '\b[^>]*/?>#i', ' ', $texto );
		}

		$texto = (string) preg_replace( '#<(?:/?)(?:p|div|section|article|header|footer|li|ul|ol|h[1-6]|br|tr|td|th|table|figure|figcaption|blockquote)\b[^>]*>#i', "\n", $texto );

		$texto = wp_strip_all_tags( $texto );
		$texto = (string) preg_replace( '/[ \t]+/', ' ', $texto );
		$texto = (string) preg_replace( '/\s*\n\s*/', "\n", $texto );
		$texto = trim( $texto );

		if ( '' === $texto ) {
			return '';
		}

		/*
		 * A QUEBRA VIRA PONTUAÇÃO antes do corte: "Título Corpo" numa frase só é
		 * o que sai quando as linhas são simplesmente concatenadas.
		 */
		$texto = (string) preg_replace( '/\n+/', '. ', $texto );
		$texto = (string) preg_replace( '/\.\s*\.\s*/', '. ', $texto );

		return trim( $texto );
	}

	/**
	 * DESCRIÇÃO de um item e a FONTE que respondeu. Regra pura.
	 *
	 * A cadeia é declarada e tem ordem: a descrição escrita no plugin de SEO
	 * vence, porque é o texto que alguém escreveu PARA ser o resumo; depois o
	 * resumo declarado no próprio conteúdo; e só então o corte do corpo, que é
	 * derivado e é o que erra.
	 *
	 * A função devolve o texto E a fonte porque sem a fonte não há como provar
	 * que a primeira foi preferida: um resumo bom, obtido do lugar errado,
	 * continua sendo o instrumento medindo outra coisa.
	 *
	 * @param string $meta_seo Descrição gravada no plugin de SEO.
	 * @param string $resumo   Resumo declarado no conteúdo.
	 * @param string $conteudo Conteúdo bruto, para o corte de última instância.
	 * @param int    $palavras Teto de palavras do corte.
	 * @return array{texto:string,fonte:string}
	 */
	public static function descricao_do_item( string $meta_seo, string $resumo, string $conteudo, int $palavras ): array {
		$meta_seo = trim( $meta_seo );

		if ( '' !== $meta_seo ) {
			return array(
				'texto' => $meta_seo,
				'fonte' => self::FONTE_META,
			);
		}

		$resumo = trim( $resumo );

		if ( '' !== $resumo ) {
			return array(
				'texto' => $resumo,
				'fonte' => self::FONTE_RESUMO,
			);
		}

		$cortado = self::resumo_limpo( $conteudo, $palavras );

		if ( '' !== $cortado ) {
			return array(
				'texto' => $cortado,
				'fonte' => self::FONTE_CONTEUDO,
			);
		}

		return array(
			'texto' => '',
			'fonte' => self::FONTE_NENHUMA,
		);
	}

	/**
	 * ENDEREÇO DO SITEMAP, medido. Regra pura.
	 *
	 * Quem serve sitemap neste site é uma pergunta com resposta, e ela tem três
	 * saídas. Sitemap do plugin de SEO ligado responde em `sitemap_index.xml`, e
	 * nesse caso o núcleo DESATIVA o endereço dele; sem o plugin, o do núcleo
	 * responde em `wp-sitemap.xml` quando estiver habilitado; e quando nenhum
	 * dos dois serve, a seção inteira é OMITIDA. Imprimir um endereço fixo é
	 * afirmar mais do que se mediu — e o endereço fixo errado é justamente o que
	 * o núcleo desliga quando o plugin assume.
	 *
	 * @param bool   $sitemap_do_seo   O plugin de SEO serve sitemap.
	 * @param bool   $sitemap_do_nucleo O núcleo serve sitemap.
	 * @param string $home             Endereço base do site, com ou sem barra final: a normalização é feita aqui.
	 * @return array{url:string,fonte:string}
	 */
	public static function endereco_do_sitemap( bool $sitemap_do_seo, bool $sitemap_do_nucleo, string $home ): array {
		/*
		 * A BARRA FINAL É GARANTIDA AQUI, e não no chamador. Função pura que
		 * confia no formato do argumento é defeito esperando o segundo
		 * chamador: com o home sem barra, a concatenação produz
		 * "https://exemplo.com.brsitemap_index.xml" — endereço que nada serve,
		 * impresso como se fosse medido.
		 */
		$base = '' === $home ? '/' : trailingslashit( $home );

		if ( $sitemap_do_seo ) {
			return array(
				'url'   => $base . 'sitemap_index.xml',
				'fonte' => 'plugin-de-seo',
			);
		}

		if ( $sitemap_do_nucleo ) {
			return array(
				'url'   => $base . 'wp-sitemap.xml',
				'fonte' => 'nucleo',
			);
		}

		return array(
			'url'   => '',
			'fonte' => 'nenhum',
		);
	}

	/**
	 * SELEÇÃO: junta curados e enumerados, aplica as exclusões, dedupe por ID.
	 *
	 * As três exclusões, e nenhuma delas é escrita duas vezes no pacote:
	 *
	 * - **noindex** — o fato vem de `F3Base_Modulo_Noindex_Honrado`, e chega
	 *   aqui já medido, no campo `noindex` de cada candidato.
	 * - **já curado** — dedupe por **ID**, nunca por URL: URL muda quando o slug
	 *   muda, e o mesmo conteúdo sairia duas vezes no arquivo.
	 * - **excluídos declarados** — a política de privacidade quando a
	 *   configuração manda não incluí-la. A regra é a mesma de sempre, aplicada
	 *   por ID, e não uma segunda cópia dela.
	 *
	 * @param array<int,array<string,mixed>> $curados     Itens da curadoria, na ordem declarada.
	 * @param array<int,array<string,mixed>> $enumerados  Candidatos enumerados.
	 * @param array<int,int>                 $excluir_ids IDs excluídos por declaração.
	 * @return array{itens:array<int,array<string,mixed>>,excluidos:array<string,array<int,int>>}
	 */
	public static function selecionar( array $curados, array $enumerados, array $excluir_ids ): array {
		$excluir        = array_map( 'intval', array_values( $excluir_ids ) );
		$vistos         = array();
		$itens          = array();
		$por_noindex    = array();
		$por_dedupe     = array();
		$por_declaracao = array();

		foreach ( array_merge( $curados, $enumerados ) as $item ) {
			$id = (int) ( $item['id'] ?? 0 );

			if ( in_array( $id, $excluir, true ) && $id > 0 ) {
				$por_declaracao[] = $id;
				continue;
			}

			if ( ! empty( $item['noindex'] ) ) {
				$por_noindex[] = $id;
				continue;
			}

			if ( $id > 0 && in_array( $id, $vistos, true ) ) {
				$por_dedupe[] = $id;
				continue;
			}

			if ( $id > 0 ) {
				$vistos[] = $id;
			}

			$itens[] = $item;
		}

		return array(
			'itens'     => $itens,
			'excluidos' => array(
				'noindex'   => $por_noindex,
				'duplicado' => $por_dedupe,
				'declarado' => $por_declaracao,
			),
		);
	}

	/**
	 * ORDEM do arquivo. Regra pura, e ela não é a ordem de leitura do banco.
	 *
	 * A página inicial primeiro, porque é ela que define o site; depois os itens
	 * curados NA ORDEM DECLARADA, porque a ordem é a curadoria; e só então o
	 * enumerado, páginas antes de posts e por data decrescente dentro de cada
	 * um. Ordenar tudo por data joga a página inicial para o rodapé, depois de
	 * qualquer artigo publicado — e o que define o site não pode sair por
	 * último.
	 *
	 * @param array<int,array<string,mixed>> $itens Itens já selecionados.
	 * @return array<int,array<string,mixed>>
	 */
	public static function ordenar( array $itens ): array {
		$peso_da_origem = array(
			self::ORIGEM_HOME       => 0,
			self::ORIGEM_CURADO     => 1,
			self::ORIGEM_AUTOMATICO => 2,
		);

		$indexados = array();

		foreach ( array_values( $itens ) as $posicao => $item ) {
			$indexados[] = array(
				'posicao' => $posicao,
				'item'    => $item,
			);
		}

		usort(
			$indexados,
			static function ( array $a, array $b ) use ( $peso_da_origem ): int {
				$origem_a = (string) ( $a['item']['origem'] ?? self::ORIGEM_AUTOMATICO );
				$origem_b = (string) ( $b['item']['origem'] ?? self::ORIGEM_AUTOMATICO );

				$pa = $peso_da_origem[ $origem_a ] ?? 2;
				$pb = $peso_da_origem[ $origem_b ] ?? 2;

				if ( $pa !== $pb ) {
					return $pa <=> $pb;
				}

				if ( self::ORIGEM_AUTOMATICO === $origem_a ) {
					$tipo_a = (string) ( $a['item']['tipo'] ?? '' );
					$tipo_b = (string) ( $b['item']['tipo'] ?? '' );

					$pagina_a = 'page' === $tipo_a ? 0 : 1;
					$pagina_b = 'page' === $tipo_b ? 0 : 1;

					if ( $pagina_a !== $pagina_b ) {
						return $pagina_a <=> $pagina_b;
					}

					$data_a = (string) ( $a['item']['data'] ?? '' );
					$data_b = (string) ( $b['item']['data'] ?? '' );

					if ( $data_a !== $data_b ) {
						return strcmp( $data_b, $data_a );
					}
				}

				/* Empate conserva a ordem de entrada: é ela que carrega a curadoria. */
				return $a['posicao'] <=> $b['posicao'];
			}
		);

		$saida = array();

		foreach ( $indexados as $linha ) {
			$saida[] = $linha['item'];
		}

		return $saida;
	}

	/**
	 * A LINHA de um item no índice curto.
	 *
	 * @param array<string,mixed> $item Item selecionado.
	 * @return string
	 */
	public static function linha_de_item( array $item ): string {
		$url = self::url_markdown( (string) ( $item['markdown_url'] ?? $item['url'] ?? '' ) );

		if ( '' === $url ) {
			return '';
		}

		$titulo = self::texto_markdown( (string) ( $item['titulo'] ?? '' ) );
		$titulo = '' !== $titulo ? $titulo : self::texto_markdown( $url );

		$linha = '- [' . $titulo . '](' . $url . ')';

		$descricao = self::texto_markdown( (string) ( $item['descricao'] ?? '' ) );

		return '' !== $descricao ? $linha . ': ' . $descricao : $linha;
	}

	/** Texto editorial ocupa uma linha; metacaracteres não criam links ou seções. */
	public static function texto_markdown( string $texto ): string {
		$texto = html_entity_decode( wp_strip_all_tags( $texto ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$texto = trim( (string) preg_replace( '/[\s\x00-\x1f\x7f]+/u', ' ', $texto ) );
		return strtr(
			$texto,
			array(
				'\\' => '\\\\',
				'['  => '\\[',
				']'  => '\\]',
				'*'  => '\\*',
				'_'  => '\\_',
				'`'  => '\\`',
				'<'  => '&lt;',
				'>'  => '&gt;',
				'#'  => '\\#',
			)
		);
	}

	/** Destino absoluto HTTP(S), sem credenciais, controles ou delimitadores Markdown. */
	public static function url_markdown( string $url ): string {
		$url = trim( $url );
		$p   = wp_parse_url( $url );
		if ( ! is_array( $p ) || empty( $p['host'] ) || ! in_array( strtolower( $p['scheme'] ?? '' ), array( 'http', 'https' ), true ) || isset( $p['user'] ) || isset( $p['pass'] ) || preg_match( '/[\x00-\x20\x7f]/', $url ) ) {
			return ''; }
		return strtr(
			$url,
			array(
				'('  => '%28',
				')'  => '%29',
				'<'  => '%3C',
				'>'  => '%3E',
				'"'  => '%22',
				'\\' => '%5C',
			)
		);
	}

	/** Raiz pública pode ser diferente de ABSPATH quando o núcleo fica em subpasta. */
	public static function arquivo_publico( string $nome ): string {
		if ( '' === $nome || preg_match( '~(?:^|[/\\\\])\.\.(?:[/\\\\]|$)|[\x00-\x1f]~', $nome ) ) {
			return ''; }
		if ( ! function_exists( 'get_home_path' ) && is_file( ABSPATH . 'wp-admin/includes/file.php' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php'; }
		$raiz    = function_exists( 'get_home_path' ) ? get_home_path() : ABSPATH;
		$caminho = trailingslashit( $raiz ) . $nome;
		return is_file( $caminho ) ? $caminho : '';
	}

	public static function site_publico(): bool {
		return '0' !== (string) get_option( 'blog_public', '1' ); }

	/** Markdown do corpo editorial armazenado, sem executar shortcodes, blocos ou requisições. */
	public static function markdown( string $conteudo, string $base, int $nivel_minimo = 2 ): string {
		$r = F3Base_Llms_Conversor::converter( $conteudo, $base, $nivel_minimo );
		if ( ! $r['completo'] ) {
			throw new RuntimeException( 'Conversão editorial incompleta: ' . implode( ', ', $r['erros'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped -- Diagnóstico interno; cada transporte aplica a codificação adequada ao texto.
		}
		return $r['texto'];
	}
	public static function html_markdown( string $conteudo, string $base, int $nivel_minimo = 2 ): string {
		if ( ! class_exists( 'DOMDocument' ) ) {
			return self::texto_markdown( self::limpar( $conteudo ) ); }
		$anterior = libxml_use_internal_errors( true );
		try {
			$doc = new DOMDocument( '1.0', 'UTF-8' );
			$doc->loadHTML( '<?xml encoding="UTF-8"><html><body>' . strip_shortcodes( $conteudo ) . '</body></html>', LIBXML_NONET );
			$body = $doc->getElementsByTagName( 'body' )->item( 0 );
			return $body ? trim( self::no_markdown( $body, $base, max( 2, min( 6, $nivel_minimo ) ) ) ) : '';
		} finally {
			libxml_clear_errors();
			libxml_use_internal_errors( $anterior ); }
	}

	/** Conversão conservadora: usa somente texto e links já presentes no conteúdo. */
	private static function no_markdown( DOMNode $no, string $base, int $nivel_minimo ): string {
		if ( XML_TEXT_NODE === $no->nodeType ) {
			$raw = (string) preg_replace( '/\s+/u', ' ', $no->nodeValue ?? '' );
			if ( '' === trim( $raw ) ) {
				return '' === $raw ? '' : ' '; }
			return ( str_starts_with( $raw, ' ' ) ? ' ' : '' ) . self::texto_markdown( $raw ) . ( str_ends_with( $raw, ' ' ) ? ' ' : '' );
		}
		if ( XML_ELEMENT_NODE !== $no->nodeType ) {
			return ''; }
		$tag = strtolower( $no->nodeName ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
		if ( in_array( $tag, array_merge( self::elementos_de_interface(), array( 'iframe', 'object', 'embed', 'input', 'textarea', 'select' ) ), true ) ) {
			return ''; }
		if ( $no instanceof DOMElement && ( $no->hasAttribute( 'hidden' ) || 'true' === $no->getAttribute( 'aria-hidden' ) ) ) {
			return ''; }
		if ( 'pre' === $tag || 'code' === $tag ) {
			$raw = $no->textContent;
			preg_match_all( '/`+/', $raw, $runs );
			$max = 0;
			foreach ( $runs[0] as $run ) {
				$max = max( $max, strlen( $run ) ); }
			$fence = str_repeat( '`', max( 'pre' === $tag ? 3 : 1, $max + 1 ) );
			return 'pre' === $tag ? "\n\n" . $fence . "\n" . trim( $raw, "\r\n" ) . "\n" . $fence . "\n\n" : $fence . ' ' . str_replace( array( "\r", "\n" ), ' ', $raw ) . ' ' . $fence;
		}
		if ( 'table' === $tag ) {
			return self::tabela_markdown( $no, $base, $nivel_minimo ); }
		if ( in_array( $tag, array( 'ul', 'ol' ), true ) ) {
			$linhas = array();
			$numero = $no instanceof DOMElement && $no->hasAttribute( 'start' ) ? max( 1, (int) $no->getAttribute( 'start' ) ) : 1;
			foreach ( $no->childNodes as $li ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
				if ( 'li' !== strtolower( $li->nodeName ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
					continue; }
				$texto_item = '';
				foreach ( $li->childNodes as $f ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
					$texto_item .= self::no_markdown( $f, $base, $nivel_minimo ); }
				$marcador = 'ol' === $tag ? (string) ( $numero++ ) . '. ' : '- ';
				$linhas[] = $marcador . str_replace( "\n", "\n" . str_repeat( ' ', strlen( $marcador ) ), trim( $texto_item ) );
			}
			return "\n\n" . implode( "\n", $linhas ) . "\n\n";
		}
		$texto = '';
		foreach ( $no->childNodes as $filho ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
			$parte  = self::no_markdown( $filho, $base, $nivel_minimo );
			$texto .= str_ends_with( $texto, "\n\n" ) && str_starts_with( $parte, "\n\n" ) ? ltrim( $parte, "\n" ) : $parte;
		}
		if ( $no instanceof DOMElement && in_array( $tag, array( 'a', 'img' ), true ) ) {
			$href = $no->getAttribute( 'a' === $tag ? 'href' : 'src' );
			$url  = '' !== $href ? self::url_markdown( WP_Http::make_absolute_url( $href, $base ) ) : '';
			if ( 'img' === $tag ) {
				$texto = self::texto_markdown( $no->getAttribute( 'alt' ) ); }
			return '' !== $url && '' !== trim( $texto ) ? ( 'img' === $tag ? '!' : '' ) . '[' . trim( $texto ) . '](' . $url . ')' : $texto;
		}
		if ( preg_match( '/^h([1-6])$/', $tag, $h ) ) {
			return "\n\n" . str_repeat( '#', min( 6, max( $nivel_minimo, (int) $h[1] + $nivel_minimo - 2 ) ) ) . ' ' . trim( $texto ) . "\n\n"; }
		if ( in_array( $tag, array( 'strong', 'b', 'em', 'i' ), true ) ) {
			$m = in_array( $tag, array( 'strong', 'b' ), true ) ? '**' : '*';
			return $m . trim( $texto ) . $m; }
		if ( 'li' === $tag ) {
			return "\n" . ( 'ol' === $no->parentNode->nodeName ? '1. ' : '- ' ) . str_replace( "\n", "\n  ", trim( $texto ) ); } // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
		if ( 'blockquote' === $tag ) {
			return "\n\n> " . str_replace( "\n", "\n> ", trim( $texto ) ) . "\n\n"; }
		if ( 'br' === $tag ) {
			return "  \n"; }
		if ( 'hr' === $tag ) {
			return "\n\n---\n\n"; }
		if ( in_array( $tag, array( 'p', 'div', 'section', 'article', 'header', 'footer', 'ul', 'ol', 'table', 'tr', 'figure', 'figcaption' ), true ) ) {
			return "\n\n" . trim( $texto ) . "\n\n"; }
		if ( in_array( $tag, array( 'td', 'th' ), true ) ) {
			return trim( $texto ) . ' | '; }
		return $texto;
	}

	private static function tabela_markdown( DOMElement $tabela, string $base, int $nivel ): string {
		$linhas    = array();
		$largura   = 0;
		$pendentes = array();
		$cabecalho = false;
		$legenda   = '';
		foreach ( $tabela->childNodes as $filho ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
			if ( 'caption' === strtolower( $filho->nodeName ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
				foreach ( $filho->childNodes as $f ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
					$legenda .= self::no_markdown( $f, $base, $nivel ); }
			}
		}
		foreach ( $tabela->getElementsByTagName( 'tr' ) as $tr ) {
			$p = $tr->parentNode; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
			while ( $p && 'table' !== strtolower( $p->nodeName ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
				$p = $p->parentNode; } // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
			if ( $p !== $tabela ) {
				continue; }
			$celulas = array();
			$coluna  = 0;
			foreach ( $pendentes as $col => $span ) {
				$celulas[ $col ] = $span['texto'];
				if ( --$pendentes[ $col ]['linhas'] < 1 ) {
					unset( $pendentes[ $col ] ); }
			}
			foreach ( $tr->childNodes as $celula ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
				if ( ! $celula instanceof DOMElement || ! in_array( strtolower( $celula->nodeName ), array( 'td', 'th' ), true ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
					continue; }
				if ( ! $linhas && 'th' === strtolower( $celula->nodeName ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
					$cabecalho = true; }
				$texto = '';
				foreach ( $celula->childNodes as $f ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Propriedades nativas da extensão DOM.
					$texto .= self::no_markdown( $f, $base, $nivel ); }
				$texto   = str_replace( array( '|', "\r", "\n" ), array( '\|', '', ' ' ), trim( $texto ) );
				$colspan = max( 1, (int) $celula->getAttribute( 'colspan' ) );
				$rowspan = max( 1, (int) $celula->getAttribute( 'rowspan' ) );
				if ( $colspan > 50 || $rowspan > 1000 || count( $linhas ) > 5000 ) {
					throw new RuntimeException( 'Tabela excede os limites da conversão integral.' ); }
				for ( $i = 0; $i < $colspan; ++$i ) {
					while ( array_key_exists( $coluna, $celulas ) ) {
						++$coluna; }
					if ( $coluna >= 50 ) {
						throw new RuntimeException( 'Tabela excede 50 colunas.' ); }
					$celulas[ $coluna ] = $texto;
					if ( $rowspan > 1 ) {
						$pendentes[ $coluna ] = array(
							'texto'  => $texto,
							'linhas' => $rowspan - 1,
						); }
					++$coluna;
				}
			}
			if ( $celulas ) {
				ksort( $celulas );
				$largura  = max( $largura, max( array_keys( $celulas ) ) + 1 );
				$linhas[] = $celulas; }
		}
		if ( ! $linhas ) {
			return ''; }
		$saida = array();
		if ( ! $cabecalho ) {
			$saida[] = '| ' . implode( ' | ', array_fill( 0, $largura, '' ) ) . ' |';
			$saida[] = '| ' . implode( ' | ', array_fill( 0, $largura, '---' ) ) . ' |'; }
		foreach ( $linhas as $i => $linha ) {
			$linha = array_replace( array_fill( 0, $largura, '' ), $linha );
			ksort( $linha );
			$saida[] = '| ' . implode( ' | ', $linha ) . ' |';
			if ( $cabecalho && 0 === $i ) {
				$saida[] = '| ' . implode( ' | ', array_fill( 0, $largura, '---' ) ) . ' |'; }
		}
		return "\n\n" . ( '' !== trim( $legenda ) ? trim( $legenda ) . "\n\n" : '' ) . implode( "\n", $saida ) . "\n\n";
	}

	/** Também a curadoria precisa respeitar publicação, senha, noindex e URL atual. */
	public static function validar_curados( array $itens ): array {
		$saida = array();
		foreach ( $itens as $item ) {
			$url = (string) ( $item['url'] ?? '' );
			if ( '' === self::url_markdown( $url ) ) {
				continue; }
			$host       = static fn( string $u ): string => (string) preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) ) );
			$mesmo_host = $host( $url ) === $host( home_url() );
			$id         = (int) ( $item['id'] ?? 0 );
			if ( $id < 1 && $mesmo_host ) {
				$id = self::id_local( $url ); }
			if ( $id > 0 ) {
				$post = get_post( $id );
				if ( ! $post instanceof WP_Post || ! is_post_publicly_viewable( $post ) || '' !== (string) $post->post_password || F3Base_Modulo_Noindex_Honrado::post_e_noindex( $id ) ) {
					continue; }
				$item['id']  = $id;
				$item['url'] = self::canonical_do_post( $post );
				if ( '' === $item['url'] ) {
					continue; }
				$item['conteudo'] = (string) $post->post_content;
				$item['data']     = (string) $post->post_date_gmt;
				$item['tipo']     = (string) $post->post_type;
				if ( empty( $item['titulo'] ) ) {
					$item['titulo'] = get_the_title( $post ); }
				if ( empty( $item['descricao'] ) ) {
					$item['descricao'] = self::resumo_limpo( $post->post_content, F3Base_Modulo_Llms_Txt_Reserva::PALAVRAS_DO_RESUMO ); }
			}
			$saida[] = $item;
		}
		return $saida;
	}

	/** Identificar um privado permite excluí-lo; a resolução não depende do visitante estar logado. */
	private static function id_local( string $url ): int {
		$resolver = static function ( WP_Query $consulta ): void {
			$consulta->set( 'post_status', 'any' );
		};
		add_action( 'pre_get_posts', $resolver, PHP_INT_MAX );
		try {
			return (int) url_to_postid( $url ); } finally {
			remove_action( 'pre_get_posts', $resolver, PHP_INT_MAX ); }
	}

	/* ------------------------------------------------------------------ *
	 * A partir daqui: o que MEDE. Separado do que decide, e nomeado.
	 * ------------------------------------------------------------------ */

	/**
	 * O PLUGIN DE SEO ESTÁ ATIVO nesta instalação? Um produtor só deste fato.
	 *
	 * O DEFEITO MEDIDO que esta função existe para fechar: `concorrente_de_llms()`
	 * e `sitemap_medido()` liam SÓ a option `wpseo`, e option sobrevive à
	 * desativação do plugin — desativar o Yoast num site que tinha
	 * `enable_llms_txt` ligada deixava a option no banco, este pacote continuava
	 * cedendo o endereço a um emissor que já não emite, e `/llms.txt` virava 404
	 * permanente com o módulo dizendo ATIVO. A chave declara a INTENÇÃO de quem
	 * configurou o plugin; quem responde por ele estar rodando é a lista de
	 * plugins ativos, e as duas perguntas precisam ser cruzadas.
	 *
	 * A leitura é direta do banco, sem `wp-admin/includes/plugin.php`, e o slug
	 * sai do vocabulário compartilhado — nunca de literal — porque quem escolhe
	 * o plugin do papel é `config/decisoes.tsv`, do outro lado.
	 *
	 * @return bool
	 */
	public static function plugin_de_seo_ativo(): bool {
		$pasta = F3Base_Vocabulario::slug_do_papel( F3Base_Vocabulario::PAPEL_SEO );

		if ( '' === $pasta ) {
			return false;
		}

		$ativos = get_option( 'active_plugins', array() );
		$ativos = is_array( $ativos ) ? $ativos : array();

		if ( function_exists( 'is_multisite' ) && is_multisite() ) {
			$rede = get_site_option( 'active_sitewide_plugins', array() );

			if ( is_array( $rede ) ) {
				$ativos = array_merge( $ativos, array_keys( $rede ) );
			}
		}

		foreach ( $ativos as $arquivo ) {
			if ( str_starts_with( (string) $arquivo, $pasta . '/' ) ) {
				return true;
			}
		}

		return false;
	}

	/** Consulta a apresentação efetiva do Yoast; a ausência da API mantém a reserva. */
	public static function seo_do_post( int $id ): array {
		if ( ! self::plugin_de_seo_ativo() || ! function_exists( 'YoastSEO' ) ) {
			return array(); }
		try {
			$meta = YoastSEO()->meta->for_post( $id );
			if ( ! $meta ) {
				return array(); }
			$robots = $meta->robots;
			return array(
				'canonical' => (string) $meta->canonical,
				'noindex'   => is_array( $robots ) ? in_array( 'noindex', $robots, true ) : str_contains( (string) $robots, 'noindex' ),
			);
		} catch ( Throwable $erro ) {
			return array(); }
	}
	/** Conteúdo com canonical apontando outro documento não é republicado no índice nem no full. */
	public static function canonical_do_post( WP_Post $post ): string {
		$url       = (string) get_permalink( $post );
		$seo       = self::seo_do_post( (int) $post->ID );
		$canonical = (string) ( $seo['canonical'] ?? '' );
		if ( '' === $canonical ) {
			return $url; }
		$identidade = static function ( string $u ): string {
			$p = wp_parse_url( $u );
			if ( ! is_array( $p ) || empty( $p['host'] ) ) {
				return ''; }
			return preg_replace( '/^www\./', '', strtolower( $p['host'] ) ) . ( isset( $p['port'] ) ? ':' . $p['port'] : '' ) . rtrim( $p['path'] ?? '/', '/' ) . ( ! empty( $p['query'] ) ? '?' . $p['query'] : '' );
		};
		return '' !== self::url_markdown( $canonical ) && $identidade( $url ) === $identidade( $canonical ) ? $canonical : '';
	}
	public static function responsaveis(): array {
		$seo        = self::plugin_de_seo_ativo();
		$llms       = F3Base_Modulo_Llms_Txt_Reserva::emissor();
		$c          = (array) F3Base_Options::ler( 'f3base_llms' );
		$publico    = self::site_publico();
		$serve      = ! empty( $c['ligado'] ) && $publico && ! empty( $llms['serve'] );
		$motivo     = empty( $c['ligado'] ) ? 'Publicação llms do Core desligada.' : ( ! $publico ? 'Site sem visibilidade pública; publicação do Core suspensa.' : (string) $llms['motivo'] );
		$candidatos = self::emissores_llms();
		$incerto    = (bool) array_filter( $candidatos, static fn( $e ) => ! empty( $e['ativo'] ) && empty( $e['configuracao_conhecida'] ) );
		return array(
			'seo'                => $seo ? 'Yoast' : 'Reservas do WordPress e Core',
			'schema'             => $seo ? 'Grafo do Yoast; extensões do Core' : 'Extensão do Core sem grafo do Yoast',
			'sitemap'            => self::sitemap_medido(),
			'llms'               => array(
				'core_serve'             => $serve,
				'core_elegivel'          => (bool) $llms['serve'],
				'configuracao_ligada'    => ! empty( $c['ligado'] ),
				'hook_registrado'        => self::hook_publicacao_registrado( 'F3Base_Modulo_Llms_Txt_Reserva' ),
				'site_publico'           => $publico,
				'motivo'                 => $motivo,
				'fisico'                 => '' !== self::arquivo_publico( 'llms.txt' ),
				'concorrentes'           => $candidatos,
				'responsavel_observado'  => 'nao_determinado',
				'concorrencia_potencial' => $incerto,
				'ressalva'               => 'core_serve descreve a configuração elegível. Uma consulta HTTP datada é necessária para confirmar a publicação.',
			),
			'full'               => array(
				'configuracao_ligada' => ! empty( $c['ligado'] ) && ! empty( $c['full'] ),
				'core_serve'          => $serve && ! empty( $c['full'] ) && F3Base_Modulo_Llms_Full_Txt::emissor()['serve'],
				'hook_registrado'     => self::hook_publicacao_registrado( 'F3Base_Modulo_Llms_Full_Txt' ),
				'fisico'              => '' !== self::arquivo_publico( 'llms-full.txt' ),
			),
			'markdown'           => array(
				'configuracao_ligada' => ! empty( $c['ligado'] ) && ! empty( $c['markdown'] ),
				'core_serve'          => $serve && ! empty( $c['markdown'] ),
				'hook_registrado'     => self::hook_publicacao_registrado( 'F3Base_Modulo_Llms_Markdown' ),
			),
			'perfil_recomendado' => 'Yoast para SEO e sitemap; Core para llms e full. Preserve o dono atual até migração explícita e backup de arquivo físico.',
		);
	}
	private static function hook_publicacao_registrado( string $classe ): bool {
		global $wp_filter;
		$hook = $wp_filter['template_redirect'] ?? null;
		if ( ! is_object( $hook ) || ! isset( $hook->callbacks ) ) {
			return false; }
		foreach ( $hook->callbacks as $prioridade ) {
			foreach ( $prioridade as $callback ) {
				$f = $callback['function'] ?? null;
				if ( is_array( $f ) && isset( $f[0], $f[1] ) && is_object( $f[0] ) && $f[0] instanceof $classe && 'talvez_servir' === $f[1] ) {
					return true; }
			}
		}
		return false;
	}

	/** Registro extensível: configuração reconhecida é diferente da mera ativação de um plugin. */
	public static function emissores_llms(): array {
		$wpseo = get_option( 'wpseo', array() );
		$itens = array(
			array(
				'id'                     => 'yoast',
				'nome'                   => 'Yoast SEO',
				'ativo'                  => self::plugin_de_seo_ativo(),
				'configuracao_conhecida' => true,
				'ligado'                 => ! empty( $wpseo['enable_llms_txt'] ),
				'base'                   => 'wpseo.enable_llms_txt + plugin ativo',
			),
		);
		foreach ( (array) get_option( 'active_plugins', array() ) as $plugin ) {
			if ( preg_match( '~(?:^|/|-)indexe(?:/|-|\.)~i', (string) $plugin ) ) {
				$itens[] = array(
					'id'                     => 'indexe',
					'nome'                   => 'Indexe',
					'ativo'                  => true,
					'configuracao_conhecida' => false,
					'ligado'                 => false,
					'base'                   => 'Plugin ativo; adaptador de publicação não validado',
				);
				break; }
		}
		$saida = array();
		foreach ( array_slice( (array) apply_filters( 'f3base_llms_emissores', $itens ), 0, 20 ) as $item ) {
			if ( ! is_array( $item ) || empty( $item['id'] ) || empty( $item['nome'] ) ) {
				continue; }
			$saida[] = array(
				'id'                     => sanitize_key( (string) $item['id'] ),
				'nome'                   => sanitize_text_field( (string) $item['nome'] ),
				'ativo'                  => ! empty( $item['ativo'] ),
				'configuracao_conhecida' => ! empty( $item['configuracao_conhecida'] ) && ! empty( $item['base'] ),
				'ligado'                 => ! empty( $item['ligado'] ),
				'base'                   => substr( sanitize_text_field( (string) ( $item['base'] ?? '' ) ), 0, 240 ),
			);
		}
		return $saida;
	}

	/**
	 * O plugin de SEO está com a publicação deste arquivo LIGADA?
	 *
	 * DUAS PERGUNTAS, e as duas precisam fechar: a chave gravada diz que ele
	 * publicaria o arquivo, e a lista de plugins ativos diz que ele está no ar
	 * para publicá-lo. Com a chave ligada e o plugin desativado não há emissor
	 * concorrente nenhum — há uma option órfã —, e ceder o endereço a ela é
	 * deixar `/llms.txt` sem dono.
	 *
	 * @return array{ligado:bool,nome:string}
	 */
	public static function concorrente_de_llms(): array {
		foreach ( self::emissores_llms() as $emissor ) {
			if ( $emissor['ativo'] && $emissor['configuracao_conhecida'] && $emissor['ligado'] ) {
				return array(
					'ligado' => true,
					'nome'   => $emissor['nome'] . ' com publicação declarada (' . $emissor['base'] . ')',
				); }
		}
		return array(
			'ligado' => false,
			'nome'   => '',
		);
	}

	/**
	 * Quem serve sitemap neste site, medido nas duas fontes possíveis.
	 *
	 * O sitemap do plugin de SEO só responde com o plugin ATIVO: a chave
	 * `enable_xml_sitemap` sobrevive à desativação, e imprimir
	 * `sitemap_index.xml` sobre uma option órfã é apontar o leitor automático
	 * para um endereço que ninguém serve.
	 *
	 * @return array{url:string,fonte:string}
	 */
	public static function sitemap_medido(): array {
		$wpseo  = get_option( 'wpseo', array() );
		$do_seo = is_array( $wpseo ) && ! empty( $wpseo['enable_xml_sitemap'] ) && self::plugin_de_seo_ativo();

		$servidor  = function_exists( 'wp_sitemaps_get_server' ) ? wp_sitemaps_get_server() : null;
		$do_nucleo = $servidor && $servidor->sitemaps_enabled();
		$medido    = self::endereco_do_sitemap( $do_seo, (bool) $do_nucleo, trailingslashit( home_url( '/' ) ) );
		if ( $do_seo && is_callable( array( 'WPSEO_Sitemaps_Router', 'get_base_url' ) ) ) {
			$medido['url'] = WPSEO_Sitemaps_Router::get_base_url( 'sitemap_index.xml' ); }
		if ( ! $do_seo && $do_nucleo ) {
			$medido['url'] = $servidor->index->get_index_url(); }
		return $medido;
	}

	/**
	 * CANDIDATOS enumerados do conteúdo publicado, com o noindex já medido.
	 *
	 * `has_password => false` NÃO É DETALHE: no WordPress, `publish` inclui o
	 * conteúdo PROTEGIDO POR SENHA — quem não tem a senha vê o formulário, não o
	 * texto. Sem esta cláusula o título e a URL da página protegida entravam no
	 * `/llms.txt` e o CORPO INTEIRO dela entrava no `/llms-full.txt`, em texto
	 * puro e sem senha nenhuma: a proteção que alguém pôs na página era
	 * contornada por um arquivo que este plugin publica.
	 *
	 * @param array<int,string> $tipos    Tipos válidos.
	 * @param int               $palavras Teto de palavras do resumo.
	 * @param int               $teto     Teto de itens enumerados.
	 * @return array<int,array<string,mixed>>
	 */
	public static function enumerar( array $tipos, int $palavras, int $teto ): array {
		if ( array() === $tipos ) {
			return array();
		}

		$posts = get_posts(
			array(
				'post_type'        => $tipos,
				'post_status'      => 'publish',
				'has_password'     => false,
				'numberposts'      => max( 1, $teto ),
				'orderby'          => 'date',
				'order'            => 'DESC',
				'suppress_filters' => false,
			)
		);

		$saida = array();

		foreach ( is_array( $posts ) ? $posts : array() as $post ) {
			if ( ! $post instanceof WP_Post || ! is_post_publicly_viewable( $post ) ) {
				continue;
			}

			$canonical = self::canonical_do_post( $post );
			if ( '' === $canonical ) {
				continue; }
			$meta = get_post_meta( $post->ID, F3Base_Modulo_Noindex_Honrado::META_DESCRICAO, true );
			$meta = is_scalar( $meta ) ? (string) $meta : '';

			$descricao = self::descricao_do_item( $meta, (string) $post->post_excerpt, (string) $post->post_content, $palavras );

			$saida[] = array(
				'id'        => (int) $post->ID,
				'titulo'    => wp_specialchars_decode( (string) get_the_title( $post ), ENT_QUOTES ),
				'url'       => $canonical,
				'descricao' => $descricao['texto'],
				'fonte'     => $descricao['fonte'],
				'tipo'      => (string) $post->post_type,
				'data'      => (string) $post->post_date_gmt,
				'conteudo'  => (string) $post->post_content,
				'origem'    => self::ORIGEM_AUTOMATICO,
				'noindex'   => F3Base_Modulo_Noindex_Honrado::post_e_noindex( (int) $post->ID ),
			);
		}

		return $saida;
	}
}
