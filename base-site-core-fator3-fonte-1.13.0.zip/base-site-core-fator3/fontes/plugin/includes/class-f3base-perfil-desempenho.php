<?php
/** Perfil optativo: só administrador com nonce, sem SQL, caminhos ou dados pessoais. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Perfil_Desempenho {
	private static float $inicio = 0;
	private static array $etapas = array();
	public static function iniciar(): void {
		add_action( 'init', array( __CLASS__, 'ativar' ), 1 );
	}
	public static function ativar(): void {
		if ( empty( $_GET['f3base_perfil'] ) || ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['f3base_perfil'] ) ), 'f3base_perfil' ) ) {
			return; }
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); }
		self::$inicio = microtime( true );
		nocache_headers();
		foreach ( array( 'wp_loaded', 'wp', 'template_redirect', 'wp_head', 'wp_footer' ) as $hook ) {
			add_action(
				$hook,
				static function () use ( $hook ): void {
					self::$etapas[ $hook ] = round( ( microtime( true ) - self::$inicio ) * 1000, 2 );
				},
				PHP_INT_MAX
			);
		}
		add_action(
			'send_headers',
			static function (): void {
				if ( headers_sent() ) {
					return; }
				header( 'Cache-Control: private, no-store, max-age=0', true );
				header( 'Server-Timing: php_headers;dur=' . round( ( microtime( true ) - (float) ( $_SERVER['REQUEST_TIME_FLOAT'] ?? self::$inicio ) ) * 1000, 2 ) . ', php_desde_init;dur=' . round( ( microtime( true ) - self::$inicio ) * 1000, 2 ) );
			}
		);
		add_action(
			'shutdown',
			static function (): void {
				$r = array(
					'etapas_ms_desde_init' => self::$etapas,
					'php_total_ms'         => round( ( microtime( true ) - (float) ( $_SERVER['REQUEST_TIME_FLOAT'] ?? self::$inicio ) ) * 1000, 2 ),
					'pico_memoria_bytes'   => memory_get_peak_usage( true ),
					'escopo'               => 'Requisição autenticada; não equivale a TTFB externo nem comprova cache MISS.',
				);
				set_transient( 'f3base_perfil_' . get_current_user_id(), $r, 600 );
			}
		);
	}
}
