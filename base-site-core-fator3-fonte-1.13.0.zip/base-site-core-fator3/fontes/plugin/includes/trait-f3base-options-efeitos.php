<?php
/** Serviço interno de efeitos composto exclusivamente pela fachada F3Base_Options. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

trait F3Base_Options_Efeitos {
	/** Efeito pertence ao dono da option. Não propaga exceções depois da persistência. */
	private static function executar_efeito( string $nome, $valor, array $d ): array {
		if ( ! isset( $d['apos_escrita'] ) ) {
			return array(
				'status'  => 'not_required',
				'applied' => null,
				'codigo'  => 'sem_efeito_sincrono',
				'motivo'  => '',
			); }
		try {
			$r = is_callable( $d['apos_escrita'] ) ? call_user_func( $d['apos_escrita'], $valor ) : null;
			if ( ! is_array( $r ) || ! is_bool( $r['ok'] ?? null ) ) {
				return array(
					'status'  => 'failed',
					'applied' => false,
					'codigo'  => 'efeito_resposta_invalida',
					'motivo'  => 'Configuração gravada; o dono do efeito não devolveu um resultado válido.',
				);
			}
			return array(
				'status'  => $r['ok'] ? 'applied' : 'failed',
				'applied' => $r['ok'],
				'codigo'  => $r['ok'] ? 'efeito_aplicado' : 'efeito_falhou',
				'motivo'  => self::e_segredo( $nome ) ? '' : (string) ( $r['motivo'] ?? '' ),
			);
		} catch ( Throwable $falha ) {
			// Exceções podem conter credenciais ou payloads; o código basta para decidir o próximo passo.
			return array(
				'status'  => 'failed',
				'applied' => false,
				'codigo'  => 'efeito_excecao',
				'motivo'  => 'Configuração gravada; ocorreu uma exceção na aplicação do efeito pelo Core.',
			);
		}
	}

	private static function verificar_configuracao_interna( string $nome, $valor = null ): array {
		$d = self::declaracao( $nome );
		if ( null === $d ) {
			return self::resultado_verificacao( 'not_attempted', 'none', 'option_nao_gerenciada', 'Option fora do catálogo.' ); }
		if ( ! empty( $d['estado_execucao'] ) ) {
			return self::resultado_verificacao( 'not_required', 'none', 'estado_interno', 'Registro interno, sem comportamento público associado.' ); }
		if ( 'f3base_cabecalhos' === $nome && class_exists( 'F3Base_Cache_Pagina' ) ) {
			return F3Base_Cache_Pagina::verificacao(); }
		if ( class_exists( 'F3Base_Cache_Pagina' ) && F3Base_Cache_Pagina::afeta( $nome ) && ! empty( F3Base_Cache_Pagina::estado()['pendente'] ) ) {
			return self::resultado_verificacao( 'pending', 'public_http', 'cache_pendente', 'A configuração está gravada; a atualização do cache de página está pendente.' );
		}

		if ( is_callable( $d['verifica'] ?? null ) ) {
			try {
				$r = call_user_func( $d['verifica'], null === $valor ? self::ler( $nome ) : $valor );
				if ( is_array( $r ) && in_array( $r['status'] ?? '', array( 'verified', 'failed', 'pending', 'not_required' ), true ) ) {
					return self::resultado_verificacao( $r['status'], (string) ( $r['scope'] ?? 'runtime' ), (string) ( $r['codigo'] ?? '' ), self::e_segredo( $nome ) ? '' : (string) ( $r['motivo'] ?? '' ), (int) ( $r['checked_at'] ?? 0 ) );
				}
			} catch ( Throwable $falha ) {
				unset( $falha ); // A falha será informada como prova pendente abaixo.
			}
			return self::resultado_verificacao( 'pending', 'runtime', 'verificacao_indisponivel', 'Configuração gravada; a verificação do comportamento não foi concluída.' );
		}
		return self::resultado_verificacao( 'pending', 'runtime', 'requer_observacao', 'A preferência é lida pelo plugin. O comportamento precisa ser observado no contexto indicado pelo módulo.' );
	}
}
