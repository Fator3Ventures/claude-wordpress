<?php
/** Relevância de alterações do Yoast para conteúdo público. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Adaptador_Yoast {
	/** Campos operacionais conhecidos não alteram a representação pública. Desconhecidos são conservadores. */
	public static function opcao_publica_alterada( string $nome, $antes, $depois ): bool {
		if ( ! str_starts_with( $nome, 'wpseo' ) || $antes === $depois ) {
			return false; }
		if ( in_array( $nome, array( 'wpseo_notifications', 'wpseo_dismissed_conflicts', 'wpseo_reindex', 'wpseo_migrations' ), true ) ) {
			return false; }
		if ( ! is_array( $antes ) || ! is_array( $depois ) ) {
			return true; }
		$internos = array( 'version', 'previous_version', 'tracking', 'first_activated_on', 'indexing_started', 'indexing_completed', 'indexing_reason', 'indexables_indexing_completed', 'indexables_indexing_started', 'dismissed_config', 'configuration_finished_steps', 'notifications', 'show_onboarding_notice', 'semrush_integration_active', 'ryte_indexability' );
		$internos = (array) apply_filters( 'f3base_yoast_campos_internos', $internos, $nome );
		foreach ( array_unique( array_merge( array_keys( $antes ), array_keys( $depois ) ) ) as $chave ) {
			if ( in_array( $chave, $internos, true ) ) {
				continue; }
			if ( array_key_exists( $chave, $antes ) !== array_key_exists( $chave, $depois ) || ( $antes[ $chave ] ?? null ) !== ( $depois[ $chave ] ?? null ) ) {
				return true; }
		}
		return false;
	}
}
