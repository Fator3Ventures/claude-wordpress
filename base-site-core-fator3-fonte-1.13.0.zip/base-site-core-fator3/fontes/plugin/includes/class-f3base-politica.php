<?php
/** Política explícita e controles locais independentes. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Politica {
    public static function catalogo(array $c): array {
        $c[F3Base_Options::OPTION_OPERAVEIS]['padrao'] = array('schema'=>1,'modo'=>'todas','lista'=>array());
        foreach (array('f3base_release_1130','f3base_1130_trava') as $n) {
            $c[$n] = array('rotulo'=>$n,'descricao'=>'Estado do esquema atual.','operavel'=>false,'estado_execucao'=>true,'campo'=>'grupo','padrao'=>array(),'autoload'=>false,'sanitiza'=>array(F3Base_Servicos::class,'identidade'));
        }
        return $c;
    }
    public static function elegiveis(): array { return array_keys(array_filter(F3Base_Options::catalogo(), static fn($d)=>!empty($d['operavel']))); }
    public static function validar($p): bool {
        return is_array($p) && count($p)===3 && ($p['schema']??null)===1 && in_array($p['modo']??'',array('todas','selecionadas','nenhuma'),true) && is_array($p['lista']??null) && array_is_list($p['lista']) && !array_filter($p['lista'],static fn($v)=>!is_string($v)) && !array_diff($p['lista'],self::elegiveis()) && count($p['lista'])===count(array_unique($p['lista'])) && (($p['modo']==='selecionadas') === (count($p['lista'])>0));
    }
    private static function efetivas($p): array {return !self::validar($p)?array():($p['modo']==='todas'?self::elegiveis():$p['lista']);}
    public static function permite(string $n): bool {
        $p=get_option(F3Base_Options::OPTION_OPERAVEIS);
        return self::validar($p) && ($p['modo']==='todas' || ($p['modo']==='selecionadas' && in_array($n,$p['lista'],true)));
    }
    public static function ler(): array {
        if (!current_user_can('manage_options')) { return array('ok'=>false,'codigo'=>'sem_permissao'); }
        return array('ok'=>true,'politica'=>F3Base_Options::fotografia(F3Base_Options::OPTION_OPERAVEIS),'gestao'=>F3Base_Options::fotografia('f3base_politica_canal'),'elegiveis'=>self::elegiveis());
    }
    public static function escrever(array $e, bool $local=false): array {
        if (!current_user_can('manage_options')) { return array('ok'=>false,'codigo'=>'sem_permissao'); }
        if (!$local && !F3Base_Options::ler('f3base_politica_canal')) { return array('ok'=>false,'codigo'=>'gestao_canal_desabilitada'); }
        if (array_diff(array_keys($e),array('politica','simular','revisao_esperada')) || !self::validar($e['politica']??null) || (isset($e['simular'])&&!is_bool($e['simular']))) { return array('ok'=>false,'codigo'=>'politica_invalida'); }
        $n=F3Base_Options::OPTION_OPERAVEIS; $foto=F3Base_Options::fotografia($n);
        if (!($e['simular']??true) || isset($e['revisao_esperada'])) {
            if (!is_string($e['revisao_esperada']??null) || !hash_equals($foto['revisao'],$e['revisao_esperada'])) { return array('ok'=>false,'codigo'=>'conflito'); }
        }
        if ($e['simular']??true) { $antes=self::efetivas($foto['valor']);$depois=self::efetivas($e['politica']);return array('ok'=>true,'simulado'=>true,'antes'=>$foto['valor'],'depois'=>$e['politica'],'acrescimos'=>array_values(array_diff($depois,$antes)),'remocoes'=>array_values(array_diff($antes,$depois)),'revisao'=>$foto['revisao']); }
        return F3Base_Options::pelo_canal($local?'admin':'ability',static fn()=>F3Base_Options::gravar($n,$e['politica'],$local?F3Base_Options::ORIGEM_MANUAL:F3Base_Options::ORIGEM_ABILITY,$foto['revisao']));
    }
    public static function gestao(bool $ativa,string $revisao): array {
        if (!current_user_can('manage_options')) { return array('ok'=>false,'codigo'=>'sem_permissao'); }
        return F3Base_Options::gravar('f3base_politica_canal',$ativa,F3Base_Options::ORIGEM_MANUAL,$revisao);
    }
    public static function iniciar(): void { add_action('admin_post_f3base_politica',array(__CLASS__,'salvar')); }
    public static function registrar(): void {
        F3Base_Servicos::ability('config-core-politica-ler','Estado e revisão da política e da gestão por agentes',array(__CLASS__,'ler'));
        F3Base_Servicos::ability('config-core-politica-escrever','Simular ou substituir política explícita; exige gestão por agentes habilitada',array(__CLASS__,'escrever'),array(
            'politica'=>array('type'=>'object','additionalProperties'=>false,'required'=>array('schema','modo','lista'),'properties'=>array('schema'=>array('const'=>1),'modo'=>array('enum'=>array('todas','selecionadas','nenhuma')),'lista'=>array('type'=>'array','uniqueItems'=>true,'items'=>array('type'=>'string','enum'=>self::elegiveis())))),
            'simular'=>array('type'=>'boolean','default'=>true),'revisao_esperada'=>array('type'=>'string')
        ),array('politica'),false);
    }
    public static function salvar(): void {
        if (!current_user_can('manage_options')) { wp_die('Sem permissão.',403); }
        $grupo=sanitize_key($_POST['grupo']??'');
        if (!in_array($grupo,array('lista','gestao'),true)) { wp_die('Ação inválida.',400); }
        check_admin_referer('f3base-politica-'.$grupo);
        $rev=is_string($_POST['revisao']??null)?wp_unslash($_POST['revisao']):'';
        $draft=array('grupo'=>$grupo);
        if ($grupo==='gestao') { $draft['ativa']=isset($_POST['ativa']); $r=self::gestao($draft['ativa'],$rev); }
        else {
            $modo=sanitize_key($_POST['modo']??'');$lista=array_values((array)wp_unslash($_POST['nomes']??array()));
            if ($modo!=='selecionadas') { $lista=array(); } elseif (!$lista) { $modo='nenhuma'; }
            $draft['politica']=array('schema'=>1,'modo'=>$modo,'lista'=>$lista);
            $r=self::escrever(array('politica'=>$draft['politica'],'simular'=>isset($_POST['simular']),'revisao_esperada'=>$rev),true);
        }
        set_transient('f3base_politica_resultado_'.get_current_user_id(),array('resultado'=>$r,'rascunho'=>$draft),300);
        wp_safe_redirect(admin_url('admin.php?page='.F3Base_Admin_Tela::SLUG.'&aba=operacao'));exit;
    }
    public static function tela(): void {
        if (!current_user_can('manage_options')) { return; }
        $foto=F3Base_Options::fotografia(F3Base_Options::OPTION_OPERAVEIS);$g=F3Base_Options::fotografia('f3base_politica_canal');$p=$foto['valor'];$ativa=(bool)$g['valor'];
        $msg=get_transient('f3base_politica_resultado_'.get_current_user_id());delete_transient('f3base_politica_resultado_'.get_current_user_id());
        echo '<h2>Permissões de configuração</h2>';
        if ($msg) {
            $r=$msg['resultado'];$ok=!empty($r['persisted']);$sim=!empty($r['simulado']);
            $texto=$ok?($msg['rascunho']['grupo']==='gestao'?('Gestão por agentes '.($ativa?'ativada.':'desativada.')):'Permissões salvas.') : ($sim?'Prévia pronta. Confira a seleção e salve para aplicar.':'Não foi possível salvar: '.($r['codigo']??'falha').'. O estado salvo permanece indicado abaixo.');
            echo '<div role="status" class="notice notice-'.($ok||$sim?'success':'error').' inline"><p>'.esc_html($texto).'</p></div>';
            if($sim){$c=F3Base_Options::catalogo();foreach(array('acrescimos'=>'Passarão a permitir edição','remocoes'=>'Deixarão de permitir edição') as $key=>$label){$names=array_map(static fn($n)=>$c[$n]['rotulo']??$n,$r[$key]??array());echo '<p><strong>'.esc_html($label).':</strong> '.esc_html($names?implode(', ',$names):'Nenhuma alteração').'.</p>';}}
            if (!$ok) { if (isset($msg['rascunho']['politica'])){$p=$msg['rascunho']['politica'];} if(isset($msg['rascunho']['ativa'])){$ativa=$msg['rascunho']['ativa'];} }
        }
        $p=self::validar($p)?$p:array('schema'=>1,'modo'=>'nenhuma','lista'=>array());
        echo '<p>Defina quais configurações podem ser editadas no painel e pelos canais autenticados. Restringir a edição mantém os valores configurados.</p><p>Modo salvo: <strong>'.esc_html($foto['valor']['modo']??'indisponível').'</strong>.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-f3base-politica="lista"><input type="hidden" name="action" value="f3base_politica"><input type="hidden" name="grupo" value="lista"><input type="hidden" name="revisao" value="'.esc_attr($foto['revisao']).'">';wp_nonce_field('f3base-politica-lista');
        echo '<label for="f3base-politica-modo">Configurações editáveis</label> <select id="f3base-politica-modo" name="modo">';
        foreach(array('todas'=>'Todas as configurações elegíveis','selecionadas'=>'Somente as selecionadas','nenhuma'=>'Nenhuma configuração') as $v=>$label){echo '<option value="'.$v.'" '.selected($p['modo'],$v,false).'>'.esc_html($label).'</option>';}
        echo '</select><fieldset><legend>Seleção de configurações</legend>';
        foreach(F3Base_Options::catalogo() as $n=>$d){if(empty($d['operavel'])){continue;} echo '<label style="display:block"><input type="checkbox" name="nomes[]" value="'.esc_attr($n).'" '.checked(in_array($n,$p['lista'],true),true,false).'> '.esc_html($d['rotulo']).'</label>';}
        echo '</fieldset><p>Em “Somente as selecionadas”, desmarcar todos salva “Nenhuma”. Você mantém acesso a esta tela para reabrir permissões.</p><p role="status" data-resumo></p><p><button class="button" name="simular" value="1">Conferir seleção</button> <button class="button button-primary">Salvar permissões</button></p></form><hr>';
        echo '<h2>Gestão por agentes</h2><p>Estado salvo: <strong>'.($g['valor']?'Ativado':'Desativado').'</strong>.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'" data-f3base-politica="gestao"><input type="hidden" name="action" value="f3base_politica"><input type="hidden" name="grupo" value="gestao"><input type="hidden" name="revisao" value="'.esc_attr($g['revisao']).'">';wp_nonce_field('f3base-politica-gestao');
        echo '<label><input type="checkbox" name="ativa" value="1" '.checked($ativa,true,false).'> Permitir que agentes alterem estas permissões</label><p>Agentes conectados com uma conta administradora poderão alterar a lista de configurações editáveis. Ao desativar, a lista permanece como está e você continua podendo ajustá-la nesta tela.</p><p role="status" data-resumo></p><button class="button button-primary">Salvar alteração</button></form><hr>';
        wp_enqueue_script('f3base-politica',F3BASE_PLUGIN_URL.'admin/assets/f3base-politica.js',array(),F3BASE_PLUGIN_VERSAO,true);
        F3Base_Redirects_Servico::tela();
    }
}
