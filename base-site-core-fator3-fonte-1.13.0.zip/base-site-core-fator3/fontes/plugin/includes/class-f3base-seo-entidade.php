<?php
/** Identidade declarada: validação local, sem consultas externas na gravação. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Seo_Entidade {
	public static function cnpj( string $v ): string {
		return strtoupper( preg_replace( '/[.\/\s-]+/', '', $v ) ); }
	public static function cnpj_valido( string $v ): bool {
		$v = self::cnpj( $v );
		if ( ! preg_match( '/^[A-Z0-9]{12}[0-9]{2}$/D', $v ) || preg_match( '/^(.)\1{13}$/D', $v ) ) {
			return false; }
		for ( $n = 12; $n <= 13; ++$n ) {
			$soma = 0;
			$peso = 2;
			for ( $i = $n - 1; $i >= 0; --$i ) {
				$soma += ( ord( $v[ $i ] ) - 48 ) * $peso;
				$peso  = 9 === $peso ? 2 : $peso + 1; }
			$resto = $soma % 11;
			$dv    = $resto < 2 ? 0 : 11 - $resto;
			if ( (string) $dv !== $v[ $n ] ) {
				return false; }
		}
		return true;
	}
	public static function https( $url ): bool {
		if ( ! is_string( $url ) || ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			return false; }
		$p = wp_parse_url( $url );
		return 'https' === ( $p['scheme'] ?? '' ) && ! empty( $p['host'] ) && ! isset( $p['user'] ) && ! isset( $p['pass'] );
	}
	public static function validar( $v ): array {
		$erros = array();
		$erro  = static function ( string $campo, string $codigo, string $motivo ) use ( &$erros ): void {
			$erros[] = array(
				'campo'  => $campo,
				'codigo' => $codigo,
				'motivo' => $motivo,
			);
		};
		if ( ! is_array( $v ) ) {
			return array(
				array(
					'campo'  => '',
					'codigo' => 'objeto_esperado',
					'motivo' => 'Informe um objeto de entidade.',
				),
			); }
		foreach ( array( 'nome', 'razao_social', 'cnpj', 'descricao', 'email', 'telefone', 'autoria' ) as $k ) {
			if ( isset( $v[ $k ] ) && ! is_string( $v[ $k ] ) ) {
				$erro( $k, 'texto_esperado', 'Informe texto.' ); }
		}
		if ( $erros ) {
			return $erros; }
		if ( ! empty( $v['cnpj'] ) && ! self::cnpj_valido( $v['cnpj'] ) ) {
			$erro( 'cnpj', 'cnpj_invalido', 'Formato ou dígitos verificadores do CNPJ inválidos.' ); }
		if ( ! empty( $v['email'] ) && ! is_email( $v['email'] ) ) {
			$erro( 'email', 'email_invalido', 'E-mail inválido.' ); }
		if ( ! empty( $v['telefone'] ) && ! preg_match( '/^\+[1-9][0-9]{7,14}$/D', $v['telefone'] ) ) {
			$erro( 'telefone', 'telefone_invalido', 'Use telefone internacional E.164, com + e dígitos.' ); }
		if ( isset( $v['autoria'] ) && ! in_array( $v['autoria'], array( 'usuario', 'organizacao' ), true ) ) {
			$erro( 'autoria', 'autoria_invalida', 'Escolha usuário ou institucional.' ); }
		$a = $v['endereco'] ?? array();
		if ( ! is_array( $a ) ) {
			$erro( 'endereco', 'objeto_esperado', 'Endereço deve ser objeto.' );
			$a = array(); }
		foreach ( array( 'logradouro', 'cidade', 'uf', 'cep', 'pais' ) as $k ) {
			if ( isset( $a[ $k ] ) && ! is_string( $a[ $k ] ) ) {
				$erro( 'endereco.' . $k, 'texto_esperado', 'Informe texto.' ); }
		}
		if ( $erros ) {
			return $erros; }
		$pais = strtoupper( $a['pais'] ?? 'BR' );
		if ( $a && ! preg_match( '/^[A-Z]{2}$/D', $pais ) ) {
			$erro( 'endereco.pais', 'pais_invalido', 'Use país ISO com duas letras.' ); }
		if ( 'BR' === $pais ) {
			if ( ! empty( $a['uf'] ) && ! in_array( strtoupper( $a['uf'] ), explode( ' ', 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO' ), true ) ) {
				$erro( 'endereco.uf', 'uf_invalida', 'UF brasileira inválida.' ); }
			if ( ! empty( $a['cep'] ) && ! preg_match( '/^[0-9]{5}-?[0-9]{3}$/D', $a['cep'] ) ) {
				$erro( 'endereco.cep', 'cep_invalido', 'CEP brasileiro deve ter oito dígitos.' ); }
		} elseif ( ! empty( $v['cnpj'] ) ) {
			$erro( 'endereco.pais', 'cnpj_pais_incompativel', 'Revise CNPJ e país estrangeiro antes de publicar.' ); }
		if ( isset( $v['same_as'] ) && ! is_array( $v['same_as'] ) ) {
			$erro( 'same_as', 'lista_esperada', 'Informe uma lista de URLs.' ); }
		foreach ( (array) ( $v['same_as'] ?? array() ) as $i => $url ) {
			$host = is_string( $url ) ? strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) : '';
			if ( ! self::https( $url ) || strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) === $host || preg_match( '/(^|\.)(wa\.me|whatsapp\.com)$/', $host ) || preg_match( '~/(share|sharer)([/.?]|$)~i', (string) $url ) ) {
				$erro( 'same_as.' . $i, 'same_as_invalido', 'Use perfil externo HTTPS; links de contato, compartilhamento e domínio próprio não são aceitos.' ); }
		}
		if ( isset( $v['pessoas'] ) ) {
			$schema = F3Base_Options::declaracao( 'f3base_seo_entidade' )['subcampos']['pessoas']['schema_entrada'];
			$r      = rest_validate_value_from_schema( $v['pessoas'], $schema, 'pessoas' );
			if ( is_wp_error( $r ) ) {
				$erro( 'pessoas', 'pessoas_invalidas', $r->get_error_message() ); } else {
				$ids = array(); foreach ( $v['pessoas'] as $i => $p ) {
					$id = $p['id'] ?? hash( 'sha256', $p['nome'] );
					if ( isset( $ids[ $id ] ) ) {
						$erro( 'pessoas.' . $i, 'pessoa_duplicada', 'Identidade repetida.' );
					} $ids[ $id ] = true;
					if ( isset( $p['id'] ) && ! self::https( $p['id'] ) ) {
						$erro( 'pessoas.' . $i, 'pessoa_id_invalido', 'ID deve ser HTTPS.' ); }
					foreach ( $p['paginas'] as $pid ) {
						$post = get_post( $pid );
						if ( ! $post || ! is_post_publicly_viewable( $post ) || $post->post_password ) {
							$erro( 'pessoas.' . $i, 'pagina_nao_publica', 'Declare páginas públicas.' ); }
					}
					foreach ( self::validar( array( 'same_as' => $p['same_as'] ?? array() ) ) as $e ) {
						$erro( 'pessoas.' . $i . '.same_as', $e['codigo'], $e['motivo'] ); }
				}
				}
		}
		$relacoes = $v['organizacoes_filhas'] ?? array();
		if ( ! is_array( $relacoes ) || ! array_is_list( $relacoes ) || count( $relacoes ) > 50 ) {
			$erro( 'organizacoes_filhas', 'lista_invalida', 'Informe até cinquenta relações.' );
			$relacoes = array(); }
		if ( is_array( $v['organizacao_mae'] ?? null ) && $v['organizacao_mae'] ) {
			$relacoes[] = $v['organizacao_mae']; } elseif ( isset( $v['organizacao_mae'] ) && ! is_string( $v['organizacao_mae'] ) && ! is_array( $v['organizacao_mae'] ) ) {
			$erro( 'organizacao_mae', 'relacao_invalida', 'Use nome legado ou objeto de relação.' ); }
			$identidades = array();
			foreach ( $relacoes as $i => $r ) {
				if ( ! is_array( $r ) || ! is_string( $r['nome'] ?? null ) || '' === trim( $r['nome'] ) || ! self::https( $r['url'] ?? null ) || ( ! empty( $r['id'] ) && ! self::https( $r['id'] ) ) ) {
					$erro( 'relacoes.' . $i, 'relacao_invalida', 'Relação exige nome, URL HTTPS e ID HTTPS opcional.' );
					continue; }
				$id = ! empty( $r['id'] ) ? $r['id'] : trailingslashit( $r['url'] ) . '#organization';
				if ( isset( $identidades[ $id ] ) ) {
					$erro( 'relacoes.' . $i, 'organizacao_duplicada_ou_ciclo', 'A mesma identidade não pode aparecer duas vezes, nem como controladora e filha.' ); }
				$identidades[ $id ] = true;
				$proprio            = F3Base_Autoria::$organizacao['@id'] ?? '';
				if ( $proprio && $proprio === $id ) {
					$erro( 'relacoes.' . $i, 'organizacao_autorreferente', 'Uma organização não pode ser controladora ou filha de si mesma.' ); }
			}
			return $erros;
	}
	public static function recusar( $v ): string {
		return implode( ' ', array_column( self::validar( $v ), 'motivo' ) ); }
	public static function relacao( array $r ): array {
		foreach ( array( 'nome', 'url', 'id' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_string( $r[ $k ] ) ) {
				$r[ $k ] = 'nome' === $k ? sanitize_text_field( $r[ $k ] ) : esc_url_raw( $r[ $k ] ); }
		}
		return $r;
	}
	public static function normalizar( array $v ): array {
		foreach ( array( 'razao_social', 'descricao', 'email', 'telefone' ) as $k ) {
			if ( isset( $v[ $k ] ) && is_string( $v[ $k ] ) ) {
				$v[ $k ] = sanitize_text_field( $v[ $k ] ); }
		}
		if ( is_string( $v['cnpj'] ?? null ) ) {
			$v['cnpj'] = self::cnpj( $v['cnpj'] ); }
		if ( is_array( $v['endereco'] ?? null ) && array_filter( $v['endereco'] ) ) {
			$v['endereco']['pais'] = strtoupper( $v['endereco']['pais'] ?? 'BR' );
			foreach ( array( 'logradouro', 'cidade', 'uf', 'cep' ) as $k ) {
				if ( is_string( $v['endereco'][ $k ] ?? null ) ) {
					$v['endereco'][ $k ] = sanitize_text_field( $v['endereco'][ $k ] ); }
			}
			if ( 'BR' === $v['endereco']['pais'] ) {
				$v['endereco']['uf']  = strtoupper( $v['endereco']['uf'] ?? '' );
				$v['endereco']['cep'] = str_replace( '-', '', $v['endereco']['cep'] ?? '' ); }
		}
		return $v;
	}
	public static function propriedades( array $v, string $id ): array {
		$r = array();
		foreach ( array(
			'razao_social' => 'legalName',
			'cnpj'         => 'taxID',
			'descricao'    => 'description',
			'email'        => 'email',
			'telefone'     => 'telephone',
		) as $k => $p ) {
			if ( ! empty( $v[ $k ] ) && is_string( $v[ $k ] ) ) {
				$r[ $p ] = $v[ $k ]; }
		}
		if ( ! empty( $r['taxID'] ) && self::cnpj_valido( $r['taxID'] ) ) {
			$r['taxID'] = preg_replace( '/^(.{2})(.{3})(.{3})(.{4})(.{2})$/', '$1.$2.$3/$4-$5', self::cnpj( $r['taxID'] ) ); }
		if ( ! empty( $v['endereco'] ) && is_array( $v['endereco'] ) ) {
			$a = array();
			foreach ( array(
				'logradouro' => 'streetAddress',
				'cidade'     => 'addressLocality',
				'uf'         => 'addressRegion',
				'cep'        => 'postalCode',
				'pais'       => 'addressCountry',
			) as $k => $p ) {
				if ( ! empty( $v['endereco'][ $k ] ) ) {
					$a[ $p ] = $v['endereco'][ $k ]; }
			}
			if ( $a ) {
				if ( 'BR' === ( $a['addressCountry'] ?? 'BR' ) && isset( $a['postalCode'] ) && preg_match( '/^[0-9]{8}$/D', $a['postalCode'] ) ) {
					$a['postalCode'] = substr( $a['postalCode'], 0, 5 ) . '-' . substr( $a['postalCode'], 5 ); }
				$r['address'] = array( '@type' => 'PostalAddress' ) + $a; }
		}
		if ( ! empty( $v['organizacao_mae'] ) ) {
			$r['parentOrganization'] = self::no_relacao( $v['organizacao_mae'], $id ); }
		$filhas = array();
		foreach ( (array) ( $v['organizacoes_filhas'] ?? array() ) as $f ) {
			$no = self::no_relacao( $f, $id );
			if ( $no ) {
				$filhas[ $no['@id'] ?? wp_json_encode( $no ) ] = $no; }
		}
		if ( $filhas ) {
			$r['subOrganization'] = array_values( $filhas ); }
		return array_filter( $r );
	}
	private static function no_relacao( $r, string $proprio ): array {
		if ( is_string( $r ) ) {
			return array(
				'@type' => 'Organization',
				'name'  => $r,
			); }
		if ( ! is_array( $r ) || empty( $r['url'] ) || ! self::https( $r['url'] ) ) {
			return array(); }
		$id = ! empty( $r['id'] ) ? $r['id'] : rtrim( $r['url'], '/' ) . '/#organization';
		if ( $proprio === $id ) {
			return array(); }
		return array(
			'@type' => 'Organization',
			'@id'   => $id,
			'name'  => $r['nome'] ?? '',
			'url'   => $r['url'],
		);
	}
}
