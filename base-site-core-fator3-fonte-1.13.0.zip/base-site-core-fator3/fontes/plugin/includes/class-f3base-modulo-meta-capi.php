<?php
/**
 * Módulo meta-capi: o evento de SERVIDOR da Conversions API da Meta.
 *
 * O QUE ESTE MÓDULO FECHA, e o defeito estava medido no próprio pacote. A 1.1.0
 * já gerava o `event_id` no clique do CTA (`assets/f3base-leads.js`) e o mandava
 * junto do Pixel — `fbq('track','Lead',{},{eventID})` — exatamente para
 * DEDUPLICAR contra um evento de servidor. Esse evento nunca era enviado. O
 * pacote pagava o preço da deduplicação (um identificador a mais viajando em
 * toda conversão) sem receber nada em troca: o pixel de navegador é a metade que
 * o iOS e os bloqueadores cortam, e a outra metade não existia.
 *
 * O DESENHO, e cada peça dele tem motivo:
 *
 * - **O token é OPTION, e nunca configuração.** `f3base_meta_capi_token` é
 *   segredo do site; `config/site.json` viaja dentro do zip, é lido pela suíte,
 *   entra no bundle e chega a quem faz o upload. Segredo em arquivo que viaja é
 *   segredo vazado. Quem grava é o agente, pelo canal — e NENHUM lote do
 *   implantador escreve essa option, por isso ela não está no schema nem no
 *   arquivo único. A ausência é a declaração.
 * - **Sem token, nada acontece, e o estado NOMEIA a option.** Com token e sem
 *   `f3base_meta_pixel_id`, o módulo fecha degradado nomeando a dependência: o
 *   endpoint de destino da Meta é `/<pixel-id>/events`, e sem o ID não há para
 *   onde enviar.
 * - **A chamada não segura a resposta ao visitante e não pode falhar o lead.**
 *   O envio acontece em OUTRA requisição, por evento único do WP-Cron; a
 *   justificativa da escolha está em `agendar()`.
 * - **Nunca dado pessoal em claro.** E-mail e telefone saem em SHA-256 sobre o
 *   valor normalizado pela regra que a própria Meta publica. IP e user agent vão
 *   como a Meta os pede — eles são a chave de correspondência que sobra quando o
 *   navegador não colabora —, e nada além disso sai daqui.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Evento de servidor `Lead` para a Conversions API da Meta.
 */
final class F3Base_Modulo_Meta_Capi extends F3Base_Modulo {

	/**
	 * Option que guarda o token de acesso. NUNCA no arquivo único.
	 */
	public const OPTION_TOKEN = 'f3base_meta_capi_token';

	/**
	 * Evento único do agendador que executa o envio.
	 */
	public const HOOK = 'f3base_meta_capi_enviar';

	/**
	 * Prefixo do transiente que carrega o payload até o evento rodar.
	 */
	public const TRANSIENTE = 'f3base_capi_';

	/**
	 * Host da Graph API.
	 */
	public const HOST = 'https://graph.facebook.com/';

	/**
	 * Versão da Graph API que este pacote endereça.
	 *
	 * DECLARADA, e com prazo de validade declarado junto: a Meta aposenta
	 * versões da Graph API por calendário, e nenhuma release nossa adivinha qual
	 * é a vigente no dia em que o site estiver no ar. Quando esta expirar, a
	 * chamada passa a responder erro — e o erro sai NOMEADO na atividade e no
	 * estado do módulo, com o código HTTP e a mensagem da Meta. O filtro existe
	 * para que trocá-la não exija release: é a mesma saída que o resto deste
	 * pacote oferece para dado que muda sem nós.
	 */
	public const VERSAO_GRAPH = 'v21.0';

	/**
	 * Nome do evento, na grafia que a Meta reconhece como conversão de lead.
	 */
	public const EVENTO = 'Lead';

	/**
	 * Origem da ação, na grafia fechada da especificação da Meta.
	 */
	public const ACTION_SOURCE = 'website';

	/**
	 * {@inheritDoc}
	 */
	public function id(): string {
		return 'meta-capi';
	}

	/**
	 * {@inheritDoc}
	 */
	public function nome(): string {
		return __( 'Meta — Conversions API', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function descricao(): string {
		return __( 'Envia o evento Lead de SERVIDOR para a Conversions API da Meta depois da persistência confirmada do lead, com o MESMO event_id que o navegador já manda no Pixel — é ele que deduplica os dois caminhos. E-mail e telefone saem em SHA-256 sobre o valor normalizado; nada de dado pessoal em claro. O token é option do site e nunca viaja no arquivo de configuração.', 'f3base' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function hooks(): array {
		return array(
			array(
				'tipo'       => 'action',
				'hook'       => self::HOOK,
				'metodo'     => 'enviar_agendado',
				'prioridade' => 10,
				'args'       => 1,
			),
			array(
				'tipo'       => 'action',
				'hook'       => 'init',
				'metodo'     => 'inicializar_fila',
				'prioridade' => 30,
				'args'       => 0,
				'sempre'     => true,
			),
			array(
				'tipo'       => 'action',
				'hook'       => F3Base_Capi_Fila::EVENTO,
				'metodo'     => 'recuperar_fila',
				'prioridade' => 10,
				'args'       => 0,
				'sempre'     => true,
			),
		);
	}
	public function inicializar_fila(): void {
		if ( F3Base_Capi_Fila::instalar() ) {
			F3Base_Capi_Fila::planejar(); }
	}
	public function recuperar_fila(): array {
		return F3Base_Capi_Fila::recuperar(); }
	public function desinstalar(): void {
		wp_unschedule_hook( self::HOOK );
		wp_unschedule_hook( F3Base_Capi_Fila::EVENTO );
	}

	/**
	 * {@inheritDoc}
	 */
	public function options_que_controlam(): array {
		return array( self::OPTION_TOKEN, 'f3base_meta_pixel_id' );
	}

	/**
	 * {@inheritDoc}
	 */
	public function atividade(): array {
		return array(
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMO_CAPI, __( 'Último evento aceito pela Meta', 'f3base' ) ),
			F3Base_Atividade::descrever( F3Base_Atividade::ULTIMA_FALHA_CAPI, __( 'Última recusa da Meta', 'f3base' ) ),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	public function dependencias(): array {
		return array(
			array(
				'rotulo'   => self::OPTION_TOKEN,
				'presente' => '' !== self::token(),
				'detalhe'  => '' !== self::token()
					? __( 'token de acesso gravado: o evento de servidor é enviado depois da persistência do lead.', 'f3base' )
					: __( 'vazio: nenhum evento de servidor é enviado. O token é SEGREDO e não viaja no config/site.json — quem o grava é o agente, pelo canal.', 'f3base' ),
			),
			array(
				'rotulo'   => 'f3base_meta_pixel_id',
				'presente' => '' !== self::pixel_id(),
				'detalhe'  => '' !== self::pixel_id()
					? __( 'o endereço de destino da Meta é montado a partir deste ID.', 'f3base' )
					: __( 'vazio: o endpoint da Conversions API é /<pixel-id>/events, e sem o ID não existe destino para onde enviar.', 'f3base' ),
			),
			array(
				'rotulo'   => __( 'Agendador do WordPress (evento único)', 'f3base' ),
				'presente' => ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ),
				'detalhe'  => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON
					? __( 'DISABLE_WP_CRON está ligada: o evento único fica agendado e só roda quando um cron do sistema chamar wp-cron.php. O lead continua gravado; o que atrasa é o evento de servidor.', 'f3base' )
					: __( 'o envio roda em OUTRA requisição, e por isso não entra no tempo de resposta de quem clicou.', 'f3base' ),
			),
		);
	}

	/**
	 * {@inheritDoc}
	 */
	protected function calcular_estado(): array {
		if ( '' === self::token() ) {
			return $this->inativo(
				sprintf(
					/* translators: %s: nome da option do token. */
					__( 'sem token de acesso: %s está vazia e nenhum evento de servidor é enviado. Ela é SEGREDO do site e por isso não existe no config/site.json nem no schema — nenhum lote do implantador a grava, e a ausência dela ali é a declaração de que ela não viaja no pacote. Gravá-la pelo canal faz o envio passar a existir no lead seguinte, sem passo manual.', 'f3base' ),
					self::OPTION_TOKEN
				)
			);
		}

		if ( '' === self::pixel_id() ) {
			return $this->degradado(
				__( 'token gravado e f3base_meta_pixel_id vazia: o endpoint da Conversions API é /<pixel-id>/events, e sem o ID não há destino. Nada é enviado, e o lead continua sendo gravado normalmente.', 'f3base' )
			);
		}

		$falha  = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_FALHA_CAPI );
		$aceito = F3Base_Atividade::ler( F3Base_Atividade::ULTIMO_CAPI );

		$em_falha  = isset( $falha['em'] ) ? (int) $falha['em'] : 0;
		$em_aceito = isset( $aceito['em'] ) ? (int) $aceito['em'] : 0;

		if ( $em_falha > 0 && $em_falha > $em_aceito ) {
			return $this->degradado(
				sprintf(
					/* translators: 1: data e hora, 2: código HTTP, 3: motivo registrado. */
					__( 'a Meta recusou o evento mais recente em %1$s (HTTP %2$s) e nenhum foi aceito depois dele: %3$s. O LEAD NÃO FOI AFETADO — ele já estava gravado antes de o envio ser agendado, e recusa da Meta nunca muda o status de um lead.', 'f3base' ),
					(string) wp_date( 'd/m/Y H:i', $em_falha ),
					(string) ( $falha['http'] ?? '—' ),
					(string) ( $falha['motivo'] ?? __( 'motivo não registrado', 'f3base' ) )
				)
			);
		}

		return $this->ativo(
			sprintf(
				/* translators: %s: versão da Graph API endereçada. */
				__( 'evento Lead de servidor enviado depois da persistência confirmada, com o mesmo event_id que o navegador manda no Pixel — é ele que deduplica os dois caminhos na Meta. Graph API %s: a Meta aposenta versões por calendário, e quando esta expirar a recusa sai nomeada aqui, com o código HTTP e a mensagem dela.', 'f3base' ),
				self::versao_graph()
			)
		);
	}

	/* ------------------------------------------------------------------ *
	 * Configuração lida
	 * ------------------------------------------------------------------ */

	/**
	 * O token de acesso gravado. Vazio quando não há.
	 *
	 * @return string
	 */
	public static function token(): string {
		$valor = F3Base_Options::ler( self::OPTION_TOKEN );

		return is_string( $valor ) ? trim( $valor ) : '';
	}

	/**
	 * O Pixel ID gravado — o mesmo que o navegador usa.
	 *
	 * FONTE ÚNICA: dois IDs para a mesma conta seriam duas verdades sobre a
	 * mesma medição, e a deduplicação depende de os dois caminhos chegarem ao
	 * MESMO dataset da Meta.
	 *
	 * @return string
	 */
	public static function pixel_id(): string {
		$valor = F3Base_Options::ler( 'f3base_meta_pixel_id' );

		return is_string( $valor ) ? trim( $valor ) : '';
	}

	/**
	 * A versão da Graph API endereçada nesta instalação.
	 *
	 * @return string
	 */
	public static function versao_graph(): string {
		$versao = (string) apply_filters( 'f3base_meta_capi_versao_graph', self::VERSAO_GRAPH );

		return 1 === preg_match( '/^v[0-9]+\.[0-9]+$/', $versao ) ? $versao : self::VERSAO_GRAPH;
	}

	/**
	 * O endereço de destino, montado do Pixel ID.
	 *
	 * @return string Vazio quando não há Pixel ID.
	 */
	public static function endereco(): string {
		$pixel = self::pixel_id();

		return '' === $pixel ? '' : self::HOST . self::versao_graph() . '/' . rawurlencode( $pixel ) . '/events';
	}

	/* ------------------------------------------------------------------ *
	 * Normalização e hash
	 * ------------------------------------------------------------------ */

	/**
	 * SHA-256 de um e-mail NORMALIZADO pela regra da Meta.
	 *
	 * A regra da Meta para e-mail é curta e é só ela: espaço fora, minúsculas.
	 * Nenhum tratamento de ponto e de sufixo por provedor — isso é a regra do
	 * GOOGLE para Enhanced Conversions, e aplicá-la aqui produziria um hash que
	 * a Meta não casa com nada. Normalizar por regra de outro fornecedor não é
	 * normalizar demais: é normalizar errado.
	 *
	 * @param string $email E-mail em claro.
	 * @return string Hash, ou vazio quando não há e-mail.
	 */
	public static function hash_email( string $email ): string {
		$limpo = strtolower( trim( $email ) );

		return '' === $limpo ? '' : hash( 'sha256', $limpo );
	}

	/**
	 * SHA-256 de um telefone NORMALIZADO pela regra da Meta.
	 *
	 * A regra da Meta: só dígitos, com código do país, sem símbolos, sem letras
	 * e sem zeros à esquerda. O `+` do E.164 SAI — a Meta o remove antes de
	 * hashear, e mandar o hash de "+55..." é mandar um hash que não casa.
	 *
	 * SEM ADIVINHAR PAÍS. Um número sem código de país é ambíguo, e completá-lo
	 * pelo idioma do site inventaria um telefone que ninguém digitou: o valor
	 * segue sem hash e o campo simplesmente não vai. É o mesmo critério que o
	 * lado do navegador já usa para as Enhanced Conversions do Google.
	 *
	 * @param string $telefone Telefone em claro.
	 * @return string Hash, ou vazio quando não dá para normalizar com segurança.
	 */
	public static function hash_telefone( string $telefone ): string {
		$bruto = trim( $telefone );

		if ( ! str_starts_with( $bruto, '+' ) ) {
			return '';
		}

		$digitos = preg_replace( '/[^0-9]/', '', $bruto );
		$digitos = is_string( $digitos ) ? ltrim( $digitos, '0' ) : '';

		return '' === $digitos ? '' : hash( 'sha256', $digitos );
	}

	/* ------------------------------------------------------------------ *
	 * Payload
	 * ------------------------------------------------------------------ */

	/**
	 * O payload do evento, na forma que a especificação da Meta declara. FUNÇÃO PURA.
	 *
	 * Pura de propósito: é ela que o piso exercita. Um piso que precisasse de
	 * rede para provar que o `event_id` é o do navegador e que o e-mail sai
	 * hasheado estaria provando a rede.
	 *
	 * `event_id` É O `correlation_id`, e essa identidade é a regra inteira: ele
	 * nasce no navegador, vai no `eventID` do `fbq` e vem no corpo do beacon.
	 * Gerar um identificador novo aqui produziria dois eventos `Lead` na Meta em
	 * vez de um deduplicado — conversão contada duas vezes, que reescreve o
	 * lance do leilão.
	 *
	 * @param array<string,mixed> $dados    Campos já validados do lead.
	 * @param string              $ip       Origem medida da requisição.
	 * @param string              $agente   User agent recebido.
	 * @param string              $url      URL da página onde o clique aconteceu.
	 * @param int                 $quando   Carimbo do evento, em segundos.
	 * @return array<string,mixed>
	 */
	public static function montar_payload( array $dados, string $ip, string $agente, string $url, int $quando ): array {
		$atribuicao = isset( $dados['atribuicao'] ) && is_array( $dados['atribuicao'] ) ? $dados['atribuicao'] : array();

		$user = array();

		$em = self::hash_email( (string) ( $dados['email'] ?? '' ) );
		if ( '' !== $em ) {
			$user['em'] = array( $em );
		}

		$ph = self::hash_telefone( (string) ( $dados['telefone'] ?? '' ) );
		if ( '' !== $ph ) {
			$user['ph'] = array( $ph );
		}

		/*
		 * IP E USER AGENT VÃO EM CLARO PORQUE A META OS PEDE ASSIM, e eles são
		 * a chave de correspondência que sobra quando o navegador não colabora
		 * — que é exatamente o caso que este módulo existe para cobrir. Nenhum
		 * outro campo em claro sai daqui: nome e mensagem do lead NÃO entram no
		 * payload, e não entram porque a Meta não os pede.
		 */
		/*
		 * SÓ IP DE VERDADE ENTRA. `origem()` devolve a palavra `desconhecida`
		 * quando o servidor não informou `REMOTE_ADDR`, e mandar essa palavra
		 * no campo `client_ip_address` seria inventar um dado de
		 * correspondência: a Meta receberia lixo com cara de endereço e casaria
		 * — ou deixaria de casar — por um motivo que ninguém escreveu.
		 */
		if ( '' !== $ip && false !== filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			$user['client_ip_address'] = $ip;
		}

		if ( '' !== $agente ) {
			$user['client_user_agent'] = $agente;
		}

		foreach ( array( 'fbc', 'fbp' ) as $cookie ) {
			$valor = (string) ( $atribuicao[ $cookie ] ?? '' );

			if ( '' !== $valor ) {
				$user[ $cookie ] = $valor;
			}
		}

		$evento = array(
			'event_name'    => self::EVENTO,
			'event_time'    => $quando,
			'event_id'      => (string) ( $dados['correlation_id'] ?? '' ),
			'action_source' => self::ACTION_SOURCE,
			'user_data'     => $user,
		);

		if ( '' !== $url ) {
			$evento['event_source_url'] = $url;
		}

		return array( 'data' => array( $evento ) );
	}

	/* ------------------------------------------------------------------ *
	 * Agendamento e envio
	 * ------------------------------------------------------------------ */

	/**
	 * Agenda o envio para DEPOIS da resposta ao visitante.
	 *
	 * O MEIO ESCOLHIDO É O EVENTO ÚNICO DO AGENDADOR — `wp_schedule_single_event()` —
	 * e a escolha é entre três, com o motivo de cada recusa escrito:
	 *
	 * - `shutdown` roda no MESMO processo. Sem `fastcgi_finish_request()` — que
	 *   não existe em toda hospedagem e por isso não pode ser a regra — a
	 *   conexão fica aberta e o worker fica ocupado pelo tempo inteiro da
	 *   chamada à Meta, inclusive pelo timeout dela. A resposta já foi escrita,
	 *   mas a requisição não terminou: sob rajada de leads é a fila do servidor
	 *   que paga.
	 * - `fastcgi_finish_request()` resolveria isso e não é portátil. Depender
	 *   dela seria um caminho que funciona no laboratório e desaparece na
	 *   hospedagem do cliente, em silêncio.
	 * - O evento único roda em OUTRA requisição, disparada pelo próprio
	 *   WordPress. É o único meio nativo que tira o trabalho de dentro do pedido
	 *   do visitante, e é o mesmo mecanismo que a cadência deste pacote já usa.
	 *
	 * O PAYLOAD NÃO VIAJA NOS ARGUMENTOS DO EVENTO, e isso é a segunda metade da
	 * escolha. Os argumentos de um evento agendado são serializados dentro da
	 * option `cron`, que é AUTOLOAD: cada lead pendente passaria a carregar
	 * hashes, IP e user agent em toda requisição do site, até o evento rodar. O
	 * argumento é só o `record_id`; o payload mora num transiente com prazo, que
	 * não é autoload e some sozinho se o evento nunca rodar.
	 *
	 * O CONSENTIMENTO É O PRIMEIRO PORTÃO, e ele vem medido de fora. O evento
	 * era agendado sem que ninguém perguntasse: `agendar()` conferia token e
	 * Pixel ID e mais nada. O payload leva `em`, `ph`, `client_ip_address`,
	 * `fbc` e `fbp` — o e-mail e o telefone da pessoa, hasheados, e o endereço
	 * dela em claro. O visitante que abria o controle do rodapé e desligava a
	 * medição via o Pixel calar no navegador enquanto o servidor mandava a mesma
	 * conversão pelo outro caminho, com mais dado do que o Pixel levava.
	 *
	 * É O MESMO PORTÃO DO NAVEGADOR, e não um segundo: quem mede é o módulo de
	 * consentimento, quem chama é o endpoint — que já mediu o estado para gravar
	 * no lead —, e aqui só entra a resposta. Dois portões seriam duas leituras
	 * do mesmo cookie podendo discordar dentro da mesma requisição.
	 *
	 * @param array<string,mixed> $dados        Campos validados do lead.
	 * @param string              $record_id    Identificador nascido no servidor.
	 * @param string              $ip           Origem medida da requisição.
	 * @param bool                $consentido   O consentimento medido permite tags?
	 * @return array{agendado:bool,motivo:string}
	 */
	public static function agendar( array $dados, string $record_id, string $ip, bool $consentido = false ): array {
		if ( ! $consentido ) {
			return array(
				'agendado' => false,
				'motivo'   => __( 'N/A: o consentimento medido nesta requisição não permite tags de terceiro, e o payload da Conversions API leva e-mail, telefone, endereço IP e os cookies da Meta. O lead continua gravado.', 'f3base' ),
			);
		}

		if ( '' === self::token() ) {
			return array(
				'agendado' => false,
				'motivo'   => sprintf(
					/* translators: %s: nome da option do token. */
					__( 'N/A: %s está vazia e nenhum evento de servidor é enviado.', 'f3base' ),
					self::OPTION_TOKEN
				),
			);
		}

		if ( '' === self::pixel_id() ) {
			return array(
				'agendado' => false,
				'motivo'   => __( 'N/A: há token e f3base_meta_pixel_id está vazia — o endpoint é /<pixel-id>/events e não existe destino.', 'f3base' ),
			);
		}

		$agente  = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_USER_AGENT'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$caminho = (string) ( $dados['pagina'] ?? '' );
		$url     = '' === $caminho ? '' : home_url( $caminho );

		$payload = self::montar_payload( $dados, $ip, $agente, $url, time() );

		$decisao = F3Base_Modulo_Consentimento::referencia_confirmada();
		if ( ! F3Base_Modulo_Consentimento::modo_granular() ) {
			$decisao['politica_versao'] = 'legado:' . F3Base_Modulo_Consentimento::politica_versao(); }
		if ( ! F3Base_Capi_Fila::inserir( $record_id, $payload, self::ttl_do_payload(), self::pixel_id(), $decisao ) ) {
			self::registrar_falha( $record_id, 0, 'Fila de conversões indisponível ou no limite; lead local preservado.' );
			return array(
				'agendado' => false,
				'motivo'   => 'Não foi possível persistir a conversão na fila; lead local preservado.',
			);
		}
		$agendado = (bool) wp_next_scheduled( self::HOOK, array( $record_id ) ) || true === wp_schedule_single_event( time() + 1, self::HOOK, array( $record_id ) );
		F3Base_Capi_Fila::planejar();
		return array(
			'agendado'   => (bool) $agendado,
			'persistido' => true,
			'motivo'     => $agendado ? 'Conversão persistida e agendada com o mesmo event_id do navegador.' : 'Conversão persistida; a rotina de recuperação tentará agendar novamente.',
		);
	}

	/**
	 * Prazo do transiente que carrega o payload.
	 *
	 * @return int
	 */
	public static function ttl_do_payload(): int {
		$ttl = (int) apply_filters( 'f3base_meta_capi_payload_ttl', HOUR_IN_SECONDS );

		return max( 5 * MINUTE_IN_SECONDS, min( DAY_IN_SECONDS, $ttl ) );
	}

	/**
	 * Executa o envio agendado.
	 *
	 * @param string $record_id Identificador do lead.
	 * @return void
	 */
	public function enviar_agendado( $record_id = '' ): void {
		self::enviar( is_string( $record_id ) ? $record_id : '' );
	}

	/**
	 * Envia o payload guardado e REGISTRA o resultado, nos dois ramos.
	 *
	 * @param string $record_id Identificador do lead.
	 * @return array{ok:bool,http:int,motivo:string}
	 */
	public static function enviar( string $record_id, int $limite_timeout = 30 ): array {
		if ( ! F3Base_Capi_Fila::instalar() ) {
			return self::registrar_falha( $record_id, 0, 'Schema da fila indisponível; consumidor suspenso.' ); }
		// Transientes legados só entram com o prazo original verificável e sem destino inventado.
		if ( ! F3Base_Capi_Fila::ler( $record_id ) ) {
			$anterior = get_transient( self::TRANSIENTE . $record_id );
			$expira   = (int) get_option( '_transient_timeout_' . self::TRANSIENTE . $record_id, 0 );
			if ( is_array( $anterior ) && $expira > time() ) {
				if ( F3Base_Capi_Fila::inserir( $record_id, $anterior, $expira - time() ) ) {
					delete_transient( self::TRANSIENTE . $record_id ); }
			} elseif ( is_array( $anterior ) ) {
				// Cache externo não informa TTL: não prolongar uma autorização desconhecida.
				F3Base_Capi_Fila::cancelar( $record_id );
				F3Base_Capi_Fila::limpar_cancelado( $record_id );
			}
		}
		$r = F3Base_Capi_Fila::reservar( $record_id );
		if ( ! $r ) {
			$estado = F3Base_Capi_Fila::ler( $record_id );
			if ( ! $estado ) {
				return self::registrar_falha( $record_id, 0, 'Payload ausente ou expirado; lead local preservado.' ); }
			return array(
				'ok'                     => 'entregue' === $estado['estado'],
				'http'                   => (int) $estado['http'],
				'local_confirmado'       => true,
				'persisted'              => true,
				'entrega'                => 'entregue' === $estado['estado'] ? 'aceita' : ( 'incerto' === $estado['estado'] ? 'incerta' : 'nao_iniciada' ),
				'reconciliacao_pendente' => 'incerto' === $estado['estado'],
				'codigo'                 => '' !== $estado['motivo'] ? $estado['motivo'] : $estado['estado'],
				'motivo'                 => 'Estado da conversão: ' . $estado['estado'] . '. Nenhum envio adicional realizado.',
			);
		}
		$payload = json_decode( $r['payload'], true );
		if ( ! is_array( $payload ) ) {
			F3Base_Capi_Fila::cancelar( $record_id );
			return self::registrar_falha( $record_id, 0, 'Payload inválido; envio cancelado.' );
		}
		$inicio = F3Base_Capi_Fila::iniciar_envio( $r );
		if ( empty( $inicio['ok'] ) ) {
			return array(
				'ok'                     => false,
				'http'                   => 0,
				'entrega'                => 'nao_iniciada',
				'local_confirmado'       => ! in_array( $inicio['codigo'], array( 'banco_indisponivel', 'confirmacao_falhou' ), true ),
				'codigo'                 => $inicio['codigo'],
				'motivo'                 => 'Envio não iniciado: ' . $inicio['codigo'],
				'reconciliacao_pendente' => false,
			);
		}
		$r = $inicio['registro'];
		if ( ! is_array( $r ) ) {
			return self::registrar_falha( $record_id, 0, 'Reserva não pôde ser relida; reconciliação pendente.' ); }
		$endereco = self::HOST . self::versao_graph() . '/' . rawurlencode( $r['pixel_id'] ) . '/events';
		try {
			$resposta = wp_remote_post(
				$endereco,
				array(
					'timeout'             => min( max( 1, $limite_timeout ), 30, max( 1, (int) apply_filters( 'f3base_meta_capi_timeout', 10 ) ) ),
					'redirection'         => 0,
					'limit_response_size' => 65536,
					'headers'             => array( 'Content-Type' => 'application/json; charset=utf-8' ),
					'body'                => (string) wp_json_encode( array_merge( $payload, array( 'access_token' => self::token() ) ) ),
				)
			);
		} catch ( Throwable $erro ) {
			$resposta = new WP_Error( 'f3base_transporte', 'Envio interrompido.' ); }
		if ( is_wp_error( $resposta ) ) {
			$conclusao = F3Base_Capi_Fila::concluir( $r, 0, false, true );
			self::registrar_falha( $record_id, 0, 'Falha de transporte; aceitação externa desconhecida.' );
			$conclusao['motivo'] = 'Falha de transporte; aceitação externa desconhecida.';
			return $conclusao;
		}
		$http       = (int) wp_remote_retrieve_response_code( $resposta );
		$body       = json_decode( (string) wp_remote_retrieve_body( $resposta ), true );
		$aceito     = $http >= 200 && $http < 300 && is_array( $body ) && (int) ( $body['events_received'] ?? 0 ) > 0;
		$temporario = in_array( $http, array( 408, 425, 429 ), true ) || $http >= 500 || ( $http >= 200 && $http < 300 ) || ! empty( $body['error']['is_transient'] );
		$retry      = (string) wp_remote_retrieve_header( $resposta, 'retry-after' );
		$espera     = ctype_digit( $retry ) ? (int) $retry : max( 0, (int) strtotime( $retry ) - time() );
		$conclusao  = F3Base_Capi_Fila::concluir( $r, $http, $aceito, $temporario, min( DAY_IN_SECONDS, $espera ) );
		$trace      = substr( sanitize_text_field( (string) ( $body['fbtrace_id'] ?? ( $body['error']['fbtrace_id'] ?? '' ) ) ), 0, 120 );
		if ( ! $aceito ) {
			self::registrar_falha( $record_id, $http, $temporario ? 'Entrega não confirmada; consulte a próxima tentativa da fila.' : 'Recusa permanente do fornecedor.', $trace ); } else {
			F3Base_Atividade::registrar(
				F3Base_Atividade::ULTIMO_CAPI,
				array(
					'record_id'        => $record_id,
					'http'             => $http,
					'events_received'  => (int) $body['events_received'],
					'fbtrace_id'       => $trace,
					'local_confirmado' => $conclusao['local_confirmado'],
				)
			); }
			$conclusao['motivo'] = ! $conclusao['local_confirmado'] ? 'Resultado externo observado; confirmação local falhou. Reconciliar antes de reenviar.' : ( $aceito ? '' : 'Fornecedor não confirmou entrega.' );
			return $conclusao;
	}

	/**
	 * Registra a recusa NOMEADA — e não toca no lead.
	 *
	 * O ramo adverso tem carimbo próprio pelo mesmo motivo que o do endpoint de
	 * leads tem: recusa que some da tela é indistinguível de recusa que nunca
	 * aconteceu. E ele NÃO altera nada do lead: o lead foi gravado antes de o
	 * envio ser agendado, a resposta ao visitante já foi dada, e a Meta não tem
	 * voto sobre isso.
	 *
	 * @param string $record_id Identificador do lead.
	 * @param int    $http      Código HTTP observado, ou zero quando não houve resposta.
	 * @param string $motivo    Motivo legível.
	 * @param string $fbtrace   Identificador de rastreio da Meta, quando houver.
	 * @return array{ok:bool,http:int,motivo:string}
	 */
	private static function registrar_falha( string $record_id, int $http, string $motivo, string $fbtrace = '' ): array {
		F3Base_Atividade::registrar(
			F3Base_Atividade::ULTIMA_FALHA_CAPI,
			array(
				'record_id'  => $record_id,
				'http'       => $http,
				'fbtrace_id' => $fbtrace,
				'motivo'     => $motivo,
			)
		);

		return array(
			'ok'     => false,
			'http'   => $http,
			'motivo' => $motivo,
		);
	}
}
