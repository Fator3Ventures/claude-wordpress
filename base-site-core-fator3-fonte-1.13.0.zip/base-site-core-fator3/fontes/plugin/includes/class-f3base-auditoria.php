<?php
/** Evidência de procedência, sem inferir autoria e sem efeitos de leitura. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Auditoria {
	public static function classificar( array $foto, $entrada, bool $erro, array $pendentes, ?bool $hash_compativel = null ): array {
		$codigo    = 'registro_ausente';
		$vinculo   = 'indeterminado';
		$evidencia = 'ausente';
		$acao      = 'revisar';
		$motivo    = 'A option existe, mas não há registro de sua origem.';
		if ( $foto['erro'] || $erro ) {
			$codigo = 'leitura_indisponivel';
			$motivo = 'Não foi possível ler a configuração ou sua auditoria.';
		} elseif ( null === $entrada && ! $foto['existe'] ) {
			$codigo = 'padrao_embutido';
			$motivo = 'Option ausente: valor de fábrica, sem gravação atribuída.';
			$acao   = 'nenhuma';
		} elseif ( null !== $entrada ) {
			if ( ! is_array( $entrada ) || ! in_array( $entrada['origem'] ?? '', array( 'implantador', 'edicao-manual', 'padrao' ), true ) ) {
				$codigo = 'registro_invalido';
				$motivo = 'Registro histórico não reconhecido; nenhuma autoria foi inferida.';
			} elseif ( is_string( $entrada['revisao'] ?? null ) && '' !== $entrada['revisao'] ) {
				if ( hash_equals( $foto['revisao'], $entrada['revisao'] ) ) {
					$codigo    = ! $foto['existe'] && 'remover' === ( $entrada['operacao'] ?? '' ) ? 'exclusao_registrada' : 'revisao_confirmada';
					$motivo    = 'Registro vinculado à revisão atual.';
					$vinculo   = 'confirmado';
					$evidencia = 'revisao';
					$acao      = 'nenhuma';
				} else {
					$codigo    = 'revisao_divergente';
					$motivo    = 'A revisão difere. Mudança do valor ou da chave HMAC são possibilidades; isto não comprova edição externa.';
					$vinculo   = 'divergente';
					$evidencia = 'revisao';
				}
			} else {
				$codigo    = 'legado_sem_vinculo';
				$motivo    = 'Origem histórica preservada; falta uma revisão que vincule o registro ao valor atual.';
				$evidencia = 'historica';
				// Única representação reconhecida: SHA-256 do JSON ordenado recursivamente.
				if ( null !== $hash_compativel ) {
					$compativel = $hash_compativel;
					$codigo     = $compativel ? 'legado_hash_compativel' : 'legado_hash_divergente';
					$vinculo    = $compativel ? 'compativel' : 'divergente';
					$evidencia  = 'hash_legado';
					$motivo     = $compativel ? 'Valor compatível com o hash histórico conhecido; origem atual permanece não confirmada.' : 'Valor incompatível com o hash histórico conhecido; revisar sem atribuir autoria.';
				}
			}
		}
		if ( ! $foto['erro'] && 'confirmado' !== $vinculo && ! $pendentes['erro'] && is_array( $pendentes['valor'] ) ) {
			foreach ( $pendentes['valor'] as $p ) {
				if ( is_array( $p ) && hash_equals( $foto['revisao'], (string) ( $p['revisao'] ?? '' ) ) ) {
					$codigo    = 'persistencia_sem_auditoria';
					$motivo    = 'Persistência confirmada, mas a gravação da auditoria falhou nesta revisão.';
					$evidencia = 'tentativa_operacional';
					break;
				}
			}
		}
		return array(
			'codigo'           => $codigo,
			'motivo'           => $motivo,
			'evidencia'        => $evidencia,
			'vinculo_valor'    => $vinculo,
			'acao_recomendada' => $acao,
			'consultado_em'    => time(),
		);
	}
	public static function ordenar( $valor ) {
		if ( ! is_array( $valor ) ) {
			return $valor; }
		if ( ! array_is_list( $valor ) ) {
			ksort( $valor ); }
		return array_map( array( __CLASS__, 'ordenar' ), $valor );
	}
	public static function rotulo( array $p ): string {
		$historico = $p['origem_registrada'] ? 'Origem registrada: ' . $p['origem_registrada'] . ( $p['em'] ? ' em ' . wp_date( 'd/m/Y H:i', $p['em'] ) : '' ) . '. ' : '';
		return $historico . $p['motivo'];
	}
	public static function resumo(): array {
		$r = array(
			'informativas'         => 0,
			'revisar'              => 0,
			'leitura_indisponivel' => 0,
			'itens'                => array(),
		);
		foreach ( F3Base_Options::nomes() as $nome ) {
			if ( in_array( $nome, F3Base_Options::estado_de_execucao(), true ) ) {
				continue; }
			$p     = F3Base_Options::procedencia( $nome );
			$grupo = 'leitura_indisponivel' === $p['codigo'] ? 'leitura_indisponivel' : ( 'nenhuma' === $p['acao_recomendada'] || ( str_starts_with( $p['codigo'], 'legado_' ) && 'divergente' !== $p['vinculo_valor'] ) ? 'informativas' : 'revisar' );
			++$r[ $grupo ];
			$r['itens'][ $nome ] = $p;
		}
		return $r;
	}
}
