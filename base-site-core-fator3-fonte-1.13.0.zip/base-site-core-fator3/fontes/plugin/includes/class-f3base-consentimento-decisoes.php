<?php
/** Decisões granulares mínimas. Comprovante só existe no navegador; banco guarda seu hash. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Consentimento_Decisoes {
	public const TABELA = 'f3base_consentimento_decisoes';
	public const ROTA   = '/consentimento';

	public static function instalar(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$tabela = $wpdb->prefix . self::TABELA;
		dbDelta(
			"CREATE TABLE {$tabela} (
			ref varchar(64) NOT NULL,
			politica_versao varchar(64) NOT NULL,
			medicao tinyint NOT NULL DEFAULT 0,
			publicidade tinyint NOT NULL DEFAULT 0,
			revogada tinyint NOT NULL DEFAULT 0,
			expira_em bigint NOT NULL,
			PRIMARY KEY  (ref),
			KEY expira_em (expira_em)
		) {$wpdb->get_charset_collate()};"
		);
	}

	public static function registrar_rota(): void {
		register_rest_route(
			F3BASE_REST_NAMESPACE,
			self::ROTA,
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( self::class, 'receber' ),
			)
		);
	}

	public static function referencia( string $comprovante ): string {
		return preg_match( '/^[a-f0-9]{64}$/D', $comprovante ) ? hash( 'sha256', $comprovante ) : '';
	}

	/** Leitura sem cache: revogação confirmada precisa valer na reserva seguinte. */
	public static function permite( string $ref, string $versao, string $categoria ): bool {
		global $wpdb;
		if ( ! in_array( $categoria, array( 'medicao', 'publicidade' ), true ) || ! preg_match( '/^[a-f0-9]{64}$/D', $ref ) ) {
			return false; }
		if ( ! F3Base_Modulo_Consentimento::modo_granular() || F3Base_Modulo_Consentimento::politica_versao() !== $versao ) {
			return false; }
		$tabela   = $wpdb->prefix . self::TABELA;
		$registro = $wpdb->get_row( $wpdb->prepare( 'SELECT politica_versao,medicao,publicidade,revogada,expira_em FROM %i WHERE ref = %s', $tabela, $ref ), ARRAY_A );
		return is_array( $registro ) && $versao === $registro['politica_versao'] && empty( $registro['revogada'] ) && (int) $registro['expira_em'] > time() && 1 === (int) $registro[ $categoria ];
	}

	public static function permite_capi( string $ref, string $versao ): bool {
		if ( '' === $ref ) {
			return ! F3Base_Modulo_Consentimento::modo_granular() && hash_equals( 'legado:' . F3Base_Modulo_Consentimento::politica_versao(), $versao ); }
		return self::permite( $ref, $versao, 'publicidade' );
	}

	private static function resposta( int $status, array $dados ): WP_REST_Response {
		return new WP_REST_Response(
			$dados,
			$status,
			array(
				'Cache-Control' => 'no-store, private',
				'Vary'          => 'Origin',
			)
		);
	}

	private static function origem_valida( WP_REST_Request $request ): bool {
		if ( '1' !== $request->get_header( 'x-f3base-consentimento' ) ) {
			return false; }
		$origem = $request->get_header( 'origin' );
		if ( '' === $origem ) {
			$origem = $request->get_header( 'referer' ); }
		$origem = wp_parse_url( $origem );
		$site   = wp_parse_url( home_url( '/' ) );
		return is_array( $origem ) && is_array( $site ) && isset( $origem['host'], $origem['scheme'] ) &&
			strtolower( $origem['host'] ) === strtolower( $site['host'] ) && $origem['scheme'] === $site['scheme'] &&
			( $origem['port'] ?? ( 'https' === $origem['scheme'] ? 443 : 80 ) ) === ( $site['port'] ?? ( 'https' === $site['scheme'] ? 443 : 80 ) );
	}

	public static function receber( WP_REST_Request $request ): WP_REST_Response {
		global $wpdb;
		if ( ! self::origem_valida( $request ) ) {
			return self::resposta(
				403,
				array(
					'ok'        => false,
					'persisted' => false,
					'codigo'    => 'origem_recusada',
				)
			); }
		if ( strlen( $request->get_body() ) > 2048 ) {
			return self::resposta(
				413,
				array(
					'ok'        => false,
					'persisted' => false,
					'codigo'    => 'corpo_excedido',
				)
			); }
		$dados = $request->get_json_params();
		if ( ! is_array( $dados ) || ! isset( $dados['medicao'], $dados['publicidade'], $dados['politica_versao'] ) ||
			! is_bool( $dados['medicao'] ) || ! is_bool( $dados['publicidade'] ) || ! is_string( $dados['politica_versao'] ) ||
			( isset( $dados['comprovante_anterior'] ) && ! is_string( $dados['comprovante_anterior'] ) ) ) {
			return self::resposta(
				400,
				array(
					'ok'        => false,
					'persisted' => false,
					'codigo'    => 'decisao_invalida',
				)
			);
		}
		$ref       = self::referencia( (string) ( $dados['comprovante_anterior'] ?? '' ) );
		$tabela    = $wpdb->prefix . self::TABELA;
		$revogacao = array(
			'persisted'     => true,
			'cancelados'    => 0,
			'http_iniciado' => 0,
		);
		if ( '' !== $ref ) {
			$persistir = static function () use ( $wpdb, $tabela, $ref ): bool {
				$limite  = time() + DAY_IN_SECONDS;
				$gravado = $wpdb->query( $wpdb->prepare( 'UPDATE %i SET revogada=1,expira_em=CASE WHEN expira_em>%d THEN %d ELSE expira_em END WHERE ref=%s', $tabela, $limite, $limite, $ref ) );
				return false !== $gravado;
			};
			$revogacao = class_exists( 'F3Base_Capi_Fila' ) && method_exists( 'F3Base_Capi_Fila', 'revogar_decisao' )
				? F3Base_Capi_Fila::revogar_decisao( $ref, $persistir )
				: array(
					'persisted'     => $persistir(),
					'cancelados'    => 0,
					'http_iniciado' => 0,
				);
			if ( empty( $revogacao['persisted'] ) ) {
				return self::resposta(
					503,
					array(
						'ok'        => false,
						'persisted' => false,
						'codigo'    => 'revogacao_pendente',
					)
				); }
		}
		// Revogar comprovante antigo continua permitido após mudança de versão/modo.
		if ( ! F3Base_Modulo_Consentimento::modo_granular() || F3Base_Modulo_Consentimento::politica_versao() !== $dados['politica_versao'] ) {
			return self::resposta(
				409,
				array(
					'ok'                   => false,
					'persisted'            => false,
					'revogacao_confirmada' => '' !== $ref,
					'codigo'               => 'politica_alterada',
				)
			);
		}
		$comprovante = '';
		if ( $dados['medicao'] || $dados['publicidade'] ) {
			if ( ! F3Base_Modulo_Endpoint_Leads::dentro_do_limite_token() ) {
				return self::resposta(
					429,
					array(
						'ok'                   => false,
						'persisted'            => false,
						'revogacao_confirmada' => '' !== $ref,
						'codigo'               => 'limite_decisoes',
					)
				); }
			$comprovante = bin2hex( random_bytes( 32 ) );
			$config      = F3Base_Options::ler( 'f3base_consentimento' );
			$ttl         = max( 1, min( 3650, (int) ( $config['ttl_dias'] ?? 180 ) ) ) * DAY_IN_SECONDS;
			$gravado     = $wpdb->insert(
				$tabela,
				array(
					'ref'             => self::referencia( $comprovante ),
					'politica_versao' => $dados['politica_versao'],
					'medicao'         => (int) $dados['medicao'],
					'publicidade'     => (int) $dados['publicidade'],
					'revogada'        => 0,
					'expira_em'       => time() + $ttl,
				),
				array( '%s', '%s', '%d', '%d', '%d', '%d' )
			);
			if ( false === $gravado ) {
				return self::resposta(
					503,
					array(
						'ok'        => false,
						'persisted' => false,
						'codigo'    => 'persistencia_falhou',
					)
				); }
		}
		return self::resposta(
			200,
			array(
				'ok'                   => true,
				'persisted'            => true,
				'comprovante'          => $comprovante,
				'politica_versao'      => $dados['politica_versao'],
				'revogacao_confirmada' => '' !== $ref,
				'cancelados'           => (int) ( $revogacao['cancelados'] ?? 0 ),
				'http_iniciado'        => (int) ( $revogacao['http_iniciado'] ?? 0 ),
			)
		);
	}

	/** Marcadores expirados não autorizam filas; excluídos em lotes limitados pelo executor diário. */
	public static function expurgar(): int {
		global $wpdb;
		$tabela = $wpdb->prefix . self::TABELA;
		$refs   = $wpdb->get_col( $wpdb->prepare( 'SELECT ref FROM %i WHERE expira_em < %d ORDER BY expira_em LIMIT 500', $tabela, time() ) );
		$total  = 0;
		foreach ( $refs as $ref ) {
			$total += (int) $wpdb->delete( $tabela, array( 'ref' => $ref ), array( '%s' ) ); }
		return $total;
	}
}
