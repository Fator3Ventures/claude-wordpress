<?php
/** Cached conversion status per public item; unavailable Markdown falls back to HTML. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Llms_Cobertura {
	const EVENTO = 'f3base_llms_converter_lote';
	public static function iniciar(): void {
		add_action( self::EVENTO, array( __CLASS__, 'lote' ), 10, 1 );
		add_action( 'save_post', array( __CLASS__, 'agendar' ), 200 );
		add_action(
			'updated_option',
			static function ( $n ): void {
				if ( in_array( $n, array( 'f3base_llms', 'permalink_structure', 'blog_public' ), true ) ) {
					self::agendar();
				} },
			200
		);
		add_action( 'init', array( __CLASS__, 'agendar' ), 99 );
	}
	public static function chave( array $i ): string {
		return 'f3base_llms_item_' . hash( 'sha256', wp_json_encode( array( F3BASE_PLUGIN_VERSAO, $i['id'] ?? 0, $i['url'] ?? '', $i['conteudo'] ?? '', get_transient( F3Base_Modulo_Cache_Publico::GERACAO ), F3Base_Options::ler( 'f3base_llms' )['blocos_interface'] ?? array() ) ) ); }
	public static function item( array $i, bool $converter = false ): array {
		$id = (int) ( $i['id'] ?? 0 );
		$p  = $id ? get_post( $id ) : null;
		if ( $p && ( ! is_post_publicly_viewable( $p ) || $p->post_password || F3Base_Modulo_Noindex_Honrado::post_e_noindex( $id ) ) ) {
			return array(
				'completo' => false,
				'erros'    => array( 'conteudo_nao_publico' ),
				'texto'    => '',
			); }
		$key = self::chave( $i );
		$r   = get_transient( $key );
		if ( is_array( $r ) ) {
			return $r; }
		if ( ! $converter ) {
			return array(
				'completo' => false,
				'pendente' => true,
				'erros'    => array(),
				'texto'    => '',
			); }
		$r            = F3Base_Llms_Conversor::converter( (string) ( $i['conteudo'] ?? '' ), (string) ( $i['url'] ?? '' ), 3 );
		$r['revisao'] = hash( 'sha256', $key );
		$r['em']      = time();
		set_transient( $key, $r, DAY_IN_SECONDS );
		return $r;
	}
	public static function disponiveis( array $itens ): array {
		return array_values( array_filter( $itens, static fn( $i )=> ! empty( self::item( $i )['completo'] ) ) ); }
	public static function resumo( array $itens ): array {
		$lista = array();
		$ok    = 0;
		foreach ( $itens as $i ) {
			$r       = self::item( $i );
			$ok     += ! empty( $r['completo'] ) ? 1 : 0;
			$lista[] = array(
				'id'      => $i['id'] ?? 0,
				'url'     => $i['url'] ?? '',
				'estado'  => ! empty( $r['completo'] ) ? 'disponivel' : ( ! empty( $r['pendente'] ) ? 'pendente' : 'incompleta' ),
				'erros'   => $r['erros'] ?? array(),
				'revisao' => $r['revisao'] ?? null,
			); }
		return array(
			'total'       => count( $itens ),
			'disponiveis' => $ok,
			'parcial'     => $ok < count( $itens ),
			'itens'       => $lista,
		);
	}
	public static function agendar(): void {
		$c = F3Base_Options::ler( 'f3base_llms' );
		if ( empty( $c['ligado'] ) || ( empty( $c['markdown'] ) && empty( $c['full'] ) ) ) {
			return; }
		$atual = hash( 'sha256', F3Base_Modulo_Cache_Publico::geracao() . F3Base_Options::revisao( 'f3base_llms' ) . F3BASE_PLUGIN_VERSAO );
		if ( get_transient( 'f3base_llms_lote_pronto' ) === $atual ) {
			return; }
		if ( ! wp_next_scheduled( self::EVENTO, array( 0 ) ) ) {
			wp_schedule_single_event( time() + 60, self::EVENTO, array( 0 ) ); }
	}
	public static function lote( int $offset = 0 ): void {
		$c = F3Base_Options::ler( 'f3base_llms' );
		if ( empty( $c['ligado'] ) ) {
			return; }
		$itens = F3Base_Modulo_Llms_Txt_Reserva::selecao( $c );
		foreach ( array_slice( $itens, $offset, 10 ) as $i ) {
			self::item( $i, true ); }
		if ( $offset + 10 < count( $itens ) ) {
			wp_schedule_single_event( time() + 10, self::EVENTO, array( $offset + 10 ) ); }
		if ( $offset + 10 >= count( $itens ) ) {
			set_transient( 'f3base_llms_lote_pronto', hash( 'sha256', F3Base_Modulo_Cache_Publico::geracao() . F3Base_Options::revisao( 'f3base_llms' ) . F3BASE_PLUGIN_VERSAO ), HOUR_IN_SECONDS ); }
		// Invalidate aggregate/index snapshots after status becomes available without invalidating per-item keys.
		if ( $offset + 10 >= count( $itens ) && 'arquivo_gerado' === ( $c['entrega'] ?? '' ) ) {
			F3Base_Llms_Arquivo::gerar(); }
	}
}
