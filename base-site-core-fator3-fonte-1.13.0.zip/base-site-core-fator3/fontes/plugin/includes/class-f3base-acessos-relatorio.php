<?php
/** Projeção comum à tela, atualização e CSV. Só resolve conteúdo dos caminhos observados. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Acessos_Relatorio {
	public const MAX_GRUPOS = 10000;
	public const MAX_LINHAS = 300;
	public static function classe( string $caminho, string $classe, int $status ): string {
		if ( in_array( $status, array( 404, 410 ), true ) ) {
			return 'inexistentes'; }
		$raiz = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $raiz && rtrim( $caminho, '/' ) !== $raiz && ! str_starts_with( $caminho, $raiz . '/' ) ) {
			return 'outros';
		}
		if ( 'api' === $classe ) {
			return 'apis'; }
		if ( preg_match( '~/(?:robots\.txt|llms(?:-full)?\.txt|[^/]*sitemap[^/]*\.xml(?:\.gz)?)/?$~i', $caminho ) ) {
			return 'descoberta'; }
		if ( preg_match( '~/(?:feed|rdf|rss|rss2|atom)/?$~i', $caminho ) ) {
			return 'feeds'; }
		if ( 'pagina' !== $classe || '' === $caminho ) {
			return 'outros'; }
		static $cache = array();
		$cachekey     = (string) get_transient( F3Base_Modulo_Cache_Publico::GERACAO ) . '|' . get_option( 'permalink_structure' ) . '|' . home_url() . '|' . $caminho;
		if ( ! isset( $cache[ $cachekey ] ) ) {
			$base = wp_parse_url( home_url() );
			$url  = $base['scheme'] . '://' . $base['host'] . ( isset( $base['port'] ) ? ':' . $base['port'] : '' ) . $caminho;
			// O resolvedor continua sendo o WordPress; apenas dispensamos caches que a classificação não lê.
			$sem_priming = static function ( WP_Query $consulta ): void {
				$consulta->set( 'update_post_meta_cache', false );
				$consulta->set( 'update_post_term_cache', false );
			};
			add_action( 'pre_get_posts', $sem_priming, PHP_INT_MAX );
			try {
				$id = url_to_postid( $url );
			} finally {
				remove_action( 'pre_get_posts', $sem_priming, PHP_INT_MAX );
			}
			$home               = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
			$home               = '' === $home ? '/' : $home;
			$cache[ $cachekey ] = ( ( '' === rtrim( $caminho, '/' ) ? '/' : rtrim( $caminho, '/' ) ) === $home || ( $id && in_array( get_post_type( $id ), array( 'page', 'post' ), true ) && 'publish' === get_post_status( $id ) ) ) ? 'paginas' : 'outros';
		}
		return $cache[ $cachekey ];
	}
	private static function permitido( string $classificacao, string $modo ): bool {
		return 'todos' === $modo || $classificacao === $modo || ( 'conteudo' === $modo && in_array( $classificacao, array( 'paginas', 'descoberta' ), true ) ); }
	private static function historico( string $inicio, string $fim, bool $erros ): array {
		global $wpdb;
		if ( ! F3Base_Modulo_Acessos_Servidor::tabela_pronta() ) {
			return array(
				'linhas' => array(),
				'corte'  => false,
			); }
		$t    = $wpdb->prefix . F3Base_Modulo_Acessos_Servidor::TABELA;
		$w    = $wpdb->prepare( 'dia >= %s AND dia <= %s AND status BETWEEN 200 AND %d', $inicio, $fim, $erros ? 599 : 399 );
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT dia,caminho,classe_caminho,agente,status,SUM(contagem) AS contagem FROM {$t} WHERE {$w} GROUP BY dia,caminho,classe_caminho,agente,status ORDER BY dia,caminho,classe_caminho,agente,status LIMIT %d", self::MAX_GRUPOS + 1 ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
		return array(
			'linhas' => array_slice( $rows, 0, self::MAX_GRUPOS ),
			'corte'  => count( $rows ) > self::MAX_GRUPOS,
		);
	}
	private static function agrupar( array $rows, string $modo ): array {
		$mapa = array();
		foreach ( $rows as $l ) {
			$classe = self::classe( $l['caminho'], $l['classe_caminho'], (int) $l['status'] );
			if ( ! self::permitido( $classe, $modo ) ) {
				continue; }
			$k = $l['caminho'] . '|' . $classe;
			if ( ! isset( $mapa[ $k ] ) ) {
				$mapa[ $k ] = array(
					'caminho'       => $l['caminho'],
					'classificacao' => $classe,
					'total'         => 0,
					'humano'        => 0,
					'busca'         => 0,
					'treino-ia'     => 0,
					'resposta-ia'   => 0,
					'proprio'       => 0,
					'hospedagem'    => 0,
					'outros'        => 0,
				); }
			$a = F3Base_Modulo_Acessos_Servidor::classe_agente( $l['agente'] );
			if ( ! array_key_exists( $a, $mapa[ $k ] ) ) {
				$a = 'outros'; }
			$mapa[ $k ][ $a ]    += (int) $l['contagem'];
			$mapa[ $k ]['total'] += (int) $l['contagem'];
		}
		uasort(
			$mapa,
			static function ( $a, $b ): int {
				foreach ( array( $b['humano'] <=> $a['humano'], $b['total'] <=> $a['total'], strcmp( $a['caminho'], $b['caminho'] ), strcmp( $a['classificacao'], $b['classificacao'] ) ) as $ordem ) {
					if ( 0 !== $ordem ) {
						return $ordem;
					}
				} return 0;
			}
		);
		return $mapa;
	}
	public static function consultar( int $dias, string $modo, bool $erros, ?array $hoje = null, bool $comparacao_hoje = false ): array {
		$j         = F3Base_Medicao_Consultas::janela( $dias );
		$historico = self::historico( $j['inicio'], F3Base_Modulo_Acessos_Servidor::dia_anterior(), $erros );
		$rows      = $historico['linhas'];
		foreach ( $hoje['linhas'] ?? array() as $l ) {
			if ( (int) $l['status'] <= ( $erros ? 599 : 399 ) && (int) $l['status'] >= 200 ) {
				$l['dia'] = wp_date( 'Y-m-d' );
				$rows[]   = $l; }
		}
		$mapa  = self::agrupar( $rows, $modo );
		$total = count( $mapa );
		$r     = array(
			'inicio'                    => $j['inicio'],
			'fim'                       => $j['fim'],
			'fuso'                      => wp_timezone_string(),
			'regra'                     => F3Base_Modulo_Acessos_Servidor::config_hash(),
			'extraido_em'               => time(),
			'classificacao'             => $modo,
			'incluir_erros'             => $erros,
			'linhas'                    => array_values( array_slice( $mapa, 0, self::MAX_LINHAS, true ) ),
			'corte'                     => $historico['corte'] || $total > self::MAX_LINHAS,
			'total_caminhos_observados' => $total,
			'limite'                    => self::MAX_LINHAS,
			'cobertura'                 => F3Base_Acessos_Coleta::cobertura( $j['inicio'], $j['fim'] ),
			'hoje'                      => $hoje ? $hoje : array(
				'erro'            => 'Hoje ainda não atualizado; clique Atualizar.',
				'atualizado'      => 0,
				'bytes_pendentes' => 0,
				'linhas'          => array(),
			),
		);
		global $wpdb;
		if ( $r['linhas'] && F3Base_Modulo_Comportamento::eventos_prontos() ) {
			$paths     = array_values( array_unique( array_column( $r['linhas'], 'caminho' ) ) );
			$in        = implode( ',', array_fill( 0, count( $paths ), '%s' ) );
			$t         = $wpdb->prefix . F3Base_Modulo_Comportamento::TABELA_EVENTOS;
			$contagens = (array) $wpdb->get_results( $wpdb->prepare( "SELECT caminho,COUNT(DISTINCT NULLIF(visitante,'')) AS pessoas FROM {$t} WHERE criado_em >= %d AND criado_em < %d AND caminho IN ({$in}) GROUP BY caminho", array_merge( array( $j['inicio_utc'], $j['fim_utc'] ), $paths ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- Identificadores e fragmentos SQL vêm de listas internas; valores e listas usam placeholders preparados.
			$pessoas   = array_column( $contagens, 'pessoas', 'caminho' );
			foreach ( $r['linhas'] as &$l ) {
				$l['pessoas_medidas'] = isset( $pessoas[ $l['caminho'] ] ) ? (int) $pessoas[ $l['caminho'] ] : null;
			} unset( $l );
		}
		$r['comparacao'] = self::comparar( $dias, $modo, $erros, $comparacao_hoje, $hoje );
		return $r;
	}
	/** Pareamento com regra/fuso compatíveis; hoje só entra por escolha explícita e fica parcial. */
	public static function comparar( int $dias, string $modo, bool $erros, bool $incluir_hoje = false, ?array $hoje = null ): array {
		$dias        = max( 1, min( F3Base_Medicao_Consultas::MAX_DIAS, $dias ) );
		$j           = F3Base_Medicao_Consultas::janela( $dias, $incluir_hoje );
		$hoje        = $incluir_hoje ? ( $hoje ?? F3Base_Acessos_Atuais::fotografia() ) : array();
		$dia_hoje    = wp_date( 'Y-m-d' );
		$valido_hoje = $incluir_hoje && ( $hoje['dia'] ?? '' ) === $dia_hoje && ! empty( $hoje['atualizado'] ) && empty( $hoje['erro'] ) && empty( $hoje['corte'] ) && wp_date( 'Y-m-d', (int) $hoje['atualizado'] ) === $dia_hoje && empty( $hoje['bytes_pendentes'] ) && empty( $hoje['ignoradas'] ) && ( $hoje['regra'] ?? '' ) === F3Base_Modulo_Acessos_Servidor::config_hash() && ( $hoje['fuso'] ?? '' ) === wp_timezone_string();
		$ini         = new DateTimeImmutable( $j['inicio'], wp_timezone() );
		$p_fim       = $ini->modify( '-1 day' )->format( 'Y-m-d' );
		$p_ini       = $ini->modify( '-' . $dias . ' days' )->format( 'Y-m-d' );
		$a           = F3Base_Acessos_Coleta::cobertura( $j['inicio'], $j['fim'] );
		$b           = F3Base_Acessos_Coleta::cobertura( $p_ini, $p_fim );
		$usados_a    = array();
		$usados_b    = array();
		$excluidos   = array();
		foreach ( $a as $i => $d ) {
			$p = $b[ $i ] ?? array();
			if ( $incluir_hoje && $d['dia'] === $dia_hoje ) {
				$d['estado'] = $valido_hoje ? 'completo' : 'fotografia_indisponivel_ou_incompleta';
				$d['regra']  = $hoje['regra'] ?? '';
				$d['fuso']   = $hoje['fuso'] ?? '';
			}
			if ( 'completo' === $d['estado'] && 'completo' === ( $p['estado'] ?? '' ) && $d['regra'] === $p['regra'] && $d['fuso'] === $p['fuso'] ) {
				$usados_a[] = $d['dia'];
				$usados_b[] = $p['dia'];
			} else {
				$excluidos[] = array(
					'atual'    => $d['dia'],
					'anterior' => $p['dia'] ?? '',
					'motivo'   => $d['estado'] . '/' . ( $p['estado'] ?? 'desconhecido' ),
				); }
		}
		$ra = self::historico( $j['inicio'], $incluir_hoje ? F3Base_Modulo_Acessos_Servidor::dia_anterior() : $j['fim'], $erros );
		if ( $valido_hoje && in_array( $dia_hoje, $usados_a, true ) ) {
			foreach ( $hoje['linhas'] ?? array() as $l ) {
				if ( (int) $l['status'] >= 200 && (int) $l['status'] <= ( $erros ? 599 : 399 ) ) {
					$l['dia']       = $dia_hoje;
					$ra['linhas'][] = $l;
				}
			}
		}
		$rb    = self::historico( $p_ini, $p_fim, $erros );
		$corte = $ra['corte'] || $rb['corte'] || count( $ra['linhas'] ) > self::MAX_GRUPOS;
		$aa    = self::agrupar( array_filter( $ra['linhas'], static fn( $l ) => in_array( $l['dia'], $usados_a, true ) ), $modo );
		$bb    = self::agrupar( array_filter( $rb['linhas'], static fn( $l ) => in_array( $l['dia'], $usados_b, true ) ), $modo );
		$saida = array();
		if ( $usados_a && ! $corte ) {
			foreach ( array_unique( array_merge( array_keys( $aa ), array_keys( $bb ) ) ) as $k ) {
				$v        = (int) ( $aa[ $k ]['total'] ?? 0 );
				$anterior = (int) ( $bb[ $k ]['total'] ?? 0 );
				$saida[]  = array(
					'caminho'   => ( $aa[ $k ] ?? $bb[ $k ] )['caminho'],
					'atual'     => $v,
					'anterior'  => $anterior,
					'diferenca' => $v - $anterior,
					'variacao'  => $anterior > 0 ? round( ( $v - $anterior ) / $anterior * 100, 2 ) : null,
					'base_zero' => 0 === $anterior,
				); }
		}
		return array(
			'inicio'          => $j['inicio'],
			'fim'             => $j['fim'],
			'anterior_inicio' => $p_ini,
			'anterior_fim'    => $p_fim,
			'dias_comparados' => count( $usados_a ),
			'pares_excluidos' => $excluidos,
			'linhas'          => array_slice( $saida, 0, self::MAX_LINHAS ),
			'corte'           => $corte || count( $saida ) > self::MAX_LINHAS,
			'hoje_incluido'   => $incluir_hoje,
			'hoje_comparado'  => in_array( $dia_hoje, $usados_a, true ),
			'periodo_parcial' => $incluir_hoje,
			'hoje_atualizado' => $incluir_hoje ? (int) ( $hoje['atualizado'] ?? 0 ) : 0,
		);
	}
	public static function celula_csv( $v ): string {
		$v = (string) $v;
		return preg_match( '/^[\s]*[=+@\-\t\r]/u', $v ) ? "'" . $v : $v; }
}
