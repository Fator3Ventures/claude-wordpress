<?php
/** Comandos administrativos opcionais. Códigos: 0 sucesso, 1 falha, 2 pendência/conflito. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Cli {
	public static function registrar(): void {
		if ( ! defined( 'WP_CLI' ) || ! WP_CLI || ! class_exists( 'WP_CLI' ) ) {
			return; }
		$comandos = array(
			'status'               => array(
				'metodo'    => 'status',
				'descricao' => 'Consulta saúde e evidências existentes.',
				'flags'     => array(),
			),
			'acessos coletar'      => array(
				'metodo'    => 'acessos',
				'descricao' => 'Executa um lote de logs fechados e informa saldo.',
				'flags'     => array(),
			),
			'capi processar'       => array(
				'metodo'    => 'capi',
				'descricao' => 'Processa um lote elegível da fila sob reserva.',
				'flags'     => array(),
			),
			'pendentes executar'   => array(
				'metodo'    => 'pendentes',
				'descricao' => 'Executa tarefas vencidas com limite de trabalhos.',
				'flags'     => array( 'limite' ),
			),
			'publicacao verificar' => array(
				'metodo'    => 'publicacao',
				'descricao' => 'Observa publicação sem reconciliar arquivos.',
				'flags'     => array( 'caminho' ),
			),
		);
		foreach ( $comandos as $nome => $comando ) {
			WP_CLI::add_command(
				'f3base ' . $nome,
				static function ( $args, $opcoes ) use ( $comando ): void {
					self::validar( $args, $opcoes, $comando['flags'] );
					self::saida( call_user_func( array( __CLASS__, $comando['metodo'] ), $opcoes ) );
				},
				array(
					'shortdesc' => $comando['descricao'],
					'synopsis'  => '[--format=<format>]' . ( in_array( 'limite', $comando['flags'], true ) ? ' [--limite=<limite>]' : '' ) . ( in_array( 'caminho', $comando['flags'], true ) ? ' [--caminho=<caminho>]' : '' ),
				)
			);
		}
	}
	private static function validar( array $args, array $opcoes, array $flags ): void {
		if ( $args || array_diff( array_keys( $opcoes ), array_merge( $flags, array( 'format' ) ) ) ) {
			self::saida( new WP_Error( 'argumento_invalido', 'Argumentos não reconhecidos; nenhuma operação iniciada.' ) ); }
		if ( isset( $opcoes['format'] ) && 'json' !== $opcoes['format'] ) {
			self::saida( new WP_Error( 'formato_invalido', 'Use --format=json; nenhuma operação iniciada.' ) ); }
		if ( isset( $opcoes['limite'] ) && ( ! preg_match( '/^[1-9][0-9]*$/D', (string) $opcoes['limite'] ) || (int) $opcoes['limite'] > F3Base_Operacao::MAX_TRABALHOS ) ) {
			self::saida( new WP_Error( 'limite_invalido', 'Limite deve ser inteiro entre 1 e ' . F3Base_Operacao::MAX_TRABALHOS . '; nenhuma operação iniciada.' ) ); }
	}
	public static function status( array $opcoes ): array {
		unset( $opcoes ); // As flags comuns já foram validadas antes do despacho.
		return F3Base_Saude::resumo(); }
	public static function acessos( array $opcoes ): array {
		unset( $opcoes ); // As flags comuns já foram validadas antes do despacho.
		$r                         = F3Base_Operacao::executar_uma( 'acessos', 'wp-cli', false );
		$e                         = (array) F3Base_Options::ler( 'f3base_acessos_estado' );
		$r['coleta']               = array(
			'arquivos_pendentes' => (int) ( $e['pendentes'] ?? 0 ),
			'ultima_soma'        => (int) ( $e['ultima_soma'] ?? 0 ),
			'tentativa'          => (int) ( $e['tentativa'] ?? 0 ),
			'erro'               => (string) ( $e['erro'] ?? '' ),
		);
		$r['verificacao_pendente'] = ! empty( $r['coleta']['arquivos_pendentes'] ) || '' !== $r['coleta']['erro'];
		return $r;
	}
	public static function capi( array $opcoes ): array {
		unset( $opcoes ); // As flags comuns já foram validadas antes do despacho.
		$r                         = F3Base_Operacao::executar_uma( 'capi', 'wp-cli', false );
		$r['fila']                 = F3Base_Capi_Fila::resumo();
		$r['agenda_fila']          = F3Base_Capi_Fila::agenda();
		$r['eventos_pendentes']    = (int) ( $r['agenda_fila']['saldo'] ?? 0 );
		$r['verificacao_pendente'] = $r['eventos_pendentes'] > 0 || ! empty( $r['agenda_fila']['migracao_pendente'] );
		return $r;
	}
	public static function pendentes( array $opcoes ): array {
		return F3Base_Operacao::executar_pendentes( array( 'limite' => (int) ( $opcoes['limite'] ?? F3Base_Operacao::MAX_TRABALHOS ) ) ); }
	public static function publicacao( array $opcoes ) {
		$caminho   = (string) ( $opcoes['caminho'] ?? '/llms.txt' );
		$assercoes = array(
			array(
				'tipo'  => 'status',
				'valor' => 200,
			),
		);
		$path      = (string) wp_parse_url( $caminho, PHP_URL_PATH );
		if ( in_array( basename( $path ), array( 'robots.txt', 'llms.txt', 'llms-full.txt' ), true ) ) {
			$assercoes[] = array(
				'tipo'  => 'cabecalho',
				'nome'  => 'content-type',
				'valor' => 'text/plain',
			); }
		if ( str_ends_with( $path, '.md' ) ) {
			$assercoes[] = array(
				'tipo'  => 'cabecalho',
				'nome'  => 'content-type',
				'valor' => 'text/markdown',
			); }
		return F3Base_Publicacao_Sonda::verificar(
			array(
				'caminho'   => $caminho,
				'metodo'    => 'GET',
				'assercoes' => $assercoes,
			)
		);
	}
	/** Distinção explícita entre falha de transporte/validação e execução ainda pendente. */
	public static function codigo_saida( array $r ): int {
		foreach ( $r['resultados'] ?? array() as $resultado ) {
			if ( 1 === self::codigo_saida( $resultado ) ) {
				return 1; }
		}
		if ( in_array( $r['status'] ?? '', array( 'falha', 'failed' ), true ) ) {
			return 1; }
		if ( isset( $r['metodo'], $r['status'] ) && is_int( $r['status'] ) ) {
			if ( 0 === $r['status'] || $r['status'] >= 400 ) {
				return 1; }
			foreach ( $r['assercoes'] ?? array() as $a ) {
				if ( 'reprovado' === $a['estado'] ) {
					return 1; }
			}
			if ( 200 !== $r['status'] || empty( $r['completa'] ) || empty( $r['persisted'] ) || empty( $r['geracao_atual'] ) ) {
				return 2; }
			foreach ( $r['assercoes'] ?? array() as $a ) {
				if ( 'inconclusivo' === $a['estado'] ) {
					return 2; }
			}
		}
		if ( ! empty( $r['tarefas_vencidas_restantes'] ) || ! empty( $r['verificacao_pendente'] ) || ( isset( $r['ok'] ) && ! $r['ok'] ) ) {
			return 2; }
		return 0;
	}
	private static function saida( $r ): void {
		if ( is_wp_error( $r ) ) {
			$pendente = in_array( $r->get_error_code(), array( 'f3base_sonda_intervalo', 'f3base_reserva_recusada' ), true );
			$r        = array(
				'ok'     => false,
				'codigo' => $r->get_error_code(),
				'motivo' => $r->get_error_message(),
				'status' => $pendente ? 'pendente' : 'falha',
			);
		}
		$codigo            = self::codigo_saida( (array) $r );
		$r['codigo_saida'] = $codigo;
		WP_CLI::line( (string) wp_json_encode( $r, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
		if ( $codigo ) {
			WP_CLI::halt( $codigo ); }
	}
}
