<?php
/** Mesclagem tipada de preferências; produz um valor completo para a fachada do dono. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Config_Mescla {
	public static function preparar( array $d, $atual, $parcial ): array {
		if ( 'grupo' !== ( $d['campo'] ?? '' ) || ! is_array( $atual ) || ! is_array( $parcial ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'mescla_nao_aplicavel',
			); }
		$schema = F3Base_Config_Contrato::schema_valor( $d );
		try {
			$valor = self::mapa( $atual, $parcial, $schema, F3Base_Config_Contrato::schema_entrada( $d ) ); } catch ( InvalidArgumentException $erro ) {
			return array(
				'ok'     => false,
				'codigo' => $erro->getMessage(),
			); }
			return array(
				'ok'    => true,
				'valor' => $valor,
			);
	}
	private static function mapa( array $atual, array $parcial, array $schema, array $entrada ): array {
		foreach ( $parcial as $k => $v ) {
			if ( ! is_string( $k ) || ! isset( $schema['properties'][ $k ] ) ) {
				throw new InvalidArgumentException( 'campo_desconhecido' ); }
			$s    = $schema['properties'][ $k ];
			$e    = $entrada['properties'][ $k ] ?? $s;
			$tipo = $s['type'] ?? null;
			if ( null === $v && ! in_array( 'null', (array) ( $e['type'] ?? array() ), true ) ) {
				throw new InvalidArgumentException( 'nulo_nao_permitido' ); }
			if ( is_wp_error( rest_validate_value_from_schema( $v, $e ) ) ) {
				throw new InvalidArgumentException( 'tipo_invalido' ); }
			if ( in_array( 'object', (array) $tipo, true ) && isset( $s['properties'] ) && is_array( $v ) && ( 'object' === $tipo || ( $v && ! array_is_list( $v ) ) ) ) {
				$atual[ $k ] = self::mapa( is_array( $atual[ $k ] ?? null ) ? $atual[ $k ] : array(), $v, $s, $e ); } else {
				// Listas substituem integralmente. Campos desconhecidos nos seus objetos também são recusados.
				if ( 'array' === $tipo && is_array( $v ) && isset( $s['items']['properties'] ) ) {
					foreach ( $v as $item ) {
						if ( ! is_array( $item ) || array_diff( array_keys( $item ), array_keys( $s['items']['properties'] ) ) ) {
							throw new InvalidArgumentException( 'campo_desconhecido' ); }
					}
				}
				$atual[ $k ] = $v;
				}
		}
		return $atual;
	}
}
