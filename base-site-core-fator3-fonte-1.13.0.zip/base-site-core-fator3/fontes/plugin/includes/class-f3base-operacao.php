<?php
/** Agenda consultável e execução limitada das tarefas pertencentes ao Core. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Operacao {

	public const OPTION              = 'f3base_operacao_estado';
	public const MAX_TRABALHOS       = 3;
	public const MAX_SEGUNDOS        = 30;
	public const LEASE_SEGUNDOS      = 180;
	private static array $callbacks  = array();
	private static bool $desativando = false;

	/** Lista fechada; nomes enviados pelo consumidor nunca viram callbacks. */
	public static function tarefas(): array {
		return array(
			'migracao' => array(
				'rotulo' => 'Atualização de estrutura',
				'hooks'  => array( F3Base_Atualizacao::EVENTO ),
			),
			'acessos'  => array(
				'rotulo' => 'Coleta de logs fechados',
				'hooks'  => array( 'f3base_acessos_somar', 'f3base_acessos_continuar' ),
			),
			'capi'     => array(
				'rotulo' => 'Fila de conversões',
				'hooks'  => array( F3Base_Capi_Fila::EVENTO ),
			),
			'robots'   => array(
				'rotulo' => 'Reconciliação do robots',
				'hooks'  => array( F3Base_Robots_Entrega::EVENTO ),
			),
			'cache'    => array(
				'rotulo' => 'Verificação do cache',
				'hooks'  => array( F3Base_Cache_Pagina::CRON ),
			),
			'retencao' => array(
				'rotulo' => 'Retenção e eliminação',
				'hooks'  => array( F3Base_Modulo_Retencao_Eliminacao::EVENTO ),
			),
			'cadencia' => array(
				'rotulo' => 'Relatório periódico',
				'hooks'  => array( F3Base_Modulo_Cadencia_Relatorio::HOOK ),
			),
		);
	}

	public static function identificar_hook( string $hook ): string {
		foreach ( self::tarefas() as $id => $tarefa ) {
			if ( in_array( $hook, $tarefa['hooks'], true ) ) {
				return $id; }
		}
		return '';
	}

	/** O registro de módulos fornece o callback confiável; o executor não aceita PHP do cliente. */
	public static function callback( string $hook, callable $callback ): callable {
		$id = self::identificar_hook( $hook );
		if ( '' === $id ) {
			return $callback; }
		self::$callbacks[ $hook ] = $callback;
		return static function () use ( $id, $hook ): void {
			self::executar_uma( $id, 'wp-cron', false, $hook );
		};
	}

	public static function sanitizar_estado( $valor, $padrao = array() ): array {
		unset( $padrao );
		$r     = array();
		$valor = is_array( $valor ) ? $valor : array();
		foreach ( array_keys( self::tarefas() ) as $id ) {
			if ( ! isset( $valor[ $id ] ) || ! is_array( $valor[ $id ] ) ) {
				continue; }
			$v           = $valor[ $id ];
			$ultima      = is_array( $v['ultima'] ?? null ) ? $v['ultima'] : array();
			$recuperacao = is_array( $v['recuperacao'] ?? null ) ? $v['recuperacao'] : array();
			$r[ $id ]    = array(
				'recuperacao'     => array(
					'hook'                   => in_array( (string) ( $recuperacao['hook'] ?? '' ), self::tarefas()[ $id ]['hooks'], true ) ? (string) $recuperacao['hook'] : '',
					'quando'                 => max( 0, (int) ( $recuperacao['quando'] ?? 0 ) ),
					'pendente'               => ! empty( $recuperacao['pendente'] ),
					'agendamento_confirmado' => ! empty( $recuperacao['agendamento_confirmado'] ),
					'codigo'                 => substr( sanitize_key( (string) ( $recuperacao['codigo'] ?? '' ) ), 0, 64 ),
				),
				'lease'           => array(
					'id'  => substr( is_string( $v['lease']['id'] ?? null ) ? $v['lease']['id'] : '', 0, 64 ),
					'ate' => max( 0, (int) ( $v['lease']['ate'] ?? 0 ) ),
				),
				'ultima'          => array(),
				'ultimo_sucesso'  => array(),
				'saldo_resultado' => array(),
				'ultima_agendada' => max( 0, (int) ( $v['ultima_agendada'] ?? 0 ) ),
			);
			foreach ( array( 'inicio', 'fim' ) as $k ) {
				$r[ $id ]['ultima'][ $k ] = max( 0, (int) ( $ultima[ $k ] ?? 0 ) ); }
			foreach ( array( 'origem', 'codigo', 'status' ) as $k ) {
				$r[ $id ]['ultima'][ $k ] = substr( sanitize_key( (string) ( $ultima[ $k ] ?? '' ) ), 0, 64 ); }
			$sucesso = is_array( $v['ultimo_sucesso'] ?? null ) ? $v['ultimo_sucesso'] : array();
			if ( (int) ( $sucesso['fim'] ?? 0 ) > 0 ) {
				foreach ( array( 'inicio', 'fim' ) as $k ) {
					$r[ $id ]['ultimo_sucesso'][ $k ] = max( 0, (int) ( $sucesso[ $k ] ?? 0 ) ); }
				foreach ( array( 'origem', 'codigo', 'escopo' ) as $k ) {
					$r[ $id ]['ultimo_sucesso'][ $k ] = substr( sanitize_key( (string) ( $sucesso[ $k ] ?? '' ) ), 0, 64 ); }
			}
			$saldo = $v['saldo_resultado'] ?? array();
			if ( is_array( $saldo ) && isset( $saldo['quantidade'], $saldo['observado_em'] ) ) {
				$r[ $id ]['saldo_resultado'] = array(
					'quantidade'   => max( 0, (int) $saldo['quantidade'] ),
					'observado_em' => max( 0, (int) $saldo['observado_em'] ),
					'escopo'       => substr( sanitize_key( (string) ( $saldo['escopo'] ?? '' ) ), 0, 64 ),
				);
			}
		}
		return $r;
	}

	private static function estado(): array {
		return (array) F3Base_Options::fotografia( self::OPTION )['valor']; }

	/** Apenas lê as agendas já registradas, inclusive quando a execução está atrasada. */
	public static function agenda(): array {
		$estado = self::estado();
		$agora  = time();
		$r      = array();
		foreach ( self::tarefas() as $id => $tarefa ) {
			$proxima    = 0;
			$hook       = '';
			$registrada = false;
			foreach ( $tarefa['hooks'] as $nome ) {
				$registrada = $registrada || isset( self::$callbacks[ $nome ] );
				$t          = (int) wp_next_scheduled( $nome );
				if ( $t && ( ! $proxima || $t < $proxima ) ) {
					$proxima = $t;
					$hook    = $nome; }
			}
			$v        = $estado[ $id ] ?? array();
			$lease    = $v['lease'] ?? array();
			$r[ $id ] = array(
				'id'               => $id,
				'rotulo'           => $tarefa['rotulo'],
				'hook'             => $hook,
				'registrada'       => $registrada,
				'proxima_execucao' => $proxima,
				'atraso_segundos'  => $proxima ? max( 0, $agora - $proxima ) : 0,
				'atrasado'         => $proxima > 0 && $proxima < $agora,
				'reservada'        => (int) ( $lease['ate'] ?? 0 ) > $agora,
				'reserva_ate'      => (int) ( $lease['ate'] ?? 0 ),
				'ultima_execucao'  => $v['ultima'] ?? array(),
				'ultimo_sucesso'   => $v['ultimo_sucesso'] ?? array(),
				'saldo'            => self::saldo( $id, $v ),
				'recuperacao'      => $v['recuperacao'] ?? array(),
				'codigo'           => ! $registrada ? 'inativa' : ( ! $proxima ? 'sem_agendamento' : ( $proxima < $agora ? 'atrasada' : 'agendada' ) ),
			);
		}
		// A evidência de cache anterior ao executor unificado continua visível como histórico.
		$r['cache']['agenda_do_modulo'] = F3Base_Cache_Evidencia::agenda();
		return $r;
	}

	/** Fotografias de escopo explícito. Ausência de prova nunca vira saldo zero. */
	private static function saldo( string $id, array $estado ): array {
		$r = array(
			'conhecido'    => false,
			'quantidade'   => null,
			'observado_em' => null,
			'escopo'       => 'nao_medido',
			'fonte'        => 'nenhuma',
		);
		if ( 'acessos' === $id ) {
			$v           = F3Base_Options::ler( 'f3base_acessos_estado' );
			$r['escopo'] = 'arquivos_pendentes_na_ultima_inspecao';
			$r['fonte']  = 'f3base_acessos_estado';
			if ( ! empty( $v['tentativa'] ) && array_key_exists( 'pendentes', $v ) && empty( $v['erro'] ) && ( $v['config_hash'] ?? '' ) === F3Base_Modulo_Acessos_Servidor::config_hash() ) {
				$r['quantidade']   = max( 0, (int) $v['pendentes'] );
				$r['observado_em'] = (int) $v['tentativa'];
				$r['conhecido']    = true;
			}
		} elseif ( 'capi' === $id && F3Base_Capi_Fila::pronta() ) {
			global $wpdb;
			$linhas      = F3Base_Capi_Fila::resumo();
			$r['escopo'] = 'eventos_nao_terminais_inclui_reconciliacao';
			$r['fonte']  = 'fila_capi_estados';
			if ( '' === $wpdb->last_error ) {
				$r['quantidade'] = 0;
				foreach ( $linhas as $linha ) {
					if ( in_array( $linha['estado'], array( 'pendente', 'reservado', 'enviando', 'cancelando', 'suspenso', 'incerto' ), true ) ) {
						$r['quantidade'] += (int) $linha['eventos']; }
				}
				$r['observado_em'] = time();
				$r['conhecido']    = true;
			}
		} elseif ( ! empty( $estado['saldo_resultado'] ) ) {
			$r = array_merge(
				$r,
				$estado['saldo_resultado'],
				array(
					'conhecido' => true,
					'fonte'     => 'ultimo_resultado_do_modulo',
				)
			);
		}
		return $r;
	}

	/** Evidência já persistida por callbacks legados sem retorno; nenhuma sonda é feita aqui. */
	private static function evidencia_modulo( string $id ): array {
		if ( 'acessos' === $id ) {
			$v = F3Base_Options::ler( 'f3base_acessos_estado' );
			return array(
				'em'     => (int) ( $v['ultima_soma'] ?? 0 ),
				'ok'     => empty( $v['erro'] ) && empty( $v['pendentes'] ),
				'id'     => hash( 'sha256', wp_json_encode( $v ) ),
				'escopo' => 'coleta_fechada_confirmada',
			);
		}
		if ( 'robots' === $id ) {
			$v = F3Base_Options::ler( F3Base_Robots_Arquivo::OPTION )['entrega'] ?? array();
			return array(
				'em'     => (int) ( $v['verificado_em'] ?? 0 ),
				'ok'     => ! empty( $v['ok'] ) && ( $v['assinatura'] ?? '' ) === F3Base_Robots_Entrega::assinatura(),
				'id'     => hash( 'sha256', wp_json_encode( $v ) ),
				'escopo' => 'robots_http_confirmado',
			);
		}
		if ( 'cache' === $id ) {
			$v = F3Base_Cache_Pagina::prova();
			return array(
				'em'     => (int) ( $v['checked_at'] ?? 0 ),
				'ok'     => F3Base_Cache_Evidencia::sucesso( $v ),
				'id'     => (string) ( $v['id'] ?? '' ),
				'escopo' => 'cache_http_confirmado',
			);
		}
		if ( 'cadencia' === $id ) {
			$v = F3Base_Atividade::ler( F3Base_Atividade::ULTIMA_CADENCIA );
			return array(
				'em'     => (int) ( $v['em'] ?? 0 ),
				'ok'     => ( $v['resultado'] ?? '' ) === F3Base_Modulo_Cadencia_Relatorio::RESULTADO_OK,
				'id'     => hash( 'sha256', wp_json_encode( $v ) ),
				'escopo' => 'relatorio_local_confirmado',
			);
		}
		return array();
	}

	private static function reservar( string $id, string $origem, string $hook ): string {
		$token = wp_generate_uuid4();
		$agora = time();
		$r     = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $v ) use ( $id, $origem, $token, $agora, $hook ) {
				$v = (array) $v;
				if ( (int) ( $v[ $id ]['lease']['ate'] ?? 0 ) > $agora ) {
					return null; }
				$v[ $id ]['lease']       = array(
					'id'  => $token,
					'ate' => $agora + self::LEASE_SEGUNDOS,
				);
				$v[ $id ]['recuperacao'] = array(
					'hook'                   => $hook,
					'quando'                 => $agora + self::LEASE_SEGUNDOS + 1,
					'pendente'               => true,
					'agendamento_confirmado' => false,
					'codigo'                 => 'execucao_em_curso',
				);
				$v[ $id ]['ultima']      = array(
					'inicio' => $agora,
					'fim'    => 0,
					'origem' => $origem,
					'status' => 'em_execucao',
					'codigo' => 'reserva_adquirida',
				);
				return $v;
			}
		);
		return ! empty( $r['persisted'] ) && ( $r['lido'][ $id ]['lease']['id'] ?? '' ) === $token ? $token : '';
	}

	private static function concluir( string $id, string $token, array $resultado ): bool {
		$r = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $v ) use ( $id, $token, $resultado ) {
				if ( ( $v[ $id ]['lease']['id'] ?? '' ) !== $token || (int) ( $v[ $id ]['lease']['ate'] ?? 0 ) <= time() ) {
					return null; }
				$v[ $id ]['lease']            = array(
					'id'  => '',
					'ate' => 0,
				);
				$v[ $id ]['ultima']['fim']    = time();
				$v[ $id ]['ultima']['status'] = $resultado['status'];
				$v[ $id ]['ultima']['codigo'] = $resultado['codigo'];
				if ( ! empty( $resultado['resultado_modulo_confirmado'] ) && ! empty( $resultado['ok'] ) && empty( $resultado['parcial'] ) ) {
					$v[ $id ]['ultimo_sucesso'] = array_merge( $v[ $id ]['ultima'], array( 'escopo' => $resultado['sucesso_escopo'] ?? 'lote_local_confirmado' ) );
				}
				foreach ( array( 'saldo', 'restantes' ) as $campo ) {
					if ( isset( $resultado['resultado_modulo'][ $campo ] ) ) {
						$v[ $id ]['saldo_resultado'] = array(
							'quantidade'   => (int) $resultado['resultado_modulo'][ $campo ],
							'observado_em' => time(),
							'escopo'       => 'ultimo_lote_' . $campo,
						);
						break;
					}
				}
				$v[ $id ]['recuperacao']['pendente'] = ! $resultado['ok'] || ! empty( $resultado['parcial'] );
				$v[ $id ]['recuperacao']['quando']   = time() + 60;
				$v[ $id ]['recuperacao']['codigo']   = $resultado['codigo'];
				return $v;
			}
		);
		return ! empty( $r['persisted'] );
	}

	/** Guarda e repõe somente hooks conhecidos. O marcador sobrevive à recusa do cron. */
	private static function recuperar_tarefa( string $id, string $hook, int $quando, string $codigo ): array {
		if ( self::$desativando || self::identificar_hook( $hook ) !== $id ) {
			return array(
				'ok'     => false,
				'codigo' => 'tarefa_nao_permitida',
			); }
		$quando  = max( time() + 1, $quando );
		$marcado = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $v ) use ( $id, $hook, $quando, $codigo ) {
				$v                       = (array) $v;
				$quando                  = max( $quando, (int) ( $v[ $id ]['lease']['ate'] ?? 0 ) + 1 );
				$v[ $id ]['recuperacao'] = array(
					'hook'                   => $hook,
					'quando'                 => $quando,
					'pendente'               => true,
					'agendamento_confirmado' => false,
					'codigo'                 => $codigo,
				);
				return $v;
			}
		);
		if ( empty( $marcado['persisted'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'recuperacao_nao_persistida',
			); }
		$quando = (int) $marcado['lido'][ $id ]['recuperacao']['quando'];
		$atual  = wp_next_scheduled( $hook );
		// Evento já vencido preserva a tentativa que um executor não conseguiu consumir.
		$aproveitar  = $atual && (int) $atual <= $quando;
		$agendado    = $aproveitar || true === wp_schedule_single_event( $quando, $hook );
		$confirmacao = F3Base_Options::atualizar_estado(
			self::OPTION,
			static function ( $v ) use ( $id, $hook, $quando, $agendado, $codigo ) {
				if ( ( $v[ $id ]['recuperacao']['hook'] ?? '' ) !== $hook || (int) ( $v[ $id ]['recuperacao']['quando'] ?? 0 ) !== $quando ) {
					return null; }
				$v[ $id ]['recuperacao']['agendamento_confirmado'] = $agendado;
				$v[ $id ]['recuperacao']['codigo']                 = $agendado ? $codigo : 'agendamento_recuperacao_recusado';
				if ( $agendado ) {
					$v[ $id ]['ultima_agendada'] = $quando; }
				return $v;
			}
		);
		return array(
			'ok'        => $agendado && ! empty( $confirmacao['persisted'] ),
			'agendado'  => $agendado,
			'persisted' => ! empty( $confirmacao['persisted'] ),
			'codigo'    => $agendado ? 'recuperacao_agendada' : 'agendamento_recuperacao_recusado',
			'quando'    => $atual && $aproveitar ? (int) $atual : $quando,
		);
	}

	/** Bootstrap do cron também passa por init; não executa trabalho nem faz rede. */
	public static function recuperar_agendamentos(): void {
		if ( self::$desativando ) {
			return; }
		foreach ( self::estado() as $id => $v ) {
			$r    = $v['recuperacao'] ?? array();
			$hook = (string) ( $r['hook'] ?? '' );
			if ( empty( $r['pendente'] ) || ! isset( self::$callbacks[ $hook ] ) || (int) ( $v['lease']['ate'] ?? 0 ) > time() ) {
				continue; }
			$atual = wp_next_scheduled( $hook );
			if ( $atual && (int) $atual <= max( time() + 1, (int) ( $r['quando'] ?? 0 ) ) && ! empty( $r['agendamento_confirmado'] ) ) {
				continue; }
			self::recuperar_tarefa( $id, $hook, max( time() + 1, (int) ( $r['quando'] ?? 0 ) ), (string) ( $r['codigo'] ?? 'recuperacao_pendente' ) );
		}
	}

	/** Projeção fechada: nenhum payload, credencial ou mensagem de fornecedor é propagado. */
	private static function resultado_seguro( array $r ): array {
		$saida = array();
		foreach ( array( 'processados', 'restantes', 'saldo', 'expirados', 'arquivados', 'eliminados', 'falhas_confirmacao', 'limpezas_pendentes' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_numeric( $r[ $k ] ) ) {
				$saida[ $k ] = max( 0, (int) $r[ $k ] ); }
		}
		foreach ( array( 'ok', 'parcial', 'reagendado', 'persisted', 'local_confirmado', 'incompleto' ) as $k ) {
			if ( isset( $r[ $k ] ) && is_bool( $r[ $k ] ) ) {
				$saida[ $k ] = $r[ $k ]; }
		}
		if ( isset( $r['codigo'] ) && is_string( $r['codigo'] ) ) {
			$saida['codigo'] = substr( sanitize_key( $r['codigo'] ), 0, 64 ); }
		if ( isset( $r['agenda']['saldo'] ) ) {
			$saida['saldo'] = max( 0, (int) $r['agenda']['saldo'] ); }
		return $saida;
	}

	/** Operação interna comum ao cron, CLI e ação autenticada. */
	public static function executar_uma( string $id, string $origem = 'administracao', bool $somente_vencida = true, string $hook_especifico = '' ): array {
		if ( self::$desativando || ! isset( self::tarefas()[ $id ] ) ) {
			return array(
				'id'     => $id,
				'status' => 'falha',
				'codigo' => 'tarefa_nao_permitida',
				'ok'     => false,
			); }
		$a    = self::agenda()[ $id ];
		$hook = '' !== $hook_especifico ? $hook_especifico : $a['hook'];
		if ( ! $hook && ! $somente_vencida ) {
			foreach ( self::tarefas()[ $id ]['hooks'] as $candidato ) {
				if ( isset( self::$callbacks[ $candidato ] ) ) {
					$hook = $candidato;
					break; }
			}
		}
		if ( ! isset( self::$callbacks[ $hook ] ) || self::identificar_hook( $hook ) !== $id ) {
			return array(
				'id'     => $id,
				'status' => 'pendente',
				'codigo' => 'tarefa_inativa',
				'ok'     => false,
			); }
		if ( $somente_vencida && ( ! $a['proxima_execucao'] || $a['proxima_execucao'] > time() ) ) {
			return array(
				'id'     => $id,
				'status' => 'sem_pendencia',
				'codigo' => 'nenhuma_execucao_vencida',
				'ok'     => true,
			); }
		$token = self::reservar( $id, $origem, $hook );
		if ( '' === $token ) {
			$r = array(
				'id'     => $id,
				'status' => 'reservado',
				'codigo' => 'reserva_indisponivel',
				'ok'     => false,
			);
			if ( 'wp-cron' === $origem ) {
				$r['recuperacao'] = self::recuperar_tarefa( $id, $hook, max( time() + 60, (int) $a['reserva_ate'] + 1 ), 'reserva_indisponivel' ); }
			return $r;
		}
		$r = array(
			'id'                          => $id,
			'status'                      => 'concluido',
			'codigo'                      => 'tarefa_executada',
			'ok'                          => true,
			'confirmado_localmente'       => false,
			'parcial'                     => false,
			'resultado_modulo_confirmado' => false,
		);
		try {
			// O cron nativo já consome/reagenda seu evento. Um executor externo faz o mesmo
			// somente para o evento vencido e sem argumentos pertencente a esta tarefa.
			if ( 'wp-cron' !== $origem ) {
				$evento = wp_get_scheduled_event( $hook );
				if ( $evento && $evento->timestamp <= time() ) {
					if ( $evento->schedule ) {
						$x = wp_reschedule_event( $evento->timestamp, $evento->schedule, $hook, array(), true );
						if ( is_wp_error( $x ) || ! $x ) {
							throw new RuntimeException( 'reagendamento_recusado' ); }
					}
					$x = wp_unschedule_event( $evento->timestamp, $hook, array(), true );
					if ( is_wp_error( $x ) || ! $x ) {
						throw new RuntimeException( 'consumo_agendamento_recusado' ); }
				}
			}
			$inicio_callback = time();
			$evidencia_antes = self::evidencia_modulo( $id );
			$resultado       = call_user_func( self::$callbacks[ $hook ] );
			if ( is_wp_error( $resultado ) || false === $resultado ) {
				$r['ok']     = false;
				$r['status'] = 'pendente';
				$r['codigo'] = 'callback_recusou';
			} elseif ( is_array( $resultado ) ) {
				$r['resultado_modulo'] = self::resultado_seguro( $resultado );
				$seguro                = $r['resultado_modulo'];
				$r['parcial']          = ! empty( $seguro['parcial'] ) || ! empty( $seguro['incompleto'] ) || (int) ( $seguro['restantes'] ?? 0 ) > 0 || (int) ( $seguro['saldo'] ?? 0 ) > 0;
				if ( isset( $seguro['ok'] ) && ! $seguro['ok'] ) {
					$r['ok']     = false;
					$r['status'] = 'pendente';
					$r['codigo'] = $seguro['codigo'] ?? 'resultado_pendente'; } elseif ( $r['parcial'] ) {
					$r['status'] = 'parcial';
					$r['codigo'] = 'lote_com_pendencias'; }
					if ( isset( $seguro['reagendado'] ) && ! $seguro['reagendado'] ) {
						$r['ok']     = false;
						$r['status'] = 'pendente';
						$r['codigo'] = 'agendamento_recusado'; }
					if ( ( isset( $seguro['persisted'] ) && ! $seguro['persisted'] ) || ( isset( $seguro['local_confirmado'] ) && ! $seguro['local_confirmado'] ) ) {
						$r['ok']     = false;
						$r['status'] = 'pendente';
						$r['codigo'] = 'confirmacao_modulo_pendente'; }
					$r['resultado_modulo_confirmado'] = isset( $seguro['ok'] ) && $r['ok'] && ! $r['parcial'];
					if ( ! isset( $seguro['ok'] ) ) {
						$r['status'] = 'executado';
						$r['codigo'] = 'resultado_sem_confirmacao'; }
			} else {
				$r['status'] = 'executado';
				$r['codigo'] = 'callback_sem_resultado_estruturado'; }
			if ( $r['ok'] && ! $r['parcial'] && ! $r['resultado_modulo_confirmado'] ) {
				$evidencia = self::evidencia_modulo( $id );
				if ( ! empty( $evidencia['ok'] ) && $evidencia['em'] >= $inicio_callback && $evidencia !== $evidencia_antes ) {
					$r['resultado_modulo_confirmado'] = true;
					$r['sucesso_escopo']              = $evidencia['escopo'];
					$r['status']                      = 'concluido';
					$r['codigo']                      = 'evidencia_modulo_confirmada';
				}
			}
		} catch ( Throwable $e ) {
			$r['ok']     = false;
			$r['status'] = 'falha';
			$r['codigo'] = in_array( $e->getMessage(), array( 'reagendamento_recusado', 'consumo_agendamento_recusado' ), true ) ? $e->getMessage() : 'tarefa_lancou_excecao';
		} finally {
			$r['confirmado_localmente'] = self::concluir( $id, $token, $r );
		}
		if ( ! $r['confirmado_localmente'] ) {
			$r['ok']     = false;
			$r['status'] = 'pendente';
			$r['codigo'] = 'confirmacao_local_pendente'; }
		if ( ! $r['ok'] || $r['parcial'] ) {
			$r['recuperacao'] = self::recuperar_tarefa( $id, $hook, time() + 60, $r['codigo'] );
			if ( empty( $r['recuperacao']['ok'] ) ) {
				$r['ok']              = false;
				$r['status']          = 'pendente';
				$r['codigo_execucao'] = $r['codigo'];
				$r['codigo']          = 'agendamento_recuperacao_pendente'; }
		}
		$r['proxima_execucao'] = self::agenda()[ $id ]['proxima_execucao'];
		$r['escopo']           = 'execucao_do_lote; entrega_externa_e_saldo_consultados_no_modulo';
		return $r;
	}

	public static function executar_pendentes( array $entrada = array() ): array {
		if ( ! current_user_can( 'manage_options' ) && ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return array(
				'ok'         => false,
				'codigo'     => 'sem_permissao',
				'resultados' => array(),
			); }
		$limite = max( 1, min( self::MAX_TRABALHOS, (int) ( $entrada['limite'] ?? self::MAX_TRABALHOS ) ) );
		$ids    = $entrada['tarefas'] ?? array_keys( self::tarefas() );
		if ( ! is_array( $ids ) || array_diff( $ids, array_keys( self::tarefas() ) ) ) {
			return array(
				'ok'         => false,
				'codigo'     => 'tarefa_nao_permitida',
				'resultados' => array(),
			); }
		$inicio = microtime( true );
		$r      = array();
		foreach ( array_unique( $ids ) as $id ) {
			if ( count( $r ) >= $limite || microtime( true ) - $inicio >= self::MAX_SEGUNDOS ) {
				break; }
			$a = self::agenda()[ $id ];
			if ( ! $a['proxima_execucao'] || $a['proxima_execucao'] > time() ) {
				continue; }
			$r[] = self::executar_uma( $id, 'executor_externo' );
		}
		$agenda = self::agenda();
		$saldo  = count( array_filter( $agenda, static fn( $a ) => $a['atrasado'] && $a['registrada'] ) );
		$falhas = count( array_filter( $r, static fn( $x ) => ! $x['ok'] ) );
		return array(
			'ok'                          => 0 === $falhas,
			'codigo'                      => $saldo || $falhas || count( array_filter( $r, static fn( $x ) => ! empty( $x['parcial'] ) ) ) ? 'execucao_parcial' : 'execucao_concluida',
			'resultados'                  => $r,
			'tarefas_vencidas_restantes'  => $saldo,
			'agenda'                      => $agenda,
			'limite_trabalhos'            => $limite,
			'limite_entre_lotes_segundos' => self::MAX_SEGUNDOS,
		);
	}

	public static function registrar(): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		F3Base_Servicos::registrar_ability(
			'f3base/executar-pendentes',
			array(
				'label'               => 'Executar pendências do Core',
				'description'         => 'Executa lotes vencidos do Core com reserva e orçamento; não executa tarefas de outros plugins.',
				'category'            => 'f3base',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'tarefas' => array(
							'type'     => 'array',
							'maxItems' => count( self::tarefas() ),
							'items'    => array(
								'type' => 'string',
								'enum' => array_keys( self::tarefas() ),
							),
						),
						'limite'  => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => self::MAX_TRABALHOS,
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
				'permission_callback' => static fn() => current_user_can( 'manage_options' ),
				'execute_callback'    => array( __CLASS__, 'executar_pendentes' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	public static function desativar(): void {
		self::$desativando = true; }
}
