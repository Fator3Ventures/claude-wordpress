<?php
/** Permanent private contact store. Imports never trigger mail or conversion. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Leads_Repositorio {
	const SCHEMA = 2;
	public static function tabela( string $s = 'leads' ): string {
		global $wpdb;
		return $wpdb->prefix . 'f3base_' . $s; }
    public static function pronto(): bool {
        global $wpdb;
        $colunas = $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', self::tabela() ) );
        return ! $wpdb->last_error && is_array( $colunas ) && ! array_diff( array( 'record_id', 'sessao', 'post_id', 'correlacao', 'resposta', 'resposta_em', 'resposta_erro' ), $colunas );
    }
	public static function instalar(): bool {
		if ( ( F3Base_Options::ler( 'f3base_leads_estrutura' )['schema'] ?? 0 ) === self::SCHEMA && self::pronto() ) {
			return true; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$cc    = $wpdb->get_charset_collate();
		$sql   = array();
		$sql[] = 'CREATE TABLE ' . self::tabela() . ' (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            record_id varchar(32) NOT NULL,
            correlacao varchar(64) DEFAULT NULL,
            sessao char(32) DEFAULT NULL,
            post_id bigint(20) unsigned DEFAULT NULL,
            resposta varchar(30) NOT NULL DEFAULT \'desligada\',
            resposta_em bigint(20) NOT NULL DEFAULT 0,
            resposta_erro varchar(100) NOT NULL DEFAULT \'\',
            formulario varchar(80) NOT NULL DEFAULT \'\',
            metodo varchar(40) NOT NULL,
            captura varchar(20) NOT NULL DEFAULT \'aceito\',
            atendimento varchar(20) NOT NULL DEFAULT \'novo\',
            lixeira tinyint(1) NOT NULL DEFAULT 0,
            criado_em datetime NOT NULL,
            atualizado_em datetime NOT NULL,
            email varchar(254) NOT NULL DEFAULT \'\',
            nome varchar(250) NOT NULL DEFAULT \'\',
            pagina text NOT NULL,
            dados longtext NOT NULL,
            anexos longtext NOT NULL,
            idempotencia varchar(64) DEFAULT NULL,
            payload_hash varchar(64) NOT NULL,
            origem_chave varchar(190) DEFAULT NULL,
            origem_hash varchar(64) NOT NULL DEFAULT \'\',
            importado_hash varchar(64) NOT NULL DEFAULT \'\',
            revisao bigint(20) unsigned NOT NULL DEFAULT 1,
            aviso varchar(30) NOT NULL DEFAULT \'desligado\',
            aviso_em bigint(20) NOT NULL DEFAULT 0,
            aviso_erro varchar(100) NOT NULL DEFAULT \'\',
            eliminacao_pendente tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY record_id (record_id),
            UNIQUE KEY idempotencia (idempotencia),
            UNIQUE KEY origem_chave (origem_chave),
            KEY cronologia (criado_em,id),
            KEY sessao (sessao),
            KEY post_id (post_id),
            KEY email (email(100)),
            KEY aviso (aviso,aviso_em)
        ) ' . $cc . ';';
		$sql[] = 'CREATE TABLE ' . self::tabela( 'contatos_legados' ) . ' (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            origem_chave varchar(190) NOT NULL,
            email varchar(254) NOT NULL DEFAULT \'\',
            dados longtext NOT NULL,
            origem_hash varchar(64) NOT NULL,
            eliminado tinyint(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY origem_chave (origem_chave),
            KEY email (email(100))
        ) ' . $cc . ';';
		$sql[] = 'CREATE TABLE ' . self::tabela( 'arquivos_leads' ) . ' (
            id varchar(32) NOT NULL,
            dono varchar(32) NOT NULL DEFAULT \'\',
            finalidade varchar(20) NOT NULL,
            nome text NOT NULL,
            mime varchar(120) NOT NULL,
            bytes bigint(20) unsigned NOT NULL,
            sha256 varchar(64) NOT NULL,
            criado_em bigint(20) NOT NULL,
            estado varchar(20) NOT NULL DEFAULT \'preparado\',
            PRIMARY KEY  (id),
            KEY dono (dono),
            KEY estado (estado,criado_em)
        ) ' . $cc . ';';
		$sql[] = 'CREATE TABLE ' . self::tabela( 'concessoes' ) . ' (
            id varchar(32) NOT NULL,
            lead_record_id varchar(32) NOT NULL,
            ativo varchar(32) NOT NULL,
            versao varchar(64) NOT NULL,
            dedup varchar(64) DEFAULT NULL,
            expira bigint(20) NOT NULL,
            quota int NOT NULL,
            usados int NOT NULL DEFAULT 0,
            revogada tinyint(1) NOT NULL DEFAULT 0,
            primeira bigint(20) NOT NULL DEFAULT 0,
            ultima bigint(20) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY dedup (dedup),
            KEY lead_record_id (lead_record_id)
        ) ' . $cc . ';';
		$sql[] = 'CREATE TABLE ' . self::tabela( 'leads_janelas' ) . ' (
            chave varchar(190) NOT NULL,
            total bigint(20) NOT NULL DEFAULT 0,
            expira bigint(20) NOT NULL,
            PRIMARY KEY  (chave),
            KEY expira (expira)
        ) ' . $cc . ';';
		foreach ( $sql as $q ) {
			dbDelta( $q );
			if ( $wpdb->last_error ) {
				return false; }
		}
		foreach ( array( 'leads', 'contatos_legados', 'arquivos_leads', 'concessoes', 'leads_janelas' ) as $t ) {
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( self::tabela( $t ) ) ) ) !== self::tabela( $t ) ) {
				return false; }
		}
		if ( ! self::pronto() ) { return false; }
		$r = F3Base_Options::atualizar_estado(
			'f3base_leads_estrutura',
			static fn()=>array(
				'schema' => self::SCHEMA,
				'em'     => time(),
			)
		);
		return ! empty( $r['persisted'] );
	}
	public static function hash( array $dados ): string {
		return hash( 'sha256', (string) wp_json_encode( F3Base_Auditoria::ordenar( $dados ) ) ); }
	public static function obter( string $record ): ?array {
		global $wpdb;
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE record_id=%s', self::tabela(), $record ), ARRAY_A );
		if ( ! $r ) {
			return null;
		} foreach ( array( 'dados', 'anexos' ) as $k ) {
			$r[ $k ] = json_decode( $r[ $k ], true ) ?? array();
		} return $r;
	}
	public static function por_origem( string $origem ): ?array {
		global $wpdb;
		$id = $wpdb->get_var( $wpdb->prepare( 'SELECT record_id FROM %i WHERE origem_chave=%s', self::tabela(), $origem ) );
		return $id ? self::obter( $id ) : null;
	}
	public static function guardar( array $d, ?string $idem = null, ?string $origem = null, string $origem_hash = '', bool $importar = false ): array {
		global $wpdb;
		if ( ! self::instalar() ) {
			return array(
				'ok'        => false,
				'codigo'    => 'estrutura_indisponivel',
				'persisted' => false,
			); }
		if ( isset( $d['correlacao'], $d['correlation_id'] ) && $d['correlacao'] !== $d['correlation_id'] ) { return array( 'ok' => false, 'persisted' => false, 'codigo' => 'correlacao_conflitante' ); }
		$d['correlacao'] = $d['correlacao'] ?? $d['correlation_id'] ?? null;
		$record  = $d['record_id'] ?? bin2hex( random_bytes( 16 ) );
		$payload = self::hash( $d['payload'] ?? $d );
		$metodo  = (string) ( $d['metodo'] ?? 'legado_desconhecido' );
		$captura = $d['captura'] ?? 'aceito';
		$email   = strtolower( sanitize_email( (string) ( $d['email'] ?? '' ) ) );
		$nome    = sanitize_text_field( (string) ( $d['nome'] ?? '' ) );
		$avisar  = ! $importar && 'suspeito' !== $captura && ! empty( $d['notificar'] );
		$dados   = $d;
		unset( $dados['record_id'], $dados['payload'] );
		$row = array(
			'record_id'      => $record,
			'correlacao'     => $d['correlacao'] ?? null,
			'sessao'         => F3Base_Leads_Contexto::sessao( $d['sessao'] ?? null ),
			'post_id'        => ! empty( $d['post_id'] ) ? (int) $d['post_id'] : null,
			'resposta'       => ! $importar && 'aceito' === $captura && ! empty( $d['resposta_visitante']['ativa'] ) && is_email( $email ) ? 'pendente' : 'desligada',
			'formulario'     => $d['formulario'] ?? '',
			'metodo'         => $metodo,
			'captura'        => $captura,
			'atendimento'    => $d['atendimento'] ?? 'novo',
			'lixeira'        => ! empty( $d['lixeira'] ) ? 1 : 0,
			'criado_em'      => $d['criado_em'] ?? gmdate( 'Y-m-d H:i:s' ),
			'atualizado_em'  => gmdate( 'Y-m-d H:i:s' ),
			'email'          => $email,
			'nome'           => $nome,
			'pagina'         => $d['pagina'] ?? '',
			'dados'          => wp_json_encode( $dados ),
			'anexos'         => wp_json_encode( $d['anexos'] ?? array() ),
			'idempotencia'   => $idem,
			'payload_hash'   => $payload,
			'origem_chave'   => $origem,
			'origem_hash'    => $origem_hash,
			'importado_hash' => $importar ? self::hash( $dados ) : '',
			'aviso'          => $avisar ? 'pendente' : 'desligado',
		);
		if ( false === $row['dados'] || false === $row['anexos'] ) {
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => 'json_invalido',
			); }
		$old = $wpdb->suppress_errors( true );
		$ok  = $wpdb->insert( self::tabela(), $row );
		$wpdb->suppress_errors( $old );
		if ( ! $ok ) {
			$consulta = $idem ? $wpdb->prepare( 'SELECT record_id,payload_hash FROM %i WHERE idempotencia=%s', self::tabela(), $idem ) : $wpdb->prepare( 'SELECT record_id,payload_hash FROM %i WHERE record_id=%s', self::tabela(), $record );
			$exist    = $wpdb->get_row( $consulta, ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Both branches of consulta are prepared immediately above.
			if ( $exist && hash_equals( $exist['payload_hash'], $payload ) ) {
				return array(
					'ok'        => true,
					'persisted' => true,
					'duplicado' => true,
					'record_id' => $exist['record_id'],
				); }
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => $exist ? 'idempotencia_conflitante' : 'persistencia_falhou',
			);
		}
		$r = self::obter( $record );
		if ( ! $r || ! hash_equals( $payload, $r['payload_hash'] ) ) {
			return array(
				'ok'        => false,
				'persisted' => false,
				'codigo'    => 'leitura_divergente',
			); }
		return array(
			'ok'        => true,
			'persisted' => true,
			'duplicado' => false,
			'record_id' => $record,
			'captura'   => $captura,
		);
	}
	public static function clique( array $dados, string $record ): array {
		$cfg = F3Base_Options::ler( 'f3base_contato' );
		$acao = F3Base_Leads_Contexto::destino( (string) ( $dados['destino'] ?? '' ) );
		$dados['metodo'] = $acao['metodo'];
		$dados['destino_tipo'] = $acao['tipo'];
		$dados = F3Base_Leads_Contexto::capturar( $dados, F3Base_Modulo_Consentimento::permite_categoria( 'medicao' ) && false !== ( $dados['consentimento_medicao'] ?? true ) );
		$d   = $dados + array(
			'record_id'     => $record,
			'metodo'        => $acao['metodo'],
			'captura'       => 'clique',
			'campos'        => $dados,
			'notificar'     => $cfg['avisar_por_clique'] ?? true,
			'destinatarios' => F3Base_Leads_Notificacoes::destinatarios( $cfg['email_leads'] ?? array() ),
			'snapshot'      => array(
				'site'    => get_bloginfo( 'name' ),
				'usuario' => get_current_user_id(),
			),
		);
		$r   = self::guardar( $d, hash( 'sha256', 'cta|' . $record ) );
		if ( ! empty( $r['persisted'] ) && empty( $r['duplicado'] ) ) {
			F3Base_Leads_Notificacoes::enviar( $record ); }
		return array(
			'ok'      => ! empty( $r['persisted'] ),
			'destino' => 'f3base_leads',
			'motivo'  => $r['codigo'] ?? '',
		);
	}
	/** Increment is atomic and the returned sequence grants at most the declared quota. */
	public static function quota( string $chave, int $max, int $expira ): bool {
		global $wpdb;
		$t = self::tabela( 'leads_janelas' );
		$wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO %i (chave,total,expira) VALUES (%s,0,%d)', $t, $chave, $expira ) );
		return 1 === $wpdb->query( $wpdb->prepare( 'UPDATE %i SET total=total+1 WHERE chave=%s AND total<%d AND expira>=%d', $t, $chave, $max, time() ) );
	}
	public static function consultar( array $e = array() ): array {
		global $wpdb;
		$where = array( 'eliminacao_pendente=0' );
		$args  = array();
		foreach ( array( 'metodo', 'formulario', 'captura', 'atendimento', 'email', 'sessao', 'correlacao', 'post_id' ) as $k ) {
			if ( isset( $e[ $k ] ) && '' !== $e[ $k ] ) {
				$where[] = $k . '=%s';
				$args[]  = $e[ $k ]; }
		}
		$where[] = 'lixeira=%d';
		$args[]  = ! empty( $e['lixeira'] ) ? 1 : 0;
		if ( ! empty( $e['busca'] ) ) {
			$where[] = '(nome LIKE %s OR email LIKE %s)';
			$args[]  = '%' . $wpdb->esc_like( $e['busca'] ) . '%';
			$args[]  = '%' . $wpdb->esc_like( $e['busca'] ) . '%'; }
		if ( ! empty( $e['cursor'] ) ) {
			$c = json_decode( (string) base64_decode( (string) $e['cursor'], true ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Decodes a typed pagination or signed form payload, never PHP or executable code.
			if ( ! is_array( $c ) || count( $c ) !== 2 || ! is_string( $c[0] ) || ! is_numeric( $c[1] ) ) {
				return array(
					'ok'     => false,
					'codigo' => 'cursor_invalido',
				); }
			$where[] = '(criado_em>%s OR (criado_em=%s AND id>%d))';
			array_push( $args, $c[0], $c[0], (int) $c[1] );
		}
		foreach ( array(
			'de'  => '>=',
			'ate' => '<=',
		) as $k => $op ) {
			if ( ! empty( $e[ $k ] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $e[ $k ] ) ) {
				$where[] = 'criado_em' . $op . '%s';
				$args[]  = $e[ $k ] . ( 'ate' === $k ? ' 23:59:59' : ' 00:00:00' ); }
		}
		$lim    = max( 1, min( 100, (int) ( $e['limite'] ?? 50 ) ) );
		$args[] = $lim + 1;
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::tabela() . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY criado_em,id LIMIT %d', $args ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- Internal query builder uses fixed columns/operators and prepared placeholders for every value.
		if ( $wpdb->last_error ) {
			return array(
				'ok'     => false,
				'codigo' => 'leitura_falhou',
			); }
		$mais   = count( $rows ) > $lim;
		$rows   = array_slice( $rows, 0, $lim );
		$last   = end( $rows );
		$cursor = $mais && $last ? base64_encode( wp_json_encode( array( $last['criado_em'], (int) $last['id'] ) ) ) : null; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Encodes a typed cursor or HMAC payload, not executable code.
		foreach ( $rows as &$r ) {
			$r['dados']  = json_decode( $r['dados'], true );
			$r['anexos'] = json_decode( $r['anexos'], true );
			unset( $r['idempotencia'], $r['payload_hash'], $r['importado_hash'] ); }
		return array(
			'ok'             => true,
			'registros'      => $rows,
			'proximo_cursor' => $cursor,
		);
	}
	public static function atualizar( array $e ): array {
		global $wpdb;
		$r = self::obter( (string) ( $e['record_id'] ?? '' ) );
		if ( ! $r || $r['eliminacao_pendente'] ) {
			return array(
				'ok'     => false,
				'codigo' => 'nao_encontrado',
			); }
		if ( (int) ( $e['revisao_esperada'] ?? 0 ) !== (int) $r['revisao'] ) {
			return array(
				'ok'     => false,
				'codigo' => 'conflito',
			); }
		$d = $e['alteracoes'] ?? array();
		if ( ! is_array( $d ) || array_diff( array_keys( $d ), array( 'atendimento', 'lixeira', 'captura' ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'alteracao_invalida',
			); }
		if ( isset( $d['atendimento'] ) && ! in_array( $d['atendimento'], array( 'novo', 'respondido', 'spam' ), true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'estado_invalido',
			); }
		if ( isset( $d['captura'] ) && ! in_array( $d['captura'], array( 'aceito', 'suspeito' ), true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'captura_invalida',
			); }
		if ( isset( $d['lixeira'] ) && ! is_bool( $d['lixeira'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'lixeira_invalida',
			); }
		if ( $e['simular'] ?? true ) {
			return array(
				'ok'       => true,
				'simulado' => true,
				'antes'    => array_intersect_key( $r, $d ),
				'depois'   => $d,
			); }
		$d['revisao']       = (int) $r['revisao'] + 1;
		$d['atualizado_em'] = gmdate( 'Y-m-d H:i:s' );
		if(false===$wpdb->query('START TRANSACTION')){return array('ok'=>false,'codigo'=>'transacao_indisponivel');}
		$ok                 = $wpdb->update(
			self::tabela(),
			$d,
			array(
				'record_id' => $r['record_id'],
				'revisao'   => $r['revisao'],
			)
		);
		if (1 === $ok && isset($d['atendimento']) && $d['atendimento'] !== $r['atendimento']) {
            $hist=$wpdb->insert($wpdb->prefix.F3Base_Analise::HISTORICO,array('record_id'=>$r['record_id'],'revisao'=>$d['revisao'],'anterior'=>$r['atendimento'],'atual'=>$d['atendimento'],'em'=>time(),'operador'=>get_current_user_id()));
            if(false===$hist){$wpdb->query('ROLLBACK');return array('ok'=>false,'persisted'=>false,'codigo'=>'historico_nao_persistido');}
        }
        if(1!==$ok){$wpdb->query('ROLLBACK');}elseif(false===$wpdb->query('COMMIT')){return array('ok'=>false,'codigo'=>'confirmacao_pendente');}
		return array(
			'ok'        => 1 === $ok,
			'persisted' => 1 === $ok,
			'revisao'   => $d['revisao'],
			'codigo'    => 1 === $ok ? 'atualizado' : 'conflito',
		);
	}
	public static function journal( string $record, string $estado, string $motivo = 'titular' ): bool {
		$entrada = array(
			'regime'             => $motivo,
			'identificador'      => '',
			'identificador_hash' => hash_hmac( 'sha256', $record, wp_salt( 'auth' ) ),
			'contagem'           => 1,
			'em'                 => time(),
			'operador'           => 'core:' . get_current_user_id(),
			'reversivel_ate'     => 0,
			'motivo'             => 'acervo_' . $estado,
		);
		$r       = F3Base_Options::atualizar_estado(
			'f3base_journal_eliminacao',
			static function ( $atual ) use ( $entrada ) {
				$atual   = (array) $atual;
				$atual[] = $entrada;
				return $atual;
			}
		);
		return ! empty( $r['persisted'] );
	}
	public static function eliminar( string $record, string $motivo = 'titular' ): bool {
		global $wpdb;
		$r = self::obter( $record );
		if ( ! $r || 'eliminado' === $r['captura'] ) {
			return true; }
		if ( ! self::journal( $record, 'solicitada', $motivo ) ) {
			return false; }
		if ( false === $wpdb->update(
			self::tabela(),
			array(
				'eliminacao_pendente' => 1,
				'aviso'               => 'cancelado',
			),
			array( 'record_id' => $record )
		) ) {
			return false; }
		if ( false === $wpdb->update( self::tabela( 'concessoes' ), array( 'revogada' => 1 ), array( 'lead_record_id' => $record ) ) ) {
			return false; }
		$cancel = F3Base_Capi_Fila::cancelar( $record, 0, true );
		if ( empty( $cancel['persisted'] ) ) {
			return false; }
		F3Base_Capi_Fila::limpar_cancelado( $record );
		$files = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM %i WHERE dono=%s AND finalidade=%s', self::tabela( 'arquivos_leads' ), $record, 'anexo' ) );
		foreach ( $files as $id ) {
			if ( ! F3Base_Arquivos_Privados::eliminar( $id ) ) {
				return false; }
		}
        if(!F3Base_Analise::eliminar_lead($r)){return false;}
		// During coexistence, the imported original is part of the same erasure.
		if ( preg_match( '/^wp:(flamingo_inbound|f3base_lead):(\d+)$/D', (string) $r['origem_chave'], $m ) ) {
			$post = get_post( (int) $m[2] );
			if ( $post && $post->post_type === $m[1] && ! wp_delete_post( $post->ID, true ) ) {
				return false; }
		}
		// A source tombstone prevents re-import. It contains no original fields or contact identity.
		if ( $r['origem_chave'] ) {
			$ok = $wpdb->update(
				self::tabela(),
				array(
					'dados'          => '{}',
					'anexos'         => '[]',
					'nome'           => '',
					'email'          => '',
					'pagina'         => '',
					'correlacao'     => null,
                    'sessao' => null, 'post_id' => null,
					'payload_hash'   => '',
					'origem_hash'    => '',
					'importado_hash' => '',
					'captura'        => 'eliminando',
					'lixeira'        => 1,
				),
				array( 'record_id' => $record )
			); } else {
			$ok = $wpdb->update(
				self::tabela(),
				array(
					'dados'        => '{}',
					'anexos'       => '[]',
					'nome'         => '',
					'email'        => '',
					'pagina'       => '',
					'correlacao'   => null,
                    'sessao' => null, 'post_id' => null,
					'payload_hash' => '',
					'captura'      => 'eliminando',
				),
				array( 'record_id' => $record )
			); }
			if ( false === $ok || ! self::journal( $record, 'concluida', $motivo ) ) {
				return false; }
				return false !== ( $r['origem_chave'] ? $wpdb->update( self::tabela(), array( 'captura' => 'eliminado' ), array( 'record_id' => $record ) ) : $wpdb->delete( self::tabela(), array( 'record_id' => $record ) ) );
	}
}
