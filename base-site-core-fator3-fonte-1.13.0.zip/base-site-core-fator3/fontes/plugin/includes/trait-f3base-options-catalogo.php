<?php
/**
 * Catálogo declarativo e descrição de contrato. Parte interna da fachada F3Base_Options.
 *
 * @package F3Base\SiteCore
 */

declare( strict_types = 1 );

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Implementação interna; somente F3Base_Options deve incorporar esta trait. */
trait F3Base_Options_Catalogo {
	/**
	 * Catálogo das options gerenciadas pelo site-core.
	 *
	 * Cada entrada declara: rótulo, descrição, se é operável na tela, o tipo de
	 * campo do formulário, o padrão embutido e o sanitizador. O catálogo é a
	 * fonte única — a tela, a guarda do canal MCP e o relatório leem daqui.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	private static function catalogo_interno(): array {
		if ( null !== self::$catalogo ) {
			return self::$catalogo;
		}

		$catalogo = array(
			'f3base_contato'                => array(
				'rotulo'    => __( 'Contato pelo WhatsApp', 'f3base' ),
				'descricao' => __( 'Para onde vai quem clica no botão de contato do site, e com que mensagem a conversa começa.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_CONTATO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'whatsapp_e164'   => '',
					'flutuante'       => false,
					'email_leads'     => '',
					'mensagem_padrao' => '',
				),
				/*
				 * `email_leads` SAIU DO FORMULÁRIO na 1.1.4, e quem a tirou foi
				 * a obrigação de escrever o IMPACTO dela. A varredura de
				 * consumidores em runtime é conclusiva: nenhum módulo deste
				 * plugin lê esta subchave — o destino do regime por e-mail mora
				 * na entrada do formulário desde a 1.1.0. Um campo cujo impacto
				 * honesto é "preencher não muda nada" não é campo: é armadilha
				 * na tela de quem opera. A subchave CONTINUA no padrão e no
				 * sanitizador, então o valor que o agente gravar ali pelo canal
				 * é preservado como qualquer chave desconhecida.
				 */
				'subcampos' => array(
					'flutuante'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Ativar WhatsApp flutuante', 'f3base' ),
						'descricao' => __( 'Ícone fixo no canto inferior direito em todas as páginas públicas.', 'f3base' ),
						'impacto'   => __( 'Ativado com um número válido, publica um link de WhatsApp independente do menu e do layout. Desativado, o plugin não publica esse ícone. Os botões do tema são definidos pelo próprio layout.', 'f3base' ),
						'exemplo'   => __( 'Marque para manter o contato disponível durante a rolagem no computador e no celular.', 'f3base' ),
					),
					'whatsapp_e164'   => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Número de WhatsApp', 'f3base' ),
						'descricao' => __( 'Código do país, DDD e número, somente dígitos.', 'f3base' ),
						'impacto'   => __( 'Define o destino do WhatsApp flutuante quando ele estiver ativado. Preencher o número não insere nem altera botões no menu ou no conteúdo. O clique instrumentado respeita o consentimento e os canais configurados.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 5511900000000 — o 55 do país, o 11 do DDD e o número, sem espaço, traço ou parêntese.', 'f3base' ),
					),
					'mensagem_padrao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Mensagem que abre a conversa', 'f3base' ),
						'descricao' => __( 'Texto já escrito na conversa quando o visitante chega ao WhatsApp.', 'f3base' ),
						'impacto'   => __( 'Preenchida, é este texto que aparece escrito na conversa antes de o visitante digitar qualquer coisa — é onde se diz de qual página ele veio. Vazia, o site usa uma frase própria com o nome do site: o botão funciona igual, e só o texto inicial muda.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: "Olá! Vim pelo site e gostaria de falar com a equipe."', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_contato' ),
			),
			'f3base_ga4_measurement_id'     => array(
				'rotulo'    => __( 'Google Analytics 4 — ID da métrica', 'f3base' ),
				'descricao' => __( 'Identificador do fluxo de dados da propriedade do Google Analytics.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site passa a carregar o Google Analytics e a enviar para lá as páginas vistas, os contatos e o comportamento que ele já mede: profundidade de rolagem, seções alcançadas, cliques que saem do site, sinais de dificuldade, erros de página e tempo de carregamento. Vazio, nada disso chega ao Google Analytics — o site continua guardando o resumo próprio, e a análise completa, com público, origem de tráfego e comparação de períodos, deixa de existir.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: G-XXXXXXXXXX. O valor real aparece no fluxo de dados da propriedade.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_de_tag' ),
			),
			'f3base_gtm_container_id'       => array(
				'rotulo'    => __( 'Google Tag Manager — ID do contêiner', 'f3base' ),
				'descricao' => __( 'Identificador do contêiner do Gerenciador de Tags.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, ele passa a ser o único caminho de medição do site: a página publica o contêiner, entrega os eventos a ele, e as etiquetas diretas do Analytics, da Meta e do LinkedIn deixam de ser publicadas — é assim que nada é contado duas vezes. Vazio, o site publica as etiquetas diretas de cada identificador preenchido nesta seção.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: GTM-XXXXXXX. O valor real aparece no painel do contêiner.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_de_tag' ),
			),
			'f3base_google_ads'             => array(
				'rotulo'    => __( 'Google Ads — conversão', 'f3base' ),
				'descricao' => __( 'A conta e a ação de conversão que recebem o clique no botão de contato.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'conversion_id'    => '',
					'conversion_label' => '',
				),
				'subcampos' => array(
					'conversion_id'    => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'ID de conversão', 'f3base' ),
						'descricao' => __( 'O identificador da conta de Google Ads que recebe a conversão.', 'f3base' ),
						'impacto'   => __( 'Preenchido junto com o rótulo, o clique no botão de contato passa a ser registrado como conversão na conta do Google Ads, e as campanhas passam a otimizar por ele em vez de otimizar por cliques. Faltando este campo, nenhuma conversão é enviada ao Google Ads e o investimento continua sendo decidido sem saber quem procurou contato.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo, na forma que o próprio Google usa na documentação: AW-000000000. O valor real aparece na ação de conversão da conta.', 'f3base' ),
					),
					'conversion_label' => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Rótulo da conversão', 'f3base' ),
						'descricao' => __( 'A segunda metade do endereço da conversão: qual ação da conta recebe o clique.', 'f3base' ),
						'impacto'   => __( 'É ele que diz QUAL ação de conversão recebe o clique. Preenchido junto com o ID, a conversão chega à ação certa. Vazio, nada é enviado: um envio sem rótulo chegaria à conta sem dizer a que ação pertence, e o relatório de campanha não teria onde somá-lo.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: rotulo-da-acao-de-conversao. O valor real é gerado pelo Google junto com a ação e aparece ao lado do ID de conversão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_google_ads' ),
			),
			'f3base_meta_pixel_id'          => array(
				'rotulo'    => __( 'Meta — Pixel', 'f3base' ),
				'descricao' => __( 'Identificador do Pixel usado por campanhas de Facebook e Instagram.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica o Pixel da Meta e envia a ele as páginas vistas e o contato — é o que permite às campanhas de Facebook e Instagram saber o que aconteceu depois do clique no anúncio. Vazio, nenhum código da Meta existe na página e essas campanhas otimizam sem resultado de volta.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 000000000000000 — somente dígitos. O valor real aparece no Gerenciador de Eventos da Meta.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_de_tag' ),
			),
			/*
			 * O TOKEN DA CONVERSIONS API É SEGREDO, e por isso ele mora AQUI e
			 * em lugar nenhum do `config/site.json`. O arquivo único viaja
			 * dentro do zip, é lido pela suíte e chega a quem faz o upload:
			 * segredo em arquivo que viaja é segredo copiado. Nenhum lote do
			 * implantador grava esta option, e a ausência dela no schema é a
			 * declaração disso. Quem a grava é o agente, pelo canal.
			 */
			'f3base_meta_capi_token'        => array(
				'rotulo'    => __( 'Meta — token do envio de servidor', 'f3base' ),
				'descricao' => __( 'Credencial do conjunto de dados do Pixel, usada para enviar o contato do servidor.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				/*
				 * `SEGREDO`, E NÃO `TEXTO` — e essa palavra era o defeito.
				 *
				 * O DEFEITO MEDIDO num WordPress real: com `campo => 'texto'`, a
				 * máscara de `F3Base_Registro::linha_de_option()` — que testa
				 * `'segredo' === $campo` — não cobria este token, e ele saía EM
				 * CLARO em dois lugares ao mesmo tempo: no `value=` do input da
				 * tela e no JSON de `F3Base_Registro::relatorio()`, que é servido
				 * pela rota `/relatorio` a qualquer administrador. Quem abrisse a
				 * tela, quem lesse o relatório e qualquer captura de tela levavam
				 * junto a credencial de servidor da Meta — que autoriza enviar
				 * eventos de conversão em nome do anunciante.
				 *
				 * `SEGREDO` NÃO SIGNIFICA "SEM CAMPO NA TELA", e é por isso que
				 * `operavel` continua verdadeiro. Este token é gravado por quem
				 * opera o site, e tirá-lo da tela empurraria o operador para o
				 * canal ou para um plugin de terceiro. O que a declaração muda é
				 * COMO o campo é renderizado: entrada mascarada, valor nunca
				 * reimpresso, vazio significando "mantenha o que está gravado" e
				 * uma caixa própria para apagar. A regra está em
				 * `F3Base_Admin_Tela::render_campo_de_segredo()`.
				 */
				'campo'     => 'segredo',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o contato passa a ser enviado também do servidor para a Meta, com o mesmo identificador de evento que o navegador manda — é essa identidade que faz os dois caminhos contarem uma conversão só, e é ela que recupera as conversões que o navegador perde por bloqueio ou por falha de rede. Vazio, existe apenas o envio pelo navegador, e o que ele perder está perdido.', 'f3base' ),
				'exemplo'   => __( 'Este campo não tem exemplo de valor, porque um valor de exemplo aqui seria uma credencial. O token é gerado no Gerenciador de Eventos da Meta, nas configurações do conjunto de dados do Pixel. Ele é o único campo desta tela que nunca viaja no arquivo de configuração do pacote: é gravado só aqui, ou pelo canal de manutenção.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_segredo_opaco' ),
			),
			'f3base_linkedin_partner_id'    => array(
				'rotulo'    => __( 'LinkedIn — identificador de parceiro', 'f3base' ),
				'descricao' => __( 'Identificador da conta de anúncios do LinkedIn.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica a etiqueta do LinkedIn e passa a registrar as páginas vistas por quem chega de campanhas de lá. Vazio, nenhum código do LinkedIn existe na página e as campanhas do canal ficam sem retorno de audiência.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 0000000 — somente dígitos. O valor real aparece no Campaign Manager do LinkedIn.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_partner_id' ),
			),
			'f3base_linkedin_conversion_id' => array(
				'rotulo'    => __( 'LinkedIn — conversão', 'f3base' ),
				'descricao' => __( 'Identificador da conversão do LinkedIn disparada no clique do botão de contato.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o clique no botão de contato passa a ser registrado como conversão no LinkedIn, e as campanhas de lá passam a otimizar por contato. Vazio, o identificador de parceiro sozinho registra apenas visitas: nenhuma conversão é declarada.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 00000000 — somente dígitos. O valor real é gerado ao criar a conversão no Campaign Manager do LinkedIn.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_partner_id' ),
			),
			'f3base_atribuicao'             => array(
				'rotulo'    => __( 'Origem do contato', 'f3base' ),
				'descricao' => __( 'Qual campanha leva o crédito pelo contato, e por quanto tempo ela o mantém.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'modelo'   => F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE,
					'ttl_dias' => 30,
				),
				'subcampos' => array(
					'modelo'   => array(
						'tipo'      => 'enum',
						'rotulo'    => __( 'Campanha que leva o crédito', 'f3base' ),
						'descricao' => __( 'A primeira que trouxe o visitante, ou a última antes do contato.', 'f3base' ),
						'opcoes'    => array(
							F3Base_Vocabulario::ATRIBUICAO_PRIMEIRO_TOQUE => __( 'a primeira visita — a campanha que descobriu o cliente', 'f3base' ),
							'last-touch' => __( 'a última visita — a campanha que fechou o contato', 'f3base' ),
						),
						'impacto'   => __( 'Escolher a primeira visita credita quem descobriu o cliente, e favorece campanhas de topo; escolher a última credita quem estava lá no momento do contato, e favorece campanhas de retomada. O relatório de cada canal muda com esta escolha, e comparar dois períodos com escolhas diferentes compara coisas diferentes.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: a primeira visita, que é o padrão deste site.', 'f3base' ),
					),
					'ttl_dias' => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias a origem é lembrada', 'f3base' ),
						'descricao' => __( 'Prazo em que a origem do visitante continua guardada no navegador dele.', 'f3base' ),
						'impacto'   => __( 'É a janela em que o visitante pode sumir e voltar sem perder a origem. Um prazo curto credita como direto quem voltou depois dele; um prazo longo mantém a campanha antiga levando o crédito muito depois de ela ter deixado de influenciar a decisão.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 30, o prazo que este site usa por padrão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_atribuicao' ),
			),
			'f3base_verificacao_google'     => array(
				'rotulo'    => __( 'Verificação de domínio — Google', 'f3base' ),
				'descricao' => __( 'Código que comprova ao Google que este domínio é seu.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica no cabeçalho a etiqueta que comprova a posse do domínio, e a propriedade do Search Console pode ser verificada — é o que destrava o relatório de busca e o envio de sitemap. Vazio, nenhuma etiqueta é publicada; a verificação por DNS continua sendo uma alternativa que dispensa este campo.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: valor-de-verificacao-do-console. O valor real é fornecido pelo Search Console ao escolher a verificação por etiqueta HTML.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_token_de_verificacao' ),
			),
			'f3base_verificacao_meta'       => array(
				'rotulo'    => __( 'Verificação de domínio — Meta', 'f3base' ),
				'descricao' => __( 'Código que comprova à Meta que este domínio é seu.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'texto',
				'padrao'    => '',
				'impacto'   => __( 'Preenchido, o site publica a etiqueta que reivindica o domínio no Gerenciador de Negócios — é o que permite controlar quem pode anunciar com links deste site e configurar eventos de página. Vazio, nenhuma etiqueta é publicada e o domínio permanece sem dono declarado para a Meta.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: valor-de-verificacao-do-dominio. O valor real é fornecido pelo Gerenciador de Negócios ao reivindicar o domínio.', 'f3base' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_token_de_verificacao' ),
			),
			'f3base_consentimento'          => array(
				'rotulo'    => __( 'Consentimento', 'f3base' ),
				'descricao' => __( 'O que o site faz antes de o visitante decidir, e como ele muda de ideia depois.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_CONSENTIMENTO,
				'campo'     => 'grupo',
				/*
				 * `AVISO_PRIMEIRA_VISITA` NASCE DESLIGADO, e ele governa uma coisa
				 * só: a faixa mostrada a quem chega pela primeira vez. Houve uma
				 * versão em que ele nascia LIGADO porque o apelido do visitante
				 * dependia dele — no modo pré-aprovado, `podeIdentificar()` exigia
				 * o banner —, e o padrão ligado existia só para o site não sair
				 * cego. Essa regra foi revertida: o apelido segue o PORTÃO do
				 * consentimento, e este campo voltou a ser o que a palavra diz. O
				 * padrão desligado é o do projeto: quem quiser a faixa liga-a, e
				 * ligar ou desligar não muda mais o que é medido.
				 */
				'padrao'    => array(
					'padrao'                => 'pre-aprovado',
					'controle_rodape'       => true,
					'aviso_primeira_visita' => false,
					'ttl_dias'              => 180,
				),
				'subcampos' => array(
					'padrao'                => array(
						'tipo'      => 'enum',
						'rotulo'    => __( 'O que vale antes de o visitante decidir', 'f3base' ),
						'descricao' => __( 'A posição do site na primeira visita, antes de qualquer clique do visitante.', 'f3base' ),
						'opcoes'    => array(
							'pre-aprovado' => __( 'pré-aprovado — a medição começa e o visitante pode recusar', 'f3base' ),
							'negado'       => __( 'negado — nada é medido até o visitante aceitar', 'f3base' ),
						),
						'impacto'   => __( 'Em pré-aprovado, a medição começa na primeira visita e quem recusa interrompe a partir do clique: os números cobrem quase todo mundo. Em negado, nada é carregado até o aceite, e os números passam a cobrir só quem aceitou — a diferença aparece como queda de tráfego no relatório, sem que o tráfego tenha caído. A escolha é jurídica antes de ser técnica. O QUE A RECUSA TARDIA NÃO DESFAZ: ela vale do clique em diante e não apaga o que já foi enviado. Google Analytics e Google Ads recebem a recusa como atualização de consentimento e passam a operar sem armazenamento no dispositivo; o que já chegou ao Google permanece com ele. Pixel da Meta e Insight Tag do LinkedIn não têm mecanismo equivalente: se o script deles já carregou nesta página, recusar não o descarrega — ele fica ali até a navegação seguinte. O que este site garante a partir da recusa é que nenhum evento novo é enviado a eles, e que na página seguinte eles não voltam a ser carregados. Em negado nada disso chega a carregar, e é por isso que nesse modo o script de consentimento é servido bloqueando o carregamento da página: ali a ordem é a garantia, e ela custa os 5.085 bytes comprimidos desse script no caminho crítico da página.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: pré-aprovado, que é a posição deste site.', 'f3base' ),
					),
					'controle_rodape'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Link de revisão no rodapé', 'f3base' ),
						'descricao' => __( 'Instrumento permanente para o visitante rever a decisão dele.', 'f3base' ),
						'impacto'   => __( 'Ligado, toda página ganha no rodapé um link que reabre a decisão — é o caminho pelo qual quem aceitou pode recusar depois, e a demonstração de que a escolha é reversível. Desligado, o visitante que mudar de ideia não tem por onde: a decisão dele fica presa até o prazo abaixo vencer.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
					'aviso_primeira_visita' => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Aviso na primeira visita', 'f3base' ),
						'descricao' => __( 'Faixa não bloqueante exibida a quem chega pela primeira vez.', 'f3base' ),
						'impacto'   => __( 'Ligado, quem chega pela primeira vez vê uma faixa na base da página avisando que o site mede a navegação; ela não bloqueia a leitura, não espera resposta e oferece o controle do rodapé. O link da política de privacidade aparece quando houver uma página pública válida. Desligado — que é como o site é entregue —, o único ponto de decisão visível é o link do rodapé, que está em toda página publicada. Este campo NÃO decide o que é medido: a medição segue a política de consentimento acima, e o registro por visitante nasce onde ela permite medir, com ou sem a faixa.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: desligado, que é como este site é entregue.', 'f3base' ),
					),
					'ttl_dias'              => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias a decisão vale', 'f3base' ),
						'descricao' => __( 'Prazo em que a recusa e o novo aceite continuam guardados no navegador.', 'f3base' ),
						'impacto'   => __( 'É o prazo em que a recusa continua sendo respeitada sem perguntar de novo. Vencido, o visitante volta à posição padrão do site e é medido outra vez até recusar de novo. Prazo curto pergunta demais; prazo longo mantém a decisão por mais tempo do que ela costuma ser lembrada.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 180, o prazo que este site usa por padrão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_consentimento' ),
			),
			'f3base_retencao_meses'         => array(
				'rotulo'    => __( 'Guarda dos contatos recebidos (meses)', 'f3base' ),
				'descricao' => __( 'Por quanto tempo os registros de contato ficam no site antes da limpeza automática.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'inteiro',
				'padrao'    => 12,
				'impacto'   => __( 'É o prazo que a limpeza automática usa: passado ele, o registro do contato vai para a lixeira e depois é eliminado, com o número de registros anotado. Um prazo longo mantém disponível o histórico comercial e mantém dado pessoal guardado por mais tempo do que a finalidade justifica; um prazo curto faz o contrário. O prazo declarado aqui governa a limpeza mesmo quando o site não tem uma página de política de privacidade. ZERO NÃO É ACEITO e não vira nada: a gravação é RECUSADA e o prazo anterior continua valendo — o mínimo é um mês.', 'f3base' ),
				'exemplo'   => __( 'Ilustrativo: 12, o prazo que este site usa por padrão.', 'f3base' ),
				'minimo'    => 1,
				/*
				 * A RECUSA É O INSTRUMENTO AQUI, e não a normalização.
				 *
				 * O DEFEITO MEDIDO: a tela aceitava `0` (`min="0"` no input) e o
				 * sanitizador o ELEVAVA a 1 em silêncio. Quem digitava zero
				 * queria desligar a limpeza automática; o que ele obtinha era o
				 * prazo MAIS CURTO POSSÍVEL, e a rotina do dia seguinte apagava
				 * todo lead com mais de um mês. Um valor que significa o oposto
				 * do que foi pedido é pior que uma recusa, e infinitamente pior
				 * que um erro: a recusa devolve a decisão a quem a tomou.
				 *
				 * NÃO EXISTE "NUNCA APAGAR" NESTE CAMPO, e isso é declarado no
				 * motivo da recusa: o prazo é o que a política de privacidade do
				 * site promete, e prazo infinito de dado pessoal não é um prazo.
				 */
				'recusa'    => array( __CLASS__, 'recusa_retencao_meses' ),
				'sanitiza'  => array( __CLASS__, 'sanitiza_retencao_meses' ),
			),
			'f3base_acessos'                => array(
				'rotulo'    => __( 'Acessos do servidor', 'f3base' ),
				'descricao' => __( 'Contagem dos logs fechados em Medição → Acessos.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado'             => true,
					'padrao_do_log'      => F3Base_Modulo_Acessos_Servidor::padrao_do_log(),
					'caminhos_excluidos' => F3Base_Modulo_Acessos_Servidor::EXCLUIDOS,
					'retencao_meses'     => 25,
				),
				'subcampos' => array(
					'ligado'             => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Somar acessos do servidor', 'f3base' ),
						'descricao' => __( 'Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.', 'f3base' ),
						'impacto'   => __( 'Soma logs datados disponíveis e preserva o histórico agregado quando desligado. Não recupera arquivos apagados pelo host.', 'f3base' ),
						'exemplo'   => __( 'Ligado.', 'f3base' ),
					),
					'padrao_do_log'      => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Padrão dos arquivos de log', 'f3base' ),
						'descricao' => __( 'Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.', 'f3base' ),
						'impacto'   => __( 'Use um diretório exclusivo deste site e arquivos access.log.AAAA-MM-DD. O padrão resolve ~ pelo ambiente, usuário do PHP e ascendentes do WordPress. Múltiplos diretórios são recusados; um caminho absoluto define a origem explicitamente.', 'f3base' ),
						'exemplo'   => __( '~/logs/exemplo.com.br/https/access.log.*', 'f3base' ),
					),
					'caminhos_excluidos' => array(
						'tipo'      => 'lista',
						'rotulo'    => __( 'Prefixos excluídos do detalhe', 'f3base' ),
						'descricao' => __( 'Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.', 'f3base' ),
						'impacto'   => __( 'Os caminhos correspondentes contam somente no rodapé, sem guardar o caminho. Adicione rotas privadas do seu site. URLs públicas podem conter dados pessoais no caminho. Mudanças reclassificam apenas os arquivos ainda disponíveis.', 'f3base' ),
						'exemplo'   => __( '/wp-admin/, /wp-json/mcp/', 'f3base' ),
					),
					'retencao_meses'     => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Retenção do agregado em meses', 'f3base' ),
						'descricao' => __( 'Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.', 'f3base' ),
						'impacto'   => __( 'Apaga agregados mais antigos que o prazo. A tela consulta até noventa dias; o histórico restante fica no banco para consultas futuras.', 'f3base' ),
						'exemplo'   => __( '25 meses.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_acessos' ),
				'recusa'    => array( __CLASS__, 'recusa_acessos' ),
			),
			'f3base_acessos_estado'         => array(
				'rotulo'          => __( 'Estado da soma de acessos', 'f3base' ),
				'descricao'       => __( 'Arquivos processados, cobertura e última execução; sem conteúdo bruto do log.', 'f3base' ),
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(),
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array( __CLASS__, 'sanitiza_lista_generica' ),
			),
			'f3base_sessao'                 => array(
				'rotulo'    => __( 'Sessão de login', 'f3base' ),
				'descricao' => __( 'Prazo dos novos logins pelo formulário nativo. O diagnóstico informa o valor efetivo.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado' => true,
					'dias'   => 90,
				),
				'subcampos' => array(
					'ligado' => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Manter login ao fechar o navegador', 'f3base' ),
						'descricao' => __( 'Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.', 'f3base' ),
						'impacto'   => __( 'Aplica o prazo aos novos logins e marca Lembrar-me no formulário nativo. Desligar não revoga cookies já emitidos.', 'f3base' ),
						'exemplo'   => __( 'Ligado.', 'f3base' ),
					),
					'dias'   => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Duração das novas sessões em dias', 'f3base' ),
						'descricao' => __( 'Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.', 'f3base' ),
						'impacto'   => __( 'Aceita de um a trezentos e sessenta e cinco dias. Um cookie roubado permite acesso pelo prazo restante; Sair de todos os outros dispositivos revoga as demais sessões.', 'f3base' ),
						'exemplo'   => __( '90 dias.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_sessao' ),
				'recusa'    => array( __CLASS__, 'recusa_sessao' ),
			),
			'f3base_comportamento'          => array(
				'rotulo'    => __( 'Resumo de comportamento no próprio site', 'f3base' ),
				'descricao' => __( 'O resumo que o site guarda por conta própria sobre como as páginas são usadas.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado'                => true,
					'retencao_dias'         => 90,
					'retencao_eventos_dias' => 30,
					'dias_no_painel'        => 28,
				),
				'subcampos' => array(
					'ligado'                => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Guardar o resumo no site', 'f3base' ),
						'descricao' => __( 'O resumo é somado por dia e por página, sem identificar visitante.', 'f3base' ),
						'impacto'   => __( 'Ligado, ao sair de cada página o navegador envia uma vez os totais daquela visita — marcos de rolagem, seções vistas, cliques para fora, sinais de dificuldade, erros e tempo de carregamento — e o site os soma na linha do dia. É o que faz o quadro desta tela ter números sem depender de conta nenhuma de fornecedor. Desligado, nada é enviado nem guardado, e o quadro fica permanentemente vazio; o envio ao Google Analytics, quando configurado, não muda.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
					'retencao_dias'         => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias o resumo é guardado', 'f3base' ),
						'descricao' => __( 'Prazo depois do qual as linhas antigas do resumo são apagadas pela limpeza automática.', 'f3base' ),
						'impacto'   => __( 'A limpeza que já roda no site apaga as linhas mais antigas que este prazo. Um prazo maior permite comparar períodos distantes e faz a tabela crescer; um prazo menor mantém a tabela pequena e impede a comparação com o mesmo mês do ano passado. Este quadro não é arquivo histórico: quem precisa de série longa a tem no Google Analytics.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 90, o prazo que este site usa por padrão.', 'f3base' ),
					),
					'retencao_eventos_dias' => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Por quantos dias o registro detalhado é guardado', 'f3base' ),
						'descricao' => __( 'Prazo do registro que guarda visitante, sessão e horário de cada acontecimento — mais curto que o do resumo, e nunca maior.', 'f3base' ),
						'impacto'   => __( 'O site guarda duas coisas diferentes. O RESUMO soma por dia e por página e não identifica ninguém; o REGISTRO DETALHADO guarda, para cada acontecimento, um apelido sorteado do navegador do visitante, o identificador da visita e o horário com precisão de milésimo — é ele que responde quanto tempo a pessoa levou para descer a página e se ela voltou e leu de novo. Por guardar isso, ele é dado pessoal, ainda que o apelido não diga quem a pessoa é: o prazo dele é curto de propósito e nunca pode passar o do resumo. Vencido o prazo, as linhas detalhadas são apagadas pela mesma limpeza automática e o resumo continua, porque ele não identifica ninguém.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 30, o prazo que este site usa por padrão.', 'f3base' ),
					),
					'dias_no_painel'        => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Período mostrado no quadro', 'f3base' ),
						'descricao' => __( 'Quantos dias o quadro desta tela soma ao exibir os números.', 'f3base' ),
						'impacto'   => __( 'Muda apenas o que esta tela mostra, nunca o que é guardado. Um período curto revela o efeito de uma mudança recente; um período longo dilui o dia atípico e mostra a tendência. O número aparece ao lado de cada total, para que ninguém leia o quadro sem saber de quantos dias ele fala. O TETO DELE É O PRAZO DO RESUMO, o campo duas linhas acima — e os quadros que vêm do REGISTRO DETALHADO cobrem o prazo DELE, que é o campo logo acima e é sempre menor ou igual: pedir aqui mais dias do que o registro guarda continua valendo para a série do agregado, e a tela Medição avisa quando os dois períodos divergem.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 28, o período que este site usa por padrão.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_comportamento' ),
			),
			'f3base_origem_confiavel'       => array(
				'rotulo'    => __( 'Como o site descobre o endereço do visitante', 'f3base' ),
				'descricao' => __( 'Quando o site está atrás de CDN ou proxy, o endereço real chega num cabeçalho.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'cabecalho'        => '',
					'saltos'           => 1,
					/*
					 * LISTA VAZIA É A PROTEÇÃO DESLIGADA, e ela é ligada por quem
					 * declara a faixa. Nome de cabeçalho não é autenticação —
					 * cabeçalho é texto que qualquer cliente manda —, e por isso
					 * a lista vazia sai AVISADA na tela, com o nome deste campo.
					 * O que ela não faz é mudar sozinha o que o site já fazia:
					 * uma atualização que passasse a ignorar o cabeçalho de toda
					 * instalação existente quebraria o rate limit e o endereço
					 * enviado ao fornecedor em cada uma delas, em silêncio.
					 */
					'redes_confiaveis' => array(),
				),
				'subcampos' => array(
					'cabecalho'        => array(
						'tipo'      => 'texto',
						'rotulo'    => __( 'Cabeçalho em que este site confia', 'f3base' ),
						'descricao' => __( 'Nome do cabeçalho que a sua CDN ou proxy escreve com o endereço do visitante.', 'f3base' ),
						'impacto'   => __( 'Preenchido, o limite de envios por visitante passa a contar cada visitante separadamente mesmo atrás de CDN. Vazio — que é o padrão e é a posição segura —, o site conta pelo endereço da conexão: atrás de CDN esse endereço é o mesmo para todo mundo, e um único visitante intenso pode esgotar o limite do site inteiro. Preencher com o nome errado é pior que deixar vazio: o visitante passaria a escolher em que balde ele conta.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: X-Forwarded-For, ou CF-Connecting-IP em sites atrás da Cloudflare. Só preencha o cabeçalho que a sua hospedagem confirmar.', 'f3base' ),
					),
					'saltos'           => array(
						'tipo'      => 'inteiro',
						'rotulo'    => __( 'Em que posição da lista está o endereço do visitante', 'f3base' ),
						'descricao' => __( 'Usado apenas quando o cabeçalho acima está preenchido.', 'f3base' ),
						/*
						 * A FRASE ANTERIOR DESCREVIA O PENÚLTIMO ELEMENTO. Ela
						 * dizia "descontando esta quantidade a partir do fim", e
						 * o código faz `count( $lista ) - $saltos`, que é a
						 * POSIÇÃO contada do fim: com 1 ele lê o ÚLTIMO. Quem
						 * tinha uma CDN só e lia a frase escrevia 2, e o site
						 * passava a ler a ponta que o próprio visitante
						 * escreveu — o defeito exato que esta chave existe para
						 * impedir.
						 */
						'impacto'   => __( 'É a POSIÇÃO contada do fim da lista do cabeçalho: 1 é o último elemento, que é o único escrito pelo seu próprio proxy. Um número menor que o real faz o site ler um endereço que o visitante escreveu; um número maior faz a leitura falhar e voltar ao endereço da conexão.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 1, quando há uma única CDN na frente do site.', 'f3base' ),
					),
					'redes_confiaveis' => array(
						'tipo'      => 'lista',
						'rotulo'    => __( 'De quais endereços os seus proxies falam com o site', 'f3base' ),
						'descricao' => __( 'Faixas de IP da sua CDN ou do seu balanceador, uma por linha, em notação de endereço ou de rede.', 'f3base' ),
						'impacto'   => __( 'Preenchidas, só o pedido que chega de uma dessas faixas tem o cabeçalho acima lido; os outros voltam a contar pelo endereço da conexão. VAZIAS — que é como o site é entregue —, o cabeçalho acima é lido de QUALQUER conexão, e a tela emite um aviso apontando este campo: cabeçalho é texto que qualquer cliente manda, e quem alcança o servidor por fora da CDN escolhe em que balde do limite ele conta e qual endereço o site envia aos fornecedores de anúncio. É esta lista que fecha essa porta, e ela só é fechada por quem declara as faixas.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: 198.51.100.0/24 numa linha e 203.0.113.7 na outra. Só declare faixa que a sua hospedagem confirmar.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_origem_confiavel' ),
			),
			'f3base_robots'                 => array(
				'rotulo'       => __( 'Robots.txt do plugin', 'f3base' ),
				'descricao'    => __( 'Alterna entre o gerador do plugin e o arquivo físico original, com backup e restauração.', 'f3base' ),
				'operavel'     => true,
				'secao'        => self::SECAO_PRIVACIDADE,
				'campo'        => 'grupo',
				'padrao'       => array( 'ligado' => true ),
				'subcampos'    => array(
					'ligado' => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Utilizar o robots.txt do plugin', 'f3base' ),
						'descricao' => __( 'Ligado, guarda o original e verifica a entrega pública. Se a hospedagem interceptar a rota virtual, mantém um arquivo físico gerenciado e atualizado automaticamente.', 'f3base' ),
						'impacto'   => __( 'Publica as regras do WordPress e dos plugins, com o sitemap disponível. O WP-Cron confirma a resposta HTTP e atualiza o arquivo gerenciado a cada hora e após mudanças reconhecidas de configuração. Desligado, retira somente o arquivo que ainda corresponde ao conteúdo gerado e restaura o original. Edições externas são preservadas. Sem original anterior, não cria um ao desligar. O diagnóstico informa falhas, conflitos e verificações pendentes.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, com o sitemap do núcleo ou do plugin de SEO.', 'f3base' ),
					),
				),
				'sanitiza'     => array( __CLASS__, 'sanitiza_robots' ),
				'apos_escrita' => array( 'F3Base_Robots_Arquivo', 'ao_gravar' ),
				'verifica'     => array( 'F3Base_Robots_Arquivo', 'verificar_configuracao' ),
			),
			'f3base_robots_backup'          => array(
				'rotulo'          => __( 'Backup do robots.txt original', 'f3base' ),
				'descricao'       => __( 'Cópia e estado da troca do arquivo físico; preservado na desinstalação para permitir recuperação.', 'f3base' ),
				'operavel'        => false,
				'campo'           => 'grupo',
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => false,
				'padrao'          => array(
					'original_existe' => false,
					'conteudo_base64' => '',
					'sha256'          => '',
					'caminho'         => '',
					'reserva'         => '',
					'modo'            => 0644,
					'etapa'           => '',
					'suspenso'        => false,
					'erro'            => '',
					'geracao'         => '',
					'gerenciado'      => array(),
					'entrega'         => array(),
				),
				'sanitiza'        => array( __CLASS__, 'sanitiza_robots_backup' ),
			),
			'f3base_llms'                   => array(
				'rotulo'    => __( 'Arquivo llms.txt para leitores automáticos', 'f3base' ),
				'descricao' => __( 'Índice curto que apresenta o site a assistentes e agentes que o leem.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'ligado'               => true,
					'introducao'           => '',
					'apresentacao'         => '',
					'modo'                 => F3Base_Llms::MODO_MISTO,
					'tipos'                => array( 'page', 'post' ),
					'full'                 => false,
					'markdown'             => true,
					'indexavel'            => true,
					'politica_privacidade' => array(),
					'livres'               => array(),
				),
				'subcampos' => array(
					'ligado'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Publicar o llms.txt', 'f3base' ),
						'descricao' => __( 'Serve o arquivo em /llms.txt quando não existe um arquivo físico na raiz.', 'f3base' ),
						'impacto'   => __( 'Ligado, o endereço /llms.txt passa a responder com um índice curto das páginas escolhidas — oferece contexto e links aos assistentes que consultam esse arquivo, sem garantir uso ou citação. Desligado, o endereço deixa de responder e a leitura automática volta a depender de rastreamento comum. Um arquivo físico na raiz do site sempre tem precedência sobre esta chave.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
					'introducao'   => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Primeira frase do arquivo', 'f3base' ),
						'descricao' => __( 'Uma linha dizendo do que este site trata.', 'f3base' ),
						'impacto'   => __( 'Preenchida, é a primeira frase que um leitor automático encontra, e ela resume o contexto do site. Vazia, o site usa a apresentação abaixo e, se ela também estiver vazia, a descrição cadastrada nas configurações gerais do WordPress — que serve, mas foi escrita para outra finalidade.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: "Consultoria de operações para indústrias de médio porte, com atendimento em todo o país."', 'f3base' ),
					),
					'apresentacao' => array(
						'tipo'      => 'textarea',
						'rotulo'    => __( 'Apresentação do negócio', 'f3base' ),
						'descricao' => __( 'Um parágrafo dizendo o que o site é, para quem e com que oferta.', 'f3base' ),
						/*
						 * A FRASE ANTERIOR CONTRADIZIA A DO CAMPO ACIMA na
						 * mesma tela: `introducao` promete ser a primeira frase
						 * e dizer que, vazia, o site usa ESTA apresentação; esta
						 * dizia que, vazia, o site "cai para a primeira frase
						 * acima". As duas não podiam estar certas ao mesmo
						 * tempo, e quem descreve o código é a de `introducao`.
						 */
						'impacto'   => __( 'Descreve o site antes da lista de links quando o campo acima está vazio. Com a primeira frase preenchida, é ELA que sai, e este parágrafo fica de reserva; com os dois vazios, o arquivo usa a descrição cadastrada no WordPress. O texto oferece contexto ao leitor, sem garantir citações ou presença em respostas de assistentes.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: "Somos uma consultoria de operações industriais para fábricas de 50 a 500 funcionários. Fazemos diagnóstico de linha, redesenho de processo e acompanhamento de indicadores, com contrato mensal e equipe em campo."', 'f3base' ),
					),
					'modo'         => array(
						'tipo'      => 'enum',
						'rotulo'    => __( 'Como a lista é formada', 'f3base' ),
						'descricao' => __( 'A escolha entre listar só o que foi escolhido na entrega e listar também o que for publicado depois.', 'f3base' ),
						'opcoes'    => self::opcoes_de_modo_llms(),
						'impacto'   => __( 'Listando apenas o escolhido na entrega, o arquivo é previsível e toda página criada depois fica de fora para sempre. Listando apenas o publicado, ele acompanha o site e perde a ordem que alguém escolheu. Com os dois — que é como este site é entregue —, a curadoria vem primeiro e o resto entra em seguida: o arquivo continua vivo quando o site cresce, sem perder a ordem escolhida.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: os dois eixos juntos, com a lista escolhida na entrega à frente do que for publicado depois.', 'f3base' ),
					),
					'tipos'        => array(
						'tipo'            => 'multiescolha',
						'rotulo'          => __( 'Tipos de conteúdo enumerados', 'f3base' ),
						'opcoes_callback' => array( __CLASS__, 'opcoes_de_tipos_llms' ),
						'descricao'       => __( 'Selecione os tipos públicos disponíveis neste site. Usado nos modos que enumeram o conteúdo publicado.', 'f3base' ),
						'impacto'         => __( 'Os tipos marcados participam da lista automática do llms.txt e do llms-full.txt. Conteúdos privados, com senha ou noindex continuam excluídos. Desmarcar todos esvazia a seleção automática; os itens de curadoria continuam seguindo o modo escolhido.', 'f3base' ),
						'exemplo'         => __( 'Ilustrativo: as páginas e os artigos do blog, que é como este site é entregue.', 'f3base' ),
					),
					'markdown'     => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Publicar páginas em Markdown', 'f3base' ),
						'descricao' => __( 'Disponibiliza versões de leitura das páginas públicas selecionadas e as anuncia no HTML.', 'f3base' ),
						'impacto'   => __( 'Ligado, os links locais do índice apontam para alternativas Markdown. Conteúdo privado, com senha ou noindex fica fora. Desligado, os links apontam para o HTML. A conversão inclui o conteúdo editorial salvo; blocos dinâmicos e shortcodes não são executados.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: uma página de serviços ganha a alternativa /servicos/index.md.', 'f3base' ),
					),
					'full'         => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Publicar também o texto integral', 'f3base' ),
						'descricao' => __( 'Serve /llms-full.txt com o conteúdo completo de cada item listado, em Markdown e sem resumo.', 'f3base' ),
						'impacto'   => __( 'Ligado, o endereço /llms-full.txt passa a responder com o texto integral das mesmas páginas — reúne o corpo completo em um único arquivo, preservando títulos, listas, links e código. Usa a mesma seleção pública do índice e não corta textos pelo limite de palavras dos resumos. É uma segunda cópia do site em texto puro, com o custo de banda e de superfície que isso traz. Desligado, que é o padrão, o endereço não responde: nenhum hook é registrado e a rota não existe.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: desligado, que é como este site é entregue.', 'f3base' ),
					),
					'indexavel'    => array(
						'tipo'      => 'booleano',
						'rotulo'    => __( 'Deixar o arquivo ser indexado', 'f3base' ),
						'descricao' => __( 'Controla o cabeçalho X-Robots-Tag na resposta do arquivo.', 'f3base' ),
						'impacto'   => __( 'Ligado, não solicita exclusão dos índices. Desligado, envia X-Robots-Tag: noindex para indexadores que respeitam a diretiva. Isso não bloqueia leitura, não é controle de treinamento de IA e não protege conteúdo. Alternativas Markdown usam noindex e apontam a página HTML canônica. As respostas usam cache interno com invalidação e exigem revalidação HTTP.', 'f3base' ),
						'exemplo'   => __( 'Ilustrativo: ligado, que é como este site é entregue.', 'f3base' ),
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_llms' ),
			),
			'f3base_redirects'              => array(
				'rotulo'     => __( 'Redirects declarados', 'f3base' ),
				'descricao'  => __( 'Pares origem/destino do próprio site aplicados antes do 404, além do redirecionamento por slug antigo.', 'f3base' ),
				'operavel'   => false,
				'campo'      => 'grupo',
				'padrao'     => array(),
				'na_escrita' => array( __CLASS__, 'escrita_de_redirects' ),
				'sanitiza'   => array( __CLASS__, 'sanitiza_redirects' ),
			),
			'f3base_auditoria_pendente'     => array(
				'rotulo'          => 'Tentativas de auditoria',
				'descricao'       => 'Estado operacional limitado, sem corpos de páginas ou segredos.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(),
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array(
					'F3Base_Release_Configuracao',
					'estado',
				),
			),
			'f3base_llms_arquivo_estado'    => array(
				'rotulo'          => 'Arquivo llms gerenciado',
				'descricao'       => 'Estado operacional limitado, sem corpos de páginas ou segredos.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(),
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array(
					'F3Base_Release_Configuracao',
					'estado',
				),
			),
			'f3base_schema_evidencia'       => array(
				'rotulo'          => 'Verificação pública do schema',
				'descricao'       => 'Estado operacional limitado, sem corpos de páginas ou segredos.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(),
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array(
					'F3Base_Release_Configuracao',
					'estado',
				),
			),
			'f3base_google_carregamento'    => array(
				'rotulo'    => 'Carregamento das tags Google',
				'descricao' => 'Controla a inserção de gtag.js direto; não se aplica ao GTM.',
				'operavel'  => true,
				'secao'     => self::SECAO_MEDICAO,
				'campo'     => 'grupo',
				'padrao'    => array(
					'modo'          => 'imediato',
					'teto_segundos' => 5,
				),
				'subcampos' => array(
					'modo'          => array(
						'tipo'      => 'select',
						'rotulo'    => 'Momento do carregamento',
						'descricao' => 'Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.',
						'impacto'   => 'Após interação adia GA4 e Ads; visitas curtas podem terminar antes da entrega. GTM mantém sua própria política.',
						'exemplo'   => 'Imediato para preservar a medição.',
						'opcoes'    => array(
							'imediato'       => 'Imediato',
							'apos_interacao' => 'Após interação ou prazo',
						),
					),
					'teto_segundos' => array(
						'tipo'          => 'inteiro',
						'rotulo'        => 'Prazo após load, em segundos',
						'descricao'     => 'Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.',
						'impacto'       => 'Prazo máximo de espera depois do carregamento da página. Interagir antecipa a liberação, sem conceder consentimento.',
						'exemplo'       => 'Aguardar até cinco segundos.',
						'min'           => 1,
						'max'           => 30,
						'schema_config' => array(
							'type'    => 'integer',
							'minimum' => 1,
							'maximum' => 30,
						),
					),
				),
				'sanitiza'  => array(
					'F3Base_Release_Configuracao',
					'google',
				),
				'recusa'    => array(
					'F3Base_Release_Configuracao',
					'recusar_google',
				),
			),
			'f3base_seo_entidade'           => array(
				'rotulo'    => __( 'Entidade de SEO', 'f3base' ),
				'descricao' => __( 'Propriedades de entidade e serviços usados para estender o grafo do plugin de SEO. sameAs vazio fica vazio.', 'f3base' ),
				'operavel'  => true,
				'secao'     => self::SECAO_PRIVACIDADE,
				'campo'     => 'grupo',
				'padrao'    => array(
					'nome'             => '',
					'same_as'          => array(),
					'area_servida'     => array(),
					'conhece_sobre'    => array(),
					'ponto_de_contato' => array(),
					'organizacao_mae'  => '',
					'servicos'         => array(),
					'faq_schema'       => false,
				),
				'subcampos' => array(
					'nome'             => array(
						'tipo'      => 'texto',
						'rotulo'    => 'Nome',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
					'same_as'          => array(
						'tipo'      => 'json',
						'rotulo'    => 'Same as',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
					'area_servida'     => array(
						'tipo'      => 'json',
						'rotulo'    => 'Area servida',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
					'conhece_sobre'    => array(
						'tipo'      => 'json',
						'rotulo'    => 'Conhece sobre',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
					'ponto_de_contato' => array(
						'tipo'      => 'json',
						'rotulo'    => 'Ponto de contato',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
					'organizacao_mae'  => array(
						'tipo'          => 'json',
						'rotulo'        => 'Organizacao mae',
						'descricao'     => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'       => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'       => 'Valor confirmado pelo responsável do site.',
						'schema_config' => array(
							'type'                 => array(
								'string',
								'object',
							),
							'additionalProperties' => true,
							'properties'           => array(
								'nome' => array(
									'type' => 'string',
								),
								'url'  => array(
									'type' => 'string',
								),
								'id'   => array(
									'type' => 'string',
								),
							),
						),
					),
					'servicos'         => array(
						'tipo'      => 'json',
						'rotulo'    => 'Servicos',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
					'faq_schema'       => array(
						'tipo'      => 'booleano',
						'rotulo'    => 'Faq schema',
						'descricao' => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'impacto'   => 'Dados declarados; vazio mantém o grafo do Yoast. Campos desconhecidos armazenados são preservados.',
						'exemplo'   => 'Valor confirmado pelo responsável do site.',
					),
				),
				'sanitiza'  => array( __CLASS__, 'sanitiza_seo_entidade' ),
			),
			'f3base_cabecalhos'             => array(
				'rotulo'     => __( 'Cabeçalhos de resposta', 'f3base' ),
				'descricao'  => __( 'Cabeçalhos de segurança emitidos no front-end. O COOP EMITIDO É O VALOR GRAVADO, dentro do vocabulário fechado do cabeçalho: fora de same-origin-allow-popups o navegador corta a relação com a janela que o CTA abre, o módulo fecha degradado NOMEANDO essa consequência, e nada é recusado. HSTS desligado por padrão.', 'f3base' ),
				'operavel'   => false,
				'campo'      => 'grupo',
				'padrao'     => array(
					'x_content_type_options' => true,
					'x_frame_options'        => F3Base_Vocabulario::FRAME_MESMA_ORIGEM,
					'csp_frame_ancestors'    => "'self'",
					'referrer_policy'        => F3Base_Vocabulario::REFERRER_ESTRITO_ENTRE_SITES,
					'coop'                   => F3Base_Vocabulario::COOP_PERMITE_POPUP,
					'permissions_policy'     => F3Base_Vocabulario::PERMISSOES_NEGADAS,
					'hsts'                   => false,
					'hsts_max_age'           => 300,
				),
				'na_escrita' => array( __CLASS__, 'escrita_de_cabecalhos' ),
				'sanitiza'   => array( __CLASS__, 'sanitiza_cabecalhos' ),
			),
			'f3base_nav_id'                 => array(
				'rotulo'    => __( 'ID da navegação', 'f3base' ),
				'descricao' => __( 'Post wp_navigation gerenciado. Estrutural: quebrar o vínculo derruba o menu do topo.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'inteiro',
				'padrao'    => 0,
				'sanitiza'  => array( __CLASS__, 'sanitiza_id_post' ),
			),
			'f3base_mcp_files_audit'        => array(
				'rotulo'           => __( 'Auditoria de escritas do canal MCP', 'f3base' ),
				'descricao'        => __( 'Registro mantido pelo complemento do canal. Estrutural: leitura apenas. Guarda as últimas entradas e descarta as mais antigas, registrando o corte na própria lista.', 'f3base' ),
				'operavel'         => false,
				'campo'            => 'grupo',
				'padrao'           => array(),
				/*
				 * `AUTOLOAD => FALSE`, e o defeito era de custo com juros. Esta
				 * option cresce a cada escrita do canal e NÃO é lida em
				 * requisição de visitante nenhuma; com autoload ligado, ela
				 * viajava dentro de `alloptions` — a consulta que roda uma vez
				 * por requisição e é servida de cache — em TODA página do site.
				 * Uma lista de auditoria sem teto e com autoload é um cache que
				 * cresce sem limite, e o limite superior é o do próprio objeto
				 * em memória.
				 */
				'autoload'         => false,
				'estado_execucao'  => true,
				'descartavel'      => true,
				'teto_de_entradas' => 200,
				'sanitiza'         => array( __CLASS__, 'sanitiza_auditoria_do_canal' ),
			),
			'f3base_atividade'              => array(
				'rotulo'          => __( 'Última atividade relevante', 'f3base' ),
				'descricao'       => __( 'Carimbos do que cada módulo fez por último. Estado de execução, não configuração.', 'f3base' ),
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(),
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array( __CLASS__, 'sanitiza_atividade' ),
			),
			'f3base_journal_eliminacao'     => array(
				'rotulo'           => __( 'Journal de eliminação', 'f3base' ),
				'descricao'        => __( 'Identificador, contagem, carimbo, operador e regime de cada eliminação. Nunca o conteúdo eliminado.', 'f3base' ),
				'operavel'         => false,
				'campo'            => 'grupo',
				'padrao'           => array(),
				'autoload'         => false,
				/*
				 * ESTADO DE EXECUÇÃO SIM, DESCARTÁVEL NÃO — e é este par que
				 * mostra por que as duas declarações são separadas. O journal é
				 * escrito pela rotina de eliminação, e não configurado por
				 * ninguém: carimbar procedência nele diria "edição manual" sobre
				 * um cron. Mas ele é a PROVA do que foi apagado e quando, e
				 * apagá-lo junto com o plugin destruiria justamente o registro
				 * que uma auditoria procuraria depois.
				 */
				'estado_execucao'  => true,
				'teto_de_entradas' => 500,
				'sanitiza'         => array( __CLASS__, 'sanitiza_journal' ),
			),
			'f3base_cadencia'               => array(
				'rotulo'    => __( 'Cadência do modo somente-relatório', 'f3base' ),
				'descricao' => __( 'Periodicidade, gatilho por número de ajustes, mecanismo e nome do hook. Gravada pelo implantador e LIDA pelo módulo de cadência do site-core, que é quem engancha o evento e conta os ajustes.', 'f3base' ),
				'operavel'  => false,
				'campo'     => 'grupo',
				'padrao'    => array(
					'periodicidade'  => 'nenhuma',
					'apos_n_ajustes' => 0,
					'mecanismo'      => '',
					'hook'           => '',
				),
				'autoload'  => false,
				'sanitiza'  => array( __CLASS__, 'sanitiza_cadencia' ),
			),
			'f3base_cadencia_estado'        => array(
				'rotulo'          => __( 'Estado da cadência', 'f3base' ),
				'descricao'       => __( 'Contador de ajustes desde o último relatório e carimbo previsto da próxima execução. Estado de execução, não configuração.', 'f3base' ),
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(
					'ajustes'  => 0,
					'previsto' => 0,
				),
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array( __CLASS__, 'sanitiza_cadencia_estado' ),
			),
			'f3base_cache_estado'           => array(
				'rotulo'          => 'Estado da integração de cache',
				'descricao'       => 'Fila de invalidação e versão aplicada ao cache de página.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'padrao'          => array(
					'versao'        => '',
					'geracao'       => '',
					'pendente'      => false,
					'solicitado_em' => 0,
					'limpo_em'      => 0,
					'codigo'        => '',
				),
				'sanitiza'        => array( 'F3Base_Cache_Pagina', 'sanitizar' ),
			),
			'f3base_cache_evidencia'        => array(
				'rotulo'          => 'Evidência pública do cache',
				'descricao'       => 'Última tentativa e último sucesso, sem corpos ou tokens; registro durável limitado.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'padrao'          => array(),
				'sanitiza'        => array( 'F3Base_Cache_Evidencia', 'sanitizar' ),
			),
			'f3base_cache_travas'           => array(
				'rotulo'          => 'Leases do cache',
				'descricao'       => 'Controle concorrente com validade, sem configuração pública.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'padrao'          => array(),
				'sanitiza'        => array( 'F3Base_Cache_Evidencia', 'sanitizar_travas' ),
			),
			'f3base_endpoint_segredo'       => array(
				'rotulo'          => __( 'Segredo do token efêmero', 'f3base' ),
				'descricao'       => __( 'Chave HMAC do token do endpoint de leads. Gerada na ativação; nunca exibida.', 'f3base' ),
				'operavel'        => false,
				'campo'           => 'segredo',
				'padrao'          => '',
				'autoload'        => false,
				'estado_execucao' => true,
				'descartavel'     => true,
				'sanitiza'        => array( __CLASS__, 'sanitiza_segredo' ),
			),
		);

		/**
		 * Permite ao implantador ou ao complemento do canal declarar options
		 * gerenciadas adicionais sem editar o catálogo embutido.
		 *
		 * @param array<string,array<string,mixed>> $catalogo Catálogo declarado.
		 */
		$catalogo = self::catalogo_evolucao( $catalogo );
		$catalogo = self::descrever_contrato( $catalogo );
		$catalogo = apply_filters( 'f3base_options_catalogo', $catalogo );

		self::$catalogo = F3Base_Servicos::catalogo( is_array( $catalogo ) ? $catalogo : array() );

		return self::$catalogo;
	}

	/** Complementos aditivos: a ausência dos novos campos preserva a política legada. */
	private static function catalogo_evolucao( array $catalogo ): array {
		$campo = static fn( string $tipo, string $rotulo, string $impacto, string $exemplo ) => array(
			'tipo'      => $tipo,
			'rotulo'    => $rotulo,
			'descricao' => $impacto,
			'impacto'   => $impacto,
			'exemplo'   => $exemplo,
		);
		$novos = array(
			'f3base_llms'          => array(
				'entrega'                        => array(
					'dinamica',
					array(
						'tipo'      => 'select',
						'rotulo'    => 'Entrega do índice',
						'descricao' => 'Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados.',
						'impacto'   => 'Arquivo gerado reduz o trabalho do PHP; requer raiz gravável e cabeçalhos do servidor configurados.',
						'exemplo'   => 'Dinâmica é o padrão.',
						'opcoes'    => array(
							'dinamica'       => 'Dinâmica',
							'arquivo_gerado' => 'Arquivo gerado',
						),
					),
				),
				'atualizacao_intervalo_segundos' => array(
					3600,
					array(
						'tipo'          => 'inteiro',
						'rotulo'        => 'Intervalo de atualização',
						'descricao'     => 'Atualização periódica. Sem visitas é necessário cron real.',
						'impacto'       => 'Atualização periódica. Sem visitas é necessário cron real.',
						'exemplo'       => 'Atualizar a cada hora.',
						'min'           => 60,
						'max'           => 86400,
						'schema_config' => array(
							'type'    => 'integer',
							'minimum' => 60,
							'maximum' => 86400,
						),
					),
				),
				'atualizar_por_visita'           => array(
					true,
					array(
						'tipo'      => 'booleano',
						'rotulo'    => 'Verificar atualização nas visitas',
						'descricao' => 'Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.',
						'impacto'   => 'Visitas processadas pelo WordPress agendam atualização vencida. Hits estáticos e de cache não executam PHP.',
						'exemplo'   => 'Ativado.',
					),
				),
			),
			'f3base_seo_entidade'  => array(
				'razao_social'        => array(
					'',
					array(
						'tipo'      => 'texto',
						'rotulo'    => 'Razão social',
						'descricao' => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'impacto'   => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'exemplo'   => 'Preencher somente dados confirmados.',
					),
				),
				'cnpj'                => array(
					'',
					array(
						'tipo'      => 'texto',
						'rotulo'    => 'CNPJ',
						'descricao' => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'impacto'   => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'exemplo'   => 'Preencher somente dados confirmados.',
					),
				),
				'descricao'           => array(
					'',
					array(
						'tipo'      => 'texto',
						'rotulo'    => 'Descrição',
						'descricao' => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'impacto'   => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'exemplo'   => 'Preencher somente dados confirmados.',
					),
				),
				'email'               => array(
					'',
					array(
						'tipo'      => 'texto',
						'rotulo'    => 'E-mail',
						'descricao' => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'impacto'   => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'exemplo'   => 'Preencher somente dados confirmados.',
					),
				),
				'telefone'            => array(
					'',
					array(
						'tipo'      => 'texto',
						'rotulo'    => 'Telefone E.164',
						'descricao' => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'impacto'   => 'Complementa somente propriedades ausentes na organização emitida pelo Yoast.',
						'exemplo'   => 'Preencher somente dados confirmados.',
					),
				),
				'endereco'            => array(
					array(),
					array(
						'tipo'          => 'json',
						'rotulo'        => 'Endereço',
						'descricao'     => 'Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.',
						'impacto'       => 'Objeto opcional com logradouro, cidade, uf, cep e pais. BR é a reserva quando há endereço.',
						'exemplo'       => '{"cidade":"São Paulo","uf":"SP","pais":"BR"}',
						'schema_config' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
							'properties'           => array(
								'logradouro' => array(
									'type' => 'string',
								),
								'cidade'     => array(
									'type' => 'string',
								),
								'uf'         => array(
									'type' => 'string',
								),
								'cep'        => array(
									'type' => 'string',
								),
								'pais'       => array(
									'type' => 'string',
								),
							),
						),
					),
				),
				'organizacoes_filhas' => array(
					array(),
					array(
						'tipo'          => 'json',
						'rotulo'        => 'Organizações filhas',
						'descricao'     => 'Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.',
						'impacto'       => 'Relações declaradas: nome, URL HTTPS e ID opcional. Não deduz relações pelo domínio.',
						'exemplo'       => '[]',
						'schema_config' => array(
							'type'     => 'array',
							'maxItems' => 50,
							'items'    => array(
								'type'                 => 'object',
								'additionalProperties' => true,
								'required'             => array(
									'nome',
									'url',
								),
								'properties'           => array(
									'nome' => array(
										'type' => 'string',
									),
									'url'  => array(
										'type' => 'string',
									),
									'id'   => array(
										'type' => 'string',
									),
								),
							),
						),
					),
				),
				'autoria'             => array(
					'usuario',
					array(
						'tipo'      => 'select',
						'rotulo'    => 'Autoria padrão',
						'descricao' => 'Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.',
						'impacto'   => 'Institucional usa a organização existente no grafo. A escolha individual do conteúdo tem precedência.',
						'exemplo'   => 'Usuário preserva a autoria atual.',
						'opcoes'    => array(
							'usuario'     => 'Usuário',
							'organizacao' => 'Institucional',
						),
					),
				),
			),

			'f3base_consentimento' => array(
				'modo'                     => array(
					'legado',
					$campo( 'select', 'Modo de consentimento', 'Legado preserva a política vigente. Granular solicita decisões separadas de medição e publicidade; cookies antigos não comprovam escolhas granulares.', 'Granular mediante mudança explícita.' ) + array(
						'opcoes' => array(
							'legado'   => 'Legado',
							'granular' => 'Por categoria',
						),
					),
				),
				'politica_versao'          => array(
					'1',
					$campo( 'texto', 'Versão da política', 'Identifica a política declarada. O runtime combina a versão com a assinatura das regras vigentes; mudanças incompatíveis solicitam nova decisão sem atribuir consentimento retroativo.', '1' ) + array(
						'schema_config' => array(
							'type'    => 'string',
							'pattern' => '^[A-Za-z0-9._-]{1,64}$',
						),
					),
				),
				'gtm_separacao_verificada' => array( false, $campo( 'booleano', 'Contêiner GTM respeita as categorias', 'Marque somente após conferir as regras do contêiner. Sem essa confirmação, o modo granular só carrega GTM com medição e publicidade autorizadas.', 'Desmarcado até verificar o contêiner.' ) ),
			),
			'f3base_comportamento' => array( 'tempo_ativo' => array( false, $campo( 'booleano', 'Estimar tempo ativo por bloco', 'Conta somente o bloco predominante com página visível e atividade recente. A estimativa não comprova atenção humana.', 'Desligado por padrão.' ) ) ),
			'f3base_acessos'       => array(
				'padroes_hospedagem' => array(
					array(),
					$campo( 'lista', 'Marcadores de agentes da hospedagem', 'Textos literais presentes no User-Agent identificam tráfego declarado da hospedagem. IP compartilhado não é prova de origem.', 'Use somente marcadores confirmados nos logs.' ) + array(
						'schema_config' => array(
							'type'     => 'array',
							'maxItems' => 8,
							'items'    => array(
								'type'      => 'string',
								'minLength' => 3,
								'maxLength' => 80,
							),
						),
					),
				),
			),
			'f3base_sessao'        => array(
				'modo'   => array(
					'legado',
					$campo( 'select', 'Política das sessões', 'Legado conserva o prazo único e Lembrar-me. Por perfil respeita a escolha de lembrar e usa a regra mais restritiva aplicável. Novas sessões apenas.', 'Por perfil após revisar as regras.' ) + array(
						'opcoes' => array(
							'legado'     => 'Legado',
							'por-perfil' => 'Por papel ou capacidade',
						),
					),
				),
				'regras' => array(
					array(
						array(
							'papel'      => '',
							'capacidade' => 'manage_options',
							'dias'       => 14,
							'nucleo'     => true,
						),
						array(
							'papel'      => '',
							'capacidade' => 'edit_others_posts',
							'dias'       => 14,
							'nucleo'     => false,
						),
						array(
							'papel'      => 'author',
							'capacidade' => '',
							'dias'       => 90,
							'nucleo'     => false,
						),
						array(
							'papel'      => 'subscriber',
							'capacidade' => '',
							'dias'       => 90,
							'nucleo'     => false,
						),
					),
					$campo( 'json', 'Regras de duração por perfil', 'Lista de regras com papel ou capacidade, dias e nucleo. A regra mais curta prevalece; manage_options sempre respeita o teto do núcleo. Nenhuma sessão existente é revogada.', '[{"papel":"editor","capacidade":"","dias":14,"nucleo":false}]' ) + array(
						'schema_config' => array(
							'type'     => 'array',
							'maxItems' => 30,
							'items'    => array(
								'type'                 => 'object',
								'additionalProperties' => false,
								'properties'           => array(
									'papel'      => array( 'type' => 'string' ),
									'capacidade' => array( 'type' => 'string' ),
									'dias'       => array(
										'type'    => 'integer',
										'minimum' => 1,
										'maximum' => 365,
									),
									'nucleo'     => array( 'type' => 'boolean' ),
								),
							),
						),
					),
				),
			),
		);
		foreach ( $novos as $nome => $campos ) {
			foreach ( $campos as $chave => $item ) {
				$catalogo[ $nome ]['padrao'][ $chave ]    = $item[0];
				$catalogo[ $nome ]['subcampos'][ $chave ] = $item[1]; }
		}

		foreach ( array( 'organizacao_mae', 'endereco', 'organizacoes_filhas' ) as $campo_entidade ) {
			$catalogo['f3base_seo_entidade']['subcampos'][ $campo_entidade ]['schema_entrada'] = $catalogo['f3base_seo_entidade']['subcampos'][ $campo_entidade ]['schema_config']; }
		$catalogo['f3base_seo_entidade']['operavel']        = true;
		$catalogo['f3base_seo_entidade']['verifica']        = array( 'F3Base_Schema_Verificacao', 'verificacao_configuracao' );
		$catalogo['f3base_google_carregamento']['verifica'] = array( 'F3Base_Release_Configuracao', 'verificar_google' );
		$catalogo['f3base_seo_entidade']['secao']           = self::SECAO_PRIVACIDADE;
		$catalogo['f3base_seo_entidade']['recusa']          = array( 'F3Base_Seo_Entidade', 'recusar' );
		$catalogo['f3base_llms']['recusa']                  = array( 'F3Base_Release_Configuracao', 'recusar_llms' );

		$catalogo['f3base_consentimento']['recusa'] = array( __CLASS__, 'recusa_consentimento' );
		$catalogo['f3base_estrutura_estado']        = array(
			'rotulo'          => 'Atualização da estrutura',
			'descricao'       => 'Versão confirmada e tentativa de migração da estrutura própria do Core.',
			'operavel'        => false,
			'campo'           => 'grupo',
			'padrao'          => array(),
			'autoload'        => false,
			'estado_execucao' => true,
			'descartavel'     => true,
			'sanitiza'        => array( 'F3Base_Atualizacao', 'sanitizar_estado' ),
		);
		$catalogo['f3base_operacao_estado']         = array(
			'rotulo'          => 'Agenda e execução',
			'descricao'       => 'Reservas e últimas execuções administrativas das tarefas próprias do Core.',
			'operavel'        => false,
			'campo'           => 'grupo',
			'padrao'          => array(),
			'autoload'        => false,
			'estado_execucao' => true,
			'descartavel'     => true,
			'sanitiza'        => array( 'F3Base_Operacao', 'sanitizar_estado' ),
		);
		$catalogo['f3base_publicacao_evidencias']   = array(
			'rotulo'          => 'Evidências de publicação',
			'descricao'       => 'Inspeções HTTP explícitas limitadas, sem corpos pessoais.',
			'operavel'        => false,
			'campo'           => 'grupo',
			'padrao'          => array(
				'versao' => 1,
				'itens'  => array(),
			),
			'autoload'        => false,
			'estado_execucao' => true,
			'descartavel'     => true,
			'sanitiza'        => array( 'F3Base_Publicacao_Sonda', 'sanitizar' ),
		);
		return $catalogo;
	}

	/** Metadados do contrato: os números são os mesmos consumidos pelos sanitizadores. */
	private static function descrever_contrato( array $catalogo ): array {
		$faixa   = static fn( string $id ) => array(
			'minimum' => self::FAIXAS[ $id ][0],
			'maximum' => self::FAIXAS[ $id ][1],
		);
		$texto   = static fn( string $id ) => array(
			'type'      => 'string',
			'maxLength' => self::TAMANHOS[ $id ],
		);
		$tag     = $texto( 'tag_id' ) + array( 'pattern' => '^[A-Za-z0-9_-]*$' );
		$partner = $texto( 'partner_id' ) + array( 'pattern' => '^[0-9]*$' );
		$item    = array(
			'type'                 => 'object',
			'properties'           => array(
				'id'        => array(
					'type'    => 'integer',
					'minimum' => 0,
				),
				'url'       => array( 'type' => 'string' ),
				'titulo'    => array( 'type' => 'string' ),
				'descricao' => array( 'type' => 'string' ),
			),
			'additionalProperties' => true,
		);
		$schemas = array(
			'f3base_contato'                => array( 'properties' => array( 'whatsapp_e164' => $texto( 'whatsapp' ) + array( 'pattern' => '^(?:[0-9]{' . self::TAMANHOS['whatsapp_minimo'] . ',' . self::TAMANHOS['whatsapp'] . '})?$' ) ) ),
			'f3base_ga4_measurement_id'     => $tag,
			'f3base_gtm_container_id'       => $tag,
			'f3base_meta_pixel_id'          => $tag,
			'f3base_google_ads'             => array(
				'properties' => array(
					'conversion_id'    => $tag,
					'conversion_label' => $tag,
				),
			),
			'f3base_meta_capi_token'        => $texto( 'segredo_opaco' ) + array(
				'x-maxBytes' => self::TAMANHOS['segredo_opaco'],
				'writeOnly'  => true,
			),
			'f3base_linkedin_partner_id'    => $partner,
			'f3base_linkedin_conversion_id' => $partner,
			'f3base_verificacao_google'     => array(
				'maxLength'  => F3Base_Modulo_Verificacao_Dominio::TETO,
				'x-maxBytes' => F3Base_Modulo_Verificacao_Dominio::TETO,
			),
			'f3base_verificacao_meta'       => array(
				'maxLength'  => F3Base_Modulo_Verificacao_Dominio::TETO,
				'x-maxBytes' => F3Base_Modulo_Verificacao_Dominio::TETO,
			),
			'f3base_atribuicao'             => array( 'properties' => array( 'ttl_dias' => $faixa( 'ttl_dias' ) ) ),
			'f3base_consentimento'          => array( 'properties' => array( 'ttl_dias' => $faixa( 'ttl_dias' ) ) ),
			'f3base_retencao_meses'         => $faixa( 'retencao_meses' ),
			'f3base_acessos'                => array(
				'properties' => array(
					'padrao_do_log'      => $texto( 'padrao_log' ) + array(
						'pattern'    => '^(?!.*\\.\\.)(?:/|~/)[a-zA-Z0-9_./* -]+$',
						'x-maxBytes' => self::TAMANHOS['padrao_log'],
					),
					'caminhos_excluidos' => array(
						'type'        => 'array',
						'maxItems'    => self::TAMANHOS['prefixos_log'],
						'uniqueItems' => true,
						'items'       => $texto( 'prefixo_log' ) + array(
							'pattern'    => '^/[^?\\x00-\\x20#]*$',
							'x-maxBytes' => self::TAMANHOS['prefixo_log'],
						),
					),
					'retencao_meses'     => $faixa( 'acessos_meses' ),
				),
			),
			'f3base_sessao'                 => array( 'properties' => array( 'dias' => $faixa( 'sessao_dias' ) ) ),
			'f3base_comportamento'          => array(
				'properties' => array(
					'retencao_dias'         => $faixa( 'comportamento_dias' ),
					'retencao_eventos_dias' => $faixa( 'comportamento_dias' ) + array( 'x-maximumField' => 'retencao_dias' ),
					'dias_no_painel'        => $faixa( 'comportamento_dias' ) + array( 'x-maximumField' => 'retencao_dias' ),
				),
			),
			'f3base_origem_confiavel'       => array(
				'properties' => array(
					'saltos'           => $faixa( 'saltos' ),
					'redes_confiaveis' => array(
						'type'  => 'array',
						'items' => array(
							'type'        => 'string',
							'description' => 'IP ou CIDR validado pelo módulo de origem.',
						),
					),
				),
			),
			'f3base_llms'                   => array(
				'properties' => array(
					'politica_privacidade' => array(
						'type'       => array( 'object', 'array' ),
						'properties' => $item['properties'],
						'maxItems'   => 0,
					),
					'livres'               => array(
						'type'  => 'array',
						'items' => $item,
					),
				),
			),
			'f3base_seo_entidade'           => array(
				'properties' => array(
					'ponto_de_contato' => array(
						'type'  => 'array',
						'items' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
							'properties'           => array(
								'tipo'     => array( 'type' => 'string' ),
								'telefone' => array( 'type' => 'string' ),
								'email'    => array( 'type' => 'string' ),
								'idiomas'  => array(
									'type'  => 'array',
									'items' => array( 'type' => 'string' ),
								),
							),
						),
					),
					'servicos'         => array(
						'type'  => 'array',
						'items' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
							'properties'           => array(
								'nome'         => array( 'type' => 'string' ),
								'descricao'    => array( 'type' => 'string' ),
								'url'          => array( 'type' => 'string' ),
								'tipo_servico' => array( 'type' => 'string' ),
								'area_servida' => array(
									'type'  => 'array',
									'items' => array( 'type' => 'string' ),
								),
							),
						),
					),
				),
			),
			'f3base_cabecalhos'             => array(
				'properties' => array(
					'x_frame_options'     => array( 'enum' => F3Base_Vocabulario::politicas_de_frame() ),
					'coop'                => array( 'enum' => F3Base_Vocabulario::politicas_de_coop() ),
					'referrer_policy'     => array( 'enum' => F3Base_Vocabulario::politicas_de_referrer() ),
					'permissions_policy'  => array( 'enum' => F3Base_Vocabulario::politicas_de_permissoes() ),
					'csp_frame_ancestors' => array( 'enum' => F3Base_Vocabulario::ancestrais_de_frame() ),
					'hsts_max_age'        => $faixa( 'hsts_segundos' ),
				),
			),
			'f3base_nav_id'                 => array( 'minimum' => 0 ),
			'f3base_cadencia'               => array(
				'properties' => array(
					'periodicidade'  => array( 'enum' => self::PERIODICIDADES ),
					'apos_n_ajustes' => array( 'minimum' => 0 ),
				),
			),
			'f3base_redirects'              => array(
				'type'                 => array( 'object', 'array' ),
				'additionalProperties' => array(
					'type'      => 'string',
					'maxLength' => self::TAMANHOS['caminho'],
				),
			),
		);
		foreach ( $schemas as $nome => $schema ) {
			$catalogo[ $nome ]['schema_config'] = $schema; }
		$catalogo['f3base_contato']['dependencias_config']       = array(
			array(
				'campo'   => 'flutuante',
				'requer'  => 'whatsapp_e164',
				'regra'   => 'numero_valido',
				'impacto' => 'O ícone só é publicado quando a opção estiver ligada e o número for válido; o tema precisa executar wp_footer.',
			),
		);
		$catalogo['f3base_comportamento']['dependencias_config'] = array(
			array(
				'campo'       => 'retencao_eventos_dias',
				'operador'    => '<=',
				'outro_campo' => 'retencao_dias',
				'tratamento'  => 'normalizar',
			),
			array(
				'campo'       => 'dias_no_painel',
				'operador'    => '<=',
				'outro_campo' => 'retencao_dias',
				'tratamento'  => 'normalizar',
			),
		);
		$catalogo['f3base_llms']['dependencias_config']          = array(
			array(
				'campo'   => 'full',
				'requer'  => 'ligado',
				'regra'   => 'true',
				'impacto' => 'O full usa a seleção do índice.',
			),
			array(
				'campo'       => 'politica_privacidade',
				'obrigatoria' => false,
				'impacto'     => 'Vazia, a seleção e a publicação dos llms continuam funcionando.',
			),
		);
		$catalogo['f3base_consentimento']['dependencias_config'] = array(
			array(
				'campo'   => 'modo',
				'quando'  => 'granular',
				'requer'  => 'controle_rodape',
				'regra'   => 'true',
				'impacto' => 'O controle permanente permite revisar e revogar as escolhas por categoria.',
			),
			array(
				'recurso'     => 'pagina_politica_privacidade',
				'obrigatoria' => false,
				'impacto'     => 'Ausência da página não muda o consentimento configurado nem bloqueia a medição; o link é omitido.',
			),
		);
		return $catalogo;
	}
}
