<?php
/** Consultas únicas para painel, CSV e agentes; unidade explícita e cobertura. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Relatorios {
    const MAX_EVENTOS=30000;
    const MAX_LEADS=3000;
    const VISOES=array('resultados','campanhas','formularios','blocos','qualidade','operacao','materiais','demanda','metodos');
    public static function iniciar(): void {
        add_action('admin_menu',static function(){add_submenu_page('f3base-leads','Relatórios integrados','Relatórios','manage_options','f3base-relatorios',array(__CLASS__,'tela'));});
        add_action('admin_post_f3base_relatorio_csv',array(__CLASS__,'csv'));
        add_action('wp_abilities_api_init',static function(){
            F3Base_Servicos::ability('relatorios-integrados-ler','Relatórios por página, campanha, formulário, conteúdo, qualidade e operação; cobertura e comparação',array(__CLASS__,'consultar'),array('de'=>array('type'=>'string','format'=>'date'),'ate'=>array('type'=>'string','format'=>'date'),'visao'=>array('enum'=>self::VISOES),'caminho'=>array('type'=>'string'),'formulario'=>array('type'=>'string'),'metodo'=>array('enum'=>array('','formulario','whatsapp_formulario','conteudo','whatsapp_cta','contato_cta')),'comparar'=>array('type'=>'boolean'),'pagina'=>array('type'=>'integer','minimum'=>1),'limite'=>array('type'=>'integer','minimum'=>1,'maximum'=>200)));
            F3Base_Servicos::ability('lead-jornada-ler','Eventos observados antes do contato; sessão e carregamentos não comprovam sequência entre abas',array(__CLASS__,'jornada'),array('record_id'=>array('type'=>'string','pattern'=>'^[a-f0-9]{32}$')),array('record_id'));
        });
    }
    private static function erro(string $codigo): array {return array('ok'=>false,'codigo'=>$codigo);}
    public static function janela(array $e): array {
        $tz=wp_timezone();$ate=$e['ate']??(new DateTimeImmutable('today',$tz))->format('Y-m-d');$de=$e['de']??(new DateTimeImmutable($ate,$tz))->modify('-29 days')->format('Y-m-d');
        foreach(array($de,$ate) as $v){if(!is_string($v)||!preg_match('/^\d{4}-\d{2}-\d{2}$/D',$v)){throw new InvalidArgumentException('periodo_invalido');}$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v,$tz);if(!$d||$d->format('Y-m-d')!==$v){throw new InvalidArgumentException('periodo_invalido');}}
        $a=new DateTimeImmutable($de,$tz);$b=(new DateTimeImmutable($ate,$tz))->modify('+1 day');$dias=(int)$a->diff($b)->format('%r%a');
        if($dias<1||$dias>90){throw new InvalidArgumentException('periodo_entre_1_e_90_dias');}
        return array('de'=>$de,'ate'=>$ate,'inicio'=>$a->getTimestamp(),'fim'=>$b->getTimestamp(),'dias'=>$dias,'fuso'=>wp_timezone_string(),'parcial'=>$b->getTimestamp()>time(),'extraido_em'=>time());
    }
    public static function consultar(array $e=array(),bool $completo=false): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}
        if(array_diff(array_keys($e),array('de','ate','visao','caminho','formulario','metodo','comparar','pagina','limite'))){return self::erro('campo_desconhecido');}
        if(isset($e['comparar'])&&!is_bool($e['comparar'])){return self::erro('comparacao_invalida');}foreach(array('pagina'=>PHP_INT_MAX,'limite'=>200) as $k=>$max){if(isset($e[$k])&&(!is_int($e[$k])||$e[$k]<1||$e[$k]>$max)){return self::erro('paginacao_invalida');}}
        if(isset($e['metodo'])&&!in_array($e['metodo'],array('','formulario','whatsapp_formulario','conteudo','whatsapp_cta','contato_cta'),true)){return self::erro('metodo_invalido');}
        $visao=$e['visao']??'resultados';if(!in_array($visao,self::VISOES,true)){return self::erro('visao_invalida');}
        foreach(array('caminho','formulario','metodo') as $key){if(isset($e[$key])&&!is_string($e[$key])){return self::erro('filtro_invalido');}}
        if(!empty($e['caminho'])&&!F3Base_Analise::caminho($e['caminho'])){return self::erro('pagina_invalida');}
        try{$j=self::janela($e);}catch(Throwable $ex){return self::erro('periodo_invalido');}
        $r=self::calcular($j,$e);if(empty($r['ok'])){return $r;}
        if(!empty($e['comparar'])){
            $a=new DateTimeImmutable($j['de'],wp_timezone());$ant=array('de'=>$a->modify('-'.$j['dias'].' days')->format('Y-m-d'),'ate'=>$a->modify('-1 day')->format('Y-m-d'));
            $prev=self::calcular(self::janela($ant),$e);
            $r['comparacao']=array('periodo'=>$ant,'ok'=>$prev['ok'],'atual'=>$r['totais'],'anterior'=>$prev['totais']??null,'variacao_envios'=>!empty($prev['totais']['envios'])?round(100*($r['totais']['envios']-$prev['totais']['envios'])/$prev['totais']['envios'],2):null,'aviso'=>'Períodos parciais, cobertura e retenção diferentes limitam a comparação; variação não identifica causa.');
        }
        $all=$r['quadros'][$visao]??array();$lim=max(1,min(200,(int)($e['limite']??100)));$pag=max(1,(int)($e['pagina']??1));
        $r['linhas']=$completo?$all:array_slice($all,($pag-1)*$lim,$lim);$r['visao']=$visao;$r['total_linhas']=count($all);$r['pagina']=$pag;$r['proxima_pagina']=$pag*$lim<count($all)?$pag+1:null;unset($r['quadros']);return $r;
    }
    private static function dados(array $j): array {
        global $wpdb;$t=F3Base_Leads_Repositorio::tabela();$evt=$wpdb->prefix.F3Base_Modulo_Comportamento::TABELA_EVENTOS;
        $wpdb->query('START TRANSACTION');
        try{
            $leads=$wpdb->get_results($wpdb->prepare('SELECT record_id,sessao,correlacao,post_id,metodo,captura,atendimento,criado_em,pagina,dados,formulario,aviso,resposta,origem_chave FROM %i WHERE criado_em>=%s AND criado_em<%s AND lixeira=0 AND eliminacao_pendente=0 ORDER BY criado_em,id LIMIT %d',$t,gmdate('Y-m-d H:i:s',$j['inicio']),gmdate('Y-m-d H:i:s',$j['fim']),self::MAX_LEADS+1),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_leads_falhou');}
            $events=$wpdb->get_results($wpdb->prepare('SELECT sessao,caminho,metrica,detalhe,valor,criado_em,ancora FROM %i WHERE criado_em>=%d AND criado_em<%d ORDER BY criado_em,id LIMIT %d',$evt,$j['inicio'],$j['fim'],self::MAX_EVENTOS+1),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_eventos_falhou');}
            $analytics=$wpdb->get_results($wpdb->prepare('SELECT * FROM %i WHERE criado_em>=%d AND criado_em<%d ORDER BY criado_em,id LIMIT %d',F3Base_Analise::tabela(),$j['inicio'],$j['fim'],self::MAX_EVENTOS+1),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_analise_falhou');}
            if(count($leads)>self::MAX_LEADS||count($events)>self::MAX_EVENTOS||count($analytics)>self::MAX_EVENTOS){return array('ok'=>false,'codigo'=>'reduza_periodo','limites'=>array('leads'=>self::MAX_LEADS,'eventos_por_fonte'=>self::MAX_EVENTOS),'motivo'=>'O relatório excede a leitura limitada. Nenhuma taxa parcial foi calculada.');}
            return array('ok'=>true,'leads'=>$leads,'events'=>$events,'analytics'=>$analytics);
        }finally{$wpdb->query('COMMIT');}
    }
    private static function base(string $path): array {return array('pagina'=>$path,'sessoes'=>array(),'intencoes'=>array(),'conversoes'=>array(),'cliques'=>0,'envios'=>0,'sem_sessao'=>0,'erros'=>array(),'friccao'=>array());}
    private static function taxa(int $a,int $b): ?float {return $b?round(100*$a/$b,2):null;}
    private static function p75(array $v): ?float {if(!$v){return null;}sort($v,SORT_NUMERIC);return (float)$v[max(0,(int)ceil(count($v)*0.75)-1)];}
    private static function classe(array $r): string {
        if($r['captura']==='suspeito'){return 'suspeitos';}if($r['atendimento']==='spam'){return 'spam';}
        if(in_array($r['metodo'],array('whatsapp_cta','contato_cta'),true)){return 'cliques';}
        return $r['captura']==='aceito'&&in_array($r['metodo'],array('formulario','whatsapp_formulario','conteudo'),true)?'envios':'outros';
    }
    private static function campanha(array $a): string {return implode(' | ',array($a['utm_source']?:($a['referrer']?:'(sem atribuição)'),$a['utm_medium']?:'(não informado)',$a['utm_campaign']?:'(não informada)',$a['utm_content']?:'(não informado)'));}
    public static function calcular(array $j,array $f=array()): array {
        $d=self::dados($j);if(empty($d['ok'])){return $d;}
        $pages=array();$seen=array();$sessions=array();$navigation=array();$campaigns=array();$forms=array();$blocks=array();$quality=array();$methods=array();$tot=array_fill_keys(array('registros','cliques','envios','suspeitos','spam','outros'),0);$coverage=array('elegiveis'=>0,'com_sessao'=>0,'com_eventos'=>0,'com_pagina_vista'=>0,'sem_sessao'=>0,'envios_com_campanha_pareada'=>0,'cliques_com_campanha_pareada'=>0,'envios_com_campos_estruturados'=>0);$oper=array();$demand=array();$materials=array();$accepted=array();$conversions=array();$leadids=array();
        $filterPath=!empty($f['caminho'])?F3Base_Analise::caminho($f['caminho']):'';
        foreach($d['events'] as $e){$path=F3Base_Analise::caminho($e['caminho']);if(!$path||($filterPath&&$path!==$filterPath)){continue;}$s=$e['sessao'];$pages[$path]=$pages[$path]??self::base($path);$seen[$s]=true;
            if($e['metrica']==='f3base_pagina_vista'){$pages[$path]['sessoes'][$s]=min($pages[$path]['sessoes'][$s]??PHP_INT_MAX,(int)$e['criado_em']);$sessions[$s]=true;}
            if(in_array($e['metrica'],array('f3base_erro_js','f3base_friccao'),true)){$key=$e['metrica']==='f3base_erro_js'?'erros':'friccao';$pages[$path][$key][$s]=true;}
            if(in_array($e['metrica'],array('f3base_secao_vista','f3base_tempo_ativo'),true)){$k=$path.'|'.$e['detalhe'];$blocks[$k]=$blocks[$k]??array('pagina'=>$path,'bloco'=>$e['detalhe'],'sessoes'=>array(),'tempo_ms'=>0);if($e['metrica']==='f3base_secao_vista'){$blocks[$k]['sessoes'][$s]=min($blocks[$k]['sessoes'][$s]??PHP_INT_MAX,(int)$e['criado_em']);}else{$blocks[$k]['tempo_ms']+=(int)$e['valor'];}}
        }
        foreach($d['analytics'] as $a){$path=$a['caminho'];if($filterPath&&$path!==$filterPath){continue;}$s=$a['sessao'];$seen[$s]=true;$pages[$path]=$pages[$path]??self::base($path);
            if($a['tipo']==='pagina'){$pages[$path]['sessoes'][$s]=min($pages[$path]['sessoes'][$s]??PHP_INT_MAX,(int)$a['criado_em']);$sessions[$s]=true;$attr=F3Base_Analise::atribuicao(json_decode($a['atribuicao'],true));$key=self::campanha($attr);$navigation[$a['navegacao']]=array('campanha'=>$key,'sessao'=>$s,'criado_em'=>(int)$a['criado_em']);$campaigns[$key]=$campaigns[$key]??array('campanha'=>$key,'sessoes'=>array(),'conversoes'=>array(),'intencoes'=>array(),'cliques'=>0,'envios'=>0);$campaigns[$key]['sessoes'][$s]=true;}
            if(str_starts_with($a['tipo'],'form_')){if(!empty($f['formulario'])&&$a['formulario']!==$f['formulario']){continue;}$key=$a['formulario'].'|'.$a['formulario_revisao'];$forms[$key]=$forms[$key]??self::form_base($a['formulario'],$a['formulario_revisao']);$corr=$s.'|'.$a['correlacao'];$forms[$key][$a['tipo']][$corr]=(int)$a['criado_em'];$forms[$key]['ultimos'][$corr]=max($forms[$key]['ultimos'][$corr]??0,(int)$a['criado_em']);}
            if($a['tipo']==='vital'){$key=$path.'|'.$a['dispositivo'].'|'.$a['detalhe'];$quality[$key]=$quality[$key]??array('pagina'=>$path,'dispositivo'=>$a['dispositivo'],'metrica'=>$a['detalhe'],'amostras'=>array(),'por_sessao'=>array());$quality[$key]['amostras'][]=(float)$a['valor'];$quality[$key]['por_sessao'][$s][]= (float)$a['valor'];}
        }
        foreach($d['leads'] as $r){$data=json_decode($r['dados'],true)?:array();$path=F3Base_Analise::caminho($r['pagina']);if(!$path){$path='(página indisponível)';}if(($filterPath&&$path!==$filterPath)||(!empty($f['formulario'])&&$r['formulario']!==$f['formulario'])||(!empty($f['metodo'])&&$r['metodo']!==$f['metodo'])){continue;}
            $class=self::classe($r);$method=$r['metodo'];$methods[$method]=$methods[$method]??array_merge(array('metodo'=>$method),array_fill_keys(array('cliques','envios','suspeitos','spam','outros'),0));++$methods[$method][$class];++$tot['registros'];++$tot[$class];if(!in_array($class,array('envios','cliques'),true)){continue;}
            $s=$r['sessao']?:'';$when=strtotime($r['criado_em'].' UTC');$pages[$path]=$pages[$path]??self::base($path);++$pages[$path][$class];++$coverage['elegiveis'];
            if($s){++$coverage['com_sessao'];}else{++$coverage['sem_sessao'];++$pages[$path]['sem_sessao'];}
            if($s&&isset($seen[$s])){++$coverage['com_eventos'];}
            $matched=$s&&isset($pages[$path]['sessoes'][$s])&&$pages[$path]['sessoes'][$s]<=$when;
            if($matched){++$coverage['com_pagina_vista'];$pages[$path][$class==='envios'?'conversoes':'intencoes'][$s]=true;}
            $op=$r['formulario']?:$r['metodo'];$oper[$op]=$oper[$op]??array('origem'=>$op,'novos'=>0,'respondidos'=>0,'maior_idade_novo_horas'=>0,'avisos_pendentes'=>0,'avisos_falhos'=>0,'respostas_pendentes'=>0,'respostas_falhas'=>0,'primeira_marcacao_resposta_segundos'=>array());
            if($r['atendimento']==='novo'){++$oper[$op]['novos'];$oper[$op]['maior_idade_novo_horas']=max($oper[$op]['maior_idade_novo_horas'],round((time()-$when)/3600,1));}elseif($r['atendimento']==='respondido'){++$oper[$op]['respondidos'];}
            if(in_array($r['aviso'],array('pendente','enviando'),true)){++$oper[$op]['avisos_pendentes'];}if(in_array($r['aviso'],array('falhou','incerto','desconfigurado'),true)){++$oper[$op]['avisos_falhos'];}
            if(in_array($r['resposta'],array('pendente','enviando'),true)){++$oper[$op]['respostas_pendentes'];}if(in_array($r['resposta'],array('falhou','incerta','desconfigurada','expirada'),true)){++$oper[$op]['respostas_falhas'];}
            $leadids[$r['record_id']]=array('op'=>$op,'when'=>$when);
            $nav=$data['navegacao']??'';if(isset($navigation[$nav])&&$navigation[$nav]['sessao']===$s&&$navigation[$nav]['criado_em']<=$when){$camp=$navigation[$nav]['campanha'];++$coverage[$class.'_com_campanha_pareada'];++$campaigns[$camp][$class];$campaigns[$camp][$class==='envios'?'conversoes':'intencoes'][$s]=true;}
            if($class!=='envios'){continue;}
            $conversions[$path][$s][]=$when;$accepted[$s.'|'.$r['correlacao']]=true;
            $rev=$data['formulario_revisao']??'';$key=$r['formulario'].'|'.$rev;$forms[$key]=$forms[$key]??self::form_base($r['formulario'],$rev);++$forms[$key]['envios'];$forms[$key]['aceitos'][$s.'|'.$r['correlacao']]=true;
            
            $current=F3Base_Formularios::obter($r['formulario']);$fields=$data['campos_relatorio']??($current&&F3Base_Formularios::revisao($current)===$rev?$current['campos']:array());
            if($fields){++$coverage['envios_com_campos_estruturados'];}
            foreach((array)$fields as $field){if(!in_array($field['tipo'],array('select','radio','checkbox'),true)||!empty($field['papel'])){continue;}$val=$data['campos'][$field['nome']]??null;foreach(is_array($val)?$val:array($val) as $v){if(!is_string($v)||!in_array($v,$field['opcoes']??array(),true)){continue;}$k=$r['formulario'].'|'.$rev.'|'.$field['nome'].'|'.$v;$demand[$k]=$demand[$k]??array('formulario'=>$r['formulario'],'revisao'=>$rev,'campo'=>$field['rotulo']??$field['nome'],'resposta'=>$v,'envios'=>0);++$demand[$k]['envios'];}}
        }
        $out=array_fill_keys(self::VISOES,array());
        foreach($pages as $p){$n=count($p['sessoes']);$good=count($p['conversoes']);$errorConverted=count(array_intersect_key($p['conversoes'],$p['erros']));$errorSessions=count(array_intersect_key($p['sessoes'],$p['erros']));
            $out['resultados'][]=array('pagina'=>$p['pagina'],'sessoes_observadas'=>$n,'cliques_registrados'=>$p['cliques'],'sessoes_com_clique'=>count($p['intencoes']),'envios_aceitos'=>$p['envios'],'sessoes_com_envio'=>$good,'taxa_clique_pct'=>self::taxa(count($p['intencoes']),$n),'taxa_envio_pct'=>self::taxa($good,$n),'registros_sem_sessao'=>$p['sem_sessao'],'sessoes_com_erro'=>$errorSessions,'sessoes_com_friccao'=>count(array_intersect_key($p['sessoes'],$p['friccao'])),'taxa_envio_com_erro_pct'=>self::taxa($errorConverted,$errorSessions),'taxa_envio_sem_erro_pct'=>self::taxa($good-$errorConverted,$n-$errorSessions));
        }
        foreach($campaigns as $c){$out['campanhas'][]=array('campanha'=>$c['campanha'],'modelo'=>'sessao_observada','sessoes'=>count($c['sessoes']),'cliques_pareados'=>$c['cliques'],'sessoes_com_clique'=>count($c['intencoes']),'taxa_clique_pct'=>self::taxa(count($c['intencoes']),count($c['sessoes'])),'envios_pareados'=>$c['envios'],'sessoes_com_envio'=>count($c['conversoes']),'taxa_envio_pct'=>self::taxa(count($c['conversoes']),count($c['sessoes'])));}
        foreach($forms as $b){$started=$b['form_inicio'];$completed=array_intersect_key($started,$b['aceitos']);$abandoned=0;foreach($started as $key=>$stamp){if(!isset($accepted[$key])&&($b['ultimos'][$key]??$stamp)<=min(time(),$j['fim'])-1800){++$abandoned;}}
            $out['formularios'][]=array('formulario'=>$b['formulario'],'revisao'=>$b['revisao'],'instancias_vistas'=>count($b['form_vista']),'inicios'=>count($started),'tentativas'=>count($b['form_tentativa']),'instancias_com_erro'=>count($b['form_erro']),'envios_aceitos'=>$b['envios'],'inicios_com_envio'=>count($completed),'taxa_inicio_envio_pct'=>self::taxa(count($completed),count($started)),'abandono_observado_30min'=>$abandoned);
        }
        foreach($blocks as $b){$conv=0;foreach($b['sessoes'] as $s=>$stamp){if(array_filter($conversions[$b['pagina']][$s]??array(),static fn($t)=>$t>=$stamp)){++$conv;}}$out['blocos'][]=array('pagina'=>$b['pagina'],'bloco'=>$b['bloco'],'sessoes_expostas'=>count($b['sessoes']),'sessoes_com_envio_apos'=>$conv,'taxa_associada_pct'=>self::taxa($conv,count($b['sessoes'])),'tempo_ativo_estimado_ms'=>$b['tempo_ms']);}
        foreach($quality as $b){$converted=array();$other=array();foreach($b['por_sessao'] as $s=>$vals){if(!empty($conversions[$b['pagina']][$s])){$converted=array_merge($converted,$vals);}else{$other=array_merge($other,$vals);}}$out['qualidade'][]=array('pagina'=>$b['pagina'],'dispositivo'=>$b['dispositivo'],'metrica'=>$b['metrica'],'amostras'=>count($b['amostras']),'p75'=>self::p75($b['amostras']),'amostras_sessoes_com_envio'=>count($converted),'p75_sessoes_com_envio'=>self::p75($converted),'amostras_sem_envio_observado'=>count($other),'p75_sem_envio_observado'=>self::p75($other));}
        // Consultas ligadas ao conjunto de leads já filtrado: sem nomes ou respostas livres.
        if($leadids){global $wpdb;$ids=array_keys($leadids);$in=implode(',',array_fill(0,count($ids),'%s'));
            $rows=$wpdb->get_results($wpdb->prepare('SELECT record_id,MIN(em) AS primeira FROM %i WHERE atual=%s AND record_id IN ('.$in.') GROUP BY record_id',array_merge(array($wpdb->prefix.F3Base_Analise::HISTORICO,'respondido'),$ids)),ARRAY_A);
            if($wpdb->last_error){return self::erro('leitura_historico_falhou');}
            foreach($rows as $h){$x=$leadids[$h['record_id']];$oper[$x['op']]['primeira_marcacao_resposta_segundos'][]=max(0,(int)$h['primeira']-$x['when']);}
            $rows=$wpdb->get_results($wpdb->prepare('SELECT ativo,versao,COUNT(*) AS concessoes,SUM(CASE WHEN usados>0 THEN 1 ELSE 0 END) AS usadas,SUM(usados) AS tentativas FROM %i WHERE lead_record_id IN ('.$in.') GROUP BY ativo,versao',array_merge(array(F3Base_Leads_Repositorio::tabela('concessoes')),$ids)),ARRAY_A);
            foreach($rows as $row){$asset=F3Base_Arquivos_Privados::obter($row['ativo']);$materials[]=array('material'=>$asset['nome']??$row['ativo'],'versao'=>$row['versao'],'concessoes'=>(int)$row['concessoes'],'concessoes_utilizadas'=>(int)$row['usadas'],'concessoes_sem_uso'=>(int)$row['concessoes']-(int)$row['usadas'],'tentativas_autorizadas'=>(int)$row['tentativas'],'taxa_uso_pct'=>self::taxa((int)$row['usadas'],(int)$row['concessoes']));}
            if($wpdb->last_error){return self::erro('leitura_complementar_falhou');}
        }
        foreach($oper as $o){$vals=$o['primeira_marcacao_resposta_segundos'];unset($o['primeira_marcacao_resposta_segundos']);$o['marcacoes_observadas']=count($vals);$o['p75_ate_primeira_marcacao_horas']=$vals?round(self::p75($vals)/3600,2):null;$out['operacao'][]=$o;}
        $out['metodos']=array_values($methods);$out['materiais']=$materials;$out['demanda']=array_values($demand);$tot['sessoes_observadas']=count($sessions);$coverage['pareamento_pct']=self::taxa($coverage['com_pagina_vista'],$coverage['elegiveis']);
        return array('ok'=>true,'versao'=>F3BASE_PLUGIN_VERSAO,'periodo'=>$j,'totais'=>$tot,'cobertura'=>$coverage,'filtros_aplicados'=>array_intersect_key($f,array_flip(array('caminho','formulario','metodo'))),'retencao_eventos_dias'=>F3Base_Modulo_Comportamento::retencao_eventos_dias(),'coleta_adicional_desde'=>get_option(F3Base_Instalacao::OPTION,array())['concluido_em']??null,'quadros'=>$out,'avisos'=>array('Filtros de formulário e método restringem contatos; o denominador continua sendo sessões da página observada.','Demanda usa apenas opções fechadas e o snapshot da definição. Campos livres e identificadores pessoais não são dimensões.','Cliques são intenção; envios aceitos não comprovam qualificação ou venda.','Taxas usam sessões observadas; registros sem pareamento continuam nos volumes.','Campanhas, funil e Web Vitals vinculados dependem da coleta 1.13.0. Ausência de amostra não significa zero.','Abandono observado: início sem aceite no período e pelo menos 30 minutos sem evento observado. Sessões recentes permanecem em aberto.','Erros e desempenho são associações; não demonstram causalidade.','Atendimento mostra marcações manuais; e-mail processado confirma aceite pelo transporte.','Dispositivo representa a largura da tela no carregamento; não identifica hardware.'));
    }
    private static function form_base(string $id,string $rev): array {return array('formulario'=>$id,'revisao'=>$rev,'form_vista'=>array(),'form_inicio'=>array(),'form_tentativa'=>array(),'form_erro'=>array(),'aceitos'=>array(),'ultimos'=>array(),'envios'=>0);}
    public static function jornada(array $e): array {
        if(!current_user_can('manage_options')){return self::erro('sem_permissao');}
        $lead=F3Base_Leads_Repositorio::obter((string)($e['record_id']??''));if(!$lead||$lead['lixeira']||$lead['eliminacao_pendente']){return self::erro('registro_indisponivel');}
        if(!$lead['sessao']){return array('ok'=>true,'record_id'=>$lead['record_id'],'eventos'=>array(),'codigo'=>'sessao_indisponivel','motivo'=>$lead['dados']['contexto']['sessao_motivo']??'nao_informado');}
        global $wpdb;$until=strtotime($lead['criado_em'].' UTC');$from=max($until-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS,time()-F3Base_Modulo_Comportamento::retencao_eventos_dias()*DAY_IN_SECONDS);$t=$wpdb->prefix.F3Base_Modulo_Comportamento::TABELA_EVENTOS;
        $a=$wpdb->get_results($wpdb->prepare('SELECT criado_em,caminho,metrica,detalhe,ancora FROM %i WHERE sessao=%s AND criado_em>=%d AND criado_em<=%d ORDER BY criado_em DESC,id DESC LIMIT 501',$t,$lead['sessao'],$from,$until),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}
        $b=$wpdb->get_results($wpdb->prepare('SELECT criado_em,caminho,tipo AS metrica,detalhe,qualidade AS ancora,navegacao FROM %i WHERE sessao=%s AND criado_em>=%d AND criado_em<=%d ORDER BY criado_em DESC,id DESC LIMIT 501',F3Base_Analise::tabela(),$lead['sessao'],$from,$until),ARRAY_A);if($wpdb->last_error){return self::erro('leitura_falhou');}
        $rows=array_merge($a,$b);usort($rows,static fn($x,$y)=>(int)$x['criado_em']<=>(int)$y['criado_em']);return array('ok'=>true,'record_id'=>$lead['record_id'],'metodo'=>$lead['metodo'],'recebido_em'=>$lead['criado_em'],'eventos'=>array_slice($rows,-500),'corte'=>count($rows)>500,'aviso'=>'Eventos anteriores ao horário de recebimento; sessão pode conter múltiplas abas. Relógio do cliente, retenção e consentimento limitam a reconstrução.');
    }
    private static function filtros(): array { $e=array();foreach(array('de','ate','visao','caminho','formulario','metodo') as $k){if(isset($_REQUEST[$k])&&is_string($_REQUEST[$k])){$value=sanitize_text_field(wp_unslash($_REQUEST[$k]));if($value!==''){$e[$k]=$value;}}}$e['comparar']=!empty($_REQUEST['comparar']);$e['pagina']=max(1,(int)($_REQUEST['pagina']??1));return $e; }
    public static function tela(): void {
        if(!current_user_can('manage_options')){return;}$e=self::filtros();$r=self::consultar($e);
        echo '<div class="wrap"><h1>Relatórios integrados</h1><p>Resultados, jornada e operação com os dados observados neste site.</p><form method="get"><input type="hidden" name="page" value="f3base-relatorios"><label>Relatório <select name="visao">';
        foreach(self::VISOES as $v){echo '<option value="'.$v.'" '.selected($e['visao']??'resultados',$v,false).'>'.esc_html(self::rotulo($v)).'</option>';}echo '</select></label> ';
        foreach(array('de'=>'De','ate'=>'Até','caminho'=>'Página','formulario'=>'Formulário') as $key=>$label){echo '<label>'.esc_html($label).' <input type="'.(in_array($key,array('de','ate'),true)?'date':'text').'" name="'.$key.'" value="'.esc_attr($e[$key]??($r['periodo'][$key]??'')).'"></label> ';}
        echo '<label>Método <select name="metodo"><option value="">Todos</option>';foreach(array('formulario','whatsapp_formulario','conteudo','whatsapp_cta','contato_cta') as $m){echo '<option value="'.$m.'" '.selected($e['metodo']??'',$m,false).'>'.esc_html(self::rotulo($m)).'</option>';}echo '</select></label> ';
        echo '<label><input type="checkbox" name="comparar" value="1" '.checked($e['comparar'],true,false).'> Comparar período anterior</label> <button class="button button-primary">Atualizar relatório</button></form>';
        if(empty($r['ok'])){echo '<p role="alert">'.esc_html($r['codigo']??'Consulta indisponível').'</p></div>';return;}
        echo '<h2>Resumo do período</h2><p>'.esc_html(sprintf('%d envios aceitos · %d cliques · %d suspeitos · %d spam · %d sessões observadas',$r['totais']['envios'],$r['totais']['cliques'],$r['totais']['suspeitos'],$r['totais']['spam'],$r['totais']['sessoes_observadas'])).'</p>';
        echo '<p>'.esc_html(sprintf('Cobertura: %d de %d registros elegíveis encontraram página vista na sessão (%s). Retenção detalhada: %d dias. Fuso: %s.',$r['cobertura']['com_pagina_vista'],$r['cobertura']['elegiveis'],$r['cobertura']['pareamento_pct']===null?'indisponível':$r['cobertura']['pareamento_pct'].'%',$r['retencao_eventos_dias'],$r['periodo']['fuso'])).'</p>';
        if(isset($r['comparacao'])){echo '<p>Envios no período anterior: '.esc_html((string)($r['comparacao']['anterior']['envios']??'indisponível')).'. Variação: '.esc_html($r['comparacao']['variacao_envios']===null?'indisponível':$r['comparacao']['variacao_envios'].'%').'. '.esc_html($r['comparacao']['aviso']).'</p>';}
        if($r['periodo']['parcial']){echo '<p><strong>Período em andamento.</strong> Os dados ainda podem mudar.</p>';}
        self::tabela($r['linhas']);echo '<p>Página '.(int)$r['pagina'].' · '.(int)$r['total_linhas'].' linhas.</p>';
        foreach(array($r['pagina']>1?$r['pagina']-1:null,$r['proxima_pagina']) as $page){if($page){echo '<a class="button" href="'.esc_url(add_query_arg(array_merge($e,array('page'=>'f3base-relatorios','pagina'=>$page)),admin_url('admin.php'))).'">Página '.(int)$page.'</a> ';}}
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="f3base_relatorio_csv">';wp_nonce_field('f3base-relatorio');foreach($e as $k=>$v){echo '<input type="hidden" name="'.esc_attr($k).'" value="'.esc_attr((string)$v).'">';}echo '<button class="button">Exportar CSV do relatório</button></form><details><summary>Como interpretar</summary><ul>';foreach($r['avisos'] as $a){echo '<li>'.esc_html($a).'</li>';}echo '</ul></details></div>';
    }
    public static function rotulo(string $k): string {
        $nomes=array('resultados'=>'Conversão por página','campanhas'=>'Origem e campanhas','formularios'=>'Funil de formulários','blocos'=>'Conteúdo e conversão','qualidade'=>'Qualidade técnica','operacao'=>'Operação de contatos','materiais'=>'Materiais protegidos','demanda'=>'Perfil da demanda','metodos'=>'Métodos de contato','formulario'=>'Formulário','whatsapp_formulario'=>'Formulário com WhatsApp','conteudo'=>'Conteúdo protegido','whatsapp_cta'=>'Clique para WhatsApp','contato_cta'=>'Clique para contato','pagina'=>'Página','revisao'=>'Revisão do formulário','taxa_envio_pct'=>'Sessões com envio (%)','taxa_clique_pct'=>'Sessões com clique (%)','criado_em'=>'Horário observado','caminho'=>'Página','metrica'=>'Evento / métrica','detalhe'=>'Detalhe','ancora'=>'Origem do horário','navegacao'=>'Carregamento','p75'=>'Percentil 75','sessoes_observadas'=>'Sessões observadas','envios_aceitos'=>'Envios aceitos','sessoes_com_envio'=>'Sessões com envio','registros_sem_sessao'=>'Registros sem sessão','abandono_observado_30min'=>'Sem aceite observado após 30 min');
        return $nomes[$k]??ucfirst(str_replace(array('_pct','_ms','_horas','_'),array(' (%)',' (ms)',' (horas)',' '),$k));
    }
    public static function tela_jornada(string $id): void {
        $r=self::jornada(array('record_id'=>$id));echo '<details><summary>Jornada observada antes deste contato</summary>';
        if(empty($r['ok'])){echo '<p>Jornada indisponível.</p>';}else{
            echo '<p>'.esc_html($r['aviso']??$r['motivo']??'Sem observações vinculadas.').'</p>';
            $rows=array();foreach($r['eventos'] as $e){$rows[]=array('criado_em'=>wp_date('d/m/Y H:i:s',(int)$e['criado_em']),'caminho'=>$e['caminho'],'metrica'=>$e['metrica'],'detalhe'=>$e['detalhe'],'ancora'=>$e['ancora'],'navegacao'=>$e['navegacao']??'Indisponível');}self::tabela($rows);
            if(!empty($r['corte'])){echo '<p>Exibidos os 500 eventos mais recentes disponíveis.</p>';}
        }echo '</details>';
    }
    public static function tabela(array $rows): void {if(!$rows){echo '<p>Sem observações disponíveis com estes filtros.</p>';return;}echo '<div style="overflow:auto"><table class="widefat striped"><thead><tr>';foreach(array_keys($rows[0]) as $k){echo '<th>'.esc_html(self::rotulo($k)).'</th>';}echo '</tr></thead><tbody>';foreach($rows as $row){echo '<tr>';foreach($row as $v){echo '<td>'.esc_html($v===null?'Indisponível':(string)$v).'</td>';}echo '</tr>';}echo '</tbody></table></div>';}
    public static function csv(): void {
        if(!current_user_can('manage_options')){wp_die('Sem permissão.',403);}check_admin_referer('f3base-relatorio');$e=self::filtros();$e['pagina']=1;$e['limite']=200;$e['comparar']=false;
        $r=self::consultar($e,true);if(empty($r['ok'])){wp_die(esc_html($r['codigo']),400);}$all=$r['linhas'];

        nocache_headers();header('Content-Type: text/csv; charset=UTF-8');header('Content-Disposition: attachment; filename="f3base-relatorio.csv"');$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,array('Período',$r['periodo']['de'],$r['periodo']['ate'],'Fuso',$r['periodo']['fuso'],'Extraído em UTC',gmdate('c')));fputcsv($out,array('Cobertura pareada (%)',$r['cobertura']['pareamento_pct']??'indisponível'));if($all){fputcsv($out,array_keys($all[0]));foreach($all as $line){fputcsv($out,array_map(static fn($v)=>F3Base_Acessos_Relatorio::celula_csv($v===null?'Indisponível':$v),$line));}}fclose($out);exit;
    }
}
