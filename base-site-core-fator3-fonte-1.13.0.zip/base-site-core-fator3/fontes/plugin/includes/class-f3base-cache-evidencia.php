<?php
/** Evidência limitada e durável. Leituras não migram, não sondam e não agendam. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Cache_Evidencia {
	public const OPTION    = 'f3base_cache_evidencia';
	public const TRAVAS    = 'f3base_cache_travas';
	public const INTERVALO = 60;
	public const JANELA    = 120;
	public const LEASE     = 120;
	public const ATRASO    = 300;
	public const MAX_RECUO = 900;

	/** A fotografia ignora caches de options de outro processo. */
	public static function ler(): array {
		return (array) F3Base_Options::fotografia( self::OPTION )['valor']; }
	public static function alterar( callable $mudar ): bool {
		for ( $i = 0; $i < 3; ++$i ) {
			$f = F3Base_Options::fotografia( self::OPTION );
			if ( $f['erro'] ) {
				return false; }
			$v = $mudar( (array) $f['valor'] );
			if ( null === $v ) {
				return false; }
			$r = F3Base_Options::gravar( self::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
			if ( ! empty( $r['persisted'] ) ) {
				return true; }
		}
		return false;
	}
	/** Campos fechados: nunca persiste corpos, tokens, cookies ou histórico crescente. */
	public static function prova( $p ): array {
		if ( ! is_array( $p ) || empty( $p ) ) {
			return array(); }
		$r = array();
		foreach ( array( 'contexto', 'geracao', 'id', 'plugin_version', 'origem', 'status', 'codigo', 'motivo', 'url', 'modo' ) as $k ) {
			$r[ $k ] = substr( is_scalar( $p[ $k ] ?? null ) ? (string) $p[ $k ] : '', 0, 'motivo' === $k ? 2048 : 512 ); }
		foreach ( array( 'checked_at', 'iniciado_em', 'concluido_em' ) as $k ) {
			$r[ $k ] = max( 0, (int) ( $p[ $k ] ?? 0 ) ); }
		$r['hit']        = ! empty( $p['hit'] );
		$r['persisted']  = ! empty( $p['persisted'] );
		$r['cabecalhos'] = array();
		foreach ( array_slice( (array) ( $p['cabecalhos'] ?? array() ), 0, 16, true ) as $k => $v ) {
			if ( is_string( $k ) && is_string( $v ) ) {
				$r['cabecalhos'][ substr( $k, 0, 64 ) ] = substr( $v, 0, 2048 ); }
		}
		$r['faltantes'] = self::textos( $p['faltantes'] ?? array(), 16 );
		$r['tokens']    = array();
		foreach ( array( 'endpoint-leads', 'comportamento' ) as $k ) {
			$t = $p['tokens'][ $k ] ?? null;
			if ( ! is_array( $t ) ) {
				continue; }
			$x = array(
				'status'        => sanitize_key( (string) ( $t['status'] ?? '' ) ),
				'codigo'        => sanitize_key( (string) ( $t['codigo'] ?? '' ) ),
				'url'           => substr( (string) ( $t['url'] ?? '' ), 0, 512 ),
				'checked_at'    => max( 0, (int) ( $t['checked_at'] ?? 0 ) ),
				'problemas'     => self::textos( $t['problemas'] ?? array(), 16 ),
				'corpos_sha256' => array(),
				'respostas'     => array(),
			);
			foreach ( self::textos( $t['corpos_sha256'] ?? array(), 2 ) as $hash ) {
				if ( preg_match( '/^[a-f0-9]{64}$/', $hash ) ) {
					$x['corpos_sha256'][] = $hash; }
			}
			foreach ( array_slice( (array) ( $t['respostas'] ?? array() ), 0, 2 ) as $resp ) {
				if ( is_array( $resp ) ) {
					$x['respostas'][] = array(
						'http_status'   => (int) ( $resp['http_status'] ?? 0 ),
						'cache_control' => self::textos( $resp['cache_control'] ?? array(), 8 ),
						'expires'       => substr( (string) ( $resp['expires'] ?? '' ), 0, 128 ),
					); }
			}
			$r['tokens'][ $k ] = $x;
		}
        $t = $p['artefato_cache'] ?? null;
        if ( is_array( $t ) ) {
            $r['artefato_cache'] = array();
            foreach ( array( 'status', 'codigo', 'sha256', 'sha256_escopo', 'expectativa', 'perfil_expectativa_anterior', 'caminho' ) as $k ) { $r['artefato_cache'][$k] = substr( (string) ( $t[$k] ?? '' ), 0, 512 ); }
            foreach ( array( 'http', 'bytes', 'checked_at' ) as $k ) { $r['artefato_cache'][$k] = max( 0, (int) ( $t[$k] ?? 0 ) ); }
            foreach ( array( 'corpo_vazio', 'corpo_completo', 'artefato_exposto' ) as $k ) { $r['artefato_cache'][$k] = ! empty( $t[$k] ); }
        }

		return $r;
	}
	private static function textos( $v, int $limite ): array {
		return array_map( static fn( $s ) => substr( $s, 0, 512 ), array_slice( array_values( array_filter( (array) $v, 'is_string' ) ), 0, $limite ) ); }
	public static function sanitizar( $v, $padrao ): array {
		$v = is_array( $v ) ? $v : array();
		$r = array(
			'versao'           => 1,
			'ultima_tentativa' => self::prova( $v['ultima_tentativa'] ?? array() ),
			'ultimo_sucesso'   => self::prova( $v['ultimo_sucesso'] ?? array() ),
		);
		foreach ( array( 'execucao', 'agenda', 'migracao', 'limpeza' ) as $grupo ) {
			$r[ $grupo ] = array();
			foreach ( array( 'id', 'origem', 'geracao', 'contexto', 'codigo', 'status' ) as $k ) {
				$r[ $grupo ][ $k ] = substr( is_scalar( $v[ $grupo ][ $k ] ?? null ) ? (string) $v[ $grupo ][ $k ] : '', 0, 128 ); }
			foreach ( array( 'iniciado_em', 'concluido_em', 'em', 'proxima_tentativa', 'falhas' ) as $k ) {
				$r[ $grupo ][ $k ] = max( 0, (int) ( $v[ $grupo ][ $k ] ?? 0 ) ); }
		}
		return $r;
	}
	public static function sanitizar_travas( $v, $padrao ): array {
		$r = array();
		foreach ( array( 'sonda', 'agenda' ) as $k ) {
			$r[ $k ] = array(
				'id'  => substr( is_string( $v[ $k ]['id'] ?? null ) ? $v[ $k ]['id'] : '', 0, 64 ),
				'ate' => max( 0, (int) ( $v[ $k ]['ate'] ?? 0 ) ),
			); }
		return $r;
	}
	public static function trava( string $nome ): array {
		return F3Base_Options::fotografia( self::TRAVAS )['valor'][ $nome ] ?? array(); }
	public static function adquirir( string $nome ): string {
		for ( $i = 0; $i < 3; ++$i ) {
			$f = F3Base_Options::fotografia( self::TRAVAS );
			if ( $f['erro'] || (int) ( $f['valor'][ $nome ]['ate'] ?? 0 ) > time() ) {
				return ''; }
			$v          = $f['valor'];
			$id         = wp_generate_uuid4();
			$v[ $nome ] = array(
				'id'  => $id,
				'ate' => time() + self::LEASE,
			);
			$r          = F3Base_Options::gravar( self::TRAVAS, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
			if ( ! empty( $r['persisted'] ) ) {
				return $id; }
		}
		return '';
	}
	public static function possui( string $nome, string $id ): bool {
		$t = self::trava( $nome );
		return '' !== $id && ( $t['id'] ?? '' ) === $id && (int) ( $t['ate'] ?? 0 ) > time(); }
	public static function liberar( string $nome, string $id ): void {
		for ( $i = 0; $i < 3; ++$i ) {
			$f = F3Base_Options::fotografia( self::TRAVAS );
			if ( $f['erro'] || ( $f['valor'][ $nome ]['id'] ?? '' ) !== $id ) {
				return; }
			$v          = $f['valor'];
			$v[ $nome ] = array(
				'id'  => '',
				'ate' => 0,
			);
			if ( ! empty( F3Base_Options::gravar( self::TRAVAS, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] )['persisted'] ) ) {
				return; }
		}
	}
	/** Executada somente por ativação, preparação pública, ação explícita ou cron. */
	public static function migrar(): bool {
		$f = F3Base_Options::fotografia( self::OPTION );
		if ( $f['erro'] ) {
			return false;
		} if ( ! empty( $f['valor']['migracao']['em'] ) ) {
			return true; }
		$p = get_transient( F3Base_Cache_Pagina::PROVA );
		// A ativação semeia o padrão vazio antes de instalar os módulos. Existir não significa ter migrado.
		$v      = (array) $f['valor'];
		$codigo = empty( F3Base_Cache_Pagina::estado()['versao'] ) ? 'instalacao_sem_historico' : 'historico_anterior_indisponivel';
		if ( ! empty( $v['ultima_tentativa'] ) || ! empty( $v['execucao']['iniciado_em'] ) ) {
			$codigo = 'registro_duravel_preservado'; } elseif ( is_array( $p ) && $p ) {
			$p['origem']           = 'legado_origem_desconhecida';
			$p['persisted']        = true;
			$v['ultima_tentativa'] = $p;
			if ( self::sucesso( $p ) ) {
				$v['ultimo_sucesso'] = $p;
			} $codigo = 'evidencia_legada_preservada'; }
			$v['migracao'] = array(
				'em'     => time(),
				'codigo' => $codigo,
			);
			$r             = F3Base_Options::gravar( self::OPTION, $v, F3Base_Options::ORIGEM_PADRAO, $f['revisao'] );
			if ( ! empty( $r['persisted'] ) ) {
				delete_transient( F3Base_Cache_Pagina::PROVA );
				return true; }
			return false;
	}
	public static function sucesso( array $p ): bool {
		if ( 'verified' !== ( $p['status'] ?? '' ) ) {
			return false; }
		if ( 'verified' !== ( $p['artefato_cache']['status'] ?? '' ) ) { return false; }
		foreach ( $p['tokens'] ?? array() as $t ) {
			if ( 'verified' !== ( $t['status'] ?? '' ) ) {
				return false; }
		}
		return true;
	}
	/** A mesma tarefa horária é movida; não existe um segundo cron de preload. */
	public static function agendar( int $quando, string $origem, bool $antecipar = true ): bool {
		$id = self::adquirir( 'agenda' );
		if ( '' === $id ) {
			return false; }
		try {
			$antes = (int) wp_next_scheduled( F3Base_Cache_Pagina::CRON );
			$alvo  = max( time() + 1, $quando );
			if ( $antecipar && $antes && $antes <= $alvo ) {
				$alvo = $antes; }
			$ok = true;
			if ( $antes !== $alvo ) {
				$r  = wp_schedule_event( $alvo, 'hourly', F3Base_Cache_Pagina::CRON, array(), true );
				$ok = ! is_wp_error( $r ) && (bool) $r;
				// Só remove o antigo depois de confirmar que há substituto; uma recusa não apaga o executor.
				if ( $ok ) {
					foreach ( _get_cron_array() as $ts => $hooks ) {
						if ( (int) $ts !== $alvo && isset( $hooks[ F3Base_Cache_Pagina::CRON ] ) ) {
							foreach ( $hooks[ F3Base_Cache_Pagina::CRON ] as $evento ) {
								$u = wp_unschedule_event( (int) $ts, F3Base_Cache_Pagina::CRON, $evento['args'], true );
								if ( is_wp_error( $u ) || ! $u ) {
									$ok = false; }
							}
						}
					}
				}
			}
			$gravou = self::alterar(
				static function ( $v ) use ( $ok, $origem ) {
					$v['agenda'] = array(
						'em'                => time(),
						'origem'            => $origem,
						'codigo'            => $ok ? 'agendado' : 'agendamento_falhou',
						'proxima_tentativa' => (int) wp_next_scheduled( F3Base_Cache_Pagina::CRON ),
					);
					return $v;
				}
			);
			return $ok && $gravou;
		} finally {
			self::liberar( 'agenda', $id ); }
	}
	public static function agenda(): array {
		$v      = self::ler();
		$p      = (int) wp_next_scheduled( F3Base_Cache_Pagina::CRON );
		$codigo = ! $p ? 'agendamento_ausente' : ( $p + self::ATRASO < time() ? 'cron_atrasado' : 'agendado' );
		if ( 'agendamento_falhou' === ( $v['agenda']['codigo'] ?? '' ) ) {
			$codigo = 'agendamento_falhou'; }
		return array(
			'codigo'              => $codigo,
			'proxima_verificacao' => $p,
			'atraso_segundos'     => $p ? max( 0, time() - $p ) : 0,
			'disparo_por_visitas' => ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ),
			'ultima_execucao'     => $v['execucao'] ?? array(),
			'ultimo_agendamento'  => $v['agenda'] ?? array(),
			'orientacao'          => 'O registro do evento não comprova execução. O cron do servidor pode executar a tarefa com DISABLE_WP_CRON ativo; confira origem, início/fim e atraso.',
		);
	}
}
