<?php
/** Serviços atuais do Core. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Servicos {
	public static function registrar_ability( string $nome, array $args ) {
		$args['meta']['fator3']['version'] = F3BASE_PLUGIN_VERSAO;
		return wp_register_ability( $nome, $args );
	}
	public static function ability( string $nome, string $descricao, callable $callback, array $properties = array(), array $required = array(), bool $read = true, string $cap = 'manage_options' ): void {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return; }
		self::registrar_ability(
			'f3base/' . $nome,
			array(
				'label'               => $descricao,
				'description'         => $descricao,
				'category'            => F3BASE_PREFIXO,
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => $properties,
					'required'             => $required,
					'additionalProperties' => false,
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => $callback,
				'permission_callback' => static fn()=>current_user_can( 'manage_options' ) || current_user_can( $cap ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array(
						'public' => true,
						'type'   => 'tool',
					),
					'annotations'  => array(
						'readonly'    => $read,
						'destructive' => 'leads-eliminar-registro' === $nome,
						'idempotent'  => true,
					),
				),
			)
		);
	}
	public static function iniciar(): void {
		F3Base_Configuracao_Atual::iniciar();
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			WP_CLI::add_command(
				'f3base politica-habilitar',
				static function (): void {
					$r = F3Base_Options::gravar( 'f3base_politica_canal', true, F3Base_Options::ORIGEM_MANUAL, F3Base_Options::revisao( 'f3base_politica_canal' ) );
					if ( empty( $r['ok'] ) ) {
						WP_CLI::error( 'Não foi possível habilitar o interruptor.' );
					} WP_CLI::success( 'Gestão explícita da política habilitada neste site.' );
				}
			); }
		if ( class_exists( 'F3Base_Formularios' ) ) {
			F3Base_Formularios::iniciar(); }
		if ( class_exists( 'F3Base_Leads_Admin' ) ) {
			F3Base_Leads_Admin::iniciar(); }
		if ( class_exists( 'F3Base_Leads_Notificacoes' ) ) {
			F3Base_Leads_Notificacoes::iniciar(); }
		F3Base_Llms_Cobertura::iniciar();
		if ( class_exists( 'F3Base_Conteudo_Privado' ) ) {
			F3Base_Conteudo_Privado::iniciar(); }
		add_action( 'wp_abilities_api_init', array( F3Base_Redirects_Servico::class, 'registrar' ) );
		add_action( 'wp_abilities_api_init', array( F3Base_Politica::class, 'registrar' ) );
		add_action(
			'wp_abilities_api_init',
			static function (): void {
				self::ability(
					'llms-cobertura-ler',
					'Consultar cobertura Markdown por item, sem conversão ou HTTP',
					static fn()=>array(
						'ok'        => true,
						'cobertura' => F3Base_Llms_Cobertura::resumo( F3Base_Modulo_Llms_Txt_Reserva::selecao( F3Base_Options::ler( 'f3base_llms' ) ) ),
					)
				);
			}
		);
		add_action( 'pre_post_update', array( F3Base_Redirects_Servico::class, 'antes_atualizar' ), 10, 2 );
		add_action( 'post_updated', array( F3Base_Redirects_Servico::class, 'historico' ), 10, 3 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_filter( 'render_block', array( __CLASS__, 'carimbar_cta' ), 30 );
		add_filter( 'the_content', array( __CLASS__, 'carimbar_cta' ), 30 );
		add_action( 'updated_option', array( __CLASS__, 'alteracao' ), 20, 3 );
		if ( class_exists( 'F3Base_Leads_Repositorio' ) ) {
			add_action( 'init', array( F3Base_Leads_Repositorio::class, 'instalar' ), 6 ); }
	}
	public static function booleano( $v ): bool {
		return (bool) $v; }
	public static function identidade( $v, $padrao = array() ): array {
		return is_array( $v ) ? $v : $padrao; }
	public static function catalogo( array $c ): array {
		foreach ( array( 'f3base_redirects', 'f3base_cabecalhos', 'f3base_nav_id', 'f3base_cadencia' ) as $n ) {
			$c[ $n ]['operavel'] = true;
			$c[ $n ]['recusa']   = array( __CLASS__, 'recusar' );
		}
		$c['f3base_redirects']['sanitiza'] = array( __CLASS__, 'identidade' );
		unset( $c['f3base_redirects']['na_escrita'] );
		$c['f3base_redirects']['schema_config']                           = F3Base_Redirects_Servico::schema_lista();
		$c['f3base_redirects']['schema_entrada']                          = $c['f3base_redirects']['schema_config'];
		$c['f3base_redirects']['verifica']                                = array( F3Base_Redirects_Servico::class, 'verificacao_config' );
		$c['f3base_nav_id']['schema_config']['minimum']                   = 1;
		$c['f3base_cabecalhos']['schema_entrada']                         = F3Base_Config_Contrato::schema_valor( $c['f3base_cabecalhos'] );
		$c['f3base_cabecalhos']['schema_entrada']['additionalProperties'] = false;
		unset( $c['f3base_cabecalhos']['na_escrita'] );
		$c['f3base_cadencia']['schema_entrada'] = array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'periodicidade'  => array(
					'type' => 'string',
					'enum' => F3Base_Options::PERIODICIDADES,
				),
				'apos_n_ajustes' => array(
					'type'    => 'integer',
					'minimum' => 0,
				),
			),
		);
		foreach ( array( 'f3base_redirects_evidencia', 'f3base_leads_estrutura', 'f3base_leads_privado', 'f3base_leads_notificacoes_estado' ) as $n ) {
			$c[ $n ] = array(
				'rotulo'          => $n,
				'descricao'       => 'Estado interno; não operável pelo canal genérico.',
				'operavel'        => false,
				'campo'           => 'grupo',
				'padrao'          => array(),
				'autoload'        => false,
				'estado_execucao' => true,
				'sanitiza'        => array( __CLASS__, 'identidade' ),
			);
		}
		$c[ F3Base_Options::OPTION_OPERAVEIS ] = array(
			'rotulo'    => 'Política de opções operáveis',
			'descricao' => 'Restrição explícita do site; gestão somente pelo serviço de política.',
			'operavel'  => false,
			'campo'     => 'json',
			'padrao'    => array(),
			'autoload'  => false,
			'sanitiza'  => array( __CLASS__, 'identidade' ),
		);
		$c['f3base_politica_canal']            = array(
			'rotulo'    => 'Gestão de política pelo canal',
			'descricao' => 'Interruptor ativado pelo painel ou WP-CLI.',
			'operavel'  => false,
			'campo'     => 'booleano',
			'padrao'    => false,
			'autoload'  => false,
			'sanitiza'  => array( __CLASS__, 'booleano' ),
		);
		if ( class_exists( 'F3Base_Formularios' ) ) {
			$c['f3base_formularios'] = array(
				'rotulo'         => 'Formulários próprios',
				'descricao'      => 'Definições revisionadas. Editor em Contatos → Formulários.',
				'operavel'       => true,
				'campo'          => 'json',
				'padrao'         => array(),
				'autoload'       => false,
				'sanitiza'       => array( __CLASS__, 'identidade' ),
				'recusa'         => array( F3Base_Formularios::class, 'recusar' ),
				'schema_entrada' => F3Base_Formularios::schema(),
				'schema_config'  => F3Base_Formularios::schema(),
			);
		}
		$c['f3base_contato']['padrao']                  += array(
			'avisar_por_clique'     => true,
			'avisar_por_formulario' => true,
			'classes_cta'           => array(),
		);
		$c['f3base_contato']['subcampos']['email_leads'] = array(
			'tipo'          => 'json',
			'rotulo'        => 'Destinatários internos (até cinco)',
			'schema_config' => array(
				'type'     => array( 'array', 'string' ),
				'items'    => array(
					'type'   => 'string',
					'format' => 'email',
				),
				'maxItems' => 5,
			),
		);
		foreach ( array( 'avisar_por_clique', 'avisar_por_formulario' ) as $k ) {
			$c['f3base_contato']['subcampos'][ $k ] = array(
				'tipo'   => 'booleano',
				'rotulo' => $k,
			); }
		$c['f3base_contato']['subcampos']['classes_cta'] = array(
			'tipo'          => 'json',
			'rotulo'        => 'Aliases de classe do CTA',
			'schema_config' => array(
				'type'     => 'array',
				'maxItems' => 20,
				'items'    => array(
					'type'    => 'string',
					'pattern' => '^[a-zA-Z][a-zA-Z0-9_-]{0,79}$',
				),
			),
		);
		$c['f3base_contato']['recusa']                   = array( __CLASS__, 'recusar' );
		$pessoas                                       = array(
			'type'     => 'array',
			'maxItems' => 50,
			'items'    => array(
				'type'                 => 'object',
				'additionalProperties' => false,
				'required'             => array( 'nome', 'paginas' ),
				'properties'           => array(
					'id'        => array(
						'type'   => 'string',
						'format' => 'uri',
					),
					'nome'      => array(
						'type'      => 'string',
						'minLength' => 1,
						'maxLength' => 200,
					),
					'cargo'     => array(
						'type'      => 'string',
						'maxLength' => 200,
					),
					'descricao' => array(
						'type'      => 'string',
						'maxLength' => 2000,
					),
					'same_as'   => array(
						'type'     => 'array',
						'maxItems' => 20,
						'items'    => array(
							'type'   => 'string',
							'format' => 'uri',
						),
					),
					'paginas'   => array(
						'type'     => 'array',
						'maxItems' => 100,
						'items'    => array(
							'type'    => 'integer',
							'minimum' => 1,
						),
					),
				),
			),
		);
		$c['f3base_seo_entidade']['padrao']['pessoas'] = array();
		$c['f3base_seo_entidade']['subcampos']['pessoas']  = array(
			'tipo'           => 'json',
			'rotulo'         => 'Pessoas por página',
			'schema_config'  => $pessoas,
			'schema_entrada' => $pessoas,
		);
		$c['f3base_llms']['padrao']['blocos_interface']    = array();
		$c['f3base_llms']['subcampos']['blocos_interface'] = array(
			'tipo'          => 'json',
			'rotulo'        => 'Blocos de interface excluídos da conversão',
			'schema_config' => array(
				'type'     => 'array',
				'maxItems' => 50,
				'items'    => array(
					'type'    => 'string',
					'pattern' => '^[a-z0-9-]+/[a-z0-9-]+$',
				),
			),
		);
		return F3Base_Configuracao_Atual::catalogo( $c );
	}
	public static function recusar( $v, array $d, string $n ): string {
		if ( 'f3base_redirects' === $n ) {
			$r = F3Base_Redirects_Servico::validar( $v );
			return $r['ok'] ? '' : implode( '; ', array_column( $r['erros'], 'codigo' ) ); }
		if ( 'f3base_nav_id' === $n ) {
			$p = is_int( $v ) ? get_post( $v ) : null;
			if ( ! $p || 'wp_navigation' !== $p->post_type || 'publish' !== $p->post_status ) {
				return 'Navegação deve ser um wp_navigation publicado com ID positivo.'; }
			return '';
		}
		if ( 'f3base_contato' === $n ) {
			if ( ! is_array( $v ) ) {
				return 'Contato deve ser objeto.'; }
			$emails = $v['email_leads'] ?? array();
			$emails = is_string( $emails ) ? array_filter( array( $emails ) ) : $emails;
			if ( ! is_array( $emails ) || count( $emails ) > 5 ) {
				return 'Até cinco destinatários internos.'; }
			foreach ( $emails as $e ) {
				if ( ! is_string( $e ) || ! is_email( $e ) || preg_match( '/[\r\n]/', $e ) ) {
					return 'Destinatário inválido.'; }
			}
			foreach ( $v['classes_cta'] ?? array() as $cl ) {
				if ( ! is_string( $cl ) || ! preg_match( '/^[a-zA-Z][a-zA-Z0-9_-]{0,79}$/D', $cl ) ) {
					return 'Classe de CTA inválida.'; }
			}
			return '';
		}
		if ( ! is_array( $v ) ) {
			return 'Objeto obrigatório.'; }
		if ( 'f3base_cabecalhos' === $n ) {
			if ( array_diff( array_keys( $v ), array_keys( $d['padrao'] ) ) ) {
				return 'Cabeçalho desconhecido.'; }
			$r = rest_validate_value_from_schema( $v, $d['schema_entrada'], $n );
			return is_wp_error( $r ) ? $r->get_error_message() : '';
		}
		if ( 'f3base_cadencia' === $n ) {
			foreach ( array( 'hook', 'mecanismo' ) as $k ) {
				if ( isset( $v[ $k ] ) && $v[ $k ] !== ( F3Base_Options::ler( $n )[ $k ] ?? '' ) ) { // phpcs:ignore WordPress.PHP.YodaConditions.NotYoda -- Comparison of runtime expressions; neither side is an assignable literal.
					return 'hook e mecanismo são controlados pelo serviço.'; }
			}
			if ( array_diff( array_keys( $v ), array( 'periodicidade', 'apos_n_ajustes', 'hook', 'mecanismo' ) ) || ( isset( $v['periodicidade'] ) && ! in_array( $v['periodicidade'], F3Base_Options::PERIODICIDADES, true ) ) || ( isset( $v['apos_n_ajustes'] ) && ( ! is_int( $v['apos_n_ajustes'] ) || $v['apos_n_ajustes'] < 0 ) ) ) {
				return 'Cadência inválida.'; }
		}
		return '';
	}
	public static function motivo_acesso( string $n ): string {
		$d = F3Base_Options::declaracao( $n );
		return null === $d ? 'option_desconhecida' : ( empty( $d['operavel'] ) ? 'catalogo_nao_operavel' : ( F3Base_Options::operavel( $n ) ? 'operavel' : 'restrita_pelo_site' ) );
	}
	public static function carimbar_cta( string $html ): string {
		if ( ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
			return $html; }
		$classes = array_merge( array( 'f3base-acao-contato' ), (array) ( F3Base_Options::ler( 'f3base_contato' )['classes_cta'] ?? array() ) );
		$p       = new WP_HTML_Tag_Processor( $html );
		while ( $p->next_tag() ) {
			if ( 'A' !== $p->get_tag() || ! $p->get_attribute( 'href' ) || $p->get_attribute( 'data-f3base-lead' ) !== null ) {
				continue; }
			foreach ( $classes as $cl ) {
				if ( $p->has_class( $cl ) ) {
					$p->set_attribute( 'data-f3base-lead', 'whatsapp' );
					break; }
			}
		}
		return $p->get_updated_html();
	}
	public static function alteracao( string $n, $antes, $depois ): void {
		if ( 'f3base_cadencia' !== $n || $antes === $depois ) {
			return; }
		$hook = (string) ( $depois['hook'] ?? '' );
		if ( $hook ) {
			wp_clear_scheduled_hook( $hook ); }
		// The cadence module owns scheduling and its counters; next init rebuilds only its event.
	}
	public static function pessoas( array $grafo, array $e, int $id ): array {
		if ( $id < 1 || ! is_singular() ) {
			return $grafo; }
		$lista = (array) ( $e['pessoas'] ?? array() );
		if ( is_array( $e['pessoa'] ?? null ) && ! empty( $e['pessoa']['paginas'] ) ) {
			$lista[] = $e['pessoa']; }
		foreach ( $lista as $p ) {
			if ( ! in_array( $id, (array) ( $p['paginas'] ?? array() ), true ) || empty( $p['nome'] ) ) {
				continue; }
			$ident = $p['id'] ?? home_url( '/#/schema/person/' . substr( hash( 'sha256', $p['nome'] ), 0, 24 ) );
			$no    = array(
				'@type' => 'Person',
				'@id'   => $ident,
				'name'  => $p['nome'],
			);
			foreach ( array(
				'cargo'     => 'jobTitle',
				'descricao' => 'description',
				'same_as'   => 'sameAs',
			) as $de => $para ) {
				if ( ! empty( $p[ $de ] ) ) {
					$no[ $para ] = $p[ $de ]; }
			}
			$existe = false;
			foreach ( $grafo as &$g ) {
				if ( ( $g['@id'] ?? '' ) === $ident ) {
					$g      = $g + $no;
					$existe = true;
					break;
				}
			} unset( $g );
			if ( ! $existe ) {
				$grafo[] = $no; }
		}
		return $grafo;
	}
	public static function schema_origens(): array {
		$core   = (array) ( F3Base_Options::ler( 'f3base_seo_entidade' )['same_as'] ?? array() );
		$social = (array) get_option( 'wpseo_social', array() );
		$yoast  = array();
		foreach ( array( 'facebook_site', 'instagram_url', 'linkedin_url', 'myspace_url', 'pinterest_url', 'youtube_url', 'wikipedia_url' ) as $key ) {
			if ( is_string( $social[ $key ] ?? null ) && F3Base_Seo_Entidade::https( $social[ $key ] ) ) {
				$yoast[] = $social[ $key ]; }
		}
		foreach ( (array) ( $social['other_social_urls'] ?? array() ) as $url ) {
			if ( F3Base_Seo_Entidade::https( $url ) ) {
				$yoast[] = $url; }
		}
		$r = array();
		foreach ( array_unique( array_merge( $core, $yoast ) ) as $url ) {
			$r[] = array(
				'url'    => $url,
				'origem' => in_array( $url, $core, true ) ? ( in_array( $url, $yoast, true ) ? 'ambos' : 'core' ) : 'yoast',
			); }
		$titles = (array) get_option( 'wpseo_titles', array() );
		return array(
			'same_as_configurado'    => $r,
			'origem_de_terceiros'    => 'desconhecida_sem_evidencia',
			'yoast_tipo'             => $titles['company_or_person'] ?? 'nao_declarado',
			'yoast_empresa_sem_logo' => ( 'company' === ( $titles['company_or_person'] ?? '' ) && empty( $titles['company_logo'] ) && empty( $titles['company_logo_id'] ) ),
		);
	}
	public static function menu(): void {}
	public static function tela(): void { F3Base_Politica::tela(); }
}
