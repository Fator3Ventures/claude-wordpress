<?php
/** Durable notification intent is part of each persisted lead. No visitor mail. */
declare(strict_types=1);
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Leads_Notificacoes {
	const EVENTO = 'f3base_leads_resumo';
	public static function iniciar(): void {
		add_action( self::EVENTO, array( __CLASS__, 'resumo' ) );
		add_action(
			'init',
			static function (): void {
				if ( ! wp_next_scheduled( self::EVENTO ) ) {
					wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::EVENTO );
				} },
			50
		);
	}
	public static function destinatarios( $v ): array {
		if ( is_string( $v ) ) {
			$v = array( $v );
		} return array_slice( array_values( array_unique( array_filter( (array) $v, static fn( $e )=>is_string( $e ) && is_email( $e ) && ! preg_match( '/[\r\n]/', $e ) ) ) ), 0, 5 );
	}
	public static function enviar( string $record ): array {
		global $wpdb;
		$t    = F3Base_Leads_Repositorio::tabela();
		$lead = F3Base_Leads_Repositorio::obter( $record );
		if ( ! $lead || 'pendente' !== $lead['aviso'] || 'suspeito' === $lead['captura'] || $lead['lixeira'] || $lead['eliminacao_pendente'] ) {
			return array( 'codigo' => 'nao_elegivel' ); }
		$to = self::destinatarios( $lead['dados']['destinatarios'] ?? array() );
		if ( ! $to ) {
			$wpdb->update(
				$t,
				array( 'aviso' => 'desconfigurado' ),
				array(
					'record_id' => $record,
					'aviso'     => 'pendente',
				)
			);
			return array( 'codigo' => 'destinatario_ausente' ); }
		$janela = (string) floor( time() / HOUR_IN_SECONDS );
		if ( ! F3Base_Leads_Repositorio::quota( 'email:' . $janela, 30, (int) ( (int) $janela + 2 ) * HOUR_IN_SECONDS ) ) {
			return array( 'codigo' => 'aguarda_resumo' ); }
		if ( 1 !== $wpdb->update(
			$t,
			array(
				'aviso'    => 'enviando',
				'aviso_em' => time(),
			),
			array(
				'record_id' => $record,
				'aviso'     => 'pendente',
			)
		) ) {
			return array( 'codigo' => 'reservado' ); }
		$titulo  = sanitize_text_field( (string) ( $lead['dados']['assunto'] ?? 'Novo contato' ) );
		$assunto = '[' . sanitize_text_field( get_bloginfo( 'name' ) ) . '] ' . $titulo . ' — ' . $lead['metodo'];
		$body    = 'Contato registrado em ' . $lead['criado_em'] . " (UTC)\nMétodo: " . $lead['metodo'] . "\nPágina: " . $lead['pagina'] . "\n";
		foreach ( (array) ( $lead['dados']['campos'] ?? array() ) as $k => $v ) {
			$body .= sanitize_text_field( (string) $k ) . ': ' . ( is_scalar( $v ) ? (string) $v : wp_json_encode( $v ) ) . "\n"; }
		$body   .= "\nConsultar contato e anexos (login necessário): " . admin_url( 'admin.php?page=f3base-leads&record_id=' . $record ) . "\n";
		$host    = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$from    = 'site@' . preg_replace( '/^www\./', '', $host );
		$headers = array( 'Content-Type: text/plain; charset=UTF-8', 'From: ' . sanitize_text_field( get_bloginfo( 'name' ) ) . ' <' . $from . '>', 'X-F3base-Formulario: ' . sanitize_key( $lead['formulario'] ), 'X-F3base-Metodo: ' . sanitize_key( $lead['metodo'] ) );
		if ( is_email( $lead['email'] ) && ! preg_match( '/[\r\n]/', $lead['email'] ) ) {
			$headers[] = 'Reply-To: ' . $lead['email']; }
		// A crash/timeout leaves sending -> uncertain; it is never retried silently.
		$timeout = static function ( $mail ): void {
			$mail->Timeout   = 10; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Public PHPMailer property spelling is defined by the transport API.
			$mail->Timelimit = 10; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- Public PHPMailer property spelling is defined by the transport API.
		};
		add_action( 'phpmailer_init', $timeout );
		try {
			$ok     = wp_mail( $to, $assunto, $body, $headers );
			$estado = $ok ? 'processado' : 'falhou'; } catch ( Throwable $e ) {
			$ok     = false;
			$estado = 'incerto'; } finally {
				remove_action( 'phpmailer_init', $timeout ); }
			$wpdb->update(
				$t,
				array(
					'aviso'      => $estado,
					'aviso_em'   => time(),
					'aviso_erro' => $ok ? '' : 'transporte_sem_confirmacao',
				),
				array(
					'record_id' => $record,
					'aviso'     => 'enviando',
				)
			);
		return array(
			'codigo'      => $estado,
			'recebimento' => 'nao_comprovado',
		);
	}
	public static function reenviar( array $e ): array {
		if ( ! F3Base_Leads_Admin::pode( 'f3base_gerir_leads' ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'sem_permissao',
			); }
		$r = F3Base_Leads_Repositorio::obter( $e['record_id'] ?? '' );
		if ( ! $r || $r['eliminacao_pendente'] || $r['lixeira'] || 'suspeito' === $r['captura'] ) {
			return array(
				'ok'     => false,
				'codigo' => 'nao_elegivel',
			); }
		$rev = hash( 'sha256', $r['aviso'] . '|' . $r['aviso_em'] . '|' . $r['revisao'] );
		if ( ( ! ( $e['simular'] ?? true ) || isset( $e['revisao_esperada'] ) ) && ! hash_equals( $rev, (string) ( $e['revisao_esperada'] ?? '' ) ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'conflito',
			); }
		if ( ! in_array( $r['aviso'], array( 'falhou', 'incerto', 'desconfigurado', 'pendente' ), true ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'estado_nao_reenviavel',
			); }
		if ( $e['simular'] ?? true ) {
			return array(
				'ok'                      => true,
				'simulado'                => true,
				'estado'                  => $r['aviso'],
				'revisao'                 => $rev,
				'exige_aceite_duplicacao' => 'incerto' === $r['aviso'],
			); }
		if ( 'incerto' === $r['aviso'] && empty( $e['aceitar_possivel_duplicacao'] ) ) {
			return array(
				'ok'     => false,
				'codigo' => 'reconciliar_transporte_ou_aceitar_duplicacao',
			); }
		global $wpdb;
		$ok = $wpdb->update(
			F3Base_Leads_Repositorio::tabela(),
			array(
				'aviso'    => 'pendente',
				'aviso_em' => time(),
			),
			array(
				'record_id' => $r['record_id'],
				'aviso'     => $r['aviso'],
				'aviso_em'  => $r['aviso_em'],
				'revisao'   => $r['revisao'],
			)
		);
		return 1 === $ok ? array(
			'ok'        => true,
			'resultado' => self::enviar( $r['record_id'] ),
		) : array(
			'ok'     => false,
			'codigo' => 'conflito',
		);
	}
	public static function resumo(): void {
		global $wpdb;
		$t = F3Base_Leads_Repositorio::tabela();
		$wpdb->query( $wpdb->prepare( 'UPDATE %i SET aviso=%s WHERE aviso=%s AND aviso_em<%d', $t, 'incerto', 'enviando', time() - 300 ) );
		$corte  = (int) floor( time() / HOUR_IN_SECONDS ) * HOUR_IN_SECONDS;
		$janela = (string) ( $corte - HOUR_IN_SECONDS );
		$ids    = $wpdb->get_col( $wpdb->prepare( 'SELECT record_id FROM %i WHERE aviso=%s AND captura<>%s AND lixeira=0 AND eliminacao_pendente=0 AND criado_em<%s ORDER BY criado_em LIMIT 1000', $t, 'pendente', 'suspeito', gmdate( 'Y-m-d H:i:s', $corte ) ) );
		if ( ! $ids ) {
			F3Base_Arquivos_Privados::limpar_orfaos();
			return; }
		$to = self::destinatarios( F3Base_Options::ler( 'f3base_contato' )['email_leads'] ?? array() );
		if ( ! $to || ! F3Base_Leads_Repositorio::quota( 'resumo:' . $janela, 1, time() + 2 * DAY_IN_SECONDS ) ) {
			return; }
		$selecionados = array();
		foreach ( $ids as $id ) {
			if ( 1 === $wpdb->update(
				$t,
				array(
					'aviso'    => 'enviando',
					'aviso_em' => time(),
				),
				array(
					'record_id' => $id,
					'aviso'     => 'pendente',
				)
			) ) {
				$selecionados[] = $id; }
		}
		if ( ! $selecionados ) {
			return; }
		try {
			$ok     = wp_mail( $to, 'Resumo de contatos — ' . sanitize_text_field( get_bloginfo( 'name' ) ), count( $selecionados ) . " contatos aguardam atendimento.\n" . admin_url( 'admin.php?page=f3base-leads' ), array( 'Content-Type: text/plain; charset=UTF-8' ) );
			$estado = $ok ? 'resumo_processado' : 'falhou'; } catch ( Throwable $e ) {
			$estado = 'incerto'; }
			foreach ( $selecionados as $id ) {
				$wpdb->update(
					$t,
					array(
						'aviso'    => $estado,
						'aviso_em' => time(),
					),
					array(
						'record_id' => $id,
						'aviso'     => 'enviando',
					)
				); }
			F3Base_Options::atualizar_estado(
				'f3base_leads_notificacoes_estado',
				static fn()=>array(
					'ultimo_resumo' => time(),
					'estado'        => $estado,
					'quantidade'    => count( $selecionados ),
					'executor'      => 'wp_cron_oportunista',
				)
			);
		$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE expira<%d', F3Base_Leads_Repositorio::tabela( 'leads_janelas' ), time() ) );
		F3Base_Arquivos_Privados::limpar_orfaos();
	}
}
