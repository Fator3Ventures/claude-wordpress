# Instruções para agentes — Core 1.13.0

1. Leia DOCUMENTACAO.md e o contrato publicado pelo runtime. Descubra abilities antes de executá-las; disponibilidade não concede autorização.
2. Use as capabilities do usuário autenticado. Relatórios integrados, jornada e documentação exigem `manage_options`.
3. Para permissões, leia `f3base/config-core-politica-ler`. A política é `{schema:1,modo:"todas"|"selecionadas"|"nenhuma",lista:[]}`. Uma seleção exige lista não vazia e elegível. Nos outros modos a lista deve ser vazia.
4. Simule com `f3base/config-core-politica-escrever`; compare acréscimos/remoções. Para aplicar, envie `simular:false` e a revisão lida. Releia em conflito. A gestão por agentes desligada bloqueia a escrita remota da política; não é um interruptor geral de rotas.
5. Para análise, use `f3base/relatorios-integrados-ler`. Consulte docs/RELATORIOS.md para unidades, cobertura, limites e filtros. Não some cliques com envios como se fossem vendas.
6. `f3base/lead-jornada-ler` recebe `record_id`. Não deduza sessão por IP, e-mail ou proximidade de horário. Múltiplas abas, consentimento, relógios e retenção limitam a reconstrução.
7. Confirme `persisted` e a leitura de volta em mutações. SMTP processado não prova entrega; concessão usada não prova download completo. Não publique dados pessoais de contatos em relatórios públicos.
8. Suporte de atualização começa na 1.12.0. Não acione importação/reparo antigo nem remova marcadores para repetir defaults. A atualização atual não altera a lista corrigida na frota por substituição automática.

A documentação acompanha o instalador. `f3base/documentacao-ler` oferece o índice e leitura paginada quando a Abilities API e o canal autenticado estão disponíveis.
