# Changelog

## 1.13.0 — 2026-09-24

- Relatórios integrados no painel, CSV e abilities; jornada no contato; cobertura, filtros e comparação.
- Coleta local de funil, navegação, atribuição de sessão, dispositivo e revisão final de vitais; consentimento, quotas e deduplicação.
- Snapshot de opções estruturadas e histórico transacional de atendimento.
- Política explícita Todas/Selecionadas/Nenhuma, prévia de alterações, revisões e gestão por agentes reversível.
- Instalação direta e atualização mínima 1.12.0; preserva políticas existentes, inclusive lista vazia (backlog 29), sem reabrir permissões.
- Sonda de cache reconhece artefatos `wp-cache-*.php` e HTML (backlog 28), sem reduzir a exigência de corpo vazio.
- Retira gravação Flamingo/CPT, reparador histórico, conversão antiga da fila CAPI e desativação automática de cópias antigas.
- Documentação operacional e de agentes incluída no plugin instalado; contrato 2.0.0.

## Histórico até 1.12.0

# Alterações — 1.12.0 — 24/09/2026

- Seletores para campos enumerados; caixas de seleção pesquisáveis para blocos, preservando identificadores indisponíveis.
- Contato organizado em avisos internos, WhatsApp e instrumentação dos botões, com rótulos e ajuda. Até cinco destinatários em campos de e-mail.
- Operação Core integrada à aba Operação do menu F3 Base; o endereço administrativo anterior encaminha ao novo.
- Política de gestão e catálogo operável habilitados na primeira atualização, com fotografia, revisão e marcador por site.
- Leads com sessão canônica, correlação, post_id resolvido no servidor e contexto de IP/user agent. Ausência de sessão tem motivo; não se inventa vínculo histórico.
- Métodos de CTA definidos pelo destino, incluindo `contato_cta` para destino interno, telefone e e-mail. Abrir diálogo continua sem registrar lead.
- Reparo em lotes dos registros já copiados, com evidência preservada ou mapeamento explícito de canal/formulário/campos. Nenhum importador CF7/Flamingo no runtime.
- Saúde e instruções do endpoint identificam o destino `f3base_leads`.
- Arquivos sem `max_bytes` ou com zero ficam sem teto do plugin; extensões vazias não restringem. Limites positivos existentes são preservados.
- Provisionamento e teste de escrita/leitura/remoção da pasta privada; diagnóstico distingue ausência criável e impossibilidade.
- Sonda HTTP do artefato de cache exige corpo vazio, persiste prova e afeta o sucesso agregado na mesma cadência de tokens.
- Web Vitals 6.2.1 local carregado após `load`, com retenção mínima das interações curtas anteriores e correção local de CLS preservada. O arquivo anterior já era minificado; não há alegação de ganho de nota por minificação.
- Resposta ao visitante opcional por formulário, independente do aviso interno, com estado persistente, reserva de envio, limite de frequência e retentativa explícita para estado incerto.
- Documentação versionada incluída no instalador e consultável por ability.
