/** Consentimento legado ou granular opcional. Negativas locais valem imediatamente;
 * comprovante e revogação da fila só são confirmados após resposta do servidor.
 * A política declarada é preservada na atualização. Consent Mode não controla tags externas ao Core.
 */
(function (window, document) {
	'use strict';

	var dados = window.f3baseConsentimentoDados;

	if (!dados || typeof dados !== 'object') {
		return;
	}

	var CATEGORIAS = Array.isArray(dados.categorias) && dados.categorias.length
		? dados.categorias
		: ['analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization'];

	/**
	 * Booleano que atravessou `wp_localize_script`, lido como booleano.
	 *
	 * O que o servidor manda é `true`/`false`; o que chega aqui é `"1"`/`""`,
	 * porque `wp_localize_script` reduz TODO escalar de primeiro nível a string.
	 * `""` é falso por acidente e `"0"` seria VERDADEIRO — a próxima pessoa que
	 * mandasse `0` em vez de `false` ligaria o controle achando que o desligou.
	 * Ler o valor por uma lista fechada de formas falsas tira essa armadilha do
	 * caminho, e vale igual para o dia em que a chave viajar aninhada e chegar
	 * como booleano de verdade.
	 */
	function verdadeiro(valor) {
		return valor !== false && valor !== 0 && valor !== '' && valor !== '0'
			&& valor !== null && valor !== undefined && valor !== 'false';
	}

	var COOKIE = String(dados.cookie || 'f3base_consentimento');
	var TTL_DIAS = parseInt(dados.ttlDias, 10) > 0 ? parseInt(dados.ttlDias, 10) : 180;
	var GRANULAR = dados.modo === 'granular';
	var VERSAO = String(dados.politicaVersao || '1');
	var confirmado = '';
	var geracao = 0;
	var sincronizacao = Promise.resolve();
	var pendenciaServidor = false;
	var PRE_APROVADO = String(dados.padrao || 'pre-aprovado') === 'pre-aprovado';
	var TEXTOS = dados.textos && typeof dados.textos === 'object' ? dados.textos : {};

	var ID_BANNER = String(dados.idBanner || 'f3base-consentimento-banner');
	var SELETOR_CONTROLE = String(dados.seletorControle || '[data-f3base-consentimento]');

	var banner = null;
	var aviso = null;
	var abridor = null;

	window.dataLayer = window.dataLayer || [];

	function gtag() {
		window.dataLayer.push(arguments);
	}

	if (typeof window.gtag !== 'function') {
		window.gtag = gtag;
	}

	function lerCookie(nome) {
		var partes = String(document.cookie || '').split(';');
		var i;
		var atual;

		for (i = 0; i < partes.length; i++) {
			atual = partes[i].replace(/^\s+/, '');
			if (atual.indexOf(nome + '=') === 0) {
				try { return decodeURIComponent(atual.substring(nome.length + 1)); } catch (erro) { return ''; }
			}
		}

		return '';
	}

	function gravarCookie(nome, valor, dias) {
		var seguro = window.location.protocol === 'https:' ? '; Secure' : '';
		document.cookie = nome + '=' + encodeURIComponent(valor) +
			'; Max-Age=' + (dias * 86400) +
			'; Path=/; SameSite=Lax' + seguro;
	}

	function escolha() {
		if (!GRANULAR) { var legado = decisaoGravada(); var livre = legado ? legado === 'granted' : PRE_APROVADO; return { medicao: livre, publicidade: livre }; }
		try {
			var valor = JSON.parse(lerCookie(COOKIE));
			if (valor && valor.v === VERSAO && typeof valor.medicao === 'boolean' && typeof valor.publicidade === 'boolean') { return valor; }
		} catch (erro) { /* Cookie legado ou inválido não comprova decisão granular. */ }
		return { medicao: false, publicidade: false, v: VERSAO };
	}

	function permiteCategoria(categoria) { return escolha()[categoria] === true; }
	function permiteGtm() {
		return verdadeiro(dados.gtmSeparacaoVerificada)
			? permiteCategoria('medicao') || permiteCategoria('publicidade')
			: permiteCategoria('medicao') && permiteCategoria('publicidade');
	}

	function persistirPendencia(valor) {
		try {
			if (valor) { window.localStorage.setItem('f3base_consentimento_pendente', JSON.stringify(valor)); }
			else { window.localStorage.removeItem('f3base_consentimento_pendente'); }
		} catch (erro) { /* Negativa local vale mesmo com armazenamento indisponível. */ }
	}

	function sincronizarEscolha(valor, sequencia) {
		pendenciaServidor = true;
		sincronizacao = sincronizacao.catch(function () {}).then(function () {
			var operacao = { politica_versao: VERSAO, medicao: valor.medicao, publicidade: valor.publicidade, comprovante_anterior: confirmado };
			persistirPendencia(operacao);
			if (typeof window.fetch !== 'function' || !dados.endpoint) { throw new Error('servidor-indisponivel'); }
			var controle = typeof window.AbortController === 'function' ? new window.AbortController() : null;
			var limite;
			var expiracao = new Promise(function (resolver, rejeitar) { limite = setTimeout(function () { if (controle) { controle.abort(); } rejeitar(new Error('prazo-excedido')); }, 8000); });
			return Promise.race([expiracao, window.fetch(String(dados.endpoint), { signal: controle ? controle.signal : undefined, method: 'POST', credentials: 'same-origin', cache: 'no-store', keepalive: true,
				headers: { 'Content-Type': 'application/json', 'X-F3Base-Consentimento': '1' }, body: JSON.stringify(operacao)
			})]).catch(function (erro) { clearTimeout(limite); throw erro; }).then(function (resposta) { clearTimeout(limite); if (!resposta.ok) { throw new Error('nao-confirmado'); } return resposta.json(); }).then(function (retorno) {
				if (!retorno.persisted) { throw new Error('nao-confirmado'); }
				confirmado = String(retorno.comprovante || '');
				var corrente = escolha();
				if (sequencia === geracao && corrente.medicao === valor.medicao && corrente.publicidade === valor.publicidade) {
					valor.comprovante = confirmado;
					gravarCookie(COOKIE, JSON.stringify(valor), TTL_DIAS);
					persistirPendencia(null); pendenciaServidor = false;
					anunciar(estadoAtual()); sincronizarBanner();
				}
			});
		}).catch(function () { pendenciaServidor = true; sincronizarBanner(); });
		return sincronizacao;
	}

	function definirCategorias(medicao, publicidade) {
		if (!GRANULAR) { return definir(medicao === true && publicidade === true ? 'granted' : 'denied'); }
		var valor = { v: VERSAO, medicao: medicao === true, publicidade: publicidade === true, comprovante: '' };
		geracao += 1;
		pendenciaServidor = true;
		persistirPendencia({ politica_versao: VERSAO, medicao: valor.medicao, publicidade: valor.publicidade, comprovante_anterior: confirmado });
		gravarCookie(COOKIE, JSON.stringify(valor), TTL_DIAS);
		try { window.localStorage.setItem('f3base_consentimento_revisao', String(Date.now()) + ':' + geracao); } catch (erro) {}
		atualizar(estadoAtual()); anunciar(estadoAtual()); sincronizarBanner(); fecharAviso(); fechar();
		sincronizarEscolha(valor, geracao);
		return valor;
	}

	function decisaoGravada() {
		var valor = lerCookie(COOKIE);
		if (GRANULAR) { try { var c = JSON.parse(valor); return c.v === VERSAO ? (c.medicao && c.publicidade ? 'granted' : 'denied') : ''; } catch (erro) { return valor === 'denied' ? 'denied' : ''; } }

		return (valor === 'granted' || valor === 'denied') ? valor : '';
	}

	function estadoAtual() {
		if (GRANULAR) { return permiteCategoria('medicao') && permiteCategoria('publicidade') ? 'granted' : 'denied'; }
		var decisao = decisaoGravada();

		if (decisao) {
			return decisao;
		}

		return PRE_APROVADO ? 'granted' : 'denied';
	}

	function mapa(estado) {
		var saida = {};
		var i;

		for (i = 0; i < CATEGORIAS.length; i++) {
			saida[CATEGORIAS[i]] = GRANULAR ? (permiteCategoria(CATEGORIAS[i] === 'analytics_storage' ? 'medicao' : 'publicidade') ? 'granted' : 'denied') : estado;
		}

		saida.functionality_storage = 'granted';
		saida.security_storage = 'granted';

		return saida;
	}

	function aplicarPadrao() {
		window.gtag('consent', 'default', mapa(estadoAtual()));
	}

	function atualizar(estado) {
		window.gtag('consent', 'update', mapa(estado));
		window.dataLayer.push({
			event: 'f3base_consentimento',
			f3base_consentimento_estado: estado
		});
	}

	/**
	 * Grava a decisão, avisa a página e FECHA o banner.
	 *
	 * O fecho faz parte da decisão, e não é enfeite: até a 1.1.2 esta função
	 * gravava o cookie, atualizava o Consent Mode e sincronizava o texto — e
	 * deixava a caixa exatamente onde estava. Para quem clicava, "Permitir" e
	 * "Desligar" eram dois botões inertes: tudo o que eles faziam acontecia
	 * fora da tela. `fecharAviso()` removia o aviso de primeira visita, que é
	 * OUTRO elemento, e nunca tocou no banner.
	 */
	function definir(estado) {
		if (GRANULAR) { return definirCategorias(estado === 'granted', estado === 'granted'); }
		var normalizado = estado === 'granted' ? 'granted' : 'denied';

		gravarCookie(COOKIE, normalizado, TTL_DIAS);
		atualizar(normalizado);
		anunciar(normalizado);
		sincronizarBanner();
		fecharAviso();
		fechar();

		return normalizado;
	}

	/**
	 * Anuncia a decisão à página, para quem carrega tag depois dela.
	 *
	 * Evento de DOM, e não chamada direta: o consentimento não pode conhecer os
	 * consumidores dele — quem conhece a lista de tags é o módulo de tracking, e
	 * uma chamada daqui para lá inverteria a dependência.
	 */
	function anunciar(estado) {
		try {
			document.dispatchEvent(new CustomEvent('f3base-consentimento', {
				detail: { estado: estado, categorias: escolha(), pendente: pendenciaServidor }
			}));
		} catch (erro) {
			// Navegador sem CustomEvent construível: a decisão vale na próxima página.
		}
	}

	function botao(rotulo, aoClicar, classe) {
		var elemento = document.createElement('button');

		elemento.type = 'button';
		elemento.className = classe;
		elemento.textContent = rotulo;
		elemento.addEventListener('click', aoClicar);

		return elemento;
	}

	/**
	 * Constrói o banner FECHADO, uma vez, na carga da página.
	 *
	 * A caixa interna existe porque a faixa ocupa a largura do viewport e o
	 * conteúdo não pode: `.f3base-consentimento-caixa` é a regra do tema que
	 * limita a medida e centraliza. Até a 1.1.2 essa regra existia no CSS e
	 * NENHUM elemento a carregava — regra órfã, e a razão de o painel aparecer
	 * como um fundo chapado sem caixa nenhuma.
	 */
	function construirBanner() {
		var faixa = document.createElement('div');
		var caixa = document.createElement('div');
		var titulo = document.createElement('h2');
		var texto = document.createElement('p');
		var estado = document.createElement('p');
		var acoes = document.createElement('div');

		faixa.id = ID_BANNER;
		faixa.className = 'f3base-consentimento-banner';
		faixa.setAttribute('role', 'dialog');
		faixa.setAttribute('aria-modal', 'false');
		faixa.setAttribute('aria-label', String(TEXTOS.titulo || 'Consentimento'));
		faixa.setAttribute('tabindex', '-1');
		faixa.hidden = true;

		caixa.className = 'f3base-consentimento-caixa';

		titulo.className = 'f3base-consentimento-titulo';
		titulo.textContent = String(TEXTOS.titulo || '');

		texto.className = 'f3base-consentimento-texto';
		texto.textContent = String(TEXTOS.explicacao || '');

		estado.className = 'f3base-consentimento-estado';

		acoes.className = 'f3base-consentimento-acoes';
		var medicao, publicidade;
		if (GRANULAR) {
			var grupo = document.createElement('fieldset');
			var legenda = document.createElement('legend'); legenda.textContent = 'Escolha as finalidades'; grupo.appendChild(legenda);
			function categoria(rotulo) { var label = document.createElement('label'); var input = document.createElement('input'); input.type = 'checkbox'; label.appendChild(input); label.appendChild(document.createTextNode(' ' + rotulo)); grupo.appendChild(label); return input; }
			medicao = categoria('Medição de uso e desempenho'); publicidade = categoria('Publicidade e conversões');
			caixa.appendChild(grupo);
			acoes.appendChild(botao('Salvar escolhas', function () { definirCategorias(medicao.checked, publicidade.checked); }, 'f3base-consentimento-salvar'));
		}
		acoes.appendChild(botao(String(TEXTOS.aceitar || 'Permitir'), function () {
			definir('granted');
		}, 'f3base-consentimento-aceitar'));
		acoes.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-recusar'));
		acoes.appendChild(botao(String(TEXTOS.fechar || 'Fechar'), function () {
			fechar();
		}, 'f3base-consentimento-fechar'));

		caixa.appendChild(titulo);
		caixa.appendChild(texto);
		caixa.appendChild(estado);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.className = 'f3base-consentimento-politica';
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || 'Política de Privacidade');
			caixa.appendChild(link);
		}

		caixa.appendChild(acoes);
		faixa.appendChild(caixa);
		document.body.appendChild(faixa);

		banner = { faixa: faixa, estado: estado, medicao: medicao, publicidade: publicidade };
		estado.setAttribute('aria-live', 'polite');

		sincronizarBanner();

		return banner;
	}

	function sincronizarBanner() {
		if (!banner) {
			return;
		}

		if (GRANULAR) { var c = escolha(); banner.medicao.checked = c.medicao; banner.publicidade.checked = c.publicidade; banner.estado.textContent = 'Medição: ' + (c.medicao ? 'permitida' : 'desligada') + '. Publicidade: ' + (c.publicidade ? 'permitida' : 'desligada') + (pendenciaServidor ? '. Sincronização pendente no servidor; a escolha local já vale.' : '.'); return; }

		banner.estado.textContent = estadoAtual() === 'granted'
			? String(TEXTOS.estadoAtivo || '')
			: String(TEXTOS.estadoNegado || '');
	}

	/**
	 * Diz a cada controle do rodapé se o banner está aberto.
	 *
	 * `aria-expanded` é o que um leitor de tela anuncia; sem ele o visitante
	 * que aciona o controle uma segunda vez não tem como saber que aquilo que
	 * ele abriu continua aberto.
	 */
	function marcarControles(aberto) {
		var controles;
		var i;

		try {
			controles = document.querySelectorAll(SELETOR_CONTROLE);
		} catch (erro) {
			return;
		}

		for (i = 0; i < controles.length; i++) {
			controles[i].setAttribute('aria-expanded', aberto ? 'true' : 'false');
		}
	}

	/**
	 * Reserva, no corpo da página, exatamente a altura do banner.
	 *
	 * Sem isto a faixa fixa tampa o fim do documento — o rodapé, e com ele o
	 * próprio controle que a abriu — e o visitante não tem como rolar até lá.
	 * A medida sai do elemento renderizado; `0px` é o valor de repouso, e ele
	 * sai COM unidade porque é uma custom property consumida por `padding`.
	 */
	function reservarEspaco(aberto) {
		var raiz = document.documentElement;
		var altura;

		if (!raiz || !raiz.style) {
			return;
		}

		if (!aberto) {
			raiz.style.setProperty('--f3base-banner-altura', '0px');
			raiz.removeAttribute('data-f3base-banner');
			return;
		}

		altura = (banner && banner.faixa && banner.faixa.offsetHeight) || 0;

		raiz.style.setProperty('--f3base-banner-altura', altura + 'px');
		raiz.setAttribute('data-f3base-banner', 'aberto');
	}

	function abrir(origem) {
		if (!banner) {
			construirBanner();
		}

		abridor = origem || abridor;

		sincronizarBanner();
		banner.faixa.hidden = false;
		marcarControles(true);
		reservarEspaco(true);

		try {
			banner.faixa.focus();
		} catch (erro) {
			// Navegador que recusa foco em elemento com tabindex -1: o banner está aberto do mesmo jeito.
		}
	}

	/**
	 * Fecha o banner e DEVOLVE O FOCO a quem o abriu.
	 *
	 * Um lugar só, porque os três botões e o controle do rodapé precisam do
	 * mesmo comportamento. Sem a devolução do foco, quem fecha pelo teclado
	 * volta ao início do documento e perde o lugar onde estava lendo.
	 */
	function fechar() {
		if (!banner) {
			return;
		}

		banner.faixa.hidden = true;
		marcarControles(false);
		reservarEspaco(false);

		if (abridor && typeof abridor.focus === 'function') {
			try {
				abridor.focus();
			} catch (erro) {
				// Controle saiu do DOM entre abrir e fechar: nada a devolver.
			}
		}

		abridor = null;
	}

	function fecharAviso() {
		if (aviso && aviso.parentNode) {
			aviso.parentNode.removeChild(aviso);
			aviso = null;
		}
	}

	function mostrarAviso() {
		if (!verdadeiro(dados.avisoPrimeiraVisita)) {
			return;
		}

		if (decisaoGravada()) {
			return;
		}

		try {
			if (window.localStorage.getItem('f3base_aviso_visto') === '1') {
				return;
			}
			window.localStorage.setItem('f3base_aviso_visto', '1');
		} catch (erro) {
			// Armazenamento indisponível: o aviso aparece nesta visita e não persiste.
		}

		aviso = document.createElement('div');
		aviso.className = 'f3base-consentimento-aviso';
		aviso.setAttribute('role', 'status');

		var texto = document.createElement('span');
		texto.textContent = String(TEXTOS.aviso || '');
		aviso.appendChild(texto);

		if (dados.politicaUrl) {
			var link = document.createElement('a');
			link.href = String(dados.politicaUrl);
			link.textContent = String(TEXTOS.politica || '');
			aviso.appendChild(link);
		}

		aviso.appendChild(botao(String(TEXTOS.avisoOk || 'Ok'), fecharAviso, 'f3base-consentimento-aviso-ok'));
		aviso.appendChild(botao(String(TEXTOS.recusar || 'Desligar'), function () {
			definir('denied');
		}, 'f3base-consentimento-aviso-recusar'));

		document.body.appendChild(aviso);
	}

	function ligarControles() {
		document.addEventListener('click', function (evento) {
			var alvo = evento.target;

			while (alvo && alvo !== document.body) {
				if (alvo.nodeType === 1 && alvo.matches && alvo.matches(SELETOR_CONTROLE)) {
					evento.preventDefault();
					abrir(alvo);
					return;
				}
				alvo = alvo.parentNode;
			}
		});
	}

	/**
	 * Esc fecha o banner, e essa é a única tecla que ele captura.
	 *
	 * Ele NÃO é modal: não prende o foco, não desliga o resto da página e não
	 * intercepta Tab. Um banner que prendesse o foco obrigaria o visitante a
	 * decidir antes de continuar lendo, que é exatamente o oposto da política
	 * pré-aprovada deste pacote.
	 */
	function ligarEscape() {
		document.addEventListener('keydown', function (evento) {
			if (!banner || banner.faixa.hidden) {
				return;
			}

			if (evento.key === 'Escape' || evento.keyCode === 27) {
				fechar();
			}
		});
	}

	function iniciar() {
		if (verdadeiro(dados.controleRodape)) {
			construirBanner();
			ligarControles();
			ligarEscape();
		}

		mostrarAviso();
	}

	if (GRANULAR) {
		confirmado = String(escolha().comprovante || '');
		try { var pendente = JSON.parse(window.localStorage.getItem('f3base_consentimento_pendente') || 'null');
			if (pendente) { confirmado = String(pendente.comprovante_anterior || confirmado); var retomar = escolha(); sincronizarEscolha(retomar, geracao); }
		} catch (erro) { /* Falta de armazenamento não equivale a confirmação. */ }
	}
	window.addEventListener('storage', function (evento) { if (evento.key === 'f3base_consentimento_revisao') { geracao += 1; confirmado = String(escolha().comprovante || ''); atualizar(estadoAtual()); anunciar(estadoAtual()); sincronizarBanner(); } });
	aplicarPadrao();

	window.f3baseConsentimento = {
		estado: estadoAtual,
		categorias: escolha,
		permiteCategoria: permiteCategoria,
		permiteGtm: permiteGtm,
		definirCategorias: definirCategorias,
		servidorPendente: function () { return pendenciaServidor; },
		definir: definir,
		abrir: abrir,
		fechar: fechar,
		permiteTags: function () {
			return estadoAtual() === 'granted';
		}
	};

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', iniciar);
	} else {
		iniciar();
	}
}(window, document));
