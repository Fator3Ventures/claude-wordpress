/** Tempo ativo estimado: relógio monotônico, uma seção por instante e sem envio periódico. */
(function (root, factory) {
	if (typeof module === 'object' && module.exports) { module.exports = factory; }
	else { root.F3BaseTempoAtivo = factory; }
}(typeof window !== 'undefined' ? window : this, function (opcoes) {
	'use strict';
	var agora = opcoes.agora, ultimo = agora(), atividade = ultimo, secao = '', visivel = false;
	var limite = Math.max(1, Math.min(30000, Number(opcoes.inatividade) || 30000));
	var maximo = Math.max(1, Math.min(30000, Number(opcoes.maximo) || 30000));
	var soma = Object.create(null);
	function atualizar() {
		var atual = Math.max(ultimo, agora());
		var fim = Math.min(atual, atividade + limite);
		if (visivel && secao && opcoes.permitido() && fim > ultimo) { soma[secao] = (soma[secao] || 0) + fim - ultimo; }
		ultimo = atual;
		visivel = opcoes.visivel() && opcoes.permitido();
		secao = visivel ? opcoes.predominante() : '';
	}
	function flush() {
		atualizar();
		Object.keys(soma).forEach(function (nome) {
			var restante = Math.floor(soma[nome]);
			delete soma[nome];
			while (restante > 0) {
				var ms = Math.min(maximo, restante);
				if (opcoes.emitir(nome, ms) === false) { break; }
				restante -= ms;
			}
		});
	}
	atualizar();
	return {
		atualizar: atualizar,
		atividade: function () { atualizar(); atividade = ultimo; },
		flush: flush,
		descartar: function () { soma = Object.create(null); ultimo = agora(); atividade = ultimo; visivel = false; secao = ''; }
	};
}));
