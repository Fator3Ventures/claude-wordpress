/*! Editor de definições Core. GPL-2.0-or-later. */
(function () {
    'use strict';
    var raw = document.getElementById('f3base-definicoes');
    if (!raw) { return; }
    var host = document.createElement('div'), defs;
    raw.parentNode.insertBefore(host, raw);
    function node(tag, text) { var n=document.createElement(tag); if(text!==undefined){n.textContent=text;} return n; }
    function save() { raw.value=JSON.stringify(defs,null,2); }
    function button(parent,label,fn) { var b=node('button',label);b.type='button';b.className='button';b.addEventListener('click',fn);parent.appendChild(b); }
    function input(parent,obj,key,label,type,choices) {
        var wrap=node('label',label+' '), el=node((type==='list'||type==='textarea')?'textarea':(choices?'select':'input'));
        if(choices){choices.forEach(function(v){var o=node('option',v);o.value=v;el.appendChild(o);});}
        else if(type!=='list'&&type!=='textarea'){el.type=type||'text';}
        if(type==='checkbox'){el.checked=obj[key]===true;} else {el.value=type==='list'?(obj[key]||[]).join('\n'):(obj[key]===undefined?'':obj[key]);}
        wrap.style.cssText='display:inline-flex;flex-direction:column;margin:6px;vertical-align:top';
        if(type==='checkbox'){wrap.style.flexDirection='row';} el.addEventListener('change',function(){if(type==='checkbox'){obj[key]=el.checked;}else if(type==='number'){if(el.value===''){delete obj[key];}else{obj[key]=Number(el.value);}}else if(type==='list'){obj[key]=el.value.split('\n').filter(function(x){return x!=='';});}else{obj[key]=el.value;}save();});
        wrap.appendChild(el);parent.appendChild(wrap);
    }
    function draw() {
        host.replaceChildren();
        defs.forEach(function(f,fi){
            var box=node('details'), title=node('summary',f.titulo||f.id||'Novo formulário');box.open=true;box.style.cssText='border:1px solid #bbb;padding:12px;margin:16px 0';box.appendChild(title);
            input(box,f,'id','ID','text');input(box,f,'titulo','Título','text');input(box,f,'regime','Regime','text',['registro','whatsapp','conteudo']);if(f.regime===undefined){f.regime='registro';}
            if(f.ligado===undefined){f.ligado=true;}input(box,f,'ligado','Publicado','checkbox');input(box,f,'botao','Botão','text');input(box,f,'confirmacao','Confirmação','text');input(box,f,'assunto','Assunto interno','text');input(box,f,'destinatarios','Destinatários: um por linha','list');input(box,f,'whatsapp','WhatsApp (regime whatsapp)','text');input(box,f,'ativo','ID do ativo (regime conteudo)','text');input(box,f,'validade_dias','Validade em dias','number');input(box,f,'quota','Quota de tentativas','number');
            f.resposta_visitante=f.resposta_visitante||{ativa:false};
            var reply=node('fieldset'), legend=node('legend','Resposta automática ao visitante');reply.appendChild(legend);
            reply.appendChild(node('p','Desligada por padrão. Texto simples; variáveis: {{nome}}, {{formulario}}, {{site}}, {{record_id}}. Uma confirmação por envio aceito; falha de e-mail mantém o contato.'));
            input(reply,f.resposta_visitante,'ativa','Ativar resposta neste formulário','checkbox');
            input(reply,f.resposta_visitante,'campo_email','Campo com papel e-mail (vazio usa o único papel e-mail)','text',[''].concat((f.campos||[]).filter(function(c){return c.tipo==='email' && c.papel==='email';}).map(function(c){return c.nome;})));
            input(reply,f.resposta_visitante,'remetente','E-mail remetente configurado no transporte','email');
            input(reply,f.resposta_visitante,'nome_remetente','Nome do remetente','text');
            input(reply,f.resposta_visitante,'assunto','Assunto','text');
            input(reply,f.resposta_visitante,'corpo','Mensagem','textarea');box.appendChild(reply);
            (f.campos||[]).forEach(function(c,ci){var field=node('fieldset'),legend=node('legend',(ci+1)+'. '+(c.rotulo||c.nome));field.style.cssText='border:1px solid #ddd;padding:8px;margin:8px';field.appendChild(legend);
                input(field,c,'nome','Nome interno','text');input(field,c,'tipo','Tipo','text',['text','email','tel','textarea','select','radio','checkbox','url','file','static']);input(field,c,'rotulo','Rótulo','text');input(field,c,'obrigatorio','Obrigatório','checkbox');input(field,c,'papel','Papel','text',['outro','nome','email','telefone','mensagem']);input(field,c,'placeholder','Placeholder','text');input(field,c,'padrao','Valor padrão','text');input(field,c,'autocomplete','Autocomplete','text');input(field,c,'ajuda','Ajuda','text');input(field,c,'largura','Largura','number',['50','100']);input(field,c,'opcoes','Opções: uma por linha','list');input(field,c,'html','Texto estático (HTML permitido)','text');input(field,c,'max_bytes','Arquivo: bytes (vazio ou 0: sem teto do plugin)','number');input(field,c,'max_arquivos','Arquivos por campo (1 a 5)','number');input(field,c,'extensoes','Extensões: uma por linha; vazio aceita todas','list');
                button(field,'Subir',function(){if(ci){var x=f.campos.splice(ci,1)[0];f.campos.splice(ci-1,0,x);save();draw();}});button(field,'Descer',function(){if(ci<f.campos.length-1){var x=f.campos.splice(ci,1)[0];f.campos.splice(ci+1,0,x);save();draw();}});button(field,'Remover campo',function(){f.campos.splice(ci,1);save();draw();});box.appendChild(field);
            });
            button(box,'Adicionar campo',function(){f.campos=f.campos||[];f.campos.push({nome:'campo-'+(f.campos.length+1),tipo:'text',rotulo:'Novo campo',max_bytes:0,max_arquivos:5});save();draw();});
            button(box,'Remover definição',function(){defs.splice(fi,1);save();draw();});host.appendChild(box);
        });
        button(host,'Novo formulário',function(){defs.push({id:'formulario-'+(defs.length+1),titulo:'Novo formulário',regime:'registro',ligado:false,campos:[]});save();draw();});
    }
    try{defs=JSON.parse(raw.value);if(!Array.isArray(defs)){return;}draw();}catch(e){return;}
    raw.addEventListener('change',function(){try{var d=JSON.parse(raw.value);if(Array.isArray(d)){defs=d;draw();}}catch(e){/* The server validator reports exact errors without losing this draft. */}});
}());
