(function () {
  'use strict';
  var form = document.getElementById('f3base-acessos-filtros');
  if (!form) return;
  var auto = document.getElementById('f3base-acessos-auto');
  var intervalo = document.getElementById('f3base-acessos-intervalo');
  var status = document.getElementById('f3base-acessos-status');
  var result = document.getElementById('f3base-acessos-resultado');
  var timer = null, busy = false, falhas = 0;
  function dizer(s) { status.textContent = s; }
  function agendar() {
    clearTimeout(timer);
    if (!auto.checked) { dizer('Atualização automática desligada'); return; }
    if (document.hidden) { dizer('Pausada: aba oculta'); return; }
    timer = setTimeout(function () { atualizar(false); }, Math.min(300, Number(intervalo.value) * Math.pow(2, falhas)) * 1000);
  }
  function filtrosAplicados(efetivos) {
    if (efetivos) {
      ['dias', 'classificacao', 'mostrar_todos', 'incluir_erros', 'comparacao_hoje'].forEach(function (nome) {
        var campo = form.elements[nome];
        if (campo.type === 'checkbox') campo.checked = String(efetivos[nome]) === '1';
        else campo.value = String(efetivos[nome]);
      });
    }
    var url = new URL(location.href), csv = document.getElementById('f3base-acessos-csv'), coleta = document.getElementById('f3base-acessos-coleta');
    ['dias', 'classificacao', 'mostrar_todos', 'incluir_erros', 'comparacao_hoje'].forEach(function (nome) {
      var campo = form.elements[nome], valor = campo.type === 'checkbox' ? (campo.checked ? '1' : '0') : campo.value;
      url.searchParams.set(nome, valor);
      if (csv && csv.elements[nome]) csv.elements[nome].value = valor;
      if (coleta && coleta.elements[nome]) coleta.elements[nome].value = valor;
    });
    history.replaceState(null, '', url.toString());
  }
  function atualizar(manual) {
    if (busy || (!manual && (!auto.checked || document.hidden))) { agendar(); return; }
    busy = true; clearTimeout(timer); dizer('Atualizando…');
    if (form.elements.classificacao.value === 'inexistentes' && !form.elements.mostrar_todos.checked) form.elements.incluir_erros.checked = true;
    var data = new FormData(form), controller = new AbortController();
    var timeout = setTimeout(function () { controller.abort(); }, 30000);
    fetch(form.dataset.ajax, {method: 'POST', body: data, credentials: 'same-origin', signal: controller.signal})
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (r) {
        if (!r.success) throw new Error('Atualização recusada');
        var x = window.scrollX, y = window.scrollY;
        var scrolls = Array.from(result.querySelectorAll('[role=region]')).map(function (el) { return el.scrollLeft; });
        var detalhes = Array.from(result.querySelectorAll('details')).map(function (el) { return el.open; });
        result.innerHTML = r.data.html;
        result.querySelectorAll('[role=region]').forEach(function (el, i) { el.scrollLeft = scrolls[i] || 0; });
        result.querySelectorAll('details').forEach(function (el, i) { el.open = !!detalhes[i]; });
        window.scrollTo(x, y); filtrosAplicados(r.data.filtros);
        if (r.data.erro) { falhas = Math.min(4, falhas + 1); dizer('Atualização parcial: ' + r.data.erro); }
        else { falhas = 0; dizer('Atualizado às ' + new Date(r.data.atualizado * 1000).toLocaleTimeString()); }
      }).catch(function () { falhas = Math.min(4, falhas + 1); dizer('Falha na atualização; próxima tentativa com intervalo ampliado.'); })
      .finally(function () { clearTimeout(timeout); busy = false; if (auto.checked && !document.hidden) agendar(); });
  }
  function preferencia() {
    var data = new FormData(form); data.set('preferencia', '1'); data.set('somente_preferencia', '1'); data.set('automatico', auto.checked ? '1' : '0');
    fetch(form.dataset.ajax, {method: 'POST', body: data, credentials: 'same-origin'}).catch(function () { dizer('Preferência ainda não salva.'); });
    falhas = 0; agendar();
  }
  form.addEventListener('submit', function (e) { e.preventDefault(); atualizar(true); });
  auto.addEventListener('change', preferencia); intervalo.addEventListener('change', preferencia);
  document.addEventListener('visibilitychange', agendar); agendar();
})();
