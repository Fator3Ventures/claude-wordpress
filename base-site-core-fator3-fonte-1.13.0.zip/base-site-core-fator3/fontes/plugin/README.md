# Base Site Core Fator3 1.13.0

Instale `base-site-core-fator3-1.13.0.zip` pelo WordPress. Requisitos de PHP/WordPress permanecem no cabeçalho do plugin. Não instale o ZIP de fontes como plugin.

- **F3 Base → Operação:** configurações editáveis em três modos explícitos, prévia de acréscimos/remoções e controle independente de gestão por agentes.
- **Contatos → Relatórios:** conversão por página, métodos, campanhas, funil, conteúdo, qualidade técnica, operação, materiais e demanda. O detalhe de um contato mostra a jornada observada.
- Painel, CSV e abilities consultam as mesmas regras; volume, sessões, cobertura e dados indisponíveis permanecem distintos.
- Coleta adicional local sob permissão de medição, sem valores digitados nos eventos de formulário.
- Atualização preserva escolhas da base 1.12.0, sem abrir listas explícitas nem repetir a habilitação inicial.
- Sonda HTTP de cache aceita arquivos reais HTML e `wp-cache-*.php`, mantendo o aceite de corpo vazio.

A pasta privada é preparada automaticamente; anexos não têm teto de tamanho/extensão do pacote quando o campo não declara restrição. A resposta ao visitante é opcional e desligada por padrão.

Leia DOCUMENTACAO.md. CRM e webhook continuam reservados para uma versão posterior. Não há exclusão de dados por padrão na atualização.
