# Operação e recuperação — 1.13.0

## Instalação e atualização

Instalação nova requer ausência de opções e tabelas anteriores do Core. Cria o esquema atual diretamente, aplica política Todas, habilita gestão por agentes e prepara a pasta privada. Configurações sem recursos associados, como navegação, permanecem com o padrão não configurado do catálogo.

Na atualização, confirme a base 1.12.0 concluída. O estado `f3base_release_1130` registra origem, fotografia da política, transformação, confirmação e conclusão. A lista vazia da base mantém seu efeito como Todas; uma lista explícita mantém exatamente os itens selecionados. A atualização preserva o interruptor já desligado. A conclusão não é removida nem reaplicada para repetir defaults.

A trava evita duas atualizações concorrentes; checkpoints permitem retomar interrupções. Conflito de política impede sobrescrita. Versão anterior à base ou origem não comprovada interrompe o fluxo antes das transformações. Não há cadeia de instaladores/importadores históricos.

Confira estado concluído, pasta privada, um envio novo e saúde após instalar. Mantenha backup restaurável do banco, arquivos privados e código. Homologação de SMTP, infraestrutura e canal MCP deve ocorrer no ambiente de destino.

## Pasta privada

O caminho padrão é um diretório irmão da raiz WordPress: `f3-privado-` seguido de hash estável de ABSPATH. Instalações cujo pai também seja público precisam declarar `F3BASE_ARQUIVOS_PRIVADOS` no `wp-config.php`, apontando para uma pasta fora da raiz pública. O diretório pai deve existir e permitir criação/escrita. O caminho não depende do diretório de trabalho do CLI.

O teste de preparação cria um arquivo aleatório, grava, lê, confere, aplica permissão e remove. O diagnóstico distingue `pronto`, `ausente_criavel`, `sem_permissao`, `dentro_da_raiz_publica`, `caminho_invalido`, `espaco_insuficiente` e falha de teste. A leitura do diagnóstico não cria a pasta.

A exclusão das raízes públicas conhecidas não prova ausência de aliases configurados no Apache/Nginx/proxy. A verificação de alias da hospedagem permanece explicitamente pendente até conferência naquele ambiente. Não publique o diretório por alias. Use a ability de preparação após corrigir permissões/caminho.

## Cache

A rotina já usada para `cache.tokens` também pede por HTTP um artefato existente e elegível em `wp-content/cache/`: `index.html`, `index-https.html` e arquivos `wp-cache-<hash>.php` no diretório do site fornecido pelo WP Super Cache. Em modo com cabeçalhos preservados, os arquivos PHP têm preferência. Não executa PHP do cache, não segue redirecionamentos e não consulta corpos privados. A evidência fica em `artefato_cache`, junto da tentativa durável e do último sucesso.

Sucesso exige resposta completa de zero bytes com HTTP 200, 403, 404 ou 410. Corpo HTML de erro não atende esse aceite. Corpo igual ao hash do arquivo é exposição efetiva. Resposta 5xx, 429, redirecionamento, corpo truncado ou erro de rede deixa a prova pendente. Sem artefato elegível/WP Super Cache compatível não há prova de proteção; o diagnóstico permanece inconclusivo.

A sonda usa a cadência e a trava existentes. Leitura de saúde não faz uma nova requisição HTTP. Prova antiga sem o novo campo não certifica acesso direto. HIT por disco/cabeçalho continua uma prova separada da proteção do diretório.

## Métricas após load

A versão vendorizada conferida é Web Vitals 6.2.1, já minificada na 1.11.0 (11.093 bytes). O Core remove o enqueue antecipado e carrega a biblioteca assincronamente após `window.load`, respeitando a permissão de medição. Se o tracking for iniciado depois do load, agenda o carregamento imediatamente para a próxima tarefa.

Um observador mínimo guarda interações curtas antes da biblioteca ficar pronta; um patch local faz a transferência sem duplicar entradas do buffer nativo. O relógio do primeiro ocultamento é preservado e coletores iniciados numa página já oculta escoam entradas pendentes. A correção local de máximo de CLS entre janelas permanece. Inicialização duplicada é evitada.

A retenção antecipada é limitada a 2.000 entradas. Em excesso, INP não é relatado como valor parcial; a condição fica em `window.f3baseVitaisAntecipados.overflow`. Falha de rede marca `erro`. Navegação encerrada antes do load/carga da biblioteca pode não produzir métricas: não há como prometer coleta completa depois que o documento deixa de executar. Não são fabricados zeros. bfcache e cobertura em navegadores reais precisam do aceite específico descrito em VALIDACAO.md. Não se alega melhora na nota PageSpeed sem ensaio comparável.

## Retorno e recuperação

Mantenha backup pré-atualização do banco, opções, plugin e arquivos privados. A política 1.13.0 tem formato diferente da 1.12.0. Voltar apenas o código não desfaz essa transformação: restaure o estado correspondente ao código de retorno. Restaurar banco antigo perde registros posteriores: exporte/dê destino a esses registros antes de uma restauração.

Não remova manualmente marcadores para repetir migração. Não use reinstalação para eliminar acervo. A rotina de desinstalação continua preservando registros, arquivos e o histórico de atendimento. A opção “apagar por padrão” não foi implementada.
