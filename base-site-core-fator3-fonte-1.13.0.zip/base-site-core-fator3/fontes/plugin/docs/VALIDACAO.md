# Validação — 1.13.0

Bancada isolada: WordPress 7.1, PHP 8.3.6 e integração SQLite. Dados sintéticos e transporte de e-mail interceptado; nenhum envio externo ou alteração da frota.

Executados: instalação nova; transformação da base 1.12.0 com lista vazia, restrita e explícita completa; preservação do interruptor desligado; repetição; origem anterior/indefinida bloqueada sem escrita; conflito após interrupção; política com simulação, revisão e modos; capabilities e execução real de abilities; rollback após falha de histórico.

Coleta/relatórios: aceites nativos e cliques, métodos, sessão/navegação, idempotência e conflito, recusa de campos livres, consentimento negado, vitais fora de ordem, cobertura, denominadores únicos, campanhas, formulário/revisão, perfil sem campos pessoais, filtros, jornada, comparação, retenção/remoção da nova coleta. HTTP local verifica assets, ordem de dependências e endpoint real.

JavaScript em VM: instância nova sobre HTML em cache, contexto no envio, correlação estável, fila de outra sessão protegida contra resposta atrasada, revogação/reconsentimento, vital final. Suite da biblioteca vendorizada: carga após load, buffer de interações, primeiro ocultamento e CLS local.

Cache: arquivos PHP e HTML; resposta vazia; artefato exposto; 403 com corpo; redirecionamento; ausência; travessia e PHP arbitrário recusados. HTTP dessa sonda foi simulado com `pre_http_request`; os 13 sites não foram acessados.

Os fontes incluem scripts e evidências em `suite/versao-1130/`. Não foram concluídos teste visual em Chromium (instalação indisponível no ambiente), MySQL/MariaDB, bfcache em navegadores reais, SMTP externo nem adaptador MCP da frota. Valide esses pontos em homologação antes da distribuição geral. Não há promessa de nota PageSpeed, entrega de e-mail, conversão de vendas ou cobertura retroativa.
