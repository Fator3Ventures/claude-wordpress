# Relatórios integrados — 1.13.0

Abra **Contatos → Relatórios**. Administradores podem filtrar período, página, formulário e método, comparar com o período anterior e exportar CSV. O detalhe de um contato contém **Jornada observada antes deste contato**. A mesma consulta é acessível por abilities.

| Relatório | Pergunta e medida |
|---|---|
| Conversão por página | Sessões observadas, cliques, envios aceitos e sessões com cada ação; taxa por sessão. |
| Métodos de contato | Volumes separados por método, captura suspeita e classificação spam. |
| Origem e campanhas | Sessões por UTM/referência, cliques e envios pareados ao carregamento e taxa; modelo de atribuição da sessão observada. |
| Funil de formulários | Instâncias vistas, iniciadas, com tentativa, com erro, com aceite e sem aceite observado após 30 minutos. Separação por revisão. |
| Conteúdo e conversão | Sessões expostas à seção e com envio posterior observado; tempo ativo estimado quando habilitado. Associação não demonstra causa. |
| Qualidade técnica | Percentil 75 de LCP, CLS, INP e TTFB por página/dispositivo, separando amostras com e sem envio observado. Erros/fricção também aparecem por página. |
| Operação de contatos | Novos/respondidos, idade do mais antigo, avisos/respostas pendentes ou falhos e tempo até primeira marcação manual de resposta. |
| Materiais protegidos | Concessões emitidas, usadas/sem uso e tentativas autorizadas por material/versão. Não mede conclusão do download. |
| Perfil da demanda | Contagem de respostas a campos select/radio/checkbox sem papel de identidade, por formulário/revisão. Sem respostas livres nos agregados. |

## Como os dados se relacionam

`f3base_leads` é a verdade do aceite. A sessão relaciona o contato a `f3base_eventos` e à nova tabela `f3base_analise`. `navegacao` distingue carregamentos/abas; `correlacao` relaciona a instância do formulário ao aceite. O histórico de atendimento relaciona-se por `record_id` e revisão. Materiais usam a concessão ligada ao lead.

As contagens comerciais não somam clique e formulário como se fossem o mesmo resultado: cliques indicam intenção; envios aceitos indicam recebimento. Suspeitos, spam e métodos sem classificação comprovada ficam separados. Lixeira e eliminação pendente ficam fora. Vários envios numa sessão aumentam o volume de envios, mas contam uma sessão convertida.

A taxa por página exige página vista na mesma sessão antes do recebimento. Eventos de página das duas fontes são deduplicados por sessão/página. Registros sem pareamento continuam no volume; cobertura mostra elegíveis, com sessão, com eventos, com página vista, sem sessão, campanhas pareadas e snapshots estruturados disponíveis. Não deduza pessoas por IP ou e-mail.

Filtros de formulário/método restringem contatos; as sessões da página permanecem o denominador de tráfego. Campanhas exigem pareamento exato de navegação/sessão e evento anterior. A atribuição da sessão é mantida no sessionStorage daquela aba; abas podem observar origens diferentes. Não é atribuição multitoque nem receita.

## Coleta adicional

O navegador guarda eventos locais de visualização/início/tentativa/erro de formulário, sem nome, e-mail, telefone, conteúdo digitado ou anexos. Identifica formulário/revisão, instância, sessão, carregamento, dispositivo por largura e horário. Referência externa é reduzida ao host; UTMs ficam limitadas. Atribuição não coleta a query inteira. Páginas são normalizadas sem query/fragmento; páginas por `?p=`/`?page_id=` usam permalink ou `/@post-ID`.

Cada carregamento recebe ID próprio. Instâncias de formulário são renovadas no navegador, mesmo com HTML em cache; reenvios preservam a chave e eventos repetidos não aumentam a contagem. A coleta respeita o módulo de comportamento, a permissão de medição e a disponibilidade da identidade local. Revogação limpa fila e origem locais; o servidor também verifica a permissão. Formulários continuam funcionando sem medição.

Web Vitals conserva a última sequência válida de cada amostra vinculada ao carregamento, inclusive atualizações ao ocultar a página. A biblioteca continua sendo carregada após load com o tratamento de entradas antecipadas já existente. Ausência de métrica não vira zero. CLS não tem unidade; LCP/INP/TTFB são em milissegundos.

Novos envios guardam snapshot dos campos de opções fechadas. Para registros da base, o relatório só usa a definição atual quando a revisão coincide. Mudança posterior de rótulos/opções não reinterpreta snapshots novos.

## Períodos, retenção e limites

Datas seguem o fuso do WordPress; fim é exclusivo no começo do dia seguinte. Intervalo de 1–90 dias; comparação usa intervalo anterior de igual duração. O dia em andamento é identificado. A retenção detalhada usa `f3base_comportamento.retencao_eventos_dias` (30 dias no padrão). A coleta adicional não recompõe sessões/campanhas antigas. A rotina de retenção remove os eventos novos vencidos; esquecimento de visitante e eliminação do lead também alcançam seus novos vínculos. O histórico de atendimento acompanha o ciclo do registro.

Leitura limitada a 3.000 registros e 30.000 eventos por fonte no período. Ao exceder, retorna `reduza_periodo`, sem calcular taxa sobre amostra truncada. O limite é conferido antes dos filtros em memória: reduza o período mesmo se a página filtrada tem pouco movimento. UI/ability paginam até 200 linhas; CSV usa uma consulta completa do conjunto limitado, com neutralização de fórmulas.

Abandono significa início sem aceite dentro do período e ao menos 30 minutos sem evento observado. Inícios recentes ficam abertos. Uma conversão posterior ao intervalo não altera retroativamente esse recorte. Jornada mostra até 500 eventos mais recentes anteriores ao recebimento; múltiplas abas e relógio do cliente impedem afirmar uma sequência causal.

Tempos de atendimento são observados somente após esta release. Aviso/resposta processados significam aceite pelo transporte de e-mail. Sem entrega ao CRM, status de venda ou gasto de mídia, o plugin não informa receita, ROI, custo por lead ou venda atribuída.
