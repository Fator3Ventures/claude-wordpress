# Configuração — 1.13.0

## Onde operar

O menu **F3 Base** contém Configurações, Informações técnicas e a aba Operação. Contatos e Formulários permanecem nas respectivas telas do plugin. A aba Operação contém a política de opções e as operações já oferecidas pelo Core.

A configuração salva por seção usa revisão esperada. Uma escrita concorrente deve ser relida e reaplicada conscientemente; não substitua a revisão pelo valor novo sem conferir as alterações.

## Controles

Entrega do índice e Modo de consentimento usam seletores com os valores do catálogo. Os valores aceitos também são declarados pelo contrato de configuração. Não envie rótulos traduzidos no lugar das chaves.

Blocos de interface excluídos da conversão usam caixas de seleção dos blocos registrados. A busca apenas filtra a exibição e não desmarca valores. Um bloco salvo que esteja temporariamente indisponível continua listado e marcado. É possível acrescentar um identificador `namespace/bloco` registrado apenas na página pública. Desmarcar todos grava lista vazia.

## Contato

| Grupo | Ajuste | Efeito |
|---|---|---|
| Registro e avisos | Quem recebe os avisos internos | Até cinco e-mails da equipe. A lista específica do formulário prevalece quando declarada. |
| Registro e avisos | Enviar aviso interno de clique | Controla o aviso, inclusive de clique sem nome/e-mail; não desliga o registro. |
| Registro e avisos | Enviar aviso interno de formulário recebido | Avisa após persistir um envio aceito; falha de e-mail não perde o registro. |
| WhatsApp | Flutuante, número e mensagem | Configura o destino do WhatsApp e seu botão flutuante. Links próprios dos CTAs são respeitados. |
| Instrumentação | Classes adicionais de botões de contato | Uma classe CSS por linha, sem ponto; instrumenta o clique sem mudar seu destino. |

As chaves existentes continuam `email_leads`, `avisar_por_clique`, `avisar_por_formulario` e `classes_cta`, dentro de `f3base_contato`. As notificações internas continuam limitadas e com resumo de pendências. O estado do aviso é independente da captura e da resposta ao visitante.


## Permissões e gestão por agentes

Em F3 Base → Operação, **Configurações editáveis** oferece Todas, Somente as selecionadas e Nenhuma. A seleção é substituída integralmente ao salvar: desmarcar revoga edição, sem alterar o valor configurado. Desmarcar todos em uma seleção salva Nenhuma. O administrador mantém acesso à própria gestão para reabrir permissões.

Use **Conferir seleção** para visualizar acréscimos e remoções sem gravar. **Salvar permissões** aplica a revisão exibida. Uma edição concorrente mantém o rascunho e exibe conflito; confira o estado salvo antes de tentar novamente.

O segundo formulário contém **Permitir que agentes alterem estas permissões** e **Salvar alteração**. É uma caixa de seleção persistente e reversível, com estado salvo e aviso de alteração não salva. Desligá-la impede a edição remota da política; a lista atual continua valendo para edições de configuração. Não é um interruptor geral de REST/MCP.

Os formulários têm nonces e revisões independentes. Funcionam sem JavaScript. Em site novo, a gestão vem ativa e o modo é Todas. Atualizações não reativam escolhas desligadas: lista vazia da 1.12.0 vira Todas uma única vez; lista explícita vira Somente as selecionadas e não ganha itens automaticamente.
