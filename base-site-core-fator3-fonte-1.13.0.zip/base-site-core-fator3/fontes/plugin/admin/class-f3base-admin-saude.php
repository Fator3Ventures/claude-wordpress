<?php
/** Painel de operação: leituras explícitas separadas das ações administrativas. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }

final class F3Base_Admin_Saude {
	public const ACAO = 'f3base_operar';
	public static function iniciar(): void {
		add_action( 'admin_post_' . self::ACAO, array( __CLASS__, 'operar' ) ); }

	public static function operar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) ); }
		check_admin_referer( self::ACAO );
		$acao = sanitize_key( is_string( $_POST['operacao'] ?? null ) ? wp_unslash( $_POST['operacao'] ) : '' );
		$r    = array(
			'ok'     => false,
			'codigo' => 'operacao_nao_permitida',
		);
		if ( in_array( $acao, array( 'schema', 'llms_arquivo' ), true ) ) {
			$revisao = sanitize_text_field( wp_unslash( $_POST['revisao_esperada'] ?? '' ) );
			$r       = 'schema' === $acao ? F3Base_Schema_Verificacao::executar(
				array(
					'acao'             => 'verificar_publico',
					'revisao_esperada' => $revisao,
				)
			) : F3Base_Llms_Arquivo::executar(
				array(
					'acao'             => 'regenerar',
					'revisao_esperada' => $revisao,
				)
			);
		} elseif ( 'pendentes' === $acao ) {
			$r = F3Base_Operacao::executar_pendentes(); } elseif ( in_array( $acao, array( 'acessos', 'capi', 'robots' ), true ) ) {
			$r = F3Base_Operacao::executar_uma( $acao, 'administracao', false ); } elseif ( 'publicacao' === $acao ) {
						$caminho = is_string( $_POST['caminho'] ?? null ) ? wp_unslash( $_POST['caminho'] ) : '/llms.txt';
						$r       = F3Base_Publicacao_Sonda::verificar(
							array(
								'caminho' => $caminho,
								'metodo'  => 'GET',
							)
						);
			} elseif ( 'previa' === $acao ) {
				$tipo = sanitize_key( is_string( $_POST['tipo'] ?? null ) ? wp_unslash( $_POST['tipo'] ) : '' );
				if ( in_array( $tipo, array( 'llms', 'full', 'robots', 'markdown' ), true ) ) {
					$post_id = isset( $_POST['post_id'] ) && is_scalar( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
					$r       = F3Base_Publicacao_Sonda::previa( $tipo, $post_id );
				}
			}
			if ( is_wp_error( $r ) ) {
				$r = array(
					'ok'     => false,
					'codigo' => $r->get_error_code(),
					'motivo' => $r->get_error_message(),
				); }
			// Evidência administrativa limitada e temporária; sem copiar corpos de leads ou segredos.
			if ( isset( $r['texto'] ) && strlen( $r['texto'] ) > 24000 ) {
				$r['texto']           = mb_strcut( $r['texto'], 0, 24000, 'UTF-8' );
				$r['previa_truncada'] = true; }
			if ( strlen( (string) wp_json_encode( $r ) ) > 65536 ) {
				$r = array(
					'ok'     => false,
					'codigo' => 'resultado_extenso',
					'motivo' => 'A resposta excede a prévia da tela. Consulte a operação pelo contrato com paginação.',
				); }
			set_transient( 'f3base_operacao_resultado_' . get_current_user_id(), $r, 5 * MINUTE_IN_SECONDS );
			wp_safe_redirect(
				add_query_arg(
					array(
						'page' => F3Base_Admin_Tela::SLUG,
						'aba'  => 'tecnica',
					),
					admin_url( 'admin.php' )
				)
			);
		exit;
	}

	private static function abrir_formulario( string $operacao ): void {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="f3base-operacao-form">';
		echo '<input type="hidden" name="action" value="' . esc_attr( self::ACAO ) . '"><input type="hidden" name="operacao" value="' . esc_attr( $operacao ) . '"><input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( self::ACAO ) ) . '">';
	}

	public static function render( ?array $resumo = null ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return; }
		$r      = $resumo ?? F3Base_Saude::resumo();
		$ultima = get_transient( 'f3base_operacao_resultado_' . get_current_user_id() );
		if ( is_array( $ultima ) ) {
			delete_transient( 'f3base_operacao_resultado_' . get_current_user_id() );
			echo '<div class="notice notice-' . ( ! empty( $ultima['ok'] ) ? 'success' : 'warning' ) . '"><p>' . esc_html( (string) ( $ultima['motivo'] ?? $ultima['codigo'] ?? 'Operação concluída. Confira a evidência.' ) ) . '</p><details><summary>Resultado da operação</summary><pre>' . esc_html( (string) wp_json_encode( $ultima, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details></div>';
		}
		echo '<section class="f3base-bloco f3base-saude"><h2>Estado operacional</h2><p>Configuração salva, efeito aplicado e resposta pública verificada são etapas independentes. Os dados abaixo mostram o estado existente e a data da última execução.</p><div class="f3base-saude-grade">';
		$alvos = array( 'acessos-servidor', 'comportamento', 'meta-capi', 'consentimento', 'llms-txt-reserva', 'robots-txt', 'cache-publico' );
		foreach ( $r['modulos'] as $m ) {
			if ( ! in_array( $m['id'], $alvos, true ) ) {
				continue; }
			echo '<article class="f3base-saude-card"><h3>' . esc_html( $m['nome'] ) . '</h3><span class="f3base-estado f3base-estado--' . esc_attr( $m['estado'] ) . '">' . esc_html( ucfirst( $m['estado'] ) ) . '</span><p>' . esc_html( $m['motivo'] ) . '</p></article>';
		}
		echo '</div><h3>Agenda e últimas execuções</h3><div class="f3base-tabela-rolagem" tabindex="0" aria-label="Agenda das tarefas"><table class="widefat striped"><thead><tr><th>Tarefa</th><th>Próxima execução</th><th>Última tentativa</th><th>Último sucesso</th><th>Saldo observado</th><th>Situação</th></tr></thead><tbody>';
		$situacoes = array(
			'inativa'         => 'Inativa',
			'sem_agendamento' => 'Sem agendamento',
			'atrasada'        => 'Execução atrasada',
			'agendada'        => 'Agendada',
			'concluido'       => 'Concluída',
			'pendente'        => 'Pendente',
			'parcial'         => 'Parcial',
			'falha'           => 'Falhou',
			'em_execucao'     => 'Em execução',
		);
		foreach ( $r['agenda'] as $a ) {
			$u          = $a['ultima_execucao'];
			$fim        = (int) ( ! empty( $u['fim'] ) ? $u['fim'] : ( $u['inicio'] ?? 0 ) );
			$sucesso    = (int) ( $a['ultimo_sucesso']['fim'] ?? 0 );
			$saldo      = $a['saldo'] ?? array();
			$pendencias = ! empty( $saldo['conhecido'] ) ? (string) $saldo['quantidade'] . ' na última observação' : 'Ainda não medido';
			if ( ! empty( $saldo['observado_em'] ) ) {
				$pendencias .= ' (' . wp_date( 'd/m/Y H:i:s', (int) $saldo['observado_em'] ) . ')';
			}
			echo '<tr><th scope="row">' . esc_html( $a['rotulo'] ) . '</th><td>' . esc_html( $a['proxima_execucao'] ? wp_date( 'd/m/Y H:i:s', $a['proxima_execucao'] ) : 'Sem agendamento' ) . '</td><td>' . esc_html( $fim ? wp_date( 'd/m/Y H:i:s', $fim ) . ' — ' . ( $situacoes[ $u['status'] ?? '' ] ?? 'Consultar resultado' ) : 'Sem registro nesta versão' ) . '</td><td>' . esc_html( $sucesso ? wp_date( 'd/m/Y H:i:s', $sucesso ) : 'Ainda não confirmado' ) . '</td><td>' . esc_html( $pendencias ) . '</td><td>' . esc_html( $a['reservada'] ? 'Em execução' : ( $situacoes[ $a['codigo'] ] ?? 'Consultar resultado' ) ) . '</td></tr>';
		}
		echo '</tbody></table></div><p class="description">Saldo de acessos representa arquivos na última inspeção; na fila, inclui eventos que aguardam reconciliação. Sem observação não significa saldo zero. Agendar não confirma a execução. Sites com cache ou pouco tráfego dependem da frequência do executor configurado na hospedagem.</p>';
		self::abrir_formulario( 'pendentes' );
		echo '<button class="button">Executar tarefas vencidas</button></form></section>';
		echo '<section class="f3base-bloco"><h2>Inspeção dos arquivos públicos</h2><p>Verificar publicação consulta a resposta e registra a evidência. Reconciliar robots pode atualizar o arquivo gerenciado e é uma ação separada.</p><div class="f3base-acoes-publicacao">';
		self::abrir_formulario( 'publicacao' );
		echo '<label>Arquivo <select name="caminho"><option value="/robots.txt">robots.txt</option><option value="/llms.txt">llms.txt</option><option value="/llms-full.txt">llms-full.txt</option></select></label> <button class="button button-primary">Verificar publicação</button></form>';
		self::abrir_formulario( 'previa' );
		echo '<label>Prévia <select name="tipo"><option value="llms">llms.txt</option><option value="full">llms-full.txt</option><option value="robots">robots.txt</option><option value="markdown">Página em Markdown</option></select></label> <label>ID do conteúdo (opcional, obrigatório para Markdown) <input type="number" name="post_id" min="1" step="1" class="small-text"></label> <button class="button">Gerar prévia e explicar seleção</button></form>';
		self::abrir_formulario( 'robots' );
		echo '<button class="button">Reconciliar robots gerenciado</button></form></div>';
		echo '<details><summary>Responsáveis e evidências de publicação</summary><pre>' . esc_html( (string) wp_json_encode( F3Base_Publicacao_Sonda::resumo(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) . '</pre></details></section>';
		echo '<section class="f3base-bloco"><h2>Schema e arquivo llms</h2>';
		foreach ( array(
			'schema'       => array( 'f3base_seo_entidade', 'Verificar schema publicado', F3Base_Schema_Verificacao::consultar() ),
			'llms_arquivo' => array( 'f3base_llms', 'Regenerar llms e verificar publicação', F3Base_Llms_Arquivo::consultar() ),
		) as $acao => $item ) {
			self::abrir_formulario( $acao );
			echo '<input type="hidden" name="revisao_esperada" value="' . esc_attr( F3Base_Options::revisao( $item[0] ) ) . '"><button class="button">' . esc_html( $item[1] ) . '</button></form><pre>' . esc_html( wp_json_encode( $item[2], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		}
		echo '<h3>Auditoria de configuração</h3><pre>' . esc_html( wp_json_encode( $r['auditoria_configuracao'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre>';
		echo '<p><a href="' . esc_url( add_query_arg( array( 'f3base_perfil' => wp_create_nonce( 'f3base_perfil' ) ), home_url( '/' ) ) ) . '">Medir a página inicial nesta sessão administrativa</a></p><pre>' . esc_html( wp_json_encode( get_transient( 'f3base_perfil_' . get_current_user_id() ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ) . '</pre></section>';
	}
}
