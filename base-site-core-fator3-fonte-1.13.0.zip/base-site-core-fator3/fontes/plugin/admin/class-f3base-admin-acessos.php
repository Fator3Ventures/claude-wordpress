<?php
/** Medição administrativa: filtros, fotografia temporária e histórico independente. */
declare( strict_types = 1 );
if ( ! defined( 'ABSPATH' ) ) {
	exit; }
final class F3Base_Admin_Acessos {
	public const TETO_PAGINAS   = 300;
	public const PERIODOS       = array( 1, 2, 3, 4, 5, 6, 7, 15, 30, 60, 90 );
	public const CLASSIFICACOES = array(
		'conteudo'     => 'Páginas, artigos e descoberta',
		'paginas'      => 'Somente páginas e artigos',
		'descoberta'   => 'Arquivos de descoberta',
		'inexistentes' => 'Caminhos inexistentes (404/410)',
		'feeds'        => 'Feeds',
		'apis'         => 'APIs',
		'outros'       => 'Outros caminhos',
	);
	public static function registrar(): void {
		add_action( 'wp_ajax_f3base_acessos_atualizar', array( __CLASS__, 'atualizar' ) );
		add_action( 'admin_post_f3base_acessos_atualizar', array( __CLASS__, 'atualizar' ) );
		add_action( 'admin_post_f3base_acessos_csv', array( __CLASS__, 'csv' ) );
		add_action( 'admin_post_f3base_comportamento_csv', array( 'F3Base_Admin_Medicao', 'csv_agregado' ) );
	}
	private static function filtros( array $e ): array {
		$dias   = is_scalar( $e['dias'] ?? null ) && in_array( (int) $e['dias'], self::PERIODOS, true ) ? (int) $e['dias'] : 90;
		$classe = is_string( $e['classificacao'] ?? null ) && isset( self::CLASSIFICACOES[ $e['classificacao'] ] ) ? $e['classificacao'] : 'conteudo';
		$todos  = '1' === (string) ( $e['mostrar_todos'] ?? '' );
		$modo   = $todos ? 'todos' : $classe;
		return array(
			'dias'            => $dias,
			'classificacao'   => $classe,
			'mostrar_todos'   => $todos ? '1' : '0',
			'incluir_erros'   => 'inexistentes' === $modo || '1' === (string) ( $e['incluir_erros'] ?? '' ) ? '1' : '0',
			'modo'            => $modo,
			'comparacao_hoje' => '1' === ( $e['comparacao_hoje'] ?? '' ) ? '1' : '0',
		);
	}
	public static function abas(): void {
		$ativa = isset( $_GET['aba'] ) && 'acessos' === $_GET['aba']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filtros de visualização somente leitura, validados antes da consulta; não executam coleta.
		echo '<nav class="nav-tab-wrapper f3base-abas" aria-label="Medição">';
		foreach ( array(
			'comportamento' => 'Comportamento',
			'acessos'       => 'Acessos',
		) as $slug => $nome ) {
			$url   = add_query_arg(
				array(
					'page' => F3Base_Admin_Medicao::SLUG,
					'aba'  => $slug,
				),
				admin_url( 'admin.php' )
			);
			$atual = ( 'acessos' === $slug ) === $ativa;
			printf( '<a class="nav-tab%s" href="%s"%s>%s</a>', $atual ? ' nav-tab-active' : '', esc_url( $url ), $atual ? ' aria-current="page"' : '', esc_html( $nome ) ); }
		echo '</nav>';
	}
	private static function guarda( string $acao ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) );
		} check_admin_referer( $acao ); }
	public static function somar(): void {
		self::guarda( 'f3base_acessos_somar' );
		$r = F3Base_Modulo_Acessos_Servidor::solicitar();
		wp_safe_redirect(
			add_query_arg(
				array_merge(
					self::filtros( $_POST ), // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Ação administrativa chama guarda() com check_admin_referer antes de ler este POST.
					array(
						'page'   => F3Base_Admin_Medicao::SLUG,
						'aba'    => 'acessos',
						'coleta' => empty( $r['agendado'] ) ? 'falha' : 'agendada',
					)
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
	public static function atualizar(): void {
		self::guarda( 'f3base_acessos_atualizar' );
		$f         = self::filtros( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Ação administrativa chama guarda() com check_admin_referer antes de ler este POST.
		$intervalo = (int) ( $_POST['intervalo'] ?? 30 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Ação administrativa chama guarda() com check_admin_referer antes de ler este POST.
		if ( ! in_array( $intervalo, array( 15, 30, 60 ), true ) ) {
			$intervalo = 30; }
		if ( isset( $_POST['preferencia'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Ação administrativa chama guarda() com check_admin_referer antes de ler este POST.
			update_user_meta(
				get_current_user_id(),
				'f3base_acessos_visualizacao',
				array(
					'automatico' => '1' === ( $_POST['automatico'] ?? '' ), // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Ação administrativa chama guarda() com check_admin_referer antes de ler este POST.
					'intervalo'  => $intervalo,
				)
			); }
		if ( isset( $_POST['somente_preferencia'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Ação administrativa chama guarda() com check_admin_referer antes de ler este POST.
			wp_send_json_success( array( 'salvo' => true ) ); }
		$hoje = F3Base_Acessos_Atuais::ler();
		$r    = F3Base_Acessos_Relatorio::consultar( $f['dias'], $f['modo'], '1' === $f['incluir_erros'], $hoje, '1' === $f['comparacao_hoje'] );
		if ( wp_doing_ajax() ) {
			ob_start();
			self::resultado( $r );
			$html = ob_get_clean();
			wp_send_json_success(
				array(
					'html'       => $html,
					'filtros'    => $f,
					'atualizado' => $hoje['atualizado'],
					'erro'       => $hoje['erro'],
				)
			); }
		wp_safe_redirect(
			add_query_arg(
				array_merge(
					$f,
					array(
						'page' => F3Base_Admin_Medicao::SLUG,
						'aba'  => 'acessos',
					)
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
	public static function render(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return; }
		$f    = self::filtros( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filtros de visualização somente leitura, validados antes da consulta; não executam coleta.
		$pref = get_user_meta( get_current_user_id(), 'f3base_acessos_visualizacao', true );
		$pref = is_array( $pref ) ? $pref : array(
			'automatico' => false,
			'intervalo'  => 30,
		);
		$r    = F3Base_Acessos_Relatorio::consultar( $f['dias'], $f['modo'], '1' === $f['incluir_erros'], F3Base_Acessos_Atuais::fotografia(), '1' === $f['comparacao_hoje'] );
		wp_enqueue_script( 'f3base-medicao-acessos', plugins_url( 'assets/js/medicao-acessos.js', F3BASE_PLUGIN_DIR . 'base-site-core-fator3.php' ), array(), F3BASE_PLUGIN_VERSAO, true );
		echo '<h2>Acessos por caminho</h2><p class="f3base-intro">Requisições registradas nos logs do servidor. Hoje usa uma fotografia temporária; o histórico contém apenas dias fechados.</p>';
		if ( isset( $_GET['coleta'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filtros de visualização somente leitura, validados antes da consulta; não executam coleta.
			echo '<div class="notice notice-info inline"><p>' . ( 'agendada' === $_GET['coleta'] ? 'Coleta solicitada. Acompanhe o progresso e a última conclusão abaixo.' : 'Não foi possível agendar a coleta. Verifique se ela está ligada e o estado técnico.' ) . '</p></div>'; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Filtros de visualização somente leitura, validados antes da consulta; não executam coleta.
		echo '<section class="f3base-bloco"><h2>Filtrar e acompanhar</h2><form id="f3base-acessos-filtros" class="f3base-filtros" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-ajax="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '"><input type="hidden" name="action" value="f3base_acessos_atualizar">';
		wp_nonce_field( 'f3base_acessos_atualizar' );
		echo '<label>Período <select name="dias">';
		foreach ( self::PERIODOS as $n ) {
			printf( '<option value="%d" %s>%s</option>', (int) $n, selected( $f['dias'], $n, false ), 1 === $n ? 'Hoje' : esc_html( 'Últimos ' . $n . ' dias' ) );
		} echo '</select></label> <label>Classificação <select name="classificacao">';
		foreach ( self::CLASSIFICACOES as $k => $v ) {
			printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $f['classificacao'], $k, false ), esc_html( $v ) );
		} echo '</select></label> ';
		printf( '<label><input name="mostrar_todos" type="checkbox" value="1" %s> Mostrar todos</label> <label><input name="incluir_erros" type="checkbox" value="1" %s> Incluir 4xx/5xx</label> ', checked( '1', $f['mostrar_todos'], false ), checked( '1', $f['incluir_erros'], false ) );
		printf( '<label><input name="comparacao_hoje" type="checkbox" value="1" %s> Incluir hoje na comparação (parcial)</label> ', checked( '1', $f['comparacao_hoje'], false ) );
		submit_button( 'Atualizar', 'primary', '', false );
		printf( '<p><label><input id="f3base-acessos-auto" name="automatico" type="checkbox" value="1" %s> Atualizar automaticamente</label> <label>Intervalo <select id="f3base-acessos-intervalo" name="intervalo">', checked( ! empty( $pref['automatico'] ), true, false ) );
		foreach ( array( 15, 30, 60 ) as $n ) {
			printf( '<option value="%d" %s>%d segundos</option>', (int) $n, selected( $pref['intervalo'] ?? 30, $n, false ), (int) $n ); }
		echo '</select></label> <span id="f3base-acessos-status" role="status" aria-live="polite">Atualização automática desligada</span></p></form><p class="description">Mostrar todos inclui as demais rotas. Inexistentes considera exclusivamente respostas 404/410. Atualização automática pausa quando a aba fica oculta.</p></section>';
		echo '<section class="f3base-bloco"><h2>Histórico de logs</h2><form id="f3base-acessos-coleta" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="f3base_acessos_somar">';
		wp_nonce_field( 'f3base_acessos_somar' );
		self::ocultos( $f );
		submit_button( 'Coletar e Armazenar Logs', 'secondary', '', false );
		echo '</form>';
		$a = F3Base_Modulo_Acessos_Servidor::agenda();
		printf( '<p>Próxima coleta: %s. Última conclusão: %s. Arquivos pendentes: %d.</p>', esc_html( $a['proxima'] ? wp_date( 'd/m/Y H:i:s', $a['proxima'] ) : 'não agendada' ), esc_html( $a['ultima_conclusao'] ? wp_date( 'd/m/Y H:i:s', $a['ultima_conclusao'] ) : 'nenhuma' ), (int) $a['pendentes'] );
		if ( $a['erro'] ) {
			echo '<p class="notice notice-warning">' . esc_html( $a['erro'] ) . '</p>';
		} echo '<p class="description">Coleta diária às 09:00 UTC, acionada pelo WP-Cron. O botão solicita o mesmo trabalho reservado. Apenas arquivos datados fechados são importados; eventos de hoje aguardam revisita.</p></section>';
		echo '<div id="f3base-acessos-resultado">';
		self::resultado( $r );
		echo '</div>';
		echo '<form id="f3base-acessos-csv" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="f3base_acessos_csv">';
		wp_nonce_field( 'f3base_acessos_csv' );
		self::ocultos( $f );
		submit_button( 'Exportar CSV', 'secondary', '', false );
		echo ' <button type="submit" class="button button-secondary" name="tipo" value="comparacao">Exportar comparação CSV</button>';
		echo '</form>';
	}
	private static function ocultos( array $f ): void {
		foreach ( array( 'dias', 'classificacao', 'mostrar_todos', 'incluir_erros', 'comparacao_hoje' ) as $k ) {
			printf( '<input type="hidden" name="%s" value="%s">', esc_attr( $k ), esc_attr( (string) $f[ $k ] ) ); } }
	private static function resultado( array $r ): void {
		echo '<section class="f3base-bloco"><h2>Cobertura dos dados</h2>';
		printf( '<p>%s a %s · %s · Extraído em %s.</p>', esc_html( $r['inicio'] ), esc_html( $r['fim'] ), esc_html( $r['fuso'] ), esc_html( wp_date( 'd/m/Y H:i:s', $r['extraido_em'] ) ) );
		$hoje = $r['hoje'];
		echo '<p>' . esc_html( ! empty( $hoje['erro'] ) ? $hoje['erro'] : 'Hoje: parcial. Fotografia atualizada em ' . wp_date( 'H:i:s', $hoje['atualizado'] ) . '; ' . (int) ( $hoje['bytes_pendentes'] ?? 0 ) . ' bytes aguardando leitura.' ) . '</p>';
		echo '<details><summary>Cobertura por dia</summary><div class="f3base-tabela-rolagem" role="region" tabindex="0" aria-label="Cobertura por dia"><table class="widefat striped"><thead><tr><th>Dia</th><th>Estado</th><th>Motivo</th></tr></thead><tbody>';
		foreach ( $r['cobertura'] as $c ) {
			printf( '<tr><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html( $c['dia'] ), esc_html( $c['estado'] ), esc_html( $c['motivo'] ) );
		} echo '</tbody></table></div></details></section>';
		echo '<div class="f3base-tabela-rolagem" tabindex="0" role="region" aria-label="Acessos por caminho"><table class="widefat striped"><thead><tr><th>Caminho</th><th>Classificação</th><th>Pessoas medidas</th><th>Total</th><th>Humanos estimados</th><th>Busca</th><th>Treino IA</th><th>Resposta IA</th><th>Próprio</th><th>Hospedagem</th><th>Outros robôs</th></tr></thead><tbody>';
		foreach ( $r['linhas'] as $l ) {
			printf( '<tr><td><code>%s</code></td><td>%s</td>', esc_html( $l['caminho'] ? $l['caminho'] : '(sem detalhe)' ), esc_html( self::CLASSIFICACOES[ $l['classificacao'] ] ?? $l['classificacao'] ) );
			echo '<td>' . esc_html( isset( $l['pessoas_medidas'] ) ? (string) $l['pessoas_medidas'] : '—' ) . '</td>';
			foreach ( array( 'total', 'humano', 'busca', 'treino-ia', 'resposta-ia', 'proprio', 'hospedagem', 'outros' ) as $k ) {
				echo '<td>' . esc_html( number_format_i18n( $l[ $k ] ) ) . '</td>';
			} echo '</tr>'; }
		if ( ! $r['linhas'] ) {
			echo '<tr><td colspan="11">Nenhum dado disponível com os filtros aplicados.</td></tr>';
		} echo '</tbody></table></div>';
		printf( '<p>%d caminhos exibidos. %s</p>', count( $r['linhas'] ), $r['corte'] ? 'Resultado limitado; CSV identifica o mesmo corte. Reduza o período para detalhar.' : 'Todos os caminhos observados neste recorte foram considerados.' );
		echo '<p class="description">User-Agent é uma declaração falsificável. As classes próprio e hospedagem indicam correspondência com regras declaradas. Requisições não equivalem a pessoas. Hoje cobre somente o arquivo ativo; rotação pode retirar parte da janela.</p>';
		$c = $r['comparacao'];
		printf( '<section class="f3base-bloco"><h2>Comparação de períodos</h2><p>%s a %s versus %s a %s. %d pares de dias com cobertura e calendário compatíveis; %d pares excluídos. %s</p>', esc_html( $c['inicio'] ), esc_html( $c['fim'] ), esc_html( $c['anterior_inicio'] ), esc_html( $c['anterior_fim'] ), (int) $c['dias_comparados'], count( $c['pares_excluidos'] ), $c['hoje_incluido'] ? 'Hoje está incluído: período parcial, apenas o arquivo ativo, comparado com dias anteriores completos.' : 'Hoje fica fora.' );
		echo '<div class="f3base-tabela-rolagem" role="region" tabindex="0" aria-label="Comparação de períodos"><table class="widefat striped"><thead><tr><th>Caminho</th><th>Atual</th><th>Anterior</th><th>Diferença</th><th>Variação</th></tr></thead><tbody>';
		foreach ( $c['linhas'] as $l ) {
			printf( '<tr><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td>%s</td></tr>', esc_html( $l['caminho'] ), (int) $l['atual'], (int) $l['anterior'], (int) $l['diferenca'], esc_html( null === $l['variacao'] ? 'base zero' : $l['variacao'] . '%' ) );
		} if ( ! $c['linhas'] ) {
			echo '<tr><td colspan="5">Comparação indisponível: cobertura incompatível, ausência de dados ou limite de consulta.</td></tr>';
		} echo '</tbody></table></div></section>';
	}
	public static function csv(): void {
		self::guarda( 'f3base_acessos_csv' );
		$tipo = $_POST['tipo'] ?? 'agregados'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guarda() valida capacidade e nonce antes desta leitura.
		if ( ! is_string( $tipo ) || ! in_array( $tipo, array( 'agregados', 'comparacao' ), true ) ) {
			wp_die( 'Tipo de exportação inválido.', '', array( 'response' => 400 ) ); }
		$f          = self::filtros( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- guarda() valida capacidade e nonce antes desta leitura.
		$r          = F3Base_Acessos_Relatorio::consultar( $f['dias'], $f['modo'], '1' === $f['incluir_erros'], F3Base_Acessos_Atuais::fotografia(), '1' === $f['comparacao_hoje'] );
		$c          = $r['comparacao'];
		$comparacao = 'comparacao' === $tipo;
		$janela     = $comparacao ? $c : $r;
		$meta       = array(
			'escopo'        => $comparacao ? 'comparacao_periodos' : 'agregados_filtrados',
			'tipo_linha'    => 'dado',
			'inicio'        => $janela['inicio'],
			'fim'           => $janela['fim'],
			'fuso'          => $r['fuso'],
			'regra'         => $r['regra'],
			'extraido_em'   => gmdate( DATE_ATOM, $r['extraido_em'] ),
			'filtro'        => $r['classificacao'],
			'incluir_erros' => $r['incluir_erros'] ? '1' : '0',
			'limite'        => F3Base_Acessos_Relatorio::MAX_LINHAS,
			'corte'         => $janela['corte'] ? '1' : '0',
			'cobertura'     => wp_json_encode( $r['cobertura'] ),
		);
		if ( $comparacao ) {
			$meta['cobertura'] = wp_json_encode( F3Base_Acessos_Coleta::cobertura( $c['inicio'], $c['fim'] ) );
			$meta             += array(
				'anterior_inicio'    => $c['anterior_inicio'],
				'anterior_fim'       => $c['anterior_fim'],
				'hoje_incluido'      => $c['hoje_incluido'] ? '1' : '0',
				'hoje_comparado'     => $c['hoje_comparado'] ? '1' : '0',
				'periodo_parcial'    => $c['periodo_parcial'] ? '1' : '0',
				'dias_comparados'    => $c['dias_comparados'],
				'pares_excluidos'    => wp_json_encode( $c['pares_excluidos'] ),
				'cobertura_anterior' => wp_json_encode( F3Base_Acessos_Coleta::cobertura( $c['anterior_inicio'], $c['anterior_fim'] ) ),
			);
			$campos            = array( 'caminho', 'atual', 'anterior', 'diferenca', 'variacao', 'base_zero' );
			$linhas            = $c['linhas'];
		} else {
			$campos = array( 'caminho', 'classificacao', 'total', 'humano', 'busca', 'treino_ia', 'resposta_ia', 'proprio', 'hospedagem', 'outros' );
			$linhas = $r['linhas'];
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="f3base-acessos' . ( $comparacao ? '-comparacao' : '' ) . '.csv"' );
		$fp = fopen( 'php://output', 'wb' );
		fputcsv( $fp, array_merge( array_keys( $meta ), $campos ), ',', '"', '' );
		foreach ( $linhas ? $linhas : array( array() ) as $l ) {
			$row               = $meta;
			$row['tipo_linha'] = $l ? 'dado' : 'metadados';
			foreach ( $campos as $campo ) {
				$chave         = in_array( $campo, array( 'treino_ia', 'resposta_ia' ), true ) ? str_replace( '_', '-', $campo ) : $campo;
				$row[ $campo ] = 'base_zero' === $campo && array_key_exists( $chave, $l ) ? ( $l[ $chave ] ? '1' : '0' ) : ( $l[ $chave ] ?? '' ); }
			fputcsv( $fp, array_map( array( 'F3Base_Acessos_Relatorio', 'celula_csv' ), $row ), ',', '"', '' );
		}
		fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Saída CSV por streaming, sem arquivo persistido.
		exit;
	}
}
