/* GPL-2.0-or-later. Filtro local; não altera escolhas. */
document.addEventListener('input',function(e){var id=e.target.getAttribute('data-f3base-buscar-blocos');if(!id)return;var root=document.getElementById(id),q=e.target.value.toLowerCase();if(root)root.querySelectorAll('[data-f3base-bloco]').forEach(function(n){n.style.display=n.textContent.toLowerCase().indexOf(q)<0?'none':'block';});});
