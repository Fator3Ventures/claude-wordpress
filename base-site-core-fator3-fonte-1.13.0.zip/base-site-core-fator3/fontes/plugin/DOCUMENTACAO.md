# Base Site Core Fator3 — documentação instalada 1.13.0

Referência operacional distribuída dentro do plugin instalado em `wp-content/plugins/base-site-core-fator3/`. Plugin 1.13.0; contrato de configuração 2.0.0; estrutura de leads 2.

| Documento | Uso |
|---|---|
| INSTRUCOES-DO-PLUGIN.md | Ponto de entrada para agentes |
| README.md | Instalação e recursos |
| CONTRACTS.md | Entradas, permissões e unidades |
| docs/CONFIGURACAO.md | Configuração e gestão por agentes |
| docs/LEADS-E-FORMULARIOS.md | Captura, formulários, anexos e resposta opcional |
| docs/RELATORIOS.md | Relatórios, coleta adicional, cobertura e interpretação |
| docs/OPERACAO-E-RECUPERACAO.md | Atualização, pasta privada, cache e recuperação |
| docs/REFERENCIA-CATALOGO.md | Catálogo gerado do runtime |
| docs/VALIDACAO.md | Ensaios executados e limites |
| CHANGELOG.md | Histórico de alterações |

Um agente pode ler os arquivos locais ou usar `f3base/documentacao-ler`: sem argumentos obtém o índice; com `arquivo`, `linha` e `limite` lê até 200 linhas e recebe SHA-256 e próxima linha. Requer `manage_options` e não devolve opções nem segredos. `f3base/como-usar` aponta para este índice.

Há dois fluxos: instalação sem estado anterior ou atualização de uma instalação 1.12.0 concluída. A repetição da 1.13.0 é idempotente. Estado antigo ou sem origem confiável é bloqueado, nunca reinterpretado como instalação nova. Os importadores e reparadores históricos não integram este runtime. Registros já incorporados ao Core são preservados.
