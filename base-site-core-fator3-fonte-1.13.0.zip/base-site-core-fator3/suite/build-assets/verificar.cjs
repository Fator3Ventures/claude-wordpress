/* Testes do build: reconstrução limpa e rejeição de arquivo ausente, antigo ou corrompido. */
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const origem=path.resolve(process.argv[2]||'fontes/plugin');
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'f3base-assets-'));
const gerar=(check=false)=>cp.spawnSync(process.execPath,[path.join(__dirname,'build.cjs'),tmp,...(check?['--check']:[])],{encoding:'utf8'});
const ler=()=>fs.readFileSync(path.join(tmp,'assets/manifesto-assets.json'),'utf8');
try {
 fs.cpSync(origem,tmp,{recursive:true});
 assert.equal(gerar().status,0); const manifesto=ler();
 assert.equal(gerar().status,0); assert.equal(ler(),manifesto); assert.equal(gerar(true).status,0);
 const f=path.join(tmp,'assets/f3base-leads.min.js');fs.unlinkSync(f);assert.notEqual(gerar(true).status,0,'Ausência não bloqueou.');
 assert.equal(gerar().status,0);fs.appendFileSync(path.join(tmp,'assets/f3base-leads.js'),'\nwindow.fixtureBuild=1;\n');assert.notEqual(gerar(true).status,0,'Fonte modificada não bloqueou.');
 assert.equal(gerar().status,0);fs.appendFileSync(f,'\nwindow.fixtureCorrompido=1;\n');assert.notEqual(gerar(true).status,0,'Minificado corrompido não bloqueou.');
 const vendor='assets/vendor/web-vitals.js';assert.equal(fs.readFileSync(path.join(tmp,vendor),'utf8'),fs.readFileSync(path.join(origem,vendor),'utf8'),'Vendor alterado.');
 console.log(JSON.stringify({ok:true,reconstrucao_identica:true,ausencia_recusada:true,fonte_antigo_recusado:true,corrupcao_recusada:true,vendor_preservado:true,manifesto_sha256:crypto.createHash('sha256').update(manifesto).digest('hex')}));
}finally{fs.rmSync(tmp,{recursive:true,force:true});}
