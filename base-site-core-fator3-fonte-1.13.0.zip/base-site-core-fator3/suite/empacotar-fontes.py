#!/usr/bin/env python3
"""Current release sources only. Explicit inclusion, hashes and deterministic ZIP."""
from pathlib import Path,PurePosixPath
import json,hashlib,zipfile,argparse
root=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser();parser.add_argument('--saida',required=True);args=parser.parse_args()
spec=json.loads((root/'suite/fontes-inclusao.json').read_text());paths=sorted(spec['arquivos']+['suite/fontes-inclusao.json']);assert len(paths)==len(set(paths));data={}
for name in paths:
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
 f=root/name;assert f.is_file() and not f.is_symlink();data[name]=f.read_bytes()
manifest={'versao':'1.13.0','arquivos':[{'caminho':k,'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in data.items()]}
data['dist/fontes-manifesto.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode();out=Path(args.saida).resolve();out.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(data.items()):
  info=zipfile.ZipInfo('base-site-core-fator3/'+n,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,b)
print(json.dumps({'arquivo':str(out),'arquivos':len(data),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
