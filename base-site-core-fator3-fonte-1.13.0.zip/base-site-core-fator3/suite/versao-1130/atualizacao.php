<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);require $site.'/wp-load.php';wp_set_current_user(1);global $wpdb;
$checks=[];function ck($n,$v){global $checks;$checks[$n]=(bool)$v;if(!$v)fwrite(STDERR,"FAIL $n\n");}
$state=get_option('f3base_release_1130');$base=get_option('f3base_release_1120');$policy=get_option('f3base_operaveis');
$signature=static fn()=>hash('sha256',wp_json_encode($wpdb->get_results("SELECT option_name,option_value FROM {$wpdb->options} WHERE option_name LIKE 'f3base_%' ORDER BY option_name",ARRAY_A)));
foreach([['versao'=>'1.11.0','concluido_em'=>1],[],['versao'=>'1.12.0','concluido_em'=>0]] as $i=>$bad){delete_option('f3base_release_1130');update_option('f3base_release_1120',$bad);$before=$signature();$r=F3Base_Instalacao::atualizar();ck('origem_bloqueada_'.$i,!$r['ok']&&$r['codigo']==='origem_nao_suportada'&&$signature()===$before);}
update_option('f3base_release_1120',$base);
$none=['schema'=>1,'modo'=>'nenhuma','lista'=>[]];update_option('f3base_operaveis',$none);
$partial=$state;unset($partial['concluido_em'],$partial['politica_confirmada']);update_option('f3base_release_1130',$partial);$r=F3Base_Instalacao::atualizar();ck('interrupcao_preserva_alteracao_posterior',!$r['ok']&&$r['codigo']==='conflito_politica'&&get_option('f3base_operaveis')===$none);
update_option('f3base_release_1130',$state);$r=F3Base_Instalacao::atualizar();ck('concluida_nao_reabre_nenhuma',$r['ok']&&get_option('f3base_operaveis')===$none);update_option('f3base_operaveis',$policy);
// A failed history insert must roll back the manual status change.
$d=F3Base_Leads_Repositorio::guardar(['metodo'=>'formulario','captura'=>'aceito','atendimento'=>'novo']);$lead=F3Base_Leads_Repositorio::obter($d['record_id']);$table=$wpdb->prefix.F3Base_Analise::HISTORICO;$failure=static fn($sql)=>str_starts_with($sql,'INSERT INTO')&&str_contains($sql,F3Base_Analise::HISTORICO)?'INSERT INTO f3base_fixture_missing (id) VALUES (1)':$sql;add_filter('query',$failure,999);$old=$wpdb->suppress_errors(true);
try{$r=F3Base_Leads_Repositorio::atualizar(['record_id'=>$lead['record_id'],'revisao_esperada'=>(int)$lead['revisao'],'alteracoes'=>['atendimento'=>'respondido'],'simular'=>false]);$after=F3Base_Leads_Repositorio::obter($lead['record_id']);ck('falha_historico_rollback',!$r['ok']&&$after['atendimento']==='novo'&&$after['revisao']===$lead['revisao']);}finally{remove_filter('query',$failure,999);$wpdb->suppress_errors($old);}
echo wp_json_encode(['checks'=>$checks,'failures'=>array_keys(array_filter($checks,static fn($v)=>!$v))],JSON_PRETTY_PRINT)."\n";exit(in_array(false,$checks,true)?1:0);
