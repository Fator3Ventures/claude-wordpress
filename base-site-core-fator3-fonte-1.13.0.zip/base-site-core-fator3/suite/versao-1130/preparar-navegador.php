<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110'))exit(2);require $site.'/wp-load.php';wp_set_current_user(1);
update_option('home','http://127.0.0.1:8130');update_option('siteurl','http://127.0.0.1:8130');update_option('permalink_structure','');
F3Base_Options::gravar('f3base_ga4_measurement_id','');F3Base_Options::gravar('f3base_gtm_id','');$wpdb->query('DELETE FROM '.F3Base_Leads_Repositorio::tabela('leads_janelas'));
$id=wp_insert_post(['post_type'=>'page','post_status'=>'publish','post_title'=>'Validação integrada 1.13.0','post_content'=>'<!-- wp:paragraph --><p>Formulário sintético de validação.</p><!-- /wp:paragraph --><!-- wp:f3base/formulario {"id":"analise1130"} /-->']);
wp_set_password('bancada1130-local',1);echo wp_json_encode(['url'=>get_permalink($id),'admin'=>get_userdata(1)->user_login]);
