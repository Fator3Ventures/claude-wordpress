<?php
$site=getenv('F3BASE_SITE');if(!$site||!is_file($site.'/.f3base-bancada-110')){http_response_code(503);exit;}
$uri=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)?:'/';if(str_contains($uri,'..')){http_response_code(403);exit;}
if(is_file($site.$uri)){return false;}
require $site.'/index.php';
