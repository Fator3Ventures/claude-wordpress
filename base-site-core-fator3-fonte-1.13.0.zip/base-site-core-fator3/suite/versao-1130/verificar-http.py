"""Local HTTP checks; localhost fixture only, e-mail transport intercepted by mu-plugin."""
import json,sys,re,uuid,time,urllib.request,urllib.parse,os,subprocess,atexit
from pathlib import Path
cfg=json.loads(Path(sys.argv[1]).read_text());url=cfg['url'];assert url.startswith('http://127.0.0.1:8130/')
checks={}
def ck(n,v):
 checks[n]=bool(v)
 if not v:raise AssertionError(n)
def req(url,p=None):
 d=None if p is None else json.dumps(p).encode();r=urllib.request.urlopen(urllib.request.Request(url,data=d,headers={} if p is None else {'Content-Type':'application/json'}));return r.read().decode()
srv=subprocess.Popen([os.environ.get('F3BASE_PHP','php'),'-S','127.0.0.1:8130','-t',os.environ['F3BASE_SITE'],str(Path(__file__).with_name('router.php'))],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
atexit.register(srv.terminate)
for attempt in range(50):
 try:html=req(url);break
 except OSError:time.sleep(.1)
else:raise RuntimeError('Servidor local indisponível')
ck('script_analise_enfileirado','f3base-analise.min.js' in html);ck('script_formulario_enfileirado','f3base-formularios.min.js' in html)
# Actual script order/dependencies and shipped source endpoint.
ck('ordem_tracking_analise',html.index('f3base-tracking.min.js')<html.index('f3base-analise.min.js'));ck('formulario_revisionado','data-revisao=' in html)
cfgjs=json.loads(re.search(r'var f3baseAnaliseDados = (\{[^\n]+\});',html).group(1));ck('canonical_com_identidade_pagina',cfgjs['caminho'].startswith('/@post-'))
session=uuid.uuid4().hex;nav=uuid.uuid4().hex;event={'evento':uuid.uuid4().hex,'sessao':session,'visitante':uuid.uuid4().hex,'navegacao':nav,'tipo':'pagina','caminho':cfgjs['caminho'],'dispositivo':'desktop','criado_em':int(time.time()),'atribuicao':{'modelo':'sessao','utm_source':'http'}}
r=json.loads(req(cfgjs['endpoint'],{'token':cfgjs['token'],'medicao':True,'eventos':[event]}));ck('endpoint_http_real',r['ok']);r=json.loads(req(cfgjs['endpoint'],{'token':cfgjs['token'],'medicao':True,'eventos':[event]}));ck('reenvio_http_real',r['ok'])
script=req('http://127.0.0.1:8130/wp-content/plugins/base-site-core-fator3/assets/f3base-analise.min.js');ck('asset_minificado_entregue',len(script)>1000)
Path(__file__).with_name('evidencias').joinpath('http.json').write_text(json.dumps({'checks':checks},indent=2));print(json.dumps({'ok':True,'checks':checks}))
