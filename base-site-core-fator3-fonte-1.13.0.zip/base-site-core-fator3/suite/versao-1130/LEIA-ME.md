# Validação e build da 1.13.0

Execute somente em WordPress isolado e descartável com `.f3base-bancada-110` na raiz. Os testes limpam tabelas sintéticas, alteram configurações e usam dados reservados `example.test`. Nunca aponte F3BASE_SITE para produção. PHP 8.1+; bancada utilizada 8.3.6/WordPress 7.1 com SQLite.

1. Instale o plugin da pasta `fontes/plugin` numa instalação vazia; registre `f3base_release_1130`, política Todas, gestão ativa e diagnóstico privado pronto. O arquivo `evidencias/instalacao.json` contém a execução local desta entrega.
2. Intercepte e-mail: um mu-plugin de bancada deve retornar true no filtro `pre_wp_mail`. Impeça HTTP externo. Isso não testa entrega SMTP.
3. Execute `F3BASE_SITE=/caminho/wp php suite/versao-1130/regressao.php` e `atualizacao.php`. Eles exercitam contratos, migração de estado da base 1.12.0 e falhas de persistência. Configure explicitamente o servidor como fixture, sem dado pessoal real.
4. Execute `node suite/versao-1130/analise.cjs` e `vitais.cjs`.
5. `preparar-navegador.php` cria uma página sintética e define uma senha SOMENTE da bancada. Guarde seu JSON. `verificar-http.py` inicia servidor local temporário; recebe esse JSON e exige F3BASE_SITE e F3BASE_PHP. `navegador.cjs` é um ensaio Playwright preparado, mas não executado nesta entrega por falta do Chromium.
6. `documentar-catalogo.php` gera referência apenas das declarações, sem valores do site. Execute em bancada para produzir docs/REFERENCIA-CATALOGO.md.
7. `node suite/build-assets/build.cjs fontes/plugin` minifica usando Terser fixado no lock. `--check` confere sem alterar. Instala a dependência de build em cache local quando necessário; Node não vai para WordPress.
8. `python3 suite/versao-1130/empacotar.py /pasta/saida` gera instalador e manifesto. `python3 suite/empacotar-fontes.py --saida /pasta/fontes.zip` gera os fontes desta release com inclusão explícita e hashes. Com as mesmas entradas, os ZIPs são reproduzíveis.

Pontos não homologados: MySQL/MariaDB, navegador visual/bfcache real, SMTP externo, WAF/proxy e adaptador MCP dos 13 sites. As sondas do WP Super Cache foram testadas com arquivos sintéticos e HTTP simulado, mantendo a exigência de corpo vazio. Referência de implementação do provedor: https://github.com/Automattic/wp-super-cache/blob/trunk/wp-cache-phase2.php (consulta em 24/09/2026; leitura de arquivo, nome PHP por hash e diretório da home).
