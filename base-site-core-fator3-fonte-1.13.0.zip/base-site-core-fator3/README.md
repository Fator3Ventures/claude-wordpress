# Fontes — Base Site Core Fator3 1.13.0

`fontes/plugin` contém exatamente o runtime e a documentação do instalador. `suite/versao-1130` contém testes e evidências desta entrega; `suite/build-assets` contém o build reproduzível dos seis scripts.

Leia `fontes/plugin/DOCUMENTACAO.md` e `suite/versao-1130/LEIA-ME.md`. A base mínima é 1.12.0. Não instalar este ZIP no WordPress: gere/use `base-site-core-fator3-1.13.0.zip`.

Os fontes desta versão não incluem árvores de compatibilidade ou suítes históricas. Registros já armazenados na base suportada permanecem preservados.
