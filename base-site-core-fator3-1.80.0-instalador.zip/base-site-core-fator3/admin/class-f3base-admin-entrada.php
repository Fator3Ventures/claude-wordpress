<?php
/** Transporte HTML com referência do servidor, delta e pré-validação. */
declare(strict_types=1);
if (!defined('ABSPATH')) { exit; }
final class F3Base_Admin_Entrada {
    /**
     * Option estruturada (grupo) que esta tela não sabe editar: sem subcampos e sem renderização própria.
     * É a única regra que decide isso; o formulário a mostra somente leitura e o contexto não a aceita.
     */
    public static function sem_editor(string $nome, array $d): bool {
        return ($d['campo']??'')==='grupo'&&empty($d['subcampos'])&&$nome!=='f3base_navegacao';
    }
    public static function contexto(string $area, array $campos, array $fotos): string {
        $id=wp_generate_uuid4(); $base=array(); $revisoes=array();
        foreach($campos as $n=>$d){
            if(self::sem_editor((string)$n,$d)){continue;}
            $base[$n]=self::html($d,F3Base_Options::e_segredo($n)?'':$fotos[$n]['valor']);
            $revisoes[$n]=$fotos[$n]['revisao'];
        }
        $uid=get_current_user_id();$index=get_transient('f3base_forms_'.$uid)?:array();$index=array_filter($index,static fn($at)=>$at>time()-2*HOUR_IN_SECONDS);while(count($index)>=10){$old=array_key_first($index);delete_transient('f3base_form_'.$old);unset($index[$old]);}$index[$id]=time();set_transient('f3base_forms_'.$uid,$index,2*HOUR_IN_SECONDS);
        set_transient('f3base_form_'.$id,array('usuario'=>$uid,'area'=>$area,'base'=>$base,'revisoes'=>$revisoes,'expira'=>time()+2*HOUR_IN_SECONDS,'limite'=>time()+2*HOUR_IN_SECONDS),2*HOUR_IN_SECONDS);
        return $id;
    }
    public static function renovar(): void {
        if(!current_user_can('manage_options')){wp_send_json_error(array('mensagem'=>'Sem permissão.'),403);}check_ajax_referer('f3base-form-renovar','nonce');
        $id=sanitize_text_field(wp_unslash($_POST['contexto']??''));$ctx=preg_match('/^[a-f0-9-]{36}$/D',$id)?get_transient('f3base_form_'.$id):false;
        if(!is_array($ctx)||$ctx['usuario']!==get_current_user_id()||($ctx['limite']??0)<time()){wp_send_json_error(array('mensagem'=>'O contexto expirou. Reabra a página e redigite a credencial.'),409);}
        // A gravação compara a revisão das opções efetivamente editadas, sob o controle do dono.
        $ctx['expira']=min(time()+2*HOUR_IN_SECONDS,$ctx['limite']);set_transient('f3base_form_'.$id,$ctx,max(1,$ctx['limite']-time()));wp_send_json_success(array('expira'=>$ctx['expira']));
    }
    public static function html(array $d,$v) {
        $t=$d['tipo']??$d['campo']??'texto';
        if($t==='grupo'){$r=array();foreach($d['subcampos']??array() as $k=>$child){$r[$k]=self::html($child,is_array($v)?($v[$k]??''):'');}return $r;}
        if($t==='campanhas'){return array_merge((array)$v,array(array('plataforma'=>'','conta'=>'','campanha'=>'','nome'=>'')));}
        if($t==='segredo'){return '';}
        if($t==='booleano'){return $v?'1':'0';}
        if($t==='json'){return wp_json_encode(!empty($d['objeto'])?(object)$v:$v,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE);}
        if($t==='emails'){return array_pad((array)$v,5,'');}
        if($t==='linhas'){return implode("\n",(array)$v);}
        if($t==='lista'){return implode(', ',(array)$v);}
        if($t==='multiescolha'){return array_merge(array(''),array_map('strval',(array)$v));}
        if($t==='blocos'){return array('selecionados'=>array_merge(array(''),(array)$v),'adicionais'=>'');}
        return is_scalar($v)?(string)$v:'';
    }
    /** Somente o adaptador HTML aceita representações textuais de números/booleanos. */
    public static function converter(array $d,$v,string $path='') {
        $t=$d['tipo']??$d['campo']??'texto';
        if($t==='grupo'){
            if(!is_array($v)){throw new InvalidArgumentException($path.'|Informe os campos do grupo.');}
            $r=array();foreach($v as $k=>$x){if(!isset($d['subcampos'][$k])){throw new InvalidArgumentException($path.'.'.$k.'|Campo não declarado.');}$r[$k]=self::converter($d['subcampos'][$k],$x,$path.'.'.$k);}return $r;
        }
        if($t==='campanhas'){if(!is_array($v)){throw new InvalidArgumentException($path.'|Informe as linhas de campanha.');}$out=array();foreach($v as $r){if(!is_array($r)||array_diff(array_keys($r),array('plataforma','conta','campanha','nome'))||array_filter($r,static fn($x)=>!is_string($x))){throw new InvalidArgumentException($path.'|Linha de campanha inválida.');}$r=array_map('trim',$r);if(array_filter($r,static fn($x)=>$x!=='')){$out[]=$r;}}return $out;}
        if($t==='inteiro'){
            if(is_int($v)){return $v;}
            if(!is_string($v)||!preg_match('/^-?(?:0|[1-9][0-9]*)$/D',trim($v))||filter_var(trim($v),FILTER_VALIDATE_INT)===false){throw new InvalidArgumentException($path.'|Informe um número inteiro válido.');}
            return (int)trim($v);
        }
        if($t==='booleano'){if(in_array($v,array(true,false,'0','1'),true)){return $v===true||$v==='1';}throw new InvalidArgumentException($path.'|Use ligado ou desligado.');}
        if($t==='blocos'){
            if(!is_array($v)||array_diff(array_keys($v),array('selecionados','adicionais'))||!is_array($v['selecionados']??null)||!is_string($v['adicionais']??null)){throw new InvalidArgumentException($path.'|Lista de blocos inválida.');}
            $v=array_merge($v['selecionados'],preg_split('/[\r\n,]+/',$v['adicionais']));
        }
        if(in_array($t,array('lista','linhas','emails','multiescolha','blocos'),true)){
            if(is_string($v)){$v=preg_split($t==='lista'?'/[\r\n,]+/':'/\r?\n/',$v);}
            if(!is_array($v)||array_filter($v,static fn($x)=>!is_string($x))){throw new InvalidArgumentException($path.'|Informe uma lista de textos.');}
            $v=array_values(array_unique(array_filter(array_map('trim',$v),static fn($x)=>$x!=='')));
            if($t==='multiescolha'){$op=isset($d['opcoes_callback'])?call_user_func($d['opcoes_callback']):($d['opcoes']??array());if(array_diff($v,array_map('strval',array_keys($op)))){throw new InvalidArgumentException($path.'|Selecione somente alternativas disponíveis.');}}
            if(in_array($t,array('multiescolha','blocos'),true)){sort($v,SORT_STRING);}return $v;
        }
        if(!is_string($v)){throw new InvalidArgumentException($path.'|Informe um texto.');}
        if($t==='json'){
            if (!empty($d['objeto']) && !str_starts_with(ltrim($v), '{')) {
                throw new InvalidArgumentException($path.'|Informe um objeto JSON com os IDs dos formulários. Use {} para limpar as exceções.');
            }
            try{$json=json_decode($v,true,32,JSON_THROW_ON_ERROR);}catch(JsonException $e){throw new InvalidArgumentException($path.'|JSON inválido. Confira aspas, vírgulas e a estrutura.');}
            if(!is_array($json)&&!($path==='f3base_seo_entidade.organizacao_mae'&&is_string($json))){throw new InvalidArgumentException($path.'|Informe um objeto ou lista JSON.');}return $json;
        }
        return $t==='segredo'?trim($v):($t==='textarea'?str_replace(array("\r\n","\r"),"\n",$v):$v);
    }
    private static function completa(array $d,$v,$base): bool {
        if(($d['tipo']??$d['campo']??'')==='grupo'){
            if(!is_array($v)||array_diff(array_keys((array)$base),array_keys($v))||array_diff(array_keys($v),array_keys((array)$base))){return false;}
            foreach($d['subcampos']??array() as $k=>$child){if(!self::completa($child,$v[$k],$base[$k])){return false;}}
        }
        return true;
    }
    private static function erro(string $n,string $code,string $motivo,string $path=''): array {
        return array('nome'=>$n,'rotulo'=>F3Base_Options::declaracao($n)['rotulo']??'Formulário','codigo'=>$code,'caminho'=>$path?:$n,'motivo'=>$motivo,'ok'=>false,'persisted'=>false,'alteraria'=>false,'effect'=>array('status'=>'not_attempted'),'verification'=>array('status'=>'not_attempted'));
    }
    public static function processar(array $enviado,array $revisoes,array $apagar,string $id,string $area,string $fim): array {
        if(!current_user_can('manage_options')){return array(self::erro('','sem_permissao','Sem permissão.'));}
        $ctx=preg_match('/^[a-f0-9-]{36}$/D',$id)?get_transient('f3base_form_'.$id):false;
        if(!is_array($ctx)||$ctx['usuario']!==get_current_user_id()||($ctx['expira']??0)<time()||$ctx['area']!==$area||!hash_equals($id,$fim)){return array(self::erro('','contexto_invalido','Formulário expirado ou incompleto. Reabra a área, confira os valores e redigite a credencial; segredos não são recuperados.'));}
        $individual = $area === 'medicao-meta';
        $nomes = array_keys($enviado);
        $permitidos = array_keys($ctx['base']);
        if (array_diff($nomes, $permitidos) || array_diff($apagar, $nomes) || (!$individual && array_diff($permitidos, $nomes))) {
            return array(self::erro('', 'escopo_invalido', 'Campos ausentes ou de outra área. Reabra a configuração.'));
        }
        if ($individual) {
            // Each option is validated against values already committed by previous options.
            // Within an option the complete group and its revision remain one unit of work.
            $saida = array();
            foreach (array_unique(array_merge(F3Base_Interface::AREAS[$area], $nomes)) as $nome) {
                if (!array_key_exists($nome, $enviado)) { continue; }
                $valor = $enviado[$nome];
                array_push($saida, ...self::aplicar(array($nome => $valor), $revisoes, $apagar, $ctx));
            }
        } else {
            $saida = self::aplicar($enviado, $revisoes, $apagar, $ctx);
        }
        if ($individual || !array_filter($saida, static fn($campo) => empty($campo['persisted']))) {
            delete_transient('f3base_form_'.$id);
        }
        return $saida;
    }
    private static function aplicar(array $enviado, array $revisoes, array $apagar, array $ctx): array {
        $pendentes=array();$erros=array();$proposta=array();
        foreach($enviado as $n=>$raw){
            $d=F3Base_Options::declaracao($n);$base=$ctx['base'][$n];$secret=F3Base_Options::e_segredo($n);$delete=in_array($n,$apagar,true);
            if(!$d||!F3Base_Options::operavel($n)||!self::completa($d,$raw,$base)||($delete&&!$secret)){$erros[]=self::erro($n,'entrada_incompleta','Campo incompleto ou fora do escopo. Reabra a configuração.');continue;}
            if(!$delete&&($secret&&$raw===''||F3Base_Options::equivalente($raw,$base))){continue;}
            try{
                $v=$delete?'':self::converter($d,$raw,$n);$delta=null;
                $inicial=self::converter($d,$base,$n);
                if(!$delete&&F3Base_Options::equivalente($v,$inicial)){continue;}
                $foto=F3Base_Options::fotografia_bruta($n);
                if($foto['erro']||!hash_equals($ctx['revisoes'][$n],$foto['revisao'])||($revisoes[$n]??'')!==$ctx['revisoes'][$n]){$erros[]=self::erro($n,'conflito','A configuração mudou. Confira o valor atual e reaplique sua edição.');continue;}
                if(($d['campo']??'')==='grupo'){
                    $delta=self::delta($v,$inicial,$d);$mescla=F3Base_Config_Mescla::preparar($d,$foto['existe']?$foto['valor']:F3Base_Options::ler($n),$delta);
                    if(empty($mescla['ok'])){$erros[]=self::erro($n,'mescla_invalida','Campos incompatíveis com o contrato.');continue;}$v=$mescla['valor'];
                }
                $pendentes[$n]=array('valor'=>$v,'delta'=>$delta);$proposta[$n]=F3Base_Options::sanitizar($n,$v);
            }catch(InvalidArgumentException $e){$parts=explode('|',$e->getMessage(),2);$erros[]=self::erro($n,'tipo_invalido',$parts[1]??'Formato inválido.',$parts[0]);}
        }
        F3Base_Options::com_proposta($proposta,static function()use($pendentes,&$erros){
            foreach($pendentes as $n=>$p){$d=F3Base_Options::declaracao($n);$v=$p['valor'];$avaliado=$p['delta']===null?$v:F3Base_Config_Mescla::escopo($n,$v,$p['delta'],$d);
                $e=F3Base_Config_Mescla::erros_schema($avaliado,F3Base_Config_Contrato::schema_entrada($d),'',true);
                if($e){foreach($e as $x){$erros[]=self::erro($n,'tipo_invalido',$x['motivo'],$n.($x['caminho']!==''?'.'.$x['caminho']:''));}continue;}
                $motivo=F3Base_Options::recusar($n,$avaliado,$d);if($motivo!==''){$erros[]=self::erro($n,'valor_recusado',$motivo);}
            }
        });
        if($erros){return $erros;}
        $saida=F3Base_Options::com_proposta($proposta,static function()use($pendentes,$ctx){$out=array();foreach($pendentes as $n=>$p){$r=F3Base_Options::pelo_canal('admin',static fn()=>F3Base_Options::gravar($n,$p['valor'],F3Base_Options::ORIGEM_MANUAL,$ctx['revisoes'][$n],$p['delta']));unset($r['lido']);$out[]=array_merge($r,array('nome'=>$n,'rotulo'=>F3Base_Options::declaracao($n)['rotulo'],'caminho'=>$n));if(empty($r['persisted'])){break;}}return $out;});
        return $saida;
    }
    private static function delta(array $v,array $base,array $d): array {
        $out=array();foreach($v as $k=>$x){if(F3Base_Options::equivalente($x,$base[$k]??null)){continue;}$child=$d['subcampos'][$k]??array();$out[$k]=($child['tipo']??'')==='grupo'&&is_array($x)&&is_array($base[$k]??null)?self::delta($x,$base[$k],$child):$x;}return $out;
    }
}
