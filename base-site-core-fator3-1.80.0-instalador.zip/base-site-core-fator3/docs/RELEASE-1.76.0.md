# Fator3 Site Core 1.76.0

Atualização direta da 1.75.1 ou instalação limpa. WordPress 7.1.4 e PHP 8.3 de 64 bits. Contrato administrativo 8.37.0.

## Pedido 383 · Testar CAPI

Em Site Core → Configurações, selecione o transporte Meta Ambos ou Servidor homologado, habilite os eventos desejados e configure dataset e token. Em Testes, selecione marcar para CAPI e informe o código da aba Eventos de teste do mesmo dataset. Abra /f3base-teste/ em uma janela privada e navegue até uma página pública. Para Lead, envie um formulário elegível e confira o modo de disparo do formulário. O teste marcado usa o servidor e suprime o Pixel direto. O navegador recebe apenas o indicador de habilitação do teste. O código fica no servidor.

Em f3base/meta-entregas-ler, consulte modo eventos e correlacione classe, event_id, estado e HTTP. A captura confirmada pelo endpoint é local. A fila registra entregue após uma resposta de sucesso com events_received positivo. Confira também a ocorrência no Gerenciador de Eventos do dataset correspondente. A amostra de homologação do modo Servidor considera apenas tráfego não marcado.

## Pedido 384 · Consentimento de PageView

A fila relê a referência da navegação imediatamente antes do envio. Em modo granular, a decisão deve estar vigente, com medição e publicidade permitidas. Em modo legado, o aceite explícito ou a política de publicidade pré-autorizada registrada na captura pode habilitar o despacho. Mudança da versão de consentimento invalida a captura. O controle do rodapé recusa novas capturas e comunica a revogação das pendências legadas identificáveis. O navegador retoma uma comunicação de revogação que ficou pendente em nova navegação.

O cookie próprio f3base_capi_ref relaciona as capturas legadas por até oito dias. Apenas o hash é gravado na fila. O marcador f3base_capi_revogar retém uma revogação pendente. Uma negativa confirmada antes do início do HTTP impede o envio. Uma entrega já iniciada exige reconciliação pelo recibo.

O executor reavalia PageView da 1.75.1 suspenso com consentimento_indisponivel quando ainda está dentro do prazo, sem tentativa de HTTP, com payload e mesmo dataset. As linhas antigas sem referência individual conservam apenas a prova da política da captura. O legado não registrava identificador que vinculasse essas linhas a uma revogação posterior de um visitante. Expirados e entregues conservam o desfecho.

## Pedido 385 · Prévia do retorno CRM

Para Google Ads e LinkedIn, configure uma ação exclusiva por etapa e um adaptador pronto para crm_stage em site-conversion-delivery/1.2.0. Use a prévia da etapa com um lead aceito. Formulários nativos Meta, Google e LinkedIn usam a origem persistida e a política de publicidade. Negativa explícita resulta em consentimento_nao_permite. Sob a política exigir_decisao, a falta de decisão resulta em decisao_ausente. Contatos do site também exigem publicidade permitida no retrato da captura.

A prévia pode avaliar um formulário nativo marcado como teste. Enfileiramento e despacho comercial continuam suprimidos para a marca de teste. O resultado elegível descreve o que o adaptador consegue preparar. Configuração, identidade, prazo e permissão continuam necessários.
