# Guia para agentes — Core 1.79.0

Este é o guia vigente. Os arquivos AGENTES de versões anteriores são histórico de cada release.

Toda operação abaixo exige uma conexão com permissão de administrador (`manage_options`). Leitura de documentação não chama fornecedor nem muda estado.

## 1. Descobrir

1. Liste as habilidades do prefixo `f3base/` pelo catálogo MCP. O schema efetivo de cada uma, com os campos que a camada MCP acrescenta, sai de `get-ability-info`.
2. Sem acesso ao catálogo, use `docs/REFERENCIA-ABILITIES.md`: todas as habilidades por domínio, com leitura ou escrita e parâmetros obrigatórios. Os schemas completos, como o Core os registra, estão em `docs/dados/abilities-*.json`.

## 2. Ler a documentação instalada

1. Chame `f3base/documentacao-ler` com `{}`. A resposta traz `versao`, `indice` e a lista `arquivos`. Só os caminhos dessa lista podem ser lidos; qualquer outro devolve `documento_nao_catalogado`.
2. Leia `docs/DOCUMENTACAO.md` (o índice) e depois `docs/RELEASE-1.79.0.md`.
3. Para ler um documento, passe `arquivo`, `linha` (a partir de 1) e `limite` (até 200 linhas por página; o padrão é 120). Repita com `linha` igual a `proxima_linha` até ela vir `null`. Confira que `sha256` e `versao` são os mesmos em todas as páginas: se mudarem, o plugin foi trocado no meio da leitura e a leitura recomeça.

## 3. Diagnosticar

1. `f3base/resumo-operacional-ler` com `{}`: versões dos pacotes, estado da atualização, filas, credenciais e avisos em até 4096 bytes. Cada bloco indica em `detalhe` a habilidade que aprofunda o assunto.
2. `f3base/saude-ler`: estado operacional dos módulos. `f3base/execucoes-ler`: histórico das tarefas, com filtro por `tarefa`.
3. `f3base/como-usar`: orientação por assunto e por módulo, com `contract_version`.
4. Diagnóstico e leitura de estado não fazem reparo. Uma operação com efeito diz o efeito no próprio nome ou na descrição.

## 4. Configurar

1. Leia o valor e a revisão com `f3base/config-core-ler` (`nome` da option).
2. Simule com `f3base/config-core-escrever`: `nome`, `valor` e `revisao_esperada`. `simular` vale `true` quando omitido, portanto nada é gravado.
3. Confira a simulação e repita com `simular: false`. Se a revisão mudou entre a leitura e a gravação, a resposta traz `ok: false` e `codigo: conflito`: leia de novo e refaça a partir do valor atual.
4. `mesclar: true` preserva as chaves que você não enviou. Sem ele, `valor` substitui a option inteira.
5. Valor fora do schema da option é recusado com `tipo_invalido` e nada é gravado.
6. Segredos nunca voltam em leitura. `f3base/credenciais-ler` informa identidade e estado de cada credencial, sem o valor.

Quem configura pelo painel usa Site Core → Configurações. `docs/GUIA-PAINEL.md` descreve a tela.

## 5. Verificar

1. Configuração gravada, efeito aplicado e resposta pública verificada são etapas separadas. Depois de gravar, use `f3base/config-core-verificar` (`acao: consultar`) para a option alterada.
2. Para efeitos públicos, confira a resposta HTTP como visitante. Opção gravada não prova o HTTP servido quando há cache.
3. Repetir uma operação confirmada não duplica o efeito. Resultado externo incerto pede reconciliação antes de nova tentativa; as habilidades de reconciliação estão em `docs/REFERENCIA-ABILITIES.md`.

## 6. Depois de atualizar para a 1.79.0

1. Confirme `versao: 1.79.0` em `f3base/documentacao-ler` e `atualizacao.estado: concluida` em `f3base/resumo-operacional-ler`.
2. A 1.79.0 não traz migração de dados nem configuração nova. Nenhum bloco de servidor precisa ser reaplicado por causa dela.
3. A tela de configuração mudou de layout. Os valores gravados são os mesmos da 1.78.0. Seis itens de estrutura própria aparecem só para leitura na tela e se alteram por habilidade: `f3base_campanhas_origem`, `f3base_contexto_sessao`, `f3base_canais_organicos`, `f3base_origens_ia` e `f3base_marcas_vigiadas` por `f3base/config-core-escrever`; `f3base_redirects` por `f3base/redirects-escrever`.
4. Coleta do site, Conteúdo e IA e SEO voltaram a gravar pela tela. Para conferir, abra cada área e use Salvar alterações sem mudar nada: a resposta esperada é "Nenhuma alteração para salvar."
5. Em site sem um dos pacotes acompanhantes (Google, Meta, LinkedIn), `f3base/resumo-operacional-ler`, `f3base/credenciais-resumo-ler` e `f3base/midia-prontidao-ler` continuam respondendo `pacote_ou_ability_ausente` para o pacote que falta e deixam de registrar aviso no log do WordPress.
6. Falha depois da instalação se corrige em nova versão. Não há procedimento de retorno à 1.78.0.
