# Operação do Core 1.77.0

Leia RELEASE-1.77.0.md por f3base/documentacao-ler. Abra f3base/como-usar para o padrão de classes adicionais do editor. Para 386, confira avisos_alvo e textos_sem_alvo e compare os eventos de uma sessão marcada. Para 387, compare a página, o consentimento aplicado, sessao, plataforma, cobertura e cobertura_fonte no contato de teste. Para 388, inspecione o HTML antes da execução dos scripts e envie a primeira etapa com e sem JavaScript. Na execução com JavaScript envie também o complemento. Limite os contatos de homologação ao segmento de teste.
