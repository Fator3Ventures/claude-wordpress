# Fator3 Site Core 1.80.0

Base de atualização 1.79.0. WordPress 7.1.4 e PHP 8.3 de 64 bits. Contrato administrativo 8.38.0.

## Editar em duas sessões

Se outro administrador alterou uma opção da área enquanto você editava outra, Salvar alterações preserva as duas edições. Se ambos alteraram a mesma opção, a gravação recusa o valor desatualizado. Reabra a área para conferir o valor persistido e reaplique sua edição. As permissões, o nonce, o prazo do formulário e a revisão continuam a ser verificados no servidor.

O índice da área abre seções recolhidas ao seguir o fragmento de um link ou usar o histórico do navegador. Um fragmento com escape inválido é ignorado pelo índice.

## Origem de formulário

O post publicado do token determina a página do contato. Na ausência dessa referência, o Core usa o caminho do Referer do próprio site. Instalações em subdiretórios preservam seu prefixo uma única vez. O fallback exclui caminhos fora da instalação e cabeçalhos com caracteres inválidos. A página salva fica separada dos parâmetros usados pela política de atribuição.

## Carga com WP Super Cache

O WP Super Cache pode registrar sua desinstalação enquanto o WordPress carrega os plugins. A gravação de uma opção alheia deixa de disparar a leitura dos diagnósticos de cabeçalhos e entrega. Uma gravação que corresponda a um aviso de configuração ativo só inicia a reavaliação dos avisos de opções a partir de `init`. O painel continua mostrando avisos de opções, de pós-atualização e do transporte de e-mail.

## Integrações

A habilidade f3base/config-core-escrever explicita readonly=false no registro. A simulação continua sendo o padrão. O contrato pipedrive-api-client/1.0.0 conserva as verificações de autorização, orçamento e classificação do resultado de escrita. O Pipedrive 0.9.0 é responsável por persistir a incerteza e controlar o reenvio.
