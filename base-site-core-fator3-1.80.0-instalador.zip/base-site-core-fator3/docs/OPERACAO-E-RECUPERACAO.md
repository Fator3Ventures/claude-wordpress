# Operação e recuperação — Core 1.80.0

Este documento cobre as tarefas agendadas, a guarda de recuperação (pausa, restauração e retomada), a atualização e a desinstalação do Core 1.80.0. Os códigos de resposta estão em CONTRACTS.md. Textos de versões anteriores estão na seção final "Histórico".

## Leituras que não têm efeito

Nenhuma destas abilities repara, reenvia ou chama fornecedor: `f3base/saude-ler`, `f3base/execucoes-ler`, `f3base/operacao-recuperacao-ler`, `f3base/estado-inventario-ler`, `f3base/resumo-operacional-ler`, `f3base/integracoes-ler`, `f3base/documentacao-ler`. A ability `f3base/como-usar` reúne o estado de atualização, recuperação, execuções, acessos de servidor, captação Meta e diagnóstico de cron.

## Tarefas agendadas

- O Core executa suas tarefas pelo WP-Cron. As tarefas conhecidas e seus ganchos estão em `F3Base_Operacao::tarefas()` (migração, acessos, editorial, WhatsApp, e-mail do site, conversões pelo servidor, Clarity, GA4, Search Console, Meta, Google, robots, llms, ofertas, navegação, schema, reaquecimento, cache e outras).
- `f3base/executar-pendentes` executa as tarefas vencidas sob reserva e orçamento. Parâmetros: `compacto`, `tarefas` (lista de nomes da lista acima), `limite` e outros; o schema completo está em REFERENCIA-ABILITIES.md e no catálogo MCP.
- Limites do executor no código: no máximo 3 trabalhos (`MAX_TRABALHOS`) e 30 segundos (`MAX_SEGUNDOS`) por passagem; reserva de 180 segundos (`LEASE_SEGUNDOS`).
- A resposta traz `execucao_concluida` ou `execucao_parcial`. Parcial significa que restam tarefas vencidas: repita a chamada.
- Sem cron em execução ou com limite de hospedagem, não há garantia de horário. Não force estado, checkpoint ou cota para obter sucesso aparente.
- Conferência de cron: CRON-DIAGNOSTICO-1.31.md explica que uma passagem registrada prova a execução e uma entrada de agenda prova só a intenção.

## Guarda de recuperação

A guarda é um conjunto de arquivos em `wp-content/f3-core-state/`, um conjunto por site (`site-N`), independente do banco restaurado:

- `site-N.php`: sentinela, com `geracao` e `pausado`.
- `site-N-state.php`: barreira das operações de recuperação.
- `site-N-workers.php`: coordena a entrada das tarefas (trava compartilhada para trabalhar, exclusiva para drenar).
- `site-N-task-<tarefa>.php`: reserva de cada tarefa.
- `index.php` da pasta: devolve 404.

Com a sentinela pausada, as tarefas e as mutações protegidas retornam `core_em_recuperacao`; a leitura da documentação continua.

### Antes de restaurar backup

1. Leia o estado: ability `f3base/operacao-recuperacao-ler` ou `wp f3base operacao recuperacao ler`. Anote `geracao`.
2. Execute `preparar` com `geracao_esperada`: `f3base/operacao-recuperacao` (`acao: preparar`) ou `wp f3base operacao recuperacao preparar --geracao=N`. A sentinela passa a pausada.
3. Se a resposta for `aguardando_drenagem`, repita a mesma chamada até `core_drenado`.
4. Restaure arquivos, banco e a pasta `f3-core-state` como um conjunto coerente. Restaurar arquivos não desfaz o banco, mensagens enviadas nem o CRM.

### Depois de restaurar

1. Reconcilie com os sistemas externos os itens suspensos ou incertos. A retomada marca como `suspenso` (ou `incerto`, conforme a tabela) o que estava pendente nas filas de Meta, Pipedrive, avisos, complementos, qualidade, LinkedIn e e-mail do site, e zera as reservas.
2. Execute `retomar` com `geracao_esperada` e `reconciliacao_confirmada`: `acao: retomar` ou `wp f3base operacao recuperacao retomar --geracao=N --reconciliacao-confirmada`. Resposta esperada: `core_retomado`, com a geração incrementada. Se o Core já estava ativo, a resposta é `ja_retomado`.
3. Se a sentinela estiver ausente ou inválida, use `recriar` (`--precondicao=HASH --copia-outro-host=sim|nao --reconciliacao-confirmada [--manter-pausado]`). Leia a `precondicao` no estado antes. `recriar` é recusado se a sentinela for válida.

Timeout ou ausência de resposta não prova que nada foi feito. Não repita uma escrita externa sem reconciliar.

## Atualização

- A migração de estrutura (`f3base_migrar_estrutura`) roda como tarefa agendada; `F3Base_Atualizacao` guarda o estado na opção `f3base_estrutura_estado`. Leia o resultado em `f3base/como-usar` (bloco `atualizacao`).
- A base de atualização da 1.80.0 é a 1.79.0. Correção de defeito sai em versão nova; este documento não descreve downgrade.

## Desinstalação

Conforme `uninstall.php`:

- Sai: estado de execução (carimbos de atividade, segredo do endpoint, estado de cadência, auditoria de escritas do canal, procedência das gravações), agendamentos, transientes e as tabelas auxiliares de comportamento, eventos, acessos, contribuições, decisões de consentimento, vitais e fila CAPI. O `llms.txt` físico próprio é retirado.
- Fica: registros de contatos (tabela `f3base_leads`, CPT e caixa do Flamingo), contatos legados, anexos e conteúdo privados, concessões, fila de avisos cifrada (suspensa), o journal de eliminação (`f3base_journal_eliminacao`) e as opções de configuração.
- Desativar ou desinstalar não autoriza apagar dados de contatos nem desfaz efeitos externos. A remoção do que fica tem rota própria com capability e journal.
- O inventário completo de estado, propriedade, backup, retenção e desinstalação sai de `f3base/estado-inventario-ler` e de `docs/dados/estado-inventario.json`.

## Limpeza do e-mail antigo

`f3base/email-legado-limpar` simula por padrão e elimina resíduos do e-mail antigo após conferir a configuração corrente. É irreversível sem backup. Fluxo: simular, conferir, aplicar, reler.

## Retenção e dados

Prazos de guarda e dicionário de dados: RETENCAO-1.45.md e DICIONARIO-DADOS.md (especificações com sufixo de versão; valem até serem substituídas, conforme DOCUMENTACAO.md).

## Histórico

Esta página descrevia, até a 1.78.0, a operação do Core 1.53.0: atualização direta da 1.51.0 em 17 etapas, regras de incidentes de captação (duas passagens perdidas, três falhas de transporte), orçamento de uma oportunidade por seis ganchos e catálogo de acessos com memória incremental. Esses pontos não foram reconferidos contra o código da 1.80.0 e saíram do texto vigente. Os documentos OPERACAO-1.55.md, OPERACAO-1.58.md, EMAIL-SITE-1.53.md e history/RELEASE-1.53.0.md registram o que valia nas versões deles.
