# Site Core 1.78.0 · 10/11/2026

Base de atualização 1.77.0. Requer WordPress 7.1.4 e PHP 8.3 de 64 bits. Contrato administrativo 8.38.0. O impacto do Implantador 2.20.0, revisão 3, consolida a autoria pedida na 2.19.0.

## Autoria no Yoast

Quando a política de autoria institucional ou a proteção de usuário técnico se aplica, o Core atribui a mesma Organization ao artigo e ao WebPage da página atual. Identifica WebPage pelo próprio @id ou url, aceita fragmento e mantém entidades alheias. Um antigo autor Person só sai do grafo depois de perder sua última referência, respeitando a equipe configurada. O modo de proteção também participa da chave de cache do grafo. A ponte editorial do tema pode aplicar perfis públicos aprovados depois do Core. A associação do usuário no WordPress é preservada.

## C6 · Reaquecimento

O worker examina o caminho antes de buscar o post e comparar seu permalink público. Recusa query, fragmento, barra invertida, caminho iniciado com duas barras, segmentos de ponto, ponto e barras codificados e rotas técnicas. Se a validação da expressão falhar, o worker descarta o candidato. A janela de visitas, o limite por hora, a exclusão de automação e a confirmação da cópia pelo conteúdo do WP Super Cache seguem a configuração existente.

## C7 · Diretório de atualização

Com bloquear_listagem ligado, servidor-aplicar gera no bloco próprio do Apache uma regra que responde 404 ao caminho de content_url('/upgrade/'), com ou sem barra final. A regra usa o prefixo real do site e só cobre o diretório. A operação verifica o arquivo de controle, o diretório aleatório e o GET exato de upgrade. ultima_operacao.listagem.upgrade_http contém a resposta observada. Uma resposta 200 vazia, um redirecionamento ou um erro de transporte deixam a prova pendente.

O operador de sites já instalados deve consultar e aplicar a revisão vigente para atualizar o bloco, depois validar as URLs públicas. Em instalações com outro servidor, a hospedagem aplica a regra equivalente e verifica o HTTP servido. Consulte AGENTES-1.78.0.md.
