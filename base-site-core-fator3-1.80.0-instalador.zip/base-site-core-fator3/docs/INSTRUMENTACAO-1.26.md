# Core 1.77.0 · 10/11/2026

Alvos por classe no editor, origem de anúncios em contatos sem sessão e formulário em duas etapas. Consulte RELEASE-1.77.0.md e AGENTES-1.77.0.md.

> Complemento vigente na 1.27.0: RELEASE-1.55.0.md e COMUNICACAO-CONTATOS-1.27.md têm precedência para conteúdo, cortes e retomada.

# Auditoria do conteúdo renderizado por URL

`f3base/conteudo-instrumentacao-ler` exige manage_options. Parâmetros: pagina (1...), limite (1–5), tipo (post/page), post_id ou url exata pertencente ao catálogo público. Sem filtro de conteúdo, o catálogo começa pela home, arquivo de posts configurado, busca representativa e rota inexistente representativa (404), seguido de posts/páginas publicados sem senha. Quando a home é o arquivo, uma entrada representa os dois; o plugin não inventa URL de arquivo que não existe. Busca/404 são amostras de rotas dinâmicas, não posts publicados nem prova de todas as combinações.

Cada GET é anônimo, sem cookies de administrador, marcado X-F3Base-Teste: 1. A saída traz `por_url` e `linhas` equivalentes, tipo, post_id quando houver, status observado/esperado, primeiro_nivel_sem_secao, seções repetidas/aninhadas, conflitos de superfície, textos WhatsApp repetidos e formulários observados. `cobertura_completa` refere-se ao HTML servido **da página de resultados consultada**; siga proxima_pagina para terminar o catálogo. `composicao_tema_inspecionada` confirma que o tema foi incluído nessa leitura.

Classes `f3base-secao-<slug>` delimitam seções. Contêineres neutros são atravessados; texto ou mídia sem ancestral marcado produz faixa sem seção. A auditoria inclui header/footer e template parts efetivamente servidos, sem depender de Gutenberg. Scripts, estilos, elementos hidden/aria-hidden e os controles de consentimento do Core não são faixas editoriais. Estes controles aparecem em interfaces_operacionais_excluidas. CSS responsivo, pseudo-elementos e conteúdo gerado por JavaScript não são avaliados: não é prova visual nem prova de visibilidade em pixels.

Limites: cinco URLs/chamada, 20 segundos totais, 2 MiB/URL, 15 mil nós e profundidade 80. Não segue redirecionamentos; URL com redirect/status inesperado, documento truncado, ausência de DOM/body/fim do HTML ou limite de inspeção fica incompleta. Resposta 404 esperada só é sucesso na rota representativa de 404. `ok: true` indica consulta executada, não ausência de lacunas: confira cobertura e as listas de cada URL.

A análise estática `analisar(WP_Post)` continua disponível internamente como apoio; a ability usa HTML renderizado. Nenhum tema é alterado. GETs podem entrar na classe de acessos técnicos/testes, não são uma operação sem requisição. Envie as URLs e caminhos DOM de lacunas ao responsável pelo tema. Zero faixas sem seção só é aceito quando efetivamente observado; o Core não suprime lacunas para satisfazer o aceite.
