# Site Core 1.79.0 · 10/11/2026

Base de atualização 1.78.0. Requer WordPress 7.1.4 e PHP 8.3 de 64 bits. Contrato administrativo 8.38.0, sem alteração.

Esta versão muda a tela de configuração, corrige dois defeitos que impediam gravar por ela, corrige a consulta a habilidades de pacotes ausentes e reorganiza a documentação instalada. Habilidades, schemas, options, tabelas, capabilities e arquivos públicos de JavaScript e CSS são os da 1.78.0. Não há migração de dados.

## Tela de configuração

- Uma folha de estilo para o painel (`admin/assets/f3base-painel.css`) e uma largura para todas as peças da tela.
- Cabeçalho com título, versão e as três áreas do plugin: Configurações, Informações técnicas e Operação.
- Nas áreas com formulário, um índice dos grupos de campos fica ao lado do conteúdo em janelas a partir de 1200 px e no topo, recolhível, nas menores.
- A barra de salvar fica fixa na base da janela durante a edição e avisa quando há alteração não salva. Ela é impressa pelo servidor: a tela grava com JavaScript desligado.
- Cada campo tem um rótulo. O detalhe "Como funciona e exemplo" deixou de repetir a descrição que já está visível.
- Informações técnicas abre com o estado operacional; as demais seções ficam recolhidas e os blocos longos têm rolagem própria.
- Em 390 px de largura nenhuma tela do plugin rola na horizontal.
- O menu lateral tem uma entrada por destino.
- Avisos de configuração dizem o que ocorreu e o que fazer; o código interno fica como informação secundária.

Atributos `data-f3base-campo`, ação e nonce do formulário, valores de `secao` e `aba` e a ordem dos blocos não mudaram. Os nomes de campos são os da 1.78.0, menos os seis itens descritos a seguir. `docs/GUIA-PAINEL.md` descreve a tela.

## Gravação pela tela

Dois defeitos existentes na 1.78.0 foram corrigidos.

Áreas que não gravavam. Em Coleta do site, Conteúdo e IA e SEO, qualquer envio do formulário, mesmo sem alteração, voltava com "Campo incompleto ou fora do escopo" e nada era gravado. Seis options de estrutura própria saíam na tela como um campo de texto vazio: `f3base_campanhas_origem`, `f3base_contexto_sessao`, `f3base_canais_organicos` e `f3base_origens_ia` em Coleta do site, `f3base_marcas_vigiadas` em Conteúdo e IA e `f3base_redirects` em SEO. O texto enviado era recusado, e a recusa de um campo impede a gravação da área. Esses seis itens deixaram de ser campo do formulário e aparecem como bloco somente leitura, com o valor atual e a habilidade que os altera (`f3base/config-core-escrever`; para redirects, `f3base/redirects-escrever`). As três áreas voltaram a gravar. A tela continua sem editor para esses seis itens.

Grupos que recusavam alteração parcial. A tela grava grupos por diferença, e o gravador avaliava a regra de recusa só sobre as chaves alteradas. Em quatro options a regra só faz sentido sobre o valor inteiro, e toda alteração era recusada: `f3base_conversoes_conteudo` ("Cada destino de material deve ser verdadeiro ou falso"), `f3base_conversoes_transporte`, `f3base_navegacao` e `f3base_gsc_consultas`. Para essas quatro, todas as chaves passam a ser avaliadas em conjunto. A regra de recusa de cada option e a gravação por habilidade não mudaram.

A interface de Qualidade e Meta passou a escapar o índice das linhas nos atributos `id` e `name`. Pelas interfaces do produto esse índice é sempre numérico; o escape cobre valor gravado por código interno.

## Consulta a pacotes acompanhantes

`f3base/resumo-operacional-ler`, `f3base/credenciais-resumo-ler` e `f3base/midia-prontidao-ler` consultavam habilidades dos pacotes Google, Meta e LinkedIn sem verificar antes se existiam. Em site sem um desses pacotes, cada leitura registrava um aviso `_doing_it_wrong` do WordPress. A consulta agora pergunta `wp_has_ability()` primeiro. As respostas são as mesmas: `pacote_ou_ability_ausente` para o pacote que falta, e o resultado do pacote quando ele está instalado. O mesmo cuidado vale para `linkedin/admin-options` e `ads/search`.

## Documentação

- `docs/DOCUMENTACAO.md` é o índice completo: todo arquivo de `docs/` aparece nele, com o papel de cada um.
- README, INSTRUCOES-DO-PLUGIN, CONTRACTS, OPERACAO-E-RECUPERACAO e VALIDACAO descrevem a versão instalada. O que não pôde ser conferido contra o código saiu do texto vigente ou foi para uma seção de histórico.
- `docs/REFERENCIA-ABILITIES.md` lista as habilidades por domínio e é gerado do registro.
- `docs/dados/abilities-*.json` passou a ser gerado do registro do Core. Até a 1.78.0 era uma captura da visão MCP feita na 1.72.1, com uma habilidade ausente e quatro listas de options desatualizadas. Os campos de envelope e o `idempotency_key` que a camada MCP acrescenta não constam mais desses arquivos; o schema efetivo de uma conexão se lê por `get-ability-info`.
- Referências a arquivos inexistentes foram corrigidas. Nenhum arquivo mudou de caminho.

## Limites desta versão

- `docs/dados/ajuda-opcoes.json` e `docs/dados/configuracao-schema.json` continuam sem gerador integral: só o campo de versão é regravado a cada release.
- DICIONARIO-DADOS, REFERENCIA-CATALOGO, PIPEDRIVE e alguns documentos por domínio ainda trazem cabeçalhos de versões anteriores. O índice indica quais.
- A integração com Yoast, PublishPress Authors e WP Super Cache não foi reexecutada nesta rodada. O código dessas fronteiras é idêntico ao da 1.78.0.

## Depois de instalar

Nenhuma ação de configuração é necessária. Consulte AGENTES-1.79.0.md para a conferência. Correção após a instalação sai em nova versão; não há retorno à 1.78.0.
