# Fator3 Site Core 1.75.1

Atualização direta da 1.74.0, para WordPress 7.1.4 e PHP 8.3 ou superiores. Contrato administrativo 8.36.0. As opções novas têm padrões locais. A instalação preserva as tabelas e o conteúdo existente.

## Mensagens acima de 2 MiB — pedido 375

A leitura IMAP consulta tamanho, cabeçalho, BODYSTRUCTURE e até 64 KiB da parte textual. Cabeçalhos grandes usam uma consulta seletiva. O contato entra na revisão de suspeitos com assunto, remetente declarado, e-mail de resposta único, tamanho da mensagem, metadados de anexos disponíveis e o motivo de descarte que se aplicaria. A autenticação fica marcada como não verificada. A movimentação para a pasta de importados depende de um contato persistido. Aprovação e avisos seguem o fluxo de contatos. Para recuperar UID descartado, use a prévia e a aplicação de `f3base/email-reprocessar` com a identidade da caixa e o UID conferidos.

Em `f3base_email_site.descartes_acima_limite`, uma lista vazia encaminha à revisão. Uma exceção explícita, como `resposta_automatica`, reativa o descarte correspondente. A data de ativação da caixa continua delimitando a importação histórica. O reparo de registros antigos com cabeçalho excedido usa somente metadados que a versão anterior conservou.

## Pixels adicionais no navegador — pedido 376

Na seção Meta, informe um ID por linha em `f3base_meta_pixels_adicionais` e mantenha o principal em `f3base_meta_pixel_id`. A lista inicia vazia. O navegador carrega uma biblioteca, inicializa cada ID e transmite PageView ou Lead com um identificador comum por ocorrência. Consentimento, modo de transporte, política de Lead e supressão em teste se aplicam a todos. A fila CAPI usa o destino de servidor configurado ou o principal. Para acompanhar os destinos pelo monitoramento, adicione os datasets autorizados a `f3base_meta_monitoramento.dataset_ids` e confira `f3base/meta-entregas-ler`. Aceite no fornecedor requer acesso aos respectivos datasets.

## Abandono de formulários — pedidos 377 e 378

Use `f3base/sessao-detalhar` para consultar o fechamento analítico com `ultimo_campo`, `etapa` e `campos_preenchidos`. O patch 1.75.1 identifica também o fechamento legado de comportamento, pareado ou sem navegação. A ausência de prova de etapa aparece como `nao_observado`. Use `visao=formularios` e `sessao` (32 caracteres hexadecimais) em `f3base/relatorios-integrados-ler`.

Em Privacidade, `f3base_formulario_tentativas.capturar_abandono` inicia desligado. Antes de ativar por ordem do dono, defina `abandono_exige_medicao` (padrão ligado). Esta decisão independe de `capturar_valores`, que trata das tentativas recusadas. Um blur com alteração, o fechamento ou a saída pode enviar uma fotografia da primeira etapa sem aceite. O servidor substitui o registro da instância pela sequência mais recente. Campos apagados permanecem vazios. O aceite elimina a fotografia. A expiração do token, o orçamento ou o fechamento do navegador podem impedir o último envio.

Apenas `f3base/formularios-tentativas-ler`, com a capacidade de leitura de leads, permite ler a fotografia. Ela acompanha a retenção das tentativas e a eliminação por sessão, contato e titular. O vínculo de eliminação do e-mail apagado é mantido como HMAC. Campos ocultos, iscas, senhas, tokens e arquivos ficam excluídos. Valores permanecem fora de relatórios de audiência e de integrações.

## Cliques inertes e de fricção — pedido 379

O tema pode declarar `data-f3base-alvo="equipe"` no elemento ou em um ancestral dentro da seção. Use até 48 letras minúsculas, dígitos, hífens e sublinhados, começando com letra ou dígito. Sem declaração, o navegador compõe um identificador com seção, tipo e posição. A janela de repetição de um clique inerte no mesmo alvo é 1.200 ms. Os tetos por carregamento em `f3base_comportamento` são `teto_clique_inerte` (30) e `teto_friccao` (15). Os limites da visita, do lote e do endpoint continuam vigentes. Os eventos seguem as seleções e o consentimento de medição existentes. Em blocos, consulte `cliques_por_alvo`. Na auditoria de HTML renderizado consulte `textos_sem_alvo`, com seção e posição DOM.

## Agenda, teste de lead e cache — pedidos 380 a 382

- Ao escrever `f3base_cadencia`, confira a resposta de efeito e a recorrência em `cron/list`. Semanal, quinzenal e mensal usam seus eventos WP-Cron. A periodicidade nenhuma remove o evento. Uma passagem CLI recompõe eventos ausentes. O resumo operacional indica divergências.
- Para testar o caminho do lead, simule `f3base/caminho-lead-testar` com `{"formulario":"contato-whatsapp","campos":{"contato":"11999990000"},"simular":true}`. Aplique com a revisão devolvida e chave de operação única. Consulte o recibo até o estado final. Os saltos indicam individualmente a disponibilidade e as supressões de fornecedores.
- Em `f3base/cache-reaquecimento-ler`, `estado.reservas` representa a cota por hora. `reservas_execucao` mostra a reserva do módulo, a lease do executor, as intenções e a conexão MySQL. Um registro antigo pode ter `desde=null`. Uma espera por orçamento no reaquecimento fica elegível a partir do segundo seguinte. Uma ocorrência já executada encerra sua intenção pendente.
- Para liberar uma reserva órfã do módulo, simule `f3base/executar-pendentes` com `liberar_reserva_reaquecimento=true`. Aplique com `simular=false`, revisão relida e motivo de 5 a 240 caracteres. O executor rejeita concorrência e confere a revisão antes da exclusão. O diário grava motivo e ator. O resumo operacional sinaliza mais de duas horas sem execução se a rotina estiver habilitada.
