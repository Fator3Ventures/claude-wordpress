# Operação por agente · 1.76.0

Descubra f3base/documentacao-ler e leia docs/RELEASE-1.76.0.md. Para CAPI, consulte f3base/meta-entregas-ler em modo eventos. Compare classe_trafego, estado, http e event_id. Os motivos negativa_explicita, decisao_ausente, politica_alterada e decisao_leitura_falhou indicam ações distintas. Investigue falhas de leitura antes de retomar a fila. Não recrie recibos expirados nem repita um envio incerto.

Para o retorno de etapa, descubra a prévia de destinos comerciais e leia o schema de record_id e etapa. O acesso exige manage_options e f3base_ler_leads. Compare a prévia de um formulário nativo marcado e a de um com negativa mapeada. Confira envio_realizado=false e o código de cada destino. Para homologação em fornecedor, use os ativos e os destinos autorizados pelo dono.
