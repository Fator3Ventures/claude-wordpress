# Operação do Site Core 1.80.0

Leia o índice com f3base/documentacao-ler. Para configuração, use f3base/config-core-ler com o nome da opção, simule a mudança por f3base/config-core-escrever com revisao_esperada e, quando autorizado, aplique e confira a nova leitura. O canal de execução precisa admitir escrita. Conflito exige nova leitura da opção.

Na tela Configurações, mantenha duas sessões em homologação e altere opções distintas da mesma área. Confirme as duas leituras depois de salvar. Em seguida, repita com a mesma opção e confira a recusa da edição obsoleta.

Em instalações sob prefixo, confira o campo página do contato com uma visita sintética. Os parâmetros de campanha pertencem à atribuição, conforme consentimento e proveniência registrados. Para o CRM, consulte o recibo e as pendências do Pipedrive antes de decidir sobre uma escrita incerta.
