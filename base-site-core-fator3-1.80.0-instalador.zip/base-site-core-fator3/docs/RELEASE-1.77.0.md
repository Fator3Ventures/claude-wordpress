# Fator3 Site Core 1.77.0

10/11/2026 · Atualização direta da 1.76.0 · WordPress 7.1.4 ou superior · PHP 8.3 ou superior · Contrato administrativo 8.38.0.

## Alvos de cliques inertes (386)

No editor, selecione o parágrafo ou seu grupo e abra Avançado → Classe(s) CSS adicional(is). Use, por exemplo, `f3base-alvo-teste-grupo`. O nome começa com letra minúscula ou algarismo e admite até 48 caracteres entre a–z, 0–9, hífen e sublinhado. O rastreador sobe do elemento tocado até a seção, inclusive. No primeiro nó com uma declaração válida, usa o atributo `data-f3base-alvo` ou, na ausência de atributo válido, a primeira classe válida na ordem do HTML. A classe não recebe estilo e a resolução ocorre durante o clique.

Consulte `f3base/conteudo-instrumentacao-ler` com `post_id`. Cada entrada de `avisos_alvo` indica o caminho, as classes concorrentes e o nome efetivo. `textos_sem_alvo` mostra os nós de texto editorial sem cobertura declarada na seção. Corrija classes duplicadas no bloco indicado. Para conferir o evento, use `f3base/sessao-detalhar` com a sessão de teste e `segmento=somente_testes`.

## Origem de contatos sem sessão (387)

Um clique de contato ou formulário sem sessão aproveita os parâmetros da navegação atual. O Core reconhece gclid, gbraid, wbraid, fbclid, li_fat_id, gad_campaignid e UTMs declaradas no contrato. O servidor completa os campos ausentes a partir da página de origem do clique. No formulário usa a URL do referenciador da própria página quando disponível. Um bloqueio do referenciador impede recuperar no servidor um parâmetro que o cliente também omitiu. As regras de publicidade filtram identificadores. Uma visita que traz gclid identifica Google Ads; gad_campaignid numérico pode preencher campanha_id quando utm_id estiver ausente e a plataforma for Google Ads.

Na atribuição do registro, `cobertura` indica o nível de detalhe e `cobertura_fonte` distingue `url_navegador`, `pagina_servidor` e `url_navegador_e_pagina`. A atribuição de um contato sem sessão não cria sessão, armazenamento de toques nem cookie. Registros anteriores mantêm o conteúdo original.

## Formulários em duas etapas (388)

Os campos da etapa 2 chegam no HTML com `hidden` e os controles chegam desabilitados. O navegador revela e habilita o complemento após a confirmação da primeira etapa. O POST nativo envia os campos da primeira etapa quando JavaScript está desativado. A opção de apresentação inline ou em diálogo continua na configuração do formulário. Para medir o resultado final da campanha, a frota deve repetir três medições PSI desktop após publicar em Korvena e registrar a mediana de CLS.
