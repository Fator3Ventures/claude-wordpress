# Documentação do Fator3 Site Core 1.80.0

Plugin `base-site-core-fator3`, versão 1.80.0. Contrato administrativo 8.38.0, base de atualização 1.79.0. Este é o índice completo da documentação instalada em `docs/`.

## Como ler

- MCP: ability `f3base/documentacao-ler`. Sem argumentos, devolve versão, índice e a lista exata de arquivos legíveis. Com `arquivo`, `linha` e `limite` (até 200 linhas, padrão 120), devolve uma página, `sha256` do arquivo inteiro, `total_linhas` e `proxima_linha`. Continue até `proxima_linha` ser nulo e confira que o `sha256` não mudou entre as páginas.
- Painel: a tela Configurações do Site Core exibe GUIA-PAINEL.md. Os demais arquivos são lidos pelo MCP ou direto na pasta `docs/` do plugin.
- Exige conta com `manage_options`. A leitura é estática: não faz HTTP, não grava configuração e não repara agenda.
- O caminho de cada arquivo é seu identificador. Nenhum arquivo muda de caminho entre versões.

## Os oito documentos lógicos da norma

A norma (NORMA-02-padrao-desenvolvimento-plugins-fator3.md, seção 7.1) pede oito documentos lógicos. Aqui, arquivos existentes cumprem cada papel; não há cópias com os nomes sugeridos.

| Documento lógico | Arquivos que cumprem o papel |
| --- | --- |
| Índice | DOCUMENTACAO.md (este), README.md |
| Especificação | Especificações por domínio (seção abaixo), LEADS-E-FORMULARIOS.md, INSTRUCOES-DO-PLUGIN.md |
| Configuração | GUIA-PAINEL.md, CONFIGURACAO.md, AJUDA-OPCOES.md, CREDENCIAIS-1.51.md, CREDENCIAIS-1.60.md, `docs/dados/configuracao-schema.json` |
| Uso | INSTRUCOES-DO-PLUGIN.md, GUIA-PAINEL.md, RELATORIOS.md, ANALISAR-CONTEUDO-ORGANICO.md, ANALISAR-PRESENCA-IA.md |
| Contratos | CONTRACTS.md, REFERENCIA-ABILITIES.md, REFERENCIA-CATALOGO.md, `docs/dados/abilities-*.json`, `docs/schemas/` |
| Guia para agentes | AGENTES-1.80.0.md |
| Operação | OPERACAO-E-RECUPERACAO.md, VALIDACAO.md, CRON-DIAGNOSTICO-1.31.md, RETENCAO-1.45.md, DICIONARIO-DADOS.md |
| Notas da versão | RELEASE-1.80.0.md, CHANGELOG.md |

## Esta release (1.80.0)

Só estes documentos descrevem a release instalada como um todo:

- AGENTES-1.80.0.md: guia para agentes (descobrir, ler, diagnosticar, configurar, verificar).
- RELEASE-1.80.0.md: mudanças, base de migração, requisitos, limites e pendências da release.
- REFERENCIA-ABILITIES.md: lista das abilities gerada do registro.

## Documentos de entrada

| Arquivo | O que responde e quando ler |
| --- | --- |
| DOCUMENTACAO.md | Este índice. |
| README.md | Leia primeiro: identidade, requisitos e como ler a documentação instalada. (O `README.md` da raiz do plugin é uma versão de três linhas.) |
| INSTRUCOES-DO-PLUGIN.md | Como operar o Core: regra principal, quem pode operar, sequência ler, simular, aplicar, verificar. Leia antes de gravar configuração. |
| GUIA-PAINEL.md | Como configurar o Site Core pelo painel do WordPress. É o arquivo que a tela Configurações exibe. |
| CONFIGURACAO.md | Notas de configuração por versão. Leia para saber o que mudou em campos e padrões. |
| CONTRACTS.md | Contrato administrativo, contratos com outros pacotes, ponte do implantador e códigos de resposta da recuperação. |
| REFERENCIA-ABILITIES.md | Lista gerada do registro: todas as abilities `f3base/*` por domínio, com rótulo, leitura ou escrita e parâmetros obrigatórios. |
| REFERENCIA-CATALOGO.md | Catálogo de configuração gerado do registro executável (chaves e schemas). Cabeçalho de uma versão anterior; a fonte atual é `docs/dados/configuracao-schema.json`. |
| AJUDA-OPCOES.md | Ajuda de cada opção, gerada do catálogo. Documento longo: leia por página e procure a opção pelo nome. Não contém valores configurados. |
| OPERACAO-E-RECUPERACAO.md | Tarefas agendadas, guarda de recuperação (preparar, restaurar, retomar), atualização e desinstalação. |
| VALIDACAO.md | Conferências sem efeito para provar que a documentação e o plugin instalados correspondem à versão. |
| CHANGELOG.md | Histórico curto de mudanças por versão, da mais nova para a mais antiga. |
| DICIONARIO-DADOS.md | Dicionário de dados: tabelas, colunas e propriedades. Cabeçalho de uma versão anterior; confira a estrutura atual em `f3base/estado-inventario-ler`. |

## Documentos vigentes por assunto

Documentos sem versão no nome. Valem até serem substituídos.

### Medição e relatórios

| Arquivo | O que responde e quando ler |
| --- | --- |
| MEDICAO-DESEMPENHO.md | Como medir o custo do Core por rota e a experiência das visitas (vitais). |
| VITAIS-VERSAO.md | Separar Web Vitals pela versão do código carregado na visita. |
| RELATORIOS.md | Relatórios integrados: quadros, filtros e leitura. |
| METRICAS.md | Identificadores das métricas de saída de `f3base/relatorios-integrados-ler` e como não somar quadros. |
| AGENTES-E-BUSCADORES.md | Relatório de robôs e buscadores nos logs do servidor. Não é o guia para agentes de MCP; esse é o AGENTES-<versão>.md. |
| ANALISAR-CONTEUDO-ORGANICO.md | Passo a passo para analisar conteúdo por busca orgânica. |
| ANALISAR-PRESENCA-IA.md | Separar conteúdo requisitado por IA, visitas vindas de IA e citações. |

### Publicidade e origens

| Arquivo | O que responde e quando ler |
| --- | --- |
| ORIGENS-ANUNCIOS.md | Origens de anúncios: atribuição web, importação de contatos nativos e envio de conversões. |
| CRUZAMENTOS-PUBLICIDADE.md | Cruzar formulários, anúncios e contatos por agente. |
| OFERTAS.md | Ofertas comerciais: marcação, verificação e SEO. |
| OFERTAS-MEDICAO.md | Medição das ofertas (impressão, abertura, fechamento). |

### Contatos e formulários

| Arquivo | O que responde e quando ler |
| --- | --- |
| LEADS-E-FORMULARIOS.md | Captação de contatos e formulários. |

### Integrações

| Arquivo | O que responde e quando ler |
| --- | --- |
| PIPEDRIVE.md | Envio de contatos ao Pipedrive. Contém blocos de versões antigas; as regras recentes estão em PIPEDRIVE-1.37.md e PIPEDRIVE-OPERACAO.md. |
| PIPEDRIVE-OPERACAO.md | Cliente de operação Pipedrive (`pipedrive-api-client/1.0.0`): token, orçamento, reservas. |
| ORCAMENTO-PIPEDRIVE.md | Orçamento diário por consumidor do Pipedrive. |
| LINKEDIN-LEAD-SYNC.md | Captação nativa de contatos LinkedIn: configuração e troca de cliente. |
| ESPECIFICACAO-LINKEDIN-REVISAO-3.md | Especificação datada do consumidor LinkedIn Lead Sync (revisão 3). Declara-se contrato proposto na época; não a use como descrição do comportamento atual. |

### Normas

| Arquivo | O que responde e quando ler |
| --- | --- |
| NORMA-01-instrucoes-agentes-plugins-fator3.md | Instruções comuns aos agentes que mantêm plugins Fator3. |
| NORMA-02-padrao-desenvolvimento-plugins-fator3.md | Padrão de desenvolvimento e entrega dos plugins Fator3. |

## Especificações por domínio (sufixo de versão)

Convenção: o sufixo do nome (`GSC-1.34.md`) é a versão em que a especificação foi escrita ou revisada pela última vez. Ela continua valendo até outro documento a substituir; o sufixo não diz que a especificação se aplica só àquela versão. Exceções declaradas nos próprios documentos: QUALIDADE-DESTINOS-1.58.md foi revisado na 1.59 e conserva o nome da origem; OPERACAO-GSC-1.20.md marca a introdução do recurso. Quando dois documentos tratam do mesmo assunto (por exemplo CAMINHO-LEAD-1.58.md e CAMINHO-LEAD-1.60.md), o de sufixo maior atualiza o outro nos pontos que declara alterar. Dentro de alguns arquivos o título interno cita outra versão; vale o texto do arquivo.

### Medição e comportamento

| Arquivo | Assunto |
| --- | --- |
| MEDICAO-1.25.md | Medição e conteúdo: consulta de contexto público, deduplicação, janelas. |
| MEDICAO-EVENTOS-1.33.md | Catálogo de eventos de medição. |
| MEDICAO-SDK-1.33.md | SDK público de medição (`site-measurement-context/1.0.0`). |
| INSTRUMENTACAO-1.26.md | Instrumentação de conteúdo, alvos e CTAs. |
| EDITORIAL-1.32.md | Relatórios editoriais de sete e 28 dias. |
| HISTORICO-1.29.md | Histórico de comportamento, conversões e operação. |
| SESSOES-1.61.md | Sessões, apps, redes e presença paga. |

### Search Console, GA4 e Clarity

| Arquivo | Assunto |
| --- | --- |
| GSC-1.34.md | Search Console: apresentação e operação. |
| OPERACAO-GSC-1.20.md | Operação do Search Console; o nome marca a introdução do recurso. |
| ACERVO-GA4-1.57.md | Acervo GA4. |
| ACERVOS-E-EMAIL-1.61.1.md | Acervos Google e Meta, consultas do Search Console e prova individual de e-mail. |
| CLARITY-1.22.md | Clarity: cadastro e teste no wp-admin. |

### Contatos, formulários e avisos

| Arquivo | Assunto |
| --- | --- |
| CONTATOS-1.22.md | Contatos, jornada e cruzamentos. |
| CONTATOS-COMERCIAL-1.58.md | Identidade, WhatsApp, resposta e desfechos do contato. |
| CONTATOS-EXTERNOS-1.54.md | Contatos externos e atribuição manual de sessões. |
| COMUNICACAO-CONTATOS-1.27.md | Seções das mensagens de contato por e-mail, Slack e Pipedrive. |
| HISTORICO-CONTATOS-1.28.md | Histórico de contatos por pseudônimo de navegador. |
| FORMULARIOS-1.29.md | Formulários em duas etapas e CTA com WhatsApp. |
| FORMULARIOS-ABANDONO-1.58.md | Abandono de formulário e relatório. |
| FORMULARIOS-SINAIS-1.53.md | Iscas antispam e política de avisos. |
| FORMULARIOS-TENTATIVAS-1.44.md | Tentativas barradas e retenção do valor digitado. |
| TELEFONE-1.45.md | Telefone em formato livre. |
| WHATSAPP-1.38.md | Links de WhatsApp e elegibilidade do número. |
| CONVERSAS-1.56.md | Conversas de WhatsApp (ponte Slack) e Instagram. |
| INSTAGRAM-EXCLUSAO-1.57.md | Exclusão de dados do Instagram. |
| ARQUIVOS-PRIVADOS-1.19.md | Arquivos privados por agentes. |
| AVISOS-WEBHOOK-1.26.md | Avisos de contatos: e-mail, Slack e webhook JSON assinado. |
| SLACK-1.32.md | Manutenção de avisos Slack. |
| CAMINHO-LEAD-1.58.md | Teste sob demanda do caminho do lead. |
| CAMINHO-LEAD-1.60.md | Atualização do teste do caminho do lead. |

### Atribuição e campanhas

| Arquivo | Assunto |
| --- | --- |
| ATRIBUICAO-1.32.md | Origem comercial e analítica do contato. |
| PROCEDENCIA-1.22.md | Procedência e complementações de configuração. |
| PUBLICIDADE-1.30.md | Publicidade, medição e negativas de consentimento. |
| CAMPANHAS-MARCAS-PERFIL-1.62.md | Marcas vigiadas, origem de campanha, canal e perfil. |
| CANAIS-ORGANICOS-1.61.md | Regras de canais orgânicos e catálogo de IA. |

### Conversões e retorno comercial

| Arquivo | Assunto |
| --- | --- |
| CONVERSOES-1.58.md | Conversões de contato e de etapa. |
| CONVERSOES-CONTEUDO-1.35.md | Conversão de solicitação de material. |
| CONVERSOES-SDK-1.36.md | SDK de conversões por finalidade (`site-conversion-purposes/1.0.0`). |
| RECONCILIACAO-COMERCIAL-1.59.md | Reconciliação de eventos comerciais. |
| QUALIDADE-META-1.29.md | Qualidade comercial e retorno à Meta. |
| QUALIDADE-CATALOGO-1.30.md | Catálogo de funis e etapas do Pipedrive. |
| QUALIDADE-DESTINOS-1.58.md | Retorno comercial por destino (revisado na 1.59; o nome conserva a origem). |

### Meta, Pipedrive e LinkedIn

| Arquivo | Assunto |
| --- | --- |
| META-ACESSO-1.28.md | Verificação de acesso Meta. |
| META-ADS-CORE-1.58.md | Consumidor do acervo Meta Ads. |
| META-ADS-CORE-1.60.md | Atualização do consumidor Meta Ads. |
| META-TRANSPORTE-1.19.md | Transporte e fila da Meta. |
| PIPEDRIVE-1.37.md | Regras comerciais do Pipedrive. |

### E-mail do site

| Arquivo | Assunto |
| --- | --- |
| EMAIL-SITE-1.53.md | Caixa de contato por site. |
| DEPENDENCIAS-EMAIL-1.53.md | Dependências MIME embutidas. |

### Configuração, credenciais e textos

| Arquivo | Assunto |
| --- | --- |
| CONFIGURACAO-1.43.md | Textos de confirmação e avisos. |
| CONFIGURACOES-1.29.md | Configurações organizadas por tarefa. |
| CREDENCIAIS-1.51.md | Credenciais: guarda cifrada e regras de campo. |
| CREDENCIAIS-1.60.md | Regra de formato de credenciais que prevalece sobre a 1.51. |
| TEXTOS-1.44.0.md | Revisão dos textos das áreas renderizadas. |

### Operação, retenção e cron

| Arquivo | Assunto |
| --- | --- |
| CRON-DIAGNOSTICO-1.31.md | Cron e confirmação da agenda. |
| OPERACAO-1.55.md | Operação, autenticação e sessões. |
| OPERACAO-1.58.md | Operação e configuração. |
| RETENCAO-1.45.md | Prazos de guarda por domínio. |

## Histórico por versão

Para cada versão há um guia para agentes (`AGENTES-<versão>.md`) e notas (`RELEASE-<versão>.md`). Só os da 1.80.0 descrevem a release instalada. Os anteriores são histórico: descrevem o comportamento e a base de cada versão e podem divergir do código atual.

Guias para agentes anteriores em `docs/`:

- AGENTES-1.57.0.md
- AGENTES-1.57.1.md
- AGENTES-1.58.0.md
- AGENTES-1.59.0.md
- AGENTES-1.60.0.md
- AGENTES-1.61.0.md
- AGENTES-1.61.1.md
- AGENTES-1.62.0.md
- AGENTES-1.63.0.md
- AGENTES-1.64.0.md
- AGENTES-1.65.0.md
- AGENTES-1.65.1.md
- AGENTES-1.66.0.md
- AGENTES-1.67.0.md
- AGENTES-1.68.0.md
- AGENTES-1.69.0.md
- AGENTES-1.70.0.md
- AGENTES-1.71.0.md
- AGENTES-1.72.0.md
- AGENTES-1.72.1.md
- AGENTES-1.73.0.md
- AGENTES-1.74.0.md
- AGENTES-1.75.1.md
- AGENTES-1.76.0.md
- AGENTES-1.77.0.md
- AGENTES-1.78.0.md
- AGENTES-1.79.0.md

Notas de versão anteriores em `docs/`:

- RELEASE-1.57.0.md
- RELEASE-1.57.1.md
- RELEASE-1.58.0.md
- RELEASE-1.59.0.md
- RELEASE-1.60.0.md
- RELEASE-1.61.0.md
- RELEASE-1.61.1.md
- RELEASE-1.62.0.md
- RELEASE-1.63.0.md
- RELEASE-1.64.0.md
- RELEASE-1.65.0.md
- RELEASE-1.65.1.md
- RELEASE-1.66.0.md
- RELEASE-1.67.0.md
- RELEASE-1.68.0.md
- RELEASE-1.69.0.md
- RELEASE-1.70.0.md
- RELEASE-1.71.0.md
- RELEASE-1.72.0.md
- RELEASE-1.72.1.md
- RELEASE-1.73.0.md
- RELEASE-1.74.0.md
- RELEASE-1.75.1.md
- RELEASE-1.76.0.md
- RELEASE-1.77.0.md
- RELEASE-1.78.0.md
- RELEASE-1.79.0.md

Versões mais antigas em `docs/history/` (leia com o caminho completo):

- docs/history/AGENTES-1.56.0.md
- docs/history/AGENTES-1.57.0.md
- docs/history/RELEASE-1.49.0.md
- docs/history/RELEASE-1.49.1.md
- docs/history/RELEASE-1.50.0.md
- docs/history/RELEASE-1.51.0.md
- docs/history/RELEASE-1.52.0.md
- docs/history/RELEASE-1.52.1.md
- docs/history/RELEASE-1.53.0.md
- docs/history/RELEASE-1.54.0.md
- docs/history/RELEASE-1.55.0.md
- docs/history/RELEASE-1.56.0.md
- docs/history/RELEASE-1.57.0.md

## Dados, schemas, fixtures e perfis

| Pasta ou arquivo | O que é |
| --- | --- |
| `docs/dados/abilities-*.json` | Catálogo das abilities `f3base/*`: descrição, schema de entrada, schema de saída e metadados como o Core os registra. Gerado do registro na construção da release (script `build/gerar-catalogo-abilities.php` do pacote fonte) e conferido pela suíte. A camada MCP acrescenta campos de envelope e, em parte das escritas, `idempotency_key`: o schema efetivo de uma conexão se lê por `get-ability-info`. |
| `docs/dados/configuracao-schema.json` | Catálogo das chaves de configuração do Core. |
| `docs/dados/ajuda-opcoes.json` | Ajuda efetiva por opção (fonte de AJUDA-OPCOES.md). |
| `docs/dados/contrato.json` | Metadados de retenção, granularidade e vínculos dos dados. |
| `docs/dados/estado-inventario.json` | Inventário de estado, propriedade, backup, retenção e desinstalação. |
| `docs/dados/origens-ia.json`, `docs/dados/robos-catalogo.json` | Catálogos de origens de IA e de robôs. |
| `docs/dados/entrega-1.19.json` | Itens da entrega da 1.19.0 (histórico). |
| `docs/schemas/` | JSON Schemas dos contratos de conversão e medição e do envio de Lead Meta. |
| `docs/fixtures/conversion/`, `docs/fixtures/measurement/` | Exemplos de entrada e saída dos contratos de conversão e medição, usados em testes. |
| `docs/perfis/` | Perfis de piso de configuração (`piso-padrao-3.2` a `piso-padrao-3.6`). O perfil canônico é `piso-padrao-3.6`; os anteriores são histórico. |
| `docs/manifesto-assets.json` | Manifesto dos arquivos JavaScript minificados. |
| `docs/CONSULTAS-EXEMPLO.sql` | Consultas de exemplo, somente SELECT (cabeçalho da 1.19.0). Para paridade com os relatórios, use as abilities. |

Todos esses arquivos, mais os `.md`, são legíveis por `f3base/documentacao-ler`.
