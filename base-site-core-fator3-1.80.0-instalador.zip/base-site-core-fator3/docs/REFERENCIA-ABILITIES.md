# Referência de habilidades (abilities) — Core 1.80.0

Arquivo gerado do registro do plugin por `build/gerar-referencia-abilities.php`. Não edite à mão.

- Plugin: Fator3 Site Core (`base-site-core-fator3`), versão 1.80.0.
- Total de abilities `f3base/*`: 193.
- Leitura: 102. Escrita: 91.
- Classificação: leitura é a ability com a anotação `readonly` verdadeira; qualquer outra, inclusive sem a anotação, é listada como escrita.
- Schema completo de cada ability: catálogo MCP (`get-ability-info`) ou `docs/dados/abilities-*.json`.
- Parâmetros obrigatórios vêm da chave `required` do schema de entrada; o total conta as chaves de `properties`.

## acessos (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/acessos-legado-ler` | Consultar agregados arquivados fora dos totais atuais | leitura | — | 3 |
| `f3base/acessos-ler` | Ler acessos do servidor | leitura | — | 6 |

## anuncios (10)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/anuncios-alteracoes-ler` | Alterações por conta, dia, entidade e campo; autoria exige dados pessoais | leitura | `ate`, `de`, `plataforma` | 8 |
| `f3base/anuncios-consultar-agora` | Consulta limitada à origem Meta autorizada; pode importar contatos | escrita | `simular` | 1 |
| `f3base/anuncios-contato-reavaliar` | Reavaliar papéis e elegibilidade local sem reenviar entregas confirmadas | escrita | `record_id` | 3 |
| `f3base/anuncios-google-reconciliar` | Ingerir lote Google autorizado; não executa GAQL | escrita | `ate`, `conta_id`, `cursor`, `de`, `equivalencia_ids_confirmada`, `executor`, `itens`, `revisao`, `simular`, `ultimo_lote` | 10 |
| `f3base/anuncios-linkedin-acesso-verificar` | Conferir token e formulários LinkedIn sem ler respostas pessoais | escrita | — | 2 |
| `f3base/anuncios-linkedin-cliente-alterar` | Prévia e troca explícita por integração LinkedIn | escrita | `cliente`, `connection_id`, `integracao_id` | 8 |
| `f3base/anuncios-linkedin-consultar` | Importar uma página de respostas LinkedIn autorizadas | escrita | — | 2 |
| `f3base/anuncios-linkedin-webhook-configurar` | Gerenciar assinaturas próprias LinkedIn; consulta e simulação por padrão | escrita | — | 5 |
| `f3base/anuncios-meta-acesso-verificar` | Verificar acesso Meta sem ativar importação; repetir para continuar catálogo | escrita | `revisao` | 2 |
| `f3base/anuncios-verificar` | Estado das origens, cadência e recuperação, sem consultar a rede | leitura | — | 0 |

## arquivos (5)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/arquivos-privados-cadastrar` | Cadastrar conteúdo privado por base64 ou cópia de mídia local | escrita | `idempotency_key`, `sha256` | 5 |
| `f3base/arquivos-privados-excluir-origem` | Excluir mídia pública após conferir cópia privada e vínculos | escrita | `confirmar`, `expected_sha256`, `id` | 4 |
| `f3base/arquivos-privados-listar` | Listar metadados privados e vínculos, sem caminhos ou concessões | leitura | — | 3 |
| `f3base/arquivos-privados-preparar` | Criar e testar diretório privado configurado, sem enviar mensagens | escrita | — | 0 |
| `f3base/arquivos-privados-substituir` | Substituir conteúdo, preservando ID e concessões vigentes | escrita | `expected_sha256`, `id`, `idempotency_key`, `sha256` | 7 |

## avisos (9)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/avisos-fila-ler` | Avisos externos e contingência por e-mail, sem payload nem segredo | leitura | — | 5 |
| `f3base/avisos-parte-reconciliar` | Reconciliar uma parte da thread; principal confirmada não é reenviada | escrita | `acao`, `chave`, `revisao` | 6 |
| `f3base/avisos-reenviar` | Prévia e reenvio explícito de aviso externo; incerto exige aceite de duplicação | escrita | `chave` | 5 |
| `f3base/avisos-slack-apagar` | Simular e apagar mensagens próprias registradas, inclusive após eliminar o contato | escrita | — | 9 |
| `f3base/avisos-slack-corrigir` | Corrigir parte própria registrada, conservando timestamp e thread | escrita | `id`, `modo`, `revisao` | 8 |
| `f3base/avisos-slack-ler` | Consultar presença ou thread de aviso registrado; não comprova leitura humana | leitura | `id` | 3 |
| `f3base/avisos-slack-listar` | Inventário local paginado, sem conteúdo pessoal e sem consulta remota | leitura | — | 8 |
| `f3base/avisos-slack-testes-apagar` | Simular e apagar avisos de teste por ids ou filtro; inclui respostas próprias | escrita | — | 9 |
| `f3base/avisos-slack-verificar` | Consultar presença ou thread de aviso registrado; não comprova leitura humana | leitura | `id` | 3 |

## caminho (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/caminho-lead-limpar` | Retoma somente limpeza autorizada de IDs conhecidos, com prévia e revisão; não repete efeitos incertos | escrita | `id` | 4 |
| `f3base/caminho-lead-recibo-ler` | Resultado dos saltos e limpezas do teste, sem campos pessoais | leitura | `id` | 1 |
| `f3base/caminho-lead-testar` | Teste sob demanda com prévia, revisão e recibo; nenhum envio de conversão e nenhuma repetição incerta | escrita | `formulario` | 7 |

## capi (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/capi-pendencias-ler` | Consultar pendências CAPI | leitura | — | 2 |
| `f3base/capi-reconciliar` | Reconciliar conclusão CAPI | escrita | `desfecho`, `record_id`, `revisao_esperada` | 3 |

## clarity (8)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/clarity-coletar` | Executar plano diário dentro da cota automática e preservar histórico | escrita | — | 0 |
| `f3base/clarity-comparar` | Comparar consultas locais compatíveis sem inventar decomposição diária | leitura | `anterior`, `atual` | 3 |
| `f3base/clarity-consultar` | Consultar API ao vivo e guardar resposta sanitizada, consumindo cota | escrita | `idempotency_key` | 3 |
| `f3base/clarity-exportar` | Exportar consulta sanitizada com hash e resposta comprimida | leitura | `coleta` | 1 |
| `f3base/clarity-gravacoes` | Consultar amostra de links de gravações sob demanda; adaptador de compatibilidade, cota própria | escrita | `ate`, `de` | 8 |
| `f3base/clarity-ler` | Histórico local de consultas móveis; nenhuma chamada externa | leitura | — | 7 |
| `f3base/clarity-reprocessar` | Reprocessar fonte sanitizada local sem consumir API | escrita | `coleta` | 1 |
| `f3base/clarity-restaurar` | Restaurar consulta sanitizada verificada sem consumir API | escrita | `arquivo` | 1 |

## config (10)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/config-complementacoes-ler` | Consultar complementações técnicas e reparo de procedência | leitura | `nome` | 2 |
| `f3base/config-core-contrato-v1` | Contrato de configuração do Core — v1 | leitura | — | 9 |
| `f3base/config-core-escrever` | Simular ou aplicar configuração persistente do Core | escrita | `nome`, `revisao_esperada` | 7 |
| `f3base/config-core-ler` | Ler configuração persistente do Core | leitura | — | 3 |
| `f3base/config-core-perfil-avaliar` | Avaliar perfil de configuração declarado | leitura | — | 7 |
| `f3base/config-core-politica-escrever` | Simular ou substituir política explícita; exige gestão por agentes habilitada | escrita | `politica` | 3 |
| `f3base/config-core-politica-ler` | Estado e revisão da política e da gestão por agentes | leitura | — | 0 |
| `f3base/config-core-verificar` | Consultar ou executar a verificação do Core | escrita | `nome` | 6 |
| `f3base/config-escrever` | Escrever a configuração do implantador | escrita | `arquivo`, `conteudo` | 2 |
| `f3base/config-ler` | Ler a configuração do implantador | leitura | `arquivo` | 1 |

## contatos (10)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/contato-complemento-reconciliar` | Reagendar somente uma atualização após conferir o destino; não repete a captura inicial | escrita | `chave`, `destino` | 6 |
| `f3base/contato-externo-registrar` | Registrar contato externo cifrado; simula por padrão, sem avisos, e-mail ou conversões | escrita | `idempotency_key`, `metodo`, `nome`, `primeiro_contato_em` | 11 |
| `f3base/contato-marcar-teste` | Marcar contato como teste, preservando trilha e cancelando pendências | escrita | `record_id` | 4 |
| `f3base/contato-primeira-resposta-atualizar` | Consultar resposta da equipe; padrão simulado; guarda somente instante e fonte | escrita | `record_id` | 2 |
| `f3base/contato-publicidade-negar` | Registrar negativa explícita do contato sem alterar medição ou apagar entregas históricas | escrita | `motivo`, `record_id`, `revisao` | 4 |
| `f3base/contato-qualidade-indicar` | Indicar etapa comercial; simulação por padrão | escrita | `etapa`, `record_id` | 8 |
| `f3base/contato-sessao-vincular` | Vincular ou desfazer atribuição manual; simula por padrão, exige revisão para gravar e não converte | escrita | `decisor`, `motivo`, `record_id`, `sessoes` | 7 |
| `f3base/contatos-qualidade-atualizar` | Atualizar captação, CRM e retorno em lote limitado | escrita | — | 2 |
| `f3base/contatos-qualidade-indicar-lote` | Indicar etapas em até cinquenta contatos, com revisões individuais | escrita | `etapa`, `itens` | 5 |
| `f3base/contatos-qualidade-ler` | Etapas atuais, histórico e estado do retorno à Meta | leitura | — | 3 |

## conteudos (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/conteudo-instrumentacao-ler` | Auditoria de seções, CTAs e formulários do conteúdo publicado | leitura | — | 5 |
| `f3base/conteudos-relatorio` | Medição editorial: conteudo | leitura | — | 35 |

## conversoes (5)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/conversoes-bloqueadas-reavaliar` | Simular ou antecipar a reavaliação de conversões bloqueadas de um destino; o envio continua no worker com todas as guardas | escrita | `destino` | 4 |
| `f3base/conversoes-contexto-ler` | Conversões por finalidade | leitura | `contract` | 2 |
| `f3base/conversoes-entregas-ler` | Estado privado de conversões por registro; não consulta fornecedores | leitura | `record_id` | 1 |
| `f3base/conversoes-fila-ler` | Resumo da fila de conversões pelo servidor por destino, estado e motivo; sem dados pessoais e sem consultar fornecedores | leitura | — | 3 |
| `f3base/conversoes-recuperar` | Simular ou agendar conversões perdidas sem repetir entregas ou resultados incertos | escrita | `record_id` | 4 |

## credenciais (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/credenciais-ler` | Identidades e ajuda das credenciais; nunca retorna valores secretos | leitura | — | 1 |
| `f3base/credenciais-resumo-ler` | Validade observada de credenciais Core e pacotes pelos contratos locais, sem valores secretos ou HTTP | leitura | — | 0 |
| `f3base/credenciais-verificar` | Verificar candidata sem gravar; mudança de identidade requer confirmação | escrita | `nome`, `revisao_esperada` | 5 |

## email (10)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/email-caixa-consultar` | Consultar caixa; simulação padrão sem gravar ou mover | escrita | — | 3 |
| `f3base/email-caixa-verificar` | Verificar IMAP/TLS e pastas; simulação padrão, aplicação cria pastas ausentes sem importar ou mover | escrita | — | 1 |
| `f3base/email-enviar` | Prévia ou envio SMTP a contato deste site, revisão obrigatória no envio | escrita | `assunto`, `record_id`, `texto` | 5 |
| `f3base/email-legado-limpar` | Simular ou eliminar resíduos do e-mail antigo após conferir a configuração corrente | escrita | — | 2 |
| `f3base/email-novo-lead-homologar` | Autoriza uma única intenção e-mail automático ao novo lead de teste por até uma hora; caixa deve constar na lista de caixas autorizadas deste site | escrita | `confirmar`, `record_id` | 2 |
| `f3base/email-novo-lead-ler` | Estado privado do e-mail e-mail automático ao novo lead; sem corpo ou credenciais | leitura | `record_id` | 1 |
| `f3base/email-registros-ler` | Ler mensagens cifradas, descartes e resultados por contato | leitura | — | 3 |
| `f3base/email-reprocessar` | Reexaminar UID da INBOX; histórico exige opção explícita e revisão | escrita | `uid`, `uidvalidity` | 5 |
| `f3base/email-smtp-verificar` | Provar conexão, TLS e AUTH sem DATA; grava recibo técnico válido por 15 minutos | escrita | — | 3 |
| `f3base/email-wordpress-fila-ler` | Ler recibos SMTP e retenções por cota, sem assunto, corpo ou destinatários | leitura | — | 1 |

## formularios (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/formularios-diagnosticar` | Estado de armazenamento e definições de formulário | leitura | — | 0 |
| `f3base/formularios-tentativas-ler` | Ler tentativas barradas dos formulários | leitura | — | 9 |

## ga4 (7)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/ga4-acervo-ler` | Séries diárias publicadas GA4; métricas não somadas | leitura | — | 8 |
| `f3base/ga4-coletar` | Coletar uma página GA4 autorizada, incluindo dia retroativo; publicação ao concluir | escrita | — | 4 |
| `f3base/ga4-comparar` | Comparação das séries GA4 em dois períodos explícitos | leitura | `anterior_ate`, `anterior_de` | 11 |
| `f3base/ga4-exportar` | Exportar parte autenticada CSV/JSON; base64, hash, revisão e continuação | leitura | — | 9 |
| `f3base/ga4-historico` | Fotografias GA4, tentativas, qualidade e cobertura por recorte | leitura | — | 9 |
| `f3base/ga4-lacunas-ler` | Dias não coletados, vazios e falhos do GA4, por recorte | leitura | — | 8 |
| `f3base/ga4-status` | Estado local do consumidor/acervo GA4; não consulta fornecedor | leitura | — | 0 |

## google (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/google-ads-acervo-ler` | Lê dias do acervo Google Ads, com moeda, revisão e cobertura; GCLID somente por igualdade exata | leitura | `ate`, `dataset`, `de` | 6 |
| `f3base/google-ads-acervo-status` | Estado do leitor Google Ads, sem chamada ao fornecedor | leitura | — | 0 |
| `f3base/google-conversao-previa` | Prévia privada com hashes e motivos, inclusive para contato de teste; sem enfileirar ou enviar | leitura | `record_id` | 1 |

## gsc (9)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/gsc-coletar` | Executar uma página da coleta autorizada Search Console | escrita | — | 0 |
| `f3base/gsc-consultas-coletar` | Executar uma página da coleta autorizada Search Console | escrita | — | 0 |
| `f3base/gsc-consultas-historico` | Fotografias Search Console e dados arquivados | leitura | — | 5 |
| `f3base/gsc-consultas-lacunas-ler` | Inventário persistido de dias pendentes e resolvidos | leitura | — | 3 |
| `f3base/gsc-consultas-status` | Estado e cobertura da coleta Search Console | leitura | — | 0 |
| `f3base/gsc-historico` | Fotografias Search Console e dados arquivados | leitura | — | 6 |
| `f3base/gsc-importar` | Importar fotografia autorizada page/date ou total de propriedade | escrita | `cobertura`, `dimensoes`, `escopo`, `estado`, `extraido_em`, `filtros`, `fonte`, `linhas`, `pesquisa`, `propriedade` | 10 |
| `f3base/gsc-lacunas-ler` | Inventário persistido de dias pendentes e resolvidos | leitura | — | 4 |
| `f3base/gsc-status` | Estado e cobertura da coleta Search Console | leitura | — | 0 |

## ia (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/ia-referencia-excluir` | Excluir referência observada pela revisão | escrita | `id`, `revisao` | 2 |
| `f3base/ia-referencia-gravar` | Criar ou revisar referência observada, sem consultar a URL da evidência | escrita | `chave`, `evidencia`, `evidencia_tipo`, `observado_em`, `origem`, `provedor`, `revisao_estado`, `tipo`, `url` | 12 |
| `f3base/ia-referencias-ler` | Referências observadas com origem e evidência | leitura | — | 6 |

## integracoes (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/integracoes-ler` | Consultar estado, filas e configuração de integrações sem efeitos | leitura | — | 0 |
| `f3base/integracoes-verificar-agora` | Verifica acesso remoto e atualiza catálogos, sem criar contatos | escrita | — | 0 |

## leads (8)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/lead-jornada-ler` | Eventos observados antes do contato; sessão e carregamentos não comprovam sequência entre abas | leitura | `record_id` | 3 |
| `f3base/leads-atualizar` | Simular ou atualizar atendimento, suspeita e lixeira; entregar=true aprova e solicita entrega uma vez | escrita | `alteracoes`, `record_id`, `revisao_esperada` | 5 |
| `f3base/leads-avisos-reenviar` | Reconciliar ou reenviar aviso interno explicitamente | escrita | `record_id` | 4 |
| `f3base/leads-eliminar-registro` | Eliminar registro privado com journal, anexos e concessões | escrita | `record_id`, `revisao_esperada` | 4 |
| `f3base/leads-ler` | Ler leads | leitura | — | 10 |
| `f3base/leads-marcar-teste` | Reclassificar contato e seus avisos como teste, sem novo envio | escrita | `record_id`, `revisao_esperada` | 4 |
| `f3base/leads-registros-ler` | Ler registros privados de contatos; escolha explícita, sem efeitos | leitura | — | 24 |
| `f3base/leads-resposta-reenviar` | Simular e reenviar resposta ao visitante, com revisão e aceite de duplicação quando incerta | escrita | `record_id` | 4 |

## linkedin (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/linkedin-campanha-reabrir` | Reabrir consulta de campanha com revisão, prévia e motivo; sem reenvio comercial | escrita | `chave`, `integracao_id`, `simular` | 5 |
| `f3base/linkedin-conversao-previa` | Prévia privada de conversão LinkedIn de um registro, inclusive de teste; não enfileira nem envia | leitura | `record_id` | 1 |
| `f3base/linkedin-formularios-configurar` | Selecionar formulários explícitos ou todos os concedidos da conta, com prévia vinculada à revisão | escrita | `formularios_modo`, `integracao_id`, `simular` | 5 |

## llms (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/llms-arquivo` | Arquivo llms gerenciado | escrita | — | 3 |
| `f3base/llms-cobertura-ler` | Consultar cobertura Markdown por item, sem conversão ou HTTP | leitura | — | 0 |
| `f3base/llms-reprocessar` | Reprocessar manualmente a geração editorial | escrita | — | 0 |

## medicao (7)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/medicao-anotacao-excluir` | Excluir anotação pela revisão, preservando auditoria | escrita | `id`, `revisao` | 2 |
| `f3base/medicao-anotacao-gravar` | Anotar dias de testes e excluir explicitamente de análises | escrita | `ate`, `chave`, `de`, `excluir`, `motivo` | 6 |
| `f3base/medicao-contexto-ler` | Contexto público de medição | leitura | — | 0 |
| `f3base/medicao-editorial` | Conteúdo, aquisição e sessões observadas | leitura | — | 36 |
| `f3base/medicao-eventos-ler` | Catálogo público de eventos | leitura | — | 3 |
| `f3base/medicao-saude-ler` | Diagnóstico da coleta e lacunas observadas | leitura | — | 0 |
| `f3base/medicao-sondas-ler` | Sondas e requisições técnicas observadas pelo WordPress | leitura | — | 7 |

## meta (8)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/meta-ads-relatorio-ler` | Histórico diário por campanha e relação com contatos e parceiros; cursor consistente, moedas e cobertura preservadas | leitura | `ate`, `de` | 4 |
| `f3base/meta-ads-status` | Estado da concessão local Meta Ads e seleção do consumidor Core, sem Graph | leitura | — | 0 |
| `f3base/meta-crm-verificar` | Verificar leitura do dataset sem enviar conversão | escrita | — | 1 |
| `f3base/meta-entregas-ler` | Eventos Meta por rota e dia; evidência local separada da plataforma | leitura | — | 4 |
| `f3base/meta-homologacao-registrar` | Registrar evidência externa para avaliar elegibilidade do modo servidor | escrita | `catalogo_equivalente`, `credencial_validada`, `eventos`, `evidencia_url`, `fim`, `inicio`, `sem_meta_terceiros` | 7 |
| `f3base/meta-lead-enviar` | Marcar Lead do contato para CAPI; simula por padrão, preserva consentimento e recibo | escrita | `motivo`, `record_id` | 4 |
| `f3base/meta-monitoramento-ler` | Histórico local de alterações, contagens e EMQ, com paginação | leitura | `ate`, `de`, `report` | 8 |
| `f3base/meta-monitoramento-status` | Estado da concessão de monitoramento Meta | leitura | — | 0 |

## navegacao (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/navegacao-listar` | Pesquisar menus clássicos e blocos publicados | leitura | `tipo` | 3 |
| `f3base/navegacao-verificar` | Conferir navegação renderizada no cabeçalho da home | escrita | — | 0 |

## operacao (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/operacao-recuperacao` | Pausar/drenar ou retomar o Core após reconciliação | escrita | `acao` | 6 |
| `f3base/operacao-recuperacao-ler` | Consultar barreira de recuperação do Core | leitura | — | 0 |

## pipedrive (8)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/pipedrive-atividade-reparar` | Reconciliar somente a atividade complementar | escrita | `chave`, `revisao` | 3 |
| `f3base/pipedrive-avisos-ler` | Avisos incertos, esgotados ou sem destinatários | leitura | — | 2 |
| `f3base/pipedrive-fila-ler` | Fila paginada e vínculos técnicos, sem dados pessoais | leitura | — | 3 |
| `f3base/pipedrive-previa` | Prévia privada dos dados elegíveis, sem envio externo | leitura | `record_id` | 1 |
| `f3base/pipedrive-processar` | Executar lote limitado da fila Pipedrive | escrita | — | 0 |
| `f3base/pipedrive-reconciliar` | Resolver pessoa incerta, selecionar lead próprio ou adicionar e-mail alternativo por decisão administrativa | escrita | `acao`, `chave`, `referencia_remota`, `revisao` | 8 |
| `f3base/pipedrive-reenviar` | Reagenda uma entrega; resultados incertos continuam sujeitos à reconciliação | escrita | `chave`, `revisao`, `simular` | 4 |
| `f3base/pipedrive-verificar` | Estado de verificação da conta, sem efeito | leitura | — | 0 |

## publicacao (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/publicacao-ler` | Ler estado da publicação | leitura | — | 1 |
| `f3base/publicacao-verificar` | Verificar publicação | escrita | — | 8 |

## qualidade (5)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/qualidade-catalogo-carregar` | Carregar funis e etapas da conta Pipedrive verificada; simulação sem HTTP | escrita | — | 1 |
| `f3base/qualidade-conversoes-previa` | Prévia comercial por etapa e destino; nenhuma ação de contato é reutilizada | leitura | `etapa`, `record_id` | 3 |
| `f3base/qualidade-crm-vincular` | Associar negócio existente por decisão explícita do operador | escrita | `negocio_id`, `record_id` | 6 |
| `f3base/qualidade-ler` | Ler configuração e catálogo local de qualidade, sem consulta remota | leitura | — | 1 |
| `f3base/qualidade-meta-reenviar` | Reativar explicitamente um envio suspenso, preservando o destino | escrita | `chave` | 3 |

## redirects (6)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/redirects-escrever` | Simular ou aplicar redirects com revisão e validação integral | escrita | `operacao` | 7 |
| `f3base/redirects-historico-escrever` | Retirar ou restaurar um caminho histórico | escrita | `caminho`, `post_id`, `revisao_esperada` | 6 |
| `f3base/redirects-historico-ler` | Consultar rotas históricas e conflitos por conteúdo | leitura | `post_id` | 1 |
| `f3base/redirects-ler` | Ler redirects, revisão e restrições sem HTTP | leitura | — | 3 |
| `f3base/redirects-planejar-base-taxonomia` | Enumerar pares exatos de termos públicos para uma base antiga | leitura | `de`, `para`, `revisao_esperada`, `taxonomia` | 4 |
| `f3base/redirects-verificar` | Consultar ou provar redirects por GET anônimo | escrita | — | 5 |

## sessoes (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/sessao-detalhar` | Medição editorial: sessao | leitura | `sessao` | 35 |
| `f3base/sessoes-listar` | Medição editorial: sessoes | leitura | — | 35 |

## tracking (3)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/tracking-diagnostico` | Slots configurados e última inspeção do GTM, sem HTTP | leitura | — | 0 |
| `f3base/tracking-encerrar-gtm` | Encerrar tarefa GTM sem contêiner, com revisão e auditoria | escrita | `revisao` | 2 |
| `f3base/tracking-verificar-gtm` | Inspecionar uma cópia limitada do contêiner público, sem executar JavaScript | escrita | — | 0 |

## whatsapp (2)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/whatsapp-conversa-consultar` | Simular ou processar janela incremental da ponte Slack | escrita | — | 3 |
| `f3base/whatsapp-conversa-verificar` | Provar leitura Slack e envelope da ponte, sem importar ou avisar | leitura | — | 1 |

## outros (27)

| Ability | Rótulo | Tipo | Obrigatórios | Total |
| --- | --- | --- | --- | --- |
| `f3base/agentes-relatorio` | Agentes e buscadores: requisições, conteúdo e frequência | leitura | — | 15 |
| `f3base/aquisicao-relatorio` | Medição editorial: aquisicao | leitura | — | 35 |
| `f3base/ativos-publicos-ler` | Estado da configuração e dos módulos públicos pré-gerados | leitura | — | 0 |
| `f3base/cache-reaquecimento-ler` | Ler configuração e resultados do reaquecimento, sem executar requisições | leitura | — | 0 |
| `f3base/campanhas-origem-simular` | Simular fontes de conta e nome da campanha usando somente o acervo local concedido, sem gravar contato nem enviar ao CRM | leitura | `parametros` | 2 |
| `f3base/canais-organicos-simular` | Simular regras e catálogo IA candidatos, ou contatos dos últimos 30 dias, sem gravar nem chamar o CRM | leitura | — | 5 |
| `f3base/como-usar` | Como usar o plugin do site | leitura | — | 8 |
| `f3base/comportamento-ler` | Ler comportamento | leitura | — | 10 |
| `f3base/configuracao-aviso-dispensar` | Dispensar um aviso de configuração ativo | escrita | `nome` | 1 |
| `f3base/contexto-sessao-simular` | Simular app e classe de rede com catálogo candidato; sem HTTP ou gravação | leitura | — | 4 |
| `f3base/ctas-inventariar` | Inspeciona lote de conteúdo salvo para CTAs com destino inválido, sem HTTP ou renderização | leitura | — | 2 |
| `f3base/desempenho-ler` | Tempos por módulo desta requisição ou de sondagem interna assinada da página/login | leitura | — | 2 |
| `f3base/documentacao-ler` | Índice e leitura paginada da documentação instalada do Core | leitura | — | 3 |
| `f3base/estado-inventario-ler` | Inventário fechado de estado, propriedade, backup, retenção e desinstalação | leitura | — | 0 |
| `f3base/eventos-ler` | Ler eventos | leitura | — | 10 |
| `f3base/execucoes-ler` | Histórico paginado das passagens e tarefas do Core | leitura | — | 4 |
| `f3base/executar-pendentes` | Executar tarefas vencidas do Core sob reserva e orçamento | escrita | — | 10 |
| `f3base/instagram-conversa-recibo` | Consultar prova local/Meta; reconciliar somente recibo persistido ou supressão real, sem repetir ingestão | escrita | `account_id`, `connection_id`, `event_id` | 5 |
| `f3base/midia-prontidao-ler` | Prontidão local por plataforma e destino, com fontes, motivos e ações; não chama fornecedores | leitura | — | 0 |
| `f3base/ofertas-diagnosticar` | Inspecionar marcações de ofertas em HTML informado, sem executar nem buscar páginas | leitura | `html` | 1 |
| `f3base/relatorios-integrados-ler` | Relatórios por página, campanha, formulário, conteúdo, qualidade e operação; cobertura e comparação | leitura | — | 37 |
| `f3base/resumo-operacional-ler` | Resumo operacional local até 4 KB; validade desconhecida é null e listas excedentes têm detalhe | leitura | — | 1 |
| `f3base/saude-ler` | Estado operacional do Core | leitura | — | 1 |
| `f3base/schema-verificar` | Verificar schema publicado | escrita | — | 4 |
| `f3base/servidor-aplicar` | Consultar, aplicar ou remover somente as regras próprias do servidor, com revisão e restauração | escrita | — | 3 |
| `f3base/slack-verificar` | Verifica credencial; postar_teste envia mensagem marcada somente quando solicitado | escrita | — | 3 |
| `f3base/vitais-ler` | Desempenho de campo por caminho e métrica | leitura | — | 10 |
